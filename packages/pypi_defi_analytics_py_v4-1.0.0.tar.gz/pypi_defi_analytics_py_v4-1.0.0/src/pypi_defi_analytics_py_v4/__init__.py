"""DeFi analytics library for NEAR Protocol."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import requests

__version__ = "1.0.0"
__all__ = ["PypiDefiAnalyticsPyV4Client"]

NEAR_RPC = "https://rpc.mainnet.near.org"
REF_FINANCE_API = "https://api.stats.ref.finance/api"


class PypiDefiAnalyticsPyV4Client:
    """DeFi analytics client for NEAR Protocol."""

    def __init__(
        self,
        rpc_url: str = NEAR_RPC,
        timeout: int = 30,
    ) -> None:
        self.rpc_url = rpc_url
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    # ── Internal helpers ──────────────────────────────────────────────────

    def _rpc(self, method: str, params: Any) -> Any:
        """Call NEAR JSON-RPC and return result."""
        payload = {"jsonrpc": "2.0", "id": "dfa", "method": method, "params": params}
        resp = self._session.post(self.rpc_url, json=payload, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        if "error" in data:
            raise RuntimeError(f"RPC error: {data['error']}")
        return data["result"]

    def _view_call(self, account_id: str, method: str, args_base64: str = "e30=") -> Any:
        """Call a NEAR contract view function."""
        result = self._rpc("query", {
            "request_type": "call_function",
            "finality": "final",
            "account_id": account_id,
            "method_name": method,
            "args_base64": args_base64,
        })
        import json, base64
        raw = bytes(result["result"])
        return json.loads(raw.decode())

    def _ref_get(self, path: str) -> Any:
        """GET from Ref Finance stats API."""
        url = f"{REF_FINANCE_API}{path}"
        resp = self._session.get(url, timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    # ── NEAR Network ──────────────────────────────────────────────────────

    def get_network_status(self) -> Dict[str, Any]:
        """Return current NEAR network status."""
        return self._rpc("status", [None])

    def get_block(self, finality: str = "final") -> Dict[str, Any]:
        """Return latest block info."""
        return self._rpc("block", {"finality": finality})

    def get_account(self, account_id: str) -> Dict[str, Any]:
        """Return NEAR account details."""
        return self._rpc("query", {
            "request_type": "view_account",
            "finality": "final",
            "account_id": account_id,
        })

    def get_near_price(self) -> Optional[float]:
        """Return NEAR/USD price from Ref Finance."""
        try:
            data = self._ref_get("/token-price?token_id=wrap.near")
            return float(data.get("price", 0))
        except Exception:
            return None

    # ── Ref Finance Pools ─────────────────────────────────────────────────

    def get_pools(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Return top pools from Ref Finance."""
        data = self._ref_get(f"/pools?limit={limit}")
        if isinstance(data, list):
            return data
        return data.get("pools", [])

    def get_pool(self, pool_id: int) -> Dict[str, Any]:
        """Return single pool details."""
        pools = self._ref_get(f"/pool/{pool_id}")
        return pools

    def get_top_pools_by_tvl(self, top_n: int = 10) -> List[Dict[str, Any]]:
        """Return top N pools sorted by TVL."""
        pools = self.get_pools(limit=200)
        return sorted(
            pools,
            key=lambda p: float(p.get("tvl", 0) or 0),
            reverse=True,
        )[:top_n]

    # ── Token Analytics ───────────────────────────────────────────────────

    def get_token_price(self, token_id: str) -> Optional[float]:
        """Return USD price for a NEAR token."""
        try:
            data = self._ref_get(f"/token-price?token_id={token_id}")
            return float(data.get("price", 0))
        except Exception:
            return None

    def get_tokens(self) -> List[Dict[str, Any]]:
        """Return list of tokens on Ref Finance."""
        return self._ref_get("/tokens")

    # ── Yield / APR ───────────────────────────────────────────────────────

    def get_farm_list(self) -> List[Dict[str, Any]]:
        """Return active farms from Ref Finance."""
        try:
            return self._ref_get("/farms")
        except Exception:
            return []

    def calculate_apr(self, daily_reward_usd: float, tvl_usd: float) -> float:
        """Return APR percentage given daily reward and TVL."""
        if tvl_usd <= 0:
            return 0.0
        return round((daily_reward_usd * 365 / tvl_usd) * 100, 4)

    # ── Wallet Analytics ──────────────────────────────────────────────────

    def get_wallet_near_balance(self, account_id: str) -> float:
        """Return NEAR balance in human-readable units."""
        account = self.get_account(account_id)
        yocto = int(account.get("amount", 0))
        return yocto / 1e24

    def get_wallet_summary(self, account_id: str) -> Dict[str, Any]:
        """Return wallet overview including NEAR balance and USD value."""
        balance = self.get_wallet_near_balance(account_id)
        price = self.get_near_price() or 0.0
        return {
            "account_id": account_id,
            "near_balance": balance,
            "near_price_usd": price,
            "portfolio_usd": round(balance * price, 2),
            "timestamp": int(time.time()),
        }

    # ── Aggregated Metrics ────────────────────────────────────────────────

    def get_protocol_summary(self) -> Dict[str, Any]:
        """Return high-level DeFi protocol summary for NEAR."""
        pools = self.get_top_pools_by_tvl(top_n=5)
        near_price = self.get_near_price()
        total_tvl = sum(float(p.get("tvl", 0) or 0) for p in pools)
        return {
            "near_price_usd": near_price,
            "top_5_pools_tvl_usd": round(total_tvl, 2),
            "top_pools": [
                {
                    "id": p.get("id"),
                    "token_symbols": p.get("token_symbols"),
                    "tvl": p.get("tvl"),
                }
                for p in pools
            ],
            "timestamp": int(time.time()),
        }