# defi-analytics-py v4

DeFi analytics library for NEAR Protocol.

**Python:** 3.9+ | **PyPI:** `pypi-defi-analytics-py-v4`

## Installation

pip install pypi-defi-analytics-py-v4

## Quick Start

from pypi_defi_analytics_py_v4 import PypiDefiAnalyticsPyV4Client

client = PypiDefiAnalyticsPyV4Client()

# Network
status = client.get_network_status()
block  = client.get_block()

# Accounts & Pricing
account = client.get_account("alice.near")
price   = client.get_near_price()

# Pools
pools     = client.get_pools()
pool      = client.get_pool(pool_id=1)
top_pools = client.get_top_pools_by_tvl(limit=10)

# Tokens
token_price = client.get_token_price("wrap.near")
tokens      = client.get_tokens()

# Farms
farms = client.get_farm_list()

## API Reference

| Method | Description |
|---|---|
| `get_network_status()` | Current NEAR network status |
| `get_block()` | Latest block info |
| `get_account(account_id)` | Account details |
| `get_near_price()` | NEAR token USD price |
| `get_pools()` | All Ref Finance pools |
| `get_pool(pool_id)` | Single pool by ID |
| `get_top_pools_by_tvl(limit)` | Top pools ranked by TVL |
| `get_token_price(token_id)` | Token price by contract ID |
| `get_tokens()` | All tracked tokens |
| `get_farm_list()` | Active farm list |

## Custom Configuration

client = PypiDefiAnalyticsPyV4Client(
    rpc_url="https://rpc.mainnet.near.org",
    timeout=60,
)

## License

MIT