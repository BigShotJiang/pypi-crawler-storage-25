import os
import re


def indent(indent_level, text, indent_char="    ", indent_suffix="", indent_prefix=""):
    if set.intersection(set([c for c in indent_char]), set([c for c in indent_suffix]), set([c for c in indent_prefix])):
        raise AttributeError("indent_char, indent_suffix and indent_prefix and not have any char-wise overlap!")

    line_regex = re.compile(fr"^{re.escape(indent_prefix)}(({re.escape(indent_char)})*){re.escape(indent_suffix)}")

    indented_text = ""
    for line in re.split('(\n)', text):
        if line and line != "\n":
            match = line_regex.search(line)
            indents_length = None
            if match:
                indents = match.group(1)
                indents_length = len(indents)

            if indents_length is not None and indents_length % len(indent_char) == 0:
                already_present_indents = int(indents_length / len(indent_char))
                line_copy = line[:]
                line = line[len(indent_prefix) + indents_length + len(indent_suffix):]

                adjusted_indent_level = indent_level + already_present_indents
                indented_text += indent_prefix + indent_char * adjusted_indent_level + indent_suffix + line

                if line_copy not in indented_text:
                    raise Exception()
            else:
                indented_text += indent_prefix + indent_char * indent_level + indent_suffix + line
        else:
            indented_text += line
    return indented_text


def replace_first_char_every_line(text, new_char):
    out = ""
    for line in re.split('(\n)', text):
        if line == "\n":
            out += "\n"
            continue
        out += replace_char_at_pos(line, 0, new_char)
    return out



def replace_char_at_pos(string, pos, new_char):
    return string[:pos] + new_char + string[pos+1:]



def connect_pipes(input_str, direction_up = True):
    if direction_up:
        input_str_copy = "".join([line for line in re.split('(\n)', input_str)[::-1]])
    else:
        input_str_copy = input_str[:]

    pipe_positions = set()

    output_str = input_str_copy[:]

    char_pos_offset = 0
    for line in re.split('(\n)', input_str_copy):
        if line == "\n":
            char_pos_offset += 1
            continue
        # apply pipe positions
        for pipe_position in pipe_positions:
            if char_pos_offset + pipe_position >= len(output_str):
                continue
            if output_str[char_pos_offset + pipe_position] == " ":
                output_str = replace_char_at_pos(output_str, char_pos_offset + pipe_position, "|")

        # update pipe positions
        for line_char_number, char in enumerate(line):
            if char.strip() == "":
                continue
            if char == "|":
                pipe_positions.add(line_char_number)
            else:
                if line_char_number in pipe_positions:
                    pipe_positions.remove(line_char_number)

        # update char pos offset
        char_pos_offset += len(line)

    if direction_up:
        output_str = "".join([line for line in re.split('(\n)', output_str)[::-1]])
    return output_str

from pathlib import Path

def get_project_root() -> Path:
    return Path(__file__).parent.parent
def get_project_gen_root() -> Path:
    return Path(os.path.join(get_project_root(), "../gen/"))

