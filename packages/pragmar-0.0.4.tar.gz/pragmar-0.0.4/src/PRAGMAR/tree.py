import os
from typing import List, TypeVar, Generic

from src.PRAGMAR.util import get_project_gen_root

"""
Tree Implementation
"""

class TreeNode:
    def __init__(self, type, name=None):
        self.type = type
        self.name = name
        self.data = dict()
        self.parent = None

    def get_all_parent(self) -> 'AllParentNode':
        current = self
        while current.parent:
            current = current.parent

        # check for generated wrapper
        if current.type == "AllParent" and not isinstance(current, AllParentNode):
            return current.wrapped_ap

        if not isinstance(current, AllParentNode):
            raise RuntimeError("AllParent could not be found")
        return current

    def get_path_to_root(self):
        path = [self]
        while not isinstance(path[-1], AllParentNode) and not path[-1].type == "AllParent":
            path.append(path[-1].parent)

        if not isinstance(path[-1], AllParentNode):
            path[-1] = path[-1].wrapped_ap

        path.reverse()
        return path

    def attribute(self, attribute_name):
        return self.get_all_parent().attribute_definitions.get_attribute(attribute_name, self)

    def get_children(self):
        return []

    def __repr__(self):
        return f"<{self.type}: {self.name}>"

class InnerNode(TreeNode):
    def __init__(self, type=None, children=None):
        super().__init__(type)
        self.children = children
        if children is None:
            self.children = dict()
        self.children_order = []

    def add_child_no_name(self, child_value):
        name = child_value.type
        return self.add_child(name, child_value)

    def add_child(self, child_key: str, child_value):
        if (child_key in self.children.keys()):
            raise KeyError(f"Duplicate child key: {child_key}")
        self.children_order.append(child_key)
        self.children[child_key] = child_value
        child_value.parent = self
        child_value.name = child_key
        return child_value

    def get_child(self, key):
        if key is int:
            str_key = self.children_order[key]
        else:
            str_key = key
        return self.children[str_key]

    def get_children(self):
        return self.children.values()

    def get_parent_that(self, function):
        current = self.parent
        while not function(current) and current is not None:
            current = current.parent
        return current

    def get_or_add_node_of_type(self, node):
        if node.type not in self.children.keys():
            self.add_child(node.type, node)
        return self.children[node.type]

TListElement = TypeVar('TListElement')
class ListNode(InnerNode, Generic[TListElement]):
    def __init__(self, list_type):
        super().__init__(f"ListNode[{list_type}]")
        self.key_counter = 0
        self.list_type = list_type

    def add_child(self, child_value: TListElement):
        super().add_child(self.key_counter, child_value)
        self.key_counter += 1
        return child_value

    def get_children(self) -> List[TListElement]:
        return list(super().get_children())


class GrammarDefinitionContext:
    def __init__(self, ap):
        self.ap = ap

    def __enter__(self):
        # Entrance logic here, called before entry of with block
        pass

    def __exit__(self, exception_type, exception_val, trace):
        self.regenerate_classes()

    def regenerate_classes(self):
        grammar_valid = self.ap.attribute("check_grammar")()
        class_helpers = self.ap.attribute("generate_class_helpers")()
        gen_root = get_project_gen_root()
        with open(os.path.join(gen_root, "classes.py"), "w") as f:
            f.write(class_helpers)

class AttributeDefinitionContext:
    def __init__(self, ap):
        self.ap = ap

    def __enter__(self):
        # Entrance logic here, called before entry of with block
        pass

    def __exit__(self, exception_type, exception_val, trace):
        self.regenerate_nodes()

    def regenerate_nodes(self):
        grammar_valid = self.ap.attribute("check_grammar")()
        node_helpers = self.ap.attribute("generate_node_helpers")()

        gen_root = get_project_gen_root()
        with open(os.path.join(gen_root, "nodes.py"), "w") as f:
            f.write(node_helpers)
        # also let the node subs in classes.py inherit from the newly generated node classes
        class_imports = ""
        with open(os.path.join(gen_root, "classes.py"), "r") as f:
            classes = f.read()
            main, stubs = classes.split("# Node Classes")

            imports = []
            for line in stubs.split("\n"):
                if line.startswith("class ") and line.endswith(":"):
                    class_name = line[6:-1]
                    imports.append(class_name)

            class_imports = main + "# Node Classes\nfrom gen.nodes import " + ",".join(imports)
        with open(os.path.join(gen_root, "classes.py"), "w") as f:
            f.write(class_imports)


class AllParentNode(InnerNode):
    def __init__(self):
        super().__init__("AllParent")

        self.add_child("Attributes", AspectList())
        self.add_child("Grammar", GrammarNode())
        self.add_child("ASTs", ListNode("ASTNode"))

        self.attribute_definitions = self.children["Attributes"]
        self.grammar_definition = self.children["Grammar"]
        self.ASTs = self.children["ASTs"]

    def create_aspect(self, aspect_name):
        new_aspect = AspectNode(aspect_name) # init new aspect
        self.attribute_definitions.add_child(new_aspect) # add it to the aspect list
        return AspectBuilder(new_aspect) # return a builder for the aspect

    def create_grammar(self, base_node=None):
        own_grammar = self.get_child("Grammar")
        return GrammarBuilder(own_grammar, base_node)

    def add_ast(self, ast_root):
        return self.ASTs.add_child(ast_root)

    def define_grammar(self):
        return GrammarDefinitionContext(self)

    def define_attributes(self, def_root):
        def_root.set_all_parent(self)
        return AttributeDefinitionContext(self)

"""
Builder Implementations for Grammar and Attributes
"""

class GrammarBuilder:
    def __init__(self, grammar: 'GrammarNode', base_node):
        self.grammar = grammar
        self.current_rule = None
        self.current_base_node = base_node
        if self.current_base_node is None:
            self.current_base_node = "ASTNode"

    def Head(self, head_type, *, head_super_type=None) -> 'GrammarBuilder':
        if head_super_type is None and not head_type == "Node":
            head_super_type = self.current_base_node
        if head_type in [c.head_type for c in self.grammar.get_child("ListNode[Rule]").children.values()]:
            raise KeyError(f"Duplicate head type definition: {head_type}")

        # add class node to hierarchy
        if head_super_type:
            super_class = self.grammar.get_child("ClassNode").find_class_node_of_type(head_super_type)
            super_class.sub_classes.add_child(ClassNode(head_type))

        # add grammar rule
        self.current_rule = self.grammar.get_child("ListNode[Rule]").add_child(RuleNode(head_type, head_super_type))
        return self


    def Field(self, *, field_type, field_name=None):
        if self.current_rule is None:
            raise RuntimeError("Start the definition of a Grammar Rule with \"Head()\", then you can add Fields")

        if isinstance(field_type, str) and "ListNode[" in field_type:
            # add class node to hierarchy
            super_class = self.grammar.get_child("ClassNode").find_class_node_of_type("ListNode")
            super_class.sub_classes.add_child(ClassNode(field_type))

        if field_name is None:
            field_name = field_type

        self.current_rule.get_child("ListNode[Field]").add_child(FieldNode(field_type, field_name))
        return self

class AspectBuilder:
    def __init__(self, aspect: 'AspectNode'):
        self.aspect = aspect
        self.current_path = []

    def __get_definition_root_list(self):
        return self.aspect.get_child("ListNode[AttrDefinitionRootPart]")

    def __get_attribute_definition_root(self, attribute_name):
        # search for definition
        for definition_root in self.__get_definition_root_list().get_children():
            if definition_root.attr_name == attribute_name:
                return definition_root
        return None

    def add_definition_path(self, path):
        attr_name = path[-1].function.__name__
        # search for definition
        definition_root = self.__get_attribute_definition_root(attr_name)
        if not definition_root:
            definition_root = self.__get_definition_root_list().add_child(AttrDefinitionRootPartNode(attr_name))

        node_to_apply_path_to = definition_root
        for path_part in path:
            # try get equivalent node
            for sub_def in node_to_apply_path_to.sub_defs.get_children():
                if path_part.equals(sub_def):
                    node_to_apply_path_to = sub_def
                    break
            # if there is none, add it
            else:
                node_to_apply_path_to = node_to_apply_path_to.sub_defs.add_child(path_part)

    def define_on(self, type):
        if self.current_path:
            raise RuntimeError("A previous definition has not been finished, please do so by calling Value(), before starting a new definition")
        self.current_path = [AttrDefinitionTypePartNode(type)]
        return self

    def Type(self, type) -> 'AttributePathBuilder':
        self.current_path.append(AttrDefinitionTypePartNode(type))
        return self

    def Name(self, name) -> 'AttributePathBuilder':
        self.current_path.append(AttrDefinitionNamePartNode(name))
        return self

    def Value(self):
        def decorator(func):
            # take in attribute function, add it to the path using a value-part,
            # apply a copy of the path to the tree, clear the path for further definitions
            self.current_path.append(AttrDefinitionValuePartNode(func))
            self.add_definition_path(self.current_path[:])
            self.current_path = []
            def do_not_call_manually(*args, **kwargs):
                raise RuntimeError(
                    "attributes are not meant to be called manually! They are only registered by this decorator.")
            return do_not_call_manually
        return decorator



class LeafNode(TreeNode):
    def __init__(self, value=None, all_parent=None):
        super().__init__(value)

"""
Grammar Implementation
"""

class ClassNode(InnerNode):
    def __init__(self, class_type):
        super().__init__("ClassNode")
        self.sub_classes = ListNode("ClassNode")
        self.add_child("sub_classes", self.sub_classes)
        self.class_type = class_type
        self.data["class_type"] = self.class_type

    def raw_type(self, t):
        if "[" in t:
            t = t[9:-1]
        return t

    def get_subtypes(self):
        subtypes = set()
        subtypes.add(self.raw_type(self.class_type))
        for sc in self.sub_classes.children.values():
            subtypes.add(self.raw_type(sc.class_type))
            for sc_subtype in sc.get_subtypes():
                subtypes.add(self.raw_type(sc_subtype))
        return subtypes

    def find_class_node_of_type(self, class_type):
        if self.class_type == class_type:
            return self
        for sc in self.sub_classes.children.values():
            if class_type == sc.class_type:
                return sc

        for child in self.sub_classes.children.values():
            res = child.find_class_node_of_type(class_type)
            if res:
                return res
        return None

    def get_immediate_super_type(self):
        if self.parent is None or not isinstance(self.parent, ListNode):
            return None
        if not isinstance(self.parent.parent, ClassNode):
            return None
        return self.parent.parent.class_type

    def is_subtype_of(self, subtype, super_type):
        subtype_node = self.find_class_node_of_type(subtype)
        supertype_node = self.find_class_node_of_type(super_type)
        while subtype_node is not supertype_node:
            subtype_node = subtype_node.parent
            if subtype_node is None:
                return False
        return True

class GrammarNode(InnerNode):
    def __init__(self):
        super().__init__("Grammar")

        # initialize default class hierarchy#
        #########################
        #       Node            #
        #       /  \            #
        # AstNode  ListNode     #
        #              \        #
        #           AstListNode #
        #########################

        node = ClassNode("Node")
        ast_node = ClassNode("ASTNode")
        list_node = ClassNode("ListNode")
        ast_list_node = ClassNode("ASTListNode")

        node.get_child("sub_classes").add_child(ast_node)
        ast_node.parent = node.get_child("sub_classes")
        node.get_child("sub_classes").add_child(list_node)
        list_node.parent = node.get_child("sub_classes")
        list_node.get_child("sub_classes").add_child(ast_list_node)
        ast_list_node.parent = list_node.get_child("sub_classes")

        self.class_node = node
        self.grammar_rules = ListNode("Rule")

        self.add_child_no_name(self.class_node)
        self.add_child_no_name(self.grammar_rules)


    def get_immediate_super_type(self, type):
        node_of_type = self.class_node.find_class_node_of_type(type)
        if not node_of_type:
            raise RuntimeError(f"Type \"{type}\" could not be found")
        return node_of_type.get_immediate_super_type()

    def is_subtype_of(self, subtype, super_type):
        return self.class_node.is_subtype_of(subtype, super_type)

    def get_all_subtypes_of_type(self, type):
        type_class_node = self.class_node.find_class_node_of_type(type)
        return type_class_node.get_subtypes()

    def get_all_reachable_types_of_type(self, type):
        if not isinstance(type, str):
            return []
        if "[" in type:
            type = type[9:-1]

        reachable_types = set()
        unexpanded_types = set()
        unexpanded_types.add(type)


        first_time = True # flag introduced to not add the starting type by default
        while unexpanded_types:
            # pop from the unexpanded stack and add the type
            unexpanded_type = unexpanded_types.pop()
            if not first_time:
                reachable_types.add(unexpanded_type)
            else:
                first_time = False
            # get all fields of the type
            rule = self.get_rule_for_type(unexpanded_type)
            fields = rule.attribute("get_all_fields")()
            # extract all field types and all field subtypes (they are all possibly new types to add)
            possible_new_types = set()
            for field in fields:
                field_type = field.field_type
                if not isinstance(field_type, str):
                    continue
                if "[" in field_type:
                    field_type = field_type[9:-1]
                for possible_new_type in self.get_all_subtypes_of_type(field_type):
                    possible_new_types.add(possible_new_type)
            # iterate all possible types to add,
            # add them they are new, this expands the type
            for possible_new_type in possible_new_types:
                if not isinstance(possible_new_type, str):
                    continue
                if "[" in possible_new_type:
                    possible_new_type = possible_new_type[9:-1]
                if possible_new_type in reachable_types or possible_new_type in unexpanded_types:
                    continue
                unexpanded_types.add(possible_new_type)

        return reachable_types

    def get_rule_for_type(self, type):
        for rule in self.grammar_rules.children.values():
            if rule.head_type == type:
                return rule
        if type == "Node":
            return None
        raise RuntimeError(f"No Rule found for Type \"{type}\"")


class RuleNode(InnerNode):
    def __init__(self, head_type, head_super_type):
        super().__init__("Rule")
        self.head_type = head_type
        self.head_super_type = head_super_type
        self.fields = ListNode("Field")
        self.add_child_no_name(self.fields)
        self.data["head_type"] = self.head_type
        self.data["head_super_type"] = self.head_super_type

    def __repr__(self):
        out = f"RULE: {self.head_type}: {self.head_super_type} ::="
        for field in self.fields.get_children():
            out += f" <{field.field_name}:{field.field_type}>"
        return out

class FieldNode(TreeNode):
    def __init__(self, field_type, field_name):
        super().__init__("Field")
        self.field_type = field_type
        self.field_name = field_name
        self.data["field_type"] = self.field_type
        self.data["field_name"] = self.field_name

    def __repr__(self):
        return f"FIELD: Type[{self.field_type}]: Name[{self.field_name}]"


"""
Attribute Implementation
"""


class AspectList(ListNode):
    def __init__(self):
        super().__init__(f"Aspect")

    def __get_ordered_matches_in_list(self, tree_node, other_tree_nodes):
        name_def_nodes = []
        type_def_nodes = []
        for tn in other_tree_nodes:
            if isinstance(tn, AttrDefinitionNamePartNode):
                name_def_nodes.append(tn)
            if isinstance(tn, AttrDefinitionTypePartNode):
                type_def_nodes.append(tn)

        matches = []
        # first: name defs
        for name_def_node in name_def_nodes:
            if tree_node.name == name_def_node.def_name:
                matches.append(name_def_node)
                break
        # then: type defs
        current_type = tree_node.type
        while current_type:
            for type_def_node in type_def_nodes:
                if current_type == type_def_node.def_type:
                    matches.append(type_def_node)
                    break
            current_type = self.get_all_parent().grammar_definition.get_immediate_super_type(current_type)
        return matches

    # the path stays at the same length throughout
    def __try_fit_full_path_into_tree(self, path: 'List[TreeNode]', input_tree_root: 'InnerNode'):
        # the path is expected to be at least length one
        if not path:
            raise Exception("Path is expected to be at least one node")

        # first node must have at least one match, if not the fitting failed
        matches = self.__get_ordered_matches_in_list(path[0], input_tree_root.sub_defs.get_children())
        if not matches:
            return None

        # if there is only one node left, and there are matches, fitting is possible
        # but the best fitting ends the deepest in the tree, so we check if there are deeper matches for the same node
        elif len(path) == 1:
            best_match = matches[0]
            while True:
                maybe_better_matches = self.__get_ordered_matches_in_list(path[0], best_match.sub_defs.get_children())
                if maybe_better_matches:
                    best_match = maybe_better_matches[0]
                else:
                    break
            return best_match

        # if there is at least one match, and the path is still long
        # we shorten the path to account for the match
        # we also further shorten the path to skip unmatchable nodes if we encounter one
        while True:
            # the path is shortened since we either matched a node, or want to skip one
            path = path[1:]
            # the last node can not be skipped, it must be matched
            if not path:
                return None
            # since matches are ordered by relevance, we evaluate them greedily until fitting is successful
            for match in matches:
                child_fit = self.__try_fit_full_path_into_tree(path, match)
                # as soon as a fit is found for the shortened path we are done
                if child_fit:
                    return child_fit

    def __fit_path_ideally_into_tree(self, input_path: 'List[TreeNode]', input_tree_root: 'InnerNode'):
        path = input_path[:]
        while path:
            # try the full path, shorten it if it does not fit
            final_matched_tree_node = self.__try_fit_full_path_into_tree(path, input_tree_root)
            if final_matched_tree_node:
                return final_matched_tree_node, path[0]
            path.pop(0)
        return None


    def get_attribute(self, attribute_name: str, node: TreeNode):
        # find aspect that defines the attribute, exactly one must be found
        defining_aspect = None
        for child in self.children.values():
            defs = [def_root.attr_name for def_root in child.definition_root_list.get_children()]
            if attribute_name in defs:
                if defining_aspect is None:
                    defining_aspect = child
                else:
                    raise RuntimeError(f"attribute {attribute_name} was defined in more that one aspect")
        if defining_aspect is None:
            raise RuntimeError(f"attribute \"{attribute_name}\" is not defined in any aspect")

        # get definition tree of the attribute
        node_path = node.get_path_to_root()
        attr_def_tree = defining_aspect.get_attribute_definition_root(attribute_name)
        res = self.__fit_path_ideally_into_tree(node_path, attr_def_tree)
        if not res:
            raise RuntimeError(f"attribute {attribute_name} could not be located")
        fitted_path_leaf_node, defining_node = res
        # find attribute value in fitted path leaf node
        func = None
        for value_node in fitted_path_leaf_node.sub_defs.children.values():
            if isinstance(value_node, AttrDefinitionValuePartNode) and value_node.function.__name__ == attribute_name:
                func = value_node.function
        if func is None:
            raise RuntimeError(f"attribute {attribute_name} could not be located")

        def decorated_function(*args, **kwargs):
            return func(defining_node, *args, **kwargs)
        return decorated_function

class AspectNode(InnerNode):
    def __init__(self, aspect_name):
        super().__init__("Aspect")
        self.data["aspect_name"] = aspect_name
        self.aspect_name = self.data["aspect_name"]
        self.definition_root_list = AttrDefinitionRootPartListNode()
        self.add_child_no_name(self.definition_root_list)

    def get_attribute_definition_root(self, attribute_name):
        # search for definition
        for definition_root in self.definition_root_list.get_children():
            if definition_root.attr_name == attribute_name:
                return definition_root
        return None

class AttrDefinitionRootPartListNode(ListNode):
    def __init__(self):
        super().__init__(f"AttrDefinitionRootPart")

class AttrDefinitionPartInnerNode(InnerNode):
    def __init__(self, type):
        super().__init__(type)
        self.add_child("sub_defs", AttrDefinitionPartListNode())
        self.sub_defs = self.children["sub_defs"]

class AttrDefinitionPartListNode(ListNode):
    def __init__(self):
        super().__init__(f"AttrDefinitionPart")


class AttrDefinitionRootPartNode(AttrDefinitionPartInnerNode):
    def __init__(self, atr_name):
        super().__init__(f"AttrDefinitionRootPart")
        self.attr_name = atr_name
        self.data["attr_name"] = self.attr_name

    def __repr__(self):
        return f"RootDef<attr_name: {self.attr_name}>"
    def equals(self, other_part):
        if not other_part.type == self.type:
            return False
        return other_part.attr_name == self.attr_name

class AttrDefinitionTypePartNode(AttrDefinitionPartInnerNode):
    def __init__(self, def_type):
        super().__init__(f"AttrDefinitionTypePart")
        self.def_type = def_type
        self.data["def_type"] = self.def_type

    def __repr__(self):
        return f"TypeDef<def_type: {self.def_type}>"
    def equals(self, other_part):
        if not other_part.type == self.type:
            return False
        return other_part.def_type == self.def_type

class AttrDefinitionNamePartNode(AttrDefinitionPartInnerNode):
    def __init__(self, def_name):
        super().__init__(f"AttrDefinitionNamePart")
        self.def_name = def_name
        self.data["def_name"] = self.def_name

    def __repr__(self):
        return f"NameDef<def_name: {self.def_name}>"
    def equals(self, other_part):
        if not other_part.type == self.type:
            return False
        return other_part.def_name == self.def_name

class AttrDefinitionValuePartNode(InnerNode):
    def __init__(self, function):
        super().__init__(f"AttrDefinitionValuePart")
        self.function = function
        self.data["function"] = self.function

    def __repr__(self):
        return f"ValueDef<def_name: {self.function.__name__}>"
    def equals(self, other_part):
        if not other_part.type == self.type:
            return False
        return other_part.function.__name__ == self.function.__name__

