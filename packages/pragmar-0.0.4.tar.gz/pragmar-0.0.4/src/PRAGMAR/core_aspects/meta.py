"""
This is the starting point of this whole application.
Here we define the "AllParentNode" that will contain all further nodes as descendants.
We also define the Grammar-Structure of the meta nodes,
and add attributes that will be used to check if any grammar is valid.
"""

import types

from src.PRAGMAR.tree import AllParentNode, RuleNode, GrammarNode, TreeNode, ListNode

ap = AllParentNode()

# create Grammar
grammar_def = ap.create_grammar("Node") # select node as base class to allow meta grammar definitions

# all nodes are nodes, all inner nodes are nodes
grammar_def.Head("Node", head_super_type=None)

# Main Structure
# AllParent :: Grammar Attributes Trees
grammar_def.Head("AllParent").Field(field_type="Grammar").Field(field_type="ListNode[Aspect]", field_name="Attributes").Field(field_type="ListNode[ASTNode]", field_name="ASTs")

# Grammar and Class Hierarchy
# Grammar ::= ClassNode Rule*
grammar_def.Head("Grammar").Field(field_type="ClassNode").Field(field_type="ListNode[Rule]")
# Rule ::= <head_type:str> <head_super_type:str> Field*
(grammar_def.Head("Rule")
 .Field(field_type=str, field_name="head_type")
 .Field(field_type=str, field_name="head_super_type")
 .Field(field_type="ListNode[Field]"))
# Field: := < field_name: str > < field_type:str >
grammar_def.Head("Field").Field(field_type=str, field_name="field_name").Field(field_type=str, field_name="field_type")
# ClassNode ::= <class:str> <sub_classes: ClassNode*>
grammar_def.Head("ClassNode").Field(field_type=str, field_name="class_type").Field(field_type="ListNode[ClassNode]", field_name="sub_classes")

# Aspects and Attributes
# Aspect: := AttrDefinitionPart*
grammar_def.Head("Aspect").Field(field_type="ListNode[AttrDefinitionRootPart]").Field(field_type=str, field_name="aspect_name")
# AttrDefinitionPart;
grammar_def.Head("AttrDefinitionPart")
# AttrDefinitionPartInner: AttrDefinitionPart ::= <sub_defs:AttrDefinitionPart*>;
grammar_def.Head("AttrDefinitionPartInner", head_super_type="AttrDefinitionPart").Field(field_type="ListNode[AttrDefinitionPart]", field_name="sub_defs")
# AttrDefinitionRootPart: AttrDefinitionPartInner ::= <attr_name:str>
grammar_def.Head("AttrDefinitionRootPart", head_super_type="AttrDefinitionPartInner").Field(field_type=str, field_name="attr_name")
# AttrDefinitionTypePart: AttrDefinitionPartInner ::= <def_type:str>
grammar_def.Head("AttrDefinitionTypePart", head_super_type="AttrDefinitionPartInner").Field(field_type=str, field_name="def_type")
# AttrDefinitionNamePart: AttrDefinitionPartInner ::= <def_name:str>
grammar_def.Head("AttrDefinitionNamePart", head_super_type="AttrDefinitionPartInner").Field(field_type=str, field_name="def_name")
# AttrDefinitionValuePart: AttrDefinitionPart ::= <function:function>
(grammar_def.Head("AttrDefinitionValuePart", head_super_type="AttrDefinitionPart")
 .Field(field_type=types.FunctionType, field_name="function"))

# ASTs
grammar_def.Head("ASTNode")


meta_checker = ap.create_aspect("meta_checker")

@meta_checker.define_on("AllParent").Type("Node").Value()
def get_super_type(node, type):
    return node.get_child("Grammar").get_immediate_super_type(type)

@meta_checker.define_on("AllParent").Type("Node").Value()
def get_rule_for_type(node, type):
    return node.get_child("Grammar").get_rule_for_type(type)

@meta_checker.define_on("AllParent").Type("Node").Value()
def is_subtype_of(node, type, potential_super_type):
    return node.get_child("Grammar").is_subtype_of(type, potential_super_type)

@meta_checker.define_on("AllParent").Type("Node").Value()
def get_all_subtypes_of_type(node, type):
    return node.get_child("Grammar").get_all_subtypes_of_type(type)

@meta_checker.define_on("AllParent").Type("Node").Value()
def get_all_reachable_types_of_type(node, type):
    return node.get_child("Grammar").get_all_reachable_types_of_type(type)


@meta_checker.define_on("Rule").Value()
def get_all_fields(node: RuleNode):
    all_fields = []
    # get fields of super type
    all_super_fields = []
    if node.head_super_type:
        super_rule = node.attribute("get_rule_for_type")(node.head_super_type)
        if super_rule and not super_rule.head_type == "Node":
            all_super_fields = super_rule.attribute("get_all_fields")()
    all_fields.extend(all_super_fields)
    all_fields.extend(node.get_child("ListNode[Field]").children.values())
    return all_fields

@meta_checker.define_on("AllParent").Value()
def check_grammar(node):
    grammar_check_res = node.get_child("Grammar").attribute("check_grammar")(node)
    if not grammar_check_res.fits:
        raise Exception(f"Grammar is not valid!\n{grammar_check_res.message}")
    return True

@meta_checker.define_on("Grammar").Value()
def check_grammar(node: GrammarNode, tree_to_check: TreeNode):
    # grammar is not empty
    if not node.children.values():
        raise Exception("Grammar is empty!")

    # fist rule is main rule
    main_rule = node.get_child("ListNode[Rule]").children[0]
    return tree_to_check.attribute("fits_grammar_rule")(main_rule)

@meta_checker.define_on("Node").Value()
def fits_grammar_rule(node: TreeNode, rule: RuleNode):
    # check head: check type
    type_fits = node.type == rule.head_type
    if not type_fits and "ListNode[" not in node.type:
        node_type_rule = node.attribute("get_rule_for_type")(node.type)
        if node.attribute("is_subtype_of")(node_type_rule.head_type, rule.head_type):
            rule = node_type_rule
            type_fits = True

    # check head: check super type
    super_type_fits = node.attribute("get_super_type")(node.type) == rule.head_super_type
    head_fits = type_fits and super_type_fits

    # if it does not fit, check if the nodes type rule is a subtype rule of the input rule
    if not head_fits:
        return GrammarFitsMessage(False, f"Head does not fit for: {node} and {rule}")

    # check body
    fields_to_check = rule.attribute("get_all_fields")()[:]
    children_to_fit = list(node.get_children())[:]

    # try fit all basic fields on the node itself
    missing_basic_fields = []
    checked_basic_fields = []
    for field_to_check in fields_to_check:
        if not isinstance(field_to_check.field_type, str):
            if node.data and field_to_check.field_name in node.data.keys():
                checked_basic_fields.append(field_to_check)
            else:
                missing_basic_fields.append(field_to_check)
    if missing_basic_fields:
        raise RuntimeError(f"Node {node} has missing basic fields: {missing_basic_fields}")
    for checked_basic_field in checked_basic_fields:
        fields_to_check.remove(checked_basic_field)

    # check if there is data present on the nodes that is not allowed
    illegal_basic_fields = []
    for key in node.data.keys():
        if key not in [field.field_name for field in checked_basic_fields]:
            illegal_basic_fields.append(key)
    if illegal_basic_fields:
        raise RuntimeError(f"Node {node} has illegal basic fields: {illegal_basic_fields}")

    # try to find a field for every child
    fit_children = []
    checked_fields = []
    for child_to_fit in children_to_fit:
        for field_to_check in fields_to_check:
            # first check name
            if child_to_fit.name != field_to_check.field_name:
                continue

            if not isinstance(field_to_check.field_type, str):
                raise RuntimeError("non string type detected, these should have been eliminated in the previous section")
            elif "ListNode[" in field_to_check.field_type:
                list_node_type = field_to_check.field_type[9:-1]

                # check list node head
                if not isinstance(child_to_fit, ListNode) or list_node_type != child_to_fit.list_type:
                    continue

                field_type_rule = node.attribute("get_rule_for_type")(list_node_type)
                for list_child in child_to_fit.get_children():
                    list_child_fits = list_child.attribute("fits_grammar_rule")(field_type_rule)
                    if not list_child_fits.fits:
                        return GrammarFitsMessage(False, f"Child {list_child} of {field_to_check.field_type} does not comply with rule: {field_type_rule}" + "\n" + list_child_fits.message)
                fit_children.append(child_to_fit)
                checked_fields.append(field_to_check)
                break
            else:
                field_type_rule = node.attribute("get_rule_for_type")(field_to_check.field_type)
                field_fits = child_to_fit.attribute("fits_grammar_rule")(field_type_rule)
                if field_fits.fits:
                    fit_children.append(child_to_fit)
                    checked_fields.append(field_to_check)
                    break
        else:
            return GrammarFitsMessage(False, f"Child: {child_to_fit} could not be matched to a field. Available fields are: {[f'<{f.field_type}:{f.field_name}' for f in fields_to_check]}")

    # remove all fit children and checked fields
    for fit_child in fit_children:
        children_to_fit.remove(fit_child)
    for checked_field in checked_fields:
        fields_to_check.remove(checked_field)

    if children_to_fit or fields_to_check:
        message = "Some nodes or fields were not fit:\n"
        if children_to_fit:
            message += f"   Node Graph Children that could not be fit: {children_to_fit}\n"
        if fields_to_check:
            message += f"   Grammar Rule Fields that could not be fit: {fields_to_check}\n"
        return GrammarFitsMessage(False, message)

    return GrammarFitsMessage(True, None)

class GrammarFitsMessage:
    def __init__(self, fits, message):
        self.fits = fits
        self.message = message