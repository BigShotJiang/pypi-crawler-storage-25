# import aspect load functions that add definitions
from src.core_aspects.gen import load
load()
from src.core_aspects.print import load
load()

# import all parent first time
from src.core_aspects.meta import ap
# provide all parent to be exported
ap = ap