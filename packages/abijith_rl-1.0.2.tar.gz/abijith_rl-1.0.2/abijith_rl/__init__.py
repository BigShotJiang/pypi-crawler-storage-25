from __future__ import annotations

from collections import defaultdict
from typing import Optional

import gymnasium as gym
import numpy as np
import pandas as pd

__all__ = [
    "montecarlo",
    "montecarlo_code",
    "td_prediction",
    "sarsa",
    "q_learning",
]

__version__ = "1.0.2"


def _epsilon_greedy_action(
    q_values: np.ndarray,
    epsilon: float,
    rng: np.random.Generator,
) -> int:
    if rng.random() < epsilon:
        return int(rng.integers(len(q_values)))
    return int(np.argmax(q_values))


def _q_table_to_frame(q_table: np.ndarray) -> pd.DataFrame:
    n_states, n_actions = q_table.shape
    rows = [
        {"state": s, "action": a, "value": float(q_table[s, a])}
        for s in range(n_states)
        for a in range(n_actions)
    ]
    return pd.DataFrame(rows)


def montecarlo_code(
    num_episodes: int = 100,
    epsilon: float = 0.5,
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """Run first-visit Monte Carlo control on Blackjack-v1."""
    if num_episodes <= 0:
        return pd.DataFrame(columns=["state", "action", "value"])

    env = gym.make("Blackjack-v1")
    rng = np.random.default_rng(seed)

    q_table = defaultdict(float)
    returns_sum = defaultdict(float)
    returns_count = defaultdict(int)

    def epsilon_greedy_action(state) -> int:
        if rng.random() < epsilon:
            return env.action_space.sample()
        q_hit = q_table[(state, 1)]
        q_stick = q_table[(state, 0)]
        if q_hit == q_stick:
            return env.action_space.sample()
        return 1 if q_hit > q_stick else 0

    state, _ = env.reset(seed=seed)
    if seed is not None:
        env.action_space.seed(seed)
    for episode in range(num_episodes):
        if episode > 0:
            state, _ = env.reset()

        episode_steps = []
        terminated = False
        truncated = False
        while not (terminated or truncated):
            action = epsilon_greedy_action(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            episode_steps.append((state, action, reward))
            state = next_state

        visited = set()
        g_return = 0.0
        for state_t, action_t, reward_t in reversed(episode_steps):
            g_return = reward_t + g_return
            if (state_t, action_t) in visited:
                continue
            visited.add((state_t, action_t))
            returns_sum[(state_t, action_t)] += g_return
            returns_count[(state_t, action_t)] += 1
            q_table[(state_t, action_t)] = (
                returns_sum[(state_t, action_t)] / returns_count[(state_t, action_t)]
            )

    env.close()
    rows = [
        {"state": state_key, "action": action_key, "value": float(value)}
        for (state_key, action_key), value in q_table.items()
    ]
    return pd.DataFrame(rows)


def td_prediction(
    num_episodes: int = 50,
    max_steps: int = 10,
    alpha: float = 0.85,
    gamma: float = 0.90,
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """Estimate state values on FrozenLake-v1 using TD(0)."""
    env = gym.make("FrozenLake-v1")
    if seed is not None:
        env.reset(seed=seed)
        env.action_space.seed(seed)

    v_table = np.zeros(env.observation_space.n, dtype=float)

    for _ in range(num_episodes):
        state, _ = env.reset()
        for _ in range(max_steps):
            action = env.action_space.sample()
            next_state, reward, terminated, truncated, _ = env.step(action)
            v_table[state] += alpha * (
                reward + gamma * v_table[next_state] - v_table[state]
            )
            if terminated or truncated:
                break
            state = next_state

    env.close()
    return pd.DataFrame(
        {"state": np.arange(len(v_table), dtype=int), "value": v_table}
    )


def sarsa(
    num_episodes: int = 500,
    max_steps: int = 50,
    alpha: float = 0.85,
    gamma: float = 0.90,
    epsilon: float = 0.8,
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """Train a SARSA agent on FrozenLake-v1."""
    env = gym.make("FrozenLake-v1")
    rng = np.random.default_rng(seed)
    if seed is not None:
        env.reset(seed=seed)
        env.action_space.seed(seed)

    n_states = env.observation_space.n
    n_actions = env.action_space.n
    q_table = np.zeros((n_states, n_actions), dtype=float)

    for _ in range(num_episodes):
        state, _ = env.reset()
        action = _epsilon_greedy_action(q_table[state], epsilon, rng)
        for _ in range(max_steps):
            next_state, reward, terminated, truncated, _ = env.step(action)
            next_action = _epsilon_greedy_action(q_table[next_state], epsilon, rng)
            td_target = reward + gamma * q_table[next_state, next_action]
            q_table[state, action] += alpha * (td_target - q_table[state, action])
            if terminated or truncated:
                break
            state, action = next_state, next_action

    env.close()
    return _q_table_to_frame(q_table)


def q_learning(
    num_episodes: int = 200,
    max_steps: int = 100,
    alpha: float = 0.85,
    gamma: float = 0.90,
    epsilon: float = 0.8,
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """Train a Q-learning agent on FrozenLake-v1."""
    env = gym.make("FrozenLake-v1")
    rng = np.random.default_rng(seed)
    if seed is not None:
        env.reset(seed=seed)
        env.action_space.seed(seed)

    n_states = env.observation_space.n
    n_actions = env.action_space.n
    q_table = np.zeros((n_states, n_actions), dtype=float)

    for _ in range(num_episodes):
        state, _ = env.reset()
        for _ in range(max_steps):
            action = _epsilon_greedy_action(q_table[state], epsilon, rng)
            next_state, reward, terminated, truncated, _ = env.step(action)
            td_target = reward + gamma * np.max(q_table[next_state])
            q_table[state, action] += alpha * (td_target - q_table[state, action])
            if terminated or truncated:
                break
            state = next_state

    env.close()
    return _q_table_to_frame(q_table)


def montecarlo():
    """Prints and returns the source code for a Monte Carlo control demo."""
    code_to_print = """
# FrozenLake Environment

import gymnasium as gym
import time

# Create Environment
env = gym.make(
    "FrozenLake-v1",
    render_mode="human"
)

# Reset and Render
env.reset()
env.render()

time.sleep(2)

# Print State Space
print(env.observation_space)

# Print Action Space
print(env.action_space)

# Print Transition Probabilities
print(env.unwrapped.P[0][2])

# Deterministic Action
print("Deterministic Action:")

next_state, reward, done, trans_prob, info = env.step(2)

print(
    "Next state is : {0}, Reward is {1}, Is a Terminal state: {2}".format(
        next_state,
        reward,
        done
    )
)

env.render()

time.sleep(2)

# Reset Environment
env.reset()

# Random Action
print("Random Action:")

rnd_action = env.action_space.sample()

next_state, reward, done, trans_prob, info = env.step(rnd_action)

print(
    "Next state is : {0}, Reward is {1}, Is a Terminal state: {2}".format(
        next_state,
        reward,
        done
    )
)

env.render()

time.sleep(2)

# Random Episode
env.reset()

num_timesteps = 20

for t in range(num_timesteps):

    rnd_action = env.action_space.sample()

    next_state, reward, done, info, trans_prob = env.step(rnd_action)

    print(
        "Time:{0}\tNext:{1}\tReward:{2}\tTerminal?:{3}".format(
            t+1,
            next_state,
            reward,
            done
        )
    )

    env.render()

    time.sleep(1)

    if done:
        break

env.close()



# CartPole Environment

import gymnasium as gym

# Create Environment
env = gym.make(
    "CartPole-v1",
    render_mode="human"
)

# Reset and Render
env.reset()
env.render()

# Print Observation Space
print(env.observation_space)

# Print Action Space
print(env.action_space)

# Reset Environment
env.reset()

# Parameters
n_episodes = 50
n_timesteps = 50

# Random Policy
for i in range(n_episodes):

    Return = 0

    for t in range(n_timesteps):

        env.render()

        rnd_action = env.action_space.sample()

        next_state, reward, done, info, prob = env.step(rnd_action)

        Return = Return + reward

        if done:

            env.reset()

            break

    if i % 10 == 0:

        print(
            "Episode : {}, Return : {}".format(
                i+1,
                Return
            )
        )

env.close()


# Value Iteration

import gymnasium as gym
import numpy as np

# Value Iteration Function
def value_iteration(env):

    num_itns = 1000

    threshold = 1e-20

    gamma = 1.0

    value_table = np.zeros(
        env.observation_space.n
    )

    for i in range(num_itns):

        updated_val_tab = np.copy(value_table)

        for s in range(env.observation_space.n):

            Q_values = [

                sum([

                    prob * (

                        r + gamma * updated_val_tab[s_]

                    )

                    for prob, s_, r, _ in env.P[s][a]

                ])

                for a in range(env.action_space.n)

            ]

            value_table[s] = max(Q_values)

        if (

            np.sum(
                np.fabs(
                    updated_val_tab - value_table
                )
            ) <= threshold

        ):
            break

    return value_table

# Extract Policy
def extract_policy(value_table):

    gamma = 1.0

    policy = np.zeros(
        env.observation_space.n
    )

    for s in range(env.observation_space.n):

        Q_values = [

            sum([

                prob * (

                    r + gamma * value_table[s_]

                )

                for prob, s_, r, _ in env.P[s][a]

            ])

            for a in range(env.action_space.n)

        ]

        policy[s] = np.argmax(np.array(Q_values))

    return policy

# Main Program
env = gym.make(
    'FrozenLake-v1',
    render_mode='human'
)

env.reset()

env.render()

env = env.unwrapped

optimal_value_function = value_iteration(env)

optimal_policy = extract_policy(
    optimal_value_function
)

print(optimal_policy)
# Policy Iteration

import gymnasium as gym
import numpy as np

# Compute Value Function
def compute_value_function(policy):

    num_iterations = 1000

    threshold = 1e-20

    gamma = 1.0

    value_table = np.zeros(
        env.observation_space.n
    )

    for i in range(num_iterations):

        updated_value_table = np.copy(value_table)

        for s in range(env.observation_space.n):

            a = policy[s]

            value_table[s] = sum([

                prob * (

                    r + gamma * updated_value_table[s_]

                )

                for prob, s_, r, _ in env.P[s][a]

            ])

        if (

            np.sum(

                np.fabs(
                    updated_value_table - value_table
                )

            ) <= threshold

        ):
            break

    return value_table

# Extract Policy
def extract_policy(value_table):

    gamma = 1.0

    policy = np.zeros(
        env.observation_space.n
    )

    for s in range(env.observation_space.n):

        Q_values = [

            sum([

                prob * (

                    r + gamma * value_table[s_]

                )

                for prob, s_, r, _ in env.P[s][a]

            ])

            for a in range(env.action_space.n)

        ]

        policy[s] = np.argmax(np.array(Q_values))

    return policy

# Policy Iteration
def policy_iteration(env):

    num_iterations = 1000

    policy = np.zeros(
        env.observation_space.n
    )

    for i in range(num_iterations):

        value_function = compute_value_function(policy)

        new_policy = extract_policy(value_function)

        if np.all(policy == new_policy):

            break

        policy = new_policy

    return policy

# Main Program
env = gym.make(
    'FrozenLake-v1',
    render_mode='human'
)

env.reset()

env.render()

env = env.unwrapped

optimal_policy = policy_iteration(env)

print(optimal_policy)

# Run Game Using Optimal Policy
state = env.reset()

s = state[0]

done = False

tot_reward = 0

while not done:

    next_state, reward, done, _, _ = env.step(
        int(optimal_policy[s])
    )

    env.render()

    s = next_state

    tot_reward += reward

    if done:
        break

print("Return =", tot_reward)

# Every-Visit Monte Carlo Prediction

import pandas as pd

from collections import defaultdict

import gymnasium as gym

# Create Environment
env = gym.make(
    'Blackjack-v1',
    render_mode='human'
)

env.reset()

env.render()

# Policy
def policy(state):

    return 0 if state[0] > 19 else 1

state = env.reset()

state = state[0]

print(state)

print(policy(state))

# Number of Timesteps
num_timesteps = 100

# Generate Episode
def generate_episode(policy):

    episode = []

    state = env.reset()

    state = state[0]

    for t in range(num_timesteps):

        action = policy(state)

        next_state, reward, done, info, trans_prob = env.step(action)

        episode.append((state, action, reward))

        if done:
            break

        state = next_state

    return episode

print(generate_episode(policy))

# Monte Carlo Prediction
total_return = defaultdict(float)

N = defaultdict(int)

num_iterations = 10

for i in range(num_iterations):

    episode = generate_episode(policy)

    states, actions, rewards = zip(*episode)

    for t, state in enumerate(states):

        R = sum(rewards[t:])

        total_return[state] += R

        N[state] += 1

print(total_return[state])

print(N[state])

# DataFrames
total_return = pd.DataFrame(

    total_return.items(),

    columns=['state', 'total_return']

)

N = pd.DataFrame(

    N.items(),

    columns=['state', 'N']

)

df = pd.merge(total_return, N, on="state")

print(df.head(10))

df['value'] = df['total_return'] / df['N']

print(df.head(10))

print(df.shape)

print(
    df[df['state'] == (21,9,False)]['value'].values
)

print(
    df[df['state'] == (5,8,False)]['value'].values
)

env.close()


#Labsheet 7
# Implementation of On-Policy Monte Carlo Control

import gym
import pandas as pd
import random

from collections import defaultdict

# Create Environment
env = gym.make('Blackjack-v1', render_mode='human')

# Initialize Q-table
Q = defaultdict(float)

total_return = defaultdict(float)

N = defaultdict(int)

# Epsilon-Greedy Policy
def epsilon_greedy_policy(state, Q):

    epsilon = 0.5

    if random.uniform(0,1) < epsilon:

        return env.action_space.sample()

    else:

        return max(

            list(range(env.action_space.n)),

            key=lambda x: Q[(state,x)]

        )

# Number of timesteps
num_timesteps = 100

# Generate Episode
def generate_episode(Q):

    episode = []

    state = env.reset()
    state = state[0]

    for t in range(num_timesteps):

        action = epsilon_greedy_policy(state, Q)

        next_state, reward, done, info, trans_prob = env.step(action)

        episode.append((state, action, reward))

        if done:
            break

        state = next_state

    return episode

# Training
num_iterations = 100

for i in range(num_iterations):

    episode = generate_episode(Q)

    all_state_action_pairs = [

        (s,a)

        for (s,a,r) in episode
    ]

    rewards = [

        r

        for (s,a,r) in episode
    ]

    for t, (state, action, _) in enumerate(episode):

        if not (state, action) in all_state_action_pairs[0:t]:

            R = sum(rewards[t:])

            total_return[(state,action)] += R

            N[(state,action)] += 1

            Q[(state,action)] = (

                total_return[(state,action)]

                /

                N[(state,action)]

            )

# Display Q-table
df = pd.DataFrame(

    Q.items(),

    columns=['state_action pair', 'value']

)

print(df.head(11))

print(df[124:126])

env.close()


#Labsheet 8
# TD Prediction

import gymnasium as gym
import pandas as pd

# Create Environment
env = gym.make("FrozenLake-v1", render_mode="human")

env.reset()
env.render()

# Random Policy
def random_policy():

    return env.action_space.sample()

# Initialize V-table
V = {}

for s in range(env.observation_space.n):

    V[s] = 0.0

# Hyperparameters
alpha = 0.85
gamma = 0.90

num_eps = 50
num_steps = 10

# Training Loop
for i in range(num_eps):

    s = env.reset()
    s = s[0]

    for t in range(num_steps):

        a = random_policy()

        s_, r, done, _, _ = env.step(a)

        # TD Update
        V[s] += alpha * (

            r + gamma * V[s_] - V[s]

        )

        s = s_

        if done:
            break

# Display Values
df = pd.DataFrame(

    list(V.items()),

    columns=['state', 'value']

)

print(df)

#LABSHEET 9
# SARSA Algorithm

import gymnasium as gym
import random
import pandas as pd

# Create Environment
env = gym.make("FrozenLake-v1", render_mode="human")

env.reset()
env.render()

# Initialize Q-table
Q = {}

for s in range(env.observation_space.n):

    for a in range(env.action_space.n):

        Q[(s,a)] = 0.0

print("Initial Q Table:", Q)

# Epsilon-Greedy Policy
def epsilon_greedy(state, epsilon):

    if random.uniform(0,1) < epsilon:

        return env.action_space.sample()

    else:

        return max(

            list(range(env.action_space.n)),

            key=lambda x: Q[(state,x)]

        )

# Hyperparameters
alpha = 0.85
gamma = 0.90
epsilon = 0.8

num_eps = 500
num_steps = 50

# Training Loop
for i in range(num_eps):

    s = env.reset()
    s = s[0]

    a = epsilon_greedy(s, epsilon)

    for t in range(num_steps):

        s_, r, done, _, _ = env.step(a)

        a_ = epsilon_greedy(s_, epsilon)

        predict = Q[(s,a)]

        target = r + gamma * Q[(s_,a_)]

        Q[(s,a)] = Q[(s,a)] + alpha * (

            target - predict

        )

        s = s_
        a = a_

        if done:
            break

# Display Q-table
df = pd.DataFrame(

    list(Q.items()),

    columns=['state_action', 'value']

)

print(df)


$LABSHEET 10
# Q-Learning Algorithm

import gymnasium as gym
import numpy as np
import random
import pandas as pd

# Create Environment
env = gym.make("FrozenLake-v1", render_mode="human")

# Initialize Q-table
Q = {}

for s in range(env.observation_space.n):

    for a in range(env.action_space.n):

        Q[(s,a)] = 0.0

# Epsilon-Greedy Policy
def epsilon_greedy(state, epsilon):

    if random.uniform(0,1) < epsilon:

        return env.action_space.sample()

    else:

        return max(

            list(range(env.action_space.n)),

            key=lambda x: Q[(state,x)]

        )

# Hyperparameters
alpha = 0.85
gamma = 0.90
epsilon = 0.8

num_eps = 50
num_steps = 100

# Training Loop
for i in range(num_eps):

    s = env.reset()
    s = s[0]

    for t in range(num_steps):

        a = epsilon_greedy(s, epsilon)

        s_, r, done, _, _ = env.step(a)

        a_ = np.argmax(

            [Q[(s_,a)] for a in range(env.action_space.n)]

        )

        Q[(s,a)] += alpha * (

            r + gamma * Q[(s_,a_)] - Q[(s,a)]

        )

        s = s_

        if done:
            break

# Display Q-table
df = pd.DataFrame(

    list(Q.items()),

    columns=['state_action', 'value']

)

print(df)


#LABSHEET 11
# Epsilon-Greedy Multi-Armed Bandit

import gym
import gym_bandits
import numpy as np

# Create Environment
env = gym.make("BanditTwoArmedHighLowFixed-v0")

print(env.action_space.n)
print(env.p_dist)

# Initialize Arrays
count = np.zeros(2)

sum_rewards = np.zeros(2)

Q = np.zeros(2)

num_rounds = 100

# Epsilon-Greedy Policy
def epsilon_greedy(epsilon):

    if np.random.uniform(0,1) < epsilon:

        return env.action_space.sample()

    else:

        return np.argmax(Q)

# Training
env.reset()

for i in range(num_rounds):

    arm = epsilon_greedy(epsilon=0.5)

    next_state, reward, done, info = env.step(arm)

    count[arm] += 1

    sum_rewards[arm] += reward

    Q[arm] = sum_rewards[arm] / count[arm]

# Display Results
print(Q)

print(

    'The optimal arm is arm {}'.format(

        np.argmax(Q)+1

    )

)


LABSHEET 12

# Softmax Exploration

import gym
import gym_bandits
import numpy as np

# Create Environment
env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize Arrays
count = np.zeros(2)

sum_rewards = np.zeros(2)

Q = np.zeros(2)

num_rounds = 100

# Softmax Policy
def softmax(T):

    denom = sum(

        [np.exp(i/T) for i in Q]

    )

    probs = [

        np.exp(i/T)/denom

        for i in Q
    ]

    arm = np.random.choice(

        env.action_space.n,

        p=probs

    )

    return arm

# Training
env.reset()

T = 50

for i in range(num_rounds):

    arm = softmax(T)

    next_state, reward, done, info = env.step(arm)

    count[arm] += 1

    sum_rewards[arm] += reward

    Q[arm] = sum_rewards[arm] / count[arm]

    T = T * 0.99

# Display Results
print(Q)

print(

    'The optimal arm is arm {}'.format(

        np.argmax(Q)+1

    )

)


#LABSHEET 13
# Upper Confidence Bound (UCB)

import gym
import gym_bandits
import numpy as np

# Create Environment
env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize Arrays
count = np.zeros(2)

sum_rewards = np.zeros(2)

Q = np.zeros(2)

num_rounds = 100

# UCB Policy
def UCB(i):

    ucb = np.zeros(2)

    if i < 2:

        return i

    else:

        for arm in range(2):

            ucb[arm] = (

                Q[arm]

                +

                np.sqrt(

                    (2*np.log(sum(count)))

                    /

                    count[arm]

                )

            )

    return np.argmax(ucb)

# Training
env.reset()

for i in range(num_rounds):

    arm = UCB(i)

    next_state, reward, done, info = env.step(arm)

    count[arm] += 1

    sum_rewards[arm] += reward

    Q[arm] = sum_rewards[arm] / count[arm]

# Display Results
print(Q)

print(

    'The optimal arm is arm {}'.format(

        np.argmax(Q)+1

    )

)


#LABSHEET 14
# Thompson Sampling

import gym
import gym_bandits
import numpy as np

# Create Environment
env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize Arrays
count = np.zeros(2)

sum_rewards = np.zeros(2)

Q = np.zeros(2)

alpha = np.ones(2)

beta = np.ones(2)

num_rounds = 100

# Thompson Sampling Policy
def thompson_sampling(alpha, beta):

    samples = [

        np.random.beta(

            alpha[i]+1,

            beta[i]+1

        )

        for i in range(2)
    ]

    return np.argmax(samples)

# Training
env.reset()

for i in range(num_rounds):

    arm = thompson_sampling(alpha, beta)

    next_state, reward, done, info = env.step(arm)

    count[arm] += 1

    sum_rewards[arm] += reward

    Q[arm] = sum_rewards[arm] / count[arm]

    if reward == 1:

        alpha[arm] += 1

    else:

        beta[arm] += 1

# Display Results
print(Q)

print(

    'The optimal arm is arm {}'.format(

        np.argmax(Q)+1

    )

)


LABSHEET 15
# Banner Advertisement Selection

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use('ggplot')

# Create Dataset
df = pd.DataFrame()

for i in range(5):

    df['Banner_type_'+str(i)] = np.random.randint(0,2,100000)

# Initialize Variables
num_iterations = 100000

num_banner = 5

count = np.zeros(num_banner)

sum_rewards = np.zeros(num_banner)

Q = np.zeros(num_banner)

banner_selected = []

# Epsilon-Greedy Policy
def epsilon_greedy_policy(epsilon):

    if np.random.uniform(0,1) < epsilon:

        return np.random.choice(num_banner)

    else:

        return np.argmax(Q)

# Training Loop
for i in range(num_iterations):

    banner = epsilon_greedy_policy(0.5)

    reward = df.values[i, banner]

    count[banner] += 1

    sum_rewards[banner] += reward

    Q[banner] = sum_rewards[banner] / count[banner]

    banner_selected.append(banner)

# Display Best Banner
print(

    'The best banner is banner {}'.format(

        np.argmax(Q)+1

    )

)

# Visualization
ax = sns.countplot(x=banner_selected)

ax.set(

    xlabel='Banner',

    ylabel='Count'

)

plt.show()
    """
    print(code_to_print)
    return code_to_print