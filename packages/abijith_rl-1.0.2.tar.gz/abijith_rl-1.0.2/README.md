# Abijith RL

Small reinforcement learning demos built on gymnasium.

## Install

```bash
pip install abijith-rl
```

## Usage

```python
import abijith_rl as rl

mc_df = rl.montecarlo_code(num_episodes=200)
print(mc_df.head())

# Prints the full demo code string
rl.montecarlo()

td_df = rl.td_prediction(num_episodes=50)
print(td_df.head())

sarsa_df = rl.sarsa(num_episodes=200)
print(sarsa_df.head())

q_df = rl.q_learning(num_episodes=200)
print(q_df.head())
```
