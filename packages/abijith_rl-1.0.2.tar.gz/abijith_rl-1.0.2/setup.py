from setuptools import setup, find_packages

setup(
    name="abijith-rl",
    version="1.0.2",
    packages=find_packages(),
    install_requires=[
        "gymnasium",
        "numpy",
        "pandas",
    ],
    author="G Abijith",
    description="Reinforcement learning demos and utilities",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)
