# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]
- No unreleased changes so far

## [0.10.3] - 2026-04-24
### Changed
- Updated dependencies to latest versions (carconnectivity, connectors and plugins)
- Updated GitHub Actions to latest versions

## [0.10.2] - 2026-03-26
### Changed
- Updated connector dependencies to latest versions to include latest fixes and improvements into docker images

## [0.10.1] - 2026-03-15
### Fixed
- Fixes a problem where the plugin would not catch an error from a missing TLS file, resulting in a wrong error message in carconnectivity

## [0.10] - 2026-02-06
### Added
- Support for MQTT v5 properties in published messages, including content type and content encoding for JSON payloads
- Messages that exceed the maximum message given by the server are now logged as errors and not published to the broker, to avoid issues with oversized messages
- If the server asks for a lower keepalive than the one configured in the plugin, this is now logged as an error and the client disconnects to avoid issues with the connection being closed by the broker due to keepalive timeouts

## [0.9.2] - 2026-01-23
### Changed
- Compatibility for Carconnectivity 11.6

## [0.9.1] - 2026-01-11
### Changed
- Compatibility for Carconnectivity 11.5

## [0.9] - 2026-01-04
### Added
- Support for initializing attributes on startup form static entries in the configuration

### Fixed
- Fixes MQTT topic filter regex

Note: This plugin is required for compatibility with CarConnectivity version 0.11 and higher.

## [0.8.1] - 2025-11-25
### Fixed
- MQTT Docker image now contains latest volkswagen connector that fixes the login

## [0.8] - 2025-11-09
### Fixed
- MQTT Docker image now contains latest skoda connector that fixes the login

## [0.7.4] - 2025-11-02
### Changed
- Updated some dependencies

## [0.7.3] - 2025-04-19
### Fixed
- Problems with connectors after changing to PyJWT

### Changed
- remove old force update mechanism in favour of new update command #102

## [0.7.2] - 2025-04-19
### Fixed
- Conflicting dependencies with carconnectivity connectors

## [0.7.1] - 2025-04-18
### Fixed
- Fixed ignore_for config option

## [0.7] - 2025-04-17
### Added
- Example for autostart with systemd

### Fixed
- Docker is now consistently using ubuntu 24.04

### Changed
- Values are now rounded to the expected precision. This is in particular useful with locales that convert values.
- Bump carconnectivity dependency to 0.7

## [0.6] - 2025-04-02
### Changed
- Bump carconnectivity dependency to 0.6
- Allowing empty broker username and password when login is not required

## [0.5] - 2025-03-20
### Changed
- Bump carconnectivity dependency to 0.5

## [0.4.2] - 2025-03-04
### Fixed
- Fixed publishing to broken topic on disconnect
- Fixed locale settings on docker container

## [0.4.1] - 2025-03-02
### Changed
- Docker container now comes with all officially maintained plugins and connectors pre-installed

## [0.4] - 2025-03-02
### Added
- Improved documentation
- Improved access to connection state
- Improved access to health state
- Access to a full json topic with all attributes (beta)
- Added callback support for third party plugins to send and receive MQTT messages
- Added writeable attributes also in readable attributes list

## [0.3.1] - 2025-02-20
### Fixed
- Fixes bug due to template ambiguity

### Added
- Plugin UI root

## [0.3] - 2025-02-19
### Added
- Added support for images
- Added support for webui plugin

## [0.2] - 2025-02-02
### Changed
- Updated version of bundled connectors

## [0.1] - 2025-01-25
Initial release, let's go and give this to the public to try out...

[unreleased]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/compare/v0.10.3...HEAD
[0.10.3]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/compare/v0.10.2...v0.10.3
[0.10.2]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/compare/v0.10.1...v0.10.2
[0.10.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.10.1
[0.10]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.10
[0.9.2]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.9.2
[0.9.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.9.1
[0.9]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.9
[0.8.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.8.1
[0.8]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.8
[0.7.4]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.7.4
[0.7.3]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.7.3
[0.7.2]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.7.2
[0.7.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.7.1
[0.7]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.7
[0.6]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.6
[0.5]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.5
[0.4.2]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.4.2
[0.4.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.4.1
[0.4]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.4
[0.3.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.3.1
[0.3]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.3
[0.2]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.2
[0.1]: https://github.com/tillsteinbach/CarConnectivity-plugin-mqtt/releases/tag/v0.1
