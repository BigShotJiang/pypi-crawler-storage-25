from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.mark.asyncio
async def test_async_browser_backend_name():
    mock_backend = AsyncMock()
    mock_backend.name = "httpx"

    with patch("crawlix.async_api._create_backend", return_value=mock_backend):
        from crawlix.async_api import AsyncBrowser
        async with AsyncBrowser(backend="httpx") as b:
            assert b.backend_name == "httpx"


@pytest.mark.asyncio
async def test_async_browser_open_returns_page():
    mock_backend = AsyncMock()
    mock_backend.name = "httpx"
    mock_backend.open.return_value = MagicMock()
    mock_backend.open.return_value.url = "https://example.com"
    mock_backend.open.return_value.html = "<html>Hello</html>"
    mock_backend.open.return_value.text = "Hello"
    mock_backend.open.return_value.status = 200

    with patch("crawlix.async_api._create_backend", return_value=mock_backend):
        from crawlix.async_api import AsyncBrowser
        async with AsyncBrowser(backend="httpx") as b:
            page = await b.open("https://example.com")
            assert page.url == "https://example.com"
            assert page.status == 200
            assert "Hello" in page.html


@pytest.mark.asyncio
async def test_aget_returns_page():
    mock_backend = AsyncMock()
    mock_backend.name = "httpx"
    mock_backend.open.return_value = MagicMock()
    mock_backend.open.return_value.url = "https://example.com"
    mock_backend.open.return_value.html = "<html>Hello</html>"

    with patch("crawlix.async_api._create_backend", return_value=mock_backend):
        from crawlix.async_api import aget
        page = await aget("https://example.com")
        assert page.url == "https://example.com"
