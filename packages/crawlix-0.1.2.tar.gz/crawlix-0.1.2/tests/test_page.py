from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from crawlix.backends.protocol import ElementData, PageData
from crawlix.page import Page


@pytest.fixture
def mock_backend():
    backend = MagicMock()
    backend.name = "mock"
    backend.supports_js = True
    backend.open.return_value = PageData(
        url="https://example.com",
        html="<html><body><h1>Hello</h1></body></html>",
        text="Hello",
        title="Test Page",
        status=200,
        headers={"content-type": "text/html"},
    )
    backend.find.return_value = ElementData(tag="h1", text="Hello", html="<h1>Hello</h1>")
    backend.find_all.return_value = [
        ElementData(tag="a", text="Link 1"),
        ElementData(tag="a", text="Link 2"),
    ]
    backend.screenshot.return_value = b"image_data"
    return backend


@pytest.fixture
def page(mock_backend) -> Page:
    return Page(mock_backend, PageData(
        url="https://example.com",
        html="<html><body><h1>Hello</h1></body></html>",
        text="Hello",
        title="Test Page",
        status=200,
        headers={"content-type": "text/html"},
    ))


class TestPageProperties:
    def test_url(self, page):
        assert page.url == "https://example.com"

    def test_title(self, page):
        assert page.title == "Test Page"

    def test_html(self, page):
        assert "Hello" in page.html

    def test_text(self, page):
        assert page.text == "Hello"

    def test_status(self, page):
        assert page.status == 200

    def test_headers(self, page):
        assert page.headers["content-type"] == "text/html"


class TestPageQuerying:
    def test_find_returns_element(self, page):
        el = page.find("h1")
        assert el is not None
        assert el.text == "Hello"

    def test_find_returns_none(self, mock_backend):
        mock_backend.find.return_value = None
        page = Page(mock_backend)
        assert page.find(".nonexistent") is None

    def test_find_all_returns_list(self, page):
        els = page.find_all("a")
        assert len(els) == 2
        assert els[0].text == "Link 1"

    def test_find_all_empty(self, mock_backend):
        mock_backend.find_all.return_value = []
        page = Page(mock_backend)
        assert page.find_all(".nonexistent") == []


class TestPageScreenshot:
    def test_screenshot_returns_bytes(self, page):
        data = page.screenshot()
        assert data == b"image_data"


class TestPageChaining:
    def test_goto_returns_page(self, page):
        result = page.goto("https://other.com")
        assert result is page

    def test_reload_returns_page(self, page):
        result = page.reload()
        assert result is page

    def test_click_returns_page(self, page):
        result = page.click("button")
        assert result is page

    def test_type_returns_page(self, page):
        result = page.type("#input", "text")
        assert result is page

    def test_chained_calls(self, mock_backend):
        page = Page(mock_backend)
        result = page.type("#email", "a").click("[type=submit]").wait_for(".dashboard")
        assert result is page


class TestPageLinks:
    def test_links_returns_hrefs(self, mock_backend):
        mock_backend.find_all.return_value = [
            ElementData(tag="a", attributes={"href": "/page1"}),
            ElementData(tag="a", attributes={"href": "/page2"}),
        ]
        page = Page(mock_backend)
        links = page.links()
        assert "/page1" in links
        assert "/page2" in links
