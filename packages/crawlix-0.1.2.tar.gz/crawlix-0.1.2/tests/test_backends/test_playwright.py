from __future__ import annotations


class TestPlaywrightBackendImport:
    def test_import_succeeds(self):
        from crawlix.backends.playwright import PlaywrightBackend
        assert PlaywrightBackend.__name__ == "PlaywrightBackend"
