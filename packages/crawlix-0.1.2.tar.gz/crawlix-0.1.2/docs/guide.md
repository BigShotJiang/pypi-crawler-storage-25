# How-to Guide

Practical recipes for common web scraping and browser automation tasks with crawlix.

---

## Scrape a Static Page

Use the `requests` backend — no browser needed, fastest option.

```python
from crawlix import Browser

with Browser() as b:
    page = b.open("https://example.com")
    heading = page.find("h1").text
    paragraphs = [p.text for p in page.find_all("p")]
    print(heading, paragraphs)
```

Extract all links:

```python
page = b.open("https://example.com")
for href in page.links():
    print(href)
```

Extract all image sources:

```python
for src in page.images():
    print(src)
```

---

## Login to a Website

Requires a browser backend (`playwright` or `selenium`).

```python
with Browser(backend="playwright") as b:
    page = b.open("https://github.com/login")
    page.type("#login_field", "your_username")
    page.type("#password", "your_password")
    page.click("[type=submit]")
    page.wait_for(".dashboard-sidebar")
    print("Logged in:", page.url)
```

### After login — access authenticated pages

The browser keeps the session. Navigate normally:

```python
    page.goto("https://github.com/settings/profile")
    print(page.find("#profile_name").text)  # or type, etc.
```

---

## Extract Tables

Works with any backend.

```python
with Browser() as b:
    page = b.open("https://en.wikipedia.org/wiki/Python_(programming_language)")
    tables = page.tables()
    for row in tables[0]:
        print(" | ".join(row))
```

`page.tables()` returns a list of tables. Each table is a list of rows, each row is a list of cell texts.

---

## Take Screenshots

Requires a browser backend.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")

    # Full page screenshot
    page.screenshot("full.png")

    # Screenshot a specific element
    el = page.find("h1")
    el.screenshot("heading.png")
```

Without a path, `screenshot()` returns the raw PNG bytes:

```python
png_bytes = page.screenshot()
```

---

## Generate PDFs

Requires a browser backend.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")
    page.pdf("page.pdf")
```

---

## Handle Pagination

### "Next page" links

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com/items")
    while True:
        for item in page.find_all(".item"):
            print(item.text)

        next_btn = page.find(".pagination .next")
        if not next_btn or "disabled" in next_btn.classes:
            break
        page.click(".pagination .next a")
        page.wait_for_load()
```

### Infinite scroll

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com/feed")
    for _ in range(5):
        page.scroll(y=1000)
        page.sleep(1)
    items = page.find_all(".post")
    print(f"Loaded {len(items)} items")
```

---

## Use Proxies

Works across all backends.

```python
with Browser(proxy="http://user:pass@proxy-host:8080") as b:
    page = b.open("https://ipinfo.io/json")
    print(page.json())
```

---

## Wait for Content

Requires a browser backend.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")

    # Wait for an element to appear
    page.wait_for(".dynamic-content", timeout=10)

    # Wait for specific text
    page.wait_for_text("Welcome back", timeout=5)

    # Wait for URL to match pattern
    page.wait_for_url("**/dashboard/**", timeout=15)

    # Wait for network to be idle
    page.wait_for_network_idle(timeout=30)
```

---

## Execute JavaScript

Requires a browser backend.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")

    # Evaluate JS in page context
    title = page.evaluate("document.title")

    # Run JS on a specific element
    count = page.evaluate_on("ul > li", "el => el.childElementCount")
```

---

## Intercept Network Requests

Requires Playwright backend.

```python
def mock_api(request):
    print("Intercepted:", request.url)

with Browser(backend="playwright") as b:
    page = b.open("https://example.com")
    page.intercept("**/api/**", mock_api)
```

---

## File Upload

Requires a browser backend.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com/upload")
    page.upload("#file-input", "/path/to/file.pdf")
    page.click("[type=submit]")
    page.wait_for(".success")
```

---

## Scrape SPAs (Single Page Apps)

SPAs render content with JavaScript. You need a browser backend.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com/spa")
    page.wait_for(".app-loaded")
    # Content is now rendered
    print(page.text)
```

---

## Chaining Methods

All `Page` interaction methods return `self`, enabling chaining:

```python
with Browser(backend="playwright") as b:
    page = (
        b.open("https://example.com/login")
        .type("#email", "user@example.com")
        .type("#password", "secret")
        .click("[type=submit]")
        .wait_for(".dashboard")
    )
    print(page.title)
```

---

## Async Scraping

For IO-bound workloads, use the async API.

```python
import asyncio
from crawlix.async_api import AsyncBrowser, aget, afetch

async def main():
    # Full async browser
    async with AsyncBrowser() as b:
        page = await b.open("https://example.com")
        print(page.title)

    # One-liner convenience
    page = await aget("https://api.github.com/users/keyreyla")
    html = await afetch("https://example.com")

asyncio.run(main())
```

---

## Error Handling

```python
from crawlix.exceptions import (
    NavigationError,
    TimeoutError,
    BackendError,
)

try:
    with Browser(backend="playwright") as b:
        page = b.open("https://example.com")
        page.wait_for(".nonexistent", timeout=1)
except TimeoutError:
    print("Element did not appear")
except BackendError as e:
    print(f"Backend issue: {e}")
```

> [!TIP]
> `BackendError` messages include install hints, so your users always know what to do.
