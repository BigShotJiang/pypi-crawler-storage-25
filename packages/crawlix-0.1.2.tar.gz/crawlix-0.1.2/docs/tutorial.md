# Getting Started with crawlix

Welcome to crawlix. This tutorial will take you from zero to scraping web pages in under five minutes.

---

## Prerequisites

- Python 3.10 or later
- `pip` installed

---

## 1. Install crawlix

```bash
pip install crawlix
```

That is it. No optional dependencies required — crawlix works out of the box with `requests` and `BeautifulSoup`.

> [!TIP]
> If you plan to do browser automation later, also install:
> ```bash
> pip install crawlix[full]
pip install crawlix[termux]    # for Termux/Android
> ```

---

## 2. Your First Scrape

Create a file called `scrape.py`:

```python
from crawlix import Browser

with Browser() as b:
    page = b.open("https://example.com")
    print(page.title)
    print(page.find("h1").text)
    print(page.find("p").text)
```

Run it:

```bash
python scrape.py
```

Output:

```
Example Domain
Example Domain
This domain is for use in illustrative examples in documents. ...
```

**What happened?**

1. `Browser()` auto-detected the best available backend (likely `requests`).
2. `b.open(url)` fetched the page and parsed the HTML.
3. `page.find("h1")` found the first `<h1>` element and returned an `Element`.
4. `.text` extracted the visible text.

---

## 3. Extract Multiple Elements

```python
from crawlix import Browser

with Browser() as b:
    page = b.open("https://news.ycombinator.com")
    for item in page.find_all(".titleline > a"):
        print(item.text, "->", item.attr("href"))
```

`find_all()` returns a list of `Element` objects. Each `Element` gives you `.text`, `.attr()`, `.html`, and more.

---

## 4. Work with APIs

Many sites provide JSON APIs that are easier to scrape than HTML:

```python
from crawlix import get

page = get("https://api.github.com/users/keyreyla")
data = page.json()
print(data["bio"])
```

`get()` is a one-liner convenience — creates a `Browser`, opens the URL, returns the `Page`.

---

## 5. Try a Browser Backend

Install a browser backend:

```bash
pip install crawlix[playwright]
python -m playwright install chromium
```

Now change one line in your scraper:

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")
    print(page.title)
```

Same API. But now you can click buttons, fill forms, take screenshots, and execute JavaScript.

```python
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")
    page.screenshot("example.png")
    title = page.evaluate("document.title")
    print("Title via JS:", title)
```

---

## 6. Use Convenience Functions

crawlix provides shortcuts for common one-off tasks:

```python
from crawlix import get, fetch, browse

# Get a Page object
page = get("https://example.com")

# Get raw HTML
html = fetch("https://example.com")

# Force a browser backend
page = browse("https://example.com")
```

---

## Next Steps

- Read the [How-to Guide](guide.md) for common scraping patterns
- Browse the [API Reference](reference.md) for the complete method list
- Learn [how crawlix works](explanation.md) under the hood
