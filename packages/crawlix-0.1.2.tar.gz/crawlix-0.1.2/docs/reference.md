# API Reference

Complete reference for the crawlix public API.

---

## Browser

The main entry point. Creates and manages a backend connection.

```python
class Browser(
    backend: str = "auto",         # "auto", "playwright", "selenium", "requests", "httpx"
    headless: bool = True,         # browser backends only
    stealth: bool = True,          # realistic headers + UA rotation
    timeout: int = 30,             # default timeout for all operations (seconds)
    proxy: Optional[str] = None,   # e.g. "http://user:pass@host:port"
    locale: str = "en-US",         # browser locale
    user_agent: Optional[str] = None,  # override auto-detected UA
)
```

### Properties

| Name | Type | Description |
|------|------|-------------|
| `backend_name` | `str` | Active backend name (e.g. `"requests"`, `"playwright"`) |
| `supports_js` | `bool` | Whether the active backend can execute JavaScript |

### Methods

| Method | Returns | Description |
|--------|---------|-------------|
| `open(url)` | `Page` | Navigate to a URL and return a Page |
| `new_page()` | `Page` | Create a blank Page |
| `close()` | `None` | Release backend resources |

### Context Manager

```python
with Browser() as b:
    ...

# __exit__ always calls close(), even on exception
```

---

## Page

Wraps a webpage. All interaction methods return `self` for chaining.

### Navigation

| Method | Returns | Browser required |
|--------|---------|:----------------:|
| `goto(url)` | `Page` | |
| `reload()` | `Page` | |
| `back()` | `Page` | ✅ |
| `forward()` | `Page` | ✅ |

### Properties

| Name | Type | Description |
|------|------|-------------|
| `url` | `str` | Current page URL |
| `title` | `str` | Page `<title>` content |
| `html` | `str` | Full page HTML |
| `text` | `str` | Visible text only |
| `status` | `int` | HTTP status code |
| `headers` | `dict` | Response headers |

### Querying

| Method | Returns | Description |
|--------|---------|-------------|
| `find(selector)` | `Element \| None` | First matching element |
| `find_all(selector)` | `list[Element]` | All matching elements |
| `find_text(text)` | `Element \| None` | Element containing text |
| `xpath(expr)` | `list[Element]` | Elements matching XPath |

### Interaction

Requires a browser backend.

| Method | Returns | Description |
|--------|---------|-------------|
| `click(selector)` | `Page` | Click an element |
| `double_click(selector)` | `Page` | Double-click |
| `right_click(selector)` | `Page` | Right-click |
| `type(selector, text)` | `Page` | Type text into an input |
| `clear(selector)` | `Page` | Clear an input field |
| `submit(selector="form")` | `Page` | Submit a form |
| `select(selector, value)` | `Page` | Select an `<option>` |
| `hover(selector)` | `Page` | Hover over an element |
| `focus(selector)` | `Page` | Focus an element |
| `blur(selector)` | `Page` | Remove focus |
| `scroll(x=0, y=500)` | `Page` | Scroll the page |
| `scroll_to(selector)` | `Page` | Scroll to an element |
| `key(key)` | `Page` | Press a key (`"Enter"`, `"Tab"`, etc.) |
| `upload(selector, path)` | `Page` | Upload a file |

### Waiting

Requires a browser backend.

| Method | Returns | Description |
|--------|---------|-------------|
| `wait_for(selector, timeout=None)` | `Page` | Wait for element to appear |
| `wait_for_text(text, timeout=None)` | `Page` | Wait for text to appear |
| `wait_for_url(pattern, timeout=None)` | `Page` | Wait for URL to match pattern |
| `wait_for_load(timeout=None)` | `Page` | Wait for page to fully load |
| `wait_for_network_idle(timeout=None)` | `Page` | Wait for network to be idle |
| `sleep(seconds)` | `Page` | Sleep for N seconds |

> `timeout` defaults to the `Browser(timeout=...)` value.

### JavaScript

Requires a browser backend.

| Method | Returns | Description |
|--------|---------|-------------|
| `evaluate(js_code)` | `Any` | Execute JS in page context |
| `evaluate_on(selector, js)` | `Any` | Execute JS on a specific element |

### Network

| Method | Returns | Browser required |
|--------|---------|:----------------:|
| `set_headers(headers)` | `Page` | |
| `set_cookies(cookies)` | `Page` | |
| `get_cookies()` | `list[dict]` | ✅ |
| `clear_cookies()` | `Page` | |
| `intercept(pattern, handler)` | `Page` | ✅ (Playwright only) |

### Extraction

| Method | Returns | Description |
|--------|---------|-------------|
| `links()` | `list[str]` | All `href` values |
| `images()` | `list[str]` | All `src` values |
| `tables()` | `list[list[list[str]]]` | All HTML tables |
| `forms()` | `list[dict]` | All form elements |
| `json()` | `dict` | Parse response body as JSON |
| `meta()` | `dict` | All `<meta>` tags |

### Output

| Method | Returns | Browser required |
|--------|---------|:----------------:|
| `screenshot(path=None)` | `bytes` | ✅ |
| `pdf(path=None)` | `bytes` | ✅ (Playwright) |
| `save(path)` | `None` | |
| `show()` | `None` | Pretty-print HTML |

---

## Element

Represents a single DOM element.

### Properties

| Name | Type | Description |
|------|------|-------------|
| `text` | `str` | Inner text |
| `html` | `str` | Inner HTML |
| `outer_html` | `str` | Outer HTML (including the element itself) |
| `tag` | `str` | Tag name (e.g. `"div"`, `"a"`) |
| `id` | `str` | `id` attribute |
| `classes` | `list[str]` | CSS class list |

### Attributes

| Method | Returns | Description |
|--------|---------|-------------|
| `attr(name, default="")` | `str` | Get an attribute value |
| `attrs` | `dict` | All attributes as a dict |
| `has_attr(name)` | `bool` | Check if attribute exists |

### Traversal

| Method | Returns | Description |
|--------|---------|-------------|
| `find(selector)` | `Element \| None` | First matching descendant |
| `find_all(selector)` | `list[Element]` | All matching descendants |
| `parent()` | `Element \| None` | Parent element |
| `children()` | `list[Element]` | Direct children |
| `siblings()` | `list[Element]` | Sibling elements |
| `next()` | `Element \| None` | Next sibling |
| `prev()` | `Element \| None` | Previous sibling |

### Interaction

Requires a browser backend.

| Method | Returns | Description |
|--------|---------|-------------|
| `click()` | `Element` | Click the element |
| `double_click()` | `Element` | Double-click |
| `type(text)` | `Element` | Type text into the element |
| `clear()` | `Element` | Clear the element |
| `hover()` | `Element` | Hover over the element |
| `focus()` | `Element` | Focus the element |
| `scroll_into_view()` | `Element` | Scroll until element is visible |
| `screenshot(path=None)` | `bytes` | Screenshot of the element only |

### Status Checks

Requires a browser backend.

| Method | Returns |
|--------|---------|
| `is_visible()` | `bool` |
| `is_enabled()` | `bool` |
| `is_checked()` | `bool` |
| `bounding_box()` | `dict` (`{x, y, width, height}`) |

### Magic Methods

| Method | Behavior |
|--------|----------|
| `__bool__()` | Always `True` — so `if page.find("x"):` works naturally |
| `__str__()` | Returns `.text` |
| `__repr__()` | Returns `"Element(<tag> .class #id)"` |

---

## Convenience Functions

```python
from crawlix import get, fetch, browse

get(url, **kwargs)     # -> Page     — one-liner open
fetch(url, **kwargs)   # -> str      — get raw HTML
browse(url, **kwargs)  # -> Page     — force Playwright backend
```

Async variants:

```python
from crawlix.async_api import aget, afetch

await aget(url, **kwargs)    # -> AsyncPage
await afetch(url, **kwargs)  # -> str
```

---

## Async API

### AsyncBrowser

```python
class AsyncBrowser(
    backend: str = "auto",
    headless: bool = True,
    stealth: bool = True,
    timeout: int = 30,
    proxy: Optional[str] = None,
    locale: str = "en-US",
    user_agent: Optional[str] = None,
)
```

- `async open(url)` -> `AsyncPage`
- `async close()`
- `async __aenter__` / `async __aexit__`

### AsyncPage

Minimal async page with:

| Name | Type | Description |
|------|------|-------------|
| `url` | `str` | Page URL |
| `html` | `str` | Page HTML |
| `text` | `str` | Visible text |
| `status` | `int` | HTTP status |
| `async json()` | `dict` | Parse as JSON |

---

## Exceptions

```
CrawlixError
├── BackendError       # Backend unavailable or op not supported
├── TimeoutError       # Wait exceeded timeout
├── NavigationError    # Page failed to load
├── SelectorError      # Invalid selector or element not found
├── NetworkError       # Connection error
└── JavaScriptError    # JS evaluation failed
```

`BackendError` always includes a human-readable install hint:

```
BackendError: screenshot() requires a browser backend.
Install one:
  pip install crawlix[playwright]   ← recommended
  pip install crawlix[selenium]
```

---

## Backend Feature Matrix

| Feature | requests | playwright | selenium | httpx |
|---------|:--------:|:----------:|:--------:|:-----:|
| **Supported** | ✅ | ✅ | ✅ | ✅ |
| **JS execution** | | ✅ | ✅ | |
| **Click/type/hover** | | ✅ | ✅ | |
| **Screenshot** | | ✅ | ✅ | |
| **PDF** | | ✅ | | |
| **Network intercept** | | ✅ | | |
| **Wait methods** | | ✅ | ✅ | |
| **Async** | | ✅ | | ✅ |
| **File upload** | | ✅ | ✅ | |
| **Cookie management** | ✅ | ✅ | ✅ | ✅ |
| **Proxy** | ✅ | ✅ | ✅ | ✅ |
| **Stealth defaults** | ✅ | ✅ | ✅ | ✅ |

---

## Backend Priority (Auto-detect)

```
playwright → selenium → httpx → requests+bs4
```

If no installed backend is found, `BackendError` is raised with install instructions.
