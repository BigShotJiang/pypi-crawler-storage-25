# crawlix

> One API. Any backend. Full browser automation to lightweight scraping.

**crawlix** is a Python browser automation and web scraping library with a unified API across multiple backends. Write your code once — switch between lightweight HTTP scraping and full browser automation without changing a single line.

```python
from crawlix import Browser

# Zero-setup scraping
with Browser() as b:
    page = b.open("https://example.com")
    print(page.find("h1").text)

# Full browser automation — same API
with Browser(backend="playwright") as b:
    page = b.open("https://example.com")
    page.type("#email", "user@example.com")
    page.click("[type=submit]")
    page.wait_for(".dashboard")
    page.screenshot("result.png")
```

## Install

```bash
pip install crawlix                    # core
pip install crawlix[playwright]        # full browser
pip install crawlix[selenium]          # full browser
pip install crawlix[async]             # async support
pip install crawlix[full]              # everything
```

## Quick Links

- [Quick Start](tutorial.md) — get scraping in 5 minutes
- [How-to Guide](guide.md) — practical recipes
- [API Reference](reference.md) — complete API docs
- [Architecture](explanation.md) — how crawlix works
