# How crawlix Works

An architectural overview of crawlix's design, decisions, and internals.

---

## Design Principles

crawlix is built on six core principles:

| # | Principle | Why |
|---|-----------|-----|
| 1 | **Same API, any backend** | Swap between HTTP scraping and full browser automation without changing user code |
| 2 | **Auto-detect** | No configuration needed — crawlix picks the best available backend |
| 3 | **Zero hard dependencies** | `pip install crawlix` always succeeds; optional backends are lazy-loaded |
| 4 | **Helpful errors** | `BackendError` always includes an install hint, never a silent failure |
| 5 | **Context manager safety** | Resources are always cleaned up, even when exceptions occur |
| 6 | **Stealth by default** | Realistic headers, UA rotation, and anti-fingerprinting out of the box |

---

## Backend Strategy Pattern

crawlix uses the **Strategy pattern** to abstract away different browser automation libraries.

```
Browser
  └── Backend (abstract base)
        ├── RequestsBackend     (requests + BeautifulSoup)
        ├── PlaywrightBackend   (Playwright)
        ├── SeleniumBackend     (Selenium)
        └── HttpxBackend        (httpx, async only)
```

### Backend ABC

The `Backend` abstract base class (in `src/crawlix/backends/protocol.py`) defines the interface:

- **Required methods**: `name`, `supports_js`, `open(url)`, `close()`, `find(selector)`, `find_all(selector)`
- **Optional overrides**: navigation (`goto`, `reload`, `back`, `forward`), interaction (`click`, `type`, etc.), waiting, JavaScript execution, screenshots, network management
- **Default behavior**: All optional methods raise `BackendError` with an install hint

This ensures that calling `screenshot()` on the `requests` backend gives a clear error rather than a confusing `NotImplementedError`.

### PageData and ElementData

Backends return data, not objects. `PageData` and `ElementData` are simple dataclasses defined in `protocol.py`. The `Page` and `Element` classes in the public API wrap these dataclasses and dispatch method calls back to the backend.

```
Browser.open(url)
  └── backend.open(url)         → PageData
      └── Page(backend, data)   → user-facing Page object

Page.find(selector)
  └── backend.find(selector)    → ElementData | None
      └── Element(backend, data) → user-facing Element object
```

---

## Auto-detect Flow

When `backend="auto"` (the default), crawlix follows this priority:

```
1. Try playwright  ─── ImportError? ──→  2
   ↓ success
   PlaywrightBackend

2. Try selenium   ─── ImportError? ──→  3
   ↓ success
   SeleniumBackend

3. Try httpx      ─── ImportError? ──→  4
   ↓ success
   HttpxBackend

4. Return RequestsBackend (always available — core dependency)
```

Detection runs once during `Browser.__init__()` and is cached for the lifetime of the `Browser` instance. It never re-detects per request.

> [!NOTE]
> If no backend is available at all (e.g., in a stripped environment), `RequestsBackend` always works since `requests` and `beautifulsoup4` are hard dependencies.

---

## Stealth & Anti-detection

crawlix applies anti-detection measures by default when `stealth=True`.

### For HTTP backends (`requests`, `httpx`)

- A random real browser User-Agent is selected from a curated list of Chrome, Firefox, and Edge UAs (Windows, macOS, Linux)
- Realistic headers are set: `Accept`, `Accept-Language`, `Accept-Encoding`, `Sec-Fetch-*` headers, `Upgrade-Insecure-Requests`

### For browser backends (`playwright`, `selenium`)

- Same realistic headers and UA rotation
- Viewport and screen dimensions set to 1920×1080
- Selenium disables `AutomationControlled` feature flags
- Playwright uses Chromium with near-human viewport settings

```python
# Disable stealth if you want raw browser behavior
Browser(stealth=False)
```

---

## Context Manager Safety

`Browser.__exit__` guarantees that `close()` is called, even if an exception occurs inside the `with` block:

```python
with Browser() as b:
    page = b.open("https://example.com")
    raise RuntimeError("Something went wrong")
# b.close() is still called — no resource leak
```

This is enforced in `__exit__`:

```python
def __exit__(self, exc_type, exc_val, exc_tb):
    self.close()
    return False  # don't suppress exceptions
```

---

## Why src-layout?

crawlix uses the `src/` package layout (`src/crawlix/` instead of `crawlix/` at root). This:

1. **Prevents import confusion** — tests import the installed package, not a local directory
2. **Catches packaging bugs** — if `pyproject.toml` is misconfigured, imports fail during testing
3. **Standard Python convention** — recommended by PyPA for distributable packages

---

## Why Optional Dependencies?

All browser backends are **optional extras**. The core package (`pip install crawlix`) only depends on `requests` and `beautifulsoup4`.

Optional imports are always inside functions or methods, wrapped in `try/except ImportError`:

```python
# Correct — lazy import with clear error
def __init__(self):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise BackendError(
            "Playwright backend requires: pip install crawlix[playwright]"
        )
```

This ensures:
- `pip install crawlix` always succeeds in 2 seconds
- Users only install what they actually use
- Error messages tell users exactly what to do

---

## Exception Hierarchy

All exceptions inherit from `CrawlixError(BaseException)`:

```
CrawlixError
├── BackendError       — backend unavailable or operation not supported
├── TimeoutError       — wait_for*() exceeded timeout
├── NavigationError    — page failed to load (HTTP error, DNS failure, etc.)
├── SelectorError      — invalid CSS selector or element not found
├── NetworkError       — connection refused, timeout, DNS failure
└── JavaScriptError    — JS evaluation returned an error
```

`BackendError` is special — its message always includes actionable install instructions:

```
BackendError: click() requires a browser backend.
Install one:
  pip install crawlix[playwright]
  pip install crawlix[selenium]
```

---

## Testing Strategy

crawlix uses three levels of testing:

| Level | What | Dependencies |
|-------|------|--------------|
| **Unit** | Browser, Page, Element logic | `unittest.mock` |
| **Backend** | Each backend's data parsing | Mocked HTTP (`responses` library) |
| **Integration** | Import verification | `pytest.importorskip` |

Tests never hit real URLs. HTTP responses are mocked. Browser backends are verified by import only (no browser launch in CI).

---

## Related

- [Getting Started Tutorial](tutorial.md)
- [How-to Guide](guide.md)
- [API Reference](reference.md)
