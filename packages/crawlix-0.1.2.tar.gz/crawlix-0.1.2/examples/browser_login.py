"""
crawlix example: Browser automation (PC only)
Requires: pip install crawlix[playwright]
          playwright install chromium
"""

from crawlix import Browser

with Browser(backend="playwright", headless=False) as b:
    # Go to login page
    page = b.open("https://github.com/login")

    # Fill credentials
    page.type("#login_field", "your_username")
    page.type("#password", "your_password")

    # Submit
    page.click("[type=submit]")

    # Wait for dashboard
    page.wait_for(".dashboard-sidebar", timeout=10)

    # Take screenshot
    page.screenshot("github_dashboard.png")

    # Extract profile info
    profile = page.find(".js-profile-editable-area")
    if profile:
        print(f"Profile: {profile.text.strip()}")

    print(f"Logged in: {page.url}")
