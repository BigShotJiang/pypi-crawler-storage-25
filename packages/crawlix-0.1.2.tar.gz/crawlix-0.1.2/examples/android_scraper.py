"""
crawlix example: Android/Termux optimized scraper
- Force requests backend (Playwright unavailable on Termux)
- Mobile User-Agent
- Saves results to JSON
"""

from crawlix import Browser
import json

HEADLINES = []

with Browser(
    backend="requests",
    user_agent="Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36",
) as b:
    page = b.open("https://news.detik.com")

    for item in page.find_all("article"):
        title = item.find("h3")
        link = item.find("a")
        if title and link:
            HEADLINES.append({
                "title": title.text.strip(),
                "url": link.attr("href"),
            })

with open("headlines.json", "w") as f:
    json.dump(HEADLINES, f, indent=2)

print(f"Saved {len(HEADLINES)} headlines to headlines.json")
