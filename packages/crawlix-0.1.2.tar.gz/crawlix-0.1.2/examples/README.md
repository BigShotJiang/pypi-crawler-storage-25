# crawlix Examples

Real-world examples for PC and Android.

| File | Platform | Requires | What it does |
|------|----------|----------|-------------|
| `scrape_news.py` | PC + Android | core | Scrape news headlines (auto-detect) |
| `android_scraper.py` | Android | core | Termux-optimized news scraper → JSON |
| `browser_login.py` | PC only | `crawlix[playwright]` | GitHub login + screenshot |
| `async_scraper.py` | PC + Android | `crawlix[async]` | Concurrent fetch multiple APIs |

## Run

```bash
# Core
pip install crawlix
python examples/scrape_news.py

# With browser
pip install crawlix[playwright]
playwright install chromium
python examples/browser_login.py

# Async
pip install crawlix[async]
python examples/async_scraper.py

# Android/Termux - use termux extra
pip install crawlix[termux]
python examples/android_scraper.py
```
