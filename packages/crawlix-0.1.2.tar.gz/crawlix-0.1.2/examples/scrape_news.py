"""
crawlix example: Scrape news headlines
Works on: PC (Linux/Mac/Windows) + Android (Termux)
"""

from crawlix import Browser

# Auto-detect: requests on Termux, playwright on PC
with Browser() as b:
    page = b.open("https://news.detik.com")

    print(f"Backend: {b.backend_name}")
    print(f"Title: {page.title}\n")

    for i, item in enumerate(page.find_all("h3 > a"), 1):
        print(f"{i:>3}. {item.text.strip()}")
        print(f"     {item.attr('href')}")
