"""
crawlix example: Async scraping multiple sites
Works on: PC + Android (with crawlix[async])
"""

import asyncio
from crawlix.async_api import aget, afetch

URLS = [
    "https://httpbin.org/get",
    "https://api.github.com/users/keyreyla",
    "https://jsonplaceholder.typicode.com/todos/1",
]


async def main():
    # Fetch all URLs concurrently
    pages = await asyncio.gather(*[aget(u) for u in URLS])

    for page in pages:
        data = page.json()
        print(f"[{page.status}] {page.url}")
        print(f"  Response: {json.dumps(data, indent=2)[:100]}...")
        print()

    # Or get raw HTML
    html = await afetch("https://example.com")
    print(f"Fetched {len(html)} bytes from example.com")


import json
asyncio.run(main())
