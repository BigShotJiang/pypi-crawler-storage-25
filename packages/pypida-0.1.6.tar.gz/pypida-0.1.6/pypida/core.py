import requests
import uuid
import base64
import hashlib
import os
import json
import stat
import time
import math
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

class PIDA:
    CONFIG_FILE = ".pida_config"

    def __init__(self, relay_url, seed_uuid, nickname="Anonymous"):
        self.relay = relay_url
        self.id = seed_uuid
        self.nickname = nickname
        self.inbox = []
        self.block_list = []
        
        # Identity Derivation
        seed = hashlib.sha256(self.id.encode()).digest()
        self.priv_key = ec.derive_private_key(int.from_bytes(seed, "big"), ec.SECP256R1())
        self.pub_key = self.priv_key.public_key()
        self.pub_key_pem = self.pub_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()
        
        self._load_config()

    # --- KHỞI TẠO (CONSTRUCTORS) ---
    @classmethod
    def create(cls, relay_url, nickname="Anonymous", save_local=True):
        """Tạo mới hoàn toàn một ID và lưu cấu hình"""
        new_id = str(uuid.uuid4())
        client = cls(relay_url, new_id, nickname)
        if save_local: client._save_config()
        return client

    @classmethod
    def import_id(cls, relay_url, existing_uuid, nickname="Anonymous", save_local=True):
        """Import một ID đã có sẵn"""
        client = cls(relay_url, existing_uuid, nickname)
        if save_local: client._save_config()
        return client

    # --- HỆ THỐNG CONFIG & BACKUP ---
    def _save_config(self):
        data = {
            "uuid": self.id,
            "nickname": self.nickname,
            "block_list": self.block_list,
            "inbox": self.inbox
        }
        try:
            with open(self.CONFIG_FILE, "w") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            if os.name != 'nt': os.chmod(self.CONFIG_FILE, 0o600)
        except Exception as e:
            print(f"⚠️ Save error: {e}")

    def _load_config(self):
        if os.path.exists(self.CONFIG_FILE):
            try:
                with open(self.CONFIG_FILE, "r") as f:
                    data = json.load(f)
                    self.id = data.get("uuid", self.id)
                    self.nickname = data.get("nickname", self.nickname)
                    self.block_list = data.get("block_list", [])
                    self.inbox = data.get("inbox", [])
            except: pass

    def export_backup(self, filepath):
        self._save_config()
        import shutil
        shutil.copy(self.CONFIG_FILE, filepath)
        return True

    def import_backup(self, filepath):
        if os.path.exists(filepath):
            with open(filepath, "r") as f:
                data = json.load(f)
                self.id = data["uuid"]
                self.nickname = data["nickname"]
                self.block_list = data.get("block_list", [])
                self.inbox = data.get("inbox", [])
            self._save_config()
            return True
        return False

    # --- QUẢN LÝ BLOCKLIST & INBOX ---
    def get_blocklist(self): return self.block_list
    def add_block(self, target_uuid):
        if target_uuid not in self.block_list:
            self.block_list.append(target_uuid)
            self._save_config()
    def remove_block(self, target_uuid):
        if target_uuid in self.block_list:
            self.block_list.remove(target_uuid)
            self._save_config()

    def delete_message(self, msg_uuid):
        self.inbox = [m for m in self.inbox if m.get('uuid') != msg_uuid]
        self._save_config()

    def view_inbox(self):
        return json.dumps(self.inbox, indent=4, ensure_ascii=False)

    # --- CRYPTO & PoW ---
    def _get_shared_secret(self, peer_pub_pem):
        peer_pub = serialization.load_pem_public_key(peer_pub_pem.encode())
        shared_key = self.priv_key.exchange(ec.ECDH(), peer_pub)
        return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'pida-e2ee').derive(shared_key)

    def encrypt_msg(self, peer_pub_pem, plaintext):
        key = self._get_shared_secret(peer_pub_pem)
        nonce = os.urandom(12)
        ct = AESGCM(key).encrypt(nonce, plaintext.encode(), None)
        return base64.b64encode(nonce + ct).decode()

    def decrypt_msg(self, peer_pub_pem, ciphertext):
        key = self._get_shared_secret(peer_pub_pem)
        data = base64.b64decode(ciphertext)
        return AESGCM(key).decrypt(data[:12], data[12:], None).decode()

    def _compute_pow(self, data, diff=4):
        nonce = 0
        prefix = '0' * diff
        while True:
            h = hashlib.sha256(f"{data}{nonce}".encode()).hexdigest()
            if h.startswith(prefix): return {"nonce": nonce, "hash": h}
            nonce += 1

    def _gen_uuidv8(self):
        return f"{int(time.time() * 1000):012x}-{uuid.uuid4()}"

    # --- MESSAGING & FILES ---
    def send_file(self, to_id, peer_pub_pem, filepath, chunk_size=512*1024):
        file_id = self._gen_uuidv8()
        with open(filepath, "rb") as f:
            total_chunks = math.ceil(os.path.getsize(filepath) / chunk_size)
            for i in range(total_chunks):
                chunk = f.read(chunk_size)
                requests.post(f"{self.relay}/upload", json={
                    "file_id": file_id, "chunk_index": i, "data": base64.b64encode(chunk).decode(), "to_id": to_id
                })
        return self.send_message(to_id, peer_pub_pem, f"FILE_SHARE:{file_id}|NAME:{os.path.basename(filepath)}", is_file=True)

    def send_message(self, to_id, peer_pub_pem, content, is_file=False):
        msg_id = self._gen_uuidv8()
        encrypted_content = self.encrypt_msg(peer_pub_pem, content)
        msg = {
            "id": msg_id, "from": self.id, "nickname": self.nickname, "to": to_id,
            "content": encrypted_content, "type": "file" if is_file else "text",
            "timestamp": int(time.time() * 1000), "sender_pub": self.pub_key_pem
        }
        pow_data = self._compute_pow(msg_id, diff=4) # Khớp với Worker
        return requests.post(f"{self.relay}/send", json={"msg": msg, "pow": pow_data}).json()

    def sync(self):
        res = requests.get(f"{self.relay}/challenge?address={self.id}").json()
        challenge = res['challenge']
        signature = self.priv_key.sign(challenge.encode(), ec.ECDSA(hashes.SHA256()))
        payload = {"address": self.id, "challenge": challenge, "signature": base64.b64encode(signature).decode()}
        
        raw_msgs = requests.post(f"{self.relay}/get", json=payload).json().get('messages', [])
        for m in raw_msgs:
            if m['from'] in self.block_list:
                self.ack(m['id'])
                continue
            try:
                decrypted = self.decrypt_msg(m['sender_pub'], m['content'])
                msg_entry = {
                    "uuid": m['id'], "sender_uuid": m['from'], "nickname": m.get('nickname', 'Unknown'),
                    "content": decrypted, "type": m['type'],
                    "time": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(m['timestamp']/1000))
                }
                if m['type'] == "file" and "FILE_SHARE:" in decrypted:
                    file_id = decrypted.split('|')[0].split(':')[1]
                    msg_entry["download_link"] = f"{self.relay}/get-file?file_id={file_id}&to_id={self.id}"
                self.inbox.append(msg_entry)
                self.ack(m['id'])
            except: continue
        self._save_config()
        return self.inbox

    def ack(self, msg_id):
        requests.post(f"{self.relay}/ack", json={"id": msg_id, "address": self.id})
    def disconnect(self):
        """Đóng kết nối serverless: Lưu cấu hình và giải phóng tài nguyên"""
        try:
            # 1. Lưu lại trạng thái cuối cùng (Inbox, Blocklist)
            self._save_config()
            
            # 2. Xóa dữ liệu trong RAM để bảo mật
            self.inbox = []
            self.block_list = []
            
            # 3. Hủy các đối tượng nhạy cảm (Key) trong memory
            del self.priv_key
            del self.pub_key
            
            print("🔌 PIDA Serverless Session Closed. Data synced to .pida_config")
            return True
        except Exception as e:
            print(f"⚠️ Error during disconnect: {e}")
            return False