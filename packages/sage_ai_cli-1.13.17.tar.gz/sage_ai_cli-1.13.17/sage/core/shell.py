"""Shell command execution utilities for SAGE.

This module contains functions for:
- Running shell commands with scoped directory support
- Extracting shell/bash blocks from text
- Quoting strings for safe shell use
- Reading files with line numbers

Extracted from main.py for better code organization (P3-73).

P0-10-15: Now uses safe execution via commands.py instead of shell=True.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Tuple, Optional, List

from sage.core.commands import execute_command, CommandResult


__all__ = [
    "extract_scoped_prefix",
    "resolve_scoped_directory",
    "run_shell",
    "safe_shell_exec",
    "shell_quote",
    "extract_bash_blocks",
    "sanitize_shell_block",
    "strip_search_comment",
    "read_file_context",
    "CommandResult",
]


def extract_scoped_prefix(value: str) -> Tuple[Optional[str], str]:
    """Extract an optional `[cwd=path]` or `[dir=path]` prefix.

    Args:
        value: String that may contain a scoped prefix

    Returns:
        Tuple of (scope_path or None, remaining_value)

    Examples:
        >>> extract_scoped_prefix("[cwd=src] pytest")
        ('src', 'pytest')
        >>> extract_scoped_prefix("pytest")
        (None, 'pytest')
    """
    match = re.match(r"^\s*\[(?:cwd|dir)=(.+?)\]\s*(.*)$", value, re.DOTALL)
    if not match:
        return None, value.strip()
    return match.group(1).strip(), match.group(2).strip()


def resolve_scoped_directory(
    scope: str, cwd: Path
) -> Tuple[Optional[Path], Optional[str]]:
    """Resolve a scoped child directory under the workspace root.

    Args:
        scope: Relative or absolute path to resolve
        cwd: Current working directory (workspace root)

    Returns:
        Tuple of (resolved_path or None, error_message or None)
    """
    workspace_root = cwd.resolve()
    try:
        candidate = Path(scope)
        target = (
            candidate.resolve()
            if candidate.is_absolute()
            else (cwd / candidate).resolve()
        )
    except (OSError, ValueError) as exc:
        return None, f"[error: invalid scoped directory {scope!r}: {exc}]"

    if not str(target).startswith(str(workspace_root)):
        return None, f"[error: scoped directory outside workspace: {scope}]"
    if not target.exists() or not target.is_dir():
        return None, f"[error: scoped directory not found: {scope}]"
    return target, None


def run_shell(cmd: str, cwd: Path, timeout: int = 30) -> str:
    """Run a shell command and return combined stdout+stderr.

    Supports scoped directory prefixes like `[cwd=subdir] command`.

    P0-10-15: Now uses safe execution via commands.py instead of direct shell=True.
    For complex commands with shell operators, falls back to shell execution
    only after validation against blocked patterns.

    Args:
        cmd: Shell command to run (may include [cwd=path] prefix)
        cwd: Current working directory
        timeout: Command timeout in seconds

    Returns:
        Combined stdout and stderr output, or error message
    """
    scope, inner_cmd = extract_scoped_prefix(cmd)
    scoped_cwd = cwd
    if scope:
        scoped_cwd_result, error = resolve_scoped_directory(scope, cwd)
        if error:
            return error
        assert scoped_cwd_result is not None  # error is None means result is valid
        scoped_cwd = scoped_cwd_result
        cmd = inner_cmd
    if not cmd.strip():
        return "[error: empty command]"

    # Use safe command execution from commands.py
    # allow_shell=True for backward compatibility with complex commands
    # validate=False to allow grep/find etc that aren't in strict allowlist
    result = execute_command(
        cmd,
        cwd=scoped_cwd,
        timeout=timeout,
        allow_shell=True,  # Allow shell for complex commands with pipes etc
        validate=False,  # Don't enforce strict allowlist for backward compat
    )

    return result.output


def safe_shell_exec(
    cmd: str,
    cwd: Path,
    timeout: int = 30,
    validate: bool = True,
) -> CommandResult:
    """Execute a shell command safely with full validation.

    This is the preferred API for new code. It returns a structured
    CommandResult and validates commands by default.

    Args:
        cmd: Shell command to run
        cwd: Current working directory
        timeout: Command timeout in seconds
        validate: Whether to validate against allowlists (default True)

    Returns:
        CommandResult with success status, output, and error info
    """
    scope, inner_cmd = extract_scoped_prefix(cmd)
    scoped_cwd = cwd
    if scope:
        scoped_cwd_result, error = resolve_scoped_directory(scope, cwd)
        if error:
            return CommandResult(
                success=False,
                returncode=-1,
                stdout="",
                stderr=error,
                command=cmd,
                error=error,
            )
        assert scoped_cwd_result is not None
        scoped_cwd = scoped_cwd_result
        cmd = inner_cmd

    return execute_command(
        cmd,
        cwd=scoped_cwd,
        timeout=timeout,
        allow_shell=True,  # Allow shell for backward compat
        validate=validate,
    )


def shell_quote(s: str) -> str:
    """Quote a string for safe shell use.

    Args:
        s: String to quote

    Returns:
        Single-quoted string with proper escaping
    """
    return "'" + s.replace("'", "'\\''") + "'"


def extract_bash_blocks(text: str) -> List[str]:
    """Extract ```bash or ```shell code blocks from model output.

    Args:
        text: Text containing potential code blocks

    Returns:
        List of command strings from bash/shell code blocks
    """
    blocks = []
    for m in re.finditer(r"```(?:bash|shell|sh)\s*\n(.*?)```", text, re.DOTALL):
        cmd = m.group(1).strip()
        if cmd:
            blocks.append(cmd)
    return blocks


def sanitize_shell_block(cmd: str) -> str:
    """Remove non-shell pseudo-tool directives from a shell block.

    Filters out READ:, SEARCH:, RUN:, FILE: directives and other
    non-command lines that may appear in model output.

    Args:
        cmd: Raw command block from model output

    Returns:
        Cleaned command string
    """
    cleaned: List[str] = []
    for raw in cmd.splitlines():
        line = raw.strip()
        if not line:
            continue
        if re.match(r"^(?:[-*]\s*)?(READ|SEARCH|RUN|FILE):\s*", line):
            continue
        if line.startswith("Task Understanding"):
            continue
        cleaned.append(raw)
    return "\n".join(cleaned).strip()


def strip_search_comment(pattern: str) -> str:
    """Remove trailing instructional comments from SEARCH patterns.

    Args:
        pattern: Search pattern that may have trailing comments

    Returns:
        Clean pattern without trailing # comments
    """
    return re.sub(r"\s+#.*$", "", pattern).strip()


def read_file_context(
    filepath: str, cwd: Path, max_lines: int = 200
) -> Optional[str]:
    """Read a file and return its content with line numbers.

    Args:
        filepath: Relative path to file
        cwd: Current working directory
        max_lines: Maximum number of lines to read

    Returns:
        Formatted file content with line numbers, or None if not found
    """
    target = (cwd / filepath).resolve()
    if not str(target).startswith(str(cwd.resolve())):
        return None
    if not target.exists() or not target.is_file():
        return None
    try:
        full_content = target.read_text("utf-8", errors="replace")
        all_lines = full_content.splitlines()
        lines = all_lines[:max_lines]
        numbered = "\n".join(f"{i+1:>4}| {l}" for i, l in enumerate(lines))
        truncated = (
            f"\n... ({len(lines)}/{len(all_lines)} lines shown)"
            if len(lines) == max_lines and len(all_lines) > max_lines
            else ""
        )
        return f"File: {filepath}\n{numbered}{truncated}"
    except Exception:
        return None


# Backward compatibility aliases (prefixed versions for main.py)
_extract_scoped_prefix = extract_scoped_prefix
_resolve_scoped_directory = resolve_scoped_directory
_run_shell = run_shell
_safe_shell_exec = safe_shell_exec
_shell_quote = shell_quote
_extract_bash_blocks = extract_bash_blocks
_sanitize_shell_block = sanitize_shell_block
_strip_search_comment = strip_search_comment
_read_file_context = read_file_context
