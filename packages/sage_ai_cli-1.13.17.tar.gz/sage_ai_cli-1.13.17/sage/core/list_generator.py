"""
List Generation Excellence for SAGE - Comprehensive implementation of Roadmap Items 121-160.

This module provides:
- P1 Items 121-135: Quantity Achievement
- P1 Items 136-150: List Quality
- P1 Items 151-160: List Formatting

All 40 P1 list generation items are addressed in this module.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Iterator, Callable
from pathlib import Path


# =============================================================================
# ITEM 121-135: QUANTITY ACHIEVEMENT
# =============================================================================

class ListBuildingStrategy(Enum):
    """Item 121: Strategies for building lists progressively."""
    PROGRESSIVE = auto()      # Build 10 items at a time until quota
    CATEGORICAL = auto()      # Explore by category
    PRIORITY_FIRST = auto()   # Start with highest priority items
    BREADTH_FIRST = auto()    # Explore broadly before going deep
    DEPTH_FIRST = auto()      # Explore one area deeply before moving on


@dataclass
class ListItem:
    """A single item in a generated list."""
    number: int
    title: str
    description: str
    file_path: str | None = None
    line_number: int | None = None
    priority: str = "P2"  # P0, P1, P2, P3
    category: str = ""
    effort: str = "medium"  # low, medium, high
    impact: str = "medium"  # low, medium, high

    def to_markdown(self) -> str:
        """Convert to markdown format."""
        parts = [f"{self.number}. **[{self.priority}]** {self.title}"]
        if self.file_path:
            location = f"`{self.file_path}"
            if self.line_number:
                location += f":{self.line_number}"
            location += "`"
            parts.append(f"   - Location: {location}")
        if self.description:
            parts.append(f"   - {self.description}")
        if self.category:
            parts.append(f"   - Category: {self.category}")
        parts.append(f"   - Effort: {self.effort} | Impact: {self.impact}")
        return "\n".join(parts)

    def to_table_row(self) -> str:
        """Convert to markdown table row."""
        location = f"`{self.file_path}:{self.line_number}`" if self.file_path else "-"
        return f"| {self.number} | {self.priority} | {self.title[:50]} | {location} | {self.effort} | {self.impact} |"


@dataclass
class ListGenerationState:
    """State tracking for progressive list generation."""
    items: list[ListItem] = field(default_factory=list)
    target_count: int = 100
    current_count: int = 0
    categories_explored: set[str] = field(default_factory=set)
    files_examined: set[str] = field(default_factory=set)
    is_complete: bool = False
    continuation_prompt: str = ""


class ProgressiveListBuilder:
    """
    Items 121-135: Builds lists progressively to achieve quantity targets.
    """

    # Item 124: Categories for list expansion
    IMPROVEMENT_CATEGORIES = [
        "Security", "Performance", "Testing", "Documentation",
        "Error Handling", "Code Quality", "Architecture", "Accessibility",
        "Maintainability", "Reliability", "Scalability", "Observability",
        "Developer Experience", "User Experience", "API Design", "Data Handling"
    ]

    def __init__(self, target_count: int = 100):
        self.target_count = target_count
        self.state = ListGenerationState(target_count=target_count)

    def add_item(self, item: ListItem) -> bool:
        """
        Item 121: Add an item if not duplicate.
        Returns True if item was added, False if duplicate.
        """
        # Item 123: Deduplication
        for existing in self.state.items:
            if self._is_duplicate(item, existing):
                return False

        item.number = len(self.state.items) + 1
        self.state.items.append(item)
        self.state.current_count = len(self.state.items)

        if item.category:
            self.state.categories_explored.add(item.category)
        if item.file_path:
            self.state.files_examined.add(item.file_path)

        self._check_completion()
        return True

    def add_items_batch(self, items: list[ListItem]) -> int:
        """Add multiple items, return count of items actually added."""
        added = 0
        for item in items:
            if self.add_item(item):
                added += 1
        return added

    def get_continuation_prompt(self) -> str:
        """
        Item 122: Generate a prompt to continue list generation.
        """
        if self.state.is_complete:
            return ""

        remaining = self.target_count - self.state.current_count
        unexplored = set(self.IMPROVEMENT_CATEGORIES) - self.state.categories_explored

        prompt_parts = [
            f"\n## CONTINUATION REQUIRED",
            f"Current items: {self.state.current_count}",
            f"Target: {self.target_count}",
            f"Remaining needed: {remaining}",
            "",
            "Continue listing items starting from number "
            f"{self.state.current_count + 1}.",
            ""
        ]

        if unexplored:
            prompt_parts.append(f"Consider exploring these categories: {', '.join(list(unexplored)[:5])}")

        # Item 125: Category-based expansion
        prompt_parts.append(f"\nCategories already covered: {', '.join(self.state.categories_explored)}")

        return "\n".join(prompt_parts)

    def get_quality_summary(self) -> dict:
        """Item 127-128: Get quality metrics for the list."""
        if not self.state.items:
            return {"count": 0, "quality_score": 0}

        # Priority distribution
        priority_counts = {"P0": 0, "P1": 0, "P2": 0, "P3": 0}
        for item in self.state.items:
            priority_counts[item.priority] = priority_counts.get(item.priority, 0) + 1

        # Items with file references
        with_files = sum(1 for item in self.state.items if item.file_path)

        # Calculate quality score
        quality_score = 0
        quality_score += min(30, self.state.current_count * 0.3)  # Quantity (up to 30)
        quality_score += (with_files / max(self.state.current_count, 1)) * 30  # Grounding (up to 30)
        quality_score += len(self.state.categories_explored) * 2  # Category coverage (up to 32)
        quality_score += 8 if priority_counts["P0"] > 0 else 0  # Has critical items

        return {
            "count": self.state.current_count,
            "target": self.target_count,
            "completion_pct": (self.state.current_count / self.target_count) * 100,
            "with_file_refs": with_files,
            "categories": len(self.state.categories_explored),
            "priority_distribution": priority_counts,
            "quality_score": min(100, quality_score)
        }

    def _is_duplicate(self, new_item: ListItem, existing: ListItem) -> bool:
        """Item 123: Check if items are duplicates."""
        # Same file and line
        if new_item.file_path and new_item.file_path == existing.file_path:
            if new_item.line_number and new_item.line_number == existing.line_number:
                return True

        # Very similar titles
        new_words = set(new_item.title.lower().split())
        existing_words = set(existing.title.lower().split())
        if len(new_words & existing_words) / max(len(new_words), 1) > 0.8:
            return True

        return False

    def _check_completion(self):
        """Check if list generation is complete."""
        self.state.is_complete = self.state.current_count >= self.target_count


# =============================================================================
# ITEMS 136-150: LIST QUALITY
# =============================================================================

@dataclass
class ListItemQuality:
    """Item 136-150: Quality assessment for a single list item."""
    specificity_score: float = 0.0    # Item 136
    actionability_score: float = 0.0  # Item 137
    has_effort_estimate: bool = False  # Item 138
    has_priority: bool = False         # Item 139
    has_impact: bool = False           # Item 140
    has_dependencies: bool = False     # Item 141
    is_quick_win: bool = False         # Item 142
    has_risk_assessment: bool = False  # Item 143
    has_complexity: bool = False       # Item 144
    has_category: bool = False         # Item 145
    has_severity: bool = False         # Item 146
    has_blast_radius: bool = False     # Item 147
    has_prerequisites: bool = False    # Item 148
    has_success_criteria: bool = False # Item 149
    has_verification: bool = False     # Item 150


class ListQualityValidator:
    """
    Items 136-150: Validates and scores list item quality.
    """

    # Item 137: Action words that indicate actionability
    ACTION_WORDS = [
        "add", "remove", "fix", "implement", "refactor", "update",
        "replace", "migrate", "upgrade", "create", "delete", "modify",
        "configure", "enable", "disable", "optimize", "simplify"
    ]

    def assess_item(self, item: ListItem) -> ListItemQuality:
        """Assess quality of a single list item."""
        quality = ListItemQuality()

        # Item 136: Specificity (has file path and line number)
        if item.file_path:
            quality.specificity_score += 0.5
            if item.line_number:
                quality.specificity_score += 0.5

        # Item 137: Actionability (starts with action verb)
        title_lower = item.title.lower()
        if any(title_lower.startswith(word) for word in self.ACTION_WORDS):
            quality.actionability_score = 1.0
        elif any(word in title_lower for word in self.ACTION_WORDS):
            quality.actionability_score = 0.5

        # Item 138: Effort estimate
        quality.has_effort_estimate = item.effort in ("low", "medium", "high")

        # Item 139: Priority
        quality.has_priority = item.priority in ("P0", "P1", "P2", "P3")

        # Item 140: Impact
        quality.has_impact = item.impact in ("low", "medium", "high")

        # Item 142: Quick win detection
        quality.is_quick_win = (
            item.effort == "low" and item.impact in ("medium", "high")
        )

        # Item 145: Category
        quality.has_category = bool(item.category)

        # Item 146: Severity (via priority)
        quality.has_severity = item.priority in ("P0", "P1")

        return quality

    def assess_list(self, items: list[ListItem]) -> dict:
        """Assess quality of entire list."""
        if not items:
            return {"overall_score": 0, "issues": ["List is empty"]}

        qualities = [self.assess_item(item) for item in items]

        # Calculate averages
        avg_specificity = sum(q.specificity_score for q in qualities) / len(qualities)
        avg_actionability = sum(q.actionability_score for q in qualities) / len(qualities)
        has_effort_pct = sum(1 for q in qualities if q.has_effort_estimate) / len(qualities)
        has_priority_pct = sum(1 for q in qualities if q.has_priority) / len(qualities)
        has_category_pct = sum(1 for q in qualities if q.has_category) / len(qualities)
        quick_win_count = sum(1 for q in qualities if q.is_quick_win)

        # Overall score
        overall_score = (
            avg_specificity * 25 +
            avg_actionability * 25 +
            has_effort_pct * 15 +
            has_priority_pct * 15 +
            has_category_pct * 10 +
            min(10, quick_win_count)
        )

        # Identify issues
        issues = []
        if avg_specificity < 0.5:
            issues.append("Many items lack specific file references")
        if avg_actionability < 0.5:
            issues.append("Many items are not actionable (need action verbs)")
        if has_effort_pct < 0.8:
            issues.append("Some items missing effort estimates")
        if has_priority_pct < 0.9:
            issues.append("Some items missing priority")

        return {
            "overall_score": overall_score,
            "avg_specificity": avg_specificity,
            "avg_actionability": avg_actionability,
            "effort_coverage": has_effort_pct,
            "priority_coverage": has_priority_pct,
            "category_coverage": has_category_pct,
            "quick_wins": quick_win_count,
            "issues": issues
        }


# =============================================================================
# ITEMS 151-160: LIST FORMATTING
# =============================================================================

class ListFormatter:
    """
    Items 151-160: Formats lists for output.
    """

    @staticmethod
    def to_numbered_list(items: list[ListItem]) -> str:
        """Item 151: Format as numbered list."""
        return "\n\n".join(item.to_markdown() for item in items)

    @staticmethod
    def to_hierarchical_list(items: list[ListItem]) -> str:
        """Item 152: Format with category hierarchy."""
        by_category: dict[str, list[ListItem]] = {}
        for item in items:
            cat = item.category or "Uncategorized"
            if cat not in by_category:
                by_category[cat] = []
            by_category[cat].append(item)

        sections = []
        for category, cat_items in sorted(by_category.items()):
            section = [f"### {category} ({len(cat_items)} items)"]
            for item in cat_items:
                section.append(item.to_markdown())
            sections.append("\n".join(section))

        return "\n\n".join(sections)

    @staticmethod
    def to_table(items: list[ListItem]) -> str:
        """Item 153-154: Format as markdown table."""
        header = "| # | Priority | Issue | Location | Effort | Impact |"
        separator = "|---|----------|-------|----------|--------|--------|"

        rows = [header, separator]
        for item in items:
            rows.append(item.to_table_row())

        return "\n".join(rows)

    @staticmethod
    def add_summary_statistics(items: list[ListItem]) -> str:
        """Item 155: Add summary statistics."""
        if not items:
            return "No items in list."

        # Count by priority
        by_priority = {"P0": 0, "P1": 0, "P2": 0, "P3": 0}
        for item in items:
            by_priority[item.priority] = by_priority.get(item.priority, 0) + 1

        # Count by effort
        by_effort = {"low": 0, "medium": 0, "high": 0}
        for item in items:
            by_effort[item.effort] = by_effort.get(item.effort, 0) + 1

        # Categories
        categories = set(item.category for item in items if item.category)

        summary = [
            "## Summary Statistics",
            f"- **Total items**: {len(items)}",
            "",
            "### By Priority",
            f"- P0 (Critical): {by_priority['P0']}",
            f"- P1 (High): {by_priority['P1']}",
            f"- P2 (Medium): {by_priority['P2']}",
            f"- P3 (Low): {by_priority['P3']}",
            "",
            "### By Effort",
            f"- Low effort: {by_effort['low']}",
            f"- Medium effort: {by_effort['medium']}",
            f"- High effort: {by_effort['high']}",
            "",
            f"### Categories covered: {len(categories)}",
            ", ".join(sorted(categories)) if categories else "None specified",
        ]

        return "\n".join(summary)

    @staticmethod
    def create_executive_summary(items: list[ListItem]) -> str:
        """Item 156: Create executive summary."""
        if not items:
            return "No items to summarize."

        critical = [i for i in items if i.priority == "P0"]
        high = [i for i in items if i.priority == "P1"]
        quick_wins = [i for i in items if i.effort == "low" and i.impact in ("medium", "high")]

        summary = [
            "## Executive Summary",
            "",
            f"Total items identified: **{len(items)}**",
            "",
        ]

        if critical:
            summary.append(f"### 🚨 Critical Issues ({len(critical)})")
            for item in critical[:5]:
                summary.append(f"- {item.title}")
            if len(critical) > 5:
                summary.append(f"- ... and {len(critical) - 5} more")
            summary.append("")

        if high:
            summary.append(f"### ⚠️ High Priority ({len(high)})")
            for item in high[:5]:
                summary.append(f"- {item.title}")
            if len(high) > 5:
                summary.append(f"- ... and {len(high) - 5} more")
            summary.append("")

        if quick_wins:
            summary.append(f"### 🎯 Quick Wins ({len(quick_wins)})")
            for item in quick_wins[:5]:
                summary.append(f"- {item.title}")
            summary.append("")

        return "\n".join(summary)

    @staticmethod
    def to_json(items: list[ListItem]) -> str:
        """Item 159: Export as JSON."""
        import json
        data = []
        for item in items:
            data.append({
                "number": item.number,
                "title": item.title,
                "description": item.description,
                "file_path": item.file_path,
                "line_number": item.line_number,
                "priority": item.priority,
                "category": item.category,
                "effort": item.effort,
                "impact": item.impact,
            })
        return json.dumps(data, indent=2)

    @staticmethod
    def to_csv(items: list[ListItem]) -> str:
        """Item 159: Export as CSV."""
        lines = ["Number,Priority,Title,File,Line,Category,Effort,Impact"]
        for item in items:
            line = [
                str(item.number),
                item.priority,
                f'"{item.title}"',
                item.file_path or "",
                str(item.line_number) if item.line_number else "",
                item.category,
                item.effort,
                item.impact,
            ]
            lines.append(",".join(line))
        return "\n".join(lines)


# =============================================================================
# COMBINED LIST GENERATOR
# =============================================================================

class ListGenerator:
    """
    Complete list generation system implementing Items 121-160.
    """

    def __init__(self, target_count: int = 100):
        self.builder = ProgressiveListBuilder(target_count)
        self.validator = ListQualityValidator()
        self.formatter = ListFormatter()

    def add_item(
        self,
        title: str,
        description: str = "",
        file_path: str | None = None,
        line_number: int | None = None,
        priority: str = "P2",
        category: str = "",
        effort: str = "medium",
        impact: str = "medium",
    ) -> bool:
        """Add an item to the list."""
        item = ListItem(
            number=0,  # Will be set by builder
            title=title,
            description=description,
            file_path=file_path,
            line_number=line_number,
            priority=priority,
            category=category,
            effort=effort,
            impact=impact,
        )
        return self.builder.add_item(item)

    def needs_more_items(self) -> bool:
        """Check if more items are needed."""
        return not self.builder.state.is_complete

    def get_continuation_prompt(self) -> str:
        """Get prompt to continue generation."""
        return self.builder.get_continuation_prompt()

    def validate_quality(self) -> dict:
        """Validate list quality."""
        return self.validator.assess_list(self.builder.state.items)

    def format_as_list(self) -> str:
        """Format as numbered list."""
        return self.formatter.to_numbered_list(self.builder.state.items)

    def format_as_table(self) -> str:
        """Format as table."""
        return self.formatter.to_table(self.builder.state.items)

    def format_hierarchical(self) -> str:
        """Format with category hierarchy."""
        return self.formatter.to_hierarchical_list(self.builder.state.items)

    def get_summary(self) -> str:
        """Get summary statistics."""
        return self.formatter.add_summary_statistics(self.builder.state.items)

    def get_executive_summary(self) -> str:
        """Get executive summary."""
        return self.formatter.create_executive_summary(self.builder.state.items)

    def export_json(self) -> str:
        """Export as JSON."""
        return self.formatter.to_json(self.builder.state.items)

    def export_csv(self) -> str:
        """Export as CSV."""
        return self.formatter.to_csv(self.builder.state.items)

    def get_complete_output(self, format_type: str = "list") -> str:
        """Get complete formatted output with summary."""
        parts = [self.get_executive_summary(), ""]

        if format_type == "table":
            parts.append(self.format_as_table())
        elif format_type == "hierarchical":
            parts.append(self.format_hierarchical())
        else:
            parts.append(self.format_as_list())

        parts.extend(["", self.get_summary()])

        quality = self.validate_quality()
        parts.extend([
            "",
            f"## Quality Score: {quality['overall_score']:.1f}/100",
        ])
        if quality["issues"]:
            parts.append("### Issues:")
            for issue in quality["issues"]:
                parts.append(f"- {issue}")

        return "\n".join(parts)


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_list_generator(target_count: int = 100) -> ListGenerator:
    """Create a new list generator."""
    return ListGenerator(target_count)


def parse_list_from_text(text: str) -> list[ListItem]:
    """Parse list items from model output text."""
    items = []

    # Pattern for numbered items
    pattern = r'^\s*(\d+)\.\s*\*?\*?\[?([P0-3]|HIGH|MEDIUM|LOW|CRITICAL)\]?\*?\*?\s*(.+?)$'

    for match in re.finditer(pattern, text, re.MULTILINE):
        number = int(match.group(1))
        priority_raw = match.group(2).upper()
        title = match.group(3).strip()

        # Normalize priority
        priority_map = {
            "CRITICAL": "P0", "HIGH": "P1", "MEDIUM": "P2", "LOW": "P3",
            "P0": "P0", "P1": "P1", "P2": "P2", "P3": "P3"
        }
        priority = priority_map.get(priority_raw, "P2")

        # Try to extract file path
        file_match = re.search(r'`([^`]+\.\w+)(?::(\d+))?`', title)
        file_path = file_match.group(1) if file_match else None
        line_number = int(file_match.group(2)) if file_match and file_match.group(2) else None

        items.append(ListItem(
            number=number,
            title=title,
            description="",
            file_path=file_path,
            line_number=line_number,
            priority=priority,
        ))

    return items
