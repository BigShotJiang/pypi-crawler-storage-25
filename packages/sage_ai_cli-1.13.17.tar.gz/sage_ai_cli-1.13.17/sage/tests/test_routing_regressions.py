"""Regression tests for analysis routing and smart read behavior."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from sage.core.request_classifier import ClassifiedRequest, OutputFormat, PipelineType, RequestType
from sage.core.tool_orchestrator import FileReadStrategy, ReadRequest, SmartFileReader
from sage.main import (
    _build_multistep_phase_prompts,
    _build_tool_followup_prompt,
    _should_use_multistep_pipeline,
)


def _make_classification(request_type: RequestType, text: str) -> ClassifiedRequest:
    """Create a classified request using the same defaults as runtime classification."""
    return ClassifiedRequest(
        original_request=text,
        request_type=request_type,
        expected_format=OutputFormat.MARKDOWN_LIST,
        pipeline_type=PipelineType.SIMPLE_RESPONSE,
    )


def test_readonly_list_generation_uses_analysis_multistep_pipeline():
    """Complex audits should still use the model, but with analysis-only phases."""
    classification = _make_classification(
        RequestType.LIST_GENERATION,
        "Analyze this codebase and list 100 improvements by priority",
    )

    assert classification.read_only is True
    assert _should_use_multistep_pipeline(
        classification.original_request,
        classification=classification,
        is_local_model=True,
    ) is True

    steps = _build_multistep_phase_prompts(classification.original_request, classification)

    assert [phase for phase, _ in steps] == ["planning", "analysis", "synthesis"]
    assert all("write the test files" not in prompt.lower() for _, prompt in steps)
    assert all("do not write code" in prompt.lower() for _, prompt in steps)


def test_complex_local_implementation_can_still_use_multistep_pipeline():
    """Local complex implementation requests should still benefit from decomposition."""
    classification = _make_classification(
        RequestType.IMPLEMENTATION,
        "Implement auth retry handling and refactor the token refresh flow with tests",
    )

    assert classification.read_only is False
    assert _should_use_multistep_pipeline(
        classification.original_request,
        classification=classification,
        is_local_model=True,
    ) is True

    steps = _build_multistep_phase_prompts(classification.original_request, classification)

    assert [phase for phase, _ in steps] == ["planning", "testing", "implementation"]
    assert any("write the test files" in prompt.lower() for _, prompt in steps)


def test_readonly_tool_followup_prompt_stays_in_analysis_mode():
    """Tool follow-ups for audits should ask for findings, not FILE blocks."""
    classification = _make_classification(
        RequestType.ANALYSIS,
        "Audit the agent loop and explain what needs to be fixed",
    )

    prompt = _build_tool_followup_prompt("READ: main.py output", classification)

    assert "continue with your analysis" in prompt.lower()
    assert "file:" not in prompt.lower()
    assert "do not write writable file blocks" in prompt.lower()


def test_smart_read_without_focus_match_returns_truncated_fallback():
    """Smart reads should clearly signal fallback when the requested focus is absent."""
    reader = SmartFileReader(Path("."))

    result = reader.read(
        ReadRequest(
            file_path="pyproject.toml",
            strategy=FileReadStrategy.SMART,
            focus_pattern="definitely-not-present-pattern",
        )
    )

    assert result.truncated is True
    assert "no matches" in result.truncation_message.lower()
