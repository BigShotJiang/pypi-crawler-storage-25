"""WebSocket terminal handler for running sage-ai-cli in the browser.

Provides:
- PTY-based terminal emulation via WebSocket
- Auto-update checking and application for sage-ai-cli
- WebGL-accelerated rendering support via xterm.js
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import pty
import select
import shutil
import signal
import struct
import subprocess
import sys
import termios
import fcntl
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger("ai-platform.terminal")


@dataclass
class CLIVersion:
    """Version info for sage-ai-cli."""
    current: str
    latest: str
    update_available: bool


class CLIAutoUpdater:
    """Handles auto-update checking and application for sage-ai-cli."""

    PACKAGE_NAME = "sage-ai-cli"

    def __init__(self):
        self._cache_timeout = 300  # 5 minutes
        self._last_check: float = 0
        self._cached_version: CLIVersion | None = None

    def get_current_version(self) -> str:
        """Get currently installed sage-ai-cli version."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", self.PACKAGE_NAME],
                capture_output=True,
                text=True,
                timeout=10,
            )
            for line in result.stdout.split("\n"):
                if line.startswith("Version:"):
                    return line.split(":", 1)[1].strip()
        except Exception as e:
            logger.warning("Failed to get current version: %s", e)
        return "0.0.0"

    def get_latest_version(self) -> str:
        """Check PyPI for latest sage-ai-cli version."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "index", "versions", self.PACKAGE_NAME],
                capture_output=True,
                text=True,
                timeout=30,
            )
            # Parse output like "sage-ai-cli (1.13.11)"
            if "(" in result.stdout:
                version = result.stdout.split("(")[1].split(")")[0].strip()
                return version
        except Exception as e:
            logger.warning("Failed to check latest version: %s", e)
        return self.get_current_version()

    def check_for_update(self, force: bool = False) -> CLIVersion:
        """Check if an update is available."""
        import time

        now = time.time()
        if not force and self._cached_version and (now - self._last_check) < self._cache_timeout:
            return self._cached_version

        current = self.get_current_version()
        latest = self.get_latest_version()
        update_available = self._compare_versions(current, latest) < 0

        self._cached_version = CLIVersion(
            current=current,
            latest=latest,
            update_available=update_available,
        )
        self._last_check = now
        return self._cached_version

    def apply_update(self) -> bool:
        """Apply the update by upgrading sage-ai-cli."""
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "--upgrade", self.PACKAGE_NAME],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                # Clear cache to force re-check
                self._cached_version = None
                self._last_check = 0
                logger.info("Successfully updated %s", self.PACKAGE_NAME)
                return True
            logger.error("Update failed: %s", result.stderr)
        except Exception as e:
            logger.error("Failed to apply update: %s", e)
        return False

    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """Compare two version strings. Returns -1 if v1 < v2, 0 if equal, 1 if v1 > v2."""
        def parse(v: str) -> tuple[int, ...]:
            parts = []
            for p in v.replace("-", ".").split("."):
                try:
                    parts.append(int(p))
                except ValueError:
                    parts.append(0)
            return tuple(parts)

        p1, p2 = parse(v1), parse(v2)
        if p1 < p2:
            return -1
        elif p1 > p2:
            return 1
        return 0


class TerminalSession:
    """Manages a PTY session for a WebSocket connection."""

    def __init__(self, websocket: WebSocket):
        self.websocket = websocket
        self.master_fd: int | None = None
        self.pid: int | None = None
        self._running = False
        self._read_task: asyncio.Task | None = None

    async def start(self, command: list[str] | None = None):
        """Start the terminal session with sage-ai-cli."""
        if command is None:
            # Default to sage-ai-cli or fallback to bash
            sage_cli = shutil.which("sage")
            if sage_cli:
                command = [sage_cli]
            else:
                # Try running as Python module
                command = [sys.executable, "-m", "sage"]

        # Create PTY
        pid, master_fd = pty.fork()

        if pid == 0:
            # Child process
            os.environ["TERM"] = "xterm-256color"
            os.environ["COLORTERM"] = "truecolor"
            os.environ["SAGE_TERMINAL"] = "web"
            try:
                os.execvp(command[0], command)
            except Exception:
                # Fallback to bash if sage not found
                os.execvp("/bin/bash", ["/bin/bash"])
        else:
            # Parent process
            self.pid = pid
            self.master_fd = master_fd
            self._running = True

            # Set non-blocking
            flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
            fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

            # Start reading task
            self._read_task = asyncio.create_task(self._read_loop())

    async def _read_loop(self):
        """Read output from PTY and send to WebSocket."""
        loop = asyncio.get_event_loop()

        while self._running and self.master_fd is not None:
            try:
                # Use select with timeout to check for data
                readable, _, _ = select.select([self.master_fd], [], [], 0.1)

                if readable:
                    try:
                        data = os.read(self.master_fd, 4096)
                        if data:
                            await self.websocket.send_json({
                                "type": "output",
                                "data": data.decode("utf-8", errors="replace"),
                            })
                        else:
                            # EOF
                            break
                    except OSError:
                        break
                else:
                    # No data, yield to event loop
                    await asyncio.sleep(0.01)

            except Exception as e:
                logger.error("Error in read loop: %s", e)
                break

        self._running = False

    async def write(self, data: str):
        """Write input to the PTY."""
        if self.master_fd is not None:
            try:
                os.write(self.master_fd, data.encode("utf-8"))
            except OSError as e:
                logger.error("Error writing to PTY: %s", e)

    async def resize(self, cols: int, rows: int):
        """Resize the PTY window."""
        if self.master_fd is not None:
            try:
                winsize = struct.pack("HHHH", rows, cols, 0, 0)
                fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, winsize)
            except OSError as e:
                logger.error("Error resizing PTY: %s", e)

    async def stop(self):
        """Stop the terminal session."""
        self._running = False

        if self._read_task:
            self._read_task.cancel()
            try:
                await self._read_task
            except asyncio.CancelledError:
                pass

        if self.pid is not None:
            try:
                os.kill(self.pid, signal.SIGTERM)
                os.waitpid(self.pid, os.WNOHANG)
            except OSError:
                pass

        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass


# Global auto-updater instance
cli_updater = CLIAutoUpdater()


async def terminal_websocket_handler(websocket: WebSocket):
    """Handle WebSocket connection for terminal."""
    await websocket.accept()

    session = TerminalSession(websocket)

    try:
        # Check for updates and notify client
        version_info = cli_updater.check_for_update()
        if version_info.update_available:
            await websocket.send_json({
                "type": "update_available",
                "info": {
                    "current_version": version_info.current,
                    "latest_version": version_info.latest,
                },
            })

        # Start terminal session
        await session.start()

        # Handle incoming messages
        while True:
            try:
                message = await websocket.receive_json()
                msg_type = message.get("type")

                if msg_type == "input":
                    await session.write(message.get("data", ""))
                elif msg_type == "resize":
                    cols = message.get("cols", 80)
                    rows = message.get("rows", 24)
                    await session.resize(cols, rows)

            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error("Error handling message: %s", e)
                break

    finally:
        await session.stop()


def get_cli_update_info() -> dict[str, Any]:
    """Get CLI update information for REST API."""
    version_info = cli_updater.check_for_update()
    return {
        "current_version": version_info.current,
        "latest_version": version_info.latest,
        "update_available": version_info.update_available,
    }


def apply_cli_update() -> dict[str, Any]:
    """Apply CLI update via REST API."""
    success = cli_updater.apply_update()
    version_info = cli_updater.check_for_update(force=True)
    return {
        "ok": success,
        "current_version": version_info.current,
        "latest_version": version_info.latest,
    }
