#!/usr/bin/env python3

"""Unit tests for skilleter_readable.readable."""

import io
import os
import re
import sys
import types
import unittest

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
PARENT_DIR = os.path.abspath(os.path.join(ROOT_DIR, '..'))
SKILLETER_MODULES_DIR = os.path.join(PARENT_DIR, 'skilleter-modules')
SKILLETER_MODULES_SRC_DIR = os.path.join(SKILLETER_MODULES_DIR, 'src')
for path in (ROOT_DIR, PARENT_DIR, SKILLETER_MODULES_DIR, SKILLETER_MODULES_SRC_DIR):
	if path not in sys.path:
		sys.path.insert(0, path)

if 'skilleter_modules' not in sys.modules:
	try:
		import skilleter_modules  # noqa: F401
	except ModuleNotFoundError:
		stub_module = types.ModuleType('skilleter_modules')
		stub_module.tidy = types.SimpleNamespace(
			debug_format=lambda text: text,
			convert_ansi=lambda text, _light: text,
			remove_ansi=lambda text: text,
			remove_sha256=lambda text: text,
			remove_sha1=lambda text: text,
			remove_times=lambda text: text,
			remove_speeds=lambda text: text,
			remove_aws_ids=lambda text: text,
			regex_replace=lambda text, _replacements: text,
		)
		stub_module.files = types.SimpleNamespace(backup=lambda _path: None)
		sys.modules['skilleter_modules'] = stub_module

import skilleter_readable.readable as readable


class _StubTidy:
	"""Lightweight stand-in for tidy helpers used in tests."""

	@staticmethod
	def debug_format(text):
		return text

	@staticmethod
	def convert_ansi(text, _light):
		return text

	@staticmethod
	def remove_ansi(text):
		return text

	@staticmethod
	def remove_sha256(text):
		return text

	@staticmethod
	def remove_sha1(text):
		return text

	@staticmethod
	def remove_times(text):
		return text

	@staticmethod
	def remove_speeds(text):
		return text

	@staticmethod
	def remove_aws_ids(text):
		return text

	@staticmethod
	def regex_replace(text, _replacements):
		return text


class CleanfileTests(unittest.TestCase):
	def setUp(self):
		self._orig_tidy = readable.tidy
		readable.tidy = _StubTidy()

	def tearDown(self):
		readable.tidy = self._orig_tidy

	def test_collection_flushes_at_eof(self):
		args = types.SimpleNamespace(
			debug=False,
			light=False,
			dark=False,
			none=False,
			tidy=False,
			aws=False,
			replace=False,
			regex_replace=[],
			minimal=True,
			terraform=True,
			strip_blank=False,
		)

		src = io.StringIO('Fetching tool 1.0\n')
		dst = io.StringIO()

		readable.cleanfile(args, src, dst)

		self.assertEqual(dst.getvalue(), 'Fetching tool 1.0\n')

	def test_trailing_whitespace_removed_after_replacements(self):
		args = types.SimpleNamespace(
			debug=False,
			light=False,
			dark=False,
			none=False,
			tidy=False,
			aws=False,
			replace=True,
			regex_replace=[{'regex': re.compile('foo'), 'replace': 'bar   '}],
			minimal=False,
			terraform=False,
			strip_blank=False,
		)

		src = io.StringIO('foo\n')
		dst = io.StringIO()

		readable.cleanfile(args, src, dst)

		self.assertEqual(dst.getvalue(), 'bar\n')

	def test_minimal_removes_refreshing_lines(self):
		args = types.SimpleNamespace(
			debug=False,
			light=False,
			dark=False,
			none=False,
			tidy=False,
			aws=False,
			replace=False,
			regex_replace=[],
			minimal=True,
			terraform=True,
			strip_blank=False,
		)

		src = io.StringIO('module.foo: Refreshing state...\nOK\n')
		dst = io.StringIO()

		readable.cleanfile(args, src, dst)

		self.assertEqual(dst.getvalue(), 'OK\n')

	def test_collection_sorted_before_normal_lines(self):
		args = types.SimpleNamespace(
			debug=False,
			light=False,
			dark=False,
			none=False,
			tidy=False,
			aws=False,
			replace=False,
			regex_replace=[],
			minimal=True,
			terraform=True,
			strip_blank=False,
		)

		src = io.StringIO('Fetching tool 2.0\nFetching tool 1.0\nDone\n')
		dst = io.StringIO()

		readable.cleanfile(args, src, dst)

		self.assertEqual(dst.getvalue(), 'Fetching tool 1.0\nFetching tool 2.0\nDone\n')

	def test_strip_blank_removes_all_blank_lines(self):
		args = types.SimpleNamespace(
			debug=False,
			light=False,
			dark=False,
			none=False,
			tidy=False,
			aws=False,
			replace=False,
			regex_replace=[],
			minimal=False,
			terraform=False,
			strip_blank=True,
		)

		src = io.StringIO('A\n\n\nB\n')
		dst = io.StringIO()

		readable.cleanfile(args, src, dst)

		self.assertEqual(dst.getvalue(), 'A\nB\n')

	def test_blank_lines_collapsed_when_strip_blank_disabled(self):
		args = types.SimpleNamespace(
			debug=False,
			light=False,
			dark=False,
			none=False,
			tidy=False,
			aws=False,
			replace=False,
			regex_replace=[],
			minimal=False,
			terraform=False,
			strip_blank=False,
		)

		src = io.StringIO('A\n\n\nB\n')
		dst = io.StringIO()

		readable.cleanfile(args, src, dst)

		self.assertEqual(dst.getvalue(), 'A\n\nB\n')


class ParseCommandLineTests(unittest.TestCase):
	def _run_with_argv(self, argv):
		old_argv = sys.argv
		try:
			sys.argv = argv
			return readable.parse_command_line()
		finally:
			sys.argv = old_argv

	def test_replace_allows_equals_in_replacement(self):
		args = self._run_with_argv(['prog', '--replace', 'foo=bar=baz'])
		self.assertEqual(args.regex_replace[0]['replace'], 'bar=baz')

	def test_minimal_implies_terraform(self):
		args = self._run_with_argv(['prog', '--minimal'])
		self.assertTrue(args.terraform)


if __name__ == '__main__':
	unittest.main()
