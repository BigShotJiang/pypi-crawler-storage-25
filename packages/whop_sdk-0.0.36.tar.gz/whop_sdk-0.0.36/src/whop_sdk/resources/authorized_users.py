# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Optional
from datetime import datetime

import httpx

from ..types import authorized_user_list_params, authorized_user_create_params, authorized_user_delete_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursorPage, AsyncCursorPage
from .._base_client import AsyncPaginator, make_request_options
from ..types.authorized_user import AuthorizedUser
from ..types.shared.authorized_user_roles import AuthorizedUserRoles
from ..types.authorized_user_list_response import AuthorizedUserListResponse
from ..types.authorized_user_delete_response import AuthorizedUserDeleteResponse

__all__ = ["AuthorizedUsersResource", "AsyncAuthorizedUsersResource"]


class AuthorizedUsersResource(SyncAPIResource):
    """Authorized users"""

    @cached_property
    def with_raw_response(self) -> AuthorizedUsersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/whopio/whopsdk-python#accessing-raw-response-data-eg-headers
        """
        return AuthorizedUsersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AuthorizedUsersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/whopio/whopsdk-python#with_streaming_response
        """
        return AuthorizedUsersResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        company_id: str,
        role: AuthorizedUserRoles,
        user_id: str,
        send_emails: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthorizedUser:
        """
        Add a new authorized user to a company.

        Required permissions:

        - `authorized_user:create`
        - `member:email:read`

        Args:
          company_id: The ID of the company to add the authorized user to.

          role:
              The role to assign to the authorized user within the company. Supported roles:
              'moderator', 'sales_manager'.

          user_id: The ID of the user to add as an authorized user.

          send_emails: Whether to send notification emails to the user on creation.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/authorized_users",
            body=maybe_transform(
                {
                    "company_id": company_id,
                    "role": role,
                    "user_id": user_id,
                    "send_emails": send_emails,
                },
                authorized_user_create_params.AuthorizedUserCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthorizedUser,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthorizedUser:
        """
        Retrieves the details of an existing authorized user.

        Required permissions:

        - `company:authorized_user:read`
        - `member:email:read`

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/authorized_users/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthorizedUser,
        )

    def list(
        self,
        *,
        after: Optional[str] | Omit = omit,
        before: Optional[str] | Omit = omit,
        company_id: Optional[str] | Omit = omit,
        created_after: Union[str, datetime, None] | Omit = omit,
        created_before: Union[str, datetime, None] | Omit = omit,
        first: Optional[int] | Omit = omit,
        last: Optional[int] | Omit = omit,
        role: Optional[AuthorizedUserRoles] | Omit = omit,
        user_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursorPage[AuthorizedUserListResponse]:
        """
        Returns a paginated list of authorized team members for a company, with optional
        filtering by user, role, and creation date.

        Required permissions:

        - `company:authorized_user:read`
        - `member:email:read`

        Args:
          after: Returns the elements in the list that come after the specified cursor.

          before: Returns the elements in the list that come before the specified cursor.

          company_id: The unique identifier of the company to list authorized users for.

          created_after: Only return authorized users created after this timestamp.

          created_before: Only return authorized users created before this timestamp.

          first: Returns the first _n_ elements from the list.

          last: Returns the last _n_ elements from the list.

          role: Possible roles an authorized user can have

          user_id: Filter results to a specific user to check if they are an authorized team
              member.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/authorized_users",
            page=SyncCursorPage[AuthorizedUserListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "company_id": company_id,
                        "created_after": created_after,
                        "created_before": created_before,
                        "first": first,
                        "last": last,
                        "role": role,
                        "user_id": user_id,
                    },
                    authorized_user_list_params.AuthorizedUserListParams,
                ),
            ),
            model=AuthorizedUserListResponse,
        )

    def delete(
        self,
        id: str,
        *,
        company_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthorizedUserDeleteResponse:
        """
        Remove an authorized user from a company.

        Required permissions:

        - `authorized_user:delete`

        Args:
          company_id: The ID of the company the authorized user belongs to. Optional if the authorized
              user ID is provided.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._delete(
            path_template("/authorized_users/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"company_id": company_id}, authorized_user_delete_params.AuthorizedUserDeleteParams
                ),
            ),
            cast_to=AuthorizedUserDeleteResponse,
        )


class AsyncAuthorizedUsersResource(AsyncAPIResource):
    """Authorized users"""

    @cached_property
    def with_raw_response(self) -> AsyncAuthorizedUsersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/whopio/whopsdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncAuthorizedUsersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAuthorizedUsersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/whopio/whopsdk-python#with_streaming_response
        """
        return AsyncAuthorizedUsersResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        company_id: str,
        role: AuthorizedUserRoles,
        user_id: str,
        send_emails: Optional[bool] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthorizedUser:
        """
        Add a new authorized user to a company.

        Required permissions:

        - `authorized_user:create`
        - `member:email:read`

        Args:
          company_id: The ID of the company to add the authorized user to.

          role:
              The role to assign to the authorized user within the company. Supported roles:
              'moderator', 'sales_manager'.

          user_id: The ID of the user to add as an authorized user.

          send_emails: Whether to send notification emails to the user on creation.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/authorized_users",
            body=await async_maybe_transform(
                {
                    "company_id": company_id,
                    "role": role,
                    "user_id": user_id,
                    "send_emails": send_emails,
                },
                authorized_user_create_params.AuthorizedUserCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthorizedUser,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthorizedUser:
        """
        Retrieves the details of an existing authorized user.

        Required permissions:

        - `company:authorized_user:read`
        - `member:email:read`

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/authorized_users/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AuthorizedUser,
        )

    def list(
        self,
        *,
        after: Optional[str] | Omit = omit,
        before: Optional[str] | Omit = omit,
        company_id: Optional[str] | Omit = omit,
        created_after: Union[str, datetime, None] | Omit = omit,
        created_before: Union[str, datetime, None] | Omit = omit,
        first: Optional[int] | Omit = omit,
        last: Optional[int] | Omit = omit,
        role: Optional[AuthorizedUserRoles] | Omit = omit,
        user_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[AuthorizedUserListResponse, AsyncCursorPage[AuthorizedUserListResponse]]:
        """
        Returns a paginated list of authorized team members for a company, with optional
        filtering by user, role, and creation date.

        Required permissions:

        - `company:authorized_user:read`
        - `member:email:read`

        Args:
          after: Returns the elements in the list that come after the specified cursor.

          before: Returns the elements in the list that come before the specified cursor.

          company_id: The unique identifier of the company to list authorized users for.

          created_after: Only return authorized users created after this timestamp.

          created_before: Only return authorized users created before this timestamp.

          first: Returns the first _n_ elements from the list.

          last: Returns the last _n_ elements from the list.

          role: Possible roles an authorized user can have

          user_id: Filter results to a specific user to check if they are an authorized team
              member.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/authorized_users",
            page=AsyncCursorPage[AuthorizedUserListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "after": after,
                        "before": before,
                        "company_id": company_id,
                        "created_after": created_after,
                        "created_before": created_before,
                        "first": first,
                        "last": last,
                        "role": role,
                        "user_id": user_id,
                    },
                    authorized_user_list_params.AuthorizedUserListParams,
                ),
            ),
            model=AuthorizedUserListResponse,
        )

    async def delete(
        self,
        id: str,
        *,
        company_id: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AuthorizedUserDeleteResponse:
        """
        Remove an authorized user from a company.

        Required permissions:

        - `authorized_user:delete`

        Args:
          company_id: The ID of the company the authorized user belongs to. Optional if the authorized
              user ID is provided.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._delete(
            path_template("/authorized_users/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"company_id": company_id}, authorized_user_delete_params.AuthorizedUserDeleteParams
                ),
            ),
            cast_to=AuthorizedUserDeleteResponse,
        )


class AuthorizedUsersResourceWithRawResponse:
    def __init__(self, authorized_users: AuthorizedUsersResource) -> None:
        self._authorized_users = authorized_users

        self.create = to_raw_response_wrapper(
            authorized_users.create,
        )
        self.retrieve = to_raw_response_wrapper(
            authorized_users.retrieve,
        )
        self.list = to_raw_response_wrapper(
            authorized_users.list,
        )
        self.delete = to_raw_response_wrapper(
            authorized_users.delete,
        )


class AsyncAuthorizedUsersResourceWithRawResponse:
    def __init__(self, authorized_users: AsyncAuthorizedUsersResource) -> None:
        self._authorized_users = authorized_users

        self.create = async_to_raw_response_wrapper(
            authorized_users.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            authorized_users.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            authorized_users.list,
        )
        self.delete = async_to_raw_response_wrapper(
            authorized_users.delete,
        )


class AuthorizedUsersResourceWithStreamingResponse:
    def __init__(self, authorized_users: AuthorizedUsersResource) -> None:
        self._authorized_users = authorized_users

        self.create = to_streamed_response_wrapper(
            authorized_users.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            authorized_users.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            authorized_users.list,
        )
        self.delete = to_streamed_response_wrapper(
            authorized_users.delete,
        )


class AsyncAuthorizedUsersResourceWithStreamingResponse:
    def __init__(self, authorized_users: AsyncAuthorizedUsersResource) -> None:
        self._authorized_users = authorized_users

        self.create = async_to_streamed_response_wrapper(
            authorized_users.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            authorized_users.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            authorized_users.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            authorized_users.delete,
        )
