# Copyright 2017 Cisco Systems, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


"""Add hostid as primary key to mapping table

Revision ID: 6454463cea8b
Revises: 73c84db9f299
Create Date: 2017-12-01 18:48:03.531425

"""

# revision identifiers, used by Alembic.
revision = '6454463cea8b'
down_revision = '73c84db9f299'


def upgrade():
    pass
