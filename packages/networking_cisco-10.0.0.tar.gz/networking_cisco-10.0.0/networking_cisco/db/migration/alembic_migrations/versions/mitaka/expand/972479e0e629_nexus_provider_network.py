# Copyright 2017 Cisco Systems, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.


"""nexus_provider_network

Revision ID: 972479e0e629
Revises: f3765e42de23
Create Date: 2017-05-02 15:11:15.280677

"""

# revision identifiers, used by Alembic.
revision = '972479e0e629'
down_revision = 'f3765e42de23'


def upgrade():
    pass
