# Copyright PolyAI Limited
# flake8: noqa
# ruff: noqa
# type: ignore
__all__ = ["ConversationLogger"]


class ConversationLogger:
    """Logging utility for Conversation objects"""

    def __init__(self) -> None: ...
    def info(self, content: str, is_pii: bool = ..., **kwargs: object) -> None: ...
    def warning(self, content: str, is_pii: bool = ..., **kwargs: object) -> None: ...
    def error(self, content: str, is_pii: bool = ..., **kwargs: object) -> None: ...
