######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.27                                                                                #
# Generated on 2026-05-06T15:46:29.996001                                                            #
######################################################################################################

from __future__ import annotations



class EventBridgeClient(object, metaclass=type):
    def __init__(self, name):
        ...
    def cron(self, cron):
        ...
    def role_arn(self, role_arn):
        ...
    def state_machine_arn(self, state_machine_arn):
        ...
    def schedule(self):
        ...
    def delete(self):
        ...
    ...

def format(name):
    ...

