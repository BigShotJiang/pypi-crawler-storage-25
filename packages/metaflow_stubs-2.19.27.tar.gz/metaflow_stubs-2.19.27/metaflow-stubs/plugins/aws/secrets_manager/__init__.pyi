######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.27                                                                                #
# Generated on 2026-05-06T15:46:29.947959                                                            #
######################################################################################################

from __future__ import annotations


from . import aws_secrets_manager_secrets_provider as aws_secrets_manager_secrets_provider

