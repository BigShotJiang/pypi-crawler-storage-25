######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.27                                                                                #
# Generated on 2026-05-06T15:46:29.966676                                                            #
######################################################################################################

from __future__ import annotations



class GcpDefaultClientProvider(object, metaclass=type):
    @staticmethod
    def get_gs_storage_client(*args, **kwargs):
        ...
    @staticmethod
    def get_credentials(scopes, *args, **kwargs):
        ...
    ...

cached_provider_class: None

def get_gs_storage_client():
    ...

def get_credentials(scopes, *args, **kwargs):
    ...

