######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.27                                                                                #
# Generated on 2026-05-06T15:46:29.966818                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.exception

from ...exception import MetaflowException as MetaflowException

class MetaflowGSPackageError(metaflow.exception.MetaflowException, metaclass=type):
    ...

