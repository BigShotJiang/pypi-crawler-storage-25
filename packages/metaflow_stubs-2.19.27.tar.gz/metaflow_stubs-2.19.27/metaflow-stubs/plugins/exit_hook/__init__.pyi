######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.27                                                                                #
# Generated on 2026-05-06T15:46:29.934576                                                            #
######################################################################################################

from __future__ import annotations


from . import exit_hook_decorator as exit_hook_decorator

