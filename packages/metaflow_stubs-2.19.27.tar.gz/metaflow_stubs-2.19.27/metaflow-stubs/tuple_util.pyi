######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.27                                                                                #
# Generated on 2026-05-06T15:46:29.895352                                                            #
######################################################################################################

from __future__ import annotations



def namedtuple_with_defaults(typename, field_descr, defaults = ()):
    ...

foreach_frame_field_list: list

