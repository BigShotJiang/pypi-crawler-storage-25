//! Imagery analysis algorithms
//!
//! Algorithms for remote sensing and spectral analysis:
//! - Spectral indices: NDVI, NDWI, SAVI, EVI, MNDWI, NBR, BSI
//! - Normalized difference: generic two-band index
//! - Band math: arbitrary raster algebra expressions
//! - Reclassify: value-based reclassification

mod band_math;
mod change_detection;
mod cloud_mask;
mod composite;
mod index_builder;
mod indices;
mod burn_severity;
mod reclassify;

pub use band_math::{band_math, band_math_binary, BandMathOp};
pub use change_detection::{
    change_vector_analysis, raster_difference, RasterDiffParams, CHANGE_DECREASE,
    CHANGE_INCREASE, CHANGE_NO_CHANGE,
};
pub use cloud_mask::{
    cloud_mask_scl, CloudMaskStrategy, S2SclMask, LandsatQaMask, NoCloudMask, SCL_VALID_DEFAULT,
};
pub use composite::median_composite;
pub use index_builder::index_builder;
pub use indices::{
    bsi, evi, evi2, gndvi, mndwi, msavi, nbr, ndbi, ndmi, ndre, ndsi, ndvi, ndwi, ngrdi,
    normalized_difference, reci, savi, EviParams, SaviParams, SpectralIndex,
};
pub use reclassify::{reclassify, ReclassEntry, ReclassifyParams};
pub use burn_severity::{dnbr, burn_severity_classify};
