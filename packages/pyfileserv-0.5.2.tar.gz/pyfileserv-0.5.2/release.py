#!/usr/bin/env python3
"""一键打包发布到 PyPI

使用方法:
    python release.py              # 发布到 PyPI
    python release.py --test       # 发布到 TestPyPI
    python release.py --skip-test  # 跳过测试直接发布
"""
import argparse
import subprocess
import sys
from pathlib import Path


def run_command(cmd: list[str], description: str) -> bool:
    """运行命令并返回是否成功"""
    print(f"\n{'='*60}")
    print(f"📦 {description}")
    print(f"{'='*60}")
    print(f"执行: {' '.join(cmd)}")
    print()

    result = subprocess.run(cmd, cwd=Path(__file__).parent)
    return result.returncode == 0


def clean_build_files() -> None:
    """清理构建产物"""
    import shutil

    project_dir = Path(__file__).parent
    dirs_to_clean = ["dist", "build", "*.egg-info"]

    print("\n🧹 清理构建产物...")
    for pattern in dirs_to_clean:
        for path in project_dir.glob(pattern):
            if path.is_dir():
                shutil.rmtree(path)
                print(f"   删除: {path}")
            elif path.is_file():
                path.unlink()
                print(f"   删除: {path}")


def main():
    parser = argparse.ArgumentParser(
        description="一键打包发布到 PyPI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
    python release.py              # 发布到 PyPI
    python release.py --test       # 发布到 TestPyPI (测试)
    python release.py --skip-test  # 跳过测试直接发布
        """
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="发布到 TestPyPI 而非 PyPI"
    )
    parser.add_argument(
        "--skip-test",
        action="store_true",
        help="跳过运行测试"
    )
    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("🚀 PyPI 发布脚本")
    print("=" * 60)

    # 1. 清理旧构建
    clean_build_files()

    # 2. 运行测试
    if not args.skip_test:
        if not run_command(
            [sys.executable, "-m", "pytest", "tests/", "-v"],
            "运行测试"
        ):
            print("\n❌ 测试失败，请修复后再发布")
            sys.exit(1)
    else:
        print("\n⏭️  跳过测试")

    # 3. 构建
    if not run_command(
        [sys.executable, "-m", "build"],
        "构建包"
    ):
        print("\n❌ 构建失败")
        sys.exit(1)

    # 4. 上传
    twine_args = [
        sys.executable, "-m", "twine", "upload",
        "--disable-progress-bar",
        "dist/*",
        "--verbose",
    ]

    if args.test:
        twine_args.extend(["--repository", "testpypi"])
        target = "TestPyPI"
    else:
        target = "PyPI"

    if not run_command(twine_args, f"上传到 {target}"):
        print(f"\n❌ 上传到 {target} 失败")
        sys.exit(1)

    # 5. 完成
    print("\n" + "=" * 60)
    print("✅ 发布成功!")
    print("=" * 60)

    if args.test:
        print("\n📦 TestPyPI 地址:")
        print("   https://test.pypi.org/project/pyfileserv/")
        print("\n安装测试命令:")
        print("   pip install --index-url https://test.pypi.org/simple/ pyfileserv")
    else:
        print("\n📦 PyPI 地址:")
        print("   https://pypi.org/project/pyfileserv/")
        print("\n安装命令:")
        print("   pip install pyfileserv")


if __name__ == "__main__":
    main()
