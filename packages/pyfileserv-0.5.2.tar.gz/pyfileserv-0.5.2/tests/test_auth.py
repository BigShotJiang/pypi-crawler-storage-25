"""认证模块测试"""
import pytest
from pathlib import Path

from file_server.auth import PasswordHasher, UserStore, SessionManager


class TestPasswordHasher:
    def test_hash_and_verify(self):
        hasher = PasswordHasher(rounds=4)  # 使用较少轮次加速测试
        password = "test_password_123"
        hashed = hasher.hash_password(password)

        assert hashed != password
        assert hasher.verify_password(password, hashed) is True
        assert hasher.verify_password("wrong_password", hashed) is False

    def test_different_salts(self):
        hasher = PasswordHasher(rounds=4)
        password = "same_password"
        hash1 = hasher.hash_password(password)
        hash2 = hasher.hash_password(password)

        # 相同密码应该产生不同的哈希值（因为盐不同）
        assert hash1 != hash2
        assert hasher.verify_password(password, hash1)
        assert hasher.verify_password(password, hash2)

    def test_empty_password(self):
        hasher = PasswordHasher(rounds=4)
        hashed = hasher.hash_password("")

        assert hasher.verify_password("", hashed) is True
        assert hasher.verify_password("a", hashed) is False


class TestUserStore:
    def test_load_empty_users(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        users = store.load_users()
        assert users == {}

    def test_save_and_load_users(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        test_users = {"test_user": {"password": "hashed_value"}}
        store.save_users(test_users)

        loaded = store.load_users()
        assert loaded == test_users

    def test_add_user(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        store.add_user("new_user", "hashed_password")

        assert store.user_exists("new_user")
        user_data = store.get_user("new_user")
        assert user_data["password"] == "hashed_password"

    def test_delete_user(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        store.add_user("to_delete", "hashed")
        assert store.user_exists("to_delete")

        result = store.delete_user("to_delete")
        assert result is True
        assert not store.user_exists("to_delete")

    def test_delete_nonexistent_user(self, tmp_path):
        users_file = tmp_path / "users.json"
        store = UserStore(users_file)

        result = store.delete_user("nonexistent")
        assert result is False


class TestSessionManager:
    def test_create_and_validate_session(self):
        manager = SessionManager(timeout_seconds=3600)

        session_id = manager.create_session("test_user")
        valid, username = manager.validate_session(session_id)

        assert valid is True
        assert username == "test_user"

    def test_invalid_session(self):
        manager = SessionManager()

        valid, username = manager.validate_session("invalid_id")

        assert valid is False
        assert username is None

    def test_destroy_session(self):
        manager = SessionManager()
        session_id = manager.create_session("test_user")

        username = manager.destroy_session(session_id)

        assert username == "test_user"
        valid, _ = manager.validate_session(session_id)
        assert valid is False

    def test_get_username(self):
        manager = SessionManager()
        session_id = manager.create_session("test_user")

        username = manager.get_username(session_id)
        assert username == "test_user"

        # 无效会话
        assert manager.get_username("invalid") is None
