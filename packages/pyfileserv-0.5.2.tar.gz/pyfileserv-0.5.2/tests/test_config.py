"""配置模块测试"""
from pathlib import Path

from file_server.config import ServerConfig


class TestServerConfig:
    def test_default_values(self):
        config = ServerConfig()

        assert config.port == 8000
        assert config.session_timeout == 3600
        assert config.bcrypt_rounds == 12
        assert config.users_file == "users.json"
        assert config.host == ""
        assert config.config_dir is None
        assert config.static_dir is None

    def test_get_users_file_path_default(self):
        config = ServerConfig()

        path = config.get_users_file_path()

        assert path == Path("users.json")

    def test_get_users_file_path_with_config_dir(self, tmp_path):
        config = ServerConfig(config_dir=tmp_path)

        path = config.get_users_file_path()

        assert path == tmp_path / "users.json"

    def test_from_args(self):
        config = ServerConfig.from_args(
            port=9000,
            directory="/tmp/files",
            config_dir="/etc/fileserver"
        )

        assert config.port == 9000
        assert config.serve_dir == Path("/tmp/files")
        assert config.config_dir == Path("/etc/fileserver")

    def test_from_args_with_defaults(self):
        config = ServerConfig.from_args()

        assert config.port == 8000
        assert config.serve_dir == Path(".")

    def test_custom_users_file(self):
        config = ServerConfig(users_file="custom_users.json")

        assert config.get_users_file_path() == Path("custom_users.json")

    def test_custom_timeout(self):
        config = ServerConfig(session_timeout=7200)

        assert config.session_timeout == 7200

    def test_custom_bcrypt_rounds(self):
        config = ServerConfig(bcrypt_rounds=10)

        assert config.bcrypt_rounds == 10
