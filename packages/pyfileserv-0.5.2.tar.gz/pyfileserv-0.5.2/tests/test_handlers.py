"""测试 HTTP 处理器模块"""
import platform
import sys
import tempfile
from pathlib import Path

import pytest

# 确保使用本地源代码
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from file_server.handlers import _is_safe_path


class TestIsSafePath:
    """测试路径安全验证函数"""

    def test_safe_path_inside_base(self):
        """测试基础目录内的路径是安全的"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "subdir" / "file.txt"
            # 创建文件
            target.parent.mkdir(parents=True, exist_ok=True)
            target.touch()

            assert _is_safe_path(base, target) is True

    def test_safe_path_direct_child(self):
        """测试直接子文件是安全的"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "file.txt"
            target.touch()

            assert _is_safe_path(base, target) is True

    def test_unsafe_path_traversal_parent(self):
        """测试路径遍历攻击 (../)"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 尝试访问父目录
            target = base / ".." / "etc" / "passwd"

            assert _is_safe_path(base, target) is False

    def test_unsafe_path_absolute_outside(self):
        """测试绝对路径访问外部目录"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 绝对路径到系统目录
            target = Path("/etc/passwd")

            assert _is_safe_path(base, target) is False

    def test_unsafe_path_deep_traversal(self):
        """测试多层路径遍历攻击"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "subdir" / ".." / ".." / ".." / "etc" / "passwd"

            assert _is_safe_path(base, target) is False

    @pytest.mark.skipif(platform.system() == "Windows", reason="Windows requires admin for symlinks")
    def test_safe_path_symlink_inside(self):
        """测试符号链接在基础目录内"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            real_file = base / "real.txt"
            real_file.touch()

            symlink = base / "link.txt"
            symlink.symlink_to(real_file)

            # 符号链接指向基础目录内的文件，应该是安全的
            assert _is_safe_path(base, symlink) is True

    def test_nonexistent_path(self):
        """测试不存在的路径"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            target = base / "nonexistent" / "file.txt"

            # 不存在的路径解析后仍在基础目录内，应该是安全的
            assert _is_safe_path(base, target) is True

    def test_base_dir_itself(self):
        """测试基础目录本身"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)

            # 基础目录本身是安全的
            assert _is_safe_path(base, base) is True

    def test_relative_path_with_dots(self):
        """测试包含点号的相对路径"""
        with tempfile.TemporaryDirectory() as base_dir:
            base = Path(base_dir)
            # 创建子目录和文件
            subdir = base / "subdir"
            subdir.mkdir()
            (subdir / "file.txt").touch()

            # 使用点号的路径
            target = base / "subdir" / "." / "file.txt"

            assert _is_safe_path(base, target) is True
