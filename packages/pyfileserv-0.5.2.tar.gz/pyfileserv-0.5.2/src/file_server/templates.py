"""HTML 模板"""
from datetime import datetime
from typing import List, Tuple, Optional
import urllib.parse

# CSS 样式常量
CSS_COMMON = """
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
"""

CSS_GRADIENT_PRIMARY = "linear-gradient(135deg, #667eea 0%, #764ba2 100%)"

# 共享表单样式
CSS_FORM_INPUTS = """
.form-group input {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 14px;
    transition: border-color 0.3s;
}
.form-group input:focus {
    outline: none;
    border-color: #667eea;
}
"""

# 共享按钮样式
CSS_BUTTON_PRIMARY = """
.btn-primary {
    padding: 14px;
    background: """ + CSS_GRADIENT_PRIMARY + """;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
}
.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
}
"""

# 共享错误消息样式
CSS_ERROR = """
.error {
    background: #fff3f3;
    border: 1px solid #ff6b6b;
    color: #d63031;
    padding: 12px;
    border-radius: 6px;
    margin-bottom: 20px;
    font-size: 14px;
}
"""

# Logo SVG (内嵌)
LOGO_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="48" height="48">
  <defs>
    <linearGradient id="logoGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea"/>
      <stop offset="100%" style="stop-color:#764ba2"/>
    </linearGradient>
  </defs>
  <circle cx="64" cy="64" r="60" fill="url(#logoGrad1)"/>
  <path d="M24 45 L24 95 C24 100 28 104 33 104 L95 104 C100 104 104 100 104 95 L104 52 C104 47 100 43 95 43 L60 43 L52 35 C50 33 47 32 44 32 L33 32 C28 32 24 36 24 41 L24 45 Z" fill="white" opacity="0.95"/>
  <path d="M24 50 L24 95 C24 100 28 104 33 104 L95 104 C100 104 104 100 104 95 L104 52 C104 47 100 43 95 43 L33 43 C28 43 24 47 24 52 L24 50 Z" fill="white"/>
  <circle cx="90" cy="78" r="24" fill="url(#logoGrad1)"/>
  <rect x="78" y="74" width="24" height="20" rx="3" fill="white"/>
  <path d="M82 74 L82 66 C82 60 86 56 90 56 C94 56 98 60 98 66 L98 74" stroke="white" stroke-width="5" fill="none" stroke-linecap="round"/>
  <circle cx="90" cy="83" r="3" fill="url(#logoGrad1)"/>
  <rect x="88" y="83" width="4" height="6" fill="url(#logoGrad1)"/>
</svg>'''

# Favicon SVG (内嵌)
FAVICON_SVG = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">
  <defs><linearGradient id="favGrad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#667eea"/><stop offset="100%" style="stop-color:#764ba2"/></linearGradient></defs>
  <circle cx="16" cy="16" r="15" fill="url(#favGrad)"/>
  <path d="M6 11 L6 25 C6 26 7 27 8 27 L24 27 C25 27 26 26 26 25 L26 13 C26 12 25 11 24 11 L15 11 L13 9 C12.5 8.5 12 8 11 8 L8 8 C7 8 6 9 6 10 L6 11 Z" fill="white" opacity="0.95"/>
  <circle cx="23" cy="20" r="6" fill="url(#favGrad)"/>
  <rect x="20" y="18" width="6" height="5" rx="1" fill="white"/>
  <path d="M21 18 L21 16 C21 14.5 22 13.5 23 13.5 C24 13.5 25 14.5 25 16 L25 18" stroke="white" stroke-width="1.5" fill="none"/>
</svg>'''


def render_login_page(error_msg: str = "", session_timeout: int = 3600) -> str:
    """渲染登录页面"""
    timeout_text = f"{session_timeout // 3600}小时" if session_timeout >= 3600 else f"{session_timeout // 60}分钟"
    error_html = f'<div class="error">{error_msg}</div>' if error_msg else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    <style>
        {CSS_COMMON}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: {CSS_GRADIENT_PRIMARY};
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }}
        .login-container {{
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            padding: 40px;
            width: 100%;
            max-width: 400px;
        }}
        .login-header {{
            text-align: center;
            margin-bottom: 30px;
        }}
        .login-header .logo {{
            margin-bottom: 15px;
        }}
        .login-header h1 {{
            color: #333;
            font-size: 28px;
            margin-bottom: 10px;
        }}
        .login-header p {{
            color: #666;
            font-size: 14px;
        }}
        .form-group {{
            margin-bottom: 20px;
        }}
        .form-group label {{
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }}
        {CSS_FORM_INPUTS}
        {CSS_ERROR}
        {CSS_BUTTON_PRIMARY}
        .btn-login {{
            width: 100%;
        }}
        .footer {{
            text-align: center;
            margin-top: 20px;
            color: #999;
            font-size: 12px;
        }}
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">{LOGO_SVG}</div>
            <h1>文件服务器</h1>
        </div>
        {error_html}
        <form method="POST" action="/do_login">
            <div class="form-group">
                <label for="username">用户名</label>
                <input type="text" id="username" name="username" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">密码</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn-login btn-primary">登录</button>
        </form>
    </div>
</body>
</html>
"""


def format_size(size: int) -> str:
    """格式化文件大小"""
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    elif size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    else:
        return f"{size / (1024 * 1024 * 1024):.1f} GB"


def render_upload_page(username: str, error_msg: str = "", success_msg: str = "") -> str:
    """渲染文件上传页面"""
    error_html = f'<div class="error">{error_msg}</div>' if error_msg else ""
    success_html = f'<div class="success">{success_msg}</div>' if success_msg else ""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>上传文件 - 文件服务器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    <style>
        {CSS_COMMON}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            min-height: 100vh;
            padding: 20px;
        }}
        .header {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .header-left {{
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        .header h1 {{
            font-size: 24px;
            margin: 0;
        }}
        .header .user-info {{
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 14px;
            opacity: 0.9;
        }}
        .header .nav-btn {{
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            text-decoration: none;
            transition: all 0.3s;
        }}
        .header .nav-btn:hover {{
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }}
        .upload-container {{
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
        }}
        .upload-area {{
            border: 3px dashed #667eea;
            border-radius: 15px;
            padding: 60px 40px;
            text-align: center;
            background: #f8f9ff;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
        }}
        .upload-area:hover {{
            background: #f0f2ff;
            border-color: #4834d4;
        }}
        .upload-area.dragover {{
            background: #e8ebff;
            border-color: #4834d4;
        }}
        .upload-icon {{
            font-size: 64px;
            margin-bottom: 20px;
        }}
        .upload-text {{
            color: #333;
            font-size: 18px;
            margin-bottom: 10px;
        }}
        .upload-hint {{
            color: #666;
            font-size: 14px;
        }}
        .file-input {{
            display: none;
        }}
        .file-list {{
            margin-top: 20px;
        }}
        .file-item {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 10px;
        }}
        .file-item .file-name {{
            color: #333;
            font-weight: 500;
        }}
        .file-item .file-size {{
            color: #666;
            font-size: 13px;
            margin-left: 10px;
        }}
        .file-item .remove-btn {{
            background: #ff6b6b;
            color: white;
            border: none;
            padding: 5px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 13px;
        }}
        .file-item .remove-btn:hover {{
            background: #ee5a5a;
        }}
        .submit-btn {{
            width: 100%;
            padding: 14px;
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            margin-top: 20px;
        }}
        .submit-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .submit-btn:disabled {{
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }}
        {CSS_ERROR}
        .success {{
            background: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>上传文件</h1>
        </div>
        <div class="user-info">
            <span>{username}</span>
            <a href="/" class="nav-btn">返回文件列表</a>
            <a href="/logout" class="nav-btn">退出</a>
        </div>
    </div>

    <div class="upload-container">
        {error_html}
        {success_html}
        <form method="POST" action="/upload" enctype="multipart/form-data" id="uploadForm">
            <div class="upload-area" id="dropZone">
                <div class="upload-icon">📁</div>
                <div class="upload-text">点击或拖拽文件到此处上传</div>
                <div class="upload-hint">支持任意类型文件</div>
                <input type="file" name="files" class="file-input" id="fileInput" multiple>
            </div>
            <div class="file-list" id="fileList"></div>
            <button type="submit" class="submit-btn" id="submitBtn" disabled>上传文件</button>
        </form>
    </div>

    <script>
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');
        const fileList = document.getElementById('fileList');
        const submitBtn = document.getElementById('submitBtn');
        const uploadForm = document.getElementById('uploadForm');
        let selectedFiles = [];

        dropZone.addEventListener('click', () => fileInput.click());

        dropZone.addEventListener('dragover', (e) => {{
            e.preventDefault();
            dropZone.classList.add('dragover');
        }});

        dropZone.addEventListener('dragleave', () => {{
            dropZone.classList.remove('dragover');
        }});

        dropZone.addEventListener('drop', (e) => {{
            e.preventDefault();
            dropZone.classList.remove('dragover');
            addFiles(e.dataTransfer.files);
        }});

        fileInput.addEventListener('change', (e) => {{
            addFiles(e.target.files);
        }});

        function addFiles(files) {{
            for (let file of files) {{
                if (!selectedFiles.some(f => f.name === file.name && f.size === file.size)) {{
                    selectedFiles.push(file);
                }}
            }}
            updateFileList();
        }}

        function updateFileList() {{
            fileList.innerHTML = '';
            selectedFiles.forEach((file, index) => {{
                const item = document.createElement('div');
                item.className = 'file-item';
                item.innerHTML = `
                    <span>
                        <span class="file-name">${{file.name}}</span>
                        <span class="file-size">(${{formatSize(file.size)}})</span>
                    </span>
                    <button type="button" class="remove-btn" onclick="removeFile(${{index}})">移除</button>
                `;
                fileList.appendChild(item);
            }});
            submitBtn.disabled = selectedFiles.length === 0;
        }}

        function removeFile(index) {{
            selectedFiles.splice(index, 1);
            updateFileList();
        }}

        function formatSize(bytes) {{
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
            return (bytes / (1024 * 1024 * 1024)).toFixed(1) + ' GB';
        }}

        uploadForm.addEventListener('submit', (e) => {{
            if (selectedFiles.length === 0) {{
                e.preventDefault();
                return;
            }}

            // 创建新的 DataTransfer 并添加文件到 input
            const dt = new DataTransfer();
            selectedFiles.forEach(file => dt.items.add(file));
            fileInput.files = dt.files;
        }});
    </script>
</body>
</html>
"""


def render_file_list_page(username: str, html_files: List[Tuple[str, int]], xmind_files: List[Tuple[str, int]],
        json_files: List[Tuple[str, int]], other_files: List[Tuple[str, int]], sort_by: str = "name",
        search_query: str = "") -> str:
    """渲染文件列表页面

    Args:
        username: 当前用户名
        html_files: HTML文件列表 [(文件名, 大小), ...]
        xmind_files: XMind文件列表 [(文件名, 大小), ...]
        json_files: JSON文件列表 [(文件名, 大小), ...]
        other_files: 其他文件列表 [(文件名, 大小), ...]
        sort_by: 排序方式 (name, size)
        search_query: 搜索关键词
    """
    # 排序文件
    reverse = sort_by == "size"
    key_func = lambda x: x[1] if sort_by == "size" else x[0].lower()
    html_files_sorted = sorted(html_files, key=key_func, reverse=reverse)
    xmind_files_sorted = sorted(xmind_files, key=key_func, reverse=reverse)
    json_files_sorted = sorted(json_files, key=key_func, reverse=reverse)
    other_files_sorted = sorted(other_files, key=key_func, reverse=reverse)

    # 生成 HTML 文件列表
    html_items = ""
    for filename, size in html_files_sorted:
        html_items += f"""
                        <li class="file-item html-file" data-name="{filename.lower()}" data-size="{size}">
                            <a href="{urllib.parse.quote(filename)}" class="file-link">{filename}</a>
                            <span class="file-info">{format_size(size)}</span>
                        </li>
        """
    if not html_files:
        html_items = '<li class="file-item">暂无HTML文件</li>'

    # 生成 XMind 文件列表
    xmind_items = ""
    for filename, size in xmind_files_sorted:
        xmind_items += f"""
                        <li class="file-item xmind-file" data-name="{filename.lower()}" data-size="{size}">
                            <a href="/download/{urllib.parse.quote(filename)}" class="file-link">{filename}</a>
                            <span class="file-info">{format_size(size)} | 点击下载</span>
                        </li>
        """
    if not xmind_files:
        xmind_items = '<li class="file-item">暂无XMind文件</li>'

    # 生成 JSON 文件列表
    json_items = ""
    for filename, size in json_files_sorted:
        json_items += f"""
                        <li class="file-item json-file" data-name="{filename.lower()}" data-size="{size}">
                            <a href="/view/{urllib.parse.quote(filename)}" class="file-link">{filename}</a>
                            <span class="file-info">{format_size(size)} | 点击查看</span>
                        </li>
        """
    if not json_files:
        json_items = '<li class="file-item">暂无JSON文件</li>'

    # 生成其他文件列表
    other_items = ""
    for filename, size in other_files_sorted:
        other_items += f"""
                        <li class="file-item other-file" data-name="{filename.lower()}" data-size="{size}">
                            <a href="/download/{urllib.parse.quote(filename)}" class="file-link">{filename}</a>
                            <span class="file-info">{format_size(size)} | 点击下载</span>
                        </li>
        """
    if not other_files:
        other_items = '<li class="file-item">暂无其他文件</li>'

    # 统计文件数量
    total_files = len(html_files) + len(xmind_files) + len(json_files) + len(other_files)
    total_size = sum(s for _, s in html_files) + sum(s for _, s in xmind_files) + sum(s for _, s in json_files) + sum(
        s for _, s in other_files)

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>文件列表</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    <style>
        {CSS_COMMON}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            padding: 20px;
        }}
        .header {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
        }}
        .header-left {{
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        .header .logo {{
            width: 40px;
            height: 40px;
        }}
        .header h1 {{
            font-size: 28px;
            margin-bottom: 0;
        }}
        .header .user-info {{
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 14px;
            opacity: 0.9;
        }}
        .header .nav-btn {{
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            text-decoration: none;
            transition: all 0.3s;
        }}
        .header .nav-btn:hover {{
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }}
        .toolbar {{
            max-width: 1200px;
            margin: 0 auto 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .search-box {{
            flex: 1;
            min-width: 200px;
            position: relative;
        }}
        .search-box input {{
            width: 100%;
            padding: 12px 15px 12px 40px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }}
        .search-box input:focus {{
            outline: none;
            border-color: #667eea;
        }}
        .search-box::before {{
            content: "🔍";
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 14px;
        }}
        .sort-controls {{
            display: flex;
            gap: 10px;
            align-items: center;
        }}
        .sort-controls label {{
            color: #666;
            font-size: 14px;
        }}
        .sort-controls select {{
            padding: 10px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            background: white;
        }}
        .sort-controls select:focus {{
            outline: none;
            border-color: #667eea;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .section {{
            margin-bottom: 30px;
        }}
        .section-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }}
        .section-title {{
            font-size: 20px;
            color: #333;
            margin: 0;
        }}
        .section-count {{
            font-size: 14px;
            color: #666;
        }}
        .file-list {{
            list-style: none;
        }}
        .file-item {{
            margin: 10px 0;
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background: #f8f9fa;
            transition: all 0.3s;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        .file-item:hover {{
            background: #e9ecef;
            border-color: #667eea;
            transform: translateX(5px);
        }}
        .file-item.html-file {{
            background: #d4edda;
            border-color: #c3e6cb;
        }}
        .file-item.html-file:hover {{
            background: #c3e6cb;
        }}
        .file-item.xmind-file {{
            background: #e2d5f1;
            border-color: #d4c4e8;
        }}
        .file-item.xmind-file:hover {{
            background: #d4c4e8;
        }}
        .file-item.json-file {{
            background: #fff3cd;
            border-color: #ffeeba;
        }}
        .file-item.json-file:hover {{
            background: #ffeeba;
        }}
        .file-item.other-file {{
            background: #d1ecf1;
            border-color: #bee5eb;
        }}
        .file-item.other-file:hover {{
            background: #bee5eb;
        }}
        .file-item.hidden {{
            display: none;
        }}
        .file-link {{
            text-decoration: none;
            color: #667eea;
            font-weight: 600;
            font-size: 16px;
            flex: 1;
        }}
        .file-link:hover {{
            color: #4834d4;
        }}
        .file-info {{
            color: #666;
            font-size: 13px;
            margin-left: 15px;
            white-space: nowrap;
        }}
        .path-info {{
            color: #666;
            font-size: 14px;
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }}
        .path-info div {{
            display: flex;
            gap: 5px;
        }}
        .no-results {{
            text-align: center;
            padding: 40px;
            color: #666;
            display: none;
        }}
        @media (max-width: 768px) {{
            .file-item {{
                flex-direction: column;
                align-items: flex-start;
            }}
            .file-info {{
                margin-left: 0;
                margin-top: 8px;
            }}
            .toolbar {{
                flex-direction: column;
                align-items: stretch;
            }}
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="40" height="40"')}</div>
            <h1>文件列表</h1>
        </div>
        <div class="user-info">
            <span>当前用户: {username}</span>
            <a href="/upload" class="nav-btn">上传文件</a>
            <a href="/logout" class="nav-btn">退出登录</a>
        </div>
    </div>

    <div class="toolbar">
        <div class="search-box">
            <input type="text" id="searchInput" placeholder="搜索文件..." value="{search_query}">
        </div>
        <div class="sort-controls">
            <label for="sortSelect">排序:</label>
            <select id="sortSelect" onchange="changeSort(this.value)">
                <option value="name" {"selected" if sort_by == "name" else ""}>按名称</option>
                <option value="size" {"selected" if sort_by == "size" else ""}>按大小</option>
            </select>
        </div>
    </div>

    <div class="container">
        <div class="section">
            <div class="section-header">
                <h2 class="section-title">HTML文件</h2>
                <span class="section-count" id="htmlCount">{len(html_files)} 个文件</span>
            </div>
            <ul class="file-list" id="htmlList">
                {html_items}
            </ul>
        </div>

        <div class="section">
            <div class="section-header">
                <h2 class="section-title">XMind文件</h2>
                <span class="section-count" id="xmindCount">{len(xmind_files)} 个文件</span>
            </div>
            <ul class="file-list" id="xmindList">
                {xmind_items}
            </ul>
        </div>

        <div class="section">
            <div class="section-header">
                <h2 class="section-title">JSON文件</h2>
                <span class="section-count" id="jsonCount">{len(json_files)} 个文件</span>
            </div>
            <ul class="file-list" id="jsonList">
                {json_items}
            </ul>
        </div>

        <div class="section">
            <div class="section-header">
                <h2 class="section-title">其他文件</h2>
                <span class="section-count" id="otherCount">{len(other_files)} 个文件</span>
            </div>
            <ul class="file-list" id="otherList">
                {other_items}
            </ul>
        </div>

        <div class="no-results" id="noResults">
            未找到匹配的文件
        </div>

        <div class="path-info">
            <div><strong>服务器时间:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            <div><strong>文件总数:</strong> {total_files} 个</div>
            <div><strong>总大小:</strong> {format_size(total_size)}</div>
        </div>
    </div>

    <script>
        const searchInput = document.getElementById('searchInput');
        const htmlList = document.getElementById('htmlList');
        const xmindList = document.getElementById('xmindList');
        const jsonList = document.getElementById('jsonList');
        const otherList = document.getElementById('otherList');
        const noResults = document.getElementById('noResults');
        const htmlCount = document.getElementById('htmlCount');
        const xmindCount = document.getElementById('xmindCount');
        const jsonCount = document.getElementById('jsonCount');
        const otherCount = document.getElementById('otherCount');

        searchInput.addEventListener('input', function() {{
            filterFiles(this.value);
        }});

        function filterFiles(query) {{
            query = query.toLowerCase();
            let htmlVisible = 0, xmindVisible = 0, jsonVisible = 0, otherVisible = 0;

            htmlList.querySelectorAll('.file-item').forEach(item => {{
                const name = item.dataset.name || '';
                const match = name.includes(query);
                item.classList.toggle('hidden', !match && query !== '');
                if (match || query === '') htmlVisible++;
            }});

            xmindList.querySelectorAll('.file-item').forEach(item => {{
                const name = item.dataset.name || '';
                const match = name.includes(query);
                item.classList.toggle('hidden', !match && query !== '');
                if (match || query === '') xmindVisible++;
            }});

            jsonList.querySelectorAll('.file-item').forEach(item => {{
                const name = item.dataset.name || '';
                const match = name.includes(query);
                item.classList.toggle('hidden', !match && query !== '');
                if (match || query === '') jsonVisible++;
            }});

            otherList.querySelectorAll('.file-item').forEach(item => {{
                const name = item.dataset.name || '';
                const match = name.includes(query);
                item.classList.toggle('hidden', !match && query !== '');
                if (match || query === '') otherVisible++;
            }});

            htmlCount.textContent = htmlVisible + ' 个文件';
            xmindCount.textContent = xmindVisible + ' 个文件';
            jsonCount.textContent = jsonVisible + ' 个文件';
            otherCount.textContent = otherVisible + ' 个文件';

            noResults.style.display = (htmlVisible === 0 && xmindVisible === 0 && jsonVisible === 0 && otherVisible === 0) ? 'block' : 'none';
        }}

        function changeSort(sortBy) {{
            const url = new URL(window.location.href);
            url.searchParams.set('sort', sortBy);
            if (searchInput.value) {{
                url.searchParams.set('q', searchInput.value);
            }}
            window.location.href = url.toString();
        }}

        // 初始搜索
        if (searchInput.value) {{
            filterFiles(searchInput.value);
        }}
    </script>
</body>
</html>
"""


def render_json_view_page(username: str, filename: str, json_content: str, project_name: Optional[str] = None) -> str:
    """渲染JSON查看页面"""
    convert_section = ""

    return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{filename} - JSON查看器</title>
    <link rel="icon" type="image/svg+xml" href="/static/favicon.svg">
    <style>
        {CSS_COMMON}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            padding: 20px;
        }}
        .header {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            padding: 20px 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
        }}
        .header-left {{
            display: flex;
            align-items: center;
            gap: 15px;
        }}
        .header .logo {{
            width: 36px;
            height: 36px;
        }}
        .header h1 {{
            font-size: 20px;
            margin: 0;
        }}
        .header .user-info {{
            display: flex;
            align-items: center;
            gap: 15px;
            font-size: 14px;
            opacity: 0.9;
        }}
        .header .nav-btn {{
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 8px 20px;
            border-radius: 20px;
            text-decoration: none;
            transition: all 0.3s;
        }}
        .header .nav-btn:hover {{
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        .toolbar {{
            background: white;
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }}
        .toolbar h2 {{
            margin: 0;
            font-size: 18px;
            color: #333;
            flex: 1;
        }}
        .btn {{
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }}
        .btn-primary {{
            background: {CSS_GRADIENT_PRIMARY};
            color: white;
            border: none;
        }}
        .btn-primary:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }}
        .btn-secondary {{
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }}
        .btn-secondary:hover {{
            background: #667eea;
            color: white;
        }}
        .convert-section {{
            background: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .convert-section h3 {{
            margin: 0 0 10px 0;
            font-size: 16px;
            color: #333;
        }}
        .convert-section p {{
            margin: 0 0 15px 0;
            color: #666;
        }}
        .convert-btn {{
            padding: 12px 25px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .convert-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(245, 87, 108, 0.4);
        }}
        .convert-btn:disabled {{
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }}
        .json-container {{
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }}
        .json-content {{
            background: #1e1e1e;
            color: #d4d4d4;
            padding: 20px;
            border-radius: 8px;
            overflow-x: auto;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 14px;
            line-height: 1.6;
            white-space: pre-wrap;
            word-break: break-all;
            max-height: 70vh;
            overflow-y: auto;
        }}
        .success-msg {{
            color: #28a745;
            margin-left: 15px;
        }}
        .error-msg {{
            color: #dc3545;
            margin-left: 15px;
        }}
        .copy-toast {{
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: white;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 14px;
            opacity: 0;
            transition: opacity 0.3s;
            z-index: 1000;
        }}
        .copy-toast.show {{
            opacity: 1;
        }}
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <div class="logo">{LOGO_SVG.replace('width="48" height="48"', 'width="36" height="36"')}</div>
            <h1>JSON 查看器</h1>
        </div>
        <div class="user-info">
            <span>{username}</span>
            <a href="/" class="nav-btn">返回列表</a>
            <a href="/logout" class="nav-btn">退出</a>
        </div>
    </div>

    <div class="container">
        <div class="toolbar">
            <h2>📄 {filename}</h2>
            <button onclick="copyContent()" class="btn btn-primary">📋 复制内容</button>
            <a href="/download/{urllib.parse.quote(filename)}" class="btn btn-secondary">⬇️ 下载JSON</a>
        </div>

        {convert_section}

        <div class="json-container">
            <div class="json-content" id="jsonContent">{json_content}</div>
        </div>
    </div>

    <div class="copy-toast" id="copyToast">已复制到剪贴板</div>

    <script>
        const jsonContent = document.getElementById('jsonContent');
        const copyToast = document.getElementById('copyToast');

        function copyContent() {{
            const text = jsonContent.textContent;
            navigator.clipboard.writeText(text).then(() => {{
                copyToast.classList.add('show');
                setTimeout(() => copyToast.classList.remove('show'), 2000);
            }}).catch(err => {{
                alert('复制失败: ' + err);
            }});
        }}

        function convertToXmind() {{
            const btn = document.getElementById('convertBtn');
            const status = document.getElementById('convertStatus');
            btn.disabled = true;
            status.innerHTML = '转换中...';
            status.className = '';

            fetch('/convert/{urllib.parse.quote(filename)}', {{ method: 'POST' }})
                .then(res => res.json())
                .then(data => {{
                    if (data.success) {{
                        status.innerHTML = '✅ 转换成功！<a href="/download/' + encodeURIComponent(data.xmind_file) + '" class="success-msg">下载 ' + data.xmind_file + '</a>';
                    }} else {{
                        status.innerHTML = '❌ 转换失败: ' + data.error;
                        status.className = 'error-msg';
                        btn.disabled = false;
                    }}
                }})
                .catch(err => {{
                    status.innerHTML = '❌ 请求失败: ' + err;
                    status.className = 'error-msg';
                    btn.disabled = false;
                }});
        }}
    </script>
</body>
</html>
"""
