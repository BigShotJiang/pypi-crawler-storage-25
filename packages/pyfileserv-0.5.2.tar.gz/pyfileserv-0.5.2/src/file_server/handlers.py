"""HTTP 请求处理器"""
import http.server
import io
import json
import logging
import os
import re
import urllib.parse
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .auth import Authenticator, SessionManager
from .templates import render_login_page, render_file_list_page, render_upload_page, render_json_view_page, LOGO_SVG, FAVICON_SVG
from .config import ServerConfig

logger = logging.getLogger(__name__)


def _is_safe_path(base_dir: Path, target_path: Path) -> bool:
    """检查目标路径是否在基础目录范围内，防止路径遍历攻击"""
    try:
        base_resolved = base_dir.resolve()
        target_resolved = target_path.resolve()
        return str(target_resolved).startswith(str(base_resolved))
    except (OSError, ValueError):
        return False


def _parse_multipart(content: bytes, boundary: str) -> List[Dict]:
    """解析 multipart/form-data 数据

    Returns:
        List of dicts with keys: 'name', 'filename', 'data', 'content_type'
    """
    parts = []
    boundary_bytes = f'--{boundary}'.encode('utf-8')
    end_boundary = f'--{boundary}--'.encode('utf-8')

    # 分割各个部分
    raw_parts = content.split(boundary_bytes)

    for raw_part in raw_parts[1:]:  # 跳过第一个空部分
        if raw_part.startswith(b'--'):
            continue  # 结束边界

        # 去除前后的 CRLF
        raw_part = raw_part.strip(b'\r\n')
        if not raw_part:
            continue

        # 分离 headers 和 body
        header_end = raw_part.find(b'\r\n\r\n')
        if header_end == -1:
            continue

        headers_raw = raw_part[:header_end].decode('utf-8', errors='replace')
        body = raw_part[header_end + 4:]

        # 解析 headers
        content_disp = None
        content_type = None

        for line in headers_raw.split('\r\n'):
            if line.lower().startswith('content-disposition:'):
                content_disp = line
            elif line.lower().startswith('content-type:'):
                content_type = line.split(':', 1)[1].strip()

        if not content_disp:
            continue

        # 提取 name 和 filename
        name_match = re.search(r'name="([^"]+)"', content_disp)
        filename_match = re.search(r'filename="([^"]+)"', content_disp)

        part_info = {
            'name': name_match.group(1) if name_match else '',
            'filename': filename_match.group(1) if filename_match else None,
            'data': body,
            'content_type': content_type or 'application/octet-stream'
        }

        # 去除 body 末尾可能的多余数据
        if body.endswith(b'\r\n'):
            part_info['data'] = body[:-2]

        parts.append(part_info)

    return parts


def _sanitize_filename(filename: str) -> str:
    """清理文件名，移除危险字符"""
    # 只保留文件名，移除路径
    filename = os.path.basename(filename)
    # 移除危险字符
    filename = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', filename)
    # 移除开头的点和空格
    filename = filename.lstrip('. ')
    # 如果清理后为空，使用默认名称
    if not filename:
        filename = 'unnamed_file'
    return filename


class SecureHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    """安全文件服务器请求处理器"""

    # 类级别注入依赖
    authenticator: Optional[Authenticator] = None
    session_manager: Optional[SessionManager] = None
    config: Optional[ServerConfig] = None

    def log_request_info(self, method: str) -> None:
        """记录请求信息"""
        client_ip = self.client_address[0]
        client_port = self.client_address[1]
        logger.info(f"[{method}] {client_ip}:{client_port} - {self.path}")

    def get_current_username(self) -> Optional[str]:
        """获取当前登录用户名"""
        session_id = self._get_session_id()
        if session_id and self.session_manager:
            return self.session_manager.get_username(session_id)
        return None

    def is_authenticated(self) -> bool:
        """检查是否已认证"""
        session_id = self._get_session_id()
        if session_id and self.session_manager:
            valid, _ = self.session_manager.validate_session(session_id)
            return valid
        return False

    def _get_session_id(self) -> Optional[str]:
        """从 Cookie 获取 session_id"""
        if 'Cookie' in self.headers:
            cookies = self.headers['Cookie'].split(';')
            for cookie in cookies:
                if cookie.strip().startswith('session_id='):
                    return cookie.strip()[11:]
        return None

    def do_GET(self) -> None:
        """处理 GET 请求"""
        self.log_request_info('GET')

        # 未认证用户只能访问登录页和静态资源
        if not self.is_authenticated():
            if self.path in ('/login', '/do_login'):
                self._handle_login_page()
            elif self.path.startswith('/static/'):
                self._handle_static()
            else:
                self._redirect_to_login()
            return

        # 已认证用户的路由
        if self.path == '/logout':
            self._handle_logout()
        elif self.path == '/upload':
            self._handle_upload_page()
        elif self.path.startswith('/view/'):
            self._handle_view_json()
        elif self.path.startswith('/download/'):
            self._handle_download()
        elif self.path.startswith('/static/'):
            self._handle_static()
        else:
            super().do_GET()

    def do_POST(self) -> None:
        """处理 POST 请求"""
        self.log_request_info('POST')

        if self.path == '/do_login':
            self._handle_login()
        elif self.path == '/do_logout':
            self._handle_logout()
        elif self.path == '/upload':
            self._handle_upload()
        else:
            self.send_error(404, "Not Found")

    def _redirect_to_login(self) -> None:
        """重定向到登录页"""
        logger.info(f"未认证用户访问 {self.path}, 重定向到登录页")
        self.send_response(302)
        self.send_header('Location', '/login')
        self.end_headers()

    def _handle_static(self) -> None:
        """处理静态文件请求"""
        static_file = self.path[len('/static/'):]

        if static_file == 'logo.svg':
            self._send_svg_response(LOGO_SVG)
        elif static_file == 'favicon.svg':
            self._send_svg_response(FAVICON_SVG)
        else:
            self.send_error(404, "Static file not found")

    def _send_svg_response(self, svg_content: str) -> None:
        """发送 SVG 响应"""
        content = svg_content.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-type', 'image/svg+xml')
        self.send_header('Content-Length', str(len(content)))
        self.send_header('Cache-Control', 'public, max-age=86400')
        self.end_headers()
        self.wfile.write(content)

    def _handle_login_page(self, error_msg: str = "") -> None:
        """显示登录页面"""
        session_timeout = self.config.session_timeout if self.config else 3600
        html = render_login_page(error_msg, session_timeout)
        self._send_html_response(html)

    def _handle_login(self) -> None:
        """处理登录请求"""
        # 解析表单数据
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        params = urllib.parse.parse_qs(post_data)

        username = params.get('username', [''])[0].strip()
        password = params.get('password', [''])[0]

        logger.info(f"登录尝试 - 用户名: {username}")

        # 认证
        if self.authenticator:
            success, result = self.authenticator.authenticate(username, password)
            if success:
                # 登录成功，result 是 session_id
                self.send_response(302)
                self.send_header('Location', '/')
                self.send_header('Set-Cookie',
                                 f'session_id={result}; Path=/; HttpOnly; SameSite=Strict')
                self.end_headers()
                return

        # 登录失败
        self._handle_login_page("用户名或密码错误")

    def _handle_logout(self) -> None:
        """处理登出"""
        session_id = self._get_session_id()
        username = None
        if session_id and self.session_manager:
            username = self.session_manager.destroy_session(session_id)

        logger.info(f"用户登出: {username or '未知用户'}")

        self.send_response(302)
        self.send_header('Location', '/login')
        self.send_header('Set-Cookie',
                         'session_id=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict')
        self.end_headers()

    def _handle_download(self) -> None:
        """处理文件下载"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试下载文件")
            self.send_error(403, "Forbidden")
            return

        file_name = self.path[len('/download/'):].lstrip('/')
        file_name = urllib.parse.unquote(file_name)
        file_path = Path(self.directory) / file_name

        # 安全检查：防止路径遍历攻击
        if not _is_safe_path(Path(self.directory), file_path):
            logger.warning(f"路径遍历攻击尝试 - 用户: {username}, 路径: {file_name}")
            self.send_error(403, "Forbidden")
            return

        if file_path.exists() and file_path.is_file():
            try:
                file_size = file_path.stat().st_size
                logger.info(f"文件下载 - 用户: {username}, 文件: {file_name}")

                # RFC 5987: 支持 UTF-8 编码的文件名
                encoded_filename = urllib.parse.quote(file_path.name)
                content_disposition = f"attachment; filename*=UTF-8''{encoded_filename}"

                self.send_response(200)
                self.send_header('Content-Type', 'application/octet-stream')
                self.send_header('Content-Disposition', content_disposition)
                self.send_header('Content-Length', str(file_size))
                self.end_headers()

                with open(file_path, 'rb') as f:
                    self.copyfile(f, self.wfile)
                logger.info(f"文件下载完成 - {file_name}")

            except Exception as e:
                logger.error(f"下载文件出错 - 文件: {file_name}, 错误: {e}")
                self.send_error(500, "Download error")
        else:
            logger.warning(f"文件不存在 - {file_path}")
            self.send_error(404, "File not found")

    def _handle_upload_page(self, error_msg: str = "", success_msg: str = "") -> None:
        """显示上传页面"""
        username = self.get_current_username() or 'Unknown'
        html = render_upload_page(username, error_msg, success_msg)
        self._send_html_response(html)

    def _handle_upload(self) -> None:
        """处理文件上传"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试上传文件")
            self.send_error(403, "Forbidden")
            return

        # 获取 Content-Type 并提取 boundary
        content_type = self.headers.get('Content-Type', '')
        if not content_type.startswith('multipart/form-data'):
            self._handle_upload_page(error_msg="无效的请求格式")
            return

        # 提取 boundary
        boundary = None
        for part in content_type.split(';'):
            part = part.strip()
            if part.startswith('boundary='):
                boundary = part[9:]
                # 移除可能的引号
                if boundary.startswith('"') and boundary.endswith('"'):
                    boundary = boundary[1:-1]
                break

        if not boundary:
            self._handle_upload_page(error_msg="缺少边界参数")
            return

        # 读取请求体
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length == 0:
            self._handle_upload_page(error_msg="没有文件数据")
            return

        # 限制文件大小 (100MB)
        max_size = 100 * 1024 * 1024
        if content_length > max_size:
            self._handle_upload_page(error_msg=f"文件大小超过限制 (最大 100MB)")
            return

        try:
            body = self.rfile.read(content_length)
            parts = _parse_multipart(body, boundary)
        except Exception as e:
            logger.error(f"解析上传数据失败: {e}")
            self._handle_upload_page(error_msg="解析上传数据失败")
            return

        # 处理上传的文件
        uploaded_files = []
        errors = []

        # 获取上传目录（static_dir 或 serve_dir）
        upload_dir = Path(self.directory)

        for part in parts:
            if part['filename']:
                original_filename = part['filename']
                filename = _sanitize_filename(original_filename)
                file_data = part['data']

                # 处理文件名冲突
                target_path = upload_dir / filename
                counter = 1
                while target_path.exists():
                    name, ext = os.path.splitext(filename)
                    filename = f"{name}_{counter}{ext}"
                    target_path = upload_dir / filename
                    counter += 1

                # 额外的路径安全检查
                if not _is_safe_path(upload_dir, target_path):
                    errors.append(f"文件名不安全: {original_filename}")
                    continue

                try:
                    with open(target_path, 'wb') as f:
                        f.write(file_data)
                    uploaded_files.append(filename)
                    logger.info(f"文件上传成功 - 用户: {username}, 文件: {filename}, 大小: {len(file_data)} bytes")
                except Exception as e:
                    logger.error(f"保存文件失败: {filename}, 错误: {e}")
                    errors.append(f"保存失败: {original_filename}")

        # 返回结果
        if uploaded_files:
            success_msg = f"成功上传 {len(uploaded_files)} 个文件"
            if errors:
                success_msg += f"，{len(errors)} 个文件失败"
            self._handle_upload_page(success_msg=success_msg)
        else:
            error_msg = "没有文件被上传" if not errors else "，".join(errors)
            self._handle_upload_page(error_msg=error_msg)

    def list_directory(self, path: str):
        """重写目录列表方法"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning(f"未认证用户尝试访问目录列表: {path}")
            self.send_error(403, "Forbidden")
            return None

        logger.info(f"目录列表访问 - 用户: {username}")

        # 解析查询参数
        parsed = urllib.parse.urlparse(self.path)
        query_params = urllib.parse.parse_qs(parsed.query)
        sort_by = query_params.get('sort', ['name'])[0]
        search_query = query_params.get('q', [''])[0]

        # 验证排序参数
        if sort_by not in ('name', 'size'):
            sort_by = 'name'

        try:
            entries = os.listdir(path)
        except OSError as e:
            logger.error(f"无法列出目录: {path}, 错误: {e}")
            self.send_error(404, "No permission to list directory")
            return None

        # 排除隐藏文件和目录
        files = [f for f in entries if not f.startswith('.')
                 and os.path.isfile(os.path.join(path, f))]

        # 分离文件为4类: HTML, XMind, JSON, 其他
        html_files = []
        xmind_files = []
        json_files = []
        other_files = []

        for f in files:
            file_path = os.path.join(path, f)
            file_size = os.path.getsize(file_path)
            lower_name = f.lower()
            if lower_name.endswith(('.html', '.htm')):
                html_files.append((f, file_size))
            elif lower_name.endswith('.xmind'):
                xmind_files.append((f, file_size))
            elif lower_name.endswith('.json'):
                json_files.append((f, file_size))
            else:
                other_files.append((f, file_size))

        # 渲染页面
        html = render_file_list_page(username, html_files, xmind_files, json_files, other_files, sort_by, search_query)

        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html.encode('utf-8'))))
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
        return None

    def _handle_view_json(self) -> None:
        """处理JSON文件查看请求"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试查看JSON文件")
            self.send_error(403, "Forbidden")
            return

        file_name = self.path[len('/view/'):].lstrip('/')
        file_name = urllib.parse.unquote(file_name)
        file_path = Path(self.directory) / file_name

        # 安全检查
        if not _is_safe_path(Path(self.directory), file_path):
            logger.warning(f"路径遍历攻击尝试 - 用户: {username}, 路径: {file_name}")
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        if not file_name.lower().endswith('.json'):
            self.send_error(400, "Not a JSON file")
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json_content = f.read()
            json_data = json.loads(json_content)
            formatted_json = json.dumps(json_data, indent=2, ensure_ascii=False)
            logger.info(f"JSON文件查看 - 用户: {username}, 文件: {file_name}")
        except json.JSONDecodeError as e:
            formatted_json = f"JSON 解析错误: {e}"
        except Exception as e:
            logger.error(f"读取JSON文件失败: {e}")
            self.send_error(500, "Failed to read file")
            return

        # 检查是否有 project.name 字段用于 XMind 转换
        project_name = None
        try:
            if isinstance(json_data, dict) and 'project' in json_data:
                if isinstance(json_data['project'], dict) and 'name' in json_data['project']:
                    project_name = json_data['project']['name']
        except Exception:
            pass

        html = render_json_view_page(username, file_name, formatted_json, project_name)
        self._send_html_response(html)

    def _handle_convert_json(self) -> None:
        """处理JSON转XMind请求"""
        username = self.get_current_username() or 'Unknown'

        if not self.is_authenticated():
            logger.warning("未认证用户尝试转换JSON")
            self.send_error(403, "Forbidden")
            return

        file_name = self.path[len('/convert/'):].lstrip('/')
        file_name = urllib.parse.unquote(file_name)
        file_path = Path(self.directory) / file_name

        # 安全检查
        if not _is_safe_path(Path(self.directory), file_path):
            logger.warning(f"路径遍历攻击尝试 - 用户: {username}, 路径: {file_name}")
            self.send_error(403, "Forbidden")
            return

        if not file_path.exists() or not file_path.is_file():
            self.send_error(404, "File not found")
            return

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json_data = json.load(f)

            # 获取项目名称
            project_name = None
            if isinstance(json_data, dict) and 'project' in json_data:
                if isinstance(json_data['project'], dict) and 'name' in json_data['project']:
                    project_name = json_data['project']['name']

            if not project_name:
                project_name = file_name.rsplit('.json', 1)[0]

            # 创建XMind文件
            xmind_name = f"{project_name}.xmind"
            xmind_path = Path(self.directory) / xmind_name

            # 处理文件名冲突
            counter = 1
            while xmind_path.exists():
                xmind_name = f"{project_name}_{counter}.xmind"
                xmind_path = Path(self.directory) / xmind_name
                counter += 1

            # 构建XMind内容
            xmind_content = self._build_xmind_content(json_data, project_name)
            self._write_xmind_file(xmind_path, xmind_content)

            logger.info(f"JSON转XMind成功 - 用户: {username}, 原文件: {file_name}, 输出: {xmind_name}")

            # 返回JSON响应
            response = json.dumps({"success": True, "xmind_file": xmind_name})
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Content-Length', len(response))
            self.end_headers()
            self.wfile.write(response.encode('utf-8'))

        except json.JSONDecodeError as e:
            response = json.dumps({"success": False, "error": f"JSON解析错误: {e}"})
            self.send_response(400)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(response.encode('utf-8'))
        except Exception as e:
            logger.error(f"JSON转XMind失败: {e}")
            response = json.dumps({"success": False, "error": str(e)})
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(response.encode('utf-8'))

    def _build_xmind_content(self, data: dict, root_title: str) -> dict:
        """构建XMind内容结构"""
        content = {
            "root": {
                "title": root_title,
                "children": []
            }
        }

        def add_children(node, parent_children):
            """递归添加子节点"""
            if isinstance(node, dict):
                for key, value in node.items():
                    child = {"title": str(key)}
                    if isinstance(value, (dict, list)) and value:
                        child["children"] = []
                        add_children(value, child["children"])
                    elif value is not None:
                        child["title"] = f"{key}: {value}"
                    parent_children.append(child)
            elif isinstance(node, list):
                for i, item in enumerate(node):
                    child = {"title": f"[{i}]"}
                    if isinstance(item, (dict, list)) and item:
                        child["children"] = []
                        add_children(item, child["children"])
                    elif item is not None:
                        child["title"] = str(item)
                    parent_children.append(child)

        add_children(data, content["root"]["children"])
        return content

    def _write_xmind_file(self, path: Path, content: dict) -> None:
        """写入XMind文件"""
        # XMind文件实际上是一个ZIP压缩包，包含content.json和manifest.json
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zf:
            # 写入content.json
            content_json = json.dumps([content], ensure_ascii=False, indent=2)
            zf.writestr('content.json', content_json.encode('utf-8'))

            # 写入manifest.json
            manifest = {
                "file-entries": {
                    "content.json": {},
                    "metadata.json": {}
                }
            }
            zf.writestr('manifest.json', json.dumps(manifest).encode('utf-8'))

            # 写入metadata.json
            metadata = {
                "creator": {
                    "name": "pyfileserv",
                    "version": "0.4.5"
                },
                "created": datetime.now().isoformat()
            }
            zf.writestr('metadata.json', json.dumps(metadata).encode('utf-8'))

    def _send_html_response(self, html: str) -> None:
        """发送 HTML 响应"""
        content = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)
