"""命令行工具 - 服务器启动和用户管理"""
import argparse
import getpass
import logging
from pathlib import Path
from typing import Tuple, Optional

from .config import ServerConfig
from .server import run_server
from .auth import PasswordHasher, UserStore


MIN_PASSWORD_LENGTH = 6


def _validate_password(password: str, confirm_password: str = None) -> Tuple[bool, Optional[str]]:
    """验证密码强度和一致性

    Args:
        password: 密码
        confirm_password: 确认密码 (可选)

    Returns:
        (是否有效, 错误信息)
    """
    if len(password) < MIN_PASSWORD_LENGTH:
        return False, f"密码长度至少为{MIN_PASSWORD_LENGTH}位"

    if confirm_password is not None and password != confirm_password:
        return False, "两次密码不一致"

    return True, None


def _prompt_password(confirm: bool = True) -> tuple[None, str | None] | tuple[str, None]:
    """交互式密码输入

    Args:
        confirm: 是否需要确认密码

    Returns:
        (密码, 错误信息) - 密码为 None 时表示输入失败
    """
    password = getpass.getpass("密码: ")
    valid, error = _validate_password(password)
    if not valid:
        return None, error

    if confirm:
        confirm_pwd = getpass.getpass("确认密码: ")
        valid, error = _validate_password(password, confirm_pwd)
        if not valid:
            return None, error

    return password, None


def main() -> None:
    """主入口"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    parser = argparse.ArgumentParser(
        description='带登录认证的文件服务器',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python -m file_server              # 启动服务器
  python -m file_server -p 9000      # 指定端口
  python -m file_server user create  # 创建用户
  python -m file_server user list    # 列出用户
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='子命令')

    # 服务器命令 (默认)
    parser.add_argument('-p', '--port', type=int, default=8000,
                        help='端口号 (默认: 8000)')
    parser.add_argument('-d', '--directory', default='.',
                        help='文件服务目录')
    parser.add_argument('-c', '--config-dir',
                        help='配置文件目录')
    parser.add_argument('-s', '--static-dir',
                        help='静态文件目录')

    # 用户管理命令
    user_parser = subparsers.add_parser('user', help='用户管理')
    user_subparsers = user_parser.add_subparsers(dest='user_command')

    # user create
    create_parser = user_subparsers.add_parser('create', help='创建用户')
    create_parser.add_argument('-u', '--username', help='用户名')

    # user list
    user_subparsers.add_parser('list', help='列出用户')

    # user delete
    delete_parser = user_subparsers.add_parser('delete', help='删除用户')
    delete_parser.add_argument('-u', '--username', help='用户名')

    # user passwd
    passwd_parser = user_subparsers.add_parser('passwd', help='修改密码')
    passwd_parser.add_argument('-u', '--username', help='用户名')

    args = parser.parse_args()

    if args.command == 'user':
        _handle_user_command(args)
    elif args.command is None:
        config = ServerConfig.from_args(
            port=args.port,
            directory=args.directory,
            config_dir=args.config_dir,
            static_dir=args.static_dir
        )
        run_server(config)
    else:
        parser.print_help()


def _handle_user_command(args) -> None:
    """处理用户管理命令"""
    users_file = Path("users.json")
    user_store = UserStore(users_file)
    hasher = PasswordHasher()

    if args.user_command == 'create':
        _create_user(user_store, hasher, args.username)
    elif args.user_command == 'list':
        _list_users(user_store)
    elif args.user_command == 'delete':
        _delete_user(user_store, args.username)
    elif args.user_command == 'passwd':
        _change_password(user_store, hasher, args.username)
    else:
        print("未知用户命令，使用 --help 查看帮助")


def _create_user(user_store: UserStore, hasher: PasswordHasher,
                 username: str = None) -> None:
    """创建用户"""
    if not username:
        username = input("用户名: ").strip()

    if not username:
        print("错误: 用户名不能为空")
        return

    if user_store.user_exists(username):
        print(f"错误: 用户 '{username}' 已存在")
        return

    password, error = _prompt_password()
    if error:
        print(f"错误: {error}")
        return

    password_hash = hasher.hash_password(password)
    user_store.add_user(username, password_hash)
    print(f"用户 '{username}' 创建成功")


def _list_users(user_store: UserStore) -> None:
    """列出用户"""
    users = user_store.load_users()
    if not users:
        print("暂无用户")
        return

    print("\n用户列表:")
    for username in users:
        print(f"  - {username}")


def _delete_user(user_store: UserStore, username: str = None) -> None:
    """删除用户"""
    if not username:
        username = input("要删除的用户名: ").strip()

    if not user_store.user_exists(username):
        print(f"错误: 用户 '{username}' 不存在")
        return

    confirm = input(f"确认删除用户 '{username}'? (yes/no): ").strip().lower()
    if confirm == 'yes':
        user_store.delete_user(username)
        print(f"用户 '{username}' 已删除")
    else:
        print("已取消")


def _change_password(user_store: UserStore, hasher: PasswordHasher,
                     username: str = None) -> None:
    """修改密码"""
    if not username:
        username = input("用户名: ").strip()

    user_data = user_store.get_user(username)
    if not user_data:
        print(f"错误: 用户 '{username}' 不存在")
        return

    old_password = getpass.getpass("原密码: ")
    if not hasher.verify_password(old_password, user_data['password']):
        print("错误: 原密码不正确")
        return

    new_password, error = _prompt_password()
    if error:
        print(f"错误: {error}")
        return

    user_store.update_password(username, hasher.hash_password(new_password))
    print("密码修改成功")


if __name__ == "__main__":
    main()
