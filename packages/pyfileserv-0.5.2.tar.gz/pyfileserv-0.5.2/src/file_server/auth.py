"""认证模块 - 密码哈希、用户存储、会话管理"""
import json
import logging
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional, Tuple

import bcrypt

logger = logging.getLogger(__name__)


@dataclass
class Session:
    """会话数据"""
    session_id: str
    username: str
    expires: float
    created_at: float


class PasswordHasher:
    """密码哈希工具"""

    def __init__(self, rounds: int = 12):
        self.rounds = rounds

    def hash_password(self, password: str) -> str:
        """使用 bcrypt 加密密码"""
        salt = bcrypt.gensalt(rounds=self.rounds)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')

    def verify_password(self, password: str, hashed_password: str) -> bool:
        """验证密码"""
        try:
            return bcrypt.checkpw(
                password.encode('utf-8'),
                hashed_password.encode('utf-8')
            )
        except Exception:
            return False


class UserStore:
    """用户存储 - 负责用户数据的读写"""

    def __init__(self, users_file_path: Path):
        self.users_file_path = Path(users_file_path)

    def load_users(self) -> Dict[str, dict]:
        """加载用户数据"""
        if not self.users_file_path.exists():
            return {}
        with open(self.users_file_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def save_users(self, users: Dict[str, dict]) -> None:
        """保存用户数据"""
        self.users_file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.users_file_path, 'w', encoding='utf-8') as f:
            json.dump(users, f, indent=2, ensure_ascii=False)
        # 设置文件权限为仅所有者可读写 (防止其他用户读取密码哈希)
        try:
            os.chmod(self.users_file_path, 0o600)
        except OSError:
            pass  # Windows 或权限不足时忽略

    def user_exists(self, username: str) -> bool:
        """检查用户是否存在"""
        return username in self.load_users()

    def get_user(self, username: str) -> Optional[dict]:
        """获取用户数据"""
        users = self.load_users()
        return users.get(username)

    def add_user(self, username: str, password_hash: str) -> None:
        """添加用户"""
        users = self.load_users()
        users[username] = {
            "password": password_hash,
            "created_at": str(time.time())
        }
        self.save_users(users)

    def update_password(self, username: str, password_hash: str) -> None:
        """更新密码"""
        users = self.load_users()
        if username in users:
            users[username]["password"] = password_hash
            self.save_users(users)

    def delete_user(self, username: str) -> bool:
        """删除用户"""
        users = self.load_users()
        if username in users:
            del users[username]
            self.save_users(users)
            return True
        return False


class SessionManager:
    """会话管理器"""

    def __init__(self, timeout_seconds: int = 3600):
        self.timeout = timeout_seconds
        self._sessions: Dict[str, Session] = {}

    def create_session(self, username: str) -> str:
        """创建新会话，返回 session_id"""
        session_id = secrets.token_hex(32)
        now = time.time()
        self._sessions[session_id] = Session(
            session_id=session_id,
            username=username,
            expires=now + self.timeout,
            created_at=now
        )
        return session_id

    def validate_session(self, session_id: str) -> Tuple[bool, Optional[str]]:
        """验证会话，返回 (是否有效, 用户名)"""
        if not session_id or session_id not in self._sessions:
            return False, None

        session = self._sessions[session_id]
        if time.time() > session.expires:
            del self._sessions[session_id]
            return False, None

        # 刷新会话过期时间
        session.expires = time.time() + self.timeout
        return True, session.username

    def get_username(self, session_id: str) -> Optional[str]:
        """获取会话对应的用户名"""
        valid, username = self.validate_session(session_id)
        return username if valid else None

    def destroy_session(self, session_id: str) -> Optional[str]:
        """销毁会话，返回被销毁会话的用户名"""
        if session_id in self._sessions:
            username = self._sessions[session_id].username
            del self._sessions[session_id]
            return username
        return None


class Authenticator:
    """认证器 - 整合密码验证和会话管理"""

    def __init__(self, user_store: UserStore, hasher: PasswordHasher,
                 session_manager: SessionManager):
        self.user_store = user_store
        self.hasher = hasher
        self.session_manager = session_manager

    def authenticate(self, username: str, password: str) -> Tuple[bool, Optional[str]]:
        """
        验证用户凭据

        返回: (是否成功, 失败原因或session_id)
        """
        user_data = self.user_store.get_user(username)
        if not user_data:
            logger.warning(f"登录失败 - 用户不存在: {username}")
            return False, "用户不存在"

        stored_hash = user_data['password']
        if not self.hasher.verify_password(password, stored_hash):
            logger.warning(f"登录失败 - 密码错误: {username}")
            return False, "密码错误"

        session_id = self.session_manager.create_session(username)
        logger.info(f"登录成功 - 用户: {username}")
        return True, session_id
