"""配置模块"""
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class ServerConfig:
    """服务器配置"""
    # 服务配置
    port: int = 8000
    host: str = ""

    # 路径配置
    config_dir: Optional[Path] = None
    static_dir: Optional[Path] = None
    serve_dir: Optional[Path] = None

    # 用户文件
    users_file: str = "users.json"

    # 会话配置
    session_timeout: int = 3600  # 秒 (1小时)

    # 密码哈希配置
    bcrypt_rounds: int = 12

    def get_users_file_path(self) -> Path:
        """获取用户文件完整路径"""
        if self.config_dir:
            return self.config_dir / self.users_file
        return Path(self.users_file)

    @classmethod
    def from_args(cls, port: int = 8000, directory: str = ".",
                  config_dir: Optional[str] = None,
                  static_dir: Optional[str] = None) -> "ServerConfig":
        """从命令行参数创建配置"""
        return cls(
            port=port,
            config_dir=Path(config_dir) if config_dir else None,
            static_dir=Path(static_dir) if static_dir else None,
            serve_dir=Path(directory) if directory else None,
        )
