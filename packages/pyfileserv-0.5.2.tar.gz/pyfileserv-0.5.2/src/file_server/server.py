"""文件服务器主模块"""
import logging
import os
import platform
import socket
import socketserver
from pathlib import Path

from .auth import Authenticator, PasswordHasher, SessionManager, UserStore
from .config import ServerConfig
from .handlers import SecureHTTPRequestHandler

logger = logging.getLogger(__name__)


def run_server(config: ServerConfig) -> None:
    """启动文件服务器"""
    logger.info("=" * 60)
    logger.info(f"启动服务器: port={config.port}")

    # 初始化组件
    user_store = UserStore(config.get_users_file_path())
    hasher = PasswordHasher(rounds=config.bcrypt_rounds)
    session_manager = SessionManager(timeout_seconds=config.session_timeout)
    authenticator = Authenticator(user_store, hasher, session_manager)

    # 检查用户文件
    if not config.get_users_file_path().exists():
        logger.warning(f"用户文件不存在: {config.get_users_file_path()}")
        logger.info("请先运行 'python -m file_server user create' 创建用户")
        return

    # 确定服务目录
    serve_dir = config.static_dir or config.serve_dir or Path.cwd()
    if not serve_dir.exists():
        logger.error(f"文件服务目录不存在: {serve_dir}")
        return

    # 配置请求处理器
    SecureHTTPRequestHandler.authenticator = authenticator
    SecureHTTPRequestHandler.session_manager = session_manager
    SecureHTTPRequestHandler.config = config
    SecureHTTPRequestHandler.directory = str(serve_dir)

    # 打印启动信息
    _print_startup_info(config, serve_dir)

    # 切换工作目录
    os.chdir(serve_dir)

    # 启动服务器
    with socketserver.TCPServer((config.host, config.port), SecureHTTPRequestHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            logger.info("服务器已停止")
        finally:
            httpd.server_close()


def _print_startup_info(config: ServerConfig, serve_dir: Path) -> None:
    """打印启动信息"""
    logger.info(f"文件服务目录: {serve_dir.absolute()}")
    logger.info(f"配置文件目录: {config.config_dir or '当前目录'}")
    logger.info(f"认证文件: {config.get_users_file_path()}")
    logger.info(f"访问地址: http://localhost:{config.port}")

    # 获取局域网 IP
    try:
        lan_ip = _get_lan_ip()
        logger.info(f"局域网访问: http://{lan_ip}:{config.port}")
    except Exception as e:
        logger.warning(f"获取局域网IP失败: {e}")

    logger.info("按 Ctrl+C 停止服务器")
    logger.info("=" * 60)


def _get_lan_ip() -> str:
    """获取局域网 IP

    使用 UDP socket 连接方式获取真实网络接口 IP，
    这种方式在 Windows 和 Linux 上都可靠。
    注意：不会实际发送数据，只是获取 socket 绑定的本地地址。
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            # 连接到公共 DNS 服务器，不会实际发送数据
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        # 回退：尝试从主机名解析
        hostname = socket.gethostname()
        return socket.gethostbyname(hostname)
