import logging
from pathlib import Path
from src.file_server.config import ServerConfig
from src.file_server.server import run_server

def main():
    logging.basicConfig(level=logging.INFO)
    server = ServerConfig()
    server.port = 83
    server.config_dir = Path("C:/Users/yzuty/PycharmProjects/my-file-server")
    server.static_dir = Path("C:/Users/yzuty/Downloads/")
    server.serve_dir = Path(__file__).parent
    run_server(server)


if __name__ == '__main__':
    main()