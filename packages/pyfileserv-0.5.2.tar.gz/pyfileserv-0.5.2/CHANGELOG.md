# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.5.2] - 2026-04-17

### Fixed
- Fixed bug

## [0.5.1] - 2026-04-17

### Fixed
- Fixed bug 

## [0.5.0] - 2026-04-17

### Added
- File categories now split into 4 sections: HTML, XMind, JSON, and Others
- JSON file viewer with syntax highlighting
- Copy JSON content to clipboard functionality
- Download JSON file from viewer page
- JSON to XMind conversion (uses `project.name` from JSON as XMind filename)
- XMind files shown in dedicated section with distinct styling

### Changed
- File list page reorganized with 4 category sections
- Each file type has distinct color styling

## [0.4.4] - 2026-04-17

### Security
- Removed server path disclosure from page title and footer
- Page title now shows "文件列表" instead of full filesystem path
- Removed "当前路径" display from file list page

## [0.4.3] - 2026-04-17

### Changed
- **Python version support**: Now supports Python 3.6+ (previously required 3.13+)
- Added `dataclasses` backport dependency for Python 3.6 compatibility
- Relaxed bcrypt version requirement to `>=4.0.0`

## [0.4.2] - 2026-04-17

### Fixed
- File upload not working due to JavaScript removing file input element before submission

## [0.4.0] - 2026-04-17

### Added
- File upload functionality with multipart/form-data parsing
- Drag-and-drop file upload support
- Multiple file selection and upload
- Automatic filename conflict resolution (adds sequence number)
- Upload entry button in file list page header
- File size limit (100MB max)
- Filename sanitization to prevent path traversal attacks

### Security
- Filename sanitization removes dangerous characters and path components
- File upload path validation prevents directory traversal
- File size limit prevents DoS via large uploads

## [0.3.0] - 2026-04-16

### Added
- Logo and favicon SVG icons for branding
- File search/filter functionality in file list page
- File sorting by name or size
- File count and total size display
- Responsive toolbar with search and sort controls
- Unit tests for path security validation

### Changed
- Improved LAN IP detection for Windows (more reliable UDP socket method)
- Extracted common CSS styles to reduce code duplication
- Extracted password validation to shared function in CLI

### Fixed
- **Security**: Path traversal vulnerability in file download
  - Added `_is_safe_path()` function to validate file paths
  - Prevents `../` attacks from accessing files outside serve directory
- **Security**: User data file now sets restrictive permissions (0o600)
  - Prevents other users from reading password hashes

### Security
- Path traversal attack prevention in file download endpoint
- Restrictive file permissions on user data storage

## [0.2.0] - 2024-01-01

### Added
- User authentication system with bcrypt password hashing
- Session management with cookie-based sessions
- File browsing with HTML/other file separation
- File download support
- User management CLI (create, list, delete, passwd)
- Configurable port, directory, and session timeout

## [0.1.0] - 2024-01-01

### Added
- Initial release

[Unreleased]: https://github.com/yzutyc/pyfileserv/compare/v0.5.2...HEAD
[0.5.2]: https://github.com/yzutyc/pyfileserv/compare/v0.4.4...v0.5.2
[0.5.1]: https://github.com/yzutyc/pyfileserv/compare/v0.4.4...v0.5.1
[0.5.0]: https://github.com/yzutyc/pyfileserv/compare/v0.4.4...v0.5.0
[0.4.4]: https://github.com/yzutyc/pyfileserv/compare/v0.4.3...v0.4.4
[0.4.3]: https://github.com/yzutyc/pyfileserv/compare/v0.4.2...v0.4.3
[0.4.2]: https://github.com/yzutyc/pyfileserv/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/yzutyc/pyfileserv/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/yzutyc/pyfileserv/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/yzutyc/pyfileserv/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/yzutyc/pyfileserv/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/yzutyc/pyfileserv/releases/tag/v0.1.0
