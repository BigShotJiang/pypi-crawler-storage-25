"""pseudo-lang — name reserved for the Pseudo language.

The Pseudo language is currently in pre-v1 development. The actual
runtime + compiler bindings will be published to PyPI when v1.0 Ludens
ships and Vladimir Dukelic personally tests + approves the working
version.

Until then:
    Source:        https://github.com/siliconyouth/pseudo
    Marketing:     https://pseudo-lang.com (lands at v1.0)
    Spec:          https://github.com/siliconyouth/pseudo/blob/main/docs/superpowers/specs/2026-05-13-pseudo-design.md
    Compatibility: https://github.com/siliconyouth/pseudo/blob/main/COMPATIBILITY.md
    Conformance:   https://github.com/siliconyouth/pseudo/blob/main/CONFORMANCE.md

License: MIT OR Apache-2.0
Owner:   Vladimir Dukelic <vladimir@dukelic.com>
"""

__version__ = "0.0.1"
__author__ = "Vladimir Dukelic"
__email__ = "vladimir@dukelic.com"
__license__ = "MIT OR Apache-2.0"
__url__ = "https://github.com/siliconyouth/pseudo"

reserved = True
status = "pre-v1"
homepage = "https://pseudo-lang.com"
repository = "https://github.com/siliconyouth/pseudo"

message = (
    "\n  pseudo-lang — name reserved for the Pseudo language.\n"
    "\n  The actual package will be published when v1.0 Ludens ships.\n"
    "  Source: https://github.com/siliconyouth/pseudo\n"
)


def main() -> None:
    """Print the reserved-name notice when run as a script."""
    print(message)


if __name__ == "__main__":
    main()
