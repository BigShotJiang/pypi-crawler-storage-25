"""DealWatch MCP package."""
