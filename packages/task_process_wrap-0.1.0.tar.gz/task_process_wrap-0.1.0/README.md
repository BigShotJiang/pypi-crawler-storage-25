# task_process_wrap
Encapsulate tasks safely using processes

## install

```bash
pip install task_process_wrap
```

## usage

```python
from task_process_wrap import TaskProcessWrap
import time


tpw = TaskProcessWrap(["python", "-c", "import time; [(print(i, flush=True), time.sleep(1)) for i in range(100)]"])
tpw.start()


while True:
    print(tpw.info())
    time.sleep(0.5)
    if tpw.info()["status"] in ["done", "killed"]:
        break
    if tpw.info()["run_time"] > 10:
        tpw.kill()


print(tpw.info())
```
