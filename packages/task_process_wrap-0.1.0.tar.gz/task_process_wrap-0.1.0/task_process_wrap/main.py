import subprocess
import threading
import time
from typing import Any

class TaskProcessWrap:
    def __init__(self, cmd_args_list: list[str], wait_time: float = 0.1) -> None:
        self.cmd_args_list = cmd_args_list
        self.wait_time = wait_time
        self.status = "pending"
        self.proc = None
        self.start_time = None
        self.end_time = None

        # 输出信息
        self.stdout_data = []
        self.stderr_data = []

        # 退出控制
        self._stop_event = threading.Event()

        # 两个独立线程
        self._stdout_thread = threading.Thread(target=self._read_stdout)
        self._stderr_thread = threading.Thread(target=self._read_stderr)

    def _read_stream(self, stream, output_list):
        while not self._stop_event.is_set():
            try:
                # 非阻塞读取一行（Windows/Linux通用）
                line = stream.readline()
                if line:
                    output_list.append(line)
                else:
                    # 流关闭，退出
                    break
            except Exception:
                break

        # 最后读完剩余内容
        for line in stream.readlines():
            output_list.append(line)

    def _read_stdout(self):
        if self.proc is not None:
            self._read_stream(self.proc.stdout, self.stdout_data)

    def _read_stderr(self):
        if self.proc is not None:
            self._read_stream(self.proc.stderr, self.stderr_data)

    def _monitor_thread(self):
        while not self._stop_event.is_set():
            if self.proc is not None:
                if self.proc.poll() is not None:
                    # 进程结束
                    if self.status != "killed":
                        self.status = "done"
                    if self.end_time is None:
                        self.end_time = time.time()
                    self._stop_event.set()
                    return
            time.sleep(self.wait_time)

    def start(self):
        if self.status != "pending":
            raise RuntimeError("You can not start a task twice.")
        
        self.proc = subprocess.Popen(
            self.cmd_args_list,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
        self.status = "running"
        self.start_time = time.time()

        # 启动三个线程：stdout、stderr、monitor
        self._stdout_thread.start()
        self._stderr_thread.start()
        threading.Thread(target=self._monitor_thread, daemon=True).start()

    def kill(self):
        if self.proc is not None:
            self.proc.kill()
            self.status = "killed"
            self.end_time = time.time()
            self._stop_event.set()

    def _get_run_time(self) -> float:
        if self.start_time is None:
            return 0.0
        if self.end_time is not None:
            return self.end_time - self.start_time
        return time.time() - self.start_time

    def info(self) -> dict[str, Any]:
        return {
            "args": self.cmd_args_list,
            "status": self.status,
            "start_time": self.start_time,
            "run_time": self._get_run_time(),
            "end_time": self.end_time,
            "stdout": self.stdout_data,
            "stderr": self.stderr_data,
        }

if __name__ == "__main__":
    tpw = TaskProcessWrap(["python", "-c", "import time; [(print(i, flush=True), time.sleep(1)) for i in range(100)]"])
    tpw.start()

    while True:
        print(tpw.info())
        time.sleep(0.5)
        if tpw.info()["status"] in ["done", "killed"]:
            break
        if tpw.info()["run_time"] > 10:
            tpw.kill()
    print(tpw.info())
