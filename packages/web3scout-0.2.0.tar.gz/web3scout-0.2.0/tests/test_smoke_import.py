"""Smoke test: the full package imports cleanly from a fresh venv.

This is the cheapest possible defense against 'pip install succeeded,
but import web3scout failed' bugs. Triggering the top-level __init__.py
exercises every module in its eager import chain (~30 modules), so
undeclared runtime dependencies and broken imports anywhere in the
package surface here rather than at a downstream user's terminal.

Unlike the other tests in this suite, this test relies on the normal
Python import machinery (`import web3scout`) rather than the
`import_module_directly` helper in conftest.py. That's intentional:
the whole point is to prove the advertised install path works.

This test also serves as runtime verification for the abi_to_signature
shim in abi/abi_load.py, which handles the eth_utils 4.x -> 5.x API
rename. Before that shim, `import web3scout` would fail on new eth_utils.
"""


class TestSmokeImport:
    """Verify the public install path works end-to-end."""

    def test_package_imports(self):
        """`import web3scout` succeeds without ImportError.

        This single line transitively exercises every module that
        __init__.py eagerly imports. Any missing runtime dependency
        or broken import in the chain causes this test to fail.
        """
        import web3scout  # noqa: F401

    def test_top_level_exports_accessible(self):
        """Representative public symbols are accessible as attributes.

        Guards against accidental deletion of `from .x import Y` lines
        in __init__.py. Picks one representative export per subpackage
        to stay meaningful without turning into a full re-export inventory.
        """
        import web3scout

        # One representative export per subpackage
        assert hasattr(web3scout, "ABILoad"),          "abi/ export missing"
        assert hasattr(web3scout, "Conversion"),       "event/tools/ export missing"
        assert hasattr(web3scout, "ReadEvents"),       "event/process/ export missing"
        assert hasattr(web3scout, "SwapEvent"),        "event/ export missing"
        assert hasattr(web3scout, "PairDetails"),      "data/ export missing"
        assert hasattr(web3scout, "BaseUtils"),        "utils/ export missing"
        assert hasattr(web3scout, "Token"),            "token/ export missing"
        assert hasattr(web3scout, "Deploy"),           "contract/ export missing"
        assert hasattr(web3scout, "FetchPairDetails"), "uniswap_v2/ export missing"
        assert hasattr(web3scout, "EventType"),        "enums/ export missing"
