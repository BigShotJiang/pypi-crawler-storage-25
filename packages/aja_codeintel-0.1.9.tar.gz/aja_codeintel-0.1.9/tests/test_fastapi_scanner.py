"""
Unit tests for the FastAPI scanner.

Each test uses in-memory Python source strings to avoid needing real files
on disk — the scanner accepts file paths as strings so we use tmp_path.
"""

from __future__ import annotations

import textwrap
import pytest
from pathlib import Path

from codeintel_cli.endpoints.fastapi_scanner import (
    FastApiScanner,
    scan_fastapi_project,
    extract_fastapi_endpoints,
    PydanticDTO,
    SQLAlchemyModel,
)
from codeintel_cli.endpoints.models import Endpoint


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write(tmp_path: Path, name: str, source: str) -> Path:
    f = tmp_path / name
    f.write_text(textwrap.dedent(source), encoding="utf-8")
    return f


def _scan(tmp_path: Path) -> tuple[list[Endpoint], list[PydanticDTO], list[SQLAlchemyModel]]:
    scanner = FastApiScanner()
    scanner.scan_files(list(tmp_path.rglob("*.py")))
    return scanner.resolve()


# ---------------------------------------------------------------------------
# 1. Basic endpoint detection
# ---------------------------------------------------------------------------

class TestBasicEndpoints:
    def test_app_get(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            app = FastAPI()

            @app.get("/users")
            def list_users():
                pass
        """)
        eps, _, _ = _scan(tmp_path)
        assert len(eps) == 1
        assert eps[0].method == "GET"
        assert eps[0].path == "/users"
        assert eps[0].handler == "list_users"
        assert eps[0].framework == "fastapi"

    def test_multiple_methods(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            app = FastAPI()

            @app.get("/items")
            def get_items(): pass

            @app.post("/items")
            def create_item(): pass

            @app.put("/items/{item_id}")
            def update_item(item_id: int): pass

            @app.delete("/items/{item_id}")
            def delete_item(item_id: int): pass

            @app.patch("/items/{item_id}")
            def patch_item(item_id: int): pass
        """)
        eps, _, _ = _scan(tmp_path)
        methods = {e.method for e in eps}
        assert methods == {"GET", "POST", "PUT", "DELETE", "PATCH"}

    def test_api_route_multi_method(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            app = FastAPI()

            @app.api_route("/ping", methods=["GET", "HEAD"])
            def ping(): pass
        """)
        eps, _, _ = _scan(tmp_path)
        methods = {e.method for e in eps}
        assert "GET" in methods
        assert "HEAD" in methods
        assert all(e.path == "/ping" for e in eps)

    def test_router_endpoints(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import APIRouter
            router = APIRouter()

            @router.get("/health")
            def health(): pass
        """)
        eps, _, _ = _scan(tmp_path)
        assert any(e.path == "/health" for e in eps)


# ---------------------------------------------------------------------------
# 2. APIRouter prefix resolution
# ---------------------------------------------------------------------------

class TestRouterPrefix:
    def test_router_prefix_applied(self, tmp_path):
        _write(tmp_path, "users.py", """\
            from fastapi import APIRouter
            router = APIRouter(prefix="/users")

            @router.get("/")
            def list_users(): pass

            @router.get("/{user_id}")
            def get_user(user_id: int): pass
        """)
        eps, _, _ = _scan(tmp_path)
        paths = {e.path for e in eps}
        # @router.get("/") + prefix="/users" normalises to /users (no trailing slash)
        assert "/users" in paths or "/users/" in paths
        assert "/users/{user_id}" in paths

    def test_include_router_prefix_stacking(self, tmp_path):
        _write(tmp_path, "users.py", """\
            from fastapi import APIRouter
            router = APIRouter(prefix="/users")

            @router.get("/")
            def list_users(): pass
        """)
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            from users import router

            app = FastAPI()
            app.include_router(router, prefix="/api/v1")
        """)
        eps, _, _ = _scan(tmp_path)
        paths = {e.path for e in eps}
        # Full resolved path: /api/v1 + /users + /
        assert any("/api/v1/users" in p for p in paths)

    def test_include_router_no_extra_prefix(self, tmp_path):
        _write(tmp_path, "items.py", """\
            from fastapi import APIRouter
            router = APIRouter(prefix="/items")

            @router.post("/")
            def create_item(): pass
        """)
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            from items import router
            app = FastAPI()
            app.include_router(router)
        """)
        eps, _, _ = _scan(tmp_path)
        paths = {e.path for e in eps}
        assert any("/items" in p for p in paths)


# ---------------------------------------------------------------------------
# 3. Response model and request body detection
# ---------------------------------------------------------------------------

class TestDTOLinking:
    def test_response_model_from_decorator(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            from pydantic import BaseModel

            app = FastAPI()

            class UserResponse(BaseModel):
                id: int
                name: str

            @app.get("/users", response_model=UserResponse)
            def list_users():
                pass
        """)
        eps, dtos, _ = _scan(tmp_path)
        ep = next(e for e in eps if e.path == "/users")
        # response_model stored in Endpoint.controller field (reused for metadata)
        # Check DTO was collected
        dto_names = {d.name for d in dtos}
        assert "UserResponse" in dto_names

    def test_request_body_detection(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            from pydantic import BaseModel

            app = FastAPI()

            class CreateUserRequest(BaseModel):
                name: str
                email: str

            @app.post("/users")
            def create_user(payload: CreateUserRequest):
                pass
        """)
        eps, dtos, _ = _scan(tmp_path)
        ep = next(e for e in eps if e.path == "/users")
        assert ep.controller == "CreateUserRequest"  # stored in controller field


# ---------------------------------------------------------------------------
# 4. Pydantic DTO extraction
# ---------------------------------------------------------------------------

class TestPydanticExtraction:
    def test_simple_model(self, tmp_path):
        _write(tmp_path, "schemas.py", """\
            from pydantic import BaseModel
            from typing import Optional

            class UserCreate(BaseModel):
                name: str
                email: str
                age: Optional[int] = None
        """)
        _, dtos, _ = _scan(tmp_path)
        dto = next(d for d in dtos if d.name == "UserCreate")
        field_map = {f.name: f for f in dto.fields}

        assert field_map["name"].required is True
        assert field_map["email"].required is True
        assert field_map["age"].required is False
        assert field_map["age"].default == "None"

    def test_optional_union_syntax(self, tmp_path):
        _write(tmp_path, "schemas.py", """\
            from pydantic import BaseModel

            class Item(BaseModel):
                title: str
                description: str | None = None
        """)
        _, dtos, _ = _scan(tmp_path)
        dto = next(d for d in dtos if d.name == "Item")
        field_map = {f.name: f for f in dto.fields}
        assert field_map["title"].required is True
        assert field_map["description"].required is False

    def test_field_with_default_factory(self, tmp_path):
        _write(tmp_path, "schemas.py", """\
            from pydantic import BaseModel, Field

            class Config(BaseModel):
                timeout: int = Field(default=30)
                name: str = Field(...)
        """)
        _, dtos, _ = _scan(tmp_path)
        dto = next(d for d in dtos if d.name == "Config")
        field_map = {f.name: f for f in dto.fields}
        assert field_map["timeout"].required is False
        assert field_map["name"].required is True

    def test_nested_model_bases(self, tmp_path):
        _write(tmp_path, "schemas.py", """\
            from pydantic import BaseModel

            class Base(BaseModel):
                id: int

            class UserOut(Base):
                name: str
        """)
        _, dtos, _ = _scan(tmp_path)
        names = {d.name for d in dtos}
        assert "Base" in names
        assert "UserOut" in names
        user_out = next(d for d in dtos if d.name == "UserOut")
        assert "Base" in user_out.bases

    def test_list_type_field(self, tmp_path):
        _write(tmp_path, "schemas.py", """\
            from pydantic import BaseModel
            from typing import List

            class TagList(BaseModel):
                tags: List[str]
                ids: list[int]
        """)
        _, dtos, _ = _scan(tmp_path)
        dto = next(d for d in dtos if d.name == "TagList")
        field_map = {f.name: f for f in dto.fields}
        assert "List[str]" in field_map["tags"].type
        assert "list[int]" in field_map["ids"].type


# ---------------------------------------------------------------------------
# 5. SQLAlchemy model extraction
# ---------------------------------------------------------------------------

class TestSQLAlchemyExtraction:
    def test_basic_model(self, tmp_path):
        _write(tmp_path, "models.py", """\
            from sqlalchemy import Column, Integer, String
            from sqlalchemy.orm import declarative_base

            Base = declarative_base()

            class User(Base):
                __tablename__ = "users"
                id = Column(Integer, primary_key=True)
                email = Column(String)
                name = Column(String)
        """)
        _, _, models = _scan(tmp_path)
        model = next(m for m in models if m.name == "User")
        assert model.table_name == "users"
        col_map = {c.name: c for c in model.columns}
        assert col_map["id"].primary_key is True
        assert "Integer" in col_map["id"].col_type
        assert col_map["email"].primary_key is False

    def test_foreign_key(self, tmp_path):
        _write(tmp_path, "models.py", """\
            from sqlalchemy import Column, Integer, String, ForeignKey
            from sqlalchemy.orm import declarative_base

            Base = declarative_base()

            class Post(Base):
                __tablename__ = "posts"
                id = Column(Integer, primary_key=True)
                user_id = Column(Integer, ForeignKey("users.id"))
                title = Column(String)
        """)
        _, _, models = _scan(tmp_path)
        model = next(m for m in models if m.name == "Post")
        col_map = {c.name: c for c in model.columns}
        assert col_map["user_id"].foreign_key == "users.id"

    def test_relationship(self, tmp_path):
        _write(tmp_path, "models.py", """\
            from sqlalchemy import Column, Integer, String
            from sqlalchemy.orm import relationship, declarative_base

            Base = declarative_base()

            class User(Base):
                __tablename__ = "users"
                id = Column(Integer, primary_key=True)
                posts = relationship("Post", back_populates="author")
        """)
        _, _, models = _scan(tmp_path)
        model = next(m for m in models if m.name == "User")
        rel_map = {r.name: r for r in model.relationships}
        assert "posts" in rel_map
        assert rel_map["posts"].target == "Post"

    def test_mapped_column_style(self, tmp_path):
        _write(tmp_path, "models.py", """\
            from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

            class Base(DeclarativeBase):
                pass

            class Product(Base):
                __tablename__ = "products"
                id: Mapped[int] = mapped_column(primary_key=True)
                name: Mapped[str] = mapped_column()
                price: Mapped[float] = mapped_column()
        """)
        _, _, models = _scan(tmp_path)
        model = next((m for m in models if m.name == "Product"), None)
        assert model is not None
        col_map = {c.name: c for c in model.columns}
        assert col_map["id"].primary_key is True


# ---------------------------------------------------------------------------
# 6. to_dict() schema compatibility (matches Java scanner output)
# ---------------------------------------------------------------------------

class TestOutputSchema:
    def test_endpoint_to_dict_keys(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            app = FastAPI()

            @app.get("/ping")
            def ping(): pass
        """)
        eps, _, _ = _scan(tmp_path)
        d = eps[0].to_dict()
        assert "method" in d
        assert "path" in d
        assert "file" in d
        assert "line" in d
        assert "handler" in d
        assert "framework" in d

    def test_dto_to_dict_keys(self, tmp_path):
        _write(tmp_path, "schemas.py", """\
            from pydantic import BaseModel

            class UserIn(BaseModel):
                name: str
        """)
        _, dtos, _ = _scan(tmp_path)
        d = dtos[0].to_dict()
        assert "name" in d
        assert "file" in d
        assert "kind" in d
        assert "bases" in d
        assert "fields" in d
        assert d["kind"] == "pydantic"

    def test_sqla_model_to_dict_keys(self, tmp_path):
        _write(tmp_path, "models.py", """\
            from sqlalchemy import Column, Integer
            from sqlalchemy.orm import declarative_base
            Base = declarative_base()

            class Order(Base):
                __tablename__ = "orders"
                id = Column(Integer, primary_key=True)
        """)
        _, _, models = _scan(tmp_path)
        d = models[0].to_dict()
        assert "name" in d
        assert "file" in d
        assert "kind" in d
        assert "table" in d
        assert "columns" in d
        assert "relationships" in d
        assert d["kind"] == "sqlalchemy"


# ---------------------------------------------------------------------------
# 7. extract_fastapi_endpoints (single-file, no prefix resolution)
# ---------------------------------------------------------------------------

class TestSingleFileExtractor:
    def test_basic(self):
        source = textwrap.dedent("""\
            from fastapi import FastAPI
            app = FastAPI()

            @app.get("/hello")
            def hello(): pass

            @app.post("/world")
            def world(): pass
        """)
        eps = extract_fastapi_endpoints(source, "main.py")
        assert len(eps) == 2
        paths = {e.path for e in eps}
        assert "/hello" in paths
        assert "/world" in paths

    def test_router_with_prefix(self):
        source = textwrap.dedent("""\
            from fastapi import APIRouter
            router = APIRouter(prefix="/v1")

            @router.get("/status")
            def status(): pass
        """)
        eps = extract_fastapi_endpoints(source, "api.py")
        assert len(eps) == 1
        assert eps[0].path == "/v1/status"

    def test_empty_source(self):
        eps = extract_fastapi_endpoints("", "empty.py")
        assert eps == []

    def test_syntax_error_source(self):
        eps = extract_fastapi_endpoints("def (: pass", "broken.py")
        assert eps == []


# ---------------------------------------------------------------------------
# 8. Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_async_endpoints(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            app = FastAPI()

            @app.get("/async")
            async def async_handler():
                pass
        """)
        eps, _, _ = _scan(tmp_path)
        assert any(e.handler == "async_handler" for e in eps)

    def test_multiple_routers_in_one_file(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI, APIRouter

            app = FastAPI()
            users_router = APIRouter(prefix="/users")
            items_router = APIRouter(prefix="/items")

            @users_router.get("/")
            def list_users(): pass

            @items_router.get("/")
            def list_items(): pass

            app.include_router(users_router)
            app.include_router(items_router)
        """)
        eps, _, _ = _scan(tmp_path)
        paths = {e.path for e in eps}
        assert any("/users" in p for p in paths)
        assert any("/items" in p for p in paths)

    def test_no_fastapi_files(self, tmp_path):
        _write(tmp_path, "utils.py", """\
            def add(a, b):
                return a + b
        """)
        eps, dtos, models = _scan(tmp_path)
        assert eps == []

    def test_path_params_preserved(self, tmp_path):
        _write(tmp_path, "main.py", """\
            from fastapi import FastAPI
            app = FastAPI()

            @app.get("/users/{user_id}/posts/{post_id}")
            def get_post(user_id: int, post_id: int): pass
        """)
        eps, _, _ = _scan(tmp_path)
        assert eps[0].path == "/users/{user_id}/posts/{post_id}"
