from __future__ import annotations
from pathlib import Path
import typer


def print_block(
    error,
    method: dict,
    project_root: Path,
    callers: list | None = None,
    callees: list | None = None,
) -> None:
    file_path = project_root / method["file_key"]
    try:
        lines = file_path.read_text(encoding="utf-8", errors="ignore").splitlines()
    except Exception:
        typer.echo(f"  [cannot read {method['file_key']}]")
        return

    start = max(0, method["start_line"] - 1)
    end = min(len(lines), method["end_line"])

    typer.echo("")
    typer.echo(typer.style("=" * 64, fg=typer.colors.RED))
    typer.echo(typer.style(f"  ERROR  {error.message}", fg=typer.colors.RED, bold=True))
    typer.echo(typer.style(f"  File   {method['file_key']}:{error.line}", fg=typer.colors.YELLOW))
    typer.echo(typer.style(f"  Method {method['class']}.{method['method']}()", fg=typer.colors.CYAN))
    typer.echo(typer.style("=" * 64, fg=typer.colors.RED))

    for i, line in enumerate(lines[start:end], start=start + 1):
        if i == error.line:
            typer.echo(typer.style(f">>> {i:4d}  {line}", fg=typer.colors.RED, bold=True))
        else:
            typer.echo(f"    {i:4d}  {line}")

    typer.echo(typer.style("=" * 64, fg=typer.colors.RED))

    if callers:
        typer.echo(typer.style("  Called by:", fg=typer.colors.MAGENTA))
        for c in callers[:5]:
            typer.echo(f"    <- {c}")
    if callees:
        typer.echo(typer.style("  Calls:", fg=typer.colors.BLUE))
        for c in callees[:5]:
            typer.echo(f"    -> {c}")
    typer.echo("")
