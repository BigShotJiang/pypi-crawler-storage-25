from __future__ import annotations
import re
from dataclasses import dataclass


@dataclass
class JavaError:
    file: str
    line: int
    message: str


_PATTERNS = [
    re.compile(r'^\[ERROR\]\s+(.+?\.java):\[(\d+),\d+\]\s+(.+)$'),
    re.compile(r'([A-Za-z0-9_/\\.\-]+\.java):(\d+):\s*error:\s*(.+)'),
    re.compile(r'\s+at\s+[\w.$]+\(([A-Za-z0-9_]+\.java):(\d+)\)'),
]


def parse_errors(output: str) -> list[JavaError]:
    errors = []
    seen = set()
    for line in output.splitlines():
        for pat in _PATTERNS:
            m = pat.search(line.strip())
            if m:
                groups = m.groups()
                file = Path_name(groups[0].strip())
                lineno = int(groups[1])
                msg = groups[2].strip() if len(groups) > 2 else ""
                if (file, lineno) not in seen:
                    seen.add((file, lineno))
                    errors.append(JavaError(file=file, line=lineno, message=msg))
                break
    return errors


def Path_name(s: str) -> str:
    return s.replace("\\", "/").split("/")[-1]
