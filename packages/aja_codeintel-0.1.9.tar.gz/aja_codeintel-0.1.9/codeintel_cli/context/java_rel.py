﻿from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Rel:
    kind: str
    target: str
    field: str
    cascade: str | None = None
    fetch: str | None = None
    mapped_by: str | None = None
    join_table: str | None = None
    join_columns: list[str] | None = None


_TYPE_RE = re.compile(r"\b(class|interface|enum|record)\s+([A-Za-z_][A-Za-z0-9_]*)\b")
_RECORD_RE = re.compile(r"\brecord\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)")
_FIELD_RE = re.compile(r"^\s*(?:public|protected|private)?\s*(?:static\s+)?(?:final\s+)?([A-Za-z0-9_<>\[\].,?]+)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:=.*)?;")
_REL_ANNOS = {"OneToOne", "OneToMany", "ManyToMany", "ManyToOne"}
_ANN_START_RE = re.compile(r"^\s*@([A-Za-z_][A-Za-z0-9_]*)\b(.*)$")
_JOINCOL_NAME_RE = re.compile(r'name\s*=\s*"([^"]+)"')
_QUOTED_RE = re.compile(r'^["\'](.*)["\']$')
_DENY_FIELD_NAMES = {"return", "this", "true", "false", "null", "new", "super", "throw", "serialversionuid", "log", "logger"}
_DENY_FIELD_TYPES = {
    "return", "throw", "stringbuilder", "stringbuffer",
    "logger", "log", "serialversionuid",
}
_COLLECTION_RE = re.compile(r"^(List|Set|Collection|Iterable|Map)\s*<\s*([^>]+)\s*>$")
_BASIC_TYPES = {
    "string","int","integer","long","double","float","boolean","byte","short","char",
    "object","void","datetime","localdatetime","localdate","instant","bigdecimal","uuid",
    "date","timestamp","number","biginteger","optional","map","hashmap","linkedhashmap",
    "stringbuilder","stringbuffer",
}

# Module-level cache: project_root_str -> set of class names
_known_types_cache: dict[str, set[str]] = {}


def clean_java(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//.*?$", "", text, flags=re.M)
    return text


def top_type_name(text: str, fallback: str) -> str:
    if not text:
        return fallback
    m = _TYPE_RE.search(text)
    return m.group(2) if m else fallback


def _find_project_root_for(path: Path) -> Path:
    for p in [path] + list(path.parents):
        for marker in ("pom.xml", "build.gradle", ".git", "pyproject.toml", "setup.py"):
            if (p / marker).exists():
                return p
    return path.parent


def collect_known_types(project_root: Path) -> set[str]:
    key = str(project_root.resolve())
    if key in _known_types_cache:
        return _known_types_cache[key]
    known: set[str] = set()
    root = project_root.resolve()
    skip = {".git", "target", "build", "out", ".gradle", "node_modules"}
    stack = [str(root)]
    while stack:
        cur = stack.pop()
        try:
            with os.scandir(cur) as it:
                for entry in it:
                    if entry.is_dir(follow_symlinks=False):
                        if entry.name not in skip:
                            stack.append(entry.path)
                    elif entry.is_file() and entry.name.endswith(".java"):
                        try:
                            with open(entry.path, "r", encoding="utf-8", errors="ignore") as f:
                                head = f.read(2048)
                            m = _TYPE_RE.search(head)
                            if m:
                                known.add(m.group(2))
                        except Exception:
                            continue
        except (PermissionError, FileNotFoundError):
            continue
    _known_types_cache[key] = known
    return known


def _collapse_annotations(text: str) -> str:
    lines = text.splitlines()
    result: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("@"):
            depth = stripped.count("(") - stripped.count(")")
            combined = stripped
            j = i + 1
            while depth > 0 and j < len(lines):
                nxt = lines[j].strip()
                combined = combined + " " + nxt
                depth += nxt.count("(") - nxt.count(")")
                j += 1
            result.append(combined)
            i = j
        else:
            result.append(line)
            i += 1
    return "\n".join(result)


def _split_record_params(sig: str) -> list[tuple[str, str]]:
    s = (sig or "").strip()
    if not s:
        return []
    parts: list[str] = []
    cur: list[str] = []
    depth = 0
    for ch in s:
        if ch == "<": depth += 1
        elif ch == ">": depth = max(0, depth - 1)
        elif ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if cur:
        parts.append("".join(cur).strip())
    out: list[tuple[str, str]] = []
    for p in parts:
        toks = p.split()
        if len(toks) >= 2:
            t = " ".join(toks[:-1]).strip()
            n = toks[-1].strip()
            if t and n:
                out.append((n, t))
    return out


def _strip_quotes(v: str | None) -> str | None:
    if not v:
        return None
    s = v.strip()
    m = _QUOTED_RE.match(s)
    if m:
        s = m.group(1).strip()
    return s or None


def _extract_arg_map(argstr: str) -> dict[str, str]:
    s = (argstr or "").strip()
    if not s:
        return {}
    out: dict[str, str] = {}
    cur: list[str] = []
    parts: list[str] = []
    depth = 0
    for ch in s:
        if ch == "(": depth += 1
        elif ch == ")": depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            parts.append("".join(cur).strip())
            cur = []
            continue
        cur.append(ch)
    if cur:
        parts.append("".join(cur).strip())
    for p in parts:
        if not p:
            continue
        if "=" in p:
            k, v = p.split("=", 1)
            out[k.strip()] = v.strip()
        else:
            out["value"] = p.strip()
    return out


def _unwrap_java_type(t: str) -> str:
    s = (t or "").strip()
    if not s:
        return ""
    s = s.replace("java.util.", "").replace("javax.persistence.", "").replace("jakarta.persistence.", "")
    m = re.match(r"^Optional\s*<\s*([^>]+)\s*>$", s)
    if m:
        s = m.group(1).strip()
    m = re.match(r"^(List|Set|Collection|Iterable)\s*<\s*([^>]+)\s*>$", s)
    if m:
        s = m.group(2).strip()
    if "." in s:
        s = s.split(".")[-1].strip()
    return s


def _infer_rel_from_field(ftype: str, fname: str, known_types: set[str]) -> Rel | None:
    s = ftype.strip()
    m_col = _COLLECTION_RE.match(s)
    if m_col:
        inner = m_col.group(2).strip()
        if "." in inner:
            inner = inner.split(".")[-1].strip()
        if inner.lower() not in _BASIC_TYPES and inner in known_types:
            return Rel(kind="OneToMany", target=inner, field=fname)
    raw = s
    if "." in raw:
        raw = raw.split(".")[-1].strip()
    if raw.lower() not in _BASIC_TYPES and raw in known_types:
        return Rel(kind="ManyToOne", target=raw, field=fname)
    return None


def java_fields_and_rels(path: Path) -> tuple[list[tuple[str, str, bool]], list[Rel]]:
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return [], []
    text = clean_java(raw)
    if not text:
        return [], []
    mrec = _RECORD_RE.search(text)
    if mrec:
        params = mrec.group(2)
        flds = [(n, t, n.lower() == "id") for (n, t) in _split_record_params(params)]
        return flds, []
    text = _collapse_annotations(text)
    lines = text.splitlines()
    fields: list[tuple[str, str, bool]] = []
    rels: list[Rel] = []
    pending: list[tuple[str, dict[str, str], str]] = []
    pending_is_id = False
    has_jpa = bool(re.search(r"@(OneToMany|ManyToOne|ManyToMany|OneToOne)\b", text))
    known_types: set[str] = set()
    if not has_jpa:
        root = _find_project_root_for(path)
        known_types = collect_known_types(root)
    for line in lines:
        s = line.strip()
        if not s:
            continue
        m = _ANN_START_RE.match(s)
        if m:
            name = m.group(1)
            rest = m.group(2).strip()
            full = rest
            if full.startswith("(") and full.endswith(")"):
                full = full[1:-1].strip()
            args = _extract_arg_map(full)
            if name == "Id":
                pending_is_id = True
            if name in _REL_ANNOS or name in {"JoinTable", "JoinColumn", "JoinColumns"}:
                pending.append((name, args, s))
            continue
        fm = _FIELD_RE.match(line)
        if not fm:
            pending.clear()
            pending_is_id = False
            continue
        ftype = fm.group(1).strip()
        fname = fm.group(2).strip()
        if not fname or fname.lower() in _DENY_FIELD_NAMES:
            pending.clear()
            pending_is_id = False
            continue
        if ftype.lower() in _DENY_FIELD_TYPES:
            pending.clear()
            pending_is_id = False
            continue
        is_pk = pending_is_id or fname.lower() == "id"
        fields.append((fname, ftype, is_pk))
        rel_kind: str | None = None
        rel_args: dict[str, str] = {}
        join_table: str | None = None
        join_cols: list[str] = []
        for aname, aargs, raw_line in pending:
            if aname in _REL_ANNOS:
                rel_kind = aname
                rel_args = aargs
            elif aname == "JoinTable":
                join_table = _strip_quotes(aargs.get("name") or aargs.get("value"))
                if not join_table:
                    mm = re.search(r'name\s*=\s*"([^"]+)"', raw_line)
                    if mm:
                        join_table = mm.group(1).strip()
            elif aname in {"JoinColumn", "JoinColumns"}:
                for mm in _JOINCOL_NAME_RE.finditer(raw_line):
                    join_cols.append(mm.group(1).strip())
        if rel_kind:
            target = _unwrap_java_type(ftype)
            if target:
                rels.append(Rel(kind=rel_kind, target=target, field=fname,
                    cascade=_strip_quotes(rel_args.get("cascade")),
                    fetch=_strip_quotes(rel_args.get("fetch")),
                    mapped_by=_strip_quotes(rel_args.get("mappedBy")),
                    join_table=join_table, join_columns=join_cols or None))
        elif not has_jpa and known_types:
            inferred = _infer_rel_from_field(ftype, fname, known_types)
            if inferred:
                rels.append(inferred)
        pending.clear()
        pending_is_id = False
    return fields, rels


def model_fields_from_extractor(path: Path, project_root: Path) -> list[tuple[str, str, bool]]:
    try:
        from ..lang.router import extract_models_for_file
        defs = extract_models_for_file(path, project_root)
        if not defs:
            return []
        d0 = defs[0]
        out: list[tuple[str, str, bool]] = []
        for f in getattr(d0, "fields", []) or []:
            name = (getattr(f, "name", "") or "").strip()
            typ = (getattr(f, "type", "") or "").strip() or "Object"
            if not name or name.lower() in _DENY_FIELD_NAMES or typ.lower() in _DENY_FIELD_TYPES:
                continue
            out.append((name, typ, name.lower() == "id"))
        return out
    except Exception:
        return []



