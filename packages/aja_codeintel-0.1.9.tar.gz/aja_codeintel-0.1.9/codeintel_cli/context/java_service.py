﻿from __future__ import annotations

from pathlib import Path
from typing import Any

from ..lang.java.ast_engine import (
    is_available as _ts_available,
    extract_class_info,
    extract_imports,
    extract_package,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SKIP_METHODS = {
    "equals", "hashCode", "toString", "clone",
    "getClass", "notify", "notifyAll", "wait",
}
_SKIP_TYPES = {
    "void", "public", "private", "protected", "static", "final",
    "return", "throw", "if", "else", "for", "while", "try", "catch",
    "new", "synchronized", "override",
}
_PRIMITIVES = {
    "String", "Long", "Integer", "Boolean", "List", "Set", "Map",
    "Optional", "Page", "Object", "ResponseEntity", "HttpStatus",
    "Collection", "Iterable",
}
_MAPPING_ANNS = {
    "GetMapping", "PostMapping", "PutMapping",
    "DeleteMapping", "PatchMapping", "RequestMapping",
}
_HTTP_VERB = {
    "GetMapping": "GET", "PostMapping": "POST", "PutMapping": "PUT",
    "DeleteMapping": "DELETE", "PatchMapping": "PATCH",
}
_REPO_BASE_TYPES = {
    "JpaRepository", "CrudRepository", "PagingAndSortingRepository",
    "MongoRepository", "Repository", "ListCrudRepository",
}
_SERVICE_ANNS = {"Service", "Component", "Transactional"}
_CONTROLLER_ANNS = {"Controller", "RestController"}
_CONTROLLER_SUFFIXES = ("Controller", "Resource", "RestController")
_CONTROLLER_DIRS = {"controller", "controllers", "web", "rest", "resource", "resources", "api"}
_ENTITY_ANNS = {"Entity", "MappedSuperclass", "Embeddable", "Table", "Document"}
_ENTITY_DIRS = {"model", "models", "entity", "entities", "domain", "core",
                # petclinic-style feature packages
                "owner", "vet", "pet", "visit"}
_DEFAULT_REPO_METHODS = [
    "findById(ID) -> Optional<T>",
    "save(T) -> T",
    "findAll() -> List<T>",
    "deleteById(ID)",
    "existsById(ID) -> boolean",
]


# ---------------------------------------------------------------------------
# File index helpers
# ---------------------------------------------------------------------------

def _get_all_java_files(project_root: Path) -> list[Path]:
    try:
        from ..db.cache import CacheManager
        with CacheManager(project_root) as cache:
            if cache.needs_rescan():
                cache.scan_project(verbose=False)
            return [p for p in cache.get_cached_files() if p.suffix.lower() == ".java"]
    except Exception:
        from ..scanner.scanner import find_all_supported_files
        return [p for p in find_all_supported_files(project_root) if p.suffix.lower() == ".java"]


def _build_stem_index(files: list[Path]) -> dict[str, list[Path]]:
    idx: dict[str, list[Path]] = {}
    for f in files:
        idx.setdefault(f.stem, []).append(f)
    return idx


def _strip_generics(t: str) -> str:
    return t.split("<")[0].strip()


# ---------------------------------------------------------------------------
# Controller / endpoint detection
# ---------------------------------------------------------------------------

def _is_controller_file(f: Path) -> bool:
    parts_lower = {p.lower() for p in f.parts}
    if parts_lower & _CONTROLLER_DIRS:
        return True
    return f.stem.endswith(_CONTROLLER_SUFFIXES)


def _extract_paths_from_ann(ann: dict) -> list[str]:
    """Extract path strings from a parsed annotation dict."""
    import re
    args = ann.get("args", "") or ""
    pairs = ann.get("pairs", {}) or {}

    for key in ("value", "path"):
        if key in pairs:
            v = pairs[key].strip().strip('"')
            if v:
                return [v]

    arr = re.search(r'\b(?:value|path)\s*=\s*\{([^}]+)\}', args, re.DOTALL)
    if arr:
        return re.findall(r'"([^"]+)"', arr.group(1))

    positional = re.findall(r'"([^"]+)"', args)
    if positional:
        return [positional[0]]

    return []


def _normalize_path(base: str, sub: str) -> str:
    base = (base or "").rstrip("/")
    sub = (sub or "").strip()
    if not sub:
        return base or "/"
    if not sub.startswith("/"):
        sub = "/" + sub
    result = base + sub
    return result if result.startswith("/") else "/" + result


def _find_controllers(all_files: list[Path], service_name: str) -> list[dict]:
    endpoints: list[dict] = []
    seen: set[tuple[str, str]] = set()

    controller_files = [f for f in all_files if _is_controller_file(f)]

    for f in controller_files:
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        # quick pre-filter: does this file reference the service at all?
        if service_name not in text:
            continue

        try:
            class_infos = extract_class_info(f)
        except Exception:
            continue

        for cls in class_infos:
            ann_names = cls.get("annotation_names", set())
            if not (ann_names & _CONTROLLER_ANNS):
                continue

            # class-level base path
            base_path = ""
            for ann in cls.get("annotations", []):
                if ann["name"] == "RequestMapping":
                    paths = _extract_paths_from_ann(ann)
                    if paths:
                        base_path = paths[0]
                        if not base_path.startswith("/"):
                            base_path = "/" + base_path
                    break

            for method in cls.get("methods", []):
                mapping_anns = [
                    a for a in method.get("annotations", [])
                    if a["name"] in _MAPPING_ANNS
                ]
                if not mapping_anns:
                    continue

                handler_name = method["name"]

                for ann in mapping_anns:
                    verb = _HTTP_VERB.get(ann["name"])
                    if ann["name"] == "RequestMapping":
                        import re
                        found = re.findall(r"RequestMethod\.([A-Z]+)", ann.get("args", "") or "")
                        verb = found[0] if found else "GET"
                    if not verb:
                        continue

                    paths = _extract_paths_from_ann(ann) or [""]
                    for p in paths:
                        full = _normalize_path(base_path, p)
                        import re
                        full = re.sub(r"/+", "/", full)
                        key = (verb, full)
                        if key in seen:
                            continue
                        seen.add(key)
                        endpoints.append({
                            "method": verb,
                            "path": full,
                            "handler": f"{f.stem}.{handler_name}()",
                        })

    return endpoints


# ---------------------------------------------------------------------------
# Model detection
# ---------------------------------------------------------------------------

def _is_entity_file(f: Path) -> bool:
    parts_lower = {p.lower() for p in f.parts}
    if parts_lower & _ENTITY_DIRS:
        return True
    # annotation-based fallback
    try:
        text = f.read_text(encoding="utf-8", errors="ignore")
        return any(f"@{a}" in text for a in _ENTITY_ANNS)
    except Exception:
        return False


def _find_models_used(
    service_file: Path,
    all_files: list[Path],
    stem_index: dict[str, list[Path]],
) -> dict[str, Any]:
    import re

    # collect candidate model names from imports + type references in source
    try:
        text = service_file.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        text = ""

    model_names: set[str] = set()

    # from imports
    for imp in extract_imports(service_file):
        last = imp.split(".")[-1]
        if last and last[0].isupper() and last not in _PRIMITIVES:
            model_names.add(last)

    # from inline type references
    for match in re.finditer(r"\b([A-Z][A-Za-z0-9_]+)\b", text):
        name = match.group(1)
        if len(name) > 2 and not name.isupper() and name not in _PRIMITIVES:
            model_names.add(name)

    models: dict[str, Any] = {}

    for model_name in model_names:
        for f in stem_index.get(model_name, []):
            if not _is_entity_file(f):
                continue
            try:
                class_infos = extract_class_info(f)
            except Exception:
                continue
            for cls in class_infos:
                if cls["name"] != model_name:
                    continue
                ann_names = cls.get("annotation_names", set())
                # must look like an entity (annotation OR has fields)
                if not (ann_names & _ENTITY_ANNS) and not cls.get("fields"):
                    continue
                fields = cls.get("fields", [])
                # resolve inherited fields if possible
                try:
                    from ..lang.java.models import extract_java_models, resolve_inherited_fields, ModelDef
                    all_models = []
                    for ff in all_files:
                        if _is_entity_file(ff):
                            all_models.extend(extract_java_models(ff, service_file.parent))
                    resolved = {m.name: m for m in resolve_inherited_fields(all_models)}
                    if model_name in resolved:
                        fields = [(fld.name, fld.type, fld.name.lower() == "id")
                                  for fld in resolved[model_name].fields]
                except Exception:
                    pass

                rels = []
                for fname, ftype, _ in fields:
                    base = _strip_generics(ftype)
                    if base and base[0].isupper() and base not in _PRIMITIVES:
                        rels.append({
                            "kind": "ref",
                            "target": base,
                            "field": fname,
                        })

                models[model_name] = {
                    "fields": fields,
                    "relationships": rels,
                }
                break
            if model_name in models:
                break

    return models


# ---------------------------------------------------------------------------
# Repository detection
# ---------------------------------------------------------------------------

def _find_repositories(
    service_file: Path,
    stem_index: dict[str, list[Path]],
) -> list[dict]:
    repos: list[dict] = []
    seen: set[str] = set()

    try:
        class_infos = extract_class_info(service_file)
    except Exception:
        return repos

    for cls in class_infos:
        # field injection
        for fname, ftype, _ in cls.get("fields", []):
            base = _strip_generics(ftype)
            if "Repository" in base or "repository" in fname.lower():
                if base not in seen:
                    seen.add(base)
                    repos.append({"name": base, "methods": _DEFAULT_REPO_METHODS[:]})

        # constructor injection (params)
        for method in cls.get("methods", []):
            if method["name"] == cls["name"][0].lower() + cls["name"][1:]:
                continue  # skip constructors themselves
            for pname, ptype in method.get("params", []):
                base = _strip_generics(ptype)
                if "Repository" in base and base not in seen:
                    seen.add(base)
                    repos.append({"name": base, "methods": _DEFAULT_REPO_METHODS[:]})

    # if the service file itself is a repository, skip base interface entries
    if "Repository" in service_file.stem:
        repos = [r for r in repos if r["name"] != service_file.stem]

    # also check imports for repository types
    for imp in extract_imports(service_file):
        last = imp.split(".")[-1]
        if "Repository" in last and last not in seen:
            seen.add(last)
            repos.append({"name": last, "methods": _DEFAULT_REPO_METHODS[:]})

    # try to extract actual methods from repo interface files
    for repo in repos:
        repo_name = repo["name"]
        for f in stem_index.get(repo_name, []):
            try:
                class_infos_r = extract_class_info(f)
            except Exception:
                continue
            for cls in class_infos_r:
                if cls["name"] != repo_name:
                    continue
                custom_methods = []
                for m in cls.get("methods", []):
                    ret = m.get("return_type", "")
                    params = ", ".join(
                        f"{_strip_generics(pt)} {pn}"
                        for pn, pt in m.get("params", [])
                    )
                    sig = f"{m['name']}({params})"
                    if ret:
                        sig += f" -> {ret}"
                    custom_methods.append(sig)
                if custom_methods:
                    repo["methods"] = custom_methods
                break

    return repos


# ---------------------------------------------------------------------------
# Service method extraction
# ---------------------------------------------------------------------------

def _extract_service_methods(class_info: dict) -> list[dict]:
    methods: list[dict] = []
    class_name = class_info.get("name", "")

    for m in class_info.get("methods", []):
        name = m.get("name", "")
        if not name or name in _SKIP_METHODS:
            continue
        # skip constructors
        if name == class_name:
            continue
        # skip setters
        if name.startswith("set") and m.get("params"):
            continue
        ret = m.get("return_type", "").strip()
        base_ret = _strip_generics(ret)
        if base_ret.lower() in {s.lower() for s in _SKIP_TYPES}:
            continue

        param_list = [
            f"{_strip_generics(pt)} {pn}"
            for pn, pt in m.get("params", [])
        ]

        methods.append({
            "name": name,
            "params": ", ".join(param_list),
            "return": ret,
        })

    return methods


# ---------------------------------------------------------------------------
# Top-level analyser
# ---------------------------------------------------------------------------

def _top_class_name(path: Path) -> str:
    try:
        class_infos = extract_class_info(path)
        if class_infos:
            return class_infos[0]["name"]
    except Exception:
        pass
    return path.stem


def analyze_java_service(service_file: Path, project_root: Path) -> dict:
    all_files = _get_all_java_files(project_root)
    stem_index = _build_stem_index(all_files)

    # resolve impl if this is an interface
    target_file = service_file
    try:
        class_infos = extract_class_info(service_file)
        if class_infos and class_infos[0]["kind"] == "interface":
            impl_candidates = stem_index.get(service_file.stem + "Impl", [])
            if impl_candidates:
                target_file = impl_candidates[0]
    except Exception:
        pass

    service_name = _top_class_name(service_file)

    # methods from the interface/class definition (not the impl)
    methods: list[dict] = []
    try:
        class_infos = extract_class_info(service_file)
        if class_infos:
            methods = _extract_service_methods(class_infos[0])
    except Exception:
        pass

    endpoints = _find_controllers(all_files, service_name)
    models    = _find_models_used(target_file, all_files, stem_index)
    repos     = _find_repositories(target_file, stem_index)

    return {
        "service_name": service_name,
        "endpoints":    endpoints,
        "methods":      methods,
        "models":       models,
        "repositories": repos,
        "summary": {
            "Endpoints":       len(endpoints),
            "Service methods": len(methods),
            "Models used":     len(models),
            "Repositories":    len(repos),
        },
    }

