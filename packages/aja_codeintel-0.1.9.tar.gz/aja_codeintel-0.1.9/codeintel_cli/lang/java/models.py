﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class ModelField:
    name: str
    type: str


@dataclass(frozen=True)
class ModelDef:
    name: str
    file: str
    kind: str
    bases: list[str]
    fields: list[ModelField]


# Annotations that indicate a class is a domain model
_MODEL_ANNOTATIONS = {
    "Entity", "MappedSuperclass", "Embeddable",
    "Table", "Document",
    "javax.persistence.Entity", "jakarta.persistence.Entity",
}

_SKIP_ANNOTATIONS = {
    "RestController", "Controller", "Service",
    "Repository", "Component", "Configuration",
    "SpringBootApplication",
}


def _is_model_class(info: dict) -> bool:
    ann = info.get("annotation_names", set())
    if ann & _SKIP_ANNOTATIONS:
        return False
    if ann & _MODEL_ANNOTATIONS:
        return True
    # Fallback: plain class with fields and no skip annotations
    kind = info.get("kind", "class")
    if kind in {"interface"}:
        return False
    return bool(info.get("fields"))


def extract_java_models(path: Path, project_root: Path) -> list[ModelDef]:
    from . import ast_engine
    try:
        rel = str(path.relative_to(project_root))
    except Exception:
        rel = str(path)

    try:
        class_infos = ast_engine.extract_class_info(path)
    except Exception:
        return []

    results: list[ModelDef] = []
    for info in class_infos:
        if not _is_model_class(info):
            continue
        fields = [ModelField(name=f[0], type=f[1]) for f in info["fields"]]
        results.append(ModelDef(
            name=info["name"],
            file=rel,
            kind=info["kind"],
            bases=info["bases"],
            fields=fields,
        ))
    return results


def resolve_inherited_fields(
    models: list[ModelDef],
) -> list[ModelDef]:
    """
    Second pass: merge fields from parent classes into child classes.
    Works for any depth of inheritance (BaseEntity -> NamedEntity -> Pet).
    Call this after scanning ALL files in the project.
    """
    by_name: dict[str, ModelDef] = {m.name: m for m in models}

    def _get_all_fields(model: ModelDef, visited: set[str]) -> list[ModelField]:
        if model.name in visited:
            return list(model.fields)
        visited.add(model.name)
        parent_fields: list[ModelField] = []
        for base in model.bases:
            if base in by_name:
                parent_fields.extend(_get_all_fields(by_name[base], visited))
        # own fields override parent fields with same name
        own_names = {f.name for f in model.fields}
        merged = [f for f in parent_fields if f.name not in own_names]
        merged.extend(model.fields)
        return merged

    resolved: list[ModelDef] = []
    for m in models:
        if m.bases:
            all_fields = _get_all_fields(m, set())
            resolved.append(ModelDef(
                name=m.name,
                file=m.file,
                kind=m.kind,
                bases=m.bases,
                fields=all_fields,
            ))
        else:
            resolved.append(m)
    return resolved
