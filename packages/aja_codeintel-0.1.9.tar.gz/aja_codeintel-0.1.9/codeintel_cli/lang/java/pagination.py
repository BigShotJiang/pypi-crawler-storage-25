﻿"""
Detects pagination style used in Spring project.
Looks for Spring Data Page/Pageable, custom wrappers, or plain lists.
"""
from __future__ import annotations
import re
from pathlib import Path


def detect_pagination(root: str) -> dict:
    """
    Returns {
        "style": "spring_data" | "custom" | "none",
        "shape": { content, totalElements, totalPages, ... } | None,
        "notes": [str],
    }
    """
    root_path = Path(root)
    result: dict = {
        "style": "none",
        "shape": None,
        "notes": [],
    }

    spring_data_hits = 0
    custom_hits = 0

    for f in root_path.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        # Spring Data standard
        if re.search(r"\bPage<|Pageable\b|PageRequest\b|PageImpl\b", text):
            spring_data_hits += 1
            result["notes"].append(f"Spring Data Pageable in {f.name}")

        # Custom pagination wrapper classes
        if re.search(r"\btotalElements\b|\btotalPages\b|\btotalCount\b", text):
            custom_hits += 1

    if spring_data_hits > 0:
        result["style"] = "spring_data"
        result["shape"] = {
            "content": "T[]",
            "totalElements": "number",
            "totalPages": "number",
            "number": "number (current page, 0-based)",
            "size": "number (page size)",
            "first": "boolean",
            "last": "boolean",
        }
    elif custom_hits > 0:
        result["style"] = "custom"
        result["notes"].append("Custom pagination wrapper detected (totalElements/totalPages fields found)")

    return result
