from __future__ import annotations
from pathlib import Path
import networkx as nx
from .method_index import load_index


def build_call_graph(index: dict) -> nx.DiGraph:
    G = nx.DiGraph()
    for file_key, methods in index.items():
        for m in methods:
            node = f"{m['class']}.{m['method']}"
            G.add_node(node, file=file_key)
            for called in m.get("calls", []):
                G.add_edge(node, called)
    return G


def get_related(G: nx.DiGraph, cls: str, method: str) -> dict:
    node = f"{cls}.{method}"
    if node not in G:
        return {"callers": [], "callees": []}
    return {
        "callers": list(G.predecessors(node)),
        "callees": list(G.successors(node)),
    }
