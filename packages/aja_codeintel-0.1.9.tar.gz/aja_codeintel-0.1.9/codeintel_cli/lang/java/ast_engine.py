from __future__ import annotations
from pathlib import Path
from typing import Optional

try:
    from tree_sitter import Language, Parser
    import tree_sitter_java as tsjava
    _JAVA_LANGUAGE = Language(tsjava.language())
    _parser = Parser(_JAVA_LANGUAGE)
    _TS_AVAILABLE = True
except Exception:
    _TS_AVAILABLE = False
    _parser = None
    _JAVA_LANGUAGE = None


def is_available() -> bool:
    return _TS_AVAILABLE


def parse_java_bytes(source: bytes):
    if not _TS_AVAILABLE:
        raise RuntimeError("tree-sitter-java not available")
    tree = _parser.parse(source)
    return tree.root_node


def parse_java_file(path: Path):
    return parse_java_bytes(path.read_bytes())


def _node_text(node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="ignore")


def _children_of_type(node, type_name: str):
    return [c for c in node.children if c.type == type_name]


def _first_child_of_type(node, type_name: str):
    for c in node.children:
        if c.type == type_name:
            return c
    return None


def _find_nodes(node, type_name: str) -> list:
    results = []
    stack = [node]
    while stack:
        cur = stack.pop()
        if cur.type == type_name:
            results.append(cur)
        stack.extend(reversed(cur.children))
    return results


def _find_nodes_shallow(node, type_name: str, stop_types: set) -> list:
    results = []
    stack = [node]
    while stack:
        cur = stack.pop()
        if cur.type == type_name:
            results.append(cur)
        if cur.type not in stop_types:
            stack.extend(reversed(cur.children))
    return results


# ---------------------------------------------------------------------------
# Annotation extraction
# ---------------------------------------------------------------------------

def _parse_annotation(node, source: bytes) -> dict:
    name = ""
    args_raw = ""
    pairs: dict[str, str] = {}

    for child in node.children:
        if child.type == "identifier":
            name = _node_text(child, source)
        elif child.type == "scoped_identifier":
            name = _node_text(child, source).split(".")[-1]
        elif child.type == "annotation_argument_list":
            args_raw = _node_text(child, source).strip("()")
            for pair in _find_nodes(child, "element_value_pair"):
                kn = _first_child_of_type(pair, "identifier")
                k = _node_text(kn, source) if kn else ""
                vals = [c for c in pair.children if c.type not in {"identifier", "="}]
                v = _node_text(vals[0], source).strip('"') if vals else ""
                pairs[k] = v

    return {"name": name, "args": args_raw, "pairs": pairs}


def _get_annotations(node, source: bytes) -> list[dict]:
    anns = []
    for child in node.children:
        if child.type == "modifiers":
            for mod in child.children:
                if mod.type in {"annotation", "marker_annotation"}:
                    anns.append(_parse_annotation(mod, source))
        if child.type in {"annotation", "marker_annotation"}:
            anns.append(_parse_annotation(child, source))
    return anns


def _annotation_names(node, source: bytes) -> set[str]:
    return {a["name"] for a in _get_annotations(node, source)}


# ---------------------------------------------------------------------------
# Package & imports
# ---------------------------------------------------------------------------

def extract_package(path: Path) -> str:
    if not _TS_AVAILABLE:
        import re
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"^\s*package\s+([\w\.]+)\s*;", text, re.MULTILINE)
            return m.group(1) if m else ""
        except Exception:
            return ""
    try:
        source = path.read_bytes()
        root = parse_java_bytes(source)
    except Exception:
        return ""
    for node in _find_nodes(root, "package_declaration"):
        for child in node.children:
            if child.type in {"identifier", "scoped_identifier"}:
                return _node_text(child, source)
    return ""


def extract_imports(path: Path) -> list[str]:
    if not _TS_AVAILABLE:
        import re
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
            return re.findall(r"^\s*import\s+([\w\.]+)\s*;", text, re.MULTILINE)
        except Exception:
            return []
    try:
        source = path.read_bytes()
        root = parse_java_bytes(source)
    except Exception:
        return []
    out: list[str] = []
    for node in _find_nodes(root, "import_declaration"):
        for child in node.children:
            if child.type in {"identifier", "scoped_identifier"}:
                out.append(_node_text(child, source))
    return out


# ---------------------------------------------------------------------------
# Class info
# ---------------------------------------------------------------------------

_ENTITY_ANNOTATIONS = {
    "Entity", "MappedSuperclass", "Embeddable",
    "Table", "Document", "Aggregate",
    "javax.persistence.Entity", "jakarta.persistence.Entity",
}

_CONTROLLER_ANNOTATIONS = {
    "Controller", "RestController",
    "RequestMapping",
}


def extract_class_info(path: Path) -> list[dict]:
    if not _TS_AVAILABLE:
        return _extract_class_info_regex(path)

    try:
        source = path.read_bytes()
        root = parse_java_bytes(source)
    except Exception:
        return []

    results = []

    TYPE_NODES = {
        "class_declaration", "interface_declaration",
        "enum_declaration", "record_declaration",
    }

    for node in root.children:
        if node.type not in TYPE_NODES:
            for child in node.children:
                if child.type in TYPE_NODES:
                    info = _extract_single_class(child, source)
                    if info:
                        results.append(info)
            if node.type in TYPE_NODES:
                info = _extract_single_class(node, source)
                if info:
                    results.append(info)
        else:
            info = _extract_single_class(node, source)
            if info:
                results.append(info)

    if not results:
        for node in _find_nodes(root, "class_declaration")[:3]:
            info = _extract_single_class(node, source)
            if info:
                results.append(info)

    return results


def _extract_single_class(node, source: bytes) -> Optional[dict]:
    TYPE_MAP = {
        "class_declaration": "class",
        "interface_declaration": "interface",
        "enum_declaration": "enum",
        "record_declaration": "record",
    }
    kind = TYPE_MAP.get(node.type, "class")

    name = ""
    id_nodes = _children_of_type(node, "identifier")
    if id_nodes:
        name = _node_text(id_nodes[0], source)
    if not name:
        return None

    anns = _get_annotations(node, source)
    ann_names = {a["name"] for a in anns}

    bases: list[str] = []
    sc = _first_child_of_type(node, "superclass")
    if sc:
        for t in sc.children:
            if t.type in {"type_identifier", "generic_type", "scoped_type_identifier"}:
                bases.append(_node_text(t, source).split("<")[0])
    si = _first_child_of_type(node, "super_interfaces")
    if si:
        for t in _find_nodes(si, "type_identifier"):
            bases.append(_node_text(t, source).split("<")[0])

    fields = _extract_fields_from_class_node(node, source)
    methods = _extract_methods_from_class_node(node, source)

    return {
        "name": name,
        "kind": kind,
        "bases": bases,
        "annotations": anns,
        "annotation_names": ann_names,
        "fields": fields,
        "methods": methods,
        "line": node.start_point[0] + 1,
    }


def _extract_fields_from_class_node(class_node, source: bytes) -> list[tuple]:
    fields: list[tuple] = []

    body_node = None
    for n in ["class_body", "interface_body", "enum_body", "record_body"]:
        body_node = _first_child_of_type(class_node, n)
        if body_node:
            break
    if not body_node:
        return fields

    for decl in _children_of_type(body_node, "field_declaration"):
        ann_names = _annotation_names(decl, source)
        mod_texts: set[str] = set()
        for mod in _children_of_type(decl, "modifiers"):
            mod_texts.update(_node_text(m, source) for m in mod.children)
        if "static" in mod_texts:
            continue

        is_id = "Id" in ann_names or "EmbeddedId" in ann_names

        type_node = None
        for child in decl.children:
            if child.type not in {"modifiers", "variable_declarator", ";", ","}:
                type_node = child
                break
        if not type_node:
            continue
        ftype = _node_text(type_node, source).strip()

        for var in _children_of_type(decl, "variable_declarator"):
            idn = _first_child_of_type(var, "identifier")
            if idn:
                fname = _node_text(idn, source).strip()
                fields.append((fname, ftype, is_id or fname.lower() == "id"))

    rec_header = _first_child_of_type(class_node, "formal_parameters")
    if rec_header:
        for param in _find_nodes(rec_header, "formal_parameter"):
            type_nodes = [c for c in param.children if c.type not in {"modifiers", "identifier", ","}]
            idn = None
            for c in reversed(param.children):
                if c.type == "identifier":
                    idn = c
                    break
            if type_nodes and idn:
                ftype = _node_text(type_nodes[0], source).strip()
                fname = _node_text(idn, source).strip()
                fields.append((fname, ftype, fname.lower() == "id"))

    return fields


def _extract_methods_from_class_node(class_node, source: bytes) -> list[dict]:
    methods: list[dict] = []

    body_node = None
    for n in ["class_body", "interface_body", "enum_body"]:
        body_node = _first_child_of_type(class_node, n)
        if body_node:
            break
    if not body_node:
        return methods

    for decl in _children_of_type(body_node, "method_declaration"):
        anns = _get_annotations(decl, source)
        ann_names = {a["name"] for a in anns}

        idn = _first_child_of_type(decl, "identifier")
        if not idn:
            continue
        mname = _node_text(idn, source)

        ret_type = ""
        for child in decl.children:
            if child.type not in {"modifiers", "identifier", "formal_parameters",
                                   "block", "throws", ";"}:
                ret_type = _node_text(child, source).strip()
                break

        params: list[tuple[str, str]] = []
        fp = _first_child_of_type(decl, "formal_parameters")
        if fp:
            for param in _find_nodes(fp, "formal_parameter"):
                p_type_nodes = [c for c in param.children
                                if c.type not in {"modifiers", "identifier", ",",
                                                   "variable_arity_parameter"}]
                p_idn = None
                for c in reversed(param.children):
                    if c.type == "identifier":
                        p_idn = c
                        break
                if p_type_nodes and p_idn:
                    params.append((_node_text(p_idn, source), _node_text(p_type_nodes[0], source)))

        methods.append({
            "name": mname,
            "return_type": ret_type,
            "annotations": anns,
            "annotation_names": ann_names,
            "params": params,
            "line": decl.start_point[0] + 1,
        })

    return methods


# ---------------------------------------------------------------------------
# Regex fallbacks
# ---------------------------------------------------------------------------

def _extract_class_info_regex(path: Path) -> list[dict]:
    import re
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    results = []
    class_re = re.compile(
        r"(?:@[\w]+(?:\([^)]*\))?\s*)*"
        r"(?:public\s+|protected\s+|private\s+)?"
        r"(?:abstract\s+|final\s+)?"
        r"(class|interface|enum|record)\s+([A-Za-z_]\w*)"
        r"(?:\s+extends\s+([\w,\s<>]+?))?(?:\s+implements\s+([\w,\s<>]+?))?"
        r"\s*\{"
    )
    field_re = re.compile(
        r"^\s*(?:@\w+(?:\([^)]*\))?\s*)*"
        r"(?:(?:public|protected|private)\s+)?"
        r"(?:(?:static|final)\s+)*"
        r"([A-Za-z0-9_<>\[\].,?]+)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:=.*)?;"
    )
    ann_re = re.compile(r"@([A-Za-z_]\w*)(?:\([^)]*\))?")

    for m in class_re.finditer(text):
        kind = m.group(1)
        name = m.group(2)
        bases = []
        if m.group(3):
            bases += [b.strip().split("<")[0] for b in m.group(3).split(",")]
        if m.group(4):
            bases += [b.strip().split("<")[0] for b in m.group(4).split(",")]

        pre = text[:m.start()]
        ann_names = set(ann_re.findall(pre[-300:]))
        anns = [{"name": a, "args": "", "pairs": {}} for a in ann_names]

        fields = []
        for fm in field_re.finditer(text[m.start():]):
            ftype = fm.group(1).strip()
            fname = fm.group(2).strip()
            if ftype.lower() not in {"return", "throw", "new"}:
                fields.append((fname, ftype, fname.lower() == "id"))

        results.append({
            "name": name,
            "kind": kind,
            "bases": [b for b in bases if b],
            "annotations": anns,
            "annotation_names": ann_names,
            "fields": fields,
            "methods": [],
            "line": text[:m.start()].count("\n") + 1,
        })

    return results


# ---------------------------------------------------------------------------
# Convenience wrappers
# ---------------------------------------------------------------------------

def extract_classes(path: Path) -> list[str]:
    return [c["name"] for c in extract_class_info(path)]


def extract_fields_ts(path: Path) -> list[tuple[str, str, bool]]:
    infos = extract_class_info(path)
    if infos:
        return infos[0]["fields"]
    return []