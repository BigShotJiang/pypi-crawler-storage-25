from __future__ import annotations
import json
from pathlib import Path
from .ast_engine import extract_class_info

INDEX_PATH = ".codeinteel/method_index.json"


def _index_path(project_root: Path) -> Path:
    return project_root / INDEX_PATH


def _index_file(java_file: Path, project_root: Path, index: dict) -> None:
    try:
        classes = extract_class_info(java_file)
        total_lines = len(java_file.read_text(encoding="utf-8", errors="ignore").splitlines())
        methods = []
        for cls in classes:
            cls_methods = cls.get("methods", [])
            for i, m in enumerate(cls_methods):
                start = m["line"]
                if i + 1 < len(cls_methods):
                    end = cls_methods[i + 1]["line"] - 1
                else:
                    end = total_lines
                methods.append({
                    "class": cls["name"],
                    "method": m["name"],
                    "start_line": start,
                    "end_line": end,
                    "calls": [],
                })
        rel = str(java_file.relative_to(project_root)).replace("\\", "/")
        index[rel] = methods
    except Exception:
        pass


def build_index(project_root: Path) -> dict:
    index = {}
    for java_file in project_root.rglob("*.java"):
        _index_file(java_file, project_root, index)
    return index


def save_index(project_root: Path, index: dict) -> None:
    p = _index_path(project_root)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(index, indent=2), encoding="utf-8")


def load_index(project_root: Path) -> dict:
    p = _index_path(project_root)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def update_file(project_root: Path, java_file: Path) -> None:
    index = load_index(project_root)
    _index_file(java_file, project_root, index)
    save_index(project_root, index)


def find_method_at_line(index: dict, filename: str, line: int) -> dict | None:
    filename = filename.replace("\\", "/").split("/")[-1]
    best = None
    best_dist = None
    for key, methods in index.items():
        if Path(key).name != filename:
            continue
        for m in methods:
            if m["start_line"] <= line <= m["end_line"]:
                return {"file_key": key, **m}
            dist = min(abs(line - m["start_line"]), abs(line - m["end_line"]))
            if best_dist is None or dist < best_dist:
                best_dist = dist
                best = {"file_key": key, **m}
    return best
