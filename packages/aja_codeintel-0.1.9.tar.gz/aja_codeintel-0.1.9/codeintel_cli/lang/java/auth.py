﻿"""
Detects authentication mechanism from Spring Security config.
Looks for: JWT filters, HttpSession, OAuth2, or no auth (PUBLIC).
"""
from __future__ import annotations
import re
from pathlib import Path


def detect_auth(root: str) -> dict:
    root_path = Path(root)
    result: dict = {
        "type": "NONE",
        "token_transport": None,
        "header_name": None,
        "scheme": None,
        "notes": [],
    }

    for f in root_path.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        if re.search(r"oauth2Login|OAuth2UserService|OAuth2AuthorizedClient", text):
            result["type"] = "OAUTH2"
            result["token_transport"] = "cookie"
            result["notes"].append(f"OAuth2 detected in {f.name}")

        if re.search(r"JwtDecoder|JwtAuthenticationFilter|parseClaimsJws|validateToken|JwtTokenProvider|JwtUtils", text):
            result["type"] = "JWT"
            result["token_transport"] = "header"
            result["header_name"] = "Authorization"
            result["scheme"] = "Bearer"
            result["notes"].append(f"JWT detected in {f.name}")

        if re.search(r"HttpSession|SessionCreationPolicy\.ALWAYS|SessionCreationPolicy\.IF_REQUIRED", text):
            if result["type"] == "NONE":
                result["type"] = "SESSION"
                result["token_transport"] = "cookie"
                result["notes"].append(f"Session auth detected in {f.name}")

        if re.search(r"SessionCreationPolicy\.STATELESS", text):
            if "STATELESS" not in " ".join(result["notes"]):
                result["notes"].append(f"Stateless session policy in {f.name}")

    return result
