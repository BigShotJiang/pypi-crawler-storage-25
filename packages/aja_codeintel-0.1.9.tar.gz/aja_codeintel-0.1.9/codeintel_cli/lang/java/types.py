﻿from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re

@dataclass(frozen=True)
class TypeField:
    name: str
    type: str

@dataclass(frozen=True)
class TypeDef:
    name: str
    file: str
    kind: str
    tag: str
    category: str
    fields: list[TypeField]
    bases: list[str]

_REQ_KEYS = ("request", "create", "update", "input", "payload", "command", "param", "params", "form", "login", "register", "managed")
_RES_KEYS = ("response", "result", "output", "view", "data", "error", "field")

_HARD_EXCLUDE_SUFFIXES = (
    "Controller", "RestController", "Service", "ServiceImpl",
    "Repository", "Config", "Configuration",
    "Handler", "Filter", "Interceptor", "Listener",
    "Scheduler", "Factory", "Mapper",
    "Exception", "Error", "Test", "Tests", "IT",
)

_DTO_NAME_SUFFIXES = (
    "Dto", "DTO", "Request", "Response", "Payload",
    "Input", "Output", "Command", "Result", "View", "Form", "Body",
    "Message", "Event", "Query", "Vo", "VO", "VM", "Vm",
    "Transfer", "Contract", "Projection", "Summary",
    "Detail", "Info", "Spec",
)

_DTO_DIRS = {
    "dto", "dtos", "payload", "payloads", "transfer",
    "vo", "vos", "vm", "vms",
    "contract", "contracts",
    "request", "response", "requests", "responses",
    "projection", "projections",
}

_HARD_EXCLUDE_DIRS = {
    "repository", "repositories", "config", "configuration",
    "security", "migration", "migrations", "test", "tests",
    "mapper", "mappers",
}

_ENTITY_ANNOTATIONS = {"Entity", "Table", "Document"}
_BASE_CLASS_ANNOTATIONS = {"MappedSuperclass", "Embeddable"}

_INFRA_ANNOTATIONS = {
    "Service", "Controller", "RestController", "Repository",
    "Component", "SpringBootApplication", "Configuration",
}

_DTO_ANNOTATIONS = {
    "Data", "Value", "JsonProperty", "JsonIgnoreProperties",
    "NotNull", "NotBlank", "NotEmpty", "Size", "Min", "Max",
    "Email", "Valid", "Validated", "Pattern", "JsonInclude",
    "JsonNaming", "AllArgsConstructor", "NoArgsConstructor",
    "RequiredArgsConstructor", "Builder",
}

_FORM_BINDING_ANNOTATIONS = {
    "NotNull", "NotBlank", "NotEmpty", "Size", "Min", "Max",
    "Email", "Valid", "Validated", "Pattern",
    "DateTimeFormat", "NumberFormat",
}

_LOMBOK_ANNOTATIONS = {
    "Data", "Value", "Builder", "Getter", "Setter",
    "AllArgsConstructor", "NoArgsConstructor", "RequiredArgsConstructor",
}

_JACKSON_ANNOTATIONS = {
    "JsonProperty", "JsonAlias", "JsonIgnoreProperties",
    "JsonInclude", "JsonNaming",
}

_VALIDATION_ANNOTATIONS = {
    "NotNull", "NotBlank", "NotEmpty", "Size", "Min", "Max",
    "Email", "Valid", "Validated", "Pattern",
}

_interface_method_re = re.compile(
    r"^\s+([A-Za-z_][\w<>\[\]., ?]+)\s+get([A-Z]\w*)\s*\(\s*\)\s*;", re.M
)


def _parts_lower(p: Path) -> set[str]:
    return {part.lower() for part in p.parts}


def _has_form_binding(src: str) -> bool:
    return any(f"@{a}" in src for a in _FORM_BINDING_ANNOTATIONS)


def _is_dto_type(p: Path, ann_names: set[str], kind: str) -> bool:
    if p.suffix != ".java":
        return False
    if p.name == "package-info.java":
        return False

    parts = _parts_lower(p)
    stem = p.stem

    if parts & _HARD_EXCLUDE_DIRS:
        return False
    if any(stem.endswith(s) for s in _HARD_EXCLUDE_SUFFIXES):
        return False
    if ann_names & _INFRA_ANNOTATIONS:
        return False
    if ann_names & _ENTITY_ANNOTATIONS:
        return False
    if ann_names & _BASE_CLASS_ANNOTATIONS:
        return False

    if parts & _DTO_DIRS:
        return True
    if any(stem.endswith(s) for s in _DTO_NAME_SUFFIXES):
        return True
    if kind == "record":
        return True
    if ann_names & _DTO_ANNOTATIONS:
        return True
    if kind == "interface":
        return True

    return False


def _is_form_entity(p: Path, ann_names: set[str], src: str) -> bool:
    if p.suffix != ".java":
        return False
    if p.name == "package-info.java":
        return False

    parts = _parts_lower(p)
    stem = p.stem

    if parts & _HARD_EXCLUDE_DIRS:
        return False
    if any(stem.endswith(s) for s in _HARD_EXCLUDE_SUFFIXES):
        return False
    if ann_names & _INFRA_ANNOTATIONS:
        return False
    if ann_names & _BASE_CLASS_ANNOTATIONS:
        return False

    if ann_names & _ENTITY_ANNOTATIONS:
        return _has_form_binding(src)

    return False


def _classify(rel_path: str, name: str) -> str:
    r = rel_path.lower().replace("\\", "/")
    n = name.lower()

    if any(k in n for k in _REQ_KEYS):
        return "request"
    if any(k in n for k in _RES_KEYS):
        return "response"

    if "/request/" in r or "/requests/" in r or "/vm/" in r or r.endswith("/request"):
        return "request"
    if "/response/" in r or "/responses/" in r or "/errors/" in r or r.endswith("/response"):
        return "response"

    return "other"


def _build_tag(ann_names: set[str], kind: str) -> str:
    tags = []
    if ann_names & _LOMBOK_ANNOTATIONS:
        tags.append("@Lombok")
    if ann_names & _VALIDATION_ANNOTATIONS:
        tags.append("@Validated")
    if ann_names & _JACKSON_ANNOTATIONS:
        tags.append("@Jackson")
    if ann_names & _ENTITY_ANNOTATIONS:
        tags.append("@Entity")
    return " ".join(tags) if tags else kind


def _extract_from_file(path: Path, project_root: Path, entity_mode: bool) -> list[TypeDef]:
    from . import ast_engine

    try:
        rel = str(path.relative_to(project_root))
    except Exception:
        rel = str(path)

    try:
        class_infos = ast_engine.extract_class_info(path)
    except Exception:
        return []

    try:
        src = path.read_bytes().decode("utf-8-sig", errors="replace")
    except Exception:
        src = ""

    results: list[TypeDef] = []

    for info in class_infos:
        ann_names: set[str] = info.get("annotation_names", set())
        kind: str = info.get("kind", "class")
        raw_fields: list[tuple] = info.get("fields", [])
        bases: list[str] = info.get("bases", [])

        if kind == "interface":
            if not _interface_method_re.search(src):
                continue

        is_dto = _is_dto_type(path, ann_names, kind)
        is_entity = entity_mode and _is_form_entity(path, ann_names, src)

        if not is_dto and not is_entity:
            continue

        fields = [TypeField(name=f[0], type=f[1]) for f in raw_fields]
        tag = _build_tag(ann_names, kind)
        category = _classify(rel, info["name"])

        results.append(TypeDef(
            name=info["name"],
            file=rel,
            kind=kind,
            tag=tag,
            category=category,
            fields=fields,
            bases=bases,
        ))

    return results


def resolve_inherited_fields(types: list[TypeDef]) -> list[TypeDef]:
    by_name: dict[str, TypeDef] = {t.name: t for t in types}

    def _get_all_fields(t: TypeDef, visited: set[str]) -> list[TypeField]:
        if t.name in visited:
            return list(t.fields)
        visited.add(t.name)
        parent_fields: list[TypeField] = []
        for base in t.bases:
            if base in by_name:
                parent_fields.extend(_get_all_fields(by_name[base], visited))
        own_names = {f.name for f in t.fields}
        merged = [f for f in parent_fields if f.name not in own_names]
        merged.extend(t.fields)
        return merged

    resolved: list[TypeDef] = []
    for t in types:
        if t.bases:
            all_fields = _get_all_fields(t, set())
            resolved.append(TypeDef(
                name=t.name,
                file=t.file,
                kind=t.kind,
                tag=t.tag,
                category=t.category,
                fields=all_fields,
                bases=t.bases,
            ))
        else:
            resolved.append(t)
    return resolved


def extract_java_types(path: Path, project_root: Path, entity_mode: bool = False) -> list[TypeDef]:
    return _extract_from_file(path, project_root, entity_mode)


def scan_java_types(paths: list[Path], project_root: Path) -> list[TypeDef]:
    results: list[TypeDef] = []
    for p in paths:
        results.extend(_extract_from_file(p, project_root, entity_mode=False))

    if not results:
        for p in paths:
            results.extend(_extract_from_file(p, project_root, entity_mode=True))

    results = resolve_inherited_fields(results)
    return results
