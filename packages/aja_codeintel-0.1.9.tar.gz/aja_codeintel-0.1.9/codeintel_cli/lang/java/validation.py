﻿"""
Extracts Bean Validation constraints (@NotNull, @Size, @Email, etc.)
from Java model/entity fields using regex.
"""
from __future__ import annotations
import re
from pathlib import Path
from collections import defaultdict

_CONSTRAINT_NAMES = (
    "NotNull", "NotBlank", "NotEmpty", "Email",
    "Positive", "PositiveOrZero", "Negative", "NegativeOrZero",
    "Size", "Length", "Min", "Max", "Pattern", "Digits",
    "DecimalMin", "DecimalMax", "Future", "Past", "FutureOrPresent", "PastOrPresent",
    "AssertTrue", "AssertFalse",
)

_ANN_RE = re.compile(
    r"@(" + "|".join(_CONSTRAINT_NAMES) + r")\s*(?:\(([^)]*)\))?",
)

_FIELD_BLOCK_RE = re.compile(
    r"((?:@[\w]+(?:\s*\([^)]*\))?\s*\n?\s*)+)"
    r"(?:private|protected|public)\s+"
    r"(?:(?:static|final)\s+)*"
    r"([\w<>\[\].,?\s]+?)\s+"
    r"(\w+)\s*;",
    re.MULTILINE,
)

_CLASS_RE = re.compile(r"(?:class|record|interface)\s+(\w+)")


def extract_validation(root: str) -> dict:
    """Returns {ClassName: {fieldName: [constraint_strings]}}"""
    root_path = Path(root)
    result: dict = {}

    trigger_anns = {f"@{n}" for n in _CONSTRAINT_NAMES}

    for f in root_path.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        if not any(a in text for a in trigger_anns):
            continue

        cm = _CLASS_RE.search(text)
        class_name = cm.group(1) if cm else f.stem
        field_constraints: dict = defaultdict(list)

        for m in _FIELD_BLOCK_RE.finditer(text):
            ann_block = m.group(1)
            field_name = m.group(3)
            constraints = []
            for am in _ANN_RE.finditer(ann_block):
                ann_name = am.group(1)
                raw_params = (am.group(2) or "").strip()
                params: dict = {}
                for kv in re.finditer(r"(\w+)\s*=\s*([^,)]+)", raw_params):
                    params[kv.group(1).strip()] = kv.group(2).strip().strip('"')
                if not params and raw_params:
                    params["value"] = raw_params.strip('"')
                entry = ann_name
                if params:
                    entry += "(" + ", ".join(f"{k}={v}" for k, v in params.items()) + ")"
                constraints.append(entry)
            if constraints:
                field_constraints[field_name].extend(constraints)

        if field_constraints:
            result[class_name] = dict(field_constraints)

    return result
