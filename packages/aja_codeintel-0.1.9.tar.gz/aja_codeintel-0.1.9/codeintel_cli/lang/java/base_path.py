﻿"""
Detects global API base path prefix from Spring config.
Checks: application.properties/yml server.servlet.context-path,
        @RequestMapping on controllers, spring.mvc.servlet.path.
"""
from __future__ import annotations
import re
from pathlib import Path


_CONTEXT_PATH_RE = re.compile(
    r"server\.servlet\.context-path\s*[=:]\s*([^\s#\n]+)"
)
_SERVLET_PATH_RE = re.compile(
    r"spring\.mvc\.servlet\.path\s*[=:]\s*([^\s#\n]+)"
)
_SPRING_WEBFLUX_RE = re.compile(
    r"spring\.webflux\.base-path\s*[=:]\s*([^\s#\n]+)"
)


def detect_base_path(root: str) -> dict:
    """
    Returns {
        "base_path": str | None,   # e.g. "/api" or "/api/v1"
        "source": str | None,
    }
    """
    root_path = Path(root)
    result: dict = {"base_path": None, "source": None}

    # 1. Check properties / yml files first (most reliable)
    for pattern in ("**/*.properties", "**/*.yml", "**/*.yaml"):
        for f in root_path.rglob(pattern):
            if any(x in f.parts for x in ("test", "target", "build", "node_modules")):
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            for rx in (_CONTEXT_PATH_RE, _SERVLET_PATH_RE, _SPRING_WEBFLUX_RE):
                m = rx.search(text)
                if m:
                    val = m.group(1).strip().strip("'\"")
                    if val and val != "/":
                        result["base_path"] = val if val.startswith("/") else "/" + val
                        result["source"] = f.name
                        return result

    # 2. Look for a common @RequestMapping prefix on ALL controllers
    controller_bases: list[str] = []
    for f in root_path.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if "@RestController" not in text and "@Controller" not in text:
            continue
        m = re.search(
            r"@RequestMapping\s*\(\s*(?:value\s*=\s*)?[\"']([^\"']+)[\"']",
            text,
        )
        if m:
            controller_bases.append(m.group(1))

    if controller_bases:
        # Find common prefix shared by majority of controllers
        from collections import Counter
        prefixes = [p.split("/")[1] if "/" in p else p for p in controller_bases]
        common = Counter(prefixes).most_common(1)
        if common and common[0][1] >= max(2, len(controller_bases) // 2):
            prefix = "/" + common[0][0]
            result["base_path"] = prefix
            result["source"] = "controller @RequestMapping pattern"

    return result
