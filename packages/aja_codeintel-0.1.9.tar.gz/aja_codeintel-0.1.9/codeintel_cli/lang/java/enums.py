﻿"""
Extracts Java enum types and their constant values from the project.
"""
from __future__ import annotations
import re
from pathlib import Path

_ENUM_DECL_RE = re.compile(
    r"(?:public\s+|protected\s+|private\s+)?enum\s+(\w+)\s*(?:implements\s+[\w,\s<>]+)?\s*\{([^}]+)\}",
    re.DOTALL,
)
_CONSTANT_RE = re.compile(r"^\s*([A-Z][A-Z0-9_]*)(?:\s*\(|,|\s*$)", re.MULTILINE)


def extract_enums(root: str) -> dict:
    """Returns {EnumName: [VALUE1, VALUE2, ...]}"""
    root_path = Path(root)
    result: dict = {}

    for f in root_path.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        if "enum " not in text:
            continue

        for m in _ENUM_DECL_RE.finditer(text):
            enum_name = m.group(1)
            body = m.group(2)

            # Stop collecting constants at first method/field declaration
            method_start = re.search(r"\b(?:public|private|protected|void|static)\b", body)
            if method_start:
                body = body[: method_start.start()]

            # Stop at semicolon (separates constants from members)
            semi = body.find(";")
            if semi != -1:
                body = body[:semi]

            constants = []
            for cm in _CONSTANT_RE.finditer(body):
                val = cm.group(1).strip()
                if val and val not in {"", "//"}:
                    constants.append(val)

            if constants:
                result[enum_name] = constants

    return result
