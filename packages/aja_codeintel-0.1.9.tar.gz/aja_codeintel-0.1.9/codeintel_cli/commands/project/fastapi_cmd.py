"""
fastapi-scan command – full FastAPI project scan with prefix resolution.

Outputs a JSON report matching the same schema as the Java Spring Boot scanner:
  {
    "endpoints": [ { method, path, file, line, handler, framework, ... } ],
    "dtos":      [ { name, file, kind, bases, fields: [{name, type, required, default}] } ],
    "models":    [ { name, file, kind, table, columns: [...], relationships: [...] } ]
  }
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import typer

from ...core.project import find_project_root
from ...endpoints.fastapi_scanner import scan_fastapi_project
from ...endpoints.scan import EndpointScanOptions, iter_supported_source_files
from ...errors import InvalidPathError


def _validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder


def _norm(p: str) -> str:
    return p.replace("\\", "/")


def register_fastapi_scan(app: typer.Typer) -> None:
    @app.command("fastapi-scan", help="Scan a FastAPI project (endpoints + DTOs + models).")
    def fastapi_scan(
        path: str = typer.Argument(".", help="FastAPI project root folder"),
        fmt: str = typer.Option("json", "--format", "-f", help="json | text"),
        hidden: bool = typer.Option(False, "--hidden", help="Include hidden dotfiles/folders"),
        no_gitignore: bool = typer.Option(False, "--no-gitignore", help="Do not apply .gitignore rules"),
        only_api: bool = typer.Option(False, "--only-api", help="Only show paths starting with /api"),
        dedupe: bool = typer.Option(True, "--dedupe/--no-dedupe", help="Remove duplicate method+path pairs"),
        no_dtos: bool = typer.Option(False, "--no-dtos", help="Omit Pydantic DTOs from output"),
        no_models: bool = typer.Option(False, "--no-models", help="Omit SQLAlchemy models from output"),
    ) -> None:
        folder = _validate_folder(path)
        project_root = find_project_root(folder)

        opts = EndpointScanOptions(
            show_hidden=hidden,
            use_gitignore=not no_gitignore,
        )

        t0 = time.perf_counter()

        # Collect .py files via the shared scanner (respects gitignore / hidden)
        py_files = [
            f for f in iter_supported_source_files(project_root, opts)
            if f.suffix.lower() == ".py"
        ]

        endpoints, dtos, sqla_models = scan_fastapi_project(
            project_root, files=py_files
        )

        # Post-processing
        if only_api:
            endpoints = [e for e in endpoints if e.path.startswith("/api")]

        if dedupe:
            seen: set[tuple[str, str]] = set()
            uniq = []
            for e in endpoints:
                key = (e.method, e.path)
                if key not in seen:
                    seen.add(key)
                    uniq.append(e)
            endpoints = uniq

        endpoints.sort(key=lambda e: (e.path, e.method))

        elapsed = time.perf_counter() - t0
        fmt_norm = fmt.strip().lower()

        # ------------------------------------------------------------------
        # JSON output (default)  — same schema as Java scanner
        # ------------------------------------------------------------------
        if fmt_norm == "json":
            report: dict = {
                "endpoints": [e.to_dict() for e in endpoints],
                "dtos": [] if no_dtos else [d.to_dict() for d in dtos],
                "models": [] if no_models else [m.to_dict() for m in sqla_models],
            }
            typer.echo(json.dumps(report, indent=2))
            return

        # ------------------------------------------------------------------
        # Text output
        # ------------------------------------------------------------------
        typer.echo(f"FastAPI project: {project_root}")
        typer.echo(f"Scanned {len(py_files)} Python files in {elapsed:.3f}s")
        typer.echo("")

        if endpoints:
            typer.echo(f"ENDPOINTS ({len(endpoints)})")
            typer.echo("─" * 60)
            for e in endpoints:
                handler_info = f"  → {e.handler}"
                if e.controller:   # request body model stored here
                    handler_info += f"  [body: {e.controller}]"
                typer.echo(f"  {e.method:7} {e.path}")
                typer.echo(f"  {handler_info}  ({_norm(e.file)}:{e.line})")
            typer.echo("")
        else:
            typer.echo("No FastAPI endpoints found.")
            typer.echo("")

        if not no_dtos and dtos:
            typer.echo(f"PYDANTIC DTOS ({len(dtos)})")
            typer.echo("─" * 60)
            for d in dtos:
                bases = ", ".join(d.bases) if d.bases else ""
                typer.echo(f"  {d.name}({bases})  {_norm(d.file)}")
                for f_def in d.fields:
                    req_marker = "*" if f_def.required else " "
                    default_str = f" = {f_def.default}" if f_def.default is not None else ""
                    typer.echo(f"    {req_marker} {f_def.name}: {f_def.type}{default_str}")
            typer.echo("")

        if not no_models and sqla_models:
            typer.echo(f"SQLALCHEMY MODELS ({len(sqla_models)})")
            typer.echo("─" * 60)
            for m in sqla_models:
                typer.echo(f"  {m.name}  table={m.table_name}  {_norm(m.file)}")
                for col in m.columns:
                    pk_marker = " [PK]" if col.primary_key else ""
                    fk_marker = f" [FK→{col.foreign_key}]" if col.foreign_key else ""
                    typer.echo(f"    {col.name}: {col.col_type}{pk_marker}{fk_marker}")
                for rel in m.relationships:
                    typer.echo(f"    {rel.name}: → {rel.target}")
            typer.echo("")
