﻿from __future__ import annotations

from pathlib import Path
from typing import Iterable
import typer

IGNORE_DIRS = {
    ".git", ".idea", ".vscode", ".mvn",
    "__pycache__", ".pytest_cache", ".ruff_cache", ".tox",
    ".venv", "venv", "env",
    "node_modules", "dist", "build", "out", "target", ".gradle",
}


def _walk_java(root: Path) -> Iterable[Path]:
    stack = [root]
    while stack:
        cur = stack.pop()
        try:
            for child in cur.iterdir():
                if child.is_dir():
                    if child.name not in IGNORE_DIRS:
                        stack.append(child)
                elif child.suffix == ".java":
                    yield child
        except (PermissionError, FileNotFoundError):
            continue


def _rel(p: Path, root: Path) -> str:
    try:
        return str(p.relative_to(root))
    except ValueError:
        return str(p)


def _render_type(item: dict, show_path: bool) -> list[str]:
    lines: list[str] = []
    tag = item["tag"]
    kind = item["kind"]
    name = item["name"]
    fields = item["fields"]
    path = item["path"]

    tag_display = tag if tag not in ("class", "record", "interface", "projection") else kind
    lines.append(f"  {name}  [{tag_display}]")

    if show_path:
        lines.append(f"      @ {path}")

    if fields:
        for f in fields:
            lines.append(f"      {f['name']}: {f['type']}")
    else:
        lines.append(f"      (no fields)")

    lines.append("")
    return lines


def register_types_command(app: typer.Typer) -> None:
    @app.command("types")
    def types_cmd(
        path: str = typer.Argument(".", help="Project root/folder to scan"),
        contains: str = typer.Option("", "-c", "--contains", help="Filter by path substring"),
        max_files: int = typer.Option(500, "-n", "--max-files"),
        show_path: bool = typer.Option(False, "--show-path", "-p", help="Show file path under each type"),
        kind: str = typer.Option("all", "--kind", "-k", help="Filter: all | request | response | other"),
    ) -> None:
        from ...lang.java.types import scan_java_types

        root = Path(path).resolve()
        filt = contains.strip().lower()

        java_files: list[Path] = []
        for f in _walk_java(root):
            rel = _rel(f, root)
            if filt and filt not in rel.lower():
                continue
            java_files.append(f)

        java_files.sort(key=lambda p: _rel(p, root).lower())
        java_files = java_files[:max_files]

        all_defs = scan_java_types(java_files, root)

        items: list[dict] = []
        for d in all_defs:
            if kind != "all" and d.category != kind:
                continue
            items.append({
                "name": d.name,
                "kind": d.kind,
                "tag": d.tag,
                "path": d.file,
                "category": d.category,
                "fields": [{"name": fld.name, "type": fld.type} for fld in d.fields],
            })

        typer.echo(f"ROOT   : {root}")
        if contains:
            typer.echo(f"Filter : {contains!r}")
        typer.echo(f"Found  : {len(items)} type(s)")

        if not items:
            return

        typer.echo("")

        group_labels = {
            "request":  "REQUEST TYPES",
            "response": "RESPONSE TYPES",
            "other":    "SHARED / OTHER TYPES",
        }

        for group_key in ("request", "response", "other"):
            group = [x for x in items if x["category"] == group_key]
            if not group:
                continue
            label = group_labels[group_key]
            typer.echo(f"{'━' * 60}")
            typer.echo(f"  {label}  ({len(group)})")
            typer.echo(f"{'━' * 60}")
            typer.echo("")
            for item in group:
                for line in _render_type(item, show_path):
                    typer.echo(line)


def _is_python_dto_like(p) -> bool:
    return False

def _parse_python_dataclasses(src: str) -> list:
    return []
