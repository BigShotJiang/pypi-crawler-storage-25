﻿from __future__ import annotations
import re
import subprocess
import time
import threading
from pathlib import Path
import typer
from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files
from ...db.cache import CacheManager


def _find_maven_cmd(root: Path) -> str:
    for name in ["mvnw.cmd", "mvnw"]:
        if (root / name).exists():
            return str(root / name)
    return "mvn"


def _changed_files(project_root: Path) -> list[Path]:
    try:
        cache = CacheManager(project_root)
        cached = {Path(p) for p in cache.get_cached_files()}
        changed = []
        for p in cached:
            if not p.exists():
                continue
            db_mtime = cache.get_file_mtime(p)
            if db_mtime is None or p.stat().st_mtime > db_mtime:
                changed.append(p)
        return changed
    except Exception:
        return []


_MVN_ERROR_RE = re.compile(r'^\[ERROR\]\s+(.+?\.java):\[(\d+),\d+\]\s+(.+)$')
_MVN_WARNING_RE = re.compile(r'^\[WARNING\]\s+(.+?\.java):\[(\d+),\d+\]\s+(.+)$')


def _run_mvn_compile(project_root: Path) -> tuple[list[dict], list[dict], str]:
    mvn = _find_maven_cmd(project_root)
    done = threading.Event()

    def spinner():
        chars = ["|", "/", "-", "\\"]
        i = 0
        start = time.perf_counter()
        while not done.is_set():
            elapsed = time.perf_counter() - start
            typer.echo(f"\r  {chars[i % 4]}  mvn compile running... {elapsed:.0f}s", nl=False)
            i += 1
            time.sleep(0.2)
        typer.echo("\r" + " " * 40 + "\r", nl=False)

    t = threading.Thread(target=spinner, daemon=True)
    t.start()

    try:
        result = subprocess.run(
            f'"{mvn}" compile -q --batch-mode',
            cwd=str(project_root),
            capture_output=True, text=True, shell=True, timeout=300,
        )
        output = result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        done.set()
        return [], [{"file": "?", "line": "?", "msg": "mvn compile timed out"}], ""
    except Exception as e:
        done.set()
        return [], [{"file": "?", "line": "?", "msg": str(e)}], ""
    finally:
        done.set()
        t.join()

    errors, warnings = [], []
    seen_e, seen_w = set(), set()
    for line in output.splitlines():
        m = _MVN_ERROR_RE.match(line.strip())
        if m:
            k = (Path(m.group(1)).name, m.group(2))
            if k not in seen_e:
                seen_e.add(k)
                errors.append({"file": Path(m.group(1)).name, "line": m.group(2), "msg": m.group(3).strip()})
            continue
        m = _MVN_WARNING_RE.match(line.strip())
        if m:
            k = (Path(m.group(1)).name, m.group(2))
            if k not in seen_w:
                seen_w.add(k)
                warnings.append({"file": Path(m.group(1)).name, "line": m.group(2), "msg": m.group(3).strip()})
    return errors, warnings, output


_STATIC_CHECKS = [
    (re.compile(r'catch\s*\([^)]+\)\s*\{\s*\}'), "Empty catch block", "warning"),
    (re.compile(r'\.get\(\)\s*\.'), "Possible null dereference after .get()", "warning"),
    (re.compile(r'System\.out\.print'), "Debug System.out.print left in code", "warning"),
    (re.compile(r'//\s*(TODO|FIXME|HACK|XXX)\b'), "Unresolved TODO/FIXME", "info"),
    (re.compile(r'catch\s*\(\s*Exception\s+\w+\s*\)'), "Catching raw Exception", "warning"),
    (re.compile(r'==\s*"[^"]*"'), 'String compared with == instead of .equals()', "error"),
    (re.compile(r'static\s+(?!final)\w+\s+\w+\s*='), "Mutable static field", "warning"),
    (re.compile(r'throw\s+new\s+NullPointerException\s*\(\s*\)'), "NullPointerException without message", "warning"),
]
_SKIP_DIRS = {"target", "build", ".git", "test", "tests"}


def _static_analyze(files: list[Path]) -> list[dict]:
    issues = []
    for f in files:
        if any(part in _SKIP_DIRS for part in f.parts):
            continue
        try:
            lines = f.read_text(encoding="utf-8", errors="ignore").splitlines()
        except Exception:
            continue
        for lineno, line in enumerate(lines, 1):
            for pattern, msg, severity in _STATIC_CHECKS:
                if pattern.search(line):
                    issues.append({"file": f.name, "line": str(lineno), "msg": msg, "severity": severity})
                    break
    return issues


_SEV_ORDER = {"error": 0, "warning": 1, "info": 2}


def _render(compile_errors, compile_warnings, static_issues) -> list[str]:
    out = []
    if not compile_errors and not compile_warnings and not static_issues:
        return ["No issues found."]
    if compile_errors:
        out.append(f"COMPILE ERRORS ({len(compile_errors)})")
        out.append("-" * 60)
        for e in compile_errors:
            out.append(f"  {e['file']:<30} line {e['line']:<6}  {e['msg']}")
        out.append("")
    if compile_warnings:
        out.append(f"COMPILE WARNINGS ({len(compile_warnings)})")
        out.append("-" * 60)
        for w in compile_warnings:
            out.append(f"  {w['file']:<30} line {w['line']:<6}  {w['msg']}")
        out.append("")
    if static_issues:
        static_issues.sort(key=lambda x: (_SEV_ORDER.get(x["severity"], 9), x["file"], int(x["line"])))
        by_sev: dict[str, list] = {}
        for i in static_issues:
            by_sev.setdefault(i["severity"], []).append(i)
        labels = {"error": "STATIC ERRORS", "warning": "STATIC WARNINGS", "info": "STATIC INFO"}
        for sev in ("error", "warning", "info"):
            group = by_sev.get(sev, [])
            if group:
                out.append(f"{labels[sev]} ({len(group)})")
                out.append("-" * 60)
                for i in group:
                    out.append(f"  {i['file']:<30} line {i['line']:<6}  {i['msg']}")
                out.append("")
    out.append("-" * 60)
    out.append(f"  Total: {len(compile_errors)} compile error(s), {len(compile_warnings)} warning(s), {len(static_issues)} static issue(s)")
    return out


def register_errors(app: typer.Typer) -> None:
    @app.command("errors", help="Static analysis (instant). Add --compile to also run mvn compile.")
    def errors(
        path: str = typer.Argument(".", help="Project root"),
        changed_only: bool = typer.Option(False, "--changed-only", "-c"),
        compile: bool = typer.Option(False, "--compile", help="Also run mvn compile"),
        skip_static: bool = typer.Option(False, "--skip-static"),
        verbose: bool = typer.Option(False, "--verbose", "-v"),
        block: bool = typer.Option(False, "--block", "-b", help="Show exact method code block for each compile error"),
    ) -> None:
        t0 = time.perf_counter()
        project_root = find_project_root(Path(path).resolve())

        if changed_only:
            java_files = _changed_files(project_root)
            typer.echo(f"Scanning {len(java_files)} changed file(s)...")
        else:
            java_files = [f for f in find_all_supported_files(project_root) if f.suffix.lower() == ".java"]
            typer.echo(f"Scanning {len(java_files)} Java file(s)...")
        typer.echo("")

        compile_errors, compile_warnings, raw_output = [], [], ""

        if compile or block:
            compile_errors, compile_warnings, raw_output = _run_mvn_compile(project_root)

        static_issues = []
        if not skip_static:
            static_issues = _static_analyze(java_files)
            if not verbose:
                static_issues = [i for i in static_issues if i["severity"] != "info"]

        for line in _render(compile_errors, compile_warnings, static_issues):
            typer.echo(line)

        if block and compile_errors:
            _show_blocks(project_root, compile_errors)
        elif block and not compile_errors:
            typer.echo("No compile errors to show blocks for.")

        typer.echo(f"\nFinished in {time.perf_counter() - t0:.3f}s")


def _show_blocks(project_root: Path, compile_errors: list[dict]) -> None:
    from ...lang.java.method_index import load_index, build_index, save_index, find_method_at_line
    from ...terminal.printer import print_block
    from ...terminal.error_parser import JavaError

    index = load_index(project_root)
    if not index:
        typer.echo("\nBuilding method index...")
        index = build_index(project_root)
        save_index(project_root, index)

    for e in compile_errors:
        err = JavaError(file=e["file"], line=int(e["line"]), message=e["msg"])
        method = find_method_at_line(index, e["file"], int(e["line"]))
        if method:
            print_block(err, method, project_root)
        else:
            typer.echo(f"\n[!] {e['file']}:{e['line']} - method not in index")