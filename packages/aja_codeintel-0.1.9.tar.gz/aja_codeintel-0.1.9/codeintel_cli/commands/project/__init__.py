from __future__ import annotations
import typer


def register_project_commands(app: typer.Typer) -> None:
    from .overview_cmd import register_overview
    from .models_cmd import register_models
    from .endpoints_cmd import register_endpoints
    from .types_cmd import register_types_command
    from .scan_cmd import register_scan
    from .context_cmd import register_context
    from .tree_cmd import register_tree
    from .imports_cmd import register_imports
    from .folder_cmd import register_folder
    from .resolve_cmd import register_resolve
    from .servicemap_cmd import register_servicemap
    from .modeltree_cmd import register_modeltree
    from .version_cmd import register_version
    from .frontend_cmd import register_frontend
    from .errors_cmd import register_errors
    from .debug_cmd import register_debug
    from .fastapi_cmd import register_fastapi_scan
    from .trace_cmd import register_trace

    register_overview(app)
    register_models(app)
    register_endpoints(app)
    register_types_command(app)
    register_scan(app)
    register_context(app)
    register_tree(app)
    register_imports(app)
    register_folder(app)
    register_resolve(app)
    register_servicemap(app)
    register_modeltree(app)
    register_version(app)
    register_frontend(app)
    register_errors(app)
    register_debug(app)
    register_fastapi_scan(app)
    register_trace(app)
