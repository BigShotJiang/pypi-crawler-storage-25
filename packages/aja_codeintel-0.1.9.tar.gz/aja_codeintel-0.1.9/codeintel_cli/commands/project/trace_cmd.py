"""
aja trace <METHOD> <PATH>

Traces a FastAPI endpoint through its full call chain:
  Router handler → service calls → utility/helper calls (with short file paths)
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import typer

from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files
from ...endpoints.fastapi_scanner import scan_fastapi_project, _collect_python_files

# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _short_path(p: Path, root: Path, parts: int = 3) -> str:
    """Return the last `parts` segments of the path relative to root."""
    try:
        rel = p.resolve().relative_to(root.resolve())
        segs = rel.parts
        return "/".join(segs[-parts:]) if len(segs) >= parts else rel.as_posix()
    except Exception:
        segs = p.parts
        return "/".join(segs[-parts:]) if len(segs) >= parts else str(p)


def _path_match(pattern: str, path: str) -> bool:
    """Simple path pattern match – treat {param} as wildcard."""
    # normalise
    def _norm(s: str) -> list[str]:
        return [p for p in s.strip("/").split("/") if p]

    pat_segs = _norm(pattern)
    url_segs = _norm(path)

    # Exact segment-count match
    if len(pat_segs) == len(url_segs):
        for ps, us in zip(pat_segs, url_segs):
            q_is_param = ps.startswith("{") and ps.endswith("}")
            ep_is_param = us.startswith("{") and us.endswith("}")
            if q_is_param:
                continue          # user typed {param} → wildcard, match anything
            if ep_is_param:
                continue          # endpoint has {param} → accept user literal (e.g. /users matches /users/{id} prefix)
            if ps != us:
                return False
        # Require at least one literal-to-literal or literal-to-param match
        # to prevent bare /{x} from matching /users
        literal_pairs = [(ps, us) for ps, us in zip(pat_segs, url_segs)
                         if not (ps.startswith("{") and ps.endswith("}"))]
        if literal_pairs:
            # At least one query literal must equal the endpoint literal (not a param)
            non_param_ep_match = any(
                not (us.startswith("{") and us.endswith("}")) and ps == us
                for ps, us in literal_pairs
            )
            if not non_param_ep_match:
                return False
        return True

    # Prefix match: user may omit trailing {param} segments
    if len(pat_segs) < len(url_segs):
        for ps, us in zip(pat_segs, url_segs):
            q_is_param = ps.startswith("{") and ps.endswith("}")
            ep_is_param = us.startswith("{") and us.endswith("}")
            if q_is_param:
                continue
            if ep_is_param:
                continue
            if ps != us:
                return False
        # Require at least one literal match
        literal_pairs = [(ps, us) for ps, us in zip(pat_segs, url_segs)
                         if not (ps.startswith("{") and ps.endswith("}"))]
        if literal_pairs:
            non_param_ep_match = any(
                not (us.startswith("{") and us.endswith("}")) and ps == us
                for ps, us in literal_pairs
            )
            if not non_param_ep_match:
                return False
        # remaining url segments must all be {param}
        remaining = url_segs[len(pat_segs):]
        return all(s.startswith("{") and s.endswith("}") for s in remaining)

    return False


# --------------------------------------------------------------------------- #
# AST: extract all function calls from a function body
# --------------------------------------------------------------------------- #

@dataclass
class CallSite:
    name: str          # bare function / method name
    full: str          # full expression e.g. "self.user_service.get_user"
    lineno: int


def _extract_calls(func_node: ast.FunctionDef) -> list[CallSite]:
    calls: list[CallSite] = []
    for node in ast.walk(func_node):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        full = ""
        name = ""
        try:
            full = ast.unparse(func)
        except Exception:
            pass

        if isinstance(func, ast.Name):
            name = func.id
        elif isinstance(func, ast.Attribute):
            name = func.attr
        else:
            continue  # skip complex expressions

        if name in ("print", "len", "str", "int", "float", "bool",
                    "list", "dict", "set", "tuple", "range", "isinstance",
                    "hasattr", "getattr", "setattr", "super", "type",
                    "enumerate", "zip", "map", "filter", "sorted", "reversed",
                    "open", "next", "iter", "any", "all", "min", "max", "sum",
                    "raise", "Exception", "ValueError", "TypeError", "KeyError",
                    "HTTPException", "JSONResponse", "RedirectResponse"):
            continue

        calls.append(CallSite(name=name, full=full, lineno=node.lineno))
    return calls


# --------------------------------------------------------------------------- #
# AST: find a function definition by name in a file
# --------------------------------------------------------------------------- #

def _parse_file(path: Path) -> Optional[ast.Module]:
    try:
        src = path.read_text(encoding="utf-8", errors="ignore")
        return ast.parse(src)
    except Exception:
        return None


def _find_func(tree: ast.Module, name: str) -> Optional[ast.FunctionDef]:
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == name:
                return node
    return None


def _collect_toplevel_funcs(tree: ast.Module) -> set[str]:
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(node.name)
        elif isinstance(node, ast.ClassDef):
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    names.add(item.name)
    return names


# --------------------------------------------------------------------------- #
# Build a name→file index from all project .py files
# --------------------------------------------------------------------------- #

@dataclass
class FuncDef:
    name: str
    file: Path
    node: ast.FunctionDef


def _build_func_index(all_py: list[Path]) -> dict[str, list[FuncDef]]:
    """name -> list of FuncDef (can appear in multiple files). Excludes test files."""
    index: dict[str, list[FuncDef]] = {}
    for path in all_py:
        # Skip test files
        parts_lower = {p.lower() for p in path.parts}
        if parts_lower & {"test", "tests", "testing", "conftest"} or path.stem.lower().startswith("test_"):
            continue
        tree = _parse_file(path)
        if tree is None:
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                index.setdefault(node.name, []).append(
                    FuncDef(name=node.name, file=path, node=node)
                )
    return index


# --------------------------------------------------------------------------- #
# Classify a file role
# --------------------------------------------------------------------------- #

_SERVICE_HINTS   = {"service", "services", "svc"}
_UTIL_HINTS      = {"util", "utils", "helper", "helpers", "common", "shared",
                    "lib", "libs", "core", "tools"}
_REPO_HINTS      = {"repository", "repositories", "repo", "repos", "dal",
                    "database", "db", "cosmos", "storage"}
_ROUTER_HINTS    = {"router", "routers", "route", "routes", "api", "endpoint",
                    "endpoints", "view", "views", "controller", "controllers"}


def _file_role(path: Path) -> str:
    parts_lower = {p.lower() for p in path.parts} | {path.stem.lower()}
    if parts_lower & _SERVICE_HINTS:
        return "service"
    if parts_lower & _REPO_HINTS:
        return "repository"
    if parts_lower & _UTIL_HINTS:
        return "util"
    if parts_lower & _ROUTER_HINTS:
        return "router"
    return "module"


# --------------------------------------------------------------------------- #
# Trace node
# --------------------------------------------------------------------------- #

@dataclass
class TraceNode:
    func_name: str
    file: Path
    role: str
    calls: list["TraceNode"] = field(default_factory=list)
    # calls that couldn't be resolved to a file
    unresolved: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Recursive trace
# --------------------------------------------------------------------------- #

_SKIP_NAMES = {
    "Depends", "Query", "Path", "Header", "Cookie", "Form", "File",
    "BackgroundTasks", "Request", "Response",
    "logger", "log", "settings", "config",
    # common noise: logger methods, dict/http methods
    "info", "debug", "warning", "error", "critical", "exception",
    "get", "post", "put", "delete", "patch",
    "append", "update", "items", "values", "keys", "format",
    "replace", "strip", "split", "join", "lower", "upper",
    "commit", "rollback", "close", "execute",
}

def _trace(
    func_node: ast.FunctionDef,
    current_file: Path,
    func_index: dict[str, list[FuncDef]],
    root: Path,
    visited: set[tuple[str, str]],
    depth: int = 0,
    max_depth: int = 4,
) -> TraceNode:
    role = _file_role(current_file)
    node = TraceNode(func_name=func_node.name, file=current_file, role=role)

    if depth >= max_depth:
        return node

    calls = _extract_calls(func_node)

    seen_names: set[str] = set()
    for call in calls:
        if call.name in _SKIP_NAMES:
            continue
        if call.name in seen_names:
            continue
        seen_names.add(call.name)

        key = (call.name, str(current_file))
        if key in visited:
            continue
        visited.add(key)

        candidates = func_index.get(call.name, [])
        # Remove router files (avoid self-referencing) and prefer service/util/repo
        non_router = [c for c in candidates if _file_role(c.file) != "router" or c.file != current_file]
        # Prioritise: service > repository > util > module
        _ROLE_PRIORITY = {"service": 0, "repository": 1, "util": 2, "module": 3, "router": 4}
        non_router.sort(key=lambda c: _ROLE_PRIORITY.get(_file_role(c.file), 9))
        resolved = non_router if non_router else candidates

        if not resolved:
            # Might be a service method call like self.svc.do_thing – try last segment
            bare = call.full.split(".")[-1] if "." in call.full else call.name
            if bare != call.name:
                candidates = func_index.get(bare, [])
                non_router = [c for c in candidates if _file_role(c.file) != "router"]
                resolved = non_router if non_router else candidates

        if not resolved:
            node.unresolved.append(call.name)
            continue

        # Pick best candidate: prefer same-project non-test file
        best = resolved[0]
        child = _trace(best.node, best.file, func_index, root, visited,
                       depth + 1, max_depth)
        node.calls.append(child)

    return node


# --------------------------------------------------------------------------- #
# Render the tree  (clean, minimal)
# --------------------------------------------------------------------------- #

def _render(node: TraceNode, root: Path, prefix: str = "", is_last: bool = True) -> list[str]:
    connector = "└─" if is_last else "├─"
    filename  = node.file.name          # just the filename, e.g. "user_service.py"
    lines = [f"{prefix}{connector} {node.func_name}()  ·  {filename}"]
    child_prefix = prefix + ("   " if is_last else "│  ")
    for i, child in enumerate(node.calls):
        lines.extend(_render(child, root, child_prefix, i == len(node.calls) - 1))
    return lines


# --------------------------------------------------------------------------- #
# Command
# --------------------------------------------------------------------------- #

_HTTP_METHODS = {"GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD"}


def _reconstruct_path(tokens: list[str]) -> str:
    """
    Join tokens back into a path, re-wrapping bare words that were
    PowerShell-expanded curly brace params (e.g. ' id ' -> '{id}').
    """
    parts: list[str] = []
    for t in tokens:
        t = t.strip()
        if not t:
            continue
        # A bare lowercase word with no / or { is likely a {param} that PS expanded
        if re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', t) and not t.startswith("/"):
            t = "{" + t + "}"
        parts.append(t)
    # Join and clean up double slashes
    joined = "".join(parts)
    joined = re.sub(r"//+", "/", joined)
    return joined


def register_trace(app: typer.Typer) -> None:
    @app.command(name="trace", help="Trace an endpoint's full call chain: router -> service -> utils.")
    def trace(
        args: list[str] = typer.Argument(..., help="[METHOD] /endpoint/path  e.g: GET /v1/users/{id}  or just  /v1/users/{id}"),
        root: str = typer.Option(".", "--root", "-r", help="Project root"),
        depth: int = typer.Option(4, "--depth", "-d", help="Max call depth"),
    ) -> None:
        if not args:
            typer.echo("Usage: aja trace [METHOD] /endpoint/path")
            raise typer.Exit(1)

        # Allow  `aja trace /path`  OR  `aja trace GET /path`
        if args[0].upper() in _HTTP_METHODS:
            method_filter: Optional[str] = args[0].upper()
            path_query = _reconstruct_path(args[1:])
        else:
            method_filter = None
            path_query = _reconstruct_path(args)

        project_root = find_project_root(Path(root).resolve())
        label = f"{method_filter} {path_query}" if method_filter else path_query
        typer.echo(f"\n  Tracing: {label}\n")

        # ── 1. Scan the project ────────────────────────────────────────
        _SKIP = {
            ".git", ".idea", ".vscode", "__pycache__", ".pytest_cache",
            ".ruff_cache", ".tox", ".venv", "venv", "env",
            "node_modules", "dist", "build", "out", "target",
        }
        all_py = _collect_python_files(project_root, _SKIP)

        endpoints, _, _, _, _, _ = scan_fastapi_project(project_root, files=all_py)

        # ── 2. Find matching endpoint(s) ──────────────────────────────
        def _method_ok(e) -> bool:
            return method_filter is None or e.method.upper() == method_filter

        matches = [e for e in endpoints if _method_ok(e) and _path_match(path_query, e.path)]

        if not matches:
            # fuzzy: ALL literal query segments must appear in the endpoint path
            q_literal_segs = [s for s in path_query.strip("/").split("/")
                              if s and not (s.startswith("{") and s.endswith("}"))]
            fuzzy = []
            for e in endpoints:
                if not _method_ok(e):
                    continue
                ep_segs = set(e.path.strip("/").split("/"))
                # every literal segment in query must match a literal or param segment
                if q_literal_segs and all(seg in ep_segs for seg in q_literal_segs):
                    fuzzy.append(e)
            if fuzzy:
                typer.echo(f"  Exact path not found. Nearest matches:")
                for m in fuzzy[:8]:
                    typer.echo(f"    {m.method} {m.path}  ({_short_path(Path(m.file), project_root)})")
                typer.echo("")
                return
            typer.echo(f"  No endpoint matching  {label}  found.")
            typer.echo("  Run 'aja endpoints .' to list all endpoints.")
            raise typer.Exit(1)

        # ── 3. If multiple matches, let user pick ──────────────────────
        # De-duplicate by (method, path)
        seen_keys: set[tuple[str, str]] = set()
        unique_matches = []
        for e in matches:
            k = (e.method, e.path)
            if k not in seen_keys:
                seen_keys.add(k)
                unique_matches.append(e)

        if len(unique_matches) > 1:
            typer.echo("  Multiple matches — pick one:\n")
            for i, e in enumerate(unique_matches, 1):
                typer.echo(f"  {i}.  {e.method:6s}  {e.path}")
            typer.echo("")
            choice = typer.prompt("  Select", type=int, default=0)
            if choice == 0 or choice < 1 or choice > len(unique_matches):
                raise typer.Exit()
            unique_matches = [unique_matches[choice - 1]]

        # Build function index once
        func_index = _build_func_index(all_py)

        def _do_trace(ep) -> None:
            handler_name = ep.handler
            handler_file = Path(ep.file)

            tree = _parse_file(handler_file)
            if tree is None:
                typer.echo(f"  Could not parse {handler_file.name}")
                return

            handler_node = _find_func(tree, handler_name)
            if handler_node is None:
                typer.echo(f"  Function '{handler_name}' not found in {handler_file.name}")
                return

            visited: set[tuple[str, str]] = set()
            root_node = _trace(handler_node, handler_file, func_index, project_root,
                               visited, depth=0, max_depth=depth)

            typer.echo(f"\n  {ep.method}  {ep.path}")
            typer.echo(f"  {'─' * 50}")
            typer.echo(f"  {handler_name}()  ·  {handler_file.name}")

            child_prefix = "  "
            for i, child in enumerate(root_node.calls):
                for line in _render(child, project_root, child_prefix, i == len(root_node.calls) - 1):
                    typer.echo(line)
            typer.echo("")

        for ep in unique_matches:
            _do_trace(ep)
