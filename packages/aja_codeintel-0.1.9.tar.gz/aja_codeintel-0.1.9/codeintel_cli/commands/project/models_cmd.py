﻿from __future__ import annotations

from pathlib import Path
import typer

from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files


MODEL_DIRS = {
    "model", "models",
    "entity", "entities",
    "domain", "domains",
    "core",
    "aggregate", "aggregates",
    "persistence",
    "db", "data", "schema",
    "pojo", "bean", "beans",
    "orm", "schemas",
    "datamodel", "datamodels",
    "table", "tables",
    "record", "records",
    "document", "documents",
    "dao",
    # petclinic-style: models live in feature packages
    "owner", "vet", "pet", "visit",
}

SKIP_DIRS = {
    "test", "tests",
    "controller", "controllers",
    "service", "services",
    "repository", "repositories",
    "config", "configuration",
    "util", "utils", "helper", "helpers",
    "exception", "exceptions",
    "security",
    "mapper", "mappers",
    "migration", "migrations",
    "dto",
}

SKIP_SUFFIXES = (
    "Repository", "Mapper", "Dao",
    "Service", "Controller",
    "Config", "Configuration",
    "Util", "Utils", "Helper",
    "Exception", "Handler",
    "Interceptor", "Filter",
    "Listener", "Scheduler",
    "Validator", "Converter",
    "Serializer", "Deserializer",
    "Factory", "Builder",
    "Specification",
)

# Annotations that definitively mark a class as a domain model
_ENTITY_ANNOTATIONS = {
    "Entity", "MappedSuperclass", "Embeddable",
    "Table", "Document",
}


def _import_extractors():
    py = None
    jv = None
    try:
        from ...lang.python.models import extract_python_models as _py
        py = _py
    except Exception:
        pass
    try:
        from ...context.python_context import extract_python_models as _py
        py = _py
    except Exception:
        pass
    try:
        from ...lang.java.models import extract_java_models as _jv
        jv = _jv
    except Exception:
        pass
    try:
        from ...context.java_context import extract_java_models as _jv
        jv = _jv
    except Exception:
        pass
    return py, jv


def _is_model_path(rel: Path) -> bool:
    parts = [p.lower() for p in rel.parts]
    if "src" in parts and "test" in parts:
        return False
    if any(part in SKIP_DIRS for part in parts):
        return False
    stem = rel.stem
    if any(stem.endswith(s) for s in SKIP_SUFFIXES):
        return False
    return any(part in MODEL_DIRS for part in parts)


def _has_entity_annotation(path: Path) -> bool:
    """Fast check: does this .java file contain a JPA/document annotation?"""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        for ann in _ENTITY_ANNOTATIONS:
            if f"@{ann}" in text:
                return True
    except Exception:
        pass
    return False


def register_models(app: typer.Typer) -> None:
    @app.command(help="List domain models.")
    def models(
        root: str = typer.Argument(".", help="Project root folder"),
        all_files: bool = typer.Option(False, "--all", help="Scan all Java files (not just model dirs)"),
        with_inherited: bool = typer.Option(True, "--inherited/--no-inherited", help="Merge inherited fields"),
    ):
        root_path = Path(root).resolve()
        project_root = find_project_root(root_path)
        extract_python_models, extract_java_models = _import_extractors()
        files = find_all_supported_files(project_root)

        pr = project_root.resolve()
        candidates: list[Path] = []

        for f in files:
            fr = f.resolve()
            try:
                rel = fr.relative_to(pr)
            except Exception:
                continue

            ext = f.suffix.lower()

            if ext == ".py":
                if _is_model_path(rel):
                    candidates.append(fr)
            elif ext == ".java":
                # 1. Directory-based heuristic
                if all_files or _is_model_path(rel):
                    candidates.append(fr)
                # 2. Annotation-based fallback — catches petclinic-style feature packages
                elif _has_entity_annotation(fr):
                    candidates.append(fr)

        # --- collect all java models first for inheritance resolution ---
        from ...lang.java.models import resolve_inherited_fields, ModelDef

        java_models_all: list[ModelDef] = []
        java_file_map: dict[str, list[ModelDef]] = {}

        if extract_java_models:
            for f in sorted(candidates, key=lambda x: str(x).lower()):
                if f.suffix.lower() == ".java":
                    defs = extract_java_models(f, pr)
                    java_file_map[str(f)] = defs
                    java_models_all.extend(defs)

            if with_inherited:
                java_models_all = resolve_inherited_fields(java_models_all)
                # rebuild map with resolved models
                resolved_by_name = {m.name: m for m in java_models_all}
                for k in java_file_map:
                    java_file_map[k] = [
                        resolved_by_name.get(m.name, m)
                        for m in java_file_map[k]
                    ]

        out: list[str] = []
        for f in sorted(candidates, key=lambda x: str(x).lower()):
            ext = f.suffix.lower()
            if ext == ".py" and extract_python_models is not None:
                defs = extract_python_models(f, project_root)
            elif ext == ".java":
                defs = java_file_map.get(str(f), [])
            else:
                continue
            for d in defs:
                inherited_marker = f"  [extends: {', '.join(d.bases)}]" if d.bases else ""
                out.append(f"{d.name}  ({d.kind}){inherited_marker}  {d.file}")
                for fld in d.fields:
                    out.append(f"  - {fld.name}: {fld.type}")

        if not out:
            typer.echo("No domain models found.")
            raise typer.Exit(0)

        for line in out:
            typer.echo(line)
