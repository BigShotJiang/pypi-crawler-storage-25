from __future__ import annotations
from pathlib import Path
import time
import typer
from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...db.cache import get_cache
from ...db.operations import needs_full_rescan


def validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder


def _start_watchdog(project_root: Path) -> None:
    try:
        from watchdog.observers import Observer
        from watchdog.events import FileSystemEventHandler
    except ImportError:
        typer.echo("Tip: pip install watchdog  to enable auto-reindex on save.")
        return

    from ...lang.java.method_index import load_index, build_index, save_index, update_file

    index = load_index(project_root)
    if not index:
        index = build_index(project_root)
        save_index(project_root, index)

    class Handler(FileSystemEventHandler):
        def on_modified(self, event):
            if not event.is_directory and event.src_path.endswith(".java"):
                update_file(project_root, Path(event.src_path))

        def on_created(self, event):
            self.on_modified(event)

    observer = Observer()
    observer.schedule(Handler(), str(project_root), recursive=True)
    observer.daemon = True
    observer.start()
    typer.echo("Watching Java files for changes (auto-reindex enabled).")


def register_scan(app: typer.Typer) -> None:
    @app.command(help="Scan and index project files")
    def scan(
        path: str = typer.Argument(".", help="Folder to scan"),
        verbose: bool = typer.Option(False, "--verbose", "-v"),
        force: bool = typer.Option(False, "--force", "-f"),
        watch: bool = typer.Option(False, "--watch", "-w", help="Keep running and auto-reindex on .java saves"),
    ):
        folder = validate_folder(path)
        project_root = find_project_root(folder)
        start_time = time.perf_counter()

        with get_cache(project_root) as cache:
            if not force and not needs_full_rescan(cache.conn, project_root):
                files = cache.get_cached_files()
                elapsed = time.perf_counter() - start_time
                java_count = sum(1 for f in files if f.suffix == ".java")
                typer.echo(f"Cache up to date")
                typer.echo(f"Cached {len(files)} files (java={java_count}) in {elapsed:.3f}s")
                typer.echo(f"Database: {cache.db_path}")
                if watch:
                    _start_watchdog(project_root)
                    typer.echo("Watching... Press Ctrl+C to stop.")
                    try:
                        while True:
                            time.sleep(1)
                    except KeyboardInterrupt:
                        pass
                return

            if verbose:
                typer.echo(f"Scanning: {project_root}")
            scanned = cache.scan_project(verbose=verbose)
            files = cache.get_cached_files()
            elapsed = time.perf_counter() - start_time
            java_count = sum(1 for f in files if f.suffix == ".java")
            typer.echo(f"Indexed {scanned} files")
            typer.echo(f"Total {len(files)} files (java={java_count}) in {elapsed:.3f}s")
            typer.echo(f"Database: {cache.db_path}")

        if watch:
            _start_watchdog(project_root)
            typer.echo("Watching... Press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
