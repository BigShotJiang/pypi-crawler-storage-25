﻿from __future__ import annotations

import ast
import re
import time
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
import typer

from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...scanner.scanner import find_all_supported_files
from ...endpoints.scan import EndpointScanOptions, iter_supported_source_files
from ...endpoints.java_spring import extract_spring_endpoints, extract_cors_config
from ...endpoints.openapi_spec import extract_openapi_endpoints
from .endpoints_cmd import _detect_spring_security_policy, _norm_path, _display_role_str
from ...context.java_rel import java_fields_and_rels, top_type_name
from ...lang.java.types import scan_java_types
from ...lang.java.models import extract_java_models, resolve_inherited_fields

IGNORE_DIRS = {
    ".git", ".idea", ".vscode", ".mvn",
    "__pycache__", ".pytest_cache", ".ruff_cache", ".tox",
    ".venv", "venv", "env",
    "node_modules", "dist", "build", "out", "target", ".gradle",
}

MODEL_DIRS = {
    "model", "models", "entity", "entities", "domain", "domains",
    "core", "aggregate", "aggregates", "persistence", "db", "data",
    "schema", "pojo", "bean", "beans", "orm", "schemas",
    "datamodel", "datamodels", "table", "tables", "record", "records",
    "document", "documents", "dao",
    "owner", "vet", "pet", "visit",
}

SKIP_MODEL_DIRS = {
    "test", "tests", "controller", "controllers",
    "service", "services", "repository", "repositories",
    "config", "configuration", "util", "utils",
    "exception", "exceptions", "security",
    "mapper", "mappers", "migration", "migrations", "dto",
}

SKIP_MODEL_SUFFIXES = (
    "Repository", "Mapper", "Dao", "Service", "Controller",
    "Config", "Configuration", "Util", "Utils", "Helper",
    "Exception", "Handler", "Interceptor", "Filter",
    "Listener", "Scheduler", "Validator", "Converter",
    "Serializer", "Deserializer", "Factory", "Builder", "Specification",
)

_ENTITY_ANNOTATIONS = {"Entity", "MappedSuperclass", "Embeddable", "Table", "Document"}


@dataclass(frozen=True)
class RelEdge:
    src: str
    kind: str
    field: str
    target: str


def _validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder


def _print_header(title: str) -> None:
    typer.echo("")
    typer.echo(f"{'━' * 60}")
    typer.echo(f"  {title}")
    typer.echo(f"{'━' * 60}")


def _is_basic_type(name: str) -> bool:
    basics = {
        "String", "Long", "Integer", "int", "long", "double", "Double",
        "float", "Float", "boolean", "Boolean", "UUID", "BigDecimal",
        "Date", "LocalDate", "LocalDateTime", "Instant", "Object",
    }
    return (name or "").strip() in basics


def _walk_java(root: Path):
    stack = [root]
    while stack:
        cur = stack.pop()
        try:
            for child in cur.iterdir():
                if child.is_dir():
                    if child.name not in IGNORE_DIRS:
                        stack.append(child)
                elif child.suffix == ".java":
                    yield child
        except (PermissionError, FileNotFoundError):
            continue


def _walk_python(root: Path):
    stack = [root]
    while stack:
        cur = stack.pop()
        try:
            for child in cur.iterdir():
                if child.is_dir():
                    if child.name not in IGNORE_DIRS:
                        stack.append(child)
                elif child.suffix == ".py":
                    yield child
        except (PermissionError, FileNotFoundError):
            continue


# ─────────────────────────────────────────────────────────────────────────────
# FRAMEWORK DETECTION
# ─────────────────────────────────────────────────────────────────────────────

def _detect_framework(project_root: Path) -> str:
    """
    Return 'java' or 'fastapi'.

    Java wins if there are .java files or Maven/Gradle build files.
    FastAPI wins if fastapi appears in requirements/pyproject or Python
    source files import FastAPI / APIRouter.
    Falls back to 'fastapi' for any Python-only project.
    """
    has_java = False
    has_fastapi_signal = False
    has_python = False

    # Build file markers
    for marker in ("pom.xml", "build.gradle", "build.gradle.kts"):
        if (project_root / marker).exists():
            has_java = True
            break

    # Requirements / pyproject
    for req_file in ("requirements.txt", "requirements-dev.txt",
                     "pyproject.toml", "setup.py", "setup.cfg", "Pipfile"):
        p = project_root / req_file
        if p.exists():
            try:
                content = p.read_text(encoding="utf-8", errors="ignore").lower()
                if "fastapi" in content:
                    has_fastapi_signal = True
            except Exception:
                pass

    # Source file sampling (first 100 .java / .py files)
    java_count = 0
    py_count = 0
    for f in project_root.rglob("*"):
        if not f.is_file():
            continue
        if any(p in IGNORE_DIRS for p in f.parts):
            continue
        if f.suffix == ".java":
            java_count += 1
            has_java = True
            if java_count > 5:
                break
        elif f.suffix == ".py":
            py_count += 1
            has_python = True
            if not has_fastapi_signal and py_count <= 30:
                try:
                    snippet = f.read_text(encoding="utf-8", errors="ignore")[:2000]
                    if "FastAPI" in snippet or "APIRouter" in snippet or "from fastapi" in snippet:
                        has_fastapi_signal = True
                except Exception:
                    pass

    if has_java:
        return "java"
    if has_fastapi_signal or has_python:
        return "fastapi"
    return "java"  # safe default


# ─────────────────────────────────────────────────────────────────────────────
# FASTAPI OVERVIEW  (runs the scanner ONCE, shares results across sections)
# ─────────────────────────────────────────────────────────────────────────────

def _collect_fastapi_data(project_root: Path):
    """
    Run scan_fastapi_project once and return
    (endpoints, pydantic_dtos, sqla_models, request_models, response_models, endpoint_deps).
    """
    from ...endpoints.fastapi_scanner import scan_fastapi_project
    opts = EndpointScanOptions(show_hidden=False, use_gitignore=True)
    py_files = [
        f for f in iter_supported_source_files(project_root, opts)
        if f.suffix.lower() == ".py"
    ]
    return scan_fastapi_project(project_root, files=py_files)


# ─── CosmosDB entity detection ───────────────────────────────────────────────

_COSMOS_DB_SIGNALS = [
    "azure.cosmos", "CosmosClient", "CosmosDBClient",
    "container_client", "get_container_client",
    "database_client", "get_database_client",
    "COSMOS_", "cosmos_db", "cosmosdb",
]

# Pydantic field names that indicate a document entity (not a pure DTO)
_ENTITY_FIELD_HINTS = {"id", "created_on", "updated_on", "created_by", "updated_by",
                        "createdBy", "updatedBy", "createdOn", "updatedOn",
                        "timestamp", "partition_key"}


def _detect_cosmos_db(project_root: Path) -> bool:
    """Quick scan: does this project use Azure CosmosDB?"""
    for f in _walk_python(project_root):
        try:
            snippet = f.read_text(encoding="utf-8", errors="ignore")[:3000]
        except Exception:
            continue
        if any(sig in snippet for sig in _COSMOS_DB_SIGNALS):
            return True
    # Check requirements files
    for req in ("requirements.txt", "pyproject.toml", "Pipfile", "setup.cfg"):
        p = project_root / req
        if p.exists():
            try:
                content = p.read_text(encoding="utf-8", errors="ignore").lower()
                if "azure-cosmos" in content or "azure_cosmos" in content:
                    return True
            except Exception:
                pass
    return False


def _cosmos_container_names(project_root: Path) -> list[str]:
    """Extract CosmosDB container names from the codebase."""
    containers: set[str] = set()
    # pattern: container_client("name") or CONTAINER_NAME = "name"
    container_call_re = re.compile(
        r"""get_container_client\s*\(["']([^"']+)["']\)"""
        r"""|CONTAINER(?:_NAME)?\s*=\s*["']([^"']+)["']"""
        r"""|container_name\s*=\s*["']([^"']+)["']""",
        re.IGNORECASE,
    )
    for f in _walk_python(project_root):
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for m in container_call_re.finditer(src):
            name = m.group(1) or m.group(2) or m.group(3)
            if name:
                containers.add(name)
    return sorted(containers)


def _cosmos_entity_models(pydantic_dtos) -> list:
    """
    Identify Pydantic models that behave like CosmosDB documents:
    - have an `id` field
    - have at least one audit field (created_by/on, updated_by/on)
    - are NOT named *Request, *Response, *Payload, *Params
    """
    skip_suffixes = (
        "Request", "Response", "Payload", "Params", "Config",
        "Summary", "Filter", "Detail", "Item"
    )
    entities = []
    for dto in pydantic_dtos:
        if any(dto.name.endswith(s) for s in skip_suffixes):
            continue
        field_names = {f.name for f in dto.fields}
        has_id = "id" in field_names
        has_audit = bool(field_names & _ENTITY_FIELD_HINTS - {"id"})
        if has_id and has_audit:
            entities.append(dto)
    return entities


def _fastapi_models_lines(sqla_models, project_root: Path | None = None,
                          pydantic_dtos=None) -> list[str]:
    # SQLAlchemy path
    if sqla_models:
        out: list[str] = []
        for m in sqla_models:
            out.append(f"{m.name}  (table: {m.table_name})  {m.file}")
            for col in m.columns:
                pk = " [PK]" if col.primary_key else ""
                fk = f" [FK→{col.foreign_key}]" if col.foreign_key else ""
                out.append(f"    {col.name}: {col.col_type}{pk}{fk}")
            for rel in m.relationships:
                out.append(f"    {rel.name}: →{rel.target}")
        return out

    # CosmosDB path
    if project_root and pydantic_dtos and _detect_cosmos_db(project_root):
        containers = _cosmos_container_names(project_root)
        entities   = _cosmos_entity_models(pydantic_dtos)

        out: list[str] = ["  DB Type         : Azure CosmosDB (document database)"]
        if containers:
            out.append(f"  Containers ({len(containers)}):")
            for c in containers:
                out.append(f"    • {c}")
        else:
            out.append("  Containers       : (names not found — check container_client calls)")

        if entities:
            out.append(f"  Entity models ({len(entities)}):")
            for e in entities:
                field_names = ", ".join(f.name for f in e.fields)
                out.append(f"    • {e.name}  [{field_names}]")
        else:
            out.append("  Entity models    : (use Pydantic models with 'id' field as documents)")
        return out

    return ["No ORM models found.",
            "  Note: If using CosmosDB, SQLite, MongoDB or another NoSQL DB,",
            "  entity detection is limited to SQLAlchemy and CosmosDB patterns."]


def _fastapi_relationships_lines(sqla_models) -> list[str]:
    edges: list[tuple[str, str, str]] = []
    for m in sqla_models:
        for rel in m.relationships:
            edges.append((m.name, rel.name, rel.target))
        for col in m.columns:
            if col.foreign_key:
                # e.g. users.id → target table = users
                tbl = col.foreign_key.split(".")[0] if "." in col.foreign_key else col.foreign_key
                edges.append((m.name, col.name, f"[FK] {tbl}"))
    if not edges:
        return ["No relationships found."]
    out: list[str] = [f"  Found {len(edges)} relationship(s)"]
    for src, field, tgt in edges:
        out.append(f"  {src}.{field} → {tgt}")
    return out


def _fastapi_types_lines(
    pydantic_dtos,
    request_models: set[str] | None = None,
    response_models: set[str] | None = None,
) -> list[str]:
    if not pydantic_dtos:
        return ["No Pydantic models found."]

    if request_models is not None and response_models is not None:
        # Usage-based classification
        req   = [d for d in pydantic_dtos if d.name in request_models and d.name not in response_models]
        res   = [d for d in pydantic_dtos if d.name in response_models and d.name not in request_models]
        both  = [d for d in pydantic_dtos if d.name in request_models and d.name in response_models]
        other = [d for d in pydantic_dtos if d.name not in request_models and d.name not in response_models]
        groups = [("REQUEST", req), ("RESPONSE", res), ("REQUEST+RESPONSE", both), ("SHARED/OTHER", other)]
    else:
        # Fallback: name-based heuristic
        req  = [d for d in pydantic_dtos if any(k in d.name.lower() for k in ("request","create","update","input","payload","command","form"))]
        res  = [d for d in pydantic_dtos if any(k in d.name.lower() for k in ("response","result","output","view","detail","out"))]
        other = [d for d in pydantic_dtos if d not in req and d not in res]
        groups = [("REQUEST", req), ("RESPONSE", res), ("SHARED/OTHER", other)]

    out: list[str] = [f"Found {len(pydantic_dtos)} Pydantic model(s)"]
    for label, group in groups:
        if not group:
            continue
        out.append(f"  {label} ({len(group)})")
        for d in group:
            bases = ", ".join(d.bases) if d.bases else ""
            out.append(f"    {d.name}({bases})  {d.file}")
            for f_def in d.fields:
                req_marker = "* " if f_def.required else "  "
                default_str = f" = {f_def.default}" if f_def.default is not None else ""
                out.append(f"        {req_marker}{f_def.name}: {f_def.type}{default_str}")
    return out


def _fastapi_endpoints_lines(endpoints) -> list[str]:
    if not endpoints:
        return ["Found 0 endpoints", "", "No FastAPI endpoints detected."]

    seen: set[tuple[str, str]] = set()
    uniq = []
    for e in endpoints:
        key = (e.method, e.path)
        if key not in seen:
            seen.add(key)
            uniq.append(e)
    uniq.sort(key=lambda e: (e.path, e.method))

    methods_by_path: dict[str, set[str]] = defaultdict(set)
    handler_by_key: dict[tuple[str, str], str] = {}
    for e in uniq:
        methods_by_path[e.path].add(e.method)
        handler_by_key[(e.path, e.method)] = e.handler

    out: list[str] = [f"Found {len(uniq)} endpoints", ""]
    for idx, p in enumerate(sorted(methods_by_path.keys()), 1):
        methods = sorted(methods_by_path[p])
        method_str = ", ".join(methods)
        handlers = ", ".join(
            handler_by_key.get((p, m), "") for m in methods if handler_by_key.get((p, m))
        )
        out.append(f"{idx:02d}. {p}  [{method_str}]  → {handlers}")
    return out


# ─────────────────────────────────────────────────────────────────────────────
# PYTHON-SPECIFIC SECTION SCANNERS
# ─────────────────────────────────────────────────────────────────────────────

_PY_JWT_SIGNALS = [
    "jwt", "jose", "python-jose", "pyjwt",
    "fastapi_jwt_auth", "fastapi-jwt-auth",
    "Depends(get_current_user", "oauth2_scheme",
    "HTTPBearer", "HTTPAuthorizationCredentials",
    "create_access_token", "decode_token",
    "JWTError", "JWTBearer",
]
_PY_OAUTH2_SIGNALS = [
    "OAuth2PasswordBearer", "OAuth2PasswordRequestForm",
    "OAuth2AuthorizationCodeBearer",
    "authlib", "python-oauth2",
]
_PY_API_KEY_SIGNALS = [
    "APIKeyHeader", "APIKeyQuery", "APIKeyCookie",
    "X-API-Key", "api_key",
]


def _fastapi_dep_flow_lines(endpoint_deps: list[dict]) -> list[str]:
    """
    Show shared Depends() functions (used by 2+ endpoints) and their callers.
    Also show endpoints that chain multiple dependencies.
    """
    if not endpoint_deps:
        return ["  No Depends() injections detected."]

    # Invert: dep_func -> list of (method, path)
    dep_to_endpoints: dict[str, list[str]] = {}
    for item in endpoint_deps:
        label = f"{item['method']} {item['path']}"
        for dep in item["depends"]:
            dep_to_endpoints.setdefault(dep, []).append(label)

    # Shared deps (used by 2+ endpoints)
    shared = {d: eps for d, eps in dep_to_endpoints.items() if len(eps) >= 2}
    # Multi-dep endpoints (2+ dependencies)
    multi_dep = [item for item in endpoint_deps if len(item["depends"]) >= 2]

    out: list[str] = []

    if shared:
        out.append(f"  Shared dependencies ({len(shared)} used by 2+ endpoints):")
        for dep in sorted(shared):
            eps = shared[dep]
            out.append(f"    {dep}  ({len(eps)} endpoints)")
            for ep_label in sorted(eps)[:10]:
                out.append(f"        {ep_label}")
            if len(eps) > 10:
                out.append(f"        ... ({len(eps) - 10} more)")
    else:
        out.append("  No shared dependencies (all Depends() are endpoint-unique).")

    if multi_dep:
        out.append(f"\n  Endpoints with multiple dependencies ({len(multi_dep)}):")
        for item in sorted(multi_dep, key=lambda x: -len(x["depends"]))[:30]:
            deps_str = ", ".join(item["depends"])
            out.append(f"    {item['method']} {item['path']}")
            out.append(f"        deps: {deps_str}")

    return out


def _scan_python_auth(project_root: Path) -> list[str]:
    jwt_hits = 0
    oauth2_hits = 0
    api_key_hits = 0

    for f in _walk_python(project_root):
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for sig in _PY_JWT_SIGNALS:
            if sig in src:
                jwt_hits += 1
                break
        for sig in _PY_OAUTH2_SIGNALS:
            if sig in src:
                oauth2_hits += 1
                break
        for sig in _PY_API_KEY_SIGNALS:
            if sig in src:
                api_key_hits += 1
                break

    out: list[str] = []
    if jwt_hits >= 1 and oauth2_hits >= 1:
        out.append(f"  Type            : JWT + OAuth2 Password Flow")
        out.append( "  Token transport : Bearer header")
        out.append( "  Usage           : Authorization: Bearer <token>")
        out.append(f"  Signals         : {jwt_hits} JWT file(s), {oauth2_hits} OAuth2 file(s)")
    elif jwt_hits >= 1:
        out.append(f"  Type            : JWT  ({jwt_hits} file(s) with JWT patterns)")
        out.append( "  Token transport : Bearer header")
        out.append( "  Usage           : Authorization: Bearer <token>")
    elif oauth2_hits >= 1:
        out.append(f"  Type            : OAuth2  ({oauth2_hits} file(s) with OAuth2 patterns)")
        out.append( "  Token transport : Bearer header")
    elif api_key_hits >= 1:
        out.append(f"  Type            : API Key  ({api_key_hits} file(s))")
        out.append( "  Token transport : Header (X-API-Key) or Query param")
    else:
        out.append( "  Type            : None / Public")
        out.append( "  Token transport : N/A")
        out.append( "  Notes           : No auth patterns detected — endpoints appear public")
    return out


def _scan_python_base_path(endpoints) -> list[str]:
    """Derive the most common top-level prefix from resolved endpoints."""
    from collections import Counter
    counter: Counter = Counter()
    for e in endpoints:
        parts = [p for p in e.path.split("/") if p and not p.startswith("{")]
        if parts:
            counter["/" + parts[0]] += 1
            if len(parts) >= 2:
                counter["/" + parts[0] + "/" + parts[1]] += 1

    if not counter:
        return ["  None — routers mount directly at /"]

    top = counter.most_common(1)[0][0]
    return [
        f"  Global prefix   : {top}",
        f"  Notes           : Use this as your API base URL prefix",
    ]


def _scan_python_pagination(project_root: Path) -> list[str]:
    """Detect FastAPI pagination patterns (skip/limit or page/size params)."""
    skip_limit_re = re.compile(r"\bskip\s*:\s*int\b|\blimit\s*:\s*int\b", re.IGNORECASE)
    page_size_re  = re.compile(r"\bpage\s*:\s*int\b|\bper_page\s*:\s*int\b|\bpage_size\s*:\s*int\b", re.IGNORECASE)
    paginate_hits: list[str] = []

    for f in _walk_python(project_root):
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if skip_limit_re.search(src):
            paginate_hits.append(f"skip/limit — {f.name}")
        elif page_size_re.search(src):
            paginate_hits.append(f"page/size  — {f.name}")

    if paginate_hits:
        return [
            "  Used            : Yes",
            "  Patterns        : skip/limit (offset-based) or page/size",
            "  Query params    : ?skip=0&limit=100  or  ?page=1&page_size=20",
        ] + [f"  File            : {h}" for h in paginate_hits[:5]]
    return [
        "  Used            : No",
        "  Notes           : No skip/limit or page/size params detected",
    ]


# Pydantic Field constraint kwargs that indicate actual validation rules
_FIELD_CONSTRAINT_KWARGS = {
    "min_length", "max_length", "pattern", "regex",
    "ge", "gt", "le", "lt", "multiple_of",
    "min_items", "max_items",
}
# Type annotations that perform implicit validation
_CONSTRAINED_TYPES = {
    "EmailStr", "AnyUrl", "AnyHttpUrl", "HttpUrl", "PostgresDsn",
    "UUID", "UUID4", "PositiveInt", "NegativeInt", "PositiveFloat",
    "constr", "conint", "confloat", "conlist", "conset",
    "SecretStr", "IPvAnyAddress",
}


def _scan_python_validation(project_root: Path) -> list[str]:
    """
    Focused validation scan: find files / models that use actual Pydantic
    constraint annotations (Field(min_length=…), EmailStr, @validator, etc.).
    Does NOT duplicate the full field listing already shown in DTO/TYPES.
    """
    constrained_models: dict[str, list[str]] = {}  # model_name → [constraint descriptions]
    validator_files: list[str] = []

    validator_re = re.compile(
        r"@(?:validator|field_validator|model_validator)\s*\(", re.MULTILINE
    )
    field_constraint_re = re.compile(
        r"Field\s*\([^)]*(?:" + "|".join(_FIELD_CONSTRAINT_KWARGS) + r")\s*=",
        re.IGNORECASE,
    )
    constrained_type_re = re.compile(
        r":\s*(?:Optional\[)?(?:" + "|".join(_CONSTRAINED_TYPES) + r")\b"
    )
    class_re = re.compile(r"^class\s+(\w+)\s*\(", re.MULTILINE)

    for f in _walk_python(project_root):
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        has_validator = bool(validator_re.search(src))
        has_field_constraint = bool(field_constraint_re.search(src))
        has_constrained_type = bool(constrained_type_re.search(src))

        if not (has_validator or has_field_constraint or has_constrained_type):
            continue

        if has_validator:
            validator_files.append(f.name)

        for cls_m in class_re.finditer(src):
            cls_name = cls_m.group(1)
            class_start = cls_m.start()
            # rough class body: next class or EOF
            nxt = class_re.search(src, cls_m.end())
            class_end = nxt.start() if nxt else len(src)
            body = src[class_start:class_end]

            hints: list[str] = []
            if validator_re.search(body):
                hints.append("@validator")
            for m in field_constraint_re.finditer(body):
                # extract the constraint kwarg name(s) found
                for kw in _FIELD_CONSTRAINT_KWARGS:
                    if kw in m.group(0):
                        hints.append(f"Field({kw}=…)")
            for ct in _CONSTRAINED_TYPES:
                if ct in body:
                    hints.append(ct)

            # deduplicate
            seen_hints: set[str] = set()
            uniq_hints = [h for h in hints if not (h in seen_hints or seen_hints.add(h))]  # type: ignore[func-returns-value]
            if uniq_hints:
                constrained_models[cls_name] = uniq_hints

    if not constrained_models and not validator_files:
        return ["  None detected"]

    out: list[str] = []
    out.append(f"  Models with Pydantic validators/constraints: {len(constrained_models)}")
    if validator_files:
        out.append(f"  Files using @validator/@field_validator: {', '.join(sorted(set(validator_files))[:8])}")
    out.append("")
    for cls_name in sorted(constrained_models):
        hints_str = ", ".join(constrained_models[cls_name])
        out.append(f"  {cls_name}: {hints_str}")
    return out


def _scan_python_enums(project_root: Path) -> list[str]:
    """Detect Python Enum classes (handles ALL_CAPS and lowercase/mixed member names)."""
    enums: dict[str, list[str]] = {}
    enum_re = re.compile(r"^class\s+(\w+)\s*\(.*Enum.*\)\s*:", re.MULTILINE)
    # Match any identifier (not just ALL_CAPS) that is assigned a simple value
    # Skip dunder methods and lines that look like method definitions
    member_re = re.compile(
        r"^[ \t]{2,8}"                      # 2–8 spaces of indentation (class body)
        r"([A-Za-z][A-Za-z0-9_]*)"          # member name (any case)
        r"\s*=\s*"
        r"([^#\n]+)",                        # value (up to end-of-line or comment)
        re.MULTILINE,
    )
    # Patterns to exclude (method-like assignments)
    _SKIP_MEMBER = re.compile(r"^def |^class |^async def |^@", re.MULTILINE)

    for f in _walk_python(project_root):
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if "Enum" not in src:
            continue
        for m in enum_re.finditer(src):
            cls_name = m.group(1)
            # Extract members from the block after the class definition
            start = m.end()
            # Find end of class (next top-level or EOF)
            block_end = len(src)
            next_class = re.search(r"^\S", src[start:], re.MULTILINE)
            if next_class:
                block_end = start + next_class.start()
            block = src[start:block_end]
            members_found: list[str] = []
            for mm in member_re.finditer(block):
                name = mm.group(1)
                val  = mm.group(2).strip()
                # Skip dunders, obviously non-enum names, or method bodies
                if name.startswith("_"):
                    continue
                if "(" in val and not val.startswith(("'", '"')):
                    # looks like a method call with body, skip
                    continue
                members_found.append(f"{name} = {val}")
            if members_found:
                enums[cls_name] = members_found

    if not enums:
        return ["  None detected"]

    out: list[str] = [f"  Found {len(enums)} enum(s)"]
    for enum_name in sorted(enums):
        values = " | ".join(v.split(" = ")[0] for v in enums[enum_name])
        out.append(f"  {enum_name}: {values}")
    return out


def _is_model_path(rel: Path) -> bool:
    parts = [p.lower() for p in rel.parts]
    if "src" in parts and "test" in parts:
        return False
    if any(p in SKIP_MODEL_DIRS for p in parts):
        return False
    if any(rel.stem.endswith(s) for s in SKIP_MODEL_SUFFIXES):
        return False
    return any(p in MODEL_DIRS for p in parts)


def _has_entity_annotation(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        return any(f"@{a}" in text for a in _ENTITY_ANNOTATIONS)
    except Exception:
        return False


def _scan_models(project_root: Path) -> list[str]:
    pr = project_root.resolve()
    files = find_all_supported_files(project_root)

    candidates: list[Path] = []
    for f in files:
        if f.suffix.lower() != ".java":
            continue
        fr = f.resolve()
        try:
            rel = fr.relative_to(pr)
        except Exception:
            continue
        if _is_model_path(rel) or _has_entity_annotation(fr):
            candidates.append(fr)

    all_models = []
    for f in sorted(candidates, key=lambda x: str(x).lower()):
        all_models.extend(extract_java_models(f, pr))

    all_models = resolve_inherited_fields(all_models)
    by_name = {m.name: m for m in all_models}

    out: list[str] = []
    for f in sorted(candidates, key=lambda x: str(x).lower()):
        fr = f.resolve()
        try:
            rel = str(fr.relative_to(pr))
        except Exception:
            rel = str(fr)
        for m in all_models:
            if m.file == rel or m.file == rel.replace("\\", "/"):
                inherited = f"  [extends: {', '.join(m.bases)}]" if m.bases else ""
                out.append(f"{m.name}  ({m.kind}){inherited}  {m.file}")
                for fld in m.fields:
                    out.append(f"    {fld.name}: {fld.type}")

    return out or ["No domain models found."]


def _scan_relationships(project_root: Path) -> tuple[list[RelEdge], dict[str, int], dict[str, list[RelEdge]]]:
    files = find_all_supported_files(project_root)
    pr = project_root.resolve()
    candidates: list[Path] = []
    for f in files:
        if f.suffix.lower() != ".java":
            continue
        fr = f.resolve()
        try:
            rel = fr.relative_to(pr)
        except Exception:
            continue
        if _is_model_path(rel):
            candidates.append(fr)

    edges: list[RelEdge] = []
    counts: dict[str, int] = defaultdict(int)
    per_src: dict[str, list[RelEdge]] = defaultdict(list)

    for f in sorted(candidates, key=lambda x: str(x).lower()):
        try:
            raw = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        src_type = top_type_name(raw, fallback=f.stem)
        _fields, rels = java_fields_and_rels(f)
        for r in rels:
            tgt = (r.target or "").strip()
            if not tgt or _is_basic_type(tgt):
                continue
            e = RelEdge(src=src_type, kind=r.kind, field=r.field, target=tgt)
            edges.append(e)
            counts[r.kind] += 1
            per_src[src_type].append(e)

    edges.sort(key=lambda e: (e.src.lower(), e.kind, e.field.lower(), e.target.lower()))
    for k in list(per_src.keys()):
        per_src[k].sort(key=lambda e: (e.kind, e.field.lower(), e.target.lower()))

    return edges, dict(counts), dict(per_src)


def _scan_types(project_root: Path) -> list[str]:
    java_files = sorted(_walk_java(project_root), key=lambda p: str(p).lower())
    all_defs = scan_java_types(java_files[:500], project_root)

    if not all_defs:
        return ["No DTO/transfer types found."]

    req   = [d for d in all_defs if d.category == "request"]
    res   = [d for d in all_defs if d.category == "response"]
    other = [d for d in all_defs if d.category == "other"]

    out: list[str] = [f"Found {len(all_defs)} type(s)"]
    for label, group in (("REQUEST", req), ("RESPONSE", res), ("SHARED", other)):
        if not group:
            continue
        out.append(f"  {label} ({len(group)})")
        for d in group:
            tag = d.tag if d.tag not in ("class", "record", "interface") else d.kind
            out.append(f"    {d.name}  [{tag}]")
            for fld in d.fields:
                out.append(f"        {fld.name}: {fld.type}")
    return out


def _scan_endpoints(project_root: Path) -> list[str]:
    opts = EndpointScanOptions(show_hidden=False, use_gitignore=True)
    t0 = time.perf_counter()
    all_eps = []
    files = list(iter_supported_source_files(project_root, opts))
    files_for_security = [
        f for f in files
        if not any(x in _norm_path(str(f)).lower() for x in ("/src/test/", "/target/", "/build/"))
    ]
    default_auth, permit_all = _detect_spring_security_policy(files_for_security)

    for f in files:
        if f.suffix.lower() != ".java":
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        all_eps.extend(extract_spring_endpoints(src, str(f), default_auth=default_auth, permit_all=permit_all))

    if not any(e.framework == "spring" for e in all_eps):
        all_eps.extend(extract_openapi_endpoints(project_root))

    filtered = [
        e for e in all_eps
        if "/src/test/" not in _norm_path(e.file)
        and ("/src/main/" in _norm_path(e.file) or "/main/" in _norm_path(e.file))
    ]

    seen: set[tuple[str, str]] = set()
    uniq = []
    for e in filtered:
        key = (e.method, e.path)
        if key not in seen:
            seen.add(key)
            uniq.append(e)
    uniq.sort(key=lambda e: (e.path, e.method))

    elapsed = time.perf_counter() - t0
    out: list[str] = [f"Found {len(uniq)} endpoints in {elapsed:.3f}s", ""]

    methods_by_path: dict[str, set[str]] = defaultdict(set)
    roles_by_key: dict[tuple[str, str], set[str]] = defaultdict(set)
    for e in uniq:
        methods_by_path[e.path].add(e.method)
        if e.roles:
            roles_by_key[(e.path, e.method)].update(e.roles)

    for idx, p in enumerate(sorted(methods_by_path.keys()), 1):
        methods = sorted(methods_by_path[p])
        parts = [
            f"{m}{_display_role_str(p, roles_by_key.get((p, m), set()), default_auth=default_auth, permit_all=permit_all)}"
            for m in methods
        ]
        out.append(f"{idx:02d}. {p}  [{', '.join(parts)}]")

    return out


def _scan_cors(project_root: Path) -> list[str]:
    info = extract_cors_config(project_root)
    out: list[str] = []

    sp = info.get("server_port")
    out.append(f"  Backend port  : {sp or '8080 (default)'}")

    origins = info.get("origins", [])
    if origins:
        out.append(f"  Allowed origins ({len(origins)}):")
        for o in origins:
            out.append(f"    {o}")
    else:
        out.append("  Allowed origins : none detected")

    ports = info.get("ports", [])
    if ports:
        out.append(f"  Frontend port(s): {', '.join(ports)}")
    else:
        out.append("  Frontend port(s): none detected")

    ctrl = info.get("cross_origin_controllers", [])
    if ctrl:
        out.append(f"  @CrossOrigin on : {', '.join(ctrl)}")

    srcs = info.get("sources", [])
    if srcs:
        out.append(f"  Detected from   : {', '.join(srcs)}")

    return out


# ─────────────────────────────────────────────────────────────────────────────
# NEW SECTION: AUTH
# ─────────────────────────────────────────────────────────────────────────────

# JWT signals — any of these confirm JWT is in use
_JWT_SIGNALS = [
    r"JwtAuthenticationFilter",
    r"JwtTokenProvider",
    r"TokenProvider",
    r"Jwts\.",
    r"JWTVerifier",
    r"BearerTokenAuthenticationFilter",
    r"import\s+io\.jsonwebtoken",
    r"import\s+com\.auth0\.jwt",
    r"import\s+org\.springframework\.security\.oauth2\.jwt",
    r"NimbusJwtDecoder",
    r"NimbusJwtEncoder",
    r"JwtDecoder",
    r"JwtEncoder",
    r"JwtClaimsSet",
]
_OAUTH2_SIGNALS = [
    r"oauth2Login\s*\(",
    r"@EnableOAuth2Sso",
    r"@EnableResourceServer",
    r"@EnableAuthorizationServer",
    r"import\s+org\.springframework\.security\.oauth2\.client",
]

def _scan_auth(project_root: Path) -> list[str]:
    jwt_hits = 0
    oauth2_hits = 0
    stateless = False
    session_hits = 0

    for f in project_root.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for p in _JWT_SIGNALS:
            if re.search(p, src):
                jwt_hits += 1
        for p in _OAUTH2_SIGNALS:
            if re.search(p, src):
                oauth2_hits += 1
        if re.search(r"SessionCreationPolicy\.STATELESS", src):
            stateless = True
        if re.search(r"\.sessionManagement\(|HttpSession", src):
            session_hits += 1

    out: list[str] = []
    if jwt_hits >= 1:
        out.append(f"  Type            : JWT  ({jwt_hits} signal(s) found)")
        out.append( "  Token transport : Bearer header")
        out.append( "  Usage           : Authorization: Bearer <token>")
    elif oauth2_hits >= 1:
        out.append(f"  Type            : OAuth2  ({oauth2_hits} signal(s) found)")
        out.append( "  Token transport : Bearer header")
        out.append( "  Usage           : Authorization: Bearer <access_token>")
    elif stateless:
        out.append( "  Type            : Stateless (token type unclear)")
        out.append( "  Token transport : Bearer header (assumed)")
        out.append( "  Notes           : SessionCreationPolicy.STATELESS set but no JWT/OAuth2 class found")
    elif session_hits >= 1:
        out.append( "  Type            : Session-based")
        out.append( "  Token transport : Cookie (JSESSIONID)")
        out.append( "  Usage           : Browser manages cookie automatically")
    else:
        out.append( "  Type            : None / Public")
        out.append( "  Token transport : N/A")
        out.append( "  Notes           : No Spring Security config detected — all endpoints appear public")
    return out


# ─────────────────────────────────────────────────────────────────────────────
# NEW SECTION: BASE PATH PREFIX
# ─────────────────────────────────────────────────────────────────────────────

def _scan_base_path(project_root: Path) -> list[str]:
    """
    Find the global API base prefix shared by most controllers.
    Counts frequency of first path segment across all @RequestMapping
    class-level annotations and returns the most common one.
    """
    from collections import Counter
    pattern = re.compile(r'@RequestMapping\s*\(\s*["\']([^"\']+)["\']')
    prefix_counter: Counter = Counter()

    for f in project_root.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if "@Controller" not in src and "@RestController" not in src:
            continue
        for m in pattern.finditer(src):
            val = m.group(1).strip()
            if not val or "{" in val:
                continue
            val = val if val.startswith("/") else "/" + val
            parts = [p for p in val.split("/") if p]
            if parts:
                prefix_counter["/" + parts[0]] += 1
            if len(parts) >= 2:
                prefix_counter["/" + parts[0] + "/" + parts[1]] += 1

    if not prefix_counter:
        return ["  None — controllers mount directly at /"]

    top = prefix_counter.most_common(1)[0][0]
    return [
        f"  Global prefix   : {top}",
        f"  Notes           : axios.defaults.baseURL = 'http://localhost:8080{top}'",
    ]


# ─────────────────────────────────────────────────────────────────────────────
# NEW SECTION: PAGINATION
# ─────────────────────────────────────────────────────────────────────────────

def _scan_pagination(project_root: Path) -> list[str]:
    pageable_re    = re.compile(r"\bPageable\b")
    page_re        = re.compile(r"\bPage<")
    class_map_re   = re.compile(r'@RequestMapping\s*\(\s*["\']([^"\']+)["\']')
    method_map_re  = re.compile(r'@(?:Get|Post|Put|Delete|Patch)Mapping\s*(?:\(\s*(?:value\s*=\s*)?["\']([^"\']*)["\'])?')

    paginated_paths: set[str] = set()

    for f in project_root.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if not (pageable_re.search(src) or page_re.search(src)):
            continue
        if "@Controller" not in src and "@RestController" not in src:
            continue

        # resolve class-level base prefix for this file
        base = ""
        cm = class_map_re.search(src)
        if cm:
            base = cm.group(1).strip()
            base = base if base.startswith("/") else "/" + base
            base = base.rstrip("/")

        for m in method_map_re.finditer(src):
            sub = (m.group(1) or "").strip()
            if sub and not sub.startswith("/"):
                sub = "/" + sub
            full = (base + sub) or "/"
            # only count if Pageable appears near this method
            snippet = src[m.start(): m.start() + 600]
            if pageable_re.search(snippet) or page_re.search(snippet):
                paginated_paths.add(full)

    if paginated_paths:
        out = [
            "  Used            : Yes (Spring Data Page / Pageable)",
            "  Response shape  : { content: T[], totalElements: number, totalPages: number,",
            "                      number: number (0-based page), size: number }",
            "  Query params    : ?page=0&size=20&sort=fieldName,asc",
            f"  Paginated paths : {', '.join(sorted(paginated_paths))}",
        ]
    else:
        out = [
            "  Used            : No",
            "  Notes           : Endpoints return plain lists or single objects",
        ]
    return out


# ─────────────────────────────────────────────────────────────────────────────
# NEW SECTION: VALIDATION CONSTRAINTS
# ─────────────────────────────────────────────────────────────────────────────
_ANN_BLOCK_RE = re.compile(
    r'(@(?:NotNull|NotBlank|NotEmpty|Email|Positive|PositiveOrZero|Negative|NegativeOrZero)'
    r'|@Size\([^)]*\)|@Min\([^)]*\)|@Max\([^)]*\)|@Pattern\([^)]*\))'
)
_FIELD_LINE_RE = re.compile(
    r'((?:@\w+(?:\([^)]*\))?\s*)+)'
    r'(?:private|protected|public)\s+'
    r'[\w<>, \[\]]+\s+'
    r'(\w+)\s*;'
)

_ANN_BLOCK_RE = re.compile(
    r'(@(?:NotNull|NotBlank|NotEmpty|Email|Positive|PositiveOrZero|Negative|NegativeOrZero)'
    r'|@Size\([^)]*\)|@Min\([^)]*\)|@Max\([^)]*\)|@Pattern\([^)]*\))'
)
_FIELD_LINE_RE = re.compile(
    r'((?:@\w+(?:\([^)]*\))?\s*)+)'
    r'(?:private|protected|public)\s+'
    r'[\w<>, \[\]]+\s+'
    r'(\w+)\s*;'
)

def _scan_validation(project_root: Path) -> list[str]:
    results: dict[str, dict[str, list[str]]] = {}

    for f in project_root.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if not _ANN_BLOCK_RE.search(src):
            continue

        cls_match = re.search(r'class\s+(\w+)', src)
        class_name = cls_match.group(1) if cls_match else f.stem

        fields: dict[str, list[str]] = {}
        for m in _FIELD_LINE_RE.finditer(src):
            ann_block = m.group(1)
            field_name = m.group(2)
            constraints = _ANN_BLOCK_RE.findall(ann_block)
            if constraints:
                fields[field_name] = constraints
        if fields:
            results[class_name] = fields

    if not results:
        return ["  None detected"]

    out: list[str] = [f"  Found constraints in {len(results)} class(es)"]
    for class_name in sorted(results):
        out.append(f"\n  {class_name}:")
        for field_name, constraints in sorted(results[class_name].items()):
            out.append(f"      {field_name}: {', '.join(constraints)}")
    return out


# ─────────────────────────────────────────────────────────────────────────────
# NEW SECTION: ENUM TYPES
# ─────────────────────────────────────────────────────────────────────────────

_ENUM_BODY_RE = re.compile(
    r'(?:public\s+)?enum\s+(\w+)\s*(?:implements[^{]*)?\{([^}]*)\}',
    re.DOTALL,
)


def _scan_enums(project_root: Path) -> list[str]:
    enums: dict[str, list[str]] = {}

    for f in project_root.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if "enum " not in src:
            continue

        for m in _ENUM_BODY_RE.finditer(src):
            enum_name = m.group(1)
            body = m.group(2)
            # constants are before the first semicolon (methods/fields follow)
            constants_section = body.split(";")[0]
            constants = [
                c.strip().split("(")[0].strip()   # strip constructor args
                for c in constants_section.split(",")
            ]
            constants = [c for c in constants if re.match(r'^[A-Z][A-Z0-9_]*$', c)]
            if constants:
                enums[enum_name] = constants

    if not enums:
        return ["  None detected"]

    out: list[str] = [f"  Found {len(enums)} enum(s)"]
    for enum_name in sorted(enums):
        values = " | ".join(enums[enum_name])
        out.append(f"  {enum_name}: {values}")
    return out


# ─────────────────────────────────────────────────────────────────────────────
# COMMAND REGISTRATION
# ─────────────────────────────────────────────────────────────────────────────

def register_overview(app: typer.Typer) -> None:
    @app.command("overview", help="Single summary: models + relationships + DTO/types + endpoints.")
    def overview(
        path: str = typer.Argument(".", help="Project root folder"),
        show_edges: bool = typer.Option(True, "--show-edges/--no-edges"),
        max_edges: int = typer.Option(200, "--max-edges"),
    ) -> None:
        t0 = time.perf_counter()

        folder = _validate_folder(path)
        project_root = find_project_root(folder)

        framework = _detect_framework(project_root)

        typer.echo("=" * 60)
        typer.echo("  CODEINTEL OVERVIEW")
        typer.echo("=" * 60)
        typer.echo(f"  ROOT     : {project_root}")
        typer.echo(f"  FRAMEWORK: {framework.upper()}")

        # ── FastAPI / Python branch ────────────────────────────────────
        if framework == "fastapi":
            endpoints, pydantic_dtos, sqla_models, request_models, response_models, endpoint_deps = _collect_fastapi_data(project_root)

            _print_header("MODELS  (SQLAlchemy / ORM)")
            for line in _fastapi_models_lines(sqla_models):
                typer.echo(line)

            _print_header("RELATIONSHIPS")
            for line in _fastapi_relationships_lines(sqla_models):
                typer.echo(line)

            _print_header("DTO / TYPES  (Pydantic)")
            for line in _fastapi_types_lines(pydantic_dtos, request_models, response_models):
                typer.echo(line)

            _print_header("ENDPOINTS")
            for line in _fastapi_endpoints_lines(endpoints):
                typer.echo(line)

            _print_header("AUTH")
            for line in _scan_python_auth(project_root):
                typer.echo(line)

            _print_header("BASE PATH PREFIX")
            for line in _scan_python_base_path(endpoints):
                typer.echo(line)

            _print_header("PAGINATION")
            for line in _scan_python_pagination(project_root):
                typer.echo(line)

            _print_header("VALIDATION CONSTRAINTS")
            for line in _scan_python_validation(project_root):
                typer.echo(line)

            _print_header("ENUM TYPES")
            for line in _scan_python_enums(project_root):
                typer.echo(line)

            _print_header("DEPENDENCY FLOW")
            for line in _fastapi_dep_flow_lines(endpoint_deps):
                typer.echo(line)

        # ── Java Spring Boot branch ────────────────────────────────────
        else:
            _print_header("MODELS")
            for line in _scan_models(project_root):
                typer.echo(line)

            _print_header("RELATIONSHIPS")
            edges, counts, per_src = _scan_relationships(project_root)
            total = sum(counts.values())
            if total == 0:
                typer.echo("No relationships found.")
            else:
                for k in sorted(counts.keys()):
                    typer.echo(f"  {k}: {counts[k]}")
                typer.echo(f"  TOTAL: {total}")
                typer.echo("")
                for src in sorted(per_src.keys(), key=lambda s: s.lower()):
                    typer.echo(f"  {src}:")
                    for e in per_src[src][:50]:
                        typer.echo(f"      {e.kind} {e.field} -> {e.target}")
                if show_edges:
                    typer.echo("")
                    for i, e in enumerate(edges):
                        if i >= max_edges:
                            typer.echo(f"  ... ({len(edges) - i} more)")
                            break
                        typer.echo(f"  {e.src} --[{e.kind}]({e.field})--> {e.target}")

            _print_header("DTO / TYPES")
            for line in _scan_types(project_root):
                typer.echo(line)

            _print_header("ENDPOINTS")
            for line in _scan_endpoints(project_root):
                typer.echo(line)

            _print_header("CORS / SERVER")
            for line in _scan_cors(project_root):
                typer.echo(line)

            _print_header("AUTH")
            for line in _scan_auth(project_root):
                typer.echo(line)

            _print_header("BASE PATH PREFIX")
            for line in _scan_base_path(project_root):
                typer.echo(line)

            _print_header("PAGINATION")
            for line in _scan_pagination(project_root):
                typer.echo(line)

            _print_header("VALIDATION CONSTRAINTS")
            for line in _scan_validation(project_root):
                typer.echo(line)

            _print_header("ENUM TYPES")
            for line in _scan_enums(project_root):
                typer.echo(line)

        # ── TIMING ────────────────────────────────────────────────────
        elapsed = time.perf_counter() - t0
        typer.echo("")
        typer.echo(f"Finished in {elapsed:.3f}s")