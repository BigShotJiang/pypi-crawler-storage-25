"""
codeintel_cli/commands/project/frontend_cmd.py
Registers the `aja frontend` command.
"""
from __future__ import annotations

from pathlib import Path
import typer

from ...errors import InvalidPathError
from ...core.project import find_project_root
from ...frontend.server import serve


def _validate_folder(path: str) -> Path:
    folder = Path(path).resolve()
    if not folder.exists() or not folder.is_dir():
        raise InvalidPathError(message="Invalid folder", path=folder)
    return folder


def register_frontend(app: typer.Typer) -> None:
    @app.command("frontend", help="Launch a visual UI dashboard for models, endpoints, relationships & DTOs.")
    def frontend(
        path: str = typer.Argument(".", help="Project root folder"),
        port: int = typer.Option(7821, "--port", "-p", help="Port to serve the UI on"),
    ) -> None:
        folder = _validate_folder(path)
        project_root = find_project_root(folder)

        typer.echo("=" * 60)
        typer.echo("  CodeIntel Frontend")
        typer.echo("=" * 60)
        typer.echo(f"  ROOT : {project_root}")
        typer.echo(f"  PORT : {port}")
        typer.echo("")
        typer.echo("  Scanning project…")

        serve(project_root, port=port)