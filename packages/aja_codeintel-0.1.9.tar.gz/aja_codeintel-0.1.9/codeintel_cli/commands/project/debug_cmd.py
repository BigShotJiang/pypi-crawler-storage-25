﻿from __future__ import annotations
import time
from pathlib import Path
import typer
from ...core.project import find_project_root


def register_debug(app: typer.Typer) -> None:
    @app.command("debug", help="Show exact error code blocks + call graph (callers/callees).")
    def debug(
        path: str = typer.Argument(".", help="Project root"),
        skip_compile: bool = typer.Option(False, "--skip-compile"),
        verbose: bool = typer.Option(False, "--verbose", "-v"),
    ) -> None:
        t0 = time.perf_counter()
        project_root = find_project_root(Path(path).resolve())

        from ...commands.project.errors_cmd import _run_mvn_compile
        from ...lang.java.method_index import load_index, build_index, save_index, find_method_at_line
        from ...lang.java.call_graph import build_call_graph, get_related
        from ...terminal.printer import print_block
        from ...terminal.error_parser import JavaError

        compile_errors = []
        if not skip_compile:
            typer.echo("Running mvn compile...")
            compile_errors, _, _ = _run_mvn_compile(project_root)

        if not compile_errors:
            typer.echo(typer.style("? No compile errors found.", fg=typer.colors.GREEN))
            raise typer.Exit()

        typer.echo(f"Found {len(compile_errors)} error(s). Building index + call graph...")

        index = load_index(project_root)
        if not index:
            index = build_index(project_root)
            save_index(project_root, index)

        G = build_call_graph(index)

        for e in compile_errors:
            err = JavaError(file=e["file"], line=int(e["line"]), message=e["msg"])
            method = find_method_at_line(index, e["file"], int(e["line"]))
            if not method:
                typer.echo(typer.style(f"\n[!] {e['file']}:{e['line']} — method not in index", fg=typer.colors.YELLOW))
                continue
            related = get_related(G, method["class"], method["method"])
            print_block(err, method, project_root, related["callers"], related["callees"])

        typer.echo(f"\nFinished in {time.perf_counter() - t0:.3f}s")
