﻿from __future__ import annotations
from collections import deque
from pathlib import Path
import os, subprocess, sys
import typer

from ...errors import InvalidPathError
from ...core.resolve_model_target import resolve_model_target_file as _resolve_model_target_file
from ...core.resolve_model_target import _is_java_model_file
from ...lang.java.resolve import resolve_java_import_to_file
from ...graph.builder import build_graph_with_counts, get_hub_files_by_ratio
from ...context.java_rel import clean_java, top_type_name, java_fields_and_rels, model_fields_from_extractor, Rel
from ...db.cache import CacheManager


def _get_cached_files(project_root: Path) -> list[Path]:
    with CacheManager(project_root) as cache:
        if cache.needs_rescan():
            cache.scan_project(verbose=False)
        return [p.resolve() for p in cache.get_cached_files()]

def _fmt_fields(fields, indent="  ") -> list[str]:
    return [f"{indent}- {n}: {t}" + (" (PK)" if pk else "") for n, t, pk in fields]

def _rel_label(kind: str) -> str:
    return {"OneToOne":"1:1","OneToMany":"1:N","ManyToMany":"N:M","ManyToOne":"N:1"}.get(kind, kind)

def _rel_meta(r: Rel) -> str:
    parts = []
    if r.mapped_by: parts.append(f"mappedBy={r.mapped_by}")
    if r.join_table: parts.append(f"joinTable={r.join_table}")
    if r.join_columns: parts.append("joinCols="+",".join(r.join_columns))
    return (" ["+"; ".join(parts)+"]") if parts else ""

def _default_outfile(root: Path, name: str) -> Path:
    base = root / f"codeintel-modeltree-{name}.txt"
    if not base.exists(): return base
    i = 2
    while True:
        p = root / f"codeintel-modeltree-{name}-{i}.txt"
        if not p.exists(): return p
        i += 1

def _open_in_editor(path: Path) -> None:
    p = path.resolve()
    try:
        from ...core.opener import open_file
        open_file(p); return
    except Exception: pass
    try:
        subprocess.Popen(["code", str(p)], close_fds=True); return
    except Exception: pass
    try:
        if sys.platform.startswith("win"):
            subprocess.Popen(["cmd","/c","start","",str(p)], close_fds=True)
    except Exception: pass

def _java_model_scope_from_files(files: list[Path]) -> list[Path]:
    return [p.resolve() for p in files if _is_java_model_file(p)]

def _layered_related(graph, start, depth, include_reverse, hubs):
    adj = {k: set(v) for k, v in graph.items()}
    if include_reverse:
        rev = {}
        for src, deps in adj.items():
            for dst in deps:
                rev.setdefault(dst, set()).add(src)
        for node, incoming in rev.items():
            adj.setdefault(node, set()).update(incoming)
    visited = {start}
    q = deque([(start, 0)])
    by_depth = {}
    while q:
        node, d = q.popleft()
        if d == depth: continue
        for nxt in adj.get(node, set()):
            if nxt in visited or nxt in hubs: continue
            visited.add(nxt)
            nd = d + 1
            by_depth.setdefault(nd, []).append(nxt)
            q.append((nxt, nd))
    return [sorted(by_depth.get(i, [])) for i in range(1, depth+1)]

def _file_for_java_class(name, scope, root):
    if not name: return None
    exact = [p for p in scope if p.suffix.lower()==".java" and p.stem==name]
    if exact: return exact[0].resolve()
    try:
        p = resolve_java_import_to_file(name, root)
        if p and p.exists(): return p.resolve()
    except Exception: pass
    return None

def _collect_java_relationship_map(target, project_root, depth, forward_only, include_hubs):
    all_files = _get_cached_files(project_root)
    graph, dep_counts = build_graph_with_counts(all_files, project_root, use_sqlite_cache=True)
    hubs = set()
    if not include_hubs:
        hubs = get_hub_files_by_ratio(dep_counts, len(all_files), 0.5)
    layers = _layered_related(graph, target.resolve(), depth, not forward_only, hubs)
    model_files = set(_java_model_scope_from_files(all_files))
    scope = [rp for layer in layers for p in layer if (rp := p.resolve()) in model_files]
    try:
        text = clean_java(target.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        text = ""
    model_name = top_type_name(text, target.stem)
    main_fields, main_rels = java_fields_and_rels(target)
    fields_by_entity = {}
    for r in main_rels:
        if not r or not r.target: continue
        p = _file_for_java_class(r.target, scope+[target], project_root)
        if p and p.exists():
            flds = model_fields_from_extractor(p, project_root) or []
            if not flds:
                flds, _ = java_fields_and_rels(p)
            if flds:
                fields_by_entity[r.target] = flds
    # Cached reverse scan — build once per project_root per process
    import functools
    cache_key = str(project_root.resolve())
    if not hasattr(_collect_java_relationship_map, "_rev_cache"):
        _collect_java_relationship_map._rev_cache = {}
    if cache_key not in _collect_java_relationship_map._rev_cache:
        rev_map: dict[str, list[tuple]] = {}
        rev_fields: dict[str, list] = {}
        for p in model_files:
            try:
                t = clean_java(p.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                continue
            src_name = top_type_name(t, p.stem)
            _, rels = java_fields_and_rels(p)
            for rr in rels:
                if not rr or not rr.target:
                    continue
                rev_map.setdefault(rr.target, []).append((src_name, rr))
                if src_name not in rev_fields:
                    flds = model_fields_from_extractor(p, project_root) or []
                    if not flds:
                        flds, _ = java_fields_and_rels(p)
                    if flds:
                        rev_fields[src_name] = flds
        _collect_java_relationship_map._rev_cache[cache_key] = (rev_map, rev_fields)
    rev_map, rev_fields = _collect_java_relationship_map._rev_cache[cache_key]
    reverse = sorted(rev_map.get(model_name, []), key=lambda x: (x[0].lower(), x[1].kind, x[1].field.lower()))
    for src_name, _ in reverse:
        if src_name not in fields_by_entity and src_name in rev_fields:
            fields_by_entity[src_name] = rev_fields[src_name]
    return model_name, main_fields, main_rels, fields_by_entity, reverse


def _view_tree(model, fields, rels, fields_by, reverse):
    lines = [model, "+- Fields"]
    for n,t,pk in fields:
        lines.append(f"|  +- {n}: {t}" + (" (PK)" if pk else ""))
    lines.append("|")
    groups = {}
    for r in rels:
        groups.setdefault(r.kind, []).append(r)
    order = ["OneToOne","OneToMany","ManyToMany","ManyToOne"]
    kinds = [k for k in order if k in groups]
    if not kinds:
        lines += ["+- Relationships", "   +- (none)"]
    else:
        for ki, kind in enumerate(kinds):
            kpad = "   " if ki==len(kinds)-1 else "|  "
            lines.append(f"+- @{kind}")
            for ri, r in enumerate(groups[kind]):
                rlast = ri==len(groups[kind])-1
                suffix = "[]" if kind in {"OneToMany","ManyToMany"} else ""
                lines.append(f"{kpad}+- {r.target}{suffix}  (field: {r.field}){_rel_meta(r)}")
                for fn,ft,_ in fields_by.get(r.target,[]):
                    lines.append(f"{kpad}{'   ' if rlast else '|  '}   +- {fn}: {ft}")
    lines += ["","Reverse References:"]
    lines += [f"  <- {s} (@{r.kind} via {r.field}){_rel_meta(r)}" for s,r in reverse] or ["  (none)"]
    return lines


def register_modeltree(app: typer.Typer) -> None:
    @app.command(help="Model relationship tree")
    def modeltree(
        model: str = typer.Argument(...),
        root: str = typer.Option("."),
        depth: int = typer.Option(2, "--depth", "-d"),
        forward_only: bool = typer.Option(False, "--forward-only"),
        include_hubs: bool = typer.Option(False, "--include-hubs"),
        out: Path | None = typer.Option(None, "--out"),
    ) -> None:
        auto = os.environ.get("AJA_AUTO") == "1"
        target, project_root = _resolve_model_target_file(model, root=root)

        if target.suffix.lower() != ".java":
            raise InvalidPathError(message="Java-only mode: only .java model files supported", path=target)
        if not _is_java_model_file(target):
            raise InvalidPathError(message="Not a model/entity file", path=target)

        model_name, fields, rels, fields_by, reverse = _collect_java_relationship_map(
            target, project_root, depth, forward_only, include_hubs
        )
        lines = _view_tree(model_name, fields, rels, fields_by, reverse)

        # Always print to terminal
        typer.echo("")
        for ln in lines:
            typer.echo(ln)

        # Ask user if they want to save (skip in auto mode)
        save = False if auto else typer.confirm("\nSave to file?", default=False)
        if save:
            out_path = out.resolve() if out else _default_outfile(project_root, model_name)
            out_path.write_text("\n".join(lines)+"\n", encoding="utf-8")
            typer.echo(out_path.as_posix())
            _open_in_editor(out_path)



