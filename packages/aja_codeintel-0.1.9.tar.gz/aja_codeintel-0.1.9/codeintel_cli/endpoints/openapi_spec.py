from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional, Set
import json
import re

from .models import Endpoint


def find_openapi_files(project_root: Path) -> list[Path]:
    names = {
        "openapi.yml",
        "openapi.yaml",
        "swagger.yml",
        "swagger.yaml",
        "openapi.json",
        "swagger.json",
    }
    out: list[Path] = []
    for p in project_root.rglob("*"):
        if not p.is_file():
            continue
        if p.name.lower() in names:
            out.append(p)
    return sorted(out, key=lambda x: str(x).lower())


def _yaml_paths_fallback(raw: str) -> Dict[str, Any]:
    """
    Minimal YAML fallback (no PyYAML installed):
    builds {"paths": {"/x": {"get": {}, "post": {}}}}
    """
    paths: Dict[str, Any] = {}
    in_paths = False
    cur_path: Optional[str] = None

    for line in raw.splitlines():
        if re.match(r"^\s*paths\s*:\s*$", line):
            in_paths = True
            continue
        if not in_paths:
            continue

        mpath = re.match(r"^\s{2}(/[^:]+)\s*:\s*$", line)
        if mpath:
            cur_path = mpath.group(1).strip()
            paths[cur_path] = {}
            continue

        mmeth = re.match(r"^\s{4}(get|post|put|delete|patch|options|head)\s*:\s*$", line, re.I)
        if mmeth and cur_path:
            paths[cur_path][mmeth.group(1).lower()] = {}

        if in_paths and line and not line.startswith(" "):
            break

    return {"paths": paths}


def _load_openapi_obj(path: Path) -> Optional[Dict[str, Any]]:
    suf = path.suffix.lower()
    try:
        raw = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None

    if suf == ".json":
        try:
            return json.loads(raw)
        except Exception:
            return None

    # YAML (preferred)
    try:
        import yaml  # type: ignore

        return yaml.safe_load(raw)
    except Exception:
        return _yaml_paths_fallback(raw)


_HTTP_METHODS = {"get", "post", "put", "delete", "patch", "options", "head"}


def _extract_scopes_from_security(sec: Any) -> Set[str]:
    """
    OpenAPI security shape:
      security: [ { schemeName: [scope1, scope2] }, { otherScheme: [] } ]
    """
    scopes: Set[str] = set()
    if not isinstance(sec, list):
        return scopes
    for entry in sec:
        if not isinstance(entry, dict):
            continue
        for _scheme, vals in entry.items():
            if isinstance(vals, list):
                for v in vals:
                    if isinstance(v, str) and v.strip():
                        scopes.add(v.strip())
    return scopes


def _looks_admin(path: str, tag: str, scopes: Set[str]) -> bool:
    p = (path or "").lower()
    t = (tag or "").lower()
    if p.startswith("/admin") or p.startswith("/api/admin"):
        return True
    if "admin" in t:
        return True
    for s in scopes:
        sl = s.lower()
        if "admin" in sl:
            return True
    return False


def _decide_roles(
    *,
    path: str,
    tag: str,
    global_security: Any,
    op_has_security_key: bool,
    op_security_value: Any,
) -> Set[str]:
    """
    Decide PUBLIC/AUTH/ADMIN based on OpenAPI security semantics.
    """
    # If operation explicitly says `security: []` => PUBLIC
    if op_has_security_key and isinstance(op_security_value, list) and len(op_security_value) == 0:
        return {"PUBLIC"}

    # Determine if secured
    has_global_sec = isinstance(global_security, list) and len(global_security) > 0

    # If global security exists and op doesn't override => secured
    if has_global_sec and not op_has_security_key:
        op_sec = global_security
        secured = True
    else:
        # If op has security and it's non-empty list => secured
        if op_has_security_key:
            secured = isinstance(op_security_value, list) and len(op_security_value) > 0
            op_sec = op_security_value
        else:
            # No global security and no op security => public
            secured = False
            op_sec = None

    if not secured:
        return {"PUBLIC"}

    scopes = _extract_scopes_from_security(op_sec)
    if _looks_admin(path, tag, scopes):
        return {"ADMIN"}

    return {"AUTH"}


def extract_openapi_endpoints(project_root: Path) -> list[Endpoint]:
    eps: list[Endpoint] = []
    files = find_openapi_files(project_root)

    for f in files:
        obj = _load_openapi_obj(f)
        if not obj or "paths" not in obj:
            continue

        global_security = obj.get("security")

        paths = obj.get("paths") or {}
        if not isinstance(paths, dict):
            continue

        for pth, methods in paths.items():
            if not isinstance(methods, dict):
                continue

            for m, meta in methods.items():
                ml = str(m).lower()
                if ml not in _HTTP_METHODS:
                    continue

                op_id = ""
                tag = ""
                op_has_security_key = False
                op_security_value = None

                if isinstance(meta, dict):
                    op_id = str(meta.get("operationId") or "")
                    tags = meta.get("tags") or []
                    if isinstance(tags, list) and tags:
                        tag = str(tags[0] or "")

                    # Key point: distinguish "no key" vs "security: []"
                    if "security" in meta:
                        op_has_security_key = True
                        op_security_value = meta.get("security")

                roles = _decide_roles(
                    path=str(pth),
                    tag=tag,
                    global_security=global_security,
                    op_has_security_key=op_has_security_key,
                    op_security_value=op_security_value,
                )

                handler = op_id or (f"{tag}:{ml.upper()}" if tag else ml.upper())

                eps.append(
                    Endpoint(
                        method=ml.upper(),
                        path=str(pth),
                        file=str(f),
                        line=1,
                        handler=handler,
                        framework="openapi",
                        controller=tag or None,
                        roles=roles,
                    )
                )

    return eps