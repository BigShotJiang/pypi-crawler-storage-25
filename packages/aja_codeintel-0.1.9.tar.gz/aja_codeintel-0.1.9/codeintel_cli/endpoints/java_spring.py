﻿from __future__ import annotations

import re
from fnmatch import fnmatch
from pathlib import Path
from typing import List, Optional, Set

from .models import Endpoint

_MAPPING_ANN = {
    "GetMapping", "PostMapping", "PutMapping",
    "DeleteMapping", "PatchMapping", "RequestMapping",
}

_HTTP_METHOD_MAP = {
    "getmapping": ["GET"],
    "postmapping": ["POST"],
    "putmapping": ["PUT"],
    "deletemapping": ["DELETE"],
    "patchmapping": ["PATCH"],
}

_PREAUTHORIZE_RE = re.compile(r'@PreAuthorize\s*\(\s*"([^"]+)"\s*\)')
_SECURED_RE      = re.compile(r"@Secured\s*\((.*?)\)")
_ROLESALLOWED_RE = re.compile(r"@RolesAllowed\s*\((.*?)\)")
_HASROLE_RE      = re.compile(r"hasRole\s*\(\s*'([^']+)'\s*\)")
_HASANYROLE_RE   = re.compile(r"hasAnyRole\s*\(\s*([^\)]+)\)")
_HASAUTH_RE      = re.compile(r"hasAuthority\s*\(\s*'([^']+)'\s*\)")
_HASANYAUTH_RE   = re.compile(r"hasAnyAuthority\s*\(\s*([^\)]+)\)")


# ---------------------------------------------------------------------------
# Path / method helpers
# ---------------------------------------------------------------------------

def _extract_paths_from_ann(ann: dict) -> list[str]:
    args = ann.get("args", "") or ""
    pairs = ann.get("pairs", {}) or {}

    for key in ("value", "path"):
        if key in pairs:
            v = pairs[key].strip().strip('"')
            return [v] if v else []

    arr = re.search(r'\b(?:value|path)\s*=\s*\{([^}]+)\}', args, re.DOTALL)
    if arr:
        return re.findall(r'"([^"]+)"', arr.group(1))

    positional = re.findall(r'"([^"]+)"', args)
    if positional:
        return [positional[0]]

    return []


def _http_methods_from_ann(ann: dict) -> list[str]:
    name_lower = ann["name"].lower()
    if name_lower in _HTTP_METHOD_MAP:
        return _HTTP_METHOD_MAP[name_lower]
    if name_lower == "requestmapping":
        args = ann.get("args", "") or ""
        found = re.findall(r"RequestMethod\.([A-Z]+)", args)
        return found if found else ["GET"]
    return []


def _normalize_join(base: str, sub: str) -> str:
    base = (base or "").rstrip("/")
    sub = (sub or "").strip()
    if not sub:
        return base or "/"
    if not sub.startswith("/"):
        sub = "/" + sub
    result = base + sub
    return result if result.startswith("/") else "/" + result


# ---------------------------------------------------------------------------
# Role helpers
# ---------------------------------------------------------------------------

def _roles_from_expr(expr: str) -> Set[str]:
    roles: Set[str] = set()
    for m in _HASROLE_RE.finditer(expr):
        roles.add(m.group(1))
    for m in _HASANYROLE_RE.finditer(expr):
        for r in re.findall(r"'([^']+)'", m.group(1)):
            roles.add(r)
    for m in _HASAUTH_RE.finditer(expr):
        r = m.group(1)
        roles.add(r[5:] if r.startswith("ROLE_") else r)
    for m in _HASANYAUTH_RE.finditer(expr):
        for r in re.findall(r"'([^']+)'", m.group(1)):
            roles.add(r[5:] if r.startswith("ROLE_") else r)
    return roles


def _roles_from_strings(arg: str) -> Set[str]:
    out: Set[str] = set()
    for s in re.findall(r'"([^"]+)"', arg or ""):
        out.add(s[5:] if s.startswith("ROLE_") else s)
    return out


def _extract_roles(text: str) -> Set[str]:
    roles: Set[str] = set()
    for m in _PREAUTHORIZE_RE.finditer(text):
        roles |= _roles_from_expr(m.group(1))
    for m in _SECURED_RE.finditer(text):
        roles |= _roles_from_strings(m.group(1))
    for m in _ROLESALLOWED_RE.finditer(text):
        roles |= _roles_from_strings(m.group(1))
    return roles


# ---------------------------------------------------------------------------
# Core extractor
# ---------------------------------------------------------------------------

def extract_spring_endpoints(
    java_source: str,
    file_path: str,
    *,
    default_auth: bool = False,
    permit_all: Optional[List[str]] = None,
) -> List[Endpoint]:
    try:
        from ..lang.java.ast_engine import is_available, extract_class_info
        if is_available():
            return _extract_via_ast(
                java_source, file_path,
                default_auth=default_auth, permit_all=permit_all,
            )
    except Exception:
        pass
    return _extract_via_regex(
        java_source, file_path,
        default_auth=default_auth, permit_all=permit_all,
    )


# ---------------------------------------------------------------------------
# AST-based extraction
# ---------------------------------------------------------------------------

def _extract_via_ast(
    java_source: str,
    file_path: str,
    *,
    default_auth: bool,
    permit_all: Optional[List[str]],
) -> List[Endpoint]:
    import tempfile, os
    from ..lang.java.ast_engine import extract_class_info

    with tempfile.NamedTemporaryFile(suffix=".java", delete=False, mode="wb") as f:
        f.write(java_source.encode("utf-8", errors="ignore"))
        tmp = f.name

    try:
        class_infos = extract_class_info(Path(tmp))
    finally:
        try:
            os.unlink(tmp)
        except Exception:
            pass

    endpoints: List[Endpoint] = []

    for cls in class_infos:
        ann_names = cls.get("annotation_names", set())

        is_controller = bool(ann_names & {"Controller", "RestController"})
        if not is_controller:
            continue

        controller_name = cls["name"]

        base_path = ""
        for ann in cls.get("annotations", []):
            if ann["name"] == "RequestMapping":
                paths = _extract_paths_from_ann(ann)
                if paths:
                    base_path = paths[0]
                    if not base_path.startswith("/"):
                        base_path = "/" + base_path
                break

        class_roles = _extract_roles(java_source[:500])

        for method in cls.get("methods", []):
            mapping_anns = [a for a in method.get("annotations", [])
                            if a["name"] in _MAPPING_ANN]
            if not mapping_anns:
                continue

            method_roles = class_roles | _extract_roles(
                " ".join(a.get("args", "") or "" for a in method.get("annotations", []))
            )

            handler = method["name"]
            line = method.get("line", 0)

            for ann in mapping_anns:
                http_methods = _http_methods_from_ann(ann)
                paths = _extract_paths_from_ann(ann) or [""]

                for http_m in http_methods:
                    for p in paths:
                        full = _normalize_join(base_path, p)
                        roles = method_roles or None
                        if not roles:
                            if _is_public_path(full, permit_all):
                                roles = None
                            elif default_auth:
                                roles = {"AUTH"}

                        endpoints.append(Endpoint(
                            method=http_m,
                            path=full,
                            file=file_path,
                            line=line,
                            handler=handler,
                            framework="spring",
                            controller=controller_name,
                            roles=roles,
                        ))

    return endpoints


# ---------------------------------------------------------------------------
# Regex fallback
# ---------------------------------------------------------------------------

_ANNOT_RE  = re.compile(r"@\s*([A-Za-z_]\w*)\s*(\((.*?)\))?", re.DOTALL)
_CLASS_RE  = re.compile(r"\b(class|record)\s+([A-Za-z_]\w*)\b")
_METHOD_RE = re.compile(
    r"(public|protected|private)?\s*(static\s+)?[\w<>\[\], ?]+\s+([A-Za-z_]\w*)\s*\("
)


def _extract_paths_regex(arg_str: str) -> List[str]:
    s = arg_str or ""
    named = re.findall(r'\b(?:value|path)\s*=\s*"([^"]+)"', s)
    if named:
        return named
    named_arr = re.search(r'\b(?:value|path)\s*=\s*\{([^}]+)\}', s, re.DOTALL)
    if named_arr:
        return re.findall(r'"([^"]+)"', named_arr.group(1))
    positional = re.findall(r'"([^"]+)"', s)
    return [positional[0]] if positional else []


def _methods_from_annotation_regex(ann: str, args: str) -> List[str]:
    al = ann.lower()
    if al in _HTTP_METHOD_MAP:
        return _HTTP_METHOD_MAP[al]
    if al == "requestmapping":
        found = re.findall(r"RequestMethod\.([A-Z]+)", args or "")
        return found if found else ["GET"]
    return []


def _is_public_path(path: str, permit_all: Optional[List[str]]) -> bool:
    for pat in permit_all or []:
        if fnmatch(path, pat.replace("**", "*")):
            return True
    return (
        path.startswith("/auth")
        or path.startswith("/api/auth/")
        or path.startswith("/api/authenticate")
    )


def _extract_via_regex(
    java_source: str,
    file_path: str,
    *,
    default_auth: bool,
    permit_all: Optional[List[str]],
) -> List[Endpoint]:
    endpoints: List[Endpoint] = []
    lines = java_source.splitlines()

    mcls = _CLASS_RE.search(java_source)
    if not mcls:
        return []

    class_pos = mcls.start()
    controller = mcls.group(2)
    pre = java_source[:class_pos]

    if "@RestController" not in pre and "@Controller" not in pre:
        return []

    base_path = ""
    for m in _ANNOT_RE.finditer(pre):
        if m.group(1) == "RequestMapping":
            ps = _extract_paths_regex(m.group(3) or "")
            if ps:
                base_path = ps[0] if ps[0].startswith("/") else "/" + ps[0]

    class_roles = _extract_roles(pre)
    pending: list[tuple[str, str, int]] = []

    for i, line in enumerate(lines, start=1):
        s = line.strip()
        if s.startswith("@"):
            am = _ANNOT_RE.search(s)
            if am and am.group(1) in _MAPPING_ANN:
                pending.append((am.group(1), am.group(3) or "", i))
            continue

        mm = _METHOD_RE.search(s)
        if mm and pending:
            handler = mm.group(3)
            j = i - 2
            buf: list[str] = []
            while j >= 0:
                s2 = (lines[j] or "").strip()
                if not s2:
                    j -= 1
                    continue
                if s2.startswith("@"):
                    buf.append(lines[j])
                    j -= 1
                    continue
                break
            method_roles = _extract_roles("\n".join(reversed(buf)))
            roles = class_roles | method_roles

            for ann, args, ln in pending:
                for meth in _methods_from_annotation_regex(ann, args):
                    paths = _extract_paths_regex(args) or [""]
                    for p in paths:
                        full = _normalize_join(base_path, p)
                        final_roles: Optional[Set[str]] = roles or None
                        if not final_roles:
                            if _is_public_path(full, permit_all):
                                final_roles = None
                            elif default_auth:
                                final_roles = {"AUTH"}
                        endpoints.append(Endpoint(
                            method=meth,
                            path=full,
                            file=file_path,
                            line=ln,
                            handler=handler,
                            framework="spring",
                            controller=controller,
                            roles=final_roles,
                        ))
            pending = []

    return endpoints


# ---------------------------------------------------------------------------
# CORS / server config extraction
# ---------------------------------------------------------------------------

_ALLOWED_ORIGINS_RE          = re.compile(r'allowedOrigins\s*\(\s*"([^"]+)"')
_ALLOWED_ORIGINS_PATTERNS_RE = re.compile(r'allowedOriginPatterns\s*\(\s*"([^"]+)"')
_CORS_PORT_RE                = re.compile(r'https?://[^"\']*:(\d{2,5})')
_SERVER_PORT_RE              = re.compile(r'(?:server\.port|SERVER_PORT)\s*[=:]\s*(\d{2,5})')
_CROSS_ORIGIN_RE             = re.compile(r'@CrossOrigin\s*\(([^)]*)\)', re.DOTALL)
_YML_ALLOWED_ORIGINS_RE      = re.compile(r"allowed-origins\s*:\s*['\"]([^'\"]+)['\"]")
_YML_ALLOWED_ORIGIN_PAT_RE   = re.compile(r"allowed-origin-patterns\s*:\s*['\"]([^'\"]+)['\"]")


def extract_cors_config(project_root: Path) -> dict:
    """
    Scans project for CORS and server port configuration.

    Detects:
      - server.port from application.properties / yml
      - allowedOrigins / allowedOriginPatterns in WebMvcConfigurer beans
      - allowed-origins / allowed-origin-patterns in yml (JHipster style)
      - @CrossOrigin on controllers

    Returns:
        {
          "server_port": str | None,
          "origins": [str],
          "ports": [str],
          "cross_origin_controllers": [str],
          "sources": [str],
        }
    """
    server_port: Optional[str] = None
    origins: list[str] = []
    ports: set[str] = set()
    sources: set[str] = set()
    cross_origin_controllers: set[str] = set()

    # ── 1. properties / yml ──────────────────────────────────────────────
    for pattern in ("**/*.properties", "**/*.yml", "**/*.yaml"):
        for f in project_root.rglob(pattern):
            if any(x in f.parts for x in ("test", "node_modules", "target", "build")):
                continue
            try:
                text = f.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue

            if not server_port:
                m = _SERVER_PORT_RE.search(text)
                if m:
                    server_port = m.group(1)

            for pat in (_ALLOWED_ORIGINS_RE, _ALLOWED_ORIGINS_PATTERNS_RE,
                        _YML_ALLOWED_ORIGINS_RE, _YML_ALLOWED_ORIGIN_PAT_RE):
                for m in pat.finditer(text):
                    for o in m.group(1).split(","):
                        o = o.strip().strip("'\"")
                        if o:
                            origins.append(o)
                            pm = _CORS_PORT_RE.search(o)
                            if pm:
                                ports.add(pm.group(1))
                    sources.add(f.name)

    # ── 2. Java files ────────────────────────────────────────────────────
    for f in project_root.rglob("*.java"):
        if any(x in f.parts for x in ("test", "target", "build")):
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue

        file_hit = False

        # WebMvcConfigurer / CorsConfigurationSource
        if "allowedOrigins" in text or "allowedOriginPatterns" in text:
            for pat in (_ALLOWED_ORIGINS_RE, _ALLOWED_ORIGINS_PATTERNS_RE):
                for m in pat.finditer(text):
                    for o in m.group(1).split(","):
                        o = o.strip().strip("'\"")
                        if o:
                            origins.append(o)
                            pm = _CORS_PORT_RE.search(o)
                            if pm:
                                ports.add(pm.group(1))
            file_hit = True

        # @CrossOrigin on controllers
        if "@CrossOrigin" in text:
            for m in _CROSS_ORIGIN_RE.finditer(text):
                inner = m.group(1)
                for om in re.finditer(r'"(https?://[^"]+)"', inner):
                    o = om.group(1)
                    origins.append(o)
                    pm = _CORS_PORT_RE.search(o)
                    if pm:
                        ports.add(pm.group(1))
            cls_m = re.search(r'class\s+(\w+)', text)
            if cls_m:
                cross_origin_controllers.add(cls_m.group(1))
            file_hit = True

        if file_hit:
            sources.add(f.name)

    return {
        "server_port": server_port,
        "origins": sorted(set(origins)),
        "ports": sorted(ports),
        "cross_origin_controllers": sorted(cross_origin_controllers),
        "sources": sorted(sources),
    }