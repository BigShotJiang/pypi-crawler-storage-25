from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any, Set


@dataclass(frozen=True)
class Endpoint:
    method: str
    path: str
    file: str
    line: int
    handler: str
    framework: str
    controller: Optional[str] = None
    roles: Optional[Set[str]] = None  # e.g. {"ADMIN","CUSTOMER"}

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        
        if self.roles is not None:
            d["roles"] = sorted(self.roles)
        return d