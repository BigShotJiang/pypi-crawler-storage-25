from __future__ import annotations

import ast
from typing import List, Optional, Tuple

from .models import Endpoint
from .fastapi_scanner import extract_fastapi_endpoints

_FASTAPI_METHODS = {"get", "post", "put", "delete", "patch", "options", "head"}


def _get_str(node: ast.AST) -> Optional[str]:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _call_name(expr: ast.AST) -> Tuple[Optional[str], Optional[str]]:
    if isinstance(expr, ast.Call):
        func = expr.func
        if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
            return func.value.id, func.attr
    return None, None


def _extract_flask_methods(dec_call: ast.Call) -> List[str]:
    for kw in dec_call.keywords:
        if kw.arg == "methods" and isinstance(kw.value, (ast.List, ast.Tuple)):
            ms: List[str] = []
            for el in kw.value.elts:
                s = _get_str(el)
                if s:
                    ms.append(s.upper())
            return sorted(set(ms)) if ms else ["GET"]
    return ["GET"]


def extract_python_endpoints(py_source: str, file_path: str) -> List[Endpoint]:
    """
    Extract Python web endpoints from a single source file.

    FastAPI endpoints are handled by the full scanner (prefix-aware).
    Flask endpoints use the legacy regex/AST path.
    """
    # Detect FastAPI first — delegate to the richer scanner
    if _is_fastapi_source(py_source):
        return extract_fastapi_endpoints(py_source, file_path)

    # --- Flask fallback ---
    try:
        tree = ast.parse(py_source)
    except SyntaxError:
        return []

    endpoints: List[Endpoint] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue

        if not node.decorator_list:
            continue

        handler = node.name

        for dec in node.decorator_list:
            if not isinstance(dec, ast.Call):
                continue

            obj, meth = _call_name(dec)
            if not obj or not meth:
                continue

            pnode = dec.args[0] if dec.args else None
            path = _get_str(pnode) if pnode else None
            if not path or not path.startswith("/"):
                continue

            low = meth.lower()
            if low == "route":
                ms = _extract_flask_methods(dec)
                for m in ms:
                    endpoints.append(
                        Endpoint(
                            method=m,
                            path=path,
                            file=file_path,
                            line=getattr(dec, "lineno", getattr(node, "lineno", 1)),
                            handler=handler,
                            framework="flask",
                        )
                    )

    return endpoints


def _is_fastapi_source(source: str) -> bool:
    """Quick check: does this file import or reference FastAPI / APIRouter?"""
    return "FastAPI" in source or "APIRouter" in source or "fastapi" in source