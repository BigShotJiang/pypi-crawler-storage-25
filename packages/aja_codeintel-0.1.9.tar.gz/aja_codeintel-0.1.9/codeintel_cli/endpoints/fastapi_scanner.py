"""
FastAPI repository scanner.

Multi-file, prefix-aware scanner that extracts:
  - Endpoints (@app/router.get/post/… + @router.api_route)
  - Full route paths (APIRouter prefix + include_router prefix stacking)
  - Request-body Pydantic models (typed function parameters)
  - Response models (response_model=… in decorator)
  - Pydantic DTO definitions (class X(BaseModel))
  - SQLAlchemy entity definitions (class X(Base))

Output types are compatible with the existing Endpoint / ModelDef / TypeDef
schemas already produced by the Java Spring scanner so that the same
CLI commands can render both.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from .models import Endpoint

# ---------------------------------------------------------------------------
# Internal data structures
# ---------------------------------------------------------------------------

@dataclass
class RouterInfo:
    var_name: str
    file: str
    prefix: str = ""
    tags: list[str] = field(default_factory=list)
    is_app: bool = False        # True = FastAPI(), False = APIRouter()


@dataclass
class IncludeCall:
    """Represents app.include_router(child, prefix=…) or router.include_router(…)."""
    parent_file: str
    parent_var: str
    child_ref: str              # local variable name of the child router
    child_origin_file: str | None   # resolved file if child was imported
    extra_prefix: str = ""
    extra_tags: list[str] = field(default_factory=list)


@dataclass
class RawEndpoint:
    """Endpoint as seen inside a single file (prefix not yet applied)."""
    router_file: str
    router_var: str
    method: str
    raw_path: str
    handler: str
    file: str
    line: int
    tags: list[str] = field(default_factory=list)
    response_model: str | None = None
    request_body_model: str | None = None
    depends: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Pydantic DTO data structures (mirrors Java TypeDef/ModelDef)
# ---------------------------------------------------------------------------

@dataclass
class PydanticField:
    name: str
    type: str
    required: bool
    default: str | None = None


@dataclass
class PydanticDTO:
    name: str
    file: str
    bases: list[str]
    fields: list[PydanticField]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "file": self.file,
            "kind": "pydantic",
            "bases": self.bases,
            "fields": [
                {
                    "name": f.name,
                    "type": f.type,
                    "required": f.required,
                    "default": f.default,
                }
                for f in self.fields
            ],
        }


# ---------------------------------------------------------------------------
# SQLAlchemy model data structures (mirrors Java ModelDef)
# ---------------------------------------------------------------------------

@dataclass
class SQLAlchemyColumn:
    name: str
    col_type: str
    primary_key: bool = False
    foreign_key: str | None = None


@dataclass
class SQLAlchemyRelationship:
    name: str
    target: str
    kind: str = "relationship"


@dataclass
class SQLAlchemyModel:
    name: str
    file: str
    table_name: str
    columns: list[SQLAlchemyColumn]
    relationships: list[SQLAlchemyRelationship]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "file": self.file,
            "kind": "sqlalchemy",
            "table": self.table_name,
            "columns": [
                {
                    "name": c.name,
                    "type": c.col_type,
                    "primary_key": c.primary_key,
                    "foreign_key": c.foreign_key,
                }
                for c in self.columns
            ],
            "relationships": [
                {"name": r.name, "target": r.target, "kind": r.kind}
                for r in self.relationships
            ],
        }


# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------

_FASTAPI_METHODS = {
    "get", "post", "put", "delete", "patch", "options", "head",
}

_PYDANTIC_BASES = {"BaseModel", "pydantic.BaseModel"}
_SQLALCHEMY_BASES = {"Base", "DeclarativeBase", "DeclarativeMeta"}

# Column type name patterns
_COLUMN_TYPE_RE = re.compile(
    r"\b(Integer|String|Text|Boolean|Float|Double|Numeric|Date(?:Time)?|"
    r"JSON|JSONB|UUID|BigInteger|SmallInteger|LargeBinary|Enum|"
    r"VARCHAR|CHAR|INT|FLOAT|BOOL|TIMESTAMP|BYTEA)\b",
    re.IGNORECASE,
)


def _unparse(node: ast.AST | None) -> str:
    if node is None:
        return "Any"
    try:
        return ast.unparse(node)
    except Exception:
        return node.__class__.__name__


def _get_str_const(node: ast.AST | None) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _get_str_list(node: ast.AST | None) -> list[str]:
    """Extract a list of string constants from an ast.List / ast.Tuple."""
    if node is None:
        return []
    if isinstance(node, (ast.List, ast.Tuple)):
        out = []
        for elt in node.elts:
            s = _get_str_const(elt)
            if s:
                out.append(s)
        return out
    s = _get_str_const(node)
    return [s] if s else []


def _call_obj_attr(expr: ast.AST) -> tuple[str | None, str | None]:
    """For `obj.method(…)` return (obj_name, method_name)."""
    if isinstance(expr, ast.Call):
        func = expr.func
        if isinstance(func, ast.Attribute):
            if isinstance(func.value, ast.Name):
                return func.value.id, func.attr
            # obj could be attribute chain (e.g. module.router.get)
            if isinstance(func.value, ast.Attribute):
                return _unparse(func.value), func.attr
    return None, None


def _kw_value(call: ast.Call, name: str) -> ast.AST | None:
    for kw in call.keywords:
        if kw.arg == name:
            return kw.value
    return None


def _is_fastapi_instance(call: ast.Call) -> bool:
    func = call.func
    if isinstance(func, ast.Name) and func.id == "FastAPI":
        return True
    if isinstance(func, ast.Attribute) and func.attr == "FastAPI":
        return True
    return False


def _is_apirouter_instance(call: ast.Call) -> bool:
    func = call.func
    if isinstance(func, ast.Name) and func.id == "APIRouter":
        return True
    if isinstance(func, ast.Attribute) and func.attr == "APIRouter":
        return True
    return False


def _extract_prefix_tags(call: ast.Call) -> tuple[str, list[str]]:
    prefix = ""
    tags: list[str] = []
    p = _kw_value(call, "prefix")
    if p:
        prefix = _get_str_const(p) or ""
    t = _kw_value(call, "tags")
    if t:
        tags = _get_str_list(t)
    return prefix, tags


def _normalize_path(base: str, sub: str) -> str:
    base = (base or "").rstrip("/")
    sub = (sub or "").lstrip("/")
    if not sub:
        return base or "/"
    result = f"{base}/{sub}"
    return result if result.startswith("/") else f"/{result}"


# ---------------------------------------------------------------------------
# Single-file AST visitor
# ---------------------------------------------------------------------------

class _FileVisitor(ast.NodeVisitor):
    """Collects routers, raw endpoints, Pydantic models, and SQLAlchemy models
    from a single Python source file."""

    def __init__(self, file_str: str) -> None:
        self.file = file_str
        # local_name -> source module (for tracking imported routers)
        self.imports: dict[str, str] = {}
        # var_name -> RouterInfo (FastAPI app or APIRouter instances defined here)
        self.routers: dict[str, RouterInfo] = {}
        # calls to include_router in this file
        self.includes: list[IncludeCall] = []
        # raw endpoint records
        self.raw_endpoints: list[RawEndpoint] = []
        # Pydantic DTOs
        self.pydantic_dtos: list[PydanticDTO] = []
        # SQLAlchemy models
        self.sqlalchemy_models: list[SQLAlchemyModel] = []
        # names of Pydantic models already collected in this file (for child detection)
        self._local_pydantic_names: set[str] = set()

    # ------------------------------------------------------------------
    # Import tracking
    # ------------------------------------------------------------------

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            local = alias.asname or alias.name
            self.imports[local] = alias.name
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        for alias in node.names:
            local = alias.asname or alias.name
            self.imports[local] = module
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Assignment: detect `app = FastAPI()` / `router = APIRouter(…)`
    # ------------------------------------------------------------------

    def visit_Assign(self, node: ast.Assign) -> None:
        if not (isinstance(node.value, ast.Call)):
            self.generic_visit(node)
            return

        call = node.value
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue
            var = target.id

            if _is_fastapi_instance(call):
                prefix, tags = _extract_prefix_tags(call)
                self.routers[var] = RouterInfo(
                    var_name=var, file=self.file,
                    prefix=prefix, tags=tags, is_app=True,
                )

            elif _is_apirouter_instance(call):
                prefix, tags = _extract_prefix_tags(call)
                self.routers[var] = RouterInfo(
                    var_name=var, file=self.file,
                    prefix=prefix, tags=tags, is_app=False,
                )

        self.generic_visit(node)

    # Also handle annotated assignments: `app: FastAPI = FastAPI()`
    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if isinstance(node.target, ast.Name) and isinstance(node.value, ast.Call):
            var = node.target.id
            call = node.value
            if _is_fastapi_instance(call):
                prefix, tags = _extract_prefix_tags(call)
                self.routers[var] = RouterInfo(
                    var_name=var, file=self.file,
                    prefix=prefix, tags=tags, is_app=True,
                )
            elif _is_apirouter_instance(call):
                prefix, tags = _extract_prefix_tags(call)
                self.routers[var] = RouterInfo(
                    var_name=var, file=self.file,
                    prefix=prefix, tags=tags, is_app=False,
                )
        self.generic_visit(node)

    # ------------------------------------------------------------------
    # Top-level expressions: detect include_router calls as statements
    # ------------------------------------------------------------------

    def visit_Expr(self, node: ast.Expr) -> None:
        if isinstance(node.value, ast.Call):
            self._try_include_router(node.value)
        self.generic_visit(node)

    def _try_include_router(self, call: ast.Call) -> None:
        obj, meth = _call_obj_attr(call)
        if meth != "include_router":
            return

        # First positional arg: the child router
        if not call.args:
            return
        child_node = call.args[0]
        child_ref = _unparse(child_node)  # may be "router", "users.router", etc.

        extra_prefix_node = _kw_value(call, "prefix")
        extra_prefix = _get_str_const(extra_prefix_node) or ""
        extra_tags = _get_str_list(_kw_value(call, "tags"))

        self.includes.append(IncludeCall(
            parent_file=self.file,
            parent_var=obj or "",
            child_ref=child_ref,
            child_origin_file=None,   # resolved later
            extra_prefix=extra_prefix,
            extra_tags=extra_tags,
        ))

    # ------------------------------------------------------------------
    # Function definitions: detect endpoint decorators
    # ------------------------------------------------------------------

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._process_function(node)
        self.generic_visit(node)

    visit_AsyncFunctionDef = visit_FunctionDef

    def _process_function(self, node: ast.FunctionDef) -> None:
        for dec in node.decorator_list:
            if not isinstance(dec, ast.Call):
                continue

            obj, meth = _call_obj_attr(dec)
            if not obj or not meth:
                continue

            methods: list[str] = []
            raw_path: str | None = None

            ml = meth.lower()
            if ml in _FASTAPI_METHODS:
                methods = [ml.upper()]
                raw_path = _get_str_const(dec.args[0]) if dec.args else None

            elif ml == "api_route":
                raw_path = _get_str_const(dec.args[0]) if dec.args else None
                methods_node = _kw_value(dec, "methods")
                if isinstance(methods_node, (ast.List, ast.Tuple)):
                    for elt in methods_node.elts:
                        s = _get_str_const(elt)
                        if s:
                            methods.append(s.upper())
                if not methods:
                    methods = ["GET"]

            if not methods or raw_path is None:
                continue

            tags = _get_str_list(_kw_value(dec, "tags"))
            resp_model_node = _kw_value(dec, "response_model")
            response_model = _unparse(resp_model_node) if resp_model_node else None

            # Return type hint as fallback for response model
            if response_model is None and node.returns is not None:
                response_model = _unparse(node.returns)

            # Request body: look for Pydantic-typed parameter
            request_body = self._find_request_body(node)

            # Depends(...) injected dependencies
            depends = self._find_depends(node)

            lineno = getattr(dec, "lineno", getattr(node, "lineno", 1))

            for m in methods:
                self.raw_endpoints.append(RawEndpoint(
                    router_file=self.file,
                    router_var=obj,
                    method=m,
                    raw_path=raw_path,
                    handler=node.name,
                    file=self.file,
                    line=lineno,
                    tags=tags,
                    response_model=response_model,
                    request_body_model=request_body,
                    depends=depends,
                ))

    def _find_request_body(self, node: ast.FunctionDef) -> str | None:
        """
        Find a parameter annotated with a Pydantic model type.
        Heuristic: if the annotation is a Name not in primitive types and
        not a FastAPI dependency (Depends, Query, Path, Header, etc.),
        it's likely a request body.
        """
        _SKIP_TYPES = {
            "str", "int", "float", "bool", "bytes", "None",
            "Any", "Optional", "Union", "List", "Dict", "Tuple",
            "Response", "Request", "Session", "BackgroundTasks",
            "HTTPException",
        }
        _FASTAPI_PARAMS = {"Depends", "Query", "Path", "Header", "Cookie", "Form", "File"}

        for arg in node.args.args:
            if arg.arg in ("self", "cls", "request", "response", "db", "session"):
                continue
            if arg.annotation is None:
                continue
            ann = arg.annotation

            # Skip if annotation is a Call (e.g., `= Depends(...)`)
            if isinstance(ann, ast.Call):
                continue

            ann_str = _unparse(ann)

            # Strip Optional[...] and list[...]
            inner = re.sub(r"^Optional\[(.+)\]$", r"\1", ann_str)
            inner = re.sub(r"^List\[(.+)\]$", r"\1", inner)
            inner = re.sub(r"^list\[(.+)\]$", r"\1", inner)

            # Skip primitives and FastAPI special params
            if inner in _SKIP_TYPES or inner in _FASTAPI_PARAMS:
                continue

            # Skip default args injected via FastAPI markers (check default)
            idx = node.args.args.index(arg)
            n_defaults = len(node.args.defaults)
            n_args = len(node.args.args)
            has_default = idx >= (n_args - n_defaults)
            if has_default:
                def_node = node.args.defaults[idx - (n_args - n_defaults)]
                if isinstance(def_node, ast.Call):
                    func_name = ""
                    if isinstance(def_node.func, ast.Name):
                        func_name = def_node.func.id
                    elif isinstance(def_node.func, ast.Attribute):
                        func_name = def_node.func.attr
                    if func_name in _FASTAPI_PARAMS or func_name == "Depends":
                        continue

            # Likely a Pydantic model
            if re.match(r"^[A-Z][A-Za-z0-9_]*$", inner):
                return inner

        return None

    def _find_depends(self, node: ast.FunctionDef) -> list[str]:
        """Extract Depends(func) dependency names from function parameters."""
        result: list[str] = []
        n_args = len(node.args.args)
        n_defaults = len(node.args.defaults)

        for i, arg in enumerate(node.args.args):
            # Check default value: def ep(x: T = Depends(func))
            idx_from_end = i - (n_args - n_defaults)
            if idx_from_end >= 0:
                dep = self._extract_depends_func(node.args.defaults[idx_from_end])
                if dep:
                    result.append(dep)
                    continue

            # Check Annotated[T, Depends(func)] annotation
            ann = arg.annotation
            if ann and isinstance(ann, ast.Subscript):
                slice_node = ann.slice
                elts = []
                if isinstance(slice_node, ast.Tuple):
                    elts = slice_node.elts
                elif isinstance(slice_node, ast.List):
                    elts = slice_node.elts
                for elt in elts:
                    dep = self._extract_depends_func(elt)
                    if dep:
                        result.append(dep)

        # kw-only args: def ep(*, user=Depends(get_user))
        for arg, default in zip(node.args.kwonlyargs, node.args.kw_defaults):
            if default:
                dep = self._extract_depends_func(default)
                if dep:
                    result.append(dep)

        return result

    @staticmethod
    def _extract_depends_func(node: ast.AST) -> str | None:
        """Return the function name inside Depends(func), or None."""
        if not isinstance(node, ast.Call):
            return None
        func = node.func
        fname = ""
        if isinstance(func, ast.Name):
            fname = func.id
        elif isinstance(func, ast.Attribute):
            fname = func.attr
        if fname != "Depends" or not node.args:
            return None
        dep_arg = node.args[0]
        if isinstance(dep_arg, ast.Name):
            return dep_arg.id
        if isinstance(dep_arg, ast.Attribute):
            return _unparse(dep_arg)
        return None

    # ------------------------------------------------------------------
    # Class definitions: Pydantic and SQLAlchemy models
    # ------------------------------------------------------------------

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        base_names = [_unparse(b) for b in node.bases]

        if self._is_pydantic_model(base_names):
            self._collect_pydantic(node, base_names)
        elif self._is_sqlalchemy_model(base_names):
            self._collect_sqlalchemy(node, base_names)

        self.generic_visit(node)

    def _is_pydantic_model(self, base_names: list[str]) -> bool:
        for b in base_names:
            if b in _PYDANTIC_BASES or b.endswith("BaseModel") or b.endswith("Schema"):
                return True
            # Class inherits from another Pydantic model defined in this same file
            if b in self._local_pydantic_names:
                return True
        return False

    def _is_sqlalchemy_model(self, base_names: list[str]) -> bool:
        for b in base_names:
            if b in _SQLALCHEMY_BASES or b.endswith("Base") or b.endswith("DeclarativeBase"):
                return True
        return False

    def _collect_pydantic(self, node: ast.ClassDef, base_names: list[str]) -> None:
        fields: list[PydanticField] = []
        n_body = len(node.body)
        for i, stmt in enumerate(node.body):
            if not isinstance(stmt, ast.AnnAssign):
                continue
            if not isinstance(stmt.target, ast.Name):
                continue

            fname = stmt.target.id
            if fname.startswith("_"):
                continue

            ftype = _unparse(stmt.annotation)

            # required = no default value
            required = stmt.value is None

            default_val: str | None = None
            if not required:
                dv = stmt.value
                if isinstance(dv, ast.Constant):
                    default_val = repr(dv.value)
                elif isinstance(dv, ast.Call):
                    # Field(...) or Field(default=None) etc.
                    if isinstance(dv.func, ast.Name) and dv.func.id in ("Field", "FieldInfo"):
                        # positional -> required if first arg is Ellipsis
                        if dv.args and isinstance(dv.args[0], ast.Constant) and dv.args[0].value is ...:
                            required = True
                        else:
                            dkw = _kw_value(dv, "default")
                            if dkw is not None:
                                default_val = _unparse(dkw)
                    else:
                        default_val = _unparse(dv)
                else:
                    default_val = _unparse(dv)

            # Optional[T] / T | None → not required
            ann_str = _unparse(stmt.annotation)
            if ann_str.startswith("Optional[") or " | None" in ann_str or "None |" in ann_str:
                required = False

            fields.append(PydanticField(
                name=fname,
                type=ftype,
                required=required,
                default=default_val,
            ))

        dto = PydanticDTO(
            name=node.name,
            file=self.file,
            bases=base_names,
            fields=fields,
        )
        self.pydantic_dtos.append(dto)
        self._local_pydantic_names.add(node.name)

    def _collect_sqlalchemy(self, node: ast.ClassDef, base_names: list[str]) -> None:
        table_name: str = node.name.lower() + "s"  # fallback
        columns: list[SQLAlchemyColumn] = []
        relationships: list[SQLAlchemyRelationship] = []

        for stmt in node.body:
            # __tablename__ = "users"
            if isinstance(stmt, ast.Assign):
                for t in stmt.targets:
                    if isinstance(t, ast.Name) and t.id == "__tablename__":
                        s = _get_str_const(stmt.value)
                        if s:
                            table_name = s

            # id = Column(Integer, primary_key=True)
            if isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Call):
                call = stmt.value
                call_name = ""
                if isinstance(call.func, ast.Name):
                    call_name = call.func.id
                elif isinstance(call.func, ast.Attribute):
                    call_name = call.func.attr

                col_name = ""
                if stmt.targets and isinstance(stmt.targets[0], ast.Name):
                    col_name = stmt.targets[0].id

                if call_name in ("Column", "mapped_column") and col_name:
                    col_type = self._extract_column_type(call)
                    is_pk = self._has_kwarg_true(call, "primary_key")
                    fk = self._extract_fk(call)
                    columns.append(SQLAlchemyColumn(
                        name=col_name,
                        col_type=col_type,
                        primary_key=is_pk,
                        foreign_key=fk,
                    ))

                elif call_name == "relationship" and col_name:
                    target = ""
                    if call.args:
                        target = _get_str_const(call.args[0]) or _unparse(call.args[0])
                    relationships.append(SQLAlchemyRelationship(
                        name=col_name,
                        target=target,
                    ))

            # Annotated assignment: id: Mapped[int] = mapped_column(…)
            if isinstance(stmt, ast.AnnAssign) and isinstance(stmt.value, ast.Call):
                call = stmt.value
                call_name = ""
                if isinstance(call.func, ast.Name):
                    call_name = call.func.id
                elif isinstance(call.func, ast.Attribute):
                    call_name = call.func.attr

                col_name = ""
                if isinstance(stmt.target, ast.Name):
                    col_name = stmt.target.id

                ann_str = _unparse(stmt.annotation)

                if call_name in ("Column", "mapped_column") and col_name:
                    col_type = self._extract_column_type(call)
                    if not col_type:
                        # pull from Mapped[T] annotation
                        m = re.search(r"Mapped\[(.+)\]", ann_str)
                        col_type = m.group(1) if m else ann_str
                    is_pk = self._has_kwarg_true(call, "primary_key")
                    fk = self._extract_fk(call)
                    columns.append(SQLAlchemyColumn(
                        name=col_name,
                        col_type=col_type,
                        primary_key=is_pk,
                        foreign_key=fk,
                    ))

                elif call_name == "relationship" and col_name:
                    target = ""
                    if call.args:
                        target = _get_str_const(call.args[0]) or _unparse(call.args[0])
                    else:
                        m = re.search(r"Mapped\[(?:list\[)?['\"]?([A-Za-z_]\w*)['\"]?", ann_str)
                        if m:
                            target = m.group(1)
                    relationships.append(SQLAlchemyRelationship(
                        name=col_name,
                        target=target,
                    ))

        self.sqlalchemy_models.append(SQLAlchemyModel(
            name=node.name,
            file=self.file,
            table_name=table_name,
            columns=columns,
            relationships=relationships,
        ))

    def _extract_column_type(self, call: ast.Call) -> str:
        """Derive SQLAlchemy column type from first positional arg."""
        for arg in call.args:
            arg_str = _unparse(arg)
            m = _COLUMN_TYPE_RE.search(arg_str)
            if m:
                return m.group(0)
            # Could be a call like Integer() or String(255)
            if isinstance(arg, ast.Call):
                if isinstance(arg.func, ast.Name):
                    return arg.func.id
                if isinstance(arg.func, ast.Attribute):
                    return arg.func.attr
            if isinstance(arg, ast.Name):
                return arg.id
        return "Unknown"

    def _has_kwarg_true(self, call: ast.Call, key: str) -> bool:
        for kw in call.keywords:
            if kw.arg == key:
                if isinstance(kw.value, ast.Constant) and kw.value.value is True:
                    return True
        return False

    def _extract_fk(self, call: ast.Call) -> str | None:
        for arg in call.args:
            if isinstance(arg, ast.Call):
                fname = ""
                if isinstance(arg.func, ast.Name):
                    fname = arg.func.id
                elif isinstance(arg.func, ast.Attribute):
                    fname = arg.func.attr
                if fname == "ForeignKey" and arg.args:
                    return _get_str_const(arg.args[0])
        for kw in call.keywords:
            if kw.arg == "foreign_keys":
                return _unparse(kw.value)
        return None


# ---------------------------------------------------------------------------
# Multi-file scanner
# ---------------------------------------------------------------------------

class FastApiScanner:
    """
    Orchestrates a full FastAPI project scan.

    Usage::

        scanner = FastApiScanner()
        scanner.scan_files(path_list)
        endpoints, dtos, models = scanner.resolve()
    """

    def __init__(self) -> None:
        # (file, var_name) → RouterInfo
        self._routers: dict[tuple[str, str], RouterInfo] = {}
        self._includes: list[IncludeCall] = []
        self._raw_endpoints: list[RawEndpoint] = []
        self._pydantic_dtos: list[PydanticDTO] = []
        self._sqlalchemy_models: list[SQLAlchemyModel] = []
        # file → {local_name → origin_module_string}
        self._file_imports: dict[str, dict[str, str]] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan_files(self, files: Iterable[Path]) -> None:
        """Parse every .py file and collect raw data."""
        for f in files:
            if f.suffix.lower() == ".py":
                self._scan_file(f)

    def resolve(
        self,
    ) -> tuple[
        list[Endpoint],
        list[PydanticDTO],
        list[SQLAlchemyModel],
        set[str],
        set[str],
        list[dict],
    ]:
        """
        Resolve full routes and return
        ``(endpoints, pydantic_dtos, sqlalchemy_models, request_models, response_models, endpoint_deps)``.

        request_models  – set of Pydantic model names used as request bodies.
        response_models – set of Pydantic model names used as response_model=.
        endpoint_deps   – list of {method, path, handler, depends} for endpoints
                          that have at least one Depends() injection.
        """
        resolved_eps = self._resolve_endpoints()
        request_models, response_models = self._compute_model_usage()
        endpoint_deps = self._compute_endpoint_deps(resolved_eps)
        return resolved_eps, self._pydantic_dtos, self._sqlalchemy_models, request_models, response_models, endpoint_deps

    # ------------------------------------------------------------------
    # Internal: scan one file
    # ------------------------------------------------------------------

    def _scan_file(self, path: Path) -> None:
        try:
            source = path.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source)
        except (SyntaxError, OSError):
            return

        file_str = str(path)
        visitor = _FileVisitor(file_str)
        visitor.visit(tree)

        # Store results
        for var, info in visitor.routers.items():
            self._routers[(file_str, var)] = info

        self._includes.extend(visitor.includes)
        self._raw_endpoints.extend(visitor.raw_endpoints)
        self._pydantic_dtos.extend(visitor.pydantic_dtos)
        self._sqlalchemy_models.extend(visitor.sqlalchemy_models)
        self._file_imports[file_str] = visitor.imports

    # ------------------------------------------------------------------
    # Internal: path resolution
    # ------------------------------------------------------------------

    def _resolve_endpoints(self) -> list[Endpoint]:
        """
        Resolve full paths by walking the router include graph.

        Strategy:
        1. Build a map: (file, var) -> list of (child_key, extra_prefix)
        2. For each raw endpoint, BFS upward from its router to find all
           prefixes that apply.
        3. If a router is never included anywhere, its own prefix applies.
        """
        # Build include graph: parent_key → [(child_key, extra_prefix)]
        # child_key = (file, var_name)
        includes_from: dict[
            tuple[str, str], list[tuple[tuple[str, str], str]]
        ] = {}

        for inc in self._includes:
            parent_key = self._resolve_router_key(
                inc.parent_var, inc.parent_file
            )
            child_key = self._resolve_child_key(inc)
            if parent_key and child_key:
                includes_from.setdefault(parent_key, []).append(
                    (child_key, inc.extra_prefix)
                )

        # Build reverse: child → list of (parent, extra_prefix)
        # so we can walk UP from endpoint router to root
        parent_of: dict[
            tuple[str, str], list[tuple[tuple[str, str], str]]
        ] = {}
        for parent_key, children in includes_from.items():
            for child_key, extra_prefix in children:
                parent_of.setdefault(child_key, []).append(
                    (parent_key, extra_prefix)
                )

        endpoints: list[Endpoint] = []

        for raw in self._raw_endpoints:
            router_key = self._resolve_router_key(raw.router_var, raw.router_file)
            if router_key is None:
                # Unrecognised router var — emit with path as-is
                endpoints.append(self._make_endpoint(raw, raw.raw_path))
                continue

            # Collect all prefix chains leading to this router
            prefix_chains = self._collect_prefix_chains(
                router_key, parent_of
            )

            if not prefix_chains:
                # No includes found — use router's own prefix
                own_prefix = self._routers.get(router_key, RouterInfo("", "")).prefix
                full_path = _normalize_path(own_prefix, raw.raw_path)
                endpoints.append(self._make_endpoint(raw, full_path))
            else:
                seen_paths: set[str] = set()
                for chain_prefix in prefix_chains:
                    full_path = _normalize_path(chain_prefix, raw.raw_path)
                    if full_path not in seen_paths:
                        seen_paths.add(full_path)
                        endpoints.append(self._make_endpoint(raw, full_path))

        return endpoints

    def _collect_prefix_chains(
        self,
        router_key: tuple[str, str],
        parent_of: dict[
            tuple[str, str], list[tuple[tuple[str, str], str]]
        ],
        _visited: frozenset | None = None,
    ) -> list[str]:
        """
        Walk UP through the include graph, accumulating prefixes.
        Returns a list of full prefix strings (one per reachable root).
        """
        if _visited is None:
            _visited = frozenset()
        if router_key in _visited:
            # Cycle guard
            return [""]

        _visited = _visited | {router_key}
        router_info = self._routers.get(router_key)
        own_prefix = router_info.prefix if router_info else ""

        parents = parent_of.get(router_key)
        if not parents:
            # This is a root (FastAPI app or standalone router)
            return [own_prefix]

        results: list[str] = []
        for parent_key, extra_prefix in parents:
            parent_chains = self._collect_prefix_chains(
                parent_key, parent_of, _visited
            )
            for pc in parent_chains:
                results.append(_normalize_path(pc, extra_prefix + own_prefix))

        return results or [own_prefix]

    def _resolve_router_key(
        self, var_name: str, file_str: str
    ) -> tuple[str, str] | None:
        """
        Given a variable name and the file it appears in, return the
        (file, var_name) key that uniquely identifies the router.
        Returns None if no router found.
        """
        # Direct: defined in the same file
        key = (file_str, var_name)
        if key in self._routers:
            return key

        # May be imported: `from some.module import router`
        imports = self._file_imports.get(file_str, {})
        origin_module = imports.get(var_name)
        if origin_module:
            # Search all known routers for a match by var_name
            # (since we don't always know the exact file path from module string)
            for (f, v), info in self._routers.items():
                if v == var_name and self._module_matches(f, origin_module):
                    return (f, v)

        # Attribute access: `users.router` → look for var `router` in a file
        # whose path contains `users`
        if "." in var_name:
            parts = var_name.split(".")
            # Last part should be the variable name used in the module
            leaf_var = parts[-1]
            module_hint = parts[-2] if len(parts) >= 2 else ""
            for (f, v), info in self._routers.items():
                if v == leaf_var and module_hint.lower() in f.lower():
                    return (f, v)

        return None

    def _resolve_child_key(self, inc: IncludeCall) -> tuple[str, str] | None:
        """Resolve the child router referenced in an include_router call."""
        return self._resolve_router_key(inc.child_ref, inc.parent_file)

    @staticmethod
    def _module_matches(file_path: str, module_str: str) -> bool:
        """Check if a file path corresponds to a dotted module string."""
        # e.g. "app.routers.users" → ends with "app/routers/users"
        module_as_path = module_str.replace(".", "/")
        normalized = file_path.replace("\\", "/")
        return (
            normalized.endswith(module_as_path + ".py")
            or normalized.endswith(module_as_path + "/__init__.py")
        )

    def _make_endpoint(self, raw: RawEndpoint, full_path: str) -> Endpoint:
        return Endpoint(
            method=raw.method,
            path=full_path,
            file=raw.file,
            line=raw.line,
            handler=raw.handler,
            framework="fastapi",
            controller=raw.request_body_model,  # stored for context (mirrors Java "controller")
            roles=None,
        )

    # ------------------------------------------------------------------
    # Model usage + dependency helpers
    # ------------------------------------------------------------------

    def _compute_model_usage(self) -> tuple[set[str], set[str]]:
        """Return (request_model_names, response_model_names) from raw endpoints."""
        request_models: set[str] = set()
        response_models: set[str] = set()
        for raw in self._raw_endpoints:
            if raw.request_body_model:
                request_models.add(raw.request_body_model)
            if raw.response_model:
                name = self._unwrap_model_name(raw.response_model)
                if name:
                    response_models.add(name)
        return request_models, response_models

    @staticmethod
    def _unwrap_model_name(type_str: str) -> str | None:
        """Strip List[X], Optional[X], list[X], Page[X] etc. and return inner class name."""
        if not type_str:
            return None
        inner = type_str.strip()
        for prefix in (
            "List[", "list[", "Optional[", "Set[", "set[",
            "Sequence[", "Page[", "Iterable[",
        ):
            if inner.startswith(prefix):
                inner = inner[len(prefix):].rstrip("]")
                break
        if "|" in inner:
            parts = [p.strip() for p in inner.split("|") if p.strip() not in ("None", "null")]
            inner = parts[0] if parts else ""
        if "[" in inner:
            inner = inner[: inner.index("[")]
        inner = inner.strip()
        return inner if inner and inner[0].isupper() else None

    def _compute_endpoint_deps(self, resolved_eps: list[Endpoint]) -> list[dict]:
        """Build list of {method, path, handler, depends} for endpoints with Depends()."""
        # Map (file, handler) -> depends list (de-duped)
        handler_deps: dict[tuple[str, str], list[str]] = {}
        for raw in self._raw_endpoints:
            key = (raw.file, raw.handler)
            existing = handler_deps.setdefault(key, [])
            for d in raw.depends:
                if d not in existing:
                    existing.append(d)

        result: list[dict] = []
        seen: set[tuple[str, str]] = set()
        for ep in resolved_eps:
            key = (ep.file, ep.handler)
            if key in seen:
                continue
            seen.add(key)
            deps = handler_deps.get(key, [])
            if deps:
                result.append({
                    "method": ep.method,
                    "path": ep.path,
                    "handler": ep.handler,
                    "depends": deps,
                })
        return result


# ---------------------------------------------------------------------------
# Convenience: scan a project folder → (endpoints, dtos, sqla_models, ...)
# ---------------------------------------------------------------------------

def scan_fastapi_project(
    root: Path,
    *,
    files: list[Path] | None = None,
    skip_dirs: set[str] | None = None,
) -> tuple[
    list[Endpoint],
    list[PydanticDTO],
    list[SQLAlchemyModel],
    set[str],
    set[str],
    list[dict],
]:
    """
    High-level entry point.

    Returns ``(endpoints, pydantic_dtos, sqlalchemy_models,
               request_models, response_models, endpoint_deps)``.

    request_models  – set of model names used as request bodies.
    response_models – set of model names used as response_model=.
    endpoint_deps   – list of {method, path, handler, depends} for endpoints
                      that inject at least one Depends() dependency.

    :param root:      Project root (used to build relative paths).
    :param files:     Pre-collected file list; if None, walks root.
    :param skip_dirs: Directory names to skip (uses sensible defaults).
    """
    _SKIP = skip_dirs or {
        ".git", ".idea", ".vscode", "__pycache__", ".pytest_cache",
        ".ruff_cache", ".tox", ".venv", "venv", "env",
        "node_modules", "dist", "build", "out", "target",
    }

    if files is None:
        files = _collect_python_files(root, _SKIP)

    scanner = FastApiScanner()
    scanner.scan_files(files)
    return scanner.resolve()


def _collect_python_files(root: Path, skip_dirs: set[str]) -> list[Path]:
    out: list[Path] = []
    stack = [root.resolve()]
    while stack:
        cur = stack.pop()
        try:
            for child in cur.iterdir():
                if child.is_dir():
                    if child.name not in skip_dirs:
                        stack.append(child)
                elif child.suffix == ".py":
                    out.append(child)
        except (PermissionError, FileNotFoundError):
            continue
    return out


# ---------------------------------------------------------------------------
# Drop-in replacement for extract_python_endpoints (used in endpoints_cmd.py)
# ---------------------------------------------------------------------------

def extract_fastapi_endpoints(py_source: str, file_path: str) -> list[Endpoint]:
    """
    Single-file FastAPI endpoint extraction (no prefix resolution).
    Intended as an enhanced drop-in for python_web.extract_python_endpoints
    when multi-file resolution is not available.
    """
    try:
        tree = ast.parse(py_source)
    except SyntaxError:
        return []

    visitor = _FileVisitor(file_path)
    visitor.visit(tree)

    endpoints: list[Endpoint] = []
    for raw in visitor.raw_endpoints:
        # Apply whatever prefix the router declares in this file
        router_info = visitor.routers.get(raw.router_var)
        prefix = router_info.prefix if router_info else ""
        full_path = _normalize_path(prefix, raw.raw_path)
        endpoints.append(Endpoint(
            method=raw.method,
            path=full_path,
            file=file_path,
            line=raw.line,
            handler=raw.handler,
            framework="fastapi",
            controller=raw.request_body_model,
            roles=None,
        ))
    return endpoints
