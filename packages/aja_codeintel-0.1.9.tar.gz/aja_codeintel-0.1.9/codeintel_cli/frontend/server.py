"""
codeintel_cli/commands/project/frontend_server.py
Serves a visual HTML dashboard of the project's codeintel overview.
"""
from __future__ import annotations

import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from collections import defaultdict

from codeintel_cli.commands.project.overview_cmd import (
    _scan_models,
    _scan_relationships,
    _scan_types,
    _scan_endpoints,
)


def _collect(project_root: Path) -> dict:
    """Run all four scans and return structured JSON-serialisable dict."""

    raw_models = _scan_models(project_root)
    models = []
    current = None
    for line in raw_models:
        if not line or line == "No domain models found.":
            continue
        if line.startswith("    "):
            if current is not None:
                current["fields"].append(line.strip())
        else:
            parts = [p for p in line.split("  ") if p.strip()]
            name = parts[0].strip() if parts else ""
            if not name:
                continue
            lang = ""
            file_ = ""
            if len(parts) >= 2:
                raw_lang = parts[1].strip()
                lang = raw_lang.lstrip("(").split(")")[0].strip()
            if len(parts) >= 3:
                file_ = parts[-1].strip()
            current = {"name": name, "lang": lang, "file": file_, "fields": []}
            models.append(current)

    edges, counts, per_src = _scan_relationships(project_root)
    relationships = {
        "counts": counts,
        "total": sum(counts.values()),
        "edges": [
            {"src": e.src, "kind": e.kind, "field": e.field, "target": e.target}
            for e in edges
        ],
        "per_src": {
            src: [{"kind": e.kind, "field": e.field, "target": e.target} for e in rels]
            for src, rels in per_src.items()
        },
    }

    raw_types = _scan_types(project_root)
    dtos: list[dict] = []
    current_section = "other"
    current_dto = None
    for line in raw_types:
        if not line or line.startswith("Found") or line == "No DTO/transfer types found.":
            continue
        stripped = line.rstrip()
        if stripped.startswith("        "):
            if current_dto is not None:
                current_dto["fields"].append(stripped.strip())
        elif stripped.startswith("    "):
            parts = stripped.strip().split("  ")
            name = parts[0].strip() if parts else ""
            if not name:
                continue
            current_dto = {"name": name, "fields": [], "section": current_section}
            dtos.append(current_dto)
        elif "REQUEST" in stripped.upper():
            current_section = "request"
            current_dto = None
        elif "RESPONSE" in stripped.upper():
            current_section = "response"
            current_dto = None
        elif "SHARED" in stripped.upper() or "OTHER" in stripped.upper():
            current_section = "other"
            current_dto = None

    raw_eps = _scan_endpoints(project_root)
    endpoints = []
    for line in raw_eps:
        if not line or line.startswith("Found") or line == "":
            continue
        dot = line.find(". ")
        if dot == -1:
            continue
        rest = line[dot + 2:]
        bracket = rest.find("  [")
        if bracket == -1:
            continue
        path = rest[:bracket].strip()
        methods_raw = rest[bracket + 3:].rstrip("]")
        methods = []
        for m in methods_raw.split(","):
            m = m.strip()
            if "{" in m:
                verb, role = m.split("{", 1)
                role = role.rstrip("}")
            else:
                verb, role = m, ""
            methods.append({"verb": verb.strip(), "role": role.strip()})
        endpoints.append({"path": path, "methods": methods})

    return {
        "root": str(project_root),
        "models": models,
        "relationships": relationships,
        "dtos": dtos,
        "endpoints": endpoints,
    }


def _build_html(data: dict) -> str:
    payload = json.dumps(data, indent=2)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>CodeIntel — {data['root']}</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet"/>
<style>
  :root{{
    --bg:#0a0b0f;
    --surface:#111318;
    --surface2:#181c24;
    --border:#1e2330;
    --accent:#00e5ff;
    --accent2:#7c3aed;
    --accent3:#f59e0b;
    --accent4:#10b981;
    --text:#e8eaf0;
    --muted:#5a6175;
    --danger:#ef4444;
    --radius:10px;
    --font-ui:'Syne',sans-serif;
    --font-mono:'JetBrains Mono',monospace;
  }}

  *{{box-sizing:border-box;margin:0;padding:0}}
  html{{scroll-behavior:smooth}}
  body{{
    background:var(--bg);
    color:var(--text);
    font-family:var(--font-ui);
    min-height:100vh;
    overflow-x:hidden;
  }}

  body::before{{
    content:'';
    position:fixed;inset:0;
    background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.035'/%3E%3C/svg%3E");
    pointer-events:none;z-index:999;opacity:.4;
  }}

  .sidebar{{
    position:fixed;left:0;top:0;bottom:0;width:220px;
    background:var(--surface);
    border-right:1px solid var(--border);
    display:flex;flex-direction:column;
    padding:28px 0;
    z-index:100;
  }}
  .sidebar-logo{{
    padding:0 24px 28px;
    border-bottom:1px solid var(--border);
    margin-bottom:20px;
  }}
  .sidebar-logo .brand{{
    font-size:18px;font-weight:800;letter-spacing:-.5px;
    color:var(--accent);
  }}
  .sidebar-logo .root{{
    font-family:var(--font-mono);
    font-size:10px;color:var(--muted);margin-top:4px;
    word-break:break-all;
  }}
  .nav-item{{
    display:flex;align-items:center;gap:10px;
    padding:10px 24px;
    font-size:13px;font-weight:600;letter-spacing:.3px;
    color:var(--muted);
    cursor:pointer;
    border-left:2px solid transparent;
    transition:all .15s;
    text-decoration:none;
  }}
  .nav-item:hover,.nav-item.active{{
    color:var(--text);
    border-left-color:var(--accent);
    background:rgba(0,229,255,.04);
  }}
  .nav-item .icon{{font-size:16px}}
  .nav-badge{{
    margin-left:auto;
    background:var(--surface2);
    color:var(--muted);
    font-family:var(--font-mono);
    font-size:10px;
    padding:2px 6px;border-radius:20px;
  }}

  .main{{
    margin-left:220px;
    padding:40px 48px;
    max-width:1400px;
  }}

  .page-header{{
    margin-bottom:40px;
    display:flex;align-items:flex-start;justify-content:space-between;
  }}
  .page-title{{font-size:32px;font-weight:800;letter-spacing:-1px;line-height:1}}
  .page-subtitle{{font-size:13px;color:var(--muted);margin-top:6px;font-family:var(--font-mono)}}

  .stat-bar{{
    display:grid;grid-template-columns:repeat(4,1fr);gap:16px;
    margin-bottom:40px;
  }}
  .stat-card{{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    padding:20px 24px;
    position:relative;overflow:hidden;
  }}
  .stat-card::after{{
    content:'';position:absolute;bottom:0;left:0;right:0;height:2px;
  }}
  .stat-card.c1::after{{background:var(--accent)}}
  .stat-card.c2::after{{background:var(--accent2)}}
  .stat-card.c3::after{{background:var(--accent3)}}
  .stat-card.c4::after{{background:var(--accent4)}}
  .stat-num{{font-size:36px;font-weight:800;letter-spacing:-1px;line-height:1}}
  .stat-card.c1 .stat-num{{color:var(--accent)}}
  .stat-card.c2 .stat-num{{color:var(--accent2)}}
  .stat-card.c3 .stat-num{{color:var(--accent3)}}
  .stat-card.c4 .stat-num{{color:var(--accent4)}}
  .stat-label{{font-size:12px;color:var(--muted);margin-top:6px;font-weight:600;letter-spacing:.5px;text-transform:uppercase}}

  .section{{margin-bottom:56px}}
  .section-head{{
    display:flex;align-items:center;gap:12px;
    margin-bottom:20px;
    padding-bottom:12px;
    border-bottom:1px solid var(--border);
  }}
  .section-icon{{font-size:20px}}
  .section-title{{font-size:20px;font-weight:800;letter-spacing:-.5px}}
  .section-count{{
    margin-left:auto;
    font-family:var(--font-mono);font-size:12px;
    color:var(--muted);
    background:var(--surface2);
    padding:3px 10px;border-radius:20px;
  }}

  .filter-bar{{
    display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap;
  }}
  .filter-input{{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    padding:8px 14px;
    color:var(--text);
    font-family:var(--font-mono);font-size:12px;
    outline:none;flex:1;min-width:200px;
    transition:border-color .15s;
  }}
  .filter-input:focus{{border-color:var(--accent)}}
  .filter-input::placeholder{{color:var(--muted)}}

  .model-grid{{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;
  }}
  .model-card{{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    padding:18px 20px;
    transition:border-color .2s,transform .2s;
    cursor:default;
  }}
  .model-card:hover{{border-color:var(--accent);transform:translateY(-2px)}}
  .model-card-head{{
    display:flex;align-items:center;gap:8px;margin-bottom:12px;
  }}
  .model-name{{font-size:15px;font-weight:700}}
  .lang-badge{{
    font-family:var(--font-mono);font-size:10px;
    padding:2px 7px;border-radius:4px;
    background:rgba(0,229,255,.1);color:var(--accent);
    font-weight:500;
  }}
  .model-fields{{list-style:none}}
  .model-field{{
    display:flex;gap:8px;align-items:baseline;
    padding:4px 0;
    border-top:1px solid var(--border);
    font-size:12px;
    font-family:var(--font-mono);
  }}
  .field-name{{color:var(--text);font-weight:500}}
  .field-type{{color:var(--muted);flex:1;text-align:right}}
  .model-file{{
    font-size:10px;color:var(--muted);
    font-family:var(--font-mono);
    margin-top:10px;
    word-break:break-all;
    opacity:.7;
  }}

  .endpoint-list{{display:flex;flex-direction:column;gap:8px}}
  .ep-row{{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    padding:12px 18px;
    display:flex;align-items:center;gap:14px;
    transition:border-color .15s;
  }}
  .ep-row:hover{{border-color:var(--border);background:var(--surface2)}}
  .ep-path{{
    font-family:var(--font-mono);font-size:13px;
    color:var(--text);flex:1;
  }}
  .ep-methods{{display:flex;gap:6px;flex-wrap:wrap}}
  .method-badge{{
    font-family:var(--font-mono);font-size:11px;font-weight:500;
    padding:3px 8px;border-radius:5px;
    display:flex;align-items:center;gap:4px;
  }}
  .method-badge.GET{{background:rgba(16,185,129,.15);color:#10b981}}
  .method-badge.POST{{background:rgba(0,229,255,.12);color:var(--accent)}}
  .method-badge.PUT{{background:rgba(245,158,11,.12);color:var(--accent3)}}
  .method-badge.PATCH{{background:rgba(124,58,237,.15);color:#a78bfa}}
  .method-badge.DELETE{{background:rgba(239,68,68,.12);color:var(--danger)}}
  .method-badge.default{{background:var(--surface2);color:var(--muted)}}
  .role-dot{{
    display:inline-block;width:6px;height:6px;border-radius:50%;
  }}
  .role-AUTH{{background:#10b981}}
  .role-PUBLIC{{background:var(--muted)}}
  .role-ADMIN{{background:var(--danger)}}

  .rel-grid{{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;
  }}
  .rel-card{{
    background:var(--surface);border:1px solid var(--border);
    border-radius:var(--radius);padding:18px 20px;
  }}
  .rel-card-title{{font-size:14px;font-weight:700;margin-bottom:10px}}
  .rel-item{{
    display:flex;align-items:center;gap:8px;
    padding:5px 0;border-top:1px solid var(--border);
    font-size:12px;font-family:var(--font-mono);
  }}
  .rel-kind{{
    font-size:10px;padding:2px 6px;border-radius:4px;
    font-weight:600;letter-spacing:.3px;white-space:nowrap;
  }}
  .OneToMany{{background:rgba(16,185,129,.12);color:#10b981}}
  .ManyToOne{{background:rgba(0,229,255,.1);color:var(--accent)}}
  .ManyToMany{{background:rgba(245,158,11,.12);color:var(--accent3)}}
  .OneToOne{{background:rgba(124,58,237,.12);color:#a78bfa}}
  .rel-arrow{{color:var(--muted)}}
  .rel-target{{color:var(--text);font-weight:500}}
  .rel-field{{color:var(--muted)}}

  .dto-grid{{
    display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px;
  }}
  .dto-card{{
    background:var(--surface);border:1px solid var(--border);
    border-radius:var(--radius);padding:18px 20px;
  }}
  .dto-name{{font-size:14px;font-weight:700;margin-bottom:8px;display:flex;align-items:center;gap:8px}}
  .dto-section-badge{{
    font-size:10px;padding:2px 7px;border-radius:4px;
    font-weight:600;letter-spacing:.3px;
  }}
  .dto-section-badge.request{{background:rgba(0,229,255,.1);color:var(--accent)}}
  .dto-section-badge.response{{background:rgba(16,185,129,.12);color:#10b981}}
  .dto-section-badge.other{{background:var(--surface2);color:var(--muted)}}
  .dto-fields{{
    display:flex;flex-wrap:wrap;gap:5px;margin-top:8px;
  }}
  .dto-field-chip{{
    font-family:var(--font-mono);font-size:10px;
    padding:3px 8px;border-radius:4px;
    background:var(--surface2);color:var(--muted);
  }}

  .prompt-box{{
    background:var(--surface);
    border:1px solid var(--border);
    border-radius:var(--radius);
    overflow:hidden;
  }}
  .prompt-tabs{{
    display:flex;border-bottom:1px solid var(--border);
  }}
  .prompt-tab{{
    padding:12px 20px;font-size:12px;font-weight:600;
    letter-spacing:.3px;cursor:pointer;
    color:var(--muted);border-bottom:2px solid transparent;
    transition:all .15s;
    background:none;border-top:none;border-left:none;border-right:none;
    font-family:var(--font-ui);
  }}
  .prompt-tab.active{{color:var(--accent);border-bottom-color:var(--accent)}}
  .prompt-content{{padding:24px;display:none}}
  .prompt-content.active{{display:block}}
  .prompt-textarea{{
    width:100%;
    background:var(--surface2);
    border:1px solid var(--border);
    border-radius:var(--radius);
    color:var(--text);
    font-family:var(--font-mono);font-size:12px;line-height:1.6;
    padding:16px;
    resize:vertical;
    min-height:300px;
    outline:none;
    transition:border-color .15s;
  }}
  .prompt-textarea:focus{{border-color:var(--accent)}}
  .copy-btn{{
    margin-top:12px;
    background:var(--accent);color:#000;
    border:none;border-radius:var(--radius);
    padding:10px 22px;font-size:13px;font-weight:700;
    font-family:var(--font-ui);cursor:pointer;
    transition:opacity .15s;
    letter-spacing:.3px;
  }}
  .copy-btn:hover{{opacity:.85}}
  .copy-btn.copied{{background:var(--accent4);color:#fff}}

  .empty{{
    text-align:center;padding:40px;color:var(--muted);
    font-size:13px;font-family:var(--font-mono);
  }}

  ::-webkit-scrollbar{{width:6px;height:6px}}
  ::-webkit-scrollbar-track{{background:var(--bg)}}
  ::-webkit-scrollbar-thumb{{background:var(--border);border-radius:3px}}

  @keyframes fadeUp{{from{{opacity:0;transform:translateY(12px)}}to{{opacity:1;transform:translateY(0)}}}}
  .section{{animation:fadeUp .35s ease both}}
  .section:nth-child(1){{animation-delay:.05s}}
  .section:nth-child(2){{animation-delay:.1s}}
  .section:nth-child(3){{animation-delay:.15s}}
  .section:nth-child(4){{animation-delay:.2s}}
  .section:nth-child(5){{animation-delay:.25s}}
</style>
</head>
<body>

<nav class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">⬡ CodeIntel</div>
    <div class="root" id="rootPath"></div>
  </div>
  <a class="nav-item active" href="#models" onclick="setActive(this)">
    <span class="icon">📦</span> Models
    <span class="nav-badge" id="badge-models">0</span>
  </a>
  <a class="nav-item" href="#endpoints" onclick="setActive(this)">
    <span class="icon">📡</span> Endpoints
    <span class="nav-badge" id="badge-endpoints">0</span>
  </a>
  <a class="nav-item" href="#relationships" onclick="setActive(this)">
    <span class="icon">🔗</span> Relationships
    <span class="nav-badge" id="badge-rels">0</span>
  </a>
  <a class="nav-item" href="#dtos" onclick="setActive(this)">
    <span class="icon">🧾</span> DTOs / Types
    <span class="nav-badge" id="badge-dtos">0</span>
  </a>
  <a class="nav-item" href="#prompt" onclick="setActive(this)">
    <span class="icon">✨</span> AI Prompt
  </a>
</nav>

<main class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Project Overview</div>
      <div class="page-subtitle" id="headerRoot">Loading…</div>
    </div>
  </div>

  <div class="stat-bar">
    <div class="stat-card c1">
      <div class="stat-num" id="stat-models">0</div>
      <div class="stat-label">Models</div>
    </div>
    <div class="stat-card c4">
      <div class="stat-num" id="stat-endpoints">0</div>
      <div class="stat-label">Endpoints</div>
    </div>
    <div class="stat-card c2">
      <div class="stat-num" id="stat-rels">0</div>
      <div class="stat-label">Relationships</div>
    </div>
    <div class="stat-card c3">
      <div class="stat-num" id="stat-dtos">0</div>
      <div class="stat-label">DTOs / Types</div>
    </div>
  </div>

  <div class="section" id="models">
    <div class="section-head">
      <span class="section-icon">📦</span>
      <span class="section-title">Models</span>
      <span class="section-count" id="models-count">0</span>
    </div>
    <div class="filter-bar">
      <input class="filter-input" id="model-search" placeholder="Search models or fields…" oninput="filterModels()"/>
    </div>
    <div class="model-grid" id="model-grid"></div>
  </div>

  <div class="section" id="endpoints">
    <div class="section-head">
      <span class="section-icon">📡</span>
      <span class="section-title">Endpoints</span>
      <span class="section-count" id="ep-count">0</span>
    </div>
    <div class="filter-bar">
      <input class="filter-input" id="ep-search" placeholder="Search paths…" oninput="filterEndpoints()"/>
      <input class="filter-input" id="ep-verb" placeholder="Filter by verb (GET, POST…)" oninput="filterEndpoints()" style="max-width:200px"/>
      <input class="filter-input" id="ep-role" placeholder="Filter by role (AUTH, ADMIN…)" oninput="filterEndpoints()" style="max-width:200px"/>
    </div>
    <div class="endpoint-list" id="ep-list"></div>
  </div>

  <div class="section" id="relationships">
    <div class="section-head">
      <span class="section-icon">🔗</span>
      <span class="section-title">Relationships</span>
      <span class="section-count" id="rel-count">0</span>
    </div>
    <div class="rel-grid" id="rel-grid"></div>
  </div>

  <div class="section" id="dtos">
    <div class="section-head">
      <span class="section-icon">🧾</span>
      <span class="section-title">DTOs / Types</span>
      <span class="section-count" id="dto-count">0</span>
    </div>
    <div class="filter-bar">
      <input class="filter-input" id="dto-search" placeholder="Search DTOs…" oninput="filterDtos()"/>
    </div>
    <div class="dto-grid" id="dto-grid"></div>
  </div>

  <div class="section" id="prompt">
    <div class="section-head">
      <span class="section-icon">✨</span>
      <span class="section-title">AI Prompt Generator</span>
    </div>
    <div class="prompt-box">
      <div class="prompt-tabs">
        <button class="prompt-tab active" onclick="showTab('full')">Full Frontend Build</button>
        <button class="prompt-tab" onclick="showTab('crud')">CRUD UI</button>
        <button class="prompt-tab" onclick="showTab('schema')">Schema Overview</button>
      </div>
      <div class="prompt-content active" id="tab-full">
        <textarea class="prompt-textarea" id="prompt-full" readonly></textarea>
        <button class="copy-btn" onclick="copyPrompt('prompt-full',this)">Copy Prompt</button>
      </div>
      <div class="prompt-content" id="tab-crud">
        <textarea class="prompt-textarea" id="prompt-crud" readonly></textarea>
        <button class="copy-btn" onclick="copyPrompt('prompt-crud',this)">Copy Prompt</button>
      </div>
      <div class="prompt-content" id="tab-schema">
        <textarea class="prompt-textarea" id="prompt-schema" readonly></textarea>
        <button class="copy-btn" onclick="copyPrompt('prompt-schema',this)">Copy Prompt</button>
      </div>
    </div>
  </div>
</main>

<script>
const DATA = {payload};

function escHtml(s){{return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}}
function setActive(el){{document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));el.classList.add('active')}}

document.getElementById('rootPath').textContent = DATA.root;
document.getElementById('headerRoot').textContent = DATA.root;
document.getElementById('stat-models').textContent = DATA.models.length;
document.getElementById('stat-endpoints').textContent = DATA.endpoints.length;
document.getElementById('stat-rels').textContent = DATA.relationships.total;
document.getElementById('stat-dtos').textContent = DATA.dtos.length;
document.getElementById('badge-models').textContent = DATA.models.length;
document.getElementById('badge-endpoints').textContent = DATA.endpoints.length;
document.getElementById('badge-rels').textContent = DATA.relationships.total;
document.getElementById('badge-dtos').textContent = DATA.dtos.length;
document.getElementById('models-count').textContent = DATA.models.length + ' models';
document.getElementById('ep-count').textContent = DATA.endpoints.length + ' endpoints';
document.getElementById('rel-count').textContent = DATA.relationships.total + ' relationships';
document.getElementById('dto-count').textContent = DATA.dtos.length + ' types';

function renderModels(models){{
  const grid = document.getElementById('model-grid');
  if(!models.length){{grid.innerHTML='<div class="empty">No models found.</div>';return}}
  grid.innerHTML = models.map(m => `
    <div class="model-card">
      <div class="model-card-head">
        <span class="model-name">${{escHtml(m.name)}}</span>
        <span class="lang-badge">${{escHtml(m.lang)}}</span>
      </div>
      <ul class="model-fields">
        ${{m.fields.map(f=>{{
          const [nm,...tp]=f.split(':');
          return `<li class="model-field"><span class="field-name">${{escHtml(nm.trim())}}</span><span class="field-type">${{escHtml(tp.join(':').trim())}}</span></li>`;
        }}).join('')}}
      </ul>
      <div class="model-file">${{escHtml(m.file)}}</div>
    </div>`).join('');
}}
renderModels(DATA.models);

function filterModels(){{
  const q = document.getElementById('model-search').value.toLowerCase();
  const filtered = q ? DATA.models.filter(m=>
    m.name.toLowerCase().includes(q) || m.fields.some(f=>f.toLowerCase().includes(q))
  ) : DATA.models;
  renderModels(filtered);
}}

function methodClass(v){{return ['GET','POST','PUT','PATCH','DELETE'].includes(v)?v:'default'}}

function renderEndpoints(eps){{
  const list = document.getElementById('ep-list');
  if(!eps.length){{list.innerHTML='<div class="empty">No endpoints found.</div>';return}}
  list.innerHTML = eps.map(e=>`
    <div class="ep-row">
      <span class="ep-path">${{escHtml(e.path)}}</span>
      <div class="ep-methods">
        ${{e.methods.map(m=>`
          <span class="method-badge ${{methodClass(m.verb)}}">
            <span class="role-dot role-${{m.role||'PUBLIC'}}"></span>
            ${{escHtml(m.verb)}}
            ${{m.role?`<span style="font-size:9px;opacity:.7">${{escHtml(m.role)}}</span>`:''}}
          </span>`).join('')}}
      </div>
    </div>`).join('');
}}
renderEndpoints(DATA.endpoints);

function filterEndpoints(){{
  const q  = document.getElementById('ep-search').value.toLowerCase();
  const vb = document.getElementById('ep-verb').value.toUpperCase();
  const rl = document.getElementById('ep-role').value.toUpperCase();
  const filtered = DATA.endpoints.filter(e=>{{
    if(q && !e.path.toLowerCase().includes(q)) return false;
    if(vb && !e.methods.some(m=>m.verb.includes(vb))) return false;
    if(rl && !e.methods.some(m=>m.role&&m.role.includes(rl))) return false;
    return true;
  }});
  renderEndpoints(filtered);
}}

(function(){{
  const per = DATA.relationships.per_src;
  const grid = document.getElementById('rel-grid');
  const keys = Object.keys(per).sort();
  if(!keys.length){{grid.innerHTML='<div class="empty">No relationships found.</div>';return}}
  grid.innerHTML = keys.map(src=>`
    <div class="rel-card">
      <div class="rel-card-title">${{escHtml(src)}}</div>
      ${{per[src].map(r=>`
        <div class="rel-item">
          <span class="rel-kind ${{r.kind}}">${{r.kind}}</span>
          <span class="rel-field">${{escHtml(r.field)}}</span>
          <span class="rel-arrow">→</span>
          <span class="rel-target">${{escHtml(r.target)}}</span>
        </div>`).join('')}}
    </div>`).join('');
}})();

function renderDtos(dtos){{
  const grid = document.getElementById('dto-grid');
  if(!dtos.length){{grid.innerHTML='<div class="empty">No DTOs found.</div>';return}}
  grid.innerHTML = dtos.map(d=>`
    <div class="dto-card">
      <div class="dto-name">
        ${{escHtml(d.name)}}
        <span class="dto-section-badge ${{d.section}}">${{d.section}}</span>
      </div>
      <div class="dto-fields">
        ${{d.fields.map(f=>`<span class="dto-field-chip">${{escHtml(f)}}</span>`).join('')}}
      </div>
    </div>`).join('');
}}
renderDtos(DATA.dtos);

function filterDtos(){{
  const q = document.getElementById('dto-search').value.toLowerCase();
  const filtered = q ? DATA.dtos.filter(d=>
    d.name.toLowerCase().includes(q)||d.fields.some(f=>f.toLowerCase().includes(q))
  ) : DATA.dtos;
  renderDtos(filtered);
}}

function showTab(name){{
  document.querySelectorAll('.prompt-tab').forEach((t,i)=>{{
    t.classList.toggle('active', ['full','crud','schema'][i]===name);
  }});
  document.querySelectorAll('.prompt-content').forEach(c=>c.classList.remove('active'));
  document.getElementById('tab-'+name).classList.add('active');
}}

function copyPrompt(id, btn){{
  navigator.clipboard.writeText(document.getElementById(id).value).then(()=>{{
    btn.textContent='✓ Copied!';btn.classList.add('copied');
    setTimeout(()=>{{btn.textContent='Copy Prompt';btn.classList.remove('copied')}},2000);
  }});
}}

(function(){{
  const d = DATA;
  const modelNames  = d.models.map(m=>m.name).join(', ');
  const epSummary   = d.endpoints.slice(0,16).map(e=>e.path+' ['+e.methods.map(m=>m.verb).join(',')+']').join('\\n');
  const dtoSummary  = d.dtos.map(dt=>dt.name+': '+dt.fields.slice(0,6).join(', ')).join('\\n');
  const relSummary  = d.relationships.edges.slice(0,20).map(e=>e.src+' --['+e.kind+']('+e.field+')--> '+e.target).join('\\n');

  document.getElementById('prompt-full').value =
`You are a senior full-stack developer. Build a clean, modern frontend for the following backend.

## Project Root
${{d.root}}

## Domain Models (${{d.models.length}} total)
${{d.models.map(m=>m.name+' ('+m.lang+'):\\n'+m.fields.map(f=>'  '+f).join('\\n')).join('\\n\\n')}}

## API Endpoints (${{d.endpoints.length}} total)
${{epSummary}}

## Entity Relationships
${{relSummary}}

## DTOs / Types
${{dtoSummary}}

## Instructions
- Use React + TypeScript + Tailwind CSS (or a clean CSS framework that suits the project)
- Choose a dark, developer-focused theme — professional and modern, not flashy
- Build the following pages/views:
  1. Dashboard — summary cards for all key models with counts
  2. A list view for each main entity (${{modelNames}}) with search + pagination
  3. Detail/form views for create and edit operations using the API endpoints
  4. Navigation sidebar with all entities listed
- Wire up all API calls using fetch or axios, respecting the AUTH/PUBLIC/ADMIN roles shown in the endpoints
- Handle loading and error states gracefully
- Use the DTO types for form validation and API payloads
- Show relationship data visually (e.g. BankAccount → Operations as nested list)
- Keep code clean, modular, and well-commented
- Output as a complete, runnable project with folder structure explained`;

  document.getElementById('prompt-crud').value =
`Generate CRUD UI components for each of these entities using React + Tailwind.

Entities: ${{modelNames}}

For each entity, produce:
1. A <EntityList /> component — table with all fields, search bar, delete button
2. A <EntityForm /> component — controlled form for create/update using these fields

Use these API endpoints:
${{epSummary}}

DTOs to use for forms and responses:
${{dtoSummary}}

Rules:
- Role-aware: hide ADMIN actions from regular AUTH users
- All forms must validate required fields before submit
- Show a toast/snackbar on success or error
- Use consistent design tokens (colors, spacing, font)
- Export each component individually so they can be imported into a routing shell`;

  document.getElementById('prompt-schema').value =
`Here is the complete data model for a ${{d.models.length>5?'large':'medium'}}-scale backend application.

## Entities
${{d.models.map(m=>m.name+': '+m.fields.join(', ')).join('\\n')}}

## Relationships
${{relSummary||'(none detected)'}}

## DTOs
${{dtoSummary||'(none detected)'}}

Using this schema:
1. Draw an ER diagram description (text-based, using arrows)
2. Identify the core aggregate roots and explain why
3. Suggest a sensible frontend navigation structure (pages, tabs, nested routes)
4. List which DTOs map to which forms or API calls
5. Flag any potential issues (e.g. circular relationships, missing soft-delete fields)`;
}})();
</script>
</body>
</html>"""


def _make_handler(html: str):
    class _H(BaseHTTPRequestHandler):
        def do_GET(self):
            body = html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, fmt, *args):
            pass

    return _H


def serve(project_root: Path, port: int = 7821) -> None:
    """Collect data, build HTML, and serve until Ctrl-C."""
    data = _collect(project_root)
    html = _build_html(data)
    handler = _make_handler(html)
    httpd = HTTPServer(("127.0.0.1", port), handler)
    url = f"http://127.0.0.1:{port}"
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    print(f"  ✦ CodeIntel UI  →  {url}")
    print("  Press Ctrl-C to stop.\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Stopped.")