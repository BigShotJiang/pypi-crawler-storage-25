"""NewsML converter (AFP news)"""

__version__ = "1.8.35"
