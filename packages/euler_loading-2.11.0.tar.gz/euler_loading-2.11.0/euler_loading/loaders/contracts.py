"""Loader contracts (Protocols) for common dataset types.

Each protocol defines the set of loader functions a dataset module must
provide.  Protocols are :func:`~typing.runtime_checkable`, so you can
verify conformance at runtime::

    from euler_loading.loaders.gpu import vkitti2
    from euler_loading.loaders.contracts import DenseDepthLoader

    assert isinstance(vkitti2, DenseDepthLoader)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, BinaryIO, Protocol, Union, runtime_checkable

if TYPE_CHECKING:
    import torch


@runtime_checkable
class DenseDepthLoader(Protocol):
    """Contract for dense-depth dataset loaders.

    A conforming module must expose the following callables, each accepting
    a file path, an optional modality-level ``meta`` dict, and optional
    per-file ``attributes`` keyword, and returning a ``torch.Tensor``:

    - **rgb** – ``(3, H, W)`` float32 in ``[0, 1]``
    - **depth** – ``(1, H, W)`` float32 in metres
    - **sky_mask** – ``(1, H, W)`` bool
    - **read_intrinsics** – ``(3, 3)`` float32 camera matrix *K*
    """

    def rgb(self, path: Union[str, BinaryIO], meta: dict[str, Any] | None = None, *, attributes: dict[str, Any] | None = None) -> torch.Tensor: ...
    def depth(self, path: Union[str, BinaryIO], meta: dict[str, Any] | None = None, *, attributes: dict[str, Any] | None = None) -> torch.Tensor: ...
    def sky_mask(self, path: Union[str, BinaryIO], meta: dict[str, Any] | None = None, *, attributes: dict[str, Any] | None = None) -> torch.Tensor: ...
    def read_intrinsics(self, path: Union[str, BinaryIO], meta: dict[str, Any] | None = None, *, attributes: dict[str, Any] | None = None) -> torch.Tensor: ...


@runtime_checkable
class DenseDepthWriter(Protocol):
    """Contract for dense-depth modality writers.

    A conforming module exposes write functions parallel to
    :class:`DenseDepthLoader`, with a shared ``(path, value, meta=None)``
    signature:

    - **write_rgb**
    - **write_depth**
    - **write_sky_mask**
    - **write_intrinsics**
    """

    def write_rgb(self, path: Union[str, BinaryIO], value: Any, meta: dict[str, Any] | None = None) -> None: ...
    def write_depth(self, path: Union[str, BinaryIO], value: Any, meta: dict[str, Any] | None = None) -> None: ...
    def write_sky_mask(self, path: Union[str, BinaryIO], value: Any, meta: dict[str, Any] | None = None) -> None: ...
    def write_intrinsics(self, path: Union[str, BinaryIO], value: Any, meta: dict[str, Any] | None = None) -> None: ...


@runtime_checkable
class DenseDepthCodec(DenseDepthLoader, DenseDepthWriter, Protocol):
    """Combined reader/writer contract for dense-depth datasets."""
