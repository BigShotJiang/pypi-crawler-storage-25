#!/usr/bin/env python

"""
Interfaces to OmniPath-derived prior knowledge resources.

The `omnipath` sub-package provides utilities for retrieving and
constructing biological interaction priors and regulatory domains
from OmniPath-related resources such as CollecTRI and DoRothEA.
"""

from typing import List

from ._collectri import load_collectri_grn
from ._dorothea import load_dorothea_grn

__all__ = [
    "load_collectri_grn",
    "load_dorothea_grn",
]


def __dir__() -> List[str]:
    return sorted(set(globals()) | set(__all__))
