# qondor-client

This is a defensive PyPI name reservation maintained by Qondor AS. It is **not** the package you want.

Install [`qondor-api-sdk`](https://pypi.org/project/qondor-api-sdk/) instead.
