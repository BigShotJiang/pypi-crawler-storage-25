"""Meta-package redirect for qondor-client. Install `qondor-api-sdk` for the real SDK."""

raise ImportError(
    "The `qondor-client` name is a defensive reservation. "
    "Install `qondor-api-sdk` (https://pypi.org/project/qondor-api-sdk/) instead."
)
