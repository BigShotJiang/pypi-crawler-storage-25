class RequestTimeoutError(TimeoutError):
    """Request-reply operation timed out."""
