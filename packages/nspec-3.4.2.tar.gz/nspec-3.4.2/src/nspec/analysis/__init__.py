"""Analysis subsystem for nspec.

Submodules:
    coverage_audit — Spec coverage auditing and gap analysis
    dep_graph      — Dependency graph analysis and visualization

Import directly from submodules:
    from nspec.analysis.coverage_audit import run_audit
    from nspec.analysis.dep_graph import analyze
"""
