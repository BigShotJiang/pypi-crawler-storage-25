"""Reporting and presentation subsystem for nspec.

Submodules:
    reports         — Epic/spec summary reports, blockers, swarm status
    dev_metrics     — Engineering velocity and quality metrics dashboard
    docgen          — Automated documentation generation
    table_formatter — CLI table formatting for spec listings

Import directly from submodules:
    from nspec.reporting.reports import epic_summary_report
    from nspec.reporting.dev_metrics import print_dev_metrics
    from nspec.reporting.docgen import generate_docs
    from nspec.reporting.table_formatter import NspecTableFormatter
"""
