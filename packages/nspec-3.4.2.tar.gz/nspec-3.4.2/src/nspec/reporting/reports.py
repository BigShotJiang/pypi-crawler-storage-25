"""
Nspec report data providers.

Each report function returns a JSON-serializable dict that can be:
1. Rendered by the TUI using Rich markup
2. Exported as JSON for external tools
3. Consumed by MCP tools

Report Structure:
{
    "title": "Report Title",
    "generated_at": "2026-01-20T12:00:00",
    "sections": [
        {
            "name": "Section Name",
            "type": "table|list|metric|chart",
            "data": { ... section-specific data ... }
        }
    ]
}
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from nspec.domain.datasets import DatasetLoader, NspecDatasets
from nspec.domain.statuses import is_active_status, is_done_status

logger = logging.getLogger("nspec.reporting")


@dataclass
class ReportContext:
    """Context for generating reports."""

    datasets: NspecDatasets
    docs_root: Path
    project_root: Path | None = None

    @classmethod
    def load(cls, docs_root: Path | None = None, project_root: Path | None = None) -> ReportContext:
        """Load datasets and create context."""
        root = docs_root or Path("docs")
        loader = DatasetLoader(root)
        datasets = loader.load()
        return cls(datasets=datasets, docs_root=root, project_root=project_root)


def epic_summary_report(ctx: ReportContext) -> dict[str, Any]:
    """Generate epic summary report with spec counts and progress."""
    # Read active epic from state.json (safe fallback to None)
    active_epic: str | None = None
    try:
        from nspec.runtime.session import SessionDAO

        if ctx.project_root:
            project_root = ctx.project_root
        elif (ctx.docs_root / ".novabuilt.dev").exists():
            # docs_root IS the project root (contains frs/ and .novabuilt.dev/)
            project_root = ctx.docs_root
        else:
            # docs_root is a nested "docs/" directory
            project_root = ctx.docs_root.parent
        dao = SessionDAO(project_root)
        active_epic = dao.get_active_epic()
    except Exception:
        logger.debug("Failed to read active epic from session", exc_info=True)

    # S256: epic membership is resolved through the EpicMembershipDAO. This
    # report no longer scans epic `deps` to determine children — it reads the
    # canonical membership map.
    from nspec.dao.markdown.epic_membership_dao import MarkdownEpicMembershipDAO

    memberships_map = MarkdownEpicMembershipDAO.compute_memberships_from_datasets(ctx.datasets)
    children_by_epic: dict[str, list[str]] = {}
    for sid, eid in memberships_map.items():
        children_by_epic.setdefault(eid, []).append(sid)

    epics = []
    epic_ids: set[str] = set()

    for spec_id, fr in ctx.datasets.active_frs.items():
        if fr.is_epic:
            epic_ids.add(spec_id)
            children = [
                sid
                for sid in children_by_epic.get(spec_id, [])
                if sid in ctx.datasets.active_frs and not ctx.datasets.active_frs[sid].is_epic
            ]

            # Calculate progress from IMPL status
            completed = 0
            active = 0
            for sid in children:
                impl = ctx.datasets.active_impls.get(sid)
                if impl:
                    if is_done_status(impl.status):
                        completed += 1
                    elif is_active_status(impl.status):
                        active += 1

            total = len(children)
            pct = (completed / total * 100) if total > 0 else 0

            epics.append(
                {
                    "id": spec_id,
                    "title": fr.title,
                    "priority": fr.priority,
                    "total": total,
                    "completed": completed,
                    "active": active,
                    "pending": total - completed - active,
                    "progress_pct": round(pct, 1),
                    "is_active_epic": spec_id == active_epic,
                }
            )

    # Normalize: if stored active_epic doesn't match any known epic, set to None
    if active_epic and active_epic not in epic_ids:
        active_epic = None

    # Sort: epics with open specs first, then by priority rank within each group
    from nspec.domain.statuses import PRIORITY_RANK as priority_rank

    epics.sort(
        key=lambda x: (
            0 if (x["pending"] + x["active"]) > 0 else 1,
            priority_rank.get(x["priority"], 99),
        )
    )

    return {
        "title": "Epic Summary",
        "generated_at": datetime.now().isoformat(),
        "active_epic": active_epic,
        "sections": [
            {
                "name": "Epics by Priority",
                "type": "table",
                "columns": ["ID", "Priority", "Title", "Progress", "Done", "Active", "Pending"],
                "data": [
                    {
                        "id": e["id"],
                        "priority": e["priority"],
                        "title": e["title"][:40] + "..." if len(e["title"]) > 40 else e["title"],
                        "progress": f"{e['progress_pct']}%",
                        "done": e["completed"],
                        "active": e["active"],
                        "pending": e["pending"],
                        "is_active_epic": e["is_active_epic"],
                    }
                    for e in epics
                ],
            },
            {
                "name": "Summary Metrics",
                "type": "metrics",
                "data": {
                    "total_epics": len(epics),
                    "total_specs": sum(e["total"] for e in epics),
                    "completed_specs": sum(e["completed"] for e in epics),
                    "active_specs": sum(e["active"] for e in epics),
                },
            },
        ],
    }


def velocity_report(ctx: ReportContext) -> dict[str, Any]:
    """Generate velocity report based on completed specs."""
    # Group completed specs by priority
    by_priority: dict[str, list[dict]] = defaultdict(list)

    for spec_id, impl in ctx.datasets.active_impls.items():
        if is_done_status(impl.status):
            fr = ctx.datasets.active_frs.get(spec_id)
            if fr and not fr.is_epic:
                loe = fr.loe if hasattr(fr, "loe") else impl.loe or "N/A"
                by_priority[fr.priority].append(
                    {
                        "id": spec_id,
                        "title": fr.title[:50],
                        "loe": loe,
                    }
                )

    # Also include completed specs from completed_impls
    for spec_id, impl in ctx.datasets.completed_impls.items():
        fr = ctx.datasets.completed_frs.get(spec_id)
        if fr and not fr.is_epic:
            loe = fr.loe if hasattr(fr, "loe") else impl.loe or "N/A"
            by_priority[fr.priority].append(
                {
                    "id": spec_id,
                    "title": fr.title[:50],
                    "loe": loe,
                }
            )

    # Calculate LOE totals
    def parse_loe(loe: str) -> float:
        """Parse LOE to days."""
        if not loe or loe == "N/A":
            return 0
        try:
            num = float(loe[:-1])
            unit = loe[-1].lower()
            if unit == "h":
                return num / 8
            elif unit == "w":
                return num * 5
            return num  # days
        except (ValueError, IndexError):
            return 0

    priority_totals = {}
    for priority, specs in by_priority.items():
        total_days = sum(parse_loe(s["loe"]) for s in specs)
        priority_totals[priority] = {
            "count": len(specs),
            "total_days": round(total_days, 1),
        }

    return {
        "title": "Velocity Report",
        "generated_at": datetime.now().isoformat(),
        "sections": [
            {
                "name": "Completed by Priority",
                "type": "table",
                "columns": ["Priority", "Specs", "Total LOE (days)"],
                "data": [
                    {"priority": p, "specs": v["count"], "loe": v["total_days"]}
                    for p, v in sorted(priority_totals.items())
                ],
            },
            {
                "name": "Recent Completions",
                "type": "list",
                "data": [
                    {"id": s["id"], "title": s["title"], "loe": s["loe"]}
                    for specs in by_priority.values()
                    for s in specs[:5]
                ][:15],
            },
        ],
    }


def blockers_report(ctx: ReportContext) -> dict[str, Any]:
    """Generate blockers report showing dependency chains."""
    blockers = []

    for spec_id, fr in ctx.datasets.active_frs.items():
        if fr.is_epic:
            continue

        impl = ctx.datasets.active_impls.get(spec_id)
        if impl and is_done_status(impl.status):  # Already done
            continue

        # Check dependencies
        blocking_deps = []
        for dep_id in fr.deps:
            dep_fr = ctx.datasets.active_frs.get(dep_id)
            if dep_fr and dep_fr.is_epic:
                continue  # Skip epic deps
            dep_impl = ctx.datasets.active_impls.get(dep_id)
            if dep_impl and not is_done_status(dep_impl.status):  # Not done
                blocking_deps.append(
                    {
                        "id": dep_id,
                        "title": dep_fr.title[:30] if dep_fr else "Unknown",
                        "status": dep_impl.status if dep_impl else "Unknown",
                    }
                )

        if blocking_deps:
            blockers.append(
                {
                    "id": spec_id,
                    "title": fr.title[:40],
                    "priority": fr.priority,
                    "blocked_by": blocking_deps,
                }
            )

    # Sort by priority
    from nspec.domain.statuses import PRIORITY_RANK as priority_rank

    blockers.sort(key=lambda x: priority_rank.get(x["priority"], 9))

    return {
        "title": "Blockers Report",
        "generated_at": datetime.now().isoformat(),
        "sections": [
            {
                "name": "Blocked Specs",
                "type": "blockers",
                "data": blockers[:20],  # Top 20
            },
            {
                "name": "Summary",
                "type": "metrics",
                "data": {
                    "total_blocked": len(blockers),
                    "p0_blocked": sum(1 for b in blockers if b["priority"] == "P0"),
                    "p1_blocked": sum(1 for b in blockers if b["priority"] == "P1"),
                },
            },
        ],
    }


def build_swarm_report(project_root: Path) -> dict[str, Any]:
    """Build swarm queue report from queue state (no dataset loading required).

    This is the standalone entry point for swarm report generation.
    It reads queue state via a lock-free snapshot and builds the report dict.
    Can be called directly from auto-refresh paths that must avoid parsing
    all FR/IMPL files.
    """
    from nspec.orchestration.queue import QueueDAO

    dao = QueueDAO(project_root)
    status = dao.status_snapshot()

    if "error" in status:
        return {
            "title": "Swarm Queue",
            "generated_at": datetime.now().isoformat(),
            "sections": [
                {
                    "name": "Queue Status",
                    "type": "metrics",
                    "data": {"status": "No queue initialized"},
                },
            ],
        }

    agents = status.get("agents", [])
    queued = status.get("queued", [])
    completed = status.get("completed", [])

    sections: list[dict[str, Any]] = []

    # Agent assignments table
    if agents:
        sections.append(
            {
                "name": "Active Agents",
                "type": "table",
                "columns": ["Agent", "Spec", "Priority", "Title"],
                "data": [
                    {
                        "agent": a["agent_id"],
                        "spec": a["spec_id"],
                        "priority": a["priority"],
                        "title": a["title"][:40],
                    }
                    for a in agents
                ],
            }
        )

    # Queued specs (add "id" key for list renderer compatibility)
    sections.append(
        {
            "name": "Queued Specs",
            "type": "list",
            "data": [
                {"id": q["spec_id"], "title": q["title"][:50], "priority": q["priority"]}
                for q in queued
            ],
        }
    )

    # Completed specs
    sections.append(
        {
            "name": "Completed",
            "type": "list",
            "data": [{"id": sid, "title": sid} for sid in completed],
        }
    )

    # Summary metrics
    sections.append(
        {
            "name": "Queue Metrics",
            "type": "metrics",
            "data": {
                "active_agents": status.get("active_agents", 0),
                "max_agents": status.get("max_agents", 0),
                "specs_queued": status.get("specs_remaining", 0),
                "specs_completed": status.get("specs_completed", 0),
                "total_entries": status.get("total_entries", 0),
                "epic": status.get("epic_id") or "All",
            },
        }
    )

    return {
        "title": "Swarm Queue",
        "generated_at": datetime.now().isoformat(),
        "sections": sections,
    }


def swarm_report(ctx: ReportContext) -> dict[str, Any]:
    """Generate swarm queue status report showing agent assignments and progress."""
    return build_swarm_report(ctx.project_root or ctx.docs_root.parent)


def status_matrix_report(ctx: ReportContext) -> dict[str, Any]:
    """Generate status matrix showing FR/IMPL status combinations."""
    matrix: dict[tuple[str, str], list[str]] = defaultdict(list)

    for spec_id, fr in ctx.datasets.active_frs.items():
        if fr.is_epic:
            continue
        impl = ctx.datasets.active_impls.get(spec_id)
        fr_status = fr.status or "Unknown"
        impl_status = impl.status if impl else "Unknown"
        matrix[(fr_status, impl_status)].append(spec_id)

    # Convert to table format
    rows = []
    for (fr_status, impl_status), specs in sorted(matrix.items()):
        rows.append(
            {
                "fr_status": fr_status,
                "impl_status": impl_status,
                "count": len(specs),
                "specs": specs[:5],  # Sample
            }
        )

    return {
        "title": "Status Matrix",
        "generated_at": datetime.now().isoformat(),
        "sections": [
            {
                "name": "FR × IMPL Status Combinations",
                "type": "matrix",
                "data": rows,
            },
        ],
    }


# Registry of available reports
REPORTS = {
    "epic_summary": {
        "name": "Epic Summary",
        "description": "Overview of epics with progress tracking",
        "fn": epic_summary_report,
    },
    "velocity": {
        "name": "Velocity",
        "description": "Completed specs and LOE analysis",
        "fn": velocity_report,
    },
    "blockers": {
        "name": "Blockers",
        "description": "Specs blocked by dependencies",
        "fn": blockers_report,
    },
    "status_matrix": {
        "name": "Status Matrix",
        "description": "FR/IMPL status combinations",
        "fn": status_matrix_report,
    },
    "swarm": {
        "name": "Swarm Queue",
        "description": "Agent assignments and queue progress",
        "fn": swarm_report,
    },
}


def generate_report(
    report_id: str, docs_root: Path | None = None, project_root: Path | None = None
) -> dict[str, Any]:
    """Generate a report by ID."""
    if report_id not in REPORTS:
        raise ValueError(f"Unknown report: {report_id}. Available: {list(REPORTS.keys())}")

    ctx = ReportContext.load(docs_root, project_root=project_root)
    return REPORTS[report_id]["fn"](ctx)


def list_reports() -> list[dict[str, str]]:
    """List available reports."""
    return [
        {"id": rid, "name": r["name"], "description": r["description"]}
        for rid, r in REPORTS.items()
    ]
