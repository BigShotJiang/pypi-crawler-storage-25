"""nspec — specification-driven backlog management.

Architecture:
    domain/     - Domain models: IDs, tasks, statuses, datasets, ordering, LOE
    runtime/    - Infrastructure: atomic writes, locks, timestamps, session persistence
    validators  - Format validation (Layer 1)
    checkers    - Cross-document validation (Layers 3-6)
    cli         - Command-line interface
    mcp_server  - MCP server (FastMCP, stdio/SSE)
    tui/        - Textual TUI application
"""

from nspec.domain.datasets import DatasetLoader, NspecDatasets
from nspec.domain.tasks import Task, TaskParser
from nspec.git_reader import (
    FileNotFoundInRefError,
    GitReaderError,
    GitRefNotFoundError,
    GitRepositoryError,
    get_spec_ids_from_ref,
    list_spec_files,
    read_spec_content,
)
from nspec.validation.validators import FRValidator, IMPLValidator

__all__ = [
    "DatasetLoader",
    "FRValidator",
    "FileNotFoundInRefError",
    "GitReaderError",
    "GitRefNotFoundError",
    "GitRepositoryError",
    "IMPLValidator",
    "NspecDatasets",
    "Task",
    "TaskParser",
    "get_spec_ids_from_ref",
    "list_spec_files",
    "read_spec_content",
]
