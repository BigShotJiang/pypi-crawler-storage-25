"""Orchestration subsystem for nspec.

Submodules:
    executor    — Agent executor resolution and dispatch (tmux, subprocess)
    operations  — Spec move/transfer operations
    queue       — Multi-agent work queue with atomic claim/release
    swarm       — Parallel Claude Code agent swarm management
    error_agent — Automatic error detection and bug spec creation
    init        — Project scaffolding, stack detection, MCP config generation

Import directly from submodules:
    from nspec.orchestration.executor import resolve_executor
    from nspec.orchestration.queue import QueueDAO
    from nspec.orchestration.swarm import SwarmManager
    from nspec.orchestration.init import scaffold_project
"""
