"""Parallel Claude Code agent swarm via nspec + tmux.

Manages N parallel Claude Code CLI instances, each in an isolated git
worktree, claiming specs from the nspec queue and working them in
parallel.

Swarm state is persisted to ``.novabuilt.dev/nspec/swarm.yaml``.
Claimed specs return to unclaimed automatically after TTL expiry.

Spec: S253 (FR/IMPL — codifies the as-built lifecycle:
``swarm_launch`` / ``swarm_status`` / ``swarm_teardown``).
"""

from __future__ import annotations

import contextlib
import logging
import os
import subprocess
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from nspec import tmux
from nspec.config import NspecConfig
from nspec.orchestration.queue import QueueDAO

logger = logging.getLogger("nspec.orchestration.swarm")

SWARM_STATE_FILE = ".novabuilt.dev/nspec/swarm.yaml"

# Agent prompt template — injected into each Claude Code instance.
# Uses /ngo to execute the full spec lifecycle (resolve, execute, verify,
# review, complete). The agent also heartbeats and releases the queue claim.
_AGENT_PROMPT_TEMPLATE = """\
You are nspec swarm agent {agent_id}. \
Run /ngo {spec_id} to execute the spec. \
Call queue_heartbeat(agent_id="{agent_id}") every 2 minutes while working. \
After /ngo completes: call queue_release(\
agent_id="{agent_id}", spec_id="{spec_id}", completed=true) then exit. \
If /ngo fails: call queue_release(\
agent_id="{agent_id}", spec_id="{spec_id}", \
reason="<failure reason>") then exit.\
"""


@dataclass
class AgentState:
    """Runtime state for a single swarm agent."""

    spec_id: str
    worktree: str
    tmux_session: str
    branch: str
    claimed_at: str
    lease_expires: str
    status: str  # "running", "completed", "failed"


@dataclass
class CompletedEntry:
    """Record of a completed spec."""

    spec_id: str
    agent_id: str
    completed_at: str


@dataclass
class SwarmState:
    """Full swarm state, serialized to swarm.yaml."""

    epic_id: str
    started_at: str
    max_agents: int
    lease_ttl_seconds: int
    model: str
    agents: dict[str, AgentState] = field(default_factory=dict)
    completed: list[CompletedEntry] = field(default_factory=list)
    failed: list[dict[str, str]] = field(default_factory=list)


class SwarmManager:
    """Manages N parallel Claude Code agents working specs from a queue.

    Lifecycle:
        1. ``launch()`` — init queue, create worktrees, spawn agents
        2. ``status()`` — read swarm.yaml, show agent health + progress
        3. ``teardown()`` — kill agents, clean worktrees, clear state
    """

    def __init__(self, project_root: Path, config: NspecConfig | None = None) -> None:
        self._project_root = project_root
        self._config = config or NspecConfig.load(project_root)
        self._queue = QueueDAO(project_root)

    @property
    def state_path(self) -> Path:
        return self._project_root / SWARM_STATE_FILE

    @property
    def worktree_base(self) -> Path:
        return self._project_root / self._config.claude_code.worktree_base

    def _load_state(self) -> SwarmState | None:
        """Load swarm state from disk."""
        if not self.state_path.exists():
            return None
        try:
            data = yaml.safe_load(self.state_path.read_text())
            if not data:
                return None
            agents = {}
            for aid, adata in data.get("agents", {}).items():
                agents[aid] = AgentState(**adata)
            completed = [CompletedEntry(**c) for c in data.get("completed", [])]
            return SwarmState(
                epic_id=data["epic_id"],
                started_at=data["started_at"],
                max_agents=data["max_agents"],
                lease_ttl_seconds=data["lease_ttl_seconds"],
                model=data.get("model", "sonnet"),
                agents=agents,
                completed=completed,
                failed=data.get("failed", []),
            )
        except (yaml.YAMLError, TypeError, KeyError):
            logger.warning("Failed to parse swarm state", exc_info=True)
            return None

    def _save_state(self, state: SwarmState) -> None:
        """Save swarm state to disk."""
        data: dict[str, Any] = {
            "epic_id": state.epic_id,
            "started_at": state.started_at,
            "max_agents": state.max_agents,
            "lease_ttl_seconds": state.lease_ttl_seconds,
            "model": state.model,
            "agents": {
                aid: {
                    "spec_id": a.spec_id,
                    "worktree": a.worktree,
                    "tmux_session": a.tmux_session,
                    "branch": a.branch,
                    "claimed_at": a.claimed_at,
                    "lease_expires": a.lease_expires,
                    "status": a.status,
                }
                for aid, a in state.agents.items()
            },
            "completed": [
                {
                    "spec_id": c.spec_id,
                    "agent_id": c.agent_id,
                    "completed_at": c.completed_at,
                }
                for c in state.completed
            ],
            "failed": state.failed,
        }
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))

    def _create_worktree(self, agent_id: str) -> Path:
        """Create a git worktree for an agent."""
        wt_path = self.worktree_base / agent_id
        branch = f"nspec/{agent_id}"

        if wt_path.exists():
            # Clean up stale worktree
            self._remove_worktree(agent_id)

        self.worktree_base.mkdir(parents=True, exist_ok=True)

        try:
            subprocess.run(
                ["git", "worktree", "add", "-b", branch, str(wt_path), "HEAD"],
                cwd=str(self._project_root),
                capture_output=True,
                text=True,
                timeout=30,
                check=True,
            )
            logger.info("Created worktree %s on branch %s", wt_path, branch)
        except subprocess.CalledProcessError as exc:
            # Branch may already exist — try without -b
            with contextlib.suppress(subprocess.CalledProcessError, subprocess.TimeoutExpired):
                subprocess.run(
                    ["git", "branch", "-D", branch],
                    cwd=str(self._project_root),
                    capture_output=True,
                    timeout=10,
                )
            try:
                subprocess.run(
                    ["git", "worktree", "add", "-b", branch, str(wt_path), "HEAD"],
                    cwd=str(self._project_root),
                    capture_output=True,
                    text=True,
                    timeout=30,
                    check=True,
                )
            except subprocess.CalledProcessError:
                raise RuntimeError(
                    f"Failed to create worktree for {agent_id}: {exc.stderr}"
                ) from exc

        return wt_path

    def _remove_worktree(self, agent_id: str) -> None:
        """Remove a git worktree and its branch."""
        wt_path = self.worktree_base / agent_id
        branch = f"nspec/{agent_id}"

        try:
            subprocess.run(
                ["git", "worktree", "remove", "--force", str(wt_path)],
                cwd=str(self._project_root),
                capture_output=True,
                timeout=30,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            logger.debug("Worktree remove failed for %s", agent_id, exc_info=True)

        with contextlib.suppress(subprocess.CalledProcessError, subprocess.TimeoutExpired):
            subprocess.run(
                ["git", "branch", "-D", branch],
                cwd=str(self._project_root),
                capture_output=True,
                timeout=10,
            )

    def _spawn_agent(
        self,
        agent_id: str,
        spec_id: str,
        worktree: Path,
        model: str,
    ) -> str:
        """Spawn a Claude Code instance in a tmux session.

        Uses ``claude --prompt`` (not ``--print``) so the agent runs
        interactively and can invoke ``/ngo`` as a skill.
        """
        import shlex

        cc = self._config.claude_code
        prompt = _AGENT_PROMPT_TEMPLATE.format(
            agent_id=agent_id,
            spec_id=spec_id,
        )

        session_name = f"{cc.session_prefix}-{agent_id}-{os.getpid()}-{int(time.time())}"

        cmd = (
            f"cd {shlex.quote(str(worktree))} && claude "
            f"--model {shlex.quote(model)} "
            f"--permission-mode {shlex.quote(cc.permission_mode)} "
            f"--prompt {shlex.quote(prompt)}"
        )

        if not tmux.is_available():
            raise RuntimeError("tmux is required for swarm mode")

        tmux.new_session(session_name, cmd, remain_on_exit=True)
        logger.info("Spawned agent %s in tmux session %s", agent_id, session_name)
        return session_name

    def launch(
        self,
        epic_id: str,
        num_agents: int = 3,
        model: str | None = None,
        docs_root: Path | None = None,
    ) -> dict[str, Any]:
        """Launch the swarm: init queue, create worktrees, spawn agents.

        Args:
            epic_id: Epic ID to pull specs from.
            num_agents: Number of parallel agents to spawn.
            model: Claude model to use (default: from config).
            docs_root: Docs root for queue initialization.

        Returns:
            Dict with launch summary.
        """
        cc = self._config.claude_code
        effective_model = model or cc.model
        lease_ttl = self._config.queue.lease_ttl_seconds

        # Resolve docs root
        if docs_root is None:
            docs_root = self._config.resolve_spec_root()

        # Initialize queue from backlog
        queue_state = self._queue.initialize_from_backlog(
            docs_root,
            epic_id=epic_id,
            max_agents=num_agents,
            lease_ttl=lease_ttl,
        )

        if not queue_state.entries:
            return {
                "success": False,
                "error": f"No eligible specs found for epic {epic_id}",
            }

        # Cap agents to available specs
        actual_agents = min(num_agents, len(queue_state.entries))

        now = datetime.now(tz=UTC).isoformat()
        state = SwarmState(
            epic_id=epic_id,
            started_at=now,
            max_agents=actual_agents,
            lease_ttl_seconds=lease_ttl,
            model=effective_model,
        )

        launched = []
        for i in range(1, actual_agents + 1):
            agent_id = f"claude-{i}"

            # Claim spec from queue
            claim = self._queue.claim(agent_id)
            if "error" in claim:
                logger.warning("Failed to claim for %s: %s", agent_id, claim["error"])
                break

            spec_id = claim["spec_id"]

            # Create worktree
            try:
                wt_path = self._create_worktree(agent_id)
            except RuntimeError as exc:
                logger.error("Worktree creation failed for %s: %s", agent_id, exc)
                self._queue.release(agent_id, spec_id, reason=str(exc))
                continue

            # Spawn tmux session
            try:
                session_name = self._spawn_agent(agent_id, spec_id, wt_path, effective_model)
            except (RuntimeError, tmux.TmuxError) as exc:
                logger.error("Spawn failed for %s: %s", agent_id, exc)
                self._queue.release(agent_id, spec_id, reason=str(exc))
                self._remove_worktree(agent_id)
                continue

            lease_expires = datetime.fromtimestamp(claim["lease_expires"], tz=UTC).isoformat()

            state.agents[agent_id] = AgentState(
                spec_id=spec_id,
                worktree=str(wt_path),
                tmux_session=session_name,
                branch=f"nspec/{agent_id}",
                claimed_at=now,
                lease_expires=lease_expires,
                status="running",
            )
            launched.append({"agent_id": agent_id, "spec_id": spec_id})

        self._save_state(state)

        return {
            "success": True,
            "epic_id": epic_id,
            "model": effective_model,
            "agents_launched": len(launched),
            "agents": launched,
            "specs_in_queue": len(queue_state.entries) - len(launched),
            "swarm_state_path": str(self.state_path),
        }

    def status(self) -> dict[str, Any]:
        """Read swarm state and return agent health + progress."""
        state = self._load_state()
        if state is None:
            return {"error": "No swarm active. Call swarm_launch first."}

        agents_info = []
        for aid, agent in state.agents.items():
            # Check if tmux session is still alive
            alive = tmux.has_session(agent.tmux_session) if tmux.is_available() else False
            info: dict[str, Any] = {
                "agent_id": aid,
                "spec_id": agent.spec_id,
                "branch": agent.branch,
                "status": agent.status,
                "tmux_alive": alive,
                "claimed_at": agent.claimed_at,
                "lease_expires": agent.lease_expires,
            }
            # Enrich with branch PR status (best-effort, non-blocking)
            try:
                from nspec.workflow.branches import get_branch_pr_status

                pr_info = get_branch_pr_status(agent.branch, cwd=str(self._project_root))
                info["pr_status"] = pr_info.get("status")
                info["pr_url"] = pr_info.get("url")
            except Exception:
                info["pr_status"] = None
                info["pr_url"] = None
            agents_info.append(info)

        return {
            "epic_id": state.epic_id,
            "model": state.model,
            "started_at": state.started_at,
            "max_agents": state.max_agents,
            "agents": agents_info,
            "completed": [
                {"spec_id": c.spec_id, "agent_id": c.agent_id, "completed_at": c.completed_at}
                for c in state.completed
            ],
            "failed": state.failed,
            "active_count": sum(1 for a in state.agents.values() if a.status == "running"),
            "completed_count": len(state.completed),
            "failed_count": len(state.failed),
        }

    def teardown(self) -> dict[str, Any]:
        """Kill all agents, clean worktrees, clear state."""
        state = self._load_state()
        if state is None:
            return {"error": "No swarm active."}

        killed = []
        cleaned = []

        # Kill tmux sessions
        for aid, agent in state.agents.items():
            if tmux.is_available():
                tmux.kill_session(agent.tmux_session)
            killed.append(aid)

            # Release any active queue claims
            if agent.status == "running":
                self._queue.release(aid, agent.spec_id, reason="swarm teardown")

        # Remove worktrees
        for aid in list(state.agents.keys()):
            self._remove_worktree(aid)
            cleaned.append(aid)

        # Clear state file
        if self.state_path.exists():
            self.state_path.unlink()

        # Clear queue
        self._queue.clear()

        return {
            "success": True,
            "agents_killed": killed,
            "worktrees_cleaned": cleaned,
            "completed_specs": [c.spec_id for c in state.completed],
        }
