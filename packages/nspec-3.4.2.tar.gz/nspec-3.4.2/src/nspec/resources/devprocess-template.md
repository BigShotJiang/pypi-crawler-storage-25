<!-- managed-by: nspec -->
# {{project_name}} Dev Process

## Philosophy

This project uses [nspec](https://github.com/novabuilt/nspec) for specification-driven development. All work is tracked through specs (FR + IMPL pairs), epics group related work, and progress is tracked via MCP tools.

## Core Workflow

```
{{test_command}}                   → Unit tests pass?
{{lint_command}}                   → Lint/type check clean?
{{format_command}}                 → Code formatted?
commit                             → One commit per change
```

## Active Work Tracking (MANDATORY)

**There must always be an active epic when work is in flight.** At session start:
1. Call `get_epic()` to check if an active epic is set
2. If not, call `epics()` to see available epics, then set the active one via `activate(epic_id)`
3. Call `next_spec(epic_id)` to find the highest-priority unblocked spec

## Progress Tracking (MANDATORY)

When working on an nspec spec, you MUST call nspec MCP tools to track progress incrementally. Do not batch updates — call each tool immediately after the corresponding work is done.

### After completing each IMPL task:
1. Verify the work is done (tests pass if applicable)
2. Call `task_complete` with the spec_id and task_id
3. Read the response to see remaining tasks and progress %
4. Continue to the next task

### After satisfying an acceptance criterion:
1. Call `criteria_complete` with the spec_id and criteria_id

### After all tasks are done:
1. Call `advance` to move the spec to the next status

### Why this matters:
- The TUI dashboard shows real-time progress to the user
- Session state is persisted for cross-session handoff
- Skipping these calls means the spec stays at 0% even though work is complete

## Dependency Semantics

`deps: [X, Y]` on spec S means "S is blocked by X and Y; X and Y are **upstream** and must complete first." The arrow is **downstream to upstream**: a spec lists the things it waits on.

When the user says "add X as a dep of Y," X goes **into Y's `deps:` list** (Y waits on X, X runs first).

MCP tool mapping: `add_dep(spec_id, dep_id)` — `dep_id` is the upstream prerequisite, `spec_id` is the downstream waiter.

**Guardrail:** Before editing dependencies, echo back the direction to confirm ("so Y will be blocked by X, correct?"). Getting this backwards creates circular dependencies or silently misordered execution.

## Review Process

Every spec that reaches review MUST have its findings documented in the IMPL file. The `write_review_verdict` MCP tool handles the Review History table and header fields automatically — but the implementer is responsible for providing a concise summary of what was found and fixed via the `feedback` parameter.

### Findings format

Each review round should produce a findings entry in this format:

```
**Review N (YYYY-MM-DD HH:MM — VERDICT):**
(1) Finding description with file:line references. (2) Next finding. ...
```

### Review Integrity

The `execute_agent(prompt=..., purpose="review")` MCP call MUST be used for every review. If `execute_agent` fails or times out, the spec MUST be parked — never substitute a self-review or fabricate a verdict.

Calling `write_review_verdict(reviewer='codex')` without actually executing the review agent is silent fraud. The review exists to catch bugs; bypassing it defeats the purpose.

### Long Review Prompts

`review_spec` output can exceed argument length limits when passed inline. Always write the review prompt to a temp file and pass its path to `execute_agent` instead of inlining the prompt string. Do this proactively — do not try inline first and fall back.

## Parking Policy

Parking (`park(spec_id, reason)`) is for specs that **cannot proceed right now**. Valid parking reasons are narrow:

| Valid | Example |
|-------|---------|
| Blocked by an upstream dependency | "Blocked by S042 (not yet complete)" |
| Requires design decision from a human | "Needs human decision on API shape" |
| External system unavailable | "CI runner offline, cannot verify" |
| Agent cannot resolve test failures | "Tests failing after 3 fix attempts" |

**These are NOT valid parking reasons** (do the work instead):

| Invalid Reason | Correct Action |
|----------------|----------------|
| "Awaiting CI" | Run tests locally, then advance |
| "Awaiting verification" | Verify now (Phase 5) |
| "Release-gated" | Complete the spec; release is a separate concern |
| "Needs tests written" | Write the tests (that is the work) |
| "Code review pending" | Call `review_spec` and `execute_agent` |

## Scope Ownership (Concurrent Agents)

When multiple agents work the same repository (via `/nloop`, `/ngo`, or parallel sessions):

- The agent working on spec S owns the files scoped to S — FR, IMPL, implementation code, tests.
- The main thread (or orchestrator) owns everything else (config, shared infra).
- If an agent sees unexpected changes in files it does not own, it flags them — it does not revert or overwrite.
- **One writer per file per session.** Two agents editing the same file creates merge conflicts.

## Auto-Generated Sections

Sections whose heading ends in `(auto-generated)` are populated post-merge by CI or tooling. During review, **skip these sections entirely** — their contents are not meaningful at review time and findings about them are noise.

## Status Management

**Never hand-edit the Status field** in FR or IMPL files. Use nspec MCP tools:

| Action | Tool |
|--------|------|
| Start work | `activate(spec_id)` |
| Move to next status | `advance(spec_id)` |
| Archive completed | `complete(spec_id)` |
| Pause work | `park(spec_id, reason)` |

Hand-editing the status emoji breaks sync between FR/IMPL status and nspec's internal state.

## Commit Rules

### Format
```
{{commit_format}}
```

### Refs Trailer (MANDATORY)

Every commit related to a spec MUST include a `Refs: S###` line in the commit body. This trailer drives post-merge file-attribution workflows.

```
feat(api): add pagination support

Implement cursor-based pagination for list endpoints.

Refs: S042
```

`/ngo` adds this automatically. Manual commits must include it explicitly.

### Branch and PR Strategy

For `/nloop` batch runs: create one branch for the batch, one commit per spec on that branch, and one PR at the end. Per-spec branches and PRs create review churn.

For standalone `/ngo` runs: one branch, one PR per spec is fine.

## Impasse Protocol

When reviewer and implementer disagree on a finding after one re-review round:

1. Record both positions in the IMPL `## Notes & References` section.
2. Advance the spec to Testing status.
3. Leave a note: "Impasse on [finding] — needs human triage."

Do not loop indefinitely between reviewer and implementer. Two rounds maximum per finding, then escalate.

## Tracker References

When a spec originates from an external issue (GitHub, Jira, etc.), the FR's `## Tracker References` section MUST contain the issue link. Leaving it as "No linked issues." when the spec was imported from an issue is a defect.

The `issue_import` tool populates this automatically. If creating a spec manually from an issue, add the reference in the `github_issue:` header field.

## Spec-ID Collision Check

`issue_import` and `create_spec` scan only the current branch for the next free ID. On a feature branch that has diverged from main, the next-free ID may already be claimed by a sibling branch.

**Before creating specs on a long-lived branch:** merge or rebase from main first. After merge, run `validate()` to detect any collisions. Use `unify_collisions()` to resolve them if found.

## MCP Tool Error Reporting

When an nspec MCP tool returns an unexpected error or behaves incorrectly:

1. Note the tool name, arguments, and error message.
2. File an issue in the project's issue tracker with the tool name, arguments, and error details.
3. Work around the error if possible and continue.

Do not silently swallow MCP tool errors. Filing issues is how the tooling improves.

## Quality Gates

```
{{test_command}}       → Fast tests, fail-fast
{{check_command}}      → Full quality gate (format + lint + typecheck + test)
```

## nspec MCP Tools Reference

### Query Tools
| Tool | Purpose |
|------|---------|
| `epics()` | List epics with progress |
| `show(spec_id)` | Show spec details (FR + IMPL) |
| `next_spec(epic_id)` | Find highest-priority unblocked spec |
| `validate()` | Run 6-layer validation engine |
| `blocked_specs()` | List blocked/paused/exception specs |

### Mutation Tools
| Tool | Purpose |
|------|---------|
| `create_spec(title, priority)` | Create new FR + IMPL pair |
| `activate(spec_id)` | Start working on a spec |
| `task_complete(spec_id, task_id)` | Mark an IMPL task done |
| `criteria_complete(spec_id, criteria_id)` | Mark an acceptance criterion done |
| `advance(spec_id)` | Advance spec to next status |
| `complete(spec_id)` | Archive a completed spec |

### Session Tools
| Tool | Purpose |
|------|---------|
| `session_start(spec_id)` | Initialize work session |
| `session_save(spec_id)` | Save session state for handoff |
| `session_resume(spec_id)` | Resume previous session |
| `session_clear()` | Clear session state |

## File Structure

```
{{docs_root}}/
├── {{feature_requests}}/   # Active feature requests
├── {{implementation}}/     # Active implementation plans
└── {{completed}}/          # Archived work
    ├── done/               # Completed specs
    ├── superseded/         # Superseded specs
    └── rejected/           # Rejected specs
```

## Configuration

All nspec configuration lives in `.novabuilt.dev/nspec/config.toml`.

Priority: CLI args > env vars (`NSPEC_*`) > config.toml > built-in defaults.
