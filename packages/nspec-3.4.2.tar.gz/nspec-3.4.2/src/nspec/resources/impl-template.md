# IMPL-XXX: Title

**Status:** Planning
**LOE:** N/A

<!--
STATUS FLOW: Planning → Active → Testing → Completed

Use nspec MCP tools to change status (never edit manually):
  activate(spec_id)                   → Start work
  task_complete(spec_id, task_id)     → Mark task done
  criteria_complete(spec_id, ac_id)   → Mark AC satisfied
  advance(spec_id)                    → Move to next status
  complete(spec_id)                   → Archive when done

CHECKBOX RULE: Only checkbox items (- [ ]) are tracked as tasks.
Plain bullets are documentation/notes and are NOT counted.
-->

## Executive Summary

[1-2 sentences: What we're building, key approach.]

## Design Decisions

### Approach

[Which approach was chosen and WHY. Reference the specific codebase patterns being followed (e.g., "Follow the SessionDAO pattern from session.py").]

### Alternatives Considered

- **Option A:** [Brief description] — [Why not chosen: trade-off reason]
- **Option B (chosen):** [Brief description] — [Why chosen: key advantage]

### Key Design Choices

- [Decision 1]: [Choice made] because [rationale]
- [Decision 2]: [Choice made] because [rationale]

## Implementation Strategy

### Phasing

[Group tasks into logical phases based on the design. Delete unused phases.]

**Phase 1: [Phase name]** — [What this phase delivers]
**Phase 2: [Phase name]** — [What this phase delivers]

## Tasks

### Phase 1: Core Logic

- [ ] 1. [First task — concrete, verifiable action]
  - File: `src/module.py`
  - Validates: FR AC-F1

- [ ] 2. [Second task]
  - File: `src/other.py`
  - Validates: FR AC-F2

### Phase 2: Integration

- [ ] 3. [Wire into entry points]
  - File: `src/cli.py`

### Phase 3: Testing

- [ ] 4. [Unit tests for core logic]
  - File: `tests/test_module.py`
  - Validates: FR TC-P1, TC-N1, TC-E1

## Files Modified

| File | Change |
|------|--------|
| `path/to/file.py` | New — description |

## Definition of Done

- [ ] dod-1. Tests pass
- [ ] dod-2. Lint/typecheck clean
- [ ] dod-3. All FR acceptance criteria marked complete
- [ ] dod-4. Agent review verdict is APPROVED
- [ ] dod-5. Code committed with descriptive message

## Review

**Implementer:** —
**Reviewer:** —
**Verdict:** PENDING

### Review History
| # | Date | Verdict | Reviewer |
|---|------|---------|----------|

### Findings

[Reviewer writes findings here]

## Session Notes

### YYYY-MM-DD

- **Started:** [What phase/task]
- **Decision:** [Choice made and why]
- **Finding:** [Unexpected insight]
- **Next:** [What to pick up next session]
