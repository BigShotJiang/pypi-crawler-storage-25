# IMPL-XXX: Title

**Status:** Planning
**LOE:** N/A

<!--
STATUS FLOW: Planning → Active → Testing → Completed

Use nspec MCP tools to change status (never edit manually):
  activate(spec_id)                   → Start work
  task_complete(spec_id, task_id)     → Mark task done
  criteria_complete(spec_id, ac_id)   → Mark AC satisfied
  advance(spec_id)                    → Move to next status
  complete(spec_id)                   → Archive when done

CHECKBOX RULE: Only checkbox items (- [ ]) are tracked as tasks.
Plain bullets are documentation/notes and are NOT counted.
-->

## Executive Summary

<!-- 1-2 sentences: what we're building and the key approach. -->

## Implementation Strategy

### Approach

<!-- High-level description of how we'll implement this. -->

### Phasing

**Phase 1: Core Logic** — Data models, core logic, test fixtures
**Phase 2: Integration** — Wire into CLI/MCP/TUI entry points
**Phase 3: Testing** — Unit tests, integration tests, verification

## Tasks

### Phase 1: Core Logic

- [ ] 1. <!-- First concrete task -->
  - File: <!-- target file path -->
  - Validates: FR AC-F1

- [ ] 2. <!-- Second concrete task -->
  - File: <!-- target file path -->
  - Validates: FR AC-F2

### Phase 2: Integration

- [ ] 3. <!-- Wire into entry points -->
  - File: <!-- target file path -->

### Phase 3: Testing

- [ ] 4. <!-- Unit tests for core logic -->
  - File: <!-- test file path -->
  - Validates: FR TC-P1, TC-N1

## Files Modified

| File | Change |
|------|--------|
| <!-- file path --> | <!-- New or Modified — description --> |

## Definition of Done

- [ ] dod-1. Tests pass
- [ ] dod-2. Lint/typecheck clean
- [ ] dod-3. All FR acceptance criteria marked complete
- [ ] dod-4. Agent review verdict is APPROVED
- [ ] dod-5. Code committed with descriptive message

## Review

**Implementer:** —
**Reviewer:** —
**Verdict:** PENDING

### Review History
| # | Date | Verdict | Reviewer |
|---|------|---------|----------|

### Findings

<!-- Reviewer writes findings here -->

## Session Notes

### YYYY-MM-DD

- **Started:** <!-- What phase/task -->
- **Decision:** <!-- Choice made and why -->
- **Finding:** <!-- Unexpected insight -->
- **Next:** <!-- What to pick up next session -->
