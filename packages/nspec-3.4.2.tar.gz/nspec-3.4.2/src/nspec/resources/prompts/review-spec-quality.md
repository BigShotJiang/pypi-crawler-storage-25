You are reviewing the specification quality for spec {spec_id}: {title}

This spec is in a **pre-implementation** state (Planning/Proposed). There is no code to review yet. Your job is to review the FR and IMPL documents for quality, completeness, and internal consistency.

## Acceptance Criteria

{ac_text}

## Implementation Tasks (with completion state)

{task_text}

## Your Task

Review the **spec documents above** (NOT code). Check:
1. Are the acceptance criteria specific, testable, and complete?
2. Do the implementation tasks cover all acceptance criteria? (traceability)
3. Are there any ambiguities, contradictions, or missing edge cases?
4. Is the task decomposition reasonable for the stated LOE?
5. Are `Validates:` annotations present and correct on tasks?

### Scope discipline (CRITICAL)

- **Review ONLY the FR and IMPL content provided above.** Do not explore the codebase.
- **Do not open other specs, source files, or historical documents.** Your review budget is for this spec's documents only.
- **DO NOT run tests or look at code.** This is a document quality review.

### Findings format

After your review, **enumerate findings as a numbered list** with severity tags:

- **P0 (Blocker):** Missing or untestable acceptance criteria, critical gap in task coverage
- **P1 (Major):** Ambiguous AC, missing edge case, task-AC traceability gap
- **P2 (Minor):** Wording improvement, missing optional section, minor inconsistency
- **P3 (Nit):** Optional polish, no action required

If no issues, write: "No issues found. Spec documents are well-structured and complete."

### Verdict (CRITICAL — verdict MUST match severity)

Respond with exactly one verdict line:

```
VERDICT: APPROVED
```
or
```
VERDICT: NEEDS_WORK
```

**Verdict-severity mapping (this is non-negotiable):**

- **At least one P0 or P1 finding → VERDICT: NEEDS_WORK**
- **Only P2/P3 findings (or no findings) → VERDICT: APPROVED**

Do **NOT** use NEEDS_WORK for P2/P3-only findings. P2 means "minor improvement suggestion," not "blocker." If you find yourself wanting to write `NEEDS_WORK` while listing only P2/P3 findings, escalate the most concerning one to P1 with explicit justification, *or* return APPROVED. The verdict and the severity list must agree.
