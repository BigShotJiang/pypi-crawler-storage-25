You are reviewing an implementation for spec {spec_id}: {title}

## Acceptance Criteria

{ac_text}

## Implementation Tasks (with completion state)

{task_text}

## Code Changes (git diff)

```diff
{git_diff}
```

## Test Results

Tests were run by the implementer before submitting for review:

```
{test_results}
```

## Your Task

Review **only the code changes shown above** against the acceptance criteria. Check:
1. Do the diff hunks satisfy each acceptance criterion?
2. Are there any bugs, security issues, or quality concerns introduced *by this diff*?
3. Is the implementation complete (all tasks checked)?

### Scope discipline (CRITICAL)

- **Read ONLY files that appear in the diff above.** Do not explore the wider codebase.
- **Do not open completed specs, unrelated modules, or historical files.** Your review budget is for *this* diff, not codebase tourism.
- If a finding requires context from another file, name the file in the finding — do not read it yourself.
- **DO NOT run tests** (`make test-quick`, `pytest`, etc.). Test results above are the receipt.

### Findings format

After your review, **enumerate findings as a numbered list** with severity tags:

- **P0 (Blocker):** Breaks functionality or introduces a security vulnerability
- **P1 (Major):** Incorrect behavior, missing edge case, or significant quality concern
- **P2 (Minor):** Style, naming, or minor improvement suggestion
- **P3 (Nit):** Optional polish, no action required

Include `file:line` references for each finding. If no issues, write: "No issues found. All acceptance criteria satisfied."

### Verdict (CRITICAL — verdict MUST match severity)

Respond with exactly one verdict line:

```
VERDICT: APPROVED
```
or
```
VERDICT: NEEDS_WORK
```

**Verdict-severity mapping (this is non-negotiable):**

- **At least one P0 or P1 finding → VERDICT: NEEDS_WORK**
- **Only P2/P3 findings (or no findings) → VERDICT: APPROVED**

Do **NOT** use NEEDS_WORK for P2/P3-only findings. P2 means "minor improvement suggestion," not "blocker." If you find yourself wanting to write `NEEDS_WORK` while listing only P2/P3 findings, escalate the most concerning one to P1 with explicit justification, *or* return APPROVED. The verdict and the severity list must agree.

> Note: a post-parse reconciliation pass enforces this rule downstream — if you emit a verdict that disagrees with your severity list, the severity list wins and the override is annotated in the IMPL findings (S393). Get it right here so the override never has to fire.
