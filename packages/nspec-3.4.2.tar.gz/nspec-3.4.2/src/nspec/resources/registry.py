"""Resource handle registry for configurable prompts and templates.

Maps logical handle names (e.g., ``review-prompt``, ``fr-template``) to file
paths.  Resolution order: ``[resources]`` config override → built-in package
resource.

Usage::

    from nspec.resources.registry import resolve_resource, load_resource

    path = resolve_resource("review-prompt", project_root)
    text = load_resource("review-prompt", project_root)
"""

from __future__ import annotations

import logging
from importlib import resources as pkg_resources
from pathlib import Path

logger = logging.getLogger(__name__)


class _Placeholder:
    """Proxy object returned for unrecognized template placeholders.

    Handles attribute access (``{key.attr}``), item access (``{key[0]}``),
    format specs (``{key:>10}``), and conversions (``{key!r}``) by
    reconstructing the original placeholder text instead of raising errors.
    """

    __slots__ = ("_key",)

    def __init__(self, key: str) -> None:
        self._key = key

    def __str__(self) -> str:
        return "{" + self._key + "}"

    def __repr__(self) -> str:
        return "{" + self._key + "}"

    def __format__(self, format_spec: str) -> str:
        if format_spec:
            return "{" + self._key + ":" + format_spec + "}"
        return "{" + self._key + "}"

    def __getattr__(self, name: str) -> _Placeholder:
        return _Placeholder(self._key + "." + name)

    def __getitem__(self, key: object) -> _Placeholder:
        return _Placeholder(self._key + "[" + str(key) + "]")


class SafeFormatMap(dict):
    """Dict subclass that preserves unrecognized format placeholders.

    When used with ``str.format_map()``, returns a ``_Placeholder`` proxy
    for missing keys instead of raising ``KeyError``.  This prevents crashes
    when templates and code are out of sync.
    """

    def __missing__(self, key: str) -> _Placeholder:
        return _Placeholder(key)


class ResourceNotFoundError(FileNotFoundError):
    """Resolved resource path does not exist."""

    def __init__(self, handle: str, path: Path) -> None:
        self.handle = handle
        self.resolved_path = path
        super().__init__(f"Resource '{handle}' resolved to {path}, but file does not exist")


class UnknownHandleError(KeyError):
    """Handle has no built-in default and no config override."""

    def __init__(self, handle: str) -> None:
        self.handle = handle
        super().__init__(
            f"Unknown resource handle '{handle}' — no built-in default or config override"
        )


# Maps handle names → package resource paths (relative to nspec.resources)
BUILTIN_HANDLES: dict[str, str] = {
    "review-prompt": "prompts/review.md",
    "refine-impl-prompt": "prompts/refine-impl.md",
    "refine-fr-prompt": "prompts/refine-fr.md",
    "fr-template": "fr-template.md",
    "impl-template": "impl-template.md",
    "claudemd-template": "claudemd-template.md",
    "changelog-template": "changelog-template.md",
}


def _get_config_overrides(project_root: Path | None) -> dict[str, str]:
    """Read ``[resources]`` section from config.toml.

    Returns an empty dict if config is absent (FileNotFoundError).
    Re-raises on malformed config to surface errors early.
    """
    if project_root is None:
        return {}
    try:
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        return dict(config.resources.handles)
    except FileNotFoundError:
        return {}
    except Exception:
        logger.warning("Failed to load [resources] config from %s", project_root, exc_info=True)
        raise


def resolve_resource(handle: str, project_root: Path | None = None) -> Path:
    """Resolve a handle to a file path.

    Resolution order:

    1. ``[resources]`` config override (path relative to ``.novabuilt.dev/nspec/``)
    2. Built-in package resource

    Args:
        handle: Logical name (e.g., ``"review-prompt"``).
        project_root: Project root for config lookup.

    Returns:
        Path to the resource file.

    Raises:
        UnknownHandleError: No built-in default and no config override.
        ResourceNotFoundError: Resolved path does not exist.
    """
    overrides = _get_config_overrides(project_root)

    # Check config override first
    if handle in overrides:
        override_path = overrides[handle]
        # Reject absolute paths and parent traversal for security
        if Path(override_path).is_absolute() or ".." in Path(override_path).parts:
            raise ValueError(
                f"Resource override for '{handle}' must be a relative path "
                f"without '..' traversal, got: {override_path!r}"
            )
        if project_root is None:
            raise ResourceNotFoundError(handle, Path(override_path))
        path = project_root / ".novabuilt.dev" / "nspec" / override_path
        if not path.exists():
            raise ResourceNotFoundError(handle, path)
        return path

    # Check profile handles (e.g., "fr-template:quick", "review-prompt:spike")
    if ":" in handle:
        base, profile = handle.rsplit(":", 1)
        if base in ("fr-template", "impl-template"):
            doc_type = "fr" if base == "fr-template" else "impl"
            # Check project-local override
            if project_root is not None:
                local_path = (
                    project_root
                    / ".novabuilt.dev"
                    / "nspec"
                    / "templates"
                    / profile
                    / f"{doc_type}.md"
                )
                if local_path.exists():
                    return local_path
            # Fall back to package resource
            pkg_path = f"templates/{profile}/{doc_type}.md"
            ref = pkg_resources.files("nspec.resources").joinpath(pkg_path)
            # importlib resources returns a Traversable; resolve to real path
            resolved = Path(str(ref))
            if not resolved.exists():
                raise ResourceNotFoundError(handle, resolved)
            return resolved
        if base == "review-prompt":
            # Type-specific review prompt (e.g., "review-prompt:spike")
            # Check project-local override
            if project_root is not None:
                local_path = (
                    project_root
                    / ".novabuilt.dev"
                    / "nspec"
                    / "resources"
                    / "prompts"
                    / f"review-{profile}.md"
                )
                if local_path.exists():
                    return local_path
            # Fall back to package resource
            pkg_path = f"prompts/review-{profile}.md"
            ref = pkg_resources.files("nspec.resources").joinpath(pkg_path)
            resolved = Path(str(ref))
            if resolved.exists():
                return resolved
            # No type-specific prompt found — fall back to default review-prompt
            logger.debug(
                "No type-specific review prompt for %r, falling back to default",
                profile,
            )
            return resolve_resource("review-prompt", project_root)

    # Check built-in handles
    if handle in BUILTIN_HANDLES:
        # Check project-local override by convention
        if project_root is not None:
            local_path = (
                project_root / ".novabuilt.dev" / "nspec" / "resources" / BUILTIN_HANDLES[handle]
            )
            if local_path.exists():
                return local_path
        # Fall back to package resource
        ref = pkg_resources.files("nspec.resources").joinpath(BUILTIN_HANDLES[handle])
        resolved = Path(str(ref))
        if not resolved.exists():
            raise ResourceNotFoundError(handle, resolved)
        return resolved

    raise UnknownHandleError(handle)


def load_resource(handle: str, project_root: Path | None = None) -> str:
    """Resolve a handle and read the file content.

    Args:
        handle: Logical name (e.g., ``"review-prompt"``).
        project_root: Project root for config lookup.

    Returns:
        File content as a string.
    """
    path = resolve_resource(handle, project_root)
    return path.read_text(encoding="utf-8")
