"""Read spec files from any git ref without checking out the branch.

Wraps ``git ls-tree`` and ``git show`` via subprocess — no gitpython dependency.
Foundation for all "read from main" operations in E012.

Usage::

    from nspec.git_reader import list_spec_files, read_spec_content, get_spec_ids_from_ref

    files = list_spec_files("main", "docs/frs/active", "FR-*.md")
    content = read_spec_content("main", "docs/frs/active/FR-S001-foo.md")
    ids = get_spec_ids_from_ref("main")
"""

from __future__ import annotations

import fnmatch
import re
import subprocess
from pathlib import PurePosixPath

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class GitReaderError(Exception):
    """Base exception for git_reader operations."""


class GitRefNotFoundError(GitReaderError):
    """Raised when the requested git ref does not exist."""

    def __init__(self, ref: str) -> None:
        self.ref = ref
        super().__init__(f"Git ref not found: {ref!r}")


class FileNotFoundInRefError(GitReaderError):
    """Raised when a file path does not exist in the given ref."""

    def __init__(self, ref: str, path: str) -> None:
        self.ref = ref
        self.path = path
        super().__init__(f"File not found in ref {ref!r}: {path!r}")


class GitRepositoryError(GitReaderError):
    """Raised when the current directory is not inside a git repository."""

    def __init__(self) -> None:
        super().__init__("Not inside a git repository")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

# Anchored to match from filename start, same as crud.py's get_all_spec_ids
_FR_SPEC_RE = re.compile(r"^FR-([ES]\d{3}[a-z]?)", re.IGNORECASE)
_IMPL_SPEC_RE = re.compile(r"^IMPL-([ES]\d{3}[a-z]?)", re.IGNORECASE)


def _run_git(*args: str, cwd: str | None = None) -> str:
    """Run a git command and return stdout.

    Translates common git errors into module-specific exceptions.
    """
    cmd = ["git", *args]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False,
            cwd=cwd,
        )
    except FileNotFoundError:
        raise GitReaderError("git executable not found on PATH") from None

    if result.returncode != 0:
        stderr = result.stderr.strip()

        # Not a git repo
        if "not a git repository" in stderr.lower():
            raise GitRepositoryError()

        # Bad ref — git ls-tree and git show both mention "Not a valid object name"
        # or "fatal: invalid object name" or "unknown revision"
        if any(
            phrase in stderr.lower()
            for phrase in (
                "not a valid object name",
                "invalid object name",
                "unknown revision",
                "bad revision",
                "ambiguous argument",
            )
        ):
            # Extract the ref from the command args
            ref = _extract_ref_from_args(args)
            raise GitRefNotFoundError(ref)

        # Path not found in ref — git show says "does not exist" or "exists on disk"
        if "does not exist" in stderr.lower() or "exists on disk" in stderr.lower():
            ref = _extract_ref_from_args(args)
            path = _extract_path_from_args(args)
            raise FileNotFoundInRefError(ref, path)

        raise GitReaderError(f"git {args[0]} failed: {stderr}")

    return result.stdout


def _extract_ref_from_args(args: tuple[str, ...]) -> str:
    """Best-effort extraction of the ref from git command args."""
    for arg in args:
        if ":" in arg:
            return arg.split(":")[0]
    # For ls-tree: args are ("ls-tree", "--name-only", "-r", REF, "--", path)
    # Find the first non-flag arg after the subcommand
    for arg in args[1:]:
        if arg == "--":
            break
        if not arg.startswith("-"):
            return arg
    return "<unknown>"


def _extract_path_from_args(args: tuple[str, ...]) -> str:
    """Best-effort extraction of the path from git command args."""
    for arg in args:
        if ":" in arg:
            return arg.split(":", 1)[1]
    # After '--' in ls-tree
    if "--" in args:
        idx = list(args).index("--")
        if idx + 1 < len(args):
            return args[idx + 1]
    return "<unknown>"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def list_spec_files(
    ref: str,
    docs_path: str,
    pattern: str = "*.md",
    *,
    cwd: str | None = None,
) -> list[str]:
    """List files matching a glob pattern from a git tree-ish.

    Uses ``git ls-tree --name-only -r`` to enumerate paths under *docs_path*
    in the given *ref*, then filters by *pattern* using fnmatch.

    Args:
        ref: Git ref (branch, tag, commit SHA).
        docs_path: Directory path within the repo (e.g. ``"docs/frs/active"``).
        pattern: Glob pattern to filter filenames (default ``"*.md"``).
        cwd: Working directory for git commands (default: current directory).

    Returns:
        Sorted list of relative file paths matching the pattern.

    Raises:
        GitRefNotFoundError: If *ref* does not exist.
        FileNotFoundInRefError: If *docs_path* does not exist in *ref*.
        GitRepositoryError: If not inside a git repository.
    """
    # Normalize docs_path — strip trailing slash
    docs_path = docs_path.rstrip("/")

    # Verify the path exists in the ref (ls-tree silently returns empty for
    # missing paths, so we check explicitly with a non-recursive ls-tree)
    check = _run_git("ls-tree", ref, "--", docs_path, cwd=cwd)
    if not check.strip():
        raise FileNotFoundInRefError(ref, docs_path)

    stdout = _run_git("ls-tree", "--name-only", "-r", ref, "--", docs_path, cwd=cwd)

    paths: list[str] = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        # ls-tree returns full paths from repo root; filter by filename pattern
        filename = PurePosixPath(line).name
        if fnmatch.fnmatch(filename, pattern):
            paths.append(line)

    paths.sort()
    return paths


def read_spec_content(
    ref: str,
    file_path: str,
    *,
    cwd: str | None = None,
) -> str:
    """Read file content from a git tree-ish.

    Uses ``git show <ref>:<file_path>`` to retrieve the content.

    Args:
        ref: Git ref (branch, tag, commit SHA).
        file_path: Path within the repo (e.g. ``"docs/frs/active/FR-S001-foo.md"``).
        cwd: Working directory for git commands (default: current directory).

    Returns:
        File content as a string.

    Raises:
        GitRefNotFoundError: If *ref* does not exist.
        FileNotFoundInRefError: If *file_path* does not exist in *ref*.
        GitRepositoryError: If not inside a git repository.
    """
    try:
        return _run_git("show", f"{ref}:{file_path}", cwd=cwd)
    except GitReaderError:
        # Re-check: is this a bad ref or a bad path?
        # If the ref itself is invalid, git show would fail with "unknown revision"
        # which is already mapped. But sometimes git says "exists on disk but not in ref"
        # which we need to map to FileNotFoundInRefError.
        raise


def get_spec_ids_from_ref(
    ref: str,
    docs_root_relative: str = "docs",
    *,
    cwd: str | None = None,
) -> set[str]:
    """Parse all spec IDs from FR/IMPL filenames in a git ref.

    Reuses the same filename patterns as ``crud.py``'s ``get_all_spec_ids``:
    extracts IDs from ``FR-{ID}-*.md`` and ``IMPL-{ID}-*.md`` filenames.

    Args:
        ref: Git ref (branch, tag, commit SHA).
        docs_root_relative: Docs directory relative to repo root (default ``"docs"``).
        cwd: Working directory for git commands (default: current directory).

    Returns:
        Set of normalized spec IDs (e.g. ``{"S001", "S042", "E001"}``).

    Raises:
        GitRefNotFoundError: If *ref* does not exist.
        GitRepositoryError: If not inside a git repository.
    """
    # Import here to avoid circular imports at module level
    from nspec.domain.ids import normalize_spec_ref

    # List all .md files under the docs root
    stdout = _run_git("ls-tree", "--name-only", "-r", ref, "--", docs_root_relative, cwd=cwd)

    ids: set[str] = set()
    for line in stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        filename = PurePosixPath(line).name

        # Try FR pattern (anchored match, same as crud.py)
        match = _FR_SPEC_RE.match(filename)
        if match:
            try:
                ids.add(normalize_spec_ref(match.group(1)))
            except ValueError:
                continue

        # Try IMPL pattern (anchored match, same as crud.py)
        match = _IMPL_SPEC_RE.match(filename)
        if match:
            try:
                ids.add(normalize_spec_ref(match.group(1)))
            except ValueError:
                continue

    return ids


def get_all_remote_branch_refs(
    *,
    cwd: str | None = None,
) -> list[str]:
    """Return all remote branch ref names (e.g. ``origin/main``, ``origin/feat-x``).

    Uses ``git for-each-ref refs/remotes/origin/`` to enumerate remote tracking
    branches.  Excludes ``origin/HEAD`` (symbolic ref).

    Returns an empty list when not inside a git repository or when no remotes
    are configured — callers should treat this as a best-effort scan.

    Args:
        cwd: Working directory for git commands (default: current directory).

    Returns:
        Sorted list of remote branch ref short-names.
    """
    try:
        stdout = _run_git(
            "for-each-ref",
            "--format=%(refname:short)",
            "refs/remotes/origin/",
            cwd=cwd,
        )
    except GitReaderError:
        return []

    refs: list[str] = []
    for line in stdout.splitlines():
        line = line.strip()
        if not line or line == "origin/HEAD":
            continue
        refs.append(line)

    refs.sort()
    return refs


def get_spec_ids_from_all_branches(
    docs_root_relative: str = "docs",
    *,
    cwd: str | None = None,
) -> set[str]:
    """Collect spec IDs from all remote branches.

    Iterates every remote branch returned by :func:`get_all_remote_branch_refs`,
    calls :func:`get_spec_ids_from_ref` for each, and unions the results.
    Branches where the ``docs/`` directory does not exist or where git
    operations fail are silently skipped (best-effort).

    Args:
        docs_root_relative: Docs directory relative to repo root (default ``"docs"``).
        cwd: Working directory for git commands (default: current directory).

    Returns:
        Union of all spec IDs found across all remote branches.
    """
    all_ids: set[str] = set()
    refs = get_all_remote_branch_refs(cwd=cwd)

    for ref in refs:
        try:
            ids = get_spec_ids_from_ref(ref, docs_root_relative=docs_root_relative, cwd=cwd)
            all_ids |= ids
        except GitReaderError:
            # Branch may not have a docs/ directory, or ref may be stale.
            # Skip silently — this is a best-effort scan.
            continue

    return all_ids
