"""Version-gated sync — keeps skills and artifacts current after nspec upgrades.

Compares the runtime nspec version (from ``importlib.metadata``) against the
version recorded in ``config.toml [nspec] version``. On mismatch, runs:
1. artifacts sync (automatic — nspec-internal)
2. skills sync (consent-gated via ``[nspec] skills_auto_update``)
3. Updates config version stamp

Designed to be called once per MCP server session (guarded by caller).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("nspec.sync")


def get_runtime_version() -> str:
    """Return the installed nspec package version, or ``'dev'`` if unavailable."""
    try:
        from importlib.metadata import version as pkg_version

        return pkg_version("nspec")
    except Exception:
        return "dev"


def ensure_synced(project_root: Path | None = None) -> dict[str, Any]:
    """Run version-gated sync if runtime version differs from config version.

    Cheap when versions match (one TOML read + string compare).
    Idempotent — safe to call multiple times.

    Skills sync is gated by ``[nspec] skills_auto_update``:
    - ``True``  → auto-sync skills
    - ``False`` → skip skills
    - ``None``  → skip skills, return ``skills_update_available: True``

    Args:
        project_root: Project root directory. If None, resolved from config.

    Returns:
        Dict with sync status.
    """
    from nspec.config import NspecConfig

    runtime_version = get_runtime_version()

    try:
        config = NspecConfig.load(project_root)
    except Exception:
        logger.debug("Config load failed during sync check", exc_info=True)
        return {"synced": False, "reason": "config_load_failed"}

    config_version = config.nspec_meta.version

    # Fast path: versions match
    if config_version == runtime_version:
        return {"synced": False, "reason": "already_current", "version": runtime_version}

    logger.info(
        "Version mismatch: config=%s runtime=%s — syncing",
        config_version or "(none)",
        runtime_version,
    )

    result: dict[str, Any] = {
        "synced": True,
        "from_version": config_version,
        "to_version": runtime_version,
    }

    project_root_resolved = config.resolve_project_root()

    # 1. Artifacts sync (automatic — nspec-internal files)
    try:
        _sync_artifacts(config, project_root_resolved)
        result["artifacts_synced"] = True
    except Exception:
        logger.warning("Artifacts sync failed (non-fatal)", exc_info=True)
        result["artifacts_error"] = True

    # 2. Skills sync (consent-gated)
    sau = config.nspec_meta.skills_auto_update
    if sau is True:
        try:
            _sync_skills(config, project_root_resolved)
            result["skills_synced"] = True
        except Exception:
            logger.warning("Skills sync failed (non-fatal)", exc_info=True)
            result["skills_error"] = True
    elif sau is False:
        result["skills_skipped"] = True
    else:
        # None = unset → don't sync, flag as available
        result["skills_update_available"] = True

    # 3. Stamp version in config (AFTER sync)
    try:
        config.nspec_meta.version = runtime_version
        config.save()
        result["config_updated"] = True
    except Exception:
        logger.warning("Config version update failed (non-fatal)", exc_info=True)
        result["config_update_error"] = True

    return result


def apply_skills_update(
    project_root: Path | None = None,
    *,
    persist: bool | None = None,
) -> dict[str, Any]:
    """Run skills sync with user's consent choice.

    Args:
        project_root: Project root directory. If None, resolved from config.
        persist: Consent choice:
            ``True``  → sync + set ``skills_auto_update = true`` in config
            ``False`` → set ``skills_auto_update = false`` in config (no sync)
            ``None``  → sync once, don't change config preference

    Returns:
        Dict with sync results.
    """
    from nspec.config import NspecConfig

    try:
        config = NspecConfig.load(project_root)
    except Exception as e:
        return {"success": False, "error": str(e)}

    project_root_resolved = config.resolve_project_root()
    result: dict[str, Any] = {"success": True}

    # "never" — just record the preference, no sync
    if persist is False:
        config.nspec_meta.skills_auto_update = False
        config.save()
        result["skills_auto_update"] = False
        result["skills_synced"] = False
        return result

    # "always" or "once" — sync skills
    try:
        counts = _sync_skills(config, project_root_resolved)
        result.update(counts)
        result["skills_synced"] = True
    except Exception as e:
        result["success"] = False
        result["error"] = str(e)
        return result

    # "always" — persist the preference
    if persist is True:
        config.nspec_meta.skills_auto_update = True
        config.save()
        result["skills_auto_update"] = True

    return result


def _sync_skills(config: Any, project_root: Path) -> dict[str, int]:
    """Run skills install + agent sync."""
    from nspec.skills import install_skills, resolve_skills, sync_to_agents

    resolved = resolve_skills(config.skills.sources, project_root=project_root)
    installed = install_skills(project_root, resolved)
    synced_agents = sync_to_agents(project_root, targets=config.skills.targets)
    return {
        "skills_installed": len(installed),
        "skills_agent_synced": len(synced_agents),
    }


def _sync_artifacts(config: Any, project_root: Path) -> None:
    """Sync template-based managed artifacts."""
    from nspec.artifacts import ArtifactManifest

    manifest = ArtifactManifest.load(project_root)
    if not manifest.artifacts:
        return

    # Build template variables for interpolation
    try:
        spec_root = config.resolve_spec_root()
        docs_rel = str(spec_root.relative_to(project_root))
    except (ValueError, AttributeError):
        docs_rel = "docs"

    epic_id = config.defaults.epic or "001"
    variables = {
        "project_name": project_root.name,
        "docs_root": docs_rel,
        "epic_id": epic_id,
        "feature_requests": config.paths.feature_requests,
        "implementation": config.paths.implementation,
        "completed": config.paths.completed,
        "test_command": "make test-quick",
        "lint_command": "make lint",
        "format_command": "make format",
        "check_command": "make check",
        "commit_format": "feat(scope): description",
    }

    current_contents: dict[str, str] = {}
    for artifact in manifest.artifacts:
        if not artifact.managed or artifact.source != "template":
            continue
        try:
            from nspec.resources import load_template

            raw = load_template(artifact.id)
            # Simple variable interpolation
            content = raw
            for key, value in variables.items():
                content = content.replace(f"{{{{{key}}}}}", str(value))
            current_contents[artifact.id] = content
        except (ValueError, FileNotFoundError):
            pass

    if current_contents:
        manifest.sync(project_root, current_contents=current_contents)
