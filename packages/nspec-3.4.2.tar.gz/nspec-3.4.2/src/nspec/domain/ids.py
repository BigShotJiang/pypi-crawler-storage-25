"""Spec/Epic ID parsing and normalization.

nspec uses prefixed IDs:
  - Epics: E### (e.g. E001)
  - Specs: S### (e.g. S118)

Both may optionally include a single letter suffix (e.g. S100a) for splits.

Bare numbers (e.g. "007", "22") are also accepted and resolved against
known IDs when a ``known_ids`` set is provided.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

SPEC_REF_RE = re.compile(r"^(?P<prefix>[ES])(?P<number>\d{3})(?P<suffix>[a-z]?)$", re.IGNORECASE)
BARE_NUMBER_RE = re.compile(r"^(?P<number>\d{1,3})(?P<suffix>[a-z]?)$")


@dataclass(frozen=True)
class SpecRef:
    prefix: str  # "E" or "S"
    number: int  # 0-999 (stored as int, rendered as 3 digits)
    suffix: str = ""  # optional single letter, lowercase

    def __post_init__(self) -> None:
        prefix = self.prefix.upper()
        if prefix not in {"E", "S"}:
            raise ValueError(f"Invalid spec ref prefix: {self.prefix!r}")
        if not (0 <= self.number <= 999):
            raise ValueError(f"Invalid spec ref number: {self.number!r}")
        if self.suffix and (len(self.suffix) != 1 or not self.suffix.isalpha()):
            raise ValueError(f"Invalid spec ref suffix: {self.suffix!r}")
        object.__setattr__(self, "prefix", prefix)
        object.__setattr__(self, "suffix", self.suffix.lower())

    @property
    def text(self) -> str:
        return f"{self.prefix}{self.number:03d}{self.suffix}"

    @property
    def is_epic(self) -> bool:
        return self.prefix == "E"


def parse_spec_ref(raw: str) -> SpecRef:
    """Parse a prefixed ID like 'S004' or 'E001' (optionally with a suffix, e.g. 'S100a')."""
    value = (raw or "").strip()
    match = SPEC_REF_RE.match(value)
    if not match:
        raise ValueError(f"Invalid spec ref: {raw!r} (expected E### or S###, optional suffix)")
    prefix = match.group("prefix").upper()
    number = int(match.group("number"))
    suffix = match.group("suffix") or ""
    return SpecRef(prefix=prefix, number=number, suffix=suffix)


def parse_bare_number(raw: str) -> tuple[int, str] | None:
    """Parse a bare number like '007', '22', or '7a'.

    Returns (number, suffix) tuple if valid, None otherwise.
    """
    value = (raw or "").strip()
    match = BARE_NUMBER_RE.match(value)
    if not match:
        return None
    return int(match.group("number")), match.group("suffix") or ""


def normalize_spec_ref(raw: str) -> str:
    """Normalize to canonical 'E###'/'S###' (+ optional lowercase suffix)."""
    return parse_spec_ref(raw).text


def resolve_fuzzy_id(raw: str, known_ids: set[str]) -> str:
    """Resolve a fuzzy ID reference against known spec/epic IDs.

    Accepts:
      - Prefixed IDs: "S022", "E007", "s22", "e7" → normalized form
      - Bare numbers: "022", "22", "7" → looks up S### and E### in known_ids

    Raises ValueError if the ID is ambiguous (matches both S### and E###)
    or not found in known_ids.
    """
    value = (raw or "").strip()

    # Try prefixed first — always wins, no lookup needed
    try:
        return parse_spec_ref(value).text
    except ValueError:
        pass

    # Try bare number
    parsed = parse_bare_number(value)
    if parsed is None:
        raise ValueError(f"Invalid spec ref: {raw!r} (expected E###, S###, or bare number)")

    number, suffix = parsed
    s_candidate = f"S{number:03d}{suffix}"
    e_candidate = f"E{number:03d}{suffix}"

    s_found = s_candidate in known_ids
    e_found = e_candidate in known_ids

    if s_found and e_found:
        raise ValueError(
            f"Ambiguous ID {raw!r}: matches both {s_candidate} and {e_candidate}. "
            f"Use the full ID to disambiguate."
        )
    if s_found:
        return s_candidate
    if e_found:
        return e_candidate

    raise ValueError(f"No spec or epic found for {raw!r} (tried {s_candidate} and {e_candidate})")


def spec_ref_number(raw: str) -> int:
    """Extract numeric portion from a normalized ref."""
    return parse_spec_ref(raw).number


def is_retired_file(name: str) -> bool:
    """True for files renamed by repair-collisions (RETIRED suffix)."""
    return "-RETIRED-" in name


def is_template_file(name: str) -> bool:
    """True for FR/IMPL template placeholder files."""
    stem = name.rsplit(".", 1)[0] if "." in name else name
    return stem.upper() == "TEMPLATE"


def should_skip_spec_file(name: str) -> bool:
    """True for files that should be excluded from spec loading."""
    return is_retired_file(name) or is_template_file(name)
