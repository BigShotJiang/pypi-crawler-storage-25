"""Domain models and parsing for nspec.

Submodules:
    ids        — Spec ID parsing and normalization
    tasks      — Task and acceptance-criteria parsing for progress tracking
    statuses   — FR/IMPL status codes, priority levels, state validation
    datasets   — FR/IMPL dataset loading and metadata
    ordering   — Spec ordering and epic dependency resolution
    loe        — Level-of-effort estimation
    spec_types — Pluggable spec format types and registry
"""

from nspec.domain.datasets import DatasetLoader, DatasetStats, NspecDatasets
from nspec.domain.ids import (
    SpecRef,
    normalize_spec_ref,
    parse_bare_number,
    parse_spec_ref,
    resolve_fuzzy_id,
    spec_ref_number,
)
from nspec.domain.loe import LoeEstimate, LoeWeights, estimate_spec_loe
from nspec.domain.ordering import eligible_next_specs, ordered_specs, spec_to_epic_map
from nspec.domain.statuses import (
    FRStatus,
    FRStatusCode,
    IMPLStatus,
    IMPLStatusCode,
    Priority,
    configure,
    is_active_status,
    is_completed_status,
    parse_status_text,
)
from nspec.domain.tasks import (
    AcceptanceCriteria,
    AcceptanceCriteriaParser,
    Task,
    TaskParser,
)

__all__ = [
    # ids
    "SpecRef",
    "normalize_spec_ref",
    "parse_bare_number",
    "parse_spec_ref",
    "resolve_fuzzy_id",
    "spec_ref_number",
    # tasks
    "AcceptanceCriteria",
    "AcceptanceCriteriaParser",
    "Task",
    "TaskParser",
    # statuses
    "FRStatus",
    "FRStatusCode",
    "IMPLStatus",
    "IMPLStatusCode",
    "Priority",
    "configure",
    "is_active_status",
    "is_completed_status",
    "parse_status_text",
    # datasets
    "DatasetLoader",
    "DatasetStats",
    "NspecDatasets",
    # ordering
    "eligible_next_specs",
    "ordered_specs",
    "spec_to_epic_map",
    # loe
    "LoeEstimate",
    "LoeWeights",
    "estimate_spec_loe",
]
