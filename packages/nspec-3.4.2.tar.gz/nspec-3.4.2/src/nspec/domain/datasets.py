"""Dataset architecture for fRIMPL validation - Layer 2.

This module provides the four-dataset architecture that separates:
    - Active FRs (configurable, default: docs/frs/active/)
    - Active IMPLs (configurable, default: docs/impls/active/)
    - Completed FRs (configurable, default: docs/completed/done/)
    - Completed IMPLs (configurable, default: docs/completed/done/)

Directory paths are configurable via .novabuilt.dev/nspec/config.toml, environment variables,
or programmatically. See nspec.paths module for configuration details.

Each dataset is loaded with strict validation (Layer 1) before being
made available for cross-document validation (Layers 3-6).

Architecture:
    NspecDatasets - Container for all four datasets
    DatasetLoader - Loads and validates all documents
"""

from __future__ import annotations

import logging
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from nspec.paths import NspecPaths, get_paths
from nspec.validation.validators import (
    FRMetadata,
    FRValidator,
    IMPLMetadata,
    IMPLValidator,
)

if TYPE_CHECKING:
    from nspec.domain.spec_types import SpecTypeRegistry

logger = logging.getLogger("nspec")

# ---------------------------------------------------------------------------
# DatasetLoader TTL cache (S926)
# ---------------------------------------------------------------------------
# Keyed by resolved docs_root path string → (monotonic timestamp, datasets).
# Short TTL (2s default) deduplicates within a single MCP request while
# ensuring mutations are never stale across requests.
_dataset_cache: dict[str, tuple[float, NspecDatasets]] = {}
_DATASET_CACHE_TTL: float = 2.0  # seconds


def invalidate_dataset_cache(docs_root: Path | None = None) -> None:
    """Clear the DatasetLoader TTL cache.

    Call after any mutation that writes FR or IMPL files to ensure the
    next ``DatasetLoader.load()`` re-reads from disk.

    Args:
        docs_root: Clear only this root's entry. When None, clears all entries.
    """
    if docs_root is not None:
        key = str(docs_root.resolve())
        _dataset_cache.pop(key, None)
    else:
        _dataset_cache.clear()


@contextmanager
def dataset_cache_scope(docs_root: Path | None = None) -> Iterator[None]:
    """Context manager providing a consistent dataset snapshot within a scope.

    On enter, sets the cache TTL effectively to infinity so all ``load()``
    calls within the scope share one snapshot. On exit, invalidates the
    cache to ensure subsequent reads see fresh data.

    Usage::

        with dataset_cache_scope(docs_root):
            ds1 = DatasetLoader(docs_root).load()
            ds2 = DatasetLoader(docs_root).load()
            assert ds1 is ds2  # guaranteed same object

    Args:
        docs_root: Scope to this root. When None, affects all roots.
    """
    global _DATASET_CACHE_TTL
    original_ttl = _DATASET_CACHE_TTL
    _DATASET_CACHE_TTL = 86400.0  # 24 hours — effectively infinite for a scope
    try:
        yield
    finally:
        _DATASET_CACHE_TTL = original_ttl
        invalidate_dataset_cache(docs_root)


class SpecIdCollisionError(ValueError):
    """Raised when a lookup hits a spec ID that exists in multiple locations.

    S384: callers (especially MCP tools) catch this specifically to return
    a structured error with the colliding paths and a remediation hint
    instead of the bare ValueError message.
    """

    def __init__(
        self,
        spec_id: str,
        label: str,
        sources: list[tuple[str, Path]],
    ) -> None:
        self.spec_id = spec_id
        self.label = label
        self.sources = sources
        sources_str = "\n".join(f"  - {loc}: {p}" for loc, p in sources)
        super().__init__(
            f"Spec ID {spec_id!r} ({label}) is ambiguous — found in multiple "
            f"locations:\n{sources_str}\n"
            f"Resolve via `nspec repair-collisions` or rename one of the files."
        )


@dataclass
class NspecDatasets:
    """Four datasets representing complete fRIMPL state.

    This separates active work (in progress) from completed work,
    and separates feature specs (FR) from implementation plans (IMPL).

    Design rationale:
        - Active vs Completed: Different validation rules apply
        - FR vs IMPL: Different document types, different purposes
        - Clean separation enables efficient querying and validation
    """

    active_frs: dict[str, FRMetadata]  # Spec ID → FR metadata
    active_impls: dict[str, IMPLMetadata]  # Spec ID → IMPL metadata
    completed_frs: dict[str, FRMetadata]  # Spec ID → FR metadata
    completed_impls: dict[str, IMPLMetadata]  # Spec ID → IMPL metadata
    # S909: cross-directory ID collisions detected at load time.
    # spec_id → list of (label, path) pairs for every place the ID appears.
    # Lookups (get_fr/get_impl) raise on collision instead of silently
    # picking active-wins (no silent fallbacks per CLAUDE.md rule 3).
    fr_collisions: dict[str, list[tuple[str, Path]]] = field(default_factory=dict)
    impl_collisions: dict[str, list[tuple[str, Path]]] = field(default_factory=dict)
    # S909: archive-only collisions (same ID in completed/done AND
    # completed/superseded with different stems). These are real ID
    # collisions reported by `nspec validate` (AC-F3), but lookups do NOT
    # raise — both files are archived, so the "done version wins" tie-break
    # preserves dep-resolution. Use this dict to surface them in validate.
    fr_archive_collisions: dict[str, list[tuple[str, Path]]] = field(default_factory=dict)
    impl_archive_collisions: dict[str, list[tuple[str, Path]]] = field(default_factory=dict)
    # S929: per-file parse errors collected during loading. Files that fail
    # validation are skipped (graceful degradation) and their errors are
    # stored here so the TUI/CLI can surface them without blocking the
    # entire backlog from loading.
    parse_errors: list[tuple[str, Path, str]] = field(default_factory=list)
    # Each entry is (label, path, error_message) where label is "FR" or "IMPL".

    def all_spec_ids(self) -> set[str]:
        """Get all spec IDs across all datasets.

        Returns:
            Set of spec IDs (both active and completed)
        """
        return set(self.active_frs.keys()) | set(self.completed_frs.keys())

    def _raise_on_collision(
        self,
        spec_id: str,
        collisions: dict[str, list[tuple[str, Path]]],
        label: str,
    ) -> None:
        """Fail loud when a lookup hits a colliding spec ID. S909/S384."""
        if spec_id not in collisions:
            return
        raise SpecIdCollisionError(spec_id, label, collisions[spec_id])

    def get_fr(self, spec_id: str) -> FRMetadata | None:
        """Get FR from active or completed datasets.

        Raises ValueError if the spec ID is ambiguous (S909) — present in
        both active and completed with different filename stems. Legitimate
        supersessions (same stem) are not collisions and resolve normally.

        Args:
            spec_id: ID like "S001" or "E007"

        Returns:
            FRMetadata if found, None otherwise
        """
        self._raise_on_collision(spec_id, self.fr_collisions, "FR")
        return self.active_frs.get(spec_id) or self.completed_frs.get(spec_id)

    def get_impl(self, spec_id: str) -> IMPLMetadata | None:
        """Get IMPL from active or completed datasets.

        Raises ValueError if the spec ID is ambiguous (S909).

        Args:
            spec_id: ID like "S001" or "E007"

        Returns:
            IMPLMetadata if found, None otherwise
        """
        self._raise_on_collision(spec_id, self.impl_collisions, "IMPL")
        return self.active_impls.get(spec_id) or self.completed_impls.get(spec_id)

    def is_active(self, spec_id: str) -> bool:
        """Check if spec is in active datasets.

        Args:
            spec_id: Spec ID to check

        Returns:
            True if FR is in active_frs
        """
        return spec_id in self.active_frs

    def is_completed(self, spec_id: str) -> bool:
        """Check if spec is in completed datasets.

        Args:
            spec_id: Spec ID to check

        Returns:
            True if FR is in completed_frs
        """
        return spec_id in self.completed_frs

    def active_spec_count(self) -> int:
        """Count of active specs."""
        return len(self.active_frs)

    def completed_spec_count(self) -> int:
        """Count of completed specs."""
        return len(self.completed_frs)

    def total_spec_count(self) -> int:
        """Total count of all specs."""
        return len(self.all_spec_ids())

    def get_active_specs(self) -> list[tuple[FRMetadata, IMPLMetadata | None]]:
        """Get all active specs with their FR and IMPL.

        Returns:
            List of (FR, IMPL) tuples, sorted by spec ID
        """
        specs = []
        from nspec.domain.ids import spec_ref_number

        for spec_id, fr in sorted(self.active_frs.items(), key=lambda kv: spec_ref_number(kv[0])):
            impl = self.active_impls.get(spec_id)
            specs.append((fr, impl))
        return specs

    def get_completed_specs(self) -> list[tuple[FRMetadata, IMPLMetadata | None]]:
        """Get all completed specs with their FR and IMPL.

        Returns:
            List of (FR, IMPL) tuples, sorted by spec ID
        """
        specs = []
        from nspec.domain.ids import spec_ref_number

        for spec_id, fr in sorted(
            self.completed_frs.items(), key=lambda kv: spec_ref_number(kv[0])
        ):
            impl = self.completed_impls.get(spec_id)
            specs.append((fr, impl))
        return specs

    def calculate_loe_rollups(self) -> None:
        """Calculate LOE rollups from dependencies for all active specs.

        For each spec with dependencies:
        - calculated_loe_parallel = max of all dep sequential LOEs (longest dep)
        - calculated_loe_sequential = sum of all active dep sequential LOEs
        - effective_loe = calculated value if has deps, else manual value

        This modifies IMPLMetadata objects in place.
        """
        from nspec.validation.validators import _format_hours_to_loe

        for spec_id, fr in self.active_frs.items():
            impl = self.active_impls.get(spec_id)
            if not impl or not fr.deps:
                continue

            # Calculate from active (non-completed) dependencies only
            dep_parallel_total = 0  # Max of deps (parallel execution)
            dep_sequential_total = 0  # Sum of deps (sequential execution)

            for dep_id in fr.deps:
                # Skip completed dependencies - they don't add to remaining work
                if dep_id in self.completed_impls:
                    continue
                if dep_id in self.active_impls:
                    dep_impl = self.active_impls[dep_id]
                    # Use effective_loe_hours which may itself be calculated
                    dep_hours = dep_impl.effective_loe_hours
                    dep_parallel_total = max(dep_parallel_total, dep_hours)
                    dep_sequential_total += dep_hours

            # Store calculated values
            impl.calculated_loe_parallel = dep_parallel_total if dep_parallel_total > 0 else None
            impl.calculated_loe_sequential = (
                dep_sequential_total if dep_sequential_total > 0 else None
            )

            # Set effective LOE: use calculated if deps exist and have LOE, else manual
            if dep_sequential_total > 0:
                if fr.is_epic:
                    # Epics show parallel,sequential format
                    par_str = _format_hours_to_loe(dep_parallel_total)
                    seq_str = _format_hours_to_loe(dep_sequential_total)
                    impl.effective_loe = f"{par_str},{seq_str}"
                    impl.effective_loe_hours = dep_sequential_total
                else:
                    # Regular specs use sequential (sum of deps)
                    impl.effective_loe = _format_hours_to_loe(dep_sequential_total)
                    impl.effective_loe_hours = dep_sequential_total


class DatasetLoader:
    """Load and validate all four fRIMPL datasets.

    This class orchestrates Layer 1 validation (format checking) while
    loading documents into the four datasets. Any format violations
    cause immediate failure - no silent fixes.

    Usage:
        loader = DatasetLoader(docs_root=Path("docs"))
        datasets = loader.load()  # Raises ValueError on any invalid document
    """

    def __init__(
        self,
        docs_root: Path | None = None,
        active_frs_dir: Path | None = None,
        active_impls_dir: Path | None = None,
        completed_frs_dir: Path | None = None,
        completed_impls_dir: Path | None = None,
        paths_config: NspecPaths | None = None,
        project_root: Path | None = None,
        registry: SpecTypeRegistry | None = None,
    ):
        """Initialize dataset loader.

        Can be initialized in three ways:

        1. Standard mode (production with configuration):
            DatasetLoader(docs_root=Path("docs"))
            Loads paths from .novabuilt.dev/nspec/config.toml (if exists), environment variables,
            or built-in defaults. Directory structure is configurable.

        2. Custom mode (testing with explicit paths):
            DatasetLoader(
                active_frs_dir=Path("tests/nspec/test_case/active-fr"),
                active_impls_dir=Path("tests/nspec/test_case/active-impl"),
                ...
            )
            Allows arbitrary directory paths for black-box testing.

        3. Custom configuration mode:
            DatasetLoader(
                docs_root=Path("docs"),
                paths_config=NspecPaths(feature_requests_dir="specs", ...)
            )
            Uses custom path configuration instead of loading from file/env.

        Args:
            docs_root: Root docs directory (standard mode)
            active_frs_dir: Custom active FR directory (testing mode)
            active_impls_dir: Custom active IMPL directory (testing mode)
            completed_frs_dir: Custom completed FR directory (testing mode)
            completed_impls_dir: Custom completed IMPL directory (testing mode)
            paths_config: Custom paths configuration (overrides file/env config)
            project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
            registry: SpecTypeRegistry for file discovery patterns (default: built-in)
        """
        # S926: Track docs_root for cache key; None in custom mode (no caching).
        self._docs_root = docs_root

        if docs_root:
            # Standard mode - use configuration system
            paths = get_paths(docs_root, config=paths_config, project_root=project_root)
            self.active_frs_dir = paths.active_frs_dir
            self.active_impls_dir = paths.active_impls_dir
            self.completed_frs_dir = paths.completed_frs_dir
            self.completed_impls_dir = paths.completed_impls_dir
            self.superseded_dir = paths.superseded_dir
        else:
            # Custom mode (testing) - use explicitly provided paths
            self.active_frs_dir = active_frs_dir
            self.active_impls_dir = active_impls_dir
            self.completed_frs_dir = completed_frs_dir
            self.completed_impls_dir = completed_impls_dir
            self.superseded_dir = None

        self.registry = registry
        self.fr_validator = FRValidator()
        self.impl_validator = IMPLValidator()

    def _fr_glob_pattern(self) -> str:
        """Derive the FR glob pattern from the registry (or default)."""
        if self.registry:
            prefixes = {
                st.file_pattern.split("-")[0]
                for st in self.registry.all()
                if st.file_pattern.startswith("FR-")
            }
            if prefixes:
                return "FR-*.md"
        return "FR-*.md"

    def _impl_glob_pattern(self) -> str:
        """Derive the IMPL glob pattern from the registry (or default)."""
        if self.registry:
            prefixes = {
                st.file_pattern.split("-")[0]
                for st in self.registry.all()
                if st.file_pattern.startswith("IMPL-")
            }
            if prefixes:
                return "IMPL-*.md"
        return "IMPL-*.md"

    def load(self) -> NspecDatasets:
        """Load all datasets with graceful degradation on parse errors.

        This is Layer 2 validation - each document goes through
        Layer 1 (format validation) before being added to datasets.
        S929: Individual files that fail validation are skipped instead
        of aborting the entire load. Parse errors are collected on the
        returned NspecDatasets for the TUI/CLI to surface.

        S926: When docs_root was provided (standard mode), results are cached
        by resolved path with a short TTL. Multiple calls within the window
        return the same NspecDatasets object without re-reading disk.

        Returns:
            NspecDatasets with all four datasets populated (valid files only)
        """
        # S926: Check TTL cache for standard-mode loaders
        cache_key: str | None = None
        if self._docs_root is not None:
            cache_key = str(self._docs_root.resolve())
            now = time.monotonic()
            if cache_key in _dataset_cache:
                cached_time, cached_datasets = _dataset_cache[cache_key]
                if (now - cached_time) < _DATASET_CACHE_TTL:
                    logger.debug(
                        "DatasetLoader: cache hit for %s (age %.1fs)",
                        cache_key,
                        now - cached_time,
                    )
                    return cached_datasets
                # Expired — remove stale entry
                del _dataset_cache[cache_key]

        # S929: Collect all parse errors across all directories
        all_parse_errors: list[tuple[str, Path, str]] = []

        if self.active_frs_dir:
            active_frs, errs = self._load_frs(self.active_frs_dir, require_completed=False)
            all_parse_errors.extend(errs)
        else:
            active_frs = {}

        if self.active_impls_dir:
            active_impls, errs = self._load_impls(self.active_impls_dir, require_completed=False)
            all_parse_errors.extend(errs)
        else:
            active_impls = {}

        if self.completed_frs_dir:
            completed_frs, errs = self._load_frs(self.completed_frs_dir, require_completed=True)
            all_parse_errors.extend(errs)
        else:
            completed_frs = {}

        if self.completed_impls_dir:
            completed_impls, errs = self._load_impls(
                self.completed_impls_dir, require_completed=True
            )
            all_parse_errors.extend(errs)
        else:
            completed_impls = {}

        # Also load superseded specs - they count as "completed" for dependency purposes.
        # S909: capture done-vs-superseded collisions BEFORE merging so they
        # are not silently overwritten by dict.update().
        superseded_frs: dict[str, FRMetadata] = {}
        superseded_impls: dict[str, IMPLMetadata] = {}
        done_vs_superseded_fr: dict[str, list[tuple[str, Path]]] = {}
        done_vs_superseded_impl: dict[str, list[tuple[str, Path]]] = {}
        if self.superseded_dir and self.superseded_dir.exists():
            superseded_frs, errs = self._load_frs(
                self.superseded_dir, require_completed=False, allow_superseded=True
            )
            all_parse_errors.extend(errs)
            superseded_impls, errs = self._load_impls(
                self.superseded_dir, require_completed=False, allow_superseded=True
            )
            all_parse_errors.extend(errs)

            # S909: detect done-vs-superseded collisions before merging
            for spec_id in set(completed_frs.keys()) & set(superseded_frs.keys()):
                done_md = completed_frs[spec_id]
                sup_md = superseded_frs[spec_id]
                if done_md.path.stem == sup_md.path.stem:
                    continue  # Same stem = legitimate history mirror
                done_vs_superseded_fr[spec_id] = [
                    ("completed", done_md.path),
                    ("superseded", sup_md.path),
                ]
            for spec_id in set(completed_impls.keys()) & set(superseded_impls.keys()):
                done_md = completed_impls[spec_id]
                sup_md = superseded_impls[spec_id]
                if done_md.path.stem == sup_md.path.stem:
                    continue
                done_vs_superseded_impl[spec_id] = [
                    ("completed", done_md.path),
                    ("superseded", sup_md.path),
                ]

            # S909: same merge semantics as before (update — superseded wins
            # ties). Done-vs-superseded collisions are already recorded in
            # done_vs_superseded_fr/impl above so the surfacing in validate
            # is independent of which dict-merge winner is used here.
            completed_frs.update(superseded_frs)
            completed_impls.update(superseded_impls)

        # S909: Cross-directory duplicate detection is now per-spec, not
        # global. Real collisions are recorded on the dataset; lookups for
        # those specific IDs raise. Operations on non-colliding IDs work
        # unchanged. Legitimate supersessions (same filename stem) are not
        # collisions at all.
        fr_collisions = self._collect_cross_directory_collisions(active_frs, completed_frs, "FR")
        impl_collisions = self._collect_cross_directory_collisions(
            active_impls, completed_impls, "IMPL"
        )

        # Merge done-vs-superseded into raise-on-lookup collisions only when
        # the ID also collides with the active dir (3-way collision). When
        # both files are archived (no active), keep them in archive-only —
        # lookups still resolve via dep-resolution (done wins) but
        # `nspec validate` will surface them as errors.
        fr_archive_collisions: dict[str, list[tuple[str, Path]]] = {}
        impl_archive_collisions: dict[str, list[tuple[str, Path]]] = {}
        for spec_id, sources in done_vs_superseded_fr.items():
            if spec_id in fr_collisions:
                existing_paths = {p for _, p in fr_collisions[spec_id]}
                for src in sources:
                    if src[1] not in existing_paths:
                        fr_collisions[spec_id].append(src)
            else:
                fr_archive_collisions[spec_id] = sources
        for spec_id, sources in done_vs_superseded_impl.items():
            if spec_id in impl_collisions:
                existing_paths = {p for _, p in impl_collisions[spec_id]}
                for src in sources:
                    if src[1] not in existing_paths:
                        impl_collisions[spec_id].append(src)
            else:
                impl_archive_collisions[spec_id] = sources
        if fr_collisions or impl_collisions:
            for spec_id, sources in fr_collisions.items():
                logger.warning(
                    "S909: FR %s has %d sources — lookups will raise",
                    spec_id,
                    len(sources),
                )
            for spec_id, sources in impl_collisions.items():
                logger.warning(
                    "S909: IMPL %s has %d sources — lookups will raise",
                    spec_id,
                    len(sources),
                )

        datasets = NspecDatasets(
            active_frs=active_frs,
            active_impls=active_impls,
            completed_frs=completed_frs,
            completed_impls=completed_impls,
            fr_collisions=fr_collisions,
            impl_collisions=impl_collisions,
            fr_archive_collisions=fr_archive_collisions,
            impl_archive_collisions=impl_archive_collisions,
            parse_errors=all_parse_errors,
        )

        # Calculate LOE rollups from dependencies (must be done after all loading)
        datasets.calculate_loe_rollups()

        # S926: Store in cache for standard-mode loaders
        if cache_key is not None:
            _dataset_cache[cache_key] = (time.monotonic(), datasets)

        return datasets

    @staticmethod
    def _collect_cross_directory_collisions(
        active: dict[str, FRMetadata] | dict[str, IMPLMetadata],
        completed: dict[str, FRMetadata] | dict[str, IMPLMetadata],
        label: str,
    ) -> dict[str, list[tuple[str, Path]]]:
        """Find spec IDs present in both active and completed datasets.

        Filters out legitimate supersessions (active and completed files
        share the same filename stem — e.g., the active spec was previously
        archived to ``completed/superseded/`` as part of a normal supersede
        flow). Real collisions (different stems for the same ID, indicating
        a repurposed ID) are returned.

        Returns:
            Dict mapping spec_id → list of (location_label, path) for each
            place the ID appears. Empty dict if no real collisions exist.
        """
        collisions: dict[str, list[tuple[str, Path]]] = {}
        overlap = set(active.keys()) & set(completed.keys())
        for spec_id in overlap:
            active_md = active[spec_id]
            completed_md = completed[spec_id]
            # Legitimate supersession: same stem means it's the same logical
            # spec, just preserved in completed/ for history. Not a collision.
            if active_md.path.stem == completed_md.path.stem:
                continue
            collisions[spec_id] = [
                ("active", active_md.path),
                ("completed", completed_md.path),
            ]
        return collisions

    def _load_frs(
        self,
        directory: Path,
        require_completed: bool = False,
        allow_superseded: bool = False,
    ) -> tuple[dict[str, FRMetadata], list[tuple[str, Path, str]]]:
        """Load and validate all FRs in directory.

        S929: Invalid files are skipped with a warning instead of aborting
        the entire load. Parse errors are returned alongside the valid data.

        Args:
            directory: Directory containing FR-*.md files
            require_completed: If True, enforce all FRs have Completed status
            allow_superseded: If True, allow Superseded status as valid

        Returns:
            Tuple of (frs_dict, parse_errors) where parse_errors is a list
            of (label, path, error_message) tuples for files that failed.
        """
        if not directory or not directory.exists():
            logger.debug("_load_frs: directory missing or None: %s", directory)
            return {}, []

        fr_files = list(directory.glob(self._fr_glob_pattern()))
        logger.debug("_load_frs: %s → %d files found", directory, len(fr_files))

        from nspec.domain.ids import should_skip_spec_file

        frs: dict[str, FRMetadata] = {}
        parse_errors: list[tuple[str, Path, str]] = []
        for path in fr_files:
            if should_skip_spec_file(path.name):
                continue

            try:
                content = path.read_text()
                metadata = self.fr_validator.validate(
                    path,
                    content,
                    require_completed=require_completed,
                    allow_superseded=allow_superseded,
                )
                # Check for duplicate spec IDs (same ID, different slug)
                if metadata.spec_id in frs:
                    existing = frs[metadata.spec_id]
                    msg = (
                        f"Duplicate spec ID {metadata.spec_id} detected:\n"
                        f"  - {existing.path.name}\n"
                        f"  - {path.name}\n"
                        f"Each spec ID must be unique. Delete one or renumber."
                    )
                    logger.warning("_load_frs: %s", msg)
                    parse_errors.append(("FR", path, msg))
                    continue
                frs[metadata.spec_id] = metadata
            except ValueError as e:
                error_msg = f"Failed to load FR from {path.relative_to(directory.parent)}:\n{e}"
                logger.warning("_load_frs: skipping %s: %s", path.name, e)
                parse_errors.append(("FR", path, error_msg))
                continue

        if parse_errors:
            logger.warning(
                "_load_frs: %d/%d FRs skipped due to parse errors in %s",
                len(parse_errors),
                len(fr_files),
                directory,
            )
        logger.debug("_load_frs: loaded %d FRs: %s", len(frs), sorted(frs.keys()))
        return frs, parse_errors

    def _load_impls(
        self,
        directory: Path,
        require_completed: bool = False,
        allow_superseded: bool = False,
    ) -> tuple[dict[str, IMPLMetadata], list[tuple[str, Path, str]]]:
        """Load and validate all IMPLs in directory.

        S929: Invalid files are skipped with a warning instead of aborting
        the entire load. Parse errors are returned alongside the valid data.

        Args:
            directory: Directory containing IMPL-*.md files
            require_completed: If True, enforce all IMPLs have Complete status
            allow_superseded: If True, allow Hold status as valid (used for superseded)

        Returns:
            Tuple of (impls_dict, parse_errors) where parse_errors is a list
            of (label, path, error_message) tuples for files that failed.
        """
        if not directory or not directory.exists():
            logger.debug("_load_impls: directory missing or None: %s", directory)
            return {}, []

        impl_files = list(directory.glob(self._impl_glob_pattern()))
        logger.debug("_load_impls: %s → %d files found", directory, len(impl_files))

        from nspec.domain.ids import should_skip_spec_file

        impls: dict[str, IMPLMetadata] = {}
        parse_errors: list[tuple[str, Path, str]] = []
        for path in impl_files:
            if should_skip_spec_file(path.name):
                continue

            try:
                content = path.read_text()
                metadata = self.impl_validator.validate(
                    path,
                    content,
                    require_completed=require_completed,
                    allow_superseded=allow_superseded,
                )
                # Check for duplicate spec IDs (same ID, different slug)
                if metadata.spec_id in impls:
                    existing = impls[metadata.spec_id]
                    msg = (
                        f"Duplicate spec ID {metadata.spec_id} detected:\n"
                        f"  - {existing.path.name}\n"
                        f"  - {path.name}\n"
                        f"Each spec ID must be unique. Delete one or renumber."
                    )
                    logger.warning("_load_impls: %s", msg)
                    parse_errors.append(("IMPL", path, msg))
                    continue
                impls[metadata.spec_id] = metadata
            except ValueError as e:
                error_msg = (
                    f"Failed to load IMPL from {path.relative_to(directory.parent)}:\n{e}"
                )
                logger.warning("_load_impls: skipping %s: %s", path.name, e)
                parse_errors.append(("IMPL", path, error_msg))
                continue

        if parse_errors:
            logger.warning(
                "_load_impls: %d/%d IMPLs skipped due to parse errors in %s",
                len(parse_errors),
                len(impl_files),
                directory,
            )
        logger.debug("_load_impls: loaded %d IMPLs: %s", len(impls), sorted(impls.keys()))
        return impls, parse_errors


# ---------------------------------------------------------------------------
# MainDatasetLoader — reads from git main branch (S304)
# ---------------------------------------------------------------------------

# Module-level SHA cache for MainDatasetLoader
_main_cache: dict[str, NspecDatasets] = {}


class MainDatasetLoader:
    """Load datasets from the main branch via git_reader.

    Reads FR/IMPL content from ``main`` (or ``origin/main``) using
    ``git_reader``, parses through validators, and returns ``NspecDatasets``.
    Results are cached by main commit SHA — invalidated when main moves.

    Falls back to local ``DatasetLoader`` when git is unavailable.

    Usage::

        loader = MainDatasetLoader(docs_root=Path("docs"))
        datasets = loader.load()  # From main branch, cached by SHA
    """

    def __init__(
        self,
        docs_root: Path,
        project_root: Path | None = None,
        *,
        ref: str = "main",
        fallback: bool = True,
    ) -> None:
        self.docs_root = docs_root
        self.project_root = project_root or Path.cwd()
        self.ref = ref
        self.fallback = fallback
        self.fr_validator = FRValidator()
        self.impl_validator = IMPLValidator()

    def _resolve_sha(self) -> str:
        """Resolve the current SHA of the configured ref."""
        import subprocess

        result = subprocess.run(
            ["git", "rev-parse", self.ref],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(self.project_root),
        )
        if result.returncode != 0:
            raise RuntimeError(f"Cannot resolve ref {self.ref!r}: {result.stderr.strip()}")
        return result.stdout.strip()

    def _docs_rel(self) -> str:
        """Compute docs_root relative to project_root for git_reader."""
        try:
            return str(self.docs_root.resolve().relative_to(self.project_root.resolve()))
        except ValueError:
            return "docs"

    def _load_frs_from_ref(
        self,
        docs_path: str,
        *,
        require_completed: bool = False,
        allow_superseded: bool = False,
    ) -> dict[str, FRMetadata]:
        """Load FRs from a directory path within the git ref.

        Best-effort: individual files that fail validation are skipped
        with a warning. This is intentional — main may contain in-flight
        PRs with partially-valid docs. The summary log at the end reports
        how many files were skipped.
        """
        from nspec.git_reader import FileNotFoundInRefError, list_spec_files, read_spec_content

        try:
            files = list_spec_files(self.ref, docs_path, "FR-*.md", cwd=str(self.project_root))
        except FileNotFoundInRefError:
            return {}

        frs: dict[str, FRMetadata] = {}
        skipped = 0
        for file_path in files:
            filename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path
            if filename.upper().startswith("TEMPLATE"):
                continue
            try:
                content = read_spec_content(self.ref, file_path, cwd=str(self.project_root))
                path_obj = Path(filename)
                metadata = self.fr_validator.validate(
                    path_obj,
                    content,
                    require_completed=require_completed,
                    allow_superseded=allow_superseded,
                )
                if metadata.spec_id in frs:
                    logger.warning(
                        "MainDatasetLoader: duplicate FR ID %s (%s), keeping first",
                        metadata.spec_id,
                        filename,
                    )
                else:
                    frs[metadata.spec_id] = metadata
            except ValueError as e:
                logger.warning("MainDatasetLoader: skipping FR %s: %s", filename, e)
                skipped += 1
                continue
        if skipped:
            logger.warning(
                "MainDatasetLoader: %d/%d FRs skipped in %s",
                skipped,
                len(files),
                docs_path,
            )
        return frs

    def _load_impls_from_ref(
        self,
        docs_path: str,
        *,
        require_completed: bool = False,
        allow_superseded: bool = False,
    ) -> dict[str, IMPLMetadata]:
        """Load IMPLs from a directory path within the git ref.

        Best-effort: individual files that fail validation are skipped.
        See ``_load_frs_from_ref`` docstring for rationale.
        """
        from nspec.git_reader import FileNotFoundInRefError, list_spec_files, read_spec_content

        try:
            files = list_spec_files(self.ref, docs_path, "IMPL-*.md", cwd=str(self.project_root))
        except FileNotFoundInRefError:
            return {}

        impls: dict[str, IMPLMetadata] = {}
        skipped = 0
        for file_path in files:
            filename = file_path.rsplit("/", 1)[-1] if "/" in file_path else file_path
            if filename.upper().startswith("TEMPLATE"):
                continue
            try:
                content = read_spec_content(self.ref, file_path, cwd=str(self.project_root))
                path_obj = Path(filename)
                metadata = self.impl_validator.validate(
                    path_obj,
                    content,
                    require_completed=require_completed,
                    allow_superseded=allow_superseded,
                )
                if metadata.spec_id in impls:
                    logger.warning(
                        "MainDatasetLoader: duplicate IMPL ID %s (%s), keeping first",
                        metadata.spec_id,
                        filename,
                    )
                else:
                    impls[metadata.spec_id] = metadata
            except ValueError as e:
                logger.warning("MainDatasetLoader: skipping IMPL %s: %s", filename, e)
                skipped += 1
                continue
        if skipped:
            logger.warning(
                "MainDatasetLoader: %d/%d IMPLs skipped in %s",
                skipped,
                len(files),
                docs_path,
            )
        return impls

    def load(self) -> NspecDatasets:
        """Load datasets from the main branch.

        Caches by commit SHA — returns cached datasets if main hasn't moved.
        Falls back to local ``DatasetLoader`` on git failures when fallback is enabled.

        Returns:
            NspecDatasets from main branch (or local fallback).
        """
        from nspec.git_reader import GitReaderError

        try:
            return self._load_from_ref()
        except (RuntimeError, GitReaderError, OSError) as e:
            if self.fallback:
                logger.warning("MainDatasetLoader: falling back to local: %s", e)
                local = DatasetLoader(
                    docs_root=self.docs_root,
                    project_root=self.project_root,
                )
                return local.load()
            raise

    def _cache_key(self, sha: str) -> str:
        """Build a cache key from SHA + roots to avoid cross-context collisions."""
        docs = str(self.docs_root.resolve())
        proj = str(self.project_root.resolve())
        return f"{sha}:{docs}:{proj}"

    def _load_from_ref(self) -> NspecDatasets:
        """Load from the git ref, using SHA cache."""
        sha = self._resolve_sha()
        key = self._cache_key(sha)

        # Check cache
        if key in _main_cache:
            logger.debug("MainDatasetLoader: cache hit for %s (%s)", self.ref, sha[:8])
            return _main_cache[key]

        logger.debug("MainDatasetLoader: loading from %s (%s)", self.ref, sha[:8])

        resolved = get_paths(self.docs_root, project_root=self.project_root)
        cfg = resolved.config
        docs_rel = self._docs_rel()

        # Build relative directory paths for git_reader using config strings
        active_frs_rel = f"{docs_rel}/{cfg.feature_requests_dir}"
        active_impls_rel = f"{docs_rel}/{cfg.implementation_dir}"
        completed_rel = f"{docs_rel}/{cfg.completed_dir}/{cfg.completed_done_subdir}"
        superseded_rel = f"{docs_rel}/{cfg.completed_dir}/{cfg.completed_superseded_subdir}"

        active_frs = self._load_frs_from_ref(active_frs_rel)
        active_impls = self._load_impls_from_ref(active_impls_rel)
        completed_frs = self._load_frs_from_ref(completed_rel, require_completed=True)
        completed_impls = self._load_impls_from_ref(completed_rel, require_completed=True)

        # Superseded
        superseded_frs = self._load_frs_from_ref(superseded_rel, allow_superseded=True)
        superseded_impls = self._load_impls_from_ref(superseded_rel, allow_superseded=True)
        completed_frs.update(superseded_frs)
        completed_impls.update(superseded_impls)

        datasets = NspecDatasets(
            active_frs=active_frs,
            active_impls=active_impls,
            completed_frs=completed_frs,
            completed_impls=completed_impls,
        )
        datasets.calculate_loe_rollups()

        # Cache by key (SHA + roots)
        _main_cache[key] = datasets
        return datasets


def clear_main_cache() -> None:
    """Clear the MainDatasetLoader SHA cache (for testing)."""
    _main_cache.clear()


class DatasetStats:
    """Compute statistics across datasets.

    Useful for reporting and dashboard generation.
    """

    def __init__(self, datasets: NspecDatasets):
        """Initialize with datasets."""
        self.datasets = datasets

    def priority_breakdown(self) -> dict[str, int]:
        """Count active specs by priority.

        Returns:
            Dict like {"P0": 3, "P1": 15, "P2": 25, "P3": 5}
        """
        from nspec.domain.statuses import SPEC_PRIORITIES

        breakdown = {pcode: 0 for pcode in SPEC_PRIORITIES}
        for fr in self.datasets.active_frs.values():
            if fr.priority in breakdown:
                breakdown[fr.priority] += 1
            else:
                breakdown[fr.priority] = 1
        return breakdown

    def status_breakdown(self) -> dict[str, int]:
        """Count active specs by status.

        Returns:
            Dict like {"🟡 Proposed": 20, "🟢 In Progress": 15, ...}
        """
        breakdown: dict[str, int] = {}
        for fr in self.datasets.active_frs.values():
            breakdown[fr.status] = breakdown.get(fr.status, 0) + 1
        return breakdown

    def overall_progress(self) -> dict[str, float]:
        """Calculate overall progress across all active specs.

        Returns:
            Dict with:
                - ac_completion: Average AC completion %
                - task_completion: Average task completion %
                - overall_completion: Combined average
        """
        if not self.datasets.active_frs:
            return {
                "ac_completion": 0.0,
                "task_completion": 0.0,
                "overall_completion": 0.0,
            }

        total_ac_completion = 0
        total_task_completion = 0
        spec_count = 0

        for spec_id, fr in self.datasets.active_frs.items():
            impl = self.datasets.active_impls.get(spec_id)

            total_ac_completion += fr.ac_completion_percent
            total_task_completion += impl.completion_percent if impl else 0
            spec_count += 1

        ac_avg = total_ac_completion / spec_count if spec_count > 0 else 0
        task_avg = total_task_completion / spec_count if spec_count > 0 else 0
        overall_avg = (ac_avg + task_avg) / 2

        return {
            "ac_completion": round(ac_avg, 1),
            "task_completion": round(task_avg, 1),
            "overall_completion": round(overall_avg, 1),
        }

    def dependency_graph(self) -> dict[str, list[str]]:
        """Build dependency graph for active specs.

        Returns:
            Dict mapping spec ID to list of dependency IDs
        """
        graph = {}
        for spec_id, fr in self.datasets.active_frs.items():
            graph[spec_id] = fr.deps
        return graph

    def specs_without_progress(self) -> list[str]:
        """Find active specs with 0% completion (no AC or tasks done).

        Returns:
            List of spec IDs
        """
        zero_progress = []
        for spec_id, fr in self.datasets.active_frs.items():
            impl = self.datasets.active_impls.get(spec_id)

            ac_done = fr.ac_completion_percent == 0
            tasks_done = (impl.completion_percent == 0) if impl else True

            if ac_done and tasks_done:
                zero_progress.append(spec_id)

        return sorted(zero_progress)

    def specs_near_completion(self, threshold: int = 80) -> list[str]:
        """Find active specs near completion.

        Args:
            threshold: Completion percentage threshold (default 80%)

        Returns:
            List of spec IDs with completion >= threshold
        """
        near_complete = []
        for spec_id, fr in self.datasets.active_frs.items():
            impl = self.datasets.active_impls.get(spec_id)

            if not impl:
                continue

            # Average of AC and task completion
            overall = (fr.ac_completion_percent + impl.completion_percent) / 2

            if overall >= threshold:
                near_complete.append(spec_id)

        return sorted(near_complete)
