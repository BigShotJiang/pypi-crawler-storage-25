"""Lifecycle hints — phase-aware ``next_steps`` for MCP tool responses.

Maps nspec lifecycle transitions (activate, task_complete, criteria_complete,
advance, spec_tests, review) to structured guidance that MCP clients read
instead of memorizing per-phase prose in the /ngo skill.

Every resolver returns an optional :class:`PhaseHint` that the MCP tool
wrapper serializes via :func:`serialize` and merges under the ``next_steps``
key of its response dict. Returning ``None`` signals "no hint" — the wrapper
then omits the key entirely.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nspec.domain.statuses import IMPLStatusCode


@dataclass
class ActionHint:
    """A single suggested next action.

    ``kind`` is ``"mcp"`` for an nspec MCP call or ``"shell"`` for a shell
    command. ``tool`` is the tool or command name, ``args`` its arguments
    (kwargs for MCP, positional for shell), and ``description`` a short
    human explanation.
    """

    kind: str
    tool: str
    description: str
    args: dict[str, Any] = field(default_factory=dict)


@dataclass
class PhaseHint:
    """Phase-aware guidance attached to a phase-transitioning tool response."""

    phase: str
    summary: str
    actions: list[ActionHint] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def serialize(hint: PhaseHint | None) -> dict[str, Any] | None:
    """Serialize a :class:`PhaseHint` to the canonical JSON shape."""
    if hint is None:
        return None
    return {
        "phase": hint.phase,
        "summary": hint.summary,
        "actions": [
            {
                "kind": a.kind,
                "tool": a.tool,
                "args": dict(a.args),
                "description": a.description,
            }
            for a in hint.actions
        ],
    }


# ---------------------------------------------------------------------------
# Resolvers
# ---------------------------------------------------------------------------


def hint_for_activate(spec_id: str) -> PhaseHint:
    """Emitted after ``activate`` succeeds.

    The freshly activated spec is now IMPL=Active; the caller should start
    executing tasks (after FR/IMPL refinement if either is a skeleton —
    that detection lives in ``refine_fr`` / ``refine_impl``, not here).
    """
    return PhaseHint(
        phase="execute",
        summary=f"Spec {spec_id} activated — begin executing tasks.",
        actions=[
            ActionHint(
                kind="mcp",
                tool="refine_fr",
                args={"spec_id": spec_id},
                description=(
                    "Check for skeleton FR content; author full FR body if needed "
                    "before proceeding to tasks."
                ),
            ),
            ActionHint(
                kind="mcp",
                tool="refine_impl",
                args={"spec_id": spec_id},
                description=(
                    "Check for skeleton IMPL tasks; refine into concrete tasks before execution."
                ),
            ),
            ActionHint(
                kind="mcp",
                tool="task_complete",
                args={"spec_id": spec_id, "task_id": "<next_task_id>"},
                description="Mark each task complete as it is finished.",
            ),
        ],
    )


def hint_for_task_complete(
    spec_id: str,
    done: int,
    total: int,
) -> PhaseHint | None:
    """Emitted after ``task_complete`` succeeds.

    When the completed task was the final one, returns a terminal-condition
    hint pointing at ``criteria_complete`` and then ``advance``. Otherwise
    returns an incremental hint nudging the caller to the next task.
    """
    if total <= 0:
        return None
    if done == total:
        return PhaseHint(
            phase="execute-complete",
            summary=(
                f"All {total} tasks complete for {spec_id}. "
                "Mark any remaining acceptance criteria, then advance to Testing."
            ),
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="criteria_complete",
                    args={"spec_id": spec_id, "criteria_id": "<AC_id>"},
                    description=(
                        "Mark each remaining acceptance criterion (AC-F#, AC-Q#) as satisfied."
                    ),
                ),
                ActionHint(
                    kind="mcp",
                    tool="advance",
                    args={"spec_id": spec_id},
                    description="Advance Active → Testing once all ACs are checked.",
                ),
            ],
        )
    return PhaseHint(
        phase="execute",
        summary=(f"{done}/{total} tasks complete for {spec_id} — continue with the next task."),
        actions=[
            ActionHint(
                kind="mcp",
                tool="task_complete",
                args={"spec_id": spec_id, "task_id": "<next_task_id>"},
                description="Mark the next pending task complete.",
            ),
        ],
    )


def hint_for_criteria_complete(
    spec_id: str,
    done: int,
    total: int,
) -> PhaseHint | None:
    """Emitted after ``criteria_complete`` succeeds.

    When all ACs are satisfied, points at ``advance`` (Active → Testing).
    Otherwise returns ``None`` — per-criterion nudges would be noise.
    """
    if total <= 0:
        return None
    if done == total:
        return PhaseHint(
            phase="execute-complete",
            summary=(
                f"All {total} acceptance criteria satisfied for {spec_id}. Advance to Testing."
            ),
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="advance",
                    args={"spec_id": spec_id},
                    description="Advance Active → Testing.",
                ),
            ],
        )
    return None


def hint_for_advance(
    spec_id: str,
    prev_status: int | None,
    new_status: int | None,
) -> PhaseHint | None:
    """Emitted after ``advance`` succeeds.

    Keyed off IMPL status codes in :class:`IMPLStatusCode`. Returns ``None``
    for no-op transitions so the wrapper omits ``next_steps``.
    """
    if prev_status is None or new_status is None or prev_status == new_status:
        return None

    if new_status == IMPLStatusCode.ACTIVE:
        return PhaseHint(
            phase="execute",
            summary=f"Spec {spec_id} now Active — begin executing tasks.",
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="task_complete",
                    args={"spec_id": spec_id, "task_id": "<next_task_id>"},
                    description="Mark each IMPL task complete as it is finished.",
                ),
            ],
        )
    if new_status == IMPLStatusCode.TESTING:
        return PhaseHint(
            phase="verify",
            summary=f"Entering Verify phase for {spec_id} — run tests.",
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="spec_tests",
                    args={"spec_id": spec_id},
                    description=(
                        "Run targeted tests from task .tests annotations "
                        "(falls back to make test-quick)."
                    ),
                ),
                ActionHint(
                    kind="mcp",
                    tool="criteria_complete",
                    args={"spec_id": spec_id, "criteria_id": "<AC_id>"},
                    description=("Mark each acceptance criterion satisfied after tests pass."),
                ),
            ],
        )
    if new_status == IMPLStatusCode.READY:
        return PhaseHint(
            phase="review",
            summary=(f"Spec {spec_id} Ready — dispatch a mandatory review before complete()."),
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="review",
                    args={"spec_id": spec_id, "base_branch": "main"},
                    description="Dispatch atomic review to the configured review agent.",
                ),
            ],
        )
    return None


def hint_for_spec_tests(
    spec_id: str,
    passed: bool,
    fallback: bool,
) -> PhaseHint | None:
    """Emitted after ``spec_tests`` returns.

    On failure: suggest reading the output and retrying. On fallback (no
    targeted tests found): suggest adding ``.tests`` annotations. On a clean
    pass: point at the Review phase (advance + review).
    """
    if not passed:
        return PhaseHint(
            phase="verify",
            summary=(
                f"Tests failed for {spec_id}. Read the output, fix the issue, "
                "and re-run spec_tests."
            ),
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="spec_tests",
                    args={"spec_id": spec_id},
                    description="Re-run after fixing.",
                ),
            ],
        )
    if fallback:
        return PhaseHint(
            phase="verify",
            summary=(
                f"No targeted tests for {spec_id} — ran make test-quick as fallback. "
                "Consider adding .tests annotations to IMPL tasks so future runs "
                "exercise just the relevant subset."
            ),
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="advance",
                    args={"spec_id": spec_id},
                    description="Advance Testing → Ready once verification is complete.",
                ),
            ],
        )
    return PhaseHint(
        phase="verify-complete",
        summary=f"Tests passed for {spec_id} — advance to Ready and dispatch review.",
        actions=[
            ActionHint(
                kind="mcp",
                tool="advance",
                args={"spec_id": spec_id},
                description="Advance Testing → Ready.",
            ),
            ActionHint(
                kind="mcp",
                tool="review",
                args={"spec_id": spec_id, "base_branch": "main"},
                description="Dispatch the mandatory review.",
            ),
        ],
    )


def hint_for_review(
    spec_id: str,
    verdict: str | None,
) -> PhaseHint | None:
    """Emitted after ``review`` returns.

    APPROVED → point at ``advance`` then ``complete``. NEEDS_WORK → fix findings and retry.
    Any other value (missing, unknown) → return ``None``.
    """
    if verdict is None:
        return None
    v = verdict.upper()
    if v == "APPROVED":
        return PhaseHint(
            phase="complete",
            summary=f"Review APPROVED for {spec_id} — advance to Ready, then archive.",
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="advance",
                    args={"spec_id": spec_id},
                    description="Advance Testing → Ready (S377: verdict no longer auto-advances).",
                ),
                ActionHint(
                    kind="mcp",
                    tool="complete",
                    args={"spec_id": spec_id},
                    description="Archive to completed/done and clear session state.",
                ),
            ],
        )
    if v == "NEEDS_WORK":
        return PhaseHint(
            phase="review",
            summary=(
                f"Review returned NEEDS_WORK for {spec_id}. Address findings, "
                "run tests again, then call review a second time (max 2 retries)."
            ),
            actions=[
                ActionHint(
                    kind="mcp",
                    tool="review",
                    args={"spec_id": spec_id, "base_branch": "main"},
                    description="Re-dispatch review after fixes.",
                ),
            ],
        )
    return None
