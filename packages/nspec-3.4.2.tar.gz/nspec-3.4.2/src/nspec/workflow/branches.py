"""Branch lifecycle management for nspec.

Lists, inspects, and cleans up ``nspec/*`` branches.
Provides branch visibility (ahead/behind main, PR status)
and merged-branch cleanup.
"""

from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("nspec")

NSPEC_BRANCH_PREFIX = "nspec/"
STALE_THRESHOLD = 20  # commits behind main before warning


@dataclass
class BranchInfo:
    """Metadata for a single nspec/* branch."""

    name: str
    spec_id: str | None = None
    ahead: int = 0
    behind: int = 0
    stale: bool = False
    pr_status: str | None = None  # "open", "merged", "closed", None
    pr_url: str | None = None
    pr_number: int | None = None


def _run_git(*args: str, cwd: str | None = None) -> str:
    """Run a git command and return stdout."""
    result = subprocess.run(
        ["git", *args],
        capture_output=True,
        text=True,
        check=False,
        cwd=cwd,
    )
    if result.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def _extract_spec_id(branch_name: str) -> str | None:
    """Extract spec ID (S### or E###) from branch name like nspec/claude-1."""
    # Try patterns: nspec/S123, nspec/claude-1 (no spec ID), nspec/S123-foo
    m = re.search(r"([SE]\d{3,})", branch_name)
    return m.group(1) if m else None


def list_spec_branches(*, cwd: str | None = None) -> list[BranchInfo]:
    """List all nspec/* branches (local + remote tracking).

    Returns a list of ``BranchInfo`` with name and extracted spec ID.
    """
    try:
        raw = _run_git(
            "branch",
            "-a",
            "--list",
            f"*{NSPEC_BRANCH_PREFIX}*",
            "--format=%(refname:short)",
            cwd=cwd,
        )
    except RuntimeError:
        return []

    branches: list[BranchInfo] = []
    seen_names: set[str] = set()
    for line in raw.splitlines():
        name = line.strip()
        if not name:
            continue
        # Normalize remote tracking branches: origin/nspec/foo -> nspec/foo
        short = name.replace("origin/", "") if name.startswith("origin/") else name
        if short in seen_names:
            continue
        seen_names.add(short)
        branches.append(BranchInfo(name=short, spec_id=_extract_spec_id(short)))
    return branches


def compute_ahead_behind(
    branch: str,
    base: str = "main",
    *,
    cwd: str | None = None,
) -> tuple[int, int]:
    """Return (ahead, behind) counts for branch relative to base.

    Uses ``git rev-list --left-right --count base...branch``.
    """
    try:
        raw = _run_git(
            "rev-list",
            "--left-right",
            "--count",
            f"{base}...{branch}",
            cwd=cwd,
        )
    except RuntimeError:
        return 0, 0

    parts = raw.split()
    if len(parts) != 2:
        return 0, 0
    behind = int(parts[0])  # left = base commits not in branch
    ahead = int(parts[1])  # right = branch commits not in base
    return ahead, behind


def get_branch_pr_status(
    branch: str,
    *,
    cwd: str | None = None,
) -> dict[str, Any]:
    """Query GitHub for PR associated with a branch.

    Returns dict with ``status``, ``url``, ``number`` keys.
    """
    if not shutil.which("gh"):
        return {"status": None, "error": "gh CLI not found"}

    try:
        raw = subprocess.run(
            [
                "gh",
                "pr",
                "list",
                "--head",
                branch,
                "--state",
                "all",
                "--json",
                "number,state,url",
                "--limit",
                "1",
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
            cwd=cwd,
        )
        if raw.returncode != 0:
            return {"status": None, "error": raw.stderr.strip()}

        prs = json.loads(raw.stdout) if raw.stdout.strip() else []
        if not prs:
            return {"status": None}

        pr = prs[0]
        return {
            "status": pr.get("state", "").lower(),  # "open", "merged", "closed"
            "url": pr.get("url"),
            "number": pr.get("number"),
        }
    except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as e:
        return {"status": None, "error": str(e)}


def enrich_branches(
    branches: list[BranchInfo],
    *,
    cwd: str | None = None,
) -> list[BranchInfo]:
    """Add ahead/behind counts and PR status to branch list."""
    for branch in branches:
        branch.ahead, branch.behind = compute_ahead_behind(
            branch.name,
            cwd=cwd,
        )
        branch.stale = branch.behind > STALE_THRESHOLD

        pr_info = get_branch_pr_status(branch.name, cwd=cwd)
        branch.pr_status = pr_info.get("status")
        branch.pr_url = pr_info.get("url")
        branch.pr_number = pr_info.get("number")

    return branches


def cleanup_merged_branches(
    *,
    cwd: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Remove nspec/* branches whose PRs have been merged.

    Returns summary with deleted, skipped, and error lists.
    """
    branches = list_spec_branches(cwd=cwd)
    branches = enrich_branches(branches, cwd=cwd)

    deleted: list[str] = []
    skipped: list[dict[str, str]] = []
    errors: list[dict[str, str]] = []

    for branch in branches:
        if branch.pr_status != "merged":
            skipped.append(
                {
                    "branch": branch.name,
                    "reason": f"PR status: {branch.pr_status or 'no PR'}",
                }
            )
            continue

        if dry_run:
            deleted.append(branch.name)
            continue

        try:
            # Try local branch deletion first
            local_deleted = False
            try:
                _run_git("branch", "-D", branch.name, cwd=cwd)
                local_deleted = True
            except RuntimeError:
                pass  # May only exist as remote

            # Delete remote tracking branch
            remote_deleted = False
            try:
                _run_git("push", "origin", "--delete", branch.name, cwd=cwd)
                remote_deleted = True
            except RuntimeError:
                pass  # Remote may already be gone

            if local_deleted or remote_deleted:
                deleted.append(branch.name)
            else:
                errors.append(
                    {
                        "branch": branch.name,
                        "error": "Neither local nor remote branch could be deleted",
                    }
                )
        except Exception as e:
            errors.append({"branch": branch.name, "error": str(e)})

    return {
        "deleted": deleted,
        "skipped": skipped,
        "errors": errors,
        "dry_run": dry_run,
    }


def branch_status_report(*, cwd: str | None = None) -> dict[str, Any]:
    """Full branch status report for MCP tool consumption."""
    branches = list_spec_branches(cwd=cwd)
    if not branches:
        return {"branches": [], "total": 0, "stale_count": 0}

    branches = enrich_branches(branches, cwd=cwd)

    result = []
    stale_count = 0
    for b in branches:
        entry: dict[str, Any] = {
            "branch": b.name,
            "spec_id": b.spec_id,
            "ahead": b.ahead,
            "behind": b.behind,
            "stale": b.stale,
            "pr_status": b.pr_status,
        }
        if b.pr_url:
            entry["pr_url"] = b.pr_url
        if b.pr_number:
            entry["pr_number"] = b.pr_number
        if b.stale:
            stale_count += 1
        result.append(entry)

    return {
        "branches": result,
        "total": len(result),
        "stale_count": stale_count,
    }
