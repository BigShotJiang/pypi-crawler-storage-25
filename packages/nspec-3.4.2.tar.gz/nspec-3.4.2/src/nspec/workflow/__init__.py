"""Workflow subsystem for nspec.

Submodules:
    refine           — FR/IMPL skeleton detection and refinement prompt generation
    review           — Review prompt assembly, token management, verdict parsing
    review_archiver  — Review packet archival
    review_workflow  — End-to-end review workflow orchestration

Import directly from submodules to avoid circular imports:
    from nspec.workflow.review import prepare_mcp_review
    from nspec.workflow.refine import generate_refinement_prompt
    from nspec.workflow.review_archiver import archive_one
    from nspec.workflow.review_workflow import finalize_review_packet_spec
"""
