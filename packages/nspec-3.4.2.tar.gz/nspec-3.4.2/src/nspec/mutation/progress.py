"""Task and acceptance-criteria progress updates."""

import re
from pathlib import Path

from nspec.domain.datasets import invalidate_dataset_cache
from nspec.domain.ids import normalize_spec_ref
from nspec.mutation._helpers import (
    _file_lock,
    _find_impl_file,
    _line_matches_task_id,
    _validate_after_write,
)
from nspec.paths import NspecPaths, get_paths
from nspec.runtime.atomic import spec_write
from nspec.runtime.timestamps import now_iso


def _find_task_by_id(tasks: list, task_id: str) -> object | None:
    """Find a task by ID in a flat or hierarchical task list.

    Searches recursively through children.
    """
    from nspec.domain.tasks import Task

    for task in tasks:
        if not isinstance(task, Task):
            continue
        if task.id == task_id:
            return task
        if task.children:
            found = _find_task_by_id(task.children, task_id)
            if found:
                return found
    return None


def _check_sequential_order(
    spec_id: str,
    task_id: str,
    content: str,
    impl_path: Path,
) -> None:
    """Validate that all prior sibling tasks are complete before this one.

    Sequential ordering is enforced per-phase: tasks in Phase 2 don't
    require Phase 1 tasks to be complete. DoD tasks are exempt.

    Raises:
        ValueError: If a prior sibling task is incomplete.
    """
    from nspec.domain.tasks import TaskParser

    # DoD tasks are exempt from sequential ordering
    if task_id.lower().startswith("dod-"):
        return

    parser = TaskParser()
    root_tasks = parser.parse(content, impl_path)
    target = _find_task_by_id(root_tasks, task_id)
    if target is None:
        return  # Task not found in tree — let the main function handle the error

    siblings = target.get_siblings(root_tasks)

    # Find prior siblings (those that come before target in document order)
    for sibling in siblings:
        if sibling.id == target.id:
            break  # We've reached the target — all prior siblings checked
        if sibling.completed:
            continue  # Done (including [~] obsolete, [>] deferred) — no blocker
        if sibling.blocked:
            raise ValueError(
                f"[{spec_id}] check_impl_task: Task '{task_id}' cannot be completed "
                f"— task '{sibling.id}' is blocked. "
                f"Resolve the blocker on task '{sibling.id}' first."
            )
        raise ValueError(
            f"[{spec_id}] check_impl_task: Task '{task_id}' cannot be completed "
            f"— task '{sibling.id}' is still pending. "
            f"Complete tasks in order: {sibling.id} → {task_id}."
        )


def _check_subtasks_complete(
    spec_id: str,
    task_id: str,
    content: str,
    impl_path: Path,
) -> None:
    """Validate that all subtasks of a parent task are complete.

    A parent task cannot be marked complete until all its children
    are checked ([x] or [~]).

    Raises:
        ValueError: If any child task is incomplete.
    """
    from nspec.domain.tasks import TaskParser

    parser = TaskParser()
    root_tasks = parser.parse(content, impl_path)
    target = _find_task_by_id(root_tasks, task_id)
    if target is None or not target.children:
        return  # No children — gate passes

    incomplete = [child for child in target.children if not child.completed]
    if incomplete:
        ids = ", ".join(child.id for child in incomplete)
        count = len(incomplete)
        total = len(target.children)
        raise ValueError(
            f"[{spec_id}] check_impl_task: Task '{task_id}' cannot be completed "
            f"— {count} of {total} subtasks are incomplete. "
            f"Incomplete: {ids}. Complete all subtasks first."
        )


def _parse_task_file_annotations(
    content: str,
    task_id: str,
) -> list[str]:
    """Extract file paths from File:/Files: annotations below a task checkbox.

    Scans non-checkbox lines following the task's checkbox line until
    the next checkbox or section heading is reached.

    Supports:
        - File: `src/foo.py`
        - Files: `src/foo.py`, `src/bar.py`
        - - File: `src/foo.py`  (bullet variant)

    Returns:
        List of file paths (without backticks), or empty list if none found.
    """
    lines = content.split("\n")
    file_paths: list[str] = []
    found_task = False

    for _i, line in enumerate(lines):
        stripped = line.strip()

        # Find the task's checkbox line
        if not found_task:
            if (
                stripped.startswith("- [ ]")
                or stripped.startswith("- [x]")
                or stripped.startswith("- [~]")
                or stripped.startswith("- [>]")
            ) and _line_matches_task_id(stripped, task_id):
                found_task = True
            continue

        # After finding the task, stop at any next checkbox line or heading.
        # This includes subtask checkboxes, delegated tasks ([→...]), and
        # standard checkboxes — File: annotations belong only to the task
        # immediately above them, not to subsequent tasks or subtasks.
        if stripped.startswith("- ["):
            break  # Next task/subtask/delegated task
        if stripped.startswith("#"):
            break  # Next section

        # Parse File:/Files: annotations
        # Accepted formats include "File: `path`", "- File: `path`", "  - File: `path`"
        file_match = re.match(r"^\s*-?\s*Files?:\s*(.+)$", stripped)
        if file_match:
            raw = file_match.group(1)
            # Skip HTML comment placeholders from templates (e.g. <!-- target file path -->)
            if raw.strip().startswith("<!--"):
                continue
            # Split by comma for Files: plural variant, then extract the
            # first backtick-wrapped path from each part (ignores description
            # text after em-dash that may contain its own backticks)
            for part in raw.split(","):
                part = part.strip()
                m = re.search(r"`([^`]+)`", part)
                if m:
                    path = m.group(1)
                    # Strip ::symbol qualifier (path::symbol → path)
                    if "::" in path:
                        path = path.split("::")[0]
                    # Filter out sentinel values even when backtick-wrapped
                    if path.strip().lower() in ("n/a", "none", "-", ""):
                        continue
                    file_paths.append(path)
                elif part and not part.startswith("—"):
                    # Fallback: no backticks, use plain text
                    path = part
                    if "::" in path:
                        path = path.split("::")[0]
                    # Filter out sentinel values (N/A, None, -, empty)
                    # that indicate verification-only tasks with no file output.
                    # Also handles "N/A (description)" by checking if the path
                    # starts with a sentinel followed by whitespace or parens.
                    stripped_lower = path.strip().lower()
                    if stripped_lower in ("n/a", "none", "-", ""):
                        continue
                    if re.match(r"^(n/a|none|-)\s*(\(|$)", stripped_lower):
                        continue
                    file_paths.append(path)

    return file_paths


def _check_files_modified(
    spec_id: str,
    task_id: str,
    content: str,
    project_root: Path | None = None,
) -> None:
    """Validate that files referenced by the task's annotations are in git diff.

    Checks both staged and unstaged changes. Tasks without File: annotations
    skip this gate entirely.

    Raises:
        ValueError: If referenced files are not found in git diff.
    """
    import subprocess

    file_annotations = _parse_task_file_annotations(content, task_id)
    if not file_annotations:
        return  # No file annotations — gate skipped

    # Get modified files from git
    cwd = project_root or Path.cwd()
    modified_files: set[str] = set()

    # Load subprocess timeout from config
    from nspec.config import NspecConfig

    _cfg = NspecConfig.load(project_root)
    _subprocess_timeout = _cfg.timeouts.subprocess_s

    try:
        # Check if we're in a git repository first
        repo_check = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=_subprocess_timeout,
        )
        if repo_check.returncode != 0:
            return  # Not a git repo — skip gate gracefully

        # S370: Determine git repo root to detect cross-repo file references.
        # File annotations pointing outside the current repo are silently
        # skipped — git diff can only track files within a single repo.
        repo_root_result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=_subprocess_timeout,
        )
        repo_root_str = (
            repo_root_result.stdout.strip()
            if repo_root_result.returncode == 0 and repo_root_result.stdout
            else None
        )

        if repo_root_str:
            repo_root_real = Path(repo_root_str).resolve()
            local_annotations: list[str] = []
            for f in file_annotations:
                resolved = (cwd / f).resolve()
                try:
                    resolved.relative_to(repo_root_real)
                    local_annotations.append(f)
                except ValueError:
                    pass  # cross-repo path — skip git diff check
            file_annotations = local_annotations

        if not file_annotations:
            return  # All annotations are cross-repo — gate skipped

        # Unstaged + staged changes vs HEAD
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=_subprocess_timeout,
        )
        if result.returncode == 0:
            modified_files.update(f.strip() for f in result.stdout.strip().split("\n") if f.strip())

        # Staged-only changes (for files that are staged but HEAD doesn't exist yet)
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=_subprocess_timeout,
        )
        if result.returncode == 0:
            modified_files.update(f.strip() for f in result.stdout.strip().split("\n") if f.strip())

        # Also check untracked files (new files not yet staged)
        result = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=_subprocess_timeout,
        )
        if result.returncode == 0:
            modified_files.update(f.strip() for f in result.stdout.strip().split("\n") if f.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return  # Git not available — skip gate gracefully

    # Check if any referenced files are in the diff.
    # Directory-prefix annotations (ending with /) match any file underneath.
    # Also handles bare directory paths without trailing slash by trying prefix + "/".
    unmodified: list[str] = []
    for f in file_annotations:
        if f.endswith("/"):
            # Explicit directory prefix: check if any modified file starts with this prefix
            if not any(mf.startswith(f) for mf in modified_files):
                unmodified.append(f)
        elif f in modified_files:
            pass  # Exact match — file is modified
        elif any(mf.startswith(f + "/") for mf in modified_files):
            pass  # Bare directory path without trailing slash — file underneath is modified
        else:
            unmodified.append(f)

    # Fallback: check recent commits if working tree diff doesn't contain the files
    if unmodified:
        try:
            result = subprocess.run(
                ["git", "log", "--diff-filter=ACMR", "--name-only", "--pretty=format:", "-n", "10"],
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=_subprocess_timeout,
            )
            if result.returncode == 0 and result.stdout:
                recent_files = {f.strip() for f in result.stdout.strip().split("\n") if f.strip()}
                still_unmodified: list[str] = []
                for f in unmodified:
                    if f.endswith("/"):
                        # Directory prefix: check if any recent file starts with this prefix
                        if not any(rf.startswith(f) for rf in recent_files):
                            still_unmodified.append(f)
                    elif f in recent_files:
                        pass  # Exact match in recent commits
                    elif any(rf.startswith(f + "/") for rf in recent_files):
                        pass  # Bare directory path — file underneath in recent commits
                    else:
                        still_unmodified.append(f)
                unmodified = still_unmodified
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass  # Git not available — skip fallback gracefully

    if unmodified:
        files_str = ", ".join(unmodified)
        raise ValueError(
            f"[{spec_id}] check_impl_task: Task '{task_id}' references files not in git diff: "
            f"{files_str}. "
            f"Stage or commit changes to these files before marking the task complete."
        )


# Exceptions expected during CRUD file operations
_NspecCrudErrors = (RuntimeError, ValueError, KeyError, TypeError, OSError, IOError)


# Priority ranges for auto-numbering (specs)


def check_acceptance_criteria(
    spec_id: str,
    criteria_id: str,
    docs_root: Path,
    marker: str = "x",
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Mark an acceptance criterion as complete or obsolete in FR file.

    Updates a checkbox from [ ] to [x] (complete) or [~] (obsolete).

    Args:
        spec_id: Spec ID (e.g., "127")
        criteria_id: Acceptance criteria ID (e.g., "AC-F1", "AC-Q2", "AC-D1")
        docs_root: Path to docs/ directory
        marker: Checkbox marker - "x" for complete, "~" for obsolete
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated FR file

    Raises:
        FileNotFoundError: If FR not found
        ValueError: If criteria ID not found or invalid marker
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    if marker not in ("x", "~", ">"):
        raise ValueError(
            f"Invalid marker '{marker}'. Use 'x' (complete), '~' (obsolete), or '>' (deferred)."
        )
    # Find FR file in active or completed directories
    fr_pattern = f"FR-{spec_id}-*.md"
    active_fr_dir = paths.active_frs_dir
    completed_fr_dir = paths.completed_frs_dir

    fr_files = list(active_fr_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(completed_fr_dir.glob(fr_pattern))

    if not fr_files:
        raise FileNotFoundError(
            f"FR-{spec_id}-*.md not found in {active_fr_dir} or {completed_fr_dir}"
        )

    fr_path = fr_files[0]

    with _file_lock(fr_path):
        content = fr_path.read_text()

        # Find and update the specific AC line
        pattern = rf"^- \[ \](.*{re.escape(criteria_id)}:.*)"
        match = re.search(pattern, content, re.MULTILINE)

        if not match:
            raise ValueError(
                f"Acceptance criterion '{criteria_id}' not found in FR-{spec_id}. "
                f"Make sure it matches pattern: '- [ ] {criteria_id}: ...'"
            )

        # Replace [ ] with [x] or [~] for this specific line
        old_line = f"- [ ]{match.group(1)}"
        new_line = f"- [{marker}]{match.group(1)}"
        content = content.replace(old_line, new_line, 1)

        fr_path.write_text(content)
        invalidate_dataset_cache(docs_root)
    _validate_after_write(spec_id, docs_root, paths_config, check_impl=False)
    return fr_path


def check_impl_task(
    spec_id: str,
    task_id: str,
    docs_root: Path,
    marker: str = "x",
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Mark an IMPL task as complete or obsolete.

    Updates a checkbox from [ ] to [x] (complete) or [~] (obsolete).

    Args:
        spec_id: Spec ID (e.g., "127")
        task_id: Task number to match (e.g., "1.1", "2.3")
        docs_root: Path to docs/ directory
        marker: Checkbox marker - "x" for complete, "~" for obsolete
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If task ID not found or matches multiple tasks
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    if marker not in ("x", "~", ">"):
        raise ValueError(
            f"Invalid marker '{marker}'. Use 'x' (complete), '~' (obsolete), or '>' (deferred)."
        )

    # Find IMPL file in active or completed directories
    impl_pattern = f"IMPL-{spec_id}-*.md"
    active_impl_dir = paths.active_impls_dir
    completed_impl_dir = paths.completed_impls_dir

    impl_files = list(active_impl_dir.glob(impl_pattern))
    if not impl_files:
        impl_files = list(completed_impl_dir.glob(impl_pattern))

    if not impl_files:
        raise FileNotFoundError(
            f"IMPL-{spec_id}-*.md not found in {active_impl_dir} or {completed_impl_dir}"
        )

    impl_path = impl_files[0]

    with _file_lock(impl_path):
        content = impl_path.read_text()
        lines = content.split("\n")
        matching_lines = []

        # Handle Definition of Done items (format: "dod-1", "dod-2", etc.)
        if task_id.lower().startswith("dod-"):
            dod_num_str = task_id[4:]  # Extract number after "dod-"
            if not dod_num_str.isdigit():
                raise ValueError(
                    f"Invalid DoD task ID '{task_id}'. Use format 'dod-1', 'dod-2', etc."
                )
            dod_num = int(dod_num_str)

            # Find Definition of Done section - count ALL checkboxes by position
            # Match any heading level containing "Definition of Done"
            # e.g. "## Definition of Done", "### Phase 3: Definition of Done"
            in_dod_section = False
            dod_heading_level = 0
            dod_checkboxes = []  # (line_idx, line, is_unchecked)
            for i, line in enumerate(lines):
                stripped = line.strip()
                if (
                    not in_dod_section
                    and stripped.startswith("#")
                    and "Definition of Done" in stripped
                ):
                    in_dod_section = True
                    dod_heading_level = len(stripped) - len(stripped.lstrip("#"))
                    continue
                if in_dod_section and stripped.startswith("#"):
                    # Any heading at same or higher level ends the section
                    level = len(stripped) - len(stripped.lstrip("#"))
                    if level <= dod_heading_level:
                        break
                if in_dod_section and line.startswith("- ["):
                    is_unchecked = line.startswith("- [ ]")
                    dod_checkboxes.append((i, line, is_unchecked))

            if not dod_checkboxes:
                raise ValueError(f"No Definition of Done items found in IMPL-{spec_id}.")
            if dod_num < 1 or dod_num > len(dod_checkboxes):
                raise ValueError(
                    f"DoD item {dod_num} not found. IMPL-{spec_id} has "
                    f"{len(dod_checkboxes)} DoD items (use dod-1 to dod-{len(dod_checkboxes)})."
                )

            line_idx, line, is_unchecked = dod_checkboxes[dod_num - 1]
            if not is_unchecked:
                raise ValueError(f"DoD item dod-{dod_num} is already checked in IMPL-{spec_id}.")
            matching_lines = [(line_idx, line)]
        else:
            # Find unchecked task matching task ID
            # Supports both "**1**: desc" and "1. desc" formats
            # Also matches indented subtasks (e.g., "  - [ ] 1.1. desc")
            for i, line in enumerate(lines):
                stripped = line.strip()
                if stripped.startswith("- [ ]") and _line_matches_task_id(stripped, task_id):
                    matching_lines.append((i, line))

            if not matching_lines:
                raise ValueError(
                    f"Task '{task_id}' not found in IMPL-{spec_id}. "
                    f"Make sure it exists and is not already checked."
                )

            if len(matching_lines) > 1:
                match_count = len(matching_lines)
                raise ValueError(
                    f"Task ID '{task_id}' matches {match_count} tasks "
                    f"in IMPL-{spec_id}. This shouldn't happen - check for duplicates:\n"
                    + "\n".join(f"  {i + 1}. {line}" for i, line in matching_lines)
                )

        # Check for BLOCKED marker on the task
        line_idx, old_line = matching_lines[0]
        if marker == "x" and line_idx + 1 < len(lines):
            next_line = lines[line_idx + 1].strip()
            if next_line.startswith("- **BLOCKED:**"):
                blocked_reason = next_line.replace("- **BLOCKED:**", "").strip()
                raise ValueError(
                    f"[{spec_id}] check_impl_task: Task '{task_id}' is blocked"
                    + (f": {blocked_reason}" if blocked_reason else "")
                )

        # S022 validation gates — only when marking complete (not obsolete)
        if marker == "x":
            # Gate 1: Sequential ordering (prior siblings must be complete)
            _check_sequential_order(spec_id, task_id, content, impl_path)
            # Gate 2: Subtask completeness (all children must be done)
            _check_subtasks_complete(spec_id, task_id, content, impl_path)
            # Gate 3: File-change verification (referenced files must be in git diff)
            _check_files_modified(spec_id, task_id, content, project_root=project_root)

        # Replace [ ] with [x] or [~] for the matching line
        new_line = old_line.replace("- [ ]", f"- [{marker}]", 1)

        # Append timestamp audit comment on completion (not obsolete)
        if marker == "x":
            new_line = new_line.rstrip() + f" <!-- {now_iso()} -->"

        lines[line_idx] = new_line
        content = "\n".join(lines)

        spec_write(impl_path, content)
        invalidate_dataset_cache(docs_root)
    _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)
    return impl_path


def validate_spec_criteria(
    spec_id: str,
    docs_root: Path,
    strict: bool = False,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[bool, list[str]]:
    """Validate acceptance criteria for a spec (policy-as-code).

    Checks:
    1. FR file has acceptance criteria defined
    2. Criteria follow AC-[FQP]N naming convention
    3. Optionally checks if criteria are marked complete (strict mode)

    Args:
        spec_id: Spec ID to validate (e.g., "127")
        docs_root: Path to docs/ directory
        strict: If True, require all criteria to be checked
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Tuple of (is_valid, list[violation_messages])

    Example output:
        (False, [
            "❌ No acceptance criteria defined in FR-127",
            "⚠️  AC-F1 not checked",
            "⚠️  AC-Q2 not checked"
        ])
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    violations = []

    # Find FR file
    fr_pattern = f"FR-{spec_id}-*.md"
    active_fr_dir = paths.active_frs_dir
    completed_fr_dir = paths.completed_frs_dir

    fr_files = list(active_fr_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(completed_fr_dir.glob(fr_pattern))

    if not fr_files:
        violations.append(f"❌ FR-{spec_id}-*.md not found")
        return False, violations

    fr_path = fr_files[0]
    fr_content = fr_path.read_text()

    # Check for acceptance criteria section
    if "## Success Criteria" not in fr_content and "## Acceptance Criteria" not in fr_content:
        violations.append(
            f"⚠️  No 'Success Criteria' or 'Acceptance Criteria' section in FR-{spec_id}"
        )

    # Find all acceptance criteria
    ac_pattern = r"^- \[(.)\]\s+(AC-[FQPD]\d+):"
    matches = list(re.finditer(ac_pattern, fr_content, re.MULTILINE))

    if not matches:
        violations.append(
            f"❌ No acceptance criteria found in FR-{spec_id} "
            f"(expected AC-F*, AC-Q*, AC-P*, AC-D* format)"
        )
        return False, violations

    # Check criteria naming convention
    for match in matches:
        checkbox_state = match.group(1)
        criteria_id = match.group(2)

        # Validate naming convention (AC-[FQPD]N where F=functional, Q=quality,
        # P=performance, D=documentation)
        if not re.match(r"AC-[FQPD]\d+$", criteria_id):
            violations.append(f"⚠️  Invalid criteria ID format: {criteria_id}")

        # In strict mode, check if criteria are marked complete
        # x=complete, ~=obsolete, >=deferred all count as "done"
        if strict and checkbox_state not in ("x", "~", ">"):
            violations.append(f"⚠️  {criteria_id} not checked")

    # Summary stats
    total_criteria = len(matches)
    checked_criteria = sum(1 for m in matches if m.group(1) in ("x", "~", ">"))
    completion_pct = (checked_criteria / total_criteria * 100) if total_criteria > 0 else 0

    if strict and checked_criteria < total_criteria:
        violations.insert(
            0,
            f"❌ Only {checked_criteria}/{total_criteria} criteria checked "
            f"({completion_pct:.0f}% complete)",
        )

    is_valid = len(violations) == 0
    return is_valid, violations


def set_task_blocked(
    spec_id: str,
    task_id: str,
    reason: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Mark an IMPL task as blocked by inserting a BLOCKED marker.

    Inserts a `  - **BLOCKED:** <reason>` line immediately after the task line.

    Args:
        spec_id: Spec ID (e.g., "004")
        task_id: Task number to match (e.g., "1", "2.1", "dod-1")
        reason: Reason for blocking
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If task ID not found
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = impl_path.read_text()
    lines = content.split("\n")

    target_line_idx = None

    for i, line in enumerate(lines):
        if line.startswith("- [") and _line_matches_task_id(line, task_id):
            target_line_idx = i
            break

    if target_line_idx is None:
        raise ValueError(
            f"Task '{task_id}' not found in IMPL-{spec_id}. Make sure the task exists."
        )

    # Check if task is already completed
    task_line = lines[target_line_idx]
    if (
        task_line.startswith("- [x]")
        or task_line.startswith("- [~]")
        or task_line.startswith("- [>]")
    ):
        raise ValueError(
            f"Task '{task_id}' in IMPL-{spec_id} is already completed. "
            f"Cannot block a completed task."
        )

    # Check if already blocked
    if target_line_idx + 1 < len(lines):
        next_line = lines[target_line_idx + 1]
        if "**BLOCKED:**" in next_line:
            raise ValueError(f"Task '{task_id}' in IMPL-{spec_id} is already blocked.")

    # Insert BLOCKED marker after the task line
    blocked_line = f"  - **BLOCKED:** {reason}"
    lines.insert(target_line_idx + 1, blocked_line)

    spec_write(impl_path, "\n".join(lines))
    invalidate_dataset_cache(docs_root)
    _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)
    return impl_path


def set_task_unblocked(
    spec_id: str,
    task_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Remove the BLOCKED marker from an IMPL task.

    Args:
        spec_id: Spec ID (e.g., "004")
        task_id: Task number to match (e.g., "1", "2.1")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If task or BLOCKED marker not found
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    content = impl_path.read_text()
    lines = content.split("\n")

    target_line_idx = None

    for i, line in enumerate(lines):
        if line.startswith("- [") and _line_matches_task_id(line, task_id):
            target_line_idx = i
            break

    if target_line_idx is None:
        raise ValueError(f"Task '{task_id}' not found in IMPL-{spec_id}.")

    # Check for BLOCKED marker on next line
    if target_line_idx + 1 >= len(lines) or "**BLOCKED:**" not in lines[target_line_idx + 1]:
        raise ValueError(f"Task '{task_id}' in IMPL-{spec_id} is not blocked.")

    # Remove the BLOCKED line
    lines.pop(target_line_idx + 1)

    spec_write(impl_path, "\n".join(lines))
    invalidate_dataset_cache(docs_root)
    _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)
    return impl_path
