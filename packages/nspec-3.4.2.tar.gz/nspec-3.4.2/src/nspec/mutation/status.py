"""Status transitions and state-pair validation."""

import re
from pathlib import Path

from nspec.domain.datasets import invalidate_dataset_cache
from nspec.domain.ids import normalize_spec_ref
from nspec.domain.statuses import (
    FR_STATUSES,
    IMPL_STATUSES,
)
from nspec.mutation._helpers import (
    _file_lock,
    _get_current_status,
    _validate_after_write,
)
from nspec.paths import NspecPaths, get_paths

# Valid status transitions (source → allowed targets).
VALID_IMPL_TRANSITIONS: dict[int, list[int]] = {
    0: [1, 4],  # Planning → Active or Paused
    1: [2, 4],  # Active → Testing or Paused
    2: [3, 4],  # Testing → Ready or Paused
    3: [],  # Ready is terminal
    4: [0, 1],  # Paused → Planning or Active (resume)
    5: [0, 1],  # Hold → Planning or Active (resume)
}

VALID_FR_TRANSITIONS: dict[int, list[int]] = {
    0: [1, 2, 4, 6],  # Proposed → In Design, Active, Rejected, Deferred
    1: [2, 4, 6],  # In Design → Active, Rejected, Deferred
    2: [3, 4, 5],  # Active → Completed, Rejected, Superseded
    3: [],  # Completed is terminal
    4: [],  # Rejected is terminal
    5: [],  # Superseded is terminal
    6: [0, 1, 2],  # Deferred → Proposed, In Design, Active (resume)
}


def _validate_transition(
    current_fr: int,
    current_impl: int,
    new_fr: int,
    new_impl: int,
    fr_statuses: dict,
    impl_statuses: dict,
) -> tuple[bool, str]:
    """Validate state transition is logically valid.

    Args:
        current_fr: Current FR status code
        current_impl: Current IMPL status code
        new_fr: New FR status code
        new_impl: New IMPL status code
        fr_statuses: FR status mapping
        impl_statuses: IMPL status mapping

    Returns:
        Tuple of (is_valid, error_message)
    """
    # Rule 0: Check valid FR transition (skip if unchanged)
    if new_fr != current_fr:
        allowed_fr = VALID_FR_TRANSITIONS.get(current_fr, [])
        if new_fr not in allowed_fr:
            curr_emoji, curr_text = fr_statuses[current_fr]
            new_emoji, new_text = fr_statuses[new_fr]
            return (
                False,
                f"[set_status] Invalid FR transition: "
                f"{curr_emoji} {curr_text} ({current_fr}) → "
                f"{new_emoji} {new_text} ({new_fr})",
            )

    # Rule 0b: Check valid IMPL transition (skip if unchanged)
    if new_impl != current_impl:
        allowed_impl = VALID_IMPL_TRANSITIONS.get(current_impl, [])
        if new_impl not in allowed_impl:
            curr_emoji, curr_text = impl_statuses[current_impl]
            new_emoji, new_text = impl_statuses[new_impl]
            return (
                False,
                f"[set_status] Invalid IMPL transition: "
                f"{curr_emoji} {curr_text} ({current_impl}) → "
                f"{new_emoji} {new_text} ({new_impl})",
            )

    # Rule 3: IMPL can't start until FR spec is finalized (Active)
    # FR must be Active (2) before IMPL can be Active (1) or beyond
    # Rationale: The FR defines WHAT to build - it must be complete before implementation
    if new_impl >= 1 and new_fr < 2:
        return (
            False,
            "[set_status] Cannot start IMPL until FR is Active (2) - finalize the spec first",
        )

    # Rule 4: Can't mark IMPL Ready without completing FR
    if new_impl == 3 and new_fr != 3:
        return (
            False,
            "[set_status] Cannot mark IMPL as Ready (3) unless FR is also Completed (3)",
        )

    # Rule 5: If completing FR, IMPL should also be ready
    if new_fr == 3 and new_impl != 3:
        return (
            False,
            "[set_status] Cannot mark FR as Completed (3) unless IMPL is also Ready (3)",
        )

    return (True, "")


def set_status(
    spec_id: str,
    fr_status: int,
    impl_status: int,
    docs_root: Path,
    *,
    force: bool = False,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Set status for both FR and IMPL files atomically.

    Status codes:
      FR: 0=Proposed, 1=In Design, 2=Active, 3=Completed, 4=Rejected, 5=Superseded, 6=Deferred
      IMPL: 0=Planning, 1=Active, 2=Testing, 3=Ready, 4=Paused, 5=Hold

    Args:
        spec_id: Spec ID to update (e.g., "128")
        fr_status: FR status code (0-6)
        impl_status: IMPL status code (0-5)
        docs_root: Path to docs/ directory
        force: If True, skip transition validation (for recovery from bad states)
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
        ValueError: If status codes are invalid or transition is illogical (unless force=True)
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Build status mappings from centralized statuses module
    fr_statuses = {code: (s.emoji, s.text) for code, s in FR_STATUSES.items()}
    impl_statuses = {code: (s.emoji, s.text) for code, s in IMPL_STATUSES.items()}

    # Validate status codes
    if fr_status not in fr_statuses:
        raise ValueError(f"Invalid FR status code: {fr_status}. Must be 0-6.")
    if impl_status not in impl_statuses:
        raise ValueError(f"Invalid IMPL status code: {impl_status}. Must be 0-6.")

    # Find FR file
    fr_pattern = f"FR-{spec_id}-*.md"
    active_fr_dir = paths.active_frs_dir
    completed_fr_dir = paths.completed_frs_dir

    fr_files = list(active_fr_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(completed_fr_dir.glob(fr_pattern))

    if not fr_files:
        raise FileNotFoundError(
            f"FR-{spec_id}-*.md not found in {active_fr_dir} or {completed_fr_dir}"
        )

    fr_path = fr_files[0]

    # Find IMPL file
    impl_pattern = f"IMPL-{spec_id}-*.md"
    active_impl_dir = paths.active_impls_dir
    completed_impl_dir = paths.completed_impls_dir

    impl_files = list(active_impl_dir.glob(impl_pattern))
    if not impl_files:
        impl_files = list(completed_impl_dir.glob(impl_pattern))

    if not impl_files:
        raise FileNotFoundError(
            f"IMPL-{spec_id}-*.md not found in {active_impl_dir} or {completed_impl_dir}"
        )

    impl_path = impl_files[0]

    from nspec.runtime.atomic import is_batch_active, spec_read, spec_write

    # Always acquire per-file locks to prevent concurrent read-modify-write
    # races — even inside batch_writes().  The batch buffers writes in memory
    # but the lock protects the read-modify-write sequence itself.  CLI
    # handlers (e.g. next_status) may not hold spec_lock, so _file_lock is
    # the safety net against concurrent processes.
    with _file_lock(fr_path), _file_lock(impl_path):
        fr_content = spec_read(fr_path)
        impl_content = spec_read(impl_path)

        # Extract current statuses
        current_fr_tuple = _get_current_status(fr_content, kind="FR")
        current_impl_tuple = _get_current_status(impl_content, kind="IMPL")

        if current_fr_tuple is None:
            raise ValueError(f"Could not parse current FR status from {fr_path.name}")
        if current_impl_tuple is None:
            raise ValueError(f"Could not parse current IMPL status from {impl_path.name}")

        current_fr, current_fr_emoji, current_fr_text = current_fr_tuple
        current_impl, current_impl_emoji, current_impl_text = current_impl_tuple

        # Validate transition is logically valid (unless force is set)
        if not force:
            is_valid, error_msg = _validate_transition(
                current_fr, current_impl, fr_status, impl_status, fr_statuses, impl_statuses
            )
            if not is_valid:
                # Show current state for context
                print("\n❌ Invalid state transition:")
                print(
                    f"   Current: FR = {current_fr_emoji} {current_fr_text} ({current_fr})  |  "
                    f"IMPL = {current_impl_emoji} {current_impl_text} ({current_impl})"
                )
                new_fr_emoji, new_fr_text = fr_statuses[fr_status]
                new_impl_emoji, new_impl_text = impl_statuses[impl_status]
                print(
                    f"   Requested: FR = {new_fr_emoji} {new_fr_text} ({fr_status})  |  "
                    f"IMPL = {new_impl_emoji} {new_impl_text} ({impl_status})"
                )
                print(f"\n   Reason: {error_msg}\n")
                raise ValueError(error_msg)
        else:
            print("\n⚠️  Force mode: Skipping transition validation")

        # Show BEFORE state
        print(f"\n📊 Setting Spec {spec_id} statuses...")
        print(
            f"   BEFORE: FR = {current_fr_emoji} {current_fr_text} ({current_fr})  |  "
            f"IMPL = {current_impl_emoji} {current_impl_text} ({current_impl})"
        )

        # Update FR status — words-only format (S332), emojis added at render time
        fr_emoji, fr_text = fr_statuses[fr_status]
        fr_content = re.sub(
            r"^\*\*Status:\*\*.*$",
            f"**Status:** {fr_text}",
            fr_content,
            flags=re.MULTILINE,
        )
        spec_write(fr_path, fr_content)

        # Update IMPL status — words-only format (S332)
        impl_emoji, impl_text = impl_statuses[impl_status]
        impl_content = re.sub(
            r"^\*\*Status:\*\*.*$",
            f"**Status:** {impl_text}",
            impl_content,
            flags=re.MULTILINE,
        )

        # Append transition timestamp as HTML comment (audit trail)
        from nspec.runtime.timestamps import now_iso

        ts = now_iso()
        impl_content = re.sub(
            r"^(\*\*Status:\*\*.*)$",
            rf"\1\n<!-- transitioned: {ts} -->",
            impl_content,
            count=1,
            flags=re.MULTILINE,
        )

        spec_write(impl_path, impl_content)
        invalidate_dataset_cache(docs_root)

    # Show AFTER state
    print(
        f"   AFTER:  FR = {fr_emoji} {fr_text} ({fr_status})  |  "
        f"IMPL = {impl_emoji} {impl_text} ({impl_status})"
    )
    print("\n   ✅ Files updated:")
    print(f"      • {fr_path.name}")
    print(f"      • {impl_path.name}\n")

    # Update state.json when activating (FR=2 Active, IMPL=1 Active)
    if fr_status == 2 and impl_status == 1:
        from nspec.runtime.session import SessionDAO

        root = project_root if project_root else docs_root.parent
        dao = SessionDAO(root)
        if spec_id.startswith("E"):
            dao.set_active_epic(spec_id)
            dao.set_spec_id("")
        else:
            dao.set_spec_id(spec_id)
        print(f"   📝 Updated session tracker: {dao.state_path.name}\n")

    # Skip post-write validation when inside a batch — the files haven't
    # been flushed to disk yet, so _validate_after_write would check stale
    # content.  The batch flush ensures atomic disk writes; validation runs
    # after the flush at the call site (or via the full nspec validate).
    if not is_batch_active():
        _validate_after_write(spec_id, docs_root, paths_config)
    return fr_path, impl_path


def next_status(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Auto-advance IMPL status to next logical state.

    Automatically progresses IMPL through: Planning → Active → Testing → Ready
    Also auto-upgrades FR when needed (e.g., FR becomes Active when IMPL becomes Active)

    Args:
        spec_id: Spec ID to advance (e.g., "128")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
        ValueError: If already at terminal state or transition invalid
    """
    from nspec.runtime.atomic import batch_writes

    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find files
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    active_fr_dir = paths.active_frs_dir
    completed_fr_dir = paths.completed_frs_dir
    fr_files = list(active_fr_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(completed_fr_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(
            f"FR-{spec_id}-*.md not found in {active_fr_dir} or {completed_fr_dir}"
        )
    fr_path = fr_files[0]

    active_impl_dir = paths.active_impls_dir
    completed_impl_dir = paths.completed_impls_dir
    impl_files = list(active_impl_dir.glob(impl_pattern))
    if not impl_files:
        impl_files = list(completed_impl_dir.glob(impl_pattern))
    if not impl_files:
        raise FileNotFoundError(
            f"IMPL-{spec_id}-*.md not found in {active_impl_dir} or {completed_impl_dir}"
        )
    impl_path = impl_files[0]

    # Read current statuses
    fr_content = fr_path.read_text()
    impl_content = impl_path.read_text()

    current_fr_tuple = _get_current_status(fr_content, kind="FR")
    current_impl_tuple = _get_current_status(impl_content, kind="IMPL")

    if current_fr_tuple is None:
        raise ValueError(f"Could not parse current FR status from {fr_path.name}")
    if current_impl_tuple is None:
        raise ValueError(f"Could not parse current IMPL status from {impl_path.name}")

    current_fr, current_fr_emoji, current_fr_text = current_fr_tuple
    current_impl, current_impl_emoji, current_impl_text = current_impl_tuple

    # Define IMPL progression path
    impl_progression = {
        0: 1,  # Planning → Active
        1: 2,  # Active → Testing
        2: 3,  # Testing → Ready
        # 3: terminal (Ready for archival)
        # 4: Paused (no auto-progression)
    }

    if current_impl not in impl_progression:
        if current_impl == 3:
            print(
                f"\n✅ Spec {spec_id} IMPL already at terminal state: "
                f"{current_impl_emoji} {current_impl_text}\n"
            )
            raise ValueError(f"IMPL already Ready ({current_impl}) - use complete() to archive")
        elif current_impl == 4:
            print(
                f"\n⏸️  Spec {spec_id} IMPL is Paused - cannot auto-advance\n"
                f"   Use activate() to resume, then advance\n"
            )
            raise ValueError(f"IMPL is Paused ({current_impl}) - use activate() to resume")
        elif current_impl == 5:
            print(
                f"\n🚨 Spec {spec_id} IMPL is in Exception state\n"
                f"   Requires human triage before advancing\n"
            )
            raise ValueError(f"IMPL is in Exception state ({current_impl}) - requires human triage")

    next_impl = impl_progression[current_impl]

    # Auto-upgrade FR if needed
    # When IMPL goes Active (1+), FR must be Active (2) - spec must be finalized first
    # When IMPL goes Ready (3), FR must also be Completed (3)
    next_fr = current_fr
    if next_impl >= 1 and current_fr < 2:  # IMPL starting but FR spec not finalized
        next_fr = 2  # Upgrade FR to "Active" (spec finalized)
        msg = (
            f"\n🔄 Auto-upgrading FR: {current_fr_emoji} {current_fr_text} "
            f"→ 🟢 Active (spec finalized)"
        )
        print(msg)
    if next_impl == 3:  # IMPL ready, FR must also be completed
        next_fr = 3
        msg = f"\n🔄 Auto-upgrading FR: {current_fr_emoji} {current_fr_text} → ✅ Completed"
        print(msg)

    # Batch the FR + IMPL writes so external observers see a single atomic update
    with batch_writes():
        result = set_status(
            spec_id,
            next_fr,
            next_impl,
            docs_root,
            paths_config=paths_config,
            project_root=project_root,
        )

    # Validate after the batch flush — files are now on disk
    _validate_after_write(spec_id, docs_root, paths_config)
    return result


def check_state_pair_warning(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> str | None:
    """Check if the current (FR, IMPL) state pair is valid per VALID_STATE_PAIRS.

    Returns a warning string if the pair is invalid, or None if valid/unknown.
    This is advisory only — callers should surface it as a soft warning.
    """
    from nspec.domain.statuses import is_valid_state_pair

    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find and read FR
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(paths.active_frs_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(fr_pattern))
    if not fr_files:
        return None

    # Find and read IMPL
    impl_pattern = f"IMPL-{spec_id}-*.md"
    impl_files = list(paths.active_impls_dir.glob(impl_pattern))
    if not impl_files:
        impl_files = list(paths.completed_impls_dir.glob(impl_pattern))
    if not impl_files:
        return None

    fr_content = fr_files[0].read_text()
    impl_content = impl_files[0].read_text()

    fr_tuple = _get_current_status(fr_content, kind="FR")
    impl_tuple = _get_current_status(impl_content, kind="IMPL")
    if fr_tuple is None or impl_tuple is None:
        return None

    fr_code = fr_tuple[0]
    impl_code = impl_tuple[0]

    is_valid, reason = is_valid_state_pair(fr_code, impl_code)
    if not is_valid:
        return (
            f"⚠️  State pair warning: FR={fr_tuple[2]}({fr_code}) + "
            f"IMPL={impl_tuple[2]}({impl_code}) — {reason}"
        )
    return None
