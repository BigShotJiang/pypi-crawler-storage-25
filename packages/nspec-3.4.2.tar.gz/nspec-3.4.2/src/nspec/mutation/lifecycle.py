"""Spec lifecycle mutations: create, delete, complete, supersede, reject, finalize."""

import fcntl
import json
import logging
import os
import re
import time
from datetime import UTC
from pathlib import Path
from typing import Any, Literal

from nspec.domain.ids import normalize_spec_ref, spec_ref_number
from nspec.domain.statuses import (
    FR_STATUSES,
    IMPL_STATUSES,
    FRStatusCode,
    IMPLStatusCode,
    get_priority_line_pattern,
    get_priority_line_sub_pattern,
    is_completed_status,
)
from nspec.mutation._helpers import (
    NspecIntegrityError,
    _git_add,
    _validate_after_write,
)
from nspec.paths import NspecPaths, ResolvedPaths, get_paths
from nspec.runtime.locks import _get_lock_dir

_crud_logger = logging.getLogger("nspec.crud")


class DuplicateSpecIdError(ValueError):
    """Raised when create_spec would allocate an ID that already exists on disk.

    This is a defensive guard — should be unreachable after the monotonic
    allocation fix (S340), but catches regressions and reservation-ledger
    corruption.
    """

    def __init__(self, spec_id: str, existing_path: str) -> None:
        self.spec_id = spec_id
        self.existing_path = existing_path
        super().__init__(
            f"Spec ID {spec_id} already exists on disk: {existing_path}. "
            f"This indicates a bug in ID allocation — IDs must be monotonically increasing."
        )


def _get_id_ranges(
    project_root: Path | None = None,
    *,
    user_id: str | None = None,
) -> tuple[dict[str, tuple[int, int]], tuple[int, int]]:
    """Load ID ranges from config, returning (priority_ranges, epic_range).

    When *user_id* is provided and has a configured range, uses the
    per-user range instead of global defaults.
    """
    from nspec.config import NspecConfig

    config = NspecConfig.load(project_root)
    r = config.id_ranges
    spec_min, spec_max, epic_min, epic_max = r.resolve_range(user_id)

    from nspec.domain.statuses import SPEC_PRIORITIES  # inline: survives importlib.reload

    priority_ranges = {pcode: (spec_min, spec_max) for pcode in SPEC_PRIORITIES}
    epic_range = (epic_min, epic_max)
    return priority_ranges, epic_range


EPIC_ID_RANGE = (1, 99)


def get_all_spec_ids(
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    git_ref: str | None = None,
) -> set[str]:
    """Get all spec IDs from active + completed directories.

    Args:
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
        git_ref: Optional git ref to read IDs from (e.g., "origin/main").
                 When provided, uses git_reader instead of filesystem scan.

    Returns:
        Set of all spec IDs (both active and completed)
    """
    # Git-ref mode: use git_reader to read IDs from a git tree-ish
    if git_ref is not None:
        from nspec.git_reader import get_spec_ids_from_ref

        # Compute docs_root relative to project root for git_reader
        pr = project_root or Path.cwd()
        try:
            docs_rel = str(docs_root.resolve().relative_to(pr.resolve()))
        except ValueError:
            docs_rel = "docs"
        return get_spec_ids_from_ref(git_ref, docs_root_relative=docs_rel, cwd=str(pr))

    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    all_ids = set()

    def _extract_ref_from_stem(stem: str) -> str | None:
        match = re.match(r"FR-([ES]\d{3}[a-z]?)", stem, re.IGNORECASE)
        if not match:
            return None
        try:
            return normalize_spec_ref(match.group(1))
        except ValueError:
            return None

    # Active FRs
    if paths.active_frs_dir.exists():
        for path in paths.active_frs_dir.glob("FR-*.md"):
            if path.stem.upper() != "TEMPLATE":
                ref = _extract_ref_from_stem(path.stem)
                if ref:
                    all_ids.add(ref)

    # Completed FRs
    if paths.completed_frs_dir.exists():
        for path in paths.completed_frs_dir.glob("FR-*.md"):
            ref = _extract_ref_from_stem(path.stem)
            if ref:
                all_ids.add(ref)

    # Superseded FRs
    if paths.superseded_dir.exists():
        for path in paths.superseded_dir.glob("FR-*.md"):
            ref = _extract_ref_from_stem(path.stem)
            if ref:
                all_ids.add(ref)

    # Rejected FRs
    if paths.rejected_dir.exists():
        for path in paths.rejected_dir.glob("FR-*.md"):
            ref = _extract_ref_from_stem(path.stem)
            if ref:
                all_ids.add(ref)

    return all_ids


def _collect_all_existing_spec_ids(
    paths: ResolvedPaths,
) -> dict[str, list[Path]]:
    """Scan all filesystem locations for spec IDs and return ID-to-paths mapping.

    Walks active FRs, active IMPLs, completed/done, completed/superseded,
    and completed/rejected directories. Returns a dict mapping each spec ID
    to all file paths that reference it — used for duplicate detection across
    the full repo lifetime.

    Unlike ``get_all_spec_ids`` (which is optimised for the allocation hot
    path and only returns a set of IDs), this helper preserves path
    information so callers can report *where* a duplicate lives.
    """

    id_to_paths: dict[str, list[Path]] = {}

    def _extract_ref_from_stem(stem: str) -> str | None:
        match = re.match(r"(?:FR|IMPL)-([ES]\d{3}[a-z]?)", stem, re.IGNORECASE)
        if not match:
            return None
        try:
            return normalize_spec_ref(match.group(1))
        except ValueError:
            return None

    # Directories to scan — both FR and IMPL variants
    scan_dirs = [
        paths.active_frs_dir,
        paths.active_impls_dir,
        paths.completed_done,
        paths.completed_superseded,
        paths.completed_rejected,
    ]

    for scan_dir in scan_dirs:
        if not scan_dir.exists():
            continue
        for path in scan_dir.glob("*.md"):
            ref = _extract_ref_from_stem(path.stem)
            if ref:
                id_to_paths.setdefault(ref, []).append(path)

    return id_to_paths


def clean_dangling_deps(
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    dry_run: bool = False,
) -> list[tuple[str, str, list[str]]]:
    """Remove dependencies pointing to non-existent specs.

    Auto-cleans FR files that reference deleted specs in their deps list.

    Args:
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
        dry_run: If True, report changes without writing files

    Returns:
        List of (spec_id, fr_path, removed_deps) for each cleaned file
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    all_spec_ids = get_all_spec_ids(docs_root, paths_config, project_root)
    cleaned: list[tuple[str, str, list[str]]] = []

    # Check active FRs
    if not paths.active_frs_dir.exists():
        return cleaned

    deps_pattern = re.compile(r"^deps:\s*\[([^\]]*)\]", re.MULTILINE)

    for path in paths.active_frs_dir.glob("FR-*.md"):
        if path.stem.upper() == "TEMPLATE":
            continue

        match = re.match(r"FR-([ES]\d{3}[a-z]?)", path.stem, re.IGNORECASE)
        if not match:
            continue

        try:
            spec_id = normalize_spec_ref(match.group(1))
        except ValueError:
            continue
        content = path.read_text(encoding="utf-8")
        deps_match = deps_pattern.search(content)

        if not deps_match:
            continue

        deps_str = deps_match.group(1)
        if not deps_str.strip():
            continue

        # Parse current deps
        current_deps = [d.strip() for d in deps_str.split(",") if d.strip()]

        # Find dangling deps
        dangling: list[str] = []
        valid: list[str] = []
        for dep in current_deps:
            try:
                normalized = normalize_spec_ref(dep)
            except ValueError:
                # Leave unparseable deps alone (validator will catch)
                valid.append(dep)
                continue

            if normalized in all_spec_ids:
                valid.append(normalized)
            else:
                dangling.append(dep)

        if dangling:
            # Rewrite deps line without dangling refs
            new_deps_str = ", ".join(valid)
            new_deps_line = f"deps: [{new_deps_str}]"
            new_content = deps_pattern.sub(new_deps_line, content)
            if not dry_run:
                path.write_text(new_content, encoding="utf-8")
            cleaned.append((spec_id, str(path), dangling))

    if cleaned and not dry_run:
        # S926: invalidate cache after modifying spec files
        from nspec.domain.datasets import invalidate_dataset_cache

        invalidate_dataset_cache(docs_root)

    return cleaned


# ---------------------------------------------------------------------------
# Main-anchored ID allocation helpers (S303)
# ---------------------------------------------------------------------------

_RESERVATION_TTL_SECONDS = 3600  # 1 hour — stale reservations are pruned


def _get_ids_with_fallback(
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> set[str]:
    """Read spec IDs from all remote branches, unioned with local filesystem.

    S355 fix: scans ALL remote branches (via ``git for-each-ref``) instead
    of only ``origin/main``.  This prevents ID collisions when sibling
    branches create specs that haven't been merged to main yet.

    S340 fix: always include the local filesystem scan so that
    locally-archived specs (not yet pushed) are visible to the allocator.

    When *project_root* is ``None``, derives it from *docs_root* (parent
    directory) so the git commands and config lookups target the correct
    project rather than falling back to ``Path.cwd()``.
    """
    from nspec.git_reader import GitReaderError, get_spec_ids_from_all_branches

    # Derive project_root so git ops and config stay scoped to the correct
    # project (avoids CWD bleed-through in tests and multi-project setups).
    if project_root is None:
        project_root = docs_root.parent

    all_ids: set[str] = set()

    # Compute docs_root relative to project root for git operations
    try:
        docs_rel = str(docs_root.resolve().relative_to(project_root.resolve()))
    except ValueError:
        docs_rel = "docs"

    # S355: scan ALL remote branches for spec IDs, not just origin/main.
    # This catches IDs allocated on sibling branches that haven't merged yet.
    try:
        branch_ids = get_spec_ids_from_all_branches(
            docs_root_relative=docs_rel,
            cwd=str(project_root),
        )
        all_ids |= branch_ids
    except Exception:
        # Best-effort: fall back to origin/main → main scan if all-branch
        # scan fails unexpectedly.
        _crud_logger.debug("All-branch scan failed, falling back to main-only")
        for ref in ("origin/main", "main"):
            try:
                all_ids |= get_all_spec_ids(
                    docs_root,
                    paths_config,
                    project_root,
                    git_ref=ref,
                )
                break
            except GitReaderError:
                _crud_logger.debug("ID fallback: %s unavailable, trying next", ref)
                continue

    # Always include local filesystem scan (S340) — catches locally-archived
    # specs that haven't been pushed yet, preventing ID reuse.
    local_ids = get_all_spec_ids(docs_root, paths_config, project_root)
    all_ids |= local_ids

    return all_ids


def _reservation_path(project_root: Path) -> Path:
    """Return the shared reservation file path."""
    return project_root / ".novabuilt.dev" / "nspec" / "id-reservations.json"


def _reservation_lock_path(project_root: Path | None = None) -> Path:
    """Return the shared lock path for reservation file operations.

    Args:
        project_root: Explicit project root for lock directory scoping.
                     If None, auto-detected via NspecConfig.
    """
    lock_dir = _get_lock_dir(project_root)
    lock_path = lock_dir / "id-reservations.lock"
    return lock_path


def _read_reservation_data(path: Path) -> dict:
    """Read raw reservation data from disk. Caller must hold the lock."""

    if not path.exists():
        return {"reservations": []}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"reservations": []}


def _active_reserved_ids(data: dict) -> set[str]:
    """Extract all reservation IDs from data dict.

    S340 fix: returns ALL reservations regardless of age.  Previously
    this filtered by ``_RESERVATION_TTL_SECONDS`` which allowed archived
    IDs to silently expire from the ledger — the root cause of ID reuse.
    The TTL constant is retained for ``_reserve_id`` (log-rotation of very
    old entries) but is no longer used for allocation decisions.
    """
    return {e["id"] for e in data.get("reservations", [])}


def _read_reservations(project_root: Path) -> set[str]:
    """Read active (non-stale) reservations under a shared lock."""
    path = _reservation_path(project_root)
    if not path.exists():
        return set()

    lock_path = _reservation_lock_path(project_root)
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT)
    try:
        fcntl.flock(fd, fcntl.LOCK_SH)
        data = _read_reservation_data(path)
        return _active_reserved_ids(data)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _reserve_id(spec_id: str, project_root: Path) -> None:
    """Reserve a spec ID in the shared reservation file with flock coordination.

    S340 fix: reservations are append-only.  We no longer prune stale
    entries during writes — once an ID enters the ledger it stays
    permanently so that ``_active_reserved_ids`` always includes it.
    """

    path = _reservation_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)

    lock_path = _reservation_lock_path(project_root)
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)

        data = _read_reservation_data(path)

        # Append-only: no pruning (S340).
        now = time.time()
        data["reservations"].append(
            {
                "id": spec_id,
                "timestamp": now,
            }
        )

        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _allocate_and_reserve(
    priority: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    id_prefix: Literal["S", "E"] = "S",
    user_id: str | None = None,
) -> str:
    """Atomically allocate the next spec ID and reserve it under one lock.

    This prevents concurrent creators from selecting the same ID by holding
    the reservation lock for the entire read-allocate-write cycle.

    When *user_id* is provided, allocates within the user's configured range.
    """

    # Derive project_root from docs_root to avoid CWD bleed-through
    if project_root is None:
        project_root = docs_root.parent
    pr = project_root
    path = _reservation_path(pr)
    path.parent.mkdir(parents=True, exist_ok=True)

    lock_path = _reservation_lock_path(pr)
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)

        # Read reservations under lock
        data = _read_reservation_data(path)
        reserved = _active_reserved_ids(data)

        # Get IDs from git/filesystem
        all_spec_ids = _get_ids_with_fallback(docs_root, paths_config, project_root)
        all_spec_ids |= reserved

        # Pick next ID (user-aware)
        spec_id = _pick_next_id(
            priority, all_spec_ids, project_root, id_prefix=id_prefix, user_id=user_id
        )

        # Reserve atomically — append-only, no pruning (S340).
        now = time.time()
        data["reservations"].append({"id": spec_id, "timestamp": now})
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")

        return spec_id
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def _prune_reservations(project_root: Path, landed_ids: set[str] | None = None) -> None:
    """No-op — retained for API compatibility only.

    **S340 fix:** Both ``landed_ids`` and TTL-based pruning are
    disabled.  The reservation ledger is now fully append-only so
    that archived IDs are never removed from uniqueness checks.
    The monotonic ``_pick_next_id`` plus the filesystem scan in
    ``_get_ids_with_fallback`` guarantee that no ID is ever reused,
    regardless of ledger state.
    """
    # Intentionally empty — ledger is append-only (S340).
    return


def _ceiling_state_path(project_root: Path | None) -> Path:
    """Path to the auto-bumped ceiling state file (S908)."""
    root = project_root or Path.cwd()
    return root / ".novabuilt.dev" / "nspec" / "state" / "id_ceiling.json"


def _read_ceiling_override(project_root: Path | None, id_prefix: str) -> int | None:
    """Read the persisted auto-bumped ceiling for this prefix, if any."""
    path = _ceiling_state_path(project_root)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None
    val = data.get(id_prefix)
    return int(val) if isinstance(val, int) else None


def _persist_ceiling_override(project_root: Path | None, id_prefix: str, new_ceiling: int) -> None:
    """Persist the auto-bumped ceiling so subsequent calls see it."""
    path = _ceiling_state_path(project_root)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        data = json.loads(path.read_text()) if path.exists() else {}
    except (json.JSONDecodeError, OSError):
        data = {}
    data[id_prefix] = new_ceiling
    path.write_text(json.dumps(data, indent=2) + "\n")


def _get_exhaustion_policy(
    project_root: Path | None,
) -> tuple[str, int, float]:
    """Return (on_exhaustion, extend_step, warn_threshold) from config."""
    from nspec.config import NspecConfig

    cfg = NspecConfig.load(project_root)
    return (
        cfg.id_ranges.on_exhaustion,
        cfg.id_ranges.extend_step,
        cfg.id_ranges.capacity_warn_threshold,
    )


def _pick_next_id(
    priority: str,
    all_spec_ids: set[str],
    project_root: Path | None = None,
    *,
    id_prefix: Literal["S", "E"] = "S",
    user_id: str | None = None,
) -> str:
    """Core ID selection logic — finds next available ID given a set of used IDs.

    Allocates ``max(used) + 1`` (monotonic). Never backfills gaps — archived
    /superseded/rejected IDs stay permanently reserved so commit history and
    PR links remain stable (S340).

    S908 changes:
    - Considers ALL used IDs of the matching prefix (not just those inside
      the current range) when computing the high-water mark, so out-of-range
      IDs (e.g., previously-bumped) are never re-issued.
    - When `max(used) + 1 > range_end` and `[id_ranges].on_exhaustion =
      "extend"` (default), bumps the ceiling by `extend_step` and persists
      the new ceiling to `.novabuilt.dev/nspec/state/id_ceiling.json`.
      Emits a logger.warning. With `on_exhaustion = "fail"`, raises (legacy).
    - Emits logger.warning when the watermark crosses
      `capacity_warn_threshold` (default 90%) of the current range.

    When *user_id* is provided, uses per-user range from config.
    """
    priority_ranges, epic_range = _get_id_ranges(project_root, user_id=user_id)
    if id_prefix == "E":
        range_start, range_end = epic_range
    else:
        range_start, range_end = priority_ranges[priority]

    # S908: honour any previously-persisted ceiling override for this prefix
    override = _read_ceiling_override(project_root, id_prefix)
    if override is not None and override > range_end:
        range_end = override

    # S908: consider ALL used IDs of this prefix (not just in-range) when
    # computing the high-water mark. Prevents re-issuing an out-of-range ID
    # that exists from a prior bump or import.
    used_all_prefix = set()
    used_in_range = set()
    for sid in all_spec_ids:
        if not sid.startswith(id_prefix):
            continue
        numeric = spec_ref_number(sid)
        used_all_prefix.add(numeric)
        if range_start <= numeric <= range_end:
            used_in_range.add(numeric)

    if not used_all_prefix:
        return f"{id_prefix}{range_start:03d}"

    # Highest is across all used IDs of this prefix, not just in-range
    highest = max(used_all_prefix)
    next_id = highest + 1

    # Capacity warning: emit when the watermark is past the threshold
    on_exhaustion, extend_step, warn_threshold = _get_exhaustion_policy(project_root)
    capacity_used = (highest - range_start + 1) / max(1, range_end - range_start + 1)
    if capacity_used >= warn_threshold:
        _crud_logger.warning(
            "ID range %s/%s for prefix %r is at %.0f%% capacity "
            "(highest=%d, range_end=%d). Consider widening or planning a bump.",
            priority,
            id_prefix,
            id_prefix,
            capacity_used * 100,
            highest,
            range_end,
        )

    if next_id <= range_end:
        return f"{id_prefix}{next_id:03d}"

    # Exhaustion
    if on_exhaustion == "fail":
        raise ValueError(
            f"Priority range exhausted for {priority} "
            f"(range: {range_start}-{range_end}, highest: {highest}). "
            f"Set [id_ranges].on_exhaustion = 'extend' to auto-bump, or "
            f"manually raise [id_ranges].spec_max."
        )

    # on_exhaustion == "extend": bump ceiling, persist, log, return next_id
    new_ceiling = highest + extend_step
    _persist_ceiling_override(project_root, id_prefix, new_ceiling)
    _crud_logger.warning(
        "S908: ID range exhausted for %s/%s — auto-extended ceiling from "
        "%d to %d (extend_step=%d). Persisted to %s. "
        "Set [id_ranges].on_exhaustion = 'fail' to disable auto-extend.",
        priority,
        id_prefix,
        range_end,
        new_ceiling,
        extend_step,
        _ceiling_state_path(project_root),
    )
    return f"{id_prefix}{next_id:03d}"


def get_next_spec_id(
    priority: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    id_prefix: Literal["S", "E"] = "S",
    user_id: str | None = None,
) -> str:
    """Determine next ID based on type and existing specs.

    Reads existing IDs from origin/main (shared truth), falling back to
    main then local filesystem when git refs are unavailable. Also checks
    the reservation file for IDs allocated but not yet pushed.

    Note: For concurrent-safe allocation, use ``_allocate_and_reserve()``
    which atomically picks and reserves under one lock.

    Args:
        priority: P0, P1, P2, or P3
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
        user_id: Optional user/agent identity for per-user range selection.

    Returns:
        Next available ID (e.g., "S044", "S105", "E007")

    Raises:
        ValueError: If priority range is exhausted
    """
    # Derive project_root from docs_root to avoid CWD bleed-through
    if project_root is None:
        project_root = docs_root.parent

    all_spec_ids = _get_ids_with_fallback(docs_root, paths_config, project_root)
    reserved = _read_reservations(project_root)
    all_spec_ids |= reserved
    return _pick_next_id(priority, all_spec_ids, project_root, id_prefix=id_prefix, user_id=user_id)


def find_duplicate_spec_ids(
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, list[Path]]:
    """Find spec IDs with multiple FR files across all directories.

    Scans FR files in active, completed/done, and completed/superseded
    directories and detects collisions where the same numeric ID appears
    with different slugs or in multiple directories.
    Returns only entries with count > 1 (actual collisions).

    Args:
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config.toml lookup

    Returns:
        Dict of spec_id → list of FR file paths (only entries with len > 1)
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    id_to_paths: dict[str, list[Path]] = {}

    # Scan all FR directories: active, completed/done, completed/superseded
    scan_dirs = [
        paths.active_frs_dir,
        paths.completed_done,
        paths.completed_superseded,
    ]

    for directory in scan_dirs:
        if not directory or not directory.exists():
            continue
        for path in directory.glob("FR-*.md"):
            if path.stem.upper() == "TEMPLATE":
                continue
            match = re.match(r"FR-([ES]\d{3}[a-z]?)", path.stem, re.IGNORECASE)
            if not match:
                continue
            try:
                ref = normalize_spec_ref(match.group(1))
            except ValueError:
                continue
            id_to_paths.setdefault(ref, []).append(path)

    return {sid: fpaths for sid, fpaths in id_to_paths.items() if len(fpaths) > 1}


def renumber_spec(
    old_id: str,
    new_id: str,
    file_path: Path,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    keep_old_dep: bool = False,
) -> list[str]:
    """Renumber a spec from old_id to new_id.

    Renames FR+IMPL files and updates their header lines.
    Also updates epic deps lines that reference old_id.

    Args:
        old_id: Current spec ID (e.g., "S257")
        new_id: New spec ID to assign (e.g., "S259")
        file_path: The specific FR file to renumber (resolves the slug)
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config.toml lookup
        keep_old_dep: If True, add new_id alongside old_id in deps instead
                      of replacing. Used in collision resolution where old_id
                      is still valid (kept file retains the ID).

    Returns:
        List of change descriptions
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    changes: list[str] = []

    # Extract slug from the FR filename: FR-S257-some-slug.md → some-slug
    fr_stem = file_path.stem  # e.g., "FR-S257-some-slug"
    prefix_pattern = re.compile(rf"^FR-{re.escape(old_id)}-", re.IGNORECASE)
    slug_match = prefix_pattern.match(fr_stem)
    if not slug_match:
        raise ValueError(f"Cannot extract slug from {file_path.name} for {old_id}")
    slug = fr_stem[slug_match.end() :]

    # Rename FR file
    new_fr_name = f"FR-{new_id}-{slug}.md"
    new_fr_path = file_path.parent / new_fr_name
    if file_path.exists():
        # Update header inside FR
        content = file_path.read_text(encoding="utf-8")
        content = re.sub(
            rf"^(#\s+)FR-{re.escape(old_id)}:",
            rf"\1FR-{new_id}:",
            content,
            count=1,
            flags=re.MULTILINE,
        )
        file_path.rename(new_fr_path)
        new_fr_path.write_text(content, encoding="utf-8")
        changes.append(f"Renamed {file_path.name} → {new_fr_name}")

    # Rename IMPL file
    old_impl_name = f"IMPL-{old_id}-{slug}.md"
    old_impl_path = paths.active_impls_dir / old_impl_name
    new_impl_name = f"IMPL-{new_id}-{slug}.md"
    new_impl_path = paths.active_impls_dir / new_impl_name
    if old_impl_path.exists():
        content = old_impl_path.read_text(encoding="utf-8")
        content = re.sub(
            rf"^(#\s+)IMPL-{re.escape(old_id)}:",
            rf"\1IMPL-{new_id}:",
            content,
            count=1,
            flags=re.MULTILINE,
        )
        old_impl_path.rename(new_impl_path)
        new_impl_path.write_text(content, encoding="utf-8")
        changes.append(f"Renamed {old_impl_name} → {new_impl_name}")

    # Update epic deps lines referencing old_id
    deps_pattern = re.compile(r"^(deps:\s*\[)([^\]]*)\]", re.MULTILINE)
    for fr_path in paths.active_frs_dir.glob("FR-*.md"):
        if fr_path == new_fr_path:
            continue
        content = fr_path.read_text(encoding="utf-8")
        deps_match = deps_pattern.search(content)
        if not deps_match:
            continue
        deps_str = deps_match.group(2)
        if not deps_str.strip():
            continue
        deps_list = [d.strip() for d in deps_str.split(",") if d.strip()]
        # Check if old_id is in deps (case-insensitive normalize)
        updated = False
        new_deps = []
        for dep in deps_list:
            try:
                normalized = normalize_spec_ref(dep)
            except ValueError:
                new_deps.append(dep)
                continue
            if normalized == old_id:
                if keep_old_dep:
                    # Collision mode: keep old dep, add new alongside
                    new_deps.append(dep)
                    new_deps.append(new_id)
                else:
                    # Standard renumber: replace old with new
                    new_deps.append(new_id)
                updated = True
            else:
                new_deps.append(dep)
        if updated:
            new_deps_line = f"deps: [{', '.join(new_deps)}]"
            new_content = deps_pattern.sub(new_deps_line, content)
            fr_path.write_text(new_content, encoding="utf-8")
            fr_ref = re.match(r"FR-([ES]\d{3}[a-z]?)", fr_path.stem, re.IGNORECASE)
            ref_label = fr_ref.group(1) if fr_ref else fr_path.stem
            if keep_old_dep:
                changes.append(f"Updated {ref_label} deps: {old_id} preserved, {new_id} added")
            else:
                changes.append(f"Updated {ref_label} deps: {old_id} → {new_id}")

    # S926: invalidate cache after renumbering spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    return changes


def unify_collisions(
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> list[dict[str, Any]]:
    """Detect and resolve spec ID collisions.

    For each collision, keeps the older file (by mtime) and renumbers the
    newer file to the next available ID.

    Args:
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config.toml lookup

    Returns:
        List of resolution dicts with keys: spec_id, kept, renumbered,
        new_id, changes. Empty list if no collisions found.
    """
    duplicates = find_duplicate_spec_ids(docs_root, paths_config, project_root)
    if not duplicates:
        return []

    # unify_collisions only auto-resolves collisions within the active
    # directory (merge conflicts).  Cross-directory duplicates (active vs
    # archived) are caught by DatasetLoader validation — not auto-fixed here.
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    active_dir = paths.active_frs_dir

    resolutions: list[dict[str, Any]] = []

    for spec_id, fr_paths in duplicates.items():
        # Filter to only paths within the active FR directory
        active_paths = [p for p in fr_paths if active_dir in p.parents or p.parent == active_dir]
        if len(active_paths) < 2:
            # Cross-directory duplicate — not a unify target
            continue

        # Sort by mtime — oldest first (keeps its ID)
        sorted_paths = sorted(active_paths, key=lambda p: p.stat().st_mtime)
        keep_path = sorted_paths[0]

        for conflict_path in sorted_paths[1:]:
            # Determine priority of the conflicting spec to get correct ID range.
            # Uses the shared priority-line regex from statuses.py so both legacy
            # (emoji+code) and words-only (S332) formats are handled correctly.
            content = conflict_path.read_text(encoding="utf-8")
            priority_match = re.search(get_priority_line_pattern(), content, re.MULTILINE)
            priority = priority_match.group(1) if priority_match else "P2"

            id_prefix: Literal["S", "E"] = "E" if spec_id.startswith("E") else "S"
            new_id = get_next_spec_id(
                priority,
                docs_root,
                paths_config,
                project_root,
                id_prefix=id_prefix,
            )
            changes = renumber_spec(
                spec_id,
                new_id,
                conflict_path,
                docs_root,
                paths_config,
                project_root,
                keep_old_dep=True,
            )
            resolutions.append(
                {
                    "spec_id": spec_id,
                    "kept": keep_path.name,
                    "renumbered": conflict_path.name,
                    "new_id": new_id,
                    "changes": changes,
                }
            )

    return resolutions


def create_new_spec(
    title: str,
    priority: str,
    docs_root: Path,
    fr_template: str | Path | None = None,
    impl_template: str | Path | None = None,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
    *,
    is_epic: bool = False,
    template: str | None = None,
    auto_priority: bool = False,
    user_id: str | None = None,
) -> tuple[Path, Path, str]:
    """Create new FR + IMPL from templates.

    Args:
        title: Spec title (e.g., "Feature Name")
        priority: P0, P1, P2, or P3
        docs_root: Path to docs/ directory
        fr_template: Optional path to FR template (relative to docs_root or absolute).
                     Defaults to package resources with project-local override.
        impl_template: Optional path to IMPL template (relative to docs_root or absolute).
                       Defaults to package resources with project-local override.
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
        is_epic: If True, create an epic (E###) instead of a spec (S###)
        template: Optional ceremony-level profile name (quick/standard/full/formal).
                  Overrides fr_template/impl_template when set.

    Returns:
        (fr_path, impl_path, spec_id) - Paths to created files and assigned ID

    Raises:
        ValueError: If priority is invalid or range exhausted
        FileNotFoundError: If templates don't exist
    """
    # S340: derive project_root from docs_root when not provided, so the
    # allocator uses the correct id-reservations.json and config instead
    # of falling back to Path.cwd() which may be a different project.
    if project_root is None:
        project_root = docs_root.parent

    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Validate priority (epics don't use priority ranges for ID assignment)
    from nspec.domain.statuses import SPEC_PRIORITIES  # inline: survives importlib.reload

    if priority not in SPEC_PRIORITIES:
        max_level = len(SPEC_PRIORITIES) - 1
        raise ValueError(
            f"Invalid priority: {priority}. Must be P0-P{max_level}. "
            f"Check if too many epics are being created."
        )

    # Enforce unique priority per epic — auto-assign if caller didn't specify
    if is_epic:
        from nspec.domain.datasets import DatasetLoader
        from nspec.mutation.deps import _check_epic_priority_unique, _epic_priority_from_id

        loader = DatasetLoader(docs_root=docs_root)
        datasets = loader.load()
        if auto_priority:
            # Pre-compute the next epic ID so we can derive priority from it
            preview_id = get_next_spec_id(
                priority, docs_root, paths_config, project_root, id_prefix="E", user_id=user_id
            )
            priority = _epic_priority_from_id(preview_id, datasets)
        else:
            _check_epic_priority_unique(priority, datasets)

    # Atomically allocate and reserve the next ID under one lock
    id_prefix = "E" if is_epic else "S"
    spec_id = _allocate_and_reserve(
        priority,
        docs_root,
        paths_config,
        project_root,
        id_prefix=id_prefix,
        user_id=user_id,
    )

    # Defensive duplicate check (S340): scan ALL directories (active + archived)
    # to verify the allocated ID doesn't already exist on disk anywhere.
    # Should be unreachable after the monotonic allocation fix, but catches
    # reservation-ledger corruption or filesystem races.
    all_existing = _collect_all_existing_spec_ids(paths)
    if spec_id in all_existing:
        conflicting = all_existing[spec_id][0]
        raise DuplicateSpecIdError(spec_id, str(conflicting))

    # Generate filenames
    slug = title.lower()
    slug = re.sub(r"[^\w\s-]", "", slug)  # Remove special chars
    slug = re.sub(r"[-\s]+", "-", slug)  # Convert spaces to dashes
    slug = slug.strip("-")

    fr_filename = f"FR-{spec_id}-{slug}.md"
    impl_filename = f"IMPL-{spec_id}-{slug}.md"

    # Resolve template content
    from nspec.resources import load_template, resolve_template_profile

    # Profile-based resolution: template param > config default > legacy chain
    profile = template
    if profile is None and fr_template is None and impl_template is None:
        # Check config for default profile
        try:
            from nspec.config import NspecConfig

            config = NspecConfig.load(project_root)
            profile = config.templates.default
        except Exception:
            pass

    if profile is not None:
        # Use profile-based templates
        fr_template = resolve_template_profile(profile, "fr", project_root)
        impl_template = resolve_template_profile(profile, "impl", project_root)
    else:
        # Legacy flat-file resolution chain
        if fr_template is None:
            legacy_fr = paths.active_frs_dir / "TEMPLATE.md"
            local_fr = paths.resources_dir / "fr-template.md"
            if legacy_fr.exists():
                fr_template = legacy_fr.read_text()
            elif local_fr.exists():
                fr_template = local_fr.read_text()
            else:
                fr_template = load_template("fr")
        elif isinstance(fr_template, Path) or (
            isinstance(fr_template, str) and Path(fr_template).suffix == ".md"
        ):
            fr_template_path = Path(fr_template)
            if not fr_template_path.is_absolute():
                fr_template_path = docs_root / fr_template_path
            if not fr_template_path.exists():
                raise FileNotFoundError(f"FR template not found: {fr_template_path}")
            fr_template = fr_template_path.read_text()

        if impl_template is None:
            legacy_impl = paths.active_impls_dir / "TEMPLATE.md"
            local_impl = paths.resources_dir / "impl-template.md"
            if legacy_impl.exists():
                impl_template = legacy_impl.read_text()
            elif local_impl.exists():
                impl_template = local_impl.read_text()
            else:
                impl_template = load_template("impl")
        elif isinstance(impl_template, Path) or (
            isinstance(impl_template, str) and Path(impl_template).suffix == ".md"
        ):
            impl_template_path = Path(impl_template)
            if not impl_template_path.is_absolute():
                impl_template_path = docs_root / impl_template_path
            if not impl_template_path.exists():
                raise FileNotFoundError(f"IMPL template not found: {impl_template_path}")
            impl_template = impl_template_path.read_text()

    # Get current date
    from datetime import datetime

    current_date = datetime.now().strftime("%Y-%m-%d")

    # Replace placeholders
    # FR replacements: XXX → spec_id, title in heading, [FEATURE NAME]/[SPEC TITLE] → title
    # P2 → priority, YYYY-MM-DD → current_date
    fr_content = fr_template.replace("XXX", spec_id)
    fr_content = re.sub(
        r"^(# FR-[ES]?\d{3}[a-z]?: )Title$",
        rf"\g<1>{title}",
        fr_content,
        count=1,
        flags=re.MULTILINE,
    )
    fr_content = fr_content.replace("[FEATURE NAME]", title)
    fr_content = fr_content.replace("[SPEC TITLE]", title)  # For code review templates
    fr_content = fr_content.replace("slug", slug)
    fr_content = fr_content.replace("YYYY-MM-DD", current_date)
    # Use the shared priority-line substitution pattern from statuses.py.
    fr_content = re.sub(
        get_priority_line_sub_pattern(),
        f"**Priority:** {priority}",
        fr_content,
    )

    # Add Type field for epics (required for epic detection)
    if is_epic:
        fr_content = re.sub(
            r"(\*\*Priority:\*\*[^\n]*\n)",
            r"\g<1>**Type:** Epic\n",
            fr_content,
            count=1,
        )

    # IMPL replacements: XXX → spec_id, title in heading, [FEATURE NAME]/[SPEC TITLE] → title
    impl_content = impl_template.replace("XXX", spec_id)
    impl_content = re.sub(
        r"^(# IMPL-[ES]?\d{3}[a-z]?: )Title$",
        rf"\g<1>{title}",
        impl_content,
        count=1,
        flags=re.MULTILINE,
    )
    impl_content = impl_content.replace("[FEATURE NAME]", title)
    impl_content = impl_content.replace("[SPEC TITLE]", title)  # For code review templates
    impl_content = impl_content.replace("slug", slug)
    impl_content = impl_content.replace("YYYY-MM-DD", current_date)

    # Write files
    fr_path = paths.active_frs_dir / fr_filename
    impl_path = paths.active_impls_dir / impl_filename

    fr_path.write_text(fr_content)
    impl_path.write_text(impl_content)

    # S926: invalidate cache after creating new spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    # Auto git-add so complete() can git-mv later
    _git_add(fr_path, impl_path)

    _validate_after_write(spec_id, docs_root, paths_config)
    return fr_path, impl_path, spec_id


def delete_spec(
    spec_id: str,
    docs_root: Path,
    force: bool = False,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Delete FR + IMPL files for a spec.

    Safety: Requires force=True or REALLY_DELETE_NSPEC_ITEM=Y environment variable.

    Args:
        spec_id: Spec ID to delete (e.g., "S044" or "044")
        docs_root: Path to docs/ directory
        force: Skip safety check if True
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        (fr_path, impl_path) - Paths of deleted files

    Raises:
        RuntimeError: If safety check fails
        FileNotFoundError: If FR or IMPL not found
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Safety check - skip if force=True
    if not force and os.environ.get("REALLY_DELETE_NSPEC_ITEM") != "Y":
        raise RuntimeError(
            "Safety check failed: use --force or set REALLY_DELETE_NSPEC_ITEM=Y\n"
            "Usage: make nspec.delete <spec_id> FORCE=1"
        )

    # Find FR and IMPL files
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    fr_dir = paths.active_frs_dir
    impl_dir = paths.active_impls_dir

    fr_files = list(fr_dir.glob(fr_pattern))
    impl_files = list(impl_dir.glob(impl_pattern))

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")
    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    # Take first match (should only be one)
    fr_path = fr_files[0]
    impl_path = impl_files[0]

    # Delete files
    fr_path.unlink()
    impl_path.unlink()

    # S926: invalidate cache after deleting spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    return fr_path, impl_path


def _check_completion_readiness(
    fr_path: Path,
    impl_path: Path,
    spec_id: str,
    docs_root: Path,
) -> tuple[bool, list[str]]:
    """Check if a spec is ready for completion by validating acceptance criteria and tasks.

    Supports both completed and rejected specs:
    - Completed: FR must be ✅ Completed, IMPL must be 🟠 Ready, AC checked, tasks done
    - Rejected: FR must be ❌ Rejected, skips AC/task validation

    Checkbox markers recognized as "complete":
    - [x] - Explicitly completed
    - [~] - Obsolete/not applicable (intentionally skipped)
    - [>] - Deferred to another tracker
    - [→XXX] - Delegated to another spec

    Args:
        fr_path: Path to FR file
        impl_path: Path to IMPL file
        spec_id: Spec ID being checked
        docs_root: Path to docs/ directory (used for review packet archival checks)

    Returns:
        (is_ready, warnings) - is_ready=True if validation passes, warnings list always returned
    """
    from nspec.domain.tasks import AcceptanceCriteriaParser, TaskParser

    warnings = []
    fr_content = fr_path.read_text()
    impl_content = impl_path.read_text()

    # Check FR status first - rejected specs skip AC/task validation
    fr_status = re.search(r"^\*\*Status:\*\*\s+(.+)$", fr_content, re.MULTILINE)
    is_rejected = fr_status and ("❌" in fr_status.group(1) or "Rejected" in fr_status.group(1))

    if is_rejected:
        # Rejected specs are ready for archival without AC/task validation
        warnings.append("ℹ️  Spec rejected - skipping AC/task validation")
        return True, warnings

    # For completed specs, check FR acceptance criteria using the parser
    # This ensures consistent counting with nspec_task display
    try:
        ac_parser = AcceptanceCriteriaParser()
        acceptance_criteria = ac_parser.parse(fr_content, fr_path)
        if acceptance_criteria:
            # Parser only returns [x] and [ ] items, but we also need to count [~] as complete
            # Re-scan for all AC items including obsolete markers
            ac_pattern = r"^- \[(.)\].*AC-[FQPD]"
            fr_criteria = re.findall(ac_pattern, fr_content, re.MULTILINE)
            if fr_criteria:
                # Count [x], [~], [>], and [→...] as complete
                checked = sum(1 for c in fr_criteria if c.lower() == "x" or c in ("~", ">", "→"))
                total = len(fr_criteria)
                if checked < total:
                    remaining = total - checked
                    warnings.append(  # pyright: ignore[reportUnknownMemberType]
                        f"❌ FR acceptance criteria incomplete: "
                        f"{checked}/{total} checked ({remaining} remaining)"
                    )
    except ValueError:
        # Parser failed - fall back to simple regex (may have format issues)
        ac_pattern = r"^- \[(.)\].*AC-[FQPD]"
        fr_criteria = re.findall(ac_pattern, fr_content, re.MULTILINE)
        if fr_criteria:
            checked = sum(1 for c in fr_criteria if c.lower() == "x" or c in ("~", ">", "→"))
            total = len(fr_criteria)
            if checked < total:
                remaining = total - checked
                warnings.append(
                    f"❌ FR acceptance criteria incomplete: "
                    f"{checked}/{total} checked ({remaining} remaining)"
                )

    # Check IMPL tasks using the TaskParser for consistency with nspec_task display
    try:
        task_parser = TaskParser()
        task_tree = task_parser.parse(impl_content, impl_path)
        flat_tasks = task_parser.flatten(task_tree)
        if flat_tasks:
            # TaskParser already handles [x], [~], and [→XXX] as complete.
            # IMPORTANT: Count nested tasks too; parse() returns a tree.
            checked = sum(1 for t in flat_tasks if t.completed)
            total = len(flat_tasks)
            completion_pct = (checked / total * 100) if total > 0 else 100
            if checked < total:
                remaining = [t for t in flat_tasks if not t.completed]
                sample = "; ".join(t.description for t in remaining[:5])
                suffix = f" Remaining: {sample}" if sample else ""
                warnings.append(
                    f"❌ IMPL tasks incomplete: "
                    f"{checked}/{total} checked ({completion_pct:.0f}% complete).{suffix}"
                )
    except ValueError:
        # Parser failed - fall back to simple regex counting [x], [~], [>]
        impl_tasks = re.findall(r"^- \[(.)\]", impl_content, re.MULTILINE)
        if impl_tasks:
            checked = sum(1 for c in impl_tasks if c.lower() == "x" or c in ("~", ">", "→"))
            total = len(impl_tasks)
            completion_pct = (checked / total * 100) if total > 0 else 100
            if checked < total:
                warnings.append(
                    f"❌ IMPL tasks incomplete: "
                    f"{checked}/{total} checked ({completion_pct:.0f}% complete)"
                )

    # Check if status is already marked complete
    impl_status = re.search(r"^\*\*Status:\*\*\s+(.+)$", impl_content, re.MULTILINE)

    if fr_status and "✅" not in fr_status.group(1) and "Completed" not in fr_status.group(1):
        warnings.append(f"❌ FR status not marked complete: {fr_status.group(1)}")

    # IMPL terminal state is "🟠 Ready" (not "✅ Completed" like FR)
    if impl_status and "🟠" not in impl_status.group(1) and "Ready" not in impl_status.group(1):
        warnings.append(f"❌ IMPL status not ready: {impl_status.group(1)} (expected 🟠 Ready)")

    is_review_packet = bool(
        re.search(r"^#\s+FR-S\\d{3}:\\s+Review Packet:", fr_content, re.MULTILINE)
    ) or ("review-packet" in fr_path.name)

    if not is_review_packet:
        # Check review verdict and reviewer
        from nspec.mutation.review import _get_impl_field, _get_review_verdict

        verdict = _get_review_verdict(impl_content)
        implementer = _get_impl_field(impl_content, "Implementer")
        reviewer = _get_impl_field(impl_content, "Reviewer")

        if verdict != "APPROVED":
            if verdict == "NEEDS_WORK":
                warnings.append(
                    "❌ Review verdict is NEEDS_WORK - address feedback before completing"
                )
            elif verdict == "PENDING" or not verdict:
                warnings.append(
                    "❌ Review not completed - run nspec_request_review then get approval"
                )
            else:
                warnings.append(f"❌ Review verdict invalid: {verdict} (expected APPROVED)")

        if implementer and reviewer:
            if implementer.lower() == reviewer.lower():
                warnings.append(
                    f"❌ Reviewer ({reviewer}) cannot be same as implementer ({implementer})"
                )
        elif not reviewer and verdict == "APPROVED":
            warnings.append("❌ No reviewer recorded but verdict is APPROVED - invalid state")
        elif not implementer and verdict == "APPROVED":
            warnings.append("❌ No implementer recorded but verdict is APPROVED - invalid state")

        # Check that review has real content (not just manually written APPROVED)
        # The write_review_verdict MCP tool populates ### Findings with review feedback.
        # If Notes is empty/missing AND Findings is placeholder, the review was faked.
        if verdict == "APPROVED":
            notes_match = re.search(
                r"###\s*Notes\s*\n(.*?)(?=\n##|\n---|\n###|\Z)",
                impl_content,
                re.DOTALL,
            )
            findings_match = re.search(
                r"###\s*Findings\s*\n(.*?)(?=\n##|\n---|\n###|\Z)",
                impl_content,
                re.DOTALL,
            )
            notes_text = notes_match.group(1).strip() if notes_match else ""
            findings_text = findings_match.group(1).strip() if findings_match else ""

            placeholder_markers = [
                "reviewer writes findings here",
                "populated by review agent",
                "populated by",
                "[reviewer",
            ]
            findings_is_placeholder = not findings_text or any(
                m in findings_text.lower() for m in placeholder_markers
            )
            has_real_review = bool(notes_text and len(notes_text) >= 10) or (
                not findings_is_placeholder and len(findings_text) >= 20
            )
            if not has_real_review:
                warnings.append(
                    "❌ Review has no substantive feedback — "
                    "run `/review` or `review_spec()` for a real agent-based review"
                )
    else:
        # Review-packet specs are meta: skip requiring a review-of-the-review,
        # but require a durable archive.
        dep_target: str | None = None
        deps_match_for_review = re.search(r"^deps:\s*\[(.*?)\]$", fr_content, re.MULTILINE)
        if deps_match_for_review:
            deps_str = deps_match_for_review.group(1).strip()
            dep_ids = [normalize_spec_ref(d.strip()) for d in deps_str.split(",") if d.strip()]
            if len(dep_ids) == 1 and dep_ids[0].startswith("S"):
                dep_target = dep_ids[0]

        if not dep_target:
            warnings.append(
                "❌ Review packet spec must declare exactly one target dep (deps: [S###])"
            )
        else:
            archive_root = docs_root / "review" / "archives"
            archive_files = list(archive_root.glob(f"*/{dep_target}.md"))
            if not archive_files:
                warnings.append(
                    f"❌ Missing archived review packet for {dep_target} under "
                    f"docs/review/archives/. "
                    f"Run `python scripts/archive_review_packets.py --docs-root {docs_root}` "
                    f"or `nspec review finalize --id {spec_id}`."
                )
            else:
                token_a = spec_id
                token_b = f"FR-{spec_id}"
                if not any(
                    (token_a in p.read_text()) or (token_b in p.read_text()) for p in archive_files
                ):
                    warnings.append(
                        f"❌ Archived packet for {dep_target} exists but "
                        f"does not mention {spec_id}. "
                        f"Re-archive after updating work/review/{dep_target}/REVIEW.md."
                    )

    # Check upstream deps are completed (only for non-rejected specs)
    deps_match = re.search(r"^deps:\s*\[(.*?)\]$", fr_content, re.MULTILINE)
    if deps_match:
        deps_str = deps_match.group(1).strip()
        if deps_str:
            dep_ids = [d.strip() for d in deps_str.split(",") if d.strip()]
            # Check each dep's FR status — all must be Completed
            for dep_id in dep_ids:
                dep_id = normalize_spec_ref(dep_id)
                dep_fr_dir = fr_path.parent
                dep_pattern = f"FR-{dep_id}-*.md"
                dep_files = list(dep_fr_dir.glob(dep_pattern))
                if dep_files:
                    dep_content = dep_files[0].read_text()
                    dep_status = re.search(r"^\*\*Status:\*\*\s+(.+)$", dep_content, re.MULTILINE)
                    if dep_status and "✅" not in dep_status.group(1):
                        warnings.append(
                            f"❌ Upstream dep {dep_id} not completed: {dep_status.group(1).strip()}"
                        )
                # If dep FR not in active dir, check completed dir
                if not dep_files:
                    resolved = get_paths(docs_root)
                    dep_files = list(resolved.completed_done.glob(dep_pattern))
                    # If found in completed dir, it's done — no warning needed

    # Determine if ready
    blockers = [w for w in warnings if w.startswith("❌")]
    is_ready = len(blockers) == 0

    return is_ready, warnings


def complete_spec(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path, Path, Path]:
    """Move FR + IMPL files to completed directory using git mv.

    Validates completion readiness by checking:
    - FR acceptance criteria are checked
    - IMPL tasks are complete
    - Status fields are marked complete

    If files already exist in completed directory:
    - Diff active vs completed versions
    - If identical: git rm active files (no move needed)
    - If different: raise error (manual resolution required)

    Args:
        spec_id: Spec ID to complete (e.g., "044")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        (fr_old_path, fr_new_path, impl_old_path, impl_new_path)

    Raises:
        FileNotFoundError: If FR or IMPL not found in active directories
        RuntimeError: If git mv fails, files differ, or validation fails
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    import subprocess

    # Load git timeout from config
    from nspec.config import NspecConfig

    _cfg = NspecConfig.load(project_root)
    GIT_TIMEOUT_S = _cfg.timeouts.git_s

    # Find FR and IMPL files in active directories
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    fr_dir = paths.active_frs_dir
    impl_dir = paths.active_impls_dir
    completed_dir = paths.completed_done

    fr_files = list(fr_dir.glob(fr_pattern))
    impl_files = list(impl_dir.glob(impl_pattern))

    # Check if files are already in completed directory
    if not fr_files or not impl_files:
        completed_fr_files = list(completed_dir.glob(fr_pattern))
        completed_impl_files = list(completed_dir.glob(impl_pattern))

        if completed_fr_files and completed_impl_files:
            print(f"✅ Spec {spec_id} is already completed")
            print(f"   FR: {completed_fr_files[0].relative_to(docs_root)}")
            print(f"   IMPL: {completed_impl_files[0].relative_to(docs_root)}")

            # Ensure status is Completed even in already-archived files
            from nspec.runtime.atomic import atomic_write

            completed_status = FR_STATUSES[FRStatusCode.COMPLETED].full
            for fpath in (completed_fr_files[0], completed_impl_files[0]):
                _content = fpath.read_text(encoding="utf-8")
                _updated = re.sub(
                    r"^\*\*Status:\*\*.*$",
                    f"**Status:** {completed_status}",
                    _content,
                    flags=re.MULTILINE,
                )
                if _updated != _content:
                    atomic_write(fpath, _updated)
                    # Stage the fix
                    git_cwd = docs_root.parent
                    try:
                        subprocess.run(
                            ["git", "add", str(fpath)],
                            check=True,
                            capture_output=True,
                            timeout=GIT_TIMEOUT_S,
                            cwd=git_cwd,
                        )
                    except subprocess.CalledProcessError as e:
                        raise RuntimeError(
                            f"git add failed for already-completed {spec_id}: {e.stderr}"
                        ) from e
                    except subprocess.TimeoutExpired as e:
                        raise RuntimeError(
                            "git add timed out for already-completed spec. "
                            "Another git process may be holding the index lock."
                        ) from e

            return (
                fr_dir / completed_fr_files[0].name,  # Dummy old path
                completed_fr_files[0],
                impl_dir / completed_impl_files[0].name,  # Dummy old path
                completed_impl_files[0],
            )

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")
    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    # Take first match (should only be one)
    fr_old_path = fr_files[0]
    impl_old_path = impl_files[0]

    fr_new_path = completed_dir / fr_old_path.name
    impl_new_path = completed_dir / impl_old_path.name

    # S909 / AC-F4: Reject archival when a DIFFERENT-stem file with the same
    # spec ID already exists in completed/done or completed/superseded.
    # The same-stem case is handled below (identical-content fast path or
    # different-content same-stem error). This check catches the
    # repurposed-ID case where completion would create a cross-dir collision.
    # Run BEFORE the completion-readiness check so users see the structural
    # issue (collision) before lifecycle issues (review not done, etc.).
    completed_done_dir = paths.completed_done
    completed_superseded_dir = paths.completed_superseded
    foreign_completed: list[Path] = []
    for scan_dir in (completed_done_dir, completed_superseded_dir):
        if not scan_dir or not scan_dir.exists():
            continue
        for pattern in (fr_pattern, impl_pattern):
            for p in scan_dir.glob(pattern):
                # Skip the same-name file in the canonical destination — that
                # case is handled by the existing diff-or-fast-path logic.
                if p.name in (fr_old_path.name, impl_old_path.name):
                    continue
                foreign_completed.append(p)
    if foreign_completed:
        listing = "\n".join(f"  - {p.relative_to(docs_root)}" for p in foreign_completed)
        raise RuntimeError(
            f"Cannot complete spec {spec_id}: a different file with the same "
            f"spec ID already exists in completed/.\n"
            f"{listing}\n\n"
            f"This would create a cross-directory ID collision. Resolve via:\n"
            f"  nspec repair-collisions       # interactive cleanup\n"
            f"  nspec repair-collisions --dry-run    # preview only\n"
            f"or manually rename/retire the existing completed file before retrying."
        )

    # Validate completion readiness
    is_ready, warnings = _check_completion_readiness(fr_old_path, impl_old_path, spec_id, docs_root)

    if warnings:
        print(f"\n🔍 Completion validation for Spec {spec_id}:")
        for warning in warnings:
            print(f"   {warning}")
        print()

    if not is_ready:
        error_msg = f"❌ Spec {spec_id} is not ready for completion.\n\n"
        error_msg += "Issues found:\n"
        for warning in [w for w in warnings if w.startswith("❌")]:
            error_msg += f"  {warning}\n"
        error_msg += "\nFix the validation or fix your spec:\n"
        error_msg += "  1. Mark all acceptance criteria as complete in FR file\n"
        error_msg += "  2. Ensure FR status is '✅ Completed' and IMPL status is '🟠 Ready'\n"
        error_msg += "  3. Update IMPL task checkboxes as work is completed\n"
        raise RuntimeError(error_msg)

    # Check if files already exist in completed directory
    if fr_new_path.exists() or impl_new_path.exists():
        # Diff active vs completed
        fr_same = False
        impl_same = False

        if fr_new_path.exists():
            fr_same = fr_old_path.read_text() == fr_new_path.read_text()

        if impl_new_path.exists():
            impl_same = impl_old_path.read_text() == impl_new_path.read_text()

        # If both exist and are identical, just delete active files
        if fr_new_path.exists() and impl_new_path.exists() and fr_same and impl_same:
            print("ℹ️  Files already exist in completed directory and are identical")
            print(f"   Removing active files: {fr_old_path.name}, {impl_old_path.name}")
            try:
                subprocess.run(
                    ["git", "rm", str(fr_old_path)],
                    check=True,
                    capture_output=True,
                    timeout=GIT_TIMEOUT_S,
                )
                subprocess.run(
                    ["git", "rm", str(impl_old_path)],
                    check=True,
                    capture_output=True,
                    timeout=GIT_TIMEOUT_S,
                )
            except subprocess.TimeoutExpired as e:
                raise RuntimeError(
                    "git rm timed out while removing duplicate active files. "
                    "Another git process may be holding the index lock (e.g., .git/index.lock)."
                ) from e

            # Update status to Completed in the existing completed files.
            # Without this, files that were copied/moved before status update
            # would retain stale statuses (e.g., IMPL="Ready").
            from nspec.runtime.atomic import atomic_write

            completed_status = FR_STATUSES[FRStatusCode.COMPLETED].full

            _fr_content = fr_new_path.read_text(encoding="utf-8")
            _fr_content = re.sub(
                r"^\*\*Status:\*\*.*$",
                f"**Status:** {completed_status}",
                _fr_content,
                flags=re.MULTILINE,
            )
            atomic_write(fr_new_path, _fr_content)

            _impl_content = impl_new_path.read_text(encoding="utf-8")
            _impl_content = re.sub(
                r"^\*\*Status:\*\*.*$",
                f"**Status:** {completed_status}",
                _impl_content,
                flags=re.MULTILINE,
            )
            atomic_write(impl_new_path, _impl_content)

            # Stage the updated files
            git_cwd = docs_root.parent
            try:
                subprocess.run(
                    ["git", "add", str(fr_new_path), str(impl_new_path)],
                    check=True,
                    capture_output=True,
                    timeout=GIT_TIMEOUT_S,
                    cwd=git_cwd,
                )
            except subprocess.CalledProcessError as e:
                raise RuntimeError(
                    f"git add failed after status update for {spec_id}: {e.stderr}. "
                    "Disk content is correct but git index is stale."
                ) from e
            except subprocess.TimeoutExpired as e:
                raise RuntimeError(
                    "git add timed out after status update. "
                    "Another git process may be holding the index lock."
                ) from e

            return fr_old_path, fr_new_path, impl_old_path, impl_new_path

        # If files differ, raise error
        error_msg = "Files already exist in completed directory but differ:\n"
        if fr_new_path.exists() and not fr_same:
            error_msg += f"  - {fr_new_path} differs from {fr_old_path}\n"
        if impl_new_path.exists() and not impl_same:
            error_msg += f"  - {impl_new_path} differs from {impl_old_path}\n"
        error_msg += "Manual resolution required."
        raise RuntimeError(error_msg)

    # Ensure completed directory exists
    completed_dir.mkdir(parents=True, exist_ok=True)

    # Move both files in a single git mv call — if it fails, both files stay
    # in active/ with Ready status and complete() can be safely re-run.
    git_cwd = docs_root.parent
    try:
        subprocess.run(
            ["git", "mv", str(fr_old_path), str(impl_old_path), str(completed_dir) + "/"],
            check=True,
            capture_output=True,
            text=True,
            cwd=git_cwd,
            timeout=GIT_TIMEOUT_S,
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"git mv failed: {e.stderr}") from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(
            "git mv timed out while completing the spec. "
            "Another git process may be holding the index lock (e.g., .git/index.lock)."
        ) from e

    # Update status to Completed in the destination files (after successful move)
    from nspec.runtime.atomic import atomic_write

    completed_status = FR_STATUSES[FRStatusCode.COMPLETED].full

    fr_content = fr_new_path.read_text(encoding="utf-8")
    fr_content = re.sub(
        r"^\*\*Status:\*\*.*$", f"**Status:** {completed_status}", fr_content, flags=re.MULTILINE
    )
    atomic_write(fr_new_path, fr_content)

    impl_content = impl_new_path.read_text(encoding="utf-8")
    impl_content = re.sub(
        r"^\*\*Status:\*\*.*$", f"**Status:** {completed_status}", impl_content, flags=re.MULTILINE
    )
    atomic_write(impl_new_path, impl_content)

    # Stage the updated files so the git index reflects the status change.
    # Without this, `git mv` stages the pre-update content and a subsequent
    # `git commit` (without `git add -A`) would commit stale statuses.
    try:
        subprocess.run(
            ["git", "add", str(fr_new_path), str(impl_new_path)],
            check=True,
            capture_output=True,
            timeout=GIT_TIMEOUT_S,
            cwd=git_cwd,
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"git add failed after status update for {spec_id}: {e.stderr}. "
            "Disk content is correct but git index is stale."
        ) from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(
            "git add timed out after status update. "
            "Another git process may be holding the index lock."
        ) from e

    print(f"✅ Updated status to completed for {spec_id}")

    # S926: invalidate cache after moving spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    # Best-effort: close linked GitHub issue (if any)
    from nspec.integrations.github import close_linked_issue

    close_linked_issue(fr_new_path, f"Completed via nspec {spec_id}", spec_id)

    # Show post-completion checklist
    print(f"\n✅ Spec {spec_id} completed successfully!")
    print(f"   • Moved: {fr_old_path.name} → docs/completed/done/")
    print(f"   • Moved: {impl_old_path.name} → docs/completed/done/")
    print("\n📋 Post-Completion Checklist:")
    print("   1. Run: make nspec")
    print("      → Regenerates NSPEC.md (removes from active)")
    print("      → Auto-updates NSPEC_COMPLETED.md (adds to completed)")
    print("   2. Run: make nspec.validate-consistency")
    print("      → Final consistency check")
    print("   3. Optional: Document this work session")
    print(f"      → Create: docs/08-sessions/session-YYYY-MM-DD-spec-{spec_id}-summary.md")
    print("   4. Run: make all")
    print("      → Full validation (tests, lint, security)")
    print("   5. Commit:")
    print("      → git add .")
    print(f'      → git commit -m "feat: Complete Spec {spec_id}"')
    print()

    # Post-move integrity: verify files exist at destination
    if not fr_new_path.exists():
        raise NspecIntegrityError(spec_id, str(fr_new_path), "FR file missing after move")
    if not impl_new_path.exists():
        raise NspecIntegrityError(spec_id, str(impl_new_path), "IMPL file missing after move")

    return fr_old_path, fr_new_path, impl_old_path, impl_new_path


def supersede_spec(
    spec_id: str,
    superseded_by: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path, Path, Path]:
    """Move FR + IMPL files to completed/superseded/ directory using git mv.

    Sets FR status to Superseded, IMPL status to Paused, and records
    which spec/epic replaces this one. Unlike complete_spec(), this does
    NOT require all acceptance criteria or tasks to be done.

    Args:
        spec_id: Spec ID to supersede (e.g., "S027")
        superseded_by: Spec/epic ID that replaces this one (e.g., "E002")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        (fr_old_path, fr_new_path, impl_old_path, impl_new_path)

    Raises:
        FileNotFoundError: If FR or IMPL not found in active directories
        RuntimeError: If git mv fails or files already exist in superseded directory
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    import subprocess

    from nspec.config import NspecConfig

    _cfg = NspecConfig.load(project_root)
    GIT_TIMEOUT_S = _cfg.timeouts.git_s

    # Find FR and IMPL files in active directories
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    fr_dir = paths.active_frs_dir
    impl_dir = paths.active_impls_dir
    superseded_dir = paths.completed_superseded

    fr_files = list(fr_dir.glob(fr_pattern))
    impl_files = list(impl_dir.glob(impl_pattern))

    # Check if files are already in superseded directory
    if not fr_files or not impl_files:
        superseded_fr_files = list(superseded_dir.glob(fr_pattern))
        superseded_impl_files = list(superseded_dir.glob(impl_pattern))

        if superseded_fr_files and superseded_impl_files:
            print(f"🔄 Spec {spec_id} is already superseded")
            print(f"   FR: {superseded_fr_files[0].relative_to(docs_root)}")
            print(f"   IMPL: {superseded_impl_files[0].relative_to(docs_root)}")
            return (
                fr_dir / superseded_fr_files[0].name,
                superseded_fr_files[0],
                impl_dir / superseded_impl_files[0].name,
                superseded_impl_files[0],
            )

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")
    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    fr_old_path = fr_files[0]
    impl_old_path = impl_files[0]

    fr_new_path = superseded_dir / fr_old_path.name
    impl_new_path = superseded_dir / impl_old_path.name

    # Check if files already exist in superseded directory
    if fr_new_path.exists() or impl_new_path.exists():
        raise RuntimeError(
            f"Files already exist in superseded directory:\n"
            f"  - {fr_new_path.relative_to(docs_root)}\n"
            f"  - {impl_new_path.relative_to(docs_root)}\n"
            "Manual resolution required."
        )

    # Update statuses before moving files
    fr_content = fr_old_path.read_text()
    impl_content = impl_old_path.read_text()

    superseded_status = FR_STATUSES[FRStatusCode.SUPERSEDED].full
    paused_status = IMPL_STATUSES[IMPLStatusCode.PAUSED].full

    fr_content = re.sub(
        r"^\*\*Status:\*\*.*$",
        f"**Status:** {superseded_status}",
        fr_content,
        flags=re.MULTILINE,
    )
    # Record which spec supersedes this one (insert after Status line in FR)
    fr_content = re.sub(
        rf"(\*\*Status:\*\* {re.escape(superseded_status)})",
        rf"\1\n**Superseded by:** {superseded_by}",
        fr_content,
    )
    impl_content = re.sub(
        r"^\*\*Status:\*\*.*$",
        f"**Status:** {paused_status}",
        impl_content,
        flags=re.MULTILINE,
    )

    fr_old_path.write_text(fr_content)
    impl_old_path.write_text(impl_content)

    print(f"🔄 Updated status to superseded for Spec {spec_id} (by {superseded_by})")

    # Ensure superseded directory exists
    superseded_dir.mkdir(parents=True, exist_ok=True)

    # Use git mv to move files
    git_cwd = docs_root.parent
    try:
        subprocess.run(
            ["git", "mv", str(fr_old_path), str(fr_new_path)],
            check=True,
            capture_output=True,
            text=True,
            cwd=git_cwd,
            timeout=GIT_TIMEOUT_S,
        )
        subprocess.run(
            ["git", "mv", str(impl_old_path), str(impl_new_path)],
            check=True,
            capture_output=True,
            text=True,
            cwd=git_cwd,
            timeout=GIT_TIMEOUT_S,
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"git mv failed: {e.stderr}") from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(
            "git mv timed out while superseding the spec. "
            "Another git process may be holding the index lock."
        ) from e

    # Post-move integrity check
    if not fr_new_path.exists():
        raise NspecIntegrityError(spec_id, str(fr_new_path), "FR file missing after move")
    if not impl_new_path.exists():
        raise NspecIntegrityError(spec_id, str(impl_new_path), "IMPL file missing after move")

    # S926: invalidate cache after moving spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    print(f"\n🔄 Spec {spec_id} superseded successfully!")
    print(f"   Superseded by: {superseded_by}")
    print(f"   Moved: {fr_old_path.name} → completed/superseded/")
    print(f"   Moved: {impl_old_path.name} → completed/superseded/")

    # Close linked GitHub issue if present
    from nspec.integrations.github import close_linked_issue

    close_linked_issue(fr_new_path, f"Superseded by {superseded_by} via nspec {spec_id}", spec_id)

    return fr_old_path, fr_new_path, impl_old_path, impl_new_path


def reject_spec(
    spec_id: str,
    docs_root: Path,
    force: bool = False,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path, Path, Path]:
    """Move a spec to the rejected directory.

    This is used when a spec has been rejected (won't implement, duplicate, etc).
    The spec is moved from active directories (10/11) to docs/completed/rejected/
    and its status is updated to Rejected.

    Args:
        spec_id: Spec ID to reject (e.g., "281")
        docs_root: Path to docs/ directory
        force: If True, skip validation checks
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Tuple of (fr_old_path, fr_new_path, impl_old_path, impl_new_path)

    Raises:
        FileNotFoundError: If FR or IMPL not found in active directories
        RuntimeError: If git mv fails or files already exist in rejected directory
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    import subprocess

    # Find FR and IMPL files in active directories
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    fr_dir = paths.active_frs_dir
    impl_dir = paths.active_impls_dir
    rejected_dir = paths.rejected_dir

    fr_files = list(fr_dir.glob(fr_pattern))
    impl_files = list(impl_dir.glob(impl_pattern))

    # Check if files are already in rejected directory
    if not fr_files or not impl_files:
        rejected_fr_files = list(rejected_dir.glob(fr_pattern))
        rejected_impl_files = list(rejected_dir.glob(impl_pattern))

        if rejected_fr_files and rejected_impl_files:
            print(f"✅ Spec {spec_id} is already rejected")
            print(f"   FR: {rejected_fr_files[0].relative_to(docs_root)}")
            print(f"   IMPL: {rejected_impl_files[0].relative_to(docs_root)}")
            return (
                fr_dir / rejected_fr_files[0].name,  # Dummy old path
                rejected_fr_files[0],
                impl_dir / rejected_impl_files[0].name,  # Dummy old path
                rejected_impl_files[0],
            )

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")
    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    # Take first match (should only be one)
    fr_old_path = fr_files[0]
    impl_old_path = impl_files[0]

    fr_new_path = rejected_dir / fr_old_path.name
    impl_new_path = rejected_dir / impl_old_path.name

    # Check if files already exist in rejected directory
    if fr_new_path.exists() or impl_new_path.exists():
        raise RuntimeError(
            f"Files already exist in rejected directory:\n"
            f"  - {fr_new_path.relative_to(docs_root)}\n"
            f"  - {impl_new_path.relative_to(docs_root)}\n"
            "Manual resolution required."
        )

    # Update status to rejected before moving files
    fr_content = fr_old_path.read_text()
    impl_content = impl_old_path.read_text()

    # Replace status with rejected status (using centralized status definitions)
    rejected_status = FR_STATUSES[FRStatusCode.REJECTED].full
    hold_status = IMPL_STATUSES[IMPLStatusCode.HOLD].full
    fr_content = re.sub(
        r"^\*\*Status:\*\*.*$", f"**Status:** {rejected_status}", fr_content, flags=re.MULTILINE
    )
    impl_content = re.sub(
        r"^\*\*Status:\*\*.*$", f"**Status:** {hold_status}", impl_content, flags=re.MULTILINE
    )

    # Write updated content
    fr_old_path.write_text(fr_content)
    impl_old_path.write_text(impl_content)

    print(f"✅ Updated status to rejected for Spec {spec_id}")

    # Ensure rejected directory exists
    rejected_dir.mkdir(parents=True, exist_ok=True)

    # Use git mv to move files
    # Run git commands from the project root (parent of docs_root)
    git_cwd = docs_root.parent
    try:
        subprocess.run(
            ["git", "mv", str(fr_old_path), str(fr_new_path)],
            check=True,
            capture_output=True,
            text=True,
            cwd=git_cwd,
        )
        subprocess.run(
            ["git", "mv", str(impl_old_path), str(impl_new_path)],
            check=True,
            capture_output=True,
            text=True,
            cwd=git_cwd,
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"git mv failed: {e.stderr}") from e

    # S926: invalidate cache after moving spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    # Show post-reject message
    print(f"\n❌ Spec {spec_id} rejected successfully!")
    print(f"   • Moved: {fr_old_path.name} → docs/completed/rejected/")
    print(f"   • Moved: {impl_old_path.name} → docs/completed/rejected/")
    print("\n📋 Next Steps:")
    print("   1. Run: make nspec")
    print("      → Regenerates NSPEC.md")
    print("   2. Commit:")
    print("      → git add .")
    print(f'      → git commit -m "chore: Reject Spec {spec_id}"')
    print()

    # Close linked GitHub issue if one exists
    from nspec.integrations.github import close_linked_issue

    close_linked_issue(fr_new_path, f"Rejected via nspec {spec_id}", spec_id)

    return fr_old_path, fr_new_path, impl_old_path, impl_new_path


def finalize_spec(
    spec_id: str,
    docs_root: Path,
    execute: bool = False,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> None:
    """Show completion status and provide command to finalize a spec.

    Lists all unchecked acceptance criteria and tasks, then provides
    a single make command that will mark everything complete and archive.

    Args:
        spec_id: Spec ID to finalize (e.g., "183")
        docs_root: Path to docs/ directory
        execute: If True, actually mark everything complete and run complete
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        None (prints to stdout)

    Raises:
        FileNotFoundError: If FR or IMPL not found
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR and IMPL files
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    fr_dir = paths.active_frs_dir
    impl_dir = paths.active_impls_dir

    fr_files = list(fr_dir.glob(fr_pattern))
    impl_files = list(impl_dir.glob(impl_pattern))

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")
    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    fr_path = fr_files[0]
    impl_path = impl_files[0]
    fr_content = fr_path.read_text()
    impl_content = impl_path.read_text()

    # Extract unchecked acceptance criteria
    unchecked_criteria = []
    for match in re.finditer(r"^- \[ \]\s*(AC-[FQPD]\d+:?.*)$", fr_content, re.MULTILINE):
        unchecked_criteria.append(match.group(1).strip())

    # Extract unchecked IMPL tasks
    unchecked_tasks = []
    for match in re.finditer(
        r"^- \[ \]\s*\*\*(\d+\.\d+)\*\*:?\s*(.*)$", impl_content, re.MULTILINE
    ):
        task_id = match.group(1)
        task_desc = match.group(2).strip()[:50]  # Truncate for display
        unchecked_tasks.append(f"{task_id}: {task_desc}")

    # Check status
    fr_status = re.search(r"^\*\*Status:\*\*\s+(.+)$", fr_content, re.MULTILINE)
    impl_status = re.search(r"^\*\*Status:\*\*\s+(.+)$", impl_content, re.MULTILINE)

    fr_complete = fr_status and is_completed_status(fr_status.group(1))
    impl_complete = impl_status and is_completed_status(impl_status.group(1))

    if execute:
        # Mark all unchecked criteria as complete
        updated_fr = fr_content
        for _ in unchecked_criteria:
            updated_fr = re.sub(
                r"^(- )\[ \](\s*AC-[FQPD])", r"\1[x]\2", updated_fr, count=1, flags=re.MULTILINE
            )

        # Mark all unchecked tasks as complete
        updated_impl = impl_content
        updated_impl = re.sub(
            r"^(- )\[ \](\s*\*\*\d+\.\d+\*\*)", r"\1[x]\2", updated_impl, flags=re.MULTILINE
        )

        # Update status to Completed (using centralized status definition)
        completed_status = FR_STATUSES[FRStatusCode.COMPLETED].full
        updated_fr = re.sub(
            r"^\*\*Status:\*\*.*$",
            f"**Status:** {completed_status}",
            updated_fr,
            flags=re.MULTILINE,
        )
        updated_impl = re.sub(
            r"^\*\*Status:\*\*.*$",
            f"**Status:** {completed_status}",
            updated_impl,
            flags=re.MULTILINE,
        )

        # Write files
        fr_path.write_text(updated_fr)
        impl_path.write_text(updated_impl)

        # S926: invalidate cache after writing spec files
        from nspec.domain.datasets import invalidate_dataset_cache

        invalidate_dataset_cache(docs_root)

        print(f"✅ Marked {len(unchecked_criteria)} acceptance criteria complete")
        print(f"✅ Marked {len(unchecked_tasks)} IMPL tasks complete")
        print("✅ Updated FR to Completed and IMPL to Ready")
        print()
        print(f"Now run: make nspec.complete {spec_id}")
        return

    # Display mode - show what needs to be done
    print(f"\n📋 Spec {spec_id} Completion Status")
    print("=" * 50)

    # Status
    print("\n📊 Status:")
    print(
        f"   FR:   {fr_status.group(1) if fr_status else 'Unknown'} {'✅' if fr_complete else '❌'}"
    )
    impl_status_text = impl_status.group(1) if impl_status else "Unknown"
    impl_check = "✅" if impl_complete else "❌"
    print(f"   IMPL: {impl_status_text} {impl_check}")

    # Unchecked criteria
    if unchecked_criteria:
        print(f"\n📝 Unchecked Acceptance Criteria ({len(unchecked_criteria)}):")
        for ac in unchecked_criteria:
            print(f"   - [ ] {ac}")
    else:
        print("\n✅ All acceptance criteria complete")

    # Unchecked tasks
    if unchecked_tasks:
        print(f"\n📝 Unchecked IMPL Tasks ({len(unchecked_tasks)}):")
        for task in unchecked_tasks[:10]:  # Limit display
            print(f"   - [ ] {task}")
        if len(unchecked_tasks) > 10:
            print(f"   ... and {len(unchecked_tasks) - 10} more")
    else:
        print("\n✅ All IMPL tasks complete")

    # Provide finalize command
    needs_work = unchecked_criteria or unchecked_tasks or not fr_complete or not impl_complete
    if needs_work:
        print("\n🚀 To mark everything complete and archive:")
        print(f"   make nspec.finalize {spec_id} EXECUTE=1")
        print()
        print("   This will:")
        if unchecked_criteria:
            print(f"   • Mark {len(unchecked_criteria)} acceptance criteria as [x]")
        if unchecked_tasks:
            print(f"   • Mark {len(unchecked_tasks)} IMPL tasks as [x]")
        if not fr_complete or not impl_complete:
            print("   • Set FR to ✅ Completed and IMPL to 🟠 Ready")
        print(f"   • Then run: make nspec.complete {spec_id}")
    else:
        print(f"\n✅ Spec {spec_id} is ready for completion!")
        print(f"   Run: make nspec.complete {spec_id}")

    print()


def force_archive_spec(
    spec_id: str,
    reason: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Force-archive a spec by bulk-marking tasks/ACs and moving to completed/done.

    Use when a spec is stuck in an inconsistent state (e.g., FR marked Completed
    but IMPL tasks unchecked) and ``complete()`` rejects it.

    Args:
        spec_id: Spec ID to force-archive (e.g., "S659")
        reason: Required reason explaining why the override is needed
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config.toml (default: cwd)

    Returns:
        Summary dict with counts of auto-completed items and paths.

    Raises:
        FileNotFoundError: If FR or IMPL not found in active directories.
        ValueError: If FR status is not Active or Completed (safety guard).
    """
    from datetime import datetime

    from nspec.runtime.atomic import atomic_write

    if not reason or not reason.strip():
        raise ValueError("reason is required for force_archive (cannot be empty)")
    reason = reason.strip()

    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR and IMPL files in active directories
    fr_pattern = f"FR-{spec_id}-*.md"
    impl_pattern = f"IMPL-{spec_id}-*.md"

    fr_dir = paths.active_frs_dir
    impl_dir = paths.active_impls_dir

    fr_files = list(fr_dir.glob(fr_pattern))
    impl_files = list(impl_dir.glob(impl_pattern))

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")
    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    fr_path = fr_files[0]
    impl_path = impl_files[0]
    fr_content = fr_path.read_text(encoding="utf-8")
    impl_content = impl_path.read_text(encoding="utf-8")

    # Safety guard: only allow force-archive for specs with Active or Completed FR
    fr_status_match = re.search(r"^\*\*Status:\*\*\s+(.+)$", fr_content, re.MULTILINE)
    if not fr_status_match:
        raise ValueError(
            f"Cannot force-archive {spec_id}: FR has no **Status:** field. "
            f"The file may be malformed."
        )
    fr_status_text = fr_status_match.group(1).strip()
    # Use word-boundary check to prevent substring matches (e.g., "Inactive")
    status_ok = bool(
        re.search(r"\bActive\b", fr_status_text, re.IGNORECASE)
        or re.search(r"\bCompleted\b", fr_status_text, re.IGNORECASE)
    )
    if not status_ok:
        raise ValueError(
            f"Cannot force-archive {spec_id}: FR status is '{fr_status_text}'. "
            f"Only specs with Active or Completed FR status can be force-archived "
            f"(safety guard against archiving unworked specs)."
        )

    # Bulk-mark unchecked FR ACs as [x] with (force_archive) tag
    ac_count = 0

    def _mark_fr_ac(m: re.Match[str]) -> str:
        nonlocal ac_count
        ac_count += 1
        return f"{m.group(1)}[x]{m.group(2)} (force_archive)"

    updated_fr = re.sub(
        r"^(- )\[ \](\s*AC-[FQPD]\d+:?.*)$",
        _mark_fr_ac,
        fr_content,
        flags=re.MULTILINE,
    )

    # Bulk-mark unchecked IMPL tasks as [x] with (force_archive) tag
    task_count = 0

    def _mark_impl_task(m: re.Match[str]) -> str:
        nonlocal task_count
        task_count += 1
        return f"{m.group(1)}[x]{m.group(2)} (force_archive)"

    updated_impl = re.sub(
        r"^(- )\[ \](\s+.*)$",
        _mark_impl_task,
        impl_content,
        flags=re.MULTILINE,
    )

    # Set FR to Completed and IMPL to Ready (canonical pre-archive states)
    fr_completed_status = FR_STATUSES[FRStatusCode.COMPLETED].full
    impl_ready_status = IMPL_STATUSES[IMPLStatusCode.READY].full
    updated_fr = re.sub(
        r"^\*\*Status:\*\*.*$",
        f"**Status:** {fr_completed_status}",
        updated_fr,
        flags=re.MULTILINE,
    )
    updated_impl = re.sub(
        r"^\*\*Status:\*\*.*$",
        f"**Status:** {impl_ready_status}",
        updated_impl,
        flags=re.MULTILINE,
    )

    # Append reason to Session Notes
    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
    session_note = (
        f"\n### {timestamp} -- force_archive\n\n"
        f"- **Reason:** {reason}\n"
        f"- **Tasks auto-completed:** {task_count}\n"
        f"- **ACs auto-completed:** {ac_count}\n"
    )

    if "## Session Notes" in updated_impl:
        updated_impl = updated_impl.replace(
            "## Session Notes",
            f"## Session Notes\n{session_note}",
        )
    else:
        updated_impl += f"\n## Session Notes\n{session_note}"

    # Write updated files
    atomic_write(fr_path, updated_fr)
    atomic_write(impl_path, updated_impl)

    # Move files to completed/done directly.  We intentionally bypass
    # complete_spec() because its validation (review verdict, dep checks)
    # is exactly what force_archive is designed to override.  We still
    # handle the "already exists in completed" conflict safely.
    import shutil

    completed_dir = paths.completed_done
    completed_dir.mkdir(parents=True, exist_ok=True)
    fr_new = completed_dir / fr_path.name
    impl_new = completed_dir / impl_path.name

    # Conflict guard: refuse if different content already archived
    for src, dst in ((fr_path, fr_new), (impl_path, impl_new)):
        if dst.exists():
            if src.read_text(encoding="utf-8") != dst.read_text(encoding="utf-8"):
                raise RuntimeError(
                    f"Cannot force-archive {spec_id}: {dst.name} already exists "
                    f"in completed/done with different content. Manual resolution required."
                )
            # Identical -- remove active copy, keep archived
            src.unlink()
        else:
            shutil.move(str(src), str(dst))

    # Normalize IMPL to Completed status in the archived file (canonical
    # post-archive state is Completed, not Ready).
    impl_archived = impl_new.read_text(encoding="utf-8")
    impl_archived = re.sub(
        r"^\*\*Status:\*\*.*$",
        f"**Status:** {fr_completed_status}",
        impl_archived,
        flags=re.MULTILINE,
    )
    atomic_write(impl_new, impl_archived)

    _git_add(fr_new)
    _git_add(impl_new)

    return {
        "spec_id": spec_id,
        "tasks_auto_completed": task_count,
        "criteria_auto_completed": ac_count,
        "status_fixed": f"FR -> {fr_completed_status}, IMPL -> Completed",
        "archived_to": str(paths.completed_done),
        "reason": reason,
        "fr_path": str(fr_new),
        "impl_path": str(impl_new),
    }
