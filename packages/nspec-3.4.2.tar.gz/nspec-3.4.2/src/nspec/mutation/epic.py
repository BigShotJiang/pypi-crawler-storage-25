"""Epic-scoped queries and bulk operations."""

from pathlib import Path
from typing import Any

from nspec.domain.ids import normalize_spec_ref
from nspec.domain.statuses import is_completed_status, parse_status_text
from nspec.paths import NspecPaths


def auto_assign_ungrouped_to_epic(
    default_epic: str,
    docs_root: Path,
) -> list[tuple[str, str]]:
    """Find ungrouped specs and add them to the default epic.

    A spec is "ungrouped" if it's not a dependency of any epic.
    This function adds all ungrouped non-epic specs to the specified
    default epic's deps list.

    Args:
        default_epic: Epic ID to assign ungrouped specs to (e.g., "215")
        docs_root: Path to docs/ directory

    Returns:
        List of (spec_id, epic_id) tuples that were added

    Raises:
        FileNotFoundError: If default epic FR not found
    """
    from nspec.domain.datasets import DatasetLoader

    loader = DatasetLoader(docs_root)
    datasets = loader.load()

    default_epic = normalize_spec_ref(default_epic)
    epic_fr = datasets.active_frs.get(default_epic)
    if not epic_fr:
        raise FileNotFoundError(f"Epic FR-{default_epic} not found in active nspec")

    if not epic_fr.is_epic:
        raise ValueError(f"Spec {default_epic} is not an epic (type: {epic_fr.type})")

    # S256: determine grouped/ungrouped state via the membership DAO.
    from nspec.dao.markdown.epic_membership_dao import MarkdownEpicMembershipDAO

    dao_paths_config = None
    membership_dao = MarkdownEpicMembershipDAO(docs_root, paths_config=dao_paths_config)
    memberships_map = MarkdownEpicMembershipDAO.compute_memberships_from_datasets(datasets)

    ungrouped_specs = []
    for spec_id, fr in datasets.active_frs.items():
        if fr.is_epic:
            continue
        if "superseded" in fr.status.lower():
            continue
        if spec_id not in memberships_map:
            ungrouped_specs.append(spec_id)

    if not ungrouped_specs:
        return []

    assigned = []
    for spec_id in ungrouped_specs:
        try:
            membership_dao.set_owner(spec_id, default_epic)
            assigned.append((spec_id, default_epic))
        except (ValueError, FileNotFoundError):
            continue  # Skip on failure

    return assigned


# ============================================================================
# ADR (Architecture Decision Record) Management
# ============================================================================


def get_epic_specs(
    epic_id: str,
    docs_root: Path,
    *,
    status_filter: str | None = None,
    starting_spec_id: str | None = None,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> list[dict[str, str]]:
    """Get specs belonging to an epic, optionally filtered by status.

    Args:
        epic_id: Epic ID (e.g., "E002")
        docs_root: Path to docs/ directory
        status_filter: One of "completed", "incomplete", "paused", or None (all)
        starting_spec_id: If provided, slice the sorted member list from this
            spec ID onward (inclusive).  Returns an empty list when the ID is
            not a member of the epic.
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        List of dicts with spec_id, title, fr_status, impl_status keys.

    Raises:
        FileNotFoundError: If epic FR not found
        ValueError: If epic has no deps or invalid status_filter
    """
    from nspec.domain.datasets import DatasetLoader

    epic_id = normalize_spec_ref(epic_id)
    if status_filter is not None and status_filter not in (
        "completed",
        "incomplete",
        "paused",
    ):
        raise ValueError(
            f"Invalid status_filter: {status_filter!r}. "
            "Must be 'completed', 'incomplete', 'paused', or None."
        )

    loader = DatasetLoader(docs_root, paths_config=paths_config, project_root=project_root)
    datasets = loader.load()

    epic_fr = datasets.get_fr(epic_id)
    if not epic_fr:
        raise FileNotFoundError(f"Epic {epic_id} not found")

    # S256: resolve epic children through the membership DAO rather than by
    # scanning epic.deps directly. Membership now lives on the child spec.
    from nspec.dao.markdown.epic_membership_dao import MarkdownEpicMembershipDAO

    memberships_map = MarkdownEpicMembershipDAO.compute_memberships_from_datasets(datasets)
    dep_ids = sorted(sid for sid, eid in memberships_map.items() if eid == epic_id)

    # S939: slice from a given spec ID onward
    if starting_spec_id is not None:
        normalized_start = normalize_spec_ref(starting_spec_id)
        if normalized_start not in dep_ids:
            return []
        start_idx = dep_ids.index(normalized_start)
        dep_ids = dep_ids[start_idx:]

    results: list[dict[str, str]] = []

    for dep_id in dep_ids:
        fr = datasets.get_fr(dep_id)
        impl = datasets.get_impl(dep_id)
        if not fr:
            continue

        impl_status_text = parse_status_text(impl.status) if impl else ""

        # Determine if this spec is "completed"
        is_done = (
            is_completed_status(fr.status) and impl is not None and impl_status_text == "ready"
        ) or datasets.is_completed(dep_id)

        is_paused = impl_status_text == "paused"

        if status_filter == "completed" and not is_done:
            continue
        if status_filter == "incomplete" and is_done:
            continue
        if status_filter == "paused" and not is_paused:
            continue

        results.append(
            {
                "spec_id": dep_id,
                "title": fr.title,
                "fr_status": fr.status,
                "impl_status": impl.status if impl else "N/A",
            }
        )

    return results


def park_epic_specs(
    epic_id: str,
    docs_root: Path,
    *,
    reason: str | None = None,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, Any]:
    """Park all non-completed specs in an epic.

    Args:
        epic_id: Epic ID (e.g., "E002")
        docs_root: Path to docs/ directory
        reason: Optional reason to record in each IMPL
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Dict with parked (list of spec_ids), skipped (list), count (int).
    """
    incomplete = get_epic_specs(
        epic_id,
        docs_root,
        status_filter="incomplete",
        paths_config=paths_config,
        project_root=project_root,
    )

    parked: list[str] = []
    skipped: list[str] = []

    for spec in incomplete:
        sid = spec["spec_id"]
        impl_status_text = parse_status_text(spec["impl_status"])

        # Skip already paused specs
        if impl_status_text == "paused":
            skipped.append(sid)
            continue

        try:
            from nspec.mutation.state import park_spec

            park_spec(
                sid,
                docs_root,
                reason=reason,
                paths_config=paths_config,
                project_root=project_root,
            )
            parked.append(sid)
        except (ValueError, FileNotFoundError):
            skipped.append(sid)

    return {
        "parked": parked,
        "skipped": skipped,
        "count": len(parked),
    }
