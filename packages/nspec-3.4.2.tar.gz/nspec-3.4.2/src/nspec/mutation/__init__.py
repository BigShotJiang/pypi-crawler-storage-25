"""Mutation package — nspec's write-path operations.

This package is the single entry point for all spec mutation operations.
Functions are organized into focused submodules by concern:

- ``_helpers``: Shared private utilities (file locks, validation, lookup)
- ``lifecycle``: Spec creation, deletion, completion, superseding, rejection
- ``deps``: Dependency graph mutations and priority management
- ``progress``: Task and acceptance-criteria checkbox updates
- ``status``: Status transitions and state-pair validation
- ``review``: Review workflow (request, start, approve, request changes)
- ``loe``: Level-of-effort calculation and updates
- ``state``: Spec state management (park, hold, reset, recover, exception)
- ``epic``: Epic-scoped queries and bulk operations
- ``adr``: Architecture Decision Record management
"""

# --- _helpers (private, but some are used by workflow/ and mcp_server) ---
# Constant re-exports
# Private constants used by some callers
from contextlib import suppress

from nspec.mutation._helpers import (  # noqa: F401
    NspecIntegrityError,
    _file_lock,
    _find_impl_file,
    _get_current_status,
    _git_add,
    _line_matches_task_id,
    _NspecCrudErrors,
    _validate_after_write,
)

# --- adr ---
from nspec.mutation.adr import (  # noqa: F401
    create_adr,
    get_next_adr_id,
    list_adrs,
)

# --- deps ---
from nspec.mutation.deps import (  # noqa: F401
    _auto_update_dependency_priorities,
    _build_reverse_dependency_map,
    _calculate_effective_priority,
    _check_dependency_cycle,
    _check_epic_priority_unique,
    _epic_priority_from_id,
    _find_dependent_specs,
    _get_priority_level,
    _next_available_epic_priority,
    add_dependency,
    check_cross_epic_dependency,
    move_dependency,
    remove_dependency,
    set_priority,
    swap_priority,
)

# --- epic ---
from nspec.mutation.epic import (  # noqa: F401
    auto_assign_ungrouped_to_epic,
    get_epic_specs,
    park_epic_specs,
)

# --- lifecycle ---
from nspec.mutation.lifecycle import (  # noqa: F401
    DuplicateSpecIdError,
    _allocate_and_reserve,
    _check_completion_readiness,
    _collect_all_existing_spec_ids,
    _get_id_ranges,
    _get_ids_with_fallback,
    _pick_next_id,
    _prune_reservations,
    _read_reservations,
    _reservation_path,
    _reserve_id,
    clean_dangling_deps,
    complete_spec,
    create_new_spec,
    delete_spec,
    finalize_spec,
    find_duplicate_spec_ids,
    force_archive_spec,
    get_all_spec_ids,
    get_next_spec_id,
    reject_spec,
    renumber_spec,
    supersede_spec,
    unify_collisions,
)

# --- loe ---
from nspec.mutation.loe import (  # noqa: F401
    _format_hours_to_loe,
    _loe_component_to_hours,
    _parse_loe_to_hours,
    calculate_epic_loe,
    set_loe,
    update_epic_loe,
)

# --- progress ---
from nspec.mutation.progress import (  # noqa: F401
    _check_files_modified,
    _check_sequential_order,
    _check_subtasks_complete,
    _find_task_by_id,
    _parse_task_file_annotations,
    check_acceptance_criteria,
    check_impl_task,
    set_task_blocked,
    set_task_unblocked,
    validate_spec_criteria,
)

# --- review ---
from nspec.mutation.review import (  # noqa: F401
    _add_review_note,
    _append_review_history_row,
    _get_impl_field,
    _get_review_round,
    _get_review_verdict,
    _set_impl_field,
    _set_review_verdict,
    approve_review,
    get_review_status,
    request_changes,
    request_review,
    start_review,
)

# --- state ---
from nspec.mutation.state import (  # noqa: F401
    _write_hold_reason,
    hold_spec,
    park_spec,
    recover_spec,
    reset_spec,
    set_exception,
    start_design_spec,
)

# --- status ---
from nspec.mutation.status import (  # noqa: F401
    VALID_FR_TRANSITIONS,
    VALID_IMPL_TRANSITIONS,
    _validate_transition,
    check_state_pair_warning,
    next_status,
    set_status,
)

with suppress(ImportError):
    from nspec.mutation.lifecycle import (  # noqa: F401
        _RESERVATION_TTL_SECONDS,
        EPIC_ID_RANGE,
        _active_reserved_ids,
        _read_reservation_data,
        _reservation_lock_path,
    )

__all__ = [
    # helpers
    "NspecIntegrityError",
    "_NspecCrudErrors",
    "_file_lock",
    "_find_impl_file",
    "_get_current_status",
    "_git_add",
    "_line_matches_task_id",
    "_validate_after_write",
    # lifecycle
    "DuplicateSpecIdError",
    "clean_dangling_deps",
    "complete_spec",
    "create_new_spec",
    "delete_spec",
    "finalize_spec",
    "find_duplicate_spec_ids",
    "force_archive_spec",
    "get_all_spec_ids",
    "get_next_spec_id",
    "reject_spec",
    "renumber_spec",
    "supersede_spec",
    "unify_collisions",
    # deps
    "add_dependency",
    "check_cross_epic_dependency",
    "move_dependency",
    "remove_dependency",
    "set_priority",
    "swap_priority",
    # progress
    "check_acceptance_criteria",
    "check_impl_task",
    "set_task_blocked",
    "set_task_unblocked",
    "validate_spec_criteria",
    # status
    "VALID_FR_TRANSITIONS",
    "VALID_IMPL_TRANSITIONS",
    "check_state_pair_warning",
    "next_status",
    "set_status",
    # review
    "approve_review",
    "get_review_status",
    "request_changes",
    "request_review",
    "start_review",
    # loe
    "calculate_epic_loe",
    "set_loe",
    "update_epic_loe",
    # state
    "hold_spec",
    "park_spec",
    "recover_spec",
    "reset_spec",
    "set_exception",
    "start_design_spec",
    # epic
    "auto_assign_ungrouped_to_epic",
    "get_epic_specs",
    "park_epic_specs",
    # adr
    "create_adr",
    "get_next_adr_id",
    "list_adrs",
]
