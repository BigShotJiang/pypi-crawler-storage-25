"""Dependency graph mutations and priority management."""

import re
from pathlib import Path

from nspec.domain.datasets import invalidate_dataset_cache
from nspec.domain.ids import normalize_spec_ref, spec_ref_number
from nspec.domain.statuses import get_priority_line_pattern
from nspec.mutation._helpers import (
    _NspecCrudErrors,
    _validate_after_write,
)
from nspec.paths import NspecPaths, get_paths


def _check_dependency_cycle(
    spec_id: str,
    new_dep_id: str,
    datasets: "NspecDatasets",  # noqa: F821
) -> None:
    """Check if adding spec_id → new_dep_id creates a dependency cycle.

    Builds the full dependency graph from datasets and does a DFS from new_dep_id
    to see if spec_id is reachable (which would mean a cycle).

    Raises:
        ValueError: If adding this dependency would create a cycle.
    """

    # Build adjacency list: spec → its deps
    graph: dict[str, list[str]] = {}
    all_frs = {**datasets.active_frs, **datasets.completed_frs}
    for sid, fr in all_frs.items():
        graph[sid] = list(fr.deps) if fr.deps else []

    # Simulate adding the new edge
    if spec_id not in graph:
        graph[spec_id] = []
    graph[spec_id] = [*graph[spec_id], new_dep_id]

    # DFS from new_dep_id to check if we can reach spec_id (cycle)
    visited: set[str] = set()
    stack: list[str] = [new_dep_id]
    while stack:
        current = stack.pop()
        if current == spec_id:
            # Found a cycle — trace the path for the error message
            raise ValueError(
                f"[{spec_id}] add_dependency: Adding dep {new_dep_id} "
                f"would create a cycle ({new_dep_id} → ... → {spec_id})"
            )
        if current in visited:
            continue
        visited.add(current)
        for dep in graph.get(current, []):
            if dep not in visited:
                stack.append(dep)


def check_cross_epic_dependency(
    spec_id: str,
    dep_id: str,
    datasets: "NspecDatasets",  # noqa: F821
) -> None:
    """Reject spec-level dependencies that cross epic boundaries.

    A spec in epic A cannot depend on a spec in epic B unless epic A
    has an explicit epic-level dependency on epic B (a cross-epic bridge).
    Epics themselves are exempt from this check.

    Args:
        spec_id: The spec that would gain the dependency.
        dep_id: The proposed dependency target.
        datasets: Loaded datasets for epic membership resolution.

    Raises:
        ValueError: If the dependency crosses epics without a bridge.
    """
    # Only check spec-to-spec deps (not epic targets or epic sources)
    spec_fr = datasets.active_frs.get(spec_id)
    dep_fr = datasets.active_frs.get(dep_id)

    # Skip if either spec isn't found or is an epic
    if not spec_fr or spec_fr.is_epic:
        return
    if not dep_fr or dep_fr.is_epic:
        return

    # S256: resolve spec-to-epic ownership through the membership DAO.
    from nspec.dao.markdown.epic_membership_dao import MarkdownEpicMembershipDAO

    memberships_map = MarkdownEpicMembershipDAO.compute_memberships_from_datasets(datasets)
    spec_epic: str | None = memberships_map.get(spec_id)
    dep_epic: str | None = memberships_map.get(dep_id)

    # If either spec is not in any epic, allow the dependency
    if spec_epic is None or dep_epic is None:
        return

    # Same epic is fine
    if spec_epic == dep_epic:
        return

    # Different epics — check for epic-level bridge
    bridge_epic_fr = datasets.active_frs.get(spec_epic)
    if bridge_epic_fr and dep_epic in (bridge_epic_fr.deps or []):
        return  # Cross-epic bridge exists

    raise ValueError(
        f"[{spec_id}] add_dependency: Cross-epic dependency rejected. "
        f"{spec_id} is in {spec_epic} but {dep_id} is in {dep_epic}. "
        f"Cross-epic ordering should be handled at the epic level "
        f"(add {dep_epic} as a dependency of {spec_epic})."
    )


def add_dependency(
    spec_id: str,
    dependency_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, Path | str | None]:
    """Add a dependency to a spec's FR file.

    Updates the deps: [...] line in the FR file to include the new dependency.
    Creates the deps line if it doesn't exist.

    If the target spec is an epic and the dependency already belongs to another
    epic, the dependency is automatically moved (removed from the old epic first).

    Args:
        spec_id: Spec ID to update (e.g., "093")
        dependency_id: Dependency to add (e.g., "090")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Dict with keys:
            - path: Path to updated FR file
            - moved_from: Epic ID if dependency was moved from another epic, None otherwise

    Raises:
        FileNotFoundError: If FR not found
        ValueError: If dependency already exists or is self-referential
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    import re

    from nspec.domain.datasets import DatasetLoader

    spec_id = normalize_spec_ref(spec_id)
    dependency_id = normalize_spec_ref(dependency_id)

    # Find FR file
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_dir = paths.active_frs_dir
    fr_files = list(fr_dir.glob(fr_pattern))

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")

    fr_path = fr_files[0]

    # Check for self-referential dependency
    if spec_id == dependency_id:
        raise ValueError(f"[{spec_id}] add_dependency: Cannot add self-referential dependency")

    # Track if we moved the dependency from another epic
    moved_from: str | None = None

    # Check if target is an epic and dependency is already in another epic
    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()
    target_fr = datasets.active_frs.get(spec_id)

    # Specs cannot depend on epics.
    if target_fr and not target_fr.is_epic and dependency_id.startswith("E"):
        raise ValueError(
            f"[{spec_id}] add_dependency: Specs cannot depend on epics. "
            f"Remove {dependency_id} from {spec_id}'s deps and add {spec_id} "
            f"to {dependency_id}'s deps instead."
        )

    # Cycle detection: build dependency graph and check if adding this edge creates a cycle
    _check_dependency_cycle(spec_id, dependency_id, datasets)

    # Cross-epic dependency check: reject spec-to-spec deps across epic boundaries
    check_cross_epic_dependency(spec_id, dependency_id, datasets)

    if target_fr and target_fr.is_epic:
        # Target is an epic - check if dependency is in another epic
        for epic_id, fr in datasets.active_frs.items():
            if fr.is_epic and epic_id != spec_id and dependency_id in fr.deps:
                # Dependency is in another epic - remove it first
                remove_dependency(epic_id, dependency_id, docs_root, paths_config, project_root)
                moved_from = epic_id
                break

    # Read current content
    content = fr_path.read_text()

    # Check if deps line exists
    deps_match = re.search(r"^deps:\s*\[(.*?)\]$", content, re.MULTILINE)

    if deps_match:
        # Parse existing dependencies
        deps_str = deps_match.group(1).strip()
        existing_deps = [d.strip() for d in deps_str.split(",") if d.strip()]

        # Check if dependency already exists
        if dependency_id in existing_deps:
            raise ValueError(
                f"[{spec_id}] add_dependency: Dependency {dependency_id} already exists"
            )

        # Add new dependency
        existing_deps.append(dependency_id)
        new_deps_str = ", ".join(existing_deps)
        new_deps_line = f"deps: [{new_deps_str}]"

        # Replace old deps line
        content = re.sub(r"^deps:\s*\[.*?\]$", new_deps_line, content, flags=re.MULTILINE)
    else:
        # Find where to insert deps line (after **Dependencies:** header or before ## section)
        # Look for **Dependencies:** section first
        deps_header_match = re.search(r"(\*\*Dependencies:\*\*\s*\n)", content, re.MULTILINE)

        if deps_header_match:
            # Insert after **Dependencies:** header
            insert_pos = deps_header_match.end()
            content = content[:insert_pos] + f"deps: [{dependency_id}]\n" + content[insert_pos:]
        else:
            # Insert before first ## section
            section_match = re.search(r"^## ", content, re.MULTILINE)
            if section_match:
                insert_pos = section_match.start()
                content = (
                    content[:insert_pos]
                    + f"\n**Dependencies:**\ndeps: [{dependency_id}]\n\n"
                    + content[insert_pos:]
                )
            else:
                # Append at end
                content += f"\n\n**Dependencies:**\ndeps: [{dependency_id}]\n"

    # Write updated content
    fr_path.write_text(content)
    invalidate_dataset_cache(docs_root)

    _validate_after_write(spec_id, docs_root, paths_config, check_impl=False)
    return {"path": fr_path, "moved_from": moved_from}


def remove_dependency(
    spec_id: str,
    dependency_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Remove a dependency from a spec's FR file.

    Updates the deps: [...] line in the FR file to remove the dependency.

    Args:
        spec_id: Spec ID to update (e.g., "093")
        dependency_id: Dependency to remove (e.g., "104")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated FR file

    Raises:
        FileNotFoundError: If FR not found
        ValueError: If dependency doesn't exist
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR file
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_dir = paths.active_frs_dir
    fr_files = list(fr_dir.glob(fr_pattern))

    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {fr_dir}")

    fr_path = fr_files[0]

    # Read current content
    content = fr_path.read_text()

    # Check if deps line exists
    deps_match = re.search(r"^deps:\s*\[(.*?)\]$", content, re.MULTILINE)

    if not deps_match:
        raise ValueError(f"No dependencies found in FR-{spec_id}")

    # Parse existing dependencies
    deps_str = deps_match.group(1).strip()
    existing_deps = [d.strip() for d in deps_str.split(",") if d.strip()]

    # Check if dependency exists
    if dependency_id not in existing_deps:
        raise ValueError(f"Dependency {dependency_id} not found in FR-{spec_id}")

    # Remove dependency
    existing_deps.remove(dependency_id)

    if existing_deps:
        # Update deps line with remaining dependencies
        new_deps_str = ", ".join(existing_deps)
        new_deps_line = f"deps: [{new_deps_str}]"
        content = re.sub(r"^deps:\s*\[.*?\]$", new_deps_line, content, flags=re.MULTILINE)
    else:
        # Remove entire deps line if no dependencies left
        content = re.sub(r"^deps:\s*\[.*?\]\n?", "", content, flags=re.MULTILINE)

    # Write updated content
    fr_path.write_text(content)
    invalidate_dataset_cache(docs_root)

    _validate_after_write(spec_id, docs_root, paths_config, check_impl=False)
    return fr_path


def move_dependency(
    spec_id: str,
    target_epic_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, list[str] | str | None]:
    """Move a spec to a target epic, removing from any other epics.

    This is a convenience method that:
    1. Finds all epics that currently have this spec as a dependency
    2. Removes the spec from all epics except the target
    3. Adds the spec to the target epic (if not already there)
    4. Auto-bumps the spec's priority if needed for parity

    Args:
        spec_id: Spec ID to move (e.g., "306")
        target_epic_id: Target epic ID (e.g., "297")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Dict with keys:
            - removed_from: List of epic IDs spec was removed from
            - added_to: Epic ID if added (None if already there)
            - priority_bumped: New priority if bumped (None if not)

    Raises:
        FileNotFoundError: If spec or epic FR not found
        ValueError: If target is not an epic
    """
    from nspec.domain.datasets import DatasetLoader

    spec_id = normalize_spec_ref(spec_id)
    target_epic_id = normalize_spec_ref(target_epic_id)

    # Load datasets to find current state
    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()

    # Verify target is an epic
    target_fr = datasets.active_frs.get(target_epic_id)
    if not target_fr:
        raise FileNotFoundError(f"Epic FR-{target_epic_id} not found")
    if not target_fr.is_epic:
        raise ValueError(f"Spec {target_epic_id} is not an epic (type: {target_fr.type})")

    # Verify spec exists
    spec_fr = datasets.active_frs.get(spec_id)
    if not spec_fr:
        raise FileNotFoundError(f"Spec FR-{spec_id} not found")

    # Find all epics that have this spec
    epics_with_spec = []
    for epic_id, fr in datasets.active_frs.items():
        if fr.is_epic and spec_id in fr.deps:
            epics_with_spec.append(epic_id)

    result: dict[str, list[str] | str | None] = {
        "removed_from": [],
        "added_to": None,
        "priority_bumped": None,
    }

    # Remove from other epics
    for epic_id in epics_with_spec:
        if epic_id != target_epic_id:
            remove_dependency(epic_id, spec_id, docs_root, paths_config, project_root)
            result["removed_from"].append(epic_id)  # type: ignore[union-attr]

    # Add to target epic if not already there
    if target_epic_id not in epics_with_spec:
        add_dependency(target_epic_id, spec_id, docs_root, paths_config, project_root)
        result["added_to"] = target_epic_id

    # Check if priority bump needed
    target_level = _get_priority_level(target_fr.priority)
    spec_level = _get_priority_level(spec_fr.priority)

    if spec_level > target_level:
        # Spec priority is lower (higher number) than epic - need to bump
        new_priority = f"P{target_level}"
        set_priority(
            spec_id,
            new_priority,
            docs_root,
            auto_update_deps=True,
            paths_config=paths_config,
            project_root=project_root,
        )
        result["priority_bumped"] = new_priority

    _validate_after_write(spec_id, docs_root, paths_config, check_impl=False)
    return result


def _get_priority_level(priority: str) -> int:
    """Extract numeric level from priority.

    Args:
        priority: Priority code (P0-P3)

    Returns:
        Numeric level (0-3, or 999 for invalid)
    """
    from nspec.domain.statuses import PRIORITY_RANK

    return PRIORITY_RANK.get(priority, 999)


def _find_dependent_specs(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> list[tuple[str, str]]:
    """Find all specs that depend on the given spec.

    Args:
        spec_id: Spec ID to check
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        List of (dependent_spec_id, dependent_priority) tuples
    """
    from nspec.domain.datasets import DatasetLoader

    spec_id = normalize_spec_ref(spec_id)
    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()

    dependents: list[tuple[str, str]] = []
    for dependent_id, fr in datasets.active_frs.items():
        if dependent_id == spec_id:
            continue
        if spec_id in (fr.deps or []):
            dependents.append((dependent_id, fr.priority))

    return dependents


def _epic_priority_from_id(epic_id: str, datasets: object) -> str:
    """Derive epic priority from its numeric ID, with collision fallback.

    Maps E001→P1, E002→P2, ..., E050→P50.  If the derived slot is already
    taken by another active epic, falls back to ``_next_available_epic_priority()``.
    Epic numbers above ``max_level`` are clamped to P{max_level}.

    Args:
        epic_id: The epic ID (e.g., "E015")
        datasets: Loaded DatasetLoader result with active_frs

    Returns:
        Priority code (e.g. "P15")
    """
    from nspec.domain.statuses import SPEC_PRIORITIES

    number = spec_ref_number(epic_id)
    max_level = len(SPEC_PRIORITIES) - 1
    clamped = min(number, max_level)
    derived = f"P{clamped}"

    # Check if derived priority is already taken by another active epic
    for _eid, fr in datasets.active_frs.items():
        if fr.is_epic and fr.priority == derived:
            # Collision — fall back to next available
            return _next_available_epic_priority(datasets)

    return derived


def _next_available_epic_priority(datasets: object) -> str:
    """Find the next unused epic priority slot, walking P1 upward.

    Args:
        datasets: Loaded DatasetLoader result with active_frs

    Returns:
        First unused priority code (e.g. "P3")

    Raises:
        ValueError: If all priority slots are exhausted
    """
    from nspec.domain.statuses import SPEC_PRIORITIES

    # Collect priorities held by active epics
    taken: set[str] = set()
    for _epic_id, fr in datasets.active_frs.items():
        if fr.is_epic:
            taken.add(fr.priority)

    # Walk P1..P{max_level} to find first free slot (skip P0 — reserved for critical)
    for code in list(SPEC_PRIORITIES.keys())[1:]:
        if code not in taken:
            return code

    # Also try P0 as last resort
    if "P0" not in taken:
        return "P0"

    max_level = len(SPEC_PRIORITIES) - 1
    raise ValueError(
        f"All epic priority slots (P0-P{max_level}) are exhausted. "
        f"Use swap_priority() to rearrange existing epics."
    )


def _cascade_epic_priority(
    target_priority: str,
    source_priority: str,
    exclude_spec_id: str,
    datasets: object,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> list[tuple[str, str, str]]:
    """Cascade-insert an epic into a priority slot, shifting others to make room.

    When moving an epic from source_priority to target_priority and the
    target slot is occupied, shift all epics between target and source
    one step toward the source's old slot.

    Example: moving E001 from P6 to P1 shifts P1->P2, P2->P3, ..., P5->P6.

    Args:
        target_priority: Desired priority (e.g. "P1")
        source_priority: Current priority of the epic being moved (e.g. "P6")
        exclude_spec_id: The epic being moved (skip it during cascade)
        datasets: Loaded DatasetLoader result with active_frs
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root

    Returns:
        List of (epic_id, old_priority, new_priority) tuples for all shifted epics.
        Empty list if no cascade was needed.
    """
    from nspec.domain.statuses import PRIORITY_RANK

    target_rank = PRIORITY_RANK.get(target_priority, 999)
    source_rank = PRIORITY_RANK.get(source_priority, 999)

    if target_rank == source_rank:
        return []

    # Build map: rank -> epic_id for all active epics (excluding the one being moved)
    rank_to_epic: dict[int, str] = {}
    for epic_id, fr in datasets.active_frs.items():
        if epic_id == exclude_spec_id:
            continue
        if not fr.is_epic:
            continue
        epic_rank = PRIORITY_RANK.get(fr.priority, 999)
        rank_to_epic[epic_rank] = epic_id

    # Check if the target slot is free — no cascade needed
    if target_rank not in rank_to_epic:
        return []

    # Determine cascade direction and range
    # Moving up (e.g., P6->P1): shift epics in [P1..P5] down by one (toward P6)
    # Moving down (e.g., P1->P6): shift epics in [P2..P6] up by one (toward P1)
    shifted: list[tuple[str, str, str]] = []

    if target_rank < source_rank:
        # Moving up: shift down (increment ranks in target..source-1)
        # Process from highest rank to lowest to avoid overwriting
        for rank in range(source_rank - 1, target_rank - 1, -1):
            if rank in rank_to_epic:
                eid = rank_to_epic[rank]
                old_p = f"P{rank}"
                new_p = f"P{rank + 1}"
                _write_priority_to_file(eid, new_p, docs_root, paths_config, project_root)
                shifted.append((eid, old_p, new_p))
    else:
        # Moving down: shift up (decrement ranks in source+1..target)
        # Process from lowest rank to highest to avoid overwriting
        for rank in range(source_rank + 1, target_rank + 1):
            if rank in rank_to_epic:
                eid = rank_to_epic[rank]
                old_p = f"P{rank}"
                new_p = f"P{rank - 1}"
                _write_priority_to_file(eid, new_p, docs_root, paths_config, project_root)
                shifted.append((eid, old_p, new_p))

    return shifted


def _write_priority_to_file(
    spec_id: str,
    priority: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> None:
    """Write a priority value directly to an FR file (no validation, no recursion).

    Used by cascade to shift epics without triggering full set_priority logic.
    """
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    fr_dir = paths.active_frs_dir
    fr_files = list(fr_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        return
    fr_path = fr_files[0]
    content = fr_path.read_text()

    _priority_line_re = get_priority_line_pattern()
    content = re.sub(
        _priority_line_re,
        f"**Priority:** {priority}",
        content,
        flags=re.MULTILINE,
    )
    fr_path.write_text(content)
    invalidate_dataset_cache(docs_root)


def _check_epic_priority_unique(
    priority: str,
    datasets: object,
    exclude_spec_id: str | None = None,
) -> None:
    """Raise ValueError if another active epic already holds this priority.

    Used during epic creation (lifecycle.py) where there is no source slot
    to cascade from. For priority changes on existing epics, use
    ``_cascade_epic_priority`` instead.

    Args:
        priority: Target priority code (e.g. "P5")
        datasets: Loaded DatasetLoader result with active_frs
        exclude_spec_id: Skip this spec (for self-assignment no-op)
    """
    for epic_id, fr in datasets.active_frs.items():
        if epic_id == exclude_spec_id:
            continue
        if not fr.is_epic:
            continue
        if fr.priority == priority:
            raise ValueError(
                f"Priority {priority} is already held by epic {epic_id} ({fr.title}).\n"
                f"Use swap_priority('{epic_id}', '<other_epic>') to exchange priorities."
            )


def set_priority(
    spec_id: str,
    priority: str,
    docs_root: Path,
    auto_update_deps: bool = True,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Change priority for a spec's FR file with optional dependency auto-update.

    Updates the **Priority:** line in both active and completed FR files.
    Optionally updates dependencies using bidirectional inheritance.

    When DOWNGRADING priority (e.g., P1 → P2), checks if any higher-priority specs
    depend on this spec. If so, raises ValueError with list of blocking dependencies.

    Args:
        spec_id: Spec ID to update (e.g., "093")
        priority: New priority (P0-P3)
        docs_root: Path to docs/ directory
        auto_update_deps: If True, auto-update dependencies to match priority level
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated FR file

    Raises:
        FileNotFoundError: If FR not found
        ValueError: If priority is invalid or downgrade blocked by dependents
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    spec_id = normalize_spec_ref(spec_id)

    # Validate priority
    from nspec.domain.statuses import SPEC_PRIORITIES

    if priority.upper() not in SPEC_PRIORITIES:
        max_level = len(SPEC_PRIORITIES) - 1
        raise ValueError(
            f"Invalid priority: {priority}. Must be P0-P{max_level}. "
            f"Check if too many epics are being created."
        )

    priority = priority.upper()

    # Find FR file in active or completed directories
    fr_pattern = f"FR-{spec_id}-*.md"
    active_fr_dir = paths.active_frs_dir
    completed_fr_dir = paths.completed_frs_dir

    fr_files = list(active_fr_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(completed_fr_dir.glob(fr_pattern))

    if not fr_files:
        raise FileNotFoundError(
            f"FR-{spec_id}-*.md not found in {active_fr_dir} or {completed_fr_dir}"
        )

    fr_path = fr_files[0]

    # Read current content
    content = fr_path.read_text()

    # For epics: cascade-insert (shift occupied slots) instead of rejecting
    _cascade_ran = False
    if spec_id.startswith("E"):
        from nspec.domain.datasets import DatasetLoader  # avoid circular import

        _plr = get_priority_line_pattern()
        _cm = re.search(_plr, content, re.MULTILINE)
        current_epic_priority = _cm.group(1) if _cm else None
        if current_epic_priority and current_epic_priority != priority:
            loader = DatasetLoader(docs_root=docs_root)
            datasets = loader.load()
            shifted = _cascade_epic_priority(
                priority,
                current_epic_priority,
                spec_id,
                datasets,
                docs_root,
                paths_config,
                project_root,
            )
            if shifted:
                _cascade_ran = True

    # Extract current priority to check if this is a downgrade.
    # Uses the shared priority-line regex from statuses.py — accepts both
    # legacy emoji+code and post-S332 words-only formats. The anchored+
    # capturing variant is used for both the search below and the re.sub
    # update at the bottom of this function.
    _priority_line_re = get_priority_line_pattern()
    current_priority_match = re.search(
        _priority_line_re,
        content,
        re.MULTILINE,
    )

    if current_priority_match:
        current_priority = current_priority_match.group(1)
        current_level = _get_priority_level(current_priority)
        new_level = _get_priority_level(priority)

        # Check if this is a downgrade (increasing level number = lower priority)
        if new_level > current_level:
            # Find specs that depend on this one
            dependents = _find_dependent_specs(spec_id, docs_root, paths_config, project_root)

            # Filter for dependents with higher priority (lower level number)
            blocking_dependents = [
                (dep_id, dep_priority)
                for dep_id, dep_priority in dependents
                if _get_priority_level(dep_priority) < new_level
            ]

            if blocking_dependents:
                # Build error message
                dep_list = ", ".join(
                    f"Spec {dep_id} ({dep_priority})"
                    for dep_id, dep_priority in blocking_dependents
                )
                raise ValueError(
                    f"Cannot downgrade Spec {spec_id} from {current_priority} to {priority}.\n"
                    f"The following higher-priority specs depend on it: {dep_list}\n"
                    f"Either:\n"
                    f"  1. Remove these dependencies first using 'make nspec.remove-dep'\n"
                    f"  2. Upgrade dependent specs to match or lower priority"
                )

    # Update priority line — words-only format (S332)
    content = re.sub(
        _priority_line_re,
        f"**Priority:** {priority}",
        content,
        flags=re.MULTILINE,
    )

    # Write updated content
    fr_path.write_text(content)
    invalidate_dataset_cache(docs_root)

    # Auto-update dependencies to match priority level.
    # Skip when cascade ran — epic priorities are the user's deliberate ordering;
    # dep inheritance would overwrite the cascade result.
    if auto_update_deps and not _cascade_ran:
        _auto_update_dependency_priorities(
            spec_id, priority, docs_root, content, paths_config, project_root
        )

    _validate_after_write(spec_id, docs_root, paths_config, check_impl=False)
    return fr_path


def swap_priority(
    spec_id_a: str,
    spec_id_b: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, str]:
    """Atomically swap priorities between two epics.

    Exchanges the priority values of two epic FRs without going through
    the uniqueness check (the swap preserves the invariant by construction).

    Args:
        spec_id_a: First epic ID
        spec_id_b: Second epic ID
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root

    Returns:
        Dict with the new priorities: {"spec_id_a": new_priority_a, ...}

    Raises:
        ValueError: If either spec is not an epic
        FileNotFoundError: If either FR file is not found
    """
    spec_id_a = normalize_spec_ref(spec_id_a)
    spec_id_b = normalize_spec_ref(spec_id_b)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Validate both are epics
    for sid in (spec_id_a, spec_id_b):
        if not sid.startswith("E"):
            raise ValueError(
                f"swap_priority requires two epics, but {sid} is not an epic (must start with E)"
            )

    # Find FR files for both epics
    fr_dir = paths.active_frs_dir
    fr_files: dict[str, Path] = {}
    for sid in (spec_id_a, spec_id_b):
        matches = list(fr_dir.glob(f"FR-{sid}-*.md"))
        if not matches:
            raise FileNotFoundError(f"FR-{sid}-*.md not found in {fr_dir}")
        fr_files[sid] = matches[0]

    # Extract current priorities via the shared priority-line regex.
    _priority_line_re = get_priority_line_pattern()

    priorities: dict[str, str] = {}
    contents: dict[str, str] = {}
    for sid, fr_path in fr_files.items():
        content = fr_path.read_text()
        m = re.search(_priority_line_re, content, re.MULTILINE)
        if not m:
            raise ValueError(f"Cannot parse priority from {fr_path.name}")
        priorities[sid] = m.group(1)
        contents[sid] = content

    # Swap: prepare both updated contents, then write atomically with rollback
    updated_contents: dict[str, str] = {}
    for sid in (spec_id_a, spec_id_b):
        other_sid = spec_id_b if sid == spec_id_a else spec_id_a
        new_priority = priorities[other_sid]
        # Words-only format (S332) — no emoji prefix in file
        updated_contents[sid] = re.sub(
            _priority_line_re,
            f"**Priority:** {new_priority}",
            contents[sid],
            flags=re.MULTILINE,
        )

    # Write both files; rollback first if second fails
    fr_files[spec_id_a].write_text(updated_contents[spec_id_a])
    try:
        fr_files[spec_id_b].write_text(updated_contents[spec_id_b])
    except Exception:
        # Rollback first write
        fr_files[spec_id_a].write_text(contents[spec_id_a])
        raise
    invalidate_dataset_cache(docs_root)

    _validate_after_write(spec_id_a, docs_root, paths_config, check_impl=False)

    return {
        spec_id_a: priorities[spec_id_b],
        spec_id_b: priorities[spec_id_a],
    }


def _build_reverse_dependency_map(
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> dict[str, list[tuple[str, str]]]:
    """Build a map of spec_id -> list of (dependent_id, dependent_priority).

    For each spec, find all specs that depend on it.

    Args:
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Dict mapping spec_id to list of (dependent_id, dependent_priority) tuples
    """
    from nspec.domain.datasets import DatasetLoader

    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()

    reverse_deps: dict[str, list[tuple[str, str]]] = {}
    all_frs = {**datasets.active_frs, **datasets.completed_frs}
    for dependent_id, fr in all_frs.items():
        for dep_id in fr.deps or []:
            reverse_deps.setdefault(dep_id, []).append((dependent_id, fr.priority))

    return reverse_deps


def _calculate_effective_priority(
    dep_id: str,
    reverse_deps: dict[str, list[tuple[str, str]]],
    updated_priorities: dict[str, int],
) -> int:
    """Calculate the effective priority level for a dependency.

    The effective priority is the HIGHEST priority (LOWEST level number)
    among all specs that depend on this one.

    Args:
        dep_id: Dependency spec ID
        reverse_deps: Reverse dependency map from _build_reverse_dependency_map
        updated_priorities: Dict of spec_id -> new priority level for specs being updated

    Returns:
        Effective priority level (0-3), or 3 if no dependents
    """
    dependents = reverse_deps.get(dep_id, [])

    if not dependents:
        return 3  # No dependents, lowest priority

    min_level = 3  # Start with lowest priority (highest number)

    for dependent_id, dependent_priority in dependents:
        # Check if this dependent has an updated priority
        if dependent_id in updated_priorities:
            level = updated_priorities[dependent_id]
        else:
            level = _get_priority_level(dependent_priority)

        min_level = min(min_level, level)

    return min_level


def _auto_update_dependency_priorities(
    spec_id: str,
    new_priority: str,
    docs_root: Path,
    fr_content: str,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> None:
    """Auto-update dependency priorities using bidirectional inheritance.

    Implements smart priority inheritance:
    - When upgrading (P2 → P1): Dependencies are upgraded to match
    - When downgrading (P1 → P2): Dependencies are downgraded ONLY if no other
      higher-priority spec depends on them

    Formula: dep_priority = MAX(priorities of all dependents) where MAX means
    the highest priority (lowest level number).

    Uses two-pass traversal for transitive dependencies (e.g., 210→211).

    Args:
        spec_id: Spec ID that was updated
        new_priority: New priority for the spec (P0-P3)
        docs_root: Path to docs/ directory
        fr_content: (legacy) FR content; ignored (deps are resolved via datasets)
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
    """
    from nspec.domain.datasets import DatasetLoader

    spec_id = normalize_spec_ref(spec_id)
    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()

    fr = datasets.get_fr(spec_id)
    if not fr or not fr.deps:
        return

    dep_ids = [d for d in fr.deps if d in datasets.active_frs]
    if not dep_ids:
        return

    reverse_deps = _build_reverse_dependency_map(docs_root, paths_config, project_root)
    updated_priorities: dict[str, int] = {spec_id: _get_priority_level(new_priority)}

    print(f"📝 Auto-updating {len(dep_ids)} dependencies with bidirectional inheritance...")

    from nspec.domain.statuses import PRIORITY_RANK

    level_to_priority = {rank: code for code, rank in PRIORITY_RANK.items()}

    for pass_num in range(2):
        if pass_num == 1:
            print("   🔄 Pass 2: Checking transitive dependencies...")

        for dep_id in dep_ids:
            try:
                dep_fr = datasets.get_fr(dep_id)
                if not dep_fr:
                    if pass_num == 0:
                        print(f"   ⚠️  Dependency {dep_id} not found, skipping")
                    continue

                current_priority = dep_fr.priority
                current_level = _get_priority_level(current_priority)
                effective_level = _calculate_effective_priority(
                    dep_id, reverse_deps, updated_priorities
                )

                if current_level != effective_level:
                    new_dep_priority = level_to_priority.get(effective_level)
                    if not new_dep_priority:
                        if pass_num == 0:
                            msg = (
                                f"   ⚠️  Invalid effective level {effective_level}, "
                                f"skipping {dep_id}"
                            )
                            print(msg)
                        continue

                    direction = "⬆️" if effective_level < current_level else "⬇️"
                    set_priority(
                        dep_id,
                        new_dep_priority,
                        docs_root,
                        auto_update_deps=False,
                        paths_config=paths_config,
                        project_root=project_root,
                    )
                    update_msg = (
                        f"   {direction} Updated Spec {dep_id}: "
                        f"{current_priority} → {new_dep_priority}"
                    )
                    print(update_msg)
                    updated_priorities[dep_id] = effective_level
                else:
                    if pass_num == 0:
                        print(
                            f"   ⏭️  Spec {dep_id} at {current_priority} "
                            f"(effective level {effective_level}), no update needed"
                        )

            except _NspecCrudErrors as e:
                print(f"   ❌ Error updating dependency {dep_id}: {e}")
