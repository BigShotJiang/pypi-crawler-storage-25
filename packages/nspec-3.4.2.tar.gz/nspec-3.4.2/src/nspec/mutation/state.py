"""Spec state management: park, hold, reset, recover, exception, design."""

import re
from pathlib import Path

from nspec.domain.ids import normalize_spec_ref
from nspec.domain.statuses import FRStatusCode, IMPLStatusCode
from nspec.mutation._helpers import (
    _find_impl_file,
    _get_current_status,
    _validate_after_write,
)
from nspec.mutation.status import set_status
from nspec.paths import NspecPaths, get_paths


def start_design_spec(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Move FR to In Design without starting the IMPL.

    Sets FR=In Design(1) while keeping IMPL at Planning(0).
    Idempotent: no-op if FR is already In Design.
    Rejects if FR is past In Design (Active, Completed, etc.).

    Args:
        spec_id: Spec ID (e.g., "004")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
        ValueError: If FR is past In Design
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find FR and check current status
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(paths.active_frs_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
    fr_path = fr_files[0]
    fr_content = fr_path.read_text()
    current_fr_status = _get_current_status(fr_content, kind="FR")

    if current_fr_status is None:
        raise ValueError(f"Could not parse current FR status for {spec_id}")

    # Idempotent: already In Design → no-op
    if current_fr_status[0] == FRStatusCode.IN_DESIGN:
        impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
        return fr_path, impl_path

    # Reject if FR is past In Design (Active=2, Completed=3, etc.)
    if current_fr_status[0] > FRStatusCode.IN_DESIGN:
        raise ValueError(
            f"Cannot start_design: FR is already at {current_fr_status[2]} "
            f"(code {current_fr_status[0]}), which is past In Design"
        )

    # Set FR=In Design(1), keep IMPL=Planning(0)
    fr_path, impl_path = set_status(
        spec_id,
        FRStatusCode.IN_DESIGN,
        IMPLStatusCode.PLANNING,
        docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    return fr_path, impl_path


def hold_spec(
    spec_id: str,
    docs_root: Path,
    reason: str,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Put a spec on hold by setting IMPL to Hold.

    Sets IMPL=Hold(5) from Planning, Active, or Testing.
    Records the hold reason in a ``**Hold Reason:**`` header field.
    Idempotent: no-op if already Hold (but updates reason if provided).
    Rejects if IMPL is Ready (terminal).

    Args:
        spec_id: Spec ID (e.g., "004")
        docs_root: Path to docs/ directory
        reason: Why the spec is being put on hold (required)
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
        ValueError: If IMPL is Ready
    """
    spec_id = normalize_spec_ref(spec_id)
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()
    current_impl_status = _get_current_status(impl_content, kind="IMPL")

    if current_impl_status is None:
        raise ValueError(f"Could not parse current IMPL status for {spec_id}")

    # Reject if IMPL is Ready (terminal)
    if current_impl_status[0] == IMPLStatusCode.READY:
        raise ValueError(
            "Cannot hold: IMPL is Ready (terminal state). Use complete() to archive instead."
        )

    # Idempotent: already Hold → update reason and return
    if current_impl_status[0] == IMPLStatusCode.HOLD:
        _write_hold_reason(impl_path, reason)
        _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)
        # Find FR path for consistent return type
        paths = get_paths(docs_root, config=paths_config, project_root=project_root)
        fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            fr_files = list(paths.completed_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
        return fr_files[0], impl_path

    # Reject if IMPL is in a state we don't hold from (Exception, Paused)
    valid_hold_sources = {
        IMPLStatusCode.PLANNING,
        IMPLStatusCode.ACTIVE,
        IMPLStatusCode.TESTING,
    }
    if current_impl_status[0] not in valid_hold_sources:
        raise ValueError(
            f"Cannot hold: IMPL is at {current_impl_status[2]} "
            f"(code {current_impl_status[0]}). Hold is only valid from "
            f"Planning, Active, or Testing."
        )

    # Find FR and get current status to preserve it
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
    fr_content = fr_files[0].read_text()
    current_fr_status = _get_current_status(fr_content, kind="FR")
    if current_fr_status is None:
        raise ValueError(f"Could not parse current FR status for {spec_id}")

    # Set IMPL=Hold(5), keep current FR status
    fr_path, impl_path = set_status(
        spec_id,
        current_fr_status[0],
        IMPLStatusCode.HOLD,
        docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    # Record hold reason
    _write_hold_reason(impl_path, reason)
    _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)

    return fr_path, impl_path


def _write_hold_reason(impl_path: Path, reason: str) -> None:
    """Write or update the **Hold Reason:** field in an IMPL file."""
    from nspec.runtime.atomic import spec_write

    content = impl_path.read_text()
    # Escape reason for safe use in re.sub replacement (backslashes are literal)
    safe_reason = reason.replace("\\", "\\\\")
    hold_reason_pattern = r"^\*\*Hold Reason:\*\*.*$"
    if re.search(hold_reason_pattern, content, re.MULTILINE):
        # Update existing field
        content = re.sub(
            hold_reason_pattern,
            f"**Hold Reason:** {safe_reason}",
            content,
            count=1,
            flags=re.MULTILINE,
        )
    else:
        # Insert after **Status:** line
        content = re.sub(
            r"(^\*\*Status:\*\*.*$)",
            rf"\1\n**Hold Reason:** {safe_reason}",
            content,
            count=1,
            flags=re.MULTILINE,
        )
    spec_write(impl_path, content)


def reset_spec(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Reset a spec back to Planning state.

    Sets IMPL=Planning(0) from Paused, Hold, or Exception.
    Idempotent: no-op if already Planning.
    Rejects if IMPL is Active, Testing, or Ready.

    Args:
        spec_id: Spec ID (e.g., "004")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
        ValueError: If IMPL is Active, Testing, or Ready
    """
    spec_id = normalize_spec_ref(spec_id)
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()
    current_impl_status = _get_current_status(impl_content, kind="IMPL")

    if current_impl_status is None:
        raise ValueError(f"Could not parse current IMPL status for {spec_id}")

    # Idempotent: already Planning → no-op
    if current_impl_status[0] == IMPLStatusCode.PLANNING:
        paths = get_paths(docs_root, config=paths_config, project_root=project_root)
        fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            fr_files = list(paths.completed_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
        return fr_files[0], impl_path

    # Reject if IMPL is in Active, Testing, or Ready
    reject_states = {
        IMPLStatusCode.ACTIVE,
        IMPLStatusCode.TESTING,
        IMPLStatusCode.READY,
    }
    if current_impl_status[0] in reject_states:
        raise ValueError(
            f"Cannot reset: IMPL is at {current_impl_status[2]} "
            f"(code {current_impl_status[0]}). Reset is only valid from "
            f"Paused, Hold, or Exception."
        )

    # Find FR and get current status
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
    fr_content = fr_files[0].read_text()
    current_fr_status = _get_current_status(fr_content, kind="FR")
    if current_fr_status is None:
        raise ValueError(f"Could not parse current FR status for {spec_id}")

    # Reset FR back to Proposed if it's Deferred (common for parked specs)
    new_fr_status = current_fr_status[0]
    if new_fr_status == FRStatusCode.DEFERRED:
        new_fr_status = FRStatusCode.PROPOSED

    # Set IMPL=Planning(0)
    fr_path, impl_path = set_status(
        spec_id,
        new_fr_status,
        IMPLStatusCode.PLANNING,
        docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    return fr_path, impl_path


def recover_spec(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Recover a spec from Exception to Active.

    Sets IMPL=Active(1) from Exception.
    Idempotent: no-op if already Active.
    Rejects if IMPL is not Exception or Active.

    Args:
        spec_id: Spec ID (e.g., "004")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
        ValueError: If IMPL is not Exception or Active
    """
    spec_id = normalize_spec_ref(spec_id)
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()
    current_impl_status = _get_current_status(impl_content, kind="IMPL")

    if current_impl_status is None:
        raise ValueError(f"Could not parse current IMPL status for {spec_id}")

    # Idempotent: already Active → no-op
    if current_impl_status[0] == IMPLStatusCode.ACTIVE:
        paths = get_paths(docs_root, config=paths_config, project_root=project_root)
        fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            fr_files = list(paths.completed_frs_dir.glob(f"FR-{spec_id}-*.md"))
        if not fr_files:
            raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
        return fr_files[0], impl_path

    # Reject if not Exception
    if current_impl_status[0] != IMPLStatusCode.EXCEPTION:
        raise ValueError(
            f"Cannot recover: IMPL is at {current_impl_status[2]} "
            f"(code {current_impl_status[0]}). Recover is only valid from "
            f"Exception."
        )

    # Find FR — ensure it's Active for valid state pair
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)
    fr_files = list(paths.active_frs_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(f"FR-{spec_id}-*.md"))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found")
    fr_content = fr_files[0].read_text()
    current_fr_status = _get_current_status(fr_content, kind="FR")
    if current_fr_status is None:
        raise ValueError(f"Could not parse current FR status for {spec_id}")

    # Set IMPL=Active(1), keep FR status (should be Active for valid pair)
    fr_path, impl_path = set_status(
        spec_id,
        current_fr_status[0],
        IMPLStatusCode.ACTIVE,
        docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    return fr_path, impl_path


def park_spec(
    spec_id: str,
    docs_root: Path,
    reason: str | None = None,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[Path, Path]:
    """Park a spec by setting IMPL to Paused and FR to Deferred.

    Sets both statuses and optionally records a blocker summary
    in the IMPL execution notes.

    Args:
        spec_id: Spec ID (e.g., "004")
        docs_root: Path to docs/ directory
        reason: Optional blocker reason to record in IMPL
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        Tuple of (FR path, IMPL path)

    Raises:
        FileNotFoundError: If FR or IMPL not found
    """
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()
    current_impl_status = _get_current_status(impl_content, kind="IMPL")

    if current_impl_status and current_impl_status[2] == "Paused":
        raise ValueError(f"Spec {spec_id} is already paused.")

    # Set FR to Deferred, IMPL to Paused
    fr_path, impl_path = set_status(
        spec_id,
        FRStatusCode.DEFERRED,
        IMPLStatusCode.PAUSED,
        docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    # Record blocker summary in IMPL execution notes
    if reason:
        impl_content = impl_path.read_text()
        timestamp = __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M")
        note = f"\n- **{timestamp}:** PARKED — {reason}"

        if "## Execution Notes" in impl_content:
            parts = impl_content.split("## Execution Notes", 1)
            rest = parts[1]
            next_section = re.search(r"\n##\s", rest)
            if next_section:
                insert_pos = next_section.start()
                new_content = (
                    parts[0] + "## Execution Notes" + rest[:insert_pos] + note + rest[insert_pos:]
                )
            else:
                new_content = impl_content + note
        else:
            new_content = impl_content.rstrip() + "\n\n## Execution Notes\n" + note

        impl_path.write_text(new_content)
        _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)

    return fr_path, impl_path


def set_exception(
    spec_id: str,
    docs_root: Path,
    reason: str,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Set a spec to Exception state for human triage.

    Use when:
    - Subagent timeout
    - Unexpected failure mode
    - Guardrail violation detected

    Exception is distinct from Paused - it indicates something went wrong
    that requires human investigation, not just temporary blocking.

    Args:
        spec_id: Spec ID (e.g., "004")
        docs_root: Path to docs/ directory
        reason: Why the spec entered exception state (required)
        paths_config: Optional custom paths configuration
        project_root: Project root for config lookup

    Returns:
        IMPL path

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If spec is already in exception state
    """
    from nspec.paths import get_paths

    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Find IMPL and check current status
    impl_path = _find_impl_file(spec_id, docs_root, paths_config, project_root)
    impl_content = impl_path.read_text()
    current_impl_status = _get_current_status(impl_content, kind="IMPL")

    if current_impl_status and current_impl_status[2] == "Exception":
        raise ValueError(f"Spec {spec_id} is already in exception state.")

    # Find FR and get current status (we won't change it)
    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(paths.active_frs_dir.glob(fr_pattern))
    if not fr_files:
        fr_files = list(paths.completed_frs_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(
            f"FR-{spec_id}-*.md not found in {paths.active_frs_dir} or {paths.completed_frs_dir}"
        )
    fr_path = fr_files[0]
    fr_content = fr_path.read_text()
    current_fr_status = _get_current_status(fr_content, kind="FR")

    if current_fr_status is None:
        raise ValueError(f"Could not parse current FR status for {spec_id}")

    # Set IMPL to Exception (FR status unchanged - exception is IMPL-only)
    # Use force=True since Exception can be entered from any state
    set_status(
        spec_id,
        current_fr_status[0],  # Keep current FR status
        IMPLStatusCode.EXCEPTION,
        docs_root,
        force=True,
        paths_config=paths_config,
        project_root=project_root,
    )

    # Record exception reason in IMPL execution notes
    impl_content = impl_path.read_text()
    timestamp = __import__("datetime").datetime.now().strftime("%Y-%m-%d %H:%M")
    note = f"\n- **{timestamp}:** ⚠️ EXCEPTION — {reason}"

    if "## Execution Notes" in impl_content:
        parts = impl_content.split("## Execution Notes", 1)
        rest = parts[1]
        next_section = re.search(r"\n##\s", rest)
        if next_section:
            insert_pos = next_section.start()
            new_content = (
                parts[0] + "## Execution Notes" + rest[:insert_pos] + note + rest[insert_pos:]
            )
        else:
            new_content = impl_content + note
    else:
        new_content = impl_content.rstrip() + "\n\n## Execution Notes\n" + note

    impl_path.write_text(new_content)
    _validate_after_write(spec_id, docs_root, paths_config, check_fr=False)

    return impl_path


# ===========================================================================
# Epic-scoped queries and bulk operations
# ===========================================================================
