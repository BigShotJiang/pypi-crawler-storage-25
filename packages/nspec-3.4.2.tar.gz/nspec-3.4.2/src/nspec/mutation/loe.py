"""Level-of-effort calculation and updates."""

import re
from pathlib import Path

from nspec.domain.ids import normalize_spec_ref
from nspec.paths import NspecPaths, get_paths


def calculate_epic_loe(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> tuple[int, int]:
    """Calculate Epic LOE from active dependencies.

    Args:
        spec_id: Epic spec ID (e.g., "093")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        (parallel_hours, sequential_hours)
        parallel = max of all dep parallel LOEs
        sequential = sum of all dep sequential LOEs

    Note:
        Completed dependencies are skipped (don't add to remaining work).
    """
    from nspec.domain.datasets import DatasetLoader

    spec_id = normalize_spec_ref(spec_id)
    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()

    epic_fr = datasets.get_fr(spec_id)
    if not epic_fr or not epic_fr.is_epic or not epic_fr.deps:
        return (0, 0)

    dep_hours: list[int] = []
    for dep_id in epic_fr.deps:
        # Skip completed dependencies (they don't add to remaining work)
        if dep_id in datasets.completed_impls:
            continue
        dep_impl = datasets.active_impls.get(dep_id)
        if not dep_impl:
            continue
        dep_hours.append(dep_impl.effective_loe_hours)

    if not dep_hours:
        return (0, 0)

    return (max(dep_hours), sum(dep_hours))


def _parse_loe_to_hours(loe_str: str) -> tuple[int, int]:
    """Parse LOE string to hours (parallel, sequential).

    Formats:
        - "~5d" → (0, 40h)  # Sequential only
        - "~3w,~10d" → (120h, 80h)  # Parallel, sequential

    Args:
        loe_str: LOE string (e.g., "~5d", "~3w,~10d")

    Returns:
        (parallel_hours, sequential_hours)
    """
    # Check if format is "~XXh,~YYd" (parallel, sequential)
    if "," in loe_str:
        parts = loe_str.split(",")
        parallel_str = parts[0].strip()
        sequential_str = parts[1].strip()

        parallel_hours = _loe_component_to_hours(parallel_str)
        sequential_hours = _loe_component_to_hours(sequential_str)

        return (parallel_hours, sequential_hours)
    else:
        # Single value = sequential only
        sequential_hours = _loe_component_to_hours(loe_str)
        return (0, sequential_hours)


def _loe_component_to_hours(component: str) -> int:
    """Convert LOE component to hours.

    Args:
        component: LOE component (e.g., "~5d", "~3w", "~40h", "~1.5d")

    Returns:
        Hours as integer (rounded from float if needed)
    """
    component = component.strip().replace("~", "")

    if component.endswith("h"):
        return int(float(component[:-1]))
    elif component.endswith("d"):
        return int(float(component[:-1]) * 8)  # 1 day = 8 hours
    elif component.endswith("w"):
        return int(float(component[:-1]) * 40)  # 1 week = 40 hours
    else:
        return 0


def _format_hours_to_loe(hours: int) -> str:
    """Format hours to LOE string with smart unit selection.

    Rules:
    - < 24h (3 days): use hours (e.g., "20h")
    - >= 24h and < 56h (7 days): use days with decimal (e.g., "3.5d")
    - >= 56h: use weeks with decimal (e.g., "1.4w")

    Args:
        hours: Hours as integer

    Returns:
        LOE string (e.g., "20h", "3.5d", "1.4w")
    """
    if hours == 0:
        return "0h"
    elif hours < 24:
        # Under 3 days: use hours
        return f"{hours}h"
    elif hours < 56:
        # 3 days to 7 days: use days with decimal
        days = hours / 8
        if days == int(days):
            return f"{int(days)}d"
        else:
            return f"{days:.1f}d"
    else:
        # 7 days and over: use weeks with decimal
        weeks = hours / 40
        if weeks == int(weeks):
            return f"{int(weeks)}w"
        else:
            return f"{weeks:.1f}w"


def update_epic_loe(
    spec_id: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path | None:
    """Update Epic FR and IMPL LOE based on dependencies.

    Only updates if spec is an Epic (Type: Epic).
    Updates both:
    - FR: **LOE Remaining:** field (uses parallel estimate)
    - IMPL: **LOE:** field (uses parallel,sequential format)

    Args:
        spec_id: Spec ID to update (e.g., "093")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file, or None if not an Epic

    Raises:
        FileNotFoundError: If FR or IMPL not found
    """
    from nspec.domain.datasets import DatasetLoader

    spec_id = normalize_spec_ref(spec_id)
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    loader = DatasetLoader(docs_root=docs_root)
    datasets = loader.load()
    fr_meta = datasets.get_fr(spec_id)
    if not fr_meta or not fr_meta.is_epic:
        return None

    fr_pattern = f"FR-{spec_id}-*.md"
    fr_files = list(paths.active_frs_dir.glob(fr_pattern))
    if not fr_files:
        raise FileNotFoundError(f"FR-{spec_id}-*.md not found in {paths.active_frs_dir}")

    fr_path = fr_files[0]
    fr_content = fr_path.read_text()

    # Calculate LOE from dependencies
    parallel_hours, sequential_hours = calculate_epic_loe(
        spec_id, docs_root, paths_config, project_root
    )

    # Load IMPL file
    impl_pattern = f"IMPL-{spec_id}-*.md"
    impl_dir = paths.active_impls_dir
    impl_files = list(impl_dir.glob(impl_pattern))

    if not impl_files:
        raise FileNotFoundError(f"IMPL-{spec_id}-*.md not found in {impl_dir}")

    impl_path = impl_files[0]
    impl_content = impl_path.read_text()

    # Format LOE string for Epics (always show parallel, sequential)
    if parallel_hours == 0 and sequential_hours == 0:
        loe_str = "TBD"
        fr_loe_str = "TBD"
    else:
        # Epics always show both parallel and sequential
        # Parallel = longest dependency (if all done in parallel)
        # Sequential = sum of all dependencies (if all done sequentially)
        parallel_str = _format_hours_to_loe(parallel_hours)
        sequential_str = _format_hours_to_loe(sequential_hours)
        loe_str = f"{parallel_str},{sequential_str}"
        # FR shows just the parallel estimate (best case with parallelization)
        fr_loe_str = f"~{parallel_str}"

    # Update IMPL **LOE:** line
    impl_content = re.sub(
        r"^\*\*LOE:\*\*\s+.+$", f"**LOE:** {loe_str}", impl_content, flags=re.MULTILINE
    )

    # Update FR **LOE Remaining:** line (if it exists)
    if re.search(r"^\*\*LOE Remaining:\*\*", fr_content, re.MULTILINE):
        fr_content = re.sub(
            r"^\*\*LOE Remaining:\*\*\s+.+$",
            f"**LOE Remaining:** {fr_loe_str}",
            fr_content,
            flags=re.MULTILINE,
        )
        # Write updated FR
        fr_path.write_text(fr_content)

    # Write updated IMPL
    from nspec.runtime.atomic import spec_write

    spec_write(impl_path, impl_content)

    # S926: invalidate cache after writing spec files
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    return impl_path


# LOE format validation regex (matches validators.py but simpler for single values)
_LOE_FORMAT_RE = re.compile(r"^(\d+(?:\.\d+)?)(h|d|w)$|^N/A$", re.IGNORECASE)


def set_loe(
    spec_id: str,
    loe: str,
    docs_root: Path,
    paths_config: NspecPaths | None = None,
    project_root: Path | None = None,
) -> Path:
    """Set LOE for a spec's IMPL file with format validation.

    Validates LOE format before writing to prevent invalid values.

    Args:
        spec_id: Spec ID to update (e.g., "280")
        loe: New LOE value (e.g., "14d", "3w", "20h", "N/A")
        docs_root: Path to docs/ directory
        paths_config: Optional custom paths configuration
        project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)

    Returns:
        Path to updated IMPL file

    Raises:
        FileNotFoundError: If IMPL not found
        ValueError: If LOE format is invalid

    Examples:
        Valid: "5d", "3w", "20h", "2.5d", "N/A"
        Invalid: "~5d", "14d (aggregate)", "TBD", "5 days"
    """
    spec_id = normalize_spec_ref(spec_id)
    paths = get_paths(docs_root, config=paths_config, project_root=project_root)

    # Validate LOE format
    loe = loe.strip()
    if not _LOE_FORMAT_RE.match(loe):
        raise ValueError(
            f"❌ Invalid LOE format: '{loe}'\n"
            f"   Required format: <number><unit> or N/A\n"
            f"   Valid units: h (hours), d (days), w (weeks)\n"
            f"   Examples: 5d, 3w, 20h, 2.5d, N/A\n"
            f"   Invalid: ~5d, 14d (notes), TBD, 5 days"
        )

    # Normalize case for N/A
    if loe.upper() == "N/A":
        loe = "N/A"

    # Find IMPL file in active or completed directories
    impl_pattern = f"IMPL-{spec_id}-*.md"
    active_impl_dir = paths.active_impls_dir
    completed_impl_dir = paths.completed_impls_dir

    impl_files = list(active_impl_dir.glob(impl_pattern))
    if not impl_files:
        impl_files = list(completed_impl_dir.glob(impl_pattern))

    if not impl_files:
        raise FileNotFoundError(
            f"IMPL-{spec_id}-*.md not found in {active_impl_dir} or {completed_impl_dir}"
        )

    impl_path = impl_files[0]

    # Read current content
    content = impl_path.read_text()

    # Update LOE line
    new_content = re.sub(
        r"^\*\*LOE:\*\*\s+.+$",
        f"**LOE:** {loe}",
        content,
        flags=re.MULTILINE,
    )

    if new_content == content:
        # LOE line not found - this shouldn't happen for valid IMPL files
        raise ValueError(f"❌ No **LOE:** line found in {impl_path.name}")

    # Write updated content
    impl_path.write_text(new_content)

    # S926: invalidate cache after writing IMPL file
    from nspec.domain.datasets import invalidate_dataset_cache

    invalidate_dataset_cache(docs_root)

    return impl_path
