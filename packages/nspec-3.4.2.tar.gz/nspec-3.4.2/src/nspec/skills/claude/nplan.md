---
description: Plan mode that outputs nspec specs — explore, design, then create specs
argument-hint: <what you want to plan>
---

Enter plan mode to research and design, then create nspec specs as the deliverable. The plan file is scratch — the specs ARE the plan.

## Step 1: Enter Plan Mode

Call the `EnterPlanMode` tool immediately. This activates read-only mode so you can explore freely without making changes.

## Step 2: Parse Intent

Parse `$ARGUMENTS` for the user's planning request.

- If no argument provided, use `AskUserQuestion` to ask: "What do you want to plan?" with free-text input.
- The description can be a sentence, paragraph, or reference to existing code/issues.

## Step 3: Determine Scope

Use `AskUserQuestion` to ask "Which epic?" with options from `epics()`, plus "New epic".

## Step 4: Explore

Launch Explore agents (up to 3 in parallel) to understand the codebase:

1. **Relevant code:** Find files, functions, patterns related to the request
2. **Existing specs:** Check `docs/frs/active/` for related or overlapping work
3. **Test patterns:** Understand how similar features are tested

Write findings to the plan file as you go — this is your scratch pad.

## Step 5: Design

Synthesize findings into a design:

1. **Identify the spec decomposition** — how many specs are needed? Each spec should be one focused, independently implementable unit of work.
2. **Map dependencies** — which specs block which?
3. **For each spec, draft:** title, 3-5 ACs, key tasks, priority

Use `AskUserQuestion` to confirm the decomposition with the user before creating specs.

## Step 6: Create Specs

For each spec in the design:

1. Call `create_spec(title, priority, epic_id)` to create the FR+IMPL pair
2. Wire dependencies via `add_dep(spec_id, dep_id)`
3. Author the FR with real content (Executive Summary, Problem, Solution, ACs, Tests) — NOT skeletons
4. Author the IMPL with real tasks, files, LOE

## Step 7: Exit Plan Mode

After all specs are created and authored:

1. Call `validate()` to verify everything is clean
2. Update the plan file with a summary of what was created
3. Call `ExitPlanMode`

The PostToolUse hook on ExitPlanMode will verify specs were created.

## Step 8: Report

Print a summary table:

```
## Plan Complete

| ID | Title | Priority | Deps | Tasks | LOE |
|----|-------|----------|------|-------|-----|
| S### | ... | P# | ... | N | Xd |

Epic: E### ({title})
Total specs: N
Ready to execute: /nloop
```

## Rules

- **Specs are the deliverable.** The plan file is scratch — never leave the plan as prose.
- **Author FRs fully.** Every spec must have real content, not skeleton placeholders.
- **One spec per concern.** Don't combine unrelated changes into one spec.
- **Explore first.** Never design without reading relevant code.
- **Confirm decomposition.** Use AskUserQuestion before creating specs — don't surprise the user with 15 specs.
