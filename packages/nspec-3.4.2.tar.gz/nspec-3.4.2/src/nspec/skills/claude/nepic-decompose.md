---
description: Decompose an existing epic into child specs using design docs as source material
argument-hint: <epic_id> [--design-doc <path>] [--dry-run]
---

Decompose an existing epic into 4-8 child specs with fully-authored FRs, wired dependencies, and skeleton IMPLs ready for `/ngo` execution. Optionally reads a design document section to inform the decomposition.

## Argument Parsing

Parse `$ARGUMENTS` for:

1. **Epic ID** (required): An epic identifier like `E002`, `e002`, or bare number `002`.
2. **`--design-doc <path>`** (optional): Path to a markdown design document. If provided, the skill reads it to inform decomposition.
3. **`--dry-run`** (optional): If present, print the decomposition plan without creating any specs.

- If no epic ID is provided, call `epics()` to list available epics and use `AskUserQuestion` to ask "Which epic to decompose?" with the epic list as options.
- Validate the epic exists by calling `show(epic_id)`. If not found, print the error and EXIT.

## Step 1: Gather Context

### 1a: Read the Epic

1. Call `show(epic_id)` to get the epic's FR content, status, and existing child specs.
2. Call `epic_specs(epic_id)` to see what child specs already exist.

### 1b: Check Idempotency

If the epic already has 3+ child specs:
- Print: "Epic {epic_id} already has {N} child specs. Decomposition may create duplicates."
- Use `AskUserQuestion`: "Continue anyway?" (Yes / No)
- If No, EXIT.

### 1c: Read Design Document (if provided)

If `--design-doc` was specified:
1. Use `Read` to load the design document.
2. Identify the section most relevant to this epic by matching headings against the epic title/description.
3. Extract the relevant section content as the primary decomposition input.

If no design document was specified:
1. Use the epic's FR content as the primary decomposition input.
2. Optionally search for architecture docs: use `Glob` to check `docs/architecture/*.md`, `docs/design/*.md`, `ARCHITECTURE.md`, `DESIGN.md`.
3. If found, use `AskUserQuestion`: "Found {file}. Use it as design input?" (Yes / No / Skip)

### 1d: Explore the Codebase

Based on the epic's scope:

1. **Identify relevant modules:** Use `Glob` and `Grep` to find source files, tests, and existing specs related to the epic theme.
2. **Read key files:** Use `Read` to examine the most relevant 3-5 files to understand current architecture and boundaries.
3. **Check completed specs:** Search `docs/completed/done/` for previously completed specs in this area to avoid duplicating work.

## Step 2: Design the Decomposition

### 2a: Identify Decomposition Boundaries

Analyze the gathered context and break the epic scope into 4-8 child specs. Use these heuristics:

- **One scope bullet = one candidate spec.** Each major deliverable in the epic FR maps to a spec.
- **Foundation specs first.** Identify leaf/foundation work (data models, config, core abstractions) that other specs depend on.
- **Parallel-capable specs stay separate.** If two pieces of work can be done independently, they should be separate specs.
- **Integration spec last.** If the epic requires wiring components together, that is the final spec.
- **Size check:** Each spec should be 0.5d-2d of work. If a spec is larger, split it. If smaller, merge with a related spec.

### 2b: Draft the Decomposition Plan

For each proposed child spec, prepare:
- **Title:** Concise, action-oriented (e.g., "Add config schema for epic-section mapping")
- **Description:** 1-2 sentences on what it delivers
- **Dependencies:** Which other child specs must be done first (by position in the list)
- **Priority:** Inherit from epic, or adjust based on dependency order

### 2c: Present Plan and Confirm

Print the decomposition plan in this format:

```
Decomposition Plan for {epic_id} — {epic_title}
================================================

Source: {design_doc_path or "Epic FR"}
Child specs: {N}

  1. {title_1}
     {description_1}
     Deps: none (foundation)

  2. {title_2}
     {description_2}
     Deps: #1

  ...

  N. {title_N} (integration)
     {description_N}
     Deps: #2, #3
```

If `--dry-run` was specified: Print the plan and EXIT. Do not create any specs.

Otherwise, use `AskUserQuestion`: "Create these {N} child specs?" (Yes / Modify / Cancel)
- **Yes:** Proceed to Step 3.
- **Modify:** Ask which spec to change, iterate, then re-present.
- **Cancel:** EXIT.

## Step 3: Create Child Specs

For each child spec in dependency order:

1. Call `create_spec(title=<title>, priority=<priority>, epic_id=<epic_id>)`.
2. Save the returned `spec_id` and `fr_path`.
3. Print: "Created {spec_id} — {title}"

## Step 4: Wire Dependencies

For each child spec that has dependencies on other child specs:

1. Call `add_dep(spec_id=<child_spec_id>, dep_id=<dep_spec_id>)` for each dependency.
2. Print: "{child_spec_id} depends on {dep_spec_id}"

## Step 5: Author Child Spec FRs

For each child spec, use `refine_fr(spec_id)` to check if the FR is a skeleton. If `is_skeleton` is True, compose the FR content and call `write_fr_refinement(spec_id, agent_output)` with the authored content wrapped in `FR_START` / `FR_END` delimiters.

### Required FR Content

Each child spec FR must include:

1. **Executive Summary:** 1-2 sentences specific to this child spec's deliverable.

2. **Problem:** What specific gap this child spec addresses within the epic scope.

3. **Solution:**
   - **Core Concept:** How this piece will be implemented
   - **Key Components:** Specific modules, classes, or interfaces involved

4. **Acceptance Criteria:**
   - **Functional (AC-F1, AC-F2, ...):** 2-5 concrete, testable criteria. Each must describe observable behavior.
   - **Quality (AC-Q1, AC-Q2):** Always include `Tests pass (make test-quick)` and `No lint/type errors`

### FR Authoring Format

When calling `write_fr_refinement`, wrap the content in delimiters:

```
FR_START
## Executive Summary

[content]

## Problem

[content]

## Solution

### Core Concept

[content]

## Acceptance Criteria

### Functional

- [ ] AC-F1: [criterion]

### Quality

- [ ] AC-Q1: Tests pass (`make test-quick`)
- [ ] AC-Q2: No lint/type errors
FR_END
```

### Guidelines

- Write criteria that are specific to the child spec, not the epic
- Reference actual file paths and module names discovered during codebase exploration
- Leave IMPLs as skeletons -- `/ngo` will refine them at execution time
- Do NOT activate or execute any child specs

## Step 6: Author Epic FR (if skeleton)

If the epic's FR still has placeholder content:

1. Call `refine_fr(epic_id)` to check if the FR is a skeleton.
2. If `is_skeleton` is True, compose the FR content and call `write_fr_refinement(epic_id, agent_output)` with the authored content wrapped in `FR_START` / `FR_END` delimiters.
3. The epic FR should be higher-level than child spec FRs -- focus on goals and outcomes.

If the epic FR already has real content, skip this step.

## Step 7: Validate and Report

1. Call `validate()` to ensure all created specs pass validation.
2. If validation fails, fix the issues and re-validate.
3. Print a summary:

```
Decomposed {epic_id} — {epic_title}
=====================================

Created {N} child specs:
  {spec_id_1} — {title_1}
  {spec_id_2} — {title_2} (depends on {spec_id_1})
  ...

Dependencies wired: {M}
FRs authored: {N}
IMPLs: skeleton (will be refined by /ngo)

Next steps:
  /nloop {epic_id}     — Execute all specs in this epic
  /ngo {first_spec_id} — Execute the first spec
  /nbacklog             — View the updated backlog
```

## Error Handling

- **Epic not found:** Print error from `show()` and EXIT.
- **Epic already fully decomposed:** Warn and ask for confirmation before proceeding.
- **`create_spec` fails:** Print the error, skip that spec, continue with remaining specs. Report failures in the summary.
- **`add_dep` fails (circular dependency):** Print warning, skip that dependency link.
- **Validation fails after creation:** Attempt to fix. If unfixable, print which specs have issues.
- **Design doc not found:** Print "Design document not found at {path}." and fall back to epic FR as input.

## Rules

- **No auto-executing:** Creating specs is planning. Never activate, advance, or execute newly created specs.
- **Explore first:** Always read the codebase before authoring FRs. Concrete file paths and module names make specs actionable.
- **Respect existing specs:** If the epic already has child specs, incorporate them into the plan rather than creating duplicates.
- **Leave IMPLs as skeletons:** Child spec IMPLs are refined by `/ngo` at execution time, not during decomposition.
- **4-8 specs:** If the decomposition yields fewer than 4 specs, the epic may be too narrow for decomposition. If more than 8, the epic is too broad -- suggest splitting into multiple epics.
- **Use only nspec MCP tools:** `create_spec`, `add_dep`, `epic_specs`, `show`, `validate`, `refine_fr`, `write_fr_refinement`, and standard tools (`Read`, `Glob`, `Grep`).
