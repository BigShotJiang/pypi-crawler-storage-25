---
description: Snapshot current session state to a handoff file and emit a /clear-ready resume prompt
argument-hint: [activity-name]
---

Capture the current working session — active epic, active spec, in-flight work, recent commits, and the immediate next action — into a git-tracked audit artifact under `.novabuilt.dev/nspec/audit/handoffs/` via the `audit_record` MCP tool. Then print a short prompt the user can paste into a fresh session (after `/clear`) so the next agent reads the file and resumes work, typically via `/nloop` or `/ngo`.

This skill is **read-only with respect to backlog state**. It must never call `activate`, `advance`, `complete`, `park`, `task_complete`, or any mutating MCP tool. It only reads state and writes a markdown file.

## Argument parsing

Parse `$ARGUMENTS` for an optional free-text activity name (e.g., `tui-validation-cleanup`, `e006-bug-sweep`). If provided, slugify it (lowercase, spaces → `-`, strip non-alphanumerics except `-`) and use it as the `activity-name` segment of the filename. If absent, derive one — see Phase 2 step 5.

## Phase 1 — Gather state

Call these nspec MCP tools in parallel:

- `get_epic()` — currently active epic (id, title), if any
- `session_list()` — current sessions: active spec, phase, last action, checkpoint
- `epics()` — epic dashboard for context
- `next_spec(epic_id=<active>)` — top unblocked spec in the active epic (or `next_spec()` if no active epic)
- `blocked_specs()` — anything paused / blocked / in exception
- `epic_specs(epic_id=<active>, status_filter="incomplete")` — in-progress specs in the active epic

Then shell via Bash (parallel where possible):

- `git rev-parse --abbrev-ref HEAD` — current branch
- `git status --porcelain` — uncommitted changes
- `git log -10 --no-merges --pretty=format:'%h %s'` — last 10 commits

## Phase 2 — Determine topic

1. Activity name: prefer `$ARGUMENTS` (slugified). If absent:
   - If there is an active spec, use the spec's slugified title.
   - Else if there is an active epic, use the epic's slugified title.
   - Else use `idle`.
2. Topic: `<epic-id>-<activity-name>` (e.g., `e006-tui-validation-cleanup`).

Cap activity name at 40 chars. Lowercase. Allowed: `[a-z0-9-]`.

## Phase 3 — Render the handoff file

Render this template (fill in bracketed values from Phase 1):

```markdown
# Handoff — <ISO UTC timestamp>

**Active epic:** <E### — Title, or "none">
**Active spec:** <S### — Title, or "none">
**Phase / last action:** <from session_list; "none" if no session>
**Branch:** <git branch>
**Working tree:** <"clean" or "dirty (N files)">

## Why this handoff exists

<One short paragraph: what was being worked on, what just finished, what's next.
Pull this from the session phase + recent commit subjects + the active spec's
current state. Keep it ≤ 4 sentences. If unclear, say so explicitly — do not
fabricate context.>

## Immediate next action

<ONE concrete next step, phrased as a command. Examples:
- "Resume work on S281 — run `/ngo S281` to continue from <phase>."
- "Pick up the next spec in E006 — run `/nloop e006`."
- "Review and merge open PR <url> before starting new work."
- "No active spec — run `/nloop` to pick the next unblocked spec across all epics."
Choose based on session_list + next_spec + blocked_specs. Prefer /nloop when the
backlog is healthy and no specific spec is mid-flight; prefer /ngo <id> when a
spec is partially executed.>

## In progress

- <spec ID + title for each item from epic_specs(incomplete), with % if available>
- <if none: "_(none)_">

## Up next in the active epic

- <next_spec() result: spec ID + title + one-line rationale>
- <if none: "_(no unblocked work in this epic)_">

## Blockers

- <each item from blocked_specs(): spec ID + reason>
- <if none: "_(none)_">

## Recent commits

1. `<short sha>` — <subject>
2. ...
<cap at 10>

## Uncommitted changes

<output of `git status --porcelain`, fenced. If empty, render: "_(clean)_">

## Epic snapshot

| ID | Priority | Title | Done | Active | Pending | Progress |
|---|---|---|---|---|---|---|
| <row per epic from epics() output> |
```

## Phase 3.5 — Persist via audit_record

Instead of writing directly, call the `audit_record` MCP tool:

```
audit_record(
    kind="handoff",
    topic=<topic from Phase 2>,
    content=<the full rendered template from Phase 3>,
    related_specs=[<active spec ID if any>]
)
```

The tool dispatches body generation to the cheap-model agent (haiku-4-5 by default), writes to `.novabuilt.dev/nspec/audit/handoffs/`, and returns the `path` and `uri`.

## Phase 4 — Print the resume prompt

After the `audit_record` call returns, print the path to the user, followed by a copy-pasteable prompt block they can use in a fresh session after `/clear`. The prompt MUST tell the next agent to:

1. Read the handoff file.
2. Confirm the active epic is set (call `get_epic`; if null, `activate` the epic from the handoff).
3. Execute the **Immediate next action** from the handoff — usually `/nloop` or `/ngo <spec>`.

Format:

```
Handoff written: <path from audit_record response>

Paste this into the fresh session after /clear:

---
Read <path from audit_record> for full session context.

Then:
1. Call get_epic — if no active epic, activate(<E###>) from the handoff.
2. Execute the "Immediate next action" from the handoff: <repeat the one-line action>.
3. Continue autonomously — do not ask for confirmation.
---
```

## Rules

- **Read-only on backlog state.** No `activate`, `advance`, `complete`, `task_complete`, `criteria_complete`, `park`, `exception`, `set_priority`, `add_dep`, `remove_dep`, `create_spec`. This skill must not mutate nspec state.
- **No test runs.** Never invoke `make check`, `make test-quick`, or any test/lint command. Pure snapshot.
- **No fabrication.** If session_list returns nothing useful, write "no active session" rather than inventing a phase.
- **One file per call.** Do not append to or rewrite prior handoff files.
- **Plain headers, no emoji** — match the convention used by `/nstandup`.
- **Activity name slug cap:** 40 chars, `[a-z0-9-]` only.
- **Immediate next action is mandatory.** Even on idle (no active spec, no active epic), produce a concrete action — usually `/nloop` to pick across all epics.
