---
description: File a bug report or feature request against nspec
argument-hint: <optional: brief description of the issue>
---

Guided issue filing for the nspec project. Walks through a structured template via interactive prompts, then creates the issue on GitHub.

## Argument Parsing

Parse `$ARGUMENTS` for an optional brief description. If provided, use it to pre-fill the title and skip the title prompt.

## Step 1: Issue Type

Use `AskUserQuestion` to ask:

> **What type of issue are you filing?**

Options:
- **Bug Report** — Something isn't working as expected
- **Feature Request** — A new capability or behavior
- **Enhancement** — Improve something that already exists
- **Question** — Need clarification on behavior or usage

## Step 2: Title

If `$ARGUMENTS` was provided, use it as the title and show it to the user for confirmation.

Otherwise, use `AskUserQuestion`:

> **Issue title** (concise, imperative — e.g., "validate rejects valid cross-epic deps")

The user enters free text via "Other".

## Step 3: Structured Details (varies by type)

### If Bug Report:

Use `AskUserQuestion` (up to 2 questions per prompt, multiple rounds):

**Round 1:**

> **What happened?** Describe the actual behavior you observed.

(Free text via "Other")

> **What did you expect?** Describe the expected behavior.

(Free text via "Other")

**Round 2:**

> **How do you reproduce this?** Step-by-step reproduction (or "not sure").

(Free text via "Other")

> **Severity?**

Options:
- **Critical** — Blocks all work, data loss, or crash
- **High** — Blocks a workflow but has a workaround
- **Medium** — Annoying but not blocking
- **Low** — Cosmetic or minor inconvenience

### If Feature Request:

**Round 1:**

> **What problem does this solve?** Describe the pain point or gap.

(Free text via "Other")

> **Proposed solution?** How should this work? (high-level is fine)

(Free text via "Other")

**Round 2:**

> **Alternatives considered?** Other approaches you thought of (or "none").

(Free text via "Other")

> **Priority suggestion?**

Options:
- **High** — Blocking or enabling for current work
- **Medium** — Would improve workflow significantly
- **Low** — Nice-to-have

### If Enhancement:

**Round 1:**

> **What exists today?** Describe the current behavior.

(Free text via "Other")

> **What should change?** Describe the desired improvement.

(Free text via "Other")

**Round 2:**

> **Why?** What's the motivation for this change?

(Free text via "Other")

> **Priority suggestion?**

Options:
- **High** — Current behavior is painful
- **Medium** — Would noticeably improve UX
- **Low** — Polish / nice-to-have

### If Question:

> **What's your question?** Include relevant context (command used, config, etc.)

(Free text via "Other")

## Step 4: Gather nspec Context (automatic)

Silently gather context to enrich the issue:

1. Run `nspec --version` via Bash to capture the installed version.
2. Run `python --version` to capture the Python version.
3. Check if there's an active session via the nspec MCP `session_get` tool (if available). If so, note the active spec/epic.

## Step 5: Assemble and Preview

Build the issue body from the gathered information. Use the appropriate template:

### Bug Report Template:

```markdown
## Bug

{what_happened}

## Expected Behavior

{expected}

## Reproduction

{repro_steps}

## Environment

- nspec version: {version}
- Python: {python_version}
- OS: {os_info}
```

### Feature Request Template:

```markdown
## Problem

{problem}

## Proposed Solution

{solution}

## Alternatives Considered

{alternatives}
```

### Enhancement Template:

```markdown
## Current Behavior

{what_exists}

## Desired Behavior

{what_should_change}

## Motivation

{why}
```

### Question Template:

```markdown
## Question

{question}

## Context

- nspec version: {version}
- Python: {python_version}
```

Display the assembled issue to the user:

```
## Preview

**Title:** {title}
**Type:** {type}
**Labels:** {labels}

---
{body}
---
```

Use `AskUserQuestion`:

> **File this issue?**

Options:
- **Submit** — Create the issue on GitHub
- **Edit title** — Change the title before submitting
- **Cancel** — Discard and exit

If "Edit title", ask for the new title and return to preview.

## Step 6: File the Issue

Map type to labels:
- Bug Report → `bug`
- Feature Request → `enhancement`
- Enhancement → `enhancement`
- Question → `question`

Map severity/priority to labels (if applicable):
- Critical → `critical`
- High → `priority:p1`
- Medium → (no extra label)
- Low → `priority:p3`

Create the issue:

```bash
gh issue create --repo Novabuiltdevv/nspec-issues \
  --title "<title>" \
  --body "<assembled_body>" \
  --label "<label1>,<label2>"
```

## Step 7: Report

Print:

```
Filed: <issue_url>
  Title: {title}
  Type: {type}
  Labels: {labels}
```

## Error Handling

- **`gh` not authenticated:** Print "Run `gh auth login` first." and EXIT.
- **Repo not accessible:** Print "Cannot reach Novabuiltdevv/nspec-issues — check your network and `gh auth status`." and EXIT.
- **User cancels at any step:** Print "Issue cancelled." and EXIT.
- **Label doesn't exist:** Create it automatically before filing:
  ```bash
  gh label create <name> --repo Novabuiltdevv/nspec-issues --color "<color>"
  ```
  Colors: `critical` = `B60205`, `priority:p1` = `D93F0B`, `priority:p3` = `0E8A16`

## Rules

- **Respect user input verbatim:** Don't rephrase or "improve" what the user wrote. Assemble it into the template as-is.
- **Minimal enrichment:** Add version/env info automatically but don't inject opinions or suggestions into the issue body.
- **One issue at a time:** This skill files a single issue. For bulk operations, use `/ntriage`.
