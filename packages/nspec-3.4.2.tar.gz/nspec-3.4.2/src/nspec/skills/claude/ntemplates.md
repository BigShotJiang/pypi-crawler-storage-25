---
description: List available nspec builtin templates with their variables and descriptions
---

List available nspec builtin templates that can be bootstrapped into a project.

## Templates

| Template | Description | Variables |
|----------|-------------|-----------|
| `fr` | Feature request template for spec authoring | *(none — static template)* |
| `impl` | Implementation plan template for spec authoring | *(none — static template)* |
| `claudemd` | CLAUDE.md project instructions file | `project_name`, `docs_root`, `feature_requests`, `implementation`, `completed` |
| `changelog` | Project changelog | *(none — static template)* |
| `devprocess` | DEV-PROCESS.md developer workflow guide | `project_name`, `docs_root`, `feature_requests`, `implementation`, `completed`, `test_command`, `lint_command`, `format_command`, `check_command`, `commit_format` |

## Variable Reference

### `devprocess` template variables

| Variable | Description | Default |
|----------|-------------|---------|
| `project_name` | Display name of the project | *(detected from directory or git remote)* |
| `docs_root` | Relative path to the docs directory | `docs` |
| `feature_requests` | Subdirectory for active FRs | `frs/active` |
| `implementation` | Subdirectory for active IMPLs | `impls/active` |
| `completed` | Subdirectory for archived specs | `completed` |
| `test_command` | Command to run tests | `make test-quick` |
| `lint_command` | Command to run linter | `make lint` |
| `format_command` | Command to auto-format | `make format` |
| `check_command` | Full quality gate command | `make check` |
| `commit_format` | Commit message convention | `feat(scope): description` |

### `claudemd` template variables

| Variable | Description | Default |
|----------|-------------|---------|
| `project_name` | Display name of the project | *(detected from directory or git remote)* |
| `docs_root` | Relative path to the docs directory | `docs` |
| `feature_requests` | Subdirectory for active FRs | `frs/active` |
| `implementation` | Subdirectory for active IMPLs | `impls/active` |
| `completed` | Subdirectory for archived specs | `completed` |

## Viewing Template Content

To see the raw content of any template, use the `load_template` API:

```python
from nspec.resources import load_template
content = load_template("devprocess")  # or "fr", "impl", "claudemd", "changelog"
```

Variables use `{{variable_name}}` placeholder syntax.

## Related Commands

- `/nbootstrap` — Interactively generate a project-specific DEV-PROCESS.md from the `devprocess` template
