---
description: Audit and resolve GitHub issue sync mismatches for an epic
argument-hint: "[epic_id] (default: active epic)"
---

# /nsync-issues — Bidirectional GitHub Issue Sync

Audit an epic's specs against the GitHub issue tracker, then walk through each mismatch interactively.

## Argument Parsing

Parse `$ARGUMENTS` for:
- `e###` or `E###` → epic ID to audit
- No argument → use the active epic from `get_epic()`

## Phase 1: Audit

1. Call `issue_sync(epic_id=<resolved_epic>)` to get the sync report.
2. If the report has no mismatches (all counts are 0), print "All specs in sync with GitHub issues." and **EXIT**.
3. Print a summary table:

```
Sync Report for E006:
  Local-only specs (no GitHub issue):  3
  Diverged (status mismatch):          2
  Orphan issues (no linked spec):      1
```

## Phase 2: Resolve Local-Only Specs

For each spec in `local_only`:

1. Print: `{spec_id}: {title} ({spec_status}) — no GitHub issue`
2. Use `AskUserQuestion` to ask:
   > Create a GitHub issue for **{spec_id}**?
   > - **yes** — create issue and link it
   > - **skip** — leave as-is
3. If "yes": Call `create_issue(spec_id=<id>)`. Print the issue URL.
4. If "skip": Continue to next.

## Phase 3: Resolve Diverged Specs

For each spec in `diverged`:

1. Print: `{spec_id}: {title} — spec is {spec_status} but issue is {issue_state}`
2. Use `AskUserQuestion` to ask:
   > How should we resolve **{spec_id}** ({github_ref})?
   > - **close** — close the GitHub issue (spec is done/superseded)
   > - **reopen** — reopen the GitHub issue (spec is still active)
   > - **supersede** — supersede the spec (issue was closed externally)
   > - **skip** — leave as-is
3. If "close": Run `gh issue close <number> -R <repo> --comment "Closed via /nsync-issues — spec {spec_id} is {spec_status}"` via Bash.
4. If "reopen": Run `gh issue reopen <number> -R <repo> --comment "Reopened via /nsync-issues — spec {spec_id} is still {spec_status}"` via Bash.
5. If "supersede": Call `supersede(spec_id=<id>, superseded_by="external-close")` — the issue was closed outside of nspec.
6. If "skip": Continue to next.

## Phase 4: Resolve Orphan Issues

For each issue in `orphan_issues`:

1. Print: `#{number}: {title} ({url}) — open with 'imported' label but no linked spec`
2. Use `AskUserQuestion` to ask:
   > How should we resolve orphan issue **#{number}**?
   > - **import** — import as a new spec via `issue_import`
   > - **close** — close the issue (no longer relevant)
   > - **skip** — leave as-is
3. If "import": Call `issue_import(repo=<repo>, number=<number>)`.
4. If "close": Run `gh issue close <number> -R <repo> --comment "Closed via /nsync-issues — no matching spec"` via Bash.
5. If "skip": Continue to next.

## Phase 5: Summary

Print final summary:
- Issues created: N
- Issues closed: N
- Issues reopened: N
- Specs superseded: N
- Specs imported: N
- Skipped: N

## Required MCP Tools

| Tool | Phase |
|------|-------|
| `get_epic` | Argument resolution |
| `issue_sync` | Phase 1 — audit |
| `create_issue` | Phase 2 — create issues for local-only specs |
| `issue_import` | Phase 4 — import orphan issues |
| `supersede` | Phase 3 — supersede diverged specs |
