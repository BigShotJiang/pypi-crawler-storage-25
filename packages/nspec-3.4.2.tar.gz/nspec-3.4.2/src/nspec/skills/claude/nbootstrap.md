---
description: Bootstrap a project-specific DEV-PROCESS.md from nspec's devprocess template with stack detection and variable resolution
---

Generate a project-specific DEV-PROCESS.md by detecting the project's stack, resolving template variables, interpolating the devprocess template, and registering the result as a managed artifact.

## Step 1: Check for Existing DEV-PROCESS.md

Look for `DEV-PROCESS.md` in the project root.

- **If it exists and starts with `<!-- managed-by: nspec -->`:** This is an nspec-managed file. Proceed — it will be overwritten with the updated version.
- **If it exists but does NOT have the managed-by marker:** This is a user-owned file. Do NOT overwrite. Instead, print:
  ```
  Found existing DEV-PROCESS.md without managed-by marker.
  This file is user-owned — /nbootstrap will not overwrite it.
  To convert it to a managed artifact, add `<!-- managed-by: nspec -->` as the first line.
  ```
  **EXIT.**
- **If it does not exist:** Continue to Step 2.

## Step 2: Detect Project Stack

Scan the project to determine tooling and conventions:

1. **Project name:** Derive from the directory name, `pyproject.toml` `[tool.poetry.name]`, `package.json` `name`, `Cargo.toml` `[package].name`, or git remote.

2. **Test command:** Look for:
   - `Makefile` with `test-quick` or `test` target → `make test-quick` / `make test`
   - `pyproject.toml` with pytest config → `pytest`
   - `package.json` with `test` script → `npm test`
   - `Cargo.toml` → `cargo test`
   - Default: `make test`

3. **Lint command:** Look for:
   - `Makefile` with `lint` target → `make lint`
   - `pyproject.toml` with ruff/flake8 config → `ruff check .`
   - `package.json` with `lint` script → `npm run lint`
   - Default: `make lint`

4. **Format command:** Look for:
   - `Makefile` with `format` target → `make format`
   - `pyproject.toml` with ruff/black config → `ruff format .`
   - `package.json` with `format` script → `npm run format`
   - Default: `make format`

5. **Check command:** Look for:
   - `Makefile` with `check` target → `make check`
   - Default: `make check`

6. **Commit format:** Look for:
   - Existing commits with conventional format → detect pattern (e.g. `feat(scope): description`)
   - `.commitlintrc` or commitlint config → extract format
   - Default: `feat(scope): description`

7. **Docs root:** Check `.novabuilt.dev/nspec/config.toml` for `[paths]` section, or default to `docs`.

8. **Path config:** From config.toml or defaults:
   - `feature_requests` → `frs/active`
   - `implementation` → `impls/active`
   - `completed` → `completed`

## Step 3: Confirm Variables

Present the detected variables to the user for confirmation:

```
Detected project settings for DEV-PROCESS.md:

  project_name:     {{detected_name}}
  test_command:      {{detected_test}}
  lint_command:      {{detected_lint}}
  format_command:    {{detected_format}}
  check_command:     {{detected_check}}
  commit_format:     {{detected_commit}}
  docs_root:         {{detected_docs}}
  feature_requests:  {{detected_frs}}
  implementation:    {{detected_impls}}
  completed:         {{detected_completed}}

Proceed with these values? (Suggest changes if needed)
```

Use `AskUserQuestion` to let the user confirm or override any values.

## Step 4: Load and Interpolate Template

1. Load the devprocess template content. The template uses `{{variable_name}}` placeholders.
2. Replace each `{{variable}}` with the confirmed value from Step 3.
3. Ensure the first line is `<!-- managed-by: nspec -->` (the template already includes this).

## Step 5: Write the File

1. Write the interpolated content to `DEV-PROCESS.md` in the project root.
2. Print the file path and a summary of what was generated.

## Step 6: Register in Artifact Manifest

Register the generated file using the `ArtifactManifest` API from `nspec.artifacts`. This ensures correct schema, checksum computation, and manifest persistence:

```python
from pathlib import Path
from nspec.artifacts import ArtifactManifest

project_root = Path(".")  # or detected project root
manifest = ArtifactManifest.load(project_root)
manifest.register(
    artifact_id="devprocess",
    path="DEV-PROCESS.md",
    source="template",
    project_root=project_root,
    managed=True,
)
manifest.save(project_root)
```

- `ArtifactManifest.load()` returns an empty manifest if `artifacts.json` doesn't exist yet.
- `register()` computes the SHA-256 checksum from the file on disk and stores it as `sha256:<hex>`.
- `save()` persists the manifest to `.novabuilt.dev/nspec/artifacts.json`.

Print:
```
Registered DEV-PROCESS.md in artifact manifest.
```

## Step 7: Summary

Print a completion summary:

```
Bootstrapped DEV-PROCESS.md for {{project_name}}

  Template:  devprocess
  Managed:   yes (<!-- managed-by: nspec -->)
  Manifest:  .novabuilt.dev/nspec/artifacts.json

To view available templates: /ntemplates
To re-generate after config changes: /nbootstrap
```

## Related Commands

- `/ntemplates` — List available templates and their variables
