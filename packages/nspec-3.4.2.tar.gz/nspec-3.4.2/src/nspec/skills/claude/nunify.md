---
description: Detect and resolve spec ID collisions after branch merges
argument-hint: (no arguments)
---

Detect and resolve spec ID collisions — when two specs share the same numeric ID (e.g., two `FR-S257-*.md` files with different slugs). This happens when CI and local sessions both allocate the same ID against different repo snapshots.

## Usage

```
/nunify
```

## Flow

1. Call `unify_collisions()` MCP tool (no arguments needed — it scans the active FR directory).
2. **If the response has no resolutions** (empty list):
   - Print: "No collisions detected."
   - **EXIT.**
3. **If collisions were resolved**, for each resolution:
   - Print the collision details: which file was kept, which was renumbered, and the new ID.
   - Print all changes (file renames, header updates, deps updates).
4. Run `nspec validate` via Bash to confirm the dataset is clean after resolution.
5. Print a summary: "Resolved N collision(s). Run `git diff` to review changes."

## Example Output

```
Collision detected: S257 has 2 specs
  - FR-S257-github-actions-pipeline.md (older, kept)
  - FR-S257-add-search-feature.md (newer, renumbered → S259)
Changes:
  - Renamed FR-S257-add-search-feature.md → FR-S259-add-search-feature.md
  - Renamed IMPL-S257-add-search-feature.md → IMPL-S259-add-search-feature.md
  - Updated E001 deps: S257 → S259

Validation: passed
Resolved 1 collision(s). Run `git diff` to review changes.
```
