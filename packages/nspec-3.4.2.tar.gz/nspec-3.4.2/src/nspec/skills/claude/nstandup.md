---
description: Generate a status update from nspec backlog + git history since the last standup
---

Produce a written status update combining current backlog state with git activity since the last standup, and persist it under `.novabuilt.dev/nspec/status-updates/`.

## Argument parsing

Parse `$ARGUMENTS` for optional flags:

- `--since <N>d` — override auto-detection with an explicit window (e.g., `--since 7d`, `--since 24h`).
- `--dry-run` — render the template and print it, but do NOT write a file.
- No arguments — auto-detect the window from the newest prior `STANDUP-*.md` file (or fall back to "last 24h" if none exist).

## Phase 1 — Determine the "since" window

1. Ensure the directory exists: `mkdir -p .novabuilt.dev/nspec/status-updates`.
2. If `--since <N>d` was passed, use that value directly and record the human-readable form (e.g., `last 7 days`) in the Window header.
3. Otherwise, list prior standups: `ls .novabuilt.dev/nspec/status-updates/STANDUP-*.md 2>/dev/null | sort | tail -1`.
4. If a prior file exists and its filename parses as `STANDUP-<YYYYMMDDTHHMMSSZ>.md`, convert the timestamp to an ISO form suitable for `git log --since` and record it in the Window header.
5. If no prior file exists, or the newest filename can't be parsed, fall back to `--since="24 hours ago"` and record `last 24h (no prior standup found)` in the Window header.

## Phase 2 — Gather data

Call these nspec MCP tools (use parallel tool calls where possible):

- `epics()` — full epic dashboard: IDs, priorities, titles, done/active/pending counts, progress %
- `get_epic()` — currently active epic, if any
- `next_spec(epic_id=<active>)` — top unblocked spec for the active epic (fall back to `next_spec()` with no epic if `get_epic()` returns null)
- `blocked_specs()` — anything paused, in-exception, or with blocked tasks, including reasons
- `epic_specs(epic_id=<active>, status_filter="incomplete")` — in-progress specs in the active epic

Then shell the git window via Bash:

- `git log --since=<window> --no-merges --pretty=format:'%h %s'` — commit subjects in the window
- `git log --since=<window> --name-only --pretty=format:'' -- docs/completed/done/` — files added under `docs/completed/done/` in the window (proxy for "specs shipped"); dedupe and map each path back to a spec ID + title

## Phase 3 — Render the template and persist

Compute the new filename: `STANDUP-$(date -u +%Y%m%dT%H%M%SZ).md` under `.novabuilt.dev/nspec/status-updates/`.

Render this template (fill in the bracketed values from Phase 2):

```markdown
# Standup — <human date, e.g. "Saturday 2026-04-11 (UTC)">

**Window:** <prior standup timestamp or "last 24h (no prior standup found)" or "last 7 days"> → now
**Active epic:** <E### — Title, or "none">

## Shipped since last standup

- <spec ID + title for each file added under docs/completed/done/ in the window>
- <if none: "_(none)_">

## In progress

- <spec ID + title for each item from epic_specs(incomplete), with % task completion if available>
- <if none: "_(none)_">

## Up next

- <next_spec() result: spec ID + title + one-line rationale (why it's next)>
- <if none: "_(no unblocked work in the active epic)_">

## Blockers

- <each item from blocked_specs(): spec ID + blocker reason>
- <if none: "_(none)_">

## Epic progress

| ID | Priority | Title | Done | Active | Pending | Progress |
|---|---|---|---|---|---|---|
| <row per epic from epics() output> |

## Commits

1. `<short sha>` — <commit subject>
2. ...

<if git log returned zero commits, render: "_(none)_">
```

**Persistence:**

- If `--dry-run`: print the rendered content to the user and STOP. Do not write the file.
- Otherwise: call `execute_agent(prompt=<summarization prompt>, purpose="handoff")` to generate a polished standup from the raw data, then write the result to `.novabuilt.dev/nspec/status-updates/STANDUP-<UTC timestamp>.md` using the Write tool, and print it to the user. The summarization prompt should include all the raw data gathered in Phase 2 and ask for the standup template format. This routes the summarization through the cheap-model agent configured in `[handoff]` (default: haiku-4-5).

## Notes

- **Plain-text section headers, no emoji** — consistent with recent FR/IMPL emoji-stripping direction (see commit `2711842`). Standup files are not spec files so the rule is softer, but keep them plain by default.
- **Commit count cap**: if `git log` returns more than ~30 subjects, render the first 30 and append a line `_(... N more, see `git log` for full list)_` to keep the file scannable.
- **No test runs** — this skill is read-only and must never invoke `make check`, `make test-quick`, or mutate backlog state.
- **Error on missing git repo** is fine — let it surface. This skill is meant to be run from within the nspec repo.
