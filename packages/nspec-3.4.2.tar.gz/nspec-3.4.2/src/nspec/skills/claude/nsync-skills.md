---
description: Sync nspec skills to the current project
---

Sync nspec's bundled skills (slash commands) to the current project by running the CLI command.

## Steps

1. Run `nspec skills sync` via Bash tool to install skills to `.novabuilt.dev/nspec/commands/` and symlink to agent directories
2. Report what was installed/updated based on the output
3. If the user wants to see what's available, run `nspec skills list`
4. Use `--force` flag if the user wants to overwrite non-managed files
