---
description: CI dashboard — list recent runs, watch active runs, drill into failures
argument-hint: [watch|status|push]
---

CI dashboard for GitHub Actions. Shows recent runs, watches active builds, drills into failures.

## Argument Parsing

Parse `$ARGUMENTS` for a subcommand:

- **`watch`** — Watch the latest in-progress run on the current branch (default if no argument)
- **`status`** — Show recent run history with pass/fail and durations
- **`push`** — Push current branch, then watch the triggered run
- **No argument** — Same as `watch`

## Subcommand: `status`

Show a dashboard of recent CI runs.

```bash
gh run list --workflow=test.yml --limit=10 --json databaseId,conclusion,headBranch,displayTitle,createdAt,updatedAt
```

For each run, compute duration from the test job:

```bash
gh run view <run_id> --json jobs --jq '.jobs[] | select(.name=="test") | {duration: ((.completedAt | fromdateiso8601) - (.startedAt | fromdateiso8601))}'
```

Present as a table:

```
| # | Branch | Commit | Status | Duration | When |
|---|--------|--------|--------|----------|------|
| 1 | main   | ci: remove codecov | ✓ pass | 2m53s | 10m ago |
| 2 | main   | fix(github): ...   | ✓ pass | 4m16s | 30m ago |
```

If any run failed, offer: "Want me to drill into run #N?"

## Subcommand: `watch`

Watch the latest run on the current branch.

1. Get the current branch: `git branch --show-current`
2. Find the latest run:
   ```bash
   gh run list --workflow=test.yml --branch=<branch> --limit=1 --json databaseId,status --jq '.[0]'
   ```
3. If the run is `in_progress` or `queued`:
   ```bash
   gh run watch <run_id> --exit-status
   ```
   Report the result: pass or fail.
4. If the run is already `completed`, show its conclusion and duration. If it failed, drill into the failure automatically.

## Subcommand: `push`

Push and watch.

1. Check for unpushed commits:
   ```bash
   git log --oneline @{upstream}..HEAD 2>/dev/null
   ```
   If no unpushed commits, print "Nothing to push." and fall through to `watch`.
2. Push:
   ```bash
   git push
   ```
3. Wait a few seconds for GitHub to register the run, then:
   ```bash
   gh run list --workflow=test.yml --branch=<branch> --limit=1 --json databaseId --jq '.[0].databaseId'
   ```
4. Watch the run:
   ```bash
   gh run watch <run_id> --exit-status
   ```
5. Report pass/fail.

## Drilling into Failures

When a run fails (either from `watch` or `status`):

1. Get the failed job logs:
   ```bash
   gh run view <run_id> --log-failed 2>&1 | tail -50
   ```
2. Summarize the failure: which step failed, what the error was, and suggest a fix if obvious.
3. If the failure is in the test step, extract the failing test name and the assertion error.

## Error Handling

- **`gh` not installed:** Print "GitHub CLI (gh) is required. Install: https://cli.github.com/" and EXIT.
- **No workflow runs found:** Print "No CI runs found for branch <branch>." and EXIT.
- **Not a git repo:** Print "Not in a git repository." and EXIT.
- **No upstream set:** On `push`, use `git push -u origin <branch>` instead.

## Examples

```
User: /nci
→ Watches latest run on current branch

User: /nci status
→ Shows table of last 10 runs with durations

User: /nci push
→ Pushes, watches triggered run, reports result

User: /nci watch
→ Same as no argument — watch latest run
```
