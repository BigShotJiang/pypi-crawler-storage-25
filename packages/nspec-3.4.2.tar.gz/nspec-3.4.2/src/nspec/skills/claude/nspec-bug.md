---
description: Report a bug or request a feature for nspec itself
argument-hint: <optional: brief description of the issue>
---

File a bug report or feature request against **nspec itself** to `Novabuiltdevv/nspec-issues`. This skill always targets nspec's issue tracker — it ignores all project-level repo config (`--repo`, `NSPEC_GITHUB_REPO`, `config.github.issues_repo`).

For filing issues against your **project's** repo, use `/nfileissue` instead.

## Argument Parsing

Parse `$ARGUMENTS` for an optional brief description. If provided, use it to pre-fill the title.

**IMPORTANT:** If `$ARGUMENTS` contains `--repo` or any repo override flag, reject immediately:

> **Error:** `/nspec-bug` always files to `Novabuiltdevv/nspec-issues`. To file issues against a project repo, use `/nfileissue`.

EXIT.

## Step 1: Issue Type

Ask the user:

> **Bug or feature request?**

Options:
- **Bug** — Something in nspec is broken or behaving unexpectedly
- **Feature Request** — A new nspec capability or improvement

## Step 2: Title

If `$ARGUMENTS` was provided (and no `--repo` flag), use it as the title and confirm with the user.

Otherwise, ask:

> **Title** (concise, imperative — e.g., "validate crashes on empty FR file")

## Step 3: Description

### If Bug:

Ask:

> **What happened?** Describe the actual behavior.

Then ask:

> **Steps to reproduce?** (or "not sure")

### If Feature Request:

Ask:

> **What should nspec do?** Describe the desired behavior or capability.

## Step 4: Gather Environment Context (automatic — do not ask)

Silently gather:

1. Run `nspec --version` via Bash to get the nspec version. If it fails, use "unknown".
2. Run `python3 --version` via Bash to get the Python version.
3. Run `uname -s -r` via Bash to get the OS info.
4. Call `get_epic()` to check for an active spec/epic context (optional enrichment).

## Step 5: Assemble Issue Body

### Bug Template:

```markdown
## Bug Report

{description}

## Steps to Reproduce

{repro_steps}

## Environment

- **nspec:** {nspec_version}
- **Python:** {python_version}
- **OS:** {os_info}
- **Active spec:** {active_spec_or_none}
```

### Feature Request Template:

```markdown
## Feature Request

{description}

## Environment

- **nspec:** {nspec_version}
- **Python:** {python_version}
- **OS:** {os_info}
```

## Step 6: File the Issue

Determine the label:
- Bug → `bug`
- Feature Request → `enhancement`

**CRITICAL:** The target repo is ALWAYS `Novabuiltdevv/nspec-issues`. Never read from project config. This is hardcoded.

Run via Bash. **Shell safety:** Write the body to a temp file and use `--body-file` to avoid shell injection from user-provided text. Quote the title with single quotes and escape any embedded single quotes.

```bash
# Write body safely to temp file
BODY_FILE=$(mktemp)
cat > "$BODY_FILE" << 'NSPEC_BODY_EOF'
<assembled_body>
NSPEC_BODY_EOF

# File the issue with safe quoting
gh issue create --repo Novabuiltdevv/nspec-issues \
  --title '<title_with_single_quotes_escaped>' \
  --body-file "$BODY_FILE" \
  --label "<label>"

# Clean up
rm -f "$BODY_FILE"
```

### Error Handling

Handle errors **immediately and directly** (per E010 Error Reporting Contract):

- **`gh` not found:** Print `Error: gh CLI not installed. Install from https://cli.github.com/` and EXIT.
- **Auth failure (exit code 4 or "not logged in"):** Print `Error: Not authenticated to GitHub. Run 'gh auth login' first.` and EXIT.
- **API/network error:** Print the error message from `gh` directly to the user and EXIT.

Do NOT batch errors. Do NOT swallow them. Display each error as it occurs.

## Step 7: Report Result

Extract the issue URL from the `gh issue create` output and print:

```
Filed: <issue_url>
  Title: <title>
  Label: <label>
```

## Rules

- **Hardcoded repo:** ALWAYS `Novabuiltdevv/nspec-issues`. NEVER read `config.github.issues_repo`, `NSPEC_GITHUB_REPO`, or `--repo`.
- **Reject `--repo`:** If the user passes `--repo`, error out and point to `/nfileissue`.
- **Respect user input verbatim:** Don't rephrase the user's description.
- **Minimal enrichment:** Add version/env info automatically but don't inject opinions.
- **One issue at a time.**
- **Direct errors:** Show errors immediately, not batched.
