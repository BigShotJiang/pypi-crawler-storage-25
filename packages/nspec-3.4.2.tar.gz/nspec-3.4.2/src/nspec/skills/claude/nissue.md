---
description: Import GitHub issues as nspec specs with interactive refinement
argument-hint: "[repo#number or just number if repo configured]"
---

# /nissue — Import GitHub Issue as nspec Spec

## Argument Parsing

Parse the argument to extract repo and issue number:
- `owner/repo#42` → repo=`owner/repo`, number=`42`
- `42` → number=`42`, repo from `[github].repo` config
- No argument → browse mode (list issues first)

## Flow

### 1. Resolve Repository

```
If repo from argument:
  Use it
Else:
  Call issue_list() with no repo → config fallback
  If still no repo → AskUserQuestion: "Which GitHub repo? (owner/repo format)"
```

### 2. Select Issue

```
If number from argument:
  Call issue_import(repo, number, dry_run=true) → preview
  Show preview to user
Else:
  Call issue_list(repo) → show table
  AskUserQuestion: "Which issue number to import?"
```

### 3. Determine Epic

```
Call epics() → list available epics
Call get_epic() → check active epic
If active epic exists:
  Suggest it as default
AskUserQuestion: "Which epic? (or press Enter for {active_epic})"
```

### 4. Determine Priority

```
Show the label-mapped priority from dry_run preview
AskUserQuestion: "Priority {mapped_priority} from labels. Confirm or override (P0-P3):"
```

### 5. Import

```
Call issue_import(repo, number, epic_id, priority)
Show result: spec_id, FR path, IMPL path, issue link
```

### 6. Refine IMPL (Optional)

```
AskUserQuestion: "Refine IMPL with agent? (y/n)"
If yes:
  Call refine_impl(spec_id) → get prompt
  Call execute_agent(prompt) → get refinement
  Call write_refinement(spec_id, content)
```

### 7. Validate

```
Call validate()
Report any issues
```

### 8. Summary

Print:
- Spec ID and title
- Epic assignment
- Priority (with label source)
- GitHub issue link
- FR and IMPL paths
- Next steps: "Run /ngo {spec_id} to start implementation"
