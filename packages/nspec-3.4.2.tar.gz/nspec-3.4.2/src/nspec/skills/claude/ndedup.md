---
description: Deduplicate and group specs within an epic — find duplicates, supersede them, close linked GitHub issues
argument-hint: "[epic_id] [--dry-run]"
---

Group all specs in an epic by topic similarity, then identify and resolve duplicates, then redistribute survivors to appropriate epics. Three phases, all within this skill:

**Phase 1 — Dedup:** Run the deterministic analysis script, review its output, supersede duplicates, close linked GitHub issues.

**Phase 2 — Redistribute:** Classify surviving open specs as bug or feature (script-driven). Bugs stay in the source epic. Features get proposed for redistribution.

**Phase 3 — Bind:** Add deps within topic groups to create intra-group cohesion (but no cross-group deps).

## Argument Parsing

Parse `$ARGUMENTS` for:
- An epic ID (e.g., `E006`, `e001`, or bare `006`) — optional, falls back to active epic
- `--dry-run` → show analysis but take no action

If no epic ID is provided, call `get_epic` to get the active epic. If no active epic, print "No epic specified and no active epic set." and **EXIT**.

## Step 1: Run Analysis Script

Run the deterministic dedup analysis script via Bash:

```bash
python -m nspec.analysis.dedup <epic_id> --format json 2>&1
```

This script (`src/nspec/analysis/dedup.py`) does all matching algorithmically:
- **Title normalization:** strips prefixes, lowercases, removes noise words, sorts tokens
- **Jaccard similarity:** token-set overlap (threshold: 0.5 for near, 0.95 for exact)
- **Bug/feature classification:** keyword regex + GitHub issue label lookup via `gh` CLI
- **Topic grouping:** keyword matching against predefined topic definitions

The script returns structured JSON with these fields:
- `census` — spec counts by bucket (open, closed, superseded, deferred)
- `specs` — full spec entries with classification
- `exact_duplicates` — pairs with similarity >= 0.95, same status bucket
- `near_duplicates` — pairs with similarity 0.5–0.95, same status bucket
- `cross_status_matches` — pairs where one is open and the other closed/superseded
- `topic_groups` — specs grouped by functional area

**If the script fails**, print the error and **EXIT**. Do not fall back to LLM-based guessing.

## Step 2: Present Script Findings

Parse the JSON output and present it as a readable report. For each section:

### Census

```
## {epic_id} Spec Census

| Bucket | Count |
|--------|-------|
| Open | N |
| Closed | N |
| Superseded | N |
| Deferred | N |
| **Total** | N |
```

### Duplicate Candidates

For each duplicate pair (exact, near, and cross-status), display:

```
### Exact Duplicates
| Spec A | Spec B | Similarity | Recommendation |
|--------|--------|------------|----------------|
| S929   | S933   | 1.0        | Supersede S933 |

### Cross-Status Matches (open ↔ closed/superseded)
| Open Spec | Closed Spec | Similarity | Recommendation |
|-----------|-------------|------------|----------------|
| S938      | S346        | 0.85       | Supersede S938 (already done) |
```

### LLM Review Gate

**The script handles matching. The LLM handles verification.**

For each duplicate candidate with similarity < 1.0, call `show(spec_id)` on both specs to verify the scope actually overlaps. The script can't distinguish "same title, different scope" from "same title, same scope" — that's the one place LLM judgment is needed.

For exact duplicates (similarity = 1.0), no verification needed — proceed directly.

Present the final action list after verification:

```
## Proposed Actions

| # | Action | Spec | Target | Source | Reason |
|---|--------|------|--------|--------|--------|
| 1 | Supersede | S933 | S929 | script (exact, 1.0) | Identical title |
| 2 | Supersede | S938 | S346 | script (cross, 0.85) + LLM verified | Same scope |
| 3 | Skip | S949 | S294 | script (cross, 0.7) + LLM rejected | Different scope |
```

## Step 3: Confirm and Execute (Phase 1)

If `--dry-run` was specified, print "Dry run — no changes made." and **EXIT**.

Otherwise, use `AskUserQuestion`:

> **Execute N supersede actions?**

Options:
- **"Execute all"** — apply all proposed supersede actions
- **"Review one by one"** — confirm each action individually
- **"Cancel"** — exit without changes

### For each supersede action:

1. Call `supersede(spec_id=<duplicate>, superseded_by=<keeper>)`.
2. If the spec has a `github_issue` field in the script output, close the GitHub issue:
   ```bash
   gh issue comment <N> --repo Novabuiltdevv/nspec-issues \
     --body "Closing as duplicate — covered by spec **<keeper>**."
   gh issue close <N> --repo Novabuiltdevv/nspec-issues --reason "not planned"
   ```

## Step 4: Redistribute (Phase 2)

### 4a: Use Script Classifications

The script already classified each open spec as `bug`, `feature`, or `ambiguous` using:
1. GitHub issue labels (`bug` → bug, `enhancement` → feature)
2. Title keyword regex (deterministic fallback)

For `ambiguous` specs, use `AskUserQuestion` to ask the user:

> **Classify {spec_id}: "{title}" — bug or feature?**

### 4b: Epic Assignment

1. Call `epics()` to load all available epics.
2. Bugs stay in the current epic — no action needed.
3. For features, propose epic assignment based on topic groups from the script:
   - Specs in "TUI" group → epic that owns TUI work
   - Specs in "CLI/Skills" group → E001 (Platform)
   - Specs in "Context/Docs" group → E001 (Platform)
   - Specs in "Review/Workflow" group → check for review-specific epic, else E001
   - Specs with "LangGraph" or "StateGraph" in title → E017

Present the redistribution table and use `AskUserQuestion` to confirm.

### 4c: Move Specs

For each confirmed move, update the `epic_id:` field in both FR and IMPL files:

```bash
sed -i '' "s/^epic_id: <old_epic>/epic_id: <new_epic>/" <fr_path>
sed -i '' "s/^epic_id: <old_epic>/epic_id: <new_epic>/" <impl_path>
```

## Step 5: Re-run Analysis After Moves

After redistribution, **re-run the script** on the target epics to catch duplicates introduced by the moves:

```bash
python -m nspec.analysis.dedup <target_epic> --skip-github --format json 2>&1
```

If new exact duplicates are found (moved spec has same title as existing spec in target epic), present them and supersede the higher-ID duplicate.

## Step 6: Bind Groups (Phase 3)

For specs that survived dedup and remain in the same epic, use the script's `topic_groups` to add intra-group deps:

1. Within each topic group, identify the **anchor spec** — the lowest-ID open spec.
2. For other open specs in the same group and same epic, call `add_dep(spec_id=<other>, dep_id=<anchor>)`.

**Skip binding if:**
- The group has only one open spec
- The specs are in different epics after redistribution

## Step 7: Summary Report

```
## Dedup & Redistribute Results — {epic_id}

### Phase 1: Dedup
| Action | Count | Source |
|--------|-------|--------|
| Superseded | N | script |
| GH issues closed | N | script |

### Phase 2: Redistribute
| Action | Count |
|--------|-------|
| Bugs kept | N |
| Features moved | N |
| Cross-epic dupes resolved | N |

### Phase 3: Bind
| Deps added | N |
| Groups bound | N |

**Before → After:** {epic_id} had M open specs, now has N
```

## Rules

- **Script first, LLM second:** All matching, classification, and grouping comes from `nspec.analysis.dedup`. The LLM only does scope verification for near-duplicates (sim < 1.0) and resolves ambiguous classifications.
- **Re-run after moves:** Always re-run the script on target epics after redistribution to catch duplicates created by the move.
- **Keep the older/more-progressed spec:** The script handles this deterministically — lower spec ID wins when progress is equal.
- **Don't bind groups together:** Deps only connect specs within the same topic group.
- **Bugs stay put:** Specs classified as bugs never leave the source epic.
- **GitHub issue sync:** When superseding a spec linked to a GitHub issue, close the issue with a comment.
- **No orphan moves:** Don't move a spec to an epic where it has no topical connection.
- **Fail loud:** If the script errors, don't guess. Fix the script or ask the user.
