---
description: Create a new epic with goals, scope, and child spec decomposition
argument-hint: <description of the epic's goal>
---

Create a new nspec epic from a natural-language description. Analyzes the codebase to define the epic's scope, goals, and initial child spec breakdown.

## Argument Parsing

Parse `$ARGUMENTS` for a natural-language description of the epic's goal or theme.

- If no argument is provided, use `AskUserQuestion` to ask: "What's the goal of this epic?" with a free-text input.
- The description can be a sentence, phrase, or short paragraph.

## Step 1: Gather Context

### 1a: Determine Priority

Use `AskUserQuestion` to ask "What priority for this epic?" with these options:
- **P1 High** — Critical initiative
- **P2 Medium (Recommended)** — Standard workstream
- **P3 Low** — Backlog / future work

### 1b: Check for Existing and In-Flight Work

Before exploring the codebase, check what already exists and what's in progress:

1. **Check existing epics:** Call `epics()` to see what's already organized. If an existing epic overlaps significantly with the description, warn the user and suggest adding specs to that epic instead.
2. **Check open PRs:** Run `gh pr list --state open --json title,headRefName,number` via Bash. Look for `epic/*` branches that might overlap. If found, print them and ask the user if this is intentionally parallel work.
3. **Check active branches:** Run `git branch -r --list 'origin/epic/*'` via Bash. Active epic branches indicate in-flight work that hasn't been merged yet.
4. **Check existing specs:** Use `Grep` to search `docs/frs/active/` for specs that might already cover the described work.

If overlapping work is found, use `AskUserQuestion` to confirm: "Existing epic E### ({title}) overlaps. Create a new epic anyway, or add specs to the existing one?"

### 1c: Explore the Codebase

Based on the user's description, explore the codebase to understand the scope:

1. **Identify relevant modules:** Use `Glob` and `Grep` to find source files, tests, and existing specs related to the epic theme.
2. **Read key files:** Use `Read` to examine the most relevant 3-5 files to understand current architecture.

## Step 2: Design the Epic

### 2a: Define Scope

State what's in scope and what's explicitly out of scope for this epic. Reference actual modules and capabilities discovered during exploration.

### 2b: Identify Child Specs

Break the epic into 3-8 concrete child specs. Each should be:
- Independently deliverable
- Ordered by dependency (foundations first)
- Sized for 0.5d-2d of work each

For each child spec, draft a one-line title and a brief description of what it delivers.

### 2c: Confirm with User

Use `AskUserQuestion` to present:
- The epic scope (in/out)
- The proposed child spec breakdown
- Any key decisions

This is the gate — if the user disagrees, iterate here.

## Step 3: Create the Epic

Call `create_spec(title=<title>, priority=<priority>, is_epic=True, set_default=True)`.

- Derive the `title` from the user's description — concise and thematic (e.g., "Issue Tracking", "Agent Swarm Manager")
- Save the returned `spec_id` (E###), `fr_path`

## Step 4: Author the Epic FR

Read the created FR file. Replace its contents with a fully-authored epic FR using the `Edit` tool. The epic FR must include:

### Required Sections

1. **Executive Summary:** 2-3 sentences describing what this epic delivers and why it matters.

2. **Problem:** What capability gap or pain points does this epic address? Reference concrete codebase findings.

3. **Solution:**
   - **Core Concept:** High-level approach in one paragraph
   - **Key Components:** The major deliverables this epic produces
   - **User Experience:** How users will interact with the completed epic

4. **Acceptance Criteria:**
   - **Functional (AC-F1, AC-F2, ...):** Epic-level criteria — what must be true when all child specs are done
   - **Quality (AC-Q1, AC-Q2):** Always include `Tests pass (make test-quick)` and `No lint/type errors (make check)`

### Epic-Specific Guidelines

- Epic FRs are higher-level than spec FRs — focus on goals and scope, not implementation details
- The `deps:` line should be empty initially (child specs will be added as they're created)
- Do NOT include Technical Design or Test Specifications — those belong in child spec FRs

## Step 5: Create Child Specs (Optional)

Ask the user: "Create the child specs now, or just the epic?"

**If yes:** For each child spec identified in Step 2b:
1. Call `create_spec(title=<child_title>, priority=<priority>, epic_id=<epic_id>)` — skeleton only, do NOT author FR/IMPL content
2. Print the spec ID and title

**If no:** Print "Child specs can be added later with `/nspec`."

**Important:** Do NOT author FR/IMPL content for child specs. Do NOT activate or execute them. Creating specs is planning work — the user must explicitly invoke `/ngo` or `/nloop` to execute.

## Step 6: Validate and Report

1. Call `validate()` to ensure everything passes.
2. If validation fails, fix and re-validate.
3. Print a summary:

```
Created E### — {title}
Priority: P#
Child specs: N created (or "none yet")

Specs in this epic:
  S### — {child_title_1}
  S### — {child_title_2}
  ...

Next: /nloop E### to start working, or /nspec to add more specs
```

## Step 7: Offer Worktree Workflow

After printing the summary:

1. **Commit the new epic and child spec skeletons** so they exist at HEAD before branching:
   - Stage only the new spec files: `git add docs/frs/active/FR-E###-*.md docs/frs/active/FR-S*-*.md docs/impls/active/IMPL-S*-*.md docs/impls/active/IMPL-E###-*.md` (use the actual filenames from create_spec results)
   - `git commit -m "chore: create epic E### — {title} ({N} child specs)"`

2. Use `AskUserQuestion`: "Enter a worktree to start executing this epic?" (Yes / No)

**If No:** Print "Run `/nloop E###` when you're ready." and **EXIT**.

**If Yes — enter worktree and start loop:**

3. **Check working tree is clean** (`git status --porcelain`). If dirty, ask user to stash.

4. **Derive branch name:** Slugify the epic title — lowercase, strip `FR-E0XX:` prefix, replace spaces/special with hyphens, truncate to 40 chars. Branch: `epic/{epic_id_lowercase}-{slug}` (e.g., `epic/e010-issue-tracking`).

5. **Enter worktree:**
   - Call `EnterWorktree` (Claude Code built-in) to create the worktree and switch CWD.
   - Rename branch to match convention: `git branch -m {branch_name}` via Bash.

6. **Activate and loop:**
   - Call `activate(epic_id)` to set the nspec session.
   - Invoke `/nloop E###` — this runs autonomously. When `/nloop` detects it's in a worktree at exit, it pushes the branch and creates a PR automatically (see `/nloop` worktree exit behavior).

## Error Handling

- **No description provided and user cancels:** Print "No description provided." and EXIT.
- **Validation fails after authoring:** Fix the validation errors and retry.
- **Overlapping epic exists:** Warn the user and suggest merging or narrowing scope.

## Rules

- **Always explore first:** Never write the epic FR without reading relevant source code.
- **Don't over-decompose:** 3-8 child specs. If you need more, the epic is too broad — suggest splitting.
- **No auto-executing:** Creating specs is planning. Never activate or execute newly created specs.
- **Epic FR is the plan:** The epic FR defines scope and goals. Child spec FRs define implementation.
- **Set as default:** Always pass `set_default=True` when creating the epic so subsequent `/nspec` calls default to it.
