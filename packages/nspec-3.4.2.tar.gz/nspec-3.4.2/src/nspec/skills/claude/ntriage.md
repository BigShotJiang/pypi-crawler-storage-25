---
description: Pull issues from nspec-issues, triage or import as nspec specs
argument-hint: "[--auto] [--epic E006] [--label bug] [number]"
---

Fetch open GitHub issues from the configured issue repo (or `Novabuiltdevv/nspec-issues`), display them for triage, and optionally import selected issues as nspec specs.

## Argument Parsing

Parse `$ARGUMENTS` for flags and filters:

- `--auto` → batch import mode (skip interactive prompts, import all open non-imported issues)
- `--epic <id>` → target epic for imported specs (overrides config default)
- `--label <name>` → filter issues by label (e.g., `bug`, `enhancement`)
- A bare number (e.g., `7`) → jump directly to that issue for triage
- Empty → show all open issues

**If `--auto` is present, go to Auto Mode below. Otherwise, continue to Step 1.**

## Auto Mode (Batch Import)

When `--auto` is passed, skip all interactive prompts and batch-import issues:

1. Call `batch_import(epic_id=<epic>, label=<label>)` — the MCP tool handles fetching, dedup, error handling, and rate limit retries.
2. If `batch_import` returns `success: false`, print the error and **EXIT**.
3. Print a summary table:

```
## Batch Import Summary

Fetched: {total_fetched} issues
Skipped (already imported): {skipped_imported}
Imported: {imported_count}
Failed: {failure_count}

| Spec ID | Issue | Title | Priority |
|---------|-------|-------|----------|
| S302    | #25   | Fix X | P1       |
| ...     |       |       |          |
```

4. If there are failures, print a failure table:

```
### Failures

| Issue | Error | Action |
|-------|-------|--------|
| org/repo#26 | Validation failed | skipped |
```

5. **EXIT** — auto mode does not loop back to interactive triage.

## Step 1: Fetch Issues (Interactive Mode)

## Step 1: Fetch Issues

Run the following via Bash to fetch open issues:

```
gh issue list --repo Novabuiltdevv/nspec-issues --state open --limit 50 \
  --json number,title,labels,body,createdAt,author,comments \
  --jq 'sort_by(.number)'
```

If `$ARGUMENTS` contains a label filter, add `--label <label>`.

If `$ARGUMENTS` is a single issue number, skip to Step 3 with that issue.

## Step 2: Display Issue List

Present the issues in a numbered table:

```
## Open Issues — Novabuiltdevv/nspec-issues

| #   | Title                          | Labels        | Age   | Comments |
|-----|--------------------------------|---------------|-------|----------|
| 8   | TUI: Epic spec list not sorted | bug           | 1d    | 0        |
| 7   | get_epic fails: avail...       |               | 1d    | 2        |
| ...                                                                     |

N open issues
```

Format the `Age` column as relative time (e.g., `2h`, `1d`, `3w`).

Then use `AskUserQuestion` to ask:

> **Pick an issue to triage** (enter a number), or choose an action:

With these options:
- Each issue number as a selectable option (showing `#N — Title`)
- **"Import all as specs"** — batch-import every listed issue
- **"Done"** — exit the skill

## Step 3: Triage a Single Issue

Fetch the full issue detail:

```
gh issue view <number> --repo Novabuiltdevv/nspec-issues --json number,title,body,labels,author,createdAt,comments
```

Display:
- **Title** and **#number**
- **Author** and **Created**
- **Labels** (if any)
- **Body** (full text, rendered as markdown)
- **Comments** (if any — show author + body for each)

Then use `AskUserQuestion` to ask:

> **What do you want to do with #N?**

With these options:
- **"Import as nspec spec"** → Go to Step 4
- **"Label"** → Go to Step 5a
- **"Comment"** → Go to Step 5b
- **"Close"** → Go to Step 5c
- **"Close as duplicate"** → Go to Step 5d
- **"Skip"** → Return to Step 2 (issue list)

## Step 4: Import as nspec Spec

This converts a GitHub issue into a full nspec spec, similar to `/nspec` but pre-filled from the issue body.

### 4a: Determine Epic

1. Call `epics()` to list active epics.
2. Use `AskUserQuestion`: "Which epic for #N?" with epic options + "New epic".
3. If "New epic", ask for title and create it.

### 4b: Determine Priority

Map from issue labels if present:
- `critical` or label containing `p0` → P0
- `urgent` or label containing `p1` → P1
- `bug` → P1 (default for bugs)
- `enhancement` → P2
- `low` or label containing `p3` → P3

If no label maps, use `AskUserQuestion` with P1/P2/P3 options.

### 4c: Explore Codebase

Based on the issue title and body, explore the codebase the same way `/nspec` does:
1. Use `Glob` and `Grep` to find files related to keywords in the issue.
2. Read the 3-5 most relevant files.
3. Check existing specs in `docs/frs/active/` for overlap.
4. Build an internal context summary.

### 4d: Create the Spec

Call `create_spec(title=<issue_title>, priority=<priority>, epic_id=<epic_id>)`.

### 4e: Author FR and IMPL

Author the FR and IMPL using the issue body as the primary input, combined with codebase context from 4c. Follow the same authoring standards as `/nspec`:

**FR must include:**
- Executive Summary (derived from issue body)
- Problem (from the issue's problem description / bug report)
- Solution with Key Components and User Experience
- Technical Design referencing actual files found in 4c
- Acceptance Criteria (AC-F*, AC-Q*)
- Test Specifications (TC-P*, TC-N*)

**IMPL must include:**
- Executive Summary
- Design Decisions with alternatives
- Tasks with file references
- Files Modified table
- LOE estimate
- Definition of Done

Add a reference line at the bottom of the FR:

```
> Imported from [Novabuiltdevv/nspec-issues#N](https://github.com/Novabuiltdevv/nspec-issues/issues/N)
```

### 4f: Validate

Call `validate()`. Fix any errors and retry.

### 4g: Update the GitHub Issue

After successful spec creation:

```bash
gh issue comment <number> --repo Novabuiltdevv/nspec-issues \
  --body "Imported as nspec spec **S<ID>** (Priority: P<N>, Epic: E<ID>).

Spec files created — ready for execution via \`/ngo S<ID>\`."
```

Then label the issue:

```bash
gh issue edit <number> --repo Novabuiltdevv/nspec-issues --add-label "imported"
```

If the `imported` label doesn't exist yet, create it first:

```bash
gh label create imported --repo Novabuiltdevv/nspec-issues \
  --description "Issue imported as nspec spec" --color "0E8A16"
```

### 4h: Report

Print:

```
Imported #N → S<ID> ({title})
  Epic: E<ID> ({epic_title})
  Priority: P<N>
  Tasks: N tasks, LOE: Xd

  Ready to execute: /ngo S<ID>
```

Then return to Step 2 to continue triaging.

## Step 5: Quick Triage Actions

### 5a: Label

Use `AskUserQuestion` with label options:
- bug, enhancement, documentation, duplicate, question, wontfix, invalid
- "Custom" → ask for label name

Then:

```bash
gh issue edit <number> --repo Novabuiltdevv/nspec-issues --add-label "<label>"
```

Return to Step 3 (same issue — may want multiple actions).

### 5b: Comment

Use `AskUserQuestion` with a free-text prompt: "Enter your comment for #N:"

Then:

```bash
gh issue comment <number> --repo Novabuiltdevv/nspec-issues --body "<comment>"
```

Return to Step 3.

### 5c: Close

Use `AskUserQuestion` to confirm: "Close #N — {title}?" (Yes / No)

If yes:

```bash
gh issue close <number> --repo Novabuiltdevv/nspec-issues
```

Return to Step 2.

### 5d: Close as Duplicate

Use `AskUserQuestion`: "Which issue is this a duplicate of?" (free text for issue number)

Then:

```bash
gh issue comment <number> --repo Novabuiltdevv/nspec-issues \
  --body "Closing as duplicate of #<dup_number>."
gh issue close <number> --repo Novabuiltdevv/nspec-issues --reason "not planned"
gh issue edit <number> --repo Novabuiltdevv/nspec-issues --add-label "duplicate"
```

Return to Step 2.

## Batch Import ("Import all as specs")

If the user chose batch import in Step 2:

1. Use `AskUserQuestion` to pick the target epic (same as 4a).
2. Use `AskUserQuestion` to confirm: "Import N issues into E<ID>? This will create N specs." (Yes / No)
3. Call `batch_import(epic_id=<epic>)` — the MCP tool handles fetching, dedup, error handling, and rate limit retries.
4. Print the same summary table as Auto Mode above.

## Error Handling

- **`gh` not authenticated:** Print "Run `gh auth login` to authenticate with GitHub." and EXIT.
- **Repo not accessible:** Print "Cannot access Novabuiltdevv/nspec-issues. Check permissions." and EXIT.
- **Issue already has `imported` label:** Show a warning "(already imported)" next to the issue in the list. Still allow re-import if the user picks it.
- **No open issues:** Print "No open issues found." and EXIT.
- **Spec creation fails:** Print the error, skip that issue, continue with remaining.

## Rules

- **Always fetch fresh data:** Don't cache issue lists across triage rounds — re-fetch after any mutation.
- **Don't auto-close on import:** Importing creates a spec but the issue stays open. The user or CI closes it when the spec is completed.
- **Respect the issue body:** The issue author's description is the primary input. Add codebase context but don't contradict or ignore what they wrote.
- **One spec per issue:** Don't merge multiple issues into a single spec. If issues are related, note the relationship in the FR but create separate specs.
