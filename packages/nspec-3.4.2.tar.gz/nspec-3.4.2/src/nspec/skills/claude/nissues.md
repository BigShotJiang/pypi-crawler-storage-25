---
description: Browse open GitHub issues and import one as an nspec spec
---

# /nissues — Browse & Import GitHub Issues

## Flow

### 1. Resolve Repository

```
Call issue_list() with no arguments → uses [github].repo from config.toml
If error indicates no repo configured:
  AskUserQuestion: "Which GitHub repo? (owner/repo format)"
  Call issue_list(repo=<answer>)
```

### 2. Present Selector

```
Build AskUserQuestion options from the issue list (max 4):
  Each option:
    label = "#<number>: <title>"
    description = truncated body (first 80 chars) or labels
  Add final option: label = "Other", description = "Type an issue number manually"

AskUserQuestion: "Which issue to import?"

If user picks "Other":
  AskUserQuestion: "Enter the issue number:"
```

### 3. Import Selected Issue

```
Call issue_import(repo, number) with the selected issue number
Capture the result: spec_id, FR path, IMPL path
```

### 4. Determine Epic

```
Call epics() → list available epics
Call get_epic() → check active epic
If active epic exists:
  Suggest it as default
AskUserQuestion: "Which epic? (or press Enter for {active_epic})"
```

### 5. Summary

```
Print:
- Spec ID and title
- Epic assignment
- Priority (from issue labels)
- GitHub issue link
- Suggest: "Run /ngo {spec_id} to implement."
```
