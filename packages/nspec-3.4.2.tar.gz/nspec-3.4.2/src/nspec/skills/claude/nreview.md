---
description: Request a code review for a spec
argument-hint: <spec_id>
---

Request an automated code review for the given spec. Uses the configured review agent (Codex, Claude, or Gemini) from `[review]` config. Defaults to the configured agent.

## Argument Parsing

Parse `$ARGUMENTS` for the spec ID (e.g., `S020`, `S015`). If no spec ID is provided, call `get_epic` and `show` the active spec to determine which spec to review.

## Review Flow

### Step 1: Validate spec

1. Call `show` with the spec ID to get current status.
2. If the spec is not in Active or Testing status, print a warning: "Spec {id} is in {status} — reviewing anyway." Continue regardless.
3. Check if `**Verdict:** APPROVED` already exists — if so, print "Already approved" and **EXIT**.

### Step 2: Run review

1. Call `review_spec(spec_id, base_branch="main")` to generate a review prompt. The prompt is written to a file under `work/review-prompts/` and the response contains `prompt_file` (the path) instead of the full text. **Save the `review_token` from the response** — it is required for Step 4.
2. Call `execute_agent(prompt_file=<path>, review_token=<token>)` with the prompt file path and review token from step 1. This dispatches to the configured review agent (`[review].agent` in config.toml).

```
review_data = review_spec(spec_id, base_branch="main")
review_token = review_data["review_token"]
response = execute_agent(prompt_file=review_data["prompt_file"], review_token=review_token)
review_agent = response.get("agent", "codex")
```

The `execute_agent` tool reads `[review].agent` from config and dispatches accordingly:
- **codex** (default): Spawns codex CLI subprocess with model/effort from `[review.codex]`
- **claude**: Returns the prompt for inline processing (you evaluate and produce the verdict yourself)
- **gemini**: Passes prompt to the configured gemini executor

**If the review agent is "claude" (self-review mode):**
- The `execute_agent` response contains the review prompt as `output` (read from the prompt file)
- YOU must read the prompt, evaluate the code against the criteria, and produce a verdict
- Apply the same P-level finding rubric as Codex would (P0/P1 → NEEDS_WORK, P2/P3 only → APPROVED)
- Write your verdict using `write_review_verdict(reviewer="claude", ...)`

**Alternative modes:**
- `review_spec(spec_id, uncommitted=true)` — review staged/unstaged changes
- `review_spec(spec_id, commit_sha="abc123")` — review a specific commit

### Step 3: Parse the verdict

Read the `output` field from the execute_agent response. Two verdict formats are supported:

**P-level findings (codex-cli native format):**
- Any `[P0]` or `[P1]` findings → `NEEDS_WORK`
- Only `[P2]`/`[P3]` findings or no findings → `APPROVED`

**Explicit VERDICT line (legacy fallback):**
- `VERDICT: APPROVED` — Reviewer approves the implementation
- `VERDICT: NEEDS_WORK` — Reviewer found issues, feedback follows

If no verdict can be parsed, the review is inconclusive. Print the raw output for debugging and **EXIT**.

### Step 4: Write verdict to IMPL

Call the nspec MCP tools to update the IMPL:

1. If not already in review status:
   - Call `advance(spec_id)` to move to Testing if needed
2. Call `write_review_verdict` with the parsed verdict, feedback, and the `review_token` from Step 2:
   - `verdict`: "APPROVED" or "NEEDS_WORK"
   - `feedback`: Finding text from the review
   - `reviewer`: the `review_agent` value from the response (e.g., "codex", "claude", "gemini")
   - `implementer`: "claude"
   - `review_token`: the token from `review_spec()` response

Print the result:
- **APPROVED:** "Spec {id} APPROVED by {reviewer}. Ready to complete."
- **NEEDS_WORK:** "Spec {id} NEEDS_WORK. Feedback:\n{feedback}"

### Step 5: Handle NEEDS_WORK

If the verdict is NEEDS_WORK and you're in an active work session:
1. Read the feedback from the response.
2. Make the requested changes.
3. Re-run Steps 2-4 (generate new review prompt via `review_spec()`, call `execute_agent()` again).
4. Max 2 retries. If still NEEDS_WORK after 2 retries, call `park(spec_id, reason="Failed review after 2 retries")`.

## Error Handling

- **codex CLI not found (codex agent only):** Print: "codex CLI not installed. Install with: npm install -g @openai/codex" and **EXIT**.
- **Timeout:** If the review takes >2 minutes, print: "Review timed out." and **EXIT**.
- **No verdict:** If the response doesn't contain parseable findings or VERDICT line, print the raw output for debugging. **EXIT**.
- **Empty response:** If the reviewer returns empty, print: "Reviewer produced no output." and **EXIT**.

## Example Session

```
User: /nreview S010

Claude: Let me review spec S010...

[Calls execute_agent(prompt_file=review_data["prompt_file"])]

Review response (review_agent: codex):
---
## Code Review: S010

[P2] Consider adding docstring to helper function
[P3] Minor style: prefer f-string over .format()

No critical issues found.
---

[Parses P-level findings: no P0/P1 → APPROVED]
[Updates IMPL-S010 with verdict]

Spec S010 APPROVED by codex. Ready to complete.
```

## Notes

- `execute_agent()` dispatches to the configured review agent from `[review].agent` in config
- Reviews use `review_spec()` to generate and persist the prompt to `work/review-prompts/`, then `execute_agent(prompt_file=...)` to run it
- Configurable via `[review]` section in config.toml (agent, timeout, per-agent model/effort)
- Per-agent settings: `[review.codex]`, `[review.claude]`, `[review.gemini]`
