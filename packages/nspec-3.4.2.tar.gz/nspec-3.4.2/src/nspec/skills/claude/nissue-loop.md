---
description: Autonomous issue processing loop — fetch, import, execute, close, repeat
argument-hint: "[--epic E006] [--max <n>] [--dry-run]"
---

Autonomous loop that processes the GitHub issue queue end-to-end: fetch open issues, batch-import as specs, execute each via `/ngo`, and loop until the issue queue is drained or limits reached.

**CRITICAL: This is an AUTONOMOUS LOOP. After completing or failing a spec, you MUST immediately loop back to Phase 1. NEVER ask the user "should I continue?" — the answer is always yes. The ONLY reasons to stop are: (1) no open issues remain, (2) `--max` limit reached, (3) max consecutive failures reached, or (4) the user explicitly interrupts.**

**All state is managed through nspec MCP tools — zero direct file I/O.**

**Context isolation:** Every spec runs in a fresh Agent context. The orchestrator NEVER executes `/ngo` inline — it always spawns a worker Agent. This prevents context exhaustion on multi-issue runs.

## Argument Parsing

Parse `$ARGUMENTS` for:
- `--epic <id>` or bare `e###` → override target epic for imported specs (default: from `[github].default_epic` config, typically E006)
- `--max <n>` → stop after N issues processed (default: unlimited)
- `--dry-run` → show what would be processed without executing
- `--label <name>` → filter issues by label (e.g., `bug`, `enhancement`)

Initialize counters: `processed = 0`, `completed = 0`, `blocked_list = []`, `consecutive_failures = 0`, `max_consecutive_failures = 3`.

## Loop Protocol

### Phase 1: Fetch Issues

1. Call `issue_list(state="open", label=<label_filter>)` to get open issues from the configured repo.
2. If no open issues → print exit summary, **EXIT** (queue drained).

### Phase 2: Dry-Run Check

If `--dry-run` is active:
- Print a summary table of issues that would be processed (no side effects — no imports, no spec creation):

```
## Dry Run — Issue Processing Plan

| Issue | Title | Mapped Priority | Action |
|-------|-------|-----------------|--------|
| #8    | TUI sort bug | P1 | Would import + execute |
| #12   | Config docs  | P2 | Would import + execute |
| #15   | Auth error   | P1 | Already imported (S302) — would execute |

Would process {N} issues. Run without --dry-run to execute.
```

- **EXIT**.

### Phase 3: Import Issues

1. Call `batch_import(epic_id=<epic>, label=<label_filter>)` to import all unprocessed issues as specs.
   - `batch_import` handles: dedup (skips `imported` label), rate limit retries (exponential backoff, max 3), error logging per E010 contract.
   - The `label` parameter is passed through so only label-matching issues are imported when `--label` is specified.
2. If `batch_import` returns failures, log them but continue — individual import failures do not halt the loop.
3. If zero issues were imported AND zero already-imported specs remain unexecuted → print exit summary, **EXIT**.
4. Store the list of newly imported spec IDs and any previously imported but unexecuted specs.

### Phase 4: Pick Next Spec

1. Call `next_spec(epic_id=<epic>)` to get the highest-priority unblocked spec in the target epic.
2. If no unblocked spec → print progress report, **EXIT** (all specs blocked or completed).
3. The picked spec should be one of the imported issue specs. If `next_spec` returns a non-issue spec (no `github_ref`), that's fine — execute it anyway since it's in the target epic.

### Phase 5: Execute via Worker Agent

**Spawn a fresh worker Agent** via the `Agent` tool for the picked spec:

**Worker Agent prompt:**

```
Execute spec {spec_id} in epic {epic_id} using /ngo. Run the full lifecycle:
resolve, start, execute, verify, review, complete.

Return ONLY the final status line in this format:
STATUS: completed | parked | exception
REASON: <one-line summary if not completed>

Do not ask for confirmation. Act autonomously.
```

**Read the worker result** and handle:

- **`STATUS: completed`**:
  - Increment `processed` and `completed`.
  - Reset `consecutive_failures = 0`.
  - Issue closure is handled automatically by S273 lifecycle hooks when `complete()` is called — no action needed here.
  - Continue to Phase 6.

- **`STATUS: parked`** or **`STATUS: exception`**:
  - Increment `processed`.
  - Increment `consecutive_failures`.
  - Append `{spec_id}: {reason}` to `blocked_list`.
  - Log per E010: `{operation: "ngo", issue_ref: <github_ref>, error: <reason>, action_taken: "skipped"}`.
  - If `consecutive_failures >= max_consecutive_failures`:
    - Print: "Max consecutive failures ({max_consecutive_failures}) reached — stopping loop."
    - **GOTO Exit Summary.**
  - Otherwise → **GOTO Phase 4** (pick next spec).

- **Worker timeout or no parseable status**:
  - Same handling as parked/exception above.

### Phase 6: Progress Report

Print after each spec completion:
- Issues processed this run: `{processed}`
- Issues completed this run: `{completed}`
- Issues blocked this run: `{blocked_list}`
- Consecutive failures: `{consecutive_failures}`

If `--max` was set and `processed >= max`:
- Print full exit summary.
- **EXIT**.

### GOTO Phase 1 (MANDATORY — DO NOT STOP HERE)

**You MUST loop back to Phase 1 now.** Re-fetch the issue list (issues may have been closed by S273 hooks during execution). Continue until no open issues remain or `--max` is reached.

## Exit Summary

On any exit, print:

```
## Issue Loop Summary

Issues processed: {processed}
Issues completed: {completed}
Issues blocked: {len(blocked_list)}

### Blocked Issues
| Spec | Issue | Reason |
|------|-------|--------|
| S302 | #8   | Review failed after 2 retries |
| ...  |       |        |

### Failures
{any import failures from batch_import}
```

## Failure Handling

| Failure Mode | Action | Loop Continues? |
|--------------|--------|-----------------|
| `issue_list` returns error | Print error, EXIT | No |
| `batch_import` partial failure | Log failures, continue with successful imports | Yes |
| Single issue import failure | Skip issue, log warning | Yes |
| `/ngo` parks spec | Log, increment consecutive failures | Yes (unless max reached) |
| `/ngo` exceptions spec | Log, increment consecutive failures | Yes (unless max reached) |
| Worker timeout | Log, increment consecutive failures | Yes (unless max reached) |
| Rate limit (HTTP 403/429) | `batch_import` handles backoff internally | Yes |
| Max consecutive failures | Print summary, EXIT | No |

## Required MCP Tools

| Tool | Phase |
|------|-------|
| `issue_list` | Phase 1 — fetch open issues |
| `batch_import` | Phase 3 — import unprocessed issues |
| `next_spec` | Phase 4 — pick highest-priority imported spec |
| `get_epic` | Phase 4 — resolve epic scope |
| `show` | Phase 2 — display spec details (dry-run) |

All execution-phase tools (`activate`, `session_start`, `task_complete`, `criteria_complete`, `review_spec`, `advance`, `complete`, etc.) are used by `/ngo` inside the worker Agent — not directly by this orchestrator.

## Rules

- **Never ask** "should I continue?" or "what do you want to do next?"
- **Always act**: fetch → import → execute → close → repeat
- **Re-fetch each iteration**: Issue state changes between iterations (S273 closes issues on spec completion). Always re-fetch to get current state.
- **Respect dedup**: `batch_import` handles the `imported` label. Trust its dedup logic.
- **One spec per issue**: Each issue maps to exactly one spec. Don't merge issues.
- **Epic scope**: All imported specs go to the configured epic (default E006). Don't scatter across epics.
