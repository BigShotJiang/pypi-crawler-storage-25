---
description: Batch review all specs in an epic with cross-spec consistency checking
argument-hint: <epic_id> [--context E001,E002]
---

Batch-review all FR specs in an epic in a single consolidated review prompt. Unlike `/nreview` which reviews one spec at a time, this skill feeds all child spec FRs into one review call for cross-spec consistency checking.

## Argument Parsing

Parse `$ARGUMENTS` for:
- An epic ID (e.g., `E001`, `e003`, or bare `001`) — required
- An optional `--context E001,E002` flag — comma-separated list of dependency epic IDs to include as context

If no epic ID is provided, call `get_epic` to get the active epic. If no active epic, print "No epic specified and no active epic set." and **EXIT**.

## Step 1: Gather Specs

1. Call `show(epic_id)` to get the epic FR content (title, priority, status, deps, acceptance criteria). If the epic is not found (error response), print "Epic {epic_id} not found." and **EXIT**.
2. Store the epic title and FR content for use in the consolidated prompt.
3. Call `epic_specs(epic_id)` to get all child specs in the target epic.
4. If no child specs found, print "Epic {epic_id} has no child specs to review." and **EXIT**.
5. For each child spec, call `show(spec_id)` to get the full FR content (title, priority, status, deps, acceptance criteria).

## Step 2: Gather Context

### Auto-detect context epics (if `--context` not provided)

1. Read the epic FR file to find its `deps:` line.
2. Parse dependency IDs from the deps line (e.g., `deps: [E001, E002]`).
3. If no deps found, proceed without context. Print "No dependency epics found — reviewing without upstream context."

### Load context epics (if `--context` provided or auto-detected)

For each context epic ID:
1. Call `epic_specs(context_epic_id, status_filter="completed")` to get completed specs.
2. If no completed specs, print "Context epic {id} has no completed specs — skipping." and continue.
3. For each completed spec, call `show(spec_id)` to get the FR content.

## Step 3: Build Consolidated Prompt

Assemble a single review prompt containing all gathered data. Use this template:

```
You are reviewing all FR specs in epic {epic_id}: {epic_title}

Your task is to evaluate the FR authoring quality and cross-spec consistency of these specs as a group. This is NOT a code review — focus on the spec documents themselves.

## Epic FR

{epic_fr_content}

## Child Specs to Review

{for each child spec:}
### {spec_id}: {title}
**Priority:** {priority}
**Status:** {status}
**Dependencies:** {deps}

#### Acceptance Criteria
{acceptance_criteria}

{end for}

## Context: Completed Dependency Specs

{for each context spec:}
### {spec_id}: {title} (Completed)
{fr_summary}
{end for}

## Review Criteria

Evaluate each spec against these criteria:

### 1. Completeness
- Do the child spec ACs collectively cover the epic's scope?
- Are there gaps where epic-level requirements are not addressed by any child spec?

### 2. Cross-Spec Consistency
- Do type names, method signatures, error variants, and API contracts agree across all specs?
- Are there contradictions between specs (e.g., one spec assumes X while another assumes Y)?
- Do dependency declarations match actual inter-spec relationships?

### 3. Precision
- Do references to dependency epic code/contracts match what was actually built?
- Are ACs concrete and testable, not vague?

### 4. Cross-Cutting Concerns (critical for convergence)
- Error taxonomy: do specs agree on error types and handling?
- Event schemas: are shared data structures consistent?
- Serialization contracts: do specs that share data agree on formats?
- Semantic ambiguity: do specs use the same term for the same concept?
- **Group findings that span 2+ specs into named themes** — these require atomic multi-file fixes and cannot be resolved one spec at a time

### 5. Gaps
- Missing test cases for edge conditions
- Implicit assumptions not stated in any spec
- Dependency graph holes (spec A needs spec B but doesn't declare it)

## Response Format

For EACH child spec, provide a verdict and findings:

### {spec_id}: {title}
**VERDICT:** APPROVED | NEEDS_WORK

**Findings:**
- [P0] Blocker: {description}
- [P1] Major: {description}
- [P2] Minor: {description}
- [P3] Nit: {description}

Then identify cross-cutting themes — findings that span multiple specs:

### Cross-Cutting Themes

For each theme that appears in 2+ specs, group the findings:

**Theme: {theme_name}** (affects: S001, S002, S003)
- What: {description of the inconsistency or gap}
- Fix scope: {which files need coordinated changes}

Then provide an overall summary:

### Overall
**Epic Coverage:** {percentage or qualitative assessment}
**Cross-Spec Issues:** {count and summary}
**Cross-Cutting Themes:** {count — these require atomic multi-file fixes}
**Recommendation:** {brief guidance}
```

## Step 4: Execute Review

1. Call `execute_agent(prompt=<assembled_prompt>)` to send the prompt to the configured review agent.
2. If the review agent is "claude" (self-review mode):
   - The `execute_agent` response contains the prompt as `output`
   - YOU must evaluate the specs against the criteria and produce per-spec verdicts
   - Apply the same P-level rubric: P0/P1 = NEEDS_WORK, P2/P3 only = APPROVED

## Step 5: Parse and Report

Parse the review output for per-spec verdicts and findings.

1. For each `### S###:` section in the output:
   - Extract the VERDICT line (APPROVED or NEEDS_WORK)
   - Count P-level findings by severity
   - Store in a results list

2. Print a summary table:

```
## Epic Review: {epic_id} — {epic_title}

| Spec  | Title                         | Verdict    | P0 | P1 | P2 | P3 |
|-------|-------------------------------|------------|----|----|----|-----|
| S263  | Project discovery engine      | APPROVED   | 0  | 0  | 1  | 0   |
| S264  | TUI project walker            | NEEDS_WORK | 0  | 2  | 0  | 1   |
| S265  | MCP discover_projects tool    | APPROVED   | 0  | 0  | 0  | 0   |

Overall: {approved_count} APPROVED, {needs_work_count} NEEDS_WORK
Findings: P0={p0_total} | P1={p1_total} | P2={p2_total} | P3={p3_total}
```

3. If there is an "Overall" section in the review output, print it after the table.

4. If the review output contains a "Cross-Cutting Themes" section, print it as an actionable fix guide:

```
### Cross-Cutting Themes (require atomic multi-file fixes)

1. **{theme_name}** — affects {spec_list}
   {description}
2. **{theme_name}** — affects {spec_list}
   {description}

Tip: Use parallel agents (one per theme) to fix these atomically.
Run `/nreview-epic {epic_id}` again to verify convergence.
```

## Step 6: Convergence Protocol (Optional — for iterative fix-review)

When NEEDS_WORK specs remain after the first pass, use this protocol to converge. **This step is only executed if the user explicitly requests iteration** (e.g., `/nreview-epic E001 --converge`).

### Why stateless reviewers oscillate

Stateless reviewers (codex, gemini) have no memory between iterations. Each pass re-reads all specs from scratch. This causes oscillation:
1. Fix spec A to match spec B's contract
2. Reviewer re-reads everything, now has "room" to notice spec C doesn't match A's update
3. New P1 on C, even though C was previously APPROVED

Sequential fix-then-review cycles get stuck at the same approval count (e.g., 2/8 for 3+ iterations).

### Oscillation detection

Track P1 findings across iterations. If the same **themes** (not exact findings) recur for 2+ consecutive iterations, oscillation is detected. Themes are identified from the "Cross-Cutting Themes" section of the review output.

### Breaking the cycle with parallel theme agents

When oscillation is detected, switch from sequential fixes to parallel theme fixes:

1. **Group remaining P1s by cross-cutting theme** from the review output (e.g., "null-vs-removal ambiguity", "sequence number semantics", "constraint enforcement gaps")
2. **Launch N parallel agents** (one per theme) using the `Agent` tool:
   - Each agent receives ALL affected spec files for its theme
   - Each agent edits 2-5 files simultaneously to resolve its theme atomically
   - Agents do NOT run reviews — only fix
3. **Re-run `/nreview-epic`** after all parallel agents complete
4. Remaining findings are typically single-spec wording issues resolvable in 1-2 more sequential passes

### Convergence loop

```
iteration = 0
prev_themes = []

while NEEDS_WORK specs remain and iteration < 6:
    run /nreview-epic (Steps 1-5)
    current_themes = extract cross-cutting themes from output

    if current_themes overlap with prev_themes:
        # Oscillation detected — parallel fix
        for each theme in current_themes:
            launch Agent(prompt="Fix {theme} across {affected_files}")
        # All agents run in parallel (single message, multiple Agent calls)
    else:
        # New issues — sequential fix is fine
        fix P1s one spec at a time

    prev_themes = current_themes
    iteration += 1
```

### Cost model

Empirically (8-spec epic, codex reviewer):
- Sequential iterations: ~100K codex tokens per review pass, diminishing returns after iteration 3-4
- Parallel theme fix: ~25K sonnet tokens per agent, 2-5 agents typical
- Total convergence: ~580K review + ~125K fix tokens, ~25 minutes wall-clock
- The parallel fix pass (iter 5) moved from 2/8 → 6/8 APPROVED — more effective than 3 sequential cycles combined

## Important: Read-Only Review

This skill does NOT:
- Write verdicts to IMPL files (use `/nreview` for that)
- Call `write_review_verdict`
- Call `advance` or change spec status
- Generate review tokens

The core review (Steps 1-5) is purely diagnostic — a read-only FR quality assessment. Step 6 (convergence) makes edits to spec files but only when explicitly requested.

## Error Handling

- **No epic ID and no active epic:** Print error and EXIT.
- **Invalid epic ID (not found):** Print "Epic {epic_id} not found." and EXIT.
- **Epic has no child specs:** Print message and EXIT.
- **Context epic not found:** Warn but continue with available context.
- **Review agent timeout:** Print "Review timed out after {timeout}s." and EXIT.
- **Empty response:** Print "Reviewer produced no output." and EXIT.
- **Unparseable output:** Print the raw output for manual inspection.

## Example Session

```
User: /nreview-epic E001

Claude: Reviewing epic E001 — nspec Platform (4 child specs)...
  Context: no dependency epics detected

[Gathers S263, S264, S265, S266 FRs]
[Builds consolidated prompt]
[Calls execute_agent(prompt=...)]

## Epic Review: E001 — nspec Platform

| Spec  | Title                         | Verdict    | P0 | P1 | P2 | P3 |
|-------|-------------------------------|------------|----|----|----|-----|
| S263  | Project discovery engine      | APPROVED   | 0  | 0  | 1  | 0   |
| S264  | TUI project walker            | APPROVED   | 0  | 0  | 0  | 1   |
| S265  | MCP discover_projects tool    | APPROVED   | 0  | 0  | 0  | 0   |
| S266  | Epic batch review skill       | APPROVED   | 0  | 0  | 1  | 0   |

Overall: 4 APPROVED, 0 NEEDS_WORK
Findings: P0=0 | P1=0 | P2=2 | P3=1
```

## Notes

- `execute_agent()` dispatches to the configured review agent from `[review].agent` in config
- Configurable via `[review]` section in config.toml (agent, timeout, per-agent model/effort)
- This is a read-only diagnostic tool — it does not modify any spec files
- For implementation code reviews, use `/nreview` instead
