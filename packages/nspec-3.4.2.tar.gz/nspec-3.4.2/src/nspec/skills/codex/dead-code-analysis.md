---
description: Codex structural analysis prompt for per-module dead code detection
target: codex
---

# Codex Dead Code Analysis Prompt Template

This skill defines the prompt template used when Codex performs dead code analysis on a module area via `execute_agent`.

## Prompt Structure

The analysis prompt is assembled from four data sources:

1. **Module Area** — the logical area being analyzed (e.g., "tui", "validator", "mcp_server")
2. **Entry Points** — the known entry points that define reachability (e.g., `cli.py:main`, `mcp_server.py:serve`)
3. **File List** — all source files in the module area
4. **File Contents** — the full source code of each file in the module area

## Template

```
You are performing dead code analysis on the "{module_area}" module area.

## Entry Points

These are the known entry points — any symbol reachable from these is considered live:

{entry_points}

## Files Under Analysis

{file_list}

## Source Code

{file_contents}

## Your Task

Trace the call graph starting from the entry points listed above. For every exported symbol (function, class, constant, or module-level variable) in the files under analysis, classify it as one of:

- **REACHABLE** — called or referenced (directly or transitively) from at least one entry point
- **TEST_ONLY** — only referenced from test files (files matching `test_*.py` or `*_test.py`), not from any entry point
- **ORPHANED** — no references from entry points or test files; completely unused

### Rules

1. Follow imports transitively — if `A` calls `B` which calls `C`, all three are REACHABLE
2. Dunder methods (`__init__`, `__str__`, etc.) used by the Python runtime are REACHABLE if the class itself is REACHABLE
3. Decorated functions (e.g., `@app.command`, `@mcp.tool`) count as entry points if the decorator registers them
4. Re-exports via `__all__` count as exported symbols
5. Private symbols (prefixed with `_`) should still be classified — they may be ORPHANED even if "private"
6. Only classify symbols defined in the files under analysis, not symbols imported from third-party packages
7. When uncertain, classify as REACHABLE — false positives are worse than false negatives

### Output Format

Respond with exactly this structure:

SUMMARY: [1-2 sentences describing the overall health of the module area]

FINDINGS_START
STATUS | module.symbol_name | reason
STATUS | module.symbol_name | reason
...
FINDINGS_END

Where:
- STATUS is one of: REACHABLE, TEST_ONLY, ORPHANED
- module.symbol_name uses dotted notation (e.g., `cli.main`, `validator.ValidationEngine.run`)
- reason is a brief explanation (e.g., "called from cli.main → datasets.load_all", "only in test_validator.py", "no references found")

Sort findings by status: ORPHANED first, then TEST_ONLY, then REACHABLE.
Only include REACHABLE symbols if the total symbol count is under 50; otherwise omit REACHABLE entries to keep output focused.

Be thorough and precise. Every exported symbol must appear exactly once.
```

## Expected Output

Codex must respond with:

1. `SUMMARY:` line — 1-2 sentence assessment of module health
2. Findings between `FINDINGS_START` and `FINDINGS_END` delimiters, one line per symbol in the format: `STATUS | module.symbol_name | reason`

Example output:

```
SUMMARY: The tui module area is mostly clean; 2 orphaned helper functions and 1 test-only utility found.

FINDINGS_START
ORPHANED | widgets.format_priority_badge | no references found in any source or test file
ORPHANED | detail_screen._build_legacy_header | was replaced by _build_header in commit abc123, no callers remain
TEST_ONLY | state.mock_state_factory | only referenced from tests/test_tui_state.py
REACHABLE | app.NspecApp | entry point via cli.main → app.NspecApp.run
FINDINGS_END
```

## Invocation

This template is assembled by the caller and invoked via `execute_agent`:

```
execute_agent(prompt="{assembled_prompt}")  # spawns codex CLI subprocess
```

To assemble the prompt, substitute the four placeholders:

- `{module_area}` — e.g., `"tui"`, `"validator"`, `"mcp_server"`
- `{entry_points}` — newline-separated list of entry points (e.g., `cli.py:main\nmcp_server.py:serve`)
- `{file_list}` — newline-separated list of file paths being analyzed
- `{file_contents}` — concatenated file contents, each prefixed with `--- path/to/file.py ---`

The `FINDINGS_START`/`FINDINGS_END` delimiters allow programmatic extraction of results from the agent response.
