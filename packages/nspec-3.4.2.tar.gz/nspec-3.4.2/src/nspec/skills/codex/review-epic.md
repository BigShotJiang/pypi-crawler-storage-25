---
description: Codex review prompt template for epic-level batch FR review
target: codex
---

# Codex Epic Review Prompt Template

This skill defines the prompt template used when the review agent evaluates all FR specs in an epic for cross-spec consistency. Unlike the single-spec `review.md` template, this reviews FR authoring quality across multiple specs simultaneously.

## Prompt Structure

The review prompt is assembled from these data sources:

1. **Epic FR** — the epic-level feature request with its acceptance criteria
2. **Child Spec FRs** — all FR documents for specs in the epic (title, priority, deps, ACs)
3. **Context Specs** — completed FRs from dependency epics (optional, for upstream validation)

## Template

```
You are reviewing all FR specs in epic {epic_id}: {epic_title}

Your task is to evaluate the FR authoring quality and cross-spec consistency of these specs as a group. This is NOT a code review — focus on the spec documents themselves.

## Epic FR

{epic_fr_content}

## Child Specs to Review

{for each child spec:}
### {spec_id}: {title}
**Priority:** {priority}
**Status:** {status}
**Dependencies:** {deps}

#### Acceptance Criteria
{acceptance_criteria}

{end for}

## Context: Completed Dependency Specs

{for each context spec:}
### {spec_id}: {title} (Completed)
{fr_summary}
{end for}

## Review Criteria

Evaluate each spec against these criteria:

### 1. Completeness
- Do the child spec ACs collectively cover the epic's scope?
- Are there gaps where epic-level requirements are not addressed by any child spec?

### 2. Cross-Spec Consistency
- Do type names, method signatures, error variants, and API contracts agree across all specs?
- Are there contradictions between specs?
- Do dependency declarations match actual inter-spec relationships?

### 3. Precision
- Do references to dependency epic code/contracts match what was actually built?
- Are ACs concrete and testable, not vague?

### 4. Cross-Cutting Concerns (critical for convergence)
- Error taxonomy: do specs agree on error types and handling?
- Event schemas: are shared data structures consistent?
- Serialization contracts: do specs that share data agree on formats?
- Semantic ambiguity: do specs use the same term for the same concept?
- **Group findings that span 2+ specs into named themes** — these require atomic multi-file fixes

### 5. Gaps
- Missing test cases for edge conditions
- Implicit assumptions not stated in any spec
- Dependency graph holes (spec A needs spec B but doesn't declare it)

## Response Format

For EACH child spec, provide a verdict and findings:

### {spec_id}: {title}
**VERDICT:** APPROVED | NEEDS_WORK

**Findings:**
- [P0] Blocker: {description}
- [P1] Major: {description}
- [P2] Minor: {description}
- [P3] Nit: {description}

Then identify cross-cutting themes — findings that span multiple specs:

### Cross-Cutting Themes

For each theme that appears in 2+ specs, group the findings:

**Theme: {theme_name}** (affects: S001, S002, S003)
- What: {description of the inconsistency or gap}
- Fix scope: {which files need coordinated changes}

Then provide an overall summary:

### Overall
**Epic Coverage:** {percentage or qualitative assessment}
**Cross-Spec Issues:** {count and summary}
**Cross-Cutting Themes:** {count — these require atomic multi-file fixes}
**Recommendation:** {brief guidance}
```

## Expected Output

The review agent must respond with per-spec sections containing:

- `**VERDICT:** APPROVED` or `**VERDICT:** NEEDS_WORK`
- P-level findings: `[P0]`, `[P1]`, `[P2]`, `[P3]`
- An overall summary section

P-level severity mapping:
- `[P0]` Blocker — breaks functionality or introduces contradiction
- `[P1]` Major — incorrect behavior, missing edge case, spec gap
- `[P2]` Minor — style, naming, minor improvement
- `[P3]` Nit — optional polish

Any `[P0]` or `[P1]` finding for a spec → that spec's verdict is NEEDS_WORK.

## Invocation

This template is assembled by the `/nreview-epic` Claude skill, which:

1. Calls `epic_specs(epic_id)` to gather child specs
2. Calls `show(spec_id)` for each child spec's FR content
3. Optionally gathers context from dependency epics
4. Assembles the prompt using this template
5. Calls `execute_agent(prompt="{assembled_prompt}")` to dispatch to the configured review agent
