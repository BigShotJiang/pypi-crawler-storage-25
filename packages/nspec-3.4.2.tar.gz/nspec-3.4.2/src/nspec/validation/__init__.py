"""Validation subsystem for nspec.

Submodules:
    validators — Format validation (Layer 1): FR/IMPL metadata parsing
    checkers   — Cross-document validation (Layers 3-6): semantic checks
    validator  — Orchestrator: NspecValidator pipeline

Import directly from submodules to avoid circular imports:
    from nspec.validation.validators import FRValidator
    from nspec.validation.checkers import ValidationError
    from nspec.validation.validator import NspecValidator
"""
