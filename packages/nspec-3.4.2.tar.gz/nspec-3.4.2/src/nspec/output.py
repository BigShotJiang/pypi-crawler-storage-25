"""Shared output sanitization for agent terminal output.

Provides ``clean_terminal_output()`` — the single place all agent output
passes through before being returned to callers. Handles ANSI escapes,
OSC sequences, MCP discovery error blocks, CLI banners, and tmux
``Pane is dead`` trailers.
"""

from __future__ import annotations

import re

# Pre-compiled patterns for performance
_ANSI_ESCAPE = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")
_OSC_ESCAPE = re.compile(r"\x1b\].*?\x07", re.DOTALL)
_MCP_ERROR_BLOCK = re.compile(
    r"^\[MCP error\].*?(?:\n\n|\n(?=[^\s])|\Z)",
    re.MULTILINE | re.DOTALL,
)
_PANE_DEAD = re.compile(r"\n?Pane is dead\s*$")

# CLI banner patterns — multi-line blocks emitted by agent CLIs on startup
_CLI_BANNERS: list[re.Pattern[str]] = [
    # OpenAI Codex: version line + dashed separator + key=value lines
    # Keys are lowercase identifiers (workdir, model, provider, etc.)
    re.compile(
        r"^OpenAI Codex v[\d.]+.*\n-+\n(?:[a-z_]+:.*\n)*",
        re.MULTILINE,
    ),
    # Gemini CLI: version/banner line
    re.compile(r"^Gemini CLI v[\d.]+.*$\n?", re.MULTILINE),
    # Claude Code: version/banner line
    re.compile(r"^Claude Code v[\d.]+.*$\n?", re.MULTILINE),
    # Generic "Starting..." / "Loading..." lines from MCP server init
    re.compile(r"^mcp: \S+ starting\s*$\n?", re.MULTILINE),
]


def strip_cli_banners(text: str) -> str:
    """Remove known CLI startup banners from output.

    Strips banners emitted by Codex, Gemini CLI, Claude Code, and
    MCP server startup lines.
    """
    for pattern in _CLI_BANNERS:
        text = pattern.sub("", text)
    return text


def clean_terminal_output(text: str) -> str:
    """Remove terminal control sequences and artifacts from output.

    Handles:
    - ANSI escape codes (``\\x1b[...``)
    - OSC escape sequences (``\\x1b]...\\x07``)
    - MCP discovery error blocks (``[MCP error]`` through next blank line)
    - CLI startup banners (Codex, Gemini, Claude Code)
    - ``Pane is dead`` trailer from tmux remain-on-exit
    - Windows-style line endings
    - Leading/trailing blank lines
    """
    # Remove OSC escape sequences first (they may contain ANSI-like content)
    text = _OSC_ESCAPE.sub("", text)

    # Remove ANSI escape codes
    text = _ANSI_ESCAPE.sub("", text)

    # Remove MCP error blocks
    text = _MCP_ERROR_BLOCK.sub("", text)

    # Strip CLI banners
    text = strip_cli_banners(text)

    # Remove "Pane is dead" trailer
    text = _PANE_DEAD.sub("", text)

    # Normalize line endings
    text = text.replace("\r\n", "\n")
    text = text.replace("\r", "")

    # Strip trailing whitespace per line, remove leading/trailing blank lines
    lines = [line.rstrip() for line in text.split("\n")]
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()

    return "\n".join(lines)
