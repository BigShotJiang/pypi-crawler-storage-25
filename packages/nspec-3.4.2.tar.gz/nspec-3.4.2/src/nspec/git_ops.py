"""Git operations for epic conflict detection.

Checks for conflicting branches, open PRs, and overlapping epic titles
before creating new epics. All checks are graceful — failures produce
``check_unavailable`` warnings rather than errors.
"""

from __future__ import annotations

import difflib
import json
import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("nspec.git_ops")

# Default similarity threshold for fuzzy title matching
_DEFAULT_SIMILARITY_THRESHOLD = 0.6


@dataclass
class ConflictReport:
    """Result of epic conflict checks.

    Each field is a list of warning dicts matching the warnings contract
    defined in FR-S329.
    """

    branches: list[dict[str, str]] = field(default_factory=list)
    prs: list[dict[str, str | int]] = field(default_factory=list)
    overlapping_epics: list[dict[str, str | float]] = field(default_factory=list)
    unavailable: list[dict[str, str]] = field(default_factory=list)

    @property
    def warnings(self) -> list[dict[str, str | int | float]]:
        """Flatten all warnings into a single list."""
        result: list[dict[str, str | int | float]] = []
        result.extend(self.branches)
        result.extend(self.prs)
        result.extend(self.overlapping_epics)
        result.extend(self.unavailable)
        return result

    @property
    def has_conflicts(self) -> bool:
        """True if any conflicts (not just unavailable checks) were found."""
        return bool(self.branches or self.prs or self.overlapping_epics)


def _normalize_title(title: str) -> str:
    """Strip FR/IMPL prefix and epic ID, then lowercase.

    Examples:
        "FR-E020: Issue Tracking" → "issue tracking"
        "Issue Tracking" → "issue tracking"
        "IMPL-E005: My Feature" → "my feature"
    """
    # Strip FR-E###: or IMPL-E###: prefix
    cleaned = re.sub(r"^(?:FR|IMPL)-[ES]\d{3}[a-z]?:\s*", "", title)
    return cleaned.lower().strip()


def _check_epic_branches(
    title: str, cwd: str | None = None
) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Check for conflicting remote epic branches.

    Args:
        title: Title of the new epic (unused but kept for API symmetry).
        cwd: Working directory for git commands. Ensures checks run in
             the correct repository when ``docs_root`` differs from cwd.

    Returns:
        (branch_warnings, unavailable_warnings)
    """
    branches: list[dict[str, str]] = []
    unavailable: list[dict[str, str]] = []

    if not shutil.which("git"):
        unavailable.append(
            {
                "type": "check_unavailable",
                "check": "git_branch",
                "message": "git not found — branch check skipped",
            }
        )
        return branches, unavailable

    try:
        result = subprocess.run(
            ["git", "branch", "-r", "--list", "origin/epic/*"],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=cwd,
        )
        if result.returncode != 0:
            unavailable.append(
                {
                    "type": "check_unavailable",
                    "check": "git_branch",
                    "message": f"git branch -r failed: {result.stderr.strip()}",
                }
            )
            return branches, unavailable

        for line in result.stdout.strip().splitlines():
            branch_name = line.strip()
            if branch_name:
                branches.append(
                    {
                        "type": "branch_conflict",
                        "branch": branch_name,
                        "message": f"Active epic branch exists: {branch_name}",
                    }
                )
    except subprocess.TimeoutExpired:
        unavailable.append(
            {
                "type": "check_unavailable",
                "check": "git_branch",
                "message": "git branch -r timed out",
            }
        )
    except Exception as e:
        unavailable.append(
            {
                "type": "check_unavailable",
                "check": "git_branch",
                "message": f"git branch check failed: {e}",
            }
        )

    return branches, unavailable


def _check_epic_prs(
    cwd: str | None = None,
) -> tuple[list[dict[str, str | int]], list[dict[str, str]]]:
    """Check for open PRs with epic/ head branches.

    Args:
        cwd: Working directory for gh commands. Ensures checks run in
             the correct repository when ``docs_root`` differs from cwd.

    Returns:
        (pr_warnings, unavailable_warnings)
    """
    prs: list[dict[str, str | int]] = []
    unavailable: list[dict[str, str]] = []

    if not shutil.which("gh"):
        unavailable.append(
            {
                "type": "check_unavailable",
                "check": "gh_pr",
                "message": "gh CLI not found — PR check skipped",
            }
        )
        return prs, unavailable

    try:
        result = subprocess.run(
            [
                "gh",
                "pr",
                "list",
                "--state",
                "open",
                "--limit",
                "200",
                "--json",
                "number,title,headRefName,url",
            ],
            capture_output=True,
            text=True,
            timeout=15,
            cwd=cwd,
        )
        if result.returncode != 0:
            unavailable.append(
                {
                    "type": "check_unavailable",
                    "check": "gh_pr",
                    "message": f"gh pr list failed: {result.stderr.strip()}",
                }
            )
            return prs, unavailable

        try:
            pr_list = json.loads(result.stdout)
        except json.JSONDecodeError:
            unavailable.append(
                {
                    "type": "check_unavailable",
                    "check": "gh_pr",
                    "message": "gh pr list returned invalid JSON",
                }
            )
            return prs, unavailable

        for pr in pr_list:
            head_ref = pr.get("headRefName", "")
            if head_ref.startswith("epic/"):
                prs.append(
                    {
                        "type": "pr_conflict",
                        "pr_number": pr.get("number", 0),
                        "pr_url": pr.get("url", ""),
                        "message": (
                            f"Open epic PR #{pr.get('number', '?')}: "
                            f"{pr.get('title', '(untitled)')} "
                            f"(branch: {head_ref})"
                        ),
                    }
                )
    except subprocess.TimeoutExpired:
        unavailable.append(
            {
                "type": "check_unavailable",
                "check": "gh_pr",
                "message": "gh pr list timed out",
            }
        )
    except Exception as e:
        unavailable.append(
            {
                "type": "check_unavailable",
                "check": "gh_pr",
                "message": f"gh pr check failed: {e}",
            }
        )

    return prs, unavailable


def _check_title_overlap(
    title: str,
    docs_root: Path,
    threshold: float = _DEFAULT_SIMILARITY_THRESHOLD,
) -> list[dict[str, str | float]]:
    """Check for existing epics with similar titles.

    Uses difflib.SequenceMatcher for fuzzy matching after normalizing titles.

    Returns:
        List of title_overlap warning dicts.
    """
    overlaps: list[dict[str, str | float]] = []
    normalized_new = _normalize_title(title)

    if not normalized_new:
        return overlaps

    try:
        from nspec.domain.datasets import DatasetLoader

        loader = DatasetLoader(docs_root=docs_root)
        datasets = loader.load()

        for spec_id, fr in datasets.active_frs.items():
            if not spec_id.startswith("E"):
                continue  # Only check epics

            normalized_existing = _normalize_title(fr.title)
            if not normalized_existing:
                continue

            similarity = difflib.SequenceMatcher(None, normalized_new, normalized_existing).ratio()

            if similarity >= threshold:
                overlaps.append(
                    {
                        "type": "title_overlap",
                        "epic_id": spec_id,
                        "similarity": round(similarity, 2),
                        "message": (
                            f"Existing epic {spec_id} has similar title "
                            f"(similarity: {similarity:.0%}): {fr.title}"
                        ),
                    }
                )
    except Exception as e:
        logger.debug("Title overlap check failed: %s", e)
        # Title overlap failure is not critical — silently skip
        # (unlike git/gh which produce check_unavailable)

    return overlaps


def epic_conflict_check(
    title: str,
    docs_root: Path,
    similarity_threshold: float | None = None,
) -> ConflictReport:
    """Check for conflicts before creating a new epic.

    Runs three checks:
    1. Remote ``epic/*`` branches via ``git branch -r``
    2. Open PRs with ``epic/`` head branches via ``gh pr list``
    3. Title overlap with existing epics via fuzzy matching

    All checks are graceful — if ``git`` or ``gh`` are unavailable or
    commands fail, a ``check_unavailable`` warning is emitted instead of
    raising an error.

    Args:
        title: Title of the new epic being created
        docs_root: Path to the docs directory
        similarity_threshold: Fuzzy match threshold (0.0-1.0).
            Default: 0.6. Can be configured via ``[epic].similarity_threshold``
            in config.toml.

    Returns:
        ConflictReport with typed warning lists.
    """
    if similarity_threshold is None:
        # Try to load from config
        try:
            from nspec.config import NspecConfig

            config = NspecConfig.load()
            raw = config._raw  # noqa: SLF001
            threshold = raw.get("epic", {}).get("similarity_threshold")
            if threshold is not None:
                similarity_threshold = float(threshold)
        except Exception:
            pass

        if similarity_threshold is None:
            similarity_threshold = _DEFAULT_SIMILARITY_THRESHOLD

    report = ConflictReport()

    # Derive project root from docs_root so git/gh run in the right repo.
    # docs_root is typically <project>/docs — go up one level.
    project_cwd = str(docs_root.parent) if docs_root.exists() else None

    # Check 1: Remote epic branches
    branch_warnings, branch_unavailable = _check_epic_branches(title, cwd=project_cwd)
    report.branches.extend(branch_warnings)
    report.unavailable.extend(branch_unavailable)

    # Check 2: Open PRs
    pr_warnings, pr_unavailable = _check_epic_prs(cwd=project_cwd)
    report.prs.extend(pr_warnings)
    report.unavailable.extend(pr_unavailable)

    # Check 3: Title overlap
    overlap_warnings = _check_title_overlap(title, docs_root, similarity_threshold)
    report.overlapping_epics.extend(overlap_warnings)

    return report
