"""Entry point for running nspec as a module.

Usage:
    python -m nspec validate
    python -m nspec generate
    python -m nspec spec --id S124
"""

import sys

from nspec.cli import main

if __name__ == "__main__":
    sys.exit(main())
