"""MCP checkout, session, init, skills, artifacts, and utility tools."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from nspec.domain import lifecycle_hints
from nspec.interfaces.mcp._helpers import (
    _dao,
    _exception_error,
    _invalid_id_error,
    _resolve_docs_root,
    _resolve_id_from_disk,
    _resolve_project_root,
    _to_bool,
    _tool_error,
)
from nspec.interfaces.mcp.server import mcp

logger = logging.getLogger("nspec.mcp")


@mcp.tool()
def checkout(
    spec_id: str,
    agent_id: str | None = None,
    ttl: int | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Reserve a spec with a TTL lease (checkout without activating).

    Prevents other agents from working on the same spec. Each spec
    can only have one active checkout. Use ``checkin`` to release.

    Args:
        spec_id: Spec ID to check out
        agent_id: Optional agent identifier
        ttl: Lease duration in seconds (default: config checkout_ttl_seconds)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import CheckoutDAO

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    try:
        dao = CheckoutDAO(project_root)
        dao.reap_expired()
        entry = dao.checkout(spec_id, agent_id=agent_id, ttl=ttl)
    except ValueError as e:
        return _tool_error(str(e))
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "session_id": entry.session_id,
        "lease_expires": entry.lease_expires,
        "agent_id": entry.agent_id,
    }


@mcp.tool()
def checkin(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Release a spec checkout reservation.

    Args:
        spec_id: Spec ID to release
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import CheckoutDAO

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    try:
        dao = CheckoutDAO(project_root)
        released = dao.checkin(spec_id)
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "spec_id": spec_id,
        "released": released,
    }


@mcp.tool()
def checkout_status(
    docs_root: str | None = None,
) -> dict[str, Any]:
    """List all active spec checkouts with TTL remaining.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    import time as _time

    from nspec.runtime.session import CheckoutDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        dao = CheckoutDAO(project_root)
        dao.reap_expired()
        active = dao.list_active()
    except Exception as e:
        return _exception_error(e)

    now = _time.time()
    entries = []
    for sid, entry in active.items():
        entries.append(
            {
                "spec_id": sid,
                "session_id": entry.session_id,
                "agent_id": entry.agent_id,
                "checked_out_at": entry.checked_out_at,
                "ttl_remaining_s": round(entry.lease_expires - now, 1),
            }
        )

    return {
        "success": True,
        "count": len(entries),
        "checkouts": entries,
    }


@mcp.tool()
def checkout_heartbeat(
    spec_id: str,
    ttl: int | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Extend the lease for a checked-out spec.

    Args:
        spec_id: Spec ID whose lease to extend
        ttl: New lease duration in seconds (default: config checkout_ttl_seconds)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import CheckoutDAO

    root = _resolve_docs_root(docs_root)
    try:
        spec_id = _resolve_id_from_disk(spec_id, root)
    except ValueError:
        return _invalid_id_error(spec_id)
    project_root = _resolve_project_root(root)

    try:
        dao = CheckoutDAO(project_root)
        entry = dao.heartbeat(spec_id, ttl=ttl)
    except Exception as e:
        return _exception_error(e)

    if entry is None:
        return _tool_error(f"Spec {spec_id} is not currently checked out")

    return {
        "success": True,
        "spec_id": spec_id,
        "lease_expires": entry.lease_expires,
    }


@mcp.tool()
def session_list(
    spec_id: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """List all sessions, optionally filtered by spec ID.

    Args:
        spec_id: Filter to sessions for this spec (optional)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    if spec_id:
        try:
            spec_id = _resolve_id_from_disk(spec_id, root)
        except ValueError:
            return _invalid_id_error(spec_id)
    try:
        dao = SessionDAO(project_root)
        sessions = dao.list(spec_id=spec_id)
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "count": len(sessions),
        "sessions": [
            {
                "session_id": s.session_id,
                "spec_id": s.spec_id,
                "status": s.status,
                "last_phase": s.last_phase,
                "last_task": s.last_task,
                "started_at": s.started_at,
                "updated_at": s.updated_at,
            }
            for s in sessions
        ],
    }


@mcp.tool()
def session_get(
    session_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Get a session by its session ID.

    Args:
        session_id: Session ID (e.g., "S186-20260308T140836Z")
        docs_root: Path to docs directory (default: ./docs)
    """
    from dataclasses import asdict

    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        dao = SessionDAO(project_root)
        state = dao.get(session_id)
    except Exception as e:
        return _exception_error(e)
    if not state:
        return _tool_error(f"Session {session_id} not found")
    result = asdict(state)
    result["success"] = True
    return result


@mcp.tool()
def session_delete(
    session_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Delete a session file.

    Args:
        session_id: Session ID to delete
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.runtime.session import SessionDAO

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        dao = SessionDAO(project_root)
        deleted = dao.delete(session_id)
    except Exception as e:
        return _exception_error(e)
    return {
        "success": True,
        "deleted": deleted,
        "session_id": session_id,
    }


@mcp.tool()
def init(
    epic_title: str = "Default Epic",
    docs_root: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Initialize a new nspec project with full directory structure.

    Creates config.toml, docs directories, templates, and a default epic.
    This is the recommended way to start a new nspec project.

    If the project is already initialized, returns information about
    existing setup unless force=True.

    Args:
        epic_title: Title for the default epic (default: "Default Epic")
        docs_root: Path to docs directory (default: ./docs)
        force: Overwrite existing files if True
    """
    from nspec.orchestration.init import scaffold_project

    # Determine paths — init is special: it creates the config, so we can't
    # use _resolve_docs_root() which has auto-scaffold side effects.
    root = Path(docs_root).resolve() if docs_root else Path("docs").resolve()
    project_root = _resolve_project_root(root)

    # Check if already initialized
    from nspec.config import CONFIG_REL_PATH

    config_file = project_root / CONFIG_REL_PATH
    force = _to_bool(force)

    if config_file.exists() and not force:
        # Already initialized — return info about existing setup
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        return {
            "success": True,
            "already_initialized": True,
            "config_file": str(config_file),
            "default_epic": config.defaults.epic,
            "hint": "Project already initialized. Use force=True to reinitialize.",
        }

    # Scaffold the project structure
    try:
        created = scaffold_project(
            project_root,
            docs_root=root.resolve(),
            ci_platform_override="none",  # Don't auto-detect CI for MCP init
            force=force,
        )
    except Exception as e:
        return _exception_error(e)

    # Reload config to get the actual paths
    from nspec.config import NspecConfig

    config = NspecConfig.load(project_root)

    # Create default epic if one doesn't exist
    epic_id = None
    fr_dir = root / config.paths.feature_requests
    existing_epics = list(fr_dir.glob("FR-E*-*.md")) if fr_dir.exists() else []

    if not existing_epics:
        try:
            fr_path, impl_path, epic_id = _dao(root).specs.create(epic_title, "P2", is_epic=True)
            created.extend([fr_path, impl_path])

            # Set as default epic in config
            epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
            config.defaults.epic = epic_num
            config.save()
        except Exception as e:
            return {
                "success": True,
                "warning": f"Project scaffolded but failed to create default epic: {e}",
                "created": [str(p) for p in created if p.is_file()],
            }
    else:
        # Use existing epic as default if none set
        import re

        for epic_file in existing_epics:
            match = re.match(r"FR-(E\d{3})", epic_file.name)
            if match:
                epic_id = match.group(1)
                if config.defaults.epic is None:
                    epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
                    config.defaults.epic = epic_num
                    config.save()
                break

    # Run version sync to install skills and stamp version on new projects
    try:
        from nspec.sync import ensure_synced

        ensure_synced(project_root)
    except Exception:
        logger.debug("Post-init sync failed (non-fatal)", exc_info=True)

    return {
        "success": True,
        "project_root": str(project_root),
        "docs_root": str(root.resolve()),
        "config_file": str(config_file),
        "default_epic": epic_id,
        "created_files": [str(p) for p in created if p.is_file()],
        "created_dirs": [str(p) for p in created if p.is_dir()],
        "next_steps": [
            f"Create your first spec: create_spec('My Feature', epic_id='{epic_id}')",
            "View the backlog: epics()",
            "Validate setup: validate()",
        ],
    }


@mcp.tool()
def skills_install(docs_root: str | None = None, force: bool = False) -> dict[str, Any]:
    """Install skills to `.novabuilt.dev/nspec/commands/` and sync to agents.

    Installs built-in nspec skills (and any custom sources from config)
    to the canonical nspec commands directory, then creates symlinks from
    agent-specific directories (e.g. `.claude/commands/`).

    Args:
        docs_root: Path to docs directory (default: ./docs)
        force: If True, overwrite all existing skill files regardless
               of managed-by status. Useful for fixing stale installs.
    """
    from nspec.config import NspecConfig
    from nspec.skills import install_skills, resolve_skills, sync_to_agents

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        config = NspecConfig.load(project_root)
        resolved = resolve_skills(config.skills.sources, project_root=project_root)
        installed = install_skills(project_root, resolved, force=force)
        synced = sync_to_agents(project_root, targets=config.skills.targets)
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "installed": [str(p.relative_to(project_root)) for p in installed],
        "synced": [str(p.relative_to(project_root)) for p in synced],
        "count": len(installed),
        "forced": force,
    }


@mcp.tool()
def skills_list(docs_root: str | None = None) -> dict[str, Any]:
    """List available skills with source info.

    Returns all resolved skills showing which source each comes from.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.config import NspecConfig
    from nspec.skills import VALID_TARGETS, resolve_skills

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        config = NspecConfig.load(project_root)
        skills_info = []
        for target in VALID_TARGETS:
            # Filesystem sources are Claude-only; Codex only has builtins
            sources = config.skills.sources if target == "claude" else ["builtin"]
            resolved = resolve_skills(sources, project_root=project_root, target=target)
            for name, info in sorted(resolved.items()):
                skills_info.append(
                    {
                        "name": name,
                        "source": info.source,
                        "target": info.target,
                        "size": len(info.content),
                    }
                )
    except Exception as e:
        return _exception_error(e)

    return {
        "sources": config.skills.sources,
        "skills": skills_info,
        "count": len(skills_info),
    }


@mcp.tool()
def skills_sync(docs_root: str | None = None, force: bool = False) -> dict[str, Any]:
    """Re-sync skills from sources (update after nspec upgrade).

    Re-resolves skills from configured sources and updates
    `.novabuilt.dev/nspec/commands/`, then syncs symlinks to agent dirs.
    Useful after `pip install --upgrade nspec`.

    Args:
        docs_root: Path to docs directory (default: ./docs)
        force: If True, overwrite all existing skill files regardless
               of managed-by status. Useful for fixing stale installs.
    """
    from nspec.config import NspecConfig
    from nspec.skills import install_skills, resolve_skills, sync_to_agents

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    try:
        config = NspecConfig.load(project_root)
        resolved = resolve_skills(config.skills.sources, project_root=project_root)
        installed = install_skills(project_root, resolved, force=force)
        synced_paths = sync_to_agents(project_root, targets=config.skills.targets)
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "synced": [str(p.relative_to(project_root)) for p in installed],
        "agent_synced": [str(p.relative_to(project_root)) for p in synced_paths],
        "count": len(installed),
        "forced": force,
    }


@mcp.tool()
def skills_update(choice: str, docs_root: str | None = None) -> dict[str, Any]:
    """Apply skills update with user's consent choice.

    Called when nspec detects an upgrade and skills_auto_update is unset.
    The agent should present the choice to the user before calling this.

    Args:
        choice: One of:
            - "always": auto-update skills on every future upgrade
            - "once": update skills just this time
            - "never": never auto-update skills
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.sync import apply_skills_update

    persist_map = {"always": True, "once": None, "never": False}
    persist = persist_map.get(choice)
    if persist is ... or choice not in persist_map:
        return {
            "success": False,
            "error": f"Invalid choice: {choice!r}. Use 'always', 'once', or 'never'.",
        }

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)
    return apply_skills_update(project_root, persist=persist)


@mcp.tool()
def artifacts_list(docs_root: str | None = None) -> dict[str, Any]:
    """List all nspec-managed artifacts with modification status.

    Returns the artifact manifest showing each managed file's path,
    source, and whether it has been modified since nspec created it.

    Args:
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.artifacts import ArtifactManifest

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        manifest = ArtifactManifest.load(project_root)
        statuses = manifest.status(project_root)
    except Exception as e:
        return _exception_error(e)

    summary = {
        "current": sum(1 for s in statuses if s["status"] == "current"),
        "modified": sum(1 for s in statuses if s["status"] == "modified"),
        "missing": sum(1 for s in statuses if s["status"] == "missing"),
    }

    return {
        "nspec_version": manifest.nspec_version,
        "created_at": manifest.created_at,
        "artifacts": statuses,
        "summary": summary,
        "total": len(statuses),
    }


@mcp.tool()
def artifacts_sync(
    docs_root: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Sync managed artifacts to the current nspec version.

    Updates stale managed artifacts (checksum mismatch) to their current
    nspec-version content. Respects managed-by markers — skips files the
    user has forked by removing the marker.

    Args:
        docs_root: Path to docs directory (default: ./docs)
        dry_run: If True, show what would change without writing.
    """
    from nspec.artifacts import ArtifactManifest
    from nspec.config import NspecConfig
    from nspec.orchestration.init import _interpolate_template
    from nspec.resources import load_template

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        manifest = ArtifactManifest.load(project_root)
        config = NspecConfig.load(project_root)

        # Resolve template variables for interpolation
        project_name = project_root.name
        try:
            docs_rel = str(root.resolve().relative_to(project_root))
        except ValueError:
            docs_rel = str(root)
        epic_id = getattr(config.defaults, "epic", None) or "001"

        variables = {
            "project_name": project_name,
            "docs_root": docs_rel,
            "epic_id": epic_id,
            "feature_requests": config.paths.feature_requests,
            "implementation": config.paths.implementation,
            "completed": config.paths.completed,
            "test_command": "make test-quick",
            "lint_command": "make lint",
            "format_command": "make format",
            "check_command": "make check",
            "commit_format": "feat(scope): description",
        }

        # Build current content for syncable templates (interpolated)
        current_contents: dict[str, str] = {}
        for template_id in ("claudemd", "devprocess"):
            try:
                raw = load_template(template_id)
                current_contents[template_id] = _interpolate_template(raw, variables)
            except ValueError:
                pass

        results = manifest.sync(
            project_root,
            current_contents=current_contents,
            dry_run=dry_run,
        )
    except Exception as e:
        return _exception_error(e)

    return {
        "success": True,
        "dry_run": dry_run,
        "results": results,
        "updated": sum(1 for r in results if r["action"] == "updated"),
        "skipped": sum(1 for r in results if r["action"].startswith("skipped")),
        "current": sum(1 for r in results if r["action"] == "current"),
    }


@mcp.tool()
def coverage_audit(
    coverage_json: str = "coverage.json",
    registry: str = "work/coverage_decisions.json",
    strict: bool = False,
    include: str | None = None,
    exclude: str | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Run full-suite coverage audit and return candidate status.

    Parses pytest-cov JSON, inventories uncovered and suspicious code,
    reconciles against the decision registry, and returns a summary.

    Args:
        coverage_json: Path to pytest-cov JSON output
        registry: Path to decision registry JSON
        strict: If True, gate_pass requires zero unresolved/stale
        include: Comma-separated regex patterns for files to include
        exclude: Comma-separated regex patterns for files to exclude
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.analysis.coverage_audit import audit_report_json, run_audit

    _resolve_docs_root(docs_root)  # ensure config is loaded

    include_patterns = [p.strip() for p in include.split(",")] if include else None
    exclude_patterns = [p.strip() for p in exclude.split(",")] if exclude else None

    try:
        result = run_audit(
            Path(coverage_json),
            Path(registry),
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
        )
    except (FileNotFoundError, ValueError) as exc:
        return _exception_error(exc)

    report = audit_report_json(result)
    report["strict"] = strict
    if strict:
        report["gate_pass"] = report["gate_pass"]  # already computed
    return {"success": True, **report}


@mcp.tool()
def discover_providers(provider: str | None = None) -> dict[str, Any]:
    """Discover available provider models and configuration values.

    Runs discovery adapters for installed CLI tools and APIs to find
    available models, effort levels, sandbox modes, and provider-specific
    options. Also validates the current config against the provider registry.

    Args:
        provider: Specific provider to discover (codex, gemini, claude, grok).
                  If omitted, discovers all known providers.
    """
    from nspec.config import NspecConfig
    from nspec.providers import discover

    try:
        config = NspecConfig.load()
        timeout = config.timeouts.subprocess_s
    except Exception:
        timeout = 10

    try:
        return {"success": True, **discover(provider, timeout=timeout)}
    except Exception as exc:
        return _exception_error(exc)


@mcp.tool()
def spec_tests(
    spec_id: str,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Run only the tests relevant to a spec.

    Uses Task.tests annotations and IMPLMetadata.test_files (from S220)
    to run a targeted pytest subset. Falls back to `make test-quick`
    if no test annotations are found.

    Args:
        spec_id: Spec ID to run tests for (e.g., "S220")
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.tasks import run_spec_tests

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        result = run_spec_tests(spec_id, root, project_root)
    except Exception as exc:
        return _exception_error(exc)

    response: dict[str, Any] = {
        "success": True,
        "spec_id": result.spec_id,
        "passed": result.passed,
        "fallback": result.fallback,
        "targets": result.targets,
        "returncode": result.returncode,
        "output": result.output[-3000:] if len(result.output) > 3000 else result.output,
    }
    hint_payload = lifecycle_hints.serialize(
        lifecycle_hints.hint_for_spec_tests(
            result.spec_id, passed=result.passed, fallback=result.fallback
        )
    )
    if hint_payload is not None:
        response["next_steps"] = hint_payload
    return response


@mcp.tool()
def spec_test_files(
    spec_id: str,
    action: str = "list",
    files: list[str] | None = None,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Manage test file entries in the ### Test Files section of an IMPL.

    Actions:
      - list: Return current test files
      - add: Add new test file entries (deduplicates)
      - remove: Remove test file entries

    Args:
        spec_id: Spec ID (e.g., "S220")
        action: "list", "add", or "remove"
        files: Test file paths (required for add/remove)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.domain.tasks import (
        add_spec_test_files,
        list_spec_test_files,
        remove_spec_test_files,
    )

    root = _resolve_docs_root(docs_root)
    project_root = _resolve_project_root(root)

    try:
        if action == "list":
            result_files = list_spec_test_files(spec_id, root, project_root)
            return {
                "success": True,
                "files": result_files,
                "added": [],
                "removed": [],
                "warnings": [],
            }
        elif action == "add":
            if not files:
                return {"success": False, "error": "files parameter required for add action"}
            result = add_spec_test_files(spec_id, files, root, project_root)
            return {
                "success": True,
                "files": result.get("files", []),
                "added": result.get("added", []),
                "removed": [],
                "warnings": result.get("warnings", []),
            }
        elif action == "remove":
            if not files:
                return {"success": False, "error": "files parameter required for remove action"}
            result = remove_spec_test_files(spec_id, files, root, project_root)
            return {
                "success": True,
                "files": result.get("files", []),
                "added": [],
                "removed": result.get("removed", []),
                "warnings": result.get("warnings", []),
            }
        else:
            return {
                "success": False,
                "error": f"Unknown action: {action}. Use list, add, or remove.",
            }
    except Exception as exc:
        return _exception_error(exc)


@mcp.tool()
def context_audit(
    file: str | None = None,
    threshold: int = 50,
    docs_root: str | None = None,
) -> dict[str, Any]:
    """Analyze a CLAUDE.md file for context budget and extraction candidates.

    Parses CLAUDE.md into ##-level sections, classifies each as behavioral
    (conventions, invariants, AI guidance) or reference (tables, command
    lists, directory trees), and recommends extractions when reference
    content exceeds the threshold.

    Args:
        file: Path to CLAUDE.md (default: ./CLAUDE.md in project root)
        threshold: Reference percentage above which to recommend extractions (default: 50)
        docs_root: Path to docs directory (default: ./docs)
    """
    from nspec.analysis.context_audit import audit_to_dict, run_context_audit

    _resolve_docs_root(docs_root)

    file_path = file or "CLAUDE.md"
    threshold_frac = threshold / 100.0

    try:
        result = run_context_audit(file_path, threshold=threshold_frac)
    except FileNotFoundError as exc:
        return _exception_error(exc)

    return {"success": True, **audit_to_dict(result)}
