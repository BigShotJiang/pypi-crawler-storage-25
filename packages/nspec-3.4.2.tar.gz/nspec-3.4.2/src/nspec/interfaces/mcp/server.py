"""nspec MCP Server — FastMCP instance, instrumentation, and bootstrap.

Provides both stdio and SSE transports for AI coding assistant integration.
Each tool is a thin wrapper calling existing crud/reports/session functions.

Usage:
    nspec mcp          # stdio transport (default, for Claude Code)
    nspec mcp --sse    # SSE transport (for web clients)
    nspec mcp --http   # streamable-http transport
"""

from __future__ import annotations

import logging
import os
import sys
from builtins import print as _builtin_print
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger("nspec.mcp")

mcp = FastMCP(
    "nspec",
    instructions="Specification-driven backlog management tools for AI-native development",
)

# ---------------------------------------------------------------------------
# Telemetry: auto-instrument every @mcp.tool() with logging + timeout
# ---------------------------------------------------------------------------
_original_mcp_tool = mcp.tool

# Version-gated sync: runs once per MCP session on first tool call
_sync_checked: bool = False
_pending_notice: str | None = None


def _instrumented_tool(**kwargs: Any):  # type: ignore[no-untyped-def]
    """Wrap mcp.tool() so every registered tool gets telemetry + timeout.

    Also runs version-gated sync on the first tool call per session.
    Tools that manage their own timeout (e.g. execute_agent) are excluded
    from the blanket MCP timeout wrapper to avoid premature cancellation.
    """
    from functools import wraps

    from nspec.telemetry import mcp_telemetry, mcp_timeout

    # Tools that handle their own timeout internally
    _self_timed_tools = {"execute_agent"}

    def decorator(fn):  # type: ignore[no-untyped-def]
        if fn.__name__ in _self_timed_tools:
            wrapped = mcp_telemetry(fn)
        else:
            wrapped = mcp_timeout()(mcp_telemetry(fn))

        @wraps(wrapped)
        def with_sync_check(*args: Any, **kw: Any) -> Any:
            global _sync_checked, _pending_notice  # noqa: PLW0603
            if not _sync_checked:
                _sync_checked = True
                try:
                    from nspec.sync import ensure_synced

                    sync_result = ensure_synced()
                    if sync_result.get("skills_update_available"):
                        _pending_notice = (
                            "nspec has been upgraded. New/updated skills are available. "
                            "Call skills_update(choice) with 'always', 'once', or 'never'."
                        )
                except Exception:
                    pass
            response = wrapped(*args, **kw)
            # Inject notice into first response after sync, then clear
            if _pending_notice and isinstance(response, dict):
                response["_nspec_notice"] = _pending_notice
                _pending_notice = None
            return response

        return _original_mcp_tool(**kwargs)(with_sync_check)

    return decorator


mcp.tool = _instrumented_tool  # type: ignore[assignment]


def _redirect_print_to_stderr_for_stdio() -> None:
    """Ensure incidental print() calls never write to MCP's stdout transport."""
    import builtins

    if getattr(_redirect_print_to_stderr_for_stdio, "_patched", False):
        return

    def _stderr_print(*args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("file", sys.stderr)
        _builtin_print(*args, **kwargs)

    builtins.print = _stderr_print
    _redirect_print_to_stderr_for_stdio._patched = True


def main(transport: str = "stdio") -> None:
    """Run the MCP server.

    Args:
        transport: One of "stdio", "sse", or "streamable-http".
    """
    from nspec.telemetry import setup_telemetry_logging

    setup_telemetry_logging()

    # Ensure tool modules are imported (registers @mcp.tool() functions).
    # When called via `nspec.interfaces.mcp`, __init__.py already imported them.
    # When called directly via `nspec.interfaces.mcp.server`, this is the fallback.
    import nspec.interfaces.mcp._audit  # noqa: F401
    import nspec.interfaces.mcp._checkout  # noqa: F401
    import nspec.interfaces.mcp._mutation  # noqa: F401
    import nspec.interfaces.mcp._query  # noqa: F401

    logger.debug("MCP server starting: cwd=%s, transport=%s", Path.cwd(), transport)
    if transport == "stdio":
        _redirect_print_to_stderr_for_stdio()
    if transport in ("sse", "streamable-http"):
        mcp.settings.host = os.environ.get("NSPEC_MCP_HOST", "0.0.0.0")
        mcp.settings.port = int(os.environ.get("NSPEC_MCP_PORT", "8080"))
    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
