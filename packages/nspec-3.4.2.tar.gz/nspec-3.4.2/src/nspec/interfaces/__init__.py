"""nspec interfaces — external protocol adapters."""
