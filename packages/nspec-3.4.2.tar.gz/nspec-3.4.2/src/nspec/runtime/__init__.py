"""Runtime infrastructure for nspec.

Submodules:
    atomic     — Atomic file writes and batched write operations
    locks      — File-based locking for specs, queue, and state
    timestamps — ISO timestamp generation
    session    — Session persistence (SessionDAO, CheckoutDAO, LoopRetriesDAO)
"""

from nspec.runtime.atomic import atomic_write, batch_writes, spec_read, spec_write
from nspec.runtime.locks import queue_lock, spec_lock, state_lock
from nspec.runtime.session import (
    CheckoutDAO,
    CheckoutEntry,
    LoopRetriesDAO,
    SessionDAO,
    SessionState,
    clear_session,
    load_session,
    save_session,
)
from nspec.runtime.timestamps import now_iso

__all__ = [
    # atomic
    "atomic_write",
    "batch_writes",
    "spec_read",
    "spec_write",
    # locks
    "queue_lock",
    "spec_lock",
    "state_lock",
    # timestamps
    "now_iso",
    # session
    "CheckoutDAO",
    "CheckoutEntry",
    "LoopRetriesDAO",
    "SessionDAO",
    "SessionState",
    "clear_session",
    "load_session",
    "save_session",
]
