"""Pluggable DAO layer for nspec persistence.

Provides Protocol-based abstractions over crud.py (markdown) and
future backends (TerminusDB). Config-driven factory selects the active backend.

Usage:
    from nspec.dao import get_registry

    registry = get_registry(docs_root, project_root)
    registry.tasks.check_task("S020", "1")
"""

from nspec.dao.factory import DAORegistry, create_dao_registry
from nspec.dao.registry import get_registry

__all__ = [
    "DAORegistry",
    "create_dao_registry",
    "get_registry",
]
