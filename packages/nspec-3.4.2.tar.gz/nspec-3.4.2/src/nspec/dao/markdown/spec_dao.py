"""Markdown backend for SpecDAO — delegates to crud.py and datasets.py."""

from __future__ import annotations

from pathlib import Path

from nspec.domain.datasets import NspecDatasets
from nspec.validation.validators import FRMetadata, IMPLMetadata


class MarkdownSpecDAO:
    """Spec CRUD operations on markdown FR+IMPL files."""

    def __init__(self, docs_root: Path, project_root: Path | None = None) -> None:
        self._docs_root = docs_root
        self._project_root = project_root

    def get(self, spec_id: str) -> tuple[FRMetadata | None, IMPLMetadata | None]:
        from nspec.domain.datasets import DatasetLoader

        datasets = DatasetLoader(self._docs_root).load()
        fr = datasets.active_frs.get(spec_id) or datasets.completed_frs.get(spec_id)
        impl = datasets.active_impls.get(spec_id) or datasets.completed_impls.get(spec_id)
        return fr, impl

    def list(
        self,
        *,
        epic_id: str | None = None,
        status: str | None = None,
        priority: str | None = None,
    ) -> NspecDatasets:
        from nspec.domain.datasets import DatasetLoader

        # Load full datasets; filtering is done at the caller level
        _ = epic_id, status, priority  # Reserved for future filtering
        return DatasetLoader(self._docs_root).load()

    def create(
        self,
        title: str,
        priority: str,
        *,
        is_epic: bool = False,
        template: str | None = None,
        epic_id: str | None = None,
        auto_priority: bool = False,
    ) -> tuple[Path, Path, str]:
        from nspec.mutation import create_new_spec

        # epic_id is used by MCP layer for auto-adding deps, not by create_new_spec
        _ = epic_id
        return create_new_spec(
            title,
            priority,
            self._docs_root,
            project_root=self._project_root,
            is_epic=is_epic,
            template=template,
            auto_priority=auto_priority,
        )

    def delete(self, spec_id: str, *, force: bool = False) -> tuple[Path, Path]:
        _ = spec_id, force
        raise NotImplementedError("delete not yet implemented for markdown backend")

    def complete(self, spec_id: str) -> tuple[Path, Path, Path, Path]:
        from nspec.mutation import complete_spec

        return complete_spec(
            spec_id,
            self._docs_root,
            project_root=self._project_root,
        )

    def supersede(self, spec_id: str, replacement_id: str) -> tuple[Path, Path, Path, Path]:
        from nspec.mutation import supersede_spec

        return supersede_spec(
            spec_id,
            replacement_id,
            self._docs_root,
            project_root=self._project_root,
        )

    def park(self, spec_id: str, reason: str | None = None) -> tuple[Path, Path]:
        from nspec.mutation import park_spec

        return park_spec(
            spec_id,
            self._docs_root,
            reason=reason,
            project_root=self._project_root,
        )

    def set_exception(self, spec_id: str, reason: str) -> Path:
        from nspec.mutation import set_exception

        return set_exception(
            spec_id,
            self._docs_root,
            reason,
            project_root=self._project_root,
        )

    def start_design(self, spec_id: str) -> tuple[Path, Path]:
        from nspec.mutation import start_design_spec

        return start_design_spec(
            spec_id,
            self._docs_root,
            project_root=self._project_root,
        )

    def hold(self, spec_id: str, reason: str) -> tuple[Path, Path]:
        from nspec.mutation import hold_spec

        return hold_spec(
            spec_id,
            self._docs_root,
            reason=reason,
            project_root=self._project_root,
        )

    def reset(self, spec_id: str) -> tuple[Path, Path]:
        from nspec.mutation import reset_spec

        return reset_spec(
            spec_id,
            self._docs_root,
            project_root=self._project_root,
        )

    def recover(self, spec_id: str) -> tuple[Path, Path]:
        from nspec.mutation import recover_spec

        return recover_spec(
            spec_id,
            self._docs_root,
            project_root=self._project_root,
        )
