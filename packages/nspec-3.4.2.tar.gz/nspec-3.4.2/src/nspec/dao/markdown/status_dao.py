"""Markdown backend for StatusDAO — delegates to crud.py."""

from __future__ import annotations

from pathlib import Path


class MarkdownStatusDAO:
    """Status transition operations on markdown FR+IMPL files."""

    def __init__(self, docs_root: Path, project_root: Path | None = None) -> None:
        self._docs_root = docs_root
        self._project_root = project_root

    def set_status(
        self,
        spec_id: str,
        fr_status: int,
        impl_status: int,
        *,
        force: bool = False,
    ) -> tuple[Path, Path]:
        from nspec.mutation import set_status

        return set_status(
            spec_id,
            fr_status,
            impl_status,
            self._docs_root,
            force=force,
            project_root=self._project_root,
        )

    def next_status(self, spec_id: str) -> tuple[Path, Path]:
        from nspec.mutation import next_status

        return next_status(
            spec_id,
            self._docs_root,
            project_root=self._project_root,
        )
