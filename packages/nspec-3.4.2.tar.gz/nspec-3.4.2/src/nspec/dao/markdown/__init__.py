"""Markdown backend DAO implementations.

Each class is a thin facade delegating to crud.py functions,
binding docs_root/project_root at construction time.
"""

from nspec.dao.markdown.dep_dao import MarkdownDependencyDAO
from nspec.dao.markdown.epic_membership_dao import MarkdownEpicMembershipDAO
from nspec.dao.markdown.review_dao import MarkdownReviewDAO
from nspec.dao.markdown.spec_dao import MarkdownSpecDAO
from nspec.dao.markdown.status_dao import MarkdownStatusDAO
from nspec.dao.markdown.task_dao import MarkdownTaskDAO

__all__ = [
    "MarkdownDependencyDAO",
    "MarkdownEpicMembershipDAO",
    "MarkdownReviewDAO",
    "MarkdownSpecDAO",
    "MarkdownStatusDAO",
    "MarkdownTaskDAO",
]
