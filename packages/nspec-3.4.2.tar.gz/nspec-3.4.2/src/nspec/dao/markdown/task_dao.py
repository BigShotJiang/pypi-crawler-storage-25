"""Markdown backend for TaskDAO — delegates to crud.py."""

from __future__ import annotations

from pathlib import Path


class MarkdownTaskDAO:
    """Task and acceptance-criteria operations on markdown IMPL files."""

    def __init__(self, docs_root: Path, project_root: Path | None = None) -> None:
        self._docs_root = docs_root
        self._project_root = project_root

    def check_task(self, spec_id: str, task_id: str, *, marker: str = "x") -> Path:
        from nspec.mutation import check_impl_task

        return check_impl_task(
            spec_id,
            task_id,
            self._docs_root,
            marker=marker,
            project_root=self._project_root,
        )

    def check_criteria(self, spec_id: str, criteria_id: str, *, marker: str = "x") -> Path:
        from nspec.mutation import check_acceptance_criteria

        return check_acceptance_criteria(
            spec_id,
            criteria_id,
            self._docs_root,
            marker=marker,
            project_root=self._project_root,
        )

    def set_blocked(self, spec_id: str, task_id: str, reason: str) -> Path:
        from nspec.mutation import set_task_blocked

        return set_task_blocked(
            spec_id,
            task_id,
            reason,
            self._docs_root,
            project_root=self._project_root,
        )

    def set_unblocked(self, spec_id: str, task_id: str) -> Path:
        from nspec.mutation import set_task_unblocked

        return set_task_unblocked(
            spec_id,
            task_id,
            self._docs_root,
            project_root=self._project_root,
        )
