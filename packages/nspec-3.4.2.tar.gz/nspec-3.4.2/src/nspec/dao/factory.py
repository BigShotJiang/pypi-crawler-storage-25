"""DAORegistry dataclass and factory function.

The registry holds one instance of each DAO protocol. The factory
reads config to decide which backend to instantiate.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from nspec.dao.protocols import (
    DependencyDAO,
    EpicMembershipDAO,
    QueueDAOProtocol,
    ReviewDAO,
    SessionDAOProtocol,
    SpecDAO,
    StatusDAO,
    TaskDAO,
)

if TYPE_CHECKING:
    from nspec.config import NspecConfig


@dataclass
class DAORegistry:
    """Container for all DAO instances."""

    specs: SpecDAO
    status: StatusDAO
    tasks: TaskDAO
    deps: DependencyDAO
    reviews: ReviewDAO
    sessions: SessionDAOProtocol
    queue: QueueDAOProtocol
    memberships: EpicMembershipDAO


def create_dao_registry(
    docs_root: Path,
    project_root: Path | None = None,
    config: NspecConfig | None = None,
) -> DAORegistry:
    """Build the full registry from config.

    Default: markdown backend. Future: reads ``[backend].engine``
    from config to select TerminusDB or other backends.
    """
    from nspec.dao.markdown import (
        MarkdownDependencyDAO,
        MarkdownEpicMembershipDAO,
        MarkdownReviewDAO,
        MarkdownSpecDAO,
        MarkdownStatusDAO,
        MarkdownTaskDAO,
    )
    from nspec.orchestration.queue import QueueDAO
    from nspec.runtime.session import SessionDAO

    if project_root is None:
        project_root = docs_root.resolve().parent

    return DAORegistry(
        specs=MarkdownSpecDAO(docs_root, project_root),
        status=MarkdownStatusDAO(docs_root, project_root),
        tasks=MarkdownTaskDAO(docs_root, project_root),
        deps=MarkdownDependencyDAO(docs_root, project_root),
        reviews=MarkdownReviewDAO(docs_root, project_root),
        sessions=SessionDAO(project_root),
        queue=QueueDAO(project_root),
        memberships=MarkdownEpicMembershipDAO(docs_root, project_root),
    )
