"""Protocol definitions for the DAO layer.

Six protocols grouping related persistence operations. Each protocol
uses structural subtyping (@runtime_checkable) so implementations
don't need to inherit — they just need matching method signatures.

Existing dataclasses (FRMetadata, IMPLMetadata, NspecDatasets, etc.)
serve as the shared data contract.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from nspec.domain.datasets import NspecDatasets
from nspec.validation.validators import FRMetadata, IMPLMetadata


@runtime_checkable
class SpecDAO(Protocol):
    """CRUD operations on spec (FR+IMPL) pairs."""

    def get(self, spec_id: str) -> tuple[FRMetadata | None, IMPLMetadata | None]: ...

    def list(
        self,
        *,
        epic_id: str | None = None,
        status: str | None = None,
        priority: str | None = None,
    ) -> NspecDatasets: ...

    def create(
        self,
        title: str,
        priority: str,
        *,
        is_epic: bool = False,
        template: str | None = None,
        epic_id: str | None = None,
        auto_priority: bool = False,
    ) -> tuple[Path, Path, str]: ...

    def delete(self, spec_id: str, *, force: bool = False) -> tuple[Path, Path]: ...

    def complete(self, spec_id: str) -> tuple[Path, Path, Path, Path]: ...

    def supersede(self, spec_id: str, replacement_id: str) -> tuple[Path, Path, Path, Path]: ...

    def park(self, spec_id: str, reason: str | None = None) -> tuple[Path, Path]: ...

    def set_exception(self, spec_id: str, reason: str) -> Path: ...

    def start_design(self, spec_id: str) -> tuple[Path, Path]: ...

    def hold(self, spec_id: str, reason: str) -> tuple[Path, Path]: ...

    def reset(self, spec_id: str) -> tuple[Path, Path]: ...

    def recover(self, spec_id: str) -> tuple[Path, Path]: ...


@runtime_checkable
class StatusDAO(Protocol):
    """Status transitions for FR+IMPL pairs."""

    def set_status(
        self,
        spec_id: str,
        fr_status: int,
        impl_status: int,
        *,
        force: bool = False,
    ) -> tuple[Path, Path]: ...

    def next_status(self, spec_id: str) -> tuple[Path, Path]: ...


@runtime_checkable
class TaskDAO(Protocol):
    """Task and acceptance-criteria checkbox operations."""

    def check_task(self, spec_id: str, task_id: str, *, marker: str = "x") -> Path: ...

    def check_criteria(self, spec_id: str, criteria_id: str, *, marker: str = "x") -> Path: ...

    def set_blocked(self, spec_id: str, task_id: str, reason: str) -> Path: ...

    def set_unblocked(self, spec_id: str, task_id: str) -> Path: ...


@runtime_checkable
class DependencyDAO(Protocol):
    """Dependency and priority management."""

    def add(self, spec_id: str, dep_id: str) -> dict[str, Any]: ...

    def remove(self, spec_id: str, dep_id: str) -> Path: ...

    def move(self, spec_id: str, target_epic: str) -> dict[str, Any]: ...

    def set_priority(self, spec_id: str, priority: str) -> dict[str, Any]: ...


@runtime_checkable
class EpicMembershipDAO(Protocol):
    """Canonical read/write interface for epic membership (S256).

    Ownership is stored on the child spec via FR `epic_id`. All application
    code that needs to know "which specs belong to epic X" or "which epic
    owns spec Y" MUST go through this DAO — never by scanning epic `deps`
    lists directly.

    The DAO reads through an in-memory snapshot on every call (so callers
    always see the current on-disk state) and mutates the child spec's FR
    file. Epic `deps` are reserved for blocking relationships only.
    """

    def get_owner(self, spec_id: str) -> str | None:
        """Return the epic ID that owns ``spec_id`` (or None)."""

    def get_members(self, epic_id: str) -> list[str]:
        """Return the spec IDs owned by ``epic_id`` (empty list if none)."""

    def all_memberships(self) -> dict[str, str]:
        """Return {spec_id -> epic_id} for every owned spec."""

    def set_owner(self, spec_id: str, epic_id: str) -> Path:
        """Set ``spec_id``'s owning epic to ``epic_id`` (writes child FR)."""

    def clear_owner(self, spec_id: str) -> Path:
        """Remove ``spec_id``'s owning epic (writes child FR)."""

    def move(self, spec_id: str, target_epic_id: str) -> dict[str, Any]:
        """Reassign ``spec_id`` to ``target_epic_id``, preserving deps/blockers."""


@runtime_checkable
class ReviewDAO(Protocol):
    """Review verdict read/write."""

    def get_verdict(self, spec_id: str) -> dict[str, Any]: ...


@runtime_checkable
class SessionDAOProtocol(Protocol):
    """Protocol mirror of session.SessionDAO's public interface."""

    def create(
        self,
        spec_id: str,
        epic_id: str | None = None,
        agent_id: str | None = None,
    ) -> Any: ...

    def get(self, session_id: str) -> Any: ...

    def get_active(self) -> Any: ...

    def list(self, spec_id: str | None = None) -> list[Any]: ...

    def update(self, state: Any) -> Any: ...

    def delete(self, session_id: str) -> bool: ...

    def activate(self, session_id: str) -> Any: ...

    def archive(self, session_id: str) -> Any: ...

    def load(self) -> Any: ...

    def save(self, state: Any) -> Path: ...

    def clear(self) -> bool: ...


@runtime_checkable
class QueueDAOProtocol(Protocol):
    """Protocol mirror of queue.QueueDAO's public interface."""

    def load(self) -> Any: ...

    def save(self, state: Any) -> Path: ...

    def exists(self) -> bool: ...

    def clear(self) -> bool: ...

    def claim(self, agent_id: str) -> dict[str, Any]: ...

    def release(
        self,
        agent_id: str,
        spec_id: str,
        reason: str | None = None,
        completed: bool = False,
    ) -> dict[str, Any]: ...

    def heartbeat(self, agent_id: str) -> dict[str, Any]: ...

    def status(self) -> dict[str, Any]: ...
