#!/bin/bash
# PostToolUse hook for ExitPlanMode
#
# After exiting plan mode, instructs the agent to create an nspec spec
# from the plan via create_spec instead of leaving it as prose.

set -euo pipefail

input=$(cat)
tool_name=$(echo "$input" | jq -r '.tool_name // empty')

# Only act on ExitPlanMode
[ "$tool_name" = "ExitPlanMode" ] || exit 0

jq -n '{
  "decision": "block",
  "reason": "BLOCKED: You must create an nspec spec from your plan before exiting plan mode. Call create_spec with the plan content (title, tasks, acceptance criteria) so it is tracked in the backlog. The spec file IS the plan — do NOT leave it as prose."
}'
