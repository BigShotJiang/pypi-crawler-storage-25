#!/bin/bash
# PostToolUse hook for nspec task_complete / criteria_complete
#
# Reads MCP tool response from stdin, computes remaining work,
# and returns additionalContext to guide Claude's next action.

set -euo pipefail

input=$(cat)
tool_name=$(echo "$input" | jq -r '.tool_name // empty')

# Only act on nspec progress tools
case "$tool_name" in
  mcp__nspec__task_complete|mcp__nspec__criteria_complete) ;;
  *) exit 0 ;;
esac

# Extract spec_id from tool input
spec_id=$(echo "$input" | jq -r '.tool_input.spec_id // empty')
[ -z "$spec_id" ] && exit 0

# Find the IMPL file
cwd=$(echo "$input" | jq -r '.session.cwd // empty')
[ -z "$cwd" ] && cwd="."
impl_file=$(ls "$cwd/docs/impls/active/IMPL-${spec_id}-"*.md 2>/dev/null | head -1)
[ -z "$impl_file" ] && exit 0

# Count tasks
done_count=$(grep -cE '^\s*- \[x\]' "$impl_file" 2>/dev/null || true)
pending_count=$(grep -cE '^\s*- \[ \]' "$impl_file" 2>/dev/null || true)
total=$((done_count + pending_count))

[ "$total" -eq 0 ] && exit 0

# Count ACs from FR
fr_file=$(ls "$cwd/docs/frs/active/FR-${spec_id}-"*.md 2>/dev/null | head -1)
ac_done=0
ac_total=0
if [ -n "$fr_file" ]; then
  ac_done=$(grep -cE '^\s*- \[x\] AC-' "$fr_file" 2>/dev/null || true)
  ac_pending=$(grep -cE '^\s*- \[ \] AC-' "$fr_file" 2>/dev/null || true)
  ac_total=$((ac_done + ac_pending))
fi

# Build context message
if [ "$done_count" -eq "$total" ] && [ "$ac_done" -eq "$ac_total" ] && [ "$ac_total" -gt 0 ]; then
  context="Spec ${spec_id}: ALL tasks (${total}/${total}) and ALL ACs (${ac_total}/${ac_total}) complete. Call advance to move to Testing, then commit your changes."
elif [ "$done_count" -eq "$total" ]; then
  remaining_acs=$(grep -E '^\s*- \[ \] AC-' "$fr_file" 2>/dev/null | sed 's/^\s*- \[ \] /  /' || true)
  context="Spec ${spec_id}: All ${total} tasks complete. ${ac_done}/${ac_total} ACs done. Remaining ACs:
${remaining_acs}
Mark remaining ACs with criteria_complete, then advance and commit."
else
  remaining=$(grep -E '^\s*- \[ \]' "$impl_file" 2>/dev/null | head -5 | sed 's/^\s*- \[ \] /  /')
  context="Spec ${spec_id} progress: ${done_count}/${total} tasks done. Next:
${remaining}"
fi

# Return structured output with additionalContext
jq -n --arg ctx "$context" '{
  "hookSpecificOutput": {
    "hookEventName": "PostToolUse",
    "additionalContext": $ctx
  }
}'
