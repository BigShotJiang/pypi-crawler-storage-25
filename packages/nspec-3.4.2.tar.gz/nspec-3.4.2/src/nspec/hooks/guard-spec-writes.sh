#!/bin/bash
# PreToolUse hook for Edit/Write — blocks direct edits to FR/IMPL files.
# Spec: S313 (FR/IMPL write guard hooks) — closes the trust gap left by S312
# HMAC verdicts: even tamper-detected verdicts can't protect spec content from
# unguarded direct edits. This hook forces all FR/IMPL mutations through nspec
# MCP tools.
#
# Forces agents to modify spec files only through nspec MCP tools, which
# enforce validation, status transitions, and tamper-evident verdicts.
#
# Bypass mechanisms:
#   - `NSPEC_GUARD_DISABLE=1` env var (temporary, for CI/scripting/debug)
#   - `[guard].enforce_mcp_writes = false` in .novabuilt.dev/nspec/config.toml
#
# MCP server writes never hit this hook — the hook only fires for agent
# Edit/Write tool calls, so validated MCP mutations pass through unaffected.

set -euo pipefail

# ---------------------------------------------------------------------------
# Escape hatches — check before parsing stdin
# ---------------------------------------------------------------------------

# Env var bypass (AC-F5)
if [ "${NSPEC_GUARD_DISABLE:-0}" = "1" ]; then
  exit 0
fi

input=$(cat)
tool_name=$(echo "$input" | jq -r '.tool_name // empty')

# Only act on Edit and Write
case "$tool_name" in
  Edit|Write) ;;
  *) exit 0 ;;
esac

file_path=$(echo "$input" | jq -r '.tool_input.file_path // empty')
[ -n "$file_path" ] || exit 0

# Normalize to relative path from project root
project_root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
rel_path="${file_path#"$project_root"/}"

# ---------------------------------------------------------------------------
# Config bypass (AC-F4) — [guard].enforce_mcp_writes = false disables hook
# ---------------------------------------------------------------------------
config_file="${project_root}/.novabuilt.dev/nspec/config.toml"
if [ -f "$config_file" ]; then
  # Minimal TOML parse: look for enforce_mcp_writes under [guard] section.
  # Accepts: true/false, with or without surrounding whitespace.
  guard_enabled=$(awk '
    /^\[guard\]/ { in_guard=1; next }
    /^\[/        { in_guard=0 }
    in_guard && /^[[:space:]]*enforce_mcp_writes[[:space:]]*=/ {
      sub(/^[^=]*=[[:space:]]*/, "")
      sub(/[[:space:]]*(#.*)?$/, "")
      print
      exit
    }
  ' "$config_file")

  if [ "$guard_enabled" = "false" ]; then
    exit 0
  fi
fi

# ---------------------------------------------------------------------------
# Path match — only block docs/frs/ and docs/impls/ files (AC-F1, TC-N3)
# ---------------------------------------------------------------------------
case "$rel_path" in
  docs/frs/*|docs/impls/*) ;;
  *) exit 0 ;;
esac

# ---------------------------------------------------------------------------
# Tool suggestion map (AC-F2)
# ---------------------------------------------------------------------------
case "$rel_path" in
  docs/frs/*)
    suggestion="Direct edits to FR files are not allowed. Use the appropriate nspec MCP tool instead:
  - criteria_complete(spec_id, criteria_id)  — mark acceptance criteria satisfied
  - write_fr_refinement(spec_id, content)    — rewrite FR content (skeleton authoring)
  - set_priority(spec_id, priority)          — change priority
  - activate / advance / complete / park     — change status
If you genuinely need a direct edit (manual fix, debugging), set NSPEC_GUARD_DISABLE=1 or [guard].enforce_mcp_writes = false."
    ;;
  docs/impls/*)
    suggestion="Direct edits to IMPL files are not allowed. Use the appropriate nspec MCP tool instead:
  - task_complete(spec_id, task_id)          — mark tasks done
  - task_block(spec_id, task_id, reason)     — record task failure
  - write_refinement(spec_id, content)       — rewrite IMPL tasks (skeleton refinement)
  - write_review_verdict(spec_id, verdict)   — record reviewer findings
  - activate / advance / complete / park     — change status
If you genuinely need a direct edit (manual fix, debugging), set NSPEC_GUARD_DISABLE=1 or [guard].enforce_mcp_writes = false."
    ;;
esac

jq -n --arg reason "$suggestion" '{
  "decision": "block",
  "reason": $reason
}'
