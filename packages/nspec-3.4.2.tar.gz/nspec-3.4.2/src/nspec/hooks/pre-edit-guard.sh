#!/bin/bash
# PreToolUse hook for Edit/Write
#
# Blocks edits to project files when no active nspec session exists.
# Enforces: "no implementation without a spec."
#
# Excluded paths (no session required):
#   .claude/  .novabuilt.dev/  .codex/  .gemini/  work/  .mcp.json

set -euo pipefail

input=$(cat)
tool_name=$(echo "$input" | jq -r '.tool_name // empty')

# Only act on Edit and Write
case "$tool_name" in
  Edit|Write) ;;
  *) exit 0 ;;
esac

# Get the file path being edited
file_path=$(echo "$input" | jq -r '.tool_input.file_path // empty')
[ -n "$file_path" ] || exit 0

# Normalize to relative path from project root
project_root="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
rel_path="${file_path#"$project_root"/}"

# Exclude meta/config paths — these don't need a spec
case "$rel_path" in
  .claude/*|.novabuilt.dev/*|.codex/*|.gemini/*|work/*|.mcp.json) exit 0 ;;
esac

# Check for active nspec session
active_link="${project_root}/.novabuilt.dev/nspec/sessions/active"
if [ -L "$active_link" ] && [ -e "$active_link" ]; then
  # Active session exists, allow
  exit 0
fi

jq -n '{
  "decision": "block",
  "reason": "BLOCKED: No active nspec session. You need a tracked spec before editing project files.\n\nAsk the user which path to take:\n1. Create a spec from your current plan/task → /nspec\n2. Pick an existing spec from the backlog → next_spec\n3. Skip tracking for this change (user must explicitly approve)"
}'
