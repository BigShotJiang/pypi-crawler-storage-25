"""Built-in hooks bundled with nspec, mirroring the skills install/sync pattern.

Hooks are shell scripts that integrate with agent hook systems (e.g., Claude Code
PreToolUse/PostToolUse hooks). Each hook has a companion JSON metadata file
defining the event type and matcher pattern.

Hooks are installed in three steps:
1. ``install_hooks()`` writes resolved hooks to ``.novabuilt.dev/nspec/hooks/``
   (nspec's canonical hooks directory).
2. ``sync_hooks_to_agents()`` creates symlinks from agent-specific hook dirs
   (e.g. ``.claude/hooks/``) into the canonical hooks directory.
3. ``configure_agent_hooks()`` upserts the agent's settings file
   (e.g. ``.claude/settings.json``) to register hook matchers.
"""

from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from importlib import resources
from pathlib import Path

# Comment header added to installed hook scripts for managed-by tracking.
MANAGED_COMMENT = "# managed-by: nspec"


@dataclass
class HookMeta:
    """Metadata for a hook's agent registration."""

    event: str  # e.g., "PostToolUse", "PreToolUse"
    matcher: str  # e.g., "ExitPlanMode", "Edit|Write"
    timeout: int = 10


@dataclass
class HookInfo:
    """Metadata about a resolved hook."""

    name: str  # e.g., "post-exit-plan"
    script: str  # shell script content
    meta: HookMeta  # registration metadata
    source: str  # "builtin" or a path string


def get_builtin_hooks() -> dict[str, HookInfo]:
    """Return built-in hooks as a dict of {name: HookInfo}.

    Loads ``.sh`` files and companion ``.json`` metadata from the
    ``hooks/`` package directory using ``importlib.resources``.

    Returns:
        Dict mapping hook name to HookInfo.
    """
    hooks: dict[str, HookInfo] = {}
    hooks_dir = resources.files("nspec.hooks")

    # Collect .sh files and their companion .json metadata
    sh_files: dict[str, str] = {}
    json_files: dict[str, str] = {}

    for item in hooks_dir.iterdir():
        if not hasattr(item, "name"):
            continue
        if item.name.endswith(".sh"):
            name = item.name.removesuffix(".sh")
            sh_files[name] = item.read_text(encoding="utf-8")
        elif item.name.endswith(".json"):
            name = item.name.removesuffix(".json")
            json_files[name] = item.read_text(encoding="utf-8")

    # Pair each .sh with its .json metadata
    for name, script in sh_files.items():
        if name not in json_files:
            continue  # skip hooks without metadata
        meta_raw = json.loads(json_files[name])
        meta = HookMeta(
            event=meta_raw["event"],
            matcher=meta_raw["matcher"],
            timeout=meta_raw.get("timeout", 10),
        )
        hooks[name] = HookInfo(name=name, script=script, meta=meta, source="builtin")

    return hooks


def resolve_hooks(
    project_root: Path | None = None,
) -> dict[str, HookInfo]:
    """Resolve hooks from builtin sources.

    Args:
        project_root: Root directory (reserved for future custom sources).

    Returns:
        Dict mapping hook name to HookInfo.
    """
    return get_builtin_hooks()


def _is_managed(content: str) -> bool:
    """Check if a hook script is managed by nspec."""
    return MANAGED_COMMENT in content


def _inject_managed_comment(content: str) -> str:
    """Inject managed-by comment after the shebang line.

    If the script starts with ``#!/``, inserts the managed-by comment
    on the next line. Otherwise prepends it.
    """
    if content.startswith("#!"):
        # Insert after shebang line
        newline_idx = content.index("\n")
        return content[: newline_idx + 1] + MANAGED_COMMENT + "\n" + content[newline_idx + 1 :]
    return MANAGED_COMMENT + "\n" + content


def install_hooks(
    project_root: Path,
    hooks: dict[str, HookInfo],
    *,
    force: bool = False,
) -> list[Path]:
    """Write resolved hooks to ``.novabuilt.dev/nspec/hooks/``.

    Only writes files that are new or already managed by nspec.
    User-created files are left untouched unless force=True.
    Scripts are made executable.

    Args:
        project_root: Project root directory.
        hooks: Resolved hooks from resolve_hooks().
        force: If True, overwrite all files regardless of managed-by status.

    Returns:
        List of paths that were written.
    """
    hooks_dir = project_root / ".novabuilt.dev" / "nspec" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    for name, info in hooks.items():
        dest = hooks_dir / f"{name}.sh"

        # Resolve symlinks to avoid mutating source files
        real_dest = dest.resolve()

        # Skip files not managed by nspec unless forced
        if not force and real_dest.exists():
            existing = real_dest.read_text(encoding="utf-8")
            if not _is_managed(existing):
                continue

        # If the dest is a symlink, remove it first
        if dest.is_symlink():
            dest.unlink()

        # Write with managed-by comment
        dest.write_text(_inject_managed_comment(info.script), encoding="utf-8")
        # Make executable
        dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        written.append(dest)

    return written


def sync_hooks_to_agents(
    project_root: Path,
    targets: dict[str, str] | None = None,
) -> list[Path]:
    """Create symlinks from agent hook dirs to nspec canonical hooks directory.

    For each configured agent target, creates symlinks from the agent's
    hooks directory (e.g., ``.claude/hooks/``) into the canonical
    ``.novabuilt.dev/nspec/hooks/`` directory.

    Args:
        project_root: Project root directory.
        targets: Agent name → relative directory mapping.
            Defaults to config's ``[skills.targets]`` if None.
            The hooks directory is derived by replacing the last
            path component (e.g., ``commands`` → ``hooks``).

    Returns:
        List of symlink paths that were created.
    """
    if targets is None:
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        targets = config.skills.targets

    canonical_dir = project_root / ".novabuilt.dev" / "nspec" / "hooks"
    if not canonical_dir.is_dir():
        return []

    created: list[Path] = []

    for agent_rel_path in targets.values():
        # Derive hooks dir from commands dir: .claude/commands → .claude/hooks
        agent_commands = Path(agent_rel_path)
        agent_hooks_dir = project_root / agent_commands.parent / "hooks"
        agent_hooks_dir.mkdir(parents=True, exist_ok=True)

        for sh_file in sorted(canonical_dir.glob("*.sh")):
            dest = agent_hooks_dir / sh_file.name
            rel_target = Path(os.path.relpath(sh_file, agent_hooks_dir))

            if dest.is_symlink():
                if dest.resolve() == sh_file.resolve():
                    continue
                dest.unlink()
            elif dest.exists():
                # Regular file exists — skip (don't clobber user files)
                continue

            dest.symlink_to(rel_target)
            created.append(dest)

    return created


def configure_agent_hooks(
    project_root: Path,
    hooks: dict[str, HookInfo],
    targets: dict[str, str] | None = None,
) -> list[Path]:
    """Upsert agent settings files to register hook matchers.

    Reads the agent's settings file (e.g., ``.claude/settings.json``),
    merges nspec hook registrations from metadata, and writes back
    preserving existing non-nspec entries.

    Args:
        project_root: Project root directory.
        hooks: Resolved hooks with metadata.
        targets: Agent name → relative directory mapping.

    Returns:
        List of settings files that were modified.
    """
    if targets is None:
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        targets = config.skills.targets

    modified: list[Path] = []

    for agent_rel_path in targets.values():
        agent_commands = Path(agent_rel_path)
        agent_dir = project_root / agent_commands.parent
        settings_path = agent_dir / "settings.json"

        # Read existing settings
        if settings_path.exists():
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        else:
            agent_dir.mkdir(parents=True, exist_ok=True)
            settings = {}

        if "hooks" not in settings:
            settings["hooks"] = {}

        hooks_section = settings["hooks"]

        # Group nspec hooks by event type
        by_event: dict[str, list[tuple[str, HookInfo]]] = {}
        for name, info in hooks.items():
            by_event.setdefault(info.meta.event, []).append((name, info))

        changed = False
        for event, event_hooks in by_event.items():
            if event not in hooks_section:
                hooks_section[event] = []

            existing_entries = hooks_section[event]

            for name, info in event_hooks:
                # The command path is relative to project root
                agent_hooks_rel = str(agent_commands.parent / "hooks" / f"{name}.sh")

                # Check if this hook is already registered
                already_registered = False
                for entry in existing_entries:
                    for hook in entry.get("hooks", []):
                        if hook.get("command") == agent_hooks_rel:
                            already_registered = True
                            break
                    if already_registered:
                        break

                if not already_registered:
                    existing_entries.append(
                        {
                            "matcher": info.meta.matcher,
                            "hooks": [
                                {
                                    "type": "command",
                                    "command": agent_hooks_rel,
                                    "timeout": info.meta.timeout,
                                }
                            ],
                        }
                    )
                    changed = True

        if changed:
            settings_path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
            modified.append(settings_path)

    return modified
