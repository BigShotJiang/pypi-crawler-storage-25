"""Artifact manifest for nspec-managed project files.

Tracks all files nspec creates or manages in a project via an
``artifacts.json`` manifest stored at ``.novabuilt.dev/nspec/artifacts.json``.

Each artifact entry records its path, source, managed-by status, and
SHA-256 checksum so nspec can detect user modifications and selectively
sync stale artifacts to the current nspec version.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# Relative path from project root to the manifest file
MANIFEST_REL_PATH = ".novabuilt.dev/nspec/artifacts.json"

# Managed-by marker pattern (HTML comment used in markdown files)
MANAGED_MARKER = "<!-- managed-by: nspec -->"


@dataclass
class ArtifactEntry:
    """A single managed artifact in the project."""

    id: str
    path: str  # relative to project root
    source: str  # "scaffold", "builtin", "skill", "hook", "ci", "template"
    managed: bool = True
    checksum: str = ""  # "sha256:<hex>"

    def compute_checksum(self, project_root: Path) -> str:
        """Compute SHA-256 checksum of the artifact file.

        Returns:
            Checksum string in ``sha256:<hex>`` format, or empty string
            if the file does not exist or is a directory.
        """
        full_path = project_root / self.path
        if not full_path.exists() or full_path.is_dir():
            return ""
        content = full_path.read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        return f"sha256:{digest}"


@dataclass
class ArtifactManifest:
    """Registry of all nspec-managed files in a project.

    Persisted to ``.novabuilt.dev/nspec/artifacts.json``.
    """

    nspec_version: str = ""
    created_at: str = ""
    artifacts: list[ArtifactEntry] = field(default_factory=list)

    def register(
        self,
        artifact_id: str,
        path: str,
        source: str,
        project_root: Path,
        *,
        managed: bool = True,
    ) -> ArtifactEntry:
        """Register a new artifact or update an existing one.

        Computes the checksum from the file on disk.

        Args:
            artifact_id: Unique identifier for this artifact.
            path: Path relative to project root.
            source: Origin category (scaffold, builtin, skill, etc.).
            project_root: Absolute path to project root.
            managed: Whether nspec manages updates to this file.

        Returns:
            The registered ArtifactEntry.
        """
        # Update existing entry if ID matches
        for entry in self.artifacts:
            if entry.id == artifact_id:
                entry.path = path
                entry.source = source
                entry.managed = managed
                entry.checksum = entry.compute_checksum(project_root)
                return entry

        entry = ArtifactEntry(
            id=artifact_id,
            path=path,
            source=source,
            managed=managed,
        )
        entry.checksum = entry.compute_checksum(project_root)
        self.artifacts.append(entry)
        return entry

    def status(self, project_root: Path) -> list[dict[str, Any]]:
        """Check status of all artifacts.

        Returns a list of dicts with artifact info plus ``status`` field:
        - ``"current"`` — file matches registered checksum
        - ``"modified"`` — file exists but checksum differs
        - ``"missing"`` — file no longer exists on disk

        Args:
            project_root: Absolute path to project root.

        Returns:
            List of status dicts for each artifact.
        """
        results: list[dict[str, Any]] = []
        for entry in self.artifacts:
            full_path = project_root / entry.path
            info = asdict(entry)

            if not full_path.exists():
                info["status"] = "missing"
            elif full_path.is_dir():
                info["status"] = "current"
            else:
                current_checksum = entry.compute_checksum(project_root)
                if current_checksum == entry.checksum:
                    info["status"] = "current"
                else:
                    info["status"] = "modified"

            results.append(info)
        return results

    def save(self, project_root: Path) -> Path:
        """Persist the manifest to ``artifacts.json``.

        Args:
            project_root: Absolute path to project root.

        Returns:
            Path to the written manifest file.
        """
        manifest_path = project_root / MANIFEST_REL_PATH
        manifest_path.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "nspec_version": self.nspec_version,
            "created_at": self.created_at,
            "artifacts": [asdict(e) for e in self.artifacts],
        }
        manifest_path.write_text(
            json.dumps(data, indent=2) + "\n",
            encoding="utf-8",
        )
        return manifest_path

    @classmethod
    def load(cls, project_root: Path) -> ArtifactManifest:
        """Load manifest from ``artifacts.json``.

        Returns an empty manifest if the file does not exist.

        Args:
            project_root: Absolute path to project root.

        Returns:
            Loaded ArtifactManifest.
        """
        manifest_path = project_root / MANIFEST_REL_PATH
        if not manifest_path.exists():
            return cls()

        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        entries = [
            ArtifactEntry(
                id=e["id"],
                path=e["path"],
                source=e["source"],
                managed=e.get("managed", True),
                checksum=e.get("checksum", ""),
            )
            for e in data.get("artifacts", [])
        ]
        return cls(
            nspec_version=data.get("nspec_version", ""),
            created_at=data.get("created_at", ""),
            artifacts=entries,
        )

    def sync(
        self,
        project_root: Path,
        current_contents: dict[str, str] | None = None,
        *,
        dry_run: bool = False,
    ) -> list[dict[str, str]]:
        """Sync managed artifacts to their current nspec version.

        Only updates files that:
        1. Are marked as ``managed=True``
        2. Have a managed-by marker (for markdown files) or are non-markdown
        3. Have a checksum mismatch with the provided current content

        Args:
            project_root: Absolute path to project root.
            current_contents: Dict mapping artifact IDs to their current
                nspec-version content. Only artifacts with an entry here
                will be considered for sync.
            dry_run: If True, report what would change without writing.

        Returns:
            List of dicts with ``id``, ``path``, and ``action`` fields.
        """
        if current_contents is None:
            return []

        results: list[dict[str, str]] = []
        for entry in self.artifacts:
            if not entry.managed:
                continue
            if entry.id not in current_contents:
                continue

            full_path = project_root / entry.path
            new_content = current_contents[entry.id]

            # Skip files the user has forked (no managed-by marker)
            if full_path.exists() and entry.path.endswith(".md"):
                first_line = full_path.read_text(encoding="utf-8").split("\n", 1)[0]
                if MANAGED_MARKER not in first_line:
                    results.append(
                        {"id": entry.id, "path": entry.path, "action": "skipped:user-owned"}
                    )
                    continue

            # Check if update is needed
            if full_path.exists():
                existing = full_path.read_bytes()
                new_digest = hashlib.sha256(new_content.encode("utf-8")).hexdigest()
                old_digest = hashlib.sha256(existing).hexdigest()
                if new_digest == old_digest:
                    results.append({"id": entry.id, "path": entry.path, "action": "current"})
                    continue

            action = "would_update" if dry_run else "updated"
            if not dry_run:
                full_path.parent.mkdir(parents=True, exist_ok=True)
                full_path.write_text(new_content, encoding="utf-8")
                entry.checksum = entry.compute_checksum(project_root)

            results.append({"id": entry.id, "path": entry.path, "action": action})

        if not dry_run:
            self.save(project_root)

        return results


def build_manifest_from_paths(
    created_paths: list[Path],
    project_root: Path,
    nspec_version: str = "",
) -> ArtifactManifest:
    """Build an ArtifactManifest from a list of created file paths.

    Infers artifact IDs and source categories from file paths.

    Args:
        created_paths: List of absolute paths created during scaffold.
        project_root: Absolute path to project root.
        nspec_version: Current nspec version string.

    Returns:
        Populated ArtifactManifest.
    """
    manifest = ArtifactManifest(
        nspec_version=nspec_version,
        created_at=datetime.now(UTC).isoformat(),
    )

    for abs_path in created_paths:
        try:
            rel_path = str(abs_path.relative_to(project_root))
        except ValueError:
            continue

        artifact_id = _infer_artifact_id(rel_path)
        source = _infer_source(rel_path)

        manifest.register(
            artifact_id=artifact_id,
            path=rel_path,
            source=source,
            project_root=project_root,
        )

    return manifest


def _infer_artifact_id(rel_path: str) -> str:
    """Infer a human-readable artifact ID from a relative path."""
    # Skills: .novabuilt.dev/nspec/commands/nloop.md → skill:nloop
    if "commands/" in rel_path and rel_path.endswith(".md"):
        name = Path(rel_path).stem
        return f"skill:{name}"

    # Hooks: .claude/hooks/foo.sh → hook:foo
    if "hooks/" in rel_path and rel_path.endswith(".sh"):
        name = Path(rel_path).stem
        return f"hook:{name}"

    # Templates: .novabuilt.dev/nspec/templates/standard/fr.md → template:standard:fr
    if "templates/" in rel_path:
        parts = Path(rel_path).parts
        # Find "templates" in parts and take the rest
        try:
            idx = list(parts).index("templates")
            suffix_parts = parts[idx + 1 :]
            return "template:" + ":".join(p.replace(".md", "") for p in suffix_parts)
        except (ValueError, IndexError):
            pass

    # Config: .novabuilt.dev/nspec/config.toml → config
    if rel_path.endswith("config.toml"):
        return "config"

    # CLAUDE.md → claudemd
    if rel_path == "CLAUDE.md":
        return "claudemd"

    # DEV-PROCESS.md → devprocess
    if rel_path == "DEV-PROCESS.md":
        return "devprocess"

    # CI configs
    if ".github/workflows/" in rel_path:
        return f"ci:{Path(rel_path).stem}"
    if rel_path in ("cloudbuild.yaml", ".gitlab-ci.yml"):
        return f"ci:{Path(rel_path).stem}"

    # MCP config
    if rel_path == ".mcp.json":
        return "mcp-config"

    # Makefile
    if rel_path == "nspec.mk":
        return "makefile"

    # Directories
    if Path(rel_path).suffix == "":
        return f"dir:{rel_path}"

    # Resources
    if "resources/" in rel_path:
        name = Path(rel_path).stem
        return f"resource:{name}"

    # Fallback: use the path itself
    return rel_path


def _infer_source(rel_path: str) -> str:
    """Infer the source category for an artifact."""
    if "commands/" in rel_path:
        return "skill"
    if "hooks/" in rel_path:
        return "hook"
    if "templates/" in rel_path or "resources/" in rel_path:
        return "template"
    if ".github/" in rel_path or rel_path in ("cloudbuild.yaml", ".gitlab-ci.yml"):
        return "ci"
    return "scaffold"
