"""Epic accordion widget — collapsible panels grouping specs by epic."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from textual.containers import VerticalScroll
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Collapsible, DataTable

from nspec.config import NspecConfig
from nspec.domain.ordering import STATUS_RANK, spec_to_epic_map
from nspec.domain.statuses import (
    DISPLAY_TERMINAL_EMOJIS,
    DepDisplayEmoji,
    EpicDisplayEmoji,
    get_dep_display_emoji,
    parse_status_text,
)

from .display_modes import SortDirection, SortMode, ViewPreset
from .filters import FilterEngine
from .table import apply_sort, calculate_epic_progress, sort_epic_groups
from .utils import clean_title, format_status

if TYPE_CHECKING:
    from .state import NspecData

logger = logging.getLogger("nspec.tui.accordion")


def _load_tui_config():
    """Load TUI display config from config.toml."""
    return NspecConfig.load().tui


class EpicPanel(Collapsible):
    """A collapsible panel for a single epic, containing an inner DataTable."""

    def __init__(
        self,
        epic_id: str | None,
        title: str = "Unassigned",
        *args: Any,
        **kwargs: Any,
    ) -> None:
        """Initialize epic panel with an inner DataTable."""
        self.epic_id = epic_id
        table_id = f"epic-table-{epic_id or 'unassigned'}"
        self._table = DataTable(id=table_id)
        self._table.cursor_type = "row"
        self._table.zebra_stripes = True
        super().__init__(self._table, *args, title=title, **kwargs)

    @property
    def table(self) -> DataTable:
        """Return the inner DataTable."""
        return self._table


class EpicAccordion(Widget):
    """Container orchestrating collapsible epic panels."""

    class SpecSelected(Message):
        """Posted when Enter is pressed on a spec row."""

        def __init__(self, spec_id: str) -> None:
            super().__init__()
            self.spec_id = spec_id

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._expanded_state: dict[str, bool] = {}
        self._focused_spec_id: str | None = None

    def compose(self):
        """Compose the scrollable container for panels."""
        yield VerticalScroll(id="accordion-scroll")

    def _get_panels(self) -> list[EpicPanel]:
        """Get all EpicPanel children in order."""
        try:
            scroll = self.query_one("#accordion-scroll", VerticalScroll)
            return list(scroll.query(EpicPanel))
        except Exception:
            logger.debug("Panel query failed", exc_info=True)
            return []

    def _get_expanded_panels(self) -> list[EpicPanel]:
        """Get only expanded panels with rows."""
        return [p for p in self._get_panels() if not p.collapsed and p.table.row_count > 0]

    def _get_focused_panel(self) -> EpicPanel | None:
        """Get the panel whose inner DataTable has focus."""
        focused = self.screen.focused
        if isinstance(focused, DataTable):
            parent = focused.parent
            if isinstance(parent, EpicPanel):
                return parent
            # Collapsible wraps content in CollapsibleContent
            if parent is not None:
                grandparent = parent.parent
                if isinstance(grandparent, EpicPanel):
                    return grandparent
        return None

    def populate(
        self,
        data: NspecData,
        viewport_width: int = 120,
        view_preset: ViewPreset = ViewPreset.STANDARD,
        sort_mode: SortMode = SortMode.DEPENDENCY,
        sort_direction: SortDirection = SortDirection.ASC,
        filter_engine: FilterEngine | None = None,
    ) -> int:
        """Build/rebuild panels with spec data. Returns total row count."""
        # Save expanded state + focused spec before rebuild
        for panel in self._get_panels():
            key = panel.epic_id or "__unassigned__"
            self._expanded_state[key] = not panel.collapsed

        focused_panel = self._get_focused_panel()
        if focused_panel:
            try:
                table = focused_panel.table
                if table.row_count > 0:
                    row_data = table.get_row_at(table.cursor_row)
                    if row_data:
                        self._focused_spec_id = str(row_data[0])
            except Exception:
                pass

        # Build spec data
        if not data.datasets:
            self._rebuild_panels([], viewport_width, view_preset, sort_mode, sort_direction)
            return 0

        spec_to_epic, epic_ids = spec_to_epic_map(data.datasets)

        # Collect spec data (same logic as NspecTable.populate for grouped mode)
        STATUS_RANK_MAP: dict[str, int] = {}
        spec_data: list[tuple[str, str, str, str, str, str, str, str]] = []
        seen_ids: set[str] = set()

        for spec_id in data.ordered_specs:
            if spec_id in epic_ids:
                continue

            fr = data.datasets.get_fr(spec_id)
            impl = data.datasets.get_impl(spec_id)
            if not fr:
                continue

            title = clean_title(fr.title)

            # Apply composable filter predicates
            if filter_engine and filter_engine.is_active and not filter_engine.matches(fr, impl):
                continue

            deps_str = self._format_deps(data, fr.deps)
            dependents_str = self._format_dependents(data, spec_id)
            raw_status = impl.status if impl else fr.status
            status_str = format_status(raw_status)
            estimate = impl.effective_loe if impl else "TBD"
            progress = (
                f"{impl.tasks_completed}/{impl.tasks_total}" if impl and impl.tasks_total else ""
            )

            spec_data.append(
                (
                    spec_id,
                    fr.priority,
                    status_str,
                    title,
                    deps_str,
                    dependents_str,
                    estimate,
                    progress,
                )
            )
            STATUS_RANK_MAP[spec_id] = STATUS_RANK.get(parse_status_text(raw_status), 99)
            seen_ids.add(spec_id)

        # Include completed specs (same as NspecTable for ungrouped "all specs" view)
        _terminal_map: dict[str, tuple[str, str]] = {
            "superseded": (DepDisplayEmoji.SUPERSEDED, "superseded"),
            "rejected": (DepDisplayEmoji.REJECTED, "rejected"),
        }
        for spec_id in sorted(data.datasets.completed_frs.keys()):
            if spec_id in seen_ids:
                continue
            fr = data.datasets.completed_frs.get(spec_id)
            if not fr:
                continue
            impl = data.datasets.completed_impls.get(spec_id)
            if filter_engine and filter_engine.is_active and not filter_engine.matches(fr, impl):
                continue
            title = clean_title(fr.title)
            status_text = parse_status_text(fr.status)
            emoji, rank_key = _terminal_map.get(
                status_text, (DepDisplayEmoji.COMPLETED, "completed")
            )
            estimate = impl.effective_loe if impl else "—"
            deps_str = self._format_deps(data, fr.deps)
            dependents_str = self._format_dependents(data, spec_id)
            spec_data.append(
                (spec_id, fr.priority, emoji, title, deps_str, dependents_str, estimate, "")
            )
            STATUS_RANK_MAP[spec_id] = STATUS_RANK.get(rank_key, 99)

        # Group by epic
        grouped: dict[str | None, list[tuple[str, str, str, str, str, str, str, str]]] = {}
        for row in spec_data:
            sid = row[0]
            eid = spec_to_epic.get(sid)
            grouped.setdefault(eid, []).append(row)

        for eid in epic_ids:
            grouped.setdefault(eid, [])
        grouped.setdefault(None, [])

        # Blocked spec IDs for sort ordering and visual dimming
        blocked_ids = data.blocked_spec_ids

        # Sort within each group, floating terminal statuses to the end
        for key in grouped:
            sorted_group = apply_sort(
                grouped[key], sort_mode, STATUS_RANK_MAP, sort_direction, blocked_ids
            )
            if sort_mode == SortMode.PICKUP:
                # PICKUP mode: preserve blocked/eligible partitioning from apply_sort;
                # only float terminal (completed) specs to the end
                grouped[key] = sorted(
                    sorted_group,
                    key=lambda r: (1 if r[2] in DISPLAY_TERMINAL_EMOJIS else 0,),
                )
            else:
                grouped[key] = sorted(
                    sorted_group,
                    key=lambda r: (
                        r[2] in DISPLAY_TERMINAL_EMOJIS,
                        STATUS_RANK_MAP.get(r[0], 99),
                    ),
                )

        # Determine panel order (unassigned first in accordion)
        epic_group_order = sort_epic_groups(
            data,
            grouped,
            epic_ids,
            sort_mode,
            sort_direction,
            STATUS_RANK_MAP,
            unassigned_first=True,
        )

        # Build panel descriptors
        panel_descs: list[
            tuple[str | None, str, list[tuple[str, str, str, str, str, str, str, str]]]
        ] = []
        for epic_id in epic_group_order:
            group_rows = grouped.get(epic_id, [])

            # Build panel title
            if epic_id:
                epic_fr = data.datasets.active_frs.get(epic_id)
                if epic_fr:
                    title = clean_title(epic_fr.title)
                    progress = calculate_epic_progress(data, epic_id)
                    panel_title = f"{epic_fr.priority} {epic_id}: {title} [{progress}]"
                else:
                    panel_title = epic_id
            else:
                panel_title = "Unassigned"

            panel_descs.append((epic_id, panel_title, group_rows))

        return self._rebuild_panels(
            panel_descs, viewport_width, view_preset, sort_mode, sort_direction, blocked_ids
        )

    def _rebuild_panels(
        self,
        panel_descs: list[
            tuple[str | None, str, list[tuple[str, str, str, str, str, str, str, str]]]
        ],
        viewport_width: int,
        view_preset: ViewPreset,
        sort_mode: SortMode,
        sort_direction: SortDirection,
        blocked_ids: set[str] | None = None,
    ) -> int:
        """Rebuild all panels from descriptors. Returns total row count."""
        _blocked = blocked_ids or set()
        scroll = self.query_one("#accordion-scroll", VerticalScroll)
        scroll.remove_children()

        tui_cfg = _load_tui_config()
        col_widths = {
            "id": tui_cfg.col_id,
            "priority": tui_cfg.col_priority,
            "status": tui_cfg.col_status,
            "progress": 5,
            "deps": tui_cfg.col_upstream,
            "dependents": tui_cfg.col_downstream,
            "estimate": tui_cfg.col_estimate,
        }
        visible_cols = view_preset.columns()
        fixed_cols_total = sum(w for k, w in col_widths.items() if k in visible_cols)
        min_title_width = tui_cfg.min_title_width

        num_columns = len(visible_cols)
        col_padding = num_columns * 2
        scrollbar_gutter = 1
        title_width = max(
            min_title_width, viewport_width - fixed_cols_total - col_padding - scrollbar_gutter
        )

        # Map sort modes to column keys for header indicators
        sort_col_map = {
            SortMode.ID: "id",
            SortMode.PICKUP: "priority",
            SortMode.PRIORITY: "priority",
            SortMode.STATUS: "status",
            SortMode.ALPHA: "title",
        }
        active_sort_col = sort_col_map.get(sort_mode)
        arrow = sort_direction.indicator if active_sort_col else ""

        column_defs = {
            "id": ("ID", col_widths["id"]),
            "priority": ("Pr", col_widths["priority"]),
            "status": ("St", col_widths["status"]),
            "title": ("Title", title_width),
            "progress": ("Prog", col_widths["progress"]),
            "deps": ("Up", col_widths["deps"]),
            "dependents": ("Dn", col_widths["dependents"]),
            "estimate": ("Est", col_widths["estimate"]),
        }

        if active_sort_col and active_sort_col in column_defs:
            label, width = column_defs[active_sort_col]
            column_defs[active_sort_col] = (f"{label}{arrow}", width)

        col_index = {
            "id": 0,
            "priority": 1,
            "status": 2,
            "title": 3,
            "deps": 4,
            "dependents": 5,
            "estimate": 6,
            "progress": 7,
        }

        def truncate_title(t: str, max_len: int) -> str:
            if len(t) <= max_len:
                return t
            return t[: max_len - 1] + "…"

        total_rows = 0
        first_panel: EpicPanel | None = None
        restore_panel: EpicPanel | None = None

        for epic_id, panel_title, group_rows in panel_descs:
            panel = EpicPanel(epic_id=epic_id, title=panel_title)

            # Restore expanded state
            state_key = epic_id or "__unassigned__"
            if state_key in self._expanded_state:
                panel.collapsed = not self._expanded_state[state_key]
            else:
                # No saved state — default to expanded
                panel.collapsed = False

            scroll.mount(panel)

            # Populate inner table
            table = panel.table
            table.clear(columns=True)

            for col_key in visible_cols:
                label, width = column_defs[col_key]
                table.add_column(label, key=col_key, width=width)

            for row in group_rows:
                spec_id = row[0]
                status_str = row[2]
                title = row[3]
                truncated = truncate_title(title, title_width)
                is_blocked = spec_id in _blocked
                if status_str in DISPLAY_TERMINAL_EMOJIS:
                    display_title = f"[dim]{truncated}[/]"
                elif status_str == "⚠️":
                    # Exception status: dim if blocked (AC-F2), bold otherwise
                    display_title = (
                        f"[dim]{truncated}[/]" if is_blocked else f"[bold]{truncated}[/]"
                    )
                elif is_blocked:
                    # Blocked specs (unmet deps, paused, etc.) are dimmed
                    display_title = f"[dim]{truncated}[/]"
                else:
                    display_title = truncated

                display_row = (
                    spec_id,
                    row[1],
                    status_str,
                    display_title,
                    row[4],
                    row[5],
                    row[6],
                    row[7],
                )
                visible_values = tuple(display_row[col_index[k]] for k in visible_cols)
                table.add_row(*visible_values, key=spec_id)
                total_rows += 1

            if first_panel is None and not panel.collapsed and table.row_count > 0:
                first_panel = panel

            # Check if the previously focused spec is in this panel
            if self._focused_spec_id:
                row_keys = [str(rk.value) for rk in table.rows]
                if self._focused_spec_id in row_keys:
                    restore_panel = panel

        # Restore focus
        if restore_panel:
            try:
                table = restore_panel.table
                table.focus()
                row_keys = [str(rk.value) for rk in table.rows]
                if self._focused_spec_id and self._focused_spec_id in row_keys:
                    idx = row_keys.index(self._focused_spec_id)
                    table.move_cursor(row=idx)
            except Exception:
                pass
        elif first_panel:
            try:
                first_panel.table.focus()
                if first_panel.table.row_count > 0:
                    first_panel.table.move_cursor(row=0)
            except Exception:
                pass

        self._focused_spec_id = None
        return total_rows

    def move_cursor_down(self) -> None:
        """Move cursor down, crossing panel boundaries."""
        focused = self.screen.focused
        if not isinstance(focused, DataTable):
            # Focus the first expanded panel
            panels = self._get_expanded_panels()
            if panels:
                panels[0].table.focus()
                if panels[0].table.row_count > 0:
                    panels[0].table.move_cursor(row=0)
            return

        table = focused
        if table.row_count == 0:
            return

        if table.cursor_row < table.row_count - 1:
            table.action_cursor_down()
        else:
            # At bottom of current table — find next expanded panel
            panels = self._get_expanded_panels()
            current_idx = None
            for i, p in enumerate(panels):
                if p.table is table:
                    current_idx = i
                    break
            if current_idx is not None and current_idx + 1 < len(panels):
                next_panel = panels[current_idx + 1]
                next_panel.table.focus()
                if next_panel.table.row_count > 0:
                    next_panel.table.move_cursor(row=0)

    def move_cursor_up(self) -> None:
        """Move cursor up, crossing panel boundaries."""
        focused = self.screen.focused
        if not isinstance(focused, DataTable):
            return

        table = focused
        if table.row_count == 0:
            return

        if table.cursor_row > 0:
            table.action_cursor_up()
        else:
            # At top of current table — find previous expanded panel
            panels = self._get_expanded_panels()
            current_idx = None
            for i, p in enumerate(panels):
                if p.table is table:
                    current_idx = i
                    break
            if current_idx is not None and current_idx > 0:
                prev_panel = panels[current_idx - 1]
                prev_panel.table.focus()
                if prev_panel.table.row_count > 0:
                    prev_panel.table.move_cursor(row=prev_panel.table.row_count - 1)

    def move_cursor_first(self) -> None:
        """Move cursor to first row of first expanded panel (gg)."""
        panels = self._get_expanded_panels()
        if panels:
            panels[0].table.focus()
            if panels[0].table.row_count > 0:
                panels[0].table.move_cursor(row=0)

    def move_cursor_last(self) -> None:
        """Move cursor to last row of last expanded panel (G)."""
        panels = self._get_expanded_panels()
        if panels:
            last = panels[-1]
            last.table.focus()
            if last.table.row_count > 0:
                last.table.move_cursor(row=last.table.row_count - 1)

    def get_focused_spec_id(self) -> str | None:
        """Read spec_id from whichever inner DataTable has focus."""
        focused = self.screen.focused
        if not isinstance(focused, DataTable):
            return None
        try:
            if focused.row_count == 0:
                return None
            row_data = focused.get_row_at(focused.cursor_row)
            if row_data:
                return str(row_data[0])
        except Exception:
            pass
        return None

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Catch Enter from any inner table and post SpecSelected."""
        if event.row_key:
            key = str(event.row_key.value)
            if key.startswith("__hdr_"):
                return
            self.post_message(self.SpecSelected(key))

    # --- Dep formatting (shared with NspecTable) ---

    def _format_deps(self, data: NspecData, deps: list[str]) -> str:
        """Format dependencies with status emoji prefix."""
        if not deps or not data.datasets:
            return ""

        def is_superseded(dep_id: str) -> bool:
            dep_fr = data.datasets.active_frs.get(dep_id) if data.datasets else None
            return dep_fr is not None and "superseded" in dep_fr.status.lower()

        filtered_deps = [d for d in deps if not is_superseded(d)]
        if not filtered_deps:
            return ""

        nspec_order = {sid: idx for idx, sid in enumerate(data.ordered_specs)}

        def dep_sort_key(dep_id: str) -> tuple[int, int, str]:
            if data.datasets and dep_id in data.datasets.completed_frs:
                return (0, 0, dep_id)
            elif dep_id in nspec_order:
                return (1, nspec_order[dep_id], dep_id)
            else:
                return (2, 9999, dep_id)

        sorted_deps = sorted(filtered_deps, key=dep_sort_key)[:2]

        def format_single_dep(dep_id: str) -> str:
            if data.datasets and dep_id in data.datasets.completed_frs:
                return f"{DepDisplayEmoji.COMPLETED}{dep_id}"
            elif data.datasets and dep_id in data.datasets.active_frs:
                dep_fr = data.datasets.active_frs[dep_id]
                if dep_fr.is_epic:
                    emoji = self._get_epic_status_emoji(data, dep_id)
                    return f"{emoji}{dep_id}"
                emoji = get_dep_display_emoji(dep_fr.status)
                return f"{emoji}{dep_id}"
            else:
                return dep_id

        formatted = [format_single_dep(dep_id) for dep_id in sorted_deps]
        result = ",".join(formatted)
        if len(filtered_deps) > 2:
            result += f" [bold]+{len(filtered_deps) - 2}[/]"
        return result

    def _format_dependents(self, data: NspecData, spec_id: str) -> str:
        """Format specs that depend on this spec."""
        dependents = data.reverse_deps.get(spec_id, [])
        if not dependents:
            return ""

        nspec_order = {sid: idx for idx, sid in enumerate(data.ordered_specs)}

        def dep_sort_key(dep_id: str) -> tuple[int, int, str]:
            if dep_id in nspec_order:
                return (0, nspec_order[dep_id], dep_id)
            else:
                return (1, 9999, dep_id)

        sorted_dependents = sorted(dependents, key=dep_sort_key)[:2]

        def format_single_dependent(dep_id: str) -> str:
            if data.datasets:
                dep_fr = data.datasets.active_frs.get(dep_id)
                if dep_fr:
                    if dep_fr.is_epic:
                        emoji = self._get_epic_status_emoji(data, dep_id)
                        return f"{emoji}{dep_id}"
                    emoji = get_dep_display_emoji(dep_fr.status)
                    return f"{emoji}{dep_id}"
            return dep_id

        formatted = [format_single_dependent(dep_id) for dep_id in sorted_dependents]
        result = ",".join(formatted)
        if len(dependents) > 2:
            result += f" [bold]+{len(dependents) - 2}[/]"
        return result

    def _get_epic_status_emoji(self, data: NspecData, epic_id: str) -> str:
        """Calculate epic status from its member specs."""
        from nspec.dao.markdown.epic_membership_dao import MarkdownEpicMembershipDAO

        if not data.datasets:
            return EpicDisplayEmoji.PROPOSED

        memberships = MarkdownEpicMembershipDAO.compute_memberships_from_datasets(data.datasets)
        members = [sid for sid, eid in memberships.items() if eid == epic_id]
        if not members:
            return EpicDisplayEmoji.PROPOSED

        has_active = False
        all_completed = True

        for sid in members:
            if sid in data.datasets.completed_frs:
                continue
            all_completed = False
            dep_fr = data.datasets.active_frs.get(sid)
            if dep_fr:
                status_text = parse_status_text(dep_fr.status)
                if status_text in ("active", "testing"):
                    has_active = True

        if all_completed and members:
            return EpicDisplayEmoji.COMPLETED
        elif has_active:
            return EpicDisplayEmoji.ACTIVE
        else:
            return EpicDisplayEmoji.PROPOSED
