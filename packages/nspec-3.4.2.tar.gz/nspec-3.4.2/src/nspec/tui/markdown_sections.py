"""Generic markdown section parser and renderer for the TUI detail view.

Parses ##-level sections from raw FR/IMPL markdown files and converts
them to Textual Rich markup for display in the detail view.
"""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class MarkdownSection:
    """A single ##-level section extracted from a markdown file."""

    heading: str  # The heading text (without the ## prefix)
    content: str  # Raw markdown content between this heading and the next
    level: int  # Heading level (2 for ##, 3 for ###, etc.)


# Sections handled by specialized renderers in detail_screen.py.
# These are identified by their ##-level heading text (case-insensitive).
# The detail view will skip these when rendering generic sections.
KNOWN_SECTIONS = frozenset(
    {
        "executive summary",
        "problem",
        "solution",
        "acceptance criteria",
        "implementation strategy",
        "tasks",
        "files modified",
        "review",
        "session notes",
        "adr / execution notes",
    }
)

# Regex for HTML comments: <!-- ... -->
_HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)

# Regex for ## headings (level 2 only)
_H2_RE = re.compile(r"^(#{2})\s+(.+)$", re.MULTILINE)


def parse_sections(content: str) -> list[MarkdownSection]:
    """Extract all ##-level sections from markdown content.

    Returns a list of MarkdownSection objects in document order.
    Only extracts level-2 headings (##). Sub-headings (###, ####)
    are included as part of their parent section's content.

    Args:
        content: Raw markdown file content.

    Returns:
        List of MarkdownSection objects.
    """
    sections: list[MarkdownSection] = []
    matches = list(_H2_RE.finditer(content))

    for i, match in enumerate(matches):
        heading = match.group(2).strip()
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(content)
        section_content = content[start:end].strip()
        sections.append(MarkdownSection(heading=heading, content=section_content, level=2))

    return sections


def is_known_section(heading: str) -> bool:
    """Check if a heading corresponds to a section with a specialized renderer.

    Args:
        heading: The section heading text.

    Returns:
        True if the section is handled by a specialized renderer.
    """
    return heading.strip().lower() in KNOWN_SECTIONS


def is_placeholder_only(content: str) -> bool:
    """Check if section content is only template placeholders / HTML comments.

    A section is considered placeholder-only if, after removing HTML comments
    and whitespace, it has no remaining visible content.

    Args:
        content: The section content to check.

    Returns:
        True if the section contains only placeholders.
    """
    stripped = _HTML_COMMENT_RE.sub("", content).strip()
    return len(stripped) == 0


def render_markdown_to_rich(content: str) -> str:
    """Convert markdown section content to Textual Rich markup.

    Handles:
    - Checkbox lists: `- [ ]` / `- [x]` / `- [~]` / `- [>]`
    - Bullet points: `- text` / `* text`
    - Bold: `**text**`
    - Italic: `*text*` / `_text_`
    - Code spans: `` `code` ``
    - ### sub-headings
    - Links: `[text](url)` → text (url)
    - HTML comments: stripped entirely
    - Tables: passed through with basic formatting

    Args:
        content: Raw markdown content (section body, not including the heading).

    Returns:
        Rich markup string suitable for Textual Static widget.
    """
    # Strip HTML comments first
    content = _HTML_COMMENT_RE.sub("", content).strip()

    if not content:
        return "[dim]No content[/]"

    lines = content.split("\n")
    result_lines: list[str] = []

    in_code_block = False

    for line in lines:
        stripped = line.strip()

        # Code blocks: pass through verbatim
        if stripped.startswith("```"):
            in_code_block = not in_code_block
            if in_code_block:
                result_lines.append("[dim]---[/]")
            else:
                result_lines.append("[dim]---[/]")
            continue

        if in_code_block:
            # Indent code block content
            result_lines.append(f"  [dim]{_escape_rich(stripped)}[/]")
            continue

        # Empty lines
        if not stripped:
            result_lines.append("")
            continue

        # Sub-headings (### and ####)
        heading_match = re.match(r"^(#{3,4})\s+(.+)$", stripped)
        if heading_match:
            heading_text = heading_match.group(2)
            result_lines.append(f"\n[bold]{heading_text}[/]")
            continue

        # Table separator rows (|---|---|)
        if re.match(r"^\|[\s\-:|]+\|$", stripped):
            continue

        # Table rows
        if stripped.startswith("|") and stripped.endswith("|"):
            cells = [c.strip() for c in stripped.strip("|").split("|")]
            formatted_cells = [_format_inline(c) for c in cells]
            result_lines.append("  " + "  |  ".join(formatted_cells))
            continue

        # Checkbox items
        checkbox_match = re.match(r"^[-*]\s+\[([ x~>])\]\s+(.+)$", stripped)
        if checkbox_match:
            marker = checkbox_match.group(1)
            text = checkbox_match.group(2)
            if marker == "x":
                result_lines.append(f"  [bold]✓[/] {_format_inline(text)}")
            elif marker == "~":
                result_lines.append(f"  [dim]~ {_format_inline(text)}[/]")
            elif marker == ">":
                result_lines.append(f"  [dim]> {_format_inline(text)}[/]")
            else:
                result_lines.append(f"  [dim]○[/] {_format_inline(text)}")
            continue

        # Bullet points
        bullet_match = re.match(r"^[-*]\s+(.+)$", stripped)
        if bullet_match:
            text = bullet_match.group(1)
            result_lines.append(f"  • {_format_inline(text)}")
            continue

        # Numbered list items
        numbered_match = re.match(r"^(\d+)[.)]\s+(.+)$", stripped)
        if numbered_match:
            num = numbered_match.group(1)
            text = numbered_match.group(2)
            result_lines.append(f"  {num}. {_format_inline(text)}")
            continue

        # Regular text
        result_lines.append(_format_inline(stripped))

    return "\n".join(result_lines)


def _escape_rich(text: str) -> str:
    """Escape Rich markup characters in plain text."""
    return text.replace("[", "\\[").replace("]", "\\]")


def _format_inline(text: str) -> str:
    """Apply inline formatting (bold, italic, code, links) to text.

    Args:
        text: Raw markdown text.

    Returns:
        Rich markup formatted text.
    """
    # Code spans first (before other formatting to avoid conflicts)
    text = re.sub(r"`([^`]+)`", r"[bold]\1[/]", text)

    # Links: [text](url) → text (url)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1 (\2)", text)

    # Bold: **text**
    text = re.sub(r"\*\*([^*]+)\*\*", r"[bold]\1[/]", text)

    # Italic: *text* (but not inside bold which we already handled)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"[italic]\1[/]", text)

    # Italic: _text_ (word boundaries)
    text = re.sub(r"\b_([^_]+)_\b", r"[italic]\1[/]", text)

    return text
