"""State management classes for the Nspec TUI.

Note: Directory paths are configurable via .novabuilt.dev/nspec/config.toml.
See nspec.paths module for configuration details.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from nspec.domain.datasets import NspecDatasets
from nspec.paths import NspecPaths, get_paths
from nspec.validation.checkers import ValidationError
from nspec.validation.validator import NspecValidator


class FollowModeState:
    """State for Claude Follow Mode - auto-tracks current spec."""

    def __init__(self, project_root: Path | None = None):
        """Initialize follow mode state."""
        self.project_root = project_root or Path(".")
        self.enabled = False
        self.current_spec_id: str | None = None
        self._last_state_mtime: float = 0.0

    @property
    def state_file(self) -> Path:
        """Path to the active session symlink."""
        from nspec.runtime.session import SessionDAO

        return SessionDAO(self.project_root).active_link

    def read_current_spec(self) -> str | None:
        """Read current spec ID from the active session."""
        try:
            from nspec.runtime.session import SessionDAO

            return SessionDAO(self.project_root).get_spec_id()
        except Exception:
            return None

    def check_for_changes(self) -> bool:
        """Check if active session symlink changed. Returns True if spec changed."""
        try:
            sf = self.state_file
            if sf.is_symlink():
                mtime = sf.lstat().st_mtime
                if mtime > self._last_state_mtime:
                    self._last_state_mtime = mtime
                    new_spec = self.read_current_spec()
                    if new_spec != self.current_spec_id:
                        self.current_spec_id = new_spec
                        return True
        except Exception:
            pass
        return False


class NspecData:
    """Container for loaded nspec data."""

    def __init__(
        self,
        docs_root: Path | None = None,
        paths_config: NspecPaths | None = None,
        project_root: Path | None = None,
    ):
        """Initialize with docs root directory.

        Args:
            docs_root: Root docs directory (default: Path("docs"))
            paths_config: Optional custom paths configuration
            project_root: Project root for finding .novabuilt.dev/nspec/config.toml (default: cwd)
        """
        if docs_root is None:
            from nspec.config import NspecConfig

            self.docs_root = NspecConfig.load(project_root).resolve_spec_root()
        else:
            self.docs_root = docs_root
        self.paths_config = paths_config
        self.project_root = project_root
        self.paths = get_paths(self.docs_root, config=paths_config, project_root=project_root)
        self.datasets: NspecDatasets | None = None
        self.ordered_specs: list[str] = []
        self.reverse_deps: dict[str, list[str]] = {}
        self.blocked_spec_ids: set[str] = set()
        self.last_load_time: datetime | None = None
        self.error: str | None = None
        self.validation_errors: list[ValidationError] = []

    def load(self) -> bool:
        """Load nspec data. Returns True on success."""
        try:
            project_root = self.project_root or self.docs_root.parent
            strict_mode = False
            try:
                from nspec.config import NspecConfig

                config = NspecConfig.load(project_root)
                strict_mode = config.validation.enforce_epic_grouping
            except Exception:
                pass

            validator = NspecValidator(
                docs_root=self.docs_root,
                strict_mode=strict_mode,
                paths_config=self.paths_config,
                project_root=project_root,
            )
            success, errors = validator.validate()

            # Always capture structured errors (includes warnings)
            self.validation_errors = getattr(validator, "structured_errors", [])

            if not success:
                self.error = f"Validation failed: {len(errors)} errors"

            # Always load datasets — validation errors are warnings, not blockers.
            # The TUI should display specs even when some have invalid status.
            if validator.datasets is not None:
                self.datasets = validator.datasets
                self.ordered_specs = validator.ordered_active_specs
            elif not success:
                return False

            # Compute blocked spec IDs for TUI visual indicators
            if self.datasets:
                from nspec.domain.ordering import compute_blocked_spec_ids

                self.blocked_spec_ids = compute_blocked_spec_ids(self.datasets)
            else:
                self.blocked_spec_ids = set()

            # Build reverse dependency map from both active and completed FRs
            # (completed specs still belong to active epics via deps)
            self.reverse_deps = {}
            if self.datasets:
                all_frs = {**self.datasets.active_frs, **self.datasets.completed_frs}
                for spec_id, fr in all_frs.items():
                    for dep_id in fr.deps:
                        if dep_id not in self.reverse_deps:
                            self.reverse_deps[dep_id] = []
                        self.reverse_deps[dep_id].append(spec_id)

            self.last_load_time = datetime.now()
            if success:
                self.error = None
            # Keep validation_errors (may contain warnings even on success)
            return True

        except ValueError as e:
            self.error = str(e)
            return False

    def get_mtime(self) -> float:
        """Get the latest modification time of FR/IMPL/completed directories."""
        latest = 0.0
        for directory in [
            self.paths.active_frs_dir,
            self.paths.active_impls_dir,
            self.paths.completed,
        ]:
            if directory.exists():
                # Check directory mtime (catches file additions/removals)
                dir_mtime = directory.stat().st_mtime
                if dir_mtime > latest:
                    latest = dir_mtime
                # Check individual file mtimes
                for path in directory.glob("**/*.md"):
                    mtime = path.stat().st_mtime
                    if mtime > latest:
                        latest = mtime
        return latest
