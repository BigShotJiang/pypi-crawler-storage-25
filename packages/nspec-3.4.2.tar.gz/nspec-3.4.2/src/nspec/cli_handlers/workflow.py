"""Session and workflow command handlers for nspec CLI.

Handles handoff, session start/log, modified files, sync, context,
next spec, loop retry, and watchdog.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from nspec.cli_handlers.crud import _normalize_spec_ref, resolve_epic
from nspec.domain.datasets import DatasetLoader
from nspec.session import (
    append_session_log,
    generate_handoff,
    get_modified_files,
    initialize_session,
    sync_spec_state,
)


def handle_next(args) -> int:
    """Find and display the next unblocked spec to work on."""
    import json as json_mod

    from nspec.domain.ordering import eligible_next_specs
    from nspec.reporting.reports import ReportContext, blockers_report

    try:
        project_root = getattr(args, "project_root", None)
        use_local = getattr(args, "local", False)
        if use_local:
            loader = DatasetLoader(docs_root=args.docs_root, project_root=project_root)
        else:
            from nspec.domain.datasets import MainDatasetLoader

            loader = MainDatasetLoader(
                docs_root=args.docs_root,
                project_root=project_root,
                fallback=True,
            )
        datasets = loader.load()
    except ValueError as e:
        print(f"Failed to load datasets: {e}", file=sys.stderr)
        return 1

    # Resolve epic filter
    epic_id = getattr(args, "epic", None)
    if epic_id:
        epic_id = resolve_epic(epic_id, args.docs_root)
        epic_fr = datasets.active_frs.get(epic_id)
        if not epic_fr:
            print(f"Epic {epic_id} not found", file=sys.stderr)
            return 1

    # Get blocked spec IDs
    ctx = ReportContext(datasets=datasets, docs_root=args.docs_root)
    blockers = blockers_report(ctx)
    blocked_ids: set[str] = set()
    for section in blockers.get("sections", []):
        if section.get("type") == "blockers":
            for b in section.get("data", []):
                blocked_ids.add(b["id"])

    candidates = eligible_next_specs(datasets, epic_id=epic_id, blocked_ids=blocked_ids)

    if not candidates:
        if getattr(args, "json_output", False):
            print(json_mod.dumps({"next": None, "message": "No unblocked specs found"}))
        else:
            print("No unblocked specs found", file=sys.stderr)
        return 1

    if getattr(args, "json_output", False):
        print(json_mod.dumps({"next": candidates[0], "alternatives": candidates[1:5]}))
    else:
        print(candidates[0]["spec_id"])

    return 0


def handle_handoff(args) -> int:
    """Generate session handoff summary."""
    if not args.id:
        print("Error: --id is required for session handoff")
        return 1

    output = generate_handoff(args.id, args.docs_root)
    print(output)
    return 0


def handle_session_start(args) -> int:
    """Initialize session context."""
    if not args.id:
        print("Error: --id is required for session start")
        return 1

    output = initialize_session(args.id, args.docs_root)
    print(output)
    return 0


def handle_session_log(args) -> int:
    """Append note to execution notes."""
    if not args.id or not args.note:
        print("Error: --id and --note are required for session log")
        return 1

    output = append_session_log(args.id, args.note, args.docs_root)
    print(output)
    return 0


def handle_modified_files(args) -> int:
    """List modified files."""
    files = get_modified_files(Path.cwd(), args.since_commit)
    for f in files:
        print(f)
    return 0


def handle_sync(args) -> int:
    """Sync spec state."""
    if not args.id:
        print("Error: --id is required for session sync")
        return 1

    output = sync_spec_state(args.id, args.docs_root, force=args.force)
    print(output)
    return 0


def handle_context(args) -> int:
    """Output LLM-friendly context for epic's dependencies."""
    from collections import defaultdict

    loader = DatasetLoader(args.docs_root, project_root=getattr(args, "project_root", None))
    datasets = loader.load()

    epic_fr = datasets.active_frs.get(args.context)
    if not epic_fr:
        print(f"Epic {args.context} not found in active nspec")
        return 1

    if not epic_fr.deps:
        print(f"Epic {args.context} has no dependencies")
        return 0

    epic_title = epic_fr.path.stem.replace(f"FR-{args.context}-", "").replace("-", " ").title()

    # Collect all incomplete deps
    incomplete: dict[str, dict] = {}
    completed: list[str] = []

    for dep_id in epic_fr.deps:
        dep_fr = datasets.active_frs.get(dep_id)
        if dep_fr:
            dep_impl = datasets.active_impls.get(dep_id)
            dep_title = dep_fr.path.stem.replace(f"FR-{dep_id}-", "").replace("-", " ")
            incomplete[dep_id] = {
                "title": dep_title,
                "fr_status": dep_fr.status,
                "impl_status": dep_impl.status if dep_impl else "N/A",
                "priority": dep_fr.priority,
                "upstream": list(dep_fr.deps) if dep_fr.deps else [],
            }
        else:
            if datasets.completed_frs.get(dep_id):
                completed.append(dep_id)

    # Build reverse dependency map
    downstream: dict[str, list[str]] = defaultdict(list)
    for spec_id, info in incomplete.items():
        for up_id in info["upstream"]:
            if up_id in incomplete:
                downstream[up_id].append(spec_id)

    # Categorize specs
    ready_to_start: list[tuple[str, str]] = []
    blocked_by_active: list[tuple[str, str, list[str]]] = []
    active_work: list[tuple[str, str]] = []

    from nspec.domain.statuses import is_status_literal_active

    for spec_id, info in incomplete.items():
        blockers = [u for u in info["upstream"] if u in incomplete]
        is_active = is_status_literal_active(info["impl_status"]) or is_status_literal_active(
            info["fr_status"]
        )
        is_hold = "Hold" in info["impl_status"] or "hold" in info["impl_status"].lower()

        if is_active and not is_hold:
            active_work.append((spec_id, info["title"]))
        elif not blockers:
            ready_to_start.append((spec_id, info["title"]))
        else:
            active_blockers = [
                b
                for b in blockers
                if incomplete.get(b, {}).get("impl_status", "").find("Active") >= 0
            ]
            if active_blockers:
                blocked_by_active.append((spec_id, info["title"], active_blockers))
            else:
                ready_to_start.append((spec_id, info["title"]))

    # Output YAML-like format
    print(f"""# LLM Context: Epic {args.context}
epic:
  id: {args.context}
  title: "{epic_title}"
  total_deps: {len(epic_fr.deps)}
  completed: {len(completed)}
  remaining: {len(incomplete)}

active_work:""")
    if active_work:
        for sid, title in sorted(active_work):
            print(f"  - {sid}: {title}")
    else:
        print("  []")

    print("\nready_to_start:")
    if ready_to_start:
        for sid, title in sorted(ready_to_start):
            print(f"  - {sid}: {title}")
    else:
        print("  []")

    print("\nblocked_by_active:")
    if blocked_by_active:
        for sid, title, blockers in sorted(blocked_by_active):
            print(f"  - {sid}: {title}")
            print(f"    blocked_by: [{', '.join(blockers)}]")
    else:
        print("  []")

    return 0


def handle_loop_retry(args) -> int:
    """Manage loop retry state."""
    import json as json_mod

    from nspec.runtime.session import LoopRetriesDAO

    project_root = getattr(args, "project_root", None) or Path.cwd()
    dao = LoopRetriesDAO(project_root)
    action = getattr(args, "retry_action", None)

    if action == "increment":
        spec_id = _normalize_spec_ref(args.id)
        exit_reason = getattr(args, "exit_reason", "") or ""
        count = dao.increment(spec_id, exit_reason)
        print(count)
        return 0
    elif action == "count":
        spec_id = _normalize_spec_ref(args.id)
        print(dao.get_count(spec_id))
        return 0
    elif action == "clear":
        spec_id = _normalize_spec_ref(args.id)
        dao.clear(spec_id)
        return 0
    elif action == "list":
        entries = dao.list_all()
        print(
            json_mod.dumps(
                {
                    k: {
                        "count": v.count,
                        "last_exit": v.last_exit,
                        "last_failure_at": v.last_failure_at,
                    }
                    for k, v in entries.items()
                },
                indent=2,
            )
        )
        return 0
    elif action == "reset":
        dao.reset()
        return 0
    else:
        print(
            "Error: specify a retry action (increment, count, clear, list, reset)", file=sys.stderr
        )
        return 1


def handle_watchdog(args) -> int:
    """Run the Claude Code stall detector & auto-recovery."""
    from nspec.config import NspecConfig
    from nspec.watchdog import Watchdog, WatchdogState

    project_root = getattr(args, "project_root", None) or Path.cwd()
    config = NspecConfig.load(project_root)
    wdg_config = config.watchdog

    # CLI args override config.toml
    if args.stall_timeout is not None:
        wdg_config.stall_timeout = args.stall_timeout
    if getattr(args, "mcp_stall_timeout", None) is not None:
        wdg_config.mcp_stall_timeout = args.mcp_stall_timeout
    if args.poll_interval is not None:
        wdg_config.poll_interval = args.poll_interval

    try:
        session = Watchdog.find_session(getattr(args, "session", None))
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    watchdog = Watchdog(session=session, config=wdg_config, state=WatchdogState())

    # Configure logging for watchdog output
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [watchdog] %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stderr,
        force=True,
    )

    watchdog.run()
    return 0
