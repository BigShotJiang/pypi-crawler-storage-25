"""Integration and system command handlers for nspec CLI.

Handles GitHub issues, Linear sync, queue management, config,
skills, init, doctor, MCP config, and statusline.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from nspec.cli_handlers.crud import _normalize_spec_ref
from nspec.mutation import create_new_spec


def handle_statusline(args) -> int:
    """Output compact status line for Claude Code integration.

    Format: E{epic} . S{spec} . [{completed}/{total}]

    Uses the same TaskParser as the TUI for consistent counts.
    """
    from nspec.domain.tasks import TaskParser
    from nspec.runtime.session import SessionDAO

    project_root = getattr(args, "project_root", None) or Path.cwd()
    agent_id = getattr(args, "agent_id", None)

    if agent_id:
        # Swarm mode: look up agent's claim from queue.json
        from nspec.orchestration.queue import QueueDAO

        queue_dao = QueueDAO(project_root)
        spec_id = queue_dao.get_agent_spec(agent_id) or "---"
        state = queue_dao.load()
        epic_id = state.epic_id if state and state.epic_id else "---"
    else:
        # Single-agent mode: read from sessions
        dao = SessionDAO(project_root)
        spec_id = dao.get_spec_id() or "---"
        epic_id = dao.get_active_epic() or "---"

    # Normalize legacy/corrupt state where an epic ID was stored in spec_id.
    if spec_id and spec_id.startswith("E"):
        if epic_id == "---":
            epic_id = spec_id
        spec_id = "---"
    if not spec_id:
        spec_id = "---"
    if not epic_id:
        epic_id = "---"

    # Get task counts using the same parser as TUI
    completed = 0
    total = 0

    if spec_id.startswith("S"):
        from nspec.paths import get_paths

        paths = get_paths(args.docs_root, project_root=getattr(args, "project_root", None))
        impl_files = list(paths.active_impls_dir.glob(f"IMPL-{spec_id}-*.md"))

        if impl_files:
            impl_path = impl_files[0]
            content = impl_path.read_text()
            parser = TaskParser()
            tasks = parser.parse(content, impl_path)

            def count_all(task_list):
                t, c = 0, 0
                for task in task_list:
                    t += 1
                    if task.completed:
                        c += 1
                    if task.children:
                        ct, cc = count_all(task.children)
                        t += ct
                        c += cc
                return t, c

            total, completed = count_all(tasks)

    # ANSI colors for terminal statusline
    cyan = "\033[36m"
    yellow = "\033[33m"
    green = "\033[32m"
    dim = "\033[2m"
    reset = "\033[0m"

    if completed == total and total > 0:
        progress_color = green
    elif completed > 0:
        progress_color = yellow
    else:
        progress_color = dim

    # Avoid double prefix (SessionDAO returns "E001", "S021" with prefix already)
    epic_display = epic_id if epic_id.startswith("E") else f"E{epic_id}"
    spec_display = spec_id if spec_id.startswith("S") else f"S{spec_id}"

    print(
        f"{cyan}{epic_display}{reset}"
        f" {dim}\u00b7{reset} "
        f"{yellow}{spec_display}{reset}"
        f" {dim}\u00b7{reset} "
        f"{progress_color}[{completed}/{total}]{reset}",
        end="",
    )
    return 0


def handle_mcp_config(args) -> int:
    """Print MCP configuration instructions."""
    from nspec.orchestration.init import generate_mcp_config

    project_root = getattr(args, "project_root", None) or Path.cwd()
    output = generate_mcp_config(project_root)
    print(output)
    return 0


def handle_doctor(args: argparse.Namespace) -> int:
    """Run project health checks."""
    from nspec.config import CONFIG_REL_PATH
    from nspec.orchestration.init import detect_stack, verify_mcp_server
    from nspec.validation.validator import NspecValidator

    docs_root_arg = getattr(args, "docs_root", None)
    if docs_root_arg:
        docs_root = docs_root_arg
    else:
        from nspec.config import NspecConfig

        docs_root = NspecConfig.load().resolve_spec_root()
    project_root = getattr(args, "project_root", None) or docs_root.parent

    passed = 0
    total = 5

    print("nspec doctor\n")

    # 1. Config file
    config_path = project_root / CONFIG_REL_PATH
    if config_path.exists():
        print("  [ok] Config file")
        passed += 1
    else:
        print("  [FAIL] Config file")
        print(f"         Expected: {config_path}")

    # 2. FR directory
    try:
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        fr_dir = docs_root / config.paths.feature_requests
    except Exception:
        fr_dir = docs_root / "frs" / "active"

    if fr_dir.is_dir():
        print("  [ok] FR directory")
        passed += 1
    else:
        print("  [FAIL] FR directory")
        print(f"         Expected: {fr_dir}")

    # 3. IMPL directory
    try:
        impl_dir = docs_root / config.paths.implementation
    except Exception:
        impl_dir = docs_root / "impls" / "active"

    if impl_dir.is_dir():
        print("  [ok] IMPL directory")
        passed += 1
    else:
        print("  [FAIL] IMPL directory")
        print(f"         Expected: {impl_dir}")

    # 4. Validation
    try:
        validator = NspecValidator(docs_root=docs_root, project_root=project_root)
        success, _errors = validator.validate()
        if success:
            print("  [ok] Validation")
            passed += 1
        else:
            print("  [FAIL] Validation")
            for err in _errors[:3]:
                print(f"         {err}")
    except Exception as e:
        print("  [FAIL] Validation")
        print(f"         {e}")

    # 5. MCP server probe
    stack = detect_stack(project_root)
    print(f"  Stack: {stack.language}/{stack.package_manager}")
    probe = verify_mcp_server(project_root, stack)
    if probe.success:
        print("  [ok] MCP server")
        passed += 1
    else:
        print("  [FAIL] MCP server")
        if probe.diagnosis:
            print(f"         {probe.diagnosis}")
        if probe.install_hint:
            print(f"         Fix: {probe.install_hint}")

    print(f"\n{passed}/{total} checks passed.")
    return 0 if passed == total else 1


def handle_issue_import(args) -> int:
    """Import a GitHub issue as an nspec spec."""
    from nspec.config import NspecConfig
    from nspec.integrations.github import (
        fetch_issue,
        issue_to_fr_content,
        map_labels_to_priority,
    )

    repo = getattr(args, "repo", None)
    number = getattr(args, "number", 0)
    epic_id_arg = getattr(args, "epic_id", None)
    priority_arg = getattr(args, "priority", None)
    dry_run = getattr(args, "dry_run", False)
    project_root = getattr(args, "project_root", None)

    # Resolve repo from config
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:
            pass
    if not repo:
        print("Error: --repo is required (or set [github].repo in config.toml)", file=sys.stderr)
        return 1

    if number <= 0:
        print("Error: --number must be a positive integer", file=sys.stderr)
        return 1

    try:
        issue = fetch_issue(repo, number)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    # Resolve priority
    try:
        config = NspecConfig.load(project_root)
        gh_config = config.github
    except Exception:
        from nspec.config import GitHubConfig

        gh_config = GitHubConfig()

    if priority_arg is None:
        priority_arg = map_labels_to_priority(
            issue.labels, gh_config.label_priority_map, gh_config.default_priority
        )

    # Fall back to config default_epic when no explicit --epic provided
    if epic_id_arg is None and gh_config.default_epic:
        epic_id_arg = gh_config.default_epic

    if dry_run:
        print(f"Issue #{issue.number}: {issue.title}")
        print(f"  State: {issue.state}")
        print(f"  Labels: {', '.join(issue.labels) or '(none)'}")
        print(f"  Mapped priority: {priority_arg}")
        print(f"  URL: {issue.url}")
        if issue.body:
            print(f"  Body preview: {issue.body[:200]}...")
        return 0

    # Create spec via crud
    try:
        from nspec.mutation import create_new_spec

        fr_path, impl_path, spec_id = create_new_spec(issue.title, priority_arg, args.docs_root)
    except Exception as e:
        print(f"Error creating spec: {e}", file=sys.stderr)
        return 1

    # Populate FR
    try:
        existing_fr = fr_path.read_text()
        updated_fr = issue_to_fr_content(issue, spec_id, priority_arg, existing_fr)
        fr_path.write_text(updated_fr)
    except Exception as e:
        print(f"Warning: FR population failed: {e}", file=sys.stderr)

    # Add to epic if specified
    if epic_id_arg:
        try:
            from nspec.mutation import move_dependency

            move_dependency(spec_id, epic_id_arg, args.docs_root)
        except Exception as e:
            print(f"Warning: failed to add to epic {epic_id_arg}: {e}", file=sys.stderr)

    print(f"Created {spec_id} from {repo}#{issue.number}")
    print(f"  Title: {issue.title}")
    print(f"  Priority: {priority_arg}")
    print(f"  FR: {fr_path}")
    print(f"  IMPL: {impl_path}")
    if epic_id_arg:
        print(f"  Epic: {epic_id_arg}")
    return 0


def handle_issue_list(args) -> int:
    """List GitHub issues with mapped priorities."""
    from nspec.config import NspecConfig
    from nspec.integrations.github import fetch_issues, map_labels_to_priority

    repo = getattr(args, "repo", None)
    state = getattr(args, "state", "open")
    label = getattr(args, "label", None)
    project_root = getattr(args, "project_root", None)

    # Resolve repo from config
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:
            pass
    if not repo:
        print("Error: --repo is required (or set [github].repo in config.toml)", file=sys.stderr)
        return 1

    # Load config for label mapping
    try:
        config = NspecConfig.load(project_root)
        gh_config = config.github
    except Exception:
        from nspec.config import GitHubConfig

        gh_config = GitHubConfig()

    try:
        issues = fetch_issues(repo, state=state, label=label)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if not issues:
        print(f"No {state} issues found in {repo}")
        return 0

    print(f"{'#':>5}  {'Priority':8}  {'State':6}  Title")
    print(f"{chr(0x2500) * 5}  {chr(0x2500) * 8}  {chr(0x2500) * 6}  {chr(0x2500) * 40}")
    for iss in issues:
        prio = map_labels_to_priority(
            iss.labels, gh_config.label_priority_map, gh_config.default_priority
        )
        print(f"{iss.number:>5}  {prio:8}  {iss.state:6}  {iss.title}")

    return 0


def handle_issue_status(args) -> int:
    """Show pipeline status of GitHub issues through the nspec lifecycle."""
    from rich.console import Console

    from nspec.config import NspecConfig
    from nspec.integrations.issue_pipeline import run_pipeline_status

    repo = getattr(args, "repo", None)
    project_root = getattr(args, "project_root", None)

    # Resolve repo from config
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:
            pass
    if not repo:
        print(
            "Error: --repo is required (or set [github].repo in config.toml, "
            "or NSPEC_GITHUB_REPO env var)",
            file=sys.stderr,
        )
        return 1

    try:
        table = run_pipeline_status(repo, args.docs_root, project_root=project_root)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    console = Console()
    console.print(table)
    return 0


def handle_tracker_audit(args) -> int:
    """Audit back-comments and status consistency for linked specs."""
    from nspec.config import NspecConfig
    from nspec.integrations.github import TrackerAuditReport, tracker_audit

    repo = getattr(args, "repo", None)
    fix = getattr(args, "fix", False)
    docs_root = getattr(args, "docs_root", None)
    project_root = getattr(args, "project_root", None) or Path.cwd()

    # Resolve docs_root
    if docs_root is None:
        try:
            config = NspecConfig.load(project_root)
            docs_root = config.resolved_docs_root(project_root)
        except Exception:
            docs_root = Path.cwd() / "docs"

    # Resolve repo from config
    if not repo:
        try:
            config = NspecConfig.load(project_root)
            repo = config.github.repo
        except Exception:
            pass
    if not repo:
        print(
            "Error: --repo is required (or set [github].repo in config.toml)",
            file=sys.stderr,
        )
        return 1

    result = tracker_audit(docs_root, repo, fix=fix, project_root=project_root)

    if isinstance(result, dict):
        print(f"Error: {result.get('error', 'unknown')}", file=sys.stderr)
        return 1

    assert isinstance(result, TrackerAuditReport)

    if result.errors:
        for err in result.errors:
            print(f"  WARN: {err}", file=sys.stderr)

    if not result.entries:
        print("No specs with github_issue: headers found.")
        return 0

    # Print table header
    print(f"{'SPEC':>8}  {'LINK':>4}  {'COMMENT':>7}  {'STATUS':>6}  {'FIXED':>5}  TITLE")
    print("-" * 80)

    inconsistencies = 0
    for entry in result.entries:
        link = "OK" if entry.link_ok else "FAIL"
        comment = "OK" if entry.back_comment_ok else "MISS"
        status = "OK" if entry.state_consistent else "DRIFT"
        fixed = "YES" if entry.fixed else ""
        title = entry.title[:40] if entry.title else ""
        print(f"{entry.spec_id:>8}  {link:>4}  {comment:>7}  {status:>6}  {fixed:>5}  {title}")

        if not entry.link_ok or not entry.back_comment_ok or not entry.state_consistent:
            inconsistencies += 1

    # Count remaining issues that --fix cannot resolve (link failures, status drift)
    unfixable = sum(
        1
        for e in result.entries
        if not e.link_ok or not e.state_consistent or (not e.back_comment_ok and not e.fixed)
    )

    print()
    print(f"Total: {len(result.entries)} specs audited, {inconsistencies} inconsistencies")
    if inconsistencies > 0 and not fix:
        print("Run with --fix to post missing back-comments.")
    elif fix and unfixable > 0:
        print(f"{unfixable} issues remain unfixable (link failures or status drift).")

    # Non-zero exit when any inconsistency remains unresolved
    return 1 if unfixable > 0 or (inconsistencies > 0 and not fix) else 0


def handle_linear_push(args) -> int:
    """Sync nspec state to Linear issues."""
    from nspec.integrations.linear import linear_push

    since_ref = getattr(args, "since", None)
    spec_id_arg = getattr(args, "spec_id", None)
    dry_run = getattr(args, "dry_run", False)

    if spec_id_arg:
        spec_id_arg = _normalize_spec_ref(spec_id_arg)

    try:
        results = linear_push(
            docs_root=args.docs_root,
            since_ref=since_ref,
            spec_id=spec_id_arg,
            dry_run=dry_run,
            project_root=getattr(args, "project_root", None),
        )
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    if not results:
        print("No linked specs to sync")
        return 0

    failures = [r for r in results if not r.success]
    if failures:
        for f in failures:
            print(f"FAILED {f.spec_id} ({f.linear_issue_id}): {f.error}", file=sys.stderr)
        return 1

    return 0


def handle_linear_bootstrap(args) -> int:
    """Print Linear config snippet with team/workflow state IDs."""
    from nspec.integrations.linear import linear_bootstrap

    try:
        output = linear_bootstrap(project_root=getattr(args, "project_root", None))
        print(output)
        return 0
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_config_get(args) -> int:
    """Read a config value by dotted key path."""
    from nspec.config import NspecConfig

    project_root = getattr(args, "project_root", None) or Path.cwd()
    config = NspecConfig.load(project_root)

    key_path = args.key
    parts = key_path.split(".", 1)
    if len(parts) != 2:
        print("Error: key must be section.field (e.g., loop.session_timeout)", file=sys.stderr)
        return 1

    value = config.get(parts[0], parts[1])
    if value is None:
        print(f"Error: unknown key '{key_path}'", file=sys.stderr)
        return 1

    print(value)
    return 0


def handle_queue(args) -> int:
    """Handle queue subcommands."""
    import json as _json

    from nspec.orchestration.queue import QueueDAO

    docs_root = args.docs_root
    project_root = args.project_root
    dao = QueueDAO(project_root)

    action = getattr(args, "queue_action", None)
    if not action:
        print(
            "Error: specify a queue action (init, status, claim, release, drain)", file=sys.stderr
        )
        return 1

    if action == "init":
        epic_id = getattr(args, "epic_id", None)
        max_agents = getattr(args, "max_agents", 5)
        lease_ttl = getattr(args, "lease_ttl", 300)
        from nspec.config import NspecConfig

        config = NspecConfig.load(project_root)
        if config.queue.mode == "single":
            max_agents = 1
        state = dao.initialize_from_backlog(
            docs_root, epic_id=epic_id, max_agents=max_agents, lease_ttl=lease_ttl
        )
        print(f"Queue initialized: {len(state.entries)} specs")
        print(f"  Epic: {state.epic_id or 'all'}")
        print(f"  Max agents: {state.max_agents}")
        print(f"  Lease TTL: {state.lease_ttl_seconds}s")
        for e in state.entries:
            print(f"  - {e.spec_id}: {e.title} ({e.priority})")
        return 0

    if action == "status":
        result = dao.status()
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        print(_json.dumps(result, indent=2))
        return 0

    if action == "claim":
        agent_id = getattr(args, "agent_id", None)
        if not agent_id:
            print("Error: --agent-id required for claim", file=sys.stderr)
            return 1
        result = dao.claim(agent_id)
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        print(f"Claimed: {result['spec_id']} ({result['title']})")
        print(f"  Agent: {result['agent_id']}")
        print(f"  Lease expires: {result['lease_expires']}")
        return 0

    if action == "release":
        agent_id = getattr(args, "agent_id", None)
        spec_id = getattr(args, "spec_id", None)
        if not agent_id or not spec_id:
            print("Error: --agent-id and --spec-id required for release", file=sys.stderr)
            return 1
        reason = getattr(args, "reason", None)
        completed = getattr(args, "completed", False)
        result = dao.release(agent_id, spec_id, reason=reason, completed=completed)
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        status = "completed" if result.get("completed") else "released"
        print(f"Spec {spec_id} {status} by {agent_id}")
        return 0

    if action == "drain":
        result = dao.status()
        if "error" in result:
            print(f"Error: {result['error']}", file=sys.stderr)
            return 1
        print(f"Active agents: {result['active_agents']}")
        print(f"Specs remaining: {result['specs_remaining']}")
        print(f"Specs completed: {result['specs_completed']}")
        return 0

    print(f"Unknown queue action: {action}", file=sys.stderr)
    return 1


def handle_init(args: argparse.Namespace) -> int:
    """Initialize a new nspec project."""
    from nspec.orchestration.init import detect_stack, interactive_init, scaffold_project

    project_root = Path.cwd()
    docs_root = getattr(args, "docs_root", None) or project_root / "docs"

    stack = detect_stack(project_root)
    ci_override = getattr(args, "ci", None)
    force = getattr(args, "force", False)

    print(f"Detected stack: {stack.language}/{stack.package_manager}")
    if stack.ci_platform != "none":
        print(f"Detected CI: {stack.ci_platform}")

    # Interactive path selection
    config = interactive_init(project_root, interactive=True)

    try:
        created = scaffold_project(
            project_root=project_root,
            docs_root=docs_root,
            stack=stack,
            ci_platform_override=ci_override,
            force=force,
            config=config,
        )
    except FileExistsError as e:
        print(f"Error: {e}")
        return 1

    # Create default epic if none exists (match MCP init behavior)
    from nspec.config import NspecConfig

    config = NspecConfig.load(project_root)
    fr_dir = docs_root / config.paths.feature_requests
    existing_epics = list(fr_dir.glob("FR-E*-*.md")) if fr_dir.exists() else []

    if not existing_epics:
        try:
            fr_path, impl_path, epic_id = create_new_spec(
                "Default Epic", "P2", docs_root, is_epic=True
            )
            created.extend([fr_path, impl_path])
            epic_num = epic_id[1:] if epic_id.startswith("E") else epic_id
            config.defaults.epic = epic_num
            config.save()
            print(f"Created default epic: {epic_id}")
        except Exception as e:
            print(f"Error: Failed to create default epic: {e}")
            return 1

    print(f"\nCreated {len(created)} files/directories:")
    for p in created:
        if p.is_file():
            try:
                rel = p.relative_to(project_root)
            except ValueError:
                rel = p
            print(f"  {rel}")

    # Post-init MCP health probe
    from nspec.orchestration.init import verify_mcp_server

    print("\nVerifying MCP server...")
    probe = verify_mcp_server(project_root, stack)
    if probe.success:
        print("  MCP server: ok")
    else:
        print("  MCP server: FAILED")
        if probe.diagnosis:
            print(f"    {probe.diagnosis}")
        if probe.install_hint:
            print(f"    Fix: {probe.install_hint}")
        print("  Run 'nspec doctor' for full diagnostics.")

    print("\nNext steps:")
    print("  1. Review .novabuilt.dev/nspec/config.toml and adjust paths if needed")
    print("  2. Add 'include nspec.mk' to your Makefile")
    print("  3. Create your first spec: nspec spec create --title 'My Feature'")
    return 0


def handle_skills_sync(args: argparse.Namespace) -> int:
    """Install skills and sync symlinks to agent directories."""
    from nspec.config import NspecConfig
    from nspec.skills import install_skills, resolve_skills, sync_to_agents

    project_root = getattr(args, "project_root", None) or Path.cwd()
    force = getattr(args, "force", False)

    config = NspecConfig.load(project_root)
    resolved = resolve_skills(config.skills.sources, project_root)
    written = install_skills(project_root, resolved, force=force)
    synced = sync_to_agents(project_root, config.skills.targets)

    print(f"{len(written)} skill(s) installed, {len(synced)} symlink(s) synced")
    return 0


def handle_skills_list(args: argparse.Namespace) -> int:
    """List available skills."""
    from nspec.config import NspecConfig
    from nspec.skills import resolve_skills

    project_root = getattr(args, "project_root", None) or Path.cwd()

    config = NspecConfig.load(project_root)
    resolved = resolve_skills(config.skills.sources, project_root)

    if not resolved:
        print("No skills found.")
        return 0

    # Print table header
    print(f"{'Name':<30} {'Source':<15} {'Target':<10}")
    print(f"{'-' * 30} {'-' * 15} {'-' * 10}")
    for info in resolved.values():
        print(f"{info.name:<30} {info.source:<15} {info.target:<10}")

    print(f"\n{len(resolved)} skill(s) available")
    return 0


# Expected guard hooks installed by nspec (S910). Each entry is the hook
# script path relative to the project root and the matchers it should be
# registered against in .claude/settings.json under PreToolUse.
_EXPECTED_HOOKS: tuple[tuple[str, tuple[str, ...]], ...] = (
    (".claude/hooks/guard-spec-writes.sh", ("Edit", "Write")),
    (".claude/hooks/guard-credentials.sh", ("Read", "Bash")),
    (".claude/hooks/guard-destructive.sh", ("Bash",)),
)


def handle_hooks_doctor(args: argparse.Namespace) -> int:
    """Verify nspec policy hooks are installed, executable, and registered.

    Per S910: lists every expected hook and confirms (a) the script file
    exists, (b) it is executable, (c) it is registered in
    `.claude/settings.json` under `PreToolUse` with at least one matcher
    that covers the expected events. Exits non-zero if anything is
    missing so this can run in CI.
    """
    import json

    project_root = getattr(args, "project_root", None) or Path.cwd()
    project_root = Path(project_root)

    settings_path = project_root / ".claude" / "settings.json"
    settings: dict = {}
    settings_ok = False
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
            settings_ok = True
        except json.JSONDecodeError as e:
            print(f"  [FAIL] .claude/settings.json: invalid JSON ({e})")
    else:
        print(f"  [FAIL] .claude/settings.json: missing at {settings_path}")

    pretooluse = []
    if settings_ok:
        hooks_section = settings.get("hooks", {}) or {}
        pretooluse_raw = hooks_section.get("PreToolUse", []) or []
        if isinstance(pretooluse_raw, list):
            pretooluse = pretooluse_raw

    print("nspec hooks doctor\n")
    failures = 0

    for rel_path, expected_matchers in _EXPECTED_HOOKS:
        script_path = project_root / rel_path
        problems: list[str] = []

        if not script_path.exists():
            problems.append("script missing")
        else:
            try:
                if not script_path.stat().st_mode & 0o111:
                    problems.append("not executable")
            except OSError as e:  # pragma: no cover - filesystem oddity
                problems.append(f"stat failed: {e}")

        # Registration: find a PreToolUse entry whose matcher covers the
        # expected events and whose hooks reference this script path.
        if settings_ok:
            registered_matchers: set[str] = set()
            for entry in pretooluse:
                if not isinstance(entry, dict):
                    continue
                matcher = str(entry.get("matcher", ""))
                hooks_list = entry.get("hooks", []) or []
                referenced = any(
                    isinstance(h, dict) and rel_path in str(h.get("command", ""))
                    for h in hooks_list
                )
                if not referenced:
                    continue
                # matcher is a regex-ish "Edit|Write" string; tokenize on '|'
                for tok in matcher.split("|"):
                    tok = tok.strip()
                    if tok:
                        registered_matchers.add(tok)
            missing = [m for m in expected_matchers if m not in registered_matchers]
            if missing:
                problems.append(
                    "not registered for: " + ", ".join(missing)
                    if registered_matchers
                    else "not registered in PreToolUse"
                )
        else:
            problems.append("settings.json unreadable")

        if problems:
            failures += 1
            print(f"  [FAIL] {rel_path}")
            for p in problems:
                print(f"         {p}")
        else:
            print(f"  [ok]   {rel_path}  (matchers: {', '.join(expected_matchers)})")

    print()
    if failures or not settings_ok:
        total = len(_EXPECTED_HOOKS)
        ok = total - failures
        print(f"FAILED: {failures} hook(s) need attention ({ok}/{total} OK)", file=sys.stderr)
        return 1
    print(f"OK: {len(_EXPECTED_HOOKS)} hook(s) installed and registered")
    return 0
