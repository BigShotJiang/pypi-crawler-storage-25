"""Command-line interface for nspec management.

This module provides the CLI entry point. Command handlers are organized in:
- cli_handlers.crud: CRUD operations (create, delete, complete, deps, priority)
- cli_handlers.workflow: Session, context, next spec, loop retry, watchdog
- cli_handlers.reporting: Validation, dashboard, stats, progress, audit
- cli_handlers.integrations: GitHub issues, Linear, queue, init, doctor, skills

Note: Directory paths are configurable via .novabuilt.dev/nspec/config.toml.
See nspec.paths module for configuration details.
"""

import argparse
import logging
import os
import sys
from importlib.metadata import version as _pkg_version
from pathlib import Path

# Import all handlers from the cli_handlers package
from nspec.cli_handlers import (  # noqa: F401
    _normalize_spec_ref,
    _resolve_strict_mode,
    handle_add_dep,
    handle_audit,
    handle_audit_trail,
    handle_check_criteria,
    handle_check_task,
    handle_complete,
    handle_config_get,
    handle_context,
    handle_context_audit,
    handle_create_adr,
    handle_create_new,
    handle_dashboard,
    handle_delete,
    handle_dep_clean,
    handle_deps,
    handle_doctor,
    handle_finalize,
    handle_generate,
    handle_handoff,
    handle_hooks_doctor,
    handle_init,
    handle_issue_import,
    handle_issue_list,
    handle_issue_status,
    handle_linear_bootstrap,
    handle_linear_push,
    handle_list_adrs,
    handle_loop_retry,
    handle_mcp_config,
    handle_modified_files,
    handle_move_dep,
    handle_next,
    handle_next_status,
    handle_progress,
    handle_queue,
    handle_reject,
    handle_remove_dep,
    handle_repair_collisions,
    handle_review_finalize,
    handle_session_log,
    handle_session_start,
    handle_set_loe,
    handle_set_priority,
    handle_set_status,
    handle_skills_list,
    handle_skills_sync,
    handle_stats,
    handle_statusline,
    handle_supersede,
    handle_sync,
    handle_tracker_audit,
    handle_validate,
    handle_validate_criteria,
    handle_validate_main,
    handle_watchdog,
    resolve_epic,
    run_validation_check,
    validate_epic_exists,
)
from nspec.domain.statuses import print_status_codes


def _get_version() -> str:
    """Return installed nspec version from package metadata."""
    try:
        return _pkg_version("nspec")
    except Exception:
        return "unknown"


logger = logging.getLogger("nspec")


# ======================================================================
# Parser helpers
# ======================================================================


def _add_common_args(sub: argparse.ArgumentParser) -> None:
    """Add common arguments shared across subcommand parsers.

    --docs-root and --project-root are hidden (resolved from config.toml
    ``[paths].spec_root`` by default). Kept for internal/test use.
    """
    sub.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    sub.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)


def _add_id_arg(sub: argparse.ArgumentParser) -> None:
    """Add --id argument to a subparser."""
    sub.add_argument("--id", type=str, required=True, help="Spec ID")


def _add_force_arg(sub: argparse.ArgumentParser) -> None:
    """Add --force argument to a subparser."""
    sub.add_argument("--force", action="store_true", help="Skip safety checks")


# ======================================================================
# Adapter functions (thin wrappers that map subcommand args to handlers)
# ======================================================================


def _handle_status_codes(args) -> int:  # noqa: ARG001
    """Adapter for 'nspec status-codes' subcommand."""
    print_status_codes()
    return 0


def _handle_tui_subcommand(args) -> int:
    """Adapter for 'nspec tui' subcommand."""
    from nspec.tui import main as tui_main

    tui_main(docs_root=args.docs_root, project_root=args.project_root)
    return 0


def _handle_ngtui_subcommand(args) -> int:
    """Adapter for 'nspec ngtui' subcommand — accordion panels."""
    from nspec.tui import main as tui_main

    tui_main(docs_root=args.docs_root, project_root=args.project_root, use_accordion=True)
    return 0


def _handle_spec_progress(args) -> int:
    """Adapter for 'nspec spec progress' — maps --id to args.progress."""
    args.progress = args.id if args.id else "__summary__"
    return handle_progress(args)


def _handle_spec_deps(args) -> int:
    """Adapter for 'nspec spec deps' — maps --id to args.deps."""
    args.deps = args.id
    return handle_deps(args)


def _handle_spec_context(args) -> int:
    """Adapter for 'nspec spec context' — maps --id to args.context."""
    args.context = args.id
    return handle_context(args)


def _handle_tests_list(args) -> int:
    """Handle 'nspec tests --id <spec_id>' — list test files."""
    from nspec.domain.tasks import list_spec_test_files

    docs_root = Path(args.docs_root) if args.docs_root else None
    project_root = Path(args.project_root) if args.project_root else None

    try:
        files = list_spec_test_files(args.id, docs_root, project_root)
    except FileNotFoundError as e:
        print(str(e), file=sys.stderr)
        return 1

    if files:
        for f in files:
            print(f)
    else:
        print("No test files registered.", file=sys.stderr)
    return 0


def _handle_tests_add(args) -> int:
    """Handle 'nspec tests add --id <spec_id> <files...>' — add test files."""
    from nspec.domain.tasks import add_spec_test_files

    docs_root = Path(args.docs_root) if args.docs_root else None
    project_root = Path(args.project_root) if args.project_root else None

    try:
        result = add_spec_test_files(args.id, args.files, docs_root, project_root)
    except (FileNotFoundError, ValueError) as e:
        print(str(e), file=sys.stderr)
        return 1

    for w in result.get("warnings", []):
        print(f"Warning: {w}", file=sys.stderr)

    added = result.get("added", [])
    if added:
        print(f"Added {len(added)} test file(s): {', '.join(added)}")
    else:
        print("No new files added (all already present).")
    return 0


def _handle_tests_remove(args) -> int:
    """Handle 'nspec tests remove --id <spec_id> <files...>' — remove test files."""
    from nspec.domain.tasks import remove_spec_test_files

    docs_root = Path(args.docs_root) if args.docs_root else None
    project_root = Path(args.project_root) if args.project_root else None

    try:
        result = remove_spec_test_files(args.id, args.files, docs_root, project_root)
    except (FileNotFoundError, ValueError) as e:
        print(str(e), file=sys.stderr)
        return 1

    for w in result.get("warnings", []):
        print(f"Warning: {w}", file=sys.stderr)

    removed = result.get("removed", [])
    if removed:
        print(f"Removed {len(removed)} test file(s): {', '.join(removed)}")
    else:
        print("No files removed.")
    return 0


# ======================================================================
# Argument parser
# ======================================================================


def build_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(
        description="Nspec management - validation, generation, and CRUD operations"
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"nspec {_get_version()}",
    )
    parser.add_argument(
        "--tui", action="store_true", help="Launch interactive TUI (shorthand for 'nspec tui')"
    )

    # Subcommands
    subparsers = parser.add_subparsers(dest="command")
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize a new nspec project",
        description=(
            "Scaffold a new nspec project with docs structure, config, CLAUDE.md,\n"
            "and optional CI. The scaffolded CLAUDE.md contains nspec-aware dev\n"
            "process instructions (progress tracking, MCP tool reference, quality\n"
            "gates, commit format) with template variables interpolated from config.\n"
            "\n"
            "Overwrite rules for CLAUDE.md:\n"
            "  - New files are always created.\n"
            "  - Existing CLAUDE.md without '<!-- managed-by: nspec -->' is never\n"
            "    overwritten (user customizations are preserved).\n"
            "  - With --force, managed CLAUDE.md is updated; other init files\n"
            "    (config.toml, nspec.mk, CI, .mcp.json) are always overwritten."
        ),
        epilog=("Examples:\n  nspec init\n  nspec init --ci github\n  nspec init --force"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    init_parser.add_argument(
        "--ci",
        type=str,
        choices=["github", "cloudbuild", "gitlab", "none"],
        default=None,
        help="CI platform (auto-detected if not specified)",
    )
    init_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files (CLAUDE.md only when managed-by header is present)",
    )
    init_parser.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)

    # -------------------------------------------------------------------------
    # Top-level subcommands
    # -------------------------------------------------------------------------

    # nspec tui
    tui_sub = subparsers.add_parser(
        "tui",
        help="Launch interactive TUI",
        description="Launch the interactive terminal UI for browsing and managing specs.",
        epilog="Examples:\n  nspec tui",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(tui_sub)
    tui_sub.set_defaults(handler=lambda args: _handle_tui_subcommand(args))

    # nspec ngtui
    ngtui_sub = subparsers.add_parser(
        "ngtui",
        help="Launch next-gen TUI with accordion panels",
        description="Launch the next-gen terminal UI with collapsible epic accordion panels.",
        epilog="Examples:\n  nspec ngtui",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(ngtui_sub)
    ngtui_sub.set_defaults(handler=lambda args: _handle_ngtui_subcommand(args))

    # nspec statusline
    statusline_sub = subparsers.add_parser(
        "statusline",
        help="Output compact status line for Claude Code",
        description="Output a compact one-line status summary for Claude Code integration.",
        epilog="Examples:\n  nspec statusline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(statusline_sub)
    statusline_sub.add_argument(
        "--agent-id",
        help="Show spec claimed by this agent from queue.json (swarm mode)",
    )
    statusline_sub.set_defaults(handler=handle_statusline)

    # nspec next
    next_sub = subparsers.add_parser(
        "next",
        help="Show next unblocked spec to work on",
        description="Find the highest-priority unblocked spec, optionally filtered to an epic.",
        epilog=("Examples:\n  nspec next\n  nspec next --epic E001\n  nspec next --json"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(next_sub)
    next_sub.add_argument("--epic", type=str, help="Filter to a specific epic")
    next_sub.add_argument(
        "--json", action="store_true", dest="json_output", help="Output structured JSON"
    )
    next_sub.add_argument(
        "--local", action="store_true", help="Use local filesystem instead of main branch"
    )
    next_sub.set_defaults(handler=handle_next)

    # nspec generate
    generate_sub = subparsers.add_parser(
        "generate",
        help="Generate NSPEC.md",
        description="Generate NSPEC.md from validated FR and IMPL documents.",
        epilog="Examples:\n  nspec generate",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(generate_sub)
    generate_sub.set_defaults(handler=handle_generate)

    # nspec dashboard
    dashboard_sub = subparsers.add_parser(
        "dashboard",
        help="Generate + stats combined",
        description="Generate NSPEC.md and display engineering metrics in one command.",
        epilog=(
            "Examples:\n"
            "  nspec dashboard\n"
            "  nspec dashboard --epic E001\n"
            "  nspec dashboard --verbose-status"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(dashboard_sub)
    dashboard_sub.add_argument("--verbose-status", action="store_true", help="Full status text")
    dashboard_sub.add_argument("--epic", type=str, help="Filter by epic ID")
    dashboard_sub.set_defaults(handler=handle_dashboard)

    # nspec stats
    stats_sub = subparsers.add_parser(
        "stats",
        help="Show engineering metrics",
        description="Display engineering metrics: completion rates, velocity, and burndown.",
        epilog="Examples:\n  nspec stats",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(stats_sub)
    stats_sub.add_argument(
        "--format",
        choices=["text", "json", "yaml"],
        default="text",
        help="Output format (default: text)",
    )
    stats_sub.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Write output to file instead of stdout",
    )
    stats_sub.set_defaults(handler=handle_stats)

    # -------------------------------------------------------------------------
    # nspec review <cmd>
    # -------------------------------------------------------------------------
    review_sub = subparsers.add_parser(
        "review",
        help="Review packet workflow",
        description=(
            "Helpers for creating and finalizing per-spec review packets (evidence + archive)."
        ),
        epilog=(
            "Examples:\n"
            "  nspec review finalize --id S033\n"
            "  nspec review finalize --id S034 --date 2026-02-04"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    review_subs = review_sub.add_subparsers(dest="review_command")

    review_finalize = review_subs.add_parser(
        "finalize",
        help="Archive + mark done + complete review spec",
        description=(
            "Archive the target review packet, mark tasks/ACs, and complete the review spec."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(review_finalize)
    _add_id_arg(review_finalize)
    review_finalize.add_argument(
        "--date",
        type=str,
        default=None,
        help="Archive date (YYYY-MM-DD). Default: today.",
    )
    review_finalize.set_defaults(handler=handle_review_finalize)

    # -------------------------------------------------------------------------
    # nspec validate [criteria]
    # -------------------------------------------------------------------------
    validate_sub = subparsers.add_parser(
        "validate",
        help="Run validation",
        description="Run the 6-layer validation engine on all FR and IMPL documents.",
        epilog=(
            "Examples:\n"
            "  nspec validate\n"
            "  nspec validate\n"
            "  nspec validate criteria --id S002 --strict"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(validate_sub)
    validate_sub.set_defaults(handler=handle_validate)

    validate_subs = validate_sub.add_subparsers(dest="validate_command")

    validate_main_sub = validate_subs.add_parser(
        "main",
        help="Validate main branch integrity",
        description="Load datasets from main branch and run integrity checks.",
    )
    _add_common_args(validate_main_sub)
    validate_main_sub.set_defaults(handler=handle_validate_main)

    validate_criteria_sub = validate_subs.add_parser(
        "criteria", help="Validate acceptance criteria"
    )
    _add_common_args(validate_criteria_sub)
    _add_id_arg(validate_criteria_sub)
    validate_criteria_sub.add_argument("--strict", action="store_true", help="Strict validation")
    validate_criteria_sub.set_defaults(handler=handle_validate_criteria)

    # -------------------------------------------------------------------------
    # nspec spec <cmd>
    # -------------------------------------------------------------------------
    spec_sub = subparsers.add_parser(
        "spec",
        help="Spec CRUD operations",
        description="Create, delete, complete, and manage spec lifecycle.",
        epilog=(
            "Examples:\n"
            "  nspec spec create --title 'Add search' --priority P1\n"
            "  nspec spec complete --id S003\n"
            "  nspec spec progress --id S002"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    spec_subs = spec_sub.add_subparsers(dest="spec_command")

    # nspec spec create
    spec_create = spec_subs.add_parser("create", help="Create new FR+IMPL spec")
    _add_common_args(spec_create)
    spec_create.add_argument("--title", type=str, required=True, help="Spec title")
    spec_create.add_argument("--priority", type=str, default=None, help="Priority level")
    spec_create.add_argument("--epic", type=str, help="Target epic ID")
    spec_create.add_argument(
        "--type",
        type=str,
        choices=["spec", "epic"],
        default="spec",
        help="Create a spec (default) or an epic",
    )
    spec_create.add_argument(
        "--set-default",
        action="store_true",
        help="Set the created epic as the default in config (only valid with --type epic)",
    )
    spec_create.set_defaults(handler=handle_create_new)

    # nspec spec delete
    spec_delete = spec_subs.add_parser("delete", help="Delete FR+IMPL spec")
    _add_common_args(spec_delete)
    _add_id_arg(spec_delete)
    _add_force_arg(spec_delete)
    spec_delete.set_defaults(handler=handle_delete)

    # nspec spec complete
    spec_complete = spec_subs.add_parser("complete", help="Archive spec as completed")
    _add_common_args(spec_complete)
    _add_id_arg(spec_complete)
    spec_complete.set_defaults(handler=handle_complete)

    # nspec spec supersede
    spec_supersede = spec_subs.add_parser("supersede", help="Archive spec as superseded")
    _add_common_args(spec_supersede)
    _add_id_arg(spec_supersede)
    spec_supersede.add_argument("--by", help="Spec/epic ID that supersedes this one (e.g., E002)")
    spec_supersede.set_defaults(handler=handle_supersede)

    # nspec spec reject
    spec_reject = spec_subs.add_parser("reject", help="Archive spec as rejected")
    _add_common_args(spec_reject)
    _add_id_arg(spec_reject)
    _add_force_arg(spec_reject)
    spec_reject.set_defaults(handler=handle_reject)

    # nspec spec finalize
    spec_finalize = spec_subs.add_parser("finalize", help="Show spec completion status")
    _add_common_args(spec_finalize)
    _add_id_arg(spec_finalize)
    spec_finalize.add_argument("--execute", action="store_true", help="Execute finalization")
    spec_finalize.set_defaults(handler=handle_finalize)

    # nspec spec progress
    spec_progress = spec_subs.add_parser("progress", help="Show task/AC progress")
    _add_common_args(spec_progress)
    spec_progress.add_argument("--id", type=str, help="Spec ID (omit for summary)")
    spec_progress.add_argument("--all", action="store_true", help="Show all specs")
    spec_progress.set_defaults(handler=_handle_spec_progress)

    # nspec spec deps
    spec_deps = spec_subs.add_parser("deps", help="List dependencies")
    _add_common_args(spec_deps)
    _add_id_arg(spec_deps)
    spec_deps.set_defaults(handler=_handle_spec_deps)

    # nspec spec context
    spec_context = spec_subs.add_parser("context", help="LLM context for epic")
    _add_common_args(spec_context)
    _add_id_arg(spec_context)
    spec_context.set_defaults(handler=_handle_spec_context)

    # -------------------------------------------------------------------------
    # nspec tests <cmd>
    # -------------------------------------------------------------------------
    tests_sub = subparsers.add_parser(
        "tests",
        help="Manage test file associations",
        description="List, add, or remove test file entries in IMPL ### Test Files section.",
        epilog=(
            "Examples:\n"
            "  nspec tests --id S220             # List test files\n"
            "  nspec tests add --id S220 tests/test_foo.py\n"
            "  nspec tests remove --id S220 tests/test_old.py"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(tests_sub)
    _add_id_arg(tests_sub)
    tests_sub.set_defaults(handler=_handle_tests_list)
    tests_subs = tests_sub.add_subparsers(dest="tests_command")

    # nspec tests add
    tests_add = tests_subs.add_parser("add", help="Add test file entries")
    _add_common_args(tests_add)
    _add_id_arg(tests_add)
    tests_add.add_argument("files", nargs="+", help="Test file paths to add")
    tests_add.set_defaults(handler=_handle_tests_add)

    # nspec tests remove
    tests_remove = tests_subs.add_parser("remove", help="Remove test file entries")
    _add_common_args(tests_remove)
    _add_id_arg(tests_remove)
    tests_remove.add_argument("files", nargs="+", help="Test file paths to remove")
    tests_remove.set_defaults(handler=_handle_tests_remove)

    # -------------------------------------------------------------------------
    # nspec hooks <cmd>  (S910 — policy-as-code)
    # -------------------------------------------------------------------------
    hooks_sub = subparsers.add_parser(
        "hooks",
        help="Inspect and verify Claude Code hooks (policy-as-code)",
        description=(
            "Manage and verify the Claude Code policy hooks (guard-credentials, "
            "guard-destructive, guard-spec-writes) installed by nspec.\n"
            "\n"
            "Run `nspec hooks doctor` to confirm every expected hook is "
            "installed, executable, and registered in .claude/settings.json. "
            "Exits non-zero if anything is missing — safe to wire into CI."
        ),
        epilog="Examples:\n  nspec hooks doctor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    hooks_subs = hooks_sub.add_subparsers(dest="hooks_command")

    hooks_doctor_sub = hooks_subs.add_parser(
        "doctor",
        help="Verify policy hooks are installed and registered",
        description=(
            "Lists every hook nspec expects to find under .claude/hooks/, "
            "checks the script exists and is executable, and confirms it is "
            "registered in .claude/settings.json under the right PreToolUse "
            "matcher. Exits 1 on any failure."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(hooks_doctor_sub)
    hooks_doctor_sub.set_defaults(handler=handle_hooks_doctor)

    # -------------------------------------------------------------------------
    # nspec repair-collisions
    # -------------------------------------------------------------------------
    repair_sub = subparsers.add_parser(
        "repair-collisions",
        help="Detect and resolve cross-directory spec ID collisions (S909)",
        description=(
            "Find spec IDs that appear in multiple directories (active, "
            "completed/done, completed/superseded) and offer per-collision "
            "resolution. Run with --dry-run first to preview the collision "
            "set without modifying anything.\n"
            "\n"
            "Modes:\n"
            "  --mode rename-completed  Append '-RETIRED-{ts}' to archived files.\n"
            "  --mode rename-active     Renumber the active file to next free ID.\n"
            "  --mode delete-completed  Delete archived files (requires --force).\n"
        ),
        epilog=(
            "Examples:\n"
            "  nspec repair-collisions --dry-run\n"
            "  nspec repair-collisions --mode rename-completed\n"
            "  nspec repair-collisions --mode delete-completed --force"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(repair_sub)
    repair_sub.add_argument(
        "--dry-run",
        action="store_true",
        help="List collisions without modifying any files",
    )
    repair_sub.add_argument(
        "--mode",
        choices=["rename-completed", "rename-active", "delete-completed"],
        help="Resolution mode applied to every detected collision",
    )
    repair_sub.add_argument(
        "--force",
        action="store_true",
        help="Required for --mode delete-completed (destructive)",
    )
    repair_sub.set_defaults(handler=handle_repair_collisions)

    # -------------------------------------------------------------------------
    # nspec dep <cmd>
    # -------------------------------------------------------------------------
    dep_sub = subparsers.add_parser(
        "dep",
        help="Dependency operations",
        description="Add, remove, and move dependencies between specs and epics.",
        epilog=(
            "Examples:\n"
            "  nspec dep add --to E001 --dep S003\n"
            "  nspec dep remove --to E001 --dep S003\n"
            "  nspec dep move --to E001 --dep S005\n"
            "  nspec dep clean\n"
            "  nspec dep clean --dry-run"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    dep_subs = dep_sub.add_subparsers(dest="dep_command")

    # nspec dep add
    dep_add = dep_subs.add_parser("add", help="Add dependency")
    _add_common_args(dep_add)
    dep_add.add_argument("--to", type=str, required=True, help="Target spec/epic ID")
    dep_add.add_argument("--dep", type=str, required=True, help="Dependency ID")
    dep_add.set_defaults(handler=handle_add_dep)

    # nspec dep remove
    dep_remove = dep_subs.add_parser("remove", help="Remove dependency")
    _add_common_args(dep_remove)
    dep_remove.add_argument("--to", type=str, required=True, help="Target spec/epic ID")
    dep_remove.add_argument("--dep", type=str, required=True, help="Dependency ID")
    dep_remove.set_defaults(handler=handle_remove_dep)

    # nspec dep move
    dep_move = dep_subs.add_parser("move", help="Move spec to epic")
    _add_common_args(dep_move)
    dep_move.add_argument("--to", type=str, required=True, help="Target epic ID")
    dep_move.add_argument("--dep", type=str, required=True, help="Spec ID to move")
    dep_move.set_defaults(handler=handle_move_dep)

    # nspec dep clean
    dep_clean = dep_subs.add_parser("clean", help="Remove dangling dependency references")
    _add_common_args(dep_clean)
    dep_clean.add_argument("--dry-run", action="store_true", help="Show changes without writing")
    dep_clean.set_defaults(handler=handle_dep_clean)

    # -------------------------------------------------------------------------
    # nspec task <cmd>
    # -------------------------------------------------------------------------
    task_sub = subparsers.add_parser(
        "task",
        help="Task and property operations",
        description="Check off tasks/criteria, set priority, LOE, and advance status.",
        epilog=(
            "Examples:\n"
            "  nspec task check --id S002 --task-id 1.1\n"
            "  nspec task criteria --id S002 --criteria-id AC-F1\n"
            "  nspec task set-priority --id S002 --priority P0\n"
            "  nspec task next-status --id S002"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    task_subs = task_sub.add_subparsers(dest="task_command")

    # nspec task check
    task_check = task_subs.add_parser("check", help="Mark task complete/obsolete")
    _add_common_args(task_check)
    _add_id_arg(task_check)
    task_check.add_argument("--task-id", type=str, required=True, help="Task ID (e.g., 1.1)")
    task_check.add_argument(
        "--marker",
        type=str,
        default="x",
        choices=["x", "~"],
        help="Marker: x=complete, ~=obsolete",
    )
    task_check.set_defaults(handler=handle_check_task)

    # nspec task criteria
    task_criteria = task_subs.add_parser("criteria", help="Mark criterion complete/obsolete")
    _add_common_args(task_criteria)
    _add_id_arg(task_criteria)
    task_criteria.add_argument(
        "--criteria-id", type=str, required=True, help="Criteria ID (e.g., AC-F1)"
    )
    task_criteria.add_argument(
        "--marker",
        type=str,
        default="x",
        choices=["x", "~"],
        help="Marker: x=complete, ~=obsolete",
    )
    task_criteria.set_defaults(handler=handle_check_criteria)

    # nspec task set-priority
    task_priority = task_subs.add_parser("set-priority", help="Change priority")
    _add_common_args(task_priority)
    _add_id_arg(task_priority)
    task_priority.add_argument("--priority", type=str, required=True, help="Priority (P0-P3)")
    task_priority.set_defaults(handler=handle_set_priority)

    # nspec task set-loe
    task_loe = task_subs.add_parser("set-loe", help="Set LOE estimate")
    _add_common_args(task_loe)
    _add_id_arg(task_loe)
    task_loe.add_argument("--loe", type=str, required=True, help="LOE value (5d, 3w, etc)")
    task_loe.set_defaults(handler=handle_set_loe)

    # nspec task next-status
    task_next = task_subs.add_parser("next-status", help="Advance to next status")
    _add_common_args(task_next)
    _add_id_arg(task_next)
    task_next.set_defaults(handler=handle_next_status)

    # nspec task set-status
    task_status = task_subs.add_parser("set-status", help="Set FR and IMPL status")
    _add_common_args(task_status)
    _add_id_arg(task_status)
    task_status.add_argument("--fr-status", type=int, required=True, help="FR status code")
    task_status.add_argument("--impl-status", type=int, required=True, help="IMPL status code")
    _add_force_arg(task_status)
    task_status.set_defaults(handler=handle_set_status)

    # -------------------------------------------------------------------------
    # nspec session <cmd>
    # -------------------------------------------------------------------------
    session_sub = subparsers.add_parser(
        "session",
        help="Session management",
        description="Manage work sessions: start, log notes, handoff, and sync state.",
        epilog=(
            "Examples:\n"
            "  nspec session start --id S002\n"
            "  nspec session log --id S002 --note 'Fixed parsing bug'\n"
            "  nspec session handoff --id S002\n"
            "  nspec session files --since-commit HEAD~3"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    session_subs = session_sub.add_subparsers(dest="session_command")

    # nspec session start
    session_start = session_subs.add_parser("start", help="Initialize session context")
    _add_common_args(session_start)
    _add_id_arg(session_start)
    session_start.set_defaults(handler=handle_session_start)

    # nspec session log
    session_log = session_subs.add_parser("log", help="Append session note")
    _add_common_args(session_log)
    _add_id_arg(session_log)
    session_log.add_argument("--note", type=str, required=True, help="Note text")
    session_log.set_defaults(handler=handle_session_log)

    # nspec session handoff
    session_handoff = session_subs.add_parser("handoff", help="Generate session handoff")
    _add_common_args(session_handoff)
    _add_id_arg(session_handoff)
    session_handoff.set_defaults(handler=handle_handoff)

    # nspec session sync
    session_sync = session_subs.add_parser("sync", help="Sync spec state")
    _add_common_args(session_sync)
    _add_id_arg(session_sync)
    _add_force_arg(session_sync)
    session_sync.set_defaults(handler=handle_sync)

    # nspec session files
    session_files = session_subs.add_parser("files", help="List modified files")
    _add_common_args(session_files)
    session_files.add_argument("--since-commit", type=str, help="Git ref for comparison")
    session_files.set_defaults(handler=handle_modified_files)

    # -------------------------------------------------------------------------
    # nspec adr <cmd>
    # -------------------------------------------------------------------------
    adr_sub = subparsers.add_parser(
        "adr",
        help="Architecture Decision Records",
        description="Create and list Architecture Decision Records (ADRs).",
        epilog="Examples:\n  nspec adr create --title 'Use argparse over click'\n  nspec adr list",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    adr_subs = adr_sub.add_subparsers(dest="adr_command")

    # nspec adr create
    adr_create = adr_subs.add_parser("create", help="Create new ADR")
    _add_common_args(adr_create)
    adr_create.add_argument("--title", type=str, required=True, help="ADR title")
    adr_create.set_defaults(handler=handle_create_adr)

    # nspec adr list
    adr_list = adr_subs.add_parser("list", help="List all ADRs")
    _add_common_args(adr_list)
    adr_list.set_defaults(handler=handle_list_adrs)

    # -------------------------------------------------------------------------
    # nspec loop-retry <cmd>
    # -------------------------------------------------------------------------
    loop_retry_sub = subparsers.add_parser(
        "loop-retry",
        help="Loop retry tracking",
        description="Track per-spec retry counts for nspec-loop crash resume.",
        epilog=(
            "Examples:\n"
            "  nspec loop-retry increment --id S064 --exit-reason timeout\n"
            "  nspec loop-retry count --id S064\n"
            "  nspec loop-retry clear --id S064\n"
            "  nspec loop-retry list\n"
            "  nspec loop-retry reset"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    loop_retry_subs = loop_retry_sub.add_subparsers(dest="retry_action")

    lr_increment = loop_retry_subs.add_parser("increment", help="Increment retry count")
    _add_common_args(lr_increment)
    _add_id_arg(lr_increment)
    lr_increment.add_argument("--exit-reason", type=str, default="", help="Why the session failed")
    lr_increment.set_defaults(handler=handle_loop_retry)

    lr_count = loop_retry_subs.add_parser("count", help="Show retry count")
    _add_common_args(lr_count)
    _add_id_arg(lr_count)
    lr_count.set_defaults(handler=handle_loop_retry)

    lr_clear = loop_retry_subs.add_parser("clear", help="Clear retry entry for a spec")
    _add_common_args(lr_clear)
    _add_id_arg(lr_clear)
    lr_clear.set_defaults(handler=handle_loop_retry)

    lr_list = loop_retry_subs.add_parser("list", help="List all retry entries")
    _add_common_args(lr_list)
    lr_list.set_defaults(handler=handle_loop_retry)

    lr_reset = loop_retry_subs.add_parser("reset", help="Delete all retry data")
    _add_common_args(lr_reset)
    lr_reset.set_defaults(handler=handle_loop_retry)

    # -------------------------------------------------------------------------
    # nspec config <key>
    # -------------------------------------------------------------------------
    config_sub = subparsers.add_parser(
        "config",
        help="Read config values",
        description="Read configuration values by dotted key path.",
        epilog=(
            "Examples:\n"
            "  nspec config loop.session_timeout\n"
            "  nspec config loop.max_retries\n"
            "  nspec config defaults.epic"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(config_sub)
    config_sub.add_argument("key", type=str, help="Dotted key path (e.g., loop.session_timeout)")
    config_sub.set_defaults(handler=handle_config_get)

    # -------------------------------------------------------------------------
    # nspec queue
    # -------------------------------------------------------------------------
    queue_sub = subparsers.add_parser(
        "queue",
        help="Agent assignment queue for parallel execution",
        description="Manage the work queue for multi-agent parallel spec execution.",
        epilog=(
            "Examples:\n"
            "  nspec queue init --epic E002 --max-agents 5\n"
            "  nspec queue status\n"
            "  nspec queue claim --agent-id worker-1\n"
            "  nspec queue release --agent-id worker-1 --spec-id S042\n"
            "  nspec queue drain"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    queue_subs = queue_sub.add_subparsers(dest="queue_action")

    q_init = queue_subs.add_parser("init", help="Initialize queue from backlog")
    q_init.add_argument("--epic", dest="epic_id", type=str, help="Epic ID to filter specs")
    q_init.add_argument(
        "--max-agents", type=int, default=5, help="Max concurrent agents (default: 5)"
    )
    q_init.add_argument(
        "--lease-ttl", type=int, default=300, help="Lease TTL in seconds (default: 300)"
    )
    q_init.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    q_init.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)

    q_status = queue_subs.add_parser("status", help="Show queue state")
    q_status.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    q_status.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)

    q_claim = queue_subs.add_parser("claim", help="Claim next spec")
    q_claim.add_argument("--agent-id", required=True, help="Agent identity")
    q_claim.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    q_claim.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)

    q_release = queue_subs.add_parser("release", help="Release a claimed spec")
    q_release.add_argument("--agent-id", required=True, help="Agent identity")
    q_release.add_argument("--spec-id", required=True, help="Spec ID to release")
    q_release.add_argument("--reason", type=str, help="Reason for release")
    q_release.add_argument("--completed", action="store_true", help="Mark as completed")
    q_release.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    q_release.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)

    q_drain = queue_subs.add_parser("drain", help="Show drain status")
    q_drain.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    q_drain.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)

    queue_sub.set_defaults(handler=handle_queue)

    # -------------------------------------------------------------------------
    # nspec watchdog
    # -------------------------------------------------------------------------
    watchdog_sub = subparsers.add_parser(
        "watchdog",
        help="Claude Code stall detector & auto-recovery",
        description=(
            "Monitor a tmux session for Claude Code API stalls. "
            "When the token count stops incrementing during active processing, "
            "sends Escape + recovery message to resume."
        ),
        epilog=(
            "Examples:\n"
            "  nspec watchdog --session my-session\n"
            "  nspec watchdog --session my-session --stall-timeout 120\n"
            "  nspec watchdog --stall-timeout 60 --poll-interval 5"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(watchdog_sub)
    watchdog_sub.add_argument(
        "--session", type=str, help="tmux session name (auto-detected if omitted)"
    )
    watchdog_sub.add_argument(
        "--stall-timeout",
        type=int,
        default=None,
        help="Seconds before declaring token stall (default: 180)",
    )
    watchdog_sub.add_argument(
        "--mcp-stall-timeout",
        type=int,
        default=None,
        help="Seconds before declaring MCP tool hang (default: 120)",
    )
    watchdog_sub.add_argument(
        "--poll-interval", type=int, default=None, help="Seconds between polls (default: 15)"
    )
    watchdog_sub.set_defaults(handler=handle_watchdog)

    # -------------------------------------------------------------------------
    # nspec audit
    # -------------------------------------------------------------------------
    audit_sub = subparsers.add_parser(
        "audit",
        help="Run coverage audit with dead-code detection",
        description=(
            "Parse whole-suite coverage artifacts, build candidate inventories\n"
            "of uncovered and suspicious code, and reconcile triage decisions."
        ),
        epilog=(
            "Examples:\n"
            "  nspec audit\n"
            "  nspec audit --strict\n"
            "  nspec audit --coverage-json work/coverage.json --registry work/decisions.json"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(audit_sub)
    audit_sub.add_argument(
        "--coverage-json",
        type=str,
        default="coverage.json",
        help="Path to pytest-cov JSON output (default: coverage.json)",
    )
    audit_sub.add_argument(
        "--registry",
        type=str,
        default="work/coverage_decisions.json",
        help="Path to decision registry JSON (default: work/coverage_decisions.json)",
    )
    audit_sub.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero if any candidates are unresolved or stale",
    )
    audit_sub.add_argument(
        "--include",
        type=str,
        default=None,
        help="Comma-separated regex patterns for files to include",
    )
    audit_sub.add_argument(
        "--exclude",
        type=str,
        default=None,
        help="Comma-separated regex patterns for files to exclude",
    )
    audit_sub.set_defaults(handler=handle_audit)

    # -------------------------------------------------------------------------
    # nspec audit list / nspec audit show (audit trail artifacts)
    # -------------------------------------------------------------------------
    audit_trail_sub = subparsers.add_parser(
        "trail",
        help="List or show audit trail artifacts (decisions, inventories, handoffs)",
        description="Browse git-tracked audit artifacts in .novabuilt.dev/nspec/audit/.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    trail_subs = audit_trail_sub.add_subparsers(dest="trail_command")

    trail_list = trail_subs.add_parser("list", help="List audit artifacts")
    trail_list.add_argument(
        "kind",
        nargs="?",
        choices=["decision", "inventory", "handoff"],
        help="Filter by artifact kind (omit to list all)",
    )
    _add_common_args(trail_list)

    trail_show = trail_subs.add_parser("show", help="Show an audit artifact by slug")
    trail_show.add_argument("slug", help="Artifact slug (filename without .md)")
    _add_common_args(trail_show)

    audit_trail_sub.set_defaults(handler=handle_audit_trail)

    # -------------------------------------------------------------------------
    # nspec context-audit
    # -------------------------------------------------------------------------
    context_audit_sub = subparsers.add_parser(
        "context-audit",
        help="Analyze CLAUDE.md for context budget and extraction candidates",
        description=(
            "Parse a CLAUDE.md file, classify each ## section as behavioral\n"
            "or reference, and recommend extractions when reference content\n"
            "exceeds the threshold."
        ),
        epilog=(
            "Examples:\n"
            "  nspec context-audit\n"
            "  nspec context-audit --file path/to/CLAUDE.md\n"
            "  nspec context-audit --threshold 40"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(context_audit_sub)
    context_audit_sub.add_argument(
        "--file",
        type=str,
        default=None,
        help="Path to CLAUDE.md file (default: ./CLAUDE.md)",
    )
    context_audit_sub.add_argument(
        "--threshold",
        type=int,
        default=50,
        help="Reference content percentage threshold for recommendations (default: 50)",
    )
    context_audit_sub.set_defaults(handler=handle_context_audit)

    # -------------------------------------------------------------------------
    # nspec linear <cmd>
    # -------------------------------------------------------------------------
    linear_sub = subparsers.add_parser(
        "linear",
        help="Linear integration (repo -> Linear sync)",
        description="Sync nspec spec state to Linear issues via GraphQL API.",
        epilog=(
            "Examples:\n"
            "  nspec linear push --since HEAD~1\n"
            "  nspec linear push --spec-id S168 --dry-run\n"
            "  nspec linear bootstrap"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    linear_subs = linear_sub.add_subparsers(dest="linear_command")

    # nspec linear push
    linear_push_sub = linear_subs.add_parser(
        "push",
        help="Push nspec state to linked Linear issues",
        description=(
            "Sync spec state to Linear. Reads linear_issue_id from FR headers "
            "and updates the corresponding Linear issues via GraphQL."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(linear_push_sub)
    linear_push_sub.add_argument(
        "--since",
        type=str,
        help="Sync only specs changed since this git ref (e.g., HEAD~1, abc123)",
    )
    linear_push_sub.add_argument(
        "--spec-id",
        type=str,
        help="Sync a single spec by ID",
    )
    linear_push_sub.add_argument(
        "--dry-run",
        action="store_true",
        help="Show planned updates without making API calls",
    )
    linear_push_sub.set_defaults(handler=handle_linear_push)

    # nspec linear bootstrap
    linear_bootstrap_sub = linear_subs.add_parser(
        "bootstrap",
        help="Print config snippet with Linear team/workflow state IDs",
        description=(
            "Query the Linear API for team and workflow state information, "
            "then print a config.toml snippet for the [linear] section."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(linear_bootstrap_sub)
    linear_bootstrap_sub.set_defaults(handler=handle_linear_bootstrap)

    # -------------------------------------------------------------------------
    # nspec issue <cmd>
    # -------------------------------------------------------------------------
    issue_sub = subparsers.add_parser(
        "issue",
        aliases=["issues"],
        help="GitHub issue integration (import issues as specs)",
        description="Import GitHub issues as nspec specs via the gh CLI.",
        epilog=(
            "Examples:\n"
            "  nspec issue list --repo owner/repo\n"
            "  nspec issue import --repo owner/repo --number 42\n"
            "  nspec issue import --repo owner/repo --number 42 --dry-run"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    issue_subs = issue_sub.add_subparsers(dest="issue_command")

    # nspec issue import
    issue_import_sub = issue_subs.add_parser(
        "import",
        help="Import a GitHub issue as an nspec spec",
        description=(
            "Fetch a GitHub issue and create an FR+IMPL pair populated "
            "with the issue content. Labels are mapped to nspec priorities."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(issue_import_sub)
    issue_import_sub.add_argument(
        "--repo",
        type=str,
        help="Repository in owner/repo format (or set [github].repo in config.toml)",
    )
    issue_import_sub.add_argument(
        "--number",
        type=int,
        required=True,
        help="Issue number to import",
    )
    issue_import_sub.add_argument(
        "--epic",
        dest="epic_id",
        type=str,
        help="Epic ID to assign the spec to",
    )
    issue_import_sub.add_argument(
        "--priority",
        type=str,
        help="Override priority (P0-P3). Default: mapped from issue labels",
    )
    issue_import_sub.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview the issue without creating a spec",
    )
    issue_import_sub.set_defaults(handler=handle_issue_import)

    # nspec issue list
    issue_list_sub = issue_subs.add_parser(
        "list",
        help="List GitHub issues with mapped priorities",
        description=(
            "Fetch issues from a GitHub repository and display them "
            "with their mapped nspec priorities based on labels."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(issue_list_sub)
    issue_list_sub.add_argument(
        "--repo",
        type=str,
        help="Repository in owner/repo format (or set [github].repo in config.toml)",
    )
    issue_list_sub.add_argument(
        "--state",
        type=str,
        default="open",
        choices=["open", "closed", "all"],
        help="Filter by issue state (default: open)",
    )
    issue_list_sub.add_argument(
        "--label",
        type=str,
        help="Filter by label",
    )
    issue_list_sub.set_defaults(handler=handle_issue_list)

    # nspec issue status
    issue_status_sub = issue_subs.add_parser(
        "status",
        help="Show issue pipeline status across lifecycle stages",
        description=(
            "Display a pipeline view showing GitHub issues flowing through "
            "the nspec lifecycle: Open -> Imported -> In Progress -> Resolved -> Closed."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(issue_status_sub)
    issue_status_sub.add_argument(
        "--repo",
        type=str,
        help="Repository in owner/repo format (or set [github].repo in config.toml)",
    )
    issue_status_sub.set_defaults(handler=handle_issue_status)

    # -------------------------------------------------------------------------
    # nspec tracker <cmd>
    # -------------------------------------------------------------------------
    tracker_sub = subparsers.add_parser(
        "tracker",
        help="Tracker sync (audit back-comments, reconcile drift)",
        description=(
            "Audit and reconcile bidirectional links between nspec specs and GitHub issues."
        ),
        epilog=(
            "Examples:\n"
            "  nspec tracker audit\n"
            "  nspec tracker audit --fix\n"
            "  nspec tracker audit --repo owner/repo"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    tracker_subs = tracker_sub.add_subparsers(dest="tracker_command")

    # nspec tracker audit
    tracker_audit_sub = tracker_subs.add_parser(
        "audit",
        help="Check back-comments and status consistency for all linked specs",
        description=(
            "Walk all specs with github_issue: headers, check each issue for "
            "a back-comment and status consistency. Read-only by default; "
            "--fix posts missing back-comments."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(tracker_audit_sub)
    tracker_audit_sub.add_argument(
        "--repo",
        type=str,
        help="Repository in owner/repo format (or set [github].repo in config.toml)",
    )
    tracker_audit_sub.add_argument(
        "--fix",
        action="store_true",
        help="Post missing back-comments (default: read-only audit)",
    )
    tracker_audit_sub.set_defaults(handler=handle_tracker_audit)

    # nspec skills <cmd>
    # -------------------------------------------------------------------------
    skills_sub = subparsers.add_parser(
        "skills",
        help="Manage nspec skills (slash commands)",
        description="Install, sync, and list nspec skills for agent platforms.",
        epilog=("Examples:\n  nspec skills list\n  nspec skills sync\n  nspec skills sync --force"),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    skills_subs = skills_sub.add_subparsers(dest="skills_command")

    # nspec skills sync
    skills_sync_sub = skills_subs.add_parser(
        "sync", help="Install skills and sync symlinks to agent directories"
    )
    _add_common_args(skills_sync_sub)
    _add_force_arg(skills_sync_sub)
    skills_sync_sub.set_defaults(handler=handle_skills_sync)

    # nspec skills list
    skills_list_sub = skills_subs.add_parser("list", help="List available skills")
    _add_common_args(skills_list_sub)
    skills_list_sub.set_defaults(handler=handle_skills_list)

    # -------------------------------------------------------------------------
    # nspec status-codes
    # -------------------------------------------------------------------------
    status_codes_sub = subparsers.add_parser(
        "status-codes",
        help="Print FR and IMPL status codes reference",
        description="Print a reference table of all FR and IMPL status codes.",
        epilog="Examples:\n  nspec status-codes",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(status_codes_sub)
    status_codes_sub.set_defaults(handler=_handle_status_codes)

    # -------------------------------------------------------------------------
    # nspec mcp-config
    # -------------------------------------------------------------------------
    mcp_config_sub = subparsers.add_parser(
        "mcp-config",
        help="Print MCP configuration instructions",
        description="Print MCP server configuration instructions for Claude Code integration.",
        epilog="Examples:\n  nspec mcp-config",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(mcp_config_sub)
    mcp_config_sub.set_defaults(handler=handle_mcp_config)

    # -------------------------------------------------------------------------
    # nspec doctor
    # -------------------------------------------------------------------------
    doctor_sub = subparsers.add_parser(
        "doctor",
        help="Run project health checks",
        description="Run project health checks: config, directories, validation, MCP server.",
        epilog="Examples:\n  nspec doctor",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    _add_common_args(doctor_sub)
    doctor_sub.set_defaults(handler=handle_doctor)

    # -------------------------------------------------------------------------
    # nspec mcp — run the MCP server (replaces nspec-mcp binary)
    # -------------------------------------------------------------------------
    mcp_sub = subparsers.add_parser(
        "mcp",
        help="Run the MCP server",
        description="Start the nspec MCP server (stdio by default).",
        epilog="Examples:\n  nspec mcp\n  nspec mcp --sse\n  nspec mcp --http",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    mcp_transport = mcp_sub.add_mutually_exclusive_group()
    mcp_transport.add_argument("--sse", action="store_true", help="Use SSE transport")
    mcp_transport.add_argument("--http", action="store_true", help="Use streamable-http transport")

    # -------------------------------------------------------------------------
    # nspec loop — run the loop orchestrator (replaces nspec-loop binary)
    # -------------------------------------------------------------------------
    subparsers.add_parser(
        "loop",
        help="Run the loop orchestrator",
        description="Execute the nspec-loop bash script for autonomous spec processing.\n"
        "All arguments after 'loop' are forwarded to the script.",
        epilog="Examples:\n  nspec loop\n  nspec loop --max-specs 5\n  nspec loop --epic E001",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Hidden: resolved from config.toml [paths].spec_root by default
    parser.add_argument("--docs-root", type=Path, default=None, help=argparse.SUPPRESS)
    parser.add_argument("--project-root", type=Path, default=None, help=argparse.SUPPRESS)

    return parser


# ======================================================================
# Main entry point
# ======================================================================


def main() -> int:
    """Main CLI entry point."""
    # Configure logging
    log_level = logging.DEBUG if os.environ.get("NSPEC_DEBUG") == "Y" else logging.WARNING
    logging.basicConfig(level=log_level, format="%(message)s", stream=sys.stdout)

    parser = build_parser()

    # Enable tab completion if argcomplete is installed
    try:
        import argcomplete

        argcomplete.autocomplete(parser)
    except ImportError:
        pass

    # Intercept 'loop' before argparse — it needs raw pass-through of all args
    # (argparse.REMAINDER can't handle unknown flags like --max-specs).
    # Let --help/-h fall through to argparse so the subparser help text works.
    if (
        len(sys.argv) >= 2
        and sys.argv[1] == "loop"
        and "--help" not in sys.argv
        and "-h" not in sys.argv
    ):
        from importlib import resources

        extra = sys.argv[2:]
        script_ref = resources.files("nspec.scripts").joinpath("nspec_loop.sh")
        with resources.as_file(script_ref) as script_path:
            os.execvp("bash", ["bash", str(script_path)] + extra)
        return 0  # unreachable but satisfies type checker

    args = parser.parse_args()

    # Subcommand dispatch (before flag-based dispatch / docs_root resolution)
    if args.command == "init":
        return handle_init(args)

    if args.command == "mcp":
        from nspec.mcp_server import main as mcp_main

        transport = "streamable-http" if args.http else ("sse" if args.sse else "stdio")
        mcp_main(transport=transport)
        return 0

    # Resolve docs_root / project_root: explicit CLI override > config.toml
    from nspec.config import NspecConfig
    from nspec.domain.statuses import configure as configure_statuses

    if getattr(args, "docs_root", None) is None:
        # If only --project-root is given, scope the config search to it so
        # the user's override actually takes effect (S910 hooks-doctor uses this).
        explicit_pr = getattr(args, "project_root", None)
        handler_config = NspecConfig.load(explicit_pr)
        args.docs_root = handler_config.resolve_spec_root()
        if explicit_pr is None:
            args.project_root = handler_config.resolve_project_root()
    elif getattr(args, "project_root", None) is None:
        args.project_root = args.docs_root.parent

    handler_config = NspecConfig.load(args.project_root)
    configure_statuses(handler_config.emojis, handler_config.priorities)

    # --tui flag: treat as 'nspec tui' subcommand
    if getattr(args, "tui", False) and not args.command:
        from nspec.tui import main as tui_main

        tui_main(docs_root=args.docs_root, project_root=args.project_root)
        return 0

    # Handler-based dispatch for new subcommands
    if hasattr(args, "handler"):
        return args.handler(args)

    # No command specified
    parser.print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())
