"""nspec MCP Server — re-export shim.

The implementation has moved to ``nspec.interfaces.mcp``.
This module re-exports all public names for backward compatibility.
"""

import subprocess  # noqa: F401 — kept for @patch("nspec.mcp_server.subprocess.run")

# Checkout / session / init / skills / artifacts tools
from nspec.interfaces.mcp._checkout import (  # noqa: F401
    artifacts_list,
    artifacts_sync,
    checkin,
    checkout,
    checkout_heartbeat,
    checkout_status,
    context_audit,
    coverage_audit,
    discover_providers,
    init,
    session_delete,
    session_get,
    session_list,
    skills_install,
    skills_list,
    skills_sync,
    skills_update,
    spec_test_files,
    spec_tests,
)

# Helpers (used by tests via @patch strings)
from nspec.interfaces.mcp._helpers import (  # noqa: F401
    _attach_branch_warnings,
    _capture_mcp_error,
    _capture_test_gate_error,
    _check_stale_branch,
    _compute_task_progress,
    _dao,
    _discover_epics_on_disk,
    _exception_error,
    _extract_spec_id_from_prompt,
    _find_epic_for_spec,
    _get_task_tag,
    _invalid_id_error,
    _normalize_epic_id,
    _normalize_id,
    _post_mutation_validate,
    _resolve_code_root,
    _resolve_docs_root,
    _resolve_id,
    _resolve_id_from_disk,
    _resolve_project_root,
    _run_test_gate,
    _scan_known_ids,
    _to_bool,
    _tool_error,
    _try_capture_from_frame,
    _verify_epic_exists,
)

# Mutation tools
# Mutation tools (continued)
from nspec.interfaces.mcp._mutation import (  # noqa: F401  # noqa: F401
    activate,
    add_dep,
    advance,
    batch_import,
    blocked_specs,
    branch_cleanup,
    branch_status,
    cheap_docs,
    complete,
    create_issue,
    create_spec,
    criteria_complete,
    dep_graph,
    epic_specs,
    exception,
    execute_agent,
    hold,
    issue_import,
    issue_list,
    issue_sync,
    loop_init,
    loop_pipeline,
    park,
    park_epic,
    queue_claim,
    queue_heartbeat,
    queue_init,
    queue_release,
    queue_status,
    recover,
    refine_fr,
    refine_impl,
    remove_dep,
    reset,
    review,
    review_spec,
    session_clear,
    session_resume,
    session_save,
    set_priority,
    start_design,
    supersede,
    swap_priority,
    swarm_launch,  # S253: parallel Claude Code agent swarm
    swarm_status,
    swarm_teardown,
    task_block,
    task_complete,
    task_unblock,
    unify_collisions,
    write_fr_refinement,
    write_refinement,
    write_review_verdict,
)

# Query tools
from nspec.interfaces.mcp._query import (  # noqa: F401
    epics,
    estimate_loe,
    get_epic,
    next_spec,
    preflight,
    session_start,
    show,
    validate,
)

# Core server
from nspec.interfaces.mcp.server import (  # noqa: F401
    _redirect_print_to_stderr_for_stdio,
    main,
    mcp,
)

if __name__ == "__main__":
    main()
