"""TerminusDB enum type definitions for nspec.

Defines Priority, Status, SpecType, ADRStatus, and ReviewVerdict
as TerminusDB EnumTemplate subclasses, plus EMOJI_MAP for display.

EMOJI_MAP is built from domain/statuses.py (the single source of truth)
via _build_emoji_map(). It reflects config.toml overrides applied at
configure() time.
"""

from __future__ import annotations

from terminusdb_client.schema import EnumTemplate


class Priority(EnumTemplate):
    """Spec/Epic priority levels."""

    P0 = "P0"  # Critical
    P1 = "P1"  # High
    P2 = "P2"  # Medium
    P3 = "P3"  # Low


class Status(EnumTemplate):
    """FR and IMPL status values.

    FR statuses: Proposed, Active, Completed
    IMPL statuses: Planning, Active, Testing, Ready, Paused, Exception, Completed
    """

    Proposed = "Proposed"
    Active = "Active"
    Planning = "Planning"
    Testing = "Testing"
    Ready = "Ready"
    Paused = "Paused"
    Exception_ = "Exception"
    Completed = "Completed"


class SpecType(EnumTemplate):
    """Type of specification."""

    Feature = "Feature"
    Enhancement = "Enhancement"
    Bug = "Bug"
    ADR = "ADR"
    Refactor = "Refactor"
    Epic = "Epic"


class ADRStatus(EnumTemplate):
    """ADR-specific status values."""

    Proposed = "Proposed"
    Accepted = "Accepted"
    Deprecated = "Deprecated"
    Superseded = "Superseded"


class ReviewVerdict(EnumTemplate):
    """Code review verdict."""

    PENDING = "PENDING"
    APPROVED = "APPROVED"
    NEEDS_WORK = "NEEDS_WORK"


def _build_emoji_map() -> dict[str, str]:
    """Build emoji map from domain/statuses.py — the single source of truth.

    Returns a dict mapping priority codes (P0-P3) and status words
    (Proposed, Active, etc.) to their config-driven emoji characters.
    """
    from nspec.domain.statuses import (
        ALL_PRIORITIES,
        FR_STATUSES,
        IMPL_STATUSES,
    )

    result: dict[str, str] = {}
    # Priority emojis
    for code, pri in ALL_PRIORITIES.items():
        result[code] = pri.emoji
    # Status emojis — FR + IMPL (IMPL overwrites shared keys like "Active")
    for status in FR_STATUSES.values():
        result[status.text] = status.emoji
    for status in IMPL_STATUSES.values():
        result[status.text] = status.emoji
    return result


# Display emoji mapping for enum values — built from domain/statuses.py
EMOJI_MAP: dict[str, str] = _build_emoji_map()
