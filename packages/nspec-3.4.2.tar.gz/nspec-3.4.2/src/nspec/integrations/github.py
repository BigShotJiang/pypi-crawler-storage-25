"""GitHub integration — import issues as nspec specs via ``gh`` CLI.

Provides:
- Issue fetching via ``gh issue view`` / ``gh issue list``
- Label-to-priority mapping
- FR content population from issue body
- ``github_issue:`` header parsing

Usage (CLI):
    nspec issue list --repo owner/repo
    nspec issue import --repo owner/repo --number 42
    nspec issue import --repo owner/repo --number 42 --dry-run
"""

from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger("nspec")

# Regex to extract github_issue: from FR header content
_GITHUB_ISSUE_REF_RE = re.compile(r"^github_issue:\s*(\S+)\s*$", re.MULTILINE | re.IGNORECASE)


@dataclass
class GitHubIssue:
    """Parsed GitHub issue."""

    number: int
    title: str
    body: str
    labels: list[str]
    state: str  # "OPEN" | "CLOSED"
    url: str
    repo: str  # "owner/repo"
    created_at: str | None = None  # ISO 8601 timestamp from GitHub


def _run_gh(*args: str, timeout: int = 30, cwd: str | None = None) -> str:
    """Run a ``gh`` CLI command and return stdout.

    Raises:
        ValueError: If ``gh`` is not installed, auth fails, or command fails.
    """
    if not shutil.which("gh"):
        raise ValueError("gh CLI not found. Install: https://cli.github.com/")

    try:
        result = subprocess.run(
            ["gh", *args],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=True,
            cwd=cwd,
        )
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.strip() if e.stderr else ""
        if "auth" in stderr.lower() or "login" in stderr.lower():
            raise ValueError("GitHub auth failed. Run: gh auth login") from None
        raise ValueError(f"gh command failed: {stderr or 'unknown error'}") from None
    except subprocess.TimeoutExpired:
        raise ValueError("gh command timed out") from None

    return result.stdout.strip()


def fetch_issue(repo: str, number: int) -> GitHubIssue:
    """Fetch a single issue by number.

    Args:
        repo: Repository in ``owner/repo`` format.
        number: Issue number.

    Returns:
        Parsed GitHubIssue.

    Raises:
        ValueError: If issue not found or gh fails.
    """
    try:
        raw = _run_gh(
            "issue",
            "view",
            str(number),
            "--repo",
            repo,
            "--json",
            "number,title,body,labels,state,url",
        )
    except ValueError as e:
        err_str = str(e)
        # Only remap to "issue not found" for gh command failures about the issue itself,
        # not for "gh CLI not found" or auth errors.
        if err_str.startswith("gh command failed:") and (
            "not found" in err_str.lower() or "could not" in err_str.lower()
        ):
            raise ValueError(f"Issue #{number} not found in repo {repo}") from None
        raise

    data = json.loads(raw)
    return GitHubIssue(
        number=data["number"],
        title=data["title"],
        body=data.get("body") or "",
        labels=[lbl["name"] for lbl in data.get("labels", [])],
        state=data["state"],
        url=data["url"],
        repo=repo,
    )


def fetch_issues(
    repo: str,
    *,
    state: str = "open",
    label: str | None = None,
    limit: int = 30,
) -> list[GitHubIssue]:
    """Fetch issues from a repository.

    Args:
        repo: Repository in ``owner/repo`` format.
        state: Filter by state: "open", "closed", or "all".
        label: Optional label filter.
        limit: Maximum number of issues to return.

    Returns:
        List of parsed GitHubIssue objects.
    """
    args = [
        "issue",
        "list",
        "--repo",
        repo,
        "--state",
        state,
        "--limit",
        str(limit),
        "--json",
        "number,title,body,labels,state,url,createdAt",
    ]
    if label:
        args.extend(["--label", label])

    raw = _run_gh(*args)
    if not raw:
        return []

    items = json.loads(raw)
    return [
        GitHubIssue(
            number=item["number"],
            title=item["title"],
            body=item.get("body") or "",
            labels=[lbl["name"] for lbl in item.get("labels", [])],
            state=item["state"],
            url=item["url"],
            repo=repo,
            created_at=item.get("createdAt"),
        )
        for item in items
    ]


def map_labels_to_priority(
    labels: list[str],
    label_map: dict[str, str],
    default: str = "P2",
) -> str:
    """Map GitHub labels to nspec priority.

    Matching is case-insensitive. Returns the highest priority found
    (lowest P-number wins).

    Args:
        labels: List of GitHub label names.
        label_map: Mapping of label name (lowercase) → priority string.
        default: Default priority if no labels match.

    Returns:
        Priority string (e.g., "P0", "P1").
    """
    # Build lowercase lookup
    lower_map = {k.lower(): v for k, v in label_map.items()}

    matched: list[str] = []
    for label in labels:
        prio = lower_map.get(label.lower())
        if prio:
            matched.append(prio)

    if not matched:
        return default

    # Return highest priority (lowest numeric rank — handles P10+ correctly)
    from nspec.domain.statuses import PRIORITY_RANK

    matched.sort(key=lambda p: PRIORITY_RANK.get(p, 99))
    return matched[0]


def issue_to_fr_content(
    issue: GitHubIssue,
    spec_id: str,  # noqa: ARG001 – reserved for future template interpolation
    priority: str,  # noqa: ARG001 – reserved for future template interpolation
    existing_fr: str,
) -> str:
    """Populate an existing FR skeleton with issue content.

    Inserts ``github_issue:`` header and maps issue body sections
    into FR sections.

    Args:
        issue: Parsed GitHub issue.
        spec_id: nspec spec ID (e.g., "S042").
        priority: Resolved priority string.
        existing_fr: Existing FR file content (skeleton from create_spec).

    Returns:
        Updated FR content string.
    """
    lines = existing_fr.splitlines(keepends=True)
    result_lines: list[str] = []

    # Insert github_issue: after deps: [] line
    inserted_ref = False
    for line in lines:
        result_lines.append(line)
        if not inserted_ref and line.strip().startswith("deps:"):
            result_lines.append(f"github_issue: {issue.repo}#{issue.number}\n")
            inserted_ref = True

    content = "".join(result_lines)

    # Parse issue body for structured sections
    body = issue.body.strip()
    if not body:
        return content

    sections = _parse_issue_sections(body)

    # Map issue sections to FR sections
    problem_content = ""
    solution_content = ""
    summary_content = ""

    if sections:
        for heading, text in sections.items():
            heading_lower = heading.lower()
            if any(kw in heading_lower for kw in ("summary", "overview", "description")):
                summary_content = text
            elif any(kw in heading_lower for kw in ("reproduction", "reproduce", "problem", "bug")):
                problem_content = text
            elif any(
                kw in heading_lower
                for kw in ("solution", "suggested", "expected", "fix", "proposal")
            ):
                solution_content = text
            elif not problem_content:
                # First unmatched section goes to problem
                problem_content = text
    else:
        # Unstructured body — place entirely in Problem section
        problem_content = body

    # Inject content into FR sections
    if summary_content:
        content = _inject_section(content, "Executive Summary", summary_content)
    if problem_content:
        content = _inject_section(content, "Problem", problem_content)
    if solution_content:
        content = _inject_section(content, "Solution", solution_content)

    return content


def _parse_issue_sections(body: str) -> dict[str, str]:
    """Parse markdown body into heading → content mapping."""
    sections: dict[str, str] = {}
    current_heading: str | None = None
    current_lines: list[str] = []

    for line in body.splitlines():
        if line.startswith("## "):
            if current_heading is not None:
                sections[current_heading] = "\n".join(current_lines).strip()
            current_heading = line[3:].strip()
            current_lines = []
        elif current_heading is not None:
            current_lines.append(line)

    if current_heading is not None:
        sections[current_heading] = "\n".join(current_lines).strip()

    return sections


def _inject_section(content: str, section_name: str, text: str) -> str:
    """Inject text after a ``## Section Name`` heading in FR content.

    If the section exists, appends text after the heading line.
    """
    pattern = re.compile(rf"^(## {re.escape(section_name)}\s*\n)", re.MULTILINE)
    match = pattern.search(content)
    if match:
        insert_pos = match.end()
        return content[:insert_pos] + "\n" + text + "\n" + content[insert_pos:]
    return content


def parse_github_issue_ref(fr_content: str) -> str | None:
    """Extract ``github_issue:`` reference from FR file content.

    Looks for a line like ``github_issue: owner/repo#42`` in the header.

    Args:
        fr_content: Raw FR file content.

    Returns:
        Reference string (e.g., "owner/repo#42") if found, None otherwise.
    """
    match = _GITHUB_ISSUE_REF_RE.search(fr_content)
    if match:
        return match.group(1).strip()
    return None


def close_linked_issue(
    fr_path_or_content: Path | str,
    reason: str,
    spec_id: str,
) -> bool:
    """Close the GitHub issue linked to an FR via its ``github_issue:`` header.

    Accepts either a file path (reads the file) or raw FR content (uses directly).
    Parses the ``github_issue: owner/repo#N`` header and calls
    ``gh issue close`` with the given reason as a comment.

    Args:
        fr_path_or_content: Path to the FR file, or raw FR content string.
        reason: Comment to post when closing the issue.
        spec_id: The nspec spec ID (for logging context).

    Returns:
        True if the issue was closed successfully, False if no linked issue
        was found or if the close command failed.
    """
    # Resolve content
    if isinstance(fr_path_or_content, Path):
        try:
            content = fr_path_or_content.read_text(encoding="utf-8")
        except OSError as e:
            logger.warning("S%s: could not read FR file %s: %s", spec_id, fr_path_or_content, e)
            return False
    else:
        content = fr_path_or_content

    # Extract github_issue: ref
    ref = parse_github_issue_ref(content)
    if not ref:
        return False

    # Split "owner/repo#42" into repo="owner/repo" and number="42"
    parts = ref.rsplit("#", 1)
    if len(parts) != 2:
        logger.warning("%s: malformed github_issue ref: %s", spec_id, ref)
        return False

    repo, number_str = parts
    if not repo or not number_str:
        logger.warning("%s: malformed github_issue ref: %s", spec_id, ref)
        return False

    # Close via gh CLI
    try:
        subprocess.run(
            ["gh", "issue", "close", number_str, "-R", repo, "--comment", reason],
            capture_output=True,
            text=True,
            timeout=30,
            check=True,
        )
    except FileNotFoundError:
        logger.warning("%s: gh CLI not found — cannot close issue %s", spec_id, ref)
        return False
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.strip() if e.stderr else ""
        logger.warning("%s: failed to close issue %s: %s", spec_id, ref, stderr)
        return False
    except subprocess.TimeoutExpired:
        logger.warning("%s: timed out closing issue %s", spec_id, ref)
        return False

    logger.info("%s: closed GitHub issue %s", spec_id, ref)
    return True


# ============================================================================
# Back-comment — post "Tracked in nspec" comment on GitHub issues
# ============================================================================

# Marker used to detect existing back-comments (idempotency)
_BACK_COMMENT_MARKER = "Tracked in nspec:"


def _parse_tracker_ref(ref: str) -> tuple[str, str] | None:
    """Parse ``owner/repo#42`` into ``(repo, number_str)``.

    Returns None if the ref is malformed.
    """
    parts = ref.rsplit("#", 1)
    if len(parts) != 2 or not parts[0] or not parts[1]:
        return None
    return parts[0], parts[1]


def check_back_comment(repo: str, issue_number: int, spec_id: str) -> bool | None:
    """Check whether a GitHub issue already has a back-comment for a spec.

    Args:
        repo: Repository in "owner/repo" format.
        issue_number: Issue number.
        spec_id: Spec ID to look for (e.g., "S367").

    Returns:
        True if a comment with ``Tracked in nspec: **S###**`` exists,
        False if no such comment exists, None if the check failed.
    """
    try:
        output = _run_gh(
            "issue",
            "view",
            str(issue_number),
            "-R",
            repo,
            "--json",
            "comments",
            "--jq",
            ".comments[].body",
            timeout=30,
        )
    except ValueError as e:
        logger.warning(
            "%s: failed to check back-comment on %s#%d: %s", spec_id, repo, issue_number, e
        )
        return None

    # Normalise spec_id for matching (accept S367 or 367)
    normalised = spec_id.upper() if spec_id.upper().startswith("S") else f"S{spec_id}"
    marker = f"{_BACK_COMMENT_MARKER} **{normalised}**"

    return any(marker in line for line in output.splitlines())


def post_back_comment(
    repo: str,
    issue_number: int,
    spec_id: str,
    fr_path: str,
    impl_path: str,
    epic_id: str | None = None,
    priority: str | None = None,
    status: str = "Planning",
) -> bool:
    """Post a ``Tracked in nspec`` back-comment on a GitHub issue.

    Idempotent: skips if a comment with the marker already exists.

    Args:
        repo: Repository in "owner/repo" format.
        issue_number: Issue number.
        spec_id: Spec ID (e.g., "S367").
        fr_path: Relative path to FR file.
        impl_path: Relative path to IMPL file.
        epic_id: Optional epic ID.
        priority: Optional priority (e.g., "P2").
        status: Current spec status.

    Returns:
        True if comment was posted (or already existed),
        False if posting failed.
    """
    normalised = spec_id.upper() if spec_id.upper().startswith("S") else f"S{spec_id}"

    # Idempotency check
    existing = check_back_comment(repo, issue_number, normalised)
    if existing is True:
        logger.info(
            "%s: back-comment already exists on %s#%d, skipping", normalised, repo, issue_number
        )
        return True

    # Build comment body
    lines = [f"{_BACK_COMMENT_MARKER} **{normalised}**"]
    lines.append(f"FR: `{fr_path}`")
    lines.append(f"IMPL: `{impl_path}`")

    meta_parts: list[str] = []
    if epic_id:
        meta_parts.append(f"Epic: {epic_id}")
    if priority:
        meta_parts.append(f"Priority: {priority}")
    meta_parts.append(f"Status: {status}")
    lines.append(" · ".join(meta_parts))

    comment_body = "\n".join(lines)

    try:
        _run_gh(
            "issue",
            "comment",
            str(issue_number),
            "-R",
            repo,
            "--body",
            comment_body,
            timeout=30,
        )
    except ValueError as e:
        logger.warning(
            "%s: failed to post back-comment on %s#%d: %s", normalised, repo, issue_number, e
        )
        return False

    logger.info("%s: posted back-comment on %s#%d", normalised, repo, issue_number)
    return True


# ============================================================================
# Tracker audit — check back-comments and status consistency
# ============================================================================


@dataclass
class TrackerAuditEntry:
    """A single spec's tracker audit result."""

    spec_id: str
    title: str
    github_ref: str
    link_ok: bool
    back_comment_ok: bool
    state_consistent: bool
    fixed: bool = False  # True if --fix posted a missing back-comment


@dataclass
class TrackerAuditReport:
    """Result of a tracker audit."""

    entries: list[TrackerAuditEntry]
    errors: list[str]


def tracker_audit(
    docs_root: Path,
    repo: str | None = None,
    *,
    fix: bool = False,
    project_root: Path | None = None,
) -> TrackerAuditReport | dict:
    """Walk specs with ``github_issue:`` headers and check back-comments.

    For each spec with a ``github_issue:`` header:
    - Confirm the issue is reachable (link_ok)
    - Check for a ``Tracked in nspec`` back-comment (back_comment_ok)
    - Check status consistency (state_consistent)
    - If ``fix=True``, post missing back-comments

    Args:
        docs_root: Path to docs directory.
        repo: Not currently used (reserved for future bare-number refs).
            Each spec's ``github_issue:`` header contains the full
            ``owner/repo#N`` reference.
        fix: If True, post missing back-comments.
        project_root: Project root for config lookup.

    Returns:
        TrackerAuditReport on success, or error dict on failure.
    """
    gh_err = _check_gh_available()
    if gh_err:
        return {"success": False, "error": gh_err}

    from nspec.domain.datasets import DatasetLoader

    loader = DatasetLoader(docs_root, project_root=project_root)
    datasets = loader.load()

    entries: list[TrackerAuditEntry] = []
    errors: list[str] = []

    # Iterate over all active and completed FRs
    all_frs = list(datasets.active_frs.values()) + list(datasets.completed_frs.values())
    for fr in all_frs:
        spec_id = fr.spec_id
        fr_content = fr.path.read_text(encoding="utf-8")
        github_ref = parse_github_issue_ref(fr_content)
        if not github_ref:
            continue

        parsed = _parse_tracker_ref(github_ref)
        if not parsed:
            errors.append(f"{spec_id}: malformed github_issue ref: {github_ref}")
            continue

        issue_repo, number_str = parsed
        if not number_str.isdigit():
            errors.append(f"{spec_id}: non-numeric issue number in ref: {github_ref}")
            continue
        issue_number = int(number_str)

        # Check link (issue reachable?)
        link_ok = True
        remote_state: str | None = None
        try:
            issue = fetch_issue(issue_repo, issue_number)
            remote_state = issue.state
        except ValueError:
            link_ok = False

        # Check back-comment
        back_comment_ok = False
        if link_ok:
            result = check_back_comment(issue_repo, issue_number, spec_id)
            back_comment_ok = result is True

        # Check status consistency
        state_consistent = True
        if link_ok and remote_state:
            # Determine what the spec status implies
            impl = datasets.get_impl(spec_id)
            impl_status = ""
            if impl:
                impl_content = impl.path.read_text(encoding="utf-8")
                status_match = re.search(r"\*\*Status:\*\*\s*(.+)", impl_content)
                if status_match:
                    impl_status = status_match.group(1).strip()

            status_lower = impl_status.lower()
            # Strip emoji prefix
            for word in status_lower.split():
                if word.isalpha():
                    status_lower = word
                    break

            spec_wants_open = status_lower in {
                "proposed",
                "active",
                "planning",
                "testing",
                "paused",
            }
            spec_wants_closed = status_lower in {
                "completed",
                "ready",
                "superseded",
                "rejected",
            }

            if (remote_state == "OPEN" and spec_wants_closed) or (
                remote_state == "CLOSED" and spec_wants_open
            ):
                state_consistent = False

        # Fix: post missing back-comment
        fixed = False
        if fix and link_ok and not back_comment_ok:
            # Get FR/IMPL paths relative to docs_root
            fr_rel = str(fr.path.relative_to(docs_root.parent))
            impl = datasets.get_impl(spec_id)
            impl_rel = str(impl.path.relative_to(docs_root.parent)) if impl else ""

            posted = post_back_comment(
                repo=issue_repo,
                issue_number=issue_number,
                spec_id=spec_id,
                fr_path=fr_rel,
                impl_path=impl_rel,
            )
            if posted:
                fixed = True
                back_comment_ok = True

        entries.append(
            TrackerAuditEntry(
                spec_id=spec_id,
                title=fr.title,
                github_ref=github_ref,
                link_ok=link_ok,
                back_comment_ok=back_comment_ok,
                state_consistent=state_consistent,
                fixed=fixed,
            )
        )

    return TrackerAuditReport(entries=entries, errors=errors)


# ============================================================================
# Sync audit — cross-reference local specs against GitHub issues
# ============================================================================

# Spec statuses that mean "should be open" on GitHub
_OPEN_STATUSES = frozenset(
    {
        "proposed",
        "active",
        "planning",
        "testing",
        "paused",
    }
)

# Spec statuses that mean "should be closed" on GitHub
_CLOSED_STATUSES = frozenset(
    {
        "completed",
        "ready",
        "superseded",
        "rejected",
    }
)


@dataclass
class SyncEntry:
    """A single spec/issue pairing with mismatch info."""

    spec_id: str
    title: str
    spec_status: str  # e.g., "Active", "Paused"
    github_ref: str | None  # e.g., "owner/repo#42" or None
    issue_state: str | None  # "OPEN" | "CLOSED" | None (if no linked issue)
    mismatch: str  # "local_only" | "diverged" | ""


@dataclass
class OrphanIssue:
    """A GitHub issue with 'imported' label but no linked spec."""

    number: int
    title: str
    url: str
    state: str


@dataclass
class SyncReport:
    """Result of cross-referencing epic specs against GitHub issues."""

    epic_id: str
    repo: str
    local_only: list[SyncEntry]
    diverged: list[SyncEntry]
    orphan_issues: list[OrphanIssue]


def _check_gh_available() -> str | None:
    """Check if gh CLI is available and authenticated.

    Returns:
        None if OK, error message string if not available.
    """
    if not shutil.which("gh"):
        return "gh CLI not found. Install: https://cli.github.com/"
    try:
        subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True,
            text=True,
            timeout=10,
            check=True,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return "gh CLI not authenticated. Run: gh auth login"
    return None


def sync_audit(
    epic_id: str,
    docs_root: Path,
    repo: str,
    *,
    project_root: Path | None = None,
) -> SyncReport | dict:
    """Cross-reference epic specs against GitHub issues.

    For each spec in the epic:
    - If no ``github_issue:`` header → local_only
    - If ``github_issue:`` header exists, check remote state vs local status → diverged

    Also fetches open issues with ``imported`` label and checks for orphans
    (no matching spec).

    Args:
        epic_id: Epic ID (e.g., "E006")
        docs_root: Path to docs directory
        repo: GitHub repo in "owner/repo" format
        project_root: Project root for config lookup

    Returns:
        SyncReport on success, or error dict on failure.
    """
    # Check gh availability
    gh_err = _check_gh_available()
    if gh_err:
        return {"success": False, "error": gh_err}

    # Load epic specs
    from nspec.mutation import get_epic_specs

    try:
        specs = get_epic_specs(epic_id, docs_root, project_root=project_root)
    except (FileNotFoundError, ValueError) as e:
        return {"success": False, "error": str(e)}

    # Read FR files and extract github_issue: refs
    from nspec.domain.datasets import DatasetLoader

    loader = DatasetLoader(docs_root, project_root=project_root)
    datasets = loader.load()

    local_only: list[SyncEntry] = []
    diverged: list[SyncEntry] = []
    # Track linked issues as (repo, number) to avoid cross-repo collisions
    linked_issue_refs: set[tuple[str, int]] = set()

    for spec in specs:
        spec_id = spec["spec_id"]
        title = spec.get("title", "")
        impl_status = spec.get("impl_status", "")

        # Get FR file content to check for github_issue: header
        fr = datasets.get_fr(spec_id)
        if not fr:
            continue

        fr_content = fr.path.read_text(encoding="utf-8")
        github_ref = parse_github_issue_ref(fr_content)

        if not github_ref:
            local_only.append(
                SyncEntry(
                    spec_id=spec_id,
                    title=title,
                    spec_status=impl_status,
                    github_ref=None,
                    issue_state=None,
                    mismatch="local_only",
                )
            )
            continue

        # Parse ref to get issue number
        parts = github_ref.rsplit("#", 1)
        if len(parts) != 2 or not parts[1].isdigit():
            continue

        issue_number = int(parts[1])
        linked_issue_refs.add((parts[0], issue_number))

        # Fetch remote issue state
        try:
            issue = fetch_issue(parts[0], issue_number)
            remote_state = issue.state  # "OPEN" or "CLOSED"
        except ValueError:
            remote_state = None

        # Check for divergence — use FR status if it indicates a terminal state,
        # otherwise fall back to IMPL status
        fr_status = spec.get("fr_status", "")
        fr_status_lower = fr_status.lower()
        for word in fr_status_lower.split():
            if word.isalpha():
                fr_status_lower = word
                break

        # Terminal FR states (Superseded, Rejected, Completed) override IMPL status
        if fr_status_lower in _CLOSED_STATUSES:
            status_lower = fr_status_lower
        else:
            status_lower = impl_status.lower()
            # Strip emoji prefix if present
            for word in status_lower.split():
                if word.isalpha():
                    status_lower = word
                    break

        spec_wants_open = status_lower in _OPEN_STATUSES
        spec_wants_closed = status_lower in _CLOSED_STATUSES

        is_diverged = False
        if remote_state is None:
            # Issue not found / inaccessible — always flag as diverged
            is_diverged = True
        elif (
            remote_state == "OPEN"
            and spec_wants_closed
            or remote_state == "CLOSED"
            and spec_wants_open
        ):
            is_diverged = True

        if is_diverged:
            diverged.append(
                SyncEntry(
                    spec_id=spec_id,
                    title=title,
                    spec_status=impl_status,
                    github_ref=github_ref,
                    issue_state=remote_state,
                    mismatch="diverged",
                )
            )

    # Fetch all open issues with 'imported' label to find orphans
    orphan_issues: list[OrphanIssue] = []
    try:
        remote_issues = fetch_issues(repo, state="open", label="imported", limit=100)
        for issue in remote_issues:
            if (repo, issue.number) not in linked_issue_refs:
                orphan_issues.append(
                    OrphanIssue(
                        number=issue.number,
                        title=issue.title,
                        url=issue.url,
                        state=issue.state,
                    )
                )
    except ValueError as e:
        logger.warning("sync_audit: failed to fetch remote issues: %s", e)

    return SyncReport(
        epic_id=epic_id,
        repo=repo,
        local_only=local_only,
        diverged=diverged,
        orphan_issues=orphan_issues,
    )


def create_issue_from_spec(
    spec_id: str,
    docs_root: Path,
    repo: str,
    *,
    project_root: Path | None = None,
) -> dict:
    """Create a GitHub issue from a spec's FR and write the github_issue: header back.

    Args:
        spec_id: Spec ID (e.g., "S042")
        docs_root: Path to docs directory
        repo: GitHub repo in "owner/repo" format
        project_root: Project root for config lookup

    Returns:
        Dict with success status and issue details, or error.
    """
    # Check gh availability
    gh_err = _check_gh_available()
    if gh_err:
        return {"success": False, "error": gh_err}

    # Load FR
    from nspec.domain.datasets import DatasetLoader

    loader = DatasetLoader(docs_root, project_root=project_root)
    datasets = loader.load()

    fr = datasets.get_fr(spec_id)
    if not fr:
        return {"success": False, "error": f"FR for {spec_id} not found"}

    fr_content = fr.path.read_text(encoding="utf-8")

    # Check if already linked
    existing_ref = parse_github_issue_ref(fr_content)
    if existing_ref:
        return {
            "success": False,
            "error": f"{spec_id} already linked to GitHub issue: {existing_ref}",
        }

    # Extract title and summary for the issue body
    title = fr.title
    # Build issue body from FR executive summary
    body_lines = [f"**nspec spec:** {spec_id}", f"**Priority:** {fr.priority}", ""]

    # Extract executive summary section
    summary_match = re.search(
        r"## Executive Summary\s*\n(.*?)(?=\n## |\Z)",
        fr_content,
        re.DOTALL,
    )
    if summary_match:
        body_lines.append(summary_match.group(1).strip())

    body = "\n".join(body_lines)

    # Create issue via gh CLI
    try:
        raw = _run_gh(
            "issue",
            "create",
            "--repo",
            repo,
            "--title",
            title,
            "--body",
            body,
            "--label",
            "imported",
        )
    except ValueError as e:
        return {"success": False, "error": f"Failed to create issue: {e}"}

    # Parse issue URL from gh output (gh issue create prints the URL)
    issue_url = raw.strip()
    # Extract issue number from URL (e.g., https://github.com/owner/repo/issues/42)
    url_match = re.search(r"/issues/(\d+)", issue_url)
    if not url_match:
        return {
            "success": False,
            "error": f"Could not parse issue number from gh output: {raw}",
        }

    issue_number = int(url_match.group(1))
    github_ref = f"{repo}#{issue_number}"

    # Write github_issue: header back to FR
    lines = fr_content.splitlines(keepends=True)
    result_lines: list[str] = []
    inserted = False
    for line in lines:
        result_lines.append(line)
        if not inserted and line.strip().startswith("deps:"):
            result_lines.append(f"github_issue: {github_ref}\n")
            inserted = True

    fr.path.write_text("".join(result_lines), encoding="utf-8")

    return {
        "success": True,
        "spec_id": spec_id,
        "issue_number": issue_number,
        "issue_url": issue_url,
        "github_ref": github_ref,
    }


# ---------------------------------------------------------------------------
# PR-on-complete workflow (S305)
# ---------------------------------------------------------------------------


def _current_branch(cwd: str | None = None) -> str | None:
    """Return current branch name, or None if detached/not git."""
    try:
        result = subprocess.run(
            ["git", "branch", "--show-current"],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
        )
        branch = result.stdout.strip()
        return branch if branch else None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def build_complete_pr_title(spec_id: str, spec_title: str) -> str:
    """Build PR title for a completed spec."""
    return f"feat({spec_id}): {spec_title}"


def build_complete_pr_body(
    spec_id: str,
    ac_items: list[str] | None = None,
    verdict: str | None = None,
    diff_stat: str | None = None,
) -> str:
    """Build PR body for a completed spec."""
    lines = [f"## {spec_id} — Completion PR", ""]

    if ac_items:
        lines.append("### Acceptance Criteria")
        for ac in ac_items:
            lines.append(f"- [x] {ac}")
        lines.append("")

    if verdict:
        lines.append(f"### Review Verdict: {verdict}")
        lines.append("")

    if diff_stat:
        lines.append("### Files Changed")
        lines.append("```")
        lines.append(diff_stat)
        lines.append("```")
        lines.append("")

    lines.append("Generated by nspec `complete()`")
    return "\n".join(lines)


def create_pr_for_completed_spec(
    spec_id: str,
    spec_title: str,
    ac_items: list[str] | None = None,
    verdict: str | None = None,
    cwd: str | None = None,
) -> str | None:
    """Create a GitHub PR for a completed spec if on a non-main branch.

    Returns PR URL on success, None if on main or skipped.
    Raises ValueError if gh CLI fails (not installed, auth issues, etc.).
    """
    branch = _current_branch(cwd=cwd)
    if branch is None or branch in ("main", "master"):
        return None

    # Push the branch first
    try:
        subprocess.run(
            ["git", "push", "-u", "origin", branch],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
            timeout=60,
        )
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        raise ValueError(f"Failed to push branch {branch}: {e}") from e

    # Get diff stat
    try:
        result = subprocess.run(
            ["git", "diff", "main...HEAD", "--stat"],
            capture_output=True,
            text=True,
            check=False,
            cwd=cwd,
        )
        diff_stat = result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.CalledProcessError, FileNotFoundError):
        diff_stat = None

    title = build_complete_pr_title(spec_id, spec_title)
    body = build_complete_pr_body(spec_id, ac_items, verdict, diff_stat)

    pr_url = _run_gh(
        "pr",
        "create",
        "--title",
        title,
        "--body",
        body,
        "--base",
        "main",
        cwd=cwd,
    )
    return pr_url.strip()
