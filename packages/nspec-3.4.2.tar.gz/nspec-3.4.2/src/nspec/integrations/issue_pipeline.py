"""Issue pipeline dashboard — classify GitHub issues into pipeline stages.

Maps each issue through the nspec lifecycle:
    Open -> Imported -> In Progress -> Resolved -> Closed

Cross-references GitHub issues with nspec specs via the ``github_issue:``
FR header (canonical format: ``owner/repo#number``).

Usage (CLI):
    nspec issue status
    nspec issue status --repo owner/repo
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path

from rich.table import Table

logger = logging.getLogger("nspec")

# Regex for canonical github_ref format: owner/repo#number
_GITHUB_REF_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+#\d+$")

# Spec statuses that map to "In Progress"
_IN_PROGRESS_STATUSES = frozenset({"active", "testing"})

# Spec statuses that map to "Resolved"
_RESOLVED_STATUSES = frozenset({"completed", "ready"})

# Spec statuses that map to "Imported" (has spec but not yet active)
_IMPORTED_STATUSES = frozenset({"proposed", "planning", "paused"})


class PipelineStage(Enum):
    """Pipeline stages for issue lifecycle tracking."""

    OPEN = "Open"
    IMPORTED = "Imported"
    IN_PROGRESS = "In Progress"
    RESOLVED = "Resolved"
    CLOSED = "Closed"
    WARNING = "Warning"


@dataclass
class PipelineEntry:
    """A single issue mapped to a pipeline stage."""

    issue_number: int | None  # None for local-only entries
    title: str
    stage: PipelineStage
    spec_id: str | None  # None for open issues without specs
    created_at: datetime | None  # Issue creation timestamp
    age_days: int  # Age in days from created_at to now
    warning: str | None = None  # Warning message for malformed refs


@dataclass
class StageSummary:
    """Aggregated summary for a pipeline stage."""

    stage: PipelineStage
    count: int
    issue_numbers: list[int]
    spec_ids: list[str]
    oldest_days: int | None  # None if no entries
    avg_days: int | None  # None if no entries
    warnings: list[str] = field(default_factory=list)


def _normalize_impl_status(status: str) -> str:
    """Extract bare status word from emoji-prefixed status string."""
    lower = status.lower()
    for word in lower.split():
        if word.isalpha():
            return word
    return lower


def classify_pipeline(
    issues: list[dict],
    spec_refs: dict[str, tuple[str, str]],
    *,
    now: datetime | None = None,
) -> list[PipelineEntry]:
    """Classify issues into pipeline stages.

    Args:
        issues: List of issue dicts with keys: number, title, state,
                created_at (ISO string or None), labels.
        spec_refs: Mapping of ``owner/repo#number`` -> ``(spec_id, impl_status)``.
                   Built from FR ``github_issue:`` headers.
        now: Current time for age calculation (default: utcnow).

    Returns:
        List of PipelineEntry, one per issue.
    """
    if now is None:
        now = datetime.now(UTC)

    entries: list[PipelineEntry] = []

    for issue in issues:
        number = issue["number"]
        title = issue.get("title", "")
        state = issue.get("state", "OPEN").upper()
        created_str = issue.get("created_at")
        repo = issue.get("repo", "")

        # Calculate age
        age_days = 0
        created_at = None
        if created_str:
            try:
                created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
                age_days = max(0, (now - created_at).days)
            except (ValueError, TypeError):
                pass

        # Closed issues go to Closed stage regardless
        if state == "CLOSED":
            ref_key = f"{repo}#{number}"
            spec_id = spec_refs.get(ref_key, (None, None))[0] if ref_key in spec_refs else None
            entries.append(
                PipelineEntry(
                    issue_number=number,
                    title=title,
                    stage=PipelineStage.CLOSED,
                    spec_id=spec_id,
                    created_at=created_at,
                    age_days=age_days,
                )
            )
            continue

        # Check if issue has a linked spec
        ref_key = f"{repo}#{number}"
        if ref_key in spec_refs:
            spec_id, impl_status = spec_refs[ref_key]
            status_word = _normalize_impl_status(impl_status)

            if status_word in _RESOLVED_STATUSES:
                stage = PipelineStage.RESOLVED
            elif status_word in _IN_PROGRESS_STATUSES:
                stage = PipelineStage.IN_PROGRESS
            else:
                stage = PipelineStage.IMPORTED

            entries.append(
                PipelineEntry(
                    issue_number=number,
                    title=title,
                    stage=stage,
                    spec_id=spec_id,
                    created_at=created_at,
                    age_days=age_days,
                )
            )
        else:
            # No linked spec — Open
            entries.append(
                PipelineEntry(
                    issue_number=number,
                    title=title,
                    stage=PipelineStage.OPEN,
                    spec_id=None,
                    created_at=created_at,
                    age_days=age_days,
                )
            )

    return entries


def build_spec_refs(
    docs_root: Path,
    *,
    project_root: Path | None = None,
) -> dict[str, tuple[str, str]]:
    """Build mapping of github_ref -> (spec_id, impl_status) from local specs.

    Scans all active FRs for ``github_issue:`` headers and cross-references
    with IMPL status.

    Args:
        docs_root: Path to docs directory.
        project_root: Project root for config lookup.

    Returns:
        Dict mapping ``owner/repo#number`` to ``(spec_id, impl_status)``.
    """
    from nspec.domain.datasets import DatasetLoader
    from nspec.integrations.github import parse_github_issue_ref

    loader = DatasetLoader(docs_root, project_root=project_root)
    datasets = loader.load()

    refs: dict[str, tuple[str, str]] = {}
    malformed: list[tuple[str, str]] = []

    for spec_id, fr in datasets.active_frs.items():
        try:
            content = fr.path.read_text(encoding="utf-8")
        except OSError:
            continue

        github_ref = parse_github_issue_ref(content)
        if not github_ref:
            continue

        # Validate format
        if not _GITHUB_REF_RE.match(github_ref):
            malformed.append((spec_id, github_ref))
            continue

        # Get IMPL status
        impl = datasets.get_impl(spec_id)
        impl_status = impl.status if impl else "Planning"

        refs[github_ref] = (spec_id, impl_status)

    # Also check completed specs
    for spec_id, fr in datasets.completed_frs.items():
        try:
            content = fr.path.read_text(encoding="utf-8")
        except OSError:
            continue

        github_ref = parse_github_issue_ref(content)
        if not github_ref:
            continue

        if not _GITHUB_REF_RE.match(github_ref):
            malformed.append((spec_id, github_ref))
            continue

        impl = datasets.get_impl(spec_id)
        impl_status = impl.status if impl else "Completed"

        refs[github_ref] = (spec_id, impl_status)

    if malformed:
        for spec_id, ref in malformed:
            logger.warning("%s: malformed github_ref '%s' — skipped", spec_id, ref)

    return refs


def get_malformed_refs(
    docs_root: Path,
    *,
    project_root: Path | None = None,
) -> list[PipelineEntry]:
    """Get pipeline warning entries for specs with malformed github_ref.

    Args:
        docs_root: Path to docs directory.
        project_root: Project root for config lookup.

    Returns:
        List of PipelineEntry with WARNING stage for malformed refs.
    """
    from nspec.domain.datasets import DatasetLoader
    from nspec.integrations.github import parse_github_issue_ref

    loader = DatasetLoader(docs_root, project_root=project_root)
    datasets = loader.load()

    warnings: list[PipelineEntry] = []

    # Scan both active and completed FRs
    all_frs = list(datasets.active_frs.items()) + list(datasets.completed_frs.items())
    for spec_id, fr in all_frs:
        try:
            content = fr.path.read_text(encoding="utf-8")
        except OSError:
            continue

        github_ref = parse_github_issue_ref(content)
        if github_ref and not _GITHUB_REF_RE.match(github_ref):
            warnings.append(
                PipelineEntry(
                    issue_number=None,
                    title=fr.title,
                    stage=PipelineStage.WARNING,
                    spec_id=spec_id,
                    created_at=None,
                    age_days=0,
                    warning=f"Malformed github_ref: {github_ref}",
                )
            )

    return warnings


def compute_stage_summaries(
    entries: list[PipelineEntry],
) -> list[StageSummary]:
    """Group pipeline entries by stage and compute summary metrics.

    Args:
        entries: List of PipelineEntry from classify_pipeline.

    Returns:
        List of StageSummary, one per stage (in pipeline order).
        Empty stages are included with zero counts.
    """
    # Group by stage
    by_stage: dict[PipelineStage, list[PipelineEntry]] = {
        stage: [] for stage in PipelineStage if stage != PipelineStage.WARNING
    }
    warning_entries: list[PipelineEntry] = []

    for entry in entries:
        if entry.stage == PipelineStage.WARNING:
            warning_entries.append(entry)
        else:
            by_stage.setdefault(entry.stage, []).append(entry)

    # Build summaries in pipeline order
    stage_order = [
        PipelineStage.OPEN,
        PipelineStage.IMPORTED,
        PipelineStage.IN_PROGRESS,
        PipelineStage.RESOLVED,
        PipelineStage.CLOSED,
    ]

    summaries: list[StageSummary] = []
    for stage in stage_order:
        stage_entries = by_stage.get(stage, [])
        issue_numbers = sorted(
            [e.issue_number for e in stage_entries if e.issue_number is not None]
        )
        spec_ids = sorted([e.spec_id for e in stage_entries if e.spec_id is not None])
        ages = [e.age_days for e in stage_entries if e.age_days > 0]

        oldest = max(ages) if ages else None
        avg = round(sum(ages) / len(ages)) if ages else None

        warnings_list = (
            [e.warning for e in warning_entries if e.warning] if stage == PipelineStage.OPEN else []
        )

        summaries.append(
            StageSummary(
                stage=stage,
                count=len(stage_entries),
                issue_numbers=issue_numbers,
                spec_ids=spec_ids,
                oldest_days=oldest,
                avg_days=avg,
                warnings=warnings_list,
            )
        )

    # Add warning summary if there are malformed refs
    if warning_entries:
        summaries.append(
            StageSummary(
                stage=PipelineStage.WARNING,
                count=len(warning_entries),
                issue_numbers=[],
                spec_ids=[e.spec_id for e in warning_entries if e.spec_id],
                oldest_days=None,
                avg_days=None,
                warnings=[e.warning or "" for e in warning_entries],
            )
        )

    return summaries


def _format_age(days: int | None) -> str:
    """Format age in days to human-readable string."""
    if days is None:
        return "\u2014"
    if days == 0:
        return "<1d"
    return f"{days}d"


def _format_issues(numbers: list[int], max_show: int = 5) -> str:
    """Format issue numbers as comma-separated list."""
    if not numbers:
        return "\u2014"
    shown = [f"#{n}" for n in numbers[:max_show]]
    result = ",".join(shown)
    if len(numbers) > max_show:
        result += f" +{len(numbers) - max_show}"
    return result


def _format_specs(spec_ids: list[str], max_show: int = 5) -> str:
    """Format spec IDs as comma-separated list."""
    if not spec_ids:
        return "\u2014"
    shown = spec_ids[:max_show]
    result = ",".join(shown)
    if len(spec_ids) > max_show:
        result += f" +{len(spec_ids) - max_show}"
    return result


def render_pipeline_table(
    summaries: list[StageSummary],
    repo: str,
) -> Table:
    """Render pipeline summaries as a Rich Table.

    Args:
        summaries: Stage summaries from compute_stage_summaries.
        repo: Repository name for the title.

    Returns:
        Rich Table ready for printing.
    """
    table = Table(title=f"Issue Pipeline ({repo})")
    table.add_column("Stage", style="bold")
    table.add_column("Count", justify="right")
    table.add_column("Issues")
    table.add_column("Specs")
    table.add_column("Oldest", justify="right")
    table.add_column("Avg Age", justify="right")

    for summary in summaries:
        if summary.stage == PipelineStage.WARNING:
            # Render warning rows
            for idx, warning in enumerate(summary.warnings):
                spec = summary.spec_ids[idx] if idx < len(summary.spec_ids) else "\u2014"
                table.add_row(
                    "[dim]Warning[/dim]",
                    "",
                    "\u2014",
                    spec,
                    "\u2014",
                    f"[dim]{warning}[/dim]",
                )
            continue

        table.add_row(
            summary.stage.value,
            str(summary.count),
            _format_issues(summary.issue_numbers),
            _format_specs(summary.spec_ids),
            _format_age(summary.oldest_days),
            _format_age(summary.avg_days),
        )

    return table


def run_pipeline_status(
    repo: str,
    docs_root: Path,
    *,
    project_root: Path | None = None,
) -> Table:
    """Run the full pipeline status: fetch, classify, render.

    This is the main entry point called by the CLI handler.

    Args:
        repo: GitHub repository in ``owner/repo`` format.
        docs_root: Path to docs directory.
        project_root: Project root for config lookup.

    Returns:
        Rich Table with pipeline status.

    Raises:
        ValueError: If repo is not configured.
    """
    from nspec.integrations.github import fetch_issues

    # Build spec refs from local data
    spec_refs = build_spec_refs(docs_root, project_root=project_root)

    # Get malformed ref warnings
    malformed_warnings = get_malformed_refs(docs_root, project_root=project_root)

    # Try to fetch issues from GitHub
    github_available = True
    all_issues: list[dict] = []
    try:
        # Fetch both open and closed issues
        open_issues = fetch_issues(repo, state="open", limit=100)
        closed_issues = fetch_issues(repo, state="closed", limit=100)

        for issue in open_issues + closed_issues:
            all_issues.append(
                {
                    "number": issue.number,
                    "title": issue.title,
                    "state": issue.state,
                    "created_at": issue.created_at,
                    "repo": issue.repo,
                }
            )
    except ValueError as e:
        logger.warning("GitHub API unavailable: %s", e)
        github_available = False

    if github_available:
        # Normal mode: classify from GitHub issues
        entries = classify_pipeline(all_issues, spec_refs)
    else:
        # Degraded mode: build entries from local spec data only
        entries = _build_degraded_entries(spec_refs)
        # Add a warning entry for GitHub unavailability
        malformed_warnings.append(
            PipelineEntry(
                issue_number=None,
                title="",
                stage=PipelineStage.WARNING,
                spec_id=None,
                created_at=None,
                age_days=0,
                warning="GitHub unavailable \u2014 showing local data only",
            )
        )

    # Combine entries with malformed warnings
    all_entries = entries + malformed_warnings

    # Compute summaries and render
    summaries = compute_stage_summaries(all_entries)
    return render_pipeline_table(summaries, repo)


def _build_degraded_entries(
    spec_refs: dict[str, tuple[str, str]],
) -> list[PipelineEntry]:
    """Build pipeline entries from local data only (degraded mode).

    When GitHub is unavailable, we can still show Imported, In Progress,
    and Resolved stages from local spec status data.

    Args:
        spec_refs: Mapping of github_ref -> (spec_id, impl_status).

    Returns:
        List of PipelineEntry from local data.
    """
    entries: list[PipelineEntry] = []

    for ref, (spec_id, impl_status) in spec_refs.items():
        # Parse issue number from ref
        parts = ref.rsplit("#", 1)
        issue_number = int(parts[1]) if len(parts) == 2 and parts[1].isdigit() else None

        status_word = _normalize_impl_status(impl_status)

        if status_word in _RESOLVED_STATUSES:
            stage = PipelineStage.RESOLVED
        elif status_word in _IN_PROGRESS_STATUSES:
            stage = PipelineStage.IN_PROGRESS
        else:
            stage = PipelineStage.IMPORTED

        entries.append(
            PipelineEntry(
                issue_number=issue_number,
                title="",
                stage=stage,
                spec_id=spec_id,
                created_at=None,
                age_days=0,
            )
        )

    return entries
