import asyncio
from xnoted.sync.syncProvider import SyncProvider
from xnoted.sync.mongodbSyncHandler import MongoDBSyncHandler


async def main() -> None:
    mongoDBSyncHandler = MongoDBSyncHandler()
    sync = SyncProvider(sync=mongoDBSyncHandler)
    await sync.initialize()
    await sync.push()


if __name__ == "__main__":
    asyncio.run(main())
