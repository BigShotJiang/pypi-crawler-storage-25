from openreward.api.environments.client import convert_tool_response


def _walk(obj):
    if isinstance(obj, dict):
        t = obj.get("type")
        if t == "array" or (isinstance(t, list) and "array" in t):
            assert "items" in obj, f"array schema missing items: {obj}"
        for v in obj.values():
            _walk(v)
    elif isinstance(obj, list):
        for v in obj:
            _walk(v)


def test_openai_array_schemas_always_have_items():
    res = {
        "tools": [
            {
                "name": "search",
                "description": "Search things",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "tags": {
                            "anyOf": [
                                {"type": "array"},
                                {"type": "null"},
                            ]
                        },
                        "ids": {"type": ["array", "null"]},
                        "filters": {
                            "type": "object",
                            "properties": {
                                "values": {"type": "array"},
                            },
                        },
                    },
                },
            }
        ]
    }

    converted = convert_tool_response(res, format="openai")
    assert len(converted) == 1
    _walk(converted[0]["parameters"])


def test_openrouter_array_schemas_always_have_items():
    res = {"tools": [{"name": "x", "input_schema": {"type": "array"}}]}
    converted = convert_tool_response(res, format="openrouter")
    _walk(converted[0]["parameters"])
