"""Sandbox template assets."""
