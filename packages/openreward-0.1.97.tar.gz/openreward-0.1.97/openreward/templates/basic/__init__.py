"""Basic template assets."""
