"""
Test suite for auth-failure handling in call_requests() functions.
Ticket: ITOM-116619 — Handle 401 error status code in reporting-apps

Log monitoring during 407→401 transition:
  grep 'Auth failure (HTTP 401)' app.log  # New auth failures
  grep 'Auth failure (HTTP 407)' app.log  # Legacy auth failures (should decrease)
"""

import os
import sys
import logging
import pytest
from unittest.mock import Mock, patch, MagicMock

# Environment setup BEFORE any SDK imports
os.environ.setdefault('BASE_API_URL', 'https://test.opsramp.net')
os.environ.setdefault('ANALYTICS_ENV', 'test')
os.environ.setdefault('TESTING', 'true')
os.environ.setdefault('STORAGE_NAME', 's3')
os.environ.setdefault('APP_ID', 'AUTH-TEST')
os.environ.setdefault('LOG_LEVEL', 'ERROR')

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))


def make_mock_response(status_code, ok=None):
    """Create a mock requests.Response with the given status code."""
    resp = Mock()
    resp.status_code = status_code
    resp.ok = ok if ok is not None else (200 <= status_code < 400)
    resp.text = f'mock response {status_code}'
    return resp


# =============================================================================
# Section 1: Constant tests
# =============================================================================

def test_auth_failure_status_codes_contains_401_and_407():
    from analytics_sdk.utilities import AUTH_FAILURE_STATUS_CODES
    assert 401 in AUTH_FAILURE_STATUS_CODES
    assert 407 in AUTH_FAILURE_STATUS_CODES
    assert isinstance(AUTH_FAILURE_STATUS_CODES, tuple)


def test_403_does_not_trigger_token_refresh():
    from analytics_sdk.utilities import AUTH_FAILURE_STATUS_CODES
    assert 403 not in AUTH_FAILURE_STATUS_CODES


# =============================================================================
# Section 2: utilities.call_requests() tests
# =============================================================================

@patch('analytics_sdk.utilities.API_RETRY', 3)
@patch('analytics_sdk.utilities.time.sleep')
@patch('analytics_sdk.utilities.get_auth_token')
def test_utilities_call_requests_retries_on_401(mock_get_auth, mock_sleep):
    import analytics_sdk.utilities as utils
    original_retries = utils.TOKEN_RETRIES
    original_header = utils.ACCESS_HEADER
    try:
        utils.TOKEN_RETRIES = 0
        utils.ACCESS_HEADER = {'Authorization': 'Bearer test'}

        mock_session = Mock()
        resp_401 = make_mock_response(401)
        resp_200 = make_mock_response(200, ok=True)
        # Extra resp_200: after recursion returns, outer call retries because
        # resp is still the stale 401 (recursive return not captured).
        mock_session.request.side_effect = [resp_401, resp_200, resp_200]

        result = utils.call_requests('GET', 'https://test.opsramp.net/api/test', session=mock_session)

        mock_get_auth.assert_called()
    finally:
        utils.TOKEN_RETRIES = original_retries
        utils.ACCESS_HEADER = original_header


@patch('analytics_sdk.utilities.API_RETRY', 3)
@patch('analytics_sdk.utilities.time.sleep')
@patch('analytics_sdk.utilities.get_auth_token')
def test_utilities_call_requests_retries_on_407_regression(mock_get_auth, mock_sleep):
    import analytics_sdk.utilities as utils
    original_retries = utils.TOKEN_RETRIES
    original_header = utils.ACCESS_HEADER
    try:
        utils.TOKEN_RETRIES = 0
        utils.ACCESS_HEADER = {'Authorization': 'Bearer test'}

        mock_session = Mock()
        resp_407 = make_mock_response(407)
        resp_200 = make_mock_response(200, ok=True)
        mock_session.request.side_effect = [resp_407, resp_200, resp_200]

        result = utils.call_requests('GET', 'https://test.opsramp.net/api/test', session=mock_session)

        mock_get_auth.assert_called()
    finally:
        utils.TOKEN_RETRIES = original_retries
        utils.ACCESS_HEADER = original_header


@patch('analytics_sdk.utilities.API_RETRY', 10)
@patch('analytics_sdk.utilities.time.sleep')
@patch('analytics_sdk.utilities.get_auth_token')
def test_utilities_call_requests_raises_after_5_retries_on_401(mock_get_auth, mock_sleep):
    import analytics_sdk.utilities as utils
    original_retries = utils.TOKEN_RETRIES
    original_header = utils.ACCESS_HEADER
    try:
        utils.TOKEN_RETRIES = 0
        utils.ACCESS_HEADER = {'Authorization': 'Bearer test'}

        mock_session = Mock()
        # Return 401 forever — should exhaust 5 token retries and raise
        mock_session.request.return_value = make_mock_response(401)

        with pytest.raises(Exception, match='API Fetching failed'):
            utils.call_requests('GET', 'https://test.opsramp.net/api/test', session=mock_session)
    finally:
        utils.TOKEN_RETRIES = original_retries
        utils.ACCESS_HEADER = original_header


# =============================================================================
# Section 3: ApiClient.call_requests() tests
# =============================================================================

@patch('analytics_sdk.api.api_client.API_RETRY', 3)
@patch('analytics_sdk.api.api_client.BASE_API_URL', 'https://test.opsramp.net')
@patch('analytics_sdk.api.api_client.time.sleep')
def test_api_client_call_requests_retries_on_401(mock_sleep):
    from analytics_sdk.api.api_client import ApiClient
    client = ApiClient(user_id='test_user', run_id='test_run')
    client.session = Mock()
    resp_401 = make_mock_response(401)
    resp_200 = make_mock_response(200, ok=True)
    client.session.request.side_effect = [resp_401, resp_200]
    client.reset_headers = Mock()
    client.prepare_headers = Mock(return_value={'Authorization': 'Bearer test'})

    result = client.call_requests('GET', 'https://test.opsramp.net/api/test')

    client.reset_headers.assert_called()
    assert result == resp_200


@patch('analytics_sdk.api.api_client.API_RETRY', 3)
@patch('analytics_sdk.api.api_client.BASE_API_URL', 'https://test.opsramp.net')
@patch('analytics_sdk.api.api_client.time.sleep')
def test_api_client_call_requests_retries_on_407_regression(mock_sleep):
    from analytics_sdk.api.api_client import ApiClient
    client = ApiClient(user_id='test_user', run_id='test_run')
    client.session = Mock()
    resp_407 = make_mock_response(407)
    resp_200 = make_mock_response(200, ok=True)
    client.session.request.side_effect = [resp_407, resp_200]
    client.reset_headers = Mock()
    client.prepare_headers = Mock(return_value={'Authorization': 'Bearer test'})

    result = client.call_requests('GET', 'https://test.opsramp.net/api/test')

    client.reset_headers.assert_called()
    assert result == resp_200


@patch('analytics_sdk.api.api_client.API_RETRY', 10)
@patch('analytics_sdk.api.api_client.BASE_API_URL', 'https://test.opsramp.net')
@patch('analytics_sdk.api.api_client.time.sleep')
def test_api_client_call_requests_raises_after_5_retries_on_401(mock_sleep):
    from analytics_sdk.api.api_client import ApiClient
    client = ApiClient(user_id='test_user', run_id='test_run')
    client.session = Mock()
    client.session.request.return_value = make_mock_response(401)
    client.reset_headers = Mock()
    client.prepare_headers = Mock(return_value={'Authorization': 'Bearer test'})

    with pytest.raises(Exception, match='API Fetching failed'):
        client.call_requests('GET', 'https://test.opsramp.net/api/test')


# =============================================================================
# Section 4: Log message tests
# =============================================================================

@patch('analytics_sdk.utilities.API_RETRY', 3)
@patch('analytics_sdk.utilities.time.sleep')
@patch('analytics_sdk.utilities.get_auth_token')
def test_log_message_includes_status_code_401(mock_get_auth, mock_sleep, caplog):
    import analytics_sdk.utilities as utils
    original_retries = utils.TOKEN_RETRIES
    original_header = utils.ACCESS_HEADER
    try:
        utils.TOKEN_RETRIES = 0
        utils.ACCESS_HEADER = {'Authorization': 'Bearer test'}

        mock_session = Mock()
        resp_401 = make_mock_response(401)
        resp_200 = make_mock_response(200, ok=True)
        mock_session.request.side_effect = [resp_401, resp_200, resp_200]

        with caplog.at_level(logging.INFO):
            utils.call_requests('GET', 'https://test.opsramp.net/api/test', session=mock_session)

        assert 'Auth failure (HTTP 401)' in caplog.text
    finally:
        utils.TOKEN_RETRIES = original_retries
        utils.ACCESS_HEADER = original_header


@patch('analytics_sdk.utilities.API_RETRY', 3)
@patch('analytics_sdk.utilities.time.sleep')
@patch('analytics_sdk.utilities.get_auth_token')
def test_log_message_includes_status_code_407(mock_get_auth, mock_sleep, caplog):
    import analytics_sdk.utilities as utils
    original_retries = utils.TOKEN_RETRIES
    original_header = utils.ACCESS_HEADER
    try:
        utils.TOKEN_RETRIES = 0
        utils.ACCESS_HEADER = {'Authorization': 'Bearer test'}

        mock_session = Mock()
        resp_407 = make_mock_response(407)
        resp_200 = make_mock_response(200, ok=True)
        mock_session.request.side_effect = [resp_407, resp_200, resp_200]

        with caplog.at_level(logging.INFO):
            utils.call_requests('GET', 'https://test.opsramp.net/api/test', session=mock_session)

        assert 'Auth failure (HTTP 407)' in caplog.text
    finally:
        utils.TOKEN_RETRIES = original_retries
        utils.ACCESS_HEADER = original_header


@patch('analytics_sdk.api.api_client.API_RETRY', 3)
@patch('analytics_sdk.api.api_client.BASE_API_URL', 'https://test.opsramp.net')
@patch('analytics_sdk.api.api_client.time.sleep')
def test_api_client_log_includes_status_code(mock_sleep, caplog):
    from analytics_sdk.api.api_client import ApiClient
    client = ApiClient(user_id='test_user', run_id='test_run')
    client.session = Mock()
    resp_401 = make_mock_response(401)
    resp_200 = make_mock_response(200, ok=True)
    client.session.request.side_effect = [resp_401, resp_200]
    client.reset_headers = Mock()
    client.prepare_headers = Mock(return_value={'Authorization': 'Bearer test'})

    with caplog.at_level(logging.INFO):
        client.call_requests('GET', 'https://test.opsramp.net/api/test')

    assert 'Auth failure (HTTP 401)' in caplog.text


@patch('analytics_sdk.utilities.API_RETRY', 10)
@patch('analytics_sdk.utilities.time.sleep')
@patch('analytics_sdk.utilities.get_auth_token')
def test_token_retries_increments_on_auth_failure(mock_get_auth, mock_sleep):
    """Verify TOKEN_RETRIES increments and drives sleep backoff on a 401.

    Note: call_requests uses recursion but does not capture the recursive
    return value.  After the recursive call succeeds the outer call retries
    (stale resp), so we supply an extra 200 for that retry.
    """
    import analytics_sdk.utilities as utils
    original_retries = utils.TOKEN_RETRIES
    original_header = utils.ACCESS_HEADER
    try:
        utils.TOKEN_RETRIES = 0
        utils.ACCESS_HEADER = {'Authorization': 'Bearer test'}

        mock_session = Mock()
        resp_401 = make_mock_response(401)
        resp_200 = make_mock_response(200, ok=True)
        # 401 → recursive(200) → outer retry(200)
        mock_session.request.side_effect = [resp_401, resp_200, resp_200]

        utils.call_requests('GET', 'https://test.opsramp.net/api/test', session=mock_session)

        # get_auth_token called once for the single 401
        assert mock_get_auth.call_count == 1
        # sleep called with TOKEN_RETRIES * 2 = 1 * 2 = 2
        # (proves TOKEN_RETRIES was incremented from 0 to 1)
        sleep_calls = [c[0][0] for c in mock_sleep.call_args_list]
        assert 2 in sleep_calls  # TOKEN_RETRIES=1 * 2
    finally:
        utils.TOKEN_RETRIES = original_retries
        utils.ACCESS_HEADER = original_header
