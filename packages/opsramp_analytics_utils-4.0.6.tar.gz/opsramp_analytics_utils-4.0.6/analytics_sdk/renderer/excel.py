import os
import json
import time
import random
import dateutil.parser
from datetime import datetime
import requests
import logging
logger = logging.getLogger(__name__)

from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter
from openpyxl.chart.label import DataLabelList, DataLabel
from openpyxl.chart import (
    DoughnutChart,
    ScatterChart,
    BarChart,
    Reference,
    Series,
    LineChart,
    PieChart
)
from openpyxl.chart.series import DataPoint
from openpyxl.drawing.spreadsheet_drawing import OneCellAnchor
from openpyxl.utils.units import cm_to_EMU
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
import re
from decimal import Decimal
from fractions import Fraction

from analytics_sdk.utilities import (
    BASE_API_URL,
    APP_ID,
    API_KEY,
    API_SECRET,
    API_RETRY,
    API_TIME_STACKS,
    APP_DISPLAY_NAME
)

chart_colors = ["0077C8", "e35420", "32a3df", "673ab7", "9c27b0", "F5BE0A","e30255","a002e3","0079e3","05e3a8","f5d255","f36686","c661e9","24a5ed","62ecbf","F7E487","fb9fb5","e39df0","79ccef","91F4D5","f8ba7e","f3a5ea","cd91eb","87E4F0","cdf38d","f78f4a","eb6dd6","9352e5","5ad1e9","afeb5a","f55a22","e302be","6834E3","02bee3","8ae305"]

class ExcelRenderer:
    ROW_START = 3
    global res
    res = ''
    def __init__(self, analysis_run, tenantId, additional_props, excel_data, report_gen_start_time, report_gen_completed_time):
        """
        :param analysis_run: AnalysisRun
        """
        self.wb = Workbook()
        self.analysis_run = analysis_run
        self.tenantId = tenantId
        self.excel_data = excel_data
        self.report_gen_start_time = report_gen_start_time
        self.report_gen_completed_time = report_gen_completed_time
        self.additional_props = additional_props

        def get_token():
            headers = {"Content-Type" : "application/x-www-form-urlencoded" , "Accept" : "application/json"};
            post_data = {"grant_type": "client_credentials", "client_id" : API_KEY, "client_secret" : API_SECRET};
            token_url = BASE_API_URL + "/tenancy/auth/oauth/token";
            response = requests.post(token_url,data=post_data,headers=headers,verify=False);
            json = response.json();
            auth = str(json["access_token"])
            return auth


        def get_headers():
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': f'Bearer {get_token()}'
            }

            return headers

        def call_requests(method, url, params=None, data=None, json=None, verify=True):
            headers = get_headers()
            retry = 1
            resp = None
            while retry <= API_RETRY:
                try:
                    resp = requests.request(method, url, params=params, data=data, json=json, headers=headers, verify=verify)
                    if not resp.ok:
                        time.sleep(retry * 2)
                        retry+=1
                        continue
                except requests.exceptions.ConnectionError:
                    time.sleep(retry * 2)
                    retry+=1
                    continue

                return resp

            return resp


        def diff_sec(st, et):
            difference = int(et - st)
            return difference

        url = BASE_API_URL + f'/reporting/api/v3/tenants/{tenantId}/runs/{analysis_run}/summary'
        api_proce_before_time = time.time()
        res = call_requests('GET', url)
        if res == None or not res.ok:
            logger.info('Get excel summary is failed')
            raise Exception("Get excel summary API FAILED", res)
        else:
            logger.info('Get excel summary API response is %s', res)
        api_proce_after_time = time.time()
        api_proce_diff = diff_sec(api_proce_before_time, api_proce_after_time)
        if api_proce_diff > API_TIME_STACKS:
            logging.info('Get excel summary API response took %d (greater than %d) seconds', api_proce_diff, API_TIME_STACKS)

        self.res = res

    def get_value(self, value):
        if value:
            try:
                value = float(value)
                return value
            except ValueError:
                return value
        return value


    def _load_data(self, ws, data, row_start, col_start, adjust_column=True, x_axis_date_format=None):
        column_widths = {}
        fixed_col_width = getattr(self, '_current_sheet_fixed_columns', None) if self._is_metered_usage else None
        if isinstance(data, list):
            if len(data) >= 1000005:
                data = data[0:1000005]

        for row_delta, row in enumerate(data):
            if self._is_metered_usage:
                ws.row_dimensions[row_start + row_delta].height = 20
            for col_delta, val in enumerate(row):
                col = col_start + col_delta
                cell = ws.cell(row=row_start+row_delta, column=col)
                if self._is_metered_usage:
                    cell.font = Font(size=14)
                    if fixed_col_width and len(str(val)) > fixed_col_width:
                        cell.alignment = Alignment(wrap_text=True, vertical='top')
                if x_axis_date_format and row_delta > 0 and col_delta == 0:
                    cell.value = datetime.strptime(val, x_axis_date_format).date()
                else:
                    try:
                        if APP_ID == 'AVAILABILITY-DETAILS':
                            if isinstance(val, str) and 'COLOR-CODE_' in val:
                                vals = val.split('_') #COLOR-CODE_{color_code}_{value}
                                if len(vals) == 3:
                                    val = vals[2]
                                    if vals[1] is not None and len(vals[1]):
                                        cell.fill = PatternFill("solid", fgColor=vals[1])
                        cell.value = self.get_value(val)
                    except Exception as e:
                        if isinstance(val, str):
                            cell.value = ILLEGAL_CHARACTERS_RE.sub(r'', val)
                        else:
                            cell.value = self.get_value(val)
                if col in column_widths:
                    column_widths[col] = max(len(str(val)), column_widths[col])
                else:
                    column_widths[col] = max(len(str(val)), ws.column_dimensions[get_column_letter(col)].width)
        # handle cell width
        if adjust_column:
            for col, column_width in column_widths.items():
                if self._is_metered_usage:
                    new_width = int(column_width * 1.1) + 3
                    if fixed_col_width:
                        new_width = min(new_width, fixed_col_width)
                    current_width = ws.column_dimensions[get_column_letter(col)].width
                    ws.column_dimensions[get_column_letter(col)].width = max(new_width, current_width)
                else:
                    ws.column_dimensions[get_column_letter(col)].width = column_width + 2

    # Outer border thickness — change this to control outer border everywhere: 'thin', 'medium', 'thick'
    OUTER_BORDER_STYLE = 'medium'

    THIN_BORDER = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    # Color map for named colors used in component title-color
    COLOR_MAP = {
        'green': '00B050',
        'red': '00598B',
        'blue': '00598B',
        'white': 'FFFFFF',
        'grey': 'CCCCCC',
    }

    # Section header styles: green background with white bold font
    SECTION_HEADER_FILL_COLORS = {'green'}

    # Gap between data table and chart (1 cm)
    CHART_TABLE_GAP_CM = 1

    # Chart types that use pixel-based anchoring (1cm after data table)
    PIXEL_ANCHOR_CHART_TYPES = ('doughnut-chart', 'bar-chart')

    def _place_chart(self, ws, chart, chart_data, col_start, row_start):
        """Place chart using pixel-based anchoring for metered-usage apps.
        Positions chart exactly 1cm after the data table's last column.
        Only applies to bar and doughnut charts; all others use cell-address positioning."""
        chart_type = chart_data.get('type', '')
        if self._is_metered_usage and chart_type in self.PIXEL_ANCHOR_CHART_TYPES:
            data = chart_data.get('data', [])
            data_col_count = len(data[0]) if isinstance(data, list) and len(data) > 0 else 2
            # 0-based column index: after the last data column
            anchor_col = col_start + data_col_count - 1  # col_start is 1-based, OneCellAnchor is 0-based
            anchor_row = row_start - 1  # convert 1-based to 0-based
            anchor = OneCellAnchor()
            anchor._from.col = anchor_col
            anchor._from.colOff = cm_to_EMU(self.CHART_TABLE_GAP_CM)
            anchor._from.row = anchor_row
            anchor._from.rowOff = 0
            anchor.ext.width = cm_to_EMU(chart.width)
            anchor.ext.height = cm_to_EMU(chart.height)
            chart.anchor = anchor
            ws.add_chart(chart)
        else:
            ws.add_chart(chart, chart_data['chart-position'])

    @property
    def _is_metered_usage(self):
        return APP_ID.lower() in ('metered-usage-insights', 'client-metered-usage-insights')

    def _apply_borders(self, ws, row_start, col_start, row_span, col_span):
        """Apply inner borders to a rectangular range of cells"""
        for r in range(row_start, row_start + row_span):
            for c in range(col_start, col_start + col_span):
                ws.cell(row=r, column=c).border = self.THIN_BORDER

    def _apply_outer_border(self, ws, start_row, start_col, row_span, col_span):
        outer = Side(style=self.OUTER_BORDER_STYLE)

        for r in range(start_row, start_row + row_span):
            for c in range(start_col, start_col + col_span):
                cell = ws.cell(row=r, column=c)
                existing = cell.border

                cell.border = Border(
                    left=outer if c == start_col else existing.left,
                    right=outer if c == start_col + col_span - 1 else existing.right,
                    top=outer if r == start_row else existing.top,
                    bottom=outer if r == start_row + row_span - 1 else existing.bottom
                )

    def _apply_chart_border(self, ws, chart_data, row_start, col_start, col_span, row_span):
        """Apply outer border around chart + data table area when 'chart-border' is set in chart_data"""
        chart_col_span = chart_data.get('chart-border-col-span', 2)
        chart_row_span = chart_data.get('chart-border-row-span', 2)

        container_row_start = row_start
        container_col_start = col_start-1

        container_col_span = chart_col_span
        container_row_span = chart_row_span

        if container_col_start == 0:
            container_col_start = 1

        # Doughnut/bar charts have a gap row inserted, so need extra offset
        chart_type = chart_data.get('type', '')
        if chart_type in ('doughnut-chart', 'bar-chart'):
            border_row_offset = 3
            border_row_extra = 1
        else:
            border_row_offset = 2
            border_row_extra = 0
        self._apply_outer_border(
            ws,
            container_row_start - border_row_offset,
            container_col_start,
            container_row_span + border_row_extra,
            container_col_span
        )

    def _apply_grey_header(self, ws, row_start, col_start, row_span, col_span):
        """Apply grey header row + inner borders (metered-usage-insights styling)"""
        grey_fill = PatternFill("solid", fgColor="CCCCCC")
        for c in range(col_start, col_start + col_span):
            header_cell = ws.cell(row=row_start, column=c)
            header_cell.fill = grey_fill
            header_cell.font = Font(bold=True, size=16)
            header_cell.alignment = Alignment(horizontal="center")
        self._apply_borders(ws, row_start, col_start, row_span, col_span)

    def _apply_styled_table(self, ws, table_data, row_start, col_start, row_span, col_span):
        """Apply table styling — green-titled sections get grey header + outer border,
        others get standard Excel table + inner borders (metered-usage-insights only).
        For non-metered apps, creates a plain Excel table."""
        ref = f'{get_column_letter(col_start)}{row_start}:{get_column_letter(col_start+col_span-1)}{row_start+row_span-1}'
        ts = time.time()
        table_name = f'Table{random.randint(0, 100)}_{ts}'

        if self._is_metered_usage:
            if table_data.get('title-color', '') == 'green':
                self._apply_grey_header(ws, row_start, col_start, row_span, col_span)
                self._apply_outer_border(ws, row_start - 1, col_start, row_span + 1, col_span)
            else:
                table = Table(displayName=table_name, ref=ref, tableStyleInfo=TableStyleInfo(name="TableStyleMedium9"))
                ws.add_table(table)
                self._apply_borders(ws, row_start, col_start, row_span, col_span)
        else:
            table = Table(displayName=table_name, ref=ref, tableStyleInfo=TableStyleInfo(name="TableStyleMedium9"))
            ws.add_table(table)

    def _apply_metered_component_title(self, ws, cell, component_data, title_row, start_col):
        """Apply metered-usage-insights specific component title styling:
        green section headers, column span merging, tall titles."""
        is_tall = component_data.get('tall-title', False)
        title_color = component_data.get('title-color', component_data.get('color', '00598B'))
        hex_color = self.COLOR_MAP.get(title_color, title_color)
        if title_color == 'green' and self._is_metered_usage:
            hex_color = '068667'
        alignment = component_data.get('align', 'center')

        col_span = component_data.get('col-span', 1)
        if col_span == 1 and 'data' in component_data and isinstance(component_data['data'], list) and len(component_data['data']) > 0:
            col_span = len(component_data['data'][0])

        if col_span > 1:
            title_len = len(str(component_data.get('title', '')))
            min_width_per_col = int((title_len * 1.3) / col_span) + 2
            fixed_col_width = getattr(self, '_current_sheet_fixed_columns', None)
            if fixed_col_width:
                min_width_per_col = min(min_width_per_col, fixed_col_width)
            for c in range(start_col, start_col + col_span):
                current_width = ws.column_dimensions[get_column_letter(c)].width
                if current_width < min_width_per_col:
                    ws.column_dimensions[get_column_letter(c)].width = min_width_per_col

        if title_color in self.SECTION_HEADER_FILL_COLORS:
            green_fill = PatternFill("solid", fgColor=hex_color)
            white_bold = Font(bold=True, size=18)
            if is_tall:
                ws.row_dimensions[title_row].height = 30
                ws.row_dimensions[title_row + 1].height = 8
            if col_span > 1:
                end_col_letter = get_column_letter(start_col + col_span - 1)
                start_col_letter = get_column_letter(start_col)
                ws.merge_cells(f'{start_col_letter}{title_row}:{end_col_letter}{title_row}')
                for c in range(start_col, start_col + col_span):
                    ws.cell(row=title_row, column=c).fill = green_fill
            else:
                cell.fill = green_fill
            cell.font = white_bold
            cell.alignment = Alignment(horizontal="center", vertical="center")
            if alignment == 'left':
                cell.alignment = Alignment(horizontal="left", vertical="center")
        else:
            cell.font = Font(color=hex_color, bold=True, size=18)

    def add_table(self, ws, table_data):
        """
        add table component
        """
        row_start = ExcelRenderer.ROW_START + table_data['start-row'] + 1
        col_start = table_data['start-col']
        self._load_data(ws, table_data['data'], row_start, col_start)
        row_span = len(table_data['data'])
        col_span = len(table_data['data'][0])

        ref = f'{get_column_letter(col_start)}{row_start}:{get_column_letter(col_start+col_span-1)}{row_start+row_span-1}'
        ts = time.time()
        table_name = f'Table{random.randint(0, 100)}_{ts}'

        table = Table(displayName=table_name, ref=ref, tableStyleInfo=TableStyleInfo(name="TableStyleMedium9"))
        ws.add_table(table)

    def _add_metered_table(self, ws, table_data):
        """
        add table component for metered-usage and client-metered-usage apps
        """
        row_start = ExcelRenderer.ROW_START + table_data['start-row'] + 1
        col_start = table_data['start-col']
        self._load_data(ws, table_data['data'], row_start, col_start)
        row_span = len(table_data['data'])
        col_span = len(table_data['data'][0])

        if self._has_no_data(table_data['data']):
            for c in range(col_start, col_start + col_span):
                ws.column_dimensions[get_column_letter(c)].width = self.CHART_NO_DATA_COL_WIDTH
            self._merge_no_data_rows(ws, table_data['data'], row_start, col_start, col_span)

        self._apply_styled_table(ws, table_data, row_start, col_start, row_span, col_span)

        if table_data.get('bold-last-row') and row_span > 1 and not self._has_no_data(table_data['data']):
            last_row = row_start + row_span - 1
            for c in range(col_start, col_start + col_span):
                cell = ws.cell(row=last_row, column=c)
                cell.font = cell.font.copy(bold=True)


    def add_metric_table(self, ws, table_data):
        """
        add metric table component
        """
        row_start = ExcelRenderer.ROW_START + table_data['start-row'] + 1
        col_start = table_data['start-col']
        self._load_data(ws, table_data['data'], row_start, col_start)
        row_span = len(table_data['data'])
        col_span = len(table_data['data'][0])
        if 'merge_cells' in table_data:
            for merge_cell in table_data['merge_cells']:
                ws.merge_cells(merge_cell)
        fill_color = 'eeeeee'
        if 'cell_color' in table_data:
            fill_color = table_data['cell_color']
        if 'color_cells' in table_data:
            min_row = table_data['color_cells'][0]
            max_row = table_data['color_cells'][1]
            min_col = table_data['color_cells'][2]
            max_col = table_data['color_cells'][3]

            for rows in ws.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col):
                for cell in rows:
                    cell.fill = PatternFill("solid", fgColor=fill_color)
                    cell.alignment = Alignment(horizontal="center")

        div_color = 'dee6ef'
        col_min_col = 13
        if 'divider-color' in table_data:
            div_color = table_data['divider-color']
        if 'col_min_col' in table_data:
            col_min_col = table_data['col_min_col']
        if 'col_divider' in table_data:
            if table_data['col_divider'] and table_data['col_divider'] is not None:
                col_min_row = table_data['col_divider'][0]
                col_max_row = table_data['col_divider'][1]
                col_length = table_data['col_divider'][2]
                count = 0
                for i in range(col_length):
                    if count > 0:
                        col_min_col = col_min_col+4
                    for rows in ws.iter_rows(min_row=col_min_row, max_row=col_max_row, min_col=col_min_col, max_col=col_min_col):
                        for cell in rows:
                            cell.fill = PatternFill(start_color=div_color, end_color=div_color, fill_type='solid')
                    count+=1

        ref = f'{get_column_letter(col_start)}{row_start}:{get_column_letter(col_start+col_span-1)}{row_start+row_span-1}'
        ts = time.time()
        table_name = f'Table{random.randint(0, 100)}_{ts}'

        table = Table(displayName=table_name, ref=ref, tableStyleInfo=TableStyleInfo(name="TableStyleMedium9"))
        ws.add_table(table)


    # Default column width for chart data tables when there's no data
    CHART_NO_DATA_COL_WIDTH = 28

    def _has_no_data(self, data):
        """Check if chart data contains 'No data found'"""
        for row in data:
            for val in row:
                if str(val).strip().lower() == 'no data found':
                    return True
        return False

    def _merge_no_data_rows(self, ws, data, row_start, col_start, col_span):
        """Merge columns in rows containing 'No data found' and center the text (metered-usage only)."""
        if not self._is_metered_usage:
            return
        for row_delta in range(1, len(data)):
            row_vals = data[row_delta]
            if any(str(v).strip() == 'No data found' for v in row_vals):
                data_row = row_start + row_delta
                if col_span > 1:
                    start_letter = get_column_letter(col_start)
                    end_letter = get_column_letter(col_start + col_span - 1)
                    ws.merge_cells(f'{start_letter}{data_row}:{end_letter}{data_row}')
                cell = ws.cell(row=data_row, column=col_start)
                cell.value = 'No data found'
                cell.alignment = Alignment(horizontal='center', vertical='center')

    def add_doughnut_chart(self, ws, chart_data):
        """
        add doughnut chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        self._load_data(ws, chart_data['data'], row_start, col_start, self._is_metered_usage)
        row_span = len(chart_data['data'])

        if self._is_metered_usage:
            col_span = len(chart_data['data'][0]) if chart_data['data'] else 2
            self._apply_grey_header(ws, row_start, col_start, row_span, col_span)
            if self._has_no_data(chart_data['data']):
                for c in range(col_start, col_start + col_span):
                    ws.column_dimensions[get_column_letter(c)].width = self.CHART_NO_DATA_COL_WIDTH
                self._merge_no_data_rows(ws, chart_data['data'], row_start, col_start, col_span)

        hole_size = 50
        if 'hole-size' in chart_data:
            hole_size = chart_data.get('hole-size')

        chart = DoughnutChart(holeSize=hole_size)
        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.title = chart_data.get('chart-title', '') if self._is_metered_usage else chart_data['chart-title']
        chart.style = 12
        chart.width = chart_data.get('width', 11)
        chart.height = chart_data.get('height', 5)

        ##Set the DataLabelList to show percentage of pie chart labels.
        #chart.dataLabels = DataLabelList()
        #chart.dataLabels.showVal = False
        #chart.dataLabels.showCatName = False
        #chart.dataLabels.showLegendKey = False

        slices = [DataPoint(idx=i) for i in range(row_span-1)]
        chart.series[0].data_points = slices

        #colors = ["0077C8", "32a3df", "673ab7", "9c27b0"]
        chart_colors = self.generate_pie_chart_colors(len(slices))
        colors = chart_colors

        if 'colors' in chart_data and chart_data['colors']:
            colors = chart_data['colors']+colors

        for idx, slice in enumerate(slices):
            #slice.graphicalProperties.solidFill = colors[idx % 4]
            slice.graphicalProperties.solidFill = colors[idx % len(colors)]

        if self._is_metered_usage:
            self._place_chart(ws, chart, chart_data, col_start, row_start)
        else:
            ws.add_chart(chart, chart_data['chart-position'])

        if self._is_metered_usage and chart_data.get('chart-border'):
            self._apply_chart_border(ws, chart_data, row_start, col_start, col_span, row_span)


    def add_pie_chart(self, ws, chart_data):
        """
        add doughnut chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        self._load_data(ws, chart_data['data'], row_start, col_start, False)
        row_span = len(chart_data['data'])

        chart = PieChart()
        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.title = chart_data['chart-title']
        chart.style = 12
        chart.width = chart_data.get('width', 11)
        chart.height = chart_data.get('height', 5)

        ##Set the DataLabelList to show percentage of pie chart labels.
        #chart.dataLabels = DataLabelList()
        #chart.dataLabels.showVal = False
        #chart.dataLabels.showCatName = False
        #chart.dataLabels.showLegendKey = False

        slices = [DataPoint(idx=i) for i in range(row_span-1)]
        chart.series[0].data_points = slices

        #colors = ["0077C8", "32a3df", "673ab7", "9c27b0"]
        chart_colors = self.generate_pie_chart_colors(len(slices))
        colors = chart_colors

        if 'colors' in chart_data and chart_data['colors']:
            colors = chart_data['colors']+colors

        for idx, slice in enumerate(slices):
            #slice.graphicalProperties.solidFill = colors[idx % 4]
            slice.graphicalProperties.solidFill = colors[idx % len(colors)]

        ws.add_chart(chart, chart_data['chart-position'])


    def add_bar_chart(self, ws, chart_data):
        """
        add bar chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        self._load_data(ws, chart_data['data'], row_start, col_start, self._is_metered_usage)
        row_span = len(chart_data['data'])

        if self._is_metered_usage:
            col_span = len(chart_data['data'][0]) if chart_data['data'] else 2
            self._apply_grey_header(ws, row_start, col_start, row_span, col_span)
            if self._has_no_data(chart_data['data']):
                for c in range(col_start, col_start + col_span):
                    ws.column_dimensions[get_column_letter(c)].width = self.CHART_NO_DATA_COL_WIDTH
                self._merge_no_data_rows(ws, chart_data['data'], row_start, col_start, col_span)

        chart = BarChart()
        chart.type = "col"
        chart.style = 10
        chart.title = chart_data.get('chart-title', '') if self._is_metered_usage else chart_data['chart-title']
        chart.x_axis.title = chart_data.get('x-axis-title')
        chart.y_axis.title = chart_data.get('y-axis-title')

        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.style = 4
        chart.legend = None
        chart.width = chart_data.get('width', 17)
        chart.height = chart_data.get('height', 8.5)

        s1 = chart.series[0]
        s1.graphicalProperties.line.solidFill = "0077C8"
        s1.graphicalProperties.solidFill = "0077C8"

        multicolor_check = False
        multi_colors = chart_colors
        if 'is-multicolored-chart' in chart_data:
            multicolor_check = chart_data['is-multicolored-chart']
        if 'colors' in chart_data and chart_data['colors']:
            multi_colors = chart_data['colors']

        for idx, s in enumerate(chart.series):
            if multicolor_check:
                for i in range(len(multi_colors)):
                    pt = DataPoint(idx=i)
                    pt.graphicalProperties.solidFill = multi_colors[i]
                    s.dPt.append(pt)
            else:
                index = len(chart_colors)%(idx+1)
                if index >= len(chart_colors):
                    index = 0
                s.graphicalProperties.line.solidFill = chart_colors[index]
                s.graphicalProperties.solidFill = chart_colors[index]

        if self._is_metered_usage:
            self._place_chart(ws, chart, chart_data, col_start, row_start)
        else:
            ws.add_chart(chart, chart_data['chart-position'])

        if self._is_metered_usage and chart_data.get('chart-border'):
            self._apply_chart_border(ws, chart_data, row_start, col_start, col_span, row_span)

    def add_bar_chart_with_formatted_values(self, ws, chart_data):
        """
        Add bar chart component with K/M formatted values.
        Displays values with 'k' for thousands and 'M' for millions while maintaining numeric data for charts.
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        self._load_data(ws, chart_data['data'], row_start, col_start, False)
        row_span = len(chart_data['data'])

        # Apply Excel number format to value column (K for thousands, M for millions)
        # General format for base numbers avoids trailing decimal points
        number_format = '[>=1000000]#,##0.##,,"M";[>=1000]#,##0.##,"k";General'
        for row_idx in range(row_start + 1, row_start + row_span):
            cell = ws.cell(row=row_idx, column=col_start + 1)
            cell.number_format = number_format

        chart = BarChart()
        chart.type = "col"
        chart.style = 10
        chart.title = chart_data['chart-title']
        chart.x_axis.title = chart_data.get('x-axis-title')
        chart.y_axis.title = chart_data.get('y-axis-title')

        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.style = 4
        chart.legend = None
        chart.width = chart_data.get('width', 17)
        chart.height = chart_data.get('height', 8.5)

        s1 = chart.series[0]
        s1.graphicalProperties.line.solidFill = "0077C8"
        s1.graphicalProperties.solidFill = "0077C8"

        multicolor_check = False
        multi_colors = chart_colors
        if 'is-multicolored-chart' in chart_data:
            multicolor_check = chart_data['is-multicolored-chart']
        if 'colors' in chart_data and chart_data['colors']:
            multi_colors = chart_data['colors']

        for idx, s in enumerate(chart.series):
            if multicolor_check:
                for i in range(len(multi_colors)):
                    pt = DataPoint(idx=i)
                    pt.graphicalProperties.solidFill = multi_colors[i]
                    s.dPt.append(pt)
            else:
                index = len(chart_colors)%(idx+1)
                if index >= len(chart_colors):
                    index = 0
                s.graphicalProperties.line.solidFill = chart_colors[index]
                s.graphicalProperties.solidFill = chart_colors[index]

        ws.add_chart(chart, chart_data['chart-position'])

    def add_stack_bar_chart(self, ws, chart_data):
        """
        add stack bar chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        self._load_data(ws, chart_data['data'], row_start, col_start, False)
        row_span = len(chart_data['data'])
        no_of_labels = chart_data['no-of-labels']
        if not no_of_labels:
            no_of_labels = 1

        chart = BarChart()
        chart.type = "col"
        chart.title = chart_data['chart-title']
        chart.x_axis.title = chart_data.get('x-axis-title')
        chart.y_axis.title = chart_data.get('y-axis-title')

        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1, max_col=col_start+no_of_labels)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.style = 4
        if no_of_labels == 1:
            chart.legend = None
        chart.grouping = "stacked"
        chart.overlap = 100
        chart.width = chart_data.get('width', 20)
        chart.height = chart_data.get('height', 10)

        s1 = chart.series[0]
        s1.graphicalProperties.line.solidFill = "0077C8"
        s1.graphicalProperties.solidFill = "0077C8"

        add_chart_colors = chart_colors
        colors_check = False
        if 'colors' in chart_data and chart_data['colors']:
            add_chart_colors = chart_data['colors']+add_chart_colors
            colors_check = True

        for idx, s in enumerate(chart.series):
            index = idx
            if not colors_check:
                index = len(add_chart_colors)%(idx+1)
            if index >= len(add_chart_colors):
                index = 0
            s.graphicalProperties.line.solidFill = add_chart_colors[index]
            s.graphicalProperties.solidFill = add_chart_colors[index]

        ws.add_chart(chart, chart_data['chart-position'])

    def add_scatter_chart(self, ws, chart_data):
        """
        add scatter chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        x_axis_date_format = chart_data.get('x-axis-date-format')
        self._load_data(ws, chart_data['data'], row_start, col_start, False, x_axis_date_format)
        row_span = len(chart_data['data'])
        no_of_lines = chart_data.get('no-of-lines')
        if not no_of_lines:
            no_of_lines = 1
        colors = ["0077C8", "e35420", "32a3df", "673ab7", "9c27b0"]

        chart = ScatterChart()
        chart.style = 5
        chart.legend = None
        chart.title = chart_data['chart-title']
        chart.x_axis.title = chart_data.get('x-axis-title')
        chart.y_axis.title = chart_data.get('y-axis-title')
        chart.width = chart_data.get('width', 15)
        chart.height = chart_data.get('height', 7.5)

        for i in range(no_of_lines):
            labels = Reference(ws, min_col=col_start, min_row=row_start+i+1, max_row=row_start+row_span-1)
            data = Reference(ws, min_col=col_start+i+1, min_row=row_start, max_row=row_start+row_span-1)
            series = Series(data, labels, title_from_data=True)
            series.marker.symbol = "circle"
            series.marker.graphicalProperties.solidFill = colors[i % 5]  # Marker filling
            series.marker.graphicalProperties.line.solidFill = colors[i % 5]  # Marker outline
            series.graphicalProperties.line.solidFill = colors[i % 5]
            series.graphicalProperties.line.width = 24050  # width in EMUs
            if x_axis_date_format:
                chart.x_axis.number_format = 'm/d'
                chart.x_axis.majorTimeUnit = "days"
            chart.series.append(series)

        ws.add_chart(chart, chart_data['chart-position'])

    def add_line_chart(self, ws, chart_data):
        """
        add line chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        x_axis_date_format = chart_data.get('x-axis-date-format')
        self._load_data(ws, chart_data['data'], row_start, col_start, self._is_metered_usage, x_axis_date_format)
        row_span = len(chart_data['data'])

        if self._is_metered_usage:
            col_span = len(chart_data['data'][0]) if chart_data['data'] else 2
            self._apply_grey_header(ws, row_start, col_start, row_span, col_span)
            if self._has_no_data(chart_data['data']):
                self._merge_no_data_rows(ws, chart_data['data'], row_start, col_start, col_span)

        no_of_lines = chart_data.get('no-of-lines')
        if not no_of_lines:
            no_of_lines = 1
        colors = ["0077C8", "e35420", "32a3df", "673ab7", "9c27b0"]
        if 'colors' in chart_data and chart_data['colors']:
            colors = chart_data['colors']+colors

        chart = LineChart()
        chart.style = 5
        chart.legend.position = 'b'     # Location of legend
        if not self._is_metered_usage and no_of_lines == 1:
            chart.legend = None
        if self._is_metered_usage and self._has_no_data(chart_data['data']):
            chart.legend = None
        chart.title = chart_data.get('chart-title', '') if self._is_metered_usage else chart_data['chart-title']
        chart.x_axis.title = chart_data.get('x-axis-title')
        chart.y_axis.title = chart_data.get('y-axis-title')
        chart.width = chart_data.get('width', 20)
        chart.height = chart_data.get('height', 10)

        for i in range(no_of_lines):
            labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
            data = Reference(ws, min_col=col_start+i+1, min_row=row_start, max_row=row_start+row_span-1)
            chart.add_data(data, titles_from_data=True)
            chart.set_categories(labels)
            series = chart.series[i]
            series.marker.graphicalProperties.solidFill = colors[i % no_of_lines]  # Marker filling
            series.marker.graphicalProperties.line.solidFill = colors[i % no_of_lines]  # Marker outline
            series.graphicalProperties.line.solidFill = colors[i % no_of_lines]
            series.graphicalProperties.line.width = 24050  # width in EMUs
            series.smooth=True        # Draw a smooth line
            if x_axis_date_format:
                chart.x_axis.number_format = 'm/d'
                chart.x_axis.majorTimeUnit = "days"

        ws.add_chart(chart, chart_data['chart-position'])

        if self._is_metered_usage:
            self._apply_outer_border(ws, row_start - 1, col_start, row_span + 1, col_span)
            if chart_data.get('chart-border'):
                self._apply_chart_border(ws, chart_data, row_start, col_start, col_span, row_span)
            # When there's no data, set row heights for empty rows in the chart area
            # so charts don't collapse into each other
            if self._has_no_data(chart_data['data']):
                chart_pos = chart_data.get('chart-position', '')
                if chart_pos:
                    chart_anchor_row = int(re.match(r'[A-Z]+(\d+)', chart_pos).group(1))
                    chart_height_rows = 15  # chart spans ~15 rows
                    for r in range(row_start, chart_anchor_row + chart_height_rows):
                        if ws.row_dimensions[r].height is None or ws.row_dimensions[r].height < 20:
                            ws.row_dimensions[r].height = 20


    def add_bar_line_trend_chart(self, ws, chart_data):
        """
        add bar line trend chart component
        """
        row_start = ExcelRenderer.ROW_START + chart_data['start-row']
        col_start = chart_data['start-col']
        self._load_data(ws, chart_data['data'], row_start, col_start, False)
        row_span = len(chart_data['data'])

        chart = BarChart()
        chart.type = "col"
        chart.style = 10
        chart.title = chart_data['chart-title']
        chart.x_axis.title = chart_data.get('x-axis-title')
        chart.y_axis.title = chart_data.get('y-axis-title')

        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(labels)
        chart.style = 4
        chart.legend = None
        chart.width = chart_data.get('width', 17)
        chart.height = chart_data.get('height', 8.5)

        chart2 = LineChart()
        #chart2.type = "col"
        chart2.style = 10
        chart2.title = chart_data['chart-title']
        chart2.x_axis.title = chart_data.get('x-axis-title')
        chart2.y_axis.title = chart_data.get('y-axis-title')

        labels = Reference(ws, min_col=col_start, min_row=row_start+1, max_row=row_start+row_span-1)
        data = Reference(ws, min_col=col_start+1, min_row=row_start, max_row=row_start+row_span-1)
        chart2.add_data(data, titles_from_data=True)
        chart2.set_categories(labels)
        chart2.style = 4
        chart2.legend = None
        chart2.width = chart_data.get('width', 17)
        chart2.height = chart_data.get('height', 8.5)

        s1 = chart.series[0]
        s1.graphicalProperties.line.solidFill = "0077C8"
        s1.graphicalProperties.solidFill = "0077C8"

        for idx, s in enumerate(chart.series):
            index = len(chart_colors)%(idx+1)
            if index >= len(chart_colors):
                index = 0
            s.graphicalProperties.line.solidFill = chart_colors[index]
            s.graphicalProperties.solidFill = chart_colors[index]

        chart += chart2
        ws.add_chart(chart, chart_data['chart-position'])


    def client_names_ids(self, customer_name):
        names = ''
        client_id = ''
        if customer_name and customer_name is not None:
            for i in customer_name:
                for j in i.items():
                    names+=j[1]['name']
                    client_id+=j[1]['uniqueId']
                    names+=', '
                    client_id+=', '
            names = names.rstrip(', ')
            client_id = client_id.rstrip(', ')
            return names, client_id
        else:
            return names, client_id


    def generate_glossary(self, ws, sheet_resp, title):
        """
        add glossary sheet
        """
        data_len = 35
        if sheet_resp is not None and 'data' in sheet_resp and sheet_resp['data'] is not None and len(sheet_resp['data']) >= data_len:
            data_len = len(sheet_resp['data'])+5
        for row_idx in range(1, data_len):
            row = ws.row_dimensions[row_idx]
            row.fill = PatternFill("solid", fgColor="eeeeee")

        ws.column_dimensions['B'].width = 50
        ws.column_dimensions['C'].width = 24

        header_idx = 2
        value_idx = 2
        if sheet_resp is not None and 'data' in sheet_resp and sheet_resp['data'] is not None:
            data = sheet_resp['data']
            for key in data.keys():
                header_idx += 1
                value_idx += 1
                display_name = key
                display_value = data[key]

                cell = ws[f'B{header_idx}']
                cell.value = display_name
                cell.font = Font(color="068667")
                cell.fill = PatternFill("solid", fgColor="eeeeee")

                cell = ws[f'C{value_idx}']
                cell.value = display_value
                cell.font = Font(color="000000")
                cell.fill = PatternFill("solid", fgColor="eeeeee")


    def generate_summary(self, res, tenantId, additional_props, report_gen_start_time, report_gen_completed_time):
        """
        add summary sheet
        """
        ws = self.wb.active
        ws.title = 'SUMMARY'

        for row_idx in range(1, 30):
            row = ws.row_dimensions[row_idx]
            row.fill = PatternFill("solid", fgColor="eeeeee")

        ws.column_dimensions['B'].width = 24
        ws.column_dimensions['C'].width = 24

        c_name = ''
        c_id = ''
        opsql_params = None
        if additional_props and additional_props is not None:
            if 'client_names' in additional_props:
                client_res = additional_props['client_names']
                result = self.client_names_ids(client_res)
                c_name = result[0]
                c_id = result[1]

            if 'opsql_query' in additional_props:
                opsql_params = additional_props['opsql_query']

        cell = ws['B4']
        cell.value = 'App'
        cell.font = Font(color="068667")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['C4']
        cell.value = APP_DISPLAY_NAME.replace('-', ' ').title()
        cell.font = Font(color="000000")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['B5']
        cell.value = 'Tenant Name'
        cell.font = Font(color="068667")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['C5']
        # cell.value = res.json()['tenantInfo']['tenantName']
        cell.value = c_name
        cell.font = Font(color="000000")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        #cell = ws['B6']
        #cell.value = 'Tenant Id'
        #cell.font = Font(color="00598B")
        #cell.fill = PatternFill("solid", fgColor="eeeeee")

        #cell = ws['C6']
        ## cell.value = tenantId
        #cell.value = c_id
        #cell.font = Font(color="000000")
        #cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['B6']
        cell.value = 'Run date'
        cell.font = Font(color="068667")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['C6']
        cell.value = report_gen_start_time
        cell.font = Font(color="000000")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['B7']
        cell.value = 'Completion date'
        cell.font = Font(color="068667")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['C7']
        cell.value = report_gen_completed_time
        cell.font = Font(color="000000")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['B8']
        cell.value = 'User'
        cell.font = Font(color="068667")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        cell = ws['C8']
        first_name = res.json()['analysisRun']['createdBy']['firstName']
        last_name = res.json()['analysisRun']['createdBy']['lastName']
        login_name = res.json()['analysisRun']['createdBy']['loginName']
        cell.value = f'{first_name} {last_name} ({login_name})'
        cell.font = Font(color="000000")
        cell.fill = PatternFill("solid", fgColor="eeeeee")

        header_idx = 8
        value_idx = 8
        if opsql_params is not None:

            for key in opsql_params.keys():
                header_idx += 1
                value_idx += 1
                display_name = self.get_display_name(key)
                display_value = self.get_display_value(opsql_params[key])

                cell = ws[f'B{header_idx}']
                cell.value = display_name
                cell.font = Font(color="068667")
                cell.fill = PatternFill("solid", fgColor="eeeeee")

                cell = ws[f'C{value_idx}']
                cell.value = display_value
                cell.font = Font(color="000000")
                cell.fill = PatternFill("solid", fgColor="eeeeee")

        # cell = ws['B10']
        # cell.value = 'Analysis Parameters'
        # cell.font = Font(color="00598B")
        # cell.fill = PatternFill("solid", fgColor="eeeeee")

        # cell = ws['B11']
        # cell.value = 'Analysis Period'
        # cell.alignment = Alignment(horizontal="right")
        # cell.font = Font(color="00598B")
        # cell.fill = PatternFill("solid", fgColor="eeeeee")

        # cell = ws['C11']
        # start_date = res.json()['analysisPeriodInUserTZ']['displayStartTime']
        # end_date = res.json()['analysisPeriodInUserTZ']['displayEndTime']
        # cell.value = f"{start_date} - {end_date}"
        # cell.font = Font(color="000000")
        # cell.fill = PatternFill("solid", fgColor="eeeeee")


        # cell = ws['B13']
        # cell.value = 'App version'
        # cell.alignment = Alignment(horizontal="right")
        # cell.font = Font(color="00598B")
        # cell.fill = PatternFill("solid", fgColor="eeeeee")
        #
        # cell = ws['C13']
        # cell.value = res['analysisRun']['version']
        # cell.font = Font(color="000000")
        # cell.fill = PatternFill("solid", fgColor="eeeeee")

    def get_display_name(self, key):
        if key == 'filterCriteria':
            return 'Query'
        if key == 'fields':
            return 'Attributes'
        if key == 'groupBy':
            return 'Group By'
        if key == 'soryBy':
            return 'Sort By'
        if key == 'sortByOrder':
            return 'Sort By Order'
        return key

    def get_display_value(self, value):
        if value is None and len(value) <= 0:
            return '-'
        else:
            if isinstance(value, list):
                all_values = ', '.join([val for val in value])
                return all_values
        return value


    def generate_pie_chart_colors(self, num_colors):
        colors=["0077C8", "00A3E0", "673AB7", "9C27B0", "E91E63", "F47925"]
        random.seed(123)  # 123 Fixed seed value
        #colors = []
        for _ in range(num_colors):
            hex_color = '{:06x}'.format(random.randint(0, 0xFFFFFF))
            colors.append(hex_color)
        return colors


    def add_header(self, ws, sheet_data):
        """
        add header to the sheet
        """
        for row_idx in range(1, ExcelRenderer.ROW_START):
            row = ws.row_dimensions[row_idx]
            row.fill = PatternFill("solid", fgColor="eeeeee")

        ws.merge_cells('B1:Z2')
        cell = ws['B1']
        cell.value = APP_DISPLAY_NAME.replace('-', ' ').title()
        cell.font = Font(color="00598B", bold=True)
        cell.fill = PatternFill("solid", fgColor="eeeeee")
        cell.alignment = Alignment(vertical="center")

    def _add_metered_header(self, ws, sheet_data):
        """
        add header to the sheet for metered-usage and client-metered-usage apps
        """
        for row_idx in range(1, ExcelRenderer.ROW_START):
            row = ws.row_dimensions[row_idx]
            row.fill = PatternFill("solid", fgColor="eeeeee")

        ws.merge_cells('A1:Z2')
        cell = ws['A1']
        cell.value = APP_DISPLAY_NAME.replace('-', ' ').title()
        cell.font = Font(color="000000", bold=True, size=26)
        cell.fill = PatternFill("solid", fgColor="eeeeee")
        cell.alignment = Alignment(vertical="center")
        ws.row_dimensions[1].height = 40

    def add_component_title(self, ws, component_data):
        """
        add component title
        """
        # cell = ws.cell(row=ExcelRenderer.ROW_START+component_data['start-row'], column=component_data['start-col'])
        # cell.value = component_data['title']

        if self._is_metered_usage:
            title_row = ExcelRenderer.ROW_START + component_data['start-row']
            start_col = component_data['start-col']
            cell = ws.cell(row=title_row, column=start_col)
            cell.value = component_data['title']
            self._apply_metered_component_title(ws, cell, component_data, title_row, start_col)
        else:
            cell = ws.cell(row=ExcelRenderer.ROW_START+component_data['start-row'], column=component_data['start-col'])
            cell.value = component_data['title']
            color = component_data.get('color', '00598B')
            cell.font = Font(color=color, bold=True)

    def add_component(self, ws, component_data):

        if component_data and 'data' in component_data:
            data = component_data['data']
            if isinstance(data, list):
                if len(data) >= 1000005:
                    logger.error('Data exceeding 1Million records.. Excluding excessive records..')
                    data = data[0:1000005]
                    component_data['data'] = data

        if component_data['type'] == 'table':
            if component_data.get('title'):
                self.add_component_title(ws, component_data)
            if 'metric_sheet' in component_data:
                self.add_metric_table(ws, component_data)
            elif self._is_metered_usage:
                self._add_metered_table(ws, component_data)
            else:
                self.add_table(ws, component_data)
        elif component_data['type'] == 'name':
            if component_data.get('title'):
                self.add_component_title(ws, component_data)
        elif component_data['type'] == 'doughnut-chart':
            self.add_doughnut_chart(ws, component_data)
        elif component_data['type'] == 'pie-chart':
            self.add_pie_chart(ws, component_data)
        elif component_data['type'] == 'bar-chart':
            self.add_bar_chart(ws, component_data)
        elif component_data['type'] == 'bar-chart-numbers-formatted':
            self.add_bar_chart_with_formatted_values(ws, component_data)
        elif component_data['type'] == 'scatter-chart':
            self.add_scatter_chart(ws, component_data)
        elif component_data['type'] == 'line-chart':
            self.add_line_chart(ws, component_data)
        elif component_data['type'] == 'bar-line-trend-chart':
            self.add_bar_line_trend_chart(ws, component_data)
        elif component_data['type'] == 'stack-bar-chart':
            self.add_stack_bar_chart(ws, component_data)

    @staticmethod
    def _group_contiguous_columns(col_letters):
        """Group a list of column letters into contiguous ranges.
        E.g. ['C','D','K','L'] -> [[3,4], [11,12]]"""
        if not col_letters:
            return []
        col_nums = sorted(ord(c.upper()) - ord('A') + 1 for c in col_letters)
        groups = []
        current_group = [col_nums[0]]
        for num in col_nums[1:]:
            if num == current_group[-1] + 1:
                current_group.append(num)
            else:
                groups.append(current_group)
                current_group = [num]
        groups.append(current_group)
        return groups

    def _render_sheet_components(self, ws, sheet):
        """Render all components for a sheet, with metered-usage tall-title handling."""
        if self._is_metered_usage:
            chart_types_tall = ('doughnut-chart', 'bar-chart')
            fixed_width_columns = sheet.get('fixed-width-columns', [])
            col_groups = self._group_contiguous_columns(fixed_width_columns)
            for idx, component_data in enumerate(sheet['components']):
                if component_data.get('type') == 'name' and idx + 1 < len(sheet['components']):
                    next_comp = sheet['components'][idx + 1]
                    if next_comp.get('type', '') in chart_types_tall:
                        component_data['tall-title'] = True
                        next_comp['start-row'] = next_comp.get('start-row', 0) + 1
                        # Position green section header within nearest fixed-width-column group
                        if component_data.get('title-color') in self.SECTION_HEADER_FILL_COLORS:
                            if col_groups:
                                start_col = component_data.get('start-col', 1)
                                # Find the nearest contiguous group by distance to start-col
                                nearest = min(col_groups, key=lambda g: min(abs(c - start_col) for c in g))
                                component_data['start-col'] = nearest[0]
                                component_data['col-span'] = nearest[-1] - nearest[0] + 1
                            else:
                                border_col_span = next_comp.get('chart-border-col-span', 5)
                                component_data['col-span'] = border_col_span - 1
                self.add_component(ws, component_data)
        else:
            for component_data in sheet['components']:
                self.add_component(ws, component_data)

    def render(self):
        """
        :return: Workbook
        """
        res = self.res
        tenantId = self.tenantId
        report_gen_start_time = self.report_gen_start_time
        report_gen_completed_time = self.report_gen_completed_time
        additional_props = self.additional_props
        self.generate_summary(res, tenantId, additional_props, report_gen_start_time, report_gen_completed_time)
        # run_data = self.analysis_run
        run_data = self.excel_data
        for sheet in run_data['sheets']:
            if 'documentation' in sheet and sheet['documentation'] == 'true':
                ws = self.wb.create_sheet(title=sheet['title'])
                if self._is_metered_usage:
                    ws.sheet_view.showGridLines = False
                    self._add_metered_header(ws, sheet)
                self.generate_glossary(ws, sheet, title=sheet['title'])
            else:
                if self._is_metered_usage:
                    ws = self.wb.create_sheet(title=sheet['title'])
                    fixed_columns = sheet.get('fixed-columns')
                    self._current_sheet_fixed_columns = fixed_columns
                    ws.sheet_view.showGridLines = False
                    # Set column widths from app-provided config
                    fixed_width_columns = sheet.get('fixed-width-columns', [])
                    min_col_width = sheet.get('min-col-width')
                    if fixed_width_columns:
                        width = min_col_width if min_col_width else fixed_columns
                        if width:
                            for col_letter in fixed_width_columns:
                                ws.column_dimensions[col_letter].width = width
                    self._add_metered_header(ws, sheet)
                    self._render_sheet_components(ws, sheet)
                    self._current_sheet_fixed_columns = None
                else:
                    ws = self.wb.create_sheet(title=sheet['title'])
                    self.add_header(ws, sheet)

                    for component_data in sheet['components']:
                        self.add_component(ws, component_data)

        return self.wb
