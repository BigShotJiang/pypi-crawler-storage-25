"""YAML 선언형 Assembly 로드 예제.

실행 (프로젝트 루트에서):
    uv run python -m examples.yaml_pipeline.run
"""

from __future__ import annotations

import sys
from pathlib import Path

# 프로젝트 루트를 sys.path 에 추가 (examples 패키지 임포트를 위해)
_ROOT = Path(__file__).resolve().parents[2]
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from examples.yaml_pipeline.blocks import LengthOutput, TextInput  # noqa: E402
from pylego_blocks.core.assembly import Assembly  # noqa: E402
from pylego_blocks.declarative import load_assembly  # noqa: E402

if __name__ == "__main__":
    yaml_path = Path(__file__).parent / "pipeline.yaml"
    pipeline: Assembly[TextInput, LengthOutput] = load_assembly(yaml_path)  # type: ignore[assignment]

    print(pipeline)  # text-pipeline[UpperBlock → LengthBlock]

    result = pipeline.run_sync(TextInput(text="hello, pylego"))
    print(f"length: {result.length}")  # 13
