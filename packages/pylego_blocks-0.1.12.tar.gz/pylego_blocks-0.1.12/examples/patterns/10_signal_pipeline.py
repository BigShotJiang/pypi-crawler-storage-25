"""Pattern 10 — SignalPipeline: 신호 수집·집계 및 임계값 기반 분기.

TapBlock + SignalAggregator 를 조합해 비차단 신호 감시 → Branch 분기 패턴을 구현한다.
"""

from __future__ import annotations

import asyncio

from pylego_blocks import (
    Assembly,
    Branch,
    SignalAggregator,
    SignalScore,
    Stud,
    TapBlock,
)
from pylego_blocks.core.block import Block


# ── Stud 계약 ─────────────────────────────────────────────────────────────────

class AiRequest(Stud):
    prompt: str
    context: str = ""


class AiResponse(Stud):
    text: str
    verdict: str = "UNKNOWN"


# ── 신호 블록들 ────────────────────────────────────────────────────────────────

class FormatSignalBlock(Block[AiResponse, AiResponse]):
    """응답 형식 불량 여부를 감시한다."""

    input_model = AiResponse
    output_model = AiResponse

    def __init__(self, aggregator: SignalAggregator) -> None:
        self._agg = aggregator

    async def run(self, inp: AiResponse) -> AiResponse:
        score = 0.0 if inp.verdict in ("PASS", "FAIL") else 0.9
        self._agg.record(
            SignalScore(score=score, reason="판정 형식 검사", block_name="FormatSignal")
        )
        print(f"  [FormatSignal] score={score:.1f}, verdict={inp.verdict!r}")
        return inp


class ContentSignalBlock(Block[AiResponse, AiResponse]):
    """응답 텍스트 길이를 기반으로 신호를 발생시킨다."""

    input_model = AiResponse
    output_model = AiResponse

    def __init__(self, aggregator: SignalAggregator) -> None:
        self._agg = aggregator

    async def run(self, inp: AiResponse) -> AiResponse:
        score = 0.2 if len(inp.text) >= 10 else 0.7
        self._agg.record(
            SignalScore(score=score, reason="응답 길이 검사", block_name="ContentSignal")
        )
        print(f"  [ContentSignal] score={score:.1f}, text_len={len(inp.text)}")
        return inp


# ── AI 및 처리 블록 ──────────────────────────────────────────────────────────

class MockAiBlock(Block[AiRequest, AiResponse]):
    input_model = AiRequest
    output_model = AiResponse

    def __init__(self, response_text: str, verdict: str = "UNKNOWN") -> None:
        self._text = response_text
        self._verdict = verdict

    async def run(self, inp: AiRequest) -> AiResponse:
        return AiResponse(text=self._text, verdict=self._verdict)


class AcceptBlock(Block[AiResponse, AiResponse]):
    input_model = AiResponse
    output_model = AiResponse

    async def run(self, inp: AiResponse) -> AiResponse:
        print(f"  [Accept] 정상 응답 통과: {inp.verdict!r}")
        return inp


class FallbackBlock(Block[AiResponse, AiResponse]):
    input_model = AiResponse
    output_model = AiResponse

    async def run(self, inp: AiResponse) -> AiResponse:
        print(f"  [Fallback] 의심 응답 차단 → 기본값 반환")
        return AiResponse(text="검토 필요", verdict="UNKNOWN")


# ── 패턴 A: max 전략 — 하나라도 임계값 초과 시 의심 ─────────────────────────

async def pattern_a_max_strategy() -> None:
    aggregator = SignalAggregator(threshold=0.7, strategy="max")

    pipeline = Assembly([
        MockAiBlock("짧은 응답", verdict="UNKNOWN"),
        TapBlock(FormatSignalBlock(aggregator)),
        TapBlock(ContentSignalBlock(aggregator)),
        Branch(
            predicate=lambda _: not aggregator.is_suspicious,
            on_true=AcceptBlock(),
            on_false=FallbackBlock(),
        ),
    ])

    result = await pipeline.run(AiRequest(prompt="테스트"))
    print(f"[A] 결과: {result.verdict!r}, is_suspicious={aggregator.is_suspicious}")


# ── 패턴 B: mean 전략 — 평균으로 판정 ───────────────────────────────────────

async def pattern_b_mean_strategy() -> None:
    aggregator = SignalAggregator(threshold=0.7, strategy="mean")

    pipeline = Assembly([
        MockAiBlock("적절한 길이의 응답 텍스트", verdict="PASS"),
        TapBlock(FormatSignalBlock(aggregator)),
        TapBlock(ContentSignalBlock(aggregator)),
        Branch(
            predicate=lambda _: not aggregator.is_suspicious,
            on_true=AcceptBlock(),
            on_false=FallbackBlock(),
        ),
    ])

    result = await pipeline.run(AiRequest(prompt="테스트"))
    scores = aggregator.scores
    mean = sum(s.score for s in scores) / len(scores)
    print(f"[B] 결과: {result.verdict!r}, mean_score={mean:.2f}, suspicious={aggregator.is_suspicious}")


# ── 패턴 C: any 전략 — 하나라도 임계값 초과이면 즉시 ────────────────────────

async def pattern_c_any_strategy() -> None:
    aggregator = SignalAggregator(threshold=0.5, strategy="any")
    aggregator.record(SignalScore(score=0.3, block_name="Signal1"))
    aggregator.record(SignalScore(score=0.6, block_name="Signal2"))  # > 0.5

    print(f"[C] any 전략: is_suspicious={aggregator.is_suspicious}")  # True


# ── 패턴 D: reset() — 요청 간 상태 초기화 ──────────────────────────────────

async def pattern_d_reset() -> None:
    aggregator = SignalAggregator(threshold=0.7)

    for i, verdict in enumerate(["UNKNOWN", "PASS"], start=1):
        aggregator.reset()
        aggregator.record(SignalScore(score=0.9 if verdict == "UNKNOWN" else 0.1))
        print(f"[D] 요청 {i}: verdict={verdict!r}, suspicious={aggregator.is_suspicious}")


# ── 실행 ─────────────────────────────────────────────────────────────────────

async def main() -> None:
    print("=== Pattern A: max 전략 ===")
    await pattern_a_max_strategy()

    print("\n=== Pattern B: mean 전략 ===")
    await pattern_b_mean_strategy()

    print("\n=== Pattern C: any 전략 ===")
    await pattern_c_any_strategy()

    print("\n=== Pattern D: reset ===")
    await pattern_d_reset()


if __name__ == "__main__":
    asyncio.run(main())
