"""패턴 03: 에러 복구 — Retry / Fallback / Timeout / CircuitBreaker.

각 래퍼는 독립적으로 사용하거나 중첩할 수 있다:
    CircuitBreakerBlock(RetryBlock(TimeoutBlock(inner, 5.0), policy), threshold=3)
"""

import asyncio
from pylego_blocks import (
    Assembly, Block, CircuitBreakerBlock, DeadLetterQueue,
    FallbackBlock, Queue, RetryBlock, RetryPolicy, Stud, TimeoutBlock, WorkerPool,
)


class ApiIn(Stud):
    query: str

class ApiOut(Stud):
    answer: str


# ─── 일시적 실패를 시뮬레이션하는 블록 ────────────────────────────────────────

class FlakyBlock(Block[ApiIn, ApiOut]):
    input_model = ApiIn
    output_model = ApiOut
    _calls = 0

    async def run(self, inp: ApiIn) -> ApiOut:
        self._calls += 1
        if self._calls < 3:
            raise ConnectionError("일시적 오류")
        return ApiOut(answer=f"ok: {inp.query}")


class CacheBlock(Block[ApiIn, ApiOut]):
    input_model = ApiIn
    output_model = ApiOut

    async def run(self, inp: ApiIn) -> ApiOut:
        return ApiOut(answer="캐시 응답")


# ─── RetryBlock ───────────────────────────────────────────────────────────────

def run_retry() -> None:
    policy = RetryPolicy(max_attempts=5, delay_sec=0.0, backoff=1.0)
    pipeline = Assembly([RetryBlock(FlakyBlock(), policy=policy)])
    result = pipeline.run_sync(ApiIn(query="test"))
    print(result.answer)  # ok: test


# ─── FallbackBlock ────────────────────────────────────────────────────────────

def run_fallback() -> None:
    # FlakyBlock 이 3회 내에 성공하지 못하면 CacheBlock 실행
    class AlwaysFailBlock(Block[ApiIn, ApiOut]):
        input_model = ApiIn
        output_model = ApiOut
        async def run(self, inp: ApiIn) -> ApiOut:
            raise RuntimeError("항상 실패")

    pipeline = Assembly([FallbackBlock(primary=AlwaysFailBlock(), fallback=CacheBlock())])
    result = pipeline.run_sync(ApiIn(query="test"))
    print(result.answer)  # 캐시 응답


# ─── TimeoutBlock ─────────────────────────────────────────────────────────────

async def run_timeout() -> None:
    class SlowBlock(Block[ApiIn, ApiOut]):
        input_model = ApiIn
        output_model = ApiOut
        async def run(self, inp: ApiIn) -> ApiOut:
            await asyncio.sleep(10)
            return ApiOut(answer="늦은 응답")

    pipeline = Assembly([TimeoutBlock(SlowBlock(), timeout_sec=0.1)])
    try:
        await pipeline.run(ApiIn(query="test"))
    except TimeoutError:
        print("타임아웃 발생")


# ─── CircuitBreakerBlock ──────────────────────────────────────────────────────

async def run_circuit_breaker() -> None:
    from pylego_blocks import CircuitOpenError

    class AlwaysFailBlock(Block[ApiIn, ApiOut]):
        input_model = ApiIn
        output_model = ApiOut
        async def run(self, inp: ApiIn) -> ApiOut:
            raise RuntimeError("서비스 중단")

    breaker = CircuitBreakerBlock(
        AlwaysFailBlock(),
        failure_threshold=2,  # 2회 연속 실패 → OPEN
        reset_timeout=1.0,    # 1초 후 HALF-OPEN
    )
    pipeline = Assembly([breaker])

    for i in range(4):
        try:
            await pipeline.run(ApiIn(query="test"))
        except CircuitOpenError:
            print(f"시도 {i+1}: circuit OPEN (fast-fail)")
        except Exception:
            print(f"시도 {i+1}: 실패")


# ─── DeadLetterQueue ─────────────────────────────────────────────────────────

async def run_dlq() -> None:
    dlq: DeadLetterQueue[ApiIn] = DeadLetterQueue()
    await dlq.put_failed(ApiIn(query="failed-1"), reason="처리 불가")
    await dlq.put_failed(ApiIn(query="failed-2"), reason="타임아웃")

    print(f"DLQ 항목 수: {dlq.failed_count()}")

    retry_q: Queue[ApiIn] = Queue()
    async for item, reason in dlq.failed_items():
        print(f"  재처리 대상: {item.query} — {reason}")
        await dlq.retry(item, retry_q)
    await retry_q.close()

    items = [i async for i in retry_q]
    print(f"재처리 큐 항목: {[i.query for i in items]}")


if __name__ == "__main__":
    run_retry()
    run_fallback()
    asyncio.run(run_timeout())
    asyncio.run(run_circuit_breaker())
    asyncio.run(run_dlq())
