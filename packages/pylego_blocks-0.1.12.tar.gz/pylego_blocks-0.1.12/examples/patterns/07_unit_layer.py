"""패턴 07: Unit 계층 — validate → run → verify 3단계 생명주기.

Unit 은 블록보다 상위 개념으로, 도메인 목적을 가진 실행 단위다.
실패는 전파되고 ResultUnit 이 최종 처리한다.
"""

import asyncio
from pylego_blocks import (
    Block, Stud, Unit, UnitPipeline, UnitResult, ResultUnit, ConfigBlock,
)


# ─── Stud 정의 ────────────────────────────────────────────────────────────────

class UserIn(Stud):
    name: str
    age: int

class Processed(Stud):
    name: str
    age: int
    greeting: str


# ─── Unit 구현 ────────────────────────────────────────────────────────────────

class ValidateUser(Unit[UserIn]):
    name = "ValidateUser"
    input_model = UserIn

    async def validate(self, inp: UserIn) -> None:
        if inp.age < 0:
            raise ValueError(f"나이는 0 이상이어야 합니다: {inp.age}")
        if not inp.name.strip():
            raise ValueError("이름이 비어있습니다")

    async def run(self, inp: UserIn) -> Processed:
        return Processed(
            name=inp.name.strip(),
            age=inp.age,
            greeting=f"안녕하세요, {inp.name.strip()}님!",
        )

    async def verify(self, inp: UserIn, result: Processed) -> None:
        assert result.greeting.endswith("님!"), "greeting 형식 오류"


class EnrichUser(Unit[Processed]):
    name = "EnrichUser"
    input_model = Processed

    async def run(self, inp: Processed) -> Processed:
        category = "adult" if inp.age >= 18 else "minor"
        return inp.model_copy(update={"greeting": f"[{category}] {inp.greeting}"})


# ─── ResultUnit ───────────────────────────────────────────────────────────────

class UserResultUnit(ResultUnit):
    async def on_success(self, result: object) -> UnitResult:
        return UnitResult(status="success", result=result)

    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(
            status="failure",
            reason=reason,
            failed_at=failed_at,
        )


# ─── ConfigBlock 패턴 ─────────────────────────────────────────────────────────

class AppConfig(Stud):
    max_retries: int = 3
    timeout_sec: float = 30.0

class MyConfigBlock(ConfigBlock[AppConfig]):
    output_model = AppConfig

    async def load(self) -> AppConfig:
        # 실제로는 환경변수·파일·외부 서비스에서 로드
        return AppConfig(max_retries=5, timeout_sec=60.0)


# ─── 실행 ─────────────────────────────────────────────────────────────────────

def run_success() -> None:
    pipeline = UnitPipeline(
        [ValidateUser(), EnrichUser()],
        result_unit=UserResultUnit(),
    )
    result = pipeline.run_sync(UserIn(name="홍길동", age=25))
    print(f"상태: {result.status}")
    print(f"결과: {result.result}")
    # 상태: success
    # 결과: Processed(name='홍길동', age=25, greeting='[adult] 안녕하세요, 홍길동님!')


def run_failure_propagation() -> None:
    pipeline = UnitPipeline(
        [ValidateUser(), EnrichUser()],
        result_unit=UserResultUnit(),
    )
    # 나이 -1 → ValidateUser.validate() 에서 실패 → EnrichUser 스킵
    result = pipeline.run_sync(UserIn(name="테스트", age=-1))
    print(f"상태: {result.status}")
    print(f"실패 위치: {result.failed_at}")
    print(f"실패 원인: {result.reason}")
    # 상태: failure
    # 실패 위치: ValidateUser
    # 실패 원인: 나이는 0 이상이어야 합니다: -1


async def run_config_block() -> None:
    config_block = MyConfigBlock()
    config = await config_block.run(Stud())
    print(f"설정: max_retries={config.max_retries}, timeout={config.timeout_sec}s")


if __name__ == "__main__":
    run_success()
    run_failure_propagation()
    asyncio.run(run_config_block())
