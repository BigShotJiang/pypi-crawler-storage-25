"""pylego v3.0.0 쇼케이스 — 자기 교정 AI 파이프라인.

다층 검증 아키텍처:
1. MultiPerspectiveBlock  — 3관점 병렬 평가 + 다수결 합의
2. SemanticRetryBlock     — 검증 실패 시 컨텍스트 주입 재시도
3. SignalAggregator       — 의심 신호 누적 추적
4. TapBlock               — 흐름 무중단 사이드 채널 관찰
"""

from __future__ import annotations

import asyncio

from pydantic import field_validator

from pylego_blocks import (
    Assembly,
    Block,
    CollectingEventBus,
    MajorityVote,
    MultiPerspectiveBlock,
    SemanticRetryBlock,
    SignalAggregator,
    SignalScore,
    Stud,
    TapBlock,
    build_stats,
    observe,
)
from pylego_blocks.core.multi_perspective import ConsensusPolicy


# ---------------------------------------------------------------------------
# Stud 계약
# ---------------------------------------------------------------------------


class CodeReviewRequest(Stud):
    code: str
    context: str = ""


class ReviewVerdict(Stud):
    verdict: str  # "PASS" | "FAIL" | "UNKNOWN"

    @field_validator("verdict")
    @classmethod
    def valid_verdict(cls, v: str) -> str:
        if v not in {"PASS", "FAIL"}:
            raise ValueError(f"verdict 는 PASS/FAIL 중 하나: {v}")
        return v


# ---------------------------------------------------------------------------
# 관점 블록 — 실제 AI 대신 결정적 규칙으로 시뮬레이션
# ---------------------------------------------------------------------------


class SecurityReviewBlock(Block[CodeReviewRequest, ReviewVerdict]):
    """보안 관점: eval/exec 같은 위험 패턴 감지."""

    input_model = CodeReviewRequest
    output_model = ReviewVerdict

    _danger = frozenset({"eval(", "exec(", "__import__("})

    async def run(self, inp: CodeReviewRequest) -> ReviewVerdict:
        verdict = "FAIL" if any(p in inp.code for p in self._danger) else "PASS"
        print(f"  [Security] → {verdict}")
        return ReviewVerdict(verdict=verdict)


class QualityReviewBlock(Block[CodeReviewRequest, ReviewVerdict]):
    """품질 관점: TODO/FIXME 같은 미완성 지표 감지."""

    input_model = CodeReviewRequest
    output_model = ReviewVerdict

    async def run(self, inp: CodeReviewRequest) -> ReviewVerdict:
        verdict = "FAIL" if ("TODO" in inp.code or "FIXME" in inp.code) else "PASS"
        print(f"  [Quality]  → {verdict}")
        return ReviewVerdict(verdict=verdict)


class LogicReviewBlock(Block[CodeReviewRequest, ReviewVerdict]):
    """논리 관점: 구조적 완결성 확인 (def/class 여부)."""

    input_model = CodeReviewRequest
    output_model = ReviewVerdict

    async def run(self, inp: CodeReviewRequest) -> ReviewVerdict:
        has_structure = "def " in inp.code or "class " in inp.code
        verdict = "PASS" if has_structure else "FAIL"
        print(f"  [Logic]    → {verdict}")
        return ReviewVerdict(verdict=verdict)


# ---------------------------------------------------------------------------
# 신호 수집 블록
# ---------------------------------------------------------------------------

_signal_agg = SignalAggregator(threshold=0.5, strategy="max")


class FailSignalBlock(Block[ReviewVerdict, ReviewVerdict]):
    """FAIL 판정을 의심 신호로 기록한다."""

    input_model = ReviewVerdict
    output_model = ReviewVerdict

    async def run(self, inp: ReviewVerdict) -> ReviewVerdict:
        if inp.verdict == "FAIL":
            _signal_agg.record(
                SignalScore(score=0.9, reason="최종 FAIL 판정", block_name="FailSignal")
            )
        return inp


# ---------------------------------------------------------------------------
# 검증 & 교정 함수
# ---------------------------------------------------------------------------


def verify_verdict(inp: CodeReviewRequest, out: ReviewVerdict) -> None:
    """합의 없는 판정(ConsensusError 후 fallback) 검증 — 여기서는 Stud 검증이 1차 방어선."""
    pass  # ReviewVerdict @field_validator 가 이미 PASS/FAIL 외 값을 차단한다


def enrich_request(
    inp: CodeReviewRequest, out: ReviewVerdict, error: str
) -> CodeReviewRequest:
    """이전 오류 컨텍스트를 주입하여 재시도 입력을 생성한다."""
    extra = f"[재시도] {error}"
    return inp.model_copy(update={"context": f"{inp.context} {extra}".strip()})


# ---------------------------------------------------------------------------
# 파이프라인 조립
# ---------------------------------------------------------------------------


def build_pipeline() -> Assembly:
    multi = MultiPerspectiveBlock(
        perspectives=[
            SecurityReviewBlock(),
            QualityReviewBlock(),
            LogicReviewBlock(),
        ],
        vote_fn=MajorityVote(min_agreement=2),
        consensus_policy=ConsensusPolicy(raise_error=True),
    )

    retry = SemanticRetryBlock(
        multi,
        verify_fn=verify_verdict,
        enrich_fn=enrich_request,
        max_attempts=2,
    )

    return Assembly([retry, TapBlock(FailSignalBlock())])


# ---------------------------------------------------------------------------
# 실행
# ---------------------------------------------------------------------------


async def review(label: str, code: str) -> None:
    pipeline = build_pipeline()
    bus = CollectingEventBus()
    _signal_agg.reset()

    print(f"\n{'─'*50}")
    print(f"검토: {label}")
    with observe(bus):
        result = await pipeline.run(CodeReviewRequest(code=code))

    stats = build_stats(bus.events)
    print(f"판정: {result.verdict}")
    if _signal_agg.is_suspicious:
        print("⚠ 의심 신호 감지")
    print(f"실행된 블록: {list(stats.keys())}")


if __name__ == "__main__":
    asyncio.run(review("정상 코드", 'def add(a: int, b: int) -> int:\n    return a + b'))
    asyncio.run(review("보안 위험", "result = eval(user_input)"))
    asyncio.run(review("미완성 코드", "# TODO: 구현 예정\npass"))
    asyncio.run(review("단순 스크립트", "print('hello world')"))
