"""패턴 06: 분산 큐 — asyncio.Queue → RedisQueue 교체 패턴.

pip install pylego[redis]

환경변수 한 줄로 asyncio ↔ Redis 백엔드를 전환한다.
코드는 전혀 바꾸지 않는다.
"""

import asyncio
import os
from pylego_blocks import Block, Queue, Stud, WorkerPool, make_queue


class Job(Stud):
    id: int
    data: str

class Result(Stud):
    id: int
    processed: str


class ProcessBlock(Block[Job, Result]):
    input_model = Job
    output_model = Result

    async def run(self, inp: Job) -> Result:
        await asyncio.sleep(0.01)  # 처리 시뮬레이션
        return Result(id=inp.id, processed=inp.data.upper())


# ─── 패턴 A: asyncio.Queue (단일 프로세스) ───────────────────────────────────

async def run_asyncio_queue() -> None:
    src: Queue[Job] = Queue()
    pool: WorkerPool[Job, Result] = WorkerPool(ProcessBlock(), concurrency=4)

    async with asyncio.TaskGroup() as tg:
        results_holder: list[list[Result]] = []

        async def collect() -> None:
            results_holder.append(await pool.run(src))

        tg.create_task(collect())
        for i in range(10):
            await src.put(Job(id=i, data=f"item-{i}"))
        await src.close()

    results = results_holder[0]
    print(f"asyncio 처리 완료: {len(results)}건")


# ─── 패턴 B: make_queue() 팩토리 (환경변수로 백엔드 선택) ────────────────────

async def run_with_factory() -> None:
    # asyncio 백엔드 (기본)
    # os.environ["PYLEGO_QUEUE_BACKEND"] = "asyncio"

    # Redis 백엔드 (pip install pylego[redis] 후 Redis 서버 필요)
    # os.environ["PYLEGO_QUEUE_BACKEND"] = "redis"
    # os.environ["PYLEGO_REDIS_URL"] = "redis://localhost:6379"

    q = make_queue(Job, queue_name="jobs:incoming")  # Queue or RedisQueue
    pool: WorkerPool[Job, Result] = WorkerPool(ProcessBlock(), concurrency=2)

    async with asyncio.TaskGroup() as tg:
        tg.create_task(pool.run(q))  # type: ignore[arg-type]
        for i in range(5):
            await q.put(Job(id=i, data=f"task-{i}"))  # type: ignore[union-attr]
        await q.close()  # type: ignore[union-attr]

    print("팩토리 패턴 완료")


# ─── 패턴 C: RedisQueue 직접 사용 (멀티머신) ─────────────────────────────────

async def run_redis_queue() -> None:
    """Redis 서버가 실행 중일 때 사용."""
    from pylego_blocks import RedisQueue, RedisWorkerPool

    src: RedisQueue[Job] = RedisQueue(
        Job,
        url=os.getenv("PYLEGO_REDIS_URL", "redis://localhost:6379"),
        queue_name="jobs:distributed",
    )
    dst: RedisQueue[Result] = RedisQueue(
        Result,
        url=os.getenv("PYLEGO_REDIS_URL", "redis://localhost:6379"),
        queue_name="results:distributed",
    )
    pool: RedisWorkerPool[Job, Result] = RedisWorkerPool(ProcessBlock(), concurrency=4)

    async with asyncio.TaskGroup() as tg:
        tg.create_task(pool.run(src, output=dst))
        for i in range(10):
            await src.put(Job(id=i, data=f"job-{i}"))
        await src.close()

    print("Redis 분산 처리 완료")

    await src.aclose_client()
    await dst.aclose_client()


if __name__ == "__main__":
    asyncio.run(run_asyncio_queue())
    asyncio.run(run_with_factory())
    # asyncio.run(run_redis_queue())  # Redis 서버 필요
