"""패턴 02: FanOut (병렬 분기) + Branch (조건 분기).

FanOut: 동일 입력을 N개 블록에 병렬 전달 → Gathered(results=(...))
Branch: 조건 함수 반환값(인덱스)으로 블록 선택
"""

from pylego_blocks import Assembly, Block, Branch, FanOut, Gathered, Stud


class Score(Stud):
    value: float

class Normalized(Stud):
    score: float

class Label(Stud):
    tag: str

class Doubled(Stud):
    value: float


# ─── FanOut ───────────────────────────────────────────────────────────────────

class NormalizeBlock(Block[Score, Normalized]):
    input_model = Score
    output_model = Normalized

    async def run(self, inp: Score) -> Normalized:
        return Normalized(score=round(inp.value / 100, 3))


class LabelBlock(Block[Score, Label]):
    input_model = Score
    output_model = Label

    async def run(self, inp: Score) -> Label:
        return Label(tag="high" if inp.value >= 70 else "low")


def run_fanout() -> None:
    fan = FanOut([NormalizeBlock(), LabelBlock()])
    pipeline = Assembly([fan])
    result: Gathered = pipeline.run_sync(Score(value=85.0))
    normalized, label = result.results
    print(normalized)  # Normalized(score=0.85)
    print(label)       # Label(tag='high')


# ─── Branch ───────────────────────────────────────────────────────────────────

class DoubleBlock(Block[Score, Doubled]):
    input_model = Score
    output_model = Doubled

    async def run(self, inp: Score) -> Doubled:
        return Doubled(value=inp.value * 2)


class TripleBlock(Block[Score, Doubled]):
    input_model = Score
    output_model = Doubled

    async def run(self, inp: Score) -> Doubled:
        return Doubled(value=inp.value * 3)


def run_branch() -> None:
    # predicate True → on_true(DoubleBlock), False → on_false(TripleBlock)
    branch = Branch(
        predicate=lambda inp: inp.value >= 50,
        on_true=DoubleBlock(),
        on_false=TripleBlock(),
    )
    high = Assembly([branch]).run_sync(Score(value=80.0))
    print(high.value)   # 160.0 (doubled)

    low = Assembly([branch]).run_sync(Score(value=30.0))
    print(low.value)    # 90.0 (tripled)


if __name__ == "__main__":
    run_fanout()
    run_branch()
