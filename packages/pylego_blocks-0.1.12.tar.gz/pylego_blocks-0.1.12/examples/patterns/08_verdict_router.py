"""Pattern 08 — VerdictRouter: AI 판정 파싱 + UNKNOWN 에스컬레이션.

VerdictParseBlock은 AI 응답 마지막 줄이 정확히 "VERDICT: PASS" / "VERDICT: FAIL" 인지
검증한다. VerdictRouter는 UNKNOWN 발생 시 정책(raise / fallback / escalate)을 적용한다.
"""

from __future__ import annotations

import asyncio

from pylego_blocks.blocks.ai import (
    UnknownPolicy,
    UnknownVerdictError,
    Verdict,
    VerdictParseBlock,
    VerdictParseRequest,
    VerdictRouter,
)
from pylego_blocks.core.block import Block


# ── 패턴 A: 기본 라우터 — UNKNOWN 그대로 통과 ─────────────────────────────────

async def pattern_a_default() -> None:
    router = VerdictRouter()

    for text, label in [
        ("검토 결과 문제 없음.\nVERDICT: PASS", "PASS"),
        ("실패 이유: 타입 불일치.\nVERDICT: FAIL", "FAIL"),
        ("잘 모르겠습니다.", "UNKNOWN (통과)"),
    ]:
        verdict = await router.run(VerdictParseRequest(text=text))
        print(f"[A] {label}: {verdict.result}")


# ── 패턴 B: UNKNOWN → 예외 발생 ────────────────────────────────────────────────

async def pattern_b_raise_error() -> None:
    router = VerdictRouter(unknown_policy=UnknownPolicy(raise_error=True))

    try:
        await router.run(VerdictParseRequest(text="판단 불가"))
    except UnknownVerdictError as exc:
        print(f"[B] UnknownVerdictError 발생: {exc}")


# ── 패턴 C: UNKNOWN → 폴백 블록 ────────────────────────────────────────────────

class ConservativeFallbackBlock(Block[VerdictParseRequest, Verdict]):
    """UNKNOWN 상황에서 보수적으로 FAIL 처리."""

    input_model = VerdictParseRequest
    output_model = Verdict

    async def run(self, inp: VerdictParseRequest) -> Verdict:
        print(f"  [fallback] 원본 텍스트 재분석 중: {inp.text[:50]!r}")
        return Verdict(result="FAIL")


async def pattern_c_fallback() -> None:
    router = VerdictRouter(
        unknown_policy=UnknownPolicy(fallback=ConservativeFallbackBlock()),
    )
    verdict = await router.run(VerdictParseRequest(text="AI가 형식을 지키지 않음"))
    print(f"[C] 폴백 결과: {verdict.result}")


# ── 패턴 D: UNKNOWN → 에스컬레이션 후 UNKNOWN 반환 ────────────────────────────

class AlertBlock(Block[VerdictParseRequest, Verdict]):
    """알림 사이드채널 — UNKNOWN 발생 시 로깅/큐잉."""

    input_model = VerdictParseRequest
    output_model = Verdict

    async def run(self, inp: VerdictParseRequest) -> Verdict:
        print(f"  [alert] UNKNOWN 감지, 알림 전송: {inp.text[:40]!r}")
        return Verdict(result="UNKNOWN")


async def pattern_d_escalate() -> None:
    router = VerdictRouter(
        unknown_policy=UnknownPolicy(escalate_to=AlertBlock()),
    )
    verdict = await router.run(VerdictParseRequest(text="판정 형식 미준수"))
    print(f"[D] 에스컬레이션 후 반환: {verdict.result}")


# ── 패턴 E: strict=False — 대소문자 무관 매칭 ─────────────────────────────────

async def pattern_e_non_strict() -> None:
    router = VerdictRouter(verdict_block=VerdictParseBlock(strict=False))

    for text in ["verdict: pass", "Verdict: Fail", "VERDICT: PASS"]:
        verdict = await router.run(VerdictParseRequest(text=text))
        print(f"[E] {text!r} → {verdict.result}")


# ── 실행 ────────────────────────────────────────────────────────────────────

async def main() -> None:
    print("=== Pattern A: 기본 라우터 ===")
    await pattern_a_default()

    print("\n=== Pattern B: raise_error ===")
    await pattern_b_raise_error()

    print("\n=== Pattern C: fallback 블록 ===")
    await pattern_c_fallback()

    print("\n=== Pattern D: escalate_to ===")
    await pattern_d_escalate()

    print("\n=== Pattern E: strict=False ===")
    await pattern_e_non_strict()


if __name__ == "__main__":
    asyncio.run(main())
