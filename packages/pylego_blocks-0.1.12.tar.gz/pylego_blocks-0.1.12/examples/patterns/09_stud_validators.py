"""패턴 09: Stud 의미론적 검증 — @field_validator / @model_validator.

Stud 는 형태(Shape) 계약만 강제하지 않는다.
pydantic v2 검증기로 의미(Semantic) 제약을 Stud 안에 직접 선언할 수 있다.

  - @field_validator  : 단일 필드 범위·형식·도메인 규칙
  - @model_validator  : 교차 필드 일관성 검증
  - Unit.validate()   : 외부 의존성이 필요한 런타임 검증
"""

import asyncio

from pydantic import field_validator, model_validator

from pylego_blocks import Assembly, Block, Stud, Unit, UnitPipeline, ResultUnit, UnitResult


# ─── 패턴 A: @field_validator — 단일 필드 범위 검증 ───────────────────────────

class Score(Stud):
    value: float
    label: str

    @field_validator("value")
    @classmethod
    def must_be_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 100.0):
            raise ValueError(f"점수는 0~100 범위여야 합니다: {v}")
        return v


def run_field_validator() -> None:
    try:
        bad = Score(value=150.0, label="high")
    except Exception as e:
        print(f"필드 검증 실패: {e}")  # 점수는 0~100 범위

    ok = Score(value=85.0, label="high")
    print(f"유효한 점수: {ok.value}")   # 85.0


# ─── 패턴 B: @model_validator — 교차 필드 일관성 검증 ────────────────────────

class AiResponse(Stud):
    verdict: str       # "PASS" / "FAIL" / "UNKNOWN"
    confidence: float  # 0.0 ~ 1.0
    reasoning: str

    @field_validator("confidence")
    @classmethod
    def confidence_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError(f"confidence는 0~1 범위: {v}")
        return v

    @model_validator(mode="after")
    def unknown_requires_low_confidence(self) -> "AiResponse":
        if self.verdict == "UNKNOWN" and self.confidence > 0.5:
            raise ValueError(
                f"UNKNOWN 판정은 confidence ≤ 0.5 이어야 합니다 (현재: {self.confidence})"
            )
        return self


def run_model_validator() -> None:
    try:
        bad = AiResponse(verdict="UNKNOWN", confidence=0.9, reasoning="모르겠음")
    except Exception as e:
        print(f"교차 필드 검증 실패: {e}")  # UNKNOWN + high confidence 불가

    ok = AiResponse(verdict="PASS", confidence=0.95, reasoning="명확한 PASS")
    print(f"유효한 응답: {ok.verdict} ({ok.confidence:.0%})")  # PASS (95%)


# ─── 패턴 C: AI 출력 형식 검증 Stud ─────────────────────────────────────────

class ReviewRequest(Stud):
    code: str
    language: str = "python"

    @field_validator("language")
    @classmethod
    def supported_language(cls, v: str) -> str:
        allowed = {"python", "typescript", "go", "rust"}
        if v.lower() not in allowed:
            raise ValueError(f"지원하지 않는 언어: {v}. 허용: {allowed}")
        return v.lower()


class ReviewResult(Stud):
    verdict: str
    issues: list[str]
    score: float

    @field_validator("verdict")
    @classmethod
    def valid_verdict(cls, v: str) -> str:
        allowed = {"PASS", "FAIL", "UNKNOWN"}
        if v.upper() not in allowed:
            raise ValueError(f"유효하지 않은 판정: {v}")
        return v.upper()

    @field_validator("score")
    @classmethod
    def score_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 10.0):
            raise ValueError(f"점수는 0~10 범위: {v}")
        return v

    @model_validator(mode="after")
    def fail_requires_issues(self) -> "ReviewResult":
        if self.verdict == "FAIL" and not self.issues:
            raise ValueError("FAIL 판정에는 issues 목록이 필요합니다")
        return self


class MockReviewBlock(Block[ReviewRequest, ReviewResult]):
    input_model = ReviewRequest
    output_model = ReviewResult

    async def run(self, inp: ReviewRequest) -> ReviewResult:
        return ReviewResult(
            verdict="FAIL",
            issues=["타입 힌트 누락", "문서 없음"],
            score=4.5,
        )


def run_review_pipeline() -> None:
    pipeline = Assembly([MockReviewBlock()])
    result = pipeline.run_sync(ReviewRequest(code="def foo(): pass"))
    print(f"리뷰: {result.verdict}, 이슈 {len(result.issues)}건, 점수: {result.score}")


# ─── 패턴 D: Unit.validate() — 외부 의존 런타임 검증 ─────────────────────────

class UserInput(Stud):
    username: str
    email: str

    @field_validator("email")
    @classmethod
    def email_format(cls, v: str) -> str:
        if "@" not in v:
            raise ValueError(f"이메일 형식이 아닙니다: {v}")
        return v.lower()


class UserOutput(Stud):
    username: str
    email: str
    normalized: bool = True


BANNED_USERS = {"spammer", "bot"}

class UserUnit(Unit[UserInput]):
    name = "UserUnit"
    input_model = UserInput

    async def validate(self, inp: UserInput) -> None:
        # 외부 상태(DB·캐시)를 참조하는 런타임 검증 → Unit.validate()
        if inp.username.lower() in BANNED_USERS:
            raise ValueError(f"금지된 사용자: {inp.username}")

    async def run(self, inp: UserInput) -> UserOutput:
        return UserOutput(username=inp.username, email=inp.email)

    async def verify(self, inp: UserInput, result: UserOutput) -> None:
        assert result.normalized, "정규화 플래그가 설정되지 않았습니다"


class SimpleResult(ResultUnit):
    async def on_success(self, result: object) -> UnitResult:
        return UnitResult(status="success", result=result)
    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(status="failure", reason=reason, failed_at=failed_at)


def run_unit_validation() -> None:
    pipeline = UnitPipeline([UserUnit()], result_unit=SimpleResult())

    # 성공
    ok = pipeline.run_sync(UserInput(username="홍길동", email="hong@example.com"))
    print(f"성공: {ok.status}, 결과: {ok.result}")

    # @field_validator 실패 (Stud 레벨)
    try:
        UserInput(username="test", email="invalid_email")
    except Exception as e:
        print(f"이메일 형식 오류: {e}")

    # Unit.validate() 실패 (런타임 레벨)
    banned = pipeline.run_sync(UserInput(username="spammer", email="spam@example.com"))
    print(f"금지 사용자: {banned.status}, 이유: {banned.reason}")


if __name__ == "__main__":
    print("=== 패턴 A: @field_validator ===")
    run_field_validator()
    print("\n=== 패턴 B: @model_validator ===")
    run_model_validator()
    print("\n=== 패턴 C: AI 출력 형식 검증 ===")
    run_review_pipeline()
    print("\n=== 패턴 D: Unit.validate() 런타임 검증 ===")
    run_unit_validation()
