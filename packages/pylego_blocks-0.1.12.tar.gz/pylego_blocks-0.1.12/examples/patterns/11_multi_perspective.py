"""Pattern 11 — MultiPerspectiveBlock: 복수 AI 관점 병렬 실행 및 합의.

동일 입력에 대해 N개의 관점 블록을 병렬 실행하고 합의 전략으로 최종 결과를 도출한다.
합의 실패 시 ConsensusPolicy 로 에스컬레이션 경로를 제어한다.
"""

from __future__ import annotations

import asyncio

from pylego_blocks import (
    Assembly,
    ConsensusError,
    ConsensusPolicy,
    MultiPerspectiveBlock,
    SignalAggregator,
    SignalScore,
    Stud,
    ConfidenceWeighted,
    MajorityVote,
    UnanimousRequired,
)
from pylego_blocks.core.block import Block


# ── Stud 계약 ─────────────────────────────────────────────────────────────────

class ReviewRequest(Stud):
    code: str


class ReviewVerdict(Stud):
    verdict: str   # "PASS" | "FAIL" | "REVIEW"
    note: str = ""


# ── 관점 블록들 ────────────────────────────────────────────────────────────────

class StrictReviewerBlock(Block[ReviewRequest, ReviewVerdict]):
    """엄격한 관점: 짧은 코드는 FAIL."""

    input_model = ReviewRequest
    output_model = ReviewVerdict

    async def run(self, inp: ReviewRequest) -> ReviewVerdict:
        verdict = "FAIL" if len(inp.code) < 20 else "PASS"
        print(f"  [Strict] {verdict!r} (코드 길이={len(inp.code)})")
        return ReviewVerdict(verdict=verdict)


class LenientReviewerBlock(Block[ReviewRequest, ReviewVerdict]):
    """우호적 관점: 항상 PASS."""

    input_model = ReviewRequest
    output_model = ReviewVerdict

    async def run(self, inp: ReviewRequest) -> ReviewVerdict:
        print("  [Lenient] 'PASS' (우호적 판정)")
        return ReviewVerdict(verdict="PASS")


class NeutralReviewerBlock(Block[ReviewRequest, ReviewVerdict]):
    """중립 관점: 키워드 존재 여부로 판단."""

    input_model = ReviewRequest
    output_model = ReviewVerdict

    async def run(self, inp: ReviewRequest) -> ReviewVerdict:
        verdict = "PASS" if "def " in inp.code else "REVIEW"
        print(f"  [Neutral] {verdict!r} (함수 선언 존재={('def ' in inp.code)})")
        return ReviewVerdict(verdict=verdict)


# ── 패턴 A: MajorityVote — 최다 득표 ────────────────────────────────────────

async def pattern_a_MajorityVote() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[StrictReviewerBlock(), LenientReviewerBlock(), NeutralReviewerBlock()],
        vote_fn=MajorityVote(min_agreement=2),
    )
    req = ReviewRequest(code="def hello(): pass")
    result = await block.run(req)
    print(f"[A] 합의 결과: {result.verdict!r}")


# ── 패턴 B: UnanimousRequired — 전원 일치 ──────────────────────────────────

async def pattern_b_unanimous() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[LenientReviewerBlock(), LenientReviewerBlock()],
        vote_fn=UnanimousRequired(),
    )
    result = await block.run(ReviewRequest(code="x = 1"))
    print(f"[B] 전원 일치 결과: {result.verdict!r}")


# ── 패턴 C: UnanimousRequired + ConsensusPolicy(raise_error=True) ───────────

async def pattern_c_consensus_fail_raise() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[StrictReviewerBlock(), LenientReviewerBlock()],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(raise_error=True),
    )
    try:
        await block.run(ReviewRequest(code="x"))
    except ConsensusError as e:
        print(f"[C] 합의 실패 예외: {e}")


# ── 패턴 D: ConsensusPolicy(fallback=...) ───────────────────────────────────

class ConservativeFallback(Block[ReviewRequest, ReviewVerdict]):
    input_model = ReviewRequest
    output_model = ReviewVerdict

    async def run(self, inp: ReviewRequest) -> ReviewVerdict:
        print("  [Fallback] 합의 실패 → 보수적 FAIL 반환")
        return ReviewVerdict(verdict="FAIL")


async def pattern_d_fallback() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[StrictReviewerBlock(), LenientReviewerBlock()],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(fallback=ConservativeFallback()),
    )
    result = await block.run(ReviewRequest(code="x"))
    print(f"[D] 폴백 결과: {result.verdict!r}")


# ── 패턴 E: ConfidenceWeighted + SignalAggregator 역가중치 ──────────────────

async def pattern_e_ConfidenceWeighted() -> None:
    # 각 관점의 신뢰도를 SignalAggregator 로 측정
    agg = SignalAggregator(threshold=0.5)
    agg.record(SignalScore(score=0.8, block_name="Strict"))     # 의심도 높음 → 낮은 가중치
    agg.record(SignalScore(score=0.1, block_name="Lenient"))    # 의심도 낮음 → 높은 가중치
    agg.record(SignalScore(score=0.4, block_name="Neutral"))

    # 역가중치: 낮은 의심도 = 높은 신뢰
    weights = [1.0 - s.score for s in agg.scores]

    block = MultiPerspectiveBlock(
        perspectives=[StrictReviewerBlock(), LenientReviewerBlock(), NeutralReviewerBlock()],
        vote_fn=ConfidenceWeighted(weights),
    )
    result = await block.run(ReviewRequest(code="x"))
    print(f"[E] 가중치={[f'{w:.1f}' for w in weights]}, 채택 결과: {result.verdict!r}")


# ── 패턴 F: Assembly 체인에 MultiPerspectiveBlock 삽입 ──────────────────────

class LogBlock(Block[ReviewVerdict, ReviewVerdict]):
    input_model = ReviewVerdict
    output_model = ReviewVerdict

    async def run(self, inp: ReviewVerdict) -> ReviewVerdict:
        print(f"  [Log] 최종 판정: {inp.verdict!r} ({inp.note})")
        return inp


async def pattern_f_in_assembly() -> None:
    pipeline = Assembly([
        MultiPerspectiveBlock(
            perspectives=[StrictReviewerBlock(), LenientReviewerBlock(), NeutralReviewerBlock()],
            vote_fn=MajorityVote(min_agreement=2),
            name="ConsensusBlock",
        ),
        LogBlock(),
    ])
    result = await pipeline.run(ReviewRequest(code="def greet(): return 'hi'"))
    print(f"[F] 파이프라인 결과: {result.verdict!r}")


# ── 실행 ─────────────────────────────────────────────────────────────────────

async def main() -> None:
    print("=== Pattern A: MajorityVote ===")
    await pattern_a_MajorityVote()

    print("\n=== Pattern B: UnanimousRequired (성공) ===")
    await pattern_b_unanimous()

    print("\n=== Pattern C: UnanimousRequired (실패 → raise) ===")
    await pattern_c_consensus_fail_raise()

    print("\n=== Pattern D: ConsensusPolicy fallback ===")
    await pattern_d_fallback()

    print("\n=== Pattern E: ConfidenceWeighted + SignalAggregator ===")
    await pattern_e_ConfidenceWeighted()

    print("\n=== Pattern F: Assembly 체인 ===")
    await pattern_f_in_assembly()


if __name__ == "__main__":
    asyncio.run(main())
