"""FanOut 동시 분기 예제.

동일 입력을 3개 브랜치에 동시에 전달하고 결과를 Gathered로 수집한다.

실행:
    uv run python examples/fanout_pipeline.py
"""

from __future__ import annotations

import asyncio

from pylego_blocks.core.block import Block
from pylego_blocks.core.fanout import FanOut, Gathered
from pylego_blocks.core.stud import Stud


class TextInput(Stud):
    text: str


class UpperOutput(Stud):
    text: str


class LengthOutput(Stud):
    length: int


class WordCountOutput(Stud):
    words: int


class UpperBlock(Block[TextInput, UpperOutput]):
    input_model = TextInput
    output_model = UpperOutput

    async def run(self, inp: TextInput) -> UpperOutput:
        return UpperOutput(text=inp.text.upper())


class LengthBlock(Block[TextInput, LengthOutput]):
    input_model = TextInput
    output_model = LengthOutput

    async def run(self, inp: TextInput) -> LengthOutput:
        return LengthOutput(length=len(inp.text))


class WordCountBlock(Block[TextInput, WordCountOutput]):
    input_model = TextInput
    output_model = WordCountOutput

    async def run(self, inp: TextInput) -> WordCountOutput:
        return WordCountOutput(words=len(inp.text.split()))


async def main() -> None:
    fan = FanOut(
        [UpperBlock(), LengthBlock(), WordCountBlock()],
        name="text-analyzer",
    )

    result: Gathered = await fan.run(TextInput(text="hello pylego world"))

    upper_out, length_out, word_out = result.results
    print(f"upper:  {upper_out.text}")    # HELLO PYLEGO WORLD
    print(f"length: {length_out.length}") # 18
    print(f"words:  {word_out.words}")    # 3


if __name__ == "__main__":
    asyncio.run(main())
