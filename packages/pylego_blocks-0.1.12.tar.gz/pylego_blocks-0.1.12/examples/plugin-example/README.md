# pylego-example

pylego 플러그인 패키지의 최소 예시입니다. 이 패키지를 참고해 서드파티 블록을 만들고
`BlockRegistry.discover()` 를 통해 자동 등록되도록 배포할 수 있습니다.

## 설치

```bash
# 개발 모드로 설치 (pylego 가 먼저 설치되어 있어야 함)
pip install pylego
pip install -e examples/plugin-example
```

## 사용 방법

```python
from pylego_blocks import default_registry

# 설치된 entry-points 에서 블록 자동 수집
discovered = default_registry.discover()
print(f"발견된 블록: {[cls.__name__ for cls in discovered]}")
# -> 발견된 블록: ['ReverseBlock', 'UpperCaseBlock']

# 이름으로 직접 사용
UpperCase = default_registry.get("UpperCaseBlock")
Reverse = default_registry.get("ReverseBlock")
```

## CLI 에서 확인

```bash
# entry-points 로 등록된 블록 포함해서 목록 표시
python -m pylego inspect list --installed
```

## 플러그인 패키지 만들기

1. `pylego.Block` 을 상속해 블록을 정의합니다.
2. `pyproject.toml` 에 entry-points 를 선언합니다.

```toml
[project.entry-points."pylego.blocks"]
my_block = "my_package.blocks:MyBlock"
```

3. 패키지를 배포(`pip install`)하면 `BlockRegistry.discover()` 가 자동으로 인식합니다.

## 블록 구조

| 블록 | 입력 | 출력 | 설명 |
|------|------|------|------|
| `UpperCaseBlock` | `TextIn(text)` | `TextOut(text)` | 텍스트를 대문자로 변환 |
| `ReverseBlock` | `TextIn(text)` | `TextOut(text)` | 텍스트를 역순으로 반환 |
