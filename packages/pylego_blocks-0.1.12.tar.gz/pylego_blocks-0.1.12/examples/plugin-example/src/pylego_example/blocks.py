"""pylego-example 플러그인 블록 정의.

이 모듈은 pylego 플러그인 패키지가 블록을 정의하고 entry-points 를 통해
BlockRegistry.discover() 에 자동 등록되는 방법을 보여주는 최소 예시다.
"""

from __future__ import annotations

from pylego_blocks import Block, Stud


class TextIn(Stud):
    """텍스트 입력 계약."""

    text: str


class TextOut(Stud):
    """텍스트 출력 계약."""

    text: str


class UpperCaseBlock(Block[TextIn, TextOut]):
    """입력 텍스트를 대문자로 변환하는 예시 블록."""

    input_model = TextIn
    output_model = TextOut

    async def run(self, inp: TextIn) -> TextOut:
        return TextOut(text=inp.text.upper())


class ReverseBlock(Block[TextIn, TextOut]):
    """입력 텍스트를 역순으로 반환하는 예시 블록."""

    input_model = TextIn
    output_model = TextOut

    async def run(self, inp: TextIn) -> TextOut:
        return TextOut(text=inp.text[::-1])
