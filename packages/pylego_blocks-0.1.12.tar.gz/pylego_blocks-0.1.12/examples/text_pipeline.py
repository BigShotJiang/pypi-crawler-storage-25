"""Block 정의 → Assembly 조립 → run_sync 최소 예제.

실행:
    uv run python examples/text_pipeline.py
"""

from __future__ import annotations

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class TextInput(Stud):
    text: str


class UpperOutput(Stud):
    text: str


class LengthOutput(Stud):
    length: int


class UpperBlock(Block[TextInput, UpperOutput]):
    input_model = TextInput
    output_model = UpperOutput

    async def run(self, inp: TextInput) -> UpperOutput:
        return UpperOutput(text=inp.text.upper())


class LengthBlock(Block[UpperOutput, LengthOutput]):
    input_model = UpperOutput
    output_model = LengthOutput

    async def run(self, inp: UpperOutput) -> LengthOutput:
        return LengthOutput(length=len(inp.text))


if __name__ == "__main__":
    pipeline: Assembly[TextInput, LengthOutput] = Assembly([UpperBlock(), LengthBlock()], name="text-pipeline")
    print(pipeline)  # text-pipeline[UpperBlock → LengthBlock]

    result = pipeline.run_sync(TextInput(text="hello, pylego"))
    print(f"upper:  {result.length}")  # 13  (HELLO, PYLEGO 의 길이)
