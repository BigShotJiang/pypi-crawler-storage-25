"""BlockRegistry v2 — 메타데이터·검색·Stud 탐색 테스트 (M88)."""

from __future__ import annotations

from pylego_blocks import Block, Stud
from pylego_blocks.registry import BlockInfo, BlockRegistry


class _AInput(Stud):
    value: int


class _AOutput(Stud):
    result: str


class _BInput(Stud):
    text: str


class _BOutput(Stud):
    length: int


def _make_registry() -> BlockRegistry:
    reg = BlockRegistry()

    class AlphaBlock(Block[_AInput, _AOutput]):
        input_model = _AInput
        output_model = _AOutput

        async def run(self, inp: _AInput) -> _AOutput:
            return _AOutput(result=str(inp.value))

    class BetaBlock(Block[_BInput, _BOutput]):
        input_model = _BInput
        output_model = _BOutput

        async def run(self, inp: _BInput) -> _BOutput:
            return _BOutput(length=len(inp.text))

    reg.register(AlphaBlock, tags=["math", "convert"], description="정수를 문자열로 변환한다")
    reg.register(BetaBlock, tags=["text", "math"], description="텍스트 길이를 측정한다")
    return reg


# ── describe ─────────────────────────────────────────────────────────────────

def test_describe_returns_block_info() -> None:
    reg = _make_registry()
    info = reg.describe("AlphaBlock")
    assert isinstance(info, BlockInfo)
    assert info.name == "AlphaBlock"
    assert info.input_model == "_AInput"
    assert info.output_model == "_AOutput"
    assert "math" in info.tags


def test_describe_accepts_class() -> None:
    reg = _make_registry()
    cls = reg.get("AlphaBlock")
    info = reg.describe(cls)
    assert info.name == "AlphaBlock"


def test_describe_missing_raises_key_error() -> None:
    reg = BlockRegistry()
    try:
        reg.describe("NonExistent")
        assert False, "should raise"
    except KeyError:
        pass


# ── all_info ─────────────────────────────────────────────────────────────────

def test_all_info_returns_sorted() -> None:
    reg = _make_registry()
    infos = reg.all_info()
    names = [i.name for i in infos]
    assert names == sorted(names)
    assert len(infos) == 2


def test_all_info_no_tags_still_included() -> None:
    reg = BlockRegistry()

    class PlainBlock(Block[_AInput, _AOutput]):
        input_model = _AInput
        output_model = _AOutput

        async def run(self, inp: _AInput) -> _AOutput:
            return _AOutput(result="")

    reg.register(PlainBlock)
    infos = reg.all_info()
    assert any(i.name == "PlainBlock" for i in infos)
    plain = reg.describe("PlainBlock")
    assert plain.tags == []
    assert plain.description == ""


# ── search ────────────────────────────────────────────────────────────────────

def test_search_by_name() -> None:
    reg = _make_registry()
    results = reg.search("Alpha")
    assert len(results) == 1
    assert results[0].name == "AlphaBlock"


def test_search_by_description() -> None:
    reg = _make_registry()
    results = reg.search("길이")
    assert len(results) == 1
    assert results[0].name == "BetaBlock"


def test_search_by_tag() -> None:
    reg = _make_registry()
    results = reg.search("math")
    names = {r.name for r in results}
    assert "AlphaBlock" in names
    assert "BetaBlock" in names


def test_search_case_insensitive() -> None:
    reg = _make_registry()
    assert reg.search("ALPHA") == reg.search("alpha")


def test_search_no_match_returns_empty() -> None:
    reg = _make_registry()
    assert reg.search("zzznomatch") == []


# ── search_by_tag ─────────────────────────────────────────────────────────────

def test_search_by_tag_single() -> None:
    reg = _make_registry()
    results = reg.search_by_tag("text")
    assert len(results) == 1
    assert results[0].name == "BetaBlock"


def test_search_by_tag_and_condition() -> None:
    reg = _make_registry()
    results = reg.search_by_tag("math", "convert")
    assert len(results) == 1
    assert results[0].name == "AlphaBlock"


def test_search_by_tag_no_match() -> None:
    reg = _make_registry()
    assert reg.search_by_tag("nonexistent") == []


# ── compatible_with ───────────────────────────────────────────────────────────

def test_compatible_with_returns_matching_blocks() -> None:
    reg = _make_registry()
    results = reg.compatible_with(_AInput)
    assert len(results) == 1
    assert results[0].name == "AlphaBlock"


def test_compatible_with_no_match_returns_empty() -> None:
    reg = _make_registry()

    class _CInput(Stud):
        x: float

    assert reg.compatible_with(_CInput) == []


# ── @register 데코레이터 형식 ──────────────────────────────────────────────────

def test_register_decorator_with_args() -> None:
    from pylego_blocks.registry import BlockRegistry

    reg = BlockRegistry()

    @reg.register  # type: ignore[arg-type]
    class SimpleBlock(Block[_AInput, _AOutput]):  # type: ignore[misc]
        input_model = _AInput
        output_model = _AOutput

        async def run(self, inp: _AInput) -> _AOutput:
            return _AOutput(result="")

    assert reg.get("SimpleBlock") is SimpleBlock
