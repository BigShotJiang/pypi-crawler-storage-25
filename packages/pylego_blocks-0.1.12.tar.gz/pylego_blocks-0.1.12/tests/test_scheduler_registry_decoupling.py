"""M126 — Scheduler-Registry 결합 해제 테스트."""

from __future__ import annotations

import importlib
import sys
import warnings
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pylego_blocks import Assembly, Block, Stud
from pylego_blocks.scheduler import SchedulerPolicy, ThawPolicy


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    x: int = 0


class _Out(Stud):
    y: int = 0


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(y=inp.x)


def _pipeline() -> Assembly[_In, _Out]:
    return Assembly([_OkBlock()])


# ── apscheduler mock 헬퍼 ─────────────────────────────────────────────────────


def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        sys.modules,
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


def _make_scheduler() -> Any:
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        return sched_mod.Scheduler()


# ── 테스트 ────────────────────────────────────────────────────────────────────


def test_probe_updates_registry_default_is_false() -> None:
    """probe_updates_registry 기본값은 False."""
    policy = SchedulerPolicy()
    assert policy.probe_updates_registry is False


def test_probe_updates_registry_false_skips_update_stat() -> None:
    """probe_updates_registry=False 이면 update_stat 호출 없이 probe만 실행한다."""
    import pylego_blocks.registry as reg_module
    from pylego_blocks.registry import BlockRegistry

    orig = reg_module.default_registry
    try:
        test_reg = BlockRegistry()
        reg_module.default_registry = test_reg  # type: ignore[assignment]

        policy = SchedulerPolicy(probe_updates_registry=False)

        probe_ok = True
        # probe_updates_registry=False 이면 update_stat 호출 건너뜀
        if policy.probe_updates_registry:
            test_reg.update_stat("any", success=probe_ok, elapsed_sec=0.0)

        # 아무 통계도 쌓이지 않아야 한다
        assert test_reg.all_info() == []
    finally:
        reg_module.default_registry = orig  # type: ignore[assignment]


def test_probe_updates_registry_true_calls_update_stat() -> None:
    """probe_updates_registry=True 이면 probe 결과가 Registry에 반영된다."""
    import pylego_blocks.registry as reg_module
    from pylego_blocks.registry import BlockRegistry

    class _PipelineBlock(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:
            return _Out(y=inp.x)

    orig = reg_module.default_registry
    try:
        test_reg = BlockRegistry()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            test_reg.register(_PipelineBlock)
        reg_module.default_registry = test_reg  # type: ignore[assignment]

        policy = SchedulerPolicy(probe_updates_registry=True)

        probe_ok = True
        if policy.probe_updates_registry:
            test_reg.update_stat("_PipelineBlock", success=probe_ok, elapsed_sec=0.0)

        info = test_reg.describe("_PipelineBlock")
        assert info.runtime is not None
        assert info.runtime.success_count == 1
    finally:
        reg_module.default_registry = orig  # type: ignore[assignment]


@pytest.mark.asyncio
async def test_canary_with_unregistered_job_id_no_error() -> None:
    """미등록 job_id canary 선택 시 오류 없이 실행된다."""
    import pylego_blocks.scheduler as sched_mod
    importlib.reload(sched_mod)

    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        importlib.reload(sched_mod)
        sched = sched_mod.Scheduler()

    tp = sched_mod.ThawPolicy(strategy="canary", canary_interval_sec=0.0, success_threshold=1)
    gp = sched_mod.GlobalSchedulerPolicy(freeze_on_alert=True, thaw_policy=tp)
    sched.set_global_policy(gp)

    sched.add(
        _pipeline(),
        input=_In(x=0),
        interval_seconds=9999.0,
        job_id="unregistered_canary",
    )
    sched._frozen = True
    sched._last_canary_at = 0.0

    # job_id가 default_registry에 없어도 KeyError 없이 정상 실행돼야 한다
    await sched._maybe_auto_thaw()

    # 카나리 성공 → frozen 해제
    assert not sched._frozen
