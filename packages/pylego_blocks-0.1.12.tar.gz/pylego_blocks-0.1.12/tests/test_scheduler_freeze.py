"""M104 — Scheduler Active Freeze + Circuit Probe 테스트."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, call

import pytest

from pylego_blocks import Assembly, Block, GlobalSchedulerPolicy, SchedulerPolicy, Stud
from pylego_blocks.scheduler import JobStatus, Scheduler, _JobState


# ── 더미 파이프라인 ───────────────────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _Ok(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _Fail(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("fail")


def _make_ok_pipeline() -> Assembly[_In, _Out]:
    return Assembly([_Ok()])


def _make_fail_pipeline() -> Assembly[_In, _Out]:
    return Assembly([_Fail()])


def _extract_run_fn(mock_scheduler: MagicMock, idx: int = 0) -> Any:
    """add_job call list에서 _run 코루틴 함수를 꺼낸다."""
    return mock_scheduler.add_job.call_args_list[idx][0][0]


from typing import Any


# ── freeze / unfreeze API ────────────────────────────────────────────────────


def test_freeze_sets_frozen_flag() -> None:
    mock_sched = MagicMock()
    mock_sched.add_job = MagicMock()
    with MagicMock() as _:
        pass

    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=MagicMock):
        sched = Scheduler.__new__(Scheduler)
        sched._sched = MagicMock()
        sched._pending = []
        sched._job_states = {}
        sched._global_policy = None
        sched._global_consecutive_failures = 0
        sched._frozen = False
        sched._freeze_reason = None

    assert sched._frozen is False
    sched.freeze("test reason")
    assert sched._frozen is True
    assert sched._freeze_reason == "test reason"


def test_unfreeze_clears_frozen_flag() -> None:
    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=MagicMock):
        sched = Scheduler.__new__(Scheduler)
        sched._sched = MagicMock()
        sched._pending = []
        sched._job_states = {}
        sched._global_policy = None
        sched._global_consecutive_failures = 0
        sched._frozen = True
        sched._freeze_reason = "some reason"

    sched.unfreeze()
    assert sched._frozen is False
    assert sched._freeze_reason is None


def test_freeze_calls_on_freeze_callback() -> None:
    from unittest.mock import patch
    on_freeze = MagicMock()
    gp = GlobalSchedulerPolicy(on_freeze=on_freeze)

    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=MagicMock):
        sched = Scheduler.__new__(Scheduler)
        sched._sched = MagicMock()
        sched._pending = []
        sched._job_states = {}
        sched._global_policy = gp
        sched._global_consecutive_failures = 0
        sched._frozen = False
        sched._freeze_reason = None

    sched.freeze("reason")
    on_freeze.assert_called_once_with("reason")


# ── global_status frozen 필드 ────────────────────────────────────────────────


def test_global_status_frozen_field() -> None:
    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=MagicMock):
        sched = Scheduler.__new__(Scheduler)
        sched._sched = MagicMock()
        sched._pending = []
        sched._job_states = {}
        sched._global_policy = None
        sched._global_consecutive_failures = 0
        sched._frozen = False
        sched._freeze_reason = None
        sched._thaw_consecutive_successes = 0
        sched._last_canary_at = 0.0
        sched._job_entries = {}
        sched._recovering = False
        sched._recovery_start_at = 0.0
        sched._recovery_runs = 0
        sched._recovery_failures = 0

    status = sched.global_status()
    assert status["frozen"] is False
    assert status["freeze_reason"] is None

    sched.freeze("alert")
    status2 = sched.global_status()
    assert status2["frozen"] is True
    assert status2["freeze_reason"] == "alert"


# ── _run 동결 시 실행 차단 ────────────────────────────────────────────────────


async def test_run_blocked_when_frozen() -> None:
    """동결 상태에서는 _run() 이 파이프라인을 실행하지 않는다."""
    mock_instance = MagicMock()
    mock_instance.add_job = MagicMock()

    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=lambda: mock_instance):
        sched = Scheduler()

    pipeline = AsyncMock(spec=Assembly)
    pipeline.run = AsyncMock()
    sched.add(pipeline, input=_In(v=1), interval_seconds=60, job_id="j1")

    run_fn = _extract_run_fn(mock_instance)

    # 동결 전 실행 → pipeline.run 호출됨
    await run_fn()
    pipeline.run.assert_called_once()

    # 동결 후 실행 → pipeline.run 호출 안 됨
    sched.freeze("test")
    await run_fn()
    pipeline.run.assert_called_once()  # 여전히 1회


# ── freeze_on_alert 자동 동결 ─────────────────────────────────────────────────


async def test_freeze_on_alert_triggered() -> None:
    """전역 연속 실패 임계 초과 시 freeze_on_alert=True 이면 자동 동결."""
    mock_instance = MagicMock()
    mock_instance.add_job = MagicMock()

    alerts: list[str] = []
    gp = GlobalSchedulerPolicy(
        max_global_consecutive_failures=2,
        on_global_alert=lambda msg: alerts.append(msg),
        freeze_on_alert=True,
    )

    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=lambda: mock_instance):
        sched = Scheduler()
    sched.set_global_policy(gp)

    pipeline = AsyncMock(spec=Assembly)
    pipeline.run = AsyncMock(side_effect=RuntimeError("fail"))
    sched.add(pipeline, input=_In(v=1), interval_seconds=60, job_id="j1")

    run_fn = _extract_run_fn(mock_instance)

    assert sched._frozen is False
    await run_fn()  # 실패 1
    await run_fn()  # 실패 2 → 임계 초과 → 자동 동결
    assert sched._frozen is True
    assert len(alerts) == 1


# ── Circuit Probe ────────────────────────────────────────────────────────────


async def test_probe_fn_false_skips_recovery() -> None:
    """probe_fn=False 이면 복구 시도를 건너뛰고 _killed_at 을 갱신한다."""
    mock_instance = MagicMock()
    mock_instance.add_job = MagicMock()

    probe = AsyncMock(return_value=False)
    policy = SchedulerPolicy(
        max_consecutive_failures=1,
        suspended_retry_seconds=0.0,
        max_recovery_attempts=3,
        probe_fn=probe,
    )

    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=lambda: mock_instance):
        sched = Scheduler()

    fail_pipeline = AsyncMock(spec=Assembly)
    fail_pipeline.run = AsyncMock(side_effect=RuntimeError("fail"))
    sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="j1", policy=policy)

    run_fn = _extract_run_fn(mock_instance)

    await run_fn()  # → suspended
    job = sched._job_states["j1"]
    assert job.state == "suspended"

    # probe=False → 복구 건너뜀 → 파이프라인 실행 안 됨
    await run_fn()
    probe.assert_called_once()
    assert fail_pipeline.run.call_count == 1  # 최초 실패만


async def test_probe_fn_true_allows_recovery() -> None:
    """probe_fn=True 이면 복구 시도를 진행한다."""
    mock_instance = MagicMock()
    mock_instance.add_job = MagicMock()

    probe = AsyncMock(return_value=True)
    policy = SchedulerPolicy(
        max_consecutive_failures=1,
        suspended_retry_seconds=0.0,
        max_recovery_attempts=3,
        probe_fn=probe,
    )

    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=lambda: mock_instance):
        sched = Scheduler()

    ok_pipeline = AsyncMock(spec=Assembly)
    ok_pipeline.run = AsyncMock()
    sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j1", policy=policy)

    run_fn = _extract_run_fn(mock_instance)

    # 먼저 실패 1회로 suspended 상태 진입
    ok_pipeline.run.side_effect = RuntimeError("fail once")
    await run_fn()
    assert sched._job_states["j1"].state == "suspended"

    # probe=True → 복구 시도 → 성공 → active 복귀
    ok_pipeline.run.side_effect = None
    await run_fn()
    probe.assert_called_once()
    assert sched._job_states["j1"].state == "active"


async def test_probe_fn_none_no_check() -> None:
    """probe_fn=None 이면 라이브니스 체크 없이 바로 재시도한다 (기존 동작 유지)."""
    mock_instance = MagicMock()
    mock_instance.add_job = MagicMock()

    policy = SchedulerPolicy(
        max_consecutive_failures=1,
        suspended_retry_seconds=0.0,
        max_recovery_attempts=3,
        probe_fn=None,
    )

    from unittest.mock import patch
    with patch("pylego_blocks.scheduler._require_apscheduler", return_value=lambda: mock_instance):
        sched = Scheduler()

    ok_pipeline = AsyncMock(spec=Assembly)
    ok_pipeline.run = AsyncMock(side_effect=[RuntimeError("fail"), None])
    sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j1", policy=policy)

    run_fn = _extract_run_fn(mock_instance)
    await run_fn()  # fail → suspended
    await run_fn()  # probe_fn=None → 바로 재시도 → 성공 → active
    assert sched._job_states["j1"].state == "active"


# ── SchedulerPolicy probe_fn 기본값 ──────────────────────────────────────────


def test_scheduler_policy_probe_fn_default_none() -> None:
    p = SchedulerPolicy()
    assert p.probe_fn is None


# ── GlobalSchedulerPolicy 신규 필드 기본값 ───────────────────────────────────


def test_global_scheduler_policy_defaults() -> None:
    gp = GlobalSchedulerPolicy()
    assert gp.freeze_on_alert is False
    assert gp.on_freeze is None
