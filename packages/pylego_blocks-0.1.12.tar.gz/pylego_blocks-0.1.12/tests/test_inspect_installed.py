"""inspect list --installed 플래그 및 BlockRegistry.discover() 통합 테스트."""

from __future__ import annotations

import importlib.metadata
import json
from typing import Any
from unittest.mock import patch

import pytest

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud
from pylego_blocks.inspect.cli import inspect_list
from pylego_blocks.registry import BlockRegistry


class _Txt(Stud):
    text: str = ""


class _TxtOut(Stud):
    text: str = ""


class _EpBlock(Block[_Txt, _TxtOut]):
    """entry-points 로 주입되는 가짜 플러그인 블록."""

    input_model = _Txt
    output_model = _TxtOut

    async def run(self, inp: _Txt) -> _TxtOut:
        return _TxtOut(text=inp.text)


class _FakeEP:
    name = "ep_block"

    def load(self) -> Any:
        return _EpBlock


def test_inspect_list_installed_includes_ep_blocks(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """--installed 플래그를 주면 entry-points 블록이 출력에 포함된다."""
    fresh_registry = BlockRegistry()
    with (
        patch("pylego_blocks.inspect.cli.default_registry", fresh_registry),
        patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]),
    ):
        rc = inspect_list(installed=True)
    assert rc == 0
    output = capsys.readouterr().out
    assert "_EpBlock" in output


def test_inspect_list_installed_json_format(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """--installed + json 형식에서 entry-points 블록이 포함된다."""
    fresh_registry = BlockRegistry()
    with (
        patch("pylego_blocks.inspect.cli.default_registry", fresh_registry),
        patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]),
    ):
        rc = inspect_list(output_format="json", installed=True)
    assert rc == 0
    payload = json.loads(capsys.readouterr().out)
    names = {item["name"] for item in payload["blocks"]}
    assert "_EpBlock" in names


def test_inspect_list_without_installed_skips_ep_blocks(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """--installed 없으면 entry-points 에 등록된 블록은 나타나지 않는다."""
    fresh_registry = BlockRegistry()
    with (
        patch("pylego_blocks.inspect.cli.default_registry", fresh_registry),
        patch.object(importlib.metadata, "entry_points", return_value=[_FakeEP()]),
    ):
        rc = inspect_list(installed=False)
    assert rc == 0
    output = capsys.readouterr().out
    # _EpBlock 은 pylego.blocks.* 패키지에 없으므로 출력에 없다
    assert "_EpBlock" not in output
