"""pylego CLI run 명령 테스트."""

from __future__ import annotations

import argparse
import os
from typing import Literal, cast

import pytest

_TEST_REPO = os.environ.get("PYLEGO_TEST_REPO", "test-owner/test-repo")

from pylego_blocks import cli
from pylego_blocks.pipelines.ai_pi import PipelineResult


def test_help_includes_run_subcommand() -> None:
    parser = cli.build_parser()
    help_text = parser.format_help()
    subparsers_action = next(
        action for action in parser._actions if isinstance(action, argparse._SubParsersAction)
    )
    inspect_parser = cast(argparse.ArgumentParser, subparsers_action.choices["inspect"])
    inspect_help = inspect_parser.format_help()
    assert "run" in help_text
    assert "inspect" in help_text
    assert "matrix" in inspect_help


def test_missing_github_repo_exits_2(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.delenv("GITHUB_REPO", raising=False)

    with pytest.raises(SystemExit) as excinfo:
        cli.main(["run", "1"])

    assert excinfo.value.code == 2
    captured = capsys.readouterr()
    assert "GITHUB_REPO" in captured.err


def test_dry_run_prints_repr_and_skips_execution(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    monkeypatch.setenv("GITHUB_REPO", _TEST_REPO)
    called = {"run": False}

    class FakePipeline:
        def __repr__(self) -> str:
            return "fake pipeline"

    def fake_build(config: object) -> FakePipeline:
        assert config is not None
        return FakePipeline()

    async def fake_run(config: object) -> PipelineResult:
        called["run"] = True
        raise AssertionError("run_ai_pi must not be called in dry-run")

    monkeypatch.setattr(cli, "build_ai_pi_pipeline", fake_build)
    monkeypatch.setattr(cli, "run_ai_pi", fake_run)

    code = cli.main(["run", "7", "--dry-run"])

    assert code == 0
    assert called["run"] is False
    assert capsys.readouterr().out.strip() == "fake pipeline"


@pytest.mark.parametrize(
    ("final_state", "expected"),
    [("merged", 0), ("failed", 1), ("escalated", 2)],
)
def test_exit_code_mapping(
    monkeypatch: pytest.MonkeyPatch,
    final_state: Literal["merged", "failed", "escalated"],
    expected: int,
) -> None:
    monkeypatch.setenv("GITHUB_REPO", _TEST_REPO)

    async def fake_run(_config: object) -> PipelineResult:
        return PipelineResult(issue_number=1, final_state=final_state, fail_count=0, verdict="PASS")

    monkeypatch.setattr(cli, "run_ai_pi", fake_run)

    assert cli.main(["run", "1"]) == expected


def test_default_prompt_timeouts_are_600_seconds(monkeypatch: pytest.MonkeyPatch) -> None:
    """#39: env 미설정 시 cli._load_config 이 600s 기본값을 씀.

    이전에는 300.0 을 하드코딩해 AiPiPipelineConfig.dev_prompt_timeout_sec(600)
    기본값을 덮어써 #27 첫 run 이 5 min 시점에 premature timeout 됐음.
    """
    monkeypatch.setenv("GITHUB_REPO", _TEST_REPO)
    monkeypatch.delenv("PYLEGO_DEV_TIMEOUT", raising=False)
    monkeypatch.delenv("PYLEGO_QA_TIMEOUT", raising=False)

    config = cli._load_config(issue_number=1)
    assert config.dev_prompt_timeout_sec == 600.0
    assert config.qa_prompt_timeout_sec == 600.0


def test_env_timeout_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    """env var 가 설정되면 그 값이 우선."""
    monkeypatch.setenv("GITHUB_REPO", _TEST_REPO)
    monkeypatch.setenv("PYLEGO_DEV_TIMEOUT", "900")
    monkeypatch.setenv("PYLEGO_QA_TIMEOUT", "450")

    config = cli._load_config(issue_number=1)
    assert config.dev_prompt_timeout_sec == 900.0
    assert config.qa_prompt_timeout_sec == 450.0
