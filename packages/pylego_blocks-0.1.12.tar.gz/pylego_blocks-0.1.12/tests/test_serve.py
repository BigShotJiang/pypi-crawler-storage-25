"""serve.py — HTTP API 게이트웨이 단위 테스트.

fastapi + httpx TestClient 를 사용한다.
"""

from __future__ import annotations

from typing import Any

import pytest

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


# ─── fixtures ────────────────────────────────────────────────────────────────

class _Req(Stud):
    value: int


class _Resp(Stud):
    result: int


class _DoubleBlock(Block[_Req, _Resp]):
    input_model = _Req
    output_model = _Resp

    async def run(self, inp: _Req) -> _Resp:
        return _Resp(result=inp.value * 2)


class _ErrorBlock(Block[_Req, _Resp]):
    input_model = _Req
    output_model = _Resp

    async def run(self, inp: _Req) -> _Resp:
        raise RuntimeError("forced error")


@pytest.fixture()
def double_assembly() -> Assembly[_Req, _Resp]:
    return Assembly([_DoubleBlock()], name="DoubleAssembly")


@pytest.fixture()
def error_assembly() -> Assembly[_Req, _Resp]:
    return Assembly([_ErrorBlock()], name="ErrorAssembly")


@pytest.fixture()
def client(double_assembly: Assembly[_Req, _Resp]) -> Any:
    from fastapi.testclient import TestClient
    from pylego_blocks.serve import build_app
    app = build_app(double_assembly)
    return TestClient(app)


@pytest.fixture()
def error_client(error_assembly: Assembly[_Req, _Resp]) -> Any:
    from fastapi.testclient import TestClient
    from pylego_blocks.serve import build_app
    app = build_app(error_assembly)
    return TestClient(app)


# ─── build_app / ImportError ─────────────────────────────────────────────────

class TestBuildApp:
    def test_returns_fastapi_app(self, double_assembly: Assembly[_Req, _Resp]) -> None:
        from fastapi import FastAPI
        from pylego_blocks.serve import build_app
        app = build_app(double_assembly)
        assert isinstance(app, FastAPI)

    def test_import_error_without_fastapi(
        self, double_assembly: Assembly[_Req, _Resp], monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import sys
        saved = {k: v for k, v in sys.modules.items() if k.startswith("fastapi") or k.startswith("uvicorn")}
        for k in list(sys.modules.keys()):
            if k.startswith("fastapi") or k.startswith("uvicorn"):
                del sys.modules[k]
        if "pylego_blocks.serve" in sys.modules:
            del sys.modules["pylego_blocks.serve"]
        try:
            import builtins
            real_import = builtins.__import__

            def mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
                if name.startswith("fastapi") or name.startswith("uvicorn"):
                    raise ImportError(f"No module named '{name}'")
                return real_import(name, *args, **kwargs)

            monkeypatch.setattr(builtins, "__import__", mock_import)
            from pylego_blocks.serve import build_app as _build_app
            with pytest.raises(ImportError, match="fastapi"):
                _build_app(double_assembly)
        finally:
            sys.modules.update(saved)
            if "pylego_blocks.serve" in sys.modules:
                del sys.modules["pylego_blocks.serve"]


# ─── POST /run ───────────────────────────────────────────────────────────────

class TestRunEndpoint:
    def test_success(self, client: Any) -> None:
        resp = client.post("/run", json={"value": 5})
        assert resp.status_code == 200
        data = resp.json()
        assert data["result"] == 10

    def test_meta_elapsed(self, client: Any) -> None:
        resp = client.post("/run", json={"value": 1})
        data = resp.json()
        assert "_meta" in data
        assert "elapsed_sec" in data["_meta"]
        assert data["_meta"]["elapsed_sec"] >= 0

    def test_invalid_input_422(self, client: Any) -> None:
        resp = client.post("/run", json={"value": "not-an-int"})
        assert resp.status_code == 422

    def test_missing_field_422(self, client: Any) -> None:
        resp = client.post("/run", json={})
        assert resp.status_code == 422

    def test_block_error_500(self, error_client: Any) -> None:
        resp = error_client.post("/run", json={"value": 1})
        assert resp.status_code == 500
        assert "forced error" in resp.json()["detail"]


# ─── GET /health ─────────────────────────────────────────────────────────────

class TestHealthEndpoint:
    def test_status_ok(self, client: Any) -> None:
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"

    def test_assembly_name(self, client: Any) -> None:
        resp = client.get("/health")
        data = resp.json()
        assert data["assembly"] == "DoubleAssembly"

    def test_model_names(self, client: Any) -> None:
        resp = client.get("/health")
        data = resp.json()
        assert data["input_model"] == "_Req"
        assert data["output_model"] == "_Resp"


# ─── GET /openapi.json ───────────────────────────────────────────────────────

class TestOpenApi:
    def test_openapi_accessible(self, client: Any) -> None:
        resp = client.get("/openapi.json")
        assert resp.status_code == 200

    def test_openapi_has_run_path(self, client: Any) -> None:
        schema = client.get("/openapi.json").json()
        assert "/run" in schema["paths"]

    def test_openapi_has_health_path(self, client: Any) -> None:
        schema = client.get("/openapi.json").json()
        assert "/health" in schema["paths"]

    def test_openapi_title_contains_assembly_name(self, client: Any) -> None:
        schema = client.get("/openapi.json").json()
        assert "DoubleAssembly" in schema["info"]["title"]
