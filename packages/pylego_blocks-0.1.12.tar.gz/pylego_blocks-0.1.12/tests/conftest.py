"""pytest 공용 설정 · fixture."""

from __future__ import annotations

import pytest
try:
    from pytest_socket import disable_socket, enable_socket
except Exception:  # pragma: no cover - allow running without pytest_socket in minimal envs
    def disable_socket(*, allow_unix_socket: bool = True) -> None:  # type: ignore
        return None

    def enable_socket() -> None:  # type: ignore
        return None


@pytest.fixture(autouse=True)
def _block_network() -> None:
    """기본적으로 외부 네트워크 차단. Unix socket 은 asyncio 이벤트 루프용으로 허용."""
    disable_socket(allow_unix_socket=True)


@pytest.fixture
def allow_network() -> None:
    """명시적으로 네트워크를 허용하는 테스트에서만 사용."""
    enable_socket()


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--pylego-contracts",
        action="store_true",
        default=False,
        help="Run pylego contract tests (marked with @pytest.mark.pylego_contracts)",
    )


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line(
        "markers",
        "pylego_contracts: pylego contract tests (run with --pylego-contracts)",
    )


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    run_contracts = config.getoption("--pylego-contracts")
    if run_contracts:
        # Keep only pylego_contracts-marked tests
        keep = []
        deselected = []
        for item in list(items):
            if item.get_closest_marker("pylego_contracts") is not None:
                keep.append(item)
            else:
                deselected.append(item)
        if deselected:
            for it in deselected:
                if it in items:
                    items.remove(it)
            config.hook.pytest_deselected(items=deselected)
    else:
        # Default: deselect pylego_contracts tests
        deselected = [it for it in list(items) if it.get_closest_marker("pylego_contracts") is not None]
        if deselected:
            for it in deselected:
                if it in items:
                    items.remove(it)
            config.hook.pytest_deselected(items=deselected)


# Provide a lightweight pytester shim when the pytester plugin is not available.
try:
    import pytester  # type: ignore
except Exception:  # pragma: no cover - fallback for minimal environments
    import fnmatch
    import subprocess
    import sys

    class _Stdout:
        def __init__(self, text: str) -> None:
            self._text = text

        def fnmatch_lines(self, patterns, consecutive: bool = False) -> None:
            lines = self._text.splitlines()
            for pat in patterns:
                matched = any(fnmatch.fnmatch(line, pat) for line in lines)
                assert matched, f"Pattern {pat!r} not found in output"

    class _RunResult:
        def __init__(self, returncode: int, stdout: str) -> None:
            self.returncode = returncode
            self.stdout = _Stdout(stdout)

        def assert_outcomes(self, passed: int = 0, failed: int = 0) -> None:
            import re

            s = self.stdout._text
            p = int(re.search(r"(\d+) passed", s).group(1)) if re.search(r"(\d+) passed", s) else 0
            f = int(re.search(r"(\d+) failed", s).group(1)) if re.search(r"(\d+) failed", s) else 0
            assert p == passed and f == failed, f"expected passed={passed} failed={failed}, got passed={p} failed={f}"

    class _PytesterShim:
        def __init__(self, tmp_path):
            self._path = tmp_path

        def makepyfile(self, **files) -> None:
            for name, content in files.items():
                p = self._path / f"{name}.py"
                p.write_text(content, encoding="utf-8")

        def runpytest(self, *args):
            cmd = [sys.executable, "-m", "pytest", "-q"] + list(args)
            proc = subprocess.run(cmd, cwd=str(self._path), capture_output=True, text=True)
            out = proc.stdout + "\n" + proc.stderr
            return _RunResult(proc.returncode, out)

    import pytest

    @pytest.fixture
    def pytester(tmp_path):
        return _PytesterShim(tmp_path)
