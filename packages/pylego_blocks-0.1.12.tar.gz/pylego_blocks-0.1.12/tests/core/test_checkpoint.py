"""Checkpoint — MemoryCheckpoint / FileCheckpoint / Assembly 체크포인팅 테스트."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.checkpoint import FileCheckpoint, MemoryCheckpoint, _default_checkpoint
from pylego_blocks.core.stud import Stud


class _N(Stud):
    v: int


class _AddOne(Block[_N, _N]):
    input_model = _N
    output_model = _N

    async def run(self, inp: _N) -> _N:
        return _N(v=inp.v + 1)


class _Double(Block[_N, _N]):
    input_model = _N
    output_model = _N

    async def run(self, inp: _N) -> _N:
        return _N(v=inp.v * 2)


# ---------------------------------------------------------------------------
# MemoryCheckpoint
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_memory_checkpoint_save_load() -> None:
    cp = MemoryCheckpoint()
    await cp.save("blk", _N(v=5))
    result = await cp.load("blk", _N)
    assert result == _N(v=5)


@pytest.mark.asyncio
async def test_memory_checkpoint_has() -> None:
    cp = MemoryCheckpoint()
    assert not await cp.has("blk")
    await cp.save("blk", _N(v=1))
    assert await cp.has("blk")


@pytest.mark.asyncio
async def test_memory_checkpoint_clear() -> None:
    cp = MemoryCheckpoint()
    await cp.save("blk", _N(v=1))
    await cp.clear()
    assert not await cp.has("blk")


@pytest.mark.asyncio
async def test_memory_checkpoint_load_missing_returns_none() -> None:
    cp = MemoryCheckpoint()
    assert await cp.load("missing", _N) is None


# ---------------------------------------------------------------------------
# FileCheckpoint
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_file_checkpoint_save_load(tmp_path: Path) -> None:
    cp = FileCheckpoint(tmp_path / "cp.json")
    await cp.save("blk", _N(v=10))
    result = await cp.load("blk", _N)
    assert result == _N(v=10)


@pytest.mark.asyncio
async def test_file_checkpoint_survives_between_instances(tmp_path: Path) -> None:
    path = tmp_path / "cp.json"
    cp1 = FileCheckpoint(path)
    await cp1.save("blk", _N(v=99))

    cp2 = FileCheckpoint(path)
    assert await cp2.has("blk")
    result = await cp2.load("blk", _N)
    assert result == _N(v=99)


@pytest.mark.asyncio
async def test_file_checkpoint_json_human_readable(tmp_path: Path) -> None:
    path = tmp_path / "cp.json"
    cp = FileCheckpoint(path)
    await cp.save("step", _N(v=7))
    text = path.read_text(encoding="utf-8")
    assert '"step"' in text
    assert "\n" in text


# ---------------------------------------------------------------------------
# Assembly + MemoryCheckpoint
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_assembly_checkpoint_basic() -> None:
    asm = Assembly([_AddOne(), _Double()], name="asm")
    cp = MemoryCheckpoint()
    result = await asm.run(_N(v=3), checkpoint=cp)
    # (3+1)*2 = 8
    assert result == _N(v=8)
    assert await cp.has("_AddOne")
    assert await cp.has("_Double")


@pytest.mark.asyncio
async def test_assembly_checkpoint_skips_completed_blocks() -> None:
    """체크포인트에 블록 결과가 있으면 재실행하지 않는다."""
    call_log: list[str] = []

    class _LogAdd(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("LogAdd")
            return _N(v=inp.v + 1)

    class _LogDouble(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("LogDouble")
            return _N(v=inp.v * 2)

    # 1차 실행
    asm = Assembly([_LogAdd(), _LogDouble()], name="asm")
    cp = MemoryCheckpoint()
    r1 = await asm.run(_N(v=2), checkpoint=cp)
    assert r1 == _N(v=6)  # (2+1)*2
    assert call_log == ["LogAdd", "LogDouble"]

    # 2차 실행 — 동일 체크포인트, 두 블록 모두 스킵
    call_log.clear()
    r2 = await asm.run(_N(v=2), checkpoint=cp)
    assert r2 == _N(v=6)
    assert call_log == []  # 재실행 없음


@pytest.mark.asyncio
async def test_assembly_checkpoint_partial_recovery() -> None:
    """3블록 파이프라인에서 3번째 실패 → 체크포인트 재실행 시 1·2번째 스킵."""
    call_log: list[str] = []

    class _B1(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("B1")
            return _N(v=inp.v + 10)

    class _B2(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("B2")
            return _N(v=inp.v + 20)

    class _B3Fail(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("B3")
            raise RuntimeError("B3 실패")

    class _B3Ok(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("B3_fixed")
            return _N(v=inp.v + 30)

    cp = MemoryCheckpoint()

    # 1차: B3에서 실패
    asm1 = Assembly([_B1(), _B2(), _B3Fail()], name="pipe")
    with pytest.raises(RuntimeError, match="B3 실패"):
        await asm1.run(_N(v=0), checkpoint=cp)

    assert call_log == ["B1", "B2", "B3"]
    call_log.clear()

    # 2차: B3 수정 버전으로 재실행 — B1·B2 스킵
    asm2 = Assembly([_B1(), _B2(), _B3Ok()], name="pipe")
    result = await asm2.run(_N(v=0), checkpoint=cp)

    assert call_log == ["B3_fixed"]  # B1·B2 재실행 없음
    assert result == _N(v=60)  # 0+10+20+30


# ---------------------------------------------------------------------------
# FileCheckpoint + Assembly (프로세스 재시작 시뮬레이션)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_assembly_file_checkpoint_survives_restart(tmp_path: Path) -> None:
    """파일 체크포인트가 있으면 프로세스 재시작 후 완료 블록을 스킵한다."""
    call_log: list[str] = []

    class _Step1(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("Step1")
            return _N(v=inp.v + 1)

    class _Step2(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("Step2")
            return _N(v=inp.v * 2)

    cp_path = tmp_path / "restart.json"

    # 1차 실행: 두 블록 모두 실행, 파일에 저장
    asm = Assembly([_Step1(), _Step2()], name="restart_test")
    cp1 = FileCheckpoint(cp_path)
    r1 = await asm.run(_N(v=4), checkpoint=cp1)
    assert r1 == _N(v=10)  # (4+1)*2
    assert call_log == ["Step1", "Step2"]

    # 2차 실행: 동일 파일 체크포인트 → 두 블록 모두 스킵
    call_log.clear()
    cp2 = FileCheckpoint(cp_path)
    r2 = await asm.run(_N(v=4), checkpoint=cp2)
    assert r2 == _N(v=10)
    assert call_log == []


# ---------------------------------------------------------------------------
# PYLEGO_CHECKPOINT_DIR 환경변수
# ---------------------------------------------------------------------------


def test_default_checkpoint_no_env() -> None:
    os.environ.pop("PYLEGO_CHECKPOINT_DIR", None)
    assert _default_checkpoint("asm") is None


def test_default_checkpoint_with_env(tmp_path: Path) -> None:
    os.environ["PYLEGO_CHECKPOINT_DIR"] = str(tmp_path)
    try:
        cp = _default_checkpoint("my_asm")
        assert cp is not None
        assert isinstance(cp, FileCheckpoint)
    finally:
        del os.environ["PYLEGO_CHECKPOINT_DIR"]


@pytest.mark.asyncio
async def test_assembly_auto_checkpoint_from_env(tmp_path: Path) -> None:
    """PYLEGO_CHECKPOINT_DIR 설정 시 checkpoint=None 이어도 자동 적용."""
    os.environ["PYLEGO_CHECKPOINT_DIR"] = str(tmp_path)
    call_log: list[str] = []

    class _Auto(Block[_N, _N]):
        input_model = _N
        output_model = _N

        async def run(self, inp: _N) -> _N:
            call_log.append("Auto")
            return _N(v=inp.v + 1)

    try:
        asm = Assembly([_Auto()], name="auto_asm")
        r1 = await asm.run(_N(v=0))
        assert r1 == _N(v=1)
        assert call_log == ["Auto"]

        # 2차: 환경변수 체크포인트로 스킵
        call_log.clear()
        r2 = await asm.run(_N(v=0))
        assert r2 == _N(v=1)
        assert call_log == []
    finally:
        del os.environ["PYLEGO_CHECKPOINT_DIR"]
