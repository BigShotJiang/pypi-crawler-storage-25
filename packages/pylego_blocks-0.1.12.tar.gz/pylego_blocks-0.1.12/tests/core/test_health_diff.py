"""M100 — HealthDiff 시맨틱 차이 + max_payload_chars 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks import Assembly, Block, HealthDiff, Stud, build_health_summary, observe
from pylego_blocks.core.events import BlockFailedEvent, CollectingEventBus


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    query: str


class _Out(Stud):
    result: str


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.query)


class _FailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise ValueError("fail")


# ── HealthDiff 기본 구조 ───────────────────────────────────────────────────────


def test_health_diff_dataclass() -> None:
    diff = HealthDiff()
    assert diff.new_failures == []
    assert diff.recovered == []
    assert diff.slower_blocks == {}
    assert diff.faster_blocks == {}
    assert diff.error_type_changes == {}


# ── diff.new_failures — 새로 실패한 블록 ──────────────────────────────────────


async def test_diff_new_failures() -> None:
    ok_bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
    with observe(ok_bus):
        await pipeline.run(_In(query="x"))
    prev_health = build_health_summary(ok_bus.events, bus=ok_bus)

    fail_bus = CollectingEventBus()
    fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(fail_bus):
        try:
            await fail_pipeline.run(_In(query="x"))
        except ValueError:
            pass
    curr_health = build_health_summary(fail_bus.events, bus=fail_bus)

    diff = curr_health.diff(prev_health)
    assert "_FailBlock" in diff.new_failures


# ── diff.recovered — 복구된 블록 ─────────────────────────────────────────────


async def test_diff_recovered() -> None:
    fail_bus = CollectingEventBus()
    fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(fail_bus):
        try:
            await fail_pipeline.run(_In(query="x"))
        except ValueError:
            pass
    prev_health = build_health_summary(fail_bus.events, bus=fail_bus)

    ok_bus = CollectingEventBus()
    ok_pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
    with observe(ok_bus):
        await ok_pipeline.run(_In(query="x"))
    curr_health = build_health_summary(ok_bus.events, bus=ok_bus)

    diff = curr_health.diff(prev_health)
    assert "_FailBlock" in diff.recovered


# ── diff.slower_blocks / diff.faster_blocks ───────────────────────────────────


def _make_health_with_elapsed(block_elapsed: dict[str, float]) -> object:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    return PipelineHealth(
        overall="ok",
        total_blocks=len(block_elapsed),
        error_blocks=[],
        slowest_block=None,
        slowest_elapsed_sec=None,
        avg_elapsed_sec=None,
        block_elapsed=block_elapsed,
    )


def test_diff_slower_blocks() -> None:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    prev = _make_health_with_elapsed({"BlockA": 1.0})
    curr = _make_health_with_elapsed({"BlockA": 2.5})

    assert isinstance(prev, PipelineHealth)
    assert isinstance(curr, PipelineHealth)

    diff = curr.diff(prev)
    assert "BlockA" in diff.slower_blocks
    assert diff.slower_blocks["BlockA"] == pytest.approx((1.0, 2.5))


def test_diff_faster_blocks() -> None:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    prev = _make_health_with_elapsed({"BlockA": 2.0})
    curr = _make_health_with_elapsed({"BlockA": 0.5})

    assert isinstance(prev, PipelineHealth)
    assert isinstance(curr, PipelineHealth)

    diff = curr.diff(prev)
    assert "BlockA" in diff.faster_blocks
    assert diff.faster_blocks["BlockA"] == pytest.approx((2.0, 0.5))


def test_diff_no_change_within_threshold() -> None:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    prev = _make_health_with_elapsed({"BlockA": 1.0})
    curr = _make_health_with_elapsed({"BlockA": 1.1})  # 10% 변화 — 임계값 미만

    assert isinstance(prev, PipelineHealth)
    assert isinstance(curr, PipelineHealth)

    diff = curr.diff(prev)
    assert "BlockA" not in diff.slower_blocks
    assert "BlockA" not in diff.faster_blocks


# ── diff.error_type_changes ───────────────────────────────────────────────────


def _make_health_with_error(block_name: str, error_type: str | None) -> object:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    ev = BlockFailedEvent(
        block_name=block_name,
        error=RuntimeError("x"),
        elapsed_sec=0.1,
        timestamp=0.0,
        error_type=error_type,
    )
    return PipelineHealth(
        overall="critical",
        total_blocks=1,
        error_blocks=[block_name],
        slowest_block=block_name,
        slowest_elapsed_sec=0.1,
        avg_elapsed_sec=0.1,
        error_details={block_name: ev},
    )


def test_diff_error_type_changes() -> None:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    prev = _make_health_with_error("MyBlock", "TypeError")
    curr = _make_health_with_error("MyBlock", "ValidationError")

    assert isinstance(prev, PipelineHealth)
    assert isinstance(curr, PipelineHealth)

    diff = curr.diff(prev)
    assert "MyBlock" in diff.error_type_changes
    assert diff.error_type_changes["MyBlock"] == ("TypeError", "ValidationError")


def test_diff_no_error_type_change() -> None:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    prev = _make_health_with_error("MyBlock", "ValueError")
    curr = _make_health_with_error("MyBlock", "ValueError")

    assert isinstance(prev, PipelineHealth)
    assert isinstance(curr, PipelineHealth)

    diff = curr.diff(prev)
    assert "MyBlock" not in diff.error_type_changes


# ── to_ai_summary(diff=...) ───────────────────────────────────────────────────


async def test_to_ai_summary_with_diff_new_failures() -> None:
    ok_bus = CollectingEventBus()
    with observe(ok_bus):
        await Assembly([_OkBlock()]).run(_In(query="x"))
    prev = build_health_summary(ok_bus.events, bus=ok_bus)

    fail_bus = CollectingEventBus()
    with observe(fail_bus):
        try:
            await Assembly([_FailBlock()]).run(_In(query="x"))
        except ValueError:
            pass
    curr = build_health_summary(fail_bus.events, bus=fail_bus)

    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)
    assert "[이전 대비 변화]" in summary
    assert "신규 실패" in summary
    assert "_FailBlock" in summary


async def test_to_ai_summary_with_diff_recovered() -> None:
    fail_bus = CollectingEventBus()
    with observe(fail_bus):
        try:
            await Assembly([_FailBlock()]).run(_In(query="x"))
        except ValueError:
            pass
    prev = build_health_summary(fail_bus.events, bus=fail_bus)

    ok_bus = CollectingEventBus()
    with observe(ok_bus):
        await Assembly([_OkBlock()]).run(_In(query="x"))
    curr = build_health_summary(ok_bus.events, bus=ok_bus)

    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)
    assert "복구됨" in summary


def test_to_ai_summary_diff_none_no_change_section() -> None:
    from pylego_blocks.core.graph import PipelineHealth  # noqa: PLC0415

    health = PipelineHealth(
        overall="ok",
        total_blocks=1,
        error_blocks=[],
        slowest_block=None,
        slowest_elapsed_sec=None,
        avg_elapsed_sec=None,
    )
    summary = health.to_ai_summary()
    assert "[이전 대비 변화]" not in summary


# ── max_payload_chars ─────────────────────────────────────────────────────────


async def test_max_payload_chars_truncates_display() -> None:
    """to_ai_summary(max_payload_chars=50)가 샘플을 50자로 잘라 표시."""
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(query="a" * 300))
        except ValueError:
            pass
    health = build_health_summary(bus.events, bus=bus)
    summary = health.to_ai_summary(include_payload=True, max_payload_chars=50)
    # 샘플 라인에서 50자 이내인지 확인
    for line in summary.split("\n"):
        if "입력 샘플" in line:
            sample_part = line.split("입력 샘플: ", 1)[1] if "입력 샘플: " in line else ""
            assert len(sample_part) <= 50 + 5  # repr 오버헤드 허용


async def test_assembly_max_payload_chars_stores_longer_sample() -> None:
    """Assembly(max_payload_chars=500)은 500자까지 저장."""
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()], max_payload_chars=500)
    long_query = "z" * 400
    with observe(bus):
        try:
            await pipeline.run(_In(query=long_query))
        except ValueError:
            pass
    ev = bus.failed_events()[0]
    assert ev.input_sample is not None
    assert len(ev.input_sample) > 200  # 기본 200자보다 길게 저장됨


async def test_assembly_max_payload_chars_default_200() -> None:
    """기본값 max_payload_chars=200 하위 호환."""
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
    with observe(bus):
        try:
            await pipeline.run(_In(query="b" * 300))
        except ValueError:
            pass
    ev = bus.failed_events()[0]
    assert ev.input_sample is not None
    assert len(ev.input_sample) <= 200


# ── block_elapsed 필드 ────────────────────────────────────────────────────────


async def test_build_health_summary_populates_block_elapsed() -> None:
    bus = CollectingEventBus()
    pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
    with observe(bus):
        await pipeline.run(_In(query="x"))
    health = build_health_summary(bus.events, bus=bus)
    assert health.block_elapsed is not None
    assert "_OkBlock" in health.block_elapsed
