"""TapBlock 테스트."""

import asyncio

import pytest

from pylego_blocks import Assembly, Block, Stud, TapBlock


class Num(Stud):
    value: int


class Doubled(Stud):
    value: int


class DoubleBlock(Block[Num, Doubled]):
    input_model = Num
    output_model = Doubled

    async def run(self, inp: Num) -> Doubled:
        return Doubled(value=inp.value * 2)


class SignalBlock(Block[Num, Num]):
    input_model = Num
    output_model = Num

    def __init__(self) -> None:
        self.seen: list[int] = []

    async def run(self, inp: Num) -> Num:
        self.seen.append(inp.value)
        return inp


class FailingBlock(Block[Num, Num]):
    input_model = Num
    output_model = Num

    async def run(self, inp: Num) -> Num:
        raise RuntimeError("observer 강제 오류")


# ── 기본 동작 ──────────────────────────────────────────────────────────────────

def test_tapblock_passes_input_through() -> None:
    tap = TapBlock(SignalBlock())
    result = asyncio.run(tap.run(Num(value=7)))
    assert result == Num(value=7)


def test_tapblock_calls_observer() -> None:
    signal = SignalBlock()
    tap = TapBlock(signal)
    asyncio.run(tap.run(Num(value=42)))
    assert signal.seen == [42]


def test_tapblock_in_assembly_chain() -> None:
    signal = SignalBlock()
    pipeline = Assembly([TapBlock(signal), DoubleBlock()])
    result = pipeline.run_sync(Num(value=5))
    assert result == Doubled(value=10)
    assert signal.seen == [5]


# ── observer 실패 처리 ─────────────────────────────────────────────────────────

def test_tapblock_ignores_observer_error_by_default() -> None:
    tap = TapBlock(FailingBlock())
    result = asyncio.run(tap.run(Num(value=3)))
    assert result == Num(value=3)


def test_tapblock_propagates_error_when_ignore_false() -> None:
    tap = TapBlock(FailingBlock(), ignore_errors=False)
    with pytest.raises(RuntimeError, match="observer 강제 오류"):
        asyncio.run(tap.run(Num(value=3)))


# ── callable observer ──────────────────────────────────────────────────────────

def test_tapblock_with_callable_observer() -> None:
    recorded: list[int] = []

    async def record(inp: Num) -> None:
        recorded.append(inp.value)

    tap = TapBlock(record, item_type=Num)
    asyncio.run(tap.run(Num(value=99)))
    assert recorded == [99]


def test_tapblock_callable_requires_item_type() -> None:
    async def noop(inp: Num) -> None:
        pass

    with pytest.raises(ValueError, match="item_type"):
        TapBlock(noop)


# ── 이름 설정 ──────────────────────────────────────────────────────────────────

def test_tapblock_name_from_block() -> None:
    signal = SignalBlock()
    tap = TapBlock(signal)
    assert "SignalBlock" in tap.name


def test_tapblock_name_override() -> None:
    tap = TapBlock(SignalBlock(), name="MySensor")
    assert tap.name == "MySensor"


def test_tapblock_name_from_callable() -> None:
    async def my_recorder(inp: Num) -> None:
        pass

    tap = TapBlock(my_recorder, item_type=Num)
    assert "my_recorder" in tap.name


# ── input/output model ─────────────────────────────────────────────────────────

def test_tapblock_io_models_match() -> None:
    signal = SignalBlock()
    tap = TapBlock(signal)
    assert tap.input_model is Num
    assert tap.output_model is Num


def test_tapblock_callable_io_models() -> None:
    async def fn(inp: Num) -> None:
        pass

    tap = TapBlock(fn, item_type=Num)
    assert tap.input_model is Num
    assert tap.output_model is Num
