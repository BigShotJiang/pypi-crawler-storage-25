"""M10 이벤트 큐 — Queue + WorkerPool 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego_blocks.core.block import Block
from pylego_blocks.core.queue import Queue, WorkerPool
from pylego_blocks.core.stud import Stud


# ── 픽스처 블록 ──────────────────────────────────────────────────────────────


class _Num(Stud):
    value: int


class _Result(Stud):
    doubled: int


class _DoubleBlock(Block[_Num, _Result]):
    input_model = _Num
    output_model = _Result

    async def run(self, inp: _Num) -> _Result:
        return _Result(doubled=inp.value * 2)


class _SlowDoubleBlock(Block[_Num, _Result]):
    input_model = _Num
    output_model = _Result

    def __init__(self, sleep_sec: float = 0.05) -> None:
        self._sleep = sleep_sec

    async def run(self, inp: _Num) -> _Result:
        await asyncio.sleep(self._sleep)
        return _Result(doubled=inp.value * 2)


# ── Queue ─────────────────────────────────────────────────────────────────────


class TestQueue:
    @pytest.mark.asyncio
    async def test_put_and_consume(self) -> None:
        q: Queue[_Num] = Queue()
        await q.put(_Num(value=1))
        await q.put(_Num(value=2))
        await q.close()

        items = [item async for item in q]
        assert [i.value for i in items] == [1, 2]

    @pytest.mark.asyncio
    async def test_close_stops_iteration(self) -> None:
        q: Queue[_Num] = Queue()
        await q.close()
        items = [item async for item in q]
        assert items == []

    @pytest.mark.asyncio
    async def test_put_after_close_raises(self) -> None:
        q: Queue[_Num] = Queue()
        await q.close()
        with pytest.raises(RuntimeError, match="닫힌 큐"):
            await q.put(_Num(value=1))

    def test_put_nowait_after_close_raises(self) -> None:
        q: Queue[_Num] = Queue()
        q.close_nowait()
        with pytest.raises(RuntimeError, match="닫힌 큐"):
            q.put_nowait(_Num(value=1))

    @pytest.mark.asyncio
    async def test_size_reflects_queue_depth(self) -> None:
        q: Queue[_Num] = Queue()
        assert q.size == 0
        await q.put(_Num(value=1))
        assert q.size == 1
        await q.put(_Num(value=2))
        assert q.size == 2

    @pytest.mark.asyncio
    async def test_closed_property(self) -> None:
        q: Queue[_Num] = Queue()
        assert not q.closed
        await q.close()
        assert q.closed

    @pytest.mark.asyncio
    async def test_double_close_is_idempotent(self) -> None:
        q: Queue[_Num] = Queue()
        await q.close()
        await q.close()  # 두 번 close 해도 오류 없음
        items = [item async for item in q]
        assert items == []


# ── WorkerPool ────────────────────────────────────────────────────────────────


class TestWorkerPool:
    @pytest.mark.asyncio
    async def test_basic_processing(self) -> None:
        q: Queue[_Num] = Queue()
        for i in range(3):
            await q.put(_Num(value=i))
        await q.close()

        pool: WorkerPool[_Num, _Result] = WorkerPool(_DoubleBlock(), concurrency=1)
        results = await pool.run(q)
        assert sorted(r.doubled for r in results) == [0, 2, 4]

    @pytest.mark.asyncio
    async def test_concurrency_speeds_up_processing(self) -> None:
        q: Queue[_Num] = Queue()
        for i in range(4):
            await q.put(_Num(value=i))
        await q.close()

        # concurrency=4 이면 4개가 병렬 실행 → 총 시간 ≈ sleep_sec
        pool: WorkerPool[_Num, _Result] = WorkerPool(
            _SlowDoubleBlock(sleep_sec=0.1), concurrency=4
        )
        import time

        t0 = time.monotonic()
        results = await pool.run(q)
        elapsed = time.monotonic() - t0

        assert len(results) == 4
        # 순차 실행이면 0.4s, 병렬이면 ~0.1s
        assert elapsed < 0.3

    @pytest.mark.asyncio
    async def test_output_queue_receives_results(self) -> None:
        src: Queue[_Num] = Queue()
        dst: Queue[_Result] = Queue()
        for i in [1, 2, 3]:
            await src.put(_Num(value=i))
        await src.close()

        pool: WorkerPool[_Num, _Result] = WorkerPool(_DoubleBlock(), concurrency=2)
        await pool.run(src, output=dst)

        # dst 는 WorkerPool 이 자동으로 close
        assert dst.closed
        items = [item async for item in dst]
        assert sorted(r.doubled for r in items) == [2, 4, 6]

    @pytest.mark.asyncio
    async def test_pipe_two_pools(self) -> None:
        """Queue → WorkerPool → Queue → WorkerPool 파이프 검증."""
        src: Queue[_Num] = Queue()
        mid: Queue[_Result] = Queue()

        class _ResultToNum(Block[_Result, _Num]):
            input_model = _Result
            output_model = _Num

            async def run(self, inp: _Result) -> _Num:
                return _Num(value=inp.doubled)

        for i in [1, 2]:
            await src.put(_Num(value=i))
        await src.close()

        pool1: WorkerPool[_Num, _Result] = WorkerPool(_DoubleBlock(), concurrency=2)
        pool2: WorkerPool[_Result, _Num] = WorkerPool(_ResultToNum(), concurrency=2)

        async with asyncio.TaskGroup() as tg:
            tg.create_task(pool1.run(src, output=mid))
            final_results_holder: list[list[_Num]] = []

            async def _run_pool2() -> None:
                final_results_holder.append(await pool2.run(mid))

            tg.create_task(_run_pool2())

        final = final_results_holder[0]
        assert sorted(r.value for r in final) == [2, 4]

    @pytest.mark.asyncio
    async def test_empty_queue_returns_empty(self) -> None:
        q: Queue[_Num] = Queue()
        await q.close()
        pool: WorkerPool[_Num, _Result] = WorkerPool(_DoubleBlock())
        results = await pool.run(q)
        assert results == []

    def test_invalid_concurrency_raises(self) -> None:
        with pytest.raises(ValueError, match="concurrency"):
            WorkerPool(_DoubleBlock(), concurrency=0)
