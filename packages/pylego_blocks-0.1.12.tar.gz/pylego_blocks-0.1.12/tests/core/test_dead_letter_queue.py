"""M15 DeadLetterQueue 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks.core.queue import DeadLetterQueue, Queue
from pylego_blocks.core.stud import Stud


# ── 픽스처 ───────────────────────────────────────────────────────────────────


class _Item(Stud):
    value: int


# ── 기본 동작 ────────────────────────────────────────────────────────────────


class TestDeadLetterQueueBasics:
    @pytest.mark.asyncio
    async def test_initially_empty(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        assert dlq.failed_count() == 0

    @pytest.mark.asyncio
    async def test_put_failed_stores_item(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        item = _Item(value=1)
        await dlq.put_failed(item, reason="테스트 실패")
        assert dlq.failed_count() == 1

    @pytest.mark.asyncio
    async def test_put_failed_multiple_items(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        for i in range(5):
            await dlq.put_failed(_Item(value=i), reason=f"실패 #{i}")
        assert dlq.failed_count() == 5

    @pytest.mark.asyncio
    async def test_failed_items_yields_all(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        items = [_Item(value=i) for i in range(3)]
        reasons = [f"reason_{i}" for i in range(3)]
        for item, reason in zip(items, reasons):
            await dlq.put_failed(item, reason)

        collected: list[tuple[_Item, str]] = []
        async for item, reason in dlq.failed_items():
            collected.append((item, reason))

        assert len(collected) == 3
        for i, (item, reason) in enumerate(collected):
            assert item.value == i
            assert reason == f"reason_{i}"

    @pytest.mark.asyncio
    async def test_failed_items_empty_queue(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        collected: list[tuple[_Item, str]] = []
        async for pair in dlq.failed_items():
            collected.append(pair)
        assert collected == []


# ── retry 동작 ───────────────────────────────────────────────────────────────


class TestDeadLetterQueueRetry:
    @pytest.mark.asyncio
    async def test_retry_moves_item_to_target_queue(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        item = _Item(value=42)
        await dlq.put_failed(item, reason="초기 실패")

        target: Queue[_Item] = Queue()
        await dlq.retry(item, target)

        # DLQ 에서 제거됐는지 확인
        assert dlq.failed_count() == 0

        # target 큐에 들어갔는지 확인
        received: list[_Item] = []
        await target.close()
        async for it in target:
            received.append(it)
        assert len(received) == 1
        assert received[0] is item

    @pytest.mark.asyncio
    async def test_retry_unknown_item_raises(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        item = _Item(value=99)
        target: Queue[_Item] = Queue()
        with pytest.raises(KeyError):
            await dlq.retry(item, target)

    @pytest.mark.asyncio
    async def test_retry_removes_only_targeted_item(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        item_a = _Item(value=1)
        item_b = _Item(value=2)
        await dlq.put_failed(item_a, reason="a 실패")
        await dlq.put_failed(item_b, reason="b 실패")

        target: Queue[_Item] = Queue()
        await dlq.retry(item_a, target)

        # item_b 는 DLQ 에 남아있어야 한다
        assert dlq.failed_count() == 1
        remaining: list[tuple[_Item, str]] = []
        async for pair in dlq.failed_items():
            remaining.append(pair)
        assert remaining[0][0] is item_b

    @pytest.mark.asyncio
    async def test_retry_uses_object_identity(self) -> None:
        """동일한 값을 가진 다른 객체는 retry 대상이 아니다 (동일성 검사)."""
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        item_a = _Item(value=1)
        await dlq.put_failed(item_a, reason="실패")

        # 같은 값이지만 다른 객체
        item_b = _Item(value=1)
        target: Queue[_Item] = Queue()
        with pytest.raises(KeyError):
            await dlq.retry(item_b, target)


# ── 복합 시나리오 ─────────────────────────────────────────────────────────────


class TestDeadLetterQueueScenario:
    @pytest.mark.asyncio
    async def test_multiple_retries_drain_dlq(self) -> None:
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        items = [_Item(value=i) for i in range(4)]
        for it in items:
            await dlq.put_failed(it, reason="실패")

        target: Queue[_Item] = Queue()
        for it in items:
            await dlq.retry(it, target)

        assert dlq.failed_count() == 0

    @pytest.mark.asyncio
    async def test_failed_items_snapshot_is_stable(self) -> None:
        """failed_items 이터레이션 중 DLQ 수정이 있어도 스냅샷 기준으로 동작한다."""
        dlq: DeadLetterQueue[_Item] = DeadLetterQueue()
        item_a = _Item(value=1)
        item_b = _Item(value=2)
        await dlq.put_failed(item_a, reason="a")
        await dlq.put_failed(item_b, reason="b")

        collected: list[_Item] = []
        async for it, _ in dlq.failed_items():
            collected.append(it)

        assert len(collected) == 2
