"""M94 — AssemblyValidator 시맨틱 조립 시점 검증 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks import Assembly, Block, Stud, check_chain
from pylego_blocks.core.compat import AssemblyValidator, SemanticCompatibilityError


# ── 픽스처 ───────────────────────────────────────────────────────────────────


class _In(Stud):
    query: str


class _Mid(Stud):
    value: int


class _Out(Stud):
    result: str


class _BlockA(Block[_In, _Mid]):
    input_model = _In
    output_model = _Mid

    async def run(self, inp: _In) -> _Mid:
        return _Mid(value=len(inp.query))


class _BlockB(Block[_Mid, _Out]):
    input_model = _Mid
    output_model = _Out

    async def run(self, inp: _Mid) -> _Out:
        return _Out(result=str(inp.value))


def _require_non_empty(inp: _In) -> None:
    if not inp.query.strip():
        raise ValueError("query 가 비어 있습니다")


# ── AssemblyValidator 기본 동작 ───────────────────────────────────────────────


def test_validate_passes_when_valid() -> None:
    v = AssemblyValidator({0: _require_non_empty})
    v.validate(0, _In(query="hello"))  # must not raise


def test_validate_raises_semantic_error_on_failure() -> None:
    v = AssemblyValidator({0: _require_non_empty})
    with pytest.raises(SemanticCompatibilityError) as exc_info:
        v.validate(0, _In(query="  "))
    assert exc_info.value.position == 0
    assert "비어" in exc_info.value.reason


def test_validate_skips_unregistered_position() -> None:
    v = AssemblyValidator({0: _require_non_empty})
    v.validate(1, _In(query=""))  # position 1 not registered — must not raise


def test_validator_positions_property() -> None:
    v = AssemblyValidator({0: _require_non_empty, 1: lambda x: None})
    assert v.positions == frozenset({0, 1})


# ── SemanticCompatibilityError 속성 ──────────────────────────────────────────


def test_semantic_error_attributes() -> None:
    err = SemanticCompatibilityError(position=2, reason="bad input")
    assert err.position == 2
    assert err.reason == "bad input"
    assert "position 2" in str(err)


# ── Assembly + validator ──────────────────────────────────────────────────────


async def test_assembly_validator_success() -> None:
    v = AssemblyValidator({0: _require_non_empty})
    pipeline: Assembly[_In, _Out] = Assembly([_BlockA(), _BlockB()], validator=v)
    result = await pipeline.run(_In(query="hello"))
    assert result.result == "5"


async def test_assembly_validator_failure_raises() -> None:
    v = AssemblyValidator({0: _require_non_empty})
    pipeline: Assembly[_In, _Out] = Assembly([_BlockA(), _BlockB()], validator=v)
    with pytest.raises(SemanticCompatibilityError) as exc_info:
        await pipeline.run(_In(query=""))
    assert exc_info.value.position == 0


def test_assembly_without_validator_unchanged() -> None:
    pipeline: Assembly[_In, _Out] = Assembly([_BlockA(), _BlockB()])
    result = pipeline.run_sync(_In(query=""))
    assert result.result == "0"


# ── check_chain + validator ───────────────────────────────────────────────────


def test_check_chain_with_valid_validator_positions() -> None:
    v = AssemblyValidator({0: _require_non_empty})
    result = check_chain([_BlockA(), _BlockB()], validator=v)
    assert result.compatible is True


def test_check_chain_out_of_bounds_validator_raises() -> None:
    v = AssemblyValidator({5: _require_non_empty})  # 5 is out of range for 2-block chain
    with pytest.raises(SemanticCompatibilityError) as exc_info:
        check_chain([_BlockA(), _BlockB()], validator=v)
    assert exc_info.value.position == 5


def test_check_chain_without_validator_unchanged() -> None:
    result = check_chain([_BlockA(), _BlockB()])
    assert result.compatible is True


def test_check_chain_validator_none_compatible_false_still_works() -> None:
    result = check_chain([_BlockB(), _BlockA()])  # incompatible chain
    assert result.compatible is False


# ── top-level import ──────────────────────────────────────────────────────────


def test_top_level_import() -> None:
    from pylego_blocks import AssemblyValidator as AV
    from pylego_blocks import SemanticCompatibilityError as SCE
    assert AV is AssemblyValidator
    assert SCE is SemanticCompatibilityError
