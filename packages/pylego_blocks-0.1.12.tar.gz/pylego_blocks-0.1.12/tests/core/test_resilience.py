"""M9 에러 복구 — RetryBlock / FallbackBlock / TimeoutBlock 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego_blocks.core.assembly import Assembly, IncompatibleSnapError
from pylego_blocks.core.block import Block
from pylego_blocks.core.events import BlockRetryEvent, observe
from pylego_blocks.core.resilience import FallbackBlock, RetryBlock, RetryPolicy, TimeoutBlock
from pylego_blocks.core.stud import Stud


# ── 픽스처 블록 ──────────────────────────────────────────────────────────────


class _In(Stud):
    value: int


class _Out(Stud):
    result: int


class _Other(Stud):
    x: int


class _DoubleBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(result=inp.value * 2)


class _FailNTimesBlock(Block[_In, _Out]):
    """처음 n 번 실패하고 그 다음부터 성공하는 블록."""

    input_model = _In
    output_model = _Out

    def __init__(self, fail_times: int) -> None:
        self._fail_times = fail_times
        self._calls = 0

    async def run(self, inp: _In) -> _Out:
        self._calls += 1
        if self._calls <= self._fail_times:
            raise RuntimeError(f"의도된 실패 #{self._calls}")
        return _Out(result=inp.value)


class _AlwaysFailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("항상 실패")


class _SlowBlock(Block[_In, _Out]):
    """지정 시간만큼 대기하는 블록."""

    input_model = _In
    output_model = _Out

    def __init__(self, sleep_sec: float) -> None:
        self._sleep_sec = sleep_sec

    async def run(self, inp: _In) -> _Out:
        await asyncio.sleep(self._sleep_sec)
        return _Out(result=inp.value)


class _CollectorBus:
    def __init__(self) -> None:
        from pylego_blocks.core.events import BlockEvent

        self.events: list[BlockEvent] = []

    def emit(self, event: object) -> None:
        from pylego_blocks.core.events import BlockEvent

        if isinstance(event, BlockEvent):  # type: ignore[arg-type]
            self.events.append(event)  # type: ignore[arg-type]


# ── RetryPolicy ───────────────────────────────────────────────────────────────


class TestRetryPolicy:
    def test_defaults(self) -> None:
        p = RetryPolicy()
        assert p.max_attempts == 3
        assert p.delay_sec == 0.0
        assert p.backoff == 1.0

    def test_invalid_max_attempts(self) -> None:
        with pytest.raises(ValueError, match="max_attempts"):
            RetryPolicy(max_attempts=0)

    def test_invalid_delay(self) -> None:
        with pytest.raises(ValueError, match="delay_sec"):
            RetryPolicy(delay_sec=-1.0)

    def test_invalid_backoff(self) -> None:
        with pytest.raises(ValueError, match="backoff"):
            RetryPolicy(backoff=0.5)


# ── RetryBlock ────────────────────────────────────────────────────────────────


class TestRetryBlock:
    def test_success_on_first_attempt(self) -> None:
        block = RetryBlock(_DoubleBlock())
        asm: Assembly[_In, _Out] = Assembly([block])
        result = asm.run_sync(_In(value=5))
        assert result.result == 10

    def test_success_after_retry(self) -> None:
        inner = _FailNTimesBlock(fail_times=2)
        block = RetryBlock(inner, RetryPolicy(max_attempts=3))
        asm: Assembly[_In, _Out] = Assembly([block])
        result = asm.run_sync(_In(value=7))
        assert result.result == 7
        assert inner._calls == 3

    def test_raises_after_max_attempts_exhausted(self) -> None:
        block = RetryBlock(_AlwaysFailBlock(), RetryPolicy(max_attempts=3))
        asm: Assembly[_In, _Out] = Assembly([block])
        with pytest.raises(RuntimeError, match="항상 실패"):
            asm.run_sync(_In(value=1))

    def test_call_count_matches_max_attempts(self) -> None:
        inner = _FailNTimesBlock(fail_times=99)
        block = RetryBlock(inner, RetryPolicy(max_attempts=4))
        asm: Assembly[_In, _Out] = Assembly([block])
        with pytest.raises(RuntimeError):
            asm.run_sync(_In(value=1))
        assert inner._calls == 4

    def test_name_reflects_inner(self) -> None:
        inner = _DoubleBlock()
        block = RetryBlock(inner)
        assert "_DoubleBlock" in block.name

    def test_input_output_model_inherited(self) -> None:
        block = RetryBlock(_DoubleBlock())
        assert block.input_model is _In
        assert block.output_model is _Out

    def test_retry_events_emitted(self) -> None:
        bus = _CollectorBus()
        inner = _FailNTimesBlock(fail_times=2)
        block = RetryBlock(inner, RetryPolicy(max_attempts=3))
        asm: Assembly[_In, _Out] = Assembly([block])
        with observe(bus):  # type: ignore[arg-type]
            asm.run_sync(_In(value=1))

        retry_events = [e for e in bus.events if isinstance(e, BlockRetryEvent)]
        assert len(retry_events) == 2
        assert retry_events[0].attempt == 1
        assert retry_events[1].attempt == 2

    def test_no_retry_event_on_final_failure(self) -> None:
        bus = _CollectorBus()
        block = RetryBlock(_AlwaysFailBlock(), RetryPolicy(max_attempts=2))
        asm: Assembly[_In, _Out] = Assembly([block])
        with observe(bus), pytest.raises(RuntimeError):  # type: ignore[arg-type]
            asm.run_sync(_In(value=1))

        retry_events = [e for e in bus.events if isinstance(e, BlockRetryEvent)]
        # 마지막 실패는 BlockRetryEvent 가 아닌 BlockFailedEvent
        assert len(retry_events) == 1  # 첫 실패 후 1회 재시도 이벤트


# ── FallbackBlock ─────────────────────────────────────────────────────────────


class TestFallbackBlock:
    def test_primary_succeeds(self) -> None:
        block = FallbackBlock(_DoubleBlock(), _DoubleBlock())
        asm: Assembly[_In, _Out] = Assembly([block])
        result = asm.run_sync(_In(value=4))
        assert result.result == 8

    def test_fallback_used_on_primary_failure(self) -> None:
        fallback = _DoubleBlock()
        block = FallbackBlock(_AlwaysFailBlock(), fallback)
        asm: Assembly[_In, _Out] = Assembly([block])
        result = asm.run_sync(_In(value=3))
        assert result.result == 6

    def test_raises_if_both_fail(self) -> None:
        block = FallbackBlock(_AlwaysFailBlock(), _AlwaysFailBlock())
        asm: Assembly[_In, _Out] = Assembly([block])
        with pytest.raises(RuntimeError, match="항상 실패"):
            asm.run_sync(_In(value=1))

    def test_input_model_mismatch_raises(self) -> None:
        class _OtherBlock(Block[_Other, _Out]):
            input_model = _Other
            output_model = _Out

            async def run(self, inp: _Other) -> _Out:
                return _Out(result=inp.x)

        with pytest.raises(IncompatibleSnapError, match="input"):
            FallbackBlock(_DoubleBlock(), _OtherBlock())

    def test_output_model_mismatch_raises(self) -> None:
        class _WrongOutBlock(Block[_In, _Other]):
            input_model = _In
            output_model = _Other

            async def run(self, inp: _In) -> _Other:
                return _Other(x=inp.value)

        with pytest.raises(IncompatibleSnapError, match="output"):
            FallbackBlock(_DoubleBlock(), _WrongOutBlock())

    def test_name_reflects_both(self) -> None:
        block = FallbackBlock(_DoubleBlock(), _AlwaysFailBlock())
        assert "_DoubleBlock" in block.name
        assert "_AlwaysFailBlock" in block.name

    def test_input_output_model_inherited(self) -> None:
        block = FallbackBlock(_DoubleBlock(), _DoubleBlock())
        assert block.input_model is _In
        assert block.output_model is _Out


# ── TimeoutBlock ──────────────────────────────────────────────────────────────


class TestTimeoutBlock:
    def test_fast_block_succeeds(self) -> None:
        block = TimeoutBlock(_SlowBlock(sleep_sec=0.0), timeout_sec=1.0)
        asm: Assembly[_In, _Out] = Assembly([block])
        result = asm.run_sync(_In(value=9))
        assert result.result == 9

    @pytest.mark.asyncio
    async def test_slow_block_raises_timeout(self) -> None:
        block = TimeoutBlock(_SlowBlock(sleep_sec=5.0), timeout_sec=0.05)
        with pytest.raises(asyncio.TimeoutError):
            await block.run(_In(value=1))

    def test_invalid_timeout_raises(self) -> None:
        with pytest.raises(ValueError, match="timeout_sec"):
            TimeoutBlock(_DoubleBlock(), timeout_sec=0.0)

    def test_negative_timeout_raises(self) -> None:
        with pytest.raises(ValueError, match="timeout_sec"):
            TimeoutBlock(_DoubleBlock(), timeout_sec=-1.0)

    def test_name_includes_timeout(self) -> None:
        block = TimeoutBlock(_DoubleBlock(), timeout_sec=3.0)
        assert "3.0s" in block.name

    def test_input_output_model_inherited(self) -> None:
        block = TimeoutBlock(_DoubleBlock(), timeout_sec=1.0)
        assert block.input_model is _In
        assert block.output_model is _Out
