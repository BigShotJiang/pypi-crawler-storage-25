"""Branch 블록 동작 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks.core import Assembly, Block, Branch, IncompatibleSnapError, Stud


class _In(Stud):
    route: bool
    text: str


class _Mid(Stud):
    text: str


class _Out(Stud):
    length: int


class _TrueBlock(Block[_In, _Mid]):
    input_model = _In
    output_model = _Mid

    async def run(self, inp: _In) -> _Mid:
        return _Mid(text=f"true:{inp.text}")


class _FalseBlock(Block[_In, _Mid]):
    input_model = _In
    output_model = _Mid

    async def run(self, inp: _In) -> _Mid:
        return _Mid(text=f"false:{inp.text}")


class _Length(Block[_Mid, _Out]):
    input_model = _Mid
    output_model = _Out

    async def run(self, inp: _Mid) -> _Out:
        return _Out(length=len(inp.text))


class _WrongInput(Block[_Out, _Mid]):
    input_model = _Out
    output_model = _Mid

    async def run(self, inp: _Out) -> _Mid:  # pragma: no cover
        return _Mid(text="")


class _WrongOutput(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:  # pragma: no cover
        return _Out(length=0)


class TestBranchRun:
    async def test_true_path_runs_true_block(self) -> None:
        branch = Branch(lambda inp: inp.route, _TrueBlock(), _FalseBlock())
        result = await branch.run(_In(route=True, text="yes"))
        assert result == _Mid(text="true:yes")

    async def test_false_path_runs_false_block(self) -> None:
        branch = Branch(lambda inp: inp.route, _TrueBlock(), _FalseBlock())
        result = await branch.run(_In(route=False, text="no"))
        assert result == _Mid(text="false:no")

    async def test_predicate_receives_original_input(self) -> None:
        seen: list[_In] = []

        def predicate(inp: _In) -> bool:
            seen.append(inp)
            return True

        branch = Branch(predicate, _TrueBlock(), _FalseBlock())
        inp = _In(route=True, text="keep")
        await branch.run(inp)
        assert seen == [inp]
        assert seen[0] is inp


class TestBranchBuild:
    def test_input_mismatch_raises(self) -> None:
        with pytest.raises(IncompatibleSnapError):
            Branch(lambda inp: True, _TrueBlock(), _WrongInput())

    def test_output_mismatch_raises(self) -> None:
        with pytest.raises(IncompatibleSnapError):
            Branch(lambda inp: True, _TrueBlock(), _WrongOutput())

    async def test_branch_is_block_in_assembly(self) -> None:
        branch = Branch(lambda inp: inp.route, _TrueBlock(), _FalseBlock())
        asm: Assembly[_In, _Out] = Assembly([branch, _Length()])
        result = await asm.run(_In(route=True, text="go"))
        assert result == _Out(length=7)
