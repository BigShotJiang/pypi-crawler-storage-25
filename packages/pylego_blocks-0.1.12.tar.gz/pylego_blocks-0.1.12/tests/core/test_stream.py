"""M10 스트리밍 — StreamBlock + Assembly.stream() 테스트."""

from __future__ import annotations

from collections.abc import AsyncGenerator

import pytest

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.stream import StreamBlock
from pylego_blocks.core.stud import Stud


# ── 픽스처 ──────────────────────────────────────────────────────────────────


class _In(Stud):
    text: str


class _Chunk(Stud):
    char: str


class _Out(Stud):
    length: int


class _LenBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(length=len(inp.text))


class _CharStream(StreamBlock[_In, _Chunk]):
    """입력 문자열을 한 글자씩 yield 하는 스트림 블록."""

    input_model = _In
    output_model = _Chunk

    async def stream(self, inp: _In) -> AsyncGenerator[_Chunk, None]:
        for ch in inp.text:
            yield _Chunk(char=ch)


class _EmptyStream(StreamBlock[_In, _Chunk]):
    input_model = _In
    output_model = _Chunk

    async def stream(self, inp: _In) -> AsyncGenerator[_Chunk, None]:
        return
        yield  # make it an async generator


# ── StreamBlock ───────────────────────────────────────────────────────────────


class TestStreamBlock:
    @pytest.mark.asyncio
    async def test_stream_yields_items(self) -> None:
        block = _CharStream()
        chunks = [c async for c in block.stream(_In(text="hi"))]
        assert [c.char for c in chunks] == ["h", "i"]

    def test_run_returns_last_item(self) -> None:
        block = _CharStream()
        asm: Assembly[_In, _Chunk] = Assembly([block])
        result = asm.run_sync(_In(text="abc"))
        assert result.char == "c"

    @pytest.mark.asyncio
    async def test_run_raises_on_empty_stream(self) -> None:
        block = _EmptyStream()
        with pytest.raises(RuntimeError, match="빈 값"):
            await block.run(_In(text="x"))

    def test_input_output_model(self) -> None:
        block = _CharStream()
        assert block.input_model is _In
        assert block.output_model is _Chunk

    def test_stream_block_in_assembly(self) -> None:
        """StreamBlock 은 Assembly 안에서 일반 Block 과 동일하게 사용 가능."""

        class _ChunkToOut(Block[_Chunk, _Out]):
            input_model = _Chunk
            output_model = _Out

            async def run(self, inp: _Chunk) -> _Out:
                return _Out(length=ord(inp.char))

        asm: Assembly[_In, _Out] = Assembly([_CharStream(), _ChunkToOut()])
        result = asm.run_sync(_In(text="A"))
        assert result.length == ord("A")


# ── Assembly.stream() ─────────────────────────────────────────────────────────


class TestAssemblyStream:
    @pytest.mark.asyncio
    async def test_stream_yields_intermediate_results(self) -> None:
        class _UpperBlock(Block[_In, _In]):
            input_model = _In
            output_model = _In

            async def run(self, inp: _In) -> _In:
                return _In(text=inp.text.upper())

        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        steps = [(name, out) async for name, out in asm.stream(_In(text="hello"))]

        assert len(steps) == 2
        name0, out0 = steps[0]
        assert name0 == "_UpperBlock"
        assert isinstance(out0, _In)
        assert out0.text == "HELLO"  # type: ignore[union-attr]

        name1, out1 = steps[1]
        assert name1 == "_LenBlock"
        assert isinstance(out1, _Out)
        assert out1.length == 5  # type: ignore[union-attr]

    @pytest.mark.asyncio
    async def test_stream_last_result_equals_run(self) -> None:
        asm: Assembly[_In, _Out] = Assembly([_LenBlock()])
        steps = [(n, o) async for n, o in asm.stream(_In(text="pylego"))]
        _, last = steps[-1]
        assert isinstance(last, _Out)
        expected = await asm.run(_In(text="pylego"))
        assert last.length == expected.length  # type: ignore[union-attr]

    @pytest.mark.asyncio
    async def test_stream_single_block(self) -> None:
        asm: Assembly[_In, _Out] = Assembly([_LenBlock()])
        steps = [(n, o) async for n, o in asm.stream(_In(text="x"))]
        assert len(steps) == 1
