"""SemanticRetryBlock abort_on_repeated_error 기능 테스트."""

import asyncio

import pytest

from pylego_blocks import Assembly, Block, SemanticRetryBlock, Stud
from pylego_blocks.core.semantic_retry import MaxRepeatedErrorError


class Req(Stud):
    prompt: str
    hint: str = ""


class Resp(Stud):
    verdict: str


class FixedErrorBlock(Block[Req, Resp]):
    """항상 동일한 에러 메시지를 반환하는 목업 블록."""

    input_model = Req
    output_model = Resp

    def __init__(self, error_sequence: list[str]) -> None:
        """error_sequence: 각 호출마다 반환할 verdict 값 목록 (모두 실패용)."""
        self._errors = error_sequence
        self._call_count = 0

    async def run(self, inp: Req) -> Resp:
        idx = min(self._call_count, len(self._errors) - 1)
        verdict = self._errors[idx]
        self._call_count += 1
        return Resp(verdict=verdict)


def _verify(inp: Req, out: Resp) -> None:
    if out.verdict != "PASS":
        raise ValueError(f"검증 실패: {out.verdict}")


def _enrich(inp: Req, out: Resp, error: str) -> Req:
    return inp.model_copy(update={"hint": f"[재시도: {error}]"})


# ── abort_on_repeated_error: 동일 오류 차단 ─────────────────────────────────


def test_abort_on_repeated_same_error() -> None:
    """동일 오류가 N회 반복되면 MaxRepeatedErrorError 발생."""
    inner = FixedErrorBlock(["FAIL", "FAIL", "FAIL", "FAIL", "FAIL"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=3,
    )
    with pytest.raises(MaxRepeatedErrorError) as exc_info:
        asyncio.run(block.run(Req(prompt="테스트")))
    assert "3회 반복" in str(exc_info.value)
    assert "검증 실패: FAIL" in str(exc_info.value)
    # 3번 호출 후 중단
    assert inner._call_count == 3


def test_no_abort_different_errors() -> None:
    """서로 다른 오류가 번갈아 발생하면 카운터가 리셋되고 일반 재시도로 진행."""
    inner = FixedErrorBlock(["FAIL_A", "FAIL_B", "FAIL_A", "FAIL_B", "FAIL_A"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=3,
    )
    # 동일 오류 연속 3회 없음 → MaxRepeatedErrorError 아닌 일반 ValueError
    with pytest.raises(ValueError, match="검증 실패"):
        asyncio.run(block.run(Req(prompt="테스트")))
    assert inner._call_count == 5


def test_none_default_no_abort() -> None:
    """abort_on_repeated_error=None(기본값)이면 조기 중단 없이 기존 동작 유지."""
    inner = FixedErrorBlock(["FAIL", "FAIL", "FAIL"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=3,
        # abort_on_repeated_error 미설정 (None)
    )
    with pytest.raises(ValueError, match="검증 실패"):
        asyncio.run(block.run(Req(prompt="테스트")))
    # MaxRepeatedErrorError가 아닌 ValueError
    assert inner._call_count == 3


def test_abort_count_resets_on_different_error() -> None:
    """오류 메시지가 바뀌면 카운터가 1로 리셋된다."""
    # FAIL_A x2 → FAIL_B x1 → FAIL_A x2 순서면 연속 동일 max = 2 → abort_on_repeated=3 미발동
    inner = FixedErrorBlock(["FAIL_A", "FAIL_A", "FAIL_B", "FAIL_A", "FAIL_A"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=3,
    )
    with pytest.raises(ValueError, match="검증 실패"):
        asyncio.run(block.run(Req(prompt="테스트")))
    # 3회 연속 동일 오류 없음 → 전체 5회 소진
    assert inner._call_count == 5


def test_invalid_abort_value() -> None:
    """abort_on_repeated_error=0은 ValueError를 발생시킨다."""
    inner = FixedErrorBlock(["FAIL"])
    with pytest.raises(ValueError, match="1 이상"):
        SemanticRetryBlock(
            inner,
            verify_fn=_verify,
            enrich_fn=_enrich,
            abort_on_repeated_error=0,
        )


def test_invalid_abort_value_negative() -> None:
    """abort_on_repeated_error=-1도 ValueError를 발생시킨다."""
    inner = FixedErrorBlock(["FAIL"])
    with pytest.raises(ValueError, match="1 이상"):
        SemanticRetryBlock(
            inner,
            verify_fn=_verify,
            enrich_fn=_enrich,
            abort_on_repeated_error=-1,
        )


def test_assembly_integration() -> None:
    """Assembly 안에서 MaxRepeatedErrorError가 정상 전파된다."""
    inner = FixedErrorBlock(["SAME_ERROR", "SAME_ERROR", "SAME_ERROR"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
    )
    pipeline: Assembly[Req, Resp] = Assembly([block])
    with pytest.raises(MaxRepeatedErrorError) as exc_info:
        pipeline.run_sync(Req(prompt="어셈블리 테스트"))
    assert "2회 반복" in str(exc_info.value)


# ── error_similarity_fn ───────────────────────────────────────────────────────


def test_error_similarity_fn_none_default_exact_match() -> None:
    """error_similarity_fn=None(기본값)이면 완전 동일 문자열만 반복으로 간주한다."""
    # 앞부분은 같지만 끝이 다른 오류 → 동일 취급 안 함 → MaxRepeatedErrorError 미발생
    inner = FixedErrorBlock(
        ["검증 실패: FAIL_1", "검증 실패: FAIL_2", "검증 실패: FAIL_1"]
    )
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=3,
        abort_on_repeated_error=2,
        error_similarity_fn=None,
    )
    # 완전 동일 문자열 반복 없음 → 일반 ValueError로 소진
    with pytest.raises(ValueError, match="검증 실패"):
        asyncio.run(block.run(Req(prompt="테스트")))
    assert inner._call_count == 3


def test_error_similarity_fn_prefix20_triggers_abort() -> None:
    """앞 20자 비교 함수를 쓰면 prefix가 같으면 동일 실패로 간주, abort_on_repeated_error=2에서 3번째 시도 전 MaxRepeatedErrorError 발생."""
    # 앞 20자는 동일("검증 실패: FAIL_LO"), 뒤는 다른 오류
    inner = FixedErrorBlock(
        [
            "검증 실패: FAIL_LONG_A",
            "검증 실패: FAIL_LONG_B",
            "검증 실패: FAIL_LONG_C",
        ]
    )
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        error_similarity_fn=lambda a, b: a[:20] == b[:20],
    )
    with pytest.raises(MaxRepeatedErrorError):
        asyncio.run(block.run(Req(prompt="테스트")))
    # 1회(repeated_count=1) + 2회(repeated_count=2, abort) → inner는 2번 호출
    assert inner._call_count == 2


# ── on_abort_fn ──────────────────────────────────────────────────────────────


def test_on_abort_fn_called_instead_of_raise() -> None:
    """on_abort_fn 지정 시 MaxRepeatedErrorError 대신 콜백 결과가 반환된다."""

    async def fallback(inp: Req, error: str) -> Resp:
        return Resp(verdict="FALLBACK")

    inner = FixedErrorBlock(["FAIL", "FAIL", "FAIL"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        on_abort_fn=fallback,
        verify_after_abort=False,  # 폴백 결과 검증 없이 그대로 반환
    )
    result = asyncio.run(block.run(Req(prompt="테스트")))
    assert result.verdict == "FALLBACK"


def test_on_abort_fn_receives_error_string() -> None:
    """on_abort_fn에 반복 오류 메시지가 전달된다."""
    received: list[str] = []

    async def capture(inp: Req, error: str) -> Resp:
        received.append(error)
        return Resp(verdict="CAPTURED")

    inner = FixedErrorBlock(["FAIL", "FAIL"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=5,
        abort_on_repeated_error=2,
        on_abort_fn=capture,
        verify_after_abort=False,  # 폴백 결과 검증 없이 그대로 반환
    )
    asyncio.run(block.run(Req(prompt="테스트")))
    assert len(received) == 1
    assert "FAIL" in received[0]


def test_error_similarity_fn_dissimilar_resets_count() -> None:
    """유사하지 않은 오류가 끼면 카운터가 리셋된다.

    _verify raises ValueError(f"검증 실패: {out.verdict}"), so error_str is
    "검증 실패: <verdict>".  We compare by verdict suffix (last 3 chars of error_str)
    so that a completely different verdict breaks the streak.

    Sequence (verdicts):  SAME, SAME, DIFF, SAME, SAME, SAME
    error_str last-3 map: AME,  AME,  IFF,  AME,  AME,  AME
    Call 1: count=1  (first entry, last_error="" → different → count=1)
    Call 2: count=2  (same suffix)
    Call 3: reset    (different suffix → count=1, last_error updated)
    Call 4: count=1  (different from DIFF → reset, count=1)
    Call 5: count=2  (same)
    Call 6: count=3 → abort
    inner._call_count == 6
    """
    inner = FixedErrorBlock(["SAME", "SAME", "DIFF", "SAME", "SAME", "SAME"])
    block = SemanticRetryBlock(
        inner,
        verify_fn=_verify,
        enrich_fn=_enrich,
        max_attempts=10,
        abort_on_repeated_error=3,
        error_similarity_fn=lambda a, b: a[-3:] == b[-3:],
    )
    with pytest.raises(MaxRepeatedErrorError):
        asyncio.run(block.run(Req(prompt="테스트")))
    # 리셋 후 3회 연속 동일 suffix → 6번째 호출에서 abort
    assert inner._call_count == 6
