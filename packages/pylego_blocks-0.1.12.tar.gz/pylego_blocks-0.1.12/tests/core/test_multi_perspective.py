"""MultiPerspectiveBlock + 합의 전략 테스트."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from pylego_blocks.core.assembly import IncompatibleSnapError
from pylego_blocks.core.block import Block
from pylego_blocks.core.multi_perspective import (
    ConsensusError,
    ConsensusPolicy,
    MultiPerspectiveBlock,
    ConfidenceWeighted,
    MajorityVote,
    UnanimousRequired,
)
from pylego_blocks.core.stud import Stud


# ── 공통 Stud / 블록 픽스처 ─────────────────────────────────────────────────

class _In(Stud):
    value: int


class _Verdict(Stud):
    result: str


def _verdict_block(result: str) -> Block[_In, _Verdict]:
    class _B(Block[_In, _Verdict]):
        input_model = _In
        output_model = _Verdict

        async def run(self, inp: _In) -> _Verdict:
            return _Verdict(result=result)

    _B.__name__ = f"Block_{result}"
    return _B()


# ── MajorityVote ────────────────────────────────────────────────────────────

def test_MajorityVote_unanimous() -> None:
    fn = MajorityVote()
    result = fn([_Verdict(result="PASS"), _Verdict(result="PASS"), _Verdict(result="PASS")])
    assert result == _Verdict(result="PASS")


def test_MajorityVote_split() -> None:
    fn = MajorityVote(min_agreement=2)
    result = fn([_Verdict(result="PASS"), _Verdict(result="PASS"), _Verdict(result="FAIL")])
    assert result == _Verdict(result="PASS")


def test_MajorityVote_min_agreement_fail() -> None:
    fn = MajorityVote(min_agreement=3)
    with pytest.raises(ConsensusError, match="미충족"):
        fn([_Verdict(result="PASS"), _Verdict(result="PASS"), _Verdict(result="FAIL")])


def test_MajorityVote_empty() -> None:
    fn = MajorityVote()
    with pytest.raises(ConsensusError, match="결과 없음"):
        fn([])


def test_MajorityVote_all_different_min1() -> None:
    fn = MajorityVote(min_agreement=1)
    result = fn([_Verdict(result="A"), _Verdict(result="B"), _Verdict(result="C")])
    assert result in [_Verdict(result="A"), _Verdict(result="B"), _Verdict(result="C")]


# ── ConfidenceWeighted ──────────────────────────────────────────────────────

def test_ConfidenceWeighted_highest_wins() -> None:
    fn = ConfidenceWeighted([0.2, 0.9, 0.5])
    result = fn([_Verdict(result="LOW"), _Verdict(result="HIGH"), _Verdict(result="MID")])
    assert result == _Verdict(result="HIGH")


def test_ConfidenceWeighted_weight_mismatch() -> None:
    fn = ConfidenceWeighted([0.5, 0.5])
    with pytest.raises(ValueError, match="일치하지 않습니다"):
        fn([_Verdict(result="A"), _Verdict(result="B"), _Verdict(result="C")])


def test_ConfidenceWeighted_inverse_signal_score() -> None:
    # 낮은 의심도 → 높은 신뢰 → 가중치 = 1 - score
    scores = [0.8, 0.1, 0.5]
    weights = [1.0 - s for s in scores]  # [0.2, 0.9, 0.5]
    fn = ConfidenceWeighted(weights)
    results = [_Verdict(result="X"), _Verdict(result="Y"), _Verdict(result="Z")]
    result = fn(results)
    assert result == _Verdict(result="Y")  # 가중치 0.9 최고


# ── UnanimousRequired ───────────────────────────────────────────────────────

def test_UnanimousRequired_all_same() -> None:
    fn = UnanimousRequired()
    result = fn([_Verdict(result="PASS")] * 3)
    assert result == _Verdict(result="PASS")


def test_UnanimousRequired_disagreement() -> None:
    fn = UnanimousRequired()
    with pytest.raises(ConsensusError, match="전원 일치"):
        fn([_Verdict(result="PASS"), _Verdict(result="FAIL")])


def test_UnanimousRequired_empty() -> None:
    fn = UnanimousRequired()
    with pytest.raises(ConsensusError, match="결과 없음"):
        fn([])


# ── MultiPerspectiveBlock 구성 검증 ──────────────────────────────────────────

def test_rejects_single_perspective() -> None:
    with pytest.raises(ValueError, match="최소 2개"):
        MultiPerspectiveBlock(
            perspectives=[_verdict_block("PASS")],
            vote_fn=MajorityVote(),
        )


def test_rejects_mismatched_input_models() -> None:
    class _OtherIn(Stud):
        x: int

    class _OtherBlock(Block[_OtherIn, _Verdict]):
        input_model = _OtherIn
        output_model = _Verdict

        async def run(self, inp: _OtherIn) -> _Verdict:
            return _Verdict(result="X")

    with pytest.raises(IncompatibleSnapError):
        MultiPerspectiveBlock(
            perspectives=[_verdict_block("PASS"), _OtherBlock()],
            vote_fn=MajorityVote(),
        )


def test_rejects_mismatched_output_models() -> None:
    class _OtherOut(Stud):
        x: int

    class _OtherBlock(Block[_In, _OtherOut]):
        input_model = _In
        output_model = _OtherOut

        async def run(self, inp: _In) -> _OtherOut:
            return _OtherOut(x=0)

    with pytest.raises(IncompatibleSnapError):
        MultiPerspectiveBlock(
            perspectives=[_verdict_block("PASS"), _OtherBlock()],
            vote_fn=MajorityVote(),
        )


def test_io_models_derived_from_perspectives() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("FAIL")],
        vote_fn=MajorityVote(),
    )
    assert block.input_model is _In
    assert block.output_model is _Verdict


def test_name_default() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("FAIL")],
        vote_fn=MajorityVote(),
    )
    assert "MultiPerspective" in block.name


def test_name_override() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("A"), _verdict_block("B")],
        vote_fn=MajorityVote(),
        name="MyConsensus",
    )
    assert block.name == "MyConsensus"


# ── 기본 실행 (MajorityVote) ─────────────────────────────────────────────────

async def test_run_MajorityVote_passes() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[
            _verdict_block("PASS"),
            _verdict_block("PASS"),
            _verdict_block("FAIL"),
        ],
        vote_fn=MajorityVote(min_agreement=2),
    )
    result = await block.run(_In(value=1))
    assert result == _Verdict(result="PASS")


async def test_run_UnanimousRequired_passes() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("PASS")],
        vote_fn=UnanimousRequired(),
    )
    result = await block.run(_In(value=1))
    assert result == _Verdict(result="PASS")


# ── ConsensusPolicy: raise_error ─────────────────────────────────────────────

async def test_policy_raise_error_on_consensus_fail() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("FAIL")],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(raise_error=True),
    )
    with pytest.raises(ConsensusError):
        await block.run(_In(value=1))


async def test_policy_raise_error_false_no_raise_when_consensus_ok() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("PASS")],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(raise_error=True),
    )
    result = await block.run(_In(value=1))
    assert result == _Verdict(result="PASS")


# ── ConsensusPolicy: fallback ─────────────────────────────────────────────────

class _FallbackBlock(Block[_In, _Verdict]):
    input_model = _In
    output_model = _Verdict

    async def run(self, inp: _In) -> _Verdict:
        return _Verdict(result="FALLBACK")


async def test_policy_fallback_on_consensus_fail() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("FAIL")],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(fallback=_FallbackBlock()),
    )
    result = await block.run(_In(value=1))
    assert result == _Verdict(result="FALLBACK")


# ── ConsensusPolicy: escalate_to ─────────────────────────────────────────────

class _EscalateBlock(Block[_In, _Verdict]):
    input_model = _In
    output_model = _Verdict

    def __init__(self) -> None:
        self.calls: list[int] = []

    async def run(self, inp: _In) -> _Verdict:
        self.calls.append(inp.value)
        return _Verdict(result="ESCALATED")


async def test_policy_escalate_called_and_reraises() -> None:
    side = _EscalateBlock()
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("A"), _verdict_block("B")],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(escalate_to=side),
    )
    with pytest.raises(ConsensusError):
        await block.run(_In(value=42))
    assert side.calls == [42]


async def test_policy_escalate_not_called_when_consensus_ok() -> None:
    side = _EscalateBlock()
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("PASS"), _verdict_block("PASS")],
        vote_fn=UnanimousRequired(),
        consensus_policy=ConsensusPolicy(escalate_to=side),
    )
    await block.run(_In(value=1))
    assert side.calls == []


# ── default policy: reraise ConsensusError ───────────────────────────────────

async def test_default_policy_reraises_consensus_error() -> None:
    block = MultiPerspectiveBlock(
        perspectives=[_verdict_block("A"), _verdict_block("B")],
        vote_fn=UnanimousRequired(),
    )
    with pytest.raises(ConsensusError):
        await block.run(_In(value=1))


# ── 공개 API 노출 확인 ───────────────────────────────────────────────────────

def test_importable_from_pylego() -> None:
    from pylego_blocks import (  # noqa: PLC0415
        ConsensusError as CE,
        ConsensusPolicy as CP,
        MultiPerspectiveBlock as MPB,
        ConfidenceWeighted as cw,
        MajorityVote as mv,
        UnanimousRequired as ur,
    )
    assert CE is ConsensusError
    assert CP is ConsensusPolicy
    assert MPB is MultiPerspectiveBlock
    assert mv is MajorityVote
    assert ur is UnanimousRequired
    assert cw is ConfidenceWeighted
