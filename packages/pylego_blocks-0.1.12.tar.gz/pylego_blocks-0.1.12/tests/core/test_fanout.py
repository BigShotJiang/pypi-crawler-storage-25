"""FanOut 블록 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego_blocks.core import Block, FanOut, Gathered, IncompatibleSnapError, Stud


class _In(Stud):
    val: int = 0


class _OutA(Stud):
    ok: bool = True


class _OutB(Stud):
    tag: str = "b"


class _OutC(Stud):
    num: int = 0


class _BlockA(Block[_In, _OutA]):
    input_model = _In
    output_model = _OutA

    async def run(self, inp: _In) -> _OutA:
        return _OutA()


class _BlockB(Block[_In, _OutB]):
    input_model = _In
    output_model = _OutB

    async def run(self, inp: _In) -> _OutB:
        return _OutB()


class _SlowA(Block[_In, _OutA]):
    input_model = _In
    output_model = _OutA

    async def run(self, inp: _In) -> _OutA:
        await asyncio.sleep(0.05)
        return _OutA()


class _WrongInput(Block[_OutC, _OutA]):
    input_model = _OutC
    output_model = _OutA

    async def run(self, inp: _OutC) -> _OutA:  # pragma: no cover
        return _OutA()


class TestFanOutBuild:
    def test_too_few_branches_zero_raises(self) -> None:
        with pytest.raises(ValueError, match="최소 2개"):
            FanOut([])

    def test_too_few_branches_one_raises(self) -> None:
        with pytest.raises(ValueError, match="최소 2개"):
            FanOut([_BlockA()])

    def test_input_model_mismatch_raises(self) -> None:
        with pytest.raises(IncompatibleSnapError):
            FanOut([_BlockA(), _WrongInput()])

    def test_sets_input_model_from_branches(self) -> None:
        fan = FanOut([_BlockA(), _BlockB()])
        assert fan.input_model is _In

    def test_output_model_is_gathered(self) -> None:
        fan = FanOut([_BlockA(), _BlockB()])
        assert fan.output_model is Gathered

    def test_fanout_is_block(self) -> None:
        fan = FanOut([_BlockA(), _BlockB()])
        assert isinstance(fan, Block)

    def test_custom_name(self) -> None:
        fan = FanOut([_BlockA(), _BlockB()], name="my_fan")
        assert fan.name == "my_fan"


class TestFanOutRun:
    async def test_gather_runs_all_branches(self) -> None:
        fan = FanOut([_BlockA(), _BlockB()])
        result = await fan.run(_In(val=1))
        assert isinstance(result, Gathered)
        assert len(result.results) == 2
        assert isinstance(result.results[0], _OutA)
        assert isinstance(result.results[1], _OutB)

    async def test_three_branches(self) -> None:
        fan = FanOut([_BlockA(), _BlockA(), _BlockA()])
        result = await fan.run(_In())
        assert len(result.results) == 3

    async def test_concurrent_execution(self) -> None:
        import time

        fan = FanOut([_SlowA(), _BlockA()])
        start = time.monotonic()
        result = await fan.run(_In())
        elapsed = time.monotonic() - start
        assert isinstance(result, Gathered)
        assert elapsed < 0.1  # 동시 실행 시 ~0.05s, 순차라면 ~0.10s+

    async def test_results_order_preserved(self) -> None:
        seen: list[int] = []

        class _Ordered(Block[_In, _OutA]):
            input_model = _In
            output_model = _OutA

            def __init__(self, idx: int) -> None:
                self._idx = idx

            async def run(self, inp: _In) -> _OutA:
                seen.append(self._idx)
                return _OutA()

        fan = FanOut([_Ordered(0), _Ordered(1), _Ordered(2)])
        result = await fan.run(_In())
        assert len(result.results) == 3
