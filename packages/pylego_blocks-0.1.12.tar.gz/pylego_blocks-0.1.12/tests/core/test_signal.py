"""SignalScore / SignalAggregator 테스트."""

from __future__ import annotations

import asyncio

import pytest

from pylego_blocks import SignalAggregator, SignalScore, TapBlock
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


# ── SignalScore ──────────────────────────────────────────────────────────────

def test_signal_score_defaults() -> None:
    s = SignalScore(score=0.5)
    assert s.score == 0.5
    assert s.reason == ""
    assert s.block_name == ""


def test_signal_score_full() -> None:
    s = SignalScore(score=0.9, reason="형식 불량", block_name="FormatBlock")
    assert s.reason == "형식 불량"
    assert s.block_name == "FormatBlock"


def test_signal_score_is_frozen() -> None:
    s = SignalScore(score=0.5)
    with pytest.raises(Exception):
        s.score = 0.9  # type: ignore[misc]


def test_signal_score_rejects_extra_fields() -> None:
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        SignalScore(score=0.5, unknown_field=1)  # type: ignore[call-arg]


# ── SignalAggregator 기본 동작 ────────────────────────────────────────────────

def test_aggregator_empty_not_suspicious() -> None:
    agg = SignalAggregator(threshold=0.5)
    assert agg.is_suspicious is False


def test_aggregator_single_score_above_threshold() -> None:
    agg = SignalAggregator(threshold=0.5)
    agg.record(SignalScore(score=0.8))
    assert agg.is_suspicious is True


def test_aggregator_single_score_at_threshold_not_suspicious() -> None:
    agg = SignalAggregator(threshold=0.5)
    agg.record(SignalScore(score=0.5))
    assert agg.is_suspicious is False


def test_aggregator_single_score_below_threshold() -> None:
    agg = SignalAggregator(threshold=0.5)
    agg.record(SignalScore(score=0.3))
    assert agg.is_suspicious is False


def test_aggregator_scores_returns_copy() -> None:
    agg = SignalAggregator()
    s = SignalScore(score=0.5)
    agg.record(s)
    copy = agg.scores
    assert copy == [s]
    copy.clear()
    assert len(agg.scores) == 1  # 원본 영향 없음


def test_aggregator_reset() -> None:
    agg = SignalAggregator(threshold=0.5)
    agg.record(SignalScore(score=0.9))
    assert agg.is_suspicious is True
    agg.reset()
    assert agg.is_suspicious is False
    assert agg.scores == []


def test_aggregator_invalid_threshold() -> None:
    with pytest.raises(ValueError, match="0.0 ~ 1.0"):
        SignalAggregator(threshold=1.5)
    with pytest.raises(ValueError, match="0.0 ~ 1.0"):
        SignalAggregator(threshold=-0.1)


# ── 전략: max ────────────────────────────────────────────────────────────────

def test_strategy_max_uses_highest_score() -> None:
    agg = SignalAggregator(threshold=0.7, strategy="max")
    agg.record(SignalScore(score=0.3))
    agg.record(SignalScore(score=0.9))  # 최고값
    assert agg.is_suspicious is True


def test_strategy_max_all_below_threshold() -> None:
    agg = SignalAggregator(threshold=0.7, strategy="max")
    agg.record(SignalScore(score=0.2))
    agg.record(SignalScore(score=0.5))
    assert agg.is_suspicious is False


# ── 전략: mean ───────────────────────────────────────────────────────────────

def test_strategy_mean_above_threshold() -> None:
    agg = SignalAggregator(threshold=0.5, strategy="mean")
    agg.record(SignalScore(score=0.8))
    agg.record(SignalScore(score=0.4))
    # mean = 0.6 > 0.5
    assert agg.is_suspicious is True


def test_strategy_mean_below_threshold() -> None:
    agg = SignalAggregator(threshold=0.5, strategy="mean")
    agg.record(SignalScore(score=0.8))
    agg.record(SignalScore(score=0.1))
    # mean = 0.45 <= 0.5
    assert agg.is_suspicious is False


def test_strategy_mean_dilutes_single_high_score() -> None:
    agg = SignalAggregator(threshold=0.7, strategy="mean")
    agg.record(SignalScore(score=0.9))
    agg.record(SignalScore(score=0.1))
    agg.record(SignalScore(score=0.1))
    # mean ≈ 0.367 < 0.7
    assert agg.is_suspicious is False


# ── 전략: any ────────────────────────────────────────────────────────────────

def test_strategy_any_triggers_on_first_over_threshold() -> None:
    agg = SignalAggregator(threshold=0.7, strategy="any")
    agg.record(SignalScore(score=0.3))
    agg.record(SignalScore(score=0.8))
    assert agg.is_suspicious is True


def test_strategy_any_all_at_or_below_threshold() -> None:
    agg = SignalAggregator(threshold=0.7, strategy="any")
    agg.record(SignalScore(score=0.5))
    agg.record(SignalScore(score=0.7))
    assert agg.is_suspicious is False


# ── 기본값 확인 ───────────────────────────────────────────────────────────────

def test_aggregator_default_threshold_and_strategy() -> None:
    agg = SignalAggregator()
    assert agg.threshold == 0.7
    assert agg.strategy == "max"


# ── TapBlock 통합 — Block 래퍼 패턴 ─────────────────────────────────────────

class _Payload(Stud):
    text: str


class _SignalBlock(Block[_Payload, SignalScore]):
    """텍스트 길이에 따라 SignalScore 를 반환하고 aggregator 에 기록하는 블록."""

    input_model = _Payload
    output_model = SignalScore

    def __init__(self, aggregator: SignalAggregator) -> None:
        self._agg = aggregator

    async def run(self, inp: _Payload) -> SignalScore:
        score = min(len(inp.text) / 100.0, 1.0)
        sig = SignalScore(score=score, block_name="SignalBlock")
        self._agg.record(sig)
        return sig


def test_signal_block_records_to_aggregator() -> None:
    agg = SignalAggregator(threshold=0.5)
    block = _SignalBlock(agg)
    asyncio.run(block.run(_Payload(text="x" * 80)))
    assert len(agg.scores) == 1
    assert agg.scores[0].score == pytest.approx(0.8)
    assert agg.is_suspicious is True


# ── 공개 API 노출 ────────────────────────────────────────────────────────────

def test_importable_from_pylego() -> None:
    from pylego_blocks import AggregationStrategy, SignalAggregator as SA, SignalScore as SS  # noqa: PLC0415
    assert SA is SignalAggregator
    assert SS is SignalScore
    _ = AggregationStrategy  # 타입 별칭 노출 확인
