"""Block 베이스 동작 검증."""

from __future__ import annotations

import types

import pytest

from pylego_blocks.core import Block, Stud


class _In(Stud):
    value: str


class _Out(Stud):
    value: str


class _Upper(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(value=inp.value.upper())


class TestBlockSubclass:
    def test_name_defaults_to_class_name(self) -> None:
        assert _Upper.name == "_Upper"

    def test_describe_returns_contract_summary(self) -> None:
        assert _Upper.describe() == "_Upper: _In → _Out"

    def test_explicit_name_preserved(self) -> None:
        class Named(Block[_In, _Out]):
            name = "custom"
            input_model = _In
            output_model = _Out

            async def run(self, inp: _In) -> _Out:
                return _Out(value=inp.value)

        assert Named.name == "custom"
        assert Named.describe() == "custom: _In → _Out"

    def test_missing_input_model_raises(self) -> None:
        with pytest.raises(TypeError, match="input_model"):

            class _Bad(Block[_In, _Out]):
                output_model = _Out

                async def run(self, inp: _In) -> _Out:  # pragma: no cover
                    return _Out(value="")

    def test_non_stud_input_model_raises(self) -> None:
        async def run(self: Block[_In, _Out], inp: _In) -> _Out:
            return _Out(value="")

        def body(namespace: dict[str, object]) -> None:
            namespace["input_model"] = str
            namespace["output_model"] = _Out
            namespace["run"] = run

        with pytest.raises(TypeError, match="Stud 서브클래스"):
            types.new_class("_Bad", (Block[_In, _Out],), exec_body=body)


class TestBlockRun:
    async def test_run_produces_output_model(self) -> None:
        result = await _Upper().run(_In(value="hello"))
        assert isinstance(result, _Out)
        assert result.value == "HELLO"

    def test_stud_is_frozen(self) -> None:
        from pydantic import ValidationError

        s = _In(value="x")
        with pytest.raises(ValidationError, match="frozen"):
            s.value = "y"  # type: ignore[misc]

    def test_stud_forbids_extra(self) -> None:
        from pydantic import ValidationError

        with pytest.raises(ValidationError, match="Extra inputs are not permitted"):
            _In(value="x", extra=1)  # type: ignore[call-arg]
