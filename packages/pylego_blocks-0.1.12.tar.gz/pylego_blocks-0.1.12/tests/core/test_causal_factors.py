"""M109 — Multi-factor Causality 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks.core.graph import (
    CausalFactor,
    EnvironmentContext,
    HealthDiff,
    PipelineHealth,
    VersionContext,
)
from pylego_blocks.core.events import BlockFailedEvent


# ── EnvironmentContext ────────────────────────────────────────────────────────


def test_environment_context_defaults() -> None:
    ec = EnvironmentContext()
    assert ec.infra_changes == []
    assert ec.metric_snapshot == {}
    assert ec.external_changes == []
    assert ec.baseline_metrics == {}


def test_environment_context_fields() -> None:
    ec = EnvironmentContext(
        infra_changes=["Redis 7.2 → 8.0 업그레이드"],
        metric_snapshot={"p99_latency_ms": 420.0},
        external_changes=["OpenAI API v2 전환"],
        baseline_metrics={"p99_latency_ms": 120.0},
    )
    assert ec.infra_changes == ["Redis 7.2 → 8.0 업그레이드"]
    assert ec.metric_snapshot["p99_latency_ms"] == 420.0
    assert ec.external_changes == ["OpenAI API v2 전환"]
    assert ec.baseline_metrics["p99_latency_ms"] == 120.0


# ── EnvironmentContext.metric_anomalies ───────────────────────────────────────


def test_metric_anomalies_detects_spike() -> None:
    """p99_latency 3배 이상 급등 → 이상 감지."""
    ec = EnvironmentContext(
        metric_snapshot={"p99_latency_ms": 420.0},
        baseline_metrics={"p99_latency_ms": 120.0},  # 3.5× 급등
    )
    anomalies = ec.metric_anomalies()
    assert "p99_latency_ms" in anomalies
    assert anomalies["p99_latency_ms"] == (120.0, 420.0)


def test_metric_anomalies_detects_drop() -> None:
    """error_rate 1/3 이하 급감 → 이상 감지 (baseline보다 낮은 방향)."""
    ec = EnvironmentContext(
        metric_snapshot={"error_rate": 0.01},
        baseline_metrics={"error_rate": 0.05},  # 0.2× 급감 (< 1/1.5)
    )
    anomalies = ec.metric_anomalies()
    assert "error_rate" in anomalies


def test_metric_anomalies_no_anomaly_within_threshold() -> None:
    """threshold_ratio=1.5 미만 변화 → 이상 없음."""
    ec = EnvironmentContext(
        metric_snapshot={"latency": 130.0},
        baseline_metrics={"latency": 100.0},  # 1.3×
    )
    anomalies = ec.metric_anomalies()
    assert "latency" not in anomalies


def test_metric_anomalies_skips_missing_current() -> None:
    """baseline 에는 있지만 snapshot 에 없는 지표는 건너뛴다."""
    ec = EnvironmentContext(
        metric_snapshot={},
        baseline_metrics={"latency": 100.0},
    )
    anomalies = ec.metric_anomalies()
    assert anomalies == {}


def test_metric_anomalies_skips_zero_baseline() -> None:
    """baseline == 0.0 인 경우 ZeroDivisionError 없이 건너뛴다."""
    ec = EnvironmentContext(
        metric_snapshot={"counter": 10.0},
        baseline_metrics={"counter": 0.0},
    )
    anomalies = ec.metric_anomalies()
    assert anomalies == {}


def test_metric_anomalies_custom_threshold() -> None:
    """사용자 정의 threshold_ratio 적용."""
    ec = EnvironmentContext(
        metric_snapshot={"cpu": 60.0},
        baseline_metrics={"cpu": 50.0},  # 1.2× — 기본 threshold=1.5 미만
    )
    assert "cpu" not in ec.metric_anomalies()  # 기본 threshold
    assert "cpu" in ec.metric_anomalies(threshold_ratio=1.1)  # 낮은 threshold


# ── VersionContext.env_context ────────────────────────────────────────────────


def test_version_context_env_context_default() -> None:
    vc = VersionContext(version="1.0.0")
    assert vc.env_context is None


def test_version_context_with_env_context() -> None:
    ec = EnvironmentContext(infra_changes=["DB 마이그레이션"])
    vc = VersionContext(version="2.0.0", env_context=ec)
    assert vc.env_context is ec


# ── CausalFactor ─────────────────────────────────────────────────────────────


def test_causal_factor_code_source() -> None:
    cf = CausalFactor(source="code", name="BlockA", confidence_score=0.7)
    assert cf.source == "code"
    assert cf.name == "BlockA"
    assert cf.confidence_score == 0.7


def test_causal_factor_env_source() -> None:
    cf = CausalFactor(source="env", name="Redis upgrade", confidence_score=0.5)
    assert cf.source == "env"


def test_causal_factor_metric_source() -> None:
    cf = CausalFactor(source="metric", name="p99_latency_ms", confidence_score=0.6)
    assert cf.source == "metric"


# ── HealthDiff.causal_factors ─────────────────────────────────────────────────


def _h(
    overall: str = "ok",
    error_blocks: list[str] | None = None,
    version_context: VersionContext | None = None,
) -> PipelineHealth:
    eb = error_blocks or []
    return PipelineHealth(
        overall=overall,  # type: ignore[arg-type]
        total_blocks=max(len(eb), 1),
        error_blocks=eb,
        slowest_block=None,
        slowest_elapsed_sec=None,
        avg_elapsed_sec=None,
        version_context=version_context,
    )


def test_causal_factors_empty_when_no_version_context() -> None:
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"])
    diff = curr.diff(prev)
    assert diff.causal_factors == []


def test_causal_factors_code_source() -> None:
    """changed_blocks ∩ error_blocks → code factor."""
    vc = VersionContext(version="2.0.0", changed_blocks=["BlockA", "BlockB"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)

    code_factors = [f for f in diff.causal_factors if f.source == "code"]
    assert len(code_factors) == 1
    assert code_factors[0].name == "BlockA"
    assert code_factors[0].confidence_score == pytest.approx(0.7)
    assert "2.0.0" in code_factors[0].description


def test_causal_factors_no_code_when_no_overlap() -> None:
    """changed_blocks 와 error_blocks 교집합 없으면 code factor 없음."""
    vc = VersionContext(version="2.0.0", changed_blocks=["BlockC"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)

    code_factors = [f for f in diff.causal_factors if f.source == "code"]
    assert code_factors == []


def test_causal_factors_env_source() -> None:
    """infra_changes → env factor."""
    ec = EnvironmentContext(infra_changes=["Redis 7 → 8", "K8s 노드 재시작"])
    vc = VersionContext(version="3.0.0", env_context=ec)
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)

    env_factors = [f for f in diff.causal_factors if f.source == "env"]
    assert len(env_factors) == 2
    names = [f.name for f in env_factors]
    assert "Redis 7 → 8" in names
    assert "K8s 노드 재시작" in names
    assert all(f.confidence_score == pytest.approx(0.5) for f in env_factors)


def test_causal_factors_external_changes() -> None:
    """external_changes → env factor."""
    ec = EnvironmentContext(external_changes=["OpenAI API v2 전환"])
    vc = VersionContext(version="3.0.0", env_context=ec)
    prev = _h()
    curr = _h(overall="critical", error_blocks=["X"], version_context=vc)
    diff = curr.diff(prev)

    env_factors = [f for f in diff.causal_factors if f.source == "env"]
    assert any(f.name == "OpenAI API v2 전환" for f in env_factors)


def test_causal_factors_metric_source() -> None:
    """metric anomaly → metric factor."""
    ec = EnvironmentContext(
        metric_snapshot={"p99_latency_ms": 600.0},
        baseline_metrics={"p99_latency_ms": 120.0},  # 5× 급등
    )
    vc = VersionContext(version="3.0.0", env_context=ec)
    prev = _h()
    curr = _h(overall="critical", error_blocks=["X"], version_context=vc)
    diff = curr.diff(prev)

    metric_factors = [f for f in diff.causal_factors if f.source == "metric"]
    assert len(metric_factors) == 1
    assert metric_factors[0].name == "p99_latency_ms"
    assert metric_factors[0].confidence_score == pytest.approx(0.6)
    assert "120.00" in metric_factors[0].description
    assert "600.00" in metric_factors[0].description


def test_causal_factors_sorted_by_confidence() -> None:
    """causal_factors 는 confidence_score 내림차순이다."""
    ec = EnvironmentContext(
        infra_changes=["Redis upgrade"],  # conf=0.5
        metric_snapshot={"latency": 600.0},
        baseline_metrics={"latency": 100.0},  # conf=0.6
    )
    vc = VersionContext(
        version="4.0.0",
        changed_blocks=["BlockA"],  # conf=0.7
        env_context=ec,
    )
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)

    scores = [f.confidence_score for f in diff.causal_factors]
    assert scores == sorted(scores, reverse=True)
    assert scores[0] == pytest.approx(0.7)  # code 요인이 최상위


def test_causal_factors_multiple_code_factors() -> None:
    """여러 changed_blocks 가 error_blocks 와 교집합이면 모두 code factor."""
    vc = VersionContext(version="5.0.0", changed_blocks=["BlockA", "BlockB", "BlockC"])
    prev = _h()
    curr = _h(
        overall="critical",
        error_blocks=["BlockA", "BlockB"],
        version_context=vc,
    )
    diff = curr.diff(prev)

    code_factors = [f for f in diff.causal_factors if f.source == "code"]
    assert len(code_factors) == 2
    names = {f.name for f in code_factors}
    assert names == {"BlockA", "BlockB"}


# ── to_ai_summary 다요인 출력 ─────────────────────────────────────────────────


def test_to_ai_summary_multi_factor_hint() -> None:
    """diff.causal_factors 가 있으면 다요인 목록이 출력된다."""
    ec = EnvironmentContext(
        infra_changes=["Redis upgrade"],
        metric_snapshot={"p99": 500.0},
        baseline_metrics={"p99": 100.0},
    )
    vc = VersionContext(
        version="3.0.0",
        changed_blocks=["BlockA"],
        env_context=ec,
    )
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)

    assert "[인과 후보 목록]" in summary
    assert "[code/" in summary
    assert "BlockA" in summary
    assert "[env/" in summary
    assert "[metric/" in summary


def test_to_ai_summary_anti_bias_disclaimer() -> None:
    """'Side Effect도 확인' 확증 편향 방지 문구가 포함된다."""
    vc = VersionContext(version="3.0.0", changed_blocks=["BlockA"])
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)
    summary = curr.to_ai_summary(diff=diff)

    assert "Side Effect" in summary


def test_to_ai_summary_no_causal_section_without_diff() -> None:
    """diff 없을 때는 인과 후보 목록 섹션이 없다."""
    vc = VersionContext(version="3.0.0", changed_blocks=["BlockA"])
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    summary = curr.to_ai_summary()

    assert "[인과 후보 목록]" not in summary
    # 대신 기존 단일 힌트 (신중한 표현)
    assert "후보 원인 중 하나" in summary or "3.0.0" in summary


def test_to_ai_summary_no_causal_when_no_factors() -> None:
    """causal_factors 가 비어 있으면 인과 후보 섹션이 없다."""
    vc = VersionContext(version="3.0.0", changed_blocks=["BlockC"])  # 교집합 없음
    prev = _h()
    curr = _h(overall="critical", error_blocks=["BlockA"], version_context=vc)
    diff = curr.diff(prev)
    # causal_factors 비어 있음 (BlockC ∉ error_blocks)
    assert diff.causal_factors == []
    summary = curr.to_ai_summary(diff=diff)
    assert "[인과 후보 목록]" not in summary


def test_to_ai_summary_version_shown() -> None:
    """version_context 가 있으면 배포 버전이 summary 에 포함된다."""
    vc = VersionContext(version="5.0.0", notes="중요 변경")
    curr = _h(overall="ok", version_context=vc)
    summary = curr.to_ai_summary()
    assert "5.0.0" in summary
    assert "중요 변경" in summary
