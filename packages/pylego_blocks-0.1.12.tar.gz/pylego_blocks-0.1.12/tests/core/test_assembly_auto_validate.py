"""M101 — Assembly auto_validate=True (Stud-level 자동 검증) 테스트."""

from __future__ import annotations

import pytest
from pydantic import model_validator

from pylego_blocks import Assembly, Block, Stud
from pylego_blocks.core.compat import AssemblyValidator, SemanticCompatibilityError


# ── 검증기가 있는 Stud ────────────────────────────────────────────────────────


class _ValidatedIn(Stud):
    query: str
    max_rows: int = 100

    @model_validator(mode="after")
    def query_not_empty(self) -> "_ValidatedIn":
        if not self.query.strip():
            raise ValueError("query 가 비어 있습니다")
        return self

    @model_validator(mode="after")
    def max_rows_positive(self) -> "_ValidatedIn":
        if self.max_rows <= 0:
            raise ValueError("max_rows 는 양수여야 합니다")
        return self


class _Out(Stud):
    result: str


class _MyBlock(Block[_ValidatedIn, _Out]):
    input_model = _ValidatedIn
    output_model = _Out

    async def run(self, inp: _ValidatedIn) -> _Out:
        return _Out(result=inp.query)


# ── 검증기 없는 Stud ──────────────────────────────────────────────────────────


class _PlainIn(Stud):
    v: int


class _PlainBlock(Block[_PlainIn, _Out]):
    input_model = _PlainIn
    output_model = _Out

    async def run(self, inp: _PlainIn) -> _Out:
        return _Out(result=str(inp.v))


# ── 기본 동작: auto_validate=False ───────────────────────────────────────────


async def test_auto_validate_false_default_valid_input() -> None:
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly([_MyBlock()])
    result = await pipeline.run(_ValidatedIn(query="hello"))
    assert result.result == "hello"


async def test_auto_validate_false_bypassed_invalid_passes() -> None:
    """auto_validate=False이면 model_construct로 만든 잘못된 입력이 통과된다."""
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly([_MyBlock()])
    bad = _ValidatedIn.model_construct(query="", max_rows=100)
    # auto_validate=False이면 검증 없이 실행
    result = await pipeline.run(bad)
    assert result.result == ""


# ── auto_validate=True — 정상 입력 ───────────────────────────────────────────


async def test_auto_validate_true_valid_input() -> None:
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly([_MyBlock()], auto_validate=True)
    result = await pipeline.run(_ValidatedIn(query="hello"))
    assert result.result == "hello"


# ── auto_validate=True — model_construct 우회 입력 검출 ──────────────────────


async def test_auto_validate_true_catches_empty_query() -> None:
    """auto_validate=True이면 model_construct로 우회한 빈 query를 SemanticCompatibilityError로 잡는다."""
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly([_MyBlock()], auto_validate=True)
    bad = _ValidatedIn.model_construct(query="", max_rows=100)
    with pytest.raises(SemanticCompatibilityError) as exc_info:
        await pipeline.run(bad)
    assert exc_info.value.position == 0
    assert "비어" in exc_info.value.reason


async def test_auto_validate_true_catches_invalid_max_rows() -> None:
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly([_MyBlock()], auto_validate=True)
    bad = _ValidatedIn.model_construct(query="ok", max_rows=-1)
    with pytest.raises(SemanticCompatibilityError) as exc_info:
        await pipeline.run(bad)
    assert exc_info.value.position == 0
    assert "양수" in exc_info.value.reason


# ── auto_validate=True + 명시적 validator 병합 ───────────────────────────────


async def test_auto_validate_merges_with_explicit_validator() -> None:
    """명시적 validator가 auto_validate 검증기보다 우선한다."""
    explicit_called: list[int] = []

    def explicit_check(inp: _ValidatedIn) -> None:
        explicit_called.append(1)
        if inp.query == "forbidden":
            raise ValueError("명시적 금지 쿼리")

    explicit_v = AssemblyValidator({0: explicit_check})
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly(
        [_MyBlock()], validator=explicit_v, auto_validate=True
    )

    # 명시적 검증기가 호출됨
    await pipeline.run(_ValidatedIn(query="hello"))
    assert len(explicit_called) == 1

    # 명시적 검증기도 적용됨
    with pytest.raises(SemanticCompatibilityError) as exc_info:
        await pipeline.run(_ValidatedIn(query="forbidden"))
    assert "명시적" in exc_info.value.reason


async def test_auto_validate_merge_explicit_overrides_position() -> None:
    """동일 위치에서 명시적 validator가 auto_validate보다 우선."""
    auto_would_fail = _ValidatedIn.model_construct(query="", max_rows=100)

    # 명시적 validator는 위치 0을 무조건 통과
    noop_v = AssemblyValidator({0: lambda inp: None})
    pipeline: Assembly[_ValidatedIn, _Out] = Assembly(
        [_MyBlock()], validator=noop_v, auto_validate=True
    )
    # 명시적 noop이 auto 검증을 덮어쓰므로 통과
    result = await pipeline.run(auto_would_fail)
    assert result.result == ""


# ── 검증기 없는 Stud에 auto_validate ─────────────────────────────────────────


async def test_auto_validate_plain_stud_no_error() -> None:
    """model_validator 없는 Stud에 auto_validate=True 적용 시 정상 동작."""
    pipeline: Assembly[_PlainIn, _Out] = Assembly([_PlainBlock()], auto_validate=True)
    result = await pipeline.run(_PlainIn(v=42))
    assert result.result == "42"


# ── AssemblyValidator.merge ───────────────────────────────────────────────────


def test_merge_self_overrides_other() -> None:
    self_called: list[str] = []
    other_called: list[str] = []

    self_v = AssemblyValidator({0: lambda inp: self_called.append("self")})
    other_v = AssemblyValidator({0: lambda inp: other_called.append("other"), 1: lambda inp: None})

    merged = self_v.merge(other_v)
    merged.validate(0, _PlainIn(v=1))

    assert self_called == ["self"]
    assert other_called == []  # 0번 위치는 self로 덮어씀
    assert 1 in merged.positions  # 1번은 other에서 상속


def test_merge_preserves_non_overlapping() -> None:
    v1 = AssemblyValidator({0: lambda inp: None})
    v2 = AssemblyValidator({1: lambda inp: None, 2: lambda inp: None})
    merged = v1.merge(v2)
    assert merged.positions == frozenset({0, 1, 2})
