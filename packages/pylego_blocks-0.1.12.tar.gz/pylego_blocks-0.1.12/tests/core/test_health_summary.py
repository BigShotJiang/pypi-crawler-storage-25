"""build_health_summary() + PipelineHealth 테스트 (M61 / M90)."""

from __future__ import annotations

import json

from pylego_blocks.core.events import BlockCompletedEvent, BlockFailedEvent, CollectingEventBus
from pylego_blocks.core.graph import PipelineHealth, build_health_summary


def _ok(name: str, elapsed: float = 0.1) -> BlockCompletedEvent:
    return BlockCompletedEvent(block_name=name, output=None, elapsed_sec=elapsed)


def _err(name: str, elapsed: float = 0.2) -> BlockFailedEvent:
    return BlockFailedEvent(block_name=name, elapsed_sec=elapsed, error=RuntimeError("fail"))


def test_all_ok() -> None:
    events = [_ok("A"), _ok("B"), _ok("C")]
    h = build_health_summary(events)
    assert h.overall == "ok"
    assert h.error_blocks == []
    assert h.total_blocks == 3


def test_some_errors_degraded() -> None:
    events = [_ok("A"), _ok("B"), _err("C")]
    h = build_health_summary(events)
    assert h.overall == "degraded"
    assert "C" in h.error_blocks


def test_majority_errors_critical() -> None:
    events = [_err("A"), _err("B"), _ok("C")]
    h = build_health_summary(events)
    assert h.overall == "critical"
    assert len(h.error_blocks) == 2


def test_slowest_block() -> None:
    events = [_ok("A", 0.1), _ok("B", 0.5), _ok("C", 0.3)]
    h = build_health_summary(events)
    assert h.slowest_block == "B"
    assert h.slowest_elapsed_sec == 0.5


def test_avg_elapsed() -> None:
    events = [_ok("A", 0.1), _ok("B", 0.3)]
    h = build_health_summary(events)
    assert h.avg_elapsed_sec is not None
    assert abs(h.avg_elapsed_sec - 0.2) < 1e-9


def test_empty_events() -> None:
    h = build_health_summary([])
    assert h.overall == "ok"
    assert h.total_blocks == 0
    assert h.slowest_block is None


def test_health_badge_in_html() -> None:
    """to_html에 health 뱃지가 포함된다."""
    from pylego_blocks.core.block import Block
    from pylego_blocks.core.stud import Stud
    from pylego_blocks.core.graph import to_html

    class _In(Stud):
        v: int

    class _Out(Stud):
        v: int

    class _B(Block[_In, _Out]):
        input_model = _In
        output_model = _Out
        async def run(self, inp: _In) -> _Out:
            return _Out(v=inp.v)

    h = PipelineHealth(
        overall="degraded",
        total_blocks=2,
        error_blocks=["X"],
        slowest_block="Y",
        slowest_elapsed_sec=0.5,
        avg_elapsed_sec=0.3,
    )
    html = to_html(_B(), health=h)
    assert "health-degraded" in html
    assert "degraded" in html


# ── M90: to_ai_summary / to_dict ─────────────────────────────────────────────

def _bus_with(*events: BlockCompletedEvent | BlockFailedEvent) -> CollectingEventBus:
    bus = CollectingEventBus()
    for e in events:
        bus._events.append(e)  # type: ignore[attr-defined]
    return bus


def test_to_ai_summary_ok() -> None:
    h = build_health_summary([_ok("A"), _ok("B")])
    s = h.to_ai_summary()
    assert "정상" in s
    assert "권장 조치: 없음" in s
    assert "실패 블록" not in s


def test_to_ai_summary_degraded_recommendation() -> None:
    bus = _bus_with(_ok("A"), _ok("B"), _err("C"))
    h = build_health_summary(bus.events, bus=bus)
    assert h.overall == "degraded"
    s = h.to_ai_summary()
    assert "부분 장애" in s
    assert ("FallbackBlock" in s or "RetryBlock" in s)


def test_to_ai_summary_critical_recommendation() -> None:
    bus = _bus_with(_err("A"), _err("B"), _ok("C"))
    h = build_health_summary(bus.events, bus=bus)
    assert h.overall == "critical"
    s = h.to_ai_summary()
    assert "위험" in s
    assert ("TimeoutBlock" in s or "FallbackBlock" in s)


def test_to_ai_summary_caused_by() -> None:
    root = BlockFailedEvent(
        block_name="RootBlock", error=RuntimeError("root"),
        elapsed_sec=0.1, timestamp=0.0,
    )
    wrapper = BlockFailedEvent(
        block_name="WrapperBlock", error=RuntimeError("wrapped"),
        elapsed_sec=2.0, timestamp=0.1,
        caused_by=root,
    )
    bus = _bus_with(root, wrapper)
    h = build_health_summary(bus.events, bus=bus)
    s = h.to_ai_summary()
    assert "RootBlock" in s or "caused_by" in s


def test_to_ai_summary_slowest_block() -> None:
    h = build_health_summary([_ok("A", 0.1), _ok("B", 1.5)])
    s = h.to_ai_summary()
    assert "B" in s
    assert "1.50s" in s


def test_to_ai_summary_sub_health() -> None:
    sub = PipelineHealth(
        overall="degraded", total_blocks=2, error_blocks=["SubX"],
        slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
    )
    h = PipelineHealth(
        overall="ok", total_blocks=1, error_blocks=[],
        slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
        sub_health={"worker": sub},
    )
    s = h.to_ai_summary()
    assert "서브 파이프라인" in s
    assert "worker" in s
    assert "부분 장애" in s


def test_to_dict_json_serializable() -> None:
    h = build_health_summary([_ok("A"), _ok("B")])
    d = h.to_dict()
    dumped = json.dumps(d)
    assert "ok" in dumped


def test_to_dict_required_keys() -> None:
    h = build_health_summary([_ok("A")])
    d = h.to_dict()
    for key in ("overall", "total_blocks", "error_blocks", "slowest_block",
                "slowest_elapsed_sec", "avg_elapsed_sec", "error_details", "sub_health"):
        assert key in d


def test_to_dict_error_details_none_without_bus() -> None:
    h = build_health_summary([_err("A")])
    d = h.to_dict()
    assert d["error_details"] is None


def test_to_dict_error_details_with_bus() -> None:
    bus = _bus_with(_err("A"), _err("B"))
    h = build_health_summary(bus.events, bus=bus)
    d = h.to_dict()
    assert d["error_details"] is not None
    assert "A" in d["error_details"] or "B" in d["error_details"]


def test_to_dict_caused_by_serialized() -> None:
    root = BlockFailedEvent(
        block_name="Root", error=RuntimeError("root"),
        elapsed_sec=0.1, timestamp=0.0,
    )
    child = BlockFailedEvent(
        block_name="Child", error=RuntimeError("child"),
        elapsed_sec=0.2, timestamp=0.1, caused_by=root,
    )
    bus = _bus_with(root, child)
    h = build_health_summary(bus.events, bus=bus)
    d = h.to_dict()
    details = d["error_details"] or {}
    caused = [v.get("caused_by") for v in details.values()]
    assert any(v == "Root" for v in caused)


def test_to_dict_sub_health_nested() -> None:
    sub = PipelineHealth(
        overall="ok", total_blocks=1, error_blocks=[],
        slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
    )
    h = PipelineHealth(
        overall="ok", total_blocks=2, error_blocks=[],
        slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
        sub_health={"ns": sub},
    )
    d = h.to_dict()
    assert d["sub_health"] is not None
    assert d["sub_health"]["ns"]["overall"] == "ok"
    json.dumps(d)  # must not raise
