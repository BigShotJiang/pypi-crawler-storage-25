"""M8 관찰 가능성 — BlockEvent 시스템 테스트."""

from __future__ import annotations

import logging
from typing import Any

import pytest

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.events import (
    BlockCompletedEvent,
    BlockEvent,
    BlockFailedEvent,
    BlockStartedEvent,
    EventBus,
    LoggingEventBus,
    observe,
)
from pylego_blocks.core.stud import Stud


# ── 픽스처 블록 ──────────────────────────────────────────────────────────────


class _In(Stud):
    text: str


class _Mid(Stud):
    upper: str


class _Out(Stud):
    length: int


class _UpperBlock(Block[_In, _Mid]):
    input_model = _In
    output_model = _Mid

    async def run(self, inp: _In) -> _Mid:
        return _Mid(upper=inp.text.upper())


class _LenBlock(Block[_Mid, _Out]):
    input_model = _Mid
    output_model = _Out

    async def run(self, inp: _Mid) -> _Out:
        return _Out(length=len(inp.upper))


class _BombBlock(Block[_In, _Mid]):
    input_model = _In
    output_model = _Mid

    async def run(self, inp: _In) -> _Mid:
        raise RuntimeError("폭발!")


# ── 테스트용 버스 ─────────────────────────────────────────────────────────────


class _CollectorBus:
    def __init__(self) -> None:
        self.events: list[BlockEvent] = []

    def emit(self, event: BlockEvent) -> None:
        self.events.append(event)


# ── 테스트 ────────────────────────────────────────────────────────────────────


class TestObserveContextManager:
    def test_started_and_completed_emitted(self) -> None:
        bus = _CollectorBus()
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        with observe(bus):
            asm.run_sync(_In(text="hello"))

        names = [e.block_name for e in bus.events]
        assert names == ["_UpperBlock", "_UpperBlock", "_LenBlock", "_LenBlock"]
        types = [type(e) for e in bus.events]
        assert types == [
            BlockStartedEvent,
            BlockCompletedEvent,
            BlockStartedEvent,
            BlockCompletedEvent,
        ]

    def test_completed_has_elapsed(self) -> None:
        bus = _CollectorBus()
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        with observe(bus):
            asm.run_sync(_In(text="hi"))

        completed = [e for e in bus.events if isinstance(e, BlockCompletedEvent)]
        assert all(e.elapsed_sec >= 0 for e in completed)

    def test_failed_event_emitted_on_error(self) -> None:
        bus = _CollectorBus()
        asm: Assembly[_In, _Mid] = Assembly([_BombBlock()])
        with observe(bus), pytest.raises(RuntimeError, match="폭발"):
            asm.run_sync(_In(text="hi"))

        failed = [e for e in bus.events if isinstance(e, BlockFailedEvent)]
        assert len(failed) == 1
        assert failed[0].block_name == "_BombBlock"
        assert isinstance(failed[0].error, RuntimeError)

    def test_no_completed_after_failure(self) -> None:
        bus = _CollectorBus()
        asm: Assembly[_In, _Mid] = Assembly([_BombBlock()])
        with observe(bus), pytest.raises(RuntimeError):
            asm.run_sync(_In(text="hi"))

        assert not any(isinstance(e, BlockCompletedEvent) for e in bus.events)

    def test_no_events_without_observe(self) -> None:
        bus = _CollectorBus()
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        # observe() 없이 실행 — 이벤트 없어야 함
        asm.run_sync(_In(text="silent"))
        assert bus.events == []

    def test_nested_assembly_events_propagate(self) -> None:
        bus = _CollectorBus()
        inner: Assembly[_In, _Mid] = Assembly([_UpperBlock()])
        outer: Assembly[_In, _Out] = Assembly([inner, _LenBlock()])
        with observe(bus):
            outer.run_sync(_In(text="nested"))

        block_names = {e.block_name for e in bus.events}
        # inner Assembly 이름과 _LenBlock 이름 모두 포함
        assert "_LenBlock" in block_names

    def test_observe_restores_previous_bus(self) -> None:
        bus1 = _CollectorBus()
        bus2 = _CollectorBus()
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        with observe(bus1):
            with observe(bus2):
                asm.run_sync(_In(text="inner"))
            asm.run_sync(_In(text="outer"))

        assert len(bus2.events) == 4  # 2 blocks × (started + completed)
        assert len(bus1.events) == 4


class TestLoggingEventBus:
    def test_debug_logged_on_completed(self, caplog: pytest.LogCaptureFixture) -> None:
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        with caplog.at_level(logging.DEBUG, logger="pylego_blocks.events"):
            with observe(LoggingEventBus()):
                asm.run_sync(_In(text="log"))
        assert "block_completed" in caplog.text
        assert "block_started" in caplog.text

    def test_warning_logged_on_failure(self, caplog: pytest.LogCaptureFixture) -> None:
        asm: Assembly[_In, _Mid] = Assembly([_BombBlock()])
        with caplog.at_level(logging.WARNING, logger="pylego_blocks.events"):
            with observe(LoggingEventBus()), pytest.raises(RuntimeError):
                asm.run_sync(_In(text="boom"))
        assert "block_failed" in caplog.text

    def test_env_var_activates_logging_bus(
        self, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
    ) -> None:
        monkeypatch.setenv("PYLEGO_LOG_LEVEL", "DEBUG")
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        with caplog.at_level(logging.DEBUG, logger="pylego_blocks.events"):
            asm.run_sync(_In(text="env"))
        assert "block_completed" in caplog.text


class TestEventBusProtocol:
    def test_custom_bus_accepted(self) -> None:
        class _MyBus:
            called: list[Any] = []

            def emit(self, event: BlockEvent) -> None:
                self.called.append(event)

        bus = _MyBus()
        asm: Assembly[_In, _Out] = Assembly([_UpperBlock(), _LenBlock()])
        with observe(bus):  # type: ignore[arg-type]
            asm.run_sync(_In(text="custom"))
        assert len(bus.called) == 4

    def test_event_bus_is_protocol(self) -> None:
        # EventBus 는 Protocol — 상속 없이도 satisfy 가능
        from pylego_blocks.core.events import EventBus as _EB

        assert hasattr(_EB, "emit")
