"""M15 Assembly fault injection 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.events import BlockFailedEvent, observe
from pylego_blocks.core.stud import Stud


# ── 픽스처 블록 ──────────────────────────────────────────────────────────────


class _A(Stud):
    value: int


class _B(Stud):
    value: int


class _C(Stud):
    value: int


class _DoubleBlock(Block[_A, _B]):
    input_model = _A
    output_model = _B

    async def run(self, inp: _A) -> _B:
        return _B(value=inp.value * 2)


class _AddOneBlock(Block[_B, _C]):
    input_model = _B
    output_model = _C

    async def run(self, inp: _B) -> _C:
        return _C(value=inp.value + 1)


class _CollectorBus:
    def __init__(self) -> None:
        self.events: list[object] = []

    def emit(self, event: object) -> None:
        self.events.append(event)


# ── fault_map 없으면 정상 실행 ─────────────────────────────────────────────


class TestAssemblyFaultInjection:
    def test_no_fault_map_runs_normally(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        result = asm.run_sync(_A(value=3))
        assert result.value == 7  # 3*2 + 1

    def test_fault_map_none_runs_normally(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        result = asm.run_sync(_A(value=5), fault_map=None)
        assert result.value == 11

    def test_fault_map_first_block_raises(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        err = ValueError("forced failure")
        with pytest.raises(ValueError, match="forced failure"):
            asm.run_sync(_A(value=1), fault_map={"_DoubleBlock": err})

    def test_fault_map_second_block_raises(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        err = RuntimeError("second block forced")
        with pytest.raises(RuntimeError, match="second block forced"):
            asm.run_sync(_A(value=1), fault_map={"_AddOneBlock": err})

    def test_fault_map_unknown_block_name_ignored(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        # 존재하지 않는 블록 이름이면 정상 실행
        result = asm.run_sync(_A(value=2), fault_map={"NonExistentBlock": ValueError("x")})
        assert result.value == 5  # 2*2 + 1

    @pytest.mark.asyncio
    async def test_fault_map_emits_block_failed_event(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        bus = _CollectorBus()
        err = ValueError("event test")
        with observe(bus):  # type: ignore[arg-type]
            with pytest.raises(ValueError):
                await asm.run(_A(value=1), fault_map={"_DoubleBlock": err})

        failed_events = [e for e in bus.events if isinstance(e, BlockFailedEvent)]
        assert len(failed_events) == 1
        assert failed_events[0].block_name == "_DoubleBlock"
        assert failed_events[0].error is err

    @pytest.mark.asyncio
    async def test_fault_map_raises_exact_exception_instance(self) -> None:
        """fault_map 에 넣은 예외 인스턴스가 그대로 raise 되어야 한다."""
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        err = TypeError("exact instance")
        with pytest.raises(TypeError) as exc_info:
            await asm.run(_A(value=1), fault_map={"_DoubleBlock": err})
        assert exc_info.value is err

    def test_fault_map_empty_dict_runs_normally(self) -> None:
        asm: Assembly[_A, _C] = Assembly([_DoubleBlock(), _AddOneBlock()])
        result = asm.run_sync(_A(value=4), fault_map={})
        assert result.value == 9  # 4*2 + 1
