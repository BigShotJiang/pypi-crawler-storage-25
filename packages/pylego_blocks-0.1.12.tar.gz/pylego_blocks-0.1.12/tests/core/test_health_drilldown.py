"""PipelineHealth 드릴다운 — events_for / failed_events / error_details 테스트 (M68)."""

from __future__ import annotations

import pytest

from pylego_blocks.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    CollectingEventBus,
)
from pylego_blocks.core.graph import build_health_summary


def _ok(name: str, elapsed: float = 0.1) -> BlockCompletedEvent:
    return BlockCompletedEvent(block_name=name, output=None, elapsed_sec=elapsed)


def _err(name: str, exc: Exception | None = None) -> BlockFailedEvent:
    return BlockFailedEvent(
        block_name=name,
        elapsed_sec=0.2,
        error=exc or RuntimeError(f"{name} failed"),
    )


# ── CollectingEventBus 필터 메서드 ────────────────────────────────────────────


def test_events_for_returns_only_named_block() -> None:
    bus = CollectingEventBus()
    bus.emit(_ok("A"))
    bus.emit(_ok("B"))
    bus.emit(_err("A"))
    result = bus.events_for("A")
    assert len(result) == 2
    assert all(e.block_name == "A" for e in result)


def test_failed_events_filter() -> None:
    bus = CollectingEventBus()
    bus.emit(_ok("A"))
    bus.emit(_err("B"))
    bus.emit(_err("C"))
    failed = bus.failed_events()
    assert len(failed) == 2
    assert {e.block_name for e in failed} == {"B", "C"}


def test_completed_events_filter() -> None:
    bus = CollectingEventBus()
    bus.emit(_ok("A"))
    bus.emit(_err("B"))
    bus.emit(_ok("C"))
    completed = bus.completed_events()
    assert len(completed) == 2
    assert {e.block_name for e in completed} == {"A", "C"}


def test_events_for_empty_when_no_match() -> None:
    bus = CollectingEventBus()
    bus.emit(_ok("A"))
    assert bus.events_for("Z") == []


# ── build_health_summary bus 파라미터 ─────────────────────────────────────────


def test_error_details_populated_when_bus_given() -> None:
    bus = CollectingEventBus()
    exc = ValueError("something broke")
    bus.emit(_ok("A"))
    bus.emit(_err("B", exc))

    health = build_health_summary(bus.events, bus=bus)
    assert health.error_details is not None
    assert "B" in health.error_details
    assert health.error_details["B"].error is exc


def test_error_details_none_when_no_bus() -> None:
    bus = CollectingEventBus()
    bus.emit(_err("A"))
    health = build_health_summary(bus.events)
    assert health.error_details is None


def test_error_details_empty_dict_when_no_failures_and_bus_given() -> None:
    bus = CollectingEventBus()
    bus.emit(_ok("A"))
    bus.emit(_ok("B"))
    health = build_health_summary(bus.events, bus=bus)
    assert health.error_details == {}


# ── to_html 에러 툴팁 렌더링 ──────────────────────────────────────────────────


def test_to_html_includes_error_tooltip() -> None:
    from pylego_blocks.core.block import Block
    from pylego_blocks.core.graph import to_html
    from pylego_blocks.core.stud import Stud

    class _In(Stud):
        v: int

    class _Out(Stud):
        v: int

    class _B(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:
            return _Out(v=inp.v)

    bus = CollectingEventBus()
    exc = RuntimeError("DB connection refused")
    bus.emit(_err("_B", exc))

    health = build_health_summary(bus.events, bus=bus)
    html = to_html(_B(), health=health)
    assert "DB connection refused" in html
    assert 'title=' in html
