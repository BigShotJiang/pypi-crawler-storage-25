"""pylego inspect matrix tests."""

from __future__ import annotations

import json
from pathlib import Path
from textwrap import dedent

import pytest

from pylego_blocks.inspect.matrix import inspect_matrix


def test_matrix_empty_package_prints_friendly_message(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _write_package(tmp_path, "emptyblocks", "__init__.py", "")
    monkeypatch.syspath_prepend(str(tmp_path))

    assert inspect_matrix(root="emptyblocks") == 0

    assert capsys.readouterr().out.strip() == "no registered blocks"


def test_matrix_single_edge_renders_grid(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _write_package(
        tmp_path,
        "singleblocks",
        "__init__.py",
        dedent(
            """
            from pylego_blocks.core import Block, Stud


            class InA(Stud):
                value: str


            class Mid(Stud):
                value: str


            class OutB(Stud):
                value: str


            class SourceBlock(Block[InA, Mid]):
                input_model = InA
                output_model = Mid

                async def run(self, inp: InA) -> Mid:
                    return Mid(value=inp.value)


            class SinkBlock(Block[Mid, OutB]):
                input_model = Mid
                output_model = OutB

                async def run(self, inp: Mid) -> OutB:
                    return OutB(value=inp.value)
            """
        ).strip()
        + "\n",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    assert inspect_matrix(root="singleblocks") == 0

    output = capsys.readouterr().out
    assert "SourceBlock" in output
    assert "SinkBlock" in output
    assert output.count("✓") == 1
    assert "—" in output


def test_matrix_multi_edge_json(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _write_package(
        tmp_path,
        "multiblocks",
        "__init__.py",
        dedent(
            """
            from pylego_blocks.core import Block, Stud


            class InA(Stud):
                value: str


            class MidB(Stud):
                value: str


            class OutC(Stud):
                value: str


            class FirstBlock(Block[InA, MidB]):
                input_model = InA
                output_model = MidB

                async def run(self, inp: InA) -> MidB:
                    return MidB(value=inp.value)


            class SecondBlock(Block[MidB, OutC]):
                input_model = MidB
                output_model = OutC

                async def run(self, inp: MidB) -> OutC:
                    return OutC(value=inp.value)


            class ThirdBlock(Block[OutC, InA]):
                input_model = OutC
                output_model = InA

                async def run(self, inp: OutC) -> InA:
                    return InA(value=inp.value)
            """
        ).strip()
        + "\n",
    )
    monkeypatch.syspath_prepend(str(tmp_path))

    assert inspect_matrix(root="multiblocks", output_format="json") == 0

    payload = json.loads(capsys.readouterr().out)
    assert {item["name"] for item in payload["blocks"]} == {
        "FirstBlock",
        "SecondBlock",
        "ThirdBlock",
    }
    assert payload["edges"] == [
        ["multiblocks.FirstBlock", "multiblocks.SecondBlock"],
        ["multiblocks.SecondBlock", "multiblocks.ThirdBlock"],
        ["multiblocks.ThirdBlock", "multiblocks.FirstBlock"],
    ]


def _write_package(tmp_path: Path, package_name: str, filename: str, content: str) -> None:
    package = tmp_path / package_name
    package.mkdir()
    (package / filename).write_text(content, encoding="utf-8")
