"""RedisCacheBlock 단위 테스트 — redis.asyncio 를 sys.modules mock 으로 대체."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks import CacheInput, CacheResult, RedisCacheBlock


@pytest.fixture()
def mock_client() -> Any:
    """redis.asyncio.Redis 를 sys.modules mock 으로 교체 (lazy import 대응)."""
    client = AsyncMock()
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=client)
    ctx.__aexit__ = AsyncMock(return_value=None)

    redis_asyncio = MagicMock()
    redis_asyncio.Redis.from_url.return_value = ctx

    redis_mod = MagicMock()
    redis_mod.asyncio = redis_asyncio

    with patch.dict("sys.modules", {"redis": redis_mod, "redis.asyncio": redis_asyncio}):
        yield client


async def test_get_hit(mock_client: Any) -> None:
    mock_client.get = AsyncMock(return_value=b"hello")
    result = await RedisCacheBlock(url="redis://localhost:6379").run(
        CacheInput(operation="get", key="foo")
    )
    assert isinstance(result, CacheResult)
    assert result.value == "hello"
    assert result.hit is True
    assert result.ok is True


async def test_get_miss(mock_client: Any) -> None:
    mock_client.get = AsyncMock(return_value=None)
    result = await RedisCacheBlock().run(CacheInput(operation="get", key="missing"))
    assert result.value is None
    assert result.hit is False
    assert result.ok is True


async def test_set(mock_client: Any) -> None:
    mock_client.set = AsyncMock(return_value=True)
    result = await RedisCacheBlock().run(
        CacheInput(operation="set", key="bar", value="world", ttl=60)
    )
    assert result.value == "world"
    assert result.ok is True
    mock_client.set.assert_called_once_with("bar", "world", ex=60)


async def test_set_requires_value(mock_client: Any) -> None:
    with pytest.raises(ValueError, match="value"):
        await RedisCacheBlock().run(CacheInput(operation="set", key="k"))


async def test_delete(mock_client: Any) -> None:
    mock_client.delete = AsyncMock(return_value=1)
    result = await RedisCacheBlock().run(CacheInput(operation="delete", key="baz"))
    assert result.ok is True
    assert result.value is None
    mock_client.delete.assert_called_once_with("baz")


async def test_namespace_prefix(mock_client: Any) -> None:
    mock_client.get = AsyncMock(return_value=b"v")
    await RedisCacheBlock().run(CacheInput(operation="get", key="k", namespace="ns"))
    mock_client.get.assert_called_once_with("ns:k")


async def test_import_error_without_package() -> None:
    with patch.dict("sys.modules", {"redis": None, "redis.asyncio": None}):  # type: ignore[dict-item]
        block = RedisCacheBlock()
        with pytest.raises(ImportError, match="pylego\\[redis\\]"):
            await block.run(CacheInput(operation="get", key="x"))
