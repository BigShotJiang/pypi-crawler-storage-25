"""M128 — Redemption Mechanism 테스트 (설계 원칙 57)."""

from __future__ import annotations

import pytest

from pylego_blocks.registry import BlockRegistry, BlockRuntimeStat, RegistryPolicy
from pylego_blocks import Block, Stud


class _Input(Stud):
    x: int


class _Output(Stud):
    y: int


class _DummyBlock(Block[_Input, _Output]):
    input_model = _Input
    output_model = _Output

    async def run(self, inp: _Input) -> _Output:
        return _Output(y=inp.x)


def _make_reg(window: int = 3, rate: float = 0.5) -> BlockRegistry:
    policy = RegistryPolicy(redemption_window=window, redemption_rate=rate)
    reg = BlockRegistry()
    reg.set_policy(policy)
    reg.register(_DummyBlock)
    return reg


def _fail(reg: BlockRegistry, n: int = 1) -> None:
    for _ in range(n):
        reg.update_stat("_DummyBlock", success=False, elapsed_sec=0.1)


def _succeed(reg: BlockRegistry, n: int = 1) -> None:
    for _ in range(n):
        reg.update_stat("_DummyBlock", success=True, elapsed_sec=0.1)


# 1. redemption_window=0이면 redemption 미발생 (기본·하위 호환)
def test_redemption_disabled_when_window_zero() -> None:
    reg = _make_reg(window=0)
    _fail(reg, 5)
    before = reg.describe("_DummyBlock").runtime
    assert before is not None
    before_wfs = before.weighted_failure_sum
    _succeed(reg, 100)
    after = reg.describe("_DummyBlock").runtime
    assert after is not None
    assert after.redemption_count == 0
    assert after.weighted_failure_sum == before_wfs


# 2. consecutive_successes가 redemption_window에 도달하면 weighted_failure_sum 경감
def test_redemption_triggers_at_window() -> None:
    reg = _make_reg(window=3, rate=0.5)
    _fail(reg, 4)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    wfs_before = info.weighted_failure_sum
    _succeed(reg, 3)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.redemption_count == 1
    assert info.weighted_failure_sum < wfs_before


# 3. 경감 비율이 redemption_rate에 정확히 비례
def test_redemption_rate_applied_correctly() -> None:
    reg = _make_reg(window=2, rate=0.5)
    _fail(reg, 4)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    wfs_before = info.weighted_failure_sum
    _succeed(reg, 2)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert abs(info.weighted_failure_sum - wfs_before * 0.5) < 1e-9


# 4. redemption 후 consecutive_successes가 0으로 초기화
def test_consecutive_successes_reset_after_redemption() -> None:
    reg = _make_reg(window=3, rate=0.5)
    _fail(reg)
    _succeed(reg, 3)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.consecutive_successes == 0


# 5. redemption_count가 redemption 발생마다 1씩 증가
def test_redemption_count_increments() -> None:
    reg = _make_reg(window=2, rate=0.5)
    _fail(reg, 4)
    _succeed(reg, 2)  # 1회
    _succeed(reg, 2)  # 2회
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.redemption_count == 2


# 6. 실패 기록 시 consecutive_successes가 0으로 초기화
def test_consecutive_successes_reset_on_failure() -> None:
    reg = _make_reg(window=5, rate=0.5)
    _succeed(reg, 3)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.consecutive_successes == 3
    _fail(reg)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.consecutive_successes == 0


# 7. redemption 후에도 이후 실패로 weighted_failure_sum이 다시 증가
def test_weighted_failure_sum_increases_after_redemption() -> None:
    reg = _make_reg(window=2, rate=0.5)
    _fail(reg, 4)
    _succeed(reg, 2)  # redemption
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    wfs_after_redemption = info.weighted_failure_sum
    _fail(reg, 2)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.weighted_failure_sum > wfs_after_redemption


# 8. redemption_rate=1.0이면 한 번의 redemption으로 위험 완전 초기화
def test_redemption_rate_1_clears_risk() -> None:
    reg = _make_reg(window=2, rate=1.0)
    _fail(reg, 4)
    _succeed(reg, 2)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.weighted_failure_sum == pytest.approx(0.0)


# 9. redemption_rate=0.0이면 redemption 발생해도 위험 변화 없음
def test_redemption_rate_0_no_change() -> None:
    reg = _make_reg(window=2, rate=0.0)
    _fail(reg, 4)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    wfs_before = info.weighted_failure_sum
    _succeed(reg, 2)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.redemption_count == 1
    assert info.weighted_failure_sum == pytest.approx(wfs_before)


# 10. risk_adjusted_confidence가 redemption 후 실제로 상승
def test_risk_adjusted_confidence_improves_after_redemption() -> None:
    reg = _make_reg(window=3, rate=0.8)
    _fail(reg, 10)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    rac_before = info.risk_adjusted_confidence
    _succeed(reg, 3)
    info = reg.describe("_DummyBlock").runtime
    assert info is not None
    assert info.risk_adjusted_confidence > rac_before
