"""패키지 로드·버전 확인 스모크 테스트."""

from __future__ import annotations

import pylego_blocks


def test_package_importable() -> None:
    assert pylego_blocks is not None


def test_version_is_string() -> None:
    assert isinstance(pylego_blocks.__version__, str)
    assert len(pylego_blocks.__version__) > 0
