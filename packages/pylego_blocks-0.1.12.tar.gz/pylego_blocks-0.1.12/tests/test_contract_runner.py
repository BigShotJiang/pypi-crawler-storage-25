"""Tests for the pylego contract test runner option.

These tests exercise the pytest plugin behavior via the pytester fixture.
"""

from __future__ import annotations

import textwrap

import pytest

pytest.importorskip("pytester")


def test_contracts_option_selects_only_marked(pytester: pytest.Pytester) -> None:
    # create two test files: one marked, one not
    pytester.makepyfile(
        test_marked=textwrap.dedent(
            """
            import pytest

            @pytest.mark.pylego_contracts
            def test_contract():
                assert True
            """
        )
    )
    pytester.makepyfile(
        test_unmarked=textwrap.dedent(
            """
            def test_normal():
                assert True
            """
        )
    )

    # run without option: only unmarked test runs
    result = pytester.runpytest()
    result.assert_outcomes(passed=1, failed=0)

    # run with --pylego-contracts: only marked test runs
    result2 = pytester.runpytest("--pylego-contracts")
    result2.assert_outcomes(passed=1, failed=0)


def test_contracts_deselected_message(pytester: pytest.Pytester) -> None:
    pytester.makepyfile(
        test_marked=textwrap.dedent(
            """
            import pytest

            @pytest.mark.pylego_contracts
            def test_contract():
                assert True
            """
        )
    )

    # run normally: marked test should be deselected
    result = pytester.runpytest()
    result.stdout.fnmatch_lines(["*deselected*"], consecutive=False)
