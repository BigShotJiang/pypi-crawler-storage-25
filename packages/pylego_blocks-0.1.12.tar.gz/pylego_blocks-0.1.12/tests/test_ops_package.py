"""M123 — pylego.ops 패키지 분리 테스트."""

from __future__ import annotations


def test_ops_import_block_registry() -> None:
    from pylego_blocks.ops import BlockRegistry
    assert BlockRegistry is not None


def test_ops_import_scheduler() -> None:
    from pylego_blocks.ops import Scheduler
    assert Scheduler is not None


def test_ops_import_pipeline_health() -> None:
    from pylego_blocks.ops import PipelineHealth, build_health_summary
    assert PipelineHealth is not None
    assert build_health_summary is not None


def test_ops_causal_import() -> None:
    from pylego_blocks.ops.causal import CausalFactor
    from pylego_blocks.ops.diff import HealthDiff
    assert CausalFactor is not None
    assert HealthDiff is not None


def test_backward_compat_pylego_block_registry() -> None:
    from pylego_blocks import BlockRegistry as Old
    from pylego_blocks.ops import BlockRegistry as New
    assert Old is New


def test_backward_compat_graph_causal_factor() -> None:
    from pylego_blocks.core.graph import CausalFactor as Old
    from pylego_blocks.ops.causal import CausalFactor as New
    assert Old is New


def test_ops_all_contains_operator_symbols() -> None:
    import pylego_blocks.ops as ops
    assert "BlockRegistry" in ops.__all__
    assert "Scheduler" in ops.__all__
    assert "PipelineHealth" in ops.__all__
    assert "HealthDiff" in ops.__all__
    assert "CausalFactor" in ops.__all__
