"""AnthropicLlmBlock / OpenAiLlmBlock / OllamaLlmBlock 단위 테스트.

각 어댑터는 sys.modules mock 으로 optional deps 없이 테스트한다.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks.blocks.llm.base import LlmInput, LlmResult


# ── AnthropicLlmBlock ─────────────────────────────────────────────────────────

@pytest.fixture()
def mock_anthropic() -> Any:
    usage = MagicMock(input_tokens=10, output_tokens=20)
    content_block = MagicMock(text="안녕하세요")
    msg = MagicMock(
        content=[content_block],
        model="claude-opus-4-5",
        stop_reason="end_turn",
        usage=usage,
    )
    client = MagicMock()
    client.messages.create = AsyncMock(return_value=msg)
    async_anthropic_cls = MagicMock(return_value=client)
    module = MagicMock()
    module.AsyncAnthropic = async_anthropic_cls
    with patch.dict("sys.modules", {"anthropic": module}):
        yield {"client": client, "msg": msg}


async def test_anthropic_llm_block_basic(mock_anthropic: Any) -> None:
    from pylego_blocks.blocks.llm.anthropic_llm import AnthropicLlmBlock

    block = AnthropicLlmBlock()
    result = await block.run(LlmInput(prompt="안녕하세요"))
    assert isinstance(result, LlmResult)
    assert result.content == "안녕하세요"
    assert result.input_tokens == 10
    assert result.output_tokens == 20


async def test_anthropic_llm_uses_default_model(mock_anthropic: Any) -> None:
    from pylego_blocks.blocks.llm.anthropic_llm import AnthropicLlmBlock

    block = AnthropicLlmBlock()
    await block.run(LlmInput(prompt="test"))
    call_kwargs = mock_anthropic["client"].messages.create.call_args.kwargs
    assert call_kwargs["model"] == "claude-opus-4-5"


async def test_anthropic_llm_custom_model(mock_anthropic: Any) -> None:
    from pylego_blocks.blocks.llm.anthropic_llm import AnthropicLlmBlock

    block = AnthropicLlmBlock()
    await block.run(LlmInput(prompt="test", model="claude-haiku-4-5-20251001"))
    call_kwargs = mock_anthropic["client"].messages.create.call_args.kwargs
    assert call_kwargs["model"] == "claude-haiku-4-5-20251001"


# ── OpenAiLlmBlock ────────────────────────────────────────────────────────────

@pytest.fixture()
def mock_openai() -> Any:
    usage = MagicMock(prompt_tokens=5, completion_tokens=15)
    choice = MagicMock()
    choice.message.content = "Hello!"
    choice.finish_reason = "stop"
    resp = MagicMock(choices=[choice], model="gpt-4o", usage=usage)
    client = MagicMock()
    client.chat.completions.create = AsyncMock(return_value=resp)
    async_openai_cls = MagicMock(return_value=client)
    module = MagicMock()
    module.AsyncOpenAI = async_openai_cls
    with patch.dict("sys.modules", {"openai": module}):
        yield {"client": client, "resp": resp}


async def test_openai_llm_block_basic(mock_openai: Any) -> None:
    from pylego_blocks.blocks.llm.openai_llm import OpenAiLlmBlock

    block = OpenAiLlmBlock()
    result = await block.run(LlmInput(prompt="Hello"))
    assert isinstance(result, LlmResult)
    assert result.content == "Hello!"
    assert result.input_tokens == 5
    assert result.output_tokens == 15


async def test_openai_llm_uses_default_model(mock_openai: Any) -> None:
    from pylego_blocks.blocks.llm.openai_llm import OpenAiLlmBlock

    block = OpenAiLlmBlock()
    await block.run(LlmInput(prompt="test"))
    call_kwargs = mock_openai["client"].chat.completions.create.call_args.kwargs
    assert call_kwargs["model"] == "gpt-4o"


# ── OllamaLlmBlock ────────────────────────────────────────────────────────────

@pytest.fixture()
def mock_httpx_ollama() -> Any:
    resp = MagicMock()
    resp.raise_for_status = MagicMock()
    resp.json.return_value = {
        "response": "응답입니다",
        "model": "llama3.2",
        "done": True,
        "prompt_eval_count": 8,
        "eval_count": 16,
    }
    async_client = AsyncMock()
    async_client.post = AsyncMock(return_value=resp)
    async_client.__aenter__ = AsyncMock(return_value=async_client)
    async_client.__aexit__ = AsyncMock(return_value=False)
    with patch("httpx.AsyncClient", return_value=async_client):
        yield {"client": async_client, "resp": resp}


async def test_ollama_llm_block_basic(mock_httpx_ollama: Any) -> None:
    from pylego_blocks.blocks.llm.ollama_llm import OllamaLlmBlock

    block = OllamaLlmBlock()
    result = await block.run(LlmInput(prompt="안녕"))
    assert isinstance(result, LlmResult)
    assert result.content == "응답입니다"
    assert result.model == "llama3.2"
    assert result.input_tokens == 8
    assert result.output_tokens == 16


async def test_ollama_llm_uses_default_model(mock_httpx_ollama: Any) -> None:
    from pylego_blocks.blocks.llm.ollama_llm import OllamaLlmBlock

    block = OllamaLlmBlock()
    await block.run(LlmInput(prompt="test"))
    call_kwargs = mock_httpx_ollama["client"].post.call_args
    payload = call_kwargs.kwargs["json"]
    assert payload["model"] == "llama3.2"
