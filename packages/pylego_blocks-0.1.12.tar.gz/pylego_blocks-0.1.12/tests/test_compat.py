"""pylego_blocks.compat — is_available / @requires 단위 테스트 (M85)."""

from __future__ import annotations

import sys
from unittest.mock import patch

import pytest

from pylego_blocks.compat import PYLEGO_EXTRAS_MAP, is_available, requires


# ── is_available ──────────────────────────────────────────────────────────────

def test_is_available_installed_package() -> None:
    assert is_available("pydantic") is True


def test_is_available_absent_package() -> None:
    with patch.dict("sys.modules", {"_nonexistent_pkg_xyz": None}):
        assert is_available("_nonexistent_pkg_xyz") is False


def test_is_available_extras_name_mapped() -> None:
    # jinja2 가 설치된 경우 True
    if "jinja2" in sys.modules or is_available("jinja2"):
        assert is_available("jinja2") is True


def test_is_available_unknown_extra_uses_name_directly() -> None:
    result = is_available("pydantic")
    assert result is True


def test_extras_map_covers_common_keys() -> None:
    for key in ("anthropic", "openai", "redis", "chromadb", "jinja2", "duckdb"):
        assert key in PYLEGO_EXTRAS_MAP


# ── @requires ─────────────────────────────────────────────────────────────────

async def test_requires_passes_when_available() -> None:
    @requires("pydantic")
    async def fn() -> str:
        return "ok"

    assert await fn() == "ok"


async def test_requires_raises_import_error_when_absent() -> None:
    with patch("pylego_blocks.compat.is_available", side_effect=lambda e: e != "missing_pkg"):

        @requires("missing_pkg")
        async def fn() -> str:  # pragma: no cover
            return "never"

        with pytest.raises(ImportError, match="missing_pkg"):
            await fn()


async def test_requires_error_message_format() -> None:
    with patch("pylego_blocks.compat.is_available", return_value=False):

        @requires("anthropic")
        async def fn() -> str:  # pragma: no cover
            return "never"

        with pytest.raises(ImportError) as exc_info:
            await fn()
        msg = str(exc_info.value)
        assert "anthropic" in msg
        assert "pip install pylego[anthropic]" in msg


async def test_requires_multiple_extras_all_must_pass() -> None:
    with patch(
        "pylego_blocks.compat.is_available",
        side_effect=lambda e: e == "pydantic",
    ):

        @requires("pydantic", "absent_one")
        async def fn() -> str:  # pragma: no cover
            return "never"

        with pytest.raises(ImportError, match="absent_one"):
            await fn()


async def test_requires_preserves_return_value() -> None:
    @requires("pydantic")
    async def add(x: int, y: int) -> int:
        return x + y

    result = await add(3, 4)
    assert result == 7


async def test_requires_preserves_function_name() -> None:
    @requires("pydantic")
    async def my_special_fn() -> None:
        pass

    assert my_special_fn.__name__ == "my_special_fn"
