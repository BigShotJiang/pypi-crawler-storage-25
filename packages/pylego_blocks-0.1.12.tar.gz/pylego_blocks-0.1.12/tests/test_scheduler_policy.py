"""M95 — SchedulerPolicy 좀비 파이프라인 격리 테스트."""

from __future__ import annotations

import asyncio
import sys
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pylego_blocks import Assembly, Block, Stud
from pylego_blocks.scheduler import JobStatus, SchedulerPolicy


# ── 픽스처 ───────────────────────────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _FailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("pipeline error")


def _ok_pipeline() -> Assembly[_In, _Out]:
    return Assembly([_OkBlock()])


def _fail_pipeline() -> Assembly[_In, _Out]:
    return Assembly([_FailBlock()])


# ── mock helpers (동일 패턴 — test_scheduler.py 참조) ──────────────────────


def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        sys.modules,
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


def _extract_run_fn(mock_instance: MagicMock) -> Any:
    call = mock_instance.add_job.call_args
    return call[0][0] if call[0] else call.kwargs.get("func")


# ── SchedulerPolicy 기본 속성 ─────────────────────────────────────────────────


def test_policy_defaults() -> None:
    p = SchedulerPolicy()
    assert p.max_consecutive_failures is None
    assert p.max_runs_per_hour is None
    assert p.on_kill is None


def test_policy_fields() -> None:
    called: list[tuple[str, str]] = []
    p = SchedulerPolicy(
        max_consecutive_failures=3,
        max_runs_per_hour=60,
        on_kill=lambda jid, reason: called.append((jid, reason)),
    )
    assert p.max_consecutive_failures == 3
    assert p.max_runs_per_hour == 60
    p.on_kill("j1", "reason")  # type: ignore[misc]
    assert called == [("j1", "reason")]


# ── JobStatus ─────────────────────────────────────────────────────────────────


def test_job_status_defaults() -> None:
    s = JobStatus()
    assert s.state == "active"
    assert s.consecutive_failures == 0
    assert s.total_runs == 0


# ── N회 연속 실패 후 killed ────────────────────────────────────────────────────


def test_killed_after_n_consecutive_failures() -> None:
    import importlib

    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        policy = sched_mod.SchedulerPolicy(max_consecutive_failures=3)
        s.add(_fail_pipeline(), input=_In(v=1), interval_seconds=1, job_id="j1", policy=policy)

    run_fn = _extract_run_fn(mock_instance)

    # 3회 연속 실패
    for _ in range(3):
        asyncio.run(run_fn())

    status = s.job_status("j1")
    assert status.state == "killed"
    assert status.consecutive_failures == 3
    assert status.total_runs == 3


# ── on_kill 콜백 호출 ────────────────────────────────────────────────────────


def test_on_kill_callback_called() -> None:
    import importlib

    killed: list[tuple[str, str]] = []

    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        policy = sched_mod.SchedulerPolicy(
            max_consecutive_failures=2,
            on_kill=lambda jid, reason: killed.append((jid, reason)),
        )
        s.add(_fail_pipeline(), input=_In(v=1), interval_seconds=1, job_id="j2", policy=policy)

    run_fn = _extract_run_fn(mock_instance)
    asyncio.run(run_fn())
    assert killed == []  # 아직 1회만 실패
    asyncio.run(run_fn())
    assert len(killed) == 1
    assert killed[0][0] == "j2"
    assert "연속 실패" in killed[0][1]


# ── killed 상태에서 추가 실행 차단 ───────────────────────────────────────────


def test_killed_job_does_not_run_again() -> None:
    import importlib

    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        policy = sched_mod.SchedulerPolicy(max_consecutive_failures=1)
        s.add(_fail_pipeline(), input=_In(v=1), interval_seconds=1, job_id="j3", policy=policy)

    run_fn = _extract_run_fn(mock_instance)
    asyncio.run(run_fn())  # 1회 실패 → killed
    asyncio.run(run_fn())  # killed 상태 → 무시
    asyncio.run(run_fn())  # killed 상태 → 무시

    status = s.job_status("j3")
    assert status.total_runs == 1  # 최초 1회만 실행


# ── max_runs_per_hour 초과 시 실행 차단 ──────────────────────────────────────


def test_max_runs_per_hour_throttles() -> None:
    import importlib

    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        policy = sched_mod.SchedulerPolicy(max_runs_per_hour=3)
        s.add(_ok_pipeline(), input=_In(v=1), interval_seconds=1, job_id="j4", policy=policy)

    run_fn = _extract_run_fn(mock_instance)
    for _ in range(5):  # 5번 시도
        asyncio.run(run_fn())

    status = s.job_status("j4")
    assert status.total_runs == 3  # 3회만 실제 실행


# ── policy=None 이면 기존 동작 유지 ──────────────────────────────────────────


def test_no_policy_runs_indefinitely() -> None:
    import importlib

    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        s.add(_ok_pipeline(), input=_In(v=1), interval_seconds=1, job_id="j5")

    run_fn = _extract_run_fn(mock_instance)
    for _ in range(5):
        asyncio.run(run_fn())

    status = s.job_status("j5")
    assert status.state == "active"
    assert status.total_runs == 5


# ── 연속 실패 리셋 — 성공하면 consecutive_failures 초기화 ────────────────────


def test_consecutive_failures_resets_on_success() -> None:
    import importlib

    call_count = 0

    class _FlakyBlock(Block[_In, _Out]):
        input_model = _In
        output_model = _Out

        async def run(self, inp: _In) -> _Out:
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                raise RuntimeError("fail")
            return _Out(v=inp.v)

    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        policy = sched_mod.SchedulerPolicy(max_consecutive_failures=5)
        s.add(
            Assembly([_FlakyBlock()]),
            input=_In(v=1),
            interval_seconds=1,
            job_id="j6",
            policy=policy,
        )

    run_fn = _extract_run_fn(mock_instance)
    asyncio.run(run_fn())  # fail 1
    asyncio.run(run_fn())  # fail 2
    asyncio.run(run_fn())  # success → resets

    status = s.job_status("j6")
    assert status.consecutive_failures == 0
    assert status.state == "active"


# ── top-level import ──────────────────────────────────────────────────────────


def test_top_level_import() -> None:
    from pylego_blocks import JobStatus as JS
    from pylego_blocks import SchedulerPolicy as SP
    assert JS is JobStatus
    assert SP is SchedulerPolicy
