"""M99 — GlobalSchedulerPolicy + 적응형 상태 전이 테스트."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pylego_blocks import Assembly, Block, GlobalSchedulerPolicy, Scheduler, SchedulerPolicy, Stud


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _OkBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _FailBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        raise RuntimeError("fail")


# ── mock helpers (test_scheduler_policy.py 동일 패턴) ────────────────────────


def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        "sys.modules",
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


def _extract_run_fn(mock_instance: MagicMock) -> Any:
    call = mock_instance.add_job.call_args
    return call[0][0] if call[0] else call[1].get("func")


# ── GlobalSchedulerPolicy dataclass ──────────────────────────────────────────


def test_global_policy_defaults() -> None:
    gp = GlobalSchedulerPolicy()
    assert gp.max_killed_ratio is None
    assert gp.max_global_consecutive_failures is None
    assert gp.on_global_alert is None


def test_global_policy_fields() -> None:
    called: list[str] = []
    gp = GlobalSchedulerPolicy(
        max_killed_ratio=0.5,
        max_global_consecutive_failures=5,
        on_global_alert=lambda msg: called.append(msg),
    )
    assert gp.max_killed_ratio == 0.5
    assert gp.max_global_consecutive_failures == 5


# ── SchedulerPolicy 확장 필드 ─────────────────────────────────────────────────


def test_scheduler_policy_new_fields() -> None:
    p = SchedulerPolicy(suspended_retry_seconds=300.0, max_recovery_attempts=2)
    assert p.suspended_retry_seconds == 300.0
    assert p.max_recovery_attempts == 2


def test_scheduler_policy_defaults_new_fields() -> None:
    p = SchedulerPolicy()
    assert p.suspended_retry_seconds is None
    assert p.max_recovery_attempts == 1


# ── JobStatus.recovery_attempts ───────────────────────────────────────────────


def test_job_status_recovery_attempts_field() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        sched.add(pipeline, input=_In(v=1), interval_seconds=60, job_id="j1")
        status = sched.job_status("j1")
        assert status.recovery_attempts == 0


# ── global_status() ───────────────────────────────────────────────────────────


def test_global_status_empty() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        status = sched.global_status()
        assert status["active"] == 0
        assert status["killed"] == 0
        assert status["suspended"] == 0
        assert status["total"] == 0
        assert status["frozen"] is False
        assert status["freeze_reason"] is None


def test_global_status_counts() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        ok_pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])

        policy = SchedulerPolicy(max_consecutive_failures=1)
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="ok")
        sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="fail", policy=policy)

        # fail 잡을 killed 상태로 전환
        sched._job_states["fail"].state = "killed"

        status = sched.global_status()
        assert status["active"] == 1
        assert status["killed"] == 1
        assert status["total"] == 2


# ── max_killed_ratio — 신규 잡 등록 차단 ─────────────────────────────────────


def test_add_blocked_by_max_killed_ratio() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        gp = GlobalSchedulerPolicy(max_killed_ratio=0.5)
        sched.set_global_policy(gp)

        ok_pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j1")
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j2")

        # j1을 killed 상태로 전환 → killed 1/2 = 50% → 차단
        sched._job_states["j1"].state = "killed"

        with pytest.raises(ValueError, match="killed 비율"):
            sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j3")


def test_add_allowed_below_max_killed_ratio() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        gp = GlobalSchedulerPolicy(max_killed_ratio=0.6)
        sched.set_global_policy(gp)

        ok_pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j1")
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j2")
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j3")

        # j1만 killed → 1/3 ≈ 33% < 60%
        sched._job_states["j1"].state = "killed"

        # 추가 허용
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="j4")
        assert sched.global_status()["total"] == 4


# ── on_global_alert — 전역 연속 실패 ─────────────────────────────────────────


async def test_on_global_alert_called() -> None:
    alerts: list[str] = []
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        gp = GlobalSchedulerPolicy(
            max_global_consecutive_failures=2,
            on_global_alert=alerts.append,
        )
        sched.set_global_policy(gp)

        fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
        sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="f")
        run_fn = _extract_run_fn(mock_instance)

        await run_fn()  # 1st fail
        assert len(alerts) == 0
        await run_fn()  # 2nd fail → alert
        assert len(alerts) == 1
        assert "2" in alerts[0]


async def test_global_consecutive_failures_reset_on_success() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()

        ok_pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
        sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="f")
        sched.add(ok_pipeline, input=_In(v=1), interval_seconds=60, job_id="ok")

        # 각 add_job 호출 순서대로 fn 추출
        fail_call = mock_instance.add_job.call_args_list[0]
        fail_run = fail_call[0][0] if fail_call[0] else fail_call[1].get("func")
        ok_call = mock_instance.add_job.call_args_list[1]
        ok_run = ok_call[0][0] if ok_call[0] else ok_call[1].get("func")

        await fail_run()  # fail → global_consecutive=1
        assert sched._global_consecutive_failures == 1

        await ok_run()  # success → global_consecutive=0
        assert sched._global_consecutive_failures == 0


# ── suspended_retry_seconds — 자동 복구 ───────────────────────────────────────


async def test_suspended_state_after_kill_with_retry() -> None:
    """suspended_retry_seconds 설정 시 killed 대신 suspended 상태."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        policy = SchedulerPolicy(
            max_consecutive_failures=2,
            suspended_retry_seconds=300.0,
        )
        fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
        sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="j", policy=policy)
        run_fn = _extract_run_fn(mock_instance)

        await run_fn()  # 1st fail
        await run_fn()  # 2nd fail → suspended (not killed)
        assert sched.job_status("j").state == "suspended"


async def test_suspended_recovery_success() -> None:
    """복구 시도 성공 시 state='active'."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        policy = SchedulerPolicy(
            max_consecutive_failures=1,
            suspended_retry_seconds=0.0,  # 즉시 재시도
        )
        ok_pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
        sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="j", policy=policy)
        run_fn = _extract_run_fn(mock_instance)

        await run_fn()  # → suspended
        assert sched.job_status("j").state == "suspended"

        # ok_pipeline으로 교체 후 복구 시도
        sched._job_states["j"].policy = SchedulerPolicy(
            max_consecutive_failures=1,
            suspended_retry_seconds=0.0,
        )
        # pipeline을 ok로 교체하는 대신 직접 state 확인
        # 실제 복구: suspended 상태에서 _killed_at이 지나면 run
        import importlib
        import pylego_blocks.scheduler as sched_mod  # noqa: PLC0415

        ok_pipeline2: Assembly[_In, _Out] = Assembly([_OkBlock()])
        sched2 = Scheduler()
        sched2.add(
            ok_pipeline2, input=_In(v=1), interval_seconds=60, job_id="j2",
            policy=SchedulerPolicy(max_consecutive_failures=1, suspended_retry_seconds=0.0),
        )
        sched2._job_states["j2"].state = "suspended"
        sched2._job_states["j2"]._killed_at = 0.0  # 이미 경과

        run_fn2 = _extract_run_fn(mock_instance)
        # 두 번째 add_job 호출에서 fn 추출
        ok_call = mock_instance.add_job.call_args_list[-1]
        ok_run = ok_call[0][0] if ok_call[0] else ok_call[1].get("func")
        await ok_run()  # success → active
        assert sched2.job_status("j2").state == "active"
        assert sched2.job_status("j2").recovery_attempts == 0


async def test_suspended_recovery_permanent_kill() -> None:
    """max_recovery_attempts 초과 시 영구 killed."""
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        policy = SchedulerPolicy(
            max_consecutive_failures=1,
            suspended_retry_seconds=0.0,
            max_recovery_attempts=2,
        )
        fail_pipeline: Assembly[_In, _Out] = Assembly([_FailBlock()])
        sched.add(fail_pipeline, input=_In(v=1), interval_seconds=60, job_id="j", policy=policy)
        run_fn = _extract_run_fn(mock_instance)

        await run_fn()  # → suspended
        await run_fn()  # 1st recovery attempt fail → recovery_attempts=1 < 2
        assert sched.job_status("j").state == "suspended"
        assert sched.job_status("j").recovery_attempts == 1

        sched._job_states["j"]._killed_at = 0.0
        await run_fn()  # 2nd recovery attempt fail → recovery_attempts=2 >= 2 → killed
        assert sched.job_status("j").state == "killed"
        assert sched.job_status("j").recovery_attempts == 2


# ── global_policy=None — 기존 동작 유지 ──────────────────────────────────────


async def test_no_global_policy_no_error() -> None:
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        sched = Scheduler()
        assert sched._global_policy is None

        pipeline: Assembly[_In, _Out] = Assembly([_OkBlock()])
        sched.add(pipeline, input=_In(v=1), interval_seconds=60, job_id="j")
        run_fn = _extract_run_fn(mock_instance)
        await run_fn()
        assert sched.job_status("j").state == "active"
