"""Unit 계층 단위 테스트 — validate/run/verify 생명주기, 실패 전파, 파이프라인."""

from __future__ import annotations

from typing import Any

import pytest

from pylego_blocks.core.stud import Stud
from pylego_blocks.unit import (
    ConfigBlock,
    ResultUnit,
    Unit,
    UnitPipeline,
    UnitResult,
    run_unit_main,
    unit_schema,
)


# ─── fixtures ────────────────────────────────────────────────────────────────

class _In(Stud):
    value: int = 0


class _Cfg(Stud):
    key: str = "default"


class _DoubleUnit(Unit[_In]):
    """value * 2 를 _In 으로 반환 — 체인 가능."""

    input_model = _In

    async def run(self, inp: _In) -> Any:
        return _In(value=inp.value * 2)


class _FailUnit(Unit[_In]):
    """항상 run() 에서 예외를 던지는 Unit."""

    input_model = _In

    async def run(self, inp: _In) -> Any:
        raise ValueError("intentional failure")


class _ValidateFailUnit(Unit[_In]):
    """validate() 에서 실패하는 Unit."""

    input_model = _In

    async def validate(self, inp: _In) -> None:
        if inp.value < 0:
            raise ValueError("value must be non-negative")

    async def run(self, inp: _In) -> Any:
        return inp.value


class _VerifyFailUnit(Unit[_In]):
    """verify() 에서 실패하는 Unit."""

    input_model = _In

    async def run(self, inp: _In) -> Any:
        return inp.value

    async def verify(self, inp: _In, result: Any) -> None:
        if result > 100:
            raise ValueError("result too large")


class _AccumulateUnit(Unit[_In]):
    """실행 횟수를 카운트하는 Unit."""

    input_model = _In
    call_count: int = 0

    async def run(self, inp: _In) -> Any:
        _AccumulateUnit.call_count += 1
        return inp.value


class _SimpleResult(ResultUnit):
    """성공/실패를 그대로 반환하는 ResultUnit."""

    async def on_success(self, result: Any) -> UnitResult:
        return UnitResult(status="success", result=result)

    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(status="failure", reason=reason, failed_at=failed_at)


class _EnvConfig(ConfigBlock[_Cfg]):
    """하드코딩된 설정을 반환하는 ConfigBlock."""

    output_model = _Cfg

    async def load(self) -> _Cfg:
        return _Cfg(key="loaded")


# ─── UnitResult ───────────────────────────────────────────────────────────────

class TestUnitResult:
    def test_success(self) -> None:
        r = UnitResult(status="success", result=42)
        assert r.status == "success"
        assert r.result == 42

    def test_failure(self) -> None:
        r = UnitResult(status="failure", reason="oops", failed_at="MyUnit")
        assert r.status == "failure"
        assert r.reason == "oops"
        assert r.failed_at == "MyUnit"

    def test_defaults(self) -> None:
        r = UnitResult(status="success")
        assert r.result is None
        assert r.reason is None
        assert r.failed_at is None


# ─── Unit.execute() ───────────────────────────────────────────────────────────

class TestUnitExecute:
    async def test_success_path(self) -> None:
        unit = _DoubleUnit()
        result = await unit.execute(_In(value=5))
        assert result.status == "success"
        assert isinstance(result.result, _In)
        assert result.result.value == 10

    async def test_run_failure_captured(self) -> None:
        unit = _FailUnit()
        result = await unit.execute(_In(value=1))
        assert result.status == "failure"
        assert "intentional failure" in (result.reason or "")
        assert result.failed_at == "_FailUnit"

    async def test_validate_failure_captured(self) -> None:
        unit = _ValidateFailUnit()
        result = await unit.execute(_In(value=-1))
        assert result.status == "failure"
        assert "validate" in (result.reason or "")

    async def test_verify_failure_captured(self) -> None:
        unit = _VerifyFailUnit()
        result = await unit.execute(_In(value=200))
        assert result.status == "failure"
        assert "verify" in (result.reason or "")

    async def test_passthrough_failed_unit_result(self) -> None:
        failed = UnitResult(status="failure", reason="prev", failed_at="PrevUnit")
        unit = _DoubleUnit()
        result = await unit.execute(failed)
        # 실행되지 않고 그대로 전달
        assert result is failed

    async def test_unpack_success_unit_result(self) -> None:
        """UnitResult(success) 를 입력으로 받으면 result 를 언팩해서 run()."""
        unit = _DoubleUnit()
        wrapped = UnitResult(status="success", result=_In(value=3))
        result = await unit.execute(wrapped)
        assert result.status == "success"
        assert isinstance(result.result, _In)
        assert result.result.value == 6

    def test_name_defaults_to_class_name(self) -> None:
        assert _DoubleUnit.name == "_DoubleUnit"


# ─── ResultUnit ───────────────────────────────────────────────────────────────

class TestResultUnit:
    async def test_on_success_called(self) -> None:
        ru = _SimpleResult()
        inp = UnitResult(status="success", result=99)
        out = await ru.execute(inp)
        assert out.status == "success"
        assert out.result == 99

    async def test_on_failure_called(self) -> None:
        ru = _SimpleResult()
        inp = UnitResult(status="failure", reason="bad", failed_at="X")
        out = await ru.execute(inp)
        assert out.status == "failure"
        assert out.failed_at == "X"

    def test_name_defaults_to_class_name(self) -> None:
        assert _SimpleResult.name == "_SimpleResult"


# ─── UnitPipeline ─────────────────────────────────────────────────────────────

class TestUnitPipeline:
    async def test_linear_success(self) -> None:
        pipeline: UnitPipeline[_In] = UnitPipeline(
            [_DoubleUnit(), _DoubleUnit()],
            result_unit=_SimpleResult(),
        )
        result = await pipeline.run(_In(value=3))
        # 3 → _In(6) → _In(12)
        assert result.status == "success"
        assert isinstance(result.result, _In)
        assert result.result.value == 12

    async def test_failure_skips_subsequent_units(self) -> None:
        _AccumulateUnit.call_count = 0
        pipeline: UnitPipeline[_In] = UnitPipeline(
            [_FailUnit(), _AccumulateUnit()],
            result_unit=_SimpleResult(),
        )
        result = await pipeline.run(_In(value=1))
        assert result.status == "failure"
        assert _AccumulateUnit.call_count == 0  # 스킵됨

    async def test_failure_propagates_to_result_unit(self) -> None:
        pipeline: UnitPipeline[_In] = UnitPipeline(
            [_FailUnit()],
            result_unit=_SimpleResult(),
        )
        result = await pipeline.run(_In(value=1))
        assert result.status == "failure"
        assert result.failed_at == "_FailUnit"

    async def test_result_unit_always_runs(self) -> None:
        """ResultUnit 은 성공/실패 무관하게 항상 실행된다."""

        class _TrackResult(ResultUnit):
            called_with: str = ""

            async def on_success(self, result: Any) -> UnitResult:
                _TrackResult.called_with = "success"
                return UnitResult(status="success", result=result)

            async def on_failure(
                self, reason: str | None, failed_at: str | None
            ) -> UnitResult:
                _TrackResult.called_with = "failure"
                return UnitResult(status="failure", reason=reason, failed_at=failed_at)

        pipeline_ok: UnitPipeline[_In] = UnitPipeline(
            [_DoubleUnit()], result_unit=_TrackResult()
        )
        await pipeline_ok.run(_In(value=1))
        assert _TrackResult.called_with == "success"

        pipeline_fail: UnitPipeline[_In] = UnitPipeline(
            [_FailUnit()], result_unit=_TrackResult()
        )
        await pipeline_fail.run(_In(value=1))
        assert _TrackResult.called_with == "failure"

    def test_empty_units_raises(self) -> None:
        with pytest.raises(ValueError, match="최소 한 개"):
            UnitPipeline([], result_unit=_SimpleResult())

    def test_run_sync(self) -> None:
        pipeline: UnitPipeline[_In] = UnitPipeline(
            [_DoubleUnit()], result_unit=_SimpleResult()
        )
        result = pipeline.run_sync(_In(value=4))
        assert result.status == "success"
        assert isinstance(result.result, _In)
        assert result.result.value == 8


# ─── ConfigBlock ─────────────────────────────────────────────────────────────

class TestConfigBlock:
    async def test_load_called_on_run(self) -> None:
        block = _EnvConfig()
        result = await block.run(Stud())
        assert isinstance(result, _Cfg)
        assert result.key == "loaded"

    def test_input_model_is_stud(self) -> None:
        assert _EnvConfig.input_model is Stud

    def test_output_model_is_config_type(self) -> None:
        assert _EnvConfig.output_model is _Cfg


# ─── unit_schema & run_unit_main ──────────────────────────────────────────────

class TestUnitSchema:
    def test_returns_json_schema(self) -> None:
        schema = unit_schema(_DoubleUnit())
        assert schema["title"] == "_In"
        assert "value" in schema["properties"]


class TestRunUnitMain:
    def test_schema_flag(self, capsys: pytest.CaptureFixture[str]) -> None:
        run_unit_main(_DoubleUnit(), argv=["--schema"])
        captured = capsys.readouterr()
        import json
        schema = json.loads(captured.out)
        assert "value" in schema["properties"]

    def test_success_output(self, capsys: pytest.CaptureFixture[str]) -> None:
        run_unit_main(_DoubleUnit(), argv=['{"value": 7}'])
        captured = capsys.readouterr()
        import json
        out = json.loads(captured.out)
        assert out["status"] == "success"
        assert out["result"]["value"] == 14

    def test_failure_output(self, capsys: pytest.CaptureFixture[str]) -> None:
        run_unit_main(_FailUnit(), argv=['{"value": 1}'])
        captured = capsys.readouterr()
        import json
        out = json.loads(captured.out)
        assert out["status"] == "failure"

    def test_invalid_json_exits(self) -> None:
        with pytest.raises(SystemExit) as exc_info:
            run_unit_main(_DoubleUnit(), argv=["not-json"])
        assert exc_info.value.code == 1

    def test_validation_error_exits(self) -> None:
        with pytest.raises(SystemExit) as exc_info:
            run_unit_main(_DoubleUnit(), argv=['{"value": "not-an-int"}'])
        assert exc_info.value.code == 1
