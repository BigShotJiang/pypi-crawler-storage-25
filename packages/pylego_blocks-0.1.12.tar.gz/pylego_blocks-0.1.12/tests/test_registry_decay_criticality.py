"""M119 — Criticality-aware Risk Decay 테스트."""

from __future__ import annotations

import time

import pytest

from pylego_blocks.registry import BlockRegistry, BlockRuntimeStat, RegistryPolicy
from pylego_blocks import Block, Stud


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _A(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _B(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


# ── decay_overrides 우선순위 ──────────────────────────────────────────────────


def test_decay_overrides_takes_precedence_over_global() -> None:
    """decay_overrides 가 전역 risk_decay_half_life_sec 보다 우선 적용된다."""
    policy = RegistryPolicy(
        risk_decay_half_life_sec=3600.0,
        decay_overrides={"_A": 60.0},
    )
    assert policy.decay_overrides.get("_A") == 60.0
    assert policy.risk_decay_half_life_sec == 3600.0


def test_decay_overrides_unregistered_falls_back_to_global() -> None:
    """미등록 블록은 전역 risk_decay_half_life_sec 폴백 (하위 호환)."""
    reg = BlockRegistry()
    reg.register(_A)
    reg.register(_B)
    policy = RegistryPolicy(
        risk_decay_half_life_sec=1000.0,
        decay_overrides={"_A": 10.0},
    )
    reg.set_policy(policy)

    assert reg._effective_half_life("_A") == pytest.approx(10.0)
    assert reg._effective_half_life("_B") == pytest.approx(1000.0)


# ── oscillation 감지 ──────────────────────────────────────────────────────────


def test_oscillation_count_increases_on_same_error_after_decay() -> None:
    """감쇠 후 동일 오류 재발 시 oscillation_count 가 증가한다."""
    reg = BlockRegistry()
    reg.register(_A)
    # half-life = 0.001초 (1ms) — 테스트 실행 시간 동안 확실히 경과
    policy = RegistryPolicy(risk_decay_half_life_sec=0.001)
    reg.set_policy(policy)

    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")
    time.sleep(0.01)  # 10ms > 1ms half-life → elapsed >= half_life
    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.oscillation_count == 1


def test_oscillation_count_no_change_without_decay() -> None:
    """half-life 없으면 oscillation_count 변화 없다."""
    reg = BlockRegistry()
    reg.register(_A)
    reg.set_policy(RegistryPolicy(risk_decay_half_life_sec=0.0))

    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")
    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.oscillation_count == 0


def test_oscillation_penalty_increases_half_life() -> None:
    """oscillation_count > 0 이면 effective_half_life 가 penalty 배 증가한다."""
    reg = BlockRegistry()
    reg.register(_A)
    policy = RegistryPolicy(
        risk_decay_half_life_sec=0.001,
        oscillation_penalty=3.0,
    )
    reg.set_policy(policy)

    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")
    time.sleep(0.01)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.oscillation_count == 1
    # effective_half_life = 0.001 × 3.0^1 = 0.003
    assert reg._effective_half_life("_A") == pytest.approx(0.003)


def test_oscillation_penalty_one_no_change() -> None:
    """`oscillation_penalty=1.0` 이면 oscillation 감지해도 half-life 변화 없다."""
    reg = BlockRegistry()
    reg.register(_A)
    policy = RegistryPolicy(
        risk_decay_half_life_sec=0.001,
        oscillation_penalty=1.0,
    )
    reg.set_policy(policy)

    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")
    time.sleep(0.01)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")

    # oscillation_count 자체는 증가하지만 half-life는 그대로
    assert reg._effective_half_life("_A") == pytest.approx(0.001)


def test_success_does_not_update_oscillation_counter() -> None:
    """성공 기록은 oscillation 카운터를 갱신하지 않는다."""
    reg = BlockRegistry()
    reg.register(_A)
    reg.set_policy(RegistryPolicy(risk_decay_half_life_sec=0.001))

    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")
    time.sleep(0.01)
    reg.update_stat("_A", success=True, elapsed_sec=0.1)  # 성공 — oscillation 없음

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.oscillation_count == 0


def test_different_error_types_not_oscillation() -> None:
    """서로 다른 error_type 연속 실패는 oscillation으로 판정하지 않는다."""
    reg = BlockRegistry()
    reg.register(_A)
    reg.set_policy(RegistryPolicy(risk_decay_half_life_sec=0.001))

    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")
    time.sleep(0.01)
    reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="ValidationError")

    info = reg.describe("_A")
    assert info.runtime is not None
    assert info.runtime.oscillation_count == 0


def test_decay_overrides_empty_uses_global() -> None:
    """decay_overrides 비어 있으면 전역 half-life 그대로 (하위 호환)."""
    reg = BlockRegistry()
    reg.register(_A)
    reg.set_policy(RegistryPolicy(risk_decay_half_life_sec=500.0, decay_overrides={}))
    assert reg._effective_half_life("_A") == pytest.approx(500.0)


# ── risk_adjusted_confidence 감쇠 반영 ───────────────────────────────────────


def test_decayed_risk_reduces_risk_adjusted_confidence() -> None:
    """half-life 경과 후 decayed_risk 감소 → risk_adjusted_confidence 상향된다."""
    reg = BlockRegistry()
    reg.register(_A)
    # half-life = 0.001초
    reg.set_policy(RegistryPolicy(risk_decay_half_life_sec=0.001, min_samples=1))

    # 충분한 실패 누적
    for _ in range(5):
        reg.update_stat("_A", success=False, elapsed_sec=0.1, error_type="TimeoutError")

    info = reg.describe("_A")
    assert info.runtime is not None
    conf_before = info.runtime.risk_adjusted_confidence

    time.sleep(0.02)  # 20ms >> 1ms half-life → 대부분 감쇠

    conf_after = info.runtime.risk_adjusted_confidence
    assert conf_after > conf_before
