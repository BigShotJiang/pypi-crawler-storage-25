"""OllamaBlock 단위 테스트 — httpx.AsyncClient 를 mock 으로 대체."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks import OllamaBlock, OllamaInput, OllamaResult

_RESP_PAYLOAD = {
    "response": "파이썬은 훌륭합니다.",
    "model": "llama3.2",
    "done": True,
    "prompt_eval_count": 5,
    "eval_count": 12,
}


@pytest.fixture()
def mock_client() -> Any:
    """httpx.AsyncClient 를 mock 으로 교체."""
    resp = MagicMock()
    resp.json.return_value = _RESP_PAYLOAD
    resp.raise_for_status = MagicMock()

    http_client = AsyncMock()
    http_client.post = AsyncMock(return_value=resp)

    with patch("httpx.AsyncClient") as mock_cls:
        ctx = MagicMock()
        ctx.__aenter__ = AsyncMock(return_value=http_client)
        ctx.__aexit__ = AsyncMock(return_value=None)
        mock_cls.return_value = ctx
        yield http_client


async def test_basic_call(mock_client: Any) -> None:
    block = OllamaBlock()
    result = await block.run(OllamaInput(model="llama3.2", prompt="파이썬이란?"))
    assert isinstance(result, OllamaResult)
    assert result.response == "파이썬은 훌륭합니다."
    assert result.model == "llama3.2"
    assert result.done is True
    assert result.prompt_eval_count == 5
    assert result.eval_count == 12


async def test_options_passed(mock_client: Any) -> None:
    block = OllamaBlock()
    await block.run(
        OllamaInput(model="llama3.2", prompt="hi", temperature=0.5, num_predict=100)
    )
    call_kwargs: dict[str, Any] = mock_client.post.call_args.kwargs
    payload: dict[str, Any] = call_kwargs["json"]
    assert payload["options"]["temperature"] == 0.5
    assert payload["options"]["num_predict"] == 100


async def test_system_passed(mock_client: Any) -> None:
    block = OllamaBlock()
    await block.run(OllamaInput(model="m", prompt="q", system="You are helpful."))
    call_kwargs: dict[str, Any] = mock_client.post.call_args.kwargs
    assert call_kwargs["json"]["system"] == "You are helpful."


async def test_no_options_when_not_set(mock_client: Any) -> None:
    block = OllamaBlock()
    await block.run(OllamaInput(model="m", prompt="q"))
    call_kwargs: dict[str, Any] = mock_client.post.call_args.kwargs
    assert "options" not in call_kwargs["json"]
