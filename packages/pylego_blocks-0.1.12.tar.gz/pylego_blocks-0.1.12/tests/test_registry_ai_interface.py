"""M125 — BlockRegistry AI 인터페이스 강화 테스트."""

from __future__ import annotations

import warnings

import pytest

from pylego_blocks import Block, Stud
from pylego_blocks.registry import BlockRegistry, RegistryPolicy


class _BaseStud(Stud):
    value: int


class _SubStud(_BaseStud):
    extra: str = ""


class _Out(Stud):
    result: str


class _BaseBlock(Block[_BaseStud, _Out]):
    input_model = _BaseStud
    output_model = _Out

    async def run(self, inp: _BaseStud) -> _Out:
        return _Out(result=str(inp.value))


class _SubBlock(Block[_SubStud, _Out]):
    input_model = _SubStud
    output_model = _Out

    async def run(self, inp: _SubStud) -> _Out:
        return _Out(result=inp.extra)


def test_register_without_description_warns() -> None:
    reg = BlockRegistry()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        reg.register(_BaseBlock)
    assert any(issubclass(warning.category, UserWarning) for warning in w)


def test_register_without_tags_warns() -> None:
    reg = BlockRegistry()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        reg.register(_BaseBlock, description="설명은 있지만 태그 없음")
    assert any(issubclass(warning.category, UserWarning) for warning in w)


def test_register_with_description_and_tags_no_warn() -> None:
    reg = BlockRegistry()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        reg.register(_BaseBlock, description="설명", tags=["test"])
    user_warnings = [x for x in w if issubclass(x.category, UserWarning)]
    assert not user_warnings


def test_compatible_with_subclass_true() -> None:
    reg = BlockRegistry()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        reg.register(_BaseBlock)
        reg.register(_SubBlock)

    exact = reg.compatible_with(_BaseStud)
    assert len(exact) == 1
    assert exact[0].name == "_BaseBlock"

    with_sub = reg.compatible_with(_BaseStud, subclass=True)
    names = {i.name for i in with_sub}
    assert "_BaseBlock" in names
    assert "_SubBlock" in names


def test_registry_policy_development_preset() -> None:
    policy = RegistryPolicy.development()
    assert policy.min_samples == 3
    assert policy.risk_decay_half_life_sec == 60.0
    assert policy.oscillation_penalty == 1.0


def test_registry_policy_production_preset() -> None:
    policy = RegistryPolicy.production()
    assert policy.min_samples == 10
    assert policy.risk_decay_half_life_sec == 3600.0
    assert policy.oscillation_penalty == 2.0


def test_registry_policy_strict_preset() -> None:
    policy = RegistryPolicy.strict()
    assert policy.oscillation_penalty == 3.0


def test_update_stat_unregistered_warns() -> None:
    reg = BlockRegistry()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        reg.update_stat("NonExistentBlock", success=True, elapsed_sec=0.1)
    assert any(issubclass(warning.category, UserWarning) for warning in w)


def test_update_stat_registered_no_warn() -> None:
    reg = BlockRegistry()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        reg.register(_BaseBlock)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        reg.update_stat("_BaseBlock", success=True, elapsed_sec=0.5)
    user_warnings = [x for x in w if issubclass(x.category, UserWarning)]
    assert not user_warnings
