"""ChunkTextBlock 단위 테스트 — 순수 Python, mock 불필요."""

from __future__ import annotations

import pytest

from pylego_blocks import ChunkTextBlock, ChunkTextInput, ChunkTextResult


async def test_short_text_single_chunk() -> None:
    block = ChunkTextBlock()
    result = await block.run(ChunkTextInput(text="짧은 텍스트", chunk_size=100))
    assert isinstance(result, ChunkTextResult)
    assert result.chunks == ["짧은 텍스트"]
    assert result.chunk_count == 1


async def test_empty_text() -> None:
    block = ChunkTextBlock()
    result = await block.run(ChunkTextInput(text="   "))
    assert result.chunks == []
    assert result.chunk_count == 0


async def test_long_text_multiple_chunks() -> None:
    # 단락 구분자 \n\n 으로 분리되어야 함
    paragraphs = ["단락 " + str(i) + ". " + "내용 " * 20 for i in range(10)]
    text = "\n\n".join(paragraphs)
    block = ChunkTextBlock()
    result = await block.run(ChunkTextInput(text=text, chunk_size=200, chunk_overlap=50))
    assert result.chunk_count > 1
    # 모든 청크가 chunk_size 이하 (다소 여유를 둠)
    for chunk in result.chunks:
        assert len(chunk) <= 300  # 약간의 여유 허용


async def test_chunk_overlap_content() -> None:
    # 오버랩이 있으면 인접 청크 사이에 공통 텍스트가 있어야 함
    words = ["word" + str(i) for i in range(100)]
    text = " ".join(words)
    result = await ChunkTextBlock().run(
        ChunkTextInput(text=text, chunk_size=50, chunk_overlap=20)
    )
    assert result.chunk_count >= 2
    # 전체 내용이 청크에 커버되는지 확인 (첫 단어, 마지막 단어 포함)
    all_content = " ".join(result.chunks)
    assert "word0" in all_content
    assert "word99" in all_content


async def test_custom_separators() -> None:
    text = "a|b|c|d|e" * 50
    result = await ChunkTextBlock().run(
        ChunkTextInput(text=text, chunk_size=30, chunk_overlap=5, separators=["|", ""])
    )
    assert result.chunk_count > 1


async def test_no_separators_fallback() -> None:
    # 구분자가 없는 연속 문자열 — 문자 단위 강제 분리
    text = "a" * 500
    result = await ChunkTextBlock().run(
        ChunkTextInput(text=text, chunk_size=100, chunk_overlap=10, separators=[""])
    )
    assert result.chunk_count >= 5


async def test_chunk_size_respected() -> None:
    long_paragraph = "한국어 " * 200
    result = await ChunkTextBlock().run(
        ChunkTextInput(text=long_paragraph, chunk_size=100, chunk_overlap=20)
    )
    for chunk in result.chunks:
        assert len(chunk) <= 150  # separator join 여유
