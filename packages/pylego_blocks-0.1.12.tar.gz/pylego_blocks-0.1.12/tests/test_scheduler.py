"""pylego_blocks.scheduler 테스트 (M91)."""

from __future__ import annotations

import asyncio
import sys
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks import Assembly, Block, Stud
from pylego_blocks.scheduler import run_once


# ── Fixtures ─────────────────────────────────────────────────────────────────

class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _EchoBlock(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v * 2)


def _pipeline() -> Assembly:
    return Assembly([_EchoBlock()])


# ── run_once ─────────────────────────────────────────────────────────────────

def test_run_once_returns_result() -> None:
    result = run_once(_pipeline(), input=_In(v=5))
    assert isinstance(result, _Out)
    assert result.v == 10


def test_run_once_does_not_require_apscheduler() -> None:
    saved = sys.modules.get("apscheduler")
    sys.modules["apscheduler"] = None  # type: ignore[assignment]
    try:
        result = run_once(_pipeline(), input=_In(v=3))
        assert result.v == 6
    finally:
        if saved is None:
            sys.modules.pop("apscheduler", None)
        else:
            sys.modules["apscheduler"] = saved


# ── Scheduler — ImportError when apscheduler missing ─────────────────────────

def test_scheduler_raises_import_error_when_apscheduler_missing() -> None:
    mock_modules: dict[str, Any] = {
        "apscheduler": None,
        "apscheduler.schedulers": None,
        "apscheduler.schedulers.asyncio": None,
    }
    with patch.dict(sys.modules, mock_modules):
        import importlib
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        with pytest.raises(ImportError, match="apscheduler"):
            sched_mod.Scheduler()


# ── Scheduler — normal operation (mocked apscheduler) ────────────────────────

def _make_mock_sched_cls() -> tuple[MagicMock, MagicMock]:
    """(MockAsyncIOScheduler 클래스, 인스턴스)를 반환한다."""
    mock_instance = MagicMock()
    mock_instance.start = MagicMock()
    mock_instance.shutdown = MagicMock()
    mock_instance.add_job = MagicMock()
    mock_cls = MagicMock(return_value=mock_instance)
    return mock_cls, mock_instance


def _patch_apscheduler(mock_cls: MagicMock) -> Any:
    mock_asyncio_module = MagicMock()
    mock_asyncio_module.AsyncIOScheduler = mock_cls
    mock_cron_trigger = MagicMock()
    mock_cron_trigger.from_crontab = MagicMock(return_value=MagicMock())
    mock_triggers_cron = MagicMock()
    mock_triggers_cron.CronTrigger = mock_cron_trigger
    return patch.dict(
        sys.modules,
        {
            "apscheduler": MagicMock(),
            "apscheduler.schedulers": MagicMock(),
            "apscheduler.schedulers.asyncio": mock_asyncio_module,
            "apscheduler.triggers": MagicMock(),
            "apscheduler.triggers.cron": mock_triggers_cron,
        },
    )


def test_scheduler_add_interval_job() -> None:
    import importlib
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        s.add(_pipeline(), input=_In(v=1), interval_seconds=300, job_id="check")
    mock_instance.add_job.assert_called_once()
    call_kwargs = mock_instance.add_job.call_args
    assert call_kwargs.kwargs.get("seconds") == 300 or call_kwargs[1].get("seconds") == 300


def test_scheduler_add_cron_job() -> None:
    import importlib
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        s.add(_pipeline(), input=_In(v=1), cron="0 9 * * *", job_id="daily")
    mock_instance.add_job.assert_called_once()


def test_scheduler_add_requires_trigger() -> None:
    import importlib
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        with pytest.raises(ValueError, match="cron 또는 interval_seconds"):
            s.add(_pipeline(), input=_In(v=1))


def test_scheduler_add_disallows_both_triggers() -> None:
    import importlib
    mock_cls, _ = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        with pytest.raises(ValueError, match="동시에"):
            s.add(_pipeline(), input=_In(v=1), cron="0 9 * * *", interval_seconds=300)


def test_scheduler_start_calls_sched_start() -> None:
    import importlib
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        asyncio.run(s.start())
    mock_instance.start.assert_called_once()


def test_scheduler_stop_calls_shutdown() -> None:
    import importlib
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        asyncio.run(s.stop())
    mock_instance.shutdown.assert_called_once()


def test_scheduler_stop_after_start() -> None:
    import importlib
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()

        async def _run() -> None:
            await s.start()
            await s.stop()

        asyncio.run(_run())
    mock_instance.start.assert_called_once()
    mock_instance.shutdown.assert_called_once()


def test_scheduler_interval_trigger_fires(monkeypatch: pytest.MonkeyPatch) -> None:
    """interval 잡이 등록되면 add_job 에 callable 이 전달된다."""
    import importlib
    mock_cls, mock_instance = _make_mock_sched_cls()
    with _patch_apscheduler(mock_cls):
        import pylego_blocks.scheduler as sched_mod
        importlib.reload(sched_mod)
        s = sched_mod.Scheduler()
        s.add(_pipeline(), input=_In(v=7), interval_seconds=1, job_id="fire")
    call = mock_instance.add_job.call_args
    # 첫 번째 positional arg 가 callable 이어야 한다
    func = call[0][0] if call[0] else call.kwargs.get("func")
    assert callable(func)
    # callable 을 직접 실행하면 파이프라인이 돌아야 한다
    result = asyncio.run(func())
    assert result is None  # _run() 반환값 없음
