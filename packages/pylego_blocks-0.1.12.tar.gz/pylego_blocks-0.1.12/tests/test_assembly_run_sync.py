from __future__ import annotations

import time

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class In(Stud):
    v: int = 0


class Mid(Stud):
    x: int = 0


class Out(Stud):
    ok: bool = True


class SyncBlock(Block[In, Mid]):
    input_model = In
    output_model = Mid

    async def run(self, inp: In) -> Mid:
        # synchronous work simulated by immediate return
        return Mid(x=inp.v + 1)


import asyncio


class AsyncBlock(Block[Mid, Out]):
    input_model = Mid
    output_model = Out

    async def run(self, inp: Mid) -> Out:
        await asyncio.sleep(0.02)
        return Out(ok=bool(inp.x))


def test_run_sync_with_mixed_blocks() -> None:
    a = SyncBlock()
    b = AsyncBlock()
    asm = Assembly([a, b])
    start = time.monotonic()
    out = asm.run_sync(In(v=2))
    elapsed = time.monotonic() - start
    assert isinstance(out, Out)
    assert out.ok is True
    assert elapsed >= 0.02
