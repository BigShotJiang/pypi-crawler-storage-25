"""M98 — BlockRuntimeStat 추세 분석 + UCB 스마트 정렬 테스트."""

from __future__ import annotations

import math

import pytest

from pylego_blocks import Block, Stud
from pylego_blocks.registry import BlockRegistry, BlockRuntimeStat, register


# ── 더미 블록 ─────────────────────────────────────────────────────────────────


class _In(Stud):
    v: int


class _Out(Stud):
    v: int


class _BlockA(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v)


class _BlockB(Block[_In, _Out]):
    input_model = _In
    output_model = _Out

    async def run(self, inp: _In) -> _Out:
        return _Out(v=inp.v * 2)


# ── recent_failure_rate ───────────────────────────────────────────────────────


def test_recent_failure_rate_empty() -> None:
    stat = BlockRuntimeStat()
    assert stat.recent_failure_rate == 0.0


def test_recent_failure_rate_all_success() -> None:
    stat = BlockRuntimeStat()
    for _ in range(10):
        stat.recent_runs.append(True)
    assert stat.recent_failure_rate == 0.0


def test_recent_failure_rate_all_failure() -> None:
    stat = BlockRuntimeStat()
    for _ in range(10):
        stat.recent_runs.append(False)
    assert stat.recent_failure_rate == 1.0


def test_recent_failure_rate_mixed() -> None:
    stat = BlockRuntimeStat()
    for _ in range(8):
        stat.recent_runs.append(True)
    for _ in range(2):
        stat.recent_runs.append(False)
    assert stat.recent_failure_rate == pytest.approx(0.2)


def test_recent_runs_maxlen_20() -> None:
    """최근 20회 초과 시 오래된 항목이 제거된다."""
    stat = BlockRuntimeStat()
    for _ in range(25):
        stat.recent_runs.append(True)
    assert len(stat.recent_runs) == 20


# ── trend 판정 ────────────────────────────────────────────────────────────────


def test_trend_stable_when_no_data() -> None:
    stat = BlockRuntimeStat()
    assert stat.trend == "stable"


def test_trend_stable_normal() -> None:
    stat = BlockRuntimeStat(success_count=90, failure_count=10)
    for _ in range(9):
        stat.recent_runs.append(True)
    stat.recent_runs.append(False)  # recent_failure_rate=0.1, overall=0.1
    assert stat.trend == "stable"


def test_trend_degrading() -> None:
    """최근 실패율이 전체의 1.5배 이상이고 최소 5회 샘플 → degrading."""
    stat = BlockRuntimeStat(success_count=90, failure_count=10)  # overall 10%
    # recent: 5 fail / 5 success = 50% → 50% >= 10% × 1.5 (15%)
    for _ in range(5):
        stat.recent_runs.append(True)
    for _ in range(5):
        stat.recent_runs.append(False)
    assert stat.trend == "degrading"
    assert stat.is_degrading is True


def test_trend_improving() -> None:
    """최근 실패율이 전체의 0.8배 이하 → improving."""
    stat = BlockRuntimeStat(success_count=50, failure_count=50)  # overall 50%
    # recent: 0 fail / 10 success = 0% → 0% <= 50% × 0.8 (40%)
    for _ in range(10):
        stat.recent_runs.append(True)
    assert stat.trend == "improving"


def test_trend_degrading_requires_min_5_samples() -> None:
    """4개 샘플만으로는 degrading 판정 안 됨."""
    stat = BlockRuntimeStat(success_count=90, failure_count=10)
    for _ in range(2):
        stat.recent_runs.append(True)
    for _ in range(2):
        stat.recent_runs.append(False)  # 4 samples
    assert stat.trend != "degrading"


# ── is_degrading ─────────────────────────────────────────────────────────────


def test_is_degrading_false_by_default() -> None:
    assert BlockRuntimeStat().is_degrading is False


# ── ucb_score ─────────────────────────────────────────────────────────────────


def test_ucb_score_zero_runs() -> None:
    stat = BlockRuntimeStat()
    assert stat.ucb_score == 0.0


def test_ucb_score_formula() -> None:
    """ucb_score = risk_adjusted_confidence × log1p(total_runs).
    직접 생성 시 weighted_failure_sum=0 → risk_adjusted_confidence=confidence=1.0.
    """
    stat = BlockRuntimeStat(success_count=8, failure_count=2)  # total=10, conf=1.0
    expected = 1.0 * math.log1p(10)
    assert stat.ucb_score == pytest.approx(expected)


def test_ucb_score_new_block_vs_established() -> None:
    """소수 샘플 블록은 UCB 점수가 낮다 (탐색 보너스 효과)."""
    # established: 1000회 90% → 0.9 × log1p(1000) ≈ 6.2
    established = BlockRuntimeStat(success_count=900, failure_count=100)
    # new: 5회 100% → 1.0 × log1p(5) ≈ 1.79
    new_block = BlockRuntimeStat(success_count=5, failure_count=0)
    assert established.ucb_score > new_block.ucb_score


# ── update_stat 후 recent_runs 반영 ──────────────────────────────────────────


def test_update_stat_appends_recent_runs() -> None:
    reg = BlockRegistry()
    reg.register(_BlockA, description="test")
    reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)
    reg.update_stat("_BlockA", success=False, elapsed_sec=0.2, error="err")
    stat = reg.describe("_BlockA").runtime
    assert stat is not None
    assert list(stat.recent_runs) == [True, False]


def test_update_stat_total_runs() -> None:
    reg = BlockRegistry()
    reg.register(_BlockA, description="test")
    for _ in range(3):
        reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)
    stat = reg.describe("_BlockA").runtime
    assert stat is not None
    assert stat.total_runs == 3


# ── sort_by="smart" ───────────────────────────────────────────────────────────


def test_search_sort_by_smart() -> None:
    reg = BlockRegistry()
    reg.register(_BlockA, tags=["db"], description="block a")
    reg.register(_BlockB, tags=["db"], description="block b")

    # _BlockA: 900 success / 100 fail → high UCB
    for _ in range(900):
        reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)
    for _ in range(100):
        reg.update_stat("_BlockA", success=False, elapsed_sec=0.2, error="e")

    # _BlockB: 5 success / 0 fail → low UCB (소수 샘플)
    for _ in range(5):
        reg.update_stat("_BlockB", success=True, elapsed_sec=0.05)

    results = reg.search("block", sort_by="smart")
    assert results[0].name == "_BlockA"
    assert results[1].name == "_BlockB"


def test_search_sort_by_success_rate_unchanged() -> None:
    """sort_by='success_rate' 기존 동작 유지."""
    reg = BlockRegistry()
    reg.register(_BlockA, tags=["db"], description="block a")
    reg.register(_BlockB, tags=["db"], description="block b")

    for _ in range(5):
        reg.update_stat("_BlockA", success=True, elapsed_sec=0.1)
    for _ in range(5):
        reg.update_stat("_BlockA", success=False, elapsed_sec=0.2, error="e")

    for _ in range(10):
        reg.update_stat("_BlockB", success=True, elapsed_sec=0.05)

    results = reg.search("block", sort_by="success_rate")
    assert results[0].name == "_BlockB"
