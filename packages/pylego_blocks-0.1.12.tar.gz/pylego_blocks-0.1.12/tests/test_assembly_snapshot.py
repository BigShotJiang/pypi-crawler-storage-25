from __future__ import annotations

import json
import os
from pathlib import Path

from pylego_blocks.core.assembly import Assembly
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


def test_simple_assembly_matches_golden(tmp_path: Path) -> None:
    """Construct a small Assembly and compare serialized metadata to a golden snapshot.

    Snapshot contents are intentionally simple and human-readable: assembly name,
    block class names and their describe() strings, plus input/output model names.
    """

    class InModel(Stud):
        pass

    class MidModel(Stud):
        pass

    class OutModel(Stud):
        pass

    class ABlock(Block[InModel, MidModel]):
        input_model = InModel
        output_model = MidModel

        async def run(self, inp: InModel) -> MidModel:
            return MidModel()

    class BBlock(Block[MidModel, OutModel]):
        input_model = MidModel
        output_model = OutModel

        async def run(self, inp: MidModel) -> OutModel:
            return OutModel()

    a = ABlock()
    b = BBlock()
    assembly: Assembly[Stud, Stud] = Assembly([a, b], name="simple")

    got = {
        "name": assembly.name,
        "blocks": [
            {"name": block.name, "describe": block.__class__.describe()} for block in assembly.blocks
        ],
        "input_model": assembly.input_model.__name__,
        "output_model": assembly.output_model.__name__,
    }

    fixtures_dir = Path(__file__).parent / "fixtures"
    golden_path = fixtures_dir / "golden_assembly.json"

    if os.environ.get("PYLEGO_UPDATE_GOLDEN") == "1":
        fixtures_dir.mkdir(parents=True, exist_ok=True)
        golden_path.write_text(
            json.dumps(got, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        return

    assert golden_path.exists(), f"golden snapshot missing: {golden_path}"
    expected = json.loads(golden_path.read_text(encoding="utf-8"))
    assert got == expected, (
        "Golden mismatch. Run `PYLEGO_UPDATE_GOLDEN=1 uv run pytest tests/test_assembly_snapshot.py` "
        "to refresh."
    )
