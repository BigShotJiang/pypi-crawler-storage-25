"""HttpBlock 단위 테스트."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from pylego_blocks.blocks.http import HttpBlock
from pylego_blocks.core.stud import Stud


# ---------------------------------------------------------------------------
# 테스트용 더미 Stud / Block
# ---------------------------------------------------------------------------


class DummyInput(Stud):
    value: str


class DummyOutput(Stud):
    result: str


class DummyHttpBlock(HttpBlock[DummyInput, DummyOutput]):
    input_model = DummyInput
    output_model = DummyOutput
    _extra = "pylego[dummy]"

    def _build_request(
        self, inp: DummyInput
    ) -> tuple[str, str, dict[str, Any]]:
        return "POST", "https://example.com/api", {"value": inp.value}

    def _parse_response(self, data: dict[str, Any]) -> DummyOutput:
        return DummyOutput(result=str(data["result"]))


# ---------------------------------------------------------------------------
# httpx stub 유틸
# ---------------------------------------------------------------------------


def _make_httpx_stub(
    response_data: dict[str, Any] | None = None,
    status_code: int = 200,
) -> types.ModuleType:
    if response_data is None:
        response_data = {"result": "ok"}

    mod = types.ModuleType("httpx")

    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = response_data
    if status_code >= 400:
        resp.raise_for_status.side_effect = Exception(f"HTTP {status_code}")
    else:
        resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    mod.AsyncClient = MagicMock(return_value=client)  # type: ignore[attr-defined]
    sys.modules["httpx"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_httpx() -> Generator[None, None, None]:
    import importlib
    real_httpx = importlib.import_module("httpx")
    saved_http = sys.modules.get("pylego_blocks.blocks.http")
    yield
    sys.modules["httpx"] = real_httpx
    if saved_http is not None:
        sys.modules["pylego_blocks.blocks.http"] = saved_http
    else:
        sys.modules.pop("pylego_blocks.blocks.http", None)


# ---------------------------------------------------------------------------
# test_http_block_abstract: 직접 인스턴스화 불가
# ---------------------------------------------------------------------------


def test_http_block_abstract() -> None:
    """HttpBlock 은 추상 클래스이므로 직접 인스턴스화할 수 없다."""

    # _build_request / _parse_response 미구현 서브클래스 — 여전히 추상
    class IncompleteBlock(HttpBlock[DummyInput, DummyOutput]):
        input_model = DummyInput
        output_model = DummyOutput

    with pytest.raises(TypeError):
        IncompleteBlock()  # type: ignore[abstract]


# ---------------------------------------------------------------------------
# test_http_block_run_success: 정상 동작
# ---------------------------------------------------------------------------


async def test_http_block_run_success() -> None:
    """_build_request / _parse_response 를 구현한 서브클래스가 정상 동작한다."""
    _make_httpx_stub(response_data={"result": "hello"})
    block = DummyHttpBlock()
    out = await block.run(DummyInput(value="test"))
    assert isinstance(out, DummyOutput)
    assert out.result == "hello"


async def test_http_block_run_passes_correct_request() -> None:
    """_build_request 가 반환한 method/url/body 로 client.request 가 호출된다."""
    stub = _make_httpx_stub(response_data={"result": "x"})
    block = DummyHttpBlock()
    await block.run(DummyInput(value="ping"))

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    assert call_args[0][0] == "POST"
    assert call_args[0][1] == "https://example.com/api"
    assert call_args[1]["json"] == {"value": "ping"}


# ---------------------------------------------------------------------------
# test_http_block_import_error: httpx 미설치 시 ImportError + 힌트 메시지
# ---------------------------------------------------------------------------


async def test_http_block_import_error() -> None:
    """httpx 가 없을 때 _extra 가 포함된 ImportError 를 발생시킨다."""
    sys.modules["httpx"] = None  # type: ignore[assignment]
    block = DummyHttpBlock()
    with pytest.raises(ImportError, match="pylego\\[dummy\\]"):
        await block.run(DummyInput(value="x"))


async def test_http_block_import_error_message_contains_httpx() -> None:
    """ImportError 메시지에 'httpx' 키워드가 포함된다."""
    sys.modules["httpx"] = None  # type: ignore[assignment]
    block = DummyHttpBlock()
    with pytest.raises(ImportError, match="httpx"):
        await block.run(DummyInput(value="x"))


# ---------------------------------------------------------------------------
# test_http_block_http_error: 4xx/5xx 전파
# ---------------------------------------------------------------------------


async def test_http_block_http_error_4xx() -> None:
    """4xx 응답은 raise_for_status() 를 통해 예외가 전파된다."""
    _make_httpx_stub(status_code=404)
    block = DummyHttpBlock()
    with pytest.raises(Exception, match="HTTP 404"):
        await block.run(DummyInput(value="x"))


async def test_http_block_http_error_5xx() -> None:
    """5xx 응답은 raise_for_status() 를 통해 예외가 전파된다."""
    _make_httpx_stub(status_code=500)
    block = DummyHttpBlock()
    with pytest.raises(Exception, match="HTTP 500"):
        await block.run(DummyInput(value="x"))


# ---------------------------------------------------------------------------
# test_telegram_still_works: TelegramBlock 기존 동작 확인
# ---------------------------------------------------------------------------


async def test_telegram_still_works() -> None:
    """TelegramBlock 이 HttpBlock 으로 리팩토링된 후에도 기존 동작을 유지한다."""
    from pylego_blocks.blocks.notification.telegram import TelegramBlock, TelegramInput, TelegramResult

    mod = types.ModuleType("httpx")
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "ok": True,
        "result": {"message_id": 77, "chat": {"id": "555"}},
    }
    resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    mod.AsyncClient = MagicMock(return_value=client)  # type: ignore[attr-defined]
    sys.modules["httpx"] = mod

    block = TelegramBlock(token="test_tok")
    result = await block.run(TelegramInput(chat_id="555", text="Works!"))
    assert isinstance(result, TelegramResult)
    assert result.message_id == 77
    assert result.chat_id == "555"
