"""TelegramBlock 단위 테스트 — httpx 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from unittest.mock import AsyncMock, MagicMock

import pytest

from pylego_blocks import Assembly, TapBlock
from pylego_blocks.blocks.notification.telegram import TelegramBlock, TelegramInput, TelegramResult


# ---------------------------------------------------------------------------
# httpx stub
# ---------------------------------------------------------------------------

def _make_httpx_stub(
    ok: bool = True,
    message_id: int = 42,
    chat_id: str = "123456",
    status_code: int = 200,
) -> types.ModuleType:
    mod = types.ModuleType("httpx")

    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = {
        "ok": ok,
        "result": {"message_id": message_id, "chat": {"id": chat_id}},
    }
    if status_code >= 400:
        resp.raise_for_status.side_effect = Exception(f"HTTP {status_code}")
    else:
        resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    async_client_cls = MagicMock(return_value=client)
    mod.AsyncClient = async_client_cls  # type: ignore[attr-defined]

    sys.modules["httpx"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_httpx() -> Generator[None, None, None]:
    import importlib
    real_httpx = importlib.import_module("httpx")
    saved_telegram = sys.modules.get("pylego_blocks.blocks.notification.telegram")
    saved_http = sys.modules.get("pylego_blocks.blocks.http")
    yield
    sys.modules["httpx"] = real_httpx
    if saved_telegram is not None:
        sys.modules["pylego_blocks.blocks.notification.telegram"] = saved_telegram
    else:
        sys.modules.pop("pylego_blocks.blocks.notification.telegram", None)
    if saved_http is not None:
        sys.modules["pylego_blocks.blocks.http"] = saved_http
    else:
        sys.modules.pop("pylego_blocks.blocks.http", None)


# ---------------------------------------------------------------------------
# 생성자 검증
# ---------------------------------------------------------------------------


def test_token_required_raises() -> None:
    import os
    os.environ.pop("PYLEGO_TELEGRAM_TOKEN", None)
    with pytest.raises(ValueError, match="token"):
        TelegramBlock()


def test_token_from_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_TELEGRAM_TOKEN", "env_token")
    block = TelegramBlock()
    assert block._token == "env_token"


def test_token_from_arg() -> None:
    block = TelegramBlock(token="arg_token")
    assert block._token == "arg_token"


def test_arg_takes_precedence_over_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_TELEGRAM_TOKEN", "env_token")
    block = TelegramBlock(token="arg_token")
    assert block._token == "arg_token"


# ---------------------------------------------------------------------------
# 정상 전송
# ---------------------------------------------------------------------------


async def test_run_returns_telegram_result() -> None:
    _make_httpx_stub(message_id=99, chat_id="111")
    block = TelegramBlock(token="test_token")
    result = await block.run(TelegramInput(chat_id="111", text="Hello"))
    assert isinstance(result, TelegramResult)
    assert result.message_id == 99
    assert result.chat_id == "111"


async def test_run_sends_correct_payload() -> None:
    stub = _make_httpx_stub()
    block = TelegramBlock(token="mytoken")
    await block.run(TelegramInput(chat_id="999", text="테스트", parse_mode="Markdown"))

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    # request(method, url, json=body) 형태로 호출됨
    assert call_args[0][0] == "POST"
    assert "sendMessage" in call_args[0][1]
    call_kwargs = call_args[1]["json"]
    assert call_kwargs["chat_id"] == "999"
    assert call_kwargs["text"] == "테스트"
    assert call_kwargs["parse_mode"] == "Markdown"


async def test_default_parse_mode_is_html() -> None:
    stub = _make_httpx_stub()
    block = TelegramBlock(token="tok")
    await block.run(TelegramInput(chat_id="1", text="hi"))

    client_instance = stub.AsyncClient.return_value
    call_kwargs = client_instance.request.call_args[1]["json"]
    assert call_kwargs["parse_mode"] == "HTML"


# ---------------------------------------------------------------------------
# 오류 처리
# ---------------------------------------------------------------------------


async def test_http_error_raises() -> None:
    _make_httpx_stub(status_code=400)
    block = TelegramBlock(token="tok")
    with pytest.raises(Exception):
        await block.run(TelegramInput(chat_id="1", text="hi"))


async def test_api_not_ok_raises_runtime_error() -> None:
    _make_httpx_stub(ok=False)
    block = TelegramBlock(token="tok")
    with pytest.raises(RuntimeError, match="Telegram API 오류"):
        await block.run(TelegramInput(chat_id="1", text="hi"))


async def test_import_error_without_httpx() -> None:
    sys.modules["httpx"] = None  # type: ignore[assignment]
    block = TelegramBlock(token="tok")
    with pytest.raises(ImportError, match="httpx"):
        await block.run(TelegramInput(chat_id="1", text="hi"))


# ---------------------------------------------------------------------------
# TapBlock 통합
# ---------------------------------------------------------------------------


async def test_tapblock_integration() -> None:
    from pylego_blocks import Stud
    from pylego_blocks.core.block import Block

    class Msg(Stud):
        content: str

    class SourceBlock(Block[Msg, TelegramInput]):
        input_model = Msg
        output_model = TelegramInput

        async def run(self, inp: Msg) -> TelegramInput:
            return TelegramInput(chat_id="777", text=inp.content)

    _make_httpx_stub(message_id=5, chat_id="777")

    pipeline: Assembly[Msg, TelegramInput] = Assembly([
        SourceBlock(),
        TapBlock(TelegramBlock(token="tok")),
    ])
    result = await pipeline.run(Msg(content="알림"))
    # TapBlock 은 원본 TelegramInput 을 그대로 통과시킨다
    assert isinstance(result, TelegramInput)
    assert result.text == "알림"
