"""DiscordBlock 단위 테스트 — httpx 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from unittest.mock import AsyncMock, MagicMock

import pytest

from pylego_blocks.blocks.notification.discord import DiscordBlock, DiscordInput, DiscordResult


# ---------------------------------------------------------------------------
# httpx stub
# ---------------------------------------------------------------------------


def _make_httpx_stub(
    status_code: int = 200,
    response_json: dict[str, object] | None = None,
) -> types.ModuleType:
    mod = types.ModuleType("httpx")

    if response_json is None:
        response_json = {"id": "123456789", "content": "test"}

    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = response_json
    if status_code >= 400:
        resp.raise_for_status.side_effect = Exception(f"HTTP {status_code}")
    else:
        resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    async_client_cls = MagicMock(return_value=client)
    mod.AsyncClient = async_client_cls  # type: ignore[attr-defined]

    sys.modules["httpx"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_httpx() -> Generator[None, None, None]:
    import importlib
    real_httpx = importlib.import_module("httpx")
    saved_discord = sys.modules.get("pylego_blocks.blocks.notification.discord")
    saved_http = sys.modules.get("pylego_blocks.blocks.http")
    yield
    sys.modules["httpx"] = real_httpx
    if saved_discord is not None:
        sys.modules["pylego_blocks.blocks.notification.discord"] = saved_discord
    else:
        sys.modules.pop("pylego_blocks.blocks.notification.discord", None)
    if saved_http is not None:
        sys.modules["pylego_blocks.blocks.http"] = saved_http
    else:
        sys.modules.pop("pylego_blocks.blocks.http", None)


# ---------------------------------------------------------------------------
# 생성자 검증
# ---------------------------------------------------------------------------


def test_discord_missing_webhook_url() -> None:
    import os
    os.environ.pop("PYLEGO_DISCORD_WEBHOOK_URL", None)
    with pytest.raises(ValueError, match="webhook_url"):
        DiscordBlock()


def test_discord_env_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/env/token")
    block = DiscordBlock()
    assert block._webhook_url == "https://discord.com/api/webhooks/env/token"


def test_webhook_url_from_arg() -> None:
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/arg/token")
    assert block._webhook_url == "https://discord.com/api/webhooks/arg/token"


def test_arg_takes_precedence_over_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_DISCORD_WEBHOOK_URL", "https://discord.com/api/webhooks/env/token")
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/arg/token")
    assert block._webhook_url == "https://discord.com/api/webhooks/arg/token"


# ---------------------------------------------------------------------------
# 정상 전송
# ---------------------------------------------------------------------------


async def test_discord_send_success() -> None:
    _make_httpx_stub(status_code=200)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    result = await block.run(DiscordInput(content="파이프라인 완료"))
    assert isinstance(result, DiscordResult)
    assert result.ok is True


async def test_discord_send_success_payload() -> None:
    stub = _make_httpx_stub(status_code=200)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    await block.run(DiscordInput(content="테스트 메시지"))

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    assert call_args[0][0] == "POST"
    assert "wait=true" in call_args[0][1]
    body = call_args[1]["json"]
    assert body["content"] == "테스트 메시지"
    assert "username" not in body
    assert "embeds" not in body


async def test_discord_send_with_embeds() -> None:
    stub = _make_httpx_stub(status_code=200)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    embed: dict[str, object] = {"title": "알림", "description": "작업이 완료되었습니다.", "color": 3066993}
    result = await block.run(DiscordInput(content="완료", embeds=[embed]))
    assert isinstance(result, DiscordResult)
    assert result.ok is True

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    body = call_args[1]["json"]
    assert "embeds" in body
    assert body["embeds"][0]["title"] == "알림"


async def test_discord_send_with_username() -> None:
    stub = _make_httpx_stub(status_code=200)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    result = await block.run(DiscordInput(content="안녕하세요", username="pylego-bot"))
    assert isinstance(result, DiscordResult)
    assert result.ok is True

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    body = call_args[1]["json"]
    assert body["username"] == "pylego-bot"


async def test_discord_none_username_excluded() -> None:
    stub = _make_httpx_stub(status_code=200)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    await block.run(DiscordInput(content="메시지", username=None))

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    body = call_args[1]["json"]
    assert "username" not in body


async def test_discord_empty_embeds_excluded() -> None:
    stub = _make_httpx_stub(status_code=200)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    await block.run(DiscordInput(content="메시지", embeds=[]))

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    body = call_args[1]["json"]
    assert "embeds" not in body


# ---------------------------------------------------------------------------
# 오류 처리
# ---------------------------------------------------------------------------


async def test_discord_http_error() -> None:
    _make_httpx_stub(status_code=400)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    with pytest.raises(Exception):
        await block.run(DiscordInput(content="오류 테스트"))


async def test_discord_http_401_error() -> None:
    _make_httpx_stub(status_code=401)
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    with pytest.raises(Exception):
        await block.run(DiscordInput(content="인증 오류"))


async def test_discord_import_error_without_httpx() -> None:
    sys.modules["httpx"] = None  # type: ignore[assignment]
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/123/token")
    with pytest.raises(ImportError, match="httpx"):
        await block.run(DiscordInput(content="임포트 오류"))
