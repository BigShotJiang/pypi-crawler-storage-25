"""HttpSessionUnit 단위 테스트 — httpx mock 기반."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks.blocks.http_session import HttpSession, HttpSessionInput, HttpSessionUnit


def _make_login_response(
    status_code: int = 200,
    json_data: dict | None = None,
    cookies: dict[str, str] | None = None,
) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.cookies = cookies or {}
    _json = json_data or {}
    resp.json = MagicMock(return_value=_json)
    resp.raise_for_status = MagicMock()
    return resp


def _make_client(login_resp: MagicMock, probe_resp: MagicMock | None = None) -> MagicMock:
    client = AsyncMock()
    if probe_resp is not None:
        client.request = AsyncMock(return_value=login_resp)
        client.get = AsyncMock(return_value=probe_resp)
    else:
        client.request = AsyncMock(return_value=login_resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


def test_token_extracted_from_response() -> None:
    """token_field 지정 시 헤더에 Bearer 토큰이 주입된다."""
    unit = HttpSessionUnit()
    login_resp = _make_login_response(json_data={"access_token": "tok123"})
    client = _make_client(login_resp)

    with patch("httpx.AsyncClient", return_value=client):
        session: HttpSession = asyncio.run(
            unit.run(HttpSessionInput(
                login_url="https://api.example.com/login",
                credentials={"username": "u", "password": "p"},
                token_field="access_token",
            ))
        )

    assert session.headers["Authorization"] == "Bearer tok123"
    assert session.raw == {"access_token": "tok123"}


def test_cookies_extracted() -> None:
    """쿠키 기반 응답에서 cookies가 채워진다."""
    unit = HttpSessionUnit()
    login_resp = _make_login_response(cookies={"session_id": "abc"})
    client = _make_client(login_resp)

    with patch("httpx.AsyncClient", return_value=client):
        session = asyncio.run(
            unit.run(HttpSessionInput(
                login_url="https://api.example.com/login",
                credentials={"user": "u"},
            ))
        )

    assert session.cookies["session_id"] == "abc"
    assert session.headers == {}


def test_verify_url_ok() -> None:
    """verify_url probe가 200이면 검증 통과한다."""
    unit = HttpSessionUnit()
    login_resp = _make_login_response(json_data={"access_token": "t"})
    probe_resp = MagicMock()
    probe_resp.status_code = 200
    client = _make_client(login_resp, probe_resp)

    with patch("httpx.AsyncClient", return_value=client):
        asyncio.run(
            unit.verify(
                HttpSessionInput(
                    login_url="https://api.example.com/login",
                    credentials={"user": "u"},
                    verify_url="https://api.example.com/me",
                ),
                HttpSession(headers={"Authorization": "Bearer t"}),
            )
        )

    client.get.assert_called_once()


def test_verify_url_fail_raises() -> None:
    """verify_url probe가 401이면 ValueError가 발생한다."""
    unit = HttpSessionUnit()
    login_resp = _make_login_response()
    probe_resp = MagicMock()
    probe_resp.status_code = 401
    client = _make_client(login_resp, probe_resp)

    with patch("httpx.AsyncClient", return_value=client):
        with pytest.raises(ValueError, match="세션 검증 실패"):
            asyncio.run(
                unit.verify(
                    HttpSessionInput(
                        login_url="https://api.example.com/login",
                        credentials={"user": "u"},
                        verify_url="https://api.example.com/me",
                    ),
                    HttpSession(),
                )
            )


def test_validate_empty_credentials_raises() -> None:
    """credentials가 비어 있으면 validate에서 ValueError가 발생한다."""
    unit = HttpSessionUnit()

    with pytest.raises(ValueError, match="credentials"):
        asyncio.run(
            unit.validate(
                HttpSessionInput(
                    login_url="https://api.example.com/login",
                    credentials={},
                )
            )
        )


def test_no_token_field_no_auth_header() -> None:
    """token_field 미지정 시 headers가 비어 있다."""
    unit = HttpSessionUnit()
    login_resp = _make_login_response(json_data={"data": "ok"})
    client = _make_client(login_resp)

    with patch("httpx.AsyncClient", return_value=client):
        session = asyncio.run(
            unit.run(HttpSessionInput(
                login_url="https://api.example.com/login",
                credentials={"user": "u"},
            ))
        )

    assert session.headers == {}
