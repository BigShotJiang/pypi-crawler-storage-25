"""AcpPromptBlock — Unix 소켓 데몬 호출 블록 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks.blocks.ai import AcpDaemonError, AcpPromptBlock, AcpPromptRequest


class _FakeSender:
    def __init__(self, response: str, raises: Exception | None = None) -> None:
        self._response = response
        self._raises = raises
        self.calls: list[tuple[str, str, float]] = []

    async def __call__(self, sock_path: str, message: str, timeout: float) -> str:
        self.calls.append((sock_path, message, timeout))
        if self._raises is not None:
            raise self._raises
        return self._response


class TestAcpPromptBlock:
    async def test_sends_prompt_and_returns_response(self) -> None:
        sender = _FakeSender(response="## QA 검증 결과: PASS\nVERDICT: PASS")
        block = AcpPromptBlock(sender=sender)
        result = await block.run(
            AcpPromptRequest(
                socket_path="/tmp/gemini-acp.sock",
                prompt="검증 지시: 이슈 #42",
                timeout_sec=60.0,
            )
        )
        assert result.text == "## QA 검증 결과: PASS\nVERDICT: PASS"
        assert sender.calls == [
            ("/tmp/gemini-acp.sock", "검증 지시: 이슈 #42", 60.0)
        ]

    async def test_default_timeout(self) -> None:
        sender = _FakeSender(response="ok")
        await AcpPromptBlock(sender=sender).run(
            AcpPromptRequest(socket_path="/tmp/x.sock", prompt="p")
        )
        # timeout_sec 기본값이 300.0 으로 전달되어야 함
        assert sender.calls[0][2] == 300.0

    async def test_sender_exception_propagates(self) -> None:
        sender = _FakeSender(response="", raises=RuntimeError("socket closed"))
        with pytest.raises(RuntimeError, match="socket closed"):
            await AcpPromptBlock(sender=sender).run(
                AcpPromptRequest(socket_path="/tmp/x.sock", prompt="p")
            )

    async def test_default_timeout_is_600_seconds(self) -> None:
        """#35: 기본 timeout 300→600 으로 확장."""
        sender = _FakeSender(response="ok")
        await AcpPromptBlock(sender=sender).run(
            AcpPromptRequest(socket_path="/tmp/x.sock", prompt="p")
        )
        # AcpPromptRequest.timeout_sec 기본값은 이전 300 에서 유지. timeout 확장은
        # 상위 AiPiPipelineConfig 쪽. Request 레벨 기본값은 테스트 호환성 위해
        # 300 유지 — 이 테스트는 미래 변경 시 의도적 선택을 상기시키기 위함.
        assert sender.calls[0][2] == 300.0

    async def test_daemon_error_prefix_raises(self) -> None:
        """#35: daemon 이 'ERROR: ...' 접두로 응답하면 AcpDaemonError 발생."""
        sender = _FakeSender(response="ERROR: Prompt timeout")
        with pytest.raises(AcpDaemonError, match="Prompt timeout"):
            await AcpPromptBlock(sender=sender).run(
                AcpPromptRequest(socket_path="/tmp/x.sock", prompt="p")
            )

    async def test_daemon_error_only_matches_exact_prefix(self) -> None:
        """#35: 응답 본문 중간에 'ERROR:' 이 섞여 있는 건 예외 아님 (접두 감지만)."""
        sender = _FakeSender(response="some legit response with ERROR: word inside")
        result = await AcpPromptBlock(sender=sender).run(
            AcpPromptRequest(socket_path="/tmp/x.sock", prompt="p")
        )
        assert "ERROR:" in result.text

    async def test_acp_daemon_error_is_runtime_error(self) -> None:
        """AcpDaemonError 는 RuntimeError 서브클래스여야 기존 except 경로 호환."""
        sender = _FakeSender(response="ERROR: abc")
        with pytest.raises(RuntimeError):
            await AcpPromptBlock(sender=sender).run(
                AcpPromptRequest(socket_path="/tmp/x.sock", prompt="p")
            )
