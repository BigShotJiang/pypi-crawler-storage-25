"""GoogleTranslateBlock 단위 테스트 — httpx 없이 Mock 으로 검증."""

from __future__ import annotations

import sys
import types
from collections.abc import Generator
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from pylego_blocks.blocks.translate.google import (
    GoogleTranslateBlock,
    GoogleTranslateInput,
    GoogleTranslateResult,
)


# ---------------------------------------------------------------------------
# httpx stub 헬퍼
# ---------------------------------------------------------------------------


def _make_httpx_stub(
    translated_text: str = "Hello",
    detected_source: str | None = None,
    status_code: int = 200,
) -> types.ModuleType:
    """httpx.AsyncClient 를 흉내 내는 stub 모듈을 sys.modules 에 주입한다."""
    mod = types.ModuleType("httpx")

    translation: dict[str, Any] = {"translatedText": translated_text}
    if detected_source is not None:
        translation["detectedSourceLanguage"] = detected_source

    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = {"data": {"translations": [translation]}}
    if status_code >= 400:
        resp.raise_for_status.side_effect = Exception(f"HTTP {status_code}")
    else:
        resp.raise_for_status.return_value = None

    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    async_client_cls = MagicMock(return_value=client)
    mod.AsyncClient = async_client_cls  # type: ignore[attr-defined]

    sys.modules["httpx"] = mod
    return mod


@pytest.fixture(autouse=True)
def _clear_httpx() -> Generator[None, None, None]:
    import importlib
    real_httpx = importlib.import_module("httpx")
    saved_translate = sys.modules.get("pylego_blocks.blocks.translate.google")
    saved_http = sys.modules.get("pylego_blocks.blocks.http")
    yield
    sys.modules["httpx"] = real_httpx
    if saved_translate is not None:
        sys.modules["pylego_blocks.blocks.translate.google"] = saved_translate
    else:
        sys.modules.pop("pylego_blocks.blocks.translate.google", None)
    if saved_http is not None:
        sys.modules["pylego_blocks.blocks.http"] = saved_http
    else:
        sys.modules.pop("pylego_blocks.blocks.http", None)


# ---------------------------------------------------------------------------
# test_translate_success: 한국어 → 영어 번역
# ---------------------------------------------------------------------------


async def test_translate_success() -> None:
    _make_httpx_stub(translated_text="Hello")
    block = GoogleTranslateBlock(api_key="test_key")
    result = await block.run(GoogleTranslateInput(text="안녕하세요", target="en"))
    assert isinstance(result, GoogleTranslateResult)
    assert result.translated_text == "Hello"
    assert result.detected_source is None


# ---------------------------------------------------------------------------
# test_translate_with_source: source 언어 명시
# ---------------------------------------------------------------------------


async def test_translate_with_source() -> None:
    stub = _make_httpx_stub(translated_text="Hello")
    block = GoogleTranslateBlock(api_key="test_key")
    result = await block.run(
        GoogleTranslateInput(text="안녕하세요", target="en", source="ko")
    )
    assert result.translated_text == "Hello"

    client_instance = stub.AsyncClient.return_value
    call_args = client_instance.request.call_args
    body: dict[str, Any] = call_args[1]["json"]
    assert body.get("source") == "ko"


# ---------------------------------------------------------------------------
# test_translate_detected_source: detectedSourceLanguage 파싱
# ---------------------------------------------------------------------------


async def test_translate_detected_source() -> None:
    _make_httpx_stub(translated_text="Hello", detected_source="ko")
    block = GoogleTranslateBlock(api_key="test_key")
    result = await block.run(GoogleTranslateInput(text="안녕하세요", target="en"))
    assert result.translated_text == "Hello"
    assert result.detected_source == "ko"


# ---------------------------------------------------------------------------
# test_translate_missing_api_key: ValueError
# ---------------------------------------------------------------------------


def test_translate_missing_api_key() -> None:
    import os
    os.environ.pop("PYLEGO_GOOGLE_API_KEY", None)
    with pytest.raises(ValueError, match="api_key"):
        GoogleTranslateBlock()


# ---------------------------------------------------------------------------
# test_translate_env_fallback: PYLEGO_GOOGLE_API_KEY 환경변수
# ---------------------------------------------------------------------------


def test_translate_env_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYLEGO_GOOGLE_API_KEY", "env_key")
    block = GoogleTranslateBlock()
    assert block._api_key == "env_key"


# ---------------------------------------------------------------------------
# test_translate_http_error: 4xx 전파
# ---------------------------------------------------------------------------


async def test_translate_http_error() -> None:
    _make_httpx_stub(status_code=403)
    block = GoogleTranslateBlock(api_key="test_key")
    with pytest.raises(Exception):
        await block.run(GoogleTranslateInput(text="안녕하세요", target="en"))


# ---------------------------------------------------------------------------
# test_translate_pipeline: Assembly 체인에서 사용
# ---------------------------------------------------------------------------


async def test_translate_pipeline() -> None:
    from pylego_blocks import Assembly, Stud
    from pylego_blocks.core.block import Block

    class RawText(Stud):
        content: str

    class ToTranslateInput(Block[RawText, GoogleTranslateInput]):
        input_model = RawText
        output_model = GoogleTranslateInput

        async def run(self, inp: RawText) -> GoogleTranslateInput:
            return GoogleTranslateInput(text=inp.content, target="en")

    _make_httpx_stub(translated_text="Hello World")

    pipeline: Assembly[RawText, GoogleTranslateResult] = Assembly([
        ToTranslateInput(),
        GoogleTranslateBlock(api_key="test_key"),
    ])
    result = await pipeline.run(RawText(content="안녕 세상"))
    assert isinstance(result, GoogleTranslateResult)
    assert result.translated_text == "Hello World"
