"""DbToExcelUnit 단위 테스트 — mock aiomysql + tmp 파일 기반."""

from __future__ import annotations

import importlib.util
import os
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks.blocks.db.db_to_excel import DbToExcelInput, DbToExcelUnit

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("aiomysql") is None
    or importlib.util.find_spec("openpyxl") is None,
    reason="aiomysql or openpyxl not installed",
)


def _make_cursor_mock(rows: list[dict], chunk_size: int = 1000) -> AsyncMock:
    cur = AsyncMock()
    cur.execute = AsyncMock()
    # fetchmany 를 chunk_size 단위로 반환하다가 빈 list 반환
    chunks = [rows[i : i + chunk_size] for i in range(0, len(rows), chunk_size)]
    chunks.append([])
    cur.fetchmany = AsyncMock(side_effect=chunks)
    cur.__aenter__ = AsyncMock(return_value=cur)
    cur.__aexit__ = AsyncMock(return_value=None)
    return cur


def _make_conn_mock(cursor: AsyncMock) -> MagicMock:
    conn = MagicMock()
    conn.cursor = MagicMock(return_value=cursor)
    conn.close = MagicMock()
    return conn


def test_run_writes_excel_file() -> None:
    """정상 실행 시 Excel 파일이 생성되고 row_count 가 일치한다."""
    import asyncio

    rows = [{"id": i, "name": f"user_{i}"} for i in range(5)]
    cursor = _make_cursor_mock(rows)
    conn = _make_conn_mock(cursor)

    unit = DbToExcelUnit(host="h", user="u", password="p", db="d")

    with tempfile.TemporaryDirectory() as tmpdir:
        out = os.path.join(tmpdir, "out.xlsx")
        inp = DbToExcelInput(query="SELECT id, name FROM users", output_path=out)

        with patch("aiomysql.connect", new=AsyncMock(return_value=conn)):
            result = asyncio.run(unit.run(inp))

        assert result.row_count == 5
        assert result.path == out
        assert os.path.isfile(out)
        assert os.path.getsize(out) > 0


def test_validate_missing_directory() -> None:
    """존재하지 않는 출력 디렉터리는 validate 에서 ValueError."""
    import asyncio

    unit = DbToExcelUnit(host="h", user="u", password="p", db="d")
    inp = DbToExcelInput(
        query="SELECT 1", output_path="/nonexistent_dir_xyz/out.xlsx"
    )
    with pytest.raises(ValueError, match="존재하지 않습니다"):
        asyncio.run(unit.validate(inp))


def test_validate_invalid_chunk_size() -> None:
    """chunk_size=0 은 validate 에서 ValueError."""
    import asyncio

    unit = DbToExcelUnit(host="h", user="u", password="p", db="d")
    with tempfile.TemporaryDirectory() as tmpdir:
        inp = DbToExcelInput(
            query="SELECT 1",
            output_path=os.path.join(tmpdir, "out.xlsx"),
            chunk_size=0,
        )
        with pytest.raises(ValueError, match="chunk_size"):
            asyncio.run(unit.validate(inp))


def test_verify_missing_file() -> None:
    """파일이 없으면 verify 에서 RuntimeError."""
    import asyncio
    from pylego_blocks.blocks.db.db_to_excel import DbToExcelResult

    unit = DbToExcelUnit(host="h", user="u", password="p", db="d")
    inp = DbToExcelInput(query="SELECT 1", output_path="/tmp/no_such_file.xlsx")
    result = DbToExcelResult(path="/tmp/no_such_file.xlsx", row_count=0)
    with pytest.raises(RuntimeError, match="생성되지 않았습니다"):
        asyncio.run(unit.verify(inp, result))


def test_chunk_boundary() -> None:
    """chunk_size 경계에서 전체 row_count 가 정확히 집계된다."""
    import asyncio

    rows = [{"v": i} for i in range(7)]  # chunk_size=3 → [3,3,1] + []
    cursor = _make_cursor_mock(rows, chunk_size=3)
    conn = _make_conn_mock(cursor)

    unit = DbToExcelUnit(host="h", user="u", password="p", db="d")

    with tempfile.TemporaryDirectory() as tmpdir:
        out = os.path.join(tmpdir, "out.xlsx")
        inp = DbToExcelInput(query="SELECT v FROM t", output_path=out, chunk_size=3)

        with patch("aiomysql.connect", new=AsyncMock(return_value=conn)):
            result = asyncio.run(unit.run(inp))

        assert result.row_count == 7


def test_empty_result_creates_header_only_file() -> None:
    """쿼리 결과가 없으면 헤더 없이 빈 파일이 생성되고 row_count=0."""
    import asyncio

    cursor = _make_cursor_mock([])
    conn = _make_conn_mock(cursor)

    unit = DbToExcelUnit(host="h", user="u", password="p", db="d")

    with tempfile.TemporaryDirectory() as tmpdir:
        out = os.path.join(tmpdir, "empty.xlsx")
        inp = DbToExcelInput(query="SELECT id FROM t WHERE 1=0", output_path=out)

        with patch("aiomysql.connect", new=AsyncMock(return_value=conn)):
            result = asyncio.run(unit.run(inp))

        assert result.row_count == 0
        assert os.path.isfile(out)
