"""SqliteBlock 단위 테스트 — aiosqlite 기반 SQLite 쿼리 검증."""

from __future__ import annotations

import asyncio
import importlib.util
from typing import Any

import pytest

from pylego_blocks.blocks.db.base import QueryInput
from pylego_blocks.blocks.db.sqlite import SqliteBlock

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("aiosqlite") is None,
    reason="aiosqlite not installed",
)


def test_select_memory() -> None:
    """인메모리 DB에서 SELECT 1 AS n 이 올바르게 반환되어야 한다."""
    block = SqliteBlock(database=":memory:")
    result = asyncio.run(block.run(QueryInput(query="SELECT 1 AS n")))
    assert result.rows == [{"n": 1}]
    assert result.row_count == 1


def test_param_binding() -> None:
    """? 파라미터 바인딩이 올바르게 동작해야 한다."""
    block = SqliteBlock(database=":memory:")
    result = asyncio.run(
        block.run(QueryInput(query="SELECT ? AS v", params=[42]))
    )
    assert result.rows[0]["v"] == 42


def test_insert_and_select(tmp_path: Any) -> None:
    """파일 DB에 INSERT 후 SELECT 결과가 일치해야 한다."""
    db_path = str(tmp_path / "test.db")
    block = SqliteBlock(database=db_path)
    asyncio.run(block.run(QueryInput(query="CREATE TABLE t (id INTEGER)")))
    asyncio.run(
        block.run(QueryInput(query="INSERT INTO t VALUES (?)", params=[1]))
    )
    result = asyncio.run(block.run(QueryInput(query="SELECT id FROM t")))
    assert result.rows == [{"id": 1}]
    assert result.row_count == 1


def test_empty_result() -> None:
    """결과가 없는 쿼리는 빈 rows와 row_count=0을 반환해야 한다."""
    block = SqliteBlock(database=":memory:")
    result = asyncio.run(
        block.run(QueryInput(query="SELECT 1 AS n WHERE 1=0"))
    )
    assert result.rows == []
    assert result.row_count == 0


def test_query_error_propagates() -> None:
    """존재하지 않는 테이블 조회 시 예외가 전파되어야 한다."""
    block = SqliteBlock(database=":memory:")
    with pytest.raises(Exception):
        asyncio.run(block.run(QueryInput(query="SELECT * FROM no_such_table")))
