"""PooledMySqlBlock 단위 테스트 — mock Pool 기반."""

from __future__ import annotations

import asyncio
import importlib.util
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks.blocks.db.base import QueryInput
from pylego_blocks.blocks.db.mysql_pool import PooledMySqlBlock

pytestmark = pytest.mark.skipif(
    importlib.util.find_spec("aiomysql") is None,
    reason="aiomysql not installed",
)


def _make_pool_mock(rows: list[dict[str, object]]) -> MagicMock:
    """mock aiomysql Pool + cursor 를 생성한다."""
    mock_cursor = AsyncMock()
    mock_cursor.execute = AsyncMock()
    mock_cursor.fetchall = AsyncMock(return_value=rows)
    mock_cursor.__aenter__ = AsyncMock(return_value=mock_cursor)
    mock_cursor.__aexit__ = AsyncMock(return_value=None)

    mock_conn = MagicMock()
    mock_conn.cursor = MagicMock(return_value=mock_cursor)

    mock_pool = MagicMock()
    mock_pool.acquire = MagicMock(return_value=_async_context(mock_conn))
    mock_pool.close = MagicMock()
    mock_pool.wait_closed = AsyncMock()
    return mock_pool


def _async_context(obj: object) -> AsyncMock:
    """__aenter__/__aexit__를 가진 비동기 컨텍스트 매니저 mock."""
    cm = AsyncMock()
    cm.__aenter__ = AsyncMock(return_value=obj)
    cm.__aexit__ = AsyncMock(return_value=None)
    return cm


def test_env_var_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    """환경변수로 연결 파라미터를 설정할 수 있어야 한다."""
    monkeypatch.setenv("PYLEGO_MYSQL_HOST", "dbhost")
    monkeypatch.setenv("PYLEGO_MYSQL_USER", "admin")
    monkeypatch.setenv("PYLEGO_MYSQL_DB", "mydb")
    block = PooledMySqlBlock()
    assert block._host == "dbhost"
    assert block._user == "admin"
    assert block._db == "mydb"


def test_explicit_params() -> None:
    """생성자 인수가 환경변수보다 우선해야 한다."""
    block = PooledMySqlBlock(host="h", port=3307, user="u", password="p", db="d")
    assert block._host == "h"
    assert block._port == 3307


def test_pool_sizes() -> None:
    """min_size / max_size 파라미터가 올바르게 저장되어야 한다."""
    block = PooledMySqlBlock(min_size=3, max_size=20)
    assert block._min_size == 3
    assert block._max_size == 20


def test_query_uses_pool() -> None:
    """쿼리 실행 시 풀에서 커넥션을 획득하여 결과를 반환해야 한다."""
    block = PooledMySqlBlock(host="localhost", user="root", password="", db="test")
    mock_pool = _make_pool_mock([{"id": 1}])

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=mock_pool)):
        result = asyncio.run(block.run(QueryInput(query="SELECT id FROM t")))

    assert result.rows == [{"id": 1}]
    assert result.row_count == 1


def test_pool_reused_across_calls() -> None:
    """두 번 쿼리해도 create_pool은 한 번만 호출되어야 한다."""
    block = PooledMySqlBlock(host="localhost", user="root", password="", db="test")
    mock_pool = _make_pool_mock([{"n": 1}])

    async def _run_twice() -> None:
        await block.run(QueryInput(query="SELECT 1"))
        await block.run(QueryInput(query="SELECT 1"))

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=mock_pool)) as mock_cp:
        asyncio.run(_run_twice())

    mock_cp.assert_called_once()


def test_close_releases_pool() -> None:
    """close() 호출 후 pool이 None으로 초기화되어야 한다."""
    block = PooledMySqlBlock(host="localhost", user="root", password="", db="test")
    mock_pool = _make_pool_mock([])

    async def _run_and_close() -> None:
        await block.run(QueryInput(query="SELECT 1"))
        await block.close()

    with patch("aiomysql.create_pool", new=AsyncMock(return_value=mock_pool)):
        asyncio.run(_run_and_close())

    assert block._pool is None
    mock_pool.close.assert_called_once()
    mock_pool.wait_closed.assert_called_once()
