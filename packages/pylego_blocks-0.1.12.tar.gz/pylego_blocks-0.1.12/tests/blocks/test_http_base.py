"""BaseHttpBlock 공통 설정 테스트 (M70)."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pylego_blocks.blocks.http_base import BaseHttpBlock
from pylego_blocks.blocks.http_request import HttpRequestBlock, HttpRequestInput
from pylego_blocks.core.stud import Stud


def _make_response_mock(status: int = 200, json_data: dict | None = None) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status
    resp.headers = {"content-type": "application/json"}
    resp.text = "{}"
    resp.json = MagicMock(return_value=json_data or {})
    return resp


def _make_client_mock(resp: MagicMock) -> MagicMock:
    client = AsyncMock()
    client.request = AsyncMock(return_value=resp)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


def test_base_http_block_is_abstract() -> None:
    """BaseHttpBlock 은 직접 인스턴스화 불가."""
    with pytest.raises(TypeError):
        BaseHttpBlock()  # type: ignore[abstract]


def test_default_headers_merged_with_request_headers() -> None:
    """생성자 default_headers 와 요청 headers 가 병합된다. 요청 헤더 우선."""
    resp = _make_response_mock()
    client = _make_client_mock(resp)

    block = HttpRequestBlock(default_headers={"X-App": "pylego", "X-Version": "1"})

    with patch("httpx.AsyncClient", return_value=client):
        asyncio.run(
            block.run(HttpRequestInput(
                url="http://example.com",
                headers={"X-Version": "2", "Authorization": "Bearer token"},
            ))
        )

    call_kwargs = client.request.call_args.kwargs
    merged = call_kwargs["headers"]
    assert merged["X-App"] == "pylego"
    assert merged["X-Version"] == "2"        # 요청 헤더 우선
    assert merged["Authorization"] == "Bearer token"


def test_empty_default_headers_uses_request_headers_only() -> None:
    """default_headers 없으면 요청 헤더만 사용된다."""
    resp = _make_response_mock()
    client = _make_client_mock(resp)

    block = HttpRequestBlock()  # default_headers 없음

    with patch("httpx.AsyncClient", return_value=client):
        asyncio.run(
            block.run(HttpRequestInput(
                url="http://example.com",
                headers={"X-Custom": "value"},
            ))
        )

    merged = client.request.call_args.kwargs["headers"]
    assert merged == {"X-Custom": "value"}


def test_merge_headers_helper() -> None:
    """_merge_headers 는 default 에 request 를 오버레이한다."""
    block = HttpRequestBlock(default_headers={"A": "1", "B": "2"})
    result = block._merge_headers({"B": "override", "C": "3"})
    assert result == {"A": "1", "B": "override", "C": "3"}
