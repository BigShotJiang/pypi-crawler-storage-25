"""GitHub 이슈 조작 블록 테스트 (LabelTransition / IssueComment / IssueClose)."""

from __future__ import annotations

import os

import pytest

_TEST_REPO = os.environ.get("PYLEGO_TEST_REPO", "test-owner/test-repo")

from pylego_blocks.blocks.github import (
    IssueCloseBlock,
    IssueCloseRequest,
    IssueCommentBlock,
    IssueCommentRequest,
    LabelTransitionBlock,
    LabelTransitionRequest,
)


class _FakeGh:
    def __init__(self, exit_code: int = 0, stdout: str = "", stderr: str = "") -> None:
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr
        self.calls: list[list[str]] = []

    async def __call__(self, args: list[str]) -> tuple[int, str, str]:
        self.calls.append(args)
        return self.exit_code, self.stdout, self.stderr


class TestLabelTransition:
    async def test_remove_then_add_as_two_calls(self) -> None:
        """#37: remove 와 add 를 별도 gh 호출로 분리해 이중 라벨 현상 차단."""
        gh = _FakeGh()
        block = LabelTransitionBlock(gh_runner=gh)
        result = await block.run(
            LabelTransitionRequest(
                repo=_TEST_REPO,
                number=1,
                from_label="status:ready",
                to_label="status:in-progress",
            )
        )
        assert result.current_label == "status:in-progress"
        assert gh.calls == [
            [
                "issue", "edit", "1",
                "--repo", _TEST_REPO,
                "--remove-label", "status:ready",
            ],
            [
                "issue", "edit", "1",
                "--repo", _TEST_REPO,
                "--add-label", "status:in-progress",
            ],
        ]

    async def test_add_without_remove_when_from_none(self) -> None:
        gh = _FakeGh()
        block = LabelTransitionBlock(gh_runner=gh)
        await block.run(
            LabelTransitionRequest(
                repo="r/p",
                number=5,
                from_label=None,
                to_label="status:ready",
            )
        )
        # remove 호출 없음, add 호출 1건만.
        assert len(gh.calls) == 1
        assert "--remove-label" not in gh.calls[0]
        assert "--add-label" in gh.calls[0]

    async def test_remove_failure_is_best_effort(self) -> None:
        """#37: remove 실패는 tolerate. add 는 계속 수행되어 to_label 확정 보장.

        라벨이 이미 부재한 정상 사례 (복구 경로 등) 에서도 전이가 완료되어야 한다.
        """
        calls: list[list[str]] = []

        class _SelectiveGh:
            async def __call__(self, args: list[str]) -> tuple[int, str, str]:
                calls.append(args)
                if "--remove-label" in args:
                    return 1, "", "label not found"  # remove 실패
                return 0, "", ""                      # add 성공

        block = LabelTransitionBlock(gh_runner=_SelectiveGh())
        result = await block.run(
            LabelTransitionRequest(
                repo="r/p", number=1, from_label="a", to_label="b"
            )
        )
        assert result.current_label == "b"
        assert len(calls) == 2
        assert "--remove-label" in calls[0]
        assert "--add-label" in calls[1]

    async def test_add_failure_raises(self) -> None:
        """#37: add 실패는 여전히 raise — to_label 단일성이 깨지기 때문."""
        calls: list[list[str]] = []

        class _SelectiveGh:
            async def __call__(self, args: list[str]) -> tuple[int, str, str]:
                calls.append(args)
                if "--add-label" in args:
                    return 1, "", "add failed"
                return 0, "", ""

        block = LabelTransitionBlock(gh_runner=_SelectiveGh())
        with pytest.raises(RuntimeError, match="add failed"):
            await block.run(
                LabelTransitionRequest(
                    repo="r/p", number=1, from_label="a", to_label="b"
                )
            )
        assert len(calls) == 2


class TestIssueComment:
    async def test_posts_body(self) -> None:
        gh = _FakeGh()
        block = IssueCommentBlock(gh_runner=gh)
        await block.run(IssueCommentRequest(repo="r/p", number=7, body="hello"))
        assert gh.calls[0] == [
            "issue",
            "comment",
            "7",
            "--repo",
            "r/p",
            "--body",
            "hello",
        ]

    async def test_raises_on_failure(self) -> None:
        gh = _FakeGh(exit_code=1, stderr="rate limit")
        with pytest.raises(RuntimeError, match="rate limit"):
            await IssueCommentBlock(gh_runner=gh).run(
                IssueCommentRequest(repo="r/p", number=1, body="x")
            )


class TestIssueClose:
    async def test_close_without_comment(self) -> None:
        gh = _FakeGh()
        await IssueCloseBlock(gh_runner=gh).run(
            IssueCloseRequest(repo="r/p", number=9)
        )
        assert gh.calls[0] == ["issue", "close", "9", "--repo", "r/p"]

    async def test_close_with_comment(self) -> None:
        gh = _FakeGh()
        await IssueCloseBlock(gh_runner=gh).run(
            IssueCloseRequest(repo="r/p", number=9, comment="완료")
        )
        assert "--comment" in gh.calls[0]
        assert "완료" in gh.calls[0]

    async def test_raises_on_failure(self) -> None:
        gh = _FakeGh(exit_code=1, stderr="already closed")
        with pytest.raises(RuntimeError, match="already closed"):
            await IssueCloseBlock(gh_runner=gh).run(
                IssueCloseRequest(repo="r/p", number=1)
            )
