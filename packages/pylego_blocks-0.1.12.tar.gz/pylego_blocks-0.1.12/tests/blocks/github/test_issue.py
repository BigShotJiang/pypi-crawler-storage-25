"""IssueInspectBlock — gh CLI 래핑 검증 (실 호출 없이 fake runner 주입)."""

from __future__ import annotations

import json
import os

import pytest

_TEST_REPO = os.environ.get("PYLEGO_TEST_REPO", "test-owner/test-repo")

from pylego_blocks.blocks.github import IssueInspectBlock, IssueMetadata, IssueRef


class _FakeGh:
    """gh 바이너리 호출을 대체하는 fake. 마지막 인자 목록을 기록한다."""

    def __init__(self, exit_code: int, stdout: str, stderr: str = "") -> None:
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr
        self.last_args: list[str] | None = None

    async def __call__(self, args: list[str]) -> tuple[int, str, str]:
        self.last_args = args
        return self.exit_code, self.stdout, self.stderr


_STUB_JSON = json.dumps(
    {
        "number": 42,
        "title": "버그: 뭔가 깨짐",
        "state": "OPEN",
        "labels": [
            {"name": "type:bug"},
            {"name": "priority:P1"},
            {"name": "status:ready"},
        ],
    }
)


class TestIssueInspectBlock:
    async def test_parses_issue_metadata(self) -> None:
        gh = _FakeGh(exit_code=0, stdout=_STUB_JSON)
        block = IssueInspectBlock(gh_runner=gh)

        result = await block.run(IssueRef(repo=_TEST_REPO, number=42))

        assert isinstance(result, IssueMetadata)
        assert result.repo == _TEST_REPO
        assert result.number == 42
        assert result.title == "버그: 뭔가 깨짐"
        assert result.state == "OPEN"
        assert result.labels == ("type:bug", "priority:P1", "status:ready")

    async def test_calls_gh_with_expected_args(self) -> None:
        gh = _FakeGh(exit_code=0, stdout=_STUB_JSON)
        block = IssueInspectBlock(gh_runner=gh)
        await block.run(IssueRef(repo=_TEST_REPO, number=42))

        assert gh.last_args == [
            "issue",
            "view",
            "42",
            "--repo",
            _TEST_REPO,
            "--json",
            "number,title,state,labels",
        ]

    async def test_nonzero_exit_raises(self) -> None:
        gh = _FakeGh(exit_code=1, stdout="", stderr="could not resolve issue")
        block = IssueInspectBlock(gh_runner=gh)
        with pytest.raises(RuntimeError, match="could not resolve issue"):
            await block.run(IssueRef(repo=_TEST_REPO, number=9999))

    async def test_unknown_state_raises(self) -> None:
        bogus = json.dumps({"number": 1, "title": "x", "state": "WEIRD", "labels": []})
        gh = _FakeGh(exit_code=0, stdout=bogus)
        block = IssueInspectBlock(gh_runner=gh)
        with pytest.raises(RuntimeError, match="알 수 없는 이슈 state"):
            await block.run(IssueRef(repo=_TEST_REPO, number=1))

    async def test_empty_labels(self) -> None:
        empty = json.dumps({"number": 7, "title": "t", "state": "CLOSED", "labels": []})
        gh = _FakeGh(exit_code=0, stdout=empty)
        block = IssueInspectBlock(gh_runner=gh)
        result = await block.run(IssueRef(repo=_TEST_REPO, number=7))
        assert result.labels == ()
        assert result.state == "CLOSED"

    def test_block_contract(self) -> None:
        assert IssueInspectBlock.input_model is IssueRef
        assert IssueInspectBlock.output_model is IssueMetadata
        assert IssueInspectBlock.name == "IssueInspectBlock"
