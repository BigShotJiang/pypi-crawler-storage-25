"""MergeToMainBlock 테스트."""

from __future__ import annotations

import pytest

from pylego_blocks.blocks.git import MergeRequest, MergeToMainBlock


class _FakeGit:
    def __init__(self, responses: list[tuple[int, str, str]]) -> None:
        self._responses = list(responses)
        self.calls: list[list[str]] = []

    async def __call__(self, args: list[str]) -> tuple[int, str, str]:
        self.calls.append(args)
        if not self._responses:
            return (0, "", "")
        return self._responses.pop(0)


class TestMergeToMain:
    async def test_full_flow_succeeds(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # status --porcelain
                (0, "", ""),  # checkout main
                (0, "", ""),  # pull origin main (best-effort)
                (0, "", ""),  # merge --no-ff
                (0, "", ""),  # push origin main
                (0, "", ""),  # branch -d feature/x (best-effort)
                (0, "", ""),  # push origin --delete feature/x (best-effort)
            ]
        )
        result = await MergeToMainBlock(git_runner=git).run(
            MergeRequest(
                base_branch="main",
                feature_branch="feature/x",
                message="Merge feature/x",
            )
        )
        assert result.base_branch == "main"
        assert result.feature_branch == "feature/x"
        assert result.local_branch_deleted is True
        assert result.remote_branch_deleted is True
        assert ["merge", "feature/x", "--no-ff", "-m", "Merge feature/x"] in git.calls
        assert ["push", "origin", "main"] in git.calls

    async def test_merge_failure_raises(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # status
                (0, "", ""),  # checkout
                (0, "", ""),  # pull
                (1, "", "conflict"),  # merge fails
            ]
        )
        with pytest.raises(RuntimeError, match="conflict"):
            await MergeToMainBlock(git_runner=git).run(
                MergeRequest(base_branch="main", feature_branch="feature/x", message="m")
            )

    async def test_branch_delete_failure_tolerated(self) -> None:
        """로컬 브랜치 삭제 실패는 best-effort — 전체 실패로 이어지지 않음."""
        git = _FakeGit(
            [
                (0, "", ""),  # status
                (0, "", ""),  # checkout
                (0, "", ""),  # pull
                (0, "", ""),  # merge
                (0, "", ""),  # push main
                (1, "", "not fully merged"),  # branch -d (실패 — 허용)
                (1, "", "no such branch"),  # push --delete (실패 — 허용)
            ]
        )
        result = await MergeToMainBlock(git_runner=git).run(
            MergeRequest(base_branch="main", feature_branch="feature/x", message="m")
        )
        assert result.local_branch_deleted is False
        assert result.remote_branch_deleted is False

    async def test_push_origin_false_skips_push(self) -> None:
        git = _FakeGit(
            [
                (0, "", ""),  # status
                (0, "", ""),  # checkout
                (0, "", ""),  # pull
                (0, "", ""),  # merge
                (0, "", ""),  # branch -d
                (0, "", ""),  # push --delete
            ]
        )
        await MergeToMainBlock(git_runner=git).run(
            MergeRequest(
                base_branch="main",
                feature_branch="feature/x",
                message="m",
                push_origin=False,
            )
        )
        assert ["push", "origin", "main"] not in git.calls

    async def test_dirty_worktree_raises_before_checkout(self) -> None:
        git = _FakeGit([(0, " M src/pylego/blocks/git/merge.py", "")])
        with pytest.raises(RuntimeError, match="working tree not clean"):
            await MergeToMainBlock(git_runner=git).run(
                MergeRequest(base_branch="main", feature_branch="feature/x", message="m")
            )
        assert git.calls == [["status", "--porcelain"]]
