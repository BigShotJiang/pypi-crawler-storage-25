"""PipelineHealth.sub_health + build_health_summary 중첩 분리 테스트 (M84)."""

from __future__ import annotations

import pytest

from pylego_blocks.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    BlockStartedEvent,
    CollectingEventBus,
)
from pylego_blocks.core.graph import PipelineHealth, build_health_summary, to_html


def _started(name: str, t: float = 0.0) -> BlockStartedEvent:
    return BlockStartedEvent(block_name=name, input=None, timestamp=t)


def _completed(name: str, elapsed: float = 0.1) -> BlockCompletedEvent:
    return BlockCompletedEvent(block_name=name, output=None, elapsed_sec=elapsed, timestamp=0.0)


def _failed(name: str) -> BlockFailedEvent:
    return BlockFailedEvent(
        block_name=name, error=RuntimeError("err"), elapsed_sec=0.1, timestamp=0.0
    )


# ── sub_health 필드 기본값 ────────────────────────────────────────────────────

def test_pipeline_health_sub_health_default_none() -> None:
    h = PipelineHealth(
        overall="ok", total_blocks=1, error_blocks=[],
        slowest_block=None, slowest_elapsed_sec=None, avg_elapsed_sec=None,
    )
    assert h.sub_health is None


# ── 네임스페이스 분리 ─────────────────────────────────────────────────────────

def test_build_health_separates_namespaced_events() -> None:
    events = [
        _started("BlockA"),
        _completed("BlockA"),
        _started("sub/BlockB"),
        _completed("sub/BlockB"),
    ]
    health = build_health_summary(events)
    assert health.total_blocks == 1  # BlockA만 최상위
    assert health.sub_health is not None
    assert "sub" in health.sub_health
    assert health.sub_health["sub"].total_blocks == 1


def test_sub_health_reflects_failures() -> None:
    events = [
        _started("BlockA"), _completed("BlockA"),
        _started("fallback/FB"), _failed("fallback/FB"),
    ]
    health = build_health_summary(events)
    assert health.overall == "ok"
    assert health.sub_health is not None
    sh = health.sub_health["fallback"]
    assert sh.overall in ("degraded", "critical")
    assert "FB" in sh.error_blocks


def test_main_health_not_polluted_by_sub_events() -> None:
    events = [
        _started("Top"), _completed("Top"),
        _failed("sub/Child"),
    ]
    health = build_health_summary(events)
    assert health.overall == "ok"
    assert health.error_blocks == []


# ── 깊이 제한 ──────────────────────────────────────────────────────────────────

def test_depth_limit_stops_at_3() -> None:
    events = [
        _completed("a/b/c/d"),  # depth 3: a > b > c/d (c 에서 멈춤)
    ]
    health = build_health_summary(events)
    assert health.sub_health is not None
    level1 = health.sub_health["a"]
    assert level1.sub_health is not None
    level2 = level1.sub_health["b"]
    # depth=2 이므로 c/d 를 분리 가능 (depth < 3)
    assert level2.sub_health is not None
    level3 = level2.sub_health["c"]
    # depth=3 이므로 더 이상 분리 안 됨
    assert level3.sub_health is None


# ── error_details top-level 필터링 ───────────────────────────────────────────

def test_error_details_filtered_with_bus() -> None:
    bus = CollectingEventBus()
    events = [
        _started("Top"), _failed("Top"),
        _started("sub/Child"), _failed("sub/Child"),
    ]
    for e in events:
        bus.emit(e)
    health = build_health_summary(bus.events, bus=bus)
    assert health.error_details is not None
    assert "Top" in health.error_details
    assert "sub/Child" not in health.error_details


def test_error_details_none_when_no_bus_nested() -> None:
    events = [_started("Top"), _failed("Top")]
    health = build_health_summary(events)
    assert health.error_details is None
    assert "Top" in health.error_blocks


def test_sub_health_overall_from_failures() -> None:
    events = [
        _started("fallback/Child"), _failed("fallback/Child"),
    ]
    health = build_health_summary(events)
    assert health.sub_health is not None
    sh = health.sub_health["fallback"]
    assert sh.overall in ("degraded", "critical")
    assert "Child" in sh.error_blocks


# ── to_html sub_health 렌더링 ────────────────────────────────────────────────

def test_to_html_sub_health_section_present() -> None:
    """to_html 출력에 <details class="sub-health"> 태그가 있어야 한다."""
    from unittest.mock import MagicMock

    from pylego_blocks.core.graph import to_html

    block = MagicMock()
    block.name = "TestPipeline"

    import pylego_blocks.core.graph as _g
    orig = _g.to_mermaid

    def _fake_mermaid(*a: object, **kw: object) -> str:
        return "graph LR\n  A --> B"

    _g.to_mermaid = _fake_mermaid  # type: ignore[assignment]
    try:
        events = [
            _started("Top"), _completed("Top"),
            _started("sub/Child"), _completed("sub/Child"),
        ]
        health = build_health_summary(events)
        html = to_html(block, health=health)
        assert 'class="sub-health"' in html
        assert "<details" in html
        assert "sub" in html
    finally:
        _g.to_mermaid = orig  # type: ignore[assignment]
