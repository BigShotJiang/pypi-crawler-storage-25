# Changelog

전체 변경 이력은 [GitHub CHANGELOG](https://github.com/hoksi/pylego/blob/main/CHANGELOG.md)를 참조하세요.
