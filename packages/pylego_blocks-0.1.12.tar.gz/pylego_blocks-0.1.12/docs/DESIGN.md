# pylego 설계 문서

> pylego의 핵심 설계 결정과 컴포넌트 동작 원리를 기술한다.
> 코드를 처음 읽는 사람이 "왜 이렇게 만들었는가"를 파악할 수 있도록 작성됐다.

---

## 1. 설계 철학

pylego는 **레고 브릭** 메타포를 Python 컴포넌트 설계에 적용한다.

| 레고 | pylego | 의미 |
|------|--------|------|
| Stud/Tube | `Stud` (pydantic 모델) | 블록이 붙는 표준 인터페이스. 맞아야만 붙는다 |
| Brick | `Block` | 단일 책임, 단독 실행 가능한 최소 단위 |
| Plate | `Assembly` | 여러 블록의 선형 조립체. 외부엔 하나의 블록처럼 보인다 |
| Fan shape | `FanOut` | N개 브랜치 동시 실행 |
| Switch track | `Branch` | 조건에 따른 2-way 분기 |
| Catalog | `BlockRegistry` | 이름으로 블록을 찾는 레지스트리 |

**불변 원칙:**
1. 블록은 다른 블록의 내부를 모른다 — `Stud` 계약만 본다.
2. 블록은 단독 실행·단독 테스트가 가능해야 한다.
3. `Assembly`는 블록과 구분 불가능해야 한다 (재귀적 합성, Liskov).
4. 런타임 교체(sync↔async)가 블록 수정 없이 가능해야 한다.

---

## 2. Stud — I/O 계약

```
┌──────────────────────────────────────────────┐
│  Stud(BaseModel)                             │
│  - extra="forbid"  → 예측 못한 필드 거부     │
│  - frozen=True     → 생성 후 불변            │
└──────────────────────────────────────────────┘
```

`Stud`는 블록 경계에서 오가는 데이터의 타입이다. pydantic v2 `BaseModel`을 상속하며 두 가지 불변식을 강제한다:

- **`extra="forbid"`**: 선언되지 않은 필드를 받으면 즉시 `ValidationError`. 암묵적 데이터 통과를 막는다.
- **`frozen=True`**: 생성 이후 필드 변경 불가. 블록 간 공유 객체가 의도치 않게 변경되는 것을 방지한다.

상태를 변경해야 하는 경우 새 `Stud` 인스턴스를 만들어 반환한다 (값 의미론).

---

## 3. Block — 최소 실행 단위

```
Block[InputT: Stud, OutputT: Stud]
├── input_model:  type[Stud]       # 입력 계약
├── output_model: type[Stud]       # 출력 계약
├── name:         str              # 기본값: 클래스명
└── run(inp: InputT) → OutputT     # 반드시 async def
```

### 수명주기

```
정의 시점 (__init_subclass__)
  → input_model / output_model 존재·타입 검증
  → name 미지정 시 클래스명 자동 설정

조립 시점 (Assembly.__init__)
  → 인접 블록의 output_model ↔ input_model 일치 검증
  → 순환 참조·중복 인스턴스 감지

실행 시점 (block.run)
  → 입력: InputT 인스턴스 (Stud, frozen)
  → 출력: OutputT 인스턴스 (새 객체)
  → 블록 내부에서 다른 블록을 직접 호출하지 않는다
```

### 구현 규칙

```python
class MyBlock(Block[MyInput, MyOutput]):
    input_model = MyInput
    output_model = MyOutput

    async def run(self, inp: MyInput) -> MyOutput:
        # 동기 로직도 async def로 선언 (await 없이 반환 가능)
        return MyOutput(value=inp.value * 2)
```

외부 의존(DB, HTTP 등)은 생성자 주입으로 받는다. 블록이 직접 import하거나 전역 상태를 참조하지 않는다.

---

## 4. Assembly — 선형 조립체

```
Assembly([BlockA, BlockB, BlockC])
  input_model  = BlockA.input_model
  output_model = BlockC.output_model

  run(inp) → BlockA.run(inp) → BlockB.run(…) → BlockC.run(…) → OutputT
```

### 조립 시점 검증

`__init__`에서 두 가지 검증이 순서대로 실행된다:

1. **사이클 감지** (`_detect_cycles`):
   - 최상위 중복 인스턴스: `id()` 기반으로 동일 객체가 두 번 이상 포함되면 `CyclicAssemblyError`.
   - 중첩 Assembly 진짜 사이클: DFS로 방문 중인 노드를 재방문하면 `CyclicAssemblyError`.

2. **스냅 검증** (`_validate_chain`):
   - `prev.output_model is not nxt.input_model` → `IncompatibleSnapError`.
   - `is` 비교 (동일 클래스 객체)를 사용한다. `issubclass`가 아님 — 명시적 계약 일치 강제.

### 재귀적 합성

`Assembly` 자체가 `Block`이므로 다른 `Assembly`의 구성 요소로 사용할 수 있다.

```python
inner = Assembly([BlockA, BlockB])   # Block[A, B]처럼 동작
outer = Assembly([inner, BlockC])    # Block[A, C]
```

### run_sync

`asyncio.run(self.run(inp))`의 얇은 래퍼. 이미 실행 중인 이벤트 루프가 있는 환경(Jupyter 등)에서는 사용할 수 없다.

---

## 5. FanOut — 동시 분기

```
         ┌→ BranchA.run(inp) ──┐
inp ─────┤                      ├→ Gathered(results=(outA, outB, outC))
         ├→ BranchB.run(inp) ──┤
         └→ BranchC.run(inp) ──┘
              asyncio.gather
```

- 모든 브랜치의 `input_model`이 동일해야 한다 (조립 시점 검증).
- 출력은 `Gathered(results: tuple[Any, ...])` — 순서는 브랜치 선언 순서와 동일.
- 최소 2개 브랜치 필요.

---

## 6. Branch — 조건부 분기

```
          predicate(inp) == True  → on_true.run(inp)
inp ─────┤
          predicate(inp) == False → on_false.run(inp)
```

- `on_true`와 `on_false`는 `input_model`, `output_model`이 모두 동일해야 한다.
- `Branch` 자체가 `Block`이므로 `Assembly`에 포함할 수 있다.

---

## 7. BlockRegistry

블록 클래스를 이름으로 등록·조회하는 카탈로그.

```python
@register
class MyBlock(Block[A, B]): ...

cls = default_registry.get("MyBlock")   # KeyError if not found
all_blocks = default_registry.all()     # 이름순 전체 목록
default_registry.load_entry_points("pylego.blocks")  # 서드파티 자동 발견
```

`register(cls)`는 `cls`를 그대로 반환하므로 데코레이터·직접 호출 양쪽에서 사용 가능하다.

---

## 8. 선언형 조립 (YAML)

```yaml
name: my-pipeline
blocks:
  - class: myapp.blocks.UpperBlock
  - class: myapp.blocks.LengthBlock
```

`load_assembly(path)`가 YAML을 읽어 `Assembly`를 반환한다.

블록 클래스 참조 형식:
- `"module.path.ClassName"` — 마지막 `.` 기준 분리
- `"module.path:ClassName"` — `:` 기준 분리 (우선)
- `"ClassName"` — 레지스트리 조회 (`registry` 인자 필요)

---

## 9. 타입 시스템

pylego는 **mypy strict** 기준을 만족한다.

- `Block[InputT, OutputT]` — PEP 695 타입 파라미터 (Python 3.12+)
- `Assembly` — 조립 시점에 `input_model`·`output_model`을 인스턴스 속성으로 섀도잉해 동적으로 타입 계약 갱신
- `Stud` — pydantic v2로 런타임 검증과 정적 타입 검사 동시 지원

---

## 10. 설계 결정 기록 (ADR 요약)

| 결정 | 선택 | 이유 |
|------|------|------|
| I/O 계약 타입 | pydantic v2 `BaseModel` | 런타임 검증 + 정적 타입 동시 확보 |
| Stud frozen | `frozen=True` | 블록 간 공유 객체 변경 버그 방지 |
| 스냅 검증 방식 | `is` 비교 | `issubclass`는 암묵적 호환을 허용해 계약 오용 가능 |
| `run` 시그니처 | 항상 `async def` | 동기 로직도 async로 선언해 런타임 통일 |
| Assembly 사이클 감지 | id 기반 + DFS | 중복 인스턴스와 진짜 사이클 모두 조립 시점에 검출 |
| BlockRegistry 반환값 | `cls` 반환 | 데코레이터로 사용 가능 (`@register`) |
