# Queue & WorkerPool

## Queue

::: pylego_blocks.core.queue.Queue

---

## WorkerPool

::: pylego_blocks.core.queue.WorkerPool

---

## DeadLetterQueue

::: pylego_blocks.core.queue.DeadLetterQueue

---

## RedisQueue

```bash
pip install pylego-blocks[redis]
```

::: pylego_blocks.core.redis_queue.RedisQueue

---

## RedisWorkerPool

::: pylego_blocks.core.redis_queue.RedisWorkerPool

---

## RedisDeadLetterQueue

::: pylego_blocks.core.redis_queue.RedisDeadLetterQueue

---

## make_queue

::: pylego_blocks.core.redis_queue.make_queue
