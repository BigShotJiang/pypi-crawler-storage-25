# Block & Stud

## Stud

::: pylego_blocks.core.stud.Stud

---

## Block

::: pylego_blocks.core.block.Block

---

## 사용 예시

```python
from pylego_blocks import Block, Stud

class MyInput(Stud):
    value: int

class MyOutput(Stud):
    result: str

class MyBlock(Block[MyInput, MyOutput]):
    input_model = MyInput
    output_model = MyOutput

    async def run(self, inp: MyInput) -> MyOutput:
        return MyOutput(result=str(inp.value * 2))
```
