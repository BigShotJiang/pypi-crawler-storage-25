# API 레퍼런스

pylego의 전체 공개 API 문서입니다.

## 모듈 구조

```
pylego
├── Block, Stud, Assembly        # 코어 빌딩 블록
├── FanOut, Branch               # DAG 분기
├── Queue, WorkerPool            # asyncio 이벤트 큐
├── RedisQueue, RedisWorkerPool  # Redis 분산 큐
├── RetryBlock, FallbackBlock    # 에러 복구
├── CircuitBreakerBlock          # 서킷 브레이커
├── TimeoutBlock                 # 타임아웃
├── DeadLetterQueue              # 실패 항목 격리
├── StreamBlock                  # 스트리밍
├── StoreBlock, FileStore        # 상태 저장
├── Checkpoint, FileCheckpoint   # 체크포인팅
├── EventBus, LoggingEventBus    # 이벤트 버스
├── OtelEventBus                 # OpenTelemetry
├── CollectingEventBus           # 이벤트 수집
├── Unit, UnitPipeline           # Unit 계층
├── build_app, serve             # HTTP API 서빙
└── make_queue                   # 큐 팩토리
```

## 빠른 참조

| 클래스/함수 | 설명 |
|------------|------|
| [`Block`](block.md) | 최소 실행 단위 |
| [`Stud`](block.md#stud) | I/O 계약 베이스 |
| [`Assembly`](assembly.md) | 블록 체인 조립체 |
| [`Queue`](queue.md) | asyncio 작업 큐 |
| [`RedisQueue`](queue.md#redisqueue) | Redis 분산 큐 |
| [`WorkerPool`](queue.md#workerpool) | 동시 워커 풀 |
| [`RetryBlock`](resilience.md) | 재시도 래퍼 |
| [`CircuitBreakerBlock`](resilience.md#circuitbreakerblock) | 서킷 브레이커 |
| [`build_app`](serve.md) | FastAPI 앱 생성 |
| [`Unit`](unit.md) | 3단계 생명주기 실행 단위 |
