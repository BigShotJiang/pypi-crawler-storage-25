# Assembly

::: pylego_blocks.core.assembly.Assembly

---

## FanOut

::: pylego_blocks.core.fanout.FanOut

---

## Branch

::: pylego_blocks.core.branch.Branch

---

## 시각화

```python
from pylego_blocks import Assembly, to_mermaid, to_dot, to_html

pipeline = Assembly([BlockA(), BlockB()])

# Mermaid
print(to_mermaid(pipeline))

# DOT (Graphviz)
print(to_dot(pipeline))

# HTML 리포트
html = to_html(pipeline)
```

::: pylego_blocks.core.visualize.to_mermaid

::: pylego_blocks.core.visualize.to_dot

::: pylego_blocks.core.visualize.to_html
