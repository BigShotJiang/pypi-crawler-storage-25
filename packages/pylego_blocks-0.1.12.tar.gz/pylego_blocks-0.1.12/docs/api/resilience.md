# Resilience (에러 복구)

## RetryPolicy

::: pylego_blocks.core.resilience.RetryPolicy

---

## RetryBlock

::: pylego_blocks.core.resilience.RetryBlock

---

## FallbackBlock

::: pylego_blocks.core.resilience.FallbackBlock

---

## TimeoutBlock

::: pylego_blocks.core.resilience.TimeoutBlock

---

## CircuitBreakerBlock

::: pylego_blocks.core.resilience.CircuitBreakerBlock
