# Unit 계층

Unit은 `validate() → run() → verify()` 3단계 생명주기를 가진 고수준 실행 단위입니다.

## UnitResult

::: pylego_blocks.unit.UnitResult

---

## Unit

::: pylego_blocks.unit.Unit

---

## ResultUnit

::: pylego_blocks.unit.ResultUnit

---

## UnitPipeline

::: pylego_blocks.unit.UnitPipeline

---

## ConfigBlock

::: pylego_blocks.unit.ConfigBlock

---

## 실행 흐름

```
[ConfigBlock] → [UnitA] → [UnitB] → [UnitC] → [ResultUnit]
                  ↓          ↓          ↓
               validate   validate   스킵 ←── UnitA 실패 전파
               run        run
               verify     verify
```

## 예시

```python
from pylego_blocks import Unit, UnitPipeline, UnitResult, ResultUnit, Stud

class JobIn(Stud):
    data: str

class ValidateUnit(Unit[JobIn]):
    name = "Validate"
    input_model = JobIn

    async def validate(self, inp: JobIn) -> None:
        if not inp.data:
            raise ValueError("data is empty")

    async def run(self, inp: JobIn) -> str:
        return inp.data.strip()

    async def verify(self, inp: JobIn, result: str) -> None:
        assert len(result) > 0

class FinalUnit(ResultUnit):
    async def on_success(self, result: object) -> UnitResult:
        return UnitResult(status="success", result=result)

    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        return UnitResult(status="failure", reason=reason, failed_at=failed_at)

pipeline = UnitPipeline([ValidateUnit()], result_unit=FinalUnit())
result = pipeline.run_sync(JobIn(data="  hello  "))
print(result.status)   # success
print(result.result)   # hello
```

## CLI 독립 실행

```bash
pylego run-unit myapp.units.ValidateUnit --input '{"data": "hello"}'
pylego run-unit myapp.units.ValidateUnit --schema
```
