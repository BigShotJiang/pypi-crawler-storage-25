# Stud 의미론적 검증

`Stud`는 블록 간 데이터 계약을 정의한다. `extra="forbid"` + `frozen=True`가 **형태(Shape)**를
보장한다면, pydantic v2의 `@field_validator` / `@model_validator`는 **의미(Semantic)**를
보장한다.

## 검증 계층 구조

```
Stud @field_validator    → 필드 값의 도메인 규칙 (범위, 형식, 열거형)
Stud @model_validator    → 교차 필드 일관성 규칙
Unit.validate(inp)       → 외부 의존 런타임 검증 (DB, 캐시, 외부 서비스)
Unit.verify(inp, result) → 실행 후 출력 의미 검증
```

상위 계층으로 갈수록 비용이 높아진다. 순수 값 규칙은 `Stud` 안에서 처리하라.

---

## @field_validator — 단일 필드 검증

```python
from pydantic import field_validator
from pylego_blocks import Stud

class Score(Stud):
    value: float
    label: str

    @field_validator("value")
    @classmethod
    def must_be_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 100.0):
            raise ValueError(f"점수는 0~100 범위: {v}")
        return v
```

`Score(value=150.0, label="high")` → `ValidationError` 즉시 발생.

**규칙:**
- 반환값이 실제 저장되는 값이다 — 정규화(`v.lower()`)나 변환을 여기서 수행할 수 있다.
- `frozen=True`이므로 인스턴스 생성 후 값 변경은 불가하다.
- `@classmethod` 데코레이터가 필수다.

---

## @model_validator — 교차 필드 검증

```python
from pydantic import field_validator, model_validator
from pylego_blocks import Stud

class AiResponse(Stud):
    verdict: str
    confidence: float

    @field_validator("confidence")
    @classmethod
    def confidence_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 1.0):
            raise ValueError(f"confidence는 0~1 범위: {v}")
        return v

    @model_validator(mode="after")
    def unknown_requires_low_confidence(self) -> "AiResponse":
        if self.verdict == "UNKNOWN" and self.confidence > 0.5:
            raise ValueError(
                "UNKNOWN 판정은 confidence ≤ 0.5 이어야 합니다"
            )
        return self
```

`mode="after"` — 모든 필드가 설정된 후 실행된다. `self`로 모든 필드에 접근 가능.

---

## AI 출력 형식 검증 패턴

AI 블록의 출력 Stud에 검증기를 선언하면, AI가 잘못된 값을 반환할 때 즉시 `ValidationError`로
포착할 수 있다.

```python
class ReviewResult(Stud):
    verdict: str
    issues: list[str]
    score: float

    @field_validator("verdict")
    @classmethod
    def valid_verdict(cls, v: str) -> str:
        if v.upper() not in {"PASS", "FAIL", "UNKNOWN"}:
            raise ValueError(f"유효하지 않은 판정: {v}")
        return v.upper()

    @field_validator("score")
    @classmethod
    def score_in_range(cls, v: float) -> float:
        if not (0.0 <= v <= 10.0):
            raise ValueError(f"점수는 0~10 범위: {v}")
        return v

    @model_validator(mode="after")
    def fail_requires_issues(self) -> "ReviewResult":
        if self.verdict == "FAIL" and not self.issues:
            raise ValueError("FAIL 판정에는 issues 목록이 필요합니다")
        return self
```

이 패턴을 `SemanticRetryBlock`과 결합하면 AI 출력이 형식을 위반할 때 자동으로 재시도한다:

```python
from pylego_blocks import SemanticRetryBlock

def verify_review(inp: ReviewRequest, out: ReviewResult) -> None:
    pass  # Stud 레벨 검증이 이미 수행됨 — 추가 의미 검증만 작성

block = SemanticRetryBlock(
    AiReviewBlock(),
    verify_fn=verify_review,
    enrich_fn=lambda inp, out, err: inp.model_copy(
        update={"context": f"이전 오류: {err}"}
    ),
)
```

---

## Unit.validate() — 외부 의존 검증

`Stud` 검증은 순수 값 규칙에만 사용한다. **외부 상태(DB, 캐시, 서비스)**가 필요한 검증은
`Unit.validate()`에서 처리한다.

```python
class UserUnit(Unit[UserInput]):
    name = "UserUnit"
    input_model = UserInput

    async def validate(self, inp: UserInput) -> None:
        # 외부 DB 조회 — Stud 레벨에서 불가
        if await db.is_banned(inp.username):
            raise ValueError(f"금지된 사용자: {inp.username}")
```

| 검증 유형 | 위치 | 이유 |
|----------|------|------|
| 숫자 범위·형식·열거형 | `Stud @field_validator` | 즉시, 비용 없음 |
| 교차 필드 일관성 | `Stud @model_validator` | 즉시, 비용 없음 |
| DB/캐시/외부 서비스 조회 | `Unit.validate()` | async 필요 |
| 실행 결과 의미 검증 | `Unit.verify()` | 출력이 있어야 확인 가능 |

---

## 실행 예제

```bash
uv run python examples/patterns/09_stud_validators.py
```
