# pylego 실전 개발 가이드

외부 의존성 없이 pylego의 핵심 기능을 직접 실행하며 익히는 가이드입니다.  
완성 예제는 **문장 분석 파이프라인** — 원시 텍스트를 입력받아 정제 → 단어 카운트 → 요약 출력하는 3단계 처리 흐름입니다.

---

## 1. 설치

Ubuntu/Debian 계열 리눅스에서는 시스템 Python에 직접 설치할 수 없습니다.  
가상환경을 먼저 만든 뒤 설치합니다.

```bash
# 가상환경 생성 및 활성화
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# pylego 설치
pip install pylego-blocks
```

또는 `uv`를 사용하면 더 빠릅니다:

```bash
# uv 설치 (공식 인스톨러 — pip 불필요)
curl -LsSf https://astral.sh/uv/install.sh | sh
source ~/.local/bin/env   # 또는 터미널 재시작

uv init my_pipeline     # 프로젝트 생성
cd my_pipeline
uv add pylego-blocks           # pylego 추가
uv run python main.py   # 실행
```

> **macOS / Windows**에서는 `pip install pylego-blocks` 직접 실행도 가능합니다.  
> 파이썬 3.12 이상, `pydantic v2`가 자동으로 함께 설치됩니다.

---

## 2. 프로젝트 구조

```
my_pipeline/
├── studs.py      # I/O 계약 (데이터 타입)
├── blocks.py     # 블록 구현
├── main.py       # 조립 및 실행
└── test_pipeline.py  # pytest 테스트
```

---

## 3. Stud 정의 — `studs.py`

블록 간에 주고받는 데이터 타입을 정의합니다.  
`Stud`는 `frozen=True`이므로 값을 바꾸려면 `.model_copy(update={...})`를 사용합니다.

```python
# studs.py
from pylego_blocks import Stud


class RawText(Stud):
    """파이프라인 입력 — 원시 텍스트."""
    text: str


class CleanText(Stud):
    """정제된 텍스트."""
    text: str


class WordCount(Stud):
    """단어 수 카운트 결과."""
    text: str
    count: int


class Summary(Stud):
    """최종 요약 출력."""
    message: str
```

---

## 4. 블록 구현 — `blocks.py`

각 블록은 단 하나의 책임을 가집니다. `run()`은 반드시 `async def`로 선언합니다.

```python
# blocks.py
from pylego_blocks import Block
from studs import RawText, CleanText, WordCount, Summary


class CleanBlock(Block[RawText, CleanText]):
    """앞뒤 공백 제거 + 연속 공백 정규화."""
    input_model = RawText
    output_model = CleanText

    async def run(self, inp: RawText) -> CleanText:
        cleaned = " ".join(inp.text.split())
        return CleanText(text=cleaned)


class CountBlock(Block[CleanText, WordCount]):
    """단어 수를 센다."""
    input_model = CleanText
    output_model = WordCount

    async def run(self, inp: CleanText) -> WordCount:
        words = inp.text.split()
        return WordCount(text=inp.text, count=len(words))


class SummaryBlock(Block[WordCount, Summary]):
    """결과 메시지를 조립한다."""
    input_model = WordCount
    output_model = Summary

    async def run(self, inp: WordCount) -> Summary:
        msg = f'"{inp.text}" — 단어 {inp.count}개'
        return Summary(message=msg)
```

---

## 5. 조립 및 실행 — `main.py`

`Assembly`에 블록 목록을 넘기면 조립 시점에 I/O 계약이 자동 검증됩니다.

```python
# main.py
from pylego_blocks import Assembly
from studs import RawText
from blocks import CleanBlock, CountBlock, SummaryBlock

pipeline = Assembly([
    CleanBlock(),
    CountBlock(),
    SummaryBlock(),
])

result = pipeline.run_sync(RawText(text="  hello   pylego  world  "))
print(result.message)
# "hello pylego world" — 단어 3개
```

실행:

```bash
python main.py
```

---

## 6. 이벤트 관찰 추가

각 블록의 실행 시간과 성공/실패 여부를 수집합니다.

```python
# main.py (관찰 추가)
import asyncio
from pylego_blocks import Assembly, observe
from pylego_blocks.core.events import CollectingEventBus
from pylego_blocks.core.visualize import build_stats
from studs import RawText
from blocks import CleanBlock, CountBlock, SummaryBlock

pipeline = Assembly([CleanBlock(), CountBlock(), SummaryBlock()])

bus = CollectingEventBus()
with observe(bus):
    result = pipeline.run_sync(RawText(text="  hello   pylego  world  "))

print(result.message)

stats = build_stats(bus.events)
for name, stat in stats.items():
    status = "실패" if stat.error_msg else "성공"
    print(f"  {name}: {stat.elapsed_sec*1000:.2f}ms  {status}")
```

출력 예시:

```
"hello pylego world" — 단어 3개
  CleanBlock:   0.01ms  성공=1
  CountBlock:   0.00ms  성공=1
  SummaryBlock: 0.01ms  성공=1
```

---

## 7. 에러 처리 — RetryBlock

외부 API 호출처럼 일시 장애가 발생할 수 있는 블록에 재시도 정책을 추가합니다.

```python
from pylego_blocks import RetryBlock, RetryPolicy
from blocks import SummaryBlock

# 최대 3회 재시도, 0.5초 대기, 지수 백오프 2배
safe_summary = RetryBlock(
    SummaryBlock(),
    policy=RetryPolicy(max_attempts=3, delay_sec=0.5, backoff=2.0),
)

pipeline = Assembly([CleanBlock(), CountBlock(), safe_summary])
```

또는 `wrap()` 빌더를 사용합니다:

```python
from pylego_blocks import wrap
from blocks import SummaryBlock

safe_summary = wrap(SummaryBlock()).retry().timeout(5.0).build()
```

---

## 8. pytest 테스트 작성 — `test_pipeline.py`

```python
# test_pipeline.py
import asyncio
import pytest
from pylego_blocks import Assembly
from studs import RawText, Summary
from blocks import CleanBlock, CountBlock, SummaryBlock

pipeline = Assembly([CleanBlock(), CountBlock(), SummaryBlock()])


# --- 동기 테스트 ---

def test_basic_run() -> None:
    result = pipeline.run_sync(RawText(text="hello world"))
    assert isinstance(result, Summary)
    assert "2개" in result.message


def test_whitespace_normalization() -> None:
    result = pipeline.run_sync(RawText(text="  a  b  c  "))
    assert "3개" in result.message


def test_single_word() -> None:
    result = pipeline.run_sync(RawText(text="pylego"))
    assert "1개" in result.message


# --- 비동기 테스트 (pytest-asyncio) ---

async def test_async_run() -> None:
    result = await pipeline.run(RawText(text="hello pylego world"))
    assert "3개" in result.message


# --- 각 블록 단위 테스트 ---

async def test_clean_block_strips_whitespace() -> None:
    from blocks import CleanBlock
    from studs import RawText, CleanText

    block = CleanBlock()
    result = await block.run(RawText(text="  hello   world  "))
    assert result.text == "hello world"


async def test_count_block() -> None:
    from blocks import CountBlock
    from studs import CleanText, WordCount

    block = CountBlock()
    result = await block.run(CleanText(text="a b c d"))
    assert result.count == 4


# --- 이벤트 버스 검증 ---

def test_all_blocks_emit_events() -> None:
    from pylego_blocks import observe
    from pylego_blocks.core.events import CollectingEventBus
    from pylego_blocks.core.visualize import build_stats

    bus = CollectingEventBus()
    with observe(bus):
        pipeline.run_sync(RawText(text="hello world"))

    stats = build_stats(bus.events)
    assert "CleanBlock" in stats
    assert "CountBlock" in stats
    assert "SummaryBlock" in stats
    assert all(s.error_msg is None for s in stats.values())
```

실행:

```bash
pytest test_pipeline.py -v
```

---

## 9. I/O 계약 불일치 — 조립 시점 오류 확인

잘못된 순서로 블록을 연결하면 **런타임이 아닌 조립 시점**에 즉시 오류가 발생합니다.

```python
from pylego_blocks import Assembly
from blocks import CleanBlock, CountBlock, SummaryBlock
from studs import RawText

# CountBlock은 CleanText를 입력으로 받는데, SummaryBlock의 출력 WordCount를 넘기면?
bad = Assembly([SummaryBlock(), CleanBlock()])
# IncompatibleSnapError: SummaryBlock.output(Summary) != CleanBlock.input(RawText)
```

---

## 10. 파이프라인 시각화

```python
from pylego_blocks import Assembly
from pylego_blocks.core.visualize import to_mermaid
from blocks import CleanBlock, CountBlock, SummaryBlock

pipeline = Assembly([CleanBlock(), CountBlock(), SummaryBlock()])
print(to_mermaid(pipeline))
```

출력 (Mermaid flowchart):

```
flowchart LR
subgraph asm_1["Assembly"]
    direction LR
    b_2["CleanBlock"]
    b_3["CountBlock"]
    b_4["SummaryBlock"]
end
    b_2 --> b_3
    b_3 --> b_4
```

[Mermaid Live Editor](https://mermaid.live)에 붙여넣으면 다이어그램으로 확인할 수 있습니다.

---

## 11. 완성 코드 한눈에 보기

```python
# all_in_one.py — 단일 파일 완성본
import asyncio
from pylego_blocks import Block, Assembly, Stud, observe
from pylego_blocks.core.events import CollectingEventBus
from pylego_blocks.core.visualize import build_stats


class RawText(Stud):
    text: str

class CleanText(Stud):
    text: str

class WordCount(Stud):
    text: str
    count: int

class Summary(Stud):
    message: str


class CleanBlock(Block[RawText, CleanText]):
    input_model = RawText
    output_model = CleanText
    async def run(self, inp: RawText) -> CleanText:
        return CleanText(text=" ".join(inp.text.split()))

class CountBlock(Block[CleanText, WordCount]):
    input_model = CleanText
    output_model = WordCount
    async def run(self, inp: CleanText) -> WordCount:
        return WordCount(text=inp.text, count=len(inp.text.split()))

class SummaryBlock(Block[WordCount, Summary]):
    input_model = WordCount
    output_model = Summary
    async def run(self, inp: WordCount) -> Summary:
        return Summary(message=f'"{inp.text}" — 단어 {inp.count}개')


pipeline = Assembly([CleanBlock(), CountBlock(), SummaryBlock()])

bus = CollectingEventBus()
with observe(bus):
    result = pipeline.run_sync(RawText(text="  hello   pylego  world  "))

print(result.message)

for name, stat in build_stats(bus.events).items():
    print(f"  {name}: {stat.elapsed_sec*1000:.3f}ms")
```

---

## 다음 단계

| 목표 | 문서 |
|------|------|
| 에러 복구 패턴 심화 | [튜토리얼 3: 탄력성](03-resilience.md) |
| 실행 통계·헬스 체크 | [튜토리얼 4: 관측성](04-observability.md) |
| Redis 분산 큐 | [튜토리얼 5: 분산 처리](05-distributed.md) |
| 전체 API 레퍼런스 | `CLAUDE.md` (프로젝트 루트) |
