# 튜토리얼 1: Hello World

첫 번째 pylego 파이프라인을 만들어 봅니다.

## 목표

텍스트를 받아 대문자로 변환한 뒤 느낌표를 붙이는 2단계 파이프라인.

## 구현

```python
import asyncio
from pylego_blocks import Block, Assembly, Stud

# 1. I/O 계약 정의
class TextIn(Stud):
    text: str

class TextOut(Stud):
    result: str

# 2. 블록 구현
class UpperBlock(Block[TextIn, TextOut]):
    input_model = TextIn
    output_model = TextOut

    async def run(self, inp: TextIn) -> TextOut:
        return TextOut(result=inp.text.upper())

class ExclamBlock(Block[TextOut, TextOut]):
    input_model = TextOut
    output_model = TextOut

    async def run(self, inp: TextOut) -> TextOut:
        return TextOut(result=inp.result + "!")

# 3. 조립
pipeline = Assembly([UpperBlock(), ExclamBlock()])

# 4. 실행
result = pipeline.run_sync(TextIn(text="hello world"))
print(result.result)  # HELLO WORLD!
```

## 계약 검증

Assembly는 조립 시점에 블록 간 I/O 타입을 자동으로 검증합니다.

```python
# 이건 조립 시점에 오류 발생
bad_pipeline = Assembly([ExclamBlock(), UpperBlock()])
# AssemblyError: ExclamBlock output TextOut != UpperBlock input TextIn
```

## 비동기 실행

```python
async def main() -> None:
    result = await pipeline.run(TextIn(text="hello"))
    print(result.result)

asyncio.run(main())
```

## 다음

[튜토리얼 2: Assembly 체인 →](02-assembly.md)
