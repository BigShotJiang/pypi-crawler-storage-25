# 튜토리얼 5: 분산 파이프라인

asyncio.Queue에서 Redis 큐로 교체해 멀티프로세스·멀티머신 파이프라인을 구성합니다.

## asyncio.Queue 기반 (단일 프로세스)

```python
import asyncio
from pylego_blocks import Queue, WorkerPool, Block, Stud

class Job(Stud):
    id: int
    data: str

class Result(Stud):
    id: int
    processed: str

class ProcessBlock(Block[Job, Result]):
    input_model = Job
    output_model = Result
    async def run(self, inp: Job) -> Result:
        return Result(id=inp.id, processed=inp.data.upper())

async def main() -> None:
    src: Queue[Job] = Queue()
    pool: WorkerPool[Job, Result] = WorkerPool(ProcessBlock(), concurrency=4)

    async with asyncio.TaskGroup() as tg:
        tg.create_task(pool.run(src))
        for i in range(10):
            await src.put(Job(id=i, data=f"item-{i}"))
        await src.close()

asyncio.run(main())
```

## Redis 큐로 교체 (분산)

```bash
pip install pylego-blocks[redis]
```

```python
from pylego_blocks import RedisQueue, RedisWorkerPool

# asyncio.Queue → RedisQueue: 코드 변경 최소화
src: RedisQueue[Job] = RedisQueue(
    Job,
    url="redis://localhost:6379",
    queue_name="jobs:incoming",
)
pool: RedisWorkerPool[Job, Result] = RedisWorkerPool(
    ProcessBlock(),
    concurrency=4,
)
```

## 환경변수 팩토리

```python
import os
from pylego_blocks import make_queue

os.environ["PYLEGO_QUEUE_BACKEND"] = "redis"
os.environ["PYLEGO_REDIS_URL"] = "redis://redis-host:6379"

# 환경변수에 따라 asyncio.Queue 또는 RedisQueue 반환
q = make_queue(Job, queue_name="jobs")
```

## 멀티머신 파이프라인

```
[Producer 서버]           [Worker 서버 × N]
  RedisQueue.put(job) →  RedisWorkerPool.run(src) → RedisQueue.put(result)
                                ↓
                         [Result Consumer 서버]
                           RedisQueue.consume → 최종 처리
```

```python
# producer.py (별도 프로세스/서버)
import asyncio
from pylego_blocks import RedisQueue
from myapp import Job

async def produce() -> None:
    q: RedisQueue[Job] = RedisQueue(Job, url="redis://host:6379", queue_name="jobs")
    for i in range(100):
        await q.put(Job(id=i, data=f"item-{i}"))
    await q.close()

# worker.py (N개 워커 서버에서 동시 실행)
async def work() -> None:
    src: RedisQueue[Job] = RedisQueue(Job, url="redis://host:6379", queue_name="jobs")
    dst: RedisQueue[Result] = RedisQueue(Result, url="redis://host:6379", queue_name="results")
    pool: RedisWorkerPool[Job, Result] = RedisWorkerPool(ProcessBlock(), concurrency=8)
    await pool.run(src, output=dst)
```

## Redis Dead Letter Queue

```python
from pylego_blocks import RedisDeadLetterQueue

dlq: RedisDeadLetterQueue[Job] = RedisDeadLetterQueue(
    Job,
    url="redis://host:6379",
    queue_name="jobs:dlq",
)

# 실패 항목 저장
await dlq.put_failed(failed_job, reason="처리 불가")

# 재처리
retry_q: RedisQueue[Job] = RedisQueue(Job, url="redis://host:6379", queue_name="jobs:retry")
async for item, reason in dlq.failed_items():
    print(f"재처리 대상: {item.id} — {reason}")
    await dlq.retry(item, retry_q)
```

---

축하합니다! 이제 pylego의 핵심 기능을 모두 살펴봤습니다.

- [API 레퍼런스 →](../api/index.md)
