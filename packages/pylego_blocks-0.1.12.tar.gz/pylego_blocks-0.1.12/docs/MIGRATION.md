# 마이그레이션 가이드

---

## v2.x → v3.0.0

### 새 기능 (하위 호환 — 기존 코드 변경 불필요)

모든 신규 기능은 기존 API에 영향 없이 추가됐습니다.

#### 즉시 활용 가능한 신규 API

```python
# M24 — 의심 신호 집계
from pylego_blocks import SignalAggregator, SignalScore
agg = SignalAggregator(threshold=0.5, strategy="max")
agg.record(SignalScore(score=0.8, reason="낮은 신뢰도", block_name="AiBlock"))
if agg.is_suspicious:
    ...

# M25 — 복수 관점 합의
from pylego_blocks import MultiPerspectiveBlock, MajorityVote, ConsensusPolicy
block = MultiPerspectiveBlock(
    perspectives=[BlockA(), BlockB(), BlockC()],
    vote_fn=MajorityVote(min_agreement=2),
    consensus_policy=ConsensusPolicy(raise_error=True),
)

# M22 — Unit 의미론적 재시도
from pylego_blocks import SemanticRetryPolicy
class MyUnit(Unit[MyInput]):
    retry_policy = SemanticRetryPolicy(max_attempts=3)
    async def enrich(self, inp, result, error): ...
```

#### 주의: 합의 전략 클래스명

v3.0.0 에서 합의 전략은 **CamelCase callable 클래스**입니다.

```python
# v3.0.0 — 올바른 사용
vote_fn=MajorityVote(min_agreement=2)
vote_fn=ConfidenceWeighted(weights=[1.0, 0.8, 0.9])
vote_fn=UnanimousRequired()
```

---

## v1.x → v2.0.0

변경 사항 없음 — CircuitBreakerBlock, OtelEventBus, DAG 시각화, Unit 계층,
HTTP 서빙, Redis 분산 큐가 추가됐으며 모두 하위 호환입니다.

---

## pipeline.sh → pylego CLI (v1.0.0)

## 개요

pylego v1.0.0부터 `pipeline.sh` 기반 ai-pi 파이프라인을 `python -m pylego run` (또는 `pylego run`)으로 완전 대체합니다.

---

## 환경변수 대응표

| pipeline.sh | pylego | 설명 |
|-------------|--------|------|
| `CLAUDE_MODEL` | `PYLEGO_MODEL` | 사용할 Claude 모델명 |
| `BASE_BRANCH` | `PYLEGO_BASE_BRANCH` | 기준 브랜치 (기본: `main`) |
| `PROMPT_BACKEND` | `PYLEGO_PROMPT_BACKEND` | 프롬프트 백엔드 (`claude_cli` / `acp`) |
| `LOG_LEVEL` | `PYLEGO_LOG_LEVEL` | 로그 레벨 (설정 시 `LoggingEventBus` 자동 활성화) |
| *(없음)* | `PYLEGO_CHECKPOINT_DIR` | 체크포인트 저장 디렉터리 (M12) |

---

## 명령어 대응표

| pipeline.sh | pylego CLI |
|-------------|------------|
| `./pipeline.sh run <issue>` | `pylego run <issue>` |
| `./pipeline.sh run <issue> --dev-only` | `pylego run <issue> --dev-only` |
| `./pipeline.sh inspect` | `pylego inspect matrix` |
| `./pipeline.sh list-blocks` | `pylego inspect list` |

---

## 빠른 전환 예제

### Before (pipeline.sh)

```bash
BASE_BRANCH=develop \
PROMPT_BACKEND=claude_cli \
./pipeline.sh run 42
```

### After (pylego CLI)

```bash
PYLEGO_BASE_BRANCH=develop \
PYLEGO_PROMPT_BACKEND=claude_cli \
pylego run 42
```

---

## 체크포인팅 활용 (M12 신기능)

장시간 실행 파이프라인이 중단되어도 재시작 시 완료된 블록을 스킵합니다.

```bash
PYLEGO_CHECKPOINT_DIR=./runs \
PYLEGO_BASE_BRANCH=develop \
pylego run 42
```

중단 후 재실행:

```bash
# 동일 명령 재실행 — 이미 완료된 블록은 스킵
PYLEGO_CHECKPOINT_DIR=./runs \
PYLEGO_BASE_BRANCH=develop \
pylego run 42
```

체크포인트를 초기화하려면 해당 파일 삭제:

```bash
rm ./runs/AiPiPipeline.json
```

---

## 이벤트 관찰 (M8 신기능)

블록 실행 추적이 필요할 때:

```bash
PYLEGO_LOG_LEVEL=DEBUG \
pylego run 42
```

커스텀 이벤트 핸들러:

```python
from pylego_blocks import observe, LoggingEventBus

with observe(LoggingEventBus()):
    result = await pipeline.run(inp)
```

---

## 에러 복구 설정 (M9 신기능)

```python
from pylego_blocks import RetryBlock, RetryPolicy, FallbackBlock

# 3회 재시도, 지수 백오프
resilient = RetryBlock(my_block, RetryPolicy(max_attempts=3, delay_sec=1.0, backoff=2.0))

# fallback 블록 지정
safe = FallbackBlock(primary=resilient, fallback=fallback_block)
```

---

## 설치

```bash
pip install pylego-blocks          # PyPI 정식
pip install pylego-blocks==1.0.0   # 특정 버전
```

---

## 지원

- 변경 이력: [Changelog](changelog.md)
