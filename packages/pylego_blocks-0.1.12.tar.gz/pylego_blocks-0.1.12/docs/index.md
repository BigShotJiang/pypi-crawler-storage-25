# pylego

**Composable block-based Python pipeline framework**

pylego는 레고 브릭처럼 조합 가능한 블록으로 파이프라인을 구성하는 Python 프레임워크입니다.

---

## 빠른 시작

```bash
pip install pylego-blocks
```

```python
from pylego_blocks import Block, Assembly, Stud

class TextIn(Stud):
    text: str

class TextOut(Stud):
    result: str

class UpperBlock(Block[TextIn, TextOut]):
    input_model = TextIn
    output_model = TextOut

    async def run(self, inp: TextIn) -> TextOut:
        return TextOut(result=inp.text.upper())

class ExclamBlock(Block[TextOut, TextOut]):
    input_model = TextOut
    output_model = TextOut

    async def run(self, inp: TextOut) -> TextOut:
        return TextOut(result=inp.result + "!")

pipeline = Assembly([UpperBlock(), ExclamBlock()])
result = pipeline.run_sync(TextIn(text="hello"))
print(result.result)  # HELLO!
```

---

## 왜 pylego인가?

| 레고 | pylego | 의미 |
|------|--------|------|
| Stud/Tube | `Stud` | 블록이 붙는 표준 인터페이스 |
| Brick | `Block` | 단일 책임 최소 실행 단위 |
| Plate | `Assembly` | 블록 체인 조립체 |
| Fan shape | `FanOut` | N개 브랜치 동시 실행 |
| Switch track | `Branch` | 조건 분기 |

---

## 핵심 특징

- **타입 안전** — pydantic v2 기반 I/O 계약, 조립 시점 검증
- **비동기 우선** — 모든 블록은 `async def run()`, asyncio 네이티브
- **관찰 가능성** — OpenTelemetry 통합, DAG 시각화 (`to_mermaid` / `to_dot` / `to_html`)
- **에러 복구** — `RetryBlock` / `FallbackBlock` / `CircuitBreakerBlock` / `TimeoutBlock`
- **HTTP 서빙** — `Assembly`를 `POST /run` REST API로 즉시 노출 (`pylego[serve]`)
- **분산 큐** — asyncio.Queue → Redis 교체 한 줄 (`pylego[redis]`)
- **Unit 계층** — `validate() → run() → verify()` 3단계 생명주기

---

## 설치 옵션

```bash
pip install pylego-blocks              # 코어만
pip install pylego-blocks[serve]       # FastAPI HTTP 서빙 추가
pip install pylego-blocks[otel]        # OpenTelemetry 추가
pip install pylego-blocks[redis]       # Redis 분산 큐 추가
pip install pylego-blocks[all]         # 전체
```

---

## 요구 사항

- Python ≥ 3.12
- pydantic ≥ 2.9
