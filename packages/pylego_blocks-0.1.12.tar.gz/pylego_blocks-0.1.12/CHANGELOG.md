# Changelog

모든 주목할 만한 변경 사항은 이 파일에 기록됩니다.
[Keep a Changelog](https://keepachangelog.com/ko/1.0.0/) 형식을 따릅니다.

---

## [Unreleased]

---

## [3.0.0] — 2026-04-23

### Added

#### VerdictRouter (M21)
- `VerdictParseBlock(strict=True|False)` — AI 출력에서 `PASS`/`FAIL`/`UNKNOWN` 판정을 추출.
  `strict=False` 시 파싱 실패를 예외 대신 `UNKNOWN` 으로 반환.
- `VerdictRouter` — `UnknownPolicy` 에 따라 분기: `raise_error` / `fallback` / `escalate_to` / 기본 통과.
- `UnknownPolicy` — 판정 불능 에스컬레이션 전략 dataclass.

#### SemanticRetryPolicy — Unit 재시도 연계 (M22)
- `SemanticRetryPolicy(max_attempts, retry_on_verify_failure)` — Unit 수준 의미론적 재시도 정책.
- `Unit.enrich(inp, result, error)` — 재시도 전 입력을 보강하는 선택적 생명주기 메서드.
- `Unit.execute()` — `validate → (run → verify → enrich) ×N` 루프 구현.

#### Stud 의미론적 검증 공식화 (M23)
- `@field_validator` / `@model_validator` 활용 패턴을 CLAUDE.md §2 에 공식화.
- 검증 계층 선택 기준 표 추가 (즉시 vs. async vs. 실행 후 검증).

#### SignalAggregator (M24)
- `SignalScore(score, reason, block_name)` — 의심 신호 단위 Stud.
- `AggregationStrategy = Literal["max", "mean", "any"]` — 집계 전략 타입.
- `SignalAggregator(threshold, strategy)` — 신호 누적·집계, `is_suspicious` 프로퍼티.
- `TapBlock` 과 연계하여 파이프라인 흐름을 방해하지 않는 의심 지수 추적 패턴.

#### MultiPerspectiveBlock (M25)
- `MultiPerspectiveBlock(perspectives, vote_fn, *, consensus_policy, name)` — N관점 병렬 평가 + 합의.
- `MajorityVote(min_agreement)` — 최다 득표 합의 전략 (callable 클래스).
- `ConfidenceWeighted(weights)` — 가중치 기반 합의 전략 (callable 클래스).
- `UnanimousRequired()` — 만장일치 합의 전략 (callable 클래스).
- `ConsensusError(RuntimeError)` — 합의 실패 예외.
- `ConsensusPolicy(raise_error, fallback, escalate_to)` — 합의 실패 대응 정책.

### Changed
- `pyproject.toml` 버전 `2.0.0` → `3.0.0`.
- `CLAUDE.md` — 설계 원칙, MultiPerspectiveBlock 관점 다양성 경고, enrich_fn 갱신 워크플로우 추가 (M29).

---

## [2.0.0] — 2026-04-23

### Added

#### 파이프라인 강건성 (M15)
- `CircuitBreakerBlock(inner, failure_threshold, reset_timeout)` — 연속 실패 시 fast-fail, reset 후 자동 복구.
- `CircuitBreakerStateEvent` — circuit 상태 변화를 이벤트로 관찰.
- `DeadLetterQueue[T]` — 최종 실패 항목 격리·재처리 API (`put_failed` / `retry` / `failed_items`).

#### OpenTelemetry 통합 (M16)
- `OtelEventBus` — Block 이벤트를 OTEL span 으로 변환 (`observe(OtelEventBus())`).
- `configure_otel_from_env()` — `PYLEGO_OTEL_ENDPOINT` / `PYLEGO_OTEL_SERVICE_NAME` 환경변수로 OTLP 익스포터 초기화.
- `pylego[otel]` optional extra — `opentelemetry-api/sdk` 선택적 의존성.

#### DAG 시각화 (M17)
- `to_mermaid(block)` — Mermaid flowchart 텍스트 반환 (Assembly subgraph, FanOut, Branch 포함).
- `to_dot(block)` — Graphviz DOT 텍스트 반환.
- `to_html(block, stats)` — Mermaid.js CDN 기반 자급 HTML 리포트, 블록별 통계 테이블.
- `CollectingEventBus` — 이벤트 수집 버스, `build_stats()` 와 연동.
- `build_stats(events)` — `BlockEvent` 목록으로 블록별 `BlockStat` 딕셔너리 생성.
- `pylego inspect graph <yaml> [--format mermaid|dot|html]` CLI.

#### Unit 계층 (M17.5)
- `Unit[T]` — `validate() → run() → verify()` 3단계 생명주기 추상 베이스.
- `UnitResult(Stud)` — 공통 출력 모델 (`status`, `result`, `reason`, `failed_at`).
- `UnitPipeline[T]` — Unit 선형 체인, 실패 전파, `ResultUnit` 연동.
- `ConfigBlock[ConfigT]` — 파이프라인 시작 전 설정을 주입하는 블록 베이스.
- `ResultUnit` — 파이프라인 마지막 성공/실패 분기 전담 Unit.
- `pylego run-unit <module.Class> [--input JSON] [--schema]` CLI.

#### HTTP API 게이트웨이 (M18)
- `build_app(assembly)` — FastAPI 앱 생성 (`POST /run`, `GET /health`, `GET /openapi.json`).
- `serve(assembly, host, port, reload)` — uvicorn 블로킹 서버 실행.
- `pylego serve <yaml> [--host] [--port] [--reload]` CLI.
- `pylego[serve]` optional extra — `fastapi` / `uvicorn` 선택적 의존성.

#### 분산 작업 큐 Redis 백엔드 (M19)
- `RedisQueue[T]` — Redis List 기반 분산 큐 (`Queue[T]` async 인터페이스 호환).
- `RedisWorkerPool[T, R]` — `RedisQueue` 소비 분산 워커 풀.
- `RedisDeadLetterQueue[T]` — Redis 기반 DLQ (`DeadLetterQueue` 인터페이스 호환).
- `make_queue(item_type)` — `PYLEGO_QUEUE_BACKEND=redis` 환경변수로 asyncio ↔ Redis 백엔드 팩토리.
- `PYLEGO_REDIS_URL` 환경변수 지원.
- `pylego[redis]` optional extra — `redis>=5.0` 선택적 의존성.

#### 문서 사이트 (M20)
- MkDocs Material 기반 문서 사이트 (`mkdocs.yml`).
- mkdocstrings 기반 API 레퍼런스 자동 생성.
- 튜토리얼 5단계 (Hello World → 분산 파이프라인).
- v1 → v2 마이그레이션 가이드.
- GitHub Actions docs 자동 배포 워크플로우.

### Changed
- `pyproject.toml` 버전 `1.0.0` → `2.0.0`.
- `Development Status` classifier `4 - Beta` → `5 - Production/Stable`.

### Fixed
- `pipeline.sh dirty_fail` — Dev 블록 부수 효과 파일 자동 스테이징 처리 (M15).

---

## [1.0.0] — 2026-04-23

### Added

#### 관찰 가능성 (M8)
- `BlockStartedEvent` / `BlockCompletedEvent` / `BlockFailedEvent` / `BlockRetryEvent` — frozen dataclass 이벤트 타입.
- `EventBus` Protocol — 커스텀 이벤트 핸들러 계약.
- `LoggingEventBus` — `pylego.events` logger 구조화 출력.
- `observe(bus)` context manager — ContextVar 기반, 중첩 Assembly 자동 전파.
- `PYLEGO_LOG_LEVEL` 환경변수로 자동 활성화.
- `Assembly.run()` 각 블록 전후 이벤트 emit (시그니처 변경 없음).

#### 에러 복구 (M9)
- `RetryPolicy(max_attempts, delay_sec, backoff)` — 재시도 정책 frozen dataclass.
- `RetryBlock(inner, policy)` — 실패 시 정책대로 재시도, 재시도마다 `BlockRetryEvent` 발행.
- `FallbackBlock(primary, fallback)` — primary 실패 시 fallback 실행, 조립 시점 계약 검증.
- `TimeoutBlock(inner, timeout_sec)` — `asyncio.wait_for` 래퍼.

#### 스트리밍 & 이벤트 큐 (M10)
- `StreamBlock[I, O]` — `stream()` abstract (AsyncGenerator), `run()` 마지막 항목 반환.
- `Assembly.stream(inp)` — 각 블록 완료 후 `(block_name, output)` yield.
- `Queue[T]` — asyncio.Queue 기반 타입 안전 작업 큐 (`put` / `close` / `async for`).
- `WorkerPool[T, R]` — N개 동시 워커, `output=Queue` 파이프 연결.

#### 분산 런타임 (M11)
- `ProcessRuntime(workers=N)` — `ProcessPoolExecutor` 기반 실제 병렬 실행.
- `FanOut` `runtime=ProcessRuntime(...)` 파라미터 추가.
- 조립 시점 pickle 가능 여부 검증.
- pydantic JSON 직렬화로 프로세스 경계 통신.

#### 상태 블록 & 체크포인팅 (M12)
- `Store` ABC + `InMemoryStore` + `FileStore` — key-value 저장소 계층.
- `StoreBlock[V]` — 값을 저장소에 보존하는 pass-through 블록.
- `Checkpoint` + `MemoryCheckpoint` + `FileCheckpoint` — Assembly 실행 체크포인팅.
- `Assembly.run(checkpoint=...)` — 블록 완료 후 저장, 재실행 시 완료 블록 스킵.
- `PYLEGO_CHECKPOINT_DIR` 환경변수로 전역 체크포인트 경로 설정.

#### PyPI 퍼블리싱 & 플러그인 생태계 (M13)
- `BlockRegistry.discover()` — `pylego.blocks` entry-points에서 서드파티 블록 자동 수집.
- `pylego inspect list --installed` — 설치된 모든 블록(서드파티 포함) 표시.
- `examples/plugin-example/` — 외부 패키지 플러그인 스켈레톤.
- GitHub Actions TestPyPI OIDC publish 워크플로우.

### Changed
- `pyproject.toml` 버전 `0.1.0` → `1.0.0`.
- `Development Status` classifier `3 - Alpha` → `4 - Beta`.

---

## [0.1.0] — 2026-04-23

### Added

#### Core (M1)
- `Block[InputT, OutputT]` — pydantic v2 기반 최소 실행 단위. `async def run()` 강제.
- `Stud` — 블록 간 I/O 계약 베이스 클래스 (pydantic `BaseModel`).
- `Assembly[InputT, OutputT]` — 블록 체인 선형 조립. 조립 시점 Stud 계약 검증.
- `Assembly.run_sync()` — `asyncio.run()` 래퍼 동기 편의 API (M5).

#### DAG·분기 (M2)
- `FanOut(Block[Stud, Gathered])` — `asyncio.gather` 기반 N-브랜치 동시 실행.
- `Gathered(Stud)` — FanOut 결과 래퍼 (`results: tuple[Any, ...]`).
- `CyclicAssemblyError` — 조립 시점 순환 참조·중복 인스턴스 감지.

#### Registry·YAML (M4)
- `BlockRegistry` — 블록 등록(`register`), 조회(`get`), 목록(`all`), entry-points 디스커버리.
- `default_registry` / `register` — 모듈 레벨 편의 API.
- `load_assembly(path)` — YAML 선언형 Assembly 로더 (`module.Class` / `module:Class` 형식).
- `load_assembly_from_yaml` — 하위 호환 별칭.
- `pylego assemble <yaml>` CLI 서브커맨드.

#### Testing (M3)
- `assert_block_contract` / `ContractResult` — 비동기 블록 계약 검증 헬퍼.
- `@pytest.mark.pylego_contracts` — 블록별 계약 테스트 마커.
- Assembly golden snapshot 지원 (`PYLEGO_UPDATE_GOLDEN=1`).
- `pylego inspect` / `pylego inspect matrix` CLI.

#### AI Pipeline (M6)
- `AiPiPipelineConfig`, `build_ai_pi_pipeline`, `run_ai_pi` — Dev/QA 데몬 오케스트레이션 파이프라인.
- `pylego run <issue>` CLI — GitHub 이슈 기반 end-to-end 파이프라인 실행.

### Changed
- `pyproject.toml` 버전 `0.0.1` → `0.1.0`.
- `Development Status` classifier `1 - Planning` → `3 - Alpha`.

---

## [0.0.1] — 초기 스캐폴딩

- 프로젝트 구조 초기화 (src-layout, uv, mypy strict, pytest-asyncio).
