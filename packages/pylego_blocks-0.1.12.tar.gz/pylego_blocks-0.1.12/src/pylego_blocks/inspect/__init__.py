"""pylego inspect API."""

from __future__ import annotations

from pylego_blocks.inspect.cli import inspect_list, inspect_matrix, inspect_show
from pylego_blocks.inspect.discovery import iter_blocks
from pylego_blocks.inspect.graph import inspect_graph

__all__ = [
    "inspect_graph",
    "inspect_list",
    "inspect_matrix",
    "inspect_show",
    "iter_blocks",
]
