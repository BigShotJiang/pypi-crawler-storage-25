"""pylego inspect graph — Assembly 구조를 Mermaid / DOT / HTML 로 출력한다."""

from __future__ import annotations

import sys


def inspect_graph(
    assembly_path: str,
    output_format: str = "mermaid",
    output_file: str | None = None,
) -> int:
    """YAML Assembly 파일을 읽어 그래프 텍스트를 출력한다.

    Args:
        assembly_path: Assembly YAML 파일 경로.
        output_format: ``"mermaid"``, ``"dot"``, ``"html"`` 중 하나.
        output_file: 결과를 저장할 파일 경로. None 이면 stdout 출력.

    Returns:
        종료 코드 (0=성공, 1=실패).
    """
    try:
        from pylego_blocks.declarative import load_assembly_from_yaml
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    try:
        assembly = load_assembly_from_yaml(assembly_path)
    except Exception as exc:
        print(f"error: failed to load assembly: {exc}", file=sys.stderr)
        return 2

    from pylego_blocks.core.visualize import to_dot, to_html, to_mermaid

    fmt = output_format.lower()
    if fmt == "mermaid":
        text = to_mermaid(assembly)
    elif fmt == "dot":
        text = to_dot(assembly)
    elif fmt == "html":
        text = to_html(assembly)
    else:
        print(f"error: unknown format {output_format!r} (mermaid|dot|html)", file=sys.stderr)
        return 2

    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"written to {output_file}")
    else:
        print(text, end="")

    return 0
