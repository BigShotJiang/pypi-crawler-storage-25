"""ai-pi 파이프라인 팩토리와 실행 API."""

from __future__ import annotations

import asyncio
import json
import os
import shlex
import sys
import tempfile
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Literal

from pylego_blocks.blocks.ai import (
    AcpDaemonError,
    AcpPromptBlock,
    AcpPromptRequest,
    VerdictParseBlock,
    VerdictParseRequest,
)
from pylego_blocks.blocks.prompt.base import PromptRequest
from pylego_blocks.blocks.prompt.claude_cli import ClaudeCliBlock
from pylego_blocks.blocks.git import BranchPrepareBlock, BranchSpec, MergeRequest, MergeToMainBlock
from pylego_blocks.blocks.git._runner import default_git_runner as _default_git_runner
from pylego_blocks.blocks.github import (
    IssueCloseBlock,
    IssueCloseRequest,
    IssueCommentBlock,
    IssueCommentRequest,
    IssueInspectBlock,
    IssueMetadata,
    IssueRef,
    LabelTransitionBlock,
    LabelTransitionRequest,
)
from pylego_blocks.blocks.github.issue import _default_gh_runner
from pylego_blocks.core import Assembly, Block, Branch, Stud

GhRunner = Callable[[list[str]], Awaitable[tuple[int, str, str]]]
GitRunner = Callable[[list[str]], Awaitable[tuple[int, str, str]]]
SocketSender = Callable[[str, str, float], Awaitable[str]]
AutoVerdictRunner = Callable[[list[str]], Awaitable[tuple[int, str, str]]]

DEFAULT_COPILOT_SOCKET_PATH = str(Path(tempfile.gettempdir()) / "copilot-acp.sock")
DEFAULT_GEMINI_SOCKET_PATH = str(Path(tempfile.gettempdir()) / "gemini-acp.sock")


def _log_stage(name: str, event: str, **extra: object) -> None:
    """Emit a stage event line to stderr unless PYLEGO_LOG_STAGES=0.

    Format: ``[stage] <name> <event> [k=v ...]``. Flush immediately so external
    tee/grep monitors see pipeline progress without buffering delays. Without
    this signal, pipeline aborts (e.g. the #53 merge-time RuntimeError) leave
    no breadcrumbs for diagnosis.
    """
    if os.environ.get("PYLEGO_LOG_STAGES", "1") == "0":
        return
    parts = [f"[stage] {name} {event}"]
    for k, v in extra.items():
        parts.append(f"{k}={v!r}")
    print(" ".join(parts), file=sys.stderr, flush=True)


class AiPiPipelineConfig(Stud):
    repo: str
    issue_number: int
    copilot_socket_path: str = DEFAULT_COPILOT_SOCKET_PATH
    gemini_socket_path: str = DEFAULT_GEMINI_SOCKET_PATH
    base_branch: str = "main"
    # #35: 기본 600s (10 min). Dev 구현은 파일 다수 생성·테스트 작성 포함해
    # 실제로 수 분 소요. Daemon prompt_timeout 과 동일하게 맞춰 daemon 이
    # 먼저 ERROR 응답을 내기보다는 pipeline 측 TimeoutError 가 우선 catch 되도록.
    dev_prompt_timeout_sec: float = 600.0
    qa_prompt_timeout_sec: float = 600.0
    prompt_backend: Literal["copilot", "claude_cli"] = "copilot"


class PipelineResult(Stud):
    issue_number: int
    final_state: Literal["merged", "failed", "escalated"]
    fail_count: int
    verdict: Literal["PASS", "FAIL", "UNKNOWN"]


class _PipelineContext(Stud):
    repo: str
    issue_number: int
    issue_title: str
    issue_state: Literal["OPEN", "CLOSED"]
    labels: tuple[str, ...]
    base_branch: str
    feature_branch: str
    copilot_socket_path: str
    gemini_socket_path: str
    dev_prompt_timeout_sec: float
    qa_prompt_timeout_sec: float
    prompt_backend: Literal["copilot", "claude_cli"] = "copilot"
    fail_count: int = 0
    dev_response: str = ""
    qa_response: str = ""
    verdict: Literal["PASS", "FAIL", "UNKNOWN"] = "UNKNOWN"


def _build_dev_rework_instruction(ctx: _PipelineContext) -> str:
    if ctx.fail_count <= 0:
        return ""
    lines = [
        f"## 재작업 지시 ({ctx.fail_count}차 FAIL 이후 재개)",
        "",
        f"이 이슈는 {ctx.fail_count}차 FAIL 후 재작업입니다. 다음 순서로 처리하세요:",
        (
            f"1. 이슈 #{ctx.issue_number} 댓글에서 QA 의 가장 최근 FAIL 사유와 "
            "참조된 Bug Issue 번호를 확인."
        ),
        (
            "2. Bug Issue 본문의 근본 원인, 수정 제안, 재현 테스트를 읽고 "
            "수정 계획에 반영."
        ),
        (
            f"3. 수정 완료 후 해당 브랜치에 커밋/푸시하고, 이슈 #{ctx.issue_number} "
            "에 작업 요약 댓글을 남긴 뒤 정확히 `@QA 재검증 요청` 문구를 포함."
        ),
        (
            "4. Bug Issue 는 직접 close 하지 말고, QA 가 원본 이슈 PASS 판정 시 "
            "함께 close 하도록 둬야 합니다."
        ),
        (
            "5. 범위 외 문제가 보이면 수정하지 말고 이슈 댓글로만 보고하세요. "
            "developer.md §8 의 티켓 범위 규칙을 지켜야 합니다."
        ),
    ]
    return "\n".join(lines)


def _build_dev_prompt(ctx: _PipelineContext) -> str:
    labels = ", ".join(ctx.labels) if ctx.labels else "(없음)"
    lines = [
        "## 작업 지시",
        "",
        f"이슈: #{ctx.issue_number}",
        f"브랜치: {ctx.feature_branch}",
        f"리포지토리: {ctx.repo}",
        f"제목: {ctx.issue_title}",
        f"누적 FAIL: {ctx.fail_count}회",
        f"라벨: {labels}",
        "",
        "현재 브랜치와 이슈 본문만 기준으로 구현하세요. 다음 조건을 모두 만족해야 합니다:",
        (
            " - 현재 이슈 범위만 작업하고, 범위 밖 버그는 직접 수정하지 말고 "
            "댓글로만 보고하세요."
        ),
        (
            " - 수정 후 반드시 git add / commit / push 를 수행하고, 결과를 같은 "
            "브랜치에 남겨야 합니다."
        ),
        " - main 브랜치에 직접 커밋하지 마세요.",
        " - 블록 경계와 기존 테스트를 유지하고, 불필요한 파일 수정은 하지 마세요.",
        (
            " - 이슈 본문과 댓글의 QA 지시를 읽고, 재작업이면 Bug Issue 와 "
            "`@QA 재검증 요청` 흐름을 그대로 따르세요."
        ),
        (
            " - 실패를 숨기거나 생략하지 말고, 발견된 문제는 수용 기준에 맞춰 "
            "끝까지 처리하세요."
        ),
    ]
    rework_instruction = _build_dev_rework_instruction(ctx)
    if rework_instruction:
        lines.extend(["", rework_instruction])
    lines.extend(
        [
            "",
            (
                f"브랜치 '{ctx.feature_branch}' 에서 작업하고 해당 브랜치에 커밋/푸시하세요. "
                "main 브랜치에 직접 커밋하지 마세요."
            ),
        ]
    )
    return "\n".join(lines)


def _build_qa_prompt(ctx: _PipelineContext) -> str:
    labels = ", ".join(ctx.labels) if ctx.labels else "(없음)"
    if "type:hotfix" in ctx.labels:
        gate_instruction = (
            "Hotfix 이슈입니다. Gate B(프로젝트 전역 위반 검사)는 면제하고, "
            "Gate A(이슈 범위 내 검증)만 수행하세요."
        )
    else:
        gate_instruction = (
            "일반 이슈입니다. Gate A(이슈 범위 검증)와 Gate B(프로젝트 전역 위반 검사)를 "
            "모두 수행하세요."
        )
    return "\n".join(
        [
            "## 검증 지시",
            "",
            f"이슈: #{ctx.issue_number}",
            f"브랜치: {ctx.feature_branch}",
            f"리포지토리: {ctx.repo}",
            f"제목: {ctx.issue_title}",
            f"누적 FAIL: {ctx.fail_count}회",
            f"라벨: {labels}",
            "",
            gate_instruction,
            "",
            "검증 절차:",
            "1. 코드와 테스트를 검토하고, 이슈 범위의 수용 기준 충족 여부를 판단하세요.",
            (
                f"2. 검증 결과는 이슈 #{ctx.issue_number} 에 §8 PASS/FAIL 템플릿 형식으로 "
                "코멘트하세요."
            ),
            (
                "3. 응답 본문에는 요약과 근거를 충분히 적되, 응답의 마지막 줄은 반드시 "
                "정확히 하나만 출력하세요."
            ),
            (
                "4. 마지막 줄은 `VERDICT: PASS` 또는 `VERDICT: FAIL` 중 하나여야 하며, "
                "다른 형식은 허용되지 않습니다."
            ),
            "5. 마지막 줄 뒤에는 공백 줄이나 추가 문자를 두지 마세요.",
            (
                "6. Hotfix 이슈는 전략 결정이 필요하면 이를 명확히 언급하고, 일반 "
                "이슈는 재작업/블로킹 조건을 분명히 적으세요."
            ),
            "",
            "추가 요구사항:",
            " - 검증 전 이슈와 브랜치 정보를 다시 확인하세요.",
            (
                " - 결과를 숨기지 말고, PASS/FAIL 사유를 코드와 테스트 관점에서 "
                "분명하게 적으세요."
            ),
            (
                " - 답변이 VERDICT 형식에서 벗어나면 상위 로직이 자동 판정을 시도하므로, "
                "반드시 형식을 지키세요."
            ),
        ]
    )


def _build_auto_verdict_command() -> list[str]:
    command = os.environ.get("PYLEGO_AUTO_VERDICT_CMD", "").strip()
    if command:
        return shlex.split(command)
    return ["uv", "run", "pytest", "-q", "--tb=short"]


async def _default_auto_verdict_runner(args: list[str]) -> tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_b, stderr_b = await proc.communicate()
    return (
        proc.returncode if proc.returncode is not None else -1,
        stdout_b.decode(errors="replace"),
        stderr_b.decode(errors="replace"),
    )


class _ConfigToContextBlock(Block[AiPiPipelineConfig, _PipelineContext]):
    input_model = AiPiPipelineConfig
    output_model = _PipelineContext

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._inspect = IssueInspectBlock(gh_runner=gh_runner)
        self._gh = gh_runner if gh_runner is not None else _default_gh_runner

    async def _count_fail_comments(self, repo: str, issue_number: int) -> int:
        exit_code, stdout, stderr = await self._gh(
            [
                "issue",
                "view",
                str(issue_number),
                "--repo",
                repo,
                "--comments",
                "--json",
                "comments",
            ]
        )
        if exit_code != 0:
            raise RuntimeError(
                "gh issue view comments 실패 "
                f"(exit={exit_code}): {stderr.strip() or stdout.strip()}"
            )
        raw = json.loads(stdout)
        comments_raw = raw.get("comments") or []
        fail_count = 0
        for comment in comments_raw:
            body = str(comment.get("body", ""))
            if "## QA 검증 결과: FAIL" in body:
                fail_count += 1
        return fail_count

    async def run(self, inp: AiPiPipelineConfig) -> _PipelineContext:
        metadata: IssueMetadata = await self._inspect.run(
            IssueRef(repo=inp.repo, number=inp.issue_number)
        )
        fail_count = await self._count_fail_comments(inp.repo, inp.issue_number)
        return _PipelineContext(
            repo=metadata.repo,
            issue_number=metadata.number,
            issue_title=metadata.title,
            issue_state=metadata.state,
            labels=metadata.labels,
            base_branch=inp.base_branch,
            feature_branch=f"feature/issue-{metadata.number}",
            copilot_socket_path=inp.copilot_socket_path,
            gemini_socket_path=inp.gemini_socket_path,
            dev_prompt_timeout_sec=inp.dev_prompt_timeout_sec,
            qa_prompt_timeout_sec=inp.qa_prompt_timeout_sec,
            prompt_backend=inp.prompt_backend,
            fail_count=fail_count,
        )


class _StatusTransitionBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(
        self,
        from_label: str | None,
        to_label: str,
        gh_runner: GhRunner | None = None,
    ) -> None:
        self._transition = LabelTransitionBlock(gh_runner=gh_runner)
        self._from_label = from_label
        self._to_label = to_label

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        await self._transition.run(
            LabelTransitionRequest(
                repo=inp.repo,
                number=inp.issue_number,
                from_label=self._from_label,
                to_label=self._to_label,
            )
        )
        return inp


class _BranchPrepareSnapshotBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(self, git_runner: GitRunner | None = None) -> None:
        self._branch = BranchPrepareBlock(git_runner=git_runner)

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        await self._branch.run(
            BranchSpec(
                base_branch=inp.base_branch,
                feature_branch=inp.feature_branch,
            )
        )
        return inp


class _DevPromptBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(
        self,
        socket_sender: SocketSender | None = None,
        gh_runner: GhRunner | None = None,
    ) -> None:
        self._acp = AcpPromptBlock(sender=socket_sender)
        self._claude = ClaudeCliBlock(allowed_tools=["Bash", "Edit", "Write"])
        self._comment = IssueCommentBlock(gh_runner=gh_runner)

    async def _call_prompt(self, inp: _PipelineContext) -> str:
        prompt = _build_dev_prompt(inp)
        if inp.prompt_backend == "claude_cli":
            cli_result = await self._claude.run(
                PromptRequest(prompt=prompt, timeout_sec=inp.dev_prompt_timeout_sec)
            )
            return cli_result.text
        acp_result = await self._acp.run(
            AcpPromptRequest(
                socket_path=inp.copilot_socket_path,
                prompt=prompt,
                timeout_sec=inp.dev_prompt_timeout_sec,
            )
        )
        return acp_result.text

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        _log_stage(
            "Dev", "start", issue=inp.issue_number, fail_count=inp.fail_count
        )
        try:
            text = await self._call_prompt(inp)
        except (AcpDaemonError, asyncio.TimeoutError, RuntimeError) as exc:
            # #35: daemon 이 ERROR 응답 or 타임아웃. Dev 실패로 즉시 FAIL 확정.
            reason = str(exc) if isinstance(exc, AcpDaemonError) else str(exc) or "timeout"
            body = (
                "## QA 검증 결과: FAIL (자동 판정 — Dev daemon 실패)\n\n"
                f"Dev daemon 호출이 정상 종료되지 못했습니다: `{reason}`\n\n"
                "파이프라인은 QA 호출을 skip 하고 FAIL 로 분기합니다. "
                "재실행 시 `PRE_FAIL_COUNT > 0` 감지로 Dev 에게 재작업 지시가 삽입됩니다.\n"
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            _log_stage("Dev", "done", result="daemon_error", reason=reason)
            return inp.model_copy(update={"dev_response": f"ERROR: {reason}", "verdict": "FAIL"})
        _log_stage("Dev", "done", result="ok", response_len=len(text))
        return inp.model_copy(update={"dev_response": text})


# 알려진 부수 효과 파일 목록 — Dev 실행 후 자동으로 변경될 수 있는 파일.
# 이 파일들만 dirty 한 경우 자동 스테이징하여 dirty_fail 을 방지한다.
_KNOWN_SIDE_EFFECT_FILES: frozenset[str] = frozenset(["uv.lock"])


async def _auto_stage_side_effect_files(
    porcelain: str,
    git_runner: GitRunner,
    git_must: Callable[[list[str]], Awaitable[str]],
) -> str:
    """``git status --porcelain`` 출력을 분석해 알려진 부수 효과 파일만 자동 스테이징한다.

    자동 스테이징 후 남은 dirty 파일이 있으면 그 목록을 반환한다.
    모두 처리됐으면 빈 문자열을 반환한다.
    """
    import logging

    logger = logging.getLogger("pylego.pipeline.dirty_guard")

    dirty_files: list[str] = []
    for line in porcelain.splitlines():
        if len(line) < 3:
            continue
        # porcelain v1: "XY path" 또는 "XY old -> new"
        path = line[3:].strip().split(" -> ")[-1].strip()
        dirty_files.append(path)

    stageable = [f for f in dirty_files if f in _KNOWN_SIDE_EFFECT_FILES]
    remaining = [f for f in dirty_files if f not in _KNOWN_SIDE_EFFECT_FILES]

    if stageable:
        logger.warning(
            "dirty_guard: 알려진 부수 효과 파일 자동 스테이징 — %s",
            stageable,
        )
        try:
            await git_must(["add", "--"] + stageable)
        except RuntimeError as exc:
            logger.warning("dirty_guard: git add 실패 — %s", exc)
            # 스테이징 실패 시 해당 파일도 remaining 으로 다시 넣는다
            remaining = dirty_files

    if not remaining:
        return ""

    # 스테이징 후 실제 porcelain 재확인
    exit_code, stdout, _ = await git_runner(["status", "--porcelain"])
    if exit_code != 0:
        return "\n".join(remaining)
    return stdout.strip()


class _DevCommitCheckBlock(Block[_PipelineContext, _PipelineContext]):
    """#37 R2: Dev 호출 직후 새 커밋 존재성·워킹트리 청결성 검증.

    `pipeline.sh` §4a(#16, dirty tree) + §4b(#22, no commits) 와 동등한 가드를
    파이썬 파이프라인에 이식. Dev daemon 이 이미 FAIL 로 verdict 를 확정했다면
    early-return.
    """

    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(
        self,
        git_runner: GitRunner | None = None,
        gh_runner: GhRunner | None = None,
    ) -> None:
        self._git = git_runner if git_runner is not None else _default_git_runner
        self._comment = IssueCommentBlock(gh_runner=gh_runner)

    async def _git_must(self, args: list[str]) -> str:
        exit_code, stdout, stderr = await self._git(args)
        if exit_code != 0:
            raise RuntimeError(
                f"git {' '.join(args)} 실패 (exit={exit_code}): "
                f"{stderr.strip() or stdout.strip()}"
            )
        return stdout

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        # Dev daemon 이 이미 FAIL 로 확정했으면 커밋 체크 불필요.
        if inp.verdict != "UNKNOWN":
            _log_stage("DevCommitCheck", "skip", verdict=inp.verdict)
            return inp

        _log_stage("DevCommitCheck", "start", feature_branch=inp.feature_branch)
        # (1) 워킹트리 dirty 검사 — 커밋 누락 사유 우선.
        porcelain = (await self._git_must(["status", "--porcelain"])).strip()
        if porcelain:
            # 알려진 부수 효과 파일(uv.lock 등)을 자동 스테이징한 뒤 재확인.
            porcelain = await _auto_stage_side_effect_files(
                porcelain, self._git, self._git_must
            )
        if porcelain:
            body = (
                "## QA 검증 결과: FAIL (자동 판정 — 커밋 누락)\n\n"
                f"Developer 가 `{inp.feature_branch}` 에 커밋을 남기지 않고 종료하여 "
                "pipeline 이 QA 호출을 skip 하고 즉시 FAIL 처리합니다.\n\n"
                "변경된 파일 (커밋되지 않음):\n```\n"
                f"{porcelain[:2000]}\n"
                "```\n\n"
                "다음 재실행 시 `PRE_FAIL_COUNT > 0` 감지로 Dev 에게 재작업 지시가 삽입됩니다. "
                "Developer 는 수정 후 반드시 `git add · commit · push` 를 수행하세요."
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            _log_stage("DevCommitCheck", "done", result="dirty_fail")
            return inp.model_copy(update={"verdict": "FAIL"})

        # (2) 새 커밋 존재성 — atomic 이라 ACP race 무관.
        rev_out = await self._git_must(
            ["rev-list", "--count", f"{inp.base_branch}..HEAD"]
        )
        try:
            new_commits = int(rev_out.strip() or "0")
        except ValueError:
            new_commits = 0
        if new_commits == 0:
            body = (
                "## QA 검증 결과: FAIL (자동 판정 — 새 커밋 없음)\n\n"
                f"Developer 호출이 정상 종료됐지만 `{inp.feature_branch}` 가 "
                f"`{inp.base_branch}` 대비 새 커밋을 가지고 있지 않아 pipeline 이 "
                "QA 호출을 skip 하고 즉시 FAIL 처리합니다.\n\n"
                "원인 후보:\n"
                "- Copilot ACP race condition: async file write 가 아직 landing 되지 않음\n"
                "- Developer 가 실제 작업 없이 종료 (no-op)\n\n"
                "대응: 재실행 시 `PRE_FAIL_COUNT > 0` 감지로 Dev 에게 재작업 지시가 삽입됩니다."
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            _log_stage("DevCommitCheck", "done", result="no_commits_fail")
            return inp.model_copy(update={"verdict": "FAIL"})

        _log_stage("DevCommitCheck", "done", result="ok", new_commits=new_commits)
        return inp


class _QaLabelBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._transition = LabelTransitionBlock(gh_runner=gh_runner)

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        # #37: Dev 실패가 이미 확정됐으면 status:review 전이 skip (in-progress 유지).
        if inp.verdict != "UNKNOWN":
            return inp
        await self._transition.run(
            LabelTransitionRequest(
                repo=inp.repo,
                number=inp.issue_number,
                from_label="status:in-progress",
                to_label="status:review",
            )
        )
        return inp


class _QaPromptBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(self, socket_sender: SocketSender | None = None) -> None:
        self._acp = AcpPromptBlock(sender=socket_sender)
        self._claude = ClaudeCliBlock()

    async def _call_prompt(self, inp: _PipelineContext) -> str:
        prompt = _build_qa_prompt(inp)
        if inp.prompt_backend == "claude_cli":
            cli_result = await self._claude.run(
                PromptRequest(prompt=prompt, timeout_sec=inp.qa_prompt_timeout_sec)
            )
            return cli_result.text
        acp_result = await self._acp.run(
            AcpPromptRequest(
                socket_path=inp.gemini_socket_path,
                prompt=prompt,
                timeout_sec=inp.qa_prompt_timeout_sec,
            )
        )
        return acp_result.text

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        # #35: Dev 단계에서 이미 verdict 가 확정됐으면 QA 호출 skip.
        if inp.verdict != "UNKNOWN":
            _log_stage("Qa", "skip", verdict=inp.verdict)
            return inp
        _log_stage("Qa", "start", issue=inp.issue_number)
        try:
            text = await self._call_prompt(inp)
        except (AcpDaemonError, asyncio.TimeoutError, RuntimeError) as exc:
            # #35: QA 실패. verdict 는 UNKNOWN 유지 → _AutoVerdictFallbackBlock 이 pytest 로 판정.
            reason = str(exc) if isinstance(exc, AcpDaemonError) else str(exc) or "timeout"
            _log_stage("Qa", "done", result="daemon_error", reason=reason)
            return inp.model_copy(update={"qa_response": f"ERROR: {reason}"})
        _log_stage("Qa", "done", result="ok", response_len=len(text))
        return inp.model_copy(update={"qa_response": text})


class _VerdictAttachBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(self) -> None:
        self._parse = VerdictParseBlock()

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        # #35: 이미 verdict 가 확정됐으면 QA 응답 파싱 skip.
        if inp.verdict != "UNKNOWN":
            return inp
        verdict = await self._parse.run(VerdictParseRequest(text=inp.qa_response))
        return inp.model_copy(update={"verdict": verdict.result})


class _AutoVerdictFallbackBlock(Block[_PipelineContext, _PipelineContext]):
    input_model = _PipelineContext
    output_model = _PipelineContext

    def __init__(
        self,
        gh_runner: GhRunner | None = None,
        auto_verdict_runner: AutoVerdictRunner | None = None,
    ) -> None:
        self._comment = IssueCommentBlock(gh_runner=gh_runner)
        self._runner = (
            auto_verdict_runner if auto_verdict_runner is not None else _default_auto_verdict_runner
        )

    async def run(self, inp: _PipelineContext) -> _PipelineContext:
        if inp.verdict != "UNKNOWN":
            return inp

        _log_stage("AutoVerdict", "start")
        command = _build_auto_verdict_command()
        exit_code, stdout, stderr = await self._runner(command)
        verdict: Literal["PASS", "FAIL"] = "PASS" if exit_code == 0 else "FAIL"
        body = (
            f"## QA 검증 결과: {verdict} (자동 판정)\n\n"
            f"auto-verdict command: `{shlex.join(command)}`\n"
            f"exit code: {exit_code}\n"
        )
        if stdout.strip():
            body += f"\nstdout:\n```\n{stdout.strip()}\n```\n"
        if stderr.strip():
            body += f"\nstderr:\n```\n{stderr.strip()}\n```\n"
        await self._comment.run(
            IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
        )
        _log_stage("AutoVerdict", "done", verdict=verdict, exit_code=exit_code)
        return inp.model_copy(update={"verdict": verdict})


class _PassFinalizeBlock(Block[_PipelineContext, PipelineResult]):
    input_model = _PipelineContext
    output_model = PipelineResult

    def __init__(
        self,
        git_runner: GitRunner | None = None,
        gh_runner: GhRunner | None = None,
    ) -> None:
        self._git = git_runner if git_runner is not None else _default_git_runner
        self._gh = gh_runner if gh_runner is not None else _default_gh_runner
        self._merge = MergeToMainBlock(git_runner=git_runner)
        self._close = IssueCloseBlock(gh_runner=gh_runner)
        self._comment = IssueCommentBlock(gh_runner=gh_runner)

    async def run(self, inp: _PipelineContext) -> PipelineResult:
        _log_stage(
            "PassFinalize", "start", issue=inp.issue_number, fail_count=inp.fail_count
        )

        # #53 Hotfix: merge 직전 dirty working tree 가드. Copilot ACP 의 async 파일
        # 쓰기가 응답 후에도 landing 되어 working tree 에 uncommitted 변경이 남는
        # race 케이스. `MergeToMainBlock` 이 예외를 던지면 파이프라인이 terminal
        # state 없이 중단되어 이슈가 status:review 로 stuck 됨. _DevCommitCheckBlock
        # 이 Dev 직후에도 같은 검사를 수행하지만 QA 소요 시간 동안 Dev 데몬의 잔여
        # 작업이 landing 될 수 있어 merge 시점에 한 번 더 확인한다.
        dirty_code, dirty_stdout, dirty_stderr = await self._git(
            ["status", "--porcelain"]
        )
        if dirty_code != 0:
            raise RuntimeError(
                f"git status --porcelain 실패 (exit={dirty_code}): "
                f"{dirty_stderr.strip() or dirty_stdout.strip()}"
            )
        if dirty_stdout.strip():
            body = (
                "## QA 검증 결과: FAIL (자동 판정 — merge 직전 dirty working tree)\n\n"
                f"QA 는 PASS 판정했지만 merge 직전 `{inp.feature_branch}` 워킹트리에 "
                "커밋되지 않은 변경이 남아있어 pipeline 이 머지를 skip 하고 FAIL 로 "
                "전환합니다 (#53 Hotfix).\n\n"
                "변경된 파일 (커밋되지 않음):\n```\n"
                f"{dirty_stdout.strip()[:2000]}\n"
                "```\n\n"
                "원인 후보:\n"
                "- Copilot ACP race: Dev 의 async 파일 쓰기가 ACP 응답 후에 landing\n"
                "- Dev 가 QA 검토 중 추가 수정 후 커밋 누락\n\n"
                "재실행 시 Dev 에게 재작업 지시가 삽입됩니다. 수정 후 반드시 "
                "`git add · commit · push` 를 수행하세요."
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            _log_stage("PassFinalize", "done", result="dirty_guard_fail")
            return PipelineResult(
                issue_number=inp.issue_number,
                final_state="failed",
                fail_count=inp.fail_count + 1,
                verdict="FAIL",
            )

        # #37 R3: merge 직전 empty-diff 가드. feature 가 base 대비 새 커밋이 없으면
        # `git merge` 가 "Already up to date" 로 무결 병합 → false PASS 빈 머지.
        # pipeline.sh §7a 와 동등한 guard 를 파이썬 파이프라인에 이식.
        exit_code, stdout, stderr = await self._git(
            ["log", "--oneline", f"{inp.base_branch}..{inp.feature_branch}"]
        )
        if exit_code != 0:
            raise RuntimeError(
                f"git log {inp.base_branch}..{inp.feature_branch} 실패 "
                f"(exit={exit_code}): {stderr.strip() or stdout.strip()}"
            )
        if not stdout.strip():
            body = (
                "## QA 검증 결과: FAIL (자동 판정 — 빈 diff, 머지 skip)\n\n"
                f"QA 는 PASS 판정했지만 `{inp.feature_branch}` 가 "
                f"`{inp.base_branch}` 대비 새 커밋을 가지고 있지 않아 pipeline 이 "
                "머지를 skip 하고 FAIL 로 전환합니다 (#37 R3).\n\n"
                "원인 후보:\n"
                "- QA hallucination: 세션 컨텍스트만으로 PASS 판정, 실제 브랜치 미확인\n"
                "- Copilot ACP race: Dev 작업이 ACP 응답 후에 landing 되어 feature 에 반영 누락\n\n"
                "재실행 시 `PRE_FAIL_COUNT > 0` 감지로 Dev 에게 재작업 지시가 삽입됩니다."
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            _log_stage("PassFinalize", "done", result="empty_diff_fail")
            # verdict=FAIL 로 플립된 PipelineResult 반환. merge·close 실행 안 함.
            return PipelineResult(
                issue_number=inp.issue_number,
                final_state="failed",
                fail_count=inp.fail_count + 1,
                verdict="FAIL",
            )

        await self._merge.run(
            MergeRequest(
                base_branch=inp.base_branch,
                feature_branch=inp.feature_branch,
                message=f"Merge issue #{inp.issue_number}",
            )
        )
        # #39: close 전 status:review 라벨 제거 — 페르소나 라벨 체계에 status:done
        # 이 없어(architect.md §5), close 된 이슈가 status:review 를 유지하는 것은
        # 라벨 단일성 의도와 어긋남. pipeline.sh §7 와 동등한 정리를 파이썬
        # 파이프라인에도 이식. best-effort (라벨 부재여도 진행).
        await self._gh([
            "issue", "edit", str(inp.issue_number),
            "--repo", inp.repo,
            "--remove-label", "status:review",
        ])
        await self._close.run(
            IssueCloseRequest(
                repo=inp.repo,
                number=inp.issue_number,
            )
        )
        _log_stage("PassFinalize", "done", result="merged")
        return PipelineResult(
            issue_number=inp.issue_number,
            final_state="merged",
            fail_count=inp.fail_count,
            verdict=inp.verdict,
        )


class _FailFinalizeBlock(Block[_PipelineContext, PipelineResult]):
    input_model = _PipelineContext
    output_model = PipelineResult

    def __init__(self, gh_runner: GhRunner | None = None) -> None:
        self._comment = IssueCommentBlock(gh_runner=gh_runner)
        self._transition = LabelTransitionBlock(gh_runner=gh_runner)

    async def run(self, inp: _PipelineContext) -> PipelineResult:
        _log_stage(
            "FailFinalize", "start", issue=inp.issue_number, fail_count=inp.fail_count
        )
        fail_count = inp.fail_count + 1
        is_hotfix = "type:hotfix" in inp.labels
        if is_hotfix:
            body = (
                "## 🚨 Architect 리뷰 요청 — 자동 에스컬레이션\n\n"
                f"**이슈**: #{inp.issue_number} — {inp.issue_title}\n"
                "**사유**: Hotfix FAIL — 전략 결정 필요 (재작업/롤백/분리)\n"
                f"**누적 FAIL**: {fail_count}회\n\n"
                "### 다음 단계\n\n"
                "**Hotfix FAIL 전략 결정 필요** (qa.md §8a, architect.md §9).\n"
                "아래 셋 중 하나를 정확한 헤더 형식으로 이 이슈에 댓글 작성:\n"
                "- `[Hotfix 전략: 재작업]` — 수정 방향 지시, 라벨 전이 없음\n"
                "- `[Hotfix 전략: 롤백]` — 신규 롤백 이슈 생성 + 기존 Hotfix close\n"
                "- `[Hotfix 전략: 분리]` — 신규 이슈 생성 "
                "(type 라벨은 사건 성격에 따라) + 기존 Hotfix close\n\n"
                "Developer 데몬은 댓글 헤더를 트리거로 재작업한다.\n\n"
                "---\n"
                "*본 댓글은 pipeline.sh 가 자동 생성. Architect 는 사용자와 대화 "
                "중인 상위 AI (Claude 등) 이며, 사용자가 이 이슈를 Architect 에게 "
                "제시하면 판단·조치를 수행합니다.*"
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            final_state: Literal["failed", "escalated"] = "escalated"
        elif fail_count >= 3:
            await self._transition.run(
                LabelTransitionRequest(
                    repo=inp.repo,
                    number=inp.issue_number,
                    from_label="status:review",
                    to_label="status:blocked",
                )
            )
            body = (
                "## 🚨 Architect 리뷰 요청 — 자동 에스컬레이션\n\n"
                f"**이슈**: #{inp.issue_number} — {inp.issue_title}\n"
                "**사유**: 3차 누적 FAIL — 재설계 또는 신규 이슈 분리 검토 필요\n"
                f"**누적 FAIL**: {fail_count}회\n\n"
                "### 다음 단계\n\n"
                "**3차 누적 FAIL 에스컬레이션** (architect.md §6).\n"
                "24시간 내 원인 분석(설계 결함 / 기술적 한계 / 범위 과다) 후:\n"
                "1. 이슈 본문 업데이트 없이 신규 이슈로 **재작성 또는 분할**\n"
                "2. 원본 이슈에 `status:needs-redesign` 라벨 부여 후 댓글로 신규 이슈 번호 링크\n"
                "3. 원본 이슈 close (상태는 needs-redesign 유지)\n\n"
                "---\n"
                "*본 댓글은 pipeline.sh 가 자동 생성. Architect 는 사용자와 대화 "
                "중인 상위 AI (Claude 등) 이며, 사용자가 이 이슈를 Architect 에게 "
                "제시하면 판단·조치를 수행합니다.*"
            )
            await self._comment.run(
                IssueCommentRequest(repo=inp.repo, number=inp.issue_number, body=body)
            )
            final_state = "escalated"
        else:
            await self._transition.run(
                LabelTransitionRequest(
                    repo=inp.repo,
                    number=inp.issue_number,
                    from_label="status:review",
                    to_label="status:in-progress",
                )
            )
            final_state = "failed"
        _log_stage(
            "FailFinalize", "done", final_state=final_state, fail_count=fail_count
        )
        return PipelineResult(
            issue_number=inp.issue_number,
            final_state=final_state,
            fail_count=fail_count,
            verdict=inp.verdict,
        )


def build_ai_pi_pipeline(
    config: AiPiPipelineConfig,
    *,
    gh_runner: GhRunner | None = None,
    git_runner: GitRunner | None = None,
    socket_sender: SocketSender | None = None,
    auto_verdict_runner: AutoVerdictRunner | None = None,
) -> Block[AiPiPipelineConfig, PipelineResult]:
    """ai-pi 파이프라인 Assembly 를 구성한다."""

    pipeline: Block[AiPiPipelineConfig, PipelineResult] = Assembly(
        [
            _ConfigToContextBlock(gh_runner=gh_runner),
            _StatusTransitionBlock(
                from_label="status:ready",
                to_label="status:in-progress",
                gh_runner=gh_runner,
            ),
            _BranchPrepareSnapshotBlock(git_runner=git_runner),
            _DevPromptBlock(socket_sender=socket_sender, gh_runner=gh_runner),
            _DevCommitCheckBlock(git_runner=git_runner, gh_runner=gh_runner),
            _QaLabelBlock(gh_runner=gh_runner),
            _QaPromptBlock(socket_sender=socket_sender),
            _VerdictAttachBlock(),
            _AutoVerdictFallbackBlock(
                gh_runner=gh_runner,
                auto_verdict_runner=auto_verdict_runner,
            ),
            Branch(
                lambda snap: snap.verdict == "PASS",
                _PassFinalizeBlock(git_runner=git_runner, gh_runner=gh_runner),
                _FailFinalizeBlock(gh_runner=gh_runner),
            ),
        ]
    )
    return pipeline


async def run_ai_pi(
    config: AiPiPipelineConfig,
    *,
    gh_runner: GhRunner | None = None,
    git_runner: GitRunner | None = None,
    socket_sender: SocketSender | None = None,
    auto_verdict_runner: AutoVerdictRunner | None = None,
) -> PipelineResult:
    """ai-pi 파이프라인을 실행한다."""

    pipeline = build_ai_pi_pipeline(
        config,
        gh_runner=gh_runner,
        git_runner=git_runner,
        socket_sender=socket_sender,
        auto_verdict_runner=auto_verdict_runner,
    )
    return await pipeline.run(config)
