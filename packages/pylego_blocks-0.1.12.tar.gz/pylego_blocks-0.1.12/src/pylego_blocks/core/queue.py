"""Queue + WorkerPool + DeadLetterQueue — asyncio 기반 이벤트 큐와 병렬 워커.

Queue[T] 와 WorkerPool[T, R] 은 Block 이 아니라 조립체(Assembly) 와
병렬로 동작하는 이벤트 드리븐 파이프라인 컴포넌트다.

DeadLetterQueue[T] 는 최종 실패 항목을 격리 저장하고 재처리를 지원한다.

    # 생산자가 이슈를 큐에 넣고
    dev_q: Queue[IssueEvent] = Queue()
    qa_q: Queue[DevResult] = Queue()

    # WorkerPool 이 동시 2개씩 소비하며 결과를 다음 큐로 연결
    dev_pool = WorkerPool(DevBlock(), concurrency=2)
    qa_pool  = WorkerPool(QaBlock(),  concurrency=2)

    async with asyncio.TaskGroup() as tg:
        tg.create_task(dev_pool.run(dev_q, output=qa_q))
        tg.create_task(qa_pool.run(qa_q))
        for issue in issues:
            await dev_q.put(issue)
        await dev_q.close()
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class _Closed:
    """큐 종료 신호 (sentinel)."""


class Queue[T: Stud]:
    """asyncio.Queue 기반 타입 안전 작업 큐.

    생산자: ``await q.put(item)`` → 소비자: ``async for item in q``
    소비는 ``await q.close()`` 호출 시 자동 종료된다.

    Example:
        ```python
        q: Queue[MyStud] = Queue()
        await q.put(MyStud(value=1))
        await q.put(MyStud(value=2))
        await q.close()

        async for item in q:
            print(item.value)  # 1, 2
        ```

    분산 큐가 필요하면 ``RedisQueue`` 로 교체한다 (동일 async 인터페이스):
        ```python
        from pylego_blocks import make_queue
        import os
        os.environ["PYLEGO_QUEUE_BACKEND"] = "redis"
        q = make_queue(MyStud)   # → RedisQueue
        ```
    """

    def __init__(self, maxsize: int = 0) -> None:
        self._q: asyncio.Queue[T | _Closed] = asyncio.Queue(maxsize=maxsize)
        self._closed = False

    async def put(self, item: T) -> None:
        if self._closed:
            raise RuntimeError("닫힌 큐에는 넣을 수 없습니다.")
        await self._q.put(item)

    def put_nowait(self, item: T) -> None:
        if self._closed:
            raise RuntimeError("닫힌 큐에는 넣을 수 없습니다.")
        self._q.put_nowait(item)

    async def close(self) -> None:
        if not self._closed:
            self._closed = True
            await self._q.put(_Closed())

    def close_nowait(self) -> None:
        if not self._closed:
            self._closed = True
            self._q.put_nowait(_Closed())

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def size(self) -> int:
        return self._q.qsize()

    def __aiter__(self) -> AsyncGenerator[T, None]:
        return self._consume()

    async def _consume(self) -> AsyncGenerator[T, None]:
        while True:
            raw = await self._q.get()
            if isinstance(raw, _Closed):
                self._q.task_done()
                return
            yield raw
            self._q.task_done()


class WorkerPool[T: Stud, R: Stud]:
    """N 개의 동시 워커로 Queue 를 소비하는 실행기.

    `run()` 은 source 큐가 닫힐 때까지 항목을 소비하고
    완료된 결과 목록을 반환한다.

    `output` 큐를 지정하면 결과를 해당 큐에 put 하고 자동으로 close 한다.
    이를 통해 Queue → WorkerPool → Queue 파이프라인을 구성할 수 있다.
    """

    def __init__(
        self,
        worker: Block[T, R],
        *,
        concurrency: int = 1,
    ) -> None:
        if concurrency < 1:
            raise ValueError("concurrency 는 1 이상이어야 합니다.")
        self._worker = worker
        self._concurrency = concurrency

    async def run(
        self,
        source: Queue[T],
        *,
        output: Queue[R] | None = None,
    ) -> list[R]:
        """source 큐를 소비하며 처리하고 결과 목록을 반환한다."""
        results: list[R] = []
        sem = asyncio.Semaphore(self._concurrency)

        async def _process(item: T) -> None:
            async with sem:
                result = await self._worker.run(item)
                results.append(result)
                if output is not None:
                    await output.put(result)

        tasks: list[asyncio.Task[None]] = []
        async for item in source:
            task: asyncio.Task[None] = asyncio.create_task(_process(item))
            tasks.append(task)

        if tasks:
            await asyncio.gather(*tasks)

        if output is not None:
            await output.close()

        return results


class DeadLetterQueue[T: Stud]:
    """최종 실패 항목을 격리 저장하고 재처리를 지원하는 큐.

    실패 항목은 (item, reason) 쌍으로 저장된다.

        dlq: DeadLetterQueue[MyStud] = DeadLetterQueue()
        await dlq.put_failed(item, reason="처리 불가 입력")

        async for item, reason in dlq.failed_items():
            print(f"실패 항목: {item!r}, 원인: {reason}")

        # 재처리 큐로 이동
        retry_q: Queue[MyStud] = Queue()
        await dlq.retry(item, retry_q)
    """

    def __init__(self) -> None:
        self._items: list[tuple[T, str]] = []

    async def put_failed(self, item: T, reason: str) -> None:
        """실패 항목과 실패 원인을 DLQ 에 저장한다."""
        self._items.append((item, reason))

    def failed_items(self) -> AsyncGenerator[tuple[T, str], None]:
        """저장된 실패 항목을 (item, reason) 쌍으로 yield 한다."""
        return self._iter_failed()

    async def _iter_failed(self) -> AsyncGenerator[tuple[T, str], None]:
        for item, reason in list(self._items):
            yield item, reason

    async def retry(self, item: T, target: Queue[T]) -> None:
        """지정 항목을 DLQ 에서 제거하고 target 큐로 이동시킨다."""
        for i, (stored, _) in enumerate(self._items):
            if stored is item:
                self._items.pop(i)
                await target.put(item)
                return
        raise KeyError(f"항목 {item!r} 이 DLQ 에 없습니다.")

    def failed_count(self) -> int:
        """현재 DLQ 에 저장된 실패 항목 수를 반환한다."""
        return len(self._items)
