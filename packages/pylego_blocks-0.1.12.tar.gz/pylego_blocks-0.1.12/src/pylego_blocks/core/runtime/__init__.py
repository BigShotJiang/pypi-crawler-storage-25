"""Runtime — 블록 실행 환경 추상화.

동일 Assembly 를 sync / async / (M5 에서) 분산 런타임으로 실행할 수 있게 한다.
블록은 런타임을 모른다 — 런타임만 블록 실행 방식을 결정한다.
"""

from __future__ import annotations

from pylego_blocks.core.runtime.asyncio_runtime import AsyncRuntime
from pylego_blocks.core.runtime.process import ProcessRuntime
from pylego_blocks.core.runtime.sync import SyncRuntime

__all__ = ["AsyncRuntime", "ProcessRuntime", "SyncRuntime"]
