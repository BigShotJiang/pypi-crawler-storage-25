"""ProcessRuntime — ProcessPoolExecutor 기반 실제 병렬 실행.

FanOut 브랜치를 별도 프로세스에서 동시에 실행한다.
블록은 pickle 가능해야 하며, Stud I/O 는 pydantic JSON 으로 직렬화된다.

    fanout = FanOut([BlockA(), BlockB()], runtime=ProcessRuntime(workers=2))
    result = await fanout.run(inp)      # A, B 가 실제 별도 프로세스에서 실행
"""

from __future__ import annotations

import asyncio
import os
import pickle
from collections.abc import Sequence
from concurrent.futures import ProcessPoolExecutor
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


def _run_block_in_process(block_bytes: bytes, inp_json: str) -> str:
    """subprocess 워커 함수. 블록 하나를 실행하고 JSON 결과를 반환한다.

    최상위 함수여야 ProcessPoolExecutor 에서 pickle 가능하다.
    """
    block: Block[Any, Any] = pickle.loads(block_bytes)
    inp = block.input_model.model_validate_json(inp_json)
    result = asyncio.run(block.run(inp))
    return str(result.model_dump_json())


class ProcessRuntime:
    """FanOut 브랜치를 ProcessPoolExecutor 로 병렬 실행하는 런타임.

    제약:
    - 블록 인스턴스(및 의존성)가 pickle 가능해야 한다.
    - Stud I/O 는 pydantic JSON 직렬화를 지원해야 한다.
    - pickle 불가 블록은 FanOut 조립 시점에 즉시 에러가 발생한다.
    """

    def __init__(self, workers: int | None = None) -> None:
        self._workers = workers if workers is not None else (os.cpu_count() or 1)

    def validate(self, branches: Sequence[Block[Any, Any]]) -> None:
        """블록 직렬화 가능 여부를 조립 시점에 검증한다."""
        for b in branches:
            try:
                pickle.dumps(b)
            except Exception as exc:
                raise TypeError(
                    f"ProcessRuntime: 블록 '{b.name}'은 pickle 불가입니다. "
                    "블록의 모든 속성이 pickle 가능해야 합니다. "
                    f"원인: {exc}"
                ) from exc

    async def run_parallel(
        self,
        branches: Sequence[Block[Any, Any]],
        inp: Stud,
    ) -> list[Stud]:
        """branches 를 별도 프로세스에서 병렬 실행하고 결과 목록을 반환한다."""
        inp_json = inp.model_dump_json()
        loop = asyncio.get_event_loop()

        with ProcessPoolExecutor(max_workers=self._workers) as executor:
            futs = [
                loop.run_in_executor(
                    executor,
                    _run_block_in_process,
                    pickle.dumps(branch),
                    inp_json,
                )
                for branch in branches
            ]
            results_json: list[str] = list(await asyncio.gather(*futs))

        return [
            branch.output_model.model_validate_json(r_json)
            for branch, r_json in zip(branches, results_json)
        ]
