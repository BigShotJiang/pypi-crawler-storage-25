"""SyncRuntime — 동기 호출자에서 블록을 실행.

내부적으로 `asyncio.run` 으로 블록의 async `run` 을 구동한다.
루프가 이미 도는 컨텍스트(예: FastAPI 핸들러 안)에선 AsyncRuntime 을 사용해야 한다.
"""

from __future__ import annotations

import asyncio
from typing import TypeVar

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud

_I = TypeVar("_I", bound=Stud)
_O = TypeVar("_O", bound=Stud)


class SyncRuntime:
    """블록을 동기 컨텍스트에서 실행."""

    def execute(self, block: Block[_I, _O], inp: _I) -> _O:
        return asyncio.run(block.run(inp))
