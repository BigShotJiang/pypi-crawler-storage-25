"""AsyncRuntime — 이미 동작 중인 asyncio 루프에서 블록 실행."""

from __future__ import annotations

from typing import TypeVar

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud

_I = TypeVar("_I", bound=Stud)
_O = TypeVar("_O", bound=Stud)


class AsyncRuntime:
    """async 컨텍스트에서 블록을 실행."""

    async def execute(self, block: Block[_I, _O], inp: _I) -> _O:
        return await block.run(inp)
