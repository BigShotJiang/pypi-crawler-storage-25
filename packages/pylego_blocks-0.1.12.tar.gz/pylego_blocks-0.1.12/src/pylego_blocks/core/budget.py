"""ExecutionBudget — 파이프라인 경제적 킬스위치.

사용 예:
    from pylego_blocks import ExecutionBudget, observe

    with observe(ExecutionBudget(max_block_calls=10, max_total_seconds=30.0)):
        result = await pipeline.run(inp)
    # 초과 시 BudgetExceededError 발생
"""

from __future__ import annotations

import time

from pylego_blocks.core.events import BlockEvent, BlockStartedEvent


class BudgetExceededError(RuntimeError):
    """ExecutionBudget 한계 초과 시 발생."""


class ExecutionBudget:
    """블록 호출 횟수·경과 시간을 추적하고 한계 초과 시 파이프라인을 중단한다.

    EventBus 프로토콜을 구현하므로 ``observe()`` 컨텍스트에 직접 전달할 수 있다.
    ``max_block_calls`` 또는 ``max_total_seconds`` 중 하나 이상 필수.
    """

    def __init__(
        self,
        max_block_calls: int | None = None,
        max_total_seconds: float | None = None,
    ) -> None:
        if max_block_calls is None and max_total_seconds is None:
            raise ValueError("max_block_calls 또는 max_total_seconds 중 하나 이상 필수")
        if max_block_calls is not None and max_block_calls < 1:
            raise ValueError("max_block_calls 는 1 이상이어야 합니다")
        if max_total_seconds is not None and max_total_seconds <= 0:
            raise ValueError("max_total_seconds 는 0 보다 커야 합니다")

        self._max_block_calls = max_block_calls
        self._max_total_seconds = max_total_seconds
        self._call_count: int = 0
        self._start_time: float | None = None

    def emit(self, event: BlockEvent) -> None:
        if not isinstance(event, BlockStartedEvent):
            return

        now = time.monotonic()
        if self._start_time is None:
            self._start_time = now

        self._call_count += 1

        if self._max_block_calls is not None and self._call_count > self._max_block_calls:
            raise BudgetExceededError(
                f"block call limit exceeded: {self._call_count} > {self._max_block_calls}"
            )

        elapsed = now - self._start_time
        if self._max_total_seconds is not None and elapsed > self._max_total_seconds:
            raise BudgetExceededError(
                f"time budget exceeded: {elapsed:.3f}s > {self._max_total_seconds}s"
            )

    def reset(self) -> None:
        """연속 요청 처리를 위한 상태 초기화."""
        self._call_count = 0
        self._start_time = None

    @property
    def call_count(self) -> int:
        return self._call_count

    @property
    def elapsed_seconds(self) -> float:
        if self._start_time is None:
            return 0.0
        return time.monotonic() - self._start_time
