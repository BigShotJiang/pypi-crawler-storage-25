"""Redis 기반 분산 작업 큐 — Queue[T] async 인터페이스 호환.

optional 의존성:
    pip install pylego[redis]   # redis>=5.0

사용:
    from pylego_blocks.core.redis_queue import RedisQueue, RedisWorkerPool

    q = RedisQueue(MyStud, url="redis://localhost:6379", queue_name="dev-jobs")
    pool = RedisWorkerPool(MyBlock(), concurrency=2)

    async with asyncio.TaskGroup() as tg:
        tg.create_task(pool.run(q))
        for item in items:
            await q.put(item)
        await q.close()

환경변수:
    PYLEGO_QUEUE_BACKEND=redis   make_queue() 가 RedisQueue 를 반환
    PYLEGO_REDIS_URL             Redis 연결 URL (기본: redis://localhost:6379)
"""

from __future__ import annotations

import asyncio
import json
import os
from collections.abc import AsyncGenerator
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


_CLOSE_SENTINEL = b"__pylego_queue_closed__"


def _require_redis() -> None:
    try:
        import redis.asyncio  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "redis 가 설치되어 있지 않습니다. "
            "`pip install pylego[redis]` 로 설치하세요."
        ) from exc


class RedisQueue[T: Stud]:
    """Redis List 기반 타입 안전 분산 작업 큐.

    asyncio.Queue 기반 Queue[T] 와 동일한 async 인터페이스(put/close/__aiter__)를
    제공한다. 여러 프로세스·머신에서 동일 queue_name 을 공유해 분산 처리 가능.

    put_nowait / close_nowait / size 는 Redis 의 비동기 특성상 미지원.
    큐 크기가 필요하면 await q.asize() 를 사용한다.
    """

    def __init__(
        self,
        item_type: type[T],
        *,
        url: str = "redis://localhost:6379",
        queue_name: str = "pylego:queue",
        block_timeout: int = 0,
    ) -> None:
        _require_redis()
        self._item_type = item_type
        self._url = url
        self._queue_name = queue_name
        self._block_timeout = block_timeout
        self._closed = False
        self._client: Any = None

    async def _conn(self) -> Any:
        if self._client is None:
            import redis.asyncio as aioredis

            self._client = aioredis.from_url(self._url)
        return self._client

    async def put(self, item: T) -> None:
        if self._closed:
            raise RuntimeError("닫힌 큐에는 넣을 수 없습니다.")
        client = await self._conn()
        await client.rpush(self._queue_name, item.model_dump_json().encode())

    def put_nowait(self, item: T) -> None:
        raise NotImplementedError(
            "RedisQueue 는 동기 put_nowait() 를 지원하지 않습니다. "
            "비동기 put() 을 사용하세요."
        )

    async def close(self) -> None:
        if not self._closed:
            self._closed = True
            client = await self._conn()
            await client.rpush(self._queue_name, _CLOSE_SENTINEL)

    def close_nowait(self) -> None:
        raise NotImplementedError(
            "RedisQueue 는 동기 close_nowait() 를 지원하지 않습니다. "
            "비동기 close() 를 사용하세요."
        )

    @property
    def closed(self) -> bool:
        return self._closed

    async def asize(self) -> int:
        """현재 큐 크기를 반환한다 (비동기)."""
        client = await self._conn()
        return int(await client.llen(self._queue_name))

    def __aiter__(self) -> AsyncGenerator[T, None]:
        return self._consume()

    async def _consume(self) -> AsyncGenerator[T, None]:
        client = await self._conn()
        while True:
            result = await client.blpop(
                [self._queue_name], timeout=self._block_timeout
            )
            if result is None:
                # timeout 만료 — 재시도
                continue
            _, raw = result
            if raw == _CLOSE_SENTINEL:
                return
            yield self._item_type.model_validate_json(raw)

    async def aclose_client(self) -> None:
        """Redis 클라이언트 연결을 닫는다."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None


class RedisWorkerPool[T: Stud, R: Stud]:
    """RedisQueue 기반 분산 WorkerPool.

    WorkerPool 과 동일한 패턴으로 RedisQueue[T] 를 소비하고
    Block[T, R] 을 N 개 동시 실행한다.
    """

    def __init__(
        self,
        worker: Block[T, R],
        *,
        concurrency: int = 1,
    ) -> None:
        if concurrency < 1:
            raise ValueError("concurrency 는 1 이상이어야 합니다.")
        self._worker = worker
        self._concurrency = concurrency

    async def run(
        self,
        source: RedisQueue[T],
        *,
        output: RedisQueue[R] | None = None,
    ) -> list[R]:
        """source RedisQueue 를 소비하며 처리하고 결과 목록을 반환한다."""
        results: list[R] = []
        sem = asyncio.Semaphore(self._concurrency)

        async def _process(item: T) -> None:
            async with sem:
                result = await self._worker.run(item)
                results.append(result)
                if output is not None:
                    await output.put(result)

        tasks: list[asyncio.Task[None]] = []
        async for item in source:
            task: asyncio.Task[None] = asyncio.create_task(_process(item))
            tasks.append(task)

        if tasks:
            await asyncio.gather(*tasks)

        if output is not None:
            await output.close()

        return results


class RedisDeadLetterQueue[T: Stud]:
    """Redis List 기반 Dead Letter Queue.

    DeadLetterQueue[T] 와 동일한 async 인터페이스를 제공한다.
    실패 항목은 (item JSON, reason) 을 하나의 JSON 엔트리로 직렬화해 저장한다.
    """

    def __init__(
        self,
        item_type: type[T],
        *,
        url: str = "redis://localhost:6379",
        queue_name: str = "pylego:dlq",
    ) -> None:
        _require_redis()
        self._item_type = item_type
        self._url = url
        self._queue_name = queue_name
        self._client: Any = None

    async def _conn(self) -> Any:
        if self._client is None:
            import redis.asyncio as aioredis

            self._client = aioredis.from_url(self._url)
        return self._client

    async def put_failed(self, item: T, reason: str) -> None:
        """실패 항목과 원인을 DLQ 에 저장한다."""
        client = await self._conn()
        entry = json.dumps(
            {"item": item.model_dump(), "reason": reason}
        ).encode()
        await client.rpush(self._queue_name, entry)

    def failed_items(self) -> AsyncGenerator[tuple[T, str], None]:
        """저장된 실패 항목을 (item, reason) 쌍으로 yield 한다."""
        return self._iter_failed()

    async def _iter_failed(self) -> AsyncGenerator[tuple[T, str], None]:
        client = await self._conn()
        raw_items: list[bytes] = await client.lrange(self._queue_name, 0, -1)
        for raw in raw_items:
            data: dict[str, Any] = json.loads(raw)
            item = self._item_type.model_validate(data["item"])
            yield item, str(data["reason"])

    async def retry(self, item: T, target: RedisQueue[T]) -> None:
        """지정 항목을 DLQ 에서 제거하고 target 큐로 이동시킨다."""
        client = await self._conn()
        raw_items: list[bytes] = await client.lrange(self._queue_name, 0, -1)
        for raw in raw_items:
            data: dict[str, Any] = json.loads(raw)
            stored = self._item_type.model_validate(data["item"])
            if stored == item:
                await client.lrem(self._queue_name, 1, raw)
                await target.put(item)
                return
        raise KeyError(f"항목 {item!r} 이 DLQ 에 없습니다.")

    async def failed_count(self) -> int:
        """현재 DLQ 에 저장된 실패 항목 수를 반환한다."""
        client = await self._conn()
        return int(await client.llen(self._queue_name))

    async def aclose_client(self) -> None:
        """Redis 클라이언트 연결을 닫는다."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None


def make_queue[T: Stud](
    item_type: type[T],
    *,
    queue_name: str = "pylego:queue",
    maxsize: int = 0,
) -> "RedisQueue[T]":
    """PYLEGO_QUEUE_BACKEND 환경변수에 따라 적절한 큐를 생성한다.

    PYLEGO_QUEUE_BACKEND=redis  → RedisQueue (PYLEGO_REDIS_URL 연결)
    그 외                       → 기존 asyncio.Queue 기반 Queue (import 후 반환)

    반환 타입:
        backend=redis  → RedisQueue[T]
        backend=asyncio → Queue[T]  (런타임 실제 타입, 정적 타입은 RedisQueue[T] 로 표시)
    """
    from pylego_blocks.core.queue import Queue  # avoid circular at module level

    backend = os.getenv("PYLEGO_QUEUE_BACKEND", "asyncio")
    if backend == "redis":
        url = os.getenv("PYLEGO_REDIS_URL", "redis://localhost:6379")
        return RedisQueue(item_type, url=url, queue_name=queue_name)
    # asyncio backend — return Queue as Any to avoid Union type complexity
    return Queue(maxsize=maxsize)  # type: ignore[return-value]
