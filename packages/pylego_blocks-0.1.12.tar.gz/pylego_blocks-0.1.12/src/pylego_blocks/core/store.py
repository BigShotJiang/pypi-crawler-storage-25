"""Store — key-value 상태 저장소 및 StoreBlock."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class Store(ABC):
    """Key-value 상태 저장소 추상 인터페이스.

    값은 JSON-직렬화 가능한 형태(dict)로 저장된다.
    """

    @abstractmethod
    async def get(self, key: str) -> Any: ...

    @abstractmethod
    async def set(self, key: str, value: Any) -> None: ...

    @abstractmethod
    async def has(self, key: str) -> bool: ...

    @abstractmethod
    async def delete(self, key: str) -> None: ...

    @abstractmethod
    async def clear(self) -> None: ...


class InMemoryStore(Store):
    """딕셔너리 기반 인메모리 저장소."""

    def __init__(self) -> None:
        self._data: dict[str, Any] = {}

    async def get(self, key: str) -> Any:
        return self._data.get(key)

    async def set(self, key: str, value: Any) -> None:
        self._data[key] = value

    async def has(self, key: str) -> bool:
        return key in self._data

    async def delete(self, key: str) -> None:
        self._data.pop(key, None)

    async def clear(self) -> None:
        self._data.clear()


class FileStore(Store):
    """JSON 파일 기반 영속 저장소."""

    def __init__(self, path: Path | str) -> None:
        self._path = Path(path)

    def _load(self) -> dict[str, Any]:
        if not self._path.exists():
            return {}
        return json.loads(self._path.read_text(encoding="utf-8"))  # type: ignore[no-any-return]

    def _save(self, data: dict[str, Any]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

    async def get(self, key: str) -> Any:
        return self._load().get(key)

    async def set(self, key: str, value: Any) -> None:
        data = self._load()
        data[key] = value
        self._save(data)

    async def has(self, key: str) -> bool:
        return key in self._load()

    async def delete(self, key: str) -> None:
        data = self._load()
        data.pop(key, None)
        self._save(data)

    async def clear(self) -> None:
        if self._path.exists():
            self._path.unlink()


class StoreBlock[V: Stud](Block[V, V]):
    """파이프라인에서 값을 저장소에 보존하는 pass-through 블록.

    입력값을 지정한 키로 Store 에 저장한 뒤 동일 값을 반환한다.
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(self, store: Store, key: str, model: type[V]) -> None:
        self._store = store
        self._key = key
        self.input_model = model
        self.output_model = model

    async def run(self, inp: V) -> V:
        await self._store.set(self._key, json.loads(inp.model_dump_json()))
        return inp
