"""TapBlock — 메인 흐름을 방해하지 않는 비차단 관찰 블록."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class TapBlock[T: Stud](Block[T, T]):
    """input을 변경 없이 전달하면서 observer를 비동기 실행하는 비차단 감시 블록.

    observer 실패는 기본적으로 무시된다(``ignore_errors=True``).
    메인 파이프라인 흐름에 영향을 주지 않는 Signal 삽입·감사 로그·의심 지수 계산에 사용한다.

    Args:
        observer: 관찰 블록 또는 비동기 callable. 블록을 전달하면 input_model을 자동 추론.
        item_type: callable observer 사용 시 필수. 블록 observer일 때는 무시됨.
        ignore_errors: True(기본)이면 observer 예외를 삼킨다. False면 파이프라인을 중단.
        name: 블록 이름 재지정.

    Example:
        ```python
        class SignalBlock(Block[AiOut, SuspicionScore]):
            async def run(self, inp: AiOut) -> SuspicionScore:
                return SuspicionScore(value=compute(inp))

        pipeline = Assembly([
            AiBlock(),
            TapBlock(SignalBlock()),   # 흐름 방해 없이 의심 지수 계산
            VerdictBlock(),
        ])

        # callable 버전
        TapBlock(lambda inp: store.record(inp), item_type=AiOut)
        ```
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        observer: Block[T, Any] | Callable[[T], Awaitable[None]],
        *,
        item_type: type[T] | None = None,
        ignore_errors: bool = True,
        name: str | None = None,
    ) -> None:
        self._observer = observer
        self._ignore_errors = ignore_errors

        if isinstance(observer, Block):
            self.input_model = observer.input_model
            self.output_model = observer.input_model
            self.name = f"Tap({observer.name})"
        else:
            if item_type is None:
                raise ValueError(
                    "callable observer를 사용할 때는 item_type을 지정해야 합니다."
                )
            self.input_model = item_type
            self.output_model = item_type
            fn_name = getattr(observer, "__name__", "fn")
            self.name = f"Tap({fn_name})"

        if name is not None:
            self.name = name

    async def run(self, inp: T) -> T:
        try:
            if isinstance(self._observer, Block):
                await self._observer.run(inp)
            else:
                await self._observer(inp)
        except Exception:
            if not self._ignore_errors:
                raise
        return inp
