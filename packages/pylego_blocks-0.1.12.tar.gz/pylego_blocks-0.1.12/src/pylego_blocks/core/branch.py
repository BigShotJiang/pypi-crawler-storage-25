"""Branch — 2-way 조건부 분기 블록."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pylego_blocks.core.assembly import IncompatibleSnapError
from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class Branch[InputT: Stud, OutputT: Stud](Block[InputT, OutputT]):
    """predicate 결과에 따라 두 블록 중 하나를 실행한다."""

    input_model = Stud
    output_model = Stud

    def __init__(
        self,
        predicate: Callable[[InputT], bool],
        on_true: Block[InputT, OutputT],
        on_false: Block[InputT, OutputT],
        *,
        name: str | None = None,
    ) -> None:
        if on_true.input_model is not on_false.input_model:
            raise IncompatibleSnapError(
                f"{on_true.name}.input({on_true.input_model.__name__}) "
                f"!= {on_false.name}.input({on_false.input_model.__name__})"
            )
        if on_true.output_model is not on_false.output_model:
            raise IncompatibleSnapError(
                f"{on_true.name}.output({on_true.output_model.__name__}) "
                f"!= {on_false.name}.output({on_false.output_model.__name__})"
            )
        self._predicate = predicate
        self._on_true = on_true
        self._on_false = on_false
        self._blocks: tuple[Block[Any, Any], Block[Any, Any]] = (on_true, on_false)
        self.input_model = on_true.input_model
        self.output_model = on_true.output_model
        if name is not None:
            self.name = name

    async def run(self, inp: InputT) -> OutputT:
        block = self._on_true if self._predicate(inp) else self._on_false
        return await block.run(inp)
