"""Stud — 블록 I/O 계약의 베이스.

pydantic v2 `BaseModel` 을 기반으로 하며, 블록 경계에서의 데이터는 반드시 Stud 서브클래스
인스턴스여야 한다. `extra="forbid"` 로 예측 못한 필드 거부, `frozen=True` 로 불변 강제.
블록 간에 흐르는 데이터는 생성 이후 변경할 수 없다 — 상태는 전용 StoreBlock 에만 보관.
"""

from __future__ import annotations

from typing import ClassVar

from pydantic import BaseModel, ConfigDict


class Stud(BaseModel):
    """블록 간 I/O 계약 베이스 클래스.

    모든 블록의 입력·출력은 Stud 서브클래스 인스턴스여야 한다.

    불변식:
        - ``extra="forbid"``: 선언되지 않은 필드 → 즉시 ``ValidationError``.
        - ``frozen=True``: 생성 후 필드 변경 불가.

    Example:
        ```python
        class MyData(Stud):
            value: int
            label: str = "default"

        d = MyData(value=1)
        d.value = 2                          # ValidationError — frozen
        d2 = d.model_copy(update={"value": 2})  # OK — 새 인스턴스 반환
        json_str = d.model_dump_json()       # '{"value":1,"label":"default"}'
        d3 = MyData.model_validate_json(json_str)  # 역직렬화
        ```

    Note:
        상태 저장이 필요하면 StoreBlock 을 사용한다.
        Redis 큐·HTTP body·체크포인트 모두 model_dump_json() / model_validate_json() 으로 자동 직렬화.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)
    is_frozen: ClassVar[bool] = True

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: object) -> None:
        super().__pydantic_init_subclass__(**kwargs)
        cls.is_frozen = bool(cls.model_config.get("frozen", False))
