"""Assembly — 여러 블록을 선형으로 스냅한 조립체.

Assembly 자체가 Block 이므로 재귀적 합성이 가능하다 (Assembly 를 다른 Assembly 의
구성 요소로 사용). 계약 불일치는 **조립 시점**(`__init__`)에 실패하며, 런타임 에러로
미뤄지지 않는다.

M1 에서는 선형 파이프라인(A → B → C)만 지원한다. M2 에서 DAG 로 확장.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import AsyncGenerator, Callable, Sequence
from itertools import pairwise
from typing import Any, cast

from pylego_blocks.core.block import Block
from pylego_blocks.core.checkpoint import Checkpoint, _default_checkpoint
from pylego_blocks.core.compat import AssemblyValidator
from pylego_blocks.core.events import (
    BlockCompletedEvent,
    BlockFailedEvent,
    BlockStartedEvent,
    _resolve_bus,
)
from pylego_blocks.core.stud import Stud


class IncompatibleSnapError(TypeError):
    """블록 간 Stud 계약이 불일치할 때 발생."""


class CyclicAssemblyError(IncompatibleSnapError):
    """Assembly 구성 시 순환 참조가 탐지되면 발생."""


class Assembly[InputT: Stud, OutputT: Stud](Block[InputT, OutputT]):
    """블록 체인을 선형으로 조립한다.

    조립 시점 검증:
    - 비어있지 않아야 한다.
    - 각 블록의 output_model 이 다음 블록의 input_model 과 동일해야 한다.

    검증 후 `input_model` 은 첫 블록의 입력, `output_model` 은 마지막 블록의 출력으로 노출된다.
    """

    # 서브클래스에서 동적으로 설정 (가변 클래스 속성 회피용 sentinel)
    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        blocks: Sequence[Block[Any, Any]],
        *,
        name: str | None = None,
        validator: AssemblyValidator | None = None,
        max_payload_chars: int = 200,
        auto_validate: bool = False,
    ) -> None:
        if not blocks:
            raise ValueError("Assembly 는 최소 한 개의 블록이 필요합니다.")
        # Detect cycles in nested Assembly instances before accepting the chain.
        self._detect_cycles(blocks)
        self._validate_chain(blocks)
        self._blocks: list[Block[Any, Any]] = list(blocks)
        self._max_payload_chars: int = max_payload_chars

        # auto_validate: Stud @model_validator 자동 수집
        effective_validator = validator
        if auto_validate:
            auto_v = self._build_auto_validator(list(blocks))
            if auto_v is not None:
                effective_validator = (
                    validator.merge(auto_v) if validator is not None else auto_v
                )
        self._validator: AssemblyValidator | None = effective_validator
        # 인스턴스 속성으로 섀도잉해 조립체별 입출력 계약을 갖는다.
        self.input_model = blocks[0].input_model
        self.output_model = blocks[-1].output_model
        if name is not None:
            self.name = name

    @staticmethod
    def _validate_chain(blocks: Sequence[Block[Any, Any]]) -> None:
        for prev, nxt in pairwise(blocks):
            if prev.output_model is not nxt.input_model:
                raise IncompatibleSnapError(
                    f"{prev.name}.output({prev.output_model.__name__}) "
                    f"!= {nxt.name}.input({nxt.input_model.__name__})"
                )

    @staticmethod
    def _detect_cycles(blocks: Sequence[Block[Any, Any]]) -> None:
        """Detect cycles and duplicate block instances reachable from `blocks`.

        Raises CyclicAssemblyError when a duplicate instance or true cycle is found.
        """
        # 최상위 중복 인스턴스 감지
        seen_ids: set[int] = set()
        for b in blocks:
            if id(b) in seen_ids:
                raise CyclicAssemblyError(
                    f"블록 '{b.name}'(id={id(b)}) 이 Assembly 에 중복 포함됩니다."
                )
            seen_ids.add(id(b))

        # 중첩 Assembly 의 진짜 사이클 감지 (DFS)
        visiting: set[int] = set()
        visited: set[int] = set()

        def _visit(b: Block[Any, Any]) -> None:
            if not isinstance(b, Assembly):
                return
            bid = id(b)
            if bid in visiting:
                raise CyclicAssemblyError(
                    f"Assembly '{b.name}' 에서 순환 참조가 감지됩니다."
                )
            if bid in visited:
                return
            visiting.add(bid)
            for sub in b.blocks:
                _visit(sub)
            visiting.discard(bid)
            visited.add(bid)

        for blk in blocks:
            _visit(blk)

    @staticmethod
    def _build_auto_validator(blocks: Sequence[Block[Any, Any]]) -> AssemblyValidator | None:
        """각 블록의 input_model 에서 pydantic 검증기를 추출해 AssemblyValidator 를 생성한다."""

        def _make_fn(cls: type) -> Callable[[Any], None]:
            def fn(inp: Any) -> None:
                if hasattr(inp, "model_dump") and hasattr(cls, "model_validate"):
                    cls.model_validate(inp.model_dump())

            return fn

        validators: dict[int, Callable[[Any], None]] = {}
        for i, block in enumerate(blocks):
            input_cls = block.input_model
            if isinstance(input_cls, type) and hasattr(input_cls, "model_validate"):
                validators[i] = _make_fn(input_cls)

        return AssemblyValidator(validators) if validators else None

    @property
    def blocks(self) -> tuple[Block[Any, Any], ...]:
        """구성 블록 튜플 (불변 뷰)."""
        return tuple(self._blocks)

    def __repr__(self) -> str:
        parts: list[str] = []
        for block in self._blocks:
            parts.append(repr(block) if isinstance(block, Assembly) else block.name)
        return f"{self.name}[{' → '.join(parts)}]"

    def __repr_mermaid__(self) -> str:
        """Mermaid flowchart LR 텍스트를 반환한다."""
        from pylego_blocks.core.visualize import to_mermaid
        return to_mermaid(self)

    def __repr_dot__(self) -> str:
        """Graphviz DOT 텍스트를 반환한다."""
        from pylego_blocks.core.visualize import to_dot
        return to_dot(self)

    async def run(
        self,
        inp: InputT,
        *,
        checkpoint: Checkpoint | None = None,
        fault_map: dict[str, Exception] | None = None,
    ) -> OutputT:
        """조립체를 실행한다.

        Args:
            inp: 첫 블록에 전달할 입력값.
            checkpoint: 체크포인트 저장소. None 이면 기본 저장소를 사용.
            fault_map: 테스트용 강제 실패 주입 맵.
                ``{"BlockName": ValueError("forced")}`` 형식으로 지정하면
                해당 블록 실행 시 대신 그 예외가 발생한다.
        """
        if checkpoint is None:
            checkpoint = _default_checkpoint(self.name)
        bus = _resolve_bus()
        value: InputT | OutputT = inp
        for i, block in enumerate(self._blocks):
            if self._validator is not None:
                self._validator.validate(i, value)
            # 체크포인트에 완료 결과가 있으면 재실행 없이 복원
            if checkpoint is not None and await checkpoint.has(block.name):
                cached = await checkpoint.load(block.name, block.output_model)
                if cached is not None:
                    value = cast(InputT | OutputT, cached)
                    continue

            t0 = time.monotonic()
            if bus is not None:
                bus.emit(BlockStartedEvent(block_name=block.name, input=value))

            # fault injection: 지정 블록을 강제 실패시킨다 (테스트 전용)
            if fault_map is not None and block.name in fault_map:
                exc = fault_map[block.name]
                if bus is not None:
                    bus.emit(
                        BlockFailedEvent(
                            block_name=block.name,
                            error=exc,
                            elapsed_sec=time.monotonic() - t0,
                            input_sample=str(value)[:self._max_payload_chars],
                            error_type=type(exc).__name__,
                        )
                    )
                raise exc

            try:
                value = cast(InputT | OutputT, await block.run(cast(Any, value)))
            except Exception as exc:
                if bus is not None:
                    bus.emit(
                        BlockFailedEvent(
                            block_name=block.name,
                            error=exc,
                            elapsed_sec=time.monotonic() - t0,
                            input_sample=str(value)[:self._max_payload_chars],
                            error_type=type(exc).__name__,
                        )
                    )
                raise
            if bus is not None:
                bus.emit(
                    BlockCompletedEvent(
                        block_name=block.name,
                        output=value,
                        elapsed_sec=time.monotonic() - t0,
                    )
                )
            # 블록 완료 후 체크포인트 저장
            if checkpoint is not None:
                await checkpoint.save(block.name, cast(Stud, value))

        return cast(OutputT, value)

    def stream(self, inp: InputT) -> AsyncGenerator[tuple[str, Stud], None]:
        """각 블록 실행 후 (block_name, output) 을 yield 하는 async generator.

        진행 상황 모니터링이나 중간 결과 활용에 사용한다.

            async for name, output in assembly.stream(inp):
                print(f"{name} → {output}")
        """
        return self._stream(inp)

    async def _stream(self, inp: InputT) -> AsyncGenerator[tuple[str, Stud], None]:
        value: Stud = cast(Stud, inp)
        for block in self._blocks:
            value = cast(Stud, await block.run(cast(Any, value)))
            yield block.name, value

    def run_sync(
        self,
        inp: InputT,
        *,
        checkpoint: Checkpoint | None = None,
        fault_map: dict[str, Exception] | None = None,
    ) -> OutputT:
        """Convenience synchronous API to run the assembly from sync code.

        This will create and run a temporary asyncio event loop and execute the
        asynchronous `run` implementation. It is a thin wrapper around
        asyncio.run(...) and intended for simple scripts and tests.
        """
        return asyncio.run(self.run(inp, checkpoint=checkpoint, fault_map=fault_map))
