"""BlockBuilder — wrap() 플루언트 빌더 API."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class BlockBuilder:
    """블록에 래퍼를 체이닝 방식으로 조합하는 플루언트 빌더.

    Example:
        ```python
        block = wrap(MyBlock()).retry().timeout(5.0).build()
        ```
    """

    def __init__(self, block: Block[Any, Any]) -> None:
        self._block: Block[Any, Any] = block
        self._stack: list[str] = [type(block).__name__]

    def inspect(self) -> list[str]:
        """래퍼 스택을 바깥→안쪽 순서로 반환한다.

        Example:
            ```python
            wrap(MyBlock()).retry().timeout(5.0).inspect()
            # → ["TimeoutBlock", "RetryBlock", "MyBlock"]
            ```
        """
        return list(self._stack)

    def semantic_retry(
        self,
        verify_fn: Callable[..., None],
        enrich_fn: Callable[..., Any],
        max_attempts: int = 3,
        abort_on_repeated_error: int | None = None,
        error_similarity_fn: Callable[[str, str], bool] | None = None,
        on_abort_fn: Callable[..., Any] | None = None,
        verify_after_abort: bool = True,
    ) -> "BlockBuilder":
        """SemanticRetryBlock 래퍼를 추가한다."""
        from pylego_blocks.core.semantic_retry import SemanticRetryBlock

        self._block = SemanticRetryBlock(
            self._block,
            verify_fn=verify_fn,
            enrich_fn=enrich_fn,
            max_attempts=max_attempts,
            abort_on_repeated_error=abort_on_repeated_error,
            error_similarity_fn=error_similarity_fn,
            on_abort_fn=on_abort_fn,
            verify_after_abort=verify_after_abort,
        )
        self._stack.insert(0, "SemanticRetryBlock")
        return self

    def retry(self, policy: Any = None) -> "BlockBuilder":
        """RetryBlock 래퍼를 추가한다."""
        from pylego_blocks.core.resilience import RetryBlock, RetryPolicy

        self._block = RetryBlock(
            self._block,
            policy=policy if policy is not None else RetryPolicy(),
        )
        self._stack.insert(0, "RetryBlock")
        return self

    def fallback(self, fallback_block: Block[Any, Any]) -> "BlockBuilder":
        """FallbackBlock 래퍼를 추가한다."""
        from pylego_blocks.core.resilience import FallbackBlock

        self._block = FallbackBlock(self._block, fallback=fallback_block)
        self._stack.insert(0, "FallbackBlock")
        return self

    def timeout(self, timeout_sec: float) -> "BlockBuilder":
        """TimeoutBlock 래퍼를 추가한다."""
        from pylego_blocks.core.resilience import TimeoutBlock

        self._block = TimeoutBlock(self._block, timeout_sec=timeout_sec)
        self._stack.insert(0, "TimeoutBlock")
        return self

    def circuit_breaker(
        self,
        failure_threshold: int = 5,
        reset_timeout: float = 30.0,
    ) -> "BlockBuilder":
        """CircuitBreakerBlock 래퍼를 추가한다."""
        from pylego_blocks.core.resilience import CircuitBreakerBlock

        self._block = CircuitBreakerBlock(
            self._block,
            failure_threshold=failure_threshold,
            reset_timeout=reset_timeout,
        )
        self._stack.insert(0, "CircuitBreakerBlock")
        return self

    def build(self) -> Block[Any, Any]:
        """최종 조합된 블록을 반환한다."""
        return self._block


def wrap(block: Block[Any, Any]) -> BlockBuilder:
    """블록을 플루언트 빌더로 감싼다.

    Example:
        ```python
        block = wrap(MyBlock()).retry().timeout(5.0).build()
        ```
    """
    return BlockBuilder(block)
