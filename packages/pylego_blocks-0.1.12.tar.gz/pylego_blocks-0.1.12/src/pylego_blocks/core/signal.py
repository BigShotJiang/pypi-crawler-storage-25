"""SignalScore / SignalAggregator — 신호 수집·집계 및 임계값 기반 판정."""

from __future__ import annotations

from typing import Literal

from pylego_blocks.core.stud import Stud


class SignalScore(Stud):
    """단일 신호 측정값.

    score 는 0.0(정상) ~ 1.0(매우 의심) 범위를 권장한다.
    """

    score: float
    reason: str = ""
    block_name: str = ""


AggregationStrategy = Literal["max", "mean", "any"]


class SignalAggregator:
    """복수 신호를 수집·집계해 임계값 기반 의심 판정을 내린다.

    집계 전략:
        ``max``  — 최고 점수 > threshold 이면 의심.
        ``mean`` — 평균 점수 > threshold 이면 의심.
        ``any``  — 임계값을 초과하는 신호가 하나라도 있으면 의심.

    Args:
        threshold: ``is_suspicious`` 판정 임계값 (0.0 ~ 1.0, 기본 0.7).
        strategy: 집계 전략 (``"max"`` / ``"mean"`` / ``"any"``, 기본 ``"max"``).

    Example:
        ```python
        aggregator = SignalAggregator(threshold=0.6, strategy="mean")
        aggregator.record(SignalScore(score=0.8, reason="형식 불량", block_name="FormatBlock"))
        aggregator.record(SignalScore(score=0.3, reason="컨텐츠 양호", block_name="ContentBlock"))
        # mean = 0.55 → not suspicious
        print(aggregator.is_suspicious)  # False
        ```
    """

    def __init__(
        self,
        threshold: float = 0.7,
        strategy: AggregationStrategy = "max",
    ) -> None:
        if not 0.0 <= threshold <= 1.0:
            raise ValueError(f"threshold 는 0.0 ~ 1.0 이어야 합니다. 입력값: {threshold}")
        self._threshold = threshold
        self._strategy: AggregationStrategy = strategy
        self._scores: list[SignalScore] = []

    # ── 공개 API ─────────────────────────────────────────────────────────────

    def record(self, score: SignalScore) -> None:
        """신호를 기록한다."""
        self._scores.append(score)

    @property
    def is_suspicious(self) -> bool:
        """현재 집계 전략으로 임계값 초과 여부를 반환한다."""
        if not self._scores:
            return False
        values = [s.score for s in self._scores]
        if self._strategy == "max":
            return max(values) > self._threshold
        if self._strategy == "mean":
            return sum(values) / len(values) > self._threshold
        # "any": 임계값을 초과하는 신호가 하나라도 있으면 의심
        return any(v > self._threshold for v in values)

    @property
    def scores(self) -> list[SignalScore]:
        """기록된 모든 신호의 복사본을 반환한다."""
        return list(self._scores)

    @property
    def threshold(self) -> float:
        return self._threshold

    @property
    def strategy(self) -> AggregationStrategy:
        return self._strategy

    def reset(self) -> None:
        """수집된 신호를 초기화한다."""
        self._scores.clear()
