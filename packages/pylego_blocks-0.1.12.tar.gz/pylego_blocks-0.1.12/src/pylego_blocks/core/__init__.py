"""pylego 코어 — Stud / Block / Assembly / Runtime 공용 API."""

from __future__ import annotations

from pylego_blocks.core.assembly import Assembly, CyclicAssemblyError, IncompatibleSnapError
from pylego_blocks.core.block import Block
from pylego_blocks.core.builder import BlockBuilder, wrap
from pylego_blocks.core.callable_block import CallableBlock
from pylego_blocks.core.budget import BudgetExceededError, ExecutionBudget
from pylego_blocks.core.branch import Branch
from pylego_blocks.core.checkpoint import Checkpoint, FileCheckpoint, MemoryCheckpoint
from pylego_blocks.core.events import (
    BlockEvent,
    BlockRetryEvent,
    CircuitBreakerStateEvent,
    CollectingEventBus,
    EventBus,
    LoggingEventBus,
    NestedEventBus,
    NoopEventBus,
    observe,
)
from pylego_blocks.core.fanout import FanOut, Gathered
from pylego_blocks.core.visualize import BlockStat, build_stats, to_dot, to_html, to_mermaid
from pylego_blocks.ops.causal import CausalFactor, EnvironmentContext, VersionContext
from pylego_blocks.ops.diff import HealthDiff
from pylego_blocks.ops.health import PipelineHealth, build_health_summary
from pylego_blocks.core.otel import OtelEventBus, configure_otel_from_env
from pylego_blocks.core.queue import DeadLetterQueue, Queue, WorkerPool
from pylego_blocks.core.redis_queue import RedisDeadLetterQueue, RedisQueue, RedisWorkerPool, make_queue
from pylego_blocks.core.resilience import (
    CircuitBreakerBlock,
    CircuitOpenError,
    FallbackBlock,
    RetryBlock,
    RetryPolicy,
    TimeoutBlock,
)
from pylego_blocks.core.runtime import AsyncRuntime, ProcessRuntime, SyncRuntime
from pylego_blocks.core.multi_perspective import (
    ConfidenceWeighted,
    ConsensusError,
    ConsensusPolicy,
    MajorityVote,
    MultiPerspectiveBlock,
    UnanimousRequired,
)
from pylego_blocks.core.semantic_retry import AbortVerificationError, MaxRepeatedErrorError, SemanticRetryBlock
from pylego_blocks.core.signal import AggregationStrategy, SignalAggregator, SignalScore
from pylego_blocks.core.tap import TapBlock
from pylego_blocks.core.store import FileStore, InMemoryStore, Store, StoreBlock
from pylego_blocks.core.stream import StreamBlock
from pylego_blocks.core.stud import Stud
from pylego_blocks.core.compat import (
    AssemblyValidator,
    CompatibilityError,
    CompatibilityResult,
    SemanticCompatibilityError,
    check_chain,
    check_connection,
)

__all__ = [
    "Assembly",
    "AsyncRuntime",
    "Block",
"BlockBuilder",
"CallableBlock",
    "BudgetExceededError",
    "ExecutionBudget",
    "BlockEvent",
    "BlockRetryEvent",
    "BlockStat",
    "CausalFactor",
    "EnvironmentContext",
    "HealthDiff",
    "PipelineHealth",
    "VersionContext",
    "Branch",
    "Checkpoint",
    "CircuitBreakerBlock",
    "CircuitBreakerStateEvent",
    "CircuitOpenError",
    "CollectingEventBus",
    "CyclicAssemblyError",
    "DeadLetterQueue",
    "EventBus",
    "FallbackBlock",
    "FanOut",
    "FileCheckpoint",
    "FileStore",
    "Gathered",
    "InMemoryStore",
    "IncompatibleSnapError",
    "LoggingEventBus",
    "MemoryCheckpoint",
    "NestedEventBus",
    "NoopEventBus",
    "OtelEventBus",
    "ProcessRuntime",
    "Queue",
    "RedisDeadLetterQueue",
    "RedisQueue",
    "RedisWorkerPool",
    "RetryBlock",
    "RetryPolicy",
    "Store",
    "StoreBlock",
    "AggregationStrategy",
    "ConfidenceWeighted",
    "ConsensusError",
    "ConsensusPolicy",
    "MajorityVote",
    "MultiPerspectiveBlock",
    "AbortVerificationError",
    "MaxRepeatedErrorError",
    "SemanticRetryBlock",
    "UnanimousRequired",
    "SignalAggregator",
    "SignalScore",
    "StreamBlock",
    "Stud",
    "SyncRuntime",
    "TapBlock",
    "TimeoutBlock",
    "WorkerPool",
    "build_health_summary",
    "build_stats",
    "configure_otel_from_env",
    "observe",
    "make_queue",
    "to_dot",
    "to_html",
    "to_mermaid",
    "wrap",
    "AssemblyValidator",
    "CompatibilityError",
    "CompatibilityResult",
    "SemanticCompatibilityError",
    "check_chain",
    "check_connection",
]
