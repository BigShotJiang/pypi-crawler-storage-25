"""Testing helpers for pylego."""

from __future__ import annotations

from .contracts import (
    assert_block_contract,
    blocks_with_compatible_pairs,
    ContractResult,
    iter_block_contracts,
)

__all__ = [
    "assert_block_contract",
    "blocks_with_compatible_pairs",
    "ContractResult",
    "iter_block_contracts",
]
