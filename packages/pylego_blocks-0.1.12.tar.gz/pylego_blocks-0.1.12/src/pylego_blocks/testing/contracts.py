from __future__ import annotations

from typing import Any, Iterable, Optional, Type
import asyncio

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud
from pylego_blocks.inspect.discovery import iter_blocks


class ContractResult(Stud):
    """Result of a single block contract assertion.

    Fields:
    - block_qualified_name: module + qualname for the block class
    - ok: whether the basic contract checks passed
    - reason: short human-readable failure reason when ok is False
    """

    block_qualified_name: str
    ok: bool
    reason: str = ""


def is_stud_subclass(obj: object) -> bool:
    return isinstance(obj, type) and issubclass(obj, Stud)


async def assert_block_contract(
    block_cls: Type[Block[Any, Any]], *, sample_input: Stud, block: Optional[Block[Any, Any]] = None
) -> ContractResult:
    """Asynchronously assert a minimal contract for a block class.

    The function performs runtime checks:
    1. input_model and output_model exist and are Stud subclasses
    2. sample_input is an instance of input_model
    3. block.run(sample_input) completes (sync or async) and returns an instance of output_model

    Returns a ContractResult describing success/failure and an explanatory reason on failure.
    """
    name = f"{block_cls.__module__}.{block_cls.__qualname__}"

    # Basic type checks
    if not isinstance(block_cls, type):
        return ContractResult(block_qualified_name=name, ok=False, reason="block_cls must be a class")

    if not hasattr(block_cls, "input_model") or not hasattr(block_cls, "output_model"):
        return ContractResult(block_qualified_name=name, ok=False, reason="missing input_model/output_model")

    inp = getattr(block_cls, "input_model")
    out = getattr(block_cls, "output_model")

    if not is_stud_subclass(inp):
        return ContractResult(block_qualified_name=name, ok=False, reason="input_model not Stud subclass")
    if not is_stud_subclass(out):
        return ContractResult(block_qualified_name=name, ok=False, reason="output_model not Stud subclass")

    # sample_input type
    if not isinstance(sample_input, inp):
        return ContractResult(block_qualified_name=name, ok=False, reason="sample_input type mismatch")

    # Instantiate block if not provided
    if block is None:
        try:
            block = block_cls()
        except Exception as exc:  # pragma: no cover - instantiation failures reported
            return ContractResult(block_qualified_name=name, ok=False, reason=f"instantiate_failed: {exc}")

    # Run the block (support sync or async run)
    try:
        maybe_awaitable = block.run(sample_input)
        if asyncio.iscoroutine(maybe_awaitable) or hasattr(maybe_awaitable, "__await__"):
            result = await maybe_awaitable
        else:
            result = maybe_awaitable
    except Exception as exc:  # pragma: no cover - runtime failures reported
        return ContractResult(block_qualified_name=name, ok=False, reason=f"run_failed: {exc}")

    # Validate output type
    if not isinstance(result, out):
        return ContractResult(block_qualified_name=name, ok=False, reason="output type mismatch")

    return ContractResult(block_qualified_name=name, ok=True)


def iter_block_contracts(root: str = "pylego_blocks.blocks") -> Iterable[Type[Block[Any, Any]]]:
    """Yield concrete Block classes found under `root` using discover.iter_blocks.

    This reuses the existing inspection implementation to avoid duplication.
    """
    for cls in iter_blocks(root):
        yield cls


def blocks_with_compatible_pairs(
    blocks: Iterable[Type[Block[Any, Any]]]
) -> Iterable[tuple[Type[Block[Any, Any]], Type[Block[Any, Any]]]]:
    """Yield (source, target) pairs where source.output_model is target.input_model."""
    for a in blocks:
        for b in blocks:
            if getattr(a, "output_model", None) is getattr(b, "input_model", None):
                yield a, b
