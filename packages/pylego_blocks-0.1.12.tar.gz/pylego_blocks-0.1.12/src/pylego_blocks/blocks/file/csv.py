"""CsvReadBlock / CsvWriteBlock — CSV 파일 읽기·쓰기 블록.

표준 라이브러리 csv 모듈 기반 — 추가 의존성 없음.
"""

from __future__ import annotations

import asyncio
import csv
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class CsvReadInput(Stud):
    """CSV 파일 읽기 입력 계약."""

    path: str
    delimiter: str = ","
    encoding: str = "utf-8"
    has_header: bool = True


class CsvReadResult(Stud):
    """CSV 파일 읽기 결과 계약."""

    rows: list[dict[str, Any]]
    row_count: int


class CsvWriteInput(Stud):
    """CSV 파일 쓰기 입력 계약."""

    path: str
    rows: list[dict[str, Any]]
    fieldnames: list[str] | None = None
    delimiter: str = ","
    encoding: str = "utf-8"


class CsvWriteResult(Stud):
    """CSV 파일 쓰기 결과 계약."""

    path: str
    row_count: int


class CsvReadBlock(Block[CsvReadInput, CsvReadResult]):
    """CSV 파일을 읽어 딕셔너리 행 목록으로 반환하는 블록.

    `has_header=True`(기본값)이면 첫 행을 헤더로 사용한다.
    `has_header=False`이면 컬럼 이름을 열 인덱스(문자열)로 사용한다.

    Example:
        ```python
        block = CsvReadBlock()
        result = await block.run(CsvReadInput(path="data.csv"))
        for row in result.rows:
            print(row)
        ```
    """

    input_model = CsvReadInput
    output_model = CsvReadResult

    async def run(self, inp: CsvReadInput) -> CsvReadResult:
        def _read() -> list[dict[str, Any]]:
            rows: list[dict[str, Any]] = []
            with open(inp.path, encoding=inp.encoding, newline="") as f:
                if inp.has_header:
                    reader: csv.DictReader[str] = csv.DictReader(
                        f, delimiter=inp.delimiter
                    )
                    for row in reader:
                        rows.append(dict(row))
                else:
                    plain = csv.reader(f, delimiter=inp.delimiter)
                    for line in plain:
                        rows.append({str(j): v for j, v in enumerate(line)})
            return rows

        rows = await asyncio.to_thread(_read)
        return CsvReadResult(rows=rows, row_count=len(rows))


class CsvWriteBlock(Block[CsvWriteInput, CsvWriteResult]):
    """딕셔너리 행 목록을 CSV 파일로 쓰는 블록.

    `fieldnames` 미설정 시 첫 번째 행의 키를 컬럼 순서로 사용한다.

    Example:
        ```python
        block = CsvWriteBlock()
        result = await block.run(CsvWriteInput(
            path="output.csv",
            rows=[{"name": "홍길동", "age": "30"}],
        ))
        print(result.row_count)
        ```
    """

    input_model = CsvWriteInput
    output_model = CsvWriteResult

    async def run(self, inp: CsvWriteInput) -> CsvWriteResult:
        def _write() -> int:
            if not inp.rows:
                with open(inp.path, "w", encoding=inp.encoding, newline="") as f:
                    f.write("")
                return 0
            fieldnames = inp.fieldnames or list(inp.rows[0].keys())
            with open(inp.path, "w", encoding=inp.encoding, newline="") as f:
                writer = csv.DictWriter(
                    f, fieldnames=fieldnames, delimiter=inp.delimiter
                )
                writer.writeheader()
                for row in inp.rows:
                    writer.writerow(row)
            return len(inp.rows)

        count = await asyncio.to_thread(_write)
        return CsvWriteResult(path=inp.path, row_count=count)
