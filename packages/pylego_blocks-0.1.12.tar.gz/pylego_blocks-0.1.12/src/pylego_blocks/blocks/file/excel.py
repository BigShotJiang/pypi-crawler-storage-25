"""ExcelReadBlock / ExcelWriteBlock — openpyxl 기반 Excel 읽기/쓰기 블록."""

from __future__ import annotations

import asyncio
from typing import Any, Union

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class ExcelReadInput(Stud):
    """Excel 읽기 입력 계약.

    Attributes:
        path: 읽을 Excel 파일 경로 (.xlsx).
        sheet: 시트 이름 또는 인덱스 (0-based). 기본값 0 (첫 번째 시트).
    """

    path: str
    sheet: Union[str, int] = 0


class ExcelReadResult(Stud):
    """Excel 읽기 결과 계약.

    Attributes:
        rows: 각 행이 ``{컬럼명: 값}`` dict 인 리스트.
        row_count: 반환된 데이터 행 수 (헤더 제외).
        sheet_name: 실제 읽은 시트 이름.
    """

    rows: list[dict[str, Any]]
    row_count: int
    sheet_name: str


class ExcelWriteInput(Stud):
    """Excel 쓰기 입력 계약.

    Attributes:
        path: 저장할 Excel 파일 경로 (.xlsx).
        rows: 쓸 데이터. 각 행은 ``{컬럼명: 값}`` dict.
        sheet_name: 시트 이름. 기본값 "Sheet1".
    """

    path: str
    rows: list[dict[str, Any]]
    sheet_name: str = "Sheet1"


class ExcelWriteResult(Stud):
    """Excel 쓰기 결과 계약.

    Attributes:
        path: 저장된 파일 경로.
        row_count: 저장된 데이터 행 수 (헤더 제외).
    """

    path: str
    row_count: int


class ExcelReadBlock(Block[ExcelReadInput, ExcelReadResult]):
    """asyncio.to_thread으로 openpyxl을 래핑한 Excel 읽기 블록.

    ``openpyxl`` 은 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[excel]

    Example:
        ```python
        block = ExcelReadBlock()
        result = await block.run(ExcelReadInput(path="data.xlsx", sheet=0))
        # result.rows == [{"name": "Alice", "age": 30}, ...]
        ```
    """

    input_model = ExcelReadInput
    output_model = ExcelReadResult

    async def run(self, inp: ExcelReadInput) -> ExcelReadResult:
        """Excel 파일을 읽어 행 목록으로 반환한다."""
        path, sheet = inp.path, inp.sheet

        def _read() -> tuple[list[dict[str, Any]], str]:
            import openpyxl  # lazy import — optional dependency

            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            if isinstance(sheet, int):
                ws = wb.worksheets[sheet]
            else:
                ws = wb[sheet]
            name: str = ws.title
            rows_iter = ws.iter_rows(values_only=True)
            header = [str(c) if c is not None else "" for c in next(rows_iter, ())]
            data: list[dict[str, Any]] = []
            for row in rows_iter:
                data.append(dict(zip(header, row)))
            wb.close()
            return data, name

        rows, sheet_name = await asyncio.to_thread(_read)
        return ExcelReadResult(rows=rows, row_count=len(rows), sheet_name=sheet_name)


class ExcelWriteBlock(Block[ExcelWriteInput, ExcelWriteResult]):
    """asyncio.to_thread으로 openpyxl을 래핑한 Excel 쓰기 블록.

    ``openpyxl`` 은 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[excel]

    Example:
        ```python
        block = ExcelWriteBlock()
        result = await block.run(ExcelWriteInput(
            path="out.xlsx",
            rows=[{"name": "Alice", "age": 30}],
        ))
        ```
    """

    input_model = ExcelWriteInput
    output_model = ExcelWriteResult

    async def run(self, inp: ExcelWriteInput) -> ExcelWriteResult:
        """행 목록을 Excel 파일로 저장한다."""
        path, rows, sheet_name = inp.path, inp.rows, inp.sheet_name

        def _write() -> None:
            import openpyxl  # lazy import — optional dependency

            wb = openpyxl.Workbook()
            ws = wb.active
            if ws is None:
                ws = wb.create_sheet()
            ws.title = sheet_name
            if rows:
                headers = list(rows[0].keys())
                ws.append(headers)
                for row in rows:
                    ws.append([row.get(h) for h in headers])
            wb.save(path)

        await asyncio.to_thread(_write)
        return ExcelWriteResult(path=path, row_count=len(rows))
