"""PdfReadBlock / PdfWriteBlock — pypdf/reportlab 기반 PDF 읽기/쓰기 블록."""

from __future__ import annotations

import asyncio
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class PdfReadInput(Stud):
    """PDF 읽기 입력 계약.

    Attributes:
        path: 읽을 PDF 파일 경로.
        pages: 읽을 페이지 번호 목록 (0-based). None 이면 전체 페이지.
    """

    path: str
    pages: list[int] | None = None


class PdfReadResult(Stud):
    """PDF 읽기 결과 계약.

    Attributes:
        text: 전체 텍스트 (페이지 구분 없이 합쳐진 문자열).
        page_texts: 페이지별 텍스트 리스트.
        page_count: 총 페이지 수 (파일 전체 기준).
    """

    text: str
    page_texts: list[str]
    page_count: int


class PdfWriteInput(Stud):
    """PDF 쓰기 입력 계약.

    Attributes:
        path: 저장할 PDF 파일 경로.
        content: 페이지별 텍스트 내용 리스트. 각 원소가 한 페이지.
        title: PDF 메타데이터 제목. 기본값 "".
    """

    path: str
    content: list[str]
    title: str = ""


class PdfWriteResult(Stud):
    """PDF 쓰기 결과 계약.

    Attributes:
        path: 저장된 파일 경로.
        page_count: 저장된 페이지 수.
    """

    path: str
    page_count: int


class PdfReadBlock(Block[PdfReadInput, PdfReadResult]):
    """pypdf를 사용한 PDF 텍스트 추출 블록.

    ``pypdf`` 는 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[pdf]

    Example:
        ```python
        block = PdfReadBlock()
        result = await block.run(PdfReadInput(path="doc.pdf"))
        print(result.text)          # 전체 텍스트
        print(result.page_texts[0]) # 첫 페이지 텍스트
        ```
    """

    input_model = PdfReadInput
    output_model = PdfReadResult

    async def run(self, inp: PdfReadInput) -> PdfReadResult:
        """PDF 파일에서 텍스트를 추출한다."""
        path, pages = inp.path, inp.pages

        def _read() -> tuple[list[str], int]:
            import pypdf  # lazy import — optional dependency

            reader = pypdf.PdfReader(path)
            total = len(reader.pages)
            indices = pages if pages is not None else list(range(total))
            texts = [reader.pages[i].extract_text() or "" for i in indices]
            return texts, total

        page_texts, page_count = await asyncio.to_thread(_read)
        return PdfReadResult(
            text="\n".join(page_texts),
            page_texts=page_texts,
            page_count=page_count,
        )


class PdfWriteBlock(Block[PdfWriteInput, PdfWriteResult]):
    """reportlab을 사용한 PDF 생성 블록.

    ``reportlab`` 은 선택적 의존성이므로 사용 전에 설치해야 한다::

        pip install pylego[pdf]

    Example:
        ```python
        block = PdfWriteBlock()
        result = await block.run(PdfWriteInput(
            path="out.pdf",
            content=["첫 페이지 내용", "두 번째 페이지 내용"],
            title="My Report",
        ))
        ```
    """

    input_model = PdfWriteInput
    output_model = PdfWriteResult

    async def run(self, inp: PdfWriteInput) -> PdfWriteResult:
        """텍스트 내용으로 PDF 파일을 생성한다."""
        path, content, title = inp.path, inp.content, inp.title

        def _write() -> None:
            from reportlab.lib.pagesizes import A4  # lazy import — optional dep
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.units import cm
            from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate

            doc = SimpleDocTemplate(
                path,
                pagesize=A4,
                title=title,
                leftMargin=2 * cm,
                rightMargin=2 * cm,
                topMargin=2 * cm,
                bottomMargin=2 * cm,
            )
            styles = getSampleStyleSheet()
            story: list[Any] = []
            for i, page_text in enumerate(content):
                if i > 0:
                    story.append(PageBreak())
                for line in page_text.splitlines():
                    story.append(Paragraph(line or "&nbsp;", styles["Normal"]))
            doc.build(story)

        await asyncio.to_thread(_write)
        return PdfWriteResult(path=path, page_count=len(content))
