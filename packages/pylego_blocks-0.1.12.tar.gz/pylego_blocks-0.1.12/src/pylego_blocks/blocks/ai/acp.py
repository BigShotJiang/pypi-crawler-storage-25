"""AcpPromptBlock — ai-pi 의 copilot/gemini 데몬 Unix 소켓에 프롬프트 전송.

``lib/acp_ask.py::send_to_socket`` 의 로직을 블록화. 소켓 I/O 를 ``SocketSender``
콜러블로 추상화하여 테스트에서 fake 로 대체 가능.
"""

from __future__ import annotations

import asyncio
import contextlib
from collections.abc import Awaitable, Callable

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud

SocketSender = Callable[[str, str, float], Awaitable[str]]


async def _default_socket_sender(sock_path: str, message: str, timeout: float) -> str:
    """기본 구현: asyncio.open_unix_connection 으로 메시지 전송 후 전체 응답 수신."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_unix_connection(path=sock_path), timeout=timeout
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"데몬 소켓을 찾을 수 없습니다: {sock_path}") from exc

    try:
        writer.write(message.encode())
        await writer.drain()
        writer.write_eof()

        chunks: list[bytes] = []
        while True:
            data = await asyncio.wait_for(reader.read(65536), timeout=timeout)
            if not data:
                break
            chunks.append(data)
        return b"".join(chunks).decode(errors="replace")
    finally:
        writer.close()
        # 닫는 과정의 잔여 예외는 무시 (연결이 이미 끊긴 경우 등)
        with contextlib.suppress(Exception):
            await writer.wait_closed()


class AcpPromptRequest(Stud):
    socket_path: str
    prompt: str
    timeout_sec: float = 300.0


class AcpPromptResponse(Stud):
    text: str


# #35: daemon 의 `_handle_client` 가 프롬프트 처리 중 예외 발생 시 소켓에
# `ERROR: <exc>` 접두 문자열을 송신한다 (ai-pi/lib/acp_daemon.py 참조).
# 이를 정상 LLM 응답으로 오인하면 auto-verdict 단계에서 false PASS 가 되므로
# transport 레이어에서 즉시 RuntimeError 로 전환해 상위 블록이 FAIL 처리 경로로
# 분기할 수 있게 한다.
DAEMON_ERROR_PREFIX = "ERROR: "


class AcpDaemonError(RuntimeError):
    """Daemon 이 ERROR 접두로 반환한 응답을 나타내는 예외."""


class AcpPromptBlock(Block[AcpPromptRequest, AcpPromptResponse]):
    """Unix 소켓 데몬(copilot/gemini) 에 프롬프트를 보내 응답을 수신."""

    input_model = AcpPromptRequest
    output_model = AcpPromptResponse

    def __init__(self, sender: SocketSender | None = None) -> None:
        self._send = sender if sender is not None else _default_socket_sender

    async def run(self, inp: AcpPromptRequest) -> AcpPromptResponse:
        text = await self._send(inp.socket_path, inp.prompt, inp.timeout_sec)
        if text.startswith(DAEMON_ERROR_PREFIX):
            raise AcpDaemonError(text)
        return AcpPromptResponse(text=text)
