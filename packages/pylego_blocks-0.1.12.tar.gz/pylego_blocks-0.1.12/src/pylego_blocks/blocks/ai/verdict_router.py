"""VerdictRouter — VerdictParseBlock + UNKNOWN 에스컬레이션 정책 결합."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pylego_blocks.blocks.ai.verdict import Verdict, VerdictParseBlock, VerdictParseRequest
from pylego_blocks.core.block import Block


class UnknownVerdictError(RuntimeError):
    """VerdictRouter에서 UNKNOWN 판정이고 ``raise_error=True`` 일 때 발생."""


@dataclass
class UnknownPolicy:
    """UNKNOWN 판정 발생 시 적용할 처리 정책.

    우선순위: raise_error → fallback → escalate_to → UNKNOWN 그대로 반환.

    Args:
        raise_error: True이면 ``UnknownVerdictError`` 를 즉시 발생시킨다.
        fallback: UNKNOWN 대신 실행할 블록. 결과가 최종 출력이 된다.
        escalate_to: 사이드 채널 알림·큐 블록. 실행 후 UNKNOWN을 그대로 반환한다.
    """

    raise_error: bool = False
    fallback: Block[VerdictParseRequest, Verdict] | None = field(default=None)
    escalate_to: Block[VerdictParseRequest, Any] | None = field(default=None)


class VerdictRouter(Block[VerdictParseRequest, Verdict]):
    """VerdictParseBlock 래퍼 + UNKNOWN 에스컬레이션 정책.

    UNKNOWN 처리 우선순위:
        1. ``raise_error=True``  → ``UnknownVerdictError`` 발생
        2. ``fallback`` 설정     → 폴백 블록 실행, 그 결과 반환
        3. ``escalate_to`` 설정  → 에스컬레이션 블록 실행 후 UNKNOWN 반환
        4. 미설정                → UNKNOWN 그대로 반환 (기본)

    Args:
        verdict_block: 사용할 ``VerdictParseBlock`` 인스턴스.
                       None 이면 기본 ``VerdictParseBlock()`` 생성.
        unknown_policy: UNKNOWN 처리 정책. None 이면 기본 통과(no-op).

    Example:
        ```python
        from pylego_blocks.blocks.ai.verdict_router import UnknownPolicy, VerdictRouter

        # UNKNOWN → 예외
        router = VerdictRouter(unknown_policy=UnknownPolicy(raise_error=True))

        # UNKNOWN → 폴백 블록 재시도
        router = VerdictRouter(
            unknown_policy=UnknownPolicy(fallback=RetryAiBlock())
        )

        # UNKNOWN → 알림 후 UNKNOWN 반환
        router = VerdictRouter(
            unknown_policy=UnknownPolicy(escalate_to=AlertBlock())
        )
        ```
    """

    input_model = VerdictParseRequest
    output_model = Verdict

    def __init__(
        self,
        verdict_block: VerdictParseBlock | None = None,
        *,
        unknown_policy: UnknownPolicy | None = None,
    ) -> None:
        self._verdict_block = verdict_block if verdict_block is not None else VerdictParseBlock()
        self._policy = unknown_policy if unknown_policy is not None else UnknownPolicy()
        self.name = f"VerdictRouter({self._verdict_block.name})"

    async def run(self, inp: VerdictParseRequest) -> Verdict:
        verdict = await self._verdict_block.run(inp)

        if verdict.result != "UNKNOWN":
            return verdict

        policy = self._policy

        if policy.raise_error:
            raise UnknownVerdictError(
                f"UNKNOWN 판정 — 자동 처리 불가: {inp.text[:120]!r}"
            )

        if policy.fallback is not None:
            return await policy.fallback.run(inp)

        if policy.escalate_to is not None:
            await policy.escalate_to.run(inp)

        return verdict
