"""BaseHttpBlock — HTTP 블록 공통 기반 클래스.

timeout / default_headers / follow_redirects 를 생성자에서 통합 설정하고,
개별 요청 시 Stud 필드로 오버라이드할 수 있다.

선택 기준:
  - 단순 REST 호출           → HttpRequestBlock
  - 로그인·쿠키·토큰 취득    → HttpSessionUnit
  - 인증 후 반복 호출        → HttpSession + HttpRequestBlock 조합
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class BaseHttpBlock[I: Stud, O: Stud](Block[I, O]):
    """HTTP 블록의 공통 기반.

    Args:
        timeout: 기본 타임아웃 (초). 개별 요청 Stud 의 timeout 필드로 오버라이드 가능.
        default_headers: 모든 요청에 기본 포함되는 헤더.
            개별 요청 헤더가 동일 키를 갖는 경우 요청 헤더가 우선된다.
        follow_redirects: 기본 리다이렉트 추적 여부.
    """

    input_model: type[Stud] = Stud
    output_model: type[Stud] = Stud

    def __init__(
        self,
        timeout: float = 30.0,
        default_headers: dict[str, str] | None = None,
        follow_redirects: bool = True,
    ) -> None:
        self._timeout = timeout
        self._default_headers: dict[str, str] = default_headers or {}
        self._follow_redirects = follow_redirects

    def _merge_headers(self, request_headers: dict[str, Any]) -> dict[str, str]:
        """생성자 기본 헤더와 요청 헤더를 병합한다. 요청 헤더가 우선된다."""
        return {**self._default_headers, **request_headers}

    @abstractmethod
    async def run(self, inp: I) -> O: ...
