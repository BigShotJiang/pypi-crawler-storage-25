"""SubprocessBlock — 외부 프로세스 실행 블록.

asyncio.to_thread 로 subprocess.run 을 비동기 래핑한다.
"""

from __future__ import annotations

import asyncio
import subprocess
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class SubprocessInput(Stud):
    """외부 프로세스 실행 입력 계약.

    cmd: 실행할 명령어 인수 목록. 예: ["git", "status"] 또는 ["python", "-c", "print(1)"]
    """

    cmd: list[str]
    cwd: str | None = None
    env: dict[str, str] | None = None
    timeout: float | None = None
    stdin_data: str | None = None


class SubprocessResult(Stud):
    """외부 프로세스 실행 결과 계약."""

    stdout: str
    stderr: str
    returncode: int
    success: bool


class SubprocessBlock(Block[SubprocessInput, SubprocessResult]):
    """외부 프로세스를 비동기로 실행하는 블록.

    `asyncio.to_thread` 로 subprocess.run 을 감싸므로 이벤트 루프를 차단하지 않는다.
    returncode == 0 이면 success=True.

    Example:
        ```python
        block = SubprocessBlock()
        result = await block.run(SubprocessInput(cmd=["git", "log", "--oneline", "-5"]))
        if result.success:
            print(result.stdout)
        else:
            print(result.stderr)
        ```
    """

    input_model = SubprocessInput
    output_model = SubprocessResult

    async def run(self, inp: SubprocessInput) -> SubprocessResult:
        kwargs: dict[str, Any] = {
            "capture_output": True,
            "text": True,
        }
        if inp.cwd is not None:
            kwargs["cwd"] = inp.cwd
        if inp.env is not None:
            kwargs["env"] = inp.env
        if inp.timeout is not None:
            kwargs["timeout"] = inp.timeout
        if inp.stdin_data is not None:
            kwargs["input"] = inp.stdin_data

        def _run() -> subprocess.CompletedProcess[str]:
            return subprocess.run(inp.cmd, **kwargs)  # noqa: S603

        proc = await asyncio.to_thread(_run)
        return SubprocessResult(
            stdout=proc.stdout,
            stderr=proc.stderr,
            returncode=proc.returncode,
            success=proc.returncode == 0,
        )
