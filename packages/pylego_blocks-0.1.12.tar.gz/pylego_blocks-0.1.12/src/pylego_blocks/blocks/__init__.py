"""pylego.blocks — 재사용 가능한 도메인 블록 모음.

M6 범위:
- github/ : GitHub 이슈·브랜치·PR 조작 블록 (ai-pi 파이프라인 재작성용)
"""
