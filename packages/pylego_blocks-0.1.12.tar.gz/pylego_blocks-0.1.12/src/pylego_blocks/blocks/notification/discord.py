"""DiscordBlock — Discord Webhook 메시지 전송 블록.

설치:
    pip install pylego[discord]

기본 사용:
    block = DiscordBlock(webhook_url="https://discord.com/api/webhooks/...")
    result = await block.run(DiscordInput(content="파이프라인 완료"))

환경변수:
    PYLEGO_DISCORD_WEBHOOK_URL — webhook_url 미지정 시 fallback
"""

from __future__ import annotations

import os
from typing import Any

from pydantic import Field

from pylego_blocks.blocks.http import HttpBlock
from pylego_blocks.core.stud import Stud


class DiscordInput(Stud):
    content: str
    username: str | None = None
    embeds: list[dict[str, object]] = Field(default_factory=list)


class DiscordResult(Stud):
    ok: bool


class DiscordBlock(HttpBlock[DiscordInput, DiscordResult]):
    """Discord Webhook API 로 메시지를 전송하는 블록.

    Args:
        webhook_url: Discord Webhook URL.
                     None 이면 ``PYLEGO_DISCORD_WEBHOOK_URL`` 환경변수 사용.
    """

    input_model = DiscordInput
    output_model = DiscordResult
    _extra = "pylego[discord]"

    def __init__(self, webhook_url: str | None = None) -> None:
        resolved = webhook_url or os.environ.get("PYLEGO_DISCORD_WEBHOOK_URL")
        if not resolved:
            raise ValueError(
                "webhook_url 또는 PYLEGO_DISCORD_WEBHOOK_URL 환경변수가 필요합니다."
            )
        self._webhook_url = resolved

    def _build_request(
        self, inp: DiscordInput
    ) -> tuple[str, str, dict[str, Any]]:
        url = f"{self._webhook_url}?wait=true"
        body: dict[str, Any] = {"content": inp.content}
        if inp.username is not None:
            body["username"] = inp.username
        if inp.embeds:
            body["embeds"] = inp.embeds
        return "POST", url, body

    def _parse_response(self, data: dict[str, Any]) -> DiscordResult:
        return DiscordResult(ok=True)
