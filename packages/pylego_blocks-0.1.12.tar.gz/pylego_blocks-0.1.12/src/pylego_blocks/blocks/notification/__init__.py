"""pylego 알림 블록 — Telegram / Gmail."""
