"""GitHub 도메인 블록."""

from __future__ import annotations

from pylego_blocks.blocks.github.issue import (
    IssueInspectBlock,
    IssueMetadata,
    IssueRef,
)
from pylego_blocks.blocks.github.issue_ops import (
    IssueCloseBlock,
    IssueCloseRequest,
    IssueCloseResult,
    IssueCommentBlock,
    IssueCommentRequest,
    IssueCommentResult,
    LabelTransitionBlock,
    LabelTransitionRequest,
    LabelTransitionResult,
)

__all__ = [
    "IssueCloseBlock",
    "IssueCloseRequest",
    "IssueCloseResult",
    "IssueCommentBlock",
    "IssueCommentRequest",
    "IssueCommentResult",
    "IssueInspectBlock",
    "IssueMetadata",
    "IssueRef",
    "LabelTransitionBlock",
    "LabelTransitionRequest",
    "LabelTransitionResult",
]
