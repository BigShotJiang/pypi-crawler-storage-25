"""QueryBlock — DB 쿼리 블록 공통 추상 베이스.

DuckDB·SQLite·MySQL 블록이 공유하는 I/O 계약(QueryInput/QueryResult)과
추상 메서드 ``_execute()`` 를 정의한다. 서브클래스는 ``_execute()`` 만 구현하면 된다.
"""

from __future__ import annotations

from abc import abstractmethod
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class QueryInput(Stud):
    """DB 쿼리 실행 입력 계약.

    Attributes:
        query: 실행할 SQL 문자열. 파라미터 자리는 DB 드라이버 규약에 따른다.
        params: 쿼리 파라미터 목록. 기본값은 빈 리스트.
    """

    model_config = Stud.model_config  # frozen=True, extra="forbid" 상속

    query: str
    params: list[Any] = []


class QueryResult(Stud):
    """DB 쿼리 실행 결과 계약.

    Attributes:
        rows: 반환된 행(row)의 리스트. 각 행은 컬럼명 → 값 매핑.
        row_count: 반환된 행 수 (len(rows) 와 일치).
    """

    model_config = Stud.model_config  # frozen=True, extra="forbid" 상속

    rows: list[dict[str, Any]]
    row_count: int


class QueryBlock(Block[QueryInput, QueryResult]):
    """DB 쿼리 블록 추상 베이스.

    서브클래스는 ``_execute()`` 만 구현하면 된다.
    ``run()`` 은 ``_execute()`` 결과를 받아 ``QueryResult`` 로 래핑한다.

    Example:
        ```python
        class SQLiteBlock(QueryBlock):
            def __init__(self, db_path: str) -> None:
                self._db_path = db_path

            async def _execute(
                self, query: str, params: list[Any]
            ) -> list[dict[str, Any]]:
                import aiosqlite
                async with aiosqlite.connect(self._db_path) as conn:
                    conn.row_factory = aiosqlite.Row
                    async with conn.execute(query, params) as cur:
                        rows = await cur.fetchall()
                        return [dict(r) for r in rows]
        ```
    """

    input_model = QueryInput
    output_model = QueryResult

    async def run(self, inp: QueryInput) -> QueryResult:
        """쿼리를 실행하고 결과를 QueryResult 로 반환한다.

        Args:
            inp: 실행할 SQL과 파라미터.

        Returns:
            rows 및 row_count 가 채워진 QueryResult 인스턴스.
        """
        rows = await self._execute(inp.query, inp.params)
        return QueryResult(rows=rows, row_count=len(rows))

    @abstractmethod
    async def _execute(
        self, query: str, params: list[Any]
    ) -> list[dict[str, Any]]:
        """실제 DB 드라이버 호출 로직. 서브클래스에서 반드시 구현.

        Args:
            query: 실행할 SQL 문자열.
            params: 쿼리 파라미터 목록.

        Returns:
            각 행이 ``{컬럼명: 값}`` dict 인 리스트.
        """
        ...
