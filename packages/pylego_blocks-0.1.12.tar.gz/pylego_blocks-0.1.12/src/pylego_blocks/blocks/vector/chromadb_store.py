"""VectorUpsertBlock / VectorQueryBlock — ChromaDB 벡터 저장·검색 블록.

pylego[chromadb] 설치 필요: `pip install pylego[chromadb]`
"""

from __future__ import annotations

import asyncio
from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


# ── Upsert ────────────────────────────────────────────────────────────────────

class VectorUpsertInput(Stud):
    """벡터 저장 입력 계약."""

    collection: str = "default"
    ids: list[str]
    embeddings: list[list[float]]
    documents: list[str] | None = None
    metadatas: list[dict[str, Any]] | None = None


class VectorUpsertResult(Stud):
    """벡터 저장 결과 계약."""

    upserted_count: int
    collection: str


# ── Query ─────────────────────────────────────────────────────────────────────

class VectorQueryInput(Stud):
    """벡터 검색 입력 계약."""

    collection: str = "default"
    query_embeddings: list[list[float]]
    top_k: int = 5
    where: dict[str, Any] | None = None


class VectorQueryResult(Stud):
    """벡터 검색 결과 계약."""

    ids: list[list[str]]
    distances: list[list[float]]
    documents: list[list[str | None]]
    collection: str


# ── 공통 ChromaDB 클라이언트 초기화 ──────────────────────────────────────────

class _ChromaBase:
    """ChromaDB 클라이언트를 레이지하게 초기화하는 믹스인."""

    def __init__(self, persist_directory: str | None = None) -> None:
        self._persist_dir = persist_directory
        self._chroma: Any = None  # chromadb.ClientAPI

    def _client(self) -> Any:
        if self._chroma is None:
            try:
                import chromadb
            except ImportError as exc:
                raise ImportError(
                    "chromadb 가 설치되어 있지 않습니다. `pip install pylego[chromadb]`"
                ) from exc
            if self._persist_dir:
                self._chroma = chromadb.PersistentClient(path=self._persist_dir)
            else:
                self._chroma = chromadb.EphemeralClient()
        return self._chroma


# ── Blocks ────────────────────────────────────────────────────────────────────

class VectorUpsertBlock(_ChromaBase, Block[VectorUpsertInput, VectorUpsertResult]):
    """임베딩 벡터를 ChromaDB 컬렉션에 저장(upsert)하는 블록.

    Args:
        persist_directory: ChromaDB 데이터 저장 경로. None이면 인메모리(EphemeralClient).

    Example:
        ```python
        block = VectorUpsertBlock(persist_directory="./chroma_db")
        result = await block.run(VectorUpsertInput(
            ids=["doc1", "doc2"],
            embeddings=[[0.1, 0.2, ...], [0.3, 0.4, ...]],
            documents=["Hello world", "How are you"],
        ))
        print(result.upserted_count)  # 2
        ```
    """

    input_model = VectorUpsertInput
    output_model = VectorUpsertResult

    def __init__(self, persist_directory: str | None = None) -> None:
        _ChromaBase.__init__(self, persist_directory)

    async def run(self, inp: VectorUpsertInput) -> VectorUpsertResult:
        client = self._client()

        def _upsert() -> int:
            col = client.get_or_create_collection(inp.collection)
            kwargs: dict[str, Any] = {
                "ids": inp.ids,
                "embeddings": inp.embeddings,
            }
            if inp.documents is not None:
                kwargs["documents"] = inp.documents
            if inp.metadatas is not None:
                kwargs["metadatas"] = inp.metadatas
            col.upsert(**kwargs)
            return len(inp.ids)

        count = await asyncio.to_thread(_upsert)
        return VectorUpsertResult(upserted_count=count, collection=inp.collection)


class VectorQueryBlock(_ChromaBase, Block[VectorQueryInput, VectorQueryResult]):
    """ChromaDB 컬렉션에서 유사 벡터를 검색하는 블록.

    Args:
        persist_directory: ChromaDB 데이터 저장 경로. None이면 인메모리(EphemeralClient).

    Example:
        ```python
        block = VectorQueryBlock(persist_directory="./chroma_db")
        result = await block.run(VectorQueryInput(
            query_embeddings=[[0.1, 0.2, ...]],
            top_k=3,
        ))
        for ids, docs, dists in zip(result.ids, result.documents, result.distances):
            for id_, doc, dist in zip(ids, docs, dists):
                print(f"{id_}: {doc!r} (distance={dist:.4f})")
        ```
    """

    input_model = VectorQueryInput
    output_model = VectorQueryResult

    def __init__(self, persist_directory: str | None = None) -> None:
        _ChromaBase.__init__(self, persist_directory)

    async def run(self, inp: VectorQueryInput) -> VectorQueryResult:
        client = self._client()

        def _query() -> dict[str, Any]:
            col = client.get_or_create_collection(inp.collection)
            kwargs: dict[str, Any] = {
                "query_embeddings": inp.query_embeddings,
                "n_results": inp.top_k,
                "include": ["documents", "distances"],
            }
            if inp.where is not None:
                kwargs["where"] = inp.where
            return col.query(**kwargs)  # type: ignore[no-any-return]

        raw = await asyncio.to_thread(_query)
        return VectorQueryResult(
            ids=raw.get("ids", []),
            distances=raw.get("distances", []),
            documents=raw.get("documents", []),
            collection=inp.collection,
        )
