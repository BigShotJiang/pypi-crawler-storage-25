"""git 서브프로세스 실행 콜러블 — 블록들에서 DI 주입용."""

from __future__ import annotations

import asyncio
import shutil
from collections.abc import Awaitable, Callable

GitRunner = Callable[[list[str]], Awaitable[tuple[int, str, str]]]


async def default_git_runner(args: list[str]) -> tuple[int, str, str]:
    """기본 git 바이너리 호출. 못 찾으면 RuntimeError."""
    binary = shutil.which("git")
    if binary is None:
        raise RuntimeError("git 바이너리를 찾을 수 없습니다.")
    proc = await asyncio.create_subprocess_exec(
        binary,
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_b, stderr_b = await proc.communicate()
    return (
        proc.returncode if proc.returncode is not None else -1,
        stdout_b.decode(errors="replace"),
        stderr_b.decode(errors="replace"),
    )
