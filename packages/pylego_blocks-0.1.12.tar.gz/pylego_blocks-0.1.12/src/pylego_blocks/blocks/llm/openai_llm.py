"""OpenAiLlmBlock — BaseLlmBlock 어댑터 (OpenAI Chat Completions API).

기존 OpenAiBlock 을 위임하여 LlmInput/LlmResult 계약으로 통합한다.
"""

from __future__ import annotations

from pylego_blocks.blocks.llm.base import BaseLlmBlock, LlmInput, LlmResult
from pylego_blocks.blocks.llm.openai import OpenAiBlock, OpenAiInput


class OpenAiLlmBlock(BaseLlmBlock):
    """OpenAI Chat Completions 백엔드 LLM 어댑터.

    Args:
        api_key: OpenAI API 키. 미설정 시 OPENAI_API_KEY 환경변수 사용.
        base_url: 커스텀 API 엔드포인트 (Azure, 로컬 호환 API 등).

    Example:
        ```python
        block = OpenAiLlmBlock()
        result = await block.run(LlmInput(prompt="Hello", max_tokens=128))
        print(result.content)
        ```
    """

    backend_name = "openai"
    _DEFAULT_MODEL = "gpt-4o"

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self._delegate = OpenAiBlock(api_key=api_key, base_url=base_url)

    async def run(self, inp: LlmInput) -> LlmResult:
        result = await self._delegate.run(
            OpenAiInput(
                model=inp.model or self._DEFAULT_MODEL,
                messages=[{"role": "user", "content": inp.prompt}],
                system=inp.system,
                max_tokens=inp.max_tokens,
                temperature=inp.temperature,
            )
        )
        return LlmResult(
            content=result.content,
            model=result.model,
            input_tokens=result.prompt_tokens,
            output_tokens=result.completion_tokens,
        )
