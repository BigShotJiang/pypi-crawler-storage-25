"""AnthropicLlmBlock — BaseLlmBlock 어댑터 (Anthropic Claude API).

기존 AnthropicBlock 을 위임하여 LlmInput/LlmResult 계약으로 통합한다.
"""

from __future__ import annotations

from pylego_blocks.blocks.llm.anthropic import AnthropicBlock, AnthropicInput
from pylego_blocks.blocks.llm.base import BaseLlmBlock, LlmInput, LlmResult


class AnthropicLlmBlock(BaseLlmBlock):
    """Anthropic Claude 백엔드 LLM 어댑터.

    Args:
        api_key: Anthropic API 키. 미설정 시 ANTHROPIC_API_KEY 환경변수 사용.

    Example:
        ```python
        block = AnthropicLlmBlock()
        result = await block.run(LlmInput(prompt="안녕하세요", max_tokens=256))
        print(result.content)
        ```
    """

    backend_name = "anthropic"
    _DEFAULT_MODEL = "claude-opus-4-5"

    def __init__(self, api_key: str | None = None) -> None:
        self._delegate = AnthropicBlock(api_key=api_key)

    async def run(self, inp: LlmInput) -> LlmResult:
        result = await self._delegate.run(
            AnthropicInput(
                model=inp.model or self._DEFAULT_MODEL,
                messages=[{"role": "user", "content": inp.prompt}],
                system=inp.system,
                max_tokens=inp.max_tokens,
                temperature=inp.temperature,
            )
        )
        return LlmResult(
            content=result.content,
            model=result.model,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
        )
