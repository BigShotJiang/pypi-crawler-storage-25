"""OllamaBlock — Ollama 로컬 LLM API 블록.

Ollama HTTP API (/api/generate) 를 httpx 로 호출한다.
pylego[ollama] 설치 필요: `pip install pylego[ollama]`
"""

from __future__ import annotations

from typing import Any

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


class OllamaInput(Stud):
    """Ollama generate API 입력 계약."""

    model: str
    prompt: str
    system: str | None = None
    base_url: str = "http://localhost:11434"
    temperature: float | None = None
    num_predict: int | None = None


class OllamaResult(Stud):
    """Ollama generate API 결과 계약."""

    response: str
    model: str
    done: bool
    prompt_eval_count: int | None = None
    eval_count: int | None = None


class OllamaBlock(Block[OllamaInput, OllamaResult]):
    """Ollama 로컬 LLM HTTP API 블록.

    Ollama 서버(`http://localhost:11434`)를 통해 로컬 LLM 을 호출한다.
    `stream=False` 모드로 완성된 응답 전체를 반환한다.

    Example:
        ```python
        block = OllamaBlock()
        result = await block.run(OllamaInput(
            model="llama3.2",
            prompt="파이썬으로 Hello World 를 출력하는 코드를 작성해줘.",
        ))
        print(result.response)
        ```
    """

    input_model = OllamaInput
    output_model = OllamaResult

    async def run(self, inp: OllamaInput) -> OllamaResult:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx 가 설치되어 있지 않습니다. `pip install pylego[ollama]`"
            ) from exc

        payload: dict[str, Any] = {
            "model": inp.model,
            "prompt": inp.prompt,
            "stream": False,
        }
        if inp.system is not None:
            payload["system"] = inp.system

        options: dict[str, Any] = {}
        if inp.temperature is not None:
            options["temperature"] = inp.temperature
        if inp.num_predict is not None:
            options["num_predict"] = inp.num_predict
        if options:
            payload["options"] = options

        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(
                f"{inp.base_url}/api/generate",
                json=payload,
            )
            resp.raise_for_status()
            data: dict[str, Any] = resp.json()

        return OllamaResult(
            response=str(data.get("response", "")),
            model=str(data.get("model", inp.model)),
            done=bool(data.get("done", True)),
            prompt_eval_count=data.get("prompt_eval_count"),
            eval_count=data.get("eval_count"),
        )
