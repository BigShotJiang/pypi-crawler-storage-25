"""BaseLlmBlock — 통합 LLM 추상화 계층.

모든 LLM 어댑터가 공유하는 LlmInput/LlmResult Stud 계약과
백엔드 등록 레지스트리를 제공한다.
"""

from __future__ import annotations

from typing import ClassVar

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud

_LLM_REGISTRY: dict[str, type[BaseLlmBlock]] = {}


class LlmInput(Stud):
    """통합 LLM 입력 계약."""

    prompt: str
    system: str | None = None
    model: str | None = None
    max_tokens: int = 1024
    temperature: float = 1.0


class LlmResult(Stud):
    """통합 LLM 결과 계약."""

    content: str
    model: str
    input_tokens: int
    output_tokens: int


class BaseLlmBlock(Block[LlmInput, LlmResult]):
    """모든 LLM 어댑터의 추상 기반 클래스.

    서브클래스는 ``backend_name`` 클래스 속성을 선언하면
    ``_LLM_REGISTRY`` 에 자동 등록된다.
    """

    input_model = LlmInput
    output_model = LlmResult

    backend_name: ClassVar[str] = ""

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        name = cls.__dict__.get("backend_name", "")
        if name:
            _LLM_REGISTRY[name] = cls

    async def run(self, inp: LlmInput) -> LlmResult:
        raise NotImplementedError(f"{type(self).__name__}.run() 가 구현되지 않았습니다.")
