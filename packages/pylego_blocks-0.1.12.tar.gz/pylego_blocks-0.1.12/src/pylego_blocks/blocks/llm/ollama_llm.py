"""OllamaLlmBlock — BaseLlmBlock 어댑터 (Ollama 로컬 LLM API).

기존 OllamaBlock 을 위임하여 LlmInput/LlmResult 계약으로 통합한다.
"""

from __future__ import annotations

from pylego_blocks.blocks.llm.base import BaseLlmBlock, LlmInput, LlmResult
from pylego_blocks.blocks.llm.ollama import OllamaBlock, OllamaInput


class OllamaLlmBlock(BaseLlmBlock):
    """Ollama 로컬 LLM 백엔드 어댑터.

    Args:
        base_url: Ollama 서버 URL. 기본값: ``http://localhost:11434``.

    Example:
        ```python
        block = OllamaLlmBlock()
        result = await block.run(LlmInput(
            prompt="안녕하세요",
            model="llama3.2",
        ))
        print(result.content)
        ```
    """

    backend_name = "ollama"
    _DEFAULT_MODEL = "llama3.2"

    def __init__(self, base_url: str = "http://localhost:11434") -> None:
        self._delegate = OllamaBlock()
        self._base_url = base_url

    async def run(self, inp: LlmInput) -> LlmResult:
        result = await self._delegate.run(
            OllamaInput(
                model=inp.model or self._DEFAULT_MODEL,
                prompt=inp.prompt,
                system=inp.system,
                base_url=self._base_url,
                temperature=inp.temperature,
            )
        )
        return LlmResult(
            content=result.response,
            model=result.model,
            input_tokens=result.prompt_eval_count or 0,
            output_tokens=result.eval_count or 0,
        )
