"""LlmRouter — 환경변수 기반 LLM 백엔드 동적 라우팅.

PYLEGO_LLM_BACKEND 환경변수 또는 생성자 인수만 바꾸면
파이프라인 코드 변경 없이 LLM 백엔드를 전환할 수 있다.
"""

from __future__ import annotations

import os

from pylego_blocks.blocks.llm import anthropic_llm  # noqa: F401 — 레지스트리 등록
from pylego_blocks.blocks.llm import ollama_llm  # noqa: F401 — 레지스트리 등록
from pylego_blocks.blocks.llm import openai_llm  # noqa: F401 — 레지스트리 등록
from pylego_blocks.blocks.llm.base import BaseLlmBlock, LlmInput, LlmResult, _LLM_REGISTRY
from pylego_blocks.core.block import Block


class LlmRouter(Block[LlmInput, LlmResult]):
    """환경변수 기반 LLM 백엔드 라우터.

    ``backend`` 를 명시하거나 ``PYLEGO_LLM_BACKEND`` 환경변수로 백엔드를 선택한다.
    ``PYLEGO_LLM_MODEL`` 환경변수로 기본 모델을 지정할 수 있다.

    Args:
        backend: LLM 백엔드 이름 (``"anthropic"``, ``"openai"``, ``"ollama"``).
                 미설정 시 PYLEGO_LLM_BACKEND 환경변수 사용.

    Example:
        ```python
        import os
        os.environ["PYLEGO_LLM_BACKEND"] = "anthropic"

        router = LlmRouter()
        result = await router.run(LlmInput(prompt="안녕하세요"))

        # 명시적 백엔드
        router = LlmRouter(backend="openai")
        result = await router.run(LlmInput(prompt="Hello"))
        ```
    """

    input_model = LlmInput
    output_model = LlmResult

    def __init__(self, backend: str | None = None) -> None:
        self._explicit_backend = backend
        self._cache: dict[str, BaseLlmBlock] = {}

    async def run(self, inp: LlmInput) -> LlmResult:
        backend = self._explicit_backend or os.getenv("PYLEGO_LLM_BACKEND")
        if not backend:
            raise ValueError(
                "LLM 백엔드가 지정되지 않았습니다. "
                "LlmRouter(backend='anthropic') 또는 "
                "PYLEGO_LLM_BACKEND 환경변수를 설정하세요."
            )

        if backend not in _LLM_REGISTRY:
            supported = ", ".join(sorted(_LLM_REGISTRY.keys()))
            raise ValueError(
                f"지원하지 않는 LLM 백엔드: {backend!r}. 지원 목록: {supported}"
            )

        if backend not in self._cache:
            self._cache[backend] = _LLM_REGISTRY[backend]()

        block = self._cache[backend]

        env_model = os.getenv("PYLEGO_LLM_MODEL")
        if inp.model is None and env_model:
            inp = inp.model_copy(update={"model": env_model})

        return await block.run(inp)
