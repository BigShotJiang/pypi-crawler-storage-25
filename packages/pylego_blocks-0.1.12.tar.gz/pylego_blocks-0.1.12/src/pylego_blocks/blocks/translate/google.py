"""GoogleTranslateBlock — Google Cloud Translation API v2(Basic) 번역 블록.

설치:
    pip install pylego[google-translate]

기본 사용:
    block = GoogleTranslateBlock(api_key="YOUR_API_KEY")
    result = await block.run(GoogleTranslateInput(text="안녕하세요", target="en"))
    print(result.translated_text)  # "Hello"

환경변수:
    PYLEGO_GOOGLE_API_KEY  — api_key 미지정 시 fallback
"""

from __future__ import annotations

import os
from typing import Any
from urllib.parse import urlencode

from pylego_blocks.blocks.http import HttpBlock
from pylego_blocks.core.stud import Stud

_TRANSLATE_URL = "https://translation.googleapis.com/language/translate/v2"


class GoogleTranslateInput(Stud):
    """Google Cloud Translation API 요청 Stud.

    Attributes:
        text: 번역할 텍스트.
        target: 번역 대상 언어 코드 (예: ``"en"``, ``"ko"``).
        source: 원본 언어 코드. None 이면 API 가 자동 감지한다.
    """

    text: str
    target: str
    source: str | None = None


class GoogleTranslateResult(Stud):
    """Google Cloud Translation API 응답 Stud.

    Attributes:
        translated_text: 번역된 텍스트.
        detected_source: 자동 감지된 원본 언어 코드 (source 미지정 시 포함).
    """

    translated_text: str
    detected_source: str | None = None


class GoogleTranslateBlock(HttpBlock[GoogleTranslateInput, GoogleTranslateResult]):
    """Google Cloud Translation API v2(Basic) 를 통해 텍스트를 번역하는 블록.

    Args:
        api_key: Google Cloud API 키.
                 None 이면 ``PYLEGO_GOOGLE_API_KEY`` 환경변수 사용.

    Raises:
        ValueError: api_key 와 환경변수 모두 없을 때.
        ImportError: httpx 가 설치되어 있지 않을 때 (``pip install pylego[google-translate]``).
        httpx.HTTPStatusError: 4xx / 5xx 응답일 때.
    """

    input_model = GoogleTranslateInput
    output_model = GoogleTranslateResult
    _extra = "pylego[google-translate]"

    def __init__(self, api_key: str | None = None) -> None:
        resolved = api_key or os.environ.get("PYLEGO_GOOGLE_API_KEY")
        if not resolved:
            raise ValueError(
                "api_key 또는 PYLEGO_GOOGLE_API_KEY 환경변수가 필요합니다."
            )
        self._api_key = resolved

    def _build_request(
        self, inp: GoogleTranslateInput
    ) -> tuple[str, str, dict[str, Any]]:
        params = urlencode({"key": self._api_key})
        url = f"{_TRANSLATE_URL}?{params}"
        body: dict[str, Any] = {
            "q": inp.text,
            "target": inp.target,
            "format": "text",
        }
        if inp.source is not None:
            body["source"] = inp.source
        return "POST", url, body

    def _parse_response(self, data: dict[str, Any]) -> GoogleTranslateResult:
        translation: dict[str, Any] = data["data"]["translations"][0]
        return GoogleTranslateResult(
            translated_text=translation["translatedText"],
            detected_source=translation.get("detectedSourceLanguage"),
        )
