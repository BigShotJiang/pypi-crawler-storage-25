"""HttpRequestBlock — 범용 REST/HTTP 요청 블록.

httpx 기반으로 GET/POST/PUT/PATCH/DELETE 등 모든 HTTP 메서드를 지원한다.
헤더·쿼리 파라미터·JSON 바디·폼 데이터·타임아웃을 Stud 계약으로 표현한다.
"""

from __future__ import annotations

from typing import Any

from pylego_blocks.blocks.http_base import BaseHttpBlock
from pylego_blocks.core.stud import Stud


class HttpRequestInput(Stud):
    """HTTP 요청 입력 계약."""

    method: str = "GET"
    url: str
    headers: dict[str, str] = {}
    params: dict[str, Any] = {}
    cookies: dict[str, str] = {}
    body: dict[str, Any] | list[Any] | None = None
    form: dict[str, str] | None = None
    timeout: float = 30.0
    follow_redirects: bool = True
    raise_for_status: bool = False


class HttpRequestResult(Stud):
    """HTTP 응답 결과 계약."""

    status_code: int
    headers: dict[str, str]
    text: str
    json_data: dict[str, Any] | list[Any] | None = None
    ok: bool


class HttpRequestBlock(BaseHttpBlock[HttpRequestInput, HttpRequestResult]):
    """범용 HTTP 요청 블록.

    Args:
        timeout: 기본 타임아웃 (초). HttpRequestInput.timeout 으로 오버라이드 가능.
        default_headers: 모든 요청에 포함되는 기본 헤더 (예: Authorization).
        follow_redirects: 기본 리다이렉트 추적 여부.

    Example:
        ```python
        block = HttpRequestBlock(default_headers={"Authorization": "Bearer token"})
        result = await block.run(HttpRequestInput(
            method="POST",
            url="https://api.example.com/data",
            body={"key": "value"},
        ))
        print(result.status_code, result.json_data)
        ```
    """

    input_model = HttpRequestInput
    output_model = HttpRequestResult

    async def run(self, inp: HttpRequestInput) -> HttpRequestResult:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx 가 설치되어 있지 않습니다. `pip install pylego[http]`"
            ) from exc

        merged_headers = self._merge_headers(inp.headers)
        async with httpx.AsyncClient(
            follow_redirects=inp.follow_redirects,
            timeout=inp.timeout,
            cookies=inp.cookies if inp.cookies else None,
        ) as client:
            resp = await client.request(
                method=inp.method.upper(),
                url=inp.url,
                headers=merged_headers if merged_headers else None,
                params=inp.params if inp.params else None,
                json=inp.body,
                data=inp.form,
            )

        if inp.raise_for_status:
            resp.raise_for_status()

        json_data: dict[str, Any] | list[Any] | None = None
        try:
            json_data = resp.json()
        except Exception:
            pass

        return HttpRequestResult(
            status_code=resp.status_code,
            headers=dict(resp.headers),
            text=resp.text,
            json_data=json_data,
            ok=resp.status_code < 400,
        )
