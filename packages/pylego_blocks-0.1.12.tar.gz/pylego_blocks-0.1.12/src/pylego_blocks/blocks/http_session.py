"""HttpSessionUnit — HTTP 세션(쿠키·토큰) 취득 유닛.

로그인 요청으로 세션 쿠키 또는 Bearer 토큰을 취득하고,
선택적으로 verify_url 을 probe 해 세션 유효성을 검증한다.

취득한 HttpSession 은 HttpRequestInput.headers / cookies 에 주입하여 사용한다.

Example:
    ```python
    from pylego_blocks import HttpSessionUnit, HttpSessionInput, HttpSession, UnitPipeline
    from pylego_blocks import HttpRequestBlock, HttpRequestInput

    pipeline = UnitPipeline([HttpSessionUnit()], result_unit=SessionResult())
    result = pipeline.run_sync(HttpSessionInput(
        login_url="https://api.example.com/login",
        credentials={"username": "user", "password": "pass"},
        token_field="access_token",
        verify_url="https://api.example.com/me",
    ))
    session: HttpSession = result.result

    # 이후 요청에 세션 주입
    resp = await HttpRequestBlock().run(HttpRequestInput(
        url="https://api.example.com/data",
        headers=session.headers,
        cookies=session.cookies,
    ))
    ```
"""

from __future__ import annotations

from typing import Any

from pylego_blocks.core.stud import Stud
from pylego_blocks.unit import Unit


class HttpSessionInput(Stud):
    """세션 취득 입력 계약."""

    login_url: str
    credentials: dict[str, Any]
    method: str = "POST"
    token_field: str | None = None
    token_header: str = "Authorization"
    token_prefix: str = "Bearer"
    verify_url: str | None = None
    extra_headers: dict[str, str] = {}
    timeout: float = 30.0


class HttpSession(Stud):
    """취득된 세션 계약.

    headers 와 cookies 를 HttpRequestInput 에 그대로 주입한다.
    """

    cookies: dict[str, str] = {}
    headers: dict[str, str] = {}
    raw: dict[str, Any] | list[Any] | None = None


class HttpSessionUnit(Unit[HttpSessionInput]):
    """로그인 → 세션 취득 → 검증 유닛.

    validate: 자격증명·URL 존재 여부 확인
    run:      로그인 요청 → 쿠키 + 토큰 헤더 추출
    verify:   verify_url probe 로 세션 유효성 확인
    """

    name = "HttpSessionUnit"
    input_model = HttpSessionInput

    async def validate(self, inp: HttpSessionInput) -> None:
        if not inp.login_url:
            raise ValueError("login_url이 비어 있습니다")
        if not inp.credentials:
            raise ValueError("credentials가 비어 있습니다")

    async def run(self, inp: HttpSessionInput) -> HttpSession:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx 가 설치되어 있지 않습니다. `pip install pylego[http]`"
            ) from exc

        async with httpx.AsyncClient(
            follow_redirects=True,
            timeout=inp.timeout,
        ) as client:
            resp = await client.request(
                method=inp.method.upper(),
                url=inp.login_url,
                headers=inp.extra_headers if inp.extra_headers else None,
                json=inp.credentials,
            )
            resp.raise_for_status()

            cookies = dict(resp.cookies)
            headers: dict[str, str] = {}

            raw: dict[str, Any] | list[Any] | None = None
            try:
                raw = resp.json()
            except Exception:
                pass

            if inp.token_field and isinstance(raw, dict):
                token = raw.get(inp.token_field)
                if token:
                    prefix = f"{inp.token_prefix} " if inp.token_prefix else ""
                    headers[inp.token_header] = f"{prefix}{token}"

        return HttpSession(cookies=cookies, headers=headers, raw=raw)

    async def verify(self, inp: HttpSessionInput, result: HttpSession) -> None:
        if not inp.verify_url:
            return

        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx 가 설치되어 있지 않습니다. `pip install pylego[http]`"
            ) from exc

        async with httpx.AsyncClient(
            follow_redirects=True,
            timeout=inp.timeout,
            cookies=result.cookies if result.cookies else None,
        ) as client:
            probe = await client.get(
                inp.verify_url,
                headers=result.headers if result.headers else None,
            )

        if probe.status_code >= 400:
            raise ValueError(
                f"세션 검증 실패: {inp.verify_url} → {probe.status_code}"
            )
