"""`python -m pylego` 진입점."""

from __future__ import annotations


def main() -> int:
    from pylego_blocks.cli import main as cli_main

    return cli_main()


if __name__ == "__main__":
    raise SystemExit(main())
