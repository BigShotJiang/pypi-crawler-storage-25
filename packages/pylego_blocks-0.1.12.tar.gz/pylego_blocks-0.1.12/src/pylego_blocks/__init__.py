"""pylego_blocks — composable block-based Python component architecture framework.

Install : pip install pylego-blocks
Import  : from pylego_blocks import Block, Stud, Assembly
"""
from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from pylego_blocks.blocks.http_base import BaseHttpBlock
from pylego_blocks.blocks.http_request import HttpRequestBlock, HttpRequestInput, HttpRequestResult
from pylego_blocks.blocks.http_session import HttpSession, HttpSessionInput, HttpSessionUnit
from pylego_blocks.blocks.db.duckdb import DuckDbBlock
from pylego_blocks.blocks.db.db_to_excel import DbToExcelInput, DbToExcelResult, DbToExcelUnit
from pylego_blocks.blocks.db.transactional import (
    TransactionalInput,
    TransactionalQueryBlock,
    TransactionalResult,
)
from pylego_blocks.blocks.db.mysql import MySqlBlock
from pylego_blocks.blocks.db.mysql_pool import PooledMySqlBlock
from pylego_blocks.blocks.db.sqlite import SqliteBlock
from pylego_blocks.blocks.file.excel import (
    ExcelReadBlock,
    ExcelReadInput,
    ExcelReadResult,
    ExcelWriteBlock,
    ExcelWriteInput,
    ExcelWriteResult,
)
from pylego_blocks.blocks.file.pdf import (
    PdfReadBlock,
    PdfReadInput,
    PdfReadResult,
    PdfWriteBlock,
    PdfWriteInput,
    PdfWriteResult,
)
from pylego_blocks.blocks.notification.discord import DiscordBlock, DiscordInput, DiscordResult
from pylego_blocks.blocks.notification.gmail import GmailBlock, GmailInput, GmailResult
from pylego_blocks.blocks.notification.slack import SlackBlock, SlackInput, SlackResult
from pylego_blocks.blocks.notification.telegram import TelegramBlock, TelegramInput, TelegramResult
from pylego_blocks.blocks.search.duckduckgo import DuckDuckGoSearchBlock, DuckDuckGoSearchInput
from pylego_blocks.blocks.search.google import (
    GoogleSearchBlock,
    GoogleSearchInput,
    GoogleSearchResult,
    SearchItem,
)
from pylego_blocks.blocks.translate.google import (
    GoogleTranslateBlock,
    GoogleTranslateInput,
    GoogleTranslateResult,
)
from pylego_blocks.blocks.llm.anthropic import AnthropicBlock, AnthropicInput, AnthropicResult
from pylego_blocks.blocks.llm.openai import OpenAiBlock, OpenAiInput, OpenAiResult
from pylego_blocks.blocks.llm.ollama import OllamaBlock, OllamaInput, OllamaResult
from pylego_blocks.blocks.llm.base import BaseLlmBlock, LlmInput, LlmResult
from pylego_blocks.blocks.llm.anthropic_llm import AnthropicLlmBlock
from pylego_blocks.blocks.llm.openai_llm import OpenAiLlmBlock
from pylego_blocks.blocks.llm.ollama_llm import OllamaLlmBlock
from pylego_blocks.blocks.llm.router import LlmRouter
from pylego_blocks.blocks.file.csv import (
    CsvReadBlock,
    CsvReadInput,
    CsvReadResult,
    CsvWriteBlock,
    CsvWriteInput,
    CsvWriteResult,
)
from pylego_blocks.blocks.template import TemplateBlock, TemplateInput, TemplateResult
from pylego_blocks.blocks.cache.redis_cache import CacheInput, CacheResult, RedisCacheBlock
from pylego_blocks.blocks.subprocess_block import SubprocessBlock, SubprocessInput, SubprocessResult
from pylego_blocks.blocks.llm.embedding import EmbeddingBlock, EmbeddingInput, EmbeddingResult
from pylego_blocks.blocks.text.chunk import ChunkTextBlock, ChunkTextInput, ChunkTextResult
from pylego_blocks.blocks.vector.chromadb_store import (
    VectorQueryBlock,
    VectorQueryInput,
    VectorQueryResult,
    VectorUpsertBlock,
    VectorUpsertInput,
    VectorUpsertResult,
)
from pylego_blocks.core import (
    AggregationStrategy,
    Assembly,
    AssemblyValidator,
    CompatibilityError,
    CompatibilityResult,
    SemanticCompatibilityError,
    check_chain,
    check_connection,
    BudgetExceededError,
    CallableBlock,
    ExecutionBudget,
    AsyncRuntime,
    Block,
    BlockBuilder,
    CausalFactor,
    EnvironmentContext,
    HealthDiff,
    PipelineHealth,
    VersionContext,
    build_health_summary,
    ConfidenceWeighted,
    ConsensusError,
    ConsensusPolicy,
    MajorityVote,
    MultiPerspectiveBlock,
    UnanimousRequired,
    BlockEvent,
    BlockRetryEvent,
    BlockStat,
    Branch,
    Checkpoint,
    CircuitBreakerBlock,
    CircuitBreakerStateEvent,
    CircuitOpenError,
    CollectingEventBus,
    DeadLetterQueue,
    EventBus,
    FallbackBlock,
    FanOut,
    FileCheckpoint,
    FileStore,
    Gathered,
    InMemoryStore,
    IncompatibleSnapError,
    LoggingEventBus,
    MemoryCheckpoint,
    NestedEventBus,
    NoopEventBus,
    OtelEventBus,
    ProcessRuntime,
    Queue,
    RedisDeadLetterQueue,
    RedisQueue,
    RedisWorkerPool,
    RetryBlock,
    RetryPolicy,
    AbortVerificationError,
    MaxRepeatedErrorError,
    SemanticRetryBlock,
    SignalAggregator,
    SignalScore,
    Store,
    StoreBlock,
    StreamBlock,
    Stud,
    SyncRuntime,
    TapBlock,
    TimeoutBlock,
    WorkerPool,
    build_stats,
    configure_otel_from_env,
    make_queue,
    observe,
    to_dot,
    to_html,
    to_mermaid,
    wrap,
)
from pylego_blocks.compat import PYLEGO_EXTRAS_MAP, is_available, requires
from pylego_blocks.scheduler import GlobalSchedulerPolicy, JobStatus, Scheduler, SchedulerPolicy, run_once
from pylego_blocks.registry import BlockInfo, BlockRegistry, BlockRuntimeStat, RegistryPolicy, default_registry, register
from pylego_blocks.unit import (
    ConfigBlock,
    ResultUnit,
    SemanticRetryPolicy,
    Unit,
    UnitPipeline,
    UnitResult,
    run_unit_main,
    unit_schema,
)

try:
    __version__: str = version("pylego-blocks")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"


def docs_path() -> Path:
    """Return the path to the bundled AGENT.md documentation file."""
    return Path(__file__).parent / "AGENT.md"


__all__ = [
    "AggregationStrategy",
    "Assembly",
    "BaseHttpBlock",
    "HttpRequestBlock",
    "HttpRequestInput",
    "HttpRequestResult",
    "HttpSession",
    "HttpSessionInput",
    "HttpSessionUnit",
    "DiscordBlock",
    "DuckDbBlock",
    "ExcelReadBlock",
    "ExcelReadInput",
    "ExcelReadResult",
    "ExcelWriteBlock",
    "ExcelWriteInput",
    "ExcelWriteResult",
    "MySqlBlock",
    "PooledMySqlBlock",
    "DbToExcelInput",
    "DbToExcelResult",
    "DbToExcelUnit",
    "TransactionalInput",
    "TransactionalQueryBlock",
    "TransactionalResult",
    "PdfReadBlock",
    "PdfReadInput",
    "PdfReadResult",
    "PdfWriteBlock",
    "PdfWriteInput",
    "PdfWriteResult",
    "SqliteBlock",
    "DuckDuckGoSearchBlock",
    "DuckDuckGoSearchInput",
    "DiscordInput",
    "DiscordResult",
    "BudgetExceededError",
    "ExecutionBudget",
    "AsyncRuntime",
    "ConfidenceWeighted",
    "GmailBlock",
    "GmailInput",
    "GmailResult",
    "SlackBlock",
    "SlackInput",
    "SlackResult",
    "TelegramBlock",
    "TelegramInput",
    "TelegramResult",
    "GoogleSearchBlock",
    "GoogleSearchInput",
    "GoogleSearchResult",
    "SearchItem",
    "GoogleTranslateBlock",
    "GoogleTranslateInput",
    "GoogleTranslateResult",
    "ConsensusError",
    "ConsensusPolicy",
    "MajorityVote",
    "MultiPerspectiveBlock",
    "UnanimousRequired",
    "Block",
    "BlockBuilder",
    "CallableBlock",
    "BlockEvent",
    "BlockInfo",
    "BlockRegistry",
    "BlockRuntimeStat",
    "RegistryPolicy",
    "BlockRetryEvent",
    "BlockStat",
    "Branch",
    "Checkpoint",
    "CircuitBreakerBlock",
    "CircuitBreakerStateEvent",
    "CircuitOpenError",
    "CollectingEventBus",
    "DeadLetterQueue",
    "EventBus",
    "FallbackBlock",
    "FanOut",
    "FileCheckpoint",
    "FileStore",
    "Gathered",
    "InMemoryStore",
    "IncompatibleSnapError",
    "LoggingEventBus",
    "MemoryCheckpoint",
    "NestedEventBus",
    "NoopEventBus",
    "OtelEventBus",
    "ProcessRuntime",
    "Queue",
    "RedisDeadLetterQueue",
    "RedisQueue",
    "RedisWorkerPool",
    "RetryBlock",
    "RetryPolicy",
    "AbortVerificationError",
    "MaxRepeatedErrorError",
    "SemanticRetryBlock",
    "SignalAggregator",
    "SignalScore",
    "Store",
    "StoreBlock",
    "StreamBlock",
    "Stud",
    "SyncRuntime",
    "TapBlock",
    "TimeoutBlock",
    "WorkerPool",
    "ConfigBlock",
    "ResultUnit",
    "SemanticRetryPolicy",
    "Unit",
    "UnitPipeline",
    "UnitResult",
    "__version__",
    "CausalFactor",
    "EnvironmentContext",
    "HealthDiff",
    "PipelineHealth",
    "VersionContext",
    "build_health_summary",
    "build_stats",
    "configure_otel_from_env",
    # scheduler
    "GlobalSchedulerPolicy",
    "JobStatus",
    "Scheduler",
    "SchedulerPolicy",
    "run_once",
    # compat
    "AssemblyValidator",
    "CompatibilityError",
    "CompatibilityResult",
    "SemanticCompatibilityError",
    "check_chain",
    "check_connection",
    "is_available",
    "requires",
    "PYLEGO_EXTRAS_MAP",
    "default_registry",
    "docs_path",
    "make_queue",
    "observe",
    "register",
    "run_unit_main",
    "to_dot",
    "to_html",
    "to_mermaid",
    "unit_schema",
    "wrap",
    # LLM blocks
    "AnthropicBlock",
    "AnthropicInput",
    "AnthropicResult",
    "OpenAiBlock",
    "OpenAiInput",
    "OpenAiResult",
    "OllamaBlock",
    "OllamaInput",
    "OllamaResult",
    # LLM abstraction layer
    "BaseLlmBlock",
    "LlmInput",
    "LlmResult",
    "AnthropicLlmBlock",
    "OpenAiLlmBlock",
    "OllamaLlmBlock",
    "LlmRouter",
    # CSV blocks
    "CsvReadBlock",
    "CsvReadInput",
    "CsvReadResult",
    "CsvWriteBlock",
    "CsvWriteInput",
    "CsvWriteResult",
    # Template block
    "TemplateBlock",
    "TemplateInput",
    "TemplateResult",
    # Cache block
    "CacheInput",
    "CacheResult",
    "RedisCacheBlock",
    # Subprocess block
    "SubprocessBlock",
    "SubprocessInput",
    "SubprocessResult",
    # Embedding block
    "EmbeddingBlock",
    "EmbeddingInput",
    "EmbeddingResult",
    # Text chunk block
    "ChunkTextBlock",
    "ChunkTextInput",
    "ChunkTextResult",
    # Vector store blocks
    "VectorUpsertBlock",
    "VectorUpsertInput",
    "VectorUpsertResult",
    "VectorQueryBlock",
    "VectorQueryInput",
    "VectorQueryResult",
]
