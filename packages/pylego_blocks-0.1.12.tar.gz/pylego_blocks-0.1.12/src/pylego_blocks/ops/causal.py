"""pylego.ops.causal — 원인 분석 데이터 클래스.

CausalFactor / VersionContext / EnvironmentContext 는 여기에 정의된다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class EnvironmentContext:
    """코드 외 환경 변화 맥락 (설계 원칙 43).

    infra_changes    — 인프라 변경 기록 (e.g. "Redis 7.2 → 8.0 업그레이드").
    metric_snapshot  — 현재 외부 지표 스냅샷 {지표명: 값}.
    external_changes — 외부 의존성 변경 (e.g. "OpenAI API 버전 전환").
    baseline_metrics — 정상 상태 기준 지표 (metric_snapshot 대비용).
    """

    infra_changes: list[str] = field(default_factory=list)
    metric_snapshot: dict[str, float] = field(default_factory=dict)
    external_changes: list[str] = field(default_factory=list)
    baseline_metrics: dict[str, float] = field(default_factory=dict)

    def metric_anomalies(
        self, threshold_ratio: float = 1.5
    ) -> dict[str, tuple[float, float]]:
        """baseline 대비 threshold_ratio 배 이상 변화된 지표를 반환한다."""
        result: dict[str, tuple[float, float]] = {}
        for k, baseline in self.baseline_metrics.items():
            current = self.metric_snapshot.get(k)
            if current is None or baseline == 0.0:
                continue
            ratio = current / baseline
            if ratio >= threshold_ratio or ratio <= 1.0 / threshold_ratio:
                result[k] = (baseline, current)
        return result


@dataclass
class CausalFactor:
    """단일 원인 후보.

    source:
      "code"   — changed_blocks 에서 파생.
      "env"    — EnvironmentContext infra/external 에서 파생.
      "metric" — metric_snapshot 이상 지표에서 파생.
    """

    source: Literal["code", "env", "metric"]
    name: str
    confidence_score: float
    """원인 가능성 (0.0~1.0)."""
    description: str = ""
    # M113 — Causal Aggregator (설계 원칙 46)
    recurrence_count: int = 0
    """이전 diff 에서 동일 name 이 등장한 횟수 — aggregate_causes() 가 채운다."""
    # M121 — Probabilistic Causal Graph (설계 원칙 52)
    correlation: float = 0.0
    """이 요인이 등장한 diff 중 다른 요인과 co-occurrence 한 비율 (0.0~1.0)."""
    residual_weight: float = 0.0
    """window 밖 이력의 잔류 가중치 — aggregate_causes() 가 채운다."""
    # M129 — Causal Feedback API (설계 원칙 58)
    feedback_delta: float = 0.0
    """누적 피드백 조정값 (양수: 상향, 음수: 하향). apply_feedback() 이 갱신한다."""
    feedback_source: str | None = None
    """마지막 피드백 출처. 'human' | 'ai' | None."""

    @property
    def adjusted_confidence(self) -> float:
        """피드백이 반영된 신뢰도. 0.0~1.0 범위로 클램핑된다."""
        return max(0.0, min(1.0, self.confidence_score + self.feedback_delta))


@dataclass
class VersionContext:
    """배포 버전 메타데이터 — HealthDiff 인과 진단에 사용."""

    version: str
    deployed_at: str | None = None
    changed_blocks: list[str] = field(default_factory=list)
    notes: str | None = None
    # M109 — 환경 맥락 (코드 외 원인 후보)
    env_context: EnvironmentContext | None = None


__all__ = [
    "CausalFactor",
    "EnvironmentContext",
    "VersionContext",
]
