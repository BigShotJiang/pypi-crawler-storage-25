"""pylego.ops.health — PipelineHealth + build_health_summary."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from pylego_blocks.core.events import (
    BlockCompletedEvent,
    BlockEvent,
    BlockFailedEvent,
    BlockRetryEvent,
    BlockStartedEvent,
    CircuitBreakerStateEvent,
)
from pylego_blocks.core.visualize import BlockStat, build_stats
from pylego_blocks.ops.causal import CausalFactor, VersionContext
from pylego_blocks.ops.diff import HealthDiff

if TYPE_CHECKING:
    from pylego_blocks.core.events import CollectingEventBus


_ERROR_TYPE_RECOMMENDATION: dict[str, str] = {
    "TimeoutError": "TimeoutBlock 설정 또는 timeout_sec 조정 검토",
    "ValidationError": "입력 Stud 필드 검증 강화 또는 @field_validator 추가 검토",
    "ConnectionError": "RetryBlock 또는 FallbackBlock 추가 검토",
    "OSError": "RetryBlock 또는 FallbackBlock 추가 검토",
    "CircuitOpenError": "CircuitBreakerBlock 파라미터 조정 검토",
}


def _recommendation_for(error_type: str | None) -> str:
    if error_type is None:
        return "FallbackBlock 추가 또는 오류 로그 확인"
    return _ERROR_TYPE_RECOMMENDATION.get(error_type, "FallbackBlock 추가 또는 오류 로그 확인")


@dataclass
class PipelineHealth:
    """파이프라인 전체 건강 상태 요약."""

    overall: Literal["ok", "degraded", "critical"]
    total_blocks: int
    error_blocks: list[str]
    slowest_block: str | None
    slowest_elapsed_sec: float | None
    avg_elapsed_sec: float | None
    error_details: dict[str, BlockFailedEvent] | None = None
    sub_health: dict[str, PipelineHealth] | None = None
    block_elapsed: dict[str, float] | None = None
    version_context: VersionContext | None = None

    def diff(self, previous: PipelineHealth) -> HealthDiff:
        """이전 실행 대비 시맨틱 차이를 계산한다."""
        prev_errors = set(previous.error_blocks)
        curr_errors = set(self.error_blocks)

        new_failures = sorted(curr_errors - prev_errors)
        recovered = sorted(prev_errors - curr_errors)

        slower: dict[str, tuple[float, float]] = {}
        faster: dict[str, tuple[float, float]] = {}
        if self.block_elapsed and previous.block_elapsed:
            for name, curr_sec in self.block_elapsed.items():
                prev_sec = previous.block_elapsed.get(name)
                if prev_sec is None:
                    continue
                if curr_sec > prev_sec * 1.2:
                    slower[name] = (prev_sec, curr_sec)
                elif curr_sec < prev_sec * 0.8:
                    faster[name] = (prev_sec, curr_sec)

        error_type_changes: dict[str, tuple[str | None, str | None]] = {}
        curr_details = self.error_details or {}
        prev_details = previous.error_details or {}
        all_names = set(curr_details) | set(prev_details)
        for name in all_names:
            curr_type = curr_details[name].error_type if name in curr_details else None
            prev_type = prev_details[name].error_type if name in prev_details else None
            if curr_type != prev_type:
                error_type_changes[name] = (prev_type, curr_type)

        if new_failures:
            severity: Literal["ok", "minor", "major", "critical"] = "critical"
        elif error_type_changes or any(
            curr >= prev * 1.5 for prev, curr in slower.values()
        ):
            severity = "major"
        elif slower:
            severity = "minor"
        else:
            severity = "ok"

        critical_changes: list[str] = []
        for name in new_failures:
            if len(critical_changes) >= 5:
                break
            critical_changes.append(f"[CRITICAL] 신규 실패: {name}")
        for name, (prev_t, curr_t) in error_type_changes.items():
            if len(critical_changes) >= 5:
                break
            critical_changes.append(
                f"[MAJOR] 오류 변화: {name} {prev_t or '없음'} → {curr_t or '없음'}"
            )
        for name, (prev_sec, curr_sec) in slower.items():
            if len(critical_changes) >= 5:
                break
            if curr_sec >= prev_sec * 1.5:
                critical_changes.append(
                    f"[MAJOR] 급격한 지연: {name} ({prev_sec:.2f}s → {curr_sec:.2f}s)"
                )
        for name, (prev_sec, curr_sec) in slower.items():
            if len(critical_changes) >= 5:
                break
            if curr_sec < prev_sec * 1.5:
                critical_changes.append(
                    f"[MINOR] 느려짐: {name} ({prev_sec:.2f}s → {curr_sec:.2f}s)"
                )
        for name in recovered:
            if len(critical_changes) >= 5:
                break
            critical_changes.append(f"[OK] 복구됨: {name}")

        causal_factors: list[CausalFactor] = []
        if self.version_context is not None:
            vc = self.version_context

            for block in vc.changed_blocks:
                if block in self.error_blocks:
                    causal_factors.append(
                        CausalFactor(
                            source="code",
                            name=block,
                            confidence_score=0.7,
                            description=f"버전 {vc.version}에서 변경됨",
                        )
                    )

            if vc.env_context is not None:
                ec = vc.env_context
                for change in ec.infra_changes + ec.external_changes:
                    causal_factors.append(
                        CausalFactor(
                            source="env",
                            name=change,
                            confidence_score=0.5,
                            description="환경 변경 — 코드 외 원인 후보",
                        )
                    )
                for metric, (baseline, current) in ec.metric_anomalies().items():
                    causal_factors.append(
                        CausalFactor(
                            source="metric",
                            name=metric,
                            confidence_score=0.6,
                            description=f"기준 {baseline:.2f} → 현재 {current:.2f}",
                        )
                    )

            causal_factors.sort(key=lambda f: f.confidence_score, reverse=True)

        return HealthDiff(
            new_failures=new_failures,
            recovered=recovered,
            slower_blocks=slower,
            faster_blocks=faster,
            error_type_changes=error_type_changes,
            severity=severity,
            critical_changes=critical_changes,
            causal_factors=causal_factors,
        )

    def to_ai_summary(
        self,
        *,
        include_payload: bool = False,
        max_payload_chars: int = 200,
        diff: HealthDiff | None = None,
    ) -> str:
        """AI가 읽을 수 있는 자연어 진단 요약을 반환한다."""
        lines: list[str] = []

        status_label = {"ok": "정상", "degraded": "부분 장애", "critical": "위험"}.get(
            self.overall, self.overall
        )
        lines.append(
            f"전체 상태: {status_label} ({self.total_blocks}개 블록 중"
            f" {len(self.error_blocks)}개 실패)"
        )

        if self.error_blocks:
            lines.append(f"실패 블록: {', '.join(self.error_blocks)}")
            if self.error_details:
                for name in self.error_blocks:
                    ev = self.error_details.get(name)
                    if ev is None:
                        continue
                    type_prefix = f"[{ev.error_type}] " if ev.error_type else ""
                    msg = f"  - {name}: {type_prefix}{ev.error}"
                    if ev.caused_by is not None:
                        msg += f" (caused_by: {ev.caused_by.block_name})"
                    lines.append(msg)
                    if include_payload and ev.input_sample is not None:
                        sample = ev.input_sample[:max_payload_chars]
                        lines.append(f"    입력 샘플: {sample}")
                    lines.append(f"    권장 조치: {_recommendation_for(ev.error_type)}")

        if self.slowest_block is not None:
            sec = f"{self.slowest_elapsed_sec:.2f}s" if self.slowest_elapsed_sec is not None else "?"
            lines.append(f"가장 느린 블록: {self.slowest_block} ({sec})")

        if self.overall == "ok":
            lines.append("권장 조치: 없음")
        elif self.overall == "degraded":
            lines.append("권장 조치: 실패 블록에 FallbackBlock 또는 RetryBlock 추가 검토")
        else:
            lines.append("권장 조치: TimeoutBlock 또는 FallbackBlock 추가 검토")

        if self.sub_health:
            lines.append("서브 파이프라인 요약:")
            for ns, sh in self.sub_health.items():
                sh_label = {"ok": "정상", "degraded": "부분 장애", "critical": "위험"}.get(
                    sh.overall, sh.overall
                )
                lines.append(f"  [{ns}] {sh_label} — 실패: {sh.error_blocks or '없음'}")

        if diff is not None:
            sev_label = {
                "ok": "정상", "minor": "경미", "major": "주의", "critical": "위험"
            }.get(diff.severity, diff.severity)
            lines.append(f"[이전 대비 변화] 심각도: {sev_label}")
            if diff.critical_changes:
                for change in diff.critical_changes:
                    lines.append(f"  {change}")
            else:
                lines.append("  변화 없음")
            for name, (bef, aft) in diff.faster_blocks.items():
                lines.append(f"  빨라짐: {name} ({bef:.2f}s → {aft:.2f}s)")

        if self.version_context is not None:
            vc = self.version_context
            lines.append(f"최근 배포: {vc.version}")
            if vc.notes:
                lines.append(f"메모: {vc.notes}")

        if diff is not None and diff.causal_factors:
            if diff.primary_cause is not None:
                pc = diff.primary_cause
                recur_note = f", 반복 등장 {pc.recurrence_count}회" if pc.recurrence_count > 0 else ""
                feedback_note = f"→{pc.adjusted_confidence:.2f}" if pc.feedback_delta != 0.0 else ""
                score_display = f"{pc.confidence_score:.2f}{feedback_note}"
                lines.append(
                    f"[최유력 원인] [{pc.source}/{score_display}] {pc.name}"
                    + (f" — {pc.description}" if pc.description else "")
                    + recur_note
                )
            # M129 — adjusted_confidence 기준 내림차순 재정렬
            sorted_factors = sorted(
                diff.causal_factors,
                key=lambda f: f.adjusted_confidence,
                reverse=True,
            )
            lines.append("[인과 후보 목록] (높은 것이 유력)")
            for factor in sorted_factors:
                feedback_note = ""
                if factor.feedback_delta != 0.0:
                    feedback_note = f" [피드백 반영: {factor.feedback_delta:+.2f}]"
                score_str = f"{factor.confidence_score:.2f}"
                lines.append(
                    f"  [{factor.source}/{score_str}] {factor.name}"
                    + (f" — {factor.description}" if factor.description else "")
                    + feedback_note
                )
            lines.append("  ※ 목록에 없는 블록 간 상호작용(Side Effect)도 확인하세요.")
        elif self.version_context is not None:
            vc = self.version_context
            hint_blocks = [b for b in vc.changed_blocks if b in self.error_blocks]
            if hint_blocks:
                lines.append(
                    f"버전 {vc.version} 변경 블록이 후보 원인 중 하나입니다"
                    f" (다른 요인도 확인하세요): {', '.join(hint_blocks)}"
                )

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """JSON 직렬화 가능한 dict를 반환한다."""
        result: dict[str, Any] = {
            "overall": self.overall,
            "total_blocks": self.total_blocks,
            "error_blocks": self.error_blocks,
            "slowest_block": self.slowest_block,
            "slowest_elapsed_sec": self.slowest_elapsed_sec,
            "avg_elapsed_sec": self.avg_elapsed_sec,
        }
        if self.error_details is not None:
            result["error_details"] = {
                name: {
                    "block_name": ev.block_name,
                    "error": str(ev.error),
                    "elapsed_sec": ev.elapsed_sec,
                    "caused_by": ev.caused_by.block_name if ev.caused_by is not None else None,
                    "input_sample": ev.input_sample,
                    "error_type": ev.error_type,
                }
                for name, ev in self.error_details.items()
            }
        else:
            result["error_details"] = None
        result["sub_health"] = (
            {ns: sh.to_dict() for ns, sh in self.sub_health.items()}
            if self.sub_health is not None
            else None
        )
        return result


def _strip_ns_from_event(event: BlockEvent, new_name: str) -> BlockEvent:
    """block_name 을 new_name 으로 교체한 새 이벤트를 반환한다."""
    if isinstance(event, BlockStartedEvent):
        return BlockStartedEvent(
            block_name=new_name, input=event.input, timestamp=event.timestamp
        )
    if isinstance(event, BlockCompletedEvent):
        return BlockCompletedEvent(
            block_name=new_name,
            output=event.output,
            elapsed_sec=event.elapsed_sec,
            timestamp=event.timestamp,
        )
    if isinstance(event, BlockFailedEvent):
        return BlockFailedEvent(
            block_name=new_name,
            error=event.error,
            elapsed_sec=event.elapsed_sec,
            timestamp=event.timestamp,
            caused_by=event.caused_by,
        )
    if isinstance(event, BlockRetryEvent):
        return BlockRetryEvent(
            block_name=new_name,
            attempt=event.attempt,
            max_attempts=event.max_attempts,
            error=event.error,
            delay_sec=event.delay_sec,
            timestamp=event.timestamp,
        )
    if isinstance(event, CircuitBreakerStateEvent):
        return CircuitBreakerStateEvent(
            block_name=new_name,
            previous_state=event.previous_state,
            new_state=event.new_state,
            timestamp=event.timestamp,
        )
    return event  # pragma: no cover


def build_health_summary(
    events: list[BlockEvent],
    bus: CollectingEventBus | None = None,
    *,
    version_context: VersionContext | None = None,
    _depth: int = 0,
) -> PipelineHealth:
    """CollectingEventBus 이벤트로부터 파이프라인 헬스 요약을 생성한다.

    판정 기준:
      - error_blocks 없음 → "ok"
      - error_blocks < 전체 절반 → "degraded"
      - error_blocks >= 전체 절반 → "critical"

    중첩 이벤트(namespace/BlockName 형식)는 sub_health 로 분리된다.
    최대 3레벨 중첩을 지원한다.
    """
    top_events: list[BlockEvent] = []
    ns_map: dict[str, list[BlockEvent]] = {}
    for e in events:
        if "/" in e.block_name:
            ns, rest = e.block_name.split("/", 1)
            ns_map.setdefault(ns, []).append(_strip_ns_from_event(e, rest))
        else:
            top_events.append(e)

    sub_health: dict[str, PipelineHealth] | None = None
    if _depth < 3 and ns_map:
        sub_health = {
            ns: build_health_summary(ns_evs, _depth=_depth + 1)
            for ns, ns_evs in ns_map.items()
        }

    stats = build_stats(top_events)
    if not stats:
        return PipelineHealth(
            overall="ok",
            total_blocks=0,
            error_blocks=[],
            slowest_block=None,
            slowest_elapsed_sec=None,
            avg_elapsed_sec=None,
            error_details=None,
            sub_health=sub_health,
            version_context=version_context if _depth == 0 else None,
        )

    error_blocks = [s.name for s in stats.values() if s.status == "error"]
    elapsed_vals = [s.elapsed_sec for s in stats.values() if s.elapsed_sec is not None]

    slowest: str | None = None
    slowest_sec: float | None = None
    if elapsed_vals:
        max_sec = max(elapsed_vals)
        slowest_sec = max_sec
        slowest = next(
            s.name for s in stats.values() if s.elapsed_sec == max_sec
        )
    avg_sec: float | None = (
        sum(elapsed_vals) / len(elapsed_vals) if elapsed_vals else None
    )

    total = len(stats)
    if not error_blocks:
        overall: Literal["ok", "degraded", "critical"] = "ok"
    elif len(error_blocks) >= total // 2 + (total % 2):
        overall = "critical"
    else:
        overall = "degraded"

    error_details: dict[str, BlockFailedEvent] | None = None
    if bus is not None:
        error_details = {
            e.block_name: e for e in bus.failed_events()
            if "/" not in e.block_name
        }

    block_elapsed = {
        name: s.elapsed_sec
        for name, s in stats.items()
        if s.elapsed_sec is not None
    }

    return PipelineHealth(
        overall=overall,
        total_blocks=total,
        error_blocks=error_blocks,
        slowest_block=slowest,
        slowest_elapsed_sec=slowest_sec,
        avg_elapsed_sec=avg_sec,
        error_details=error_details,
        sub_health=sub_health,
        block_elapsed=block_elapsed or None,
        version_context=version_context if _depth == 0 else None,
    )


__all__ = [
    "BlockStat",
    "PipelineHealth",
    "build_health_summary",
    "build_stats",
]
