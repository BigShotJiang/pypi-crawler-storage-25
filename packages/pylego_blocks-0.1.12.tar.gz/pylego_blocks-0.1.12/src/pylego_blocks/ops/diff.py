"""pylego.ops.diff — HealthDiff: 두 PipelineHealth 간 시맨틱 차이."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal

from pylego_blocks.ops.causal import CausalFactor

if TYPE_CHECKING:
    from pylego_blocks.ops.health import PipelineHealth


@dataclass
class HealthDiff:
    """두 PipelineHealth 사이의 시맨틱 차이."""

    new_failures: list[str] = field(default_factory=list)
    recovered: list[str] = field(default_factory=list)
    slower_blocks: dict[str, tuple[float, float]] = field(default_factory=dict)
    faster_blocks: dict[str, tuple[float, float]] = field(default_factory=dict)
    error_type_changes: dict[str, tuple[str | None, str | None]] = field(default_factory=dict)
    severity: Literal["ok", "minor", "major", "critical"] = "ok"
    critical_changes: list[str] = field(default_factory=list)
    # M109 — 다요인 원인 후보 목록
    causal_factors: list[CausalFactor] = field(default_factory=list)
    # M113 — 최유력 원인 (aggregate_causes() 호출 후 설정)
    primary_cause: CausalFactor | None = None
    # M129 — Causal Feedback API (설계 원칙 58)
    feedback_log: list[dict[str, Any]] = field(default_factory=list)
    """피드백 감사 이력. 각 항목: {timestamp, factor_name, delta, source, reason}."""

    _SOURCE_WEIGHTS: dict[str, float] = field(
        default_factory=lambda: {"code": 1.2, "metric": 1.0, "env": 0.8},
        repr=False,
        compare=False,
    )

    def apply_feedback(
        self,
        factor_name: str,
        delta: float,
        source: str = "human",
        reason: str = "",
    ) -> None:
        """인과 요인에 피드백을 적용한다.

        Args:
            factor_name: 피드백 대상 요인 이름. 없으면 KeyError.
            delta: 신뢰도 조정값 (-1.0~1.0). 0.0이면 이력 미추가.
            source: 피드백 출처 ('human' | 'ai').
            reason: 피드백 사유 (선택).

        Raises:
            KeyError: factor_name 이 causal_factors 에 없을 때.
        """
        target = next((f for f in self.causal_factors if f.name == factor_name), None)
        if target is None:
            raise KeyError(f"'{factor_name}' 은 causal_factors 에 없습니다.")
        if delta == 0.0:
            return
        target.feedback_delta += delta
        target.feedback_source = source
        self.feedback_log.append(
            {
                "timestamp": time.time(),
                "factor_name": factor_name,
                "delta": delta,
                "source": source,
                "reason": reason,
            }
        )

    def aggregate_causes(
        self,
        history: list[HealthDiff] | None = None,
        recurrence_window: int = 0,
        top_k: int = 3,
        residual_decay_factor: float = 0.1,
        compute_correlation: bool = False,
    ) -> CausalFactor | None:
        """causal_factors 를 분석해 최유력 원인을 결정하고 primary_cause 에 저장한다.

        Args:
            history: 이전 diff 목록. recurrence_count 산출에 사용.
            recurrence_window: > 0 이면 최근 N개만 window로, 나머지는 residual로 처리.
            top_k: 후보 필터링 수. 상위 K개만 평가한다.
            residual_decay_factor: window 밖 이력 감쇠 계수.
            compute_correlation: True 이면 compute_correlations(history) 를 먼저 호출한다.

        Returns:
            최유력 CausalFactor (primary_cause 에도 저장). 후보가 없으면 None.
        """
        if not self.causal_factors:
            self.primary_cause = None
            return None

        hist = history or []

        if compute_correlation and hist:
            self.compute_correlations(hist)

        if recurrence_window > 0 and len(hist) > recurrence_window:
            window_hist = hist[-recurrence_window:]
            residual_hist = hist[:-recurrence_window]
        else:
            window_hist = hist
            residual_hist = []

        recurrence: dict[str, int] = {}
        for prev_diff in window_hist:
            for f in prev_diff.causal_factors:
                recurrence[f.name] = recurrence.get(f.name, 0) + 1

        residual_count: dict[str, int] = {}
        for prev_diff in residual_hist:
            for f in prev_diff.causal_factors:
                residual_count[f.name] = residual_count.get(f.name, 0) + 1

        if top_k < len(self.causal_factors):
            top_names = {
                f.name
                for f in sorted(
                    self.causal_factors,
                    key=lambda f: f.confidence_score,
                    reverse=True,
                )[:top_k]
            }
            candidates = [f for f in self.causal_factors if f.name in top_names]
        else:
            candidates = list(self.causal_factors)

        best_factor: CausalFactor | None = None
        best_score: float = -1.0

        for factor in candidates:
            count = recurrence.get(factor.name, 0)
            r_count = residual_count.get(factor.name, 0)
            adjusted = factor.confidence_score * min(2.0, 1.0 + 0.1 * count)
            r_weight = r_count * residual_decay_factor if residual_decay_factor > 0.0 else 0.0
            adjusted += r_weight
            weight = self._SOURCE_WEIGHTS.get(factor.source, 1.0)
            score = adjusted * weight

            if score > best_score or (
                score == best_score
                and count > (recurrence.get(best_factor.name, 0) if best_factor else 0)
            ):
                best_score = score
                best_factor = CausalFactor(
                    source=factor.source,
                    name=factor.name,
                    confidence_score=factor.confidence_score,
                    description=factor.description,
                    recurrence_count=count,
                    correlation=factor.correlation,
                    residual_weight=r_weight,
                )

        self.primary_cause = best_factor
        return best_factor

    def compute_correlations(self, history: list[HealthDiff]) -> None:
        """history 내 factor 간 co-occurrence 비율을 계산해 각 factor.correlation 을 갱신한다."""
        my_names = {f.name for f in self.causal_factors}
        for factor in self.causal_factors:
            appearances = 0
            co_occurrences = 0
            for diff in history:
                diff_names = {f.name for f in diff.causal_factors}
                if factor.name in diff_names:
                    appearances += 1
                    if diff_names & (my_names - {factor.name}):
                        co_occurrences += 1
            factor.correlation = co_occurrences / appearances if appearances > 0 else 0.0

    def to_causal_mermaid(self) -> str:
        """causal_factors 를 Mermaid flowchart 로 시각화한다.

        - 엣지 레이블: corr=X.XX
        - correlation < 0.3: 점선 엣지 (-. label .->)
        - correlation >= 0.7: 굵은 엣지 (== label ==>)
        - residual_weight > 0: 노드 레이블에 (잔류) 표시
        """
        if not self.causal_factors:
            return "flowchart LR\n  empty[인과 요인 없음]"

        factors = sorted(self.causal_factors, key=lambda f: f.confidence_score, reverse=True)
        lines = ["flowchart LR"]

        for i, f in enumerate(factors):
            label = f.name.replace('"', "'")
            if f.residual_weight > 0:
                label += " (잔류)"
            lines.append(f'  N{i}["{label}"]')

        for i in range(len(factors) - 1):
            src = f"N{i}"
            dst = f"N{i + 1}"
            corr = factors[i + 1].correlation
            edge_label = f"corr={corr:.2f}"
            if corr < 0.3:
                lines.append(f"  {src} -. {edge_label} .->{dst}")
            elif corr >= 0.7:
                lines.append(f"  {src} == {edge_label} ==>{dst}")
            else:
                lines.append(f"  {src} -->|{edge_label}| {dst}")

        return "\n".join(lines)


__all__ = ["HealthDiff"]
