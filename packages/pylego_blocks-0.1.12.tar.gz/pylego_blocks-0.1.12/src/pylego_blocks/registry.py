"""pylego.registry — Block 등록·이름 조회·메타데이터 검색·entry-points 디스커버리."""

from __future__ import annotations

import importlib.metadata
import math
import sys
import time
import warnings
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Literal

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud

if TYPE_CHECKING:
    from pylego_blocks.core.events import BlockEvent

_RECENT_WINDOW = 20


@dataclass
class RegistryPolicy:
    """BlockRegistry 통계 판단 정책.

    도메인 특성에 맞게 추세 민감도와 최소 샘플 기준을 조정한다.
    """

    min_samples: int = 5
    """UCB 신뢰도 패널티 기준 — total_runs < min_samples × 2 이면 confidence < 1.0."""

    trend_window: int = 20
    """추세 판정에 사용하는 rolling window 크기."""

    trend_worsening_threshold: float = 0.2
    """recent_fail - overall_fail 이 이 값 이상이면 degrading 판정 (절대 차이)."""

    trend_improvement_threshold: float = 0.1
    """overall_fail - recent_fail 이 이 값 이상이면 improving 판정 (절대 차이)."""

    # M107 — Risk-Adjusted Confidence (설계 원칙 41)
    error_severity_map: dict[str, float] = field(default_factory=dict)
    """오류 타입별 심각도 (0.0~1.0). 미등록 타입은 default_error_severity 적용."""

    default_error_severity: float = 1.0
    """error_severity_map 에 없는 오류 타입의 기본 심각도."""

    # M111 — Priority-weighted Severity (설계 원칙 44)
    block_priority_map: dict[str, float] = field(default_factory=dict)
    """블록명 → 비즈니스 중요도 (1.0=기본, 2.0=높음, 0.5=낮음).
    실질 위험도 = severity × priority."""

    cumulative_risk_threshold: float | None = None
    """None이면 비활성. priority_adjusted_risk 가 이 값 초과 시 on_risk_alert 호출."""

    # M115 — Dynamic Priority & Risk Decay (설계 원칙 47)
    risk_decay_half_life_sec: float = 0.0
    """0이면 감쇠 없음. > 0이면 마지막 실패 후 half-life 초 경과 시 decayed_risk 절반 감쇠."""

    priority_fn: Callable[[str], float] | None = None
    """동적 우선순위 공급자. None이면 block_priority_map 폴백."""

    # M119 — Criticality-aware Risk Decay (설계 원칙 50)
    decay_overrides: dict[str, float] = field(default_factory=dict)
    """블록별 개별 half-life (초). 미등록 블록은 risk_decay_half_life_sec 전역값 폴백."""

    oscillation_penalty: float = 2.0
    """oscillation_count > 0인 블록의 effective_half_life 배수 억제.
    effective_half_life = configured_half_life × oscillation_penalty^oscillation_count."""

    # M128 — Redemption Mechanism (설계 원칙 57)
    redemption_window: int = 0
    """N회 연속 성공 시 redemption 트리거. 0이면 비활성화 (하위 호환)."""

    redemption_rate: float = 0.5
    """redemption 1회당 weighted_failure_sum 경감 비율.
    weighted_failure_sum *= (1 - redemption_rate). 범위: 0.0~1.0."""

    @classmethod
    def development(cls) -> RegistryPolicy:
        """개발 환경용 프리셋 — 빠른 피드백, 낮은 패널티."""
        return cls(min_samples=3, risk_decay_half_life_sec=60.0, oscillation_penalty=1.0)

    @classmethod
    def production(cls) -> RegistryPolicy:
        """프로덕션 환경용 프리셋 — 신중한 신뢰도 축적, 긴 기억."""
        return cls(min_samples=10, risk_decay_half_life_sec=3600.0, oscillation_penalty=2.0)

    @classmethod
    def strict(cls) -> RegistryPolicy:
        """고위험 환경용 프리셋 — 강한 oscillation 패널티."""
        return cls(min_samples=10, risk_decay_half_life_sec=3600.0, oscillation_penalty=3.0)


@dataclass
class BlockRuntimeStat:
    """블록 런타임 실행 통계."""

    success_count: int = 0
    failure_count: int = 0
    avg_elapsed_sec: float = 0.0
    last_error: str | None = None
    recent_runs: deque[bool] = field(
        default_factory=lambda: deque(maxlen=_RECENT_WINDOW)
    )
    # M107 — 누적 심각도 가중 실패 합계
    weighted_failure_sum: float = 0.0
    # M111 — 누적 실질 위험도 합계 (severity × block_priority)
    priority_adjusted_risk: float = 0.0
    # M115/M119 — 시간 감쇠 관련 필드
    last_failure_at: float = 0.0
    """마지막 실패 시각 (time.monotonic() 기준). 0이면 실패 없음."""
    oscillation_count: int = 0
    """감쇠 후 동일 오류 재발 횟수 (oscillation 횟수)."""
    last_error_type: str | None = None
    """oscillation 판정용 직전 오류 타입."""
    # M128 — Redemption Mechanism (설계 원칙 57)
    consecutive_successes: int = 0
    """연속 성공 횟수. 실패 시 0으로 초기화. redemption_window 도달 시 redemption 트리거."""
    redemption_count: int = 0
    """갱생 발생 횟수 — 감사 이력 및 투명성."""
    # BlockRegistry 가 주입하는 정책·half-life 참조 — repr·compare 에서 제외
    _policy: RegistryPolicy = field(
        default_factory=RegistryPolicy, repr=False, compare=False
    )
    _half_life: float = field(default=0.0, repr=False, compare=False)
    """BlockRegistry 가 주입하는 실효 half-life (초). 0이면 감쇠 없음."""

    @property
    def total_runs(self) -> int:
        return self.success_count + self.failure_count

    @property
    def success_rate(self) -> float:
        total = self.total_runs
        return self.success_count / total if total > 0 else 0.0

    @property
    def recent_failure_rate(self) -> float:
        if not self.recent_runs:
            return 0.0
        return sum(1 for r in self.recent_runs if not r) / len(self.recent_runs)

    @property
    def confidence(self) -> float:
        """샘플 크기 기반 신뢰도 (0.0~1.0).

        total_runs 이 min_samples × 2 에 도달해야 1.0 이 된다.
        """
        min_s = self._policy.min_samples
        if min_s <= 0:
            return 1.0
        return min(1.0, self.total_runs / (min_s * 2))

    @property
    def trend(self) -> Literal["improving", "stable", "degrading"]:
        total = self.total_runs
        if total == 0 or not self.recent_runs:
            return "stable"
        overall_fail = self.failure_count / total
        recent_fail = self.recent_failure_rate
        min_s = self._policy.min_samples
        worsening = self._policy.trend_worsening_threshold
        improving = self._policy.trend_improvement_threshold
        if (
            len(self.recent_runs) >= min_s
            and recent_fail - overall_fail >= worsening
        ):
            return "degrading"
        if overall_fail - recent_fail >= improving:
            return "improving"
        return "stable"

    @property
    def is_degrading(self) -> bool:
        return self.trend == "degrading"

    @property
    def weighted_failure_rate(self) -> float:
        """심각도 가중 실패율 — weighted_failure_sum / total_runs."""
        total = self.total_runs
        if total == 0:
            return 0.0
        return min(1.0, self.weighted_failure_sum / total)

    @property
    def decayed_risk(self) -> float:
        """시간 감쇠 적용 후 실효 위험도.

        _half_life > 0이면 마지막 실패 이후 경과 시간에 따라 priority_adjusted_risk 가
        지수적으로 감쇠한다 (half-life 경과마다 절반).
        """
        if self._half_life <= 0.0 or self.last_failure_at <= 0.0:
            return self.priority_adjusted_risk
        elapsed = time.monotonic() - self.last_failure_at
        return self.priority_adjusted_risk * math.pow(0.5, elapsed / self._half_life)

    @property
    def risk_adjusted_confidence(self) -> float:
        """confidence × (1 - decayed_risk/total_runs) — 시간 감쇠 반영 신뢰도 (M111/M115/M119)."""
        total = self.total_runs
        if total == 0:
            return self.confidence
        rate = min(1.0, self.decayed_risk / total)
        return self.confidence * (1.0 - rate)

    @property
    def ucb_score(self) -> float:
        """위험 조정 신뢰도 기반 UCB 스코어: risk_adjusted_confidence × log1p(total_runs)."""
        return self.risk_adjusted_confidence * math.log1p(self.total_runs)


@dataclass
class BlockInfo:
    """블록 메타데이터."""

    name: str
    description: str
    tags: list[str]
    input_model: str
    output_model: str
    module: str
    runtime: BlockRuntimeStat | None = field(default=None)


class BlockRegistry:
    """블록 클래스를 이름으로 등록하고 조회·검색하는 레지스트리."""

    def __init__(self) -> None:
        self._blocks: dict[str, type[Block[Any, Any]]] = {}
        self._meta: dict[str, BlockInfo] = {}
        self._policy: RegistryPolicy = RegistryPolicy()
        self._risk_alert: Callable[[str, float], None] | None = None

    def set_risk_alert(self, callback: Callable[[str, float], None]) -> None:
        """cumulative_risk_threshold 초과 시 호출될 콜백을 등록한다."""
        self._risk_alert = callback

    def _effective_half_life(self, name: str) -> float:
        """블록의 실효 half-life 계산 (decay_overrides + oscillation_penalty 반영)."""
        base = self._policy.decay_overrides.get(name, self._policy.risk_decay_half_life_sec)
        if base <= 0.0:
            return 0.0
        info = self._meta.get(name)
        osc = info.runtime.oscillation_count if (info and info.runtime) else 0
        return base * (self._policy.oscillation_penalty ** osc)

    def set_policy(self, policy: RegistryPolicy) -> None:
        """레지스트리 전역 통계 정책을 설정한다.

        기존 블록 통계의 정책 참조도 즉시 갱신된다.
        """
        self._policy = policy
        for name, info in self._meta.items():
            if info.runtime is not None:
                info.runtime._policy = policy
                info.runtime._half_life = self._effective_half_life(name)

    def register(
        self,
        cls: type[Block[Any, Any]],
        *,
        tags: list[str] | None = None,
        description: str = "",
    ) -> type[Block[Any, Any]]:
        """블록 등록. 데코레이터로도 사용 가능."""
        if not description or not tags:
            warnings.warn(
                f"{cls.__name__}: description과 tags를 제공하면 AI 에이전트가 블록을 더 잘 발견할 수 있습니다"
                " (@register(description='...', tags=[...]))",
                UserWarning,
                stacklevel=3,
            )
        self._blocks[cls.__name__] = cls
        input_name = getattr(cls, "input_model", None)
        output_name = getattr(cls, "output_model", None)
        self._meta[cls.__name__] = BlockInfo(
            name=cls.__name__,
            description=description,
            tags=list(tags or []),
            input_model=input_name.__name__ if isinstance(input_name, type) else "",
            output_model=output_name.__name__ if isinstance(output_name, type) else "",
            module=cls.__module__,
        )
        return cls

    def get(self, name: str) -> type[Block[Any, Any]]:
        """이름으로 블록 조회. 없으면 KeyError."""
        return self._blocks[name]

    def describe(self, cls: type[Block[Any, Any]] | str) -> BlockInfo:
        """블록 메타데이터 반환. 없으면 KeyError."""
        name = cls if isinstance(cls, str) else cls.__name__
        return self._meta[name]

    def all_info(self) -> list[BlockInfo]:
        """등록된 모든 BlockInfo 반환 (이름 오름차순)."""
        return [self._meta[k] for k in sorted(self._meta)]

    def all(self) -> list[type[Block[Any, Any]]]:
        """등록된 모든 블록 반환 (이름 오름차순)."""
        return [self._blocks[k] for k in sorted(self._blocks)]

    def search(
        self,
        query: str,
        *,
        sort_by: Literal["success_rate", "latency", "smart"] | None = None,
    ) -> list[BlockInfo]:
        """이름·설명·태그에서 query를 포함하는 블록 목록 반환 (대소문자 무시).

        sort_by="success_rate" — 성공률 높은 순 정렬.
        sort_by="latency"      — 평균 지연 낮은 순 정렬.
        sort_by="smart"        — UCB 스코어 기반 정렬 (에코 챔버 방지).
        """
        q = query.lower()
        result: list[BlockInfo] = []
        for info in self._meta.values():
            if (
                q in info.name.lower()
                or q in info.description.lower()
                or any(q in t.lower() for t in info.tags)
            ):
                result.append(info)
        result.sort(key=lambda i: i.name)
        if sort_by == "success_rate":
            result.sort(
                key=lambda i: i.runtime.success_rate if i.runtime else 0.0,
                reverse=True,
            )
        elif sort_by == "latency":
            result.sort(
                key=lambda i: i.runtime.avg_elapsed_sec if i.runtime else float("inf"),
            )
        elif sort_by == "smart":
            result.sort(
                key=lambda i: i.runtime.ucb_score if i.runtime else 0.0,
                reverse=True,
            )
        return result

    def update_stat(
        self,
        block_name: str,
        *,
        success: bool,
        elapsed_sec: float,
        error: str | None = None,
        error_type: str | None = None,
        severity: float | None = None,
        priority: float | None = None,
    ) -> None:
        """블록 런타임 통계를 누적 갱신한다. 미등록 블록이면 무시.

        severity: 명시적 심각도(0.0~1.0). None이면 error_type → policy.error_severity_map 추론.
        priority: 명시적 비즈니스 중요도. None이면 policy.block_priority_map 에서 추론, 없으면 1.0.
        """
        if block_name not in self._meta:
            warnings.warn(
                f"update_stat: '{block_name}' 은 등록되지 않은 블록입니다. 통계가 무시됩니다.",
                UserWarning,
                stacklevel=2,
            )
            return
        info = self._meta[block_name]
        if info.runtime is None:
            info.runtime = BlockRuntimeStat(_policy=self._policy)
        stat = info.runtime
        total = stat.success_count + stat.failure_count
        stat.avg_elapsed_sec = (stat.avg_elapsed_sec * total + elapsed_sec) / (total + 1)
        if success:
            stat.success_count += 1
            # M128 — Redemption Mechanism (설계 원칙 57)
            stat.consecutive_successes += 1
            window = self._policy.redemption_window
            if window > 0 and stat.consecutive_successes >= window:
                rate = max(0.0, min(1.0, self._policy.redemption_rate))
                stat.weighted_failure_sum *= 1.0 - rate
                stat.consecutive_successes = 0
                stat.redemption_count += 1
        else:
            stat.consecutive_successes = 0
            stat.failure_count += 1
            if error is not None:
                stat.last_error = error
            # M107 — 심각도 가중 실패 누적
            resolved_severity: float
            if severity is not None:
                resolved_severity = severity
            elif error_type is not None:
                resolved_severity = self._policy.error_severity_map.get(
                    error_type, self._policy.default_error_severity
                )
            else:
                resolved_severity = self._policy.default_error_severity
            stat.weighted_failure_sum += resolved_severity
            # M111 — 우선순위 조정 실질 위험도 누적 (설계 원칙 44)
            # M115 — priority_fn 동적 우선순위 지원
            resolved_priority: float
            if priority is not None:
                resolved_priority = priority
            elif self._policy.priority_fn is not None:
                resolved_priority = self._policy.priority_fn(block_name)
            else:
                resolved_priority = self._policy.block_priority_map.get(block_name, 1.0)
            # M119 — oscillation 감지 (감쇠 후 동일 오류 재발)
            current_half_life = self._effective_half_life(block_name)
            if (
                stat.last_failure_at > 0.0
                and current_half_life > 0.0
                and error_type is not None
                and error_type == stat.last_error_type
            ):
                elapsed = time.monotonic() - stat.last_failure_at
                if elapsed >= current_half_life:
                    stat.oscillation_count += 1
            # 마지막 실패 시각·오류 타입 갱신
            stat.last_failure_at = time.monotonic()
            if error_type is not None:
                stat.last_error_type = error_type
            stat.priority_adjusted_risk += resolved_severity * resolved_priority
            # half-life 재계산 (oscillation_count 변동 반영)
            stat._half_life = self._effective_half_life(block_name)
            threshold = self._policy.cumulative_risk_threshold
            if (
                threshold is not None
                and stat.priority_adjusted_risk > threshold
                and self._risk_alert is not None
            ):
                self._risk_alert(block_name, stat.priority_adjusted_risk)
        stat.recent_runs.append(success)

    def ingest_events(self, events: list[BlockEvent]) -> None:
        """CollectingEventBus.events 를 소비해 등록된 블록의 통계를 자동 갱신한다."""
        from pylego_blocks.core.events import BlockCompletedEvent, BlockFailedEvent  # noqa: PLC0415

        for event in events:
            if isinstance(event, BlockCompletedEvent):
                self.update_stat(
                    event.block_name, success=True, elapsed_sec=event.elapsed_sec
                )
            elif isinstance(event, BlockFailedEvent):
                self.update_stat(
                    event.block_name,
                    success=False,
                    elapsed_sec=event.elapsed_sec,
                    error=str(event.error),
                    error_type=event.error_type,
                )

    def search_by_tag(self, *tags: str) -> list[BlockInfo]:
        """지정한 태그를 모두 포함하는 블록 목록 반환 (AND 조건, 대소문자 무시)."""
        lower_tags = [t.lower() for t in tags]
        result: list[BlockInfo] = []
        for info in self._meta.values():
            info_tags_lower = [t.lower() for t in info.tags]
            if all(t in info_tags_lower for t in lower_tags):
                result.append(info)
        return sorted(result, key=lambda i: i.name)

    def compatible_with(
        self, stud_type: type[Stud], *, subclass: bool = False
    ) -> list[BlockInfo]:
        """input_model이 stud_type과 일치하는 블록 목록 반환.

        subclass=True 이면 stud_type 의 서브클래스를 입력으로 받는 블록도 포함한다.
        """
        result: list[BlockInfo] = []
        for name, cls in self._blocks.items():
            input_model = getattr(cls, "input_model", None)
            if not isinstance(input_model, type):
                continue
            if subclass:
                if issubclass(input_model, stud_type):
                    result.append(self._meta[name])
            else:
                if input_model is stud_type:
                    result.append(self._meta[name])
        return sorted(result, key=lambda i: i.name)

    def load_entry_points(self, group: str = "pylego.blocks") -> None:
        """설치된 패키지의 entry-points 로 블록 일괄 로드."""
        eps = importlib.metadata.entry_points(group=group)
        for ep in eps:
            try:
                obj = ep.load()
            except Exception:
                continue
            if isinstance(obj, type) and issubclass(obj, Block):
                self.register(obj)

    def discover(self, group: str = "pylego.blocks") -> list[type[Block[Any, Any]]]:
        """설치된 entry-points에서 블록을 자동 수집하고 등록된 블록 목록을 반환."""
        before = set(self._blocks.keys())
        eps = importlib.metadata.entry_points(group=group)
        for ep in eps:
            try:
                obj = ep.load()
            except Exception as exc:
                print(
                    f"warning: pylego.blocks entry-point '{ep.name}' 로드 실패: {exc}",
                    file=sys.stderr,
                )
                continue
            if isinstance(obj, type) and issubclass(obj, Block):
                self.register(obj)
            else:
                print(
                    f"warning: pylego.blocks entry-point '{ep.name}'이 "
                    f"Block 서브클래스가 아닙니다: {obj!r}",
                    file=sys.stderr,
                )
        after = set(self._blocks.keys())
        newly_added = after - before
        return [self._blocks[k] for k in sorted(newly_added)]


default_registry: BlockRegistry = BlockRegistry()


def register(
    cls: type[Block[Any, Any]] | None = None,
    *,
    tags: list[str] | None = None,
    description: str = "",
) -> Any:
    """블록을 default_registry에 등록하는 데코레이터.

    인자 없이 ``@register`` 또는 인자와 함께 ``@register(tags=[...], description="...")``
    두 가지 형태로 사용 가능.
    """
    if cls is not None:
        return default_registry.register(cls, tags=tags, description=description)

    def decorator(c: type[Block[Any, Any]]) -> type[Block[Any, Any]]:
        return default_registry.register(c, tags=tags, description=description)

    return decorator
