"""Unit 계층 — 목적을 가진 블랙박스 + 3단계 생명주기.

Block 이 최소 단위라면 Unit 은 하나의 도메인 목적을 완성하는 블랙박스다.
Unit 은 Block·다른 Unit 을 내부에 포함할 수 있고, 외부에는 계약(Stud)만 노출한다.

생명주기:
    validate(inp)  → 사전 검증. 실패 시 예외.
    run(inp)       → 주 실행. 결과 반환.
    verify(inp, result) → 사후 검증. 실패 시 예외.

파이프라인:
    pipeline = UnitPipeline([UnitA(), UnitB()], result_unit=MyResult())
    result: UnitResult = await pipeline.run(inp)

독립 실행:
    # python -m mypackage '{"field": "value"}'
    # mypackage/__main__.py
    from pylego_blocks import run_unit_main
    from mypackage.units import MyUnit
    run_unit_main(MyUnit())
"""

from __future__ import annotations

import asyncio
import json
import sys
from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

from pylego_blocks.core.block import Block
from pylego_blocks.core.stud import Stud


# ─── SemanticRetryPolicy ─────────────────────────────────────────────────────

@dataclass
class SemanticRetryPolicy:
    """Unit.verify() 실패 시 적용할 재시도 정책.

    Args:
        max_attempts: 최초 시도 포함 총 시도 횟수 (기본 3).
        retry_on_verify_failure: False 이면 verify() 실패를 즉시 failure 로 처리한다.
    """

    max_attempts: int = field(default=3)
    retry_on_verify_failure: bool = field(default=True)

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts 는 1 이상이어야 합니다.")


# ─── UnitResult ───────────────────────────────────────────────────────────────

class UnitResult(Stud):
    """Unit 실행의 공통 출력. 성공·실패 모두 이 타입으로 전달된다."""

    status: Literal["success", "failure"]
    result: Any = None
    reason: str | None = None
    failed_at: str | None = None


# ─── Unit ─────────────────────────────────────────────────────────────────────

class Unit[T: Stud](ABC):
    """Unit 추상 베이스.

    구체 클래스는 반드시 ``input_model`` 클래스 속성과 ``run()`` 을 선언해야 한다.

    Example::

        class MyUnit(Unit[MyInput]):
            input_model = MyInput

            async def run(self, inp: MyInput) -> Any:
                return inp.value * 2
    """

    name: str = ""
    input_model: type[Stud] = Stud  # 구체 클래스에서 오버라이드
    retry_policy: SemanticRetryPolicy | None = None

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if getattr(cls, "__abstractmethods__", None):
            return
        if not cls.name:
            cls.name = cls.__name__
        if cls.input_model is Stud and cls.__name__ not in ("ResultUnit",):
            pass  # 런타임 체크는 execute() 에서 수행 — strict 요구 안 함

    async def validate(self, inp: T) -> None:
        """사전 검증. 예외를 raise 하면 failure 로 처리된다."""

    @abstractmethod
    async def run(self, inp: T) -> Any:
        """주 실행 로직. 반환값은 UnitResult.result 에 저장된다."""

    async def verify(self, inp: T, result: Any) -> None:
        """사후 검증. 예외를 raise 하면 failure 로 처리된다."""

    async def enrich(self, inp: T, result: Any, error: str) -> T:
        """verify() 실패 시 재시도를 위한 입력 생성.

        Args:
            inp: 직전 시도의 입력.
            result: 직전 시도의 출력.
            error: verify() 예외 메시지.

        Returns:
            다음 시도에 전달할 새 입력. 기본 구현은 inp 를 그대로 반환한다.
        """
        return inp

    async def execute(self, inp: Any) -> UnitResult:
        """프레임워크 진입점. 실패 전파·생명주기를 처리한다.

        Args:
            inp: ``T`` 또는 앞 Unit 의 ``UnitResult``.
        """
        # 앞 Unit 이 실패한 경우 그대로 전달 (스킵)
        if isinstance(inp, UnitResult) and inp.status == "failure":
            return inp

        # UnitResult(success) 이면 result 를 언팩
        from typing import cast as _cast

        actual: T = _cast(T, inp.result if isinstance(inp, UnitResult) else inp)

        try:
            await self.validate(actual)
        except Exception as exc:
            return UnitResult(
                status="failure",
                reason=f"validate: {exc}",
                failed_at=self.name,
            )

        policy = self.retry_policy
        max_attempts = (
            policy.max_attempts
            if policy is not None and policy.retry_on_verify_failure
            else 1
        )

        current_inp: T = actual
        last_result: Any = None
        last_exc: Exception = RuntimeError("unreachable")

        for attempt in range(max_attempts):
            if attempt > 0:
                current_inp = await self.enrich(current_inp, last_result, str(last_exc))

            try:
                last_result = await self.run(current_inp)
            except Exception as exc:
                return UnitResult(
                    status="failure",
                    reason=str(exc),
                    failed_at=self.name,
                )

            try:
                await self.verify(current_inp, last_result)
                return UnitResult(status="success", result=last_result)
            except Exception as exc:
                last_exc = exc

        return UnitResult(
            status="failure",
            reason=f"verify: {last_exc}",
            failed_at=self.name,
        )


# ─── ResultUnit ───────────────────────────────────────────────────────────────

class ResultUnit(ABC):
    """파이프라인 마지막을 담당하는 Unit.

    항상 실행되며 성공·실패를 모두 처리한다.

    Example::

        class MyResult(ResultUnit):
            async def on_success(self, result: Any) -> UnitResult:
                return UnitResult(status="success", result=result)

            async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
                return UnitResult(status="failure", reason=reason, failed_at=failed_at)
    """

    name: str = ""

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if not cls.name:
            cls.name = cls.__name__

    @abstractmethod
    async def on_success(self, result: Any) -> UnitResult:
        """파이프라인 성공 시 호출. 최종 UnitResult 를 반환한다."""

    @abstractmethod
    async def on_failure(self, reason: str | None, failed_at: str | None) -> UnitResult:
        """파이프라인 실패 시 호출. 최종 UnitResult 를 반환한다."""

    async def execute(self, inp: UnitResult) -> UnitResult:
        """성공·실패 분기 실행."""
        if inp.status == "success":
            return await self.on_success(inp.result)
        return await self.on_failure(inp.reason, inp.failed_at)


# ─── ConfigBlock ──────────────────────────────────────────────────────────────

class ConfigBlock[ConfigT: Stud](Block[Stud, ConfigT], ABC):
    """설정을 로드해 파이프라인에 주입하는 Block 베이스.

    ``input_model = Stud`` 로 고정되며 ``output_model`` 은 구체 클래스에서 선언.

    Example::

        class EnvConfig(Stud):
            api_key: str
            timeout: int = 30

        class EnvConfigBlock(ConfigBlock[EnvConfig]):
            output_model = EnvConfig

            async def load(self) -> EnvConfig:
                return EnvConfig(api_key=os.environ["API_KEY"])
    """

    input_model = Stud
    output_model: type[Stud] = Stud  # 구체 클래스에서 실제 ConfigT 로 오버라이드

    @abstractmethod
    async def load(self) -> ConfigT:
        """설정을 로드한다. 구체 클래스에서 구현."""

    async def run(self, inp: Stud) -> ConfigT:
        return await self.load()


# ─── UnitPipeline ─────────────────────────────────────────────────────────────

class UnitPipeline[T: Stud]:
    """Unit 들을 선형으로 실행하는 파이프라인.

    첫 Unit 은 ``T`` 타입 입력을 받고, 이후 Unit 들은 앞 Unit 의 ``UnitResult``
    를 받는다. 실패 발생 시 이후 Unit 들은 자동으로 스킵된다.
    ``ResultUnit`` 은 항상 마지막에 실행된다.

    Example::

        pipeline: UnitPipeline[MyInput] = UnitPipeline(
            [UnitA(), UnitB()],
            result_unit=MyResult(),
        )
        result = await pipeline.run(MyInput(value=1))
    """

    def __init__(
        self,
        units: Sequence[Unit[Any]],
        result_unit: ResultUnit,
    ) -> None:
        if not units:
            raise ValueError("UnitPipeline 은 최소 한 개의 Unit 이 필요합니다.")
        self._units: list[Unit[Any]] = list(units)
        self._result_unit = result_unit

    async def run(self, inp: T) -> UnitResult:
        """파이프라인을 실행한다."""
        current: Any = inp
        for unit in self._units:
            current = await unit.execute(current)
        return await self._result_unit.execute(current)

    def run_sync(self, inp: T) -> UnitResult:
        """동기 래퍼 — 이벤트 루프가 없는 환경에서 사용."""
        return asyncio.run(self.run(inp))


# ─── 독립 실행 헬퍼 ────────────────────────────────────────────────────────────

def unit_schema(unit: Unit[Any]) -> dict[str, Any]:
    """Unit 의 입력 JSON Schema 를 반환한다."""
    return unit.input_model.model_json_schema()


def run_unit_main(unit: Unit[Any], argv: list[str] | None = None) -> None:
    """Unit 을 독립 CLI 로 실행하는 진입점 헬퍼.

    사용::

        # mypackage/__main__.py
        from pylego_blocks import run_unit_main
        from mypackage.units import MyUnit

        run_unit_main(MyUnit())

    실행::

        python -m mypackage '{"field": "value"}'
        python -m mypackage --schema  # JSON Schema 출력
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog=f"python -m {unit.__class__.__module__}",
        description=f"Run {unit.name}",
    )
    parser.add_argument(
        "input",
        nargs="?",
        help="JSON input string",
    )
    parser.add_argument(
        "--schema",
        action="store_true",
        help="Print input JSON Schema and exit",
    )
    args = parser.parse_args(argv)

    if args.schema:
        print(json.dumps(unit_schema(unit), ensure_ascii=False, indent=2))
        return

    if args.input is None:
        parser.error("input JSON string is required")

    try:
        inp_dict = json.loads(args.input)
    except json.JSONDecodeError as exc:
        print(f"error: invalid JSON — {exc}", file=sys.stderr)
        sys.exit(1)

    try:
        inp = unit.input_model.model_validate(inp_dict)
    except Exception as exc:
        print(f"error: input validation failed — {exc}", file=sys.stderr)
        sys.exit(1)

    result = asyncio.run(unit.execute(inp))
    print(result.model_dump_json(indent=2))
