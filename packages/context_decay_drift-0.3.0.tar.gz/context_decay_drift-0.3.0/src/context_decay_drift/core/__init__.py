"""Core drift analysis engine."""
