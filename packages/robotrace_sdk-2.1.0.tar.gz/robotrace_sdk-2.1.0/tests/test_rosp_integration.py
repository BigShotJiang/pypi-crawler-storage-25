"""Tests for ROSP integration middleware — URN parsing, component registration,
stream normalization, and health event mapping."""

from __future__ import annotations

import json
import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from datetime import datetime, timezone

from robotrace.integrations.rosp import (
    parse_rosp_urn,
    _normalize_stream_data,
    _topic_to_stream,
    _topic_to_sensor_id,
    RoboTraceMiddleware,
)


# ---------------------------------------------------------------------------
# URN parsing
# ---------------------------------------------------------------------------

class TestParseROSPURN:
    def test_standard_urn(self):
        result = parse_rosp_urn("urn:rosp:robot:robotis:turtlebot3:waffle-001")
        assert result["entity_type"] == "robot"
        assert result["manufacturer"] == "robotis"
        assert result["model"] == "turtlebot3"
        assert result["serial"] == "waffle-001"
        assert result["device_id"] == "robotis-turtlebot3-waffle-001"

    def test_sensor_urn(self):
        result = parse_rosp_urn("urn:rosp:sensor:sick:tim781:s12345")
        assert result["entity_type"] == "sensor"
        assert result["device_id"] == "sick-tim781-s12345"

    def test_complex_serial(self):
        result = parse_rosp_urn("urn:rosp:robot:abb:irb1200:s4c45-1")
        assert result["serial"] == "s4c45-1"
        assert result["device_id"] == "abb-irb1200-s4c45-1"

    def test_invalid_urn_fallback(self):
        result = parse_rosp_urn("not-a-urn")
        assert result["device_id"] == "not-a-urn"
        assert result["entity_type"] == "unknown"

    def test_empty_string(self):
        result = parse_rosp_urn("")
        assert result["device_id"] == ""


# ---------------------------------------------------------------------------
# Stream data normalization
# ---------------------------------------------------------------------------

class TestNormalizeStreamData:
    def test_scalar_float(self):
        assert _normalize_stream_data(42.5) == {"value_float": 42.5}

    def test_scalar_int(self):
        assert _normalize_stream_data(10) == {"value_float": 10.0}

    def test_dict_with_value(self):
        assert _normalize_stream_data({"value": 3.14}) == {"value_float": 3.14}

    def test_dict_with_ranges(self):
        result = _normalize_stream_data({"ranges": [1.0, 2.0, 3.0], "angle_min": 0})
        assert result == {"value_array": [1.0, 2.0, 3.0]}

    def test_dict_with_values(self):
        result = _normalize_stream_data({"values": [0.1, 0.2]})
        assert result == {"value_array": [0.1, 0.2]}

    def test_complex_dict(self):
        data = {"x": 1.0, "y": 2.0, "z": 0.0, "qw": 1.0}
        result = _normalize_stream_data(data)
        assert "value_json" in result
        parsed = json.loads(result["value_json"])
        assert parsed["x"] == 1.0

    def test_list_of_floats(self):
        result = _normalize_stream_data([1.0, 2.0, 3.0])
        assert result == {"value_array": [1.0, 2.0, 3.0]}

    def test_list_of_dicts(self):
        result = _normalize_stream_data([{"a": 1}])
        assert "value_json" in result

    def test_string_data(self):
        result = _normalize_stream_data("hello")
        assert "value_json" in result


# ---------------------------------------------------------------------------
# Topic conversion
# ---------------------------------------------------------------------------

class TestTopicToStream:
    def test_sensor_topic(self):
        assert _topic_to_stream("/sensor/lidar/scan") == "sensors/lidar"

    def test_actuator_topic(self):
        assert _topic_to_stream("/actuator/base/cmd") == "actuators/base"

    def test_plain_topic(self):
        assert _topic_to_stream("/robot/pose") == "robot/pose"

    def test_no_leading_slash(self):
        assert _topic_to_stream("sensor/imu/data") == "sensors/imu"


class TestTopicToSensorId:
    def test_direct_match(self):
        sensor_map = {"/sensor/lidar/scan": "lidar-360"}
        assert _topic_to_sensor_id("/sensor/lidar/scan", sensor_map) == "lidar-360"

    def test_name_match(self):
        sensor_map = {"lidar": "lidar-360"}
        assert _topic_to_sensor_id("/sensor/lidar/scan", sensor_map) == "lidar-360"

    def test_no_match(self):
        assert _topic_to_sensor_id("/sensor/unknown", {}) is None


# ---------------------------------------------------------------------------
# Middleware — describe()
# ---------------------------------------------------------------------------

def _make_mock_card():
    """Create a mock RobotCard."""
    card = MagicMock()
    card.id = "urn:rosp:robot:robotis:turtlebot3:waffle-001"
    card.rosp_version = "0.1"
    card.identity = {"type": "mobile_robot", "manufacturer": "ROBOTIS", "model": "TurtleBot3"}
    card.sensors = [
        {"sensor_id": "lidar", "type": "lidar", "model": "LDS-01", "rate_hz": 5},
        {"sensor_id": "imu", "type": "imu", "model": "ICM-20948", "rate_hz": 100},
    ]
    card.actuators = [
        {"actuator_id": "base", "type": "wheel"},
    ]
    return card


def _make_mock_adapter(card=None):
    """Create a mock ROSP adapter."""
    adapter = AsyncMock()
    adapter.describe = AsyncMock(return_value=card or _make_mock_card())
    adapter.is_connected = True
    return adapter


def _make_mock_rt():
    """Create a mock RoboTrace client."""
    rt = MagicMock()
    rt.event = MagicMock()
    rt.component = MagicMock()
    rt.configure_stream = MagicMock()
    rt.log = MagicMock()
    rt.flush = MagicMock()
    return rt


@pytest.mark.asyncio
async def test_describe_registers_device():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    card = await mw.describe()

    # Device event should be fired
    rt.event.assert_called_once()
    call_args = rt.event.call_args
    assert call_args[0][0] == "rosp_device_registered"
    assert call_args[1]["data"]["device_id"] == "robotis-turtlebot3-waffle-001"
    assert call_args[1]["data"]["manufacturer"] == "ROBOTIS"


@pytest.mark.asyncio
async def test_describe_registers_components():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    await mw.describe()

    # 2 sensors + 1 actuator = 3 component() calls
    assert rt.component.call_count == 3
    component_ids = [c[0][0] for c in rt.component.call_args_list]
    assert "lidar" in component_ids
    assert "imu" in component_ids
    assert "base" in component_ids


@pytest.mark.asyncio
async def test_describe_configures_streams():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    await mw.describe()

    # 2 sensors = 2 configure_stream() calls
    assert rt.configure_stream.call_count == 2
    stream_names = [c[0][0] for c in rt.configure_stream.call_args_list]
    assert "sensors/lidar" in stream_names
    assert "sensors/imu" in stream_names


@pytest.mark.asyncio
async def test_describe_only_registers_once():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    await mw.describe()
    await mw.describe()

    # Should only register once
    assert rt.event.call_count == 1


@pytest.mark.asyncio
async def test_device_id_property():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    assert mw.device_id is None
    await mw.describe()
    assert mw.device_id == "robotis-turtlebot3-waffle-001"


# ---------------------------------------------------------------------------
# Middleware — health_check()
# ---------------------------------------------------------------------------

def _make_mock_health(robot_status="connected", latency=5.2):
    status = MagicMock()
    status.adapter_status = MagicMock()
    status.adapter_status.value = "healthy"
    status.robot_status = MagicMock()
    status.robot_status.value = robot_status
    status.latency_ms = latency
    status.uptime_seconds = 120.0
    return status


@pytest.mark.asyncio
async def test_health_check_logs_event():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    health = _make_mock_health()
    adapter.health_check = AsyncMock(return_value=health)
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    result = await mw.health_check()

    rt.event.assert_called_once()
    call_args = rt.event.call_args
    assert call_args[0][0] == "rosp_health_check"
    assert call_args[1]["data"]["robot_status"] == "connected"
    assert call_args[1]["severity"] == "info"


@pytest.mark.asyncio
async def test_health_check_estop_severity():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    health = _make_mock_health(robot_status="estop")
    adapter.health_check = AsyncMock(return_value=health)
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    await mw.health_check()

    call_args = rt.event.call_args
    assert call_args[1]["severity"] == "error"


@pytest.mark.asyncio
async def test_health_check_logs_latency():
    rt = _make_mock_rt()
    adapter = _make_mock_adapter()
    health = _make_mock_health(latency=12.5)
    adapter.health_check = AsyncMock(return_value=health)
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    await mw.health_check()

    # Should log latency as telemetry
    rt.log.assert_called_once()
    assert rt.log.call_args[0][0] == "health/latency_ms"
