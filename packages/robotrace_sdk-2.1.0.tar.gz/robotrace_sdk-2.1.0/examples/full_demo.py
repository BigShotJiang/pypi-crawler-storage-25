#!/usr/bin/env python3
"""Complete RoboTrace demo with ALL sensors, components, and annotated missions.

Subscribes to every TurtleBot3 Waffle sensor:
- LiDAR (/scan) - 360 degree laser scanner
- IMU (/imu) - acceleration + gyroscope
- Odometry (/odom) - position + velocity
- Camera (/camera/image_raw) - front camera
- Joint states (/joint_states) - wheel encoders

Registers components, configures streams, and logs expected vs actual positions.
"""
import time
import math
import threading
import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from sensor_msgs.msg import LaserScan as RosLaserScan
from sensor_msgs.msg import Imu as RosImu
from sensor_msgs.msg import Image as RosImage
from sensor_msgs.msg import JointState as RosJointState
from nav_msgs.msg import Odometry as RosOdometry
from geometry_msgs.msg import Twist

from robotrace import RoboTrace, Scalar, Pose3D, Vector3, Log
from robotrace import Image as RTImage, JointState as RTJointState
from robotrace.ros2 import from_laser_scan, from_imu, from_odometry
from robotrace.ros2 import from_odometry_twist, from_joint_state

# --- RoboTrace setup ---
rt = RoboTrace(
    host="http://localhost:8080",
    public_key="rt-pk-dev-default",
    secret_key="rt-sk-dev-default",
    device_id="turtlebot3-waffle-001",
    device_type="mobile_robot",
    manufacturer="ROBOTIS",
    model="TurtleBot3 Waffle",
    environment="simulation",
)

# --- Register components ---
print("Registering device components...")
rt.component("lidar-360", type="sensor", manufacturer="ROBOTIS", model="LDS-01")
rt.component("imu", type="sensor", manufacturer="ROBOTIS", model="ICM-20948")
rt.component("camera-front", type="sensor", manufacturer="Intel", model="RealSense R200")
rt.component("odometry", type="sensor")
rt.component("wheel-encoders", type="sensor")

# --- Configure streams ---
rt.configure_stream("sensors/lidar", {
    "display_name": "LiDAR 360",
    "data_type": "laser_scan",
    "rate_hz": 5,
})
rt.configure_stream("robot/pose", {
    "display_name": "Odometry",
    "data_type": "pose3d",
    "rate_hz": 10,
})
rt.configure_stream("sensors/imu/accel", {
    "display_name": "IMU Acceleration",
    "data_type": "vector3",
    "rate_hz": 10,
})
rt.configure_stream("sensors/imu/gyro", {
    "display_name": "IMU Gyroscope",
    "data_type": "vector3",
    "rate_hz": 10,
})
rt.configure_stream("sensors/camera", {
    "display_name": "Front Camera",
    "data_type": "image",
    "rate_hz": 1,
})
rt.configure_stream("sensors/joints", {
    "display_name": "Wheel Encoders",
    "data_type": "joint_state",
    "rate_hz": 5,
})
rt.configure_stream("robot/velocity", {
    "display_name": "Velocity",
    "data_type": "twist",
    "rate_hz": 5,
})
print("Stream configs registered.")


class RateLimiter:
    def __init__(self, hz):
        self.interval = 1.0 / hz
        self.last = 0.0

    def ok(self):
        now = time.monotonic()
        if now - self.last < self.interval:
            return False
        self.last = now
        return True


rl_scan = RateLimiter(2)
rl_odom = RateLimiter(5)
rl_imu = RateLimiter(5)
rl_cam = RateLimiter(0.5)
rl_joints = RateLimiter(2)

current_mission_id = None
counts = {"scan": 0, "odom": 0, "imu": 0, "camera": 0, "joints": 0}
last_pos = {"x": 0.0, "y": 0.0, "theta": 0.0}


class FullSensorBridge(Node):
    def __init__(self):
        super().__init__("robotrace_full_bridge")
        self.cmd_pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.create_subscription(RosLaserScan, "/scan", self.on_scan, 10)
        self.create_subscription(RosOdometry, "/odom", self.on_odom, 10)
        self.create_subscription(RosImu, "/imu", self.on_imu, 10)
        self.create_subscription(RosImage, "/camera/image_raw", self.on_camera, 10)
        self.create_subscription(RosJointState, "/joint_states", self.on_joints, 10)

    def on_scan(self, msg):
        if rl_scan.ok():
            rt.log("sensors/lidar", from_laser_scan(msg),
                   mission_id=current_mission_id, sensor_id="lidar-360")
            counts["scan"] += 1

    def on_odom(self, msg):
        if rl_odom.ok():
            rt.log("robot/pose", from_odometry(msg),
                   mission_id=current_mission_id, sensor_id="odometry")
            rt.log("robot/velocity", from_odometry_twist(msg),
                   mission_id=current_mission_id, sensor_id="odometry")
            last_pos["x"] = msg.pose.pose.position.x
            last_pos["y"] = msg.pose.pose.position.y
            q = msg.pose.pose.orientation
            siny = 2.0 * (q.w * q.z + q.x * q.y)
            cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
            last_pos["theta"] = math.atan2(siny, cosy)
            counts["odom"] += 1

    def on_imu(self, msg):
        if rl_imu.ok():
            data = from_imu(msg)
            rt.log("sensors/imu/accel", data["accel"],
                   mission_id=current_mission_id, sensor_id="imu")
            rt.log("sensors/imu/gyro", data["gyro"],
                   mission_id=current_mission_id, sensor_id="imu")
            counts["imu"] += 1

    def on_camera(self, msg):
        if rl_cam.ok():
            try:
                import cv2
                import numpy as np
                channels = 3 if "rgb" in msg.encoding or "bgr" in msg.encoding else 1
                arr = np.frombuffer(msg.data, dtype=np.uint8).reshape(
                    msg.height, msg.width, channels
                )
                if msg.encoding == "rgb8":
                    arr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
                ok, jpeg = cv2.imencode(".jpg", arr, [cv2.IMWRITE_JPEG_QUALITY, 50])
                if ok:
                    # Use artifact=True to upload to S3 — appears in Media tab
                    rt.log("sensors/camera", RTImage(data=bytes(jpeg), format="jpeg"),
                           mission_id=current_mission_id, sensor_id="camera-front",
                           artifact=True)
                    counts["camera"] += 1
            except ImportError:
                # No OpenCV — log metadata as text
                rt.log("sensors/camera",
                       Log(message="frame %dx%d %s" % (msg.width, msg.height, msg.encoding)),
                       mission_id=current_mission_id, sensor_id="camera-front")
                counts["camera"] += 1
            except Exception:
                pass

    def on_joints(self, msg):
        if rl_joints.ok():
            rt.log("sensors/joints", from_joint_state(msg),
                   mission_id=current_mission_id, sensor_id="wheel-encoders")
            counts["joints"] += 1

    def move(self, linear_x, angular_z, duration):
        twist = Twist()
        twist.linear.x = float(linear_x)
        twist.angular.z = float(angular_z)
        end_time = time.time() + duration
        while time.time() < end_time:
            self.cmd_pub.publish(twist)
            time.sleep(0.1)
        self.cmd_pub.publish(Twist())


def main():
    global current_mission_id
    rclpy.init()

    node = FullSensorBridge()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    spin_thread = threading.Thread(target=executor.spin, daemon=True)
    spin_thread.start()

    time.sleep(2)
    start_x, start_y = last_pos["x"], last_pos["y"]
    print("Robot at: x=%.2f, y=%.2f, theta=%.1f deg" % (
        last_pos["x"], last_pos["y"], math.degrees(last_pos["theta"])))
    print("")

    # =======================================================
    # Mission 1: Exploration with annotated waypoints
    # =======================================================
    print("=== Mission 1: Annotated exploration ===")
    with rt.mission("annotated_exploration", tags=["demo", "all-sensors", "annotated"]) as m:
        current_mission_id = m.mission_id

        # Drive forward
        target_x = last_pos["x"] + 0.6
        with m.phase("drive_forward") as p:
            p.log("nav/target", Pose3D(x=target_x, y=last_pos["y"], z=0.0))
            p.event("start", {"target_x": round(target_x, 2)})
            print("  Driving forward...")
            node.move(0.2, 0.0, 3.0)
            actual_x, actual_y = last_pos["x"], last_pos["y"]
            error = abs(actual_x - target_x)
            p.log("nav/actual", Pose3D(x=actual_x, y=actual_y, z=0.0))
            p.log("nav/error", Scalar(round(error, 3)))
            p.event("done", {"actual_x": round(actual_x, 2), "error": round(error, 3)})
            print("    x=%.2f (target=%.2f, error=%.3fm)" % (actual_x, target_x, error))

        # Turn left
        with m.phase("turn_left") as p:
            p.event("turning", {"degrees": 90})
            print("  Turning left...")
            node.move(0.0, 0.5, math.pi / 2 / 0.5)
            heading = math.degrees(last_pos["theta"])
            p.log("nav/heading", Scalar(round(heading, 1)))
            print("    Heading: %.1f deg" % heading)

        # Drive forward again
        with m.phase("drive_forward_2") as p:
            print("  Driving forward...")
            node.move(0.2, 0.0, 3.0)
            print("    x=%.2f, y=%.2f" % (last_pos["x"], last_pos["y"]))

        # Turn around and return
        with m.phase("return_home") as p:
            p.event("returning", {"start_x": round(start_x, 2), "start_y": round(start_y, 2)})
            print("  Turning around and returning...")
            node.move(0.0, 0.5, math.pi / 0.5)
            node.move(0.2, 0.0, 3.0)
            dist = math.sqrt((last_pos["x"] - start_x)**2 + (last_pos["y"] - start_y)**2)
            p.log("nav/return_distance", Scalar(round(dist, 2)))
            p.event("returned", {"distance_from_start": round(dist, 2)})
            print("    x=%.2f, y=%.2f (%.2fm from start)" % (last_pos["x"], last_pos["y"], dist))

        m.score("success", True)
        m.score("return_distance_m", round(dist, 2))
        m.score("total_sensors", 5)
        current_mission_id = None

    rt.flush()
    time.sleep(2)
    print("  Telemetry: scan=%d odom=%d imu=%d cam=%d joints=%d" % (
        counts["scan"], counts["odom"], counts["imu"], counts["camera"], counts["joints"]))

    # =======================================================
    # Mission 2: Square patrol with per-segment tracking
    # =======================================================
    print("")
    print("=== Mission 2: Square patrol with tracking ===")
    c_before = dict(counts)

    sides = ["north", "west", "south", "east"]
    with rt.mission("tracked_square_patrol", tags=["demo", "all-sensors", "square", "tracked"]) as m:
        current_mission_id = m.mission_id
        m.log("mission/start", Pose3D(x=last_pos["x"], y=last_pos["y"], z=0.0))

        for i, direction in enumerate(sides):
            with m.phase("drive_%s" % direction) as p:
                bx, by = last_pos["x"], last_pos["y"]
                p.log("nav/segment_start", Pose3D(x=bx, y=by, z=0.0))
                print("  Driving %s..." % direction)
                node.move(0.15, 0.0, 2.5)
                ax, ay = last_pos["x"], last_pos["y"]
                seg_dist = math.sqrt((ax - bx)**2 + (ay - by)**2)
                p.log("nav/segment_end", Pose3D(x=ax, y=ay, z=0.0))
                p.log("nav/segment_distance", Scalar(round(seg_dist, 3)))
                p.event("segment", {
                    "direction": direction,
                    "from": [round(bx, 2), round(by, 2)],
                    "to": [round(ax, 2), round(ay, 2)],
                    "distance": round(seg_dist, 3),
                })
                print("    (%.2f,%.2f) -> (%.2f,%.2f) = %.3fm" % (bx, by, ax, ay, seg_dist))

            next_dir = sides[(i + 1) % len(sides)]
            with m.phase("turn_toward_%s" % next_dir) as p:
                node.move(0.0, 0.785, 2.0)
                hdg = math.degrees(last_pos["theta"])
                p.log("nav/heading", Scalar(round(hdg, 1)))

        m.log("mission/end", Pose3D(x=last_pos["x"], y=last_pos["y"], z=0.0))
        m.score("success", True)
        m.score("sides_completed", 4)
        m2_total = sum(counts.values()) - sum(c_before.values())
        m.score("telemetry_points", m2_total)
        current_mission_id = None

    rt.flush()
    time.sleep(2)
    m2 = {k: counts[k] - c_before[k] for k in counts}
    print("  Telemetry: scan=%d odom=%d imu=%d cam=%d joints=%d" % (
        m2["scan"], m2["odom"], m2["imu"], m2["camera"], m2["joints"]))

    # =======================================================
    # Summary
    # =======================================================
    print("")
    print("=" * 50)
    print("DEMO COMPLETE")
    print("  Total: %d samples" % sum(counts.values()))
    print("  scan=%d odom=%d imu=%d camera=%d joints=%d" % (
        counts["scan"], counts["odom"], counts["imu"], counts["camera"], counts["joints"]))
    print("  Position: x=%.2f, y=%.2f" % (last_pos["x"], last_pos["y"]))
    print("  Components: lidar-360, imu, camera-front, odometry, wheel-encoders")
    print("=" * 50)

    rt.flush()
    time.sleep(3)
    rt.shutdown()
    executor.shutdown()
    rclpy.shutdown()
    print("Done!")


if __name__ == "__main__":
    main()
