#!/usr/bin/env python3
"""End-to-end test: ROSP middleware → RoboTrace server → ClickHouse.

Tests both integration paths:
1. ROSP middleware (RoboTraceMiddleware wrapping a mock adapter)
2. Direct rt.log() (existing path — must still work)

Verifies that:
- describe() registers device + components
- stream() normalizes data to correct telemetry types
- health_check() logs events
- Direct rt.log() still works alongside ROSP
"""

import asyncio
import time
import math
import random
from datetime import datetime, timezone
from typing import AsyncIterator

# ROSP SDK types
from rosp_sdk import (
    ROSPAdapter,
    RobotCard,
    StreamMessage,
    StreamQoS,
    DiscoveryInfo,
    HealthStatus,
    AdapterStatus,
    RobotStatus,
)

# RoboTrace SDK
from robotrace import RoboTrace, Scalar, Pose3D, Battery, Vector3
from robotrace.integrations.rosp import RoboTraceMiddleware


# ---------------------------------------------------------------------------
# Mock ROSP adapter simulating a TurtleBot3
# ---------------------------------------------------------------------------

class MockTurtleBot3Adapter(ROSPAdapter):
    """Simulates a TurtleBot3 Waffle with 3 sensors."""

    def __init__(self):
        super().__init__()
        self._x = 0.0
        self._y = 0.0
        self._theta = 0.0

    async def connect(self) -> None:
        print("[ROSP] Connected to mock TurtleBot3")

    async def disconnect(self) -> None:
        print("[ROSP] Disconnected")

    async def describe(self, depth: str = "full") -> RobotCard:
        return RobotCard(
            rosp_version="0.1",
            id="urn:rosp:robot:robotis:turtlebot3:rosp-e2e-001",
            identity={
                "type": "mobile_robot",
                "manufacturer": "ROBOTIS",
                "model": "TurtleBot3 Waffle",
                "firmware_version": "2.1.0",
            },
            hardware={"weight_kg": 1.8, "max_velocity_mps": 0.26},
            sensors=[
                {"sensor_id": "lidar", "type": "lidar", "model": "LDS-01", "rate_hz": 5},
                {"sensor_id": "imu", "type": "imu", "model": "ICM-20948", "rate_hz": 10},
                {"sensor_id": "battery", "type": "custom", "model": "Li-Po 11.1V"},
            ],
            actuators=[
                {"actuator_id": "base", "type": "wheel"},
            ],
            capabilities=[
                {"capability_id": "cap:nav", "name": "Navigation", "type": "navigation"},
            ],
            integration={"supported_protocols": [{"protocol": "ros2", "version": "humble"}]},
        )

    async def stream(
        self, topics: list[str], qos: StreamQoS | None = None
    ) -> AsyncIterator[StreamMessage]:
        """Generate 30 messages simulating movement."""
        for i in range(30):
            # Simulate movement
            self._x += 0.02 * math.cos(self._theta)
            self._y += 0.02 * math.sin(self._theta)
            self._theta += 0.05

            ts = datetime.now(timezone.utc)

            # LiDAR scan
            yield StreamMessage(
                topic="/sensor/lidar/scan",
                seq=i,
                timestamp=ts,
                encoding="json",
                data={"ranges": [random.uniform(0.3, 3.5) for _ in range(36)]},
            )

            # IMU acceleration
            yield StreamMessage(
                topic="/sensor/imu/accel",
                seq=i,
                timestamp=ts,
                encoding="json",
                data={"value": 9.81 + random.uniform(-0.1, 0.1)},
            )

            # Battery state
            soc = max(0.0, 1.0 - i * 0.01)
            yield StreamMessage(
                topic="/sensor/battery/state",
                seq=i,
                timestamp=ts,
                encoding="json",
                data={"voltage": 11.1 - i * 0.02, "soc": soc, "current": -1.5},
            )

            await asyncio.sleep(0.05)

    async def discover(self) -> DiscoveryInfo:
        return DiscoveryInfo(
            robot_id="rosp-e2e-001",
            model="TurtleBot3 Waffle",
            manufacturer="ROBOTIS",
            capabilities_summary=["navigation"],
            endpoint="mock://localhost",
        )

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            adapter_status=AdapterStatus.HEALTHY,
            robot_status=RobotStatus.CONNECTED,
            latency_ms=2.3,
            uptime_seconds=self.uptime_seconds,
        )


async def main():
    print("=" * 60)
    print("ROSP <-> RoboTrace E2E Integration Test")
    print("=" * 60)

    # ---------------------------------------------------------------
    # Path 1: ROSP Middleware (new path)
    # ---------------------------------------------------------------
    print("\n--- Path 1: ROSP Middleware ---")

    rt_rosp = RoboTrace(
        host="http://localhost:8080",
        public_key="rt-pk-dev-default",
        secret_key="rt-sk-dev-default",
        device_id="robotis-turtlebot3-rosp-e2e-001",  # Will be overridden by URN
        device_type="mobile_robot",
        manufacturer="ROBOTIS",
        model="TurtleBot3 Waffle",
        environment="test",
    )

    adapter = MockTurtleBot3Adapter()
    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt_rosp)

    async with mw:
        # 1. Describe — should register device + 3 sensors + 1 actuator
        card = await mw.describe()
        print(f"  Device: {mw.device_id}")
        print(f"  Sensors: {len(card.sensors)}, Actuators: {len(card.actuators)}")

        # 2. Stream — 30 iterations x 3 sensors = 90 messages
        count = 0
        async for msg in mw.stream(["*"]):
            count += 1
        print(f"  Streamed: {count} messages via ROSP middleware")

        # 3. Health check
        health = await mw.health_check()
        print(f"  Health: adapter={health.adapter_status.value}, robot={health.robot_status.value}")

    rt_rosp.flush()
    time.sleep(2)
    rt_rosp.shutdown()
    print("  ROSP path complete!")

    # ---------------------------------------------------------------
    # Path 2: Direct RoboTrace (existing path — must still work)
    # ---------------------------------------------------------------
    print("\n--- Path 2: Direct RoboTrace (existing) ---")

    rt_direct = RoboTrace(
        host="http://localhost:8080",
        public_key="rt-pk-dev-default",
        secret_key="rt-sk-dev-default",
        device_id="turtlebot3-direct-001",
        device_type="mobile_robot",
        manufacturer="ROBOTIS",
        model="TurtleBot3 Waffle",
        environment="test",
    )

    # Register components the old way
    rt_direct.component("lidar-360", type="sensor", model="LDS-01")
    rt_direct.component("imu", type="sensor", model="ICM-20948")

    # Log telemetry the old way
    with rt_direct.mission("direct_test_mission", tags=["e2e", "direct"]) as m:
        with m.phase("move_forward") as p:
            for i in range(20):
                rt_direct.log("robot/pose", Pose3D(x=i * 0.1, y=0.0, z=0.0),
                              mission_id=m.mission_id)
                rt_direct.log("sensors/imu", Vector3(x=0.1, y=0.0, z=9.81),
                              mission_id=m.mission_id, sensor_id="imu")
                time.sleep(0.05)
            p.log("nav/distance", Scalar(2.0))
        m.score("success", True)

    print(f"  Logged 40 telemetry points via direct rt.log()")

    rt_direct.flush()
    time.sleep(2)
    rt_direct.shutdown()
    print("  Direct path complete!")

    # ---------------------------------------------------------------
    # Summary
    # ---------------------------------------------------------------
    print("\n" + "=" * 60)
    print("E2E TEST COMPLETE")
    print(f"  ROSP path: {count} messages streamed via middleware")
    print(f"  Direct path: 40 telemetry points via rt.log()")
    print(f"  Both paths write to same ClickHouse + PostgreSQL")
    print(f"  Dashboard should show both devices:")
    print(f"    - robotis-turtlebot3-rosp-e2e-001 (ROSP)")
    print(f"    - turtlebot3-direct-001 (Direct)")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
