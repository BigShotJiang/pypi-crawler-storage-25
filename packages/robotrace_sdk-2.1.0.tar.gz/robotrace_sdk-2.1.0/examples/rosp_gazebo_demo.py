#!/usr/bin/env python3
"""ROSP Gazebo Demo — TurtleBot3 simulation data via ROSP protocol.

Demonstrates the ROSP integration path:
  Gazebo -> ROS2 Topics -> ROSP ROS2Adapter -> RoboTraceMiddleware -> Dashboard

This script:
1. Creates a ROSP ROS2Adapter that introspects TurtleBot3 topics
2. Wraps it with RoboTraceMiddleware for auto-registration
3. Manually subscribes to ROS2 topics (since the adapter's stream() needs
   topic configuration) and converts to ROSP StreamMessages
4. Sends movement commands to drive the robot

Prerequisites:
  - Gazebo running with TurtleBot3 spawned (gzserver + spawn)
  - ROS2 sourced in this terminal
  - pip install robotrace-sdk rosp-sdk rosp-adapter-ros2

Usage:
  cd ~/robotrace_ws && python3 rosp_gazebo_demo.py
"""

import asyncio
import math
import time
import threading
from datetime import datetime, timezone

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from sensor_msgs.msg import LaserScan, Imu, JointState as RosJointState
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.models import (
    RobotCard,
    StreamMessage,
    StreamQoS,
    DiscoveryInfo,
    HealthStatus,
    AdapterStatus,
    RobotStatus,
)

from robotrace import RoboTrace, Scalar, Pose3D
from robotrace.integrations.rosp import RoboTraceMiddleware
from robotrace.ros2 import from_laser_scan, from_imu, from_odometry


# ---------------------------------------------------------------------------
# Live ROS2 ROSP Adapter (wraps real ROS2 topics)
# ---------------------------------------------------------------------------

class LiveTurtleBot3ROSPAdapter(ROSPAdapter):
    """ROSP adapter for a live TurtleBot3 in Gazebo.

    This is a simplified adapter that manually subscribes to known topics
    and yields StreamMessages. A production adapter would introspect topics
    dynamically (like rosp-adapter-ros2 does).
    """

    def __init__(self, node: Node):
        super().__init__()
        self._node = node
        self._msg_queue = []
        self._lock = threading.Lock()
        self._seq = {"scan": 0, "odom": 0, "imu": 0, "joints": 0}
        self._last_pos = {"x": 0.0, "y": 0.0, "theta": 0.0}

        # Subscribe to TurtleBot3 topics
        self._node.create_subscription(LaserScan, "/scan", self._on_scan, 10)
        self._node.create_subscription(Odometry, "/odom", self._on_odom, 10)
        self._node.create_subscription(Imu, "/imu", self._on_imu, 10)
        self._node.create_subscription(RosJointState, "/joint_states", self._on_joints, 10)

    @property
    def last_pos(self):
        return self._last_pos

    def _enqueue(self, topic: str, data: dict, seq_key: str):
        ts = datetime.now(timezone.utc)
        self._seq[seq_key] += 1
        msg = StreamMessage(
            topic=topic,
            seq=self._seq[seq_key],
            timestamp=ts,
            encoding="json",
            data=data,
        )
        with self._lock:
            self._msg_queue.append(msg)

    def _on_scan(self, msg):
        ranges = [float(r) for r in msg.ranges if not math.isinf(r) and not math.isnan(r)]
        self._enqueue("/sensor/lidar/scan", {"ranges": ranges[:360]}, "scan")

    def _on_odom(self, msg):
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        q = msg.pose.pose.orientation
        siny = 2.0 * (q.w * q.z + q.x * q.y)
        cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self._last_pos["x"] = x
        self._last_pos["y"] = y
        self._last_pos["theta"] = math.atan2(siny, cosy)
        self._enqueue("/sensor/odometry/pose", {
            "x": round(x, 4), "y": round(y, 4), "z": 0.0,
            "qx": round(q.x, 4), "qy": round(q.y, 4),
            "qz": round(q.z, 4), "qw": round(q.w, 4),
        }, "odom")

    def _on_imu(self, msg):
        self._enqueue("/sensor/imu/accel", {
            "value": round(msg.linear_acceleration.z, 3),
        }, "imu")

    def _on_joints(self, msg):
        if msg.name:
            self._enqueue("/sensor/joints/state", {
                "names": list(msg.name),
                "positions": [round(p, 4) for p in msg.position],
                "velocities": [round(v, 4) for v in msg.velocity],
            }, "joints")

    async def connect(self) -> None:
        print("[ROSP] Connected to TurtleBot3 via ROS2")

    async def disconnect(self) -> None:
        print("[ROSP] Disconnected")

    async def describe(self, depth: str = "full") -> RobotCard:
        return RobotCard(
            rosp_version="0.1",
            id="urn:rosp:robot:robotis:turtlebot3:gazebo-rosp-001",
            identity={
                "type": "mobile_robot",
                "manufacturer": "ROBOTIS",
                "model": "TurtleBot3 Waffle",
                "firmware_version": "sim-2.1.0",
            },
            hardware={"weight_kg": 1.8, "max_velocity_mps": 0.26},
            sensors=[
                {"sensor_id": "lidar", "type": "lidar", "model": "LDS-01", "rate_hz": 5},
                {"sensor_id": "imu", "type": "imu", "model": "ICM-20948", "rate_hz": 10},
                {"sensor_id": "odometry", "type": "custom", "rate_hz": 10},
                {"sensor_id": "joints", "type": "encoder", "rate_hz": 5},
            ],
            actuators=[
                {"actuator_id": "base-drive", "type": "wheel"},
            ],
            capabilities=[
                {"capability_id": "cap:nav", "name": "Navigation", "type": "navigation",
                 "description": "Autonomous navigation with obstacle avoidance"},
            ],
            integration={"supported_protocols": [{"protocol": "ros2", "version": "humble"}]},
        )

    async def stream(self, topics, qos=None):
        """Yield queued messages from ROS2 callbacks."""
        while True:
            with self._lock:
                batch = list(self._msg_queue)
                self._msg_queue.clear()
            for msg in batch:
                yield msg
            if not batch:
                await asyncio.sleep(0.1)

    async def discover(self) -> DiscoveryInfo:
        return DiscoveryInfo(
            robot_id="gazebo-rosp-001",
            model="TurtleBot3 Waffle",
            manufacturer="ROBOTIS",
            capabilities_summary=["navigation"],
            endpoint="ros2://localhost",
        )

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            adapter_status=AdapterStatus.HEALTHY,
            robot_status=RobotStatus.CONNECTED,
            latency_ms=1.0,
            uptime_seconds=self.uptime_seconds,
        )


# ---------------------------------------------------------------------------
# Movement commands
# ---------------------------------------------------------------------------

def move(node: Node, linear_x: float, angular_z: float, duration: float):
    """Send velocity commands for a duration."""
    pub = node.create_publisher(Twist, "/cmd_vel", 10)
    twist = Twist()
    twist.linear.x = float(linear_x)
    twist.angular.z = float(angular_z)
    end_time = time.time() + duration
    while time.time() < end_time:
        pub.publish(twist)
        time.sleep(0.1)
    pub.publish(Twist())  # Stop


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def run_rosp_demo(node, adapter, mw, executor):
    """Run the ROSP demo: describe + stream + move."""
    async with mw:
        # 1. Describe — auto-registers device + 4 sensors + 1 actuator
        card = await mw.describe()
        print(f"  Device: {mw.device_id}")
        print(f"  Sensors: {len(card.sensors)}, Actuators: {len(card.actuators)}")

        # 2. Start streaming in background
        stream_count = 0
        stream_done = False

        async def stream_task():
            nonlocal stream_count
            async for msg in mw.stream(["*"]):
                stream_count += 1
                if stream_done:
                    break

        stream_coro = asyncio.create_task(stream_task())

        # 3. Move the robot (in thread so asyncio loop stays free for streaming)
        print("\n  === Mission: ROSP Square Patrol ===")
        pos = adapter.last_pos

        sides = ["north", "east", "south", "west"]
        for i, direction in enumerate(sides):
            print(f"  Driving {direction}...")
            await asyncio.to_thread(move, node, 0.15, 0.0, 2.5)
            await asyncio.sleep(0.5)
            print(f"    -> x={pos['x']:.2f}, y={pos['y']:.2f}")

            print(f"  Turning...")
            await asyncio.to_thread(move, node, 0.0, 0.785, 2.0)
            await asyncio.sleep(0.5)

        # 4. Let streaming catch up
        await asyncio.sleep(2)

        # 5. Stop streaming
        stream_done = True
        await asyncio.sleep(0.5)
        stream_coro.cancel()
        try:
            await stream_coro
        except asyncio.CancelledError:
            pass

        # 5. Health check
        health = await mw.health_check()
        print(f"\n  Health: adapter={health.adapter_status.value}, robot={health.robot_status.value}")
        print(f"  Telemetry: {stream_count} ROSP messages streamed")


def main():
    print("=" * 60)
    print("ROSP Gazebo Demo — TurtleBot3 via ROSP Protocol")
    print("=" * 60)

    rclpy.init()
    node = rclpy.create_node("rosp_gazebo_demo")
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    spin_thread = threading.Thread(target=executor.spin, daemon=True)
    spin_thread.start()

    # Wait for topics
    time.sleep(2)

    adapter = LiveTurtleBot3ROSPAdapter(node)

    rt = RoboTrace(
        host="http://localhost:8080",
        public_key="rt-pk-dev-default",
        secret_key="rt-sk-dev-default",
        device_id="robotis-turtlebot3-gazebo-rosp-001",
        device_type="mobile_robot",
        manufacturer="ROBOTIS",
        model="TurtleBot3 Waffle",
        environment="simulation",
    )

    mw = RoboTraceMiddleware(adapter=adapter, robotrace=rt)

    try:
        asyncio.run(run_rosp_demo(node, adapter, mw, executor))
    except KeyboardInterrupt:
        pass

    rt.flush()
    time.sleep(2)
    rt.shutdown()
    executor.shutdown()
    rclpy.shutdown()

    print("\n" + "=" * 60)
    print("ROSP GAZEBO DEMO COMPLETE")
    print("  Check dashboard: Devices -> robotis-turtlebot3-gazebo-rosp-001")
    print("=" * 60)


if __name__ == "__main__":
    main()
