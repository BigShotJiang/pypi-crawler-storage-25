"""ROSP integration — automatic tracing for ROSP adapter operations.

Wraps a ROSP adapter so that:
- describe() registers the device, components, and stream configs in RoboTrace
- stream() normalizes sensor data to TelemetryPoint format (float/array/json)
- health_check() logs health events with appropriate severity

Usage::

    from robotrace import RoboTrace
    from robotrace.integrations.rosp import RoboTraceMiddleware

    rt = RoboTrace(host="http://localhost:8080", public_key="...", secret_key="...")
    traced = RoboTraceMiddleware(adapter=my_adapter, robotrace=rt)

    async with traced:
        card = await traced.describe()       # auto-registers device + sensors
        async for msg in traced.stream(["*"]):  # auto-normalizes telemetry
            print(msg.data)
"""

from __future__ import annotations

import json
import logging
import re
import time
from typing import Any, AsyncIterator, Dict, List, Optional

logger = logging.getLogger("robotrace.integrations.rosp")

# ---------------------------------------------------------------------------
# URN parsing
# ---------------------------------------------------------------------------

_URN_PATTERN = re.compile(
    r"^urn:rosp:(?P<entity_type>[^:]+):(?P<manufacturer>[^:]+)"
    r":(?P<model>[^:]+):(?P<serial>.+)$"
)


def parse_rosp_urn(urn: str) -> Dict[str, str]:
    """Parse a ROSP URN into its components.

    Format: ``urn:rosp:{entity_type}:{manufacturer}:{model}:{serial}``

    Returns dict with keys: entity_type, manufacturer, model, serial, device_id.
    The device_id is synthesized as ``{manufacturer}-{model}-{serial}``.
    """
    m = _URN_PATTERN.match(urn)
    if not m:
        # Fallback: use the raw URN as device_id
        return {"device_id": urn, "entity_type": "unknown",
                "manufacturer": "", "model": "", "serial": ""}
    parts = m.groupdict()
    parts["device_id"] = f"{parts['manufacturer']}-{parts['model']}-{parts['serial']}"
    return parts


# ---------------------------------------------------------------------------
# Stream data normalization
# ---------------------------------------------------------------------------

def _normalize_stream_data(data: Any) -> Dict[str, Any]:
    """Convert arbitrary StreamMessage.data into TelemetryPoint value fields.

    Returns a dict with one of: value_float, value_array, or value_json.
    """
    if isinstance(data, (int, float)):
        return {"value_float": float(data)}

    if isinstance(data, dict):
        # Single numeric value
        if "value" in data and isinstance(data["value"], (int, float)):
            return {"value_float": float(data["value"])}

        # Array-like: ranges, values, positions
        for key in ("ranges", "values", "positions", "data"):
            if key in data and isinstance(data[key], list):
                arr = data[key]
                if arr and isinstance(arr[0], (int, float)):
                    return {"value_array": [float(v) for v in arr]}

        # Complex structured data — serialize as JSON
        return {"value_json": json.dumps(data, default=str)}

    if isinstance(data, list):
        if data and isinstance(data[0], (int, float)):
            return {"value_array": [float(v) for v in data]}
        return {"value_json": json.dumps(data, default=str)}

    return {"value_json": json.dumps({"value": str(data)}, default=str)}


def _topic_to_stream(topic: str) -> str:
    """Convert a ROSP topic path to a RoboTrace stream name.

    /sensor/lidar/scan -> sensors/lidar
    /sensor/imu/data -> sensors/imu
    /actuator/base/cmd -> actuators/base
    """
    # Strip leading slash
    t = topic.lstrip("/")

    # Common ROSP topic patterns
    if t.startswith("sensor/"):
        parts = t.split("/")
        return "sensors/" + parts[1] if len(parts) >= 2 else t
    if t.startswith("actuator/"):
        parts = t.split("/")
        return "actuators/" + parts[1] if len(parts) >= 2 else t

    # Fallback: replace slashes, keep as-is
    return t


def _topic_to_sensor_id(topic: str, sensor_map: Dict[str, str]) -> Optional[str]:
    """Resolve a ROSP topic to a sensor_id using the RobotCard sensor map."""
    # Direct match
    if topic in sensor_map:
        return sensor_map[topic]

    # Match by sensor name in topic path
    t = topic.lstrip("/")
    parts = t.split("/")
    for part in reversed(parts):
        if part in sensor_map:
            return sensor_map[part]

    return None


# ---------------------------------------------------------------------------
# RoboTraceMiddleware
# ---------------------------------------------------------------------------

class RoboTraceMiddleware:
    """Full-featured tracing wrapper for any ROSP adapter.

    Translates ROSP protocol operations into RoboTrace API calls:
    - describe() -> device registration + component registration + stream config
    - stream() -> normalized telemetry (value_float/value_array/value_json)
    - health_check() -> health events with severity mapping
    """

    def __init__(
        self,
        adapter: Any,
        robotrace: Any,
        auto_register: bool = True,
        stream_batch_size: int = 50,
    ) -> None:
        self._adapter = adapter
        self._rt = robotrace
        self._auto_register = auto_register
        self._batch_size = stream_batch_size
        self._device_id: str | None = None
        self._urn_parts: Dict[str, str] = {}
        self._sensor_map: Dict[str, str] = {}  # topic/name -> sensor_id
        self._registered = False

    # -- Lifecycle --

    async def connect(self) -> None:
        await self._adapter.connect()

    async def disconnect(self) -> None:
        try:
            self._rt.flush()
        except Exception:
            logger.debug("Flush failed during disconnect")
        await self._adapter.disconnect()

    async def __aenter__(self) -> "RoboTraceMiddleware":
        await self.connect()
        return self

    async def __aexit__(
        self, exc_type: type | None, exc_val: BaseException | None, exc_tb: Any
    ) -> None:
        await self.disconnect()

    # -- describe() with full registration --

    async def describe(self, depth: str = "full") -> Any:
        """Call adapter.describe() and register device + components in RoboTrace."""
        card = await self._adapter.describe(depth=depth)

        # Parse URN for device identity
        self._urn_parts = parse_rosp_urn(card.id)
        self._device_id = self._urn_parts["device_id"]

        if not self._auto_register or self._registered:
            return card

        try:
            self._register_device(card)
            self._register_components(card)
            self._configure_streams(card)
            self._registered = True
            logger.info(
                "ROSP device registered in RoboTrace: %s (%d sensors, %d actuators)",
                self._device_id,
                len(card.sensors),
                len(card.actuators),
            )
        except Exception as e:
            logger.warning("Failed to register ROSP device in RoboTrace: %s", e)

        return card

    def _register_device(self, card: Any) -> None:
        """Register the device using RobotCard identity fields."""
        identity = card.identity or {}
        # Log a registration event with full identity
        self._rt.event(
            "rosp_device_registered",
            data={
                "device_id": self._device_id,
                "rosp_urn": card.id,
                "rosp_version": card.rosp_version,
                "type": identity.get("type", "unknown"),
                "manufacturer": identity.get("manufacturer", ""),
                "model": identity.get("model", ""),
                "firmware_version": identity.get("firmware_version", ""),
            },
            severity="info",
        )

    def _register_components(self, card: Any) -> None:
        """Register each sensor and actuator as a RoboTrace Component."""
        for sensor in (card.sensors or []):
            sid = sensor.get("sensor_id", sensor.get("name", ""))
            if not sid:
                continue
            stype = sensor.get("type", "sensor")
            self._rt.component(
                sid,
                type="sensor",
                manufacturer=sensor.get("manufacturer", ""),
                model=sensor.get("model", ""),
            )
            # Build topic -> sensor_id map for stream normalization
            self._sensor_map[sid] = sid
            logger.debug("Registered sensor component: %s (type=%s)", sid, stype)

        for actuator in (card.actuators or []):
            aid = actuator.get("actuator_id", actuator.get("name", ""))
            if not aid:
                continue
            self._rt.component(
                aid,
                type="actuator",
                manufacturer=actuator.get("manufacturer", ""),
                model=actuator.get("model", ""),
            )
            self._sensor_map[aid] = aid
            logger.debug("Registered actuator component: %s", aid)

    def _configure_streams(self, card: Any) -> None:
        """Configure RoboTrace streams from RobotCard sensor metadata."""
        for sensor in (card.sensors or []):
            sid = sensor.get("sensor_id", "")
            if not sid:
                continue
            stream_name = f"sensors/{sid}"
            config: Dict[str, Any] = {
                "display_name": sensor.get("name", sid),
                "data_type": sensor.get("type", "unknown"),
            }
            rate = sensor.get("rate_hz") or sensor.get("frequency_hz")
            if rate:
                config["rate_hz"] = rate
            try:
                self._rt.configure_stream(stream_name, config)
            except Exception:
                logger.debug("Failed to configure stream: %s", stream_name)

    # -- stream() with normalization --

    async def stream(
        self, topics: List[str], qos: Any = None
    ) -> AsyncIterator[Any]:
        """Stream sensor data with automatic telemetry normalization."""
        if not self._device_id:
            try:
                card = await self._adapter.describe(depth="summary")
                self._urn_parts = parse_rosp_urn(card.id)
                self._device_id = self._urn_parts["device_id"]
            except Exception:
                logger.warning("Could not resolve device_id for tracing")

        async for msg in self._adapter.stream(topics, qos):
            if self._device_id:
                try:
                    stream_name = _topic_to_stream(msg.topic)
                    sensor_id = _topic_to_sensor_id(msg.topic, self._sensor_map)
                    normalized = _normalize_stream_data(msg.data)

                    # Route to the appropriate rt.log() call
                    if "value_float" in normalized:
                        from robotrace.types import Scalar
                        self._rt.log(
                            stream_name,
                            Scalar(normalized["value_float"]),
                            sensor_id=sensor_id,
                        )
                    elif "value_array" in normalized:
                        from robotrace.types import VectorN
                        self._rt.log(
                            stream_name,
                            VectorN(normalized["value_array"]),
                            sensor_id=sensor_id,
                        )
                    else:
                        # JSON — log as dict
                        raw = json.loads(normalized["value_json"])
                        self._rt.log(stream_name, raw, sensor_id=sensor_id)
                except Exception:
                    logger.debug("Failed to trace stream message: %s", msg.topic)
            yield msg

    # -- health_check() with event mapping --

    async def health_check(self) -> Any:
        """Check health and log status as a RoboTrace event."""
        status = await self._adapter.health_check()

        try:
            # Map robot status to severity
            robot_status = status.robot_status.value if hasattr(status.robot_status, "value") else str(status.robot_status)
            severity_map = {
                "connected": "info",
                "degraded": "warning",
                "disconnected": "error",
                "estop": "error",
                "unknown": "warning",
            }
            severity = severity_map.get(robot_status, "info")

            self._rt.event(
                "rosp_health_check",
                data={
                    "adapter_status": status.adapter_status.value if hasattr(status.adapter_status, "value") else str(status.adapter_status),
                    "robot_status": robot_status,
                    "latency_ms": status.latency_ms,
                    "uptime_seconds": status.uptime_seconds,
                },
                severity=severity,
            )

            # Log latency as telemetry
            if status.latency_ms is not None:
                from robotrace.types import Scalar
                self._rt.log("health/latency_ms", Scalar(status.latency_ms))

        except Exception:
            logger.debug("Failed to log health check")

        return status

    # -- Passthrough --

    async def discover(self) -> Any:
        return await self._adapter.discover()

    @property
    def is_connected(self) -> bool:
        return self._adapter.is_connected

    @property
    def device_id(self) -> str | None:
        return self._device_id

    def __getattr__(self, name: str) -> Any:
        return getattr(self._adapter, name)
