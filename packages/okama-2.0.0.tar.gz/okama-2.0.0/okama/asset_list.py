from typing import Optional, Union, Tuple

import numpy as np
import pandas as pd

from okama.common.helpers.helpers import check_rolling_window
import okama.common.helpers.ratios as ratios
from okama.common.helpers import helpers
from okama.common import make_asset_list

from okama import settings


class AssetList(make_asset_list.ListMaker):
    """
    List of financial assets.

    AssetList can include stocks, ETFs, mutual funds, commodities, currencies and stock indexes (benchmarks).

    Parameters
    ----------
    assets : list, default None
        List of assets. Could include tickers or asset-like objects (`Asset`, `Portfolio`).
        If None, a single-asset list with a default ticker is used.
    first_date : str, default None
        First date of monthly return time series.
        If None, the first date is calculated automatically as the oldest available date for the listed assets.
    last_date : str, default None
        Last date of monthly return time series.
        If None, the last date is calculated automatically as the newest available date for the listed assets.
    ccy : str, default 'USD'
        Base currency for the list of assets. All risk metrics and returns are adjusted to the base currency.

    inflation : bool, default True
        Defines whether to take inflation data into account in the calculations.
        Including inflation could limit available data (`first_date`, `last_date`)
        as the inflation data is usually published with a one-month delay.
        With `inflation=False`, some properties like real return are not available.
    """

    def __repr__(self):
        dic = {
            "assets": self.symbols,
            "currency": self._currency.ticker,
            "first_date": self.first_date.strftime("%Y-%m"),
            "last_date": self.last_date.strftime("%Y-%m"),
            "period_length": self._pl_txt,
            "inflation": self.inflation if hasattr(self, "inflation") else "None",
        }
        return repr(pd.Series(dic))

    @property
    def wealth_indexes(self) -> pd.DataFrame:
        """
        Calculate wealth index time series for the assets and accumulated inflation.

        Wealth index (Cumulative Wealth Index) is a time series that presents the value of each asset over
        historical time period. Accumulated inflation time series is added if `inflation=True` in the AssetList.

        Wealth index is obtained from the accumulated return multiplied by the initial investments.
        That is: 1000 * (Acc_Return + 1)
        Initial investments are taken as 1000 units of the AssetList base currency.

        Returns
        -------
        DataFrame
            Time series of wealth index values for each asset and accumulated inflation.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SPY.US', 'BND.US'])
        >>> x.wealth_indexes.plot()
        >>> plt.show()
        """
        df = self._add_inflation()
        return helpers.Frame.get_wealth_indexes(df)

    @property
    def risk_monthly(self) -> pd.DataFrame:
        """
        Calculate monthly risk expanding time series for each asset.

        Monthly risk of the asset is a standard deviation of the rate of return time series.
        Standard deviation (sigma σ) is normalized by N-1.

        Monthly risk is calculated for the rate of retirun time series for the sample from 'first_date' to
        'last_date'.

        Returns
        -------
        DataFrame
            Monthly risk (standard deviation) expanding time series for each asset in form of Series.

        See Also
        --------
        risk_annual : Calculate annualized risks expanding time series.
        semideviation_monthly : Calculate semideviation monthly values.
        semideviation_annual : Calculate semideviation annualized values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate drawdowns.

        Examples
        --------
        >>> al = ok.AssetList(['GC.COMM', 'SHV.US'], ccy='USD', last_date='2021-01')
        >>> al.risk_monthly
        Symbols   GC.COMM    SHV.US
        date
        2007-03  0.025668  0.000141
        2007-04  0.020872  0.000153
        2007-05  0.027513  0.000451
        2007-06  0.025988  0.000406
                   ...       ...
        2020-09  0.051006  0.001380
        2020-10  0.050861  0.001377
        """
        return self.assets_ror.expanding().std().iloc[1:]

    @property
    def risk_annual(self) -> pd.DataFrame:
        """
        Calculate annualized risk expanding time series for each asset.

        Risk is a standard deviation of the rate of return.

        Annualized risk time series is calculated for the rate of return from 'first_date' to
        'last_date' (expanding).

        Returns
        -------
        DataFrame
            Annualized risk (standard deviation) expanding time series for each asset.

        See Also
        --------
        risk_monthly : Calculate montly risk expanding time series for each asset.
        get_rolling_risk_annual : Calculate annualized risk rolling time series.
        semideviation_monthly : Calculate semideviation monthly values.
        semideviation_annual : Calculate semideviation annualized values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate assets drawdowns.

        Notes
        -----
        CFA recomendations are used to annualize risk values [1]_.

        .. [1] `What’s Wrong with Multiplying by the Square Root of Twelve. <https://www.cfainstitute.org/en/research/cfa-digest/2013/11/whats-wrong-with-multiplying-by-the-square-root-of-twelve-digest-summary>`_ Paul D. Kaplan, CFA Institute Journal Review, 2013

        Examples
        --------
        >>> al = ok.AssetList(['GC.COMM', 'SHV.US'], ccy='USD', last_date='2021-01')
        >>> al.risk_annual
        Symbols   GC.COMM    SHV.US
        date
        2007-03  0.097820  0.000511
        2007-04  0.084806  0.000552
        2007-05  0.099466  0.001633
        2007-06  0.089265  0.001472
        2007-07  0.095290  0.001442
        ...           ...       ...
        2020-09  0.193815  0.004824
        2020-10  0.193087  0.004813
        2020-11  0.192583  0.004807
        2020-12  0.193513  0.004796
        2021-01  0.192754  0.004788
        [167 rows x 2 columns]
        """
        risk_ts = self.assets_ror.expanding().std()
        mean_return_ts = self.assets_ror.expanding().mean()
        return helpers.Float.annualize_risk(risk_ts, mean_return_ts).iloc[1:]

    def get_rolling_risk_annual(self, window: int = 12):
        """
        Calculate annualized risk rolling time series for each asset.

        Risk is a standard deviation of the rate of return.

        Annualized risk time series is calculated for the rate of return values limited by moving window.

        Parameters
        ----------
        window : int, default 12
            Size of the moving window in months.

        Returns
        -------
        DataFrame
            Annualized risk (standard deviation) rolling time series for each asset.

        See Also
        --------
        risk_monthly : Calculate montly risk expanding time series for each asset.
        risk_annual : Calculate annualized risks.
        semideviation_monthly : Calculate semideviation monthly values.
        semideviation_annual : Calculate semideviation annualized values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate assets drawdowns.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SPY.US', 'AGG.US'], ccy='USD', inflation=True)
        >>> x.get_rolling_risk_annual(window=5*12).plot()
        >>> plt.show()
        """
        check_rolling_window(window=window, ror=self.assets_ror, window_below_year=True)
        risk_ts = self.assets_ror.rolling(window).std()
        mean_return_ts = self.assets_ror.rolling(window).mean()
        return helpers.Float.annualize_risk(risk_ts, mean_return_ts).dropna()

    @property
    def semideviation_monthly(self) -> pd.Series:
        """
        Calculate semi-deviation monthly values for each asset.

        Semi-deviation (Downside risk) is the risk of the return being below the expected return.

        Semi-deviation is calculated for rate of retirun time series for the sample from 'first_date' to
        'last_date'.

        Returns
        -------
        Series
            Monthly semideviation values for each asset in form of Series.

        See Also
        --------
        risk_monthly : Calculate montly risk for each asset.
        risk_annual : Calculate annualized risks.
        semideviation_annual : Calculate semideviation annualized values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate drawdowns.

        Examples
        --------
        >>> al = ok.AssetList(['GC.COMM', 'SHV.US'], ccy='USD', last_date='2021-01')
        >>> al.semideviation_monthly
        GC.COMM    0.039358
        SHV.US     0.000384
        dtype: float64
        """
        return helpers.Frame.get_semideviation(self.assets_ror)

    @property
    def semideviation_annual(self) -> pd.Series:
        """
        Return semideviation annualized values for each asset.

        Semi-deviation (Downside risk) is the risk of the return being below the expected return.

        Semi-deviation is calculated for rate of retirun time series for the sample from 'first_date' to
        'last_date'.

        Returns
        -------
        Series
            Annualized semideviation values for each asset in form of Series.

        See Also
        --------
        risk_monthly : Calculate montly risk for each asset.
        risk_annual : Calculate annualized risks.
        semideviation_monthly : Calculate semideviation monthly values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate drawdowns.

        Examples
        --------
        >>> al = ok.AssetList(['GC.COMM', 'SHV.US'], ccy='USD', last_date='2021-01')
        >>> al.semideviation_annual
        GC.COMM    0.115302
        SHV.US     0.000560
        dtype: float64
        """
        return helpers.Frame.get_semideviation(self.assets_ror) * 12**0.5

    def get_var_historic(self, time_frame: int = 12, level: int = 1) -> pd.Series:
        """
        Calculate historic Value at Risk (VaR) for the assets with a given timeframe.

        The VaR calculates the potential loss of an investment with a given time frame and confidence level.
        Loss is a positive number (expressed in cumulative return).
        If VaR is negative there are expected gains at this confidence level.

        Parameters
        ----------
        time_frame : int, default 12
            Time period size in months

        level : int, default 1
            Confidence level in percents (1 - 100%). Default value is 1%.

        Returns
        -------
        Series
            VaR values for each asset in form of Series.

        See Also
        --------
        risk_monthly : Calculate montly risk for each asset.
        risk_annual : Calculate annualized risks.
        semideviation_monthly : Calculate semideviation monthly values.
        semideviation_annual : Calculate semideviation annualized values.
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate drawdowns.

        Examples
        --------
        >>> x = ok.AssetList(['SPY.US', 'AGG.US'])
        >>> x.get_var_historic(time_frame=60, level=1)
        SPY.US    0.2101
        AGG.US    -0.0867
        Name: VaR, dtype: float64
        """
        df = self.get_rolling_cumulative_return(window=time_frame).loc[:, self.symbols]
        return helpers.Frame.get_var_historic(df, level)

    def get_cvar_historic(self, time_frame: int = 12, level: int = 1) -> pd.Series:
        """
        Calculate historic Conditional Value at Risk (CVAR, expected shortfall) for the assets with a given timeframe.

        CVaR is the average loss over a specified time period of unlikely scenarios beyond the confidence level.
        Loss is a positive number (expressed in cumulative return).
        If CVaR is negative there are expected gains at this confidence level.

        Parameters
        ----------
        time_frame : int, default 12
            Time period size in months
        level : int, default 1
            Confidence level in percents to calculate the VaR. Default value is 1% (1% quantile).

        Returns
        -------
        Series
            CVaR values for each asset in form of Series.

        See Also
        --------
        risk_monthly : Calculate montly risk for each asset.
        risk_annual : Calculate annualized risks.
        semideviation_monthly : Calculate semideviation monthly values.
        semideviation_annual : Calculate semideviation annualized values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        drawdowns : Calculate drawdowns.

        Examples
        --------
        >>> x = ok.AssetList(['SPY.US', 'AGG.US'])
        >>> x.get_cvar_historic(time_frame=60, level=1)
        SPY.US    0.2574
        AGG.US   -0.0766
        dtype: float64
        Name: VaR, dtype: float64
        """
        df = self.get_rolling_cumulative_return(window=time_frame).loc[:, self.symbols]
        return helpers.Frame.get_cvar_historic(df, level)

    @property
    def drawdowns(self) -> pd.DataFrame:
        """
        Calculate drawdowns time series for the assets.

        The drawdown is the percent decline from a previous peak in wealth index.

        Returns
        -------
        DataFrame
            Time series of drawdowns.

        See Also
        --------
        risk_monthly : Calculate montly risk for each asset.
        risk_annual : Calculate annualized risks.
        semideviation_monthly : Calculate semideviation monthly values.
        semideviation_annual : Calculate semideviation annualized values.
        get_var_historic : Calculate historic Value at Risk (VaR).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['SPY.US', 'BND.US'], last_date='2021-08')
        >>> al.drawdowns.plot()
        >>> plt.show()
        """
        return helpers.Frame.get_drawdowns(self.assets_ror)

    @property
    def recovery_periods(self) -> pd.Series:
        """
        Calculate the longest recovery periods for the assets.

        The recovery period (drawdown duration) is the number of months to reach the value of the last maximum.

        Returns
        -------
        Series
            Max recovery period for each asset (in months).

        See Also
        --------
        drawdowns : Calculate drawdowns time series.

        Notes
        -----
        If the last asset maximum value is not recovered NaN is returned.
        The largest recovery period does not necessary correspond to the max drawdown.

        Examples
        --------
        >>> x = ok.AssetList(['SPY.US', 'AGG.US'])
        >>> x.recovery_periods
        SPY.US    52
        AGG.US    15
        dtype: int32
        """
        cummax = self.wealth_indexes.cummax()
        growth = cummax.pct_change()[1:]
        recovery_data = {}  # Collect data to create Series once at the end
        for name in self.symbols:
            namespace = name.split(".", 1)[-1]
            if namespace == "INFL":
                continue
            s = growth[name]
            s1 = s.where(s == 0).notnull().astype(int)
            s1_1 = s.where(s == 0).isnull().astype(int).cumsum()
            s2 = s1.groupby(s1_1).cumsum()
            # Max recovery period date should not be in the border (it's not recovered)
            max_period = s2.max() if s2.idxmax().to_timestamp() != self.last_date else np.nan
            recovery_data[name] = max_period
        # Use Int64 (nullable integer) to support NaN values
        return pd.Series(recovery_data, dtype="Int64")

    def get_cagr(self, period: Optional[int] = None, real: bool = False) -> pd.Series:
        """
        Calculate assets Compound Annual Growth Rate (CAGR) for a given trailing period.

        Compound annual growth rate (CAGR) is the rate of return that would be required for an investment to grow from
        its initial to its final value, assuming all incomes were reinvested.

        Inflation adjusted annualized returns (real CAGR) are shown with `real=True` option.

        Annual inflation value is calculated for the same period if `inflation=True` in the `AssetList`.

        Parameters
        ----------
        period : int, default None
            CAGR trailing period in years. If None, use the full available period.
        real : bool, default False
            CAGR is adjusted for inflation (real CAGR) if True.
            AssetList should be initiated with `inflation=True` for real CAGR.

        Returns
        -------
        Series
            CAGR values for each asset and annualized inflation (optional).

        See Also
        --------
        get_rolling_cagr : Calculate rolling CAGR.

        Notes
        -----
        CAGR is not defined for periods less than 1 year (NaN values are returned).

        Examples
        --------
        >>> x = ok.AssetList()
        >>> x.get_cagr(period=5)
        SPY.US    0.1510
        USD.INFL   0.0195
        dtype: float64

        To get inflation adjusted return (real annualized return) add `real=True` option:

        >>> x = ok.AssetList(['EURUSD.FX', 'CNYUSD.FX'], inflation=True)
        >>> x.get_cagr(period=5, real=True)
        EURUSD.FX    0.000439
        CNYUSD.FX   -0.017922
        dtype: float64
        """
        df = self._add_inflation()
        dt0 = self.last_date
        if period is None:
            dt = self.first_date
        else:
            self._validate_period(period)
            dt = helpers.Date.subtract_years(dt0, period)
        cagr = helpers.Frame.get_cagr(df[dt:])
        if real:
            if not hasattr(self, "inflation"):
                raise ValueError("Real CAGR is not defined. Set inflation=True in AssetList to calculate it.")
            mean_inflation = helpers.Frame.get_cagr(self.inflation_ts[dt:])
            cagr = (1.0 + cagr) / (1.0 + mean_inflation) - 1.0
            cagr.drop(self.inflation, inplace=True)
        return cagr

    def get_rolling_cagr(self, window: int = 12, real: bool = False) -> pd.DataFrame:
        """
        Calculate rolling CAGR for each asset.

        Compound annual growth rate (CAGR) is the rate of return that would be required for an investment to grow from
        its initial to its final value, assuming all incomes were reinvested.

        Inflation adjusted annualized returns (real CAGR) are shown with `real=True` option.

        Parameters
        ----------
        window : int, default 12
            Size of the moving window in months. Window size should be at least 12 months for CAGR.
        real : bool, default False
            CAGR is adjusted for inflation (real CAGR) if True.
            AssetList should be initiated with `inflation=True` for real CAGR.

        Returns
        -------
        DataFrame
            Time series of rolling CAGR and mean inflation (optionally).

        See Also
        --------
        get_rolling_cagr : Calculate rolling CAGR.
        get_cagr : Calculate CAGR.
        get_rolling_cumulative_return : Calculate rolling cumulative return.
        annual_return : Calculate annualized mean return (arithmetic mean).

        Notes
        -----
        CAGR is not defined for periods less than 1 year (NaN values are returned).

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SPY.US', 'AGG.US'], ccy='USD', inflation=True)
        >>> x.get_rolling_cagr(window=5*12).plot()
        >>> plt.show()

        For inflation adjusted rolling CAGR add 'real=True' option:

        >>> x.get_rolling_cagr(window=5*12, real=True).plot()
        >>> plt.show()
        """
        df = self._add_inflation()
        if real:
            df = self._make_real_return_time_series(df)
        return helpers.Frame.get_rolling_fn(df, window=window, fn=helpers.Frame.get_cagr)

    def get_monthly_geometric_mean_return(self):
        """
        Calculate monthly geometric mean return for each asset.

        The geometric mean return is the constant periodic return that would produce the same
        final value as a sequence of varying periodic returns when compounded over time.

        Returns
        -------
        Series
            Monthly geometric mean return value for each asset.

        Examples
        --------
        >>> al = ok.AssetList(['SPY.US', 'AGG.US'])
        >>> al.get_monthly_geometric_mean_return()
        SPY.US    0.008456
        AGG.US    0.003124
        dtype: float64
        """
        return (self.assets_ror + 1.0).prod() ** (1 / self.assets_ror.shape[0]) - 1.0

    def get_cumulative_return(self, period: Union[str, int, None] = None, real: bool = False) -> pd.Series:
        """
        Calculate cumulative return over a given trailing period for each asset.

        The cumulative return is the total change in the asset price during the investment period.

        Inflation adjusted cumulative returns (real cumulative returns) are shown with `real=True` option.
        Annual inflation data is calculated for the same period if `inflation=True` in the AssetList.

        Parameters
        ----------
        period : str or int or None, default None
            Trailing period in years. Period should be greater than 0.
            None - full time cumulative return.
            'YTD' - (Year To Date) period of time beginning the first day of the calendar year up to the last month.
        real : bool, default False
            Cumulative return is adjusted for inflation (real cumulative return) if True.
            AssetList should be initiated with `inflation=True` for real cumulative return.

        Returns
        -------
        Series
            Cumulative return values for each asset and cumulative inflation (if inflation=True in AssetList).

        See Also
        --------
        get_rolling_cagr : Calculate rolling CAGR.
        get_cagr : Calculate CAGR.
        get_rolling_cumulative_return : Calculate rolling cumulative return.
        annual_return : Calculate annualized mean return (arithmetic mean).

        Examples
        --------
        >>> x = ok.AssetList(['MCFTR.INDX'], ccy='RUB')
        >>> x.get_cumulative_return(period='YTD')
        MCFTR.INDX   0.1483
        RUB.INFL     0.0485
        dtype: float64
        """
        df = self._add_inflation()
        dt0 = self.last_date

        if period is None:
            dt = self.first_date
        elif str(period).lower() == "ytd":
            year = dt0.year
            dt = str(year)
        else:
            self._validate_period(period)
            dt = helpers.Date.subtract_years(dt0, period)

        cr = helpers.Frame.get_cumulative_return(df[dt:])
        if real:
            if not hasattr(self, "inflation"):
                raise ValueError(
                    "Real cumulative return is not defined (no inflation information is available)."
                    "Set inflation=True in AssetList to calculate it."
                )
            cumulative_inflation = helpers.Frame.get_cumulative_return(self.inflation_ts[dt:])
            cr = (1.0 + cr) / (1.0 + cumulative_inflation) - 1.0
            cr.drop(self.inflation, inplace=True)
        return cr

    def get_rolling_cumulative_return(self, window: int = 12, real: bool = False) -> pd.DataFrame:
        """
        Calculate rolling cumulative return for each asset.

        The cumulative return is the total change in the asset price.

        Parameters
        ----------
        window : int, default 12
            Size of the moving window in months.
        real : bool, default False
            Cumulative return is adjusted for inflation (real cumulative return) if True.
            AssetList should be initiated with `inflation=True` for real cumulative return.

        Returns
        -------
        DataFrame
            Time series of rolling cumulative return.

        See Also
        --------
        get_rolling_cagr : Calculate rolling CAGR.
        get_cagr : Calculate CAGR.
        get_cumulative_return : Calculate cumulative return.
        annual_return : Calculate annualized mean return (arithmetic mean).

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SPY.US', 'AGG.US'], ccy='USD', inflation=True)
        >>> x.get_rolling_cumulative_return(window=5*12).plot()
        >>> plt.show()

        For inflation adjusted rolling cumulative return add 'real=True' option:

        >>> x.get_rolling_cumulative_return(window=5*12, real=True).plot()
        >>> plt.show()
        """
        df = self._add_inflation()
        if real:
            df = self._make_real_return_time_series(df)
        return helpers.Frame.get_rolling_fn(
            df,
            window=window,
            fn=helpers.Frame.get_cumulative_return,
            window_below_year=True,
        )

    @property
    def annual_return_ts(self) -> pd.DataFrame:
        """
        Calculate annual rate of return time series for each asset.

        Rate of return is calculated for each calendar year.

        Returns
        -------
        DataFrame
            Calendar annual rate of return time series.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['SPY.US', 'BND.US'], last_date='2021-08')
        >>> al.annual_return_ts.plot(kind='bar')
        >>> plt.show()
        """
        return helpers.Frame.get_annual_return_ts_from_monthly(self.assets_ror)

    def describe(self, years: Tuple[int, ...] = (1, 5, 10), tickers: bool = True) -> pd.DataFrame:
        """
        Generate descriptive statistics for a list of assets.

        Statistics includes:

        - YTD (Year To date) compound return
        - CAGR for a given list of periods and full available period
        - Annualized mean rate of return (full available period)
        - LTM Dividend yield - last twelve months dividend yield

        Risk metrics (full period):

        - risk (standard deviation)
        - CVAR (timeframe is 1 year)
        - max drawdowns (and dates of the drawdowns)

        Statistics also shows for each asset:
        - inception date - first date available for each asset
        - last asset date - available for each asset date
        - Common last data date - common for the asset list data (may be set by last_date manually)

        Parameters
        ----------
        years : tuple of int, default (1, 5, 10)
            List of periods for CAGR.

        tickers : bool, default True
            Defines whether to show tickers (True) or asset names in the header.

        Returns
        -------
        DataFrame
            Table of descriptive statistics for a list of assets.

        See Also
        --------
        get_cumulative_return : Calculate cumulative return.
        get_cagr : Calculate assets Compound Annual Growth Rate (CAGR).
        dividend_yield : Calculate dividend yield (LTM).
        risk_annual : Return annualized risks (standard deviation).
        get_cvar_historic : Calculate historic Conditional Value at Risk (CVaR).
        drawdowns : Calculate drawdowns.

        Examples
        --------
        >>> al = ok.AssetList(['SPY.US', 'AGG.US'], last_date='2021-08')
        >>> al.describe(years=[1, 10, 15])
                         property               period    AGG.US    SPY.US inflation
        0         Compound return                  YTD -0.005620  0.180519  0.048154
        1                    CAGR              1 years -0.007530  0.363021  0.053717
        2                    CAGR             10 years  0.032918  0.152310  0.019136
        3                    CAGR             15 years  0.043013  0.107598  0.019788
        4                    CAGR  17 years, 10 months  0.039793  0.107972  0.022002
        5          Dividend yield                  LTM  0.018690  0.012709       NaN
        6                    Risk  17 years, 10 months  0.037796  0.158301       NaN
        7                    CVAR  17 years, 10 months  0.023107  0.399398       NaN
        """
        rows_list = []
        dt0 = self.last_date
        df = self._add_inflation()
        # YTD return
        ytd_return = self.get_cumulative_return(period="YTD")
        row = ytd_return.to_dict()
        row.update(period="YTD", property="Compound return")
        rows_list.append(row)
        # CAGR for a list of periods
        if self.pl.years >= 1:
            for i in years:
                dt = helpers.Date.subtract_years(dt0, i)
                if dt >= self.first_date:
                    row = self.get_cagr(period=i).to_dict()
                else:
                    row = {x: None for x in df.columns}
                row.update(period=f"{i} years", property="CAGR")
                rows_list.append(row)
            # CAGR for full period
            row = self.get_cagr(period=None).to_dict()
            row.update(period=self._pl_txt, property="CAGR")
            rows_list.append(row)
            # Mean rate of return (arithmetic mean)
            row = self.mean_return.to_dict()
            row.update(
                period=self._pl_txt,
                property="Annualized mean return",
            )
            rows_list.append(row)
            # Dividend Yield
            row = self._assets_dividend_yield.iloc[-1].to_dict()
            row.update(period="LTM", property="Dividend yield")
            rows_list.append(row)
        # risk for full period
        row = self.risk_annual.iloc[-1, :].to_dict()
        row.update(period=self._pl_txt, property="Risk")
        rows_list.append(row)
        # CVAR
        if self.pl.years >= 1:
            row = self.get_cvar_historic().to_dict()
            row.update(period=self._pl_txt, property="CVAR")
            rows_list.append(row)
        # max drawdowns
        row = self.drawdowns.min().to_dict()
        row.update(period=self._pl_txt, property="Max drawdowns")
        rows_list.append(row)
        # max drawdowns dates
        row = self.drawdowns.idxmin().to_dict()
        row.update(period=self._pl_txt, property="Max drawdowns dates")
        rows_list.append(row)
        # inception dates
        row = {}
        for ti in self.symbols:
            # short_ticker = ti.split(".", 1)[0]
            value = self.assets_first_dates[ti].strftime("%Y-%m")
            row.update({ti: value})
        row.update(period=None, property="Inception date")
        if hasattr(self, "inflation"):
            row.update({self.inflation: self.inflation_first_date.strftime("%Y-%m")})
        rows_list.append(row)
        # last asset date
        row = {}
        for ti in self.symbols:
            # short_ticker = ti.split(".", 1)[0]
            value = self.assets_last_dates[ti].strftime("%Y-%m")
            row.update({ti: value})
        row.update(period=None, property="Last asset date")
        if hasattr(self, "inflation"):
            row.update({self.inflation: self.inflation_last_date.strftime("%Y-%m")})
        rows_list.append(row)
        # last data date
        row = {x: self.last_date.strftime("%Y-%m") for x in df.columns}
        row.update(period=None, property="Common last data date")
        rows_list.append(row)
        # Create DataFrame from list of rows
        description = pd.DataFrame(rows_list)
        # rename columns
        if hasattr(self, "inflation"):
            description.rename(columns={self.inflation: "inflation"}, inplace=True)
            description = helpers.Frame.change_columns_order(description, ["inflation"], position="last")
        description = helpers.Frame.change_columns_order(description, ["property", "period"], position="first")
        if not tickers:
            for ti in self.symbols:
                # short_ticker = ti.split(".", 1)[0]
                description.rename(columns={ti: self.names[ti]}, inplace=True)
        return description

    @property
    def mean_return(self) -> pd.Series:
        """
        Calculate annualized mean return (arithmetic mean) for the rate of return time series (each asset).

        Mean return calculated for the full history period. Arithmetic mean for the inflation is also shown
        if there is an `inflation=True` option in AssetList.

        Returns
        -------
        Series
            Mean return value for each asset.

        Examples
        --------
        >>> x = ok.AssetList(['MCFTR.INDX', 'RGBITR.INDX'], ccy='RUB', inflation=True)
        >>> x.mean_return
        MCFTR.INDX     0.209090
        RGBITR.INDX    0.100133
        dtype: float64
        """
        mean = self.assets_ror.mean()
        return mean * settings._MONTHS_PER_YEAR

    @property
    def real_mean_return(self) -> pd.Series:
        """
        Calculate annualized real mean return (arithmetic mean) for the rate of return time series (each assets).

        Real rate of return is adjusted for inflation. Real return is defined if
        there is an `inflation=True` option in AssetList.

        Returns
        -------
        Series
            Mean real return value for each asset.

        Examples
        --------
        >>> x = ok.AssetList(['MCFTR.INDX', 'RGBITR.INDX'], ccy='RUB', inflation=True)
        >>> x.real_mean_return
        MCFTR.INDX     0.118116
        RGBITR.INDX    0.017357
        dtype: float64
        """
        # TODO: make a single method with mean_return
        if not hasattr(self, "inflation"):
            raise ValueError("Real Return is not defined. Set inflation=True to calculate.")
        df = pd.concat([self.assets_ror, self.inflation_ts], axis=1, join="inner", copy="false")
        infl_mean = self.inflation_ts.values.mean() * settings._MONTHS_PER_YEAR
        ror_mean = df.loc[:, self.symbols].mean() * settings._MONTHS_PER_YEAR
        return (1.0 + ror_mean) / (1.0 + infl_mean) - 1.0

    @property
    def dividend_yield(self):
        """
        Calculate last twelve months (LTM) dividend yield time series (monthly) for each asset.

        LTM dividend yield is the sum trailing twelve months of common dividends per share divided by
        the current price per share.

        All yields are calculated in the asset list base currency after adjusting the dividends and price time series.
        Forecasted (future) dividends are removed.
        Zero value time series are created for assets without dividends.

        Returns
        -------
        DataFrame
            Time series of LTM dividend yield for each asset.

        See Also
        --------
        dividend_yield_annual : Calendar year dividend yield time series.
        dividends_annual : Calendar year dividends time series.
        dividend_paying_years : Number of years of consecutive dividend payments.
        dividend_growing_years : Number of years when the annual dividend was growing.
        get_dividend_mean_yield : Arithmetic mean for annual dividend yield.
        get_dividend_mean_growth_rate : Geometric mean of annual dividends growth rate.

        Examples
        --------
        >>> x = ok.AssetList(['T.US', 'XOM.US'], first_date='1984-01', last_date='1994-12')
        >>> x.dividend_yield
                   T.US    XOM.US
        1984-01  0.000000  0.000000
        1984-02  0.000000  0.002597
        1984-03  0.002038  0.002589
        1984-04  0.001961  0.002346
                   ...       ...
        1994-09  0.018165  0.012522
        1994-10  0.018651  0.011451
        1994-11  0.018876  0.012050
        1994-12  0.019344  0.011975
        [132 rows x 2 columns]
        """
        return super()._assets_dividend_yield

    @property
    def dividends_annual(self) -> pd.DataFrame:
        """
        Return calendar year dividends sum time series for each asset.

        Returns
        -------
        DataFrame
            Annual dividends time series for each asset.

        See Also
        --------
        dividend_yield : Dividend yield time series.
        dividend_yield_annual : Calendar year dividend yield time series.
        dividend_paying_years : Number of years of consecutive dividend payments.
        dividend_growing_years : Number of years when the annual dividend was growing.
        get_dividend_mean_yield : Arithmetic mean for annual dividend yield.
        get_dividend_mean_growth_rate : Geometric mean of annual dividends growth rate.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['T.US', 'XOM.US'], first_date='2010-01', last_date='2020-12')
        >>> x.dividends_annual.plot(kind='bar')
        >>> plt.show()
        """
        return self._get_assets_dividends().resample("Y").sum()

    @property
    def dividend_yield_annual(self):
        """
        Calculate last twelve months (LTM) dividend yield annual time series.

        Time series is based on the dividend yield for the end of calendar year.

        LTM dividend yield is the sum trailing twelve months of common dividends per share divided by
        the current price per share.

        All yields are calculated in the asset list base currency after adjusting the dividends and price time series.
        Forecasted (future) dividends are removed.

        Returns
        -------
        DataFrame
            Time series of LTM dividend yield for each asset.

        See Also
        --------
        dividend_yield : Dividend yield time series.
        dividends_annual : Calendar year dividends time series.
        dividend_paying_years : Number of years of consecutive dividend payments.
        dividend_growing_years : Number of years when the annual dividend was growing.
        get_dividend_mean_yield : Arithmetic mean for annual dividend yield.
        get_dividend_mean_growth_rate : Geometric mean of annual dividends growth rate.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['T.US', 'XOM.US'], first_date='2010-01', last_date='2020-12')
        >>> x.dividend_yield_annual.plot(kind='bar')
        >>> plt.show()
        """
        return self._assets_dividend_yield.resample(rule="Y").last()

    @property
    def dividend_growing_years(self) -> pd.DataFrame:
        """
        Return the number of years when the annual dividend was growing for each asset.

        Returns
        -------
        DataFrame
            Dividend growth length periods time series for each asset.

        See Also
        --------
        dividend_yield : Dividend yield time series.
        dividend_yield_annual : Calendar year dividend yield time series.
        dividends_annual : Calendar year dividends.
        dividend_paying_years : Number of years of consecutive dividend payments.
        get_dividend_mean_yield : Arithmetic mean for annual dividend yield.
        get_dividend_mean_growth_rate : Geometric mean of annual dividends growth rate.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['T.US', 'XOM.US'], first_date='1984-01', last_date='1994-12')
        >>> x.dividend_growing_years.plot(kind='bar')
        >>> plt.show()
        """
        div_growth = self.dividends_annual.pct_change()[1:]
        df = pd.DataFrame()
        for name in div_growth:
            s = div_growth[name]
            s1 = s.where(s > 0).notnull().astype(int)
            s1_1 = s.where(s > 0).isnull().astype(int).cumsum()
            s2 = s1.groupby(s1_1).cumsum()
            df = pd.concat([df, s2], axis=1, copy="false")
        return df

    @property
    def dividend_paying_years(self) -> pd.DataFrame:
        """
        Return the number of years of consecutive dividend payments for each asset.

        Returns
        -------
        DataFrame
            Dividend payment period length time series for each asset.

        See Also
        --------
        dividend_yield : Dividend yield time series.
        dividend_yield_annual : Calendar year dividend yield time series.
        dividends_annual : Calendar year dividends.
        dividend_growing_years : Number of years when the annual dividend was growing.
        get_dividend_mean_yield : Arithmetic mean for annual dividend yield.
        get_dividend_mean_growth_rate : Geometric mean of annual dividends growth rate.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['T.US', 'XOM.US'], first_date='1984-01', last_date='1994-12')
        >>> x.dividend_paying_years.plot(kind='bar')
        >>> plt.show()
        """
        div_annual = self.dividends_annual
        frame = pd.DataFrame()
        df = frame
        for name in div_annual:
            s = div_annual[name]
            s1 = s.where(s != 0).notnull().astype(int)
            s1_1 = s.where(s != 0).isnull().astype(int).cumsum()
            s2 = s1.groupby(s1_1).cumsum()
            df = pd.concat([df, s2], axis=1, copy="false")
        return df

    def get_dividend_mean_growth_rate(self, period: int = 5) -> pd.Series:
        """
        Calculate geometric mean of annual dividends growth rate time series for a given trailing period.

        Growth rate is taken for full calendar annual dividends.

        Parameters
        ----------
        period : int, default 5
            Growth rate trailing period in years. Period should be a positive integer
            and not exceed the available data period_length.

        Returns
        -------
        Series
            Dividend growth geometric mean value for each asset.

        See Also
        --------
        dividend_yield : Dividend yield time series.
        dividend_yield_annual : Calendar year dividend yield time series.
        dividends_annual : Calendar year dividends.
        dividend_paying_years : Number of years of consecutive dividend payments.
        dividend_growing_years : Number of years when the annual dividend was growing.
        get_dividend_mean_yield : Arithmetic mean for annual dividend yield.

        Examples
        --------
        >>> x = ok.AssetList(['T.US', 'XOM.US'], first_date='1984-01', last_date='1994-12')
        >>> x.get_dividend_mean_growth_rate(period=3)
        T.US      0.020067
        XOM.US    0.024281
        dtype: float64
        """
        self._validate_period(period)
        growth_ts = self.dividends_annual.pct_change().iloc[1:-1]  # Slice the last year for full dividends
        growth_ts.replace([np.inf, -np.inf, np.nan], 0, inplace=True)  # replace possible nan and inf
        dt0 = self.last_date
        dt = helpers.Date.subtract_years(dt0, period)
        return ((growth_ts[dt:] + 1.0).prod()) ** (1 / period) - 1.0

    def get_dividend_mean_yield(self, period: int = 5) -> pd.Series:
        """
        Calculate the arithmetic mean for annual dividend yield (LTM) over a specified period.

        Dividend yield is taken for full calendar annual dividends.

        Parameters
        ----------
        period : int, default 5
            Mean dividend yield trailing period in years. Period should be a positive integer
            and not exceed the available data period_length.

        Returns
        -------
        Series
            Mean dividend yield value for each asset.

        See Also
        --------
        dividend_yield : Dividend yield time series.
        dividend_yield_annual : Calendar year dividend yield time series.
        dividends_annual : Calendar year dividends.
        get_dividend_mean_growth_rate : Geometric mean of annual dividends growth rate.
        dividend_paying_years : Number of years of consecutive dividend payments.
        dividend_growing_years : Number of years when the annual dividend was growing.

        Examples
        --------
        >>> al = ok.AssetList(["SBERP.MOEX", "LKOH.MOEX"], ccy='RUB', first_date='2005-01', last_date='2023-12')
        >>> al.get_dividend_mean_yield(period=3)
        SBERP.MOEX    0.052987
        LKOH.MOEX     0.156526
        dtype: float64
        """

        self._validate_period(period)
        dt0 = self.last_date
        dt = helpers.Date.subtract_years(dt0, period)
        return self.dividend_yield_annual[dt:].mean()

    # index methods
    def tracking_difference(self, rolling_window=None) -> pd.DataFrame:
        """
        Return tracking difference for the rate of return of assets.

        Tracking difference is calculated by measuring the accumulated difference between the returns of a benchmark
        and those of the ETF replicating it (could be mutual funds, or other types of assets). Tracking difference is
        measured in percents.

        Benchmark should be in the first position of the symbols list in AssetList parameters.

        Parameters
        ----------
        rolling_window : int or None, default None
            Size of the moving window in months.
            If None calculate expanding tracking difference.

        Returns
        -------
        DataFrame
            Tracking diffirence time series for each asset.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SP500TR.INDX', 'SPY.US', 'VOO.US'], last_date='2021-01')
        >>> x.tracking_difference().plot()
        >>> plt.show()

        To calculate rolling Tracking difference set `rolling_window` to a number of months (moving window size):

        >>> x.tracking_difference(rolling_window = 24).plot()
        >>> plt.show()
        """
        if rolling_window:
            rolling_cum_return = helpers.Frame.get_rolling_fn(
                self.assets_ror,
                window=rolling_window,
                fn=helpers.Frame.get_cumulative_return,
                window_below_year=True,  # small windows below 12 months are allowed
            )
            return rolling_cum_return.subtract(rolling_cum_return.iloc[:, 0], axis=0).iloc[:, 1:]
        else:
            accumulated_return = helpers.Frame.get_wealth_indexes(self.assets_ror)  # we don't need inflation here
            return helpers.Index.tracking_difference(accumulated_return)

    def tracking_difference_annualized(self, rolling_window: Optional[int] = None) -> pd.DataFrame:
        """
        Calculate annualized tracking difference time series for the rate of return of assets.

        Tracking difference is calculated by measuring the accumulated difference between the returns of a benchmark
        and ETFs replicating it (could be mutual funds, or other types of assets). Tracking difference is
        measured in percents.

        Benchmark should be in the first position of the symbols list in AssetList parameters.

        Annual values are available for history periods of more than 12 months.
        Returns for less than 12 months can't be annualized According to the CFA
        Institute's Global Investment Performance Standards (GIPS).

        Parameters
        ----------
        rolling_window : int or None, default None
            Size of the moving window in months. Must be at least 12 months.
            If None calculate expanding annualized tracking difference.

        Returns
        -------
        DataFrame
            Annualized tracking diffirence time series for each asset.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SP500TR.INDX', 'SPY.US', 'VOO.US'], last_date='2021-01')
        >>> x.tracking_difference_annualized().plot()

        To calculate rolling annualized tracking difference set `rolling_window` to a number of months (moving window size):

        >>> x.tracking_difference_annualized(rolling_window = 12*5).plot()
        >>> plt.show()
        """
        if rolling_window:
            rolling_cagr = helpers.Frame.get_rolling_fn(
                self.assets_ror,
                window=rolling_window,
                fn=helpers.Frame.get_cagr,
                window_below_year=False,  # small windows below 12 months are not allowed (CAGR is not defined)
            )
            return rolling_cagr.subtract(rolling_cagr.iloc[:, 0], axis=0).iloc[:, 1:]
        else:
            return helpers.Index.tracking_difference_annualized(self.tracking_difference())

    @property
    def tracking_difference_annual(self) -> pd.DataFrame:
        """
        Calculate tracking difference for each calendar year.

        Tracking difference is calculated by measuring the accumulated difference between the returns of a benchmark
        and ETFs replicating it (could be mutual funds, or other types of assets). Tracking difference is
        measured in percents.

        Benchmark should be in the first position of the symbols list in AssetList parameters.

        Returns
        -------
        DataFrame
            Time series with tracking difference for each calendar year period.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['SP500TR.INDX', 'VOO.US', 'SPXS.LSE'], inflation=False)
        >>> al.tracking_difference_annual.plot(kind='bar')
        """
        rows_list = []  # Collect all rows to concatenate once at the end
        for x in self.assets_ror.resample("Y"):
            df = x[1]
            wealth_index = helpers.Frame.get_wealth_indexes(df)
            row = helpers.Index.tracking_difference(wealth_index).iloc[[-1]]
            rows_list.append(row)
        result = pd.concat(rows_list, ignore_index=False)
        result.index = result.index.asfreq("Y")
        return result

    def tracking_error(self, rolling_window: Optional[int] = None) -> pd.DataFrame:
        """
        Calculate tracking error time series for the rate of return of assets.

        Tracking error is defined as the standard deviation of the difference between the returns of the asset
        and the returns of the benchmark. Tracking error is measured in percents.

        Benchmark should be in the first position of the symbols list in AssetList parameters.

        Parameters
        ----------
        rolling_window : int or None, default None
            Size of the moving window in months. Must be at least 12 months.
            If None calculate expanding tracking error.

        Returns
        -------
        DataFrame
            rolling or expanding tracking error time series for each asset.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> x = ok.AssetList(['SP500TR.INDX', 'SPY.US', 'VOO.US'], last_date='2021-01')
        >>> x.tracking_error().plot()
        >>> plt.show()

        To calculate rolling tracking error set `rolling_window` to a number of months (moving window size):

        >>> x.tracking_error(rolling_window = 12*5).plot()
        >>> plt.show()
        """
        if rolling_window:
            return helpers.Index.rolling_fn(
                df=self.assets_ror,
                window=rolling_window,
                fn=helpers.Index.tracking_error,
                window_below_year=False,  # small windows below 12 months are not allowed
            )
        else:
            return helpers.Index.tracking_error(self.assets_ror)

    def index_corr(self, rolling_window: Optional[int] = None) -> pd.DataFrame:
        """
        Compute correlation with the index (or benchmark) time series for the assets. Expanding or rolling correlation
        is available.

        Index (benchmark) should be in the first position of the symbols list in AssetList parameters.
        There should be at least 12 months of historical data.

        Parameters
        ----------
        rolling_window : int or None, default None
            Size of the moving window in months. Must be at least 12 months.
            If None calculate expanding correlation with index.

        Returns
        -------
        DataFrame
            Rolling or expanding correlation with the index (or benchmark) time series for each asset.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> sp = ok.AssetList(['SP500TR.INDX', 'VBMFX.US', 'GC.COMM'])
        >>> sp.names
        {'SP500TR.INDX': 'S&P 500 (TR)',
        'VBMFX.US': 'VANGUARD TOTAL BOND MARKET INDEX FUND INVESTOR SHARES',
        'GC.COMM': 'Gold'}
        >>> sp.index_corr().plot()  # expanding correlation with S&P 500
        >>> plt.show()

        To calculate rolling correlation with S&P 500 set `rolling_window` to a number of months (moving window size):

        >>> sp.index_corr(rolling_window=24).plot()
        >>> plt.show()
        """
        if rolling_window:
            return helpers.Index.rolling_cov_cor(self.assets_ror, window=rolling_window, fn="corr")
        return helpers.Index.expanding_cov_cor(self.assets_ror, fn="corr")

    def index_beta(self, rolling_window: Optional[int] = None) -> pd.DataFrame:
        """
        Compute beta coefficient time series for the assets.

        Beta coefficient is defined in Capital Asset Pricing Model (CAPM). It is a measure of how
        an individual asset moves (on average) when the benchmark increases or decreases. When beta is positive,
        the asset price tends to move in the same direction as the benchmark,
        and the magnitude of beta tells by how much.

        Index (benchmark) should be in the first position of the symbols list in AssetList parameters.
        There should be at least 12 months of historical data.

        Parameters
        ----------
        rolling_window : int or None, default None
            Size of the moving window in months. Must be at least 12 months.
            If None calculate expanding beta coefficient.

        Returns
        -------
        DataFrame
            rollinf or expanding beta coefficient time series for each asset.

        See Also
        --------
        index_corr : Compute correlation with the index (or benchmark).
        index_rolling_corr : Compute rolling correlation with the index (or benchmark).
        index_beta : Compute beta coefficient.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> sp = ok.AssetList(['SP500TR.INDX', 'VBMFX.US', 'GC.COMM', 'VNQ.US'])
        >>> sp.names
        {'SP500TR.INDX': 'S&P 500 (TR)',
        'VBMFX.US': 'VANGUARD TOTAL BOND MARKET INDEX FUND INVESTOR SHARES',
        'GC.COMM': 'Gold',
        'VNQ.US': 'Vanguard Real Estate Index Fund ETF Shares'}
        >>> sp.index_beta().plot()
        >>> plt.show()

        To calculate rolling beta set `rolling_window` to a number of months (moving window size):

        >>> sp.index_beta(rolling_window = 12 * 5).plot()  # 5 years moving window
        >>> plt.show()
        """
        if rolling_window:
            return helpers.Index.rolling_fn(
                df=self.assets_ror,
                window=rolling_window,
                fn=helpers.Index.beta,
                window_below_year=False,  # small windows below 12 months are not allowed
            )
        return helpers.Index.beta(self.assets_ror)

    # TODO: add index_alpha() method
    # TODO: add index_information_ratio() method

    # distributions
    @property
    def skewness(self) -> pd.DataFrame:
        """
        Compute expanding skewness of the return time series for each asset returns.

        Skewness is a measure of the asymmetry of the probability distribution
        of a real-valued random variable about its mean. The skewness value can be positive, zero, negative,
        or undefined.

        For normally distributed returns, the skewness should be about zero.
        A skewness value greater than zero means that there is more weight in the right tail of the distribution.

        Returns
        -------
        Dataframe
            Expanding skewness time series for each asset.

        See Also
        --------
        skewness_rolling : Compute rolling skewness.
        kurtosis : Calculate expanding Fisher (normalized) kurtosis.
        kurtosis_rolling : Calculate rolling Fisher (normalized) kurtosis.
        jarque_bera : Perform Jarque-Bera test for normality.
        kstest : Perform Kolmogorov-Smirnov test for different types of distributions.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['VFINX.US', 'GC.COMM'], last_date='2021-01')
        >>> al.names
        {'VFINX.US': 'VANGUARD 500 INDEX FUND INVESTOR SHARES',
        'GC.COMM': 'Gold'}
        >>> al.skewness.plot()
        >>> plt.show()
        """
        return helpers.Frame.skewness(self.assets_ror)

    def skewness_rolling(self, window: int = 60) -> pd.DataFrame:
        """
        Compute rolling skewness of the return time series for each asset.

        Skewness is a measure of the asymmetry of the probability distribution
        of a real-valued random variable about its mean. The skewness value can be positive, zero, negative,
        or undefined.

        For normally distributed returns, the skewness should be about zero.
        A skewness value greater than zero means that there is more weight in the right tail of the distribution.

        Parameters
        ----------
        window : int, default 60
            Rolling window size in months. This is the number of observations used for calculating the statistic.
            The window size should be at least 12 months.

        Returns
        -------
        DataFrame
            Rolling skewness time series for each asset.

        See Also
        --------
        skewness : Compute skewness.
        kurtosis : Calculate expanding Fisher (normalized) kurtosis.
        kurtosis_rolling : Calculate rolling Fisher (normalized) kurtosis.
        jarque_bera : Perform Jarque-Bera test for normality.
        kstest : Perform Kolmogorov-Smirnov test for different types of distributions.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['VFINX.US', 'GC.COMM'], last_date='2021-01')
        >>> al.names
        {'VFINX.US': 'VANGUARD 500 INDEX FUND INVESTOR SHARES',
        'GC.COMM': 'Gold'}
        >>> al.skewness_rolling(window=12*5).plot()
        >>> plt.show()
        """
        return helpers.Frame.skewness_rolling(self.assets_ror, window=window)

    @property
    def kurtosis(self) -> pd.DataFrame:
        """
        Calculate expanding Fisher (normalized) kurtosis of the return time series for each asset.

        Kurtosis is the fourth central moment divided by the square of the variance. It is a measure of the "tailedness"
        of the probability distribution of a real-valued random variable.

        Kurtosis should be close to zero for normal distribution.

        Returns
        -------
        DataFrame
            Expanding kurtosis time series for each asset.

        See Also
        --------
        skewness : Compute skewness.
        skewness_rolling : Compute rolling skewness.
        kurtosis_rolling : Calculate rolling Fisher (normalized) kurtosis.
        jarque_bera : Perform Jarque-Bera test for normality.
        kstest : Perform Kolmogorov-Smirnov test for different types of distributions.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['GC.COMM', 'FNER.INDX'], first_date='2000-01', last_date='2021-01')
        >>> al.names
        {'GC.COMM': 'Gold',
        'FNER.INDX': 'FTSE NAREIT All Equity REITs'}
        >>> al.kurtosis.plot()
        >>> plt.show()
        """
        return helpers.Frame.kurtosis(self.assets_ror)

    def kurtosis_rolling(self, window: int = 60):
        """
        Calculate rolling Fisher (normalized) kurtosis of the return time series for each asset.

        Kurtosis is the fourth central moment divided by the square of the variance. It is a measure of the "tailedness"
        of the probability distribution of a real-valued random variable.

        Kurtosis should be close to zero for normal distribution.

        Parameters
        ----------
        window : int, default 60
            Rolling window size in months. This is the number of observations used for calculating the statistic.
            The window size should be at least 12 months.

        Returns
        -------
        DataFrame
            Rolling kurtosis time series for each asset.

        See Also
        --------
        skewness : Compute skewness.
        skewness_rolling : Compute rolling skewness.
        kurtosis : Calculate expanding Fisher (normalized) kurtosis.
        jarque_bera : Perform Jarque-Bera test for normality.
        kstest : Perform Kolmogorov-Smirnov test for different types of distributions.

        Examples
        --------
        >>> import matplotlib.pyplot as plt
        >>> al = ok.AssetList(['GC.COMM', 'FNER.INDX'], first_date='2000-01', last_date='2021-01')
        >>> al.names
        {'GC.COMM': 'Gold',
        'FNER.INDX': 'FTSE NAREIT All Equity REITs'}
        >>> al.kurtosis_rolling(window=12*5).plot()
        >>> plt.show()
        """
        return helpers.Frame.kurtosis_rolling(self.assets_ror, window=window)

    @property
    def jarque_bera(self) -> pd.DataFrame:
        """
        Perform Jarque-Bera test for normality of assets returns historical data.

        Jarque-Bera test shows whether the returns have the skewness and kurtosis
        matching a normal distribution (null hypothesis or H0).

        Returns
        -------
        DataFrame
            Returns test statistic and the p-value for the hypothesis test.
            Large Jarque-Bera statistics and tiny p-value (< 0.05) indicate that null hypothesis (H0) is rejected and
            the time series is not normally distributed.
            Low statistic numbers correspond to normal distribution.

        See Also
        --------
        skewness : Compute skewness.
        skewness_rolling : Compute rolling skewness.
        kurtosis : Calculate expanding Fisher (normalized) kurtosis.
        kurtosis_rolling : Calculate rolling Fisher (normalized) kurtosis.
        kstest : Perform Kolmogorov-Smirnov test for different types of distributions.

        Examples
        --------
        >>> al = ok.AssetList(['GC.COMM', 'FNER.INDX'], first_date='2000-01', last_date='2021-01')
        >>> al.names
        {'GC.COMM': 'Gold',
        'FNER.INDX': 'FTSE NAREIT All Equity REITs'}
        >>> al.jarque_bera
                    GC.COMM   FNER.INDX
        statistic  4.507287  593.633047
        p-value    0.105016    0.000000

        Gold return time series (GC.COMM) distribution have small p-values (H0 is not rejected).
        Null hypothesis (H0) is rejected for FTSE NAREIT Index (FNER.INDX) as Jarque-Bera test shows very small p-value
        and large statistic.
        """
        return helpers.Frame.jarque_bera_dataframe(self.assets_ror)

    def kstest(self, distr: str = "norm") -> pd.DataFrame:
        """
        Perform Kolmogorov-Smirnov test for goodness of fit the asset returns to a given distribution.

        Kolmogorov-Smirnov is a test of the distribution of assets returns historical data against a
        given distribution. Under the null hypothesis (H0), the two distributions are identical.

        Parameters
        ----------
        distr : {'norm', 'lognorm', 't'}, default 'norm'
            Distribution type for the rate of return of portfolio.
            'norm' - for normal distribution.
            'lognorm' - for lognormal distribution.
            't' - for Student's T distribution.

        Returns
        -------
        DataFrame
            Returns test statistic and the p-value for the hypothesis test.
            Large test statistics and tiny p-value (< 0.05) indicate that null hypothesis (H0) is rejected.

        Examples
        --------
        >>> al = ok.AssetList(['EDV.US'], last_date='2021-01')
        >>> al.kstest(distr='lognorm')
                     EDV.US
        p-value    0.402179
        statistic  0.070246

        H0 is not rejected for EDV ETF and it seems to have lognormal distribution.
        """
        return helpers.Frame.kstest_dataframe(self.assets_ror, distr=distr)

    def get_sharpe_ratio(self, rf_return: float = 0) -> pd.Series:
        """
        Calculate Sharpe ratio for the assets.

        The Sharpe ratio is the average annual return in excess of the risk-free rate
        per unit of risk (annualized standard deviation).

        Risk-free rate should be taken according to the AssetList base currency.

        Parameters
        ----------
        rf_return : float, default 0
            Risk-free rate of return.

        Returns
        -------
        pd.Series

        Examples
        --------
        >>> al = ok.AssetList(['VOO.US', 'BND.US'])
        >>> al.get_sharpe_ratio(rf_return=0.02)
        VOO.US    0.962619
        BND.US    0.390814
        dtype: float64
        """
        mean_return = self.mean_return
        risk = self.risk_annual.iloc[-1, :]
        return ratios.get_sharpe_ratio(pf_return=mean_return, rf_return=rf_return, std_deviation=risk)

    def get_sortino_ratio(self, t_return: float = 0) -> pd.Series:
        """
        Calculate Sortino ratio for the assets with specified target return.

        Sortion ratio measures the risk-adjusted return of each asset. It is a modification of the Sharpe ratio
        but penalizes only those returns falling below a specified target rate of return, while
        the Sharpe ratio penalizes both upside and downside volatility equally.

        Parameters
        ----------
        t_return : float, default 0
            Traget rate of return.

        Returns
        -------
        pd.Series

        Examples
        --------
        >>> al = ok.AssetList(['VOO.US', 'BND.US'], last_date='2021-12')
        >>> al.get_sortino_ratio(t_return=0.03)
        VOO.US    1.321951
        BND.US    0.028969
        dtype: float64
        """
        mean_return = self.mean_return
        semideviation = helpers.Frame.get_below_target_semideviation(ror=self.assets_ror, t_return=t_return) * 12**0.5
        return ratios.get_sortino_ratio(pf_return=mean_return, t_return=t_return, semi_deviation=semideviation)
