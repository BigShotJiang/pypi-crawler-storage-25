"""Atomic effects (put, go, …)."""
