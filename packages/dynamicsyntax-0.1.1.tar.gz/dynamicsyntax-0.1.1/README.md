# dynamicsyntax

Python 3.13 port of the **DyLan** Dynamic Syntax parser core (Java `qmul.ds`). PyPI distribution name: **`dynamicsyntax`**.

## Install (from PyPI)

```bash
pip install dynamicsyntax
```

Quick API (bundled **2015-english-ttr** grammar when using `backend="ttr"`):

```python
import dynamicsyntax as ds

semantics = ds.parse("a man arrives", "ttr")
print(semantics)
```

The low-level implementation modules live under **`dylan`** (for example `InteractiveContextParser`, `TTRRecordType`); `import dylan` remains supported for advanced use.

Optional extras: `pip install dynamicsyntax[gui]` (Flet desktop), `[nlp]`, `[viz]`.

Console entry points: `dylan-gui` and `dynamicsyntax-gui` (same app).

## Install (development)

```bash
cd dynamicsyntax
uv sync
uv run pytest
```

Optional NLP tokenizers:

```bash
uv sync --extra nlp
```

## Scope

- Working **parser** path: grammar/lexicon resource loading, `InteractiveContextParser`, `parseUtterance`, and the `dynamicsyntax.parse` facade over a bundled grammar snapshot.
- **Not** ported: probabilistic generators, `Feature`, learner GUI stack.

## Publishing (maintainers)

```bash
uv build
uv publish   # requires PyPI API token; try TestPyPI first with --publish-url
```

## License

DyLan upstream license applies to ported logic; see `LICENSE` if copied from the Java project.
