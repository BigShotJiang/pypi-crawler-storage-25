"""
Sandflare Python SDK
====================
Sandbox — Compute VM for AI agents (sb-N) backed by Firecracker microVMs.

Quick start:
    from sandflare import Sandbox

    # Create a sandbox
    sb = Sandbox.create("agent")

    # Run Python code in the sandbox
    result = sb.run_python('''
        print("Hello from the sandbox!")
    ''')
    print(result.stdout)

    # Clean up
    sb.delete()
"""
from __future__ import annotations

__version__ = "2.1.0"

import http.client
import json
import os
import pathlib
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import base64
import shlex
from dataclasses import dataclass, field
from typing import Any, AsyncGenerator, Generator, Optional, Union

DEFAULT_BASE_URL = "https://api.sandflare.io"

# ---------------------------------------------------------------------------
# Connection pool — per-thread HTTPS connections to avoid thread-safety issues
# ---------------------------------------------------------------------------

_thread_local = threading.local()
_ssl_ctx = ssl.create_default_context()


def _get_conn(host: str, port: int) -> http.client.HTTPSConnection:
    """Return a per-thread HTTPS connection, creating one if needed."""
    if not hasattr(_thread_local, "pool"):
        _thread_local.pool = {}
    key = f"{host}:{port}"
    conn = _thread_local.pool.get(key)
    if conn is None:
        conn = http.client.HTTPSConnection(host, port, context=_ssl_ctx, timeout=60)
        _thread_local.pool[key] = conn
    return conn


def _http_request(method: str, url: str, body: bytes | None,
                  headers: dict, timeout: int) -> tuple[int, bytes]:
    """Perform an HTTP/HTTPS request, reusing per-thread connections."""
    parsed = urllib.parse.urlparse(url)
    host = parsed.hostname or ""
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    hdrs = dict(headers)
    hdrs.setdefault("Connection", "keep-alive")

    key = f"{host}:{port}"

    for attempt in range(2):  # retry once on stale connection
        conn = _get_conn(host, port)
        conn.timeout = timeout
        try:
            conn.request(method, path, body=body, headers=hdrs)
            resp = conn.getresponse()
            data = resp.read()
            if resp.status == 502 and attempt == 0:
                # 502 Bad Gateway — stale upstream connection. Refresh and retry.
                try:
                    conn.close()
                except Exception:
                    pass
                _thread_local.pool[key] = http.client.HTTPSConnection(host, port, context=_ssl_ctx, timeout=60)
                continue
            return resp.status, data
        except (http.client.RemoteDisconnected, http.client.CannotSendRequest,
                http.client.NotConnected, ConnectionResetError,
                BrokenPipeError, OSError):
            # Connection was stale — close and retry with fresh one
            try:
                conn.close()
            except Exception:
                pass
            _thread_local.pool[key] = http.client.HTTPSConnection(host, port, context=_ssl_ctx, timeout=60)
            if attempt == 1:
                raise


def _first_env(*names: str) -> str:
    for name in names:
        value = os.environ.get(name, "")
        if value:
            return value
    return ""


def _resolve_base_url(base_url: str | None = None) -> str:
    return (base_url or _first_env("SANDFLARE_API_URL", "PANDAAGENT_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")


def _resolve_api_key(api_key: str | None = None) -> str:
    return api_key or _first_env("SANDFLARE_API_KEY", "PANDAAGENT_API_KEY", "AGENTBOX_API_KEY")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ExecResult:
    exit_code: int
    stdout:    str
    stderr:    str
    ok:        bool

    def __str__(self):
        parts = [f"exit_code={self.exit_code}"]
        if self.stdout:
            parts.append(f"stdout={self.stdout[:200]!r}")
        if self.stderr:
            parts.append(f"stderr={self.stderr[:200]!r}")
        return f"ExecResult({', '.join(parts)})"

    def raise_on_error(self):
        if not self.ok:
            raise RuntimeError(
                f"Command failed (exit {self.exit_code}):\n{self.stderr or self.stdout}"
            )
        return self


@dataclass
class CodeResult:
    """Result from run_code() — stateful kernel execution."""
    text:   str | None   # last expression value (e.g. "42", "DataFrame(...)")
    stdout: str          # print() output
    stderr: str          # stderr output
    png:    str | None   # base64-encoded PNG if a matplotlib plot was generated
    html:   str | None   # HTML output (reserved for future use)
    error:  str | None   # full traceback if execution raised an exception
    ok:     bool         # True if no exception was raised

    def raise_on_error(self):
        if not self.ok:
            raise RuntimeError(f"Kernel execution failed:\n{self.error or self.stderr}")
        return self

    def save_png(self, path: str) -> bool:
        """Save the base64 PNG to a file. Returns True if a plot was saved."""
        import base64 as _b64
        if not self.png:
            return False
        with open(path, "wb") as f:
            f.write(_b64.b64decode(self.png))
        return True


@dataclass
class FileEntry:
    name:   str
    path:   str
    is_dir: bool
    size:   int
    mtime:  int


class SandflareError(Exception):
    def __init__(self, status: int, message: str, body: dict):
        super().__init__(f"HTTP {status}: {message}")
        self.status  = status
        self.message = message
        self.body    = body


AgentBoxError = SandflareError


class TierLimitError(SandflareError):
    """Raised when a request exceeds the plan's resource limits (HTTP 429)."""
    def __init__(self, message: str, body: dict):
        super().__init__(429, message, body)
        self.upgrade_url = body.get("upgrade_url", "https://app.sandflare.io/upgrade")

    def __str__(self):
        return (
            f"\n  ⚠️  Plan limit reached: {self.message}\n"
            f"  → Upgrade at: {self.upgrade_url}\n"
        )


class AuthError(SandflareError):
    """Raised on authentication failure (HTTP 401/403)."""
    def __init__(self, message: str, body: dict):
        super().__init__(403, message, body)


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _req(method: str, url: str, body: Any = None, headers: dict | None = None,
         timeout: int = 35) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    hdrs: dict[str, str] = {
        "Content-Type": "application/json",
        "User-Agent": "sandflare-sdk/1.0",
    } if data else {"User-Agent": "sandflare-sdk/1.0"}
    if headers:
        hdrs.update(headers)
    try:
        status, raw = _http_request(method, url, data, hdrs, timeout)
    except OSError as e:
        raise SandflareError(0, str(e), {}) from e

    try:
        parsed_url = urllib.parse.urlparse(url)
        if b"error code: 1010" in raw or (status >= 400 and b"<!doctype html" in raw.lower()):
            raise AuthError(
                "Request blocked — check your API key and ensure you are using the sandflare-sdk/1.0 User-Agent",
                {"error": "cloudflare_block"}
            )
        err_body = json.loads(raw) if raw else {}
    except (AuthError, TierLimitError):
        raise
    except Exception:
        err_body = {"error": raw.decode(errors="replace") if raw else ""}

    if status == 429:
        raise TierLimitError(err_body.get("error", "Resource limit exceeded"), err_body)
    if status in (401, 403):
        raise AuthError(
            err_body.get("error", "Unauthorized — check your SANDFLARE_API_KEY (or legacy AGENTBOX_API_KEY)"),
            err_body,
        )
    if status >= 400:
        raise SandflareError(status, err_body.get("error", f"HTTP {status}"), err_body)
    return json.loads(raw) if raw else {}


@dataclass
class SnapshotInfo:
    name:               str
    created_at:         str | None = None
    size_mb:            float | None = None
    vmstate:            str | None = None
    mem:                str | None = None
    # Advanced snapshot fields
    snapshot_id:        str = ""
    id:                 str = ""  # Alias for snapshot_id
    sandbox_id:         str = ""
    build_id:           str = ""
    status:             str = "uploading"
    description:        str | None = None
    tags:               list = field(default_factory=list)
    fork_count:         int = 0
    parent_snapshot_id: str | None = None
    auto_created:       bool = False
    raw:                dict = field(default_factory=dict)

    def __repr__(self):
        sid = self.snapshot_id or self.name
        return f"SnapshotInfo(id={sid!r}, status={self.status!r})"


# ---------------------------------------------------------------------------
# Sandbox — wraps /sandboxes/sb-N
# ---------------------------------------------------------------------------

@dataclass
class SandboxInfo:
    name:        str
    ip:          str
    agent_port:  int
    agent_url:   str
    status:      str
    memory_mb:   int
    vcpus:       int
    root_gb:     int
    public_url:  str = ""
    panel_url:   str = ""
    preview_url: str | None = None
    preview_port: int | None = None
    subdomain:   str | None = None
    subdomain_url: str | None = None
    template_id: str | None = None
    expires_at:  str | None = None
    ttl_hours:   int = 0
    label:       str = ""
    ephemeral:   bool = False
    size:        str = "nano"
    tier:        str | None = None
    metadata:    dict = field(default_factory=dict)
    raw:         dict = field(default_factory=dict)


@dataclass
class StreamEvent:
    """A single SSE event from a streaming exec call."""
    event:     str       = ""
    data:      Any       = field(default_factory=dict)
    type:      str       = ""
    exit_code: int | None = None

    @property
    def line(self) -> str:
        """Convenience: return stdout/stderr line text."""
        if isinstance(self.data, dict):
            return self.data.get("line", "")
        return str(self.data)

    def __str__(self):
        return f"StreamEvent(event={self.event!r}, type={self.type!r}, data={self.data})"


@dataclass
class ProcessInfo:
    pid:            int
    command:        str
    cpu_percent:    float
    memory_percent: float


@dataclass
class SandboxMetrics:
    sandbox_id:   str
    status:       str
    cpu_count:    int
    cpu_used_pct: float
    mem_total:    int
    mem_used:     int
    disk_total:   int
    disk_used:    int
    ts:           int


@dataclass
class GitCloneResult:
    path:   str
    repo:   str
    branch: str | None
    output: str


@dataclass
class TemplateBuildJob:
    id:          str
    name:        str
    status:      str  # pending | building | ready | failed
    description: str = ''
    error:       str = ''
    team_id:     str = ''
    created_at:  str = ''
    updated_at:  str = ''
    logs:        list[str] = field(default_factory=list)


class Sandbox:
    """
    An isolated compute VM for running AI agent code.

    Create:  Sandbox.create("sb-1")
    Attach:  Sandbox.get("sb-1")
    """

    def __init__(self, info: SandboxInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)
        # Sandbox-scoped memory (memories tied to this sandbox session)
        self.memory = SandboxMemory(info.name, self._base, self._api_key)

    # -- Factory --

    @classmethod
    def create(
        cls,
        label:                    str = "",
        template_id:              str = "",
        snapshot_id:              str | None = None,
        size:                     str = "nano",
        tier:                     str | None = None,   # alias for size
        ttl_hours:                int = 0,
        env:                      dict[str, str] | None = None,
        ephemeral:                bool = False,
        metadata:                 dict | None = None,
        base_url:                 str | None = None,
        api_key:                  str | None = None,
        wait:                     bool = True,
        wait_timeout:             int = 120,
        auto_snapshot_interval_mins: int = 0,
        volumes:                  "dict[str, Union['Volume', str]] | None" = None,
        # Deprecated aliases kept for backwards-compat (ignored by server)
        template:                 str = "",
    ) -> "Sandbox":
        """Provision a new compute sandbox, optionally from a snapshot.

        Args:
            label:       Human-readable name for the sandbox.
            template_id: Template to use. One of:
                         ""                 — base Ubuntu (default)
                         "code-interpreter" — Jupyter + pandas + numpy + matplotlib + scipy
            snapshot_id: Create sandbox from this snapshot ID instead of a template.
            size:        VM size. One of:
                         "nano"   — 1 vCPU, 512 MB  (Free tier max)
                         "small"  — 1 vCPU, 1 GB
                         "medium" — 2 vCPU, 2 GB
                         "large"  — 4 vCPU, 4 GB    (Pro tier max)
                         "xl"     — 4 vCPU, 8 GB    (Teams tier max)
            ttl_hours:   Hard TTL. 0 = use plan default (1h free / 24h pro / unlimited teams).
            env:         Environment variables injected into the sandbox.
            ephemeral:   If True, sandbox auto-deletes when it stops.
            auto_snapshot_interval_mins: If > 0, start auto-snapshotting immediately
                         after creation. Minimum 5 minutes.
        """
        payload: dict[str, Any] = {
            "label": label,
            "size": tier or size,  # tier is an alias for size
            "ephemeral": ephemeral,
        }
        if snapshot_id:
            payload["snapshot_id"] = snapshot_id
        if ttl_hours:
            payload["ttl_hours"] = ttl_hours
        effective_template = template_id or template
        if effective_template and not snapshot_id:
            payload["template_id"] = effective_template
        if env:
            payload["env_vars"] = env
        if metadata:
            payload["metadata"] = metadata
        if auto_snapshot_interval_mins >= 5:
            payload["auto_snapshot_interval_mins"] = auto_snapshot_interval_mins
        if volumes:
            payload["volumes"] = {
                path: (vol.id if isinstance(vol, Volume) else vol)
                for path, vol in volumes.items()
            }
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("POST", f"{resolved_base_url}/sandboxes", payload,
                   headers={"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None,
                   timeout=min(60, wait_timeout))
        sb = cls(_sb_info_from_raw(raw), base_url=resolved_base_url, api_key=key)
        if template_id:
            sb._info.template_id = template_id
        # The API already waits for agent readiness before returning 200.
        # _wait_for_agent is redundant and adds 300-500ms per create.
        if template_id and not snapshot_id:
            deadline = time.monotonic() + wait_timeout
            sb._provision_template(template_id, deadline=deadline)
        return sb

    @classmethod
    def get(cls, name: str, base_url: str | None = None,
            api_key: str | None = None) -> "Sandbox":
        """Attach to an existing sandbox."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req("GET", f"{resolved_base_url}/sandboxes/{name}",
                   headers={"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None, timeout=10)
        if raw.get("status") == "absent":
            raise SandflareError(404, f"Sandbox '{name}' not found", raw)
        return cls(_sb_info_from_raw(raw), base_url=resolved_base_url, api_key=key)

    @classmethod
    def list(cls, label: str | None = None, metadata: dict | None = None,
             base_url: str | None = None,
             api_key: str | None = None) -> list["Sandbox"]:
        """List all sandboxes, optionally filtered by label or metadata tags."""
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        url = f"{resolved_base_url}/sandboxes"
        params = []
        if label:
            params.append(f"label={urllib.parse.quote(label)}")
        if metadata:
            import json as _json
            params.append(f"metadata={urllib.parse.quote(_json.dumps(metadata))}")
        if params:
            url += "?" + "&".join(params)
        raw_list = _req("GET", url,
                        headers={"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None, timeout=10)
        return [cls(_sb_info_from_raw(r), base_url=resolved_base_url, api_key=key) for r in raw_list]

    # -- Properties --

    @property
    def id(self) -> str:
        """The sandbox ID (e.g. 'sb-3ccfa557'). Canonical identifier."""
        return self._info.name
    @property
    def name(self) -> str:
        """Alias for id — kept for backward compatibility."""
        return self._info.name

    # -- Class-level user memory (persists across all sandboxes) --
    @classmethod
    def user_memory(
        cls,
        base_url: str | None = None,
        api_key:  str | None = None,
    ) -> "UserMemory":
        """Return the user-level :class:`UserMemory` client.

        Memories stored here survive sandbox deletion and are automatically
        included in MCP ``memory_context`` when creating new sandboxes.

        Example::

            mem = Sandbox.user_memory()
            mem.add("User prefers async Python and uses black formatter")
            for m in mem.search("Python coding style"):
                print(m.memory)
        """
        return UserMemory(_resolve_base_url(base_url), _resolve_api_key(api_key))
    @property
    def label(self) -> str:
        """Human-readable label set at creation time (e.g. 'my-agent')."""
        return self._info.label
    @property
    def info(self) -> SandboxInfo: return self._info
    @property
    def agent_url(self) -> str: return self._info.agent_url
    @property
    def public_url(self) -> str: return self._info.public_url
    @property
    def panel_url(self) -> str: return self._info.panel_url
    @property
    def preview_url(self) -> str | None: return self._info.preview_url
    @property
    def preview_port(self) -> int | None: return self._info.preview_port
    @property
    def subdomain(self) -> str | None: return self._info.subdomain
    @property
    def subdomain_url(self) -> str | None: return self._info.subdomain_url
    @property
    def status(self) -> str: return self._info.status
    @property
    def metadata(self) -> dict: return self._info.raw.get("metadata") or {}

    def get_preview_url(self, port: int = 3000) -> str:
        """
        Returns the HTTPS preview URL for a specific port inside the sandbox.
        Format: https://{port}-{sandboxId}.sandflare.io/

        Example:
            sb.get_preview_url(8000)  # "https://8000-sb-abc123.sandflare.io/"
            sb.get_preview_url()      # "https://3000-sb-abc123.sandflare.io/" (default)
        """
        base = self._info.preview_url or ""
        import re
        # Strip any scheme and optional existing port prefix (e.g. "https://3000-" or "https://")
        domain = re.sub(r"^https?://(?:\d+-)?", "", base).rstrip("/")
        if not domain:
            return ""
        return f"https://{port}-{domain}/"

    # -- Code execution --

    def exec(self, cmd: str, timeout: int = 30, cwd: str = "/home/user",
             env: dict | None = None) -> ExecResult:
        """Run a shell command inside the sandbox."""
        # Inline env vars directly into the command so they work regardless of
        # whether the orchestrator supports the `env` field.
        env_prefix = ""
        if env:
            env_prefix = " ".join(
                f"export {k}={shlex.quote(str(v))};" for k, v in env.items()
            ) + " "
        wrapped_cmd = f"bash -lc {shlex.quote(f'cd {shlex.quote(cwd)} && {env_prefix}{cmd}')}"
        body: dict = {"cmd": wrapped_cmd, "timeout": timeout, "cwd": "/home/user"}
        r = self._post(f"/sandboxes/{self.name}/exec", body, timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_python(self, code: str, timeout: int = 30) -> ExecResult:
        """Execute Python 3 code inside the sandbox (stateless — each call is isolated)."""
        r = self._post(f"/sandboxes/{self.name}/run/python",
                       {"code": code, "timeout": timeout}, timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_node(self, code: str, timeout: int = 30) -> ExecResult:
        """Execute JavaScript (Node.js) code inside the sandbox (stateless).

        Requires the sandbox to be created with a Node.js-capable template:
        ``template="node"`` or ``template="fullstack"``.

        Args:
            code:    JavaScript source code to execute.
            timeout: Execution timeout in seconds. Defaults to 30.

        Returns:
            ExecResult with stdout, stderr, exit_code, ok.
        """
        r = self._post(f"/sandboxes/{self.name}/run/node",
                       {"code": code, "timeout": timeout}, timeout=timeout + 5)
        return ExecResult(exit_code=r.get("exit_code", -1), stdout=r.get("stdout", ""),
                          stderr=r.get("stderr", ""), ok=r.get("ok", False))

    def run_playwright(self, script: str, timeout: int = 60) -> ExecResult:
        """Run a Playwright browser automation script inside the sandbox.

        Playwright and Chromium are pre-installed in the ``code-interpreter`` template.
        The script runs headlessly — no display is needed.

        Args:
            script:  Python source using the ``playwright.sync_api`` or
                     ``playwright.async_api`` APIs.
            timeout: Execution timeout in seconds. Defaults to 60.

        Returns:
            ExecResult with stdout, stderr, exit_code, ok.

        Example::

            sb = Sandbox.create("code-interpreter")
            result = sb.run_playwright(\"\"\"
            from playwright.sync_api import sync_playwright

            with sync_playwright() as p:
                browser = p.chromium.launch()
                page = browser.new_page()
                page.goto("https://example.com")
                title = page.title()
                print("Title:", title)
                browser.close()
            \"\"\")
            print(result.stdout)  # "Title: Example Domain"
        """
        # Write the script to a temp file and execute it so that multi-line
        # scripts with complex indentation are not mangled by shell quoting.
        import uuid as _uuid
        script_path = f"/tmp/pw_{_uuid.uuid4().hex[:8]}.py"
        self.write_file(script_path, script)
        result = self.exec(
            f"PLAYWRIGHT_BROWSERS_PATH=/opt/playwright python3 {script_path}",
            timeout=timeout,
        )
        self.exec(f"rm -f {script_path}")
        return result

    def run_code(self, code: str, context: str = "default", timeout: int = 60) -> CodeResult:
        """Execute Python code in a **stateful** kernel — variables persist across calls.

        This is the enterprise-grade execution method. Unlike run_python(), the kernel
        maintains a shared namespace so ``x = 1`` in one call is visible as ``x`` in the next.

        Args:
            code:    Python source code to execute.
            context: Kernel context ID — use multiple contexts for isolated namespaces.
                     Defaults to "default".
            timeout: Execution timeout in seconds. Defaults to 60.

        Returns:
            CodeResult with text (last expression), stdout, stderr, png (base64 plot), error.

        Example::

            sb.run_code("x = 42")
            result = sb.run_code("x * 2")
            print(result.text)   # "84"

            # Plots are captured automatically
            r = sb.run_code("import matplotlib.pyplot as plt; plt.plot([1,2,3]); plt.show()")
            r.save_png("/tmp/plot.png")
        """
        r = self._post(
            f"/sandboxes/{self.name}/run/kernel",
            {"code": code, "context_id": context, "timeout": timeout},
            timeout=timeout + 10,
        )
        return CodeResult(
            text=r.get("text"),
            stdout=r.get("stdout", ""),
            stderr=r.get("stderr", ""),
            png=r.get("png"),
            html=r.get("html"),
            error=r.get("error"),
            ok=r.get("ok", True),
        )

    def stream(
        self, cmd: str, timeout: int = 30, cwd: str = "/home/user"
    ) -> "Generator[StreamEvent, None, None]":
        """
        Stream a shell command's output in real-time via SSE.

        Yields :class:`StreamEvent` objects as lines arrive::

            for event in sb.stream("python3 train.py"):
                if event.event in ("stdout", "stderr"):
                    print(event.line, end="", flush=True)
                elif event.event == "done":
                    print(f"\\nexited {event.exit_code}")
        """
        import http.client
        from urllib.parse import quote, urlparse as _up

        qs     = f"cmd={quote(cmd)}&timeout={timeout}&cwd={quote(cwd)}"
        parsed = _up(self._base)
        # Use Connection: close so the server closes after all SSE events are
        # sent; this lets resp.read() return instead of waiting indefinitely.
        conn   = http.client.HTTPConnection(parsed.netloc, timeout=timeout + 20)
        emitted = False
        try:
            conn.request(
                "GET", f"/sandboxes/{self.name}/exec/stream?{qs}",
                headers={
                    **self._auth_headers(),
                    "Accept": "text/event-stream",
                    "Connection": "close",
                },
            )
            resp       = conn.getresponse()
            body       = resp.read().decode("utf-8", errors="replace")
            event_type = "message"
            for line in body.splitlines():
                line = line.rstrip("\r")
                if line.startswith("event:"):
                    event_type = line[6:].strip()
                elif line.startswith("data:"):
                    data_str = line[5:].strip()
                    try:
                        data = json.loads(data_str)
                    except Exception:
                        data = {"raw": data_str}
                    emitted = True
                    ec = data.get("exit_code") if isinstance(data, dict) else None
                    yield StreamEvent(event=event_type, data=data,
                                      exit_code=ec if event_type == "done" else None)
                    event_type = "message"
        finally:
            conn.close()
        if emitted:
            return
        result = self.exec(cmd, timeout=timeout, cwd=cwd)
        for line in result.stdout.splitlines():
            yield StreamEvent(event="stdout", data={"line": line})
        for line in result.stderr.splitlines():
            yield StreamEvent(event="stderr", data={"line": line})
        yield StreamEvent(event="done", data={"exit_code": result.exit_code, "ok": result.ok},
                          exit_code=result.exit_code)

    def _provision_template(self, template_id: str, deadline: Optional[float] = None) -> None:
        _pip = "python3 -m pip install --quiet --prefer-binary --break-system-packages {pkgs}"
        _apk_or_apt = (
            "if command -v apk >/dev/null 2>&1; then apk add --no-cache {apk}; "
            "else apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y {apt}; fi"
        )

        if template_id == "code-interpreter":
            self._ensure_packages(
                verify_cmd="python3 -c \"import pandas,numpy,matplotlib,scipy\"",
                install_cmd=_pip.format(pkgs="pandas numpy matplotlib scipy"),
                timeout=600,
                label=template_id,
                deadline=deadline,
            )
            return
        if template_id == "sandbox-python":
            self._ensure_packages(
                verify_cmd="python3 -c \"import requests\"",
                install_cmd=_pip.format(pkgs="requests"),
                timeout=300,
                label=template_id,
                deadline=deadline,
            )
            return
        if template_id == "sandbox-node":
            self._ensure_packages(
                verify_cmd="command -v node",
                install_cmd=_apk_or_apt.format(apk="nodejs npm", apt="nodejs npm"),
                timeout=300,
                label=template_id,
                deadline=deadline,
            )
            return
        if template_id in ("sandbox-full", "coding-agent"):
            self._ensure_packages(
                verify_cmd="command -v git && command -v node",
                install_cmd=_apk_or_apt.format(apk="git nodejs npm", apt="git nodejs npm python3-pip"),
                timeout=300,
                label=template_id,
                deadline=deadline,
            )
            if template_id == "coding-agent":
                self._ensure_packages(
                    verify_cmd="python3 -c \"import anthropic,openai\"",
                    install_cmd=_pip.format(pkgs="anthropic openai"),
                    timeout=300,
                    label=template_id,
                    deadline=deadline,
                )
            return

    def _ensure_packages(self, verify_cmd: str, install_cmd: str, timeout: int, label: str,
                         deadline: Optional[float] = None) -> None:
        def _remaining() -> int:
            if deadline is None:
                return timeout
            remaining = int(deadline - time.monotonic())
            if remaining <= 0:
                raise SandflareError(408, f"Sandbox.create() timed out waiting for template '{label}' to provision", {})
            return min(timeout, remaining)

        verify = self._exec_template_verify(verify_cmd, _remaining(), deadline)
        if verify.ok:
            return
        install = self.exec(install_cmd, timeout=_remaining())
        if not install.ok:
            raise RuntimeError(
                f"template provisioning failed for {label}: {install.stderr or install.stdout or 'unknown error'}"
            )
        verify = self._exec_template_verify(verify_cmd, _remaining(), deadline)
        if not verify.ok:
            raise RuntimeError(
                f"template provisioning verification failed for {label}: "
                f"{verify.stderr or verify.stdout or 'packages still unavailable'}"
            )

    def _exec_template_verify(self, verify_cmd: str, timeout: int,
                              deadline: Optional[float] = None) -> ExecResult:
        last_err: Optional[AgentBoxError] = None
        for attempt in range(15):
            if deadline is not None and time.monotonic() >= deadline:
                raise SandflareError(408, "Sandbox.create() timed out during template verification", {})
            try:
                remaining = timeout if deadline is None else min(timeout, int(deadline - time.monotonic()))
                if remaining <= 0:
                    raise SandflareError(408, "Sandbox.create() timed out during template verification", {})
                return self.exec(f"{verify_cmd} >/dev/null 2>&1", timeout=remaining)
            except AgentBoxError as exc:
                if exc.status not in (408, 503) or attempt == 14:
                    raise
                last_err = exc
                time.sleep(2)
        if last_err is not None:
            raise last_err
        return self.exec(f"{verify_cmd} >/dev/null 2>&1", timeout=timeout)

    # -- File I/O --

    def write_file(self, path: str, content: str | bytes) -> None:
        """Write a file to the sandbox filesystem. Accepts str (UTF-8 encoded) or raw bytes."""
        hdrs = {**self._auth_headers(), "Content-Type": "application/octet-stream"}
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(path, safe='')}"
        data = content if isinstance(content, bytes) else content.encode("utf-8")
        status, _ = _http_request("POST", url, data, hdrs, 15)
        if status >= 400:
            raise SandflareError(status, f"write_file failed (HTTP {status})", {})

    def read_file(self, path: str) -> str:
        """Read a text file from the sandbox filesystem."""
        hdrs = self._auth_headers()
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(path, safe='')}"
        status, data = _http_request("GET", url, None, hdrs, 10)
        if status >= 400:
            raise SandflareError(status, f"read_file failed (HTTP {status})", {})
        return data.decode("utf-8", errors="replace")

    def upload(self, src: "str | bytes | os.PathLike", remote_path: str) -> None:
        """
        Upload a file to the sandbox.

        *src* can be:
        - a local file path (``str`` or ``os.PathLike``)
        - raw bytes / ``bytearray``

        Example::

            sb.upload("data.csv", "/home/user/data.csv")
            sb.upload(b"hello", "/home/user/hello.txt")
        """
        if isinstance(src, (bytes, bytearray)):
            raw = bytes(src)
        else:
            with open(src, "rb") as f:
                raw = f.read()
        hdrs = {**self._auth_headers(), "Content-Type": "application/octet-stream"}
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(remote_path, safe='')}"
        status, _ = _http_request("POST", url, raw, hdrs, 30)
        if status >= 400:
            raise SandflareError(status, f"upload failed (HTTP {status})", {})

    def download(self, remote_path: str) -> bytes:
        """
        Download a file from the sandbox as raw bytes.

        Example::

            chart_png = sb.download("/home/user/chart.png")
            with open("chart.png", "wb") as f:
                f.write(chart_png)
        """
        hdrs = self._auth_headers()
        url = f"{self._base}/sandboxes/{self.name}/files?path={urllib.parse.quote(remote_path, safe='')}"
        status, data = _http_request("GET", url, None, hdrs, 15)
        if status >= 400:
            raise SandflareError(status, f"download failed (HTTP {status})", {})
        return data

    def ls(self, path: str = "/home/user") -> list[FileEntry]:
        """List directory contents inside the sandbox."""
        hdrs = self._auth_headers()
        url = f"{self._base}/sandboxes/{self.name}/ls?path={urllib.parse.quote(path, safe='')}"
        status, data = _http_request("GET", url, None, hdrs, 10)
        if status == 404:
            return []  # empty directory or not found
        if status >= 400:
            raise SandflareError(status, f"ls failed (HTTP {status})", {})
        try:
            parsed = json.loads(data)
        except Exception:
            return []
        if isinstance(parsed, list):
            # envd returns flat array: [{name, path, type}]
            return [FileEntry(
                name=e.get("name", ""),
                path=e.get("path", ""),
                is_dir=e.get("type") in ("dir", "directory"),
                size=int(e.get("size", 0)),
                mtime=int(e.get("mtime", 0)),
            ) for e in parsed]
        # Wrapped format: {"entries": [...]}
        return [FileEntry(
            name=e.get("name", ""),
            path=e.get("path", ""),
            is_dir=e.get("is_dir", False) or e.get("type") in ("dir", "directory"),
            size=int(e.get("size", 0)),
            mtime=int(e.get("mtime", 0)),
        ) for e in parsed.get("entries", [])]

    # -- Package management --

    def install(self, pkg: str, runtime: str = "apt") -> ExecResult:
        """Install a package. runtime: 'apt' | 'pip' | 'npm'"""
        r = self._post(f"/sandboxes/{self.name}/install",
                       {"pkg": pkg, "runtime": runtime}, timeout=200)
        return ExecResult(exit_code=r.get("exit_code", 0 if r.get("ok") else 1),
                          stdout=r.get("stdout", ""), stderr=r.get("stderr", ""),
                          ok=r.get("ok", False))

    # -- Lifecycle --

    def health(self) -> dict:
        """Check the guest agent health."""
        return self._get(f"/sandboxes/{self.name}/health", timeout=5)

    def delete(self) -> None:
        """Stop the VM and delete all data."""
        hdrs = {**self._auth_headers(), "User-Agent": "sandflare-sdk/1.0"}
        req = urllib.request.Request(
            f"{self._base}/sandboxes/{self.name}",
            method="DELETE", headers=hdrs,
        )
        try:
            urllib.request.urlopen(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code != 404:
                raise

    def close(self) -> None:
        """Alias for delete(). Stop the VM and delete all data."""
        self.delete()

    def list_files(self, path: str = "/home/user") -> list:
        """Alias for ls(). List files in a directory inside the sandbox."""
        return self.ls(path)

    def pause(self) -> None:
        """Suspend the sandbox VM (CPU + memory frozen, billed at reduced rate)."""
        self._post(f"/sandboxes/{self.name}/pause", {})

    def resume(self) -> None:
        """Resume a previously paused sandbox VM."""
        self._post(f"/sandboxes/{self.name}/resume", {})

    def get_env(self) -> dict[str, str]:
        """Return current environment variables inside the sandbox."""
        return self._get(f"/sandboxes/{self.name}/agent/envs")  # type: ignore[return-value]

    def set_env(self, vars: dict[str, str]) -> None:
        """Set environment variables inside the running sandbox."""
        self._post(f"/sandboxes/{self.name}/agent/envs", vars)

    def get_processes(self) -> list[dict[str, Any]]:
        """List all running processes in the sandbox.

        Returns:
            List of processes with pid, command, cpu_percent, memory_percent.
        """
        return self._get(f"/sandboxes/{self.name}/agent/processes")  # type: ignore[return-value]

    def kill_process(self, pid: int) -> None:
        """Kill a process by PID (sends SIGKILL).

        Args:
            pid: Process ID to kill.
        """
        self._delete(f"/sandboxes/{self.name}/agent/processes/{pid}")

    def get_logs(self, stream: bool = False) -> list[str]:
        """Return the execution log lines recorded for this sandbox.

        Each ``exec()``, ``run_python()``, ``run_node()``, and ``install()``
        call appends its command + stdout/stderr to an in-memory ring buffer
        inside the orchestrator.  ``get_logs()`` fetches that buffer.

        Args:
            stream: If ``True`` the request keeps the connection open and
                    the server pushes new lines via SSE until the caller
                    disconnects.  In streaming mode the method returns
                    the initial snapshot as a plain list (same as
                    ``stream=False``) and the caller should use the
                    ``stream_logs()`` generator for continuous tailing.

        Returns:
            List of log lines (strings).

        Example::

            sb.exec("echo hello")
            sb.exec("python3 -c 'print(42)'")
            for line in sb.get_logs():
                print(line)
        """
        url = f"{self._base}/sandboxes/{self.name}/logs"
        if stream:
            url += "?stream=true"
        status, data = _http_request("GET", url, None, self._auth_headers(), 15)
        if status >= 400:
            raise SandflareError(status, f"get_logs failed (HTTP {status})", {})
        try:
            parsed = json.loads(data)
            return parsed.get("logs", []) if isinstance(parsed, dict) else []
        except Exception:
            return []

    def create_snapshot(
        self,
        name: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> "SnapshotInfo":
        """Create a snapshot of this running sandbox.

        The sandbox continues running after the snapshot is taken.
        The snapshot can be used to spawn new sandboxes from this exact state.

        Args:
            name:        Human-readable label for the snapshot.
            description: Optional longer description.
            tags:        List of string tags for filtering.

        Returns:
            SnapshotInfo with snapshot_id, status, and metadata.

        Example::

            snap = sandbox.create_snapshot(name="after-data-load")
            new_sb = Sandbox.create(snapshot_id=snap.snapshot_id)
        """
        body: dict[str, Any] = {}
        if name:        body["name"]        = name
        if description: body["description"] = description
        if tags:        body["tags"]        = tags
        r = self._post(f"/sandboxes/{self.name}/snapshot", body)
        return _snapshot_info_from_raw(r)

    def snapshot(
        self,
        name: str | None = None,
        description: str | None = None,
        tags: list[str] | None = None,
    ) -> "SnapshotInfo":
        """Alias for create_snapshot()."""
        return self.create_snapshot(name=name, description=description, tags=tags)

    def fork(
        self,
        n: int = 1,
        size: str = "nano",
    ) -> "list[Sandbox]":
        """Clone this live sandbox into *n* parallel copies.

        Each fork boots from an ephemeral snapshot of the current VM state.
        The intermediate snapshot is automatically discarded after the forks
        are ready — it never appears in your snapshot list.

        Forked sandboxes are regular sandboxes: same billing, same cleanup,
        same TTL rules. They carry ``metadata.fork_parent_id`` pointing back
        to this sandbox.

        Args:
            n:    Number of copies to create (1–8, default 1).
            size: VM size for each fork. Defaults to "nano".

        Returns:
            List of new :class:`Sandbox` objects, one per fork.

        Example::

            fork_a, fork_b = sandbox.fork(n=2)
            # fork_a and fork_b are identical copies of sandbox at this moment
        """
        r = self._post(f"/sandboxes/{self.name}/fork", {"n": n, "size": size})
        api_key = self._api_key
        base_url = self._base
        forks = []
        for raw in r.get("forks", []):
            if isinstance(raw, dict):
                forks.append(Sandbox(_sb_info_from_raw(raw), base_url=base_url, api_key=api_key))
        return forks

    @property
    def browser(self) -> "BrowserClient":
        """HTTP control API for the live browser running inside this sandbox.

        Only available on sandboxes created with the ``browser-agent`` template.

        Example::

            sb = Sandbox.create("browser-agent")
            sb.browser.navigate("https://github.com")
            png = sb.browser.screenshot()  # base64 PNG
        """
        return BrowserClient(self)

    def keep_alive(self, seconds: int = 300) -> None:
        """Extend the sandbox lifetime by *seconds* from now.

        Resets both the orchestrator's idle-timeout clock and the dashboard
        ``expires_at`` column.  The maximum extension per call is 24 h
        (86 400 s); call repeatedly to extend further.

        Args:
            seconds: How many seconds to keep the sandbox alive from now
                     (default 300 = 5 min, max 86 400 = 24 h).

        Example::

            sandbox.keep_alive(3600)  # stay alive for at least 1 more hour
        """
        self._post(f"/sandboxes/{self.name}/timeout", {"timeout": seconds})

    def keep_alive_forever(self, interval: int = 60) -> None:
        """Prevent this sandbox from expiring for as long as the process runs.

        Starts a daemon thread that calls :meth:`keep_alive` every
        *interval* seconds.  The thread is automatically stopped when the
        Python process exits.

        Args:
            interval: Ping interval in seconds (default 60).

        Example::

            sandbox.keep_alive_forever()
            # now safe to run long-running agent loops
        """
        def _ping() -> None:
            while True:
                try:
                    self.keep_alive(interval * 3)
                except Exception:  # noqa: BLE001
                    pass
                time.sleep(interval)

        t = threading.Thread(target=_ping, daemon=True, name=f"keep-alive-{self.name}")
        t.start()


        """List snapshots for this sandbox."""
        r = self._get(f"/snapshots?sandbox_id={self.name}")
        # API returns { snapshots: [...] } not just [...]
        if isinstance(r, dict) and "snapshots" in r:
            return [_snapshot_info_from_raw(item) for item in r["snapshots"]]
        if isinstance(r, list):
            return [_snapshot_info_from_raw(item) for item in r]
        return []

    def enable_auto_snapshot(self, interval_mins: int = 30) -> dict:
        """Enable automatic snapshots every N minutes.

        The sandbox is briefly paused (~100ms) during each snapshot, then
        automatically resumed. Snapshots are uploaded to GCS and metadata is
        written to Supabase.

        Args:
            interval_mins: How often to snapshot (minimum 5, default 30).

        Returns:
            dict with ``status``, ``sandbox_id``, and ``interval_mins``.

        Example::

            sb = Sandbox.create(auto_snapshot_interval_mins=30)
            # — or — enable later:
            sb.enable_auto_snapshot(15)
        """
        if interval_mins < 5:
            raise ValueError("interval_mins must be at least 5")
        return self._post(  # type: ignore[return-value]
            f"/sandboxes/{self.name}/auto-snapshot",
            {"interval_mins": interval_mins},
        )

    def disable_auto_snapshot(self) -> dict:
        """Disable automatic snapshotting for this sandbox.

        Returns:
            dict with ``status`` and ``sandbox_id``.
        """
        base = self._base
        key  = self._api_key
        headers: dict = {"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else {}
        headers["Content-Type"] = "application/json"
        import urllib.request
        req = urllib.request.Request(
            f"{base}/sandboxes/{self.name}/auto-snapshot",
            method="DELETE",
            headers=headers,
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                import json as _json
                return _json.loads(resp.read())
        except Exception:
            return {"status": "disabled", "sandbox_id": self.name}

    @classmethod
    def list_all_snapshots(
        cls,
        sandbox_id: str | None = None,
        base_url:   str | None = None,
        api_key:    str | None = None,
    ) -> "list[SnapshotInfo]":
        """List all snapshots for the current API key.

        Args:
            sandbox_id: Optional — filter to a specific sandbox.
            base_url:   API base URL override.
            api_key:    API key override.

        Returns:
            List of SnapshotInfo objects.
        """
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        headers = {"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None
        url = f"{resolved_base_url}/snapshots"
        if sandbox_id:
            url += f"?sandbox_id={sandbox_id}"
        raw = _req("GET", url, headers=headers, timeout=10)
        # API returns { snapshots: [...] } not just [...]
        if isinstance(raw, dict) and "snapshots" in raw:
            return [_snapshot_info_from_raw(item) for item in raw["snapshots"]]
        if isinstance(raw, list):
            return [_snapshot_info_from_raw(item) for item in raw]
        return []

    @classmethod
    def delete_snapshot(
        cls,
        snapshot_id: str,
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> bool:
        """Delete a snapshot by ID.

        Args:
            snapshot_id: The snapshot ID to delete.
            base_url:    API base URL override.
            api_key:     API key override.

        Returns:
            True if deleted successfully.
        """
        resolved_base_url = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        headers = {"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else {}
        req = urllib.request.Request(
            f"{resolved_base_url}/snapshots/{snapshot_id}",
            method="DELETE",
            headers=headers,
        )
        try:
            urllib.request.urlopen(req, timeout=10)
            return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            raise SandflareError(e.code, body.get("error", e.reason), body) from e

    # -- Internals --


    def _wait_for_agent(self, timeout: int = 120) -> None:
        deadline = time.time() + timeout
        last_err = None
        interval = 0.5  # start with 500ms, backoff up to 2s
        while time.time() < deadline:
            try:
                self.health()
                return
            except Exception as e:
                last_err = e
                time.sleep(interval)
                interval = min(interval * 1.5, 2.0)
        raise TimeoutError(f"Agent not reachable after {timeout}s for {self.name}: {last_err}")

    def _auth_headers(self) -> dict:
        return {"X-API-Key": self._api_key, "User-Agent": "sandflare-sdk/1.0"} if self._api_key else {"User-Agent": "sandflare-sdk/1.0"}

    def _get(self, path: str, timeout: int = 10) -> dict:
        return _req("GET", f"{self._base}{path}", headers=self._auth_headers(), timeout=timeout)

    def _post(self, path: str, body: Any, timeout: int = 35) -> dict:
        return _req("POST", f"{self._base}{path}", body,
                    headers=self._auth_headers(), timeout=timeout)

    def _delete(self, path: str, timeout: int = 10) -> dict:
        url = f"{self._base}{path}"
        req = urllib.request.Request(url, method="DELETE", headers=self._auth_headers())
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                try:
                    return json.loads(resp.read())
                except Exception:
                    return {}
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            raise SandflareError(e.code, body.get("error", e.reason), body) from e

    # -- Metrics & process management --

    def metrics(self) -> SandboxMetrics:
        """Return live CPU, memory, and disk metrics for this sandbox."""
        raw = self._get(f"/sandboxes/{self._info.name}/metrics")
        return SandboxMetrics(
            sandbox_id=str(raw.get("sandbox_id", self._info.name)),
            status=str(raw.get("status", "")),
            cpu_count=int(raw.get("cpu_count", 0)),
            cpu_used_pct=float(raw.get("cpu_used_pct", 0)),
            mem_total=int(raw.get("mem_total", 0)),
            mem_used=int(raw.get("mem_used", 0)),
            disk_total=int(raw.get("disk_total", 0)),
            disk_used=int(raw.get("disk_used", 0)),
            ts=int(raw.get("ts", 0)),
        )

    def kill_process(self, pid: int) -> None:
        """Send SIGKILL to a process inside the sandbox by PID."""
        self._delete(f"/sandboxes/{self._info.name}/processes/{pid}")

    def git_clone(
        self,
        repo: str,
        path: str | None = None,
        branch: str | None = None,
        depth: int = 1,
        token: str | None = None,
        ssh_key: str | None = None,
    ) -> GitCloneResult:
        """Clone a git repository into the sandbox."""
        body: dict[str, Any] = {"repo": repo, "depth": depth}
        if path:    body["path"] = path
        if branch:  body["branch"] = branch
        if token:   body["token"] = token
        if ssh_key: body["ssh_key"] = ssh_key
        raw = self._post(f"/sandboxes/{self._info.name}/git/clone", body, timeout=300)
        return GitCloneResult(
            path=str(raw.get("path", "")),
            repo=str(raw.get("repo", repo)),
            branch=raw.get("branch"),
            output=str(raw.get("output", "")),
        )

    def exec_stream(self, cmd: str, timeout: int = 300) -> Generator[StreamEvent, None, None]:
        """Execute a command and yield StreamEvent objects for each stdout/stderr line."""
        import urllib.parse
        qs  = urllib.parse.urlencode({"cmd": cmd, "timeout": str(timeout)})
        url = f"{self._base}/sandboxes/{self._info.name}/exec/stream?{qs}"
        req = urllib.request.Request(url, headers=self._auth_headers())

        try:
            with urllib.request.urlopen(req, timeout=timeout + 5) as resp:
                buf = b""
                for chunk in iter(lambda: resp.read(1), b""):
                    buf += chunk
                    if b"\n\n" in buf:
                        parts = buf.split(b"\n\n")
                        buf   = parts[-1]
                        for part in parts[:-1]:
                            event_type = "stdout"
                            data       = ""
                            for line in part.decode("utf-8", errors="replace").splitlines():
                                if line.startswith("event:"):
                                    event_type = line[6:].strip()
                                elif line.startswith("data:"):
                                    data = line[5:].strip()
                            if event_type == "done":
                                exit_code = 0
                                try:
                                    import json as _json
                                    exit_code = _json.loads(data).get("exit_code", 0)
                                except Exception:
                                    pass
                                yield StreamEvent(type="done", data="", exit_code=exit_code)
                                return
                            if data:
                                yield StreamEvent(type=event_type, data=data)
        except urllib.error.URLError as e:
            raise SandflareError(0, str(e), {}) from e


# ---------------------------------------------------------------------------
# Template — helpers for .dockerignore parsing
# ---------------------------------------------------------------------------

def _parse_dockerignore(dockerignore_path: "pathlib.Path") -> list[str]:
    """Return a list of gitignore-style patterns from a .dockerignore file."""
    if not dockerignore_path.exists():
        return []
    patterns = []
    for line in dockerignore_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            patterns.append(line)
    return patterns


def _dockerignore_matches(rel_path: str, patterns: list[str]) -> bool:
    """Return True if *rel_path* matches any .dockerignore pattern."""
    import fnmatch
    parts = rel_path.replace("\\", "/").split("/")
    for pattern in patterns:
        # Negative patterns (!) are not excluded — we conservatively include the file.
        if pattern.startswith("!"):
            continue
        # Match against the full relative path or just the first path component.
        if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(parts[0], pattern):
            return True
        # Also match any path component against bare filename patterns.
        if "/" not in pattern and any(fnmatch.fnmatch(p, pattern) for p in parts):
            return True
    return False


# ---------------------------------------------------------------------------
# Template
# ---------------------------------------------------------------------------

class Template:
    """Manage custom Sandflare sandbox templates built from Dockerfiles."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key:  str | None = None,
    ) -> None:
        self._base_url = _resolve_base_url(base_url)
        self._api_key  = _resolve_api_key(api_key)

    @classmethod
    def build(
        cls,
        name:        str,
        dockerfile:  str,
        *,
        description: str = "",
        team_id:     str = "",
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> "TemplateBuildJob":
        """Submit a Dockerfile string to build a custom template. Returns immediately with build job.

        Note: This method does not support COPY or ADD instructions that reference local files.
        Use :meth:`build_from_directory` to send a full build context with COPY/ADD support.
        """
        t = cls(base_url=base_url, api_key=api_key)
        body: dict[str, Any] = {"name": name, "dockerfile": dockerfile}
        if description: body["description"] = description
        if team_id:     body["team_id"]     = team_id
        raw = t._post("/templates/build", body)
        return t._parse_job(raw)

    @classmethod
    def build_from_directory(
        cls,
        path:        str,
        name:        str,
        *,
        description: str = "",
        team_id:     str = "",
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> "TemplateBuildJob":
        """Build a custom template from a local directory.

        Reads the Dockerfile from *path* and sends all other files in the directory
        as the Docker build context, enabling ``COPY`` and ``ADD`` instructions.
        Patterns listed in ``.dockerignore`` (if present) are excluded.

        Example::

            job = Template.build_from_directory(
                ".",
                name="my-template",
                description="Node + Python runtime",
            )
            Template.wait_for_build(job.id)

        Args:
            path: Directory containing the Dockerfile (and any files to COPY).
            name: Template name shown in the Sandflare dashboard.
            description: Optional human-readable description.
            team_id: Optional team ID; defaults to your personal team.
        """
        dir_path = pathlib.Path(path).resolve()
        dockerfile_path = dir_path / "Dockerfile"
        if not dockerfile_path.exists():
            raise FileNotFoundError(f"No Dockerfile found in {dir_path}")

        dockerfile_text = dockerfile_path.read_text(encoding="utf-8")

        ignore_patterns = _parse_dockerignore(dir_path / ".dockerignore")

        # Collect all context files (everything except the Dockerfile itself).
        context_files: dict[str, bytes] = {}
        for file_path in sorted(dir_path.rglob("*")):
            if not file_path.is_file():
                continue
            try:
                rel = file_path.relative_to(dir_path)
            except ValueError:
                continue
            rel_str = rel.as_posix()
            if rel_str == "Dockerfile":
                continue
            if _dockerignore_matches(rel_str, ignore_patterns):
                continue
            context_files[rel_str] = file_path.read_bytes()

        t = cls(base_url=base_url, api_key=api_key)
        fields: dict[str, str] = {"name": name, "dockerfile": dockerfile_text}
        if description:
            fields["description"] = description
        if team_id:
            fields["team_id"] = team_id
        raw = t._post_multipart("/templates/build", fields, context_files)
        return t._parse_job(raw)

    @classmethod
    def get_build_status(
        cls,
        template_id: str,
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> TemplateBuildJob:
        t = cls(base_url=base_url, api_key=api_key)
        raw = t._get(f"/templates/{template_id}/build-status")
        return t._parse_job(raw)

    @classmethod
    def list(
        cls,
        team_id:  str | None = None,
        base_url: str | None = None,
        api_key:  str | None = None,
    ) -> list[TemplateBuildJob]:
        t  = cls(base_url=base_url, api_key=api_key)
        qs = f"?team_id={team_id}" if team_id else ""
        raw = t._get(f"/templates{qs}")
        return [t._parse_job(j) for j in (raw if isinstance(raw, list) else raw.get("templates", []))]

    @classmethod
    def wait_for_build(
        cls,
        template_id:      str,
        timeout_seconds:  int   = 1800,
        poll_interval:    float = 3.0,
        base_url:         str | None = None,
        api_key:          str | None = None,
    ) -> TemplateBuildJob:
        """Poll until template build is ready or failed. Default timeout: 30 minutes."""
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            job = cls.get_build_status(template_id, base_url=base_url, api_key=api_key)
            if job.status == "ready":
                return job
            if job.status == "failed":
                raise SandflareError(500, f"Template build failed: {job.error}", {})
            time.sleep(poll_interval)
        raise SandflareError(408, f"Template build timed out after {timeout_seconds}s", {})

    @classmethod
    def delete(
        cls,
        template_id: str,
        base_url:    str | None = None,
        api_key:     str | None = None,
    ) -> None:
        t = cls(base_url=base_url, api_key=api_key)
        t._delete(f"/templates/{template_id}")

    def _parse_job(self, raw: dict) -> TemplateBuildJob:
        return TemplateBuildJob(
            id=str(raw.get("id") or raw.get("template_id", "")),
            name=str(raw.get("name", "")),
            status=str(raw.get("status", "")),
            description=str(raw.get("description", "")),
            error=str(raw.get("error", "")),
            team_id=str(raw.get("team_id", "")),
            created_at=str(raw.get("created_at", "")),
            updated_at=str(raw.get("updated_at", "")),
            logs=raw.get("logs") or [],
        )

    def _auth_headers(self) -> dict:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": "sandflare-python-sdk/2.1.3",
        }

    def _post_multipart(
        self,
        path: str,
        fields: dict[str, str],
        files: dict[str, bytes],
        timeout: int = 300,
    ) -> dict:
        """POST multipart/form-data with text *fields* and binary *files*."""
        boundary = f"sandflare{int(time.time() * 1e6):x}"
        parts: list[bytes] = []

        for key, value in fields.items():
            parts.append(
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{key}"\r\n'
                f"\r\n"
                f"{value}\r\n".encode("utf-8")
            )

        for filename, content in files.items():
            header = (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{filename}"; filename="{filename}"\r\n'
                f"Content-Type: application/octet-stream\r\n"
                f"\r\n"
            ).encode("utf-8")
            parts.append(header + content + b"\r\n")

        parts.append(f"--{boundary}--\r\n".encode("utf-8"))
        body = b"".join(parts)

        url = f"{self._base_url}{path}"
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "X-API-Key": self._api_key,
                "Content-Type": f"multipart/form-data; boundary={boundary}",
                "User-Agent": "sandflare-python-sdk/2.1.3",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            b: dict = {}
            try:
                b = json.loads(e.read())
            except Exception:
                pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e

    def _get(self, path: str, timeout: int = 30) -> dict:
        url = f"{self._base_url}{path}"
        req = urllib.request.Request(url, headers={
            "X-API-Key": self._api_key,
            "User-Agent": "sandflare-python-sdk/2.1.3",
        })
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = {}
            try: body = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, body.get("error", e.reason), body) from e

    def _post(self, path: str, body: Any, timeout: int = 60) -> dict:
        url  = f"{self._base_url}{path}"
        data = json.dumps(body).encode()
        req  = urllib.request.Request(url, data=data, headers=self._auth_headers(), method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            b = {}
            try: b = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e

    def _delete(self, path: str, timeout: int = 30) -> dict:
        url = f"{self._base_url}{path}"
        req = urllib.request.Request(url, method="DELETE", headers={
            "X-API-Key": self._api_key,
            "User-Agent": "sandflare-python-sdk/2.1.3",
        })
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                try: return json.loads(resp.read())
                except Exception: return {}
        except urllib.error.HTTPError as e:
            b = {}
            try: b = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e


# ──────────────────────────────────────────────────────────────────────────────
# Memory — agent-level memory backed by mem0 Cloud
# ──────────────────────────────────────────────────────────────────────────────

class MemoryEntry:
    """A single memory entry returned from mem0."""
    def __init__(self, raw: dict) -> None:
        self.id          = str(raw.get("id", ""))
        self.memory      = str(raw.get("memory", ""))
        self.score       = float(raw.get("score", 0.0))
        self.user_id     = str(raw.get("user_id", ""))
        self.agent_id    = str(raw.get("agent_id", ""))
        self.categories  = raw.get("categories") or []
        self.metadata    = raw.get("metadata") or {}
        self.created_at  = str(raw.get("created_at", ""))
        self.raw         = raw

    def __repr__(self) -> str:
        return f"<MemoryEntry id={self.id!r} score={self.score:.2f} memory={self.memory[:60]!r}>"


def __repr__(self) -> str:
        return f"<MemoryEntry id={self.id!r} score={self.score:.2f} memory={self.memory[:60]!r}>"


# ── Browser-in-a-Box ──────────────────────────────────────────────────────────

class BrowserClient:
    """HTTP control API for the live Chromium browser running inside a sandbox.

    Obtained via ``sandbox.browser``. Only meaningful for sandboxes created
    with the ``browser-agent`` template, where Xvfb + Chromium + the browser
    controller service start automatically at VM boot.

    The VNC live view is available at ``https://6080-<sandbox-name>.sandflare.io``
    and the raw CDP endpoint at ``https://9222-<sandbox-name>.sandflare.io``.

    Example::

        sb = Sandbox.create("browser-agent")
        sb.browser.navigate("https://github.com")
        png_b64 = sb.browser.screenshot()
        sb.browser.click(x=640, y=400)
        sb.browser.type(text="hello world")
    """

    def __init__(self, sandbox: "Sandbox") -> None:
        self._sb = sandbox

    def _post(self, path: str, body: dict | None = None) -> dict:
        return self._sb._post(f"/sandboxes/{self._sb.name}/browser{path}", body or {})

    def _get(self, path: str) -> dict:
        return self._sb._get(f"/sandboxes/{self._sb.name}/browser{path}")

    def status(self) -> dict:
        """Return browser status: ``{ready, status, url, title}``.

        If the browser is not yet running, ``ready`` is ``False`` and
        ``status`` is ``"not_started"``.
        """
        return self._get("/status")

    def start(self) -> dict:
        """Launch Chromium inside the sandbox (no-op if already running).

        Returns:
            ``{"started": True, "status": "running"}``
        """
        return self._post("/start")

    def stop(self) -> dict:
        """Stop the Chromium process.

        Returns:
            ``{"stopped": True}``
        """
        return self._post("/stop")

    def navigate(self, url: str) -> dict:
        """Navigate to *url*. Launches Chromium automatically if not running.

        Returns:
            ``{"navigated": True, "url": url}``
        """
        return self._post("/navigate", {"url": url})

    def click(self, x: float, y: float) -> dict:
        """Click at viewport coordinates *(x, y)*.

        Returns:
            ``{"clicked": True, "x": x, "y": y}``
        """
        return self._post("/click", {"x": x, "y": y})

    def type(self, text: str) -> dict:  # noqa: A003
        """Type *text* at the current cursor position.

        Returns:
            ``{"typed": True, "length": len(text)}``
        """
        return self._post("/type", {"text": text})

    def scroll(self, x: float = 0, y: float = 0,
               delta_x: float = 0, delta_y: float = 100) -> dict:
        """Scroll at position *(x, y)* by *(delta_x, delta_y)* pixels.

        Returns:
            ``{"scrolled": True}``
        """
        return self._post("/scroll", {"x": x, "y": y, "delta_x": delta_x, "delta_y": delta_y})

    def screenshot(self) -> str:
        """Capture a PNG screenshot of the current page.

        Returns:
            Base64-encoded PNG string. Decode with ``base64.b64decode(png)``
            to get raw bytes.

        Example::

            png_b64 = sb.browser.screenshot()
            import base64, pathlib
            pathlib.Path("shot.png").write_bytes(base64.b64decode(png_b64))
        """
        r = self._get("/screenshot")
        return r.get("png", "")

    def evaluate(self, expression: str) -> Any:
        """Evaluate a JavaScript *expression* in the page context.

        Args:
            expression: JavaScript to evaluate (e.g. ``"document.title"``).

        Returns:
            The return value of the expression (JSON-serialisable types only).

        Example::

            title = sb.browser.evaluate("document.title")
        """
        r = self._post("/evaluate", {"expression": expression})
        return r.get("result")

    def wait_until_ready(self, timeout: float = 60, poll: float = 2.0) -> dict:
        """Block until the browser controller is up and Chromium is ready.

        Polls ``status()`` every *poll* seconds (default 2 s), retrying on
        502 errors (controller not yet listening) and ``ready=False``
        (Chromium still starting). Raises :exc:`TimeoutError` if the browser
        is not ready within *timeout* seconds.

        Args:
            timeout: Maximum seconds to wait (default 60).
            poll: Seconds between status checks (default 2).

        Returns:
            The last ``status()`` response once ``ready`` is ``True``.

        Example::

            sb = Sandbox.create(template_id="browser-agent")
            sb.browser.wait_until_ready()
            sb.browser.navigate("https://example.com")
        """
        import time as _time
        deadline = _time.monotonic() + timeout
        while True:
            try:
                st = self.status()
                if st.get("ready"):
                    return st
            except Exception:
                # 502 = controller not yet listening — keep retrying
                pass
            if _time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Browser controller not ready after {timeout:.0f}s — "
                    "is the sandbox using the browser-agent template?"
                )
            _time.sleep(poll)

    @property
    def url(self) -> str:
        """Current page URL (empty string if browser not running)."""
        try:
            return self._get("/url").get("url", "")
        except Exception:
            return ""

    @property
    def vnc_url(self) -> str:
        """noVNC live view URL — open in any browser for real-time screen."""
        return f"https://6080-{self._sb.name}.sandflare.io/vnc.html"

    @property
    def cdp_url(self) -> str:
        """Raw Chrome DevTools Protocol endpoint URL."""
        return f"https://9222-{self._sb.name}.sandflare.io"


class SandboxMemory:
    """
    Sandbox-scoped agent memory — memories tied to a specific sandbox session.

    AI agents use this to remember what they learned within a sandbox and
    to recall that knowledge in future sessions.

    Usage::

        sb = Sandbox.create("agent")

        # Store what the agent discovered
        sb.memory.add("User's FastAPI app uses SQLAlchemy async sessions")
        sb.memory.add("JWT decode requires algorithm='HS256'")

        # Recall in the next session
        results = sb.memory.search("FastAPI auth context")
        for r in results:
            print(r.memory)

        sb.memory.delete_all()
    """

    def __init__(self, sandbox_name: str, base_url: str, api_key: str) -> None:
        self._sandbox_name = sandbox_name
        self._base         = base_url.rstrip("/")
        self._api_key      = api_key

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json", "User-Agent": "sandflare-sdk/1.0"}
        if self._api_key:
            h["X-API-Key"] = self._api_key
        return h

    def _request(self, method: str, path: str, body: dict | None = None, timeout: int = 15) -> dict:
        import urllib.request
        url  = f"{self._base}{path}"
        data = json.dumps(body).encode() if body else None
        req  = urllib.request.Request(url, data=data, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            b = {}
            try: b = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e

    def add(self, text: str, metadata: dict | None = None, category: str | None = None,
            infer: bool = False) -> list[dict]:
        """Store a memory scoped to this sandbox session.

        Args:
            text:     The memory text. Be specific: what was discovered, what worked,
                      what failed, user preferences, technical decisions.
            metadata: Optional key-value metadata for filtering (e.g. {"topic": "auth"}).
            category: Optional category tag: ``preference``, ``bug_fix``,
                      ``project_context``, or ``command``.
            infer:    If True, uses LLM to extract structured memories from the text
                      (async, ~30s). If False, stores the text directly (instant).

        Returns:
            List of stored memory results (each has ``id`` and ``event``).
        """
        body: dict = {"text": text}
        if metadata:
            body["metadata"] = metadata
        if category:
            body["category"] = category
        if infer:
            body["infer"] = True
        raw = self._request("POST", f"/sandboxes/{self._sandbox_name}/memory", body)
        return raw.get("results", [])

    def batch_add(self, facts: list[str], metadata: dict | None = None, category: str | None = None) -> list[dict]:
        """Store multiple memories in a single call.

        More efficient than calling :meth:`add` in a loop. All facts share the
        same metadata and category.

        Args:
            facts:    List of memory strings to store.
            metadata: Optional shared key-value metadata.
            category: Optional shared category tag.

        Returns:
            List of stored memory results.
        """
        body: dict = {"facts": facts}
        if metadata:
            body["metadata"] = metadata
        if category:
            body["category"] = category
        raw = self._request("POST", f"/sandboxes/{self._sandbox_name}/memory/batch", body)
        return raw.get("results", [])

    def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        """Semantic search over this sandbox's memories.

        Args:
            query: Natural language query (e.g. "auth bug fix", "database connection").
            limit: Max results to return. Default: 10.

        Returns:
            List of :class:`MemoryEntry` sorted by relevance score (highest first).
        """
        raw = self._request("GET", f"/sandboxes/{self._sandbox_name}/memory?q={urllib.parse.quote(query)}")
        return [MemoryEntry(m) for m in raw.get("memories", [])]

    def list(self) -> list[MemoryEntry]:
        """List all memories for this sandbox (no query — sorted by recency)."""
        raw = self._request("GET", f"/sandboxes/{self._sandbox_name}/memory")
        return [MemoryEntry(m) for m in raw.get("memories", [])]

    def delete(self, memory_id: str) -> None:
        """Delete a specific memory by its ID."""
        self._request("DELETE", f"/sandboxes/{self._sandbox_name}/memory/{memory_id}")

    def delete_all(self) -> None:
        """Delete all memories for this sandbox session."""
        self._request("DELETE", f"/sandboxes/{self._sandbox_name}/memory")

    def feedback(self, memory_id: str, useful: bool) -> None:
        """Rate a recalled memory.

        Positive feedback boosts future recall; negative suppresses it.

        Args:
            memory_id: The memory ID (from :meth:`search` or :meth:`list`).
            useful:    ``True`` if this memory was helpful, ``False`` if noise.
        """
        self._request("POST", f"/memory/{memory_id}/feedback", {"useful": useful})


class UserMemory:
    """
    User-level agent memory — persists across ALL sandbox sessions.

    This is the primary memory store for AI agents. Memories stored here
    survive sandbox deletion and are automatically surfaced via the MCP
    ``memory_context`` field when the agent creates a new sandbox.

    Access via the class-level ``Sandbox.memory`` property::

        # Store cross-session learnings
        Sandbox.memory.add("User prefers async Python, uses black formatter")
        Sandbox.memory.add("Project: FastAPI + PostgreSQL on Supabase")

        # Recall before starting work
        context = Sandbox.memory.search("user coding preferences")
        for m in context:
            print(m.memory)

        # Full list
        all_memories = Sandbox.memory.list()
    """

    def __init__(self, api_key: str | None = None, base_url: str | None = None) -> None:
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json", "User-Agent": "sandflare-sdk/1.0"}
        if self._api_key:
            h["X-API-Key"] = self._api_key
        return h

    def _request(self, method: str, path: str, body: dict | None = None, timeout: int = 15) -> dict:
        import urllib.request
        url  = f"{self._base}{path}"
        data = json.dumps(body).encode() if body else None
        req  = urllib.request.Request(url, data=data, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            b = {}
            try: b = json.loads(e.read())
            except Exception: pass
            raise SandflareError(e.code, b.get("error", e.reason), b) from e

    def add(self, text: str, metadata: dict | None = None, category: str | None = None,
            infer: bool = False) -> list[dict]:
        """Store a user-level memory (persists across all sandboxes).

        Args:
            text:     Memory text. Be specific — what was learned, what the user prefers,
                      project context, technical decisions.
            metadata: Optional key-value metadata.
            category: Optional category tag: ``preference``, ``bug_fix``,
                      ``project_context``, or ``command``.
            infer:    If True, uses LLM to extract structured memories (async, ~30s).

        Returns:
            List of stored memory results.
        """
        body: dict = {"text": text}
        if metadata:
            body["metadata"] = metadata
        if category:
            body["category"] = category
        if infer:
            body["infer"] = True
        raw = self._request("POST", "/memory", body)
        return raw.get("results", [])

    def batch_add(self, facts: list[str], metadata: dict | None = None, category: str | None = None) -> list[dict]:
        """Store multiple user-level memories in a single call.

        Args:
            facts:    List of memory strings to store.
            metadata: Optional shared key-value metadata.
            category: Optional shared category tag.

        Returns:
            List of stored memory results.
        """
        body: dict = {"facts": facts}
        if metadata:
            body["metadata"] = metadata
        if category:
            body["category"] = category
        raw = self._request("POST", "/memory/batch", body)
        return raw.get("results", [])

    def search(self, query: str, limit: int = 10) -> list[MemoryEntry]:
        """Semantic search over all user-level memories.

        Args:
            query: Natural language query (e.g. "project tech stack", "auth preferences").
            limit: Max results. Default: 10.

        Returns:
            List of :class:`MemoryEntry` sorted by relevance.
        """
        raw = self._request("GET", f"/memory?q={urllib.parse.quote(query)}")
        return [MemoryEntry(m) for m in raw.get("memories", [])]

    def list(self) -> list[MemoryEntry]:
        """List all user-level memories (sorted by recency)."""
        raw = self._request("GET", "/memory")
        return [MemoryEntry(m) for m in raw.get("memories", [])]

    def delete(self, memory_id: str) -> None:
        """Delete a specific memory by ID."""
        self._request("DELETE", f"/memory/{memory_id}")

    def delete_all(self) -> None:
        """Delete ALL user-level memories. Use with caution."""
        self._request("DELETE", "/memory")

    def feedback(self, memory_id: str, useful: bool) -> None:
        """Rate a recalled memory.

        Positive feedback boosts future recall; negative suppresses it.

        Args:
            memory_id: The memory ID (from :meth:`search` or :meth:`list`).
            useful:    ``True`` if this memory was helpful, ``False`` if noise.
        """
        self._request("POST", f"/memory/{memory_id}/feedback", {"useful": useful})


def _sb_info_from_raw(raw: dict) -> SandboxInfo:
    # Derive subdomain_url from preview_url if not explicitly returned
    # preview_url = "https://3000-sb-xxx.sandflare.io" → subdomain_url = "https://sb-xxx.sandflare.io"
    subdomain_url = raw.get("subdomain_url")
    if not subdomain_url and raw.get("preview_url"):
        import re as _re
        m = _re.match(r"https://\d+-(.+)", raw["preview_url"])
        if m:
            subdomain_url = f"https://{m.group(1)}"

    # Derive tier from size or memory_mb
    size = raw.get("size") or raw.get("tier") or ""
    if not size:
        mem = raw.get("memory_mb", 0)
        size = {512: "nano", 1024: "small", 2048: "medium", 4096: "large"}.get(mem, "nano")
    tier = raw.get("tier") or size

    return SandboxInfo(
        name=raw.get("name", ""),
        ip=raw.get("ip", ""),
        agent_port=raw.get("agent_port", 0),
        agent_url=raw.get("agent_url", ""),
        public_url=raw.get("public_url", ""),
        panel_url=raw.get("panel_url", raw.get("subdomain_url", "")),
        preview_url=raw.get("preview_url"),
        preview_port=int(raw["preview_port"]) if raw.get("preview_port") is not None else None,
        subdomain=raw.get("subdomain"),
        subdomain_url=subdomain_url,
        status=raw.get("status", "unknown"),
        memory_mb=raw.get("memory_mb", 0),
        vcpus=raw.get("vcpus", 0),
        root_gb=raw.get("root_gb", 0),
        template_id=raw.get("template") or raw.get("template_id"),
        expires_at=raw.get("expires_at"),
        ttl_hours=int(raw.get("ttl_hours", 0)),
        label=raw.get("label", ""),
        ephemeral=bool(raw.get("ephemeral", False)),
        size=size,
        tier=tier,
        metadata=raw.get("metadata") or {},
        raw=raw,
    )


def _snapshot_info_from_raw(raw: dict) -> SnapshotInfo:
    snapshot_id = raw.get("snapshot_id", raw.get("id", ""))
    return SnapshotInfo(
        name=raw.get("name", ""),
        created_at=raw.get("created_at"),
        size_mb=raw.get("size_mb"),
        vmstate=raw.get("vmstate"),
        mem=raw.get("mem"),
        snapshot_id=snapshot_id,
        id=snapshot_id,  # Alias for snapshot_id
        sandbox_id=raw.get("sandbox_id", ""),
        build_id=raw.get("build_id", ""),
        status=raw.get("status", "uploading"),
        description=raw.get("description"),
        tags=raw.get("tags", []),
        fork_count=int(raw.get("fork_count", 0)),
        parent_snapshot_id=raw.get("parent_snapshot_id"),
        auto_created=bool(raw.get("auto_created", False)),
        raw=raw,
    )


# ---------------------------------------------------------------------------
# Volumes — persistent storage that outlives sandboxes
# ---------------------------------------------------------------------------

@dataclass
class VolumeInfo:
    id: str
    name: str
    size_gb: int
    status: str
    created_at: str
    team_id: str = ""
    raw: dict = field(default_factory=dict)

    def __repr__(self) -> str:
        return f"<Volume id={self.id!r} name={self.name!r} size_gb={self.size_gb} status={self.status!r}>"


def _volume_from_raw(raw: dict) -> VolumeInfo:
    return VolumeInfo(
        id=raw.get("id", ""),
        name=raw.get("name", ""),
        size_gb=raw.get("size_gb", 10),
        status=raw.get("status", ""),
        created_at=raw.get("created_at", ""),
        team_id=raw.get("team_id", ""),
        raw=raw,
    )


class Volume:
    """
    Persistent storage volume that outlives individual sandboxes.

    Usage::

        vol = Volume.create("my-data", size_gb=50)
        sb = Sandbox.create(volumes={"/data": vol})
        # ... use /data inside sandbox ...
        sb.delete()

        # Attach same volume to a new sandbox later
        vol = Volume.get("my-data")
        sb2 = Sandbox.create(volumes={"/data": vol})
    """

    def __init__(self, info: VolumeInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    @classmethod
    def create(
        cls,
        name: str,
        size_gb: int = 10,
        base_url: str | None = None,
        api_key: str | None = None,
    ) -> "Volume":
        """Create a new persistent volume."""
        resolved_base = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req(
            "POST", f"{resolved_base}/volumes",
            {"name": name, "size_gb": size_gb},
            headers={"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None,
            timeout=30,
        )
        return cls(_volume_from_raw(raw), base_url=resolved_base, api_key=key)

    @classmethod
    def get(cls, name_or_id: str, base_url: str | None = None,
            api_key: str | None = None) -> "Volume":
        """Get an existing volume by name or ID."""
        resolved_base = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw = _req(
            "GET", f"{resolved_base}/volumes/{urllib.parse.quote(name_or_id)}",
            headers={"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None,
            timeout=10,
        )
        return cls(_volume_from_raw(raw), base_url=resolved_base, api_key=key)

    @classmethod
    def list(cls, base_url: str | None = None,
             api_key: str | None = None) -> "list[Volume]":
        """List all volumes for the current team."""
        resolved_base = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        raw_list = _req(
            "GET", f"{resolved_base}/volumes",
            headers={"X-API-Key": key, "User-Agent": "sandflare-sdk/1.0"} if key else None,
            timeout=10,
        )
        items = raw_list if isinstance(raw_list, list) else raw_list.get("volumes", [])
        return [cls(_volume_from_raw(r), base_url=resolved_base, api_key=key) for r in items]

    def delete(self) -> None:
        """Delete this volume. WARNING: all data is permanently destroyed."""
        _req(
            "DELETE", f"{self._base}/volumes/{self._info.id}",
            headers={"X-API-Key": self._api_key, "User-Agent": "sandflare-sdk/1.0"} if self._api_key else None,
            timeout=30,
        )

    @property
    def id(self) -> str:
        return self._info.id

    @property
    def name(self) -> str:
        return self._info.name

    @property
    def size_gb(self) -> int:
        return self._info.size_gb

    @property
    def status(self) -> str:
        return self._info.status

    @property
    def info(self) -> VolumeInfo:
        return self._info

    def __repr__(self) -> str:
        return repr(self._info)


# ---------------------------------------------------------------------------
# Async helpers
# ---------------------------------------------------------------------------

async def _async_req(
    method: str,
    url: str,
    body: Any = None,
    headers: dict | None = None,
    timeout: int = 60,
) -> Any:
    """Async HTTP request using aiohttp."""
    try:
        import aiohttp
    except ImportError:
        raise ImportError(
            "aiohttp is required for AsyncSandbox. Install with: pip install aiohttp"
        )
    hdrs = {"Content-Type": "application/json", **(headers or {})}
    data = json.dumps(body).encode() if body is not None else None
    async with aiohttp.ClientSession() as session:
        async with session.request(
            method,
            url,
            data=data,
            headers=hdrs,
            timeout=aiohttp.ClientTimeout(total=timeout),
        ) as resp:
            raw = await resp.read()
            if resp.status >= 400:
                try:
                    err = json.loads(raw)
                except Exception:
                    err = {}
                msg = err.get("error") or err.get("message") or raw.decode(errors="replace")
                if resp.status == 401 or resp.status == 403:
                    raise AuthError(msg, err)
                if resp.status == 429:
                    raise TierLimitError(msg, err)
                raise SandflareError(resp.status, msg, err)
            if not raw:
                return {}
            try:
                return json.loads(raw)
            except Exception:
                return {}


class AsyncSandbox:
    """
    Async version of Sandbox. Fully async/await API backed by Firecracker microVMs.

    Usage::

        async with await AsyncSandbox.create("agent") as sb:
            result = await sb.exec("echo hello")
            print(result.stdout)

        # Or manually:
        sb = await AsyncSandbox.create("agent")
        try:
            result = await sb.exec("python3 script.py")
        finally:
            await sb.delete()
    """

    def __init__(self, info: SandboxInfo, base_url: str | None = None,
                 api_key: str | None = None):
        self._info    = info
        self._base    = _resolve_base_url(base_url)
        self._api_key = _resolve_api_key(api_key)

    # -- Context manager --

    async def __aenter__(self) -> "AsyncSandbox":
        return self

    async def __aexit__(self, *_: Any) -> None:
        try:
            await self.delete()
        except Exception:
            pass

    # -- Factory methods --

    @classmethod
    async def create(
        cls,
        label:          str = "",
        template_id:    str = "",
        snapshot_id:    str | None = None,
        size:           str = "nano",
        tier:           str | None = None,
        ttl_hours:      int = 0,
        env:            dict[str, str] | None = None,
        ephemeral:      bool = False,
        metadata:       dict | None = None,
        base_url:       str | None = None,
        api_key:        str | None = None,
        wait_timeout:   int = 120,
        auto_snapshot_interval_mins: int = 0,
        volumes:        "dict[str, Union['Volume', str]] | None" = None,
    ) -> "AsyncSandbox":
        """Create a new sandbox asynchronously."""
        payload: dict[str, Any] = {
            "label": label,
            "size": tier or size,
            "ephemeral": ephemeral,
        }
        if snapshot_id:
            payload["snapshot_id"] = snapshot_id
        if ttl_hours:
            payload["ttl_hours"] = ttl_hours
        if template_id and not snapshot_id:
            payload["template_id"] = template_id
        if env:
            payload["env_vars"] = env
        if metadata:
            payload["metadata"] = metadata
        if auto_snapshot_interval_mins >= 5:
            payload["auto_snapshot_interval_mins"] = auto_snapshot_interval_mins
        if volumes:
            payload["volumes"] = {
                path: (vol.id if isinstance(vol, Volume) else vol)
                for path, vol in volumes.items()
            }
        resolved_base = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        hdrs: dict[str, str] = {}
        if key:
            hdrs["X-API-Key"] = key
            hdrs["User-Agent"] = "sandflare-sdk/async/1.0"
        raw = await _async_req("POST", f"{resolved_base}/sandboxes", payload, headers=hdrs, timeout=min(60, wait_timeout))
        return cls(_sb_info_from_raw(raw), base_url=resolved_base, api_key=key)

    @classmethod
    async def get(cls, name: str, base_url: str | None = None,
                  api_key: str | None = None) -> "AsyncSandbox":
        """Attach to an existing sandbox."""
        resolved_base = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        hdrs: dict[str, str] = {}
        if key:
            hdrs["X-API-Key"] = key
        raw = await _async_req("GET", f"{resolved_base}/sandboxes/{name}", headers=hdrs, timeout=10)
        if raw.get("status") == "absent":
            raise SandflareError(404, f"Sandbox '{name}' not found", raw)
        return cls(_sb_info_from_raw(raw), base_url=resolved_base, api_key=key)

    @classmethod
    async def list(
        cls,
        label: str | None = None,
        metadata: dict | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
    ) -> "list[AsyncSandbox]":
        """List sandboxes, optionally filtered by label or metadata."""
        resolved_base = _resolve_base_url(base_url)
        key = _resolve_api_key(api_key)
        url = f"{resolved_base}/sandboxes"
        params: list[str] = []
        if label:
            params.append(f"label={urllib.parse.quote(label)}")
        if metadata:
            params.append(f"metadata={urllib.parse.quote(json.dumps(metadata))}")
        if params:
            url += "?" + "&".join(params)
        hdrs: dict[str, str] = {}
        if key:
            hdrs["X-API-Key"] = key
        raw_list = await _async_req("GET", url, headers=hdrs, timeout=10)
        return [cls(_sb_info_from_raw(r), base_url=resolved_base, api_key=key) for r in raw_list]

    # -- Properties --

    @property
    def id(self) -> str:
        return self._info.name

    @property
    def name(self) -> str:
        return self._info.name

    @property
    def status(self) -> str:
        return self._info.status

    @property
    def info(self) -> SandboxInfo:
        return self._info

    @property
    def agent_url(self) -> str:
        return self._info.agent_url

    @property
    def public_url(self) -> str:
        return self._info.public_url

    def get_preview_url(self, port: int = 3000) -> str:
        sb_name = self._info.name
        return f"https://{port}-{sb_name}.sandflare.io"

    # -- Execution --

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {}
        if self._api_key:
            h["X-API-Key"] = self._api_key
            h["User-Agent"] = "sandflare-sdk/async/1.0"
        return h

    async def exec(
        self,
        cmd: str,
        timeout: int = 30,
        cwd: str = "/home/user",
        env: dict[str, str] | None = None,
    ) -> ExecResult:
        """Execute a shell command inside the sandbox."""
        sb_id = self._info.name
        payload: dict[str, Any] = {"cmd": cmd, "timeout": timeout, "cwd": cwd}
        if env:
            payload["env"] = env
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/exec",
            payload, headers=self._headers(), timeout=timeout + 10,
        )
        return ExecResult(
            exit_code=raw.get("exit_code", -1),
            stdout=raw.get("stdout", ""),
            stderr=raw.get("stderr", ""),
            ok=raw.get("exit_code", -1) == 0,
        )

    async def run_python(self, code: str, timeout: int = 30) -> ExecResult:
        """Run Python code in a fresh interpreter."""
        sb_id = self._info.name
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/run/python",
            {"code": code, "timeout": timeout}, headers=self._headers(), timeout=timeout + 10,
        )
        return ExecResult(
            exit_code=raw.get("exit_code", -1),
            stdout=raw.get("stdout", ""),
            stderr=raw.get("stderr", ""),
            ok=raw.get("exit_code", -1) == 0,
        )

    async def run_node(self, code: str, timeout: int = 30) -> ExecResult:
        """Run JavaScript/Node.js code in a fresh process."""
        sb_id = self._info.name
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/run/node",
            {"code": code, "timeout": timeout}, headers=self._headers(), timeout=timeout + 10,
        )
        return ExecResult(
            exit_code=raw.get("exit_code", -1),
            stdout=raw.get("stdout", ""),
            stderr=raw.get("stderr", ""),
            ok=raw.get("exit_code", -1) == 0,
        )

    async def run_code(self, code: str, context: str = "default", timeout: int = 60) -> CodeResult:
        """Run Python in a persistent stateful Jupyter kernel."""
        sb_id = self._info.name
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/run/kernel",
            {"code": code, "context_id": context, "timeout": timeout},
            headers=self._headers(), timeout=timeout + 10,
        )
        return CodeResult(
            text=raw.get("text"),
            stdout=raw.get("stdout", ""),
            stderr=raw.get("stderr", ""),
            png=raw.get("png"),
            html=raw.get("html"),
            error=raw.get("error"),
            ok=not raw.get("error"),
        )

    async def astream(
        self,
        cmd: str,
        cwd: str = "/home/user",
        timeout: int = 300,
    ) -> "AsyncGenerator[StreamEvent, None]":
        """
        Stream a shell command's output in real-time via SSE.

        Usage::

            async for event in sb.astream("python3 train.py"):
                if event.event in ("stdout", "stderr"):
                    print(event.line, end="", flush=True)
                elif event.event == "done":
                    print(f"\\nexited {event.exit_code}")
        """
        try:
            import aiohttp
        except ImportError:
            raise ImportError(
                "aiohttp is required for astream(). Install with: pip install aiohttp"
            )
        sb_id = self._info.name
        qs = f"cmd={urllib.parse.quote(cmd)}&timeout={timeout}&cwd={urllib.parse.quote(cwd)}"
        url = f"{self._base}/sandboxes/{sb_id}/exec/stream?{qs}"
        hdrs = self._headers()
        hdrs["Accept"] = "text/event-stream"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=hdrs, timeout=aiohttp.ClientTimeout(total=timeout + 10)) as resp:
                buffer = ""
                async for chunk in resp.content:
                    buffer += chunk.decode(errors="replace")
                    while "\n\n" in buffer:
                        block, buffer = buffer.split("\n\n", 1)
                        event_type = "stdout"
                        data_str = ""
                        for line in block.splitlines():
                            if line.startswith("event: "):
                                event_type = line[7:].strip()
                            elif line.startswith("data: "):
                                data_str = line[6:].strip()
                        if not data_str:
                            continue
                        try:
                            payload = json.loads(data_str)
                        except Exception:
                            continue
                        ev = StreamEvent(event=event_type, data=payload)
                        yield ev
                        if event_type == "done":
                            return

    # -- File operations --

    async def write_file(self, path: str, content: "str | bytes") -> None:
        """Write a file into the sandbox."""
        sb_id = self._info.name
        if isinstance(content, bytes):
            body_bytes = content
        else:
            body_bytes = content.encode()
        try:
            import aiohttp
        except ImportError:
            raise ImportError("aiohttp is required. pip install aiohttp")
        url = f"{self._base}/sandboxes/{sb_id}/files?path={urllib.parse.quote(path)}"
        hdrs = self._headers()
        hdrs["Content-Type"] = "application/octet-stream"
        async with aiohttp.ClientSession() as session:
            async with session.post(url, data=body_bytes, headers=hdrs,
                                    timeout=aiohttp.ClientTimeout(total=30)) as resp:
                if resp.status >= 400:
                    raise SandflareError(resp.status, f"write_file failed: {await resp.text()}", {})

    async def read_file(self, path: str) -> str:
        """Read a file from the sandbox."""
        sb_id = self._info.name
        raw = await _async_req(
            "GET", f"{self._base}/sandboxes/{sb_id}/files?path={urllib.parse.quote(path)}",
            headers=self._headers(), timeout=30,
        )
        return raw.get("content", "")

    async def ls(self, path: str = "/home/user") -> list[FileEntry]:
        """List directory contents."""
        sb_id = self._info.name
        raw = await _async_req(
            "GET", f"{self._base}/sandboxes/{sb_id}/ls?path={urllib.parse.quote(path)}",
            headers=self._headers(), timeout=10,
        )
        entries = raw if isinstance(raw, list) else raw.get("files", [])
        return [
            FileEntry(
                name=e.get("name", ""),
                path=e.get("path", ""),
                is_dir=e.get("is_dir", False),
                size=e.get("size", 0),
                mtime=e.get("mtime", ""),
            )
            for e in entries
        ]

    async def upload(self, src: "str | bytes | os.PathLike", remote_path: str) -> None:
        """Upload a local file into the sandbox."""
        if isinstance(src, (str, os.PathLike)):
            with open(src, "rb") as f:
                content = f.read()
        else:
            content = src
        await self.write_file(remote_path, content)

    async def download(self, remote_path: str) -> bytes:
        """Download a file from the sandbox."""
        content = await self.read_file(remote_path)
        return content.encode()

    # -- Package management --

    async def install(self, pkg: str, runtime: str = "pip") -> ExecResult:
        """Install a package inside the sandbox."""
        sb_id = self._info.name
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/install",
            {"pkg": pkg, "runtime": runtime}, headers=self._headers(), timeout=120,
        )
        return ExecResult(
            exit_code=raw.get("exit_code", -1),
            stdout=raw.get("stdout", ""),
            stderr=raw.get("stderr", ""),
            ok=raw.get("exit_code", -1) == 0,
        )

    async def git_clone(
        self,
        url: str,
        path: str | None = None,
        branch: str | None = None,
        token: str | None = None,
    ) -> GitCloneResult:
        """Clone a git repository into the sandbox."""
        sb_id = self._info.name
        payload: dict[str, Any] = {"url": url}
        if path:
            payload["path"] = path
        if branch:
            payload["branch"] = branch
        if token:
            payload["token"] = token
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/git/clone",
            payload, headers=self._headers(), timeout=120,
        )
        return GitCloneResult(
            path=raw.get("path", path or "/home/user/repo"),
            repo=raw.get("repo", url),
            branch=raw.get("branch", branch),
            output=raw.get("output", ""),
        )

    # -- Lifecycle --

    async def health(self) -> dict:
        sb_id = self._info.name
        return await _async_req(
            "GET", f"{self._base}/sandboxes/{sb_id}/health",
            headers=self._headers(), timeout=10,
        )

    async def pause(self) -> None:
        sb_id = self._info.name
        await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/pause",
            headers=self._headers(), timeout=30,
        )

    async def resume(self) -> None:
        sb_id = self._info.name
        await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/resume",
            headers=self._headers(), timeout=30,
        )

    async def create_snapshot(self, label: str = "") -> SnapshotInfo:
        sb_id = self._info.name
        raw = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/snapshot",
            {"label": label} if label else {},
            headers=self._headers(), timeout=60,
        )
        return _snapshot_info_from_raw(raw)

    async def fork(self, n: int = 1, size: str = "nano") -> "list[AsyncSandbox]":
        """Clone this live sandbox into *n* parallel copies.

        Async variant of :meth:`Sandbox.fork`. Forked sandboxes are regular
        sandboxes billed identically to normally created ones. The ephemeral
        intermediate snapshot is automatically discarded.

        Args:
            n:    Number of copies to create (1–8, default 1).
            size: VM size for each fork. Defaults to "nano".

        Returns:
            List of new :class:`AsyncSandbox` objects.

        Example::

            fork_a, fork_b = await sandbox.fork(n=2)
        """
        sb_id = self._info.name
        r = await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/fork",
            {"n": n, "size": size},
            headers=self._headers(), timeout=120,
        )
        forks = []
        for raw in r.get("forks", []):
            if isinstance(raw, dict):
                forks.append(AsyncSandbox(
                    _sb_info_from_raw(raw),
                    base_url=self._base,
                    api_key=self._api_key,
                ))
        return forks

    @property
    def browser(self) -> "AsyncBrowserClient":
        """HTTP control API for the browser inside this sandbox.

        Only available on sandboxes created with the ``browser-agent`` template.
        """
        return AsyncBrowserClient(self)

    async def keep_alive(self, seconds: int = 300) -> None:
        """Extend the sandbox lifetime by *seconds* from now.

        Async variant of :meth:`Sandbox.keep_alive`.

        Args:
            seconds: How many seconds to keep alive from now (max 86 400).

        Example::

            await sandbox.keep_alive(3600)
        """
        sb_id = self._info.name
        await _async_req(
            "POST", f"{self._base}/sandboxes/{sb_id}/timeout",
            {"timeout": seconds},
            headers=self._headers(), timeout=15,
        )

    async def keep_alive_forever(self, interval: int = 60) -> None:
        """Prevent this sandbox from expiring by pinging every *interval* seconds.

        Starts an asyncio background task.  The task is automatically cancelled
        when the event loop shuts down.

        Args:
            interval: Ping interval in seconds (default 60).

        Example::

            await sandbox.keep_alive_forever()
        """
        import asyncio

        async def _ping() -> None:
            while True:
                try:
                    await self.keep_alive(interval * 3)
                except Exception:  # noqa: BLE001
                    pass
                await asyncio.sleep(interval)

        asyncio.ensure_future(_ping())
        """Delete the sandbox."""
        sb_id = self._info.name
        try:
            await _async_req(
                "DELETE", f"{self._base}/sandboxes/{sb_id}",
                headers=self._headers(), timeout=15,
            )
        except SandflareError:
            pass

    async def close(self) -> None:
        """Alias for delete()."""
        await self.delete()

    async def get_processes(self) -> list[ProcessInfo]:
        sb_id = self._info.name
        raw = await _async_req(
            "GET", f"{self._base}/sandboxes/{sb_id}/processes",
            headers=self._headers(), timeout=10,
        )
        procs = raw if isinstance(raw, list) else raw.get("processes", [])
        return [
            ProcessInfo(
                pid=p.get("pid", 0),
                command=p.get("cmd", p.get("command", "")),
                cpu_percent=p.get("cpu_pct", p.get("cpu_percent", 0.0)),
                memory_percent=p.get("mem_mb", p.get("memory_percent", 0.0)),
            )
            for p in procs
        ]

    async def kill_process(self, pid: int) -> None:
        sb_id = self._info.name
        await _async_req(
            "DELETE", f"{self._base}/sandboxes/{sb_id}/processes/{pid}",
            headers=self._headers(), timeout=10,
        )

    def __repr__(self) -> str:
        return f"<AsyncSandbox id={self.id!r} status={self.status!r}>"


# ── AsyncBrowserClient ────────────────────────────────────────────────────────

class AsyncBrowserClient:
    """Async HTTP control API for the live Chromium browser inside a sandbox.

    Obtained via ``async_sandbox.browser``. Async counterpart of
    :class:`BrowserClient`.
    """

    def __init__(self, sandbox: "AsyncSandbox") -> None:
        self._sb = sandbox

    async def _post(self, path: str, body: dict | None = None) -> dict:
        sb_id = self._sb._info.name
        return await _async_req(
            "POST",
            f"{self._sb._base}/sandboxes/{sb_id}/browser{path}",
            body or {},
            headers=self._sb._headers(),
            timeout=30,
        )

    async def _get(self, path: str) -> dict:
        sb_id = self._sb._info.name
        return await _async_req(
            "GET",
            f"{self._sb._base}/sandboxes/{sb_id}/browser{path}",
            headers=self._sb._headers(),
            timeout=10,
        )

    async def status(self) -> dict:
        """Return browser status: ``{ready, status, url, title}``."""
        return await self._get("/status")

    async def start(self) -> dict:
        """Launch Chromium (no-op if already running)."""
        return await self._post("/start")

    async def stop(self) -> dict:
        """Stop the Chromium process."""
        return await self._post("/stop")

    async def navigate(self, url: str) -> dict:
        """Navigate to *url*. Launches Chromium automatically if not running."""
        return await self._post("/navigate", {"url": url})

    async def click(self, x: float, y: float) -> dict:
        """Click at viewport coordinates *(x, y)*."""
        return await self._post("/click", {"x": x, "y": y})

    async def type(self, text: str) -> dict:  # noqa: A003
        """Type *text* at the current cursor position."""
        return await self._post("/type", {"text": text})

    async def scroll(self, x: float = 0, y: float = 0,
                     delta_x: float = 0, delta_y: float = 100) -> dict:
        """Scroll at position *(x, y)* by *(delta_x, delta_y)* pixels."""
        return await self._post("/scroll", {"x": x, "y": y, "delta_x": delta_x, "delta_y": delta_y})

    async def screenshot(self) -> str:
        """Capture a PNG screenshot. Returns base64-encoded PNG string."""
        r = await self._get("/screenshot")
        return r.get("png", "")

    async def evaluate(self, expression: str) -> Any:
        """Evaluate a JavaScript *expression* in the page context."""
        r = await self._post("/evaluate", {"expression": expression})
        return r.get("result")

    @property
    def vnc_url(self) -> str:
        """noVNC live view URL."""
        return f"https://6080-{self._sb._info.name}.sandflare.io"

    @property
    def cdp_url(self) -> str:
        """Raw Chrome DevTools Protocol endpoint URL."""
        return f"https://9222-{self._sb._info.name}.sandflare.io"

