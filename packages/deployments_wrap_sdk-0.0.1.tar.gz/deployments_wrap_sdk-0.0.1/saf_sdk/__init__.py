"""deployments-wrap-sdk.

Provides lightweight wrappers for deploying agents from popular frameworks
(Google ADK, Strands, etc.) to LangSmith without requiring knowledge of
LangGraph internals.
"""

__version__ = "0.0.1"
