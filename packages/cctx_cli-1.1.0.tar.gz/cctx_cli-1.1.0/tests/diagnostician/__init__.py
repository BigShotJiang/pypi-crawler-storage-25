"""Diagnostician tests."""
