"""Pattern classifiers."""
