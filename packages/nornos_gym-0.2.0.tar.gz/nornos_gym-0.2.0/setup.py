from setuptools import setup, find_packages

setup(
    name="nornos-gym",
    version="0.2.0",
    description="Gym-compatible wrapper for the NornOS Hosted Research API (research.laif2.com).",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/wmaass/nornos_v3/tree/master/research/python",
    project_urls={
        "Documentation": "https://github.com/wmaass/nornos_v3/blob/master/research/python/README.md",
        "Source": "https://github.com/wmaass/nornos_v3",
    },
    python_requires=">=3.11",
    packages=find_packages(exclude=["tests", "tests.*"]),
    install_requires=[
        "gymnasium>=0.29",
        "numpy>=1.24",
        "requests>=2.28",
    ],
    extras_require={
        "dev": ["pytest>=7.0"],
    },
    classifiers=[
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: Other/Proprietary License",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Operating System :: OS Independent",
    ],
)
