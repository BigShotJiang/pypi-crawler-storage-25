"""Pytest tests for NornOSEnv against the live research stack."""
from __future__ import annotations

import re

import numpy as np
import pytest

from nornos_gym import NornOSEnv


SHA256_HEX = re.compile(r"^[0-9a-f]{64}$")


def test_reset_returns_obs_and_info(live_stack: bool) -> None:
    env = NornOSEnv()
    obs, info = env.reset()
    assert isinstance(obs, np.ndarray)
    assert obs.dtype == np.float32
    assert info["seedId"] == "default"
    assert info["stepCount"] == 0
    assert "auditHashes" in info
    assert len(info["auditHashes"]) == len(env.entity_ids)
    env.close()


def test_reset_determinism(live_stack: bool) -> None:
    env = NornOSEnv()
    obs1, info1 = env.reset()
    obs2, info2 = env.reset()
    np.testing.assert_array_equal(obs1, obs2)
    # auditHashes differ across calls because chain_seq advances.
    assert info1["auditHashes"] != info2["auditHashes"]
    env.close()


def test_step_reward_in_bounds(fresh_env: NornOSEnv) -> None:
    rng = np.random.default_rng(42)
    for _ in range(10):
        action = {
            "entityId": int(rng.integers(0, len(fresh_env.entity_ids))),
            "features": rng.random(len(fresh_env.feature_keys)).astype(np.float32),
        }
        _obs, reward, terminated, truncated, _info = fresh_env.step(action)
        assert 0.0 <= reward <= 1.0, f"reward out of bounds: {reward}"
        assert terminated is False
        assert truncated is False


def test_step_increments_stepcount(fresh_env: NornOSEnv) -> None:
    action = {
        "entityId": 0,
        "features": np.zeros(len(fresh_env.feature_keys), dtype=np.float32),
    }
    _obs, _reward, _term, _trunc, info1 = fresh_env.step(action)
    _obs, _reward, _term, _trunc, info2 = fresh_env.step(action)
    assert info2["stepCount"] == info1["stepCount"] + 1


def test_step_audit_hash_present(fresh_env: NornOSEnv) -> None:
    action = {
        "entityId": 0,
        "features": np.zeros(len(fresh_env.feature_keys), dtype=np.float32),
    }
    _obs, _reward, _term, _trunc, info = fresh_env.step(action)
    audit = info["auditHash"]
    assert isinstance(audit, str)
    assert SHA256_HEX.match(audit), f"not 64-char hex: {audit}"
