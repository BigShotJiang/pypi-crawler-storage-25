"""TASK-03 — Tests für HTTP-Client mit Bearer + 429-Retry.

Mockt requests.request mit unittest.mock — kein responses-Library
nötig, kein Live-Stack erforderlich.
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from nornos_gym._http import (
    NornOSAuthError,
    NornOSHTTPClient,
    RateLimitError,
)


def _mock_response(status_code: int, json_body: dict | None = None,
                   headers: dict | None = None) -> MagicMock:
    resp = MagicMock()
    resp.status_code = status_code
    resp.headers = headers or {}
    resp.content = b"{}" if json_body is None else b'{"x":1}'
    resp.json.return_value = json_body if json_body is not None else {}
    resp.text = ""
    if status_code >= 400:
        from requests.exceptions import HTTPError
        resp.raise_for_status.side_effect = HTTPError(f"HTTP {status_code}")
    else:
        resp.raise_for_status.return_value = None
    return resp


# ─────────────────────────────────────────────────────────────────────────────
# Auth-Header-Forwarding
# ─────────────────────────────────────────────────────────────────────────────

def test_request_without_api_key_omits_authorization_header() -> None:
    client = NornOSHTTPClient(base_url="http://test", api_key=None)
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(200, {"ok": True})
        client.get_json("/some/path")
    assert mock_req.call_args is not None
    headers = mock_req.call_args.kwargs["headers"]
    assert "authorization" not in headers


def test_request_with_api_key_sends_bearer_authorization() -> None:
    client = NornOSHTTPClient(base_url="http://test", api_key="nornos-research-abc-123")
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(200, {"ok": True})
        client.get_json("/some/path")
    headers = mock_req.call_args.kwargs["headers"]
    assert headers["authorization"] == "Bearer nornos-research-abc-123"


# ─────────────────────────────────────────────────────────────────────────────
# Auth-Errors
# ─────────────────────────────────────────────────────────────────────────────

def test_401_raises_NornOSAuthError() -> None:
    client = NornOSHTTPClient(base_url="http://test", api_key=None)
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(
            401, {"error": "missing_or_malformed_authorization"}
        )
        with pytest.raises(NornOSAuthError, match="missing_or_malformed_authorization"):
            client.get_json("/internal/research/reset")


def test_403_raises_NornOSAuthError() -> None:
    client = NornOSHTTPClient(base_url="http://test", api_key="nornos-research-bogus")
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(
            403, {"error": "invalid_or_revoked_key"}
        )
        with pytest.raises(NornOSAuthError, match="invalid_or_revoked_key"):
            client.post_json("/internal/research/reset", {"seedId": "default"})


# ─────────────────────────────────────────────────────────────────────────────
# 429-Retry mit exponential backoff
# ─────────────────────────────────────────────────────────────────────────────

def test_429_retries_then_succeeds() -> None:
    sleeps: list[float] = []
    client = NornOSHTTPClient(
        base_url="http://test", api_key="nornos-research-x",
        sleep=lambda s: sleeps.append(s),
        rng=lambda: 0.5,  # jitter neutral (0.5 → +0.0 mit (rng*2-1)*0.25 = 0)
    )
    with patch("requests.request") as mock_req:
        mock_req.side_effect = [
            _mock_response(429, headers={"retry-after": "0"}),
            _mock_response(429, headers={"retry-after": "0"}),
            _mock_response(200, {"ok": True}),
        ]
        out = client.get_json("/internal/research/observe")
    assert out == {"ok": True}
    assert mock_req.call_count == 3
    # 3 Versuche → 2 Sleeps. Backoff bei attempt=0 ist 1s, attempt=1 ist 2s.
    assert len(sleeps) == 2
    assert sleeps[0] == pytest.approx(1.0, abs=0.001)
    assert sleeps[1] == pytest.approx(2.0, abs=0.001)


def test_429_persistent_raises_RateLimitError_after_max_retries() -> None:
    sleeps: list[float] = []
    client = NornOSHTTPClient(
        base_url="http://test", api_key="x",
        max_retries=2, sleep=lambda s: sleeps.append(s),
        rng=lambda: 0.5,
    )
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(429, headers={"retry-after": "0"})
        with pytest.raises(RateLimitError, match="after 2 retries"):
            client.get_json("/internal/research/observe")
    # 3 Versuche (attempt 0, 1, 2), dann Raise. 2 Sleeps zwischen den Retries.
    assert mock_req.call_count == 3
    assert len(sleeps) == 2


def test_429_retry_after_header_overrides_short_backoff() -> None:
    sleeps: list[float] = []
    client = NornOSHTTPClient(
        base_url="http://test", api_key="x",
        sleep=lambda s: sleeps.append(s), rng=lambda: 0.5,
    )
    with patch("requests.request") as mock_req:
        mock_req.side_effect = [
            _mock_response(429, headers={"retry-after": "5"}),
            _mock_response(200, {"ok": True}),
        ]
        client.get_json("/path")
    # max(retry_after=5, 2^0=1) = 5
    assert sleeps[0] == pytest.approx(5.0, abs=0.001)


def test_jitter_applies_within_25_percent() -> None:
    sleeps: list[float] = []
    # rng → 1.0 → max-jitter +25%
    client = NornOSHTTPClient(
        base_url="http://test", api_key="x",
        sleep=lambda s: sleeps.append(s), rng=lambda: 1.0,
    )
    with patch("requests.request") as mock_req:
        mock_req.side_effect = [
            _mock_response(429, headers={"retry-after": "0"}),
            _mock_response(200, {}),
        ]
        client.get_json("/path")
    # base=1, jitter=+0.25 → sleep ≈ 1.25
    assert sleeps[0] == pytest.approx(1.25, abs=0.01)


# ─────────────────────────────────────────────────────────────────────────────
# Other status codes
# ─────────────────────────────────────────────────────────────────────────────

def test_400_raises_immediately_no_retry() -> None:
    sleeps: list[float] = []
    client = NornOSHTTPClient(
        base_url="http://test", api_key="x",
        sleep=lambda s: sleeps.append(s),
    )
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(400, {"error": "BAD_REQUEST"})
        with pytest.raises(Exception):  # HTTPError
            client.post_json("/path", {})
    assert mock_req.call_count == 1
    assert len(sleeps) == 0


def test_500_retries_then_raises_after_max() -> None:
    sleeps: list[float] = []
    client = NornOSHTTPClient(
        base_url="http://test", api_key="x",
        max_retries=1, sleep=lambda s: sleeps.append(s),
        rng=lambda: 0.5,
    )
    with patch("requests.request") as mock_req:
        mock_req.return_value = _mock_response(500, {"error": "internal"})
        with pytest.raises(Exception):
            client.get_json("/path")
    # 2 Versuche, 1 Sleep dazwischen
    assert mock_req.call_count == 2
    assert len(sleeps) == 1


def test_204_no_content_returns_empty_dict() -> None:
    client = NornOSHTTPClient(base_url="http://test", api_key="x")
    with patch("requests.request") as mock_req:
        resp = MagicMock()
        resp.status_code = 204
        resp.content = b""
        resp.headers = {}
        resp.json.return_value = {}
        mock_req.return_value = resp
        out = client.post_json("/path", {})
    assert out == {}
