"""Pytest tests for NornOSMultiAgentEnv."""
from __future__ import annotations

import time

import numpy as np
import pytest

from nornos_gym import NornOSMultiAgentEnv


PARTITION = {
    "A": ["entity-001", "entity-002", "entity-003", "entity-004"],
    "B": ["entity-005", "entity-006", "entity-007"],
    "C": ["entity-008", "entity-009", "entity-010"],
}


def test_multi_agent_reset_partitions_entities(live_stack: bool) -> None:
    mae = NornOSMultiAgentEnv(agent_entity_map=PARTITION)
    results = mae.reset()
    assert set(results.keys()) == {"A", "B", "C"}
    # Per-agent observation shape = entities × features. feature-count
    # comes from the seed; we don't hardcode it here, but the observation
    # divides evenly by the per-agent entity count.
    n_features_a = results["A"][0].size // len(PARTITION["A"])
    assert results["A"][0].size == len(PARTITION["A"]) * n_features_a
    assert results["B"][0].size == len(PARTITION["B"]) * n_features_a
    assert results["C"][0].size == len(PARTITION["C"]) * n_features_a
    mae.close()


def test_multi_agent_step_returns_all_results(live_stack: bool) -> None:
    """Submit 3 parallel actions, verify all 3 return successfully with
    rewards in bounds. Timing-based parallelism assertions are inherently
    flaky on macOS+Docker-Desktop with sub-50ms HTTP calls and server-side
    advisory locks serializing audit-event inserts. The PRD §14-5
    horizontal-scalability claim is verified by the slow 20-agent test
    instead."""
    mae = NornOSMultiAgentEnv(agent_entity_map=PARTITION)
    mae.reset()
    n_features = len(mae.envs["A"].feature_keys)
    actions = {
        a: {
            "entityId": 0,
            "features": np.full(n_features, 0.5, dtype=np.float32),
        }
        for a in PARTITION
    }
    results = mae.step(actions)
    assert set(results.keys()) == {"A", "B", "C"}
    for agent_id, (obs, reward, terminated, truncated, info) in results.items():
        assert isinstance(obs, np.ndarray), f"{agent_id} obs not ndarray"
        assert 0.0 <= reward <= 1.0, f"{agent_id} reward out of bounds: {reward}"
        assert terminated is False
        assert truncated is False
        assert "auditHash" in info
    mae.close()


@pytest.mark.slow
def test_multi_agent_20_concurrent_60s_no_postgres_errors(live_stack: bool) -> None:
    """PRD §14 punkt 5: 20 agents stepping at 1s intervals for 10 min.
    Test variant uses 60s for CI feasibility — same code path."""
    # Build 20 single-entity agents from the 10 default entities (2 agents
    # share each entity — that's ok for the load test, the stack must
    # tolerate concurrent acts on the same entity).
    base_entities = [f"entity-{i:03d}" for i in range(1, 11)]
    agent_map = {
        f"agent-{n:02d}": [base_entities[n % len(base_entities)]]
        for n in range(20)
    }
    mae = NornOSMultiAgentEnv(agent_entity_map=agent_map)
    mae.reset()
    n_features = len(mae.envs["agent-00"].feature_keys)
    actions = {
        a: {
            "entityId": 0,
            "features": np.full(n_features, 0.5, dtype=np.float32),
        }
        for a in agent_map
    }
    deadline = time.time() + 60.0
    rounds = 0
    while time.time() < deadline:
        results = mae.step(actions)
        # Surface any HTTPError that the inner env raised through future.result().
        for _agent_id, (_obs, reward, _term, _trunc, _info) in results.items():
            assert 0.0 <= reward <= 1.0
        rounds += 1
        time.sleep(1.0)
    mae.close()
    assert rounds >= 30, f"expected ~60 rounds in 60s, got {rounds}"
