"""Pytest tests for NornOSAdapter (no live stack required)."""
from __future__ import annotations

import numpy as np

from nornos_gym import NornOSAdapter


def test_default_extract_features_sorts_by_key() -> None:
    a = NornOSAdapter()
    out = a.extract_features({"features": {"b": 2.0, "a": 1.0}})
    np.testing.assert_array_equal(out, np.array([1.0, 2.0], dtype=np.float32))


def test_default_compute_reward_returns_score() -> None:
    a = NornOSAdapter()
    assert a.compute_reward({"score": 0.7}) == 0.7


def test_default_compute_reward_no_score_zero() -> None:
    a = NornOSAdapter()
    assert a.compute_reward({}) == 0.0
    assert a.compute_reward({"other": 0.9}) == 0.0


def test_subclass_override() -> None:
    class CircularAdapter(NornOSAdapter):
        def compute_reward(self, skill_outputs: dict) -> float:
            recyc = skill_outputs.get("recyclability_score", 0.0)
            co2 = skill_outputs.get("co2_footprint", 0.0)
            return float((1.0 - recyc) * co2)

    a = CircularAdapter()
    assert a.compute_reward({"recyclability_score": 0.2, "co2_footprint": 0.5}) == 0.4
    # Default extract_features still works on subclasses.
    out = a.extract_features({"features": {"x": 1.5}})
    np.testing.assert_array_equal(out, np.array([1.5], dtype=np.float32))
