"""HTTP-Client für die Hosted Research API.

PRD-NORNOS-CORE-002 §6 Bearer-Token-Auth + §7 Rate-Limiting/429-Retry.

Internes Modul (Underscore-Prefix). Researcher nutzen ausschließlich
NornOSEnv / NornOSMultiAgentEnv und sehen diesen Client nicht direkt.

Retry-Policy:
- 429 Too Many Requests → Retry mit exponential backoff
  delay = min(retry_after, 2 ** attempt) Sekunden, plus ±25 % Jitter
- Bis zu MAX_RETRIES=5 Versuche; danach RateLimitError raise
- 5xx Server Errors → identische Backoff-Logik (transiente Fehler)
- 4xx außer 429 → sofortiger Raise (Auth-Fehler retryen ist sinnlos)
"""
from __future__ import annotations

import random
import time
from typing import Any, Optional

import requests


DEFAULT_BASE_URL = "http://localhost:4400"
DEFAULT_TIMEOUT = 5.0
MAX_RETRIES = 5
JITTER_FRACTION = 0.25


class NornOSAuthError(Exception):
    """Raised on 401/403 — Bearer-Token fehlt, ist invalid oder revoked."""


class RateLimitError(Exception):
    """Raised wenn 429 nach MAX_RETRIES weiter persistiert."""


class NornOSHTTPClient:
    """Synchroner HTTP-Client mit Bearer-Auth + Retry-Logic.

    Stateless gegenüber dem Server — der Server hält per-Researcher-
    Counter in event_log.research_rate_log. Hier nur Retry-Bookkeeping.
    """

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        api_key: Optional[str] = None,
        request_timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
        # Hook für Tests — sonst time.sleep / random.random.
        sleep: Any = time.sleep,
        rng: Any = random.random,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.request_timeout = request_timeout
        self.max_retries = max_retries
        self._sleep = sleep
        self._rng = rng

    # ── public API ─────────────────────────────────────────────────────────

    def get_json(self, path: str, params: Optional[dict] = None) -> dict:
        return self._request("GET", path, params=params)

    def post_json(self, path: str, body: dict) -> dict:
        return self._request("POST", path, json=body)

    # ── internal ───────────────────────────────────────────────────────────

    def _headers(self) -> dict:
        out = {"accept": "application/json"}
        if self.api_key:
            out["authorization"] = f"Bearer {self.api_key}"
        return out

    def _request(self, method: str, path: str, **kwargs: Any) -> dict:
        url = f"{self.base_url}{path}"
        attempt = 0
        while True:
            resp = requests.request(
                method,
                url,
                headers=self._headers(),
                timeout=self.request_timeout,
                **kwargs,
            )

            # 2xx → success
            if 200 <= resp.status_code < 300:
                if resp.status_code == 204 or not resp.content:
                    return {}
                return resp.json()

            # 401/403 → no point retrying. Raise auth-spezifisch.
            if resp.status_code in (401, 403):
                msg = self._safe_msg(resp)
                raise NornOSAuthError(
                    f"{resp.status_code} {msg} — check api_key against "
                    f"{self.base_url}"
                )

            # 429 / 5xx → retry mit backoff
            if resp.status_code == 429 or 500 <= resp.status_code < 600:
                if attempt >= self.max_retries:
                    if resp.status_code == 429:
                        raise RateLimitError(
                            f"429 after {self.max_retries} retries — "
                            f"raise nornos-gym rate limit or slow your loop"
                        )
                    resp.raise_for_status()  # 5xx → HTTPError
                delay = self._compute_delay(resp, attempt)
                self._sleep(delay)
                attempt += 1
                continue

            # Other 4xx → raise sofort
            resp.raise_for_status()
            return resp.json()  # unreachable; keeps mypy happy

    def _compute_delay(self, resp: requests.Response, attempt: int) -> float:
        """Exponential backoff mit Jitter.

        Server sendet bei 429 üblicherweise einen Retry-After-Header in
        Sekunden. Wir respektieren ihn als Mindestwert; falls kürzer als
        unser eigener Backoff, nehmen wir den eigenen.

          base_delay = max(retry_after, 2 ** attempt)
          jitter = base_delay * (1 + uniform(-0.25, +0.25))

        attempt=0 → ≈1 s, attempt=4 → ≈16 s.
        """
        retry_after_str = resp.headers.get("retry-after", "0")
        try:
            retry_after = float(retry_after_str)
        except (TypeError, ValueError):
            retry_after = 0.0

        backoff = float(2 ** attempt)
        base = max(retry_after, backoff)
        jitter = (self._rng() * 2 - 1) * JITTER_FRACTION
        return max(0.0, base * (1 + jitter))

    @staticmethod
    def _safe_msg(resp: requests.Response) -> str:
        try:
            j = resp.json()
            err = j.get("error", "")
            return err if isinstance(err, str) else str(j)
        except Exception:
            return resp.text[:200] if resp.text else ""
