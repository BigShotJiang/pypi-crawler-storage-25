"""Gym space builders for NornOSEnv.

Observation space is a flat Box (n_entities * n_features), filled in
entityId-ASC × feature-key-ASC order. The flat layout keeps the env
compatible with off-the-shelf agents that expect a 1-D Box.

Action space is a Dict { entityId: Discrete(n), features: Box } —
Discrete because the env exposes a stable entity ordering at reset()
time. Researchers who prefer named-entity actions can decode the index
back to entityId via env.entity_ids[action["entityId"]].
"""
from __future__ import annotations

import numpy as np
from gymnasium import spaces


def build_observation_space(n_entities: int, n_features: int) -> spaces.Box:
    return spaces.Box(
        low=-np.inf,
        high=np.inf,
        shape=(n_entities * n_features,),
        dtype=np.float32,
    )


def build_action_space(n_entities: int, feature_keys: list[str]) -> spaces.Dict:
    n_features = len(feature_keys)
    return spaces.Dict(
        {
            "entityId": spaces.Discrete(n_entities),
            "features": spaces.Box(
                low=0.0, high=1.0, shape=(n_features,), dtype=np.float32
            ),
        }
    )
