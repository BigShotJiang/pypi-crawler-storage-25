"""NornOSMultiAgentEnv — MARL wrapper over NornOSEnv.

Maps each agent to a subset of entityIds. Internally holds one NornOSEnv
per agent, all pointing at the SAME shared NornOS stack and seedId.
reset() resets the shared state once and then snapshots each agent's
observation. step(actions) submits per-agent acts via a ThreadPoolExecutor
so HTTP calls run in parallel.

True asyncio.gather would require an aiohttp dep — `requests` is sync.
ThreadPoolExecutor gives the same speedup for I/O-bound parallelism with
zero new dependencies. Native async via aiohttp is deferred to v2.

PRD-NORNOS-CORE-001 §5.6.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Optional

import numpy as np

from .env import (
    DEFAULT_BASE_URL,
    DEFAULT_SEED_ID,
    DEFAULT_TIMEOUT,
    NornOSEnv,
)


class NornOSMultiAgentEnv:
    """MARL wrapper. agent_entity_map: dict[agentId -> list[entityId]]."""

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        seed_id: str = DEFAULT_SEED_ID,
        agent_entity_map: Optional[dict[str, list[str]]] = None,
        request_timeout: float = DEFAULT_TIMEOUT,
        api_key: Optional[str] = None,
    ) -> None:
        if not agent_entity_map:
            raise ValueError("agent_entity_map is required and must be non-empty")
        self.base_url = base_url.rstrip("/")
        self.seed_id = seed_id
        self.agent_entity_map = {a: list(eids) for a, eids in agent_entity_map.items()}
        self.request_timeout = request_timeout
        self.api_key = api_key
        self.envs: dict[str, NornOSEnv] = {
            agent_id: NornOSEnv(
                base_url=base_url,
                seed_id=seed_id,
                entity_filter=entity_ids,
                request_timeout=request_timeout,
                actor_id=f"nornos-gym/{agent_id}",
                api_key=api_key,
            )
            for agent_id, entity_ids in self.agent_entity_map.items()
        }

    # ── Gym-style multi-agent API ─────────────────────────────────────────

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ) -> dict[str, tuple[np.ndarray, dict]]:
        # Reset once via the first agent's env (one HTTP reset for the
        # shared stack), then have each per-agent env fetch its own
        # filtered snapshot. We can't simply reset() each env since that
        # would issue N reset POSTs and the last one's audit hashes would
        # win.
        agent_ids = list(self.envs.keys())
        first = self.envs[agent_ids[0]]
        first.reset(seed=seed, options=options)
        out: dict[str, tuple[np.ndarray, dict]] = {agent_ids[0]: self._snapshot(first)}
        for agent_id in agent_ids[1:]:
            env = self.envs[agent_id]
            self._sync_observe(env)
            out[agent_id] = self._snapshot(env)
        return out

    def step(
        self, actions: dict[str, dict]
    ) -> dict[str, tuple[np.ndarray, float, bool, bool, dict]]:
        if not actions:
            return {}
        # Parallel HTTP fan-out via ThreadPoolExecutor. requests is sync;
        # ThreadPoolExecutor + I/O-bound calls keeps the GIL out of the way.
        with ThreadPoolExecutor(max_workers=len(actions)) as pool:
            futures = {
                agent_id: pool.submit(self.envs[agent_id].step, action)
                for agent_id, action in actions.items()
                if agent_id in self.envs
            }
            return {agent_id: fut.result() for agent_id, fut in futures.items()}

    def close(self) -> None:
        for env in self.envs.values():
            env.close()

    # ── internal ──────────────────────────────────────────────────────────

    def _sync_observe(self, env: NornOSEnv) -> None:
        """Populate env.entity_ids/feature_keys from the shared stack
        without re-issuing a /reset (which would mint new audit hashes
        for the whole world)."""
        body = env._get_json(
            "/internal/research/observe", params={"seedId": env.seed_id}
        )
        entities = body["entities"]
        if env.entity_filter is not None:
            keep = set(env.entity_filter)
            entities = [e for e in entities if e["entityId"] in keep]
        entities.sort(key=lambda e: e["entityId"])
        env.entity_ids = [e["entityId"] for e in entities]
        feat_set: set[str] = set()
        for e in entities:
            feat_set.update(e["features"].keys())
        env.feature_keys = sorted(feat_set)
        from .spaces import build_action_space, build_observation_space

        env.observation_space = build_observation_space(
            len(env.entity_ids), len(env.feature_keys)
        )
        env.action_space = build_action_space(len(env.entity_ids), env.feature_keys)
        env._last_step_count = body["stepCount"]

    def _snapshot(self, env: NornOSEnv) -> tuple[np.ndarray, dict]:
        body = env._get_json(
            "/internal/research/observe", params={"seedId": env.seed_id}
        )
        entities = body["entities"]
        if env.entity_filter is not None:
            keep = set(env.entity_filter)
            entities = [e for e in entities if e["entityId"] in keep]
        entities.sort(key=lambda e: e["entityId"])
        obs = env._build_obs(entities)
        info = {
            "seedId": body["seedId"],
            "stepCount": body["stepCount"],
            "auditHashes": [e.get("auditHash") for e in entities],
        }
        return obs, info
