"""NornOSEnv — Gym 0.26+ wrapper around the NornOS Research Snapshot API.

Treats the NornOS event-log-service-research stack as a black-box env:
- reset() POSTs /internal/research/reset and constructs spaces from the
  returned entity list.
- step(action) POSTs /internal/research/act and re-fetches /observe to
  build the next observation.

Observation layout: flat numpy array shape (n_entities * n_features,),
in entityId-ASC × feature-key-ASC order. n_features is the union of all
feature keys across the entity set, sorted alphabetically.

action shape: {"entityId": int (Discrete index), "features": np.ndarray
of length n_features in feature-key-ASC order}.

terminated/truncated are always False — episodic termination is the
researcher's responsibility (subclass and override if needed).
"""
from __future__ import annotations

from typing import Any, Optional

import numpy as np
from gymnasium import Env

from ._http import (
    DEFAULT_BASE_URL,
    DEFAULT_TIMEOUT,
    NornOSAuthError,
    NornOSHTTPClient,
    RateLimitError,
)
from .spaces import build_action_space, build_observation_space

DEFAULT_SEED_ID = "default"
DEFAULT_ACTOR_ID = "nornos-gym"


class NornOSEnv(Env):
    """Gym-compatible env over the NornOS Research Snapshot API."""

    metadata = {"render_modes": []}

    def __init__(
        self,
        base_url: str = DEFAULT_BASE_URL,
        seed_id: str = DEFAULT_SEED_ID,
        entity_filter: Optional[list[str]] = None,
        request_timeout: float = DEFAULT_TIMEOUT,
        actor_id: str = DEFAULT_ACTOR_ID,
        api_key: Optional[str] = None,
    ) -> None:
        """Initialize the env.

        Args:
            base_url: NornOS Research API base URL. Default localhost.
                For the hosted API use ``https://research.laif2.com``.
            api_key: Bearer token issued by the operator (PRD-NORNOS-CORE-002).
                Required when talking to the hosted endpoint; optional
                for local stacks. Format ``nornos-research-<uuid>``.
            seed_id: NornOS-side scenario id (NOT the Gym RNG seed).
            entity_filter: Optional whitelist of entityIds to keep.
            request_timeout: Per-request timeout in seconds.
            actor_id: Audit-trail actorId for /act calls. Server overrides
                this with the auth-derived ``nornos-gym/<researcher>`` when
                api_key is in use.
        """
        super().__init__()
        self.base_url = base_url.rstrip("/")
        self.seed_id = seed_id
        self.entity_filter = list(entity_filter) if entity_filter else None
        self.request_timeout = request_timeout
        self.actor_id = actor_id
        self.api_key = api_key
        self._client = NornOSHTTPClient(
            base_url=self.base_url,
            api_key=self.api_key,
            request_timeout=self.request_timeout,
        )
        # Filled by reset():
        self.entity_ids: list[str] = []
        self.feature_keys: list[str] = []
        self._last_step_count: int = 0

    # ── HTTP helpers (delegate to NornOSHTTPClient for retry + auth) ───────

    def _post_json(self, path: str, body: dict) -> dict:
        return self._client.post_json(path, body)

    def _get_json(self, path: str, params: Optional[dict] = None) -> dict:
        return self._client.get_json(path, params=params)

    # ── Gym API ────────────────────────────────────────────────────────────

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ) -> tuple[np.ndarray, dict]:
        # `seed` (Gym) is not the NornOS seedId — that lives in self.seed_id.
        # Gym's `seed` controls the env-internal RNG, which we don't have.
        super().reset(seed=seed)
        body = self._post_json("/internal/research/reset", {"seedId": self.seed_id})
        entities = body["entities"]
        if self.entity_filter is not None:
            keep = set(self.entity_filter)
            entities = [e for e in entities if e["entityId"] in keep]
        # Stable entityId ordering (already ASC from server, redundant sort
        # in case the filter reorders).
        entities.sort(key=lambda e: e["entityId"])
        self.entity_ids = [e["entityId"] for e in entities]

        feat_set: set[str] = set()
        for e in entities:
            feat_set.update(e["features"].keys())
        self.feature_keys = sorted(feat_set)

        self.observation_space = build_observation_space(
            len(self.entity_ids), len(self.feature_keys)
        )
        self.action_space = build_action_space(len(self.entity_ids), self.feature_keys)

        obs = self._build_obs(entities)
        self._last_step_count = body["stepCount"]
        info = {
            "seedId": body["seedId"],
            "stepCount": body["stepCount"],
            "auditHashes": [e["auditHash"] for e in entities],
            "timestamp": body.get("timestamp"),
        }
        return obs, info

    def step(
        self, action: dict
    ) -> tuple[np.ndarray, float, bool, bool, dict]:
        if not self.entity_ids:
            raise RuntimeError("step() called before reset() — call reset() first")
        idx_raw = action.get("entityId")
        idx = int(idx_raw) if idx_raw is not None else 0
        if idx < 0 or idx >= len(self.entity_ids):
            raise ValueError(f"action.entityId index {idx} out of range")
        entity_id = self.entity_ids[idx]
        feature_arr = np.asarray(action.get("features", []), dtype=np.float32)
        features_dict = {
            self.feature_keys[i]: float(feature_arr[i])
            for i in range(min(len(self.feature_keys), feature_arr.size))
        }

        act_resp = self._post_json(
            "/internal/research/act",
            {
                "entityId": entity_id,
                "actorId": self.actor_id,
                "action": {"kind": "step", "features": features_dict},
                "seedId": self.seed_id,
            },
        )
        reward = float(act_resp.get("reward", 0.0))
        self._last_step_count = int(act_resp.get("stepCount", self._last_step_count + 1))

        # Re-fetch the full observation so MARL/multi-entity agents see the
        # consistent post-step world. Single-agent scenarios could reuse the
        # act-response features locally, but that diverges from /observe in
        # multi-agent runs.
        obs_resp = self._get_json(
            "/internal/research/observe", params={"seedId": self.seed_id}
        )
        entities = obs_resp["entities"]
        if self.entity_filter is not None:
            keep = set(self.entity_filter)
            entities = [e for e in entities if e["entityId"] in keep]
        entities.sort(key=lambda e: e["entityId"])
        obs = self._build_obs(entities)

        info = {
            "auditEventId": act_resp.get("auditEventId"),
            "auditHash": act_resp.get("auditHash"),
            "stepCount": self._last_step_count,
            "entityId": entity_id,
        }
        return obs, reward, False, False, info

    def close(self) -> None:
        # Stateless HTTP client — nothing to free.
        return None

    # ── internal ───────────────────────────────────────────────────────────

    def _build_obs(self, entities: list[dict]) -> np.ndarray:
        n_features = len(self.feature_keys)
        flat = np.zeros(len(self.entity_ids) * n_features, dtype=np.float32)
        index_by_id = {eid: i for i, eid in enumerate(self.entity_ids)}
        for ent in entities:
            row_idx = index_by_id.get(ent["entityId"])
            if row_idx is None:
                continue
            features = ent["features"] or {}
            for col_idx, key in enumerate(self.feature_keys):
                v = features.get(key)
                if v is None:
                    continue
                try:
                    flat[row_idx * n_features + col_idx] = float(v)
                except (TypeError, ValueError):
                    continue
        return flat
