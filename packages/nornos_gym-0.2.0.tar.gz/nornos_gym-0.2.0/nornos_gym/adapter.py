"""NornOSAdapter — domain-specific feature extraction + reward shaping.

Subclasses can override `extract_features` to flatten domain-specific
entity payloads into a fixed-length numpy array, and `compute_reward` to
turn skill outputs into a scalar in [0, 1] (or any other bounded range
the agent's PPO/DQN scale expects).

The default implementation:
- extract_features: take the entity's `features` dict, sort keys ASC,
  return values as float32 array.
- compute_reward: return `skill_outputs["score"]` when present, else 0.

PRD-NORNOS-CORE-001 §5.6 / §5.7. The base class itself imports nothing
from NornOS internals — it is a pure interface contract.
"""
from __future__ import annotations

from typing import Any, Optional

import numpy as np


class NornOSAdapter:
    """Base class for domain adapters."""

    def __init__(self, feature_keys: Optional[list[str]] = None) -> None:
        # If feature_keys is provided, extract_features uses this exact
        # order; otherwise the order is sorted-ASC at extraction time.
        self.feature_keys: Optional[list[str]] = (
            list(feature_keys) if feature_keys else None
        )

    def extract_features(self, raw_entity: dict) -> np.ndarray:
        features = raw_entity.get("features", {}) or {}
        keys = self.feature_keys if self.feature_keys is not None else sorted(features.keys())
        out = np.zeros(len(keys), dtype=np.float32)
        for i, k in enumerate(keys):
            v = features.get(k)
            if v is None:
                continue
            try:
                out[i] = float(v)
            except (TypeError, ValueError):
                out[i] = 0.0
        return out

    def compute_reward(self, skill_outputs: dict) -> float:
        v = skill_outputs.get("score", 0.0)
        try:
            return float(v)
        except (TypeError, ValueError):
            return 0.0
