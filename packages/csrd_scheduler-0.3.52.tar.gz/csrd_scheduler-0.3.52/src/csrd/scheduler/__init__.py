"""Minimal csrd.scheduler stub package."""

__all__: tuple[str, ...] = ()
