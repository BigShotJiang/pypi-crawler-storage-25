# csrd-scheduler

Minimal stub package reserved for future scheduler support in the `csrd` ecosystem.
