"""Tests for CLI module."""

import tempfile
from click.testing import CliRunner
from git_stats.cli import cli
from tests.conftest import create_fake_repo


def test_cli_default():
    """Test default CLI invocation."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, [])
            assert result.exit_code == 0
            assert "Commits" in result.output or "No commits" in result.output
        finally:
            os.chdir(old_cwd)


def test_cli_summary():
    """Test summary command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["summary"])
            assert result.exit_code == 0
            assert "commits" in result.output
        finally:
            os.chdir(old_cwd)


def test_cli_heatmap():
    """Test heatmap command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["heatmap"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_streaks():
    """Test streaks command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["streaks"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_hours():
    """Test hours command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["hours"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_days():
    """Test days command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["days"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_files():
    """Test files command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["files"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_langs():
    """Test langs command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["langs"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_export():
    """Test export command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os, json
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["export", "--json"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert "total_commits" in data
        finally:
            os.chdir(old_cwd)


def test_cli_report():
    """Test report command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["report"])
            assert result.exit_code == 0
            assert "Git Stats Report" in result.output
        finally:
            os.chdir(old_cwd)


def test_cli_blame():
    """Test blame command."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["blame", "hello.py"])
            assert result.exit_code == 0
        finally:
            os.chdir(old_cwd)


def test_cli_help():
    """Test --help flag."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Personal developer analytics" in result.output


def test_cli_author_filter():
    """Test --author flag."""
    runner = CliRunner()
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        import os
        old_cwd = os.getcwd()
        os.chdir(repo)
        try:
            result = runner.invoke(cli, ["--author", "Nobody", "summary"])
            assert result.exit_code == 0
            assert "0 commits" in result.output
        finally:
            os.chdir(old_cwd)
