"""Tests for reporter module."""

import tempfile
from git_stats.collector import collect_commits
from git_stats.analyzer import compute_stats
from git_stats.reporter import format_dashboard, format_summary, format_json, format_report
from tests.conftest import create_fake_repo


def test_format_dashboard():
    """Test dashboard formatting."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits, repo_name="fake_repo")
        output = format_dashboard(stats)
        assert "Commits" in output
        assert "fake_repo" in output
        assert "3" in output


def test_format_dashboard_empty():
    """Test dashboard with no commits."""
    stats = compute_stats([], repo_name="empty")
    output = format_dashboard(stats)
    assert "No commits found" in output


def test_format_summary():
    """Test one-line summary."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits, repo_name="fake_repo")
        output = format_summary(stats)
        assert "commits" in output
        assert "lines" in output


def test_format_json():
    """Test JSON export."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits, repo_name="fake_repo")
        output = format_json(stats)
        import json
        data = json.loads(output)
        assert data["total_commits"] == 3
        assert data["repo"] == "fake_repo"


def test_format_report():
    """Test markdown report."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits, repo_name="fake_repo")
        output = format_report(stats)
        assert "# Git Stats Report" in output
        assert "fake_repo" in output


def test_format_report_empty():
    """Test report with no commits."""
    stats = compute_stats([], repo_name="empty")
    output = format_report(stats)
    assert "No commits found" in output
