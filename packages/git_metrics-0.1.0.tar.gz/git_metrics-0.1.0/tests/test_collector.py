"""Tests for collector module."""

import os
import tempfile
from git_stats.collector import collect_commits, _parse_git_log, get_repo_name
from tests.conftest import create_fake_repo


def test_collect_commits_basic():
    """Test basic commit collection from a fake repo."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        assert len(commits) == 3
        assert commits[0].subject == "commit 3"  # newest first
        assert commits[0].author_name == "Test User"
        assert commits[0].author_email == "test@test.com"


def test_collect_commits_with_files():
    """Test that file changes are parsed."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        assert len(commits[0].files) > 0


def test_collect_commits_author_filter():
    """Test author filtering."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo, author="NonExistent")
        assert len(commits) == 0


def test_parse_git_log_empty():
    """Test parsing empty output."""
    assert _parse_git_log("") == []


def test_parse_git_log_single_commit():
    """Test parsing a single commit."""
    output = "abc123|2025-01-15 10:00:00 -0500|John|john@test.com|initial commit\n\n2\t0\thello.py\n"
    commits = _parse_git_log(output)
    assert len(commits) == 1
    assert commits[0].hash == "abc123"
    assert commits[0].subject == "initial commit"
    assert len(commits[0].files) == 1
    assert commits[0].files[0].path == "hello.py"
    assert commits[0].files[0].added == 2
    assert commits[0].files[0].deleted == 0


def test_parse_git_log_multiple_commits():
    """Test parsing multiple commits."""
    output = (
        "hash1|2025-01-15 10:00:00 -0500|John|j@t.com|commit 1\n\n3\t0\tfile.py\n\n"
        "hash2|2025-01-16 11:00:00 -0500|John|j@t.com|commit 2\n\n1\t2\tfile.py\n"
    )
    commits = _parse_git_log(output)
    assert len(commits) == 2


def test_parse_git_log_binary_file():
    """Test parsing with binary file markers."""
    output = "h1|2025-01-15 10:00:00|A|a@b.c|add binary\n\n-\t-\timage.png\n"
    commits = _parse_git_log(output)
    assert len(commits) == 1
    assert commits[0].files[0].added == 0
    assert commits[0].files[0].deleted == 0


def test_get_repo_name():
    """Test repo name extraction."""
    name = get_repo_name("/path/to/myproject")
    assert name == "myproject"


def test_collect_invalid_repo():
    """Test collecting from non-git directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        commits = collect_commits(tmpdir)
        assert commits == []
