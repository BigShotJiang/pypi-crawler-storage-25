"""Tests for streaks module."""

from datetime import datetime, timedelta
from git_stats.streaks import compute_streaks


def test_streaks_empty():
    """Test with no commits."""
    assert compute_streaks({}) == (0, 0)


def test_streaks_single_day():
    """Test with single day of commits."""
    today = datetime.now().strftime("%Y-%m-%d")
    current, longest = compute_streaks({today: 5})
    assert current == 1
    assert longest == 1


def test_streaks_consecutive():
    """Test consecutive day streak."""
    today = datetime.now()
    data = {}
    for i in range(5):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        data[d] = 1
    current, longest = compute_streaks(data)
    assert current == 5
    assert longest == 5


def test_streaks_broken():
    """Test broken streak."""
    today = datetime.now()
    # 3 days ago, skip yesterday, today
    d1 = (today - timedelta(days=3)).strftime("%Y-%m-%d")
    d2 = (today - timedelta(days=2)).strftime("%Y-%m-%d")
    # Skip 1 day ago
    d4 = today.strftime("%Y-%m-%d")
    data = {d1: 1, d2: 1, d4: 1}
    current, longest = compute_streaks(data)
    assert current == 1
    assert longest == 2


def test_streaks_no_today():
    """Test when there are no commits today."""
    yesterday = datetime.now() - timedelta(days=1)
    day_before = yesterday - timedelta(days=1)
    data = {
        yesterday.strftime("%Y-%m-%d"): 1,
        day_before.strftime("%Y-%m-%d"): 1,
    }
    current, longest = compute_streaks(data)
    assert current == 0
    assert longest == 2


def test_streaks_longest_in_middle():
    """Test that longest streak is found even if not current."""
    today = datetime.now()
    data = {}
    # 5-day streak ending 10 days ago
    for i in range(5):
        d = (today - timedelta(days=10+i)).strftime("%Y-%m-%d")
        data[d] = 1
    # 2-day current streak
    for i in range(2):
        d = (today - timedelta(days=i)).strftime("%Y-%m-%d")
        data[d] = 1
    current, longest = compute_streaks(data)
    assert current == 2
    assert longest == 5
