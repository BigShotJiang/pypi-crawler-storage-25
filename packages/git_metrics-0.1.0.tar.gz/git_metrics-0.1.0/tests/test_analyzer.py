"""Tests for analyzer module."""

import tempfile
from git_stats.collector import collect_commits
from git_stats.analyzer import compute_stats
from tests.conftest import create_fake_repo


def test_compute_stats_basic():
    """Test basic stat computation."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits, repo_name="fake_repo")

        assert stats.total_commits == 3
        assert stats.repo_name == "fake_repo"
        assert stats.lines_added > 0
        assert len(stats.files_changed) > 0
        assert len(stats.active_days) == 3


def test_compute_stats_dates():
    """Test date tracking."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits)

        assert stats.first_commit_date is not None
        assert stats.last_commit_date is not None
        assert stats.first_commit_date < stats.last_commit_date


def test_compute_stats_empty():
    """Test stats with no commits."""
    stats = compute_stats([])
    assert stats.total_commits == 0
    assert stats.lines_added == 0
    assert stats.lines_deleted == 0


def test_compute_stats_hour_distribution():
    """Test hourly commit distribution."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits)

        # Our test commits are at 10, 14, 9
        assert 10 in stats.commits_by_hour or 15 in stats.commits_by_hour  # depends on timezone
        assert sum(stats.commits_by_hour.values()) == 3


def test_compute_stats_weekday_distribution():
    """Test weekday commit distribution."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits)

        assert sum(stats.commits_by_weekday.values()) == 3


def test_compute_stats_file_tracking():
    """Test file change tracking."""
    with tempfile.TemporaryDirectory() as tmpdir:
        repo = create_fake_repo(tmpdir)
        commits = collect_commits(repo)
        stats = compute_stats(commits)

        assert "hello.py" in stats.files_changed
