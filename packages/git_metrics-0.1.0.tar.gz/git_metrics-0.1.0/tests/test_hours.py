"""Tests for hours module."""

from git_stats.hours import analyze_hours, format_hour_bar


def test_analyze_hours_empty():
    """Test with no data."""
    result = analyze_hours({})
    assert result["peak_hour"] is None
    assert result["peak_count"] == 0


def test_analyze_hours_basic():
    """Test basic hour analysis."""
    data = {10: 20, 11: 15, 14: 10}
    result = analyze_hours(data)
    assert result["peak_hour"] == 10
    assert result["peak_count"] == 20
    assert result["total"] == 45


def test_analyze_hours_peak_range():
    """Test peak range detection."""
    data = {10: 50, 11: 40, 12: 30, 13: 20}
    result = analyze_hours(data)
    assert "peak_range" in result
    assert "%" in result["peak_range"]


def test_format_hour_bar():
    """Test bar formatting."""
    bar = format_hour_bar(5, 10, width=10)
    assert bar == "█████░░░░░"
    bar = format_hour_bar(0, 10, width=10)
    assert bar == "░░░░░░░░░░"
    bar = format_hour_bar(10, 10, width=10)
    assert bar == "██████████"


def test_format_hour_bar_zero_max():
    """Test bar with zero max."""
    bar = format_hour_bar(0, 0, width=10)
    assert bar == "░░░░░░░░░░"


def test_analyze_hours_single_hour():
    """Test with single hour."""
    result = analyze_hours({3: 5})
    assert result["peak_hour"] == 3
    assert result["peak_count"] == 5
