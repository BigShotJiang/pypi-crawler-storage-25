"""Tests for heatmap module."""

from git_stats.heatmap import generate_heatmap


def test_heatmap_empty():
    """Test heatmap with no data."""
    assert generate_heatmap({}) == "No commits found."


def test_heatmap_basic():
    """Test basic heatmap generation."""
    data = {
        "2025-01-13": 2,
        "2025-01-14": 3,
        "2025-01-15": 5,
        "2025-01-16": 1,
    }
    output = generate_heatmap(data)
    assert "Mon" in output
    assert "Total:" in output
    assert "11" in output  # total count


def test_heatmap_single_day():
    """Test heatmap with single commit day."""
    data = {"2025-01-15": 10}
    output = generate_heatmap(data)
    assert "10" in output
    assert "Total: 10" in output


def test_heatmap_weeks_param():
    """Test heatmap with explicit weeks parameter."""
    data = {"2025-01-15": 5}
    output = generate_heatmap(data, weeks=4)
    assert "W1" in output
    assert "W4" in output


def test_heatmap_large_count():
    """Test heatmap with large commit count."""
    data = {"2025-01-15": 15}
    output = generate_heatmap(data)
    assert "15" in output


def test_heatmap_multiple_weeks():
    """Test heatmap spanning multiple weeks."""
    data = {
        "2025-01-06": 1,
        "2025-01-13": 2,
        "2025-01-20": 3,
    }
    output = generate_heatmap(data)
    assert "Total: 6" in output
