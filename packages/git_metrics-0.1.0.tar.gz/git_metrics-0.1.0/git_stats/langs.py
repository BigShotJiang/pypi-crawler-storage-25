"""Language detection and breakdown."""

from collections import defaultdict
from pathlib import Path

from .config import LANG_MAP, FILENAME_LANG_MAP


def detect_language(filepath: str) -> str:
    """Detect programming language from file path."""
    p = Path(filepath)
    name = p.name

    # Check filename map first
    if name in FILENAME_LANG_MAP:
        return FILENAME_LANG_MAP[name]

    # Check extension
    ext = p.suffix.lower()
    return LANG_MAP.get(ext, "Unknown")


def compute_language_breakdown(files_changed: set[str]) -> dict[str, int]:
    """Compute language breakdown by file count."""
    lang_count = defaultdict(int)
    for f in files_changed:
        lang = detect_language(f)
        lang_count[lang] += 1
    return dict(sorted(lang_count.items(), key=lambda x: x[1], reverse=True))
