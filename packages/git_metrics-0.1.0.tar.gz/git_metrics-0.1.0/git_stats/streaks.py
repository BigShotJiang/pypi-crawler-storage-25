"""Commit streak calculation."""

from datetime import datetime, timedelta
from typing import Optional


def compute_streaks(commits_by_date: dict[str, int]) -> tuple[int, int]:
    """Return (current_streak, longest_streak) in days."""
    if not commits_by_date:
        return 0, 0

    dates = sorted(set(commits_by_date.keys()))
    date_set = set(dates)

    # Longest streak
    longest = 1
    current = 1
    for i in range(1, len(dates)):
        prev = datetime.strptime(dates[i - 1], "%Y-%m-%d")
        curr = datetime.strptime(dates[i], "%Y-%m-%d")
        if (curr - prev).days == 1:
            current += 1
            longest = max(longest, current)
        else:
            current = 1

    # Current streak (from today backwards)
    today = datetime.now().strftime("%Y-%m-%d")
    today_dt = datetime.now()
    streak = 0
    check = today_dt
    while True:
        key = check.strftime("%Y-%m-%d")
        if key in date_set:
            streak += 1
            check -= timedelta(days=1)
        else:
            break

    return streak, max(longest, streak)
