"""Parse git log output into structured data."""

import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional


@dataclass
class FileChange:
    path: str
    added: int
    deleted: int


@dataclass
class Commit:
    hash: str
    date: datetime
    author_name: str
    author_email: str
    subject: str
    files: list[FileChange] = field(default_factory=list)


def collect_commits(
    repo_path: str = ".",
    author: Optional[str] = None,
    after: Optional[str] = None,
    before: Optional[str] = None,
) -> list[Commit]:
    """Collect commits from a git repo by parsing git log output."""
    cmd = [
        "git", "-C", repo_path,
        "log",
        "--format=%H|%ai|%an|%ae|%s",
        "--numstat",
        "--all",
    ]
    if author:
        cmd.extend(["--author", author])
    if after:
        cmd.extend(["--after", after])
    if before:
        cmd.extend(["--before", before])

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return []

    return _parse_git_log(result.stdout)


def _parse_git_log(output: str) -> list[Commit]:
    """Parse git log output into Commit objects."""
    commits = []
    lines = output.split("\n")
    i = 0

    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue

        parts = line.split("|", 4)
        if len(parts) < 5:
            i += 1
            continue

        commit_hash, date_str, author_name, author_email, subject = parts
        try:
            date = datetime.strptime(date_str.strip(), "%Y-%m-%d %H:%M:%S %z")
        except ValueError:
            try:
                date = datetime.strptime(date_str.strip(), "%Y-%m-%d %H:%M:%S")
            except ValueError:
                i += 1
                continue

        commit = Commit(
            hash=commit_hash.strip(),
            date=date,
            author_name=author_name.strip(),
            author_email=author_email.strip(),
            subject=subject.strip(),
        )

        # Parse following numstat lines (git log puts blank line before them)
        i += 1
        # Skip blank line between header and numstat
        if i < len(lines) and not lines[i].strip():
            i += 1
        while i < len(lines):
            stat_line = lines[i].strip()
            if not stat_line:
                i += 1
                break
            stat_parts = stat_line.split("\t")
            if len(stat_parts) == 3:
                added_str, deleted_str, filepath = stat_parts
                try:
                    added = int(added_str) if added_str != "-" else 0
                    deleted = int(deleted_str) if deleted_str != "-" else 0
                    commit.files.append(FileChange(filepath, added, deleted))
                except ValueError:
                    pass
            else:
                break
            i += 1

        commits.append(commit)

    return commits


def get_repo_name(repo_path: str = ".") -> str:
    """Get the repository name from the directory."""
    return Path(repo_path).resolve().name
