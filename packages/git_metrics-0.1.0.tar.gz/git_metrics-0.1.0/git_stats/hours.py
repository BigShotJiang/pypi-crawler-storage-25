"""Productive hours analysis."""

from collections import defaultdict


def analyze_hours(commits_by_hour: dict[int, int]) -> dict:
    """Analyze productive hours from commit data."""
    if not commits_by_hour:
        return {"peak_hour": None, "peak_count": 0, "distribution": {}, "peak_range": ""}

    peak_hour = max(commits_by_hour, key=commits_by_hour.get)
    peak_count = commits_by_hour[peak_hour]
    total = sum(commits_by_hour.values())

    # Find 4-hour peak window
    best_start = peak_hour
    best_sum = 0
    for start_h in range(24):
        window_sum = sum(
            commits_by_hour.get((start_h + h) % 24, 0) for h in range(4)
        )
        if window_sum > best_sum:
            best_sum = window_sum
            best_start = start_h

    end_h = (best_start + 3) % 24
    peak_pct = round(best_sum / total * 100) if total else 0

    return {
        "peak_hour": peak_hour,
        "peak_count": peak_count,
        "distribution": dict(commits_by_hour),
        "peak_range": f"{best_start % 12 or 12}{'am' if best_start < 12 else 'pm'} - {end_h % 12 or 12}{'am' if end_h < 12 else 'pm'} ({peak_pct}% of commits)",
        "total": total,
    }


def format_hour_bar(count: int, max_count: int, width: int = 30) -> str:
    """Generate a bar for the hours chart."""
    if max_count == 0:
        return "░" * width
    filled = round(count / max_count * width)
    return "█" * filled + "░" * (width - filled)
