"""Configuration for git-stats."""

import os
from pathlib import Path


def get_config_path() -> Path:
    """Return path to .gitstats config file."""
    return Path(os.getcwd()) / ".gitstats"


def load_config() -> dict:
    """Load config from .gitstats file if present."""
    config_path = get_config_path()
    config = {}
    if config_path.exists():
        for line in config_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                config[key.strip()] = value.strip()
    return config


# Language mapping by file extension
LANG_MAP = {
    ".py": "Python",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".tsx": "TypeScript",
    ".jsx": "JavaScript",
    ".java": "Java",
    ".kt": "Kotlin",
    ".go": "Go",
    ".rs": "Rust",
    ".rb": "Ruby",
    ".php": "PHP",
    ".c": "C",
    ".cpp": "C++",
    ".h": "C/C++ Header",
    ".hpp": "C++ Header",
    ".cs": "C#",
    ".swift": "Swift",
    ".m": "Objective-C",
    ".scala": "Scala",
    ".r": "R",
    ".R": "R",
    ".sql": "SQL",
    ".sh": "Shell",
    ".bash": "Shell",
    ".zsh": "Shell",
    ".fish": "Shell",
    ".ps1": "PowerShell",
    ".html": "HTML",
    ".css": "CSS",
    ".scss": "SCSS",
    ".less": "Less",
    ".vue": "Vue",
    ".svelte": "Svelte",
    ".json": "JSON",
    ".yaml": "YAML",
    ".yml": "YAML",
    ".toml": "TOML",
    ".xml": "XML",
    ".md": "Markdown",
    ".rst": "reStructuredText",
    ".txt": "Text",
    ".dockerfile": "Dockerfile",
    ".lua": "Lua",
    ".perl": "Perl",
    ".pl": "Perl",
    ".ex": "Elixir",
    ".exs": "Elixir",
    ".erl": "Erlang",
    ".hs": "Haskell",
    ".ml": "OCaml",
    ".dart": "Dart",
    ".zig": "Zig",
    ".nim": "Nim",
    ".vim": "Vim Script",
    ".el": "Emacs Lisp",
    ".clj": "Clojure",
    ".coffee": "CoffeeScript",
    ".tf": "Terraform",
    ".proto": "Protocol Buffers",
    ".graphql": "GraphQL",
    ".sol": "Solidity",
    ".wasm": "WebAssembly",
}

# Files with no extension that indicate a language
FILENAME_LANG_MAP = {
    "Makefile": "Makefile",
    "Dockerfile": "Dockerfile",
    "Jenkinsfile": "Groovy",
    "Vagrantfile": "Ruby",
    "Gemfile": "Ruby",
    "Rakefile": "Ruby",
    "CMakeLists.txt": "CMake",
    "requirements.txt": "Requirements",
    "setup.py": "Python",
    "Cargo.toml": "TOML",
    "go.mod": "Go Module",
    "package.json": "JSON",
}
