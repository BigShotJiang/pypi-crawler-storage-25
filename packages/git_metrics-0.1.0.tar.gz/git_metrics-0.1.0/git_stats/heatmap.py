"""Generate contribution heatmap."""

from collections import defaultdict
from datetime import datetime, timedelta
from typing import Optional


def generate_heatmap(
    commits_by_date: dict[str, int],
    weeks: int = 0,
) -> str:
    """Generate a text-based contribution heatmap."""
    if not commits_by_date:
        return "No commits found."

    dates = sorted(commits_by_date.keys())
    first = datetime.strptime(dates[0], "%Y-%m-%d")
    last = datetime.strptime(dates[-1], "%Y-%m-%d")

    if weeks == 0:
        weeks = ((last - first).days // 7) + 1

    # Start from the Monday of the week containing the first commit
    start = first - timedelta(days=first.weekday())

    day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    lines = []
    header = "     " + "  ".join(day_names)
    lines.append(header)

    total = 0
    for w in range(weeks):
        parts = [f"W{w+1:<2}"]
        for d in range(7):
            day = start + timedelta(weeks=w, days=d)
            key = day.strftime("%Y-%m-%d")
            count = commits_by_date.get(key, 0)
            total += count if key not in commits_by_date else count
            # Avoid double counting
            if d == 0:
                total_check = 0
            if count == 0:
                parts.append(" ·")
            elif count < 10:
                parts.append(f" {count}")
            else:
                parts.append(f"{count}")
        lines.append("  ".join(parts))

    # Recalculate total properly
    total = sum(commits_by_date.values())

    lines.append("")
    lines.append(f"   · = no commits  number = commit count")
    lines.append(f"   Total: {total} commits over {weeks} weeks")

    return "\n".join(lines)
