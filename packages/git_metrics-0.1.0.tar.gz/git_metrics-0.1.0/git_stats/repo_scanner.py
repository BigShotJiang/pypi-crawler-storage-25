"""Find git repos in directories."""

import os
from pathlib import Path


def find_repos(directory: str = ".", max_depth: int = 3) -> list[str]:
    """Find all git repos under a directory."""
    repos = []
    base = Path(directory).resolve()

    for root, dirs, files in os.walk(str(base)):
        depth = Path(root).relative_to(base).parts
        if len(depth) > max_depth:
            dirs.clear()
            continue

        if ".git" in dirs:
            repos.append(root)
            dirs.remove(".git")  # Don't descend into .git
            # Also don't descend further - submodules handled separately

    return repos
