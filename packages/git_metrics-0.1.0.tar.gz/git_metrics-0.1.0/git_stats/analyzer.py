"""Compute stats from parsed commits."""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional, Dict, Set, List
from collections import defaultdict

from .collector import Commit


@dataclass
class Stats:
    total_commits: int = 0
    lines_added: int = 0
    lines_deleted: int = 0
    files_changed: set = field(default_factory=set)
    active_days: set = field(default_factory=set)
    commits_by_date: dict = field(default_factory=lambda: defaultdict(int))
    commits_by_hour: dict = field(default_factory=lambda: defaultdict(int))
    commits_by_weekday: dict = field(default_factory=lambda: defaultdict(int))
    commits_by_file: dict = field(default_factory=lambda: defaultdict(int))
    lines_by_lang: dict = field(default_factory=lambda: defaultdict(int))
    first_commit_date: Optional[datetime] = None
    last_commit_date: Optional[datetime] = None
    repo_name: str = ""


def compute_stats(commits: List[Commit], repo_name: str = "") -> Stats:
    """Compute comprehensive stats from a list of commits."""
    stats = Stats(repo_name=repo_name)

    for commit in commits:
        stats.total_commits += 1

        if stats.first_commit_date is None or commit.date < stats.first_commit_date:
            stats.first_commit_date = commit.date
        if stats.last_commit_date is None or commit.date > stats.last_commit_date:
            stats.last_commit_date = commit.date

        day_key = commit.date.strftime("%Y-%m-%d")
        stats.active_days.add(day_key)
        stats.commits_by_date[day_key] += 1

        stats.commits_by_hour[commit.date.hour] += 1
        stats.commits_by_weekday[commit.date.strftime("%A")] += 1

        for fc in commit.files:
            stats.lines_added += fc.added
            stats.lines_deleted += fc.deleted
            stats.files_changed.add(fc.path)
            stats.commits_by_file[fc.path] += 1

    return stats
