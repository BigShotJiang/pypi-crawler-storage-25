"""File change frequency analysis."""

from collections import defaultdict
from typing import Optional


def analyze_files(commits_by_file: dict[str, int], top_n: int = 10) -> list[tuple[str, int]]:
    """Return top N most changed files with commit counts."""
    sorted_files = sorted(commits_by_file.items(), key=lambda x: x[1], reverse=True)
    return sorted_files[:top_n]
