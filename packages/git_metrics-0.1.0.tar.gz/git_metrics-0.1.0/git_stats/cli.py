"""Click CLI for git-stats."""

import json
import sys
from datetime import datetime, timedelta

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .collector import collect_commits, get_repo_name
from .analyzer import compute_stats
from .heatmap import generate_heatmap
from .streaks import compute_streaks
from .hours import analyze_hours, format_hour_bar
from .files import analyze_files
from .langs import detect_language, compute_language_breakdown
from .blame_analyzer import blame_file
from .reporter import format_dashboard, format_summary, format_json, format_report
from .repo_scanner import find_repos

console = Console()


def _get_period(after: bool, before: bool, week: bool, month: bool):
    """Compute --after and --before date strings."""
    after_date = None
    before_date = None
    if week:
        after_date = (datetime.now() - timedelta(weeks=1)).strftime("%Y-%m-%d")
    elif month:
        after_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    return after_date, before_date


@click.group(invoke_without_command=True)
@click.option("--week", is_flag=True, help="Show stats for the last week")
@click.option("--month", is_flag=True, help="Show stats for the last 30 days")
@click.option("--author", default=None, help="Filter by author name/email")
@click.option("--all", "scan_all", is_flag=True, help="Scan all git repos in parent directory")
@click.pass_context
def cli(ctx, week, month, author, scan_all):
    """Personal developer analytics from your git repos."""
    ctx.ensure_object(dict)
    ctx.obj["author"] = author
    ctx.obj["week"] = week
    ctx.obj["month"] = month
    ctx.obj["scan_all"] = scan_all

    if ctx.invoked_subcommand is not None:
        return

    after_date, before_date = _get_period(week, month, week, month)

    if scan_all:
        repos = find_repos("..")
    else:
        repos = ["."]

    for repo in repos:
        commits = collect_commits(repo, author=author, after=after_date, before=before_date)
        name = get_repo_name(repo)
        stats = compute_stats(commits, repo_name=name)
        console.print(format_dashboard(stats))
        console.print()


@cli.command()
@click.option("--weeks", default=0, type=int, help="Number of weeks to show (0=auto)")
@click.pass_context
def heatmap(ctx, weeks):
    """Contribution heatmap (like GitHub)."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits)
    output = generate_heatmap(stats.commits_by_date, weeks=weeks)
    console.print(output)


@cli.command()
@click.pass_context
def streaks(ctx):
    """Current and longest commit streaks."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits)
    current, longest = compute_streaks(stats.commits_by_date)
    console.print(f"  Current streak: [bold green]{current}[/bold green] days")
    console.print(f"  Longest streak: [bold yellow]{longest}[/bold yellow] days")


@cli.command()
@click.pass_context
def hours(ctx):
    """Most productive hours of day."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits)
    data = analyze_hours(stats.commits_by_hour)

    if not data["distribution"]:
        console.print("No commits found.")
        return

    max_count = max(data["distribution"].values())
    lines = []
    for h in range(24):
        count = data["distribution"].get(h, 0)
        bar = format_hour_bar(count, max_count)
        label = f"{h % 12 or 12}{'am' if h < 12 else 'pm'}"
        marker = " ← peak" if h == data["peak_hour"] else ""
        lines.append(f"  {label:>4}  {bar}{marker}")

    lines.append("")
    lines.append(f"  Peak hours: {data['peak_range']}")

    panel = Panel("\n".join(lines), title="Productive Hours (24h)", border_style="blue")
    console.print(panel)


@cli.command()
@click.pass_context
def days(ctx):
    """Most productive days of week."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits)

    if not stats.commits_by_weekday:
        console.print("No commits found.")
        return

    day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    max_count = max(stats.commits_by_weekday.values()) if stats.commits_by_weekday else 1

    table = Table(title="Commits by Day of Week")
    table.add_column("Day", style="bold")
    table.add_column("Commits", justify="right")
    table.add_column("Bar")

    for day in day_order:
        count = stats.commits_by_weekday.get(day, 0)
        bar = "█" * round(count / max_count * 30) if max_count else ""
        table.add_row(day, str(count), bar)

    console.print(table)


@cli.command()
@click.option("--top", default=10, type=int, help="Number of top files to show")
@click.pass_context
def files(ctx, top):
    """Most changed files."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits)
    top_files = analyze_files(stats.commits_by_file, top_n=top)

    if not top_files:
        console.print("No files found.")
        return

    table = Table(title="Most Changed Files")
    table.add_column("#", style="dim", justify="right")
    table.add_column("File", style="bold")
    table.add_column("Commits", justify="right")

    for i, (path, count) in enumerate(top_files, 1):
        table.add_row(str(i), path, str(count))

    console.print(table)


@cli.command()
@click.pass_context
def langs(ctx):
    """Language breakdown by files."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits)
    breakdown = compute_language_breakdown(stats.files_changed)

    if not breakdown:
        console.print("No files found.")
        return

    total = sum(breakdown.values())
    table = Table(title="Language Breakdown")
    table.add_column("Language", style="bold")
    table.add_column("Files", justify="right")
    table.add_column("%", justify="right")

    for lang, count in breakdown.items():
        pct = round(count / total * 100) if total else 0
        table.add_row(lang, str(count), f"{pct}%")

    console.print(table)


@cli.command()
@click.argument("filepath")
def blame(filepath):
    """Who owns each line of a file."""
    result = blame_file(filepath)
    if not result:
        console.print(f"Could not blame [bold]{filepath}[/bold]")
        return

    total = sum(result.values())
    table = Table(title=f"Ownership: {filepath}")
    table.add_column("Author", style="bold")
    table.add_column("Lines", justify="right")
    table.add_column("%", justify="right")

    for author, count in result.items():
        pct = round(count / total * 100) if total else 0
        table.add_row(author, str(count), f"{pct}%")

    console.print(table)


@cli.command()
@click.pass_context
def summary(ctx):
    """One-line summary (good for shell prompts)."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits, repo_name=get_repo_name())
    console.print(format_summary(stats))


@cli.command(name="export")
@click.option("--json", "as_json", is_flag=True, help="Export as JSON")
@click.pass_context
def export_cmd(ctx, as_json):
    """Export all stats as JSON."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits, repo_name=get_repo_name())
    console.print(format_json(stats))


@cli.command()
@click.pass_context
def report(ctx):
    """Full markdown report."""
    author = ctx.obj.get("author")
    commits = collect_commits(".", author=author)
    stats = compute_stats(commits, repo_name=get_repo_name())
    console.print(format_report(stats))


if __name__ == "__main__":
    cli()
