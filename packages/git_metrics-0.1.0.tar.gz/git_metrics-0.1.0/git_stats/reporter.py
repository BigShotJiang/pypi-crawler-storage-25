"""Format output as table, JSON, or markdown."""

import json
from datetime import datetime
from typing import Optional

from .analyzer import Stats
from .langs import compute_language_breakdown
from .files import analyze_files
from .streaks import compute_streaks


def format_dashboard(stats: Stats) -> str:
    """Format stats as a rich dashboard string."""
    from .hours import analyze_hours

    if stats.total_commits == 0:
        return "No commits found."

    total_days = 1
    if stats.first_commit_date and stats.last_commit_date:
        total_days = (stats.last_commit_date - stats.first_commit_date).days + 1

    avg_per_day = round(stats.total_commits / total_days, 1) if total_days > 0 else 0
    active_count = len(stats.active_days)
    active_pct = round(active_count / total_days * 100) if total_days > 0 else 0
    net = stats.lines_added - stats.lines_deleted
    net_str = f"+{net}" if net >= 0 else str(net)

    current_streak, longest_streak = compute_streaks(stats.commits_by_date)

    hours_data = analyze_hours(stats.commits_by_hour)
    peak_range = hours_data.get("peak_range", "N/A")

    # Busiest day
    if stats.commits_by_weekday:
        busiest_day = max(stats.commits_by_weekday, key=stats.commits_by_weekday.get)
        busiest_count = stats.commits_by_weekday[busiest_day]
        busiest_str = f"{busiest_day} ({busiest_count} commits)"
    else:
        busiest_str = "N/A"

    top_files = analyze_files(stats.commits_by_file, top_n=3)
    lang_breakdown = compute_language_breakdown(stats.files_changed)

    lines = []
    lines.append(f"╭── Git Stats — {stats.repo_name} {'─' * max(1, 40 - len(stats.repo_name))}╮")
    lines.append("│")
    lines.append(f"│  Commits:        {stats.total_commits} (avg {avg_per_day}/day)")
    lines.append(f"│  Lines added:    {stats.lines_added:,}")
    lines.append(f"│  Lines deleted:  {stats.lines_deleted:,}")
    lines.append(f"│  Net lines:      {net_str}")
    lines.append(f"│  Files changed:  {len(stats.files_changed)}")
    lines.append(f"│  Active days:    {active_count}/{total_days} ({active_pct}%)")
    lines.append("│")
    lines.append(f"│  Current streak: {current_streak} days")
    lines.append(f"│  Longest streak: {longest_streak} days")
    lines.append("│")
    lines.append(f"│  Most productive: {peak_range}")
    lines.append(f"│  Busiest day: {busiest_str}")
    lines.append("│")

    if top_files:
        lines.append("│  Top files changed:")
        for i, (path, count) in enumerate(top_files, 1):
            lines.append(f"│  {i}. {path} ({count} commits)")

    if lang_breakdown:
        lines.append("│")
        lines.append("│  Languages:")
        total_lang = sum(lang_breakdown.values())
        for lang, count in list(lang_breakdown.items())[:5]:
            pct = round(count / total_lang * 100) if total_lang else 0
            lines.append(f"│  {lang:20s} {pct}% ({count} files)")

    lines.append("│")
    lines.append("╰" + "─" * 59 + "╯")

    return "\n".join(lines)


def format_summary(stats: Stats) -> str:
    """One-line summary for shell prompts."""
    net = stats.lines_added - stats.lines_deleted
    net_str = f"+{net}" if net >= 0 else str(net)
    current_streak, _ = compute_streaks(stats.commits_by_date)
    return f"{stats.total_commits} commits | {net_str} lines | {current_streak}d streak"


def format_json(stats: Stats) -> str:
    """Export stats as JSON."""
    current_streak, longest_streak = compute_streaks(stats.commits_by_date)
    lang_breakdown = compute_language_breakdown(stats.files_changed)
    top_files = analyze_files(stats.commits_by_file, top_n=20)

    data = {
        "repo": stats.repo_name,
        "total_commits": stats.total_commits,
        "lines_added": stats.lines_added,
        "lines_deleted": stats.lines_deleted,
        "net_lines": stats.lines_added - stats.lines_deleted,
        "files_changed": len(stats.files_changed),
        "active_days": len(stats.active_days),
        "current_streak": current_streak,
        "longest_streak": longest_streak,
        "commits_by_date": dict(stats.commits_by_date),
        "commits_by_hour": {str(k): v for k, v in stats.commits_by_hour.items()},
        "commits_by_weekday": dict(stats.commits_by_weekday),
        "top_files": [{"path": p, "commits": c} for p, c in top_files],
        "languages": lang_breakdown,
        "first_commit": stats.first_commit_date.isoformat() if stats.first_commit_date else None,
        "last_commit": stats.last_commit_date.isoformat() if stats.last_commit_date else None,
    }
    return json.dumps(data, indent=2)


def format_report(stats: Stats) -> str:
    """Full markdown report."""
    from .hours import analyze_hours

    if stats.total_commits == 0:
        return "No commits found."

    current_streak, longest_streak = compute_streaks(stats.commits_by_date)
    hours_data = analyze_hours(stats.commits_by_hour)
    top_files = analyze_files(stats.commits_by_file, top_n=10)
    lang_breakdown = compute_language_breakdown(stats.files_changed)

    total_days = 1
    if stats.first_commit_date and stats.last_commit_date:
        total_days = (stats.last_commit_date - stats.first_commit_date).days + 1

    lines = [
        f"# Git Stats Report — {stats.repo_name}",
        "",
        "## Overview",
        f"- **Commits:** {stats.total_commits}",
        f"- **Lines added:** {stats.lines_added:,}",
        f"- **Lines deleted:** {stats.lines_deleted:,}",
        f"- **Net lines:** {stats.lines_added - stats.lines_deleted:,}",
        f"- **Files changed:** {len(stats.files_changed)}",
        f"- **Active days:** {len(stats.active_days)}/{total_days}",
        "",
        "## Streaks",
        f"- Current streak: **{current_streak} days**",
        f"- Longest streak: **{longest_streak} days**",
        "",
        "## Productivity",
        f"- Peak hours: {hours_data.get('peak_range', 'N/A')}",
        "",
        "### Commits by Hour",
    ]

    for h in range(24):
        count = stats.commits_by_hour.get(h, 0)
        bar = "█" * count
        label = f"{h:02d}:00"
        lines.append(f"| {label} | {bar} {count} |")

    lines.append("")
    lines.append("### Commits by Day of Week")
    for day in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]:
        count = stats.commits_by_weekday.get(day, 0)
        lines.append(f"| {day} | {'█' * count} {count} |")

    lines.append("")
    lines.append("## Top Files")
    for path, count in top_files:
        lines.append(f"- `{path}` ({count} commits)")

    if lang_breakdown:
        lines.append("")
        lines.append("## Languages")
        total_lang = sum(lang_breakdown.values())
        for lang, count in lang_breakdown.items():
            pct = round(count / total_lang * 100) if total_lang else 0
            lines.append(f"- {lang}: {pct}% ({count} files)")

    return "\n".join(lines)
