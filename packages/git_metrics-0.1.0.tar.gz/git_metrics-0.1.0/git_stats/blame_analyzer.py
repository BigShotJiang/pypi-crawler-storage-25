"""Per-file ownership analysis via git blame."""

import subprocess
from collections import defaultdict
from typing import Optional


def blame_file(filepath: str, repo_path: str = ".") -> dict[str, int]:
    """Run git blame and return line counts per author."""
    cmd = ["git", "-C", repo_path, "blame", "--porcelain", filepath]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return {}

    authors = defaultdict(int)
    for line in result.stdout.split("\n"):
        if line.startswith("author "):
            author = line[7:]
            authors[author] += 1

    return dict(sorted(authors.items(), key=lambda x: x[1], reverse=True))
