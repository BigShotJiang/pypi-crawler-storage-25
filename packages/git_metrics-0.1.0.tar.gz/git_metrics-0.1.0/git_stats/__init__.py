"""git-stats: Personal developer analytics from your git repos."""

__version__ = "0.1.0"
