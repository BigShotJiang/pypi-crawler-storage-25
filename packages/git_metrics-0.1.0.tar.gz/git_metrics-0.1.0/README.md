# git-stats

Personal developer analytics from your git repos. Lines of code, commit patterns, most productive hours, streak tracking. Like GitHub's contribution graph but way deeper and for all your repos.

## Install

```bash
pip install git-stats
```

Or from source:

```bash
git clone https://github.com/hiren-thakore/git-stats-cli.git
cd git-stats-cli
pip install -e .
```

## Usage

```bash
# Summary dashboard for current repo
git-stats

# Time filters
git-stats --week          # Last 7 days
git-stats --month         # Last 30 days

# Author filter
git-stats --author "John Doe"

# All repos in parent directory
git-stats --all

# Subcommands
git-stats heatmap         # Contribution heatmap
git-stats streaks         # Current and longest streaks
git-stats hours           # Most productive hours
git-stats days            # Most productive days of week
git-stats files           # Most changed files
git-stats langs           # Language breakdown
git-stats blame <file>    # Who owns each line
git-stats summary         # One-line summary (for shell prompts)
git-stats export --json   # Export stats as JSON
git-stats report          # Full markdown report
```

## Examples

### Dashboard

```
$ git-stats

╭── Git Stats — myapp ──────────────────────────────────────╮
│                                                             │
│  Commits:        47 (avg 1.6/day)                           │
│  Lines added:    3,247                                       │
│  Lines deleted:  1,891                                       │
│  Net lines:      +1,356                                      │
│  Files changed:  83                                          │
│  Active days:    22/30 (73%)                                 │
│                                                             │
│  Current streak: 5 days                                     │
│  Longest streak: 12 days                                    │
│                                                             │
│  Most productive: 10am - 1pm (62% of commits)               │
│  Busiest day: Wednesday (9 commits)                         │
│                                                             │
│  Top files changed:                                         │
│  1. src/api.py (23 commits)                                 │
│  2. src/models.py (18 commits)                              │
│  3. tests/test_api.py (14 commits)                         │
│                                                             │
│  Languages:                                                  │
│  Python              68% (57 files)                         │
│  YAML                18% (15 files)                         │
│  Shell               14% (11 files)                         │
│                                                             │
╰─────────────────────────────────────────────────────────────╯
```

### Heatmap

```
$ git-stats heatmap

     Mon  Tue  Wed  Thu  Fri  Sat  Sun
W1    ·    ·    ·    ·    ·    ·    ·
W2    ·    ·    3    2    5    1    ·
W3    4    2    7    1    3    ·    ·
W4    2    5    4    6    2    1    ·
W5    3    4    8    3    2    ·    ·

   · = no commits  number = commit count
   Total: 71 commits over 5 weeks
```

### Shell Prompt

```bash
# In your .bashrc / .zshrc
export PS1='$(git-stats summary) $ '
# Output: 47 commits | +1356 lines | 5d streak $
```

## Development

```bash
pip install -e ".[dev]"
pytest tests/ -q
```

## License

MIT
