"""
OSCAL Agent module.

Provides a factory function to create a production-ready Strands agent
configured with OSCAL-specific tools, retry strategy, and observability.
"""

import argparse
import logging
import uuid
import warnings
from collections.abc import Callable
from pathlib import Path
from typing import Any

# Suppress cosmetic RequestsDependencyWarning from requests library
# (urllib3/charset_normalizer version check is overly strict)
warnings.filterwarnings("ignore", message=".*urllib3.*charset.*")

import boto3
from strands import Agent, ModelRetryStrategy
from strands.hooks import (
    AfterInvocationEvent,
    AfterModelCallEvent,
    BeforeToolCallEvent,
    HookProvider,
    HookRegistry,
)
from strands.models import BedrockModel

from mcp_server_for_oscal.config import config
from mcp_server_for_oscal.tools import get_tool_list
from mcp_server_for_oscal.tools.utils import verify_package_integrity

logger = logging.getLogger(__name__)

def _build_system_prompt(tools: list[Any]) -> str:
    """Build the system prompt with dynamically injected tool names.

    Args:
        tools: List of tool functions whose names will be included in the prompt.

    Returns:
        The complete system prompt string.
    """
    tool_names = [getattr(t, "__name__", str(t)) for t in tools]
    tool_list_str = ", ".join(sorted(tool_names))

    return (
        "You're an expert in modeling and interpreting GRC (governance, risk, and "
        "compliance) data in machine-readable format: OSCAL (Open Security Controls "
        "Assessment Language). Interoperability is the biggest constraint to GRC "
        "automation. GRC automation is the only way to make regulatory compliance "
        "sustainable for stakeholders. The interoperability problem stems from the "
        "fact that input artifacts (e.g., control frameworks, policies) are owned by "
        "external stakeholders (e.g., regulators, customers, auditors) and maintained "
        "in digital-paper formats (e.g., PDF) meant for humans, not machines. To "
        "solve the interoperability problem, we will make OSCAL the common language "
        "of GRC. Your job is to help people make good use of OSCAL without having to "
        "become experts in OSCAL. You may have OSCAL-based sources of information "
        "about systems and services from AWS and other vendors.\n"
        "\n"
        "You help users understand OSCAL concepts, models, and implementation "
        "approaches. You are knowledgeable about:\n"
        "- OSCAL architecture and layers (Control, Implementation, Assessment)\n"
        "- All OSCAL model types and their relationships\n"
        "- OSCAL implementation best practices\n"
        "- Integration with compliance frameworks like NIST SP 800-53, FedRAMP, etc.\n"
        "\n"
        "## Available Tools\n"
        "\n"
        f"You have access to ONLY the following tools: {tool_list_str}\n"
        "Do NOT attempt to call any tool not in this list.\n"
        "\n"
        "## Behavioral Guidelines\n"
        "\n"
        "1. **Be efficient with tool calls.** For conceptual or explanatory questions, "
        "use your built-in knowledge first. Only call tools when you need specific "
        "data the user asked for (e.g., a schema, a component definition, validation "
        "results). Do NOT fetch full schemas just to explain what a model is.\n"
        "2. **Use list_oscal_models for model overviews.** When a user asks about an "
        "OSCAL model type, call list_oscal_models for a summary. Only call "
        "get_oscal_schema if the user explicitly asks for the schema itself.\n"
        "3. **Stay in scope.** You are an OSCAL, GRC, and compliance assistant. If a "
        "request is unrelated to OSCAL, GRC, or compliance, politely decline and "
        "explain that you are specialized in OSCAL and GRC topics.\n"
        "4. **Be honest about uncertainty.** If you don't have enough information to "
        "answer a question accurately, say so. Do not guess or fabricate information. "
        "State what you do know and suggest how the user might find the answer.\n"
        "5. **Provide practical, actionable guidance.** Explain concepts clearly for "
        "both beginners and experts. Reference official sources and examples.\n"
    )


def _truncate_args(args: Any, max_len: int = 200) -> str:
    """Return a truncated repr of tool arguments."""
    text = repr(args)
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _build_session_manager(
    args: argparse.Namespace, cfg: Any
) -> tuple[Any | None, str | None]:
    """Build a session manager from CLI args and config defaults.

    CLI arguments take precedence over config (environment variable) defaults.

    Args:
        args: Parsed CLI argument namespace.
        cfg: Config instance with session-related attributes.

    Returns:
        A tuple of (session_manager, session_id). Both are None when
        session storage is not configured (stateless mode).

    Raises:
        SystemExit: With code 1 when ``s3`` storage is selected but
            ``--session-s3-bucket`` is not provided.
    """
    from strands.session import FileSessionManager, S3SessionManager

    storage = args.session_storage or cfg.session_storage
    if not storage:
        return None, None

    session_id = args.session_id or str(uuid.uuid4())

    if storage == "file":
        session_dir = args.session_dir or cfg.session_dir
        return FileSessionManager(
            session_id=session_id,
            storage_dir=session_dir,
        ), session_id
    elif storage == "s3":
        bucket = args.session_s3_bucket or cfg.session_s3_bucket
        if not bucket:
            logger.error(
                "--session-s3-bucket is required when --session-storage=s3"
            )
            raise SystemExit(1)
        prefix = args.session_s3_prefix or cfg.session_s3_prefix
        return S3SessionManager(
            session_id=session_id,
            bucket=bucket,
            prefix=prefix,
        ), session_id

    return None, None


def _build_conversation_manager(
    args: argparse.Namespace, cfg: Any
) -> Any | None:
    """Build a conversation manager from CLI args and config defaults.

    CLI arguments take precedence over config (environment variable) defaults.

    Args:
        args: Parsed CLI argument namespace.
        cfg: Config instance with session-related attributes.

    Returns:
        A conversation manager instance, or None when no conversation
        manager type is configured (SDK default behavior).
    """
    cm_type = args.conversation_manager or cfg.conversation_manager_type
    if not cm_type:
        return None

    from strands.agent.conversation_manager import (
        NullConversationManager,
        SlidingWindowConversationManager,
        SummarizingConversationManager,
    )

    if cm_type == "sliding-window":
        return SlidingWindowConversationManager()
    elif cm_type == "summarizing":
        return SummarizingConversationManager()
    elif cm_type == "null":
        return NullConversationManager()

    return None


class AgentObservabilityHook(HookProvider):
    """HookProvider that logs agent lifecycle events.

    Handles:
        - BeforeToolCallEvent: logs tool name + truncated args at DEBUG
        - AfterModelCallEvent: logs stop reason + token usage at DEBUG
        - AfterInvocationEvent: logs completion at DEBUG
    Also logs retry/throttle events at WARNING.
    """

    def __init__(self) -> None:
        self._logger = logging.getLogger(__name__)

    def register_hooks(self, registry: HookRegistry, **kwargs: Any) -> None:
        """Register callbacks for agent lifecycle events."""
        registry.add_callback(BeforeToolCallEvent, self._on_before_tool_call)
        registry.add_callback(AfterModelCallEvent, self._on_after_model_call)
        registry.add_callback(AfterInvocationEvent, self._on_after_invocation)

    def _on_before_tool_call(self, event: BeforeToolCallEvent) -> None:
        """Log tool name and truncated arguments at DEBUG level."""
        tool_name = event.tool_use.get("name", "<unknown>")
        tool_input = event.tool_use.get("input", {})
        self._logger.debug(
            "Tool call: %s args=%s",
            tool_name,
            _truncate_args(tool_input),
        )

    def _on_after_model_call(self, event: AfterModelCallEvent) -> None:
        """Log stop reason and token usage at DEBUG level."""
        if event.stop_response is not None:
            self._logger.debug(
                "Model call complete: stop_reason=%s",
                event.stop_response.stop_reason,
            )
        elif event.exception is not None:
            self._logger.debug(
                "Model call failed: %s",
                event.exception,
            )

    def _on_after_invocation(self, event: AfterInvocationEvent) -> None:
        """Log invocation completion at DEBUG level."""
        if event.result is not None:
            self._logger.debug(
                "Invocation complete: stop_reason=%s",
                event.result.stop_reason,
            )
        else:
            self._logger.debug("Invocation complete")


def create_oscal_agent(
    tools: list[Any] | None = None,
    callback_handler: Any = "default",
    session_manager: Any | None = None,
    conversation_manager: Any | None = None,
) -> Agent:
    """Create a production-ready OSCAL Strands agent.

    Args:
        tools: Optional list of tool functions. Defaults to get_tool_list().
        callback_handler: Callback handler for streaming output. Pass None
            to suppress all streaming output. Defaults to the SDK default.
        session_manager: Optional pre-built session manager instance
            (e.g. FileSessionManager, S3SessionManager). When None, the
            Agent is created without a session manager (stateless).
        conversation_manager: Optional pre-built conversation manager
            instance (e.g. SlidingWindowConversationManager). When None,
            the Agent uses the SDK default behavior.

    Returns:
        Configured Agent instance.

    Raises:
        ValueError: If boto3 session or BedrockModel creation fails.
    """
    if tools is None:
        tools = get_tool_list()

    # Create boto3 session
    try:
        session = boto3.Session(
            profile_name=config.aws_profile,
            region_name=config.aws_region,
        )
    except Exception as e:
        msg = f"Failed to create boto3 session with profile '{config.aws_profile}': {e}"
        logger.exception(msg)
        raise ValueError(msg) from e

    # Create BedrockModel
    try:
        model = BedrockModel(
            model_id=config.bedrock_model_id,
            boto_session=session,
            max_tokens=config.agent_max_tokens,
        )
    except Exception as e:
        msg = (
            f"Failed to create BedrockModel with model_id "
            f"'{config.bedrock_model_id}': {e}"
        )
        logger.exception(msg)
        raise ValueError(msg) from e

    # Configure retry strategy
    retry_strategy = ModelRetryStrategy(
        max_attempts=config.agent_max_retry_attempts,
        initial_delay=config.agent_retry_initial_delay,
        max_delay=config.agent_retry_max_delay,
    )

    # Build system prompt with dynamic tool names
    system_prompt = _build_system_prompt(tools)

    # Create the agent
    agent_kwargs: dict[str, Any] = {
        "model": model,
        "tools": list(tools),
        "system_prompt": system_prompt,
        "retry_strategy": retry_strategy,
        "hooks": [AgentObservabilityHook()],
    }
    if callback_handler != "default":
        agent_kwargs["callback_handler"] = callback_handler
    if session_manager is not None:
        agent_kwargs["session_manager"] = session_manager
    if conversation_manager is not None:
        agent_kwargs["conversation_manager"] = conversation_manager

    agent = Agent(**agent_kwargs)

    logger.info(
        "OSCAL agent created: model_id=%s, region=%s, tools=%d, retry_enabled=True",
        config.bedrock_model_id,
        config.aws_region,
        len(tools),
    )

    return agent


def main() -> None:
    """Standalone agent entry point.

    Parses CLI args, configures logging, verifies integrity,
    creates agent, runs interactive loop.
    """
    parser = argparse.ArgumentParser(description="OSCAL Agent")
    parser.add_argument(
        "--aws-profile",
        type=str,
        default=config.aws_profile,
        help="AWS profile name to use for authentication",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default=config.log_level,
        help="Log level for the application (defaults to INFO)",
    )
    parser.add_argument(
        "--bedrock-model-id",
        type=str,
        help="Bedrock model ID to use (overrides BEDROCK_MODEL_ID env var)",
    )
    parser.add_argument(
        "--knowledge-base-id",
        type=str,
        help="Knowledge base ID to use (overrides OSCAL_KB_ID env var)",
    )
    parser.add_argument(
        "--max-tokens",
        type=int,
        help="Maximum tokens for agent responses",
    )
    parser.add_argument(
        "--query",
        type=str,
        help="Run a single query and exit (non-interactive mode)",
    )
    parser.add_argument(
        "--session-id",
        type=str,
        default=None,
        help="Session ID for resuming a previous conversation",
    )
    parser.add_argument(
        "--session-storage",
        choices=["file", "s3"],
        default=None,
        help="Session storage backend: 'file' or 's3'",
    )
    parser.add_argument(
        "--session-dir",
        type=str,
        default=None,
        help="Local directory for file-based session storage",
    )
    parser.add_argument(
        "--session-s3-bucket",
        type=str,
        default=None,
        help="S3 bucket name for S3-based session storage",
    )
    parser.add_argument(
        "--session-s3-prefix",
        type=str,
        default=None,
        help="S3 key prefix for S3-based session storage",
    )
    parser.add_argument(
        "--conversation-manager",
        choices=["sliding-window", "summarizing", "null"],
        default=None,
        help="Conversation manager type: 'sliding-window', 'summarizing', or 'null'",
    )
    args = parser.parse_args()

    # In single-query mode, suppress all logs except errors
    # so only the agent response goes to stdout.
    if args.query:
        log_level = "ERROR"
    else:
        log_level = args.log_level

    # Update configuration with CLI arguments
    config.update_from_args(
        bedrock_model_id=args.bedrock_model_id,
        knowledge_base_id=args.knowledge_base_id,
        log_level=log_level,
    )
    if args.max_tokens is not None:
        config.agent_max_tokens = args.max_tokens

    # Configure logging (same pattern as main.py)
    try:
        logging.basicConfig(level=config.log_level)
        logging.getLogger("strands").setLevel(config.log_level)
        logging.getLogger("trestle").setLevel(config.log_level)
        logging.getLogger(__package__).setLevel(config.log_level)
        logging.getLogger(__name__).setLevel(config.log_level)
    except ValueError:
        logger.warning("Failed to set log level to: %s", log_level)

    # Verify bundled content integrity
    try:
        my_dir = Path(__file__).parent
        verify_package_integrity(my_dir.joinpath("oscal_schemas"))
    except (RuntimeError, KeyError) as err:
        logger.exception("Bundled context files may have been tampered with; exiting.")
        raise SystemExit(2) from err

    # Initialize OscalStore so store-backed tools work in agent mode
    from mcp_server_for_oscal.main import _init_oscal_store

    _init_oscal_store()

    # Build session and conversation managers from CLI args / config
    session_manager, session_id = _build_session_manager(args, config)
    conversation_manager = _build_conversation_manager(args, config)

    # Create agent
    try:
        agent = create_oscal_agent(
            callback_handler=None if args.query else "default",
            session_manager=session_manager,
            conversation_manager=conversation_manager,
        )
    except ValueError as err:
        logger.exception("Failed to create OSCAL agent")
        raise SystemExit(1) from err

    # Log session ID for discoverability (Req 9.1–9.4)
    if session_manager is not None:
        if args.query:
            logger.debug("Session ID: %s", session_id)
        else:
            logger.info("Session ID: %s", session_id)
            print(f"Session ID: {session_id}")  # noqa: T201

    # Single-query mode: run one query and exit
    if args.query:
        response = agent(args.query)
        print(response)  # noqa: T201
        return

    # Interactive stdin/stdout loop
    logger.info("OSCAL Agent ready. Type your questions below.")
    try:
        while True:
            try:
                user_input = input("You: ")
                if not user_input.strip():
                    continue
                response = agent(user_input)
                print(f"\nAgent: {response}\n")  # noqa: T201
            except (KeyboardInterrupt, EOFError):
                break
    except KeyboardInterrupt:
        logger.info("Shutdown due to keyboard interrupt")
        pass


if __name__ == "__main__":
    main()
