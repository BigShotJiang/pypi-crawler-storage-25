"""
Configuration module for OSCAL MCP Server.

This module handles loading configuration from environment variables with sensible defaults.
"""

import os

from dotenv import load_dotenv


class Config:
    """Configuration class that loads settings from environment variables."""

    def __init__(self) -> None:
        load_dotenv()
        """Initialize configuration from environment variables."""

        # Bedrock configuration (can be overridden by command line args)
        self.bedrock_model_id: str = os.getenv(
            "BEDROCK_MODEL_ID", "us.anthropic.claude-sonnet-4-20250514-v1:0"
        )

        # Knowledge base configuration (can be overridden by command line args)
        self.knowledge_base_id: str = os.getenv("OSCAL_KB_ID", "")

        # AWS configuration
        self.aws_profile: str | None = os.getenv("AWS_PROFILE")
        self.aws_region: str | None = os.getenv("AWS_REGION")

        # Logging configuration
        self.log_level: str = os.getenv("LOG_LEVEL", "INFO")

        # Server configuration
        self.server_name: str = os.getenv("OSCAL_MCP_SERVER_NAME", "OSCAL")

        # Transport configuration
        self.transport: str = os.getenv("OSCAL_MCP_TRANSPORT", "stdio")

        # Server network configuration (for streamable-http transport)
        self.host: str = os.getenv("OSCAL_MCP_HOST", "127.0.0.1")
        self.stateless_http: bool = os.getenv("OSCAL_MCP_STATELESS_HTTP", "false").lower() == "true"

        # Component Definition remote URI configuration
        self.allow_remote_uris: bool = os.getenv("OSCAL_ALLOW_REMOTE_URIS", "false").lower() == "true"
        self.request_timeout: int = int(os.getenv("OSCAL_REQUEST_TIMEOUT", "30"))
        self.max_uri_depth: int = int(os.getenv("OSCAL_MAX_URI_DEPTH", "3"))

        # Component Definition directory configuration
        self.component_definitions_dir: str = os.getenv("OSCAL_COMPONENT_DEFINITIONS_DIR", "component_definitions")

        # OSCAL Store configuration
        self.oscal_store_db_path: str = os.getenv("OSCAL_STORE_DB_PATH", "")
        self.oscal_store_cache_size: int = int(os.getenv("OSCAL_STORE_CACHE_SIZE", "100"))
        self.oscal_documents_dir: str = os.getenv("OSCAL_DOCUMENTS_DIR", "")

        # Session management configuration
        self.session_storage: str = os.getenv("OSCAL_AGENT_SESSION_STORAGE", "")
        self.session_dir: str = os.getenv("OSCAL_AGENT_SESSION_DIR", ".oscal_sessions")
        self.session_s3_bucket: str = os.getenv("OSCAL_AGENT_SESSION_S3_BUCKET", "")
        self.session_s3_prefix: str = os.getenv(
            "OSCAL_AGENT_SESSION_S3_PREFIX", "oscal-agent-sessions/"
        )

        # Conversation management configuration
        self.conversation_manager_type: str = os.getenv(
            "OSCAL_AGENT_CONVERSATION_MANAGER", ""
        )

        # Agent configuration
        self.agent_max_tokens: int = int(os.getenv("OSCAL_AGENT_MAX_TOKENS", "4096"))
        self.agent_max_retry_attempts: int = int(os.getenv("OSCAL_AGENT_MAX_RETRY_ATTEMPTS", "4"))
        self.agent_retry_initial_delay: int = int(os.getenv("OSCAL_AGENT_RETRY_INITIAL_DELAY", "2"))
        self.agent_retry_max_delay: int = int(os.getenv("OSCAL_AGENT_RETRY_MAX_DELAY", "60"))

    def update_from_args(
        self,
        bedrock_model_id: str | None = None,
        knowledge_base_id: str | None = None,
        log_level: str | None = None,
        transport: str | None = None,
    ) -> None:
        """Update configuration with command line arguments."""
        if bedrock_model_id:
            self.bedrock_model_id = bedrock_model_id
        if knowledge_base_id:
            self.knowledge_base_id = knowledge_base_id
        if log_level:
            self.log_level = log_level
        if transport:
            self.transport = transport

    def validate_transport(self) -> None:
        """Validate that the configured transport is supported.

        Raises:
            ValueError: If transport is not one of the valid options.
        """
        valid_transports = ["stdio", "streamable-http"]
        if self.transport not in valid_transports:
            raise ValueError(
                f"Invalid transport type: {self.transport}. "
                f"Valid options are: {', '.join(valid_transports)}"
            )


# Global configuration instance
config = Config()
