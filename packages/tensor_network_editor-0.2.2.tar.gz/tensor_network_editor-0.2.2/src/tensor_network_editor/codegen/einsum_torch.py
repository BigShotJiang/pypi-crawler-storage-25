"""PyTorch einsum code generator."""

from __future__ import annotations

from ..models import EngineName
from .einsum import BaseEinsumCodeGenerator


class EinsumTorchCodeGenerator(BaseEinsumCodeGenerator):
    """Generate PyTorch-based einsum code."""

    engine = EngineName.EINSUM_TORCH
    import_line = "import torch"
    module_alias = "torch"
    zero_initializer_suffix = ", dtype=torch.float32"
    empty_network_expression = "torch.tensor(1.0, dtype=torch.float32)"
