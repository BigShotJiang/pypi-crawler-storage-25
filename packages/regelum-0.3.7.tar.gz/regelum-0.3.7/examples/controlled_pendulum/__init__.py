"""Controlled pendulum marimo example."""

