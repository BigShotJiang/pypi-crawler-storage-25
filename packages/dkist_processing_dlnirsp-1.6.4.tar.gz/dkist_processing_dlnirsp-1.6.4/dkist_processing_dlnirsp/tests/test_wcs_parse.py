import datetime
from typing import Literal
from typing import Type

import numpy as np
import pytest
from astropy.wcs import WCS
from dkist_data_simulator.dataset import key_function
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.models.constants import BudName
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.tasks import WorkflowTaskBase

from dkist_processing_dlnirsp.models.constants import DlnirspBudName
from dkist_processing_dlnirsp.models.parameters import DlnirspParsingParameters
from dkist_processing_dlnirsp.models.tags import DlnirspTag
from dkist_processing_dlnirsp.tasks.parse import ParseL0DlnirspLinearizedData
from dkist_processing_dlnirsp.tests.conftest import DlnirspHeaders
from dkist_processing_dlnirsp.tests.conftest import DlnirspTestingParameters
from dkist_processing_dlnirsp.tests.conftest import make_random_data
from dkist_processing_dlnirsp.tests.conftest import write_dark_frames_to_task
from dkist_processing_dlnirsp.tests.conftest import write_frames_to_task
from dkist_processing_dlnirsp.tests.conftest import write_lamp_gain_frames_to_task
from dkist_processing_dlnirsp.tests.conftest import write_polcal_frames_to_task
from dkist_processing_dlnirsp.tests.conftest import write_solar_gain_frames_to_task


class WCSModulatedObserveHeaders(DlnirspHeaders):
    def __init__(
        self,
        num_mosaics: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
        dither_mode_on: bool = False,
        aborted_loop_level: (
            Literal["dither", "mosaic", "X_tile", "Y_tile", "data_cycle", "modstate"] | None
        ) = None,
        first_XY_loop: Literal["X", "Y"] = "X",
        array_shape: tuple[int, int] = (10, 10),
        exp_time_ms: float = 6.0,
        start_date: str = "2023-01-01T01:23:45",
        arm_position: float = -4.2,
        grating_constant: float = 23.0,
        grating_angle: float = 149.4,
        crpix_zero_point: tuple[float, float] = (100.0, 2000.0),
        crpix_delta: tuple[float, float] = (80.3, 20.7),
        swap_crpix_values: bool = False,
        modstate_length_sec: float = 0.5,
        num_raw_frames_per_fpa: int = 2,
        cam_fps: float = 1.23,
        allow_3D_arrays: bool = False,
    ):
        if len(array_shape) == 3 and not allow_3D_arrays:
            if array_shape[0] != 1:
                raise ValueError(f"{array_shape = } is weird")
            array_shape = array_shape[1:]

        num_dither = int(dither_mode_on) + 1
        num_files = (
            num_mosaics * num_dither * num_X_tiles * num_Y_tiles * num_data_cycles * num_modstates
        )

        if first_XY_loop == "X":
            spatial_step_pattern = "vertical_snake"
        else:
            spatial_step_pattern = "horizontal_snake"

        crpix1_vec = np.arange(num_X_tiles) * crpix_delta[0] + crpix_zero_point[0]
        crpix2_vec = np.arange(num_Y_tiles) * crpix_delta[1] + crpix_zero_point[1]

        # Arrays that show the CRPIX? value at a give [x, y] position
        self.mosaic_crpix1_values, self.mosaic_crpix2_values = np.meshgrid(
            crpix1_vec, crpix2_vec, indexing="ij"
        )

        list_func_input = {
            "num_mosaics": num_mosaics,
            "num_dither": num_dither,
            "num_X_tiles": num_X_tiles,
            "num_Y_tiles": num_Y_tiles,
            "num_data_cycles": num_data_cycles,
            "num_modstates": num_modstates,
        }
        self.mosaic_id_list = self.compute_mosaic_index_list(**list_func_input)
        self.dither_bool_list = self.compute_dither_bool_list(**list_func_input)
        self.spatial_step_X_id_list = self.compute_spatial_step_X_index_list(
            first_XY_loop=first_XY_loop, **list_func_input
        )
        self.spatial_step_Y_id_list = self.compute_spatial_step_Y_index_list(
            first_XY_loop=first_XY_loop, **list_func_input
        )
        self.data_cycle_id_list = self.compute_data_cycle_index_list(**list_func_input)
        self.modstate_id_list = self.compute_modstate_index_list(**list_func_input)

        # The (x, y) *mosaic* indices for a given (spatial_step_x, spatial_step_y) tuple
        self.mosaic_index_tuples = [
            self.compute_spatial_step_to_mosaic_index_mapping(
                spatial_step_x=x,
                spatial_step_y=y,
                num_x_steps=num_X_tiles,
                num_y_steps=num_Y_tiles,
                step_pattern=spatial_step_pattern,
            )
            for x, y in zip(self.spatial_step_X_id_list, self.spatial_step_Y_id_list)
        ]
        self.crpix_1_list = self.compute_crpix1_list(self.mosaic_index_tuples)
        self.crpix_2_list = self.compute_crpix2_list(self.mosaic_index_tuples)

        if swap_crpix_values:
            self.crpix_1_list, self.crpix_2_list = self.crpix_2_list, self.crpix_1_list

        match aborted_loop_level:
            case "mosaic":
                num_missing_files = (
                    num_dither * num_X_tiles * num_Y_tiles * num_data_cycles * num_modstates
                )

            case "dither":
                num_missing_files = num_X_tiles * num_Y_tiles * num_data_cycles * num_modstates

            case "X_tile":
                num_missing_files = num_data_cycles * num_modstates
                if first_XY_loop == "X":
                    num_missing_files *= num_Y_tiles

            case "Y_tile":
                num_missing_files = num_data_cycles * num_modstates
                if first_XY_loop == "Y":
                    num_missing_files *= num_X_tiles

            case "data_cycle":
                num_missing_files = num_modstates

            case "modstate":
                num_missing_files = 1

            case _:
                num_missing_files = 0

        num_files -= num_missing_files
        # Not strictly necessary to shorten these lists because by setting num_files correctly
        # we'll never index into the ends of the full lists, but it helps make things clear
        # (and provides assurance we never accidentally make more files than we expected).
        if num_missing_files > 0:
            self.modstate_id_list = self.modstate_id_list[:-num_missing_files]
            self.spatial_step_Y_id_list = self.spatial_step_Y_id_list[:-num_missing_files]
            self.spatial_step_X_id_list = self.spatial_step_X_id_list[:-num_missing_files]
            self.crpix_1_list = self.crpix_1_list[:-num_missing_files]
            self.crpix_2_list = self.crpix_2_list[:-num_missing_files]
            self.mosaic_id_list = self.mosaic_id_list[:-num_missing_files]
            self.dither_bool_list = self.dither_bool_list[:-num_missing_files]

        dataset_shape = (num_files, *array_shape)
        super().__init__(
            dataset_shape=dataset_shape,
            array_shape=array_shape,
            start_time=datetime.datetime.fromisoformat(start_date),
            time_delta=modstate_length_sec,
            dither_mode_on=dither_mode_on,
            arm_position=arm_position,
            grating_constant=grating_constant,
            grating_angle=grating_angle,
        )

        self.add_constant_key("DKIST004", "OBSERVE")
        self.add_constant_key("DLN__031", num_mosaics)
        self.add_constant_key("DLN__034", num_X_tiles)
        self.add_constant_key("DLN__038", num_Y_tiles)
        self.add_constant_key("DLN__020", num_data_cycles)
        self.add_constant_key("DLN__014", num_modstates)
        self.add_constant_key("CAM__004", exp_time_ms)
        self.add_constant_key("CAM__006", cam_fps)
        self.add_constant_key("CAM__014", num_raw_frames_per_fpa)
        if dither_mode_on:
            del self._fixed_keys["DLN__045"]

    def compute_spatial_step_to_mosaic_index_mapping(
        self,
        spatial_step_x: int,
        spatial_step_y: int,
        num_x_steps: int,
        num_y_steps: int,
        step_pattern: str,
    ) -> tuple[int, int]:
        """
        Given a single (spatial_step_x, spatial_step_y) location, compute the corresponding, absolute (x, y) mosaic position.

        Needed because the spatial step pattern could be basically anything, but we need to know where we are in an
        absolute sense to correctly populate WCS values.
        """
        if step_pattern == "vertical_snake":
            x_mosaic_index = spatial_step_x
            y_mosaic_index = list(range(num_y_steps))[:: -1 if spatial_step_x % 2 else 1][
                spatial_step_y
            ]
        elif step_pattern == "horizontal_snake":
            x_mosaic_index = list(range(num_x_steps))[:: -1 if spatial_step_y % 2 else 1][
                spatial_step_x
            ]
            y_mosaic_index = spatial_step_y
        else:
            raise ValueError(f"Don't know how to map {step_pattern = }")

        return x_mosaic_index, y_mosaic_index

    def compute_mosaic_index_list(
        self,
        num_mosaics: int,
        num_dither: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
    ) -> list[int]:
        return sum(
            [
                [
                    i
                    for _ in range(
                        num_modstates * num_data_cycles * num_Y_tiles * num_X_tiles * num_dither
                    )
                ]
                for i in range(num_mosaics)
            ],
            [],
        )

    def compute_dither_bool_list(
        self,
        num_mosaics: int,
        num_dither: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
    ) -> list[bool]:
        single_mosaic = sum(
            [
                [
                    bool(d)
                    for _ in range(num_X_tiles * num_Y_tiles * num_data_cycles * num_modstates)
                ]
                for d in range(num_dither)
            ],
            [],
        )
        return single_mosaic * num_mosaics

    def compute_spatial_step_X_index_list(
        self,
        first_XY_loop: Literal["X", "Y"],
        num_mosaics: int,
        num_dither: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
    ) -> list[int]:
        inner_range = num_modstates * num_data_cycles * num_Y_tiles
        outer = num_mosaics * num_dither
        if first_XY_loop == "Y":
            inner_range //= num_Y_tiles
            outer *= num_Y_tiles
        return sum(
            [[i for _ in range(inner_range)] for i in range(num_X_tiles)] * outer,
            [],
        )

    def compute_spatial_step_Y_index_list(
        self,
        first_XY_loop: Literal["X", "Y"],
        num_mosaics: int,
        num_dither: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
    ) -> list[int]:
        inner_range = num_modstates * num_data_cycles
        outer = num_mosaics * num_dither * num_X_tiles
        if first_XY_loop == "Y":
            inner_range *= num_X_tiles
            outer //= num_X_tiles

        return sum([[i for _ in range(inner_range)] for i in range(num_Y_tiles)] * outer, [])

    def compute_data_cycle_index_list(
        self,
        num_mosaics: int,
        num_dither: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
    ) -> list[int]:
        single_Y_tile = sum(
            [[i for _ in range(num_modstates)] for i in range(1, num_data_cycles + 1)], []
        )
        return single_Y_tile * num_mosaics * num_dither * num_X_tiles * num_Y_tiles

    def compute_modstate_index_list(
        self,
        num_mosaics: int,
        num_dither: int,
        num_X_tiles: int,
        num_Y_tiles: int,
        num_data_cycles: int,
        num_modstates: int,
    ) -> list[int]:
        single_data_cycle = list(range(1, num_modstates + 1))
        return (
            single_data_cycle
            * num_mosaics
            * num_dither
            * num_X_tiles
            * num_Y_tiles
            * num_data_cycles
        )

    def compute_crpix1_list(
        self,
        mosaic_index_tuples: list[tuple[int, int]],
    ) -> list[float]:
        raw_crpix_list = [self.mosaic_crpix1_values[idx] for idx in mosaic_index_tuples]
        noisy_crpix_list = (
            np.array(raw_crpix_list) + np.random.random(len(raw_crpix_list))
        ).tolist()
        return noisy_crpix_list

    def compute_crpix2_list(
        self,
        mosaic_index_tuples: list[tuple[int, int]],
    ) -> list[float]:

        raw_crpix_list = [self.mosaic_crpix2_values[idx] for idx in mosaic_index_tuples]
        noisy_crpix_list = (
            np.array(raw_crpix_list) + np.random.random(len(raw_crpix_list))
        ).tolist()
        return noisy_crpix_list

    @property
    def fits_wcs(self):
        w = WCS(naxis=self.array_ndim)
        w.wcs.crpix = self.crpix_1_list[self.index], self.crpix_2_list[self.index], 1
        w.wcs.crval = 1565.0, 0, 0
        w.wcs.cdelt = 1, 1, 0.2
        w.wcs.cunit = "arcsec", "arcsec", "nm"
        w.wcs.ctype = "HPLN-TAN", "HPLT-TAN", "AWAV"
        w.wcs.pc = np.identity(self.array_ndim)
        return w

    @property
    def current_MINDEX1_value(self) -> int:
        # Add one because MINDEX keys are 1-indexed
        return self.mosaic_index_tuples[self.index][0] + 1

    @property
    def current_MINDEX2_value(self) -> int:
        return self.mosaic_index_tuples[self.index][1] + 1

    @key_function("DLN__045")
    def current_dither(self, key: str) -> bool:
        return self.dither_bool_list[self.index]

    @key_function("DLN__032")
    def current_mosaic(self, key: str) -> int:
        return self.mosaic_id_list[self.index]

    @key_function("DLN__037")
    def current_spatial_step_X(self, key: str) -> int:
        return self.spatial_step_X_id_list[self.index]

    @key_function("DLN__041")
    def current_spatial_step_Y(self, key: str) -> int:
        return self.spatial_step_Y_id_list[self.index]

    @key_function("DLN__021")
    def current_data_cycle(self, key: str) -> int:
        return self.data_cycle_id_list[self.index]

    @key_function("DLN__015")
    def current_modstate(self, key: str) -> int:
        return self.modstate_id_list[self.index]


class WCSMissingMosaicStepObserveHeaders(WCSModulatedObserveHeaders):
    """For headers where the set of `mosaic_num` values isn't continuous."""

    def __init__(self, array_shape: tuple[int, ...]):

        super().__init__(
            num_modstates=2,
            num_mosaics=2,
            num_X_tiles=3,
            num_Y_tiles=3,
            num_data_cycles=2,
            array_shape=array_shape,
            dither_mode_on=True,
            exp_time_ms=6.0,
        )

        self.mosaic_id_list = [i * 2 for i in self.mosaic_id_list]


class WCSMissingDitherStepObserveHeaders(WCSModulatedObserveHeaders):
    """For headers where the set of `dither_num` values isn't continuous."""

    def __init__(self, array_shape: tuple[int, ...], num_mosaics: int = 1):

        super().__init__(
            num_modstates=2,
            num_mosaics=num_mosaics,
            num_X_tiles=3,
            num_Y_tiles=3,
            num_data_cycles=2,
            dither_mode_on=True,
            array_shape=array_shape,
            exp_time_ms=6.0,
        )

        self.dither_bool_list = [True for _ in self.dither_bool_list]


class WCSMissingXStepObserveHeaders(WCSModulatedObserveHeaders):
    """For headers where the set of `X_tile_num` values isn't continuous."""

    def __init__(self, array_shape: tuple[int, ...], num_mosaics: int = 1):
        """Set num_mosaics > 1 to test whole missing X tiles in the middle of all mosaics."""

        super().__init__(
            num_modstates=2,
            num_mosaics=num_mosaics,
            num_X_tiles=3,
            num_Y_tiles=2,
            num_data_cycles=2,
            array_shape=array_shape,
            exp_time_ms=6.0,
        )

        self.spatial_step_X_id_list = [i * 2 for i in self.spatial_step_X_id_list]


class WCSMissingYStepObserveHeaders(WCSModulatedObserveHeaders):
    """For headers where the set of `Y_tile_num` values isn't continuous."""

    def __init__(self, array_shape: tuple[int, ...], num_mosaics: int = 1, num_X_tiles: int = 1):
        """Set either num_mosaics > 1 or num_X_tiles > 1 to test whole missing Y tiles from all higher-level loops."""
        super().__init__(
            num_modstates=2,
            num_mosaics=num_mosaics,
            num_X_tiles=num_X_tiles,
            num_Y_tiles=3,
            num_data_cycles=2,
            array_shape=array_shape,
            exp_time_ms=6.0,
        )

        self.spatial_step_Y_id_list = [i * 2 for i in self.spatial_step_Y_id_list]


def wcs_write_observe_frames_to_task(
    task: Type[WorkflowTaskBase],
    exp_time_ms: float = 6.0,
    num_modstates: int = 8,
    num_X_tiles: int = 2,
    num_Y_tiles: int = 3,
    num_mosaics: int = 4,
    num_data_cycles: int = 2,
    dither_mode_on: bool = False,
    arm_position: float = -4.2,
    grating_constant: float = 23,
    grating_angle: float = 149.4,
    cam_fps: float = 1.0,
    array_shape: tuple[int, int] = (10, 10),
    crpix_delta: tuple[float, float] = (80.3, 20.7),
    swap_crpix_values: bool = False,
    start_date: str = "2023-01-01T01:23:45",
    modstate_length_sec: float = 0.5,
    data_func: callable = make_random_data,
    tags: list[str] | None = None,
    tag_func: callable = lambda x: [],
) -> int:
    frame_generator = WCSModulatedObserveHeaders(
        num_modstates=num_modstates,
        num_X_tiles=num_X_tiles,
        num_Y_tiles=num_Y_tiles,
        num_mosaics=num_mosaics,
        num_data_cycles=num_data_cycles,
        array_shape=array_shape,
        exp_time_ms=exp_time_ms,
        dither_mode_on=dither_mode_on,
        arm_position=arm_position,
        grating_constant=grating_constant,
        grating_angle=grating_angle,
        crpix_delta=crpix_delta,
        start_date=start_date,
        modstate_length_sec=modstate_length_sec,
        cam_fps=cam_fps,
        swap_crpix_values=swap_crpix_values,
    )

    num_frames = write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=data_func,
        extra_tags=tags,
        tag_func=tag_func,
    )

    return num_frames


@pytest.fixture
def linearized_wcs_parse_task_flip_crpix1_wcs_correction(
    tmp_path, recipe_run_id, assign_input_dataset_doc_to_task, link_constants_db
):
    constants = {"OBS_IP_START_TIME": "2024-01-01"}
    link_constants_db(recipe_run_id=recipe_run_id, constants_obj=constants)
    with ParseL0DlnirspLinearizedData(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)
        assign_input_dataset_doc_to_task(
            task=task,
            parameters=DlnirspTestingParameters(
                dlnirsp_wcs_crpix_correction_method="flip_crpix1",
                dlnirsp_parse_use_crpix_for_mosaic=True,
            ),
            parameter_class=DlnirspParsingParameters,
            obs_ip_start_time=task.constants.obs_ip_start_time,
        )

        yield task
        task._purge()


@pytest.fixture(params=["flip_crpix1", "swap_then_flip_crpix2"])
def linearized_wcs_parse_task_with_multi_crpix_correction_methods(
    tmp_path, recipe_run_id, assign_input_dataset_doc_to_task, link_constants_db, request
):
    crpix_correction_method = request.param
    constants = {"OBS_IP_START_TIME": "2024-01-01"}
    link_constants_db(recipe_run_id=recipe_run_id, constants_obj=constants)
    with ParseL0DlnirspLinearizedData(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        task.scratch = WorkflowFileSystem(scratch_base_path=tmp_path, recipe_run_id=recipe_run_id)
        assign_input_dataset_doc_to_task(
            task=task,
            parameters=DlnirspTestingParameters(
                dlnirsp_wcs_crpix_correction_method=crpix_correction_method,
                dlnirsp_parse_use_crpix_for_mosaic=True,
            ),
            parameter_class=DlnirspParsingParameters,
            obs_ip_start_time=task.constants.obs_ip_start_time,
        )

        yield task
        task._purge()


@pytest.mark.parametrize(
    "dither_mode_on",
    [pytest.param(False, id="dither_mode_off"), pytest.param(True, id="dither_mode_on")],
)
def test_wcs_parse_linearized_data(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods, dither_mode_on
):
    """
    Given: A set of LINEARIZED frames and a Parse task
    When: Parsing the frames
    Then: The frames are tagged correctly and constants are populated correctly
    """

    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    lamp_exp_time = 10.0
    solar_exp_time = 5.0
    obs_exp_time = 6.0
    polcal_exp_time = 7.0
    unused_exp_time = 99.0
    num_mod = 4
    num_dither = int(dither_mode_on) + 1
    num_mosaic = 3
    num_X_tile = 2
    num_Y_tile = 3
    num_data_cycles = 2
    dark_exp_times = [lamp_exp_time, solar_exp_time, obs_exp_time, unused_exp_time]
    arm_position = 6.28
    grating_constant = 43
    grating_angle = 132.2
    solar_ip_start_date = "1999-12-31T23:59:59"

    num_dark = 0
    lin_tag = [DlnirspTag.linearized()]

    # Give dark, lamp, and polcal frames different grating constant, angle, and arm position values to test that the
    # `TaskIn*` buds are correctly discriminating
    for exp_time in dark_exp_times:
        num_dark += write_dark_frames_to_task(
            task,
            exp_time_ms=exp_time,
            tags=lin_tag,
            num_modstates=num_mod,
            arm_position=arm_position * 10,
            grating_constant=grating_constant * 100,
            grating_angle=grating_angle * -2,
        )
    num_lamp = write_lamp_gain_frames_to_task(
        task,
        tags=lin_tag,
        num_modstates=num_mod,
        arm_position=arm_position * 20,
        grating_constant=grating_constant * 200,
        grating_angle=grating_angle * -4,
    )
    num_solar = write_solar_gain_frames_to_task(
        task,
        tags=lin_tag,
        num_modstates=num_mod,
        arm_position=arm_position,
        grating_constant=grating_constant,
        grating_angle=grating_angle,
        start_date=solar_ip_start_date,
    )
    num_polcal = write_polcal_frames_to_task(
        task,
        tags=lin_tag,
        num_modstates=num_mod,
        arm_position=arm_position * 30,
        grating_constant=grating_constant * 300,
        grating_angle=grating_angle * -6,
    )
    obs_start_time = "2020-01-01T01:23:45"
    modstate_length_sec = 0.5
    num_obs = wcs_write_observe_frames_to_task(
        task,
        num_modstates=num_mod,
        num_mosaics=num_mosaic,
        num_X_tiles=num_X_tile,
        num_Y_tiles=num_Y_tile,
        num_data_cycles=num_data_cycles,
        tags=lin_tag,
        arm_position=arm_position,
        grating_constant=grating_constant,
        grating_angle=grating_angle,
        dither_mode_on=dither_mode_on,
        start_date=obs_start_time,
        modstate_length_sec=modstate_length_sec,
        swap_crpix_values="swap" in task.parameters.wcs_crpix_correction_method,
    )
    obs_end_time = datetime.datetime.fromisoformat(obs_start_time) + datetime.timedelta(
        seconds=num_obs * modstate_length_sec
    )

    task()

    # Tags applied correctly
    assert len(list(task.read(tags=[DlnirspTag.linearized(), DlnirspTag.task_dark()]))) == num_dark
    assert (
        len(list(task.read(tags=[DlnirspTag.linearized(), DlnirspTag.task_lamp_gain()])))
        == num_lamp
    )
    assert (
        len(list(task.read(tags=[DlnirspTag.linearized(), DlnirspTag.task_solar_gain()])))
        == num_solar
    )
    assert (
        len(list(task.read(tags=[DlnirspTag.linearized(), DlnirspTag.task_polcal()]))) == num_polcal
    )
    assert (
        len(list(task.read(tags=[DlnirspTag.linearized(), DlnirspTag.task_observe()]))) == num_obs
    )

    for task_name, exp_times in zip(
        [
            TaskName.dark.value,
            TaskName.lamp_gain.value,
            TaskName.solar_gain.value,
            TaskName.polcal.value,
        ],
        [dark_exp_times, [lamp_exp_time], [solar_exp_time], [polcal_exp_time]],
    ):
        for exp in exp_times:
            for modstate in range(1, num_mod + 1):
                tags = [
                    DlnirspTag.linearized_frame(),
                    DlnirspTag.task(task_name),
                    DlnirspTag.exposure_time(exp),
                    DlnirspTag.modstate(modstate),
                ]
                assert len(list(task.read(tags=tags))) == 1

    # Observe frames are special because we want to check for mosaic stuff
    for dither_step in range(num_dither):
        for mosaic in range(num_mosaic):
            for X_tile in range(num_X_tile):
                for Y_tile in range(num_Y_tile):
                    for modstate in range(1, num_mod + 1):
                        tags = [
                            DlnirspTag.linearized_frame(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles

    # Constants loaded correctly
    assert task.constants._db_dict[DlnirspBudName.wavelength] == 1565.0
    assert task.constants._db_dict[DlnirspBudName.polarimeter_mode] == "Full Stokes"
    assert task.constants._db_dict[DlnirspBudName.num_modstates] == num_mod
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_repeats] == num_mosaic
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x] == num_X_tile
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y] == num_Y_tile
    assert task.constants._db_dict[DlnirspBudName.num_dither_steps] == num_dither
    assert task.constants._db_dict[DlnirspBudName.lamp_gain_exposure_times] == [lamp_exp_time]
    assert task.constants._db_dict[DlnirspBudName.solar_gain_exposure_times] == [solar_exp_time]
    assert task.constants._db_dict[DlnirspBudName.observe_exposure_times] == [obs_exp_time]
    assert task.constants._db_dict[DlnirspBudName.polcal_exposure_times] == [polcal_exp_time]
    assert task.constants._db_dict[BudName.retarder_name] == "SiO2 OC"
    assert task.constants._db_dict[DlnirspBudName.arm_position_mm] == arm_position
    assert task.constants._db_dict[DlnirspBudName.grating_constant_inverse_mm] == grating_constant
    np.testing.assert_allclose(
        task.constants._db_dict[DlnirspBudName.grating_position_deg], grating_angle, atol=0.01
    )
    assert task.constants._db_dict[DlnirspBudName.solar_gain_ip_start_time] == solar_ip_start_date
    assert task.constants._db_dict[BudName.camera_name] == "camera_name"
    assert task.constants._db_dict[BudName.dark_gos_level3_status] == "lamp"
    assert task.constants._db_dict[BudName.solar_gain_gos_level3_status] == "clear"
    assert task.constants._db_dict[BudName.solar_gain_num_raw_frames_per_fpa] == 30
    assert task.constants._db_dict[BudName.polcal_num_raw_frames_per_fpa] == 10
    assert task.constants._db_dict[DlnirspBudName.obs_ip_end_time] == obs_end_time.isoformat("T")


def test_crpix_and_spatial_step_association_swapped(
    linearized_wcs_parse_task_flip_crpix1_wcs_correction,
):
    """
    Given: A Parse task and a set of observe frames where CRPIX1 corresponds to the "spatial step y" direction
    When: Parsing the mosaic information
    Then: The correct absolute (i.e., CRPIX[12]) mosaic is determined and tagged.
    """
    task = linearized_wcs_parse_task_flip_crpix1_wcs_correction

    obs_exp_time = 6.0
    num_mod = 1
    num_dither = 1
    num_mosaic = 1
    num_X_tile = 3
    num_Y_tile = 2
    num_data_cycles = 1

    wcs_write_observe_frames_to_task(
        task,
        num_modstates=num_mod,
        num_mosaics=num_mosaic,
        num_X_tiles=num_X_tile,
        num_Y_tiles=num_Y_tile,
        num_data_cycles=num_data_cycles,
        tags=[DlnirspTag.linearized()],
        dither_mode_on=False,
        swap_crpix_values=True,
    )

    task()

    parsed_num_x_tiles = task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x]
    parsed_num_y_tiles = task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y]
    # Here we check that the number of tiles is correctly parsed as the swap of what is expected from the spatial step
    # keys
    assert parsed_num_x_tiles == num_Y_tile
    assert parsed_num_y_tiles == num_X_tile

    for dither_step in range(num_dither):
        for mosaic in range(num_mosaic):
            for X_tile in range(parsed_num_x_tiles):
                for Y_tile in range(parsed_num_y_tiles):
                    for modstate in range(1, num_mod + 1):
                        tags = [
                            DlnirspTag.frame(),
                            DlnirspTag.linearized(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles


########################
# NOTE ABOUT ABORT TESTS
####
# The following tests ensure that parsing is correct when data collection is aborted.
# Each separate test function represents how many *completed* "things" there are before the abort happens, organized
# (as you read down the file) by loop-level. For example, in the first test, `test_parse_aborted_multiple_mosaics`,
# we test how an abort is handled if it happens after at least one complete mosaic as been observed. We need these
# different tests because the abort logic states that if *any* higher-level loop as completed one cycle then *all* lower
# loops are only used if they are complete (see the `mosaic` parsing module for more information).
#
# Each test is parameterized by the level at which the abort happens because we want to make sure the abort detection
# works no matter where in the process the plug was pulled.
#
# Finally, tests of loops below the "dither" level are additionally parameterized by the direction the field moves in
# an absolute sense (`crpix_delta`). This is because at these levels we use the largest contiguous portion of an
# aborted mosaic, and we need to check that the mosaic step assignment is not thrown off by CRPIX[12] values in mosaic
# tiles that will be thrown away (because they are in a sparse part of the aborted mosaic).
########################


@pytest.mark.parametrize(
    "abort_loop, dither_mode_on, num_X_tiles",
    [
        pytest.param("mosaic", True, 3, id="mosaic"),
        #
        pytest.param("dither", True, 3, id="dither"),
        #
        pytest.param("X_tile", True, 3, id="X_tile"),
        pytest.param("X_tile", False, 3, id="X_tile_single_mosaic"),
        #
        pytest.param("Y_tile", True, 3, id="Y_tile"),
        pytest.param("Y_tile", False, 3, id="Y_tile_single_mosaic"),
        pytest.param("Y_tile", False, 1, id="Y_tile_single_mosaic_X_tile"),
        #
        pytest.param("data_cycle", False, 1, id="data_cycle"),
        pytest.param("modstate", False, 1, id="modstate"),
    ],
)
def test_wcs_parse_aborted_multiple_mosaics(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods,
    abort_loop,
    dither_mode_on,
    num_X_tiles,
):
    """
    Given: A Parse task and a set of data with multiple mosaics and the last mosaic aborted at various loop levels
    When: Parsing the data
    Then: The number of mosaics is correctly set to the number of *completed* mosaics
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    num_mosaics = 3
    num_Y_tiles = 2
    num_data_cycles = 3
    num_modstates = 2
    num_dither = int(dither_mode_on) + 1
    obs_exp_time = 6.0

    frame_generator = WCSModulatedObserveHeaders(
        num_mosaics=num_mosaics,
        num_X_tiles=num_X_tiles,
        num_Y_tiles=num_Y_tiles,
        num_data_cycles=num_data_cycles,
        num_modstates=num_modstates,
        dither_mode_on=dither_mode_on,
        aborted_loop_level=abort_loop,
        array_shape=(3, 3),
        swap_crpix_values="swap" in task.parameters.wcs_crpix_correction_method,
    )

    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    expected_num_mosaic = num_mosaics - 1

    task()
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_repeats] == expected_num_mosaic
    assert task.constants._db_dict[DlnirspBudName.num_dither_steps] == num_dither
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x] == num_X_tiles
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y] == num_Y_tiles
    assert task.constants._db_dict[DlnirspBudName.num_modstates] == num_modstates
    for dither_step in range(num_dither):
        for mosaic in range(expected_num_mosaic):
            for X_tile in range(num_X_tiles):
                for Y_tile in range(num_Y_tiles):
                    for modstate in range(1, num_modstates + 1):
                        tags = [
                            DlnirspTag.frame(),
                            DlnirspTag.linearized(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles


@pytest.mark.parametrize(
    "abort_loop, num_X_tiles",
    [
        pytest.param("dither", 3, id="dither"),
        #
        pytest.param("X_tile", 3, id="X_tile"),
        #
        pytest.param("Y_tile", 3, id="Y_tile"),
        pytest.param("Y_tile", 1, id="Y_tile_single_X_tile"),
        #
        pytest.param("data_cycle", 1, id="data_cycle"),
        pytest.param("modstate", 1, id="modstate"),
    ],
)
def test_wcs_parse_aborted_single_mosaic(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods, abort_loop, num_X_tiles
):
    """
    Given: A Parse task and a set of dithered data and the last dither aborted at various loop levels
    When: Parsing the data
    Then: The number of dither steps is always 1 in this case
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    num_mosaics = 1
    num_Y_tiles = 2
    num_data_cycles = 3
    num_modstates = 2
    obs_exp_time = 6.0

    frame_generator = WCSModulatedObserveHeaders(
        num_mosaics=num_mosaics,
        num_X_tiles=num_X_tiles,
        num_Y_tiles=num_Y_tiles,
        num_data_cycles=num_data_cycles,
        num_modstates=num_modstates,
        dither_mode_on=True,
        aborted_loop_level=abort_loop,
        array_shape=(3, 3),
        swap_crpix_values="swap" in task.parameters.wcs_crpix_correction_method,
    )

    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    # Because if we abort when dither mode is on then we get 1, but if dither mode is off it's also 1.
    expected_num_dither = 1

    task()
    assert task.constants._db_dict[DlnirspBudName.num_dither_steps] == expected_num_dither
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x] == num_X_tiles
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y] == num_Y_tiles
    assert task.constants._db_dict[DlnirspBudName.num_modstates] == num_modstates
    for dither_step in range(expected_num_dither):
        for mosaic in range(num_mosaics):
            for X_tile in range(num_X_tiles):
                for Y_tile in range(num_Y_tiles):
                    for modstate in range(1, num_modstates + 1):
                        tags = [
                            DlnirspTag.frame(),
                            DlnirspTag.linearized(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles


@pytest.mark.parametrize(
    "abort_loop",
    [
        pytest.param("X_tile", id="X_tile"),
        pytest.param("Y_tile", id="Y_tile"),
        pytest.param("data_cycle", id="data_cycle"),
        pytest.param("modstate", id="modstate"),
    ],
)
@pytest.mark.parametrize(
    "crpix_delta",
    [
        pytest.param((10.2, 5.1), id="positive_dcrpix"),
        pytest.param((-10.2, 5.1), id="negative_dcrpix1"),
        pytest.param((10.2, -5.1), id="negative_dcrpix2"),
        pytest.param((-10.2, -5.1), id="negative_dcrpix"),
    ],
)
def test_wcs_parse_aborted_single_dither(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods, abort_loop, crpix_delta
):
    """
    Given: A Parse task and a set of data with a single mosaic and the last X tile aborted at various loop levels
    When: Parsing the data
    Then: The number of X tiles is correctly set to the number of *completed* X tiles
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    num_mosaics = 1
    num_dither = 1
    num_X_tiles = 2
    num_Y_tiles = 2
    num_data_cycles = 3
    num_modstates = 2
    obs_exp_time = 6.0

    frame_generator = WCSModulatedObserveHeaders(
        num_mosaics=num_mosaics,
        num_X_tiles=num_X_tiles,
        num_Y_tiles=num_Y_tiles,
        num_data_cycles=num_data_cycles,
        num_modstates=num_modstates,
        dither_mode_on=False,
        aborted_loop_level=abort_loop,
        array_shape=(3, 3),
        crpix_delta=crpix_delta,
        swap_crpix_values="swap" in task.parameters.wcs_crpix_correction_method,
    )

    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    expected_X_tiles = num_X_tiles - 1

    task()
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_repeats] == num_mosaics
    assert task.constants._db_dict[DlnirspBudName.num_dither_steps] == num_dither
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x] == expected_X_tiles
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y] == num_Y_tiles
    assert task.constants._db_dict[DlnirspBudName.num_modstates] == num_modstates
    for dither_step in range(num_dither):
        for mosaic in range(num_mosaics):
            for X_tile in range(expected_X_tiles):
                for Y_tile in range(num_Y_tiles):
                    for modstate in range(1, num_modstates + 1):
                        tags = [
                            DlnirspTag.frame(),
                            DlnirspTag.linearized(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles


@pytest.mark.parametrize(
    "abort_loop", [pytest.param("Y_tile"), pytest.param("data_cycle"), pytest.param("modstate")]
)
@pytest.mark.parametrize(
    "crpix_delta",
    [
        pytest.param((10.2, 5.1), id="positive_dcrpix"),
        pytest.param((-10.2, 5.1), id="negative_dcrpix1"),
        pytest.param((10.2, -5.1), id="negative_dcrpix2"),
        pytest.param((-10.2, -5.1), id="negative_dcrpix"),
    ],
)
def test_wcs_parse_aborted_single_X_tile(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods, abort_loop, crpix_delta
):
    """
    Given: A Parse task and a set of data with a single mosaic and X tile and the last Y tile aborted at various loop levels
    When: Parsing the data
    Then: The number of Y tiles is correctly set to the number of *completed* Y tiles
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    num_mosaics = 1
    num_dither = 1
    num_X_tiles = 1
    num_Y_tiles = 2
    num_data_cycles = 3
    num_modstates = 2
    obs_exp_time = 6.0

    frame_generator = WCSModulatedObserveHeaders(
        num_mosaics=num_mosaics,
        num_X_tiles=num_X_tiles,
        num_Y_tiles=num_Y_tiles,
        num_data_cycles=num_data_cycles,
        num_modstates=num_modstates,
        dither_mode_on=False,
        aborted_loop_level=abort_loop,
        array_shape=(3, 3),
        crpix_delta=crpix_delta,
        swap_crpix_values="swap" in task.parameters.wcs_crpix_correction_method,
    )

    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    expected_Y_tiles = num_Y_tiles - 1

    task()
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_repeats] == num_mosaics
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x] == num_dither
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y] == expected_Y_tiles
    assert task.constants._db_dict[DlnirspBudName.num_modstates] == num_modstates
    for dither_step in range(num_dither):
        for mosaic in range(num_mosaics):
            for X_tile in range(num_X_tiles):
                for Y_tile in range(expected_Y_tiles):
                    for modstate in range(1, num_modstates + 1):
                        tags = [
                            DlnirspTag.frame(),
                            DlnirspTag.linearized(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles


@pytest.mark.parametrize(
    "frame_generator_class, error_name",
    [
        pytest.param(
            WCSMissingMosaicStepObserveHeaders,
            "mosaic repeats",
            id="Mosaic",
        ),
        pytest.param(WCSMissingDitherStepObserveHeaders, "dither steps", id="dither"),
        pytest.param(
            WCSMissingXStepObserveHeaders,
            "spatial_step_x's",
            id="X_tile",
        ),
        pytest.param(
            WCSMissingYStepObserveHeaders,
            "spatial_step_y's",
            id="Y_tile",
        ),
    ],
)
def test_wcs_parse_aborted_single_loop_failures(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods, frame_generator_class, error_name
):
    """
    Given: A Parse task and a set of data where all three of mosaic, X_tile, and Y_tile loops contain missing data
    When: Parsing the data
    Then: The correct error is raised
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    frame_generator = frame_generator_class(array_shape=(3, 3))

    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    with pytest.raises(
        ValueError,
        match=f"Not all sequential {error_name} could be found.",
    ):
        task()


@pytest.mark.parametrize(
    "frame_generator_class, frame_generator_args, error_name",
    [
        pytest.param(
            WCSMissingDitherStepObserveHeaders,
            {"num_mosaics": 2},
            "dither steps",
            id="mosaic",
        ),
        pytest.param(
            WCSMissingXStepObserveHeaders,
            {"num_mosaics": 2},
            "spatial_step_x's",
            id="X_tile",
        ),
        pytest.param(
            WCSMissingYStepObserveHeaders,
            {"num_X_tiles": 2},
            "spatial_step_y's",
            id="Y_tile",
        ),
    ],
)
def test_wcs_parse_missing_loop_failures(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods,
    frame_generator_class,
    frame_generator_args,
    error_name,
):
    """
    Given: A Parse task and a set of data where all three of mosaic, X_tile, and Y_tile loops contain missing data
    When: Parsing the data
    Then: The correct error is raised
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    kwargs = {"array_shape": (3, 3)} | frame_generator_args
    frame_generator = frame_generator_class(**kwargs)
    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    with pytest.raises(
        ValueError,
        match=f"Whole {error_name} are missing. This is extremely strange.",
    ):
        task()


@pytest.mark.parametrize(
    "abort_loop, first_XY_loop",
    [
        pytest.param("X_tile", "X", id="X_abort_X_first"),
        pytest.param("Y_tile", "X", id="Y_abort_X_first"),
        pytest.param("X_tile", "Y", id="X_abort_Y_first"),
        pytest.param("Y_tile", "Y", id="Y_abort_Y_first"),
    ],
)
@pytest.mark.parametrize(
    "crpix_delta",
    [
        pytest.param((10.2, 5.1), id="positive_dcrpix"),
        pytest.param((-10.2, 5.1), id="negative_dcrpix1"),
        pytest.param((10.2, -5.1), id="negative_dcrpix2"),
        pytest.param((-10.2, -5.1), id="negative_dcrpix"),
    ],
)
def test_wcs_parse_aborted_XY_loop_order(
    linearized_wcs_parse_task_with_multi_crpix_correction_methods,
    abort_loop,
    first_XY_loop,
    crpix_delta,
):
    """
    Given: A Parse task and a set of data with a single mosaic and dither where the last X/Y tile is aborted and the X/Y loop order changes
    When: Parsing the data
    Then: The number of the outer loop tiles is one less while the inner loop is all present in the input
    """
    task = linearized_wcs_parse_task_with_multi_crpix_correction_methods

    num_mosaics = 1
    num_dither = 1
    num_X_tiles = 2
    num_Y_tiles = 3
    num_data_cycles = 1
    num_modstates = 1
    obs_exp_time = 6.0

    frame_generator = WCSModulatedObserveHeaders(
        num_mosaics=num_mosaics,
        num_X_tiles=num_X_tiles,
        num_Y_tiles=num_Y_tiles,
        num_data_cycles=num_data_cycles,
        num_modstates=num_modstates,
        dither_mode_on=False,
        aborted_loop_level=abort_loop,
        array_shape=(3, 3),
        first_XY_loop=first_XY_loop,
        crpix_delta=crpix_delta,
        swap_crpix_values="swap" in task.parameters.wcs_crpix_correction_method,
    )

    write_frames_to_task(
        task=task,
        frame_generator=frame_generator,
        data_func=make_random_data,
        extra_tags=[DlnirspTag.linearized()],
    )

    if first_XY_loop == "X":
        expected_X_tiles = num_X_tiles - 1
        expected_Y_tiles = num_Y_tiles
    else:
        expected_X_tiles = num_X_tiles
        expected_Y_tiles = num_Y_tiles - 1

    task()
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_repeats] == num_mosaics
    assert task.constants._db_dict[DlnirspBudName.num_dither_steps] == num_dither
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_x] == expected_X_tiles
    assert task.constants._db_dict[DlnirspBudName.num_mosaic_tiles_y] == expected_Y_tiles
    assert task.constants._db_dict[DlnirspBudName.num_modstates] == num_modstates
    for dither_step in range(num_dither):
        for mosaic in range(num_mosaics):
            for X_tile in range(expected_X_tiles):
                for Y_tile in range(expected_Y_tiles):
                    for modstate in range(1, num_modstates + 1):
                        tags = [
                            DlnirspTag.frame(),
                            DlnirspTag.linearized(),
                            DlnirspTag.task_observe(),
                            DlnirspTag.exposure_time(obs_exp_time),
                            DlnirspTag.mosaic_num(mosaic),
                            DlnirspTag.mosaic_tile_x(X_tile),
                            DlnirspTag.mosaic_tile_y(Y_tile),
                            DlnirspTag.dither_step(dither_step),
                            DlnirspTag.modstate(modstate),
                        ]
                        assert len(list(task.read(tags=tags))) == num_data_cycles
