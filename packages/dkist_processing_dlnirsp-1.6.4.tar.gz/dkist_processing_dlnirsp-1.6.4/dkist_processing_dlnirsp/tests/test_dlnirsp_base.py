import pytest
from dkist_processing_common.codecs.basemodel import basemodel_decoder
from dkist_processing_common.models.quality import TaskCount

from dkist_processing_dlnirsp.models.constants import DlnirspConstants
from dkist_processing_dlnirsp.models.parameters import DlnirspParameters
from dkist_processing_dlnirsp.tasks.dlnirsp_base import DlnirspTaskBase
from dkist_processing_dlnirsp.tests.conftest import DlnirspTestingConstants


@pytest.fixture()
def dummy_arm_id() -> str:
    return "ARMY_MCARMFACE"


@pytest.fixture
def dlnirsp_science_task(session_recipe_run_id, session_link_constants_db, dummy_arm_id):
    class Task(DlnirspTaskBase):
        def run(self) -> None:
            pass

    session_link_constants_db(
        recipe_run_id=session_recipe_run_id,
        constants_obj=DlnirspTestingConstants(ARM_ID=dummy_arm_id),
    )

    with Task(
        recipe_run_id=session_recipe_run_id,
        workflow_name="dlnirsp_base_test",
        workflow_version="x.y.z",
    ) as task:
        yield task
        task._purge()


def test_base_constants_class(dlnirsp_science_task, dummy_arm_id):
    """
    Given: A Science task made from a DL task base
    When: Instantiating the class
    Then: The task's constants object is a DlnirspConstants object
    """
    task = dlnirsp_science_task

    assert type(task.constants) is DlnirspConstants
    assert task.constants.arm_id == dummy_arm_id


def test_base_parameters_class(dlnirsp_science_task, dummy_arm_id):
    """
    Given: A Science task made from a DL task base
    When: Instantiating the class
    Then: DlnirspTaskBase has a DlnirspParameters object and DlnirspLinearityTaskBase doesn't have any parameters
    """
    task = dlnirsp_science_task

    if isinstance(task, DlnirspTaskBase):
        assert type(task.parameters) is DlnirspParameters
        assert task.parameters._arm_id == dummy_arm_id.casefold()
    else:
        with pytest.raises(AttributeError):
            task.parameters


@pytest.mark.parametrize(
    "task_type, total_frames, frames_not_used",
    [
        pytest.param("one", 1, 1, id="simple"),
        pytest.param("two", 2, 0, id="not_used_zero"),
        pytest.param("three", 3, None, id="not_used_none"),
    ],
)
def test_quality_write_intermediate_task_type_counts(
    task_type: str, total_frames: int, frames_not_used: int | None, dlnirsp_science_task
):
    """
    Given: Valid intermediate task type count input
    When: Running DlnirspTaskBase quality_write_intermediate_task_type_counts()
    Then: A single TaskCount file gets created
    """
    # Given
    task = dlnirsp_science_task

    # When
    if frames_not_used is not None:
        task.quality_write_intermediate_task_type_counts(task_type, total_frames, frames_not_used)
    else:
        task.quality_write_intermediate_task_type_counts(task_type, total_frames)

    # Then
    task_counts: list[TaskCount] = list(
        task.read(tags="QUALITY_TASK_TYPES", decoder=basemodel_decoder, model=TaskCount)
    )
    assert isinstance(task_counts, list)
    assert len(task_counts) == 1
    task_count = task_counts[0]
    assert task_count.task_type == str(task_type).upper()
    assert task_count.total_frames == total_frames
    if frames_not_used is not None:
        assert task_count.frames_not_used == frames_not_used
    else:
        assert task_count.frames_not_used == 0
