"""Buds to parse the number of subloops making up a mosaic."""

from collections import defaultdict
from datetime import datetime
from functools import cache
from functools import cached_property
from typing import Literal
from typing import Type

import numpy as np
from dkist_processing_common.models.flower_pot import ListStem
from dkist_processing_common.models.flower_pot import SpilledDirt
from dkist_processing_common.models.task_name import TaskName
from dkist_service_configuration.logging import logger
from pydantic import BaseModel

from dkist_processing_dlnirsp.models.constants import DlnirspBudName
from dkist_processing_dlnirsp.parsers.dlnirsp_l0_fits_access import DlnirspL0FitsAccess

cached_info_logger = cache(logger.info)
SPATIAL_STEP_LABEL_TYPE_HINT = Literal["spatial_step_x", "spatial_step_y"]


class locking_cached_property(cached_property):
    """
    Version of `cached_property` that sets `_state_locked` to `True` when the property is accessed.

    This is useful for cases where we want to ensure the state of the class containing this property doesn't change
    after the property is computed once.
    """

    def __get__(self, instance, owner=None):
        """Set `instance._state_locked = True` while getting the cached value."""
        if instance is None:
            raise ValueError(f"{self.__class__.__name__} doesn't work outside a class instance")

        instance._state_locked = True

        return super().__get__(instance, owner)


class MosaicPiece(BaseModel):
    """Container and validator for storing header values used to assign mosaic location."""

    dither_step: int
    mosaic_num: int
    spatial_step_x: int
    spatial_step_y: int
    timestamp: float


class MosaicPieceBase(ListStem):
    """
    Base class for identifying the organization of dither steps, mosaic repeats, X tiles, and Y tiles in a dataset.

    Header keys exist for all of these loop levels; this class exists to handle the logic of datasets that are aborted
    at different levels of the instrument loops.

    Each "piece" of the mosaic loop (dither, mosaic repeats, X tiles, Y tiles) is recorded for all OBSERVE frames so
    that derived classes can use this information to figure out how many pieces there are.
    """

    # Type-hint for linting
    value_list: list[MosaicPiece]

    def setter(self, fits_obj: DlnirspL0FitsAccess) -> Type[SpilledDirt] | MosaicPiece:
        """
        Extract the mosaic piece information from each frame and package in a tuple.

        Only OBSERVE frames are considered.
        """
        if fits_obj.ip_task_type.casefold() != TaskName.observe.value.casefold():
            return SpilledDirt

        dither_step = fits_obj.dither_step
        mosaic_num = fits_obj.mosaic_num
        spatial_step_x = fits_obj.X_tile_num
        spatial_step_y = fits_obj.Y_tile_num
        timestamp = datetime.fromisoformat(fits_obj.time_obs).timestamp()

        return MosaicPiece(
            dither_step=dither_step,
            mosaic_num=mosaic_num,
            spatial_step_x=spatial_step_x,
            spatial_step_y=spatial_step_y,
            timestamp=timestamp,
        )

    def multiple_pieces_attempted_and_at_least_one_completed(
        self, piece_name: Literal["dither_step", "mosaic_num", "spatial_step_x", "spatial_step_y"]
    ) -> bool:
        """Return `True` if more than one of the requested pieces was attempted and at least one completed."""
        num_files_per_piece = self.num_files_per_mosaic_piece(piece_name)
        complete_piece_nums = self.complete_piece_list(num_files_per_piece)
        num_attempted_pieces = len(num_files_per_piece.keys())
        num_completed_pieces = len(complete_piece_nums)

        return num_attempted_pieces > 1 and num_completed_pieces > 0

    def num_files_per_mosaic_piece(
        self, piece_name: Literal["dither_step", "mosaic_num", "spatial_step_x", "spatial_step_y"]
    ) -> dict[int, int]:
        """
        Compute the number of files per each unique mosaic piece.

        For example, if each mosaic num usually has 4 files, but an abort resulted in the last one only having 2 then
        the output of this method would be `{0: 4, 1: 4, 2: 4, 3: 2}`.
        """
        num_files_per_piece = defaultdict(int)
        for mosaic_piece in self.value_list:
            num_files_per_piece[getattr(mosaic_piece, piece_name)] += 1

        return num_files_per_piece

    def complete_piece_list(self, num_files_per_piece_dict: dict[int, int]) -> list[int]:
        """
        Identify the identifiers of all complete mosaic pieces.

        "Completed" pieces are assumed to be those that have a number of files equal to the maximum number of files
        in any mosaic piece. This is a good assumption for now.
        """
        complete_piece_size = max(num_files_per_piece_dict.values())
        return [
            piece_num
            for piece_num, piece_size in num_files_per_piece_dict.items()
            if piece_size == complete_piece_size
        ]


class NumMosaicRepeatsBud(MosaicPieceBase):
    """
    Bud for determining the number of mosaic repeats.

    Only completed mosaics are considered.
    """

    def __init__(self):
        super().__init__(stem_name=DlnirspBudName.num_mosaic_repeats.value)

    def getter(self) -> int:
        """
        Return the number of *completed* mosaic repeats.

        A check is also made that the list of completed repeats is continuous from 0 to the number of completed repeats.
        """
        num_files_per_mosaic = self.num_files_per_mosaic_piece("mosaic_num")
        complete_mosaic_nums = self.complete_piece_list(num_files_per_mosaic)

        num_mosaics = len(complete_mosaic_nums)
        sorted_complete_mosaic_nums = sorted(complete_mosaic_nums)
        if sorted_complete_mosaic_nums != list(range(num_mosaics)):
            raise ValueError(
                f"Not all sequential mosaic repeats could be found. Found {sorted_complete_mosaic_nums}"
            )

        return num_mosaics


class NumDitherStepsBud(MosaicPieceBase):
    """
    Bud for determining the number of dither steps.

    If there are multiple mosaic repeats and any of them are complete then *all* dither steps are expected to exist.
    Otherwise the number of completed dither steps is returned.
    """

    def __init__(self):
        super().__init__(stem_name=DlnirspBudName.num_dither_steps.value)

    def getter(self) -> int:
        """
        Return the number of *completed* dither steps.

        Also check that the set of completed dither steps is either `{0}` or `{0, 1}` (because the max number of dither
        steps is 2).
        """
        num_files_per_dither = self.num_files_per_mosaic_piece("dither_step")
        if self.multiple_pieces_attempted_and_at_least_one_completed("mosaic_num"):
            # Only consider complete dither steps
            all_dither_steps = sorted(list(num_files_per_dither.keys()))
            num_dither_steps = len(all_dither_steps)
            if all_dither_steps != list(range(num_dither_steps)):
                raise ValueError(
                    f"Whole dither steps are missing. This is extremely strange. Found {all_dither_steps}"
                )
            return num_dither_steps

        complete_dither_nums = self.complete_piece_list(num_files_per_dither)

        num_dither = len(complete_dither_nums)

        if sorted(complete_dither_nums) != list(range(num_dither)):
            raise ValueError(
                f"Not all sequential dither steps could be found. Found {set(complete_dither_nums)}."
            )

        return num_dither


class NumXYMosaicTilesBaseBud(MosaicPieceBase):
    """
    Bud Class for determining the number of X and Y mosaic tiles.

    As a child of `MosaicPieceBase` this class adds the ability to determine which mosaic loop (X or Y) was the
    outer loop. The order of loops is needed to accurately identify the number of "completed" mosaic pieces.
    """

    def __init__(self, stem_name: str, spatial_step_label: SPATIAL_STEP_LABEL_TYPE_HINT) -> None:
        super().__init__(stem_name=stem_name)
        self.spatial_step_label = spatial_step_label
        self._state_locked = False

    def setter(self, fits_obj: DlnirspL0FitsAccess) -> Type[SpilledDirt] | MosaicPiece:
        """
        Disallow setting if a `locking_cached_property` has already been accessed.

        Otherwise, set as in `MosaicPieceBase.setter`.
        """
        if self._state_locked:
            raise ValueError(
                f"State of {self.__class__.__name__} has been locked. No more setting allowed."
            )
        return super().setter(fits_obj)

    def get_avg_delta_time_for_piece(self, piece_name: SPATIAL_STEP_LABEL_TYPE_HINT) -> float:
        """
        Compute the median length of time it took to observe all frames of a single X/Y tile index.

        This is different than the time to observe a single tile. For example, if the loop order is::

          spatial_step_x:
            spatial_step_y:

        then spatial_step_y index 0 won't be finished observing until the last spatial_step_x, while spatial_step_x
        index 0 will be finished as soon as all spatial_step_ys are observed once.
        """
        times_per_piece = defaultdict(list)
        for mosaic_piece in self.value_list:
            times_per_piece[getattr(mosaic_piece, piece_name)].append(mosaic_piece.timestamp)

        length_per_piece = [max(times) - min(times) for times in times_per_piece.values()]

        # median because an abort could cause a weirdly short piece
        return float(np.median(length_per_piece))

    @locking_cached_property
    def outer_loop_identifier(self) -> str:
        """
        Return the identified of the outer X/Y mosaic loop.

        The loop with the smaller time to complete a single index is the outer loop. See `get_avg_delta_time_for_piece`
        for more info.
        """
        avg_x_step_length = self.get_avg_delta_time_for_piece("spatial_step_x")
        avg_y_step_length = self.get_avg_delta_time_for_piece("spatial_step_y")

        if avg_x_step_length > avg_y_step_length:
            return "spatial_step_y"

        return "spatial_step_x"

    @locking_cached_property
    def any_outer_loop_attempted_multiple_times_and_completed_at_least_once(self) -> bool:
        """
        Return True if any outer loop completed at least once.

        The dither and mosaic loops are always "outer", and we also check if the other X/Y loop was outer to the loop
        in question.
        """
        # The logic of this conditionals is pretty subtle so here's an explanation:
        # If ANY outer-level loop has more than one iteration then ALL inner-level loops will be required
        # to be complete. This is why this is `or` instead of `and` when combining booleans for each loop level. For
        # example if num_dithers=2 but the mosaic loop was not used (num_mosaic = 1) we still need all X tiles.
        dither_or_mosaic_completed = (
            self.multiple_pieces_attempted_and_at_least_one_completed("mosaic_num")  # fmt: skip
            or self.multiple_pieces_attempted_and_at_least_one_completed("dither_step")
        )

        opposite_tile_identifier: SPATIAL_STEP_LABEL_TYPE_HINT = (
            "spatial_step_x" if self.spatial_step_label == "spatial_step_y" else "spatial_step_y"
        )

        if self.outer_loop_identifier == opposite_tile_identifier:
            return (
                dither_or_mosaic_completed
                or self.multiple_pieces_attempted_and_at_least_one_completed(opposite_tile_identifier)  # fmt: skip
            )

        return dither_or_mosaic_completed

    def getter(self) -> int:
        """
        Return the number of X or Y tiles.

        First, the order of X/Y loops is established. If any outer loops (mosaic, dither, and the outer X/Y loop) were
        attempted and at least one is completed then all tiles are required to be complete, but if all outer loops are
        singular then the total number of tiles is considered to be the number of *completed* tiles.

        We also check that the set of tiles is continuous from 0 to the number of tiles.
        """
        cached_info_logger(f"Outer mosaic loop is {self.outer_loop_identifier}")
        num_files_per_tile = self.num_files_per_mosaic_piece(self.spatial_step_label)

        if self.any_outer_loop_attempted_multiple_times_and_completed_at_least_once:
            all_tiles = sorted(list(num_files_per_tile.keys()))
            num_tiles = len(all_tiles)
            if all_tiles != list(range(num_tiles)):
                raise ValueError(
                    f"Whole {self.spatial_step_label}'s are missing. This is extremely strange. Found {all_tiles}"
                )
            return num_tiles

        # Otherwise all outer loops only have 1 element and all complete tiles are valid
        completed_tiles = self.complete_piece_list(num_files_per_tile)

        num_tiles = len(completed_tiles)
        sorted_complete_tiles = sorted(completed_tiles)
        if sorted_complete_tiles != list(range(num_tiles)):
            raise ValueError(
                f"Not all sequential {self.spatial_step_label}'s could be found. Found {sorted_complete_tiles}"
            )

        return num_tiles


class NumMosaicXTilesBud(NumXYMosaicTilesBaseBud):
    """Class for finding the number of mosaic tiles in the X direction."""

    def __init__(self):
        super().__init__(
            stem_name=DlnirspBudName.num_mosaic_tiles_x.value, spatial_step_label="spatial_step_x"
        )


class NumMosaicYTilesBud(NumXYMosaicTilesBaseBud):
    """Class for finding the number of mosaic tiles in the Y direction."""

    def __init__(self):
        super().__init__(
            stem_name=DlnirspBudName.num_mosaic_tiles_y.value, spatial_step_label="spatial_step_y"
        )
