"""Tasks for parsing both raw and linearized data."""

from typing import TypeVar

from dkist_processing_common.models.constants import BudName
from dkist_processing_common.models.fits_access import MetadataKey
from dkist_processing_common.models.flower_pot import ListStem
from dkist_processing_common.models.flower_pot import Stem
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.parsers.cs_step import CSStepFlower
from dkist_processing_common.parsers.cs_step import CSStepFrameFlower
from dkist_processing_common.parsers.cs_step import NumCSStepBud
from dkist_processing_common.parsers.cs_step import NumFramesPerCSStepBud
from dkist_processing_common.parsers.lookup_bud import TaskTimeLookupBud
from dkist_processing_common.parsers.near_bud import TaskNearFloatBud
from dkist_processing_common.parsers.retarder import RetarderNameBud
from dkist_processing_common.parsers.single_value_single_key_flower import (
    SingleValueSingleKeyFlower,
)
from dkist_processing_common.parsers.task import PolcalTaskFlower
from dkist_processing_common.parsers.task import parse_header_ip_task_with_gains
from dkist_processing_common.parsers.time import ExposureTimeFlower
from dkist_processing_common.parsers.time import ObsIpStartTimeBud
from dkist_processing_common.parsers.time import TaskExposureTimesBud
from dkist_processing_common.parsers.time import TaskReadoutExpTimesBud
from dkist_processing_common.parsers.unique_bud import TaskUniqueBud
from dkist_processing_common.parsers.unique_bud import UniqueBud
from dkist_processing_common.tasks import ParseDataBase
from dkist_processing_common.tasks import default_constant_bud_factory
from dkist_processing_common.tasks import default_tag_flower_factory
from dkist_service_configuration.logging import logger

from dkist_processing_dlnirsp.models.constants import DlnirspBudName
from dkist_processing_dlnirsp.models.fits_access import DlnirspMetadataKey
from dkist_processing_dlnirsp.models.parameters import DlnirspParsingParameters
from dkist_processing_dlnirsp.models.tags import DlnirspStemName
from dkist_processing_dlnirsp.models.tags import DlnirspTag
from dkist_processing_dlnirsp.parsers.dlnirsp_l0_fits_access import DlnirspL0FitsAccess
from dkist_processing_dlnirsp.parsers.dlnirsp_l0_fits_access import DlnirspRampFitsAccess
from dkist_processing_dlnirsp.parsers.mosaic import NumDitherStepsBud
from dkist_processing_dlnirsp.parsers.mosaic import NumMosaicRepeatsBud
from dkist_processing_dlnirsp.parsers.mosaic import NumMosaicXTilesBud
from dkist_processing_dlnirsp.parsers.mosaic import NumMosaicYTilesBud
from dkist_processing_dlnirsp.parsers.task import DlnirspTaskTypeFlower
from dkist_processing_dlnirsp.parsers.time import DLnirspSolarGainIpStartTimeBud
from dkist_processing_dlnirsp.parsers.time import DlnirspTimeObsBud
from dkist_processing_dlnirsp.parsers.time import TaskDateEndBud
from dkist_processing_dlnirsp.parsers.wcs_mosaic import WCSMosaicStepXFlower
from dkist_processing_dlnirsp.parsers.wcs_mosaic import WCSMosaicStepYFlower
from dkist_processing_dlnirsp.parsers.wcs_mosaic import WCSNumDitherStepsBud
from dkist_processing_dlnirsp.parsers.wcs_mosaic import WCSNumMosaicRepeatsBud
from dkist_processing_dlnirsp.parsers.wcs_mosaic import WCSNumMosaicXTilesBud
from dkist_processing_dlnirsp.parsers.wcs_mosaic import WCSNumMosaicYTilesBud

S = TypeVar("S", bound=Stem)

__all__ = ["ParseL0DlnirspRampData", "ParseL0DlnirspLinearizedData"]


class ParseL0DlnirspRampData(ParseDataBase):
    """
    Parse DLNIRSP pre-linearized ramp data.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    @property
    def fits_parsing_class(self):
        """FITS access class to be used with this task."""
        return DlnirspRampFitsAccess

    @property
    def constant_buds(self) -> list[S]:
        """Add DLNIRSP specific constants to common constants."""
        return [
            ObsIpStartTimeBud(),
            # Time Obs is the unique identifier for each ramp in the data set
            DlnirspTimeObsBud(),
            # This is used to determine whether we need to do any linearity correction at all.
            UniqueBud(
                constant_name=DlnirspBudName.arm_id.value, metadata_key=DlnirspMetadataKey.arm_id
            ),
        ]

    @property
    def tag_flowers(self) -> list[S]:
        """Add DLNIRSP specific tags to common tags."""
        return [
            SingleValueSingleKeyFlower(
                tag_stem_name=DlnirspStemName.current_frame_in_ramp.value,
                metadata_key=DlnirspMetadataKey.current_frame_in_ramp,
            ),
            # time_obs is a unique identifier for all raw frames in a single ramp
            SingleValueSingleKeyFlower(
                tag_stem_name=DlnirspStemName.time_obs.value,
                metadata_key=MetadataKey.time_obs,
            ),
        ]

    @property
    def tags_for_input_frames(self) -> list[str]:
        """Tags for the input data to parse."""
        return [DlnirspTag.input(), DlnirspTag.frame()]


class ParseL0DlnirspLinearizedData(ParseDataBase):
    """
    Parse linearity corrected DLNIRSP input data.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    def __init__(
        self,
        recipe_run_id: int,
        workflow_name: str,
        workflow_version: str,
    ):
        super().__init__(
            recipe_run_id=recipe_run_id,
            workflow_name=workflow_name,
            workflow_version=workflow_version,
        )
        self.parameters = DlnirspParsingParameters(
            scratch=self.scratch, obs_ip_start_time=self.constants.obs_ip_start_time
        )

    @property
    def fits_parsing_class(self):
        """FITS access class to be used in this task."""
        return DlnirspL0FitsAccess

    @property
    def tags_for_input_frames(self) -> list[str]:
        """Tags for the linearity corrected input frames."""
        return [DlnirspTag.linearized(), DlnirspTag.frame()]

    @property
    def mosaic_buds(self) -> list[Stem | ListStem]:
        """
        Return list of Buds used to parse mosaic information.

        This property reads the `~dkist_processing_dlnirsp.models.parameters.DlnirspParsingParameters.parse_use_crpix_for_mosaic`
        parameter and either CRPIX or metadata-key based parsing Buds depending on the value.
        """
        if self.parameters.parse_use_crpix_for_mosaic:
            logger.info("Using WCS-based mosaic parsing")
            return [
                WCSNumMosaicRepeatsBud(
                    crpix_correction_method=self.parameters.wcs_crpix_correction_method,
                    bin_crpix_to_multiple_of=self.parameters.parse_bin_crpix_to_multiple_of,
                ),
                WCSNumDitherStepsBud(
                    crpix_correction_method=self.parameters.wcs_crpix_correction_method,
                    bin_crpix_to_multiple_of=self.parameters.parse_bin_crpix_to_multiple_of,
                ),
                WCSNumMosaicXTilesBud(
                    crpix_correction_method=self.parameters.wcs_crpix_correction_method,
                    bin_crpix_to_multiple_of=self.parameters.parse_bin_crpix_to_multiple_of,
                ),
                WCSNumMosaicYTilesBud(
                    crpix_correction_method=self.parameters.wcs_crpix_correction_method,
                    bin_crpix_to_multiple_of=self.parameters.parse_bin_crpix_to_multiple_of,
                ),
            ]

        logger.info("Using spatial-step-based mosaic parsing")
        return [
            NumMosaicRepeatsBud(),
            NumDitherStepsBud(),
            NumMosaicXTilesBud(),
            NumMosaicYTilesBud(),
        ]

    @property
    def mosaic_flowers(self) -> list[Stem]:
        """
        Return list of Flowers used to tag files with mosaic information.

        This property reads the `~dkist_processing_dlnirsp.models.parameters.DlnirspParsingParameters.parse_use_crpix_for_mosaic`
        parameter and either CRPIX or metadata-key based parsing Flowers depending on the value.
        """
        if self.parameters.parse_use_crpix_for_mosaic:
            return [
                WCSMosaicStepXFlower(
                    crpix_correction_method=self.parameters.wcs_crpix_correction_method,
                    bin_crpix_to_multiple_of=self.parameters.parse_bin_crpix_to_multiple_of,
                ),
                WCSMosaicStepYFlower(
                    crpix_correction_method=self.parameters.wcs_crpix_correction_method,
                    bin_crpix_to_multiple_of=self.parameters.parse_bin_crpix_to_multiple_of,
                ),
            ]

        return [
            SingleValueSingleKeyFlower(
                tag_stem_name=DlnirspStemName.mosaic_tile_x.value,
                metadata_key=DlnirspMetadataKey.X_tile_num,
            ),
            SingleValueSingleKeyFlower(
                tag_stem_name=DlnirspStemName.mosaic_tile_y.value,
                metadata_key=DlnirspMetadataKey.Y_tile_num,
            ),
        ]

    @property
    def constant_buds(self) -> list[S]:
        """Add DLNIRSP specific constants to common constants."""
        return (
            default_constant_bud_factory()
            + [
                TaskUniqueBud(
                    constant_name=BudName.wavelength,
                    metadata_key=MetadataKey.wavelength,
                    ip_task_types=TaskName.observe,
                ),
                TaskUniqueBud(
                    constant_name=DlnirspBudName.obs_ip_end_time.value,
                    metadata_key=MetadataKey.ip_end_time,
                    ip_task_types=TaskName.observe,
                ),
                DLnirspSolarGainIpStartTimeBud(),
                NumCSStepBud(max_cs_step_time_sec=self.parameters.max_cs_step_time_sec),
                UniqueBud(
                    constant_name=DlnirspBudName.polarimeter_mode.value,
                    metadata_key=DlnirspMetadataKey.polarimeter_mode,
                ),
                RetarderNameBud(),
                UniqueBud(
                    constant_name=DlnirspBudName.num_modstates.value,
                    metadata_key=DlnirspMetadataKey.number_of_modulator_states,
                ),
                TaskExposureTimesBud(
                    stem_name=DlnirspBudName.lamp_gain_exposure_times.value,
                    ip_task_types=TaskName.lamp_gain.value,
                    header_task_parsing_func=parse_header_ip_task_with_gains,
                ),
                TaskExposureTimesBud(
                    stem_name=DlnirspBudName.solar_gain_exposure_times.value,
                    ip_task_types=TaskName.solar_gain.value,
                    header_task_parsing_func=parse_header_ip_task_with_gains,
                ),
                TaskExposureTimesBud(
                    stem_name=DlnirspBudName.observe_exposure_times.value,
                    ip_task_types=TaskName.observe.value,
                    header_task_parsing_func=parse_header_ip_task_with_gains,
                ),
                TaskExposureTimesBud(
                    stem_name=DlnirspBudName.polcal_exposure_times.value,
                    ip_task_types=TaskName.polcal.value,
                    header_task_parsing_func=parse_header_ip_task_with_gains,
                ),
                TaskReadoutExpTimesBud(
                    stem_name=DlnirspBudName.solar_gain_readout_exposure_times.value,
                    ip_task_types=TaskName.solar_gain.value,
                    header_task_parsing_func=parse_header_ip_task_with_gains,
                ),
                TaskReadoutExpTimesBud(
                    stem_name=DlnirspBudName.polcal_readout_exposure_times.value,
                    ip_task_types=TaskName.polcal.value,
                ),
                TaskNearFloatBud(
                    constant_name=DlnirspBudName.arm_position_mm.value,
                    metadata_key=DlnirspMetadataKey.arm_position_mm,
                    ip_task_types=[TaskName.solar_gain.value, TaskName.observe.value],
                    tolerance=0.01,
                    task_type_parsing_function=parse_header_ip_task_with_gains,
                ),
                TaskUniqueBud(
                    constant_name=DlnirspBudName.grating_constant_inverse_mm.value,
                    metadata_key=DlnirspMetadataKey.grating_constant_inverse_mm,
                    ip_task_types=[TaskName.solar_gain.value, TaskName.observe.value],
                    task_type_parsing_function=parse_header_ip_task_with_gains,
                ),
                TaskNearFloatBud(
                    constant_name=DlnirspBudName.grating_position_deg.value,
                    metadata_key=DlnirspMetadataKey.grating_position_deg,
                    ip_task_types=[TaskName.solar_gain.value, TaskName.observe.value],
                    tolerance=0.01,
                    task_type_parsing_function=parse_header_ip_task_with_gains,
                ),
                TaskDateEndBud(
                    constant_name=BudName.dark_date_end,
                    ip_task_types=TaskName.dark.value,
                    task_type_parsing_function=parse_header_ip_task_with_gains,
                ),
                TaskDateEndBud(
                    constant_name=BudName.polcal_date_end,
                    ip_task_types=TaskName.polcal.value,
                    task_type_parsing_function=parse_header_ip_task_with_gains,
                ),
                TaskDateEndBud(
                    constant_name=BudName.solar_gain_date_end,
                    ip_task_types=TaskName.solar_gain.value,
                    task_type_parsing_function=parse_header_ip_task_with_gains,
                ),
                TaskTimeLookupBud(
                    constant_name=DlnirspBudName.dark_readout_times_per_dark_exposure_time.value,
                    key_metadata_key=MetadataKey.fpa_exposure_time_ms,
                    value_metadata_key=MetadataKey.sensor_readout_exposure_time_ms,
                    ip_task_types=TaskName.dark,
                ),
            ]
            + self.mosaic_buds
        )

    @property
    def tag_flowers(self) -> list[S]:
        """Add DLNIRSP specific tags to common tags."""
        return (
            default_tag_flower_factory()
            + [
                DlnirspTaskTypeFlower(),
                PolcalTaskFlower(),
                SingleValueSingleKeyFlower(
                    tag_stem_name=DlnirspStemName.arm_id.value,
                    metadata_key=DlnirspMetadataKey.arm_id,
                ),
                ExposureTimeFlower(),
                SingleValueSingleKeyFlower(
                    tag_stem_name=DlnirspStemName.modstate.value,
                    metadata_key=DlnirspMetadataKey.modulator_state,
                ),
                SingleValueSingleKeyFlower(
                    tag_stem_name=DlnirspStemName.mosaic_num.value,
                    metadata_key=DlnirspMetadataKey.mosaic_num,
                ),
                SingleValueSingleKeyFlower(
                    tag_stem_name=DlnirspStemName.dither_step.value,
                    metadata_key=DlnirspMetadataKey.dither_step,
                ),
                CSStepFlower(max_cs_step_time_sec=self.parameters.max_cs_step_time_sec),
            ]
            + self.mosaic_flowers
        )
