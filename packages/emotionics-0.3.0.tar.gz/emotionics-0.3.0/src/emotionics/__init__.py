# src/emotionics/__init__.py
from .core import activate, estimate, gyo

__all__ = ["activate", "estimate", "gyo"]
__version__ = "0.2.1"