# src/emotionics/gyo.py
from __future__ import annotations

import json
from typing import Any, Dict, Optional

from .schema import GyoResult
from .errors import ProviderResponseError
from .full import analyze_full  # 表層分析のために内部で呼び出す

VERSION = "0.2.1"

# === Circuit Theory Mappers (Emotionics 3.0) ===
PLATFORM_CIRCUIT_MAP = {
    "twitter": "N:N (Open Network)", "x": "N:N (Open Network)", "sns": "N:N (Open Network)",
    "press_conference": "1:N (Broadcast)", "speech": "1:N (Broadcast)",
    "dm": "1:1 (Private)", "meeting": "1:1 (Private)"
}

TARGET_GRADIENT_MAP = {
    "upward": "Upward (Power Disadvantage)",
    "boss": "Upward (Power Disadvantage)",
    "downward": "Downward (Power Advantage)",
    "public": "Downward (Power Advantage)",
    "symmetrical": "Symmetrical (Equal)",
    "anyone": "N:N Broadcasting (Seeking mass consensus)",
    "supporter": "Ingroup (Echo chamber reinforcement)"
}

INTENT_MAP = {
    "defense": "Defense / Excuse",
    "attack": "Attack / Appeal",
    "neutral": "Information Transfer",
    "collect attention": "Status Seeking / Social Validation",
    "empathy": "Bonding / Shared Vulnerability"
}

def analyze_gyo(
    text: str,
    subject: str,
    platform: str,
    target: str,
    intent: str,
    provider: Optional[object] = None,
    model: str = "auto",
    **kwargs: Any,
) -> Dict[str, Any]:
    
    if provider is None:
        return {"mode": "gyo", "status": "no_provider"}

    # 1. 入力変数の正規化（ファジーな文字列をアーキテクチャの変数へ）
    p_norm = platform.lower().strip()
    t_norm = target.lower().strip()
    i_norm = intent.lower().strip()
    
    circuit_type = PLATFORM_CIRCUIT_MAP.get(p_norm, f"Unknown ({p_norm})")
    power_gradient = TARGET_GRADIENT_MAP.get(t_norm, f"Unknown ({t_norm})")
    intent_type = INTENT_MAP.get(i_norm, f"Unknown ({i_norm})")

    # 2. 表層分析（Surface Layer）の実行
    # 一般大衆がどう受け取るかを estimate() と同じロジックで取得
    surface_result = analyze_full(text=text, provider=provider, model=model, **kwargs)
    # ここでは一番スコアの高い感情をピックアップ（簡略化）
    top_surface_emotion = surface_result.get("candidate_emotions", [{"label": "Unknown"}])[0]["label"]

    # 3. 深層・差分分析（Deep & Delta Layer）のためのプロンプト
    prompt_template = """
You are the Emotionics 2.0/3.0 'GYO' (Backtracking & Observation) Engine.
Analyze the following text based on the provided context to deduce the TRUE hidden emotion (O) and the acting strategy.

[INPUT]
Text: "{text}"
Subject: "{subject}"
Platform Circuit: {circuit_type}
Target Gradient: {power_gradient}
Intent/Stance: {intent_type}

[SURFACE OBSERVATION]
General public perceives this as: {surface_emotion}

[INSTRUCTIONS]
1. Subject Profiling: Analyze the provided `Subject` and `Platform Circuit` to determine the subject's implicit state:
   - Power Level: High (Authority/Leader) or Low (Citizen/Anonymous).
   - Stake/Risk: High Stake (Has real-world reputation/status to lose) or Zero Stake (Anonymous, safe zone, no personal risk).
   *Rule:* Anonymous users on N:N platforms usually have Zero Stake. Their "Anger" is often Fake/Entertainment, not Fear-driven defense.
2. Determine the 'Feel/Feign x Real/Fake' quadrant for the hidden emotion.
   - Upward/Defense intents strongly correlate with 'Feign'.
   - N:N Open Networks correlate with 'Fake' (social contagion).
3. Use Backtracking: If surface is Anger/Pride but intent is Defense, the True Emotion is likely Fear/Shame.
4. Output ONLY valid JSON matching the schema below. Do not include markdown formatting.

[OUTPUT SCHEMA]
{{
    "deep_layer": {{
        "method": "emotionics.gyo()",
        "true_emotion_O": "...",
        "actual_quadrant": "..."
    }},
    "delta_analysis": {{
        "gap": "...",
        "mechanism": "..."
    }}
}}
"""
    prompt = prompt_template.format(
        text=text,
        subject=subject,
        circuit_type=circuit_type,
        power_gradient=power_gradient,
        intent_type=intent_type,
        surface_emotion=top_surface_emotion
    )

    raw = provider.generate(prompt=prompt, model=model, **kwargs)

    # 4. 結果のパースと結合
    try:
        # Markdownのコードブロックが含まれている場合のクリーニング
        clean_raw = raw.strip()
        if clean_raw.startswith("```json"):
            clean_raw = clean_raw[7:-3].strip()
        
        deep_data = json.loads(clean_raw)
        
        res: GyoResult = {
            "mode": "gyo",
            "version": VERSION,
            "surface_layer": {
                "method": "emotionics.estimate(mode='full')",
                "perceived_emotion": top_surface_emotion,
                "perceived_quadrant": "Feel Real Emotion (Assumed by public)"
            },
            "deep_layer": deep_data.get("deep_layer", {}),
            "delta_analysis": deep_data.get("delta_analysis", {})
        }
        return res
        
    except Exception as e:
        raise ProviderResponseError(
            "LLM response parse failed in gyo mode.",
            details={"raw": raw[:1000]},
            cause=e
        )