"""
Unit tests for UID extraction from NATS message subjects.

Reproduces the bug from logs where JetStream delivery via an internal
inbox subject caused the UID to be incorrectly sliced:

  msg.subject = "speech-to-text.audio-transcriptions.57f4d8b9b-976x5.2e72ccb6-ad80-4746-acd2-3d7051c201a2"
  Old (broken): subject from _INBOX prefix → UID = "anscriptions.57f4d8b9b-976x5.…"
  New (fixed):  subject from queue+link     → UID = "57f4d8b9b-976x5.2e72ccb6-…"
"""
import pytest


def extract_uid(subject_prefix: str, msg_subject: str) -> str:
    """Replicates the UID extraction logic from listener.get_data."""
    l_sub = len(subject_prefix) + 1
    return msg_subject[l_sub:]


def resolve_subject(sub_subject: str, queue: str, link: str) -> tuple[str, bool]:
    """Replicates the subject resolution logic from listener.wait_msg."""
    if sub_subject.startswith("nc."):
        return sub_subject.replace(".*.*", ""), False
    else:
        return queue + "." + link, True


QUEUE = "speech-to-text"
LINK = "audio-transcriptions"
EXPECTED_UID = "57f4d8b9b-976x5.2e72ccb6-ad80-4746-acd2-3d7051c201a2"
MSG_SUBJECT = f"{QUEUE}.{LINK}.{EXPECTED_UID}"


class TestUIDExtraction:

    def test_jetstream_old_nats_inbox_prefix(self):
        """JetStream with old NATS _INBOX. delivery subject."""
        sub_subject = "_INBOX.M5XwKPcA5HuNQX8185x724"
        subject, is_js = resolve_subject(sub_subject, QUEUE, LINK)
        assert is_js is True
        assert subject == f"{QUEUE}.{LINK}"
        uid = extract_uid(subject, MSG_SUBJECT)
        assert uid == EXPECTED_UID

    def test_jetstream_new_nats_delivery_subject(self):
        """JetStream with newer NATS internal delivery subject (no _INBOX. prefix)."""
        sub_subject = "some-other-internal-id.abc123"
        subject, is_js = resolve_subject(sub_subject, QUEUE, LINK)
        assert is_js is True
        assert subject == f"{QUEUE}.{LINK}"
        uid = extract_uid(subject, MSG_SUBJECT)
        assert uid == EXPECTED_UID

    def test_core_nats(self):
        """Core NATS with nc. prefix and wildcard subject."""
        sub_subject = f"nc.{QUEUE}.{LINK}.*.*"
        subject, is_js = resolve_subject(sub_subject, QUEUE, LINK)
        assert is_js is False
        assert subject == f"nc.{QUEUE}.{LINK}"
        nc_msg_subject = f"nc.{MSG_SUBJECT}"
        uid = extract_uid(subject, nc_msg_subject)
        assert uid == EXPECTED_UID

    def test_old_code_was_broken(self):
        """Demonstrates the old _INBOX.-based code produced a wrong UID."""
        sub_subject = "_INBOX.M5XwKPcA5HuNQX8185x724"
        # Old logic: subject = sub_subject[7:]
        old_subject = sub_subject[7:]
        uid = extract_uid(old_subject, MSG_SUBJECT)
        assert uid != EXPECTED_UID  # was broken
        assert "anscriptions" in uid  # the observed bug
