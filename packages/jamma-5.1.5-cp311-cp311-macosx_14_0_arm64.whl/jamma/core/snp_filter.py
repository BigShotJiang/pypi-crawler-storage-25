"""Shared SNP filtering utilities for JAMMA.

Provides reusable functions for computing per-SNP statistics and
applying quality control filters (MAF, missing rate, monomorphism, HWE).
Used by both kinship computation and LMM association runners.
"""

import math

import numpy as np
from loguru import logger

from jamma.jlinalg import compute_snp_stats_chunk

_SNP_STATS_CHUNK_SIZE = 10_000

# Chi-squared SF with df=1: P(X > x) = erfc(sqrt(x/2))
# Uses np.vectorize(math.erfc) since numpy has no built-in erfc.
# HWE runs once per GWAS (not per-chunk), so vectorize overhead is negligible.
_erfc_vec = np.vectorize(math.erfc, otypes=[np.float64])


def apply_snp_list_mask(
    snp_mask: np.ndarray, indices: np.ndarray, n_snps: int, label: str
) -> None:
    """Apply SNP list restriction to mask in-place with bounds validation.

    Args:
        snp_mask: Boolean mask to modify in-place (AND with list mask).
        indices: Array of SNP indices to include.
        n_snps: Total number of SNPs (for bounds checking).
        label: Human-readable label for log messages (e.g. "Kinship SNP list").
    """
    if len(indices) > 0 and indices.max() >= n_snps:
        raise ValueError(
            f"{label} index {indices.max()} out of range for {n_snps} SNPs"
        )
    if len(indices) == 0:
        snp_mask[:] = False
        logger.info(f"{label}: restricting to 0 requested SNPs (all filtered)")
        return

    # indices is sorted (guaranteed by resolve_snp_list_to_indices).
    # Use searchsorted to test membership without allocating an O(n_snps) boolean array.
    active = np.where(snp_mask)[0]
    pos = np.searchsorted(indices, active)
    pos = np.clip(pos, 0, len(indices) - 1)
    in_list = indices[pos] == active
    # Zero out positions that are True in snp_mask but not in indices
    snp_mask[active[~in_list]] = False
    retained = int(np.sum(snp_mask))
    logger.info(
        f"{label}: restricting to {len(indices)} requested SNPs "
        f"({retained} retained after intersection)"
    )


def compute_snp_stats(
    genotypes: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute per-SNP mean, missing count, and variance.

    Handles all-NaN columns gracefully (returns 0.0 for mean and variance).
    Delegates to compute_snp_stats_chunk (C kernel with NumPy fallback)
    for numerical consistency with streaming runners.

    Args:
        genotypes: Genotype matrix (n_samples, n_snps) with NaN for missing.

    Returns:
        Tuple of (col_means, miss_counts, col_vars) where each is a
        1-D array of length n_snps.
    """
    n_snps = genotypes.shape[1]
    col_means = np.zeros(n_snps, dtype=np.float64)
    miss_counts = np.zeros(n_snps, dtype=np.intp)
    col_vars = np.zeros(n_snps, dtype=np.float64)

    # Large in-memory matrices are processed in bounded SNP slices to avoid
    # allocating a full contiguous copy of the genotype matrix at once.
    if n_snps <= _SNP_STATS_CHUNK_SIZE:
        data = np.ascontiguousarray(genotypes)
        compute_snp_stats_chunk(data, col_means, miss_counts, col_vars)
        return col_means, miss_counts, col_vars

    for start in range(0, n_snps, _SNP_STATS_CHUNK_SIZE):
        end = min(start + _SNP_STATS_CHUNK_SIZE, n_snps)
        chunk = np.ascontiguousarray(genotypes[:, start:end])
        compute_snp_stats_chunk(
            chunk,
            col_means[start:end],
            miss_counts[start:end],
            col_vars[start:end],
        )

    return col_means, miss_counts, col_vars


def compute_snp_filter_mask(
    col_means: np.ndarray,
    miss_counts: np.ndarray,
    col_vars: np.ndarray,
    n_samples: int,
    maf_threshold: float,
    miss_threshold: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute boolean mask for SNPs passing QC filters.

    Applies three filters matching GEMMA behavior:
    1. Minor allele frequency >= maf_threshold
    2. Missing rate <= miss_threshold
    3. Polymorphic (variance > 0)

    Args:
        col_means: Per-SNP genotype means from compute_snp_stats.
        miss_counts: Per-SNP missing counts from compute_snp_stats.
        col_vars: Per-SNP genotype variances from compute_snp_stats.
        n_samples: Total sample count for computing missing rates.
        maf_threshold: Minimum MAF for inclusion.
        miss_threshold: Maximum missing rate for inclusion.

    Returns:
        Tuple of (snp_mask, allele_freqs, mafs) where snp_mask is a
        boolean array indicating which SNPs pass all filters.
    """
    miss_rates = miss_counts / n_samples
    allele_freqs = col_means / 2.0
    mafs = np.minimum(allele_freqs, 1.0 - allele_freqs)
    is_polymorphic = col_vars > 0
    snp_mask = (mafs >= maf_threshold) & (miss_rates <= miss_threshold) & is_polymorphic
    return snp_mask, allele_freqs, mafs


def compute_hwe_pvalues(
    n_aa: np.ndarray, n_ab: np.ndarray, n_bb: np.ndarray
) -> np.ndarray:
    """Compute Hardy-Weinberg equilibrium chi-squared p-values.

    Computes the chi-squared goodness-of-fit test for HWE for each SNP.
    Under HWE, genotype frequencies are p^2 (AA), 2pq (AB), q^2 (BB)
    where p = freq(A), q = 1-p.

    This uses the chi-squared approximation (df=1). Note this differs
    from GEMMA's exact test (Wigginton et al. 2005) but is standard
    for large-sample QC filtering.

    Degenerate SNPs (all same genotype, zero total, or monomorphic)
    return p-value = 1.0 by convention (they pass HWE trivially).

    Args:
        n_aa: Count of homozygous reference genotypes per SNP.
        n_ab: Count of heterozygous genotypes per SNP.
        n_bb: Count of homozygous alternate genotypes per SNP.

    Returns:
        Array of p-values, one per SNP. Values >= threshold pass HWE.
    """
    n_aa = np.asarray(n_aa, dtype=np.float64)
    n_ab = np.asarray(n_ab, dtype=np.float64)
    n_bb = np.asarray(n_bb, dtype=np.float64)

    n = n_aa + n_ab + n_bb

    with np.errstate(invalid="ignore", divide="ignore"):
        p = (2 * n_aa + n_ab) / (2 * n)
        q = 1.0 - p

        e_aa = n * p**2
        e_ab = 2 * n * p * q
        e_bb = n * q**2

        chi_sq = (
            (n_aa - e_aa) ** 2 / e_aa
            + (n_ab - e_ab) ** 2 / e_ab
            + (n_bb - e_bb) ** 2 / e_bb
        )

    # Degenerate SNPs (monomorphic, zero count) produce NaN chi_sq.
    # Replace with 0.0 so they get p-value = 1.0 (pass HWE by convention).
    chi_sq = np.where(np.isnan(chi_sq), 0.0, chi_sq)

    # Chi-squared SF with df=1: P(X > x) = erfc(sqrt(x/2))
    pvalues = _erfc_vec(np.sqrt(chi_sq / 2.0))
    return pvalues
