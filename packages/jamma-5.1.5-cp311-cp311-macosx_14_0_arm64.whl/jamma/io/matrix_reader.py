"""Parallel matrix text reader for large matrices.

Provides read_matrix_parallel() which uses multiprocessing to parse matrix
rows across CPU cores. At 50k x 50k (2.5B floats), np.loadtxt is single-threaded
even in numpy 2.x (C-based tokenizer, but one core). Parallel parsing brings
cold reads from ~4 minutes to ~50 seconds on a 48-core machine.

Uses file-backed numpy.memmap for worker IPC instead of shared memory to avoid
SIGBUS crashes when Docker's /dev/shm is capped at 64 MB (cpython#114390).

Workers open the source text file at pre-computed byte offsets, seek to the chunk
start, and parse via np.loadtxt(f, max_rows=N) directly on the file handle. This
streams line-by-line internally instead of buffering the entire byte range in RAM.
The memmap-to-dense final copy uses block-by-block transfer (1024 rows at a time)
so that only a small window of memmap pages is faulted into physical memory at a
time, significantly reducing peak RSS compared to np.array(mm) which faults the
entire memmap at once. When copy=False, skips the memmap-to-dense copy and returns
the read-only memmap directly, with cleanup deferred to garbage collection via
weakref.finalize.

Mirrors the conventions in matrix_writer.py: spawn context, file-backed memmap,
top-level picklable functions, temp dir on same filesystem as input.
"""

import multiprocessing as mp
import os
import tempfile
import weakref
from pathlib import Path

import numpy as np
from loguru import logger

# Cap worker count — beyond this, disk I/O contention and memory pressure
# outweigh the benefit of additional parse parallelism.
_MAX_READERS = 32


def _parse_chunk_to_memmap(args: tuple) -> None:
    """Parse a byte range of a text file and write parsed rows into a memmap.

    Must be a top-level function for pickling with spawn context.

    Uses np.loadtxt with max_rows directly on the file handle instead of
    buffering the entire byte range via f.read(). This streams line-by-line
    internally, keeping per-worker memory bounded.

    Args:
        args: Tuple of (txt_path, memmap_path, shape, dtype_str,
              start_byte, end_byte, start_row, n_rows, delimiter).
    """
    (
        txt_path,
        memmap_path,
        shape,
        dtype_str,
        start_byte,
        end_byte,
        start_row,
        n_rows,
        delimiter,
    ) = args

    try:
        with open(txt_path, "rb") as f:
            f.seek(start_byte)
            chunk = np.loadtxt(
                f, dtype=np.dtype(dtype_str), delimiter=delimiter, max_rows=n_rows
            )
        chunk = np.atleast_2d(chunk)
        if chunk.shape[0] != n_rows:
            raise RuntimeError(
                f"Row count mismatch in chunk at byte offset {start_byte}: "
                f"expected {n_rows} data rows, parsed {chunk.shape[0]}. "
                f"File may have been modified during read."
            )

        mm = np.memmap(memmap_path, dtype=np.dtype(dtype_str), mode="r+", shape=shape)
        mm[start_row : start_row + chunk.shape[0], :] = chunk
        del mm  # release memmap reference
    except MemoryError:
        raise  # Let parent process handle OOM directly
    except Exception as e:
        raise RuntimeError(
            f"_parse_chunk_to_memmap failed at bytes {start_byte}-{end_byte}, "
            f"row offset {start_row}: {e}"
        ) from e


def _is_data_line(line: bytes) -> bool:
    """Return True if line is a non-blank, non-comment data line.

    Matches np.loadtxt behaviour: blank lines and lines starting with '#'
    (after stripping leading whitespace) are skipped.
    """
    stripped = line.lstrip()
    return len(stripped) > 0 and not stripped.startswith(b"#")


def _count_data_lines_between(f, start: int, end: int) -> int:
    """Count data lines between byte offsets using readline iteration.

    Uses f.readline() instead of ``for line in f`` because Python's file
    iterator uses an internal read-ahead buffer that makes f.tell()
    unreliable (returns buffer position, not line position).

    Avoids materializing the entire byte range in memory — at 200GB files
    with 4 workers, each chunk is ~50GB which would OOM before parsing.
    """
    f.seek(start)
    count = 0
    while True:
        line = f.readline()
        if not line or f.tell() > end:
            break
        if _is_data_line(line):
            count += 1
    return count


def _scan_chunk_boundaries(
    path: Path, n_workers: int, delimiter: str | None = None
) -> tuple[int, int, list[tuple[int, int, int, int]]]:
    """Scan a text file to find byte offsets aligned to newline boundaries.

    Two-pass scan: first pass counts total data rows and detects column count;
    second pass seeks to approximate boundaries and counts per-chunk rows via
    bounded line-by-line iteration.

    Args:
        path: Input text file path.
        n_workers: Number of parallel chunks to create.
        delimiter: Column separator (None = whitespace).

    Returns:
        Tuple of (n_rows, n_cols, chunks) where each chunk is
        (start_byte, end_byte, start_row, n_rows_in_chunk).
    """
    file_size = path.stat().st_size
    if file_size == 0:
        raise ValueError(f"Matrix file is empty: {path}")

    # First pass: find first data line (for column count) and count all data rows.
    first_line = b""
    n_rows = 0
    with open(path, "rb") as f:
        for raw_line in f:
            if _is_data_line(raw_line):
                if not first_line:
                    first_line = raw_line
                n_rows += 1

    if n_rows == 0 or not first_line:
        raise ValueError(f"Matrix file has no data rows: {path}")

    if delimiter is not None:
        n_cols = len(first_line.split(delimiter.encode()))
    else:
        n_cols = len(first_line.split())

    # Compute byte boundaries aligned to newlines
    target_chunk_size = file_size // n_workers
    chunks: list[tuple[int, int, int, int]] = []
    current_row = 0

    with open(path, "rb") as f:
        chunk_start = 0
        for _i in range(n_workers - 1):
            # Seek to approximate split point and find next newline
            target = chunk_start + target_chunk_size
            if target >= file_size:
                break
            f.seek(target)
            # Read ahead to find newline boundary
            f.readline()  # advance past next newline boundary
            chunk_end = f.tell()

            # Count data rows in this chunk via bounded line iteration
            # (no large byte buffer allocation)
            rows_in_chunk = _count_data_lines_between(f, chunk_start, chunk_end)

            if rows_in_chunk > 0:
                chunks.append((chunk_start, chunk_end, current_row, rows_in_chunk))
                current_row += rows_in_chunk
                chunk_start = chunk_end

        # Final chunk: everything remaining
        if chunk_start < file_size:
            rows_in_last = n_rows - current_row
            chunks.append((chunk_start, file_size, current_row, rows_in_last))

    return n_rows, n_cols, chunks


def _create_temp_dir(input_path: Path) -> str:
    """Create temp dir on the same filesystem as the input file.

    Tries the input's parent directory first, falls back to the system
    default (TMPDIR / /tmp) if that fails.
    """
    input_dir = input_path.parent
    try:
        return tempfile.mkdtemp(prefix=".jamma_mread_", dir=input_dir)
    except OSError as e:
        logger.warning(
            f"Cannot create temp dir in {input_dir} ({e}), "
            "falling back to system tmpdir. "
            "If /tmp is RAM-backed (tmpfs), this may increase memory "
            "usage significantly for large matrices."
        )
        return tempfile.mkdtemp(prefix="jamma_mread_")


def _cleanup_temp_memmap(tmp_dir: str, memmap_path: str) -> None:
    """Clean up temp memmap file and its parent directory.

    Called from weakref.finalize (GC) and from the finally block on the
    copy=True path. Logger calls are guarded because finalizers can run
    during interpreter shutdown when loguru may already be torn down.
    """
    try:
        os.unlink(memmap_path)
    except FileNotFoundError:
        pass
    except OSError as e:
        try:
            logger.warning(f"Failed to clean up temp memmap {memmap_path}: {e}")
        except Exception:
            pass  # Logger may be torn down during interpreter shutdown
    try:
        os.rmdir(tmp_dir)
    except FileNotFoundError:
        pass
    except OSError as e:
        try:
            logger.warning(f"Could not remove temp dir {tmp_dir}: {e}")
        except Exception:
            pass


def read_matrix_parallel(
    path: Path | str,
    delimiter: str | None = None,
    n_workers: int | None = None,
    min_rows_for_parallel: int = 500,
    copy: bool = True,
) -> np.ndarray:
    """Read a 2D matrix from a text file, optionally using parallel parsing.

    For matrices with fewer than min_rows_for_parallel rows, falls back to
    np.loadtxt. For larger matrices, distributes row parsing across multiple
    processes for significant speedup.

    Args:
        path: Input text file path.
        delimiter: Column separator (None = whitespace, matching np.loadtxt default).
        n_workers: Number of worker processes (default: min(cpu_count, 32)).
        min_rows_for_parallel: Row threshold for parallel path (default 500).
        copy: If True (default), returns a dense C-contiguous float64 array
            (existing behavior). If False, returns a read-only ``np.memmap``
            backed by a temp file; the temp file is removed automatically when
            the returned memmap is garbage collected via ``weakref.finalize``.
            copy=False only applies to the parallel path; the small-matrix
            np.loadtxt fallback always returns a dense array regardless.

    Returns:
        2D float64 numpy array (C-contiguous) when copy=True, or a read-only
        np.memmap when copy=False on the parallel path.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Matrix file not found: {path}")

    file_size = path.stat().st_size
    if file_size == 0:
        raise ValueError(f"Matrix file is empty: {path}")

    # Quick row count to decide parallel vs serial.
    # Read the first data line to get bytes-per-line, then extrapolate.
    # Previous 64KB sample approach failed for wide matrices (75k+ columns
    # produce ~1.5MB lines, so no newline appeared in the sample).
    # Skip comment lines (starting with '#') to avoid inflated line length.
    with open(path, "rb") as f:
        first_line = f.readline()
        if not first_line:
            raise ValueError(f"Matrix file is empty: {path}")
        while first_line.startswith(b"#"):
            first_line = f.readline()
            if not first_line:
                raise ValueError(f"Matrix file contains only comments: {path}")
        bytes_per_line = len(first_line)
    n_rows_approx = max(1, file_size // bytes_per_line)

    if n_rows_approx < min_rows_for_parallel:
        if not copy:
            logger.debug(
                f"copy=False ignored for {path.name}: below parallel threshold "
                f"({n_rows_approx} < {min_rows_for_parallel} rows), "
                f"returning dense array"
            )
        logger.info(f"Reading {path.name} via np.loadtxt (small matrix)")
        return np.atleast_2d(np.loadtxt(path, dtype=np.float64, delimiter=delimiter))

    if n_workers is None:
        n_workers = min(os.cpu_count() or 1, _MAX_READERS)
    n_workers = max(1, n_workers)

    logger.info(f"Reading {path.name} via parallel parse ({n_workers} workers)")

    n_rows, n_cols, chunks = _scan_chunk_boundaries(path, n_workers, delimiter)
    shape = (n_rows, n_cols)

    logger.debug(f"Matrix dimensions: {n_rows}x{n_cols}, {len(chunks)} chunks")

    tmp_dir = _create_temp_dir(path)
    memmap_path = os.path.join(tmp_dir, "matrix.dat")

    # When copy=False, cleanup happens via weakref.finalize on the returned
    # memmap instead of the finally block. This flag controls which path runs.
    cleanup_in_finally = True

    try:
        # Create zero-filled memmap for workers to write into
        mm = np.memmap(memmap_path, dtype=np.float64, mode="w+", shape=shape)
        del mm  # release memmap reference; workers reopen in r+ mode

        dtype_str = str(np.dtype(np.float64))
        chunk_args = [
            (str(path), memmap_path, shape, dtype_str, sb, eb, sr, nr, delimiter)
            for sb, eb, sr, nr in chunks
        ]

        ctx = mp.get_context("spawn")
        with ctx.Pool(processes=n_workers) as pool:
            try:
                for _ in pool.imap(_parse_chunk_to_memmap, chunk_args):
                    pass
            except BaseException as e:
                pool.terminate()
                pool.join()
                if not isinstance(e, (KeyboardInterrupt, SystemExit)):
                    logger.opt(exception=e).error(f"Pool error reading {path}: {e}")
                raise

        if not copy:
            # Return a read-only memmap; cleanup deferred to GC via weakref.finalize.
            mm = np.memmap(memmap_path, dtype=np.float64, mode="r", shape=shape)
            weakref.finalize(mm, _cleanup_temp_memmap, tmp_dir, memmap_path)
            cleanup_in_finally = False
            return mm

        # Block-by-block copy: dense output is pre-allocated at full size,
        # but only ~1024 rows of memmap pages are faulted at a time.  For
        # matrices larger than physical memory this significantly reduces
        # peak RSS vs np.array(mm) which faults the entire memmap.
        result = np.empty(shape, dtype=np.float64)
        mm = np.memmap(memmap_path, dtype=np.float64, mode="r", shape=shape)
        block_rows = min(1024, shape[0])
        for start in range(0, shape[0], block_rows):
            end = min(start + block_rows, shape[0])
            result[start:end] = mm[start:end]
        del mm

        return result
    finally:
        if cleanup_in_finally:
            _cleanup_temp_memmap(tmp_dir, memmap_path)
