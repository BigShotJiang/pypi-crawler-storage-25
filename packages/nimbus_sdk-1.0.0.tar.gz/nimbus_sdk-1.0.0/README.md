# nimbus-sdk

Official Python SDK for [Nimbus](https://get-nimbus.com) -- autonomous software engineering.

## Install

```bash
pip install nimbus-sdk
```

## Usage

```python
from nimbus_sdk import NimbusClient

client = NimbusClient(api_key="nk_...")

# Run a task
task = client.tasks.run(
    description="add rate limiting to /api/upload",
    repo="acme/api"
)
task.wait()
print(task.pr_url)

# Run a built-in agent
task = client.agents.run("security-audit", repo="acme/api")
task.wait()

# Search your codebase
results = client.search.query("where is rate limiting handled", repo="acme/api")
for r in results:
    print(r.path, r.score)

# List available agents
for agent in client.agents.list(category="security"):
    print(agent.name, agent.description)
```

## Async support

```python
import asyncio
from nimbus_sdk import NimbusClient

async def main():
    async with NimbusClient(api_key="nk_...") as client:
        task = client.tasks.run("add tests for auth module", repo="acme/api")
        await task.async_wait()
        print(task.pr_url)

asyncio.run(main())
```
