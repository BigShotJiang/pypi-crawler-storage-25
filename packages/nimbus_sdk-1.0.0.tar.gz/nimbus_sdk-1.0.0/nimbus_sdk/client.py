import httpx
import asyncio
import time
from typing import Optional
from .models import Task, Agent, Skill, SearchResult

DEFAULT_BASE_URL = "https://api.get-nimbus.com"
DEFAULT_TIMEOUT = 30.0
POLL_INTERVAL = 5


class TaskHandle:
    """Represents a submitted task. Call .wait() to block until completion."""

    def __init__(self, task: Task, client: "NimbusClient"):
        self._task = task
        self._client = client

    @property
    def id(self) -> str:
        return self._task.id

    @property
    def pr_url(self) -> Optional[str]:
        return self._task.pr_url

    @property
    def phase(self) -> str:
        return self._task.phase

    def wait(self, timeout: int = 600, poll_interval: int = POLL_INTERVAL) -> "TaskHandle":
        start = time.time()
        while True:
            if time.time() - start > timeout:
                raise TimeoutError(f"Task {self.id} timed out after {timeout}s")

            task = self._client.tasks.get(self.id)
            self._task = task

            if task.phase in ("completed", "failed"):
                return self
            if task.pr_url:
                return self
            if task.phase == "awaiting_approval":
                self._client.tasks.approve(self.id)

            time.sleep(poll_interval)

    async def async_wait(self, timeout: int = 600) -> "TaskHandle":
        start = time.time()
        while True:
            if time.time() - start > timeout:
                raise TimeoutError(f"Task {self.id} timed out after {timeout}s")

            task = await self._client.tasks.async_get(self.id)
            self._task = task

            if task.phase in ("completed", "failed"):
                return self
            if task.pr_url:
                return self
            if task.phase == "awaiting_approval":
                await self._client.tasks.async_approve(self.id)

            await asyncio.sleep(POLL_INTERVAL)

    def __repr__(self):
        return f"<TaskHandle id={self.id} phase={self.phase} pr_url={self.pr_url}>"


class TasksResource:
    def __init__(self, client: "NimbusClient"):
        self._client = client

    def run(
        self,
        description: str,
        repo: str,
        workspace: Optional[str] = None,
        skill: Optional[str] = None,
    ) -> TaskHandle:
        ws_id, repo_id = self._client._ensure_repo(repo, workspace)
        payload: dict = {
            "workspace_id": ws_id,
            "repo_id": repo_id,
            "description": description,
        }
        if skill:
            payload["skill"] = skill
        data = self._client._post("/tasks/", payload)
        return TaskHandle(Task.from_dict(data), self._client)

    def get(self, task_id: str) -> Task:
        data = self._client._get(f"/tasks/{task_id}/")
        return Task.from_dict(data)

    async def async_get(self, task_id: str) -> Task:
        data = await self._client._async_get(f"/tasks/{task_id}/")
        return Task.from_dict(data)

    def approve(self, task_id: str) -> dict:
        return self._client._post(f"/tasks/{task_id}/approve", {})

    async def async_approve(self, task_id: str) -> dict:
        return await self._client._async_post(f"/tasks/{task_id}/approve", {})

    def list(self, workspace_id: Optional[str] = None) -> list[Task]:
        params = {}
        if workspace_id:
            params["workspace_id"] = workspace_id
        data = self._client._get("/tasks/", params=params)
        return [Task.from_dict(d) for d in (data if isinstance(data, list) else [])]


class AgentsResource:
    def __init__(self, client: "NimbusClient"):
        self._client = client

    def list(self, category: Optional[str] = None) -> list[Agent]:
        params = {}
        if category:
            params["category"] = category
        data = self._client._get("/agents/", params=params)
        return [Agent(
            name=d.get("name", ""),
            category=d.get("category", ""),
            description=d.get("description", ""),
            estimated_prs=d.get("estimated_prs", ""),
        ) for d in (data if isinstance(data, list) else [])]

    def run(self, name: str, repo: str, workspace: Optional[str] = None, dry_run: bool = False) -> TaskHandle:
        ws_id, repo_id = self._client._ensure_repo(repo, workspace)
        data = self._client._post(f"/agents/{name}/run", {
            "workspace_id": ws_id,
            "repo_id": repo_id,
            "dry_run": dry_run,
        })
        return TaskHandle(Task.from_dict(data), self._client)


class SkillsResource:
    def __init__(self, client: "NimbusClient"):
        self._client = client

    def list(self) -> list[Skill]:
        data = self._client._get("/skills/")
        return [Skill(name=d.get("name", ""), description=d.get("description", ""), prompt=d.get("prompt")) for d in (data if isinstance(data, list) else [])]

    def search(self, query: str) -> list[Skill]:
        data = self._client._get("/marketplace/skills", params={"q": query})
        return [Skill(name=d.get("name", ""), description=d.get("description", ""), tags=d.get("tags")) for d in (data if isinstance(data, list) else [])]

    def install(self, name: str) -> Skill:
        data = self._client._post(f"/marketplace/skills/{name}/install", {})
        return Skill(name=data.get("name", ""), description=data.get("description", ""), prompt=data.get("prompt"))


class SearchResource:
    def __init__(self, client: "NimbusClient"):
        self._client = client

    def query(self, q: str, repo: str, workspace: Optional[str] = None, top_k: int = 8) -> list[SearchResult]:
        ws_id, repo_id = self._client._ensure_repo(repo, workspace)
        data = self._client._get("/search", params={"q": q, "repo_id": repo_id, "top_k": top_k})
        results = data if isinstance(data, list) else data.get("results", [])
        return [SearchResult(
            path=r.get("path", ""),
            score=r.get("score", 0.0),
            summary=r.get("summary", ""),
        ) for r in results]


class NimbusClient:
    """
    Official Python SDK for the Nimbus API.

    Usage:
        from nimbus_sdk import NimbusClient
        client = NimbusClient(api_key="nk_...")
        task = client.tasks.run("add rate limiting", repo="acme/api")
        task.wait()
        print(task.pr_url)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            timeout=timeout,
        )
        self._async_http = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-API-Key": api_key, "Content-Type": "application/json"},
            timeout=timeout,
        )
        self._workspace_cache: dict[str, str] = {}
        self._repo_cache: dict[str, str] = {}

        self.tasks = TasksResource(self)
        self.agents = AgentsResource(self)
        self.skills = SkillsResource(self)
        self.search = SearchResource(self)

    def _ensure_repo(self, repo: str, workspace: Optional[str] = None) -> tuple[str, str]:
        ws_name = workspace or repo
        if ws_name not in self._workspace_cache:
            data = self._post("/workspaces/", {"name": ws_name})
            self._workspace_cache[ws_name] = data["id"]
        ws_id = self._workspace_cache[ws_name]

        if repo not in self._repo_cache:
            data = self._post("/repos/", {
                "workspace_id": ws_id,
                "url": f"https://github.com/{repo}",
                "name": repo.replace("/", "-"),
            })
            self._repo_cache[repo] = data["id"]
        repo_id = self._repo_cache[repo]

        return ws_id, repo_id

    def _get(self, path: str, params: Optional[dict] = None) -> dict:
        r = self._http.get(path, params=params)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, data: dict) -> dict:
        r = self._http.post(path, json=data)
        r.raise_for_status()
        return r.json()

    async def _async_get(self, path: str, params: Optional[dict] = None) -> dict:
        r = await self._async_http.get(path, params=params)
        r.raise_for_status()
        return r.json()

    async def _async_post(self, path: str, data: dict) -> dict:
        r = await self._async_http.post(path, json=data)
        r.raise_for_status()
        return r.json()

    def close(self):
        self._http.close()

    async def aclose(self):
        await self._async_http.aclose()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.aclose()
