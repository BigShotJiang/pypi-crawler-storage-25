from dataclasses import dataclass
from typing import Optional


@dataclass
class Task:
    id: str
    description: str
    phase: str
    repo_id: str
    workspace_id: str
    pr_url: Optional[str] = None
    error: Optional[str] = None
    plan: Optional[str] = None
    branch_name: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "Task":
        return cls(
            id=d.get("id", ""),
            description=d.get("description", ""),
            phase=d.get("phase", ""),
            repo_id=d.get("repo_id", ""),
            workspace_id=d.get("workspace_id", ""),
            pr_url=d.get("pr_url"),
            error=d.get("error"),
            plan=d.get("plan"),
            branch_name=d.get("branch_name"),
            created_at=d.get("created_at"),
            updated_at=d.get("updated_at"),
        )


@dataclass
class Agent:
    name: str
    category: str
    description: str
    estimated_prs: str


@dataclass
class Skill:
    name: str
    description: str
    prompt: Optional[str] = None
    tags: Optional[str] = None


@dataclass
class SearchResult:
    path: str
    score: float
    summary: str
