"""
sandflare-autogen
~~~~~~~~~~~~~~~~~
AutoGen CodeExecutor that runs code in isolated Sandflare Firecracker microVM sandboxes.

Usage::

    from sandflare_autogen import SandflareCodeExecutor
    from autogen import ConversableAgent

    with SandflareCodeExecutor(api_key="pa_live_...") as executor:
        agent = ConversableAgent(
            name="coder",
            llm_config={"model": "gpt-4o", "api_key": "..."},
            code_execution_config={"executor": executor},
        )
        user = ConversableAgent(
            name="user",
            human_input_mode="NEVER",
            is_termination_msg=lambda x: x.get("content", "").rstrip().endswith("TERMINATE"),
        )
        user.initiate_chat(agent, message="Write Python code to find the 50th prime number.")
"""
from __future__ import annotations

import os
import textwrap
from typing import Any, List, Optional

try:
    from autogen.coding import CodeBlock, CodeExecutor, CodeResult
except ImportError:
    raise ImportError(
        "ag2 package is required. Install with: pip install ag2"
    )

try:
    from sandflare import Sandbox
except ImportError:
    raise ImportError(
        "sandflare package is required. Install with: pip install sandflare"
    )


class SandflareCodeExecutor(CodeExecutor):
    """
    AutoGen CodeExecutor backed by Sandflare Firecracker microVM sandboxes.

    Each executor manages one sandbox. The sandbox is created on first use
    and deleted when stop() is called or the context manager exits.

    Args:
        api_key:     Sandflare API key. Falls back to SANDFLARE_API_KEY env var.
        template_id: Sandbox template (default: "" = base Ubuntu with Python 3).
        size:        VM size: "nano", "small", "medium", "large", "xl".
        timeout:     Per-execution timeout in seconds (default: 60).
        persistent:  If True, reuse the same sandbox across executor.restart() calls.
                     If False (default), restart() creates a fresh sandbox.
        base_url:    Override API base URL (for self-hosted deployments).
        env:         Environment variables to inject into the sandbox.

    Examples::

        # One-shot (creates fresh sandbox per executor)
        executor = SandflareCodeExecutor(api_key="pa_live_...")
        result = executor.execute_code_blocks([
            CodeBlock(code="import math; print(math.factorial(20))", language="python")
        ])
        executor.stop()

        # Context manager (auto-cleanup)
        with SandflareCodeExecutor() as executor:
            result = executor.execute_code_blocks([
                CodeBlock(code="print('hello from firecracker')", language="python")
            ])
            print(result.output)

        # Persistent sandbox (state preserved between calls)
        executor = SandflareCodeExecutor(persistent=True)
        executor.execute_code_blocks([CodeBlock(code="x = 42", language="python")])
        result = executor.execute_code_blocks([CodeBlock(code="print(x)", language="python")])
        # prints: 42
        executor.stop()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        template_id: str = "",
        size: str = "small",
        timeout: int = 60,
        persistent: bool = False,
        base_url: Optional[str] = None,
        env: Optional[dict] = None,
    ) -> None:
        self._api_key     = api_key or os.environ.get("SANDFLARE_API_KEY", "")
        self._template_id = template_id
        self._size        = size
        self._timeout     = timeout
        self._persistent  = persistent
        self._base_url    = base_url
        self._env         = env or {}
        self._sandbox: Optional[Sandbox] = None

    # -- Sandbox lifecycle --

    def _get_sandbox(self) -> Sandbox:
        if self._sandbox is None:
            self._sandbox = Sandbox.create(
                label="autogen-executor",
                template_id=self._template_id,
                size=self._size,
                env=self._env or None,
                api_key=self._api_key or None,
                base_url=self._base_url,
            )
        return self._sandbox

    def _delete_sandbox(self) -> None:
        if self._sandbox is not None:
            try:
                self._sandbox.delete()
            except Exception:
                pass
            self._sandbox = None

    # -- CodeExecutor interface --

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        """
        Execute a list of code blocks sequentially in the sandbox.

        Each code block is executed in order. stdout/stderr are collected and
        returned as a single CodeResult.

        Supported languages: python, python3, sh, bash, shell, javascript, js, node
        """
        sb = self._get_sandbox()
        outputs: list[str] = []
        last_exit = 0

        for block in code_blocks:
            lang = (block.language or "python").lower().strip()
            code = textwrap.dedent(block.code)

            try:
                if lang in ("python", "python3"):
                    result = sb.run_python(code, timeout=self._timeout)
                elif lang in ("javascript", "js", "node"):
                    result = sb.run_node(code, timeout=self._timeout)
                elif lang in ("sh", "bash", "shell"):
                    result = sb.exec(f"bash -c {_quote(code)}", timeout=self._timeout)
                else:
                    # Unknown language — try exec as shell command
                    result = sb.exec(code, timeout=self._timeout)

                if result.stdout:
                    outputs.append(result.stdout)
                if result.stderr:
                    outputs.append(f"[stderr]\n{result.stderr}")
                if result.exit_code != 0:
                    outputs.append(f"[exit code: {result.exit_code}]")
                last_exit = result.exit_code

            except Exception as exc:
                outputs.append(f"[execution error] {exc}")
                last_exit = 1
                break

        return CodeResult(
            exit_code=last_exit,
            output="\n".join(outputs),
        )

    def restart(self) -> None:
        """
        Restart the executor.

        If persistent=False (default), deletes the current sandbox and creates a
        fresh one on next execute_code_blocks() call.

        If persistent=True, keeps the same sandbox (state is preserved).
        """
        if not self._persistent:
            self._delete_sandbox()

    def stop(self) -> None:
        """Stop the executor and delete the underlying sandbox."""
        self._delete_sandbox()

    # -- Context manager --

    def __enter__(self) -> "SandflareCodeExecutor":
        return self

    def __exit__(self, *_: Any) -> None:
        self.stop()

    def __repr__(self) -> str:
        sb_id = self._sandbox.id if self._sandbox else "none"
        return f"<SandflareCodeExecutor sandbox={sb_id!r} size={self._size!r}>"


class SandflarePersistentExecutor(SandflareCodeExecutor):
    """
    Convenience subclass of SandflareCodeExecutor with persistent=True.

    State (variables, imports, installed packages) is preserved between
    execute_code_blocks() calls. Uses Sandflare's persistent Jupyter kernel.

    Usage::

        with SandflarePersistentExecutor() as executor:
            executor.execute_code_blocks([CodeBlock(code="import numpy as np\\nx = np.array([1,2,3])", language="python")])
            result = executor.execute_code_blocks([CodeBlock(code="print(x.mean())", language="python")])
            print(result.output)  # 2.0
    """

    def __init__(self, **kwargs: Any) -> None:
        kwargs["persistent"] = True
        super().__init__(**kwargs)

    def execute_code_blocks(self, code_blocks: List[CodeBlock]) -> CodeResult:
        """Execute using persistent Jupyter kernel (state preserved between calls)."""
        sb = self._get_sandbox()
        outputs: list[str] = []
        last_exit = 0

        for block in code_blocks:
            lang = (block.language or "python").lower().strip()
            code = textwrap.dedent(block.code)

            try:
                if lang in ("python", "python3"):
                    result = sb.run_code(code, context="autogen", timeout=self._timeout)
                    if result.stdout:
                        outputs.append(result.stdout)
                    if result.text and result.text.strip():
                        outputs.append(result.text)
                    if result.error:
                        outputs.append(f"[error]\n{result.error}")
                        last_exit = 1
                else:
                    # Non-Python falls back to exec
                    exec_result = sb.exec(code, timeout=self._timeout)
                    if exec_result.stdout:
                        outputs.append(exec_result.stdout)
                    if exec_result.stderr:
                        outputs.append(f"[stderr]\n{exec_result.stderr}")
                    last_exit = exec_result.exit_code

            except Exception as exc:
                outputs.append(f"[execution error] {exc}")
                last_exit = 1
                break

        return CodeResult(
            exit_code=last_exit,
            output="\n".join(outputs),
        )


def _quote(s: str) -> str:
    """Shell-quote a string for use in bash -c."""
    import shlex
    return shlex.quote(s)


__all__ = [
    "SandflareCodeExecutor",
    "SandflarePersistentExecutor",
]
