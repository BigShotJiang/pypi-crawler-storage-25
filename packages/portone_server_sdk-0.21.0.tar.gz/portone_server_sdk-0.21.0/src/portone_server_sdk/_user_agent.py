USER_AGENT = "v0.21.0-dirty"

__all__ = ["USER_AGENT"]
