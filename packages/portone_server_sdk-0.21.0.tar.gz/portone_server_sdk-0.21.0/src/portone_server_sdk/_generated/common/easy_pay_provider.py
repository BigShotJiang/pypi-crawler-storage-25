from __future__ import annotations
from typing import Any, Literal, Optional, Union

EasyPayProvider = Union[Literal["SAMSUNGPAY", "KAKAOPAY", "NAVERPAY", "PAYCO", "SSGPAY", "CHAI", "LPAY", "KPAY", "TOSSPAY", "LGPAY", "PINPAY", "APPLEPAY", "SKPAY", "TOSS_BRANDPAY", "KB_APP", "ALIPAY", "HYPHEN", "TMONEY", "PAYPAL", "SMILEPAY", "MIR", "WECHAT", "LINEPAY", "KLARNA", "GRABPAY", "SHOPEEPAY", "JKOPAY", "PAYPAY", "AMAZONPAY", "RAKUTENPAY", "DBARAI", "AUPAY", "MERPAY", "MONEYTREE", "KPLUS", "TINABA", "BILL_EASE", "KREDIVO", "RABBIT_LINE_PAY", "ALIPAY_HK", "AKULAKU_PAY_LATER", "BOOST", "BPI", "DANA", "G_CASH", "HIPAY", "MPAY", "TOUCH_N_GO", "TRUE_MONEY", "DOKU_WALLET", "JENIUS_PAY", "OVO", "MAYA", "QRIS", "THAI_QR"], str]
"""간편 결제사
"""


def _serialize_easy_pay_provider(obj: EasyPayProvider) -> Any:
    if isinstance(obj, dict):
        return obj
    return obj


def _deserialize_easy_pay_provider(obj: Any) -> EasyPayProvider:
    return obj
