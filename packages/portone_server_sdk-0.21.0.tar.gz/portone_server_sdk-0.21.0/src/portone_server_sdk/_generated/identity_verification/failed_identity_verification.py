from __future__ import annotations
from dataclasses import field
from typing import Any, Optional
from dataclasses import dataclass, field
from ..identity_verification.identity_verification_failure import IdentityVerificationFailure, _deserialize_identity_verification_failure, _serialize_identity_verification_failure
from ..identity_verification.identity_verification_requested_customer import IdentityVerificationRequestedCustomer, _deserialize_identity_verification_requested_customer, _serialize_identity_verification_requested_customer
from ..common.port_one_version import PortOneVersion, _deserialize_port_one_version, _serialize_port_one_version
from ..common.selected_channel import SelectedChannel, _deserialize_selected_channel, _serialize_selected_channel

@dataclass
class FailedIdentityVerification:
    """실패한 본인인증 내역
    """
    """본인인증 상태
    """
    id: str
    """고객사 본인인증 번호
    """
    requested_customer: IdentityVerificationRequestedCustomer
    """요청 시 고객 정보
    """
    requested_at: str
    """본인인증 요청 시점
    (RFC 3339 date-time)
    """
    updated_at: str
    """업데이트 시점
    (RFC 3339 date-time)
    """
    status_changed_at: str
    """상태 업데이트 시점
    (RFC 3339 date-time)
    """
    failure: IdentityVerificationFailure
    """본인인증 실패 정보
    """
    version: PortOneVersion
    """포트원 버전
    """
    channel: Optional[SelectedChannel] = field(default=None)
    """사용된 본인인증 채널
    """
    custom_data: Optional[str] = field(default=None)
    """사용자 지정 데이터
    """
    pg_tx_id: Optional[str] = field(default=None)
    """본인인증 내역 PG사 아이디
    """


def _serialize_failed_identity_verification(obj: FailedIdentityVerification) -> Any:
    if isinstance(obj, dict):
        return obj
    entity = {}
    entity["status"] = "FAILED"
    entity["id"] = obj.id
    entity["requestedCustomer"] = _serialize_identity_verification_requested_customer(obj.requested_customer)
    entity["requestedAt"] = obj.requested_at
    entity["updatedAt"] = obj.updated_at
    entity["statusChangedAt"] = obj.status_changed_at
    entity["failure"] = _serialize_identity_verification_failure(obj.failure)
    entity["version"] = _serialize_port_one_version(obj.version)
    if obj.channel is not None:
        entity["channel"] = _serialize_selected_channel(obj.channel)
    if obj.custom_data is not None:
        entity["customData"] = obj.custom_data
    if obj.pg_tx_id is not None:
        entity["pgTxId"] = obj.pg_tx_id
    return entity


def _deserialize_failed_identity_verification(obj: Any) -> FailedIdentityVerification:
    if not isinstance(obj, dict):
        raise ValueError(f"{repr(obj)} is not dict")
    if "status" not in obj:
        raise KeyError(f"'status' is not in {obj}")
    status = obj["status"]
    if status != "FAILED":
        raise ValueError(f"{repr(status)} is not 'FAILED'")
    if "id" not in obj:
        raise KeyError(f"'id' is not in {obj}")
    id = obj["id"]
    if not isinstance(id, str):
        raise ValueError(f"{repr(id)} is not str")
    if "requestedCustomer" not in obj:
        raise KeyError(f"'requestedCustomer' is not in {obj}")
    requested_customer = obj["requestedCustomer"]
    requested_customer = _deserialize_identity_verification_requested_customer(requested_customer)
    if "requestedAt" not in obj:
        raise KeyError(f"'requestedAt' is not in {obj}")
    requested_at = obj["requestedAt"]
    if not isinstance(requested_at, str):
        raise ValueError(f"{repr(requested_at)} is not str")
    if "updatedAt" not in obj:
        raise KeyError(f"'updatedAt' is not in {obj}")
    updated_at = obj["updatedAt"]
    if not isinstance(updated_at, str):
        raise ValueError(f"{repr(updated_at)} is not str")
    if "statusChangedAt" not in obj:
        raise KeyError(f"'statusChangedAt' is not in {obj}")
    status_changed_at = obj["statusChangedAt"]
    if not isinstance(status_changed_at, str):
        raise ValueError(f"{repr(status_changed_at)} is not str")
    if "failure" not in obj:
        raise KeyError(f"'failure' is not in {obj}")
    failure = obj["failure"]
    failure = _deserialize_identity_verification_failure(failure)
    if "version" not in obj:
        raise KeyError(f"'version' is not in {obj}")
    version = obj["version"]
    version = _deserialize_port_one_version(version)
    if "channel" in obj:
        channel = obj["channel"]
        channel = _deserialize_selected_channel(channel)
    else:
        channel = None
    if "customData" in obj:
        custom_data = obj["customData"]
        if not isinstance(custom_data, str):
            raise ValueError(f"{repr(custom_data)} is not str")
    else:
        custom_data = None
    if "pgTxId" in obj:
        pg_tx_id = obj["pgTxId"]
        if not isinstance(pg_tx_id, str):
            raise ValueError(f"{repr(pg_tx_id)} is not str")
    else:
        pg_tx_id = None
    return FailedIdentityVerification(id, requested_customer, requested_at, updated_at, status_changed_at, failure, version, channel, custom_data, pg_tx_id)
