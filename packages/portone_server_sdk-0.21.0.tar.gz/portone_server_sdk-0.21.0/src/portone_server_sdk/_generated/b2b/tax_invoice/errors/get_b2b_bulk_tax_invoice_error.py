from dataclasses import dataclass
from ....._portone_error import PortOneError
@dataclass
class GetB2bBulkTaxInvoiceError(PortOneError):
    pass
