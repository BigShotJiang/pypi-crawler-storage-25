"""Local web server providing a browser-based UI for udsxml2tex (--serve mode)."""

from __future__ import annotations

import io
import logging
import os
import shutil
import tempfile
import threading
import webbrowser
import zipfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

try:
    from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
    from fastapi.responses import (
        FileResponse, JSONResponse, Response, StreamingResponse,
    )
    import uvicorn
    _FASTAPI_AVAILABLE = True
except ImportError:
    _FASTAPI_AVAILABLE = False

from udsxml2tex import __version__
from udsxml2tex.parser import ArxmlParser
from udsxml2tex.generator import TexGenerator

# Optional modules — imported lazily so missing them doesn't break the server
try:
    from udsxml2tex.validator import UdsValidator  # type: ignore[import]
    _VALIDATOR_AVAILABLE = True
except ImportError:
    _VALIDATOR_AVAILABLE = False

try:
    from udsxml2tex.diff import SpecDiffer  # type: ignore[import]
    _DIFFER_AVAILABLE = True
except ImportError:
    _DIFFER_AVAILABLE = False

_TEMPLATES_DIR = Path(__file__).parent / "templates"
_SAMPLES_DIR = Path(__file__).parent / "samples"

# Session-scoped state for the chat tab.
#   _CHAT_SESSIONS[session_id] = {"spec": <UdsSpecification>, "summary": {...}}
# Cleared on server restart. Single-process; not safe for multi-worker uvicorn —
# acceptable for the local-dev `udsxml2tex --serve` usage pattern.
_CHAT_SESSIONS: dict[str, dict] = {}
_CHAT_SESSIONS_LOCK = threading.Lock()
_CHAT_SESSION_LIMIT = 32  # FIFO eviction of the oldest entries past this

_SAMPLE_META: dict[str, dict] = {
    "sample_dcm.arxml": {
        "label": "Sample DCM ARXML (main UDS spec)",
        "description": "Full DCM configuration: sessions, security levels, DIDs, routines, services",
        "type": "arxml",
        "targets": ["primary"],
    },
    "sample_cantp.arxml": {
        "label": "Sample CanTp ARXML",
        "description": "CAN Transport Protocol channel and PDU configuration",
        "type": "arxml",
        "targets": ["primary"],
    },
    "sample_dem.arxml": {
        "label": "Sample DEM ARXML",
        "description": "Diagnostic Event Manager — DTC definitions and severity levels",
        "type": "arxml",
        "targets": ["dem"],
    },
    "udsspec.cls": {
        "label": "udsspec.cls (LaTeX class file)",
        "description": "Built-in LaTeX document class for UDS specification documents",
        "type": "cls",
        "targets": ["cls"],
    },
    "sample_did.c": {
        "label": "Sample DID implementation C code",
        "description": "Example C source with DID read/write functions and global variable references",
        "type": "c",
        "targets": ["did_c"],
    },
    "sample_rid.c": {
        "label": "Sample RID implementation C code",
        "description": "Example C source with RID start/stop/result functions and global variable references",
        "type": "c",
        "targets": ["rid_c"],
    },
    "system_redundant.yaml": {
        "label": "Sample 1+1 redundant system config (YAML)",
        "description": "Multi-ECU system config: gateway primary + endpoint secondary, with explicit routing rules (paired with sample_dcm.arxml + sample_cantp.arxml + sample_dem.arxml + sample_secondary_dcm.arxml)",
        "type": "yaml",
        "targets": ["system_yaml"],
    },
    "sample_secondary_dcm.arxml": {
        "label": "Sample DCM ARXML (secondary ECU of redundant pair)",
        "description": "Minimal DCM for the secondary MCU; receives forwarded calibration DIDs and routines from the primary",
        "type": "arxml",
        "targets": ["secondary"],
    },
}


def _require_fastapi() -> None:
    """Raise ImportError with helpful message if FastAPI is not installed."""
    if not _FASTAPI_AVAILABLE:
        raise ImportError(
            "The web server requires optional dependencies.\n"
            "Install them with:\n\n"
            "    pip install udsxml2tex[web]\n\n"
            "or manually:\n\n"
            "    pip install fastapi uvicorn python-multipart"
        )


def _store_chat_session(spec: object, summary: dict) -> str:
    """Stash a parsed spec under a fresh session ID; returns the ID.

    Evicts the oldest entries when the in-memory store exceeds
    `_CHAT_SESSION_LIMIT`. Threadsafe.
    """
    import secrets
    session_id = secrets.token_urlsafe(16)
    with _CHAT_SESSIONS_LOCK:
        _CHAT_SESSIONS[session_id] = {"spec": spec, "summary": summary}
        # FIFO eviction
        while len(_CHAT_SESSIONS) > _CHAT_SESSION_LIMIT:
            _CHAT_SESSIONS.pop(next(iter(_CHAT_SESSIONS)))
    return session_id


def _get_chat_session(session_id: str) -> Optional[dict]:
    """Retrieve a stashed spec by session ID, or None if expired/unknown."""
    with _CHAT_SESSIONS_LOCK:
        return _CHAT_SESSIONS.get(session_id)


def _save_upload(upload: "UploadFile", dest: Path) -> None:
    """Save an uploaded file to *dest* on disk."""
    content = upload.file.read()
    dest.write_bytes(content)


def _safe_basename(name: str, *, default: Optional[str]) -> Optional[str]:
    """Return the safe basename of `name`, or `default` if it can't be made safe.

    Drops any path components and rejects names that try to escape the work
    directory (`..`) or contain NUL / forward slashes after stripping.
    `default=None` makes a malicious name surface as None for the caller.
    """
    bn = os.path.basename(name).strip()
    if not bn or bn in ("", ".", "..") or "\x00" in bn or "/" in bn or "\\" in bn:
        return default
    return bn


def _build_summary(spec: object) -> dict:
    """Build a JSON-serialisable summary dict from a UdsSpecification."""
    return {
        "ecu_name": spec.ecu_name,
        "protocol_name": spec.protocol_name,
        "session_count": len(spec.sessions),
        "security_level_count": len(spec.security_levels),
        "service_count": len(spec.services),
        "did_count": len(spec.dids),
        "routine_count": len(spec.routines),
        "dtc_count": len(spec.dtcs),
        "memory_range_count": len(spec.memory_ranges),
    }


def _parse_arxml(
    arxml_paths: "Path | list[Path]",
    dem_path: Optional[Path] = None,
    ecu_name: Optional[str] = None,
) -> tuple:
    """Parse ARXML file(s) and return (spec, warnings_list)."""
    parser = ArxmlParser()
    if isinstance(arxml_paths, list) and len(arxml_paths) > 1:
        spec = parser.parse_multi(arxml_paths)
    else:
        path = arxml_paths[0] if isinstance(arxml_paths, list) else arxml_paths
        spec = parser.parse(path)

    if dem_path is not None:
        try:
            from udsxml2tex.dem_parser import DemParser
            DemParser().parse(dem_path, spec)
        except Exception as exc:  # noqa: BLE001
            logger.warning("DEM parse error (non-fatal): %s", exc)

    if ecu_name:
        spec.ecu_name = ecu_name

    warnings = [
        {"section": w.section, "message": w.message}
        for w in parser.warnings
    ]
    return spec, warnings


def _create_app() -> "FastAPI":
    """Build and return the FastAPI application instance."""
    _require_fastapi()

    app = FastAPI(
        title="udsxml2tex Web UI",
        version=__version__,
        description="Browser-based interface for converting AUTOSAR ARXML to UDS specification documents.",
    )

    # ------------------------------------------------------------------
    # GET /  — serve the web UI HTML page
    # ------------------------------------------------------------------

    @app.get("/")
    async def serve_ui() -> FileResponse:
        ui_path = _TEMPLATES_DIR / "web_ui.html"
        if not ui_path.exists():
            raise HTTPException(status_code=404, detail="web_ui.html not found in templates directory")
        return FileResponse(str(ui_path), media_type="text/html")

    # ------------------------------------------------------------------
    # GET /health
    # ------------------------------------------------------------------

    @app.get("/health")
    async def health() -> JSONResponse:
        return JSONResponse({"status": "ok", "version": __version__})

    # ------------------------------------------------------------------
    # GET /samples — list available built-in sample files
    # ------------------------------------------------------------------

    @app.get("/samples")
    async def list_samples() -> JSONResponse:
        items = []
        for name, meta in _SAMPLE_META.items():
            path = _SAMPLES_DIR / name
            items.append({
                "name": name,
                "label": meta["label"],
                "description": meta["description"],
                "type": meta["type"],
                "targets": meta.get("targets", []),
                "available": path.exists(),
                "size": path.stat().st_size if path.exists() else 0,
            })
        return JSONResponse({"samples": items})

    # ------------------------------------------------------------------
    # GET /samples/{name} — download a built-in sample file
    # ------------------------------------------------------------------

    @app.get("/samples/{name}")
    async def get_sample(name: str) -> Response:
        if name not in _SAMPLE_META:
            raise HTTPException(status_code=404, detail=f"Sample '{name}' not found")
        path = _SAMPLES_DIR / name
        if not path.exists():
            raise HTTPException(status_code=404, detail=f"Sample file '{name}' is missing from installation")
        content = path.read_bytes()
        if name.endswith(".arxml"):
            media_type = "application/xml"
        elif name.endswith((".yaml", ".yml")):
            media_type = "text/yaml"
        else:
            media_type = "text/plain"
        return Response(
            content=content,
            media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="{name}"'},
        )

    # ------------------------------------------------------------------
    # POST /parse — parse uploaded ARXML and return a JSON summary
    # ------------------------------------------------------------------

    @app.post("/parse")
    async def parse_arxml(
        arxml_files: list[UploadFile] = File(...),
        dem_file: Optional[UploadFile] = File(None),
        ecu_name: Optional[str] = Form(None),
    ) -> JSONResponse:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_parse_")
        try:
            arxml_paths: list[Path] = []
            for i, uf in enumerate(arxml_files):
                if uf is not None and uf.filename:
                    p = Path(tmpdir) / f"input_{i}.arxml"
                    _save_upload(uf, p)
                    arxml_paths.append(p)
            if not arxml_paths:
                return JSONResponse({"success": False, "error": "No ARXML file provided"}, status_code=400)

            dem_path: Optional[Path] = None
            if dem_file is not None and dem_file.filename:
                dem_path = Path(tmpdir) / "dem.arxml"
                _save_upload(dem_file, dem_path)

            spec, warnings = _parse_arxml(arxml_paths, dem_path, ecu_name or None)
            summary = _build_summary(spec)
            # Stash the parsed spec under a fresh session ID so the Chat tab
            # can ask questions against it without re-uploading the ARXML.
            session_id = _store_chat_session(spec, summary)
            return JSONResponse({
                "success": True,
                "summary": summary,
                "warnings": warnings,
                "session_id": session_id,
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Parse error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /generate — parse ARXML and return generated output as download
    # ------------------------------------------------------------------

    @app.post("/generate")
    async def generate_output(
        arxml_files: list[UploadFile] = File(...),
        dem_file: Optional[UploadFile] = File(None),
        format: str = Form("tex"),  # noqa: A002  # "tex" | "pdf" | "html"
        ecu_name: Optional[str] = Form(None),
        cls_file: Optional[UploadFile] = File(None),
        did_c_files: Optional[list[UploadFile]] = File(None),
        rid_c_files: Optional[list[UploadFile]] = File(None),
    ) -> Response:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_gen_")
        try:
            arxml_paths: list[Path] = []
            for i, uf in enumerate(arxml_files):
                if uf is not None and uf.filename:
                    p = Path(tmpdir) / f"input_{i}.arxml"
                    _save_upload(uf, p)
                    arxml_paths.append(p)
            if not arxml_paths:
                return Response(content="No ARXML file provided", status_code=400)

            dem_path: Optional[Path] = None
            if dem_file is not None and dem_file.filename:
                dem_path = Path(tmpdir) / "dem.arxml"
                _save_upload(dem_file, dem_path)

            spec, _ = _parse_arxml(arxml_paths, dem_path, ecu_name or None)

            # Run C scanner for DID variables if DID C files were provided
            if did_c_files:
                _did_c_paths: list[Path] = []
                for uf in did_c_files:
                    if uf is not None and uf.filename:
                        p = Path(tmpdir) / f"did_c_{uf.filename}"
                        _save_upload(uf, p)
                        _did_c_paths.append(p)
                if _did_c_paths and spec.dids:
                    from udsxml2tex.c_scanner import scan_did_variables
                    scan_did_variables(_did_c_paths, spec.dids)

            # Run C scanner for RID variables if RID C files were provided
            if rid_c_files:
                _rid_c_paths: list[Path] = []
                for uf in rid_c_files:
                    if uf is not None and uf.filename:
                        p = Path(tmpdir) / f"rid_c_{uf.filename}"
                        _save_upload(uf, p)
                        _rid_c_paths.append(p)
                if _rid_c_paths and spec.routines:
                    from udsxml2tex.c_scanner import scan_rid_variables
                    scan_rid_variables(_rid_c_paths, spec.routines)

            safe_name = (spec.ecu_name or "ecu").replace(" ", "_")
            tex_gen = TexGenerator()

            fmt = format.lower()

            if fmt == "tex":
                # Generate structured tex zip
                cls_content: Optional[bytes] = None
                if cls_file is not None and cls_file.filename:
                    cls_content = cls_file.file.read()
                out_zip = Path(tmpdir) / f"{safe_name}_uds_spec_tex.zip"
                tex_gen.generate_structured_tex_zip(spec, out_zip, cls_content=cls_content)
                content = out_zip.read_bytes()
                filename = out_zip.name
                media_type = "application/zip"

            elif fmt == "pdf":
                # Compile the structured tex to PDF
                import subprocess
                cls_content = None
                if cls_file is not None and cls_file.filename:
                    cls_content = cls_file.file.read()
                # First generate the structured tex tree into a temp subdir
                tex_dir = Path(tmpdir) / "tex_src"
                tex_dir.mkdir()
                tex_gen.generate_structured_tex_zip(
                    spec, Path(tmpdir) / "tex_tmp.zip", cls_content=cls_content
                )
                # Extract the zip to tex_dir
                import zipfile as _zipfile
                with _zipfile.ZipFile(Path(tmpdir) / "tex_tmp.zip") as zf:
                    zf.extractall(tex_dir)
                # Try to compile with xelatex (twice for TOC/refs)
                pdf_path = tex_dir / "root.pdf"
                try:
                    for _ in range(2):
                        result = subprocess.run(
                            ["xelatex", "-interaction=nonstopmode", "root.tex"],
                            cwd=tex_dir, capture_output=True, timeout=60
                        )
                    if pdf_path.exists():
                        content = pdf_path.read_bytes()
                        filename = f"{safe_name}_uds_spec.pdf"
                        media_type = "application/pdf"
                    else:
                        # xelatex failed — return the tex zip instead with a warning header
                        out_zip2 = Path(tmpdir) / f"{safe_name}_uds_spec_tex.zip"
                        tex_gen.generate_structured_tex_zip(spec, out_zip2, cls_content=cls_content)
                        content = out_zip2.read_bytes()
                        filename = out_zip2.name
                        media_type = "application/zip"
                except (subprocess.TimeoutExpired, FileNotFoundError):
                    # xelatex not available — fall back to tex zip
                    out_zip3 = Path(tmpdir) / f"{safe_name}_uds_spec_tex.zip"
                    tex_gen.generate_structured_tex_zip(spec, out_zip3, cls_content=cls_content)
                    content = out_zip3.read_bytes()
                    filename = out_zip3.name
                    media_type = "application/zip"

            elif fmt == "html":
                out_zip = Path(tmpdir) / f"{safe_name}_uds_spec_html.zip"
                tex_gen.generate_html_zip(spec, out_zip)
                content = out_zip.read_bytes()
                filename = out_zip.name
                media_type = "application/zip"

            else:
                return JSONResponse(
                    {"success": False, "error": f"Unknown format: {format}. Supported: tex, pdf, html"},
                    status_code=400,
                )

            return Response(
                content=content,
                media_type=media_type,
                headers={
                    "Content-Disposition": f'attachment; filename="{filename}"',
                },
            )
        except Exception as exc:  # noqa: BLE001
            logger.exception("Generate error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /validate — validate ARXML and return issues
    # ------------------------------------------------------------------

    @app.post("/validate")
    async def validate_arxml(
        arxml_file: UploadFile = File(...),
    ) -> JSONResponse:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_validate_")
        try:
            arxml_path = Path(tmpdir) / "input.arxml"
            _save_upload(arxml_file, arxml_path)

            if _VALIDATOR_AVAILABLE:
                validator = UdsValidator()
                result = validator.validate_file(arxml_path)
                return JSONResponse({"success": True, "result": result})

            # Fallback: use parser warnings as validation result
            parser = ArxmlParser()
            errors: list[dict] = []
            warnings_out: list[dict] = []
            infos: list[dict] = []

            try:
                spec = parser.parse(arxml_path)
                for w in parser.warnings:
                    warnings_out.append({
                        "severity": "warning",
                        "category": w.section,
                        "message": w.message,
                        "item_id": "",
                    })
                infos.append({
                    "severity": "info",
                    "category": "summary",
                    "message": (
                        f"Parsed successfully: {len(spec.sessions)} sessions, "
                        f"{len(spec.dids)} DIDs, {len(spec.services)} services, "
                        f"{len(spec.dtcs)} DTCs"
                    ),
                    "item_id": "",
                })
            except Exception as exc:  # noqa: BLE001
                errors.append({
                    "severity": "error",
                    "category": "parse",
                    "message": str(exc),
                    "item_id": "",
                })

            summary_parts = []
            if errors:
                summary_parts.append(f"{len(errors)} error(s)")
            if warnings_out:
                summary_parts.append(f"{len(warnings_out)} warning(s)")
            if infos:
                summary_parts.append(f"{len(infos)} info(s)")
            summary_str = ", ".join(summary_parts) if summary_parts else "No issues found"

            return JSONResponse({
                "success": True,
                "result": {
                    "errors": errors,
                    "warnings": warnings_out,
                    "infos": infos,
                    "summary": summary_str,
                },
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Validate error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /diff — diff two ARXML files
    # ------------------------------------------------------------------

    @app.post("/diff")
    async def diff_arxml(
        arxml_a: UploadFile = File(...),
        arxml_b: UploadFile = File(...),
    ) -> JSONResponse:
        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_diff_")
        try:
            path_a = Path(tmpdir) / "spec_a.arxml"
            path_b = Path(tmpdir) / "spec_b.arxml"
            _save_upload(arxml_a, path_a)
            _save_upload(arxml_b, path_b)

            if _DIFFER_AVAILABLE:
                differ = SpecDiffer()
                diff_result = differ.diff_files(path_a, path_b)
                return JSONResponse({"success": True, "diff": diff_result})

            # Fallback: basic structural diff via parser
            parser_a = ArxmlParser()
            parser_b = ArxmlParser()

            try:
                spec_a = parser_a.parse(path_a)
            except Exception as exc:  # noqa: BLE001
                return JSONResponse(
                    {"success": False, "error": f"Failed to parse Spec A: {exc}"},
                    status_code=400,
                )

            try:
                spec_b = parser_b.parse(path_b)
            except Exception as exc:  # noqa: BLE001
                return JSONResponse(
                    {"success": False, "error": f"Failed to parse Spec B: {exc}"},
                    status_code=400,
                )

            entries = _basic_diff(spec_a, spec_b)
            added = sum(1 for e in entries if e["kind"] == "added")
            removed = sum(1 for e in entries if e["kind"] == "removed")
            changed = sum(1 for e in entries if e["kind"] == "changed")
            summary = f"{added} added, {removed} removed, {changed} changed"

            return JSONResponse({
                "success": True,
                "diff": {
                    "summary": summary,
                    "entries": entries,
                },
            })
        except Exception as exc:  # noqa: BLE001
            logger.exception("Diff error")
            return JSONResponse({"success": False, "error": str(exc)}, status_code=400)
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    # ------------------------------------------------------------------
    # POST /chat — multi-turn LLM chat against the most recently parsed spec
    # ------------------------------------------------------------------
    @app.post("/chat")
    async def chat(request: Request) -> "Response":
        """Stream an LLM chat response as Server-Sent Events.

        Request JSON body:
            session_id  (required) — ID returned by /parse
            messages    (required) — list of {role: "user"|"assistant", content: str}
            model       (optional) — "sonnet" (default) | "opus" | "haiku"
            api_key     (optional) — override ANTHROPIC_API_KEY for this call

        Response: text/event-stream emitting:
            data: {"delta": "...next chunk of text..."}
            data: {"done": true}
            data: {"error": "..."}
        """
        try:
            body = await request.json()
        except Exception:  # noqa: BLE001
            return JSONResponse(
                {"error": "Invalid JSON body"}, status_code=400
            )

        session_id = body.get("session_id")
        messages = body.get("messages") or []
        # Per-call config overrides — None means "fall back to server's default"
        # (env vars / ~/.udsxml2tex/llm.json / built-in default).
        ui_provider  = body.get("provider") or None
        ui_base_url  = body.get("base_url") or None
        ui_model     = body.get("model") or None
        ui_api_key   = body.get("api_key") or None

        if not session_id:
            return JSONResponse(
                {"error": "session_id is required (parse an ARXML first)"},
                status_code=400,
            )
        sess = _get_chat_session(session_id)
        if not sess:
            return JSONResponse(
                {"error": "Unknown or expired session_id; re-parse the ARXML"},
                status_code=404,
            )
        if not messages or messages[0].get("role") != "user":
            return JSONResponse(
                {"error": "messages must be non-empty and start with role='user'"},
                status_code=400,
            )

        spec = sess["spec"]

        try:
            from udsxml2tex.llm_integration import LLMConfig, chat_stream
        except ImportError as e:
            return JSONResponse(
                {"error": str(e)}, status_code=500,
            )

        # Build a per-request config: server defaults + UI overrides.
        cfg = LLMConfig.auto()
        if ui_provider:
            cfg.provider = ui_provider
        if ui_base_url:
            cfg.base_url = ui_base_url
        if ui_model:
            cfg.model = ui_model
        if ui_api_key:
            cfg.api_key = ui_api_key

        def _sse_iter():
            import json as _json
            try:
                for delta in chat_stream(spec, messages, config=cfg):
                    yield "data: " + _json.dumps({"delta": delta}) + "\n\n"
                yield "data: " + _json.dumps({"done": True}) + "\n\n"
            except Exception as exc:  # noqa: BLE001
                logger.exception("Chat error")
                yield "data: " + _json.dumps({"error": str(exc)}) + "\n\n"

        return StreamingResponse(
            _sse_iter(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache, no-transform",
                "X-Accel-Buffering": "no",
            },
        )

    # ------------------------------------------------------------------
    # POST /system — multi-ECU (redundant / gateway) generation
    # ------------------------------------------------------------------
    @app.post("/system")
    async def system_generate(
        system_yaml: UploadFile = File(...),
        arxml_files: list[UploadFile] = File(...),
        c_files: Optional[list[UploadFile]] = File(None),
        format: str = Form("html"),
        no_routing_inference: str = Form("false"),
    ) -> Response:
        """Generate per-ECU specs + integration document for a multi-ECU system.

        Request:
            system_yaml         — system config (.yaml/.yml/.json). Filenames it
                                  references must match the basenames of the
                                  uploaded `arxml_files` / `c_files`.
            arxml_files         — every ARXML the system config refers to,
                                  primary + secondary + DEM, etc.
            c_files             — optional .c/.cpp/.h sources matching any
                                  per-ECU `did_c_files:` / `rid_c_files:`
                                  entries in the YAML. The scanners populate
                                  DataElement.global_variables in-place.
            format              — "html" (default) | "tex" | "pdf" | "md".
                                  `pdf` requires latexmk or pdflatex on the
                                  server.
            no_routing_inference — "true" disables ARXML coverage-gap routing
                                  inference; explicit rules are always kept.

        Response: application/zip with the same layout as
            `udsxml2tex --system <yaml> --system-output-dir <dir>`:
                <ecu_name>/spec.<ext>     — one per ECU
                system.<ext>              — integration document
                system_topology.tex       — TikZ topology figure
        """
        fmt = (format or "html").strip().lower()
        if fmt not in ("html", "tex", "pdf", "md"):
            return JSONResponse(
                {"error": f"Unsupported format {fmt!r}; use html, tex, pdf, or md"},
                status_code=400,
            )

        try:
            from udsxml2tex.multi_ecu import (
                generate_system_html,
                generate_system_latex,
                generate_system_markdown,
                generate_topology_tikz,
                load_system_config,
            )
        except ImportError as exc:
            return JSONResponse(
                {"error": f"multi_ecu module not available: {exc}"},
                status_code=500,
            )

        infer = not (no_routing_inference or "").strip().lower() in ("1", "true", "yes")

        tmpdir = tempfile.mkdtemp(prefix="udsxml2tex_system_")
        try:
            workdir = Path(tmpdir)

            # Save the system YAML — original filename so messages stay readable.
            yaml_name = _safe_basename(
                system_yaml.filename or "system.yaml", default="system.yaml",
            )
            yaml_path = workdir / yaml_name
            _save_upload(system_yaml, yaml_path)

            # Save each ARXML using its original filename so the YAML's relative
            # `arxml_files:` entries resolve. Reject path traversal.
            for uf in arxml_files:
                if not uf or not uf.filename:
                    continue
                bn = _safe_basename(uf.filename, default=None)
                if bn is None:
                    return JSONResponse(
                        {"error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                _save_upload(uf, workdir / bn)

            # C source files: same flat-bucket pattern. Per-ECU assignment
            # happens via the YAML's `did_c_files:` / `rid_c_files:` lists.
            for uf in (c_files or []):
                if not uf or not uf.filename:
                    continue
                bn = _safe_basename(uf.filename, default=None)
                if bn is None:
                    return JSONResponse(
                        {"error": f"Rejected unsafe filename: {uf.filename!r}"},
                        status_code=400,
                    )
                _save_upload(uf, workdir / bn)

            # Load + parse + (optionally) infer routing.
            try:
                system = load_system_config(
                    yaml_path, parse_arxml=True, infer_routing=infer,
                )
            except FileNotFoundError as exc:
                return JSONResponse(
                    {"error": f"YAML refers to a file that wasn't uploaded: {exc}"},
                    status_code=400,
                )
            except Exception as exc:  # noqa: BLE001
                logger.exception("System config load failed")
                return JSONResponse(
                    {"error": f"Failed to load system config: {exc}"},
                    status_code=400,
                )

            # Generate per-ECU outputs + system integration doc into output dir.
            out_dir = workdir / "out"
            out_dir.mkdir()
            tex_gen = TexGenerator()
            per_ecu_ext = {
                "tex": ".tex", "pdf": ".tex",
                "html": ".zip", "md": ".md",
            }[fmt]

            for name, ecu in system.ecus.items():
                if not ecu.spec:
                    continue
                ecu_dir = out_dir / name
                ecu_dir.mkdir(parents=True, exist_ok=True)
                spec_out = ecu_dir / f"spec{per_ecu_ext}"
                if fmt in ("tex", "pdf"):
                    tex_gen.generate(ecu.spec, spec_out)
                elif fmt == "html":
                    tex_gen.generate_html_zip(ecu.spec, spec_out)
                else:  # md
                    tex_gen.generate_markdown(ecu.spec, spec_out)
                if fmt == "pdf":
                    try:
                        tex_gen.compile_pdf(spec_out)
                    except Exception as exc:  # noqa: BLE001
                        return JSONResponse(
                            {"error":
                             f"PDF compilation failed for ECU {name!r}: {exc}. "
                             "Install latexmk + a TeX distribution on the "
                             "server, or use format=tex/html/md."},
                            status_code=500,
                        )

            if fmt in ("tex", "pdf"):
                sys_text = generate_system_latex(system)
                (out_dir / "system.tex").write_text(sys_text, encoding="utf-8")
            elif fmt == "html":
                sys_text = generate_system_html(system)
                (out_dir / "system.html").write_text(sys_text, encoding="utf-8")
            else:  # md
                sys_text = generate_system_markdown(system)
                (out_dir / "system.md").write_text(sys_text, encoding="utf-8")

            (out_dir / "system_topology.tex").write_text(
                generate_topology_tikz(system), encoding="utf-8"
            )

            if fmt == "pdf":
                try:
                    tex_gen.compile_pdf(out_dir / "system.tex")
                except Exception as exc:  # noqa: BLE001
                    return JSONResponse(
                        {"error":
                         f"System integration PDF compilation failed: {exc}"},
                        status_code=500,
                    )

            # Bundle the whole out_dir into a single ZIP for the browser.
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in sorted(out_dir.rglob("*")):
                    if p.is_file():
                        zf.write(p, arcname=str(p.relative_to(out_dir)))
            buf.seek(0)

            return Response(
                content=buf.getvalue(),
                media_type="application/zip",
                headers={
                    "Content-Disposition":
                        f'attachment; filename="{system.name or "system"}.zip"',
                },
            )
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    return app


# ---------------------------------------------------------------------------
# Helper: basic structural diff (used when SpecDiffer is not available)
# ---------------------------------------------------------------------------

def _basic_diff(spec_a: object, spec_b: object) -> list[dict]:
    """Produce a list of diff entries comparing two UdsSpecification objects."""
    entries: list[dict] = []

    def _compare_items(
        items_a: list,
        items_b: list,
        category: str,
        id_fn,
        desc_fn,
    ) -> None:
        ids_a = {id_fn(x): x for x in items_a}
        ids_b = {id_fn(x): x for x in items_b}
        for key in sorted(ids_a.keys() - ids_b.keys()):
            entries.append({
                "kind": "removed",
                "category": category,
                "item_id": str(key),
                "description": desc_fn(ids_a[key]),
            })
        for key in sorted(ids_b.keys() - ids_a.keys()):
            entries.append({
                "kind": "added",
                "category": category,
                "item_id": str(key),
                "description": desc_fn(ids_b[key]),
            })
        for key in sorted(ids_a.keys() & ids_b.keys()):
            if desc_fn(ids_a[key]) != desc_fn(ids_b[key]):
                entries.append({
                    "kind": "changed",
                    "category": category,
                    "item_id": str(key),
                    "description": f"{desc_fn(ids_a[key])} → {desc_fn(ids_b[key])}",
                })

    _compare_items(
        spec_a.sessions, spec_b.sessions,
        "session",
        lambda s: s.session_id,
        lambda s: s.short_name,
    )
    _compare_items(
        spec_a.security_levels, spec_b.security_levels,
        "security_level",
        lambda s: s.security_level,
        lambda s: s.short_name,
    )
    _compare_items(
        spec_a.services, spec_b.services,
        "service",
        lambda s: s.service_id,
        lambda s: s.short_name,
    )
    _compare_items(
        spec_a.dids, spec_b.dids,
        "did",
        lambda d: d.did_id,
        lambda d: d.short_name,
    )
    _compare_items(
        spec_a.routines, spec_b.routines,
        "routine",
        lambda r: r.routine_id,
        lambda r: r.short_name,
    )
    _compare_items(
        spec_a.dtcs, spec_b.dtcs,
        "dtc",
        lambda d: d.dtc_id,
        lambda d: d.short_name,
    )
    return entries


# ---------------------------------------------------------------------------
# Helper: markdown export
# ---------------------------------------------------------------------------

def _spec_to_markdown(spec: object) -> str:
    """Render a UdsSpecification as a simple Markdown document."""
    lines: list[str] = []
    lines.append(f"# {spec.ecu_name} UDS Specification\n")
    lines.append(f"**Protocol:** {spec.protocol_name}\n")

    lines.append("\n## Diagnostic Sessions\n")
    lines.append("| ID | Name | P2 (s) | P2* (s) |")
    lines.append("|----|------|--------|---------|")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        lines.append(f"| {s.session_id_hex} | {s.short_name} | {s.p2_server_max} | {s.p2_star_server_max} |")

    lines.append("\n## Security Levels\n")
    lines.append("| Level | Name | Seed Size | Key Size |")
    lines.append("|-------|------|-----------|----------|")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        lines.append(f"| {s.security_level_hex} | {s.short_name} | {s.seed_size} B | {s.key_size} B |")

    lines.append("\n## Services\n")
    lines.append("| SID | Name | Sub-Functions | NRCs |")
    lines.append("|-----|------|---------------|------|")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        lines.append(f"| {s.service_id_hex} | {s.short_name} | {len(s.sub_functions)} | {len(s.nrc_list)} |")

    lines.append("\n## Data Identifiers (DIDs)\n")
    lines.append("| DID | Name | Length | Read | Write |")
    lines.append("|-----|------|--------|------|-------|")
    for d in sorted(spec.dids, key=lambda x: x.did_id):
        lines.append(
            f"| {d.did_id_hex} | {d.short_name} | {d.total_byte_length} B "
            f"| {'Yes' if d.read_access else 'No'} | {'Yes' if d.write_access else 'No'} |"
        )

    lines.append("\n## Routines\n")
    lines.append("| ID | Name | Start | Stop | Result |")
    lines.append("|----|------|-------|------|--------|")
    for r in sorted(spec.routines, key=lambda x: x.routine_id):
        lines.append(
            f"| {r.routine_id_hex} | {r.short_name} "
            f"| {'Yes' if r.start_supported else 'No'} "
            f"| {'Yes' if r.stop_supported else 'No'} "
            f"| {'Yes' if r.result_supported else 'No'} |"
        )

    lines.append("\n## DTCs\n")
    lines.append("| DTC | Name | Severity |")
    lines.append("|-----|------|----------|")
    for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
        lines.append(f"| {d.dtc_id_hex} | {d.short_name} | {d.severity} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helper: CSV export (returns ZIP bytes)
# ---------------------------------------------------------------------------

def _spec_to_csv_zip(spec: object) -> bytes:
    """Return a ZIP archive containing multiple CSV files for the specification."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # sessions.csv
        rows = ["id,name,p2_server_max,p2_star_server_max"]
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            rows.append(f"{s.session_id_hex},{s.short_name},{s.p2_server_max},{s.p2_star_server_max}")
        zf.writestr("sessions.csv", "\n".join(rows))

        # security_levels.csv
        rows = ["level,name,seed_size,key_size"]
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            rows.append(f"{s.security_level_hex},{s.short_name},{s.seed_size},{s.key_size}")
        zf.writestr("security_levels.csv", "\n".join(rows))

        # services.csv
        rows = ["sid,name,sub_function_count,nrc_count"]
        for s in sorted(spec.services, key=lambda x: x.service_id):
            rows.append(f"{s.service_id_hex},{s.short_name},{len(s.sub_functions)},{len(s.nrc_list)}")
        zf.writestr("services.csv", "\n".join(rows))

        # dids.csv
        rows = ["did,name,length,read_access,write_access"]
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            rows.append(
                f"{d.did_id_hex},{d.short_name},{d.total_byte_length},"
                f"{'1' if d.read_access else '0'},{'1' if d.write_access else '0'}"
            )
        zf.writestr("dids.csv", "\n".join(rows))

        # routines.csv
        rows = ["id,name,start_supported,stop_supported,result_supported"]
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            rows.append(
                f"{r.routine_id_hex},{r.short_name},"
                f"{'1' if r.start_supported else '0'},"
                f"{'1' if r.stop_supported else '0'},"
                f"{'1' if r.result_supported else '0'}"
            )
        zf.writestr("routines.csv", "\n".join(rows))

        # dtcs.csv
        rows = ["dtc,name,severity"]
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            rows.append(f"{d.dtc_id_hex},{d.short_name},{d.severity}")
        zf.writestr("dtcs.csv", "\n".join(rows))

    return buf.getvalue()


# ---------------------------------------------------------------------------
# Helper: dict export (for JSON/YAML)
# ---------------------------------------------------------------------------

def _spec_to_dict(spec: object) -> dict:
    """Convert a UdsSpecification to a plain dict for JSON/YAML serialisation."""
    return {
        "ecu_name": spec.ecu_name,
        "protocol_name": spec.protocol_name,
        "protocol_type": spec.protocol_type,
        "sessions": [
            {
                "id": s.session_id_hex,
                "name": s.short_name,
                "p2_server_max": s.p2_server_max,
                "p2_star_server_max": s.p2_star_server_max,
            }
            for s in sorted(spec.sessions, key=lambda x: x.session_id)
        ],
        "security_levels": [
            {
                "level": s.security_level_hex,
                "name": s.short_name,
                "seed_size": s.seed_size,
                "key_size": s.key_size,
            }
            for s in sorted(spec.security_levels, key=lambda x: x.security_level)
        ],
        "services": [
            {
                "sid": s.service_id_hex,
                "name": s.short_name,
                "sub_function_count": len(s.sub_functions),
                "nrc_count": len(s.nrc_list),
            }
            for s in sorted(spec.services, key=lambda x: x.service_id)
        ],
        "dids": [
            {
                "id": d.did_id_hex,
                "name": d.short_name,
                "length": d.total_byte_length,
                "read_access": d.read_access,
                "write_access": d.write_access,
            }
            for d in sorted(spec.dids, key=lambda x: x.did_id)
        ],
        "routines": [
            {
                "id": r.routine_id_hex,
                "name": r.short_name,
                "start_supported": r.start_supported,
                "stop_supported": r.stop_supported,
                "result_supported": r.result_supported,
            }
            for r in sorted(spec.routines, key=lambda x: x.routine_id)
        ],
        "dtcs": [
            {
                "id": d.dtc_id_hex,
                "name": d.short_name,
                "severity": d.severity,
            }
            for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)
        ],
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
) -> None:
    """Start the uvicorn web server.

    Args:
        host: Bind address (default: 127.0.0.1).
        port: TCP port (default: 8765).
        open_browser: If True, open the browser automatically after startup.
    """
    _require_fastapi()

    app = _create_app()
    url = f"http://{host}:{port}"

    if open_browser:
        def _open() -> None:
            import time
            time.sleep(0.5)
            webbrowser.open(url)

        t = threading.Thread(target=_open, daemon=True)
        t.start()

    logger.info("Starting udsxml2tex web server at %s", url)
    uvicorn.run(app, host=host, port=port)
