"""Tests for agenthive.models."""
import pytest
from unittest.mock import AsyncMock
from agenthive.models import Attachment, Message, Task


def test_attachment_creation():
    a = Attachment(id="att1", filename="file.txt", content_type="text/plain", url="http://example.com/file.txt")
    assert a.id == "att1"
    assert a.filename == "file.txt"
    assert a.content_type == "text/plain"
    assert a.url == "http://example.com/file.txt"


def test_message_from_dict_minimal():
    data = {"id": "msg1", "text": "hello", "thread_id": "t1", "space_id": "s1",
            "author_handle": "user1", "author_type": "human"}
    msg = Message.from_dict(data)
    assert msg.id == "msg1"
    assert msg.text == "hello"
    assert msg.thread_id == "t1"
    assert msg.space_id == "s1"
    assert msg.author_handle == "user1"
    assert msg.author_type == "human"
    assert msg.mentions == []
    assert msg.attachments == []
    assert msg.created_at == ""
    assert msg._api is None
    assert msg._task_id is None
    assert msg._agent_handle == ""


def test_message_from_dict_with_attachments():
    data = {
        "id": "msg2",
        "text": "see attachment",
        "thread_id": "t1",
        "space_id": "s1",
        "author_handle": "agent1",
        "author_type": "agent",
        "attachments": [
            {"id": "a1", "filename": "doc.pdf", "content_type": "application/pdf", "url": "http://x.com/doc.pdf"}
        ],
        "mentions": ["user2"],
        "created_at": "2024-01-01T00:00:00Z",
    }
    msg = Message.from_dict(data)
    assert len(msg.attachments) == 1
    assert msg.attachments[0].filename == "doc.pdf"
    assert msg.mentions == ["user2"]
    assert msg.created_at == "2024-01-01T00:00:00Z"


def test_message_from_dict_passes_api_and_task_id():
    mock_api = object()
    data = {"id": "msg3", "text": "hi", "thread_id": "t1", "space_id": "s1",
            "author_handle": "u", "author_type": "human"}
    msg = Message.from_dict(data, api=mock_api, task_id="task99")
    assert msg._api is mock_api
    assert msg._task_id == "task99"


async def test_message_reply_raises_without_api():
    data = {"id": "msg4", "text": "hi", "thread_id": "t1", "space_id": "s1",
            "author_handle": "u", "author_type": "human"}
    msg = Message.from_dict(data)
    with pytest.raises(RuntimeError, match="not bound to an API client"):
        await msg.reply("response")


async def test_message_reply_calls_api_with_agent_handle():
    mock_api = AsyncMock()
    mock_api.post_message.return_value = Message(
        id="reply1", text="response", thread_id="t1", space_id="s1",
        author_handle="agent", author_type="agent"
    )
    data = {"id": "msg5", "text": "hello", "thread_id": "t1", "space_id": "s1",
            "author_handle": "u", "author_type": "human"}
    msg = Message.from_dict(data, api=mock_api)
    msg._agent_handle = "bot"
    reply = await msg.reply("response", mentions=["u"])
    mock_api.post_message.assert_called_once_with(
        thread_id="t1", text="response", agent_handle="bot", mentions=["u"]
    )
    assert reply.id == "reply1"


async def test_message_reply_without_agent_handle():
    """reply() still works when _agent_handle is empty (backwards compat)."""
    mock_api = AsyncMock()
    mock_api.post_message.return_value = Message(
        id="reply1", text="response", thread_id="t1", space_id="s1",
        author_handle="agent", author_type="agent"
    )
    data = {"id": "msg5", "text": "hello", "thread_id": "t1", "space_id": "s1",
            "author_handle": "u", "author_type": "human"}
    msg = Message.from_dict(data, api=mock_api)
    await msg.reply("response")
    mock_api.post_message.assert_called_once_with(
        thread_id="t1", text="response", agent_handle="", mentions=None
    )


async def test_message_get_thread_history_raises_without_api():
    data = {"id": "msg6", "text": "hi", "thread_id": "t1", "space_id": "s1",
            "author_handle": "u", "author_type": "human"}
    msg = Message.from_dict(data)
    with pytest.raises(RuntimeError, match="not bound to an API client"):
        await msg.get_thread_history()


async def test_message_get_thread_history_calls_api():
    mock_api = AsyncMock()
    mock_api.get_messages.return_value = []
    data = {"id": "msg7", "text": "hi", "thread_id": "t1", "space_id": "s1",
            "author_handle": "u", "author_type": "human"}
    msg = Message.from_dict(data, api=mock_api)
    result = await msg.get_thread_history(limit=10)
    mock_api.get_messages.assert_called_once_with(thread_id="t1", limit=10)
    assert result == []


def test_task_defaults():
    task = Task(id="t1", thread_id="thread1")
    assert task.status == "queued"
    assert task.trigger_message_id is None
    assert task.agent_handle == ""
    assert task.backend == ""
    assert task.system_instruction == ""


def test_task_with_all_fields():
    task = Task(id="t1", thread_id="thread1", agent_handle="bot", backend="claude_code",
                trigger_message_id="msg1", status="running")
    assert task.status == "running"
    assert task.trigger_message_id == "msg1"
    assert task.agent_handle == "bot"
    assert task.backend == "claude_code"


def test_task_with_system_instruction():
    """Task carries per-agent system_instruction from the server."""
    task = Task(
        id="t1", thread_id="thread1", agent_handle="eng-bot",
        system_instruction="You are a senior engineer.",
    )
    assert task.system_instruction == "You are a senior engineer."


def test_message_system_instruction_field():
    """Message has a _system_instruction field for per-agent instructions."""
    msg = Message(
        id="m1", text="hello", thread_id="t1", space_id="s1",
        author_handle="user", author_type="human",
    )
    assert msg._system_instruction == ""
    msg._system_instruction = "You are a TPM."
    assert msg._system_instruction == "You are a TPM."
