import pytest
from agenthive.local_runner import build_user_prompt, build_resume_prompt, build_system_prompt, build_prompt
from agenthive.models import Message

def test_build_user_prompt_no_quote():
    history = [
        Message(id="1", text="hello", thread_id="t1", space_id="s1", author_handle="user1", author_type="human"),
        Message(id="2", text="hi there", thread_id="t1", space_id="s1", author_handle="agent1", author_type="agent")
    ]
    prompt = build_user_prompt(history)
    assert "@user1: hello" in prompt
    assert "@agent1: hi there" in prompt
    assert "MANDATORY_REPLY: NO" in prompt
    # Ensure no empty "In response to" blocks
    assert "In response to" not in prompt

def test_build_user_prompt_with_quote():
    history = [
        Message(id="1", text="original message", thread_id="t1", space_id="s1", author_handle="user1", author_type="human"),
        Message(
            id="2", 
            text="reply with quote", 
            thread_id="t1", 
            space_id="s1", 
            author_handle="agent1", 
            author_type="agent",
            quoted_message_id="1",
            quoted_message={"author_handle": "user1", "text": "original message"}
        )
    ]
    prompt = build_user_prompt(history)
    assert "@user1: original message" in prompt
    assert '@agent1: (In response to @user1: "original message") reply with quote' in prompt

def test_build_resume_prompt_with_quote():
    new_messages = [
        Message(
            id="2", 
            text="reply with quote", 
            thread_id="t1", 
            space_id="s1", 
            author_handle="agent1", 
            author_type="agent",
            quoted_message_id="1",
            quoted_message={"author_handle": "user1", "text": "original message"}
        )
    ]
    prompt = build_resume_prompt(new_messages, handle="agent1", must_reply=True)
    assert '@agent1: (In response to @user1: "original message") reply with quote' in prompt
    assert "You were directly addressed. You MUST reply — do not output PASS." in prompt


def test_build_system_prompt_includes_custom_instruction():
    """Per-agent system_instruction is included in the system prompt."""
    prompt = build_system_prompt(
        "You are a senior Python engineer.",
        "claude-eng",
    )
    assert "You are a senior Python engineer." in prompt
    assert "@claude-eng" in prompt


def test_build_system_prompt_includes_space_rules():
    """space_rules are injected as Project Rules."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        space_rules="Always respond in bullet points.\nNo emojis.",
    )
    assert "## Project Rules" in prompt
    assert "Always respond in bullet points." in prompt
    assert "No emojis." in prompt


def test_build_system_prompt_omits_empty_rules():
    """Empty space_rules should not produce a Project Rules section."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        space_rules="",
    )
    assert "## Project Rules" not in prompt


def test_build_system_prompt_includes_memory_context():
    """Memory context is appended to the system prompt."""
    prompt = build_system_prompt(
        "You are a helpful assistant.",
        "test-bot",
        memory_context="SELF: I prefer concise answers.",
    )
    assert "SELF: I prefer concise answers." in prompt


def test_build_prompt_uses_per_agent_instruction():
    """build_prompt passes system_instruction through to the system prompt."""
    history = [
        Message(id="1", text="hello", thread_id="t1", space_id="s1",
                author_handle="human", author_type="human"),
    ]
    prompt = build_prompt(
        history,
        "You are the TPM responsible for project tracking.",
        "claude-tpm",
        space_rules="Ship weekly updates.",
    )
    assert "You are the TPM responsible for project tracking." in prompt
    assert "@claude-tpm" in prompt
    assert "## Project Rules" in prompt
    assert "Ship weekly updates." in prompt
    assert "@human: hello" in prompt


def test_build_resume_prompt_includes_project_rules():
    """Resume prompt includes project rules as a context reminder."""
    new_messages = [
        Message(id="1", text="what's the plan?", thread_id="t1", space_id="s1",
                author_handle="human", author_type="human"),
    ]
    prompt = build_resume_prompt(
        new_messages, handle="bot",
        must_reply=True,
        space_rules="Always use TypeScript.\nNo console.log in prod.",
    )
    assert "Context reminder" in prompt
    assert "Project Rules:" in prompt
    assert "Always use TypeScript." in prompt
    assert "No console.log in prod." in prompt
    assert "@human: what's the plan?" in prompt


def test_build_resume_prompt_includes_memory_context():
    """Resume prompt includes memory context as a reminder."""
    new_messages = [
        Message(id="1", text="hi", thread_id="t1", space_id="s1",
                author_handle="human", author_type="human"),
    ]
    prompt = build_resume_prompt(
        new_messages, handle="bot",
        memory_context="LEARNED: The codebase uses FastAPI with aiosqlite.",
    )
    assert "Context reminder" in prompt
    assert "LEARNED: The codebase uses FastAPI with aiosqlite." in prompt


def test_build_resume_prompt_no_context_when_empty():
    """Resume prompt omits context reminder when no rules or memory."""
    new_messages = [
        Message(id="1", text="hi", thread_id="t1", space_id="s1",
                author_handle="human", author_type="human"),
    ]
    prompt = build_resume_prompt(new_messages, handle="bot")
    assert "Context reminder" not in prompt
    assert "Project Rules:" not in prompt


def test_build_resume_prompt_backwards_compatible():
    """Resume prompt still works without the new kwargs (backwards compat)."""
    new_messages = [
        Message(id="1", text="hello", thread_id="t1", space_id="s1",
                author_handle="user1", author_type="human"),
    ]
    prompt = build_resume_prompt(new_messages, handle="bot", must_reply=False)
    assert "@user1: hello" in prompt
    assert 'output exactly "PASS"' in prompt
    assert "Context reminder" not in prompt
