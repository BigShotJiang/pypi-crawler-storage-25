"""Tests for agenthive.api using respx for HTTP mocking."""
import json

import pytest
import respx
import httpx
from agenthive.api import AgentAPI
from agenthive.models import Message


@pytest.fixture
def api():
    return AgentAPI(server_url="http://testserver", token="test-token")


@pytest.fixture(autouse=True)
async def close_api(api):
    yield
    await api.close()


async def test_get_me(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/backends/me").mock(
            return_value=httpx.Response(200, json={"id": "backend1", "label": "my-machine"})
        )
        result = await api.get_me()
    assert result["id"] == "backend1"
    assert result["label"] == "my-machine"


async def test_get_me_sends_auth_header(api):
    with respx.mock(base_url="http://testserver") as mock:
        route = mock.get("/api/backends/me").mock(
            return_value=httpx.Response(200, json={"id": "b1", "label": "m"})
        )
        await api.get_me()
    assert route.called
    request = route.calls[0].request
    assert request.headers["Authorization"] == "Bearer test-token"


async def test_get_tasks(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/backends/me/tasks").mock(
            return_value=httpx.Response(200, json=[{"id": "task1", "status": "queued"}])
        )
        result = await api.get_tasks()
    assert len(result) == 1
    assert result[0]["id"] == "task1"


async def test_ack_task(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.post("/api/backends/me/tasks/task1/ack").mock(
            return_value=httpx.Response(200, json={"status": "running"})
        )
        result = await api.ack_task("task1")
    assert result["status"] == "running"


async def test_complete_task(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.post("/api/backends/me/tasks/task1/complete").mock(
            return_value=httpx.Response(200, json={"status": "completed"})
        )
        result = await api.complete_task("task1")
    assert result["status"] == "completed"


async def test_fail_task(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.post("/api/backends/me/tasks/task1/fail").mock(
            return_value=httpx.Response(200, json={"status": "failed"})
        )
        result = await api.fail_task("task1", error="something went wrong")
    assert result["status"] == "failed"


async def test_get_messages_returns_message_objects(api):
    messages_data = [
        {"id": "m1", "text": "hello", "thread_id": "t1", "space_id": "s1",
         "author_handle": "user1", "author_type": "human"},
        {"id": "m2", "text": "world", "thread_id": "t1", "space_id": "s1",
         "author_handle": "user2", "author_type": "human"},
    ]
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/threads/t1/messages").mock(
            return_value=httpx.Response(200, json=messages_data)
        )
        result = await api.get_messages("t1")
    assert len(result) == 2
    assert all(isinstance(m, Message) for m in result)
    assert result[0].id == "m1"
    assert result[1].text == "world"


async def test_get_messages_respects_limit(api):
    messages_data = [
        {"id": f"m{i}", "text": f"msg{i}", "thread_id": "t1", "space_id": "s1",
         "author_handle": "u", "author_type": "human"}
        for i in range(10)
    ]
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/threads/t1/messages").mock(
            return_value=httpx.Response(200, json=messages_data)
        )
        result = await api.get_messages("t1", limit=3)
    assert len(result) == 3
    assert result[0].id == "m7"


async def test_post_message(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.post("/api/threads/t1/messages").mock(
            return_value=httpx.Response(200, json={
                "id": "new_msg", "text": "hello there", "thread_id": "t1",
                "space_id": "s1", "author_handle": "myagent", "author_type": "agent"
            })
        )
        result = await api.post_message("t1", "hello there", agent_handle="myagent")
    assert isinstance(result, Message)
    assert result.id == "new_msg"
    assert result.text == "hello there"


async def test_post_message_sends_agent_handle(api):
    with respx.mock(base_url="http://testserver") as mock:
        route = mock.post("/api/threads/t1/messages").mock(
            return_value=httpx.Response(200, json={
                "id": "m1", "text": "hi", "thread_id": "t1",
                "space_id": "s1", "author_handle": "bot", "author_type": "agent"
            })
        )
        await api.post_message("t1", "hi", agent_handle="bot")
    request = route.calls[0].request
    # Form-encoded body
    body = request.content.decode()
    assert "agent_handle=bot" in body


async def test_get_messages_binds_api(api):
    messages_data = [
        {"id": "m1", "text": "hi", "thread_id": "t1", "space_id": "s1",
         "author_handle": "u", "author_type": "human"}
    ]
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/threads/t1/messages").mock(
            return_value=httpx.Response(200, json=messages_data)
        )
        result = await api.get_messages("t1")
    assert result[0]._api is api


async def test_get_me_raises_on_error(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/backends/me").mock(
            return_value=httpx.Response(401, json={"error": "unauthorized"})
        )
        with pytest.raises(httpx.HTTPStatusError):
            await api.get_me()


# ------------------------------------------------------------------
# Memory endpoints
# ------------------------------------------------------------------


async def test_save_memories(api):
    memories = [
        {"domain": "self", "subject": None, "content": "I prefer pytest"},
        {"domain": "project", "subject": "backend", "content": "Uses FastAPI"},
    ]
    with respx.mock(base_url="http://testserver") as mock:
        route = mock.post("/api/backends/me/memories").mock(
            return_value=httpx.Response(200, json={"saved": 2})
        )
        result = await api.save_memories(memories, space_id="s1", thread_id="t1", agent_handle="bot")
    assert result["saved"] == 2
    # Verify request body
    request = route.calls[0].request
    body = json.loads(request.content)
    assert body["memories"] == memories
    assert body["space_id"] == "s1"
    assert body["thread_id"] == "t1"
    assert body["agent_handle"] == "bot"


async def test_save_memories_with_corrections_and_participants(api):
    memories = [{"domain": "self", "subject": None, "content": "I prefer pytest"}]
    corrections = [{"domain": "peer", "subject": "alice", "content": "Alice uses Go"}]
    participants = ["alice", "bot"]
    with respx.mock(base_url="http://testserver") as mock:
        route = mock.post("/api/backends/me/memories").mock(
            return_value=httpx.Response(200, json={"saved": 2})
        )
        result = await api.save_memories(
            memories, space_id="s1", thread_id="t1", agent_handle="bot",
            corrections=corrections, participants=participants,
        )
    assert result["saved"] == 2
    body = json.loads(route.calls[0].request.content)
    assert body["corrections"] == corrections
    assert body["participants"] == participants


async def test_save_memories_empty_list(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.post("/api/backends/me/memories").mock(
            return_value=httpx.Response(200, json={"saved": 0})
        )
        result = await api.save_memories([])
    assert result["saved"] == 0


async def test_get_memory_context(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/backends/me/memories").mock(
            return_value=httpx.Response(200, json={
                "context": "## My Memory\n### About Myself\n- I prefer pytest"
            })
        )
        result = await api.get_memory_context(space_id="s1", agent_handle="bot")
    context, rules = result
    assert "My Memory" in context


async def test_get_memory_context_with_participants(api):
    with respx.mock(base_url="http://testserver") as mock:
        route = mock.get("/api/backends/me/memories").mock(
            return_value=httpx.Response(200, json={"context": "some context"})
        )
        result = await api.get_memory_context(
            space_id="s1", participants=["alice", "bob"]
        )
    context, rules = result
    assert context == "some context"
    request = route.calls[0].request
    assert "participants=alice%2Cbob" in str(request.url) or "participants=alice,bob" in str(request.url)


async def test_get_memory_context_empty(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.get("/api/backends/me/memories").mock(
            return_value=httpx.Response(200, json={})
        )
        result = await api.get_memory_context()
    context, rules = result
    assert context == ""


# ------------------------------------------------------------------
# Stats endpoint
# ------------------------------------------------------------------


async def test_report_stats(api):
    stats = {
        "thread_id": "t1",
        "backend": "claude_code",
        "agent_handle": "bot",
        "input_tokens": 1000,
        "output_tokens": 500,
    }
    with respx.mock(base_url="http://testserver") as mock:
        route = mock.post("/api/backends/me/stats").mock(
            return_value=httpx.Response(200, json={"ok": True})
        )
        result = await api.report_stats(stats)
    assert result["ok"] is True
    request = route.calls[0].request
    body = json.loads(request.content)
    assert body["input_tokens"] == 1000


async def test_report_stats_raises_on_error(api):
    with respx.mock(base_url="http://testserver") as mock:
        mock.post("/api/backends/me/stats").mock(
            return_value=httpx.Response(500, json={"error": "internal"})
        )
        with pytest.raises(httpx.HTTPStatusError):
            await api.report_stats({"thread_id": "t1"})
