"""Tests for agenthive.memory — memory tag extraction and guardrails."""
import pytest
from agenthive.memory import extract_memory_tags


class TestExtractMemoryTags:
    """Basic extraction tests."""

    def test_no_delimiter_returns_original_text(self):
        text = "Hello world, this is a response."
        clean, memories, _ = extract_memory_tags(text)
        assert clean == text
        assert memories == []

    def test_empty_string(self):
        clean, memories, _ = extract_memory_tags("")
        assert clean == ""
        assert memories == []

    def test_single_memory_tag(self):
        text = (
            "Here is my response.\n"
            "---\n"
            "[MEMORY: project | my-project | The API uses REST endpoints]"
        )
        clean, memories, _ = extract_memory_tags(text)
        assert clean == "Here is my response."
        assert len(memories) == 1
        assert memories[0]["domain"] == "project"
        assert memories[0]["subject"] == "my-project"
        assert memories[0]["content"] == "The API uses REST endpoints"

    def test_multiple_memory_tags(self):
        text = (
            "Done with the review.\n"
            "---\n"
            "[MEMORY: self | | I prefer concise code reviews]\n"
            "[MEMORY: learned | | Python 3.12 has better error messages]\n"
            "[MEMORY: project | backend | Uses FastAPI with SQLAlchemy]"
        )
        clean, memories, _ = extract_memory_tags(text)
        assert clean == "Done with the review."
        assert len(memories) == 3
        assert memories[0]["domain"] == "self"
        assert memories[0]["subject"] is None
        assert memories[1]["domain"] == "learned"
        assert memories[2]["domain"] == "project"
        assert memories[2]["subject"] == "backend"

    def test_delimiter_at_end_no_tags_preserves_text(self):
        """A --- without memory tags is just markdown — full text preserved."""
        text = "Some response.\n---\nJust some notes without tags."
        clean, memories, _ = extract_memory_tags(text)
        assert clean == text  # Full text preserved, not stripped
        assert memories == []

    def test_multiple_delimiters_uses_last(self):
        text = (
            "First section.\n---\nMiddle section.\n---\n"
            "[MEMORY: self | | I remember this]"
        )
        clean, memories, _ = extract_memory_tags(text)
        # rfind gets the last delimiter
        assert "First section." in clean
        assert "Middle section." in clean
        assert len(memories) == 1

    def test_markdown_hr_not_stripped(self):
        """A --- used as markdown horizontal rule must NOT truncate the response."""
        response = (
            "Here's my assessment for Track 1:\n"
            "\n---\n\n"
            "**Priority**: High\n"
            "**Status**: On track\n"
            "\n---\n\n"
            "And here's the summary."
        )
        clean, memories, _ = extract_memory_tags(response)
        assert clean == response
        assert memories == []

    def test_markdown_hr_with_trailing_content_not_stripped(self):
        """Response with --- followed by normal text (not memory tags) is preserved."""
        response = (
            "Good. Here's my assessment:\n"
            "\n---\n\n"
            "Track 1: Approval system\n"
            "Track 2: Quote/reply feature"
        )
        clean, memories, _ = extract_memory_tags(response)
        assert clean == response
        assert memories == []

    def test_memory_tags_after_markdown_hrs(self):
        """Memory tags at the end still work even when earlier --- exist."""
        response = (
            "My analysis:\n"
            "\n---\n\n"
            "Section two content.\n"
            "\n---\n"
            "[MEMORY: self | | Key insight about the codebase]"
        )
        clean, memories, _ = extract_memory_tags(response)
        assert "My analysis:" in clean
        assert "Section two content." in clean
        assert len(memories) == 1
        assert memories[0]["content"] == "Key insight about the codebase"

    def test_all_domains(self):
        text = (
            "Response.\n---\n"
            "[MEMORY: self | | Note about self]\n"
            "[MEMORY: peer | alice | Alice prefers TypeScript]\n"
            "[MEMORY: project | proj1 | Uses microservices]\n"
            "[MEMORY: learned | | Redis supports pub/sub]"
        )
        _, memories, _ = extract_memory_tags(text)
        domains = [m["domain"] for m in memories]
        assert domains == ["self", "peer", "project", "learned"]


class TestSubjectiveGuardrail:
    """Peer memories with subjective language should be filtered out."""

    @pytest.mark.parametrize("subjective_word", [
        "slow", "fast", "lazy", "brilliant", "terrible", "great",
        "mediocre", "incompetent", "careless", "sloppy", "unreliable",
    ])
    def test_filters_subjective_adjectives(self, subjective_word):
        text = (
            "Done.\n---\n"
            f"[MEMORY: peer | bob | Bob is {subjective_word} at code reviews]"
        )
        _, memories, _ = extract_memory_tags(text)
        assert memories == []

    @pytest.mark.parametrize("pattern", [
        "tends to overcomplicate things",
        "always misses deadlines",
        "never follows up",
        "usually late",
        "struggles with testing",
    ])
    def test_filters_behavioral_patterns(self, pattern):
        text = f"Done.\n---\n[MEMORY: peer | bob | Bob {pattern}]"
        _, memories, _ = extract_memory_tags(text)
        assert memories == []

    @pytest.mark.parametrize("pattern", [
        "overcomplicates the architecture",
        "over-engineers solutions",
        "too slow in reviews",
        "doesn't listen to feedback",
        "hard to work with",
    ])
    def test_filters_negative_patterns(self, pattern):
        text = f"Done.\n---\n[MEMORY: peer | bob | Bob {pattern}]"
        _, memories, _ = extract_memory_tags(text)
        assert memories == []

    def test_allows_factual_peer_memory(self):
        text = (
            "Done.\n---\n"
            "[MEMORY: peer | alice | Alice specializes in database optimization]"
        )
        _, memories, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "Alice specializes in database optimization"

    def test_subjective_filter_only_applies_to_peer(self):
        """Subjective words in non-peer domains should not be filtered."""
        text = (
            "Done.\n---\n"
            "[MEMORY: self | | I am slow at debugging]\n"
            "[MEMORY: learned | | Fast algorithms use memoization]"
        )
        _, memories, _ = extract_memory_tags(text)
        # "slow" and "fast" are subjective but domain is not peer
        assert len(memories) == 2


class TestSelfIdentityGuardrail:
    """Self-identity rewrites should be filtered out."""

    @pytest.mark.parametrize("prefix", [
        "I am a senior engineer",
        "My role is to review code",
        "I'm a project manager",
    ])
    def test_filters_identity_rewrites(self, prefix):
        text = f"Done.\n---\n[MEMORY: self | | {prefix}]"
        _, memories, _ = extract_memory_tags(text)
        assert memories == []

    def test_allows_non_identity_self_memory(self):
        text = "Done.\n---\n[MEMORY: self | | I prefer using pytest over unittest]"
        _, memories, _ = extract_memory_tags(text)
        assert len(memories) == 1

    def test_identity_filter_only_applies_to_self(self):
        """Identity keywords in non-self domains should not be filtered."""
        text = (
            "Done.\n---\n"
            "[MEMORY: learned | | I am a concept is important in philosophy]"
        )
        _, memories, _ = extract_memory_tags(text)
        assert len(memories) == 1


class TestEdgeCases:
    """Edge cases and malformed inputs."""

    def test_malformed_tag_missing_pipes(self):
        text = "Done.\n---\n[MEMORY: self content without pipes]"
        _, memories, _ = extract_memory_tags(text)
        assert memories == []

    def test_malformed_tag_wrong_domain(self):
        text = "Done.\n---\n[MEMORY: unknown | subject | content]"
        _, memories, _ = extract_memory_tags(text)
        assert memories == []

    def test_whitespace_handling_in_tags(self):
        text = "Done.\n---\n[MEMORY:  self  |  subject  |  content with spaces  ]"
        _, memories, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["subject"] == "subject"
        assert memories[0]["content"] == "content with spaces"

    def test_body_preserved_exactly(self):
        body = "Line 1\n\nLine 3\n  indented"
        text = f"{body}\n---\n[MEMORY: self | | note]"
        clean, _, _ = extract_memory_tags(text)
        assert clean == body

    def test_tags_before_delimiter_ignored(self):
        text = (
            "[MEMORY: self | | should be ignored]\n"
            "Some response.\n---\n"
            "[MEMORY: self | | should be captured]"
        )
        clean, memories, _ = extract_memory_tags(text)
        assert len(memories) == 1
        assert memories[0]["content"] == "should be captured"
        assert "[MEMORY:" in clean  # the pre-delimiter tag is in the body


class TestCorrectionTags:
    """Tests for [MEMORY:correct | domain | subject | content] extraction."""

    def test_correction_tag_extracted(self):
        text = (
            "Done.\n---\n"
            "[MEMORY:correct | peer | alice | Alice specializes in Go, not Python]"
        )
        _, memories, corrections = extract_memory_tags(text)
        assert memories == []
        assert len(corrections) == 1
        assert corrections[0]["domain"] == "peer"
        assert corrections[0]["subject"] == "alice"
        assert corrections[0]["content"] == "Alice specializes in Go, not Python"

    def test_mixed_memories_and_corrections(self):
        text = (
            "Done.\n---\n"
            "[MEMORY: self | | I learned pytest fixtures]\n"
            "[MEMORY:correct | learned | | Python 3.12 has better tracebacks, not 3.11]\n"
            "[MEMORY: peer | bob | Bob owns the CI pipeline]"
        )
        _, memories, corrections = extract_memory_tags(text)
        assert len(memories) == 2
        assert len(corrections) == 1
        assert corrections[0]["domain"] == "learned"
        assert corrections[0]["content"] == "Python 3.12 has better tracebacks, not 3.11"

    def test_correction_only_no_regular_memories(self):
        text = "Done.\n---\n[MEMORY:correct | project | backend | Actually uses Django, not FastAPI]"
        _, memories, corrections = extract_memory_tags(text)
        assert memories == []
        assert len(corrections) == 1

    def test_no_delimiter_returns_empty_corrections(self):
        text = "Just a response."
        _, _, corrections = extract_memory_tags(text)
        assert corrections == []

    def test_correction_with_extra_whitespace(self):
        text = "Done.\n---\n[MEMORY:correct  |  self  |  |  Fixed my understanding of asyncio  ]"
        _, _, corrections = extract_memory_tags(text)
        assert len(corrections) == 1
        assert corrections[0]["domain"] == "self"
        assert corrections[0]["subject"] is None
        assert corrections[0]["content"] == "Fixed my understanding of asyncio"

    def test_correction_invalid_domain_ignored(self):
        text = "Done.\n---\n[MEMORY:correct | unknown | | content]"
        _, _, corrections = extract_memory_tags(text)
        assert corrections == []
