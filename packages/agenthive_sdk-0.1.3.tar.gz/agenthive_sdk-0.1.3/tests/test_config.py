"""Tests for agenthive.config module."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from agenthive.config import (
    Config,
    ConfigError,
    detect_backends,
    load_config,
    save_config,
    validate_config,
)


@pytest.fixture
def config_dir(tmp_path, monkeypatch):
    """Redirect config paths to a temp directory."""
    monkeypatch.setattr("agenthive.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("agenthive.config.CONFIG_FILE", tmp_path / "config.json")
    monkeypatch.setattr("agenthive.config.PID_FILE", tmp_path / "daemon.pid")
    monkeypatch.setattr("agenthive.config.LOG_FILE", tmp_path / "daemon.log")
    return tmp_path


class TestSaveAndLoad:
    def test_round_trip(self, config_dir):
        config = Config(
            server_url="https://example.com",
            token="ahv_abc123",
            backends={"claude_code": True, "codex": False},
            auto_start=True,
            log_level="debug",
        )
        save_config(config)
        loaded = load_config()
        assert loaded.server_url == "https://example.com"
        assert loaded.token == "ahv_abc123"
        assert loaded.backends == {"claude_code": True, "codex": False}
        assert loaded.auto_start is True
        assert loaded.log_level == "debug"

    def test_load_missing_file(self, config_dir):
        with pytest.raises(ConfigError, match="Config not found"):
            load_config()

    def test_load_invalid_json(self, config_dir):
        (config_dir / "config.json").write_text("not json{")
        with pytest.raises(ConfigError, match="Invalid config"):
            load_config()

    def test_save_creates_directory(self, tmp_path, monkeypatch):
        nested = tmp_path / "a" / "b"
        monkeypatch.setattr("agenthive.config.CONFIG_DIR", nested)
        monkeypatch.setattr("agenthive.config.CONFIG_FILE", nested / "config.json")
        save_config(Config(server_url="http://x", token="ahv_t"))
        assert (nested / "config.json").exists()

    def test_load_defaults(self, config_dir):
        """Missing fields in JSON get defaults."""
        (config_dir / "config.json").write_text('{"server_url": "http://x"}')
        config = load_config()
        assert config.server_url == "http://x"
        assert config.token == ""
        assert config.backends == {}
        assert config.auto_start is False


class TestValidate:
    def test_valid_config(self):
        config = Config(
            server_url="https://app.agenthive.ai",
            token="ahv_abc123",
            backends={"claude_code": True},
        )
        assert validate_config(config) == []

    def test_missing_server(self):
        config = Config(token="ahv_abc", backends={"claude_code": True})
        errors = validate_config(config)
        assert any("server_url" in e for e in errors)

    def test_missing_token(self):
        config = Config(server_url="http://x", backends={"claude_code": True})
        errors = validate_config(config)
        assert any("token is required" in e for e in errors)

    def test_bad_token_prefix(self):
        config = Config(server_url="http://x", token="bad_token", backends={"claude_code": True})
        errors = validate_config(config)
        assert any("ahv_" in e for e in errors)

    def test_no_backends_enabled(self):
        config = Config(server_url="http://x", token="ahv_abc", backends={"codex": False})
        errors = validate_config(config)
        assert any("backend" in e.lower() for e in errors)


class TestDetectBackends:
    def test_returns_dict(self):
        result = detect_backends()
        assert isinstance(result, dict)
        # Should have at least the registered backends
        assert "claude_code" in result
        assert "opencode" in result

    def test_values_are_bools(self):
        result = detect_backends()
        for v in result.values():
            assert isinstance(v, bool)
