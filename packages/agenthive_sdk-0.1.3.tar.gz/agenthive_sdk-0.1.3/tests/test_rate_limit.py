"""Tests for agenthive.rate_limit — rate limit classification and truncation detection."""
import asyncio

import pytest
from agenthive.rate_limit import (
    RateLimitError,
    classify_rate_limit,
    is_truncated,
    retry_with_backoff,
)


class TestClassifyRateLimit:
    """Test rate-limit pattern matching."""

    @pytest.mark.parametrize("text", [
        "TerminalQuotaError: you have exceeded your quota",
        "QUOTA_EXHAUSTED for this billing period",
        "You have exhausted your API capacity",
        "rate_limited error: too many requests",
        "Rate limited exceeded, please wait",
        "HTTP 429 Too Many Requests",
        "status code 429",
        "too many requests, please retry later",
        "ResourceExhausted: quota depleted",
    ])
    def test_detects_rate_limit_patterns(self, text):
        result = classify_rate_limit(text)
        assert result is not None

    def test_returns_context_snippet(self):
        text = "prefix " * 20 + "HTTP 429 error" + " suffix" * 20
        result = classify_rate_limit(text)
        assert result is not None
        assert "429" in result

    @pytest.mark.parametrize("text", [
        "Everything is working fine",
        "The agent responded successfully",
        "No errors detected",
        "Completed in 2.3 seconds",
        "",
    ])
    def test_no_false_positives(self, text):
        assert classify_rate_limit(text) is None


class TestIsTruncated:
    """Test truncation detection."""

    def test_max_tokens_stop_reason(self):
        assert is_truncated("any text", "max_tokens") is True

    def test_normal_stop_reason(self):
        assert is_truncated("Normal response text.", "end_turn") is False
        assert is_truncated("Normal response text.", None) is False

    def test_short_text_ending_with_colon(self):
        assert is_truncated("## Next Steps:", None) is True

    def test_short_text_ending_with_em_dash(self):
        assert is_truncated("The implementation\u2014", None) is True

    def test_long_text_ending_with_colon_not_truncated(self):
        long_text = "a" * 300 + ":"
        assert is_truncated(long_text, None) is False

    def test_empty_text_not_truncated(self):
        assert is_truncated("", None) is False

    def test_normal_short_text(self):
        assert is_truncated("PASS", None) is False
        assert is_truncated("Looks good to me!", None) is False


class TestRateLimitError:
    """Test RateLimitError exception."""

    def test_attributes(self):
        exc = RateLimitError("claude_code", "HTTP 429", attempt=2)
        assert exc.backend == "claude_code"
        assert exc.raw_error == "HTTP 429"
        assert exc.attempt == 2
        assert "claude_code" in str(exc)


class TestRetryWithBackoff:
    """Test the retry_with_backoff helper."""

    async def test_succeeds_first_try(self):
        call_count = 0

        async def succeed():
            nonlocal call_count
            call_count += 1
            return "ok"

        result = await retry_with_backoff(succeed, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert call_count == 1

    async def test_retries_on_rate_limit(self):
        call_count = 0

        async def fail_then_succeed():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise RateLimitError("test", "rate limited", call_count)
            return "ok"

        result = await retry_with_backoff(fail_then_succeed, max_retries=3, base_delay=0.01)
        assert result == "ok"
        assert call_count == 3

    async def test_exhausts_retries(self):
        async def always_fail():
            raise RateLimitError("test", "rate limited")

        with pytest.raises(RateLimitError):
            await retry_with_backoff(always_fail, max_retries=2, base_delay=0.01)

    async def test_non_rate_limit_error_propagates(self):
        async def raise_other():
            raise ValueError("not a rate limit")

        with pytest.raises(ValueError, match="not a rate limit"):
            await retry_with_backoff(raise_other, max_retries=3, base_delay=0.01)
