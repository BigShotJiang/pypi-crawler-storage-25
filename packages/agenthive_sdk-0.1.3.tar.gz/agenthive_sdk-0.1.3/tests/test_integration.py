"""SDK integration test against the FastAPI backend (in-process).

Uses httpx.ASGITransport to run the backend without a network, then
exercises the SDK's AgentAPI against it. This validates the contract
between SDK and server without needing a live server.

Run with: cd sdk && python -m pytest tests/test_integration.py -x -q
"""

from __future__ import annotations

import hashlib
import uuid
from datetime import datetime, timezone

import aiosqlite
import httpx
import pytest
import pytest_asyncio

# We need to import the backend app and set up a test DB
# This test runs from the sdk/ directory but needs access to the backend
import sys
from pathlib import Path

# Add project root to path so we can import backend
project_root = str(Path(__file__).parent.parent.parent)
if project_root not in sys.path:
    sys.path.insert(0, project_root)


@pytest_asyncio.fixture
async def backend_app():
    """Set up backend app with in-memory DB and test data."""
    from unittest.mock import patch

    from backend.database import SCHEMA

    db = await aiosqlite.connect(":memory:")
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA foreign_keys=ON")
    await db.executescript(SCHEMA)
    await db.commit()

    now = datetime.now(timezone.utc).isoformat()

    # Create test user
    user_id = str(uuid.uuid4())
    await db.execute(
        "INSERT INTO users (id, clerk_user_id, email, display_name, status, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, "clerk-integ", "integ@test.local", "Integration User", "active", now),
    )

    # Create test project
    project_id = str(uuid.uuid4())
    await db.execute(
        "INSERT INTO projects (id, name, description, rules, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
        (project_id, "Integration Test", "test", "Be concise", now, now),
    )
    await db.execute(
        "INSERT INTO project_users (project_id, user_id, role, created_at) VALUES (?, ?, ?, ?)",
        (project_id, user_id, "owner", now),
    )

    # Create backend machine
    backend_id = str(uuid.uuid4())
    await db.execute(
        """INSERT INTO agent_backends (id, project_id, user_id, label, supported_backends, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (backend_id, project_id, user_id, "Test Backend", '["claude_code"]', now, now),
    )

    # Create SDK token
    sdk_token = "ahv_integration_test_token_000000000000000000000000000000000000"
    token_hash = hashlib.sha256(sdk_token.encode()).hexdigest()
    await db.execute(
        "INSERT INTO backend_tokens (id, agent_backend_id, token_hash, label, created_at) VALUES (?, ?, ?, ?, ?)",
        (str(uuid.uuid4()), backend_id, token_hash, "SDK Token", now),
    )

    # Create agent assigned to this backend
    agent_id = str(uuid.uuid4())
    await db.execute(
        """INSERT INTO agents (id, project_id, handle, display_name, backend, role_description,
           system_instruction, agent_backend_id, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (agent_id, project_id, "integ-agent", "Integration Agent", "claude_code",
         "Test", "You are a test agent.", backend_id, now, now),
    )

    # Create a space + thread for task tests
    space_id = str(uuid.uuid4())
    await db.execute(
        "INSERT INTO spaces (id, project_id, name, description, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
        (space_id, project_id, "integ-space", "test", now, now),
    )
    await db.execute(
        "INSERT INTO space_members (space_id, agent_id, added_at) VALUES (?, ?, ?)",
        (space_id, agent_id, now),
    )

    thread_id = str(uuid.uuid4())
    await db.execute(
        "INSERT INTO threads (id, space_id, title, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
        (thread_id, space_id, "Integration Thread", now, now),
    )

    await db.commit()

    from backend.main import app

    with patch("backend.database._db", db), patch("backend.database.get_db", return_value=db):
        yield {
            "app": app,
            "token": sdk_token,
            "project_id": project_id,
            "backend_id": backend_id,
            "agent_id": agent_id,
            "agent_handle": "integ-agent",
            "space_id": space_id,
            "thread_id": thread_id,
        }

    await db.close()


@pytest_asyncio.fixture
async def sdk_client(backend_app):
    """Create an httpx client bound to the test backend app."""
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=backend_app["app"]),
        base_url="http://testserver",
        headers={"Authorization": f"Bearer {backend_app['token']}"},
    ) as client:
        yield client


class TestSDKIntegration:
    """Integration tests validating SDK-to-server contract."""

    async def test_identity_check(self, sdk_client, backend_app):
        """GET /api/backends/me returns backend identity with agents."""
        resp = await sdk_client.get("/api/backends/me")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == backend_app["backend_id"]
        assert data["project_id"] == backend_app["project_id"]
        assert len(data["agents"]) == 1
        assert data["agents"][0]["handle"] == "integ-agent"

    async def test_empty_task_list(self, sdk_client):
        """GET /api/backends/me/tasks returns empty when nothing queued."""
        resp = await sdk_client.get("/api/backends/me/tasks?status=queued")
        assert resp.status_code == 200
        assert resp.json() == []

    async def test_memory_save_and_retrieve(self, sdk_client, backend_app):
        """POST /api/backends/me/memories → GET /api/backends/me/memories round-trip."""
        # Save
        resp = await sdk_client.post(
            "/api/backends/me/memories",
            json={
                "agent_handle": backend_app["agent_handle"],
                "memories": [
                    {"domain": "self", "content": "I am good at testing."},
                    {"domain": "project", "content": "The project uses pytest."},
                ],
            },
        )
        assert resp.status_code == 200
        assert resp.json()["saved"] == 2

        # Retrieve
        resp = await sdk_client.get(
            "/api/backends/me/memories",
            params={"agent_handle": backend_app["agent_handle"]},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "context" in data

    async def test_stats_reporting(self, sdk_client, backend_app):
        """POST /api/backends/me/stats records token usage."""
        resp = await sdk_client.post(
            "/api/backends/me/stats",
            json={
                "agent_handle": backend_app["agent_handle"],
                "thread_id": backend_app["thread_id"],
                "input_tokens": 500,
                "output_tokens": 200,
                "cache_read_tokens": 100,
                "cache_create_tokens": 50,
                "cost_usd": 0.003,
                "backend": "claude_code",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "recorded"
