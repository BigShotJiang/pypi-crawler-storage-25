"""Tests for agenthive.cli module."""
from __future__ import annotations

import json
import sys
from unittest.mock import patch

import pytest

from agenthive.cli import main


class TestCLIDispatch:
    def test_no_command_prints_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main([])
        assert exc_info.value.code == 1

    def test_help_flag(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "setup" in out
        assert "start" in out
        assert "stop" in out
        assert "status" in out
        assert "doctor" in out

    def test_setup_subcommand_help(self, capsys):
        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--help"])
        assert exc_info.value.code == 0
        out = capsys.readouterr().out
        assert "--no-interactive" in out


class TestSetupNonInteractive:
    def test_writes_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr("agenthive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agenthive.config.CONFIG_FILE", tmp_path / "config.json")
        # Also patch at the import location in the setup module
        monkeypatch.setattr("agenthive.commands.setup.CONFIG_FILE", tmp_path / "config.json")

        main([
            "setup", "--no-interactive",
            "--server", "https://example.com",
            "--token", "ahv_test_token_123",
        ])

        config_file = tmp_path / "config.json"
        assert config_file.exists()
        data = json.loads(config_file.read_text())
        assert data["server_url"] == "https://example.com"
        assert data["token"] == "ahv_test_token_123"
        assert isinstance(data["backends"], dict)

    def test_missing_server_exits(self, tmp_path, monkeypatch):
        monkeypatch.setattr("agenthive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agenthive.config.CONFIG_FILE", tmp_path / "config.json")
        monkeypatch.setattr("agenthive.commands.setup.CONFIG_FILE", tmp_path / "config.json")

        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--no-interactive", "--token", "ahv_test"])
        assert exc_info.value.code == 1

    def test_missing_token_exits(self, tmp_path, monkeypatch):
        monkeypatch.setattr("agenthive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agenthive.config.CONFIG_FILE", tmp_path / "config.json")
        monkeypatch.setattr("agenthive.commands.setup.CONFIG_FILE", tmp_path / "config.json")

        with pytest.raises(SystemExit) as exc_info:
            main(["setup", "--no-interactive", "--server", "http://x"])
        assert exc_info.value.code == 1


class TestStopNoProcess:
    def test_stop_no_pid_file(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr("agenthive.config.PID_FILE", tmp_path / "daemon.pid")
        monkeypatch.setattr("agenthive.commands.stop.PID_FILE", tmp_path / "daemon.pid")
        main(["stop"])
        out = capsys.readouterr().out
        assert "not running" in out.lower()


class TestStatusNoConfig:
    def test_status_no_config(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setattr("agenthive.config.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("agenthive.config.CONFIG_FILE", tmp_path / "config.json")
        main(["status"])
        out = capsys.readouterr().out
        assert "not found" in out.lower()
