"""agenthive doctor — diagnostic checks."""
from __future__ import annotations

import argparse
import shutil
import sys

from agenthive.config import (
    Config,
    ConfigError,
    CONFIG_FILE,
    PID_FILE,
    load_config,
)


def _check(label: str, ok: bool, detail: str = "") -> bool:
    mark = "\u2713" if ok else "\u2717"
    suffix = f" {detail}" if detail else ""
    print(f"  {label:20s} {mark}{suffix}")
    return ok


def run_doctor(_args: argparse.Namespace) -> None:
    """Run the doctor command."""
    print()
    all_ok = True

    # 1. Config file
    config: Config | None = None
    try:
        config = load_config()
        all_ok &= _check("Config", True, str(CONFIG_FILE))
    except ConfigError:
        all_ok &= _check("Config", False, f"not found ({CONFIG_FILE})")

    # 2. Token
    if config:
        has_token = bool(config.token) and config.token.startswith("ahv_")
        masked = config.token[:4] + "****" + config.token[-4:] if len(config.token) > 8 else "(not set)"
        all_ok &= _check("Token", has_token, masked)
    else:
        all_ok &= _check("Token", False, "no config")

    # 3. Server reachable
    if config and config.server_url:
        try:
            import httpx
        except ImportError:
            all_ok &= _check("Server", False, "httpx not installed (pip install httpx)")
            httpx = None  # type: ignore[assignment]
        if httpx is not None:
            try:
                resp = httpx.get(config.server_url, timeout=5, follow_redirects=True)
                all_ok &= _check("Server", True, f"{config.server_url} (HTTP {resp.status_code})")
            except Exception as exc:
                all_ok &= _check("Server", False, f"{config.server_url} ({exc})")
    else:
        all_ok &= _check("Server", False, "no server_url configured")

    # 4. Backends
    print()
    print("  Backends:")
    from agenthive.backends import list_all, is_available
    for name in list_all():
        binary = _get_binary_name(name)
        path = shutil.which(binary)
        if path:
            all_ok &= _check(f"    {name}", True, f"{binary} found")
        else:
            _check(f"    {name}", False, f"{binary} not on PATH")
            # Not a hard failure — some backends being missing is fine

    # 5. Daemon
    print()
    import os
    pid = None
    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            try:
                os.kill(pid, 0)
            except OSError:
                pid = None
        except (ValueError, OSError):
            pid = None
    if pid:
        _check("Daemon", True, f"running (PID {pid})")
    else:
        _check("Daemon", False, "not running")

    print()
    if all_ok:
        print("  All checks passed.")
    else:
        print("  Some checks failed. Fix the issues above.")
    print()

    if not all_ok:
        sys.exit(1)


def _get_binary_name(backend_name: str) -> str:
    """Map backend registry name to expected CLI binary name."""
    mapping = {
        "claude_code": "claude",
        "gemini_cli": "gemini",
        "codex": "codex",
        "openclaw": "openclaw",
        "opencode": "opencode",
    }
    return mapping.get(backend_name, backend_name)
