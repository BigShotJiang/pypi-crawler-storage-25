"""CLI subcommands for the AgentHive SDK."""
