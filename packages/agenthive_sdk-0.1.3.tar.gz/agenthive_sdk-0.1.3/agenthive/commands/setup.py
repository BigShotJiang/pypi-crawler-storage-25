"""agenthive setup — interactive (or non-interactive) configuration wizard."""
from __future__ import annotations

import argparse
import sys

from agenthive.config import (
    Config,
    ConfigError,
    CONFIG_FILE,
    detect_backends,
    load_config,
    save_config,
)


def _mask_token(token: str) -> str:
    if len(token) <= 8:
        return "****"
    return token[:4] + "****"


def _prompt(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    val = input(f"  {label}{suffix}: ").strip()
    return val or default


def _confirm(label: str, default: bool = False) -> bool:
    hint = "Y/n" if default else "y/N"
    val = input(f"  {label} [{hint}] ").strip().lower()
    if not val:
        return default
    return val in ("y", "yes")


def run_setup(args: argparse.Namespace) -> None:
    """Run the setup command."""
    # Load existing config as defaults
    existing = Config()
    try:
        existing = load_config()
    except ConfigError:
        pass

    if args.no_interactive:
        _run_non_interactive(args, existing)
    else:
        _run_interactive(existing)


def _run_interactive(existing: Config) -> None:
    print()
    print("  AgentHive SDK Setup")
    print()

    server_url = _prompt("Server URL", existing.server_url)
    token_default = _mask_token(existing.token) if existing.token else ""
    token_input = _prompt("Backend token", token_default)
    # If user accepted the masked default, keep the original token
    if token_input == token_default:
        token = existing.token
    else:
        token = token_input

    print()
    print("  Detecting installed backends...")
    detected = detect_backends()
    for name, found in sorted(detected.items()):
        mark = "\u2713 found" if found else "\u2717 not found"
        print(f"    {name:15s} {mark}")
    print()

    backends: dict[str, bool] = {}
    for name, found in sorted(detected.items()):
        if found:
            prev = existing.backends.get(name, True)
            backends[name] = _confirm(f"Enable {name}?", default=prev)
        else:
            backends[name] = False

    print()
    auto_start = _confirm("Start daemon on login?", default=existing.auto_start)

    config = Config(
        server_url=server_url,
        token=token,
        backends=backends,
        auto_start=auto_start,
        log_level=existing.log_level,
        timeout=existing.timeout,
    )
    save_config(config)
    print()
    print(f"  Config saved to {CONFIG_FILE}")
    print("  Run 'agenthive start' to connect.")
    print()


def _run_non_interactive(args: argparse.Namespace, existing: Config) -> None:
    server_url = args.server or existing.server_url
    token = args.token or existing.token

    if not server_url:
        print("Error: --server is required in non-interactive mode", file=sys.stderr)
        sys.exit(1)
    if not token:
        print("Error: --token is required in non-interactive mode", file=sys.stderr)
        sys.exit(1)

    detected = detect_backends()
    # Auto-enable all detected backends
    backends = {name: found for name, found in detected.items()}

    config = Config(
        server_url=server_url,
        token=token,
        backends=backends,
        auto_start=existing.auto_start,
        log_level=existing.log_level,
        timeout=existing.timeout,
    )
    save_config(config)
    enabled = [k for k, v in backends.items() if v]
    print(f"Config saved to {CONFIG_FILE}")
    print(f"Backends enabled: {', '.join(enabled) or 'none'}")
