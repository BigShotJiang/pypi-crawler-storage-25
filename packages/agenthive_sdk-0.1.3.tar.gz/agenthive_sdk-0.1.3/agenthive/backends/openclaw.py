"""OpenClaw CLI backend."""

from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


class LocalOpenClawBackend(LocalCliBackend):
    """Wraps the ``openclaw`` CLI.

    Unlike other backends, OpenClaw takes input via ``--message`` flag
    rather than stdin.  We store the prompt temporarily so ``_build_args``
    can append it, and return ``None`` from ``_get_stdin_data``.
    """

    supports_resume = True
    _pending_prompt: str = ""

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("openclaw") is not None

    def _base_command(self) -> list[str]:
        return ["openclaw", "agent", "--local", "--json"]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        cmd = list(self._base_command())
        if session_id:
            cmd.extend(["--session-id", session_id])
        else:
            cmd.extend(["--agent", "main"])
        # Append --message with the stored prompt
        if self._pending_prompt:
            cmd.extend(["--message", self._pending_prompt])
        return cmd

    def _get_stdin_data(self, prompt: str) -> str | None:
        # OpenClaw uses --message flag, not stdin.
        return None

    async def invoke(
        self,
        prompt: str,
        session_id: str | None = None,
        timeout: int = 300,
        cwd: str | None = None,
    ) -> LocalInvocationResult:
        # Set _pending_prompt *before* super().invoke() so _build_args
        # can append --message.  The base class calls _build_args before
        # _get_stdin_data, so we must store the prompt here.
        self._pending_prompt = prompt
        try:
            return await super().invoke(prompt, session_id=session_id, timeout=timeout, cwd=cwd)
        finally:
            self._pending_prompt = ""

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        # Strip any non-JSON lines (e.g. debug/gateway messages) before the JSON
        lines = stdout.strip().splitlines()
        json_start = None
        for i, line in enumerate(lines):
            if line.strip().startswith("{"):
                json_start = i
                break

        if json_start is not None:
            json_text = "\n".join(lines[json_start:])
        else:
            json_text = stdout.strip()

        try:
            data = json.loads(json_text)
        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON from openclaw output, treating as plain text")
            return LocalInvocationResult(text=stdout.strip())

        # Extract text from payloads
        payloads = data.get("payloads", [])
        text_parts = [p.get("text", "") for p in payloads if p.get("text")]
        text = "\n".join(text_parts)

        # Extract metadata
        meta = data.get("meta", {})
        agent_meta = meta.get("agentMeta", {})
        usage = agent_meta.get("usage", {})

        return LocalInvocationResult(
            text=text,
            session_id=agent_meta.get("sessionId"),
            stop_reason=meta.get("stopReason"),
            input_tokens=usage.get("input", 0),
            output_tokens=usage.get("output", 0),
            cache_read_tokens=usage.get("cacheRead", 0),
        )
