"""OpenCode CLI backend — nd-JSON output, session resume via --session <id>."""
from __future__ import annotations

import json
import logging
import shutil

from .base import LocalCliBackend, LocalInvocationResult

logger = logging.getLogger(__name__)


class LocalOpenCodeBackend(LocalCliBackend):
    supports_resume = True

    @classmethod
    def is_available(cls) -> bool:
        return shutil.which("opencode") is not None

    def _base_command(self) -> list[str]:
        return ["opencode", "run", "--format", "json"]

    def _build_args(self, session_id: str | None = None) -> list[str]:
        args = list(self._base_command())
        if session_id:
            args.extend(["--session", session_id])
        return args

    def _parse_output(self, stdout: str) -> LocalInvocationResult:
        """Parse OpenCode nd-JSON event stream.

        Event types: text, step_start, step_finish, tool_use, reasoning, error.
        """
        result_text = ""
        session_id = None
        input_tokens = 0
        output_tokens = 0
        cache_read_tokens = 0

        for line in stdout.strip().split("\n"):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping malformed JSONL line: %s", line[:100])
                continue

            # Every event carries sessionID — grab from first event
            if session_id is None:
                session_id = event.get("sessionID")

            event_type = event.get("type", "")
            part = event.get("part", {})
            if event_type == "text":
                result_text += part.get("text", "")
            elif event_type == "step_finish":
                tokens = part.get("tokens", {})
                input_tokens += tokens.get("input", 0)
                output_tokens += tokens.get("output", 0)
                cache_read_tokens += tokens.get("cached", 0)
            elif event_type == "error":
                error_msg = event.get("error", event.get("message", "unknown error"))
                raise RuntimeError(f"OpenCode error: {str(error_msg)[:500]}")

        return LocalInvocationResult(
            text=result_text,
            session_id=session_id,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cache_read_tokens=cache_read_tokens,
        )
