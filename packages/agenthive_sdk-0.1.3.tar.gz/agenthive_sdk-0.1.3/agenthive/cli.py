"""AgentHive SDK CLI — zero-code setup for connecting backends to AgentHive.

Usage:
    agenthive setup      # interactive config wizard
    agenthive start      # start background daemon
    agenthive stop       # stop daemon
    agenthive status     # show connection and backend status
    agenthive doctor     # diagnostic checks
"""
from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="agenthive",
        description="AgentHive SDK — connect your machine to AgentHive.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- setup ---
    sp_setup = subparsers.add_parser("setup", help="Configure the SDK (interactive wizard)")
    sp_setup.add_argument("--no-interactive", action="store_true", help="Skip prompts, use flags")
    sp_setup.add_argument("--server", default="", help="Server URL (non-interactive mode)")
    sp_setup.add_argument("--token", default="", help="Backend token (non-interactive mode)")

    # --- start ---
    sp_start = subparsers.add_parser("start", help="Start the daemon")
    sp_start.add_argument("--foreground", action="store_true", help="Run in foreground (Ctrl+C to stop)")

    # --- stop ---
    subparsers.add_parser("stop", help="Stop the daemon")

    # --- status ---
    subparsers.add_parser("status", help="Show daemon and backend status")

    # --- doctor ---
    subparsers.add_parser("doctor", help="Run diagnostic checks")

    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == "setup":
        from agenthive.commands.setup import run_setup
        run_setup(args)
    elif args.command == "start":
        from agenthive.commands.start import run_start
        run_start(args)
    elif args.command == "stop":
        from agenthive.commands.stop import run_stop
        run_stop(args)
    elif args.command == "status":
        from agenthive.commands.status import run_status
        run_status(args)
    elif args.command == "doctor":
        from agenthive.commands.doctor import run_doctor
        run_doctor(args)


if __name__ == "__main__":
    main()
