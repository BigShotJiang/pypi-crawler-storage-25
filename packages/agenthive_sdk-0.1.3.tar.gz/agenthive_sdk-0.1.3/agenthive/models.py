"""Data models for the AgentHive SDK."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agenthive.api import AgentAPI

@dataclass
class Attachment:
    """A file attached to a message (image, PDF, etc.)."""

    id: str
    filename: str
    content_type: str
    url: str

@dataclass
class Message:
    """A message in an AgentHive thread.

    Messages received in a task handler are pre-bound to the API client,
    so you can call :meth:`reply` and :meth:`get_thread_history` directly.
    """
    id: str
    text: str
    thread_id: str
    space_id: str
    author_handle: str
    author_type: str
    mentions: list[str] = field(default_factory=list)
    attachments: list[Attachment] = field(default_factory=list)
    quoted_message_id: str | None = None
    quoted_message: dict | None = None
    created_at: str = ""
    _api: AgentAPI | None = field(default=None, repr=False)
    _task_id: str | None = field(default=None, repr=False)
    _agent_handle: str = field(default="", repr=False)
    _must_reply: bool = field(default=False, repr=False)
    _system_instruction: str = field(default="", repr=False)

    async def reply(self, text: str, mentions: list[str] | None = None, quote: bool = False) -> Message | None:
        """Reply to this message's thread.

        Args:
            text: Response text (supports markdown).
            mentions: Optional @mentions to trigger other agents.
            quote: If True, quotes this message in the reply.
        """
        if self._api is None:
            raise RuntimeError("Message not bound to an API client")
        return await self._api.post_message(
            thread_id=self.thread_id, text=text,
            agent_handle=self._agent_handle,
            mentions=mentions,
            quoted_message_id=self.id if quote else None,
            task_id=self._task_id,
        )

    async def reply_with_files(
        self,
        text: str,
        file_paths: list[str],
        mentions: list[str] | None = None,
        quote: bool = False,
    ) -> Message | None:
        """Reply with file attachments (images, etc.).

        Args:
            text: Response text (supports markdown).
            file_paths: Local paths to files to attach.
            mentions: Optional @mentions to trigger other agents.
            quote: If True, quotes this message in the reply.
        """
        if self._api is None:
            raise RuntimeError("Message not bound to an API client")
        return await self._api.post_message_with_files(
            thread_id=self.thread_id,
            text=text,
            file_paths=file_paths,
            agent_handle=self._agent_handle,
            mentions=mentions,
            quoted_message_id=self.id if quote else None,
            task_id=self._task_id,
        )

    async def get_thread_history(self, limit: int = 50) -> list[Message]:
        """Fetch recent messages from this message's thread."""
        if self._api is None:
            raise RuntimeError("Message not bound to an API client")
        return await self._api.get_messages(thread_id=self.thread_id, limit=limit)

    @classmethod
    def from_dict(cls, data: dict, api: AgentAPI | None = None, task_id: str | None = None) -> Message:
        attachments = [
            Attachment(id=a.get("id",""), filename=a.get("filename",""),
                       content_type=a.get("content_type",""), url=a.get("url",""))
            for a in data.get("attachments", [])
        ]
        return cls(
            id=data["id"], text=data.get("text",""), thread_id=data.get("thread_id",""),
            space_id=data.get("space_id",""), author_handle=data.get("author_handle",""),
            author_type=data.get("author_type",""), mentions=data.get("mentions",[]),
            attachments=attachments,
            quoted_message_id=data.get("quoted_message_id"),
            quoted_message=data.get("quoted_message"),
            created_at=data.get("created_at",""),
            _api=api, _task_id=task_id,
        )

@dataclass
class Task:
    """A task dispatched to a backend machine for processing."""

    id: str
    thread_id: str
    agent_handle: str = ""
    backend: str = ""
    trigger_message_id: str | None = None
    must_reply: bool = False
    status: str = "queued"
    system_instruction: str = ""
    space_id: str = ""
