"""Local runner: wraps CLI backends as remote agents via the AgentHive SDK.

Connects as a backend machine (one token for all agents), discovers its
assigned agents from ``GET /api/backends/me``, and routes incoming tasks
to the appropriate CLI based on the ``backend`` field.

Usage:
    python3 -m agenthive.local_runner \
        --server http://localhost:8000 \
        --token ahv_... \
        --repo-path /path/to/repo \
        --timeout 300
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import re

from agenthive import BackendClient, Message
from agenthive.backends import create_backend, list_available
from agenthive.memory import extract_memory_tags
from agenthive.rate_limit import (
    BASE_DELAY_S,
    MAX_RETRIES,
    RateLimitError,
    is_truncated,
)

logger = logging.getLogger(__name__)

_ARTIFACT_RE = re.compile(
    r'<<<ARTIFACT\s+title="([^"]+)"(?:\s+type="([^"]*)")?\s*>>>\s*\n(.*?)\n\s*<<<END_ARTIFACT>>>',
    re.DOTALL,
)


def _extract_artifacts(text: str) -> tuple[str, list[dict]]:
    """Extract <<<ARTIFACT>>> blocks from agent response, return (chat_text, artifacts)."""
    artifacts = []
    for match in _ARTIFACT_RE.finditer(text):
        artifacts.append({
            "title": match.group(1),
            "content": match.group(3).strip(),
            "content_type": match.group(2) or "markdown",
        })
    chat_text = _ARTIFACT_RE.sub("", text).strip()
    return chat_text, artifacts


# ---------------------------------------------------------------------------
# Prompt building
# ---------------------------------------------------------------------------


def build_system_prompt(
    system_instruction: str,
    handle: str,
    *,
    memory_context: str = "",
    space_rules: str = "",
) -> str:
    """Stable system prompt — cached across calls by LLM API."""
    lines = [system_instruction, ""]
    lines.append(f"You are @{handle} in a multi-agent chatroom.")
    lines.append("")
    if space_rules:
        lines.append("## Project Rules")
        lines.append(space_rules)
        lines.append("")
    lines.append("")
    lines.append("WHEN TO RESPOND:")
    lines.append('- If MANDATORY_REPLY is YES: you MUST reply (you were @mentioned).')
    lines.append('- If MANDATORY_REPLY is NO: only reply if you have something concrete and NEW to add. Otherwise output exactly "PASS".')
    lines.append('- Output EXACTLY "PASS" — not "Standing by", "Nothing to add", "Acknowledged", or "+1". Those create real messages and trigger other agents.')
    lines.append('- When referring to another agent, do NOT @mention them unless you need them to act. Use their role ("the engineer") instead of @handle to avoid triggering cascades.')
    lines.append("")
    lines.append("OUTPUT FORMAT:")
    lines.append("- Never echo MANDATORY_REPLY in your response — it is an internal instruction.")
    lines.append('- To create a shared document, wrap it in: <<<ARTIFACT title="Title" type="markdown">>>\\ncontent\\n<<<END_ARTIFACT>>>')
    lines.append("  Supported types: markdown, code, html, mermaid.")
    lines.append("- Your chat message goes OUTSIDE the artifact block.")
    lines.append("")
    lines.append("MEMORY INSTRUCTIONS:")
    lines.append('- You can save important information to your persistent memory by adding memory tags at the END of your response, after a "---" delimiter.')
    lines.append("- Format: [MEMORY: domain | subject | content]")
    lines.append("- Domains and when to use each:")
    lines.append('  * self — your own experience and lessons (subject: leave empty)')
    lines.append('  * peer — factual observations about a workmate (subject: their @handle). Stick to facts — no subjective judgments.')
    lines.append('  * project — decisions, goals, status, blockers (subject: leave empty or use space context)')
    lines.append('  * learned — technical facts, codebase patterns, domain knowledge (subject: leave empty or use space context)')
    lines.append("- Only save things worth remembering across future conversations.")
    lines.append("- To CORRECT a previous memory: [MEMORY:correct | domain | subject | new correct content]")
    if memory_context:
        lines.append("")
        lines.append(memory_context)
    return "\n".join(lines)


def build_user_prompt(
    history: list[Message],
    *,
    must_reply: bool = False,
) -> str:
    """Per-call user prompt — conversation + directive."""
    lines = ["Conversation:"]
    for m in history:
        quote_part = ""
        if m.quoted_message:
            q = m.quoted_message
            quote_part = f" (In response to @{q.get('author_handle')}: \"{q.get('text')}\")"
        lines.append(f"@{m.author_handle}:{quote_part} {m.text}")
    lines.append("")
    if must_reply:
        lines.append("MANDATORY_REPLY: YES")
    else:
        lines.append("MANDATORY_REPLY: NO")
    return "\n".join(lines)


def build_prompt(
    history: list[Message],
    system: str,
    handle: str,
    *,
    memory_context: str = "",
    space_rules: str = "",
    must_reply: bool = False,
) -> str:
    """Flat prompt fallback for backends that don't support system/user split."""
    sys_part = build_system_prompt(
        system, handle, memory_context=memory_context, space_rules=space_rules,
    )
    user_part = build_user_prompt(history, must_reply=must_reply)
    return f"{sys_part}\n\n{user_part}"


def build_resume_prompt(
    new_messages: list[Message],
    handle: str,
    *,
    must_reply: bool = False,
    memory_context: str = "",
    space_rules: str = "",
) -> str:
    """Build a shorter prompt for session-resume (only new messages).

    Includes a context reminder with project rules and memory so that
    these survive even if the original system prompt is compressed away
    in long conversations.
    """
    lines = []
    # Context reminder — keeps rules and memory alive across long sessions
    if space_rules or memory_context:
        lines.append("Context reminder (still in effect):")
        if space_rules:
            lines.append(f"Project Rules: {space_rules}")
        if memory_context:
            lines.append(memory_context)
        lines.append("")
    lines.append("New messages in the conversation:")
    lines.append("")
    for m in new_messages:
        quote_part = ""
        if m.quoted_message:
            q = m.quoted_message
            quote_part = f" (In response to @{q.get('author_handle')}: \"{q.get('text')}\")"
        lines.append(f"@{m.author_handle}:{quote_part} {m.text}")
    lines.append("")
    if must_reply:
        lines.append(
            "You were directly addressed. You MUST reply — do not output PASS."
        )
    else:
        lines.append(
            'Respond to the above. If you have nothing to add, output exactly "PASS".'
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Local runner: wraps CLI backends as remote AgentHive agents.",
    )
    parser.add_argument(
        "--server",
        required=True,
        help="AgentHive server URL (e.g. http://localhost:8000)",
    )
    parser.add_argument(
        "--token",
        required=True,
        help="Backend API token (e.g. ahv_...)",
    )
    parser.add_argument(
        "--system",
        default="You are a helpful assistant.",
        help="Fallback system instruction (used when server doesn't provide per-agent instruction)",
    )
    parser.add_argument(
        "--repo-path",
        default=None,
        help="Working directory for the subprocess",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=300,
        help="Subprocess timeout in seconds (default: 300)",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable debug logging",
    )
    return parser.parse_args(argv)


def create_task_handler(
    daemon: BackendClient,
    *,
    system_instruction: str = "You are a helpful assistant.",
    repo_path: str | None = None,
    timeout: int = 300,
) -> None:
    """Create and register a task handler on the given BackendClient.

    This is the core logic used by both the legacy CLI and the new
    ``agenthive start`` command.
    """
    api = daemon.api
    sessions: dict[tuple[str, str], str] = {}
    last_seen: dict[tuple[str, str], str] = {}

    @daemon.on_task
    async def handle(agent_handle: str, backend: str, message: Message) -> None:
        thread_id = message.thread_id
        session_key = (agent_handle, thread_id)
        logger.info("[%s@%s] Task received (backend=%s, thread=%s)", agent_handle, thread_id[:8], backend, thread_id)
        history = await message.get_thread_history()

        # Resolve the backend from the registry
        try:
            cli = create_backend(backend)
        except ValueError:
            logger.error("Unknown backend %r for agent %s, skipping", backend, agent_handle)
            return

        session_id = sessions.get(session_key)
        resumed = bool(session_id)
        logger.info("[%s@%s] Session: %s", agent_handle, thread_id[:8], session_id[:8] if session_id else "new")

        # 1. Fetch memory context + space rules
        memory_ctx = ""
        space_rules = ""
        try:
            participants = list({m.author_handle for m in history})
            memory_ctx, space_rules = await api.get_memory_context(
                space_id=message.space_id,
                participants=participants,
                agent_handle=agent_handle,
            )
        except Exception as exc:
            logger.warning("Failed to fetch memory context: %s", exc)

        logger.info("[%s@%s] Memory: %d chars, rules: %d chars", agent_handle, thread_id[:8], len(memory_ctx), len(space_rules))

        # Server tells us whether a reply is mandatory (e.g. DM or @mention)
        must_reply = getattr(message, "_must_reply", False)

        # Use per-agent system_instruction from the server if available,
        # otherwise fall back to the global --system CLI arg.
        agent_instruction = getattr(message, "_system_instruction", "") or system_instruction

        # 2. Build prompt
        if session_id and cli.supports_resume:
            # Resume: only send messages after our last response
            last_id = last_seen.get(session_key)
            if last_id:
                new_msgs = []
                found = False
                for m in history:
                    if found:
                        new_msgs.append(m)
                    elif m.id == last_id:
                        found = True
                if new_msgs:
                    prompt = build_resume_prompt(
                        new_msgs, agent_handle,
                        must_reply=must_reply,
                        memory_context=memory_ctx,
                        space_rules=space_rules,
                    )
                else:
                    prompt = build_prompt(
                        history, agent_instruction, agent_handle, memory_context=memory_ctx, space_rules=space_rules, must_reply=must_reply,
                    )
            else:
                prompt = build_prompt(
                    history, agent_instruction, agent_handle, memory_context=memory_ctx, space_rules=space_rules, must_reply=must_reply,
                )
        else:
            prompt = build_prompt(
                history, agent_instruction, agent_handle, memory_context=memory_ctx, space_rules=space_rules, must_reply=must_reply,
            )

        logger.debug("[%s@%s] Prompt (%d chars): %s...", agent_handle, thread_id[:8], len(prompt), prompt[:200])

        # 3. Run subprocess with retry logic
        delay = BASE_DELAY_S
        result = None
        truncation_retried = False

        for attempt in range(MAX_RETRIES + 1):
            logger.info(
                "Running %s for @%s thread %s (attempt %d, resume=%s)",
                backend, agent_handle, thread_id, attempt + 1, bool(session_id),
            )

            try:
                result = await cli.invoke(
                    prompt,
                    session_id=session_id,
                    timeout=timeout,
                    cwd=repo_path,
                )
                break

            except RateLimitError:
                if attempt < MAX_RETRIES:
                    logger.warning(
                        "[%s@%s] Rate limit (attempt %d/%d), waiting %.0fs",
                        agent_handle, thread_id[:8], attempt + 1, MAX_RETRIES, delay,
                    )
                    await asyncio.sleep(delay)
                    delay *= 3
                    continue
                # Exhausted retries
                sessions.pop(session_key, None)
                last_seen.pop(session_key, None)
                raise

            except TimeoutError as exc:
                sessions.pop(session_key, None)
                last_seen.pop(session_key, None)
                await message.reply(f"[error] {exc}")
                raise

            except RuntimeError:
                # Resume failure -> clear session and retry with full prompt
                if session_id and attempt == 0:
                    logger.warning(
                        "[%s@%s] Resume failed, falling back to full prompt", agent_handle, thread_id[:8],
                    )
                    sessions.pop(session_key, None)
                    session_id = None
                    prompt = build_prompt(
                        history, agent_instruction, agent_handle, memory_context=memory_ctx, space_rules=space_rules, must_reply=must_reply,
                    )
                    continue
                sessions.pop(session_key, None)
                last_seen.pop(session_key, None)
                raise

        # 4. Extract results
        logger.info("[%s@%s] CLI result: %d chars, session=%s", agent_handle, thread_id[:8], len(result.text), result.session_id[:8] if result.session_id else None)
        reply_text = result.text
        new_session_id = result.session_id
        usage = {
            "input_tokens": result.input_tokens,
            "output_tokens": result.output_tokens,
            "cache_read_tokens": result.cache_read_tokens,
            "cost_usd": result.cost_usd,
        }

        if new_session_id:
            sessions[session_key] = new_session_id

        # 5. Truncation check -> retry if needed
        first_run_files = result.generated_files or []
        if not truncation_retried and is_truncated(reply_text, result.stop_reason):
            logger.warning(
                "[%s@%s] Response truncated, retrying with full prompt", agent_handle, thread_id[:8],
            )
            truncation_retried = True
            sessions.pop(session_key, None)
            session_id = None
            resumed = False
            prompt = build_prompt(
                history, agent_instruction, agent_handle, memory_context=memory_ctx, space_rules=space_rules, must_reply=must_reply,
            )
            try:
                result = await cli.invoke(
                    prompt,
                    session_id=None,
                    timeout=timeout,
                    cwd=repo_path,
                )
                reply_text = result.text
                new_session_id = result.session_id
                usage = {
                    "input_tokens": result.input_tokens,
                    "output_tokens": result.output_tokens,
                    "cache_read_tokens": result.cache_read_tokens,
                    "cost_usd": result.cost_usd,
                }
                if new_session_id:
                    sessions[session_key] = new_session_id
                # Merge generated files from both runs (dedup by path)
                retry_files = result.generated_files or []
                seen = set(first_run_files)
                merged = list(first_run_files)
                for f in retry_files:
                    if f not in seen:
                        merged.append(f)
                        seen.add(f)
                result.generated_files = merged
            except Exception as exc:
                logger.warning("Truncation retry failed: %s", exc)
                result.generated_files = first_run_files

        # 6. Extract memory tags
        clean_text, memories, corrections = extract_memory_tags(reply_text)
        logger.info("[%s@%s] Extracted %d memories, %d corrections", agent_handle, thread_id[:8], len(memories), len(corrections))

        # 7. Extract artifacts from response
        clean_text, artifacts = _extract_artifacts(clean_text)
        if artifacts:
            logger.info("[%s@%s] Extracted %d artifacts", agent_handle, thread_id[:8], len(artifacts))

        # 8. Reply (skip if PASS or empty)
        reply_msg = None
        generated_files = result.generated_files or []
        if not clean_text or clean_text.strip() == "PASS":
            if generated_files:
                # Agent PASSed on text but generated images — still upload them
                logger.info("[%s@%s] PASS with %d generated files, uploading", agent_handle, thread_id[:8], len(generated_files))
                reply_msg = await message.reply_with_files(
                    "Generated images:",
                    generated_files,
                )
                generated_files = []  # Already uploaded
            else:
                logger.info("[%s@%s] PASS — no reply needed", agent_handle, thread_id[:8])
            last_seen[session_key] = message.id
        else:
            if generated_files:
                # Upload reply text with attached image files
                reply_msg = await message.reply_with_files(clean_text, generated_files)
                generated_files = []  # Already uploaded
            else:
                reply_msg = await message.reply(clean_text)
            last_seen[session_key] = message.id
            if reply_msg is None:
                # Server filtered as non-substantive (soft-PASS)
                logger.info("[%s@%s] Reply filtered by server", agent_handle, thread_id[:8])
            else:
                logger.info("[%s@%s] Reply posted (%d chars, %d files)", agent_handle, thread_id[:8], len(clean_text), len(result.generated_files or []))

        # 9. Upload artifacts (fire-and-forget)
        for art in artifacts:
            try:
                await api.create_artifact(
                    thread_id=thread_id,
                    title=art["title"],
                    content=art["content"],
                    content_type=art["content_type"],
                    author_handle=agent_handle,
                    author_display_name=agent_handle,
                    message_id=reply_msg.id if reply_msg else None,
                )
                logger.info("[%s@%s] Artifact created: %s", agent_handle, thread_id[:8], art["title"])
            except Exception as exc:
                logger.warning("[%s@%s] Failed to create artifact: %s", agent_handle, thread_id[:8], exc)

        # 10. Create a companion artifact for generated images using attachment URLs
        if reply_msg and reply_msg.attachments and (result.generated_files or []):
            image_atts = [a for a in reply_msg.attachments if a.url]
            if image_atts:
                image_md = "\n\n".join(
                    f"![{a.filename}]({a.url})" for a in image_atts
                )
                try:
                    await api.create_artifact(
                        thread_id=thread_id,
                        title="Generated Images",
                        content=image_md,
                        content_type="markdown",
                        author_handle=agent_handle,
                        author_display_name=agent_handle,
                        message_id=reply_msg.id,
                    )
                    logger.info("[%s@%s] Image artifact created (%d images)", agent_handle, thread_id[:8], len(image_atts))
                except Exception as exc:
                    logger.warning("[%s@%s] Failed to create image artifact: %s", agent_handle, thread_id[:8], exc)

        # 11. Save memories (fire-and-forget)
        if memories or corrections:
            try:
                await api.save_memories(
                    memories,
                    message.space_id,
                    thread_id,
                    agent_handle=agent_handle,
                    corrections=corrections or None,
                    participants=participants if participants else None,
                )
                logger.info("Saved %d memories, %d corrections for @%s thread %s", len(memories), len(corrections), agent_handle, thread_id)
            except Exception as exc:
                logger.warning("Failed to save memories: %s", exc)

        # 12. Report stats (fire-and-forget)
        if usage:
            try:
                await api.report_stats({
                    "thread_id": thread_id,
                    "space_id": message.space_id,
                    "backend": backend,
                    "agent_handle": agent_handle,
                    "resumed": resumed,
                    **usage,
                })
            except Exception as exc:
                logger.warning("Failed to report stats: %s", exc)


def run_daemon(
    server_url: str,
    token: str,
    supported_backends: list[str] | None = None,
    *,
    system_instruction: str = "You are a helpful assistant.",
    repo_path: str | None = None,
    timeout: int = 300,
    log_level: str = "INFO",
) -> None:
    """Run the backend daemon. Called by both legacy CLI and ``agenthive start``."""
    logging.basicConfig(
        level=getattr(logging, log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
        datefmt="%H:%M:%S",
    )
    daemon = BackendClient(server_url=server_url, token=token)
    create_task_handler(
        daemon,
        system_instruction=system_instruction,
        repo_path=repo_path,
        timeout=timeout,
    )
    if supported_backends is None:
        supported_backends = list_available()
    daemon.run(supported_backends=supported_backends)


def main(argv: list[str] | None = None) -> None:
    """Legacy CLI entry point (python -m agenthive.local_runner)."""
    args = parse_args(argv)
    run_daemon(
        server_url=args.server,
        token=args.token,
        system_instruction=args.system,
        repo_path=args.repo_path,
        timeout=args.timeout,
        log_level="DEBUG" if args.verbose else "INFO",
    )


if __name__ == "__main__":
    main()
