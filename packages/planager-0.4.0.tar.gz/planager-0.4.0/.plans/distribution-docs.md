---
feature: distribution-docs
title: Distribution and Documentation
status: in-progress
created: 2026-04-18
updated: 2026-04-18
---

## Context

Fill out project metadata, write user-facing documentation, and publish
to PyPI so anyone can run `uvx planager init`.

Corresponds to PLAN.md Phase 3.

## Phase 1: Metadata and docs

- [x] Fill out pyproject.toml metadata (description, author, license, urls, classifiers)
- [x] Write README.md
  - One-liner install: `uvx planager init`
  - What it does, how it works
  - Plan format reference
  - Slash command docs

## Phase 2: Publish

- [ ] Test: `uvx` install from source into a clean project, verify workflow
- [ ] Publish to PyPI (`uv build && uv publish`)

## Notes

README and metadata are complete. Still need to do a clean-project smoke test
and the actual PyPI publish.
