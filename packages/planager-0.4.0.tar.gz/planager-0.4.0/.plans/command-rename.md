---
feature: command-rename
title: Resolve /plan Command Name Collision with Claude Code Built-in
status: done
created: 2026-04-18
updated: 2026-04-18
---

## Context

Claude Code has a built-in `/plan` command that enters "plan mode" - a
structured planning workflow built into the tool itself. planager also installs
a `/plan` skill that creates feature plan markdown files. These serve different
purposes but occupy the same name.

In practice, when both exist, Claude Code's skill system appears to let the
user-defined skill take precedence (the planager `/plan` skill is what fires).
But this shadows the built-in `/plan` entirely, which users may want access to.
It also creates confusion in docs and conversation ("which /plan?").

The `/plan-status` command also collides - renamed to `/planager-status`.

## Options analysis

### Option A: Rename to `/fplan` or `/feature-plan`

**Pros:** Completely avoids collision. Short and descriptive.
**Cons:** Less discoverable. `/fplan` is cryptic; `/feature-plan` is verbose.

### Option B: Rename to `/planager`

**Pros:** Matches the package name. Zero ambiguity.
**Cons:** Longer to type. Couples the command name to the tool name rather than
the action.

### Option C: Drop the skill, rely on CLAUDE.md behavior

**Pros:** No collision at all. The CLAUDE.md snippet already teaches agents to
create plans automatically - the skill is a convenience, not a requirement.
**Cons:** Loses the explicit trigger. Users who want to manually invoke plan
creation have to type a natural-language request instead of a slash command.
The AGENTS.md snippet (for non-Claude-Code agents) doesn't have skills at all,
so this approach is already how it works for Codex etc.

### Option D: Keep the name, document the override

**Pros:** `/plan` is the natural name. Users who install planager presumably
want planager-style plans, so shadowing the built-in is arguably correct.
**Cons:** Users lose access to Claude Code's built-in plan mode. Could confuse
users who don't understand why `/plan` behaves differently than expected.

### Option E: Rename to `/plans`

**Pros:** Minimal change, still intuitive, maps to the `.plans/` directory.
Naturally distinct from `/plan` (the built-in). Pairs well with `/plan-status`.
**Cons:** Subtle difference from `/plan` could still confuse.

## Phase 1: Decide and implement

- [x] Choose a renaming strategy - went with Option B: `/planager`
- [x] Rename skill directory from `plan/` to `planager/` in `src/planager/templates/`
- [x] Rename skill directory from `plan-status/` to `planager-status/` in `src/planager/templates/`
- [x] Update SKILL.md content to reference new command names
- [x] Update cli.py to copy the renamed skill directories
- [x] Update CLAUDE.md snippet - no command references to change (describes behavior, not commands)
- [x] Update AGENTS.md snippet - no command references to change
- [x] Update README.md slash command docs
- [x] Update PLAN.md references

## Phase 2: Update installed files and tests

- [x] Rename this repo's `.claude/skills/plan/` to `.claude/skills/planager/`
- [x] Rename this repo's `.claude/skills/plan-status/` to `.claude/skills/planager-status/`
- [x] Update tests in test_cli.py for new skill directory names
- [x] Run tests - 12/12 pass
- [x] Run ruff check and ruff format - clean

## Notes

Went with Option B (`/planager`) per user preference. All references updated
across templates, installed skills, cli.py, tests, README, and PLAN.md.
The CLAUDE.md and AGENTS.md snippets didn't need content changes - they describe
automatic behavior without referencing slash command names.
