---
feature: package-init
title: Package and Init Command
status: done
created: 2026-04-18
updated: 2026-04-18
---

## Context

Package planager as a Python package distributable via `uvx planager init`.
The init command copies template files into the user's project. No runtime
dependencies - stdlib only.

Corresponds to PLAN.md Phase 2.

## Phase 1: Project skeleton

- [x] Set up pyproject.toml with hatchling build backend
- [x] Set up src layout (src/planager/)
- [x] Configure uv sync

## Phase 2: Template bundling

- [x] Bundle CLAUDE.md.snippet in src/planager/templates/
- [x] Bundle AGENTS.md.snippet in src/planager/templates/
- [x] Bundle plan/SKILL.md in src/planager/templates/
- [x] Bundle plan-status/SKILL.md in src/planager/templates/

## Phase 3: CLI implementation

- [x] Write cli.py with `planager init` command
  - Creates `.plans/`
  - Copies skills into `.claude/skills/`
  - Appends snippet to CLAUDE.md (skip if already present)
  - Appends snippet to AGENTS.md (skip if already present)
  - Idempotent (safe to run again)
- [x] Wire up `[project.scripts]` so `uvx planager init` works

## Phase 4: Tests and quality

- [x] Write tests for init command (file creation, idempotency, CLI args)
- [x] Ensure `ruff check` passes
- [x] Ensure `ruff format --check` passes

## Notes

10 tests in tests/test_cli.py covering creation, appending, idempotency, and
CLI argument handling. Snippet uses marker comments (`<!-- planager:start -->`)
for idempotency detection.
