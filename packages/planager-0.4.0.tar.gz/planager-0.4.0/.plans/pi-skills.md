---
feature: pi-skills
title: Add pi.dev and Codex Skill Support via Targeted init Commands
status: done
created: 2026-04-21
updated: 2026-04-21
---

## Context

planager currently only installs skills for Claude Code (`.claude/skills/`, no
frontmatter). Both pi.dev and Codex support the Agent Skills standard - they
need frontmatter in `SKILL.md` and use different directories:

| Target  | Skills dir           | Instruction file | Frontmatter |
|---------|----------------------|------------------|-------------|
| claude  | `.claude/skills/`    | `CLAUDE.md`      | No          |
| pi      | `.pi/skills/`        | `AGENTS.md`      | Yes         |
| codex   | `.codex/skills/`     | `AGENTS.md`      | Yes         |

To avoid cluttering a user's project, `init` now requires a target argument:
`uvx planager init claude`, `uvx planager init pi`, or `uvx planager init codex`.
Each creates only the files that target needs. `.plans/` is shared across all.

## Phase 1: Template reorganization

- [x] Create `src/planager/templates/pi/` directory with `planager/SKILL.md` and `planager-status/SKILL.md` (both with Agent Skills frontmatter)
- [x] Create `src/planager/templates/codex/` directory with `planager/SKILL.md` and `planager-status/SKILL.md` (both with Agent Skills frontmatter - identical to pi)
- [x] Move `src/planager/templates/planner/` → `src/planager/templates/claude/planner/`
- [x] Move `src/planager/templates/planner-status/` → `src/planager/templates/claude/planner-status/`
- [x] Consolidate `CLAUDE.md.snippet` and `AGENTS.md.snippet` into a single `snippet.md` (they are identical)
- [x] Add `src/planager/templates/__init__.py` update if needed (no change needed)

## Phase 2: CLI refactor

- [x] Change `init` subcommand to require a positional target argument (`claude`, `pi`, `codex`)
- [x] `init` with no target shows help listing available targets
- [x] Each target's init creates: `.plans/`, target-specific skills dir, target-specific instruction file with snippet
- [x] `init claude` creates: `.plans/`, `.claude/skills/planner/SKILL.md`, `.claude/skills/planner-status/SKILL.md`, `CLAUDE.md`
- [x] `init pi` creates: `.plans/`, `.pi/skills/planner/SKILL.md`, `.pi/skills/planner-status/SKILL.md`, `AGENTS.md`
- [x] `init codex` creates: `.plans/`, `.codex/skills/planner/SKILL.md`, `.codex/skills/planner-status/SKILL.md`, `AGENTS.md`
- [x] Running multiple targets (e.g. `init pi` then `init claude`) is additive - `.plans/` already exists = skipped, different instruction files coexist, AGENTS.md snippet marker check prevents duplicate
- [x] Update success message to mention the target's slash commands

## Phase 3: Update tests

- [x] Update existing tests to use `init claude`
- [x] Add test: `init pi` creates `.pi/skills/planner/SKILL.md` with frontmatter
- [x] Add test: `init pi` creates `.pi/skills/planner-status/SKILL.md` with frontmatter
- [x] Add test: `init pi` creates `AGENTS.md` with planager snippet
- [x] Add test: `init codex` creates `.codex/skills/planner/SKILL.md` with frontmatter
- [x] Add test: `init codex` creates `.codex/skills/planner-status/SKILL.md` with frontmatter
- [x] Add test: `init codex` creates `AGENTS.md` with planager snippet
- [x] Add test: pi/codex SKILL.md `name` field matches parent directory name
- [x] Add test: running `init pi` then `init claude` is additive (both skill dirs exist, both instruction files exist)
- [x] Add test: running `init pi` then `init codex` doesn't duplicate AGENTS.md snippet
- [x] Update `test_returns_actions` for new action counts
- [x] Update idempotency test

## Phase 4: Update docs

- [x] Update README.md to document three `init` targets
- [x] Update README slash commands section: note pi uses `/skill:planager` and `/skill:planager-status`, codex uses `$planager`
- [x] Verify clean `uvx` install works end-to-end

## Notes

- The SKILL.md content for pi and codex is identical (same frontmatter, same instructions). The only difference from Claude Code is the addition of YAML frontmatter.
- AGENTS.md snippet is shared between pi and codex. If a user runs both `init pi` and `init codex`, the AGENTS.md snippet won't be duplicated (marker check).
- Pi registers skills as `/skill:planager` and `/skill:planager-status`. Codex uses `$planager` syntax.

All phases complete. 34 tests passing.
