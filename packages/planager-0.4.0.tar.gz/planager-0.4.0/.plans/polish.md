---
feature: polish
title: Polish and Future Improvements
status: planning
created: 2026-04-18
updated: 2026-04-18
---

## Context

Post-launch improvements based on real usage. All items are "consider" - they
may or may not be worth doing.

Corresponds to PLAN.md Phase 4.

## Phase 1: Refinement

- [ ] Refine CLAUDE.md wording based on real usage feedback
- [ ] Consider: `/plan-archive` skill to move done plans out of the way
- [ ] Consider: plan templates for different work types (feature vs bugfix)

## Notes

These are ideas to evaluate after real-world usage, not commitments.
