---
feature: core-content
title: Core Content - CLAUDE.md Snippet and Skills
status: done
created: 2026-04-18
updated: 2026-04-18
---

## Context

The CLAUDE.md snippet and skill definitions are the actual product. They teach
LLM agents to automatically create, follow, and maintain feature plans using
nothing but markdown files. Everything else in planager is packaging around
these files.

Corresponds to PLAN.md Phase 1.

## Phase 1: CLAUDE.md snippet

Write the snippet with automatic plan behavior for agents.

- [x] Session-start: detect and offer to resume in-progress plans
- [x] New feature: explore, propose phased plan, get approval, save
- [x] During work: check steps, add notes, update frontmatter
- [x] Completion: set done, write summary

## Phase 2: Slash-command skills

- [x] Write `plan/SKILL.md` - the `/plan` skill
  - Create flow: gather description, explore, propose phases
  - Resume flow: read plan, summarize, begin from first unchecked step
- [x] Write `plan-status/SKILL.md` - the `/plan-status` skill
  - Glob `.plans/*.md`, parse frontmatter + checkboxes, print table

## Phase 3: Validation

- [x] Add the snippet and skills to this repo
- [x] Verify the agent follows the plan workflow

## Notes

All template files implemented and installed in this repo. The snippet covers
CLAUDE.md (Claude Code) and AGENTS.md (Codex/other agents).
