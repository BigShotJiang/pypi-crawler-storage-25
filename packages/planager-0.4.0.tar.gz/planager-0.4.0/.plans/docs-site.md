---
feature: docs-site
title: GitHub-Hosted Docs Page
status: done
created: 2026-04-19
updated: 2026-04-19
---

## Context

Create a minimal, clean GitHub Pages docs site using the Planager design system. Single static HTML file served from `docs/`
on `main` branch. No build step, no JS framework.

Design source: Claude Design handoff bundle with full CSS tokens, SVG assets,
and React JSX prototype components.

## Phase 1: Project setup

- [x] Create `docs/` directory
- [x] Copy SVG assets (logo-light, logo-dark, pattern-tile) into `docs/assets/`

## Phase 2: Build the static site

- [x] Create `docs/index.html` - single-page static site matching the design:
  - Header with nav (Docs, GitHub links)
  - Hero section (headline, tagline, install command)
  - "How it works" feature section (3 steps)
  - Code demo section (plan file + status table examples)
  - Docs/Getting Started content (inline, no separate page)
  - Footer
- [x] Inline the CSS design tokens from `colors_and_type.css`
- [x] Use Google Fonts CDN links (Cormorant Garamond, DM Sans, JetBrains Mono)
- [x] Match the design's colors, spacing, typography, and layout exactly

## Phase 3: Verify

- [x] Serve locally and check rendering
- [x] Confirm responsive behavior at mobile widths

## Notes

- Single HTML file - no build, no dependencies
- Smooth-scroll anchor links instead of client-side routing
- GitHub link points to the actual repo (forest-d/planager)
- All content pulled from existing README / design prototype
- Responsive breakpoints at 768px and 480px
- To enable GitHub Pages: repo Settings > Pages > Source: Deploy from branch, Branch: main, Folder: /docs
