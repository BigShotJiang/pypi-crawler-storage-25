from contextlib import contextmanager
from contextvars import ContextVar
from typing import TypeVar

T = TypeVar("T")
TRACE_ID = "trace_id"
TRACE_ID_VAR: ContextVar[str] = ContextVar(TRACE_ID, default="")


@contextmanager
def installed_trace_id(trace_id):
    token = TRACE_ID_VAR.set(trace_id)
    try:
        yield
    finally:
        TRACE_ID_VAR.reset(token)
