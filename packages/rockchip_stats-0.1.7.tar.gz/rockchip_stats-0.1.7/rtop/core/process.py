# -*- coding: UTF-8 -*-
# Copyright (c) 2026 Batuhan Berkay Aydın.
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>

"""
Process reader - reads top processes from /proc.
Returns list of dicts sorted by CPU usage.
"""

import os
import logging

logger = logging.getLogger(__name__)

# Cached page size
_PAGE_SIZE = os.sysconf('SC_PAGE_SIZE') if hasattr(os, 'sysconf') else 4096
_CLK_TCK = os.sysconf('SC_CLK_TCK') if hasattr(os, 'sysconf') else 100

# Cache for previous CPU times to calculate delta
_prev_times = {}  # pid -> (utime + stime, timestamp)


def _read_file(path):
    try:
        with open(path, 'r') as f:
            return f.read()
    except (IOError, OSError):
        return ''


def _get_uid_name(uid):
    """Convert UID to username."""
    try:
        import pwd
        return pwd.getpwuid(int(uid)).pw_name
    except Exception:
        return str(uid)


def get_processes(max_count=10):
    """Read top processes from /proc, return list of dicts.

    Each dict has: pid, user, pri, stat, cpu, mem, mem_str, cmd
    """
    import time
    now = time.time()

    try:
        pids = [p for p in os.listdir('/proc') if p.isdigit()]
    except OSError:
        return []

    # Read total memory once
    mem_total_kb = 0
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    mem_total_kb = int(line.split()[1])
                    break
    except (IOError, OSError):
        pass

    procs = []
    for pid_str in pids:
        pid = int(pid_str)
        stat_path = '/proc/{}/stat'.format(pid_str)
        status_path = '/proc/{}/status'.format(pid_str)
        cmdline_path = '/proc/{}/cmdline'.format(pid_str)

        stat = _read_file(stat_path)
        if not stat:
            continue

        # Parse /proc/pid/stat. comm (field 2) is parenthesized and may contain
        # spaces or ')' — split around the last ')' to stay robust.
        try:
            rparen = stat.rindex(')')
            comm = stat[stat.index('(') + 1:rparen]
            # fields 3..52 after the last ')'
            rest = stat[rparen + 2:].split()
            state = rest[0]                # field 3
            utime = int(rest[14 - 3])      # field 14
            stime = int(rest[15 - 3])      # field 15
            priority = int(rest[18 - 3])   # field 18
            rss = int(rest[24 - 3])        # field 24, in pages
        except Exception:
            continue

        # CPU%: delta of (utime+stime) / elapsed wall time
        total_ticks = utime + stime
        prev = _prev_times.get(pid)
        if prev is not None:
            prev_ticks, prev_time = prev
            elapsed = now - prev_time
            if elapsed > 0:
                cpu_pct = (total_ticks - prev_ticks) / _CLK_TCK / elapsed * 100.0
            else:
                cpu_pct = 0.0
        else:
            cpu_pct = 0.0
        _prev_times[pid] = (total_ticks, now)

        # Memory in KB
        mem_kb = rss * _PAGE_SIZE // 1024
        if mem_total_kb > 0:
            mem_pct = mem_kb / mem_total_kb * 100.0
        else:
            mem_pct = 0.0

        # Format mem_str
        if mem_kb >= 1024 * 1024:
            mem_str = '{:.1f}G'.format(mem_kb / 1024 / 1024)
        elif mem_kb >= 1024:
            mem_str = '{:.1f}M'.format(mem_kb / 1024)
        else:
            mem_str = '{}K'.format(mem_kb)

        # Get UID from status
        uid = 0
        status = _read_file(status_path)
        for line in status.splitlines():
            if line.startswith('Uid:'):
                parts = line.split()
                if len(parts) >= 2:
                    uid = parts[1]
                break
        user = _get_uid_name(uid)

        # Command line
        cmdline = _read_file(cmdline_path)
        if cmdline:
            cmd = cmdline.replace('\x00', ' ').strip()
            if not cmd:
                cmd = '[{}]'.format(comm)
        else:
            cmd = '[{}]'.format(comm)

        procs.append({
            'pid': pid,
            'user': user,
            'pri': priority,
            'stat': state,
            'cpu': max(0.0, cpu_pct),
            'mem': mem_pct,
            'mem_str': mem_str,
            'cmd': cmd,
        })

    # Sort by CPU descending, take top max_count
    procs.sort(key=lambda p: p['cpu'], reverse=True)
    return procs[:max_count]
