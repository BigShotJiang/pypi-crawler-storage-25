"""
Shared candle and exchange configuration.

This module intentionally keeps the public enums stable because they are used
across the package and by downstream callers.

The V3 rewrite moved concrete Upstox request details out of this module and into
`candle_loader.py`, but `CandleLength` still carries the legacy metadata needed
for compatibility with older call sites and defaults.
"""

from enum import Enum


class Candle:
    """
    Backward-compatible candle metadata.

    `api_length_val` is retained for existing callers even though the V3 loader
    now uses explicit unit/interval mappings in `candle_loader.py`.
    """

    def __init__(self, length_in_minutes: int, api_length_val: str, days_to_fetch: int):
        self.__length_in_minutes = length_in_minutes
        self.__api_length_val = api_length_val
        self.__days_to_fetch = days_to_fetch

    def get_length_in_minutes(self):
        return self.__length_in_minutes

    def get_api_length_val(self):
        return self.__api_length_val

    def get_days_to_fetch(self):
        return self.__days_to_fetch


class CandleLength(Enum):
    """
    Public candle lengths supported by candlestix.

    Notes:
    - These enum names are part of the package contract and should remain stable.
    - Historical fetch limits are enforced by `CandleDataLoader`.
    - `WEEK` and `MONTH` remain defined for compatibility, but the core loader
      does not fetch them directly.
    """

    ONE_MIN = Candle(1, '1minute', 5)
    FIVE_MIN = Candle(5, '1minute', 6)
    TEN_MIN = Candle(10, '1minute', 10)
    FIFTEEN_MIN = Candle(15, '1minute', 16)
    THIRTY_MIN = Candle(30, '30minute', 32)
    ONE_HOUR = Candle(60, '30minute', 64)
    DAY = Candle(24 * 60, 'day', 730)
    WEEK = Candle(7 * 24 * 60, 'week', 0)
    MONTH = Candle(30 * 7 * 24 * 60, 'month', 0)

    @staticmethod
    def from_name_str(value):
        return CandleLength.__members__.get(value)


class Exchange(Enum):
    """Supported exchange/instrument namespaces used by instrument resolution."""

    BSE = "BSE_EQ"
    NSE = 'NSE_EQ'
    NSE_INDEX = 'NSE_INDEX'
    BSE_INDEX = 'BSE_INDEX'
    OPTIDX = 'OPTIDX'
    OPTSTK = 'OPTSTK'


class Constants:
    """Generic response status constants retained for compatibility."""
    API_VERSION = '2.0'
    API_STATUS_ERROR = "error"
    API_STATUS_SUCCESS = "success"


if __name__ == '__main__':
    x = CandleLength.from_name_str('ONE_MIN')
    assert x == CandleLength.ONE_MIN
    print(x)

    x = CandleLength.from_name_str('MONTH')
    assert x == CandleLength.MONTH
    print(x)

    x = CandleLength.from_name_str('Z')
    assert x is None
    print(x)

    x = CandleLength.from_name_str(None)
    assert x is None
    print(x)
