"""
Core candle loading for candlestix.

Design goals for the V3 rewrite:
- Keep the public `CandleDataLoader.candles(...)` contract stable.
- Move all Upstox-specific protocol details behind `UpstoxCandleDataFetcher`.
- Request native candle sizes from Upstox V3 instead of resampling old V2 data.
- Enforce Upstox historical range limits in one place and stitch batches together.
- Preserve on-disk caching so repeated historical queries stay cheap.

Important behavior:
- Historical candles are fetched only up to yesterday.
- Today's candles are fetched separately from the intraday endpoint.
- Both datasets are concatenated, deduplicated by timestamp, and sorted ascending.
- `WEEK` and `MONTH` remain part of the public enum surface but are not fetched
  by this loader.
"""

import logging
import os
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import List, Tuple

import pandas as pd
from pandas import DataFrame

import candlestix
from candlestix.candleconf import CandleLength, Exchange
from candlestix.time import TimeService
from candlestix.upstox import UpstoxCandleDataFetcher


@dataclass(frozen=True)
class CandleRequestSpec:
    """
    Concrete Upstox V3 request shape for a supported `CandleLength`.

    `max_span_months` and `max_span_years` encode the largest historical window
    that may be requested in a single API call for that unit/interval pair.
    """

    unit: str
    interval: int
    max_span_months: int = 0
    max_span_years: int = 0


class CandleDataLoader:
    """
    Public candle loading entry point.

    Existing clients are expected to call:

    `candles(symbol, exchange, candle_length, duration_in_days=-1)`

    The loader resolves the requested candle length to a concrete Upstox V3
    request, batches historical calls when the API requires it, fetches the
    current trading day separately, and returns a single OHLCV dataframe indexed
    by timestamp.
    """

    REQUEST_SPECS = {
        CandleLength.ONE_MIN: CandleRequestSpec(unit='minutes', interval=1, max_span_months=1),
        CandleLength.FIVE_MIN: CandleRequestSpec(unit='minutes', interval=5, max_span_months=1),
        CandleLength.TEN_MIN: CandleRequestSpec(unit='minutes', interval=10, max_span_months=1),
        CandleLength.FIFTEEN_MIN: CandleRequestSpec(unit='minutes', interval=15, max_span_months=1),
        CandleLength.THIRTY_MIN: CandleRequestSpec(unit='minutes', interval=30, max_span_months=3),
        CandleLength.ONE_HOUR: CandleRequestSpec(unit='hours', interval=1, max_span_months=3),
        CandleLength.DAY: CandleRequestSpec(unit='days', interval=1, max_span_years=10),
    }

    def __init__(
        self,
        time_service: TimeService = None,
        candle_data_fetcher: UpstoxCandleDataFetcher = None,
        debug_dump_unified_candles_to_csv: bool = False,
    ):
        self.__logger = logging.getLogger(self.__class__.__name__)
        self.__time_service = TimeService() if time_service is None else time_service
        self.__fetcher = UpstoxCandleDataFetcher() if candle_data_fetcher is None else candle_data_fetcher
        self.debug_dump_unified_candles_to_csv = debug_dump_unified_candles_to_csv

    def candles(
        self,
        symbol: str,
        exchange: Exchange,
        candle_length: CandleLength,
        duration_in_days: int = -1,
    ) -> DataFrame:
        """
        Fetch unified candles for `symbol`.

        Parameters:
        - `symbol`: trading symbol or index symbol already understood by the
          instrument lookup tables loaded during `candlestix.init()`
        - `exchange`: exchange enum used for instrument resolution
        - `candle_length`: logical candle size requested by the client
        - `duration_in_days`: historical lookback window; `-1` means use the
          default encoded in `CandleLength`

        Returns:
        - pandas DataFrame indexed by `date`
        - columns: `open`, `high`, `low`, `close`, `volume`
        """

        spec = self._get_request_spec(candle_length)

        if duration_in_days == -1:
            duration_in_days = candle_length.value.get_days_to_fetch()

        df_hist = self.__fetcher.empty_df() if duration_in_days == 1 else self._fetch_historical_candles(
            symbol,
            exchange,
            spec,
            duration_in_days,
        )
        df_today = self._fetch_today_candles(symbol, exchange, spec)

        frames = [df for df in [df_hist, df_today] if df is not None and not df.empty]
        combined_df = self.__fetcher.empty_df() if not frames else pd.concat(frames)
        if not combined_df.empty:
            combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
            combined_df.sort_index(ascending=True, inplace=True)

        if self.debug_dump_unified_candles_to_csv:
            file_name = f'debug__{symbol}-{exchange.name}_candle-{candle_length.name}.csv'
            combined_df.to_csv(os.path.join(candlestix.candlestix_conf['cache_dir'], file_name))

        return combined_df

    def _fetch_historical_candles(
        self,
        symbol: str,
        exchange: Exchange,
        spec: CandleRequestSpec,
        duration_in_days: int,
    ) -> DataFrame:
        """
        Fetch all historical candles up to yesterday.

        Upstox limits how much historical data can be retrieved per request.
        This method converts the requested date range into API-safe chunks,
        fetches them serially, merges the frames, and caches the final result.
        """

        start_date = self._parse_date(self.__time_service.get_past_date(duration_in_days))
        end_date = self._parse_date(self.__time_service.get_past_date(1))

        if start_date > end_date:
            return self.__fetcher.empty_df()

        cache_file = self._create_filename(symbol, exchange, spec, end_date, start_date)
        cached_df = self._load_cached_data_if_found(cache_file)
        if cached_df is not None:
            return cached_df

        chunks = self._split_historical_date_range(start_date, end_date, spec)
        frames: List[DataFrame] = []
        for chunk_start, chunk_end in chunks:
            df = self.__fetcher.get_historical_data_for_symbol(
                symbol,
                exchange,
                unit=spec.unit,
                interval=spec.interval,
                to_date=chunk_end.isoformat(),
                from_date=chunk_start.isoformat(),
            )
            if df is not None and not df.empty:
                frames.append(df)

        combined_df = self.__fetcher.empty_df() if not frames else pd.concat(frames)
        if not combined_df.empty:
            combined_df = combined_df[~combined_df.index.duplicated(keep='last')]
            combined_df.sort_index(ascending=True, inplace=True)

        combined_df.to_csv(cache_file)
        return combined_df

    def _fetch_today_candles(self, symbol: str, exchange: Exchange, spec: CandleRequestSpec) -> DataFrame:
        """Fetch current-day candles from the Upstox intraday endpoint."""
        return self.__fetcher.get_today_data_for_symbol(
            symbol,
            exchange,
            unit=spec.unit,
            interval=spec.interval,
        )

    def _get_request_spec(self, candle_length: CandleLength) -> CandleRequestSpec:
        """Translate a public candle length into a concrete Upstox V3 request."""
        if candle_length in (CandleLength.WEEK, CandleLength.MONTH):
            raise ValueError(f'Unsupported candle_length: {candle_length.name}.')

        spec = self.REQUEST_SPECS.get(candle_length)
        if spec is None:
            raise ValueError(f'Unsupported candle_length: {candle_length.name}.')
        return spec

    def _split_historical_date_range(
        self,
        start_date: date,
        end_date: date,
        spec: CandleRequestSpec,
    ) -> List[Tuple[date, date]]:
        """
        Break a historical range into contiguous API-safe windows.

        Example:
        - minute data may need one-month slices
        - hourly data may need quarter-sized slices
        """

        ranges: List[Tuple[date, date]] = []
        cursor = start_date

        while cursor <= end_date:
            next_end = self._chunk_end_date(cursor, end_date, spec)
            ranges.append((cursor, next_end))
            cursor = next_end + timedelta(days=1)

        return ranges

    def _chunk_end_date(self, start_date: date, overall_end_date: date, spec: CandleRequestSpec) -> date:
        """Compute the inclusive end date for a single historical request chunk."""
        start_ts = pd.Timestamp(start_date)
        if spec.max_span_months:
            max_end = start_ts + pd.DateOffset(months=spec.max_span_months) - pd.Timedelta(days=1)
        elif spec.max_span_years:
            max_end = start_ts + pd.DateOffset(years=spec.max_span_years) - pd.Timedelta(days=1)
        else:
            max_end = pd.Timestamp(overall_end_date)

        candidate_end = min(max_end.date(), overall_end_date)
        return candidate_end

    def _create_filename(
        self,
        symbol: str,
        exchange: Exchange,
        spec: CandleRequestSpec,
        end_date: date,
        start_date: date,
    ) -> str:
        """Create a deterministic cache key for a historical request."""
        file_name = (
            f'cache__{symbol}-{exchange.name}_{spec.unit}-{spec.interval}'
            f'__{start_date.isoformat()}_{end_date.isoformat()}.csv'
        )
        return str(os.path.join(candlestix.candlestix_conf['cache_dir'], file_name))

    def _load_cached_data_if_found(self, cache_file):
        """Load a cached historical dataframe if present and valid."""
        if not os.path.isfile(cache_file):
            return None

        try:
            df = pd.read_csv(cache_file)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            return df
        except Exception as exc:
            self.__logger.warning(
                'Failed to load cache file. Deleting it!: %s',
                exc,
                stack_info=True,
                exc_info=True,
            )
            os.remove(cache_file)
            return None

    def _parse_date(self, value: str) -> date:
        """Parse internal `YYYY-MM-DD` date strings produced by `TimeService`."""
        return datetime.strptime(value, '%Y-%m-%d').date()
