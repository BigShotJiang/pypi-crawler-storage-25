"""
Internal Upstox adapter for candlestix.

This module is intentionally small and loader-focused:
- Resolve symbols to Upstox instrument keys.
- Call the Upstox History V3 SDK.
- Normalize SDK responses into pandas OHLCV dataframes.

It is not intended to be the primary public API for downstream clients; that
role belongs to `CandleDataLoader`.
"""

import csv
import importlib
import logging
import os
from typing import Optional

import pandas as pd
import upstox_client
from upstox_client.rest import ApiException

import candlestix
from candlestix import Instrument
from candlestix.candleconf import Exchange


class UpstoxCandleDataFetcher:
    """
    Thin adapter over the Upstox History V3 SDK.

    This class hides SDK wiring and response normalization from the higher-level
    loader. It accepts concrete V3 request parameters (`unit`, `interval`) rather
    than legacy V2 interval labels.
    """

    def __init__(self, api_instance=None):
        self.__logger = logging.getLogger(self.__class__.__name__)
        self.__api_instance = api_instance

    def get_historical_data_for_symbol(
        self,
        symbol: str,
        exchange: Exchange,
        unit: str,
        interval: int,
        to_date: str,
        from_date: Optional[str],
    ) -> pd.DataFrame:
        """Resolve `symbol` to an instrument key and fetch historical candles."""
        instrument = self._fetch_instrument(symbol, exchange)
        if instrument is None:
            raise ValueError(f'No instrument_token found for symbol={symbol} exchange={exchange.value}')
        return self.get_historical_data_for_inst_key(
            instrument.instrument_key,
            unit=unit,
            interval=interval,
            to_date=to_date,
            from_date=from_date,
        )

    def get_today_data_for_symbol(self, symbol: str, exchange: Exchange, unit: str, interval: int) -> pd.DataFrame:
        """Resolve `symbol` to an instrument key and fetch intraday candles."""
        instrument = self._fetch_instrument(symbol, exchange)
        if instrument is None:
            raise ValueError(f'No instrument_token found for symbol={symbol} exchange={exchange.value}')
        return self.get_today_data_for_inst_key(instrument.instrument_key, unit=unit, interval=interval)

    def get_historical_data_for_inst_key(
        self,
        instrument_key: str,
        unit: str,
        interval: int,
        to_date: str,
        from_date: Optional[str],
    ) -> pd.DataFrame:
        """
        Fetch historical candles for an already-resolved instrument key.

        `from_date` is optional because the V3 SDK exposes both:
        - a `to_date` only variant
        - a `from_date` + `to_date` variant
        """

        api_instance = self._get_api_instance()

        try:
            if from_date is None:
                response = api_instance.get_historical_candle_data(
                    instrument_key,
                    unit,
                    str(interval),
                    to_date,
                )
            else:
                response = api_instance.get_historical_candle_data1(
                    instrument_key,
                    unit,
                    str(interval),
                    to_date,
                    from_date,
                )
        except ApiException as exc:
            self.__logger.error(
                "%s: get_historical_data_for_inst_key failed:%s %s",
                instrument_key,
                os.linesep,
                exc,
            )
            return None

        return self._candles_to_df(response)

    def get_today_data_for_inst_key(self, instrument_key: str, unit: str, interval: int) -> pd.DataFrame:
        """Fetch current-day candles for an already-resolved instrument key."""
        api_instance = self._get_api_instance()

        try:
            response = api_instance.get_intra_day_candle_data(instrument_key, unit, str(interval))
        except ApiException as exc:
            self.__logger.error(
                "%s: get_today_data_for_inst_key failed:%s %s",
                instrument_key,
                os.linesep,
                exc,
            )
            return None

        return self._candles_to_df(response)

    def empty_df(self) -> pd.DataFrame:
        """Return the canonical empty OHLCV dataframe used by the loaders."""
        df = pd.DataFrame(columns=['date', 'open', 'high', 'low', 'close', 'volume'])
        df['date'] = pd.to_datetime(df['date'])
        df.set_index('date', inplace=True)
        return df

    def _get_api_instance(self):
        """Create or reuse the configured `HistoryV3Api` SDK client."""
        if self.__api_instance is not None:
            return self.__api_instance

        history_v3_api_cls = getattr(upstox_client, 'HistoryV3Api', None)
        if history_v3_api_cls is None:
            history_v3_api_cls = self._import_history_v3_api()

        configuration = upstox_client.Configuration()
        self.__api_instance = history_v3_api_cls(upstox_client.ApiClient(configuration))
        return self.__api_instance

    def _import_history_v3_api(self):
        """Import `HistoryV3Api` from SDK layouts that do not re-export it at top level."""
        try:
            module = importlib.import_module('upstox_client.api.history_v3_api')
            return getattr(module, 'HistoryV3Api')
        except (ImportError, AttributeError) as exc:
            version = getattr(upstox_client, '__version__', 'unknown')
            raise ImportError(
                'HistoryV3Api is not available in the installed upstox-python-sdk. '
                f'Found version={version}. Upgrade the SDK to a V3-capable release.'
            ) from exc

    def _candles_to_df(self, response) -> pd.DataFrame:
        """
        Normalize Upstox SDK candle payloads into a sorted dataframe.

        The SDK returns candles in a list form including `open_interest`.
        Candlestix standardizes that into:
        - datetime index `date`
        - columns `open`, `high`, `low`, `close`, `volume`
        """

        candles = getattr(getattr(response, 'data', None), 'candles', None) or []
        if not candles:
            return self.empty_df()

        df = pd.DataFrame(candles, columns=['date', 'open', 'high', 'low', 'close', 'volume', 'open_interest'])
        df['date'] = pd.to_datetime(df['date'])
        df.sort_values('date', inplace=True)
        df.drop(columns=['open_interest'], inplace=True, errors='ignore')
        df.set_index('date', inplace=True)
        return df

    def _fetch_instrument(self, symbol: str, exchange: Exchange) -> Instrument:
        """Resolve a symbol from the in-memory lookup maps populated by `candlestix.init()`."""
        if exchange in (Exchange.NSE, Exchange.NSE_INDEX):
            return candlestix.nse_lookup.get(symbol)
        if exchange in (Exchange.BSE, Exchange.BSE_INDEX):
            return candlestix.bse_lookup.get(symbol)
        if exchange in (Exchange.OPTIDX, Exchange.OPTSTK):
            return self.__find_option_in_csv(symbol, exchange)
        return None

    def __find_option_in_csv(self, symbol, exchange):
        """
        Fallback option lookup.

        Equity and index lookups are preloaded into memory during `candlestix.init()`.
        Options are resolved lazily from the downloaded instrument master because
        they are larger and more transient.
        """

        file_path = candlestix.download_and_unzip_gzip_file()
        with open(file_path, 'r') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                if row[9] == exchange.name and row[2] == symbol:
                    return Instrument(symbol, row[0], '', exchange)
        return None
