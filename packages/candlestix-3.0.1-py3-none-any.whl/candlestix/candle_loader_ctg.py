"""
Lightweight HTTP candle loader for Chitragupt APIs.

This module is intentionally separate from the Upstox-backed loader:
- no instrument bootstrap
- no file cache
- no market-specific batching logic

The goal is to provide a tiny, predictable adapter around a plain HTTP API while
keeping the public surface area stable for existing callers.
"""

import logging
from datetime import datetime, timedelta
from pprint import pprint
from typing import Callable, List
from urllib.parse import quote

import pandas as pd
import requests


class CtgCandleLoader:
    """
    Simple HTTP candle loader for Chitragupt APIs.

    Public API is intentionally small and backward compatible:
    - ohlc(symbol, from_date, to_date)
    - df(symbol, from_date, to_date)
    - df_lookback(symbol, lookback_days=30)
    """

    def __init__(
        self,
        http_protocol: str = "http",
        api_host: str = "localhost",
        api_port: int = 5000,
        session=None,
        now_provider: Callable[[], datetime] = None,
    ):
        """
        Create a Chitragupt candle loader.

        Optional injection points:
        - `session`: lets tests or higher-level callers supply their own
          requests-compatible session
        - `now_provider`: lets tests control `df_lookback()` date generation
        """

        self.__logger = logging.getLogger(self.__class__.__name__)
        self.__session = requests.Session() if session is None else session
        self.__now_provider = datetime.now if now_provider is None else now_provider
        self.api_url_template = (
            f"{http_protocol}://{api_host}:{api_port}"
            "/historical-candle/v1/<SYMBOL>/<FROM_DATE>/<TO_DATE>"
        )

    def __make_url(self, symbol: str, from_date: str, to_date: str) -> str:
        """Build the request URL for a symbol/date range."""
        return (
            self.api_url_template
            .replace("<SYMBOL>", quote(symbol, safe=""))
            .replace("<FROM_DATE>", from_date)
            .replace("<TO_DATE>", to_date)
        )

    def __fetch(self, url: str) -> List[list]:
        """Perform the HTTP request and validate the expected JSON payload shape."""
        self.__logger.debug("Fetching candles: %s", url)

        response = self.__session.get(url, timeout=10)
        response.raise_for_status()

        payload = response.json()
        status = payload.get("status")
        if status != "success":
            raise RuntimeError(f"API error: {payload}")

        data = payload.get("data") or {}
        candles = data.get("candles")
        if candles is None:
            raise RuntimeError(f"Malformed API response: {payload}")

        return candles

    def __empty_df(self) -> pd.DataFrame:
        """Return the canonical empty dataframe for CTG candle data."""
        df = pd.DataFrame(columns=["date", "open", "high", "low", "close", "volume", "oi"])
        df["date"] = pd.to_datetime(df["date"])
        df.set_index("date", inplace=True)
        return df

    def ohlc(self, symbol: str, from_date: str, to_date: str) -> List[list]:
        """
        Fetch raw OHLC candles.

        Returned shape:
        [
            [timestamp, open, high, low, close, volume, oi],
            ...
        ]
        """

        url = self.__make_url(symbol, from_date, to_date)
        return self.__fetch(url)

    def df(self, symbol: str, from_date: str, to_date: str) -> pd.DataFrame:
        """
        Fetch candle data as a pandas dataframe.

        Output contract:
        - datetime index named `date`
        - columns: `open`, `high`, `low`, `close`, `volume`, `oi`
        - rows sorted in chronological order
        """

        candles = self.ohlc(symbol, from_date, to_date)
        if not candles:
            return self.__empty_df()

        df = pd.DataFrame(
            candles,
            columns=["date", "open", "high", "low", "close", "volume", "oi"],
        )
        df["date"] = pd.to_datetime(df["date"])
        df.set_index("date", inplace=True)
        df.sort_index(inplace=True)
        return df

    def df_lookback(self, symbol: str, lookback_days: int = 30) -> pd.DataFrame:
        """Convenience wrapper over `df()` for `today - lookback_days` to `today`."""
        now = self.__now_provider()
        to_date = now.strftime("%Y-%m-%d")
        from_date = (now - timedelta(days=lookback_days)).strftime("%Y-%m-%d")
        return self.df(symbol, from_date, to_date)


if __name__ == '__main__':
    loader = CtgCandleLoader()
    data = loader.ohlc("suzlon", "2026-01-01", "2026-02-01")
    pprint(data)
    print('-' * 100)

    df = loader.df("suzlon", "2026-01-01", "2026-02-01")
    print(df.to_string())
    print('-' * 100)

    df = loader.df_lookback("suzlon", 365)
    print(df.to_string())
