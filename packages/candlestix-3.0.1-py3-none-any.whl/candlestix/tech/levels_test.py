from pprint import pprint

from candlestix.candle_loader_ctg import CtgCandleLoader
from levels import WeeklySupportResistanceDetector


if __name__ == '__main__':

    loader = CtgCandleLoader()
    df = loader.df_lookback("OIL", lookback_days=730)

    detector = WeeklySupportResistanceDetector()
    zones = detector.detect(df)

    pprint(zones)
