"""
levels.py
=========

Simple, explainable Support & Resistance detection on WEEKLY timeframe.

Design goals:
- KISS (Keep It Simple, Stupid)
- Deterministic (no ML, no clustering algorithms)
- Explainable on a chart
- Copy-paste friendly
- Production-safe building block

What this module does:
1. Converts DAILY OHLCV data to WEEKLY
2. Detects swing-based Support & Resistance LINES
3. Groups nearby lines into SR ZONES
4. Filters zones to keep only ACTUAL / RELEVANT zones

What it does NOT do:
- No indicators
- No zigzag repainting
- No k-means / statistics
- No scoring systems
"""

from dataclasses import dataclass
from typing import List
import pandas as pd
from pandas import DataFrame


# ============================================================
# DATA MODELS
# ============================================================

@dataclass
class Level:
    """
    Represents a single swing-based SR level (a line).
    """
    date: pd.Timestamp
    price: float
    diff_pct: float  # % distance from current price


@dataclass
class SRZone:
    """
    Represents a Support or Resistance ZONE (price area).
    """
    low: float
    high: float
    zone_type: str          # 'support' or 'resistance'
    touches: int
    last_touched: pd.Timestamp

    def __repr__(self):
        return (
            f"SRZone(type={self.zone_type}, "
            f"range={round(self.low,2)}-{round(self.high,2)}, "
            f"touches={self.touches})"
        )


# ============================================================
# CORE DETECTOR
# ============================================================

class WeeklySupportResistanceDetector:
    """
    Detects weekly Support & Resistance zones from DAILY OHLCV data.

    Expected DataFrame columns:
    ['date', 'open', 'high', 'low', 'close', 'volume']
    """

    # -------------------------
    # PUBLIC API
    # -------------------------

    def detect(
        self,
        daily_df: DataFrame,
        swing_lookback: int = 3,
        zone_merge_pct: float = 1.0,
        min_zone_touches: int = 1
    ) -> List[SRZone]:
        """
        Main entry point.

        Parameters:
        - daily_df : DAILY OHLCV dataframe
        - swing_lookback : candles on each side to define a swing
        - zone_merge_pct : % range to group levels into a zone
        - min_zone_touches : minimum touches to qualify as ACTUAL zone
        """

        weekly_df = self._to_weekly(daily_df)
        levels = self._detect_swings(weekly_df, swing_lookback)
        zones = self._build_zones(levels, zone_merge_pct)
        actual_zones = self._filter_actual_zones(zones, min_zone_touches)

        return actual_zones

    # -------------------------
    # STEP 1: DAILY → WEEKLY
    # -------------------------

    def _to_weekly(self, df: DataFrame) -> DataFrame:
        """
        Converts daily OHLCV to weekly OHLCV.

        Accepts DataFrame where:
        - date is either the index (preferred)
        - OR a 'date' column
        """
        df = df.copy()

        # If date is a column, move it to index
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)

        # Ensure index is datetime
        if not isinstance(df.index, pd.DatetimeIndex):
            raise ValueError("DataFrame must be indexed by date or have a 'date' column")

        weekly = df.resample('W').agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        })

        weekly.dropna(inplace=True)
        weekly.reset_index(inplace=True)

        return weekly

    # -------------------------
    # STEP 2: SWING DETECTION
    # -------------------------

    def _detect_swings(self, df: DataFrame, n: int) -> List[Level]:
        """
        Detects swing highs & lows on weekly candles.
        """
        levels: List[Level] = []
        current_price = df.iloc[-1]['close']

        for i in range(n, len(df) - n):
            high = df.iloc[i]['high']
            low = df.iloc[i]['low']

            prev_highs = df.iloc[i - n:i]['high']
            next_highs = df.iloc[i + 1:i + n + 1]['high']

            prev_lows = df.iloc[i - n:i]['low']
            next_lows = df.iloc[i + 1:i + n + 1]['low']

            is_swing_high = high > prev_highs.max() and high > next_highs.max()
            is_swing_low = low < prev_lows.min() and low < next_lows.min()

            if is_swing_high:
                levels.append(
                    Level(
                        date=df.iloc[i]['date'],
                        price=high,
                        diff_pct=round(100 * (high - current_price) / current_price, 2)
                    )
                )

            if is_swing_low:
                levels.append(
                    Level(
                        date=df.iloc[i]['date'],
                        price=low,
                        diff_pct=round(100 * (low - current_price) / current_price, 2)
                    )
                )

        return levels

    # -------------------------
    # STEP 3: LEVELS → ZONES
    # -------------------------

    def _build_zones(self, levels: List[Level], pct: float) -> List[SRZone]:
        """
        Groups nearby levels into price zones with a hard cap on zone width
        to prevent chain-merge explosions.
        """
        if not levels:
            return []

        MAX_ZONE_WIDTH_PCT = 1.5  # hard cap (weekly-safe)

        levels = sorted(levels, key=lambda x: x.price)
        zones: List[SRZone] = []
        bucket = [levels[0]]

        for lvl in levels[1:]:
            # price proximity check
            pct_diff = abs(100 * (lvl.price - bucket[-1].price) / bucket[-1].price)

            # prospective zone width check
            prospective_prices = [l.price for l in bucket] + [lvl.price]
            zone_low = min(prospective_prices)
            zone_high = max(prospective_prices)
            zone_width_pct = 100 * (zone_high - zone_low) / zone_low

            if pct_diff <= pct and zone_width_pct <= MAX_ZONE_WIDTH_PCT:
                bucket.append(lvl)
            else:
                zones.append(self._create_zone(bucket))
                bucket = [lvl]

        if bucket:
            zones.append(self._create_zone(bucket))

        return zones

    def _create_zone(self, bucket: List[Level]) -> SRZone:
        prices = [l.price for l in bucket]
        zone_type = 'support' if all(l.diff_pct < 0 for l in bucket) else 'resistance'

        return SRZone(
            low=min(prices),
            high=max(prices),
            zone_type=zone_type,
            touches=len(bucket),
            last_touched=max(l.date for l in bucket)
        )

    # -------------------------
    # STEP 4: ACTUAL ZONES
    # -------------------------

    def _filter_actual_zones(
        self,
        zones: List[SRZone],
        min_touches: int
    ) -> List[SRZone]:
        """
        Keeps only zones with sufficient market interaction.
        """
        return [z for z in zones if z.touches >= min_touches]
