"""
This module defines the Event class and related types.

The Event class is the main way to send data from the server to the client in a structured way.
It supports various types of events, such as alerts, toasts, dialogs, downloads, and redirects.

Each event has a type, a detail dictionary that contains the event's parameters, and an optional data stream for heavy data.

The Event class also provides static methods to create specific types of events, such as alert, toast, confirm, button_dialog, custom_dialog, and download.

The EventData type is a TypedDict that represents the data contained in an Event, which is used for transmission to the client.

The Stream class represents a file stream with a filename, mimetype, and data.

The Button class represents a button with an action, label, and URL.

The DataViewMode, ButtonAction, EventType, and EventSeverity classes are StrEnum classes that define the possible values
for data view modes, button actions, event types, and event severities.
"""

import copy
from dataclasses import dataclass, field
from enum import StrEnum
from io import BytesIO
from typing import Dict, List, Literal, TypedDict

from .dictutils import clear_dict, get_dict_value, set_dict_value


class DataViewMode(StrEnum):
    """Class representing the data view mode for download events (see `Event.download`)"""

    PREVIEW = "preview"
    DOWNLOAD = "download"


class ButtonAction(StrEnum):
    """Class representing the possible button actions (see `Event.confirm` and `Event.button_dialog`)"""

    NONE = ""
    ACCEPT = "accept"
    APPLY = "apply"
    DISMISS = "dismiss"


class EventType(StrEnum):
    """Class representing the possible event types (see `Event.type`)"""

    NONE = ""
    ALERT = "nd:dialog:alert"  # tested
    TOAST = "nd:dialog:toast"  # tested
    ONE_BUTTON = "nd:dialog:one_button"
    TWO_BUTTON = "nd:dialog:two_button"
    THREE_BUTTON = "nd:dialog:three_button"
    CONFIRM = "nd:dialog:confirm"
    CUSTOM_DIALOG = "nd:dialog:custom"
    DOWNLOAD = "nd:download"
    REDIRECT = "nd:redirect"


class EventSeverity(StrEnum):
    """Class representing the possible event severities (see `EventSeverity`)"""

    DANGER = "danger"
    WARNING = "warning"
    SUCCESS = "success"
    INFO = "info"
    DEFAULT = "primary"


class EventData(TypedDict):
    """Class representing the data contained in an Event, used for transmission to the client (see `Event._as_event_data`)"""

    type: EventType
    detail: Dict
    data: BytesIO | None


@dataclass
class Stream:
    """Class representing a file stream, used for download events (see `Event.get_stream`)"""

    filename: str
    mimetype: str
    data: BytesIO


class DialogType(StrEnum):
    """Class representing the possible dialog types (see `EventType`)"""

    ALERT = "alert"
    TOAST = "toast"
    CONFIRM = "confirm"
    ONE_BUTTON = "one_button"
    TWO_BUTTON = "two_button"
    THREE_BUTTON = "three_button"
    CUSTOM = "custom"


@dataclass
class Button:
    """Class representing a button, used for confirm and button dialog events (see `Event.confirm` and `Event.button_dialog`)"""

    action: ButtonAction
    label: str = "No label"
    url: str = ""


@dataclass()
class Event:
    """Class representing an event to be sent to the client (see `Event.get_event`)"""

    type: EventType = EventType.NONE
    detail: Dict[str, str | Dict] = field(
        init=False,
        default_factory=lambda: {
            "severity": "danger",  # Severity
            "title": "No title defined !",  # The dialog's title
            "message": "No message defined !",  # The dialog's body
            "buttons": {
                "accept": "OK",  # The 'accept' button's label
                "dismiss": "Cancel",  # The 'dismiss' button's label
                "apply": "Apply",  # The 'apply' button's label
            },
            "confirm": "Please, confirm the operation",  # Confirm checkbox label
            "urls": {
                "redirect": "/_redirect",  # The redirect URL
                "accept": "/_accept",  # The 'accept' url
                "dismiss": "/_dismiss",  # The 'dismiss' url
                "apply": "/_apply",  # The 'apply' url
            },
            "actions": {
                "accept": "js_accept",  # The 'accept' action
                "dismiss": "js_dismiss",  # The 'dismiss' action
                "apply": "js_apply",  # The 'apply' action
            },
            "payload": {
                "data": BytesIO(b"this is my data stream"),
                "mimetype": "application/pdf",
                "filename": "my_document.pdf",
                "mode": DataViewMode.PREVIEW,
            },
            "custom": {
                "html": "<p>This is HTML</p>",
                "width_pc": 50,
            },
        },
    )

    def set_value(self, path: str, value: str) -> None:
        """Set a value in the event detail dictionary using a dot-separated path (see `Event.detail`)"""
        set_dict_value(self.detail, path, value)

    def clear_dict(self) -> None:
        """Clear the event detail dictionary (see `Event.detail`)"""
        clear_dict(self.detail)

    def _as_event_data(self) -> EventData:
        """
        Convert the event to an `EventData` structure for transmission to the client (see `Event.get_event`)

        Events are transmitted to the client via 2 channels:

        - Light data is put into the <b>response header</b>
        - Heavy data is put into the <b>response body</b>
        """
        # Extract the data stream from the event detail
        data = get_dict_value(self.detail, "payload.data") or None

        # Create a deep copy of the event detail to avoid modifying the original
        d = copy.deepcopy(self.detail)

        # Set the 'payload.data' value to a boolean indicating whether the data stream
        # is present or not, to avoid sending heavy data in the response header
        set_dict_value(d, "payload.data", True if data else False)

        # Return the event data as a dictionary
        return EventData(type=self.type, detail=d, data=data)

    def get_event(self) -> Dict:
        """Get the event data as a dictionary for transmission to the client (see `Event._as_event_data`)"""
        # Convert the event to an EventData structure and return it as a dictionary
        ed = self._as_event_data()

        # The 'data' field is not sent in the response header,
        # so we remove it from the event data dictionary
        return dict(type=ed["type"], detail=ed["detail"])

    def get_stream(self) -> Stream | None:
        """Get the data stream from the event detail, if it exists (see `Event.detail`)"""

        # Extract the data stream information from the event detail
        data = get_dict_value(self.detail, "payload.data") or None
        mimetype = get_dict_value(self.detail, "payload.mimetype") or ""
        filename = get_dict_value(self.detail, "payload.filename") or ""

        # If the data stream exists, return it as a Stream object, otherwise return None
        if data is not None:
            return Stream(filename, mimetype, data)

        return None

    @staticmethod
    def redirect(url: str = "") -> "Event":
        """Create a redirect event with the given URL (see `EventType.REDIRECT`)"""

        # Create a new event and set its type to REDIRECT
        result = Event()
        result.type = EventType.REDIRECT
        clear_dict(result.detail)

        # Set the redirect URL in the event detail
        set_dict_value(result.detail, "urls.redirect", url)

        return result

    @staticmethod
    def alert(severity: EventSeverity, message: str, redirect_url: str = "") -> "Event":
        """Create an alert event with the given severity, message, and optional redirect URL (see `EventType.ALERT`)"""
        result = Event()
        result.type = EventType.ALERT
        clear_dict(result.detail)
        set_dict_value(result.detail, "severity", severity.value)
        set_dict_value(result.detail, "message", message)
        set_dict_value(result.detail, "urls.redirect", redirect_url)
        return result

    @staticmethod
    def toast(severity: EventSeverity, title: str, message: str, redirect_url: str = "") -> "Event":
        """Create a toast event with the given severity, title, message, and optional redirect URL (see `EventType.TOAST`)"""
        result = Event()
        result.type = EventType.TOAST
        clear_dict(result.detail)
        set_dict_value(result.detail, "severity", severity.value)
        set_dict_value(result.detail, "title", title)
        set_dict_value(result.detail, "message", message)
        set_dict_value(result.detail, "urls.redirect", redirect_url)
        return result

    @staticmethod
    def confirm(title: str, message: str, confirm_label: str, buttons: List[Button]) -> "Event":
        """Create a confirm event with the given title, message, confirm label, and buttons (see `EventType.CONFIRM`)"""
        result = Event()
        result.type = EventType.CONFIRM
        clear_dict(result.detail)
        set_dict_value(result.detail, "title", title)
        set_dict_value(result.detail, "message", message)
        set_dict_value(result.detail, "confirm", confirm_label)
        for b in buttons:
            set_dict_value(result.detail, f"urls.{b.action}", b.url)
            set_dict_value(result.detail, f"buttons.{b.action}", b.label)
        return result

    @staticmethod
    def button_dialog(title: str, message: str, buttons: List[Button]) -> "Event":
        """Create a button dialog event with the given title, message, and buttons (see `EventType.ONE_BUTTON`, `EventType.TWO_BUTTON`, and `EventType.THREE_BUTTON`)"""
        result = Event()

        # Dialog type
        match len(buttons):
            case 1:
                result.type = EventType.ONE_BUTTON
            case 2:
                result.type = EventType.TWO_BUTTON
            case 3:
                result.type = EventType.THREE_BUTTON

        clear_dict(result.detail)
        set_dict_value(result.detail, "title", title)
        set_dict_value(result.detail, "message", message)
        for b in buttons:
            set_dict_value(result.detail, f"urls.{b.action}", b.url)
            set_dict_value(result.detail, f"buttons.{b.action}", b.label)
        return result

    @staticmethod
    def custom_dialog(html: str, width_pc: int) -> "Event":
        """Create a custom dialog event with the given HTML content and width percentage (see `EventType.CUSTOM_DIALOG`)"""
        result = Event()
        result.type = EventType.CUSTOM_DIALOG
        clear_dict(result.detail)
        set_dict_value(result.detail, "custom.html", html)
        set_dict_value(result.detail, "custom.width_pc", width_pc)
        return result

    @staticmethod
    def download(data: BytesIO, mimetype: str, filename: str, mode: Literal["preview", "download"] = "download") -> "Event":
        """Create a download event with the given data stream, mimetype, filename, and mode (see `EventType.DOWNLOAD`)"""
        result = Event()
        result.type = EventType.DOWNLOAD
        clear_dict(result.detail)
        set_dict_value(result.detail, "payload.data", data)
        set_dict_value(result.detail, "payload.mimetype", mimetype)
        set_dict_value(result.detail, "payload.filename", filename)
        set_dict_value(result.detail, "payload.mode", mode)

        return result
