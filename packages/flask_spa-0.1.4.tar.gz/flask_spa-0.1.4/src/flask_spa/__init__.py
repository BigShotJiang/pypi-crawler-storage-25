"""
The `flask_spa` module provides the `FlaskSpa` class, which is a Flask extension that allows you to send events
from the server to the client in a single-page application (SPA) context.

The `FlaskSpa` class extends the Flask class and adds methods to send different types of events to the client,
such as setting the document title, redirecting to a URL, displaying alerts and toasts, showing confirmation
dialogs, and triggering file downloads.

The events are sent using the `FlaskMiddleware`, which manages the event queue and the stream to the client.

The `FlaskSpa` class provides a simple and convenient way to communicate with the client and enhance the user experience in a Flask-based SPA.
"""

from io import BytesIO
import mimetypes
from os import PathLike
from pathlib import Path
from typing import List

from flask import Flask

from .event_types import Event, EventSeverity, Button
from .middleware import FlaskMiddleware


class FlaskSpa(Flask):
    """A Flask extension that provides a simple way to send events from the server to the client.
    The FlaskSpa class extends the Flask class and adds methods to send different types of events to the client.
    The events are sent using the FlaskMiddleware, which is responsible for managing the event queue and the stream to the client.

    The FlaskSpa class provides the following methods to send events to the client:
    - `title(title: str)`: Sets the web document title. The title is sent to the client as an event, and the client will update the document title accordingly.

    - `redirect_to(url: str)`: Sends a redirection event to the client, which will redirect the client to the specified URL.

    - `alert(severity: EventSeverity, message: str, redirect_url: str = "")`: Sends an alert event to the client, which will display an alert message with the specified severity level. Optionally, a redirection URL can be provided, which will redirect the client after the alert is closed.

    - `toast(severity: EventSeverity, title: str, message: str, redirect_url: str = "")`: Sends a toast event to the client, which will display a toast message with the specified severity level, title, and message. Optionally, a redirection URL can be provided, which will redirect the client after the toast is closed.

    - `confirm(header: str, message: str, confirm_label: str, buttons: List[Button])`: Sends a confirmation dialog event to the client, which will display a confirmation dialog with the specified header, message, confirmation button label, and a list of buttons. Each button can have a label, a value, and an optional command that will be executed when the button is clicked.

    - `button_dialog(title: str, message: str, buttons: List[Button])`: Sends a button dialog event to the client, which will display a dialog with the specified title, message, and a list of buttons. Each button can have a label, a value, and an optional command that will be executed when the button is clicked.

    - `download(url: str, filename: str)`: Sends a download event to the client, which will trigger a file download with the specified URL and filename.
    """

    def __init__(
        self,
        import_name: str,
        static_url_path: str | None = None,
        static_folder: str | PathLike[str] | None = "static",
        static_host: str | None = None,
        host_matching: bool = False,
        subdomain_matching: bool = False,
        template_folder: str | PathLike[str] | None = "templates",
        instance_path: str | None = None,
        instance_relative_config: bool = False,
        root_path: str | None = None,
    ):
        # Initialize the Flask app with the provided parameters
        super().__init__(import_name, static_url_path, static_folder, static_host, host_matching, subdomain_matching, template_folder, instance_path, instance_relative_config, root_path)

        # Initialize the FlaskMiddleware and set it as an attribute of the FlaskSpa instance
        self._middleware = FlaskMiddleware(self)

    def _send(self, event: Event) -> None:
        """
        Pushes an event to the client.

        The event is added to the middleware's event queue, and the stream is set if it exists.
        """
        # Get the stream from the event and set it in the middleware if it exists
        stream = event.get_stream()
        if stream:
            self._middleware.set_stream(stream)

        # Add the event to the middleware's event queue
        self._middleware.add_event(event)

    def title(self, title: str):
        """
        Sets the web document title.

        The title is sent to the client as an event, and the client will update the document title accordingly.
        """
        # Set the title in the middleware
        self._middleware.set_title(title)

    def redirect_to(self, url: str = "") -> None:
        """
        Sends a redirection event to the client.

        The client will redirect to the specified URL when it receives this event.
        """
        # Send the redirection event to the client
        self._send(Event.redirect(url))

    def alert(self, severity: EventSeverity, message: str, redirect_url: str = "") -> None:
        """
        Sends an alert event to the client.

        Eventually, a redirection can be triggered after the alert is closed.
        """
        # Send the alert event to the client
        self._send(Event.alert(severity, message, redirect_url))

    def toast(self, severity: EventSeverity, title: str, message: str, redirect_url: str = "") -> None:
        """
        Sends a toast event to the client.

        Eventually, a redirection can be triggered after the toast is closed.

        The `title` parameter is the title of the toast, and the `message` parameter is the content of the toast.
        The `severity` parameter indicates the severity level of the toast (e.g., success, error, warning, info).
        """
        # Send the toast event to the client
        self._send(Event.toast(severity, title, message, redirect_url))

    def confirm(self, header: str, message: str, confirm_label: str, buttons: List[Button]) -> None:
        """Sends a confirmation dialog event to the client.

        The `buttons` parameter is a list of `Button` objects that will be displayed in the dialog.
        Each button can have a label, a value, and an optional command that will be executed when the button is clicked.

        The `confirm_label` parameter is the label of the confirmation button that will be displayed in the dialog.

        The `header` parameter is the title of the dialog, and the `message` parameter is the content of the dialog.
        """
        # Send the confirmation dialog event to the client
        self._send(Event.confirm(header, message, confirm_label, buttons))

    def button_dialog(self, title: str, message: str, buttons: List[Button]) -> None:
        """
        Sends a button dialog event to the client.

        The `buttons` parameter is a list of `Button` objects that will be displayed in the dialog.
        Each button can have a label, a value, and an optional command that will be executed when the button is clicked.
        """
        # Send the button dialog event to the client
        self._send(Event.button_dialog(title, message, buttons))

    def download(self, path: Path, filename: str, preview=False) -> None:
        """Sends a file download event to the client.

        The file is read from the specified `path`, and the `filename` parameter is the name that will be suggested to the user when downloading the file.

        If the `preview` parameter is set to `True`, the client will attempt to preview the file instead of downloading it.
        The behavior of the preview depends on the client's capabilities and the file type.
        """
        # Guess mimetype
        mimetype, _ = mimetypes.guess_type(path, strict=False)

        # Read the file content into a BytesIO object
        with open(path, "rb") as fh:
            file = BytesIO(fh.read())

        # Create a download event with the file content, mimetype, filename, and preview flag
        event = Event.download(file, mimetype or "", filename, "preview" if preview else "download")

        # Send the event to the client
        self._send(event)
