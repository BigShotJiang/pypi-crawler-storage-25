"""
HTTP utilities with retry logic for CODERS API requests.

Provides fetch_url_content() and urlopen_with_retry() with exponential backoff
and jitter to handle transient failures (timeouts, rate limiting).
"""
import random
import socket
import time
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

# Retry configuration
MAX_RETRIES = 3
BASE_DELAY = 2  # seconds
MAX_DELAY = 60  # cap for exponential backoff

# Retryable HTTP status codes (rate limit, server errors)
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def fetch_url_content(url: str, timeout: int = 30) -> bytes:
    """
    Fetch URL content with retries using exponential backoff and jitter.

    Retries on URLError, socket.timeout, and HTTPError 429/500/502/503/504.
    Does not retry on other 4xx client errors. Raises the last exception
    after all retries are exhausted.

    Args:
        url: URL to fetch.
        timeout: Request timeout in seconds.

    Returns:
        Raw response bytes.
    """
    last_exception = None
    for attempt in range(MAX_RETRIES):
        try:
            with urlopen(url, timeout=timeout) as response:
                return response.read()
        except (URLError, socket.timeout, HTTPError) as e:
            last_exception = e
            # Do not retry non-retryable 4xx client errors
            if isinstance(e, HTTPError) and e.code not in RETRYABLE_STATUS_CODES:
                raise
            if attempt == MAX_RETRIES - 1:
                raise last_exception
            # Exponential backoff with jitter to avoid thundering herd
            delay = min(BASE_DELAY * (2 ** attempt), MAX_DELAY) + random.uniform(0, 1)
            time.sleep(delay)
    raise last_exception  # Fallback (should not be reached)


def urlopen_with_retry(url: str, timeout: int = 30):
    """
    Open URL with retries, returning a context manager compatible with urlopen.

    Use fetch_url_content() for the common read-then-parse pattern instead.
    This is provided for cases where streaming or response metadata is needed.
    """
    last_exception = None
    for attempt in range(MAX_RETRIES):
        try:
            return urlopen(url, timeout=timeout)
        except (URLError, socket.timeout, HTTPError) as e:
            last_exception = e
            if isinstance(e, HTTPError) and e.code not in RETRYABLE_STATUS_CODES:
                raise
            if attempt == MAX_RETRIES - 1:
                raise last_exception
            delay = min(BASE_DELAY * (2 ** attempt), MAX_DELAY) + random.uniform(0, 1)
            time.sleep(delay)
    raise last_exception
