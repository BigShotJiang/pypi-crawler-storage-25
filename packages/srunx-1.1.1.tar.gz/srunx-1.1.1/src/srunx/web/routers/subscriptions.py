"""Notification subscriptions CRUD: ``/api/subscriptions/*``."""

from __future__ import annotations

import sqlite3
from typing import Any

import anyio
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..deps import get_db_conn, get_subscription_repo

router = APIRouter(prefix="/api/subscriptions", tags=["subscriptions"])

_VALID_PRESETS = ("terminal", "running_and_terminal", "all", "digest")

# Presets that are accepted for NEW subscriptions. The schema CHECK
# still allows ``'digest'`` (keeping any prior rows readable), but the
# service layer drops every delivery under that preset
# (``should_deliver('digest', ...) → False``), so new subscribers who
# picked it would silently receive zero notifications. Reject it at
# the API until digest batching is actually implemented. (P1-3)
_ACCEPTED_PRESETS_FOR_CREATE = ("terminal", "running_and_terminal", "all")


class SubscriptionCreate(BaseModel):
    watch_id: int = Field(..., gt=0)
    endpoint_id: int = Field(..., gt=0)
    preset: str = Field(default="terminal")


def _serialize(sub: Any) -> dict[str, Any]:
    d = sub.model_dump()
    for field in ("created_at",):
        val = d.get(field)
        if val is not None and hasattr(val, "isoformat"):
            d[field] = val.isoformat().replace("+00:00", "Z")
    return d


@router.get("")
async def list_subscriptions(
    watch_id: int | None = Query(default=None),
    endpoint_id: int | None = Query(default=None),
    limit: int = Query(default=200, ge=1, le=500),
    conn: sqlite3.Connection = Depends(get_db_conn),
) -> list[dict[str, Any]]:
    """List subscriptions.

    - With ``watch_id`` or ``endpoint_id`` → scoped listing (newest first).
    - Without either → recent subscriptions across all watches/endpoints,
      bounded by ``limit`` (default 200, max 500). Used by the
      NotificationsCenter dashboard.
    """
    repo = get_subscription_repo(conn)
    if watch_id is not None:
        rows = await anyio.to_thread.run_sync(lambda: repo.list_by_watch(watch_id))
    elif endpoint_id is not None:
        rows = await anyio.to_thread.run_sync(
            lambda: repo.list_by_endpoint(endpoint_id)
        )
    else:
        rows = await anyio.to_thread.run_sync(lambda: repo.list_recent(limit=limit))
    return [_serialize(r) for r in rows]


@router.post("", status_code=201)
async def create_subscription(
    body: SubscriptionCreate,
    conn: sqlite3.Connection = Depends(get_db_conn),
) -> dict[str, Any]:
    if body.preset not in _VALID_PRESETS:
        raise HTTPException(
            status_code=422,
            detail=f"Invalid preset '{body.preset}'. Allowed: {_VALID_PRESETS}",
        )
    if body.preset not in _ACCEPTED_PRESETS_FOR_CREATE:
        # Digest batching isn't implemented yet; accepting new
        # subscriptions under that preset would silently deliver zero
        # notifications.
        raise HTTPException(
            status_code=422,
            detail=(
                f"Preset '{body.preset}' is not implemented yet. "
                f"Accepted: {_ACCEPTED_PRESETS_FOR_CREATE}"
            ),
        )
    repo = get_subscription_repo(conn)
    try:
        new_id = await anyio.to_thread.run_sync(
            lambda: repo.create(body.watch_id, body.endpoint_id, body.preset)
        )
    except sqlite3.IntegrityError as exc:
        raise HTTPException(
            status_code=409,
            detail="subscription for this (watch, endpoint) already exists",
        ) from exc
    created = await anyio.to_thread.run_sync(lambda: repo.get(new_id))
    if created is None:
        raise HTTPException(
            status_code=500, detail="subscription vanished after create"
        )
    return _serialize(created)


@router.delete("/{subscription_id}", status_code=204)
async def delete_subscription(
    subscription_id: int,
    conn: sqlite3.Connection = Depends(get_db_conn),
) -> None:
    repo = get_subscription_repo(conn)
    ok = await anyio.to_thread.run_sync(lambda: repo.delete(subscription_id))
    if not ok:
        raise HTTPException(status_code=404, detail="subscription not found")
