from typing import Annotated

from pydantic import BaseModel, Field

from burnr8.client import get_client
from burnr8.errors import handle_google_ads_errors
from burnr8.helpers import run_gaql, validate_id


class NegativeKeyword(BaseModel):
    text: str = Field(description="The keyword text")
    match_type: str = Field(default="BROAD", description="Match type: EXACT, PHRASE, or BROAD")


def register(mcp):
    @mcp.tool
    @handle_google_ads_errors
    def list_negative_keywords(
        customer_id: Annotated[str, Field(description="Google Ads customer ID (no dashes)")],
        campaign_id: Annotated[str | None, Field(description="Filter by campaign ID")] = None,
        ad_group_id: Annotated[str | None, Field(description="Include ad-group-level negatives for this ad group ID")] = None,
    ) -> dict:
        """List negative keywords at campaign level, and optionally at ad group level."""
        if err := validate_id(customer_id, "customer_id"):
            return {"error": True, "message": err}
        if campaign_id and (err := validate_id(campaign_id, "campaign_id")):
            return {"error": True, "message": err}
        if ad_group_id and (err := validate_id(ad_group_id, "ad_group_id")):
            return {"error": True, "message": err}

        client = get_client()

        # --- Campaign-level negatives ---
        campaign_query = """
            SELECT
                campaign_criterion.criterion_id,
                campaign_criterion.keyword.text,
                campaign_criterion.keyword.match_type,
                campaign_criterion.negative,
                campaign.id,
                campaign.name
            FROM campaign_criterion
            WHERE campaign_criterion.type = 'KEYWORD'
                AND campaign_criterion.negative = true
        """
        if campaign_id:
            campaign_query += f" AND campaign.id = {campaign_id}"
        campaign_query += " ORDER BY campaign_criterion.keyword.text"

        rows = run_gaql(client, customer_id, campaign_query)
        campaign_negatives = []
        for row in rows:
            cc = row.get("campaign_criterion", {})
            kw = cc.get("keyword", {})
            c = row.get("campaign", {})
            campaign_negatives.append({
                "criterion_id": cc.get("criterion_id"),
                "text": kw.get("text"),
                "match_type": kw.get("match_type"),
                "campaign_id": c.get("id"),
                "campaign_name": c.get("name"),
                "level": "CAMPAIGN",
            })

        result = {"campaign_negatives": campaign_negatives}

        # --- Ad-group-level negatives (only when ad_group_id supplied) ---
        if ad_group_id:
            ag_query = f"""
                SELECT
                    ad_group_criterion.criterion_id,
                    ad_group_criterion.keyword.text,
                    ad_group_criterion.keyword.match_type,
                    ad_group_criterion.negative,
                    ad_group.id,
                    ad_group.name,
                    campaign.id,
                    campaign.name
                FROM ad_group_criterion
                WHERE ad_group_criterion.type = 'KEYWORD'
                    AND ad_group_criterion.negative = true
                    AND ad_group.id = {ad_group_id}
            """
            ag_query += " ORDER BY ad_group_criterion.keyword.text"

            ag_rows = run_gaql(client, customer_id, ag_query)
            ad_group_negatives = []
            for row in ag_rows:
                ac = row.get("ad_group_criterion", {})
                kw = ac.get("keyword", {})
                ag = row.get("ad_group", {})
                c = row.get("campaign", {})
                ad_group_negatives.append({
                    "criterion_id": ac.get("criterion_id"),
                    "text": kw.get("text"),
                    "match_type": kw.get("match_type"),
                    "ad_group_id": ag.get("id"),
                    "ad_group_name": ag.get("name"),
                    "campaign_id": c.get("id"),
                    "campaign_name": c.get("name"),
                    "level": "AD_GROUP",
                })
            result["ad_group_negatives"] = ad_group_negatives

        return result

    @mcp.tool
    @handle_google_ads_errors
    def add_negative_keywords(
        customer_id: Annotated[str, Field(description="Google Ads customer ID (no dashes)")],
        campaign_id: Annotated[str, Field(description="Campaign ID to add negative keywords to")],
        keywords: Annotated[list[NegativeKeyword], Field(description="List of negative keywords with text and match_type")],
    ) -> dict:
        """Add one or more negative keywords at campaign level via CampaignCriterionService."""
        if err := validate_id(customer_id, "customer_id"):
            return {"error": True, "message": err}
        if err := validate_id(campaign_id, "campaign_id"):
            return {"error": True, "message": err}

        client = get_client()
        campaign_criterion_service = client.get_service("CampaignCriterionService")
        campaign_service = client.get_service("CampaignService")

        operations = []
        for kw in keywords:
            operation = client.get_type("CampaignCriterionOperation")
            criterion = operation.create
            criterion.campaign = campaign_service.campaign_path(customer_id, campaign_id)
            criterion.negative = True

            match_map = {
                "EXACT": client.enums.KeywordMatchTypeEnum.EXACT,
                "PHRASE": client.enums.KeywordMatchTypeEnum.PHRASE,
                "BROAD": client.enums.KeywordMatchTypeEnum.BROAD,
            }
            criterion.keyword.text = kw.text
            criterion.keyword.match_type = match_map.get(
                kw.match_type.upper(),
                client.enums.KeywordMatchTypeEnum.BROAD,
            )
            operations.append(operation)

        response = campaign_criterion_service.mutate_campaign_criteria(
            customer_id=customer_id, operations=operations
        )
        return {
            "added": len(response.results),
            "resource_names": [r.resource_name for r in response.results],
        }

    @mcp.tool
    @handle_google_ads_errors
    def add_ad_group_negative_keywords(
        customer_id: Annotated[str, Field(description="Google Ads customer ID (no dashes)")],
        ad_group_id: Annotated[str, Field(description="Ad group ID to add negative keywords to")],
        keywords: Annotated[list[NegativeKeyword], Field(description="List of negative keywords with text and match_type")],
    ) -> dict:
        """Add one or more negative keywords at ad group level via AdGroupCriterionService."""
        if err := validate_id(customer_id, "customer_id"):
            return {"error": True, "message": err}
        if err := validate_id(ad_group_id, "ad_group_id"):
            return {"error": True, "message": err}

        client = get_client()
        ad_group_criterion_service = client.get_service("AdGroupCriterionService")
        ad_group_service = client.get_service("AdGroupService")

        operations = []
        for kw in keywords:
            operation = client.get_type("AdGroupCriterionOperation")
            criterion = operation.create
            criterion.ad_group = ad_group_service.ad_group_path(customer_id, ad_group_id)
            criterion.negative = True

            match_map = {
                "EXACT": client.enums.KeywordMatchTypeEnum.EXACT,
                "PHRASE": client.enums.KeywordMatchTypeEnum.PHRASE,
                "BROAD": client.enums.KeywordMatchTypeEnum.BROAD,
            }
            criterion.keyword.text = kw.text
            criterion.keyword.match_type = match_map.get(
                kw.match_type.upper(),
                client.enums.KeywordMatchTypeEnum.BROAD,
            )
            operations.append(operation)

        response = ad_group_criterion_service.mutate_ad_group_criteria(
            customer_id=customer_id, operations=operations
        )
        return {
            "added": len(response.results),
            "resource_names": [r.resource_name for r in response.results],
        }

    @mcp.tool
    @handle_google_ads_errors
    def remove_negative_keyword(
        customer_id: Annotated[str, Field(description="Google Ads customer ID (no dashes)")],
        criterion_id: Annotated[str, Field(description="Negative keyword criterion ID to remove")],
        campaign_id: Annotated[str | None, Field(description="Campaign ID (required for campaign-level negatives)")] = None,
        ad_group_id: Annotated[str | None, Field(description="Ad group ID (required for ad-group-level negatives)")] = None,
        confirm: Annotated[bool, Field(description="Must be true to execute removal.")] = False,
    ) -> dict:
        """Remove a negative keyword. Provide campaign_id for campaign-level or ad_group_id for ad-group-level. Requires confirm=true."""
        if not confirm:
            return {
                "warning": f"This will remove negative keyword criterion {criterion_id}. "
                "Set confirm=true to execute."
            }

        if err := validate_id(customer_id, "customer_id"):
            return {"error": True, "message": err}
        if err := validate_id(criterion_id, "criterion_id"):
            return {"error": True, "message": err}

        if not campaign_id and not ad_group_id:
            return {"error": True, "message": "Provide either campaign_id (campaign-level) or ad_group_id (ad-group-level)."}

        if campaign_id and ad_group_id:
            return {"error": True, "message": "Provide only one of campaign_id or ad_group_id, not both."}

        client = get_client()

        if campaign_id:
            if err := validate_id(campaign_id, "campaign_id"):
                return {"error": True, "message": err}
            campaign_criterion_service = client.get_service("CampaignCriterionService")
            resource_name = campaign_criterion_service.campaign_criterion_path(
                customer_id, campaign_id, criterion_id
            )
            operation = client.get_type("CampaignCriterionOperation")
            operation.remove = resource_name
            response = campaign_criterion_service.mutate_campaign_criteria(
                customer_id=customer_id, operations=[operation]
            )
        else:
            if err := validate_id(ad_group_id, "ad_group_id"):
                return {"error": True, "message": err}
            ad_group_criterion_service = client.get_service("AdGroupCriterionService")
            resource_name = ad_group_criterion_service.ad_group_criterion_path(
                customer_id, ad_group_id, criterion_id
            )
            operation = client.get_type("AdGroupCriterionOperation")
            operation.remove = resource_name
            response = ad_group_criterion_service.mutate_ad_group_criteria(
                customer_id=customer_id, operations=[operation]
            )

        return {"removed": response.results[0].resource_name}
