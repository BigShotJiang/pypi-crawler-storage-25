# Run {{title}} from the GDM-SAR-In processing pipeline

The **GDM-SAR-In** (Ground Deformation Monitoring using SAR Interferometry) on-demand processing service is a [Data Terra](https://www.data-terra.org/) service developed and operated by its solid Earth hub, FormaTerre, in collaboration with [ISTerre](https://www.isterre.fr/) ([OSUG](https://www.osug.fr/)), [IPGP](https://www.ipgp.fr/), [CNES](https://cnes.fr/fr) and the [ISDeform NOS](https://www.isdeform.fr/). The service is deployed on the CNES computing center. It was set up with the support of CNES and [CNRS/INSU](https://www.insu.cnrs.fr/fr/institut-national-des-sciences-de-lunivers).

It is linked to the [Thematic Core Service « Satellite Data »](https://www.epos-eu.org/tcs/satellite-data) of the European research infrastructure [EPOS](https://www.epos-eu.org/), as GDM-SAR-In provides products that can be exposed on the [EPOS data portal](https://www.ics-c.epos-eu.org/).

GDM-SAR-In uses the **NSBAS processing chain** (Doin et al., 2011, Grandin, 2015, see providers) to process radar images acquired by the Sentinel-1 satellites (in IW mode) of the [Copernicus](https://www.copernicus.eu/fr) program. It enables the user to calculate interferograms or **InSAR** time series, as well as other associated products. Detailed product descriptions are available in a [dedicated document](https://formater.pages.in2p3.fr/flatsim/).

This product contains data over {{nbdates}}.

`nsbas.proc`, `success_coreg_*txt`, `baseline*rsc`
: List of the auxiliary files related to the interferogram processing for each subswaths (iw1, iw2, iw3). In particular busts selection and perpendicular baseline information.

{{shortdesc}}
