# The auxiliary data collection from run {{title}}

The **auxiliary data** contain product relative to LOS vectors, digital elevation models, lookup tables and temporal coherence.
