"""
This file is a CLI to test the processor independently from a STAC Repository.
To use it, just call "uv run stac_processor_gdmsar/app.py" from the main directory.

The CLI has the following commands:
- discover: to test the discover function, it will print the product sources discovered in the given source
- process: to test the process function, it will convert the given product source into a STAC catalog, and save it in the given destination directory
- version: to test the version function, it will print the version of the given product source
- id: to test the id function, it will print the id of the given product source

This CLI is only for testing purposes, it is not intended to be used by users of the processor, and it is not intended to be used in production. 
It is only a way to test the processor independently from a STAC Repository, and to check that the output of the processor is correct.
"""

import logging
import os
import shutil
import typer
from tqdm import tqdm
from stac_processor_gdmsar.__about__ import __version__
from stac_processor_gdmsar.discover import discover as api_discover
from stac_processor_gdmsar.id import id as api_id
from stac_processor_gdmsar.version import version as api_version
from stac_processor_gdmsar.process import process as api_process

# define the logger (the logger is already configured in ./__init__.py)
logger = logging.getLogger(__name__)

# define the CLI app
app = typer.Typer()

def set_time_between_requests(time_between_requests: float):
    if time_between_requests is not None:
        os.environ["STAC_PROCESSOR_GDMSAR_MIN_TIME_BETWEEN_REQUESTS"] = str(time_between_requests)
        logger.debug(f"Setting minimum time between requests to {time_between_requests} seconds for this process")

@app.callback(invoke_without_command=True)
def main(version: bool = False):
    logger.debug("Calling 'main' function of the CLI")
    if version:
        logger.info(f"Version: {__version__}")


@app.command()
def id(product_source: str, time_between_requests: float = None):
    # usage: uv run stac_processor_gdmsar/app.py id <product_source>
    logger.debug(f"Calling 'id' command with product_source: {product_source}")
    set_time_between_requests(time_between_requests)
    id = api_id(product_source)
    logger.info(f"ID: {id}")


@app.command()
def version(product_source: str, time_between_requests: float = None):
    # usage: uv run stac_processor_gdmsar/app.py version <product_source>
    logger.debug(f"Calling 'version' command with product_source: {product_source}")
    set_time_between_requests(time_between_requests)
    version = api_version(product_source)
    logger.info(f"Version: {version}")


@app.command()
def discover(source: str, time_between_requests: float = None):
    # usage: uv run stac_processor_gdmsar/app.py discover <source>
    logger.debug(f"Calling 'discover' command with source: {source}")
    set_time_between_requests(time_between_requests)
    product_sources = api_discover(source)
    for product_source in product_sources:
        logger.info(f"{product_source}")

@app.command()
def process(product_source: str, destination: str, import_assets: bool = False, hide_progress_bar: bool = False, time_between_requests: float = None):
    # usage: uv run stac_processor_gdmsar/app.py process <product_source> <destination> [--import-assets]
    logger.debug(f"Calling 'process' command with product_source: {product_source}, destination: {destination}, import_assets: {import_assets}")

    class DummyProgressBar:
        def init(self, total): self.progress_bar = tqdm(total=total)
        def update(self, n=1): self.progress_bar.update(n)
        def close(self): 
            self.progress_bar.n = self.progress_bar.total # make sure the progress bar is at 100% at the end of the process (just as a precaution, but it should not be necessary)
            self.progress_bar.close()

    if destination is not None:
        try:
            set_time_between_requests(time_between_requests)
            # call the process function that returns the path of the corresponding collection in a temporary directory
            if hide_progress_bar: 
                href = api_process(product_source, import_assets=import_assets)
            else:
                progress_bar = DummyProgressBar()
                href = api_process(product_source, import_assets=import_assets, callback_init=progress_bar.init, callback_update=progress_bar.update)
            parent_result_dir = os.path.dirname(href)
            # clean the previous content of destination, if any
            os.makedirs(destination, exist_ok=True)

            logger.debug(f"Moving the processed files to destination {destination}")
            # move the entire directory to destination, erasing previous content if any
            complete_destination = os.path.join(destination, os.path.basename(parent_result_dir))
            if os.path.exists(complete_destination):
                if os.path.isdir(complete_destination):
                    shutil.rmtree(complete_destination, ignore_errors=True)
                else:
                    os.remove(complete_destination)
            shutil.move(parent_result_dir, complete_destination)

            result = os.path.join(destination, os.path.basename(parent_result_dir))
            logger.info(f"Processing completed successfully. The STAC collection has been saved in {result}")
            if not hide_progress_bar: progress_bar.close()

        except BaseException as error:
            logger.error(f"Error occurred while processing: {error}")
            raise error

if __name__ == "__main__":
    app()
