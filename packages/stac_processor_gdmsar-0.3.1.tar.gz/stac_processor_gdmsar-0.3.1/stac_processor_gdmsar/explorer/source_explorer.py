import html.parser
import logging
import os
import requests
import time
import urllib.parse

from typing import List, Any
from functools import lru_cache

from .base_explorer import BaseExplorer

logger = logging.getLogger(__name__)

class SourceExplorer(BaseExplorer):

    # we use a static session to reuse the same connection for multiple requests, which is more efficient than creating a new connection for each request
    session = requests.Session()

    time_since_last_request: float = 0
    default_time_between_requests: float = 0.25 # in seconds
    min_time_between_requests: float = None # in seconds

    @staticmethod
    def wait_between_requests():
        # first we need to check if the minimum time between requests is set, if not we use the value from the environment variable or the default value
        if SourceExplorer.min_time_between_requests is None:
            env_min_time = os.environ.get("STAC_PROCESSOR_GDMSAR_MIN_TIME_BETWEEN_REQUESTS")
            if env_min_time is not None:
                try:
                    min_time = float(env_min_time)
                    if min_time >= 0:
                        SourceExplorer.min_time_between_requests = min_time
                        logger.debug(f"Setting min_time_between_requests to {min_time} seconds based on environment variable")
                    else:
                        logger.warning(f"Invalid value for STAC_PROCESSOR_GDMSAR_MIN_TIME_BETWEEN_REQUESTS: {min_time}. Using default value of {SourceExplorer.default_time_between_requests} seconds")
                        SourceExplorer.min_time_between_requests = SourceExplorer.default_time_between_requests
                except ValueError:
                    logger.warning(f"Invalid value for STAC_PROCESSOR_GDMSAR_MIN_TIME_BETWEEN_REQUESTS: {env_min_time}. Using default value of {SourceExplorer.default_time_between_requests} seconds")
                    SourceExplorer.min_time_between_requests = SourceExplorer.default_time_between_requests
            else:
                SourceExplorer.min_time_between_requests = SourceExplorer.default_time_between_requests
        # then we need to check how much time has passed since the last request, and if it is less than the minimum time between requests, we need to wait for the remaining time
        time_since_last_request = time.time() - SourceExplorer.time_since_last_request
        if time_since_last_request < SourceExplorer.min_time_between_requests:
            time.sleep(SourceExplorer.min_time_between_requests - time_since_last_request)

    @staticmethod
    @lru_cache(maxsize=None)
    def source_get(url: str) -> requests.Response:
        # make sure that we wait at least min_time_between_requests seconds between each request, to avoid overwhelming the server
        SourceExplorer.wait_between_requests()
        # request the url, retry if it fails, up to 3 times, with a delay of 1 second between each attempt
        nb_attempts = 3
        sleep_time = 1
        last_exception = None
        for i in range(nb_attempts):
            try:
                # logger.debug(f"Getting {url} (attempt {i+1}/{nb_attempts})...")
                # response = requests.get(url)
                response = SourceExplorer.session.get(url)
                response.raise_for_status()
                SourceExplorer.time_since_last_request = time.time()
                return response
            except Exception as e:
                if i < nb_attempts - 1:
                    logger.debug(f"Failed to get {url}: {e}. Attempt {i+1}/{nb_attempts} in {sleep_time} second...")
                last_exception = e
                time.sleep(sleep_time)
        logger.error(f"Failed to get {url} after {nb_attempts} attempts")
        raise Exception(f"Failed to get {url} after {nb_attempts} attempts") from last_exception

    @classmethod
    def validate(cls, url: str) -> None:
        response = cls.source_get(url)
        response.close()

    class DirListingParser(html.parser.HTMLParser):
        _hrefs: List[str]

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._hrefs = []

        @property
        def hrefs(self):
            return self._hrefs

        def handle_starttag(self, tag, attrs):
            if tag == "a":
                for (attr_name, attr_value) in attrs:
                    if attr_name == "href":
                        self._hrefs.append(attr_value)

    @classmethod
    def list_dir(cls, dir_listing_url: str) -> List[str]:
        response = cls.source_get(dir_listing_url)

        if not response.headers["content-type"].startswith("text/html"):
            raise NotADirectoryError

        parser = cls.DirListingParser()
        parser.feed(response.text)
        parser.close()
        response.close()

        def is_in_directory(dir: str, file: str):
            file = file[:-1] if file.endswith("/") else file
            dir = dir[:-1] if dir.endswith("/") else dir
            return file.startswith(dir) and file != dir

        return [
            cls.basename(href)
            for href
            in parser.hrefs
            if is_in_directory(dir_listing_url, cls.join(dir_listing_url, href))
        ]

    @classmethod
    def load_json(cls, file_url: str) -> Any:
        response = cls.source_get(file_url)
        json = response.json()
        response.close()
        return json

    @classmethod
    def load(cls, file_url: str) -> Any:
        response = cls.source_get(file_url)
        text = response.text
        response.close()
        return text

    @classmethod
    def join(cls, file_dir_name: str, file_base_name: str) -> str:
        if not file_dir_name.endswith("/"):
            file_dir_name += "/"

        return urllib.parse.urljoin(file_dir_name, file_base_name)

    @classmethod
    def basename(cls, file: str) -> str:
        file_path = urllib.parse.urlparse(file).path
        if file_path.endswith("/"):
            file_path = file_path[:-1]
        file_parts = file_path.split("/")
        file_name = file_parts.pop()

        # if the file is a directory, add the trailing slash back to the name
        # this is necessary to distinguish between a file and a directory with the same name
        if file.endswith("/"):
            file_name += "/"

        return file_name

    @classmethod
    def dirname(cls, file: str) -> str:
        url_parts = urllib.parse.urlparse(file)
        file_path = url_parts.path

        if file_path.endswith("/"):
            file_path = file_path[:-1]

        file_parts = file_path.split("/")
        file_parts.pop()

        return urllib.parse.urlunparse(url_parts._replace(path="/".join(file_parts)))

    @classmethod
    def resolve(cls, file: str) -> str:
        return file

    @classmethod
    def is_directory(cls, file: str) -> bool:
        # response = requests.head(file)
        response = SourceExplorer.session.head(file)
        response.raise_for_status()

        return response.headers["content-type"].startswith("text/html")

    @classmethod
    def copy(cls, file: str, destination: str):
        try:
            file_response = cls.source_get(file)
            with open(destination, 'wb') as f:
                for chunk in file_response.iter_content(chunk_size=8192):
                    f.write(chunk)
            file_response.close()
        except Exception as e:
            logger.error(f"Failed to download {file}: {e}")
