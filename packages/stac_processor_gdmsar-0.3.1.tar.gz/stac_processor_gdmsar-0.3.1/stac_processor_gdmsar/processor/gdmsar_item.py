from datetime import datetime
import logging
import pystac

from stac_processor_gdmsar.processor.gdmsar_element import GDMElement
import stac_processor_gdmsar.metadata.common_metadata as metadata
import stac_processor_gdmsar.metadata.extensions as extensions
import stac_processor_gdmsar.metadata.templates as templates

logger = logging.getLogger(__name__)

class GDMItem(GDMElement):
    json_files: dict = {} # contains the content of all the json files associated to this element
    json: dict = None # this will contain the content of the future stac file

    def __init__(self, uuid: str, main_id: str, file_basename: str, files: list[str], geometry: str, codes: list[str] = [], date: str = "", resolution: str = "", default_keywords: list[str] = None) -> None:
        self.uuid = uuid
        self.main_id = main_id
        self.file_name = f"{file_basename}.json"
        self.files = files
        self.geometry = geometry
        self.codes = codes
        self.date = date
        self.resolution = resolution
        self.default_keywords = default_keywords
        self.stac_id = f"{main_id}_{file_basename}"

    def generate_stac_object(self):
        # this function can be used to generate the stac item after the properties have been updated, for example to update the keywords after creating the item
        self.json_files = templates.get_json_files(self.files, self.codes, self.geometry)
        # it's possible that there are no files corresponding to this code and geometry, in this case we will not create a stac item
        if len(self.json_files) == 0:
            # logger.debug(f"No json files found for item in folder {self.folder_name} with codes {self.codes} and geometry {self.geometry}. Skipping item creation.")
            logger.debug(f"No json files found for item {self.file_name} with codes {self.codes} and geometry {self.geometry}. Skipping item creation.")
            return
        self.keywords = templates.get_keywords(self.files, self.codes, self.geometry, self.default_keywords)
        assets = templates.get_assets(self.files, self.codes, self.geometry, self.date, self.resolution)
        # an item without any asset should not be created
        if len(assets) == 0: return

        self.title = templates.get_title(self.codes[0], self.geometry)
        self.description = templates.get_description(self.codes[0], self.geometry)
        self.update_properties()

        # create the stac item
        self.stac_object = pystac.Item(
            id=self.stac_id, 
            geometry=self.get_geometry(), 
            bbox=self.get_bbox(), 
            properties=self.get_properties(),
            datetime=self.get_datetime(), 
            assets = assets if len(assets) > 0 else None,
        )
        # add links to the stac item
        self.add_common_links()
        logger.debug(f"Stac item {self.stac_id} created with {len(assets)} assets")
        

    def update_properties(self):
        # use the content from the original json file as much as possible
        if len(self.json_files) > 0:
            # take the first json file as a base, but some fields can be extracted from the others if they are not present in the first one
            self.json = list(self.json_files.values())[0]
            # at this point, we know that self.json has a "properties" field
            updated_properties = self.json["properties"].copy()
            # change the title, description, etc.
            updated_properties["parent_collection"] = self.main_id
            updated_properties["uuid"] = self.uuid
            updated_properties["title"] = self.title
            updated_properties["description"] = self.description
            providers_json = []
            for provider in metadata.providers:
                providers_json.append({
                    "name": provider.name,
                    "description": provider.description,
                    "roles": [role.value for role in provider.roles],
                    "url": provider.url,
                })
            updated_properties["providers"] = providers_json
            updated_properties["platforms"] = metadata.platforms
            updated_properties["instruments"] = metadata.instruments
            updated_properties["constellation"] = metadata.constellation
            updated_properties["mission"] = metadata.mission
            updated_properties["licenses"] = metadata.license_name
            # add the extensions
            updated_properties.update(extensions.get_sat_extension_properties(self.json))
            updated_properties.update(extensions.get_sar_extension_properties(self.json))
            updated_properties.update(extensions.get_processing_extension_properties(self.json))
            updated_properties.update(extensions.get_insar_extension_properties(self.json))
            updated_properties.update(extensions.get_projection_extension_properties(self.json))
            updated_properties.update(extensions.get_scientific_extension_properties(self.json))
            # if pystac does not do it, add the links and the stac version
            self.json["properties"] = updated_properties
            # if the properties contain a "sat:orbit_state" field, we can add its value to the keywords
            if "sat:orbit_state" in updated_properties:
                self.keywords.append(updated_properties["sat:orbit_state"])

    def get_geometry(self) -> dict: return self.json["geometry"] if "geometry" in self.json else {}
    def get_bbox(self) -> list[float]: return self.json["bbox"] if "bbox" in self.json else []
    def get_properties(self) -> dict: return self.json["properties"] if "properties" in self.json else {}
    def get_datetime(self) -> datetime: 
        for field in ["updated", "created", "datetime", "start_datetime"]:
            try:
                return datetime.fromisoformat(self.json["properties"][field])
            except:
                continue
        return None

    def update_variables(self, content: str|list):
        def do_update(item: str) -> str:
            item = item.replace("{{id}}", self.stac_id)
            item = item.replace("{{title}}", self.title)
            item = item.replace("{{geometry}}", self.geometry)
            if "{{from}}" in item and "{{to}}" in item and "_" in self.date:
                date_from, date_to = self.date.split("_")
                item = item.replace("{{from}}", date_from)
                item = item.replace("{{to}}", date_to)
            return item
        if isinstance(content, str): 
            return do_update(content)
        else:
            return [do_update(item) for item in content]

    def update_keywords(self, keywords: list[str]):
        # updates the current list of keywords with keywords from the parent collection, without duplicates
        current_keywords = set(self.keywords)
        parent_keywords = set(keywords)
        all_keywords = current_keywords.union(parent_keywords)
        self.keywords = self.update_variables(list(all_keywords))
        if self.stac_object is not None:
            self.stac_object.properties["keywords"] = self.keywords
