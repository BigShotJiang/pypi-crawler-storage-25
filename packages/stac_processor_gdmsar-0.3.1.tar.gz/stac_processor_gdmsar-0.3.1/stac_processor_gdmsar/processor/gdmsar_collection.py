import logging
import os
import pystac

import stac_processor_gdmsar.metadata.common_metadata as metadata
import stac_processor_gdmsar.metadata.templates as templates
from stac_processor_gdmsar.processor.gdmsar_catalog import GDMCatalog
from stac_processor_gdmsar.processor.gdmsar_item import GDMItem
from stac_processor_gdmsar.processor.utils import list_all_dates, load_json

logger = logging.getLogger(__name__)


class GDMCollection(GDMCatalog):
    def __init__(self, uuid: str, main_id: str, title: str, file_basename: str, files: list[str], geometry: str, codes: list[str] = [], date: str = "", 
          child_collections: list["GDMCollection"] = [], child_items: list[GDMItem] = [], template_list: list[str] = []):
        # store the information
        self.uuid = uuid
        self.main_id = main_id
        self.title = title
        self.file_name = f"{file_basename}.json"
        self.files = files
        self.geometry = geometry
        self.codes = codes
        self.date = date
        self.stac_id = f"{main_id}_{file_basename}"
        # remove the children who have no stac object
        self.child_collections = [collection for collection in child_collections if collection.stac_object is not None]
        self.child_items = []
        for item in child_items:
            item.generate_stac_object()
            if item.stac_object is not None:
                self.child_items.append(item)
        # get some more information from the templates and the files, such as the keywords and the assets
        extra_fields = {"uuid": uuid} # add the uuid as an extra field, to make it easier to find the corresponding collection for a given product source
        if main_id != uuid: extra_fields["parent_id"] = main_id # do not add the parent_id if the current collection is the main collection
        assets = templates.get_assets(files, codes, geometry, date)
        self.keywords = self.get_keywords([], files, template_list, codes, geometry)

        # do not create the stac object if there are no child items, no child collections and no assets
        if len(self.child_items) == 0 and len(self.child_collections) == 0 and len(assets) == 0:
            logger.debug(f"Not creating stac collection for {self.stac_id} because it has no child items, no child collections and no assets")
            return

        # use the children to create the stac collection
        self.stac_object = pystac.Collection(
            id=self.stac_id, 
            description=templates.read_template(template_list[0]) if len(template_list) > 0 else "",
            extent=self.get_extent(),
            title=self.title, 
            license=metadata.license_name,
            keywords=self.keywords,
            providers=metadata.providers,
            summaries=None, # will be set later, after all the items are created
            extra_fields=extra_fields, # if we want to add more fields at the top level of the collection
            assets=assets if len(assets) > 0 else None, 
            catalog_type=pystac.CatalogType.SELF_CONTAINED,
        )
        # add links to the stac collection
        self.add_common_links()
        logger.debug(f"Stac collection {self.stac_id} created with {len(assets)} assets, {len(self.child_collections)} child collections and {len(self.child_items)} child items")

    def get_keywords(self, default_keywords: list[str] = [], files: list[str] = [], template_list: list[str] = [], codes: list[str] = [], geometry: str = "") -> list[str]:
        # keywords can come from different sources: the type of collection, the templates, the geometry, an information in a filename, etc.
        keywords = set()
        # add the default keywords
        keywords.update(default_keywords)
        # add the keywords from the templates
        for template in template_list:
            template_keywords = templates.get_keywords_from_template(template)
            if template_keywords is not None: keywords.update(template_keywords)
        # add the keywords from the code and geometry
        if len(codes) > 0 and geometry != "":
            code_geometry_keywords = templates.get_keywords(files, codes, geometry)
            if code_geometry_keywords is not None: keywords.update(code_geometry_keywords)
        # return a list of keywords without duplicates
        return list(keywords)

    def get_child_items(self) -> list[GDMItem]:
        child_items = []
        # only return the children who have a stac object
        for item in self.child_items:
            if item.stac_object is not None:
                child_items.append(item.stac_object)
        for collection in self.child_collections:
            if collection.stac_object is not None:
                child_items.extend(collection.get_child_items())
        return child_items
    
    def get_extent(self):
        # if there are no child items, the extent will be like "extent": {"spatial": {"bbox": [[null,null,null,null]]},"temporal": {"interval": [[null,null]]}}
        # it feels wrong, but it's better to have a correct extent with null values than to have an extent with empty lists
        children = self.get_child_items()
        return pystac.Extent.from_items(children)

    def _clean_summary_lists(self, lists: dict[str, list]) -> dict[str, list]:
        # Children summaries contain arrays with potentially shared values for multiple items. Specifications require to merge these arrays into a single array with unique elements.
        # cf. https://github.com/radiantearth/stac-spec/blob/master/collection-spec/collection-spec.md#summaries
        def make_hashable(e):
            if isinstance(e, dict): return tuple(sorted((k, make_hashable(v)) for k, v in e.items()))
            elif isinstance(e, (list, tuple)): return tuple(make_hashable(x) for x in e)
            return e

        def remove_duplicates(my_list):
            seen = set()
            result = []
            for item in my_list:
                hashable = make_hashable(item)
                if hashable not in seen:
                    seen.add(hashable)
                    result.append(item)
            return result

        cleaned_summary_lists = {}
        for key in lists:
            cleaned_summary_lists[key] = remove_duplicates(lists[key])
        return cleaned_summary_lists

    def get_summary(self):
        summarizer = pystac.summaries.Summarizer()
        items = self.get_child_items()
        summary = summarizer.summarize(items)
        # remove duplicates in the lists of the summary
        summary.lists = self._clean_summary_lists(summary.lists)
        return summary

    def get_short_description(self):
        for file in self.files:
            if file.endswith(".json") and templates.get_matching_product(file, self.codes, self.geometry):
                json = load_json(file)
                return json.get("properties", {}).get("Short-description", "")
        return ""

    def update_variables(self, content: str|list):
        def do_update(item: str) -> str:
            item = item.replace("{{id}}", self.stac_id)
            item = item.replace("{{title}}", self.title)
            item = item.replace("{{geometry}}", self.geometry)
            if "{{nbdates}}" in item:
                nb = len(list_all_dates(self.files))
                item = item.replace("{{nbdates}}", f"{nb} date{'s' if nb > 1 else ''}")
            if "{{from}}" in item and "{{to}}" in item and "_" in self.date:
                date_from, date_to = self.date.split("_")
                # date_from and date_to are in the format YYYYMMDD, we want to convert them to the format YYYY-MM-DD
                item = item.replace("{{from}}", f"{date_from[:4]}-{date_from[4:6]}-{date_from[6:]}")
                item = item.replace("{{to}}", f"{date_to[:4]}-{date_to[4:6]}-{date_to[6:]}")
            item = item.replace("{{shortdesc}}", self.get_short_description())
            return item
        if isinstance(content, str): 
            return do_update(content)
        else:
            return [do_update(item) for item in content]

    def update_keywords(self, keywords: list[str]):
        # add the keywords from the parent collection to the existing keywords, without duplicates
        current_keywords = set(self.keywords)
        parent_keywords = set(keywords)
        all_keywords = current_keywords.union(parent_keywords)
        self.keywords = self.update_variables(list(all_keywords))

    def get_child_relative_path(self, child_href: str) -> str:
        if self.stac_object is None or child_href is None: return None
        # get the href from the current stac object
        href = self.stac_object.get_self_href()
        # remove the file name to get the directory
        directory = os.path.dirname(href)
        # replace that directory with a "." to get the relative path from this collection to the child item or collection
        return child_href.replace(directory, ".")

    def check_extent(self):
        # an extent can be empty when a collection has just a list of assets, but no child items and no child collections
        # an empty extent contains bboxes and intervals with null values
        # this is valid according to the stac specification, but it creates validation errors with some stac validators, so we need to clean the extent in this case
        # extents cannot be removed before because they are needed to create the extent of their parents

        def is_null_or_inf(array):
            for element in array:
                if element is not None and element != float("inf") and element != float("-inf"):
                    return False
            return True

        # return if the objects are not present, it avoids having lots of nested if statements
        if self.stac_object is None or self.stac_object.extent is None: return
        if self.stac_object.extent.spatial is None or self.stac_object.extent.spatial.bboxes is None: return
        if self.stac_object.extent.temporal is None or self.stac_object.extent.temporal.intervals is None: return
        if len(self.stac_object.extent.spatial.bboxes) == 0 or len(self.stac_object.extent.temporal.intervals) == 0: return

        # test if the bboxes are empty, and if they contain real values (not null, not inf)
        if is_null_or_inf(self.stac_object.extent.spatial.bboxes[0]) or is_null_or_inf(self.stac_object.extent.temporal.intervals[0]):
            logger.warning(f"The extent of collection '{self.stac_object.id}' contains null or inf values.")
            # print(f"Warning: the extent of collection {self.stac_object.id} contains null or inf values.")
            # the next lines would work here, but the stac file would later be impossible to open
            # self.stac_object.extent.spatial.bboxes = []
            # self.stac_object.extent.temporal.intervals = []


    def update_stac(self, base_path: str = "", keywords: list[str] = [], parent_href: str = None):
        # this function will diffuse some information to its children, such as  keywords and paths
        # add the keywords from the parent to the current collection
        self.update_keywords(keywords)
        # set self href for the current collection
        self.stac_object.set_self_href(f"{base_path}/{self.file_name}")
        # clear the extent if it contains null values, to avoid validation errors
        self.check_extent()
        # create child links for all child collections
        for collection in self.child_collections:
            if collection.stac_object is not None:
                # update the child collections recursively
                collection.update_stac(base_path, self.keywords, f"./{self.file_name}")
                # create the link from this collection to the child collection
                self.link_to("child", collection, self.get_child_relative_path(collection.stac_object.get_self_href()))
                # create the link from the child collection to this collection
                if parent_href is not None: collection.link_to("parent", self, parent_href)
        # create child links for all child items
        for item in self.child_items:
            if item.stac_object is not None:
                # add the keywords from this collection to the item
                item.update_keywords(self.keywords)
                # create the link from the item to this collection
                item.link_to("parent", self, parent_href if parent_href is not None else "collection.json") # parent_href should be there, but if not we can use main collection
                item.link_to("collection", self, "./collection.json")
                # set the href of the item to point to the new location of the stac file
                item.stac_object.set_self_href(f"{base_path}/{item.file_name}")
                # add the parent collection
                item.stac_object.collection_id = self.stac_object.id
                # create the link from this collection to the item, with a relative path
                self.link_to("item", item, self.get_child_relative_path(item.stac_object.get_self_href()))

    def summarize(self):
        # summarize the collection after all the items have been created, and after all the keywords have been updated
        if self.stac_object is not None:
            self.stac_object.keywords = None # only keep the summary keywords, to avoid confusion and redundancy, and to be sure that the keywords are consistent with the content of the items
            self.stac_object.summaries = self.get_summary()
        for collection in self.child_collections:
            collection.summarize()

    def add_extra_assets(self, assets: dict[str, pystac.Asset]):
        # if self.stac_object is None: return
        # add the assets to the child items, and recursively to the child collections
        for item in self.child_items:
            for key, asset in assets.items():
                item.stac_object.add_asset(key, asset)
        for collection in self.child_collections:
            collection.add_extra_assets(assets)
        # also add the assets to this collection
        for key, asset in assets.items():
            self.stac_object.add_asset(key, asset)

    def generate_stac_files(self, import_assets: bool = False, callback=None):
        # this function will generate all the files for this collection, and all its children. At this point, all the stac objects should be finalized
        # first write the stac files for the child items
        for item in self.child_items:
            item.write_stac_file(import_assets=import_assets, callback=callback)
        # then call the function of the child collections recursively
        for collection in self.child_collections:
            collection.generate_stac_files(import_assets=import_assets, callback=callback)
        # finally, write the stac file for this collection
        self.write_stac_file(import_assets=import_assets, callback=callback)

    def count_all_child_items(self) -> int:
        # count the number of child items in this collection, and in all its child collections recursively
        count = len(self.child_items)
        for collection in self.child_collections:
            count += collection.count_all_child_items()
        return count
    
    def count_all_child_collections(self) -> int:
        # count the number of child collections in this collection, and in all its child collections recursively
        count = len(self.child_collections)
        for collection in self.child_collections:
            count += collection.count_all_child_collections()
        return count

    def update_description(self, parents: list=[]):
        # first call is for the parent collection, who may not have a parent collection yet (it will only have one after ingestion)
        # in this case, we can use "Repository" with link="../collection.json"
        # then, for child collections and items, we can pass self.title and self.file_name

        # do nothing if there is no stac object
        if self.stac_object is None: return
        # update the description with the text provided by the parent (if any)
        self.prepend_description(parents)
        # update the text to include the title of the current collection, to be used for the children
        new_parents = parents + [(self.title, self.file_name)]
        # update the descriptions from the assets, while we're at it
        for asset in self.stac_object.assets.values():
            asset.description = self.update_variables(asset.description)
        # recursively update the description of the child collections and items
        for item in self.child_items:
            item.prepend_description(new_parents)
            # also update the descriptions from the assets
            for asset in item.stac_object.assets.values():
                asset.description = item.update_variables(asset.description)
        for collection in self.child_collections:
            collection.update_description(new_parents)
