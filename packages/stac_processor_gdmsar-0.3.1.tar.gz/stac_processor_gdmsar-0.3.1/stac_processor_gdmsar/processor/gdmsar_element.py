import abc
import logging
import os
import pystac
import time

from stac_processor_gdmsar.explorer import make_explorer
import stac_processor_gdmsar.metadata.common_metadata as metadata

logger = logging.getLogger(__name__)

class GDMElement(metaclass=abc.ABCMeta):
    main_id: str = None # the id of the root element, which is used in all the child elements
    stac_id: str = None # the id that will be given to the stac object
    title: str = None
    file_name: str = None # the name of the file, with the json extension
    folder_name: str = None # the name of the folder where the stac file will be saved, without the path
    keywords: list[str] = None # will be loaded from the templates files
    stac_object: pystac.Item | pystac.Collection | pystac.Catalog = None # will be created in the to_stac function, and will contain the final stac object to be saved as a json file
    href: str = None

    def add_common_links(self):
        if self.stac_object is not None:
            for publication in metadata.publications:
                self.stac_object.add_link(pystac.Link(rel="cite-as", target=publication["href"]))
            self.stac_object.add_link(pystac.Link(rel="license", target=metadata.license_href))

    def link_to(self, relation: str, target: "GDMElement", target_relation: str = None, media_type="application/json"):
        if self.stac_object is not None and target.stac_object is not None:
            link = pystac.Link(
                rel=relation, 
                target=target.stac_object.get_self_href() if target_relation is None else target_relation, 
                title=target.title, 
                media_type=media_type
            )
            self.stac_object.add_link(link)

    def write_stac_file(self, import_assets: bool = False, callback=None):
        # do not write the stac file if the stac object has not been created or if it has no children
        if self.stac_object is None: return
        # do not write the stac file if the stac object has no children
        if isinstance(self.stac_object, pystac.Collection) and self.count_all_child_collections() + self.count_all_child_items() == 0: return
        # import the assets if needed, and update the href of the assets to point to the new location
        if import_assets:
            for asset_key in self.stac_object.assets:
                asset = self.stac_object.assets[asset_key]
                if asset.media_type != "text/html":
                    asset_name = os.path.basename(asset.href)
                    directory = os.path.dirname(self.stac_object.get_self_href())
                    os.makedirs(f"{directory}/assets", exist_ok=True)
                    explorer = make_explorer(asset.href)
                    explorer.copy(asset.href, f"{directory}/assets/{asset_name}")
                    asset.href = f"assets/{asset_name}"
        # save the stac file
        if isinstance(self.stac_object, pystac.Item):
            self.stac_object.save_object(include_self_link=False) # for items, we need to remove the self link because it is not correct after saving the file, and it creates a problem when writing the file
        else:
            self.stac_object.keywords = self.keywords
            self.stac_object.save(catalog_type=pystac.CatalogType.SELF_CONTAINED,)
        if callback is not None: 
            callback() # the total number of the progress bar is based on the potential number of items
            time.sleep(0.01) # add a small sleep to make sure that the progress bar is updated

    def update_variables(self, content: str|list):
        """
        Update the variables in the content, based on the properties of the stac object.
        The variables are represented as **{variable}** in the content, and they are replaced by the value of the corresponding property in the stac object.
        This function is meant to be overridden in the child classes, to add specific variables based on the type of element.
        """
        pass

    def prepend_description(self, parents: list):
        if self.stac_object is not None:
            # navigation starts with the repository, which is located at "../collection.json"
            text = f"[Repository](../collection.json)"
            # add breadcrumb navigation to the description, based on the parents of the element, and the title of the element
            for parent in parents:
                title, link = parent
                text += f" > [{title}]({link})"
            text += f" > {self.title}"
            # add the navigation at the beginning of the description
            if isinstance(self.stac_object, pystac.Item):
                if "description" not in self.stac_object.properties or self.stac_object.properties["description"] is None:
                    self.stac_object.properties["description"] = text
                else:
                    self.stac_object.properties["description"] = text + "\n\n" + self.update_variables(self.stac_object.properties.get("description", ""))
            else:
                if self.stac_object.description is None:
                    self.stac_object.description = text
                else:
                    self.stac_object.description = text + "\n\n" + self.update_variables(self.stac_object.description)
