from stac_processor_gdmsar.processor.gdmsar_item import GDMItem

class GDMGeoDEM(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id,  "geo_aux_dem_item", files, "WGS84", ["dem"], date, resolution, ["digital elevation model"])
class GDMRadarDEM(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id,  "radar_aux_dem_item", files, "RADAR", ["dem"], date, resolution, ["digital elevation model"])

class GDMGeoTCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id,  "geo_aux_tcoh_item", files, "WGS84", ["tcoh"], date, resolution, ["temporal coherence"])
class GDMRadarTCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id,  "radar_aux_tcoh_item", files, "RADAR", ["tcoh"], date, resolution, ["temporal coherence"])

class GDMGeoCosEnu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "geo_aux_cosenu_item", files, "WGS84", ["cosenu"], date, resolution, ["Map of LOS vector", "ENU", "EPOS convention"])
class GDMRadarCosEnu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "radar_aux_cosenu_item", files, "RADAR", ["cosenu"], date, resolution, ["Map of LOS vector", "ENU", "EPOS convention"])

class GDMGeoCosNeu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "geo_aux_cosneu_item", files, "WGS84", ["cosneu"], date, resolution, ["Map of LOS vector", "NEU", "FlatSIM convention"])
class GDMRadarCosNeu(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "radar_aux_cosneu_item", files, "RADAR", ["cosneu"], date, resolution, ["Map of LOS vector", "NEU", "FlatSIM convention"])

class GDMGeoCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"geo_interferogram_{date}_coh_item", files, "WGS84", ["coh"], date, resolution, ["spatial coherence"])
class GDMRadarCoh(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"radar_interferogram_{date}_coh_item", files, "RADAR", ["coh"], date, resolution, ["spatial coherence"])

class GDMGeoInW(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"geo_interferogram_{date}_inw_item", files, "WGS84", ["inw"], date, resolution, ["wrapped interferogram"])
class GDMRadarInW(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"radar_interferogram_{date}_inw_item", files, "RADAR", ["inw"], date, resolution, ["wrapped interferogram"])

class GDMGeoInWF(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"geo_interferogram_{date}_inwf_item", files, "WGS84", ["inwf"], date, resolution, ["filtered interferogram"])
class GDMRadarInWF(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"radar_interferogram_{date}_inwf_item", files, "RADAR", ["inwf"], date, resolution, ["filtered interferogram"])

class GDMGeoInU(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"geo_interferogram_{date}_inu_item", files, "WGS84", ["inu"], date, resolution, ["unwrapped interferogram"])
class GDMRadarInU(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, f"radar_interferogram_{date}_inu_item", files, "RADAR", ["inu"], date, resolution, ["unwrapped interferogram"])

class GDMGeoDts(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "geo_aux_dts_item", files, "WGS84", ["dts_los", "geo_tot"], date, resolution, ["LOS displacement"])
class GDMRadarDts(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "radar_aux_dts_item", files, "RADAR", ["dts_los"], date, resolution, ["LOS displacement"])

class GDMGeoNet(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "geo_aux_net_item", files, "WGS84", ["net"], date, resolution, ["network misclosure"])
class GDMRadarNet(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "radar_aux_net_item", files, "RADAR", ["net"], date, resolution, ["network misclosure"])

class GDMGeoMvlos(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "geo_aux_mvlos_item", files, "WGS84", ["mv-los"], date, resolution, ["mean velocity map"])
class GDMRadarMvlos(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "radar_aux_mvlos_item", files, "RADAR", ["mv-los"], date, resolution, ["mean velocity map"])

class GDMGeoLut(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "geo_aux_lut_item", files, "WGS84", ["lut"], date, resolution, ["lookup table"])
class GDMRadarLut(GDMItem):
    def __init__(self, main_id: str, uuid: str, files: list[str], date: str = "", resolution: str = ""): 
        super().__init__(uuid, main_id, "radar_aux_lut_item", files, "RADAR", ["lut"], date, resolution, ["lookup table"])