import logging
import stac_processor_gdmsar.processor.gdmsar_items_list as items
from stac_processor_gdmsar.processor.utils import extract_date_intervals, get_sublist_by_tags
from stac_processor_gdmsar.processor.gdmsar_collection import GDMCollection
    
logger = logging.getLogger(__name__)

class GDMGeoAux(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Auxiliary data",
            file_basename="geo_aux_collection",
            files=files,
            geometry="WGS84", # no assets for this collection
            child_items=[
                items.GDMGeoDEM(main_id, uuid, files),
                items.GDMGeoTCoh(main_id, uuid, files),
                items.GDMGeoCosEnu(main_id, uuid, files),
                items.GDMGeoCosNeu(main_id, uuid, files),
            ], 
            template_list=["auxiliary_data_collection.md"]
        )

class GDMGeoDateInterval(GDMCollection):
    def __init__(self, main_id: str, uuid: str, date_from: str, date_to: str, files: list[str]) -> None:
        date_interval = f"{date_from}_{date_to}"
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Interferogram from {date_from} to {date_to}",
            file_basename=f"geo_interferogram_{date_interval}_collection",
            files=files,
            geometry="WGS84", # no assets for this collection
            date=date_interval,
            child_items=[
                items.GDMGeoCoh(main_id, uuid, files, date=date_interval),
                items.GDMGeoInW(main_id, uuid, files, date=date_interval),
                items.GDMGeoInWF(main_id, uuid, files, date=date_interval),
                items.GDMGeoInU(main_id, uuid, files, date=date_interval)
            ], 
            template_list=["interferogram.md"]
        )

class GDMGeoInterferograms(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        # extract the date intervals from the file names
        interferogram_files = get_sublist_by_tags(files, ["_Coh_geo_", "_InW_geo_", "_InWF_geo_", "_INU_geo_"])
        date_intervals = extract_date_intervals(interferogram_files)
        date_interval_collections = []
        for date_interval in date_intervals:
            date_from, date_to = date_interval.split("_")
            date_interval_collections.append(GDMGeoDateInterval(main_id, uuid, date_from, date_to, files))
        # call the super constructor
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Interferograms",
            file_basename="geo_interferogram_collection",
            files=files,
            geometry="WGS84", # no assets for this collection
            child_collections=date_interval_collections, 
            template_list=["interferogram_collection.md"] 
        )

class GDMGeoTimeSerie(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Time Series",
            file_basename="geo_timeseries_collection",
            files=files,
            geometry="WGS84", # no assets for this collection
            child_items=[
                items.GDMGeoDts(main_id, uuid, files),
                items.GDMGeoNet(main_id, uuid, files),
                items.GDMGeoMvlos(main_id, uuid, files)
            ], 
            template_list=["time_series.md"]
        )

class GDMGeo(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Ground geometry",
            file_basename="geo_collection",
            files=files,
            geometry="WGS84", # no assets for this collection
            child_collections=[
                GDMGeoAux(main_id, uuid, files),
                GDMGeoInterferograms(main_id, uuid, files),
                GDMGeoTimeSerie(main_id, uuid, files)
            ],
            template_list=["run_geocoded_wgs84_collection.md"]
        )
