import logging
import stac_processor_gdmsar.processor.gdmsar_items_list as items
from stac_processor_gdmsar.processor.utils import extract_date_intervals, get_sublist_by_tags
from stac_processor_gdmsar.processor.gdmsar_collection import GDMCollection

logger = logging.getLogger(__name__)

class GDMRadarAux(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Auxiliary data",
            file_basename="radar_aux_collection",
            files=files,
            geometry="RADAR", # no assets for this collection
            codes=["extra"],
            child_items=[
                items.GDMRadarDEM(main_id, uuid, files),
                items.GDMRadarTCoh(main_id, uuid, files),
                items.GDMRadarCosEnu(main_id, uuid, files),
                items.GDMRadarCosNeu(main_id, uuid, files),
                # lookup tables for both geo and radar geometries are stored here on purpose
                items.GDMGeoLut(main_id, uuid, files),
                items.GDMRadarLut(main_id, uuid, files)
            ], 
            template_list=["auxiliary_data_collection.md"]
        )

class GDMRadarDateInterval(GDMCollection):
    def __init__(self, main_id: str, uuid: str, date_from: str, date_to: str, files: list[str]) -> None:
        date_interval = f"{date_from}_{date_to}"
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Interferogram from {date_from} to {date_to}",
            file_basename=f"radar_interferogram_{date_interval}_collection",
            files=files,
            geometry="RADAR", # no assets for this collection
            date=date_interval,
            child_items=[
                items.GDMRadarCoh(main_id, uuid, files, date=date_interval),
                items.GDMRadarInW(main_id, uuid, files, date=date_interval),
                items.GDMRadarInWF(main_id, uuid, files, date=date_interval),
                items.GDMRadarInU(main_id, uuid, files, date=date_interval)
            ], 
            template_list=["interferogram.md"]
        )

class GDMRadarInterferograms(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        # extract the date intervals from the file names
        interferogram_files = get_sublist_by_tags(files, ["_Coh_radar_", "_InW_radar_", "_InWF_radar_", "_INU_radar_"])
        date_intervals = extract_date_intervals(interferogram_files)
        date_interval_collections = []
        for date_interval in date_intervals:
            date_from, date_to = date_interval.split("_")
            date_interval_collections.append(GDMRadarDateInterval(main_id, uuid, date_from, date_to, files))
        # call the super constructor
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Interferograms",
            file_basename="radar_interferogram_collection",
            files=files,
            geometry="RADAR", # no assets for this collection
            child_collections=date_interval_collections, 
            template_list=["interferogram_collection.md"]
        )

class GDMRadarTimeSerie(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Time series",
            file_basename="radar_timeseries_collection",
            files=files,
            geometry="RADAR", # no assets for this collection
            codes=["inversion"],
            child_items=[
                items.GDMRadarDts(main_id, uuid, files),
                items.GDMRadarNet(main_id, uuid, files),
                items.GDMRadarMvlos(main_id, uuid, files)
            ], 
            template_list=["time_series.md"]
        )

class GDMRadar(GDMCollection):
    def __init__(self, main_id: str, uuid: str, files: list[str]) -> None:
        super().__init__(
            uuid=uuid,
            main_id=main_id,
            title=f"Radar geometry",
            file_basename="radar_collection",
            files=files,
            geometry="RADAR", # no assets for this collection
            child_collections=[
                GDMRadarAux(main_id, uuid, files),
                GDMRadarInterferograms(main_id, uuid, files),
                GDMRadarTimeSerie(main_id, uuid, files)
            ], 
            template_list=["run_geocoded_radar_collection.md"]
        )
