import logging.config
from stac_processor_gdmsar.__about__ import (
    __version__,
    __catalog_name__,
    __catalog_desc__,
)
from stac_processor_gdmsar.discover import discover
from stac_processor_gdmsar.id import id
from stac_processor_gdmsar.version import version
from stac_processor_gdmsar.process import process

# define the logger here, so that it can be used in the other modules without having to redefine it
logging_config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": { "format": "%(asctime)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s", "datefmt": "%Y-%m-%d %H:%M:%S", },
    },
    "handlers": {
        "console": { "class": "logging.StreamHandler", "formatter": "standard", "level": logging.INFO, },
    },
    "loggers": {
        "": { "handlers": ["console"], "level": logging.INFO, "propagate": True, },
        # reduce logging level to warning for some very verbose loggers
        "smart_open": { "handlers": ["console"], "level": logging.WARNING, "propagate": False, },
        "urllib3": { "handlers": ["console"], "level": logging.WARNING, "propagate": False, },
        "requests": { "handlers": ["console"], "level": logging.WARNING, "propagate": False, },
    },
}
logging.config.dictConfig(logging_config)
