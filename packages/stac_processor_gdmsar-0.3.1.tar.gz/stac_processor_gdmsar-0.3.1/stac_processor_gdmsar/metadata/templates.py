import logging
import os
import re
from pystac import Asset, MediaType
from stac_processor_gdmsar.processor.utils import is_valid_json, load_json
from stac_processor_gdmsar.explorer import is_local
from stac_processor_gdmsar.metadata.products import products, Product, get_product

logger = logging.getLogger(__name__)

def read_template(template_name: str) -> str:
    # some products may not have a template, in this case we return an empty description
    if template_name == "": return ""
    if os.path.exists(template_name):
        # this allows to use this function with a specific template file, useful for testing
        file = template_name
    else:
        # create an absolute path to the template file, even if the current working directory is different, and read the content of the file
        file = os.path.join(os.path.dirname(__file__), "..", "templates", template_name)
        if not file.endswith(".md"): file += ".md"
    # open the template file, read the content, and replace the variables by the corresponding values
    if os.path.exists(file):
        with open(file) as f:
            return f.read()
    logger.warning(f"Template file {file} not found, returning an empty description.")
    return ""

def get_title(code: str, geometry: str) -> str:
    for product in products:
        if product.code.lower() == code.lower() and product.geometry.lower() == geometry.lower():
            return product.title
    logger.warning(f"No product found for code {code} and geometry {geometry}, returning 'Unknown' as title.")
    return "Unknown"

def get_description(code: str, geometry: str) -> str:
    for product in products:
        if product.code.lower() == code.lower() and product.geometry.lower() == geometry.lower():
            description = read_template(product.template)
            if description == "":
                logger.warning(f"Product {product.title} has an empty description, check the template file {product.template}.")
            return description
    logger.warning(f"No product found for code {code} and geometry {geometry}, returning an empty description.")
    return " " # empty description should be avoided in stac, return a space in the worst case to avoid validation errors

def is_in_list(string: str, list: list[str]) -> bool:
    for element in list:
        if element.lower() == string.lower():
            return True
    return False

def get_matching_product(file: str, codes: list[str], geometry: str, _date: str = "", _resolution: str = "") -> Product | None:
    # get the product corresponding to the file
    product = get_product(file)
    if not product: return None
    # test for each field if it is not empty
    if not is_in_list(product.code, codes): return None
    if product.geometry.lower() != geometry.lower(): return None
    # date and resolution are optional, if they are not empty, they should be in the file name
    if _date != "" and _date.lower() not in file.lower(): return None
    if _resolution != "" and _resolution.lower() not in file.lower(): return None
    return product

def get_keywords_from_template(template_name: str) -> list:
    description = read_template(template_name)
    keywords = re.findall(r"\*\*(.*?)\*\*", description)
    return keywords

def get_keywords_from_json_file(file: str) -> list:
    keywords = []
    json = load_json(file)
    if is_valid_json(file, json):
        # recent json files have a field called "Tag" in the properties, that contains a list of keywords separated by commas
        tag = json.get("properties", {}).get("Tag", "")
        if tag:
            keywords.extend([keyword.strip() for keyword in tag.split(",")])
    return keywords

def get_keywords(files: list[str], codes: list[str], geometry: str, default_keywords: list[str] = None) -> list:
    found_keywords = set()
    # add default keywords if any
    if default_keywords:
        found_keywords.update(default_keywords)
    # keywords based on elements in the file name
    for file in files:
        if get_matching_product(file, codes, geometry):
            # resolution
            match = re.search(r'_(\d+)rlks', file)
            if match: found_keywords.add(f"resolution_{match.group(1)}looks")
            # keywords from json file
            if file.endswith(".json"):
                keywords = get_keywords_from_json_file(file)
                found_keywords.update(keywords)
    # keywords based on templates
    for product in products:
        if is_in_list(product.code, codes) and product.geometry.lower() == geometry.lower():
            keywords = get_keywords_from_template(product.template)
            found_keywords.update(keywords)
    return list(found_keywords)

def get_mime_type(file: str) -> str:
    # if the file does not have an extension, return application/octet-stream
    if "." not in file: return "application/octet-stream"
    # get the extension of the file
    extension = file.split(".")[-1].lower()
    # return the corresponding media type based on the extension
    if extension == "flatgeobuf" or extension == "fgb": return MediaType.FLATGEOBUF
    elif extension == "geojson": return MediaType.GEOJSON
    elif extension == "gpkg": return MediaType.GEOPACKAGE
    elif extension == "tif" or extension == "tiff": return MediaType.GEOTIFF
    elif extension == "hdf": return MediaType.HDF
    elif extension == "hdf5": return MediaType.HDF5
    elif extension == "html": return MediaType.HTML
    elif extension == "jpg" or extension == "jpeg": return MediaType.JPEG
    elif extension == "jp2": return MediaType.JPEG2000
    elif extension == "json": return MediaType.JSON
    elif extension == "png": return MediaType.PNG
    elif extension == "txt" or file.endswith("nsbas.proc") or file.endswith("baseline.rsc"): return MediaType.TEXT
    elif extension == "kml": return MediaType.KML
    elif extension == "xml": return MediaType.XML
    elif extension == "pdf": return MediaType.PDF
    elif extension == "netcdf" or extension == "nc": return MediaType.NETCDF
    elif extension == "laszip" or extension == "copc": return MediaType.COPC
    elif extension == "pmtiles": return MediaType.VND_PMTILES
    elif extension == "parquet": return MediaType.VND_APACHE_PARQUET
    elif extension == "zarr": return MediaType.VND_ZARR
    # if the extension is not recognized, return application/octet-stream
    else: return "application/octet-stream"

def get_roles(file_name: str) -> list[str]:
    roles = set()
    if file_name.endswith(".json") or file_name.endswith(".meta") or file_name.endswith(".tiff.aux.xml") or file_name.endswith(".tiff.xml"): roles.add("metadata")
    if file_name.endswith(".tiff") or file_name.endswith(".csv"): roles.add("data")
    if "legend" in file_name: roles.add("legend")
    if file_name.endswith(".png") or file_name.endswith(".jpg") or file_name.endswith(".jpeg"): roles.add("thumbnail")
    return list(roles)

def get_assets(files: list, codes: list[str], geometry: str, _date: str = "", _resolution: str = "") -> dict:
    assets = {}
    for file in files:
        # exclude some files that are not relevant
        if file.endswith(".meta") or file.endswith(".aux.xml"): continue
        # get the product corresponding to the file
        product = get_matching_product(file, codes, geometry, _date, _resolution)
        if product:
            if file.endswith(".json") and not is_local(file):
                # if file is json and online, add the original as an asset with role "metadata"
                assets[file] = Asset(file, title="Source product", description="Link to the original source product, before STAC conversion.", media_type="text/html",  roles=get_roles(file))
            elif not file.endswith(".json"):
                # for non-json files, use the product template to create a description for the asset, and use the product title as the asset title
                assets[os.path.basename(file)] = Asset(href=file, title=os.path.basename(file), media_type=get_mime_type(file),
                    description=read_template(product.template),
                    roles=get_roles(file))
    return assets

def get_json_files(files: list, codes: list[str], geometry: str) -> dict:
    json_files = {}
    for file in files:
        if file.endswith(".json") and get_matching_product(file, codes, geometry) is not None:
            # check that the json file is valid and matches a product
            json = load_json(file)
            if is_valid_json(file, json):
                json_files[file] = json
    return json_files
