import http.server
import threading
import os
import time
import orjson
import pytest
import zipfile
from deepdiff import DeepDiff

from stac_processor_gdmsar.discover import discover as api_discover
from stac_processor_gdmsar.explorer import LocalExplorer, SourceExplorer
from stac_processor_gdmsar.id import id as api_id
from stac_processor_gdmsar.process import process as api_process
from stac_processor_gdmsar.processor import utils
from stac_processor_gdmsar.processor.gdmsar_collection import GDMCollection
from stac_processor_gdmsar.metadata import products
from stac_processor_gdmsar.metadata import templates
from stac_processor_gdmsar.version import version as api_version

# Note: run "uv run pytest tests/test.py" to execute the tests in this file
# use -s to see the print statements in the output
# use -x option to stop after the first failure
# use -vv for more verbose output

# set the main options
cwd = os.path.dirname(__file__)
host = "0.0.0.0"
port = 8000
expected_targets = [
    f"http://{host}:{port}/05ef8d62-da41-11ee-9f22-0242c0a87004/iw2_iw3/",
    f"http://{host}:{port}/1c1b0a64-8a52-11ef-960d-0242c0a87003/iw2_iw3/"
]

def join_to_cwd(*args):
    return os.path.join(cwd, *args)

def prepare_test_data():
    # make sure that the test data is available in the expected directory
    base_dir = join_to_cwd("test_data")
    if not os.path.exists(base_dir):
        print(f"Decompressing test data into {base_dir}...")
        with zipfile.ZipFile(join_to_cwd("test_data.zip"), "r") as zip_ref:
            zip_ref.extractall(cwd)
    return base_dir

@pytest.fixture
def http_server():
    # a fixture is called before each test that have the name of the fixture as an argument
    # note that the server requires that the port is not already in use, also it may fail if you are behind a proxy
    print(f"Starting test HTTP server for '{server_base_dir}': http://{host}:{port}/")
    # make sure to change the current directory to the server base directory, so the server can serve the files from that directory
    # Warning: if the directory changes during the tests, it will affect the response from the server
    os.chdir(server_base_dir)
    server = http.server.HTTPServer((host, port), http.server.SimpleHTTPRequestHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.1) # wait for server to start
    try:
        yield server
    finally:
        server.shutdown()
        server.server_close()

def compare_json(result_file, expected_file):
    print(f"Comparing {result_file} to {expected_file}")
    # both files should exist
    assert os.path.exists(result_file), f"Result file {result_file} does not exist"
    assert os.path.exists(expected_file), f"Expected file {expected_file} does not exist"
    with open(result_file, "r") as f: result = orjson.loads(f.read())
    with open(expected_file, "r") as f: expected = orjson.loads(f.read())
    # do not compare the href fields, because they may contain different paths that are not relevant for the test
    # if the files are actually different, they will differ in other fields as well
    diff = DeepDiff(result, expected, ignore_order=True, exclude_regex_paths="['href']")
    return diff

# decompress the test data if not already done
base_dir = prepare_test_data()
# set the current directory, so the test server can give access to the input test data
server_base_dir = os.path.join(base_dir, "input")
# get the URL of the test server
base_url = f"http://{host}:{port}"

# note that the following tests will not be executed in that order

def test_id(http_server):
    source = expected_targets[0]
    expected_id = "Earthquake Iran 2017"
    print(f"Testing id for source '{source}'")
    result_id = api_id(source)
    # print(f"Result id : {result_id}")
    assert result_id == expected_id, f"Expected id {expected_id} does not match result id {result_id}"

def test_version(http_server):
    source = expected_targets[0]
    expected_version = "2024-03-21T09:15:21Z"
    print(f"Testing version for source '{source}'")
    result_version = api_version(source)
    # print(f"Result version : {result_version}")
    assert result_version == expected_version, f"Expected version {expected_version} does not match result version {result_version}"

# test the discover function with the test server as source
def test_discover(http_server):
    source = base_url
    print(f"Testing discover for source '{source}'")
    # get the product sources discovered by the API
    products = []
    for product_source in api_discover(source):
        products.append(product_source)
    # check that the discovered product sources are the expected ones
    assert len(products) == len(expected_targets)
    for i in range(len(expected_targets)):
        assert products[i] == expected_targets[i]

def process(source):
    # source = join_to_cwd("test_data/input/05ef8d62-da41-11ee-9f22-0242c0a87004/iw2_iw3/")
    expected_result_directory = join_to_cwd("test_data/output")
    print(f"Testing process for source '{source}'")
    # process the source
    href = api_process(source)
    result_dir = os.path.dirname(href)
    parent_result_dir = os.path.dirname(result_dir)
    print(f"Result directory : {parent_result_dir}")
    # the output is in a temporary directory, that is automatically cleaned up after the test
    print(f"Expected result directory : {expected_result_directory}")
    # check that all the files in result_dir have a corresponding file in expected_result_directory
    for root, _, files in os.walk(parent_result_dir):
        for file in files:
            expected_file = os.path.join(root, file).replace(parent_result_dir, expected_result_directory)
            assert os.path.exists(expected_file), f"Expected file {expected_file} does not exist"
    # check that all the files in expected_result_directory have a corresponding file in result_dir
    for root, _, files in os.walk(expected_result_directory):
        for file in files:
            result_file = os.path.join(root, file).replace(expected_result_directory, parent_result_dir)
            assert os.path.exists(result_file), f"Result file {result_file} does not exist"
    # check the content of a collection, it must match the expected content
    result_collection = os.path.join(parent_result_dir, "05ef8d62-da41-11ee-9f22-0242c0a87004", "collection.json")
    expected_collection = os.path.join(expected_result_directory, "05ef8d62-da41-11ee-9f22-0242c0a87004", "collection.json")
    diff_collection = compare_json(result_collection, expected_collection)
    assert diff_collection == {}, f"Collection content does not match expected content : {diff_collection}"
    # check the content of an item, it must match the expected content
    item_relative_path = "05ef8d62-da41-11ee-9f22-0242c0a87004/wgs84_collection/interferogram_collection/interferogram_date_interval_20171107_20171119_collection/spatial_coherence_item/spatial_coherence_item.json"
    result_item = os.path.join(parent_result_dir, item_relative_path)
    expected_item = os.path.join(expected_result_directory, item_relative_path)
    diff_item = compare_json(result_item, expected_item)
    assert diff_item == {}, f"Item content does not match expected content : {diff_item}"

def test_process_local():
    source = join_to_cwd("test_data/input/05ef8d62-da41-11ee-9f22-0242c0a87004/iw2_iw3/")
    process(source)

def test_process_remote(http_server):
    source = expected_targets[0]
    process(source)

def test_utils():
    assert utils.is_matching("GDM_Coh_radar_20171107_20171119_4rlks.png", ["_Coh_radar_", "_InW_radar_"], True) == True
    assert utils.is_matching("GDM_Coh_geo_20171107_20171119_4rlks.png", ["_Coh_radar_", "_InW_radar_"], True) == False
    assert utils.is_matching("GDM_Coh_radar_20171107_20171119_4rlks.png", ["_InW_radar_"], True) == False
    assert utils.is_matching("GDM_Coh_radar_20171107_20171119_4rlks.png", ["_coh_radar_"], True) == False
    assert utils.is_matching("GDM_Coh_radar_20171107_20171119_4rlks.png", ["_coh_radar_"], False) == True
    assert utils.get_sublist_by_tags(["GDM_Coh_radar_20171107_20171119_4rlks.png", "GDM_Coh_geo_20171107_20171119_4rlks.png"], ["_Coh_radar_"], True) == ["GDM_Coh_radar_20171107_20171119_4rlks.png"]
    assert utils.extract_date_interval("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff") == "20161026_20161101"
    assert utils.extract_date_interval("GDM_InWF_geo_sd_era_4rlks.tiff") == None
    assert utils.extract_date_intervals(["GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", "GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", "GDM_InWF_geo_20161030_20161105_sd_era_4rlks.tiff"]) == ["20161026_20161101", "20161030_20161105"]
    assert utils.load_json(join_to_cwd("test_data/input/small.json")) == {"id": "Earthquake Iran 2017", "version": "2024-03-21T09:15:21Z"}
    assert utils.load_json("") == {}
    assert utils.load_json(None) == {}
    assert utils.load_json(join_to_cwd("test_data/non_existent.json")) == {}

def test_local_explorer():
    os.chdir(base_dir) # cwd was changed during processing, change it back to the base directory for the next tests
    explorer = LocalExplorer()
    assert explorer.validate(join_to_cwd("test_data/input/small.json")) == None
    with pytest.raises(FileNotFoundError): explorer.validate(join_to_cwd("test_data/non_existent.json"))
    assert explorer.list_dir(join_to_cwd("test_data/")) == ["input", "output"]
    test_file = join_to_cwd("test_data/input/small.json")
    assert explorer.load_json(test_file) == {"id": "Earthquake Iran 2017", "version": "2024-03-21T09:15:21Z"}
    with pytest.raises(FileNotFoundError): explorer.load_json("")
    with pytest.raises(FileNotFoundError): explorer.load_json(join_to_cwd("test_data/non_existent.json"))
    assert explorer.load(join_to_cwd("test_data/input/small.json")) == '{\n    "id": "Earthquake Iran 2017", \n    "version": "2024-03-21T09:15:21Z"\n}'
    assert explorer.join(join_to_cwd("test_data/input"), "small.json") == join_to_cwd("test_data/input/small.json")
    assert explorer.basename(test_file) == "small.json"
    assert explorer.dirname(test_file) == join_to_cwd("test_data/input")
    assert explorer.resolve("input/small.json") == join_to_cwd("test_data/input/small.json")
    assert explorer.is_directory(test_file) == False
    assert explorer.is_directory(join_to_cwd("test_data/")) == True

def test_source_explorer(http_server):
    explorer = SourceExplorer()
    base_url = f"http://{host}:{port}"
    test_file = f"{base_url}/small.json"
    non_existent_file = f"{base_url}/non_existent.json"
    assert explorer.validate(test_file) == None
    with pytest.raises(Exception): explorer.validate(non_existent_file)
    assert explorer.list_dir(base_url) == ["05ef8d62-da41-11ee-9f22-0242c0a87004/", "1c1b0a64-8a52-11ef-960d-0242c0a87003/", "interferogram.md", "small.json"]
    assert explorer.load_json(test_file) == {"id": "Earthquake Iran 2017", "version": "2024-03-21T09:15:21Z"}
    with pytest.raises(Exception): explorer.load_json("")
    with pytest.raises(Exception): explorer.load_json(non_existent_file)
    assert explorer.load(test_file) == '{\n    "id": "Earthquake Iran 2017", \n    "version": "2024-03-21T09:15:21Z"\n}'
    assert explorer.join(base_url, "small.json") == f"{base_url}/small.json"
    assert explorer.basename(test_file) == "small.json"
    assert explorer.dirname(test_file) == f"{base_url}"
    assert explorer.resolve("input/small.json") == "input/small.json"
    assert explorer.is_directory(test_file) == False
    assert explorer.is_directory(expected_targets[0]) == True

def test_metadata():
    template = join_to_cwd("test_data/input/interferogram.md")
    collection = GDMCollection("test_id", "", [], "", geometry="test_geometry", date="20260401_20260402", is_parent_collection=True)
    # collection.processing_id = "test_processing_id"
    content = collection.update_variables(templates.read_template(template))
    assert "{{" not in content
    assert "An item containing the products related to the **interferogram test_id between 20260401 and 20260402** in **test_geometry geometry**." in content
    assert products.get_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff") is not None
    assert products.get_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff").code == "InWF"
    assert products.get_product("non_existent_file.tiff") is None
    assert templates.get_title("InWF", "RADAR") == "Filtered Wrapped Differential Interferogram"
    assert templates.get_title("InWF", "WGS84") == "Filtered Wrapped Differential Interferogram"
    content = collection.update_variables(templates.get_description("CosENU", "RADAR"))
    assert content == "# The ENU Map of LOS Vector from run test_processing_id (test_geometry)\n"
    assert templates.get_description("test", "geo").strip() == ""
    assert templates.is_in_list("INWF", ["inwf", "CoH"]) == True
    assert templates.is_in_list("INWF", ["coh", "aps"]) == False
    assert templates.is_in_list("InW", ["inwf", "coh"]) == False
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["InWF"], "WGS84") is not None
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["InWF"], "WGS84").code == "InWF"
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["Coh"], "WGS84") is None
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["InWF"], "WGS84", _resolution = "4rlks") is not None
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["InWF"], "WGS84", _resolution = "2rlks") is None
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["InWF"], "WGS84", _date = "_20161026_20161101") is not None
    assert templates.get_matching_product("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", ["InWF"], "WGS84", _date = "_20161026_20161102") is None
    keywords = templates.get_keywords_from_template(template)
    collection.update_keywords(keywords)
    keywords = collection.keywords
    assert len(keywords) == 6
    assert "Wrapped Interferogram" in keywords
    assert "interferogram test_id between 20260401 and 20260402" in keywords
    assert "test_geometry geometry" in keywords
    keywords = templates.get_keywords(["GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff", "GDM_CosENU_geo_4rlks.tiff"], ["InWF"], "WGS84", ["test1", "test2"])
    assert len(keywords) == 4
    assert "test1" in keywords
    assert "test2" in keywords
    assert "resolution_4looks" in keywords
    assert "filtered wrapped interferogram" in keywords
    assert templates.get_mime_type("GDM_InWF_geo_20161026_20161101_sd_era_4rlks.tiff") == "image/tiff; application=geotiff"
    assert templates.get_mime_type("non-existent_file.xyz") == "application/octet-stream"
    assert templates.get_mime_type("") == "application/octet-stream"
    assert len(templates.get_assets(["GDM_CosENU_geo_4rlks.png", "GDM_DEM_radar_4rlks.json", "GDM_Lut_geo_4rlks.meta"], ["CosENU", "DEM"], "WGS84")) == 1
    files = [
        join_to_cwd("test_data/input/05ef8d62-da41-11ee-9f22-0242c0a87004/iw2_iw3/GDM_InW_geo_20171107_20171119_sd_4rlks.tiff"), 
        join_to_cwd("test_data/input/05ef8d62-da41-11ee-9f22-0242c0a87004/iw2_iw3/GDM_InW_geo_20171107_20171119_sd_4rlks.json"), 
        join_to_cwd("test_data/input/05ef8d62-da41-11ee-9f22-0242c0a87004/iw2_iw3/GDM_DEM_radar_4rlks.json"),
        join_to_cwd("test_data/input/small.json")
    ]
    json_files = templates.get_json_files(files, ["InW"], "WGS84")
    for file in json_files.keys():
        print(f"Found json file : {file}")
    assert len(json_files) == 1
    assert files[1] in json_files
    assert "id" in json_files[files[1]]