# Quisy MCP System Tools

MCP server for system-level operations, including system time retrieval.

## Installation

```bash
pip install quisy-mcp-system-tools
# or using uvx
uvx quisy-mcp-system-tools
```

## Usage as MCP Server

Add the following to your MCP client configuration (e.g., `claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "system-tools": {
      "command": "uvx",
      "args": ["quisy-mcp-system-tools"]
    }
  }
}
```
