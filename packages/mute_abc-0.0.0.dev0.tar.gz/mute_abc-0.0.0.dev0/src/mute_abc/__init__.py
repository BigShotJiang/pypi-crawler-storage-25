from mute_abc.core import *
from mute_abc.tests import *

if __name__ == "__main__":
    main()
