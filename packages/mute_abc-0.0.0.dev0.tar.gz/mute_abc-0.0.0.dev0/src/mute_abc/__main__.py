from mute_abc import main

if __name__ == "__main__":
    main()
