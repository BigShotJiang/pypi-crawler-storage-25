import requests

BASE_URL = "https://blobsvault.com/api"

class BlobsVault:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("BlobsVault: api_key is required")
        self.api_key = api_key
        self.is_team = api_key.startswith("bv_team_")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })

    def _request(self, path: str, method: str = "GET", json: dict = None) -> dict:
        url = BASE_URL + path
        res = self.session.request(method, url, json=json)
        data = res.json()
        if not res.ok:
            raise Exception(data.get("error", f"BlobsVault API error: {res.status_code}"))
        return data

    def generate_otp(self, account: str) -> dict:
        if not account:
            raise ValueError('account is required (format: "Issuer:AccountName")')
        endpoint = "/v1/team/otp/generate" if self.is_team else "/v1/otp/generate"
        return self._request(endpoint, method="POST", json={"account": account})

    def list_accounts(self) -> dict:
        return self._request("/v1/vault/api-items")

    def get_usage(self) -> dict:
        return self._request("/developer/usage")

    def list_api_keys(self) -> dict:
        return self._request("/developer/keys")

    def create_api_key(self, name: str) -> dict:
        if not name:
            raise ValueError("name is required")
        return self._request("/developer/keys", method="POST", json={"name": name})
