# blobsvault (Python SDK)

Official Python SDK for [BlobsVault](https://blobsvault.com) — 2FA infrastructure for AI agents.

## Install

```bash
pip install blobsvault
```

## Usage

```python
from blobsvault import BlobsVault

bv = BlobsVault("bv_live_your_key_here")

# Generate a 2FA code
otp = bv.generate_otp("GitHub:user@example.com")
print(otp["code"])  # 123456

# List accounts
accounts = bv.list_accounts()

# Check usage
usage = bv.get_usage()
print(usage["calls_this_month"])

# API key management
keys = bv.list_api_keys()
new_key = bv.create_api_key("my-agent")
```

## Get an API key

Sign up at [blobsvault.com](https://blobsvault.com) → Developer → API Keys.
