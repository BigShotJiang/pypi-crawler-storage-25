"""SCP optimization passes."""
