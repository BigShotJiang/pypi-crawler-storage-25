"""cmux JSON-RPC socket 通信层。

直连 Unix socket，不依赖 cmux CLI，任何进程都能用（需 automation 模式）。
"""

from __future__ import annotations

import json
import os
import socket


SOCKET_PATH = os.environ.get(
    "CMUX_SOCKET_PATH",
    os.path.expanduser("~/Library/Application Support/cmux/cmux.sock"),
)


def rpc(method: str, params: dict | None = None) -> dict:
    payload = {"id": "mation", "method": method, "params": params or {}}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(SOCKET_PATH)
        s.sendall(json.dumps(payload).encode() + b"\n")
        s.settimeout(10)
        data = s.recv(65536).decode()
    resp = json.loads(data)
    if not resp.get("ok"):
        error = resp.get("error", {})
        msg = error.get("message", str(error)) if isinstance(error, dict) else str(error)
        raise RuntimeError(f"cmux {method}: {msg}")
    return resp.get("result", {})


def get_current_surface() -> str | None:
    return os.environ.get("CMUX_SURFACE_ID")


def send_text(surface_id: str, text: str) -> None:
    rpc("surface.send_text", {"surface_id": surface_id, "text": text})
    rpc("surface.send_key", {"surface_id": surface_id, "key": "enter"})


def send_escape(surface_id: str) -> None:
    rpc("surface.send_key", {"surface_id": surface_id, "key": "escape"})


def ping() -> bool:
    try:
        rpc("system.ping")
        return True
    except Exception:
        return False
