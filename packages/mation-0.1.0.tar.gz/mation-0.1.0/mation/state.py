"""Mation 状态持久化。读写 ~/.mation/active.json"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

STATE_DIR = Path.home() / ".mation"
STATE_FILE = STATE_DIR / "active.json"
CONFIG_FILE = STATE_DIR / "config.json"

DEFAULT_WORKFLOW = ["code", "test", "simplify", "review", "fix"]
DEFAULT_STEP_PROMPTS: dict[str, str | None] = {
    "code": None,
    "test": "对你刚才的改动跑测试，修复失败的用例",
    "simplify": "/simplify",
    "review": "/review",
    "fix": "修复 review 中发现的问题",
}


def _ensure_dir() -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)


def load_state() -> dict[str, Any] | None:
    if not STATE_FILE.exists():
        return None
    return json.loads(STATE_FILE.read_text())


def save_state(state: dict[str, Any]) -> None:
    _ensure_dir()
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2))


def delete_state() -> None:
    if STATE_FILE.exists():
        STATE_FILE.unlink()


def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {"step_prompts": dict(DEFAULT_STEP_PROMPTS)}
    return json.loads(CONFIG_FILE.read_text())


def save_config(config: dict[str, Any]) -> None:
    _ensure_dir()
    CONFIG_FILE.write_text(json.dumps(config, ensure_ascii=False, indent=2))


def new_state(supervisor_surface: str, workflow: list[str]) -> dict[str, Any]:
    return {
        "supervisor_surface": supervisor_surface,
        "worker_session": None,
        "worker_cache": None,
        "daemon_pid": None,
        "workflow": workflow,
        "mission_prompt": None,
        "plans": [],
        "next_plan_id": 1,
    }


def add_plan(
    state: dict[str, Any],
    desc: str,
    workflow: list[str] | None = None,
    before: int | None = None,
    after: int | None = None,
) -> dict[str, Any]:
    plan = {
        "id": state["next_plan_id"],
        "desc": desc,
        "workflow": workflow or state["workflow"],
        "status": "pending",
        "step": None,
        "step_index": 0,
    }
    state["next_plan_id"] += 1

    plans = state["plans"]
    if before is not None:
        idx = next((i for i, p in enumerate(plans) if p["id"] == before), None)
        if idx is not None:
            plans.insert(idx, plan)
        else:
            plans.append(plan)
    elif after is not None:
        idx = next((i for i, p in enumerate(plans) if p["id"] == after), None)
        if idx is not None:
            plans.insert(idx + 1, plan)
        else:
            plans.append(plan)
    else:
        plans.append(plan)

    return plan


def find_plan(state: dict[str, Any], plan_id: int) -> dict[str, Any] | None:
    return next((p for p in state["plans"] if p["id"] == plan_id), None)


def move_plan(
    state: dict[str, Any],
    plan_id: int,
    *,
    top: bool = False,
    bottom: bool = False,
    before: int | None = None,
    after: int | None = None,
) -> bool:
    plans = state["plans"]
    idx = next((i for i, p in enumerate(plans) if p["id"] == plan_id), None)
    if idx is None:
        return False

    plan = plans.pop(idx)

    if top:
        plans.insert(0, plan)
    elif bottom:
        plans.append(plan)
    elif before is not None:
        target_idx = next((i for i, p in enumerate(plans) if p["id"] == before), len(plans))
        plans.insert(target_idx, plan)
    elif after is not None:
        target_idx = next((i for i, p in enumerate(plans) if p["id"] == after), len(plans) - 1)
        plans.insert(target_idx + 1, plan)
    else:
        plans.append(plan)

    return True


def remove_plan(state: dict[str, Any], plan_id: int) -> bool:
    before_len = len(state["plans"])
    state["plans"] = [p for p in state["plans"] if p["id"] != plan_id]
    return len(state["plans"]) < before_len
