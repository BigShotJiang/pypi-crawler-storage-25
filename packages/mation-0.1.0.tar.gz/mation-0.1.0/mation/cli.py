"""Mission CLI — CC Worker 托管与任务编排。"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
from typing import Optional

import typer

from mation import cmux
from mation.state import (
    DEFAULT_WORKFLOW,
    STATE_DIR,
    add_plan,
    delete_state,
    find_plan,
    load_state,
    move_plan,
    new_state,
    remove_plan,
    save_state,
)
from mation.worker import resolve_worker

app = typer.Typer(help="CC Worker orchestration CLI")
plan_app = typer.Typer(help="Plan 管理")
prompt_app = typer.Typer(help="Mission prompt 管理")
app.add_typer(plan_app, name="plan")
app.add_typer(prompt_app, name="prompt")


def _require_state() -> dict:
    state = load_state()
    if state is None:
        typer.echo("没有活跃的 mation。先运行 mation start", err=True)
        raise typer.Exit(1)
    return state


def _output(data: dict) -> None:
    typer.echo(json.dumps(data, ensure_ascii=False, indent=2))


def _is_daemon_running(state: dict) -> bool:
    pid = state.get("daemon_pid")
    if not pid:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, TypeError):
        return False


# ── 生命周期 ────────────────────────────────────────────────


@app.command()
def start(
    foreground: bool = typer.Option(False, "-f", "--foreground", help="前台运行"),
    workflow: str = typer.Option(
        ",".join(DEFAULT_WORKFLOW), "--workflow", "-w", help="默认 workflow，逗号分隔",
    ),
) -> None:
    """启动 mation daemon。默认后台运行，-f 前台运行。"""
    state = load_state()

    if state is None:
        surface = cmux.get_current_surface()
        if not surface:
            typer.echo("未检测到 CMUX_SURFACE_ID，请在 cmux 终端中运行", err=True)
            raise typer.Exit(1)
        wf = [s.strip() for s in workflow.split(",") if s.strip()]
        state = new_state(surface, wf)
        save_state(state)
    elif _is_daemon_running(state):
        typer.echo("Daemon 已在运行", err=True)
        raise typer.Exit(1)

    if foreground:
        state["daemon_pid"] = os.getpid()
        save_state(state)
        _output({"ok": True, "daemon_pid": os.getpid(), "mode": "foreground"})
        from mation.daemon import run_daemon
        run_daemon()
    else:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        log_file = open(STATE_DIR / "daemon.log", "a")
        proc = subprocess.Popen(
            [sys.executable, "-m", "mation.daemon_runner"],
            stdout=log_file,
            stderr=log_file,
        )
        state["daemon_pid"] = proc.pid
        save_state(state)
        _output({"ok": True, "daemon_pid": proc.pid, "mode": "background"})


@app.command()
def stop() -> None:
    """停止 daemon。"""
    state = _require_state()
    daemon_pid = state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
            _output({"ok": True, "stopped_pid": daemon_pid})
        except (ProcessLookupError, TypeError):
            _output({"ok": True, "message": "Daemon 已不在运行"})
    else:
        _output({"ok": True, "message": "没有 daemon"})
    state["daemon_pid"] = None
    save_state(state)


@app.command()
def status() -> None:
    """查看当前 mation 状态。"""
    state = _require_state()

    plans_summary = []
    for p in state["plans"]:
        plans_summary.append({
            "id": p["id"],
            "status": p["status"],
            "step": p.get("step"),
            "workflow": ",".join(p["workflow"]) if isinstance(p["workflow"], list) else p["workflow"],
            "desc": p["desc"],
        })

    done_count = sum(1 for p in state["plans"] if p["status"] == "done")
    running_count = sum(1 for p in state["plans"] if p["status"] == "running")
    pending_count = sum(1 for p in state["plans"] if p["status"] == "pending")

    worker_info = None
    session = state.get("worker_session")
    if session:
        info = resolve_worker(session)
        worker_info = {
            "session": session,
            "running": info.running,
            "pid": info.pid,
            "surface_id": info.surface_id,
        }

    _output({
        "mission_prompt": state.get("mission_prompt"),
        "supervisor_surface": state["supervisor_surface"],
        "daemon": {"pid": state.get("daemon_pid"), "running": _is_daemon_running(state)},
        "worker": worker_info,
        "plans": {"total": len(state["plans"]), "done": done_count, "running": running_count, "pending": pending_count},
        "plan_list": plans_summary,
    })


@app.command()
def done() -> None:
    """结束 mation，清除所有状态。"""
    state = _require_state()
    daemon_pid = state.get("daemon_pid")
    if daemon_pid:
        try:
            os.kill(daemon_pid, signal.SIGTERM)
        except (ProcessLookupError, TypeError):
            pass
    delete_state()
    _output({"ok": True, "message": "Mission 结束"})


# ── Worker ──────────────────────────────────────────────────


@app.command()
def adopt(
    session: str = typer.Argument(..., help="Worker 的 session name"),
) -> None:
    """托管一个 CC worker。"""
    state = _require_state()

    info = resolve_worker(session)
    if not info.running:
        typer.echo(f"未找到运行中的 session '{session}'", err=True)
        raise typer.Exit(1)
    if not info.jsonl_path:
        typer.echo(f"session '{session}' 还没有交互记录，请先发一条消息再 adopt", err=True)
        raise typer.Exit(1)

    state["worker_session"] = session
    state["worker_cache"] = {
        "pid": info.pid,
        "surface_id": info.surface_id,
        "jsonl_path": str(info.jsonl_path),
    }
    save_state(state)
    _output({"ok": True, "session": session, "pid": info.pid, "surface_id": info.surface_id, "jsonl": str(info.jsonl_path)})


@app.command()
def drop() -> None:
    """取消托管。"""
    state = _require_state()
    session = state.get("worker_session")
    state["worker_session"] = None
    state["worker_cache"] = None
    save_state(state)
    _output({"ok": True, "released": session})


@app.command()
def send(message: str = typer.Argument(..., help="发给 worker 的消息")) -> None:
    """给 worker 发一条消息。"""
    state = _require_state()
    session = state.get("worker_session")
    if not session:
        typer.echo("没有托管的 worker", err=True)
        raise typer.Exit(1)
    info = resolve_worker(session)
    if not info.running or not info.surface_id:
        typer.echo(f"Worker '{session}' 未运行", err=True)
        raise typer.Exit(1)
    cmux.send_text(info.surface_id, message)
    _output({"ok": True, "sent_to": session, "hint": "不用等，Worker 完成后 daemon 会通知你"})


@app.command()
def kick() -> None:
    """打断卡住的 worker 并让它继续。"""
    state = _require_state()
    session = state.get("worker_session")
    if not session:
        typer.echo("没有托管的 worker", err=True)
        raise typer.Exit(1)
    info = resolve_worker(session)
    if not info.running or not info.surface_id:
        typer.echo(f"Worker '{session}' 未运行", err=True)
        raise typer.Exit(1)
    cmux.send_escape(info.surface_id)
    import time
    time.sleep(1)
    cmux.send_text(info.surface_id, "继续当前任务")
    _output({"ok": True, "kicked": session, "hint": "不用等，Worker 完成后 daemon 会通知你"})


# ── Plan ────────────────────────────────────────────────────


@plan_app.command("add")
def plan_add(
    descriptions: list[str] = typer.Argument(..., help="Plan 描述（支持多个）"),
    workflow: str = typer.Option(None, "--workflow", "-w", help="Workflow 覆盖"),
    before: Optional[int] = typer.Option(None, "--before"),
    after: Optional[int] = typer.Option(None, "--after"),
) -> None:
    """添加 plan。"""
    state = _require_state()
    wf = [s.strip() for s in workflow.split(",") if s.strip()] if workflow else None
    added = []
    for desc in descriptions:
        plan = add_plan(state, desc, workflow=wf, before=before, after=after)
        added.append({"id": plan["id"], "desc": plan["desc"]})
        if before is not None or after is not None:
            after = plan["id"]
            before = None
    save_state(state)
    _output({"ok": True, "added": added})


@plan_app.command("ls")
def plan_ls() -> None:
    """列出所有 plan。"""
    state = _require_state()
    plans = [{"id": p["id"], "status": p["status"], "step": p.get("step"),
              "workflow": ",".join(p["workflow"]) if isinstance(p["workflow"], list) else p["workflow"],
              "desc": p["desc"]} for p in state["plans"]]
    _output({"plans": plans})


@plan_app.command("show")
def plan_show(plan_id: int = typer.Argument(...)) -> None:
    """查看 plan 详情。"""
    state = _require_state()
    plan = find_plan(state, plan_id)
    if not plan:
        typer.echo(f"Plan #{plan_id} 不存在", err=True)
        raise typer.Exit(1)
    _output(plan)


@plan_app.command("rm")
def plan_rm(plan_id: int = typer.Argument(...)) -> None:
    """删除 plan。"""
    state = _require_state()
    if not remove_plan(state, plan_id):
        typer.echo(f"Plan #{plan_id} 不存在", err=True)
        raise typer.Exit(1)
    save_state(state)
    _output({"ok": True, "removed": plan_id})


@plan_app.command("move")
def plan_move(
    plan_id: int = typer.Argument(...),
    top: bool = typer.Option(False, "--top"),
    bottom: bool = typer.Option(False, "--bottom"),
    before: Optional[int] = typer.Option(None, "--before"),
    after: Optional[int] = typer.Option(None, "--after"),
) -> None:
    """调整 plan 顺序。"""
    state = _require_state()
    if not move_plan(state, plan_id, top=top, bottom=bottom, before=before, after=after):
        typer.echo(f"Plan #{plan_id} 不存在", err=True)
        raise typer.Exit(1)
    save_state(state)
    _output({"ok": True, "moved": plan_id})


@plan_app.command("done")
def plan_done(plan_id: int = typer.Argument(...)) -> None:
    """手动标记 plan 完成。"""
    state = _require_state()
    plan = find_plan(state, plan_id)
    if not plan:
        typer.echo(f"Plan #{plan_id} 不存在", err=True)
        raise typer.Exit(1)
    plan["status"] = "done"
    plan["step"] = None
    save_state(state)
    _output({"ok": True, "plan": plan_id, "status": "done"})


# ── Prompt ──────────────────────────────────────────────────


@prompt_app.command("show")
def prompt_show() -> None:
    """查看 mation prompt。"""
    state = _require_state()
    _output({"mission_prompt": state.get("mission_prompt")})


@prompt_app.command("set")
def prompt_set(text: str = typer.Argument(...)) -> None:
    """设置 mation prompt。"""
    state = _require_state()
    state["mission_prompt"] = text
    save_state(state)
    _output({"ok": True, "mission_prompt": text})


# ── Set ─────────────────────────────────────────────────────


@app.command("set")
def set_config(key: str = typer.Argument(...), value: str = typer.Argument(...)) -> None:
    """修改 mation 配置。"""
    state = _require_state()
    if key == "workflow":
        wf = [s.strip() for s in value.split(",") if s.strip()]
        state["workflow"] = wf
        save_state(state)
        _output({"ok": True, "workflow": wf})
    else:
        typer.echo(f"未知配置项: {key}", err=True)
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
