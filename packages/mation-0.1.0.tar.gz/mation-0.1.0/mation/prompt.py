"""Prompt 拼接逻辑。"""

from __future__ import annotations

from typing import Any

from mation.state import load_config


def build_message(
    state: dict[str, Any],
    plan: dict[str, Any],
    step_name: str,
) -> str:
    """根据 mission prompt + plan/step 拼接最终发给 worker 的消息。"""
    config = load_config()
    step_prompts = config.get("step_prompts", {})
    mission_prompt = state.get("mission_prompt") or ""

    step_prompt = step_prompts.get(step_name)

    # slash command 不拼接 mission prompt
    if step_prompt and step_prompt.startswith("/"):
        return step_prompt

    parts: list[str] = []

    if mission_prompt:
        parts.append(mission_prompt)
        parts.append("---")

    if step_name == "code" or step_prompt is None:
        # code 步骤：发 plan 描述
        parts.append(plan["desc"])
    else:
        parts.append(step_prompt)

    # 单行拼接，避免 CC TUI 多行输入模式（多行时 enter 变换行不提交）
    return " --- ".join(parts)
