"""Worker 解析：从 session name 查找运行时信息（PID、workspace、surface、JSONL 路径）。

查找链路：
  session name → ps 找 "claude.*<session>" → PID
  PID → ps eww 读环境变量 → CMUX_WORKSPACE_ID, CMUX_SURFACE_ID
  session name → JSONL 目录匹配文件名
"""

from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class WorkerInfo:
    session: str
    pid: int | None = None
    workspace_id: str | None = None  # cmux UUID
    surface_id: str | None = None  # cmux UUID
    jsonl_path: Path | None = None
    running: bool = False


def _find_claude_pid(session: str) -> int | None:
    """从 ps 找到 claude --resume <session> 的实际二进制 PID（跳过 bash wrapper）。"""
    try:
        result = subprocess.run(
            ["ps", "-eo", "pid,args"],
            capture_output=True, text=True, timeout=5,
        )
    except Exception:
        return None

    candidates: list[tuple[int, str]] = []
    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if "claude" not in line:
            continue
        # 匹配 --resume <session> 或 --name <session>
        matched = False
        for flag in ("--resume", "--name"):
            if f"{flag} {session}" in line or f'{flag} "{session}"' in line:
                matched = True
                break
        if not matched:
            continue
        parts = line.split()
        try:
            pid = int(parts[0])
            args = " ".join(parts[1:])
            candidates.append((pid, args))
        except (ValueError, IndexError):
            pass

    if not candidates:
        return None

    # 优先选非 bash wrapper 的进程（实际二进制）
    for pid, args in candidates:
        if "bash" not in args:
            return pid

    # fallback：返回第一个
    return candidates[0][0]


def _read_env_from_pid(pid: int, var: str) -> str | None:
    """从进程环境变量读取指定变量（macOS ps eww）。"""
    try:
        result = subprocess.run(
            ["ps", "eww", "-p", str(pid)],
            capture_output=True, text=True, timeout=5,
        )
    except Exception:
        return None

    for token in result.stdout.replace("\n", " ").split(" "):
        if token.startswith(f"{var}="):
            return token.split("=", 1)[1]
    return None


def _find_jsonl(session: str) -> Path | None:
    """在 .cac 和 .claude 目录下找 session 对应的 JSONL 文件。

    session 可以是 UUID（直接匹配文件名）或 display name（从 customTitle 匹配）。
    """
    search_dirs = [
        Path.home() / ".cac" / "envs" / "main" / ".claude" / "projects",
        Path.home() / ".claude" / "projects",
    ]

    for search_dir in search_dirs:
        if not search_dir.exists():
            continue

        # 1. 直接匹配 UUID 文件名
        for jsonl_path in search_dir.rglob(f"{session}.jsonl"):
            return jsonl_path

        # 2. 按 customTitle 匹配（session name 不是 UUID 的情况）
        for jsonl_path in search_dir.rglob("*.jsonl"):
            try:
                with open(jsonl_path) as f:
                    first_line = f.readline()
                if not first_line:
                    continue
                entry = json.loads(first_line)
                if entry.get("type") == "custom-title" and entry.get("customTitle") == session:
                    return jsonl_path
            except (json.JSONDecodeError, OSError):
                continue

    return None


def resolve_worker(session: str) -> WorkerInfo:
    """解析 worker 的完整运行时信息。"""
    info = WorkerInfo(session=session)

    # 1. 找 PID
    pid = _find_claude_pid(session)
    if pid is None:
        info.running = False
        # 仍然尝试找 JSONL（进程可能已退出但文件还在）
        info.jsonl_path = _find_jsonl(session)
        return info

    info.pid = pid
    info.running = True

    # 2. 从 PID 读 cmux 信息
    info.workspace_id = _read_env_from_pid(pid, "CMUX_WORKSPACE_ID")
    info.surface_id = _read_env_from_pid(pid, "CMUX_SURFACE_ID")

    # 3. 找 JSONL
    info.jsonl_path = _find_jsonl(session)

    return info


def get_worker_state_from_jsonl(jsonl_path: Path) -> dict:
    """从 JSONL 读取 worker 最新状态。

    返回:
        {"status": "idle"|"busy"|"interrupted"|"unknown",
         "last_type": str, "last_timestamp": str, "last_text": str}
    """
    if not jsonl_path.exists():
        return {"status": "unknown"}

    # 读最后几行
    try:
        lines = jsonl_path.read_text().strip().split("\n")
    except Exception:
        return {"status": "unknown"}

    if not lines:
        return {"status": "unknown"}

    # 从后往前找最近的真实 user/assistant 消息（跳过 local command）
    last_entry = None
    for line in reversed(lines[-50:]):
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue

        entry_type = entry.get("type")

        if entry_type == "assistant":
            last_entry = entry
            break

        if entry_type == "user":
            # 跳过 local command（/model, /clear 等）
            content = entry.get("message", {}).get("content", "")
            content_str = str(content)
            if "<command-name>" in content_str or "<local-command" in content_str:
                continue
            last_entry = entry
            break

    if last_entry is None:
        return {"status": "unknown"}

    entry_type = last_entry["type"]
    timestamp = last_entry.get("timestamp", "")

    if entry_type == "assistant":
        # 最后一条是 assistant 回复 → idle
        content = last_entry.get("message", {}).get("content", "")
        text = ""
        if isinstance(content, list):
            for c in content:
                if c.get("type") == "text":
                    text = c["text"][:200]
                    break
        else:
            text = str(content)[:200]

        return {"status": "idle", "last_type": "assistant", "last_timestamp": timestamp, "last_text": text}

    elif entry_type == "user":
        content = last_entry.get("message", {}).get("content", "")
        # 检查是否是中断
        if isinstance(content, list):
            for c in content:
                if isinstance(c, dict) and "Request interrupted" in str(c.get("text", "")):
                    return {"status": "interrupted", "last_type": "user", "last_timestamp": timestamp, "last_text": "interrupted"}

        return {"status": "busy", "last_type": "user", "last_timestamp": timestamp, "last_text": ""}

    return {"status": "unknown"}
