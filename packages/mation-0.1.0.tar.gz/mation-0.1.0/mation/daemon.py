"""后台守护进程：事件接力 + 进度提醒。

两个职责：
1. Worker Stop 信号 → 通知 Supervisor（正常接力）
2. 两者都停了 → 提醒 Supervisor 当前进度和剩余 plan（防遗忘）
"""

from __future__ import annotations

import json
import logging
import os
import signal
import sys
import time
from pathlib import Path
from typing import Any

from mation import cmux
from mation.state import STATE_DIR, load_state

STATE_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = STATE_DIR / "daemon.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [daemon] %(message)s",
    handlers=[logging.FileHandler(LOG_FILE)],
)
log = logging.getLogger(__name__)

POLL_INTERVAL = 2
IDLE_REMIND_TIMEOUT = 120  # 两者都停了多久后提醒 supervisor


def stop_file(session_id: str) -> Path:
    return STATE_DIR / f"stop-{session_id}"


def _get_worker_session_id(state: dict[str, Any]) -> str | None:
    cache = state.get("worker_cache") or {}
    jsonl = cache.get("jsonl_path", "")
    if jsonl:
        return Path(jsonl).stem
    return state.get("worker_session")


def _plan_summary(state: dict[str, Any]) -> str:
    plans = state.get("plans", [])
    if not plans:
        return "没有 plan。"
    done = sum(1 for p in plans if p["status"] == "done")
    total = len(plans)
    pending = [p for p in plans if p["status"] in ("pending", "running")]
    summary = f"Plan 进度：{done}/{total} 完成。"
    if pending:
        next_plans = ", ".join(f"#{p['id']} {p['desc']}" for p in pending[:3])
        summary += f" 待推进：{next_plans}"
    return summary


def notify_supervisor(state: dict[str, Any], message: str) -> None:
    surface = state.get("supervisor_surface")
    if not surface:
        return
    log.info(f"→ Supervisor: {message[:120]}")
    try:
        cmux.send_text(surface, message)
    except RuntimeError as e:
        log.error(f"Failed to notify supervisor: {e}")


def run_daemon() -> None:
    log.info("Daemon started (pid=%d)", os.getpid())

    both_idle_since: float | None = None

    def handle_signal(signum: int, frame: Any) -> None:
        log.info("Daemon stopping")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    while True:
        try:
            state = load_state()
            if state is None:
                log.info("No active mation, exiting")
                break

            session = state.get("worker_session")
            if not session:
                time.sleep(POLL_INTERVAL)
                continue

            session_id = _get_worker_session_id(state)
            if not session_id:
                time.sleep(POLL_INTERVAL)
                continue

            sf = stop_file(session_id)

            if sf.exists():
                # Worker 停了 → 读信号 → 通知 Supervisor → 消费
                try:
                    stop_data = json.loads(sf.read_text())
                    last_msg = stop_data.get("last_assistant_message", "")
                except (json.JSONDecodeError, OSError):
                    last_msg = ""

                sf.unlink()
                both_idle_since = None

                summary = _plan_summary(state)
                notify_supervisor(state, f"[Mation] Worker 停了。回复：{last_msg[:300]} --- {summary}")
                log.info("Stop signal consumed, supervisor notified")

            else:
                # 没有 Stop 信号 → Worker 在忙或者两者都停了
                # 如果 Worker 在忙，不需要提醒
                # 如果两者都停了（一段时间没有 Stop 信号），提醒 Supervisor
                if both_idle_since is None:
                    both_idle_since = time.time()
                elif time.time() - both_idle_since > IDLE_REMIND_TIMEOUT:
                    summary = _plan_summary(state)
                    notify_supervisor(state, f"[Mation] {IDLE_REMIND_TIMEOUT}s 没有活动。{summary}")
                    log.info("Both idle, reminded supervisor")
                    both_idle_since = time.time()

        except Exception as e:
            log.error(f"Daemon error: {e}")

        time.sleep(POLL_INTERVAL)
