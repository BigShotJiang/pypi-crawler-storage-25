# mation

CC Worker orchestration CLI — adopt, monitor, and drive Claude Code agents via [cmux](https://cmux.com).

## The Three-Party System

`mation` implements a relay system between three parties: **Human**, **Supervisor CC**, and **Worker CC**. At least one of them is always active — the system never stalls.

```
Worker stops → Daemon relays → Supervisor wakes up, evaluates, instructs Worker
                                        → Worker works → stops → Daemon relays → ...

All plans done → Supervisor notifies Human → Human decides: more plans or done
```

- **Worker** does the actual coding work. It doesn't know it's being managed.
- **Supervisor** is the Human's agent. It evaluates Worker output, runs verification (by telling Worker to review/test), and drives plans forward.
- **Human** sets the mission direction and makes final decisions. Only gets notified when Supervisor needs input.
- **Daemon** is the relay — when Worker stops, it instantly notifies Supervisor. Pure event bridge, no decisions.

The three never all idle at once. Worker stops → Supervisor picks up. Supervisor sends instruction → Worker picks up. Like monks taking turns ringing the bell.

## Requirements

- [cmux](https://cmux.com) with socket mode set to **Automation** (Settings → Socket Control Mode)
- Python 3.12+
- [uv](https://github.com/astral-sh/uv)
- CC Stop hook configured (see [Setup](#setup))

## Install

```bash
uv tool install .
```

## Setup

Configure the CC Stop hook globally so `mation` knows when a Worker finishes responding:

```json
// ~/.claude/settings.json (or your cac env settings)
{
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "bash ~/.mation/on-stop.sh"
          }
        ]
      }
    ]
  }
}
```

Create the hook script:

```bash
mkdir -p ~/.mation
cat > ~/.mation/on-stop.sh << 'EOF'
#!/bin/bash
INPUT=$(cat)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id')
echo "$INPUT" > ~/.mation/stop-${SESSION_ID}
EOF
chmod +x ~/.mation/on-stop.sh
```

## Quick start

```bash
# Start daemon (background)
mation start

# Set the mission goal
mation prompt set "Implement chat read receipts"

# Adopt a running CC worker
# (get session name from worker's exit: claude --resume "xxx")
mation adopt my-worker

# Queue plans
mation plan add "Create message_reads table" "Backend read API" "Frontend read status"

# Daemon watches Worker. When Worker stops, Supervisor gets notified.
# Supervisor evaluates, then instructs Worker:
mation send "review your changes"
mation send "run tests"
mation send "fix the failing test"

# Mark plan complete when satisfied
mation plan done 1

# Check progress
mation status

# Stop daemon
mation stop

# End mission
mation done
```

## CLI Reference

### Lifecycle
| Command | Description |
|---------|-------------|
| `mation start [-f]` | Start daemon (default: background, `-f`: foreground) |
| `mation stop` | Stop daemon |
| `mation status` | Show mission status (JSON) |
| `mation done` | End mission, clear all state |

### Worker
| Command | Description |
|---------|-------------|
| `mation adopt <session>` | Adopt a CC worker by session name |
| `mation drop` | Release worker |
| `mation send "msg"` | Send message to worker |
| `mation kick` | Interrupt stuck worker + resume |

### Plan
| Command | Description |
|---------|-------------|
| `mation plan add "desc" [-w workflow]` | Add plans |
| `mation plan ls` | List all plans |
| `mation plan show <id>` | Show plan details |
| `mation plan rm <id>` | Remove plan |
| `mation plan move <id> --top/--before/--after` | Reorder plans |
| `mation plan done <id>` | Mark plan complete |

### Prompt & Config
| Command | Description |
|---------|-------------|
| `mation prompt set "text"` | Set mission prompt |
| `mation prompt show` | Show current prompt |
| `mation set workflow "code,test,review"` | Change default workflow |

## How it works

1. **Worker detection**: `mation adopt` finds the CC process via `ps`, reads `CMUX_SURFACE_ID` from its environment, locates session JSONL by `customTitle`
2. **Idle detection**: CC Stop hook writes a signal file when Worker finishes responding. Daemon polls for this file.
3. **Communication**: JSON-RPC over cmux Unix socket (`surface.send_text`, `surface.send_key`)
4. **Relay**: Daemon consumes the signal file and injects a notification message into Supervisor's terminal. Supervisor CC wakes up and decides what to do next.

## License

MIT
