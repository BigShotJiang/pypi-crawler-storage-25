from __future__ import annotations

from typing import Any

import pytest

from benchstone.gate import evaluate
from benchstone.manifest import Benchmark
from benchstone.references import Reference
from benchstone.store import Baseline, Run


def _bench(**overrides: Any) -> Benchmark:
    base: dict[str, Any] = dict(
        name="B",
        entry_point="B",
        tier="quality",
        deterministic=False,
        metric_direction="minimize",
        expected_runtime_seconds=None,
        threads=1,
        gpu="none",
        background_required=False,
        repetitions=5,
        baseline_seeds=(1, 2, 3, 4, 5),
        promotion_sigma=2.0,
        promotion_z=None,
        corpus_path=None,
        corpus_hash=None,
        corpus_type=None,
        reference_policy=None,
        gate_policy="sigma",
    )
    base.update(overrides)
    return Benchmark(**base)


def _run(
    metric: float | None = None,
    status: str = "ok",
    rep: int = 0,
    artifact_hash: str | None = None,
) -> Run:
    return Run(
        id=0, project="P", benchmark="B", git_sha="sha",
        git_dirty=False, dirty_diff_path=None,
        timestamp="t", harness_version="0.1.0", host="h",
        seed=1, meta_seed=None, repetition_index=rep,
        status=status, metric=metric, metric_components=None,
        wall_clock_seconds=0.0, project_metadata=None,
        stderr_log_path=None,
        artifact_hash=artifact_hash,
        artifact_path=None,
    )


def _baseline() -> Baseline:
    return Baseline(
        project="P", benchmark="B", git_sha="baseline_sha",
        established_at="t", notes=None,
    )


def test_no_baseline() -> None:
    v = evaluate(_bench(), None, [], [])
    assert v.kind == "NO_BASELINE"


def test_needs_more_baseline_data() -> None:
    bench = _bench()
    v = evaluate(bench, _baseline(), [_run(1.0)], [_run(1.0) for _ in range(5)])
    assert v.kind == "NEEDS_MORE_DATA"
    assert "baseline" in v.reason


def test_needs_more_candidate_data() -> None:
    bench = _bench()
    baseline_runs = [_run(1.0 + 0.01 * i, rep=i) for i in range(5)]
    candidate_runs = [_run(1.0, rep=0)]
    v = evaluate(bench, _baseline(), baseline_runs, candidate_runs)
    assert v.kind == "NEEDS_MORE_DATA"
    assert "candidate" in v.reason


def test_promote_minimize() -> None:
    bench = _bench()  # minimize, sigma threshold 2.0
    baseline = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    candidate = [_run(5.0 + 0.1 * i, rep=i) for i in range(5)]
    v = evaluate(bench, _baseline(), baseline, candidate)
    assert v.kind == "PROMOTE"
    assert v.sigma is not None and v.sigma >= 2.0


def test_reject_minimize_no_improvement() -> None:
    bench = _bench()
    baseline = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    candidate = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    v = evaluate(bench, _baseline(), baseline, candidate)
    assert v.kind == "REJECT"
    assert v.sigma is not None and abs(v.sigma) < 2.0


def test_reject_minimize_regression() -> None:
    bench = _bench()
    baseline = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    candidate = [_run(15.0 + 0.1 * i, rep=i) for i in range(5)]
    v = evaluate(bench, _baseline(), baseline, candidate)
    assert v.kind == "REJECT"
    assert v.sigma is not None and v.sigma < 0


def test_promote_maximize() -> None:
    bench = _bench(metric_direction="maximize")
    baseline = [_run(5.0 + 0.1 * i, rep=i) for i in range(5)]
    candidate = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    v = evaluate(bench, _baseline(), baseline, candidate)
    assert v.kind == "PROMOTE"


def test_errored_runs_excluded_from_count() -> None:
    bench = _bench()
    baseline = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    candidate = (
        [_run(5.0, rep=0)]
        + [_run(None, status="error", rep=i) for i in range(1, 5)]
    )
    v = evaluate(bench, _baseline(), baseline, candidate)
    assert v.kind == "NEEDS_MORE_DATA"
    assert "candidate" in v.reason


def test_correctness_no_reference() -> None:
    bench = _bench(
        tier="correctness", deterministic=True, metric_direction=None,
        promotion_sigma=None, reference_policy="byte_equivalence",
    )
    v = evaluate(bench, None, [], [_run(artifact_hash="sha256:aa")])
    assert v.kind == "NO_REFERENCE"


def test_correctness_needs_more_data() -> None:
    bench = _bench(
        tier="correctness", deterministic=True, metric_direction=None,
        promotion_sigma=None, reference_policy="byte_equivalence",
    )
    ref = Reference(
        project="P", benchmark="B", frozen_at="t",
        frozen_git_sha="sha", content_hash="sha256:aa",
        content_path="/tmp/ref.bin", from_run_id=1, notes=None,
    )
    v = evaluate(bench, None, [], [], reference=ref)
    assert v.kind == "NEEDS_MORE_DATA"


def test_correctness_pass_on_hash_match() -> None:
    bench = _bench(
        tier="correctness", deterministic=True, metric_direction=None,
        promotion_sigma=None, reference_policy="byte_equivalence",
    )
    ref = Reference(
        project="P", benchmark="B", frozen_at="t",
        frozen_git_sha="sha", content_hash="sha256:abc",
        content_path="/tmp/ref.bin", from_run_id=1, notes=None,
    )
    v = evaluate(
        bench, None, [],
        [_run(artifact_hash="sha256:abc", rep=0)],
        reference=ref,
    )
    assert v.kind == "PASS"
    assert v.reference_hash == "sha256:abc"
    assert v.candidate_hash == "sha256:abc"


def test_correctness_fail_on_hash_mismatch() -> None:
    bench = _bench(
        tier="correctness", deterministic=True, metric_direction=None,
        promotion_sigma=None, reference_policy="byte_equivalence",
    )
    ref = Reference(
        project="P", benchmark="B", frozen_at="t",
        frozen_git_sha="sha", content_hash="sha256:abc",
        content_path="/tmp/ref.bin", from_run_id=1, notes=None,
    )
    v = evaluate(
        bench, None, [],
        [_run(artifact_hash="sha256:xyz", rep=0)],
        reference=ref,
    )
    assert v.kind == "FAIL"
    assert v.candidate_hash == "sha256:xyz"


def test_correctness_picks_latest_candidate() -> None:
    """When multiple candidate runs are present, the most recent one decides the verdict."""
    bench = _bench(
        tier="correctness", deterministic=True, metric_direction=None,
        promotion_sigma=None, reference_policy="byte_equivalence",
    )
    ref = Reference(
        project="P", benchmark="B", frozen_at="t",
        frozen_git_sha="sha", content_hash="sha256:abc",
        content_path="/tmp/ref.bin", from_run_id=1, notes=None,
    )
    v = evaluate(
        bench, None, [],
        [_run(artifact_hash="sha256:old", rep=0),
         _run(artifact_hash="sha256:abc", rep=1)],  # latest matches
        reference=ref,
    )
    assert v.kind == "PASS"


def test_gate_policy_mann_whitney_promotes_cleanly_separated() -> None:
    bench = _bench(gate_policy="mann_whitney")
    baseline = [_run(10.0 + 0.1 * i, rep=i) for i in range(5)]
    candidate = [_run(5.0 + 0.1 * i, rep=i) for i in range(5)]
    v = evaluate(bench, _baseline(), baseline, candidate)
    assert v.kind == "PROMOTE"
    assert v.sigma is not None and v.sigma >= 2.0
    assert "mann_whitney" in v.reason


def test_gate_policy_mann_whitney_immune_to_outlier() -> None:
    """Arborist pathology replayed: sigma REJECT, mann_whitney PROMOTE."""
    bench_sigma = _bench(gate_policy="sigma", promotion_sigma=2.0)
    bench_mw = _bench(gate_policy="mann_whitney", promotion_sigma=2.0)

    baseline = [_run(m, rep=i) for i, m in enumerate([1.248, 1.324, 1.254, 1.261, 1.832])]
    candidate = [_run(m, rep=i) for i, m in enumerate([1.20, 1.21, 1.22, 1.23, 1.24])]

    v_sigma = evaluate(bench_sigma, _baseline(), baseline, candidate)
    v_mw = evaluate(bench_mw, _baseline(), baseline, candidate)

    # Parametric sigma: outlier inflates baseline SE, reject.
    assert v_sigma.kind == "REJECT"
    # Rank-based: every candidate value beats every non-outlier baseline
    # value; promotion is clean.
    assert v_mw.kind == "PROMOTE"


def test_deterministic_non_correctness_raises() -> None:
    bench = _bench(deterministic=True)
    with pytest.raises(NotImplementedError):
        evaluate(bench, _baseline(), [], [])
