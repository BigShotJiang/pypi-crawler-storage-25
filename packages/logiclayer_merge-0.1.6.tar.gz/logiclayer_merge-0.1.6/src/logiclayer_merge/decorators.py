from functools import wraps
from fastapi import status
from fastapi.responses import JSONResponse
import polars as pl
import httpx
import inspect

from .exceptions import APIException

def handle_api_exceptions(func):
    """Decorator to handle common API exceptions."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            if inspect.iscoroutinefunction(func):
                return await func(*args, **kwargs)
            else:
                return func(*args, **kwargs)
        except APIException as e:
            return e.to_json_response()
        except (pl.exceptions.InvalidOperationError, pl.exceptions.ColumnNotFoundError) as e:
            return JSONResponse(
                status_code=status.HTTP_400_BAD_REQUEST,
                content={
                    "Error": "The requested column to join is missing in one of the datasets.",
                    "Details": str(e)
                }
            )
        except (httpx.ConnectTimeout, httpx.ReadTimeout) as e:
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"Error": f"{type(e).__name__}", "Details": str(e)}
            )
        except Exception as e:
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content={"Error": str(e)}
            )
    return wrapper
