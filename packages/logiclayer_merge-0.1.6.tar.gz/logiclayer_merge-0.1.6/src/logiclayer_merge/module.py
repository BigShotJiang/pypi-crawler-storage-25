from typing import Annotated, Optional

import datetime
import logiclayer as ll
import polars as pl
import httpx
from urllib.parse import urlparse

from fastapi import Depends, Header, Query, status
from fastapi.responses import JSONResponse
from tesseract_olap import OlapServer
from tesseract_olap.backend import JoinStep
from tesseract_olap.backend.models import Result
from tesseract_olap.logiclayer.response import data_response, ResponseFormat
from tesseract_olap.query import DataMultiRequest, DataMultiQuery
from tesseract_olap.schema.public import TesseractSchema
from tesseract_olap.schema import DataType

from . import __title__, __version__
from .models import MergeParams, FileParams, StructureParams, MergeOptionsParams
from .exceptions import DomainNotAllowedException, InvalidUrlException, EmptyDFException, UnsupportedContentTypeException
from .decorators import handle_api_exceptions

QueryShowAll = Query(
    description=(
        "Show all elements including non-visible ones. When false (default), "
        "show only visible elements. When true, show all elements."
    ),
)


def auth_token(
    header_auth: Annotated[Optional[str], Header(alias="authorization")] = None,
    header_jwt: Annotated[Optional[str], Header(alias="x-tesseract-jwt")] = None,
    query_token: Annotated[Optional[str], Query(alias="token")] = None,
):
    if header_jwt:
        return ll.AuthToken(ll.AuthTokenType.JWTOKEN, header_jwt)
    if query_token:
        return ll.AuthToken(ll.AuthTokenType.SEARCHPARAM, query_token)
    if header_auth:
        if header_auth.startswith("Bearer "):
            return ll.AuthToken(ll.AuthTokenType.JWTOKEN, header_auth[7:])
        if header_auth.startswith("Basic "):
            return ll.AuthToken(ll.AuthTokenType.BASIC, header_auth[6:])
        if header_auth.startswith("Digest "):
            return ll.AuthToken(ll.AuthTokenType.DIGEST, header_auth[7:])
    return None


class MergeModule(ll.LogicLayerModule):
    """Endpoint merging module.

    Allows to merge the results of other LogicLayer modules in a single response.
    """

    def __init__(self, olap: Optional[OlapServer] = None, allowed_domains: Optional[str] = "", **kwargs):
        super().__init__(**kwargs)
        self.tesseract = olap
        self.auth = kwargs.get("auth")
        self.allowed_domains = allowed_domains
        self.client = httpx.AsyncClient()

    def startup_tasks(self):
        """Startup tasks."""
        self.set_allowed_domains()

    def shutdown_tasks(self):
        """Shutdown tasks."""
        self.client.aclose()

    def set_allowed_domains(self):
        """Set the allowed domains for this module."""
        if self.allowed_domains != "":
            self.allowed_domains = self.allowed_domains.split(',')

    def _get_cubes(
        self,
        token: Optional[ll.AuthToken],
        locale: Optional[str] = None,
        show_all: Annotated[bool, QueryShowAll] = False,
    ):
        """send available cubes"""
        roles = self.auth.get_roles(token) if self.auth else None
        return TesseractSchema.from_entity(
            self.tesseract.schema, roles=roles, locale=locale, show_all=show_all
        ).cubes

    @staticmethod
    def build_adjacency_list(cubes):
        """Builds an adjacency list for cubes and their levels."""
        adjacency_list = {
            cube.name: [
                level.name
                for dim in cube.dimensions
                for hier in dim.hierarchies
                for level in hier.levels
            ]
            for cube in cubes
        }

        reversed_adj = {}
        for cube_name, levels in adjacency_list.items():
            for level_name in levels:
                reversed_adj.setdefault(level_name, []).append(cube_name)

        return {**adjacency_list, **reversed_adj}

    @staticmethod
    def preprocess_cube(cubes):
        """Preprocesses cubes to extract measure information."""
        ad_cube_measure = {}
        cube_to_measures = {}

        for cube in cubes:
            cube_name = cube.name
            measures = [m.name for m in cube.measures]
            ad_cube_measure[cube_name] = [f"{m}@{cube_name}" for m in measures]
            cube_to_measures[cube_name] = measures

        return {"ad_cube_measure": ad_cube_measure, "cube_to_measures": cube_to_measures}

    @ll.route("GET", "/")
    def status(self) -> ll.ModuleStatus:
        """Return the current status of the internals of this module."""
        return ll.ModuleStatus(module=__title__, version=__version__, debug=self.debug, status="ok")

    @ll.route("POST", "/query.{extension}")
    @handle_api_exceptions
    def multiquery_data(
        self,
        extension: ResponseFormat,
        params: DataMultiRequest,
        token: Optional[ll.AuthToken] = Depends(auth_token),
    ):
        """Execute a request for joining data from the server."""
        # Add role data to all params, overwrite possible user injections
        roles = self.auth.get_roles(token) if self.auth else None
        for request in params.requests:
            request.roles = roles

        query = DataMultiQuery.from_requests(
            self.tesseract.schema,
            params.requests,
            params.joins,
        )

        with self.tesseract.session() as session:
            result = session.fetch_dataframe(query.initial)
            if result.data.shape[0] == 0:
                raise EmptyDFException("Left Query")
            step = JoinStep.new(result)

            for query_right, join_params in query.join_with:
                result = session.fetch_dataframe(query_right)
                if result.data.shape[0] == 0:
                    raise EmptyDFException("Right Query")
                join_params.suffix = f"_{query_right.cube.name}"
                step = step.join_with(result, join_params)

        result = step.get_result(params.pagination)

        return data_response(
            query,
            result,
            extension
        )

    @ll.route("POST", "/structures")
    def get_data_structures(
        self,
        params: Optional[StructureParams] = None,
        token: Optional[ll.AuthToken] = Depends(auth_token)
    ):
        """Send adjacency list and cube to measures mapping"""
        if params is None:
            params = StructureParams()
        cubes_data = self._get_cubes(token, locale=params.locale, show_all=params.show_all)
        preprocessed = self.preprocess_cube(cubes_data)

        return JSONResponse(content={
            "ad_cube_measure": preprocessed["ad_cube_measure"],
            "cube_to_measures": preprocessed["cube_to_measures"],
            "adjacency_list": self.build_adjacency_list(cubes_data),
        })

    @ll.route("POST", "/cubes")
    def get_cubes(
        self,
        params: Optional[StructureParams] = None,
        token: Optional[ll.AuthToken] = Depends(auth_token)
    ):
        """send available cubes"""
        if params is None:
            params = StructureParams()
        return self._get_cubes(token, locale=params.locale, show_all=params.show_all)
    
    @ll.route("GET", "/allowed")
    def get_allowed_domains(
        self,
    ):
        """send allowed domains"""
        return self.allowed_domains

    @ll.route("POST", "/cubes/merge_options")
    def get_merge_options(
        self,
        params: MergeOptionsParams,
        locale: Optional[str] = None,
        show_all: Annotated[bool, QueryShowAll] = False,
        token: Optional[ll.AuthToken] = Depends(auth_token)
    ):
        """for dimensions selected send available cubes to merge on or available cubes+measures"""

        cubes_data = self._get_cubes(token, locale=locale, show_all=show_all)
        preprocessed = self.preprocess_cube(cubes_data)
        adjacency_list = self.build_adjacency_list(cubes_data)

        if not params.q:
            return JSONResponse(content={"option_sets": [], "option_measures": []})

        try:
            option_sets = list(set.intersection(*[set(adjacency_list.get(c, [])) for c in params.q]))
            if option_sets:
                measures_lists = [preprocessed["cube_to_measures"].get(c, []) for c in params.q]
                option_measures = list(set.intersection(*[set(measures) for measures in measures_lists]))
            else:
                option_measures = []
            return JSONResponse(content={"option_sets": option_sets, "option_measures": option_measures})

        except TypeError as e:
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"Status": "Error", "Message": str(e)})

    @ll.route("POST", "/cubes/merge.{extension}")
    @handle_api_exceptions
    async def merge_cubes(
        self,
        extension: ResponseFormat,
        merge_params: MergeParams
    ):
        join_params = merge_params.join
        left_params = merge_params.query_left
        right_params = merge_params.query_right
        pagi = merge_params.pagination
        df, annotations = await self.fetch_query(left_params.url, left_params.data, left_params.headers)
        df2, annotations2 = await self.fetch_query(right_params.url, right_params.data, right_params.headers)

        date = datetime.datetime.now(tz=datetime.timezone.utc)

        query = FileParams(
            filename = f"datajoin_{date.strftime(r'%Y-%m-%d_%H-%M-%S')}",
            annotations = {"query_left": annotations, "query_right": annotations2}
        )

        step = JoinStep(data=df, keys=[], statuses=[])

        result = Result(
            data=df2, 
            columns={
                k: DataType.from_polars(v) for k, v in dict(zip(df.columns, df.dtypes)).items()
            },
            cache={"key": "", "status": ""}
        )

        step = step.join_with(result, join_params)

        result = step.get_result(pagi)

        return data_response(
            query,
            result,
            extension
        )

    async def fetch_query(self, url, data, headers):

        self._validate_url(url)

        r = await self.client.get(url=url, auth=data, headers=headers)
        content_type = r.headers.get("content-type", "")

        if "text/csv" in content_type or content_type.endswith("/csv"):
            df = pl.read_csv(r.content, separator=",", has_header=True, infer_schema_length=1000)
            if df.shape[0] == 0:
                raise EmptyDFException(url, "Empty DataFrame")
            return df, "Not Available"
        elif "application/json" in content_type:
            json_data = r.json()
            df = pl.DataFrame(json_data["data"])
            if df.shape[0] == 0:
                raise EmptyDFException(url, "Empty DataFrame")
            return df, json_data["annotations"]
        else:
            raise UnsupportedContentTypeException(content_type, source=url)

    def _validate_url(self, url: str) -> None:
        """Validate URL and raise appropriate exceptions"""
        try:
            parsed = urlparse(url)
            if not parsed.scheme or not parsed.netloc:
                raise InvalidUrlException(url, "Missing scheme or network location")
        except Exception:
            raise InvalidUrlException(url, "Malformed URL")

        # Check domain
        domain = parsed.netloc.split(':')[0]
        valid_domains = [d for d in self.allowed_domains if d and isinstance(d, str)]

        if not any(
            domain.endswith(f".{allowed}") or domain == allowed
            for allowed in valid_domains
        ):
            raise DomainNotAllowedException(domain, valid_domains, source=url)