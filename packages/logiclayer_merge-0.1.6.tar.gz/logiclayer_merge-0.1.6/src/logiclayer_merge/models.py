from typing import Optional, List

from pydantic import Field
from pydantic import BaseModel as PydanticBaseModel
from tesseract_olap.query import JoinIntent


class BaseModel(PydanticBaseModel):
    class Config:
        arbitrary_types_allowed = True


class PaginationIntent(BaseModel):
    limit: int = 0
    offset: int = 0


class QueryRequest(BaseModel):
    url: str
    data: Optional[str] = None
    headers: Optional[str] = None


class MergeParams(BaseModel):
    query_left : QueryRequest
    query_right: QueryRequest
    pagination: PaginationIntent = Field(default_factory=PaginationIntent)
    join: JoinIntent


class FileParams(BaseModel):
    filename: str
    annotations: dict

    def get_annotations(self):
        return self.annotations


class StructureParams(BaseModel):
    locale: Optional[str] = Field(default=None)
    show_all: bool = Field(
        default=False,
        description=(
            "Show all elements including non-visible ones. When false (default), "
            "show only visible elements. When true, show all elements."
        ),
    )


class MergeOptionsParams(BaseModel):
    q: List[str] = Field(
        default=[],
        description="for dimensions selected send available cubes to merge on or available cubes+measures"
    )