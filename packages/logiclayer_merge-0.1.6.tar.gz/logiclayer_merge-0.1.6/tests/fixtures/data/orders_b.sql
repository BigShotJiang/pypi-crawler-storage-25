CREATE TABLE default.orders_b
(
    `order_id` String,
    `customer_id` String,
    `product` String,
    `quantity` Int64,
    `unit_price` Int64,
    `order_date` String
)
ENGINE = MergeTree()
ORDER BY order_id
SETTINGS index_granularity = 8192;

INSERT INTO default.orders_b
FROM INFILE '/docker-entrypoint-initdb.d/orders_b.csv'
FORMAT CSV;