"""Tests for drape."""
