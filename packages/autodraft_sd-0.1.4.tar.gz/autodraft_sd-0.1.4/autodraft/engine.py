"""Public ``Autodraft`` class.

Kept import-light: this module must not import torch / transformers / the
MobiTree source tree. Heavy imports happen lazily inside
:mod:`autodraft.local_runner` when ``run()`` is actually invoked.
"""

from __future__ import annotations

from typing import Any, Optional

from .config import AutodraftConfig
from .errors import InvalidAutodraftConfigError


class Autodraft:
    """Thin wrapper around the MobiTree speculative-decoding runtime.

    MobiTree always runs split-process: the draft side (this object) opens a
    socket to a target server (started via ``autodraft.serve_target`` or
    ``examples/target.py``). For single-host setups, leave ``target_host`` at
    its default ``"127.0.0.1"`` and run the target script in another
    terminal. For cross-host setups, set ``target_host`` to the target
    machine's address.

    Parameters
    ----------
    draft_model:
        Hugging Face id (or local path) of the small draft model.
    target_model:
        Hugging Face id (or local path) of the large target model.
    draft_quantization, target_quantization:
        One of ``None`` / ``"none"`` / ``"4bit"`` / ``"8bit"``.
    target_host, target_port:
        Address of the MobiTree target server. Defaults to ``127.0.0.1:26001``.
    hf_token:
        HF access token for gated repos. ``None`` falls back to ``HF_TOKEN``
        / ``HUGGING_FACE_HUB_TOKEN`` env vars. Masked in ``__repr__``.
    **kwargs:
        Forwarded verbatim to the underlying runner. Use this to pass any of
        ``run_draft``'s ~70 options without refactoring this wrapper.
    """

    def __init__(
        self,
        draft_model: str,
        target_model: str,
        draft_quantization: Optional[str] = None,
        target_quantization: Optional[str] = None,
        target_host: str = "127.0.0.1",
        target_port: int = 26001,
        hf_token: Optional[str] = None,
        **kwargs: Any,
    ):
        if not isinstance(draft_model, str) or not draft_model:
            raise InvalidAutodraftConfigError("draft_model must be a non-empty string")
        if not isinstance(target_model, str) or not target_model:
            raise InvalidAutodraftConfigError("target_model must be a non-empty string")
        if not isinstance(target_host, str) or not target_host:
            raise InvalidAutodraftConfigError("target_host must be a non-empty string")
        if not isinstance(target_port, int) or isinstance(target_port, bool):
            raise InvalidAutodraftConfigError("target_port must be int")
        if hf_token is not None and not isinstance(hf_token, str):
            raise InvalidAutodraftConfigError("hf_token must be a string or None")

        self.config = AutodraftConfig(
            draft_model=draft_model,
            target_model=target_model,
            draft_quantization=draft_quantization,
            target_quantization=target_quantization,
            target_host=target_host,
            target_port=target_port,
            hf_token=hf_token,
        )
        self.extra_kwargs = dict(kwargs)

    def run(
        self,
        input_text: str,
        proactive: bool = False,
        cs: Any = None,
        **kwargs: Any,
    ) -> Any:
        """Run speculative decoding on ``input_text`` and return the result."""

        if not isinstance(input_text, str) or not input_text:
            raise ValueError("input_text must be a non-empty string")

        merged_kwargs = dict(self.extra_kwargs)
        merged_kwargs.update(kwargs)

        from .local_runner import run_local

        return run_local(
            draft_model=self.config.draft_model,
            target_model=self.config.target_model,
            draft_quantization=self.config.draft_quantization,
            target_quantization=self.config.target_quantization,
            input_text=input_text,
            proactive=proactive,
            cs=cs,
            target_host=self.config.target_host,
            target_port=self.config.target_port,
            hf_token=self.config.hf_token,
            **merged_kwargs,
        )

    def __repr__(self) -> str:
        c = self.config
        token_repr = "None" if c.hf_token is None else "'***'"
        return (
            f"Autodraft(draft_model={c.draft_model!r}, "
            f"target_model={c.target_model!r}, "
            f"target_host={c.target_host!r}, "
            f"target_port={c.target_port}, "
            f"hf_token={token_repr})"
        )
