"""Python entry point for the MobiTree target server.

Symmetric counterpart to ``autodraft.local_runner.run_local`` but for the
target side. Today users start the target server with ``./run_target.sh``
which shells out to ``python -m evaluation.eval_opt_classic_target``;
``serve_target`` lets them do the same from a ``.py`` file.

Mirrors ``run_local``'s conventions:
- import-light at module load (no torch / no evaluation runtime)
- HF token resolved + exported to env BEFORE the lazy runtime import
- raises :class:`LocalRuntimeUnavailableError` if the source checkout / heavy
  deps are missing
- forwards a curated overlay; unknown kwargs are passed through to the inner
  ``serve()``

This function **blocks forever** (server loop). Run it in its own process or
its own thread.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Optional

from .errors import LocalRuntimeUnavailableError


# Quantization tokens accepted by the underlying runtime. ``run_target.sh``
# defaults to ``--load-in-8bit``, so we mirror that here. Note: the raw CLI
# parser falls back to ``"4bit"`` if neither flag is set, but that's a CLI
# quirk — we don't reproduce it. ``quantization="none"`` means no quantization.
_VALID_QUANTIZATIONS = {"none", "4bit", "8bit"}


def _import_runtime():
    try:
        from evaluation.eval_opt_classic_target import serve, set_seed  # type: ignore
    except ImportError as exc:
        raise LocalRuntimeUnavailableError(
            "autodraft.target_server could not import the MobiTree target "
            "runtime (evaluation/eval_opt_classic_target.py). The wheel ships "
            "the runtime, so this usually means the heavy dependencies "
            "(torch, transformers, accelerate) are not installed in this "
            "environment. Install with `pip install autodraft-sd` (or "
            "`pip install -e .` from a source checkout) and make sure your "
            "PyTorch wheel matches your CUDA version. For 4/8-bit "
            "quantization, also `pip install autodraft-sd[quant]`."
        ) from exc
    return serve, set_seed


def _apply_hf_token(hf_token: Optional[str]) -> None:
    """Same protocol as ``autodraft.local_runner._apply_hf_token`` — kept
    duplicated rather than imported so this module stays import-light."""
    effective = hf_token or os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if effective:
        os.environ["HF_TOKEN"] = effective
        os.environ["HUGGING_FACE_HUB_TOKEN"] = effective


def _ensure_data_dir() -> None:
    """Same protocol as ``autodraft.local_runner._ensure_data_dir``: default
    to ``./data`` (CWD-relative) so caches land where the user ran the
    script. Override via ``MOBITREE_DATA_DIR``."""
    if not os.environ.get("MOBITREE_DATA_DIR"):
        os.environ["MOBITREE_DATA_DIR"] = str(Path.cwd() / "data")
    root = Path(os.environ["MOBITREE_DATA_DIR"])
    root.mkdir(parents=True, exist_ok=True)
    (root / "profile").mkdir(parents=True, exist_ok=True)


def serve_target(
    host: str = "0.0.0.0",
    port: int = 26001,
    target_model: str = "",
    draft_model: Optional[str] = None,
    quantization: str = "8bit",
    device_map: str = "auto",
    server_name: str = "autodraft",
    hf_token: Optional[str] = None,
    eager_load: bool = False,
    enable_auto_target_profile: bool = True,
    enable_auto_server_draft_profile: bool = True,
    temperature: float = 0.0,
    enable_gpu_monitor: bool = False,
    gpu_monitor_interval: float = 0.05,
    fix_gpu_clock: bool = False,
    graphics_clock: Optional[int] = None,
    memory_clock: Optional[int] = None,
    seed: Optional[int] = None,
    deterministic: bool = False,
    debug: bool = False,
    output_file: Optional[str] = None,
    int8_cpu_offload: bool = False,
    **kwargs: Any,
) -> None:
    """Start the MobiTree target server. **Blocks forever.**

    The defaults mirror ``run_target.sh``: 8-bit quantization, ``device_map="auto"``,
    auto target profiling enabled, lazy model load. Pass ``draft_model`` only
    if you intend to run a Server-Only / autoregressive workload that needs
    the target host to also load the draft.

    Parameters
    ----------
    host, port:
        Bind address. Default ``0.0.0.0:26001`` matches the chat UI.
    target_model:
        HF id (or local path) of the target model. Required.
    draft_model:
        Optional HF id for Server-Only mode. Default ``None``.
    quantization:
        ``"none"`` / ``"4bit"`` / ``"8bit"``. Default ``"8bit"`` matching
        ``run_target.sh``.
    device_map:
        Forwarded to ``from_pretrained``. Default ``"auto"``.
    server_name:
        Profile/reference cache key. Must match the ``server_name`` you use
        on the draft side (see ``Autodraft(server_name=...)``).
    hf_token:
        HF access token for gated repos. ``None`` falls back to ``HF_TOKEN``
        / ``HUGGING_FACE_HUB_TOKEN`` env vars. Treat as a secret.
    eager_load:
        If True, load the model at startup; else defer until the first init
        RPC arrives.
    """

    if not isinstance(target_model, str) or not target_model:
        raise ValueError("target_model must be a non-empty string")
    if not isinstance(port, int) or isinstance(port, bool):
        raise ValueError("port must be int")
    if quantization not in _VALID_QUANTIZATIONS:
        raise ValueError(
            f"quantization must be one of {sorted(_VALID_QUANTIZATIONS)}; got {quantization!r}"
        )

    # Set HF env vars BEFORE the lazy runtime import. huggingface_hub reads
    # them at import time, and the target runtime resolves
    # ``from_pretrained(token=...)`` from os.environ.
    _apply_hf_token(hf_token)
    _ensure_data_dir()

    serve, set_seed = _import_runtime()

    if seed is not None:
        set_seed(int(seed))

    load_in_8bit = quantization == "8bit"
    load_in_4bit = quantization == "4bit"

    # serve() reads many additional fields off the args Namespace via getattr
    # (server_name, enable_auto_target_profile, enable_auto_server_draft_profile,
    # base_model_path, temperature, quantization, load_in_8bit, load_in_4bit,
    # enable_gpu_monitor, gpu_monitor_interval, fix_gpu_clock, graphics_clock,
    # memory_clock, device_map, seed, deterministic, debug). Build a Namespace
    # that covers all of them.
    args_ns = argparse.Namespace(
        host=host,
        port=port,
        base_model_path=target_model,
        temperature=temperature,
        load_in_8bit=load_in_8bit,
        load_in_4bit=load_in_4bit,
        int8_cpu_offload=int8_cpu_offload,
        device_map=device_map,
        enable_gpu_monitor=enable_gpu_monitor,
        gpu_monitor_interval=gpu_monitor_interval,
        output_file=output_file,
        fix_gpu_clock=fix_gpu_clock,
        graphics_clock=graphics_clock,
        memory_clock=memory_clock,
        debug=debug,
        seed=seed,
        deterministic=deterministic,
        draft_model_path=draft_model,
        eager_load=eager_load,
        server_name=server_name,
        enable_auto_target_profile=enable_auto_target_profile,
        enable_auto_server_draft_profile=enable_auto_server_draft_profile,
        quantization=quantization,
    )
    # Allow callers to inject additional Namespace fields via **kwargs without
    # forcing us to enumerate every future flag.
    for k, v in kwargs.items():
        setattr(args_ns, k, v)

    serve(
        host,
        port,
        target_model,
        temperature,
        quantization,
        int8_cpu_offload,
        device_map,
        enable_gpu_monitor,
        gpu_monitor_interval,
        output_file,
        fix_gpu_clock,
        graphics_clock,
        memory_clock,
        args=args_ns,
        debug=debug,
        draft_model_path=draft_model,
        preload_model_on_start=bool(eager_load),
    )
