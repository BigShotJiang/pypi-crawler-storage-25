"""In-process wrapper around the MobiTree draft runtime.

The chat UI (``chat_ui/mobitree_service.py``) drives the same flow by
subprocessing ``python -m evaluation.eval_opt_classic_draft`` with a one-line
mt_bench JSONL question file and reading the resulting answer file. We follow
that pattern here, but call ``run_draft`` directly in-process instead of
spawning a subprocess.

Notes:
- ``evaluation`` and ``opt_classic`` are NOT shipped inside the ``autodraft``
  wheel. ``run_local`` therefore only works from a source checkout. Standalone
  PyPI installs raise :class:`LocalRuntimeUnavailableError`.
- ``run_draft`` opens a socket to ``target_host:target_port`` and a target
  server (started via ``./run_target.sh``) must be reachable there before
  this function can produce output. That is architectural; we do not hide it.
"""

from __future__ import annotations

import inspect
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from .errors import LocalRuntimeUnavailableError


def _import_runtime():
    """Lazy-import the heavy MobiTree draft runtime."""
    try:
        from evaluation.eval_opt_classic_draft import run_draft, set_seed  # type: ignore
    except ImportError as exc:
        raise LocalRuntimeUnavailableError(
            "autodraft.local_runner could not import the MobiTree draft "
            "runtime (evaluation/eval_opt_classic_draft.py). The wheel ships "
            "the runtime, so this usually means the heavy dependencies "
            "(torch, transformers, fastchat, shortuuid, tqdm, accelerate) "
            "are not installed in this environment. Install with "
            "`pip install autodraft-sd` (or `pip install -e .` from a "
            "source checkout) and make sure your PyTorch wheel matches "
            "your CUDA version. engine.run also needs a reachable target "
            "server (start one via examples/target.py or autodraft.serve_target)."
        ) from exc
    return run_draft, set_seed


# UI ↔ run_draft flag translation. The chat UI's algorithm dropdown
# (``MobiTree`` / ``Server-Only`` / ``Server-Only-AR`` / ``OPT-Tree`` /
# ``Fixed-tree``) is a higher-level concept than ``run_draft``'s flags, so
# we translate it here the same way ``chat_ui/mobitree_service.py:_build_base_command``
# does.
def _algorithm_overlay(algorithm: str) -> Dict[str, Any]:
    algo = (algorithm or "MobiTree").strip()
    overlay: Dict[str, Any] = {}
    if algo == "Server-Only":
        overlay.update(force_server_only=True)
    elif algo == "Server-Only-AR":
        overlay.update(
            force_server_only=True,
            nodes=1,
            max_depth=1,
            fixed_width=True,
            fixed_width_value=1,
            fixed_nnodes=True,
            fixed_depth=True,
        )
    elif algo == "OPT-Tree":
        overlay.update(opt_tree=True, disable_server_only=True)
    elif algo == "Fixed-tree":
        overlay.update(
            fixed_depth=True,
            fixed_nnodes=True,
            fixed_width=True,
            disable_server_only=True,
        )
    else:
        # MobiTree (default)
        overlay.update(disable_server_only=True)
    return overlay


def _normalize_quantization(value: Optional[str]) -> str:
    return (value or "none").lower()


def _write_question_file(path: Path, input_text: str) -> None:
    """Serialize a single user prompt as one-line mt_bench JSONL."""
    record = {
        "question_id": 1,
        "category": "autodraft",
        "turns": [input_text],
    }
    path.write_text(json.dumps(record, ensure_ascii=False) + "\n", encoding="utf-8")


def _parse_answer_file(path: Path) -> Optional[str]:
    """Read the last JSONL row produced by run_draft and return the final
    turn's text. Mirrors ``chat_ui/mobitree_service.py:_parse_answer_file``.

    Used as a fallback if the integrated results file (see
    ``_parse_integrated_result``) is not present.
    """
    if not path.exists():
        return None
    try:
        lines = path.read_text(encoding="utf-8").strip().splitlines()
        if not lines:
            return None
        row = json.loads(lines[-1])
        choices = row.get("choices") or []
        if not choices:
            return None
        turns = choices[0].get("turns") or []
        if not turns:
            return None
        return str(turns[-1]).strip()
    except (OSError, ValueError, KeyError):
        return None


def _find_integrated_result_file(tmpdir: Path, answer_file: Path) -> Optional[Path]:
    """Locate the ``{basename}_results_{timestamp}.json`` file run_draft writes.

    ``run_draft`` ignores the literal ``answer_file`` path and instead writes
    its output to ``<answer_file_stem>_results_<timestamp>.json`` in the same
    directory (see eval_opt_classic_draft.py around line 8665). We pick the
    most recent matching file and exclude the ``_trimmed`` companion.
    """
    stem = answer_file.stem  # e.g. "answer"
    candidates = sorted(
        (p for p in tmpdir.glob(f"{stem}_results_*.json") if not p.stem.endswith("_trimmed")),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def _parse_integrated_result(path: Path) -> Optional[Dict[str, Any]]:
    """Parse the top-level integrated result file run_draft produces.

    Returns a dict ``{generated_text, answer_row, raw}`` if the answer can
    be extracted; ``None`` otherwise. The integrated format is::

        {
          ...,
          "answers": [
            {"question_id": ..., "choices": [{"turns": [...], ...}], ...}
          ]
        }
    """
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    answers = raw.get("answers") or []
    if not answers:
        return None
    answer_row = answers[-1]
    choices = answer_row.get("choices") or []
    if not choices:
        return None
    turns = choices[0].get("turns") or []
    if not turns:
        return None
    return {
        "generated_text": str(turns[-1]).strip(),
        "answer_row": answer_row,
        "raw": raw,
    }


def _apply_hf_token(hf_token: Optional[str]) -> None:
    """Export the user-supplied HF access token via env vars.

    The MobiTree draft runtime calls ``from_pretrained`` with
    ``token=os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")``,
    so setting either of those env vars before the runtime is imported is
    sufficient. We set both for compatibility (the official name is
    ``HF_TOKEN``; ``HUGGING_FACE_HUB_TOKEN`` is the legacy alias still read
    by huggingface_hub).
    """
    effective = hf_token or os.environ.get("HF_TOKEN") or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    if effective:
        os.environ["HF_TOKEN"] = effective
        os.environ["HUGGING_FACE_HUB_TOKEN"] = effective


def _resolve_device_name() -> str:
    """Pick a stable identifier for the local GPU, mirroring
    ``chat_ui/mobitree_service.py:_resolve_device_name``.

    Why this matters: profile cache filenames embed the device name, so
    different GPUs get different cache slots (a Llama-2-7B latency profile
    for an RTX 5080 isn't reusable on a Tesla V100). When ``device_name``
    is falsy, the runtime's profile-load path early-returns and **no
    auto-profiling happens**, which is exactly the symptom we want to fix
    here.

    Resolution order:
    1. ``MOBITREE_DEVICE_NAME`` env var (lets users pin their own label)
    2. ``torch.cuda.get_device_name(0)`` (auto-detect)
    3. ``"unknown-gpu"`` (always non-empty so the profile path runs)
    """
    configured = os.environ.get("MOBITREE_DEVICE_NAME", "").strip()
    if configured:
        return configured
    try:
        import torch  # lazy: keep autodraft import-light
        if torch.cuda.is_available() and torch.cuda.device_count() > 0:
            name = str(torch.cuda.get_device_name(0)).strip()
            if name:
                return name
    except Exception:
        pass
    return "unknown-gpu"


def _ensure_data_dir() -> None:
    """Pick a writable location for the runtime's profile/reference caches.

    The runtime resolves ``data/profile`` and ``data/reference`` relative
    to its own ``parent_dir``. After ``pip install autodraft-sd`` that
    resolves to ``site-packages/data`` which is awkward (sometimes
    read-only, pollutes the install tree). Default to ``./data`` so the
    cache lives next to wherever the user launched their script — that
    matches the source-checkout behavior (where users run from the repo
    root and the runtime writes to ``<repo>/data``) and gives PyPI users a
    visible, project-local cache. Honor ``MOBITREE_DATA_DIR`` if the user
    wants a fixed location.
    """
    if not os.environ.get("MOBITREE_DATA_DIR"):
        os.environ["MOBITREE_DATA_DIR"] = str(Path.cwd() / "data")
    root = Path(os.environ["MOBITREE_DATA_DIR"])
    root.mkdir(parents=True, exist_ok=True)
    for sub in ("profile", "reference"):
        (root / sub).mkdir(parents=True, exist_ok=True)


def run_local(
    draft_model: str,
    target_model: str,
    draft_quantization: Optional[str],
    target_quantization: Optional[str],
    input_text: str,
    proactive: bool = False,
    cs: Any = None,
    target_host: str = "127.0.0.1",
    target_port: int = 26001,
    hf_token: Optional[str] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    """Run a single-prompt MobiTree decode and return the generated text.

    Internally this writes ``input_text`` to a temporary one-line mt_bench
    JSONL file, calls ``evaluation.eval_opt_classic_draft.run_draft``
    in-process (the same function the chat UI subprocesses), and parses the
    answer file the script writes. ``run_draft`` requires a target server to
    be reachable at ``target_host:target_port`` — start it with
    ``./run_target.sh`` first.

    The ``algorithm`` keyword argument selects between MobiTree variants
    (``"MobiTree"`` (default), ``"Server-Only"``, ``"Server-Only-AR"``,
    ``"OPT-Tree"``, ``"Fixed-tree"``) and is translated into ``run_draft``'s
    low-level flags. Any other ``**kwargs`` is forwarded to ``run_draft``
    directly; unknown keys are silently dropped (logged) so this wrapper
    keeps working when ``run_draft`` adds or renames parameters.
    """

    if not isinstance(input_text, str) or not input_text:
        raise ValueError("input_text must be a non-empty string")

    # Set HF env vars BEFORE the lazy runtime import. huggingface_hub reads
    # these at import time, and the draft runtime resolves its
    # ``from_pretrained(token=...)`` argument from os.environ at call time.
    _apply_hf_token(hf_token)
    _ensure_data_dir()

    run_draft, set_seed = _import_runtime()

    algorithm = kwargs.pop("algorithm", "MobiTree")
    seed = kwargs.pop("seed", 4)
    set_seed(int(seed))

    # Curated overlay: only the values where the chat UI intentionally
    # diverges from run_draft's own defaults. Everything else is left to
    # run_draft to default.
    overlay: Dict[str, Any] = dict(
        host=target_host,
        port=target_port,
        base_model_path=target_model,
        draft_model_path=draft_model,
        bench_name="mt_bench",
        limit=1,
        num_choices=1,
        temperature=0.0,
        nodes=150,
        max_depth=15,
        device_map=os.getenv("MOBITREE_DEVICE_MAP", "cuda:0"),
        # device_name is required: when it's falsy, the runtime's profile-load
        # path early-returns and auto-profiling never runs.
        device_name=_resolve_device_name(),
        load_in_4bit=(_normalize_quantization(draft_quantization) == "4bit"),
        load_in_8bit=(_normalize_quantization(draft_quantization) == "8bit"),
        target_quantization=_normalize_quantization(target_quantization),
        draft_per_hour_cost=0.152,
        target_per_hour_cost=1.208,
        user_communication_cost_per_gb=2.3333333333,
        accept_length_margin=0.05,
        objective_metric="total_cost",
        objective_selection_mode="blend",
        constraint_target="metric",
        cost_sensitivity=15.0 if cs is None else float(cs),
        online_profile_update=True,
        online_profile_lr=0.05,
        enable_gpu_monitor=True,
    )
    overlay.update(_algorithm_overlay(algorithm))
    if proactive:
        overlay.update(
            proactive_drafting=True,
            adaptive_proactive_threshold=True,
            proactive_threshold=0.0,
        )
    overlay.update(kwargs)

    # ``run_draft`` is a fixed-arg function (no **kwargs sink today). Filter
    # the overlay to parameters it actually accepts so we never hit "got
    # unexpected keyword argument" if the wrapper drifts ahead of the
    # runtime. If a future ``run_draft`` adds a **kwargs sink, accept
    # everything.
    sig = inspect.signature(run_draft)
    has_var_keyword = any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()
    )
    if has_var_keyword:
        filtered = dict(overlay)
        dropped: list = []
    else:
        accepted = {
            name for name, p in sig.parameters.items()
            if p.kind is not inspect.Parameter.VAR_POSITIONAL
        }
        filtered = {k: v for k, v in overlay.items() if k in accepted}
        dropped = sorted(set(overlay) - accepted)
    if dropped:
        print(f"[autodraft] dropping unknown run_draft kwargs: {dropped}")

    with tempfile.TemporaryDirectory(prefix="autodraft-") as tmpdir:
        tmp = Path(tmpdir)
        question_file = tmp / "question.jsonl"
        answer_file = tmp / "answer.jsonl"
        _write_question_file(question_file, input_text)
        filtered.setdefault("question_file", str(question_file))
        filtered.setdefault("answer_file", str(answer_file))

        run_draft(**filtered)

        # ``run_draft`` writes the actual answers to a sibling file named
        # ``{stem}_results_{timestamp}.json`` rather than to ``answer_file``
        # itself. Look for that integrated file first; fall back to the
        # JSONL parser in case a future run_draft starts writing to
        # answer_file directly.
        generated_text: Optional[str] = None
        answer_row: Optional[Dict[str, Any]] = None
        raw_result: Optional[Dict[str, Any]] = None

        integrated_path = _find_integrated_result_file(tmp, answer_file)
        if integrated_path is not None:
            parsed = _parse_integrated_result(integrated_path)
            if parsed is not None:
                generated_text = parsed["generated_text"]
                answer_row = parsed["answer_row"]
                raw_result = parsed["raw"]

        if generated_text is None:
            # Fallback: maybe a future run_draft writes JSONL to answer_file.
            generated_text = _parse_answer_file(answer_file)

    return {
        "generated_text": generated_text,
        "input_text": input_text,
        "proactive": bool(proactive),
        "cs": cs,
        "algorithm": algorithm,
        "answer_row": answer_row,
        "raw_result": raw_result,
    }
