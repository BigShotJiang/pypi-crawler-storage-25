import pytest

from autodraft import Autodraft
from autodraft.errors import (
    InvalidAutodraftConfigError,
    RemoteTargetConnectionError,
)


def test_default_construction_ok():
    engine = Autodraft(
        draft_model="draft-id",
        target_model="target-id",
    )
    assert engine.config.draft_model == "draft-id"
    assert engine.config.target_model == "target-id"
    assert engine.config.target_host == "127.0.0.1"
    assert engine.config.target_port == 26001


def test_explicit_target_host_and_port():
    engine = Autodraft(
        draft_model="draft-id",
        target_model="target-id",
        target_host="10.0.0.1",
        target_port=26010,
    )
    assert engine.config.target_host == "10.0.0.1"
    assert engine.config.target_port == 26010


def test_target_port_must_be_int():
    with pytest.raises(InvalidAutodraftConfigError):
        Autodraft(
            draft_model="draft-id",
            target_model="target-id",
            target_port="26001",  # type: ignore[arg-type]
        )


def test_target_host_cannot_be_empty():
    with pytest.raises(InvalidAutodraftConfigError):
        Autodraft(
            draft_model="draft-id",
            target_model="target-id",
            target_host="",
        )


def test_empty_draft_model_rejected():
    with pytest.raises(InvalidAutodraftConfigError):
        Autodraft(draft_model="", target_model="target-id")


def test_empty_target_model_rejected():
    with pytest.raises(InvalidAutodraftConfigError):
        Autodraft(draft_model="draft-id", target_model="")


def test_empty_input_text_rejected():
    engine = Autodraft(draft_model="d", target_model="t")
    with pytest.raises(ValueError):
        engine.run("")


def test_extra_kwargs_preserved():
    engine = Autodraft(
        draft_model="d",
        target_model="t",
        nodes=42,
        max_depth=8,
    )
    assert engine.extra_kwargs == {"nodes": 42, "max_depth": 8}


def test_remote_client_wraps_connection_refused():
    """Hitting a closed port should produce RemoteTargetConnectionError."""
    from autodraft.remote_client import request_remote_target

    # Port 1 is reserved/unused on virtually all systems → connection refused.
    with pytest.raises(RemoteTargetConnectionError):
        request_remote_target("127.0.0.1", 1, {"type": "ping"}, timeout=1.0)


def test_remote_client_validates_host():
    from autodraft.remote_client import request_remote_target

    with pytest.raises(RemoteTargetConnectionError):
        request_remote_target("", 26001, {"type": "ping"}, timeout=1.0)


def test_hf_token_stored_and_masked_in_repr():
    engine = Autodraft(
        draft_model="d",
        target_model="t",
        hf_token="hf_secret_xyz",
    )
    assert engine.config.hf_token == "hf_secret_xyz"
    rendered = repr(engine)
    assert "hf_secret_xyz" not in rendered
    assert "hf_token='***'" in rendered


def test_hf_token_none_renders_as_none_in_repr():
    engine = Autodraft(draft_model="d", target_model="t")
    assert engine.config.hf_token is None
    assert "hf_token=None" in repr(engine)


def test_hf_token_must_be_string_or_none():
    with pytest.raises(InvalidAutodraftConfigError):
        Autodraft(draft_model="d", target_model="t", hf_token=12345)  # type: ignore[arg-type]


def test_repr_does_not_mention_remote():
    """``remote`` was removed from the API; repr must not mention it."""
    engine = Autodraft(draft_model="d", target_model="t")
    assert "remote" not in repr(engine)
