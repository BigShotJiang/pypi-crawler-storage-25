from __future__ import annotations

import contextlib
import concurrent.futures
import csv
import dataclasses
import io
import json
import os
import re
import shlex
import signal
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Dict
from urllib.parse import parse_qsl, quote, urlencode, urlparse

from . import csv as _csv_commands
from deepline_core.enrich import (
    completed_rows_from_wait,
    compute_poll_timeout_s,
    failure_like_jobs_from_wait,
    summarize_wait_outcome,
)
from deepline_core.commands.retry_policy import RATE_LIMIT_MAX_RETRIES, RETRY_BACKOFF_MS
from deepline_core.command_decorators import OptionSpec, SubcommandRouter
from deepline_core.command_common import expand_cli_at_file_path as _expand_cli_at_file_path
from deepline_core.command_common import log as _log
from deepline_core.command_common import print_lines as _print_lines
from deepline_core.command_common import read_cli_text_input as _read_cli_text_input
from deepline_core.command_common import require_api_key as _require_api_key
from deepline_core.command_common import usage_enrich as _usage_enrich
from deepline_core.command_common import EXIT_NETWORK, EXIT_OK, EXIT_SERVER, EXIT_USAGE, EXIT_VALIDATION
from deepline_core import dataset as _dataset
from deepline_core.browser import open_url_in_browser
from deepline_core.http import build_tool_execute_url, build_tool_get_url, http_request
from deepline_core.local_tools import (
    evaluate_extract_javascript,
)
from deepline_core.playground_helpers import compact_text as _compact_text
from deepline_core.playground_helpers import env_dir as _env_dir
from deepline_core.playground_helpers import ensure_local_playground_backend as _ensure_local_playground_backend
from deepline_core.playground_helpers import playground_api_request as _playground_api_request
from deepline_core.playground_helpers import playground_api_request_with_headers as _playground_api_request_with_headers
from deepline_core.playground_helpers import playground_default_api as _playground_default_api
from deepline_core.playground_helpers import playground_read_state as _playground_read_state
from deepline_core.playground_helpers import playground_write_state as _playground_write_state
from deepline_core.playground_helpers import render_ascii as _render_ascii
from deepline_core.tool_helpers import is_local_tool as _is_local_tool
from deepline_core.tool_helpers import normalize_tool_id as _normalize_tool_id

router = SubcommandRouter()
_ENRICH_DEBUG_T0 = time.time()
_COMPACT_TOOL_LIST_HEADERS: Dict[str, str] = {"X-Deepline-Tool-Resolve": "1"}
_META_ONLY_TOOL_HEADERS: Dict[str, str] = {"X-Deepline-Tool-Meta-Only": "1"}
_RATE_LIMIT_MARKER = "__DEEPLINE_RATE_LIMIT__"
_ENRICH_META_PREFIXES: tuple[str, ...] = _dataset.METADATA_PREFIXES
_write_csv = _dataset.write_csv_rows
_PLAY_DERIVED_INTERPOLATION_ALIASES: set[str] = set()
_PERSISTENT_DATA_DIR = Path("deepline") / "data"


def _run_enrich_background_task(
    env: Dict[str, str],
    label: str,
    task: Callable[[], None],
) -> None:
    def _runner() -> None:
        try:
            task()
        except Exception:
            _enrich_debug(env, f"{label} async dispatch failed")

    thread = threading.Thread(target=_runner, name=f"deepline-enrich-{label}", daemon=True)
    thread.start()


def _enrich_debug_enabled(env: Dict[str, str]) -> bool:
    raw = str(env.get("DEEPLINE_DEBUG_ENRICH") or os.environ.get("DEEPLINE_DEBUG_ENRICH") or "").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    node_env = str(env.get("NODE_ENV") or os.environ.get("NODE_ENV") or "").strip().lower()
    deepline_env = str(env.get("DEEPLINE_ENV") or os.environ.get("DEEPLINE_ENV") or "").strip().lower()
    return node_env == "development" or deepline_env in {"dev", "development"}


def _enrich_debug(env: Dict[str, str], message: str) -> None:
    if not _enrich_debug_enabled(env):
        return
    now = time.time()
    ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(now))
    frac = int((now % 1) * 1000)
    elapsed_ms = int((now - _ENRICH_DEBUG_T0) * 1000)
    print(f"[deepline:enrich] {ts}.{frac:03d} +{elapsed_ms}ms {message}", file=sys.stderr, flush=True)


def _release_output_lock(lock_dir: str) -> None:
    if not lock_dir:
        return
    try:
        os.rmdir(lock_dir)
    except Exception:
        pass


def _ensure_persistent_data_dir() -> Path:
    data_dir = _PERSISTENT_DATA_DIR
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def _format_playground_error_detail(resp_body: Any) -> str:
    raw = str(resp_body or "").strip()
    if not raw:
        return ""
    try:
        parsed = json.loads(raw)
    except Exception:
        parsed = None
    detail = ""
    if isinstance(parsed, dict):
        parts: list[str] = []
        for key in ("error", "message", "details"):
            value = parsed.get(key)
            if isinstance(value, str) and value.strip():
                parts.append(f"{key}={value.strip()}")
        issues = parsed.get("issues")
        if isinstance(issues, list):
            rendered_issues: list[str] = []
            for issue in issues[:3]:
                if not isinstance(issue, dict):
                    continue
                path = str(issue.get("path") or "").strip()
                message = str(issue.get("message") or "").strip()
                if path and message:
                    rendered_issues.append(f"{path}: {message}")
                elif message:
                    rendered_issues.append(message)
            if rendered_issues:
                parts.append(f"issues={'; '.join(rendered_issues)}")
        if parts:
            detail = " | ".join(parts)
        else:
            detail = json.dumps(parsed, ensure_ascii=False, separators=(",", ":"))
    else:
        detail = raw
    return re.sub(r"\s+", " ", detail).strip()


def _parse_positive_float(value: Any) -> float | None:
    if isinstance(value, (int, float)) and value >= 0:
        return float(value)
    if isinstance(value, str):
        try:
            parsed = float(value.strip())
        except Exception:
            return None
        return parsed if parsed >= 0 else None
    return None


def _get_positive_int_env(
    env: Dict[str, str],
    key: str,
    default: int,
) -> int:
    raw = str(env.get(key) or os.environ.get(key) or "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except Exception:
        return default
    return value if value > 0 else default


def _parse_rate_limit_meta(payload: Any) -> dict[str, Any] | None:
    if isinstance(payload, str):
        text = payload.strip()
        if text.startswith(_RATE_LIMIT_MARKER):
            encoded = text[len(_RATE_LIMIT_MARKER):].strip()
            if not encoded:
                return None
            try:
                parsed = json.loads(encoded)
            except Exception:
                return None
            return _parse_rate_limit_meta(parsed)
        return None
    if not isinstance(payload, dict):
        return None

    retry_after_seconds = _parse_positive_float(payload.get("retry_after_seconds"))
    retry_after_ms = _parse_positive_float(payload.get("retry_after_ms"))
    rule = str(
        payload.get("rate_limit_rule_id") or payload.get("rate_limit_rule") or ""
    ).strip()
    bucket_scope = str(payload.get("rate_limit_bucket_scope") or "").strip()
    bucket_id = str(payload.get("rate_limit_bucket_id") or payload.get("rate_limit_bucket") or "").strip()
    code = str(payload.get("code") or payload.get("error_code") or "").strip()
    provider = str(payload.get("provider") or "").strip()
    operation = str(payload.get("operation") or "").strip()

    if isinstance(payload.get("body"), dict):
        nested = _parse_rate_limit_meta(payload.get("body"))
        if nested:
            return nested

    for key in ("error", "detail"):
        if isinstance(payload.get(key), dict):
            nested = _parse_rate_limit_meta(payload.get(key))
            if nested:
                return nested

    status = int(payload.get("status") or 0)
    has_rate_limit_marker = bool(
        code.startswith("UPSTREAM_RATE_LIMIT")
        or code == "RATE_LIMIT"
        or status == 429
        or rule
        or bucket_id
    )
    if not has_rate_limit_marker:
        return None

    return {
        "retry_after_ms": int(retry_after_ms * 1000) if retry_after_ms else (int(retry_after_seconds * 1000) if retry_after_seconds else None),
        "code": code or ("UPSTREAM_RATE_LIMIT" if status == 429 else "RATE_LIMIT"),
        "rule_id": rule,
        "bucket_scope": bucket_scope,
        "bucket_id": bucket_id,
        "provider": provider,
        "operation": operation,
    }


def _parse_rate_limit_meta_from_headers(headers: dict[str, str] | None) -> dict[str, Any] | None:
    if not isinstance(headers, dict):
        return None
    retry_after_raw = headers.get("retry-after") or headers.get("Retry-After")
    retry_after_seconds = _parse_positive_float(retry_after_raw)
    has_rate_limit_headers = bool(retry_after_raw)
    if not has_rate_limit_headers:
        for key in headers.keys():
            normalized = str(key or "").strip().lower()
            if normalized.startswith("x-ratelimit-") or normalized.startswith("ratelimit-"):
                has_rate_limit_headers = True
                break
    if not has_rate_limit_headers:
        return None
    return {
        "retry_after_ms": int(retry_after_seconds * 1000) if retry_after_seconds else None,
        "code": "UPSTREAM_RATE_LIMIT",
        "rule_id": "",
        "bucket_scope": "",
        "bucket_id": "",
        "provider": "provider",
        "operation": "",
    }


def _resolve_rate_limit_from_run_block_response(
    response_status: int,
    response_body: str,
    response_headers: dict[str, str] | None,
    wait_jobs: list[dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    body_payload = _safe_json(response_body)
    direct = _parse_rate_limit_meta(body_payload)
    if direct:
        return direct
    if isinstance(wait_jobs, list):
        for job in wait_jobs:
            if not isinstance(job, dict):
                continue
            parsed = _parse_rate_limit_meta(job.get("last_error") or job.get("error"))
            if parsed:
                return parsed
    if response_status == 429:
        from_headers = _parse_rate_limit_meta_from_headers(response_headers)
        if from_headers:
            return from_headers
        return {
            "retry_after_ms": None,
            "code": "UPSTREAM_RATE_LIMIT",
            "rule_id": "",
            "bucket_scope": "",
            "bucket_id": "",
            "provider": "provider",
            "operation": "",
        }
    return _parse_rate_limit_meta_from_headers(response_headers)


def _resolve_run_block_rate_limit_retry(
    response_status: int,
    response_body: str,
    response_headers: dict[str, str] | None,
    wait_jobs: list[dict[str, Any]] | None,
    retry_attempt: int,
    failed_count: int | None = None,
    completed_count: int | None = None,
) -> _RateLimitDecision | None:
    meta = _resolve_rate_limit_from_run_block_response(
        response_status,
        response_body,
        response_headers,
        wait_jobs,
    )
    if not meta:
        return None
    if retry_attempt >= RATE_LIMIT_MAX_RETRIES:
        return None
    if isinstance(failed_count, int) and failed_count <= 0 and response_status < 400:
        return None
    if isinstance(completed_count, int) and completed_count > 0:
        return None
    delay_ms = _resolve_rate_limit_delay_ms(meta, retry_attempt + 1)
    if not isinstance(delay_ms, int) or delay_ms <= 0:
        return None
    source = "wait_jobs" if isinstance(wait_jobs, list) and wait_jobs else "http_response"
    return _RateLimitDecision(meta=meta, delay_ms=delay_ms, source=source)


def _resolve_rate_limit_delay_ms(error_meta: dict[str, Any] | None, attempt: int) -> int | None:
    if attempt <= 0:
        return None
    index = attempt - 1
    retry_after_ms = error_meta.get("retry_after_ms") if error_meta else None
    if isinstance(retry_after_ms, int) and retry_after_ms > 0:
        return retry_after_ms
    if index < len(RETRY_BACKOFF_MS):
        return RETRY_BACKOFF_MS[index]
    return None


def _rate_limit_label(error_meta: dict[str, Any] | None) -> str:
    if not isinstance(error_meta, dict):
        return "Rate limit hit, retrying."
    provider = str(error_meta.get("provider") or "").strip() or "provider"
    rule_id = str(error_meta.get("rule_id") or error_meta.get("bucket_id") or "rate-limit")
    bucket_scope = str(error_meta.get("bucket_scope") or "").strip()
    if bucket_scope:
        return f"Rate limit hit for {provider} ({bucket_scope}), rule {rule_id}, retrying..."
    return f"Rate limit hit for {provider}, rule {rule_id}, retrying..."


def _safe_json(raw: Any) -> Any:
    if not isinstance(raw, str):
        return raw
    try:
        return json.loads(raw)
    except Exception:
        return {}


def _append_startup_diagnostic(
    diagnostics: list[Dict[str, Any]],
    column: str,
    last_error: str,
    row_id: int | None = None,
) -> None:
    diagnostics.append(
        {
            "job_id": f"startup-{len(diagnostics)}",
            "row_id": row_id,
            "col_index": -1,
            "column": column,
            "last_error": _compact_text(str(last_error or "").strip(), 700) or "Unknown startup failure",
        }
    )


def _auto_open_render_requested(env: Dict[str, str]) -> bool:
    headless_env = str(
        env.get("PLAYGROUND_HEADLESS") or os.environ.get("PLAYGROUND_HEADLESS") or ""
    ).strip().lower()
    if headless_env in {"1", "true", "yes"}:
        return False

    # Default enrich behavior to no browser auto-open.
    # Opt in explicitly when needed.
    open_env = str(
        env.get("DEEPLINE_ENRICH_OPEN_PLAYGROUND")
        or os.environ.get("DEEPLINE_ENRICH_OPEN_PLAYGROUND")
        or ""
    ).strip().lower()
    return open_env in {"1", "true", "yes"}


def _ensure_render_ui_for_enrich(
    base_url: str,
    env: Dict[str, str],
    csv_path: str,
) -> list[Dict[str, Any]]:
    # Keep backend/render available and open the CSV-scoped UI when interactive,
    # but never block enrich execution on render startup.
    if str(env.get("DEEPLINE_TEST_API_URL") or os.environ.get("DEEPLINE_TEST_API_URL") or "").strip():
        return []

    startup_diagnostics: list[Dict[str, Any]] = []
    open_render = _auto_open_render_requested(env)
    _enrich_debug(
        env,
        f"ensure_render_ui start base_url={base_url} open_render={open_render} csv_path={csv_path}",
    )
    render_args = ["render", "start"]
    if open_render:
        render_args.append("--open")
    if str(csv_path or "").strip():
        render_args.extend(["--csv", str(csv_path)])
    _enrich_debug(env, f"ensure_render_ui render_args={render_args}")

    def _run() -> tuple[int, int]:
        _enrich_debug(env, "ensure_render_ui invoking backend ensure(auto) and csv render start")
        backend_rc, _ = _ensure_local_playground_backend(base_url, install_mode="auto")
        render_rc = EXIT_OK
        if backend_rc == EXIT_OK:
            def _start_render_async() -> None:
                try:
                    with contextlib.redirect_stdout(io.StringIO()):
                        _csv_commands.handle(base_url, env, render_args)
                except Exception:
                    pass

            threading.Thread(target=_start_render_async, daemon=True).start()
        else:
            render_rc = _csv_commands.handle(base_url, env, render_args)
        _enrich_debug(env, f"ensure_render_ui backend_rc={backend_rc} render_rc={render_rc}")
        return backend_rc, render_rc

    try:
        backend_rc, render_rc = _run()
        if backend_rc != EXIT_OK:
            print("Warning: Unable to ensure playground backend is running.", file=sys.stderr)
            _append_startup_diagnostic(
                startup_diagnostics,
                "playground_backend_start",
                f"Unable to ensure playground backend is running (exit_code={backend_rc})",
            )
        if render_rc != EXIT_OK:
            print("Warning: Unable to start playground render UI automatically.", file=sys.stderr)
            _append_startup_diagnostic(
                startup_diagnostics,
                "playground_render_start",
                f"Unable to start playground render UI automatically (exit_code={render_rc})",
            )
    except Exception:
        print("Warning: Unable to start playground render UI automatically.", file=sys.stderr)
        _append_startup_diagnostic(
            startup_diagnostics,
            "playground_startup_exception",
            "Exception raised while starting playground backend/render UI",
        )
    finally:
        _enrich_debug(env, "ensure_render_ui end")
    return startup_diagnostics


def _normalize_path(path: str) -> str:
    return os.path.abspath(os.path.expanduser(str(path or "")))


def _resolve_playground_link_session_id() -> str:
    from deepline_core.commands.session import _resolve_cli_session_id
    return _resolve_cli_session_id()


def _playground_render_display_url(csv_path: str) -> str | None:
    target_csv = str(csv_path or "").strip()
    if not target_csv:
        return None
    try:
        state = _playground_read_state()
        render_url = str(state.get("render_url") or "").strip()
    except Exception:
        render_url = ""
    if not render_url:
        return None
    base = render_url
    try:
        parsed = urlparse(base)
        query = dict(parse_qsl(parsed.query, keep_blank_values=True))
        query["view"] = "playground"
        query["csv"] = target_csv
        query["session_id"] = _resolve_playground_link_session_id()
        return parsed._replace(query=urlencode(query)).geturl()
    except Exception:
        return base


def _same_file_path(left: str, right: str) -> bool:
    try:
        left_real = os.path.realpath(_normalize_path(left))
    except Exception:
        left_real = _normalize_path(left)
    try:
        right_real = os.path.realpath(_normalize_path(right))
    except Exception:
        right_real = _normalize_path(right)
    return left_real == right_real


def _enrich_dataset_summary_text(csv_path: str, max_row: int) -> str | None:
    api = _playground_default_api()
    s_code, snap_raw = _playground_api_request("GET", api, "/api/snapshot", None, csv_path)
    w_code, win_raw = _playground_api_request(
        "GET",
        api,
        f"/api/window?row_start=0&row_end={max(0, int(max_row))}",
        None,
        csv_path,
    )
    if s_code >= 400 or w_code >= 400:
        return None
    try:
        snapshot = json.loads(snap_raw or "{}")
        window = json.loads(win_raw or "{}")
        return _csv_commands._csv_show_render(snapshot, window, "json", False, True, fallback_row_start=0)
    except Exception:
        return None


def _enrich_preview_rows(csv_path: str, limit: int = 3) -> list[Dict[str, Any]]:
    out: list[Dict[str, Any]] = []
    try:
        with open(csv_path, "r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for idx, row in enumerate(reader):
                if idx >= limit:
                    break
                normalized: Dict[str, Any] = {}
                for key, value in (row or {}).items():
                    key_text = str(key or "")
                    if key_text == "_metadata":
                        continue
                    out_key = key_text
                    k = key_text.strip()
                    if k.startswith("{") and k.endswith("}"):
                        try:
                            parsed = json.loads(k)
                            if isinstance(parsed, dict):
                                name = parsed.get("name")
                                if isinstance(name, str) and name.strip():
                                    out_key = name.strip()
                        except Exception:
                            pass
                    normalized[out_key] = value
                out.append(normalized)
    except Exception:
        return []
    return out


def _read_filtered_headers(path: str) -> list[str]:
    return _dataset.load_csv_for_schema_validation(path)


def _parse_existing_display_name(header_text: str) -> str:
    return _dataset.parse_display_name(header_text)


def _build_waterfall_group_id(name: str) -> str:
    cleaned = _normalize_alias(name)
    if not cleaned:
        cleaned = "group"
    return f"wf_{cleaned}"


def _validate_output_path_available(output_path: str) -> tuple[bool, list[str]]:
    return (
        False,
        [
            f"--output already exists: {output_path}",
            "Use --in-place with --input set to that CSV to continue editing it.",
            "Use a different --output path to create a new derived CSV.",
        ],
    )


def _collect_template_paths(value: Any) -> list[str]:
    paths: list[str] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            for child in node.values():
                walk(child)
            return
        if isinstance(node, list):
            for child in node:
                walk(child)
            return
        if not isinstance(node, str):
            return
        for match in re.finditer(r"\{\{([^{}]+)\}\}", node):
            path = str(match.group(1) or "").strip()
            if path:
                paths.append(path)

    walk(value)
    return paths


def _parse_json_object(raw: Any) -> Dict[str, Any] | None:
    text = str(raw or "").strip()
    if not text or not (text.startswith("{") and text.endswith("}")):
        return None
    try:
        parsed = json.loads(text)
    except Exception:
        return None
    return parsed if isinstance(parsed, dict) else None


def _nested_path_exists(obj: Dict[str, Any], path: list[str]) -> bool:
    cursor: Any = obj
    for segment in path:
        if not isinstance(cursor, dict):
            return False
        next_cursor: Any = None
        found = False
        for candidate_key in ("", "result", "data"):
            candidate = cursor if not candidate_key else cursor.get(candidate_key)
            if not isinstance(candidate, dict) or segment not in candidate:
                continue
            next_cursor = candidate.get(segment)
            found = True
            break
        if not found:
            return False
        cursor = next_cursor
    return True


def _is_templated_string(value: Any) -> bool:
    if not isinstance(value, str):
        return False
    return bool(re.search(r"\{\{[^{}]+\}\}", value))


def _validate_field_type(expected: str, value: Any) -> bool:
    et = expected.strip().lower()
    if et in {"string", "text"}:
        return isinstance(value, str)
    if et in {"integer", "int"}:
        return isinstance(value, int) and not isinstance(value, bool)
    if et in {"number", "float", "double"}:
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if et in {"boolean", "bool"}:
        return isinstance(value, bool)
    if et in {"array", "list"}:
        return isinstance(value, list)
    if et in {"object", "dict", "map"}:
        return isinstance(value, dict)
    return True


def _is_known_interpolation_base(
    base: str,
    *,
    known_aliases: set[str],
    waterfall_aliases: set[str],
    prior_spec_aliases: set[str],
) -> bool:
    return (
        base in known_aliases
        or base in waterfall_aliases
        or base in prior_spec_aliases
    )


def _schema_fields_for_tool(base_url: str, env: Dict[str, str], tool_id: str, cache: Dict[str, list[Dict[str, Any]]]) -> list[Dict[str, Any]]:
    key = str(tool_id or "").strip()
    if key in cache:
        return cache[key]
    if key == "run_javascript":
        cache[key] = [{"name": "code", "type": "string"}]
        return cache[key]
    if _is_local_tool(key):
        cache[key] = []
        return []
    status, meta_body = http_request(
        "GET",
        build_tool_get_url(base_url, key),
        env.get("DEEPLINE_API_KEY"),
        extra_headers=_META_ONLY_TOOL_HEADERS,
    )
    if status >= 400:
        cache[key] = []
        return []
    try:
        meta = json.loads(meta_body)
    except Exception:
        meta = {}
    schema = (meta.get("input_schema") or meta.get("inputSchema") or {})
    fields = schema.get("fields") or []
    if not isinstance(fields, list):
        fields = []
    cache[key] = [f for f in fields if isinstance(f, dict)]
    return cache[key]


def _validate_specs_preflight(
    base_url: str,
    env: Dict[str, str],
    specs: list[Dict[str, Any]],
    fieldnames: list[str],
    source_rows: list[Dict[str, Any]],
    schema_cache_seed: Dict[str, list[Dict[str, Any]]] | None = None,
) -> tuple[list[str], list[str]]:
    payload_errors: list[str] = []
    interpolation_errors: list[str] = []
    alias_to_header: Dict[str, str] = {}
    for header in fieldnames:
        if not header or header == "_metadata":
            continue
        alias = _normalize_alias(header)
        if alias and alias not in alias_to_header:
            alias_to_header[alias] = header
    known_aliases = set(alias_to_header.keys())
    prior_spec_aliases: set[str] = set()
    waterfall_aliases = {_normalize_alias(str(s.get("group") or "")) for s in specs if str(s.get("group") or "").strip()}
    schema_cache: Dict[str, list[Dict[str, Any]]] = dict(schema_cache_seed or {})

    for spec in specs:
        alias = str(spec.get("column") or "")
        alias_norm = _normalize_alias(alias)
        tool_id = str(spec.get("tool_id") or "")
        payload = spec.get("payload") if isinstance(spec.get("payload"), dict) else {}

        # Payload type checks against tool input schema for explicit non-templated values.
        for field in _schema_fields_for_tool(base_url, env, tool_id, schema_cache):
            name = str(field.get("name") or "").strip()
            if not name or name not in payload:
                continue
            value = payload.get(name)
            if _is_templated_string(value):
                continue
            expected = str(field.get("type") or "").strip()
            if expected and not _validate_field_type(expected, value):
                payload_errors.append(
                    f"{alias} ({tool_id}): {name} expected {expected}, got {type(value).__name__}"
                )

        # Validate interpolation paths resolve to known columns / nested object paths.
        for template_path in _collect_template_paths(payload):
            parts = [p.strip() for p in template_path.split(".") if p.strip()]
            if not parts:
                continue
            base = _normalize_alias(parts[0])
            if not _is_known_interpolation_base(
                base,
                known_aliases=known_aliases,
                waterfall_aliases=waterfall_aliases,
                prior_spec_aliases=prior_spec_aliases,
            ):
                interpolation_errors.append(
                    f"{alias}: '{template_path}' base column '{parts[0]}' not found"
                )
                continue
            if len(parts) <= 1:
                continue
            if base not in alias_to_header:
                continue
            sample_obj: Dict[str, Any] | None = None
            base_header = alias_to_header.get(base, parts[0])
            for row in source_rows:
                candidate = _parse_json_object(row.get(base_header))
                if candidate is not None:
                    sample_obj = candidate
                    break
            if sample_obj is not None and not _nested_path_exists(sample_obj, parts[1:]):
                interpolation_errors.append(
                    f"{alias}: '{template_path}' missing nested path on '{parts[0]}' sample JSON"
                )
        if alias_norm:
            prior_spec_aliases.add(alias_norm)
    return payload_errors, interpolation_errors


def _normalize_provider_payload(tool_id: str, payload: Dict[str, Any], user_payload: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(payload or {})
    tid = str(tool_id or "").strip()
    if tid == "crustdata_companydb_autocomplete":
        field_value = out.get("field")
        if isinstance(field_value, str) and field_value.strip() == "industry":
            out["field"] = "linkedin_industries"
    if tid in {"crustdata_person_enrichment", "crustdata_people_enrich"}:
        if "linkedinProfileUrl" in user_payload and "businessEmail" not in user_payload:
            out.pop("businessEmail", None)
        if "businessEmail" in user_payload and "linkedinProfileUrl" not in user_payload:
            out.pop("linkedinProfileUrl", None)
    return out


def _canonical_tool_ref(tool_ref: str) -> str:
    normalized = _normalize_tool_id(tool_ref)
    lowered = normalized.lower()
    if lowered.startswith("plays/build/"):
        return lowered[len("plays/build/") :]
    if lowered.startswith("plays/"):
        return lowered[len("plays/") :]
    return normalized


def _is_dev_cli_base_url(base_url: str) -> bool:
    parsed = urlparse(str(base_url or "").strip())
    host = str(parsed.hostname or "").strip().lower()
    return host in {"localhost", "127.0.0.1", "0.0.0.0", "::1"}


def _local_tools_catalog(base_url: str = "") -> list[Dict[str, Any]]:
    out = [
        {"toolId": "run_javascript", "provider": "local", "operation": "run_javascript"},
        {"toolId": "call_local_claude_code", "provider": "local", "operation": "call_local_claude_code"},
        {"toolId": "call_local_codex", "provider": "local", "operation": "call_local_codex"},
        {"toolId": "read_file", "provider": "local", "operation": "read_file"},
    ]
    if _is_dev_cli_base_url(base_url):
        return out
    return out


def _resolve_tool_reference(tool_ref: str, tools: list[Dict[str, Any]]) -> Dict[str, Any] | None:
    ref = _canonical_tool_ref(tool_ref)
    if not ref:
        return None

    exact = [t for t in tools if str(t.get("toolId") or "") == ref]
    if exact:
        return exact[0]

    if "." in ref:
        provider_ref, op_ref = ref.split(".", 1)
        provider_ref = provider_ref.strip().lower()
        op_ref = op_ref.strip().lower()
        candidates: list[tuple[int, Dict[str, Any]]] = []
        for tool in tools:
            provider = str(tool.get("provider") or "").lower()
            operation = str(tool.get("operation") or "")
            operation_l = operation.lower()
            tool_id = str(tool.get("toolId") or "").lower()
            op_short = operation_l[len(provider_ref) + 1 :] if operation_l.startswith(f"{provider_ref}_") else operation_l
            if provider != provider_ref:
                continue
            score = 0
            if op_short == op_ref:
                score = 100
            elif operation_l == op_ref:
                score = 90
            elif operation_l.startswith(f"{provider_ref}_{op_ref}"):
                score = 80
            elif tool_id == f"{provider_ref}_{op_ref}":
                score = 70
            elif op_ref in operation_l:
                score = 50
            elif op_ref in tool_id:
                score = 40
            if score > 0:
                candidates.append((score, tool))
        if candidates:
            candidates.sort(key=lambda item: (-item[0], str(item[1].get("toolId") or "")))
            return candidates[0][1]

    fuzzy = [t for t in tools if ref.lower() in str(t.get("toolId") or "").lower()]
    if len(fuzzy) == 1:
        return fuzzy[0]
    if len(fuzzy) > 1:
        fuzzy.sort(key=lambda t: str(t.get("toolId") or ""))
        return fuzzy[0]
    return None


def _resolve_tool_reference_with_fallback(
    base_url: str,
    env: Dict[str, str],
    tool_ref: str,
    tools: list[Dict[str, Any]],
    tool_meta_cache: Dict[str, Dict[str, Any]] | None = None,
) -> tuple[Dict[str, Any] | None, str]:
    resolved = _resolve_tool_reference(tool_ref, tools)
    if isinstance(resolved, dict):
        return resolved, ""

    canonical = _canonical_tool_ref(tool_ref)
    normalized = _normalize_tool_id(canonical)
    if not normalized:
        return None, ""

    status, meta = _get_or_resolve_tool_meta(
        base_url,
        env,
        normalized,
        tool_meta_cache,
        include_samples=False,
    )
    if status != EXIT_OK:
        return None, str(meta.get("message") or "")
    if not isinstance(meta, dict):
        return None, ""

    provider = str(meta.get("provider") or "").strip()
    operation = str(meta.get("operation") or "").strip()
    if not provider and not operation:
        return None, f"Failed to load tool metadata for '{normalized}'."

    return {
        "toolId": normalized,
        "provider": provider,
        "operation": operation or normalized,
    }, ""


def _is_direct_tool_id_ref(tool_ref: str) -> bool:
    canonical = _canonical_tool_ref(tool_ref)
    normalized = _normalize_tool_id(canonical)
    return bool(normalized) and canonical == normalized


def _normalize_extract_js(raw: str) -> str:
    # Shells often escape nested quotes in inline JS getters.
    normalized = str(raw or "")
    normalized = normalized.replace('\\"', '"').replace("\\'", "'")
    return normalized


def _expand_at_file_path(raw_path: str) -> str:
    return _expand_cli_at_file_path(raw_path)


def _load_run_javascript_file_payload(payload: Dict[str, Any], raw_spec: str) -> Dict[str, Any]:
    code = payload.get("code")
    if not isinstance(code, str):
        return payload
    code_ref = code.strip()
    if not code_ref.startswith("@"):
        return payload
    try:
        file_content = _read_cli_text_input(
            code_ref,
            argument_name="run_javascript payload.code",
            strip=False,
        )
    except ValueError as exc:
        raise ValueError(f"{exc} for spec: {raw_spec}") from exc
    resolved = dict(payload)
    resolved["code"] = file_content
    return resolved


def _needs_known_tool_catalog(specs: list[Dict[str, Any]]) -> bool:
    for spec in specs:
        tool_ref = str(spec.get("tool_ref") or spec.get("tool_id") or "").strip()
        if not tool_ref:
            continue
        canonical = _canonical_tool_ref(tool_ref)
        normalized = _normalize_tool_id(canonical)
        if normalized and _is_local_tool(normalized):
            continue
        if _is_direct_tool_id_ref(canonical):
            continue
        return True
    return False


def _parse_with_spec(raw_spec: str) -> Dict[str, Any]:
    raw = str(raw_spec or "").strip()
    if not raw:
        raise ValueError("Invalid --with spec: expected JSON object.")

    try:
        raw = _read_cli_text_input(raw, argument_name="--with")
    except ValueError as exc:
        raise ValueError(str(exc)) from exc

    try:
        parsed = json.loads(raw)
    except Exception as exc:
        extract_js_hint = ""
        if "extract_js" in raw or "\\" in raw:
            extract_js_hint = (
                " Hint: extract_js with regex or special characters? Save to a file and use "
                "\"extract_js\": \"@path/to/file.js\" instead of inline JS."
            )
        hint = (
            "Tip: --with now accepts only JSON object specs, e.g. "
            "--with '{\"alias\":\"email_step\",\"tool\":\"apollo_people_match\",\"payload\":{...},"
            "\"extract_js\":\"extract(\\\"email\\\")\"}'."
            f"{extract_js_hint}"
        )
        if not str(raw_spec or "").strip().startswith("@"):
            hint += " On Windows/PowerShell, prefer --with @path/to/spec.json to avoid shell quoting issues."
        raise ValueError(f"Invalid JSON payload in --with spec: {raw} ({exc})\n{hint}") from exc

    if not isinstance(parsed, dict):
        raise ValueError("Invalid --with spec: expected JSON object.")

    allowed_keys = {"alias", "column", "tool", "tool_ref", "tool_id", "payload", "extract_js", "run_if_js"}
    unknown_keys = sorted(str(key) for key in parsed.keys() if str(key) not in allowed_keys)
    if unknown_keys:
        raise ValueError(
            "Invalid --with spec: unknown key(s): "
            + ", ".join(unknown_keys)
            + ". Allowed keys: alias, tool, payload, extract_js, run_if_js."
        )

    alias = str(parsed.get("alias") or parsed.get("column") or "").strip()
    tool_ref = str(parsed.get("tool") or parsed.get("tool_ref") or parsed.get("tool_id") or "").strip()
    payload = parsed.get("payload")
    extract_js = _normalize_extract_js(str(parsed.get("extract_js") or "").strip())
    run_if_js = str(parsed.get("run_if_js") or "").strip()

    if not alias:
        raise ValueError("Invalid --with spec: alias is required.")
    if not tool_ref:
        raise ValueError("Invalid --with spec: tool is required.")
    if not isinstance(payload, dict):
        raise ValueError("Invalid --with spec: payload must be a JSON object.")

    canonical_tool = _canonical_tool_ref(tool_ref)
    if _normalize_tool_id(canonical_tool) == "run_javascript":
        payload = _load_run_javascript_file_payload(payload, raw_spec)
    return {
        "column": alias,
        "tool_ref": canonical_tool,
        "tool_id": _normalize_tool_id(canonical_tool),
        "payload": payload,
        "extract_js": extract_js,
        "run_if_js": run_if_js,
    }


def _resolve_tool_meta(
    base_url: str,
    env: Dict[str, str],
    tool_id: str,
    *,
    include_samples: bool = True,
) -> tuple[int, Dict[str, Any]]:
    normalized = _normalize_tool_id(_canonical_tool_ref(tool_id))
    if _is_local_tool(normalized):
        schema_fields: list[Dict[str, Any]] = []
        if normalized == "run_javascript":
            schema_fields = [{"name": "code", "type": "string"}]
        return EXIT_OK, {
            "tool_id": normalized,
            "operation": normalized,
            "provider": "local",
            "schema_fields": schema_fields,
            "input_schema": {"fields": schema_fields},
            "list_extractor_paths": [],
            "result_identity_getters": {},
            "sample_response": None,
            "output_schema": None,
            "play_expansion": None,
            "estimated_credits_range": "",
        }
    def _fetch_tool_meta(extra_headers: Dict[str, str] | None) -> tuple[int, Dict[str, Any]]:
        status, meta_body = http_request(
            "GET",
            build_tool_get_url(base_url, normalized),
            env.get("DEEPLINE_API_KEY"),
            extra_headers=extra_headers,
        )
        if status >= 400:
            return EXIT_SERVER, {
                "status": status,
                "message": _parse_tools_get_error_message(status, meta_body, normalized),
            }
        try:
            meta = json.loads(meta_body)
        except Exception:
            meta = {}
        if not isinstance(meta, dict):
            return EXIT_SERVER, {"status": status, "message": f"Tools get returned invalid metadata for {normalized}"}
        return EXIT_OK, meta

    status, meta = _fetch_tool_meta(_META_ONLY_TOOL_HEADERS)
    if status != EXIT_OK:
        return status, meta
    schema = (meta.get("input_schema") or meta.get("inputSchema") or {})
    fields = schema.get("fields") if isinstance(schema, dict) else []
    if not isinstance(fields, list):
        fields = []
    schema_fields = [f for f in fields if isinstance(f, dict)]
    list_extractor_paths = meta.get("list_extractor_paths") or meta.get("listExtractorPaths") or []
    if not isinstance(list_extractor_paths, list):
        list_extractor_paths = []
    list_extractor_paths = [str(entry) for entry in list_extractor_paths if isinstance(entry, str)]
    result_identity_getters = (
        meta.get("result_identity_getters")
        or meta.get("resultIdentityGetters")
        or {}
    )
    if not isinstance(result_identity_getters, dict):
        result_identity_getters = {}
    normalized_result_identity_getters: Dict[str, list[str]] = {}
    for key, value in result_identity_getters.items():
        if not isinstance(key, str):
            continue
        if not isinstance(value, list):
            continue
        normalized_values = [str(entry) for entry in value if isinstance(entry, str)]
        if normalized_values:
            normalized_result_identity_getters[key] = normalized_values
    samples = meta.get("samples") if isinstance(meta.get("samples"), dict) else {}
    response_sample = samples.get("response") if isinstance(samples, dict) else None
    sample_response = response_sample.get("payload") if isinstance(response_sample, dict) else None
    output_schema = meta.get("output_schema") or meta.get("outputSchema")
    if not isinstance(output_schema, dict):
        output_schema = None
    play_expansion = meta.get("play_expansion") or meta.get("playExpansion")
    if not isinstance(play_expansion, dict):
        play_expansion = None
    if include_samples and sample_response is None:
        full_status, full_meta = _fetch_tool_meta(None)
        if full_status == EXIT_OK and isinstance(full_meta, dict):
            meta = full_meta
            samples = meta.get("samples") if isinstance(meta.get("samples"), dict) else {}
            response_sample = samples.get("response") if isinstance(samples, dict) else None
            sample_response = response_sample.get("payload") if isinstance(response_sample, dict) else None
            output_schema = meta.get("output_schema") or meta.get("outputSchema")
            if not isinstance(output_schema, dict):
                output_schema = None
            play_expansion = meta.get("play_expansion") or meta.get("playExpansion")
            if not isinstance(play_expansion, dict):
                play_expansion = None
    estimated_credits_range = str(
        meta.get("estimated_credits_range") or meta.get("estimatedCreditsRange") or ""
    ).strip()
    provider = str(meta.get("provider") or "").strip()
    operation = str(meta.get("operation") or "").strip()
    if not provider and not operation:
        return EXIT_SERVER, {"status": status, "message": f"Tools get failed (unresolved tool metadata) for {normalized}"}
    op = operation or normalized
    return EXIT_OK, {
        "tool_id": normalized,
        "operation": op,
        "provider": provider,
        "schema_fields": schema_fields,
        "input_schema": schema if isinstance(schema, dict) else {},
        "list_extractor_paths": list_extractor_paths,
        "result_identity_getters": normalized_result_identity_getters,
        "sample_response": sample_response,
        "output_schema": output_schema,
        "play_expansion": play_expansion,
        "estimated_credits_range": estimated_credits_range,
    }


def _get_or_resolve_tool_meta(
    base_url: str,
    env: Dict[str, str],
    tool_id: str,
    tool_meta_cache: Dict[str, Dict[str, Any]] | None = None,
    *,
    include_samples: bool = True,
) -> tuple[int, Dict[str, Any]]:
    normalized = _normalize_tool_id(_canonical_tool_ref(tool_id))
    if isinstance(tool_meta_cache, dict):
        cached = tool_meta_cache.get(normalized)
        if isinstance(cached, dict):
            if include_samples or cached.get("sample_response") is not None:
                return EXIT_OK, dict(cached)
    status, meta = _resolve_tool_meta(
        base_url,
        env,
        normalized,
        include_samples=include_samples,
    )
    if status == EXIT_OK and isinstance(meta, dict) and isinstance(tool_meta_cache, dict):
        tool_meta_cache[normalized] = dict(meta)
    return status, meta


def _execute_enrich_tool(
    base_url: str,
    env: Dict[str, str],
    tool_id: str,
    payload: Dict[str, Any],
    telemetry_run_id: str | None = None,
    retry_attempt: int | None = None,
    timeout: int = 20,
    connect_timeout: int | None = None,
) -> tuple[int, Dict[str, Any]]:
    status, meta = _resolve_tool_meta(base_url, env, tool_id)
    if status != EXIT_OK:
        return status, meta if isinstance(meta, dict) else {}

    provider = str(meta.get("provider") or "").strip()
    operation = str(meta.get("operation") or "").strip()
    if not provider or not operation:
        return EXIT_SERVER, {"status": status, "message": f"Tools get failed (unresolved tool metadata) for {tool_id}"}

    execute_payload: Dict[str, Any] = {
        "provider": provider,
        "operation": operation,
        "payload": payload if isinstance(payload, dict) else {},
    }
    if tool_id == "deeplineagent":
        execute_payload["response_mode"] = "stream"
    metadata: Dict[str, Any] = {"inside_enrich": True}
    if telemetry_run_id:
        metadata["parent_run_id"] = telemetry_run_id
    if isinstance(retry_attempt, int) and retry_attempt >= 0:
        metadata["retry_attempt"] = retry_attempt
    if metadata:
        execute_payload["metadata"] = metadata

    response_status, raw_response = http_request(
        "POST",
        build_tool_execute_url(base_url, tool_id),
        env.get("DEEPLINE_API_KEY"),
        execute_payload,
        timeout=timeout,
        connect_timeout=connect_timeout,
    )
    parsed: Dict[str, Any] = {}
    if tool_id == "deeplineagent" and execute_payload.get("response_mode") == "stream":
        stream_result = _parse_deeplineagent_stream_response(raw_response or "")
        if isinstance(stream_result, dict):
            parsed = {
                "status": str(stream_result.get("status") or "completed"),
                "result": stream_result,
            }
    if not parsed:
        try:
            parsed = json.loads(raw_response or "{}")
        except Exception:
            parsed = {}
        if not isinstance(parsed, dict):
            parsed = {}
    return (EXIT_OK if response_status < 400 else EXIT_SERVER), parsed


def _parse_deeplineagent_stream_response(raw_stream: str) -> Dict[str, Any] | None:
    if not isinstance(raw_stream, str) or "data:" not in raw_stream:
        return None

    text_parts: list[str] = []
    finish_reason: str | None = None
    usage: Dict[str, Any] | None = None
    structured_output: Dict[str, Any] | None = None
    model = ""
    total_cost_usd: float | None = None
    json_schema: Dict[str, Any] | None = None
    saw_finish = False

    for block in re.split(r"\r?\n\r?\n", raw_stream):
        data_lines = []
        for line in re.split(r"\r?\n", block):
            if line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
        if not data_lines:
            continue
        data = "\n".join(data_lines).strip()
        if not data or data == "[DONE]":
            continue
        try:
            parsed = json.loads(data)
        except Exception:
            continue
        if not isinstance(parsed, dict):
            continue
        part_type = str(parsed.get("type") or "").strip()
        if part_type == "text-delta":
            delta = parsed.get("delta")
            if isinstance(delta, str):
                text_parts.append(delta)
            continue

        if part_type == "finish":
            saw_finish = True
            raw_finish_reason = parsed.get("finishReason")
            finish_reason = raw_finish_reason if isinstance(raw_finish_reason, str) else None
            metadata = parsed.get("messageMetadata")
            if isinstance(metadata, dict):
                raw_usage = metadata.get("usage")
                if isinstance(raw_usage, dict):
                    usage = {
                        "inputTokens": _parse_nonnegative_int(raw_usage.get("inputTokens")),
                        "outputTokens": _parse_nonnegative_int(raw_usage.get("outputTokens")),
                        "totalTokens": _parse_nonnegative_int(raw_usage.get("totalTokens")),
                    }
                raw_model = metadata.get("model")
                if isinstance(raw_model, str):
                    model = raw_model
                if "totalCostUsd" in metadata:
                    total_cost_usd = _parse_nonnegative_float(metadata.get("totalCostUsd"))
                raw_structured_output = metadata.get("structuredOutput")
                if not isinstance(raw_structured_output, dict):
                    raw_structured_output = metadata.get("structured_output")
                if isinstance(raw_structured_output, dict):
                    structured_output = raw_structured_output

                raw_json_schema = metadata.get("jsonSchema")
                if isinstance(raw_json_schema, dict):
                    json_schema = raw_json_schema

    if not saw_finish:
        return None

    return {
        "status": "completed",
        "result": {
            "text": "".join(text_parts) or (json.dumps(structured_output, ensure_ascii=False) if isinstance(structured_output, dict) else ""),
            **({"object": structured_output} if isinstance(structured_output, dict) else {}),
            "finishReason": finish_reason,
        },
        "usage": usage or {
            "inputTokens": 0,
            "outputTokens": 0,
            "totalTokens": 0,
        },
        **({
            "meta": {
                **({"model": model} if model else {}),
                **({"totalCostUsd": total_cost_usd} if total_cost_usd is not None else {}),
                **({"jsonSchema": json_schema} if isinstance(json_schema, dict) else {}),
            }
        } if model or total_cost_usd is not None or isinstance(json_schema, dict) else {}),
    }


def _parse_nonnegative_int(value: Any) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)) and value >= 0:
        return int(value)
    if isinstance(value, str):
        try:
            parsed = int(float(value.strip()))
        except Exception:
            return 0
        return parsed if parsed >= 0 else 0
    return 0


def _parse_nonnegative_float(value: Any) -> float:
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)) and value >= 0:
        return float(value)
    if isinstance(value, str):
        try:
            parsed = float(value.strip())
        except Exception:
            return 0.0
        return parsed if parsed >= 0 else 0.0
    return 0.0


def _required_schema_fields(input_schema: Dict[str, Any]) -> list[str]:
    fields = input_schema.get("fields") if isinstance(input_schema, dict) else []
    out: list[str] = []
    if not isinstance(fields, list):
        return out
    for field in fields:
        if not isinstance(field, dict):
            continue
        name = str(field.get("name") or "").strip()
        if not name or "." in name:
            continue
        if field.get("required"):
            out.append(name)
    return out


def _array_schema_fields(input_schema: Dict[str, Any]) -> set[str]:
    fields = input_schema.get("fields") if isinstance(input_schema, dict) else []
    out: set[str] = set()
    if not isinstance(fields, list):
        return out
    for field in fields:
        if not isinstance(field, dict):
            continue
        name = str(field.get("name") or "").strip()
        if not name or "." in name:
            continue
        type_text = str(field.get("type") or "").strip().lower()
        dtype_text = str(field.get("dtype") or "").strip().lower()
        if (
            "array" in type_text
            or "[]" in type_text
            or "array" in dtype_text
            or "[]" in dtype_text
        ):
            out.add(name)
    return out


def _coerce_array_field_value(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    trimmed = value.strip()
    if re.fullmatch(r"\{\{[^{}]+\}\}", trimmed):
        return value
    if not trimmed:
        return []
    if trimmed.startswith("[") and trimmed.endswith("]"):
        try:
            parsed = json.loads(trimmed)
        except Exception:
            parsed = None
        if isinstance(parsed, list):
            return parsed
    if trimmed.startswith("[") and trimmed.endswith("]") and "'" in trimmed:
        inner = trimmed[1:-1].strip()
        if not inner:
            return []
        return [
            part.strip().strip("'").strip('"')
            for part in inner.split(",")
            if part.strip().strip("'").strip('"')
        ]
    return [part.strip() for part in trimmed.split(",") if part.strip()]


def _coerce_payload_by_input_schema(payload: Dict[str, Any], input_schema: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    array_fields = _array_schema_fields(input_schema)
    if not array_fields:
        return dict(payload)
    out = dict(payload)
    for field in array_fields:
        if field not in out:
            continue
        out[field] = _coerce_array_field_value(out.get(field))
    return out


def _extract_play_expansion(meta: Dict[str, Any]) -> Dict[str, Any] | None:
    play_expansion = meta.get("play_expansion")
    if not isinstance(play_expansion, dict):
        return None
    mode = str(play_expansion.get("mode") or "").strip()
    group = str(play_expansion.get("group") or "").strip()
    steps = play_expansion.get("steps")
    if mode != "enrich_with_specs" or not group or not isinstance(steps, list):
        return None
    normalized_steps: list[Dict[str, Any]] = []
    for step in steps:
        if not isinstance(step, dict):
            return None
        block_type = str(step.get("type") or "").strip()
        if block_type == "waterfall":
            alias = str(step.get("alias") or "").strip()
            inner_steps = step.get("steps")
            if not alias or not isinstance(inner_steps, list) or not inner_steps:
                return None
            min_results = None
            if step.get("min_results") is not None:
                try:
                    min_results = max(1, int(step.get("min_results") or 1))
                except Exception:
                    min_results = 1
            normalized_inner_steps: list[Dict[str, Any]] = []
            for inner_step in inner_steps:
                if not isinstance(inner_step, dict):
                    return None
                inner_alias = str(inner_step.get("alias") or "").strip()
                inner_tool = str(inner_step.get("tool") or "").strip()
                payload = inner_step.get("payload")
                extract_js = str(inner_step.get("extract_js") or "").strip()
                if not inner_alias or not inner_tool or not isinstance(payload, dict):
                    return None
                normalized_inner_step: Dict[str, Any] = {
                    "alias": inner_alias,
                    "tool": inner_tool,
                    "payload": dict(payload),
                }
                if extract_js:
                    normalized_inner_step["extract_js"] = extract_js
                requires = [
                    str(entry).strip()
                    for entry in (inner_step.get("requires") or [])
                    if str(entry).strip()
                ]
                if requires:
                    normalized_inner_step["requires"] = requires
                normalized_inner_steps.append(normalized_inner_step)
            normalized_block: Dict[str, Any] = {
                "type": "waterfall",
                "alias": alias,
                "steps": normalized_inner_steps,
            }
            if min_results is not None:
                normalized_block["min_results"] = min_results
            normalized_steps.append(normalized_block)
            continue

        if block_type == "step":
            inner_step = step.get("step")
            if not isinstance(inner_step, dict):
                return None
            alias = str(inner_step.get("alias") or "").strip()
            tool = str(inner_step.get("tool") or "").strip()
            payload = inner_step.get("payload")
            if not alias or not tool or not isinstance(payload, dict):
                return None
            normalized_step: Dict[str, Any] = {
                "type": "step",
                "step": {
                    "alias": alias,
                    "tool": tool,
                    "payload": dict(payload),
                },
            }
            requires = [
                str(entry).strip()
                for entry in (inner_step.get("requires") or [])
                if str(entry).strip()
            ]
            if requires:
                normalized_step["step"]["requires"] = requires
            normalized_steps.append(normalized_step)
            continue
        return None
    normalized: Dict[str, Any] = {
        "mode": "enrich_with_specs",
        "group": group,
        "steps": normalized_steps,
    }
    return normalized


def _has_placeholder_source(value: Any) -> bool:
    if isinstance(value, str):
        return bool(re.search(r"\{\{[^{}]+\}\}", value))
    if isinstance(value, list):
        return any(_has_placeholder_source(item) for item in value)
    if isinstance(value, dict):
        return any(_has_placeholder_source(item) for item in value.values())
    return False


def _interpolate_play_value(value: Any, play_payload: Dict[str, Any]) -> tuple[bool, Any]:
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, child in value.items():
            keep, next_value = _interpolate_play_value(child, play_payload)
            if keep:
                out[str(key)] = next_value
        return True, out
    if isinstance(value, list):
        out: list[Any] = []
        for child in value:
            keep, next_value = _interpolate_play_value(child, play_payload)
            if keep:
                out.append(next_value)
        return True, out
    if not isinstance(value, str):
        return True, value

    matches = list(re.finditer(r"\{\{([^{}]+)\}\}", value))
    if not matches:
        return True, value

    if len(matches) == 1 and matches[0].span() == (0, len(value)):
        key = str(matches[0].group(1) or "").strip()
        if key not in play_payload:
            return False, None
        replacement = play_payload.get(key)
        if replacement in (None, ""):
            return False, None
        return True, replacement

    rendered = value
    for match in matches:
        key = str(match.group(1) or "").strip()
        if key not in play_payload:
            rendered = rendered.replace(match.group(0), "")
            continue
        replacement = play_payload.get(key)
        if replacement in (None, ""):
            rendered = rendered.replace(match.group(0), "")
            continue
        rendered = rendered.replace(match.group(0), str(replacement))
    return True, rendered


def _build_play_interpolation_context(
    play_payload: Dict[str, Any],
    root_alias: str,
    template_group: str,
    blocks: list[Dict[str, Any]],
) -> Dict[str, Any]:
    context: Dict[str, Any] = {
        **play_payload,
        "play_alias": root_alias,
        "play_alias_json": json.dumps(root_alias),
    }
    for block in blocks:
        if str(block.get("type") or "").strip() != "waterfall":
            continue
        block_alias = str(block.get("alias") or "").strip()
        if not block_alias:
            continue
        runtime_group = root_alias if block_alias == template_group else f"{root_alias}__{block_alias}"
        context[f"block_alias.{block_alias}"] = runtime_group
        context[f"block_alias_json.{block_alias}"] = json.dumps(runtime_group)
    return context


def _print_play_expansion_preview(expansion_preview: list[Dict[str, Any]]) -> None:
    if not expansion_preview:
        return
    print("Play expansion preview:")
    for play in expansion_preview:
        alias = str(play.get("alias") or "").strip() or "<unnamed>"
        estimated_range = str(play.get("estimated_credits_range") or "").strip()
        play_tool_id = str(play.get("tool_id") or "").strip()
        template_group = str(play.get("template_group") or "").strip()
        summary = f"  - {alias} -> native enrich args"
        if estimated_range:
            summary += f" | estimated {estimated_range}"
        print(summary)
        steps = [step for step in (play.get("steps") or []) if isinstance(step, dict)]

        def _print_with_arg(step: Dict[str, Any]) -> None:
            column = str(step.get("column") or "").strip()
            step_tool = str(step.get("tool") or "").strip()
            payload = step.get("payload") if isinstance(step.get("payload"), dict) else {}
            step_extract_js = str(step.get("extract_js") or "").strip()
            spec_payload: Dict[str, Any] = {
                "alias": column,
                "tool": step_tool,
                "payload": payload,
            }
            if step_extract_js:
                spec_payload["extract_js"] = step_extract_js
            print(f"      --with {shlex.quote(json.dumps(spec_payload, separators=(',', ':')))}")

        grouped_waterfalls: dict[str, list[Dict[str, Any]]] = {}
        for step in steps:
            if str(step.get("block") or "").strip() == "waterfall":
                group = str(step.get("group") or "").strip()
                if group:
                    grouped_waterfalls.setdefault(group, []).append(step)

        inferred_play_waterfall = (
            not grouped_waterfalls
            and bool(steps)
            and any(name.endswith("_waterfall") for name in (play_tool_id, template_group) if name)
        )
        if inferred_play_waterfall:
            grouped_waterfalls[alias] = steps

        if inferred_play_waterfall:
            print(f"      --with-waterfall {alias}")
            min_results = play.get("min_results")
            if isinstance(min_results, int):
                print(f"      --min-results {min_results}")
            for step in steps:
                _print_with_arg(step)
            print("      --end-waterfall")
            continue

        rendered_groups: set[str] = set()
        for step in steps:
            block_type = str(step.get("block") or "").strip()
            if block_type == "waterfall":
                group = str(step.get("group") or "").strip()
                if not group or group in rendered_groups:
                    continue
                rendered_groups.add(group)
                print(f"      --with-waterfall {group}")
                min_results = grouped_waterfalls[group][0].get("waterfall_min_results")
                if isinstance(min_results, int):
                    print(f"      --min-results {min_results}")
                for grouped_step in grouped_waterfalls[group]:
                    _print_with_arg(grouped_step)
                print("      --end-waterfall")
                continue
            _print_with_arg(step)


def _play_expansion_summary_lines(expansion_preview: list[Dict[str, Any]]) -> list[str]:
    lines: list[str] = []
    for play in expansion_preview:
        alias = str(play.get("alias") or "").strip() or "<unnamed>"
        steps = [step for step in (play.get("steps") or []) if isinstance(step, dict)]
        providers: list[str] = []
        seen: set[str] = set()
        for step in steps:
            tool_id = str(step.get("tool") or step.get("tool_id") or "").strip()
            if not tool_id:
                continue
            provider = tool_id.split("_", 1)[0].strip() or tool_id
            if provider not in seen:
                seen.add(provider)
                providers.append(provider)
        if providers:
            lines.append(f'Expanded play "{alias}" into providers: {", ".join(providers)}.')
        else:
            lines.append(f'Expanded play "{alias}" into concrete enrich commands.')
    return lines


def _enrich_rerun_hint(input_path: str, output_path: str, config_path: str, in_place: bool = False) -> str:
    parts = ["deepline", "enrich", "--input", input_path]
    if in_place:
        parts.append("--in-place")
    else:
        parts.extend(["--output", output_path])
    parts.extend(["--config", config_path])
    return " ".join(shlex.quote(part) for part in parts)


def _sanitize_error_message(raw: Any, max_len: int = 240) -> str:
    text = str(raw or "").strip()
    if not text:
        return ""
    compact = re.sub(r"\s+", " ", text).strip()
    if len(compact) <= max_len:
        return compact
    return f"{compact[: max_len - 3]}..."


def _parse_tools_list_error_message(status: int | None, body: str) -> str:
    compact_body = _sanitize_error_message(body)
    parsed: Any = None
    if body:
        try:
            parsed = json.loads(body)
        except Exception:
            parsed = None

    if isinstance(parsed, dict):
        for key in ("message", "error", "detail", "details"):
            value = parsed.get(key)
            msg = _sanitize_error_message(value)
            if msg:
                return msg
    if compact_body:
        return compact_body
    if status in (401, 403):
        return "Auth error while listing tools. Check DEEPLINE_API_KEY."
    if status == 404:
        return "Integrations list endpoint not found."
    if isinstance(status, int):
        return f"Failed to list tools (status {status})."
    return "Failed to list tools."


def _parse_tools_get_error_message(status: int | None, body: str, tool_id: str) -> str:
    compact_body = _sanitize_error_message(body)
    parsed: Any = None
    if body:
        try:
            parsed = json.loads(body)
        except Exception:
            parsed = None

    detail = ""
    if isinstance(parsed, dict):
        for key in ("message", "error", "detail", "details"):
            value = parsed.get(key)
            detail = _sanitize_error_message(value)
            if detail:
                break
    elif compact_body:
        detail = compact_body

    if status == 404:
        generic_detail = detail.lower().rstrip(".") in {"unknown tool", "not found", "tool not found"}
        if generic_detail or not detail:
            return f"Unknown tool '{tool_id}'."
        return detail or f"Unknown tool '{tool_id}'."
    if status in (401, 403):
        if detail:
            return f"Auth error while loading tool metadata for '{tool_id}' (status {status}): {detail}"
        return f"Auth error while loading tool metadata for '{tool_id}' (status {status}). Check DEEPLINE_API_KEY."
    if detail:
        if isinstance(status, int):
            return f"Failed to load tool metadata for '{tool_id}' (status {status}): {detail}"
        return f"Failed to load tool metadata for '{tool_id}': {detail}"
    if isinstance(status, int):
        return f"Failed to load tool metadata for '{tool_id}' (status {status})."
    return f"Failed to load tool metadata for '{tool_id}'."


def _is_transient_tools_list_failure(status: int | None) -> bool:
    if not isinstance(status, int):
        return False
    if status == 429:
        return True
    return 500 <= status <= 599


def _list_known_tools(base_url: str, env: Dict[str, str]) -> Dict[str, Any]:
    max_retries = 1
    retry_attempts = 0
    while True:
        try:
            status, body = http_request(
                "GET",
                f"{base_url}/api/v2/integrations/list",
                env.get("DEEPLINE_API_KEY"),
                extra_headers=_COMPACT_TOOL_LIST_HEADERS,
            )
        except RuntimeError as exc:
            message = _sanitize_error_message(exc)
            if retry_attempts < max_retries:
                retry_attempts += 1
                time.sleep(0.25)
                continue
            return {
                "exit_code": EXIT_NETWORK,
                "tools": [],
                "http_status": None,
                "error_message": message or "Failed to reach API while listing tools.",
                "retry_attempts": retry_attempts,
            }

        if status >= 400:
            message = _parse_tools_list_error_message(status, body)
            if _is_transient_tools_list_failure(status) and retry_attempts < max_retries:
                retry_attempts += 1
                time.sleep(0.25)
                continue
            return {
                "exit_code": EXIT_SERVER,
                "tools": [],
                "http_status": status,
                "error_message": message,
                "retry_attempts": retry_attempts,
            }

        break

    try:
        data = json.loads(body)
    except Exception:
        data = {}
    tools = data.get("tools") if isinstance(data, dict) else []
    out: list[Dict[str, Any]] = []
    seen: set[str] = set()
    if isinstance(tools, list):
        for item in tools:
            if not isinstance(item, dict):
                continue
            tid = _normalize_tool_id(_canonical_tool_ref(str(item.get("toolId") or item.get("tool_id") or "")))
            if not tid or tid in seen:
                continue
            seen.add(tid)
            out.append(
                {
                    "toolId": tid,
                    "provider": str(item.get("provider") or "").strip(),
                    "operation": str(item.get("operation") or "").strip(),
                }
            )
    for item in _local_tools_catalog(base_url):
        tid = _normalize_tool_id(str(item.get("toolId") or ""))
        if not tid or tid in seen:
            continue
        seen.add(tid)
        out.append(dict(item))
    return {
        "exit_code": EXIT_OK,
        "tools": out,
        "http_status": status,
        "error_message": "",
        "retry_attempts": retry_attempts,
    }


def _prefetch_tool_metadata(
    base_url: str,
    env: Dict[str, str],
    specs: list[Dict[str, Any]],
    known_tools: list[Dict[str, Any]],
    tool_meta_cache: Dict[str, Dict[str, Any]],
) -> tuple[int, str]:
    unique_tool_ids: list[str] = []
    seen: set[str] = set()
    for spec in specs:
        tool_ref = str(spec.get("tool_ref") or spec.get("tool_id") or "").strip()
        if not tool_ref:
            continue
        resolved = _resolve_tool_reference(tool_ref, known_tools)
        tool_id = str(resolved.get("toolId") or "").strip() if isinstance(resolved, dict) else ""
        if not tool_id and _is_direct_tool_id_ref(tool_ref):
            tool_id = _normalize_tool_id(_canonical_tool_ref(tool_ref))
        if not tool_id or _is_local_tool(tool_id) or tool_id in tool_meta_cache or tool_id in seen:
            continue
        seen.add(tool_id)
        unique_tool_ids.append(tool_id)

    if len(unique_tool_ids) <= 1:
        return EXIT_OK, ""

    max_workers = min(8, len(unique_tool_ids))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(
                _get_or_resolve_tool_meta,
                base_url,
                env,
                tool_id,
                tool_meta_cache,
                include_samples=False,
            ): tool_id
            for tool_id in unique_tool_ids
        }
        for future in concurrent.futures.as_completed(future_map):
            tool_id = future_map[future]
            try:
                status, meta = future.result()
            except Exception as exc:
                return EXIT_SERVER, f"Failed to resolve tool: {tool_id} ({exc})"
            if status != EXIT_OK:
                return status, str(meta.get("message") or f"Failed to resolve tool: {tool_id}")
    return EXIT_OK, ""


def _load_compacted_csv(path: str) -> tuple[list[str], list[Dict[str, Any]]]:
    return _dataset.load_compacted_csv(path, alias_fn=_normalize_alias, keep_metadata=True)


def _run_columns_in_playground(
    csv_path: str,
    row_start: int,
    row_end: int,
    run_columns: list[Dict[str, Any]],
    force_overwrite: bool,
    telemetry_run_id: str | None = None,
    log_progress: bool = False,
    rate_limit_events: list[Dict[str, Any]] | None = None,
) -> tuple[bool, list[Dict[str, Any]], int]:
    api = _playground_default_api()
    dbg_env = dict(os.environ)
    inline_wait_row_threshold = 25
    _enrich_debug(
        dbg_env,
        (
            f"run_columns_in_playground start csv_path={csv_path} row_start={row_start} "
            f"row_end={row_end} column_count={len(run_columns)} force_overwrite={bool(force_overwrite)} "
            f"api={api}"
        ),
    )
    failed_jobs: list[Dict[str, Any]] = []
    skipped_count = 0
    dataset_stats_text: str | None = None
    dataset_stats: Dict[str, Any] | None = None
    if rate_limit_events is None:
        rate_limit_events = []
    total_queued_all = 0
    total_completed_all = 0
    total_missed_all = 0
    total_skipped_existing_all = 0
    total_skipped_waterfall_all = 0
    had_column_failures = False

    def _record_column_failure(
        job_or_jobs: Dict[str, Any] | list[Dict[str, Any]],
        progress_message: str | None = None,
    ) -> None:
        nonlocal had_column_failures
        if isinstance(job_or_jobs, list):
            for job in job_or_jobs:
                if isinstance(job, dict):
                    failed_jobs.append(job)
        elif isinstance(job_or_jobs, dict):
            failed_jobs.append(job_or_jobs)
        had_column_failures = True
        if log_progress and progress_message:
            print(progress_message)

    def _fatal_column_failure(
        job_or_jobs: Dict[str, Any] | list[Dict[str, Any]],
        progress_message: str | None = None,
    ) -> tuple[bool, list[Dict[str, Any]], int]:
        _record_column_failure(job_or_jobs, progress_message)
        return False, failed_jobs, skipped_count

    def _count_rows(value: Any) -> int:
        if isinstance(value, int):
            return max(0, value)
        if isinstance(value, list):
            return len(value)
        return 0

    def _execute_run_block_request(
        *,
        idx: int,
        col_name: str,
        effective_col_index: int,
        body: Dict[str, Any],
        request_timeout_s: int,
    ) -> tuple[int, str, dict[str, str], Dict[str, Any]]:
        code = 0
        resp_body = ""
        resp_headers: dict[str, str] = {}
        parsed: Dict[str, Any] = {}
        for run_block_attempt in range(RATE_LIMIT_MAX_RETRIES + 1):
            run_block_response = _playground_api_request_with_headers(
                "POST",
                api,
                "/api/run-block",
                body,
                csv_path,
                timeout=request_timeout_s,
            )
            code = run_block_response.status
            resp_body = run_block_response.body
            resp_headers = run_block_response.headers
            if code >= 400 and _is_transient_disconnect_message(resp_body):
                for retry_idx in range(2):
                    _enrich_debug(
                        dbg_env,
                        f"run-block transient error idx={idx} column={col_name} status={code} retry={retry_idx + 1}",
                    )
                    time.sleep(0.35 * float(retry_idx + 1))
                    retry_response = _playground_api_request_with_headers(
                        "POST",
                        api,
                        "/api/run-block",
                        body,
                        csv_path,
                        timeout=request_timeout_s,
                    )
                    code = retry_response.status
                    resp_body = retry_response.body
                    resp_headers = retry_response.headers
                    if code < 400 or not _is_transient_disconnect_message(resp_body):
                        break
            parsed = {}
            try:
                maybe = json.loads(resp_body) if resp_body else {}
                if isinstance(maybe, dict):
                    parsed = maybe
            except Exception:
                parsed = {}
            wait_obj = parsed.get("wait") if isinstance(parsed, dict) else None
            wait_jobs = wait_obj.get("jobs") if isinstance(wait_obj, dict) and isinstance(wait_obj.get("jobs"), list) else None
            failed_status_count = 0
            completed_status_count = 0
            if isinstance(wait_jobs, list):
                for job in wait_jobs:
                    if not isinstance(job, dict):
                        continue
                    status_text = str(job.get("status") or "").strip().lower()
                    if status_text in {"failed", "canceled", "queued", "running"}:
                        failed_status_count += 1
                    elif status_text == "completed":
                        completed_status_count += 1
            rate_limit_retry = _resolve_run_block_rate_limit_retry(
                code,
                resp_body,
                resp_headers,
                wait_jobs,
                run_block_attempt,
                failed_count=failed_status_count,
                completed_count=completed_status_count,
            )
            if not rate_limit_retry:
                break
            if isinstance(rate_limit_events, list) and isinstance(rate_limit_retry.meta, dict):
                rate_limit_events.append(dict(rate_limit_retry.meta))
            if log_progress:
                print(_rate_limit_label(rate_limit_retry.meta))
            _enrich_debug(
                dbg_env,
                f"run-block rate-limit retry idx={idx} column={col_name} source={rate_limit_retry.source} delay_ms={rate_limit_retry.delay_ms} attempt={run_block_attempt + 1}",
            )
            time.sleep(rate_limit_retry.delay_ms / 1000.0)
        return code, resp_body, resp_headers, parsed

    def _poll_run_block_completion(
        *,
        idx: int,
        col_name: str,
        effective_col_index: int,
        run_id: str,
        timeout_s: int,
    ) -> tuple[int, str, dict[str, str], Dict[str, Any]]:
        started_at = time.time()
        deadline = started_at + max(30.0, float(timeout_s))
        next_progress_at = started_at + 5.0
        poll_attempt = 0

        while True:
            status_response = _playground_api_request_with_headers(
                "GET",
                api,
                f"/api/run-status?run_id={quote(run_id, safe='')}",
                None,
                csv_path,
                timeout=15,
            )
            code = status_response.status
            resp_body = status_response.body
            resp_headers = status_response.headers
            parsed: Dict[str, Any] = {}
            try:
                maybe = json.loads(resp_body) if resp_body else {}
                if isinstance(maybe, dict):
                    parsed = maybe
            except Exception:
                parsed = {}

            if code >= 400:
                _enrich_debug(
                    dbg_env,
                    f"run-status error idx={idx} column={col_name} status={code}",
                )
                return code, resp_body, resp_headers, parsed

            wait_obj = parsed.get("wait") if isinstance(parsed, dict) else None
            pending = bool(wait_obj.get("pending")) if isinstance(wait_obj, dict) else False
            summary = parsed.get("summary") if isinstance(parsed, dict) and isinstance(parsed.get("summary"), dict) else {}
            _enrich_debug(
                dbg_env,
                (
                    f"run-status poll idx={idx} column={col_name} pending={pending} "
                    f"completed={int(summary.get('completed_count') or 0)} "
                    f"missed={int(summary.get('missed_count') or 0)} "
                    f"failed={int(summary.get('failed_count') or 0)} "
                    f"pending_count={int(summary.get('pending_count') or 0)} "
                    f"total_jobs={int(summary.get('total_jobs') or 0)}"
                ),
            )
            if not pending:
                return code, resp_body, resp_headers, parsed

            now = time.time()
            if log_progress and now >= next_progress_at:
                if isinstance(summary, dict):
                    print(
                        "  ... Waiting on "
                        + col_name
                        + " (completed="
                        + str(int(summary.get("completed_count") or 0))
                        + ", missed="
                        + str(int(summary.get("missed_count") or 0))
                        + ", pending="
                        + str(int(summary.get("pending_count") or 0))
                        + ", failed="
                        + str(int(summary.get("failed_count") or 0))
                        + ", total_jobs="
                        + str(int(summary.get("total_jobs") or 0))
                        + ")"
                    )
                next_progress_at = now + 5.0

            if now >= deadline:
                timeout_message = (
                    f"Timed out while polling run status for column '{col_name}' "
                    f"(run_id={run_id}, col={effective_col_index})."
                )
                return 599, timeout_message, {}, {
                    "ok": False,
                    "error": timeout_message,
                    "wait": {
                        "pending": True,
                        "missing": [],
                        "jobs": [],
                    },
                    "failed_jobs": [
                        {
                            "job_id": f"run-block-{idx}",
                            "row_id": int(row_start),
                            "col_index": effective_col_index,
                            "column": col_name,
                            "status": "pending",
                            "last_error": timeout_message,
                        }
                    ],
                }

            poll_attempt += 1
            if poll_attempt <= 5:
                poll_interval_s = 0.05
            elif poll_attempt <= 10:
                poll_interval_s = 0.1
            else:
                poll_interval_s = 0.5
            time.sleep(poll_interval_s)

    def _resolve_snapshot_col(target_col: int, column_name: str) -> int:
        _enrich_debug(dbg_env, f"resolve_snapshot_col start column={column_name} target_col={target_col}")
        status, body = _playground_api_request("GET", api, "/api/snapshot", None, csv_path)
        if status >= 400:
            _enrich_debug(dbg_env, f"resolve_snapshot_col snapshot failed status={status} -> using target_col={target_col}")
            return target_col
        try:
            data = json.loads(body) if body else {}
        except Exception:
            data = {}
        columns = data.get("columns") if isinstance(data, dict) else []
        if not isinstance(columns, list):
            _enrich_debug(dbg_env, f"resolve_snapshot_col invalid snapshot columns type -> using target_col={target_col}")
            return target_col
        if 0 <= target_col < len(columns):
            candidate = columns[target_col]
            if isinstance(candidate, dict) and bool(candidate.get("is_block")):
                _enrich_debug(dbg_env, f"resolve_snapshot_col target is block column={column_name} resolved_col={target_col}")
                return target_col
        for col in columns:
            if not isinstance(col, dict):
                continue
            if not bool(col.get("is_block")):
                continue
            idx = col.get("col_index")
            if not isinstance(idx, int) or idx < 0:
                continue
            name = str(col.get("display_name") or col.get("name") or "")
            if name == column_name:
                _enrich_debug(dbg_env, f"resolve_snapshot_col matched by name column={column_name} resolved_col={idx}")
                return idx
        _enrich_debug(dbg_env, f"resolve_snapshot_col fallback column={column_name} resolved_col={target_col}")
        return target_col

    healthy = False
    # Windows may need more time for the Node.js backend to finish binding to
    # the port (race condition with loopback firewall / antivirus scanning).
    max_health_attempts = 12 if sys.platform == "win32" else 4
    health_sleep = 0.5 if sys.platform == "win32" else 0.1
    for attempt in range(max_health_attempts):
        try:
            hs, _ = http_request("GET", f"{api.rstrip('/')}/api/health", None, None, timeout=2)
            if hs == 200:
                healthy = True
                _enrich_debug(dbg_env, f"playground health ok on attempt={attempt + 1}")
                break
            _enrich_debug(dbg_env, f"playground health non-200 status={hs} attempt={attempt + 1}")
        except Exception:
            _enrich_debug(dbg_env, f"playground health request error attempt={attempt + 1}")
        time.sleep(health_sleep)
    if not healthy:
        _enrich_debug(dbg_env, "playground health failed after max attempts")
        if log_progress:
            print("Playground backend is not running. Start it with `deepline backend start` and rerun.")
        return False, failed_jobs, skipped_count

    reload_ok = False
    for attempt in range(20):
        _enrich_debug(dbg_env, f"reload-csv attempt={attempt + 1}")
        status, reload_body = _playground_api_request("POST", api, "/api/reload-csv", {}, csv_path)
        if status < 400:
            try:
                reload_payload = json.loads(reload_body) if reload_body else {}
            except Exception:
                reload_payload = {}
            if not isinstance(reload_payload, dict) or reload_payload.get("ok") is not False:
                reload_ok = True
                _enrich_debug(dbg_env, f"reload-csv ok attempt={attempt + 1}")
                break
        _enrich_debug(dbg_env, f"reload-csv not ready status={status} attempt={attempt + 1}")
        time.sleep(0.25 + (attempt * 0.02))
    if not reload_ok:
        _enrich_debug(dbg_env, "reload-csv failed after max attempts")
        if log_progress:
            print("Playground failed to reload CSV context.")
        return False, failed_jobs, skipped_count

    for idx, item in enumerate(run_columns):
        col_index = item.get("col_index")
        if not isinstance(col_index, int) or col_index < 0:
            _enrich_debug(dbg_env, f"skip column idx={idx} invalid col_index={col_index}")
            continue
        col_name = str(item.get("column") or f"Column {col_index + 1}")
        group_name = str(item.get("group") or "").strip()
        column_force_overwrite = bool(force_overwrite or bool(item.get("force_overwrite")))
        _enrich_debug(dbg_env, f"run-block prepare idx={idx} column={col_name} configured_col={col_index}")
        effective_col_index = _resolve_snapshot_col(col_index, col_name)
        body = {
            "col": effective_col_index,
            "row_start": int(row_start),
            "row_end": int(row_end),
            "wait": bool(max(0, int(row_end) - int(row_start) + 1) <= inline_wait_row_threshold),
            "immediate": False,
            "dry_run": False,
            "mock": False,
            "overwrite_existing": column_force_overwrite,
            "overwriteExisting": column_force_overwrite,
        }
        if log_progress:
            label = col_name
            op = str(item.get("operation") or "").strip()
            if op:
                label = f"{label} -> {op}"
            source = str(item.get("source") or "").strip().lower()
            if source == "updated":
                label = f"{label} [existing]"
            print(f"Running {label}...")
        request_timeout_s = _get_positive_int_env(
            dbg_env,
            "DEEPLINE_ENRICH_RUN_REQUEST_TIMEOUT_S",
            90,
        )
        poll_timeout_s = _get_positive_int_env(
            dbg_env,
            "DEEPLINE_ENRICH_RUN_POLL_TIMEOUT_S",
            compute_poll_timeout_s(int(row_start), int(row_end)),
        )
        _enrich_debug(
            dbg_env,
            (
                f"run-block request idx={idx} column={col_name} col={effective_col_index} "
                f"rows={row_start}:{row_end} timeout_s={request_timeout_s} poll_timeout_s={poll_timeout_s}"
            ),
        )
        _enrich_debug(
            dbg_env,
            (
                f"run-block submit idx={idx} column={col_name} "
                f"rows={row_start}:{row_end} backend_queue_owner=true"
            ),
        )
        code, resp_body, resp_headers, parsed = _execute_run_block_request(
            idx=idx,
            col_name=col_name,
            effective_col_index=effective_col_index,
            body=body,
            request_timeout_s=request_timeout_s,
        )
        if code < 400:
            run_id = str(parsed.get("run_id") or "").strip()
            if run_id:
                wait_obj = parsed.get("wait") if isinstance(parsed, dict) else None
                initial_pending = bool(wait_obj.get("pending")) if isinstance(wait_obj, dict) else None
                if initial_pending is False:
                    _enrich_debug(
                        dbg_env,
                        f"run-block initial response terminal idx={idx} column={col_name}; skipping poll",
                    )
                else:
                    code, resp_body, resp_headers, parsed = _poll_run_block_completion(
                        idx=idx,
                        col_name=col_name,
                        effective_col_index=effective_col_index,
                        run_id=run_id,
                        timeout_s=poll_timeout_s,
                    )

        if code >= 400:
            _enrich_debug(dbg_env, f"run-block failed idx={idx} column={col_name} status={code}; trying adjacent columns")
            raw_lower = str(resp_body or "").lower()
            if "not a block" in raw_lower:
                for candidate_col in (effective_col_index + 1, max(0, effective_col_index - 1)):
                    _enrich_debug(
                        dbg_env,
                        f"run-block retry with adjacent column idx={idx} column={col_name} candidate_col={candidate_col}",
                    )
                    retry_body = dict(body)
                    retry_body["col"] = candidate_col
                    retry_response = _playground_api_request_with_headers(
                        "POST",
                        api,
                        "/api/run-block",
                        retry_body,
                        csv_path,
                        timeout=request_timeout_s,
                    )
                    if retry_response.status < 400:
                        code = retry_response.status
                        resp_body = retry_response.body
                        resp_headers = retry_response.headers
                        effective_col_index = candidate_col
                        _enrich_debug(
                            dbg_env,
                            f"run-block adjacent-column retry succeeded idx={idx} column={col_name} col={candidate_col}",
                        )
                        break
        if code >= 400:
            _enrich_debug(dbg_env, f"run-block hard failure idx={idx} column={col_name} status={code}")
            error_detail = _format_playground_error_detail(resp_body)
            last_error = f"Playground API error ({code})"
            if error_detail:
                last_error = f"{last_error}: {error_detail}"
            return _fatal_column_failure(
                {
                    "job_id": f"run-block-{idx}",
                    "row_id": int(row_start),
                    "col_index": effective_col_index,
                    "column": col_name,
                    "last_error": last_error,
                },
                f"Column '{col_name}' failed with playground API error ({code}).",
            )
        _enrich_debug(
            dbg_env,
            f"run-block response idx={idx} column={col_name} status={code} ok={parsed.get('ok')} keys={sorted(parsed.keys()) if isinstance(parsed, dict) else []}",
        )
        threshold_raw = str(os.environ.get("DEEPLINE_ENRICH_COLUMN_FAIL_THRESHOLD_PERCENT") or "90").strip()
        try:
            fail_threshold = float(threshold_raw)
        except Exception:
            fail_threshold = 90.0
        wait_obj = parsed.get("wait") if isinstance(parsed, dict) else None
        jobs = wait_obj.get("jobs") if isinstance(wait_obj, dict) else []
        missing = wait_obj.get("missing") if isinstance(wait_obj, dict) else []
        wf_skipped = parsed.get("skipped_rows_by_waterfall")
        wait_summary = summarize_wait_outcome(jobs, missing, wf_skipped)
        failed_count = wait_summary.failed_count
        completed_count = wait_summary.completed_count
        missed_count = wait_summary.missed_count
        missing_count = wait_summary.missing_count
        total_count = wait_summary.total_count
        failed_pct = wait_summary.failed_pct
        if parsed.get("ok") is False:
            wait_failures = failure_like_jobs_from_wait(
                jobs,
                missing,
                column_name=col_name,
                target_col_index=effective_col_index,
                fallback_row=int(row_start),
            )
            failure_jobs = wait_failures or {
                "job_id": f"run-block-{idx}",
                "row_id": int(row_start),
                "col_index": effective_col_index,
                "column": col_name,
                "last_error": str(parsed.get("error") or parsed.get("message") or "run-block failed"),
            }
            failure_message = (
                f"Column '{col_name}' reported failure; continuing waterfall group '{group_name}'."
                if group_name
                else f"Column '{col_name}' reported failure."
            )
            if group_name:
                _record_column_failure(failure_jobs, failure_message)
                continue
            return _fatal_column_failure(failure_jobs, failure_message)
        elif failed_count > 0 and failed_pct >= fail_threshold:
            wait_failures = failure_like_jobs_from_wait(
                jobs,
                missing,
                column_name=col_name,
                target_col_index=effective_col_index,
                fallback_row=int(row_start),
            )
            last_error = ""
            if isinstance(jobs, list):
                for job in jobs:
                    if not isinstance(job, dict):
                        continue
                    status_text = str(job.get("status") or "").strip().lower()
                    if status_text in {"failed", "canceled", "queued", "running"}:
                        last_error = str(job.get("last_error") or job.get("error") or "").strip()
                        if last_error:
                            break
            if not last_error:
                last_error = f"Column execution failures exceeded threshold ({failed_count}/{total_count})"
            failure_jobs = wait_failures or {
                "job_id": f"run-block-{idx}",
                "row_id": int(row_start),
                "col_index": effective_col_index,
                "column": col_name,
                "last_error": last_error,
            }
            failure_message = (
                f"Column '{col_name}' had high failure rate ({failed_count}/{total_count}); "
                f"continuing waterfall group '{group_name}'."
                if group_name
                else f"Column '{col_name}' had high failure rate ({failed_count}/{total_count})."
            )
            if group_name:
                _record_column_failure(failure_jobs, failure_message)
                continue
            return _fatal_column_failure(failure_jobs, failure_message)
        elif completed_count == 0 and missed_count > 0:
            # Miss-only outcomes are expected in waterfall/list flows and should
            # not flip the overall run into a failure state by themselves.
            if log_progress:
                print(
                    f"Column '{col_name}' completed with misses only ({missed_count} missed, 0 filled).",
                )
        jobs_for_counts = parsed.get("jobs")
        if not isinstance(jobs_for_counts, list):
            jobs_for_counts = jobs if isinstance(jobs, list) else []
        queued_count = len(jobs_for_counts) if isinstance(jobs_for_counts, list) else 0
        skipped_existing_count = 0
        for key in ("skipped_rows", "skipped_existing", "skippedExisting", "skipped"):
            val = parsed.get(key)
            if isinstance(val, (list, int)):
                skipped_existing_count = _count_rows(val)
                break
        skipped_waterfall_count = 0
        for key in ("skipped_rows_by_waterfall", "skippedRowsByWaterfall"):
            val = parsed.get(key)
            if isinstance(val, (list, int)):
                skipped_waterfall_count = _count_rows(val)
                break
        skipped_total_count = skipped_existing_count + skipped_waterfall_count
        targeted_rows_count = max(0, int(row_end) - int(row_start))
        if (
            parsed.get("ok") is not False
            and targeted_rows_count > 0
            and queued_count == 0
            and skipped_total_count == 0
        ):
            wait_failures = failure_like_jobs_from_wait(
                jobs,
                missing,
                column_name=col_name,
                target_col_index=effective_col_index,
                fallback_row=int(row_start),
            )
            failure_jobs = wait_failures or {
                "job_id": f"run-block-{idx}",
                "row_id": int(row_start),
                "col_index": effective_col_index,
                "column": col_name,
                "last_error": (
                    "run-block returned no queued/skipped rows; likely transient execution failure "
                    "(for example RemoteDisconnected)."
                ),
            }
            failure_message = (
                f"Column '{col_name}' produced no queued/skipped rows; continuing waterfall group '{group_name}'."
                if group_name
                else (
                    f"Column '{col_name}' produced no queued/skipped rows; "
                    "treating as failure to avoid silent no-op."
                )
            )
            if group_name:
                _record_column_failure(failure_jobs, failure_message)
                continue
            return _fatal_column_failure(failure_jobs, failure_message)
        skipped_count += skipped_existing_count
        total_queued_all += queued_count
        total_completed_all += completed_count
        total_missed_all += missed_count
        total_skipped_existing_all += skipped_existing_count
        total_skipped_waterfall_all += skipped_waterfall_count
        _enrich_debug(
            dbg_env,
            (
                f"run-block summary idx={idx} column={col_name} queued={queued_count} "
                f"skipped_existing={skipped_existing_count} skipped_waterfall={skipped_waterfall_count} "
                f"completed={completed_count} missed={missed_count} failed_jobs={len(failed_jobs)}"
            ),
        )
        if log_progress:
            label = col_name
            op = str(item.get("operation") or "").strip()
            if op:
                label = f"{label} -> {op}"
            source = str(item.get("source") or "").strip().lower()
            if source == "updated":
                label = f"{label} [existing]"
            if queued_count == 0 and skipped_total_count > 0:
                print(
                    f"  ~ No-op {label} (queued=0, skipped_existing={skipped_existing_count}, "
                    f"skipped_waterfall={skipped_waterfall_count}, skipped_total={skipped_total_count})"
                )
            elif completed_count == 0 and missed_count > 0:
                print(
                    f"  ! Missed {label} (queued={queued_count}, missed={missed_count}, "
                    f"skipped_existing={skipped_existing_count}, skipped_waterfall={skipped_waterfall_count}, "
                    f"skipped_total={skipped_total_count})"
                )
            else:
                print(
                    f"  + Completed {label} (queued={queued_count}, skipped_existing={skipped_existing_count}, "
                    f"skipped_waterfall={skipped_waterfall_count}, skipped_total={skipped_total_count})"
                )

    if log_progress:
        try:
            _fieldnames, latest_rows = _load_compacted_csv(csv_path)
        except Exception:
            latest_rows = []
        if latest_rows:
            pruned_failed_jobs = _prune_satisfied_waterfall_group_failures(
                failed_jobs,
                run_columns,
                latest_rows,
                row_start,
                row_end,
            )
            if len(pruned_failed_jobs) != len(failed_jobs):
                failed_jobs[:] = pruned_failed_jobs
                had_column_failures = bool(failed_jobs)
        total_skipped_all = total_skipped_existing_all + total_skipped_waterfall_all
        if had_column_failures:
            print(
                f"Column execution finished with failures (queued={total_queued_all}, "
                f"skipped_existing={total_skipped_existing_all}, "
                f"skipped_waterfall={total_skipped_waterfall_all}, skipped_total={total_skipped_all})."
            )
        elif total_queued_all == 0 and total_skipped_all > 0:
            print(
                f"No-op: all targeted rows were skipped (existing={total_skipped_existing_all}, "
                f"waterfall={total_skipped_waterfall_all}, total={total_skipped_all})."
            )
        else:
            print(
                f"All targeted columns completed (queued={total_queued_all}, "
                f"filled={total_completed_all}, missed={total_missed_all}, "
                f"skipped_existing={total_skipped_existing_all}, "
                f"skipped_waterfall={total_skipped_waterfall_all}, skipped_total={total_skipped_all})."
            )

    _enrich_debug(
        dbg_env,
        (
            f"run_columns_in_playground end success=True failed_jobs={len(failed_jobs)} "
            f"skipped_count={skipped_count} total_queued={total_queued_all} "
            f"total_skipped_existing={total_skipped_existing_all} total_skipped_waterfall={total_skipped_waterfall_all}"
        ),
    )
    return True, failed_jobs, skipped_count


def _wait_for_backend_output_csv(
    output_path: str,
    fieldnames: list[str],
    source_rows: list[Dict[str, Any]],
    row_start: int,
    row_end: int,
    expected_columns: list[str],
    failed_columns: list[str],
    timeout_s: float = 2.0,
) -> tuple[list[str], list[Dict[str, Any]]]:
    deadline = time.time() + max(0.1, float(timeout_s or 0.0))
    stable_window_s = min(0.75, max(0.2, deadline - time.time()))
    latest_fieldnames = list(fieldnames)
    latest_rows = [dict(row) for row in source_rows]
    expected = [str(col or "").strip() for col in expected_columns if str(col or "").strip()]
    failed = [str(col or "").strip() for col in failed_columns if str(col or "").strip()]
    target_start = max(0, int(row_start))
    ready_signature: tuple[Any, ...] | None = None
    ready_since: float | None = None

    while True:
        try:
            loaded_fieldnames, loaded_rows = _load_compacted_csv(output_path)
            if loaded_fieldnames or loaded_rows:
                latest_fieldnames = loaded_fieldnames
                latest_rows = loaded_rows
                headers_ready = all(col in loaded_fieldnames for col in expected)
                values_ready = True
                if failed and loaded_rows:
                    target_end = min(len(loaded_rows), int(row_end))
                    if target_end > target_start:
                        for col in failed:
                            has_target_value = any(
                                bool(str(loaded_rows[idx].get(col) or "").strip())
                                for idx in range(target_start, target_end)
                            )
                            if not has_target_value:
                                values_ready = False
                                break
                if headers_ready and values_ready:
                    stat_signature: tuple[Any, ...]
                    try:
                        stat_result = os.stat(output_path)
                        stat_signature = (
                            stat_result.st_mtime_ns,
                            stat_result.st_size,
                            tuple(loaded_fieldnames),
                            len(loaded_rows),
                        )
                    except OSError:
                        stat_signature = (
                            tuple(loaded_fieldnames),
                            len(loaded_rows),
                        )
                    now = time.time()
                    if stat_signature != ready_signature:
                        ready_signature = stat_signature
                        ready_since = now
                    elif ready_since is not None and (now - ready_since) >= stable_window_s:
                        return loaded_fieldnames, loaded_rows
        except Exception:
            pass
        if time.time() >= deadline:
            return latest_fieldnames, latest_rows
        time.sleep(0.1)


def _persist_failed_column_errors(
    failed_jobs: list[Dict[str, Any]],
    fieldnames: list[str],
    source_rows: list[Dict[str, Any]],
    row_start: int,
    row_end: int,
    output_path: str,
) -> None:
    """Write error strings from failed_jobs into source_rows and save the CSV."""
    error_by_col: Dict[str, str] = {}
    for job in failed_jobs:
        col = str(job.get("column") or "").strip()
        err = str(job.get("last_error") or job.get("error") or "").strip()
        if col and err:
            error_by_col[col] = err
    if not error_by_col:
        return
    changed = False
    target_end = min(len(source_rows), row_end + 1)
    for idx in range(max(0, row_start), target_end):
        row = source_rows[idx]
        for col, err_text in error_by_col.items():
            error_value = json.dumps({"error": err_text, "__dl": {"miss": True, "miss_reason": "column_failure"}})
            row[col] = error_value
            changed = True
    if changed:
        _write_csv(output_path, fieldnames, source_rows)


def _summarize_failed_job_error(raw_error: Any) -> str:
    text = " ".join(str(raw_error or "").split()).strip()
    marker = "__DEEPLINE_BILLING_PAUSE__"
    if text.startswith(marker):
        encoded = text[len(marker) :].strip()
        try:
            parsed = json.loads(encoded)
        except Exception:
            parsed = None
        if isinstance(parsed, dict):
            needed = parsed.get("needed_credits")
            recommended = parsed.get("recommended_add_credits")
            billing_url = str(parsed.get("billing_url") or "").strip()
            summary = "workflow paused for insufficient credits"
            extra: list[str] = []
            if needed is not None:
                extra.append(f"needed={needed}")
            if recommended is not None:
                extra.append(f"recommended={recommended}")
            if extra:
                summary += f" ({', '.join(extra)})"
            if billing_url:
                summary += f" url={billing_url}"
            text = summary
    if len(text) > 500:
        return text[:497] + "..."
    return text


def _persist_failed_jobs_report(
    failed_jobs: list[Dict[str, Any]],
    *,
    api_url: str = "",
    output_path: str = "",
    row_start: int | None = None,
    row_end: int | None = None,
    command_text: str = "",
) -> str:
    jobs = [dict(job) for job in failed_jobs if isinstance(job, dict)]
    if not jobs:
        return ""
    try:
        state_dir = _env_dir() / "runtime" / "state"
        state_dir.mkdir(parents=True, exist_ok=True)
        report_path = state_dir / f"run-block-failures-{int(time.time())}-{os.getpid()}.json"

        failed_entries: list[Dict[str, Any]] = []
        canceled_entries: list[Dict[str, Any]] = []
        pending_entries: list[Dict[str, Any]] = []
        missing_job_ids: list[str] = []
        for job in jobs:
            status_text = str(job.get("status") or "").strip().lower()
            if status_text == "canceled":
                canceled_entries.append(job)
            elif status_text in {"queued", "running"}:
                pending_entries.append(job)
            elif status_text == "missing":
                missing_id = str(job.get("job_id") or "").strip()
                if missing_id:
                    missing_job_ids.append(missing_id)
            else:
                failed_entries.append(job)

        report: Dict[str, Any] = {
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "api_url": api_url,
            "output_csv": output_path,
            "summary": {
                "failed_count": len(failed_entries),
                "canceled_count": len(canceled_entries),
                "pending_count": len(pending_entries),
                "missing_count": len(missing_job_ids),
                "total_jobs": len(jobs),
            },
            "jobs": jobs,
            "failed_jobs": failed_entries,
            "canceled_jobs": canceled_entries,
            "pending_jobs": pending_entries,
            "missing_job_ids": missing_job_ids,
        }
        if isinstance(row_start, int) and isinstance(row_end, int):
            report["rows"] = {"start": row_start, "end": row_end}
        if command_text:
            report["command"] = command_text

        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        return str(report_path)
    except Exception:
        return ""


def _print_failed_jobs_preview(
    failed_jobs: list[Dict[str, Any]],
    *,
    report_path: str = "",
) -> None:
    jobs = [job for job in failed_jobs if isinstance(job, dict)]
    if jobs:
        print("Failure preview (up to 5 failed jobs):", file=sys.stderr)
        print("job_id\trow_id\tcol_index\tcolumn\tstatus\terror", file=sys.stderr)
        for job in jobs[:5]:
            job_id = str(job.get("job_id") or "-").strip() or "-"
            row_raw = job.get("row_id")
            if not isinstance(row_raw, int):
                row_raw = job.get("row")
            row_text = str(row_raw) if isinstance(row_raw, int) and row_raw >= 0 else "-"
            col_raw = job.get("col_index")
            if not isinstance(col_raw, int):
                col_raw = job.get("col")
            col_text = str(col_raw) if isinstance(col_raw, int) and col_raw >= 0 else "-"
            column_text = str(job.get("column") or "").strip() or "-"
            status_text = str(job.get("status") or "failed").strip().lower() or "failed"
            error_text = _summarize_failed_job_error(job.get("last_error") or job.get("error") or "")
            print(
                f"{job_id}\t{row_text}\t{col_text}\t{column_text}\t{status_text}\t{error_text}",
                file=sys.stderr,
            )
        if len(jobs) > 5:
            print(f"Showing 5 of {len(jobs)} failed jobs.", file=sys.stderr)
    if report_path:
        print(f"Full failure report: {report_path}", file=sys.stderr)
        print(
            "Inspect failed jobs: "
            + f"jq -r '.jobs[] | [.job_id,.row_id,.col_index,.column,.status,.last_error] | @tsv' {shlex.quote(report_path)}",
            file=sys.stderr,
        )


def _validate_waterfall_extractors_in_playground(
    csv_path: str,
    specs: list[Dict[str, Any]],
    base_url: str,
    env: Dict[str, str],
    tool_meta_cache: Dict[str, Dict[str, Any]],
) -> list[str]:
    def _should_block_on_extractor_validation_error(message: str) -> bool:
        normalized = str(message or "").strip()
        if not normalized:
            return False
        blocking_markers = (
            "Unknown target ",
            "No registered getter paths exist for target ",
            "Available target keys:",
            "Available registered targets:",
            "Available keys:",
            "List waterfalls must return an array",
            "Scalar waterfalls cannot return list-mode values",
            "expects a non-empty",
            "expects a string target name",
            "passed to target(...)",
        )
        return any(marker in normalized for marker in blocking_markers)

    api = _playground_default_api()
    errors: list[str] = []
    dbg_env = dict(os.environ)
    for spec in specs:
        group_name = str(spec.get("group") or "").strip()
        if not group_name:
            continue
        source = str(spec.get("extract_js") or "").strip()
        column = str(spec.get("column") or "").strip() or "<unnamed>"
        if not source:
            errors.append(f"{column}: waterfall steps require an extractor (use extract_js, e.g. (data) => extract(\"apollo_people_match\", data, \"email\")).")
            continue
        tool_id = str(spec.get("tool_id") or "").strip()
        input_payload = spec.get("payload")
        list_extractor_paths = spec.get("list_extractor_paths")
        result_identity_getters = spec.get("result_identity_getters")
        sample_response = spec.get("sample_response")
        output_schema = spec.get("output_schema")
        if tool_id and not _is_local_tool(tool_id):
            needs_meta = (
                not isinstance(list_extractor_paths, list)
                or not isinstance(result_identity_getters, dict)
                or sample_response is None
                or not isinstance(output_schema, dict)
            )
            if needs_meta:
                meta_status, meta = _get_or_resolve_tool_meta(
                    base_url,
                    env,
                    tool_id,
                    tool_meta_cache,
                    include_samples=True,
                )
                if meta_status == EXIT_OK and isinstance(meta, dict):
                    if not isinstance(list_extractor_paths, list):
                        list_extractor_paths = meta.get("list_extractor_paths")
                        spec["list_extractor_paths"] = list_extractor_paths
                    if not isinstance(result_identity_getters, dict):
                        result_identity_getters = meta.get(
                            "result_identity_getters"
                        )
                        spec["result_identity_getters"] = result_identity_getters
                    if sample_response is None:
                        sample_response = meta.get("sample_response")
                        spec["sample_response"] = sample_response
                    if not isinstance(output_schema, dict):
                        output_schema = meta.get("output_schema")
                        spec["output_schema"] = output_schema
        if _is_local_tool(tool_id):
            eval_status, eval_output = evaluate_extract_javascript(
                {
                    "source": source,
                    "toolId": tool_id,
                    "resultPayload": sample_response if sample_response is not None else {},
                    "rowContext": input_payload if isinstance(input_payload, dict) else {},
                    "defaultListExtractorPaths": (
                        [str(entry) for entry in list_extractor_paths if isinstance(entry, str)]
                        if isinstance(list_extractor_paths, list)
                        else []
                    ),
                    "targetGetterMap": (
                        {
                            str(key): [str(entry) for entry in value if isinstance(entry, str)]
                            for key, value in result_identity_getters.items()
                            if isinstance(key, str) and isinstance(value, list)
                        }
                        if isinstance(result_identity_getters, dict)
                        else {}
                    ),
                }
            )
            if eval_status == EXIT_OK:
                continue
            eval_message = ""
            try:
                eval_payload = json.loads(eval_output or "{}")
                if isinstance(eval_payload, dict):
                    eval_message = str(eval_payload.get("error") or "").strip()
            except Exception:
                eval_message = ""
            if not eval_message:
                eval_message = str(eval_output or "").strip() or "extractor validation failed"
            if _should_block_on_extractor_validation_error(eval_message):
                errors.append(f"{column}: {eval_message}")
            continue
        body = {
            "source": source,
            "mode": "list" if str(spec.get("waterfall_mode") or "").strip() == "list" else "scalar",
        }
        if tool_id:
            body["toolId"] = tool_id
        if isinstance(input_payload, dict):
            body["inputPayload"] = input_payload
        if isinstance(list_extractor_paths, list) and list_extractor_paths:
            body["listExtractorPaths"] = [str(entry) for entry in list_extractor_paths if isinstance(entry, str)]
        if (
            isinstance(result_identity_getters, dict)
            and result_identity_getters
        ):
            normalized_result_identity_getters: Dict[str, list[str]] = {}
            for key, value in result_identity_getters.items():
                if not isinstance(key, str) or not isinstance(value, list):
                    continue
                normalized_values = [str(entry) for entry in value if isinstance(entry, str)]
                if normalized_values:
                    normalized_result_identity_getters[key] = normalized_values
            if normalized_result_identity_getters:
                body["resultIdentityGetters"] = normalized_result_identity_getters
        if sample_response is not None:
            body["resultSample"] = sample_response
        if isinstance(output_schema, dict) and output_schema:
            body["outputSchema"] = output_schema
        _enrich_debug(
            dbg_env,
            (
                "validate extractor "
                f"column={column} tool_id={tool_id or '(none)'} "
                f"mode={body.get('mode')} has_result_sample={'resultSample' in body} "
                f"sample_keys={sorted(sample_response.keys())[:8] if isinstance(sample_response, dict) else ('<list>' if isinstance(sample_response, list) else '<none>')} "
                f"targets={sorted(body.get('resultIdentityGetters', {}).keys()) if isinstance(body.get('resultIdentityGetters'), dict) else []}"
            ),
        )
        status, resp_body = _playground_api_request(
            "POST",
            api,
            "/api/waterfall/validate-extractor",
            body,
            csv_path,
            timeout=15,
        )
        payload: Any = {}
        try:
            payload = json.loads(resp_body) if resp_body else {}
        except Exception:
            payload = {}
        if status < 400 and isinstance(payload, dict) and payload.get("ok") is True:
            continue
        remote_errors = payload.get("errors") if isinstance(payload, dict) else None
        if isinstance(remote_errors, list) and remote_errors:
            for item in remote_errors:
                message = str(item or "").strip()
                if message and _should_block_on_extractor_validation_error(message):
                    errors.append(f"{column}: {message}")
            continue
        payload_message = ""
        if isinstance(payload, dict):
            payload_message = str(
                payload.get("error")
                or payload.get("message")
                or ""
            ).strip()
        response_message = str(resp_body or "").strip()
        fallback_message = payload_message or response_message
        if fallback_message and _should_block_on_extractor_validation_error(fallback_message):
            errors.append(f"{column}: {fallback_message}")
            continue
        if status >= 500:
            errors.append(f"{column}: extractor validation failed (status {status}).")
    return errors


def _emit_enrich_runtime_state(
    *,
    api: str,
    csv_path: str,
    action: str,
    owner_id: str,
    command: str = "",
    rows_range: str = "",
    force_overwrite: bool | None = None,
    reason: str = "",
    force: bool = False,
    async_mode: bool = False,
) -> None:
    debug_env = dict(os.environ)
    _enrich_debug(
        debug_env,
        (
            f"emit runtime state action={action} owner={owner_id} csv={csv_path} "
            f"force={bool(force)} reason={reason or '(none)'} async={bool(async_mode)}"
        ),
    )
    body: Dict[str, Any] = {
        "action": action,
        "owner_id": owner_id,
    }
    session_id = str(_resolve_playground_link_session_id() or "").strip()
    if session_id:
        body["session_id"] = session_id
    if command:
        body["command"] = command
    if rows_range:
        body["rows_range"] = rows_range
    if force_overwrite is not None:
        body["force_overwrite"] = bool(force_overwrite)
    if reason:
        body["reason"] = reason
    if force:
        body["force"] = True

    def _send() -> None:
        try:
            _playground_api_request("POST", api, "/api/enrich-runtime", body, csv_path)
        except KeyboardInterrupt:
            _enrich_debug(debug_env, f"emit runtime state interrupted action={action} owner={owner_id}")
            # Best-effort telemetry only; never fail enrich because of runtime status.
            pass
        except Exception:
            _enrich_debug(debug_env, f"emit runtime state failed action={action} owner={owner_id}")
            # Best-effort telemetry only; never fail enrich because of runtime status.
            pass

    if async_mode:
        _run_enrich_background_task(debug_env, f"runtime-{action}", _send)
        return
    _send()


def _emit_enrich_telemetry(
    *,
    base_url: str,
    env: Dict[str, str],
    event: str,
    run_id: str,
    command: str = "",
    rows_range: str = "",
    input_path: str = "",
    summary: Dict[str, Any] | None = None,
    sample_rows: list[Dict[str, str]] | None = None,
    failure_samples: list[Dict[str, Any]] | None = None,
    async_mode: bool = False,
) -> None:
    _enrich_debug(
        env,
        (
            f"emit telemetry event={event} run_id={run_id} rows_range={rows_range or '(none)'} "
            f"has_summary={bool(summary)} async={bool(async_mode)}"
        ),
    )
    body: Dict[str, Any] = {
        "event": event,
        "source": "cli_enrich",
        "run_id": str(run_id or "").strip(),
    }
    if command:
        body["command"] = str(command)
    if rows_range:
        body["rows_range"] = str(rows_range)
    if input_path:
        body["input_path"] = os.path.basename(str(input_path))
    if isinstance(summary, dict):
        body["summary"] = summary
    if sample_rows:
        body["sample_rows"] = sample_rows[:2]
    if failure_samples:
        body["failure_samples"] = failure_samples[:3]

    def _send() -> None:
        try:
            http_request(
                "POST",
                f"{base_url}/api/v2/telemetry/activity",
                env.get("DEEPLINE_API_KEY"),
                body,
                timeout=20,
            )
        except KeyboardInterrupt:
            _enrich_debug(env, f"emit telemetry interrupted event={event} run_id={run_id}")
            # Best-effort telemetry only; never fail enrich because of telemetry status.
            pass
        except Exception:
            _enrich_debug(env, f"emit telemetry failed event={event} run_id={run_id}")
            # Best-effort telemetry only; never fail enrich because of telemetry status.
            pass

    if async_mode:
        _run_enrich_background_task(env, f"telemetry-{event}", _send)
        return
    _send()


def usage_enrich_computed() -> list[str]:
    return _usage_enrich()


def _enrich_unknown(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    routed = router.dispatch("run", base_url, env, args)
    if routed is not None:
        return routed
    return EXIT_USAGE

def _parse_rows_arg(value: str, max_end: int) -> tuple[int, int]:
    if ":" not in value:
        raise ValueError("rows must be start:end")
    left, right = value.split(":", 1)
    if not left.strip():
        raise ValueError("rows must include start")
    start = int(left)
    # Allow open-ended ranges like "2:" to mean "from row 2 to the end".
    # End is exclusive: 0:1 targets only row 0.
    end = int(right) if right.strip() else max_end
    if start < 0 or end < 0:
        raise ValueError("rows must be non-negative")
    if end < start:
        raise ValueError("rows end must be >= start")
    return max(0, start), min(max_end, end)


def _runtime_specs_from_compiled_config(config: Dict[str, Any]) -> list[Dict[str, Any]]:
    commands = config.get("commands") if isinstance(config, dict) else []
    if not isinstance(commands, list):
        return []
    runtime_specs: list[Dict[str, Any]] = []
    for command in commands:
        if not isinstance(command, dict):
            continue
        waterfall_alias = str(command.get("with_waterfall") or "").strip()
        if not waterfall_alias:
            runtime_specs.append(
                {
                    "column": str(command.get("alias") or ""),
                    "tool_ref": str(command.get("tool") or ""),
                    "tool_id": _normalize_tool_id(_canonical_tool_ref(str(command.get("tool") or ""))),
                    "operation": str(command.get("operation") or "").strip(),
                    "payload": dict(command.get("payload") or {}),
                    "extract_js": str(command.get("extract_js") or ""),
                    "run_if_js": str(command.get("run_if_js") or ""),
                    "group": "",
                    "waterfall_mode": "scalar",
                    "waterfall_min_results": None,
                }
            )
            continue
        group_alias = waterfall_alias
        min_results_raw = command.get("min_results")
        waterfall_mode = "list" if min_results_raw is not None else "scalar"
        min_results = None
        if min_results_raw is not None:
            try:
                min_results = max(1, int(min_results_raw))
            except Exception:
                min_results = 1
        nested = command.get("commands") if isinstance(command.get("commands"), list) else []
        for nested_command in nested:
            if not isinstance(nested_command, dict):
                continue
            runtime_specs.append(
                {
                    "column": str(nested_command.get("alias") or ""),
                    "tool_ref": str(nested_command.get("tool") or ""),
                    "tool_id": _normalize_tool_id(_canonical_tool_ref(str(nested_command.get("tool") or ""))),
                    "operation": str(nested_command.get("operation") or "").strip(),
                    "payload": dict(nested_command.get("payload") or {}),
                    "extract_js": str(nested_command.get("extract_js") or ""),
                    "run_if_js": str(nested_command.get("run_if_js") or ""),
                    "group": group_alias,
                    "waterfall_mode": waterfall_mode,
                    "waterfall_min_results": min_results,
                }
            )
        runtime_specs.append(
            {
                "column": group_alias,
                "tool_ref": "run_javascript",
                "tool_id": "run_javascript",
                "operation": "run_javascript",
                "payload": {"code": f"return row[{json.dumps(group_alias)}]||null;"},
                "extract_js": "",
                "run_if_js": "",
                "group": "",
                "waterfall_mode": "scalar",
                "waterfall_min_results": None,
                "synthetic_waterfall_output": True,
            }
        )
    return runtime_specs


def _expand_with_force_aliases_for_waterfall_children(
    specs: list[Dict[str, Any]],
    requested_aliases: set[str],
) -> set[str]:
    expanded = set(requested_aliases)
    if not requested_aliases or not specs:
        return expanded
    forced_groups = {
        alias
        for alias in requested_aliases
        if any(_normalize_alias(str(spec.get("group") or "")) == alias for spec in specs)
    }
    if not forced_groups:
        return expanded
    for spec in specs:
        child_alias = _normalize_alias(str(spec.get("column") or ""))
        group_alias = _normalize_alias(str(spec.get("group") or ""))
        if child_alias and group_alias and group_alias in forced_groups:
            expanded.add(child_alias)
    return expanded


def _slugify_enrich_config_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "-", str(value or "").strip()).strip("-._")
    return text or "enrich"


def _build_enrich_config_sidecar_path(input_path: str, output_path: str, dry_run: bool) -> str:
    cwd = Path.cwd()
    enrichments_dir = cwd / "deepline" / "enrichments"
    base_name = Path(output_path if output_path and not dry_run else input_path).stem or "enrich"
    timestamp = time.strftime("%Y%m%d-%H%M%S", time.localtime())
    filename = f"{_slugify_enrich_config_name(base_name)}-{timestamp}.jsonc"
    return str(enrichments_dir / filename)


def _render_enrich_config_jsonc(config: Dict[str, Any]) -> str:
    body = {
        "version": int(config.get("version") or 1),
        "commands": config.get("commands") if isinstance(config.get("commands"), list) else [],
    }
    lines = [
        "// Deepline enrich compiled config.",
        "// This file stores the concrete commands that ran.",
    ]
    comments = config.get("_comments")
    if isinstance(comments, list):
        for comment in comments:
            if not isinstance(comment, dict):
                continue
            comment_lines = comment.get("lines")
            if not isinstance(comment_lines, list):
                continue
            for line in comment_lines:
                text = str(line or "").strip()
                if text:
                    lines.append(f"// {text}")
    lines.append(json.dumps(body, indent=2, ensure_ascii=False))
    return "\n".join(lines) + "\n"


def _persist_enrich_config_sidecar(config: Dict[str, Any], input_path: str, output_path: str, dry_run: bool) -> str:
    sidecar_path = _build_enrich_config_sidecar_path(input_path, output_path, dry_run)
    sidecar = Path(sidecar_path)
    sidecar.parent.mkdir(parents=True, exist_ok=True)
    sidecar.write_text(_render_enrich_config_jsonc(config), encoding="utf-8")
    return str(sidecar)


def _strip_jsonc_comments(text: str) -> str:
    out: list[str] = []
    i = 0
    in_string = False
    escaped = False
    while i < len(text):
        ch = text[i]
        if in_string:
            out.append(ch)
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            i += 1
            continue
        if ch == '"':
            in_string = True
            out.append(ch)
            i += 1
            continue
        if ch == "/" and i + 1 < len(text):
            nxt = text[i + 1]
            if nxt == "/":
                i += 2
                while i < len(text) and text[i] not in "\r\n":
                    i += 1
                continue
            if nxt == "*":
                i += 2
                while i + 1 < len(text) and not (text[i] == "*" and text[i + 1] == "/"):
                    i += 1
                i = min(i + 2, len(text))
                continue
        out.append(ch)
        i += 1
    return "".join(out)


def _load_enrich_config_jsonc(config_path: str) -> Dict[str, Any]:
    path = Path(_normalize_path(config_path))
    if not path.exists():
        raise ValueError(f"--config file does not exist: {path}")
    if not path.is_file():
        raise ValueError(f"--config path is not a regular file: {path}")
    try:
        raw = _read_cli_text_input(f"@{path}", argument_name="--config", strip=False)
    except ValueError as exc:
        raise ValueError(str(exc)) from exc
    try:
        parsed = json.loads(_strip_jsonc_comments(raw))
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid enrich config JSONC in '{path}' at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc
    except Exception as exc:
        raise ValueError(f"Invalid enrich config JSONC in '{path}': {exc}") from exc
    if not isinstance(parsed, dict):
        raise ValueError(f"Invalid enrich config in '{path}': expected a top-level JSON object.")
    return parsed


def _prepare_plan_args_for_server_compile(plan_args: list[str]) -> list[str]:
    prepared: list[str] = []
    i = 0
    while i < len(plan_args):
        arg = str(plan_args[i])
        if arg == "--with":
            if i + 1 >= len(plan_args):
                raise ValueError("Missing value for --with.")
            spec = _parse_with_spec(str(plan_args[i + 1]))
            payload: Dict[str, Any] = {
                "alias": str(spec.get("column") or ""),
                "tool": str(spec.get("tool_ref") or spec.get("tool_id") or ""),
                "payload": dict(spec.get("payload") or {}),
            }
            extract_js = str(spec.get("extract_js") or "").strip()
            run_if_js = str(spec.get("run_if_js") or "").strip()
            if extract_js:
                payload["extract_js"] = extract_js
            if run_if_js:
                payload["run_if_js"] = run_if_js
            prepared.extend(["--with", json.dumps(payload, ensure_ascii=False)])
            i += 2
            continue
        if arg.startswith("--with="):
            spec = _parse_with_spec(str(arg.split("=", 1)[1]))
            payload = {
                "alias": str(spec.get("column") or ""),
                "tool": str(spec.get("tool_ref") or spec.get("tool_id") or ""),
                "payload": dict(spec.get("payload") or {}),
            }
            extract_js = str(spec.get("extract_js") or "").strip()
            run_if_js = str(spec.get("run_if_js") or "").strip()
            if extract_js:
                payload["extract_js"] = extract_js
            if run_if_js:
                payload["run_if_js"] = run_if_js
            prepared.append(f"--with={json.dumps(payload, ensure_ascii=False)}")
            i += 1
            continue
        prepared.append(arg)
        i += 1
    return prepared


def _compile_enrich_config_via_server(
    base_url: str,
    env: Dict[str, str],
    *,
    plan_args: list[str] | None = None,
    config: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {}
    if plan_args is not None:
        payload["plan_args"] = plan_args
    if config is not None:
        payload["config"] = config
    started_at = time.time()
    _enrich_debug(
        env,
        (
            "compile request start "
            f"url={base_url.rstrip('/')}/api/v2/enrich/compile "
            f"has_plan_args={plan_args is not None} "
            f"has_config={config is not None} "
            f"api_key={'yes' if bool(env.get('DEEPLINE_API_KEY')) else 'no'}"
        ),
    )
    compile_timeout_s = _get_positive_int_env(
        env,
        "DEEPLINE_ENRICH_COMPILE_TIMEOUT_S",
        90,
    )
    status, body = http_request(
        "POST",
        f"{base_url.rstrip('/')}/api/v2/enrich/compile",
        env.get("DEEPLINE_API_KEY"),
        payload,
        timeout=compile_timeout_s,
    )
    elapsed_ms = int((time.time() - started_at) * 1000)
    _enrich_debug(env, f"compile request finished status={status} elapsed_ms={elapsed_ms}")
    if status >= 400:
        try:
            parsed = json.loads(body)
        except Exception:
            parsed = {}
        message = str(parsed.get("error") or body or "Enrich compile failed.").strip()
        if status in (401, 403):
            detail = (
                f"Auth error while compiling enrich config (status {status}). "
                f"base_url={base_url.rstrip('/')} "
                f"api_key_present={'yes' if bool(env.get('DEEPLINE_API_KEY')) else 'no'}"
            )
            raise ValueError(detail)
        raise ValueError(message)
    try:
        parsed = json.loads(body)
    except Exception as exc:
        raise ValueError(f"Invalid response from enrich compile endpoint: {exc}") from exc
    config_value = parsed.get("config")
    if not isinstance(config_value, dict):
        raise ValueError("Invalid response from enrich compile endpoint: missing config object.")
    return config_value


def _normalize_alias(value: str) -> str:
    return "".join(ch for ch in str(value or "").lower() if ch.isalnum())


def _normalize_waterfall_name_key(value: str) -> str:
    return re.sub(r"[\s_-]+", "_", str(value or "").strip().lower())


def _playground_col_index(fieldnames: list[str], column: str) -> int:
    target = str(column or "")
    idx = 0
    for name in fieldnames:
        header = str(name or "")
        if header == "_metadata" or header.startswith(_ENRICH_META_PREFIXES):
            continue
        if header == target:
            return idx
        idx += 1
    return -1


def _build_requested_column_order(
    fieldnames: list[str],
    parsed_specs: list[Dict[str, Any]],
) -> list[str]:
    requested_columns: list[str] = []
    seen: set[str] = set()
    fieldname_set = set(fieldnames)
    index = 0

    while index < len(parsed_specs):
        spec = parsed_specs[index]
        group_name = str(spec.get("group") or "").strip()
        if group_name:
            while index < len(parsed_specs):
                grouped_spec = parsed_specs[index]
                if str(grouped_spec.get("group") or "").strip() != group_name:
                    break
                column_name = str(grouped_spec.get("column") or "").strip()
                if column_name and column_name in fieldname_set and column_name not in seen:
                    requested_columns.append(column_name)
                    seen.add(column_name)
                index += 1

            if group_name in fieldname_set and group_name not in seen:
                requested_columns.append(group_name)
                seen.add(group_name)

            source_column = f"{_normalize_waterfall_name_key(group_name)}_source"
            if source_column in fieldname_set and source_column not in seen:
                requested_columns.append(source_column)
                seen.add(source_column)
            continue

        column_name = str(spec.get("column") or "").strip()
        if column_name and column_name in fieldname_set and column_name not in seen:
            requested_columns.append(column_name)
            seen.add(column_name)
        index += 1

    return requested_columns


def _parse_metadata_columns(raw: Any) -> Dict[str, Dict[str, Any]]:
    text = str(raw or "").strip()
    if not text:
        return {}
    try:
        parsed = json.loads(text)
    except Exception:
        parsed = None
        # Legacy CSVs may contain backslash-escaped JSON blobs such as:
        # {\"version\":2,\"columns\":{...}}
        # Be permissive only for that explicit shape.
        if '\\"' in text and text.startswith("{") and text.endswith("}"):
            try:
                repaired = bytes(text, "utf-8").decode("unicode_escape")
                parsed = json.loads(repaired)
            except Exception:
                return {}
        else:
            return {}
    if not isinstance(parsed, dict):
        return {}
    if int(parsed.get("version") or 0) != 2:
        return {}
    columns = parsed.get("columns")
    if not isinstance(columns, dict):
        return {}
    out: Dict[str, Dict[str, Any]] = {}
    for key, value in columns.items():
        alias = _normalize_alias(str(key))
        if not alias or not isinstance(value, dict):
            continue
        out[alias] = dict(value)
    return out


def _build_metadata_entry(spec: Dict[str, Any]) -> Dict[str, Any]:
    name = str(spec.get("column") or "").strip()
    tool_id = str(spec.get("tool_id") or "").strip()
    operation = str(spec.get("operation") or tool_id).strip()
    source = str(spec.get("source") or "added").strip()
    payload = spec.get("payload")
    extract_js = str(spec.get("extract_js") or "").strip()
    run_if_js = str(spec.get("run_if_js") or "").strip()
    group_name = str(spec.get("group") or "").strip()
    waterfall_group_id = str(spec.get("waterfall_group_id") or "").strip()
    waterfall_step_index = spec.get("waterfall_step_index")
    waterfall_mode = "list" if str(spec.get("waterfall_mode") or "").strip() == "list" else "scalar"
    waterfall_min_results_raw = spec.get("waterfall_min_results")

    entry: Dict[str, Any] = {
        "name": name,
        "tool_id": tool_id,
        "source": source,
    }
    if operation:
        entry["operation"] = operation
    if payload is not None:
        entry["payload"] = payload
    if extract_js:
        entry["extract_js"] = extract_js
    if run_if_js:
        entry["run_if_js"] = run_if_js
    if group_name or waterfall_group_id:
        group_id = waterfall_group_id or _build_waterfall_group_id(group_name)
        wf_entry: Dict[str, Any] = {
            "group_id": group_id,
            "step_index": int(waterfall_step_index) if isinstance(waterfall_step_index, int) else 0,
            "enabled": True,
            "display_name": group_name or group_id,
            "mode": waterfall_mode,
        }
        if waterfall_mode == "list":
            try:
                min_results = int(waterfall_min_results_raw)
            except Exception:
                min_results = 1
            wf_entry["min_results"] = max(1, min_results)
        entry["waterfall"] = wf_entry
    return entry


def _cell_has_success_value(raw: Any) -> bool:
    if raw is None:
        return False
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return False
        if text.startswith("Error:"):
            return False
        return text.lower() not in {"null", "none"}
    if isinstance(raw, (list, dict)):
        return len(raw) > 0
    return True


def _parse_json_like_cell(raw: Any) -> Any:
    if isinstance(raw, str):
        text = raw.strip()
        if not text:
            return raw
        if text[0] in "{[":
            try:
                return json.loads(text)
            except Exception:
                return raw
    return raw


def _extract_matched_result(raw: Any) -> Any:
    parsed = _parse_json_like_cell(raw)
    if parsed and isinstance(parsed, dict):
        for key in ("matched_result", "matchedResult"):
            if key in parsed:
                return parsed.get(key)
    return None


def _cell_has_matched_result_key(raw: Any) -> bool:
    parsed = _parse_json_like_cell(raw)
    return bool(
        parsed
        and isinstance(parsed, dict)
        and any(key in parsed for key in ("matched_result", "matchedResult"))
    )


def _cell_has_matched_result(raw: Any) -> bool:
    matched = _extract_matched_result(raw)
    if matched is None:
        return False
    if isinstance(matched, str):
        text = matched.strip()
        if not text:
            return False
        return text.lower() != "no matched result"
    if isinstance(matched, (list, dict)):
        return len(matched) > 0
    return True


def _extract_js_warning_needed(sample_value: Any, sample_type: str) -> bool:
    sample = _parse_json_like_cell(sample_value)
    if isinstance(sample, dict) and any(
        key in sample for key in ("matched_result", "matchedResult")
    ):
        matched = _extract_matched_result(sample)
        if matched is None:
            return False
        if isinstance(matched, (dict, list)):
            return len(matched) > 0
        return False
    return sample_type in {"object", "array"}


def _resolve_run_column_group_name(item: Dict[str, Any]) -> str:
    group_name = str(item.get("group") or "").strip()
    if group_name:
        return group_name
    waterfall_cfg = item.get("waterfall")
    if isinstance(waterfall_cfg, dict):
        return str(
            waterfall_cfg.get("display_name")
            or waterfall_cfg.get("group")
            or ""
        ).strip()
    return ""




def _prune_satisfied_waterfall_group_failures(
    failed_jobs: list[Dict[str, Any]],
    run_columns: list[Dict[str, Any]],
    source_rows: list[Dict[str, Any]],
    row_start: int,
    row_end: int,
) -> list[Dict[str, Any]]:
    if not failed_jobs or not run_columns or row_end < row_start:
        return list(failed_jobs)
    targeted_rows = source_rows[row_start : min(len(source_rows), row_end + 1)]
    if not targeted_rows:
        return list(failed_jobs)

    column_to_group: dict[str, str] = {}
    candidate_groups: set[str] = set()
    for item in run_columns:
        if not isinstance(item, dict):
            continue
        col_name = str(item.get("column") or "").strip()
        group_name = _resolve_run_column_group_name(item)
        if not col_name or not group_name:
            continue
        column_to_group[col_name] = group_name
        candidate_groups.add(group_name)

    if not candidate_groups:
        return list(failed_jobs)

    satisfied_groups = {
        group_name
        for group_name in candidate_groups
        if all(_cell_has_success_value(row.get(group_name)) for row in targeted_rows)
    }
    if not satisfied_groups:
        return list(failed_jobs)

    return [
        job
        for job in failed_jobs
        if column_to_group.get(str(job.get("column") or "").strip()) not in satisfied_groups
    ]


def _targeted_enrich_rows(
    source_rows: list[Dict[str, Any]],
    row_start: int,
    row_end: int,
) -> list[Dict[str, Any]]:
    if row_end < row_start:
        return []
    return source_rows[row_start : min(len(source_rows), row_end + 1)]


def _coerce_source_values(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        values = raw
    elif isinstance(raw, str):
        text = raw.strip()
        if not text:
            return []
        if text.startswith("[") and text.endswith("]"):
            try:
                parsed = json.loads(text)
            except Exception:
                parsed = None
            if isinstance(parsed, list):
                values = parsed
            else:
                values = [raw]
        else:
            values = [raw]
    else:
        values = [raw]
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text)
        out.append(text)
    return out


def _summarize_waterfall_sources(
    run_columns: list[Dict[str, Any]],
    source_rows: list[Dict[str, Any]],
    row_start: int,
    row_end: int,
) -> list[Dict[str, Any]]:
    targeted_rows = _targeted_enrich_rows(source_rows, row_start, row_end)
    if not targeted_rows:
        return []

    group_order: list[str] = []
    group_source_labels: dict[str, dict[str, str]] = {}
    for item in run_columns:
        if not isinstance(item, dict):
            continue
        group_name = str(item.get("group") or "").strip()
        column_name = str(item.get("column") or "").strip()
        if not group_name or not column_name:
            continue
        if group_name not in group_source_labels:
            group_source_labels[group_name] = {}
            group_order.append(group_name)
        source_label = str(item.get("tool_ref") or item.get("tool_id") or column_name).strip()
        group_source_labels[group_name][column_name] = source_label or column_name

    summaries: list[Dict[str, Any]] = []
    for group_name in group_order:
        source_column = f"{_normalize_waterfall_name_key(group_name)}_source"
        per_source_counts: dict[str, int] = {}
        resolved_rows = 0
        empty_rows = 0
        for row in targeted_rows:
            raw_values = _coerce_source_values(row.get(source_column))
            if not raw_values:
                empty_rows += 1
                continue
            resolved_rows += 1
            seen_sources_for_row: set[str] = set()
            for raw_value in raw_values:
                label = group_source_labels.get(group_name, {}).get(raw_value, raw_value)
                if label in seen_sources_for_row:
                    continue
                seen_sources_for_row.add(label)
                per_source_counts[label] = per_source_counts.get(label, 0) + 1
        if not per_source_counts and empty_rows == len(targeted_rows):
            continue
        top_sources = sorted(
            (
                {"source": label, "rows": count}
                for label, count in per_source_counts.items()
            ),
            key=lambda item: (-int(item["rows"]), str(item["source"])),
        )[:5]
        summaries.append(
            {
                "waterfall": group_name,
                "source_column": source_column,
                "targeted_rows": len(targeted_rows),
                "resolved_rows": resolved_rows,
                "empty_rows": empty_rows,
                "sources": top_sources,
            }
        )
    return summaries


def _summarize_column_results(
    run_columns: list[Dict[str, Any]],
    source_rows: list[Dict[str, Any]],
    row_start: int,
    row_end: int,
) -> list[Dict[str, Any]]:
    targeted_rows = _targeted_enrich_rows(source_rows, row_start, row_end)
    if not targeted_rows:
        return []

    summaries: list[Dict[str, Any]] = []
    seen_columns: set[str] = set()
    targeted_count = len(targeted_rows)
    for item in run_columns:
        if not isinstance(item, dict):
            continue
        column_name = str(item.get("column") or "").strip()
        if not column_name or column_name in seen_columns:
            continue
        seen_columns.add(column_name)
        saw_matched_result_key = False
        matched_rows = 0
        success_rows = 0
        for row in targeted_rows:
            if not isinstance(row, dict):
                continue
            cell_value = row.get(column_name)
            if _cell_has_matched_result_key(cell_value):
                saw_matched_result_key = True
            if _cell_has_matched_result(cell_value):
                matched_rows += 1
            if _cell_has_success_value(cell_value):
                success_rows += 1
        summary: Dict[str, Any] = {
            "column": column_name,
            "targeted_rows": targeted_count,
            "success_rows": success_rows,
            "empty_rows": max(0, targeted_count - success_rows),
        }
        if saw_matched_result_key:
            summary["matched_rows"] = matched_rows
        tool_name = str(item.get("tool_ref") or item.get("tool_id") or "").strip()
        if tool_name:
            summary["tool"] = tool_name
        summaries.append(summary)
    return summaries


def _summarize_rate_limit_stats(
    failed_jobs: list[Dict[str, Any]],
    retry_events: list[Dict[str, Any]] | None = None,
) -> Dict[str, Any] | None:
    provider_stats: dict[tuple[str, str], dict[str, Any]] = {}
    event_count = 0
    retry_count = 0
    final_failure_count = 0
    max_retry_after_ms = 0

    def _record(meta: dict[str, Any], *, is_retry: bool, is_final_failure: bool) -> None:
        nonlocal event_count, retry_count, final_failure_count, max_retry_after_ms
        provider = str(meta.get("provider") or "unknown").strip() or "unknown"
        operation = str(meta.get("operation") or "").strip()
        key = (provider, operation)
        stat = provider_stats.setdefault(
            key,
            {
                "provider": provider,
                "operation": operation,
                "events": 0,
                "retries": 0,
                "final_failures": 0,
            },
        )
        stat["events"] += 1
        event_count += 1
        retry_after_ms = int(meta.get("retry_after_ms") or 0)
        if retry_after_ms > max_retry_after_ms:
            max_retry_after_ms = retry_after_ms
        if is_retry:
            stat["retries"] += 1
            retry_count += 1
        if is_final_failure:
            stat["final_failures"] += 1
            final_failure_count += 1

    for event in retry_events or []:
        meta = event if isinstance(event, dict) else None
        if isinstance(meta, dict):
            _record(meta, is_retry=True, is_final_failure=False)

    for job in failed_jobs:
        if not isinstance(job, dict):
            continue
        meta = _parse_rate_limit_meta(job.get("last_error") or job.get("error"))
        if not isinstance(meta, dict):
            continue
        _record(meta, is_retry=False, is_final_failure=True)

    if event_count == 0:
        return None

    providers = sorted(
        provider_stats.values(),
        key=lambda item: (
            -int(item.get("events") or 0),
            -int(item.get("final_failures") or 0),
            str(item.get("provider") or ""),
            str(item.get("operation") or ""),
        ),
    )[:5]
    summary: Dict[str, Any] = {
        "event_count": event_count,
        "retry_count": retry_count,
        "final_failure_count": final_failure_count,
        "providers": providers,
    }
    if max_retry_after_ms > 0:
        summary["max_retry_after_ms"] = max_retry_after_ms
    return summary


def _is_transient_disconnect_message(raw: Any) -> bool:
    lowered = str(raw or "").strip().lower()
    if not lowered:
        return False
    markers = (
        "remotedisconnected",
        "remote end closed connection",
        "connection reset by peer",
        "broken pipe",
        "connection aborted",
        "connection unexpectedly closed",
    )
    return any(marker in lowered for marker in markers)


def _render_value_template(
    value: Any,
    row: Dict[str, Any],
    array_fields: set[str] | None = None,
) -> Any:
    if isinstance(value, str):
        matches = list(re.finditer(r"\{\{([^{}]+)\}\}", value))
        if not matches:
            return value
        if len(matches) == 1 and matches[0].span() == (0, len(value)):
            key = str(matches[0].group(1) or "").strip()
            resolved = row.get(key, "")
            if array_fields and key in array_fields and isinstance(resolved, str):
                trimmed = resolved.strip()
                if not trimmed:
                    return []
                if trimmed.startswith("[") and trimmed.endswith("]"):
                    try:
                        parsed = json.loads(trimmed)
                    except Exception:
                        parsed = None
                    if isinstance(parsed, list):
                        return parsed
                return [part.strip() for part in trimmed.split(",") if part.strip()]
            return resolved
        out = value
        for k, v in row.items():
            out = out.replace("{{" + str(k) + "}}", str(v if v is not None else ""))
        return out
    if isinstance(value, dict):
        return {
            str(k): _render_value_template(v, row, array_fields)
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [_render_value_template(v, row, array_fields) for v in value]
    return value


@router.route(
    "run",
    summary="Run csv enrichment/waterfall operations.",
    options=[
        OptionSpec("--input", "Input CSV path", takes_value=True, value_name="PATH"),
        OptionSpec("--output", "Output CSV path", takes_value=True, value_name="PATH"),
        OptionSpec("--in-place", "Write output back to input file"),
        OptionSpec("--config", "Compiled enrich config JSONC path", takes_value=True, value_name="PATH"),
        OptionSpec("--with", "Tool spec JSON ({alias,tool,payload,extract_js,run_if_js})", takes_value=True, value_name="SPEC"),
        OptionSpec("--with-force", "Force rerun for selected aliases", takes_value=True, value_name="ALIASES"),
        OptionSpec("--with-waterfall", "Open waterfall group", takes_value=True, value_name="GROUP"),
        OptionSpec("--min-results", "Minimum list results before stopping a waterfall", takes_value=True, value_name="N"),
        OptionSpec("--end-waterfall", "Close waterfall group"),
        OptionSpec("--rows", "Row range start:end", takes_value=True, value_name="RANGE"),
        OptionSpec("--all", "Run all rows"),
        OptionSpec("--json", "Emit JSON output"),
    ],
)
def cmd_enrich(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    _enrich_debug(env, f"cmd_enrich start base_url={base_url} args_count={len(args)}")
    has_input = False
    input_path = ""
    output_path = ""
    config_path = ""
    plan_args: list[str] = []
    dry_run = False
    output_json = False
    in_place = False
    rows_value = ""
    run_all = False
    force_overwrite = False
    with_force_aliases: set[str] = set()
    i = 0
    while i < len(args):
        arg = args[i]
        if arg in {"--input", "--csv"}:
            if i + 1 >= len(args):
                _log("Missing value for --input.", err=True)
                return EXIT_USAGE
            input_path = args[i + 1]
            has_input = True
            i += 2
            continue
        if arg == "--output":
            if i + 1 >= len(args):
                _log("Missing value for --output.", err=True)
                return EXIT_USAGE
            output_path = args[i + 1]
            i += 2
            continue
        if arg == "--config":
            if i + 1 >= len(args):
                print("Missing value for --config.", file=sys.stderr)
                return EXIT_USAGE
            config_path = str(args[i + 1])
            i += 2
            continue
        if arg.startswith("--config="):
            config_path = str(arg.split("=", 1)[1])
            if not config_path.strip():
                print("Missing value for --config.", file=sys.stderr)
                return EXIT_USAGE
            i += 1
            continue
        if arg == "--in-place":
            in_place = True
            i += 1
            continue
        if arg.startswith("--with="):
            raw_spec = str(arg.split("=", 1)[1])
            if not raw_spec:
                print("Missing value for --with.", file=sys.stderr)
                return EXIT_USAGE
            plan_args.append(arg)
            i += 1
            continue
        if arg == "--with":
            if i + 1 >= len(args):
                print("Missing value for --with.", file=sys.stderr)
                return EXIT_USAGE
            plan_args.extend([arg, str(args[i + 1])])
            i += 2
            continue
        if arg == "--dry-run":
            dry_run = True
            i += 1
            continue
        if arg == "--json":
            output_json = True
            i += 1
            continue
        if arg == "--rows":
            if i + 1 >= len(args):
                print("Missing value for --rows.", file=sys.stderr)
                return EXIT_USAGE
            rows_value = args[i + 1]
            i += 2
            continue
        if arg.startswith("--rows="):
            rows_value = arg.split("=", 1)[1]
            if not rows_value.strip():
                print("Missing value for --rows.", file=sys.stderr)
                return EXIT_USAGE
            i += 1
            continue
        if arg == "--all":
            run_all = True
            i += 1
            continue
        if arg == "--overwrite":
            print(
                "--overwrite is not supported. Use a different --output path, or use --in-place with --input set to the CSV you want to edit.",
                file=sys.stderr,
            )
            return EXIT_USAGE
        if arg == "--force":
            force_overwrite = True
            i += 1
            continue
        if arg.startswith("--with-force="):
            value = str(arg.split("=", 1)[1])
            if not value:
                print("Missing value for --with-force.", file=sys.stderr)
                return EXIT_USAGE
            for item in value.split(","):
                alias_norm = _normalize_alias(item.strip())
                if alias_norm:
                    with_force_aliases.add(alias_norm)
            i += 1
            continue
        if arg == "--with-force":
            if i + 1 >= len(args):
                print("Missing value for --with-force.", file=sys.stderr)
                return EXIT_USAGE
            for item in str(args[i + 1]).split(","):
                alias_norm = _normalize_alias(item.strip())
                if alias_norm:
                    with_force_aliases.add(alias_norm)
            i += 2
            continue
        if arg == "--with-waterfall":
            if i + 1 >= len(args):
                print("Missing value for --with-waterfall.", file=sys.stderr)
                return EXIT_USAGE
            plan_args.extend([arg, str(args[i + 1])])
            i += 2
            continue
        if arg == "--min-results":
            if i + 1 >= len(args):
                print("Missing value for --min-results.", file=sys.stderr)
                return EXIT_USAGE
            plan_args.extend([arg, str(args[i + 1])])
            i += 2
            continue
        if arg == "--type":
            print("--type has been removed. Put extraction in extract_js on each JSON --with spec.", file=sys.stderr)
            return EXIT_USAGE
        if arg == "--result-getters":
            print("--result-getters has been removed. Put extraction in extract_js on each JSON --with spec.", file=sys.stderr)
            return EXIT_USAGE
        if arg == "--end-waterfall":
            plan_args.append(arg)
            i += 1
            continue
        if arg == "--help" or arg == "-h":
            _print_lines(_usage_enrich())
            return EXIT_OK
        print(f"error: Unknown option: {arg}")
        return EXIT_USAGE

    _enrich_debug(
        env,
        (
            f"arg parse done input={input_path} output={output_path} config={config_path or '(none)'} in_place={in_place} "
            f"dry_run={dry_run} plan_args={len(plan_args)} rows={rows_value or '(default)'} "
            f"run_all={run_all} with_force={sorted(with_force_aliases)}"
        ),
    )
    if config_path and plan_args:
        print("Choose either --config or plan-shaping args like --with/--with-waterfall, not both.", file=sys.stderr)
        return EXIT_USAGE
    if not config_path and not plan_args:
        auth_status = _require_api_key(env)
        print("Provide either --config or at least one --with spec.")
        return auth_status if auth_status is not None else EXIT_USAGE
    if in_place and output_path:
        print("--in-place and --output cannot both be used together.")
        return EXIT_USAGE
    if in_place and dry_run:
        print("--in-place is not supported with --dry-run.")
        return EXIT_USAGE
    if rows_value and run_all:
        print("Choose one of --rows or --all.", file=sys.stderr)
        return EXIT_USAGE

    _enrich_debug(env, "compile path: server compile required")
    try:
        compiled_config = _compile_enrich_config_via_server(
            base_url,
            env,
            config=_load_enrich_config_jsonc(config_path) if config_path else None,
            plan_args=_prepare_plan_args_for_server_compile(plan_args) if not config_path else None,
        )
        checked_config = compiled_config
    except ValueError as exc:
        print("ERROR: enrich compile failed before execution.", file=sys.stderr)
        print(str(exc), file=sys.stderr)
        return EXIT_USAGE

    parsed_specs_runtime = _runtime_specs_from_compiled_config(checked_config)
    with_force_aliases = _expand_with_force_aliases_for_waterfall_children(parsed_specs_runtime, with_force_aliases)
    expansion_preview = []
    compiled_expansion_preview = compiled_config.get("_expansion_preview")
    if isinstance(compiled_expansion_preview, dict):
        plays = compiled_expansion_preview.get("plays")
        if isinstance(plays, list):
            expansion_preview = [play for play in plays if isinstance(play, dict)]
    _enrich_debug(
        env,
        f"compiled enrich config commands={len(checked_config.get('commands') or [])} runtime_specs={len(parsed_specs_runtime)} plays={len(expansion_preview)}",
    )
    config_sidecar_path = _persist_enrich_config_sidecar(
        compiled_config,
        input_path=input_path,
        output_path=output_path,
        dry_run=dry_run,
    )
    _enrich_debug(env, f"saved enrich config sidecar path={config_sidecar_path}")

    output_path_is_temp = False
    if in_place:
        output_path = input_path
    elif not output_path:
        output_dir = _ensure_persistent_data_dir()
        if dry_run:
            output_path = str(output_dir / f"deepline-enrich-dry-run-{os.getpid()}-{int(os.times().elapsed * 1000)}.csv")
            output_path_is_temp = True
        else:
            output_path = str(output_dir / "deepline-enrich-output.csv")
    if not rows_value and not run_all:
        if dry_run:
            rows_value = "0:1"
        else:
            run_all = True

    input_path = _normalize_path(input_path)
    output_path = _normalize_path(output_path)
    if not in_place and _same_file_path(input_path, output_path):
        print("--input and --output must be different files when not using --in-place.", file=sys.stderr)
        return EXIT_USAGE
    if os.path.exists(output_path) and not Path(output_path).is_file():
        print(f"--output path exists and is not a regular file: {output_path}", file=sys.stderr)
        return EXIT_USAGE

    source_csv_path = input_path
    if not in_place and Path(output_path).is_file():
        ok, messages = _validate_output_path_available(output_path)
        if not ok:
            for line in messages:
                print(line, file=sys.stderr)
            return EXIT_USAGE
    _enrich_debug(
        env,
        f"paths resolved input={input_path} source_csv={source_csv_path} output={output_path} output_exists={Path(output_path).is_file()}",
    )

    fieldnames, source_rows = _load_compacted_csv(source_csv_path)
    if not fieldnames and not source_rows:
        fieldnames = []
    row_count = len(source_rows)
    max_row_index = max(0, row_count - 1)
    parse_max_end = max_row_index
    row_start, row_end = (0, max_row_index)
    if rows_value:
        try:
            row_start, row_end = _parse_rows_arg(rows_value, parse_max_end)
        except ValueError as exc:
            message = str(exc)
            if "end must be >=" in message:
                print("Invalid --rows range: end must be >= start", file=sys.stderr)
            else:
                print(
                    f"Invalid --rows value: {rows_value} (expected start:end or start:, e.g. 0:49 or 2:).",
                    file=sys.stderr,
                )
            if output_path_is_temp:
                try:
                    os.remove(output_path)
                except Exception:
                    pass
            return EXIT_USAGE

    auth_status = _require_api_key(env)
    if not has_input:
        print("Missing --input path (or --csv alias).")
        return auth_status if auth_status is not None else EXIT_USAGE
    if not Path(input_path).is_file():
        print(f"CSV file not found: {input_path}")
        return auth_status if auth_status is not None else EXIT_USAGE

    lock_dir = ""
    if not dry_run:
        lock_dir = f"{output_path}.deepline.lock"
        try:
            os.mkdir(lock_dir)
        except FileExistsError:
            print(f"Output is locked by another enrich run: {output_path}", file=sys.stderr)
            print(f"Lock path: {lock_dir}", file=sys.stderr)
            return EXIT_USAGE
        _enrich_debug(env, f"lock acquired path={lock_dir}")

    tool_meta_cache: Dict[str, Dict[str, Any]] = {}
    for spec in parsed_specs_runtime:
        if not isinstance(spec, dict):
            continue
        if str(spec.get("waterfall_mode") or "").strip() != "list":
            continue
        if str(spec.get("extract_js") or "").strip() != "out":
            continue
        spec["extract_js"] = "out==null?[]:[out]"
    existing_columns = {
        str(spec.get("column") or "").strip()
        for spec in parsed_specs_runtime
        if isinstance(spec, dict)
    }
    for play in expansion_preview:
        if not isinstance(play, dict):
            continue
        alias = str(play.get("alias") or "").strip()
        if not alias:
            continue
        steps = [step for step in (play.get("steps") or []) if isinstance(step, dict)]
        if not steps:
            continue
        step_columns = [
            str(step.get("column") or "").strip()
            for step in steps
            if str(step.get("column") or "").strip()
        ]
        if not step_columns:
            continue
        resolver_payload = {
            "code": (
                "for (const col of "
                + json.dumps(step_columns)
                + ") {"
                + "const v = row[col];"
                + "if (Array.isArray(v)) {"
                + "for (const item of v) {"
                + "if (item === null || item === undefined) continue;"
                + "if (typeof item === 'string' && item.trim() === '') continue;"
                + "return item;"
                + "}"
                + "continue;"
                + "}"
                + "if (v === null || v === undefined) continue;"
                + "if (typeof v === 'string' && v.trim() === '') continue;"
                + "return v;"
                + "}"
                + "return null;"
            )
        }
        if alias in existing_columns:
            with_force_aliases.add(_normalize_alias(alias))
            updated_existing = False
            for spec in parsed_specs_runtime:
                if not isinstance(spec, dict):
                    continue
                if str(spec.get("column") or "").strip() != alias:
                    continue
                spec["tool_ref"] = "run_javascript"
                spec["tool_id"] = "run_javascript"
                spec["payload"] = resolver_payload
                spec["extract_js"] = ""
                spec["group"] = ""
                spec["waterfall_mode"] = "scalar"
                spec["waterfall_min_results"] = None
                spec["force_overwrite"] = True
                spec["synthetic_waterfall_output"] = True
                updated_existing = True
            if not updated_existing:
                existing_columns.discard(alias)
                continue
            continue
        parsed_specs_runtime.append(
            {
                "column": alias,
                "tool_ref": "run_javascript",
                "tool_id": "run_javascript",
                "payload": resolver_payload,
                "extract_js": "",
                "group": "",
                "waterfall_mode": "scalar",
                "waterfall_min_results": None,
                "force_overwrite": True,
                "synthetic_waterfall_output": True,
            }
        )
        with_force_aliases.add(_normalize_alias(alias))
        existing_columns.add(alias)
    if expansion_preview and not output_json:
        _print_play_expansion_preview(expansion_preview)
    if dry_run:
        headers = fieldnames
        data_rows = source_rows
        row_count = len(data_rows)

        preview_aliases = [str(spec.get("column") or "").strip() for spec in parsed_specs_runtime if str(spec.get("column") or "").strip()]
        preview_headers = list(headers) + [a for a in preview_aliases if a not in headers]

        added_specs: list[dict[str, Any]] = []
        run_columns: list[dict[str, Any]] = []
        for idx, spec in enumerate(parsed_specs_runtime):
            column = str(spec.get("column") or "").strip()
            if not column:
                continue
            tool_id = str(spec.get("tool_id") or "")
            tool_ref = str(spec.get("tool_ref") or tool_id)
            payload = spec.get("payload") if isinstance(spec.get("payload"), dict) else {}
            added_specs_item = {
                "col_index": len(headers) + idx,
                "column": column,
                "tool_ref": tool_ref,
                "tool_id": tool_id,
                "operation": tool_id,
                "payload": payload,
                "extract_js": str(spec.get("extract_js") or ""),
                "run_if_js": str(spec.get("run_if_js") or ""),
                "source": "added",
                "mapped_fields": [],
                "auto_corrections": [],
                "skipped_auto_mappings": [],
                "group": str(spec.get("group") or ""),
                "waterfall_mode": str(spec.get("waterfall_mode") or "scalar"),
                "waterfall_min_results": spec.get("waterfall_min_results"),
                "waterfall_group_id": "",
                "waterfall_step_index": None,
                "force_overwrite": False,
            }
            added_specs.append(added_specs_item)
            run_columns.append(dict(added_specs_item))

        preview_window = data_rows[row_start:row_end] if row_end > row_start else []
        preview_ascii_rows = [
            [str(row.get(header, "")) for header in preview_headers]
            for row in preview_window[: min(5, len(preview_window))]
        ]
        preview_rows = []
        for idx, row in enumerate(preview_window):
            entry = {"__row": str(row_start + idx)}
            for hidx, header in enumerate(headers):
                entry[header] = _compact_text(row.get(header, ""), 28)
            for col in preview_aliases:
                if col not in entry:
                    entry[col] = ""
            preview_rows.append(entry)

        payload = {
            "status": "completed",
            "dry_run": True,
            "summary": {
                "input_csv_path": input_path,
                "source_csv_path": input_path,
                "csv_path": output_path,
                "added": added_specs,
                "updated": [],
                "skipped": [],
                "run_columns": run_columns,
                "run_count": len(added_specs),
                "added_count": len(added_specs),
                "updated_count": 0,
                "skipped_count": 0,
                "row_count": row_count,
                "skipped_auto_mappings": [],
                "tool_samples": [{"tool_id": str(s.get("tool_id") or ""), "tool_ref": str(s.get("tool_ref") or s.get("tool_id") or ""), "sample_payload": None} for s in parsed_specs_runtime if str(s.get("tool_id") or "").strip()],
                "dry_run": True,
            },
            "preview": {
                "row_start": row_start,
                "row_end": row_end,
                "row_count": len(preview_window),
                "columns": preview_headers,
                "rows": preview_rows,
            },
            "ascii": _render_ascii(preview_headers, preview_ascii_rows[:1]).replace("\n", "\\n"),
            "provider_samples": [{"tool_id": str(s.get("tool_id") or ""), "tool_ref": str(s.get("tool_ref") or s.get("tool_id") or ""), "sample_payload": None} for s in parsed_specs_runtime if str(s.get("tool_id") or "").strip()],
        }
        if expansion_preview:
            payload["expansion_preview"] = {"plays": expansion_preview}
        payload["config_path"] = config_sidecar_path
        if output_json:
            print(json.dumps(payload))
        else:
            print("Dry-run validation complete.")
            print(f"Rows: {row_count}")
            print(f"Columns added: {len(added_specs)}")
            for line in _play_expansion_summary_lines(expansion_preview):
                print(line)
            print(f"Rerun this with: {_enrich_rerun_hint(input_path, output_path, config_sidecar_path, in_place)}")
            if preview_ascii_rows:
                print(_render_ascii(preview_headers, preview_ascii_rows))
            else:
                print("ASCII Preview: CSV has no data rows.")
        with open(output_path, "w", encoding="utf-8", newline="") as out:
            writer = csv.writer(out)
            writer.writerow(preview_headers)
            for row in data_rows:
                values = [row.get(header, "") for header in headers]
                writer.writerow(values + [""] * max(0, len(preview_headers) - len(headers)))
        if output_path_is_temp:
            try:
                os.remove(output_path)
            except Exception:
                pass
        _release_output_lock(lock_dir)
        return EXIT_OK

    parsed_specs: list[Dict[str, Any]] = list(parsed_specs_runtime)
    if with_force_aliases:
        known_aliases = {_normalize_alias(str(spec.get("column") or "")) for spec in parsed_specs}
        unknown = sorted(a for a in with_force_aliases if a not in known_aliases)
        if unknown:
            print(f"--with-force references unknown --with column alias(es): {', '.join(unknown)}.", file=sys.stderr)
            _release_output_lock(lock_dir)
            return EXIT_USAGE

    resolved_ops: Dict[str, str] = {}
    preflight_schema_cache: Dict[str, list[Dict[str, Any]]] = {}
    for spec in parsed_specs:
        tool_id = str(spec.get("tool_id") or "")
        if not tool_id:
            print("Compiled spec missing tool_id.", file=sys.stderr)
            _release_output_lock(lock_dir)
            return EXIT_SERVER
        resolved_tool_id = tool_id
        schema_fields = spec.get("schema_fields")
        cached_meta = tool_meta_cache.get(resolved_tool_id)
        op = str(spec.get("operation") or "").strip()
        if not op and isinstance(cached_meta, dict):
            op = str(cached_meta.get("operation") or "").strip()
        if not op:
            op = resolved_tool_id
        spec["operation"] = op
        resolved_ops[resolved_tool_id] = op
        if not isinstance(schema_fields, list):
            if isinstance(cached_meta, dict):
                schema_fields = cached_meta.get("schema_fields")
                if not spec.get("input_schema") and isinstance(cached_meta.get("input_schema"), dict):
                    spec["input_schema"] = cached_meta.get("input_schema")
                if not spec.get("list_extractor_paths") and isinstance(cached_meta.get("list_extractor_paths"), list):
                    spec["list_extractor_paths"] = cached_meta.get("list_extractor_paths")
                if not spec.get("result_identity_getters") and isinstance(cached_meta.get("result_identity_getters"), dict):
                    spec["result_identity_getters"] = cached_meta.get("result_identity_getters")
                if spec.get("sample_response") is None and cached_meta.get("sample_response") is not None:
                    spec["sample_response"] = cached_meta.get("sample_response")
                if not spec.get("output_schema") and isinstance(cached_meta.get("output_schema"), dict):
                    spec["output_schema"] = cached_meta.get("output_schema")
        if isinstance(schema_fields, list):
            preflight_schema_cache[resolved_tool_id] = [f for f in schema_fields if isinstance(f, dict)]
    _enrich_debug(env, f"tool resolve done parsed_specs={len(parsed_specs)} resolved_ops={sorted(resolved_ops.keys())}")

    _enrich_debug(env, f"csv loaded source_rows={len(source_rows)} field_count={len(fieldnames)}")

    _enrich_debug(env, "running preflight payload/interpolation validation")
    payload_errors, interpolation_errors = _validate_specs_preflight(
        base_url,
        env,
        parsed_specs,
        fieldnames,
        source_rows,
        preflight_schema_cache,
    )
    if payload_errors:
        print("Payload type check failed for one or more --with blocks:", file=sys.stderr)
        for err in payload_errors:
            print(f"  - {err}", file=sys.stderr)
        _release_output_lock(lock_dir)
        return EXIT_USAGE
    if interpolation_errors:
        print("Interpolation validation failed for one or more --with blocks:", file=sys.stderr)
        for err in interpolation_errors:
            print(f"  - {err}", file=sys.stderr)
        available = [h for h in fieldnames if h and h != "_metadata"]
        if available:
            print(f"  Available columns: {available}", file=sys.stderr)
        _release_output_lock(lock_dir)
        return EXIT_USAGE
    _enrich_debug(env, "preflight validation passed")

    run_columns_summary: list[Dict[str, Any]] = []
    added_specs_summary: list[Dict[str, Any]] = []
    updated_specs_summary: list[Dict[str, Any]] = []
    group_step_indexes: Dict[str, int] = {}

    for spec in parsed_specs:
        column = str(spec.get("column") or "")
        alias_norm = _normalize_alias(column)
        existing_column = False
        for h in fieldnames:
            if _normalize_alias(_parse_existing_display_name(h)) == alias_norm:
                existing_column = True
                break
        group_name = str(spec.get("group") or "").strip()
        waterfall_group_id = _build_waterfall_group_id(group_name) if group_name else ""
        waterfall_step_index = None
        if waterfall_group_id:
            waterfall_step_index = group_step_indexes.get(waterfall_group_id, 0)
            group_step_indexes[waterfall_group_id] = waterfall_step_index + 1

        if not existing_column:
            fieldnames.append(spec["column"])
        if group_name and group_name not in fieldnames:
            fieldnames.append(group_name)
        if group_name:
            source_column = f"{_normalize_waterfall_name_key(group_name)}_source"
            if source_column not in fieldnames:
                fieldnames.append(source_column)

        mapped_fields = sorted({
            p.split(".", 1)[0]
            for p in _collect_template_paths(spec.get("payload") or {})
            if p.strip()
        })
        item = {
            "col_index": _playground_col_index(fieldnames, column),
            "column": column,
            "tool_ref": str(spec.get("tool_id") or ""),
            "tool_id": str(spec.get("tool_id") or ""),
            "operation": str(spec.get("operation") or spec.get("tool_id") or ""),
            "payload": spec.get("payload"),
            "extract_js": str(spec.get("extract_js") or ""),
            "run_if_js": str(spec.get("run_if_js") or ""),
            "source": "updated" if existing_column else "added",
            "mapped_fields": mapped_fields,
            "auto_corrections": [],
            "skipped_auto_mappings": [],
            "group": group_name,
            "waterfall_mode": str(spec.get("waterfall_mode") or "scalar"),
            "waterfall_min_results": spec.get("waterfall_min_results"),
            "waterfall_group_id": waterfall_group_id,
            "waterfall_step_index": waterfall_step_index,
            "force_overwrite": bool(force_overwrite or (alias_norm in with_force_aliases)),
            "synthetic_waterfall_output": bool(spec.get("synthetic_waterfall_output")),
        }
        run_columns_summary.append(dict(item))
        if existing_column:
            updated_specs_summary.append(dict(item))
        else:
            added_specs_summary.append(dict(item))

        spec["source"] = item["source"]
        spec["operation"] = item["operation"]
        spec["waterfall_group_id"] = item["waterfall_group_id"]
        spec["waterfall_step_index"] = item["waterfall_step_index"]
        spec["force_overwrite"] = item["force_overwrite"]
    _enrich_debug(
        env,
        (
            f"column plan built run_columns={len(run_columns_summary)} added={len(added_specs_summary)} "
            f"updated={len(updated_specs_summary)}"
        ),
    )
    if "_metadata" not in fieldnames:
        fieldnames.append("_metadata")

    # Enforce requested --with column order (including existing columns) while
    # preserving the relative order of all non-requested columns.
    requested_columns = _build_requested_column_order(fieldnames, parsed_specs)
    if requested_columns:
        remaining = [name for name in fieldnames if name not in requested_columns]
        fieldnames = remaining + [name for name in requested_columns if name in fieldnames]
    for item in run_columns_summary:
        col = str(item.get("column") or "")
        if col in fieldnames:
            item["col_index"] = _playground_col_index(fieldnames, col)
    for item in added_specs_summary:
        col = str(item.get("column") or "")
        if col in fieldnames:
            item["col_index"] = _playground_col_index(fieldnames, col)
    for item in updated_specs_summary:
        col = str(item.get("column") or "")
        if col in fieldnames:
            item["col_index"] = _playground_col_index(fieldnames, col)

    executable_run_columns_summary = [
        dict(item)
        for item in run_columns_summary
        if not bool(item.get("synthetic_waterfall_output"))
    ]
    _enrich_debug(
        env,
        (
            f"column execution plan executable_run_columns={len(executable_run_columns_summary)} "
            f"synthetic_run_columns={len(run_columns_summary) - len(executable_run_columns_summary)}"
        ),
    )

    metadata_columns: Dict[str, Dict[str, Any]] = {}
    for row in source_rows:
        parsed_columns = _parse_metadata_columns(row.get("_metadata"))
        for alias, meta in parsed_columns.items():
            if alias not in metadata_columns:
                metadata_columns[alias] = dict(meta)
    for spec in parsed_specs:
        alias = _normalize_alias(str(spec.get("column") or ""))
        if not alias:
            continue
        prior = metadata_columns.get(alias)
        next_meta = dict(prior) if isinstance(prior, dict) else {}
        next_meta.update(_build_metadata_entry(spec))
        metadata_columns[alias] = next_meta

    # Keep previously persisted metadata entries, even when the current run
    # targets only a subset of columns. Pruning to the current header set can
    # drop waterfall metadata on untouched aliases during reruns.
    metadata_template = {"version": 2, "columns": metadata_columns}

    _enrich_debug(env, f"row range resolved row_start={row_start} row_end={row_end}")

    interrupted = False
    prev_int = None
    prev_term = None

    def _sig_handler(_signum: int, _frame: Any) -> None:
        nonlocal interrupted
        interrupted = True
        raise KeyboardInterrupt()

    prev_int = signal.getsignal(signal.SIGINT)
    prev_term = signal.getsignal(signal.SIGTERM)
    signal.signal(signal.SIGINT, _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)
    failed_jobs: list[Dict[str, Any]] = []
    skipped_count = 0
    dataset_stats_text: str | None = None
    dataset_stats: Dict[str, Any] | None = None
    rate_limit_events: list[Dict[str, Any]] = []

    for row in source_rows:
        row["_metadata"] = ""
    if source_rows:
        source_rows[0]["_metadata"] = json.dumps(metadata_template, ensure_ascii=False)
    with open(output_path, "w", encoding="utf-8", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=fieldnames)
        writer.writeheader()
        for row in source_rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})
    _enrich_debug(env, f"seed output csv written path={output_path} rows={len(source_rows)} field_count={len(fieldnames)}")

    startup_diagnostics: list[Dict[str, Any]] = []
    _enrich_debug(
        env,
        "using backend playground path for run-block execution",
    )
    _enrich_debug(env, "ensuring render/backend runtime before run-block execution")
    startup_diagnostics = _ensure_render_ui_for_enrich(base_url, env, output_path)
    if startup_diagnostics:
        _enrich_debug(env, f"startup diagnostics recorded count={len(startup_diagnostics)}")
    runtime_owner_id = f"py-enrich-{os.getpid()}-{int(time.time() * 1000)}"
    telemetry_run_id = runtime_owner_id
    runtime_started = False
    runtime_api = _playground_default_api()
    extractor_validation_errors = _validate_waterfall_extractors_in_playground(
        source_csv_path,
        parsed_specs_runtime,
        base_url,
        env,
        tool_meta_cache,
    )
    if extractor_validation_errors:
        for line in extractor_validation_errors:
            print(line, file=sys.stderr)
        if lock_dir:
            try:
                os.rmdir(lock_dir)
            except Exception:
                pass
        return EXIT_USAGE
    rows_range_text = f"{row_start}:{row_end}" if row_end >= row_start else ""
    command_text = "deepline enrich " + " ".join(args)
    row_range = max(0, row_end - row_start + 1)
    final_status = "failed"
    started_at = time.time()
    try:
        _emit_enrich_telemetry(
            base_url=base_url,
            env=env,
            event="enrich_started",
            run_id=telemetry_run_id,
            command=command_text,
            rows_range=rows_range_text,
            input_path=input_path,
            async_mode=True,
        )
        _emit_enrich_runtime_state(
            api=runtime_api,
            csv_path=output_path,
            action="start",
            owner_id=runtime_owner_id,
            command=command_text,
            rows_range=rows_range_text,
            force_overwrite=force_overwrite,
            async_mode=True,
        )
        runtime_started = True
        _enrich_debug(env, f"runtime state started owner={runtime_owner_id} rows_range={rows_range_text}")
        print(
            f"Executing {len(executable_run_columns_summary)} target column(s) across row range {row_start}:{row_end} ({row_range} rows)..."
        )
        if force_overwrite:
            print("Overwrite mode enabled: existing non-empty target values will be recomputed.")
        if row_range <= 0:
            print("No rows selected; skipping execution.")
            used_playground, pg_failed, pg_skipped = True, [], 0
        else:
            _enrich_debug(env, "running columns in playground")
            used_playground, pg_failed, pg_skipped = _run_columns_in_playground(
                output_path,
                row_start,
                row_end,
                executable_run_columns_summary,
                force_overwrite,
                telemetry_run_id=telemetry_run_id,
                log_progress=True,
                rate_limit_events=rate_limit_events,
            )
        if not used_playground:
            failed_column_names = [
                str(job.get("column") or "").strip()
                for job in pg_failed
                if str(job.get("column") or "").strip()
            ]
            failed_jobs.extend(job for job in pg_failed if isinstance(job, dict))
            fieldnames, source_rows = _wait_for_backend_output_csv(
                output_path=output_path,
                fieldnames=fieldnames,
                source_rows=source_rows,
                row_start=row_start,
                row_end=row_end,
                expected_columns=[str(item.get("column") or "").strip() for item in executable_run_columns_summary],
                failed_columns=failed_column_names,
            )
            # Persist error strings from failed jobs into the CSV so
            # downstream consumers (csv show --summary, regression tests)
            # see an error value instead of an empty/default cell.
            _persist_failed_column_errors(
                pg_failed, fieldnames, source_rows,
                row_start, row_end, output_path,
            )
            final_status = "failed"
            report_path = _persist_failed_jobs_report(
                failed_jobs,
                api_url=runtime_api,
                output_path=output_path,
                row_start=row_start,
                row_end=row_end,
                command_text=command_text,
            )
            print("Execution failed.", file=sys.stderr)
            _print_failed_jobs_preview(failed_jobs, report_path=report_path)
            if report_path:
                print("Enrichment failed. See failure report above.", file=sys.stderr)
            else:
                print("Enrichment failed.", file=sys.stderr)
            return EXIT_SERVER
        _enrich_debug(
            env,
            f"playground run complete used_playground={used_playground} failed_jobs={len(pg_failed)} skipped={int(pg_skipped or 0)}",
        )
        failed_jobs.extend(pg_failed)
        skipped_count += int(pg_skipped or 0)
        fieldnames, source_rows = _load_compacted_csv(output_path)
        _enrich_debug(env, f"post-run csv reload rows={len(source_rows)} field_count={len(fieldnames)}")
        dataset_max_row = max(0, min(len(source_rows) - 1, 99))
        dataset_stats_text = _enrich_dataset_summary_text(output_path, dataset_max_row)
        if dataset_stats_text:
            try:
                parsed_stats = json.loads(dataset_stats_text)
                dataset_stats = parsed_stats if isinstance(parsed_stats, dict) else None
            except Exception:
                dataset_stats = None
        _enrich_debug(env, f"dataset stats parsed has_stats={bool(dataset_stats_text)}")
        for item in run_columns_summary:
            col = str(item.get("column") or "")
            if col in fieldnames:
                item["col_index"] = _playground_col_index(fieldnames, col)
        _run_cols_by_name = {str(rc.get("column") or "").strip(): rc for rc in run_columns_summary}
        if isinstance(dataset_stats, dict):
            column_stats_map = dataset_stats.get("columnStats")
            miss_reasons_map = dataset_stats.get("miss_reasons")
            miss_details_map = dataset_stats.get("miss_details")
            if isinstance(column_stats_map, dict) and isinstance(miss_reasons_map, dict):
                targeted_rows = (
                    source_rows[row_start : min(len(source_rows), row_end + 1)]
                    if row_end >= row_start
                    else []
                )
                failed_columns = {
                    str(job.get("column") or "").strip()
                    for job in failed_jobs
                    if str(job.get("column") or "").strip()
                }
                for item in run_columns_summary:
                    col = str(item.get("column") or "").strip()
                    if not col or col in failed_columns:
                        continue
                    source_kind = str(item.get("source") or "").strip().lower()
                    rc = _run_cols_by_name.get(col)
                    group_name = str(item.get("group") or "").strip()
                    if not group_name and isinstance(rc, dict):
                        waterfall_cfg = rc.get("waterfall")
                        if isinstance(waterfall_cfg, dict):
                            group_name = str(
                                waterfall_cfg.get("display_name")
                                or waterfall_cfg.get("group")
                                or ""
                            ).strip()
                    if group_name and targeted_rows:
                        group_satisfied = all(
                            _cell_has_success_value(str(row.get(group_name) or ""))
                            for row in targeted_rows
                        )
                        if group_satisfied:
                            continue
                    col_stats = column_stats_map.get(col)
                    miss_stats = miss_reasons_map.get(col)
                    if not isinstance(col_stats, dict) or not isinstance(miss_stats, dict) or not miss_stats:
                        continue
                    non_empty = str(col_stats.get("non_empty") or "").strip()
                    if not non_empty.startswith("0/"):
                        continue
                    # Existing columns can legitimately rerun into a miss-only state
                    # without indicating a broken enrich pass. Step-level execution
                    # has already classified these as non-fatal miss-only outcomes.
                    if source_kind == "updated":
                        continue
                    top_reason = next((str(reason).strip() for reason in miss_stats.keys() if str(reason).strip()), "missed")
                    detail_suffix = ""
                    if isinstance(miss_details_map, dict):
                        detail_by_reason = miss_details_map.get(col)
                        if isinstance(detail_by_reason, dict):
                            reason_detail = detail_by_reason.get(top_reason)
                            if isinstance(reason_detail, dict):
                                examples = reason_detail.get("examples")
                                if isinstance(examples, list):
                                    for example in examples:
                                        if not isinstance(example, dict):
                                            continue
                                        example_detail = _compact_text(str(example.get("detail") or "").strip(), 160)
                                        if example_detail:
                                            detail_suffix = f" Example: {example_detail}."
                                            break
                    if group_name:
                        continue
                    waterfall_hint = ""
                    failed_jobs.append(
                        {
                            "job_id": f"summary-miss-{col}",
                            "row_id": int(row_start),
                            "column": col,
                            "last_error": f"All targeted rows missed; top reason: {top_reason}.{detail_suffix}{waterfall_hint}",
                        }
                    )
                    failed_columns.add(col)

            # Warn when extract_js produced objects instead of scalars (independent of miss detection)
            if isinstance(column_stats_map, dict):
                for col_name, col_stats in column_stats_map.items():
                    if not isinstance(col_stats, dict):
                        continue
                    st = str(col_stats.get("sample_type") or "").strip()
                    rc = _run_cols_by_name.get(col_name)
                    if not rc or not str(rc.get("extract_js") or "").strip():
                        continue
                    # Intermediate waterfall step columns store full response objects by design
                    if str(rc.get("group") or "").strip():
                        continue
                    if not _extract_js_warning_needed(
                        col_stats.get("sample_value"),
                        st,
                    ):
                        continue
                    tool_id = str(rc.get("tool_id") or "unknown")
                    print(
                        f"Warning: extract_js for column '{col_name}' returned an {st} instead of a scalar string. "
                        f"You may need to drill deeper into the response. "
                        f"Run `deepline tools get {tool_id}` to see the response shape.",
                        file=sys.stderr,
                    )


        final_status = "completed_with_failures" if failed_jobs else "completed"
    except KeyboardInterrupt:
        print("Interrupt received; canceling in-flight jobs for CSV context...", file=sys.stderr)
        api = _playground_default_api()
        try:
            s_code, snap = _playground_api_request("GET", api, "/api/snapshot", None, output_path)
            if s_code < 400:
                snap_data = json.loads(snap)
                for col in snap_data.get("columns") or []:
                    if not isinstance(col, dict):
                        continue
                    if not bool(col.get("is_block")):
                        continue
                    col_idx = col.get("col_index")
                    if isinstance(col_idx, int) and col_idx >= 0:
                        _playground_api_request("POST", api, "/api/stop-column", {"col": col_idx}, output_path)
        except Exception:
            pass
        interrupted = True
        final_status = "interrupted"
        _enrich_debug(env, "keyboard interrupt handled; attempting stop-column for running blocks")
    finally:
        if final_status == "failed" and interrupted:
            final_status = "interrupted"
        if runtime_started:
            _emit_enrich_runtime_state(
                api=runtime_api,
                csv_path=output_path,
                action="stop",
                owner_id=runtime_owner_id,
                reason=final_status if not interrupted else "interrupted",
                force=True,
                # Final stop-state dispatch must finish before process exit.
                async_mode=False,
            )
            _enrich_debug(env, f"runtime state stopped owner={runtime_owner_id} status={final_status}")
        if Path(output_path).is_file():
            try:
                latest_fieldnames, latest_rows = _load_compacted_csv(output_path)
                if latest_fieldnames or latest_rows:
                    fieldnames = latest_fieldnames
                    source_rows = latest_rows
                    _enrich_debug(env, f"final csv reload path={output_path} rows={len(source_rows)} field_count={len(fieldnames)}")
            except Exception:
                pass
        play_aliases = {
            str(play.get("alias") or "").strip()
            for play in expansion_preview
            if isinstance(play, dict) and str(play.get("alias") or "").strip()
        }
        if play_aliases and source_rows:
            flattened_any = False
            for row in source_rows:
                if not isinstance(row, dict):
                    continue
                for alias in play_aliases:
                    raw = row.get(alias)
                    if isinstance(raw, list) and len(raw) == 1 and isinstance(raw[0], (str, int, float, bool)):
                        row[alias] = str(raw[0])
                        flattened_any = True
                        continue
                    if not isinstance(raw, str):
                        continue
                    text = raw.strip()
                    if not (text.startswith("[") and text.endswith("]")):
                        continue
                    try:
                        parsed = json.loads(text)
                    except Exception:
                        continue
                    if isinstance(parsed, list) and len(parsed) == 1 and isinstance(parsed[0], (str, int, float, bool)):
                        row[alias] = str(parsed[0])
                        flattened_any = True
            if flattened_any:
                try:
                    _write_csv(output_path, fieldnames, source_rows)
                except Exception:
                    pass
        _display_fields = [f for f in fieldnames if f and f != "_metadata" and not f.startswith("_")]
        _sample_cols = _display_fields[:16]
        _sample_source_rows = source_rows[row_start : min(len(source_rows), row_end)] if row_end > row_start else []
        if not _sample_source_rows:
            _sample_source_rows = source_rows
        _sample_rows: list[Dict[str, str]] = [
            {k: _compact_text(str(row.get(k, "") or ""), 60) for k in _sample_cols}
            for row in _sample_source_rows[:2]
        ]
        _failure_samples: list[Dict[str, Any]] = []
        for job in failed_jobs[:3]:
            if not isinstance(job, dict):
                continue
            column = _compact_text(str(job.get("column") or ""), 80)
            last_error = str(job.get("last_error") or "Unknown failure").strip() or "Unknown failure"
            row_id_raw = job.get("row_id")
            row_id = int(row_id_raw) if isinstance(row_id_raw, int) and row_id_raw >= 0 else None
            _failure_samples.append(
                {
                    "column": column or "(unknown_column)",
                    "last_error": last_error,
                    "row_id": row_id,
                }
            )
        _emit_enrich_telemetry(
            base_url=base_url,
            env=env,
            event="enrich_completed",
            run_id=telemetry_run_id,
            command=command_text,
            rows_range=rows_range_text,
            input_path=input_path,
            summary={
                "status": final_status,
                "rows_targeted": int(max(0, row_range)),
                "columns_targeted": int(max(0, len(executable_run_columns_summary))),
                "failed_jobs": int(max(0, len(failed_jobs))),
                "skipped_cells": int(max(0, skipped_count)),
                "duration_ms": int(max(0, round((time.time() - started_at) * 1000))),
                "waterfall_sources": _summarize_waterfall_sources(
                    run_columns_summary,
                    source_rows,
                    row_start,
                    row_end,
                ),
                "column_results": _summarize_column_results(
                    run_columns_summary,
                    source_rows,
                    row_start,
                    row_end,
                ),
                "rate_limits": _summarize_rate_limit_stats(
                    failed_jobs,
                    rate_limit_events,
                ),
            },
            sample_rows=_sample_rows if _sample_rows else None,
            failure_samples=_failure_samples if _failure_samples else None,
            # Final completion telemetry must finish before process exit.
            async_mode=False,
        )
        if lock_dir:
            try:
                os.rmdir(lock_dir)
            except Exception:
                pass
            else:
                _enrich_debug(env, f"lock released path={lock_dir}")
        if prev_int is not None:
            signal.signal(signal.SIGINT, prev_int)
        if prev_term is not None:
            signal.signal(signal.SIGTERM, prev_term)

    final_play_aliases = {
        str(play.get("alias") or "").strip()
        for play in expansion_preview
        if isinstance(play, dict) and str(play.get("alias") or "").strip()
    }
    if final_play_aliases and source_rows:
        normalize_changed = False
        for row in source_rows:
            if not isinstance(row, dict):
                continue
            for alias in final_play_aliases:
                raw = row.get(alias)
                if isinstance(raw, list) and len(raw) == 1 and isinstance(raw[0], (str, int, float, bool)):
                    row[alias] = str(raw[0])
                    normalize_changed = True
                    continue
                if not isinstance(raw, str):
                    continue
                text = raw.strip()
                if not (text.startswith("[") and text.endswith("]")):
                    continue
                try:
                    parsed = json.loads(text)
                except Exception:
                    continue
                if isinstance(parsed, list) and len(parsed) == 1 and isinstance(parsed[0], (str, int, float, bool)):
                    row[alias] = str(parsed[0])
                    normalize_changed = True
        if normalize_changed:
            try:
                _write_csv(output_path, fieldnames, source_rows)
            except Exception:
                pass

    if output_json:
        preview_headers = [h for h in fieldnames if h and h != "_metadata"]
        preview_window = source_rows[row_start:row_end] if row_end > row_start else []
        preview_rows: list[Dict[str, Any]] = []
        for idx, row in enumerate(preview_window):
            item: Dict[str, Any] = {"__row": row_start + idx}
            for header in preview_headers:
                item[header] = row.get(header, "")
            preview_rows.append(item)
        payload: Dict[str, Any] = {
            "status": final_status,
            "ok": (not interrupted) and (len(failed_jobs) == 0),
            "csv_path": output_path,
            "failed_jobs": failed_jobs,
            "skipped_count": skipped_count,
            "row_start": row_start,
            "row_end": row_end,
            "preview": {
                "row_start": row_start,
                "row_end": row_end,
                "row_count": len(preview_window),
                "columns": preview_headers,
                "rows": preview_rows,
            },
        }
        if isinstance(dataset_stats, dict):
            payload["dataset_stats"] = dataset_stats
        if expansion_preview:
            payload["expansion_preview"] = {"plays": expansion_preview}
        payload["config_path"] = config_sidecar_path
        print(json.dumps(payload))
    else:
        print(f"Results written to: {output_path}")
        for line in _play_expansion_summary_lines(expansion_preview):
            print(line)
        print(
            "Rerun with saved config: "
            f"{_enrich_rerun_hint(input_path, output_path, config_sidecar_path, in_place)}"
        )
        display_url = _playground_render_display_url(output_path)
        if display_url:
            print(f"Open playground: {display_url}")
            # Temporarily disable auto-opening the browser on enrich completion.
        if dataset_stats_text:
            print(dataset_stats_text)
        if interrupted:
            print("Enrichment canceled.")
        elif failed_jobs:
            print("Enrichment completed with failures.")
            report_path = _persist_failed_jobs_report(
                failed_jobs,
                api_url=runtime_api,
                output_path=output_path,
                row_start=row_start,
                row_end=row_end,
                command_text=command_text,
            )
            _print_failed_jobs_preview(failed_jobs, report_path=report_path)
        else:
            print("Enrichment complete.")
        print(f"Run `deepline csv show --csv {output_path}` for full output.")
    # Register output with session UI including provider/cost meta
    try:
        _enrich_meta: Dict[str, Any] = {
            "duration_ms": int(max(0, round((time.time() - started_at) * 1000))),
        }
        # Build provider breakdown from waterfall source columns
        _provider_counts: Dict[str, int] = {}
        _waterfall_sources = _summarize_waterfall_sources(
            run_columns_summary, source_rows, row_start, row_end,
        )
        for ws in _waterfall_sources:
            for src_name, src_count in (ws.get("per_source_counts") or {}).items():
                label = str(src_name).strip()
                if label and isinstance(src_count, (int, float)) and src_count > 0:
                    _provider_counts[label] = _provider_counts.get(label, 0) + int(src_count)
        # Fallback: extract provider from tool_id in run_columns if no waterfall
        if not _provider_counts:
            for item in run_columns_summary:
                if not isinstance(item, dict):
                    continue
                tool_id = str(item.get("tool_id") or item.get("tool_ref") or "").strip()
                if tool_id:
                    provider = tool_id.split("/")[0] if "/" in tool_id else tool_id.split(".")[0]
                    _provider_counts[provider] = _provider_counts.get(provider, 0) + 1
        if _provider_counts:
            _enrich_meta["providers"] = _provider_counts
        _meta_json = json.dumps(_enrich_meta)
        _session_id = _resolve_playground_link_session_id()
        _playground_api_request(
            "POST",
            runtime_api,
            "/api/cli-event",
            {
                "action": "append_event",
                "csv_path": output_path,
                "status": "completed",
                "message": Path(output_path).stem,
                "source": "cli_output",
                "meta": _enrich_meta,
                "session_id": _session_id,
            },
            output_path,
            timeout=2,
        )
        _enrich_debug(env, f"session output registered session_id={_session_id} meta={_meta_json}")
    except Exception:
        _enrich_debug(env, "session output registration failed (non-fatal)")

    if interrupted:
        _enrich_debug(env, "cmd_enrich interrupted -> exit 130")
        return 130
    rc = EXIT_OK if not failed_jobs else EXIT_VALIDATION
    _enrich_debug(env, f"cmd_enrich end rc={rc} failed_jobs={len(failed_jobs)}")
    return rc


def handle(base_url: str, env: Dict[str, str], args: list[str]) -> int:
    if "--help" in args or "-h" in args:
        _print_lines(_usage_enrich())
        return EXIT_OK
    return cmd_enrich(base_url, env, args)
