# __init__.py
from .session import SmartSession as smart_session

__all__ = ["smart_session"]