"""Core plugin — tracks update entities and autoposts to TOP.TL."""

from __future__ import annotations

import functools
import logging
from typing import Any, Awaitable, Callable, Optional

from telegram import Update
from telegram.ext import Application, ContextTypes, TypeHandler
from toptl import AsyncTopTL

logger = logging.getLogger(__name__)


class TopTLPlugin:
    """State for an installed TOP.TL plugin.

    Don't instantiate this directly — call :func:`setup_toptl`, which
    wires the tracker and job queue for you and returns the plugin
    handle.

    The plugin exposes:

    * ``user_count`` / ``group_count`` / ``channel_count`` — live counts
      collected since process start.
    * :meth:`has_voted` — thin wrapper around ``AsyncTopTL.has_voted``
      returning a plain ``bool`` so you can treat the result as a gate.
    * :meth:`post_now` — immediately flush current counts, useful from
      a graceful-shutdown hook.
    """

    def __init__(self, client: AsyncTopTL, username: str) -> None:
        self._client = client
        self._username = username
        self._user_ids: set[int] = set()
        self._group_ids: set[int] = set()
        self._channel_ids: set[int] = set()
        # Last (member, group, channel) snapshot we posted, so we skip
        # ticks when nothing changed.
        self._last_post: tuple[int, int, int] | None = None

    # ------------------------------------------------------------------
    # Counts
    # ------------------------------------------------------------------

    @property
    def user_count(self) -> int:
        return len(self._user_ids)

    @property
    def group_count(self) -> int:
        return len(self._group_ids)

    @property
    def channel_count(self) -> int:
        return len(self._channel_ids)

    # ------------------------------------------------------------------
    # Internal — registered as a TypeHandler by setup_toptl
    # ------------------------------------------------------------------

    async def _track(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.effective_user:
            self._user_ids.add(update.effective_user.id)
        chat = update.effective_chat
        if chat:
            # 'group' and 'supergroup' are both group-class chats per the
            # Bot API; 'channel' and 'private' are the other two.
            if chat.type in ("group", "supergroup"):
                self._group_ids.add(chat.id)
            elif chat.type == "channel":
                self._channel_ids.add(chat.id)

    # ------------------------------------------------------------------
    # Internal — registered on the JobQueue
    # ------------------------------------------------------------------

    async def _post_job(self, context: ContextTypes.DEFAULT_TYPE) -> None:
        await self.post_now()

    async def post_now(self) -> None:
        """Flush the current counts to TOP.TL. Idempotent when unchanged."""
        snapshot = (self.user_count, self.group_count, self.channel_count)
        if snapshot == self._last_post:
            return
        try:
            await self._client.post_stats(
                self._username,
                member_count=snapshot[0],
                group_count=snapshot[1],
                channel_count=snapshot[2],
            )
            self._last_post = snapshot
        except Exception:
            # post_stats already swallows network failures at the SDK
            # level when it retries; anything reaching here is a real
            # error that we log but don't propagate — the bot keeps
            # running.
            logger.exception("toptl-ptb: post_stats failed for @%s", self._username)

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    async def has_voted(self, user_id: int) -> bool:
        """True iff ``user_id`` has voted for this listing on TOP.TL.

        Failures (network, auth) return False — the vote gate is never a
        reason to brick your bot. Log them separately if you want.
        """
        try:
            result = await self._client.has_voted(self._username, user_id)
            return bool(result.voted)
        except Exception:
            logger.exception("toptl-ptb: has_voted failed for %s", user_id)
            return False


def setup_toptl(
    application: Application,
    client: AsyncTopTL,
    username: str,
    *,
    interval_seconds: float = 30 * 60,
    first_seconds: float = 30,
    handler_group: int = -100,
) -> TopTLPlugin:
    """Install the plugin on a PTB ``Application``.

    Parameters
    ----------
    application
        Built from ``ApplicationBuilder().token(...).build()``.
    client
        An :class:`toptl.AsyncTopTL` instance — this plugin is async-only
        because PTB 21+ is async-only.
    username
        Your listing's Telegram username without the leading ``@``.
    interval_seconds
        How often to flush stats to TOP.TL. Default 30 minutes. The
        server-side rate limit kicks in above roughly once per minute —
        keep it generous.
    first_seconds
        Delay before the first post. Default 30 s so the bot has time to
        collect at least a handful of users before the first flush.
    handler_group
        PTB handler group number. ``-100`` puts the tracker first and
        keeps it out of the way of your command handlers. Override if
        you already use negative groups.

    Returns
    -------
    TopTLPlugin
        Handle to the installed plugin. Keep it — you'll need it for
        :func:`vote_required`, manual :meth:`TopTLPlugin.post_now` calls,
        and direct :meth:`TopTLPlugin.has_voted` checks.
    """
    plugin = TopTLPlugin(client, username)

    # Track every update (including edited messages, channel posts, etc.).
    application.add_handler(TypeHandler(Update, plugin._track), group=handler_group)

    # JobQueue is optional in PTB — skip silently if the user hasn't
    # installed the `[job-queue]` extra rather than crashing their bot.
    job_queue = getattr(application, "job_queue", None)
    if job_queue is not None:
        job_queue.run_repeating(
            plugin._post_job,
            interval=interval_seconds,
            first=first_seconds,
            name="toptl_post_stats",
        )
    else:
        logger.warning(
            "toptl-ptb: no JobQueue on this Application — install "
            "python-telegram-bot[job-queue] to enable autoposting. "
            "Call plugin.post_now() manually as a fallback."
        )

    return plugin


Handler = Callable[[Update, ContextTypes.DEFAULT_TYPE], Awaitable[Any]]


def vote_required(
    plugin: TopTLPlugin,
    *,
    message: Optional[str] = None,
    vote_url: Optional[str] = None,
) -> Callable[[Handler], Handler]:
    """Decorator that blocks a handler for users who haven't voted.

    Example::

        @vote_required(plugin, message="Vote to unlock premium!")
        async def premium(update, context):
            ...

    The default message links to the public vote page if ``vote_url`` is
    provided; otherwise a generic prompt is sent.
    """

    def decorator(func: Handler) -> Handler:
        @functools.wraps(func)
        async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args: Any, **kwargs: Any) -> Any:
            user = update.effective_user
            if user is None:
                return None
            if await plugin.has_voted(user.id):
                return await func(update, context, *args, **kwargs)
            if update.effective_message:
                text = message or (
                    f"Please vote on TOP.TL first: {vote_url}"
                    if vote_url
                    else "Please vote for this bot on TOP.TL to use this command."
                )
                await update.effective_message.reply_text(text)
            return None

        return wrapper

    return decorator
