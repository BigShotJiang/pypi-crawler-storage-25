"""python-telegram-bot plugin for TOP.TL.

Install once on your PTB `Application`:

    from telegram.ext import ApplicationBuilder
    from toptl import AsyncTopTL
    from toptl_ptb import setup_toptl

    app = ApplicationBuilder().token("BOT_TOKEN").build()
    client = AsyncTopTL("toptl_xxx")
    plugin = setup_toptl(app, client, "mybot")

    # Gate commands behind a TOP.TL vote
    from toptl_ptb import vote_required
    @vote_required(plugin)
    async def premium(update, context):
        ...

`setup_toptl` adds a low-priority tracker that learns unique users /
groups / channels from every update, and schedules a JobQueue tick
that calls `post_stats` on the configured interval (30 min by default,
only when counts have changed).
"""

from .plugin import TopTLPlugin, setup_toptl, vote_required

__all__ = ["TopTLPlugin", "setup_toptl", "vote_required"]
__version__ = "0.1.0"
