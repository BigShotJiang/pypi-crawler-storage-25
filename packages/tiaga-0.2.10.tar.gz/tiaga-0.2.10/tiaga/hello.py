print("welcome")
print("hello")