# CLAUDE.md — cann-gitcode-mcp

## Project Overview

`cann-gitcode-mcp` is an MCP (Model Context Protocol) server that exposes GitCode API operations as MCP tools for CANN developers. It wraps GitCode's REST API (v5, base URL `https://gitcode.com/api/v5`) so that Claude Code and other MCP clients can perform GitCode actions (create PRs, list PRs, merge, comment, etc.) directly from a conversation. The package name is `cann-gitcode-mcp`; the importable Python module is `cann_gitcode_mcp`.

## Architecture

```
src/cann_gitcode_mcp/
├── __init__.py          # Package version / public exports
├── __main__.py          # python -m cann_gitcode_mcp entry point → calls server.main()
├── server.py            # FastMCP instance + wires in all tool modules
├── client.py            # GitCodeClient: async HTTP client wrapping httpx
└── tools/
    ├── __init__.py
    ├── pull_request.py  # register_pull_request_tools(mcp) — 7 PR tools
    └── pipeline.py      # register_pipeline_tools(mcp) — 2 pipeline tools (trigger + summary)
```

- **`server.py`** — creates the `FastMCP("gitcode")` instance and calls every `register_*_tools(mcp)` function. This is the single wiring point.
- **`client.py`** — `GitCodeClient` reads `GITCODE_API_TOKEN` from the environment, sets up an `httpx.AsyncClient`, and provides `get / post / patch / put / delete` async helpers.
- **`tools/`** — each file owns one domain (pull requests, issues, repos, …). Tools are registered via `@mcp.tool()` inside a `register_*_tools(mcp: FastMCP)` function.

## Adding New Tools

1. Create `src/cann_gitcode_mcp/tools/<domain>.py`.
2. Define `register_<domain>_tools(mcp: FastMCP) -> None` that decorates each async function with `@mcp.tool()`.
3. Import and call the registration function in `server.py`.
4. Add tests in `tests/test_<domain>.py` (see Testing Patterns below).

Example skeleton:

```python
# src/cann_gitcode_mcp/tools/issue.py
from __future__ import annotations
import json
from mcp.server.fastmcp import FastMCP
from cann_gitcode_mcp.client import GitCodeClient

_client: GitCodeClient | None = None

def _get_client() -> GitCodeClient:
    global _client
    if _client is None:
        _client = GitCodeClient()
    return _client

def register_issue_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def get_issue(owner: str, repo: str, number: int) -> str:
        """Get details of a GitCode issue.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: Issue number
        """
        client = _get_client()
        result = await client.get(f"/repos/{owner}/{repo}/issues/{number}")
        return json.dumps(result, indent=2, ensure_ascii=False)
```

Then in `server.py`:

```python
from cann_gitcode_mcp.tools.issue import register_issue_tools
register_issue_tools(mcp)
```

## Development Commands

```bash
# Install with dev dependencies
uv pip install -e ".[dev]"

# Run the test suite
pytest

# Run with verbose output
pytest -v

# Start the MCP server (stdio transport)
python -m cann_gitcode_mcp
```

## Code Style

- **Python 3.11+** — use `X | Y` union types, `from __future__ import annotations` at the top of every file.
- **Async** — all tool functions must be `async def`.
- **Type hints** — all function parameters and return types must be annotated.
- **Docstrings** — every tool function must have a docstring; the first line becomes the MCP tool description. Use `Args:` sections for parameter documentation.
- **Return type** — all tools return `str` (JSON-serialised with `json.dumps(..., ensure_ascii=False)`).
- **No bare exceptions** — let errors propagate from `GitCodeClient`; the MCP framework will surface them to the client.

## Testing Patterns

Tests live in `tests/`. The project uses `pytest-asyncio` with `asyncio_mode = "auto"`.

Key pattern — mock `GitCodeClient` methods so tests never hit the network:

```python
import pytest
from unittest.mock import AsyncMock, patch
from mcp.server.fastmcp import FastMCP
from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools

@pytest.fixture
def mcp_server():
    server = FastMCP("test")
    with patch("cann_gitcode_mcp.tools.pull_request._client", None), \
         patch.dict("os.environ", {"GITCODE_API_TOKEN": "test-token"}):
        register_pull_request_tools(server)
        yield server

async def test_get_pull_request(mcp_server):
    tool_fn = mcp_server._tool_manager._tools["get_pull_request"].fn
    fake_pr = {"number": 1, "title": "fix: something"}
    with patch("cann_gitcode_mcp.tools.pull_request.GitCodeClient.get",
               new_callable=AsyncMock, return_value=fake_pr):
        result = await tool_fn(owner="org", repo="repo", number=1)
    assert '"number": 1' in result
```

Use `mcp_server._tool_manager._tools["<tool_name>"].fn` to get the raw async callable for a registered tool.

## Environment

| Variable | Required | Description |
|----------|----------|-------------|
| `GITCODE_API_TOKEN` | Yes | Personal access token from GitCode settings |
| `GITCODE_API_BASE_URL` | No | Override API base (default: `https://gitcode.com/api/v5`) |
