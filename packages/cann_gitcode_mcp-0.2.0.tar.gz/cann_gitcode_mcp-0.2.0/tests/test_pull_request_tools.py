from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools


@pytest.fixture(autouse=True)
def reset_client():
    """Reset the module-level client singleton between tests."""
    import cann_gitcode_mcp.tools.pull_request as pr_mod
    pr_mod._client = None
    yield
    pr_mod._client = None


@pytest.fixture
def mock_client():
    """Return a mock GitCodeClient and patch _get_client to return it."""
    client = AsyncMock()
    with patch("cann_gitcode_mcp.tools.pull_request._get_client", return_value=client):
        yield client


@pytest.fixture
def mcp_server():
    from mcp.server.fastmcp import FastMCP
    server = FastMCP("test")
    register_pull_request_tools(server)
    return server


class TestCreatePullRequest:
    async def test_create_pr_minimal(self, mock_client, mcp_server):
        mock_client.post.return_value = {
            "number": 42,
            "title": "fix: build error",
            "html_url": "https://gitcode.com/org/repo/pulls/42",
            "state": "open",
        }

        tool_fn = mcp_server._tool_manager._tools["create_pull_request"].fn
        result = await tool_fn(
            owner="org", repo="repo",
            title="fix: build error", head="fix-branch", base="main",
        )

        parsed = json.loads(result)
        assert parsed["number"] == 42
        assert parsed["html_url"] == "https://gitcode.com/org/repo/pulls/42"

        mock_client.post.assert_called_once_with(
            "/repos/org/repo/pulls",
            json={"title": "fix: build error", "head": "fix-branch", "base": "main"},
        )

    async def test_create_pr_with_optional_fields(self, mock_client, mcp_server):
        mock_client.post.return_value = {"number": 43, "draft": True}

        tool_fn = mcp_server._tool_manager._tools["create_pull_request"].fn
        result = await tool_fn(
            owner="org", repo="repo",
            title="wip: new feature", head="feat-branch", base="develop",
            body="## Summary\nNew feature", draft=True, labels="enhancement",
        )

        parsed = json.loads(result)
        assert parsed["draft"] is True

        call_json = mock_client.post.call_args[1]["json"]
        assert call_json["body"] == "## Summary\nNew feature"
        assert call_json["draft"] is True
        assert call_json["labels"] == "enhancement"


class TestListPullRequests:
    async def test_list_prs_default(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"number": 1, "title": "PR one", "state": "open"},
            {"number": 2, "title": "PR two", "state": "open"},
        ]

        tool_fn = mcp_server._tool_manager._tools["list_pull_requests"].fn
        result = await tool_fn(owner="org", repo="repo")

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["number"] == 1

    async def test_list_prs_with_filters(self, mock_client, mcp_server):
        mock_client.get.return_value = []

        tool_fn = mcp_server._tool_manager._tools["list_pull_requests"].fn
        await tool_fn(owner="org", repo="repo", state="closed", page=2, per_page=10)

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls",
            state="closed", page=2, per_page=10,
        )

    async def test_list_prs_filter_by_head(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"number": 5, "title": "feat: new", "state": "open"},
        ]

        tool_fn = mcp_server._tool_manager._tools["list_pull_requests"].fn
        result = await tool_fn(
            owner="org", repo="repo", state="open", head="my-feature",
        )

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls",
            state="open", head="my-feature",
        )
        parsed = json.loads(result)
        assert len(parsed) == 1
        assert parsed[0]["number"] == 5

    async def test_list_prs_filter_by_base(self, mock_client, mcp_server):
        mock_client.get.return_value = []

        tool_fn = mcp_server._tool_manager._tools["list_pull_requests"].fn
        await tool_fn(owner="org", repo="repo", base="master")

        mock_client.get.assert_called_once_with(
            "/repos/org/repo/pulls",
            base="master",
        )


class TestGetPullRequest:
    async def test_get_pr(self, mock_client, mcp_server):
        mock_client.get.return_value = {
            "number": 42,
            "title": "fix: build",
            "state": "open",
            "mergeable": True,
        }

        tool_fn = mcp_server._tool_manager._tools["get_pull_request"].fn
        result = await tool_fn(owner="org", repo="repo", number=42)

        parsed = json.loads(result)
        assert parsed["number"] == 42
        assert parsed["mergeable"] is True

        mock_client.get.assert_called_once_with("/repos/org/repo/pulls/42")


class TestMergePullRequest:
    async def test_merge_pr_default(self, mock_client, mcp_server):
        mock_client.put.return_value = {"sha": "abc123", "merged": True}

        tool_fn = mcp_server._tool_manager._tools["merge_pull_request"].fn
        result = await tool_fn(owner="org", repo="repo", number=42)

        parsed = json.loads(result)
        assert parsed["merged"] is True

        mock_client.put.assert_called_once_with(
            "/repos/org/repo/pulls/42/merge",
            json={"merge_method": "merge"},
        )

    async def test_merge_pr_squash(self, mock_client, mcp_server):
        mock_client.put.return_value = {"sha": "def456", "merged": True}

        tool_fn = mcp_server._tool_manager._tools["merge_pull_request"].fn
        await tool_fn(owner="org", repo="repo", number=42, merge_method="squash")

        call_json = mock_client.put.call_args[1]["json"]
        assert call_json["merge_method"] == "squash"


class TestCommentPullRequest:
    async def test_comment_pr(self, mock_client, mcp_server):
        mock_client.post.return_value = {
            "id": 100,
            "body": "LGTM!",
        }

        tool_fn = mcp_server._tool_manager._tools["comment_pull_request"].fn
        result = await tool_fn(
            owner="org", repo="repo", number=42, body="LGTM!",
        )

        parsed = json.loads(result)
        assert parsed["body"] == "LGTM!"

        mock_client.post.assert_called_once_with(
            "/repos/org/repo/pulls/42/comments",
            json={"body": "LGTM!"},
        )


class TestGetPullRequestFiles:
    async def test_get_pr_files(self, mock_client, mcp_server):
        mock_client.get.return_value = [
            {"filename": "src/main.py", "status": "modified", "additions": 10, "deletions": 2},
            {"filename": "tests/test_main.py", "status": "added", "additions": 25, "deletions": 0},
        ]

        tool_fn = mcp_server._tool_manager._tools["get_pull_request_files"].fn
        result = await tool_fn(owner="org", repo="repo", number=42)

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["filename"] == "src/main.py"

        mock_client.get.assert_called_once_with("/repos/org/repo/pulls/42/files")
