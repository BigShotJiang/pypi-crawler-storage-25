from cann_gitcode_mcp.server import mcp


def test_all_tools_registered():
    """Verify all tools are registered on the MCP server."""
    tools = mcp._tool_manager._tools
    expected_tools = [
        # PR tools
        "create_pull_request",
        "list_pull_requests",
        "get_pull_request",
        "merge_pull_request",
        "comment_pull_request",
        "get_pull_request_files",
        "list_pull_request_comments",
        # Pipeline tools
        "get_pr_pipeline_summary",
        "trigger_pr_pipeline",
    ]
    for tool_name in expected_tools:
        assert tool_name in tools, f"Tool '{tool_name}' not registered"


def test_server_metadata():
    """Verify server name."""
    assert mcp.name == "gitcode"
