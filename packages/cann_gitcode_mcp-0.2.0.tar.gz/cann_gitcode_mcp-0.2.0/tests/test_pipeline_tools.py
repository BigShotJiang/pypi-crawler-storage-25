from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest
from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.tools.pipeline import (
    _get_pipeline_status,
    _parse_pipeline_comment,
    register_pipeline_tools,
)


@pytest.fixture(autouse=True)
def reset_client():
    import cann_gitcode_mcp.tools.pipeline as pipeline_mod
    pipeline_mod._client = None
    yield
    pipeline_mod._client = None


@pytest.fixture
def mock_client():
    client = AsyncMock()
    with patch("cann_gitcode_mcp.tools.pipeline._get_client", return_value=client):
        yield client


@pytest.fixture
def mcp_server():
    server = FastMCP("test")
    register_pipeline_tools(server)
    return server


# -- Sample bot comment matching the research doc format --

PIPELINE_COMMENT_BODY = """\
流水线任务触发成功
任务链接 [<a href='https://www.openlibing.com/apps/pipelineDetail?pipelineId=8033cdebd5e5420e9165181589392a80&pipelineRunId=aaa5c9122dbb44b0bbdd2890218a92f2&projectName=CANN'>aaa5c9122dbb44b0bbdd2890218a92f2</a>]
<table>
<tr><th>任务名称</th><th>状态</th><th>日志</th><th>下载链接</th></tr>
<tr>
<td><strong>Check_Pr</strong></td>
<td>✅ SUCCESS</td>
<td><a href=https://www.openlibing.com/apps/pipelineDetail?pipelineId=8033cdebd5e5420e9165181589392a80&pipelineRunId=aaa5c9122dbb44b0bbdd2890218a92f2&projectName=CANN>>>>>></a></td>
<td><a href=></a></td>
</tr>
<tr>
<td><strong>Compile_X86_compiler</strong></td>
<td>❌ FAILED</td>
<td><a href=https://www.openlibing.com/apps/pipelineDetail?pipelineId=8033cdebd5e5420e9165181589392a80&pipelineRunId=aaa5c9122dbb44b0bbdd2890218a92f2&projectName=CANN>>>>>></a></td>
<td><a href=></a></td>
</tr>
<tr>
<td><strong>Compile_X86_executor</strong></td>
<td>✅ SUCCESS</td>
<td><a href=https://www.openlibing.com/apps/pipelineDetail?pipelineId=8033cdebd5e5420e9165181589392a80&pipelineRunId=aaa5c9122dbb44b0bbdd2890218a92f2&projectName=CANN>>>>>></a></td>
<td><a href=https://ascend-ci.obs.cn-north-4.myhuaweicloud.com/ge/package/1601/cann-ge-executor_linux-x86_64.run>>>>>></a></td>
</tr>
</table>
[2026-03-28 16:45:30] CI执行失败
"""

APPROVAL_COMMENT_BODY = """\
CLA签名通过
lgtm: 0/2
approve: 0/1
"""


class TestParsePipelineComment:
    def test_parses_pipeline_comment(self):
        result = _parse_pipeline_comment(PIPELINE_COMMENT_BODY)
        assert result is not None
        assert result["pipeline_id"] == "8033cdebd5e5420e9165181589392a80"
        assert result["pipeline_run_id"] == "aaa5c9122dbb44b0bbdd2890218a92f2"
        assert result["conclusion"] == "CI执行失败"
        assert result["timestamp"] == "2026-03-28 16:45:30"

        tasks = result["tasks"]
        assert len(tasks) == 3

        assert tasks[0]["name"] == "Check_Pr"
        assert tasks[0]["status"] == "SUCCESS"

        assert tasks[1]["name"] == "Compile_X86_compiler"
        assert tasks[1]["status"] == "FAILED"

        assert tasks[2]["name"] == "Compile_X86_executor"
        assert tasks[2]["status"] == "SUCCESS"
        assert "download_url" in tasks[2]
        assert "ascend-ci" in tasks[2]["download_url"]

    def test_returns_none_for_non_pipeline_comment(self):
        assert _parse_pipeline_comment(APPROVAL_COMMENT_BODY) is None

    def test_returns_none_for_empty_string(self):
        assert _parse_pipeline_comment("") is None

    def test_extracts_openlibing_url(self):
        result = _parse_pipeline_comment(PIPELINE_COMMENT_BODY)
        assert result is not None
        assert "openlibing_url" in result
        assert "pipelineDetail" in result["openlibing_url"]

    def test_success_comment(self):
        body = PIPELINE_COMMENT_BODY.replace("CI执行失败", "CI执行成功").replace(
            "❌ FAILED", "✅ SUCCESS"
        )
        result = _parse_pipeline_comment(body)
        assert result is not None
        assert result["conclusion"] == "CI执行成功"
        assert all(t["status"] == "SUCCESS" for t in result["tasks"])


class TestGetPipelineStatus:
    def test_running(self):
        labels = [{"name": "ci-pipeline-running"}, {"name": "enhancement"}]
        assert _get_pipeline_status(labels) == "running"

    def test_passed(self):
        labels = [{"name": "ci-pipeline-passed"}]
        assert _get_pipeline_status(labels) == "passed"

    def test_failed(self):
        labels = [{"name": "ci-pipeline-failed"}, {"name": "cann-cla/yes"}]
        assert _get_pipeline_status(labels) == "failed"

    def test_unknown_when_no_pipeline_label(self):
        labels = [{"name": "enhancement"}, {"name": "cann-cla/yes"}]
        assert _get_pipeline_status(labels) == "unknown"

    def test_empty_labels(self):
        assert _get_pipeline_status([]) == "unknown"


class TestTriggerPrPipeline:
    async def test_posts_compile_comment(self, mock_client, mcp_server):
        mock_client.post.return_value = {"id": 999, "body": "compile"}

        tool_fn = mcp_server._tool_manager._tools["trigger_pr_pipeline"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=1601)

        parsed = json.loads(result)
        assert parsed["action"] == "pipeline_triggered"
        assert parsed["comment_id"] == 999
        assert parsed["pr"] == "cann/ge#1601"

        mock_client.post.assert_called_once_with(
            "/repos/cann/ge/pulls/1601/comments",
            json={"body": "compile"},
        )


class TestGetPrPipelineSummary:
    def _setup_mock(self, mock_client, labels, comments):
        """Configure mock for get_pr_pipeline_summary: PR detail + paginated comments."""
        mock_client.get.side_effect = [
            # First call: PR detail
            {"labels": labels},
            # Second call: comments page 1 (return all, simulating < per_page)
            comments,
        ]

    async def test_returns_pipeline_summary_with_status(self, mock_client, mcp_server):
        self._setup_mock(
            mock_client,
            labels=[{"name": "ci-pipeline-failed"}, {"name": "enhancement"}],
            comments=[
                {"user": {"login": "someone"}, "body": "regular comment"},
                {"user": {"login": "cann-robot"}, "body": APPROVAL_COMMENT_BODY},
                {"user": {"login": "cann-robot"}, "body": PIPELINE_COMMENT_BODY},
            ],
        )

        tool_fn = mcp_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=1601)

        parsed = json.loads(result)
        assert parsed["pipeline_found"] is True
        assert parsed["pipeline_status"] == "failed"
        assert parsed["pr"] == "cann/ge#1601"
        assert parsed["conclusion"] == "CI执行失败"
        assert len(parsed["tasks"]) == 3

    async def test_running_status(self, mock_client, mcp_server):
        self._setup_mock(
            mock_client,
            labels=[{"name": "ci-pipeline-running"}],
            comments=[],
        )

        tool_fn = mcp_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=1601)

        parsed = json.loads(result)
        assert parsed["pipeline_status"] == "running"
        assert parsed["pipeline_found"] is False

    async def test_no_pipeline_comments(self, mock_client, mcp_server):
        self._setup_mock(
            mock_client,
            labels=[],
            comments=[{"user": {"login": "someone"}, "body": "just a comment"}],
        )

        tool_fn = mcp_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=100)

        parsed = json.loads(result)
        assert parsed["pipeline_found"] is False
        assert parsed["pipeline_status"] == "unknown"

    async def test_multiple_pipeline_comments_returns_latest(self, mock_client, mcp_server):
        early_body = PIPELINE_COMMENT_BODY.replace(
            "2026-03-28 16:45:30", "2026-03-28 10:00:00"
        )
        self._setup_mock(
            mock_client,
            labels=[{"name": "ci-pipeline-failed"}],
            comments=[
                {"user": {"login": "cann-robot"}, "body": early_body},
                {"user": {"login": "cann-robot"}, "body": PIPELINE_COMMENT_BODY},
            ],
        )

        tool_fn = mcp_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=1601)

        parsed = json.loads(result)
        assert parsed["total_pipeline_comments"] == 2
        assert parsed["timestamp"] == "2026-03-28 16:45:30"

    async def test_pagination_fetches_all_pages(self, mock_client, mcp_server):
        """Verify that comments are fetched across multiple pages."""
        mock_client.get.side_effect = [
            # PR detail
            {"labels": [{"name": "ci-pipeline-failed"}]},
            # Page 1: 100 non-pipeline comments (simulating full page)
            [{"user": {"login": "someone"}, "body": "comment"}] * 100,
            # Page 2: pipeline comment (< 100 items, so pagination stops)
            [{"user": {"login": "cann-robot"}, "body": PIPELINE_COMMENT_BODY}],
        ]

        tool_fn = mcp_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=1601)

        parsed = json.loads(result)
        assert parsed["pipeline_found"] is True
        assert parsed["conclusion"] == "CI执行失败"
        # Verify 3 get calls: PR detail + 2 comment pages
        assert mock_client.get.call_count == 3

    async def test_empty_comments(self, mock_client, mcp_server):
        self._setup_mock(mock_client, labels=[], comments=[])

        tool_fn = mcp_server._tool_manager._tools["get_pr_pipeline_summary"].fn
        result = await tool_fn(owner="cann", repo="ge", pr_number=1)

        parsed = json.loads(result)
        assert parsed["pipeline_found"] is False


class TestListPullRequestComments:
    """Test list_pull_request_comments added to pull_request tools."""

    async def test_list_comments(self):
        from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools
        import cann_gitcode_mcp.tools.pull_request as pr_mod
        pr_mod._client = None

        server = FastMCP("test")
        register_pull_request_tools(server)

        client = AsyncMock()
        client.get.return_value = [
            {"id": 1, "body": "comment 1", "user": {"login": "alice"}},
            {"id": 2, "body": "comment 2", "user": {"login": "bob"}},
        ]

        with patch("cann_gitcode_mcp.tools.pull_request._get_client", return_value=client):
            tool_fn = server._tool_manager._tools["list_pull_request_comments"].fn
            result = await tool_fn(owner="org", repo="repo", number=42)

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["body"] == "comment 1"

        client.get.assert_called_once_with(
            "/repos/org/repo/pulls/42/comments",
        )

        pr_mod._client = None
