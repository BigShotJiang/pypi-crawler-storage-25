import os
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from cann_gitcode_mcp.client import GitCodeClient


class TestGitCodeClientInit:
    def test_init_with_explicit_token(self):
        client = GitCodeClient(token="test-token-123")
        assert client.token == "test-token-123"
        assert client.base_url == "https://gitcode.com/api/v5"

    def test_init_from_env(self):
        with patch.dict(os.environ, {"GITCODE_API_TOKEN": "env-token"}):
            client = GitCodeClient()
            assert client.token == "env-token"

    def test_init_custom_base_url(self):
        client = GitCodeClient(token="t", base_url="https://custom.api/v5")
        assert client.base_url == "https://custom.api/v5"

    def test_init_missing_token_raises(self):
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("GITCODE_API_TOKEN", None)
            with pytest.raises(ValueError, match="GITCODE_API_TOKEN"):
                GitCodeClient()


class TestGitCodeClientRequests:
    @pytest.fixture
    def client(self):
        return GitCodeClient(token="test-token")

    async def test_get_success(self, client):
        mock_response = httpx.Response(
            200,
            json={"id": 1, "name": "test"},
            request=httpx.Request("GET", "https://example.com"),
        )
        with patch.object(client._client, "request", new_callable=AsyncMock, return_value=mock_response):
            result = await client.get("/repos/owner/repo")
            assert result == {"id": 1, "name": "test"}

    async def test_post_success(self, client):
        mock_response = httpx.Response(
            201,
            json={"id": 1, "title": "new PR"},
            request=httpx.Request("POST", "https://example.com"),
        )
        with patch.object(client._client, "request", new_callable=AsyncMock, return_value=mock_response):
            result = await client.post("/repos/owner/repo/pulls", json={"title": "new PR"})
            assert result == {"id": 1, "title": "new PR"}

    async def test_request_api_error_raises(self, client):
        mock_response = httpx.Response(
            404,
            text="Not Found",
            request=httpx.Request("GET", "https://example.com"),
        )
        with patch.object(client._client, "request", new_callable=AsyncMock, return_value=mock_response):
            with pytest.raises(RuntimeError, match="404"):
                await client.get("/repos/owner/nonexistent")

    async def test_delete_204_returns_none(self, client):
        mock_response = httpx.Response(
            204,
            request=httpx.Request("DELETE", "https://example.com"),
        )
        with patch.object(client._client, "request", new_callable=AsyncMock, return_value=mock_response):
            result = await client.delete("/some/resource")
            assert result is None
