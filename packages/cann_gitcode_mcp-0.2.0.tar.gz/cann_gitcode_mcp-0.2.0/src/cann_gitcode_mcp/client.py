from __future__ import annotations

import os
from typing import Any

import httpx


class GitCodeClient:
    """GitCode v5 API client."""

    def __init__(
        self,
        token: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self.token = token or os.environ.get("GITCODE_API_TOKEN", "")
        self.base_url = (
            base_url
            or os.environ.get("GITCODE_API_BASE_URL")
            or "https://gitcode.com/api/v5"
        )

        if not self.token:
            raise ValueError(
                "GitCode API token is required. "
                "Set GITCODE_API_TOKEN environment variable."
            )

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        response = await self._client.request(
            method, path, json=json, params=params,
        )
        if not response.is_success:
            raise RuntimeError(
                f"GitCode API error {response.status_code}: {response.text}"
            )
        if response.status_code == 204:
            return None
        return response.json()

    async def get(self, path: str, **params: Any) -> Any:
        return await self.request("GET", path, params=params or None)

    async def post(self, path: str, json: dict[str, Any] | None = None) -> Any:
        return await self.request("POST", path, json=json)

    async def patch(self, path: str, json: dict[str, Any] | None = None) -> Any:
        return await self.request("PATCH", path, json=json)

    async def put(self, path: str, json: dict[str, Any] | None = None) -> Any:
        return await self.request("PUT", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self.request("DELETE", path)

    async def close(self) -> None:
        await self._client.aclose()
