from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.client import GitCodeClient

_client: GitCodeClient | None = None


def _get_client() -> GitCodeClient:
    global _client
    if _client is None:
        _client = GitCodeClient()
    return _client


def _text_result(data: Any) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False)


def register_pull_request_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def create_pull_request(
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str,
        body: str | None = None,
        draft: bool | None = None,
        labels: str | None = None,
        assignees: str | None = None,
        testers: str | None = None,
        prune_source_branch: bool | None = None,
        squash: bool | None = None,
    ) -> str:
        """Create a Pull Request on a GitCode repository.

        Args:
            owner: Repository namespace (organization or user path)
            repo: Repository name
            title: PR title
            head: Source branch, format: branch or namespace:branch
            base: Target branch
            body: PR description (Markdown)
            draft: Create as draft PR
            labels: Comma-separated labels
            assignees: Comma-separated reviewer usernames
            testers: Comma-separated tester usernames
            prune_source_branch: Delete source branch after merge
            squash: Use squash merge
        """
        client = _get_client()
        payload: dict[str, Any] = {"title": title, "head": head, "base": base}
        for key in ("body", "draft", "labels", "assignees", "testers",
                     "prune_source_branch", "squash"):
            val = locals()[key]
            if val is not None:
                payload[key] = val

        result = await client.post(f"/repos/{owner}/{repo}/pulls", json=payload)
        return _text_result(result)

    @mcp.tool()
    async def list_pull_requests(
        owner: str,
        repo: str,
        state: str | None = None,
        head: str | None = None,
        base: str | None = None,
        sort: str | None = None,
        direction: str | None = None,
        page: int | None = None,
        per_page: int | None = None,
    ) -> str:
        """List Pull Requests of a GitCode repository.

        Tip: use `head` to find the PR associated with a local branch.
        For example, after `git branch --show-current` returns "fix-bug",
        call list_pull_requests(owner, repo, state="open", head="fix-bug")
        to locate the PR for that branch.

        Args:
            owner: Repository namespace
            repo: Repository name
            state: Filter by state (open/closed/merged/all, default open)
            head: Filter by source branch name (e.g. "my-feature")
            base: Filter by target branch name (e.g. "master")
            sort: Sort by (created/updated/popularity)
            direction: Sort direction (asc/desc)
            page: Page number
            per_page: Items per page (default 20)
        """
        client = _get_client()
        params = {
            k: v for k, v in {
                "state": state, "head": head, "base": base,
                "sort": sort, "direction": direction,
                "page": page, "per_page": per_page,
            }.items() if v is not None
        }
        result = await client.get(f"/repos/{owner}/{repo}/pulls", **params)
        return _text_result(result)

    @mcp.tool()
    async def get_pull_request(owner: str, repo: str, number: int) -> str:
        """Get details of a Pull Request on a GitCode repository.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: PR number
        """
        client = _get_client()
        result = await client.get(f"/repos/{owner}/{repo}/pulls/{number}")
        return _text_result(result)

    @mcp.tool()
    async def merge_pull_request(
        owner: str,
        repo: str,
        number: int,
        merge_method: str | None = None,
        prune_source_branch: bool | None = None,
    ) -> str:
        """Merge a Pull Request on a GitCode repository.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: PR number
            merge_method: Merge method (merge/squash/rebase, default merge)
            prune_source_branch: Delete source branch after merge
        """
        client = _get_client()
        payload: dict[str, Any] = {"merge_method": merge_method or "merge"}
        if prune_source_branch is not None:
            payload["prune_source_branch"] = prune_source_branch

        result = await client.put(
            f"/repos/{owner}/{repo}/pulls/{number}/merge", json=payload,
        )
        return _text_result(result)

    @mcp.tool()
    async def comment_pull_request(
        owner: str, repo: str, number: int, body: str,
    ) -> str:
        """Add a comment to a GitCode Pull Request.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: PR number
            body: Comment content (Markdown)
        """
        client = _get_client()
        result = await client.post(
            f"/repos/{owner}/{repo}/pulls/{number}/comments",
            json={"body": body},
        )
        return _text_result(result)

    @mcp.tool()
    async def get_pull_request_files(
        owner: str, repo: str, number: int,
    ) -> str:
        """Get the list of files changed in a GitCode Pull Request.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: PR number
        """
        client = _get_client()
        result = await client.get(
            f"/repos/{owner}/{repo}/pulls/{number}/files",
        )
        return _text_result(result)

    @mcp.tool()
    async def list_pull_request_comments(
        owner: str,
        repo: str,
        number: int,
        page: int | None = None,
        per_page: int | None = None,
    ) -> str:
        """List all comments on a GitCode Pull Request.

        Args:
            owner: Repository namespace
            repo: Repository name
            number: PR number
            page: Page number
            per_page: Items per page (default 20)
        """
        client = _get_client()
        params = {
            k: v for k, v in {"page": page, "per_page": per_page}.items()
            if v is not None
        }
        result = await client.get(
            f"/repos/{owner}/{repo}/pulls/{number}/comments", **params,
        )
        return _text_result(result)
