from __future__ import annotations

import json
import re
from html.parser import HTMLParser
from typing import Any

from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.client import GitCodeClient

_client: GitCodeClient | None = None


def _get_client() -> GitCodeClient:
    global _client
    if _client is None:
        _client = GitCodeClient()
    return _client


def _text_result(data: Any) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False)


class _PipelineTableParser(HTMLParser):
    """Parse the HTML table from cann-robot's pipeline comment."""

    def __init__(self) -> None:
        super().__init__()
        self.tasks: list[dict[str, str]] = []
        self._in_table = False
        self._in_row = False
        self._in_cell = False
        self._in_header = False
        self._current_row: list[str] = []
        self._current_cell = ""
        self._current_href = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "table":
            self._in_table = True
        elif tag == "tr" and self._in_table:
            self._in_row = True
            self._current_row = []
        elif tag == "th" and self._in_row:
            self._in_header = True
        elif tag == "td" and self._in_row:
            self._in_cell = True
            self._current_cell = ""
            self._current_href = ""
        elif tag == "a" and self._in_cell:
            href = dict(attrs).get("href", "")
            if href:
                self._current_href = href

    def handle_endtag(self, tag: str) -> None:
        if tag == "table":
            self._in_table = False
        elif tag == "tr" and self._in_row:
            self._in_row = False
            if self._current_row and not self._in_header:
                self._emit_task()
        elif tag == "th":
            self._in_header = False
        elif tag == "td" and self._in_cell:
            self._in_cell = False
            self._current_row.append((self._current_cell.strip(), self._current_href))

    def handle_data(self, data: str) -> None:
        if self._in_cell:
            self._current_cell += data

    def _emit_task(self) -> None:
        if len(self._current_row) < 2:
            return
        # Columns: 任务名称, 状态, 日志, 下载链接
        name = self._current_row[0][0] if self._current_row[0] else ""
        status_text = self._current_row[1][0] if len(self._current_row) > 1 else ""
        log_link = self._current_row[2][1] if len(self._current_row) > 2 else ""
        download_link = self._current_row[3][1] if len(self._current_row) > 3 else ""

        # Clean status text: remove emoji prefixes like ✅ ❌
        status = re.sub(r"^[^\w]*", "", status_text).strip()

        task: dict[str, str] = {"name": name, "status": status}
        if log_link:
            task["log_url"] = log_link
        if download_link:
            task["download_url"] = download_link
        self.tasks.append(task)


def _parse_pipeline_comment(body: str) -> dict[str, Any] | None:
    """Extract pipeline info from a cann-robot comment body.

    Returns None if the comment is not a pipeline comment.
    """
    if "流水线任务触发成功" not in body:
        return None

    result: dict[str, Any] = {}

    # Extract openLiBing link
    link_match = re.search(
        r"https://www\.openlibing\.com/apps/pipelineDetail\?[^'\"<>\s]+", body,
    )
    if link_match:
        url = link_match.group(0)
        result["openlibing_url"] = url
        # Extract pipelineId and pipelineRunId from URL
        pid = re.search(r"pipelineId=([^&]+)", url)
        prid = re.search(r"pipelineRunId=([^&]+)", url)
        if pid:
            result["pipeline_id"] = pid.group(1)
        if prid:
            result["pipeline_run_id"] = prid.group(1)

    # Parse HTML table for task details
    parser = _PipelineTableParser()
    parser.feed(body)
    result["tasks"] = parser.tasks

    # Extract overall conclusion — handle &nbsp; and <p> tags in real data
    conclusion_match = re.search(
        r"\]\s*(?:&nbsp;|\s)*(CI执行[^\n<]+)", body,
    )
    if conclusion_match:
        result["conclusion"] = conclusion_match.group(1).strip()

    # Extract timestamp
    ts_match = re.search(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", body)
    if ts_match:
        result["timestamp"] = ts_match.group(1)

    return result


_PIPELINE_LABELS = {
    "ci-pipeline-running": "running",
    "ci-pipeline-passed": "passed",
    "ci-pipeline-failed": "failed",
}


def _get_pipeline_status(labels: list[dict[str, Any]]) -> str:
    """Extract pipeline status from PR labels."""
    for label in labels:
        name = label.get("name", "")
        if name in _PIPELINE_LABELS:
            return _PIPELINE_LABELS[name]
    return "unknown"


async def _fetch_all_comments(
    client: GitCodeClient, owner: str, repo: str, pr_number: int,
) -> list[dict[str, Any]]:
    """Fetch all PR comments, handling pagination."""
    all_comments: list[dict[str, Any]] = []
    page = 1
    per_page = 100
    while True:
        comments = await client.get(
            f"/repos/{owner}/{repo}/pulls/{pr_number}/comments",
            page=page,
            per_page=per_page,
        )
        all_comments.extend(comments)
        if len(comments) < per_page:
            break
        page += 1
    return all_comments


def register_pipeline_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def trigger_pr_pipeline(
        owner: str,
        repo: str,
        pr_number: int,
    ) -> str:
        """Trigger CI/CD pipeline for a GitCode PR by posting a 'compile' comment.

        The cann-robot bot will pick up the comment and start the pipeline.
        Use get_pr_pipeline_summary to check the result later (pipelines
        take minutes to tens of minutes to complete).

        IMPORTANT: Do not call this repeatedly — a second 'compile' comment
        will abort the running pipeline and restart it.

        Workflow: if you only have a branch name, first call
        list_pull_requests(owner, repo, state="open", head="<branch>")
        to find the PR number.

        Args:
            owner: Repository namespace (e.g. "cann")
            repo: Repository name (e.g. "ge")
            pr_number: PR number
        """
        client = _get_client()
        result = await client.post(
            f"/repos/{owner}/{repo}/pulls/{pr_number}/comments",
            json={"body": "compile"},
        )
        return _text_result({
            "pr": f"{owner}/{repo}#{pr_number}",
            "action": "pipeline_triggered",
            "message": "Posted 'compile' comment. Pipeline will start shortly. "
                       "Use get_pr_pipeline_summary to check status.",
            "comment_id": result.get("id"),
        })

    @mcp.tool()
    async def get_pr_pipeline_summary(
        owner: str,
        repo: str,
        pr_number: int,
    ) -> str:
        """Get CI/CD pipeline summary for a GitCode Pull Request.

        Returns pipeline status (from PR labels: running/passed/failed)
        and the latest pipeline result parsed from cann-robot bot comments.
        Only uses GitCode API (Level 1), no openLiBing token required.

        Args:
            owner: Repository namespace (e.g. "cann")
            repo: Repository name (e.g. "ge")
            pr_number: PR number
        """
        client = _get_client()

        # Fetch PR details for label-based status
        pr_detail = await client.get(
            f"/repos/{owner}/{repo}/pulls/{pr_number}",
        )
        pipeline_status = _get_pipeline_status(pr_detail.get("labels", []))

        # Fetch all comments (paginated) for pipeline results
        all_comments = await _fetch_all_comments(client, owner, repo, pr_number)

        pipeline_results: list[dict[str, Any]] = []
        for comment in all_comments:
            user_login = comment.get("user", {}).get("login", "")
            body = comment.get("body", "")

            if user_login != "cann-robot":
                continue

            parsed = _parse_pipeline_comment(body)
            if parsed is not None:
                pipeline_results.append(parsed)

        base_result: dict[str, Any] = {
            "pr": f"{owner}/{repo}#{pr_number}",
            "pipeline_status": pipeline_status,
        }

        if not pipeline_results:
            return _text_result({
                **base_result,
                "pipeline_found": False,
                "message": "No pipeline comments found from cann-robot",
            })

        # Return the latest pipeline result (last comment)
        latest = pipeline_results[-1]
        return _text_result({
            **base_result,
            "pipeline_found": True,
            "total_pipeline_comments": len(pipeline_results),
            **latest,
        })
