"""CANN GitCode MCP Server - GitCode platform tools for CANN developers."""

__version__ = "0.2.0"
