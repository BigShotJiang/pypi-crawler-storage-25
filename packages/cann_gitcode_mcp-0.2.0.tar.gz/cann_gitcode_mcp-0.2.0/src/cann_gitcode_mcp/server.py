from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.tools.pipeline import register_pipeline_tools
from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools

mcp = FastMCP("gitcode")

register_pull_request_tools(mcp)
register_pipeline_tools(mcp)


def main():
    """stdio transport entry point."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
