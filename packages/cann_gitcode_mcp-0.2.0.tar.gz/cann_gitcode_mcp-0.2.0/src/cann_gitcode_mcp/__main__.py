from cann_gitcode_mcp.server import main

main()
