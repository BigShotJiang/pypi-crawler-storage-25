# AGENTS.md — cann-gitcode-mcp

Guidelines for AI agents (and humans) contributing to this repository.

## Project Purpose

`cann-gitcode-mcp` wraps the GitCode REST API (v5) as an MCP server so that AI assistants (Claude Code, etc.) can perform GitCode operations on behalf of CANN developers. Current scope: Pull Request management and CI/CD pipeline summary (Level 1 — parsing cann-robot PR comments). Planned: pipeline details via openLiBing API (Level 2), repository tools, Issue tools.

## Repository Structure

```
cann-gitcode-mcp/
├── src/cann_gitcode_mcp/
│   ├── __init__.py          # Package metadata
│   ├── __main__.py          # Entry point: python -m cann_gitcode_mcp
│   ├── server.py            # FastMCP instance; wires all tool modules
│   ├── client.py            # GitCodeClient (async httpx wrapper)
│   └── tools/
│       ├── __init__.py
│       ├── pull_request.py  # 7 PR tools (incl. list comments)
│       └── pipeline.py      # Pipeline summary from PR bot comments
├── tests/
│   ├── test_pull_request_tools.py
│   ├── test_pipeline_tools.py
│   ├── test_client.py
│   └── test_server.py
├── pyproject.toml
├── README.md
├── CLAUDE.md
└── AGENTS.md
```

## Setup

```bash
# Activate the virtual environment (if using the repo's venv)
source venv/bin/activate

# Install the package with development dependencies
uv pip install -e ".[dev]"
```

If `uv` is not available, use:

```bash
pip install -e ".[dev]"
```

Python >= 3.11 is required.

## Running Tests

```bash
pytest tests/ -v
```

All tests are unit tests that mock network calls — no real API token is needed.

## API Client

`GitCodeClient` (in `src/cann_gitcode_mcp/client.py`) is the only HTTP layer.

- **Auto-reads token**: reads `GITCODE_API_TOKEN` from the environment on construction. Raises `ValueError` if unset.
- **Base URL**: `https://gitcode.com/api/v5` (override with `GITCODE_API_BASE_URL`).
- **Methods**: `get`, `post`, `patch`, `put`, `delete` — all async, return parsed JSON or `None` (for 204).
- **Error handling**: raises `RuntimeError` on non-2xx responses with the status code and body.

Example usage in a tool:

```python
client = GitCodeClient()  # reads GITCODE_API_TOKEN from env
data = await client.get("/repos/owner/repo/pulls/1")
data = await client.post("/repos/owner/repo/pulls", json={"title": "fix", "head": "dev", "base": "main"})
```

## How to Add a New Tool

Follow these steps exactly:

### 1. Create the tool file

Create `src/cann_gitcode_mcp/tools/<domain>.py`. The file must:

- Import `FastMCP` from `mcp.server.fastmcp` and `GitCodeClient` from `cann_gitcode_mcp.client`.
- Define a module-level `_client: GitCodeClient | None = None` and a `_get_client()` helper.
- Define a single public function `register_<domain>_tools(mcp: FastMCP) -> None`.
- Inside that function, define each tool as an `async def` decorated with `@mcp.tool()`.

Rules for tool functions:
- Must be `async def`.
- Must return `str` (JSON, produced with `json.dumps(..., ensure_ascii=False)`).
- Must have a docstring — the first line is the MCP tool description; use `Args:` sections for parameters.
- Must include type annotations on all parameters.

### 2. Register in server.py

Add two lines to `src/cann_gitcode_mcp/server.py`:

```python
from cann_gitcode_mcp.tools.<domain> import register_<domain>_tools
register_<domain>_tools(mcp)
```

### 3. Add tests

Create `tests/test_<domain>.py`. Use `unittest.mock.AsyncMock` / `patch` to mock `GitCodeClient` methods. Never make real HTTP requests in tests.

Pattern for accessing a registered tool function:

```python
tool_fn = mcp_server._tool_manager._tools["<tool_name>"].fn
result = await tool_fn(owner="org", repo="repo", ...)
```

### 4. Run tests

```bash
pytest tests/ -v
```

All existing and new tests must pass before committing.

## Important Constraints

- **All tool functions must be `async def`** — synchronous tools will fail at runtime.
- **Return type is always `str`** — serialize with `json.dumps(result, indent=2, ensure_ascii=False)`.
- **Registration pattern** — tools must be registered via `@mcp.tool()` inside a `register_*_tools(mcp)` function; do not call `mcp.tool()` at module import time.
- **No global state beyond `_client`** — the module-level `_client` singleton is reset between test fixtures via `patch`.
- **Token is required** — `GitCodeClient()` raises `ValueError` if `GITCODE_API_TOKEN` is not set; tests must patch the env or the client.

## GitCode API Reference

- Base URL: `https://gitcode.com/api/v5`
- Authentication: `Authorization: Bearer <token>` header
- PR endpoints: `/repos/{owner}/{repo}/pulls[/{number}[/merge|comments|files]]`
- Pipeline data: extracted from cann-robot PR comments (no dedicated API); see `docs/pipeline-tools-research.md` for details
- Full API docs: consult GitCode platform documentation
