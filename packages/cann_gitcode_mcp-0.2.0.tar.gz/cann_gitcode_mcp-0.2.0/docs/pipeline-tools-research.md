# Pipeline Tools 前期调研与架构设计

> 调研日期: 2026-03-29

## 1. 背景

CANN 的 CI/CD 流水线托管在 openLiBing (www.openlibing.com)。需要通过 MCP 工具查看流水线结果（编译结果、用例执行结果等）。

## 2. openLiBing 平台调研

### 2.1 平台概况

- **URL**: https://www.openlibing.com
- **性质**: MaJun 平台上的 CI/CD 服务，用于华为开源生态
- **登录方式**: 通过 GitCode 账号 OAuth 授权登录
- **公开 API**: 无。无公开文档、无 SDK、无 CLI
- **内部接口**: 有，Web UI 背后通过 JSON 接口获取数据

### 2.2 已确认的内部接口

**Pipeline Run Detail（流水线运行详情）**

```
GET /gateway/openlibing-cicd/project/pipeline/pipeline-run/detail
    ?projectId={projectId}
    &pipelineId={pipelineId}
    &pipelineRunId={pipelineRunId}
```

- Host: `www.openlibing.com`
- 认证方式: JWT Token，通过 Cookie 和 Header 双重传递
  - Cookie: `token={jwt}; csrf-token-open-li-bing={jwt}`
  - Header: `Csrf-Token-Open-Li-Bing: {jwt}`
- Token 有效期: 30 分钟（`Max-Age=1800`），响应 Set-Cookie 自动续期
- JWT Payload 含: accountId, accountLogin, accountPlatform("gitcode"), exp 等

### 2.3 流水线数据没有列表接口

用户确认：openLiBing 没有通过 pipelineId 查询运行列表的接口。每次流水线的入口是从 GitCode PR 上 bot 评论中的链接点进去的。

## 3. GitCode PR Bot 评论分析

### 3.1 Bot 信息

- **Bot 用户**: `cann-robot` (login: `cann-robot`)
- **评论 API**: `GET /api/v5/repos/{owner}/{repo}/pulls/{number}/comments`
- **认证**: `Authorization: Bearer {GITCODE_API_TOKEN}`（注意是 Bearer 不是 token 前缀）

### 3.2 Bot 评论结构

Bot 发两条评论：

**评论 1**: PR 审批状态（CLA签名、lgtm/approve 进度）

**评论 2**: 流水线结果（关键），包含：

1. **触发信息**: "流水线任务触发成功"
2. **openLiBing 链接**:
   ```
   https://www.openlibing.com/apps/pipelineDetail
     ?pipelineId={pipelineId}
     &pipelineRunId={pipelineRunId}
     &projectName=CANN
   ```
3. **HTML 表格**，每行一个任务：
   - 任务名称: `Check_Pr`, `Compile_X86_compiler`, `UT_Test_dflow` 等
   - 状态: `SUCCESS` / `FAILED` / `ABORTED`
   - 日志链接: openLiBing 详情页链接
   - 下载链接: `ascend-ci.obs.cn-north-4.myhuaweicloud.com` 上的构建产物
4. **结论**: `CI执行失败` 或 `CI执行成功`

### 3.3 Bot 评论示例（关键部分）

```html
流水线任务触发成功
任务链接 [<a href='https://www.openlibing.com/apps/pipelineDetail?pipelineId=xxx&pipelineRunId=yyy&projectName=CANN'>yyy</a>]
<table>
  <tr><th>任务名称</th><th>状态</th><th>日志</th><th>下载链接</th></tr>
  <tr>
    <td><strong>Compile_X86_compiler</strong></td>
    <td>❌ FAILED</td>
    <td><a href=https://www.openlibing.com/apps/pipelineDetail?...>>>>>></a></td>
    <td><a href=></a></td>
  </tr>
  <tr>
    <td><strong>Compile_X86_executor</strong></td>
    <td>✅ SUCCESS</td>
    <td><a href=...>>>>>></a></td>
    <td><a href=https://ascend-ci.obs.cn-north-4.myhuaweicloud.com/ge/package/1601/cann-ge-executor_linux-x86_64.run>>>>>></a></td>
  </tr>
  ...
</table>
[2026-03-28 16:45:30] CI执行失败
```

## 4. openLiBing Pipeline Run Detail 数据结构

从实际抓包获得的 JSON 结构（以 cann_ge pipeline #7071 为例）：

```
Pipeline Run
├── id, pipeline_id, name("cann_ge"), status("FAILED")
├── executor_name, trigger_type("Note"), run_number(7071)
├── start_time, end_time (epoch ms)
├── sources[] — 代码来源信息
│   └── git_type("gitcode"), repo_name("ge"), build_params(MR信息)
├── artifacts[] — 构建产物列表
│   └── name, packageType, version
└── stages[] — 流水线阶段列表
    ├── 阶段_1 (sequence:0) — 解析CI分支, COMPLETED
    ├── Image (sequence:1) — 解析镜像版本, COMPLETED
    ├── 编译构建 (sequence:2) — 14个并行Job, FAILED
    │   └── jobs[]
    │       ├── name, identifier, status, condition
    │       ├── message (失败时有错误信息)
    │       └── steps[]
    │           ├── name, task, business_type, status, message
    │           └── inputs[] (key/value配置)
    ├── LLT (sequence:3) — UT/ST测试 + codecheck等, 23个Job, INIT(未执行)
    ├── lcov (sequence:4) — 覆盖率报告, INIT
    └── 后处理阶段 (sequence:5) — last_comment + Resource Clean, FAILED
```

### 4.1 Stage 依赖关系

```
阶段_1 → Image → 编译构建 → LLT → lcov
                                └→ 后处理阶段 (run_always:true)
```

### 4.2 Job 状态枚举

- `COMPLETED` — 成功
- `FAILED` — 失败（message 字段含错误信息）
- `INIT` — 未执行（因前置阶段失败）
- `ABORTED` — 被中止

### 4.3 典型错误信息

```json
{"errorMessage":" 构建任务执行失败!","errorCode":"DEV-CODECI-35002"}
```

## 5. 架构设计方案

### 5.1 分层设计（已与用户达成共识）

**Level 1: PR 评论解析 + 触发（纯 GitCode API）** ✅ 已实现
- 不依赖 openLiBing，只用 GITCODE_API_TOKEN
- 工具 1: `get_pr_pipeline_summary(owner, repo, pr_number)` — 解析 cann-robot 评论提取任务状态表，通过 PR labels 判断流水线状态（running/passed/failed），支持分页获取所有评论确保取到最后一次 pipeline 结果
- 工具 2: `trigger_pr_pipeline(owner, repo, pr_number)` — 在 PR 中发 `compile` 评论触发流水线

**Level 2: openLiBing 详情（需 openLiBing JWT）**
- 获取 stage/job/step 级别的详细信息和错误消息
- 工具: `get_pipeline_run_detail(pipeline_id, pipeline_run_id)`
- 需要解决 JWT 获取和续期问题
- **后续实现**，用于获取失败的详细信息

### 5.2 流水线状态判断

通过 PR labels 判断流水线状态（比解析评论更准确）：

| PR Label | pipeline_status |
|----------|----------------|
| `ci-pipeline-running` | `running` |
| `ci-pipeline-passed` | `passed` |
| `ci-pipeline-failed` | `failed` |
| 都没有 | `unknown` |

### 5.3 职责划分

| 职责 | 归属 | 原因 |
|------|------|------|
| 发 `compile` 评论触发流水线 | MCP 工具 | 原子操作 |
| 查询最新 pipeline 结果 | MCP 工具 | 原子操作 |
| 等待流水线完成（轮询） | 调用方（Claude Code / 用户） | 等待时间分钟~几十分钟级 |
| 判断是否需要重新触发 | 调用方 | 业务决策 |

### 5.4 代码结构

```
src/cann_gitcode_mcp/
├── client.py              # 现有 GitCodeClient (Bearer token auth)
├── openlibing_client.py   # 待实现: OpenLiBingClient (JWT + CSRF auth, auto-refresh)
└── tools/
    ├── pull_request.py    # 7 个 PR 工具（含 list_pull_request_comments）
    └── pipeline.py        # 2 个 pipeline 工具（trigger + summary）
```

### 5.5 环境变量

| 变量 | 用途 | Level |
|------|------|-------|
| `GITCODE_API_TOKEN` | GitCode API 认证 | Level 1 |
| `OPENLIBING_TOKEN` | openLiBing JWT token | Level 2 |

## 6. 待确认/待探索

- [ ] openLiBing 是否有获取单个 Job 日志的接口（需要用户在 Web UI 上抓包）
- [ ] openLiBing JWT 的自动获取方案（OAuth flow 还是手动提供）
- [ ] 是否有其他 openLiBing 接口（如项目列表、流水线列表等）

## 7. 参考

- GitCode PR 评论 API: `GET /api/v5/repos/{owner}/{repo}/pulls/{number}/comments`
- openLiBing Pipeline Detail: `GET /gateway/openlibing-cicd/project/pipeline/pipeline-run/detail`
- 示例 PR: https://gitcode.com/cann/ge/pull/1601
- 示例 Pipeline Run ID: `aaa5c9122dbb44b0bbdd2890218a92f2`
- 示例 Pipeline ID: `8033cdebd5e5420e9165181589392a80`
- Project ID: `300033`, Project Name: `CANN`
