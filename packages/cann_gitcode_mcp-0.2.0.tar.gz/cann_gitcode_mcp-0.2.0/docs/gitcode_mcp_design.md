# CANN GitCode MCP Server 设计文档

## 1. 背景与目标

### 1.1 背景

CANN 社区的开发工作整体基于 GitCode 平台。在日常开发中，CANN 开发者需要频繁与 GitCode 交互：创建 PR、触发 CANN CI 流水线、查询流水线状态、管理 Issue 等。这些操作通常需要在浏览器和 IDE 之间频繁切换，打断开发流程。

MCP (Model Context Protocol) 是 Anthropic 推出的开放协议，允许 AI 助手（如 Claude Code）通过标准化接口调用外部工具。本项目（cann-gitcode-mcp）将 GitCode 平台操作封装为 MCP Server，同时叠加 CANN 特有的工作流能力（如 CI 流水线触发与查询）。CANN 开发者可以直接在 AI 助手中完成所有 GitCode 操作，无需离开开发环境。

### 1.2 目标

- 将 GitCode 通用操作和 CANN 特有工作流封装为 MCP 工具（Tools），供 Claude Code 等 MCP 客户端调用
- 第一期实现 PR 相关操作，后续迭代扩展流水线、Issue 等功能
- 保持架构简洁，易于扩展

---

## 2. GitCode API 调研

### 2.1 API 体系概览

GitCode 提供两套 REST API：

| API 风格 | 认证方式 | Base URL | 特点 |
|---------|---------|----------|------|
| **v5 (Gitee 兼容)** | `Authorization: Bearer <token>` | `https://gitcode.com/api/v5/` | 文档完善，参数清晰，覆盖面广 |
| **v4 (GitLab 兼容)** | `PRIVATE-TOKEN: <token>` | `https://api.gitcode.com/api/v4/` | 部分高级功能 |

**选型结论：主要使用 v5 API。** 原因：
1. OpenAPI 规范完整（可从 `https://gitee.com/api/v5/doc_json` 获取，GitCode v5 与 Gitee v5 兼容）
2. 文档清晰，社区资料丰富
3. 覆盖 PR、Issue、仓库、分支、标签、Webhook 等所有常用操作

### 2.2 认证方式

支持三种认证方式：

| 方式 | 格式 | 适用场景 |
|------|------|---------|
| Bearer Token (Header) | `Authorization: Bearer {token}` | **推荐**，标准 OAuth2 方式 |
| Query 参数 | `?access_token={token}` | 简单场景，不推荐（token 暴露在 URL 中） |
| OAuth 2.0 授权流程 | 授权码 → Token | Web 应用，需要用户授权 |

OAuth 2.0 端点：
- 授权：`https://gitcode.com/oauth/authorize`
- Token 交换：`https://gitcode.com/oauth/token`

MCP Server 场景下推荐使用 **Bearer Token**，通过环境变量注入。

### 2.3 PR 相关 API 详细分析

#### 2.3.1 创建 PR

```
POST /api/v5/repos/{owner}/{repo}/pulls
```

**路径参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `owner` | string | 是 | 仓库命名空间（组织或用户路径） |
| `repo` | string | 是 | 仓库名称 |

**请求体参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `title` | string | **是** | PR 标题 |
| `head` | string | **是** | 源分支，格式：`branch` 或 `namespace:branch`（跨 fork 时使用后者） |
| `base` | string | **是** | 目标分支名称 |
| `body` | string | 否 | PR 描述（支持 Markdown） |
| `milestone_number` | integer | 否 | 里程碑 ID |
| `labels` | string | 否 | 逗号分隔的标签，每个 2-20 字符，如 `bug,performance` |
| `issue` | string | 否 | 关联的 Issue ID，可自动填充标题和描述 |
| `assignees` | string | 否 | 逗号分隔的审查者用户名，如 `user1,user2` |
| `testers` | string | 否 | 逗号分隔的测试者用户名 |
| `assignees_number` | integer | 否 | 最少审查者人数 |
| `testers_number` | integer | 否 | 最少测试者人数 |
| `ref_pull_request_numbers` | string | 否 | 同仓库内依赖的 PR 编号，如 `17,18,19` |
| `prune_source_branch` | boolean | 否 | 合并后删除源分支（默认 false） |
| `close_related_issue` | boolean | 否 | 合并时关闭关联 Issue |
| `draft` | boolean | 否 | 创建为草稿 PR |
| `squash` | boolean | 否 | 使用 squash 合并 |
| `security_hole` | boolean | 否 | 私有/安全 PR |

**响应：** `201 Created`，返回 `PullRequest` 对象，包含 `id`、`number`、`title`、`body`、`state`、`head`、`base`、`html_url`、`diff_url`、`patch_url`、`created_at`、`updated_at`、`merged_at`、`closed_at`、`draft`、`mergeable`、`labels`、`assignees`、`testers`、`user`、`milestone`、`_links` 等字段。

**请求示例：**

```bash
curl -s -X POST "https://gitcode.com/api/v5/repos/cann/ge/pulls" \
  -H "Authorization: Bearer $GITCODE_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "fix: resolve build error (#32)",
    "head": "username:fix/issue-32",
    "base": "develop",
    "body": "## Summary\n\nFix the build error caused by missing header.\n\n## Test Plan\n\n- [x] Unit tests pass"
  }'
```

#### 2.3.2 其他 PR 操作

| 操作 | 方法 | 端点 | 说明 |
|------|------|------|------|
| 列出 PR | GET | `/repos/{owner}/{repo}/pulls` | 支持 state/sort/direction/page 等过滤 |
| 获取 PR 详情 | GET | `/repos/{owner}/{repo}/pulls/{number}` | 返回完整 PR 信息 |
| 更新 PR | PATCH | `/repos/{owner}/{repo}/pulls/{number}` | 修改标题、描述、状态等 |
| 合并 PR | PUT | `/repos/{owner}/{repo}/pulls/{number}/merge` | 支持 merge/squash/rebase 方式 |
| PR 评论 | POST | `/repos/{owner}/{repo}/pulls/{number}/comments` | 添加普通评论 |
| PR 行内评论 | POST | `/repos/{owner}/{repo}/pulls/{number}/comments` | 在 diff 特定行添加评论 |
| 获取 PR 评论 | GET | `/repos/{owner}/{repo}/pulls/{number}/comments` | 获取所有评论 |
| PR 标签 | POST/DELETE | `/repos/{owner}/{repo}/pulls/{number}/labels` | 管理 PR 标签 |
| PR 审查者 | POST/DELETE | `/repos/{owner}/{repo}/pulls/{number}/assignees` | 管理审查者 |
| PR 测试者 | POST/DELETE | `/repos/{owner}/{repo}/pulls/{number}/testers` | 管理测试者 |
| PR 文件列表 | GET | `/repos/{owner}/{repo}/pulls/{number}/files` | 获取 PR 改动的文件 |

### 2.4 流水线/CI 相关说明

CANN 项目的 CI/CD 流水线由 **CANN 工程团队自建**，并非 GitCode 平台原生功能。其工作方式为：

1. **触发方式**：开发者在 PR 评论区输入特定命令（如特定关键词），自建系统监听评论事件后触发对应的流水线
2. **状态查询**：流水线执行状态通过 CANN 工程团队的 Web 页面查看，而非 GitCode API

因此，MCP Server 中的流水线相关工具**不是基于 GitCode REST API**，而是需要：

- **触发流水线**：通过 PR 评论 API (`POST /repos/{owner}/{repo}/pulls/{number}/comments`) 发送触发命令
- **查询流水线状态**：通过爬取/调用 CANN 工程团队的流水线 Web 页面获取状态

> **待调研：** CANN 流水线的具体触发命令格式、流水线状态页面的 URL 规则和数据获取方式，需要后续与工程团队对齐后补充。

GitCode 平台本身也提供 **Check Runs** API，可用于将 CI 状态回写到 PR 页面（供参考）：

| 操作 | 方法 | 端点 | 说明 |
|------|------|------|------|
| 创建 Check Run | POST | `/repos/{owner}/{repo}/check-runs` | 创建检查记录 |
| 获取 Check Run | GET | `/repos/{owner}/{repo}/check-runs/{id}` | 查询检查详情 |
| 更新 Check Run | PATCH | `/repos/{owner}/{repo}/check-runs/{id}` | 更新状态和结论 |
| Commit 检查 | GET | `/repos/{owner}/{repo}/commits/{ref}/check-runs` | 获取某次提交的所有检查 |

### 2.5 其他可用 API 汇总

| 类别 | 端点数量 | 关键操作 |
|------|---------|---------|
| **仓库** | ~76 | 文件 CRUD、分支管理、设置、协作者、Fork |
| **Issue** | ~21 | Issue CRUD、评论、标签 |
| **分支** | ~8 | 列出/创建/删除分支、分支保护 |
| **标签** | ~16 | 仓库/Issue/PR 标签管理 |
| **Commit** | 若干 | 列出提交、获取提交详情 |
| **Tag** | 若干 | 列出/创建/删除标签 |
| **Webhook** | ~6 | Webhook CRUD、测试 |
| **里程碑** | ~5 | 里程碑 CRUD |
| **组织** | ~14 | 组织管理、成员、仓库 |
| **用户** | ~18 | 用户信息、关注、SSH Key |
| **搜索** | ~3 | 搜索 Issue、仓库、用户 |
| **Activity** | ~26 | 事件、通知、Star、Watch |

---

## 3. 架构选型

### 3.1 技术栈

| 决策项 | 选择 | 理由 |
|-------|------|------|
| **语言** | Python >= 3.11 | CANN 团队日常使用，零学习成本，环境已就绪 |
| **MCP SDK** | `mcp` (官方 Python SDK) | Anthropic 官方维护，与 TypeScript SDK 功能对等 |
| **传输方式** | stdio（主） + SSE（可选） | stdio 适合本地 Claude Code 使用；SSE 适合远程/团队部署 |
| **HTTP 客户端** | `httpx` | 支持 async，MCP Python SDK 已依赖 |
| **参数校验** | `pydantic` | MCP Python SDK 内置依赖，用于工具参数定义 |
| **包管理** | `uv` 或 `pip` | uv 速度快，pip 兼容性好 |

### 3.2 依赖清单

```toml
# pyproject.toml
[project]
name = "cann-gitcode-mcp"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "mcp>=1.0",
    "httpx>=0.27",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.24",
]
```

运行时依赖仅 2 个（`pydantic` 是 `mcp` 的传递依赖，无需显式声明）。

---

## 4. 架构设计

### 4.1 整体架构

```
┌─────────────────┐     stdio / SSE      ┌──────────────────┐      HTTPS       ┌──────────────┐
│                 │ ◄──────────────────► │                  │ ────────────────► │              │
│   MCP Client    │   MCP Protocol       │  GitCode MCP     │   REST API v5    │  gitcode.com │
│  (Claude Code)  │   (JSON-RPC 2.0)     │    Server        │                  │              │
│                 │ ◄──────────────────► │                  │ ◄──────────────── │              │
└─────────────────┘                      └──────────────────┘                  └──────────────┘
                                                │
                                                │ 读取
                                                ▼
                                         ┌──────────────┐
                                         │ 环境变量      │
                                         │ GITCODE_API  │
                                         │ _TOKEN       │
                                         └──────────────┘
```

### 4.2 内部模块结构

```
┌──────────────────────────────────────────────────────┐
│                   MCP Server (server.py)              │
│                                                      │
│  ┌──────────┐  ┌──────────┐  ┌───────────────────┐   │
│  │ Transport │  │ Tool     │  │ Error Handler     │   │
│  │ (stdio/  │  │ Registry │  │                   │   │
│  │  SSE)    │  │          │  │                   │   │
│  └──────────┘  └────┬─────┘  └───────────────────┘   │
│                     │                                 │
│         ┌───────────┼───────────┐                     │
│         ▼           ▼           ▼                     │
│  ┌────────────┐ ┌─────────┐ ┌────────────┐           │
│  │ PR Tools   │ │Pipeline │ │ Repo Tools │  ...      │
│  │            │ │ Tools   │ │            │           │
│  └──────┬─────┘ └────┬────┘ └─────┬──────┘           │
│         │            │            │                   │
│         └────────────┼────────────┘                   │
│                      ▼                                │
│            ┌──────────────────┐                       │
│            │  GitCode Client  │                       │
│            │   (client.py)    │                       │
│            └──────────────────┘                       │
└──────────────────────────────────────────────────────┘
```

### 4.3 目录结构

```
cann-gitcode-mcp/
├── pyproject.toml            # 项目配置、依赖
├── README.md                 # 使用说明
└── src/
    └── cann_gitcode_mcp/
        ├── __init__.py
        ├── server.py         # 入口：创建 MCP Server，注册工具，启动传输
        ├── client.py         # GitCode API 客户端封装（认证、请求、错误处理）
        └── tools/
            ├── __init__.py
            ├── pull_request.py   # PR 工具集（create, list, get, merge, comment）
            ├── pipeline.py       # 流水线工具集（通过 PR 评论触发 + 状态查询）
            └── repository.py     # 仓库工具集（branches, files, commits）
```

### 4.4 核心模块设计

#### 4.4.1 入口模块 (`src/cann_gitcode_mcp/server.py`)

职责：创建 MCP Server 实例，注册所有工具模块，启动传输层。

```python
import asyncio

from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.tools.pull_request import register_pull_request_tools
# from cann_gitcode_mcp.tools.pipeline import register_pipeline_tools       # 第二期
# from cann_gitcode_mcp.tools.repository import register_repository_tools   # 第三期

mcp = FastMCP("gitcode", version="0.1.0")

# 注册工具模块
register_pull_request_tools(mcp)
# register_pipeline_tools(mcp)
# register_repository_tools(mcp)


def main():
    """stdio 模式启动入口"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
```

#### 4.4.2 API 客户端 (`src/cann_gitcode_mcp/client.py`)

职责：封装 GitCode API 调用，统一处理认证、请求构造、错误处理。

```python
from __future__ import annotations

import os
from typing import Any

import httpx


class GitCodeClient:
    """GitCode v5 API 客户端"""

    def __init__(
        self,
        token: str | None = None,
        base_url: str | None = None,
    ) -> None:
        self.token = token or os.environ.get("GITCODE_API_TOKEN", "")
        self.base_url = (
            base_url
            or os.environ.get("GITCODE_API_BASE_URL")
            or "https://gitcode.com/api/v5"
        )

        if not self.token:
            raise ValueError(
                "GitCode API token is required. "
                "Set GITCODE_API_TOKEN environment variable."
            )

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        response = await self._client.request(
            method, path, json=json, params=params,
        )
        if not response.is_success:
            raise RuntimeError(
                f"GitCode API error {response.status_code}: {response.text}"
            )
        if response.status_code == 204:
            return None
        return response.json()

    # 便捷方法
    async def get(self, path: str, **params: Any) -> Any:
        return await self.request("GET", path, params=params or None)

    async def post(self, path: str, json: dict[str, Any] | None = None) -> Any:
        return await self.request("POST", path, json=json)

    async def patch(self, path: str, json: dict[str, Any] | None = None) -> Any:
        return await self.request("PATCH", path, json=json)

    async def put(self, path: str, json: dict[str, Any] | None = None) -> Any:
        return await self.request("PUT", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self.request("DELETE", path)

    async def close(self) -> None:
        await self._client.aclose()
```

#### 4.4.3 PR 工具模块 (`src/cann_gitcode_mcp/tools/pull_request.py`)

职责：注册所有 PR 相关的 MCP 工具。

```python
from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from cann_gitcode_mcp.client import GitCodeClient

_client: GitCodeClient | None = None


def _get_client() -> GitCodeClient:
    global _client
    if _client is None:
        _client = GitCodeClient()
    return _client


def _text_result(data: Any) -> str:
    return json.dumps(data, indent=2, ensure_ascii=False)


def register_pull_request_tools(mcp: FastMCP) -> None:

    # ---------- 创建 PR ----------
    @mcp.tool()
    async def create_pull_request(
        owner: str,
        repo: str,
        title: str,
        head: str,
        base: str,
        body: str | None = None,
        draft: bool | None = None,
        labels: str | None = None,
        assignees: str | None = None,
        testers: str | None = None,
        prune_source_branch: bool | None = None,
        squash: bool | None = None,
    ) -> str:
        """在 GitCode 仓库创建 Pull Request

        Args:
            owner: 仓库命名空间（组织或用户路径）
            repo: 仓库名称
            title: PR 标题
            head: 源分支，格式: branch 或 namespace:branch
            base: 目标分支
            body: PR 描述（Markdown）
            draft: 是否创建为草稿 PR
            labels: 逗号分隔的标签
            assignees: 逗号分隔的审查者用户名
            testers: 逗号分隔的测试者用户名
            prune_source_branch: 合并后删除源分支
            squash: 使用 squash 合并
        """
        client = _get_client()
        payload: dict[str, Any] = {"title": title, "head": head, "base": base}
        for key in ("body", "draft", "labels", "assignees", "testers",
                     "prune_source_branch", "squash"):
            val = locals()[key]
            if val is not None:
                payload[key] = val

        result = await client.post(f"/repos/{owner}/{repo}/pulls", json=payload)
        return _text_result(result)

    # ---------- 列出 PR ----------
    @mcp.tool()
    async def list_pull_requests(
        owner: str,
        repo: str,
        state: str | None = None,
        sort: str | None = None,
        direction: str | None = None,
        page: int | None = None,
        per_page: int | None = None,
    ) -> str:
        """列出 GitCode 仓库的 Pull Request

        Args:
            owner: 仓库命名空间
            repo: 仓库名称
            state: PR 状态过滤（open/closed/merged/all，默认 open）
            sort: 排序方式（created/updated/popularity）
            direction: 排序方向（asc/desc）
            page: 页码
            per_page: 每页数量（默认 20）
        """
        client = _get_client()
        params = {
            k: v for k, v in {
                "state": state, "sort": sort, "direction": direction,
                "page": page, "per_page": per_page,
            }.items() if v is not None
        }
        result = await client.get(f"/repos/{owner}/{repo}/pulls", **params)
        return _text_result(result)

    # ---------- 获取 PR 详情 ----------
    @mcp.tool()
    async def get_pull_request(owner: str, repo: str, number: int) -> str:
        """获取 GitCode 仓库的 Pull Request 详情

        Args:
            owner: 仓库命名空间
            repo: 仓库名称
            number: PR 编号
        """
        client = _get_client()
        result = await client.get(f"/repos/{owner}/{repo}/pulls/{number}")
        return _text_result(result)

    # ---------- 合并 PR ----------
    @mcp.tool()
    async def merge_pull_request(
        owner: str,
        repo: str,
        number: int,
        merge_method: str | None = None,
        prune_source_branch: bool | None = None,
    ) -> str:
        """合并 GitCode 仓库的 Pull Request

        Args:
            owner: 仓库命名空间
            repo: 仓库名称
            number: PR 编号
            merge_method: 合并方式（merge/squash/rebase，默认 merge）
            prune_source_branch: 合并后删除源分支
        """
        client = _get_client()
        payload: dict[str, Any] = {"merge_method": merge_method or "merge"}
        if prune_source_branch is not None:
            payload["prune_source_branch"] = prune_source_branch

        result = await client.put(
            f"/repos/{owner}/{repo}/pulls/{number}/merge", json=payload,
        )
        return _text_result(result)

    # ---------- 评论 PR ----------
    @mcp.tool()
    async def comment_pull_request(
        owner: str, repo: str, number: int, body: str,
    ) -> str:
        """在 GitCode Pull Request 上添加评论

        Args:
            owner: 仓库命名空间
            repo: 仓库名称
            number: PR 编号
            body: 评论内容（Markdown）
        """
        client = _get_client()
        result = await client.post(
            f"/repos/{owner}/{repo}/pulls/{number}/comments",
            json={"body": body},
        )
        return _text_result(result)

    # ---------- 获取 PR 改动文件 ----------
    @mcp.tool()
    async def get_pull_request_files(
        owner: str, repo: str, number: int,
    ) -> str:
        """获取 GitCode Pull Request 改动的文件列表

        Args:
            owner: 仓库命名空间
            repo: 仓库名称
            number: PR 编号
        """
        client = _get_client()
        result = await client.get(
            f"/repos/{owner}/{repo}/pulls/{number}/files",
        )
        return _text_result(result)
```

---

## 5. MCP 工具清单与迭代计划

### 5.1 第一期：PR 操作（P0）

| 工具名称 | 功能 | 对应 API |
|---------|------|---------|
| `create_pull_request` | 创建 PR | `POST /repos/{owner}/{repo}/pulls` |
| `list_pull_requests` | 列出 PR | `GET /repos/{owner}/{repo}/pulls` |
| `get_pull_request` | 获取 PR 详情 | `GET /repos/{owner}/{repo}/pulls/{number}` |
| `merge_pull_request` | 合并 PR | `PUT /repos/{owner}/{repo}/pulls/{number}/merge` |
| `comment_pull_request` | 评论 PR | `POST /repos/{owner}/{repo}/pulls/{number}/comments` |
| `get_pull_request_files` | 获取 PR 文件列表 | `GET /repos/{owner}/{repo}/pulls/{number}/files` |

### 5.2 第二期：流水线/CI（P1）

CANN 流水线通过 PR 评论触发，状态通过工程团队 Web 页面查询。

| 工具名称 | 功能 | 实现方式 |
|---------|------|---------|
| `trigger_pipeline` | 在 PR 评论区发送流水线触发命令 | 基于 PR 评论 API (`POST /repos/.../pulls/{number}/comments`) |
| `get_pipeline_status` | 查询流水线执行状态 | 基于 CANN 工程团队流水线 Web 页面（待调研具体接口） |
| `list_commit_check_runs` | 获取提交的 Check Run 状态 | `GET /repos/{owner}/{repo}/commits/{ref}/check-runs` |

> **注意：** 触发命令格式和状态页面 URL 需与 CANN 工程团队对齐后补充。

### 5.3 第三期：仓库与 Issue（P2）

| 工具名称 | 功能 | 对应 API |
|---------|------|---------|
| `list_branches` | 列出分支 | `GET /repos/{owner}/{repo}/branches` |
| `create_branch` | 创建分支 | `POST /repos/{owner}/{repo}/branches` |
| `get_file_content` | 获取文件内容 | `GET /repos/{owner}/{repo}/contents/{path}` |
| `list_issues` | 列出 Issue | `GET /repos/{owner}/{repo}/issues` |
| `get_issue` | 获取 Issue 详情 | `GET /repos/{owner}/{repo}/issues/{number}` |
| `create_issue` | 创建 Issue | `POST /repos/{owner}/{repo}/issues` |
| `comment_issue` | 评论 Issue | `POST /repos/{owner}/{repo}/issues/{number}/comments` |
| `search_repos` | 搜索仓库 | `GET /search/repositories` |

### 5.4 可选扩展（P3）

| 工具名称 | 功能 |
|---------|------|
| `list_webhooks` | 列出 Webhook |
| `create_webhook` | 创建 Webhook |
| `list_milestones` | 列出里程碑 |
| `manage_labels` | 管理标签 |
| `get_user_info` | 获取用户信息 |

---

## 6. 客户端集成配置

### 6.1 Claude Code 配置

在项目 `.claude/settings.json` 或全局 `~/.claude/settings.json` 中添加：

```json
{
  "mcpServers": {
    "gitcode": {
      "command": "python",
      "args": ["-m", "cann_gitcode_mcp.server"],
      "env": {
        "GITCODE_API_TOKEN": "${GITCODE_API_TOKEN}"
      }
    }
  }
}
```

也可以使用 `uv` 直接运行（无需预先安装）：

```json
{
  "mcpServers": {
    "gitcode": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/cann-gitcode-mcp", "python", "-m", "cann_gitcode_mcp.server"],
      "env": {
        "GITCODE_API_TOKEN": "${GITCODE_API_TOKEN}"
      }
    }
  }
}
```

### 6.2 环境变量

| 变量名 | 必填 | 说明 |
|-------|------|------|
| `GITCODE_API_TOKEN` | 是 | GitCode 个人访问令牌 |
| `GITCODE_API_BASE_URL` | 否 | API 基础 URL，默认 `https://gitcode.com/api/v5` |

### 6.3 构建与运行

```bash
# 方式一：使用 uv（推荐）
uv sync                    # 安装依赖
uv run python -m cann_gitcode_mcp.server   # 启动 server

# 方式二：使用 pip
pip install -e .           # 安装到当前环境
python -m cann_gitcode_mcp.server          # 启动 server

# 本地测试（stdio 模式，验证工具注册）
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python -m cann_gitcode_mcp

# 通过 Claude Code 使用
# 配置好 mcpServers 后，Claude Code 会自动启动 MCP Server
```

---

## 7. 错误处理策略

| 场景 | 处理方式 |
|------|---------|
| Token 未配置 | Server 启动时抛出明确错误信息 |
| API 返回 4xx | 将状态码和错误信息包装为 MCP 错误返回给客户端 |
| API 返回 5xx | 同上，附带重试建议 |
| 网络超时 | httpx 超时（默认 30s），错误信息中说明网络问题 |
| 参数校验失败 | FastMCP 基于函数签名和类型注解自动校验，返回参数错误描述 |

---

## 8. 安全考量

1. **Token 保护**：Token 仅通过环境变量注入，不硬编码、不记录日志
2. **最小权限**：建议用户创建仅包含所需权限的 Token
3. **传输安全**：与 GitCode API 通信使用 HTTPS
4. **输入校验**：所有工具参数通过 FastMCP 类型注解自动校验，防止注入

---

## 9. 附录

### 9.1 GitCode API 文档入口

- 官方文档：https://docs.gitcode.com/docs/apis/
- v5 API OpenAPI 规范（Gitee 兼容）：https://gitee.com/api/v5/doc_json
- OAuth 文档：https://docs.gitcode.com/docs/apis/oauth/

### 9.2 MCP 协议参考

- MCP 规范：https://spec.modelcontextprotocol.io/
- MCP Python SDK：https://github.com/modelcontextprotocol/python-sdk
- MCP Server 开发指南：https://modelcontextprotocol.io/docs/concepts/servers
