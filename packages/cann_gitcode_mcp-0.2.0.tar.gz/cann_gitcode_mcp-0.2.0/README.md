# cann-gitcode-mcp

[![PyPI version](https://img.shields.io/pypi/v/cann-gitcode-mcp)](https://pypi.org/project/cann-gitcode-mcp/)
[![Python](https://img.shields.io/pypi/pyversions/cann-gitcode-mcp)](https://pypi.org/project/cann-gitcode-mcp/)
[![License](https://img.shields.io/pypi/l/cann-gitcode-mcp)](https://github.com/shengnan666/cann-gitcode-mcp/blob/main/LICENSE)

CANN 社区的代码托管在 [GitCode](https://gitcode.com/) 平台。`cann-gitcode-mcp` 将 GitCode API 封装为 [MCP](https://modelcontextprotocol.io/) 工具，让 CANN 开发者在 Claude Code 等 AI 助手中直接操作仓库的 Pull Request、Issue、流水线等，无需离开对话界面。

## 快速开始

### 1. 安装

```bash
pip install cann-gitcode-mcp
```

### 2. 配置 Claude Code

先在 [GitCode 用户设置](https://gitcode.com/setting/token-classic) 中生成个人访问令牌，然后在 Claude Code 的 MCP 配置文件（`~/.claude/settings.json` 或项目级 `.mcp.json`）中添加：

```json
{
  "mcpServers": {
    "gitcode": {
      "command": "cann-gitcode-mcp",
      "env": {
        "GITCODE_API_TOKEN": "your_token_here"
      }
    }
  }
}
```

重启 Claude Code 即可使用。

> **环境变量说明**：Token 通过 MCP 配置的 `env` 字段传入即可，无需手动 `export`。如需覆盖 API 地址，可额外设置 `GITCODE_API_BASE_URL`（默认 `https://gitcode.com/api/v5`）。

## 可用工具

### Pull Request

| 工具名 | 说明 |
|--------|------|
| `create_pull_request` | 创建 Pull Request |
| `list_pull_requests` | 列出仓库的 Pull Request（支持状态、排序等过滤） |
| `get_pull_request` | 获取指定 PR 的详细信息 |
| `merge_pull_request` | 合并 Pull Request |
| `comment_pull_request` | 在 PR 上发表评论 |
| `get_pull_request_files` | 获取 PR 的变更文件列表 |
| `list_pull_request_comments` | 获取 PR 的所有评论 |

### Pipeline（流水线）

| 工具名 | 说明 |
|--------|------|
| `get_pr_pipeline_summary` | 获取 PR 的 CI/CD 流水线摘要（解析 cann-robot 评论） |

`get_pr_pipeline_summary` 从 PR 评论中解析 cann-robot 发布的流水线结果，返回每个任务的名称、状态（SUCCESS/FAILED/ABORTED）、日志链接、构建产物下载链接，以及整体 CI 结论。无需 openLiBing token，仅使用 GitCode API。

## 路线图

当前处于早期开发阶段（`0.x`），已实现 PR 工具集和流水线摘要。后续将按 CANN 社区实际研发流程的优先级逐步扩展：

1. **Issue 工具** — Issue 增删改查、评论管理（CANN 社区日常协作最频繁的场景）
2. **仓库工具** — 分支管理、文件读取、提交历史
3. **流水线详情（Level 2）** — 通过 openLiBing API 获取 stage/job/step 级别的详细信息和错误消息

欢迎在 [Issue](https://gitcode.com/shengnan666/cann-gitcode-mcp/issues) 中提出需求或反馈。

## 开发

```bash
# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest

# 构建与发布
python -m build
twine upload dist/*
```

## 许可证

[Apache License 2.0](LICENSE)
