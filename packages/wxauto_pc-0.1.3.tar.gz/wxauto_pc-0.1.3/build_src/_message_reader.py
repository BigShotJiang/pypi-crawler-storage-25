"""消息读取器。"""

from __future__ import annotations

from typing import Dict, List, Optional

from wxauto_pc.core.client import WeChatClient


class MessageReader:
    """微信消息读取器。"""

    def __init__(self, client: Optional[WeChatClient] = None):
        self.client = client or WeChatClient()

    def read_latest_from_chat(self, chat_name: str, count: int | None = None) -> List[Dict[str, object]]:
        if not self.client.switch_to_chat(chat_name):
            raise ValueError(f"未找到聊天: {chat_name}")

        # 判断聊天类型
        chat_type = self.client._detect_chat_type()
        is_group = chat_type == "group"
        messages = self.client.get_latest_messages(None)
        if is_group:
            messages = self._mark_my_messages(messages, chat_name, is_group)
        else:
            messages = self._format_private_messages(messages, chat_name, is_group)
        return messages[-count:] if count else messages

    def _mark_my_messages(self, messages: List[Dict[str, object]], chat_name: str, is_group: bool = False) -> List[Dict[str, object]]:
        formatted = []
        current_time = ""

        # 调用封装好的方法获取消息内容到发送人信息的映射
        content_to_sender = self.client.get_group_senders_info(messages)

        for msg in messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue

            content = msg["content"]
            raw_content = msg.get("raw_content", content)
            is_mine = self.client.message_cache.is_sent_by_me(content, chat_name)

            if is_mine:
                sender = "我"
                sender_id = ""
                sender_info = None
            else:
                # 根据消息内容查找发送人信息
                sender_info = content_to_sender.get(raw_content)
                if sender_info:
                    sender = sender_info.get("nickname", "群成员")
                    sender_id = sender_info.get("wechat_id", "")
                else:
                    sender = "群成员"
                    sender_id = ""

            formatted.append(
                {
                    "sender": sender,
                    "senderId": sender_id,
                    "content": content,
                    "time": current_time,
                    "formatted_content": f"[{current_time}][{sender}] {content}",
                    "raw_content": raw_content,
                    "is_group": is_group,
                    "chat_type": "group",
                    "sender_info": sender_info,
                }
            )
        return formatted

    def _format_private_messages(self, messages: List[Dict[str, object]], chat_name: str, is_group: bool = False) -> List[Dict[str, object]]:
        formatted = []
        current_time = ""

        # 获取对方的发送人信息（私聊只需要获取一次）
        sender_info = None
        try:
            info = self.client.get_sender_info(chat_name)
            if info and not info.get("error"):
                sender_info = info
        except Exception:
            pass

        for msg in messages:
            if msg.get("is_time", False):
                current_time = msg["content"]
                continue
            content = msg["content"]
            raw_content = msg.get("raw_content", content)
            is_mine = msg.get("is_mine", False)
            if msg.get("color_ambiguous", True):
                is_mine = self.client.message_cache.is_sent_by_me(content, chat_name)

            if is_mine:
                sender = "我"
                sender_id = ""
                formatted_content = f"[{current_time}][我] {content}"
            else:
                # 使用获取到的真实昵称和微信号
                if sender_info:
                    sender = sender_info.get("nickname", chat_name)
                    sender_id = sender_info.get("wechat_id", "")
                else:
                    sender = chat_name
                    sender_id = ""
                formatted_content = f"[{current_time}][{sender}] {content}"

            formatted.append(
                {
                    "sender": sender,
                    "senderId": sender_id,
                    "content": formatted_content,
                    "time": current_time,
                    "is_mine": is_mine,
                    "raw_content": raw_content,
                    "is_group": is_group,
                    "chat_type": "private",
                    "sender_info": sender_info if not is_mine else None,
                }
            )
        return formatted

    def is_group_chat(self, chat_name: str) -> bool:
        """判断指定聊天是否为群聊。

        Args:
            chat_name: 聊天名称

        Returns:
            True 表示群聊，False 表示私聊
        """
        if not self.client.switch_to_chat(chat_name):
            raise ValueError(f"未找到聊天: {chat_name}")
        chat_type = self.client._detect_chat_type()
        return chat_type == "group"
