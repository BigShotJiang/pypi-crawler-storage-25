import asyncio
import httpx
from .. import config

ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
RETRY_CODES = {429, 503}
RETRY_BACKOFFS = (10, 30)
REQUEST_TIMEOUT = 480.0


async def _call(client: httpx.AsyncClient, model: str, prompt: str, api_key: str) -> httpx.Response:
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "tools": [{"google_search": {}}],
        "generationConfig": {"temperature": 1.0},
    }
    return await client.post(
        ENDPOINT.format(model=model),
        headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
        json=body,
        timeout=REQUEST_TIMEOUT,
    )


async def _try_model(client: httpx.AsyncClient, model: str, prompt: str, api_key: str) -> httpx.Response | None:
    for attempt in range(len(RETRY_BACKOFFS) + 1):
        resp = await _call(client, model, prompt, api_key)
        if resp.status_code == 200:
            return resp
        if resp.status_code in RETRY_CODES and attempt < len(RETRY_BACKOFFS):
            await asyncio.sleep(RETRY_BACKOFFS[attempt])
            continue
        return resp
    return None


def _extract_text(payload: dict) -> str:
    parts = payload.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    return "\n".join(p.get("text", "") for p in parts if "text" in p).strip()


async def research(prompt: str, model: str | None = None) -> str:
    api_key = config.require("GEMINI_API_KEY")
    primary = model or config.get("GEMINI_MODEL", "gemini-2.5-pro")
    fallback = "gemini-2.5-flash"

    async with httpx.AsyncClient() as client:
        resp = await _try_model(client, primary, prompt, api_key)
        if resp is not None and resp.status_code == 200:
            return _extract_text(resp.json())

        if primary != fallback:
            resp = await _try_model(client, fallback, prompt, api_key)
            if resp is not None and resp.status_code == 200:
                return _extract_text(resp.json())

    detail = resp.text if resp is not None else "no response"
    raise RuntimeError(f"Gemini failed (last status {getattr(resp, 'status_code', '???')}): {detail[:500]}")
