import httpx
from .. import config

ENDPOINT = "https://api.perplexity.ai/chat/completions"
REQUEST_TIMEOUT = 480.0


async def research(prompt: str, model: str | None = None, deep: bool = False) -> str:
    api_key = config.require("PERPLEXITY_API_KEY")
    if model is None:
        model = "sonar-deep-research" if deep else config.get("PERPLEXITY_MODEL", "sonar-pro")

    body = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
    }

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            ENDPOINT,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=body,
            timeout=REQUEST_TIMEOUT,
        )

    if resp.status_code != 200:
        raise RuntimeError(f"Perplexity failed (status {resp.status_code}): {resp.text[:500]}")

    payload = resp.json()
    content = payload["choices"][0]["message"]["content"]
    citations = payload.get("citations") or []
    if citations:
        refs = "\n".join(f"[{i + 1}] {url}" for i, url in enumerate(citations))
        return f"{content}\n\n---\nSources:\n{refs}"
    return content
