from mcp.server.fastmcp import FastMCP
from . import config
from .providers import gemini, perplexity

mcp = FastMCP("idea-vault-gateway")


@mcp.tool()
async def gemini_research(prompt: str, model: str | None = None) -> str:
    """Run a Gemini query with google_search grounding. Falls back to gemini-2.5-flash on persistent 429/503."""
    return await gemini.research(prompt, model=model)


@mcp.tool()
async def perplexity_research(prompt: str, model: str | None = None, deep: bool = False) -> str:
    """Run a Perplexity Sonar query. Set deep=True for sonar-deep-research (slower, more thorough)."""
    return await perplexity.research(prompt, model=model, deep=deep)


def run(transport: str = "stdio") -> None:
    config.load()
    mcp.run(transport=transport)
