import typer
from . import __version__, config, server

app = typer.Typer(no_args_is_help=True, add_completion=False, help="Idea Vault Gateway — local MCP bridge to Gemini and Perplexity.")


@app.command()
def mcp(transport: str = typer.Option("stdio", help="MCP transport: stdio | sse | streamable-http")) -> None:
    """Run the MCP server."""
    server.run(transport=transport)


@app.command()
def version() -> None:
    typer.echo(__version__)


@app.command()
def init(
    gemini_key: str = typer.Option("", "--gemini-key", help="Gemini API key (prompt if omitted)."),
    perplexity_key: str = typer.Option("", "--perplexity-key", help="Perplexity API key (prompt if omitted)."),
) -> None:
    """Write API keys to ~/.config/idea-vault-gateway/.env. Optional — env vars in the MCP config block also work."""
    if not gemini_key:
        gemini_key = typer.prompt("GEMINI_API_KEY (leave empty to skip)", default="", show_default=False)
    if not perplexity_key:
        perplexity_key = typer.prompt("PERPLEXITY_API_KEY (leave empty to skip)", default="", show_default=False)

    config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = []
    if gemini_key:
        lines.append(f"GEMINI_API_KEY={gemini_key}")
    if perplexity_key:
        lines.append(f"PERPLEXITY_API_KEY={perplexity_key}")
    if not lines:
        typer.echo("No keys provided; nothing written.")
        raise typer.Exit(code=1)

    config.ENV_FILE.write_text("\n".join(lines) + "\n")
    config.ENV_FILE.chmod(0o600)
    typer.echo(f"Wrote {config.ENV_FILE}")


if __name__ == "__main__":
    app()
