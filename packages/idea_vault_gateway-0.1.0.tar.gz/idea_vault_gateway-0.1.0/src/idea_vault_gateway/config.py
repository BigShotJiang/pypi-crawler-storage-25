import os
from pathlib import Path
from dotenv import load_dotenv

CONFIG_DIR = Path(os.environ.get("IDEA_VAULT_GATEWAY_CONFIG_DIR", Path.home() / ".config" / "idea-vault-gateway"))
ENV_FILE = CONFIG_DIR / ".env"


def load() -> None:
    if ENV_FILE.exists():
        load_dotenv(ENV_FILE, override=False)


def get(key: str, default: str | None = None) -> str | None:
    return os.environ.get(key, default)


def require(key: str) -> str:
    value = os.environ.get(key)
    if not value:
        raise RuntimeError(
            f"{key} is not set. Add it to {ENV_FILE} or export it in the MCP server's env block."
        )
    return value
