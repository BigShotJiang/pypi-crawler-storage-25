"""Tests for auto-pagination."""

PAGE_1 = {
    "data": [{"signal_id": "sig_1"}, {"signal_id": "sig_2"}],
    "has_more": True,
    "cursor": "cursor_page2",
}

PAGE_2 = {
    "data": [{"signal_id": "sig_3"}],
    "has_more": False,
}


class TestListAll:
    def test_auto_pagination(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=PAGE_1)
        httpx_mock.add_response(json=PAGE_2)

        items = list(mock_client.signals.list_all(entity="NVIDIA"))
        assert len(items) == 3
        assert items[0]["signal_id"] == "sig_1"
        assert items[2]["signal_id"] == "sig_3"

    def test_single_page(self, mock_client, httpx_mock):
        single_page = {
            "data": [{"signal_id": "sig_1"}],
            "has_more": False,
        }
        httpx_mock.add_response(json=single_page)

        items = list(mock_client.signals.list_all(entity="test"))
        assert len(items) == 1

    def test_entity_list_all(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=PAGE_1)
        httpx_mock.add_response(json=PAGE_2)

        items = list(mock_client.entities.list_all(type_primary="organization"))
        assert len(items) == 3
