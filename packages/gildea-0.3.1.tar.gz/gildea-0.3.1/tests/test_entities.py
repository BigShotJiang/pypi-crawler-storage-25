"""Tests for the entities resource."""

ENTITIES_LIST_RESPONSE = {
    "data": [
        {
            "entity_id": "org:/nvidia",
            "display_name": "NVIDIA",
            "type_primary": "organization",
            "signal_count": 42,
        }
    ],
    "has_more": False,
}

ENTITY_DETAIL_RESPONSE = {
    "entity_id": "org:/nvidia",
    "display_name": "NVIDIA",
    "type_primary": "organization",
    "signal_count": 42,
    "related_entities": [],
}


class TestEntitiesList:
    def test_list_entities(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=ENTITIES_LIST_RESPONSE)
        result = mock_client.entities.list(type_primary="organization")
        assert result["data"][0]["entity_id"] == "org:/nvidia"

    def test_list_with_sort(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=ENTITIES_LIST_RESPONSE)
        result = mock_client.entities.list(sort="trend", limit=10)
        assert len(result["data"]) == 1

    def test_list_with_direction_filter(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=ENTITIES_LIST_RESPONSE)
        result = mock_client.entities.list(direction="Rising", confidence="Significant")
        assert result["data"][0]["entity_id"] == "org:/nvidia"

    def test_list_with_all_categorical_filters(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=ENTITIES_LIST_RESPONSE)
        result = mock_client.entities.list(
            direction="Rising",
            confidence="Significant",
            stability="Steady",
            scale="Large",
            notability="High",
        )
        assert "data" in result


class TestEntitiesGet:
    def test_get_by_name(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=ENTITY_DETAIL_RESPONSE)
        result = mock_client.entities.get("NVIDIA")
        assert result["display_name"] == "NVIDIA"

    def test_get_by_id(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=ENTITY_DETAIL_RESPONSE)
        result = mock_client.entities.get("org:/nvidia")
        assert result["entity_id"] == "org:/nvidia"
