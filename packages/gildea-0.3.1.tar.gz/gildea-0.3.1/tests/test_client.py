"""Tests for the Gildea client initialization."""

import pytest

from gildea_sdk import Gildea, AuthenticationError


class TestClientInit:
    def test_explicit_api_key(self):
        client = Gildea(api_key="sk-test", base_url="https://test.gildea.ai")
        assert client.api_key == "sk-test"
        client.close()

    def test_api_key_from_env(self, monkeypatch):
        monkeypatch.setenv("GILDEA_API_KEY", "sk-env")
        client = Gildea(base_url="https://test.gildea.ai")
        assert client.api_key == "sk-env"
        client.close()

    def test_missing_api_key_raises(self, monkeypatch):
        monkeypatch.delenv("GILDEA_API_KEY", raising=False)
        with pytest.raises(AuthenticationError, match="No API key"):
            Gildea()

    def test_explicit_key_overrides_env(self, monkeypatch):
        monkeypatch.setenv("GILDEA_API_KEY", "sk-env")
        client = Gildea(api_key="sk-explicit", base_url="https://test.gildea.ai")
        assert client.api_key == "sk-explicit"
        client.close()

    def test_context_manager(self, monkeypatch):
        monkeypatch.setenv("GILDEA_API_KEY", "sk-test")
        with Gildea(base_url="https://test.gildea.ai") as client:
            assert client.api_key == "sk-test"

    def test_resource_namespaces_exist(self, mock_client):
        assert hasattr(mock_client, "signals")
        assert hasattr(mock_client, "entities")
        assert hasattr(mock_client, "themes")
        assert callable(mock_client.search)
