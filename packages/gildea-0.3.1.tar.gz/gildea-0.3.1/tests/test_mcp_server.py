"""Tests for MCP server authentication and error handling."""

from __future__ import annotations

import json
import os
import sys
from unittest.mock import patch

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client


@pytest.fixture(autouse=True)
def _reset_mcp_globals():
    """Reset MCP server module-level state between tests."""
    import gildea_sdk.mcp.server as srv

    srv._http_client = None
    yield
    srv._http_client = None


def _parse_result(result):
    """Extract the JSON data from MCP TextContent result."""
    assert len(result) == 1
    return json.loads(result[0].text)


async def test_missing_api_key_returns_error():
    from gildea_sdk.mcp.server import call_tool

    with patch.dict("os.environ", {}, clear=True):
        result = await call_tool("get_themes", {})
    data = _parse_result(result)
    assert "error" in data
    assert "Authentication failed" in data["error"]


async def test_empty_api_key_returns_error():
    from gildea_sdk.mcp.server import call_tool

    with patch.dict("os.environ", {"GILDEA_API_KEY": ""}):
        result = await call_tool("get_themes", {})
    data = _parse_result(result)
    assert "error" in data
    assert "Authentication failed" in data["error"]


async def test_api_returns_401_auth_error():
    from gildea_sdk.mcp.server import call_tool

    response = httpx.Response(
        401,
        json={"error": {"message": "Invalid API key"}},
        request=httpx.Request("GET", "https://api.gildea.ai/v1/themes"),
    )

    async def mock_get(*args, **kwargs):
        return response

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_invalid"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        result = await call_tool("get_themes", {})
    data = _parse_result(result)
    assert "error" in data
    assert "Authentication failed" in data["error"]


async def test_api_returns_429_rate_limit_error():
    from gildea_sdk.mcp.server import call_tool

    response = httpx.Response(
        429,
        json={"error": {"message": "Rate limit exceeded. Retry after 60s."}},
        request=httpx.Request("GET", "https://api.gildea.ai/v1/themes"),
    )

    async def mock_get(*args, **kwargs):
        return response

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        result = await call_tool("get_themes", {})
    data = _parse_result(result)
    assert "error" in data
    assert "Rate limit exceeded" in data["error"]


async def test_valid_response_returns_data():
    from gildea_sdk.mcp.server import call_tool

    response = httpx.Response(
        200,
        json={"data": [{"label": "Infrastructure"}]},
        request=httpx.Request("GET", "https://api.gildea.ai/v1/themes"),
    )

    async def mock_get(*args, **kwargs):
        return response

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        result = await call_tool("get_themes", {})
    data = _parse_result(result)
    assert "data" in data
    assert data["data"][0]["label"] == "Infrastructure"


async def test_unknown_tool_returns_error():
    """Unknown tool names should return an error, not crash."""
    from gildea_sdk.mcp.server import call_tool

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        result = await call_tool("nonexistent_tool", {})
    data = _parse_result(result)
    assert "error" in data
    assert "Unknown tool" in data["error"]


async def test_search_forwards_similar_to():
    """similar_to param should be forwarded to the REST API."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "similar_to": "unit_abc123"},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool("search_text_units", {"similar_to": "unit_abc123"})

    assert captured_params["similar_to"] == "unit_abc123"
    assert "q" not in captured_params


async def test_search_forwards_recency_boost():
    """recency_boost param should be forwarded to the REST API."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "query": "test"},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool("search_text_units", {"q": "AI chips", "recency_boost": 0.7})

    assert captured_params["recency_boost"] == 0.7


async def test_search_forwards_verification_detail():
    """verification_detail param should be forwarded to the REST API."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "query": "test"},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool(
            "search_text_units", {"q": "AI chips", "verification_detail": "full"}
        )

    assert captured_params["verification_detail"] == "full"


async def test_search_forwards_published_after():
    """published_after param should be forwarded to the REST API."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "query": "test"},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool(
            "search_text_units",
            {"q": "AI chips", "published_after": "2026-01-01"},
        )

    assert captured_params["published_after"] == "2026-01-01"


async def test_search_forwards_published_before():
    """published_before param should be forwarded to the REST API."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "query": "test"},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool(
            "search_text_units",
            {"q": "AI chips", "published_before": "2026-03-01"},
        )

    assert captured_params["published_before"] == "2026-03-01"


async def test_search_forwards_date_range():
    """Both date params should be forwarded together."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "query": "test"},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool(
            "search_text_units",
            {
                "q": "AI chips",
                "published_after": "2026-01-01",
                "published_before": "2026-03-01",
            },
        )

    assert captured_params["published_after"] == "2026-01-01"
    assert captured_params["published_before"] == "2026-03-01"


async def test_list_signals_default_limit_is_25():
    """list_signals should default to limit=25 (matching the REST API)."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "has_more": False},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool("list_signals", {"entity": "NVIDIA"})

    assert captured_params["limit"] == 25


async def test_list_signals_accepts_limit_up_to_50():
    """list_signals should accept limit=50 (matching the REST API max)."""
    from gildea_sdk.mcp.server import call_tool

    captured_params = {}

    async def mock_get(url, *, params=None, **kwargs):
        captured_params.update(params or {})
        return httpx.Response(
            200,
            json={"data": [], "has_more": False},
            request=httpx.Request("GET", f"https://api.gildea.ai{url}"),
        )

    mock_client = httpx.AsyncClient(base_url="https://api.gildea.ai")
    mock_client.get = mock_get

    with (
        patch.dict("os.environ", {"GILDEA_API_KEY": "gld_validkey"}),
        patch("gildea_sdk.mcp.server._ensure_client", return_value=mock_client),
    ):
        await call_tool("list_signals", {"entity": "NVIDIA", "limit": 50})

    assert captured_params["limit"] == 50


async def test_mcp_list_signals_no_filter_e2e():
    """E2E: list_signals without any filter returns recent signals.

    Requires GILDEA_API_KEY and GILDEA_API_BASE_URL pointing to an API
    deployment with the no-filter change (post-deploy verification).
    """
    api_key = os.environ.get("GILDEA_API_KEY")
    if not api_key:
        pytest.skip("GILDEA_API_KEY not set")
    base_url = os.environ.get("GILDEA_API_BASE_URL", "https://api.gildea.ai")

    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": api_key, "GILDEA_API_BASE_URL": base_url},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            result = await session.call_tool(
                "list_signals",
                {"limit": 5},
            )
            data = json.loads(result.content[0].text)
            assert "error" not in data, f"Unexpected error: {data}"
            assert "data" in data
            assert len(data["data"]) > 0, "Expected recent signals with no filter"


async def test_mcp_search_recency_boost_e2e():
    """E2E: search_text_units with recency_boost via MCP stdio returns results."""
    api_key = os.environ.get("GILDEA_API_KEY")
    if not api_key:
        pytest.skip("GILDEA_API_KEY not set")

    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": api_key},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            result = await session.call_tool(
                "search_text_units",
                {"q": "AI chips", "recency_boost": 0.5, "limit": 3},
            )
            data = json.loads(result.content[0].text)
            assert "error" not in data, f"Unexpected error: {data}"
            assert "data" in data
            assert isinstance(data["data"], list)


async def test_mcp_search_verification_detail_e2e():
    """E2E: search_text_units with verification_detail=full via MCP stdio."""
    api_key = os.environ.get("GILDEA_API_KEY")
    if not api_key:
        pytest.skip("GILDEA_API_KEY not set")

    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": api_key},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            result = await session.call_tool(
                "search_text_units",
                {"q": "AI chips", "verification_detail": "full", "limit": 3},
            )
            data = json.loads(result.content[0].text)
            assert "error" not in data, f"Unexpected error: {data}"
            assert "data" in data
            # verification_detail=full should include scoring metadata
            if data["data"]:
                unit = data["data"][0]
                assert "verification" in unit, (
                    "Expected verification metadata with detail=full"
                )


async def test_mcp_search_similar_to_e2e():
    """E2E: search_text_units with similar_to via MCP stdio."""
    api_key = os.environ.get("GILDEA_API_KEY")
    if not api_key:
        pytest.skip("GILDEA_API_KEY not set")

    # First, get a real unit ID from a search
    base_url = os.environ.get("GILDEA_API_BASE_URL", "https://api.gildea.ai")
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": api_key, "GILDEA_API_BASE_URL": base_url},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            # Get a unit ID from a regular search
            search_result = await session.call_tool(
                "search_text_units",
                {"q": "AI", "limit": 1},
            )
            search_data = json.loads(search_result.content[0].text)
            if not search_data.get("data"):
                pytest.skip("No search results to test similar_to with")
            unit_id = search_data["data"][0]["unit"]["unit_id"]

            # Now use similar_to with that unit ID
            result = await session.call_tool(
                "search_text_units",
                {"similar_to": unit_id, "limit": 3},
            )
            data = json.loads(result.content[0].text)
            assert "error" not in data, f"Unexpected error: {data}"
            assert "data" in data
            assert data.get("similar_to") == unit_id


async def test_mcp_list_signals_limit_50_e2e():
    """E2E: list_signals with limit=50 via MCP stdio returns up to 50 results."""
    api_key = os.environ.get("GILDEA_API_KEY")
    if not api_key:
        pytest.skip("GILDEA_API_KEY not set")

    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": api_key},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            result = await session.call_tool(
                "list_signals",
                {"q": "AI", "limit": 50},
            )
            data = json.loads(result.content[0].text)
            assert "error" not in data, f"Unexpected error: {data}"
            assert "data" in data
            # Should be able to return more than the old cap of 25
            assert len(data["data"]) > 0


EXPECTED_TOOLS = {
    "search_text_units",
    "list_signals",
    "get_signal_detail",
    "get_entity_profile",
    "list_entities",
    "get_themes",
    "get_theme_detail",
}


async def test_stdio_initialize_and_list_tools():
    """End-to-end: spawn MCP server subprocess, initialize, and list tools."""
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": "test_e2e"},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            result = await session.initialize()
            assert result.serverInfo.name == "gildea"

            tools_result = await session.list_tools()
            tool_names = {t.name for t in tools_result.tools}
            assert tool_names == EXPECTED_TOOLS


async def test_stdio_call_tool_without_api_returns_error():
    """End-to-end: calling a tool with a dummy key returns an auth/connection error."""
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "gildea_sdk.mcp"],
        env={"GILDEA_API_KEY": "gld_fake_key"},
    )
    async with stdio_client(params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()
            result = await session.call_tool("get_themes", {})
            assert len(result.content) == 1
            data = json.loads(result.content[0].text)
            assert "error" in data
