"""Tests for the themes resource."""

THEMES_LIST_RESPONSE = {
    "data": [
        {
            "axis": "value_chain",
            "label": "Foundation Models",
            "signal_count": 42,
            "direction": "Rising",
        }
    ],
}

THEME_DETAIL_RESPONSE = {
    "axis": "value_chain",
    "label": "Foundation Models",
    "signal_count": 42,
    "related_themes": [],
}


class TestThemesList:
    def test_list_all_themes(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=THEMES_LIST_RESPONSE)
        result = mock_client.themes.list()
        assert result["data"][0]["label"] == "Foundation Models"

    def test_list_by_axis(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=THEMES_LIST_RESPONSE)
        result = mock_client.themes.list(axis="value_chain")
        assert result["data"][0]["axis"] == "value_chain"


class TestThemesGet:
    def test_get_theme(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=THEME_DETAIL_RESPONSE)
        result = mock_client.themes.get("value_chain", "Foundation Models")
        assert result["label"] == "Foundation Models"
