"""Tests for the signals resource."""

import httpx


SIGNALS_LIST_RESPONSE = {
    "data": [
        {
            "signal_id": "0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7",
            "title": "NVIDIA ships H200",
            "content_type": "analysis",
        }
    ],
    "has_more": False,
}

SIGNAL_DETAIL_RESPONSE = {
    "signal_id": "0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7",
    "title": "NVIDIA ships H200",
    "content_type": "analysis",
    "decomposition": {"thesis": {"text": "Core thesis"}},
}


class TestSignalsList:
    def test_list_signals(self, mock_client, httpx_mock):
        httpx_mock.add_response(
            url=httpx.URL(
                "https://test.gildea.ai/v1/signals",
                params={"entity": "NVIDIA", "limit": "5"},
            ),
            json=SIGNALS_LIST_RESPONSE,
        )
        result = mock_client.signals.list(entity="NVIDIA", limit=5)
        assert (
            result["data"][0]["signal_id"] == "0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7"
        )

    def test_list_with_all_filters(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SIGNALS_LIST_RESPONSE)
        result = mock_client.signals.list(
            entity="NVIDIA",
            theme="Foundation Models",
            q="GPU",
            content_type="analysis",
            published_after="2024-01-01",
            published_before="2024-12-31",
            limit=10,
        )
        assert len(result["data"]) == 1


class TestSignalsGet:
    def test_get_signal(self, mock_client, httpx_mock):
        httpx_mock.add_response(
            url="https://test.gildea.ai/v1/signals/0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7",
            json=SIGNAL_DETAIL_RESPONSE,
        )
        result = mock_client.signals.get("0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7")
        assert result["signal_id"] == "0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7"

    def test_get_with_include_evidence(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=SIGNAL_DETAIL_RESPONSE)
        result = mock_client.signals.get(
            "0001f3a7b9c8d4e5f6a7b8c9d0e1f2a3b4c5d6e7",
            include="evidence",
            verification_detail="full",
        )
        assert result["decomposition"]["thesis"]["text"] == "Core thesis"
