"""Tests for the embed endpoint."""

EMBED_RESPONSE = {
    "embedding": [0.1] * 768,
    "embedding_model": "BAAI/bge-base-en-v1.5",
    "dimensions": 768,
}


class TestEmbed:
    def test_embed_returns_vector(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=EMBED_RESPONSE)
        result = mock_client.embed("hello world")
        assert len(result["embedding"]) == 768
        assert result["embedding_model"] == "BAAI/bge-base-en-v1.5"
        assert result["dimensions"] == 768

    def test_embed_sends_text_in_json_body(self, mock_client, httpx_mock):
        httpx_mock.add_response(json=EMBED_RESPONSE)
        mock_client.embed("test text")
        req = httpx_mock.get_request()
        assert req.method == "POST"
        assert req.url.path == "/v1/embed"
        import json as _json

        assert _json.loads(req.content) == {"text": "test text"}


class TestSignalsIncludeEmbeddings:
    def test_signals_get_with_include_embeddings(self, mock_client, httpx_mock):
        signal_response = {
            "signal_id": "sig_test",
            "title": "Test",
            "decomposition": {},
        }
        httpx_mock.add_response(json=signal_response)
        mock_client.signals.get("sig_test", include="embeddings")
        req = httpx_mock.get_request()
        assert "include=embeddings" in str(req.url)
