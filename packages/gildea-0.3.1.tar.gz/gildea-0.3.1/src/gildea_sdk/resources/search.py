"""Search resource."""

from __future__ import annotations

from ..pagination import _clean, _request


class SearchResource:
    def __init__(self, client):
        self._client = client

    def query(
        self,
        q=None,
        *,
        similar_to=None,
        unit_type=None,
        entity=None,
        theme=None,
        published_after=None,
        published_before=None,
        recency_boost=None,
        diversity_cap=None,
        verification_detail=None,
        limit=10,
    ):
        if not q and not similar_to:
            raise ValueError("Exactly one of q or similar_to is required")
        if q and similar_to:
            raise ValueError("Exactly one of q or similar_to is required")
        params = _clean(
            {
                "q": q,
                "similar_to": similar_to,
                "unit_type": unit_type,
                "entity": entity,
                "theme": theme,
                "published_after": published_after,
                "published_before": published_before,
                "recency_boost": recency_boost,
                "diversity_cap": diversity_cap,
                "verification_detail": verification_detail,
                "limit": limit,
            }
        )
        return _request(self._client, "GET", "/v1/search", params=params)
