"""Tests for vision module."""
