"""Search module for Carta."""
