# Tribulnation Btcturk SDK

> An SDK to connect Btcturk with the Tribulnation ecosystem.

🚧 Under construction.