"""
### Tribulnation Btcturk
> An SDK to connect Btcturk with the Tribulnation ecosystem.

- Details
"""