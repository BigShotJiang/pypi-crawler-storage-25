from .evidence import AssembledEvidence, FileEvidenceCard, EvidenceAssembler
from .generation import (
    PageGenerator,
    GenerationResult,
    GenerationSummary,
    summarize_generation_results,
    BucketGenerationEngine,
)
from .validation import ValidationResult, PageValidator
from .post_processors import (
    _fix_mermaid_diagram,
    build_internal_doc_link_maps,
    escape_mdx_route_params,
    escape_mdx_text_hazards,
    fix_file_references,
    fix_mermaid_diagrams,
    normalize_code_fence_languages,
    normalize_explanatory_lines_outside_fences,
    normalize_html_code_blocks,
    normalize_mdx_steps,
    repair_internal_doc_links,
    repair_mdx_component_blocks,
    repair_dangling_plain_fences,
    repair_unbalanced_code_fences,
)
