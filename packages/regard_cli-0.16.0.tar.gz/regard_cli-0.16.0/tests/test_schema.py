"""Schema introspection tests — verify CLI command tree introspection."""

import json

from regard.main import app, generate_schema


def test_schema_structure():
    """Schema has expected top-level keys."""
    s = generate_schema(app)
    assert "version" in s
    assert "total_commands" in s
    assert "commands" in s
    assert isinstance(s["commands"], list)


def test_schema_command_shape():
    """Each command has name, description, class, params."""
    for cmd in generate_schema(app)["commands"]:
        assert "name" in cmd
        assert "description" in cmd
        assert "class" in cmd
        assert "params" in cmd
        assert cmd["class"] in ("agent-safe", "mutating", "human-only", "meta")


def test_schema_dot_notation():
    """Command names use dot notation."""
    names = [c["name"] for c in generate_schema(app)["commands"]]
    assert "hl.order" in names
    assert "hl.status" in names
    assert "poly.markets" in names


def test_schema_includes_hl_commands():
    """Known HL commands appear."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("hl.status", "hl.order", "hl.preflight", "hl.positions", "hl.stop"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_poly_commands():
    """Known poly commands appear."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("poly.status", "poly.order", "poly.markets"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_session_commands():
    """Session commands appear."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("session.gm", "session.gg", "session.cope", "session.pnl"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_includes_invoke_without_command():
    """Directly invocable groups (killswitch, selfup, port) appear as commands."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for cmd in ("killswitch", "selfup", "port"):
        assert cmd in names, f"Missing: {cmd}"


def test_schema_excludes_structural_groups():
    """Structural groups (hl, poly, auth, session) are not commands."""
    names = {c["name"] for c in generate_schema(app)["commands"]}
    for group in ("hl", "poly", "auth", "session"):
        assert group not in names, f"Structural group should be excluded: {group}"


def test_schema_params_structure():
    """Command params have type and required fields."""
    cmds = {c["name"]: c for c in generate_schema(app)["commands"]}
    order = cmds["hl.order"]
    assert isinstance(order["params"], dict)
    for name, info in order["params"].items():
        assert "type" in info
        assert "required" in info


def test_schema_param_types():
    """Param types are JSON Schema types, not Click types."""
    cmds = {c["name"]: c for c in generate_schema(app)["commands"]}
    order = cmds["hl.order"]
    valid_types = {"string", "integer", "number", "boolean"}
    for name, info in order["params"].items():
        assert info["type"] in valid_types, f"Param {name} has non-schema type: {info['type']}"


def test_schema_command_classes():
    """Mutating and human-only commands are correctly classified."""
    cmds = {c["name"]: c for c in generate_schema(app)["commands"]}
    assert cmds["hl.order"]["class"] == "mutating"
    assert cmds["hl.transfer"]["class"] == "mutating"
    assert cmds["poly.approve"]["class"] == "mutating"
    assert cmds["killswitch"]["class"] == "human-only"
    assert cmds["auth.hl"]["class"] == "human-only"
    assert cmds["hl.status"]["class"] == "agent-safe"
    assert cmds["hl.positions"]["class"] == "agent-safe"


def test_schema_no_unclassified_commands():
    """Every command has a valid class — no orphans."""
    for cmd in generate_schema(app)["commands"]:
        assert cmd["class"] in ("agent-safe", "mutating", "human-only", "meta"), \
            f"{cmd['name']} has invalid class: {cmd['class']}"


def test_schema_total_count():
    """Total commands is reasonable."""
    s = generate_schema(app)
    assert s["total_commands"] >= 40, f"Only {s['total_commands']} commands"


def test_schema_cli_all_commands():
    """The schema CLI command (no arg) produces valid JSON envelope with all commands."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["schema"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    assert data["data"]["total_commands"] >= 40


def test_schema_cli_single_command():
    """The schema CLI command with an arg returns a single command."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["schema", "hl.order"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    assert data["data"]["name"] == "hl.order"
    assert data["data"]["class"] == "mutating"
    assert "params" in data["data"]


def test_schema_cli_unknown_command():
    """The schema CLI command with unknown arg returns structured error."""
    from typer.testing import CliRunner
    runner = CliRunner()
    result = runner.invoke(app, ["schema", "nonexistent.command"])
    assert result.exit_code != 0
    data = json.loads(result.output)
    assert data["ok"] is False
    assert data["error"]["code"] == "UNKNOWN_COMMAND"
