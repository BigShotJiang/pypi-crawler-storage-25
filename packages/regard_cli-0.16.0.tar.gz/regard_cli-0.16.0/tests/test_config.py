"""Tests for regard config command."""

import json

from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


def test_config_show_default():
    """config show returns default polygon_rpc when no override set."""
    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["ok"] is True
    rpc = data["data"]["polygon_rpc"]
    assert rpc["current"] == "https://rpc.regard.computer/regard/evm/137"
    assert rpc["source"] == "default"
    assert rpc["default"] == rpc["current"]


def test_config_show_custom(tmp_path, monkeypatch):
    """config show reflects POLYGON_RPC from settings file."""
    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {"POLYGON_RPC": "https://custom-rpc.example.com"}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    rpc = data["data"]["polygon_rpc"]
    assert rpc["current"] == "https://custom-rpc.example.com"
    assert rpc["source"] == "settings"
    assert rpc["default"] == "https://rpc.regard.computer/regard/evm/137"
