"""Auth setup — secure credential onboarding via real terminal (getpass)."""

import getpass
import json
import os
import sys
from pathlib import Path
from typing import Annotated

import typer

auth_app = typer.Typer(
    name="auth",
    no_args_is_help=True,
    help="Credential setup for trading venues.",
)


def _find_settings_path() -> Path:
    """Global Claude Code settings — works across all projects."""
    return Path.home() / ".claude" / "settings.local.json"


def _save_env_var(key: str, value: str, settings_path: Path):
    """Merge an env var into settings.local.json."""
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    settings = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    settings.setdefault("env", {})[key] = value
    settings_path.write_text(json.dumps(settings, indent=2) + "\n")


def _validate_hex_key(key: str) -> str:
    """Validate and normalize a hex private key."""
    key = key.strip()
    if key.startswith("0x"):
        key = key[2:]
    if len(key) != 64:
        return ""
    try:
        int(key, 16)
    except ValueError:
        return ""
    return "0x" + key


@auth_app.command()
def hl(
    key: Annotated[str | None, typer.Argument(help="Private key (or omit to enter interactively)")] = None,
):
    """Set up Hyperliquid trading credentials.

    Run this in a regular terminal (not inside Claude Code).
    Your key is saved to ~/.claude/settings.local.json (global)
    and never appears in any conversation transcript.
    """
    if not key:
        if not sys.stdin.isatty():
            print("Error: this command requires an interactive terminal.", file=sys.stderr)
            print("Run it in a regular terminal, not inside Claude Code.", file=sys.stderr)
            raise SystemExit(1)

        print()
        print("  Regard — Hyperliquid credential setup")
        print()
        print("  Paste the master wallet private key for this trading instance.")
        print("  The key signs trades and manages funds on this account.")
        print()

        key = getpass.getpass("  Paste your key (input is hidden): ")

    normalized = _validate_hex_key(key)
    if not normalized:
        print()
        print("  Invalid key. Expected 0x + 64 hex characters.", file=sys.stderr)
        raise SystemExit(1)

    try:
        import eth_account
        address = eth_account.Account.from_key(normalized).address
        print()
        print(f"  Hyperliquid address: {address}")
    except Exception:
        print()
        print("  Could not derive address. Saving key anyway.")

    settings_path = _find_settings_path()
    _save_env_var("HYPERLIQUID_PRIVATE_KEY", normalized, settings_path)

    # Clean up any legacy HYPERLIQUID_AGENT_KEY entry from older installs
    try:
        settings = json.loads(settings_path.read_text())
        if "HYPERLIQUID_AGENT_KEY" in settings.get("env", {}):
            del settings["env"]["HYPERLIQUID_AGENT_KEY"]
            settings_path.write_text(json.dumps(settings, indent=2) + "\n")
    except Exception:
        pass

    print()
    print(f"  Saved to {settings_path}")
    print()
    print("  Return to Claude Code — your key is ready.")
    print("  If Claude Code was already running, the key is")
    print("  picked up automatically on the next command.")
    print()


@auth_app.command()
def poly(
    key: Annotated[str | None, typer.Argument(help="Private key (or omit to enter interactively)")] = None,
):
    """Set up Polymarket trading credentials.

    Run this in a regular terminal (not inside Claude Code).
    Uses the same Polygon wallet key for CLOB API auth.
    CLOB credentials are derived at runtime — no separate API key needed.
    """
    if not key:
        if not sys.stdin.isatty():
            print("Error: this command requires an interactive terminal.", file=sys.stderr)
            print("Run it in a regular terminal, not inside Claude Code.", file=sys.stderr)
            raise SystemExit(1)

        print()
        print("  Regard — Polymarket credential setup")
        print()
        print("  Enter your Polygon wallet private key.")
        print("  This is the same key used for Hyperliquid if you share the wallet.")
        print()
        print("  CLOB API credentials are derived automatically from this key.")
        print("  No separate Polymarket API key is needed.")
        print()
        print("  Note: Polymarket trading is geo-restricted.")
        print("  You need a Dublin VPN for order placement.")
        print()

        key = getpass.getpass("  Paste your key (input is hidden): ")

    normalized = _validate_hex_key(key)
    if not normalized:
        print()
        print("  Invalid key. Expected 0x + 64 hex characters.", file=sys.stderr)
        raise SystemExit(1)

    try:
        import eth_account
        address = eth_account.Account.from_key(normalized).address
        print()
        print(f"  Polygon address: {address}")
    except Exception:
        print()
        print("  Could not derive address. Saving key anyway.")

    settings_path = _find_settings_path()
    _save_env_var("POLYMARKET_PRIVATE_KEY", normalized, settings_path)

    print()
    print(f"  Saved to {settings_path}")
    print()
    print("  Return to Claude Code — your key is ready.")
    print()
    print("  Note: Polymarket trading is geo-restricted.")
    print("  Order placement requires a non-US/non-SG IP (e.g. Ireland).")
    print()


@auth_app.command()
def check():
    """Check which venues have credentials configured."""
    result: dict = {"venues": {}}

    # Fallback: read from settings file if env vars missing
    from regard.venues.hyperliquid.client import _load_settings_env
    settings_env = _load_settings_env()

    # Hyperliquid
    hl_key = os.environ.get("HYPERLIQUID_PRIVATE_KEY") or settings_env.get("HYPERLIQUID_PRIVATE_KEY")

    if hl_key:
        try:
            import eth_account
            address = eth_account.Account.from_key(hl_key).address
            result["venues"]["hyperliquid"] = {
                "configured": True,
                "address": address,
            }
        except Exception:
            result["venues"]["hyperliquid"] = {"configured": True}
    else:
        result["venues"]["hyperliquid"] = {
            "configured": False,
            "setup_command": "regard auth hl",
        }

    # Polymarket
    poly_key = os.environ.get("POLYMARKET_PRIVATE_KEY") or settings_env.get("POLYMARKET_PRIVATE_KEY")
    if poly_key:
        try:
            import eth_account
            address = eth_account.Account.from_key(poly_key).address
            result["venues"]["polymarket"] = {
                "configured": True, "address": address,
            }
        except Exception:
            result["venues"]["polymarket"] = {"configured": True}
    else:
        result["venues"]["polymarket"] = {
            "configured": False,
            "setup_command": "regard auth poly",
        }

    from regard.core.output import output as _output
    _output(result, None)
