"""Transfer safety — amount caps, cooldown, risk classification.

All enforcement happens at the CLI level. Not in hooks, not in LLM config.
"""

import calendar
import json
import sys
import time
from pathlib import Path

from regard.core.output import die

_LOG_FILE = Path.home() / ".regard" / "send_log.jsonl"


def classify_risk(amount: float, balance: float) -> str:
    """Classify send risk based on amount as percentage of balance.

    Returns: "STANDARD", "HIGH", or "CRITICAL"
    """
    if balance <= 0:
        return "CRITICAL"
    pct = amount / balance
    if pct > 0.9:
        return "CRITICAL"
    if pct > 0.5:
        return "HIGH"
    return "STANDARD"


def check_amount_cap(amount: float, token: str, settings_env: dict) -> None:
    """Die if amount exceeds configured per-operation cap."""
    cap_key = "SEND_MAX_AMOUNT"
    cap_str = settings_env.get(cap_key)
    if cap_str is None:
        return
    try:
        cap = float(cap_str)
    except (ValueError, TypeError):
        return
    if amount > cap:
        die(
            "validation_error", "AMOUNT_CAP_EXCEEDED",
            f"Send amount {amount} {token} exceeds configured cap of {cap}",
            hint=f"Adjust {cap_key} in settings or reduce the amount",
        )


def check_daily_cap(amount: float, token: str, venue: str, settings_env: dict) -> None:
    """Die if today's total + this send exceeds daily cap."""
    cap_str = settings_env.get("SEND_DAILY_MAX")
    if cap_str is None:
        return
    try:
        cap = float(cap_str)
    except (ValueError, TypeError):
        return

    today_total = _sum_today_sends(venue)
    if today_total + amount > cap:
        die(
            "validation_error", "DAILY_CAP_EXCEEDED",
            f"This send ({amount} {token}) would bring today's total to {today_total + amount}, "
            f"exceeding the daily cap of {cap}",
            hint="Adjust SEND_DAILY_MAX in settings or wait until tomorrow",
        )


def check_cooldown(dest_address: str, settings_env: dict) -> None:
    """Die if a send to this address was made too recently."""
    cooldown_str = settings_env.get("SEND_COOLDOWN", "30")
    try:
        cooldown = int(cooldown_str)
    except (ValueError, TypeError):
        cooldown = 30

    if cooldown <= 0:
        return

    last_send_ts = _last_send_to(dest_address)
    if last_send_ts is None:
        return

    elapsed = time.time() - last_send_ts
    if elapsed < cooldown:
        remaining = int(cooldown - elapsed)
        die(
            "validation_error", "COOLDOWN_ACTIVE",
            f"Must wait {remaining}s before sending to this address again",
            hint=f"Cooldown is {cooldown}s (SEND_COOLDOWN). Last send was {int(elapsed)}s ago.",
        )


def _sum_today_sends(venue: str) -> float:
    """Sum all executed send amounts for today (UTC) from audit log."""
    today = time.strftime("%Y-%m-%d", time.gmtime())
    total = 0.0
    if not _LOG_FILE.exists():
        return total
    try:
        for line in _LOG_FILE.read_text().splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if (
                record.get("event") == "executed"
                and record.get("command") == "send"
                and record.get("venue") == venue
                and record.get("ts", "").startswith(today)
            ):
                total += float(record.get("amount", 0))
    except Exception:
        pass
    return total


def _last_send_to(dest_address: str) -> float | None:
    """Find the timestamp of the most recent executed send to this address."""
    if not _LOG_FILE.exists():
        return None
    dest_lower = dest_address.lower()
    last_ts = None
    try:
        for line in _LOG_FILE.read_text().splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                print(f"WARNING: corrupt audit log entry, skipping: {line[:80]}", file=sys.stderr)
                continue
            if (
                record.get("event") == "executed"
                and record.get("command") == "send"
                and record.get("to", "").lower() == dest_lower
            ):
                ts_str = record.get("ts", "")
                try:
                    ts = calendar.timegm(time.strptime(ts_str, "%Y-%m-%dT%H:%M:%SZ"))
                    if last_ts is None or ts > last_ts:
                        last_ts = ts
                except ValueError:
                    print(f"WARNING: unparseable timestamp in audit log: {ts_str}", file=sys.stderr)
    except Exception:
        pass
    return last_ts
