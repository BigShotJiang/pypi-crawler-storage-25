"""Append-only audit log for transfer-related events.

Logs to ~/.regard/send_log.jsonl. Every address book mutation and send
command event (proposed, approved, executed, rejected, failed) is recorded.
"""

import json
import time
from pathlib import Path

_LOG_DIR = Path.home() / ".regard"
_LOG_FILE = _LOG_DIR / "send_log.jsonl"


def log_event(event: str, **fields) -> None:
    """Append a single audit event.

    Args:
        event: event type (e.g. "proposed", "approved", "executed", "rejected", "failed")
        **fields: arbitrary key-value pairs (command, venue, from, to, amount, etc.)
    """
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    record = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "event": event}
    record.update(fields)
    with open(_LOG_FILE, "a") as f:
        f.write(json.dumps(record, separators=(",", ":")) + "\n")
