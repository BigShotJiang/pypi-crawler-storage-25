"""Select all objects of a given Maya type."""

# Import future modules
from __future__ import annotations

# Import local modules
from dcc_mcp_core.skill import skill_entry, skill_error, skill_exception, skill_success

# Import built-in modules


def select_by_type(object_type: str) -> dict:
    """Select all objects of a given Maya type.

    Args:
        object_type: Maya node type string (e.g. ``"mesh"``, ``"transform"``,
            ``"joint"``, ``"camera"``).

    Returns:
        ActionResultModel dict with ``context.selection`` and ``context.count``.
    """

    try:
        import maya.cmds as cmds  # noqa: PLC0415

        objects = cmds.ls(type=object_type) or []
        if objects:
            cmds.select(objects, replace=True)
        else:
            cmds.select(clear=True)

        return skill_success(
            "Selected {} '{}' object(s)".format(len(objects), object_type),
            object_type=object_type,
            selection=objects,
            count=len(objects),
            prompt="Check the result with list_scene or use related actions to continue.",
        )
    except ImportError:
        return skill_error("Maya not available", "maya.cmds could not be imported")
    except Exception as exc:
        return skill_exception(exc, message="Failed to select by type '{}'".format(object_type))


@skill_entry
def main(**kwargs) -> dict:
    """Entry point; delegates to :func:`select_by_type`."""
    return select_by_type(**kwargs)


if __name__ == "__main__":
    from dcc_mcp_core.skill import run_main

    run_main(main)
