# Execution Constraint Engine (ECE)

Runtime decision layer for enforcing cost constraints in multi-step LLM workflows.  

ECE evaluates projected cost before each step and returns a BLOCK decision when execution would exceed a defined budget.

---

## Install

```bash
pip install veloryn
```

---


### Minimal usage

```python
from veloryn import execute

def run_task():
    return {
        "output": "model response",
        "usage": {
            "input_tokens": 120,
            "output_tokens": 300,
        },
    }

execute(
    task_id="demo",
    run_task=run_task,
    input_data="Analyze input",
    model="gpt-4o",
    max_cost=0.05,
)
```

`run_task` must return `usage` (input/output tokens).  
 ECE does not infer cost automatically.

---

Full documentation and examples:  
https://github.com/veloryn-intel/execution-constraint-engine
