import dataclasses

from scaler.config.common.logging import LoggingConfig
from scaler.config.config_class import ConfigClass
from scaler.config.types.object_storage_server import ObjectStorageAddressConfig


@dataclasses.dataclass
class ObjectStorageServerConfig(ConfigClass):
    bind_address: ObjectStorageAddressConfig = dataclasses.field(
        metadata=dict(
            positional=True, help="specify the object storage server address to listen to, e.g. tcp://localhost:2345."
        )
    )
    logging_config: LoggingConfig = dataclasses.field(default_factory=LoggingConfig)
