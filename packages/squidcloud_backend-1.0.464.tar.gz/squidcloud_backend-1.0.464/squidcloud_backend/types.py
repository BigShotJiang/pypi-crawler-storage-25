"""Type definitions for the Squid Python backend SDK.

Mirrors the TypeScript types from:
- internal-common/src/public-types-backend/bundle-api.public-types.ts
- internal-common/src/public-types-backend/bundle-data.public-types.ts
- internal-common/src/public-types/context.public-types.ts
- internal-common/src/public-types-backend/application.public-types.ts
- internal-common/src/public-types/ai-function.public-types.ts
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Literal, TypedDict

# ---------------------------------------------------------------------------
# Primitive aliases (matching TS string-branded types)
# ---------------------------------------------------------------------------

AppId = str
ClientId = str
IntegrationId = str
CollectionName = str
TopicName = str
ServiceFunctionName = str
"""Format: 'ClassName:method_name'"""
ServiceName = str
FunctionName = str
TriggerId = str
SchedulerId = str
WebhookId = str
AiFunctionId = str
AiFunctionsConfiguratorId = str
ApiEndpointId = str
SecretKey = str
SecretValue = Any
EnvironmentId = str
SquidDeveloperId = str
TenantModuleId = str
UserAiChatModelName = str
IntegrationType = str
SquidRegion = str
JSONSchema = dict[str, Any]

# Default integration IDs matching the TS SDK constants
BUILT_IN_DB_INTEGRATION_ID = "built_in_db"
BUILT_IN_STORAGE_INTEGRATION_ID = "built_in_storage"
BUILT_IN_QUEUE_INTEGRATION_ID = "built_in_queue"
AI_AGENTS_INTEGRATION_ID = "ai_agents"

# ---------------------------------------------------------------------------
# Action type literals
# ---------------------------------------------------------------------------

DatabaseActionType = Literal["read", "write", "update", "insert", "delete", "all"]
StorageActionType = Literal["read", "write", "update", "insert", "delete", "all"]
TopicActionType = Literal["read", "write", "all"]
MetricActionType = Literal["write", "all"]
MutationType = Literal["insert", "update", "delete"]
LimiterScope = Literal["ip", "user", "global"]
QuotaRenewPeriod = Literal["hourly", "daily", "weekly", "monthly", "quarterly", "annually"]
AuthType = Literal["Bearer", "ApiKey"]
ClientConnectionState = Literal["connected", "disconnected"]
AiFunctionParamType = Literal["string", "number", "boolean", "date", "files"]


# ---------------------------------------------------------------------------
# Auth types
# ---------------------------------------------------------------------------


class AuthWithBearer(TypedDict, total=False):
    type: Literal["Bearer"]
    userId: str
    expiration: int
    attributes: dict[str, Any]
    jwt: str


class AuthWithApiKey(TypedDict):
    type: Literal["ApiKey"]
    apiKey: str


Auth = AuthWithBearer | AuthWithApiKey


def auth_from_dict(data: dict | None) -> Auth | None:
    """Deserialize an auth dict from JSON."""
    if data is None:
        return None
    if data.get("type") == "Bearer":
        result = AuthWithBearer(
            type="Bearer",
            userId=data.get("userId", ""),
            expiration=data.get("expiration", 0),
            attributes=data.get("attributes", {}),
        )
        if "jwt" in data:
            result["jwt"] = data["jwt"]
        return result
    if data.get("type") == "ApiKey":
        return AuthWithApiKey(type="ApiKey", apiKey=data.get("apiKey", ""))
    return None


# ---------------------------------------------------------------------------
# Request context types
# ---------------------------------------------------------------------------


class RawRequest(TypedDict, total=False):
    method: str
    path: str
    queryParams: dict[str, str]
    rawBody: str
    headers: dict[str, str]


class OpenApiContext(TypedDict):
    request: RawRequest


class RunContext(TypedDict, total=False):
    appId: AppId
    clientId: ClientId
    sourceIp: str
    headers: dict[str, Any]
    openApiContext: OpenApiContext


@dataclass
class ServiceRequestConfig:
    """Per-request configuration stored in context var."""

    auth: Auth | None = None
    context: RunContext = field(default_factory=lambda: RunContext(appId=""))


# ---------------------------------------------------------------------------
# Webhook / Trigger request types
# ---------------------------------------------------------------------------


class SquidFile(TypedDict, total=False):
    """A file uploaded via webhook or executable."""

    data: bytes
    fieldName: str
    mimetype: str
    originalName: str
    size: int
    encoding: str
    __isSquidFile__: bool


HttpMethod = Literal["post", "get", "put", "delete", "patch", "options", "head"]


class WebhookRequest(TypedDict, total=False):
    """Request object received by @webhook handlers."""

    body: Any
    rawBody: str
    queryParams: dict[str, str]
    headers: dict[str, str]
    httpMethod: HttpMethod
    files: list[SquidFile]


class WebhookResponse(TypedDict, total=False):
    """Response object returned from webhook handlers."""

    body: Any
    statusCode: int
    headers: dict[str, Any]
    __isWebhookResponse__: bool


class OpenApiResponse(TypedDict, total=False):
    """Response object returned from OpenAPI handlers."""

    body: Any
    statusCode: int
    headers: dict[str, Any]
    __isOpenApiResponse__: bool


class TriggerRequest(TypedDict, total=False):
    """Request object received by @trigger handlers."""

    squidDocId: str
    integrationId: IntegrationId
    collectionName: CollectionName
    docId: Any
    mutationType: MutationType
    docBefore: Any
    docAfter: Any


class QueueMessageRequest(TypedDict, total=False):
    """Request object received by @queue_message handlers."""

    integrationId: IntegrationId
    topicName: str
    message: Any


# ---------------------------------------------------------------------------
# AI function types
# ---------------------------------------------------------------------------


class AiFunctionParam(TypedDict, total=False):
    """Parameter definition for an AI function."""

    name: str
    description: str
    type: AiFunctionParamType
    required: bool
    enum: list[str]


class AiFunctionAttributes(TypedDict, total=False):
    """Attributes for an AI function."""

    integrationType: list[IntegrationType]


# ---------------------------------------------------------------------------
# Rate / quota limiting
# ---------------------------------------------------------------------------


class RateLimitOptions(TypedDict, total=False):
    """Rate limit options (queries per second)."""

    value: int
    scope: LimiterScope


class QuotaLimitOptions(TypedDict, total=False):
    """Quota limit options (total executions per period)."""

    value: int
    scope: LimiterScope
    renewPeriod: QuotaRenewPeriod


class LimiterOptions(TypedDict, total=False):
    """Normalized limiter options (list form)."""

    rateLimit: list[RateLimitOptions]
    quotaLimit: list[QuotaLimitOptions]


LimiterConfigValue = int | RateLimitOptions | list[RateLimitOptions]
QuotaConfigValue = int | QuotaLimitOptions | list[QuotaLimitOptions]


class LimiterConfig(TypedDict, total=False):
    """Developer-friendly limiter config. Accepts int, single options, or list."""

    rateLimit: LimiterConfigValue
    quotaLimit: QuotaConfigValue


def limiter_config_to_options(config: LimiterConfig) -> LimiterOptions:
    """Normalize a LimiterConfig to LimiterOptions (list form).

    Mirrors limiterConfigToOptions() from actions.ts.
    """
    result: LimiterOptions = {}

    rl = config.get("rateLimit")
    if rl is not None:
        if isinstance(rl, int):
            result["rateLimit"] = [RateLimitOptions(value=rl, scope="global")]
        elif isinstance(rl, dict):
            rl.setdefault("scope", "global")
            result["rateLimit"] = [rl]
        elif isinstance(rl, list):
            for r in rl:
                r.setdefault("scope", "global")
            result["rateLimit"] = rl

    ql = config.get("quotaLimit")
    if ql is not None:
        if isinstance(ql, int):
            result["quotaLimit"] = [
                QuotaLimitOptions(value=ql, scope="global", renewPeriod="monthly")
            ]
        elif isinstance(ql, dict):
            ql.setdefault("scope", "global")
            ql.setdefault("renewPeriod", "monthly")
            result["quotaLimit"] = [ql]
        elif isinstance(ql, list):
            for q in ql:
                q.setdefault("scope", "global")
                q.setdefault("renewPeriod", "monthly")
            result["quotaLimit"] = ql

    return result


# ---------------------------------------------------------------------------
# LLM / MCP types
# ---------------------------------------------------------------------------


class UserAiChatOptions(TypedDict, total=False):
    """Options passed to LLM ask handlers."""

    model: str
    maxTokens: int
    maxOutputTokens: int
    temperature: float
    instructions: str
    responseFormat: Any
    memoryOptions: dict[str, Any]
    functions: list[str]
    agentContext: dict[str, Any]


class UserAiAskResponse(TypedDict, total=False):
    """Response from LLM ask handlers."""

    responseString: str
    annotations: dict[str, Any]


class LlmModelMetadata(TypedDict, total=False):
    """Metadata for a single LLM model."""

    contextWindowTokens: int
    maxOutputTokens: int


class LlmServiceOptions(TypedDict, total=False):
    """Options for the @llm_service decorator."""

    models: dict[UserAiChatModelName, LlmModelMetadata]
    supportsFunctions: bool


class McpServerOptions(TypedDict):
    """Options for the @mcp_server decorator."""

    id: str
    description: str
    name: str
    version: str


class McpToolMetadataOptions(TypedDict, total=False):
    """Options for the @mcp_tool decorator."""

    description: str
    inputSchema: JSONSchema
    outputSchema: JSONSchema


class McpAuthorizationRequest(TypedDict, total=False):
    """Request received by @mcp_authorizer handlers."""

    body: Any
    queryParams: dict[str, str]
    headers: dict[str, str]


# ---------------------------------------------------------------------------
# Trigger / Scheduler option types (decorator argument forms)
# ---------------------------------------------------------------------------


class TriggerOptions(TypedDict, total=False):
    """Options for the @trigger decorator."""

    id: str
    collection: str
    integrationId: str
    mutationTypes: list[MutationType]


class SchedulerOptions(TypedDict, total=False):
    """Options for the @scheduler decorator."""

    cron: str
    id: str
    exclusive: bool


class AiFunctionMetadataOptions(TypedDict, total=False):
    """Options for the @ai_function decorator."""

    id: str
    description: str
    params: list[AiFunctionParam]
    attributes: AiFunctionAttributes
    categories: list[str]
    internal: bool


class AiFunctionsConfiguratorMetadataOptions(TypedDict, total=False):
    """Options for the @ai_functions_configurator decorator."""

    id: str
    integrationTypes: list[IntegrationType]


class SecureMetricOptions(TypedDict, total=False):
    """Options for the @secure_metric decorator."""

    metricNamePrefix: str
    type: MetricActionType


# ---------------------------------------------------------------------------
# Integration lifecycle types
# ---------------------------------------------------------------------------


class IntegrationLifecycleHooksMetadata(TypedDict):
    """Tracks which lifecycle hooks are implemented."""

    onIntegrationCreated: bool
    onIntegrationChanged: bool
    onIntegrationDeleted: bool


class OnIntegrationLifecycleInput(TypedDict, total=False):
    """Input to integration lifecycle hook methods."""

    integrationId: str
    integrationType: str
    config: dict[str, Any]


# ---------------------------------------------------------------------------
# CronExpression enum
# ---------------------------------------------------------------------------


class CronExpression(StrEnum):
    """Common cron expressions. Values are UTC cron strings."""

    EVERY_SECOND = "* * * * * *"
    EVERY_5_SECONDS = "*/5 * * * * *"
    EVERY_10_SECONDS = "*/10 * * * * *"
    EVERY_30_SECONDS = "*/30 * * * * *"
    EVERY_MINUTE = "*/1 * * * *"
    EVERY_5_MINUTES = "*/5 * * * *"
    EVERY_10_MINUTES = "*/10 * * * *"
    EVERY_15_MINUTES = "*/15 * * * *"
    EVERY_30_MINUTES = "*/30 * * * *"
    EVERY_HOUR = "0 * * * *"
    EVERY_2_HOURS = "0 */2 * * *"
    EVERY_3_HOURS = "0 */3 * * *"
    EVERY_4_HOURS = "0 */4 * * *"
    EVERY_6_HOURS = "0 */6 * * *"
    EVERY_8_HOURS = "0 */8 * * *"
    EVERY_12_HOURS = "0 */12 * * *"
    EVERY_DAY_AT_MIDNIGHT = "0 0 * * *"
    EVERY_DAY_AT_1AM = "0 1 * * *"
    EVERY_DAY_AT_2AM = "0 2 * * *"
    EVERY_DAY_AT_3AM = "0 3 * * *"
    EVERY_DAY_AT_4AM = "0 4 * * *"
    EVERY_DAY_AT_5AM = "0 5 * * *"
    EVERY_DAY_AT_6AM = "0 6 * * *"
    EVERY_DAY_AT_7AM = "0 7 * * *"
    EVERY_DAY_AT_8AM = "0 8 * * *"
    EVERY_DAY_AT_9AM = "0 9 * * *"
    EVERY_DAY_AT_10AM = "0 10 * * *"
    EVERY_DAY_AT_11AM = "0 11 * * *"
    EVERY_DAY_AT_NOON = "0 12 * * *"
    EVERY_DAY_AT_1PM = "0 13 * * *"
    EVERY_DAY_AT_2PM = "0 14 * * *"
    EVERY_DAY_AT_3PM = "0 15 * * *"
    EVERY_DAY_AT_4PM = "0 16 * * *"
    EVERY_DAY_AT_5PM = "0 17 * * *"
    EVERY_DAY_AT_6PM = "0 18 * * *"
    EVERY_DAY_AT_7PM = "0 19 * * *"
    EVERY_DAY_AT_8PM = "0 20 * * *"
    EVERY_DAY_AT_9PM = "0 21 * * *"
    EVERY_DAY_AT_10PM = "0 22 * * *"
    EVERY_DAY_AT_11PM = "0 23 * * *"
    EVERY_WEEK = "0 0 * * 0"
    EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT = "0 0 1 * *"
    EVERY_1ST_DAY_OF_MONTH_AT_NOON = "0 12 1 * *"
    EVERY_QUARTER = "0 0 1 */3 *"
    EVERY_6_MONTHS = "0 0 1 */6 *"
    EVERY_YEAR = "0 0 1 1 *"
    MONDAY_TO_FRIDAY_AT_9AM = "0 9 * * 1-5"
    MONDAY_TO_FRIDAY_AT_1AM = "0 1 * * 1-5"
    MONDAY_TO_FRIDAY_AT_6AM = "0 6 * * 1-5"
    MONDAY_TO_FRIDAY_AT_6PM = "0 18 * * 1-5"
    MONDAY_TO_FRIDAY_AT_11_30AM = "30 11 * * 1-5"
    MONDAY_TO_FRIDAY_AT_NOON = "0 12 * * 1-5"
