"""Python worker subprocess for the Squid tenant and local-backend.

Long-running process that communicates with the Node.js host via
JSON-line protocol over stdin/stdout.

Function executions (``executeFunction``) are dispatched to a background
asyncio event loop so that multiple async user functions can run in
parallel.  All other actions (``loadPy``, ``lookupFunction``, etc.) are
handled synchronously on the main thread to avoid deadlocks with
C-extension imports (e.g. numpy).

Protocol:
  TS -> Python:  {"action": "...", "requestId": "uuid", "payload": {...}}
  Python -> TS:  {"success": bool, "response": any, "requestId": "uuid"}

When success is true, response is the function's return value.
When success is false, response contains error details.
"""

from __future__ import annotations

import asyncio
import base64
import importlib
import importlib.util
import inspect
import json
import os
import sys
import threading
import traceback
from typing import Any

from squidcloud_backend.context import RequestScope
from squidcloud_backend.metadata import get_metadata
from squidcloud_backend.service import (
    OpenApiResponseException,
    SquidService,
    WebhookResponseException,
)
from squidcloud_backend.types import (
    QueueMessageRequest,
    RunContext,
    ServiceRequestConfig,
    TriggerRequest,
    WebhookRequest,
    auth_from_dict,
)


def _log(msg: str) -> None:
    """Log to stderr (forwarded to Node.js console)."""
    print(f"[python-worker] {msg}", file=sys.stderr, flush=True)


def _write_response(response: dict, lock: threading.Lock) -> None:
    """Serialize *response* as a JSON line to stdout, guarded by *lock*."""
    data = json.dumps(response, default=str) + "\n"
    with lock:
        sys.stdout.write(data)
        sys.stdout.flush()


class PythonWorker:
    """Manages loaded Python modules and service instances.

    Non-execute actions run synchronously on the main thread.
    ``executeFunction`` actions are dispatched to a background asyncio
    event loop so multiple user coroutines can run concurrently.
    """

    def __init__(self) -> None:
        self._modules: dict[str, Any] = {}
        self._projects: dict[str, Any] = {}
        self._service_instances: dict[str, SquidService] = {}

        # Background event loop for concurrent function execution.
        self._loop = asyncio.new_event_loop()
        self._loop_thread = threading.Thread(
            target=self._loop.run_forever, daemon=True, name="asyncio-loop"
        )
        self._loop_thread.start()

        # Tracks in-flight executeFunction tasks.
        self._in_flight: set[asyncio.Task] = set()

        # Guards stdout writes from the main thread and the background loop.
        self._write_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Synchronous message handling (main thread)
    # ------------------------------------------------------------------

    def handle_message(self, message: dict) -> dict:
        """Route a non-execute message to the appropriate handler."""
        action = message.get("action", "")
        request_id = message.get("requestId", "")
        payload = message.get("payload", {})

        try:
            if action == "loadPy":
                result = self._handle_load(payload)
            elif action == "lookupFunction":
                result = self._handle_lookup_function(payload)
            elif action == "metadata":
                result = self._handle_metadata()
            elif action == "heartbeat":
                result = {"success": True, "response": None}
            elif action == "terminate":
                result = self._handle_terminate()
            else:
                result = {"success": False, "response": {"message": f"Unknown action: {action}"}}
        except Exception as e:
            _log(f"Error handling {action}: {traceback.format_exc()}")
            result = {
                "success": False,
                "response": {"message": str(e), "stack": traceback.format_exc()},
            }

        result["requestId"] = request_id
        return result

    # ------------------------------------------------------------------
    # Async function execution (background event loop)
    # ------------------------------------------------------------------

    def submit_execute(self, message: dict) -> None:
        """Submit an executeFunction message to the background event loop."""
        future = asyncio.run_coroutine_threadsafe(self._execute_and_respond(message), self._loop)
        # Fire-and-forget: response is written by the coroutine itself.
        # Attach a callback to log unexpected errors.
        future.add_done_callback(self._on_execute_done)

    async def _execute_and_respond(self, message: dict) -> None:
        """Execute a function and write the response to stdout."""
        request_id = message.get("requestId", "")
        payload = message.get("payload", {})

        task = asyncio.current_task()
        if task is not None:
            self._in_flight.add(task)

        try:
            result = await self._handle_execute(payload)
        except Exception as e:
            _log(f"Error handling executeFunction: {traceback.format_exc()}")
            result = {
                "success": False,
                "response": {"message": str(e), "stack": traceback.format_exc()},
            }

        result["requestId"] = request_id
        _write_response(result, self._write_lock)

        if task is not None:
            self._in_flight.discard(task)

    @staticmethod
    def _on_execute_done(future: asyncio.futures.Future) -> None:
        """Log exceptions that escaped _execute_and_respond."""
        exc = future.exception()
        if exc is not None:
            _log(f"Unhandled error in executeFunction task: {exc}")

    def wait_for_in_flight(self) -> None:
        """Block the calling (main) thread until all in-flight tasks finish."""
        if not self._in_flight:
            return
        _log(f"Waiting for {len(self._in_flight)} in-flight request(s)...")
        gather_future = asyncio.run_coroutine_threadsafe(
            asyncio.gather(*self._in_flight, return_exceptions=True), self._loop
        )
        gather_future.result()  # blocks

    def shutdown_loop(self) -> None:
        """Stop the background event loop."""
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._loop_thread.join(timeout=5)

    # ------------------------------------------------------------------
    # Action handlers
    # ------------------------------------------------------------------

    def _handle_load(self, payload: dict) -> dict:
        """Load a Python module from the given path."""
        index_py_path = payload.get("indexPyPath", "")
        module_id = payload.get("moduleId", "user-code")

        if not index_py_path:
            return {"success": False, "response": {"message": "Missing indexPyPath"}}

        _log(f"Loading Python module: {index_py_path} (id={module_id})")

        try:
            src_dir = os.path.dirname(os.path.abspath(index_py_path))
            if src_dir not in sys.path:
                sys.path.insert(0, src_dir)

            project_dir = os.path.dirname(src_dir)
            if project_dir not in sys.path:
                sys.path.insert(0, project_dir)

            spec = importlib.util.spec_from_file_location(f"squid_user_{module_id}", index_py_path)
            if spec is None or spec.loader is None:
                return {
                    "success": False,
                    "response": {"message": f"Cannot load module: {index_py_path}"},
                }

            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)

            self._modules[module_id] = module

            from squidcloud_backend.project import SquidProject

            for attr_name in dir(module):
                attr = getattr(module, attr_name, None)
                if isinstance(attr, SquidProject):
                    self._projects[module_id] = attr
                    _log(f"Found SquidProject instance: {attr_name}")
                    break

            public_dir = os.path.join(os.path.dirname(index_py_path), "public")
            if os.path.isdir(public_dir):
                SquidService._global_assets_directory = public_dir

            _log(f"Successfully loaded module {module_id}")
            return {"success": True, "response": None}

        except Exception as e:
            _log(f"Failed to load module: {traceback.format_exc()}")
            return {
                "success": False,
                "response": {"message": str(e), "stack": traceback.format_exc()},
            }

    def _handle_lookup_function(self, payload: dict) -> dict:
        """Check if a function exists in the loaded Python modules."""
        function_name = payload.get("functionName", "")
        if ":" not in function_name:
            return {"success": True, "response": {"found": False}}

        class_name, method_name = function_name.split(":", 1)
        service_classes = get_metadata().get_service_classes()
        cls = service_classes.get(class_name)
        if cls is None:
            return {"success": True, "response": {"found": False}}

        if not hasattr(cls, method_name) or not callable(getattr(cls, method_name, None)):
            return {"success": True, "response": {"found": False}}

        return {"success": True, "response": {"found": True}}

    async def _handle_execute(self, payload: dict) -> dict:
        """Execute a backend function."""
        function_name = payload.get("functionName", "")
        params = list(payload.get("params", []))
        context_data = payload.get("context", {})
        auth_data = payload.get("auth")
        secrets = payload.get("secrets", {})
        api_keys = payload.get("apiKeys", {})
        backend_api_key = payload.get("backendApiKey", "")
        annotation_type = payload.get("executeFunctionAnnotationType", "")

        # Params arrive already transformed by TS (transformParams ran before IPC).
        # Decode any base64-encoded binary data (SquidFile.data converted by TS for JSON serialization).
        params = self._decode_base64_in_params(params)

        # Update global config per-request.
        # Invalidate cached Squid client if credentials changed.
        new_api_key = backend_api_key
        new_app_id = context_data.get("appId", "")
        if (
            SquidService._global_backend_api_key != new_api_key
            or SquidService._global_app_id != new_app_id
        ):
            SquidService._global_squid_client = None

        SquidService._global_secrets = secrets if isinstance(secrets, dict) else {}
        SquidService._global_api_keys = api_keys if isinstance(api_keys, dict) else {}
        SquidService._global_backend_api_key = new_api_key
        SquidService._global_app_id = new_app_id

        # Auto-convert webhook/trigger/queueMessage params to typed objects
        if annotation_type == "webhook" and params and isinstance(params[0], dict):
            params = [WebhookRequest(**params[0])]
        elif annotation_type == "trigger" and params and isinstance(params[0], dict):
            params = [TriggerRequest(**params[0])]
        elif annotation_type == "queueMessageHandler" and params and isinstance(params[0], dict):
            params = [QueueMessageRequest(**params[0])]

        # Parse context and auth
        run_context = RunContext(appId=context_data.get("appId", ""))
        if "clientId" in context_data:
            run_context["clientId"] = context_data["clientId"]
        if "sourceIp" in context_data:
            run_context["sourceIp"] = context_data["sourceIp"]
        if "headers" in context_data:
            run_context["headers"] = context_data["headers"]
        if "openApiContext" in context_data:
            run_context["openApiContext"] = context_data["openApiContext"]

        auth = auth_from_dict(auth_data)
        request_config = ServiceRequestConfig(auth=auth, context=run_context)

        # Special case: metadata
        if function_name == "default:metadata":
            return self._handle_metadata()

        # Parse service function name
        if ":" not in function_name:
            return {
                "success": False,
                "response": {
                    "message": f"Invalid function name format: '{function_name}', expected 'ClassName:method_name'"
                },
            }

        class_name, method_name = function_name.split(":", 1)

        # Find or create service instance
        service = self._get_or_create_service(class_name)
        if service is None:
            return {
                "success": False,
                "response": {"message": f"Service class '{class_name}' not found"},
            }

        method = getattr(service, method_name, None)
        if method is None or not callable(method):
            return {
                "success": False,
                "response": {"message": f"Method '{method_name}' not found on {class_name}"},
            }

        # Execute within request scope
        try:
            with RequestScope(request_config):
                result = method(*params)
                if inspect.isawaitable(result):
                    result = await result

            # Webhook/OpenAPI responses returned as success with markers
            return {"success": True, "response": self._serialize_response(result)}

        except WebhookResponseException as e:
            return {"success": True, "response": dict(e.response)}

        except OpenApiResponseException as e:
            return {"success": True, "response": dict(e.response)}

        except Exception as e:
            _log(f"Function execution error: {traceback.format_exc()}")
            return {
                "success": False,
                "response": {"message": str(e), "stack": traceback.format_exc()},
            }

    def _handle_metadata(self) -> dict:
        """Return collected metadata."""
        return {"success": True, "response": get_metadata().data}

    def _handle_terminate(self) -> dict:
        """Graceful shutdown."""
        for module_id, project in self._projects.items():
            try:
                cleanup = getattr(project, "cleanup", None)
                if cleanup and callable(cleanup):
                    result = cleanup()
                    if inspect.isawaitable(result):
                        asyncio.run_coroutine_threadsafe(result, self._loop).result()
            except Exception as e:
                _log(f"Cleanup error for module {module_id}: {e}")

        return {"success": True, "response": None}

    def _get_or_create_service(self, class_name: str) -> SquidService | None:
        """Get or create a singleton service instance."""
        if class_name in self._service_instances:
            return self._service_instances[class_name]

        service_classes = get_metadata().get_service_classes()
        cls = service_classes.get(class_name)
        if cls is None:
            return None

        try:
            instance = cls()
            self._service_instances[class_name] = instance
            return instance
        except Exception as e:
            _log(f"Failed to instantiate {class_name}: {e}")
            return None

    def _decode_base64_in_params(self, params: Any) -> Any:
        """Recursively decode base64-encoded binary data in params.

        The TS side converts Uint8Array to {__base64__: "..."} for JSON serialization.
        This restores them to Python bytes.
        """
        if isinstance(params, dict):
            if "__base64__" in params:
                return base64.b64decode(params["__base64__"])
            return {k: self._decode_base64_in_params(v) for k, v in params.items()}
        if isinstance(params, list):
            return [self._decode_base64_in_params(item) for item in params]
        return params

    def _serialize_response(self, result: Any) -> Any:
        """Ensure the response is JSON-serializable.

        Handles bytes/bytearray by converting to base64 with a marker,
        matching the TS maybeConvertToBase64Files pattern.
        """
        if result is None:
            return None
        if isinstance(result, bytes):
            return {
                "base64": base64.b64encode(result).decode("ascii"),
                "__isSquidBase64File__": True,
            }
        if isinstance(result, dict):
            # Recursively serialize dict values (handles files inside dicts)
            return {k: self._serialize_response(v) for k, v in result.items()}
        if isinstance(result, (str, int, float, bool)):
            return result
        if isinstance(result, (list, tuple)):
            return [self._serialize_response(item) for item in result]
        if hasattr(result, "__dict__"):
            return {k: self._serialize_response(v) for k, v in result.__dict__.items()}
        return str(result)


DEBUGPY_PORT = 5678


def _setup_debugpy() -> None:
    """Enable debugpy for local development. Silently skipped if debugpy is not installed.

    Only activates when SQUID_LOCAL_DEV=true, which is set by the local-backend
    when running via 'squid start'. Not set in the tenant (production or local infra).
    """
    if os.environ.get("SQUID_LOCAL_DEV") == "true":
        try:
            import debugpy  # type: ignore[import-untyped]

            debugpy.listen(("127.0.0.1", DEBUGPY_PORT))
            _log(f"debugpy listening on port {DEBUGPY_PORT} -- attach your debugger")
        except ImportError:
            pass  # debugpy not installed -- skip silently
        except Exception as e:
            _log(f"debugpy setup failed: {e}")  # port in use, etc.


def main() -> None:
    """Main entry point -- reads JSON lines from stdin, writes responses to stdout.

    The main thread reads stdin synchronously (no background threads touching
    stdin) so that C-extension imports during ``loadPy`` cannot deadlock.
    ``executeFunction`` requests are dispatched to a background asyncio event
    loop for concurrent execution.
    """
    _log("Python worker starting...")
    _setup_debugpy()
    worker = PythonWorker()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue

        try:
            message = json.loads(line)
        except json.JSONDecodeError as e:
            _log(f"Invalid JSON: {e}")
            response = {"success": False, "response": {"message": str(e)}, "requestId": ""}
            _write_response(response, worker._write_lock)
            continue

        action = message.get("action")

        if action == "executeFunction":
            # Dispatch to background event loop for concurrent execution.
            worker.submit_execute(message)
        elif action == "terminate":
            # Drain in-flight function executions, then terminate.
            worker.wait_for_in_flight()
            response = worker.handle_message(message)
            _write_response(response, worker._write_lock)
            _log("Python worker terminating.")
            break
        else:
            # loadPy, lookupFunction, metadata, heartbeat -- handle inline.
            response = worker.handle_message(message)
            _write_response(response, worker._write_lock)

    worker.shutdown_loop()
    _log("Python worker exiting.")


if __name__ == "__main__":
    main()
