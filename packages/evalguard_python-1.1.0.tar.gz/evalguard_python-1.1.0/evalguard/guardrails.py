"""Core guardrail client shared by all framework integrations.

Provides pre-LLM input checking (prompt injection, PII redaction) and
post-LLM trace logging.  Every framework wrapper delegates to a single
:class:`GuardrailClient` instance so configuration is consistent.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import requests

logger = logging.getLogger("evalguard.guardrails")

_DEFAULT_RULES: List[str] = ["prompt_injection", "pii_redact"]


class GuardrailClient:
    """Lightweight HTTP client for the EvalGuard guardrail & trace APIs.

    Parameters
    ----------
    api_key:
        EvalGuard API key (``eg_live_...`` or ``eg_test_...``).
    base_url:
        API base URL.  Override for self-hosted deployments.
    project_id:
        Optional project ID attached to every trace.
    timeout:
        HTTP request timeout in seconds.  Keep low (default 5 s) so the
        guardrail check never dominates end-to-end latency.
    fail_open:
        If *True*, network / server errors allow the request through
        instead of raising.  Defaults to *False*.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.evalguard.ai",
        project_id: Optional[str] = None,
        timeout: float = 5.0,
        fail_open: bool = False,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._project_id = project_id
        self._timeout = timeout
        self._fail_open = fail_open
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "evalguard-python/1.0.0",
            }
        )

    # ── Public API ────────────────────────────────────────────────────

    def check_input(
        self,
        text: str,
        rules: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Pre-LLM guard check.

        Returns
        -------
        dict
            ``{"allowed": bool, "violations": [...], "sanitized": str | None}``
        """
        payload: Dict[str, Any] = {
            "input": text,
            "rules": rules or _DEFAULT_RULES,
        }
        if self._project_id:
            payload["project_id"] = self._project_id
        if metadata:
            payload["metadata"] = metadata
        try:
            resp = self._session.post(
                f"{self._base_url}/api/v1/guardrails",
                json=payload,
                timeout=self._timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("data", {"allowed": True, "violations": [], "sanitized": None})
        except Exception:
            if self._fail_open:
                logger.debug("Guardrail check failed; fail-open allowing request", exc_info=True)
                return {"allowed": True, "violations": [], "sanitized": None}
            raise

    def check_output(
        self,
        text: str,
        rules: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Post-LLM output check.

        Returns
        -------
        dict
            ``{"allowed": bool, "violations": [...], "sanitized": str | None}``
        """
        payload: Dict[str, Any] = {
            "output": text,
            "rules": rules or ["toxic_content", "pii_redact"],
        }
        if self._project_id:
            payload["project_id"] = self._project_id
        if metadata:
            payload["metadata"] = metadata
        try:
            resp = self._session.post(
                f"{self._base_url}/api/v1/guardrails/output",
                json=payload,
                timeout=self._timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            return data.get("data", {"allowed": True, "violations": [], "sanitized": None})
        except Exception:
            if self._fail_open:
                logger.debug("Output check failed; fail-open allowing response", exc_info=True)
                return {"allowed": True, "violations": [], "sanitized": None}
            raise

    def log_trace(self, data: Dict[str, Any]) -> None:
        """Fire-and-forget trace logging.  Errors are silently swallowed."""
        payload = {**data}
        if self._project_id:
            payload.setdefault("project_id", self._project_id)
        try:
            self._session.post(
                f"{self._base_url}/api/v1/traces",
                json=payload,
                timeout=self._timeout,
            )
        except Exception:
            logger.debug("Trace log failed", exc_info=True)

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()


class GuardrailViolation(Exception):
    """Raised when a guardrail check blocks a request."""

    def __init__(self, violations: List[Dict[str, Any]], message: str = "Blocked by EvalGuard guardrail"):
        super().__init__(message)
        self.violations = violations
