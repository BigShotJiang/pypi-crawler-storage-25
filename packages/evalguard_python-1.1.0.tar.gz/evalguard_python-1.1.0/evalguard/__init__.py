"""EvalGuard Python SDK -- evaluate, red-team, and guard LLM applications."""

from .client import EvalGuardClient, EvalGuardError
from .guardrails import GuardrailClient, GuardrailViolation
from .types import (
    BenchmarkResult,
    CaseResult,
    ComplianceReport,
    DriftReport,
    EvalCase,
    EvalResult,
    EvalRun,
    FirewallResult,
    FirewallRule,
    SecurityFinding,
    SecurityScanResult,
    TokenUsage,
)

__version__ = "1.1.0"

__all__ = [
    # Core client
    "EvalGuardClient",
    "EvalGuardError",
    # Guardrails
    "GuardrailClient",
    "GuardrailViolation",
    # Types
    "BenchmarkResult",
    "CaseResult",
    "ComplianceReport",
    "DriftReport",
    "EvalCase",
    "EvalResult",
    "EvalRun",
    "FirewallResult",
    "FirewallRule",
    "SecurityFinding",
    "SecurityScanResult",
    "TokenUsage",
]
