"""
ZarPay Python SDK v1.1.0 — Client implementation
"""

import hashlib
import hmac
import json
import time
from typing import Any, Dict, Optional
from urllib.parse import quote, urlencode

import requests


DEFAULT_BASE_URL = "https://zarpay.pk/api/v1"
DEFAULT_TIMEOUT = 120
SDK_VERSION = "1.1.0"


class ZarPayAPIError(Exception):
    """Raised when the ZarPay API returns an error response."""

    def __init__(self, status_code: int, error: str, body: dict):
        self.status_code = status_code
        self.error = error
        self.body = body
        super().__init__(f"ZarPay API error ({status_code}): {error}")


class PaymentsResource:
    """Payment operations."""

    def __init__(self, client: "ZarPay"):
        self._client = client

    def create(
        self,
        merchant_order_id: str,
        amount: float,
        channel_id: int,
        customer_phone: str,
        metadata: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> dict:
        """
        Create a new payment.

        Args:
            merchant_order_id: Your unique order ID (max 100 chars)
            amount: Amount in PKR (minimum 100)
            channel_id: Channel ID from channels.list()
            customer_phone: Customer phone (03XXXXXXXXX or +923XXXXXXXXX)
            metadata: Optional custom key-value pairs
            idempotency_key: Optional key to prevent duplicates

        Returns:
            Payment response dict with 'success' and 'data' keys

        Raises:
            ZarPayAPIError: If the API returns an error
        """
        body: Dict[str, Any] = {
            "merchant_order_id": merchant_order_id,
            "amount": amount,
            "channel_id": channel_id,
            "customer_phone": customer_phone,
        }
        if metadata is not None:
            body["metadata"] = metadata
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key

        return self._client._request("POST", "/payments", json=body)

    def get(self, zarpay_id: str) -> dict:
        """Get a payment by its ZarPay ID."""
        return self._client._request("GET", f"/payments/{quote(zarpay_id, safe='')}")

    def get_by_order_id(self, order_id: str) -> dict:
        """Get a payment by your merchant order ID."""
        return self._client._request(
            "GET", f"/payments/by-order/{quote(order_id, safe='')}"
        )


class RefundsResource:
    """Refund operations."""

    def __init__(self, client: "ZarPay"):
        self._client = client

    def create(
        self,
        zarpay_id: str,
        amount: float,
        reason: Optional[str] = None,
    ) -> dict:
        """
        Initiate a refund on a completed payment.

        Args:
            zarpay_id: The ZarPay payment ID to refund
            amount: Refund amount in PKR
            reason: Optional reason for the refund

        Returns:
            Refund response dict with 'success' and 'data' keys
        """
        body: Dict[str, Any] = {
            "zarpay_id": zarpay_id,
            "amount": amount,
        }
        if reason is not None:
            body["reason"] = reason
        return self._client._request("POST", "/refunds", json=body)


class BalanceResource:
    """Balance queries."""

    def __init__(self, client: "ZarPay"):
        self._client = client

    def get(self) -> dict:
        """
        Get the project's financial balance summary.

        Returns:
            Balance dict with settled, unsettled, pending, available, etc.
        """
        return self._client._request("GET", "/balance")


class SettlementsResource:
    """Settlement queries."""

    def __init__(self, client: "ZarPay"):
        self._client = client

    def list(
        self,
        status: Optional[str] = None,
        page: int = 1,
        limit: int = 20,
    ) -> dict:
        """
        List settlements for the project.

        Args:
            status: Optional filter (PENDING, SETTLED, PAID)
            page: Page number (default 1)
            limit: Results per page (default 20)

        Returns:
            Paginated settlements response
        """
        params: Dict[str, Any] = {"page": page, "limit": limit}
        if status is not None:
            params["status"] = status
        qs = urlencode(params)
        return self._client._request("GET", f"/settlements?{qs}")


class ChannelsResource:
    """Channel operations."""

    def __init__(self, client: "ZarPay"):
        self._client = client

    def list(self) -> dict:
        """List available payment channels for your project."""
        return self._client._request("GET", "/channels")


class ZarPay:
    """
    ZarPay API client.

    Args:
        api_key: Your ZarPay API key (sk_sandbox_... or sk_production_...)
        base_url: API base URL (default: https://zarpay.pk/api/v1)
        timeout: Request timeout in seconds (default: 120)

    Example::

        from zarpay import ZarPay

        client = ZarPay("sk_sandbox_xxxxxxxxxxxxx")

        # Create payment
        payment = client.payments.create(
            merchant_order_id="ORD-123",
            amount=1500,
            channel_id=1,
            customer_phone="03001234567",
        )

        # Check balance
        balance = client.balance.get()
        print(balance["data"]["available"])

        # Initiate refund
        refund = client.refunds.create("ZP_abc123", 500, reason="Customer request")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise ValueError("ZarPay API key is required")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"zarpay-python/{SDK_VERSION}",
            }
        )

        self.payments = PaymentsResource(self)
        self.refunds = RefundsResource(self)
        self.balance = BalanceResource(self)
        self.settlements = SettlementsResource(self)
        self.channels = ChannelsResource(self)

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self._base_url}{path}"
        response = self._session.request(
            method, url, timeout=self._timeout, **kwargs
        )
        data = response.json()

        if not response.ok and "error" in data:
            raise ZarPayAPIError(response.status_code, data["error"], data)

        return data


def verify_webhook(
    raw_body: bytes,
    signature_header: str,
    secret: str,
    tolerance_sec: int = 300,
) -> dict:
    """
    Verify a ZarPay webhook signature.

    Args:
        raw_body: The raw request body (bytes)
        signature_header: The X-ZarPay-Signature header value
        secret: Your webhook signing secret (whsec_...)
        tolerance_sec: Max age in seconds (default: 300)

    Returns:
        The parsed webhook payload dict

    Raises:
        ValueError: If signature is invalid or timestamp is too old
    """
    parts = {}
    for part in signature_header.split(","):
        key, _, value = part.partition("=")
        parts[key] = value

    t = parts.get("t", "")
    v1 = parts.get("v1", "")

    if not t or not v1:
        raise ValueError("Invalid X-ZarPay-Signature header format")

    timestamp = int(t)
    if abs(time.time() - timestamp) > tolerance_sec:
        raise ValueError("Webhook timestamp too old — possible replay attack")

    body_str = raw_body.decode("utf-8") if isinstance(raw_body, bytes) else raw_body
    expected = hmac.new(
        secret.encode("utf-8"),
        f"{t}.{body_str}".encode("utf-8"),
        digestmod=hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(expected, v1):
        raise ValueError("Invalid webhook signature")

    return json.loads(raw_body)
