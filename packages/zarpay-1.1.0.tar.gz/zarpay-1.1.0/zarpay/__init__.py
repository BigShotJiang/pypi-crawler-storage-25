"""
ZarPay Python SDK

Official SDK for integrating with the ZarPay payment gateway.

Usage:
    from zarpay import ZarPay

    client = ZarPay("sk_sandbox_xxxxxxxxxxxxx")

    payment = client.payments.create(
        merchant_order_id="ORD-123",
        amount=1500,
        channel_id=1,
        customer_phone="03001234567",
    )
"""

from .client import ZarPay, ZarPayAPIError, verify_webhook

__version__ = "1.1.0"
__all__ = ["ZarPay", "ZarPayAPIError", "verify_webhook"]
