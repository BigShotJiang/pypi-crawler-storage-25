# Copyright 2026 The Radiativity Company
# Licensed under the Apache License, Version 2.0

"""
ucon.units
===========

Unit objects loaded from ``comprehensive.ucon.toml`` at import time.

Every ``Unit`` defined in the TOML file becomes a module-level global.
For IDE autocomplete, see the companion ``units.pyi`` stub.

Example
-------
>>> from ucon import units
>>> units.meter.dimension
<LENGTH>
>>> units.newton.dimension
<FORCE>

Notes
-----
The design allows for future extensibility: users can register their own units,
systems, or aliases dynamically, without modifying the core definitions.
"""
import warnings

from ucon.core import BaseForm, Dimension, Scale, Unit, UnknownUnitError  # noqa: F401
from ucon.system import BaseUnits
from ucon.dimension import (
    NONE, TIME, LENGTH, MASS, CURRENT, TEMPERATURE,
    LUMINOUS_INTENSITY, AMOUNT_OF_SUBSTANCE, INFORMATION,
    ANGLE, SOLID_ANGLE, RATIO, COUNT,
    VELOCITY, ACCELERATION, FORCE, ENERGY, POWER,
    MOMENTUM, ANGULAR_MOMENTUM, AREA, VOLUME, DENSITY, PRESSURE, FREQUENCY,
    DYNAMIC_VISCOSITY, KINEMATIC_VISCOSITY, LINEAR_DENSITY, GRAVITATION,
    CHARGE, VOLTAGE, RESISTANCE, RESISTIVITY, CONDUCTANCE, CONDUCTIVITY,
    CAPACITANCE, INDUCTANCE, MAGNETIC_FLUX, MAGNETIC_FLUX_DENSITY,
    MAGNETIC_PERMEABILITY, PERMITTIVITY, ELECTRIC_FIELD_STRENGTH,
    MAGNETIC_FIELD_STRENGTH,
    ENTROPY, SPECIFIC_HEAT_CAPACITY, THERMAL_CONDUCTIVITY,
    ILLUMINANCE, CATALYTIC_ACTIVITY, MOLAR_MASS, MOLAR_VOLUME, CONCENTRATION,
    WAVENUMBER, RADIANT_EXPOSURE, EXPOSURE, ELECTRIC_DIPOLE_MOMENT,
    # CGS dimensions
    CGS_FORCE, CGS_ENERGY, CGS_PRESSURE,
    CGS_DYNAMIC_VISCOSITY, CGS_KINEMATIC_VISCOSITY,
    CGS_ACCELERATION, CGS_WAVENUMBER, CGS_RADIANT_EXPOSURE,
    # CGS-ESU dimensions
    CGS_ESU_CHARGE, CGS_ESU_CURRENT, CGS_ESU_VOLTAGE,
    CGS_ESU_RESISTANCE, CGS_ESU_CAPACITANCE,
    CGS_ESU_MAGNETIC_FLUX_DENSITY, CGS_ESU_MAGNETIC_FLUX,
    CGS_ESU_MAGNETIC_FIELD_STRENGTH, CGS_ESU_ELECTRIC_DIPOLE_MOMENT,
    # CGS-EMU dimensions
    CGS_EMU_CURRENT, CGS_EMU_CHARGE, CGS_EMU_VOLTAGE,
    CGS_EMU_RESISTANCE, CGS_EMU_CAPACITANCE, CGS_EMU_INDUCTANCE,
    # Natural-unit dimensions
    NATURAL_ENERGY,
    # Planck-unit dimensions
    PLANCK_ENERGY, PLANCK_LENGTH,
    # Atomic-unit dimensions
    ATOMIC_ENERGY, ATOMIC_LENGTH,
)
from ucon.resolver import (
    get_unit_by_name,
    parse_unit,
    register_priority_scaled_alias,
    register_unit,
)


# ---------------------------------------------------------------------------
# Load all units from the canonical TOML file
# ---------------------------------------------------------------------------

from ucon._loader import get_units as _get_units

_units = _get_units()
globals().update(_units)

# Sentinel unit (no name, no dimension) — not in TOML
none = Unit()

# Register all units with the global resolver
for _u in _units.values():
    register_unit(_u)


# ---------------------------------------------------------------------------
# Predefined BaseUnits (dimension → base unit mappings)
# ---------------------------------------------------------------------------

si = BaseUnits(
    name="SI",
    bases={
        LENGTH: _units['meter'],
        MASS: _units['kilogram'],
        TIME: _units['second'],
        TEMPERATURE: _units['kelvin'],
        CURRENT: _units['ampere'],
        AMOUNT_OF_SUBSTANCE: _units['mole'],
        LUMINOUS_INTENSITY: _units['candela'],
    }
)

imperial = BaseUnits(
    name="Imperial",
    bases={
        LENGTH: _units['foot'],
        MASS: _units['pound'],
        TIME: _units['second'],
        TEMPERATURE: _units['fahrenheit'],
    }
)


# ---------------------------------------------------------------------------
# Priority scaled aliases (usage conventions, not unit definitions)
# ---------------------------------------------------------------------------

def _register_aliases() -> None:
    """Register scaled aliases that encode usage conventions."""
    gram = _units['gram']
    meter = _units['meter']
    second = _units['second']
    hertz = _units['hertz']
    liter = _units['liter']
    watt = _units['watt']
    joule = _units['joule']
    pascal = _units['pascal']
    volt = _units['volt']
    ampere = _units['ampere']
    byte = _units['byte']
    bit = _units['bit']

    # Medical conventions
    register_priority_scaled_alias('mcg', gram, Scale.micro)   # microgram
    register_priority_scaled_alias('cc', liter, Scale.milli)   # cubic centimeter = 1 mL

    # -- Spelled-out scale aliases -----------------------------------------
    # Length
    register_priority_scaled_alias('kilometer', meter, Scale.kilo)
    register_priority_scaled_alias('centimeter', meter, Scale.centi)
    register_priority_scaled_alias('millimeter', meter, Scale.milli)
    register_priority_scaled_alias('micrometer', meter, Scale.micro)
    register_priority_scaled_alias('nanometer', meter, Scale.nano)
    register_priority_scaled_alias('picometer', meter, Scale.pico)

    # Mass
    register_priority_scaled_alias('milligram', gram, Scale.milli)
    register_priority_scaled_alias('microgram', gram, Scale.micro)

    # Time
    register_priority_scaled_alias('millisecond', second, Scale.milli)
    register_priority_scaled_alias('microsecond', second, Scale.micro)
    register_priority_scaled_alias('nanosecond', second, Scale.nano)
    register_priority_scaled_alias('picosecond', second, Scale.pico)

    # Frequency
    register_priority_scaled_alias('kilohertz', hertz, Scale.kilo)
    register_priority_scaled_alias('megahertz', hertz, Scale.mega)
    register_priority_scaled_alias('gigahertz', hertz, Scale.giga)

    # Volume
    register_priority_scaled_alias('milliliter', liter, Scale.milli)
    register_priority_scaled_alias('microliter', liter, Scale.micro)

    # Power
    register_priority_scaled_alias('kilowatt', watt, Scale.kilo)
    register_priority_scaled_alias('megawatt', watt, Scale.mega)
    register_priority_scaled_alias('gigawatt', watt, Scale.giga)
    register_priority_scaled_alias('milliwatt', watt, Scale.milli)

    # Energy
    register_priority_scaled_alias('kilojoule', joule, Scale.kilo)
    register_priority_scaled_alias('megajoule', joule, Scale.mega)

    # Pressure
    register_priority_scaled_alias('kilopascal', pascal, Scale.kilo)
    register_priority_scaled_alias('megapascal', pascal, Scale.mega)
    register_priority_scaled_alias('hectopascal', pascal, Scale.hecto)

    # Voltage
    register_priority_scaled_alias('millivolt', volt, Scale.milli)
    register_priority_scaled_alias('kilovolt', volt, Scale.kilo)

    # Current
    register_priority_scaled_alias('milliampere', ampere, Scale.milli)
    register_priority_scaled_alias('microampere', ampere, Scale.micro)

    # Information (decimal)
    register_priority_scaled_alias('kilobyte', byte, Scale.kilo)
    register_priority_scaled_alias('megabyte', byte, Scale.mega)
    register_priority_scaled_alias('gigabyte', byte, Scale.giga)
    register_priority_scaled_alias('terabyte', byte, Scale.tera)
    register_priority_scaled_alias('petabyte', byte, Scale.peta)
    register_priority_scaled_alias('kilobit', bit, Scale.kilo)
    register_priority_scaled_alias('megabit', bit, Scale.mega)
    register_priority_scaled_alias('gigabit', bit, Scale.giga)

    # Information (binary)
    register_priority_scaled_alias('kibibyte', byte, Scale.kibi)
    register_priority_scaled_alias('mebibyte', byte, Scale.mebi)
    register_priority_scaled_alias('gibibyte', byte, Scale.gibi)
    register_priority_scaled_alias('tebibyte', byte, Scale.tebi)
    register_priority_scaled_alias('pebibyte', byte, Scale.pebi)
    register_priority_scaled_alias('exbibyte', byte, Scale.exbi)

    # -- Scaled aliases not covered by prefix decomposition -------------------
    # Angle
    radian = _units['radian']
    register_priority_scaled_alias('microradian', radian, Scale.micro)
    register_priority_scaled_alias('milliradian', radian, Scale.milli)

    # Luminous intensity
    lumen = _units['lumen']
    register_priority_scaled_alias('millilumen', lumen, Scale.milli)

    # Concentration (molar prefixed forms; unscaled "M" lives in TOML aliases)
    molar = _units['molar']
    register_priority_scaled_alias('mM', molar, Scale.milli)
    register_priority_scaled_alias('µM', molar, Scale.micro)
    register_priority_scaled_alias('uM', molar, Scale.micro)
    register_priority_scaled_alias('nM', molar, Scale.nano)
    register_priority_scaled_alias('pM', molar, Scale.pico)

    # -- Plural forms of spelled-out scaled aliases ---------------------------
    # Length
    register_priority_scaled_alias('kilometers', meter, Scale.kilo)
    register_priority_scaled_alias('centimeters', meter, Scale.centi)
    register_priority_scaled_alias('millimeters', meter, Scale.milli)
    register_priority_scaled_alias('micrometers', meter, Scale.micro)
    register_priority_scaled_alias('nanometers', meter, Scale.nano)
    register_priority_scaled_alias('picometers', meter, Scale.pico)

    # Mass
    register_priority_scaled_alias('milligrams', gram, Scale.milli)
    register_priority_scaled_alias('micrograms', gram, Scale.micro)

    # Time
    register_priority_scaled_alias('milliseconds', second, Scale.milli)
    register_priority_scaled_alias('microseconds', second, Scale.micro)
    register_priority_scaled_alias('nanoseconds', second, Scale.nano)

    # Volume
    register_priority_scaled_alias('milliliters', liter, Scale.milli)
    register_priority_scaled_alias('microliters', liter, Scale.micro)

    # Power
    register_priority_scaled_alias('kilowatts', watt, Scale.kilo)
    register_priority_scaled_alias('megawatts', watt, Scale.mega)
    register_priority_scaled_alias('milliwatts', watt, Scale.milli)

    # Energy
    register_priority_scaled_alias('kilojoules', joule, Scale.kilo)
    register_priority_scaled_alias('megajoules', joule, Scale.mega)

    # Pressure
    register_priority_scaled_alias('kilopascals', pascal, Scale.kilo)
    register_priority_scaled_alias('megapascals', pascal, Scale.mega)
    register_priority_scaled_alias('hectopascals', pascal, Scale.hecto)

    # Angle
    register_priority_scaled_alias('microradians', radian, Scale.micro)
    register_priority_scaled_alias('milliradians', radian, Scale.milli)

    # Luminous intensity
    register_priority_scaled_alias('millilumens', lumen, Scale.milli)


_register_aliases()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def have(name: str) -> bool:
    """Check if a unit name is defined.

    .. deprecated:: 1.8.0
        Use :func:`ucon.resolver.parse_unit` and catch
        :class:`~ucon.core.UnknownUnitError` instead. ``have`` will be
        removed in v2.0.

    Delegates to :func:`~ucon.resolver.parse_unit`; the legacy
    Python-variable-name fallback is dropped in favour of the canonical
    ``Unit.name`` + alias resolution served by the resolver registry.
    """
    warnings.warn(
        "units.have() is deprecated; call parse_unit() and catch "
        "UnknownUnitError instead. It will be removed in ucon v2.0.",
        DeprecationWarning,
        stacklevel=2,
    )
    assert name, "Must provide a unit name to check"
    assert isinstance(name, str), "Unit name must be a string"
    try:
        parse_unit(name)
    except UnknownUnitError:
        return False
    return True


# Public surface: explicit names plus every TOML-loaded unit attribute.
# Built dynamically because the unit set is populated at import time from
# the canonical TOML registry.
__all__ = sorted(
    {
        "have",
        "none",
        "si",
        "imperial",
        *_units.keys(),
    }
)
