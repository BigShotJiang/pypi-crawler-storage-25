# © 2026 The Radiativity Company
# Licensed under the Apache License, Version 2.0
# See the LICENSE file for details.

"""
ucon.resolver
=============

Resolves unit strings into :class:`~ucon.core.Unit` and
:class:`~ucon.core.UnitProduct` objects.

Handles plain names (``"meter"``), aliases (``"m"``),
SI-prefix decomposition (``"km"``), exponents (``"m²"``),
and composite expressions (``"kg*m/s^2"``).

The global registries are populated at import time by
:mod:`ucon.units`, which calls :func:`register_unit` for
every canonical unit it defines.

Functions
---------
- :func:`parse_unit` — Public resolver (string → Unit | UnitProduct).
- :func:`get_unit_by_name` — Deprecated alias for :func:`parse_unit`.
- :func:`register_unit` — Register a unit (name + aliases) in the global lookup.
- :func:`register_priority_scaled_alias` — Register a scaled alias (e.g. "mcg").
"""
from __future__ import annotations

import re
import warnings
from typing import TYPE_CHECKING, Dict, Tuple, Union

if TYPE_CHECKING:
    from ucon.system import UnitSystem

from ucon.core import (
    NonScalableError,
    Scale,
    Unit,
    UnitFactor,
    UnitProduct,
    UnknownUnitError,
    _get_parsing_graph,
)
from ucon.parsing import parse_unit_expression, ParseError


# ---------------------------------------------------------------------------
# Global registries (populated by ucon.units at import time)
# ---------------------------------------------------------------------------

_UNIT_REGISTRY: Dict[str, Unit] = {}
_UNIT_REGISTRY_CASE_SENSITIVE: Dict[str, Unit] = {}

# Verbatim alias registry: aliases that contain parentheses are stored
# here so they can be resolved as a single token before the composite
# parser tokenises on '('. Multiplication / division operators are NOT
# routed through this registry because the composite parser already
# handles aliases like "m/s²" or "J/K" correctly; only parentheses cause
# the parser to fail outright (e.g. "Gy(RBE)" → ParseError).
#
# Only aliases enter this registry; canonical unit names are unaffected.
# This preserves the existing invariant that composite-looking strings
# parse via the recursive-descent parser unless an explicit
# parenthesised alias intercepts them.
_VERBATIM_ALIASES: Dict[str, Unit] = {}

# Characters whose presence in an alias makes it un-parseable by the
# composite parser, requiring whole-token resolution.
_VERBATIM_TRIGGER_CHARS = frozenset('()')

# ---------------------------------------------------------------------------
# Priority Alias Invariant (for contributors)
# ---------------------------------------------------------------------------
#
# When a unit alias could be misinterpreted as a scale prefix + unit symbol,
# add it to _PRIORITY_ALIASES or _PRIORITY_SCALED_ALIASES to prevent ambiguity.
#
# Examples:
#   - "min" could parse as milli-inch (m + in), but should be minute
#   - "mcg" could fail (no "mc" prefix), but should be microgram
#   - "cc" could fail, but should be cubic centimeter (cm³)
#
# Rule: If a unit string starts with a valid scale prefix AND the remainder
# is a valid unit symbol, check whether the whole string should be treated
# as a single unit. If so, add it to:
#
#   _PRIORITY_ALIASES - for unscaled units (e.g., "min" -> minute)
#   _PRIORITY_SCALED_ALIASES - for scaled units (e.g., "mcg" -> microgram)
#
# The parser checks these sets BEFORE attempting prefix decomposition.
# ---------------------------------------------------------------------------

# Priority aliases that must match exactly before prefix decomposition.
# Prevents ambiguous parses like "min" -> milli-inch instead of minute.
_PRIORITY_ALIASES: set = {'min', 'ft', 'ft_lb', 'ft_lbf'}

# Priority scaled aliases that map to a specific (unit, scale) tuple.
# Used for medical conventions like "mcg" -> (gram, Scale.micro).
_PRIORITY_SCALED_ALIASES: Dict[str, Tuple[Unit, Scale]] = {}

# Scale prefix mapping (shorthand -> Scale)
# Derived from Scale enum's ScaleDescriptor.shorthand, plus input-only aliases
_SCALE_PREFIXES: Dict[str, Scale] = {
    s.shorthand: s for s in Scale if s.shorthand
}

# Additional input aliases not in canonical ScaleDescriptor.shorthand
_SCALE_PREFIXES.update({
    'u': Scale.micro,  # ASCII alternative for µ
    'μ': Scale.micro,  # Unicode MICRO SIGN (U+00B5)
    # Note: Scale.micro.shorthand is 'µ' (GREEK SMALL LETTER MU, U+03BC)
})

# Sorted by length descending for greedy prefix matching
_SCALE_PREFIXES_SORTED = sorted(_SCALE_PREFIXES.keys(), key=len, reverse=True)

# Unicode superscript translation table
_SUPERSCRIPT_TO_DIGIT = str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹⁻', '0123456789-')


# ---------------------------------------------------------------------------
# Registration API
# ---------------------------------------------------------------------------

def register_unit(unit: Unit) -> None:
    """Register a unit in the global lookup tables.

    Registers the unit's canonical name and all aliases in both the
    case-insensitive and case-sensitive registries.

    Parameters
    ----------
    unit : Unit
        The unit to register. Must have a non-empty ``name``.
    """
    if not unit.name:
        return
    _UNIT_REGISTRY[unit.name.lower()] = unit
    _UNIT_REGISTRY_CASE_SENSITIVE[unit.name] = unit
    for alias in unit.aliases:
        if alias:
            _UNIT_REGISTRY[alias.lower()] = unit
            _UNIT_REGISTRY_CASE_SENSITIVE[alias] = unit
            # Aliases containing parentheses need the verbatim registry
            # to bypass composite tokenisation (which would fail on '(').
            if any(c in alias for c in _VERBATIM_TRIGGER_CHARS):
                _VERBATIM_ALIASES[alias] = unit


def register_priority_scaled_alias(alias: str, unit: Unit, scale: Scale) -> None:
    """Register a priority scaled alias.

    Priority scaled aliases are checked before prefix decomposition,
    e.g. ``"mcg"`` → ``(gram, Scale.micro)`` rather than trying to
    parse as a prefix + unit.

    Parameters
    ----------
    alias : str
        The alias string (e.g. ``"mcg"``).
    unit : Unit
        The target unit (e.g. ``gram``).
    scale : Scale
        The scale to apply (e.g. ``Scale.micro``).
    """
    _PRIORITY_SCALED_ALIASES[alias] = (unit, scale)


# ---------------------------------------------------------------------------
# Internal parsing helpers
# ---------------------------------------------------------------------------

def _parse_exponent(s: str) -> Tuple[str, float]:
    """
    Extract exponent from unit factor string.

    Handles both formats:
    - Unicode: 'm²' -> ('m', 2.0), 's⁻¹' -> ('s', -1.0)
    - ASCII:  'm^2' -> ('m', 2.0), 's^-1' -> ('s', -1.0)

    Returns:
        Tuple of (base_unit_str, exponent) where exponent defaults to 1.0.
    """
    # Try ASCII caret notation first: "m^2", "s^-1"
    if '^' in s:
        base, exp_str = s.rsplit('^', 1)
        try:
            return base.strip(), float(exp_str)
        except ValueError:
            raise UnknownUnitError(s)

    # Try Unicode superscripts: "m²", "s⁻¹"
    match = re.search(r'[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+$', s)
    if match:
        base = s[:match.start()]
        exp_str = match.group().translate(_SUPERSCRIPT_TO_DIGIT)
        try:
            return base, float(exp_str)
        except ValueError:
            raise UnknownUnitError(s)

    # No exponent found
    return s, 1.0


def _resolve_base_for_prefix(
    remainder: str,
    *,
    graph=None,
) -> Unit | None:
    """Resolve a prefix-decomposition remainder to a base :class:`Unit`.

    Used by :func:`_lookup_factor` after greedy prefix matching. Consults
    both the graph-local registry (case-sensitive, for session-defined units)
    and the global module-level registry. Returns ``None`` if the remainder
    is not a known unit in either registry.

    Case-sensitive in both registries — preserves the distinction between
    ``"fT"`` (femto-tesla) and ``"ft"`` (foot), and lets session-defined
    units shadow globals via the graph when present.

    Parameters
    ----------
    remainder : str
        The unit-name portion left after stripping a scale prefix.
    graph : ConversionGraph | None
        The graph context (already resolved via ``_get_parsing_graph()`` by
        the caller); ``None`` falls back to the global registry only.

    Returns
    -------
    Unit | None
        The base unit if found, otherwise ``None``.
    """
    if graph is not None:
        graph_result = graph.resolve_unit(remainder)
        if graph_result is not None:
            return graph_result[0]
    if remainder in _UNIT_REGISTRY_CASE_SENSITIVE:
        return _UNIT_REGISTRY_CASE_SENSITIVE[remainder]
    return None


def _lookup_factor(
    s: str,
    *,
    system: "UnitSystem | None" = None,
) -> Tuple[Unit, Scale]:
    """
    Look up a single unit factor, handling scale prefixes.

    Checks (in order):

    1. ``system.units`` when a :class:`~ucon.system.UnitSystem` is supplied
       — lets a curated registry shadow the global namespace at the factor
       level, so composite expressions like ``"USD/year"`` resolve through
       the system instead of the module globals.
    2. The graph-local registry (if within a ``using_graph()`` context).
    3. The module-level global registry, including priority aliases and
       scale-prefix decomposition.

    Prioritizes prefix+unit interpretation over direct unit lookup,
    except for priority aliases (like 'min', 'mcg') which are checked first
    to avoid ambiguous parses or to handle domain-specific conventions.

    This means "kg" returns (gram, Scale.kilo) rather than (kilogram, Scale.one).

    Examples:
    - 'meter' -> (meter, Scale.one)
    - 'm' -> (meter, Scale.one)
    - 'km' -> (meter, Scale.kilo)
    - 'kg' -> (gram, Scale.kilo)
    - 'mL' -> (liter, Scale.milli)
    - 'min' -> (minute, Scale.one)  # priority alias, not milli-inch
    - 'mcg' -> (gram, Scale.micro)  # medical convention for microgram

    Returns:
        Tuple of (unit, scale).

    Raises:
        UnknownUnitError: If the unit cannot be resolved.
    """
    # System override: a curated UnitSystem can shadow factor names.
    # Only accept Unit values here — UnitProduct entries don't fit the
    # (Unit, Scale) shape expected by the composite parser.
    if system is not None:
        sys_unit = system.units.get(s)
        if isinstance(sys_unit, Unit):
            return sys_unit, Scale.one

    # Check graph-local registry first (if in using_graph() context)
    graph = _get_parsing_graph()
    if graph is not None:
        result = graph.resolve_unit(s)
        if result is not None:
            return result

    # Check priority scaled aliases first (e.g., "mcg" -> microgram)
    if s in _PRIORITY_SCALED_ALIASES:
        return _PRIORITY_SCALED_ALIASES[s]

    # Check priority aliases (prevents "min" -> milli-inch)
    if s in _PRIORITY_ALIASES:
        if s in _UNIT_REGISTRY_CASE_SENSITIVE:
            return _UNIT_REGISTRY_CASE_SENSITIVE[s], Scale.one
        s_lower = s.lower()
        if s_lower in _UNIT_REGISTRY:
            return _UNIT_REGISTRY[s_lower], Scale.one

    # Try scale prefix + unit (prioritize decomposition).
    # Only case-sensitive matching for remainder (e.g., "fT" = femto-tesla, "ft" = foot).
    #
    # The remainder is looked up in both the graph-local registry (when in a
    # using_graph context) and the global registry, so session-defined units
    # participate in prefix decomposition with the same scalability semantics
    # as built-ins.
    #
    # When a prefix decomposition matches but the base unit is marked
    # non-scalable (Unit.scalable == False), the match is *recorded* rather
    # than returned. This lets a subsequent shorter prefix that lands on a
    # scalable base still win (the parser stays greedy on scalable matches),
    # while preserving the diagnostic so an unambiguous non-scalable
    # decomposition surfaces as NonScalableError rather than the generic
    # UnknownUnitError. NonScalableError is-a UnknownUnitError so existing
    # exception handlers continue to work.
    non_scalable_match: Tuple[Unit, str] | None = None
    for prefix in _SCALE_PREFIXES_SORTED:
        if s.startswith(prefix) and len(s) > len(prefix):
            remainder = s[len(prefix):]
            base_unit = _resolve_base_for_prefix(remainder, graph=graph)
            if base_unit is not None:
                if base_unit.scalable:
                    return base_unit, _SCALE_PREFIXES[prefix]
                if non_scalable_match is None:
                    # Record the first (longest-prefix) non-scalable hit;
                    # keep looping in case a shorter prefix yields a scalable
                    # match against a different base.
                    non_scalable_match = (base_unit, prefix)

    # Fall back to exact case-sensitive match (for aliases like 'L', 'B', 'm')
    if s in _UNIT_REGISTRY_CASE_SENSITIVE:
        return _UNIT_REGISTRY_CASE_SENSITIVE[s], Scale.one

    # Fall back to case-insensitive match
    s_lower = s.lower()
    if s_lower in _UNIT_REGISTRY:
        return _UNIT_REGISTRY[s_lower], Scale.one

    # No other interpretation succeeded. If we recorded a non-scalable
    # decomposition, surface it specifically; otherwise the input is just
    # unknown.
    if non_scalable_match is not None:
        base_unit, prefix = non_scalable_match
        raise NonScalableError(s, base_unit, prefix)

    raise UnknownUnitError(s)


def _parse_composite(
    s: str,
    *,
    system: "UnitSystem | None" = None,
) -> UnitProduct:
    """
    Parse composite unit string into UnitProduct using recursive descent.

    Accepts both Unicode and ASCII notation:
    - Unicode: 'm/s²', 'kg·m/s²', 'N·m', 'W/(m²*K)'
    - ASCII:  'm/s^2', 'kg*m/s^2', 'N*m', 'W/(m^2*K)'

    Supports:
    - Parentheses: `W/(m²*K)`, `(kg*m)/(s^2)`
    - Chained division: `mg/kg/d`
    - Unicode superscripts: `⁰¹²³⁴⁵⁶⁷⁸⁹⁻`
    - ASCII exponents: `^2`, `^-1`

    When ``system`` is supplied, factor lookups consult ``system.units``
    before the global registry, so expressions like ``"USD/year"`` resolve
    against a curated registry without mutating module globals.

    Returns:
        UnitProduct representing the parsed composite unit.

    Raises:
        ParseError: If the expression is malformed (e.g., unbalanced parens).
        UnknownUnitError: If a unit name cannot be resolved.
    """
    if system is None:
        return parse_unit_expression(s, _lookup_factor, UnitFactor, UnitProduct)

    def _system_lookup(token: str) -> Tuple[Unit, Scale]:
        return _lookup_factor(token, system=system)

    return parse_unit_expression(s, _system_lookup, UnitFactor, UnitProduct)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse_unit(
    name: str,
    *,
    system: "UnitSystem | None" = None,
) -> Union[Unit, UnitProduct]:
    """
    Parse a unit string into a :class:`Unit` or :class:`UnitProduct`.

    Handles:
    - Plain units: "meter", "m", "second", "s"
    - Scaled units: "km", "mL", "kg"
    - Composite units: "m/s", "kg*m/s^2", "N·m"
    - Exponents: "m²", "m^2", "s⁻¹", "s^-1"

    Args:
        name: Unit string to parse.
        system: Optional :class:`~ucon.system.UnitSystem`. When provided,
            ``system.units`` is consulted before the module-level registry,
            so a system can shadow or restrict the name space without
            mutating globals. Unknown names then fall back to the global
            registry to keep prefix decomposition (``"km"``) working.

    Returns:
        Unit for simple unscaled units, UnitProduct for scaled or composite.

    Raises:
        UnknownUnitError: If the unit cannot be resolved.

    Examples:
        >>> parse_unit("meter")
        <Unit m>
        >>> parse_unit("km")
        <UnitProduct km>
        >>> parse_unit("m/s^2")
        <UnitProduct m/s²>

    See Also:
        :func:`~ucon.dimension.parse_dimension` — sibling for dimension strings.
    """
    if not name or not name.strip():
        raise UnknownUnitError(name if name else "")

    name = name.strip()

    # System override: when a UnitSystem is supplied, a direct match in
    # ``system.units`` short-circuits the rest of the lookup. This lets
    # callers thread a curated registry (e.g. CGS-only) through entry
    # points without mutating module globals.
    if system is not None:
        sys_unit = system.units.get(name)
        if sys_unit is not None:
            return sys_unit

    # Verbatim alias check (runs BEFORE composite detection).
    # Aliases registered with operator-like characters (e.g. "Gy(RBE)",
    # "Sv(RBE)") resolve as a single token rather than being tokenised
    # on the parenthesis. Case-sensitive only — these labels carry
    # convention-specific casing.
    if name in _VERBATIM_ALIASES:
        return _VERBATIM_ALIASES[name]

    # Check for composite (has operators or parentheses)
    # Note: · (U+00B7 middle dot) and ⋅ (U+22C5 dot operator) are both multiplication
    if '/' in name or '·' in name or '⋅' in name or '*' in name or '(' in name:
        return _parse_composite(name, system=system)

    # Check for exponent
    base_str, exp = _parse_exponent(name)
    if exp != 1.0:
        unit, scale = _lookup_factor(base_str, system=system)
        return UnitProduct({UnitFactor(unit, scale): exp})

    # Simple unit or scaled unit
    unit, scale = _lookup_factor(name, system=system)
    if scale == Scale.one:
        return unit
    else:
        return UnitProduct({UnitFactor(unit, scale): 1})


def get_unit_by_name(name: str) -> Union[Unit, UnitProduct]:
    """Deprecated alias for :func:`parse_unit`.

    .. deprecated:: 1.7.0
        Use :func:`parse_unit` instead. ``get_unit_by_name`` will be
        removed in v2.0.
    """
    warnings.warn(
        "get_unit_by_name() is deprecated; use parse_unit() instead. "
        "It will be removed in ucon v2.0.",
        DeprecationWarning,
        stacklevel=2,
    )
    return parse_unit(name)


__all__ = [
    'parse_unit',
    'get_unit_by_name',
    'register_unit',
    'register_priority_scaled_alias',
]
