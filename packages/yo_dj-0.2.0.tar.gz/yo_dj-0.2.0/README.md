# 🎧 YO-Dj

> A lightning-fast CLI — scaffold apps, wire settings, inspect your project, and go from zero to Dockerfile in one command.

i'm just playing around nothing crazy ...
---

## Installation

```bash
pip install yo-dj
```

One global install. Works in every Django project.

---

## What's new in v0.2

| Category | What you can do now |
|---|---|
| **Scaffold** | Create projects, apps, views, models, URLs, full DRF API endpoints |
| **Config** | Edit settings, split into base/dev/prod, manage `.env`, add CORS & Celery |
| **Info** | List all URL patterns, installed apps, and models at a glance |
| **Env** | Create virtualenvs, install + track packages, generate `Dockerfile` |
| **Database** | Reset, seed, dump, and restore fixtures |
| **Shortcuts** | All original shortcuts still work — nothing broke |

---

## Shortcuts (original, still here)

```bash
yo serv          # python manage.py runserver
yo mkm           # python manage.py makemigrations
yo mg            # python manage.py migrate
yo su            # python manage.py createsuperuser
yo sh            # python manage.py shell
yo p mkm         # also works
yo dj mg         # also works
```

---

## Scaffold — create things fast

### New project

```bash
yo new myproject
```

Creates a Django project folder with a pre-filled `.gitignore` and `README.md`.

### New app (auto-registered in INSTALLED_APPS)

```bash
yo create app blog
```

Runs `startapp` **and** automatically adds `'blog'` to `INSTALLED_APPS` in your `settings.py`.

### Create any file with the right template

```bash
yo create file blog/templates/blog/list.html
yo create file blog/utils.py
yo create file .env
```

HTML files get `{% extends %}` stubs. Python files get a comment header. `.env` files get sane defaults.

### Add a class-based view

```bash
yo add view PostListView blog
```

Appends a ready-to-go `View` subclass to `blog/views.py`. Import is auto-added.

### Add a model stub

```bash
yo add model Post blog
```

Appends a model with `created_at` / `updated_at` and `__str__` to `blog/models.py`.

```bash
yo mkm && yo mg    # always next step
```

### Add a URL pattern

```bash
yo add url posts/ PostListView blog
```

Inserts `path('posts/', views.PostListView.as_view(), ...)` into the right `urls.py`.

### Scaffold a full DRF API endpoint

```bash
yo add api Post blog
```

Generates in one shot:
- `serializers.py` with `PostSerializer`
- `PostViewSet` in `views.py`
- Router-wired `urls.py`

---

## Config — wire your project

### Add a settings variable

```bash
yo add settings DEFAULT_FROM_EMAIL=hello@mysite.com
yo add settings MAX_UPLOAD_SIZE=5242880
yo add settings USE_S3=True
```

Type inference: booleans stay booleans, integers stay integers, strings get quotes.

### Split settings into base / dev / prod

```bash
yo split settings
```

Converts your monolithic `settings.py` into:

```
settings/
  __init__.py
  base.py    ← original settings
  dev.py     ← DEBUG=True, wildcard hosts
  prod.py    ← SECRET_KEY from env, SECURE_SSL_REDIRECT, PostgreSQL stub
```

### Write to .env

```bash
yo set env SECRET_KEY=supersecretkey123
yo set env DATABASE_URL=postgres://user:pass@localhost/mydb
```

Creates or updates `.env`. Existing keys are overwritten, new ones are appended.

### Add CORS headers

```bash
yo add cors
```

Runs `pip install django-cors-headers`, adds it to `INSTALLED_APPS` and `MIDDLEWARE`, appends `CORS_ALLOW_ALL_ORIGINS = True`.

### Add Celery

```bash
yo add celery
```

Scaffolds `<project>/celery.py`, wires it into `__init__.py`, and appends Redis broker settings to `settings.py`.

---

## Info — inspect your project

```bash
yo urls              # list every URL pattern and its view
yo apps              # list all installed apps
yo models            # list all models across all apps
yo models blog       # list only models in the blog app
yo check             # run Django system checks
```

---

## Env — virtualenv & dependencies

```bash
yo venv              # create ./venv
yo venv .myenv       # create with custom name

yo install django djangorestframework  # pip install + add to requirements.txt
yo install                             # pip install -r requirements.txt

yo freeze            # pip freeze > requirements.txt

yo docker init       # scaffold Dockerfile + docker-compose.yml (with postgres)
```

---

## Database

```bash
yo db reset          # flush DB + migrate (with confirmation prompt)
yo db seed data.json # loaddata from a fixture
yo db dump           # dumpdata → fixtures/dump.json
yo db dump blog      # dump only the blog app
yo db restore fixtures/dump.json
```

---

## Passthrough

Any command that isn't recognized falls through to `manage.py`:

```bash
yo collectstatic
yo createsuperuser
yo test blog
yo shell_plus        # works if django-extensions is installed
```

---

## Tips

- **`yo` finds `manage.py` automatically** — you don't need to be in the exact root directory, it walks up the tree.
- **App detection is automatic** — most `yo add` commands detect your app directory. Pass the app name as the last argument to be explicit.
- **Color output** — all output is colored in terminals that support ANSI. Piping strips colors automatically.

---

## Contributing

PRs are welcome. Want to add new slang? New scaffold templates? New boilerplate integrations?

1. Fork the repo
2. `git checkout -b feature/my-feature`
3. `git commit -m 'Add my feature'`
4. Open a Pull Request

---

## License

MIT — made with ❤️ by **migisho**, extended by the community.