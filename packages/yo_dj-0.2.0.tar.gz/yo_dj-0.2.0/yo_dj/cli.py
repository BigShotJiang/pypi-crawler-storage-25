import sys
import subprocess
import os
import shutil
from pathlib import Path

# ──────────────────────────────────────────────
#  Colour helpers (no deps, just ANSI)
# ──────────────────────────────────────────────

def _c(text, code): return f"\033[{code}m{text}\033[0m" if sys.stdout.isatty() else text

def green(t):  return _c(t, "32")
def yellow(t): return _c(t, "33")
def cyan(t):   return _c(t, "36")
def bold(t):   return _c(t, "1")
def dim(t):    return _c(t, "2")
def red(t):    return _c(t, "31")


# ──────────────────────────────────────────────
#  Help
# ──────────────────────────────────────────────

HELP = f"""
{bold("🎧  YO-Dj")}  — the full Django project CLI

{bold(cyan("SHORTCUTS"))} (original, still work)
  yo serv / p serv / dj serv   → runserver
  yo mkm  / p mkm  / dj mkm   → makemigrations
  yo mg   / p mg   / dj mg    → migrate
  yo su                        → createsuperuser
  yo sh                        → shell

{bold(cyan("SCAFFOLD"))}  — create files & boilerplate
  yo new <name>                create a new Django project folder
  yo create app <name>         startapp + register in INSTALLED_APPS
  yo create file <path>        create any file with the right template
  yo add view <name> [app]     append a class-based view to views.py
  yo add model <name> [app]    append a model stub to models.py
  yo add url <path> <view>     append a URL pattern to urls.py
  yo add api <name> [app]      scaffold a DRF ViewSet + serializer

{bold(cyan("CONFIG"))}    — settings & project wiring
  yo add settings <key=value>  append a variable to settings.py
  yo split settings            split settings → base / dev / prod
  yo set env <KEY=value>       write/update a .env file entry
  yo add cors                  install & configure django-cors-headers
  yo add celery                scaffold celery.py + settings stubs

{bold(cyan("INFO"))}      — inspect your project
  yo urls                      list all URL patterns in the project
  yo apps                      list all installed apps
  yo models [app]              list all models (or models in one app)
  yo check                     run Django system checks

{bold(cyan("ENV"))}       — virtual env & dependencies
  yo venv [name]               create a virtualenv
  yo install [pkg ...]         pip install + add to requirements.txt
  yo freeze                    pip freeze → requirements.txt
  yo docker init               scaffold a Dockerfile + docker-compose.yml

{bold(cyan("DATABASE"))}
  yo db reset                  flush DB + re-run all migrations
  yo db seed <file>            load a JSON fixture
  yo db dump [app]             dumpdata → fixtures/
  yo db restore <file>         loaddata from a fixture file

{bold(cyan("PASSTHROUGH"))}
  yo <anything>                falls through to: python manage.py <anything>

"""


# ──────────────────────────────────────────────
#  Utilities
# ──────────────────────────────────────────────

def find_manage():
    """Walk upward from cwd to find manage.py."""
    p = Path.cwd()
    for _ in range(5):
        if (p / "manage.py").exists():
            return p
        p = p.parent
    return None


def run_manage(*args):
    """Run python manage.py <args> and exit on failure."""
    root = find_manage()
    if root is None:
        print(red("Error: manage.py not found. Are you in a Django project?"))
        sys.exit(1)
    cmd = [sys.executable, str(root / "manage.py")] + list(args)
    try:
        subprocess.run(cmd, check=True, cwd=root)
    except KeyboardInterrupt:
        sys.exit(0)
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)


def find_settings():
    """Return Path to settings.py by scanning project root."""
    root = find_manage()
    if root is None:
        return None
    for p in root.rglob("settings.py"):
        if ".tox" not in str(p) and "venv" not in str(p):
            return p
    return None


def find_app_dir(app_name):
    root = find_manage()
    if root is None:
        return None
    for d in root.iterdir():
        if d.is_dir() and d.name == app_name and (d / "models.py").exists():
            return d
    return None


def confirm(prompt):
    ans = input(f"{yellow('?')} {prompt} [y/N] ").strip().lower()
    return ans in ("y", "yes")


def append_to_file(path: Path, content: str):
    with open(path, "a") as f:
        f.write("\n" + content + "\n")
    print(green(f"  ✔  appended to {path.name}"))


# ──────────────────────────────────────────────
#  SHORTCUT TABLE (original)
# ──────────────────────────────────────────────

SHORTCUTS = {
    "p mkm":    ["makemigrations"],
    "dj mkm":   ["makemigrations"],
    "dj serv":  ["runserver"],
    "create su": ["createsuperuser"],
    "p mg":     ["migrate"],
    "dj mg":    ["migrate"],
    "p serv":   ["runserver"],
    "serv":     ["runserver"],
    "mkm":      ["makemigrations"],
    "mg":       ["migrate"],
    "su":       ["createsuperuser"],
    "sh":       ["shell"],
}


# ──────────────────────────────────────────────
#  SCAFFOLD commands
# ──────────────────────────────────────────────

def cmd_new(args):
    if not args:
        print(red("Usage: yo new <project-name>"))
        return
    name = args[0]
    dest = Path.cwd() / name
    if dest.exists():
        print(red(f"Directory '{name}' already exists."))
        return
    print(cyan(f"Creating Django project: {name}"))
    subprocess.run([sys.executable, "-m", "django", "startproject", name], check=True)

    # Add a .gitignore and a minimal README
    gitignore = dest / ".gitignore"
    gitignore.write_text(
        "__pycache__/\n*.pyc\n*.pyo\n*.pyd\n.env\nvenv/\n.venv/\n"
        "*.sqlite3\n.DS_Store\ndist/\nbuild/\n*.egg-info/\n"
    )
    readme = dest / "README.md"
    readme.write_text(f"# {name}\n\nA Django project.\n\n## Quick start\n\n```bash\nyo serv\n```\n")

    print(green(f"\n  ✔  Project '{name}' ready."))
    print(dim(f"     cd {name} && yo serv"))


def cmd_create(args):
    if not args:
        print(red("Usage: yo create app <name> | yo create file <path>"))
        return

    sub = args[0].lower()

    if sub == "app":
        if len(args) < 2:
            print(red("Usage: yo create app <appname>"))
            return
        app_name = args[1]
        root = find_manage()
        if root is None:
            print(red("manage.py not found."))
            return
        subprocess.run([sys.executable, str(root / "manage.py"), "startapp", app_name],
                       check=True, cwd=root)
        # Auto-register in settings
        settings_path = find_settings()
        if settings_path:
            text = settings_path.read_text()
            if "INSTALLED_APPS" in text and app_name not in text:
                new_text = text.replace(
                    "INSTALLED_APPS = [",
                    f"INSTALLED_APPS = [\n    '{app_name}',"
                )
                settings_path.write_text(new_text)
                print(green(f"  ✔  '{app_name}' registered in INSTALLED_APPS"))
        print(green(f"  ✔  App '{app_name}' created."))

    elif sub == "file":
        if len(args) < 2:
            print(red("Usage: yo create file <relative/path/to/file.py>"))
            return
        target = Path(args[1])
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            print(yellow(f"  ⚠  {target} already exists — skipping."))
            return
        ext = target.suffix

        templates = {
            ".py":   f"# {target.name}\n",
            ".html": "{% extends 'base.html' %}\n{% block content %}\n\n{% endblock %}\n",
            ".css":  f"/* {target.name} */\n",
            ".js":   f"// {target.name}\n",
            ".env":  "# Environment variables\nDEBUG=True\nSECRET_KEY=changeme\n",
        }
        target.write_text(templates.get(ext, f"# {target.name}\n"))
        print(green(f"  ✔  Created {target}"))

    else:
        print(red(f"Unknown sub-command: yo create {sub}"))


# ──────────────────────────────────────────────
#  ADD commands
# ──────────────────────────────────────────────

def cmd_add(args):
    if not args:
        print(red("Usage: yo add view|model|url|api|settings|cors|celery ..."))
        return

    sub = args[0].lower()
    rest = args[1:]

    if sub == "view":
        _add_view(rest)
    elif sub == "model":
        _add_model(rest)
    elif sub == "url":
        _add_url(rest)
    elif sub == "api":
        _add_api(rest)
    elif sub == "settings":
        _add_settings(rest)
    elif sub == "cors":
        _add_cors()
    elif sub == "celery":
        _add_celery()
    else:
        print(red(f"Unknown: yo add {sub}"))


def _resolve_app(rest, require_name=True):
    """Return (name, app_dir) from args like ['MyThing', 'myapp']."""
    name = rest[0] if rest else None
    app_hint = rest[1] if len(rest) > 1 else None
    if require_name and not name:
        return None, None

    root = find_manage()
    if root is None:
        print(red("manage.py not found."))
        return name, None

    if app_hint:
        app_dir = find_app_dir(app_hint)
    else:
        # pick the first app dir that isn't the project package
        candidates = [
            d for d in root.iterdir()
            if d.is_dir() and (d / "models.py").exists()
        ]
        app_dir = candidates[0] if candidates else None

    if app_dir is None:
        print(red("Could not find a Django app directory. Pass the app name as second arg."))
    return name, app_dir


def _add_view(rest):
    name, app_dir = _resolve_app(rest)
    if not name or not app_dir:
        print(red("Usage: yo add view <ClassName> [app]"))
        return
    views_py = app_dir / "views.py"
    snippet = (
        f"\nclass {name}(View):\n"
        f"    def get(self, request, *args, **kwargs):\n"
        f"        return render(request, '{app_dir.name}/{name.lower()}.html', {{}})\n"
    )
    # Ensure View is imported
    text = views_py.read_text() if views_py.exists() else ""
    if "from django.views import View" not in text:
        snippet = "from django.views import View\nfrom django.shortcuts import render\n" + snippet
    append_to_file(views_py, snippet)


def _add_model(rest):
    name, app_dir = _resolve_app(rest)
    if not name or not app_dir:
        print(red("Usage: yo add model <ModelName> [app]"))
        return
    models_py = app_dir / "models.py"
    snippet = (
        f"\nclass {name}(models.Model):\n"
        f"    created_at = models.DateTimeField(auto_now_add=True)\n"
        f"    updated_at = models.DateTimeField(auto_now=True)\n\n"
        f"    def __str__(self):\n"
        f"        return f'{name} {{self.pk}}'\n\n"
        f"    class Meta:\n"
        f"        verbose_name_plural = '{name}s'\n"
    )
    text = models_py.read_text() if models_py.exists() else ""
    if "from django.db import models" not in text:
        snippet = "from django.db import models\n" + snippet
    append_to_file(models_py, snippet)
    print(dim(f"     Don't forget: yo mkm && yo mg"))


def _add_url(rest):
    if len(rest) < 2:
        print(red("Usage: yo add url <path> <ViewName> [app]"))
        return
    url_path, view_name = rest[0], rest[1]
    app_hint = rest[2] if len(rest) > 2 else None

    root = find_manage()
    if root is None:
        return

    # Prefer app's urls.py, fall back to project urls.py
    app_dir = find_app_dir(app_hint) if app_hint else None
    if app_dir:
        urls_py = app_dir / "urls.py"
        if not urls_py.exists():
            urls_py.write_text(
                "from django.urls import path\nfrom . import views\n\nurlpatterns = [\n]\n"
            )
    else:
        candidates = list(root.rglob("urls.py"))
        urls_py = candidates[0] if candidates else root / "urls.py"

    text = urls_py.read_text() if urls_py.exists() else ""
    new_pattern = f"    path('{url_path}', views.{view_name}.as_view(), name='{view_name.lower()}'),"
    if "urlpatterns = [" in text:
        new_text = text.replace("urlpatterns = [", f"urlpatterns = [\n{new_pattern}")
        urls_py.write_text(new_text)
        print(green(f"  ✔  Added URL /{url_path} → {view_name}"))
    else:
        append_to_file(urls_py, f"\nurlpatterns = [\n{new_pattern}\n]\n")


def _add_api(rest):
    name, app_dir = _resolve_app(rest)
    if not name or not app_dir:
        print(red("Usage: yo add api <ModelName> [app]"))
        return

    # serializers.py
    ser_py = app_dir / "serializers.py"
    ser_snippet = (
        f"from rest_framework import serializers\n"
        f"from .models import {name}\n\n"
        f"class {name}Serializer(serializers.ModelSerializer):\n"
        f"    class Meta:\n"
        f"        model = {name}\n"
        f"        fields = '__all__'\n"
    )
    if not ser_py.exists():
        ser_py.write_text(ser_snippet)
        print(green(f"  ✔  Created serializers.py"))
    else:
        append_to_file(ser_py, ser_snippet)

    # views.py — ViewSet
    views_py = app_dir / "views.py"
    view_snippet = (
        f"from rest_framework import viewsets\n"
        f"from .models import {name}\n"
        f"from .serializers import {name}Serializer\n\n"
        f"class {name}ViewSet(viewsets.ModelViewSet):\n"
        f"    queryset = {name}.objects.all()\n"
        f"    serializer_class = {name}Serializer\n"
    )
    append_to_file(views_py, view_snippet)

    # urls.py — router
    urls_py = app_dir / "urls.py"
    router_snippet = (
        f"from rest_framework.routers import DefaultRouter\n"
        f"from .views import {name}ViewSet\n\n"
        f"router = DefaultRouter()\n"
        f"router.register(r'{name.lower()}s', {name}ViewSet)\n"
        f"urlpatterns = router.urls\n"
    )
    if not urls_py.exists():
        urls_py.write_text(router_snippet)
        print(green(f"  ✔  Created urls.py with router"))
    else:
        append_to_file(urls_py, router_snippet)

    print(green(f"\n  ✔  DRF scaffold for {name} done."))
    print(dim(f"     Add '{app_dir.name}.urls' to your project urlconf."))


def _add_settings(rest):
    if not rest:
        print(red("Usage: yo add settings KEY=value  or  yo add settings KEY"))
        return
    settings_path = find_settings()
    if not settings_path:
        print(red("settings.py not found."))
        return
    entry = " ".join(rest)
    if "=" in entry:
        key, val = entry.split("=", 1)
        # Try to infer type
        if val.lower() in ("true", "false"):
            line = f"{key.strip()} = {val.strip().capitalize()}"
        elif val.isdigit():
            line = f"{key.strip()} = {val.strip()}"
        else:
            line = f"{key.strip()} = '{val.strip()}'"
    else:
        line = f"{entry.strip()} = None  # TODO"
    append_to_file(settings_path, line)


def _split_settings():
    settings_path = find_settings()
    if not settings_path:
        print(red("settings.py not found."))
        return
    root = settings_path.parent
    settings_dir = root / "settings"
    if settings_dir.exists():
        print(yellow("  ⚠  settings/ directory already exists."))
        return
    if not confirm("Split settings.py into base/dev/prod?"):
        return

    settings_dir.mkdir()
    original = settings_path.read_text()

    (settings_dir / "__init__.py").write_text("")
    (settings_dir / "base.py").write_text(
        f"# Base settings — shared across all environments\n\n{original}"
    )
    (settings_dir / "dev.py").write_text(
        "from .base import *\n\nDEBUG = True\nALLOWED_HOSTS = ['*']\n"
        "# Add dev-only packages here\n"
    )
    (settings_dir / "prod.py").write_text(
        "from .base import *\n\nDEBUG = False\n"
        "ALLOWED_HOSTS = []  # TODO: add your domain\n"
        "SECRET_KEY = os.environ['SECRET_KEY']\n"
        "DATABASES = {'default': {'ENGINE': 'django.db.backends.postgresql'}}\n"
        "SECURE_SSL_REDIRECT = True\n"
        "SESSION_COOKIE_SECURE = True\n"
        "CSRF_COOKIE_SECURE = True\n"
    )
    settings_path.rename(root / "settings.py.bak")
    print(green("  ✔  Settings split → settings/base.py + dev.py + prod.py"))
    print(dim("     Run with: --settings=<pkg>.settings.dev"))


def _add_cors():
    print(cyan("Installing django-cors-headers ..."))
    subprocess.run([sys.executable, "-m", "pip", "install", "django-cors-headers"], check=True)
    settings_path = find_settings()
    if settings_path:
        text = settings_path.read_text()
        if "corsheaders" not in text:
            new_text = text.replace(
                "INSTALLED_APPS = [",
                "INSTALLED_APPS = [\n    'corsheaders',"
            ).replace(
                "MIDDLEWARE = [",
                "MIDDLEWARE = [\n    'corsheaders.middleware.CorsMiddleware',"
            )
            settings_path.write_text(new_text)
            append_to_file(settings_path, "CORS_ALLOW_ALL_ORIGINS = True  # TODO: restrict in production")
    print(green("  ✔  django-cors-headers installed & configured."))


def _add_celery():
    root = find_manage()
    if root is None:
        return
    # Find project package (the one with settings.py)
    settings_path = find_settings()
    pkg = settings_path.parent.name if settings_path else root.name

    celery_file = root / pkg / "celery.py"
    celery_file.write_text(
        f"import os\nfrom celery import Celery\n\n"
        f"os.environ.setdefault('DJANGO_SETTINGS_MODULE', '{pkg}.settings')\n\n"
        f"app = Celery('{pkg}')\n"
        f"app.config_from_object('django.conf:settings', namespace='CELERY')\n"
        f"app.autodiscover_tasks()\n\n"
        f"@app.task(bind=True, ignore_result=True)\n"
        f"def debug_task(self):\n"
        f"    print(f'Request: {{self.request!r}}')\n"
    )

    init_file = root / pkg / "__init__.py"
    init_text = init_file.read_text() if init_file.exists() else ""
    if "celery" not in init_text:
        init_file.write_text(
            "from .celery import app as celery_app\n__all__ = ('celery_app',)\n" + init_text
        )

    settings_path = find_settings()
    if settings_path:
        append_to_file(settings_path,
            "# Celery\nCELERY_BROKER_URL = 'redis://localhost:6379/0'\n"
            "CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'\n"
            "CELERY_ACCEPT_CONTENT = ['json']\n"
            "CELERY_TASK_SERIALIZER = 'json'\n"
        )

    print(green(f"  ✔  Celery scaffolded at {pkg}/celery.py"))
    print(dim("     pip install celery redis  →  celery -A " + pkg + " worker -l info"))


# ──────────────────────────────────────────────
#  INFO commands
# ──────────────────────────────────────────────

def cmd_urls():
    run_manage("show_urls") if shutil.which("django-admin") else run_manage("shell", "-c",
        "from django.urls import get_resolver\n"
        "def show(r, prefix=''):\n"
        "    for p in r.url_patterns:\n"
        "        full = prefix+str(p.pattern)\n"
        "        if hasattr(p, 'url_patterns'):\n"
        "            show(p, full)\n"
        "        else:\n"
        "            print(full, '→', getattr(p.callback,'__name__','?'))\n"
        "show(get_resolver())"
    )


def cmd_apps():
    run_manage("shell", "-c",
        "import django; django.setup()\n"
        "from django.apps import apps\n"
        "[print(f'  {a.name}') for a in apps.get_app_configs()]"
    )


def cmd_models(args):
    app = args[0] if args else None
    code = (
        "import django; django.setup()\n"
        "from django.apps import apps\n"
        "for app in apps.get_app_configs():\n"
        f"    {'if app.name != \"' + app + '\": continue' if app else ''}\n"
        "    ms = list(app.get_models())\n"
        "    if ms: print(f'  [{app.name}]')\n"
        "    [print(f'    {m.__name__}') for m in ms]\n"
    )
    run_manage("shell", "-c", code)


def cmd_check():
    run_manage("check")


# ──────────────────────────────────────────────
#  ENV commands
# ──────────────────────────────────────────────

def cmd_venv(args):
    name = args[0] if args else "venv"
    print(cyan(f"Creating virtualenv: {name}"))
    subprocess.run([sys.executable, "-m", "venv", name], check=True)
    print(green(f"  ✔  virtualenv '{name}' created."))
    activate = f"source {name}/bin/activate" if os.name != "nt" else f"{name}\\Scripts\\activate"
    print(dim(f"     Activate with: {activate}"))


def cmd_install(args):
    if not args:
        # install from requirements.txt
        req = Path("requirements.txt")
        if req.exists():
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
        else:
            print(red("No packages given and no requirements.txt found."))
        return
    subprocess.run([sys.executable, "-m", "pip", "install"] + args, check=True)
    # append to requirements.txt
    req = Path("requirements.txt")
    existing = req.read_text() if req.exists() else ""
    with open(req, "a") as f:
        for pkg in args:
            if pkg not in existing:
                f.write(pkg + "\n")
    print(green(f"  ✔  Installed {', '.join(args)} and updated requirements.txt"))


def cmd_freeze():
    result = subprocess.run([sys.executable, "-m", "pip", "freeze"],
                            capture_output=True, text=True)
    Path("requirements.txt").write_text(result.stdout)
    print(green("  ✔  requirements.txt updated."))


def cmd_docker_init():
    root = find_manage()
    if root is None:
        return
    settings_path = find_settings()
    pkg = settings_path.parent.name if settings_path else "myproject"

    dockerfile = root / "Dockerfile"
    if not dockerfile.exists():
        dockerfile.write_text(
            "FROM python:3.12-slim\n\n"
            "ENV PYTHONDONTWRITEBYTECODE=1 \\\n"
            "    PYTHONUNBUFFERED=1\n\n"
            "WORKDIR /app\n\n"
            "COPY requirements.txt .\n"
            "RUN pip install --no-cache-dir -r requirements.txt\n\n"
            "COPY . .\n\n"
            f'CMD ["gunicorn", "{pkg}.wsgi:application", "--bind", "0.0.0.0:8000"]\n'
        )
        print(green("  ✔  Dockerfile created"))

    compose = root / "docker-compose.yml"
    if not compose.exists():
        compose.write_text(
            f"version: '3.9'\n\nservices:\n"
            f"  web:\n"
            f"    build: .\n"
            f"    command: python manage.py runserver 0.0.0.0:8000\n"
            f"    volumes:\n      - .:/app\n"
            f"    ports:\n      - '8000:8000'\n"
            f"    env_file:\n      - .env\n"
            f"    depends_on:\n      - db\n\n"
            f"  db:\n"
            f"    image: postgres:16\n"
            f"    environment:\n"
            f"      POSTGRES_DB: {pkg}_db\n"
            f"      POSTGRES_USER: {pkg}_user\n"
            f"      POSTGRES_PASSWORD: changeme\n"
            f"    volumes:\n      - pgdata:/var/lib/postgresql/data\n\n"
            f"volumes:\n  pgdata:\n"
        )
        print(green("  ✔  docker-compose.yml created"))


# ──────────────────────────────────────────────
#  SET commands
# ──────────────────────────────────────────────

def cmd_set(args):
    if not args:
        print(red("Usage: yo set env KEY=value"))
        return
    sub = args[0].lower()
    if sub == "env":
        if len(args) < 2 or "=" not in args[1]:
            print(red("Usage: yo set env KEY=value"))
            return
        key, val = args[1].split("=", 1)
        env_file = Path(".env")
        lines = env_file.read_text().splitlines() if env_file.exists() else []
        updated = False
        for i, line in enumerate(lines):
            if line.startswith(key + "="):
                lines[i] = f"{key}={val}"
                updated = True
                break
        if not updated:
            lines.append(f"{key}={val}")
        env_file.write_text("\n".join(lines) + "\n")
        action = "Updated" if updated else "Added"
        print(green(f"  ✔  {action} {key} in .env"))
    else:
        print(red(f"Unknown: yo set {sub}"))


# ──────────────────────────────────────────────
#  SPLIT command
# ──────────────────────────────────────────────

def cmd_split(args):
    if args and args[0].lower() == "settings":
        _split_settings()
    else:
        print(red("Usage: yo split settings"))


# ──────────────────────────────────────────────
#  DATABASE commands
# ──────────────────────────────────────────────

def cmd_db(args):
    if not args:
        print(red("Usage: yo db reset | seed <file> | dump [app] | restore <file>"))
        return
    sub = args[0].lower()
    rest = args[1:]

    if sub == "reset":
        if not confirm("This will FLUSH the database. Continue?"):
            return
        run_manage("flush", "--no-input")
        run_manage("migrate")
        print(green("  ✔  Database reset complete."))

    elif sub == "seed":
        if not rest:
            print(red("Usage: yo db seed <fixture.json>"))
            return
        run_manage("loaddata", rest[0])

    elif sub == "dump":
        root = find_manage()
        if root is None:
            return
        fixtures_dir = root / "fixtures"
        fixtures_dir.mkdir(exist_ok=True)
        out = fixtures_dir / "dump.json"
        cmd = [sys.executable, str(root / "manage.py"), "dumpdata",
               "--natural-foreign", "--natural-primary",
               "--indent", "2", "-o", str(out)]
        if rest:
            cmd.insert(3, rest[0])  # app label
        subprocess.run(cmd, check=True)
        print(green(f"  ✔  Dumped to {out}"))

    elif sub == "restore":
        if not rest:
            print(red("Usage: yo db restore <fixture.json>"))
            return
        run_manage("loaddata", rest[0])

    else:
        print(red(f"Unknown: yo db {sub}"))


# ──────────────────────────────────────────────
#  NEW (top-level alias)
# ──────────────────────────────────────────────

def cmd_new_project(args):
    cmd_new(args)


# ──────────────────────────────────────────────
#  MAIN ROUTER
# ──────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print(HELP)
        return

    raw_args = sys.argv[1:]
    cmd1 = raw_args[0].lower()
    rest = raw_args[1:]

    # Help
    if cmd1 in ("help", "--help", "-h"):
        print(HELP)
        return

    # New project
    if cmd1 == "new":
        cmd_new(rest)
        return

    # Create
    if cmd1 == "create" and rest and rest[0].lower() in ("app", "file"):
        cmd_create(rest)
        return

    # Add
    if cmd1 == "add":
        cmd_add(rest)
        return

    # Split
    if cmd1 == "split":
        cmd_split(rest)
        return

    # Set
    if cmd1 == "set":
        cmd_set(rest)
        return

    # Info commands
    if cmd1 == "urls":
        cmd_urls()
        return
    if cmd1 == "apps":
        cmd_apps()
        return
    if cmd1 == "models":
        cmd_models(rest)
        return
    if cmd1 == "check":
        cmd_check()
        return

    # Env commands
    if cmd1 == "venv":
        cmd_venv(rest)
        return
    if cmd1 == "install":
        cmd_install(rest)
        return
    if cmd1 == "freeze":
        cmd_freeze()
        return
    if cmd1 == "docker" and rest and rest[0].lower() == "init":
        cmd_docker_init()
        return

    # DB commands
    if cmd1 == "db":
        cmd_db(rest)
        return

    # ── Original shortcut table ──
    phrase_2 = " ".join(raw_args[:2]).lower() if len(raw_args) >= 2 else ""
    phrase_1 = raw_args[0].lower()

    if phrase_2 in SHORTCUTS:
        django_args = SHORTCUTS[phrase_2] + list(raw_args[2:])
    elif phrase_1 in SHORTCUTS:
        django_args = SHORTCUTS[phrase_1] + list(raw_args[1:])
    else:
        django_args = list(raw_args)

    # Passthrough to manage.py
    root = find_manage()
    if root is None:
        print(red("Error: manage.py not found. Are you in a Django project?"))
        sys.exit(1)
    full_cmd = [sys.executable, str(root / "manage.py")] + django_args
    try:
        subprocess.run(full_cmd, check=True, cwd=root)
    except KeyboardInterrupt:
        sys.exit(0)
    except FileNotFoundError:
        print(red("Error: manage.py not found. Are you in the root of your Django project?"))
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        sys.exit(e.returncode)


if __name__ == "__main__":
    main()