"""Ingest existing markdown files into DEG.

Two modes:
1. Heuristic (default): regex-based extraction, free, fast, reliable for structured docs.
   Pattern from: DecisionGraph HeuristicExtractor (115 lines, production-tested)
2. LLM (optional fallback): for unstructured docs where heuristics fail.

Research basis: SLOT (arXiv:2505.04016) shows raw LLM prompting = 74.7% schema accuracy.
Heuristic extraction on well-formatted docs is ~95%+ because it matches exact patterns.
"""

from __future__ import annotations

import re
import uuid
from datetime import date
from pathlib import Path
from typing import Callable


def _first_sentence(text: str, fallback: str = "") -> str:
    cleaned = " ".join(text.strip().split())
    if not cleaned:
        return fallback
    # Skip markdown headings, blockquotes, and blank-ish lines
    for line in text.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        # Strip markdown formatting
        line = re.sub(r'^#+\s*', '', line)
        line = re.sub(r'^>\s*', '', line)
        line = re.sub(r'\*\*([^*]+)\*\*', r'\1', line)
        line = line.strip()
        if len(line) > 10:  # Skip very short lines
            pieces = re.split(r"[.!?]", line)
            sentence = pieces[0].strip()
            return sentence[:140] if sentence else fallback
    return fallback


def _extract_list(text: str, prefixes: list[str]) -> list[str]:
    out = []
    for line in text.splitlines():
        lower = line.lower().strip()
        for pref in prefixes:
            if lower.startswith(pref):
                value = line.split(":", 1)[1].strip() if ":" in line else line.strip()
                if value:
                    out.append(value)
    return out


def _extract_heading_block(text: str, heading_names: list[str]) -> list[str]:
    lines = text.splitlines()
    current = None
    buckets: dict[str, list[str]] = {}
    names = {n.lower() for n in heading_names}
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            heading = line.lstrip("#").strip().lower()
            current = heading if heading in names else None
            if current and current not in buckets:
                buckets[current] = []
            continue
        if current is None:
            continue
        value = line.lstrip("- *").strip()
        if value:
            buckets.setdefault(current, []).append(value)
    out = []
    for h in heading_names:
        out.extend(buckets.get(h.lower(), []))
    return out


def _extract_key_value(text: str, keys: list[str]) -> str | None:
    key_set = {k.lower() for k in keys}
    for line in text.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        if key.strip().lower() in key_set and value.strip():
            return value.strip()
    return None


def heuristic_extract(text: str, source_ref: str = "") -> dict:
    """Extract decision + evidence from structured markdown text. No LLM needed.

    Returns dict with 'decision' and 'evidence' keys containing extracted data.
    Works best on docs with headings like: Decision, Alternatives, Assumptions, Risks, etc.
    """
    title = (
        _extract_key_value(text, ["title", "decision", "decision title"])
        or _first_sentence(text, "Extracted decision")
    )
    summary = _extract_key_value(text, ["summary", "context", "rationale"]) or ""
    date_value = _extract_key_value(text, ["date", "decided"]) or str(date.today())

    alternatives = _extract_list(text, ["alternative:", "alternatives:", "rejected:", "considered:"])
    alternatives.extend(_extract_heading_block(text, ["alternatives", "rejected options", "considered options"]))

    assumptions = _extract_list(text, ["assumption:", "assumptions:"])
    assumptions.extend(_extract_heading_block(text, ["assumptions"]))

    risks = _extract_list(text, ["risk:", "risks:"])
    risks.extend(_extract_heading_block(text, ["risks", "unresolved risks"]))

    consequences = _extract_heading_block(text, ["consequences", "downstream", "impact"])

    # Build structured output
    decision_data = {
        "title": title,
        "context": summary,
        "alternatives": [{"option": a, "why": "rejected per document"} for a in dict.fromkeys(alternatives)],
        "scope": _extract_key_value(text, ["scope", "component", "module"]) or "",
    }

    evidence_data = {
        "claim": _first_sentence(text, title),
        "source": source_ref,
        "confidence": 0.7,
    }

    return {"decision": decision_data, "evidence": evidence_data}


def ingest_file(file_path: Path, project_root: Path | None = None) -> dict:
    """Ingest a single markdown file using heuristic extraction. No LLM, no cost."""
    from deg.graph import Graph

    project_root = project_root or file_path.parent
    g = Graph(project_root)

    text = file_path.read_text(encoding="utf-8")
    extracted = heuristic_extract(text, source_ref=str(file_path.name))

    # Create evidence
    ev_data = extracted["evidence"]
    eid = g.evidence(
        claim=ev_data["claim"],
        source=ev_data["source"],
        confidence=ev_data["confidence"],
        source_type="derived",
    )

    # Create decision
    dec_data = extracted["decision"]
    did = g.decide(
        title=dec_data["title"],
        evidence=[eid],
        alternatives=dec_data["alternatives"] if dec_data["alternatives"] else None,
        scope=dec_data["scope"],
        context=dec_data["context"],
    )

    return {"file": file_path.name, "decision_id": did, "evidence_id": eid}


def ingest_directory(directory: Path, project_root: Path | None = None, pattern: str = "*.md") -> list[dict]:
    """Ingest all markdown files in a directory. No LLM, no cost."""
    results = []
    for md_file in sorted(directory.glob(pattern)):
        if md_file.name.startswith(".") or md_file.name.startswith("_"):
            continue
        try:
            result = ingest_file(md_file, project_root)
            results.append(result)
        except Exception as e:
            results.append({"file": md_file.name, "error": str(e)})
    return results
