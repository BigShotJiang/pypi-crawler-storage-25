"""Setup DEG as a Claude Code skill in any project.

Usage:
    deg setup              # Configure current project for Claude Code integration
    deg setup --global     # Install globally for all projects

What it does:
1. Creates .deg/ directory with STATE.yaml
2. Adds CLAUDE.md instructions for DEG protocol
3. Configures MCP server in .claude/settings.json (project-level)
4. Adds hooks for auto-status on session start and auto-close on stop

After setup, Claude Code will:
- Auto-read DEG status at session start
- Auto-record decisions and evidence during work (via SKILL.md instructions)
- Auto-save state on session end
- Expose all DEG tools via MCP (search, trace, challenge, impact, etc.)
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).parent / "skill"


def setup_project(project_root: Path | None = None, global_install: bool = False) -> dict:
    """Set up DEG skill in a project or globally."""
    root = project_root or Path.cwd()
    results = []

    # Check if MCP package is available (informational only)
    try:
        import mcp  # noqa: F401
    except ImportError:
        results.append("⚠️  MCP package not installed. Claude Code MCP tools won't work. Run: pip install degraph[mcp]")

    # 1. Initialize DEG if not already done
    deg_dir = root / ".deg"
    if not deg_dir.exists():
        from deg.graph import Graph
        g = Graph(root)
        g.init()
        results.append("Created .deg/ directory")

    # 2. Add/update CLAUDE.md with DEG instructions + project context template
    claude_md = root / "CLAUDE.md"
    deg_section = _get_claude_md_section()

    # Add project-specific context from STATE.yaml
    state_file = deg_dir / "STATE.yaml"
    project_context = ""
    if state_file.exists():
        import yaml as _yaml
        state_data = _yaml.safe_load(state_file.read_text()) or {}
        if state_data.get("project_goal"):
            project_context += f"**Goal**: {state_data['project_goal']}\n\n"
        if state_data.get("current_phase"):
            project_context += f"**Phase**: {state_data['current_phase']}\n\n"
    if not project_context:
        project_context = "**Goal**: (set with `deg init --goal '...'`)\n\n**Phase**: (set with `deg init --phase '...'`)\n\n"
    project_context += "**File Structure**: (add key paths here)\n\n**How to Run**: (add commands here)\n\n**Key Metrics**: (add numbers here)\n"

    full_content = deg_section + project_context

    if claude_md.exists():
        content = claude_md.read_text()
        if "## Project Context + Decision Memory" in content:
            results.append("CLAUDE.md already configured (no changes)")
        else:
            # APPEND with clear separator — preserve everything above
            content += f"\n\n---\n\n{full_content}"
            claude_md.write_text(content)
            results.append("Appended DEG section to existing CLAUDE.md (your content preserved above)")
    else:
        claude_md.write_text(full_content)
        results.append("Created CLAUDE.md with DEG protocol + project context template")

    # 3. Configure MCP server in .claude/settings.json
    claude_dir = root / ".claude"
    claude_dir.mkdir(exist_ok=True)
    settings_file = claude_dir / "settings.json"

    settings = {}
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text())
        except json.JSONDecodeError:
            settings = {}

    # Add MCP server config
    if "mcpServers" not in settings:
        settings["mcpServers"] = {}

    deg_path = shutil.which("deg")
    if not deg_path:
        # Try the Python executable's directory (common with uv/pipx)
        bin_dir = Path(sys.executable).parent
        candidate = bin_dir / "deg"
        if candidate.exists():
            deg_path = str(candidate)
    if not deg_path:
        # Ultimate fallback: use python -m to run the module
        deg_path = sys.executable
        deg_args = ["-m", "deg.cli", "serve", "--root", str(root)]
    else:
        deg_args = ["serve", "--root", str(root)]

    settings["mcpServers"]["deg"] = {
        "type": "stdio",
        "command": deg_path,
        "args": deg_args
    }

    settings_file.write_text(json.dumps(settings, indent=2))
    results.append("Configured MCP server in .claude/settings.json")

    # 4. Add hooks
    if "hooks" not in settings:
        settings["hooks"] = {}

    hooks_source = SKILL_DIR / "hooks.json"
    if hooks_source.exists():
        hooks_data = json.loads(hooks_source.read_text())
        settings["hooks"] = hooks_data.get("hooks", {})
        settings_file.write_text(json.dumps(settings, indent=2))
        results.append("Added session hooks (auto-status on start, auto-close on stop)")

    # 5. Copy SKILL.md to .claude/ for reference
    skill_source = SKILL_DIR / "SKILL.md"
    if skill_source.exists():
        skill_dest = claude_dir / "deg-skill.md"
        shutil.copy2(skill_source, skill_dest)
        results.append("Copied DEG skill instructions to .claude/deg-skill.md")

    # Check if existing docs might be ingestible
    existing_docs = list(root.glob("*.md")) + list(root.glob("docs/**/*.md"))
    if len(existing_docs) > 2:
        results.append(f"💡 Found {len(existing_docs)} markdown files. Have Claude read them and record decisions (better than regex ingest).")

    # Suggest ecosystem tools
    results.append("")
    results.append("Recommended ecosystem (optional, enhances DEG):")
    results.append("  Code understanding: /plugin install understand-anything")
    results.append("  Web research:       npm install -g tinyfish")
    results.append("  Deep literature:    github.com/HumanSignal/ml-intern (optional, requires Opus)")

    return {"root": str(root), "actions": results}


def _get_claude_md_section() -> str:
    return """## Project Context + Decision Memory

This project uses DEG for persistent decision memory. DEG is your memory — use it reflexively, not optionally.

### MANDATORY SESSION PROTOCOL

**Start**: Call `deg_status` FIRST. Read goal, phase, stale alerts, next actions. Challenge anything stale.
**During**: Record every decision (`deg_decide`) and finding (`deg_evidence`) AS they happen. Query (`deg_search`) BEFORE recommending anything.
**End**: Auto-saved via hook. If manually closing: `deg_close_session` with summary + next actions.

### YOUR DECISION MEMORY (via MCP tools)

| When | Action | Tool |
|------|--------|------|
| Starting session | Read current state | `deg_status` |
| Before any recommendation | Check what exists | `deg_search` |
| Making a choice | Record with alternatives | `deg_decide` |
| Finding something new | Record with source | `deg_evidence` |
| Asked "why X?" | Show provenance chain | `deg_trace` |
| Asked "still valid?" | Check triggers + evidence | `deg_challenge` |
| Asked "what if we change?" | Show cascade | `deg_impact` |
| Continuing research | Get where we stopped | `deg_continue` |

### WHAT GOES IN DEG vs WHAT STAYS IN .md FILES

**DEG handles** (queryable, traceable, auto-stale-detection):
- Every decision with evidence + rejected alternatives + reconsider_if
- Research findings with source + confidence + temporal validity
- Session handoff (what happened, what's next)
- Cascade: if evidence changes → downstream decisions flagged

**CLAUDE.md handles** (static context, rarely changes):
- Project goal and current phase (below)
- File/repo structure overview
- How to run/reproduce
- Key metrics and numbers

### REFLEXIVE RULES

1. NEVER make a decision without checking DEG first (`deg_search`)
2. ALWAYS record decisions with alternatives and reconsider_if conditions
3. NEVER ask "should I record this?" — just record it
4. When evidence contradicts existing: use `invalidates` parameter — trust model handles the rest
5. Confidence is honest: 0.3=guess, 0.7=reasonable, 0.9=strong, 0.95=confirmed

### SELF-HEALING (DEG handles its own consistency)

`deg_status` returns `integrity_issues` when the graph has problems. Handle by severity:
- **auto_fix**: Execute the instruction immediately (e.g., "Decision has no evidence — record reasoning")
- **confirm**: Ask user (e.g., "All evidence for D-xxx was superseded — supersede the decision too?")
- **info**: Mention briefly, don't block work

DEG also detects contradictions on every write. If `deg_status` shows contradictions:
1. Present the conflict to user: "These two decisions conflict: [details]"
2. User decides which wins → supersede the other

### MAINTENANCE (periodic, suggest when graph grows)

When the graph has 20+ nodes, occasionally run:
- `deg check` — structural constraint validation (cycles, dangling refs, cardinality)
- `deg check --git` — check if files referenced by decisions changed
- `deg maintenance` — find orphans, duplicates, merge candidates, stale items

### RESEARCH REVALIDATION (when decisions go stale)

When `deg_status` shows `stale_alerts` or `integrity_issues` suggests re-research:
1. Challenge the decision: `deg_challenge(id)` — see alternatives + reconsider_if
2. Research current state (use web search, S2 API, or ask user)
3. Record findings: `deg_evidence(claim, source, confidence)`
4. If new evidence invalidates old: `deg_evidence(..., invalidates=old_evidence_id)`
5. If decision still valid: acknowledge — staleness resolves next revalidation cycle

### ECOSYSTEM TOOLS (use alongside DEG when available)

DEG handles WHY. These tools handle WHAT and WHERE:

**Understand-Anything** (code structure + impact analysis):
- Install: `/plugin marketplace add Lum1104/Understand-Anything` then `/plugin install understand-anything`
- When decision superseded → use `/understand-diff` to find affected code files
- When asked "why is code like this?" → UA explains WHAT + DEG explains WHY
- When reviewing architecture → cross-reference UA layers with DEG decisions
- When code changes → `deg check --git` flags decisions, UA shows what changed

**TinyFish** (web research for decision revalidation):
- Install: `npm install -g tinyfish`
- When decision is stale → `tinyfish search "topic 2026"` to check current landscape
- When reconsider_if mentions external events → search for those events
- Record findings: `deg_evidence(claim, source=url, confidence=0.7-0.9)`

**ML-Intern** (optional deep literature research):
- When user needs 40-60 paper survey → suggest: `ml-intern --max-iterations 25 "topic"`
- User installs separately if needed (forces Opus model)

If these tools are NOT installed, fall back to your own knowledge (lower confidence).
Always record what source was used: source_type="observation" for your own knowledge vs "literature" for verified sources.

### FULL PROTOCOL REFERENCE

For detailed protocols (conflict resolution steps, research tiers, UA integration patterns, dismissal system): read `.claude/deg-skill.md`

---

## Static Project Context

"""
