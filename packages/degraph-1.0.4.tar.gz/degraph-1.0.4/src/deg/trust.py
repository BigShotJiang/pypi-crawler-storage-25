"""Evidence trust and confidence model.

Solves 4 problems identified in adversarial testing:
1. Low-confidence override prevention (confidence-weighted supersession)
2. Evidence lifecycle states (multi-state, not binary)
3. Trust scoring for search filtering (noisy/adversarial rejection)
4. Evidence provenance chains (full history per decision)

Mathematical basis:
- Supersession: conf(new) × overlap > conf(old) × (1 - decay) [Confidence-weighted]
- Trust: source_trust × consistency × age_penalty [Exponential decay, 180-day half-life]
- Impact: validity × strength × scope × (1 - staleness) [4-factor composite]
- Cascade threshold: |impact_delta| > 0.25 [Significance filter]

Sources:
- FPF (arXiv:2601.21116): WLNK = min evidence, congruence levels
- Dempster-Shafer evidence theory: belief + plausibility intervals
- WorldDB (arXiv:2604.18478): write-time programs with validity semantics
"""

from __future__ import annotations

import math
import time
from datetime import date, datetime
from typing import Any


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Problem 1: Confidence-Weighted Supersession
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def can_supersede(new_confidence: float, old_confidence: float,
                  old_created: date | None = None,
                  decay_period_days: int = 365) -> tuple[bool, str]:
    """Determine if new evidence can supersede old evidence.

    Rules:
    - New confidence must exceed old confidence × (1 - time_decay)
    - Time decay weakens old evidence by max 30% over decay_period
    - Returns (can_supersede, reason)
    """
    if old_created:
        age_days = (date.today() - old_created).days
        temporal_decay = min(0.3, age_days / decay_period_days)
    else:
        temporal_decay = 0.0

    effective_old = old_confidence * (1 - temporal_decay)

    if new_confidence >= effective_old:
        return True, f"new_conf={new_confidence:.2f} >= effective_old={effective_old:.2f} (decay={temporal_decay:.2f})"
    else:
        return False, f"new_conf={new_confidence:.2f} < effective_old={effective_old:.2f} — BLOCKED"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Problem 2: Evidence Impact Score (4-factor)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Evidence validity states
VALIDITY_ACTIVE = 1.0
VALIDITY_WEAKENED = 0.8
VALIDITY_CONTRADICTED = 0.3
VALIDITY_SUPERSEDED = 0.0


def compute_impact(confidence: float, validity: float = VALIDITY_ACTIVE,
                   scope: float = 1.0, created_at: date | None = None,
                   max_useful_days: int = 180) -> float:
    """Compute evidence impact score: validity × confidence × scope × (1 - staleness).

    Higher impact = more trustworthy evidence.
    """
    staleness = 0.0
    if created_at:
        age_days = (date.today() - created_at).days
        staleness = min(0.5, age_days / max_useful_days)

    return validity * confidence * scope * (1 - staleness)


def should_cascade(old_impact: float, new_impact: float,
                   high_stakes: bool = False) -> tuple[bool, str]:
    """Determine if evidence change should trigger cascade to downstream decisions.

    Cascade fires only if impact change is significant (>0.25) or high-stakes (>0.1).
    This prevents low-confidence noise from triggering cascades.
    """
    delta = abs(old_impact - new_impact)
    threshold = 0.1 if high_stakes else 0.25

    if delta > threshold:
        return True, f"impact_delta={delta:.2f} > threshold={threshold:.2f}"
    return False, f"impact_delta={delta:.2f} <= threshold={threshold:.2f} — cascade BLOCKED"


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Problem 3: Trust Scoring for Search Filtering
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Source trust levels
SOURCE_TRUST = {
    "literature": 0.85,    # Peer-reviewed papers
    "experiment": 0.90,    # Your own experimental results
    "observation": 0.60,   # Observed but not verified
    "derived": 0.50,       # Inferred/calculated
    "adversarial": 0.10,   # Known adversarial input
}


def compute_trust_score(confidence: float, source_type: str = "observation",
                        created_at: date | None = None,
                        contradictions: int = 0,
                        credibility_half_life_days: int = 180) -> float:
    """Compute trust score for evidence filtering.

    Low trust score → evidence shouldn't appear in search results or trigger cascades.
    """
    source_trust = SOURCE_TRUST.get(source_type, 0.5)

    # Consistency penalty: each contradiction reduces trust
    consistency = max(0.1, 1.0 - 0.2 * contradictions)

    # Age penalty: exponential decay
    age_penalty = 1.0
    if created_at:
        age_days = (date.today() - created_at).days
        age_penalty = math.exp(-age_days / credibility_half_life_days)

    return confidence * source_trust * consistency * age_penalty


def filter_by_trust(nodes: list[dict], min_trust: float = 0.3) -> list[dict]:
    """Filter search results by trust score threshold.

    Removes low-confidence, adversarial, or contradicted evidence from results.
    """
    filtered = []
    for node in nodes:
        confidence = node.get("confidence", 0.5)
        source_type = "observation"
        source = node.get("source", {})
        if isinstance(source, dict):
            source_type = source.get("type", "observation")

        created_at = None
        created_str = node.get("created_at") or node.get("created")
        if created_str:
            try:
                created_at = date.fromisoformat(str(created_str))
            except (ValueError, TypeError):
                pass

        trust = compute_trust_score(confidence, source_type, created_at)
        if trust >= min_trust:
            node["_trust_score"] = trust
            filtered.append(node)

    return filtered


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Problem 4: Decision Confidence from Evidence Chain
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def decision_confidence(evidence_impacts: list[float]) -> float:
    """Compute decision confidence using WLNK (Weakest Link) aggregation.

    FPF (arXiv:2601.21116): decision reliability = min of all supporting evidence.
    A decision is only as strong as its weakest evidence.
    """
    if not evidence_impacts:
        return 0.5  # No evidence → neutral confidence
    return min(evidence_impacts)


def decision_health(evidence_nodes: list[dict]) -> dict:
    """Compute full health report for a decision based on its evidence chain.

    Returns: overall confidence, weakest link, risk factors.
    """
    if not evidence_nodes:
        return {
            "confidence": 0.5,
            "health": "unknown",
            "weakest_link": None,
            "risk_factors": ["No supporting evidence"],
        }

    impacts = []
    weakest = None
    weakest_impact = 1.0
    risks = []

    for ev in evidence_nodes:
        confidence = ev.get("confidence", 0.5)
        status = ev.get("status", "active")

        if status == "superseded":
            validity = VALIDITY_SUPERSEDED
            risks.append(f"{ev.get('deg_id', '?')}: superseded")
        elif status == "contradicted":
            validity = VALIDITY_CONTRADICTED
            risks.append(f"{ev.get('deg_id', '?')}: contradicted")
        else:
            validity = VALIDITY_ACTIVE

        created_at = None
        created_str = ev.get("created_at") or ev.get("created")
        if created_str:
            try:
                created_at = date.fromisoformat(str(created_str))
            except (ValueError, TypeError):
                pass

        impact = compute_impact(confidence, validity, created_at=created_at)
        impacts.append(impact)

        if impact < weakest_impact:
            weakest_impact = impact
            weakest = ev.get("deg_id", "unknown")

    overall = decision_confidence(impacts)

    if overall >= 0.7:
        health = "strong"
    elif overall >= 0.4:
        health = "moderate"
    elif overall > 0:
        health = "weak"
    else:
        health = "unsupported"

    return {
        "confidence": round(overall, 3),
        "health": health,
        "weakest_link": weakest,
        "weakest_impact": round(weakest_impact, 3),
        "evidence_count": len(evidence_nodes),
        "risk_factors": risks,
    }
