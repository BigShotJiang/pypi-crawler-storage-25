"""Git-event-driven staleness detector for DEG.

Detects when files referenced by decisions have changed,
making those decisions potentially stale.
"""

from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

INFRA_FILES = {"requirements.txt", "pyproject.toml", "package.json", "Cargo.toml", "go.mod"}


def get_last_validated_commit(project_root: Path) -> str | None:
    """Read .deg/git_state.json, return last commit hash or None."""
    state_file = project_root / ".deg" / "git_state.json"
    if not state_file.exists():
        return None
    try:
        data = json.loads(state_file.read_text())
        return data.get("last_validated_commit")
    except (json.JSONDecodeError, OSError):
        return None


def save_git_state(project_root: Path, commit: str) -> None:
    """Write current commit to .deg/git_state.json."""
    state_dir = project_root / ".deg"
    state_dir.mkdir(parents=True, exist_ok=True)
    state_file = state_dir / "git_state.json"
    state_file.write_text(json.dumps({
        "last_validated_commit": commit,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }, indent=2) + "\n")


def _run_git(args: list[str], cwd: Path) -> str | None:
    """Run a git command, return stdout or None on failure."""
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def _get_head_commit(project_root: Path) -> str | None:
    return _run_git(["rev-parse", "HEAD"], project_root)


def _get_changed_files(project_root: Path, diff_args: list[str]) -> list[str]:
    output = _run_git(["diff", "--name-only"] + diff_args, project_root)
    if not output:
        return []
    return [f for f in output.splitlines() if f]


def _find_stale_decisions(changed_files: list[str], nodes: dict) -> list[dict]:
    """Match changed files against decision nodes."""
    if not changed_files:
        return []

    changed_set = set(changed_files)
    changed_basenames = {Path(f).name for f in changed_files}
    infra_changed = bool(changed_basenames & INFRA_FILES)
    results = []

    for node_id, node in nodes.items():
        if node.get("type") != "decision":
            continue

        reasons = []
        matched_files = []

        # Check references
        refs = node.get("references", [])
        for ref in refs:
            if ref in changed_set or any(ref in cf for cf in changed_files):
                matched_files.append(ref)

        if matched_files:
            reasons.append(f"referenced files changed: {', '.join(matched_files)}")

        # Check infrastructure scope
        if infra_changed and node.get("scope") in ("infrastructure", "technology"):
            reasons.append("dependency manifest changed")

        if reasons:
            results.append({
                "decision_id": node_id,
                "reason": "; ".join(reasons),
                "changed_files": matched_files or [f for f in changed_files if Path(f).name in INFRA_FILES],
            })

    return results


def check_git_staleness(project_root: Path, nodes: dict) -> list[dict]:
    """Check which decisions are stale based on git changes since last check.

    Returns list of: {"decision_id": str, "reason": str, "changed_files": list[str]}
    """
    head = _get_head_commit(project_root)
    if head is None:
        return []

    last_commit = get_last_validated_commit(project_root)
    if last_commit is None:
        # First run: all files changed since initial commit
        changed = _get_changed_files(project_root, ["--name-only", "HEAD"])
        # Fallback: treat as if everything is potentially stale
        changed = _get_changed_files(project_root, ["4b825dc642cb6eb9a060e54bf899d69f82cf7bfb", "HEAD"])
    else:
        changed = _get_changed_files(project_root, [last_commit, "HEAD"])

    results = _find_stale_decisions(changed, nodes)
    save_git_state(project_root, head)
    return results


def check_staged_staleness(project_root: Path, nodes: dict) -> list[dict]:
    """Check staged files (pre-commit hook compatible). Same logic but uses git diff --staged."""
    head = _get_head_commit(project_root)
    if head is None:
        return []

    changed = _get_changed_files(project_root, ["--staged"])
    return _find_stale_decisions(changed, nodes)
