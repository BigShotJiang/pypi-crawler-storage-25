"""Hybrid retrieval: FAISS semantic + BFS graph traversal + keyword matching + PPR scoring.

Implements GAAMA pattern (arXiv:2603.27910): mild PPR augmentation (w=0.1) over semantic seeds.
Implements Mem0 pattern: keyword + semantic + entity boost fusion.
"""

from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
from typing import Any

try:
    import numpy as np
except ImportError:
    np = None  # numpy only needed for hybrid_search (via embeddings)


def hybrid_search(
    query: str,
    project_root: Path,
    nodes: dict,
    edges: list[dict],
    successors: dict[str, list[str]],
    k: int = 10,
    w_semantic: float = 1.0,
    w_keyword: float = 0.3,
    w_graph: float = 0.1,
) -> list[dict]:
    """
    Hybrid retrieval combining:
    1. FAISS semantic search (cosine similarity)
    2. Keyword matching (BM25-lite)
    3. Graph-based PPR boost from semantic seeds

    Returns ranked list of {id, score, title, type, ...}
    """
    from deg.embeddings import semantic_search

    # --- Step 1: Semantic search (FAISS) ---
    sem_results = semantic_search(query, project_root, k=k * 4)
    sem_scores = {nid: score for nid, score in sem_results}

    # --- Step 2: Keyword search (simple BM25-lite) ---
    kw_scores = _keyword_search(query, nodes)

    # --- Step 3: Graph expansion + PPR from top semantic seeds ---
    graph_scores = {}
    if sem_results:
        seeds = [nid for nid, _ in sem_results[:min(10, len(sem_results))]]
        graph_scores = _graph_ppr(seeds, nodes, edges, successors, alpha=0.6, hops=2)

    # --- Step 4: Score fusion (additive, Mem0 pattern) ---
    all_candidates = set(sem_scores.keys()) | set(kw_scores.keys()) | set(graph_scores.keys())
    scored = []
    for nid in all_candidates:
        s_sem = sem_scores.get(nid, 0)
        s_kw = kw_scores.get(nid, 0)
        s_graph = graph_scores.get(nid, 0)
        combined = w_semantic * s_sem + w_keyword * s_kw + w_graph * s_graph
        scored.append((nid, combined))

    scored.sort(key=lambda x: x[1], reverse=True)

    # --- Step 5: Format results ---
    results = []
    for nid, score in scored[:k]:
        node = nodes.get(nid, {})
        results.append({
            "id": nid,
            "score": round(score, 4),
            "type": node.get("type", ""),
            "title": node.get("title", node.get("claim", "")),
            "status": node.get("status", ""),
        })

    return results


def trace_provenance(
    node_id: str,
    nodes: dict,
    edges: list[dict],
    max_depth: int = 10,
) -> list[dict]:
    """BFS upstream traversal following informed_by + depends_on edges."""
    chain = []
    visited = set()
    queue = deque([(node_id, 0)])

    # Build reverse edge index for upstream traversal
    upstream: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for edge in edges:
        if edge["type"] in ("informed_by", "depends_on"):
            upstream[edge["from"]].append((edge["to"], edge["type"]))

    while queue:
        nid, depth = queue.popleft()
        if nid in visited or depth > max_depth:
            continue
        visited.add(nid)

        node = nodes.get(nid)
        if node:
            chain.append({
                "id": nid,
                "depth": depth,
                "type": node.get("type", ""),
                "title": node.get("title", node.get("claim", "")),
                "status": node.get("status", ""),
                "confidence": node.get("confidence", ""),
                "created": str(node.get("created", node.get("created_at", ""))),
            })

        for target_id, edge_type in upstream.get(nid, []):
            if target_id not in visited:
                queue.append((target_id, depth + 1))

    return chain


def cascade_impact_bfs(
    node_id: str,
    successors: dict[str, list[str]],
    nodes: dict,
) -> list[dict]:
    """BFS downstream traversal. Returns all affected nodes with metadata."""
    affected = []
    visited = set()
    queue = deque(successors.get(node_id, []))

    while queue:
        nid = queue.popleft()
        if nid in visited:
            continue
        visited.add(nid)

        node = nodes.get(nid, {})
        if node.get("unit_type") == "protected":
            continue

        affected.append({
            "id": nid,
            "type": node.get("type", ""),
            "title": node.get("title", node.get("claim", "")),
            "status": node.get("status", ""),
        })
        queue.extend(successors.get(nid, []))

    return affected


def _keyword_search(query: str, nodes: dict, top_k: int = 20) -> dict[str, float]:
    """Simple keyword matching (BM25-lite). Scores nodes by term overlap."""
    query_terms = set(query.lower().split())
    if not query_terms:
        return {}

    scores = {}
    for nid, node in nodes.items():
        text = f"{node.get('title', '')} {node.get('claim', '')} {node.get('context', '')} {node.get('scope', '')}".lower()
        node_terms = set(text.split())
        overlap = query_terms & node_terms
        if overlap:
            # TF-like score: fraction of query terms found
            scores[nid] = len(overlap) / len(query_terms)

    # Normalize to [0, 1]
    if scores:
        max_score = max(scores.values())
        if max_score > 0:
            scores = {k: v / max_score for k, v in scores.items()}

    # Return top-k
    sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
    return dict(sorted_scores)


def _graph_ppr(
    seeds: list[str],
    nodes: dict,
    edges: list[dict],
    successors: dict[str, list[str]],
    alpha: float = 0.6,
    hops: int = 2,
) -> dict[str, float]:
    """
    Simplified Personalized PageRank from semantic seed nodes.
    GAAMA pattern: expand 2 hops, compute PPR on subgraph.
    Uses networkx if available, otherwise manual BFS approximation.
    """
    try:
        import networkx as nx

        # Build subgraph around seeds (expand by hops)
        expanded = set(seeds)
        frontier = set(seeds)
        for _ in range(hops):
            new_frontier = set()
            for n in frontier:
                new_frontier.update(successors.get(n, []))
                # Also follow reverse edges
                for edge in edges:
                    if edge["to"] == n:
                        new_frontier.add(edge["from"])
            expanded.update(new_frontier)
            frontier = new_frontier

        if len(expanded) < 2:
            return {}

        # Build networkx graph on subgraph
        G = nx.DiGraph()
        edge_weights = {
            "informed_by": 0.8,
            "depends_on": 0.8,
            "supersedes": 0.5,
            "invalidates": 0.5,
            "informs": 0.6,
            "cross_project_link": 0.3,
        }
        for edge in edges:
            if edge["from"] in expanded and edge["to"] in expanded:
                w = edge_weights.get(edge.get("type", ""), 0.5)
                G.add_edge(edge["from"], edge["to"], weight=w)

        # Add nodes without edges
        for n in expanded:
            if n not in G:
                G.add_node(n)

        # Personalization: seed nodes get weight proportional to their semantic score position
        personalization = {}
        for i, seed in enumerate(seeds):
            if seed in expanded:
                personalization[seed] = 1.0 / (i + 1)  # rank-weighted

        # Normalize
        total = sum(personalization.values())
        if total > 0:
            personalization = {k: v / total for k, v in personalization.items()}

        # Add zero weight for non-seed expanded nodes
        for n in expanded:
            if n not in personalization:
                personalization[n] = 0

        try:
            ppr = nx.pagerank(G, alpha=alpha, personalization=personalization, max_iter=100)
        except (nx.PowerIterationFailedConvergence, nx.NetworkXError):
            return {}

        return ppr

    except ImportError:
        # Fallback: simple BFS distance scoring without networkx
        scores = {}
        for seed in seeds:
            visited = set()
            queue = deque([(seed, 0)])
            while queue:
                nid, depth = queue.popleft()
                if nid in visited or depth > hops:
                    continue
                visited.add(nid)
                # Score decays with distance
                scores[nid] = scores.get(nid, 0) + 1.0 / (1 + depth)
                for succ in successors.get(nid, []):
                    queue.append((succ, depth + 1))

        # Normalize
        if scores:
            max_s = max(scores.values())
            if max_s > 0:
                scores = {k: v / max_s for k, v in scores.items()}
        return scores
