"""Denial-constraint-based contradiction detector for DEG.

Based on Bleifuss VLDB'17 + Wikidata constraint taxonomy.
On structured data with typed YAML fields, rule-based detection is provably complete.
No ML needed.

Four contradiction types:
1. Single-value violation — two active decisions with same scope making different choices
2. Conflicts-with (lookup) — explicit incompatibilities from rules YAML
3. Temporal overlap — same-scope decisions with overlapping validity windows
4. Dependency-on-invalid — active decision depending on superseded/deprecated node
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import yaml


@dataclass
class Contradiction:
    type: str  # "single_value", "conflicts_with", "temporal_overlap", "dependency_invalid"
    decision_ids: list[str]  # the conflicting decisions
    message: str
    severity: str  # "warning" (soft conflict) or "critical" (hard contradiction)


def load_rules(project_root: Path) -> dict:
    """Load deg_rules.yaml from .deg/ directory. Returns empty dict if not found."""
    candidates = [
        project_root / ".deg" / "deg_rules.yaml",
        project_root / "deg_rules.yaml",
    ]
    for path in candidates:
        if path.exists():
            with open(path) as f:
                return yaml.safe_load(f) or {}
    return {}


def _is_active(node: dict) -> bool:
    """A decision is active if not superseded or deprecated."""
    status = node.get("status", "active")
    return status not in ("superseded", "deprecated", "rejected")


def _parse_dt(val) -> datetime | None:
    if val is None:
        return None
    if isinstance(val, datetime):
        return val
    if isinstance(val, str):
        try:
            return datetime.fromisoformat(val)
        except (ValueError, TypeError):
            return None
    return None


def _windows_overlap(a_from, a_until, b_from, b_until) -> bool:
    """Check if two time windows overlap. None means unbounded."""
    a_start = a_from or datetime.min
    a_end = a_until or datetime.max
    b_start = b_from or datetime.min
    b_end = b_until or datetime.max
    return a_start < b_end and b_start < a_end


def _title_contains(node: dict, pattern: str) -> bool:
    title = node.get("title", "") or node.get("name", "") or ""
    return pattern.lower() in title.lower()


def detect_contradictions(
    nodes: dict[str, dict],
    edges: list[dict],
    rules: dict | None = None,
) -> list[Contradiction]:
    """Detect all contradictions in the graph. Rules loaded from deg_rules.yaml if not passed."""
    if rules is None:
        rules = {}

    contradictions: list[Contradiction] = []
    active_decisions = {
        nid: n for nid, n in nodes.items()
        if n.get("type") == "decision" and _is_active(n)
    }

    # Types 1-2 only fire with explicit user rules. Types 3-4 are universal.

    # 1. Single-value violation
    sv_scopes = set(rules.get("single_value_scopes", []))
    if sv_scopes:
        by_scope: dict[str, list[str]] = defaultdict(list)
        for nid, n in active_decisions.items():
            scope = n.get("scope", "")
            if scope in sv_scopes:
                by_scope[scope].append(nid)
        for scope, ids in by_scope.items():
            if len(ids) > 1:
                contradictions.append(Contradiction(
                    type="single_value",
                    decision_ids=ids,
                    message=f"Multiple active decisions for scope '{scope}': {ids}",
                    severity="critical",
                ))

    # 2. Conflicts-with (lookup)
    conflict_rules = rules.get("conflicts_with", [])
    for rule in conflict_rules:
        if_cond = rule.get("if", {})
        then_not = rule.get("then_not", {})
        matching_if = [
            nid for nid, n in active_decisions.items()
            if n.get("scope") == if_cond.get("scope")
            and (not if_cond.get("title_contains") or _title_contains(n, if_cond["title_contains"]))
        ]
        matching_then = [
            nid for nid, n in active_decisions.items()
            if n.get("scope") == then_not.get("scope")
            and (not then_not.get("title_contains") or _title_contains(n, then_not["title_contains"]))
        ]
        for a in matching_if:
            for b in matching_then:
                if a != b:
                    contradictions.append(Contradiction(
                        type="conflicts_with",
                        decision_ids=[a, b],
                        message=f"Rule conflict: '{nodes[a].get('title', a)}' incompatible with '{nodes[b].get('title', b)}'",
                        severity="critical",
                    ))

    # 3. Temporal overlap — only flags when decisions share scope AND have title similarity
    #    (prevents false positives: "architecture" scope can legitimately have multiple decisions
    #     about different concerns like storage, indexing, temporal model)
    by_scope_temporal: dict[str, list[str]] = defaultdict(list)
    for nid, n in active_decisions.items():
        scope = n.get("scope")
        if scope:
            by_scope_temporal[scope].append(nid)

    for scope, ids in by_scope_temporal.items():
        for i in range(len(ids)):
            for j in range(i + 1, len(ids)):
                a, b = nodes[ids[i]], nodes[ids[j]]
                # Require title similarity > 0.4 to flag as temporal overlap
                # This prevents unrelated decisions in the same scope from conflicting
                a_title = (a.get("title") or "").lower().split()
                b_title = (b.get("title") or "").lower().split()
                if not a_title or not b_title:
                    continue
                common = set(a_title) & set(b_title)
                # Remove stopwords from overlap calculation
                stopwords = {"the", "a", "an", "for", "to", "in", "on", "of", "and", "or", "use", "with"}
                common -= stopwords
                a_meaningful = set(a_title) - stopwords
                b_meaningful = set(b_title) - stopwords
                if not a_meaningful or not b_meaningful:
                    continue
                similarity = len(common) / min(len(a_meaningful), len(b_meaningful))
                if similarity < 0.4:
                    continue
                a_from = _parse_dt(a.get("valid_from"))
                a_until = _parse_dt(a.get("valid_until") or a.get("expired_at"))
                b_from = _parse_dt(b.get("valid_from"))
                b_until = _parse_dt(b.get("valid_until") or b.get("expired_at"))
                if _windows_overlap(a_from, a_until, b_from, b_until):
                    contradictions.append(Contradiction(
                        type="temporal_overlap",
                        decision_ids=[ids[i], ids[j]],
                        message=f"Temporal overlap in scope '{scope}': '{a.get('title', ids[i])}' and '{b.get('title', ids[j])}' (title similarity: {similarity:.0%})",
                        severity="warning",
                    ))

    # 4. Dependency-on-invalid
    edge_index: dict[str, list[str]] = defaultdict(list)
    for e in edges:
        rel = e.get("relation", "")
        if rel in ("depends_on", "informed_by"):
            edge_index[e.get("source", "")].append(e.get("target", ""))

    for nid in active_decisions:
        for target in edge_index.get(nid, []):
            if target in nodes:
                target_status = nodes[target].get("status", "active")
                if target_status in ("superseded", "deprecated"):
                    contradictions.append(Contradiction(
                        type="dependency_invalid",
                        decision_ids=[nid, target],
                        message=f"Active decision '{nodes[nid].get('title', nid)}' depends on {target_status} node '{nodes[target].get('title', target)}'",
                        severity="warning",
                    ))

    return contradictions
