"""Graph integrity self-healing — detects inconsistencies DEG can fix automatically.

These checks catch situations where the graph is internally inconsistent,
not where the external world changed (that's triggers/staleness). These are
bugs in the GRAPH ITSELF that should never exist and can be auto-corrected.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path


@dataclass
class IntegrityIssue:
    type: str           # issue type identifier
    severity: str       # "auto_fix" (Claude fixes without asking), "confirm" (ask user), "info"
    node_ids: list[str]
    message: str        # what's wrong (self-explanatory for fresh agent)
    auto_fix: str       # what Claude should do (executable instruction)


def check_integrity(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Run all integrity checks. Returns issues sorted by severity."""
    issues = []
    issues.extend(_check_unsupported_decisions(nodes, edges))
    issues.extend(_check_circular_evidence(nodes, edges))
    issues.extend(_check_evidence_newer_than_decision(nodes, edges))
    issues.extend(_check_orphaned_active_decisions(nodes, edges))
    issues.extend(_check_superseded_still_depended_on(nodes, edges))
    issues.extend(_check_confidence_inconsistency(nodes, edges))
    return sorted(issues, key=lambda i: {"auto_fix": 0, "confirm": 1, "info": 2}[i.severity])


def _get_informed_by_targets(node_id: str, edges: list[dict]) -> list[str]:
    """Get all evidence IDs supporting a decision (via informed_by OR informs edges)."""
    targets = [e.get("to") for e in edges if e.get("from") == node_id and e.get("type") == "informed_by"]
    # Also check reverse: evidence that 'informs' this decision
    targets += [e.get("from") for e in edges if e.get("to") == node_id and e.get("type") == "informs"]
    return targets


def _get_depends_on_targets(node_id: str, edges: list[dict]) -> list[str]:
    """Get all node IDs that a decision depends_on."""
    return [e.get("to") for e in edges if e.get("from") == node_id and e.get("type") == "depends_on"]


def _check_unsupported_decisions(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Active decisions where ALL supporting evidence has been superseded/deprecated."""
    issues = []
    invalid_statuses = {"superseded", "deprecated"}

    for nid, node in nodes.items():
        if node.get("type") != "decision" or node.get("status") != "active":
            continue

        evidence_ids = _get_informed_by_targets(nid, edges)
        if not evidence_ids:
            continue  # no evidence is a different check (orphaned)

        # Check if ALL evidence is invalid
        all_invalid = all(
            nodes.get(eid, {}).get("status") in invalid_statuses
            for eid in evidence_ids
            if eid in nodes
        )

        if all_invalid:
            issues.append(IntegrityIssue(
                type="unsupported_decision",
                severity="confirm",
                node_ids=[nid] + evidence_ids,
                message=f"Decision {nid} is active but ALL its supporting evidence ({len(evidence_ids)} items) has been superseded or deprecated.",
                auto_fix=f"Flag decision {nid} as 'under_review' — all its evidence is invalid. Call deg_challenge({nid}) and present alternatives to user.",
            ))

    return issues


def _check_circular_evidence(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Decision depends on evidence that cites the same decision as its source,
    or two decisions mutually depend on each other."""
    issues = []

    for nid, node in nodes.items():
        if node.get("type") != "decision":
            continue

        # Check 1: decision D informed_by evidence E where E.source references D
        evidence_ids = _get_informed_by_targets(nid, edges)
        decision_title = node.get("title", "")

        for eid in evidence_ids:
            ev = nodes.get(eid)
            if ev is None:
                continue
            ev_source = ev.get("source", "") or ""
            # Check if evidence source contains the decision ID or title
            if nid in ev_source or (decision_title and decision_title in ev_source):
                issues.append(IntegrityIssue(
                    type="circular_evidence",
                    severity="confirm",
                    node_ids=[nid, eid],
                    message=f"Circular reasoning: {nid} is informed by {eid}, but {eid}'s source references {nid} itself.",
                    auto_fix=f"Circular reasoning detected: {nid} <- {eid} <- {nid}. The evidence is self-referential. Record genuine external evidence or remove the circular link.",
                ))

        # Check 2: mutual depends_on between decisions
        deps = _get_depends_on_targets(nid, edges)
        for dep_id in deps:
            dep_node = nodes.get(dep_id)
            if dep_node is None or dep_node.get("type") != "decision":
                continue
            # Check if dep_id also depends_on nid
            reverse_deps = _get_depends_on_targets(dep_id, edges)
            if nid in reverse_deps:
                # Avoid duplicate: only report once (smaller ID first)
                if nid < dep_id:
                    issues.append(IntegrityIssue(
                        type="circular_dependency",
                        severity="confirm",
                        node_ids=[nid, dep_id],
                        message=f"Mutual dependency: {nid} depends_on {dep_id} AND {dep_id} depends_on {nid}.",
                        auto_fix=f"Circular reasoning detected: {nid} <-> {dep_id}. These decisions mutually depend on each other. Determine which is foundational and remove the reverse dependency.",
                    ))

    return issues


def _check_evidence_newer_than_decision(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Evidence with high confidence recorded long after the decision it supports (possible confirmation bias)."""
    issues = []
    threshold_days = 30
    confidence_threshold = 0.9

    for edge in edges:
        if edge.get("type") != "informed_by":
            continue

        decision_id = edge.get("from")
        evidence_id = edge.get("to")

        decision = nodes.get(decision_id)
        evidence = nodes.get(evidence_id)

        if decision is None or evidence is None:
            continue
        if decision.get("type") != "decision" or evidence.get("type") != "evidence":
            continue

        ev_confidence = evidence.get("confidence", 0.5)
        if ev_confidence <= confidence_threshold:
            continue

        # Parse created timestamps
        d_created = _parse_timestamp(decision.get("created"))
        e_created = _parse_timestamp(evidence.get("created"))

        if d_created is None or e_created is None:
            continue

        delta_days = (e_created - d_created).days
        if delta_days > threshold_days:
            issues.append(IntegrityIssue(
                type="late_high_confidence_evidence",
                severity="info",
                node_ids=[evidence_id, decision_id],
                message=f"Evidence {evidence_id} (confidence {ev_confidence}) was recorded {delta_days} days after decision {decision_id} it supports.",
                auto_fix=f"Evidence {evidence_id} (confidence {ev_confidence}) was recorded {delta_days} days after decision {decision_id} it supports. This may be confirmation bias. Consider: was this genuinely found later, or recorded to justify an existing choice?",
            ))

    return issues


def _check_orphaned_active_decisions(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Active decisions with ZERO informed_by edges (no evidence at all)."""
    issues = []

    # Build set of decisions that have at least one supporting evidence link
    decisions_with_evidence = set()
    for e in edges:
        if e.get("type") == "informed_by":
            decisions_with_evidence.add(e.get("from"))
        elif e.get("type") == "informs":
            decisions_with_evidence.add(e.get("to"))

    for nid, node in nodes.items():
        if node.get("type") != "decision" or node.get("status") != "active":
            continue

        if nid not in decisions_with_evidence:
            issues.append(IntegrityIssue(
                type="orphaned_decision",
                severity="auto_fix",
                node_ids=[nid],
                message=f"Decision {nid} has no supporting evidence. No informed_by edges exist.",
                auto_fix=f"Decision {nid} has no supporting evidence. Record the reasoning: what evidence supports this choice? Call deg_evidence() with the justification.",
            ))

    return issues


def _check_superseded_still_depended_on(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Active decisions that depends_on a superseded decision."""
    issues = []

    for nid, node in nodes.items():
        if node.get("type") != "decision" or node.get("status") != "active":
            continue

        deps = _get_depends_on_targets(nid, edges)
        for dep_id in deps:
            dep_node = nodes.get(dep_id)
            if dep_node is None:
                continue
            if dep_node.get("status") == "superseded":
                issues.append(IntegrityIssue(
                    type="depends_on_superseded",
                    severity="confirm",
                    node_ids=[nid, dep_id],
                    message=f"Active decision {nid} depends on superseded decision {dep_id}.",
                    auto_fix=f"{nid} depends on superseded {dep_id}. Either update the dependency to {dep_id}'s successor, or re-evaluate if {nid} is still valid without {dep_id}.",
                ))

    return issues


def _check_confidence_inconsistency(nodes: dict, edges: list[dict]) -> list[IntegrityIssue]:
    """Decision's evidence has wildly different confidence levels (spread > 0.5)."""
    issues = []
    spread_threshold = 0.5

    for nid, node in nodes.items():
        if node.get("type") != "decision" or node.get("status") != "active":
            continue

        evidence_ids = _get_informed_by_targets(nid, edges)
        if len(evidence_ids) < 2:
            continue

        confidences = []
        low_conf_evidence = None
        for eid in evidence_ids:
            ev = nodes.get(eid)
            if ev is None:
                continue
            conf = ev.get("confidence")
            if conf is not None:
                confidences.append((conf, eid))

        if len(confidences) < 2:
            continue

        max_conf = max(c for c, _ in confidences)
        min_conf = min(c for c, _ in confidences)

        if max_conf - min_conf > spread_threshold:
            # Find the lowest-confidence evidence for the message
            low_eid = min(confidences, key=lambda x: x[0])
            issues.append(IntegrityIssue(
                type="confidence_inconsistency",
                severity="info",
                node_ids=[nid] + [eid for _, eid in confidences],
                message=f"Decision {nid} rests on mixed-quality evidence (confidence range: {min_conf}-{max_conf}).",
                auto_fix=f"{nid} rests on mixed-quality evidence (confidence range: {min_conf}-{max_conf}). The low-confidence evidence {low_eid[1]} ({low_eid[0]}) weakens the foundation. Consider: find stronger evidence or acknowledge uncertainty.",
            ))

    return issues


def _parse_timestamp(value) -> datetime | None:
    """Parse a timestamp from various formats."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    if isinstance(value, str):
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%SZ"):
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
    return None
