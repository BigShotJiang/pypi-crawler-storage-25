"""Compile markdown decision/evidence files into the .deg/ sidecar graph."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import yaml

from deg.schemas import Decision, Evidence


def parse_frontmatter(path: Path) -> dict | None:
    """Extract YAML frontmatter from a markdown file."""
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    parts = text.split("---", 2)
    if len(parts) < 3:
        return None
    try:
        meta = yaml.safe_load(parts[1])
    except yaml.YAMLError:
        return None
    if not isinstance(meta, dict):
        return None
    meta["_body"] = parts[2].strip()
    meta["_file"] = str(path)
    return meta


def compile_graph(project_root: Path) -> dict:
    """Parse all markdown files, build graph structures, write .deg/ directory."""
    decisions_dir = project_root / "decisions"
    evidence_dir = project_root / "evidence"
    deg_dir = project_root / ".deg"
    deg_dir.mkdir(exist_ok=True)

    nodes: dict[str, dict] = {}
    edges: list[dict] = []
    successors: dict[str, list[str]] = defaultdict(list)
    errors: list[str] = []

    # Parse decisions
    if decisions_dir.exists():
        for md_file in sorted(decisions_dir.glob("*.md")):
            meta = parse_frontmatter(md_file)
            if meta is None:
                errors.append(f"Cannot parse: {md_file}")
                continue
            node_id = meta.get("deg_id", md_file.stem)
            nodes[node_id] = meta

    # Parse evidence
    if evidence_dir.exists():
        for md_file in sorted(evidence_dir.glob("*.md")):
            meta = parse_frontmatter(md_file)
            if meta is None:
                errors.append(f"Cannot parse: {md_file}")
                continue
            node_id = meta.get("deg_id", md_file.stem)
            nodes[node_id] = meta

    # Build edges from relationships
    for node_id, meta in nodes.items():
        # informed_by edges (decision → evidence)
        for target_id in meta.get("informed_by", []):
            edges.append({"from": node_id, "to": target_id, "type": "informed_by"})
            successors[target_id].append(node_id)

        # depends_on edges (decision → decision)
        for target_id in meta.get("depends_on", []):
            edges.append({"from": node_id, "to": target_id, "type": "depends_on"})
            successors[target_id].append(node_id)

        # informs edges (evidence → decision)
        for target_id in meta.get("informs", []):
            edges.append({"from": node_id, "to": target_id, "type": "informs"})
            successors[node_id].append(target_id)

    # Auto-populate depended_on_by
    for node_id, meta in nodes.items():
        meta["depended_on_by"] = successors.get(node_id, [])

    # Validate: check for dangling references
    all_ids = set(nodes.keys())
    for edge in edges:
        if edge["to"] not in all_ids and "/" not in edge["to"]:
            errors.append(f"Dangling reference: {edge['from']} → {edge['to']}")

    # Write compiled artifacts
    nodes_file = deg_dir / "nodes.jsonl"
    with open(nodes_file, "w") as f:
        for nid, n in nodes.items():
            record = {k: v for k, v in n.items() if not k.startswith("_")}
            record["id"] = nid
            f.write(json.dumps(record, default=str) + "\n")

    edges_file = deg_dir / "edges.jsonl"
    with open(edges_file, "w") as f:
        for e in edges:
            f.write(json.dumps(e) + "\n")

    graph_file = deg_dir / "graph.json"
    with open(graph_file, "w") as f:
        json.dump(dict(successors), f, indent=2)

    return {
        "nodes": len(nodes),
        "edges": len(edges),
        "errors": errors,
        "path": str(deg_dir),
    }


def load_compiled(project_root: Path) -> tuple[dict, list[dict], dict[str, list[str]]]:
    """Load the compiled graph from .deg/ directory."""
    deg_dir = project_root / ".deg"

    nodes = {}
    nodes_file = deg_dir / "nodes.jsonl"
    if nodes_file.exists():
        for line in nodes_file.read_text().splitlines():
            if line.strip():
                record = json.loads(line)
                nodes[record["id"]] = record

    edges = []
    edges_file = deg_dir / "edges.jsonl"
    if edges_file.exists():
        for line in edges_file.read_text().splitlines():
            if line.strip():
                edges.append(json.loads(line))

    successors = defaultdict(list)
    graph_file = deg_dir / "graph.json"
    if graph_file.exists():
        raw = json.loads(graph_file.read_text())
        for k, v in raw.items():
            successors[k] = v

    return nodes, edges, dict(successors)
