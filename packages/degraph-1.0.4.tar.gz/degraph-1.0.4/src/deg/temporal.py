"""Bi-temporal validity logic: check if nodes are current, detect supersession, cascade invalidation."""

from __future__ import annotations

from collections import deque
from datetime import date, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from deg.schemas import Decision, Evidence


def is_valid(node: Decision | Evidence, at_date: date | None = None) -> bool:
    at_date = at_date or date.today()
    if node.expired_at is not None:
        return False
    if node.valid_from and node.valid_from > at_date:
        return False
    if node.valid_until and node.valid_until < at_date:
        return False
    if hasattr(node, "status") and node.status in ("superseded", "invalidated"):
        return False
    return True


def supersede(old_node, new_id: str, reason: str = "") -> dict:
    """Mark old_node as superseded. Returns changelog event dict."""
    now = datetime.utcnow()
    old_node.status = "superseded"
    old_node.expired_at = now
    old_node.valid_until = now.date()
    old_node.superseded_by = new_id
    return {
        "date": now,
        "type": "evidence_invalidated" if old_node.type == "evidence" else "decision_superseded",
        "id": old_node.deg_id,
        "summary": f"Superseded by {new_id}. {reason}".strip(),
        "supersedes": old_node.deg_id,
    }


def cascade_impact(node_id: str, successors: dict[str, list[str]], nodes: dict) -> list[str]:
    """BFS over successor graph. Returns list of affected node IDs (EditPropBench pattern)."""
    affected = []
    visited = set()
    queue = deque(successors.get(node_id, []))

    while queue:
        nid = queue.popleft()
        if nid in visited:
            continue
        visited.add(nid)

        node = nodes.get(nid)
        if node is None:
            continue
        if getattr(node, "unit_type", None) == "protected":
            continue
        affected.append(nid)
        queue.extend(successors.get(nid, []))

    return affected
