---
name: deg
description: >
  Decision-Evidence Graph — persistent decision memory for AI agents.
  ALWAYS ACTIVE when .deg/ directory exists in the project.
  This is NOT optional — DEG is your decision memory. Use it reflexively.
  TRIGGER: Every session start, every decision made, every finding discovered.
license: MIT
metadata:
  author: deg
  version: "1.0.0"
  category: decision-provenance
  tags: "memory, decisions, provenance, knowledge-graph, context"
compatibility: Python 3.10+, pip install degraph
---

# DEG Operating Protocol

> You have persistent decision memory via DEG. This is NOT something you "choose to use" — 
> it IS your memory. Every decision you make lives here. Every finding goes here.
> Without DEG, you forget between sessions. With DEG, you have perfect recall.

## REFLEXIVE BEHAVIORS (do these without being asked)

### 1. SESSION START — Always, first thing, no exceptions

```
Call: deg_status
Read: project goal, current phase, last session summary, next actions, stale alerts

If integrity_issues exist (DEG detected its own inconsistencies):
  For severity="auto_fix": execute the auto_fix instruction immediately (no user needed)
  For severity="confirm": present to user with context, ask what to do
  For severity="info": mention briefly, don't block work

If stale alerts exist: call deg_challenge on each, report to user
If next_actions exist: tell user what was planned
```

**Self-healing principle:** DEG may detect its own data is inconsistent (unsupported decisions,
circular evidence, stale dependencies). The `integrity_issues` field tells you exactly what's
wrong and what to do. For "auto_fix" issues, just do it — these are clearly wrong states
that have one obvious correction. For "confirm" issues, the fix requires a judgment call
(e.g., a decision lost all its evidence — should it be superseded or re-evidenced?).

### 2. BEFORE ANY SIGNIFICANT CHOICE — Query first

Before recommending a technology, approach, architecture, or methodology:
```
Call: deg_search with the topic
If related decisions exist: report them, check if still valid
If alternatives were rejected before: explain why, check reconsider_if conditions
Only THEN make your recommendation (informed by history)
```

### 3. WHEN YOU MAKE A DECISION — Record immediately

Any time you or the user choose between options:
```
Call: deg_evidence (record the finding that supports the choice)
Call: deg_decide (record the choice with: evidence, alternatives rejected, reconsider_if, scope)
```

Decisions include: framework choices, architecture decisions, methodology selections,
tool selections, approach pivots, scope changes, priority shifts.

### 4. WHEN YOU DISCOVER SOMETHING — Record immediately

Any new finding, benchmark result, paper discovery, test result:
```
Call: deg_evidence (claim, source, confidence, source_type)
If it contradicts existing evidence: use invalidates parameter
```

### 5. WHEN ASKED "WHY" — Trace provenance

```
Call: deg_search (find the decision)
Call: deg_trace (show full evidence chain)
Call: deg_challenge (show current validity + alternatives)
Present: decision ← evidence ← source, plus what was rejected and when to reconsider
```

### 6. WHEN ASKED "WHAT IF WE CHANGE X" — Show impact

```
Call: deg_impact (show all downstream dependencies)
Report: what breaks, what needs re-evaluation
```

### 7. SESSION END — Save state

```
Call: deg_close_session (summary of what happened, next actions, your agent name)
```

## THE CLAUDE.md + DEG INTEGRATION MODEL

DEG replaces the need for these .md file sections:
- "Why we chose X" → now in deg_trace
- "Alternatives considered" → now in deg_challenge
- "What's outdated" → now in stale_alerts (automatic)
- "Session handoff notes" → now in STATE.yaml (automatic)
- "Context maintenance protocol" → DEG IS the protocol

You still need a minimal CLAUDE.md for:
- Project goal (one sentence)
- Current phase (one line)
- File structure overview (where code lives)
- Reproduction commands (how to run things)
- Key metrics (numbers that matter)

Everything else — every WHY, every alternative, every "is this still valid?" — lives in DEG.

## TRUST MODEL (your confidence matters)

- 0.3 = guess/intuition
- 0.5 = seems right but unverified
- 0.7 = reasonable evidence supports this
- 0.85 = strong evidence, tested
- 0.95 = experimentally confirmed, replicated

Low-confidence evidence CANNOT override high-confidence. The system enforces this.
If you have 0.3 confidence on something that contradicts a 0.9 finding — record it but don't invalidate.

## WHAT THIS GIVES THE NEXT AGENT

When the next session starts, the agent gets from deg_status:
- Exactly where the project stands
- What decisions are active and valid
- What's stale and needs re-checking
- What the last agent accomplished
- What was planned as next steps

From deg_search / deg_trace:
- Full history of every decision ever made
- Why each was chosen over alternatives
- What evidence supported it
- When to reconsider

This is COMPLETE session continuity. No drift. No ambiguity. No repeated research.

## SESSION-START CONFLICT RESOLUTION PROTOCOL

When `deg_status` returns stale_alerts at session start, follow this protocol:

### Step 1: Challenge each stale decision
```
For each stale alert:
  Call: deg_challenge(id)
  Read: triggers_fired, evidence_health, alternatives, reconsider_if conditions
```

### Step 2: Assess severity
- **Critical** (WLNK < 0.4 or evidence superseded): Tell user immediately, suggest re-research
- **Moderate** (WLNK 0.4-0.7 or temporal trigger fired): Note for user, offer to investigate
- **Low** (WLNK > 0.7, just past revalidation window): Mention briefly, continue with planned work

### Step 3: Suggest research for critical/moderate items
Tell the user: "Decision [title] is stale. The reconsider_if condition was: [condition]. Should I research whether better alternatives exist now?"

If user agrees:
- Search web for current state (if TinyFish available: `tinyfish search "topic"`)
- Check Semantic Scholar for new papers (if query is academic)
- Record findings as new evidence: `deg_evidence(claim, source, confidence)`
- If new evidence contradicts: `deg_evidence(claim, source, confidence, invalidates=old_id)`
- If decision still valid: update last_verified timestamp

## RESEARCH PROTOCOL (when investigating or revalidating)

### Quick lookup (default — use Claude's own knowledge + available tools)
1. Think about what you know about the topic
2. If web search available (TinyFish): `tinyfish search "query"` → `tinyfish fetch <url>`
3. Record findings: `deg_evidence(claim, source="web/tinyfish", confidence=X)`

### Academic research (when decision cites papers or needs literature backing)
1. If Semantic Scholar available: query `https://api.semanticscholar.org/graph/v1/paper/search?query=...`
2. Check citations of papers your decision is based on (are there newer contradicting findings?)
3. Record: `deg_evidence(claim, source="literature/arxiv:XXXX.XXXXX", confidence=X)`

### Deep research (when user explicitly requests thorough investigation)
1. If ML-Intern is available (user installed separately): suggest user run it
2. Otherwise: use TinyFish + S2 API iteratively (search → fetch → follow references → synthesize)
3. Record each finding as evidence with proper attribution

### What confidence to assign
- 0.3 = found on a blog/forum, unverified
- 0.5 = found in documentation, seems right
- 0.7 = found in peer-reviewed paper or official benchmarks
- 0.85 = multiple sources agree, well-established
- 0.95 = you ran the experiment yourself or verified directly

## UNDERSTAND-ANYTHING INTEGRATION

When the Understand-Anything plugin is installed alongside DEG, use these concrete patterns:

### Pattern 1: Decision superseded → What code needs changing?

When a decision is superseded by a better alternative:
```
1. Record the new decision: deg_decide("Switch to Valkey", invalidates=redis_evidence)
2. Ask: "What code is affected by this change?"
3. Use UA: /understand-explain or grep for references to the old choice
4. Report to user: "These files reference the superseded choice: [list]"
5. Optionally: /understand-diff after changes to verify nothing missed
```

### Pattern 2: Code changed → Which decisions are affected?

When significant code refactoring happens:
```
1. Run: deg check --git (detects files referenced by decisions that changed)
2. If decisions flagged: "D-003 references src/auth.py which was modified"
3. Challenge affected decisions: deg_challenge(D-003)
4. If the code change invalidates the decision's premise: supersede it
5. If still valid: acknowledge (the decision survives the refactor)
```

### Pattern 3: "Why is the code like this?" → Code context + Decision provenance

When someone asks about code structure:
```
1. UA explains WHAT: /understand-explain src/cache.py → "Redis cache layer"
2. DEG explains WHY: deg_search("redis") or deg_search("cache") → finds decision
3. DEG shows ALTERNATIVES: deg_trace(decision_id) → full evidence chain
4. Combined answer: "This file exists because of D-005 (chose Redis over Memcached 
   because [evidence]). Reconsider if: [condition]."
```

### Pattern 4: Architecture review → Cross-reference structure with decisions

For periodic health checks:
```
1. UA shows current state: /understand → architecture layers, file counts, complexity
2. DEG shows decision state: deg timeline --scope=architecture (or deg_search)
3. For each architecture decision: deg challenge → health + alternatives
4. Cross-reference: Has the codebase outgrown a decision's assumptions?
   Example: "Decision D-002 assumed <5 services. UA shows 12 services now.
   reconsider_if: 'component count > 10' — TRIGGERED."
5. Present unified report: what decisions are stale given current code structure
```

### Pattern 5: Decision recording WITH code references

When recording a decision about a specific part of the codebase:
```
deg_decide("Use connection pooling for DB",
    evidence=[e_id],
    scope="database",
    context="Affects src/db/pool.py and config/database.yml",
    references=["src/db/pool.py", "config/database.yml"]  # enables git staleness tracking
)
```

The `references` field (list of file paths) enables `deg check --git` to detect when those files change, automatically flagging the decision for review.

### The fundamental split
- **DEG:** WHY was this chosen? WHAT alternatives? WHEN to reconsider? WHAT decisions break?
- **UA:** WHAT does code look like? WHERE are components? HOW do they connect? WHAT's the blast radius?
- **Together:** "This code exists because of this decision, which was based on this evidence, and if we change it, these other decisions and these code files are affected."

## TINYFISH INTEGRATION (external world monitoring)

When checking if the world has changed since a decision was made:

### Pattern: Technology decision revalidation
```
1. deg digest → "D-007 (Use library X v2) is past revalidation"
2. You: "Should I check if the landscape changed?"
3. tinyfish search "library X v3 release 2026" → finds release announcement
4. tinyfish fetch <changelog-url> --format markdown → reads changes
5. If relevant: deg_evidence("Library X v3 released: [key changes]", source="changelog-url", confidence=0.85)
6. If breaking change affects our use case: deg_evidence(..., invalidates=old_evidence_id)
7. Cascade fires → downstream decisions flagged
```

### Pattern: Competitor/alternative monitoring
```
1. Decision has reconsider_if: "alternative Y becomes production-ready"
2. tinyfish search "Y production release 2026"
3. If found: deg_evidence("Y is now production-ready as of [date]", source=url)
4. Claude: "The reconsider_if condition for D-003 has triggered. Y is now available.
   Should we re-evaluate this decision?"
```

### Pattern: Documentation drift check
```
1. Decision references official docs as evidence (e.g., "API supports feature X")
2. tinyfish fetch <docs-url> → compare with what was recorded
3. If docs changed significantly: note potential drift
4. Claude judges: does the change affect our decision or not?
```

### When TinyFish is NOT available
Fall back to:
- Claude's own knowledge (with lower confidence: 0.5)
- Ask user to check manually
- Record as open_question in continue_research

## CHANGELOG AWARENESS

DEG maintains `.deg/CHANGELOG.yaml` automatically. When asked about project history:
- Use `deg_search` for decisions about a topic
- Use `deg_trace` for the full chain of evidence
- CHANGELOG shows the raw timeline of all writes

Every write (decide, evidence, reject, close) appends to CHANGELOG. This is the immutable audit trail.

## CONSTRAINT CHECKING (v1.1)

DEG now automatically detects contradictions on every write. When you call `deg_decide` or `deg_evidence`:
- Contradiction detection runs AFTER the write (never blocks writes)
- If conflicts found: stored in `.deg/contradictions.json`
- `deg_status` includes contradiction count
- `deg_challenge` shows contradictions relevant to that decision

Additionally, use these commands proactively:
- `deg check` — run full constraint validation (dangling refs, cycles, cardinality, valid status)
- `deg check --git` — also check if files referenced by decisions have changed
- `deg maintenance` — find orphans, duplicates, cycles, stale unreviewed decisions

### When to run checks
- **Session start** (if graph has >20 nodes): suggest `deg check` to user
- **Before major decisions**: `deg check` ensures graph is healthy first
- **Periodically**: suggest `deg maintenance` if graph has >50 nodes and hasn't been maintained in 2+ weeks

### Handling contradictions
When `deg_status` shows contradictions:
1. Read the contradiction details (type, affected decisions, message)
2. Present to user: "Two decisions conflict: [details]. Which should be superseded?"
3. User decides → record new decision superseding the wrong one
4. Contradiction auto-resolves (superseded decisions don't trigger conflicts)

### Dismissing false positives
When maintenance or contradiction findings are NOT relevant to the project:
1. User says "ignore that" or "not relevant" or "false positive"
2. Record dismissal so it doesn't resurface next session
3. Dismissed findings won't appear in future `deg maintenance` or `deg check` runs

Never dismiss without user confirmation. Always explain what's being dismissed and why.

## INTELLIGENT INGEST (Claude as the ingest engine)

When a project has existing documentation with decisions embedded in prose:

DO NOT rely on `deg ingest` (regex-based, works only on simple ADR-format docs).

Instead, YOU are the intelligent ingest engine:
1. Read the existing document (IMPLEMENTATION.md, ARCHITECTURE.md, etc.)
2. Identify decisions: technology choices, methodology selections, architecture decisions, scope changes, pivots
3. For each decision found: call `deg_decide` with proper alternatives + reconsider_if
4. For each finding/evidence: call `deg_evidence` with source + confidence
5. Link evidence to decisions via the `evidence=[ids]` parameter

This is BETTER than regex because you understand context, implicit decisions, and can extract proper alternatives from prose like "we considered X but chose Y because Z."

## SEMANTIC CONTRADICTION DETECTION (Claude as the judge)

Rule-based contradiction detection catches STRUCTURAL conflicts (same scope, temporal overlap).
But SEMANTIC conflicts require understanding:

When challenging a decision (deg_challenge):
1. Read the evidence claims that support the decision
2. Ask: "Does any evidence actually UNDERMINE the decision it supports?"
3. Example: evidence says "approach X fails on domain Y" but the decision says "use approach X"
   → This is a TENSION that rules can't catch. YOU catch it.
4. Report to user: "Evidence E-xxx documents a failure mode of Decision D-yyy. Current mitigation status unknown."

When recording evidence that seems to conflict with existing decisions:
1. After recording, check: does this new evidence weaken an existing decision?
2. If yes: mention to user (don't auto-invalidate unless confidence is high enough)

## RECORDING OBSERVATIONS vs DECISION-SUPPORTING EVIDENCE

When recording experimental results or research findings:

- If the finding DIRECTLY supports or informs a specific decision → use `informs=[decision_id]`
- If the finding is a STANDALONE OBSERVATION (experiment result, benchmark, discovery) that doesn't directly support any current decision → use `source_type="observation"`

Standalone observations are NOT orphans — they're legitimate research outputs.
DEG won't flag them in maintenance.

Examples of observations (use source_type="observation"):
- "Run 8 achieved 0.92 accuracy on the test set"
- "Biology domain shows 40% degradation"  
- "Model X takes 3x longer than Model Y"

Examples of decision-supporting evidence (use informs=[id]):
- "PostgreSQL handles our ACID requirements" → informs database decision
- "CORAL provides Docker isolation" → informs infrastructure decision
