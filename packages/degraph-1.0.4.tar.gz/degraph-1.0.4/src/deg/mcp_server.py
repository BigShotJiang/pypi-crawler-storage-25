"""MCP Server: expose DEG operations as Model Context Protocol tools.

Start with: deg serve
Any MCP-compatible client (Claude, Cursor, Codex) can then use these tools.
"""

from __future__ import annotations

import json
from pathlib import Path

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
    HAS_MCP = True
except ImportError:
    HAS_MCP = False


def create_server(project_root: str | Path | None = None) -> "Server":
    if not HAS_MCP:
        raise ImportError("MCP not installed. Run: pip install deg[mcp]")

    from deg.graph import Graph

    server = Server("deg")
    g = Graph(project_root)

    TOOLS = [
        Tool(
            name="deg_status",
            description="Get project state: goal, phase, active decisions, stale alerts, next actions. Call this first in every new session.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        ),
        Tool(
            name="deg_decide",
            description="Record a decision with evidence links, rejected alternatives, and revalidation triggers.",
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "What was decided"},
                    "evidence": {"type": "array", "items": {"type": "string"}, "description": "Evidence IDs that inform this decision"},
                    "alternatives": {"type": "array", "items": {"type": "object"}, "description": "Rejected options with 'option', 'why', 'reconsider_if'"},
                    "revalidation_days": {"type": "integer", "default": 30},
                    "scope": {"type": "string"},
                    "context": {"type": "string"},
                },
                "required": ["title"],
            },
        ),
        Tool(
            name="deg_evidence",
            description="Record a research finding or experimental result with source and confidence.",
            inputSchema={
                "type": "object",
                "properties": {
                    "claim": {"type": "string", "description": "What was found/observed"},
                    "source": {"type": "string", "description": "Where this came from (paper, experiment, observation)"},
                    "confidence": {"type": "number", "default": 0.8},
                    "source_type": {"type": "string", "enum": ["literature", "experiment", "observation", "derived"]},
                    "invalidates": {"type": "string", "description": "Evidence ID this supersedes (if any)"},
                    "informs": {"type": "array", "items": {"type": "string"}, "description": "Decision IDs this informs"},
                },
                "required": ["claim"],
            },
        ),
        Tool(
            name="deg_search",
            description="Semantic + keyword + graph hybrid search across all decisions and evidence.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "k": {"type": "integer", "default": 5},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="deg_trace",
            description="Trace the full provenance chain for a decision: what evidence and upstream decisions informed it.",
            inputSchema={
                "type": "object",
                "properties": {"node_id": {"type": "string"}},
                "required": ["node_id"],
            },
        ),
        Tool(
            name="deg_challenge",
            description="Revalidation assessment: check if a decision is still valid based on evidence freshness, triggers, and alternatives.",
            inputSchema={
                "type": "object",
                "properties": {"decision_id": {"type": "string"}},
                "required": ["decision_id"],
            },
        ),
        Tool(
            name="deg_impact",
            description="Cascade analysis: what downstream decisions are affected if this node changes.",
            inputSchema={
                "type": "object",
                "properties": {"node_id": {"type": "string"}},
                "required": ["node_id"],
            },
        ),
        Tool(
            name="deg_continue",
            description="Get research continuation directives: what was already searched, what to search next, open questions.",
            inputSchema={
                "type": "object",
                "properties": {"decision_id": {"type": "string"}},
                "required": ["decision_id"],
            },
        ),
        Tool(
            name="deg_close_session",
            description="Close session and update STATE.yaml for handoff to next session.",
            inputSchema={
                "type": "object",
                "properties": {
                    "summary": {"type": "string", "description": "What was accomplished this session"},
                    "next_actions": {"type": "array", "items": {"type": "string"}},
                    "agent": {"type": "string"},
                },
                "required": ["summary"],
            },
        ),
    ]

    @server.list_tools()
    async def list_tools():
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        try:
            if name == "deg_status":
                result = g.status()
            elif name == "deg_decide":
                deg_id = g.decide(
                    title=arguments["title"],
                    evidence=arguments.get("evidence"),
                    alternatives=arguments.get("alternatives"),
                    revalidation_days=arguments.get("revalidation_days", 30),
                    scope=arguments.get("scope", ""),
                    context=arguments.get("context", ""),
                )
                result = {"id": deg_id, "status": "recorded"}
            elif name == "deg_evidence":
                deg_id = g.evidence(
                    claim=arguments["claim"],
                    source=arguments.get("source", ""),
                    confidence=arguments.get("confidence", 0.8),
                    source_type=arguments.get("source_type", "literature"),
                    invalidates=arguments.get("invalidates"),
                    informs=arguments.get("informs"),
                )
                result = {"id": deg_id, "status": "recorded"}
            elif name == "deg_search":
                result = g.search(arguments["query"], k=arguments.get("k", 5))
            elif name == "deg_trace":
                result = g.trace(arguments["node_id"])
            elif name == "deg_challenge":
                result = g.challenge(arguments["decision_id"])
            elif name == "deg_impact":
                result = g.impact(arguments["node_id"])
            elif name == "deg_continue":
                result = g.continue_research(arguments["decision_id"])
            elif name == "deg_close_session":
                result = g.close_session(
                    summary=arguments["summary"],
                    next_actions=arguments.get("next_actions"),
                    agent=arguments.get("agent", ""),
                )
            else:
                result = {"error": f"Unknown tool: {name}"}

            return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

        except Exception as e:
            return [TextContent(type="text", text=json.dumps({"error": str(e)}))]

    return server


async def run_server(project_root: str | Path | None = None):
    server = create_server(project_root)
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())
