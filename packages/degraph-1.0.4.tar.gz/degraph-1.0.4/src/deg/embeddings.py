"""Embedding module: lazy-loaded sentence-transformers + IDMap2(FlatL2) with content hashing.

Key design choices (traced to research):
- IDMap2(IndexFlatL2): O(1) delete, exact recall=1.0, 0.46ms at 10K (Scale report §2)
- Content hashing: 100x embedding savings by skipping unchanged files (Cursor pattern)
- NOT HNSW: has no remove_ids, incompatible with supersession/expiry
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

_MODEL = None
_MODEL_NAME = "all-MiniLM-L6-v2"
EMBEDDING_DIM = 384


def _get_model():
    global _MODEL
    if _MODEL is None:
        from sentence_transformers import SentenceTransformer
        _MODEL = SentenceTransformer(_MODEL_NAME)
    return _MODEL


def embed_text(text: str) -> np.ndarray:
    model = _get_model()
    return model.encode(text, normalize_embeddings=True).astype(np.float32)


def embed_texts(texts: list[str]) -> np.ndarray:
    if not texts:
        return np.empty((0, EMBEDDING_DIM), dtype=np.float32)
    model = _get_model()
    return model.encode(texts, normalize_embeddings=True, show_progress_bar=False).astype(np.float32)


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:16]


def build_index(project_root: Path, nodes: dict) -> dict:
    """Build/update FAISS IDMap2 index with content-hash-based incremental updates.

    Only re-embeds nodes whose content hash has changed. Returns stats.
    """
    import faiss

    deg_dir = project_root / ".deg"
    deg_dir.mkdir(exist_ok=True)

    hash_file = deg_dir / "hashes.json"
    old_hashes: dict[str, str] = {}
    if hash_file.exists():
        old_hashes = json.loads(hash_file.read_text())

    # Determine what changed
    texts_to_embed = {}
    current_hashes = {}
    for nid, node in nodes.items():
        text = _node_text(node)
        if not text:
            continue
        h = content_hash(text)
        current_hashes[nid] = h
        if old_hashes.get(nid) != h:
            texts_to_embed[nid] = text

    # Load or create index
    index_path = deg_dir / "index.faiss"
    ids_path = deg_dir / "embedding_ids.json"
    id_map_path = deg_dir / "id_to_faiss.json"

    # We always rebuild from scratch since IDMap2 + FlatL2 rebuild is 3ms at 10K
    # (Scale report: "index rebuild cost is literally irrelevant")
    # This is simpler than incremental and just as fast
    all_texts = []
    all_ids = []
    for nid, node in nodes.items():
        text = _node_text(node)
        if text:
            all_ids.append(nid)
            all_texts.append(text)

    if not all_texts:
        hash_file.write_text(json.dumps(current_hashes))
        return {"embedded": 0, "skipped": 0, "total": 0}

    # Only embed changed nodes, reuse cached embeddings for unchanged
    embeddings_cache_path = deg_dir / "embeddings_cache.json"
    cached_embeddings: dict[str, list[float]] = {}
    if embeddings_cache_path.exists():
        try:
            cached_embeddings = json.loads(embeddings_cache_path.read_text())
        except json.JSONDecodeError:
            cached_embeddings = {}

    # Embed only what changed
    need_embedding = [nid for nid in all_ids if nid in texts_to_embed]
    if need_embedding:
        new_texts = [texts_to_embed[nid] for nid in need_embedding]
        new_vecs = embed_texts(new_texts)
        for nid, vec in zip(need_embedding, new_vecs):
            cached_embeddings[nid] = vec.tolist()

    # Build full embedding matrix from cache
    final_vecs = []
    final_ids = []
    for i, nid in enumerate(all_ids):
        if nid in cached_embeddings:
            final_vecs.append(cached_embeddings[nid])
            final_ids.append(i)

    if not final_vecs:
        hash_file.write_text(json.dumps(current_hashes))
        return {"embedded": len(need_embedding), "skipped": len(all_ids) - len(need_embedding), "total": len(all_ids)}

    # Build IDMap2(FlatL2) index — exact recall, O(1) delete, 3ms at 10K
    embeddings_np = np.array(final_vecs, dtype=np.float32)
    flat_index = faiss.IndexFlatL2(EMBEDDING_DIM)
    index = faiss.IndexIDMap2(flat_index)
    ids_np = np.array(final_ids, dtype=np.int64)
    index.add_with_ids(embeddings_np, ids_np)

    # Save
    faiss.write_index(index, str(index_path))
    ids_path.write_text(json.dumps(all_ids))
    hash_file.write_text(json.dumps(current_hashes))
    embeddings_cache_path.write_text(json.dumps(cached_embeddings))

    return {
        "embedded": len(need_embedding),
        "skipped": len(all_ids) - len(need_embedding),
        "total": len(all_ids),
    }


def load_index(project_root: Path):
    """Load FAISS IDMap2 index and ID mapping."""
    import faiss

    deg_dir = project_root / ".deg"
    index_path = deg_dir / "index.faiss"
    ids_path = deg_dir / "embedding_ids.json"

    if not index_path.exists() or not ids_path.exists():
        return None, None

    index = faiss.read_index(str(index_path))
    node_ids = json.loads(ids_path.read_text())
    return index, node_ids


def semantic_search(query: str, project_root: Path, k: int = 10) -> list[tuple[str, float]]:
    """Search IDMap2 index. Returns (node_id, score) tuples."""
    index, node_ids = load_index(project_root)
    if index is None:
        return []

    query_vec = embed_text(query).reshape(1, -1)
    distances, indices = index.search(query_vec, min(k, len(node_ids)))

    results = []
    for dist, idx in zip(distances[0], indices[0]):
        if idx < 0 or idx >= len(node_ids):
            continue
        score = 1.0 / (1.0 + float(dist))
        results.append((node_ids[idx], score))

    return results


def _node_text(node: dict) -> str:
    """Extract searchable text from a node."""
    parts = []
    if node.get("title"):
        parts.append(node["title"])
    if node.get("claim"):
        parts.append(node["claim"])
    if node.get("context"):
        parts.append(node["context"])
    if node.get("scope"):
        parts.append(node["scope"])
    for alt in node.get("rejected", []):
        if isinstance(alt, dict):
            parts.append(alt.get("option", ""))
            parts.append(alt.get("why", ""))
    return " ".join(parts)
