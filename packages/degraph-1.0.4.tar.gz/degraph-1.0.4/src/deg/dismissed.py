"""Dismissal memory — findings that were seen and explicitly dismissed don't resurface."""

import hashlib
import json
from pathlib import Path


def _finding_hash(category: str, node_ids: list[str], message: str) -> str:
    """Stable hash for a finding so it can be recognized across runs."""
    content = f"{category}:{sorted(node_ids)}:{message}"
    return hashlib.sha256(content.encode()).hexdigest()[:12]


def load_dismissed(project_root: Path) -> set[str]:
    """Load set of dismissed finding hashes."""
    path = project_root / ".deg" / "dismissed.json"
    if not path.exists():
        return set()
    try:
        data = json.loads(path.read_text())
        return set(data.get("dismissed", []))
    except (json.JSONDecodeError, ValueError):
        return set()


def dismiss_finding(project_root: Path, category: str, node_ids: list[str], message: str) -> str:
    """Dismiss a finding. Returns the hash that was dismissed."""
    h = _finding_hash(category, node_ids, message)
    path = project_root / ".deg" / "dismissed.json"
    dismissed = load_dismissed(project_root)
    dismissed.add(h)
    path.write_text(json.dumps({"dismissed": sorted(dismissed)}, indent=2))
    return h


def is_dismissed(project_root: Path, category: str, node_ids: list[str], message: str) -> bool:
    """Check if a finding has been dismissed."""
    h = _finding_hash(category, node_ids, message)
    return h in load_dismissed(project_root)


def filter_dismissed(project_root: Path, findings: list) -> list:
    """Remove dismissed findings from a list. Findings must have .category, .node_ids, .message."""
    dismissed = load_dismissed(project_root)
    return [f for f in findings if _finding_hash(f.category, f.node_ids, f.message) not in dismissed]
