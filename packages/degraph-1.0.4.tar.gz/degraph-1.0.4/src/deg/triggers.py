"""Evaluate revalidation triggers: temporal_expiry, dependency_change, metric_threshold, context_drift."""

from __future__ import annotations

from datetime import date
from typing import Any


def evaluate_triggers(node, nodes: dict, metrics: dict[str, float] | None = None) -> list[dict]:
    """Check all revalidation triggers for a node. Returns list of fired trigger dicts."""
    revalidation = getattr(node, "revalidation", None)
    if not revalidation:
        return []

    today = date.today()
    fired = []

    for trigger in revalidation.triggers:
        result = _check_trigger(trigger, revalidation, today, nodes, metrics)
        if result:
            fired.append(result)

    return fired


def _check_trigger(trigger, revalidation, today: date, nodes: dict, metrics: dict | None) -> dict | None:
    t = trigger.type

    if t == "temporal_expiry":
        if trigger.review_after_days:
            days_since = (today - revalidation.last_verified).days
            if days_since > trigger.review_after_days:
                return {
                    "trigger_type": t,
                    "reason": f"{days_since} days since last verification (threshold: {trigger.review_after_days})",
                    "severity": "medium",
                }

    elif t == "dependency_change":
        for dep_id in trigger.watch:
            dep = nodes.get(dep_id)
            if dep is None:
                continue
            status = getattr(dep, "status", None)
            if status in ("invalidated", "superseded"):
                return {
                    "trigger_type": t,
                    "reason": f"Dependency {dep_id} is {status}",
                    "severity": "high",
                }

    elif t == "metric_threshold":
        if metrics and trigger.metric and trigger.metric in metrics:
            val = metrics[trigger.metric]
            ops = {"gt": lambda a, b: a > b, "lt": lambda a, b: a < b, "eq": lambda a, b: a == b}
            op_fn = ops.get(trigger.operator or "gt", ops["gt"])
            if op_fn(val, trigger.threshold or 0):
                return {
                    "trigger_type": t,
                    "reason": f"{trigger.metric}={val} {trigger.operator} {trigger.threshold}",
                    "severity": "high",
                }

    elif t == "context_drift":
        pass  # Phase 5: requires embedding comparison

    return None


def compute_stale_alerts(nodes: dict, all_nodes: dict, metrics: dict | None = None) -> list[dict]:
    """Scan all nodes and return those with fired triggers."""
    alerts = []
    for nid, node in nodes.items():
        status = getattr(node, "status", "active")
        if status not in ("active",):
            continue
        fired = evaluate_triggers(node, all_nodes, metrics)
        if fired:
            alerts.append({"id": nid, "triggers": fired})
    return alerts
