"""Graph constraint checker for DEG (Decision-Evidence Graph).

Validates structural integrity of a decision graph stored as compiled dicts.
Pure Python — zero external imports beyond stdlib.
"""

from __future__ import annotations

import re
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class Violation:
    check: str          # e.g., "cardinality", "acyclic_supersedes"
    severity: str       # "error", "warning", "info"
    node_ids: list[str] = field(default_factory=list)  # affected nodes
    message: str = ""   # human-readable explanation


# --- ID format patterns ---

_DECISION_ID_RE = re.compile(r"^D-\d{8}-\d{3}$")
_EVIDENCE_ID_RE = re.compile(r"^E-\d{8}-\d{3}$")

_VALID_STATUSES = {"active", "proposed", "accepted", "superseded", "deprecated", "under_review"}


# --- Individual checks ---


def check_cardinality(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Accepted decisions must have >= 1 evidence (via informed_by edge)."""
    violations: list[Violation] = []

    # Collect nodes that receive an informed_by edge
    informed_targets: set[str] = set()
    for edge in edges:
        if edge.get("type") == "informed_by":
            informed_targets.add(edge["from"])

    for nid, node in nodes.items():
        if node.get("type") == "decision" and node.get("status") == "accepted":
            if nid not in informed_targets:
                violations.append(Violation(
                    check="cardinality",
                    severity="error",
                    node_ids=[nid],
                    message=f"Accepted decision '{nid}' has no informed_by evidence edge.",
                ))
    return violations


def check_valid_status(nodes: dict[str, dict]) -> list[Violation]:
    """Status must be in the allowed set."""
    violations: list[Violation] = []
    for nid, node in nodes.items():
        status = node.get("status")
        if status and status not in _VALID_STATUSES:
            violations.append(Violation(
                check="valid_status",
                severity="error",
                node_ids=[nid],
                message=f"Node '{nid}' has invalid status '{status}'. Must be one of {_VALID_STATUSES}.",
            ))
    return violations


def check_id_format(nodes: dict[str, dict]) -> list[Violation]:
    """Decision IDs match D-YYYYMMDD-NNN, evidence IDs match E-YYYYMMDD-NNN."""
    violations: list[Violation] = []
    for nid, node in nodes.items():
        deg_id = node.get("deg_id", nid)
        ntype = node.get("type")
        if ntype == "decision":
            if not _DECISION_ID_RE.match(deg_id):
                violations.append(Violation(
                    check="id_format",
                    severity="error",
                    node_ids=[nid],
                    message=f"Decision node '{nid}' has invalid ID format '{deg_id}'. Expected D-YYYYMMDD-NNN.",
                ))
        elif ntype == "evidence":
            if not _EVIDENCE_ID_RE.match(deg_id):
                violations.append(Violation(
                    check="id_format",
                    severity="error",
                    node_ids=[nid],
                    message=f"Evidence node '{nid}' has invalid ID format '{deg_id}'. Expected E-YYYYMMDD-NNN.",
                ))
    return violations


def check_dangling_edges(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """All edge source/target must exist in nodes."""
    violations: list[Violation] = []
    node_ids = set(nodes.keys())
    for edge in edges:
        src = edge.get("from", "")
        tgt = edge.get("to", "")
        missing: list[str] = []
        if src not in node_ids:
            missing.append(src)
        if tgt not in node_ids:
            missing.append(tgt)
        if missing:
            violations.append(Violation(
                check="dangling_edges",
                severity="error",
                node_ids=missing,
                message=f"Edge '{src}' -> '{tgt}' references non-existent node(s): {missing}.",
            ))
    return violations


def _has_cycle_iterative(adj: dict[str, list[str]]) -> list[str] | None:
    """Iterative DFS cycle detection. Returns cycle node IDs or None."""
    WHITE, GRAY, BLACK = 0, 1, 2
    color: dict[str, int] = defaultdict(int)

    for start in adj:
        if color[start] != WHITE:
            continue
        stack: list[tuple[str, int]] = [(start, 0)]
        path: list[str] = []

        while stack:
            node, idx = stack.pop()

            if idx == 0:
                if color[node] == GRAY:
                    # Found cycle — collect nodes in current path from this node
                    cycle_start = path.index(node) if node in path else len(path)
                    return path[cycle_start:] + [node]
                if color[node] == BLACK:
                    continue
                color[node] = GRAY
                path.append(node)
            else:
                # Returning from children — just continue
                pass

            neighbors = adj.get(node, [])
            if idx < len(neighbors):
                # Push current node back with next index
                stack.append((node, idx + 1))
                child = neighbors[idx]
                if color[child] == GRAY:
                    cycle_start = path.index(child) if child in path else len(path)
                    return path[cycle_start:] + [child]
                elif color[child] == WHITE:
                    stack.append((child, 0))
            else:
                color[node] = BLACK
                if path and path[-1] == node:
                    path.pop()

    return None


def check_acyclic_supersedes(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Supersedes edges form a DAG (iterative DFS, no recursion)."""
    violations: list[Violation] = []
    adj: dict[str, list[str]] = defaultdict(list)
    for edge in edges:
        if edge.get("type") == "supersedes":
            adj[edge["from"]].append(edge["to"])

    cycle = _has_cycle_iterative(adj)
    if cycle:
        violations.append(Violation(
            check="acyclic_supersedes",
            severity="error",
            node_ids=cycle,
            message=f"Cycle detected in supersedes edges: {' -> '.join(cycle)}.",
        ))
    return violations


def check_acyclic_depends(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Depends_on edges form a DAG (warning only, not error)."""
    violations: list[Violation] = []
    adj: dict[str, list[str]] = defaultdict(list)
    for edge in edges:
        if edge.get("type") == "depends_on":
            adj[edge["from"]].append(edge["to"])

    cycle = _has_cycle_iterative(adj)
    if cycle:
        violations.append(Violation(
            check="acyclic_depends",
            severity="warning",
            node_ids=cycle,
            message=f"Cycle detected in depends_on edges: {' -> '.join(cycle)}. This may indicate circular reasoning.",
        ))
    return violations


def check_no_self_loops(edges: list[dict]) -> list[Violation]:
    """No edge where source == target."""
    violations: list[Violation] = []
    for edge in edges:
        src = edge.get("from", "")
        tgt = edge.get("to", "")
        if src == tgt and src:
            violations.append(Violation(
                check="no_self_loops",
                severity="error",
                node_ids=[src],
                message=f"Self-loop detected on node '{src}' (edge type: '{edge.get('type', '?')}').",
            ))
    return violations


def check_depends_on_valid(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Active decisions should not depends_on superseded decisions."""
    violations: list[Violation] = []
    for edge in edges:
        if edge.get("type") == "depends_on":
            src = edge["from"]
            tgt = edge["to"]
            src_node = nodes.get(src, {})
            tgt_node = nodes.get(tgt, {})
            if src_node.get("status") == "active" and tgt_node.get("status") == "superseded":
                violations.append(Violation(
                    check="depends_on_valid",
                    severity="error",
                    node_ids=[src, tgt],
                    message=f"Active decision '{src}' depends on superseded decision '{tgt}'. Update dependency.",
                ))
    return violations


def check_referential_integrity(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Every informed_by/depends_on target exists in nodes."""
    violations: list[Violation] = []
    node_ids = set(nodes.keys())
    for edge in edges:
        etype = edge.get("type", "")
        if etype in ("informed_by", "depends_on"):
            tgt = edge.get("to", "")
            if tgt not in node_ids:
                violations.append(Violation(
                    check="referential_integrity",
                    severity="error",
                    node_ids=[tgt],
                    message=f"Edge type '{etype}' references non-existent target '{tgt}'.",
                ))
    return violations


def check_superseded_has_successor(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Superseded decisions must have a supersedes edge pointing to them."""
    violations: list[Violation] = []

    # Collect all nodes that are targets of supersedes edges
    superseded_targets: set[str] = set()
    for edge in edges:
        if edge.get("type") == "supersedes":
            superseded_targets.add(edge["to"])

    for nid, node in nodes.items():
        if node.get("status") == "superseded" and node.get("type") == "decision":
            if nid not in superseded_targets:
                violations.append(Violation(
                    check="superseded_has_successor",
                    severity="error",
                    node_ids=[nid],
                    message=f"Decision '{nid}' is marked superseded but no supersedes edge points to it.",
                ))
    return violations


# --- Main entry point ---


def run_all_checks(nodes: dict[str, dict], edges: list[dict]) -> list[Violation]:
    """Run all constraint checks. Returns list of violations, empty if graph is healthy."""
    violations: list[Violation] = []

    violations.extend(check_cardinality(nodes, edges))
    violations.extend(check_valid_status(nodes))
    violations.extend(check_id_format(nodes))
    violations.extend(check_dangling_edges(nodes, edges))
    violations.extend(check_acyclic_supersedes(nodes, edges))
    violations.extend(check_acyclic_depends(nodes, edges))
    violations.extend(check_no_self_loops(edges))
    violations.extend(check_depends_on_valid(nodes, edges))
    violations.extend(check_referential_integrity(nodes, edges))
    violations.extend(check_superseded_has_successor(nodes, edges))

    return violations
