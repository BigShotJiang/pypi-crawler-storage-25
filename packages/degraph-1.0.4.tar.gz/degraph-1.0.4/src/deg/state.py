"""STATE.yaml management: read, update, compute stale alerts."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import yaml

from deg.schemas import State, LastSession


def read_state(project_root: Path) -> State:
    """Read STATE.yaml from .deg/ directory."""
    state_file = project_root / ".deg" / "STATE.yaml"
    if not state_file.exists():
        return State()
    raw = yaml.safe_load(state_file.read_text(encoding="utf-8"))
    if not raw:
        return State()
    return State(**raw)


def write_state(project_root: Path, state: State) -> None:
    """Write STATE.yaml to .deg/ directory."""
    deg_dir = project_root / ".deg"
    deg_dir.mkdir(exist_ok=True)
    state_file = deg_dir / "STATE.yaml"
    data = state.model_dump(exclude_none=True, mode="json")
    state_file.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False), encoding="utf-8")


def close_session(project_root: Path, summary: str, next_actions: list[str] | None = None,
                  agent: str = "", active_decisions: list[str] | None = None) -> State:
    """Update STATE.yaml at session close."""
    state = read_state(project_root)
    state.last_session = LastSession(
        date=date.today(),
        agent=agent,
        summary=summary,
    )
    if next_actions is not None:
        state.next_actions = next_actions
    if active_decisions is not None:
        state.active_decisions = active_decisions
    write_state(project_root, state)
    return state
