"""Pydantic models for DEG nodes: Decision, Evidence, Alternative, Trigger, State."""

from __future__ import annotations

from datetime import date, datetime
from typing import Optional
from pydantic import BaseModel, Field


class RevalidationTrigger(BaseModel):
    type: str  # temporal_expiry | dependency_change | metric_threshold | context_drift
    review_after_days: Optional[int] = None
    watch: list[str] = Field(default_factory=list)
    metric: Optional[str] = None
    operator: Optional[str] = None
    threshold: Optional[float] = None


class Revalidation(BaseModel):
    last_verified: date
    triggers: list[RevalidationTrigger] = Field(default_factory=list)


class Alternative(BaseModel):
    option: str
    why: str
    reconsider_if: Optional[str] = None


class CompletedSearch(BaseModel):
    query: str
    date: date
    papers_found: list[str] = Field(default_factory=list)


class ContinueResearch(BaseModel):
    completed_searches: list[CompletedSearch] = Field(default_factory=list)
    next_searches: list[str] = Field(default_factory=list)
    open_questions: list[str] = Field(default_factory=list)
    look_for: list[str] = Field(default_factory=list)


class Decision(BaseModel):
    deg_id: str
    type: str = "decision"
    status: str = "active"  # active | superseded | invalidated | under_review
    title: str
    created: date
    confidence: float = 0.8
    scope: Optional[str] = None
    context: Optional[str] = None

    informed_by: list[str] = Field(default_factory=list)
    depends_on: list[str] = Field(default_factory=list)
    depended_on_by: list[str] = Field(default_factory=list)

    rejected: list[Alternative] = Field(default_factory=list)
    revalidation: Optional[Revalidation] = None
    continue_research: Optional[ContinueResearch] = None

    # Bi-temporal (Graphiti pattern)
    valid_from: Optional[date] = None
    valid_until: Optional[date] = None
    expired_at: Optional[datetime] = None
    superseded_by: Optional[str] = None


class EvidenceSource(BaseModel):
    type: str = "literature"  # literature | experiment | observation | derived
    ref: str = ""
    search_terms: list[str] = Field(default_factory=list)
    papers_consulted: list[str] = Field(default_factory=list)


class Evidence(BaseModel):
    deg_id: str
    type: str = "evidence"
    claim: str
    confidence: float = 0.8

    # Bi-temporal
    valid_from: Optional[date] = None
    valid_until: Optional[date] = None
    created_at: Optional[date] = None
    expired_at: Optional[datetime] = None
    superseded_by: Optional[str] = None

    source: EvidenceSource = Field(default_factory=EvidenceSource)
    informs: list[str] = Field(default_factory=list)
    invalidation_conditions: list[str] = Field(default_factory=list)
    revalidation: Optional[Revalidation] = None


class LastSession(BaseModel):
    date: date
    agent: str = ""
    summary: str = ""


class State(BaseModel):
    project_goal: str = ""
    current_phase: str = ""
    last_session: Optional[LastSession] = None
    active_decisions: list[str] = Field(default_factory=list)
    stale_alerts: list[dict] = Field(default_factory=list)
    next_actions: list[str] = Field(default_factory=list)
    open_questions: list[str] = Field(default_factory=list)


class ChangelogEntry(BaseModel):
    date: datetime
    type: str  # decision_made | evidence_added | evidence_invalidated | alternative_rejected | session_closed
    id: str
    summary: str
    evidence: list[str] = Field(default_factory=list)
    supersedes: Optional[str] = None
    downstream_impact: list[str] = Field(default_factory=list)
