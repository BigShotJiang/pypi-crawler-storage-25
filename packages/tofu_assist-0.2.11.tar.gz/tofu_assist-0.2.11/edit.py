#!/usr/bin/env python3
"""
tofu-assist edit — Modify existing OpenTofu config via natural language.

Usage:
    tofu-assist edit "add a read replica to the RDS"
    tofu-assist edit --dir ./infra "rename the VPC to production-vpc"
    tofu-assist edit --dry-run "convert security group to use CIDR blocks"
"""

import difflib
import json
import sys
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime

from llm_utils import call_llm, PENDING_DIR, MODEL, TOFU_ASSIST_HOME
from generate import run_tofu_validate


# ─── File Reading ─────────────────────────────────────────────────────────────

def read_existing_config(tf_dir: str) -> dict[str, str]:
    """Read all .tf and .tfvars files from a directory.

    Returns dict of filename → content.
    Raises FileNotFoundError if directory doesn't exist.
    Raises ValueError if no .tf files found.
    """
    dir_path = Path(tf_dir)
    if not dir_path.exists():
        raise FileNotFoundError(f"Directory not found: {tf_dir}")
    if not dir_path.is_dir():
        raise NotADirectoryError(f"Not a directory: {tf_dir}")

    files = {}
    for pattern in ["*.tf", "*.tfvars"]:
        for f in sorted(dir_path.glob(pattern)):
            if f.name.startswith(".") or f.name == "plan.json":
                continue
            files[f.name] = f.read_text()

    if not files:
        raise ValueError(f"No .tf files found in {tf_dir}")

    return files


# ─── System Prompt ────────────────────────────────────────────────────────────

EDIT_SYSTEM_PROMPT = """You are an OpenTofu infrastructure editor. You receive existing HCL files and a natural language edit instruction. Your job is to modify ONLY what's needed — preserve everything else exactly.

INPUT FORMAT:
The user provides their current .tf files (filenames and content) followed by an edit instruction.

OUTPUT FORMAT:
Return ONLY a JSON object with exactly three keys. No explanation. No markdown. No backticks.

{
  "main_tf": "<modified main.tf content>",
  "variables_tf": "<modified variables.tf content>",
  "outputs_tf": "<modified outputs.tf content>"
}

If a file doesn't need changes, return its original content unchanged.

CRITICAL RULES:
1. PRESERVE all existing resources, data sources, locals, and provider blocks unless the user explicitly asks to remove or rename them
2. PRESERVE all existing variable definitions and output definitions
3. PRESERVE inline comments and formatting style where possible
4. Only modify resources directly related to the edit instruction
5. If adding a new resource, place it logically near related resources
6. If removing a resource, also remove references to it in outputs and other resources
7. Maintain snake_case naming conventions
8. Never remove provider blocks, backend configs, or terraform{} blocks
9. If the edit instruction is ambiguous, prefer the safer interpretation (don't destroy anything)
10. For destructive changes (renaming resources, removing resources), include a comment noting the change

SECURITY DEFAULTS (apply to any new resources):
- Encryption at rest: enabled on all storage and databases
- S3 buckets: public access blocked
- Security groups: NO ingress from 0.0.0.0/0 on ports 22, 3306, 5432, 6379, 27017, 3389
- IAM: no wildcard actions unless user explicitly asks
- Database passwords: use random_password resource

Edit instruction: {instruction}

Existing files:
{existing_files}

Return ONLY the JSON object with the modified files."""


# ─── Data Structures ──────────────────────────────────────────────────────────

@dataclass
class EditResult:
    """Result of an edit operation."""
    success: bool
    original_files: dict[str, str] = field(default_factory=dict)
    modified_files: dict[str, str] = field(default_factory=dict)
    error: str = ""
    pending_dir: str = ""
    attempts: int = 0


# ─── Core Edit Orchestration ──────────────────────────────────────────────────

def edit_existing(
    instruction: str,
    tf_dir: str,
    model: str = MODEL,
    max_attempts: int = 2,
) -> EditResult:
    """Modify existing OpenTofu config based on natural language instruction.

    Args:
        instruction: Natural language edit (e.g., "add a read replica")
        tf_dir: Directory containing .tf files to modify
        model: LLM model to use
        max_attempts: Retry count on validation failure

    Returns:
        EditResult with success flag, original/modified files, and pending_dir
    """
    # 1. Read existing config
    try:
        original_files = read_existing_config(tf_dir)
    except (FileNotFoundError, NotADirectoryError, ValueError) as e:
        return EditResult(success=False, error=str(e))

    # 2. Build the user prompt with existing files
    files_text = ""
    for filename, content in original_files.items():
        files_text += f"\n=== {filename} ===\n{content}\n"

    system = EDIT_SYSTEM_PROMPT.replace("{instruction}", instruction)
    system = system.replace("{existing_files}", files_text)
    user_prompt = f"Existing files:\n{files_text}\n\nEdit instruction: {instruction}"

    current_prompt = user_prompt

    for attempt in range(max_attempts):
        # 3. Call LLM
        try:
            raw = call_llm(system, current_prompt, model=model)
        except RuntimeError as e:
            return EditResult(
                success=False,
                original_files=original_files,
                error=f"LLM call failed: {e}",
                attempts=attempt + 1,
            )

        # 4. Parse JSON response
        try:
            modified = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            if attempt < max_attempts - 1:
                current_prompt = (
                    f"{user_prompt}\n\n"
                    f"Your previous response was not valid JSON. "
                    f"Return ONLY a JSON object with keys: main_tf, variables_tf, outputs_tf. "
                    f"No markdown, no explanation."
                )
                continue
            return EditResult(
                success=False,
                original_files=original_files,
                error="LLM returned malformed JSON after retry",
                attempts=attempt + 1,
            )

        if not isinstance(modified, dict):
            if attempt < max_attempts - 1:
                current_prompt = f"{user_prompt}\n\nReturn ONLY a JSON object. No extra text."
                continue
            return EditResult(
                success=False,
                original_files=original_files,
                error="LLM response was not a JSON object",
                attempts=attempt + 1,
            )

        # 5. Write to pending directory (temp, not overwriting originals)
        timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
        pending_dir = str(PENDING_DIR / f"edit-{timestamp}")
        Path(pending_dir).mkdir(parents=True, exist_ok=True)

        FILENAME_MAP = {
            "main_tf": "main.tf",
            "variables_tf": "variables.tf",
            "outputs_tf": "outputs.tf",
        }

        # Write the three standard files
        for json_key, disk_name in FILENAME_MAP.items():
            content = modified.get(json_key, original_files.get(disk_name, ""))
            (Path(pending_dir) / disk_name).write_text(content)

        # Copy over any extra files that weren't in the JSON response
        for fname in original_files:
            if fname not in FILENAME_MAP.values():
                (Path(pending_dir) / fname).write_text(original_files[fname])

        # 6. Validate with tofu
        valid, error = run_tofu_validate(pending_dir)

        if valid:
            return EditResult(
                success=True,
                original_files=original_files,
                modified_files={
                    k: modified.get(k, original_files.get(FILENAME_MAP.get(k, k), ""))
                    for k in ["main_tf", "variables_tf", "outputs_tf"]
                },
                pending_dir=pending_dir,
                attempts=attempt + 1,
            )

        # 7. Retry with validation error feedback
        if attempt < max_attempts - 1:
            current_prompt = (
                f"{user_prompt}\n\n"
                f"The previous attempt failed validation with this error:\n{error}\n\n"
                f"Fix the error and regenerate. Return ONLY the JSON object."
            )
            continue

        return EditResult(
            success=False,
            original_files=original_files,
            modified_files=modified,
            error=f"Validation failed after {max_attempts} attempts: {error}",
            attempts=attempt + 1,
            pending_dir=pending_dir,
        )

    return EditResult(success=False, error="Unexpected error", attempts=max_attempts)


# ─── Diff and Apply ───────────────────────────────────────────────────────────

def show_diff(original_files: dict[str, str], modified_files: dict[str, str]) -> str:
    """Generate a unified diff between original and modified files.

    Returns a human-readable diff string, or empty string if no changes.
    """
    FILENAME_MAP = {
        "main_tf": "main.tf",
        "variables_tf": "variables.tf",
        "outputs_tf": "outputs.tf",
    }

    diff_parts = []

    for json_key, disk_name in FILENAME_MAP.items():
        original = original_files.get(disk_name, "")
        modified = modified_files.get(json_key, "")

        if original != modified:
            diff = difflib.unified_diff(
                original.splitlines(keepends=True),
                modified.splitlines(keepends=True),
                fromfile=f"a/{disk_name}",
                tofile=f"b/{disk_name}",
            )
            diff_text = "".join(diff)
            if diff_text.strip():
                diff_parts.append(diff_text)

    return "\n".join(diff_parts)


def apply_edit(pending_dir: str, target_dir: str) -> list[str]:
    """Copy modified files from pending_dir to target_dir, backing up originals.

    Backs up originals to ~/.tofu-assist/backups/<timestamp>/ before overwriting.
    Returns list of files that were overwritten.
    """
    from shutil import copy2

    pending = Path(pending_dir)
    target = Path(target_dir)
    overwritten = []

    # Backup originals
    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    backup_dir = TOFU_ASSIST_HOME / "backups" / timestamp
    backup_dir.mkdir(parents=True, exist_ok=True)

    for f in pending.glob("*.tf"):
        target_file = target / f.name
        if target_file.exists():
            copy2(target_file, backup_dir / f.name)

    # Copy modified files
    for f in pending.glob("*.tf"):
        target_file = target / f.name
        content = f.read_text()
        target_file.write_text(content)
        overwritten.append(f.name)

    return overwritten


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main() -> None:
    """CLI entry point for tofu-assist edit."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Modify existing OpenTofu config via natural language"
    )
    parser.add_argument(
        "instruction",
        nargs="+",
        help='Natural language edit instruction (e.g., "add a read replica")',
    )
    parser.add_argument(
        "--dir",
        default=".",
        help="Directory containing .tf files (default: current directory)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show diff without applying changes",
    )
    parser.add_argument(
        "--yes", "-y",
        action="store_true",
        help="Skip approval prompt (apply immediately)",
    )

    args = parser.parse_args()
    instruction = " ".join(args.instruction)
    tf_dir = str(Path(args.dir).resolve())

    # --- Step 1: Run the edit ---
    from display import is_plain_mode
    if is_plain_mode():
        print(f"Editing {tf_dir}...")
        print(f"Instruction: {instruction}")
    else:
        from rich.panel import Panel
        from rich.console import Console
        Console().print(Panel(f"Editing {tf_dir}...\nInstruction: {instruction}"))
    print()

    result = edit_existing(instruction, tf_dir)

    if not result.success:
        print(f"✗ Edit failed: {result.error}", file=sys.stderr)
        if result.pending_dir:
            print(f"  Partial files saved to: {result.pending_dir}", file=sys.stderr)
        sys.exit(1)

    # --- Step 2: Show diff ---
    diff = show_diff(result.original_files, result.modified_files)

    if not diff.strip():
        print("No changes detected. Your config already matches the instruction.")
        return

    print("Changes:")
    print(diff)
    print()

    # --- Step 3: Dry run mode ---
    if args.dry_run:
        print("Dry run — files NOT modified.")
        print(f"Preview saved to: {result.pending_dir}")
        return

    # --- Step 4: Approval ---
    if args.yes:
        choice = "y"
    else:
        try:
            choice = input("Apply these changes? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nCancelled.")
            print(f"Preview saved to: {result.pending_dir}")
            return

    if choice in ("y", "yes"):
        overwritten = apply_edit(result.pending_dir, tf_dir)
        print(f"✓ Modified {len(overwritten)} file(s): {', '.join(overwritten)}")
        print("  Backup saved to: ~/.tofu-assist/backups/")
        print()
        print("Next steps:")
        print(f"  cd {tf_dir} && tofu plan    # review the plan")
        print("  tofu apply                 # apply changes")
    else:
        print(f"Cancelled. Preview saved to: {result.pending_dir}")


if __name__ == "__main__":
    main()
