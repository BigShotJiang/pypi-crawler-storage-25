#!/usr/bin/env python3
"""
tofu-assist — Natural language → provisioned infrastructure, with safety checks.

Full pipeline:
    NL prompt → generate .tf files → Checkov scan → tofu plan → explain → cost → approve

Usage:
    tofu-assist "I need a k8s cluster with postgres"
    tofu-assist --dry-run "S3 bucket with CloudFront CDN"
"""

import subprocess
import sys
from pathlib import Path

# Import from sibling modules
from generate import (
    detect_provider, generate_tf, MODEL,
)
from explain import (
    analyze_plan, load_plan_json, validate_schema,
    run_security_scan,
)
from display import (
    print_banner, print_generation_result, print_security_scan,
    print_plan_result, print_error, print_approval_prompt, print_help, print_step,
)


def run_tofu_plan(tf_dir: str) -> tuple[bool, str, str]:
    """Run 'tofu plan -json' in the given directory.

    Returns (success, plan_json_string, error_message).
    """
    try:
        result = subprocess.run(
            ["tofu", "init"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=120,
        )
        if result.returncode != 0:
            return False, "", f"tofu init failed:\n{result.stderr[-500:]}"

        result = subprocess.run(
            ["tofu", "plan", "-json"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=120,
        )
    except FileNotFoundError:
        return False, "", "OpenTofu is not installed. Install: https://opentofu.org"
    except subprocess.TimeoutExpired:
        return False, "", "Plan timed out"

    if result.returncode == 0:
        return True, result.stdout, ""
    if result.returncode == 2:
        # Exit code 2 = planned changes detected (this is a successful plan)
        return True, result.stdout, ""

    error = (result.stdout + result.stderr).strip()[-1000:]

    # Make common errors human-readable
    if "failed to get shared config profile" in error:
        return False, "", (
            "No AWS credentials found.\n"
            "  Set AWS_PROFILE or run: aws configure\n"
            "  Or use --dry-run to preview without credentials."
        )
    if "Error: " in error:
        # Extract just the error lines, skip JSON noise
        lines = []
        for line in error.split("\n"):
            line = line.strip()
            if line.startswith("Error: "):
                lines.append(line)
            elif line.startswith("│ Error: "):
                lines.append(line.replace("│ ", ""))
        if lines:
            error = "\n".join(lines[:5])
    return False, "", f"Plan failed:\n{error}"


def run_tofu_apply(tf_dir: str) -> tuple[bool, str]:
    """Run 'tofu apply -auto-approve'. Returns (success, output)."""
    try:
        result = subprocess.run(
            ["tofu", "apply", "-auto-approve"],
            capture_output=True, text=True,
            cwd=tf_dir, timeout=600,
        )
    except FileNotFoundError:
        return False, "OpenTofu is not installed"
    except subprocess.TimeoutExpired:
        return False, "Apply timed out"

    output = (result.stdout + result.stderr).strip()
    return result.returncode == 0, output[-2000:]


def main() -> None:
    # Subcommand: edit
    if len(sys.argv) > 1 and sys.argv[1] == "edit":
        import edit
        sys.argv.pop(1)
        edit.main()
        return

    # Subcommand: explain
    if len(sys.argv) > 1 and sys.argv[1] == "explain":
        import explain_codebase
        sys.argv.pop(1)
        explain_codebase.main()
        return

    # REPL: no args + TTY → interactive session
    if len(sys.argv) == 1 and sys.stdout.isatty():
        import repl
        repl.run_repl()
        return

    dry_run = "--dry-run" in sys.argv
    args = [a for a in sys.argv[1:] if a not in ("--dry-run", "--json", "--plain")]

    if not args or "--help" in sys.argv or "-h" in sys.argv:
        print_help()
        sys.exit(0 if "--help" in sys.argv or "-h" in sys.argv else 1)

    user_prompt = " ".join(args)

    # ── Early API key check ─────────────────────────────────────────────
    from llm_utils import API_KEY
    if not API_KEY:
        print_error("No API key set. Set TOFU_ASSIST_API_KEY or DEEPSEEK_API_KEY.")
        sys.exit(1)

    # ── Step 1: Provider detection ──────────────────────────────────────
    provider, region = detect_provider()
    if provider == "unknown":
        print_error("Could not detect cloud provider.\n  Set AWS_PROFILE, GOOGLE_APPLICATION_CREDENTIALS, or ARM_SUBSCRIPTION_ID.\n  Or create .tf files with provider blocks first.")
        sys.exit(1)

    print_banner(provider, region, MODEL)

    # \u2500\u2500 Step 2: Generate HCL \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    print_step("Generating configuration...")
    print()

    result = generate_tf(user_prompt, provider, region, dry_run=dry_run)

    if not result.success:
        print_generation_result(False, result.files, result.pending_dir, result.error)
        sys.exit(1)

    if dry_run:
        # Print generated HCL to stdout, no files written to disk
        FILENAME_MAP = {
            "main_tf": "main.tf",
            "variables_tf": "variables.tf",
            "outputs_tf": "outputs.tf",
        }
        for key, fname in FILENAME_MAP.items():
            if key in result.files:
                print(f"# {fname}")
                print(result.files[key])
                print()
        return

    print_generation_result(True, result.files)

    tf_dir = result.pending_dir

    # ── Step 3: Security scan (always run) ──────────────────────────────
    security = run_security_scan(tf_dir)
    # Separate tool-status messages from real findings
    tool_status = [f for f in security.findings
                   if "unavailable" in f.lower() or "timed out" in f.lower()]
    real_findings = [f for f in security.findings if f not in tool_status]

    print_security_scan(security.findings, tool_status)

    # ── Step 4: tofu plan (always run) ──────────────────────────────────
    print_step("Running tofu plan...")
    success, plan_json, error = run_tofu_plan(tf_dir)

    if not success:
        print_error(f"{error}\n  Files saved to: {tf_dir}\n  Fix the errors and run: tofu-assist retry {tf_dir}")
        sys.exit(1)

    # Save plan JSON for Infracost
    plan_path = Path(tf_dir) / "plan.json"
    plan_path.write_text(plan_json)

    # ── Step 5: Explain ─────────────────────────────────────────────────
    plan = load_plan_json(plan_json)
    if plan is None:
        print_error("Could not parse plan output")
        sys.exit(1)

    schema_error = validate_schema(plan)
    if schema_error:
        print_error(schema_error)
        sys.exit(1)

    explain_result = analyze_plan(plan)

    # Inject real security findings into the explain output
    if real_findings:
        explain_result.attention_items = real_findings + explain_result.attention_items

    print()

    # ── Step 6: Render explain output ───────────────────────────────────
    print_plan_result(explain_result, str(plan_path), dry_run, tf_dir)
    if dry_run:
        return

    # ── Step 7: Approve (live mode only) ────────────────────────────────
    if explain_result.alarming:
        print_error(f"This plan requires manual review. Apply manually:\n  cd {tf_dir} && tofu apply")
        sys.exit(3)

    critical_risks_list = [a for a in explain_result.attention_items if a.startswith("⛔")]
    choice = print_approval_prompt(bool(critical_risks_list), critical_risks_list)
    if choice is None:
        print(f"Files saved to: {tf_dir}")
        print(f"Review and apply manually: cd {tf_dir} && tofu apply")
        sys.exit(0)

    if choice in ("y", "yes"):
        print_step("Applying...")
        success, output = run_tofu_apply(tf_dir)
        if success:
            print("✓ Infrastructure provisioned successfully.")
            from generate import archive_applied
            applied = archive_applied(tf_dir)
            if applied:
                print(f"  Config archived to: {applied}")
        else:
            print_error(f"Apply failed:\n{output}")
            print(f"Files saved to: {tf_dir}")
            sys.exit(1)
    else:
        print(f"Files saved to: {tf_dir}")
        print(f"Apply manually: cd {tf_dir} && tofu apply")


if __name__ == "__main__":
    main()
