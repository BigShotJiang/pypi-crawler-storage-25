import sys
from typing import Any


def is_plain_mode() -> bool:
    return "--plain" in sys.argv or "--json" in sys.argv or not sys.stdout.isatty()


def print_step(message: str) -> None:
    if is_plain_mode():
        print(message)
        return
    from rich.console import Console
    from rich.text import Text
    Console().print(Text(message, style="bold blue"))


def print_banner(provider: str, region: str, model: str) -> None:
    if is_plain_mode():
        print(f"Provider: {provider} ({region})")
        print(f"Model: {model}")
        return

    from rich.panel import Panel
    from rich.console import Console
    from rich.text import Text

    console = Console()
    info = Text()
    info.append(f"Provider: {provider} ({region})", style="bold cyan")
    info.append("\n")
    info.append(f"Model: {model}", style="yellow")
    panel = Panel(info, border_style="cyan")
    console.print(panel)
    print()


def print_generation_result(
    success: bool,
    files: dict[str, str],
    pending_dir: str | None = None,
    error: str = "",
) -> None:
    if not success:
        print_error(f"Generation failed: {error}")
        if pending_dir:
            msg = f"  Partial files saved to: {pending_dir}"
            if is_plain_mode():
                print(msg, file=sys.stderr)
            else:
                from rich.console import Console
                Console(stderr=True).print(msg, style="dim")
        return

    if is_plain_mode():
        for fname, content in files.items():
            line_count = content.count("\n") + 1
            display_name = fname.replace("_tf", ".tf")
            print(f"   \u2713 {display_name} ({line_count} lines)")
        print()
        return

    from rich.panel import Panel
    from rich.console import Console, Group
    from rich.text import Text

    console = Console()
    items = []
    for fname, content in files.items():
        line_count = content.count("\n") + 1
        display_name = fname.replace("_tf", ".tf")
        items.append(Text(f"\u2713 {display_name} ({line_count} lines)", style="bold green"))
    panel = Panel(Group(*items), title="Generated Files", border_style="green", title_align="left")
    console.print(panel)
    print()


def print_security_scan(findings: list[str], tool_status: list[str]) -> None:
    real_findings = [f for f in findings if f not in tool_status]

    if is_plain_mode():
        if real_findings:
            print(f"Security scan: \u26a0 {len(real_findings)} issue(s)")
            for finding in real_findings:
                print(f"  {finding}")
            print()
        elif tool_status:
            print(f"Security scan: {tool_status[0]}")
            print()
        else:
            print("Security scan: \u2713 no issues found")
            print()
        return

    from rich.panel import Panel
    from rich.console import Console
    from rich.text import Text

    console = Console()

    if real_findings:
        content = Text()
        content.append(f"{len(real_findings)} issue(s) found\n", style="bold yellow")
        for finding in real_findings:
            content.append(f"  \u2022 {finding}\n", style="yellow")
        panel = Panel(content, title="Security Scan", border_style="yellow")
    elif tool_status:
        panel = Panel(tool_status[0], title="Security Scan", border_style="dim")
    else:
        panel = Panel("\u2713 no issues found", title="Security Scan", border_style="green")
    console.print(panel)
    print()


def print_plan_result(
    explain_result: Any,
    plan_path: str | None = None,
    dry_run: bool = False,
    tf_dir: str = "",
) -> None:
    from explain import render_plain, group_resources, get_cost_estimate

    if explain_result.no_op:
        if is_plain_mode():
            print("No changes. Your infrastructure matches the configuration.")
        else:
            from rich.panel import Panel
            from rich.console import Console
            Console().print(Panel("No changes. Your infrastructure matches the configuration.", border_style="green"))
        return

    if explain_result.refresh_only:
        if is_plain_mode():
            print("State refreshed. No infrastructure changes will be made.")
        else:
            from rich.panel import Panel
            from rich.console import Console
            Console().print(Panel("State refreshed. No infrastructure changes will be made.", border_style="green"))
        return

    if is_plain_mode():
        if dry_run:
            print("\u2501" * 60)
            print("DRY RUN \u2014 nothing will be applied")
            print("\u2501" * 60)
            print()
        output = render_plain(explain_result, plan_path)
        print(output)
        print()
        if dry_run:
            print(f"Files saved to: {tf_dir}")
            print(f"Run `tofu-assist apply {tf_dir}` to apply this plan.")
        return

    from rich.panel import Panel
    from rich.console import Console
    from rich.table import Table
    from rich.text import Text
    from rich import box

    console = Console()

    if dry_run:
        dry_run_panel = Panel("DRY RUN \u2014 nothing will be applied", border_style="yellow")
        console.print(dry_run_panel)
        print()

    total = sum(
        len(x) for x in [
            explain_result.creates, explain_result.updates,
            explain_result.destroys, explain_result.replaces,
        ]
    )
    parts = []
    if explain_result.creates:
        parts.append(f"{len(explain_result.creates)} created")
    if explain_result.updates:
        parts.append(f"{len(explain_result.updates)} updated")
    if explain_result.replaces:
        parts.append(f"{len(explain_result.replaces)} replaced")
    if explain_result.destroys:
        parts.append(f"{len(explain_result.destroys)} destroyed")

    summary_text = Text()
    summary_text.append(f"{total} resource{'s' if total != 1 else ''}", style="bold")
    summary_text.append(f": {', '.join(parts)}")

    cost = get_cost_estimate(plan_path) if plan_path else ""
    if cost:
        summary_text.append(f"\nEstimated cost: {cost}", style="cyan")

    console.print(Panel(summary_text, title="Summary", border_style="blue"))
    print()

    if explain_result.attention_items:
        critical = [i for i in explain_result.attention_items if i.startswith("\u26db")]
        warnings = [i for i in explain_result.attention_items if not i.startswith("\u26db")]
        att_text = Text()
        for item in critical:
            att_text.append(f"  {item}\n", style="bold red")
        if critical and warnings:
            att_text.append("\n")
        for item in warnings:
            att_text.append(f"  {item}\n", style="yellow")
        panel = Panel(
            att_text,
            title="Attention Required",
            border_style="red" if critical else "yellow",
        )
        console.print(panel)
        print()

    if explain_result.creates or explain_result.replaces:
        table = Table(title="What Will Be Built", box=box.MINIMAL_HEAVY_HEAD)
        table.add_column("Change", style="bold green")
        table.add_column("Resource")
        all_new = explain_result.creates + explain_result.replaces
        replace_set = set(id(r) for r in explain_result.replaces)
        for label, members in group_resources(all_new):
            marker = "\u21ba" if any(id(m) in replace_set for m in members) else "+"
            table.add_row(marker, label)
        console.print(table)
        print()

    if explain_result.updates:
        table = Table(title="What Will Change", box=box.MINIMAL_HEAVY_HEAD)
        table.add_column("Change", style="bold blue")
        table.add_column("Resource")
        for label, _ in group_resources(explain_result.updates):
            table.add_row("~", label)
        console.print(table)
        print()

    if explain_result.destroys:
        table = Table(title="What Will Be Destroyed", box=box.MINIMAL_HEAVY_HEAD)
        table.add_column("Change", style="bold red")
        table.add_column("Resource")
        for label, _ in group_resources(explain_result.destroys):
            table.add_row("-", label)
        console.print(table)
        print()

    if dry_run:
        console.print(Text(f"Files saved to: {tf_dir}", style="dim"))
        console.print(Text(f"Run `tofu-assist apply {tf_dir}` to apply this plan.", style="dim"))


def print_error(message: str) -> None:
    if is_plain_mode():
        print(message, file=sys.stderr)
        return

    from rich.panel import Panel
    from rich.console import Console
    console = Console(stderr=True)
    panel = Panel(message, border_style="red", title="Error", title_align="left")
    console.print(panel)


def print_approval_prompt(
    has_critical_risks: bool,
    critical_risks: list[str] | None = None,
) -> str | None:
    if is_plain_mode():
        if has_critical_risks and critical_risks:
            print("\u2501" * 60)
            print("\u26db  CRITICAL RISKS DETECTED:")
            for item in critical_risks[:3]:
                print(f"  {item}")
            if len(critical_risks) > 3:
                print(f"  ... and {len(critical_risks) - 3} more critical issue(s)")
            print("\u2501" * 60)
            print()
        try:
            if has_critical_risks:
                return input("Apply this plan? CRITICAL RISKS ABOVE [y/N] ").strip().lower()
            return input("Apply this plan? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return None

    from rich.panel import Panel
    from rich.console import Console
    from rich.text import Text

    console = Console()

    if has_critical_risks and critical_risks:
        risk_text = Text()
        risk_text.append("\u26db  CRITICAL RISKS DETECTED:\n", style="bold red")
        for item in critical_risks[:3]:
            risk_text.append(f"  {item}\n", style="red")
        if len(critical_risks) > 3:
            risk_text.append(f"  ... and {len(critical_risks) - 3} more critical issue(s)", style="red")
        panel = Panel(risk_text, border_style="red")
        console.print(panel)
        print()

    try:
        if has_critical_risks:
            return console.input("Apply this plan? CRITICAL RISKS ABOVE [y/N] ").strip().lower()
        return console.input("Apply this plan? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return None


def print_help() -> None:
    if is_plain_mode():
        print("Usage: tofu-assist 'I need a kubernetes cluster with postgres'", file=sys.stderr)
        print(file=sys.stderr)
        print("Options:", file=sys.stderr)
        print("  --dry-run    Preview plan without applying", file=sys.stderr)
        print("  --json       Output plan as JSON", file=sys.stderr)
        print("  --plain      Plain text output (no styling)", file=sys.stderr)
        print(file=sys.stderr)
        print("Subcommands:", file=sys.stderr)
        print("  edit         Modify existing config via natural language", file=sys.stderr)
        print("  explain      Explain any .tf codebase in plain English", file=sys.stderr)
        print(file=sys.stderr)
        print("Examples:", file=sys.stderr)
        print("  tofu-assist 'I need a k8s cluster with postgres'", file=sys.stderr)
        print("  tofu-assist edit 'add a read replica to the RDS'", file=sys.stderr)
        print("  tofu-assist explain ./infra", file=sys.stderr)
        return

    from rich.panel import Panel
    from rich.console import Console
    from rich.table import Table

    console = Console(stderr=True)
    grid = Table.grid(padding=(0, 2))
    grid.add_column(style="bold cyan")
    grid.add_column()

    grid.add_row("Usage:", "tofu-assist 'I need a kubernetes cluster with postgres'")
    grid.add_row("")
    grid.add_row("Options:", "")
    grid.add_row("  --dry-run", "  Preview plan without applying")
    grid.add_row("  --json", "     Output plan as JSON")
    grid.add_row("  --plain", "     Plain text output (no styling)")
    grid.add_row("")
    grid.add_row("Subcommands:", "")
    grid.add_row("  edit", "       Modify existing config via natural language")
    grid.add_row("  explain", "     Explain any .tf codebase in plain English")
    grid.add_row("")
    grid.add_row("Examples:", "")
    grid.add_row("  tofu-assist 'I need a k8s cluster with postgres'", "")
    grid.add_row("  tofu-assist edit 'add a read replica to the RDS'", "")
    grid.add_row("  tofu-assist explain ./infra", "")

    panel = Panel(grid, border_style="cyan")
    console.print(panel)
