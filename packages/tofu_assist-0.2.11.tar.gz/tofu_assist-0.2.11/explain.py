#!/usr/bin/env python3
"""
tofu-assist explain — Plain-English explain layer for terraform/opentofu plan JSON.

The abstraction IS the product. The user never sees raw JSON, stack traces,
or Checkov reports. Every failure path degrades gracefully into plain English.

Merged from two implementations:
  Claude:  address parsing, resource grouping, friendly naming, output structure
  Hermes:  tag/computed filtering, alarming plan detection, egress + rule-level SG checks

Usage:
    tofu plan -json | python3 explain.py
    python3 explain.py plan.json
    python3 explain.py --json plan.json   # machine-readable output
"""

import json
import re
import subprocess
import sys
import tempfile
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


# ─── Constants ────────────────────────────────────────────────────────────────

SENSITIVE_PORTS: dict[int, str] = {
    22: "SSH",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    6379: "Redis",
    27017: "MongoDB",
    1433: "MSSQL",
    1521: "Oracle",
    11211: "Memcached",
}

STATEFUL_RESOURCE_TYPES: set[str] = {
    "aws_db_instance", "aws_rds_cluster", "aws_rds_cluster_instance",
    "aws_elasticache_cluster", "aws_elasticache_replication_group",
    "aws_s3_bucket", "aws_dynamodb_table",
    "aws_elasticsearch_domain", "aws_opensearch_domain",
    "aws_msk_cluster", "aws_redshift_cluster",
    "aws_ebs_volume", "aws_ebs_snapshot",
    "aws_efs_file_system",
    "aws_neptune_cluster", "aws_docdb_cluster",
    "aws_kinesis_stream", "aws_mq_broker",
    "aws_backup_vault",
    "google_sql_database_instance", "google_storage_bucket",
    "google_bigtable_instance", "google_spanner_instance",
    "google_bigquery_dataset",
    "azurerm_sql_database", "azurerm_storage_account",
    "azurerm_cosmosdb_account", "azurerm_postgresql_flexible_server",
    "azurerm_postgresql_database", "azurerm_mssql_database",
    "azurerm_storage_container",
}

IAM_RESOURCE_TYPES: set[str] = {
    "aws_iam_role", "aws_iam_policy", "aws_iam_role_policy",
    "aws_iam_role_policy_attachment", "aws_iam_user", "aws_iam_group",
    "aws_iam_user_policy", "aws_iam_group_policy", "aws_iam_instance_profile",
    "aws_iam_access_key",
    "google_project_iam_member", "google_project_iam_binding",
    "google_service_account", "google_service_account_key",
    "azurerm_role_assignment", "azurerm_role_definition",
}

SECURITY_GROUP_TYPES: set[str] = {
    "aws_security_group", "aws_security_group_rule",
    "aws_vpc_security_group_ingress_rule", "aws_vpc_security_group_egress_rule",
    "google_compute_firewall",
    "azurerm_network_security_group", "azurerm_network_security_rule",
}

COMPUTED_MARKER = "(known after apply)"

PROD_NAME_PATTERNS = re.compile(
    r'\b(prod|production|prd|primary|live|main|master)\b',
    re.IGNORECASE
)

RESOURCE_TYPE_NAMES: dict[str, str] = {
    "aws_instance": "EC2 instance",
    "aws_launch_template": "launch template",
    "aws_autoscaling_group": "Auto Scaling group",
    "aws_spot_instance_request": "spot instance",
    "aws_vpc": "VPC",
    "aws_subnet": "subnet",
    "aws_internet_gateway": "internet gateway",
    "aws_nat_gateway": "NAT gateway",
    "aws_eip": "Elastic IP",
    "aws_route_table": "route table",
    "aws_route_table_association": "route table association",
    "aws_route": "route",
    "aws_security_group": "security group",
    "aws_security_group_rule": "security group rule",
    "aws_vpc_security_group_ingress_rule": "security group ingress rule",
    "aws_vpc_security_group_egress_rule": "security group egress rule",
    "aws_vpc_peering_connection": "VPC peering connection",
    "aws_network_acl": "network ACL",
    "aws_lb": "load balancer",
    "aws_alb": "load balancer",
    "aws_lb_listener": "load balancer listener",
    "aws_lb_target_group": "load balancer target group",
    "aws_eks_cluster": "EKS cluster",
    "aws_eks_node_group": "EKS node group",
    "aws_eks_fargate_profile": "EKS Fargate profile",
    "aws_ecs_cluster": "ECS cluster",
    "aws_ecs_service": "ECS service",
    "aws_ecs_task_definition": "ECS task definition",
    "aws_ecr_repository": "ECR repository",
    "aws_db_instance": "RDS instance",
    "aws_rds_cluster": "RDS cluster",
    "aws_rds_cluster_instance": "RDS cluster instance",
    "aws_db_subnet_group": "RDS subnet group",
    "aws_db_parameter_group": "RDS parameter group",
    "aws_elasticache_cluster": "ElastiCache cluster",
    "aws_elasticache_replication_group": "ElastiCache replication group",
    "aws_elasticache_subnet_group": "ElastiCache subnet group",
    "aws_dynamodb_table": "DynamoDB table",
    "aws_redshift_cluster": "Redshift cluster",
    "aws_s3_bucket": "S3 bucket",
    "aws_s3_bucket_policy": "S3 bucket policy",
    "aws_s3_bucket_public_access_block": "S3 public access block",
    "aws_cloudfront_distribution": "CloudFront distribution",
    "aws_route53_record": "Route53 record",
    "aws_route53_zone": "Route53 zone",
    "aws_acm_certificate": "ACM certificate",
    "aws_acm_certificate_validation": "ACM certificate validation",
    "aws_iam_role": "IAM role",
    "aws_iam_policy": "IAM policy",
    "aws_iam_role_policy": "IAM role policy",
    "aws_iam_role_policy_attachment": "IAM policy attachment",
    "aws_iam_user": "IAM user",
    "aws_iam_group": "IAM group",
    "aws_iam_instance_profile": "IAM instance profile",
    "aws_lambda_function": "Lambda function",
    "aws_api_gateway_rest_api": "API Gateway",
    "aws_api_gateway_v2_api": "API Gateway v2",
    "aws_cloudwatch_log_group": "CloudWatch log group",
    "aws_cloudwatch_metric_alarm": "CloudWatch alarm",
    "aws_sns_topic": "SNS topic",
    "aws_sqs_queue": "SQS queue",
    "aws_kms_key": "KMS key",
    "aws_ssm_parameter": "SSM parameter",
    "aws_secretsmanager_secret": "Secrets Manager secret",
    "google_compute_instance": "Compute Engine instance",
    "google_compute_network": "VPC network",
    "google_compute_subnetwork": "subnet",
    "google_compute_firewall": "firewall rule",
    "google_container_cluster": "GKE cluster",
    "google_container_node_pool": "GKE node pool",
    "google_sql_database_instance": "Cloud SQL instance",
    "google_storage_bucket": "Cloud Storage bucket",
    "google_service_account": "service account",
    "azurerm_virtual_machine": "virtual machine",
    "azurerm_virtual_network": "virtual network",
    "azurerm_subnet": "subnet",
    "azurerm_kubernetes_cluster": "AKS cluster",
    "azurerm_sql_database": "SQL database",
    "azurerm_storage_account": "storage account",
    "azurerm_resource_group": "resource group",
    "kubernetes_deployment": "Kubernetes deployment",
    "kubernetes_service": "Kubernetes service",
    "kubernetes_namespace": "namespace",
    "kubernetes_config_map": "ConfigMap",
    "kubernetes_secret": "Kubernetes secret",
    "helm_release": "Helm release",
}


# ─── Data Classes ─────────────────────────────────────────────────────────────

@dataclass
class ResourceChange:
    address: str
    resource_type: str
    name: str
    module_path: list[str]
    actions: list[str]
    before: Optional[dict]
    after: Optional[dict]
    index: Optional[Any] = None


@dataclass
class ExplainResult:
    no_op: bool = False
    refresh_only: bool = False
    alarming: bool = False
    alarming_message: str = ""
    creates: list[ResourceChange] = field(default_factory=list)
    updates: list[ResourceChange] = field(default_factory=list)
    destroys: list[ResourceChange] = field(default_factory=list)
    replaces: list[ResourceChange] = field(default_factory=list)
    attention_items: list[str] = field(default_factory=list)
    total_meaningful: int = 0
    delete_count: int = 0


@dataclass
class SecurityResult:
    """Result of a Checkov security scan."""
    passed: bool
    findings: list[str]        # plain-English findings ready to surface
    raw_failed: int = 0         # total Checkov failures (including hidden)


# ─── Address Parsing ──────────────────────────────────────────────────────────

def parse_address(address: str) -> tuple[list[str], str, str, Any]:
    """Parse a Terraform resource address into its components.

    module.vpc.aws_subnet.public[0]
        → module_path=["vpc"], type="aws_subnet", name="public", index=0

    module.network.module.vpc.aws_subnet.public["web"]
        → module_path=["network","vpc"], type="aws_subnet", name="public", index="web"

    aws_instance.web
        → module_path=[], type="aws_instance", name="web", index=None
    """
    index: Any = None
    index_match = re.search(r'\[(.+?)\]$', address)
    if index_match:
        raw = index_match.group(1)
        address = address[:index_match.start()]
        try:
            index = int(raw)
        except ValueError:
            index = raw.strip('"\'')

    parts = address.split(".")
    module_path: list[str] = []
    i = 0
    while i < len(parts) - 2 and parts[i] == "module":
        module_path.append(parts[i + 1])
        i += 2

    remaining = parts[i:]
    resource_type = remaining[0] if len(remaining) >= 1 else "unknown"
    name = remaining[1] if len(remaining) >= 2 else ""

    return module_path, resource_type, name, index


def humanize_resource_type(resource_type: str) -> str:
    return RESOURCE_TYPE_NAMES.get(resource_type, resource_type.replace("_", " "))


def humanize_name(name: str) -> str:
    return name.replace("_", " ").replace("-", " ")


def humanize_address(module_path: list[str], resource_type: str, name: str) -> str:
    """Convert parsed address components into a readable label.

    Avoids redundancy (don't say 'VPC VPC subnet').
    """
    human_type = humanize_resource_type(resource_type)
    human_name = humanize_name(name)

    if module_path:
        module_label = humanize_name(module_path[-1])
        type_lower = human_type.lower()
        module_lower = module_label.lower()
        name_lower = human_name.lower()

        if module_lower == type_lower or module_lower == name_lower:
            return f"{human_name} ({human_type})"
        return f"{module_label} {human_name} ({human_type})"

    return f"{human_name} ({human_type})"


# ─── Grouping (count / for_each) ──────────────────────────────────────────────

def group_resources(changes: list[ResourceChange]) -> list[tuple[str, list[ResourceChange]]]:
    """Collapse indexed duplicates into '3x web (EC2 instance)'.

    Groups by (module_path, resource_type, name) — index stripped.
    Returns (label, members) pairs in stable insertion order.
    """
    groups: dict[tuple, list[ResourceChange]] = defaultdict(list)
    order: list[tuple] = []

    for change in changes:
        key = (tuple(change.module_path), change.resource_type, change.name)
        if key not in groups:
            order.append(key)
        groups[key].append(change)

    result = []
    for key in order:
        module_path_tuple, resource_type, name = key
        module_path = list(module_path_tuple)
        members = groups[key]
        count = len(members)

        human_type = humanize_resource_type(resource_type)
        human_name = humanize_name(name)

        if module_path:
            module_label = humanize_name(module_path[-1])
            module_lower = module_label.lower()
            if module_lower == human_type.lower() or module_lower == human_name.lower():
                base = f"{human_name} ({human_type})"
            else:
                base = f"{module_label} {human_name} ({human_type})"
        else:
            base = f"{human_name} ({human_type})"

        label = f"{count}x {base}" if count > 1 else base
        result.append((label, members))

    return result


# ─── Noise Filtering ──────────────────────────────────────────────────────────
# These functions hide changes that don't matter to the user.
# Tag-only changes and computed-value resolution are noise — never show them.

def should_hide(change: ResourceChange) -> bool:
    """Return True if this change is pure noise and should be hidden."""
    # Provider changes
    if change.resource_type == 'provider':
        return True
    # No-op changes
    if change.actions == ['no-op'] or not change.actions:
        return True
    # Tag-only (updates only)
    if _is_tag_only(change):
        return True
    # Computed-only (updates only)
    if _is_computed_only(change):
        return True
    return False


def _is_tag_only(change: ResourceChange) -> bool:
    """True if only tags/tags_all differ between before/after.

    Only applies to pure UPDATE actions. Creates and deletes are never tag-only.
    If either before or after is essentially empty, don't hide — we need data to compare.
    """
    actions = change.actions
    if 'create' in actions or 'delete' in actions:
        return False

    before = change.before or {}
    after = change.after or {}

    # If either side is empty, we can't meaningfully compare — don't hide
    if not before or not after:
        return False

    all_keys = set(before.keys()) | set(after.keys())
    non_tag_keys = {k for k in all_keys if k not in ('tags', 'tags_all')}

    if not non_tag_keys:
        return True  # Only tags exist in both before and after

    for k in non_tag_keys:
        if before.get(k) != after.get(k):
            return False
    return True


def _is_computed_only(change: ResourceChange) -> bool:
    """True if all changes resolve '(known after apply)' placeholders.

    Only applies to UPDATE actions. Creates/deletes are never computed-only.
    """
    actions = change.actions
    if 'create' in actions or 'delete' in actions:
        return False

    before = change.before or {}
    after = change.after or {}

    if not before and after:
        return False  # CREATE — all values new
    if before and not after:
        return False  # DELETE — values being removed

    for k, v in after.items():
        if v == COMPUTED_MARKER:
            continue
        if before.get(k) != v:
            return False
    return True


# ─── Production Risk Classification ────────────────────────────────────────────

def classify_destroy_risk(resource: ResourceChange) -> Optional[str]:
    """Classify the risk of destroying/replacing a resource.

    Returns 'hard_stop', 'warn', or None.

    hard_stop: stateful resource with prod-pattern name — single destroy matters
    warn:      non-stateful resource with prod-pattern name, or
               stateful resource with ambiguous name
    None:      safe to proceed without flagging
    """
    # Check both resource name AND module path for production signals
    name_signal = PROD_NAME_PATTERNS.search(resource.name)
    module_signal = any(
        PROD_NAME_PATTERNS.search(m) for m in resource.module_path
    ) if resource.module_path else False

    prod_signal = bool(name_signal or module_signal)
    is_stateful = resource.resource_type in STATEFUL_RESOURCE_TYPES

    if is_stateful and prod_signal:
        return "hard_stop"      # aws_db_instance.production — full stop
    if is_stateful:
        return "warn"           # aws_db_instance.replica — worth surfacing
    if prod_signal:
        return "warn"           # aws_instance.prod-web — flag but don't block
    return None


# ─── Security Checks ──────────────────────────────────────────────────────────

def check_open_security_group(resource: ResourceChange) -> list[str]:
    """Inspect security group after-state for dangerously open rules.

    Handles both nested ingress format (aws_security_group) and
    flat rule format (aws_security_group_rule with cidr_blocks/from_port/to_port).
    Also checks egress rules.

    Returns plain-English warnings.
    """
    warnings: list[str] = []
    after = resource.after or {}

    # ── Ingress rules (nested format: aws_security_group) ──
    for ingress in after.get("ingress", []):
        if not isinstance(ingress, dict):
            continue
        cidrs = (ingress.get("cidr_blocks") or []) + (ingress.get("ipv6_cidr_blocks") or [])
        open_to_internet = "0.0.0.0/0" in cidrs or "::/0" in cidrs
        if not open_to_internet:
            continue

        from_port = ingress.get("from_port", 0) or 0
        to_port = ingress.get("to_port", 0) or 0

        if from_port == 0 and to_port == 0:
            warnings.append(
                "⚠ Security group allows ALL inbound traffic from the internet (0.0.0.0/0)"
            )
            continue

        for port, port_name in SENSITIVE_PORTS.items():
            if from_port <= port <= to_port:
                warnings.append(
                    f"⚠ Security group opens {port_name} (port {port}) to the internet (0.0.0.0/0)"
                )

    # ── Flat rule format (aws_security_group_rule) ──
    cidrs = after.get("cidr_blocks", []) or []
    from_port = after.get("from_port")
    to_port = after.get("to_port")

    if ("0.0.0.0/0" in cidrs or "::/0" in cidrs) and from_port is not None:
        if from_port == 0 and to_port == 0:
            warnings.append(
                "⚠ Security group allows ALL inbound traffic from the internet (0.0.0.0/0)"
            )
        else:
            effective_to = to_port or from_port
            for port, port_name in SENSITIVE_PORTS.items():
                if from_port <= port <= effective_to:
                    warnings.append(
                        f"⚠ Security group opens {port_name} (port {port}) to the internet (0.0.0.0/0)"
                    )
                    break

    # ── Egress rules — flag if all outbound is open ──
    for egress in after.get("egress", []):
        if not isinstance(egress, dict):
            continue
        egress_cidrs = (egress.get("cidr_blocks") or []) + (egress.get("ipv6_cidr_blocks") or [])
        has_wide = any(c in ("0.0.0.0/0", "::/0") for c in egress_cidrs)
        e_from = egress.get("from_port", 0) or 0
        e_to = egress.get("to_port", 0) or 0
        if has_wide and e_from == 0 and e_to == 0:
            warnings.append(
                "⚠ Security group allows ALL outbound traffic (egress open to 0.0.0.0/0)"
            )

    return warnings


# ─── Core Analysis ────────────────────────────────────────────────────────────

def analyze_plan(plan: dict) -> ExplainResult:
    """Parse plan JSON into a structured ExplainResult.

    This is the only function that touches the raw plan data.
    Everything downstream works with ResourceChange and ExplainResult.
    """
    resource_changes: list[dict] = plan.get("resource_changes", [])

    # ── No-op detection ──
    meaningful = [
        rc for rc in resource_changes
        if rc.get("change", {}).get("actions") not in (["no-op"], ["read"], None)
    ]

    if not meaningful:
        if plan.get("resource_drift") is not None and not resource_changes:
            return ExplainResult(refresh_only=True)
        return ExplainResult(no_op=True)

    # ── Parse all changes first, then filter ──
    result = ExplainResult()
    seen_attention: set[str] = set()
    delete_count = 0
    hard_stops: list[ResourceChange] = []
    total_raw = 0

    def add_attention(msg: str) -> None:
        if msg not in seen_attention:
            seen_attention.add(msg)
            result.attention_items.append(msg)

    for rc in meaningful:
        change = rc.get("change", {})
        actions: list[str] = change.get("actions", ["no-op"])
        module_path, resource_type, name, index = parse_address(rc.get("address", ""))

        resource = ResourceChange(
            address=rc.get("address", ""),
            resource_type=resource_type,
            name=name,
            module_path=module_path,
            actions=actions,
            before=change.get("before"),
            after=change.get("after"),
            index=index,
        )

        # ── Noise filtering ──
        if should_hide(resource):
            continue

        total_raw += 1

        # ── Classify ──
        if actions == ["create"]:
            result.creates.append(resource)

        elif actions == ["delete"]:
            result.destroys.append(resource)
            delete_count += 1
            label = humanize_address(module_path, resource_type, name)
            risk = classify_destroy_risk(resource)
            if risk == "hard_stop":
                hard_stops.append(resource)
                add_attention(f"⛔ {label} will be DESTROYED — this appears to be production infrastructure")
            elif resource_type in STATEFUL_RESOURCE_TYPES:
                add_attention(f"⚠ {label} will be DESTROYED — this may cause permanent data loss")
            else:
                add_attention(f"⚠ {label} will be DESTROYED")

        elif actions == ["update"]:
            result.updates.append(resource)

        elif set(actions) == {"delete", "create"}:
            result.replaces.append(resource)
            delete_count += 1
            label = humanize_address(module_path, resource_type, name)
            risk = classify_destroy_risk(resource)
            if risk == "hard_stop":
                hard_stops.append(resource)
                add_attention(f"⛔ {label} will be REPLACED (destroyed and recreated) — this appears to be production infrastructure")
            elif resource_type in STATEFUL_RESOURCE_TYPES:
                add_attention(f"⚠ {label} will be REPLACED (destroyed and recreated) — data loss risk")
            else:
                add_attention(f"⚠ {label} will be REPLACED (destroyed and recreated)")

        # ── Security group checks (create + update) ──
        if resource_type in SECURITY_GROUP_TYPES and resource.after:
            for warning in check_open_security_group(resource):
                add_attention(warning)

        # ── IAM changes (only modifications, not creates) ──
        if resource_type in IAM_RESOURCE_TYPES and actions not in (["create"],):
            label = humanize_resource_type(resource_type)
            add_attention(f"⚠ {label} is being modified — review permissions carefully")

    # ── Alarming plan detection ──
    total = len(result.creates) + len(result.updates) + len(result.destroys) + len(result.replaces)
    delete_ratio = delete_count / max(total, 1)

    if hard_stops:
        result.alarming = True
        names = [humanize_address(r.module_path, r.resource_type, r.name) for r in hard_stops]
        result.alarming_message = (
            f"I can see this plan, but I'm not summarizing it automatically.\n\n"
            f"It includes destruction of: {', '.join(names)}.\n"
            f"These appear to be production resources.\n\n"
            f"Full plan saved at ~/tofu-assist/pending/plan.json\n"
            f"Run `tofu-assist show --full` to review manually, then "
            f"`tofu-assist apply` to proceed."
        )
    elif delete_count >= 15 or (delete_count >= 5 and delete_ratio > 0.3):
        result.alarming = True
        result.alarming_message = (
            f"I can see this plan, but I'm not summarizing it automatically.\n"
            f"It includes {delete_count} resource deletions ({delete_ratio:.0%} of total), "
            f"including what appears to be production infrastructure.\n\n"
            f"Full plan saved at ~/tofu-assist/pending/plan.json\n"
            f"Run `tofu-assist show --full` to review manually, then "
            f"`tofu-assist apply` to proceed."
        )

    result.total_meaningful = total
    result.delete_count = delete_count
    return result


# ─── Infracost Integration ────────────────────────────────────────────────────

def get_cost_estimate(plan_json_path: str, timeout: int = 30) -> str:
    """Call Infracost CLI to get a monthly cost estimate.

    Never raises — all failure paths return a display-ready string.

    Returns:
        "$87/month"
        "$1,247/month"
        "$0/month (free tier resources only)"
        "Cost estimate unavailable — infracost not installed"
        "Cost estimate unavailable — run 'infracost auth login'"
        "Cost estimate timed out — run infracost manually"
    """
    try:
        result = subprocess.run(
            ["infracost", "breakdown", "--plan-json", plan_json_path,
             "--format", "json"],
            capture_output=True, text=True, timeout=timeout,
        )
    except FileNotFoundError:
        return "Cost estimate unavailable — infracost not installed"
    except subprocess.TimeoutExpired:
        return "Cost estimate timed out — run infracost manually"

    if result.returncode != 0:
        stderr_lower = result.stderr.lower() if result.stderr else ""
        if "api key" in stderr_lower or "auth" in stderr_lower:
            return "Cost estimate unavailable — run 'infracost auth login'"
        return "Cost estimate unavailable"

    try:
        data = json.loads(result.stdout)
        total = data.get("totalMonthlyCost", "0")
    except (json.JSONDecodeError, KeyError):
        return "Cost estimate unavailable"

    try:
        cost = float(total)
    except (ValueError, TypeError):
        return "Cost estimate unavailable"

    if cost == 0.0:
        return "$0/month (free tier or no billable resources)"

    # Format: drop cents, add thousands separator
    cost_int = round(cost)
    formatted = f"${cost_int:,}/month"
    return formatted


# ─── Checkov Integration ──────────────────────────────────────────────────────

# Only surface findings in these categories. Everything else is swallowed.
# Checkov has hundreds of rules — most are noise for a first-run workflow.
SURFACE_FINDING_KEYWORDS = [
    "public", "publicly", "0.0.0.0",
    "encrypt", "unencrypted",
    "wildcard",
    "open security group",
]


def run_security_scan(tf_dir: str, timeout: int = 60) -> SecurityResult:
    """Run Checkov static analysis on a directory of .tf files.

    Never raises — all failure paths return a SecurityResult with passed=True
    and a descriptive finding. We never block on tool failures.

    Returns SecurityResult with:
        passed:  True if no findings to surface (including tool errors)
        findings: list of plain-English attention items
        raw_failed: total Checkov failures behind the scenes
    """
    findings: list[str] = []

    try:
        result = subprocess.run(
            ["checkov", "-d", tf_dir, "-o", "json", "--quiet"],
            capture_output=True, text=True, timeout=timeout,
        )
    except FileNotFoundError:
        return SecurityResult(
            passed=True,
            findings=["Security scan unavailable — checkov not installed"],
        )
    except subprocess.TimeoutExpired:
        return SecurityResult(
            passed=True,
            findings=["Security scan timed out — run checkov manually"],
        )

    if result.returncode != 0:
        # Checkov returns non-zero on findings AND on errors.
        # Try to parse anyway — findings may still be present.
        pass

    try:
        data = json.loads(result.stdout) if result.stdout else {}
    except json.JSONDecodeError:
        return SecurityResult(
            passed=True,
            findings=["Security scan unavailable"],
        )

    results = data.get("results", {})
    failed_checks = results.get("failed_checks", [])
    summary = results.get("summary", {})
    raw_failed = summary.get("failed", len(failed_checks))

    if not failed_checks:
        return SecurityResult(passed=True, findings=[])

    for check in failed_checks:
        check_id = check.get("check_id", "")
        check_name = check.get("check_name", "")
        severity = check.get("severity", "").upper()
        resource = check.get("resource", "unknown")
        file_path = check.get("file_path", "")
        line = check.get("file_line_range", [0])[0] if check.get("file_line_range") else 0

        # Always surface CRITICAL
        if severity == "CRITICAL":
            findings.append(
                f"⛔ CRITICAL: {check_name} — {resource}"
                + (f" ({file_path}:{line})" if file_path else "")
            )
            continue

        # Surface if keyword match
        search_text = f"{check_name} {check_id}".lower()
        if any(kw in search_text for kw in SURFACE_FINDING_KEYWORDS):
            loc = f" ({file_path}:{line})" if file_path else ""
            findings.append(f"⚠ {check_name} — {resource}{loc}")

    return SecurityResult(
        passed=len(findings) == 0,
        findings=findings,
        raw_failed=raw_failed,
    )


# ─── Rendering ────────────────────────────────────────────────────────────────

def render_plain(result: ExplainResult, plan_json_path: str | None = None) -> str:
    """Render ExplainResult as plain English.

    Three sections: SUMMARY, ATTENTION REQUIRED (conditional),
    then WHAT WILL BE BUILT / CHANGED / DESTROYED.
    """
    if result.no_op:
        return "No changes. Your infrastructure matches the configuration."

    if result.refresh_only:
        return "State refreshed. No infrastructure changes will be made."

    lines: list[str] = []

    # ── SUMMARY ──
    total = sum(len(x) for x in [result.creates, result.updates, result.destroys, result.replaces])
    parts: list[str] = []
    if result.creates:
        parts.append(f"{len(result.creates)} will be created")
    if result.updates:
        parts.append(f"{len(result.updates)} will be updated")
    if result.replaces:
        parts.append(f"{len(result.replaces)} will be replaced")
    if result.destroys:
        parts.append(f"{len(result.destroys)} will be destroyed")

    lines.append("SUMMARY")
    lines.append(f"  {total} resource{'s' if total != 1 else ''}: {', '.join(parts)}.")
    cost = get_cost_estimate(plan_json_path) if plan_json_path else "calculating..."
    lines.append(f"  Estimated cost: {cost}")

    if total > 20:
        lines.append("  ⚠ This is a large plan — review carefully before applying.")
    lines.append("")

    # ── ATTENTION REQUIRED ──
    # Severity-sorted: critical items first, then warnings.
    # Visual framing so users SEE this section, not scroll past it.
    if result.attention_items:
        critical = [i for i in result.attention_items if i.startswith("⛔")]
        warnings = [i for i in result.attention_items if not i.startswith("⛔")]
        crit_count = len(critical)
        warn_count = len(warnings)

        lines.append("━" * 60)
        lines.append("")
        if crit_count > 0 and warn_count > 0:
            lines.append(f"⛔  ATTENTION REQUIRED — {crit_count} CRITICAL  ·  {warn_count} WARNING(S)")
        elif crit_count > 0:
            lines.append(f"⛔  ATTENTION REQUIRED — {crit_count} CRITICAL ISSUE(S)")
        else:
            lines.append(f"⚠  ATTENTION REQUIRED — {warn_count} WARNING(S)")
        lines.append("")

        for item in critical:
            lines.append(f"  {item}")

        if critical and warnings:
            lines.append("")
            lines.append("  ─── Additional warnings ───")
            lines.append("")

        for item in warnings:
            lines.append(f"  {item}")

        lines.append("")
        if crit_count > 0:
            lines.append("  ⛔ DO NOT APPLY until you understand and accept these risks.")
        else:
            lines.append("  ⚠ Review these items before applying.")
        lines.append("")
        lines.append("━" * 60)
        lines.append("")

    # ── WHAT WILL BE BUILT ──
    if result.creates or result.replaces:
        lines.append("WHAT WILL BE BUILT")
        all_new = result.creates + result.replaces
        replace_set = set(id(r) for r in result.replaces)
        for label, members in group_resources(all_new):
            marker = "↺" if any(id(m) in replace_set for m in members) else "+"
            lines.append(f"  {marker} {label}")
        lines.append("")

    # ── WHAT WILL CHANGE ──
    if result.updates:
        lines.append("WHAT WILL CHANGE")
        for label, _ in group_resources(result.updates):
            lines.append(f"  ~ {label}")
        lines.append("")

    # ── WHAT WILL BE DESTROYED ──
    if result.destroys:
        lines.append("WHAT WILL BE DESTROYED")
        for label, _ in group_resources(result.destroys):
            lines.append(f"  - {label}")
        lines.append("")

    return "\n".join(lines).rstrip()


def render_json(result: ExplainResult) -> str:
    """Machine-readable output for piping into the larger tofu-assist pipeline."""
    def _serialize(changes: list[ResourceChange]) -> list[dict]:
        return [
            {"address": r.address, "type": r.resource_type, "name": r.name,
             "module_path": r.module_path, "actions": r.actions}
            for r in changes
        ]

    return json.dumps({
        "no_op": result.no_op,
        "refresh_only": result.refresh_only,
        "alarming": result.alarming,
        "alarming_message": result.alarming_message,
        "counts": {
            "creates": len(result.creates),
            "updates": len(result.updates),
            "destroys": len(result.destroys),
            "replaces": len(result.replaces),
        },
        "creates": _serialize(result.creates),
        "updates": _serialize(result.updates),
        "destroys": _serialize(result.destroys),
        "replaces": _serialize(result.replaces),
        "attention_items": result.attention_items,
    }, indent=2)


# ─── Schema Validation ────────────────────────────────────────────────────────

def validate_schema(plan: dict) -> Optional[str]:
    """Validate that this looks like a terraform/opentofu plan JSON.

    Returns a plain-English error string, or None if valid.
    OpenTofu forked from pre-BUSL Terraform — schema is identical.
    Both use format_version "1.0" or "1.1".
    """
    format_version = plan.get("format_version", "")

    if not format_version:
        return (
            "The plan output is missing a format_version field. "
            "Make sure you're running: terraform plan -json | tofu-assist explain"
        )

    major = format_version.split(".")[0]
    if major != "1":
        return (
            f"Unexpected plan format version: {format_version} (expected 1.x).\n"
            f"Your infrastructure has not been changed.\n"
            f"Update tofu-assist, or run `tofu-assist diagnose` to report this."
        )

    expected_keys = {"resource_changes", "variables", "planned_values", "prior_state"}
    if not expected_keys.intersection(plan.keys()):
        return (
            "This doesn't look like a terraform plan JSON output.\n"
            "Expected keys like 'resource_changes' or 'planned_values' are missing."
        )

    return None


# ─── Input Parsing ────────────────────────────────────────────────────────────

def load_plan_json(raw: str) -> Optional[dict]:
    """Parse raw input into a plan dict.

    Handles:
    - Standard single-object plan JSON
    - Streamed output (multiple JSON objects per line — older tf versions)
      → we want the object with format_version / resource_changes
    """
    raw = raw.strip()
    if not raw:
        return None

    try:
        candidate = json.loads(raw)
        if isinstance(candidate, dict):
            return candidate
    except json.JSONDecodeError:
        pass

    # Fall back: line-by-line, find the plan object
    for line in reversed(raw.splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            candidate = json.loads(line)
            if isinstance(candidate, dict) and (
                "resource_changes" in candidate or "format_version" in candidate
            ):
                return candidate
        except json.JSONDecodeError:
            continue

    return None


# ─── Error Messages ───────────────────────────────────────────────────────────

ERR_NOT_JSON = """\
I couldn't parse the plan output — it doesn't appear to be valid JSON.

Make sure you're running:
  tofu plan -json | tofu-assist explain
  tofu-assist explain plan.json

Your infrastructure has not been changed."""

ERR_EMPTY_INPUT = """\
No input received.

Usage:
  tofu plan -json | tofu-assist explain
  tofu-assist explain plan.json"""


# ─── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    json_output = "--json" in sys.argv
    tf_dir: str | None = None
    remaining: list[str] = []
    argv = sys.argv[1:]
    i = 0
    while i < len(argv):
        if argv[i] == "--tf-dir" and i + 1 < len(argv):
            tf_dir = argv[i + 1]
            i += 2
        elif argv[i] == "--json":
            json_output = True
            i += 1
        else:
            remaining.append(argv[i])
            i += 1
    args = remaining

    # Read raw input
    if args:
        filepath = args[0]
        try:
            with open(filepath) as f:
                raw = f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {filepath}", file=sys.stderr)
            sys.exit(1)
        except PermissionError:
            print(f"Error: Permission denied: {filepath}", file=sys.stderr)
            sys.exit(1)
    else:
        if sys.stdin.isatty():
            print(ERR_EMPTY_INPUT, file=sys.stderr)
            sys.exit(1)
        raw = sys.stdin.read()

    if not raw.strip():
        print(ERR_EMPTY_INPUT, file=sys.stderr)
        sys.exit(1)

    # Parse JSON — Error state 1
    plan = load_plan_json(raw)
    if plan is None:
        print(ERR_NOT_JSON, file=sys.stderr)
        sys.exit(1)

    # Validate schema — Error state 2
    schema_error = validate_schema(plan)
    if schema_error:
        print(f"\n{schema_error}\n", file=sys.stderr)
        sys.exit(2)

    # Analyze and render — Error state 3 (unexpected structure)
    try:
        result = analyze_plan(plan)
    except Exception as exc:
        print(
            "The plan output had an unexpected structure. "
            "Your infrastructure has not been changed.\n"
            "Run `tofu-assist diagnose` to report this, or update tofu-assist.",
            file=sys.stderr,
        )
        print(f"\nTechnical detail: {exc}", file=sys.stderr)
        sys.exit(2)

    # Alarming plan — Error state 4 (too destructive to auto-summarize)
    if result.alarming:
        print(result.alarming_message, file=sys.stderr)
        sys.exit(3)

    # Run security scan on .tf files if directory provided
    if tf_dir:
        security = run_security_scan(tf_dir)
        if security.findings:
            result.attention_items = security.findings + result.attention_items

    # Save plan to temp file for Infracost to consume
    if not json_output:
        tmp = tempfile.NamedTemporaryFile(
            mode='w', suffix='.json', prefix='tofu-plan-', delete=False
        )
        json.dump(plan, tmp)
        tmp.close()
        plan_path = tmp.name
    else:
        plan_path = None

    try:
        output = render_json(result) if json_output else render_plain(result, plan_path)
        print(output)
    finally:
        if plan_path:
            Path(plan_path).unlink(missing_ok=True)


if __name__ == "__main__":
    main()
