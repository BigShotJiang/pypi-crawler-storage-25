import gc
import uvicorn
import os
import json
import re
import socket
import asyncio
import threading
from importlib.metadata import PackageNotFoundError, version as package_version
from platformdirs import user_config_dir


from contextlib import asynccontextmanager
from PIL import Image
from fastapi import (
    FastAPI,
    Request,
    HTTPException,
    WebSocket,
    WebSocketDisconnect,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from pillow_heif import register_heif_opener

from sqlmodel import select

from pixlstash.db_models import (
    Picture,
    User,
)

from pixlstash.event_types import EventType
from pixlstash.auth import AuthService, LoginRequest
from pixlstash.picture_tagger import PictureTagger
from pixlstash.pixl_logging import get_logger, uvicorn_log_config
from pixlstash.startup_checks import StartupChecks
from pixlstash.vault import Vault
from pixlstash.routes.config import create_router as create_config_router
from pixlstash.routes.characters import create_router as create_characters_router
from pixlstash.routes.picture_sets import create_router as create_picture_sets_router
from pixlstash.routes.projects import create_router as create_projects_router
from pixlstash.routes.tags import create_router as create_tags_router
from pixlstash.routes.stacks import create_router as create_stacks_router
from pixlstash.routes.pictures import (
    create_router as create_pictures_router,
    clear_stats_cache,
)
from pixlstash.routes.comfyui import create_router as create_comfyui_router
from pixlstash.routes.tag_predictions import (
    create_router as create_tag_predictions_router,
)
from pixlstash.routes.reference_folders import (
    create_router as create_reference_folders_router,
)
from pixlstash.routes.import_folders import (
    create_router as create_import_folders_router,
)
from pixlstash.routes.filesystem import create_router as create_filesystem_router
from pixlstash.utils.image_processing.image_utils import ImageUtils
from pixlstash.utils.path_mapper import PathMapper
from pixlstash.utils.rate_limiter import RateLimitMiddleware


# Logging will be set up after config is loaded
logger = get_logger(__name__)


def _get_lan_ip() -> str | None:
    """Return the machine's primary LAN IP by probing an outbound UDP route.

    Does not send any data. Returns None if the IP cannot be determined.
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


API_OPENAPI_TAGS = [
    {
        "name": "config",
        "description": "User configuration, auth helpers, worker progress and server config utilities.",
    },
    {
        "name": "characters",
        "description": "Character CRUD, summaries, reference pictures and face assignment endpoints.",
    },
    {
        "name": "picture_sets",
        "description": "Picture set CRUD and picture membership management.",
    },
    {
        "name": "tags",
        "description": "Tag management for pictures, faces and hands.",
    },
    {
        "name": "stacks",
        "description": "Stack creation, ordering and membership operations.",
    },
    {
        "name": "pictures",
        "description": "Picture listing, metadata, thumbnails, import/export and media operations.",
    },
    {
        "name": "comfyui",
        "description": "ComfyUI workflow management and image-to-image execution.",
    },
    {
        "name": "projects",
        "description": "Project management, including character/set scoping and file attachments.",
    },
]

API_V1_PREFIX = "/api/v1"


class Server:
    """
    Main server class for the PixlStash FastAPI application.

    Attributes:
        server_config_path(str): Server-side-only configuration file.
        DEFAULT_MAX_VRAM_GB: Class-level VRAM budget override (GB). When set
            (e.g. by the pytest ``--max-vram-gb`` option) it takes precedence
            over the persisted user config value for all Server instances.
            ``None`` means use the user config.
        DEFAULT_FORCE_CPU: Class-level CPU-inference override. When ``True``,
            forces CPU inference after startup checks complete, preventing the
            startup check from clobbering a ``--force-cpu`` flag set by the
            test framework. ``None`` means startup checks decide.
        DEFAULT_PORT: Class-level port override. When set (e.g. by the pytest
            conftest to a free OS-assigned port), it replaces the port from the
            persisted config for all Server instances. ``None`` means use the
            config value.
        DEFAULT_CLEANUP_MISSING_PICTURES: Class-level startup cleanup toggle.
            When ``True``, startup removes picture rows that point to missing
            source files before thumbnail generation. ``False`` means disabled.
    """

    DEFAULT_MAX_VRAM_GB: float | None = None
    DEFAULT_FORCE_CPU: bool | None = None
    DEFAULT_PORT: int | None = None
    DEFAULT_CLEANUP_MISSING_PICTURES: bool = False

    @staticmethod
    def running_in_docker() -> bool:
        """Return True when the server is running inside a Docker container."""
        return os.environ.get("PIXLSTASH_IN_DOCKER", "") == "1"

    def __init__(
        self,
        server_config_path,
        path_map: dict[str, str] | None = None,
    ):
        """
        Initialize the Server instance.

        Args:
            server_config_path (str): Path to the server-only config file.
            path_map: Optional dict mapping host path prefixes to their
                container equivalents. Set by the ``--path-map`` CLI arg.
        """
        # Ensure garbage collection before starting server to free up memory.
        # This is mainly to ensure repeated runs within the testing framework do not accumulate memory usage.
        gc.collect()

        self._server_config_path = server_config_path

        self.path_mapper = PathMapper(path_map)

        self._server_config = self._init_server_config(server_config_path)
        self._startup_check_report = StartupChecks(
            server_config=self._server_config,
            server_config_path=self._server_config_path,
            logger=logger,
        ).run()
        # Re-apply any test-level FORCE_CPU override that startup checks may have clobbered.
        if Server.DEFAULT_FORCE_CPU is not None:
            PictureTagger.FORCE_CPU = Server.DEFAULT_FORCE_CPU
        with open(server_config_path, "w") as f:
            json.dump(self._server_config, f, indent=2)

        # SSL config
        if self._server_config.get("require_ssl", False):
            self._ensure_ssl_certificates()

        logger.debug(
            "Creating Vault instance with image root: "
            + str(self._server_config["image_root"])
        )

        register_heif_opener()

        self.vault = Vault(
            image_root=self._server_config["image_root"],
            description=User().description,
            server_config_path=self._server_config_path,
            path_mapper=self.path_mapper,
        )

        self._ws_clients = []
        self._ws_clients_lock = threading.Lock()
        self._ws_loop = None
        self.vault.add_event_listener(self._handle_vault_event)

        self.auth = AuthService(
            self.vault.db,
            self._server_config,
            self._server_config_path,
            logger,
        )
        self._user = self.auth.ensure_user()
        if self._user and self._user.description is not None:
            self.vault.set_description(self._user.description)
        self.vault.set_keep_models_in_memory(
            getattr(self._user, "keep_models_in_memory", True)
        )
        effective_vram_gb = (
            Server.DEFAULT_MAX_VRAM_GB
            if Server.DEFAULT_MAX_VRAM_GB is not None
            else getattr(self._user, "max_vram_gb", None)
        )
        self.vault.set_max_vram_usage_gb(effective_vram_gb)
        self.vault.set_wd14_tagger_enabled(
            getattr(self._user, "wd14_tagger_enabled", False)
        )
        self.vault.set_custom_tagger_enabled(
            getattr(self._user, "custom_tagger_enabled", True)
        )
        self.vault.set_wd14_threshold(getattr(self._user, "wd14_threshold", None))
        self.vault.set_custom_tagger_threshold_offset(
            getattr(self._user, "custom_tagger_threshold_offset", None)
        )

        self.api = FastAPI(
            title="PixlStash API",
            version=self._get_version(),
            description=(
                "PixlStash backend API for picture management, tagging, stacks, "
                "sets, character workflows and ComfyUI integration."
            ),
            openapi_tags=API_OPENAPI_TAGS,
            lifespan=self.lifespan,
        )
        # CORS: always allow localhost/127.0.0.1 on any port plus the machine's
        # own LAN IP (any port) so the Vite dev server works over LAN without
        # any extra configuration. Additional origins can be added via cors_origins.
        self.allow_origins = list(self._server_config.get("cors_origins") or [])
        _cors_hosts = ["localhost", r"127\.0\.0\.1"]
        _lan_ip = _get_lan_ip()
        if _lan_ip and _lan_ip not in ("127.0.0.1", "localhost"):
            _cors_hosts.append(re.escape(_lan_ip))
        self.allow_origin_regex = r"^https?\://(" + "|".join(_cors_hosts) + r")(:\d+)?$"
        self.api.add_middleware(
            CORSMiddleware,
            allow_origins=self.allow_origins,
            allow_origin_regex=self.allow_origin_regex,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        self._add_cors_exception_handler()
        self._setup_routes()

        # Temporary storage for export tasks
        self.export_tasks = {}

        # Temporary storage for import tasks
        self.import_tasks = {}
        self._shutdown_on_lifespan = False

    def __enter__(self):
        # Allow use as a context manager for robust cleanup
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if hasattr(self, "vault"):
            logger.info("Closing the vault and cleaning up resources")
            self.vault.close()
        gc.collect()

    def _handle_vault_event(self, event_type: EventType, data=None):
        if event_type in (EventType.CHANGED_TAGS, EventType.CLEARED_TAGS):
            clear_stats_cache()
        if not self._ws_loop:
            return
        coro = self._broadcast_ws_event(event_type, data)
        try:
            logger.debug("Got the following event from vault: %s", event_type)
            asyncio.run_coroutine_threadsafe(coro, self._ws_loop)
        except Exception as exc:
            logger.warning("Failed to dispatch websocket event: %s", exc)
            coro.close()  # prevent 'coroutine never awaited' ResourceWarning

    def _should_send_ws_update(self, event_type: EventType, filters: dict) -> bool:
        return event_type in (
            EventType.CHANGED_PICTURES,
            EventType.PICTURE_IMPORTED,
            EventType.PLUGIN_PROGRESS,
            EventType.CHANGED_TAGS,
            EventType.CLEARED_TAGS,
            EventType.CHANGED_CHARACTERS,
            EventType.CHANGED_FACES,
        )

    async def _broadcast_ws_event(self, event_type: EventType, data=None):
        with self._ws_clients_lock:
            clients = list(self._ws_clients)
        if not clients:
            return
        if event_type in (EventType.CHANGED_CHARACTERS, EventType.CHANGED_FACES):
            payload = {
                "type": "characters_changed",
                "event": event_type.name,
            }
        elif event_type in (EventType.CHANGED_TAGS, EventType.CLEARED_TAGS):
            picture_ids = data if isinstance(data, (list, tuple, set)) else []
            payload = {
                "type": "tags_changed",
                "event": event_type.name,
                "picture_ids": list(picture_ids),
            }
        elif event_type == EventType.PICTURE_IMPORTED:
            picture_ids = data if isinstance(data, (list, tuple, set)) else []
            payload = {
                "type": "picture_imported",
                "event": event_type.name,
                "picture_ids": list(picture_ids),
            }
        elif event_type == EventType.PLUGIN_PROGRESS:
            progress_payload = data if isinstance(data, dict) else {}
            payload = {
                "type": "plugin_progress",
                "event": event_type.name,
                **progress_payload,
            }
        else:
            picture_ids = data if isinstance(data, (list, tuple, set)) else []
            payload = {
                "type": "pictures_changed",
                "event": event_type.name,
                "picture_ids": list(picture_ids) if picture_ids else [],
            }
        stale = []
        for client in clients:
            ws = client.get("ws")
            filters = client.get("filters") or {}
            if not ws:
                stale.append(client)
                continue
            if not self._should_send_ws_update(event_type, filters):
                continue
            try:
                logger.debug("Sending websocket event: %s", payload)
                await ws.send_json(payload)
            except Exception:
                stale.append(client)
        if stale:
            with self._ws_clients_lock:
                for client in stale:
                    if client in self._ws_clients:
                        self._ws_clients.remove(client)

    def _generate_missing_thumbnails(self):
        def fetch_pictures(session):
            return session.exec(select(Picture.id, Picture.file_path)).all()

        rows = self.vault.db.run_immediate_read_task(fetch_pictures)
        if not rows:
            logger.info("No pictures found for thumbnail generation.")
            return

        missing = []
        for row in rows:
            pic_id, file_path = row
            if not file_path:
                continue
            thumb_path = ImageUtils.get_thumbnail_path(self.vault.image_root, file_path)
            if thumb_path and os.path.exists(thumb_path):
                continue
            missing.append((pic_id, file_path))

        total = len(missing)
        if total == 0:
            logger.debug("All thumbnails already exist.")
            return

        logger.info("Generating %s missing thumbnails at startup.", total)
        generated = 0
        skipped = 0
        missing_source_count = 0
        for index, (pic_id, file_path) in enumerate(missing, start=1):
            resolved = ImageUtils.resolve_picture_path(self.vault.image_root, file_path)
            if not resolved or not os.path.exists(resolved):
                missing_source_count += 1
                skipped += 1
                logger.warning(
                    "Missing source file for thumbnail generation: %s", resolved
                )
                if (
                    missing_source_count == 1
                    and not Server.DEFAULT_CLEANUP_MISSING_PICTURES
                ):
                    logger.info(
                        "Startup cleanup tip: run with '--cleanup-missing-pictures' "
                        "to remove stale picture records that point to missing files."
                    )
                continue
            img = ImageUtils.load_image_or_video(resolved)
            if img is None:
                skipped += 1
                logger.warning(
                    "Failed to load image for thumbnail generation: %s", resolved
                )
                continue
            if not isinstance(img, Image.Image):
                img = Image.fromarray(img)
            thumbnail_bytes = ImageUtils.generate_thumbnail_bytes(img)
            if not thumbnail_bytes:
                skipped += 1
                logger.warning(
                    "Failed to generate thumbnail bytes for picture %s", pic_id
                )
                continue
            saved = ImageUtils.write_thumbnail_bytes(
                self.vault.image_root, file_path, thumbnail_bytes
            )
            if saved:
                generated += 1
            else:
                skipped += 1
                logger.warning("Failed to persist thumbnail for picture %s", pic_id)
            if index % 250 == 0:
                logger.info("Thumbnail generation progress: %s/%s", index, total)

        logger.info(
            "Thumbnail generation completed: %s generated, %s skipped (%s missing source files).",
            generated,
            skipped,
            missing_source_count,
        )

    def _cleanup_missing_pictures(self):
        def fetch_pictures(session):
            return session.exec(select(Picture.id, Picture.file_path)).all()

        rows = self.vault.db.run_immediate_read_task(fetch_pictures)
        if not rows:
            logger.info("No pictures found for startup missing-file cleanup.")
            return

        missing_ids = []
        thumbnail_candidates = []
        for row in rows:
            pic_id, file_path = row
            resolved = None
            if file_path:
                resolved = ImageUtils.resolve_picture_path(
                    self.vault.image_root, file_path
                )
            if not resolved or not os.path.isfile(resolved):
                missing_ids.append(pic_id)
                if file_path:
                    thumbnail_candidates.append(file_path)

        if not missing_ids:
            logger.info("Startup missing-file cleanup found no stale picture records.")
            return

        logger.warning(
            "Startup missing-file cleanup removing %s stale picture records.",
            len(missing_ids),
        )

        def delete_rows(session, ids: list[int]):
            deleted_count = 0
            pictures = session.exec(select(Picture).where(Picture.id.in_(ids))).all()
            for pic in pictures:
                session.delete(pic)
                deleted_count += 1
            session.commit()
            return deleted_count

        deleted_count = self.vault.db.run_task(delete_rows, missing_ids)

        thumbnails_removed = 0
        for rel_path in thumbnail_candidates:
            thumb_path = ImageUtils.get_thumbnail_path(self.vault.image_root, rel_path)
            if not thumb_path or not os.path.isfile(thumb_path):
                continue
            try:
                os.remove(thumb_path)
                thumbnails_removed += 1
            except Exception as exc:
                logger.warning(
                    "Failed to delete orphan thumbnail %s: %s", thumb_path, exc
                )

        logger.info(
            "Startup missing-file cleanup completed: %s records removed, %s orphan thumbnails removed.",
            deleted_count,
            thumbnails_removed,
        )

    def run(self):
        self._shutdown_on_lifespan = True
        version = self._get_version()
        host = self._server_config.get("host", "127.0.0.1")
        port = self._server_config.get("port", 9537)
        scheme = "https" if self._server_config.get("require_ssl", False) else "http"
        server_url = f"{scheme}://{host}:{port}"
        _w = 54
        _b = "═" * _w
        print(
            f"\n"
            f"  ╔{_b}╗\n"
            f"  ║{'  PixlStash  v' + version:<{_w}}║\n"
            f"  ╠{_b}╣\n"
            f"  ║{'  GitHub : https://github.com/pikselkroken/pixlstash':<{_w}}║\n"
            f"  ║{'  Server : ' + server_url:<{_w}}║\n"
            f"  ╚{_b}╝\n"
        )
        uvicorn_kwargs = dict(
            host=host,
            port=port,
            log_config=uvicorn_log_config,
        )
        if self._server_config.get("require_ssl", False):
            uvicorn_kwargs["ssl_keyfile"] = self._server_config.get("ssl_keyfile")
            uvicorn_kwargs["ssl_certfile"] = self._server_config.get("ssl_certfile")
            print(
                f"[SSL] Running with SSL: keyfile={self._server_config.get('ssl_keyfile')}, certfile={self._server_config.get('ssl_certfile')}"
            )
        try:
            uvicorn.run(self.api, **uvicorn_kwargs)
        finally:
            if hasattr(self, "vault"):
                self.vault.close()

    @asynccontextmanager
    async def lifespan(self, app):
        # Startup logic
        loop = asyncio.get_running_loop()
        # Only claim _ws_loop if nothing else (e.g. a WebSocket handler) has set it
        # yet. This avoids overwriting the WebSocket loop when TestClient creates a
        # fresh event loop per HTTP request.
        was_set_by_us = self._ws_loop is None
        if was_set_by_us:
            self._ws_loop = loop
        if Server.DEFAULT_CLEANUP_MISSING_PICTURES:
            await loop.run_in_executor(None, self._cleanup_missing_pictures)
        if self._server_config.get("generate_thumbnails_on_startup", True):
            await loop.run_in_executor(None, self._generate_missing_thumbnails)
        host = self._server_config.get("host", "127.0.0.1")
        port = self._server_config.get("port", 9537)
        scheme = "https" if self._server_config.get("require_ssl", False) else "http"
        logger.info(
            "PixlStash is ready. Open in your browser: %s://%s:%s/", scheme, host, port
        )
        yield
        # Shutdown logic — only clear _ws_loop if this lifespan instance set it
        if was_set_by_us:
            self._ws_loop = None
        if self._shutdown_on_lifespan and hasattr(self, "vault"):
            self.vault.close()

    @staticmethod
    def _init_server_config(server_config_path):
        config_dir = os.path.dirname(server_config_path)
        os.makedirs(config_dir, exist_ok=True)

        # SSL certs are always stored in the platform user-config dir so they
        # stay in a consistent, writable location regardless of where the
        # server-config file itself resides (e.g. a custom --server-config path).
        _ssl_dir = os.path.join(user_config_dir("pixlstash"), "ssl")
        default_log_path = os.path.join(config_dir, "server.log")
        default_ssl_cert_path = os.path.join(_ssl_dir, "cert.pem")
        default_ssl_key_path = os.path.join(_ssl_dir, "key.pem")
        default_image_root = os.path.join(config_dir, "images")

        server_config = {}
        if not os.path.exists(server_config_path):
            server_config = {
                "host": "localhost",
                "port": 9537,
                "log_level": "info",
                "log_file": default_log_path,
                "require_ssl": False,
                "ssl_keyfile": default_ssl_key_path,
                "ssl_certfile": default_ssl_cert_path,
                "cookie_samesite": "Lax",
                "cookie_secure": False,
                "image_root": default_image_root,
                "default_device": "auto",
                "min_free_disk_gb": 1.0,
                "min_free_vram_mb": 1024.0,
                "cors_origins": [],
                "max_attachment_size_mb": 50,
                "filesystem_roots": [],
            }
            with open(server_config_path, "w") as f:
                json.dump(server_config, f, indent=2)
        else:
            with open(server_config_path, "r") as f:
                server_config = json.load(f)

                # Ensure server config options exist
                if "host" not in server_config:
                    server_config["host"] = "localhost"
                if "port" not in server_config:
                    server_config["port"] = 8000
                if "log_level" not in server_config:
                    server_config["log_level"] = "info"
                if "log_file" not in server_config:
                    server_config["log_file"] = default_log_path
                if "require_ssl" not in server_config:
                    server_config["require_ssl"] = False
                if "ssl_keyfile" not in server_config:
                    server_config["ssl_keyfile"] = default_ssl_key_path
                if "ssl_certfile" not in server_config:
                    server_config["ssl_certfile"] = default_ssl_cert_path
                if "cookie_samesite" not in server_config:
                    server_config["cookie_samesite"] = "Lax"
                if "cookie_secure" not in server_config:
                    server_config["cookie_secure"] = False
                if "image_root" not in server_config:
                    server_config["image_root"] = default_image_root
                if "default_device" not in server_config:
                    server_config["default_device"] = "auto"
                if "min_free_disk_gb" not in server_config:
                    server_config["min_free_disk_gb"] = 1.0
                if "min_free_vram_mb" not in server_config:
                    server_config["min_free_vram_mb"] = 1024.0
                if "cors_origins" not in server_config:
                    server_config["cors_origins"] = []
                if "max_attachment_size_mb" not in server_config:
                    server_config["max_attachment_size_mb"] = 50
                if "generate_thumbnails_on_startup" not in server_config:
                    server_config["generate_thumbnails_on_startup"] = True
                if "filesystem_roots" not in server_config:
                    server_config["filesystem_roots"] = []

        # Resolve SSL paths that are relative: interpret them relative to the
        # config file's directory, not the process's CWD, so that the certs
        # always live alongside the config regardless of where the server is
        # launched from.
        for key in ("ssl_keyfile", "ssl_certfile"):
            value = server_config.get(key)
            if value and not os.path.isabs(value):
                server_config[key] = os.path.join(config_dir, value)

        # Apply any test-level port override (set by the pytest conftest before
        # Server is instantiated). This lets tests run on a free port even when
        # the production server is already occupying the configured port.
        if Server.DEFAULT_PORT is not None:
            server_config["port"] = Server.DEFAULT_PORT

        return server_config

    def _ensure_ssl_certificates(self):
        import datetime

        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID

        keyfile = self._server_config.get("ssl_keyfile")
        certfile = self._server_config.get("ssl_certfile")
        # If either file is missing, generate self-signed cert
        if not (os.path.exists(keyfile) and os.path.exists(certfile)):
            os.makedirs(os.path.dirname(keyfile), exist_ok=True)
            os.makedirs(os.path.dirname(certfile), exist_ok=True)
            print(f"[SSL] Generating self-signed certificate: {certfile}, {keyfile}")
            try:
                private_key = rsa.generate_private_key(
                    public_exponent=65537,
                    key_size=2048,
                )
                subject = issuer = x509.Name(
                    [x509.NameAttribute(NameOID.COMMON_NAME, "localhost")]
                )
                now = datetime.datetime.now(datetime.timezone.utc)
                cert = (
                    x509.CertificateBuilder()
                    .subject_name(subject)
                    .issuer_name(issuer)
                    .public_key(private_key.public_key())
                    .serial_number(x509.random_serial_number())
                    .not_valid_before(now)
                    .not_valid_after(now + datetime.timedelta(days=365))
                    .add_extension(
                        x509.SubjectAlternativeName([x509.DNSName("localhost")]),
                        critical=False,
                    )
                    .sign(private_key, hashes.SHA256())
                )
                with open(keyfile, "wb") as f:
                    f.write(
                        private_key.private_bytes(
                            serialization.Encoding.PEM,
                            serialization.PrivateFormat.TraditionalOpenSSL,
                            serialization.NoEncryption(),
                        )
                    )
                with open(certfile, "wb") as f:
                    f.write(cert.public_bytes(serialization.Encoding.PEM))
            except Exception as e:
                print(f"[SSL] Failed to generate self-signed certificate: {e}")
                raise

    def _add_cors_exception_handler(self):
        @self.api.exception_handler(HTTPException)
        async def cors_exception_handler(request, exc):
            origin = request.headers.get("origin")
            headers = {
                "Access-Control-Allow-Credentials": "true",
            }
            if origin and (
                origin in self.allow_origins
                or (
                    self.allow_origin_regex
                    and re.match(self.allow_origin_regex, origin)
                )
            ):
                headers["Access-Control-Allow-Origin"] = origin
            return JSONResponse(
                status_code=exc.status_code,
                content={"detail": exc.detail},
                headers=headers,
            )

        @self.api.exception_handler(Exception)
        async def generic_exception_handler(request, exc):
            logger.error(f"Unhandled exception: {exc}")
            origin = request.headers.get("origin")
            headers = {
                "Access-Control-Allow-Credentials": "true",
            }
            if origin and (
                origin in self.allow_origins
                or (
                    self.allow_origin_regex
                    and re.match(self.allow_origin_regex, origin)
                )
            ):
                headers["Access-Control-Allow-Origin"] = origin
            return JSONResponse(
                status_code=500,
                content={"detail": "Internal Server Error"},
                headers=headers,
            )

        @self.api.exception_handler(RequestValidationError)
        async def validation_exception_handler(request, exc):
            origin = request.headers.get("origin")
            headers = {
                "Access-Control-Allow-Credentials": "true",
            }
            if origin and (
                origin in self.allow_origins
                or (
                    self.allow_origin_regex
                    and re.match(self.allow_origin_regex, origin)
                )
            ):
                headers["Access-Control-Allow-Origin"] = origin

            detail = exc.errors()
            for err in detail:
                if err.get("type") == "string_too_short" and "password" in (
                    err.get("loc") or []
                ):
                    return JSONResponse(
                        status_code=422,
                        content={
                            "detail": "Password must be at least 8 characters long."
                        },
                        headers=headers,
                    )

            return JSONResponse(
                status_code=422,
                content={"detail": detail},
                headers=headers,
            )

    def _get_version(self):
        # Prefer pyproject.toml when running from the repo so that the version
        # is always authoritative and never stale from an old editable install.
        try:
            import tomllib
        except ImportError:
            import tomli as tomllib
        pyproject_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), "pyproject.toml"
        )
        try:
            with open(pyproject_path, "rb") as f:
                data = tomllib.load(f)
            ver = data.get("project", {}).get("version")
            if ver:
                return ver
        except OSError as exc:
            logger.debug("Could not read version from pyproject.toml: %s", exc)

        # Fall back to installed package metadata (pip install / wheel deployment).
        try:
            return package_version("pixlstash")
        except PackageNotFoundError:
            return "unknown"

    def _get_frontend_dist_dir(self):
        package_dir = os.path.abspath(os.path.dirname(__file__))
        packaged_dist_dir = os.path.join(package_dir, "frontend", "dist")
        if os.path.isdir(packaged_dist_dir):
            return packaged_dist_dir

        repo_root = os.path.abspath(os.path.join(package_dir, ".."))
        repo_dist_dir = os.path.join(repo_root, "frontend", "dist")
        if os.path.isdir(repo_dist_dir):
            return repo_dist_dir

        return None

    def _get_frontend_index_path(self):
        dist_dir = self._get_frontend_dist_dir()
        if not dist_dir:
            return None
        index_path = os.path.join(dist_dir, "index.html")
        if not os.path.isfile(index_path):
            return None
        return index_path

    def _setup_routes(self):
        ###############################
        # Rate limiting              ##
        ###############################
        self.api.add_middleware(RateLimitMiddleware)

        ###############################
        # Static file endpoints      ##
        ###############################
        dist_dir = self._get_frontend_dist_dir()
        if dist_dir:
            assets_dir = os.path.join(dist_dir, "assets")
            if os.path.isdir(assets_dir):
                self.api.mount(
                    "/assets",
                    StaticFiles(directory=assets_dir),
                    name="frontend-assets",
                )

        @self.api.get("/")
        async def read_root():
            index_path = self._get_frontend_index_path()
            if index_path:
                return FileResponse(index_path)
            version = self._get_version()
            return {"message": "PixlStash REST API", "version": version}

        @self.api.get("/version")
        async def read_version():
            version = self._get_version()
            install_type = "docker" if Server.running_in_docker() else "pip"
            return {
                "message": "PixlStash REST API",
                "version": version,
                "install_type": install_type,
            }

        @self.api.get("/favicon.ico")
        def favicon():
            index_path = self._get_frontend_index_path()
            if index_path:
                favicon_path = os.path.join(os.path.dirname(index_path), "favicon.ico")
                if os.path.isfile(favicon_path):
                    return FileResponse(
                        favicon_path, media_type="image/vnd.microsoft.icon"
                    )
            favicon_path = os.path.join(
                os.path.dirname(__file__), "..", "frontend", "public", "favicon.ico"
            )
            return FileResponse(favicon_path, media_type="image/vnd.microsoft.icon")

        @self.api.websocket(f"{API_V1_PREFIX}/ws/updates")
        async def websocket_updates(websocket: WebSocket):
            await websocket.accept()
            # Always refresh _ws_loop so it tracks the currently-running event loop.
            # In production (uvicorn) this is always the same loop; in tests each
            # WebSocket session may run on a different loop than HTTP requests.
            self._ws_loop = asyncio.get_running_loop()
            client = {"ws": websocket, "filters": {}}
            with self._ws_clients_lock:
                self._ws_clients.append(client)
            try:
                while True:
                    message = await websocket.receive_text()
                    if not message:
                        continue
                    try:
                        payload = json.loads(message)
                    except Exception:
                        continue
                    if payload.get("type") == "set_filters":
                        filters = {
                            "selected_character": payload.get("selected_character"),
                            "selected_set": payload.get("selected_set"),
                            "search_query": payload.get("search_query"),
                        }
                        client["filters"] = filters
            except WebSocketDisconnect:
                logger.debug("WebSocket client disconnected normally.")
            finally:
                with self._ws_clients_lock:
                    if client in self._ws_clients:
                        self._ws_clients.remove(client)

        self.api.include_router(
            create_config_router(self),
            prefix=API_V1_PREFIX,
            tags=["config"],
        )
        self.api.include_router(
            create_characters_router(self),
            prefix=API_V1_PREFIX,
            tags=["characters"],
        )
        self.api.include_router(
            create_picture_sets_router(self),
            prefix=API_V1_PREFIX,
            tags=["picture_sets"],
        )
        self.api.include_router(
            create_projects_router(self),
            prefix=API_V1_PREFIX,
            tags=["projects"],
        )
        self.api.include_router(
            create_tags_router(self),
            prefix=API_V1_PREFIX,
            tags=["tags"],
        )
        self.api.include_router(
            create_stacks_router(self),
            prefix=API_V1_PREFIX,
            tags=["stacks"],
        )
        # tag_predictions must be registered before pictures so that the
        # specific path /pictures/{id}/tag_predictions is not swallowed by
        # the wildcard /pictures/{id}/{field} route in the pictures router.
        self.api.include_router(
            create_tag_predictions_router(self),
            prefix=API_V1_PREFIX,
            tags=["tag_predictions"],
        )
        self.api.include_router(
            create_pictures_router(self),
            prefix=API_V1_PREFIX,
            tags=["pictures"],
        )
        self.api.include_router(
            create_comfyui_router(self),
            prefix=API_V1_PREFIX,
            tags=["comfyui"],
        )
        self.api.include_router(
            create_reference_folders_router(self),
            prefix=API_V1_PREFIX,
            tags=["config"],
        )
        self.api.include_router(
            create_import_folders_router(self),
            prefix=API_V1_PREFIX,
            tags=["config"],
        )
        self.api.include_router(
            create_filesystem_router(self),
            prefix=API_V1_PREFIX,
            tags=["config"],
        )

        @self.api.middleware("http")
        async def auth_middleware(request: Request, call_next):
            return await self.auth.auth_middleware(
                request,
                call_next,
                self.allow_origins,
                self.allow_origin_regex,
            )

        @self.api.get(f"{API_V1_PREFIX}/check-session")
        async def check_session(request: Request):
            return self.auth.check_session(request)

        @self.api.post(f"{API_V1_PREFIX}/login")
        def login(request: LoginRequest):
            response = self.auth.login(request)
            self._user = self.auth.user
            return response

        @self.api.get(f"{API_V1_PREFIX}/login")
        def check_registration():
            return self.auth.check_registration()

        @self.api.post(f"{API_V1_PREFIX}/logout")
        def logout(response: Response, request: Request):
            return self.auth.logout(response, request)

        @self.api.get(f"{API_V1_PREFIX}/protected")
        async def protected():
            return {"message": "You are authenticated!"}

        @self.api.get("/{full_path:path}")
        async def frontend_fallback(full_path: str):
            dist_dir = self._get_frontend_dist_dir()
            if not dist_dir:
                raise HTTPException(status_code=404, detail="Not Found")

            safe_path = os.path.normpath(full_path).lstrip(os.sep)
            candidate = os.path.abspath(os.path.join(dist_dir, safe_path))
            if candidate.startswith(dist_dir) and os.path.isfile(candidate):
                return FileResponse(candidate)

            index_path = self._get_frontend_index_path()
            if not index_path:
                raise HTTPException(status_code=404, detail="Not Found")
            return FileResponse(index_path)
