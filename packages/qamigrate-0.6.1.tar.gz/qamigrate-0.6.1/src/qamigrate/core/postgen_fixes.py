"""
Deterministic post-generation fixups for known Playwright Java migration gaps.

These are rule-based, zero-LLM-cost transformations applied to every generated
file after the Coder runs but before the first compile attempt. They target
patterns the LLM consistently gets wrong regardless of provider or prompt.

v0.5.8:
  - @Listeners({X.class}) → @ExtendWith(X.class) (TestNG → JUnit5)
  - ScreenshotOptions import fix (inner class, not a top-level type)

v0.5.9:
  - @Listeners guard: only apply @ExtendWith when the listener class is
    likely to implement Extension. Otherwise remove the broken annotation
    and emit a compile-safe stub so javac can proceed.
  - Locator.WaitForOptions.setState(Locator.State.*) →
    setState(WaitForSelectorState.*)

v0.5.11:
  - Strip AssertJ imports from non-test files; replace with Playwright assertThat
  - Strip leftover Selenium imports from generated Playwright files
  - Ensure WaitForSelectorState import present when the type is referenced
"""

from __future__ import annotations

import re

import structlog

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Fix 1 — @Listeners → @ExtendWith
# ---------------------------------------------------------------------------
#
# TestNG uses @Listeners({MyListener.class}) on test classes.
# JUnit 5 equivalent: @ExtendWith(MyListener.class) (no array, no braces).
# The Coder copies the TestNG form verbatim, which javac rejects because
# org.testng.annotations.Listeners doesn't exist in the JUnit5 classpath.
#
# The import also changes:
#   import org.testng.annotations.Listeners; → REMOVE
#   ADD import org.junit.jupiter.api.extension.ExtendWith;
#
# We only rewrite the annotation form -- not arbitrary class references.

_LISTENERS_ANNOTATION_RE = re.compile(
    r"@Listeners\s*\(\s*\{([^}]+)\}\s*\)",
    re.MULTILINE,
)

# Remove these TestNG-specific imports; they have no JUnit5 equivalent.
_TESTNG_LISTENER_IMPORTS = re.compile(
    r"^\s*import\s+org\.testng\.annotations\.Listeners\s*;\s*\n?",
    re.MULTILINE,
)

_EXTENDWITH_IMPORT = "import org.junit.jupiter.api.extension.ExtendWith;"


def _fix_listeners_annotation(
    code: str,
    extension_classes: set[str] | None = None,
) -> tuple[str, bool]:
    """Rewrite @Listeners({X.class}) → @ExtendWith(X.class).

    v0.5.9 guard: @ExtendWith requires the listener to implement
    org.junit.jupiter.api.extension.Extension. If the listener implements
    ITestListener (TestNG), applying @ExtendWith blindly causes a type error:
      "Class<TestListener> cannot be converted to Class<? extends Extension>"

    We apply @ExtendWith only when the listener class name is in
    `extension_classes` (a caller-supplied set of class names known to
    implement Extension). When we can't confirm, we remove the @Listeners
    annotation and replace it with a safe no-op comment -- this eliminates
    the "cannot find symbol: @Listeners" error without introducing a new
    type error. The Fixer's LLM can then address the cross-file migration
    in a subsequent pass with full context.

    `extension_classes=None` uses the conservative path (always safe-remove)
    since we can't verify. Callers who have cross-file class info can pass
    the set of confirmed Extension implementors.

    Returns (new_code, changed).
    """
    if "@Listeners" not in code:
        return code, False

    known_extensions = extension_classes or set()
    changed = False
    result = code

    def _replace_listeners(m: re.Match) -> str:
        inner = m.group(1)  # "TestListener.class" or "A.class, B.class"
        classes = [c.strip() for c in inner.split(",") if c.strip()]
        # Extract simple names (strip ".class" suffix).
        names = [cls.replace(".class", "").strip() for cls in classes]

        if known_extensions and all(n in known_extensions for n in names):
            # All listeners confirmed as Extension implementors -- safe to rewrite.
            return "\n".join(f"@ExtendWith({cls})" for cls in classes)

        # Cannot confirm: remove the broken annotation and leave a TODO.
        # This makes javac happy (no unknown symbol) without introducing a
        # type error. The Fixer or a human can address the cross-file migration.
        todo = (
            "// TODO: @Listeners removed -- listener class(es) must implement\n"
            "// org.junit.jupiter.api.extension.Extension before @ExtendWith\n"
            "// can be used. Migrate "
            + ", ".join(names)
            + " to implement BeforeEachCallback/AfterEachCallback."
        )
        return todo

    new_result, count = _LISTENERS_ANNOTATION_RE.subn(_replace_listeners, result)
    if count:
        changed = True
        result = new_result
        # Remove old TestNG import regardless of path taken above.
        result = _TESTNG_LISTENER_IMPORTS.sub("", result)
        # Only add ExtendWith import if we actually emitted @ExtendWith.
        if "@ExtendWith(" in result and _EXTENDWITH_IMPORT not in result:
            result = _insert_import(result, _EXTENDWITH_IMPORT)

    return result, changed


# ---------------------------------------------------------------------------
# Fix 2 — ScreenshotOptions import
# ---------------------------------------------------------------------------
#
# The LLM hallucinates `import com.microsoft.playwright.options.ScreenshotOptions;`
# which does not exist. The correct type is `Page.ScreenshotOptions` (an inner
# class of Page). Fix:
#   1. Remove the non-existent import.
#   2. Replace standalone `ScreenshotOptions` type references with
#      `Page.ScreenshotOptions` so the code compiles.
#   3. Ensure `import com.microsoft.playwright.Page;` is present.
#
# We only fix the specific hallucinated path. Other options.* imports are left
# alone (AriaRole, SelectOption, etc. are legitimately in that package).

_FAKE_SCREENSHOT_IMPORT = re.compile(
    r"^\s*import\s+com\.microsoft\.playwright\.options\.ScreenshotOptions\s*;\s*\n?",
    re.MULTILINE,
)

_PAGE_IMPORT = "import com.microsoft.playwright.Page;"


def _fix_screenshot_options_import(code: str) -> tuple[str, bool]:
    """Remove the non-existent ScreenshotOptions import and fix usages.

    Returns (new_code, changed).
    """
    if "ScreenshotOptions" not in code:
        return code, False

    # Only act if the hallucinated import is present.
    if not _FAKE_SCREENSHOT_IMPORT.search(code):
        return code, False

    result = _FAKE_SCREENSHOT_IMPORT.sub("", code)
    # Replace bare `ScreenshotOptions` with `Page.ScreenshotOptions`.
    # Use word-boundary match to avoid touching `Page.ScreenshotOptions`
    # that a previous run may have already fixed.
    result = re.sub(
        r"(?<!Page\.)\bScreenshotOptions\b",
        "Page.ScreenshotOptions",
        result,
    )
    # Ensure Page is imported.
    if _PAGE_IMPORT not in result:
        result = _insert_import(result, _PAGE_IMPORT)

    # v0.6.1: report `changed` based on actual content diff, not the
    # presence of the trigger pattern. Previously this returned True even
    # when no further mutation was needed, breaking the identity-check
    # optimization in apply_all_postgen_fixes (which uses `is` to skip
    # writes when nothing changed).
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 3 — Locator.WaitForOptions.setState enum type
# ---------------------------------------------------------------------------
#
# The LLM generates:
#   .waitFor(new Locator.WaitForOptions().setState(Locator.State.HIDDEN))
#
# But setState() takes a WaitForSelectorState, not Locator.State. The correct
# Playwright Java API is:
#   import com.microsoft.playwright.options.WaitForSelectorState;
#   .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN))

_LOCATOR_STATE_RE = re.compile(
    r"\bLocator\.State\.([A-Z_]+)\b",
    re.MULTILINE,
)

_WAIT_FOR_SELECTOR_STATE_IMPORT = (
    "import com.microsoft.playwright.options.WaitForSelectorState;"
)


def _fix_locator_state_enum(code: str) -> tuple[str, bool]:
    """Replace Locator.State.X with WaitForSelectorState.X.

    Returns (new_code, changed).
    """
    if "Locator.State." not in code:
        return code, False

    result = _LOCATOR_STATE_RE.sub(r"WaitForSelectorState.\1", code)
    changed = result != code
    if changed and _WAIT_FOR_SELECTOR_STATE_IMPORT not in result:
        result = _insert_import(result, _WAIT_FOR_SELECTOR_STATE_IMPORT)
    return result, changed


# ---------------------------------------------------------------------------
# Fix 4 — AssertJ imports stripped from non-test files
# ---------------------------------------------------------------------------
#
# The LLM sometimes adds `import static org.assertj.core.api.Assertions.assertThat;`
# to utility/page-object files. AssertJ is not injected by `qamigrate init` and
# almost never a project dependency in the source tree. When it appears in
# src/main/java files, Maven fails with "package org.assertj.core.api does not exist".
#
# Fix: remove the static AssertJ import and replace any assertThat(x).isTrue()
# style calls with Playwright's assertThat(locator).isVisible() equivalent.
# Also ensures `import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;`
# is present when Playwright assertThat is used.

_ASSERTJ_STATIC_IMPORT_RE = re.compile(
    r"^\s*import\s+static\s+org\.assertj\.[^;]+;\s*\n?",
    re.MULTILINE,
)
_ASSERTJ_PACKAGE_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.assertj\.[^;]+;\s*\n?",
    re.MULTILINE,
)

# Playwright's assertThat import
_PW_ASSERT_IMPORT = "import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;"

# Common AssertJ boolean wrappers → Playwright equivalents.
# assertThat(locator.isVisible()).isTrue() → assertThat(locator).isVisible()
# assertThat(locator.isVisible()).isFalse() → assertThat(locator).isHidden()
_ASSERTJ_BOOL_PATTERNS = [
    (re.compile(r"assertThat\(([^)]+)\.isVisible\(\)\)\.isTrue\(\)"), r"assertThat(\1).isVisible()"),
    (re.compile(r"assertThat\(([^)]+)\.isVisible\(\)\)\.isFalse\(\)"), r"assertThat(\1).isHidden()"),
    (re.compile(r"assertThat\(([^)]+)\.isHidden\(\)\)\.isTrue\(\)"), r"assertThat(\1).isHidden()"),
    (re.compile(r"assertThat\(([^)]+)\.isEnabled\(\)\)\.isTrue\(\)"), r"assertThat(\1).isEnabled()"),
    (re.compile(r"assertThat\(([^)]+)\.isEnabled\(\)\)\.isFalse\(\)"), r"assertThat(\1).isDisabled()"),
]


def _fix_assertj_imports(code: str) -> tuple[str, bool]:
    """Remove AssertJ imports and rewrite boolean assertions to Playwright form.

    Only fires when org.assertj imports are present. Does not touch test files
    that legitimately use AssertJ for non-Playwright assertions — the fix only
    replaces patterns that have a direct Playwright equivalent.

    Returns (new_code, changed).
    """
    if "org.assertj" not in code:
        return code, False

    result = code
    result = _ASSERTJ_STATIC_IMPORT_RE.sub("", result)
    result = _ASSERTJ_PACKAGE_IMPORT_RE.sub("", result)

    # Rewrite boolean wrapper patterns to Playwright assertThat.
    for pattern, replacement in _ASSERTJ_BOOL_PATTERNS:
        result = pattern.sub(replacement, result)

    # If Playwright assertThat is now used but not imported, add the import.
    if "assertThat(" in result and _PW_ASSERT_IMPORT not in result:
        result = _insert_import(result, _PW_ASSERT_IMPORT)

    return result, result != code


# ---------------------------------------------------------------------------
# Fix 5 — Strip leftover Selenium imports from generated files
# ---------------------------------------------------------------------------
#
# Generated files occasionally retain `import org.openqa.selenium.*` lines that
# were in the original source. These cause "package org.openqa.selenium does not
# exist" if selenium-java is not on the Playwright-only classpath.
#
# We remove the entire org.openqa.selenium.* import block. We also remove
# org.testng.* imports that aren't @Test/@BeforeMethod (those are already handled
# by the TestNG→JUnit5 migration; stragglers get cleaned here).

_SELENIUM_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.openqa\.selenium[^;]*;\s*\n?",
    re.MULTILINE,
)
_TESTNG_IMPORT_RE = re.compile(
    # Remove all TestNG imports. JUnit5 equivalents are added by the Coder.
    r"^\s*import\s+org\.testng(?!\.annotations\.Test\b)[^;]*;\s*\n?",
    re.MULTILINE,
)
# Also remove TestNG Assert static imports (replaced by JUnit5/Playwright assertions).
_TESTNG_ASSERT_IMPORT_RE = re.compile(
    r"^\s*import\s+static\s+org\.testng\.Assert[^;]*;\s*\n?",
    re.MULTILINE,
)


def _simple_name_from_import(import_line: str) -> str | None:
    """Extract the simple class name from a Java import line.

    'import org.testng.ITestListener;' -> 'ITestListener'
    'import static org.testng.Assert.assertEquals;' -> 'assertEquals'
    Returns None when the import ends in '.*' (wildcard).
    """
    # Strip leading whitespace and 'import [static] '
    m = re.search(r"import\s+(?:static\s+)?([\w.]+)\s*;", import_line)
    if not m:
        return None
    fq = m.group(1)
    last = fq.rsplit(".", 1)[-1]
    return None if last == "*" else last


def _import_is_still_used(import_line: str, code: str) -> bool:
    """Return True if the simple class name from `import_line` appears in
    the file body (i.e., the file still references the imported type/method).

    This guards the strip rule: we must NOT remove an import whose class is
    still referenced (e.g. `implements ITestListener` keeps the import).
    """
    name = _simple_name_from_import(import_line)
    if name is None:
        return False  # wildcard -- always safe to remove
    # Remove the import line itself before searching so we don't count the
    # import declaration as a "reference".
    body = code.replace(import_line, "", 1)
    return bool(re.search(rf"\b{re.escape(name)}\b", body))


def _fix_leftover_selenium_imports(
    code: str,
    strip_testng: bool = True,
) -> tuple[str, bool]:
    """Strip residual Selenium (and optionally TestNG) imports from a generated file.

    Args:
        strip_testng: When False (TestNG target framework), skip the TestNG
            import strip entirely. org.testng.* imports are intentional on
            the TestNG path. Selenium imports are still removed regardless.

    v0.5.12 guard: only remove an import if the imported class name is no longer
    referenced anywhere in the file body.

    Returns (new_code, changed).
    """
    result = code
    changed = False

    # Process Selenium imports line-by-line with the guard (always).
    for m in list(_SELENIUM_IMPORT_RE.finditer(code)):
        line = m.group(0)
        if not _import_is_still_used(line, result):
            result = result.replace(line, "", 1)
            changed = True

    if strip_testng:
        # On JUnit5 path: remove orphaned TestNG lifecycle/annotation imports
        # (they were replaced by JUnit5 equivalents by the Coder).
        for m in list(_TESTNG_IMPORT_RE.finditer(code)):
            line = m.group(0)
            if not _import_is_still_used(line, result):
                result = result.replace(line, "", 1)
                changed = True

        # TestNG Assert static imports are always safe to remove on the JUnit5
        # path — those calls are rewritten to JUnit5/Playwright assertions.
        for m in list(_TESTNG_ASSERT_IMPORT_RE.finditer(code)):
            line = m.group(0)
            result = result.replace(line, "", 1)
            changed = True

    return result, changed


# ---------------------------------------------------------------------------
# Fix 6 — Ensure WaitForSelectorState import when type is referenced
# ---------------------------------------------------------------------------
#
# After Fix 3 rewrites Locator.State.X → WaitForSelectorState.X, the import
# is added. But the Fixer may regenerate sections of the file without the import.
# This guard ensures the import is always present when the type appears.


def _ensure_wait_for_selector_state_import(code: str) -> tuple[str, bool]:
    """Add WaitForSelectorState import if the type is used but not imported."""
    if "WaitForSelectorState" not in code:
        return code, False
    if _WAIT_FOR_SELECTOR_STATE_IMPORT in code:
        return code, False
    return _insert_import(code, _WAIT_FOR_SELECTOR_STATE_IMPORT), True


# ---------------------------------------------------------------------------
# Shared helper
# ---------------------------------------------------------------------------


def _insert_import(code: str, import_stmt: str) -> str:
    """Insert `import_stmt` after the last existing import line.

    Falls back to inserting after the package declaration if there are no
    existing imports.
    """
    # Find the last import line.
    last_import = -1
    for m in re.finditer(r"^\s*import\s+[^;]+;\s*$", code, re.MULTILINE):
        last_import = m.end()

    if last_import != -1:
        return code[:last_import] + f"\n{import_stmt}" + code[last_import:]

    # No imports found -- insert after package declaration.
    pkg_match = re.search(r"^\s*package\s+[^;]+;\s*$", code, re.MULTILINE)
    if pkg_match:
        pos = pkg_match.end()
        return code[:pos] + f"\n\n{import_stmt}" + code[pos:]

    # Default: prepend.
    return f"{import_stmt}\n\n{code}"


# ---------------------------------------------------------------------------
# Fix 13 — Missing `{` between method signature and one-line body (v0.6.1)
# ---------------------------------------------------------------------------
#
# The LLM occasionally emits a non-abstract method as a one-liner without
# the opening brace. v0.6.1 production run on AutomationFrameworkSelenium
# had this in BrowserFactory.java:
#
#   private Browser createBrowser(BrowserType browserType) Playwright playwright = ...; return ...;
#
# Java requires:
#
#   private Browser createBrowser(BrowserType browserType) { Playwright playwright = ...; return ...; }
#
# The pattern is: <signature ending in `)`> <whitespace> <statement starting
# with a Java identifier or keyword> ... `;` ... `;` <line end>. Without the
# braces, the second `;` is a syntax error.
#
# Heuristic: if a line matches `<modifiers> <type> <name>(<args>)` followed
# by a non-`{`/`;`/`throws`/newline character, we wrap the rest of the line
# in `{ ... }`. We require the rest to contain a `;` so we don't trip on
# abstract / interface methods (Fix 11 handles those).

_NONABSTRACT_MISSING_BRACE_RE = re.compile(
    # Capture the modifier-laden signature ending at `)`.
    r"^("
    r"(?:\s*(?:public\s+|protected\s+|private\s+|static\s+|final\s+|synchronized\s+|default\s+)+)?"
    r"[\w<>\[\]\.]+\s+\w+\s*\([^)]*\)"
    r")"
    # Skip optional throws clause.
    r"(\s*(?:throws\s+[\w,\s\.]+?)?)"
    # Required: at least one space, then content that DOES NOT start with
    # `{`, `;`, or end-of-line. Must contain at least one `;` somewhere
    # before end-of-line so we don't trigger on abstract declarations.
    r"\s+([^{;\n][^\n]*;[^\n]*)$",
    re.MULTILINE,
)


def _fix_nonabstract_method_missing_brace(code: str) -> tuple[str, bool]:
    """Wrap an inline method body in `{ ... }` when the LLM omitted the braces.

    Targets:
      `<sig>) Playwright p = ...; return ...;`
    Produces:
      `<sig>) { Playwright p = ...; return ...; }`
    """
    if "(" not in code or ";" not in code:
        return code, False

    def _repl(m: re.Match) -> str:
        sig = m.group(1)
        throws = (m.group(2) or "").strip()
        body = m.group(3)
        # Don't touch lines that look like field/variable declarations.
        # The signature must contain `(` followed by `)` — we already
        # required that, but double-check that body has executable content.
        if "=" not in body and "return" not in body:
            return m.group(0)
        prefix = f"{sig}{(' ' + throws) if throws else ''}"
        return f"{prefix} {{ {body} }}"

    result = _NONABSTRACT_MISSING_BRACE_RE.sub(_repl, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 12 — Doubled method signature (v0.5.18 / v0.5.19)
# ---------------------------------------------------------------------------
#
# The LLM occasionally emits a method header twice in a row before the body:
#
#   synchronized public static void addAuthors(String[] authors)
#   synchronized public static void addAuthors(String[] authors) {
#       ...
#   }
#
# Production project's ExtentReportManager.java had 6 errors, all this shape.
# Java compiler rejects with "class, interface, enum, or record expected" /
# "<identifier> expected".
#
# The fix is structural and deterministic: when two byte-identical headers
# appear back-to-back (separated only by whitespace) and the second is
# followed by `{`, drop the first. We require exact textual match so we never
# collapse a real overload — overloads differ in their parameter list.

# Match a method header: at least one modifier (or annotation) + return type
# + name + (args). Requiring a modifier prevents the regex from matching
# random `funcCall(arg)` patterns inside method bodies.
#
# Modifiers accepted (any order, repeated): public/protected/private/static/
# final/abstract/synchronized/default/native/strictfp, plus @Override-style
# annotations.
_METHOD_HEADER_RE = (
    r"((?:(?:@\w+(?:\([^)]*\))?\s+)|"
    r"(?:public|protected|private|static|final|abstract|synchronized|default|native|strictfp)\s+)+"
    r"[\w.]+(?:<[^<>]*>)?(?:\[\])?"
    r"\s+\w+\s*\([^)]*\))"
)
_DOUBLED_METHOD_HEADER_RE = re.compile(
    rf"{_METHOD_HEADER_RE}\s+\1\s*(\{{)",
    re.MULTILINE,
)


def _fix_doubled_method_header(code: str) -> tuple[str, bool]:
    """Collapse `<header>  <header> {` into `<header> {` when both are identical.

    Requires textual identity, so legitimate overloads (different param lists)
    are never affected.
    """
    # Cheap early-out: we need at least one '(' and one '{'.
    if "(" not in code or "{" not in code:
        return code, False

    def _repl(m: re.Match) -> str:
        header = m.group(1)
        brace = m.group(2)
        return f"{header} {brace}"

    result = _DOUBLED_METHOD_HEADER_RE.sub(_repl, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 11 — Missing semicolon on abstract method declarations (v0.5.17)
# ---------------------------------------------------------------------------
#
# The LLM frequently emits abstract method declarations without the trailing
# semicolon, especially when followed by a trailing comment:
#   public abstract Foo bar(Baz baz)  // comment
# Java requires:
#   public abstract Foo bar(Baz baz);  // comment
#
# This pattern showed up in the production project's BrowserFactory.java
# (3 errors, all the same shape). Deterministic regex fix.

_ABSTRACT_METHOD_NO_SEMI_RE = re.compile(
    # Match: optional modifiers, "abstract", return type, name, args ),
    # then optional comment without a semicolon before line end.
    r"^(\s*(?:public\s+|protected\s+|private\s+)?abstract\s+[\w<>\[\]\.]+\s+\w+\s*\([^)]*\))(\s*(?://[^\n]*)?)$",
    re.MULTILINE,
)


def _fix_abstract_method_missing_semicolon(code: str) -> tuple[str, bool]:
    """Add `;` to abstract method declarations missing the terminator."""
    if "abstract" not in code:
        return code, False

    def _repl(m: re.Match) -> str:
        sig = m.group(1)
        trailing = m.group(2) or ""
        # Already has a semicolon somewhere in the trailing section? skip.
        if ";" in (sig + trailing):
            return m.group(0)
        return f"{sig};{trailing}"

    result = _ABSTRACT_METHOD_NO_SEMI_RE.sub(_repl, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 10 — TakesScreenshot import strip (v0.5.16)
# ---------------------------------------------------------------------------
#
# Selenium's TakesScreenshot is replaced by page.screenshot() in Playwright.
# When AllureManager/ExtentReportManager use the cast pattern
# `((TakesScreenshot) driver).getScreenshotAs(BYTES)`, the LLM usually rewrites
# the body but may leave the `import org.openqa.selenium.TakesScreenshot;` line
# behind. Strip it deterministically when the type is no longer used in body.

_TAKES_SCREENSHOT_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.openqa\.selenium\.TakesScreenshot\s*;\s*\n?",
    re.MULTILINE,
)
_TAKES_SCREENSHOT_USAGE_RE = re.compile(r"\bTakesScreenshot\b")


def _fix_takes_screenshot_orphan(code: str) -> tuple[str, bool]:
    """Strip TakesScreenshot import when no longer used in body."""
    if "TakesScreenshot" not in code:
        return code, False
    # Strip the import temporarily and check if name still appears.
    without_import = _TAKES_SCREENSHOT_IMPORT_RE.sub("", code)
    if _TAKES_SCREENSHOT_USAGE_RE.search(without_import):
        return code, False  # Still used — leave alone
    return without_import, without_import != code


# ---------------------------------------------------------------------------
# Fix 8 — Strip N/A prose lines injected by the LLM (v0.5.16)
# ---------------------------------------------------------------------------
#
# The LLM sometimes inserts pseudo-documentation lines like:
#   N/A - Utility class with static methods only
#   N/A - No constructor needed; all methods are static
# These are NOT valid Java and cause an immediate compile error.
# This is the highest-frequency bug seen in the production project run
# (5+ files affected). A simple regex strip costs zero and eliminates the
# entire class of error.

_NA_PROSE_RE = re.compile(
    r"^\s*N/?A\s*[-–—:]\s*[^\n]*\n?",
    re.MULTILINE | re.IGNORECASE,
)


def _fix_na_prose_injection(code: str) -> tuple[str, bool]:
    """Strip N/A prose lines that the LLM injects into Java source."""
    if not re.search(r"^\s*N/?A\s*[-–—:]", code, re.MULTILINE | re.IGNORECASE):
        return code, False
    result = _NA_PROSE_RE.sub("", code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 9 — No-arg enum constant separator (v0.5.16)
# ---------------------------------------------------------------------------
#
# The existing _fix_listeners_annotation handles many enum cases but the
# comma separator postgen rule in the existing code only fires when enum
# constants have constructor arguments. No-arg enums like:
#   STOP_ON_FAILURE;
#   CONTINUE_ON_FAILURE;
# need to become:
#   STOP_ON_FAILURE,
#   CONTINUE_ON_FAILURE;   ← last one stays semicolon if methods follow
#
# This fix is conservative: only fire inside a clearly identified enum body
# (between `{` and `}`) for lines that look like UPPER_CASE_IDENTIFIER;
# with no other tokens on the line.

_ENUM_BODY_RE = re.compile(
    r"(public\s+|private\s+|protected\s+)?enum\s+\w+[^{]*\{([^}]*)\}",
    re.DOTALL,
)
_NO_ARG_CONST_RE = re.compile(
    r"^\s*([A-Z][A-Z0-9_]*);\s*$",
    re.MULTILINE,
)


def _fix_enum_separator(code: str) -> tuple[str, bool]:
    """Fix no-arg enum constants that have `;` instead of `,` as separator.

    Only rewrites inside enum body. The last constant before any method/field
    declarations keeps its `;` if followed by method/field content; otherwise
    all but the trailing semicolon become commas.
    """
    if "enum " not in code:
        return code, False

    def _fix_body(m: re.Match) -> str:
        full = m.group(0)
        body = m.group(2)
        # Find all no-arg constants
        consts = list(_NO_ARG_CONST_RE.finditer(body))
        if not consts:
            return full
        # Replace all but the last with comma
        new_body = body
        for i, cm in enumerate(consts[:-1]):
            old = cm.group(0).rstrip()
            new = old.rstrip(";") + ","
            new_body = new_body.replace(old, new, 1)
        return full.replace(body, new_body, 1)

    result = _ENUM_BODY_RE.sub(_fix_body, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 7 — Strip spurious .playwright suffix from Cucumber imports (v0.5.15)
# ---------------------------------------------------------------------------
#
# The sibling import rewrite (pipeline Phase 1.5) rewrites project class
# imports to .playwright. But Cucumber imports (io.cucumber.*) are third-party
# and must NEVER have .playwright appended. If the LLM or import rewriter
# accidentally produces `import io.cucumber.java.playwright.en.Given`, this
# rule strips the spurious suffix.

_CUCUMBER_IMPORT_BAD_RE = re.compile(
    r"^\s*import\s+(io\.cucumber[^;]*?)\.playwright([^;]*;)\s*$",
    re.MULTILINE,
)


def _fix_cucumber_import_corruption(code: str) -> tuple[str, bool]:
    """Remove any .playwright suffix that crept into Cucumber imports."""
    if "io.cucumber" not in code or ".playwright" not in code:
        return code, False
    result = _CUCUMBER_IMPORT_BAD_RE.sub(r"import \1\2", code)
    return result, result != code


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def apply_all_postgen_fixes(
    code: str,
    file_path: str = "",
    extension_classes: set[str] | None = None,
    target_framework: str = "junit5",
) -> str:
    """Apply all deterministic post-generation fixes to `code`.

    Args:
        code: Java source to fix.
        file_path: Used for logging only.
        extension_classes: Optional set of class names confirmed to implement
            org.junit.jupiter.api.extension.Extension. When provided, the
            @Listeners→@ExtendWith rewrite is applied for those classes only;
            others get a safe TODO comment. When None (default), the rewrite
            is always replaced with a TODO (conservative safe path).
            Ignored when target_framework == "testng".
        target_framework: The test framework the generated code targets.
            "testng"  — generated code uses TestNG; @Listeners must NOT be
                        rewritten, org.testng imports must NOT be stripped.
            "junit5"  — generated code uses JUnit5 (default behaviour).
            "junit4"  — generated code uses JUnit4; same as junit5 for postgen.

    Returns the fixed source. If nothing changed, returns the original object
    unchanged (identity comparison safe).
    """
    is_testng = target_framework == "testng"
    result = code
    any_changed = False

    # @Listeners rewrite: JUnit5 only.
    # On TestNG, @Listeners({X.class}) is a valid TestNG annotation and MUST
    # be preserved. Rewriting it would break the TestNG listener mechanism.
    if not is_testng:
        result, changed = _fix_listeners_annotation(result, extension_classes)
        if changed:
            logger.info("postgen_fixes: rewrote @Listeners annotation", file=file_path)
            any_changed = True

    # These fixes are framework-neutral — apply on all paths.
    result, changed = _fix_screenshot_options_import(result)
    if changed:
        logger.info("postgen_fixes: fixed ScreenshotOptions import", file=file_path)
        any_changed = True

    result, changed = _fix_locator_state_enum(result)
    if changed:
        logger.info("postgen_fixes: fixed Locator.State -> WaitForSelectorState", file=file_path)
        any_changed = True

    result, changed = _ensure_wait_for_selector_state_import(result)
    if changed:
        logger.info("postgen_fixes: added missing WaitForSelectorState import", file=file_path)
        any_changed = True

    result, changed = _fix_assertj_imports(result)
    if changed:
        logger.info("postgen_fixes: removed AssertJ imports, rewrote assertions", file=file_path)
        any_changed = True

    # Selenium import strip: on TestNG, org.testng imports are intentional
    # (TestNG API is the target framework).  Only strip Selenium imports;
    # the TestNG-import strip blocks inside _fix_leftover_selenium_imports
    # are already individually guarded by _import_is_still_used, but we
    # pass a flag so the function can skip the TestNG strip pass entirely
    # when target is TestNG for a cleaner separation of concerns.
    result, changed = _fix_leftover_selenium_imports(result, strip_testng=not is_testng)
    if changed:
        logger.info("postgen_fixes: stripped leftover Selenium/TestNG imports", file=file_path)
        any_changed = True

    # v0.5.15: fix Cucumber imports that got .playwright suffix from import rewriter
    result, changed = _fix_cucumber_import_corruption(result)
    if changed:
        logger.info("postgen_fixes: removed spurious .playwright from Cucumber imports", file=file_path)
        any_changed = True

    # v0.5.16: strip N/A prose lines the LLM inserts into Java source
    result, changed = _fix_na_prose_injection(result)
    if changed:
        logger.info("postgen_fixes: stripped N/A prose injection", file=file_path)
        any_changed = True

    # v0.5.16: fix no-arg enum constant separators (STOP_ON_FAILURE; -> ,)
    result, changed = _fix_enum_separator(result)
    if changed:
        logger.info("postgen_fixes: fixed no-arg enum separators", file=file_path)
        any_changed = True

    # v0.5.16: strip orphaned TakesScreenshot import after migration
    result, changed = _fix_takes_screenshot_orphan(result)
    if changed:
        logger.info("postgen_fixes: stripped orphan TakesScreenshot import", file=file_path)
        any_changed = True

    # v0.5.17: add missing ; on abstract method declarations
    result, changed = _fix_abstract_method_missing_semicolon(result)
    if changed:
        logger.info("postgen_fixes: added missing ; on abstract methods", file=file_path)
        any_changed = True

    # v0.5.19: collapse doubled method headers
    result, changed = _fix_doubled_method_header(result)
    if changed:
        logger.info("postgen_fixes: collapsed doubled method headers", file=file_path)
        any_changed = True

    # v0.6.1: wrap inline method bodies that are missing `{ ... }`.
    # Must run AFTER Fix 11 (abstract semicolon), since the Fix 13
    # heuristic requires at least one `;` in the body — we don't want
    # to corrupt abstract declarations.
    result, changed = _fix_nonabstract_method_missing_brace(result)
    if changed:
        logger.info("postgen_fixes: wrapped inline method body in braces", file=file_path)
        any_changed = True

    return result if any_changed else code
