"""
Fixer Agent.

Applies targeted fixes to generated Playwright Java code when compilation
fails. Two strategies:

1. Rule-based fixes for well-known errors (missing imports, void assignments).
   These are fast, deterministic, and safe.

2. LLM-based fix that returns the whole file via Anthropic tool use. We force
   structured output so the model cannot inject prose into the source. The
   fix is only accepted if it is syntactically valid Java.

The caller (pipeline) is responsible for rejecting the fix if compilation
errors go up after applying it.
"""

import re
from pathlib import Path
from typing import Any

import structlog

from qamigrate.agents.compiler import CompilerError, ErrorType
from qamigrate.core.config import FixerConfig
from qamigrate.core.parser import get_parser
from qamigrate.llm.base import LLMProvider, ToolSchema
from qamigrate.llm.errors import LLMError
from qamigrate.llm.sanitize import escape_for_code_fence

logger = structlog.get_logger(__name__)


# Common Playwright imports for auto-fixing missing-symbol errors
PLAYWRIGHT_IMPORTS: dict[str, str] = {
    "Page": "com.microsoft.playwright.Page",
    "Locator": "com.microsoft.playwright.Locator",
    "Browser": "com.microsoft.playwright.Browser",
    "BrowserContext": "com.microsoft.playwright.BrowserContext",
    "BrowserType": "com.microsoft.playwright.BrowserType",
    "Playwright": "com.microsoft.playwright.Playwright",
    "PlaywrightAssertions": "com.microsoft.playwright.assertions.PlaywrightAssertions",
    "AriaRole": "com.microsoft.playwright.options.AriaRole",
    "SelectOption": "com.microsoft.playwright.options.SelectOption",
    "FileChooser": "com.microsoft.playwright.FileChooser",
    "Dialog": "com.microsoft.playwright.Dialog",
    "Download": "com.microsoft.playwright.Download",
    "Frame": "com.microsoft.playwright.Frame",
    "ElementHandle": "com.microsoft.playwright.ElementHandle",
    "JSHandle": "com.microsoft.playwright.JSHandle",
    "Route": "com.microsoft.playwright.Route",
    "Request": "com.microsoft.playwright.Request",
    "Response": "com.microsoft.playwright.Response",
    "TimeoutError": "com.microsoft.playwright.TimeoutError",
    "PlaywrightException": "com.microsoft.playwright.PlaywrightException",
    "WaitForSelectorState": "com.microsoft.playwright.options.WaitForSelectorState",
    "LoadState": "com.microsoft.playwright.options.LoadState",
    "MouseButton": "com.microsoft.playwright.options.MouseButton",
    "KeyboardModifier": "com.microsoft.playwright.options.KeyboardModifier",
    "ScreenshotType": "com.microsoft.playwright.options.ScreenshotType",
    "ColorScheme": "com.microsoft.playwright.options.ColorScheme",
    "ViewportSize": "com.microsoft.playwright.options.ViewportSize",
}


FIXER_SYSTEM_PROMPT = """You are a Java compiler-error fixer.

You will be shown ONE Java source file that has compilation errors, plus the
exact error list from javac. Return the ENTIRE corrected Java file via the
`emit_fixed_java` tool.

## Output format -- strict

The `source` field of your tool call must contain ONLY valid Java source code.
Specifically:

- No markdown fences (no ``` of any kind).
- No "Here is the corrected code:" or any other prose outside Java comments.
- No diff markers, no "..." placeholders, no "TODO" stubs.
- The file must parse as Java on the first try. If you are not confident the
  output will parse, return the ORIGINAL source unchanged -- it is always
  better to make no change than to emit code that will be rejected.

## Hard rules

1. Return the complete file, never a patch or diff.
2. Do not invent methods, fields, or classes that were not in the original.
3. Preserve all business logic, comments, and JavaDoc from the original.
4. Only change what is necessary to fix the reported errors.
5. Every import must be a real package path; prefer `com.microsoft.playwright.*`
   and `org.junit.jupiter.api.*`.
6. Every method body must be syntactically complete: matched braces, every
   statement terminated with a semicolon.
7. Output must parse as Java. The caller will reject your output silently if it
   doesn't, wasting a call -- don't let that happen.

## Common corrections

- "cannot find symbol Locator/Page/Browser/..." -> add the appropriate
  `import com.microsoft.playwright.X;` statement.
- "cannot find symbol" for a method on a `Locator` -> use the correct
  Playwright API (fill, click, textContent, getAttribute, inputValue,
  selectOption, isVisible, isEnabled, hover, press, check, uncheck).
- "void type not allowed here" -> Playwright action methods return void, so
  `String x = locator.click();` is wrong; write `locator.click();` on its own.
- "cannot find symbol method `foo()` on class Bar" -> that method doesn't
  exist; remove the call or replace it with a Playwright API on the underlying
  Page/Locator. Do NOT invent a method on Bar.
- Duplicate method / field declaration -> remove the duplicate, keep the first.
- Orphan code outside a class -> remove it or move it inside.
- Java enum bodies use `,` between constants, not `;`. Only the last constant
  is followed by `;` (or by nothing if no methods follow).
  Example: `enum E { A("a"), B("b"); }` -- commas between, semicolon only
  if a method/field follows.

## Playwright migration — common false fixes to AVOID

These substitutions look plausible but are WRONG for Playwright-migrated code:

- `DriverManager.getPage()` should NOT be changed to `DriverManager.getDriver()`.
  `getPage()` returns `Page`. `getDriver()` returns `WebDriver` -- a completely
  different type. If `getPage()` is missing, the import path is wrong: fix the
  import to `com.qastarter.*.playwright.DriverManager` (add `.playwright` to the
  package), do NOT change the method name.
- Do NOT rename any method whose return type is `Page` to return `WebDriver` or
  vice-versa. They are different types with incompatible APIs.
- When a sibling project class cannot be found (any class that was originally in
  `com.qastarter.*`), the fix is almost always to correct the import to use the
  `.playwright` sub-package: `com.qastarter.X` → `com.qastarter.X.playwright`.
  Do NOT change method names to work around a missing import.

## When in doubt

If you cannot figure out how to fix an error without guessing, leave the file
unchanged. The pipeline will move on and report the file as partially
migrated, which is strictly better than corrupting working code.
"""


PLAYWRIGHT_FIX_TOOL = {
    "name": "emit_fixed_java",
    "description": "Return the complete corrected Java source file.",
    "input_schema": {
        "type": "object",
        "required": ["source"],
        "properties": {
            "source": {
                "type": "string",
                "description": "The complete, corrected Java source code for the file.",
            },
            "notes": {
                "type": "string",
                "description": "Brief explanation of the changes made.",
            },
        },
    },
}


class FixerAgent:
    """Applies rule-based and LLM-based fixes to generated Java code."""

    def __init__(
        self,
        config: FixerConfig | None = None,
        *,
        llm_provider: LLMProvider | None = None,
    ) -> None:
        """
        Args:
            config: FixerConfig with model / retry settings.
            llm_provider: Optional pre-built LLMProvider. If None, builds
                an AnthropicProvider using `config.model` (back-compat path).
        """
        self.config = config or FixerConfig()
        self.model = self.config.model
        self.use_rule_based_first = self.config.use_rule_based_first
        self.parser = get_parser()

        if llm_provider is None:
            from qamigrate.llm.providers.anthropic import AnthropicProvider
            llm_provider = AnthropicProvider(model=self.model)
        self.provider: LLMProvider = llm_provider

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fix_file(
        self,
        file_path: Path,
        code: str,
        all_errors: list[CompilerError],
        retry_count: int = 0,
    ) -> tuple[str, list[str]]:
        """
        Fix one file using only errors that belong to it.

        In project-level compilation, the Compiler returns a flat list of
        errors for many files at once. This helper filters to just the ones
        whose `file_path` points at `file_path`, so the LLM isn't confused
        by errors from sibling files it can't see.
        """
        target = str(file_path.resolve()) if file_path.exists() else str(file_path)
        file_errors: list[CompilerError] = []
        for err in all_errors:
            # Paths in CompilerError come straight from javac stderr, so
            # comparison has to tolerate absolute vs. relative and Windows
            # backslash vs. forward slash. Match on the basename + parent
            # dir as a last resort.
            if err.file_path == target:
                file_errors.append(err)
                continue
            try:
                if Path(err.file_path).resolve() == Path(target):
                    file_errors.append(err)
                    continue
            except (OSError, ValueError):
                pass
            if file_path.name and Path(err.file_path).name == file_path.name:
                file_errors.append(err)

        if not file_errors:
            # No errors for this file -- nothing to fix.
            return code, []

        return self.fix(code=code, errors=file_errors, retry_count=retry_count)

    def fix(
        self,
        code: str,
        errors: list[CompilerError],
        retry_count: int = 0,
    ) -> tuple[str, list[str]]:
        """
        Apply fixes for compilation errors.

        Returns:
            Tuple of (possibly-fixed-code, list-of-change-descriptions).
            If all strategies fail, returns the ORIGINAL code unchanged and
            an empty change list -- we never return worse code than we got.
        """
        logger.info(
            "Fixer: attempting to fix code",
            error_count=len(errors),
            retry_count=retry_count,
        )

        changes: list[str] = []
        working_code = code

        # 1) Rule-based fixes first. These are safe: only syntactic
        #    transformations that can't invent new code.
        if self.use_rule_based_first:
            sorted_errors = sorted(errors, key=lambda e: e.line_number, reverse=True)
            for error in sorted_errors:
                new_code, change = self._apply_rule_based_fix(working_code, error)
                if change:
                    working_code = new_code
                    changes.append(change)

        # If rule-based fixes already changed something, return early so the
        # caller can recompile. No sense bothering the LLM if we might have
        # already resolved everything.
        if changes:
            logger.info("Fixer: applied rule-based fixes", count=len(changes))
            return working_code, changes

        # 2) LLM whole-file rewrite with structured output + validation.
        fixed_code, llm_change = self._apply_llm_whole_file_fix(working_code, errors)
        if fixed_code is not None:
            return fixed_code, [llm_change] if llm_change else []

        # Nothing worked. Return the ORIGINAL code so the caller doesn't
        # regress. The pipeline will stop retrying when errors don't decrease.
        logger.warning("Fixer: no fix produced; keeping original code")
        return code, []

    # ------------------------------------------------------------------
    # Rule-based fixes (safe, narrow)
    # ------------------------------------------------------------------

    def _apply_rule_based_fix(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        if error.error_type in (ErrorType.MISSING_IMPORT, ErrorType.MISSING_CLASS):
            return self._fix_missing_import(code, error)
        if error.error_type == ErrorType.TYPE_MISMATCH:
            return self._fix_type_mismatch(code, error)
        if error.error_type == ErrorType.SYNTAX:
            return self._fix_syntax_error(code, error)
        return code, None

    def _fix_missing_import(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        match = re.search(r"symbol.*(?:class|variable)\s+(\w+)", error.message)
        if not match:
            match = re.search(r"package\s+(\S+)\s+does not exist", error.message)
            if match:
                package = match.group(1)
                import_stmt = f"import {package}.*;"
                if import_stmt in code:
                    return code, None
                return self._insert_import(code, import_stmt)
            return code, None

        class_name = match.group(1)
        if class_name not in PLAYWRIGHT_IMPORTS:
            return code, None

        import_stmt = f"import {PLAYWRIGHT_IMPORTS[class_name]};"
        if import_stmt in code:
            return code, None
        return self._insert_import(code, import_stmt)

    def _insert_import(self, code: str, import_stmt: str) -> tuple[str, str | None]:
        lines = code.split("\n")
        insert_index = 0
        for i, line in enumerate(lines):
            if line.startswith("package "):
                insert_index = i + 1
            elif line.startswith("import "):
                insert_index = i + 1
        lines.insert(insert_index, import_stmt)
        return "\n".join(lines), f"Added import: {import_stmt}"

    def _fix_type_mismatch(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        lines = code.split("\n")
        if error.line_number <= 0 or error.line_number > len(lines):
            return code, None

        line_idx = error.line_number - 1
        line = lines[line_idx]

        # Common: `WebElement x = locator.click();` -- click() is void.
        for void_method in ("click", "fill", "press", "check", "uncheck", "hover"):
            pattern = rf"(\s*).*=\s*(.*\.{void_method}\([^)]*\).*)$"
            match = re.match(pattern, line)
            if match:
                indent = match.group(1)
                call = match.group(2)
                lines[line_idx] = f"{indent}{call}"
                return "\n".join(lines), (
                    f"Removed void assignment at line {error.line_number} "
                    f"({void_method}() returns void)"
                )
        return code, None

    def _fix_syntax_error(
        self,
        code: str,
        error: CompilerError,
    ) -> tuple[str, str | None]:
        lines = code.split("\n")
        if error.line_number <= 0 or error.line_number > len(lines):
            return code, None

        line_idx = error.line_number - 1
        line = lines[line_idx]

        if "';' expected" in error.message:
            stripped = line.rstrip()
            if not stripped.endswith((";", "{", "}")):
                lines[line_idx] = stripped + ";"
                return "\n".join(lines), f"Added missing semicolon at line {error.line_number}"
        return code, None

    # ------------------------------------------------------------------
    # LLM whole-file fix with validation
    # ------------------------------------------------------------------

    def _apply_llm_whole_file_fix(
        self,
        code: str,
        errors: list[CompilerError],
    ) -> tuple[str | None, str | None]:
        """
        Ask the LLM to rewrite the whole file. Validate the output parses as
        Java before accepting.

        Returns:
            (fixed_code, change_description) on success,
            (None, None) if the LLM output was invalid or the call failed.
        """
        if not errors:
            return None, None

        error_listing = "\n".join(
            f"- Line {e.line_number}, col {e.column} [{e.error_type.value}]: {e.message}"
            for e in errors[:20]  # cap to keep prompt bounded
        )

        # Escape any stray triple-backticks in the user's source so they
        # can't break out of the code fence below.
        safe_code = escape_for_code_fence(code)

        prompt = f"""Fix the compilation errors in this Playwright Java file.

## Errors from javac
{error_listing}

## Current source
```java
{safe_code}
```

Return the complete corrected file via the `emit_fixed_java` tool. The source
must be valid Java that parses cleanly; do NOT include markdown fences,
explanations, or prose inside the source string."""

        tool = ToolSchema(
            name=PLAYWRIGHT_FIX_TOOL["name"],
            description=PLAYWRIGHT_FIX_TOOL["description"],
            input_schema=PLAYWRIGHT_FIX_TOOL["input_schema"],
        )

        try:
            response = self.provider.generate_structured(
                system=FIXER_SYSTEM_PROMPT,
                user=prompt,
                tool=tool,
                max_tokens=8192,
                temperature=0.0,
            )
        except LLMError as e:
            logger.error("Fixer: LLM call failed", error=str(e))
            return None, None
        except Exception as e:  # pragma: no cover
            logger.error("Fixer: LLM call failed (unexpected)", error=str(e))
            return None, None

        fixed = response.data.get("source")

        if not fixed or not fixed.strip():
            logger.warning("Fixer: LLM returned no source")
            return None, None

        fixed = self._strip_any_stray_markdown(fixed)

        # VALIDATION: tree-sitter must parse this cleanly. If the LLM snuck
        # prose in, or returned something that isn't Java, reject it.
        if not self._is_valid_java(fixed):
            logger.warning("Fixer: LLM output did not parse as Java; rejecting")
            return None, None

        # Sanity check: output should be the same order-of-magnitude as input.
        # If the model returned 3 lines for a 200-line file, something is off.
        orig_lines = code.count("\n")
        new_lines = fixed.count("\n")
        if new_lines < max(10, orig_lines // 4):
            logger.warning(
                "Fixer: LLM output too short; rejecting",
                orig_lines=orig_lines,
                new_lines=new_lines,
            )
            return None, None

        return fixed, "LLM whole-file rewrite applied"

    @staticmethod
    def _strip_any_stray_markdown(text: str) -> str:
        """Defensive: if the model wrapped the code in ```java ... ``` anyway."""
        text = text.strip()
        if text.startswith("```"):
            # remove opening fence line
            text = text.split("\n", 1)[1] if "\n" in text else ""
            # remove trailing fence
            if text.rstrip().endswith("```"):
                text = text.rstrip()[:-3].rstrip()
        return text

    def _is_valid_java(self, source: str) -> bool:
        """
        Check that the source parses cleanly as Java.

        We use the raw tree-sitter tree here (not the ASTNode wrapper)
        because `has_error` is only exposed on the native Node. Tree-sitter
        is lenient: it still returns a tree for broken input, but it marks
        error spans with `ERROR` nodes, missing tokens, or `has_error=True`
        on the root.
        """
        if not source or not source.strip():
            return False
        try:
            src_bytes = source.encode("utf-8")
            tree = self.parser.parser.parse(src_bytes)
        except Exception:
            return False

        root = tree.root_node
        if root.has_error:
            return False

        # Defensive extra pass: a true Java file should have at least one
        # class_declaration at top level. Prose-polluted output usually
        # ends up as `local_variable_declaration` / `labeled_statement`
        # nodes at the top, not a class.
        top_types = {c.type for c in root.children}
        if "class_declaration" not in top_types and "interface_declaration" not in top_types:
            return False

        return True

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def suggest_fixes(
        self,
        errors: list[CompilerError],
    ) -> list[dict[str, Any]]:
        """Return fix suggestions for an error list, without applying them."""
        suggestions: list[dict[str, Any]] = []
        for error in errors:
            suggestion: dict[str, Any] = {
                "error": error.to_dict(),
                "suggestion": None,
                "confidence": "low",
            }
            if error.error_type == ErrorType.MISSING_IMPORT:
                match = re.search(r"class (\w+)", error.message)
                if match and match.group(1) in PLAYWRIGHT_IMPORTS:
                    suggestion["suggestion"] = f"Add import: {PLAYWRIGHT_IMPORTS[match.group(1)]}"
                    suggestion["confidence"] = "high"
            elif error.error_type == ErrorType.TYPE_MISMATCH:
                suggestion["suggestion"] = (
                    "Playwright action methods (click, fill, press, hover) return void; "
                    "remove any variable assignment from the left side."
                )
                suggestion["confidence"] = "medium"
            elif error.error_type == ErrorType.SYNTAX:
                suggestion["suggestion"] = "Check for missing semicolons or brackets"
                suggestion["confidence"] = "medium"
            suggestions.append(suggestion)
        return suggestions
