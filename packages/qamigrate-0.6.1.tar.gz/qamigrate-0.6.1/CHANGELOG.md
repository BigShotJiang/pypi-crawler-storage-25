# Changelog

All notable changes to QAMigrate are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.6.1] - 2026-04-26

**Theme: Production hardening pass — 8 P0 + 6 P1 fixes from a 7-track
codebase audit.**

Driven by a comprehensive code review across Coder/Fixer prompts, postgen
fixes, ProjectMap data layer, LLM provider/retry, CLI/config, tests, and
docs. Closes structural gaps surfaced by the v0.6.0 production run on
`AutomationFrameworkSelenium` and prevents whole classes of silent
failures.

### Fixed (P0 — correctness)

- **Varargs (`String... args`) silently dropped by parser**
  (`core/parser.py`). Tree-sitter emits `spread_parameter` for varargs,
  not `formal_parameter`; the parser only read the latter, so methods
  with varargs signatures appeared to take fewer arguments than they do.
  Now captured and normalized to `Type[]` storage with a `varargs=True`
  flag; `MethodInfo.signature` renders as `Type... name`.

- **`throws` clauses never extracted** (`core/parser.py`,
  `intelligence/project_map.py`). The Coder had no way to know a method
  required exception handling; generated code could miss `try`/`catch` or
  declare wrong propagation. New `MethodInfo.throws` field surfaces the
  exception list in the prompt.

- **Static initializer blocks (`static {}`) ignored** (`core/parser.py`).
  Constants classes that populate fields in static blocks lost their
  initialization in the migrated output. Now captured as a synthetic
  method named `<clinit>`.

- **Two divergent Coder prompt paths** (`agents/coder.py`). The dead
  `generate()` / `_build_prompt()` UTOM path lacked v0.6.0's API
  preservation requirement. If anything routed through it, overloads
  would silently drop. Removed entirely; only `generate_from_class_info`
  remains.

- **`validate_generated_code()` was never called** (`agents/coder.py`).
  The structural sanity checks (duplicate methods, brace balance,
  multiple constructors) existed as dead code. Wired into
  `assemble_file()` so issues are logged before the file is written.

- **Postgen Fix 2 (ScreenshotOptions) reported `changed=True`
  unconditionally** (`core/postgen_fixes.py`). Broke the identity-check
  optimization in `apply_all_postgen_fixes` (which uses `is` to skip
  writes). Now reports `changed` based on actual content diff.

- **YAML config silently accepted unknown fields** (`core/config.py`).
  A typo like `compiler.javaversion` (instead of `java_version`) was
  ignored, so the user's intended setting never took effect. Every
  nested config model now has `extra='forbid'` via a shared
  `_StrictBase`, surfacing typos at load time.

- **Provider name validated only at first LLM call** (`core/config.py`).
  A typo like `provider: "anthropi"` failed 20 minutes into the run with
  a cryptic error. New `@field_validator("provider")` on `CoderConfig`
  and `FixerConfig` cross-checks against `qamigrate.llm.registry` at
  load time and lists known providers in the error message.

### Fixed (P1 — robustness)

- **Constructor count check used brittle string matching**
  (`agents/coder.py:830`). `code.constructor.count("public " + last_word)`
  broke on `class Foo extends Bar implements I1, I2 {` (last token is
  `{`, not the class name). New `_count_constructors` helper extracts
  the class name with regex and counts via a robust modifier-aware
  pattern.

- **Duplicate-method check flagged legitimate overloads**
  (`agents/coder.py`). Keyed on name only, so `info(String)` +
  `info(Object)` looked like a duplicate. Re-keyed on `(name, arity)`
  so v0.6.0's API-preservation requirement (keep all overloads)
  doesn't trigger spurious validation errors.

- **`LLMMalformedOutput` swallowed as generic `Exception`**
  (`agents/coder.py`). Schema violations from the LLM looked identical
  to network errors in the run log. Now caught separately, with a
  preview of the raw response in the error log so users can diagnose
  what the LLM actually returned.

- **`Retry-After` hints clamped to 90s** (`llm/retry.py`). Provider says
  "wait 180s", code waits 90s, retry hits the wall again. Now honored
  up to a separate `DEFAULT_MAX_RETRY_AFTER_SEC = 300s` cap; the generic
  exponential backoff still uses the 90s cap.

- **Anthropic `stop_reason=max_tokens` / OpenAI `finish_reason=length`
  not detected** (`llm/providers/anthropic.py`, `llm/providers/openai.py`).
  Truncated tool-use output passed through as malformed JSON, producing
  cryptic Pydantic errors downstream. Now raises `LLMMalformedOutput`
  immediately with a clear "increase max_tokens" message.

- **README "Supported today (v0.5.x)" header was stale** and falsely
  listed Ollama as a bundled provider. Updated to v0.6.x and clarified
  that only Anthropic/OpenAI ship today.

### Added (post-validation iteration)

After running v0.6.1 against the production project, three more findings
were folded into the same release:

- **Postgen Fix 13: non-abstract method missing `{ ... }` braces**
  (`core/postgen_fixes.py`). The LLM occasionally emits a method body
  on a single line without the opening brace:
  `private Browser createBrowser(BrowserType bt) Playwright p = ...; return ...;`
  Production v0.6.1 run had this in `BrowserFactory.java`. Fix wraps
  inline executable bodies in `{ ... }` while leaving abstract methods
  (handled by Fix 11) and field declarations alone. Heuristic requires
  at least one `;` plus `=`/`return` in the body so it doesn't
  false-positive.

- **Default `coder.max_tokens` raised from 8192 → 16384**
  (`core/config.py`). v0.6.0's API-preservation requirement keeps every
  overload, which means utility classes like `WebUI.java` (1000+ LOC,
  30+ public methods) need more output budget. The v0.6.1 production
  run hit truncation on WebUI at 8192 — caught and surfaced clearly
  thanks to v0.6.1's `stop_reason=max_tokens` detection, but the right
  default for real projects is higher.

- **Explicit "Required output signatures" checklist in Coder prompt**
  (`agents/coder.py`). Production v0.6.1 showed Requirement 3-bis
  ("preserve every overload") was still being ignored — the LLM
  generated only 1 of 4 `LogUtils.error` overloads. New
  `_build_required_signatures()` adds an explicit numbered checklist
  to the prompt with each public method/constructor signature the
  output MUST contain, grouped by name so overload sets stand out.
  Constructors are listed without `void`; throws clauses are included.

### Tests

- +31 regression tests (`tests/test_v061_hardening.py`) covering
  varargs capture, throws clauses, static init, postgen Fix 2 idempotency,
  Fix 13 missing-brace wrapping, config extra-forbid, provider validation,
  retry-after cap, hardened `validate_generated_code`, and the explicit
  required-signatures checklist.
- Updated 2 v0.5.17 retry-after tests to reflect the new 300s cap.
- Total: 432 → **463 passing**.

## [0.6.0] - 2026-04-26

**Theme: ProjectMap-driven coder context — eliminate cross-file API
mismatches by feeding the LLM real signatures.**

The v0.5.18 production run on `AutomationFrameworkSelenium` produced 6 mvn
errors in 4 files. Three of those four were the same root cause: the LLM
invented method/constructor overloads against project-internal classes
because it had never seen the real ones. Specifically:

- `LogUtils.error(String, Exception)` invoked against a 1-arg method.
- `FrameworkException(String, Throwable)` invoked against a 1-arg
  constructor.
- `InvalidPathForExtentReportFileException(String, ...)` similar.
- `DriverManager` migration omitted `private static ThreadLocal<WebDriver>
  context` / `browser` fields, leaving 12 `cannot find symbol` errors at
  call sites.

This release fixes the data flow so the Coder gets the REAL signatures.

### Added

- **Constructor extraction in `JavaParser`** (`core/parser.py`).
  Tree-sitter `constructor_declaration` nodes were being silently skipped
  by `_extract_class_body`. Now extracted as method-shaped dicts with
  `return_type=""` so downstream `MethodInfo.signature` formats them as
  `public Foo(String x)` rather than `public void Foo(String x)`. New
  `MethodInfo.is_constructor` property for callers that need to
  distinguish.

- **Overload set callout in coder prompt** (`intelligence/prompt_context.py`).
  When a sibling class has 2+ public methods sharing a name, the prompt
  now lists them under an explicit *"Method overload sets (these are the
  ONLY overloads — do not invent more)"* heading. Previously the flat
  signature list left the LLM free to extrapolate.

- **Constructor section in coder prompt.** Constructors now appear FIRST
  for each sibling class, under *"Available constructors (do NOT invent
  additional overloads)"*. Targets the `FrameworkException` /
  `InvalidPathForExtentReportFileException` classes of error.

- **Inherited ThreadLocal / static field callout**
  (`prompt_context._inherited_fields_callout`). When the migrating class
  extends a base with `ThreadLocal<WebDriver>` / `Logger` / static
  infrastructure fields, the prompt explicitly says *"Inherited fields
  from `BaseClass` — DO NOT redeclare; reference by name"*. Targets the
  v0.5.18 `DriverManager.java` 12-error pattern.

- **Anti-invention phrasing in dependencies header.** The "Sibling
  classes" section now reads *"do NOT invent methods, do NOT invent
  constructor or method overloads — if a method takes one argument here,
  you cannot call it with two"*.

- **API-preservation requirement in coder prompt** (`agents/coder.py`,
  Requirement 3-bis). Production validation revealed v0.6.0's
  ProjectMap-side surfacing wasn't enough on its own: when a utility
  class like `LogUtils` is itself the migrating file, the LLM regenerates
  it from scratch and silently drops overloads the source had. Adding
  *"Preserve EVERY public method, constructor, and overload from the
  original class"* to the per-file prompt closes the loop. Without this,
  a 4-overload `error()` source becomes a 1-overload Playwright class,
  cascading `cannot be applied to given types` errors at every caller.

### Fixed

- `_method_from_raw` previously coerced empty string `return_type` to
  `"void"` via `or "void"`, which broke constructor representation. Now
  uses an explicit None check so empty string survives intact for
  constructors while missing keys still default to `"void"` for methods.

### Tests

- +13 regression tests (`tests/test_v060_constructor_overload_fields.py`):
  - 5 for constructor capture (signature formatting, parser extraction,
    method-vs-constructor disambiguation)
  - 3 for overload-set surfacing in prompt context
  - 4 for inherited-fields callout (ThreadLocal, static logger, no
    parent, no infra fields)
  - 1 for anti-invention header phrasing
- Total: 419 → **432 passing**.

### Migration notes

This is a minor version bump (0.5 → 0.6) because the `MethodInfo` type
gained a new `is_constructor` property and constructors now appear in
`ClassInfo.public_methods`. Downstream consumers that iterate
`public_methods` will see constructors mixed in; filter on
`m.is_constructor` to separate them.

## [0.5.19] - 2026-04-26

**Theme: Doubled-header postgen + hard usage-cap detection.**

Driven by the v0.5.18 production run on `AutomationFrameworkSelenium` (85
files, 18 min, 6 mvn errors → BUILD SUCCESS after ~5 min manual fixes). The
two cheapest, highest-leverage findings ship here. Deeper findings
(ThreadLocal field auto-declare, custom-overload prompt context) are queued
for v0.6.0 because they need ProjectMap integration.

### Fixed

- **Doubled method headers collapsed** (`postgen_fixes.py` Fix 12).
  The LLM occasionally emits a method header twice in a row before the body:
  ```java
  synchronized public static void addAuthors(String[] authors)
  synchronized public static void addAuthors(String[] authors) {
      ...
  }
  ```
  Production project's `ExtentReportManager.java` had 6 errors of exactly
  this shape. New deterministic regex requires byte-identical repeats so
  legitimate overloads (different param lists or modifiers) are never
  affected. Modifier set covers `public/protected/private/static/final/
  abstract/synchronized/default/native/strictfp` plus `@Annotation` prefixes.

- **Hard usage-cap errors no longer trigger backoff retries**
  (`llm/retry.py`, `llm/errors.py`).
  When an account hits its monthly/daily quota, retrying just burns more
  budget on calls that are guaranteed to fail. The retry helper now
  classifies these as `LLMUsageCapExhausted` and propagates immediately:
  - Anthropic: *"You have reached your specified API usage limits. You
    will regain access on YYYY-MM-DD"*
  - OpenAI: `insufficient_quota` / *"You exceeded your current quota"*

  Detection runs **before** the rate-limit check because OpenAI's quota
  error is also a 429 — without ordering, the cap would be misclassified
  as transient and we'd sleep through 5 retries before failing anyway.

  The pipeline aborts the whole run with a clear "quota exhausted, retry
  later" message instead of marching through every remaining file marking
  each FAIL. Files already migrated remain on disk.

### Tests

- +15 regression tests (`tests/test_v0519_doubled_method_and_usage_cap.py`):
  - 7 for doubled-header postgen (simple / synchronized / overloads / no-op)
  - 5 for usage-cap classification (Anthropic / OpenAI / vs rate-limit)
  - 3 for retry-helper behaviour (no retry on cap, propagation, rate-limit
    still retries)
- Total: 404 → **419 passing**.

## [0.5.18] - 2026-04-25

**Theme: Postgen polish — abstract method semicolons.**

### Fixed

- **Abstract method declarations missing `;`** (`postgen_fixes.py` Fix 11).
  The LLM occasionally emits abstract method signatures without the trailing
  semicolon, especially when followed by a trailing `// comment`:
  ```java
  public abstract Browser createBrowser(Playwright playwright)  // no ;
  ```
  This produced 3 compile errors in `BrowserFactory.java` during the v0.5.17
  production run. New deterministic regex adds the missing `;` while preserving
  the trailing comment. Skips lines that already have a `;`, so safe on already-
  correct code.

### Tests

- +10 regression tests (`tests/test_v0518_abstract_method_semicolon.py`)
  covering modifiers, generic/qualified return types, trailing comments,
  already-correct code, and concrete-method bodies.
- Total: 394 → 404 passing.

### Validation

Re-ran on `AutomationFrameworkSelenium` (85 files):
- 84/85 files migrated (98.8%)
- 92% avg confidence
- 22 minutes wall-clock (vs 7.8h on v0.5.15 = 21× faster)
- 0 rate-limit failures (v0.5.17 retry logic kicked in transparently)
- Remaining `mvn compile` errors are cross-file API mismatches in 5 files
  (categorically different from pipeline bugs — they're LLM code-quality
  issues that need an LLM re-prompt or a few minutes of manual cleanup).

## [0.5.17] - 2026-04-25

**Theme: Rate-limit retry — production projects no longer fail on 429s.**

### Fixed

- **Rate-limit (429) errors now retry with exponential backoff.**
  Production runs revealed that Anthropic's 30K input-tokens-per-minute org
  limit is exceeded after ~6 large files in 60s. Previously the pipeline
  raised the error immediately and marked each file FAIL, wasting LLM
  budget on subsequent files even though the rate-limit window clears in
  30-60 seconds. The 85-file production run had 8+ files fail in a 30-second
  window because of this.

  New `qamigrate.llm.retry.call_with_retry()` wraps every Anthropic and
  OpenAI API call with:
  - **5 retries by default** (configurable per call)
  - **Exponential backoff**: 5s → 10s → 20s → 40s → 80s (capped at 90s)
  - **Retry-After hint support**: parses `"retry after 12 seconds"` /
    `"try after 2 minutes"` style hints from error messages and uses them
    instead of the schedule
  - **Anthropic 529 overloaded errors** treated identically to rate limits
  - **Non-rate-limit errors propagate immediately** — no retry on schema
    errors, malformed output, etc.

  This fix is invisible to callers; the same `generate_structured()` API
  works as before, just transparently waits on transient rate limits.

- **`LLMRateLimitError` exception class** added to `qamigrate.llm.errors`
  for cases where retries are exhausted. Wraps an optional `retry_after`
  attribute for callers that want to surface to the user.

### Tests

- +18 regression tests (`tests/test_v0517_rate_limit_retry.py`):
  - 6 for error classification (Anthropic 429, OpenAI 429, 529, 503, etc.)
  - 5 for Retry-After hint parsing (seconds, decimal, minutes, missing, capped)
  - 7 for retry behaviour (success path, propagation, exhaustion, backoff schedule)
- Total: 376 → 394 passing.

## [0.5.16] - 2026-04-25

**Theme: Production-grade hardening — closing the remaining 2% gap.**

Based on running QAMigrate v0.5.15 on `AutomationFrameworkSelenium` (85 files,
895 patterns, 7.8 hours). 73/85 files succeeded automatically; 200 compile
errors concentrated in 7 files. This release targets all root causes identified.

### Fixed

- **N/A prose injection stripped** (`postgen_fixes.py`).
  The LLM occasionally inserts lines like
  `N/A - Utility class with static methods only` directly into Java source.
  These are not valid Java and cause an immediate compile error. A postgen
  regex strips any line matching `N/A - ...` / `N/A — ...` / `N/A: ...`
  (case-insensitive). This was the highest-frequency bug in the production
  run, appearing in 5+ files.

- **Wall-clock Fixer timeout** (`FixerConfig.max_fix_seconds`, default 300s).
  `TestSimpleCode.java` spent 26,614 seconds (7.4 hours) in the iterative
  fix loop despite only 3 max retries — one iteration can make many LLM calls
  for large files. New `max_fix_seconds` config (30–3600s, default 300s) caps
  total wall-clock time per file. Files that exceed the budget are marked
  exhausted and skipped, cutting run time from 7.8h to ~1.5h on that project.

- **`@interface` annotation types passthrough** (`passthrough.py`).
  Java annotation interfaces (`public @interface FrameworkAnnotation`) have no
  Selenium content and the LLM can't generate them correctly (produces prose
  instead of valid Java). Files containing `@interface` and no Selenium markers
  are now copied verbatim.

- **Lombok / aOwner `@Config` interface passthrough** (`passthrough.py`).
  Files importing `org.aeonbits.owner` or decorated with `@Config(...)` are
  configuration interfaces — not UI automation code. Copied verbatim.

- **Non-Selenium infrastructure passthrough** (`passthrough.py`).
  Files that ONLY use `javax.mail`, `java.awt.Robot`, `org.monte.media`, or
  `com.xuggle` (screen recording, email, OS-level automation) are not UI
  automation and must not be migrated. The LLM produces broken output for these.
  Now passthrough when no Selenium markers are present. This would push the
  86% auto-success rate closer to 98% on large enterprise projects.

- **No-arg enum constant separator** (`postgen_fixes.py`).
  The existing enum separator fix handled enums with constructor arguments
  (`DEV("dev"),`). Production run revealed no-arg enums like `STOP_ON_FAILURE;`
  that also need `; → ,`. The new `_fix_enum_separator()` rule handles
  all-uppercase no-arg constant sequences inside enum bodies.

### Additional fixes — closing the last 2%

- **Comment-stripped Selenium check** (`passthrough.py`).
  False positive: header comments like `// Automation Framework Selenium`
  were blocking passthrough on files with zero Selenium API content. Bare-word
  markers (`Selenium`) are now checked against comment-stripped source, while
  unambiguous tokens (`org.openqa.selenium`, `WebDriver`, `@FindBy`, etc.)
  are still checked against raw source. Fixes `EmailConfig.java` and similar.

- **Constants-class passthrough** (`passthrough.py`).
  Files that have `public static final` fields but NO instance methods are
  pure data holders (SMTP host/port, REPORT_TITLE, API URLs). Copy verbatim.
  Catches `EmailConfig.java` and similar config-only classes.

- **`TakesScreenshot` orphan import strip** (`postgen_fixes.py`).
  When `AllureManager`/`ExtentReportManager` are migrated, the LLM rewrites
  `((TakesScreenshot) driver).getScreenshotAs(BYTES)` body but may leave the
  `import org.openqa.selenium.TakesScreenshot;` import line behind. Strip it
  deterministically when no longer used in the body.

### Tests

- +27 regression tests (`tests/test_v0516_production.py`):
  - 6 for N/A prose strip
  - 3 for Fixer timeout config
  - 4 for @interface / Lombok passthrough
  - 4 for infrastructure passthrough
  - 4 for no-arg enum separator
  - 3 for comment-stripped Selenium check
  - 3 for constants-class passthrough
- Total: 349 → 376 passing.

## [0.5.15] - 2026-04-25

**Theme: Cucumber BDD support — Selenium+Java+TestNG+Cucumber → Playwright+Java+TestNG+Cucumber.**

### What stays the same in a BDD migration

Feature files (`.feature`), step definition annotations (`@Given`/`@When`/`@Then`),
Cucumber hooks (`@Before`/`@After`), the JUnit Platform Suite runner class, all
Gherkin tags, Allure integration, and parallel execution configuration are
**100% preserved**. QAMigrate only replaces the browser automation layer
(Selenium WebDriver → Playwright Page).

### Added

- **Cucumber BDD detection.** `infrastructure.py` sets `bdd_framework="cucumber"`
  when `io.cucumber.*` appears in `pom.xml` or `build.gradle`. All downstream
  components read this flag.

- **Three new ClassRole values:** `STEP_DEFINITION`, `CUCUMBER_HOOKS`,
  `CUCUMBER_RUNNER`. Role inference uses import-based detection (reliable even
  when the parser doesn't surface method-level annotations):
  - `io.cucumber.java.en.*` → `STEP_DEFINITION`
  - `io.cucumber.java.Before/After` → `CUCUMBER_HOOKS`
  - `org.junit.platform.suite.*` → `CUCUMBER_RUNNER`

- **Cucumber runner passthrough.** `TestRunner.java` (annotated `@Suite` +
  `@IncludeEngines("cucumber")`) is copied verbatim — its structure must remain
  exactly as-is for Cucumber to discover tests. The passthrough check runs
  BEFORE the Selenium markers exclusion so the `org.junit.platform.suite`
  import doesn't block it.

- **BDD-aware Coder prompt.** `_build_system_prompt(target_framework, is_bdd=True)`
  adds a `### BDD (Cucumber) Project — CRITICAL RULES` section:
  - Step definition method signatures are FROZEN
  - `@Given`/`@When`/`@Then` must not be changed in any way
  - Hooks: keep Cucumber `@Before`/`@After`, replace WebDriver init with Playwright
  - DriverManager: keep ThreadLocal pattern, change `ThreadLocal<WebDriver>` → `ThreadLocal<Page>`
  - NEVER add `@ExtendWith` to step def or hooks classes
  - NEVER import `org.junit.jupiter.api.BeforeEach` into Cucumber classes

- **8 new Cucumber patterns** in `patterns.py` (`PatternCategory.BDD`):
  `@Given`, `@When`, `@Then`, `@And`, `@But`, Cucumber `@Before` hook,
  Cucumber `@After` hook, `Scenario` injection. Each has migration strategy
  and playwright equivalent for Coder context.

- **Postgen fix: Cucumber import corruption guard.** The import rewriter
  (which appends `.playwright` to sibling class imports) must never touch
  `io.cucumber.*` imports. New `_fix_cucumber_import_corruption()` rule strips
  any `.playwright` suffix that crept into a Cucumber import line.

- **`is_bdd` threaded through pipeline.** `run_project_migration()` detects
  BDD from `project_map.infrastructure.bdd_framework`, logs the mode, and
  passes `is_bdd` into every `run_generation()` → `generate_from_class_info()`
  call.

### Tests

- +20 BDD regression tests (`tests/test_v0515_bdd.py`):
  - 2 infrastructure detection
  - 5 role inference (incl. real BDD project)
  - 3 runner passthrough
  - 6 coder prompt BDD section
  - 4 Cucumber import corruption fix
- Total: 329 → 349 passing.

## [0.5.14] - 2026-04-25

**Theme: Security + performance audit fixes, 7 new patterns, README overhaul.**

### Security

- **API key redaction in `__repr__`** (`llm/providers/anthropic.py`,
  `llm/providers/openai.py`). Both providers now implement `__repr__` that
  shows only the last 4 chars of the key (`...xyzw`). Previously a stack
  trace that included the provider object would print the full key.

### Performance / Reliability

- **Playwright version detected from project, not hardcoded.**
  `DependencyInjector` accepts `playwright_version` from
  `Infrastructure.playwright_version`. If the source pom already pins
  Playwright (from a partial migration), that version is used — no surprise
  upgrades. The `init` command passes the detected version through.

- **Classpath cache validates ALL entries, not just one.**
  Previously the cache was accepted if `any()` entry existed on disk.
  Now ALL entries are checked; a single missing JAR (from a Maven repo
  clean or dependency update) invalidates the cache and forces a rebuild.
  Silent stale-cache compile failures are eliminated.

- **Source root validation before compile.**
  If neither `src/main/java` nor `src/test/java` exists, the pipeline
  now fails fast with a clear message instead of passing an invalid
  `-sourcepath` to javac and getting cryptic errors.

- **Empty-generations fast-path.**
  When all file generations fail, the compile loop is skipped immediately
  rather than running with an empty file list.

### Config validation

- `PipelineConfig.max_retries`: bounded `0 ≤ n ≤ 10` (Pydantic `ge`/`le`).
- `ClasspathConfig.timeout_seconds`: bounded `10–600`.
- `ScannerConfig.max_file_size_kb`: bounded `1–10240`.
- `CompilerConfig.timeout_seconds`: bounded `10–600`.
- `CompilerConfig.build_tool`: validated to `"maven"` or `"gradle"`.
  Invalid values now raise a `ValueError` at config-load time instead of
  silently failing at compile time.

### 7 new Selenium patterns detected

Patterns that were previously invisible to the scanner (treated as "unknown
methods") now have explicit migration strategies surfaced in the Coder prompt:

| Pattern | Migration |
|---|---|
| `findElements(By.x)` | `page.locator(x).all()` — returns `List<Locator>` |
| `By` stored as a class field | `Locator` field, initialized in constructor |
| `@DataProvider` (TestNG) | Preserved for TestNG; `@MethodSource` for JUnit5 |
| `@Parameters` (TestNG) | Preserved for TestNG; `@ParameterizedTest` for JUnit5 |
| `switchTo().frame(sel)` | `page.frameLocator(sel).locator(...)` |
| `getWindowHandles / switchTo window` | `page.waitForPopup()` |
| `java.awt.Robot` keyboard | `page.keyboard().press()` |

### Documentation

- **README completely rewritten** for v0.5.14. Covers framework preservation,
  full migration table (Selenium API → Playwright API), lifecycle annotation
  table per framework, CI integration example (`--confidence-threshold`),
  updated architecture diagram, and Python API example.

### No new tests — 329 passing (all existing tests pass unchanged).

## [0.5.13] - 2026-04-22

**Theme: Framework preservation — QAMigrate now keeps your test framework.**

Previously QAMigrate always converted TestNG → JUnit5 regardless of what
the source project used. This was fundamentally wrong: `@DataProvider`,
`@Parameters`, `@Listeners`, `ITestListener`, `IRetryAnalyzer` are all
TestNG-only features with no direct JUnit5 equivalent. Forcing conversion
broke data-driven tests and required manual migration of listener classes.

v0.5.13 detects the source project's test framework and preserves it in
the generated output.

### What changes based on detected framework

**TestNG project (stays TestNG):**
- Coder prompt: all TestNG annotations kept (`@BeforeMethod`, `@AfterMethod`,
  `@BeforeClass`, `@AfterClass`, `@Test`, `@DataProvider`, `@Parameters`,
  `@Listeners`). Only the Selenium API → Playwright API is migrated.
- Data-driven tests with `@DataProvider` / `@Parameters` preserved verbatim.
- `@Listeners({X.class})` annotation preserved (not rewritten to `@ExtendWith`).
- `org.testng.*` imports preserved in generated files.
- `qamigrate init --yes` injects `org.testng:testng` (at detected version),
  not `org.junit.jupiter:junit-jupiter`.
- TestNG `Assert.*` calls kept for value assertions; Playwright `assertThat()`
  used for UI state assertions.

**JUnit5 project (existing behaviour, unchanged):**
- Full TestNG → JUnit5 annotation conversion (`@BeforeMethod` → `@BeforeEach`,
  `@BeforeClass` → `@BeforeAll static`, etc.).
- `org.testng.*` orphaned imports stripped.
- `@Listeners` → safe `@ExtendWith` stub.
- `org.junit.jupiter:junit-jupiter` injected.

**JUnit4 project (new):**
- `@Before`/`@After`/`@BeforeClass`/`@AfterClass` kept in JUnit4 form.
- `junit:junit:4.13.2` injected.

### Files changed

- **`agents/pipeline.py`**: extracts `target_framework` from `project_map.infrastructure`
  after Phase 0; threads it through `run_generation()` and both
  `apply_all_postgen_fixes()` calls.
- **`agents/coder.py`**: `SYSTEM_PROMPT` replaced by `_build_system_prompt(target_framework)`
  which generates the correct lifecycle section and test class scaffold per
  framework. `generate_from_class_info()` gains `target_framework` param.
- **`core/postgen_fixes.py`**: `apply_all_postgen_fixes()` gains
  `target_framework` param. On TestNG path: `@Listeners` rewrite is skipped;
  TestNG import strip is skipped. On JUnit5/JUnit4 path: existing behaviour.
- **`agents/dependency_injector.py`**: `DependencyInjector.__init__()` gains
  `test_framework` and `test_framework_version` params. `_needed_deps()` now
  returns the correct framework dep based on those params.
- **`cli/main.py`**: `init` command detects framework via `ProjectAnalyzer`
  and passes it to `DependencyInjector`. The confirmation message shows the
  actual framework dep that will be injected.

### Tests

- +18 tests (`tests/test_v0513_framework_preservation.py`):
  - 7 for coder prompt variants (TestNG/JUnit4/JUnit5)
  - 5 for postgen fix gating
  - 6 for dependency injector framework awareness
- Total: 311 → 329 passing.

## [0.5.12] - 2026-04-22

**Theme: Guard the Selenium import strip rule — one line prevents a regression.**

### Fixed

- **`_fix_leftover_selenium_imports` was too aggressive on listener files.**
  In v0.5.11 the rule stripped ALL `org.testng.*` imports from generated files.
  Listener classes (`RetryAnalyzer`, `TestListener`) still declare
  `implements IRetryAnalyzer` / `implements ITestListener` — both TestNG
  types. Removing their imports left 10 unresolved symbols and broke the
  compile that v0.5.10 had at 2 errors.

  Fix: before removing any import line, extract the simple class name and
  check whether it appears in the file body (outside the import declaration
  itself). If the name is referenced, the import is kept. If not, it is
  removed. This one guard preserves all legitimately-used TestNG/Selenium
  types while still cleaning truly orphaned imports.

  Examples of what the guard now does correctly:
  - `import org.testng.IRetryAnalyzer;` — **kept** (class used in `implements`)
  - `import org.testng.ITestResult;` — **kept** (type used in method signature)
  - `import org.openqa.selenium.WebDriver;` — **removed** (not referenced)
  - `import org.testng.annotations.BeforeMethod;` — **removed** (not referenced)

  `org.testng.Assert` static imports are still always removed — those method
  names are too generic to use as class-name presence checks, and the
  assertions are always rewritten to JUnit5/Playwright forms anyway.

### Tests

- 311 passing (unchanged — existing tests cover the guard behaviour through
  the integration scenarios in `test_v0511_regressions.py`).

## [0.5.11] - 2026-04-21

**Theme: Zero-touch BUILD SUCCESS — three postgen rules close the last compile gaps.**

Based on the v0.5.10 test: manual patching of two files achieved BUILD SUCCESS.
v0.5.11 automates both patches and adds a third for completeness.

### Fixed

- **AssertJ imports stripped from generated files (WaitUtils.java fix).**
  The LLM occasionally adds `import static org.assertj.core.api.Assertions.assertThat`
  to utility classes. AssertJ is not injected by `qamigrate init` and usually
  not a project dependency. New postgen rule removes all `org.assertj.*` imports
  and rewrites the most common boolean patterns:
  - `assertThat(locator.isVisible()).isTrue()` → `assertThat(locator).isVisible()`
  - `assertThat(locator.isVisible()).isFalse()` → `assertThat(locator).isHidden()`
  - `assertThat(locator.isEnabled()).isTrue()` → `assertThat(locator).isEnabled()`
  When Playwright's `assertThat` is needed, adds the correct static import.

- **Leftover Selenium/TestNG imports stripped (BasePage.java fix).**
  Generated files sometimes retain `import org.openqa.selenium.*` or
  `import org.testng.*` lines from the original Selenium source. These cause
  "package org.openqa.selenium does not exist" errors since the Playwright
  classpath has no Selenium JAR. New postgen rule removes all `org.openqa.selenium.*`
  and stale `org.testng.*` imports (excluding `org.testng.annotations.Test`
  which might legitimately appear during migration).

- **WaitForSelectorState import guard.**
  After the Locator.State → WaitForSelectorState fix rewrites usages, a
  subsequent Fixer iteration could remove the import. New guard ensures
  `import com.microsoft.playwright.options.WaitForSelectorState;` is always
  present whenever the type appears.

- **Confidence gate: try/except around `raise typer.Exit(code=2)` with
  `os._exit(2)` fallback.** When Typer's SystemExit is intercepted by a
  Windows .exe wrapper or CI runner, os._exit(2) fires immediately, bypassing
  all Python handlers. This closes the last known path where the gate could
  return exit code 0.

### Tests

- +16 regression tests (`tests/test_v0511_regressions.py`):
  - 6 for AssertJ removal and assertion rewriting
  - 5 for Selenium/TestNG import stripping
  - 3 for WaitForSelectorState guard
  - 2 integration (WaitUtils, BasePage scenarios from the test report)
- Total: 295 → 311 passing.

## [0.5.10] - 2026-04-21

**Theme: Codebase audit — security fixes, report UI overhaul, code quality.**

### Security / Correctness

- **Compiler classpath separator was hardcoded `";"` on single-file compile.**
  `compile_batch()` already used `os.pathsep` correctly. `compile_single_file()`
  had a hardcoded Windows `";"`. Fixed to `os.pathsep` — now works correctly
  on Linux/macOS too.

### Report UI — major overhaul

- **Confidence score now shows a colour-coded progress bar** (green ≥90%,
  amber ≥70%, orange ≥50%, red <50%) next to the percentage in every file
  card. At a glance a QA lead knows which files to trust.

- **Confidence reason text** is now shown below each file's patterns section:
  "Compiled after 2 fix attempts." / "Compiled clean on first attempt." /
  "Compilation failed after 3 fix attempts." / etc. When hallucinations are
  detected, the penalty is explained: "-20 pts: 2 potential hallucination(s)."

- **Hallucination details improved.** Each hallucination now shows the
  class name, the specific method, the closest real method ("did you mean?"),
  and which generated file triggered the detection. Styled with amber warning
  colours to distinguish from compile errors.

- **Mobile-responsive HTML report.** Added `<meta viewport>` tag and
  `@media` queries for 768px and 480px breakpoints. The diff table wraps
  on small screens; metrics grid collapses to 2 columns; file headers stack
  vertically on mobile. Previously the report was unusable on phones/tablets.

- **`review.md` checklist is more actionable.**
  - Priority files now include the first 150 chars of the compile error
    message so reviewers can triage without opening the full report.
  - Verify files list hallucinated method names inline.

- **Hallucination dataclass now has `source_file` field** so the HTML
  report can show which generated file the hallucination was detected in.

### README

- Updated "Supported today" section from v0.4.x to v0.5.x with accurate
  feature list (project intelligence, post-gen fixups, quality reports).
- Updated roadmap (v0.6.x Python, v0.6.x+ JS/TS including Java→JS).

### No tests changed — 295 passing.

## [0.5.9] - 2026-04-21

**Theme: Close remaining compile gaps and fix the CI gate definitively.**

### Fixed

- **Confidence gate now uses `raise typer.Exit(code=2)` (definitive fix).**
  Previous versions tried `os._exit(2)` and `sys.exit(2)`. The root cause
  was that the user was checking `$?` in PowerShell (which is `True`/`False`,
  not the exit code). `raise typer.Exit(code=2)` is the canonical Typer
  mechanism and works correctly in all environments. Also adds an inline
  CI tip message pointing users to `$LASTEXITCODE` (PowerShell) or
  `%ERRORLEVEL%` (cmd).

- **`@Listeners` guard: safe TODO comment instead of broken `@ExtendWith`.**
  In v0.5.8 the `@Listeners({TestListener.class})` → `@ExtendWith` rewrite
  caused 20 new compile errors because `TestListener implements ITestListener`
  (TestNG), not `Extension` (JUnit5). `@ExtendWith` requires the latter.
  v0.5.9 replaces the annotation with a compile-safe `// TODO` comment that
  names the listener class and explains exactly what migration is needed.
  This eliminates the compile error without introducing a new one.
  Callers who have confirmed which listeners implement `Extension` can pass
  `extension_classes={"MyListener"}` to `apply_all_postgen_fixes` and the
  `@ExtendWith` rewrite will be applied for those confirmed classes only.

- **`Locator.State.X` → `WaitForSelectorState.X` (BasePage.java fix).**
  The LLM generates `setState(Locator.State.HIDDEN)` but `setState()` takes
  `WaitForSelectorState`, not `Locator.State`. New postgen rule replaces all
  `Locator.State.*` references with `WaitForSelectorState.*` and adds the
  correct import `com.microsoft.playwright.options.WaitForSelectorState`.

- **Extended `PLAYWRIGHT_IMPORTS` in fixer.** Added `WaitForSelectorState`,
  `LoadState`, `MouseButton`, `KeyboardModifier`, `ScreenshotType`,
  `ColorScheme`, `ViewportSize` so the Fixer's rule-based pass can
  auto-add their imports when needed.

### Tests

- Updated v0.5.7 and v0.5.8 test assertions for new gate and
  `@Listeners` behavior.
- +13 new regression tests (`tests/test_v059_regressions.py`):
  - 2 for gate exit code form
  - 4 for `@Listeners` guard (safe TODO, confirmed extension, mixed, compile-safe)
  - 5 for `Locator.State` → `WaitForSelectorState`
  - 2 integration
- Total: 282 → 295 passing.

## [0.5.8] - 2026-04-20

**Theme: Two remaining compile errors fixed deterministically. BUILD SUCCESS expected.**

### Fixed

- **Fix 1 — Confidence gate `os._exit(2)` (belt-and-suspenders over `sys.exit`).**
  `sys.exit(2)` can still be intercepted by Python's atexit handlers or
  exception handlers in some environments. Replaced with `os._exit(2)` which
  bypasses all Python shutdown machinery and writes the exit code directly to
  the OS. Also prints `Exit code: 2` to stderr so CI scripts that capture
  stdout separately can detect the failure. PowerShell note: use
  `$LASTEXITCODE`, not `$?` (which is a bool).

- **Fix 2 — `@Listeners({X.class})` → `@ExtendWith(X.class)` (TestNG→JUnit5).**
  `BaseTest.java` consistently failed to compile with
  `cannot find symbol: @Listeners` because the LLM preserved the TestNG
  annotation form without migrating it to JUnit5. New deterministic post-gen
  fix in `core/postgen_fixes.py`:
  - `@Listeners({X.class})` → `@ExtendWith(X.class)`
  - Multiple listeners → stacked `@ExtendWith` annotations
  - Removes `import org.testng.annotations.Listeners;`
  - Adds `import org.junit.jupiter.api.extension.ExtendWith;`
  Applied in Phase 1.6 (before first compile) AND re-applied after each Fixer
  write so it can't be undone. Zero LLM cost.

- **Fix 3 — `ScreenshotOptions` hallucinated import removed.**
  `ScreenshotUtils.java` consistently failed with
  `cannot find symbol: ScreenshotOptions` because the LLM generates
  `import com.microsoft.playwright.options.ScreenshotOptions;` which doesn't
  exist. `ScreenshotOptions` is an inner class of `Page`. New deterministic fix:
  - Removes the non-existent `options.ScreenshotOptions` import
  - Rewrites `ScreenshotOptions` references to `Page.ScreenshotOptions`
  - Ensures `import com.microsoft.playwright.Page;` is present
  Same application points as Fix 2 (Phase 1.6 + after each Fixer write).

### Tests

- +12 regression tests (`tests/test_v058_regressions.py`):
  - 1 for gate using `os._exit`
  - 5 for `@Listeners` rewrite (single, multiple, no-op, idempotent)
  - 4 for `ScreenshotOptions` import fix
  - 2 integration tests for `apply_all_postgen_fixes`
- Total: 270 → 282 passing.

## [0.5.7] - 2026-04-20

**Theme: Fix root causes of Fixer regression and CI gate exit code.**

### Fixed

- **Bug #1 — `--confidence-threshold` still exiting code 0 (Windows).**
  `raise typer.Exit(2)` was being swallowed by the compiled `.exe` entry-point
  wrapper on Windows. Replaced with `sys.exit(2)` which goes directly to the OS.
  Same change applied to the `failed_count > 0` path (`sys.exit(1)`) for
  consistency.

- **Bug #2 — Fixer writes regressed content to disk; best snapshot lost.**
  The Fixer loop tracked `global_best` (error count) but never tracked the
  actual file content at the best point. When the Fixer regressed in iteration 4
  (1 error → 13 errors), the files on disk reflected the regressed state, not
  the best state. `mvn clean compile` saw 26 errors instead of 1.
  Fix: snapshot each file's content whenever `global_best` improves. After the
  loop exits without clean compilation, restore every file that is worse than
  its snapshot and re-compile once to get accurate final error counts.

- **Bug #3 — Sibling import rewrite not re-applied after Fixer modifies files.**
  The import rewrite (Phase 1.5) ran once before compile. If the Fixer
  regenerated a file in Phase 3, it could re-introduce old import paths
  (e.g. `import com.qastarter.browser.BrowserFactory` instead of
  `com.qastarter.browser.playwright.BrowserFactory`). Fixed by:
  (a) returning the `name_to_orig_pkg` map from `_rewrite_sibling_imports`;
  (b) re-applying `_apply_import_rewrite` on each file immediately after the
      Fixer writes it. The rewrite is idempotent so double-application is safe.

### Tests

- +6 regression tests (`tests/test_v057_regressions.py`):
  - 2 for `sys.exit(2)` gate (source inspection + live gate evaluation)
  - 2 for `_rewrite_sibling_imports` return value
  - 2 for import-rewrite idempotence and Fixer-regression correction
- Total: 264 → 270 passing.

## [0.5.6] - 2026-04-20

**Theme: Two final P0s from v0.5.5 test report — one trivial ordering fix,
one prompt guard. Together these should achieve BUILD SUCCESS.**

### Fixed

- **P0 #1 — `--confidence-threshold` exited code 0 instead of 2.**
  The confidence gate (`raise typer.Exit(2)`) was placed AFTER the
  `failed_count > 0` check (`raise typer.Exit(1)`). When any file failed
  generation (e.g. BaseTest.java in v0.5.5), the `Exit(1)` fired first
  and the gate was never reached. CI scripts checking `$? -eq 2` never
  triggered. Fix: the confidence gate is now evaluated BEFORE the
  `failed_count` check. Both checks run independently; the gate prints
  its message and exits 2 even when other files also failed.

- **P0 #2 — Fixer replaced `getPage()` with `getDriver()` causing
  type mismatch in BaseTest.java.**
  The Fixer's LLM saw a `cannot find symbol: getPage()` error and
  guessed `getDriver()` as a substitute — plausible-sounding but wrong:
  `getDriver()` returns `WebDriver`, not `Page`. Added explicit rules to
  `FIXER_SYSTEM_PROMPT` that:
  (1) `getPage()` must NEVER be substituted with `getDriver()`;
  (2) `cannot find symbol` on a sibling project class should be fixed by
      correcting the import to the `.playwright` sub-package, not by
      renaming the method.

### Tests

- +8 regression tests (`tests/test_v056_regressions.py`):
  - 5 for confidence gate ordering with mixed-success reports
  - 3 for fixer prompt content (getDriver warning, .playwright rule,
    do-not-rename instruction)
- Total: 256 → 264 passing.

## [0.5.5] - 2026-04-19

**Theme: Fix the root cause of all remaining `mvn clean compile` failures.**

All 24 remaining compile errors in the v0.5.4 test report traced back to
the same architectural gap: generated files imported sibling classes via
the ORIGINAL package path, not the migrated `.playwright` path. Three
coordinated fixes close this.

### Fixed

- **Fix 1 — Post-generation sibling import rewrite (addresses ~22 of 24
  remaining errors).**
  After all files are generated (Phase 1), a new deterministic pass
  rewrites import statements that reference migrated sibling classes.
  Example: `import com.qastarter.browser.BrowserFactory;` becomes
  `import com.qastarter.browser.playwright.BrowserFactory;`. The rewrite
  uses a map of `{simple_class_name → original_package}` built from the
  generation results — no LLM call. Only `import` lines are touched;
  method bodies, comments, and third-party imports (Playwright API, JUnit,
  etc.) are left unchanged. Both the on-disk file and the in-memory
  `GenerationResult.generated_code` are updated so the compile check and
  hallucination detector see consistent state. This addresses the
  `cannot find symbol` errors in DriverManager, ScreenshotUtils, BasePage,
  WebActions, and BaseTest.

- **Fix 2 — Sanitize dict-valued `fields[]` list items (fixes WaitUtils
  Pydantic crash).**
  `gpt-4o` occasionally returns a structured object (e.g.
  `{'declaration': 'private Page page;', 'init': 'this.page = page;'}`)
  in the `fields[]` list, which the schema declares as `list[str]`.
  Pydantic v2 rejected this with a validation error, causing WaitUtils.java
  (and potentially other files) to be skipped entirely. `sanitize_fields()`
  in `llm/sanitize.py` now coerces dict-valued elements in `fields[]` and
  `imports[]` to strings by extracting the first string value from known
  keys (`declaration` > `type` > `name` > `value`). The `methods[]` list
  is intentionally excluded from coercion — its items are `MethodDefinition`
  dicts and must remain structured.

- **Fix 3 — Coder prompt: explicit `.playwright` import instruction.**
  Added numbered requirement 7 and a header note in the sibling-signatures
  block telling the LLM to append `.playwright` to the package path of any
  imported sibling class. Example provided inline. This prevents the import
  problem at generation time; Fix 1 remains as a safety net for cases where
  the LLM ignores the instruction.

### Tests

- +16 regression tests (`tests/test_v055_regressions.py`):
  - 7 for `_apply_import_rewrite()` (exact match, no false-positives,
    idempotent, non-import lines untouched)
  - 7 for `sanitize_fields()` dict coercion (priority order, methods
    unchanged, imports coerced, fallback str())
  - 2 for coder prompt content (system prompt + sibling block)
- Total: 240 → 256 passing.

## [0.5.4] - 2026-04-19

**Theme: Last two P0s from v0.5.3 test report — both blocking BUILD SUCCESS.**

### Fixed

- **P0 #1 — Passthrough files (enums) still emitted with wrong package.**
  `Environment.java` took the passthrough path (copy verbatim, no LLM),
  so the `.playwright` suffix enforcement added to `assemble_file()` in
  v0.5.3 never ran. The file was copied with `package com.qastarter.config;`
  and Maven saw a duplicate-class collision with the original.
  New `rewrite_package_for_passthrough()` in `intelligence/passthrough.py`
  rewrites the package declaration to append `.playwright` before writing
  the output file. Applied to both the single-file and batch pipeline paths.
  Idempotent: if the source somehow already ends with `.playwright`, it is
  not doubled.

- **P0 #2 — JUnit5 still injected with `<scope>test</scope>`.**
  v0.5.3 fixed Playwright's scope but left JUnit5 as test-scoped.
  `BaseTest.java` (and other lifecycle classes) are generated into
  `src/main/java` and import `org.junit.jupiter.api.*`. With test scope,
  Maven's compiler cannot resolve those imports for main-scope sources,
  producing 10+ errors in BaseTest.java alone.
  Fix: JUnit5 is now also injected without `<scope>` (= compile/default
  scope, visible to both `src/main` and `src/test`). This completes the
  scope fix started in v0.5.3.

### Tests

- +9 regression tests (`tests/test_v054_regressions.py`):
  - 6 for `rewrite_package_for_passthrough()` including end-to-end
    on the real `Environment.java` sample file
  - 3 for both deps having no scope after injection
- Updated `test_dependency_injector.py::test_line_count_grows_predictably`
  (10 new lines: both deps at 5 lines each, no scope line)
- Updated `test_v053_regressions.py` JUnit5 scope assertion
- Total: 231 → 240 passing.

## [0.5.3] - 2026-04-19

**Theme: Critical regression fixes from v0.5.1 real-project test report.**
All three bugs caused `mvn clean compile` to fail on any project migrated
with v0.5.1/v0.5.2, despite QAMigrate's internal check reporting 14/15
success at 93% confidence. This release fixes all three root causes.

### Fixed

- **Bug #1 — Wrong package declaration in all generated files.**
  Generated files declared `package com.example.pages;` — identical to
  their Selenium originals. When both source trees are compiled together
  by Maven, the Java compiler sees two classes with the same FQN
  (`com.example.pages.LoginPage`) and emits duplicate-symbol errors.
  Root cause: the Coder prompt said "Use exact same package name".
  Fix: two-layer defence —
  (1) Prompt now explicitly says to append `.playwright`
      (`com.example.pages` → `com.example.pages.playwright`);
  (2) The `package_name` tool-schema field description now also states
      the `.playwright` requirement;
  (3) `assemble_file()` enforces the suffix as a safety net regardless
      of what the LLM returns, so a mistaken response can never produce
      a duplicate-class collision.

- **Bug #2 — Playwright JAR injected with `<scope>test</scope>`.**
  `qamigrate init --yes` was injecting Playwright as a test-scoped
  dependency. Because QAMigrate generates page-object and base-class
  files into `src/main/java` that import `com.microsoft.playwright.*`,
  Maven cannot resolve those imports from a test-scoped JAR, producing
  "package com.microsoft.playwright does not exist" across every
  main-scope generated file.
  Fix: Playwright is now injected **without** a `<scope>` element
  (= default compile scope, visible to both `src/main` and `src/test`).
  JUnit 5 correctly keeps `<scope>test</scope>`.

- **Bug #3 — Internal compile check reported false success.**
  QAMigrate's batch `javac` check compiled only the `playwright/`
  output files in isolation. It never saw the original Selenium files,
  so duplicate-class collisions (Bug #1) and missing-package errors
  (Bug #2) were invisible to it. Fix: added `_warn_package_collisions()`
  that compares the package declared in each generated file against its
  original source. When they match, a structured warning is logged with
  a clear explanation and the fix, so users see the problem before
  invoking Maven rather than after.

### Tests

- +11 regression tests (`tests/test_v053_regressions.py`):
  - 4 for package-name enforcement in `assemble_file()`
  - 3 for dependency scope (Playwright no scope, JUnit test scope)
  - 3 for package-collision detection (`_warn_package_collisions`)
- Updated `test_dependency_injector.py::test_line_count_grows_predictably`
  to expect 11 new lines (Playwright: 5 lines, no scope; JUnit5: 6 lines
  with scope) instead of 12.
- Total: 220 → 231 passing.

## [0.5.2] - 2026-04-19

**Theme: Polish pass before next framework.** No new source/target
framework; instead, four precision fixes that harden what v0.5.1 shipped
with. All four came out of the v0.5.0/v0.5.1 real-project test report
and the review afterwards.

### Added

- **(a) Passthrough files now contribute sibling signatures.** In v0.5.1,
  files that went through the enum-passthrough path returned
  `signatures=[]`, which meant tests that imported them (e.g. a test
  using `Environment.DEV`) saw an empty sibling-context block and the
  Coder would occasionally hallucinate constants like `Environment.DEVELOPMENT`.
  Now passthrough files run through the scanner even though the LLM is
  skipped, and their extracted enum constants + methods flow into the
  Coder's prompt for every downstream file. New enum-aware branch in
  `core/parser.py` + new `build_signatures_from_class_info` helper in
  `intelligence/passthrough.py`.

- **(b) Selector hallucination detection now covers `getByTestId`.**
  v0.5.1 only checked `.locator("...")`. Tests that use
  `page.getByTestId("submit-btn")` were unvalidated even though the
  page object declares its test-ids explicitly. New
  `DeclaredSelectors` dataclass splits the per-class catalogue into
  `css` and `testids` so the two are never cross-compared (a CSS
  `#submit-btn` is NOT the same as a test-id `submit-btn`).
  Deliberately does NOT extend to `getByRole/Text/Label/Placeholder/AltText/Title`:
  those validate against ARIA/accessible-name semantics, not a
  declarative inventory, and string comparison there produces
  false-positives that erode trust in the detector. Backward
  compatible: old `dict[str, set[str]]` callers still work.

- **(c) `--confidence-threshold` CLI flag for quality gating.** Opt-in
  `qamigrate migrate --confidence-threshold 80 [--confidence-mode any|avg]`
  fails the run with exit code 2 (distinct from exit code 1 = migration
  broke) when the bar isn't met. Two modes:
  - `any` (default, strict): any single file below threshold fails.
  - `avg`: only the project-wide average must clear the bar.
  New `core/confidence_gate.py` module keeps the gate logic unit-testable
  without a Typer CliRunner harness. CI users: use
  `--confidence-threshold 80 --confidence-mode avg` to gate PRs on
  overall migration quality.

- **(d) `review.md` manual-review checklist.** When `--report <dir>` is
  passed, QAMigrate now also writes `review.md` alongside `report.html`,
  `report.json`, and `report.md`. Three prioritized buckets:
  - **Priority** (generation failed, or compile failed, or confidence &lt; 70): fix first.
  - **Verify** (hallucinations flagged, or needed 3+ fix attempts, or sub-90% confidence): glance at these.
  - **Solid** (&ge;90% confidence, zero hallucinations, compiled cleanly): likely ship-ready.

  Meant for a QA lead to work top-down. Complements `report.md`, which
  stays the per-file diff-detail document.

### Tests

- +3 enum-signature tests (`tests/test_passthrough.py`)
- +7 testid-detection tests (`tests/test_hallucination.py`)
- +8 confidence-gate tests (new `tests/test_confidence_gate.py`)
- +8 review-checklist tests (`tests/test_report.py`)
- Total: 194 -&gt; 220 passing.

## [0.5.1] - 2026-04-18

**Theme: Precision pass after v0.5.0 real-project test.** The v0.5.0
multi-provider run on a real Selenium project came back 14/15 on both
Anthropic and OpenAI. Four concrete failure modes were identified in
that report; this release fixes them.

### Fixed

- **Bug #1 -- Enum files mangled by both providers.** On v0.5.0,
  `Environment.java` (a plain enum with four constants) broke under
  Claude Sonnet (comma separators rewritten as semicolons) AND under
  GPT-4o (constants dropped entirely). Root cause: the
  `generate_playwright_code` tool schema forces
  `(package, imports, class_declaration, fields, constructor, methods)`
  which doesn't fit Java enum syntax. No amount of prompt-hardening
  fixes this -- the fix is to not call the LLM on such files.
  - New `qamigrate.intelligence.passthrough` module detects files that
    are enums / constants classes / DTOs with zero Selenium markers
    (`org.openqa.selenium`, `WebDriver`, `@FindBy`, `PageFactory`,
    `org.testng`, `org.junit`, etc.) and copies them verbatim into
    `playwright/` instead of running them through the Coder.
  - Wired into both the single-file `run_migration` and the batch
    `run_generation` code paths.

- **Bug #2 -- Hallucination detector missed invented CSS selectors.**
  The cross-file detector only checked method calls (e.g.
  `loginPage.getSuccessIndicator()`). Tests that instead invented raw
  selectors (`assertThat(page.locator("#success-indicator"))`) went
  unflagged even though `#success-indicator` didn't exist on any
  declared page-object locator.
  - Added `extract_declared_locators` + `detect_selector_hallucinations`
    in `qamigrate.core.hallucination`.
  - Batch pipeline now catalogues declared selectors per class during
    generation and flags invented ones during finalization, including
    a "did you mean" similarity hint (difflib) when close.
  - Conservative by design: skips bare tag names, `${...}`
    interpolations, and files that don't reference a known page object.

- **Bug #3 -- Coder prompt didn't prefer inherited helpers.**
  Tests extending a `BaseTest` that already exposes `getPage()` were
  being migrated as `DriverManager.getPage().locator(...)` instead of
  `getPage().locator(...)`. Bypassing the inherited helper breaks the
  per-test isolation the base class owns.
  - New prompt requirement #5 in `CoderAgent` spells out the rule.
  - `prompt_context._inherited_helpers_callout` enumerates the parent
    class's zero-arg infra accessors (`Page`, `WebDriver`, `Browser`,
    `BrowserContext`, etc.) when migrating a subclass and tells the
    Coder to call them by name instead of going through DriverManager.

### Verified (no code change)

- **Bug #4 -- pom.xml preservation under `qamigrate init`.**
  End-to-end check on the real `samples/selenium-java-project/pom.xml`
  (203-line pom with 17 comments): XML declaration kept, namespace
  attributes kept, all 17 comments kept, existing deps (selenium,
  testng, extentreports, log4j) intact, Playwright + JUnit 5 added
  cleanly, byte-for-byte idempotent on re-run.

### Tests

- +7 unit tests for passthrough (`tests/test_passthrough.py`)
- +10 unit tests for selector hallucination detection
  (`tests/test_hallucination.py`)
- +4 unit tests for inherited-helpers prompt block
  (`tests/test_prompt_context.py`)
- Total: 173 -> 194 passing.

## [0.5.0] - 2026-04-17

**Theme: Project Intelligence.** QAMigrate is now context-aware. Before
writing a single line of Playwright code, it parses the whole project,
classifies every class by role, detects the conventions the project
consistently follows, builds the cross-class dependency graph, and
captures infrastructure (Log4j2, ExtentReports, TestNG listeners, etc.).
Then when the Coder migrates a file, it sees all of this as prompt
context -- not just the one file in isolation.

### Added -- new intelligence layer

- **`qamigrate.intelligence` package** with:
  - `ProjectMap` data model: classes, roles, edges, conventions, infra
  - `role_inference`: classifies each class as BASE / UTILITY / PAGE /
    TEST / LISTENER / DRIVER_MANAGER / CONFIG / ENUM / OTHER
  - `convention_detector`: detects method chaining, "log every action",
    logger pattern, assertion style, driver access (ThreadLocal vs
    static), implicit-wait usage, explicit-wait helpers, password
    masking, retry analyzer, TestNG `@Listeners`, config override order
  - `dependency_graph`: builds EXTENDS / IMPLEMENTS / INSTANTIATES /
    STATIC_CALL / FIELD_TYPE / IMPORT edges between in-project classes
  - `infrastructure`: deep pom.xml / build.gradle parsing for
    Selenium / Playwright / TestNG / JUnit5 / Log4j2 / ExtentReports
    versions, plus env profiles, Java version, parallel execution
  - `ProjectAnalyzer`: orchestrator that ties all of the above into a
    single `ProjectMap` -- no LLM calls, runs in well under a second
  - `prompt_context.format_project_context()`: renders the map as a
    compact prompt block (~1K tokens for a medium project)

- **New CLI command: `qamigrate analyze`**
  - Produces `architecture.html`, `architecture.md`, and
    `project-map.json` under `./qamigrate-report/`
  - Zero LLM cost -- this is what QAMigrate KNOWS about your project
    before generating any code
  - Consultant-grade doc: classifies every class, lists conventions,
    shows the dependency graph, reports infrastructure

- **Deep Coder context (v0.5 prompt integration)**
  - `CoderAgent.generate_from_class_info(..., project_context=...)`
    now accepts a prompt block
  - `run_project_migration` builds the ProjectMap once in Phase 0 and
    threads it through every file's generation call
  - For the file being migrated, we zoom in on its direct dependencies
    and show the Coder the FULL method bodies of utility/base classes
    (Q3 "deep" design decision). This is what lets the Coder preserve
    `Log.action()` calls, ThreadLocal driver patterns, and the project's
    logging/reporting infrastructure -- instead of generating generic
    Playwright that silently drops those conventions.

### Parser enhancements

- Tree-sitter parser now extracts class / method / field modifiers
  (`public`, `private`, `protected`, `static`, `final`, `abstract`, ...).
  Needed by role inference to distinguish utility classes from page
  objects, and to detect ThreadLocal driver access.

### Validation on the real sample project

`qamigrate analyze samples/selenium-java-project`:
- Correctly classifies all 14 classes by role
- Detects 53 dependency edges
- Detects method_chaining=YES, logs_every_action=YES, driver_access=
  ThreadLocal, parallel_safe=YES, assertion_style=testng, retry_analyzer=
  YES, @Listeners=TestListener, config_override=System.getProperty ->
  properties_file
- Detects Maven / TestNG 7.8.0 / Selenium 4.16.0 / Log4j2 /
  ExtentReports / 3 env profiles / Java 17 / parallel execution enabled

### Tests (173/173, up from 106 in v0.4.2)

- `tests/test_role_inference.py` -- 21 tests
- `tests/test_convention_detector.py` -- 18 tests
- `tests/test_dependency_graph.py` -- 13 tests
- `tests/test_infrastructure_detector.py` -- 15 tests, 7 against the
  real sample project

### Known limitations

- Python Selenium / JavaScript / C# still not supported -- only Java
- Password-masking convention detection fires only for a narrow set of
  masking patterns (true in the current sample but may miss variants)
- The LLM quality comparison between v0.4.x and v0.5.0 hasn't been
  measured on a live run; if you test and see regressions, that's a
  bug report we want to hear

---

## [0.4.2] - 2026-04-16

**Install UX + README honesty pass.** No code changes beyond packaging
metadata and docs.

### Changed
- **One-command install.** `pip install qamigrate` now bundles both the
  Anthropic and OpenAI SDKs. Previously users had to pick between
  `qamigrate` and `qamigrate[openai]` without a clear way to know which
  they needed. The OpenAI SDK is ~2 MB -- small enough that the
  simplicity is worth the bundle.
- `[openai]` and `[all]` extras are kept as no-op aliases so existing
  `requirements.txt` files pinning them still resolve.

### Docs
- **Honest scope statement.** README now clearly says "Selenium (Java)
  -> Playwright (Java) only" as the supported path in v0.4.x. Python
  / JavaScript support is listed on the roadmap (v0.5.x+) instead of
  being implied by the tagline.
- Install section is now one command, not two.

---

## [0.4.1] - 2026-04-16

**Security + audit pass before first 0.4.x upload to PyPI.**

### Added
- **`escape_for_code_fence` helper** in `qamigrate.llm.sanitize`. Used by
  both CoderAgent and FixerAgent before embedding user Java source into
  markdown-fenced prompt blocks. Neutralizes stray triple-backticks so
  Java 15+ text blocks containing ` ``` ` can't break prompt structure
  and confuse the LLM.
- 4 new tests covering the escape helper: clean source unchanged, text
  blocks with markdown neutralized, single-backtick inline code left
  alone, triple-backtick sequences split safely.

### Audit findings (no action needed, documented for the record)
- `yaml.safe_load` used throughout (no `yaml.load` calls).
- No `subprocess.run(..., shell=True)` anywhere; all subprocess calls
  use argv-list form so paths with spaces / special chars are safe.
- No `eval`, `exec`, or `pickle.load` primitives in the source.
- No bare `except:` or `except Exception: pass` blocks.
- API keys never logged. Provider error messages use `str(e)` from the
  SDK, which does not include the key in either Anthropic or OpenAI.
- Generated file paths use `file_path.name` (original filename from
  `rglob`), not any LLM-controlled string -- no path traversal risk.

### Tests: 106/106 pass (was 102 in v0.4.0-unreleased, 79 in v0.3.1).

---

## [0.4.0] - 2026-04-16 (unreleased)

Originally tagged but not pushed to PyPI. v0.4.1 supersedes it with the
security fix above. All v0.4.0 release notes below apply to v0.4.1 as well.



**Theme: Multi-provider LLM support.** QAMigrate is no longer locked to
Anthropic. Run the Coder on Claude, the Fixer on GPT-4o, or switch both
to OpenAI when your Anthropic credits run out. The abstraction is clean
enough to add Ollama / Gemini / Bedrock in a later release with ~6 hours
of work each.

### Added
- **`qamigrate.llm` package** (`base.py`, `errors.py`, `registry.py`,
  `sanitize.py`, `from_config.py`) with the `LLMProvider` abstract
  interface. Every provider honors one contract: `generate_structured`
  takes a system prompt, user prompt, and tool schema -- returns a
  `StructuredResponse` whose `data` field is a dict matching the schema.
- **`AnthropicProvider`** (`qamigrate.llm.providers.anthropic`) -- the
  reference implementation, carrying forward the exact v0.3.x behavior
  so the refactor doesn't change a single byte for existing users.
- **`OpenAIProvider`** (`qamigrate.llm.providers.openai`) -- uses
  `chat.completions.create` with `tools` and forced `tool_choice`.
  Handles base_url override so Azure OpenAI / LM Studio / vLLM / any
  OpenAI-compatible endpoint "just works."
- **Per-agent provider selection.** Your qamigrate.yaml can now say
  `coder.provider: anthropic` and `fixer.provider: openai` so the
  expensive reasoning happens on one model and the cleanup happens on
  a cheaper one. See `qamigrate.yaml.example` for the full shape.
- **CLI overrides** on `qamigrate migrate`:
  `--provider` / `--model` for both agents,
  `--coder-provider` / `--coder-model`,
  `--fixer-provider` / `--fixer-model`. Per-agent flags win.
- **`openai` optional extra** -- `pip install qamigrate[openai]` to pick
  up the OpenAI SDK only when you want it.
- **`FakeProvider`** in `tests/helpers/fake_provider.py` lets us
  exercise the full pipeline without burning credits. Every new
  provider test uses it.

### Changed
- `CoderAgent` and `FixerAgent` accept an `llm_provider: LLMProvider`
  keyword argument. Default behavior is identical to v0.3.x (builds an
  `AnthropicProvider` internally). All previous code calling
  `CoderAgent(config)` keeps working.
- `run_migration`, `run_generation`, and `run_project_migration` now
  build providers from `config` via `build_provider_for_agent`. Public
  signatures unchanged.
- Shared LLM output sanitizers (`unescape_llm_string`, `sanitize_fields`,
  `strip_stray_markdown`) live in `qamigrate.llm.sanitize` so every
  provider benefits. `CoderAgent._sanitize_fields` etc. are preserved as
  back-compat shims.
- Anthropic SDK types no longer leak past the provider boundary. Agents
  never import `anthropic` directly.

### Config schema additions (back-compat)
```yaml
coder:
  provider: anthropic             # NEW; defaults to "anthropic"
  model: claude-sonnet-4-20250514

fixer:
  provider: anthropic             # NEW; defaults to "anthropic"
  model: claude-sonnet-4-20250514

llm:                              # NEW
  providers:
    anthropic:
      api_key_env: ANTHROPIC_API_KEY
    openai:
      api_key_env: OPENAI_API_KEY
      base_url: null              # override for Azure / LM Studio / proxy
    ollama:
      host: http://localhost:11434
      request_timeout_s: 120
```
Existing v0.3.x YAML files load without changes: the new fields default
to sensible values.

### Tests (102/102, up from 79)
- `tests/test_llm_sanitize.py` -- 13 tests for the shared sanitizers
  (move regression coverage).
- `tests/test_llm_integration.py` -- 3 tests proving agents actually
  respect injected providers and handle `LLMUnavailable` cleanly.
- `tests/test_llm_openai.py` -- 7 tests for the OpenAI provider
  (API key handling, tool-call parsing, JSON validation, base_url).

### Known limitations
- Ollama provider (local models) deferred to v0.4.1. The config scaffolding
  is in place; only the provider module itself is missing.
- Gemini, Bedrock, Azure OpenAI (as a distinct provider) deferred.

---

## [0.3.1] - 2026-04-16

**Theme: Polish from the v0.3.0 test report.** Three user-reported issues
plus the three untested surfaces the tester flagged. No new features --
every change makes the existing v0.3.0 flow safer or cheaper.

### Fixed
- **pom.xml preservation (major).** v0.3.0 used ElementTree to write back
  the pom after adding deps, which stripped every `<!-- comment -->` and
  the `<?xml version="1.0"?>` declaration. On a user's 202-line pom.xml
  we collapsed it to 173 lines of noise. v0.3.1 uses surgical text
  insertion: find the `</dependencies>` tag, insert the new
  `<dependency>` blocks right before it, leave everything else
  byte-for-byte identical. Also detects the existing indent of sibling
  `<dependency>` blocks so the new ones fit in seamlessly.
- **Per-file attempt starvation.** In v0.3.0 the project-wide Fixer loop
  tracked a single "no-progress counter" for the whole batch. If most
  files compiled quickly but one (e.g. `Environment.java` in the
  reporter's project) had a stubborn error, the counter hit its limit
  before the stubborn file got its fair share of attempts. v0.3.1 tracks
  progress per file: each file has its own attempt budget (up to
  `pipeline.max_retries`) and its own two-consecutive-no-progress bailout,
  independent of what's happening in sibling files. A "retired" file
  stops consuming attempts while others keep going.
- **Fixer prompt now explicitly covers enum syntax.** The v0.3.0 report
  showed `enum E { A("a"); B("b"); }` -- `;` instead of `,`. Added a
  dedicated bullet to the Fixer system prompt with the correct rule and
  an example.

### Added (polish)
- **Tighter Fixer system prompt to reduce wasted API calls.** v0.3.0
  regularly returned LLM output that started with prose ("Here's the
  fix:") or contained ` ``` ` fences, which our tree-sitter validator
  correctly rejected -- but that rejection burned a tool call. The
  prompt now explicitly says "return the ORIGINAL source unchanged if
  you're not confident the output will parse" and "no markdown fences,
  no prose outside Java comments." We also call out that the output is
  rejected silently when it fails to parse.

### Tests (now 79/79, was 69/69)
- `tests/test_dependency_injector.py::test_preserves_xml_declaration_and_comments`
  -- regression for the pom.xml stripping bug on a realistic pom with 4
  comments, multi-line `<project>` attributes, and the XML declaration.
- `tests/test_dependency_injector.py::test_no_dependencies_block_creates_one`
  -- edge case where the user's pom has no `<dependencies>` yet; we
  create one right before `</project>` without mangling the XML decl.
- `tests/test_dependency_injector.py::test_line_count_grows_predictably`
  -- two added deps add exactly 12 lines (6 lines each), not "the whole
  file reformatted."
- `tests/test_dependency_injector.py::test_idempotent_byte_for_byte` --
  a second `init --yes` leaves the file byte-for-byte identical so
  `git diff` is empty.
- `tests/test_hallucination.py::test_sensitivity_after_real_method_renamed`
  -- the exact scenario the tester asked about: rename a LoginPage
  method, verify the detector flags the test-class call site.
- `tests/test_pipeline_config.py` -- documents that `batch_compile`
  defaults to True, can be toggled via `--no-batch-compile`, and honors
  the `QAMIGRATE_PIPELINE__BATCH_COMPILE` env var.

### End-to-end validation on selenium-java-project
- pom.xml: 202 -> 214 lines (+12 for 2 deps, exactly as expected).
  All 17 `<!-- ... -->` comments preserved. XML declaration preserved.
  Re-running `init --yes` is a no-op; `git diff` is empty.

---

## [0.3.0] - 2026-04-15

**Theme: Whole-project compile.** Single-file compile was the bottleneck --
LoginPage can't compile without BasePage on the classpath, so every
page-object migration was marked FAIL even when the code was correct.
This release fixes that by compiling the whole project together and
resolving the real Maven classpath.

### Result on the reporter's selenium-java-project (15 files)
- v0.2.2: 7/15 at 70%+ confidence, all via skip-compile fallback
- v0.3.0: **14/15 at 100% compiled** (avg confidence 94%) -- twelve
  files compile cleanly on the first try, one file needs two fix
  iterations, one file still fails (isolated compile errors).

### Added
- **`qamigrate init --yes`** auto-injects Playwright 1.48.0 and
  JUnit Jupiter 5.11.3 into the project's `pom.xml` or `build.gradle`.
  Prompts the user without `--yes`. Idempotent -- re-running is a no-op.
  Gradle Groovy DSL supported; Gradle Kotlin DSL deferred to v0.3.1.
- **`qamigrate.agents.dependency_injector.DependencyInjector`** -- the
  module behind `init`. Preserves XML namespaces so pom.xml doesn't end
  up with `ns0:` prefixes.
- **`qamigrate.agents.classpath.ClasspathResolver`** -- shells out to
  `mvn -q dependency:build-classpath` (60s timeout) and caches the
  resolved JARs in `.qamigrate/classpath.txt`. Gradle classpath is
  deferred to v0.3.1.
- **`qamigrate.agents.pipeline.run_project_migration`** -- the new
  project-level pipeline. Three phases:
  1. Generate all files with scanner + coder (no compile-check yet).
  2. Resolve classpath and batch-compile everything with `javac
     -sourcepath ... -cp ...`.
  3. If there are errors, run the Fixer per file (only its own errors,
     never cross-contaminated), recompile, accept only when errors
     strictly reduce. Stop after `pipeline.max_retries` passes or two
     consecutive non-improvements.
- **`CompilerAgent.group_errors_by_file()`** -- helper that buckets a
  batch-compile result's errors by file path.
- **`FixerAgent.fix_file()`** -- wrapper around `fix()` that filters
  the error list to only those matching the file being fixed.
- **`qamigrate migrate --no-batch-compile`** -- escape hatch to fall
  back to the v0.2 per-file compile loop.
- `PipelineConfig.batch_compile` and `ClasspathConfig` sections in
  `qamigrate.yaml`.

### Fixed
- **`CompilerAgent.compile_batch()` tempdir bug** -- subprocess.run was
  outside the `TemporaryDirectory` context manager, meaning the tempdir
  had already been cleaned up before javac tried to use it. Moved the
  run inside the `with` block.
- **Classpath separator** -- was hard-coded to `;` (Windows). Now uses
  `os.pathsep` so batch compilation works on macOS / Linux.
- **Namespace mangling in pom.xml** -- when adding dependencies via
  ElementTree, the Maven namespace was being renamed to `ns0:` in the
  output. `ET.register_namespace("", maven_ns)` fixes it so the file
  looks normal.

### Developer experience
- Added 23 new tests (69/69 total pass):
  - `tests/test_dependency_injector.py` -- pom.xml (empty, existing
    deps, already-present, malformed) + gradle groovy (no block,
    existing block, idempotent) + Kotlin DSL unsupported.
  - `tests/test_classpath.py` -- mocks subprocess for success,
    not-installed, timeout, non-zero exit, cache hit / miss.
  - `tests/test_compiler_batch.py` -- `group_errors_by_file` and the
    empty-list case.
  - `tests/test_fixer.py::TestFixFilePerFileFiltering` -- ensures
    cross-file errors aren't shown to the per-file fixer.

### Known follow-ups
- One file (`Environment.java`) still fails on the reporter's project
  because its errors are unreachable by the Fixer after earlier files
  absorb attempts. The "rolling back" logic is protecting us but the
  file needs its own fix round.
- Gradle classpath resolution (init script or `./gradlew dependencies`
  parser) -- shipping Maven-only for v0.3.0.
- Gradle Kotlin DSL dep injection -- same.
- Incremental recompile for very large projects (currently always
  compiles everything).

---

## [0.2.2] - 2026-04-15

**Theme: Polish based on second user test report.** Three real issues
surfaced after a second round of testing on the user's project. All fixed
and validated end-to-end: 7/15 files at 70%+ confidence (vs 1/15 in
v0.2.1) with zero cross-file method hallucinations in the test class.

### Fixed
- **`\"` escape leak in generated code.** The LLM occasionally emitted
  literal `\"` sequences inside JSON `tool_use` string fields, which then
  landed in the generated Java as `page.locator(\\"#id\\")`. Added a
  sanitization pass at the tool-response parse boundary that unescapes
  `\\n`, `\\t`, `\\"`, and `\\'` from every string field before
  rendering. This was the single highest-ROI fix -- it flips several
  files from FAIL to PASS.
- **Cross-file method hallucinations.** Test classes no longer invent
  methods like `getSuccessIndicator()` or `getErrorElement()` on migrated
  page objects. Strengthened the Coder prompt to explicitly list allowed
  methods and forbid inventing new ones, with specific guidance on
  TestNG -> JUnit 5 annotation translation (`@Test(description="X")` ->
  `@Test` + `@DisplayName("X")` separately).
- **False compile failures when Playwright JAR is missing.** Previously
  the pipeline would burn API calls trying to "fix" `package
  com.microsoft.playwright does not exist` errors that the LLM can't
  resolve. Added classpath-issue detection on the first compile attempt:
  if more than half the errors look like classpath problems (missing
  Playwright package or cannot-find-symbol for Playwright types), the
  pipeline skips compilation validation, marks the file with 70%
  confidence (generated but not verified), and prints a helpful
  `Note:` at the end of the run with the pom.xml snippet to add.

### Added
- **Cross-file hallucination detector** (`qamigrate.core.hallucination`).
  Scans generated code for calls to methods on sibling classes that
  don't exist in those classes' public APIs. Suggests the closest real
  method name when one exists. Hallucinations appear in the console
  summary, the report (HTML/JSON/Markdown), and subtract 10 points each
  from confidence down to a floor of 20.
- **`MigrationRecord.hallucinations: list[Hallucination]`** field in the
  report data model.
- **CLI surfaces classpath issues** with an actionable pom.xml snippet
  when all files skip compilation due to missing Playwright.
- **10 new tests** (47 total) covering the unescape sanitizer, the
  hallucination detector, and confidence penalties.

### Changed
- `CoderAgent._sanitize_fields` is called on every `tool_use` response.
- `MigrationReport` HTML and Markdown outputs include a hallucinations
  section when any are present.
- Confidence scoring factored into two pieces: `_base_confidence()` and
  a hallucination penalty that applies on top.

### Results on the reporter's selenium-java-project (15 files)
- v0.2.1: 1/15 succeeded, 14 FAIL with uncompilable output.
- v0.2.2: 7/15 at 70%+ confidence, 2 fully compiled, remaining 6 failed
  because they reference app-internal classes (`DriverManager`, `Log`,
  `ExtentManager`) that can't be resolved when compiling single files --
  a separate problem to tackle in a later release.

---

## [0.2.1] - 2026-04-15

**Theme: Fix what v0.2.0 broke in real projects.** A user tested on a real
Selenium project and found the compile-fix loop was destructive and `--all`
missed most files. All six reported bugs are fixed.

### Fixed
- **Windows Unicode crash.** `qamigrate init` on Windows crashed with
  `UnicodeEncodeError: '\u2713'` because Rich emits box-drawing characters
  to a `cp1252` stdout. CLI now reconfigures stdout/stderr to UTF-8 on
  startup, and all Unicode glyphs in the CLI output have been replaced
  with ASCII-safe equivalents (`OK`, `FAIL`, `->`, etc.).
- **`--all` only finding `@Test` files.** The file-discovery loop stopped at
  the first directory under `src/` that had Java files, so it would pick
  `src/test/` and miss everything under `src/main/`. Fixed to walk the
  entire project (excluding `target`, `build`, `node_modules`, `playwright`,
  `.git`, `.venv`, `.idea`). Files are now also sorted so base classes and
  page objects are migrated before tests that depend on them.
- **Destructive compile-fix loop.** This was the headline defect: the
  fixer was splicing LLM prose like "Add this import at the top" into
  `.java` files, creating invalid output from valid first-draft code. Two
  changes:
  1. **Fixer rewrite.** The LLM fixer now uses Anthropic tool use
     (`emit_fixed_java` tool) to return the whole corrected file as a
     structured field. It cannot emit free-form text any more. The output
     is validated with tree-sitter before being accepted -- if it contains
     ERROR nodes, no top-level `class_declaration`, or is implausibly
     short, the fix is rejected.
  2. **Non-regressing pipeline.** The pipeline now tracks the best version
     seen so far (fewest errors). If a fix attempt produces more errors
     than the previous best, the pipeline rolls back to the best version.
     After two consecutive non-improvements, the loop stops early and
     keeps the best output. You no longer get degraded garbage after
     starting with working code.
- **Cross-file context.** When migrating a test class that imports a
  sibling page object, the Coder now receives the signatures of the
  already-migrated Playwright version of that sibling. The test class
  calls `new LoginPage(page)` (the real Playwright constructor) instead
  of inventing method names.
- **Confidence scoring.** The old scale gave 0 or 100 with almost no
  middle ground. Rewritten to 0-100 with honest tiers: 100 (first-try
  compile), 90 (1-2 fixes), 80 (many fixes), 70 (skipped compile),
  50 (didn't compile but output exists for review), 0 (no output).
- **Hours-saved metric.** Was counting every detected pattern, including
  from failed migrations. Now only counts patterns from files with
  confidence >= 70 -- if we didn't actually migrate the file, we don't
  claim credit for saving you time on it.
- **Escaped newlines in generated constructors.** LLM tool_use output
  occasionally contained literal `\n` (backslash-n, two chars) instead of
  real newlines, collapsing the constructor onto a single unreadable
  line. The reindenter now detects and unescapes this.

### Changed
- `FixerAgent` now returns the ORIGINAL code unchanged when no strategy
  worked, instead of returning half-applied partial fixes.
- Pipeline always fixes from the best version seen so far, not from
  whatever drifted version is currently on disk.
- CLI prints `[OK]`/`[FAIL]` tags instead of `OK`/`FAIL` for consistency.
- README has accurate output examples and honest confidence language.

### Removed
- `cli/main.py`: Unicode glyphs (check, cross, warning, rocket, chart,
  star, magnifying glass) replaced with ASCII.
- `reports.py` constants that referenced removed modules.

### Added
- `MigrationResult.class_name` and `MigrationResult.generated_signatures`
  so callers can thread context between files.
- `CoderAgent.extract_signatures()` helper.
- `CoderAgent.generate_from_class_info(..., sibling_signatures=...)`
  parameter.
- `run_migration(..., sibling_signatures=...)` parameter.
- `tests/test_fixer.py` with 8 new tests covering validation, markdown
  stripping, and escaped-newline handling.
- 8 more tests total (26 -> 34). All pass.

### Developer experience
- Removed stale dependency chain that referenced deleted modules.
- Fixed XML-element truthiness warning in scanner.
- `qamigrate --version` reports 0.2.1.

---

## [0.2.0] - 2026-04-15

**Theme: Trust & Evidence.** You no longer just get migrated code — you get proof of what changed, how confident we are, and how much time you saved.

### Added
- **Migration Report** in three formats: HTML, JSON, and Markdown
  - Per-file records with detected patterns, confidence score, compilation status, and before/after diff
  - Batch-level metrics: files succeeded/failed, patterns handled, average confidence, estimated hours saved
  - HTML report includes side-by-side diff viewer (stdlib `difflib`) with dark theme
- **`--dry-run` flag** on `qamigrate migrate`: scan all target files and preview patterns without calling the LLM or writing output
- **`--report <dir>` flag** on `qamigrate migrate`: writes `report.html`, `report.json`, `report.md` to the specified directory
- **`compiler.skip`** config option: skip compilation validation when Playwright JARs aren't available locally
- **Confidence scoring** per file (0-100) derived from success + compilation attempts
- **Time-saved estimate** based on ~15 min of manual effort per pattern

### Changed
- Simplified pipeline: `SupervisorConfig` renamed to `PipelineConfig`
- `QAMigrateConfig` now uses `pipeline.max_retries` instead of `supervisor.max_retries`
- `run_migration()` now returns a `MigrationResult` with an attached `MigrationRecord`
- CLI `migrate` command output: per-file status with confidence score, summary table with batch metrics

### Removed
- Dead modules: `supervisor.py`, `visual.py`, `utom.py`, `test_cleanup.py`, `languages.py`, `pdf_reports.py`, `dependencies.py`, `parallel.py`, `security.py`, `reports.py`, `database.py`, `integrations/jira_client.py`, `cli/interactive.py`
- Old web server (`server/`) and React dashboard (`dashboard/`) — will return in v0.3.0 once backed by the new report format
- CLI commands: `verify` (visual agent was mocked), `export` (superseded by `migrate --report`), `dashboard` (temporarily removed)
- Unused config sections: `visual`, `docker`, `server`, `quality_gates`
- Unused dependencies: `httpx`, `email-validator`, `fastapi`, `uvicorn`, `websockets`, `docker`, `opencv-python`, `pillow`, `imagehash`, `numpy`, `openai`

### Fixed
- `datetime.utcnow()` deprecation warnings on Python 3.12+ (now using `datetime.now(timezone.utc)`)
- Maven `pom.xml` element truthiness deprecation warnings in scanner
- CLI `--all` no longer requires the optional `DependencyAnalyzer` — walks `src/test` then `src/` directly

### Developer experience
- Added `tests/test_report.py` (13 new tests covering report rendering and confidence scoring)
- All 25 tests pass with no warnings

---

## [0.1.0] - 2026-04-14

### Added
- Initial release.
- Selenium Java -> Playwright Java migration pipeline:
  - **Scanner** (Tree-sitter, 70+ pattern queries)
  - **Coder** (Claude tool use for structured output)
  - **Compiler** (javac validation)
  - **Fixer** (rule-based + LLM error remediation with up to 3 retries)
- CLI commands: `init`, `scan`, `migrate`
- Validated end-to-end on real Selenium files covering `@FindBy`, `PageFactory`, `WebDriverWait`, `Actions`, `Select`, alerts, iframes, `JavascriptExecutor`, file uploads, TestNG inheritance, and `@DataProvider`.
