from __future__ import annotations


class Intents(int):
    GUILDS = 1 << 0
    GUILD_MEMBERS = 1 << 1
    GUILD_MODERATION = 1 << 2
    GUILD_EMOJIS_AND_STICKERS = 1 << 3
    GUILD_INTEGRATIONS = 1 << 4
    GUILD_WEBHOOKS = 1 << 5
    GUILD_INVITES = 1 << 6
    GUILD_VOICE_STATES = 1 << 7
    GUILD_PRESENCES = 1 << 8
    GUILD_MESSAGES = 1 << 9
    GUILD_MESSAGE_REACTIONS = 1 << 10
    GUILD_MESSAGE_TYPING = 1 << 11
    DIRECT_MESSAGES = 1 << 12
    DIRECT_MESSAGE_REACTIONS = 1 << 13
    DIRECT_MESSAGE_TYPING = 1 << 14
    MESSAGE_CONTENT = 1 << 15
    GUILD_SCHEDULED_EVENTS = 1 << 16
    AUTO_MODERATION_CONFIGURATION = 1 << 20
    AUTO_MODERATION_EXECUTION = 1 << 21
    GUILD_MESSAGE_POLLS = 1 << 24
    DIRECT_MESSAGE_POLLS = 1 << 25

    DEFAULT_VALUE = GUILDS | GUILD_MESSAGES | DIRECT_MESSAGES | MESSAGE_CONTENT
    ALL_VALUE = (
        GUILDS
        | GUILD_MEMBERS
        | GUILD_MODERATION
        | GUILD_EMOJIS_AND_STICKERS
        | GUILD_INTEGRATIONS
        | GUILD_WEBHOOKS
        | GUILD_INVITES
        | GUILD_VOICE_STATES
        | GUILD_PRESENCES
        | GUILD_MESSAGES
        | GUILD_MESSAGE_REACTIONS
        | GUILD_MESSAGE_TYPING
        | DIRECT_MESSAGES
        | DIRECT_MESSAGE_REACTIONS
        | DIRECT_MESSAGE_TYPING
        | MESSAGE_CONTENT
        | GUILD_SCHEDULED_EVENTS
        | AUTO_MODERATION_CONFIGURATION
        | AUTO_MODERATION_EXECUTION
        | GUILD_MESSAGE_POLLS
        | DIRECT_MESSAGE_POLLS
    )

    @classmethod
    def default(cls) -> "Intents":
        return cls(cls.DEFAULT_VALUE)

    @classmethod
    def all(cls) -> "Intents":
        return cls(cls.ALL_VALUE)

    @classmethod
    def none(cls) -> "Intents":
        return cls(0)

    @classmethod
    def from_names(cls, *names: str) -> "Intents":
        value = 0
        for name in names:
            value |= int(getattr(cls, name))
        return cls(value)

    def has(self, intent: int) -> bool:
        return bool(int(self) & int(intent))

    def add(self, *intents: int) -> "Intents":
        value = int(self)
        for intent in intents:
            value |= int(intent)
        return Intents(value)

    def remove(self, *intents: int) -> "Intents":
        value = int(self)
        for intent in intents:
            value &= ~int(intent)
        return Intents(value)
