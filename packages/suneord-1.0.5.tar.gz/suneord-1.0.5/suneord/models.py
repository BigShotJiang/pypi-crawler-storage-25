from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


class Color:
    # Существующие
    RED = 0xED4245
    GREEN = 0x57F287
    BLUE = 0x5865F2
    YELLOW = 0xFEE75C
    BLURPLE = 0x5865F2
    WHITE = 0xFFFFFF
    BLACK = 0x000000
    ORANGE = 0xFAA61A
    FUCHSIA = 0xEB459E
    AQUA = 0x1ABC9C
    GRAY = 0x95A5A6
    GOLD = 0xF1C40F         
    DARK_GOLD = 0xC27C0E     
    LIGHT_GREEN = 0x2ECC71   
    DARK_GREEN = 0x1F8B4C    
    LIGHT_BLUE = 0x3498DB  
    DARK_BLUE = 0x206694    
    PURPLE = 0x9B59B6     
    DARK_PURPLE = 0x71368A  
    PINK = 0xE91E63      
    DARK_PINK = 0xAD1457    
    CYAN = 0x00BCD4     
    TEAL = 0x1ABC9C        
    LIME = 0x00FF00        
    INDIGO = 0x4B0082     
    VIOLET = 0xEE82EE  
    BROWN = 0x8B4513     
    DARK_BROWN = 0x5D4037   
    SILVER = 0xC0C0C0     
    DARK_GRAY = 0x607D8B 
    LIGHT_GRAY = 0xB0BEC5   
    NAVY = 0x000080   
    MAROON = 0x800000        
    OLIVE = 0x808000       
    CORAL = 0xFF6B6B       
    SALMON = 0xFA8072     
    MINT = 0x98FB98        
    LAVENDER = 0xE6E6FA     
    PEACH = 0xFFDAB9        
    SKY_BLUE = 0x87CEEB    
    TURQUOISE = 0x40E0D0     
    EMERALD = 0x50C878      
    RUBY = 0xE0115F          
    SAPPHIRE = 0x0F52BA     
    AMBER = 0xFFBF00   
    CRIMSON = 0xDC143C     
    TOMATO = 0xFF6347        
    CHOCOLATE = 0xD2691E     
    KHAKI = 0xF0E68C       
    PLUM = 0xDDA0DD          
    ORCHID = 0xDA70D6       
    STEEL_BLUE = 0x4682B4    
    ROYAL_BLUE = 0x4169E1   
    DODGER_BLUE = 0x1E90FF  
    DEEP_SKY_BLUE = 0x00BFFF 
    SPRING_GREEN = 0x00FF7F  
    MEDIUM_SPRING_GREEN = 0x00FA9A 
    SEA_GREEN = 0x2E8B57    
    FOREST_GREEN = 0x228B22 
    DARK_SLATE_GRAY = 0x2F4F4F 
    DIM_GRAY = 0x696969     
    INDIAN_RED = 0xCD5C5C    
    FIREBRICK = 0xB22222    
    DARK_RED = 0x8B0000     
    HOT_PINK = 0xFF69B4    
    DEEP_PINK = 0xFF1493   
    MEDIUM_VIOLET_RED = 0xC71585  
    MAGENTA = 0xFF00FF     
    SLATE_BLUE = 0x6A5ACD  
    MEDIUM_SLATE_BLUE = 0x7B68EE 
    DARK_ORCHID = 0x9932CC  
    DARK_VIOLET = 0x9400D3 
    BLUE_VIOLET = 0x8A2BE2  
    MEDIUM_PURPLE = 0x9370DB 
    SADDLE_BROWN = 0x8B4513  
    SIENNA = 0xA0522D  
    PERU = 0xCD853F       
    BURLYWOOD = 0xDEB887   
    WHEAT = 0xF5DEB3       
    TAN = 0xD2B48C       
    ROSY_BROWN = 0xBC8F8F    
    LIGHT_CORAL = 0xF08080  
    

@dataclass(slots=True)
class Embed:
    title: str | None = None
    description: str | None = None
    url: str | None = None
    color: int | None = None
    timestamp: str | None = None
    fields: list[dict[str, Any]] = field(default_factory=list)
    author: dict[str, Any] | None = None
    thumbnail: dict[str, Any] | None = None
    image: dict[str, Any] | None = None
    footer: dict[str, Any] | None = None

    def set_title(self, value: str | None) -> "Embed":
        self.title = value
        return self

    def set_description(self, value: str | None) -> "Embed":
        self.description = value
        return self

    def set_color(self, value: int | None) -> "Embed":
        self.color = value
        return self

    def set_url(self, value: str | None) -> "Embed":
        self.url = value
        return self

    def add_field(self, *, name: str, value: str, inline: bool = False) -> "Embed":
        self.fields.append({"name": name, "value": value, "inline": inline})
        return self

    def remove_field(self, index: int) -> "Embed":
        self.fields.pop(index)
        return self

    def clear_fields(self) -> "Embed":
        self.fields.clear()
        return self

    def set_author(
        self,
        *,
        name: str,
        url: str | None = None,
        icon_url: str | None = None,
    ) -> "Embed":
        author = {"name": name}
        if url is not None:
            author["url"] = url
        if icon_url is not None:
            author["icon_url"] = icon_url
        self.author = author
        return self

    def set_thumbnail(self, *, url: str) -> "Embed":
        self.thumbnail = {"url": url}
        return self

    def set_image(self, *, url: str) -> "Embed":
        self.image = {"url": url}
        return self

    def set_footer(self, *, text: str, icon_url: str | None = None) -> "Embed":
        footer = {"text": text}
        if icon_url is not None:
            footer["icon_url"] = icon_url
        self.footer = footer
        return self

    def set_timestamp(self, value: datetime | None = None) -> "Embed":
        timestamp = value or datetime.now(timezone.utc)
        self.timestamp = timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        return self

    def copy(self) -> "Embed":
        return Embed.from_dict(self.to_dict())

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "Embed":
        return cls(
            title=payload.get("title"),
            description=payload.get("description"),
            url=payload.get("url"),
            color=payload.get("color"),
            timestamp=payload.get("timestamp"),
            fields=list(payload.get("fields", [])),
            author=payload.get("author"),
            thumbnail=payload.get("thumbnail"),
            image=payload.get("image"),
            footer=payload.get("footer"),
        )

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if self.title is not None:
            payload["title"] = self.title
        if self.description is not None:
            payload["description"] = self.description
        if self.url is not None:
            payload["url"] = self.url
        if self.color is not None:
            payload["color"] = self.color
        if self.timestamp is not None:
            payload["timestamp"] = self.timestamp
        if self.fields:
            payload["fields"] = self.fields
        if self.author is not None:
            payload["author"] = self.author
        if self.thumbnail is not None:
            payload["thumbnail"] = self.thumbnail
        if self.image is not None:
            payload["image"] = self.image
        if self.footer is not None:
            payload["footer"] = self.footer
        return payload
