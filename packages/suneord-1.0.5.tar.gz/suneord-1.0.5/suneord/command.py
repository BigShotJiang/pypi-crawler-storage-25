from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Iterable, Optional


Callback = Callable[..., Awaitable[None]]
CheckCallback = Callable[..., bool | Awaitable[bool]]


class CommandError(Exception):
    pass


class CheckFailure(CommandError):
    pass


class DisabledCommand(CommandError):
    pass


class MemberNotMuted(CommandError):
    pass


class CommandOnCooldown(CommandError):
    def __init__(self, retry_after: float) -> None:
        self.retry_after = retry_after
        super().__init__(f"Command is on cooldown for {retry_after:.2f}s")


class OptionType:
    SUB_COMMAND = 1
    SUB_COMMAND_GROUP = 2
    STRING = 3
    INTEGER = 4
    BOOLEAN = 5
    USER = 6
    CHANNEL = 7
    ROLE = 8
    MENTIONABLE = 9
    NUMBER = 10
    ATTACHMENT = 11


@dataclass(slots=True)
class SlashOption:
    name: str
    description: str
    type: int = OptionType.STRING
    required: bool = False
    autocomplete: bool = False
    choices: list[dict[str, Any]] = field(default_factory=list)
    min_value: int | float | None = None
    max_value: int | float | None = None
    min_length: int | None = None
    max_length: int | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "type": self.type,
            "required": self.required,
            "autocomplete": self.autocomplete,
        }
        if self.choices:
            payload["choices"] = self.choices
        if self.min_value is not None:
            payload["min_value"] = self.min_value
        if self.max_value is not None:
            payload["max_value"] = self.max_value
        if self.min_length is not None:
            payload["min_length"] = self.min_length
        if self.max_length is not None:
            payload["max_length"] = self.max_length
        return payload


@dataclass(slots=True)
class Command:
    name: str
    callback: Callback
    description: str = "No description provided."
    aliases: tuple[str, ...] = ()
    usage: str | None = None
    cooldown: float | None = None
    checks: tuple[CheckCallback, ...] = ()
    enabled: bool = True
    hidden: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
    _cooldowns: dict[int, float] = field(default_factory=dict, repr=False)

    @property
    def all_names(self) -> tuple[str, ...]:
        return (self.name, *self.aliases)

    def get_retry_after(self, bucket_id: int) -> float:
        if self.cooldown is None:
            return 0.0
        expires_at = self._cooldowns.get(bucket_id, 0.0)
        retry_after = expires_at - time.monotonic()
        return retry_after if retry_after > 0 else 0.0

    def is_on_cooldown(self, bucket_id: int) -> bool:
        return self.get_retry_after(bucket_id) > 0

    def update_cooldown(self, bucket_id: int) -> None:
        if self.cooldown is None:
            return
        self._cooldowns[bucket_id] = time.monotonic() + self.cooldown

    def reset_cooldown(self, bucket_id: int) -> None:
        self._cooldowns.pop(bucket_id, None)


@dataclass(slots=True)
class SlashCommand:
    name: str
    callback: Callback
    description: str
    options: tuple[SlashOption, ...] = ()
    guild_id: Optional[int] = None
    dm_permission: bool = True
    default_member_permissions: str | None = None
    nsfw: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "type": 1,
        }
        if self.options:
            payload["options"] = [option.to_dict() for option in self.options]
        if self.dm_permission is not None:
            payload["dm_permission"] = self.dm_permission
        if self.default_member_permissions is not None:
            payload["default_member_permissions"] = self.default_member_permissions
        if self.nsfw:
            payload["nsfw"] = True
        return payload


class Cog:
    def __init__(self, bot: Any | None = None) -> None:
        self.bot = bot

    @property
    def cog_name(self) -> str:
        return self.__class__.__name__

    @staticmethod
    def listener(name: str | None = None) -> Callable[[Callback], Callback]:
        def decorator(callback: Callback) -> Callback:
            callback.__suneord_listener__ = name or callback.__name__
            return callback

        return decorator


def normalize_aliases(*aliases: str, aliases_value: str | Iterable[str] | None = None) -> tuple[str, ...]:
    collected: list[str] = []
    for alias in aliases:
        if alias:
            collected.append(str(alias))
    if aliases_value is None:
        return tuple(collected)
    if isinstance(aliases_value, str):
        collected.append(aliases_value)
        return tuple(collected)
    for alias in aliases_value:
        if alias:
            collected.append(str(alias))
    return tuple(collected)


def command(
    *alias_args: str,
    name: str | None = None,
    description: str = "No description provided.",
    aliases: str | Iterable[str] | None = None,
    usage: str | None = None,
    cooldown: float | None = None,
    checks: Iterable[CheckCallback] | None = None,
    hidden: bool = False,
    enabled: bool = True,
    **metadata: Any,
) -> Callable[[Callback], Callback]:
    def decorator(callback: Callback) -> Callback:
        callback.__suneord_command__ = {
            "name": name or callback.__name__,
            "description": description,
            "aliases": normalize_aliases(*alias_args, aliases_value=aliases),
            "usage": usage,
            "cooldown": cooldown,
            "checks": tuple(checks or ()),
            "hidden": hidden,
            "enabled": enabled,
            "metadata": metadata,
        }
        return callback

    return decorator


def slash_command(
    *,
    name: str,
    description: str,
    options: Iterable[SlashOption] | None = None,
    guild_id: int | None = None,
    dm_permission: bool = True,
    default_member_permissions: int | str | None = None,
    nsfw: bool = False,
    **metadata: Any,
) -> Callable[[Callback], Callback]:
    def decorator(callback: Callback) -> Callback:
        callback.__suneord_slash_command__ = {
            "name": name,
            "description": description,
            "options": tuple(options or ()),
            "guild_id": guild_id,
            "dm_permission": dm_permission,
            "default_member_permissions": (
                str(default_member_permissions)
                if default_member_permissions is not None
                else None
            ),
            "nsfw": nsfw,
            "metadata": metadata,
        }
        return callback

    return decorator
