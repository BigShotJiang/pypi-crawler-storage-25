from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse

import aiohttp

from .models import Embed

OEMBED_URL = "https://soundcloud.com/oembed"
API_V2_BASE = "https://api-v2.soundcloud.com"


class SoundCloudError(Exception):
    """Базовая ошибка клиента SoundCloud."""


class SoundCloudHTTPError(SoundCloudError):
    def __init__(self, status: int, message: str) -> None:
        self.status = status
        super().__init__(message)


def format_duration_ms(duration_ms: int | None) -> str | None:
    if duration_ms is None or duration_ms < 0:
        return None
    total_seconds = duration_ms // 1000
    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"


def _player_api_track_url(embed_html: str | None) -> str | None:
    if not embed_html:
        return None
    # iframe src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/ID..."
    marker = 'src="'
    start = embed_html.find(marker)
    if start == -1:
        return None
    start += len(marker)
    end = embed_html.find('"', start)
    if end == -1:
        return None
    iframe_src = embed_html[start:end]
    parsed = urlparse(iframe_src)
    qs = parse_qs(parsed.query)
    urls = qs.get("url")
    if not urls:
        return None
    return unquote(urls[0])


@dataclass(slots=True)
class SoundCloudTrack:
    """Метаданные трека: oEmbed и (опционально) ответ resolve API v2."""

    source_url: str
    title: str
    author_name: str
    author_url: str
    thumbnail_url: str | None
    embed_html: str | None
    oembed_type: str
    duration_ms: int | None = None
    track_id: int | None = None
    permalink_url: str | None = None
    streamable: bool | None = None
    waveform_url: str | None = None
    description: str | None = None
    playback_count: int | None = None
    likes_count: int | None = None
    genre: str | None = None
    tag_list: str | None = None

    @property
    def public_url(self) -> str:
        return self.permalink_url or self.source_url

    @property
    def api_track_url(self) -> str | None:
        return _player_api_track_url(self.embed_html)

    def to_embed(self, *, color: int | None = None) -> Embed:
        """Собирает `Embed` для отправки в Discord."""
        col = color if color is not None else 0xFF5500
        duration = format_duration_ms(self.duration_ms)
        embed = Embed(
            title=self.title[:256] if self.title else "SoundCloud",
            url=self.public_url[:2048] if self.public_url else None,
            color=col,
        )
        embed.set_author(name=self.author_name[:256], url=self.author_url[:2048] if self.author_url else None)
        if self.thumbnail_url:
            embed.set_thumbnail(url=self.thumbnail_url[:2048])
        lines: list[str] = []
        if duration:
            lines.append(f"Длительность: **{duration}**")
        if self.genre:
            lines.append(f"Жанр: **{self.genre}**")
        if self.playback_count is not None:
            lines.append(f"Прослушиваний: **{self.playback_count}**")
        if self.likes_count is not None:
            lines.append(f"Лайков: **{self.likes_count}**")
        if self.description:
            desc = self.description.strip().replace("\r\n", "\n")
            if len(desc) > 350:
                desc = desc[:347] + "..."
            lines.append(desc)
        if lines:
            embed.set_description("\n".join(lines))
        footer_bits: list[str] = ["SoundCloud"]
        if self.track_id is not None:
            footer_bits.append(f"id {self.track_id}")
        embed.set_footer(text=" · ".join(footer_bits))
        return embed


@dataclass(slots=True)
class SoundCloudSearchHit:
    """Элемент выдачи поиска треков (API v2)."""

    track_id: int
    title: str
    permalink_url: str
    author_name: str
    author_permalink_url: str | None
    duration_ms: int | None
    artwork_url: str | None
    playback_count: int | None
    likes_count: int | None

    def to_embed(self, *, color: int | None = None) -> Embed:
        col = color if color is not None else 0xFF5500
        duration = format_duration_ms(self.duration_ms)
        embed = Embed(title=self.title[:256], url=self.permalink_url[:2048], color=col)
        author_url = self.author_permalink_url
        embed.set_author(
            name=self.author_name[:256],
            url=author_url[:2048] if author_url else None,
        )
        if self.artwork_url:
            embed.set_thumbnail(url=self.artwork_url.replace("-large", "-t500x500")[:2048])
        parts: list[str] = []
        if duration:
            parts.append(f"**{duration}**")
        if self.playback_count is not None:
            parts.append(f"▶ {self.playback_count}")
        if self.likes_count is not None:
            parts.append(f"♥ {self.likes_count}")
        if parts:
            embed.set_description(" · ".join(parts))
        embed.set_footer(text="SoundCloud · поиск")
        return embed


def _track_from_oembed(source_url: str, payload: dict[str, Any]) -> SoundCloudTrack:
    return SoundCloudTrack(
        source_url=source_url,
        title=str(payload.get("title") or ""),
        author_name=str(payload.get("author_name") or ""),
        author_url=str(payload.get("author_url") or ""),
        thumbnail_url=payload.get("thumbnail_url"),
        embed_html=payload.get("html"),
        oembed_type=str(payload.get("type") or ""),
    )


def _merge_resolve(track: SoundCloudTrack, data: dict[str, Any]) -> SoundCloudTrack:
    user = data.get("user") or {}
    author_name = str(user.get("username") or track.author_name)
    author_url = str(user.get("permalink_url") or track.author_url)
    artwork = data.get("artwork_url") or track.thumbnail_url
    duration = data.get("duration")
    duration_ms = int(duration) if isinstance(duration, (int, float)) else track.duration_ms
    tid = data.get("id")
    track_id = int(tid) if isinstance(tid, (int, float)) else track.track_id
    streamable = data.get("streamable")
    stream_b = bool(streamable) if streamable is not None else track.streamable
    permalink = data.get("permalink_url")
    permalink_url = str(permalink) if permalink else track.permalink_url
    description = data.get("description")
    desc = str(description) if description is not None else track.description
    waveform = data.get("waveform_url")
    wv = str(waveform) if waveform else track.waveform_url
    pb = data.get("playback_count")
    playback = int(pb) if isinstance(pb, (int, float)) else track.playback_count
    lk = data.get("likes_count")
    likes = int(lk) if isinstance(lk, (int, float)) else track.likes_count
    genre = data.get("genre")
    genre_s = str(genre) if genre else track.genre
    tags = data.get("tag_list")
    tags_s = str(tags) if tags else track.tag_list
    title = str(data.get("title") or track.title)
    return SoundCloudTrack(
        source_url=track.source_url,
        title=title,
        author_name=author_name,
        author_url=author_url,
        thumbnail_url=artwork,
        embed_html=track.embed_html,
        oembed_type=track.oembed_type,
        duration_ms=duration_ms,
        track_id=track_id,
        permalink_url=permalink_url,
        streamable=stream_b,
        waveform_url=wv,
        description=desc,
        playback_count=playback,
        likes_count=likes,
        genre=genre_s,
        tag_list=tags_s,
    )


def _search_hit_from_api(item: dict[str, Any]) -> SoundCloudSearchHit | None:
    tid = item.get("id")
    if not isinstance(tid, (int, float)):
        return None
    user = item.get("user") or {}
    author = str(user.get("username") or "")
    author_link = user.get("permalink_url")
    author_link_s = str(author_link) if author_link else None
    title = str(item.get("title") or "")
    pl = item.get("permalink_url")
    if not pl:
        return None
    permalink_url = str(pl)
    duration = item.get("duration")
    duration_ms = int(duration) if isinstance(duration, (int, float)) else None
    art = item.get("artwork_url")
    artwork = str(art) if art else None
    pb = item.get("playback_count")
    playback = int(pb) if isinstance(pb, (int, float)) else None
    lk = item.get("likes_count")
    likes = int(lk) if isinstance(lk, (int, float)) else None
    return SoundCloudSearchHit(
        track_id=int(tid),
        title=title,
        permalink_url=permalink_url,
        author_name=author,
        author_permalink_url=author_link_s,
        duration_ms=duration_ms,
        artwork_url=artwork,
        playback_count=playback,
        likes_count=likes,
    )


class SoundCloudClient:
    """
    Асинхронный клиент SoundCloud на `aiohttp`.

    **Без `client_id`:** доступен только публичный oEmbed (метаданные и превью).

    **С `client_id`:** resolve и поиск по API v2 (ключ берут из веб-клиента SoundCloud;
    храните его в переменной окружения и не публикуйте в репозиторий).
    """

    def __init__(
        self,
        *,
        session: aiohttp.ClientSession | None = None,
        client_id: str | None = None,
        timeout: aiohttp.ClientTimeout | None = None,
    ) -> None:
        self._external_session = session
        self._session: aiohttp.ClientSession | None = session
        self._owns_session = session is None
        self.client_id = client_id
        self._timeout = timeout or aiohttp.ClientTimeout(total=20)

    async def __aenter__(self) -> SoundCloudClient:
        await self._ensure_session()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            self._session = aiohttp.ClientSession(timeout=self._timeout)
            self._owns_session = self._external_session is None
        return self._session

    async def close(self) -> None:
        if self._owns_session and self._session is not None:
            await self._session.close()
        self._session = None

    async def _request_json(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        session = await self._ensure_session()
        async with session.request(method, url, params=params, headers=headers) as response:
            text = await response.text()
            if response.status >= 400:
                raise SoundCloudHTTPError(response.status, text[:500])
            if "application/json" in (response.headers.get("Content-Type") or ""):
                return json.loads(text)
            return text

    async def fetch_oembed(self, url: str) -> dict[str, Any]:
        """Сырой JSON oEmbed для любой поддерживаемой ссылки SoundCloud."""
        session = await self._ensure_session()
        async with session.get(
            OEMBED_URL,
            params={"format": "json", "url": url},
            headers={"Accept": "application/json"},
        ) as response:
            text = await response.text()
            if response.status >= 400:
                raise SoundCloudHTTPError(response.status, text[:500])
            return json.loads(text)

    async def fetch_track(self, url: str) -> SoundCloudTrack:
        """Метаданные трека/плейлиста по ссылке через oEmbed (без `client_id`)."""
        payload = await self.fetch_oembed(url)
        return _track_from_oembed(url, payload)

    async def resolve(self, url: str, client_id: str | None = None) -> dict[str, Any]:
        """
        Полный JSON объекта SoundCloud по ссылке (API v2).

        Для плейлиста `kind` будет `playlist`, для трека — `track`.
        """
        cid = client_id or self.client_id
        if not cid:
            raise SoundCloudError("Нужен client_id для resolve (передайте в конструктор или в вызов).")
        params = {"url": url, "client_id": cid}
        return await self._request_json("GET", f"{API_V2_BASE}/resolve", params=params)

    async def fetch_track_detailed(self, url: str, client_id: str | None = None) -> SoundCloudTrack:
        """oEmbed + resolve для трека: длительность, счётчики, permalink, обложка."""
        base = await self.fetch_track(url)
        cid = client_id or self.client_id
        if not cid:
            return base
        data = await self.resolve(url, cid)
        kind = str(data.get("kind") or "")
        if kind != "track":
            raise SoundCloudError(f"Ожидался track, получено: {kind or 'unknown'}")
        return _merge_resolve(base, data)

    async def search_tracks(
        self,
        query: str,
        *,
        client_id: str | None = None,
        limit: int = 10,
    ) -> list[SoundCloudSearchHit]:
        """Поиск треков (требуется `client_id`)."""
        cid = client_id or self.client_id
        if not cid:
            raise SoundCloudError("Нужен client_id для search_tracks.")
        limit = max(1, min(int(limit), 50))
        params: dict[str, Any] = {
            "q": query,
            "client_id": cid,
            "limit": limit,
            "app_locale": "en",
        }
        data = await self._request_json("GET", f"{API_V2_BASE}/search/tracks", params=params)
        collection = data.get("collection")
        if not isinstance(collection, list):
            return []
        out: list[SoundCloudSearchHit] = []
        for item in collection:
            if isinstance(item, dict):
                hit = _search_hit_from_api(item)
                if hit is not None:
                    out.append(hit)
        return out

    async def stream_transcoding_urls(
        self,
        track: SoundCloudTrack,
        *,
        client_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Список транскодингов (HLS/opus и т.д.) для трека.

        Нужен `track_id` и `client_id`. Возвращает элементы с полями `url`, `preset`, `snipped`, `format`.
        Дальнейшая загрузка потока — по ссылке из `url` (часто отдельный JSON с `url` внутри).
        """
        cid = client_id or self.client_id
        if not cid:
            raise SoundCloudError("Нужен client_id для stream_transcoding_urls.")
        tid = track.track_id
        if tid is None:
            raise SoundCloudError("У трека нет track_id — сначала вызовите fetch_track_detailed.")
        progress = await self._request_json(
            "GET",
            f"{API_V2_BASE}/tracks/{tid}",
            params={"client_id": cid},
        )
        if not isinstance(progress, dict):
            return []
        media = progress.get("media") or {}
        trans = media.get("transcodings")
        if not isinstance(trans, list):
            return []
        return [t for t in trans if isinstance(t, dict)]


__all__ = [
    "API_V2_BASE",
    "OEMBED_URL",
    "SoundCloudClient",
    "SoundCloudError",
    "SoundCloudHTTPError",
    "SoundCloudSearchHit",
    "SoundCloudTrack",
    "format_duration_ms",
]
