from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

ModalCallback = Callable[..., Any]

MAX_MODAL_TEXT_INPUTS = 5
MAX_MODAL_TITLE_LENGTH = 45


class TextInputStyle:
    SHORT = 1
    PARAGRAPH = 2


@dataclass(slots=True)
class TextInput:
    custom_id: str
    label: str
    style: int = TextInputStyle.SHORT
    placeholder: str | None = None
    value: str | None = None
    required: bool = True
    min_length: int | None = None
    max_length: int | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "type": 4,
            "custom_id": self.custom_id,
            "label": self.label,
            "style": self.style,
            "required": self.required,
        }
        if self.placeholder is not None:
            payload["placeholder"] = self.placeholder
        if self.value is not None:
            payload["value"] = self.value
        if self.min_length is not None:
            payload["min_length"] = self.min_length
        if self.max_length is not None:
            payload["max_length"] = self.max_length
        return payload


@dataclass(slots=True)
class Modal:
    custom_id: str
    title: str
    components: tuple[TextInput, ...]
    callback: ModalCallback | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.components:
            raise ValueError("Modal must contain between 1 and 5 text inputs")
        if len(self.components) > MAX_MODAL_TEXT_INPUTS:
            raise ValueError(
                f"A Discord modal may contain at most {MAX_MODAL_TEXT_INPUTS} text inputs"
            )
        if len(self.title) > MAX_MODAL_TITLE_LENGTH:
            raise ValueError(
                f"Modal title must be at most {MAX_MODAL_TITLE_LENGTH} characters (Discord limit)"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "custom_id": self.custom_id,
            "title": self.title,
            "components": [
                {
                    "type": 1,
                    "components": [component.to_dict()],
                }
                for component in self.components
            ],
        }


def combine_text_inputs(*items: TextInput | Iterable[TextInput]) -> tuple[TextInput, ...]:
    merged: list[TextInput] = []
    for item in items:
        if isinstance(item, TextInput):
            merged.append(item)
        else:
            merged.extend(item)
    if len(merged) > MAX_MODAL_TEXT_INPUTS:
        raise ValueError(
            f"A Discord modal may contain at most {MAX_MODAL_TEXT_INPUTS} text inputs (got {len(merged)})"
        )
    return tuple(merged)


@dataclass(slots=True)
class ModalBuilder:
    """Собирает модальное окно из полей; удобно комбинировать с `combine_text_inputs`."""

    custom_id: str
    title: str
    _components: list[TextInput] = field(default_factory=list, repr=False)
    _metadata: dict[str, Any] = field(default_factory=dict, repr=False)

    def add(self, inp: TextInput) -> ModalBuilder:
        if len(self._components) >= MAX_MODAL_TEXT_INPUTS:
            raise ValueError(
                f"A Discord modal may contain at most {MAX_MODAL_TEXT_INPUTS} text inputs"
            )
        self._components.append(inp)
        return self

    def add_short(
        self,
        custom_id: str,
        label: str,
        *,
        placeholder: str | None = None,
        value: str | None = None,
        required: bool = True,
        min_length: int | None = None,
        max_length: int | None = None,
    ) -> ModalBuilder:
        return self.add(
            TextInput(
                custom_id=custom_id,
                label=label,
                style=TextInputStyle.SHORT,
                placeholder=placeholder,
                value=value,
                required=required,
                min_length=min_length,
                max_length=max_length,
            )
        )

    def add_paragraph(
        self,
        custom_id: str,
        label: str,
        *,
        placeholder: str | None = None,
        value: str | None = None,
        required: bool = True,
        min_length: int | None = None,
        max_length: int | None = None,
    ) -> ModalBuilder:
        return self.add(
            TextInput(
                custom_id=custom_id,
                label=label,
                style=TextInputStyle.PARAGRAPH,
                placeholder=placeholder,
                value=value,
                required=required,
                min_length=min_length,
                max_length=max_length,
            )
        )

    def extend(self, *inputs: TextInput) -> ModalBuilder:
        for inp in inputs:
            self.add(inp)
        return self

    def extend_from(self, inputs: Iterable[TextInput]) -> ModalBuilder:
        for inp in inputs:
            self.add(inp)
        return self

    def with_metadata(self, **metadata: Any) -> ModalBuilder:
        self._metadata.update(metadata)
        return self

    def build(self, *, callback: ModalCallback | None = None) -> Modal:
        if not self._components:
            raise ValueError("Modal must contain at least one TextInput")
        if len(self.title) > MAX_MODAL_TITLE_LENGTH:
            raise ValueError(
                f"Modal title must be at most {MAX_MODAL_TITLE_LENGTH} characters (Discord limit)"
            )
        return Modal(
            custom_id=self.custom_id,
            title=self.title,
            components=tuple(self._components),
            callback=callback,
            metadata=dict(self._metadata),
        )


def modal(
    *,
    custom_id: str,
    title: str,
    components: Iterable[TextInput],
    **metadata: Any,
) -> Callable[[ModalCallback], ModalCallback]:
    def decorator(callback: ModalCallback) -> ModalCallback:
        callback.__suneord_modal__ = {
            "custom_id": custom_id,
            "title": title,
            "components": combine_text_inputs(components),
            "metadata": metadata,
        }
        return callback

    return decorator
