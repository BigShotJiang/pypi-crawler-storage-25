from __future__ import annotations

from typing import Any

from .command import OptionType
from .components import ActionRow
from .modal import Modal
from .models import Color, Embed


def _build_message_payload(
    *,
    content: str | None = None,
    embed: Embed | None = None,
    embeds: list[Embed] | None = None,
    reply_to: int | None = None,
    components: list[ActionRow] | None = None,
) -> dict[str, Any]:
    has_body = (
        content is not None
        or embed is not None
        or bool(embeds)
        or components is not None
    )
    if not has_body:
        raise ValueError("content, embed, embeds or components is required")

    payload: dict[str, Any] = {}
    if content is not None:
        payload["content"] = content
    if embed is not None:
        payload["embeds"] = [embed.to_dict()]
    if embeds:
        payload["embeds"] = [item.to_dict() for item in embeds]
    if components is not None:
        payload["components"] = [row.to_dict() for row in components]
    if reply_to is not None:
        payload["message_reference"] = {"message_id": str(reply_to)}
    return payload


class MessageContext:
    def __init__(self, bot: Any, message: dict[str, Any]) -> None:
        self.bot = bot
        self.message = message
        self.channel_id = int(message["channel_id"])
        self.guild_id = int(message["guild_id"]) if message.get("guild_id") else None
        self.message_id = int(message["id"])
        self.author = message["author"]
        self.author_id = int(self.author["id"])
        self.content = message.get("content", "")
        self.command = None
        self.invoked_with: str | None = None
        self.args: list[str] = []
        self.command_failed = False

    @property
    def latency(self) -> int:
        return self.bot.latency_ms

    @property
    def args_text(self) -> str:
        return " ".join(self.args)

    @property
    def author_name(self) -> str:
        return self.author.get("global_name") or self.author.get("username") or "Unknown User"

    @property
    def author_mention(self) -> str:
        return f"<@{self.author_id}>"

    @property
    def me(self) -> Any:
        return self.bot.user

    @property
    def jump_url(self) -> str | None:
        if self.guild_id is None:
            return None
        return f"https://discord.com/channels/{self.guild_id}/{self.channel_id}/{self.message_id}"

    @property
    def channel_mention(self) -> str:
        return f"<#{self.channel_id}>"

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        reply_to: int | None = None,
        components: list[ActionRow] | None = None,
    ) -> dict[str, Any]:
        if content is not None and embed is None and not embeds and components is None:
            normalized = content.strip().casefold()
            if normalized in {"понг!", "pong!"}:
                content = f"{content} {self.bot.latency_ms} мс"

        payload = _build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            reply_to=reply_to,
            components=components,
        )
        return await self.bot.http.create_message(self.channel_id, payload)

    async def reply(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[ActionRow] | None = None,
    ) -> dict[str, Any]:
        return await self.send(
            content,
            embed=embed,
            embeds=embeds,
            reply_to=self.message_id,
            components=components,
        )

    async def typing(self) -> None:
        await self.bot.http.trigger_typing(self.channel_id)

    async def react(self, emoji: str) -> None:
        await self.bot.http.add_reaction(self.channel_id, self.message_id, emoji)

    async def pin(self) -> None:
        await self.bot.http.pin_message(self.channel_id, self.message_id)

    async def unpin(self) -> None:
        await self.bot.http.unpin_message(self.channel_id, self.message_id)

    async def edit(
        self,
        *,
        content: str | None = None,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[ActionRow] | None = None,
    ) -> dict[str, Any]:
        payload = _build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            components=components,
        )
        return await self.bot.http.edit_message(self.channel_id, self.message_id, payload)

    async def delete(self) -> None:
        await self.bot.http.delete_message(self.channel_id, self.message_id)

    async def send_success(self, content: str, *, title: str = "Успешно") -> dict[str, Any]:
        embed = Embed(title=title, description=content, color=Color.GREEN).set_timestamp()
        return await self.send(embed=embed)

    async def send_error(self, content: str, *, title: str = "Ошибка") -> dict[str, Any]:
        embed = Embed(title=title, description=content, color=Color.RED).set_timestamp()
        return await self.send(embed=embed)


class _InteractionMixin:
    def __init__(self) -> None:
        self._responded = False
        self._deferred = False

    @property
    def responded(self) -> bool:
        return self._responded

    @property
    def deferred(self) -> bool:
        return self._deferred

    @property
    def latency(self) -> int:
        return self.bot.latency_ms

    @property
    def author_name(self) -> str:
        if not self.user:
            return "Unknown User"
        return self.user.get("global_name") or self.user.get("username") or "Unknown User"

    @property
    def author_mention(self) -> str:
        return f"<@{self.author_id}>"

    @property
    def channel_mention(self) -> str | None:
        if self.channel_id is None:
            return None
        return f"<#{self.channel_id}>"

    def option(self, name: str, default: Any = None) -> Any:
        return self.options.get(name, default)

    async def send(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        components: list[ActionRow] | None = None,
    ) -> None:
        await self.respond(
            content,
            embed=embed,
            embeds=embeds,
            ephemeral=ephemeral,
            components=components,
        )

    async def respond(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        components: list[ActionRow] | None = None,
    ) -> None:
        data = _build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            components=components,
        )
        if ephemeral:
            data["flags"] = data.get("flags", 0) | 64

        await self.bot.http.create_interaction_response(
            self.id,
            self.token,
            {
                "type": 4,
                "data": data,
            },
        )
        self._responded = True

    async def defer(self, *, ephemeral: bool = False) -> None:
        data: dict[str, Any] = {}
        if ephemeral:
            data["flags"] = 64
        await self.bot.http.create_interaction_response(
            self.id,
            self.token,
            {
                "type": 5,
                "data": data,
            },
        )
        self._responded = True
        self._deferred = True

    async def followup(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        components: list[ActionRow] | None = None,
    ) -> dict[str, Any]:
        payload = _build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            components=components,
        )
        if ephemeral:
            payload["flags"] = payload.get("flags", 0) | 64
        return await self.bot.http.create_followup_message(
            int(self.bot.application_id),
            self.token,
            payload,
        )

    async def edit_original_response(
        self,
        *,
        content: str | None = None,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[ActionRow] | None = None,
    ) -> dict[str, Any]:
        payload = _build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            components=components,
        )
        return await self.bot.http.edit_original_interaction_response(
            int(self.bot.application_id),
            self.token,
            payload,
        )

    async def delete_original_response(self) -> None:
        await self.bot.http.delete_original_interaction_response(
            int(self.bot.application_id),
            self.token,
        )

    async def send_success(self, content: str, *, title: str = "Успешно", ephemeral: bool = False) -> None:
        embed = Embed(title=title, description=content, color=Color.GREEN).set_timestamp()
        await self.respond(embed=embed, ephemeral=ephemeral)

    async def send_error(self, content: str, *, title: str = "Ошибка", ephemeral: bool = True) -> None:
        embed = Embed(title=title, description=content, color=Color.RED).set_timestamp()
        await self.respond(embed=embed, ephemeral=ephemeral)


class SlashContext(_InteractionMixin):
    def __init__(self, bot: Any, interaction: dict[str, Any]) -> None:
        super().__init__()
        self.bot = bot
        self.interaction = interaction
        self.id = interaction["id"]
        self.token = interaction["token"]
        self.guild_id = int(interaction["guild_id"]) if interaction.get("guild_id") else None
        self.channel_id = int(interaction["channel_id"]) if interaction.get("channel_id") else None
        self.data = interaction.get("data", {})
        self.command = None
        self.command_name = self.data.get("name")
        self.user = interaction.get("member", {}).get("user") or interaction.get("user")
        self.author = self.user
        self.author_id = int(self.user["id"]) if self.user else 0
        self.resolved = self.data.get("resolved", {})
        self.options = self._parse_options(self.data.get("options", []))

    async def show_modal(self, modal: Modal) -> None:
        existing = self.bot.get_modal(modal.custom_id)
        if existing is not None and modal.callback is None:
            merged = Modal(
                custom_id=modal.custom_id,
                title=modal.title,
                components=modal.components,
                callback=existing.callback,
                metadata={**existing.metadata, **modal.metadata},
            )
            self.bot.add_modal(merged)
            payload = merged.to_dict()
        else:
            self.bot.add_modal(modal)
            payload = modal.to_dict()

        await self.bot.http.create_interaction_response(
            self.id,
            self.token,
            {
                "type": 9,
                "data": payload,
            },
        )
        self._responded = True

    def _parse_options(self, options: list[dict[str, Any]]) -> dict[str, Any]:
        parsed: dict[str, Any] = {}
        for option in options:
            option_type = option.get("type")
            name = option.get("name")
            if not name:
                continue
            if option_type in {OptionType.SUB_COMMAND, OptionType.SUB_COMMAND_GROUP}:
                nested = self._parse_options(option.get("options", []))
                parsed[name] = nested
                continue
            parsed[name] = self._resolve_option_value(option)
        return parsed

    def _resolve_option_value(self, option: dict[str, Any]) -> Any:
        option_type = option.get("type")
        value = option.get("value")
        if value is None:
            return None

        if option_type == OptionType.USER:
            user = dict(self.resolved.get("users", {}).get(str(value), {}))
            member = self.resolved.get("members", {}).get(str(value), {})
            if member:
                user["member"] = member
            return user or value
        if option_type == OptionType.CHANNEL:
            return self.resolved.get("channels", {}).get(str(value), value)
        if option_type == OptionType.ROLE:
            return self.resolved.get("roles", {}).get(str(value), value)
        if option_type == OptionType.MENTIONABLE:
            return (
                self.resolved.get("users", {}).get(str(value))
                or self.resolved.get("roles", {}).get(str(value))
                or value
            )
        if option_type == OptionType.ATTACHMENT:
            return self.resolved.get("attachments", {}).get(str(value), value)
        return value


class ModalContext(_InteractionMixin):
    def __init__(self, bot: Any, interaction: dict[str, Any]) -> None:
        super().__init__()
        self.bot = bot
        self.interaction = interaction
        self.id = interaction["id"]
        self.token = interaction["token"]
        self.guild_id = int(interaction["guild_id"]) if interaction.get("guild_id") else None
        self.channel_id = int(interaction["channel_id"]) if interaction.get("channel_id") else None
        self.data = interaction.get("data", {})
        self.user = interaction.get("member", {}).get("user") or interaction.get("user")
        self.author = self.user
        self.author_id = int(self.user["id"]) if self.user else 0
        self.custom_id = self.data.get("custom_id")
        self.modal = None
        self.options = self._extract_values(self.data.get("components", []))

    def value(self, custom_id: str, default: Any = None) -> Any:
        return self.options.get(custom_id, default)

    def _extract_values(self, components: list[dict[str, Any]]) -> dict[str, Any]:
        values: dict[str, Any] = {}
        for row in components:
            for component in row.get("components", []):
                custom_id = component.get("custom_id")
                if custom_id:
                    values[custom_id] = component.get("value")
        return values


class ComponentContext(_InteractionMixin):
    def __init__(self, bot: Any, interaction: dict[str, Any]) -> None:
        super().__init__()
        self.bot = bot
        self.interaction = interaction
        self.id = interaction["id"]
        self.token = interaction["token"]
        self.guild_id = int(interaction["guild_id"]) if interaction.get("guild_id") else None
        self.channel_id = int(interaction["channel_id"]) if interaction.get("channel_id") else None
        self.data = interaction.get("data", {})
        self.user = interaction.get("member", {}).get("user") or interaction.get("user")
        self.author = self.user
        self.author_id = int(self.user["id"]) if self.user else 0
        self.custom_id = self.data.get("custom_id")
        self.component_type = self.data.get("component_type")
        message = interaction.get("message") or {}
        self.message = message
        self.message_id = int(message["id"]) if message.get("id") else None
        self.listener: Any | None = None

    async def defer_update(self) -> None:
        await self.bot.http.create_interaction_response(
            self.id,
            self.token,
            {"type": 6},
        )
        self._responded = True
        self._deferred = True

    async def update_message(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        components: list[ActionRow] | None = None,
    ) -> None:
        data = _build_message_payload(
            content=content,
            embed=embed,
            embeds=embeds,
            components=components,
        )
        await self.bot.http.create_interaction_response(
            self.id,
            self.token,
            {
                "type": 7,
                "data": data,
            },
        )
        self._responded = True
