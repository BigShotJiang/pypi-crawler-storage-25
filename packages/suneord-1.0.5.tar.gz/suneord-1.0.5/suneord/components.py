from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from .command import Callback


class ButtonStyle:
    PRIMARY = 1
    SECONDARY = 2
    SUCCESS = 3
    DANGER = 4
    LINK = 5


@dataclass(slots=True)
class Button:
    style: int
    label: str | None = None
    custom_id: str | None = None
    url: str | None = None
    disabled: bool = False
    emoji: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"type": 2, "style": self.style}
        if self.label is not None:
            payload["label"] = self.label
        if self.custom_id is not None:
            payload["custom_id"] = self.custom_id
        if self.url is not None:
            payload["url"] = self.url
        if self.disabled:
            payload["disabled"] = True
        if self.emoji is not None:
            payload["emoji"] = self.emoji
        return payload


@dataclass(slots=True)
class ActionRow:
    components: tuple[Button, ...]

    def to_dict(self) -> dict[str, Any]:
        return {"type": 1, "components": [component.to_dict() for component in self.components]}


@dataclass(slots=True)
class ButtonListener:
    custom_id: str
    callback: Callback
    metadata: dict[str, Any] = field(default_factory=dict)


def button(*, custom_id: str, **metadata: Any) -> Callable[[Callback], Callback]:
    def decorator(callback: Callback) -> Callback:
        callback.__suneord_button__ = {"custom_id": custom_id, "metadata": metadata}
        return callback

    return decorator
