# Jentic API Tools - Common

Shared types, Pydantic models, centralized configuration, and utility functions for the Jentic API Tools monorepo. Every other package depends on this one.

## Key Features

The common package defines the core type aliases (`SpecType`, `SpecFormat`, `SpecVersion`) used throughout the project, along with all Pydantic request/response models for the processing pipeline. It provides a centralized `Settings` class built on pydantic-settings that reads configuration from environment variables and `.env` files, with nested sections for LLM, API, jobs, pipeline, CLI, and public APIs configuration. The `PublicApisSettings` section configures GitHub integration for the public APIs catalog (token, repository, base branch, and catalog URL). Utility modules provide consistent logging via `get_module_logger` with configurable rotating file output, spec reordering, file I/O helpers, and CPU detection for parallelism. File logging uses a `RotatingFileHandler` (default 10 MB, 3 backups) and can be disabled entirely via `LOG_FILE_ENABLED=false` for containerized deployments.

## Dependencies

No internal dependencies. External: pydantic, pydantic-settings, python-dotenv, jentic-openapi-validator.

## Installation

```bash
pip install jentic-apitools-common
```

## Quick Start

```python
from jentic.apitools.common.types import SpecType, SpecFormat
from jentic.apitools.common.settings import settings

print(settings.llm.provider)        # "BEDROCK"
print(settings.api.port)            # 8000
print(settings.jobs.storage_backend) # "memory"
```

## Testing

```bash
pytest tests -v
```
