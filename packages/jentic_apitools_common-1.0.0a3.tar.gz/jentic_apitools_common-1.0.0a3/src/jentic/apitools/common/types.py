"""Common type definitions and type aliases."""

from typing import Literal, TypeAlias


__all__ = [
    "SpecFormat",
    "SpecType",
    "SpecVersion",
]


# Spec type (OpenAPI, Swagger, Google Discovery)
SpecType: TypeAlias = Literal["openapi", "swagger", "google-discovery"]

# OpenAPI version
SpecVersion: TypeAlias = Literal["2.0", "3.0.0", "3.0.1", "3.0.2", "3.0.3", "3.1.0", "3.1.1"]

# Spec format (JSON or YAML)
SpecFormat: TypeAlias = Literal["json", "yaml"]
