"""Utilities for serialising and classifying JenticDiagnostic objects."""

from __future__ import annotations

from typing import TYPE_CHECKING

from lsprotocol.types import DiagnosticSeverity


if TYPE_CHECKING:
    from jentic.apitools.openapi.validator.core import JenticDiagnostic

_SEVERITY_LABELS: dict[int, str] = {
    DiagnosticSeverity.Error: "error",
    DiagnosticSeverity.Warning: "warning",
    DiagnosticSeverity.Information: "information",
    DiagnosticSeverity.Hint: "hint",
}


def serialize_diagnostic(d: JenticDiagnostic) -> dict:
    """Convert a JenticDiagnostic into a JSON-serialisable dict.

    The returned dict always contains ``code``, ``message``, ``severity``
    (human-readable label), and ``source``.  Optional ``target`` and ``fatal``
    fields are included when the diagnostic carries meaningful values for them.
    """
    severity_label = _SEVERITY_LABELS.get(d.severity, "unknown") if d.severity else "unknown"

    result: dict = {
        "code": d.code,
        "message": d.message,
        "severity": severity_label,
        "source": d.source or "",
    }

    target = (d.data or {}).get("target", "") if hasattr(d, "data") else ""
    if target:
        result["target"] = target

    fatal = (d.data or {}).get("fatal", None) if hasattr(d, "data") else None
    if fatal is not None:
        result["fatal"] = fatal

    return result


def classify_error(diagnostics: list[JenticDiagnostic]) -> tuple[str, str]:
    """Determine the primary error code and message from a list of diagnostics.

    Selection priority:
    1. First diagnostic whose ``data.fatal`` is truthy.
    2. First diagnostic with ``DiagnosticSeverity.Error``.
    3. Fallback ``("scoring_failed", "Scoring failed")``.

    Returns a ``(error_code, error_message)`` tuple.
    """
    first_error: JenticDiagnostic | None = None

    for d in diagnostics:
        data = d.data if hasattr(d, "data") and d.data else {}
        if data.get("fatal"):
            return (str(d.code) if d.code else "scoring_failed", d.message)
        if first_error is None and d.severity == DiagnosticSeverity.Error:
            first_error = d

    if first_error is not None:
        code = str(first_error.code) if first_error.code else "scoring_failed"
        return (code, first_error.message)

    return ("scoring_failed", "Scoring failed")
