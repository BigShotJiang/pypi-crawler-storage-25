"""CPU-related utility functions."""

import os


__all__ = ["get_available_cpu_count"]


def get_available_cpu_count() -> int:
    """Get the number of CPUs available to the process.

    Returns the number of CPUs available via sched_getaffinity (Linux)
    or falls back to os.cpu_count().
    """
    if hasattr(os, "sched_getaffinity"):
        return len(os.sched_getaffinity(0))

    return os.cpu_count() or 1
