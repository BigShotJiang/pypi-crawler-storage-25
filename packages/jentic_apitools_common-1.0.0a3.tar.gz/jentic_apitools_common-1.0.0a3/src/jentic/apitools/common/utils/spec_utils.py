"""Utility helpers for downloading, converting, and tidying OpenAPI specs."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
from typing import Tuple
from urllib.parse import urlparse

import requests
from ruamel.yaml import YAML


logger = logging.getLogger(__name__)

__all__ = [
    "SpecError",
    "InvalidSpecError",
    "DownloadError",
    "reorder_openapi_spec",
    "is_valid_spec",
    "download_spec",
    "convert_to_openapi3",
    "is_google_format",
    "is_swagger_2",
    "extract_version",
    "derive_endpoint_name",
    "split_label",
    "save_pristine_copy",
    "inject_source_url",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class SpecError(Exception):
    """Base class for spec-related errors."""


class InvalidSpecError(SpecError):
    """Raised when a spec is invalid."""


class DownloadError(SpecError):
    """Raised when downloading a spec fails."""


# ---------------------------------------------------------------------------
# Core helpers
# ---------------------------------------------------------------------------


def reorder_openapi_spec(spec_data: dict) -> dict:  # pragma: no cover
    """Return *spec_data* with top-level keys ordered consistently."""
    key_order = [
        "openapi",
        "info",
        "jsonSchemaDialect",
        "servers",
        "paths",
        "webhooks",
        "components",
        "security",
        "tags",
        "externalDocs",
    ]

    ordered: dict[str, object] = {}
    for key in key_order:
        if key in spec_data:
            ordered[key] = spec_data[key]
    for key, value in spec_data.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def is_valid_spec(content: bytes | str) -> Tuple[bool, str | None]:  # pragma: no cover
    """Best-effort validation that *content* looks like an API spec."""
    try:
        yaml = YAML(typ="safe")
        data = yaml.load(content)
        if isinstance(data, dict):
            if "swagger" in data or "openapi" in data:
                return True, None
            if is_google_format_data(data):
                return True, None
            return False, "File is not a valid OpenAPI, Swagger, or Google API spec"
    except Exception as exc:  # noqa: BLE001
        return False, f"Error parsing spec file: {exc}"
    return False, "Invalid or empty spec file"


def is_google_format_data(data: object) -> bool:  # pragma: no cover
    if isinstance(data, dict):
        kind = data.get("kind", "")
        has_discovery_version = "discoveryVersion" in data
        return kind.startswith("discovery#") or has_discovery_version
    return False


def is_google_format(file_path: str) -> bool:  # pragma: no cover
    yaml = YAML(typ="safe")
    try:
        with open(file_path, "r") as file:
            data = yaml.load(file)
            return is_google_format_data(data)
    except Exception:  # noqa: BLE001
        return False


def is_swagger_2(file_path: str) -> bool:  # pragma: no cover
    yaml = YAML(typ="safe")
    try:
        with open(file_path, "r") as file:
            data = yaml.load(file)
            if isinstance(data, dict):
                return str(data.get("swagger", "")).startswith("2.")
    except Exception:  # noqa: BLE001
        pass
    return False


def convert_to_openapi3(file_path: str, source_format: str) -> str | None:  # pragma: no cover
    """Use `api-spec-converter` to convert *file_path* to OpenAPI 3 JSON."""
    try:
        logger.info(
            "Starting conversion with api-spec-converter from %s to openapi_3", source_format
        )
        proc = subprocess.Popen(
            [
                "npx",
                "--yes",
                "api-spec-converter",
                f"--from={source_format}",
                "--to=openapi_3",
                file_path,
                "--syntax=json",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        logger.info("Waiting for conversion to complete (120s timeout)...")
        try:
            stdout, stderr = proc.communicate(timeout=120)  # 120 second timeout
        except subprocess.TimeoutExpired:
            logger.error("Conversion timed out after 120 seconds")
            proc.kill()
            stdout, stderr = proc.communicate()
            return None

        if proc.returncode != 0:
            logger.error(
                "api-spec-converter failed with return code %d: %s",
                proc.returncode,
                stderr.decode(),
            )
            return None

        logger.info("Conversion completed successfully")
        with open(file_path, "w") as fh:
            fh.write(stdout.decode())
        return file_path
    except OSError as exc:  # pragma: no cover – npx not found
        logger.error("Converter not available (npx/api-spec-converter): %s", exc)
        return None
    except subprocess.CalledProcessError as exc:  # pragma: no cover
        logger.error("Converter subprocess error: %s", exc)
        return None
    except Exception as exc:  # pragma: no cover
        logger.error("Unexpected error during conversion: %s", exc)
        return None


def download_spec(url: str, base_dir: str, label: str) -> str | None:  # noqa: D401
    """Download *url* into *base_dir/label* after rudimentary validation."""
    try:
        if os.path.isfile(url):
            logger.info("Using local file: %s", url)
            with open(url, "rb") as fh:
                content = fh.read()
        else:
            logger.info("Starting download of %s", url)
            resp = requests.get(url, timeout=300)
            logger.info(
                "Download completed, status: %s, content length: %s",
                resp.status_code,
                len(resp.content),
            )
            resp.raise_for_status()
            content = resp.content

        logger.info("Validating downloaded content (%d bytes)", len(content))
        is_valid, error = is_valid_spec(content)
        if not is_valid:
            logger.error("Spec validation failed: %s", error)
            raise InvalidSpecError(error or "invalid spec")
        logger.info("Spec validation passed")

        full_dir = os.path.join(base_dir, label)
        os.makedirs(full_dir, exist_ok=True)
        file_name = os.path.basename(urlparse(url).path) or "spec"
        file_path = os.path.join(full_dir, file_name)
        logger.info("Writing spec to file: %s", file_path)
        with open(file_path, "wb") as fh:
            fh.write(content)
        logger.info("File written successfully")
        return file_path
    except requests.RequestException as exc:
        logger.error("Request failed: %s", exc)
        raise DownloadError(f"Failed to download spec: {exc}") from exc


def extract_version(file_path: str, placeholder_version: str = "0.0.0") -> str:  # pragma: no cover
    yaml = YAML(typ="safe")
    try:
        with open(file_path, "r") as fh:
            data = yaml.load(fh)
            if isinstance(data, dict) and data.get("info", {}).get("version"):
                version = data["info"]["version"]
                # Ensure version is always a string (YAML may parse dates as date objects)
                return str(version)
    except Exception:  # noqa: BLE001
        pass
    return placeholder_version


def split_label(label: str) -> Tuple[str, str]:
    """Return (vendor, api_name) pair, falling back to ``main``.

    Examples
    --------
    >>> split_label("vendor_abc.com/api_123")
    ('vendor_abc.com', 'api_123')
    >>> split_label("elevenlabs.io")
    ('vendor_abc.com', 'main')
    """
    if "/" in label:
        return tuple(label.split("/", 1))  # type: ignore[return-value]
    return label, "main"


def derive_endpoint_name(label: str) -> str:
    """Return canonical `vendor/api` endpoint name derived from *label*.

    If *label* already contains a slash treat it as `vendor/api`. For single
    segment labels, fall back to `label/main` so that callers always receive a
    two-segment string.
    """
    vendor, api = split_label(label)
    return f"{vendor}/{api}"


def save_pristine_copy(src_path: str, version_dir: str) -> str:  # pragma: no cover
    """Copy *src_path* into ``<version_dir>/orig/`` and pretty-print JSON.

    Returns the destination path. The source file is *copied*, not moved, so
    subsequent pipeline steps can still mutate or move the original as needed.
    """
    orig_dir = os.path.join(version_dir, "orig")
    os.makedirs(orig_dir, exist_ok=True)
    basename = os.path.basename(src_path)
    if basename.endswith(".origcopy"):
        basename = basename[: -len(".origcopy")]
    dest_path = os.path.join(orig_dir, basename)
    shutil.copy(src_path, dest_path)

    if dest_path.lower().endswith(".json"):
        try:
            with open(dest_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            with open(dest_path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)
        except Exception:  # noqa: BLE001
            pass

    return dest_path


def inject_source_url(spec: dict, url: str, enabled: bool = True) -> dict:  # pragma: no cover
    """Insert the original *url* into ``spec['info']['x-jentic-source-url']``.

    If *enabled* is False or ``spec`` is not a mapping, the function is a no-op.
    The function mutates *spec* **and** returns it for convenience.
    """
    if not enabled or not isinstance(spec, dict):
        return spec

    info = spec.setdefault("info", {})
    if isinstance(info, dict):
        info["x-jentic-source-url"] = url
    return spec
