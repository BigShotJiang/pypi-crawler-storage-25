"""Logging helpers shared by the CLI and FastAPI service."""

import json
import logging
import sys
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional


__all__ = ["configure_root_logger", "setup_process_logging", "get_module_logger"]


class JSONFormatter(logging.Formatter):
    """JSON formatter that includes extra fields from structured logging."""

    # Standard logging record attributes that should not be shown as extras
    RESERVED_ATTRS = {
        "name",
        "msg",
        "args",
        "created",
        "filename",
        "funcName",
        "levelname",
        "levelno",
        "lineno",
        "module",
        "msecs",
        "message",
        "pathname",
        "process",
        "processName",
        "relativeCreated",
        "thread",
        "threadName",
        "exc_info",
        "exc_text",
        "stack_info",
        "asctime",
    }

    def format(self, record):
        # Build the base log entry
        log_data = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        # Add extra fields (any attribute not in the standard set)
        extra_fields = {
            key: value
            for key, value in record.__dict__.items()
            if key not in self.RESERVED_ATTRS and not key.startswith("_")
        }

        # Merge extra fields into log_data
        if extra_fields:
            log_data.update(extra_fields)

        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_data)


def configure_root_logger(level: str = "INFO") -> None:
    """Configure the root logger with console and optional rotating file handlers."""
    from jentic.apitools.common.settings import settings

    log_settings = settings.logging

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)  # handlers will filter

    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    # Use JSON formatter for structured logging
    formatter = JSONFormatter()

    console_handler = logging.StreamHandler(sys.stdout)
    try:
        console_level = getattr(logging, level.upper())
    except AttributeError:
        console_level = logging.INFO
    console_handler.setLevel(console_level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    if log_settings.log_file_enabled:
        log_dir = Path("logs")
        log_dir.mkdir(exist_ok=True)
        file_handler = RotatingFileHandler(
            log_dir / "app.log",
            maxBytes=log_settings.log_file_max_bytes,
            backupCount=log_settings.log_file_backup_count,
            encoding="utf-8",
        )
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)


def get_module_logger(name: str) -> logging.Logger:
    """Return a module-scoped logger.

    Ensures the root logger is configured once via ``configure_root_logger`` so
    that all module loggers share the same handlers.
    """
    if not logging.getLogger().handlers:
        configure_root_logger()
    return logging.getLogger(name)


# ---------------------------------------------------------------------------
# Per-request logging helper
# ---------------------------------------------------------------------------


def setup_process_logging(label: str) -> Optional[str]:  # pragma: no cover
    """Attach a file handler for a single request and return its path.

    In *dev* environment a `logs/process_<label>_<timestamp>.log` file is
    created and added as a `FileHandler` at INFO level. The absolute path is
    returned. In non-dev environments no file handler is added and *None* is
    returned so that production deployments aren’t writing many files by
    default.
    """

    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    safe_label = label.replace("/", "_")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"process_{safe_label}_{timestamp}.log"

    # Ensure root is configured
    if not logging.getLogger().handlers:
        configure_root_logger()

    handler = logging.FileHandler(log_path)
    handler.setLevel(logging.INFO)
    handler.setFormatter(JSONFormatter())
    logging.getLogger().addHandler(handler)

    return str(log_path)
