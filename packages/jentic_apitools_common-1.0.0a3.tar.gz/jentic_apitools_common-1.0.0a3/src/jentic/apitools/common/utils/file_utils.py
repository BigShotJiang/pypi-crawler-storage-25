"""Utility helpers for filename sanitisation and extension correction."""

from __future__ import annotations

import json
import logging
import os
import re

from ruamel.yaml import YAML, YAMLError


__all__ = [
    "ensure_correct_extension",
    "sanitize_filepath",
]


logger = logging.getLogger(__name__)


def ensure_correct_extension(file_path: str) -> str:
    """Ensure the file extension matches the content type (.json or .yaml).

    If the extension is wrong, rename the file and return the *new* path."""
    yaml = YAML(typ="safe")

    try:
        with open(file_path, "r") as file:
            content = file.read()
            try:
                json.loads(content)
                correct_extension = ".json"
            except json.JSONDecodeError:
                try:
                    yaml.load(content)
                except YAMLError:
                    logger.warning("File is neither valid JSON nor YAML: %s", file_path)
                    return file_path
                correct_extension = ".yaml"

        base, ext = os.path.splitext(file_path)
        if ext != correct_extension:
            new_path = base + correct_extension
            os.rename(file_path, new_path)
            logger.debug("Renamed %s to %s", file_path, new_path)
            return new_path
    except OSError as exc:
        logger.warning("Error ensuring correct extension for %s: %s", file_path, exc)

    return file_path


def sanitize_filepath(filepath: str, invalid_chars: str = ":*?\"'<>|\t\n\r\x0b\x0c$!^\\") -> str:  # noqa: W605
    """Sanitize a user-provided label/dir name for safe use on the filesystem."""
    filepath = "".join(c for c in filepath if c not in invalid_chars)
    filepath = filepath.strip()
    elements = [re.sub(r"\s*\.\s*", ".", e) for e in filepath.split("/")]
    elements = [e.strip() for e in elements]
    filepath = "/".join(elements)
    filepath = re.sub(r"\s+", "_", filepath)
    filepath = re.sub(r"\.*/", "/", filepath)
    filepath = re.sub(r"/\.+", "/", filepath)
    filepath = filepath.strip("./")
    return filepath
