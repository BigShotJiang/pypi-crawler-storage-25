"""
Centralized configuration settings for Jentic API Tools.

This module provides a single Settings class with nested sections for all
configuration across the project. All packages should import settings from here.

Usage:
    from jentic.apitools.common.settings import settings

    # Access nested settings
    provider = settings.llm.provider
    log_level = settings.logging.console_level
    api_port = settings.api.port

Environment Variables:
    Settings are loaded from environment variables with these patterns:
    - Standard names: OPENAI_API_KEY, LLM_PROVIDER, AWS_REGION
    - Root .env file is automatically loaded
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import AliasChoices, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


__all__ = [
    "Settings",
    "LLMSettings",
    "LoggingSettings",
    "PipelineSettings",
    "CORSSettings",
    "CSRFSettings",
    "RateLimitSettings",
    "APISettings",
    "JobsSettings",
    "CLISettings",
    "PublicApisSettings",
    "settings",
    "get_settings",
]


def _find_project_root() -> Path:
    """
    Find project root by searching upward for workspace markers.

    Looks for uv.lock (workspace lockfile) or .git directory to identify
    the monorepo root where .env files are expected to live.

    Returns:
        Path to the project root directory.
    """
    current = Path(__file__).resolve().parent
    for parent in [current, *current.parents]:
        # uv.lock only exists at workspace root, not in individual packages
        if (parent / "uv.lock").exists() or (parent / ".git").exists():
            return parent
    # Fallback to current working directory if no markers found
    return Path.cwd()


_ROOT_DIR = _find_project_root()
_ENV_FILE = _ROOT_DIR / ".env"

# Shared config for all nested settings classes
_NESTED_SETTINGS_CONFIG = SettingsConfigDict(
    env_file=_ENV_FILE,
    env_file_encoding="utf-8",
    extra="ignore",
    populate_by_name=True,
)


class LLMSettings(BaseSettings):
    """
    LLM provider configuration.

    Attributes:
        provider: Default LLM provider (OPENAI, CLAUDE, ANTHROPIC, GEMINI, BEDROCK).
        light_provider: Provider for lightweight/fast operations.
        llm_model: Default model for the primary provider.
        llm_light_model: Model for lightweight operations.
        max_tokens: Default maximum tokens for responses.
        openai_api_key: OpenAI API key.
        anthropic_api_key: Anthropic API key.
        gemini_api_key: Google Gemini API key.
        aws_region: AWS region for Bedrock.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    # Provider selection
    provider: str = Field(
        default="BEDROCK",
        validation_alias=AliasChoices("LLM_PROVIDER", "JENTIC_LLM_PROVIDER"),
    )
    light_provider: str = Field(
        default="BEDROCK",
        validation_alias=AliasChoices("LIGHT_LLM_PROVIDER", "JENTIC_LLM_LIGHT_PROVIDER"),
    )

    # Model defaults
    llm_model: str = Field(
        default="eu.anthropic.claude-sonnet-4-20250514-v1:0",
        validation_alias=AliasChoices("LLM_MODEL", "JENTIC_LLM_MODEL"),
    )
    llm_light_model: str = Field(
        default="eu.anthropic.claude-haiku-4-5-20251001-v1:0",
        validation_alias=AliasChoices("LLM_LIGHT_MODEL", "JENTIC_LLM_LIGHT_MODEL"),
    )

    # Token limits
    max_tokens: int = Field(
        default=8000,
        validation_alias=AliasChoices("LLM_MAX_TOKENS", "JENTIC_LLM_MAX_TOKENS"),
    )

    # API Keys
    openai_api_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("OPENAI_API_KEY", "JENTIC_OPENAI_API_KEY"),
    )
    anthropic_api_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("ANTHROPIC_API_KEY", "JENTIC_ANTHROPIC_API_KEY"),
    )
    gemini_api_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GEMINI_API_KEY", "JENTIC_GEMINI_API_KEY"),
    )

    # AWS configuration
    aws_region: str = Field(
        default="eu-west-1",
        validation_alias=AliasChoices("AWS_REGION", "JENTIC_AWS_REGION"),
    )

    # API URLs
    openai_api_url: str = Field(
        default="https://api.openai.com/v1/chat/completions",
        validation_alias=AliasChoices("OPENAI_API_URL", "JENTIC_OPENAI_API_URL"),
    )
    anthropic_api_url: str = Field(
        default="https://api.anthropic.com/v1/messages",
        validation_alias=AliasChoices("ANTHROPIC_API_URL", "JENTIC_ANTHROPIC_API_URL"),
    )
    gemini_api_url: str = Field(
        default="https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
        validation_alias=AliasChoices("GEMINI_API_URL", "JENTIC_GEMINI_API_URL"),
    )


class LoggingSettings(BaseSettings):
    """
    Logging configuration.

    Attributes:
        console_level: Log level for console output.
        per_request_logs: Whether to write per-request log files.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    console_level: str = Field(
        default="INFO",
        validation_alias=AliasChoices("LOG_LEVEL", "JENTIC_LOG_LEVEL"),
    )
    per_request_logs: bool = Field(
        default=False,
        validation_alias=AliasChoices("PER_REQUEST_LOGS", "JENTIC_PER_REQUEST_LOGS"),
    )
    log_file_enabled: bool = Field(
        default=True,
        validation_alias=AliasChoices("LOG_FILE_ENABLED", "JENTIC_LOG_FILE_ENABLED"),
    )
    log_file_max_bytes: int = Field(
        default=10_485_760,
        validation_alias=AliasChoices("LOG_FILE_MAX_BYTES", "JENTIC_LOG_FILE_MAX_BYTES"),
    )
    log_file_backup_count: int = Field(
        default=3,
        validation_alias=AliasChoices("LOG_FILE_BACKUP_COUNT", "JENTIC_LOG_FILE_BACKUP_COUNT"),
    )


class PipelineSettings(BaseSettings):
    """
    Pipeline configuration.

    Attributes:
        enable_spec_repair: Whether to enable automatic spec repair.
        include_source_url: Whether to inject source URL into specs.
        output_format: Output format (json or yaml).
        timeout_sec: Pipeline timeout in seconds.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    enable_spec_repair: bool = Field(
        default=True,
        validation_alias=AliasChoices("ENABLE_SPEC_REPAIR", "JENTIC_ENABLE_SPEC_REPAIR"),
    )
    include_source_url: bool = Field(
        default=True,
        validation_alias=AliasChoices("INCLUDE_SOURCE_URL", "JENTIC_INCLUDE_SOURCE_URL"),
    )
    output_format: str = Field(
        default="json",
        validation_alias=AliasChoices("OUTPUT_FORMAT", "JENTIC_OUTPUT_FORMAT"),
    )
    timeout_sec: int = Field(
        default=300,
        validation_alias=AliasChoices("PIPELINE_TIMEOUT", "JENTIC_PIPELINE_TIMEOUT"),
    )


class CORSSettings(BaseSettings):
    """
    CORS middleware configuration.

    By default CORS is disabled (no origins allowed). In dev mode the app
    factory will fall back to allowing all origins when ``allow_origins``
    is empty — see ``create_app()`` in the API package.

    Attributes:
        allow_origins: Comma-separated allowed origins (e.g. "https://example.com,https://other.com").
        allow_methods: Comma-separated allowed HTTP methods.
        allow_headers: Comma-separated allowed request headers.
        expose_headers: Comma-separated headers exposed to the browser.
        allow_credentials: Whether to allow credentials (cookies, auth headers).
        max_age: Maximum time (seconds) browsers may cache preflight responses.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    allow_origins: list[str] = Field(
        default_factory=list,
        validation_alias=AliasChoices("CORS_ALLOW_ORIGINS", "JENTIC_CORS_ALLOW_ORIGINS"),
    )
    allow_methods: list[str] = Field(
        default=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        validation_alias=AliasChoices("CORS_ALLOW_METHODS", "JENTIC_CORS_ALLOW_METHODS"),
    )
    allow_headers: list[str] = Field(
        default=["Authorization", "Content-Type", "Accept", "CSRF-Token"],
        validation_alias=AliasChoices("CORS_ALLOW_HEADERS", "JENTIC_CORS_ALLOW_HEADERS"),
    )
    expose_headers: list[str] = Field(
        default=[
            "Content-Disposition",
            "Vary",
            "X-RateLimit-Limit",
            "X-RateLimit-Remaining",
            "X-RateLimit-Reset",
            "Retry-After",
        ],
        validation_alias=AliasChoices("CORS_EXPOSE_HEADERS", "JENTIC_CORS_EXPOSE_HEADERS"),
    )
    allow_credentials: bool = Field(
        default=False,
        validation_alias=AliasChoices("CORS_ALLOW_CREDENTIALS", "JENTIC_CORS_ALLOW_CREDENTIALS"),
    )
    max_age: int = Field(
        default=600,
        validation_alias=AliasChoices("CORS_MAX_AGE", "JENTIC_CORS_MAX_AGE"),
    )


class CSRFSettings(BaseSettings):
    """
    CSRF protection configuration for UI-facing endpoints.

    When enabled, requests to protected routes must include an ``CSRF-Token``
    header whose value matches the ``__csrf`` cookie set when loading UI pages.

    Attributes:
        enabled: Whether CSRF validation is active.
        cookie_name: Name of the CSRF cookie.
        header_name: Name of the request header carrying the CSRF token.
        cookie_secure: Whether the cookie requires HTTPS (set False for local HTTP dev).
        cookie_samesite: SameSite policy for the CSRF cookie (strict, lax, or none).
    """

    model_config = _NESTED_SETTINGS_CONFIG

    enabled: bool = Field(
        default=True,
        validation_alias=AliasChoices("CSRF_ENABLED", "JENTIC_CSRF_ENABLED"),
    )
    cookie_name: str = Field(
        default="__csrf",
        validation_alias=AliasChoices("CSRF_COOKIE_NAME", "JENTIC_CSRF_COOKIE_NAME"),
    )
    header_name: str = Field(
        default="CSRF-Token",
        validation_alias=AliasChoices("CSRF_HEADER_NAME", "JENTIC_CSRF_HEADER_NAME"),
    )
    cookie_secure: bool = Field(
        default=True,
        validation_alias=AliasChoices("CSRF_COOKIE_SECURE", "JENTIC_CSRF_COOKIE_SECURE"),
    )
    cookie_samesite: Literal["strict", "lax", "none"] = Field(
        default="strict",
        validation_alias=AliasChoices("CSRF_COOKIE_SAMESITE", "JENTIC_CSRF_COOKIE_SAMESITE"),
    )


class RateLimitSettings(BaseSettings):
    """
    Rate limiting configuration for processing endpoints.

    Uses a sliding window algorithm to limit per-client request rates.

    Attributes:
        enabled: Whether rate limiting is active.
        max_requests: Maximum requests allowed per window.
        window_seconds: Sliding window duration in seconds.
        rate_limited_paths: URL path prefixes subject to rate limiting.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    enabled: bool = Field(
        default=True,
        validation_alias=AliasChoices("RATE_LIMIT_ENABLED", "JENTIC_RATE_LIMIT_ENABLED"),
    )
    max_requests: int = Field(
        default=10,
        validation_alias=AliasChoices("RATE_LIMIT_MAX_REQUESTS", "JENTIC_RATE_LIMIT_MAX_REQUESTS"),
    )
    window_seconds: int = Field(
        default=60,
        validation_alias=AliasChoices(
            "RATE_LIMIT_WINDOW_SECONDS", "JENTIC_RATE_LIMIT_WINDOW_SECONDS"
        ),
    )
    rate_limited_paths: list[str] = Field(
        default=[
            "/openapi/import",
            "/openapi/score",
            "/public-apis/import",
            "/public-apis/rescore",
        ],
        validation_alias=AliasChoices("RATE_LIMIT_PATHS", "JENTIC_RATE_LIMIT_PATHS"),
    )


class APISettings(BaseSettings):
    """
    API server configuration.

    Attributes:
        host: Host to bind the server to.
        port: Port to bind the server to.
        variant: API variant (oss for full, score for lightweight).
        title: API title.
        version: API version string.
        debug: Enable debug mode.
        cors: CORS middleware configuration.
        csrf: CSRF protection configuration.
        rate_limit: Rate limiting configuration.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    host: str = Field(
        default="0.0.0.0",
        validation_alias=AliasChoices("API_HOST", "JENTIC_API_HOST"),
    )
    port: int = Field(
        default=8000,
        validation_alias=AliasChoices("API_PORT", "JENTIC_API_PORT"),
    )
    variant: str = Field(
        default="oss",
        validation_alias=AliasChoices("API_VARIANT", "JENTIC_API_VARIANT"),
    )
    title: str = Field(
        default="Jentic API Tools",
        validation_alias=AliasChoices("API_TITLE", "JENTIC_API_TITLE"),
    )
    version: str = Field(
        default="1.0.0-alpha.3",
        validation_alias=AliasChoices("API_VERSION", "JENTIC_API_VERSION"),
    )
    debug: bool = Field(
        default=False,
        validation_alias=AliasChoices("API_DEBUG", "JENTIC_API_DEBUG"),
    )
    api_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("API_KEY", "JENTIC_API_KEY"),
    )
    dev_mode: bool = Field(
        default=False,
        validation_alias=AliasChoices("API_DEV_MODE", "JENTIC_API_DEV_MODE"),
    )
    api_key_header_name: str = Field(
        default="Jentic-API-Key",
        validation_alias=AliasChoices("API_KEY_HEADER", "JENTIC_API_KEY_HEADER"),
    )
    ui_enabled: bool = Field(
        default=False,
        validation_alias=AliasChoices("UI_ENABLED", "JENTIC_UI_ENABLED"),
    )
    disable_max_memory_check: bool = Field(
        default=False,
        validation_alias=AliasChoices(
            "DISABLE_MAX_MEMORY_CHECK", "JENTIC_DISABLE_MAX_MEMORY_CHECK"
        ),
    )
    max_memory_usage_mb: int = Field(
        default=16000,
        ge=500,
        validation_alias=AliasChoices("MAX_MEMORY_USAGE_MB", "JENTIC_MAX_MEMORY_USAGE_MB"),
    )
    cors: CORSSettings = Field(default_factory=CORSSettings)
    csrf: CSRFSettings = Field(default_factory=CSRFSettings)
    rate_limit: RateLimitSettings = Field(default_factory=RateLimitSettings)


class JobsSettings(BaseSettings):
    """
    Jobs subsystem configuration.

    Attributes:
        storage_backend: Job storage backend (memory or redis).
        redis_url: Redis URL for the redis backend.
        max_concurrent_jobs: Maximum number of concurrent jobs.
        job_retention_hours: Hours to retain completed job data.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    storage_backend: str = Field(
        default="memory",
        validation_alias=AliasChoices("JOBS_STORAGE_BACKEND", "JENTIC_JOBS_STORAGE_BACKEND"),
    )
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        validation_alias=AliasChoices("JOBS_REDIS_URL", "JENTIC_JOBS_REDIS_URL"),
    )
    max_concurrent_jobs: int = Field(
        default=10,
        validation_alias=AliasChoices(
            "JOBS_MAX_CONCURRENT_JOBS", "JENTIC_JOBS_MAX_CONCURRENT_JOBS"
        ),
    )
    job_retention_hours: int = Field(
        default=24,
        validation_alias=AliasChoices("JOBS_RETENTION_HOURS", "JENTIC_JOBS_RETENTION_HOURS"),
    )
    immediate_job_delete: bool = Field(
        default=True,
        validation_alias=AliasChoices("IMMEDIATE_JOB_DELETE", "JENTIC_IMMEDIATE_JOB_DELETE"),
    )
    cleanup_output_dirs: bool = Field(
        default=True,
        validation_alias=AliasChoices(
            "JOBS_CLEANUP_OUTPUT_DIRS", "JENTIC_JOBS_CLEANUP_OUTPUT_DIRS"
        ),
    )
    cleanup_interval_minutes: int = Field(
        default=120,
        validation_alias=AliasChoices(
            "JOBS_CLEANUP_INTERVAL_MINUTES", "JENTIC_JOBS_CLEANUP_INTERVAL_MINUTES"
        ),
    )


class PublicApisSettings(BaseSettings):
    """
    Public APIs UI configuration for GitHub integration.

    Attributes:
        github_token: GitHub personal access token for creating branches and PRs.
        github_repo: Full name of the public APIs repository (owner/repo).
        github_base_branch: Base branch for PRs.
        apis_json_url: URL to fetch the root apis.json catalog.
    """

    model_config = _NESTED_SETTINGS_CONFIG

    github_token: str | None = Field(
        default=None,
        validation_alias=AliasChoices("GITHUB_TOKEN", "JENTIC_GITHUB_TOKEN"),
    )
    github_repo: str = Field(
        default="jentic/jentic-public-apis",
        validation_alias=AliasChoices("PUBLIC_APIS_REPO", "JENTIC_PUBLIC_APIS_REPO"),
    )
    github_base_branch: str = Field(
        default="main",
        validation_alias=AliasChoices("PUBLIC_APIS_BASE_BRANCH", "JENTIC_PUBLIC_APIS_BASE_BRANCH"),
    )
    apis_json_url: str = Field(
        default="https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/apis/openapi/apis.json",
        validation_alias=AliasChoices("APIS_JSON_URL", "JENTIC_APIS_JSON_URL"),
    )


class CLISettings(BaseSettings):
    """
    CLI configuration.

    Attributes:
        output_format: Default output format (json or yaml).
    """

    model_config = _NESTED_SETTINGS_CONFIG

    output_format: str = Field(
        default="json",
        validation_alias=AliasChoices("CLI_OUTPUT_FORMAT", "JENTIC_CLI_OUTPUT_FORMAT"),
    )


class Settings(BaseSettings):
    """
    Root settings with all configuration sections.

    This is the main entry point for all configuration. Import the singleton
    `settings` instance and access nested sections:

        from jentic.apitools.common.settings import settings

        settings.llm.provider
        settings.logging.console_level
        settings.api.port
    """

    model_config = _NESTED_SETTINGS_CONFIG

    llm: LLMSettings = Field(default_factory=LLMSettings)
    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    pipeline: PipelineSettings = Field(default_factory=PipelineSettings)
    api: APISettings = Field(default_factory=APISettings)
    jobs: JobsSettings = Field(default_factory=JobsSettings)
    cli: CLISettings = Field(default_factory=CLISettings)
    public_apis: PublicApisSettings = Field(default_factory=PublicApisSettings)


def get_settings() -> Settings:
    """
    Get a fresh settings instance.

    Creates a new settings instance, re-reading environment variables.
    Useful in tests when environment is modified.

    Returns:
        A new Settings instance.
    """
    return Settings()


# Singleton settings instance
settings = Settings()
