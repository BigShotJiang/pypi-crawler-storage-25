"""Pydantic request/response models used by the service API."""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum, StrEnum
from typing import Annotated, Any, Callable, Dict, List, Literal, Optional, Union

from attrs import define, field
from jentic.apitools.openapi.validator.core import JenticDiagnostic
from pydantic import AnyUrl, BaseModel, ConfigDict, Field, HttpUrl


__all__ = [
    "ProcessRequest",
    "ProcessResponse",
    "DownloadRequest",
    "OASRequestMeta",
    "OASProcessResult",
    "StorageConfigData",
    "OASProcessConfiguration",
    "ImportSuccessResponse",
    "DiagnosticTarget",
    "OASJsonRequest",
    "FailureResponse",
    "SpecSource",
    "MetaZipSource",
    "SpecSourceUrl",
    "SpecSourceInline",
    "MetaZipUrl",
    "MetaZipNone",
    "OASRepairResult",
    # Request / Response for /scores
    "ScoringRequest",
    "Scorecard",
    # Summary & details
    "Summary",
    "Grouping",
    "DimensionBase",
    "DimensionSummary",
    "DimensionDetails",
    "Signal",
    "Rule",
    "Finding",
    "FindingTrend",
    "SummaryTrend",
    # Value objects
    "Score",
    "ScoreDeviation",
    # Diagnostics
    "DiagnosticSeverity",
    "Diagnostic",
    # Metadata
    "Metadata",
    "Engine",
    "Metadata",
    "Vendor",
    "Contact",
    # Trend models (for /trends)
    "ScoreTrendResponse",
    "TrendMetadata",
    "TrendTimelineEntry",
    "TrendAnalytics",
    "TrendDimensionSummary",
    # Async job models
    "JobStatus",
    "JobOperation",
    "ProgressEvent",
    "JobInfo",
    "JobSubmitResponse",
    "JobResult",
    "JobListResponse",
    "ProgressCallback",
]


class ProcessRequest(BaseModel):
    url: str
    label: str
    output_dir: str
    timeout: int = 300


class ProcessResponse(BaseModel):
    success: bool
    log_file: Optional[str] = None
    error: Optional[str] = None
    output_dir: Optional[str] = None


class DownloadRequest(BaseModel):
    url: str
    label: str
    timeout: int = 300  # mirrors CLI default


############## quality pipelines #############


class SpecSourceUrl(BaseModel):
    """
    OpenAPI source as a URL.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "description": "OpenAPI source specified by an absolute URL. The server will download it.",
            "examples": [{"kind": "url", "url": "https://example.com/openapi.yaml"}],
            "title": "Spec Source: URL",
        }
    )
    kind: Literal["url"] = Field(
        ...,
        title="Discriminator",
        description="Specifies the variant type: 'url'.",
        examples=["url"],
    )
    url: HttpUrl | str | None = Field(
        ...,
        title="OpenAPI URL",
        description="Absolute URL pointing to the OpenAPI YAML or JSON.",
        examples=["https://example.com/openapi.yaml"],
    )


class SpecSourceInline(BaseModel):
    """
    OpenAPI source as inline YAML/JSON.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "description": "OpenAPI source provided inline as YAML or JSON text.",
            "examples": [
                {
                    "kind": "inline",
                    "content": "openapi: 3.0.3\ninfo:\n  title: Demo\n  version: 1.0.0\npaths: {}",
                }
            ],
            "title": "Spec Source: Inline",
        }
    )
    kind: Literal["inline"] = Field(
        ...,
        title="Discriminator",
        description="Specifies the variant type: 'inline'.",
        examples=["inline"],
    )
    content: str = Field(
        ...,
        title="Inline OpenAPI content",
        description="Raw YAML or JSON string containing the OpenAPI document.",
        examples=["openapi: 3.0.3\ninfo:\n  title: Demo\n  version: 1.0.0\npaths: {}"],
    )


def _json_schema_extra_specsource(schema: dict) -> None:
    """Convert anyOf to oneOf for discriminated unions."""
    if "anyOf" in schema and "discriminator" in schema:
        schema["oneOf"] = schema.pop("anyOf")
    schema["x-ui-hint"] = "Select source type then provide URL or content."


SpecSource = Annotated[
    SpecSourceUrl | SpecSourceInline,
    Field(
        discriminator="kind",
        title="OpenAPI Specification Source",
        description=(
            "Where the OpenAPI document comes from. "
            "Use `kind=url` with a `url`, or `kind=inline` with raw `content`."
        ),
        examples=[
            {"kind": "url", "url": "https://example.com/openapi.yaml"},
            {
                "kind": "inline",
                "content": "openapi: 3.0.3\ninfo: {title: Demo, version: 1.0.0}\npaths: {}",
            },
        ],
        json_schema_extra=_json_schema_extra_specsource,
    ),
]


class MetaZipUrl(BaseModel):
    """
    Metadata ZIP referenced by URL.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "description": "Optional metadata ZIP provided as a URL.",
            "examples": [{"kind": "url", "url": "https://example.com/meta.zip"}],
            "title": "Meta ZIP Source: URL",
        }
    )
    kind: Literal["url"] = Field(
        ...,
        title="Discriminator",
        description="Specifies the variant type: 'url'.",
        examples=["url"],
    )
    url: HttpUrl | str | None = Field(
        ...,
        title="Metadata ZIP URL",
        description="Absolute URL to a ZIP archive containing metadata files.",
        examples=["https://example.com/meta.zip"],
    )


class MetaZipNone(BaseModel):
    """
    No metadata ZIP provided.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "description": "No metadata ZIP will be used for this request.",
            "examples": [{"kind": "none"}],
            "title": "Meta ZIP Source: None",
        }
    )
    kind: Literal["none"] = Field(
        "none",
        title="Discriminator",
        description="Specifies the variant type: 'none'.",
        examples=["none"],
    )


MetaZipSource = Annotated[
    MetaZipUrl | MetaZipNone,
    Field(
        discriminator="kind",
        title="Optional metadata ZIP source (JSON)",
        description="Provide a ZIP by URL (`kind=url`) or choose none (`kind=none`).",
        examples=[{"kind": "none"}],
    ),
]


class StorageConfigData(BaseModel):
    """
    Storage configuration for import pipeline.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Storage Configuration",
            "description": "Optional storage backend configuration for artifacts and outputs.",
            "examples": [
                {"storage_type": "filesystem", "base_path": "/data", "config": {}},
                {
                    "storage_type": "s3",
                    "base_path": None,
                    "config": {"bucket": "acme-artifacts", "prefix": "apis/"},
                },
            ],
        }
    )
    storage_type: Literal["filesystem", "s3", "database", "github"] = Field(
        "filesystem",
        title="Storage type",
        description="Select the backend used to persist artifacts and outputs.",
        examples=["filesystem"],
    )
    base_path: Optional[str] = Field(
        None,
        title="Base path / namespace",
        description="Base path (filesystem prefix, S3 prefix, repository path, or DB namespace).",
        examples=["/data/staging/petstore/1.0", "apis/openapi/tenantA/"],
    )
    config: Dict[str, Any] = Field(
        default_factory=dict,
        title="Backend-specific configuration",
        description="Key-value settings specific to the selected storage backend.",
        examples=[{"bucket": "acme-artifacts", "region": "eu-west-1"}],
    )


class OASProcessConfiguration(BaseModel):
    """
    Controls fetch and processing behavior.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "title": "OpenAPI Processor Configuration",
            "description": "Timeouts and feature toggles used during fetching/validation/repair.",
            "examples": [{"conn_timeout": 60, "read_timeout": 180, "enable_spec_repair": True}],
        }
    )
    conn_timeout: int = Field(
        300,
        title="Connection timeout (seconds)",
        description="Maximum time to establish HTTP connections.",
        examples=[60, 300],
    )
    read_timeout: int = Field(
        300,
        title="Read timeout (seconds)",
        description="Maximum time to read HTTP responses.",
        examples=[180, 300],
    )
    enable_spec_repair: bool | None = Field(
        True,
        title="Enable spec repair",
        description="If true, attempt minor automatic repairs during processing.",
        examples=[True],
    )
    enable_llm_analysis: bool | None = Field(
        False,
        title="Enable LLM semantic analysis",
        description="If true, use LLM to analyze and improve operation descriptions and summaries for AI agent interpretability.",
        examples=[False, True],
    )
    accepts_relative_references: bool | None = Field(
        True,
        title="Accepts specs with relative references",
        description="If false, don't allow relative references in the spec.",
        examples=[True],
    )
    accepts_absolute_http_references: bool | None = Field(
        True,
        title="Accepts specs with absolute HTTP references",
        description="If false, don't allow absolute HTTP references in the spec.",
        examples=[True],
    )
    include_diagnostics_in_score: bool | None = Field(
        False,
        title="Include diagnostics in score",
        description="If true, include diagnostic messages in the score output.",
        examples=[False],
    )
    bundled_spec: bool | None = Field(
        False,
        title="Spec passed as input is bundled",
        description="If true, spec passed as input is bundled.",
        examples=[False],
    )
    skip_bundle: bool | None = Field(
        False,
        title="Skip bundling step",
        description="If true, skip bundling and run validation/scoring directly on the input spec.",
        examples=[False],
    )
    validate_repair_bundle: bool | None = Field(
        True,
        title="Run validate and repair on the bundled spec before final validation",
        description="If true, run validate and repair on the bundled spec before final validation.",
        examples=[True],
    )


class OASRequestMeta(BaseModel):
    """
    Processing metadata, labels, and contextual information.
    """

    model_config = ConfigDict(
        json_schema_extra={
            "title": "Processing Metadata",
            "description": "Includes labels/ids, doc URLs, storage config, and processor configuration.",
            "examples": [
                {
                    "label": "petclinic.com/petstore",
                    "output_dir": "/data/staging/petstore/1.0",
                    "doc_urls": ["https://docs.example.com/petstore"],
                    "api_id": "1210328234234",
                    "api_version_id": "1210328234345234",
                    "oas_process_configuration": {
                        "conn_timeout": 60,
                        "read_timeout": 180,
                        "enable_spec_repair": True,
                    },
                    "storage_config": {
                        "storage_type": "filesystem",
                        "base_path": "/data",
                        "config": {},
                    },
                }
            ],
        }
    )
    label: str = Field(
        ...,
        min_length=1,
        title="Label",
        description="<vendor>/<api> label for this request.",
        examples=["acme.com/main", "petclinic.com/petstore"],
    )
    output_dir: str | None = Field(
        None,
        title="Output directory",
        description="Optional target directory/prefix for outputs",
        examples=["/data/staging/petstore/1.0"],
    )
    original_url: HttpUrl | str | None = Field(
        None,
        title="Original URL",
        description="Optional provenance of the original spec link (if different from spec.url).",
        examples=["https://landingpage.example.com/openapi.json"],
    )
    api_meta_url: HttpUrl | str | None = Field(
        None,
        title="API metadata URL",
        description="Optional URL of v1 OAK meta.json file.",
        examples=[
            "https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/apis/openapi/1password.com/events/meta.json"
        ],
    )
    doc_urls: list[HttpUrl] | None = Field(
        default_factory=list,
        title="Additional documentation URLs",
        description="Supplemental documentation links.",
        examples=[["https://docs.example.com/petstore"]],
    )
    api_id: str | None = Field(
        None, title="API ID", description="Logical API identifier.", examples=["1210328234234"]
    )
    api_version_id: str | None = Field(
        None,
        title="API Version ID",
        description="Logical API version identifier.",
        examples=["1210328234234"],
    )
    canonical_source_url: str | None = Field(
        None,
        title="URL to be used in returned meta.json for the 'import/source/url' field'",
        description="URL to be used in returned meta.json for the 'import/source/url' field'",
        examples=[
            "https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/apis/openapi/1password.com/events/1.2.0/openapi.json"
        ],
    )
    canonical_artifacts_base_url: str | None = Field(
        None,
        title="Canonical target base URL (service)",
        description="Actual canonical service base URL that used in generated meta.json and apis.json",
        examples=[
            "https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/staging/apis/openapi"
        ],
    )
    canonical_artifacts_base_url_ui: str | None = Field(
        None,
        title="Canonical target base URL (UI)",
        description="Actual canonical UI base URL that used in generated meta.json and apis.json",
        examples=["https://github.com/jentic/jentic-public-apis/tree/main/staging/apis/openapi"],
    )
    oas_process_configuration: OASProcessConfiguration = Field(
        default=OASProcessConfiguration(),
        title="Processor config",
        description="Timeouts and toggles used by the processor.",
    )
    context: str | None = Field(
        None,
        max_length=10000,
        title="Context / notes",
        description="Free-form notes; provenance of the URL(s) or other context.",
        examples=["Discovered via partner portal; needs auth headers on fetch."],
    )
    storage_config: Optional[StorageConfigData] = Field(
        None,
        title="Storage config",
        description="Optional storage backend configuration. Defaults to filesystem if not provided.",
    )


class OASJsonRequest(BaseModel):
    """
    Request body for JSON endpoint: spec via URL or inline string; metadata ZIP via URL (or none).
    """

    model_config = ConfigDict(
        json_schema_extra={
            "title": "OpenAPI Processing Request (JSON)",
            "description": (
                "Use this when providing the spec by URL or inline content. "
                "Optionally provide a metadata ZIP by URL."
            ),
            "examples": [
                {
                    "spec": {"kind": "url", "url": "https://example.com/openapi.yaml"},
                    "meta_zip": {"kind": "url", "url": "https://example.com/meta.zip"},
                    "meta": {"label": "petstore-import"},
                }
            ],
        }
    )

    spec: SpecSource = Field(
        ...,
        title="OpenAPI spec source",
        description="The OpenAPI document to process (URL or inline content).",
    )
    meta_zip: MetaZipSource = Field(
        default_factory=lambda: MetaZipNone(),
        title="Metadata ZIP source",
        description="Optional metadata ZIP by URL, or none.",
    )
    meta: OASRequestMeta = Field(
        ...,
        title="Processing metadata",
        description="Processing configuration, labels, and contextual information.",
    )


@define(frozen=True, slots=True)
class OASProcessResult:
    success: bool
    diagnostics: list[JenticDiagnostic] = field(factory=list)
    output_dir: str | None = None
    version_dir: str | None = None
    endpoint_name: str | None = None
    error_message: str | None = None
    error_code: Union[int, str] | None = None


@define(frozen=True, slots=True)
class OASRepairResult:
    success: bool
    spec: dict
    spec_text: str
    diagnostics: list[JenticDiagnostic] = field(factory=list)
    overlays: list | None = None
    rewritten_invalid_refs: bool = False
    repair_logs: str | None = None


class DiagnosticTarget(StrEnum):
    IMPORT_URL = "import-url"
    ORIGINAL_URL = "original-url"
    META_URL = "meta-url"
    DOCS_URL = "docs-url"
    IMPORTED_SPEC = "imported-spec"
    REPAIR_SPEC = "repair-spec"
    REPAIR_BUNDLED_SPEC = "repair-bundled-spec"
    BUNDLED_SPEC = "bundled-spec"


class ImportSuccessResponse(BaseModel):
    success: bool
    version_path: str


class FailureResponse(BaseModel):
    success: bool
    message: str


############## SCORE ################


class ScoringRequest(BaseModel):
    apiDescriptionUrl: AnyUrl = Field(
        ...,
        description="Resolvable URL pointing to an API specification (OpenAPI, AsyncAPI, or Arazzo).",
    )
    includeScoreDeviation: Optional[bool] = Field(
        False,
        description="include details regarding previous score relative to current score, incuding deltas.",
    )


class Engine(BaseModel):
    name: Optional[str] = Field(None, examples=["Jentic API Scoring Engine"])
    version: Optional[str] = Field(
        None,
        description="The build version of engine.",
        examples=["b2025.10.19-commit9f7"],
    )


class Metadata(BaseModel):
    version: Optional[str] = Field(
        None, description="Jentic Scoring Framework version.", examples=["0.1-beta"]
    )
    releaseDate: Optional[date] = Field(
        None,
        description="The release date of the Jentic Scoring Framework version.",
        examples=["2025-11-01"],
    )
    engine: Optional[Engine] = Field(
        None,
        description="Metadata about the Jentic Scoring Engine used to generate this score.",
    )
    disclaimer: Optional[str] = Field(
        None,
        examples=[
            "Scores are indicative and opinion biased based on Jentic's view of what is important to deliver APIs which higher levels of interpretability for AI systems."
        ],
    )


class Specification(Enum):
    openapi = "openapi"


class Contact(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None


class Vendor(BaseModel):
    name: Optional[str] = Field(None, description="The API Vendor's name.", examples=["Stripe"])
    domain: Optional[AnyUrl] = Field(
        None,
        description="The API Vendor's domain or primary website.",
        examples=["https://stripe.com"],
    )
    contact: Optional[Contact] = Field(
        None,
        description="The vendor (e.g. contact) listed for the API.",
        examples=[{"name": "stripe engineering", "email": "apis@stripe.com"}],
    )


class ApiMetadata(BaseModel):
    apiId: Optional[str] = Field(
        None,
        description="A Jentic curated identifier to help uniquely identify an API over multiple scores.",
    )
    name: str = Field(
        ...,
        description="The API name as contained with the source API description (i.e., the `info.title` within the OpenAPI Description).",
        examples=["Billing API"],
    )
    apiDescriptionVersion: Optional[str] = Field(
        None,
        description="The version of the API description document as defined within the source API description (i.e., the `info.version` within the OpenAPI Description).",
        examples=["v2.3.1"],
    )
    specification: Specification = Field(..., examples=["openapi"])
    specificationVersion: str = Field(
        ...,
        description="The version of the relevant specification used for the API under evaluation.",
        examples=["3.2.0", "3.1.2", "3.0.4"],
    )
    sourceUrl: Optional[AnyUrl] = Field(
        None,
        description="The sourceURL of the API (if provided in the request).",
        examples=["https://api.example.com/spec/openapi.yaml"],
    )
    vendor: Vendor = Field(
        ...,
        description="Information about the Vendor or API provider (basically the owner of the API being scored).",
    )
    operationCount: Optional[int] = Field(
        None, description="total number of defined operations", examples=[10, 23]
    )
    schemaCount: Optional[int] = Field(
        None, description="total number of defined schemas", examples=[10, 14]
    )
    securitySchemeCount: Optional[int] = Field(
        None, description="total number of distinct security schemes", examples=[3, 1]
    )
    securitySchemeTypes: Optional[List[str]] = Field(
        None,
        description="list of scheme types (e.g., `apiKey`, `http`, `mutualTLS`, `oauth2`, `openIdConnect`.)",
        examples=[["apiKey", "oauth2"]],
    )
    tagCount: Optional[int] = Field(
        None, description="number of unique tags or groupings", examples=[2, 7]
    )


class Level(Enum):
    non_ready = "non-ready"
    foundational = "foundational"
    ai_aware = "ai-aware"
    ai_ready = "ai-ready"
    agent_optimized = "agent-optimized"


class Grade(Enum):
    A = "A"
    A_ = "A+"
    A__1 = "A-"
    B = "B"
    B_ = "B+"
    B__1 = "B-"
    C = "C"
    C_ = "C+"
    C__1 = "C-"
    D = "D"
    D_ = "D+"
    D__1 = "D-"
    E = "E"
    E_ = "E+"
    E__1 = "E-"
    F = "F"
    F_ = "F+"


class SummaryTrend(Enum):
    improved = "improved"
    declined = "declined"
    stable = "stable"


class Kind(Enum):
    FC = "FC"
    DXJ = "DXJ"
    ARAX = "ARAX"
    AU = "AU"
    SEC = "SEC"
    AID = "AID"


class DimensionBase(BaseModel):
    kind: Optional[Kind] = Field(
        None, description="The kind of scoring dimension.", examples=["ARAX", "FC"]
    )
    name: Optional[str] = Field(
        None,
        description="The dimension name",
        examples=["AI-Readiness & Agent Experience"],
    )
    intention: Optional[str] = Field(
        None,
        description="The intention or rationale of the dimension in relation to API quality and AI interpretability of an API.",
        examples=[
            "Evaluates how semantically interpretable and intent-rich the API is for AI agents."
        ],
    )


class Severity(Enum):
    info = "info"
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class Status(Enum):
    skipped = "skipped"
    passed = "passed"
    warning = "warning"
    failed = "failed"


class Rule(BaseModel):
    kind: str = Field(
        ...,
        description="The rule or evaluation name",
        examples=["jentic", "linting:spectral", "linting:redocly"],
    )
    ruleId: str = Field(..., description="A rule identifier", examples=["error-formats"])
    description: Optional[str] = Field(
        None,
        description="A description of scoring rule",
        examples=["Ensures RFC9457 Problem Details are used for errors."],
    )
    severity: Severity = Field(
        ..., description="The severity associated with a rule", examples=["high"]
    )
    status: Status = Field(
        ...,
        description="A status indicating the state of the rule outcome for a given scoring run.",
        examples=["passed"],
    )
    impact: Optional[str] = Field(
        None,
        description="A descriptive narrative on the general impact this rule can have on the API quality",
        examples=["Improves AI interpretability of error responses."],
    )


class FindingTrend(Enum):
    new = "new"
    remaining = "remaining"
    resolved = "resolved"
    improved = "improved"


class Finding(BaseModel):
    description: str = Field(..., examples=["Missing response examples"])
    count: int = Field(..., description="The number of occurances of the finding", examples=[5])
    trend: FindingTrend = Field(
        ...,
        description="An indication on whether the finding is new, remaining, or resolved.",
        examples=["remaining"],
    )


class Score(BaseModel):
    current: float = Field(..., description="The current score")


class ScoreDeviation(BaseModel):
    previous: Optional[float] = Field(
        None, description="The previous score for the current given level"
    )
    current: float = Field(..., description="The current score")
    delta: Optional[float] = Field(
        None,
        description="The difference between the previous score and the current score.",
    )


class DiagnosticSeverity(int, Enum):
    """Severity level of a diagnostic (LSP protocol values)"""

    ERROR = 1
    WARNING = 2
    INFORMATION = 3
    HINT = 4


class Diagnostic(BaseModel):
    """A diagnostic message produced during API analysis"""

    code: str = Field(
        ...,
        description="Diagnostic code identifier",
        examples=["total_operations", "describable_elements"],
    )
    message: str = Field(..., description="Human-readable diagnostic message")
    severity: int = Field(
        ...,
        description="Severity level of the diagnostic (1=Error, 2=Warning, 3=Information, 4=Hint)",
        examples=[3],
    )
    source: str = Field(
        ...,
        description="Source of the diagnostic (e.g., validator name)",
        examples=["speclynx-validator"],
    )
    data: Optional[Dict[str, Any]] = Field(
        None, description="Additional structured data associated with the diagnostic"
    )


class Period(BaseModel):
    start: Optional[date] = Field(
        None, description="Earliest scoring record date.", examples=["2025-10-24"]
    )
    end: Optional[date] = Field(
        None, description="Most recent scoring record date.", examples=["2025-11-01"]
    )


class TrendMetadata(BaseModel):
    apiId: Optional[str] = Field(
        None,
        description="A Jentic curated identifier to help uniquely identify an API over multiple scores.",
    )
    name: Optional[str] = Field(
        None,
        description="The API name as contained with the source API description (i.e., the info.title within the OpenAPI Description).",
    )
    records: Optional[int] = Field(
        None,
        description="Number of historical scoring records available.",
        examples=[6],
    )
    period: Optional[Period] = None
    generatedAt: Optional[datetime] = Field(
        None,
        description="Timestamp of trend report generation.",
        examples=["2025-10-23T10:00:00Z"],
    )


class Metadata1(BaseModel):
    jenticScoringEngineVersion: Optional[str] = Field(
        None,
        description="Version of the Jentic Scoring Engine used for this scoring run.",
        examples=["0.1.0", "1.0.0"],
    )
    jenticScoringFrameworkVersion: Optional[str] = Field(
        None,
        description="Version of the Jentic Scoring Framework used for this scoring run.",
        examples=["0.0.1-beta", "1.0.1"],
    )


class DimensionScore1(DimensionBase):
    score: Optional[float] = Field(None, examples=[79])


class TrendTimelineEntry(BaseModel):
    scoringDate: Optional[datetime] = Field(
        None,
        description="Timestamp of the scoring execution.",
        examples=["2025-10-23T09:45:00Z"],
    )
    overallScore: float | None = Field(
        None,
        ge=0.0,
        le=100.0,
        description="Overall score achieved during this scoring run.",
        examples=[83],
    )
    metadata: Optional[Metadata1] = Field(
        None,
        description="Metadata about the scoring context, engine, and framework used during this evaluation.",
    )
    dimensionScores: Optional[List[DimensionScore1]] = Field(
        None,
        description="Scores achieved per framework dimension during this scoring run.",
    )


class DirectionalTrend(Enum):
    upward = "upward"
    downward = "downward"
    stable = "stable"
    volatile = "volatile"


class MostImprovedDimension(Enum):
    FC = "FC"
    DXJ = "DXJ"
    ARAX = "ARAX"
    AU = "AU"
    SEC = "SEC"
    AID = "AID"


class StableDimension(Enum):
    FC = "FC"
    DXJ = "DXJ"
    ARAX = "ARAX"
    AU = "AU"
    SEC = "SEC"
    AID = "AID"


class TrendAnalytics(BaseModel):
    trend: Optional[DirectionalTrend] = Field(
        None,
        description="Overall direction of the scoring trend.",
        examples=["upward", "volatile"],
    )
    avgImprovementRate: Optional[float] = Field(
        None,
        description="Average improvement rate between scoring runs (percentage points per period).",
        examples=[4.5],
    )
    volatilityIndex: Optional[float] = Field(
        None,
        description="Indicates the degree of fluctuation in scores over time.  \nCalculated as the normalized standard deviation of scores.  \nLower values indicate more stable maturity; higher values indicate greater variability.\n",
        examples=[0.12],
    )
    mostImprovedDimension: Optional[MostImprovedDimension] = Field(
        None,
        description="Dimension with the highest cumulative improvement.",
        examples=["DXJ", "ARAX"],
    )
    stableDimensions: Optional[List[StableDimension]] = Field(
        None,
        description="Dimensions showing minimal variance over time.",
        examples=[["FC", "DXJ"]],
    )
    regressedSignals: Optional[List[str]] = Field(
        None,
        description="Signals that have declined in score across scoring periods. TODO - We need to define our exact list of symbols",
        examples=[["Schema Readability", "Error Standardization"]],
    )


class TrendDimensionSummary(DimensionBase):
    trend: Optional[DirectionalTrend] = Field(
        None,
        description="Directional trend for this dimension.",
        examples=["upward", "stable"],
    )
    averageScore: Optional[float] = Field(
        None, description="Mean score across all evaluations.", examples=[74]
    )
    minScore: Optional[float] = Field(
        None, description="Lowest observed score for this dimension.", examples=[55]
    )
    maxScore: Optional[float] = Field(
        None, description="Highest observed score for this dimension.", examples=[79]
    )


class DimensionSummary(DimensionBase):
    score: Optional[float] = Field(None, description="The current score")
    grade: Optional[Grade] = None
    scores: Optional[Score] = None


class Signal(BaseModel):
    kind: Optional[str] = Field(
        None,
        description="The kind or type of signal",
        examples=["description_coverage"],
    )
    name: Optional[str] = Field(
        None, description="The signal name", examples=["Description Coverage"]
    )
    description: Optional[str] = Field(
        None, examples=["Percentage of describable elements that have a description."]
    )
    score: Optional[float] = Field(None, description="The current score")
    metadata: Optional[Dict[str, Any]] = Field(
        None,
        description="Arbitrary metadata associated with the signal, including diagnostic provenance and signal-specific details.",
        examples=[
            {
                "provenance": {
                    "diagnostics": {"code": ["described_elements", "describable_elements"]}
                }
            }
        ],
    )
    scoreDeviation: Optional[ScoreDeviation] = None
    rules: Optional[List[Rule]] = None
    findings: Optional[List[Finding]] = None


class ScoreTrendResponse(BaseModel):
    metadata: TrendMetadata
    timeline: List[TrendTimelineEntry] = Field(
        ..., description="Chronological record of scoring evaluations for this API."
    )
    trends: TrendAnalytics
    dimensionTrends: List[TrendDimensionSummary] = Field(
        ..., description="Per-dimension summary of long-term scoring patterns."
    )


class Summary(BaseModel):
    scoringDate: datetime = Field(..., description="The datetime of the current scoring run.")
    score: float = Field(
        ..., ge=0.0, le=100.0, description="The overall score of the group.", examples=[74.3]
    )
    level: Level = Field(
        ...,
        description="The overall Jentic defined level of your API.",
        examples=["ai-ready"],
    )
    grade: Grade = Field(
        ...,
        description="A grade associated with the `overallScore`.",
        examples=["A+", "B-", "C"],
    )
    trend: Optional[SummaryTrend] = Field(
        None,
        description="A trend indicator providing information on how an API is scoring compared to a previous evaluation score.",
        examples=["improved"],
    )
    scoreDeviation: Optional[ScoreDeviation] = None
    dimensions: List[DimensionSummary] = Field(..., description="Per-dimension scoring data.")


class DimensionDetails(DimensionBase):
    score: Optional[float] = Field(None, description="The current score")
    grade: Optional[Grade] = None
    scoreDeviation: Optional[ScoreDeviation] = None
    signals: Optional[List[Signal]] = Field(
        None, description="An array of signals associated with the dimension"
    )


class Dimension(BaseModel):
    kind: Optional[Kind] = Field(
        None, description="The kind of scoring dimension.", examples=["ARAX", "FC"]
    )
    name: Optional[str] = Field(
        None,
        description="The dimension name",
        examples=["AI-Readiness & Agent Experience"],
    )
    intention: Optional[str] = Field(
        None,
        description="The intention or rationale of the dimension in relation to API quality and AI interpretability of an API.",
        examples=[
            "Evaluates how semantically interpretable and intent-rich the API is for AI agents."
        ],
    )
    signals: Optional[List[Signal]] = Field(
        None, description="An array of signals associated with the dimension"
    )


class DimensionScore(BaseModel):
    kind: Optional[Kind] = Field(
        None, description="The kind of scoring dimension.", examples=["ARAX", "FC"]
    )
    name: Optional[str] = Field(
        None,
        description="The dimension name",
        examples=["AI-Readiness & Agent Experience"],
    )
    intention: Optional[str] = Field(
        None,
        description="The intention or rationale of the dimension in relation to API quality and AI interpretability of an API.",
        examples=[
            "Evaluates how semantically interpretable and intent-rich the API is for AI agents."
        ],
    )
    score: Optional[float] = Field(None, description="The current score")
    scoreDeviation: Optional[ScoreDeviation] = None
    signals: Optional[List[Signal]] = Field(
        None, description="An array of signals associated with the dimension"
    )


class Grouping(BaseModel):
    kind: Optional[str] = Field(
        None, description="The kind or type of grouping.", examples=["FDX", "AIRU", "TSD"]
    )
    name: Optional[str] = Field(
        None, description="A scoring group name.", examples=["AI-Readiness & Usability"]
    )
    description: Optional[str] = Field(
        None,
        description="A description of the framework grouping",
        examples=["Evaluates interpretability, orchestration safety, and agent ergonomics."],
    )
    score: float | None = Field(
        None, ge=0.0, le=100.0, description="The overall score of the group.", examples=[74.3]
    )
    grade: Optional[Grade] = None
    dimensions: Optional[List[DimensionDetails]] = None


class Scorecard(BaseModel):
    metadata: Metadata = Field(
        ...,
        description="Information about the API being scored, the scoring run, and engine performing the score.",
    )
    apiMetadata: ApiMetadata = Field(..., description="Metadata about the API under evaluation.")
    summary: Summary
    details: List[Grouping] = Field(
        ...,
        description="Scoring Result Details based on Jentic's Scoring Framework groupings and dimensions.",
    )
    diagnostics: Optional[List[Diagnostic]] = Field(
        default_factory=list,
        description="Diagnostic messages produced during API analysis and scoring.",
    )


############## PROGRESS CALLBACK ################

ProgressCallback = Callable[[int, str], None]
"""Sync callback for reporting progress from pipelines/jobs.

Args:
    progress: Percentage (0-100).
    message: Human-readable milestone description.
"""


############## ASYNC JOB MODELS ################


class JobStatus(StrEnum):
    """Status of an async job"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class JobOperation(StrEnum):
    """Type of operation being performed"""

    IMPORT = "import"
    QA = "qa"
    SCORE = "score"


class ProgressEvent(BaseModel):
    """A single progress event in a job's timeline"""

    timestamp: datetime = Field(
        ..., description="When this progress event occurred", examples=["2025-01-15T10:30:00Z"]
    )
    progress: int = Field(
        ..., ge=0, le=100, description="Progress percentage (0-100)", examples=[50]
    )
    message: str = Field(
        ..., description="Human-readable progress message", examples=["Validating OpenAPI spec..."]
    )


class JobInfo(BaseModel):
    """Complete information about a job"""

    job_id: str = Field(
        ..., description="Unique job identifier", examples=["a1b2c3d4-e5f6-7890-abcd-ef1234567890"]
    )
    operation: JobOperation = Field(..., description="Type of operation", examples=["score"])
    status: JobStatus = Field(..., description="Current job status", examples=["running"])
    progress: int = Field(
        default=0, ge=0, le=100, description="Current progress percentage (0-100)", examples=[75]
    )
    progress_message: str = Field(
        default="", description="Latest progress message", examples=["Generating scorecard..."]
    )
    created_at: datetime = Field(
        ..., description="When the job was created", examples=["2025-01-15T10:00:00Z"]
    )
    started_at: datetime | None = Field(
        None, description="When the job started running", examples=["2025-01-15T10:00:01Z"]
    )
    completed_at: datetime | None = Field(
        None, description="When the job completed or failed", examples=["2025-01-15T10:05:00Z"]
    )
    error: str | None = Field(
        None,
        description="Error message if job failed",
        examples=["Failed to download spec: Connection timeout"],
    )
    result_available: bool = Field(
        default=False, description="Whether the result is available for download"
    )


class JobSubmitResponse(BaseModel):
    """Response when submitting a new async job"""

    job_id: str = Field(
        ..., description="Unique job identifier", examples=["a1b2c3d4-e5f6-7890-abcd-ef1234567890"]
    )
    status_url: str = Field(
        ...,
        description="URL to query job status",
        examples=["/jobs/a1b2c3d4-e5f6-7890-abcd-ef1234567890"],
    )
    progress_url: str = Field(
        ...,
        description="URL for Server-Sent Events progress stream",
        examples=["/jobs/a1b2c3d4-e5f6-7890-abcd-ef1234567890/progress"],
    )
    result_url: str = Field(
        ...,
        description="URL to download result when job completes",
        examples=["/jobs/a1b2c3d4-e5f6-7890-abcd-ef1234567890/result"],
    )


class JobResult(BaseModel):
    """Result of a completed job"""

    job_id: str = Field(
        ..., description="Job identifier", examples=["a1b2c3d4-e5f6-7890-abcd-ef1234567890"]
    )
    operation: JobOperation = Field(..., description="Type of operation", examples=["score"])
    status: JobStatus = Field(..., description="Final job status", examples=["completed"])
    result: dict | None = Field(
        None, description="The actual result data (structure depends on operation)"
    )
    error: str | None = Field(None, description="Error message if job failed")
    error_code: str | None = Field(
        None,
        description="Machine-readable error code when the job failed (e.g. 'failed-to-parse-import-spec')",
    )


class JobListResponse(BaseModel):
    """List of jobs with pagination info"""

    jobs: List[JobInfo] = Field(..., description="List of jobs matching query criteria")
    total: int = Field(..., description="Total number of jobs matching criteria", examples=[42])
    page: int = Field(default=1, description="Current page number", examples=[1])
    page_size: int = Field(default=20, description="Number of items per page", examples=[20])
