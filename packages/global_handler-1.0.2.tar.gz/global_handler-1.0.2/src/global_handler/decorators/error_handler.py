
from ...controllers.base_controller import BaseController
from ..exceptions.http_exceptions import HttpError
from logger_tracker import logg_warning, _request_uuid, logg_debug, logg_error
from src.config import DEBUG


def register_error_handlers(app):
    base_controller = BaseController()

    @app.errorhandler(HttpError)
    def handle_http_error(error: HttpError):
        request_id = getattr(_request_uuid, "id", None)
        extra={
                "status_code": error.status_code,
                "details": error.details,
                "request_id": request_id
            }
        logg_warning(
            f"HTTP Error {error.error_code}"
        )
        logg_debug(
            f"HTTP Error details: {extra}"
        )

        return base_controller.error(
            message=error.message,
            details=error.details,
            status_code=error.status_code,
            error_code=error.error_code,
        )

    @app.errorhandler(Exception)
    def handle_unexpected_error(error: Exception):
        request_id = getattr(_request_uuid, "id", None)
        extra={
                "request_id": request_id,
                "exception_type": type(error).__name__,
                "error_details": str(error)
        },
        logg_error(
            "Unhandled exception"
        )
        logg_debug(
            f"Unhandled exception details: {extra}"
        )

        message = "Internal server error"
        details = str(error) if DEBUG else None

        return base_controller.error(
            message=message,
            details=details,
            status_code=500
        )
