from functools import wraps
from flask import request
from werkzeug.exceptions import BadRequest
from pydantic import ValidationError

from logger_tracker import logg_warning, logg_debug, logg_info
from ..exceptions.http_exceptions import (
    ValidationHttpError,
    InvalidJsonHttpError,
    MissingParameterHttpError,
    InvalidParameterHttpError,
)


def normalize_validation_errors(exc):
    """Normalize Pydantic validation errors to a consistent format."""
    return exc.errors()


def validate_with(model):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not request.is_json:
                raise InvalidJsonHttpError("Request body must be a valid JSON")

            try:
                validated = model(**request.get_json())
                return f(validated_data=validated, *args, **kwargs)

            except BadRequest:
                raise InvalidJsonHttpError("Request body must be a valid JSON")

            except ValidationError as exc:
                extra = {"errors": exc.errors()}
                logg_warning(
                    f"Validation error on {model.__name__}"
                )
                logg_debug(
                    f"Validation error details: {extra}"
                )
                logg_info("Aqui estamos")
                raise ValidationHttpError(normalize_validation_errors(exc))

        return wrapper
    return decorator


def validate_headers_with(model):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                # Convertir headers a dict y validar
                headers_dict = dict(request.headers)
                validated = model(**headers_dict)
                return f(headers_data=validated, *args, **kwargs)

            except ValidationError as exc:
                extra = {"errors": exc.errors()}
                logg_warning(
                    f"Header validation error on {model.__name__}"
                )
                logg_debug(
                    f"Header validation error details: {extra}"
                )
                raise ValidationHttpError(normalize_validation_errors(exc))

        return wrapper
    return decorator


def validate_query_with(model):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            try:
                validated = model(**request.args.to_dict())
                return f(query_params=validated, *args, **kwargs)

            except ValidationError as exc:
                extra = {"errors": exc.errors()}
                logg_warning(
                    f"Query validation error on {model.__name__}"
                )
                logg_debug(
                    f"Query validation error details: {extra}"
                )

                for error in exc.errors():
                    error_type = error.get("type")

                    if error_type == "missing":
                        raise MissingParameterHttpError(error)

                    raise InvalidParameterHttpError(error)

                raise ValidationHttpError(exc.errors())

        return wrapper
    return decorator

def normalize_validation_errors(exc: ValidationError) -> list[dict]:
    normalized_errors = []

    for err in exc.errors():
        field = ".".join(str(loc) for loc in err.get("loc", []))
        error_type = err.get("type")

        normalized_errors.append(
            {
                "field": field,
                "error_type": error_type,
                "error": err.get("msg"),
            }
        )

    return normalized_errors
