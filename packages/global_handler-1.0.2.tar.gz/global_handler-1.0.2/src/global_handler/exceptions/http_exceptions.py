class HttpError(Exception):
    status_code: int = 400
    message: str = "Bad Request"
    error_code = "BAD_REQUEST"

    def __init__(self, details=None, *, message: str | None = None):
        self.details = details
        if message:
            self.message = message
        super().__init__(self.message)

# -------------------------
# Errores 400 Errores del cliente
# -------------------------
class BadRequestHttpError(HttpError):
    status_code = 400
    message = "Bad request"

class ValidationHttpError(HttpError):
    status_code = 400
    message = "Invalid request body"
    error_code = "VALIDATION_ERROR"

class InvalidJsonHttpError(HttpError):
    status_code = 400
    message = "Invalid JSON payload"
    error_code = "INVALID_JSON"

class MissingParameterHttpError(HttpError):
    status_code = 400
    message = "Missing required parameter"
    error_code = "MISSING_PARAMETER"

class InvalidParameterHttpError(HttpError):
    status_code = 400
    message = "Invalid parameter value"
    error_code = "INVALID_PARAMETER"

# -------------------------
# Errores 401 Autenticacion
# -------------------------
class UnauthorizedHttpError(HttpError):
    status_code = 401
    message = "Unauthorized"


class InvalidCredentialsHttpError(HttpError):
    status_code = 401
    message = "Invalid credentials"


class TokenExpiredHttpError(HttpError):
    status_code = 401
    message = "Authentication token expired"

# -------------------------
# Errores 403 Authorizacion
# -------------------------
class ForbiddenHttpError(HttpError):
    status_code = 403
    message = "Forbidden"


class InsufficientPermissionsHttpError(HttpError):
    status_code = 403
    message = "Insufficient permissions"

# -------------------------
# Errores 404 Recurso no encontrado
# -------------------------
class NotFoundHttpError(HttpError):
    status_code = 404
    message = "Resource not found"

class EndpointNotFoundHttpError(NotFoundHttpError):
    message = "Endpoint not found"

# -------------------------
# Errores 409 Conflicto
# -------------------------
class ConflictHttpError(HttpError):
    status_code = 409
    message = "Conflict"

class ResourceAlreadyExistsHttpError(ConflictHttpError):
    message = "Resource already exists"

# -------------------------
# Errores 422 Entidad no procesable
# -------------------------
class UnprocessableEntityHttpError(HttpError):
    status_code = 422
    message = "Unprocessable entity"


class InvalidStateHttpError(UnprocessableEntityHttpError):
    message = "Invalid resource state"

# -------------------------
# Errores 429 Rate limit
# -------------------------
class TooManyRequestsHttpError(HttpError):
    status_code = 429
    message = "Too many requests"

# -------------------------
# Errores 500 Errores del servidor
# -------------------------
class InternalServerHttpError(HttpError):
    status_code = 500
    message = "Internal server error"


class ServiceUnavailableHttpError(HttpError):
    status_code = 503
    message = "Service unavailable"


class TimeoutHttpError(HttpError):
    status_code = 504
    message = "Gateway timeout"
