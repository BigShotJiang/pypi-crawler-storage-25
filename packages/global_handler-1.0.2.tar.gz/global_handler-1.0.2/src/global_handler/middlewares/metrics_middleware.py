import time
from flask import request, g
from logger_tracker import _request_uuid, logg_info, logg_debug


def before_request_metrics():
    g.start_time = time.perf_counter()
    extra={
            "query_params": request.args.to_dict(),
            "request_id": getattr(_request_uuid, "id", None)
    }
    
    logg_info(
        f"📦 Method: {request.method} Path: {request.path}"
    )
    logg_debug(extra)

def after_request_metrics(response):
    elapsed = time.perf_counter() - g.start_time
    extra={
            "request_id": getattr(_request_uuid, "id", None),
            "method": request.method,
            "path": request.path,
            "status_code": response.status_code,
            "duration_ms": round(elapsed * 1000, 2)
    }
    logg_debug(extra)
    logg_info(
        "HTTP request completed",
    )

    return response
