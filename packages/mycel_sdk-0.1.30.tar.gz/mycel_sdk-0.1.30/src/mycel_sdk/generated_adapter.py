"""Stable facade adapter over FastAPI/OpenAPI-generated client output."""

from __future__ import annotations

import json
import sys
from collections.abc import Callable
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import httpx

from .errors import ApiError, ConnectionClosed, ReplayOverflow

_OMIT = object()


def _normalize_result(result: Any) -> Any:
    if result is None:
        return None
    if isinstance(result, list):
        return [_normalize_result(item) for item in result]
    if isinstance(result, dict):
        return {key: _normalize_result(value) for key, value in result.items()}
    if hasattr(result, "to_dict"):
        return _normalize_result(result.to_dict())
    return result


def load_generated_bundle(package_name: str) -> Any:
    client_mod = import_module(f"{package_name}.client")

    def _attr(module_path: str, attr_name: str) -> Any:
        return getattr(import_module(f"{package_name}.{module_path}"), attr_name)

    return SimpleNamespace(
        Client=client_mod.Client,
        AuthenticatedClient=client_mod.AuthenticatedClient,
        UNSET=_attr("types", "UNSET"),
        LoginRequest=_attr("models.login_request", "LoginRequest"),
        SendOtpRequest=_attr("models.send_otp_request", "SendOtpRequest"),
        VerifyOtpRequest=_attr("models.verify_otp_request", "VerifyOtpRequest"),
        CompleteRegisterRequest=_attr(
            "models.complete_register_request", "CompleteRegisterRequest"
        ),
        CreateExternalUserRequest=_attr(
            "models.create_external_user_request", "CreateExternalUserRequest"
        ),
        CreateAgentRequest=_attr("models.create_agent_request", "CreateAgentRequest"),
        CreateThreadRequest=_attr(
            "models.create_thread_request", "CreateThreadRequest"
        ),
        MountSpec=_attr("models.mount_spec", "MountSpec"),
        MountSpecMode=_attr("models.mount_spec_mode", "MountSpecMode"),
        CreateChatBody=_attr("models.create_chat_body", "CreateChatBody"),
        CreateChatBodyKind=_attr("models.create_chat_body_kind", "CreateChatBodyKind"),
        ChatJoinRequestBody=_attr(
            "models.chat_join_request_body", "ChatJoinRequestBody"
        ),
        ChatJoinRequestActionBody=_attr(
            "models.chat_join_request_action_body", "ChatJoinRequestActionBody"
        ),
        ChatMemberAddBody=_attr("models.chat_member_add_body", "ChatMemberAddBody"),
        MuteChatBody=_attr("models.mute_chat_body", "MuteChatBody"),
        SendMessageBody=_attr("models.send_message_body", "SendMessageBody"),
        SendMessageBodyDeliveryScope=_attr(
            "models.send_message_body_delivery_scope",
            "SendMessageBodyDeliveryScope",
        ),
        SetChatWorkflowBody=_attr(
            "models.set_chat_workflow_body", "SetChatWorkflowBody"
        ),
        SetChatWorkflowBodyConfig=_attr(
            "models.set_chat_workflow_body_config", "SetChatWorkflowBodyConfig"
        ),
        CreateChatTaskBody=_attr("models.create_chat_task_body", "CreateChatTaskBody"),
        CreateChatTaskBodyMetadata=_attr(
            "models.create_chat_task_body_metadata", "CreateChatTaskBodyMetadata"
        ),
        UpdateChatTaskBody=_attr("models.update_chat_task_body", "UpdateChatTaskBody"),
        UpdateChatTaskBodyMetadataType0=_attr(
            "models.update_chat_task_body_metadata_type_0",
            "UpdateChatTaskBodyMetadataType0",
        ),
        CreateChatWorkflowEventBody=_attr(
            "models.create_chat_workflow_event_body", "CreateChatWorkflowEventBody"
        ),
        CreateChatWorkflowEventBodyDecisionStates=_attr(
            "models.create_chat_workflow_event_body_decision_states",
            "CreateChatWorkflowEventBodyDecisionStates",
        ),
        CreateChatWorkflowEventBodyFinalState=_attr(
            "models.create_chat_workflow_event_body_final_state",
            "CreateChatWorkflowEventBodyFinalState",
        ),
        CreateChatWorkflowEventBodyMetadata=_attr(
            "models.create_chat_workflow_event_body_metadata",
            "CreateChatWorkflowEventBodyMetadata",
        ),
        CreateChatWorkflowEventBodyRationales=_attr(
            "models.create_chat_workflow_event_body_rationales",
            "CreateChatWorkflowEventBodyRationales",
        ),
        CreateChatWorkflowEventBodyResourceRefsItem=_attr(
            "models.create_chat_workflow_event_body_resource_refs_item",
            "CreateChatWorkflowEventBodyResourceRefsItem",
        ),
        UpdateChatWorkflowEventBody=_attr(
            "models.update_chat_workflow_event_body", "UpdateChatWorkflowEventBody"
        ),
        UpdateChatWorkflowEventBodyDecisionStatesType0=_attr(
            "models.update_chat_workflow_event_body_decision_states_type_0",
            "UpdateChatWorkflowEventBodyDecisionStatesType0",
        ),
        UpdateChatWorkflowEventBodyFinalStateType0=_attr(
            "models.update_chat_workflow_event_body_final_state_type_0",
            "UpdateChatWorkflowEventBodyFinalStateType0",
        ),
        UpdateChatWorkflowEventBodyMetadataType0=_attr(
            "models.update_chat_workflow_event_body_metadata_type_0",
            "UpdateChatWorkflowEventBodyMetadataType0",
        ),
        UpdateChatWorkflowEventBodyRationalesType0=_attr(
            "models.update_chat_workflow_event_body_rationales_type_0",
            "UpdateChatWorkflowEventBodyRationalesType0",
        ),
        RelationshipRequestBody=_attr(
            "models.relationship_request_body", "RelationshipRequestBody"
        ),
        RelationshipActionBody=_attr(
            "models.relationship_action_body", "RelationshipActionBody"
        ),
        login_sync=_attr("api.auth.login_api_auth_login_post", "sync_detailed"),
        send_otp_sync=_attr(
            "api.auth.send_otp_api_auth_send_otp_post", "sync_detailed"
        ),
        verify_otp_sync=_attr(
            "api.auth.verify_otp_api_auth_verify_otp_post", "sync_detailed"
        ),
        complete_register_sync=_attr(
            "api.auth.complete_register_api_auth_complete_register_post",
            "sync_detailed",
        ),
        me_sync=_attr("api.auth.me_api_auth_me_get", "sync_detailed"),
        create_external_user_sync=_attr(
            "api.auth.create_external_user_api_auth_external_users_post",
            "sync_detailed",
        ),
        list_agents_sync=_attr(
            "api.panel.list_agents_api_panel_agents_get", "sync_detailed"
        ),
        create_agent_sync=_attr(
            "api.panel.create_agent_api_panel_agents_post", "sync_detailed"
        ),
        create_thread_sync=_attr(
            "api.threads.create_thread_api_threads_post", "sync_detailed"
        ),
        list_chats_sync=_attr("api.chats.list_chats_api_chats_get", "sync_detailed"),
        create_chat_sync=_attr("api.chats.create_chat_api_chats_post", "sync_detailed"),
        get_chat_sync=_attr(
            "api.chats.get_chat_api_chats_chat_id_get", "sync_detailed"
        ),
        get_chat_join_target_sync=_attr(
            "api.chats.get_chat_join_target_api_chats_chat_id_join_target_get",
            "sync_detailed",
        ),
        add_chat_member_sync=_attr(
            "api.chats.add_chat_member_api_chats_chat_id_members_post",
            "sync_detailed",
        ),
        list_chat_join_requests_sync=_attr(
            "api.chats.list_chat_join_requests_api_chats_chat_id_join_requests_get",
            "sync_detailed",
        ),
        request_chat_join_sync=_attr(
            "api.chats.request_chat_join_api_chats_chat_id_join_requests_post",
            "sync_detailed",
        ),
        approve_chat_join_sync=_attr(
            "api.chats.approve_chat_join_api_chats_chat_id_join_requests_request_id_approve_post",
            "sync_detailed",
        ),
        reject_chat_join_sync=_attr(
            "api.chats.reject_chat_join_api_chats_chat_id_join_requests_request_id_reject_post",
            "sync_detailed",
        ),
        mute_chat_sync=_attr(
            "api.chats.mute_chat_api_chats_chat_id_mute_post", "sync_detailed"
        ),
        list_messages_sync=_attr(
            "api.chats.list_messages_api_chats_chat_id_messages_get", "sync_detailed"
        ),
        list_unread_messages_sync=_attr(
            "api.chats.list_unread_messages_api_chats_chat_id_messages_unread_get",
            "sync_detailed",
        ),
        read_unread_messages_sync=_attr(
            "api.chats.read_unread_messages_api_chats_chat_id_messages_read_post",
            "sync_detailed",
        ),
        mark_read_sync=_attr(
            "api.chats.mark_read_api_chats_chat_id_read_post", "sync_detailed"
        ),
        send_message_sync=_attr(
            "api.chats.send_message_api_chats_chat_id_messages_post", "sync_detailed"
        ),
        get_chat_workflow_sync=_attr(
            "api.chats.get_chat_workflow_api_chats_chat_id_workflow_get",
            "sync_detailed",
        ),
        set_chat_workflow_sync=_attr(
            "api.chats.set_chat_workflow_api_chats_chat_id_workflow_put",
            "sync_detailed",
        ),
        delete_chat_workflow_sync=_attr(
            "api.chats.delete_chat_workflow_api_chats_chat_id_workflow_delete",
            "sync_detailed",
        ),
        list_chat_workflow_events_sync=_attr(
            "api.chats.list_chat_workflow_events_api_chats_chat_id_workflow_events_get",
            "sync_detailed",
        ),
        create_chat_workflow_event_sync=_attr(
            "api.chats.create_chat_workflow_event_api_chats_chat_id_workflow_events_post",
            "sync_detailed",
        ),
        get_chat_workflow_event_sync=_attr(
            "api.chats.get_chat_workflow_event_api_chats_chat_id_workflow_events_event_id_get",
            "sync_detailed",
        ),
        update_chat_workflow_event_sync=_attr(
            "api.chats.update_chat_workflow_event_api_chats_chat_id_workflow_events_event_id_patch",
            "sync_detailed",
        ),
        delete_chat_workflow_event_sync=_attr(
            "api.chats.delete_chat_workflow_event_api_chats_chat_id_workflow_events_event_id_delete",
            "sync_detailed",
        ),
        list_chat_tasks_sync=_attr(
            "api.chats.list_chat_tasks_api_chats_chat_id_tasks_get", "sync_detailed"
        ),
        create_chat_task_sync=_attr(
            "api.chats.create_chat_task_api_chats_chat_id_tasks_post", "sync_detailed"
        ),
        get_chat_task_sync=_attr(
            "api.chats.get_chat_task_api_chats_chat_id_tasks_task_id_get",
            "sync_detailed",
        ),
        update_chat_task_sync=_attr(
            "api.chats.update_chat_task_api_chats_chat_id_tasks_task_id_patch",
            "sync_detailed",
        ),
        delete_chat_task_sync=_attr(
            "api.chats.delete_chat_task_api_chats_chat_id_tasks_task_id_delete",
            "sync_detailed",
        ),
        list_relationships_sync=_attr(
            "api.relationships.list_relationships_api_relationships_get",
            "sync_detailed",
        ),
        request_relationship_sync=_attr(
            "api.relationships.request_relationship_api_relationships_request_post",
            "sync_detailed",
        ),
        approve_relationship_sync=_attr(
            "api.relationships.approve_relationship_api_relationships_relationship_id_approve_post",
            "sync_detailed",
        ),
        reject_relationship_sync=_attr(
            "api.relationships.reject_relationship_api_relationships_relationship_id_reject_post",
            "sync_detailed",
        ),
        upgrade_relationship_sync=_attr(
            "api.relationships.upgrade_relationship_api_relationships_relationship_id_upgrade_post",
            "sync_detailed",
        ),
        revoke_relationship_sync=_attr(
            "api.relationships.revoke_relationship_api_relationships_relationship_id_revoke_post",
            "sync_detailed",
        ),
        downgrade_relationship_sync=_attr(
            "api.relationships.downgrade_relationship_api_relationships_relationship_id_downgrade_post",
            "sync_detailed",
        ),
        drain_runtime_inbox_sync=_attr(
            "api.runtime.drain_runtime_inbox_api_runtime_inbox_drain_post",
            "sync_detailed",
        ),
        wait_runtime_inbox_sync=_attr(
            "api.runtime.wait_runtime_inbox_api_runtime_inbox_wait_post",
            "sync_detailed",
        ),
        UnexpectedStatus=_attr("errors", "UnexpectedStatus"),
    )


class _GeneratedAuthApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def login(self, identifier: str, password: str) -> dict[str, Any] | None:
        body = self._owner.bundle.LoginRequest(identifier=identifier, password=password)
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.login_sync, client=self._owner._client(), body=body
            )
        )

    def send_otp(
        self, email: str, password: str, invite_code: str
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.SendOtpRequest(
            email=email, password=password, invite_code=invite_code
        )
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.send_otp_sync,
                client=self._owner._client(),
                body=body,
            )
        )

    def verify_otp(self, email: str, token: str) -> dict[str, Any] | None:
        body = self._owner.bundle.VerifyOtpRequest(email=email, token=token)
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.verify_otp_sync,
                client=self._owner._client(),
                body=body,
            )
        )

    def complete_register(
        self, temp_token: str, invite_code: str
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.CompleteRegisterRequest(
            temp_token=temp_token, invite_code=invite_code
        )
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.complete_register_sync,
                client=self._owner._client(),
                body=body,
            )
        )

    def create_external_user(
        self, user_id: str, display_name: str
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.CreateExternalUserRequest(
            user_id=user_id, display_name=display_name
        )
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.create_external_user_sync,
                client=self._owner._authenticated_client(),
                body=body,
            )
        )


class _GeneratedMeApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def whoami(self) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(self._owner.bundle.me_sync, client=client)
        )


class _GeneratedAgentsApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def list(self) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(self._owner.bundle.list_agents_sync, client=client)
        )

    def create(self, name: str, *, description: str = "") -> dict[str, Any] | None:
        body = self._owner.bundle.CreateAgentRequest(name=name, description=description)
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.create_agent_sync, client=client, body=body
            )
        )


class _GeneratedThreadsApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def create(
        self,
        managed_agent_id: str,
        *,
        sandbox: str = "local",
        sandbox_template_id: str | None = None,
        existing_sandbox_id: str | None = None,
        cwd: str | None = None,
        model: str | None = None,
        agent: str | None = None,
        bind_mounts: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.CreateThreadRequest(
            agent_user_id=managed_agent_id,
            sandbox=sandbox,
            sandbox_template_id=sandbox_template_id,
            existing_sandbox_id=existing_sandbox_id,
            cwd=cwd,
            model=model,
            agent=agent,
            bind_mounts=self._bind_mounts(bind_mounts),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.create_thread_sync, client=client, body=body
            )
        )

    def _bind_mounts(
        self, bind_mounts: list[dict[str, Any]] | None
    ) -> list[Any] | None:
        if bind_mounts is None:
            return self._owner.bundle.UNSET
        mounts = []
        for item in bind_mounts:
            mode = item.get("mode")
            if isinstance(mode, str):
                mode = self._owner.bundle.MountSpecMode(mode)
            if mode is None:
                mode = self._owner.bundle.MountSpecMode("mount")
            mounts.append(
                self._owner.bundle.MountSpec(
                    source=item["source"],
                    target=item["target"],
                    mode=mode,
                    read_only=bool(item.get("read_only", False)),
                )
            )
        return mounts


class _GeneratedUsersApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def create_external(self, user_id: str, display_name: str) -> dict[str, Any] | None:
        return self._owner.auth.create_external_user(user_id, display_name)


class _GeneratedChatsApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def list(self) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(self._owner.bundle.list_chats_sync, client=client)
        )

    def get(self, chat_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.get_chat_sync, client=client, chat_id=chat_id
            )
        )

    def join_target(self, chat_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.get_chat_join_target_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def add_member(self, chat_id: str, user_id: str) -> dict[str, Any] | None:
        body = self._owner.bundle.ChatMemberAddBody(user_id=user_id)
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.add_chat_member_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )

    def create(
        self, user_ids: list[str], *, title: str | None = None, kind: str = "auto"
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.CreateChatBody(
            user_ids=user_ids,
            title=title,
            kind=self._owner.bundle.CreateChatBodyKind(kind),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.create_chat_sync, client=client, body=body
            )
        )

    def direct(self, target_id: str) -> dict[str, Any] | None:
        return self._find_or_create_with_current_user(target_id)

    def ensure_direct(self, target_id: str) -> dict[str, Any] | None:
        return self._find_or_create_with_current_user(target_id)

    def list_join_requests(self, chat_id: str) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.list_chat_join_requests_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def request_join(
        self, chat_id: str, *, message: str | None = None
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.ChatJoinRequestBody(message=message)
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.request_chat_join_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )

    def approve_join(self, chat_id: str, request_id: str) -> dict[str, Any] | None:
        return self._join_action(
            self._owner.bundle.approve_chat_join_sync, chat_id, request_id
        )

    def reject_join(self, chat_id: str, request_id: str) -> dict[str, Any] | None:
        return self._join_action(
            self._owner.bundle.reject_chat_join_sync, chat_id, request_id
        )

    def mute_member(
        self, chat_id: str, user_id: str, *, mute_until: float | None = None
    ) -> dict[str, Any] | None:
        return self._set_member_mute(
            chat_id, user_id, muted=True, mute_until=mute_until
        )

    def unmute_member(self, chat_id: str, user_id: str) -> dict[str, Any] | None:
        return self._set_member_mute(chat_id, user_id, muted=False)

    def get_workflow(self, chat_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.get_chat_workflow_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def set_workflow(
        self,
        chat_id: str,
        *,
        kind: str,
        state: str = "active",
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.SetChatWorkflowBody(
            kind=kind,
            state=state,
            config=_generated_dict_model(
                self._owner.bundle, "SetChatWorkflowBodyConfig", config
            ),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.set_chat_workflow_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )

    def delete_workflow(self, chat_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.delete_chat_workflow_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def list_workflow_events(self, chat_id: str) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.list_chat_workflow_events_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def create_workflow_event(
        self,
        chat_id: str,
        *,
        kind: str,
        resource_refs: list[dict[str, Any]] | None = None,
        requested_by_user_id: str | None = None,
        decision_states: dict[str, dict[str, str]] | None = None,
        rationales: dict[str, Any] | None = None,
        final_state: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.CreateChatWorkflowEventBody(
            kind=kind,
            resource_refs=_generated_dict_model_list(
                self._owner.bundle,
                "CreateChatWorkflowEventBodyResourceRefsItem",
                resource_refs,
            ),
            requested_by_user_id=_unset_if_none(
                self._owner.bundle, requested_by_user_id
            ),
            decision_states=_generated_dict_model(
                self._owner.bundle,
                "CreateChatWorkflowEventBodyDecisionStates",
                decision_states,
            ),
            rationales=_generated_dict_model(
                self._owner.bundle, "CreateChatWorkflowEventBodyRationales", rationales
            ),
            final_state=_generated_dict_model(
                self._owner.bundle, "CreateChatWorkflowEventBodyFinalState", final_state
            ),
            metadata=_generated_dict_model(
                self._owner.bundle, "CreateChatWorkflowEventBodyMetadata", metadata
            ),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.create_chat_workflow_event_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )

    def get_workflow_event(self, chat_id: str, event_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.get_chat_workflow_event_sync,
                client=client,
                chat_id=chat_id,
                event_id=event_id,
            )
        )

    def update_workflow_event(
        self,
        chat_id: str,
        event_id: str,
        *,
        state: Any = _OMIT,
        decision_states: Any = _OMIT,
        rationales: Any = _OMIT,
        final_state: Any = _OMIT,
        metadata: Any = _OMIT,
        settled_at: Any = _OMIT,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.UpdateChatWorkflowEventBody(
            state=_unset_if_omit(self._owner.bundle, state),
            decision_states=_generated_dict_model_or_unset(
                self._owner.bundle,
                "UpdateChatWorkflowEventBodyDecisionStatesType0",
                decision_states,
            ),
            rationales=_generated_dict_model_or_unset(
                self._owner.bundle,
                "UpdateChatWorkflowEventBodyRationalesType0",
                rationales,
            ),
            final_state=_generated_dict_model_or_unset(
                self._owner.bundle,
                "UpdateChatWorkflowEventBodyFinalStateType0",
                final_state,
            ),
            metadata=_generated_dict_model_or_unset(
                self._owner.bundle,
                "UpdateChatWorkflowEventBodyMetadataType0",
                metadata,
            ),
            settled_at=_unset_if_omit(self._owner.bundle, settled_at),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.update_chat_workflow_event_sync,
                client=client,
                chat_id=chat_id,
                event_id=event_id,
                body=body,
            )
        )

    def delete_workflow_event(
        self, chat_id: str, event_id: str
    ) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.delete_chat_workflow_event_sync,
                client=client,
                chat_id=chat_id,
                event_id=event_id,
            )
        )

    def list_tasks(self, chat_id: str) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.list_chat_tasks_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def create_task(
        self,
        chat_id: str,
        *,
        subject: str,
        description: str = "",
        status: str = "pending",
        active_form: str | None = None,
        owner: str | None = None,
        blocks: list[str] | None = None,
        blocked_by: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.CreateChatTaskBody(
            subject=subject,
            description=description,
            status=status,
            active_form=_unset_if_none(self._owner.bundle, active_form),
            owner=_unset_if_none(self._owner.bundle, owner),
            blocks=_unset_if_none(self._owner.bundle, blocks),
            blocked_by=_unset_if_none(self._owner.bundle, blocked_by),
            metadata=_generated_dict_model(
                self._owner.bundle, "CreateChatTaskBodyMetadata", metadata
            ),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.create_chat_task_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )

    def get_task(self, chat_id: str, task_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.get_chat_task_sync,
                client=client,
                chat_id=chat_id,
                task_id=task_id,
            )
        )

    def update_task(
        self,
        chat_id: str,
        task_id: str,
        *,
        status: Any = _OMIT,
        subject: Any = _OMIT,
        description: Any = _OMIT,
        active_form: Any = _OMIT,
        owner: Any = _OMIT,
        blocks: Any = _OMIT,
        blocked_by: Any = _OMIT,
        metadata: Any = _OMIT,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.UpdateChatTaskBody(
            status=_unset_if_omit(self._owner.bundle, status),
            subject=_unset_if_omit(self._owner.bundle, subject),
            description=_unset_if_omit(self._owner.bundle, description),
            active_form=_unset_if_omit(self._owner.bundle, active_form),
            owner=_unset_if_omit(self._owner.bundle, owner),
            blocks=_unset_if_omit(self._owner.bundle, blocks),
            blocked_by=_unset_if_omit(self._owner.bundle, blocked_by),
            metadata=_generated_dict_model(
                self._owner.bundle,
                "UpdateChatTaskBodyMetadataType0",
                None if metadata is _OMIT else metadata,
            ),
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.update_chat_task_sync,
                client=client,
                chat_id=chat_id,
                task_id=task_id,
                body=body,
            )
        )

    def delete_task(self, chat_id: str, task_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.delete_chat_task_sync,
                client=client,
                chat_id=chat_id,
                task_id=task_id,
            )
        )

    def _set_member_mute(
        self,
        chat_id: str,
        user_id: str,
        *,
        muted: bool,
        mute_until: float | None = None,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.MuteChatBody(
            user_id=user_id, muted=muted, mute_until=mute_until
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.mute_chat_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )

    def _join_action(
        self, operation: Any, chat_id: str, request_id: str
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.ChatJoinRequestActionBody()
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                operation,
                client=client,
                chat_id=chat_id,
                request_id=request_id,
                body=body,
            )
        )

    def _find_or_create_with_current_user(
        self, target_id: str
    ) -> dict[str, Any] | None:
        return self.create([target_id], kind="direct")


def _generated_dict_model(
    bundle: Any, model_name: str, value: dict[str, Any] | None
) -> Any:
    if value is None:
        return bundle.UNSET
    model = getattr(bundle, model_name, None)
    if model is None:
        return value
    if hasattr(model, "from_dict"):
        return model.from_dict(value)
    try:
        instance = model()
    except TypeError:
        return value
    if hasattr(instance, "additional_properties"):
        instance.additional_properties = dict(value)
        return instance
    return value


def _generated_dict_model_or_unset(bundle: Any, model_name: str, value: Any) -> Any:
    if value is _OMIT:
        return bundle.UNSET
    if value is None:
        return None
    return _generated_dict_model(bundle, model_name, value)


def _generated_dict_model_list(
    bundle: Any, model_name: str, values: list[dict[str, Any]] | None
) -> Any:
    if values is None:
        return bundle.UNSET
    model = getattr(bundle, model_name, None)
    if model is None or not hasattr(model, "from_dict"):
        return values
    return [model.from_dict(value) for value in values]


def _unset_if_none(bundle: Any, value: Any) -> Any:
    if value is None:
        return bundle.UNSET
    return value


def _unset_if_omit(bundle: Any, value: Any) -> Any:
    if value is _OMIT:
        return bundle.UNSET
    return value


class _GeneratedMessagesApi:
    _MAX_PAGE_SIZE = 200

    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def list(
        self, chat_id: str, *, limit: int = 50, before: str | None = None
    ) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.list_messages_sync,
                client=client,
                chat_id=chat_id,
                limit=limit,
                before=before,
            )
        )

    def list_all(
        self,
        chat_id: str,
        *,
        max_messages: int | None = None,
        page_size: int = _MAX_PAGE_SIZE,
        before: str | None = None,
    ) -> list[dict[str, Any]]:
        if page_size < 1 or page_size > self._MAX_PAGE_SIZE:
            raise ValueError("page_size must be between 1 and 200")
        if max_messages is not None and max_messages < 1:
            raise ValueError("max_messages must be at least 1")

        remaining = max_messages
        cursor = before
        collected: list[dict[str, Any]] = []
        while remaining is None or remaining > 0:
            current_limit = (
                page_size if remaining is None else min(page_size, remaining)
            )
            page = self.list(chat_id, limit=current_limit, before=cursor) or []
            if not isinstance(page, list):
                raise RuntimeError("message page response is invalid")
            if not page:
                break

            collected = page + collected
            if remaining is not None:
                remaining -= len(page)
                if remaining <= 0:
                    break
            if len(page) < current_limit:
                break

            oldest = page[0]
            if not isinstance(oldest, dict) or oldest.get("seq") is None:
                raise RuntimeError("message seq is required to continue pagination")
            next_cursor = str(oldest["seq"])
            if next_cursor == cursor:
                raise RuntimeError("message pagination cursor did not advance")
            cursor = next_cursor

        return collected

    def unread(self, chat_id: str) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.list_unread_messages_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def read(self, chat_id: str) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.read_unread_messages_sync,
                client=client,
                chat_id=chat_id,
            )
        )

    def mark_read(self, chat_id: str) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        payload = _normalize_result(
            self._owner._request(
                self._owner.bundle.mark_read_sync, client=client, chat_id=chat_id
            )
        )
        return payload or {"status": "ok", "chat_id": chat_id}

    def send(
        self,
        chat_id: str,
        content: str,
        *,
        reply_to: str | None = None,
        mentions: list[str] | None = None,
        delivery_scope: str = "broadcast",
        addressed_to_user_ids: list[str] | None = None,
        enforce_caught_up: bool = True,
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.SendMessageBody(
            content=content,
            mentioned_ids=mentions,
            delivery_scope=self._owner.bundle.SendMessageBodyDeliveryScope(
                delivery_scope
            ),
            addressed_to_user_ids=_unset_if_none(
                self._owner.bundle, addressed_to_user_ids
            ),
            reply_to=reply_to,
            enforce_caught_up=enforce_caught_up,
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.send_message_sync,
                client=client,
                chat_id=chat_id,
                body=body,
            )
        )


class _GeneratedRelationshipsApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def list(self) -> list[dict[str, Any]] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.list_relationships_sync, client=client
            )
        )

    def request(
        self, target_user_id: str, message: str | None = None
    ) -> dict[str, Any] | None:
        body = self._owner.bundle.RelationshipRequestBody(
            target_user_id=target_user_id,
            message=message,
        )
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.request_relationship_sync, client=client, body=body
            )
        )

    def approve(self, relationship_id: str) -> dict[str, Any] | None:
        return self._action(
            self._owner.bundle.approve_relationship_sync, relationship_id
        )

    def reject(self, relationship_id: str) -> dict[str, Any] | None:
        return self._action(
            self._owner.bundle.reject_relationship_sync, relationship_id
        )

    def upgrade(self, relationship_id: str) -> dict[str, Any] | None:
        return self._action(
            self._owner.bundle.upgrade_relationship_sync, relationship_id
        )

    def revoke(self, relationship_id: str) -> dict[str, Any] | None:
        return self._action(
            self._owner.bundle.revoke_relationship_sync, relationship_id
        )

    def downgrade(self, relationship_id: str) -> dict[str, Any] | None:
        return self._action(
            self._owner.bundle.downgrade_relationship_sync, relationship_id
        )

    def _action(self, operation: Any, relationship_id: str) -> dict[str, Any] | None:
        body = self._owner.bundle.RelationshipActionBody()
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                operation,
                client=client,
                relationship_id=relationship_id,
                body=body,
            )
        )


class _GeneratedNotificationsApi:
    def __init__(self, owner: GeneratedClientAdapter) -> None:
        self._owner = owner

    def drain(self) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.drain_runtime_inbox_sync,
                client=client,
            )
        )

    def wait(self, *, timeout_seconds: float = 25.0) -> dict[str, Any] | None:
        client = self._owner._authenticated_client()
        return _normalize_result(
            self._owner._request(
                self._owner.bundle.wait_runtime_inbox_sync,
                client=client,
                timeout_seconds=timeout_seconds,
            )
        )

    def stream(
        self,
        *,
        since_seq: int | None = None,
        timeout: float | None = None,
        should_stop: Callable[[], bool] | None = None,
    ):
        token = self._owner.auth_token
        if not token:
            raise RuntimeError("auth_token is required for notification stream")
        websocket = _load_websocket_module()
        socket_timeout = timeout
        if should_stop is not None and socket_timeout is None:
            socket_timeout = 1.0
        socket = websocket.create_connection(
            _runtime_inbox_ws_url(self._owner.base_url),
            header=[f"Authorization: Bearer {token}"],
            timeout=socket_timeout,
        )
        timeout_exception = getattr(websocket, "WebSocketTimeoutException", None)
        try:
            if since_seq is not None:
                socket.send(json.dumps({"type": "resume", "since_seq": since_seq}))
            while True:
                if should_stop is not None and should_stop():
                    return
                try:
                    raw = socket.recv()
                except Exception as exc:
                    if timeout_exception is not None and isinstance(
                        exc, timeout_exception
                    ):
                        continue
                    raise ConnectionClosed("runtime inbox stream closed") from exc
                if not raw:
                    raise ConnectionClosed("runtime inbox stream closed")
                frame = json.loads(raw)
                if frame.get("type") == "replay_overflow":
                    raise ReplayOverflow(frame)
                if frame.get("type") == "notify":
                    yield frame
        finally:
            socket.close()


def _runtime_inbox_ws_url(base_url: str) -> str:
    stripped = base_url.rstrip("/")
    if stripped.startswith("https://"):
        return "wss://" + stripped[len("https://") :] + "/api/runtime/inbox/subscribe"
    if stripped.startswith("http://"):
        return "ws://" + stripped[len("http://") :] + "/api/runtime/inbox/subscribe"
    raise RuntimeError("base_url must start with http:// or https://")


def _load_websocket_module() -> Any:
    try:
        return import_module("websocket")
    except ImportError as exc:
        raise RuntimeError(
            "websocket-client is required for notification stream"
        ) from exc


@dataclass(frozen=True)
class GeneratedClientAdapter:
    bundle: Any
    base_url: str
    auth_token: str | None = None
    me: Any = None
    auth: Any = None
    agents: Any = None
    threads: Any = None
    users: Any = None
    chats: Any = None
    messages: Any = None
    relationships: Any = None
    notifications: Any = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "me", _GeneratedMeApi(self))
        object.__setattr__(self, "auth", _GeneratedAuthApi(self))
        object.__setattr__(self, "agents", _GeneratedAgentsApi(self))
        object.__setattr__(self, "threads", _GeneratedThreadsApi(self))
        object.__setattr__(self, "users", _GeneratedUsersApi(self))
        object.__setattr__(self, "chats", _GeneratedChatsApi(self))
        object.__setattr__(self, "messages", _GeneratedMessagesApi(self))
        object.__setattr__(self, "relationships", _GeneratedRelationshipsApi(self))
        object.__setattr__(self, "notifications", _GeneratedNotificationsApi(self))

    @classmethod
    def from_package(
        cls, package_name: str, *, base_url: str, auth_token: str | None = None
    ) -> GeneratedClientAdapter:
        return cls(
            bundle=load_generated_bundle(package_name),
            base_url=base_url,
            auth_token=auth_token,
        )

    @classmethod
    def from_generated_root(
        cls,
        package_root: str | Path,
        *,
        base_url: str,
        auth_token: str | None = None,
    ) -> GeneratedClientAdapter:
        root = Path(package_root)
        package_dirs = [path.name for path in root.iterdir() if path.is_dir()]
        package_name = next(
            (name for name in package_dirs if name.endswith("_client")), None
        )
        if package_name is None and len(package_dirs) == 1:
            package_name = package_dirs[0]
        if package_name is None:
            raise RuntimeError(f"Could not infer generated package name under {root}")

        root_str = str(root)
        old_sys_path = list(sys.path)
        sys.path.insert(0, root_str)
        try:
            return cls.from_package(
                package_name, base_url=base_url, auth_token=auth_token
            )
        finally:
            sys.path[:] = old_sys_path

    def _client(self) -> Any:
        return self.bundle.Client(
            base_url=self.base_url,
            raise_on_unexpected_status=True,
            httpx_args={"trust_env": False},
        )

    def _authenticated_client(self) -> Any:
        if not self.auth_token:
            raise RuntimeError(
                "auth_token is required for generated adapter authenticated calls"
            )
        return self.bundle.AuthenticatedClient(
            base_url=self.base_url,
            token=self.auth_token,
            raise_on_unexpected_status=True,
            httpx_args={"trust_env": False},
        )

    def _request(self, operation: Any, **kwargs: Any) -> Any:
        try:
            result = operation(**kwargs)
            if hasattr(result, "parsed") and hasattr(result, "content"):
                status_code = int(getattr(result, "status_code", 0) or 0)
                if status_code >= 400:
                    raise ApiError.from_response_content(status_code, result.content)
                if result.parsed is not None:
                    return result.parsed
                try:
                    return json.loads(result.content)
                except (TypeError, ValueError):
                    return result.parsed
            return result
        except Exception as exc:
            unexpected_status = getattr(self.bundle, "UnexpectedStatus", None)
            if unexpected_status is not None and isinstance(exc, unexpected_status):
                raise ApiError.from_response_content(
                    exc.status_code, exc.content
                ) from exc
            if isinstance(exc, httpx.TransportError):
                raise ApiError(0, f"transport error: {exc}") from exc
            raise
