"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => IgrepSearchPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian2 = require("obsidian");

// src/search-modal.ts
var import_obsidian = require("obsidian");

// src/igrep-bridge.ts
var import_child_process = require("child_process");
var TIMEOUT_MS = 3e4;
var cachedEnv = null;
function resolveEnv() {
  if (cachedEnv) return cachedEnv;
  const shell = process.env.SHELL || "/bin/zsh";
  try {
    const output = (0, import_child_process.execSync)(
      `${shell} -l -c 'echo "$PATH"; which igrep'`,
      { timeout: 5e3 }
    ).toString().trim();
    const lines = output.split("\n");
    const shellPath = lines[0] || "";
    const igrepBin = lines[1]?.trim() || "igrep";
    cachedEnv = {
      bin: igrepBin,
      env: { ...process.env, PATH: shellPath }
    };
  } catch {
    cachedEnv = {
      bin: "igrep",
      env: process.env
    };
  }
  return cachedEnv;
}
function searchVault(query, vaultPath, topK = 30) {
  return new Promise((resolve, reject) => {
    const { bin, env } = resolveEnv();
    const args = ["search", "--format", "obsidian", "-m", String(topK), query, vaultPath];
    (0, import_child_process.execFile)(bin, args, { timeout: TIMEOUT_MS, maxBuffer: 8 * 1024 * 1024, env }, (err, stdout, stderr) => {
      if (err) {
        reject(new Error(`igrep failed: ${stderr || err.message}`));
        return;
      }
      const trimmed = stdout.trim();
      if (!trimmed) {
        resolve([]);
        return;
      }
      try {
        const results = trimmed.split("\n").filter((line) => line.trim()).map((line) => JSON.parse(line));
        resolve(results);
      } catch (e) {
        reject(new Error(`Failed to parse igrep output: ${e}`));
      }
    });
  });
}
function checkIgrepInstalled() {
  return new Promise((resolve) => {
    const { bin, env } = resolveEnv();
    (0, import_child_process.execFile)(bin, ["--version"], { timeout: 5e3, env }, (err) => {
      resolve(!err);
    });
  });
}

// src/search-modal.ts
var MAX_HISTORY = 20;
var IgrepSearchModal = class extends import_obsidian.Modal {
  constructor(app, vaultPath, state, history) {
    super(app);
    this.historyIndex = -1;
    this.historyDraft = "";
    this.showingHistory = false;
    /** Track which file-level results are expanded to show all matches */
    this.expandedFiles = /* @__PURE__ */ new Set();
    /** True after ↑↓ navigation; Enter opens instead of searching */
    this.hasNavigated = false;
    this.vaultPath = vaultPath;
    this.state = state;
    this.history = history;
  }
  onOpen() {
    const { contentEl } = this;
    this.modalEl.addClass("igrep-search-modal");
    contentEl.addClass("igrep-search-content");
    const modeBar = contentEl.createDiv("igrep-mode-bar");
    modeBar.addEventListener("mousedown", (e) => e.preventDefault());
    this.vaultTabEl = modeBar.createSpan({ text: "Vault", cls: "igrep-mode-tab is-active" });
    this.vaultTabEl.addEventListener("click", () => {
      if (this.showingHistory) this.toggleHistory();
    });
    this.historyTabEl = modeBar.createSpan({ text: "History", cls: "igrep-mode-tab" });
    this.historyTabEl.addEventListener("click", () => this.toggleHistory());
    const inputContainer = contentEl.createDiv("igrep-search-input-container");
    this.inputEl = inputContainer.createEl("input", {
      type: "text",
      placeholder: "Search vault...",
      cls: "igrep-search-input"
    });
    const editorSelection = this.app.workspace.activeEditor?.editor?.getSelection()?.trim();
    if (editorSelection) {
      this.inputEl.value = editorSelection;
    } else if (this.state.query) {
      this.inputEl.value = this.state.query;
    }
    this.inputEl.focus();
    if (this.inputEl.value) {
      this.inputEl.select();
    }
    const hint = contentEl.createDiv("igrep-search-hint");
    hint.innerHTML = "<span><kbd>Enter</kbd> search</span><span><kbd>\u2318Enter</kbd> open</span><span><kbd>\u21E7Enter</kbd> bg</span><span><kbd>\u2191\u2193</kbd> nav</span><span><kbd>\u2325\u2191\u2193</kbd> history</span>";
    this.resultsEl = contentEl.createDiv("igrep-search-results");
    this.resultsEl.addEventListener("mousedown", (e) => e.preventDefault());
    const currentInput = this.inputEl.value.trim();
    if (this.state.results.length > 0 && currentInput === this.state.query) {
      this.renderResults();
    } else if (this.state.results.length > 0) {
      this.state.results = [];
      this.state.selectedIndex = 0;
      this.state.openedIndices = [];
    }
    this.inputEl.addEventListener("input", () => {
      this.hasNavigated = false;
    });
    this.inputEl.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.isComposing) {
        e.preventDefault();
        if (e.ctrlKey || e.metaKey) {
          this.openAndClose();
        } else if (e.shiftKey) {
          this.openInBackground();
        } else if (this.hasNavigated && this.state.results.length > 0) {
          this.openAndClose();
        } else {
          this.doSearch();
        }
      } else if (e.key === "ArrowDown") {
        e.preventDefault();
        if (e.altKey) {
          this.historyNext();
        } else {
          this.hasNavigated = true;
          this.selectNext();
        }
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (e.altKey) {
          this.historyPrev();
        } else {
          this.hasNavigated = true;
          this.selectPrev();
        }
      }
    });
  }
  async doSearch() {
    const query = this.inputEl.value.trim();
    if (!query) return;
    if (this.showingHistory) {
      this.showingHistory = false;
      this.historyTabEl.removeClass("is-active");
      this.vaultTabEl.addClass("is-active");
    }
    this.resultsEl.empty();
    this.resultsEl.createDiv({ text: "Searching...", cls: "igrep-search-loading" });
    try {
      this.state.results = await searchVault(query, this.vaultPath);
      this.state.query = query;
      this.state.selectedIndex = 0;
      this.state.openedIndices = [];
      this.expandedFiles.clear();
      this.historyIndex = -1;
      this.hasNavigated = false;
      this.addToHistory(query, this.state.results);
      this.renderResults();
    } catch (err) {
      this.resultsEl.empty();
      this.resultsEl.createDiv({
        text: `Error: ${err instanceof Error ? err.message : String(err)}`,
        cls: "igrep-search-error"
      });
    }
  }
  addToHistory(query, results) {
    const idx = this.history.findIndex((e) => e.query === query);
    if (idx >= 0) this.history.splice(idx, 1);
    this.history.unshift({ query, results });
    if (this.history.length > MAX_HISTORY) {
      this.history.length = MAX_HISTORY;
    }
  }
  historyPrev() {
    if (this.history.length === 0) return;
    if (this.historyIndex === -1) {
      this.historyDraft = this.inputEl.value;
    }
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this.inputEl.value = this.history[this.historyIndex].query;
      this.inputEl.select();
    }
  }
  historyNext() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.inputEl.value = this.history[this.historyIndex].query;
      this.inputEl.select();
    } else if (this.historyIndex === 0) {
      this.historyIndex = -1;
      this.inputEl.value = this.historyDraft;
      this.inputEl.select();
    }
  }
  toggleHistory() {
    if (this.showingHistory) {
      this.showingHistory = false;
      this.historyTabEl.removeClass("is-active");
      this.vaultTabEl.addClass("is-active");
      if (this.state.results.length > 0) {
        this.renderResults();
      } else {
        this.resultsEl.empty();
      }
    } else {
      this.vaultTabEl.removeClass("is-active");
      this.historyTabEl.addClass("is-active");
      this.renderHistory();
    }
  }
  renderHistory() {
    this.resultsEl.empty();
    this.showingHistory = true;
    if (this.history.length === 0) {
      this.resultsEl.createDiv({ text: "No recent searches", cls: "igrep-search-empty" });
      return;
    }
    this.resultsEl.createDiv({
      text: "Recent searches",
      cls: "igrep-history-header"
    });
    this.history.forEach((entry) => {
      const item = this.resultsEl.createDiv("igrep-history-item");
      const icon = item.createSpan("igrep-history-item-icon");
      (0, import_obsidian.setIcon)(icon, "clock");
      const label = entry.results.length > 0 ? `${entry.query}  (${entry.results.length} files)` : entry.query;
      item.createSpan({ text: label, cls: "igrep-history-item-text" });
      item.addEventListener("click", () => {
        this.inputEl.value = entry.query;
        this.showingHistory = false;
        this.historyTabEl.removeClass("is-active");
        this.vaultTabEl.addClass("is-active");
        if (entry.results.length > 0) {
          this.state.query = entry.query;
          this.state.results = entry.results;
          this.state.selectedIndex = 0;
          this.state.openedIndices = [];
          this.expandedFiles.clear();
          this.hasNavigated = false;
          this.renderResults();
        } else {
          this.doSearch();
        }
      });
    });
  }
  renderResults() {
    this.resultsEl.empty();
    if (this.state.results.length === 0) {
      this.resultsEl.createDiv({ text: "No results found.", cls: "igrep-search-empty" });
      return;
    }
    const totalMatches = this.state.results.reduce((n, r) => n + r.matches.length, 0);
    this.resultsEl.createDiv({
      text: `${this.state.results.length} file${this.state.results.length > 1 ? "s" : ""}, ${totalMatches} match${totalMatches > 1 ? "es" : ""}`,
      cls: "igrep-search-count"
    });
    this.state.results.forEach((result, index) => {
      const opened = this.state.openedIndices.includes(index);
      const selected = index === this.state.selectedIndex;
      const expanded = this.expandedFiles.has(index);
      const hasMultiple = result.matches.length > 1;
      const cls = [
        "igrep-search-result-item",
        selected ? "is-selected" : "",
        opened ? "is-opened" : ""
      ].filter(Boolean).join(" ");
      const item = this.resultsEl.createDiv({ cls });
      const header = item.createDiv("igrep-result-header");
      if (hasMultiple) {
        const toggle = header.createSpan("igrep-result-toggle");
        (0, import_obsidian.setIcon)(toggle, expanded ? "chevron-down" : "chevron-right");
        toggle.addEventListener("click", (e) => {
          e.stopPropagation();
          if (this.expandedFiles.has(index)) {
            this.expandedFiles.delete(index);
          } else {
            this.expandedFiles.add(index);
          }
          this.renderResults();
        });
      }
      header.createSpan({ text: result.file, cls: "igrep-result-file" });
      if (hasMultiple) {
        header.createSpan({
          text: `(${result.matches.length})`,
          cls: "igrep-result-match-count"
        });
      }
      const pct = Math.round(result.score * 100);
      const scoreCls = pct >= 70 ? "score-high" : pct >= 40 ? "score-mid" : "";
      header.createSpan({
        text: `${pct}%`,
        cls: `igrep-result-score ${scoreCls}`.trim()
      });
      item.addEventListener("click", () => {
        this.state.selectedIndex = index;
        this.openAndClose();
      });
      const best = result.matches[0];
      this.renderMatchPreview(item, best);
      if (expanded && hasMultiple) {
        const matchList = item.createDiv("igrep-match-list");
        result.matches.forEach((match) => {
          const matchItem = matchList.createDiv("igrep-match-item");
          const matchHeader = matchItem.createDiv("igrep-match-header");
          matchHeader.createSpan({ text: `:${match.line}`, cls: "igrep-result-line" });
          if (match.header || match.title) {
            matchHeader.createSpan({
              text: match.header || match.title || "",
              cls: "igrep-match-title"
            });
          }
          const mPct = Math.round(match.score * 100);
          matchHeader.createSpan({ text: `${mPct}%`, cls: "igrep-match-score" });
          const snippet = match.content.split("\n").slice(0, 2).join("\n");
          matchItem.createDiv({ text: snippet, cls: "igrep-result-content" });
          matchItem.addEventListener("click", (e) => {
            e.stopPropagation();
            this.state.selectedIndex = index;
            this.markOpened();
            this.openFileAtLine(result.file, match.line);
          });
        });
      }
    });
  }
  renderMatchPreview(container, match) {
    if (match.title || match.header) {
      container.createDiv({
        text: match.header || match.title || "",
        cls: "igrep-result-title"
      });
    }
    const snippet = match.content.split("\n").slice(0, 3).join("\n");
    container.createDiv({ text: snippet, cls: "igrep-result-content" });
  }
  selectNext() {
    if (this.state.results.length === 0) return;
    this.state.selectedIndex = (this.state.selectedIndex + 1) % this.state.results.length;
    this.renderResults();
    this.scrollToSelected();
  }
  selectPrev() {
    if (this.state.results.length === 0) return;
    this.state.selectedIndex = (this.state.selectedIndex - 1 + this.state.results.length) % this.state.results.length;
    this.renderResults();
    this.scrollToSelected();
  }
  scrollToSelected() {
    const selected = this.resultsEl.querySelector(".is-selected");
    selected?.scrollIntoView({ block: "nearest" });
  }
  /** Open file at a specific line and close modal */
  async openFileAtLine(filePath, line) {
    this.close();
    const file = this.app.vault.getAbstractFileByPath(filePath);
    if (!file) {
      new import_obsidian.Notice(`Could not open file: ${filePath}`);
      return;
    }
    const leaf = this.app.workspace.getLeaf(false);
    await leaf.openFile(file);
    this.navigateToLine(leaf, line);
  }
  /** Open file in new tab behind modal, keep modal open */
  async openInBackground() {
    const result = this.state.results[this.state.selectedIndex];
    if (!result) return;
    const file = this.app.vault.getAbstractFileByPath(result.file);
    if (!file) {
      new import_obsidian.Notice(`Could not open file: ${result.file}`);
      return;
    }
    this.markOpened();
    const activeLeaf = this.app.workspace.getLeaf(false);
    let leaf = this.findLeafByFile(result.file);
    if (!leaf || leaf === activeLeaf) {
      leaf = this.app.workspace.getLeaf("tab");
    }
    await leaf.openFile(file);
    this.navigateToLine(leaf, result.matches[0].line);
    setTimeout(() => this.inputEl.focus(), 50);
  }
  /** Open file in current pane and close modal */
  async openAndClose() {
    const result = this.state.results[this.state.selectedIndex];
    if (!result) return;
    this.markOpened();
    this.close();
    const file = this.app.vault.getAbstractFileByPath(result.file);
    if (!file) {
      new import_obsidian.Notice(`Could not open file: ${result.file}`);
      return;
    }
    const leaf = this.app.workspace.getLeaf(false);
    await leaf.openFile(file);
    this.navigateToLine(leaf, result.matches[0].line);
  }
  markOpened() {
    const idx = this.state.selectedIndex;
    if (!this.state.openedIndices.includes(idx)) {
      this.state.openedIndices.push(idx);
      this.renderResults();
    }
  }
  findLeafByFile(filePath) {
    let found = null;
    this.app.workspace.iterateAllLeaves((leaf) => {
      if (leaf.view?.file?.path === filePath) {
        found = leaf;
      }
    });
    return found;
  }
  navigateToLine(leaf, lineNum) {
    const view = leaf.view;
    if (view?.editor) {
      const line = Math.max(0, lineNum - 1);
      view.editor.setCursor({ line, ch: 0 });
      view.editor.scrollIntoView({ from: { line, ch: 0 }, to: { line, ch: 0 } }, true);
    }
  }
  onClose() {
    this.contentEl.empty();
  }
};

// src/main.ts
var IgrepSearchPlugin = class extends import_obsidian2.Plugin {
  constructor() {
    super(...arguments);
    this.searchState = { query: "", results: [], selectedIndex: 0, openedIndices: [] };
    this.searchHistory = [];
  }
  async onload() {
    const installed = await checkIgrepInstalled();
    if (!installed) {
      new import_obsidian2.Notice("igrep not found. Install it: pip install igrep", 1e4);
    }
    const openSearch = () => {
      const adapter = this.app.vault.adapter;
      if (!(adapter instanceof import_obsidian2.FileSystemAdapter)) {
        new import_obsidian2.Notice("igrep requires a local vault");
        return;
      }
      new IgrepSearchModal(
        this.app,
        adapter.getBasePath(),
        this.searchState,
        this.searchHistory
      ).open();
    };
    this.addRibbonIcon("sparkles", "igrep: Search vault", openSearch);
    this.addCommand({
      id: "open-search",
      name: "Search vault",
      callback: openSearch
    });
  }
  onunload() {
  }
};
