"""igrep — agent-first semantic grep / RAG grep CLI."""

from __future__ import annotations

__version__ = "0.1.1"
