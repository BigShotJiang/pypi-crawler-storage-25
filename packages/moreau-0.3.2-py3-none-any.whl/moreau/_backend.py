"""Backend discovery and registration for moreau.

This module provides a generic device registration system. Backend packages
register themselves via Python entry points:

    [project.entry-points."moreau.backends"]
    cuda = "moreau_cuda:_register"

When moreau is imported, it discovers all registered backends automatically.
The 'cpu' backend is always available as a built-in fallback.
"""
from importlib.metadata import entry_points
from typing import Any, Callable, Dict, List, Optional

                              
                                                            
_device_registry: Dict[str, dict] = {}

                                                         
_discovery_errors: Dict[str, str] = {}

                                                                   
_default_device_override: Optional[str] = None


def _discover_backends() -> None:
    """Discover and register backends via entry points."""
    try:
        eps = entry_points(group='moreau.backends')
    except TypeError:
                                                                 
        eps = entry_points().get('moreau.backends', [])

    for ep in eps:
        try:
            register_func = ep.load()
            register_func()
        except Exception as e:
                                                      
            _discovery_errors[ep.name] = f"{type(e).__name__}: {e}"


def register_device(
    name: str,
    *,
    priority: int = 50,
    solver_class: Any,
    batch_solver_class: Any = None,
    cones_class: Any = None,
    settings_class: Any = None,
    torch_solver_class: Any = None,
    torch_batch_solver_class: Any = None,
    torch_layer_class: Any = None,
    torch_solve_function_class: Any = None,
    jax_solver_class: Any = None,
    cones_converter: Callable = None,
    settings_converter: Callable = None,
) -> None:
    """Register a device backend with moreau.

    Called by backend packages to register their components.

    Args:
        name: Device name (e.g., 'cuda', 'rocm', 'tpu')
        priority: Selection priority for device='auto' (higher = preferred).
                  Suggested values: cuda=100, rocm=90, tpu=80
        solver_class: The single-problem solver class for this device
        batch_solver_class: The batch solver class for this device (optional)
        cones_class: The internal cones type for this backend (optional)
        settings_class: The internal settings type for this backend (optional)
        torch_solver_class: PyTorch single-problem solver class (optional)
        torch_batch_solver_class: PyTorch batch solver class (optional)
        torch_layer_class: PyTorch nn.Module layer class (optional)
        torch_solve_function_class: PyTorch autograd.Function class (optional)
        jax_solver_class: JAX solver class (optional)
        cones_converter: Function to convert Cones to backend type (optional)
        settings_converter: Function to convert Settings to backend type (optional)
    """
    _device_registry[name] = {
        'priority': priority,
        'solver': solver_class,
        'batch_solver': batch_solver_class,
        'cones': cones_class,
        'settings': settings_class,
        'torch_solver': torch_solver_class,
        'torch_batch_solver': torch_batch_solver_class,
        'torch_layer': torch_layer_class,
        'torch_solve_function': torch_solve_function_class,
        'jax_solver': jax_solver_class,
        'cones_converter': cones_converter,
        'settings_converter': settings_converter,
    }


def _reset_registry() -> None:
    """Reset the registry (for testing only)."""
    _device_registry.clear()
    _discovery_errors.clear()


                    

def available_devices() -> List[str]:
    """Return list of available device names, sorted by priority (highest first).

    Returns:
        List of device names. Always includes 'cpu' as fallback.
    """
    devices = list(_device_registry.keys())
                                 
    devices.sort(key=lambda d: _device_registry[d].get('priority', 0), reverse=True)
                                         
    if 'cpu' not in devices:
        devices.append('cpu')
    return devices


def device_available(name: str) -> bool:
    """Check if a device is available.

    Args:
        name: Device name (e.g., 'cuda', 'cpu')

    Returns:
        True if the device is registered and available.
    """
    if name == 'cpu':
        return True
    return name in _device_registry


def device_error(name: str) -> Optional[str]:
    """Return the error message if device discovery failed.

    Args:
        name: Device name

    Returns:
        Error message string, or None if no error.
    """
    return _discovery_errors.get(name)


def default_device() -> str:
    """Return the default device.

    If set_default_device() was called, returns that device.
    Otherwise returns the highest priority available device.

    Returns:
        Device name string.
    """
    if _default_device_override is not None:
        return _default_device_override
    devices = available_devices()
    return devices[0] if devices else 'cpu'


def _choose_device(n: int, nnz_A: int, batch_size: int = 1) -> str:
    """Choose optimal device based on problem characteristics.

    Uses empirical thresholds to determine whether CPU or CUDA will be faster.
    CUDA has ~25ms fixed overhead from cuDSS initialization, so it only wins
    for larger problems where GPU parallelism overcomes this cost.

    If set_default_device() was called, returns that device instead of
    using the heuristics.

    Args:
        n: Number of primal variables
        nnz_A: Number of non-zeros in constraint matrix A
        batch_size: Number of problems to solve in parallel (default 1)

    Returns:
        Device name: 'cuda' if CUDA is available and problem is large enough,
        otherwise 'cpu'.

    Thresholds (empirically determined):
        - n < 500: Always CPU (problem too small)
        - n >= 750: Always CUDA (problem large enough)
        - nnz_A >= 50,000: CUDA wins (enough linear algebra work)
        - batch_size >= 2 and nnz_A >= 25,000: CUDA wins (batching helps)
    """
                           
    if _default_device_override is not None:
        return _default_device_override

                                
    cuda_available = device_available('cuda')
    if not cuda_available:
        return 'cpu'

                                                   
    if n < 500:
        return 'cpu'

                               
    if n >= 750:
        return 'cuda'

                                                      
    if nnz_A >= 50_000:
        return 'cuda'

    if batch_size >= 2 and nnz_A >= 25_000:
        return 'cuda'

    return 'cpu'


def set_default_device(device: Optional[str]) -> None:
    """Set the default device for all solvers.

    This overrides the automatic priority-based device selection.
    Useful for testing or forcing a specific backend.

    Args:
        device: Device name ('cpu', 'cuda', etc.) or None to reset
                to automatic selection.

    Raises:
        ValueError: If the specified device is not available.

    Example:
        >>> import moreau
        >>> moreau.set_default_device('cpu')  # Force CPU
        >>> # All solvers will now use CPU by default
        >>> moreau.set_default_device(None)   # Reset to auto
    """
    global _default_device_override
    if device is not None and not device_available(device):
        raise ValueError(f"Device '{device}' is not available. "
                        f"Available devices: {available_devices()}")
    _default_device_override = device


def get_default_device() -> Optional[str]:
    """Get the current default device override.

    Returns:
        The device set by set_default_device(), or None if using
        automatic selection.
    """
    return _default_device_override


def get_device_component(device: str, component: str) -> Any:
    """Get a component from a registered device.

    Args:
        device: Device name (e.g., 'cuda')
        component: Component name. One of:
            - 'solver': Single-problem solver class
            - 'batch_solver': Batch solver class (three-step API)
            - 'cones': Internal cones type
            - 'settings': Internal settings type
            - 'torch_solver': PyTorch single-problem solver class
            - 'torch_batch_solver': PyTorch batch solver class
            - 'torch_layer': PyTorch nn.Module class
            - 'torch_solve_function': PyTorch autograd.Function
            - 'jax_solver': JAX solver class
            - 'cones_converter': Function to convert Cones
            - 'settings_converter': Function to convert Settings

    Returns:
        The component, or None if not available.
    """
    return _device_registry.get(device, {}).get(component)


def torch_available(device: str = None) -> bool:
    """Check if PyTorch integration is available for a device.

    Args:
        device: Device name. If None, checks if any device has torch support.

    Returns:
        True if PyTorch solver is available for the device.
    """
    if device is not None:
        return get_device_component(device, 'torch_solver') is not None

                                                      
    for dev in _device_registry:
        if _device_registry[dev].get('torch_solver') is not None:
            return True
    return False


def jax_available(device: str = None) -> bool:
    """Check if JAX integration is available for a device.

    Args:
        device: Device name. If None, checks if any device has JAX support.

    Returns:
        True if JAX solver is available for the device.
    """
    if device is not None:
        return get_device_component(device, 'jax_solver') is not None

                                                    
    for dev in _device_registry:
        if _device_registry[dev].get('jax_solver') is not None:
            return True
    return False


def _settings_to_cpu(settings):
    """Convert Settings to CPU DefaultSettings."""
    from moreau_cpu._cpu import settings_to_cpu
    return settings_to_cpu(settings)


def _register_cpu() -> None:
    """Register built-in CPU backend.

    CPU is always available as a fallback with lowest priority.
    Note: CPU uses moreau_cpu.Solver (three-step pattern) for both solver_class
    and batch_solver_class since it handles both single and batch based on input shape.
    """
    import moreau_cpu
    from ._types import Cones

    register_device(
        'cpu',
        priority=0,                              
        solver_class=moreau_cpu.Solver,                             
        batch_solver_class=moreau_cpu.Solver,                            
        cones_class=Cones,
        settings_class=moreau_cpu.DefaultSettings,
        torch_solver_class=None,
        torch_batch_solver_class=None,
        jax_solver_class=None,
        cones_converter=None,                                        
        settings_converter=_settings_to_cpu,
    )
                                                                      
                                                                                 
                                                                                  
                                                                             
    try:
        from .torch._cpu_impl import _TorchSolverCpu
        _device_registry['cpu']['torch_solver'] = _TorchSolverCpu
    except ImportError:
        pass

    try:
        from .jax._cpu_impl import JaxSolverCpu
        _device_registry['cpu']['jax_solver'] = JaxSolverCpu
    except ImportError:
        pass


def _cuda_hardware_available() -> bool:
    """Check if CUDA hardware is present (without requiring moreau-cuda)."""
                                   
    try:
        import torch
        if torch.cuda.is_available():
            return True
    except ImportError:
        pass

              
    try:
        import cupy
        cupy.cuda.runtime.getDeviceCount()
        return True
    except (ImportError, Exception):
        pass

               
    try:
        from numba import cuda
        if cuda.is_available():
            return True
    except (ImportError, Exception):
        pass

    return False


def _show_cuda_hint() -> None:
    """Show a hint if CUDA hardware is available but moreau-cuda isn't installed."""
                   
                                  
                                                      
                                                                           
    import sys
    if 'moreau_cuda' in sys.modules:
                                                                      
        return
    if 'cuda' not in _device_registry and _cuda_hardware_available():
        import warnings
        warnings.warn(
            "CUDA GPU detected. Install moreau[cuda] for 10-100x faster solving: "
            "pip install moreau[cuda]",
            stacklevel=2,
        )


                             
_discover_backends()

                                   
_register_cpu()

                                                                      
_show_cuda_hint()


def solver_methods_for_device(device: str) -> List[str]:
    """Return candidate KKT solver methods for a given device.

    Args:
        device: Device name ('cuda', 'cpu', etc.)

    Returns:
        List of method name strings to benchmark during tune().
    """
    if device == 'cuda':
                                                                        
                                                                      
                                                                      
        return ['cudss']
    elif device == 'cpu':
        return ['qdldl', 'faer']
    else:
        return ['qdldl']


def _rank_method(device: str, n: int, m: int, nnz_A: int, batch_size: int) -> List[str]:
    """Return methods for a device, ordered by heuristic likelihood of winning.

    For CPU, faer wins on larger systems; QDLDL wins on small ones.

    Args:
        device: 'cuda', 'cpu', etc.
        n: Number of variables.
        m: Number of constraints.
        nnz_A: Number of non-zeros in A.
        batch_size: Batch size.
    """
    kkt_dim = n + m
    methods = solver_methods_for_device(device)
    if device == 'cuda':
        return methods
    elif device == 'cpu':
                                                       
        if kkt_dim >= 500 or nnz_A >= 10_000:
            return [m for m in methods if m == 'faer'] + [m for m in methods if m != 'faer']
        return [m for m in methods if m == 'qdldl'] + [m for m in methods if m != 'qdldl']
    return methods


def auto_tune_candidates(
    device: str, method: str,
    n: int = 0, m: int = 0, nnz_P: int = 0, nnz_A: int = 0,
    batch_size: int = 1,
) -> List[tuple]:
    """Return (device, method) combos to benchmark, heuristic-best first.

    The first candidate runs without a time limit and sets the baseline.
    Subsequent candidates are time-limited against that baseline, so
    ordering matters for auto-tune speed.

    If device='auto', returns all available devices × their methods.
    If only method='auto', returns all methods for the explicit device.

    Args:
        device: Device setting ('auto' or explicit like 'cpu', 'cuda')
        method: direct_solve_method setting ('auto' or explicit)
        n: Number of variables (for heuristic ordering).
        m: Number of constraints (for heuristic ordering).
        nnz_P: Non-zeros in P (for heuristic ordering).
        nnz_A: Non-zeros in A (for heuristic ordering).
        batch_size: Batch size (for heuristic ordering).

    Returns:
        List of (device, method) tuples to benchmark, best guess first.
    """
    if device == 'auto':
                                             
        best_dev = _choose_device(n, nnz_A, batch_size)
        devices = available_devices()
        ordered_devs = [best_dev] + [d for d in devices if d != best_dev]
        combos = []
        for dev in ordered_devs:
            for meth in _rank_method(dev, n, m, nnz_A, batch_size):
                combos.append((dev, meth))
        return combos
    elif method == 'auto':
                                                                            
        return [
            (device, meth)
            for meth in _rank_method(device, n, m, nnz_A, batch_size)
        ]
    else:
                                              
        return []


                                             
__all__ = [
    'available_devices',
    'device_available',
    'device_error',
    'default_device',
    'set_default_device',
    'get_default_device',
    'torch_available',
    'jax_available',
]

                                                                               
                                                                               
                                                                             
