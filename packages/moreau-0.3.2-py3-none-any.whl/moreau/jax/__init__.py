"""
Moreau JAX integration with unified CPU/CUDA support.

Provides differentiable convex optimization for JAX with automatic
device selection between CPU and CUDA backends.

Example (full signature):
    >>> import jax
    >>> import jax.numpy as jnp
    >>> from moreau.jax import Solver
    >>> import moreau
    >>>
    >>> cones = moreau.Cones(num_zero_cones=1, num_nonneg_cones=2)
    >>> solver = Solver(n=2, m=3, P_row_offsets=..., P_col_indices=...,
    ...                 A_row_offsets=..., A_col_indices=..., cones=cones)
    >>>
    >>> solution = solver.solve(P_values, A_values, q, b)
    >>> print(solution.x, solver.info.status)

Example (two-step API):
    >>> solver = Solver(n=2, m=3, ...)
    >>> solver.setup(P_values, A_values)  # Set matrices once
    >>> solution = solver.solve(q, b)  # Solve with 2 args
    >>>
    >>> # User can vmap/jit as needed
    >>> batched = jax.vmap(solver.solve)
    >>> solutions = batched(q_batch, b_batch)

Example (differentiation):
    >>> def loss_fn(q):
    ...     return jnp.sum(solver.solve(q, b).x)
    >>> grad_q = jax.grad(loss_fn)(q)
"""

from typing import Optional, Any, Callable, Tuple
import time

from moreau._backend import (
    default_device,
    get_device_component,
    jax_available,
)
from moreau._types import Cones, Settings, IPMSettings, JaxSolution, JaxSolveInfo, WarmStart, BatchedWarmStart, SolverStatus, TuneResult
from moreau._backend import solver_methods_for_device as _solver_methods_for_device
from moreau._backend import auto_tune_candidates as _auto_tune_candidates

                                                                        
                                                                    
                                                                          
from moreau._backend import _device_registry as _dr
if 'cpu' in _dr and _dr['cpu'].get('jax_solver') is None:
    from ._cpu_impl import JaxSolverCpu
    _dr['cpu']['jax_solver'] = JaxSolverCpu
del _dr


class Solver:
    """JAX solver with automatic device selection and gradient support.

    Provides a solve method compatible with jax.vmap, jax.grad, and jax.jit.
    Solve metadata (timing, status) is available via solver.info after solve().

    Supports two usage patterns:
    1. Full signature: solve(P_data, A_data, q, b)
    2. Two-step: setup(P_data, A_data) then solve(q, b)

    Args:
        n: Number of primal variables
        m: Number of constraints
        P_row_offsets: CSR row pointers for P matrix (array-like).
            P must be full symmetric (both upper and lower triangles).
        P_col_indices: CSR column indices for P matrix (array-like)
        A_row_offsets: CSR row pointers for A matrix (array-like)
        A_col_indices: CSR column indices for A matrix (array-like)
        cones: Cone specification (moreau.Cones object)
        settings: Optional solver settings (moreau.Settings object).
                  If device='auto' (default), uses CUDA if available, else CPU.
        jit: If True (default), JIT-compile the solve method for better performance.

    Example (full signature):
        >>> solver = Solver(n=2, m=3, P_row_offsets=..., P_col_indices=...,
        ...                 A_row_offsets=..., A_col_indices=..., cones=cones)
        >>> solution = solver.solve(P_data, A_data, q, b)

    Example (two-step):
        >>> solver = Solver(n=2, m=3, ...)
        >>> solver.setup(P_data, A_data)  # Set matrices once
        >>> solution = solver.solve(q, b)  # Solve with 2 args
        >>>
        >>> # User can vmap/jit as needed
        >>> batched = jax.vmap(solver.solve)
        >>> solutions = batched(q_batch, b_batch)
    """

    def __init__(
        self,
        n: int,
        m: int,
        P_row_offsets,
        P_col_indices,
        A_row_offsets,
        A_col_indices,
        cones: Cones,
        settings: Optional[Settings] = None,
        jit: bool = True,
    ):
                                            
        from moreau import _warn_cvxpy_soc_if_needed
        _warn_cvxpy_soc_if_needed(cones)

        if settings is None:
            settings = Settings()

                                                                           
        device = settings.device
        if device == 'auto':
            device = default_device()

                                                                
        from moreau._types import SolverType
        from moreau import _resolve_solver_type
        nnz_P = len(P_col_indices)
        settings, device = _resolve_solver_type(settings, n, m, cones, device, nnz_P=nnz_P)

        self._device = device
        self._n = n
        self._m = m
        self._settings = settings
        self._cones = cones
        self._P_row_offsets = P_row_offsets
        self._P_col_indices = P_col_indices
        self._A_row_offsets = A_row_offsets
        self._A_col_indices = A_col_indices
        self._jit = jit

                                            
        JaxSolverClass = get_device_component(device, 'jax_solver')

        if JaxSolverClass is None:
                                                               
            if device != 'cpu':
                JaxSolverClass = get_device_component('cpu', 'jax_solver')

        if JaxSolverClass is None:
            raise ImportError(
                f"JAX extension for device '{device}' not available. "
                f"Ensure JAX is installed and the appropriate moreau backend is built with JAX support. "
                f"Available devices with JAX support: {[d for d in ['cpu', 'cuda'] if jax_available(d)]}"
            )

                                 
        construction_start = time.perf_counter()

                                       
        self._impl = JaxSolverClass(
            n, m,
            P_row_offsets, P_col_indices,
            A_row_offsets, A_col_indices,
            cones, settings,
        )

        self._construction_time = time.perf_counter() - construction_start

                                              
        self._solve_raw = self._impl.solve

                                     
        if jit:
            import jax
            self._solve_raw = jax.jit(self._solve_raw)

                                                                  
                                                                             
                                                                          
                                                                                  
                                                         
        self._original_device = settings.device
        ipm = settings.ipm_settings
        self._original_method = ipm.direct_solve_method if ipm else 'auto'
        if self._original_method == 'auto' and settings.device != 'auto':
            from moreau._backend import _rank_method
            import numpy as _np
            nnz_A = len(_np.asarray(A_col_indices))
            ranked = _rank_method(device, n, m, nnz_A,
                                  settings.batch_size)
            initial_method = ranked[0] if ranked else 'auto'
            if ipm:
                ipm.direct_solve_method = initial_method

                         
        self._auto_tuned = False
        self._tune_result = None

                                                   
        self._info = None

                                          
        self._P_data = None
        self._A_data = None

    def setup(self, P_data, A_data):
        """Set P and A matrix values for subsequent solve() calls.

        After calling setup(), solve() can be called with just (q, b).
        Gradients w.r.t. P/A are still computed when using the 2-arg solve().

        Args:
            P_data: P matrix values, shape (nnzP,)
            A_data: A matrix values, shape (nnzA,)
        """
        import jax.numpy as jnp
        self._P_data = jnp.asarray(P_data, dtype=jnp.float64)
        self._A_data = jnp.asarray(A_data, dtype=jnp.float64)

                                                                            
    _WARM_START_NO_RETRY = frozenset({
        SolverStatus.Solved,
        SolverStatus.AlmostSolved,
        SolverStatus.MaxIterations,
        SolverStatus.CallbackTerminated,
    })

    _AUTO_TUNE_MARGIN = 1.5

    def _needs_auto_tune(self) -> bool:
        """Check if auto-tune benchmarking should run on this solve."""
        if self._auto_tuned:
            return False
        if not self._settings.auto_tune:
            return False
                                                               
        from moreau._types import SolverType
        if self._settings.solver == SolverType.ACTIVE_SET:
            return False
                                                                              
        from moreau._backend import _default_device_override
        if self._original_device == 'auto' and _default_device_override is not None:
            return False
                                                       
        if self._original_device == 'auto':
            return True
        if self._original_method == 'auto':
            return True
        return False

    def _auto_tune(self, P_data, A_data, q, b):
        """Benchmark solver configs and lock in the fastest.

        Uses moreau.CompiledSolver internally for benchmarking (no grad
        overhead), then reconstructs this solver's backend with the winner.
        """
        import warnings
        warnings.warn(
            "First solve is benchmarking solver configurations "
            "(auto_tune=True). Subsequent solves will be faster. "
            "Set auto_tune=False (default) to use heuristic selection "
            "without benchmarking.",
            stacklevel=3,
        )
        import numpy as np
        import jax.numpy as jnp
        import moreau

                                                                       
                                                     
        stored_P_data = self._P_data
        stored_A_data = self._A_data

        q_np = np.asarray(q, dtype=np.float64)
        b_np = np.asarray(b, dtype=np.float64)
        P_np = np.asarray(P_data, dtype=np.float64)
        A_np = np.asarray(A_data, dtype=np.float64)
        P_ro = np.asarray(self._P_row_offsets, dtype=np.int64)
        P_ci = np.asarray(self._P_col_indices, dtype=np.int64)
        A_ro = np.asarray(self._A_row_offsets, dtype=np.int64)
        A_ci = np.asarray(self._A_col_indices, dtype=np.int64)

                                      
        if q_np.ndim == 1:
            q_np = q_np.reshape(1, -1)
        if b_np.ndim == 1:
            b_np = b_np.reshape(1, -1)
        batch_size = q_np.shape[0]

        candidates = _auto_tune_candidates(
            self._original_device, self._original_method,
            n=self._n, m=self._m,
            nnz_P=len(P_ci), nnz_A=len(A_ci),
            batch_size=batch_size,
        )

        if not candidates:
            self._auto_tuned = True
            return

                                                      
        ipm = self._settings.ipm_settings
        current_method = ipm.direct_solve_method if ipm else 'auto'
        current_config = (self._device, current_method)
        current_key = f"{current_config[0]}:{current_config[1]}"

                                                                                
        verbose = self._settings.verbose
        results = {}
        best_time = float('inf')
        best_key = None
        construction_limit = None

        if verbose:
            _print = lambda *a, **kw: print(*a, **kw, flush=True)
            _print(f"[moreau] auto-tune: benchmarking {len(candidates)} "
                   f"candidate(s)...")
        else:
            _print = None

        for trial_device, trial_method in candidates:
            key = f"{trial_device}:{trial_method}"
            trial_settings = self._settings.model_copy(deep=True)
            trial_settings.device = trial_device
            trial_settings.verbose = False
            trial_settings.batch_size = batch_size
            if trial_settings.ipm_settings is None:
                trial_settings.ipm_settings = IPMSettings()
            trial_settings.ipm_settings.direct_solve_method = trial_method
                                                             
            if best_time < float('inf'):
                trial_settings.time_limit = min(
                    best_time * self._AUTO_TUNE_MARGIN,
                    trial_settings.time_limit,
                )

                                       
            build_t0 = time.perf_counter()
            trial = moreau.CompiledSolver(
                n=self._n, m=self._m,
                P_row_offsets=P_ro, P_col_indices=P_ci,
                A_row_offsets=A_ro, A_col_indices=A_ci,
                cones=self._cones, settings=trial_settings,
            )
            trial.setup(P_np, A_np)
            build_time = time.perf_counter() - build_t0

                                                           
            if construction_limit is None:
                construction_limit = max(build_time * 5, 1.0)

                                                
            if build_time > construction_limit:
                results[key] = {
                    'solve_time': float('inf'),
                    'iterations': 0,
                    'status': [SolverStatus.NumericalError],
                }
                if _print:
                    _print(f"[moreau] auto-tune:   {key:<16s} "
                           f"{build_time:.3f}s build  "
                           f"skipped (build > {construction_limit:.2f}s limit)")
                continue

            trial.solve(q_np, b_np)
            info = trial.info
            results[key] = {
                'solve_time': info.solve_time,
                'iterations': info.iterations,
                'status': info.status,
            }

            _ok = (SolverStatus.Solved, SolverStatus.AlmostSolved)
            statuses = info.status if isinstance(info.status, list) else [info.status]
            is_ok = all(s in _ok for s in statuses)
            if is_ok and info.solve_time < best_time:
                best_time = info.solve_time
                best_key = key

            if _print:
                iters = info.iterations
                iters_str = str(max(iters)) if isinstance(iters, list) else str(iters)
                names = set(s.name if hasattr(s, 'name') else str(s) for s in statuses)
                status_str = names.pop() if len(names) == 1 else '/'.join(sorted(names))
                marker = " *" if key == best_key else ""
                _print(f"[moreau] auto-tune:   {key:<16s} "
                       f"{build_time:.3f}s build  "
                       f"{info.solve_time:.4f}s solve  "
                       f"{iters_str} iters  "
                       f"{status_str}{marker}")

                                                                                        
        from moreau._backend import get_device_component
        _ok_statuses = (SolverStatus.Solved, SolverStatus.AlmostSolved)
        sorted_keys = sorted(results, key=lambda k: results[k]['solve_time'])
        winner_key = None
        for key in sorted_keys:
            r_status = results[key]['status']
            r_statuses = r_status if isinstance(r_status, list) else [r_status]
            if not all(s in _ok_statuses for s in r_statuses):
                continue
            dev = key.split(':', 1)[0]
            jax_cls = get_device_component(dev, 'jax_solver')
            if jax_cls is None and dev != 'cpu':
                jax_cls = get_device_component('cpu', 'jax_solver')
            if jax_cls is not None:
                winner_key = key
                break

        if winner_key is None:
            winner_key = sorted_keys[0]
            best_device = self._device
            best_method = winner_key.split(':', 1)[1]
        else:
            best_device, best_method = winner_key.split(':', 1)

        best_time = results[winner_key]['solve_time']
        tuned_limit = best_time * self._AUTO_TUNE_MARGIN
        time_limit = max(tuned_limit, self._settings.time_limit)

        if _print:
            _print(f"[moreau] auto-tune: winner {best_device}:{best_method} "
                   f"({best_time:.4f}s solve)")

        self._tune_result = TuneResult(
            device=best_device,
            method=best_method,
            time_limit=time_limit,
            results=results,
        )

                                                           
        winner_config = (best_device, best_method)
        if winner_config != current_config:
            winning_settings = self._settings.model_copy(deep=True)
            winning_settings.device = best_device
            if winning_settings.ipm_settings is None:
                winning_settings.ipm_settings = IPMSettings()
            winning_settings.ipm_settings.direct_solve_method = best_method
            winning_settings.time_limit = time_limit
            self._settings = winning_settings
            self._device = best_device

            JaxSolverClass = get_device_component(best_device, 'jax_solver')
            if JaxSolverClass is None and best_device != 'cpu':
                JaxSolverClass = get_device_component('cpu', 'jax_solver')

            self._impl = JaxSolverClass(
                self._n, self._m,
                self._P_row_offsets, self._P_col_indices,
                self._A_row_offsets, self._A_col_indices,
                self._cones, self._settings,
            )
            self._solve_raw = self._impl.solve
            if self._jit:
                import jax
                self._solve_raw = jax.jit(self._solve_raw)

                                                                 
            if stored_P_data is not None:
                self._P_data = stored_P_data
                self._A_data = stored_A_data

        self._auto_tuned = True

    def solve(self, *args, warm_start=None) -> JaxSolution:
        """Solve the optimization problem.

        Two signatures supported:
        - solve(q, b): Uses P/A from setup()
        - solve(P_data, A_data, q, b): Full signature

        Args (2-arg form):
            q: Linear cost, shape (n,) or (batch, n)
            b: Constraint RHS, shape (m,) or (batch, m)

        Args (4-arg form):
            P_data: P matrix values, shape (nnzP,) or (batch, nnzP)
            A_data: A matrix values, shape (nnzA,) or (batch, nnzA)
            q, b: Same as 2-arg form.

        Keyword Args:
            warm_start: Optional WarmStart or BatchedWarmStart from a previous
                solve (e.g. ``solution.to_warm_start()``). Gradients do NOT
                flow through warm start values.

        Returns:
            JaxSolution: NamedTuple with x, z, s

        Note:
            Solver metadata (status, timing) is available via solver.info
            after calling solve().
        """
        if len(args) == 2:
            if self._P_data is None:
                raise RuntimeError("setup() must be called before solve(q, b)")
            q, b = args
            P_data, A_data = self._P_data, self._A_data
        elif len(args) == 4:
            P_data, A_data, q, b = args
        else:
            raise TypeError(f"solve() takes 2 or 4 arguments, got {len(args)}")

                                                                  
        if self._needs_auto_tune():
            self._auto_tune(P_data, A_data, q, b)

        if warm_start is not None:
            if not isinstance(warm_start, (WarmStart, BatchedWarmStart)):
                raise TypeError(
                    f"warm_start must be a WarmStart or BatchedWarmStart, "
                    f"got {type(warm_start).__name__}")

                                                                           
                                                                            
                                                  
            import jax.numpy as jnp
            solve_warm_fn = self._impl.solve_warm
            if solve_warm_fn is not None:
                warm_x = jnp.asarray(warm_start.x, dtype=jnp.float64)
                warm_z = jnp.asarray(warm_start.z, dtype=jnp.float64)
                warm_s = jnp.asarray(warm_start.s, dtype=jnp.float64)
                solution, info = solve_warm_fn(
                    P_data, A_data, q, b, warm_x, warm_z, warm_s)
            else:
                                                                     
                import numpy as np
                self._impl._pending_warm_start = {
                    'warm_x': np.asarray(warm_start.x, dtype=np.float64),
                    'warm_z': np.asarray(warm_start.z, dtype=np.float64),
                    'warm_s': np.asarray(warm_start.s, dtype=np.float64),
                }
                solution, info = self._solve_raw(P_data, A_data, q, b)
                self._impl._pending_warm_start = None
        else:
            solution, info = self._solve_raw(P_data, A_data, q, b)

                                                                   
        if warm_start is not None:
            import jax.numpy as jnp
            status_val = int(jnp.asarray(info.status))
            from moreau._types import normalize_status
            status_enum = normalize_status(status_val)
            ipm = self._settings.ipm_settings
            no_retry = ipm.warm_start_no_retry if (ipm and ipm.warm_start_no_retry is not None) else self._WARM_START_NO_RETRY
            if status_enum not in no_retry:
                import warnings
                warnings.warn(
                    f"Warm-started solve failed ({status_enum.name}), "
                    f"retrying without warm start.",
                    UserWarning,
                    stacklevel=2,
                )
                solution, info = self._solve_raw(P_data, A_data, q, b)

                                                            
                                                                            
        self._info = info

        return solution

    @property
    def info(self) -> Optional[JaxSolveInfo]:
        """Metadata from the last solve() call.

        Returns None if solve() has not been called yet.

        Contains:
            - status: Solver status (as int, SolverStatus enum value)
            - obj_val: Objective value at solution
            - iterations: Number of IPM iterations
            - solve_time: Time in IPM iterations (seconds)
            - setup_time: Time setting matrix values (seconds)
            - construction_time: Time constructing solver (seconds)

        Note: For vmap calls, this returns info from the last single call,
        not the batched result. Access batched info via the returned tuple.
        """
        return self._info

    @property
    def device(self) -> str:
        """Return the active device name ('cpu' or 'cuda')."""
        return self._device

    @property
    def n(self) -> int:
        """Number of primal variables."""
        return self._n

    @property
    def m(self) -> int:
        """Number of constraints."""
        return self._m

    @property
    def construction_time(self) -> float:
        """Time spent constructing solver structure (seconds)."""
        return self._construction_time

    @property
    def tune_result(self):
        """Result from auto-tuning on the first solve() call.

        Returns None if auto-tune has not run yet (e.g. device and method
        were set explicitly, or solve() has not been called).
        """
        return self._tune_result


                                                                           
                                                             
def solver(
    n: int,
    m: int,
    P_row_offsets,
    P_col_indices,
    A_row_offsets,
    A_col_indices,
    cones: Cones,
    settings: Optional[Settings] = None,
    jit: bool = True,
) -> Callable:
    """Create a JAX-compatible solve function (legacy API).

    Note: Consider using Solver class instead for access to solver.info.

    Returns a pure function that can be used with jax.vmap, jax.grad, and jax.jit.
    The returned function has signature:

        solve(P_data, A_data, q, b) -> (JaxSolution, JaxSolveInfo)

    Args:
        n: Number of primal variables
        m: Number of constraints
        P_row_offsets: CSR row pointers for P matrix (array-like).
            P must be full symmetric (both upper and lower triangles).
        P_col_indices: CSR column indices for P matrix (array-like)
        A_row_offsets: CSR row pointers for A matrix (array-like)
        A_col_indices: CSR column indices for A matrix (array-like)
        cones: Cone specification (moreau.Cones object)
        settings: Optional solver settings (moreau.Settings object).
                  If device='auto' (default), uses CUDA if available, else CPU.
        jit: If True (default), JIT-compile the solve function for better performance.

    Returns:
        Pure function: (P_data, A_data, q, b) -> (JaxSolution, JaxSolveInfo)

    Example:
        >>> from moreau.jax import solver
        >>> solve = solver(n=2, m=3, ...)
        >>> solution, info = solve(P_data, A_data, q, b)
    """
                                                                             
    s = Solver(
        n, m,
        P_row_offsets, P_col_indices,
        A_row_offsets, A_col_indices,
        cones, settings,
        jit=jit,
    )
                                                              
    return s._solve_raw


__all__ = ['Solver', 'solver']
