"""Moreau: Conic optimization solver with CPU and optional accelerator backends.

Usage:
    pip install moreau           # CPU only
    pip install moreau[cuda]     # CPU + GPU

Example (Solver - single problem):
    import moreau
    import numpy as np
    from scipy import sparse

    # Problem data
    P = sparse.diags([1.0, 1.0], format='csr')
    q = np.array([2.0, 1.0])
    A = sparse.csr_array([[1.0, 1.0], [1.0, 0.0], [0.0, 1.0]])
    b = np.array([1.0, 0.7, 0.7])

    cones = moreau.Cones(num_zero_cones=1, num_nonneg_cones=2)

    # Create solver with all problem data
    solver = moreau.Solver(P, q, A, b, cones=cones)
    solution = solver.solve()
    print(solution.x, solver.info.status)

Example (CompiledSolver - multiple problems):
    import moreau
    import numpy as np

    # Define problem structure
    cones = moreau.Cones(num_zero_cones=1, num_nonneg_cones=2)
    settings = moreau.Settings(device='cpu', batch_size=4)

    solver = moreau.CompiledSolver(
        n=2, m=3,
        P_row_offsets=[0, 1, 2], P_col_indices=[0, 1],
        A_row_offsets=[0, 2, 3, 4], A_col_indices=[0, 1, 0, 1],
        cones=cones, settings=settings
    )

    # Set matrix values for batch
    P_values = [[1.0, 1.0]] * 4
    A_values = [[1.0, 1.0, 1.0, 1.0]] * 4
    solver.setup(P_values, A_values)

    # Solve batch
    qs = [[2.0, 1.0]] * 4
    bs = [[1.0, 0.7, 0.7]] * 4
    solution = solver.solve(qs, bs)
    print(solution.x.shape, solver.info.status[0])
"""
__version__ = "0.3.2"

                          
import numpy as np
import time
import warnings
from scipy import sparse
from moreau_cpu import _cpu_solver

              
from ._types import (
    SolverType, SolverStatus, Cones, Settings, IPMSettings, ActiveSetSettings,
    WarmStart, BatchedWarmStart,
    SolveInfo, Solution, BatchedSolveInfo, BatchedSolution,
    TuneResult,
    normalize_status as _normalize_status,
)
from typing import Tuple, Optional

                                                
from ._backend import (
    available_devices,
    device_available,
    default_device,
    device_error,
    set_default_device,
    get_default_device,
    torch_available,
    jax_available,
)

                                                                      
from ._backend import (
    get_device_component as _get_device_component,
    _choose_device,
    solver_methods_for_device as _solver_methods_for_device,
    auto_tune_candidates as _auto_tune_candidates,
)

def _resolve_solver_type(settings, n, m, cones, device, nnz_P=None):
    """Resolve solver='auto' to active-set or IPM.

    Returns a (possibly copied) settings object with solver resolved,
    and the device (forced to 'cpu' for active-set).

    Args:
        nnz_P: Number of nonzeros in P. If 0, the problem is an LP and
            active-set is not used. If None, assumed nonzero (QP).
    """
    if settings.solver == SolverType.AUTO or settings.solver == 'auto':
        is_qp_only = (
            cones.num_exp_cones == 0 and
            len(cones.power_alphas) == 0 and
            len(cones.so_cone_dims) == 0 and
            len(getattr(cones, 'gen_power_cone_params', [])) == 0
        )
        has_quadratic = (nnz_P is None or nnz_P > 0)
        m_limit = max(500, 2 * n)
        if is_qp_only and has_quadratic and n <= 500 and m > 0 and m <= m_limit and device != 'cuda':
            settings = settings.model_copy(deep=True)
            settings.solver = SolverType.ACTIVE_SET
        else:
            settings = settings.model_copy(deep=True)
            settings.solver = SolverType.IPM

    if settings.solver == SolverType.ACTIVE_SET:
        device = 'cpu'

    return settings, device


                        
_cpu_solver.force_load_blas_lapack()

_cvxpy_soc_warning_issued = False


def _warn_cvxpy_soc_if_needed(cones):
    """Warn if CVXPY <= 1.8.1 is installed and the problem has SOC cones.

    CVXPY 1.8.2+ generates significantly better SOC formulations for Moreau.
    This warning is issued at most once per process.
    """
    global _cvxpy_soc_warning_issued
    if _cvxpy_soc_warning_issued:
        return
    if not cones.so_cone_dims:
        return
    import sys
    cvxpy = sys.modules.get("cvxpy")
    if cvxpy is None:
        return
    try:
        version_tuple = tuple(int(x) for x in cvxpy.__version__.split(".")[:3])
        if version_tuple <= (1, 8, 1):
            _cvxpy_soc_warning_issued = True
            warnings.warn(
                f"CVXPY {cvxpy.__version__} detected with SOC constraints. "
                "Upgrade to CVXPY >= 1.8.2 for significantly improved SOC "
                "performance with Moreau: pip install 'cvxpy>=1.8.2'",
                stacklevel=3,
            )
    except Exception:
        pass


def _to_csr(matrix):
    """Convert matrix to CSR format, extracting row_offsets, col_indices, values."""
    if sparse.issparse(matrix):
        csr = matrix.tocsr()
    else:
        csr = sparse.csr_array(matrix)
    return (
        np.asarray(csr.indptr, dtype=np.int64),
        np.asarray(csr.indices, dtype=np.int64),
        np.asarray(csr.data, dtype=np.float64),
    )


def _validate_problem_dimensions(P, q, A, b, cones):
    """Validate that problem dimensions are consistent.

    Args:
        P: Quadratic objective matrix (n x n)
        q: Linear objective vector (n,)
        A: Constraint matrix (m x n)
        b: Constraint RHS vector (m,)
        cones: Cone specification

    Raises:
        ValueError: If dimensions are inconsistent
    """
                    
    q_arr = np.asarray(q)
    b_arr = np.asarray(b)
    n = q_arr.shape[-1] if q_arr.ndim > 0 else 1
    m = b_arr.shape[-1] if b_arr.ndim > 0 else 1

                      
    if q_arr.ndim != 1:
        raise ValueError(
            f"q must be a 1D array, got shape {q_arr.shape}"
        )

                      
    if b_arr.ndim != 1:
        raise ValueError(
            f"b must be a 1D array, got shape {b_arr.shape}"
        )

                           
    if sparse.issparse(P):
        P_shape = P.shape
    else:
        P_arr = np.asarray(P)
        P_shape = P_arr.shape

    if len(P_shape) != 2:
        raise ValueError(
            f"P must be a 2D matrix, got shape {P_shape}"
        )
    if P_shape[0] != P_shape[1]:
        raise ValueError(
            f"P must be square, got shape {P_shape}"
        )
    if P_shape[0] != n:
        raise ValueError(
            f"P has shape {P_shape} but q has length {n}. "
            f"P must be (n x n) where n = len(q) = {n}"
        )

                           
    if sparse.issparse(A):
        A_shape = A.shape
    else:
        A_arr = np.asarray(A)
        A_shape = A_arr.shape

    if len(A_shape) != 2:
        raise ValueError(
            f"A must be a 2D matrix, got shape {A_shape}"
        )
    if A_shape[1] != n:
        raise ValueError(
            f"A has shape {A_shape} but problem has n={n} variables (from q). "
            f"A must have {n} columns."
        )
    if A_shape[0] != m:
        raise ValueError(
            f"A has shape {A_shape} but b has length {m}. "
            f"A must have {m} rows to match b."
        )

                                       
    cone_total = cones.total_constraints()
    if cone_total != m:
        raise ValueError(
            f"Cone dimensions sum to {cone_total} but b has length {m}. "
            f"Total cone constraints must equal m = len(b) = {m}."
        )


def _validate_csr_structure(n, m, P_row_offsets, P_col_indices,
                            A_row_offsets, A_col_indices, cones):
    """Validate CSR structure is consistent with problem dimensions.

    Args:
        n: Number of primal variables
        m: Number of constraints
        P_row_offsets: CSR row pointers for P (length n+1)
        P_col_indices: CSR column indices for P
        A_row_offsets: CSR row pointers for A (length m+1)
        A_col_indices: CSR column indices for A
        cones: Cone specification

    Raises:
        ValueError: If CSR structure is invalid
    """
    P_ro = np.asarray(P_row_offsets)
    P_ci = np.asarray(P_col_indices)
    A_ro = np.asarray(A_row_offsets)
    A_ci = np.asarray(A_col_indices)

                                   
    if len(P_ro) != n + 1:
        raise ValueError(
            f"P_row_offsets has length {len(P_ro)} but must have length n+1 = {n + 1} "
            f"for a matrix with n={n} rows."
        )

                                   
    if len(A_ro) != m + 1:
        raise ValueError(
            f"A_row_offsets has length {len(A_ro)} but must have length m+1 = {m + 1} "
            f"for a matrix with m={m} rows."
        )

                                                         
    if P_ro[0] != 0:
        raise ValueError(
            f"P_row_offsets must start at 0, got {P_ro[0]}"
        )
    if not np.all(np.diff(P_ro) >= 0):
        raise ValueError(
            "P_row_offsets must be monotonically non-decreasing"
        )

                                                         
    if A_ro[0] != 0:
        raise ValueError(
            f"A_row_offsets must start at 0, got {A_ro[0]}"
        )
    if not np.all(np.diff(A_ro) >= 0):
        raise ValueError(
            "A_row_offsets must be monotonically non-decreasing"
        )

                                                                     
    nnz_P = int(P_ro[-1])
    if len(P_ci) != nnz_P:
        raise ValueError(
            f"P_col_indices has length {len(P_ci)} but P_row_offsets indicates "
            f"nnz_P = {nnz_P} non-zeros."
        )

                                                                     
    nnz_A = int(A_ro[-1])
    if len(A_ci) != nnz_A:
        raise ValueError(
            f"A_col_indices has length {len(A_ci)} but A_row_offsets indicates "
            f"nnz_A = {nnz_A} non-zeros."
        )

                                                   
    if len(P_ci) > 0:
        if np.any(P_ci < 0) or np.any(P_ci >= n):
            bad_idx = P_ci[(P_ci < 0) | (P_ci >= n)]
            raise ValueError(
                f"P_col_indices contains invalid column index(es): {bad_idx[:5].tolist()}... "
                f"Valid range is [0, {n - 1}]."
            )

                                                   
    if len(A_ci) > 0:
        if np.any(A_ci < 0) or np.any(A_ci >= n):
            bad_idx = A_ci[(A_ci < 0) | (A_ci >= n)]
            raise ValueError(
                f"A_col_indices contains invalid column index(es): {bad_idx[:5].tolist()}... "
                f"Valid range is [0, {n - 1}]."
            )

                                       
    cone_total = cones.total_constraints()
    if cone_total != m:
        raise ValueError(
            f"Cone dimensions sum to {cone_total} but m={m}. "
            f"Total cone constraints must equal m."
        )


def _validate_smoothed_diff_cones(settings, cones):
    """Validate that smoothed differentiation is only used with supported cones.

    Smoothed diff requires zero + nonneg + SOC cones only (no exp or power).
    Raises ValueError if diff_method='smoothed' with unsupported cones.
    """
    if settings is None or not hasattr(settings, 'ipm_settings'):
        return
    ipm = settings.ipm_settings
    if ipm is None or getattr(ipm, 'diff_method', 'auto') != 'smoothed':
        return

    unsupported = []
    if cones.num_exp_cones > 0:
        unsupported.append("exponential")
    if len(cones.power_alphas) > 0:
        unsupported.append("power")
    if hasattr(cones, 'gen_power_cone_params') and len(cones.gen_power_cone_params) > 0:
        unsupported.append("generalized power")

    if unsupported:
        raise ValueError(
            f"diff_method='smoothed' only supports zero + nonneg + SOC cones, "
            f"but problem has {', '.join(unsupported)} cone(s). "
            f"Use diff_method='exact' or 'auto' instead."
        )


def _validate_setup_values(batch_size, nnz_P, nnz_A, P_values, A_values):
    """Validate P_values and A_values dimensions for setup().

    Args:
        batch_size: Expected batch size
        nnz_P: Number of non-zeros in P
        nnz_A: Number of non-zeros in A
        P_values: P matrix values array
        A_values: A matrix values array

    Raises:
        ValueError: If dimensions don't match
    """
    P_vals = np.asarray(P_values)
    A_vals = np.asarray(A_values)

                                                   
    if P_vals.ndim == 1:
        if P_vals.shape[0] != nnz_P:
            raise ValueError(
                f"P_values has length {P_vals.shape[0]} but expected nnz_P = {nnz_P}. "
                f"For shared values, shape should be ({nnz_P},)."
            )
    elif P_vals.ndim == 2:
        if P_vals.shape[0] != batch_size:
            raise ValueError(
                f"P_values has batch dimension {P_vals.shape[0]} but solver has "
                f"batch_size = {batch_size}."
            )
        if P_vals.shape[1] != nnz_P:
            raise ValueError(
                f"P_values has {P_vals.shape[1]} values per problem but expected "
                f"nnz_P = {nnz_P}. Shape should be ({batch_size}, {nnz_P})."
            )
    else:
        raise ValueError(
            f"P_values must be 1D (shared) or 2D (per-batch), got shape {P_vals.shape}"
        )

                                                   
    if A_vals.ndim == 1:
        if A_vals.shape[0] != nnz_A:
            raise ValueError(
                f"A_values has length {A_vals.shape[0]} but expected nnz_A = {nnz_A}. "
                f"For shared values, shape should be ({nnz_A},)."
            )
    elif A_vals.ndim == 2:
        if A_vals.shape[0] != batch_size:
            raise ValueError(
                f"A_values has batch dimension {A_vals.shape[0]} but solver has "
                f"batch_size = {batch_size}."
            )
        if A_vals.shape[1] != nnz_A:
            raise ValueError(
                f"A_values has {A_vals.shape[1]} values per problem but expected "
                f"nnz_A = {nnz_A}. Shape should be ({batch_size}, {nnz_A})."
            )
    else:
        raise ValueError(
            f"A_values must be 1D (shared) or 2D (per-batch), got shape {A_vals.shape}"
        )


def _validate_solve_inputs(batch_size, n, m, qs, bs):
    """Validate qs and bs dimensions for solve().

    Args:
        batch_size: Expected batch size
        n: Number of primal variables
        m: Number of constraints
        qs: q vectors (linear cost)
        bs: b vectors (constraint RHS)

    Raises:
        ValueError: If dimensions don't match
    """
    qs_arr = np.asarray(qs)
    bs_arr = np.asarray(bs)

                       
    if qs_arr.ndim == 1:
        if batch_size != 1:
            raise ValueError(
                f"qs is 1D but solver has batch_size = {batch_size}. "
                f"Expected shape ({batch_size}, {n})."
            )
        if qs_arr.shape[0] != n:
            raise ValueError(
                f"qs has length {qs_arr.shape[0]} but problem has n = {n} variables."
            )
    elif qs_arr.ndim == 2:
        if qs_arr.shape[0] != batch_size:
            raise ValueError(
                f"qs has batch dimension {qs_arr.shape[0]} but solver has "
                f"batch_size = {batch_size}."
            )
        if qs_arr.shape[1] != n:
            raise ValueError(
                f"qs has {qs_arr.shape[1]} elements per problem but expected "
                f"n = {n}. Shape should be ({batch_size}, {n})."
            )
    else:
        raise ValueError(
            f"qs must be 1D (batch_size=1) or 2D, got shape {qs_arr.shape}"
        )

                       
    if bs_arr.ndim == 1:
        if batch_size != 1:
            raise ValueError(
                f"bs is 1D but solver has batch_size = {batch_size}. "
                f"Expected shape ({batch_size}, {m})."
            )
        if bs_arr.shape[0] != m:
            raise ValueError(
                f"bs has length {bs_arr.shape[0]} but problem has m = {m} constraints."
            )
    elif bs_arr.ndim == 2:
        if bs_arr.shape[0] != batch_size:
            raise ValueError(
                f"bs has batch dimension {bs_arr.shape[0]} but solver has "
                f"batch_size = {batch_size}."
            )
        if bs_arr.shape[1] != m:
            raise ValueError(
                f"bs has {bs_arr.shape[1]} elements per problem but expected "
                f"m = {m}. Shape should be ({batch_size}, {m})."
            )
    else:
        raise ValueError(
            f"bs must be 1D (batch_size=1) or 2D, got shape {bs_arr.shape}"
        )


def _validate_P_symmetry(P, tol: float = 1e-10):
    """Validate that P matrix is numerically symmetric.

    P must be provided as full symmetric matrix (not just upper or lower triangle).

    Args:
        P: The P matrix (scipy sparse or numpy array)
        tol: Tolerance for symmetry check (default 1e-10)

    Raises:
        ValueError: If P is not numerically symmetric
    """
    if sparse.issparse(P):
        P_csr = P.tocsr()
        P_diff = P_csr - P_csr.T
        max_diff = abs(P_diff).max() if P_diff.nnz > 0 else 0.0
    else:
        P_arr = np.asarray(P)
        max_diff = np.max(np.abs(P_arr - P_arr.T))

    if max_diff > tol:
        raise ValueError(
            f"P matrix is not numerically symmetric (max|P - P^T| = {max_diff:.2e}). "
            f"P must be full symmetric, not upper or lower triangle only. "
            f"Use P = (P + P.T) / 2 to symmetrize, or provide the full symmetric matrix."
        )


def _validate_P_sparsity_pattern_symmetric(n: int, P_row_offsets, P_col_indices):
    """Validate that the P sparsity pattern is symmetric.

    For full symmetric P matrix requirement, the sparsity pattern must include
    both (i,j) and (j,i) for every off-diagonal entry.

    Args:
        n: Number of columns/rows in P
        P_row_offsets: CSR row pointers (length n+1)
        P_col_indices: CSR column indices

    Raises:
        ValueError: If sparsity pattern is not symmetric
    """
    P_ro = np.asarray(P_row_offsets)
    P_ci = np.asarray(P_col_indices)

                                                      
    entries = set()
    for row in range(n):
        start, end = P_ro[row], P_ro[row + 1]
        for idx in range(start, end):
            col = P_ci[idx]
            entries.add((row, col))

                                                     
    missing = []
    for row, col in entries:
        if row != col and (col, row) not in entries:
            missing.append((row, col))
            if len(missing) >= 5:                            
                break

    if missing:
        examples = ", ".join(f"({r},{c})" for r, c in missing[:3])
        raise ValueError(
            f"P sparsity pattern is not symmetric. "
            f"Found entries without their transpose: {examples}{'...' if len(missing) > 3 else ''}. "
            f"P must be a full symmetric matrix (both upper and lower triangles). "
            f"Ensure both P[i,j] and P[j,i] positions are included in the sparsity pattern."
        )


def _validate_P_values_symmetry(
    n: int, P_row_offsets, P_col_indices, P_values, tol: float = 1e-10
):
    """Validate P matrix symmetry from CSR components.

    P must be full symmetric (not upper/lower triangle only).
    This validates a single problem's P_values.

    Args:
        n: Number of columns/rows in P
        P_row_offsets: CSR row pointers
        P_col_indices: CSR column indices
        P_values: CSR values (for one problem, shape (nnz,))
        tol: Tolerance for symmetry check

    Raises:
        ValueError: If P is not numerically symmetric
    """
                                                  
    P_csr = sparse.csr_array(
        (P_values, P_col_indices, P_row_offsets),
        shape=(n, n)
    )
    P_diff = P_csr - P_csr.T
    max_diff = abs(P_diff).max() if P_diff.nnz > 0 else 0.0

    if max_diff > tol:
        raise ValueError(
            f"P matrix is not numerically symmetric (max|P - P^T| = {max_diff:.2e}). "
            f"P must be full symmetric, not upper or lower triangle only. "
            f"Ensure P_values contains both P[i,j] and P[j,i] entries."
        )


class Solver:
    """Single-problem conic optimization solver.

    All problem data is provided in the constructor, then call solve().

    Problem Formulation:
        minimize    (1/2)x'Px + q'x
        subject to  Ax + s = b
                    s ∈ K

    Args:
        P: Quadratic objective matrix (scipy sparse or numpy array).
            Must be full symmetric (both upper and lower triangles).
        q: Linear objective vector
        A: Constraint matrix (scipy sparse or numpy array)
        b: Constraint RHS vector
        cones: Cone specification (moreau.Cones object)
        settings: Optional solver settings (moreau.Settings object)

    Example:
        >>> import moreau
        >>> from scipy import sparse
        >>> import numpy as np
        >>>
        >>> P = sparse.diags([1.0, 1.0], format='csr')
        >>> q = np.array([2.0, 1.0])
        >>> A = sparse.csr_array([[1.0, 1.0], [1.0, 0.0], [0.0, 1.0]])
        >>> b = np.array([1.0, 0.7, 0.7])
        >>> cones = moreau.Cones(num_zero_cones=1, num_nonneg_cones=2)
        >>>
        >>> solver = moreau.Solver(P, q, A, b, cones)
        >>> solution = solver.solve()
        >>> print(solution.x, info.status)
    """

    def __init__(self, P, q, A, b, cones, settings=None):
                                                                         
        _validate_problem_dimensions(P, q, A, b, cones)

                                                                           
        _validate_smoothed_diff_cones(settings, cones)

                                            
        _warn_cvxpy_soc_if_needed(cones)

                                              
        if settings is None:
            settings = Settings()

                                      
        device = settings.device
        enable_grad = settings.enable_grad
        n = len(q)

                                                                     
        if sparse.issparse(P):
            nnz_P = P.nnz
        else:
            nnz_P = np.count_nonzero(P)
        settings, device = _resolve_solver_type(settings, n, len(b), cones, device, nnz_P=nnz_P)

                                                                               
        if device == 'auto':
                                                  
            if sparse.issparse(A):
                nnz_A = A.nnz
            else:
                nnz_A = np.count_nonzero(A)
            device = _choose_device(n, nnz_A, batch_size=1)

                                      
        if not device_available(device):
            error = device_error(device) or ''
            raise RuntimeError(
                f"Device '{device}' is not available. {error}\n"
                f"Available devices: {available_devices()}"
            )

        self._device = device
        self._settings = settings
        self._enable_grad = enable_grad

                                    
                                                                                
        _validate_P_symmetry(P)

                                        
        P_row_offsets, P_col_indices, P_values = _to_csr(P)
        A_row_offsets, A_col_indices, A_values = _to_csr(A)

                            
        q = np.asarray(q, dtype=np.float64)
        b = np.asarray(b, dtype=np.float64)

        self._n = len(q)
        self._m = len(b)
        self._nnz_P = len(P_values)
        self._nnz_A = len(A_values)

                         
        self._P_values = P_values
        self._A_values = A_values
        self._q = q
        self._b = b
        self._cones = cones

                             
        self._P_row_offsets = P_row_offsets
        self._P_col_indices = P_col_indices
        self._A_row_offsets = A_row_offsets
        self._A_col_indices = A_col_indices

        construction_start = time.perf_counter()
        self._init_device(device, cones, settings, enable_grad)
        self._construction_time = time.perf_counter() - construction_start

                                                   
        self._info: Optional[SolveInfo] = None

    def _init_device(self, device, cones, settings, enable_grad):
        """Initialize a registered device backend."""
                                                         
        if settings is not None and settings.solver == SolverType.ACTIVE_SET:
            from moreau_cpu._cpu import ActiveSetSolver
            self._device_cones = cones
            self._device_settings = settings
            self._impl = ActiveSetSolver(
                self._n, self._m,
                self._P_row_offsets, self._P_col_indices,
                self._A_row_offsets, self._A_col_indices,
                cones, settings,
                batch_size=1,
                enable_grad=enable_grad,
            )
            setup_start = time.perf_counter()
            self._impl.setup(self._P_values, self._A_values)
            self._setup_time = time.perf_counter() - setup_start
            return

        DeviceSolver = _get_device_component(device, 'solver')
        if DeviceSolver is None:
            raise RuntimeError(
                f"No solver registered for device '{device}'. "
                f"Available devices: {available_devices()}"
            )
        DeviceSettings = _get_device_component(device, 'settings')
        cones_converter = _get_device_component(device, 'cones_converter')
        settings_converter = _get_device_component(device, 'settings_converter')

                                                  
        if cones_converter is not None:
            device_cones = cones_converter(cones)
        else:
            device_cones = cones
        self._device_cones = device_cones

                                                     
        if settings is None:
            device_settings = DeviceSettings() if DeviceSettings else None
            if device_settings is not None and hasattr(device_settings, 'verbose'):
                device_settings.verbose = True
        elif settings_converter is not None:
            device_settings = settings_converter(settings)
        else:
            device_settings = settings
        self._device_settings = device_settings

                                                                              
                                                
        self._impl = DeviceSolver(
            self._n, self._m,
            self._P_row_offsets, self._P_col_indices,
            self._A_row_offsets, self._A_col_indices,
            device_cones, device_settings,
            batch_size=1,
            enable_grad=enable_grad,
        )

                                      
        setup_start = time.perf_counter()
        self._impl.setup(self._P_values, self._A_values)
        self._setup_time = time.perf_counter() - setup_start

                                                                            
    _WARM_START_NO_RETRY = frozenset({
        SolverStatus.Solved,
        SolverStatus.AlmostSolved,
        SolverStatus.MaxIterations,
        SolverStatus.CallbackTerminated,
    })

    def solve(self, warm_start=None) -> Solution:
        """Solve the optimization problem.

        Args:
            warm_start: Optional WarmStart from a previous solve
                (e.g. ``solution.to_warm_start()``). If the warm-started solve
                fails, it is automatically retried without warm start.

        Returns:
            Solution: primal/dual solution vectors (x, z, s)

        Note:
            Solver metadata (status, timing, iterations) is available via solver.info
            after calling solve().
        """
        kwargs = {}
        if warm_start is not None:
            if not isinstance(warm_start, WarmStart):
                raise TypeError(
                    f"warm_start must be a WarmStart, "
                    f"got {type(warm_start).__name__}")

            warm_x = np.asarray(warm_start.x, dtype=np.float64)
            warm_z = np.asarray(warm_start.z, dtype=np.float64)
            warm_s = np.asarray(warm_start.s, dtype=np.float64)

            if warm_x.shape != (self._n,):
                raise ValueError(
                    f"warm_start.x shape {warm_x.shape}, expected ({self._n},)")
            if warm_z.shape != (self._m,):
                raise ValueError(
                    f"warm_start.z shape {warm_z.shape}, expected ({self._m},)")
            if warm_s.shape != (self._m,):
                raise ValueError(
                    f"warm_start.s shape {warm_s.shape}, expected ({self._m},)")

                                                                       
            kwargs['warm_x'] = warm_x.reshape(1, -1)
            kwargs['warm_z'] = warm_z.reshape(1, -1)
            kwargs['warm_s'] = warm_s.reshape(1, -1)

        result = self._impl.solve(self._q, self._b, **kwargs)

                                                         
                                                                                
        construction_time = result.get('construction_time', 0.0)
        if construction_time == 0.0:
            construction_time = self._construction_time
        setup_time = result.get('setup_time', 0.0)
        if setup_time == 0.0 and hasattr(self, '_setup_time'):
            setup_time = self._setup_time
        solve_time = result.get('solve_time', 0.0)

        status = _normalize_status(result['status'])

        solution = Solution(
            x=result['x'],
            z=result['z'],
            s=result['s'],
        )

        self._info = SolveInfo(
            status=status,
            obj_val=float(result['obj_val']),
            iterations=result['iterations'],
            solve_time=solve_time,
            setup_time=setup_time,
            construction_time=construction_time,
        )

                                                                   
        ipm = self._settings.ipm_settings
        no_retry = ipm.warm_start_no_retry if (ipm and ipm.warm_start_no_retry is not None) else self._WARM_START_NO_RETRY
        if warm_start is not None and status not in no_retry:
            warnings.warn(
                f"Warm-started solve failed ({status.name}), "
                f"retrying without warm start.",
                stacklevel=2,
            )
            result = self._impl.solve(self._q, self._b)
            construction_time = result.get('construction_time', 0.0)
            if construction_time == 0.0:
                construction_time = self._construction_time
            setup_time = result.get('setup_time', 0.0)
            if setup_time == 0.0 and hasattr(self, '_setup_time'):
                setup_time = self._setup_time
            solve_time = result.get('solve_time', 0.0)
            status = _normalize_status(result['status'])
            solution = Solution(
                x=result['x'],
                z=result['z'],
                s=result['s'],
            )
            self._info = SolveInfo(
                status=status,
                obj_val=float(result['obj_val']),
                iterations=result['iterations'],
                solve_time=solve_time,
                setup_time=setup_time,
                construction_time=construction_time,
            )

        return solution

    def backward(self, dx, dz=None, ds=None):
        """Compute gradients via implicit differentiation using cached state."""
        return self._impl.backward(dx, dz, ds)

    @property
    def device(self) -> str:
        return self._device

    @property
    def n(self) -> int:
        return self._n

    @property
    def m(self) -> int:
        return self._m

    @property
    def construction_time(self) -> float:
        """Time spent constructing solver structure (seconds)."""
        return self._construction_time

    @property
    def info(self) -> Optional[SolveInfo]:
        """Metadata from the last solve() call.

        Returns None if solve() has not been called yet.

        Contains:
            - status: SolverStatus enum
            - obj_val: Objective value at solution
            - iterations: Number of IPM iterations
            - solve_time: Time in IPM iterations (seconds)
            - setup_time: Time setting matrix values (seconds)
            - construction_time: Time constructing solver (seconds)
        """
        return self._info


class CompiledSolver:
    """Compiled solver for multiple conic optimization problems with shared structure.

    Problem structure is defined at construction, matrix values via setup(),
    and solve parameters (q, b) via solve().

    Three-step API pattern:
    1. Construct with structure (dimensions, sparsity patterns, cones)
    2. setup(P_values, A_values) - Set matrix values for batch
    3. solve(qs, bs) - Solve with per-problem parameters

    Args:
        n: Number of primal variables
        m: Number of constraints
        P_row_offsets: CSR row pointers for P matrix (must be full symmetric)
        P_col_indices: CSR column indices for P matrix (must be full symmetric)
        A_row_offsets: CSR row pointers for A matrix
        A_col_indices: CSR column indices for A matrix
        cones: Cone specification (moreau.Cones object)
        settings: Solver settings (moreau.Settings object). Controls device, batch_size,
                  enable_grad, tolerances, etc. Defaults to Settings() if not provided.

    Example:
        >>> import moreau
        >>> import numpy as np
        >>>
        >>> cones = moreau.Cones(num_zero_cones=1, num_nonneg_cones=2)
        >>> settings = moreau.Settings(batch_size=4)
        >>> solver = moreau.CompiledSolver(
        ...     n=2, m=3,
        ...     P_row_offsets=[0, 1, 2], P_col_indices=[0, 1],
        ...     A_row_offsets=[0, 2, 3, 4], A_col_indices=[0, 1, 0, 1],
        ...     cones=cones, settings=settings
        ... )
        >>>
        >>> P_values = [[1.0, 1.0]] * 4
        >>> A_values = [[1.0, 1.0, 1.0, 1.0]] * 4
        >>> solver.setup(P_values, A_values)
        >>>
        >>> qs = [[2.0, 1.0]] * 4
        >>> bs = [[1.0, 0.7, 0.7]] * 4
        >>> solution = solver.solve(qs, bs)
        >>> print(solution.x.shape, info.status[0])
    """

    def __init__(self, n, m, P_row_offsets, P_col_indices,
                 A_row_offsets, A_col_indices, cones,
                 settings=None):

                                                                    
        _validate_csr_structure(n, m, P_row_offsets, P_col_indices,
                                A_row_offsets, A_col_indices, cones)

                                                                            
                                                                        
        _validate_P_sparsity_pattern_symmetric(n, P_row_offsets, P_col_indices)

                                                                           
        _validate_smoothed_diff_cones(settings, cones)

                                            
        _warn_cvxpy_soc_if_needed(cones)

                                              
        if settings is None:
            settings = Settings()

                          
        device = settings.device
        batch_size = settings.batch_size
        enable_grad = settings.enable_grad

                                                                     
        nnz_P = len(P_col_indices)
        settings, device = _resolve_solver_type(settings, n, m, cones, device, nnz_P=nnz_P)

                                                                               
        if device == 'auto':
            nnz_A = len(A_col_indices)
            device = _choose_device(n, nnz_A, batch_size=batch_size)

                                      
        if not device_available(device):
            error = device_error(device) or ''
            raise RuntimeError(
                f"Device '{device}' is not available. {error}\n"
                f"Available devices: {available_devices()}"
            )

        self._device = device
        self._n = n
        self._m = m
        self._batch_size = batch_size
        self._enable_grad = enable_grad
        self._nnz_P = len(P_col_indices)
        self._nnz_A = len(A_col_indices)

                           
        self._P_row_offsets = np.asarray(P_row_offsets, dtype=np.int64)
        self._P_col_indices = np.asarray(P_col_indices, dtype=np.int64)
        self._A_row_offsets = np.asarray(A_row_offsets, dtype=np.int64)
        self._A_col_indices = np.asarray(A_col_indices, dtype=np.int64)
        self._cones = cones
        self._settings = settings

                                                                  
                                                                             
                                                                          
                                                                                  
                                                         
        self._original_device = settings.device
        ipm = settings.ipm_settings
        self._original_method = ipm.direct_solve_method if ipm else 'auto'
        if self._original_method == 'auto' and settings.device != 'auto':
            from moreau._backend import _rank_method
            ranked = _rank_method(device, n, m, self._nnz_A, batch_size)
            initial_method = ranked[0] if ranked else 'auto'
            if ipm:
                ipm.direct_solve_method = initial_method

        construction_start = time.perf_counter()
        self._init_device(device, cones, settings, batch_size, enable_grad)
        self._construction_time = time.perf_counter() - construction_start

                         
        self._auto_tuned = False
        self._tune_result: Optional[TuneResult] = None

                                                   
        self._info: Optional[BatchedSolveInfo] = None

    def _init_device(self, device, cones, settings, batch_size, enable_grad):
        """Initialize a registered device backend."""
                                                                             
        if settings is not None and settings.solver == SolverType.ACTIVE_SET:
            from moreau_cpu._cpu import ActiveSetSolver
            self._device_cones = cones
            self._device_settings = settings
            self._impl = ActiveSetSolver(
                self._n, self._m,
                self._P_row_offsets, self._P_col_indices,
                self._A_row_offsets, self._A_col_indices,
                cones, settings,
                batch_size=batch_size,
                enable_grad=enable_grad,
            )
            return

        DeviceSolver = _get_device_component(device, 'solver')
        if DeviceSolver is None:
            raise RuntimeError(
                f"No solver registered for device '{device}'. "
                f"Available devices: {available_devices()}"
            )
        DeviceSettings = _get_device_component(device, 'settings')
        cones_converter = _get_device_component(device, 'cones_converter')
        settings_converter = _get_device_component(device, 'settings_converter')

                                                  
        if cones_converter is not None:
            device_cones = cones_converter(cones)
        else:
            device_cones = cones
        self._device_cones = device_cones

                                                     
        if settings is None:
            device_settings = DeviceSettings() if DeviceSettings else None
            if device_settings is not None and hasattr(device_settings, 'verbose'):
                device_settings.verbose = True
        elif settings_converter is not None:
            device_settings = settings_converter(settings)
        else:
            device_settings = settings
        self._device_settings = device_settings

                                   
        self._impl = DeviceSolver(
            self._n, self._m,
            self._P_row_offsets, self._P_col_indices,
            self._A_row_offsets, self._A_col_indices,
            device_cones, device_settings,
            batch_size=batch_size,
            enable_grad=enable_grad,
        )

    def setup(self, P_values, A_values):
        """Set P and A matrix values for the batch.

        Args:
            P_values: P matrix values. Shape (batch, nnz_P) for per-problem values,
                      or (nnz_P,) to share across all problems in the batch.
            A_values: A matrix values. Shape (batch, nnz_A) for per-problem values,
                      or (nnz_A,) to share across all problems in the batch.
        """
                                                                         
        _validate_setup_values(self._batch_size, self._nnz_P, self._nnz_A,
                               P_values, A_values)

        P_values = np.asarray(P_values, dtype=np.float64)
        A_values = np.asarray(A_values, dtype=np.float64)

                                                                      
                                                                

                                                                      
        if P_values.size > 0:
            P_vals_0 = P_values[0] if P_values.ndim > 1 else P_values
            _validate_P_values_symmetry(
                self._n, self._P_row_offsets, self._P_col_indices, P_vals_0
            )

                                                                        
        self._cached_P_values = P_values
        self._cached_A_values = A_values

        setup_start = time.perf_counter()
        self._impl.setup(P_values, A_values)
        self._setup_time = time.perf_counter() - setup_start

                                                                            
                                               
    _WARM_START_NO_RETRY = frozenset({
        SolverStatus.Solved,
        SolverStatus.AlmostSolved,
        SolverStatus.MaxIterations,
        SolverStatus.CallbackTerminated,
    })

    _AUTO_TUNE_MARGIN = 1.5

    def _needs_auto_tune(self) -> bool:
        """Check if auto-tune benchmarking should run on this solve."""
        if self._auto_tuned:
            return False
        if not self._settings.auto_tune:
            return False
                                                               
        if self._settings.solver == SolverType.ACTIVE_SET:
            return False
                                                                              
        from moreau._backend import _default_device_override
        if self._original_device == 'auto' and _default_device_override is not None:
            return False
                                                       
        if self._original_device == 'auto':
            return True
        if self._original_method == 'auto':
            return True
        return False

    def _auto_tune(self, qs, bs):
        """Benchmark solver configs and lock in the fastest.

        1. Solve with current (heuristic-best) config — keep the result
        2. Benchmark remaining combos with time_limit = best_time * margin
        3. If a challenger wins, reconfigure self and re-solve
        """
        warnings.warn(
            "First solve is benchmarking solver configurations "
            "(auto_tune=True). Subsequent solves will be faster. "
            "Set auto_tune=False (default) to use heuristic selection "
            "without benchmarking.",
            stacklevel=3,
        )
        if not hasattr(self, '_cached_P_values') or self._cached_P_values is None:
            raise RuntimeError(
                "setup() must be called before solve(). "
                "Matrix values are needed to benchmark solvers."
            )

                                                               
        candidates = _auto_tune_candidates(
            self._original_device, self._original_method,
            n=self._n, m=self._m,
            nnz_P=self._nnz_P, nnz_A=self._nnz_A,
            batch_size=self._batch_size,
        )

        if not candidates:
            self._auto_tuned = True
            return

                                  
        verbose = self._settings.verbose
        results = {}
        best_time = float('inf')
        best_key = None
        construction_limit = None

        if verbose:
            _print = lambda *a, **kw: print(*a, **kw, flush=True)
            _print(f"[moreau] auto-tune: benchmarking {len(candidates)} "
                   f"candidate(s)...")
        else:
            _print = None

        for trial_device, trial_method in candidates:
            key = f"{trial_device}:{trial_method}"

            trial_settings = self._settings.model_copy(deep=True)
            trial_settings.device = trial_device
            trial_settings.verbose = False
            trial_settings.auto_tune = False                               
            if trial_settings.ipm_settings is None:
                trial_settings.ipm_settings = IPMSettings()
            trial_settings.ipm_settings.direct_solve_method = trial_method
                                                            
            if best_time < float('inf'):
                trial_settings.time_limit = min(
                    best_time * self._AUTO_TUNE_MARGIN,
                    trial_settings.time_limit,
                )

                                       
            build_t0 = time.perf_counter()
            trial_solver = CompiledSolver(
                n=self._n, m=self._m,
                P_row_offsets=self._P_row_offsets,
                P_col_indices=self._P_col_indices,
                A_row_offsets=self._A_row_offsets,
                A_col_indices=self._A_col_indices,
                cones=self._cones,
                settings=trial_settings,
            )
            trial_solver.setup(self._cached_P_values, self._cached_A_values)
            build_time = time.perf_counter() - build_t0

                                                           
            if construction_limit is None:
                construction_limit = max(build_time * 5, 1.0)

                                                
            if build_time > construction_limit:
                results[key] = {
                    'solve_time': float('inf'),
                    'iterations': 0,
                    'status': [SolverStatus.NumericalError],
                }
                if _print:
                    _print(f"[moreau] auto-tune:   {key:<16s} "
                           f"{build_time:.3f}s build  "
                           f"skipped (build > {construction_limit:.2f}s limit)")
                continue

            trial_solver.solve(qs, bs)

            info = trial_solver.info
            results[key] = {
                'solve_time': info.solve_time,
                'iterations': info.iterations,
                'status': info.status,
            }

            _ok = (SolverStatus.Solved, SolverStatus.AlmostSolved)
            statuses = info.status if isinstance(info.status, list) else [info.status]
            is_ok = all(s in _ok for s in statuses)
            if is_ok and info.solve_time < best_time:
                best_time = info.solve_time
                best_key = key

            if _print:
                iters = info.iterations
                iters_str = str(max(iters)) if isinstance(iters, list) else str(iters)
                names = set(s.name if hasattr(s, 'name') else str(s) for s in statuses)
                status_str = names.pop() if len(names) == 1 else '/'.join(sorted(names))
                marker = " *" if key == best_key else ""
                _print(f"[moreau] auto-tune:   {key:<16s} "
                       f"{build_time:.3f}s build  "
                       f"{info.solve_time:.4f}s solve  "
                       f"{iters_str} iters  "
                       f"{status_str}{marker}")

                                                                    
        if best_key is None and results:
            best_key = min(results, key=lambda k: results[k]['solve_time'])
            best_time = results[best_key]['solve_time']

        if best_key is None:
                                                                   
            self._auto_tuned = True
            return

        best_device, best_method = best_key.split(':', 1)
        tuned_limit = best_time * self._AUTO_TUNE_MARGIN
        time_limit = max(tuned_limit, self._settings.time_limit)

        if _print:
            _print(f"[moreau] auto-tune: winner {best_device}:{best_method} "
                   f"({best_time:.4f}s solve)")

        self._tune_result = TuneResult(
            device=best_device,
            method=best_method,
            time_limit=time_limit,
            results=results,
        )

                                                 
                                                                         
                                                                         
        winning_settings = self._settings.model_copy(deep=True)
        winning_settings.device = best_device
        if winning_settings.ipm_settings is None:
            winning_settings.ipm_settings = IPMSettings()
        winning_settings.ipm_settings.direct_solve_method = best_method
        winning_settings.time_limit = time_limit

        DeviceSolver = _get_device_component(best_device, 'solver')
        cones_converter = _get_device_component(best_device, 'cones_converter')
        settings_converter = _get_device_component(best_device, 'settings_converter')

        new_device_cones = cones_converter(self._cones) if cones_converter else self._cones
        if settings_converter is not None:
            new_device_settings = settings_converter(winning_settings)
        else:
            new_device_settings = winning_settings

        new_impl = DeviceSolver(
            self._n, self._m,
            self._P_row_offsets, self._P_col_indices,
            self._A_row_offsets, self._A_col_indices,
            new_device_cones, new_device_settings,
            batch_size=self._batch_size,
            enable_grad=self._enable_grad,
        )
        new_impl.setup(self._cached_P_values, self._cached_A_values)

                                         
        self._settings = winning_settings
        self._device = best_device
        self._device_cones = new_device_cones
        self._device_settings = new_device_settings
        self._impl = new_impl
        self._auto_tuned = True

    def solve(self, qs, bs, warm_start=None) -> BatchedSolution:
        """Solve a batch of problems with optional warm starting.

        On the first call, if device or method is 'auto', automatically
        benchmarks all candidate configurations and locks in the fastest
        for subsequent solves.

        Args:
            qs: List of q vectors (linear cost), one per problem
            bs: List of b vectors (constraint RHS), one per problem
            warm_start: Optional WarmStart or BatchedWarmStart from a previous
                solve (e.g. ``solution.to_warm_start()``). The solver applies
                central-path smoothing internally. If the warm-started solve
                fails, it is automatically retried without warm start.
                Control which statuses trigger retry via
                ``IPMSettings.warm_start_no_retry``.

        Returns:
            BatchedSolution: primal/dual solution arrays (batch, n/m)

        Note:
            Solver metadata (status, timing, iterations) is available via solver.info
            after calling solve().
        """
                                                                         
        _validate_solve_inputs(self._batch_size, self._n, self._m, qs, bs)

        qs = np.asarray(qs, dtype=np.float64)
        bs = np.asarray(bs, dtype=np.float64)

                                                                  
        if self._needs_auto_tune():
            self._auto_tune(qs, bs)

        kwargs = {}
        if warm_start is not None:
            if not isinstance(warm_start, (WarmStart, BatchedWarmStart)):
                raise TypeError(
                    f"warm_start must be a WarmStart or BatchedWarmStart, "
                    f"got {type(warm_start).__name__}")

            warm_x = np.asarray(warm_start.x, dtype=np.float64)
            warm_z = np.asarray(warm_start.z, dtype=np.float64)
            warm_s = np.asarray(warm_start.s, dtype=np.float64)

                                                             
            if warm_x.ndim == 1:
                warm_x = warm_x.reshape(1, -1)
            if warm_z.ndim == 1:
                warm_z = warm_z.reshape(1, -1)
            if warm_s.ndim == 1:
                warm_s = warm_s.reshape(1, -1)

            if warm_x.shape != (self._batch_size, self._n):
                raise ValueError(
                    f"warm_start.x shape {warm_x.shape}, expected ({self._batch_size}, {self._n})")
            if warm_z.shape != (self._batch_size, self._m):
                raise ValueError(
                    f"warm_start.z shape {warm_z.shape}, expected ({self._batch_size}, {self._m})")
            if warm_s.shape != (self._batch_size, self._m):
                raise ValueError(
                    f"warm_start.s shape {warm_s.shape}, expected ({self._batch_size}, {self._m})")

            kwargs['warm_x'] = warm_x
            kwargs['warm_z'] = warm_z
            kwargs['warm_s'] = warm_s

        result = self._impl.solve(qs, bs, **kwargs)
        solution, status = self._process_result(result)

                                                                   
        ipm = self._settings.ipm_settings
        no_retry = ipm.warm_start_no_retry if (ipm and ipm.warm_start_no_retry is not None) else self._WARM_START_NO_RETRY
        if warm_start is not None and any(
            s not in no_retry for s in status
        ):
            failed = [s.name for s in status if s not in no_retry]
            warnings.warn(
                f"Warm-started solve failed ({', '.join(failed)}), "
                f"retrying without warm start.",
                stacklevel=2,
            )
            result = self._impl.solve(qs, bs)
            solution, status = self._process_result(result)

        return solution

    def _process_result(self, result):
        """Convert raw backend result into BatchedSolution and status list."""
        construction_time = result.get('construction_time', 0.0)
        if construction_time == 0.0:
            construction_time = self._construction_time
        setup_time = result.get('setup_time', 0.0)
        if setup_time == 0.0 and hasattr(self, '_setup_time'):
            setup_time = self._setup_time
        solve_time = result.get('solve_time', 0.0)

        raw_status = result['status']
        if np.isscalar(raw_status) or (hasattr(raw_status, 'ndim') and raw_status.ndim == 0):
            status = [_normalize_status(int(raw_status))]
        else:
            status = [_normalize_status(s) for s in raw_status]

        solution = BatchedSolution(
            x=result['x'],
            z=result['z'],
            s=result['s'],
        )

        self._info = BatchedSolveInfo(
            status=status,
            obj_val=result['obj_val'],
            iterations=result['iterations'],
            solve_time=solve_time,
            setup_time=setup_time,
            construction_time=construction_time,
        )

        return solution, status

    def backward(self, dx, dz=None, ds=None):
        """Compute gradients via implicit differentiation using cached state."""
        return self._impl.backward(dx, dz, ds)

    @property
    def device(self) -> str:
        return self._device

    @property
    def n(self) -> int:
        return self._n

    @property
    def m(self) -> int:
        return self._m

    @property
    def batch_size(self) -> int:
        return self._batch_size

    @property
    def construction_time(self) -> float:
        """Time spent constructing solver structure (seconds)."""
        return self._construction_time

    @property
    def tune_result(self) -> Optional[TuneResult]:
        """Result from auto-tuning on the first solve() call.

        Returns None if auto-tune has not run yet (e.g. device and method
        were set explicitly, or solve() has not been called).
        """
        return self._tune_result

    @property
    def info(self) -> Optional[BatchedSolveInfo]:
        """Metadata from the last solve() call.

        Returns None if solve() has not been called yet.

        Contains:
            - status: List of SolverStatus enums (one per problem)
            - obj_val: Objective values array, shape (batch_size,)
            - iterations: Number of IPM iterations
            - solve_time: Time in IPM iterations (seconds)
            - setup_time: Time setting matrix values (seconds)
            - construction_time: Time constructing solver (seconds)
        """
        return self._info


__all__ = [
                    
    'Solver', 'CompiledSolver',
    'Cones', 'Settings', 'IPMSettings', 'ActiveSetSettings', 'SolverType', 'SolverStatus',
    'WarmStart', 'BatchedWarmStart',
    'SolveInfo', 'Solution', 'BatchedSolveInfo', 'BatchedSolution',
    'TuneResult',
                
    'available_devices', 'device_available', 'device_error',
    'default_device', 'set_default_device', 'get_default_device',
    'torch_available', 'jax_available',
    '__version__',
]
