"""Shared type definitions for moreau package.

This module defines the core data types used across CPU and GPU backends:
- SolverStatus: Unified status enum
- Cones: Cone specification
- Settings: Solver settings with sub-settings for different solver types

These are pure Python types that each backend converts internally.
"""
from dataclasses import dataclass, field
from enum import IntEnum, Enum
from typing import Dict, FrozenSet, List, Literal, Optional, Set, Union, Annotated

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict


class SolverType(str, Enum):
    """Solver algorithm type.

    - AUTO: Automatically select solver based on problem structure (default).
            Uses active-set for small QPs (n ≤ 500, m ≤ max(500, 2n), zero+nonneg only),
            IPM otherwise.
    - IPM: Interior-point method. High accuracy, moderate speed.
           Supports automatic differentiation. All cone types.
    - ACTIVE_SET: Dual active-set method. Very fast for small QPs.
                  CPU-only. Zero + nonneg cones only. Supports differentiation.
    """
    AUTO = "auto"
    IPM = "ipm"
    ACTIVE_SET = "active_set"


class SolverStatus(IntEnum):
    """Unified solver status enum supporting both CPU and GPU backends.

    This IntEnum provides a consistent API regardless of backend:
    - Supports direct comparison: status == SolverStatus.Solved
    - Supports int comparison: status == 1
    - Has .value and .name properties
    - Works with int(): int(status) == 1
    """
    Unsolved = 0
    Solved = 1
    PrimalInfeasible = 2
    DualInfeasible = 3
    AlmostSolved = 4
    AlmostPrimalInfeasible = 5
    AlmostDualInfeasible = 6
    MaxIterations = 7
    MaxTime = 8
    NumericalError = 9
    InsufficientProgress = 10
    CallbackTerminated = 11


class Cones(BaseModel):
    """Cone specification for conic optimization problems.

    Attributes:
        num_zero_cones: Number of equality constraint dimensions (zero cone)
        num_nonneg_cones: Number of inequality constraint dimensions (nonnegative cone)
        so_cone_dims: List of second-order cone dimensions (each >= 2)
        num_exp_cones: Number of exponential cones (each is 3D)
        power_alphas: List of power cone alpha parameters (each cone is 3D)
        gen_power_cone_params: List of generalized power cone parameters.
            Each element is (alphas, dim2) where alphas is a list of positive
            floats summing to 1 (length = dim1) and dim2 >= 1. Total cone
            dimension is dim1 + dim2.

    Example:
        >>> cones = Cones(num_zero_cones=1, num_nonneg_cones=2, so_cone_dims=[3, 5])
        >>> # Backward compat: num_so_cones=2 creates [3, 3]
        >>> cones = Cones(num_zero_cones=1, num_nonneg_cones=2, num_so_cones=2)
        >>> # GenPowerCone: alphas=[0.3, 0.7], dim2=2 => total dim = 4
        >>> cones = Cones(gen_power_cone_params=[([0.3, 0.7], 2)])
    """
    model_config = ConfigDict(validate_assignment=True)

    num_zero_cones: Annotated[int, Field(ge=0)] = 0
    num_nonneg_cones: Annotated[int, Field(ge=0)] = 0
    so_cone_dims: List[int] = Field(default_factory=list)
    num_exp_cones: Annotated[int, Field(ge=0)] = 0
    power_alphas: List[float] = Field(default_factory=list)
    gen_power_cone_params: List[tuple] = Field(default_factory=list)

    @model_validator(mode='before')
    @classmethod
    def compat_num_so_cones(cls, data):
        """Backward compat: num_so_cones=N -> so_cone_dims=[3]*N."""
        if isinstance(data, dict) and 'num_so_cones' in data and 'so_cone_dims' not in data:
            n = data.pop('num_so_cones')
            if n < 0:
                raise ValueError(f"num_so_cones must be >= 0, got {n}")
            if n > 0:
                data['so_cone_dims'] = [3] * n
        return data


    @field_validator('so_cone_dims')
    @classmethod
    def validate_so_cone_dims(cls, v: List[int]) -> List[int]:
        """Validate SOC dimensions are >= 2."""
        for i, d in enumerate(v):
            if d < 2:
                raise ValueError(
                    f"so_cone_dims[{i}] = {d}, must be >= 2"
                )
        return v

    @field_validator('power_alphas')
    @classmethod
    def validate_power_alphas(cls, v: List[float]) -> List[float]:
        """Validate power cone alphas are in (0, 1)."""
        for i, alpha in enumerate(v):
            if not (0 < alpha < 1):
                raise ValueError(
                    f"power_alphas[{i}] = {alpha} must be in (0, 1)"
                )
        return v

    @field_validator('gen_power_cone_params')
    @classmethod
    def validate_gen_power_cone_params(cls, v: List[tuple]) -> List[tuple]:
        """Validate generalized power cone parameters."""
        for i, param in enumerate(v):
            if not isinstance(param, (list, tuple)) or len(param) != 2:
                raise ValueError(
                    f"gen_power_cone_params[{i}] must be (alphas, dim2)"
                )
            alphas, dim2 = param
            alphas = list(alphas)                               
            try:
                dim2 = int(dim2)
            except (TypeError, ValueError):
                raise ValueError(
                    f"gen_power_cone_params[{i}]: dim2 must be convertible to int"
                )
            if len(alphas) == 0:
                raise ValueError(
                    f"gen_power_cone_params[{i}]: alphas must be a non-empty list"
                )
            if dim2 < 1:
                raise ValueError(
                    f"gen_power_cone_params[{i}]: dim2 must be an integer >= 1"
                )
            for j, a in enumerate(alphas):
                if not (a > 0):
                    raise ValueError(
                        f"gen_power_cone_params[{i}].alphas[{j}] = {a} must be > 0"
                    )
            alpha_sum = sum(alphas)
            if abs(alpha_sum - 1.0) > 1e-8 * len(alphas):
                raise ValueError(
                    f"gen_power_cone_params[{i}]: alphas must sum to 1, got {alpha_sum}"
                )
            v[i] = (alphas, dim2)
        return v

    @property
    def num_so_cones(self) -> int:
        """Number of second-order cones."""
        return len(self.so_cone_dims)

    @property
    def num_power_cones(self) -> int:
        """Number of power cones."""
        return len(self.power_alphas)

    @property
    def num_gen_power_cones(self) -> int:
        """Number of generalized power cones."""
        return len(self.gen_power_cone_params)

    def total_constraints(self) -> int:
        """Total number of constraint rows across all cones."""
        total = self.num_zero_cones + self.num_nonneg_cones
        total += sum(self.so_cone_dims)
        total += 3 * self.num_exp_cones
        total += 3 * len(self.power_alphas)
        for alphas, dim2 in self.gen_power_cone_params:
            total += len(alphas) + dim2
        return total

    def degree(self) -> int:
        """Degree of the cone (barrier function degree)."""
        deg = self.num_nonneg_cones
        deg += len(self.so_cone_dims)
        deg += 3 * self.num_exp_cones
        deg += 3 * len(self.power_alphas)
        for alphas, _dim2 in self.gen_power_cone_params:
                                            
            deg += len(alphas) + 1
        return deg


class IPMSettings(BaseModel):
    """Interior-point method specific settings.

    These settings control the behavior of the IPM solver algorithm.
    They are stored in Settings.ipm_settings when solver='ipm'.

    Attributes:
        Convergence tolerances:
        tol_gap_abs: Absolute duality gap tolerance (default: 1e-8)
        tol_gap_rel: Relative duality gap tolerance (default: 1e-8)
        tol_feas: Feasibility tolerance (default: 1e-8)
        tol_infeas_abs: Absolute infeasibility tolerance (default: 1e-8)
        tol_infeas_rel: Relative infeasibility tolerance (default: 1e-8)
        tol_ktratio: KT ratio tolerance for homogeneous self-dual (default: 1e-6)

        Algorithm control:
        max_step_fraction: Maximum step size fraction (default: 0.99)
        equilibrate_enable: Enable matrix equilibration (default: True)
        direct_solve_method: KKT solver method (default: 'auto')
            Options: 'auto', 'qdldl', 'faer-1t', 'faer-nt', 'faer', 'cudss', 'riccati'
            Note: 'qdldl' is CPU-only; 'cudss' is CUDA-only; 'riccati' requires
            block-tridiagonal structure (MPC/LQR problems).

        Reduced tolerances (for relaxed convergence):
        reduced_tol_gap_abs: Reduced absolute duality gap tolerance (default: 5e-5)
        reduced_tol_gap_rel: Reduced relative duality gap tolerance (default: 5e-5)
        reduced_tol_feas: Reduced feasibility tolerance (default: 1e-4)
        reduced_tol_infeas_abs: Reduced absolute infeasibility tolerance (default: 5e-12)
        reduced_tol_infeas_rel: Reduced relative infeasibility tolerance (default: 5e-5)
        reduced_tol_ktratio: Reduced KT ratio tolerance (default: 1e-4)

        Warm start retry control:
        warm_start_no_retry: Set of SolverStatus values that do NOT trigger a cold
            retry when warm starting. Default (None) uses {Solved, AlmostSolved,
            MaxIterations, CallbackTerminated}. All other statuses trigger an
            automatic cold retry with a warning.

    Example:
        >>> ipm = IPMSettings(tol_gap_abs=1e-6, tol_feas=1e-6)
        >>> settings = Settings(ipm_settings=ipm, device='cuda')
    """
    model_config = ConfigDict(validate_assignment=True)

                            
    tol_gap_abs: Annotated[float, Field(gt=0)] = 1e-8
    tol_gap_rel: Annotated[float, Field(gt=0)] = 1e-8
    tol_feas: Annotated[float, Field(gt=0)] = 1e-8
    tol_infeas_abs: Annotated[float, Field(gt=0)] = 1e-8
    tol_infeas_rel: Annotated[float, Field(gt=0)] = 1e-8
    tol_ktratio: Annotated[float, Field(gt=0)] = 1e-6

                       
    max_step_fraction: Annotated[float, Field(gt=0, le=1)] = 0.99
    equilibrate_enable: bool = True
    direct_solve_method: str = 'auto'

                                                                           
    cudss_ir_steps: Annotated[int, Field(ge=0)] = 2
    cudss_pivot_enable: bool = False

                                                  
    reduced_tol_gap_abs: Annotated[float, Field(gt=0)] = 5e-5
    reduced_tol_gap_rel: Annotated[float, Field(gt=0)] = 5e-5
    reduced_tol_feas: Annotated[float, Field(gt=0)] = 1e-4
    reduced_tol_infeas_abs: Annotated[float, Field(gt=0)] = 5e-12
    reduced_tol_infeas_rel: Annotated[float, Field(gt=0)] = 5e-5
    reduced_tol_ktratio: Annotated[float, Field(gt=0)] = 1e-4

                            
    diff_method: str = 'auto'
    diff_smoothing_mu: Annotated[float, Field(gt=0)] = 1e-4
    diff_smoothing_step_factor: Annotated[float, Field(gt=1)] = 30.0

                                                                          
                                                                         
                                                                                    
    warm_start_no_retry: Optional[FrozenSet[SolverStatus]] = None

    @field_validator('direct_solve_method')
    @classmethod
    def validate_direct_solve_method(cls, v: str) -> str:
        """Validate KKT solver method."""
        valid = {'auto', 'qdldl', 'faer-1t', 'faer-nt', 'faer', 'cudss', 'riccati', 'woodbury'}
        if v not in valid:
            raise ValueError(
                f"direct_solve_method must be one of {valid}, got '{v}'"
            )
        return v

    @field_validator('diff_method')
    @classmethod
    def validate_diff_method(cls, v: str) -> str:
        """Validate differentiation method."""
        valid = {'auto', 'smoothed', 'exact'}
        if v not in valid:
            raise ValueError(
                f"diff_method must be one of {valid}, got '{v}'"
            )
        return v


class ActiveSetSettings(BaseModel):
    """Active-set solver specific settings.

    These settings control the dual active-set QP solver.
    Only used when solver='active_set'. Supports differentiation
    (enable_grad=True) and warm starting. CPU-only. Zero + nonneg cones only.

    Attributes:
        primal_tol: Primal feasibility tolerance (default: 1e-6)
        dual_tol: Dual feasibility tolerance (default: 1e-12)
        zero_tol: Zero tolerance for numerical checks (default: 1e-11)
        pivot_tol: Pivot tolerance for LDL factorization (default: 1e-6)
        progress_tol: Progress tolerance for cycle detection (default: 1e-14)
        fval_bound: Objective bound for infeasibility detection (default: 1e30)
        iter_limit: Maximum iterations (default: 10000)
        cycle_tol: Cycle detection tolerance (default: 10)
        diff_method: Differentiation method - 'exact' (default) or 'smoothed'.
            'smoothed' uses barrier-based smoothing (h_i = z_i²/(z_i² + μ)) to
            produce C^∞ gradients through active-set transitions.
        diff_smoothing_mu: Smoothing parameter μ for 'smoothed' mode (default: 1e-4).
            Larger values produce smoother gradients at the cost of accuracy.
    """
    model_config = ConfigDict(validate_assignment=True)

    primal_tol: float = 1e-6
    dual_tol: float = 1e-12
    zero_tol: float = 1e-11
    pivot_tol: float = 1e-6
    progress_tol: float = 1e-14
    fval_bound: float = 1e30
    iter_limit: Annotated[int, Field(ge=1)] = 10000
    cycle_tol: Annotated[int, Field(ge=1)] = 10
    diff_method: Literal['exact', 'smoothed'] = 'exact'
    diff_smoothing_mu: Annotated[float, Field(gt=0)] = 1e-4


class Settings(BaseModel):
    """Solver settings for CPU and CUDA backends.

    The Settings class provides a unified interface for configuring solver behavior.
    It uses a two-level structure:
    - Top-level settings control device, batching, and algorithm-agnostic options
    - Solver-specific settings (e.g., IPMSettings) control tolerances and algorithm details

    Attributes:
        solver: Solver algorithm - 'ipm' (default) or 'active_set'.
                'active_set' uses dual active-set method (CPU-only, zero+nonneg cones only).
        device: Device selection - 'auto' (default), 'cuda', or 'cpu'
        batch_size: Number of problems in batch for CompiledSolver (default: 1)
        enable_grad: If True, pre-compute gradient structures for backward pass.
                     Required for backward() to work.
        auto_tune: If True, benchmark solver configurations on first solve() when
                   device='auto' or direct_solve_method='auto'. If False (default),
                   use heuristic selection without benchmarking.
        max_iter: Maximum iterations (default: 200)
        time_limit: Time limit in seconds (default: infinity)
        verbose: Enable verbose output (default: False)
        ipm_settings: IPM-specific settings including tolerances (auto-created if None)

    Example:
        >>> # Simple usage with defaults
        >>> settings = Settings(device='cuda', verbose=True)
        >>>
        >>> # With custom tolerances
        >>> ipm = IPMSettings(tol_gap_abs=1e-6, tol_feas=1e-6)
        >>> settings = Settings(ipm_settings=ipm, device='cuda')
    """
    model_config = ConfigDict(validate_assignment=True)

                      
    solver: Union[SolverType, str] = SolverType.AUTO

                                  
    device: str = 'auto'
    device_id: int = -1                                            
    batch_size: Annotated[int, Field(ge=1)] = 1
    enable_grad: bool = False
    auto_tune: bool = False
    yolo: bool = False
    yolo_num_iters: Annotated[int, Field(ge=1)] = 15

                   
    max_iter: Annotated[int, Field(ge=1)] = 200
    time_limit: Annotated[float, Field(gt=0)] = float('inf')
    verbose: bool = False

                                                       
    ipm_settings: Optional[IPMSettings] = None
    active_set_settings: Optional[ActiveSetSettings] = None

    @field_validator('solver', mode='before')
    @classmethod
    def normalize_solver(cls, v):
        """Normalize solver to SolverType enum."""
        if isinstance(v, str):
            return SolverType(v.lower())
        return v

    @field_validator('device')
    @classmethod
    def validate_device(cls, v: str) -> str:
        """Validate device selection."""
        valid = {'auto', 'cpu', 'cuda'}
        if v not in valid:
            raise ValueError(
                f"device must be one of {valid}, got '{v}'"
            )
        return v

    @model_validator(mode='after')
    def create_default_ipm_settings(self):
        """Create default IPM settings if needed."""
        if self.ipm_settings is None and self.solver in (SolverType.IPM, SolverType.AUTO):
            self.ipm_settings = IPMSettings()
        return self

    @model_validator(mode='after')
    def validate_yolo(self):
        """Validate YOLO mode settings."""
        if self.yolo:
            if self.enable_grad:
                raise ValueError(
                    "yolo=True is incompatible with enable_grad=True "
                    "(backward pass needs convergence data)"
                )
            object.__setattr__(self, 'verbose', False)
        return self

    def to_device_settings(self, device: str):
        """Convert to device-specific settings.

        Args:
            device: Device name (e.g., 'cuda')

        Returns:
            The native settings type for the specified device.

        Raises:
            ImportError: If the device backend is not available.
        """
        from moreau._backend import get_device_component, device_available
        if not device_available(device):
            raise ImportError(f"Device '{device}' not available.")

        settings_converter = get_device_component(device, 'settings_converter')
        if settings_converter is None:
            raise ImportError(
                f"Device '{device}' has no settings_converter registered."
            )
        return settings_converter(self)


def normalize_status(status) -> SolverStatus:
    """Convert backend status to unified SolverStatus IntEnum.

    Handles numpy arrays, lists, backend enums, and raw integers.
    Returns scalar SolverStatus for scalar input, list for array input.
    """
    import numpy as np

    if isinstance(status, SolverStatus):
        return status
    if isinstance(status, np.integer):
        return SolverStatus(int(status))
    if isinstance(status, np.ndarray):
        return [SolverStatus(int(s)) for s in status]
    if isinstance(status, list):
        return [SolverStatus(int(s)) for s in status]
    if hasattr(status, '__iter__') and not isinstance(status, (int, str)):
        return [SolverStatus(int(s)) for s in status]
    return SolverStatus(int(status))


@dataclass
class WarmStart:
    """Warm start point for a single conic optimization problem.

    Contains primal, dual, and slack variables from a previous solve
    that can be used to accelerate convergence on a related problem.

    Attributes:
        x: Primal variables, shape (n,)
        z: Dual variables, shape (m,)
        s: Slack variables, shape (m,)
    """
    x: 'np.ndarray'
    z: 'np.ndarray'
    s: 'np.ndarray'

    def __repr__(self) -> str:
        n = len(self.x) if hasattr(self.x, '__len__') else 0
        return f"WarmStart(n={n})"


@dataclass
class BatchedWarmStart:
    """Warm start point for batched conic optimization problems.

    Contains primal, dual, and slack variables from a previous batched solve
    that can be used to accelerate convergence on related problems.

    Attributes:
        x: Primal variables, shape (batch_size, n)
        z: Dual variables, shape (batch_size, m)
        s: Slack variables, shape (batch_size, m)
    """
    x: 'np.ndarray'
    z: 'np.ndarray'
    s: 'np.ndarray'

    def __repr__(self) -> str:
        batch_size = self.x.shape[0] if hasattr(self.x, 'shape') else len(self.x)
        return f"BatchedWarmStart(batch_size={batch_size})"

    def __len__(self) -> int:
        return self.x.shape[0] if hasattr(self.x, 'shape') else len(self.x)

    def __getitem__(self, idx: int) -> WarmStart:
        if idx < 0:
            idx = len(self) + idx
        if idx < 0 or idx >= len(self):
            raise IndexError(f"Index {idx} out of range for batch size {len(self)}")
        return WarmStart(x=self.x[idx], z=self.z[idx], s=self.s[idx])

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]


@dataclass
class SolveInfo:
    """Solver metadata from a solve operation.

    Contains solver status, objective value, iteration count, and timing info.

    Attributes:
        status: Solver status (SolverStatus enum)
        obj_val: Objective value at solution
        iterations: Number of iterations taken
        solve_time: Time spent in IPM iterations (seconds)
        setup_time: Time spent setting matrix values (seconds)
        construction_time: Time spent constructing solver structure (seconds)

    Example:
        >>> solution = solver.solve(q, b)
        >>> print(solver.info.status)
        >>> print(info.status)
        >>> print(f"Solved in {info.iterations} iterations, {info.solve_time:.3f}s")
    """
    status: SolverStatus
    obj_val: float
    iterations: int
    solve_time: float
    setup_time: float = 0.0
    construction_time: float = 0.0

    def __repr__(self) -> str:
        return (
            f"SolveInfo(status={self.status.name}, "
            f"obj_val={self.obj_val:.6g}, "
            f"iterations={self.iterations})"
        )


@dataclass
class Solution:
    """Solution vectors for a single conic optimization problem.

    Contains only the optimization variables (primal and dual solutions).
    Returned as the first element of the (Solution, SolveInfo) tuple from solve().

    Attributes:
        x: Primal solution vector, shape (n,)
        z: Dual variable (Lagrange multipliers), shape (m,)
        s: Slack variable, shape (m,)

    Example:
        >>> solution = solver.solve(q, b)
        >>> print(solver.info.status)
        >>> print(solution.x)  # Access primal solution
        >>> print(info.status)  # Check solver status
    """
    x: 'np.ndarray'
    z: 'np.ndarray'
    s: 'np.ndarray'

    def __repr__(self) -> str:
        n = len(self.x) if hasattr(self.x, '__len__') else 0
        return f"Solution(n={n})"

    def to_warm_start(self) -> WarmStart:
        """Create a WarmStart from this solution."""
        return WarmStart(x=self.x.copy(), z=self.z.copy(), s=self.s.copy())


@dataclass
class BatchedSolveInfo:
    """Solver metadata from a batched solve operation.

    Contains per-problem status and objective values, plus shared timing info.

    Attributes:
        status: List of solver statuses, one per problem
        obj_val: Objective values, shape (batch_size,)
        iterations: Iterations taken (typically same for all in batch)
        solve_time: Time spent in IPM iterations (seconds)
        setup_time: Time spent setting matrix values (seconds)
        construction_time: Time spent constructing solver structure (seconds)

    Example:
        >>> solution = solver.solve(q_batch, b_batch)
        >>> print(solver.info.status[0])  # Check first problem's status
        >>> print(f"Batch solved in {info.solve_time:.3f}s")
    """
    status: List[SolverStatus]
    obj_val: List[float]
    iterations: List[int]
    solve_time: float
    setup_time: float = 0.0
    construction_time: float = 0.0

    def __repr__(self) -> str:
        batch_size = len(self.status)
        return (
            f"BatchedSolveInfo(batch_size={batch_size}, "
            f"iterations={self.iterations}, solve_time={self.solve_time:.6f}s)"
        )


@dataclass
class BatchedSolution:
    """Solution vectors for batched conic optimization problems.

    Contains only the optimization variables (primal and dual solutions).
    Returned on calls to CompiledSolver's solve method.

    Attributes:
        x: Primal solutions, shape (batch_size, n)
        z: Dual variables, shape (batch_size, m)
        s: Slack variables, shape (batch_size, m)

    Example:
        >>> solution = solver.solve(q_batch, b_batch)
        >>> print(solution.x.shape)  # (batch_size, n)
        >>> sol = solution[1]  # Get Solution for 2nd problem
        >>> print(sol.x)  # 1D array for that problem
    """
    x: 'np.ndarray'
    z: 'np.ndarray'
    s: 'np.ndarray'

    def __repr__(self) -> str:
        batch_size = self.x.shape[0] if hasattr(self.x, 'shape') else len(self.x)
        return f"BatchedSolution(batch_size={batch_size})"

    def __len__(self) -> int:
        """Return the batch size."""
        return self.x.shape[0] if hasattr(self.x, 'shape') else len(self.x)

    def __getitem__(self, idx: int) -> Solution:
        """Get Solution for a single problem in the batch.

        Args:
            idx: Index of the problem in the batch (0-based)

        Returns:
            Solution object for that problem

        Example:
            >>> solution = solver.solve(q_batch, b_batch)
            >>> sol = solution[1]  # Get 2nd problem's solution
            >>> print(sol.x)     # 1D array
        """
        if idx < 0:
            idx = len(self) + idx
        if idx < 0 or idx >= len(self):
            raise IndexError(f"Index {idx} out of range for batch size {len(self)}")

        return Solution(
            x=self.x[idx],
            z=self.z[idx],
            s=self.s[idx],
        )

    def __iter__(self):
        """Iterate over solutions in the batch."""
        for i in range(len(self)):
            yield self[i]

    def to_warm_start(self) -> BatchedWarmStart:
        """Create a BatchedWarmStart from this solution."""
        return BatchedWarmStart(x=self.x.copy(), z=self.z.copy(), s=self.s.copy())


@dataclass
class TorchSolveInfo:
    """Solver metadata from a PyTorch solve operation.

    Contains solver status, objective value, iteration count, and timing info.
    Returned as the second element of the (TorchSolution, TorchSolveInfo) tuple.

    Attributes:
        status: Solver status (SolverStatus enum)
        obj_val: Objective value tensor at solution
        iterations: Number of iterations tensor
        solve_time: Time spent in solve phase (seconds)
        setup_time: Time spent setting matrix values (seconds)
        construction_time: Time spent constructing solver structure (seconds)

    Example:
        >>> from moreau.torch import Solver
        >>> solution = solver.solve(q, b)
        >>> print(solver.info.status)
        >>> print(info.status)
        >>> print(f"Solved in {int(info.iterations)} iterations")
    """
    status: SolverStatus
    obj_val: 'torch.Tensor'
    iterations: 'torch.Tensor'
    solve_time: float
    setup_time: float = 0.0
    construction_time: float = 0.0

    def __repr__(self) -> str:
        return (
            f"TorchSolveInfo(status={self.status.name}, "
            f"obj_val={float(self.obj_val):.6g}, "
            f"iterations={int(self.iterations)})"
        )


@dataclass
class TorchSolution:
    """Solution vectors for a single PyTorch conic optimization problem.

    Contains only the optimization variables (primal and dual solutions).
    Returned as the first element of the (TorchSolution, TorchSolveInfo) tuple.

    Attributes:
        x: Primal solution tensor, shape (n,)
        z: Dual variable tensor (Lagrange multipliers), shape (m,)
        s: Slack variable tensor, shape (m,)

    Example:
        >>> from moreau.torch import Solver
        >>> solution = solver.solve(q, b)
        >>> print(solver.info.status)
        >>> print(solution.x)  # Access primal solution tensor
        >>> loss = solution.x.sum()
        >>> loss.backward()  # Gradients flow through solution
    """
    x: 'torch.Tensor'
    z: 'torch.Tensor'
    s: 'torch.Tensor'

    def __repr__(self) -> str:
        n = self.x.shape[-1] if hasattr(self.x, 'shape') else 0
        return f"TorchSolution(n={n})"

    def to_warm_start(self) -> WarmStart:
        """Create a WarmStart from this solution (detaches and moves to CPU)."""
        import numpy as np
        return WarmStart(
            x=self.x.detach().cpu().numpy().astype(np.float64),
            z=self.z.detach().cpu().numpy().astype(np.float64),
            s=self.s.detach().cpu().numpy().astype(np.float64),
        )


@dataclass
class TorchBatchedSolveInfo:
    """Solver metadata from a batched PyTorch solve operation.

    Contains per-problem status and objective values, plus shared timing info.
    Returned as the second element of the (TorchBatchedSolution, TorchBatchedSolveInfo) tuple.

    Attributes:
        status: List of solver statuses, one per problem
        obj_val: Objective values tensor, shape (batch_size,)
        iterations: Iterations tensor
        solve_time: Time spent in solve phase (seconds)
        setup_time: Time spent setting matrix values (seconds)
        construction_time: Time spent constructing solver structure (seconds)

    Example:
        >>> from moreau.torch import Solver
        >>> solution = solver.solve(q_batch, b_batch)
        >>> print(info.status[0])  # Check first problem's status
        >>> print(f"Batch solved in {info.solve_time:.3f}s")
    """
    status: List[SolverStatus]
    obj_val: 'torch.Tensor'
    iterations: 'torch.Tensor'
    solve_time: float
    setup_time: float = 0.0
    construction_time: float = 0.0

    def __repr__(self) -> str:
        batch_size = len(self.status)
                                                  
        if hasattr(self.iterations, '__len__') and len(self.iterations) > 1:
            iters_str = f"[{', '.join(str(int(i)) for i in self.iterations)}]"
        else:
            iters_str = str(int(self.iterations))
        return (
            f"TorchBatchedSolveInfo(batch_size={batch_size}, "
            f"iterations={iters_str}, solve_time={self.solve_time:.6f}s)"
        )


@dataclass
class TorchBatchedSolution:
    """Solution vectors for batched PyTorch conic optimization problems.

    Contains only the optimization variables (primal and dual solutions).
    Returned as the first element of the (TorchBatchedSolution, TorchBatchedSolveInfo) tuple.

    Attributes:
        x: Primal solutions tensor, shape (batch_size, n)
        z: Dual variables tensor, shape (batch_size, m)
        s: Slack variables tensor, shape (batch_size, m)

    Example:
        >>> from moreau.torch import Solver
        >>> solution = solver.solve(q_batch, b_batch)
        >>> print(solution.x.shape)  # (batch_size, n)
        >>> sol = solution[1]  # Get TorchSolution for 2nd problem
        >>> print(sol.x)  # 1D tensor for that problem
    """
    x: 'torch.Tensor'
    z: 'torch.Tensor'
    s: 'torch.Tensor'

    def __repr__(self) -> str:
        batch_size = self.x.shape[0] if hasattr(self.x, 'shape') else len(self.x)
        return f"TorchBatchedSolution(batch_size={batch_size})"

    def __len__(self) -> int:
        """Return the batch size."""
        return self.x.shape[0]

    def __getitem__(self, idx: int) -> TorchSolution:
        """Get TorchSolution for a single problem in the batch.

        Args:
            idx: Index of the problem in the batch (0-based)

        Returns:
            TorchSolution object for that problem

        Example:
            >>> solution = solver.solve(q_batch, b_batch)
            >>> sol = solution[1]  # Get 2nd problem's solution
            >>> print(sol.x)     # 1D tensor
        """
        if idx < 0:
            idx = len(self) + idx
        if idx < 0 or idx >= len(self):
            raise IndexError(f"Index {idx} out of range for batch size {len(self)}")

        return TorchSolution(
            x=self.x[idx],
            z=self.z[idx],
            s=self.s[idx],
        )

    def __iter__(self):
        """Iterate over solutions in the batch."""
        for i in range(len(self)):
            yield self[i]

    def to_warm_start(self) -> BatchedWarmStart:
        """Create a BatchedWarmStart from this solution (detaches and moves to CPU)."""
        import numpy as np
        return BatchedWarmStart(
            x=self.x.detach().cpu().numpy().astype(np.float64),
            z=self.z.detach().cpu().numpy().astype(np.float64),
            s=self.s.detach().cpu().numpy().astype(np.float64),
        )


                                                     
from typing import NamedTuple


class JaxSolveInfo(NamedTuple):
    """Solver metadata from a JAX solve operation.

    Uses NamedTuple for JAX pytree compatibility (jit, vmap, grad).

    Attributes:
        status: Solver status as float (SolverStatus enum value)
        obj_val: Objective value at solution
        iterations: Number of iterations taken
        solve_time: Time spent in solve phase (seconds)
        setup_time: Time spent setting matrix values (seconds)
        construction_time: Time spent constructing solver structure (seconds)
    """
    status: float                                               
    obj_val: float
    iterations: int
    solve_time: float
    setup_time: float
    construction_time: float


class JaxSolution(NamedTuple):
    """Solution vectors for a JAX conic optimization problem.

    Uses NamedTuple for JAX pytree compatibility (jit, vmap, grad).
    Contains only the optimization variables (primal and dual solutions).

    Attributes:
        x: Primal solution array
        z: Dual variable array (Lagrange multipliers)
        s: Slack variable array
    """
    x: 'jnp.ndarray'
    z: 'jnp.ndarray'
    s: 'jnp.ndarray'

    def to_warm_start(self) -> WarmStart:
        """Create a WarmStart from this solution (converts JAX arrays to numpy)."""
        import numpy as np
        return WarmStart(
            x=np.asarray(self.x, dtype=np.float64),
            z=np.asarray(self.z, dtype=np.float64),
            s=np.asarray(self.s, dtype=np.float64),
        )


@dataclass
class TuneResult:
    """Result from CompiledSolver.tune() benchmarking.

    Attributes:
        device: Winning device name (e.g. 'cuda', 'cpu'). When tune() is called
            with device='auto', this reflects the best device found across all
            available devices. When an explicit device was set, this is that device.
        method: Winning KKT solver method name (e.g. 'qdldl', 'cudss', 'faer').
        time_limit: Time limit set for future solves (seconds), computed as
            best_time * margin.
        results: Per-method benchmark data. Keys are 'device:method' strings
            (e.g. 'cuda:qdldl') when cross-device tuning, or plain method names
            when single-device. Values are dicts with 'solve_time' (float),
            'iterations' (list[int]), and 'status' (list[SolverStatus]).
    """
    device: str
    method: str
    time_limit: float
    results: Dict[str, dict] = field(default_factory=dict)

    def __repr__(self) -> str:
        methods = ', '.join(
            f"{m}: {r['solve_time']:.4f}s" for m, r in self.results.items()
        )
        return (
            f"TuneResult(device='{self.device}', method='{self.method}', "
            f"time_limit={self.time_limit:.4f}s, {{{methods}}})"
        )


__all__ = [
    'SolverType', 'SolverStatus', 'Cones', 'Settings', 'IPMSettings', 'ActiveSetSettings',
    'normalize_status',
    'WarmStart', 'BatchedWarmStart',
    'SolveInfo', 'Solution', 'BatchedSolveInfo', 'BatchedSolution',
    'TorchSolveInfo', 'TorchSolution', 'TorchBatchedSolveInfo', 'TorchBatchedSolution',
    'JaxSolveInfo', 'JaxSolution',
    'TuneResult',
]
