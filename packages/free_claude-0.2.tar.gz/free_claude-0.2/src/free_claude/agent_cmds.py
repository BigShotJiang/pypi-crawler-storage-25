"""CommandMixin — slash-command handling for Agent."""
from __future__ import annotations

import os
import sys

from . import rich_ui as ui
from .config import API_BASE, DEFAULT_SYSTEM_PROMPT, MODELS
from .mcp import discover_hfi_plugins
from .teammates import AgentTeam, TeammateRole
from .ui_components import show_search_results, show_task_monitor, show_team_status


class CommandMixin:
    """Mixin that provides /command handling for the Agent chat loop."""

    # ── Main command dispatcher ────────────────────────────────────────

    def _handle_cmd(self, cmd_line: str):
        parts = cmd_line.split()
        cmd = parts[0].lower()

        if cmd in ("/quit", "/exit"):
            ui.print_goodbye()
            self.cleanup()
            sys.exit(0)

        elif cmd in ("/clear", "/c"):
            self._ctx.clear()
            ui.print_success("Conversation cleared")

        elif cmd in ("/usage", "/u"):
            self._show_usage()

        elif cmd in ("/model", "/m"):
            if len(parts) > 1:
                requested = parts[1]
                resolved = MODELS.get(requested)
                if not resolved and requested in MODELS.values():
                    resolved = requested
                if resolved:
                    self.model = resolved
                    ui.set_current_model(self.model)
                    if hasattr(self, "_team") and self._team:
                        self._team.set_runtime(model=self.model)
                    ui.print_success(f"Model switched to: {self.model}")
                    ui.print_info("Use /model anytime to list choices again.")
                else:
                    ui.print_warning(f"Unknown model '{requested}'")
                    ui.console.print(f"[dim]Try one of:[/dim] [cyan]{', '.join(MODELS.keys())}[/cyan]")
                    ui.console.print("[dim]You can also paste the full model name, e.g.:[/dim] [cyan]model claude-opus-4-6[/cyan]")
            else:
                ui.print_models_table(MODELS, self.model)

        elif cmd in ("/tools", "/t"):
            ui.print_tools_table(self.tools)

        elif cmd == "/plugins":
            ui.print_plugins_table(discover_hfi_plugins())

        elif cmd == "/plugin":
            self._load_plugin(parts)

        elif cmd == "/mcp":
            self._add_mcp(parts)

        elif cmd in ("/search", "/find"):
            self._cmd_search(cmd_line, parts)

        elif cmd == "/index":
            self._cmd_index(cmd_line)

        elif cmd == "/teammate":
            self._cmd_teammate(cmd_line, parts)

        elif cmd == "/tasks":
            self._cmd_tasks(parts)

        elif cmd == "/task":
            self._cmd_task(parts)

        elif cmd == "/cd":
            if len(parts) > 1:
                try:
                    os.chdir(os.path.expanduser(parts[1]))
                    ui.print_success(f"Directory: {os.getcwd()}")
                except Exception as e:
                    ui.print_error(str(e))

        elif cmd == "/system":
            self.system = cmd_line[8:].strip() or DEFAULT_SYSTEM_PROMPT
            ui.print_success("System prompt updated")

        elif cmd == "/config":
            self._show_config()

        elif cmd in ("/save", "/s"):
            self._cmd_save(parts)

        elif cmd in ("/resume", "/r"):
            self._cmd_resume(parts)

        elif cmd == "/sessions":
            self._cmd_sessions()

        elif cmd in ("/memory", "/mem"):
            self._cmd_memory(cmd_line, parts)

        elif cmd == "/plan":
            self._cmd_plan(cmd_line, parts)

        elif cmd in ("/think", "/thinking"):
            self._cmd_think(parts)

        elif cmd == "/adaptive":
            self._cmd_adaptive(parts)

        elif cmd in ("/autoplan", "/ap"):
            self._cmd_autoplan(cmd_line)

        elif cmd in ("/help", "/?"):
            self._show_help()

        elif cmd in ("/magicdoc", "/memory-doc", "/md"):
            self._cmd_magic_doc(parts)

        elif cmd in ("/permissions", "/perms"):
            self._cmd_permissions(parts)

        elif cmd in ("/hooks",):
            self._cmd_hooks(parts)

        elif cmd in ("/fileindex", "/fi"):
            self._cmd_file_index()

        elif cmd in ("/paste", "/p"):
            self._cmd_paste()

        else:
            ui.print_warning(f"Unknown command '{cmd}'. Type /help.")

    # ── Search / index ─────────────────────────────────────────────────

    def _cmd_search(self, cmd_line: str, parts: list):
        if len(parts) < 2:
            ui.print_info("Usage: /search <query> [--glob pattern]")
            return
        from .search import ProjectIndexer
        query = " ".join(parts[1:]).split("--glob")[0].strip()
        file_pattern = None
        if "--glob" in cmd_line:
            file_pattern = cmd_line.split("--glob")[1].strip().split()[0]
        indexer = ProjectIndexer(os.getcwd())
        results = indexer.search(query, file_pattern)
        if results:
            ui.console.print(f"[cyan]Found {len(results)} matches[/cyan]")
            show_search_results(ui.console, [
                {"file_path": r.file_path, "line_num": r.line_num,
                 "matched_text": r.matched_text}
                for r in results
            ])
        else:
            ui.print_info("No matches found")

    def _cmd_index(self, cmd_line: str):
        from .search import ProjectIndexer
        force = "--force" in cmd_line
        indexer = ProjectIndexer(os.getcwd())
        ui.console.print("[cyan]Indexing project...[/cyan]")
        stats = indexer.index_project(force=force)
        ui.console.print(f"[green]✓ Indexed {stats['files_indexed']} files[/green]")
        if stats["errors"]:
            ui.print_warning(f"{len(stats['errors'])} errors during indexing")

    # ── Team / tasks ───────────────────────────────────────────────────

    def _ensure_team(self) -> AgentTeam:
        if not hasattr(self, "_team") or self._team is None:
            self._team = AgentTeam(api_base=API_BASE, token=self.token, model=self.model)
        else:
            self._team.set_runtime(token=self.token, model=self.model)
        return self._team

    def _cmd_teammate(self, cmd_line: str, parts: list):
        team = self._ensure_team()
        if len(parts) < 2:
            show_team_status(ui.console, team.get_team_status())
            ui.print_info("Use /teammate roles, /teammate add <role> [name], /teammate ask <role> <question>, or /teammate delegate <role> <task>")
            return

        subcmd = parts[1]
        if subcmd == "roles":
            self._show_teammate_roles()
        elif subcmd == "add":
            if len(parts) < 3:
                ui.print_info("Usage: /teammate add <role> [name]")
                ui.print_info(f"Roles: {', '.join(r.value for r in TeammateRole)}")
                return
            try:
                role = TeammateRole(parts[2])
                name = parts[3] if len(parts) > 3 else None
                teammate = team.add_teammate(name, role)
                ui.print_success(f"Added teammate: {teammate.name} ({role.value})")
            except ValueError as e:
                ui.print_error(str(e))
        elif subcmd == "list":
            show_team_status(ui.console, team.get_team_status())
        elif subcmd == "remove":
            if len(parts) < 3:
                ui.print_info("Usage: /teammate remove <name>")
                return
            if team.remove_teammate(parts[2]):
                ui.print_success(f"Removed teammate: {parts[2]}")
            else:
                ui.print_error(f"Could not remove teammate '{parts[2]}' (not found or currently busy)")
        elif subcmd == "ask":
            if len(parts) < 4:
                ui.print_info("Usage: /teammate ask <role> <question>")
                return
            try:
                role = TeammateRole(parts[2])
            except ValueError:
                ui.print_error(f"Unknown role: {parts[2]}")
                return
            answer = team.ask_teammate(role, " ".join(parts[3:]))
            if answer is None:
                ui.print_warning(f"No teammate with role '{role.value}' yet. Add one first with /teammate add {role.value}")
                return
            ui.print_assistant_header()
            ui.render_markdown(answer)
            ui.print_response_end()
        elif subcmd == "delegate":
            if len(parts) < 4:
                ui.print_info("Usage: /teammate delegate <role> <task>")
                return
            try:
                role = TeammateRole(parts[2])
            except ValueError:
                ui.print_error(f"Unknown role: {parts[2]}")
                return
            description = " ".join(parts[3:])
            task = team.delegate_task(
                title=description[:80],
                description=description,
                role=role,
                run_async=True,
            )
            if task.assigned_to:
                ui.print_success(f"Delegated task {task.id} to {task.assigned_to}")
                ui.print_info("Check progress with /tasks active, /tasks all, or /task <id>")
            else:
                ui.print_warning(f"No teammate available for role '{role.value}' yet — task queued ({task.id})")
        else:
            ui.print_warning("Unknown teammate subcommand. Try: roles, add, list, remove, ask, delegate")

    def _cmd_tasks(self, parts: list):
        team = self._ensure_team()
        status = parts[1].lower() if len(parts) > 1 else "active"
        valid = {"active", "all", "pending", "assigned", "in_progress", "done", "failed", "blocked", "cancelled"}
        if status not in valid:
            ui.print_info("Usage: /tasks [active|all|pending|assigned|in_progress|done|failed|blocked|cancelled]")
            return
        tasks = team.list_tasks(status)
        if tasks:
            show_task_monitor(ui.console, [
                {"id": t.id, "title": t.title, "assigned_to": t.assigned_to or "unassigned",
                 "status": t.status, "priority": t.priority, "role": t.role}
                for t in tasks
            ])
            ui.print_info("Use /task <id> for full detail or /task result <id> for just the output")
        else:
            ui.print_info(f"No {status} tasks")

    def _cmd_task(self, parts: list):
        team = self._ensure_team()
        if len(parts) < 2:
            ui.print_info("Usage: /task <id> | /task result <id>")
            return
        if parts[1] == "result":
            if len(parts) < 3:
                ui.print_info("Usage: /task result <id>")
                return
            task = team.get_task(parts[2])
            if not task:
                ui.print_error(f"Task '{parts[2]}' not found")
                return
            if task.result:
                ui.console.print()
                ui.console.print(f"[bold cyan]Result for {task.id}[/bold cyan]")
                ui.render_markdown(task.result)
                ui.console.print()
            elif task.error:
                ui.print_error(task.error)
            else:
                ui.print_info(f"Task {task.id} has no result yet (status: {task.status})")
            return
        task = team.get_task(parts[1])
        if not task:
            ui.print_error(f"Task '{parts[1]}' not found")
            return
        self._show_task_detail(task)

    # ── Session management ─────────────────────────────────────────────

    def _cmd_save(self, parts: list):
        if not self._ctx.messages:
            ui.print_info("Nothing to save yet")
            return
        fmt = parts[1].lower() if len(parts) > 1 else "md"
        if fmt == "session":
            session = self._history.save(
                self._ctx.messages, self.model,
                session_id=self._current_session_id,
            )
            self._current_session_id = session.id
            ui.print_success(f"Session saved: {session.id}  ({session.message_count} messages)")
        elif fmt == "json":
            path = self._exporter.to_json(self._ctx.messages, model=self.model)
            ui.print_success(f"Exported JSON: {path}")
        else:
            path = self._exporter.to_markdown(self._ctx.messages, model=self.model)
            ui.print_success(f"Exported Markdown: {path}")
        self._checkpoint.save(self._ctx.messages, self.model, self.system)

    def _cmd_resume(self, parts: list):
        if len(parts) < 2:
            data = self._checkpoint.load()
            if not data:
                ui.print_info("No checkpoint found. Use /save first or provide a session ID.")
                return
            self._ctx.messages = data["messages"]
            self.model = data.get("model", self.model)
            ui.print_success(
                f"Resumed checkpoint: {data['message_count']} messages  "
                f"(saved {data['saved_at'][:16]})"
            )
        else:
            session = self._history.load(parts[1])
            if not session:
                ui.print_error(f"Session '{parts[1]}' not found. Use /sessions to list.")
                return
            self._ctx.messages = session.messages
            self._current_session_id = session.id
            self.model = session.model
            ui.print_success(
                f"Resumed session: {session.id}  "
                f"'{session.preview}'  ({session.message_count} messages)"
            )

    def _cmd_sessions(self):
        sessions = self._history.list()
        if not sessions:
            ui.print_info("No saved sessions. Use /save session to save one.")
            return
        from rich import box
        from rich.table import Table
        table = Table(box=box.ROUNDED, header_style="bold cyan",
                      border_style="dim cyan", padding=(0, 2), show_edge=True)
        table.add_column("ID", style="yellow", min_width=18, no_wrap=True)
        table.add_column("Preview", style="white", width=40)
        table.add_column("Msgs", style="cyan", justify="right")
        table.add_column("Saved", style="dim")
        for s in sessions:
            table.add_row(s.id, s.preview, str(s.message_count), s.updated_at[:16])
        ui.console.print()
        ui.console.print(table)
        ui.console.print("\n[dim]Resume with: /resume <id>[/dim]\n")

    # ── Memory ─────────────────────────────────────────────────────────

    def _cmd_memory(self, cmd_line: str, parts: list):
        if len(parts) < 2:
            entries = self._memory.all()
            if not entries:
                ui.print_info("No memories yet. Use /memory set <key> <value>")
                return
            from rich import box
            from rich.table import Table
            table = Table(box=box.ROUNDED, header_style="bold cyan",
                          border_style="dim cyan", padding=(0, 2), show_edge=True)
            table.add_column("Key", style="yellow", min_width=16)
            table.add_column("Value", style="white")
            table.add_column("Category", style="dim", justify="center")
            for e in entries:
                table.add_row(e.key, e.value[:60], e.category)
            ui.console.print()
            ui.console.print(table)
            ui.console.print()
            return

        subcmd = parts[1]
        if subcmd == "set" and len(parts) >= 4:
            key, value = parts[2], " ".join(parts[3:])
            self._memory.remember(key, value)
            ui.print_success(f"Remembered: {key} = {value}")
        elif subcmd == "get" and len(parts) >= 3:
            val = self._memory.recall(parts[2])
            if val:
                ui.console.print(f"  [yellow]{parts[2]}[/yellow]: {val}")
            else:
                ui.print_info(f"No memory for '{parts[2]}'")
        elif subcmd == "forget" and len(parts) >= 3:
            if self._memory.forget(parts[2]):
                ui.print_success(f"Forgotten: {parts[2]}")
            else:
                ui.print_info(f"Key '{parts[2]}' not found")
        elif subcmd == "clear":
            self._memory.clear()
            ui.print_success("All memories cleared")
        elif subcmd == "search" and len(parts) >= 3:
            results = self._memory.search(" ".join(parts[2:]))
            for e in results:
                ui.console.print(f"  [yellow]{e.key}[/yellow]: {e.value}")
        else:
            ui.print_info("Usage: /memory [set <key> <val> | get <key> | forget <key> | search <q> | clear]")

    # ── Planning ───────────────────────────────────────────────────────

    def _cmd_plan(self, cmd_line: str, parts: list):
        if len(parts) < 2 or parts[1] == "show":
            if self._planner.current_plan:
                ui.console.print(self._planner.current_plan.summary())
            else:
                ui.print_info("No active plan. Use /plan new <goal>")
            return

        subcmd = parts[1]
        if subcmd == "new" and len(parts) >= 3:
            goal = " ".join(parts[2:])
            self._planner.new_plan(goal)
            ui.print_success(f"New plan: {goal}")
        elif subcmd == "next":
            step = self._planner.advance()
            if step:
                ui.console.print(f"[cyan]▶ Step {step.index + 1}:[/cyan] {step.title}")
                ui.console.print(f"  {step.description}")
            else:
                ui.print_info("Plan complete or no active plan")
        elif subcmd == "done":
            self._planner.complete_step()
            if self._planner.current_plan:
                ui.console.print(self._planner.current_plan.summary())
        elif subcmd == "reset":
            self._planner.reset()
            ui.print_success("Plan reset")
        else:
            ui.print_info("Usage: /plan [new <goal> | next | done | show | reset]")

    def _cmd_think(self, parts: list):
        from .core.streaming import DEFAULT_THINKING_BUDGET
        if len(parts) >= 2:
            arg = parts[1].lower()
            if arg in ("off", "0", "disable"):
                self.thinking_budget = 0
                ui.print_success("Extended thinking disabled")
                return
            try:
                budget = int(arg)
                if budget < 1000:
                    ui.print_warning("Budget must be >= 1000 tokens. Setting to 1000.")
                    budget = 1000
                self.thinking_budget = budget
                ui.print_thinking_status(budget)
                return
            except ValueError:
                pass
        if self.thinking_budget == 0:
            from .core.streaming import DEFAULT_THINKING_BUDGET
            self.thinking_budget = DEFAULT_THINKING_BUDGET
            ui.print_thinking_status(self.thinking_budget)
            ui.print_info("Extended thinking ON. Use /think off to disable.")
        else:
            ui.print_thinking_status(self.thinking_budget)
            ui.print_info("Use '/think off' to disable or '/think <n>' to change budget.")

    def _cmd_autoplan(self, cmd_line: str):
        goal = cmd_line.split(None, 1)[1].strip() if len(cmd_line.split(None, 1)) > 1 else ""
        if not goal:
            ui.print_info("Usage: /autoplan <goal description>")
            return

        ui.print_info(f"🗺️  Planning: {goal}")
        plan_prompt = (
            f"Break down this goal into 5-10 clear, ordered steps that I can execute one by one.\n"
            f"Format each step as: N. Title — Brief description of what to do.\n\n"
            f"Goal: {goal}"
        )
        from .core.streaming import StreamingClient as SC
        streamer = SC(API_BASE, self.token, self.model, "", [])
        try:
            response, _ = streamer.call([{"role": "user", "content": plan_prompt}],
                                        max_tokens=1024)
            plan_text = " ".join(
                b.get("text", "") for b in response.get("content", [])
                if b.get("type") == "text"
            ).strip()
            if plan_text:
                plan = self._planner.parse_from_text(goal, plan_text)
                ui.print_plan(plan.summary())
                ui.print_success(f"Plan created with {len(plan.steps)} steps. Use /plan next to start.")
            else:
                ui.print_error("Could not generate plan")
        except Exception as e:
            ui.print_error(f"Planning failed: {e}")

    # ── Phase 3 commands ───────────────────────────────────────────────

    def _cmd_magic_doc(self, parts: list):
        sub = parts[1].lower() if len(parts) > 1 else "show"
        if sub == "show":
            if self._magic_doc.exists():
                content = self._magic_doc.doc_path.read_text(encoding="utf-8")
                ui.console.print(f"\n[bold cyan]Magic Doc:[/bold cyan] {self._magic_doc.show_path()}\n")
                ui.render_markdown(content)
            else:
                ui.print_info("No Magic Doc yet. Use /magicdoc init to create one.")
        elif sub == "init":
            self._magic_doc.initialize()
            ui.print_success(f"Magic Doc created: {self._magic_doc.show_path()}")
        elif sub == "update":
            if not self._ctx.messages:
                ui.print_info("No conversation to update from.")
                return
            ui.console.print("[dim]Updating Magic Doc...[/dim]")
            ok = self._magic_doc.update_after_session(
                self._ctx.messages, API_BASE, self.token
            )
            if ok:
                ui.print_success(f"Magic Doc updated: {self._magic_doc.show_path()}")
            else:
                ui.print_warning("Magic Doc update skipped (too few messages or API error)")
        elif sub == "path":
            ui.print_info(f"Magic Doc path: {self._magic_doc.show_path()}")
        else:
            ui.print_info("Usage: /magicdoc [show|init|update|path]")

    def _cmd_permissions(self, parts: list):
        if len(parts) > 1 and parts[1] == "allow":
            if len(parts) > 2:
                self._permissions.add_session_allow(parts[2])
                ui.print_success(f"Tool '{parts[2]}' always allowed this session")
            else:
                ui.print_info("Usage: /perms allow <tool_name>")
        else:
            ui.console.print("\n[bold cyan]Permission Summary[/bold cyan]")
            ui.console.print(self._permissions.summary())
            ui.console.print("[dim]Use /perms allow <tool> to skip confirmation for a tool.[/dim]\n")

    def _cmd_adaptive(self, parts: list):
        sub = parts[1].lower() if len(parts) > 1 else "status"

        if sub in ("on", "enable", "bật"):
            self._adaptive.enable()
            ui.set_adaptive_status(True)
            ui.print_success("🧠 Adaptive thinking ENABLED — budget auto-selected per query")
            ui.console.print(
                "[dim]  trivial/simple → no thinking\n"
                "  medium  → 4,000 tokens\n"
                "  complex → 10,000 tokens\n"
                "  expert  → 16,000 tokens[/dim]"
            )
        elif sub in ("off", "disable", "tắt"):
            self._adaptive.disable()
            ui.set_adaptive_status(False)
            ui.print_success("Adaptive thinking DISABLED")
        elif sub in ("status", "info"):
            stats = self._adaptive.stats()
            ui.console.print("\n[bold cyan]Adaptive Thinking[/bold cyan]")
            ui.console.print(f"  Enabled:         {'✓ Yes' if stats['enabled'] else '✗ No'}")
            ui.console.print(f"  Classifications: {stats['classifications']}")
            ui.console.print(f"  API classifier:  {stats['api_calls']} calls")
            ui.console.print(f"  Avg budget:      {stats['avg_budget']:,} tokens")
            ui.console.print(f"  Total budget:    {stats['total_budget']:,} tokens\n")
        elif sub == "test":
            query = " ".join(parts[2:]) if len(parts) > 2 else "refactor auth module"
            result = self._adaptive.classify(query, len(self._ctx.messages))
            ui.console.print(f"\n[bold cyan]Classification for:[/bold cyan] [yellow]{query}[/yellow]")
            ui.console.print(f"  Complexity:  [bold]{result.complexity.value.upper()}[/bold]")
            ui.console.print(f"  Budget:      [bold]{result.budget:,}[/bold] tokens")
            ui.console.print(f"  Confidence:  {result.confidence:.0%}")
            ui.console.print(f"  Reason:      [dim]{result.reason}[/dim]")
            ui.console.print(f"  Duration:    {result.duration_ms:.1f}ms\n")
        else:
            ui.print_info("Usage: /adaptive [on|off|status|test <query>]")

    def _cmd_hooks(self, parts: list):
        ui.console.print("\n[bold cyan]Hook System[/bold cyan]")
        ui.console.print(f"  Pre-hooks:  {sum(len(v) for v in self._hooks._pre.values())} registered")
        ui.console.print(f"  Post-hooks: {sum(len(v) for v in self._hooks._post.values())} registered")
        ui.console.print(f"  Total runs: {self._hooks.hook_count}")
        ui.console.print(f"  Total time: {self._hooks.hook_total_ms:.1f}ms\n")

    def _cmd_file_index(self):
        stats = self._git_index.stats()
        ui.console.print("\n[bold cyan]File Index[/bold cyan]")
        ui.console.print(f"  Ready:     {'✓' if stats['ready'] else '⏳ building...'}")
        ui.console.print(f"  Root:      {stats['root']}")
        ui.console.print(f"  Tracked:   {stats['tracked']} files")
        ui.console.print(f"  Untracked: {stats['untracked']} files")
        ui.console.print(f"  Total:     {stats['total']} files\n")

    def _cmd_paste(self):
        """Enter paste mode: collect multi-line input until a line with only '.' or Ctrl+D."""
        ui.console.print(
            "[dim cyan]Paste mode — paste your text below.[/dim cyan]\n"
            "[dim]End with a line containing only [bold].[/bold] (dot) or press Ctrl+D.[/dim]"
        )
        lines = []
        try:
            while True:
                try:
                    line = input()
                except EOFError:
                    break
                if line == ".":
                    break
                lines.append(line)
        except KeyboardInterrupt:
            ui.console.print("\n[yellow]Paste cancelled.[/yellow]")
            return

        if not lines:
            ui.print_info("No input received.")
            return

        user_input = "\n".join(lines)
        ui.console.print(f"[dim]→ Sending {len(lines)} line(s)...[/dim]")
        try:
            self.run(user_input, stream=True)
        except KeyboardInterrupt:
            ui.print_interrupted()
            self._ctx.pop_last()
