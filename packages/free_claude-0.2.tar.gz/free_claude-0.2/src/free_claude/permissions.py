"""Tool permission system for fclaude.

Inspired by Claude-HFI's alwaysAllowRules / toolPermissionContext pattern.
Provides per-tool allow/confirm/block decisions with session-level overrides.

Usage:
    mgr = ToolPermissionManager()
    decision = mgr.check("bash", {"command": "ls -la"})
    if decision == "confirm":
        ok = mgr.ask_user("bash", {"command": "ls -la"}, "List files")
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Set

log = logging.getLogger(__name__)

Decision = str   # "allow" | "confirm" | "block"


# ─────────────────────────────────────────────────────────────────────────────
# Safe-pattern definitions (mirroring HFI's alwaysAllowRules)
# ─────────────────────────────────────────────────────────────────────────────

# Bash commands that are always safe (read-only / informational)
_BASH_SAFE_PATTERNS: List[str] = [
    r"^(ls|ll|la|l)\b",
    r"^cat\b",
    r"^echo\b",
    r"^pwd\b",
    r"^which\b",
    r"^type\b",
    r"^env\b",
    r"^printenv\b",
    r"^whoami\b",
    r"^date\b",
    r"^uname\b",
    r"^df\b",
    r"^du\b",
    r"^free\b",
    r"^top\b",
    r"^ps\b",
    r"^find\b.*(?:-name|-type|-size|-mtime|-newer)\b",
    r"^grep\b",
    r"^rg\b",
    r"^ag\b",
    r"^wc\b",
    r"^head\b",
    r"^tail\b",
    r"^sort\b",
    r"^uniq\b",
    r"^awk\b",
    r"^sed\b",
    r"^cut\b",
    r"^tr\b",
    r"^diff\b",
    r"^file\b",
    r"^stat\b",
    r"^lsof\b",
    r"^python3?\s+-c\b",
    r"^python3?\s+-m\s+(pytest|unittest|mypy|pylint|flake8|black|isort)\b",
    r"^pip3?\s+show\b",
    r"^pip3?\s+list\b",
    r"^pip3?\s+freeze\b",
    r"^npm\s+(list|ls|show|info|view)\b",
    r"^node\s+-e\b",
    r"^git\s+(status|log|diff|branch|show|stash list|remote|fetch|tag)\b",
    r"^git\s+log\b",
    r"^git\s+diff\b",
    r"^make\s+-n\b",   # dry-run make
    r"^cargo\s+(check|clippy|test|doc)\b",
    r"^go\s+(vet|test|build)\b",
    r"^rustfmt\b",
    r"^black\b",
    r"^isort\b",
    r"^mypy\b",
    r"^pyright\b",
    r"^pylint\b",
    r"^flake8\b",
    r"^ruff\b",
    r"^bun\s+(run|test|check)\b",
    r"^bunx\b",
]

# Bash patterns that need explicit confirmation
_BASH_CONFIRM_PATTERNS: List[str] = [
    r"\brm\b",          # any rm
    r"\bmv\b",          # move (potentially destructive)
    r"\bsudo\b",        # privilege escalation
    r"\bchmod\b",
    r"\bchown\b",
    r"\bcurl\b",        # network
    r"\bwget\b",
    r"\bnpm\s+install\b",
    r"\bpip\s+install\b",
    r"\bapt\b",
    r"\byum\b",
    r"\bbrew\s+install\b",
    r"\bgit\s+(commit|push|reset|rebase|merge|checkout\s+-b)\b",
    r"\bdocker\b",
    r"\bkubectl\b",
    r"\bssh\b",
    r"\bscp\b",
    r"\brsync\b",
    r">\s*[^&]",        # any redirect to file (not &>)
    r"\btee\b",
]


# ─────────────────────────────────────────────────────────────────────────────
# ToolPermissionManager
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PermissionRule:
    """A single permission rule."""
    tool: str
    decision: Decision
    pattern: Optional[str] = None   # regex for input matching (bash only)


class ToolPermissionManager:
    """Manages per-tool allow/confirm/block decisions.

    Three levels:
    1. session_always_allow  — user said "always allow" in this session
    2. safe_pattern match    — auto-allow known-safe commands
    3. confirm_pattern match — ask user (can upgrade to always_allow)
    4. default_decisions     — per-tool default (read=allow, write=confirm)
    """

    # Default decisions per tool name
    _TOOL_DEFAULTS: Dict[str, Decision] = {
        # Always safe — read-only
        "read_file":        "allow",
        "list_directory":   "allow",
        "search":           "allow",
        "grep":             "allow",
        "glob":             "allow",
        "python_eval":      "allow",
        "fetch_url":        "confirm",
        # Potentially destructive
        "write_file":       "confirm",
        "edit_file":        "confirm",
        "run_notebook":     "confirm",
        "read_document":    "allow",
        # Bash — evaluated by pattern
        "bash":             "pattern",
        # MCP tools — confirm by default
        "__mcp__":          "confirm",
    }

    def __init__(self) -> None:
        # Tools that the user has approved for the whole session
        self._session_allow: Set[str] = set()
        # Compiled regexes
        self._safe_re = [re.compile(p) for p in _BASH_SAFE_PATTERNS]
        self._confirm_re = [re.compile(p, re.IGNORECASE) for p in _BASH_CONFIRM_PATTERNS]
        # Custom rules added at runtime
        self._custom_rules: List[PermissionRule] = []

    # ── Public API ──────────────────────────────────────────────────────────

    def check(self, tool_name: str, tool_input: Dict) -> Decision:
        """Return the permission decision for a tool call.

        Args:
            tool_name:  Name of the tool (e.g., 'bash', 'write_file').
            tool_input: The tool's input dict.

        Returns:
            'allow' | 'confirm' | 'block'
        """
        # Session-level override (user said "always allow")
        if tool_name in self._session_allow:
            return "allow"

        # Custom rules take priority
        for rule in self._custom_rules:
            if rule.tool == tool_name or rule.tool == "*":
                if rule.pattern is None:
                    return rule.decision
                cmd = str(tool_input.get("command", ""))
                if re.search(rule.pattern, cmd, re.IGNORECASE):
                    return rule.decision

        # MCP tools
        if tool_name.startswith("mcp_"):
            # Auto-allow all Serena tools (they are safe read/write ops within the project)
            if tool_name.startswith("mcp_serena_"):
                return "allow"
            return "confirm"

        # Bash: pattern-based evaluation
        if tool_name == "bash":
            return self._check_bash(tool_input.get("command", ""))

        # Default per-tool decision
        return self._TOOL_DEFAULTS.get(tool_name, "confirm")

    def add_session_allow(self, tool_name: str) -> None:
        """Permanently allow a tool for the rest of this session."""
        self._session_allow.add(tool_name)
        log.info("[Permissions] Session allow added: %s", tool_name)

    def add_custom_rule(self, tool: str, decision: Decision,
                        pattern: Optional[str] = None) -> None:
        """Add a custom permission rule (inserted at highest priority)."""
        self._custom_rules.insert(0, PermissionRule(tool, decision, pattern))

    def ask_user(self, tool_name: str, tool_input: Dict,
                 description: str = "") -> bool:
        """Show an interactive permission prompt and return True if allowed.

        Prints to terminal using Rich if available, falls back to input().
        Supports: y=yes, n=no, a=always (session-level), q=block always
        """
        from . import rich_ui as ui

        cmd_preview = ""
        if tool_name == "bash":
            cmd_preview = f"  [dim]$ {str(tool_input.get('command',''))[:120]}[/dim]\n"
        elif "path" in tool_input:
            cmd_preview = f"  [dim]→ {tool_input['path']}[/dim]\n"
        elif description:
            cmd_preview = f"  [dim]{description[:120]}[/dim]\n"

        ui.console.print()
        ui.console.print(
            f"[bold yellow]⚠ Permission required:[/bold yellow] "
            f"[cyan]{tool_name}[/cyan]"
        )
        if cmd_preview:
            ui.console.print(cmd_preview, end="")
        ui.console.print(
            "[dim]  y[/dim] = yes    "
            "[dim]a[/dim] = always (this session)    "
            "[dim]n[/dim] = no"
        )

        try:
            answer = input("  Allow? [y/a/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            ui.console.print()
            return False

        if answer in ("a", "always"):
            self.add_session_allow(tool_name)
            ui.print_success(f"'{tool_name}' always allowed for this session")
            return True
        if answer in ("y", "yes"):
            return True

        ui.print_warning(f"Tool call blocked: {tool_name}")
        return False

    # ── Internal ─────────────────────────────────────────────────────────────

    def _check_bash(self, command: str) -> Decision:
        cmd = command.strip()

        # Check safe patterns first (allow immediately)
        for pat in self._safe_re:
            if pat.match(cmd):
                return "allow"

        # Check confirm patterns
        for pat in self._confirm_re:
            if pat.search(cmd):
                return "confirm"

        # Heuristic: short, no special chars → likely safe
        if len(cmd) < 40 and not any(c in cmd for c in (";", "&&", "||", "|", ">", "<", "$(")):
            return "allow"

        return "confirm"

    def summary(self) -> str:
        lines = ["=== Permission Summary ==="]
        lines.append(f"  Session always-allow: {sorted(self._session_allow) or '(none)'}")
        lines.append(f"  Custom rules: {len(self._custom_rules)}")
        return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singleton
# ─────────────────────────────────────────────────────────────────────────────

_global_perm: Optional[ToolPermissionManager] = None


def get_permissions() -> ToolPermissionManager:
    global _global_perm
    if _global_perm is None:
        _global_perm = ToolPermissionManager()
    return _global_perm


__all__ = [
    "ToolPermissionManager",
    "PermissionRule",
    "Decision",
    "get_permissions",
]
