"""Interactive UI components for rich terminal interfaces."""

import subprocess
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text


class ComponentType(str, Enum):
    """Types of interactive components."""
    FILE_SELECTOR = "file_selector"
    BRANCH_SELECTOR = "branch_selector"
    TASK_MONITOR = "task_monitor"
    SEARCH_RESULTS = "search_results"
    CODE_DIFF = "code_diff"
    TOOL_MONITOR = "tool_monitor"


@dataclass
class SelectOption:
    """Option for a selector component."""
    label: str
    value: Any
    description: str = ""


class InteractiveComponent:
    """Base class for interactive UI components."""

    def __init__(self, console: Console, title: str):
        self.console = console
        self.title = title

    def render(self):
        """Render the component."""
        raise NotImplementedError


class FileSelector(InteractiveComponent):
    """Interactive file selector."""

    def __init__(
        self,
        console: Console,
        files: List[str],
        title: str = "Select Files",
        multiselect: bool = False,
    ):
        super().__init__(console, title)
        self.files = files
        self.multiselect = multiselect
        self.selected: List[str] = []

    def render(self) -> List[str]:
        """Render file selector and return selected files."""
        if not self.files:
            self.console.print("[yellow]No files to select[/yellow]")
            return []

        table = Table(
            title=self.title,
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
        )
        table.add_column("#", style="dim", width=4)
        table.add_column("File", style="yellow", width=46)
        table.add_column("Size", style="dim", justify="right")
        table.add_column("Type", style="cyan", justify="center")

        for i, file_path in enumerate(self.files[:50]):  # Limit display
            try:
                stat = Path(file_path).stat()
                size = f"{stat.st_size / 1024:.1f}KB"
                file_type = Path(file_path).suffix or "?"
                table.add_row(str(i + 1), file_path, size, file_type)
            except Exception:
                table.add_row(str(i + 1), file_path, "-", "-")

        self.console.print(table)

        if self.multiselect:
            self.console.print("[dim]Enter file numbers separated by commas (e.g., 1,3,5), or 'all':[/dim] ", end="")
        else:
            self.console.print("[dim]Enter file number:[/dim] ", end="")

        try:
            raw = input().strip()
        except (EOFError, KeyboardInterrupt):
            return []

        if not raw:
            return []

        if self.multiselect:
            if raw.lower() == "all":
                self.selected = list(self.files[:50])
            else:
                indices = []
                for part in raw.split(","):
                    part = part.strip()
                    if part.isdigit():
                        idx = int(part) - 1
                        if 0 <= idx < len(self.files):
                            indices.append(idx)
                self.selected = [self.files[i] for i in indices]
        else:
            if raw.isdigit():
                idx = int(raw) - 1
                if 0 <= idx < len(self.files):
                    self.selected = [self.files[idx]]
        return self.selected


class BranchSelector(InteractiveComponent):
    """Interactive git branch selector."""

    def __init__(self, console: Console, repo_path: str = "."):
        super().__init__(console, "Select Branch")
        self.repo_path = repo_path
        self.branches: List[str] = self._get_branches()

    def _get_branches(self) -> List[str]:
        """Get list of git branches."""
        try:
            result = subprocess.run(
                ["git", "-C", self.repo_path, "branch", "-a"],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return [b.strip() for b in result.stdout.split("\n") if b.strip()]
        except Exception:
            pass
        return []

    def render(self) -> Optional[str]:
        """Render branch selector and return selected branch."""
        if not self.branches:
            self.console.print("[yellow]No branches found[/yellow]")
            return None

        table = Table(
            title=self.title,
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
        )
        table.add_column("#", style="dim", width=4)
        table.add_column("Branch", style="yellow")
        table.add_column("Current", style="green", justify="center")

        clean_branches = []
        for i, branch in enumerate(self.branches):
            is_current = "✓" if branch.startswith("*") else ""
            clean = branch.lstrip("* ")
            clean_branches.append(clean)
            table.add_row(str(i + 1), clean, is_current)

        self.console.print(table)
        self.console.print("[dim]Enter branch number:[/dim] ", end="")

        try:
            raw = input().strip()
        except (EOFError, KeyboardInterrupt):
            return None

        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(clean_branches):
                return clean_branches[idx]

        # Default to current branch (marked with *)
        for b in self.branches:
            if b.startswith("*"):
                return b.lstrip("* ")
        return clean_branches[0] if clean_branches else None


class SearchResults(InteractiveComponent):
    """Display search results."""

    def __init__(
        self,
        console: Console,
        results: List[Dict],
        title: str = "Search Results",
    ):
        super().__init__(console, title)
        self.results = results

    def render(self):
        """Render search results."""
        if not self.results:
            self.console.print("[yellow]No results found[/yellow]")
            return

        table = Table(
            title=self.title,
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
        )
        table.add_column("File", style="yellow", width=40)
        table.add_column("Line", style="cyan", width=8, justify="right")
        table.add_column("Match", style="white", width=60)

        for result in self.results[:100]:  # Limit display
            file_path = result.get("file_path", "")
            line_num = result.get("line_num", 0)
            matched_text = result.get("matched_text", "")[:60]
            table.add_row(file_path, str(line_num), matched_text)

        self.console.print(table)
        self.console.print(f"\n[dim]Showing {len(self.results)} results[/dim]")


class TaskMonitor(InteractiveComponent):
    """Monitor task progress of teammates."""

    def __init__(
        self,
        console: Console,
        tasks: List[Dict],
        title: str = "Task Monitor",
    ):
        super().__init__(console, title)
        self.tasks = tasks

    def render(self):
        """Render task monitor."""
        if not self.tasks:
            self.console.print("[yellow]No tasks[/yellow]")
            return

        table = Table(
            title=self.title,
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
        )
        table.add_column("ID", style="dim", width=18, no_wrap=True)
        table.add_column("Task", style="yellow", width=28)
        table.add_column("Role", style="cyan", width=18)
        table.add_column("Assigned To", style="cyan", width=18)
        table.add_column("Status", style="white", justify="center")
        table.add_column("Priority", style="magenta", justify="center")

        status_colors = {
            "pending": "yellow",
            "assigned": "cyan",
            "in_progress": "blue",
            "done": "green",
            "blocked": "red",
            "failed": "bold red",
            "cancelled": "dim",
        }

        for task in self.tasks[:50]:
            task_id = task.get("id", "-")[:18]
            title = task.get("title", "")[:25]
            role = task.get("role", "-")[:18]
            assigned = task.get("assigned_to", "-")[:18]
            status = task.get("status", "unknown")
            priority = "★" * task.get("priority", 1)

            status_text = Text(status, style=status_colors.get(status, "white"))
            table.add_row(task_id, title, role, assigned, status_text, priority)

        self.console.print(table)


class TeammateStatus(InteractiveComponent):
    """Display teammate status."""

    def __init__(
        self,
        console: Console,
        teammates: Dict[str, Dict],
        title: str = "Team Status",
    ):
        super().__init__(console, title)
        self.teammates = teammates

    def render(self):
        """Render teammate status."""
        if not self.teammates:
            self.console.print("[yellow]No teammates[/yellow]")
            return

        table = Table(
            title=self.title,
            box=box.ROUNDED,
            header_style="bold cyan",
            border_style="dim cyan",
            padding=(0, 2),
        )
        table.add_column("Name", style="yellow", width=20)
        table.add_column("Role", style="cyan", width=20)
        table.add_column("Status", style="white", justify="center")
        table.add_column("Active", style="magenta", justify="center")
        table.add_column("Done", style="green", justify="center")

        status_colors = {
            "idle": "green",
            "thinking": "yellow",
            "working": "blue",
            "blocked": "red",
            "done": "green",
        }

        for name, info in self.teammates.items():
            role = info.get("role", "").replace("_", " ").title()
            status = info.get("status", "unknown")
            active = info.get("active_tasks", 0)
            completed = info.get("tasks_completed", 0)

            status_text = Text(status, style=status_colors.get(status, "white"))
            table.add_row(name, role, status_text, str(active), str(completed))

        self.console.print(table)


class CodeViewer(InteractiveComponent):
    """Display code with syntax highlighting."""

    def __init__(
        self,
        console: Console,
        code: str,
        language: str = "python",
        title: str = "Code",
        line_numbers: bool = True,
    ):
        super().__init__(console, title)
        self.code = code
        self.language = language
        self.line_numbers = line_numbers

    def render(self):
        """Render code with syntax highlighting."""
        syntax = Syntax(
            self.code,
            self.language,
            theme="monokai",
            line_numbers=self.line_numbers,
            word_wrap=False,
        )
        panel = Panel(
            syntax,
            title=self.title,
            border_style="cyan",
            expand=False,
        )
        self.console.print(panel)


class ProgressMonitor(InteractiveComponent):
    """Monitor progress of operations."""

    def __init__(self, console: Console, title: str = "Progress"):
        super().__init__(console, title)

    def render_operation(
        self,
        operation_name: str,
        total_steps: int,
        callback: Optional[Callable] = None,
    ):
        """Render progress for an operation."""
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            console=self.console,
            transient=True,
        ) as progress:
            task_id = progress.add_task(operation_name, total=total_steps)
            
            for step in range(total_steps):
                if callback:
                    callback(step)
                progress.update(task_id, advance=1)


class InteractiveConfirm(InteractiveComponent):
    """Interactive confirmation dialog."""

    def __init__(
        self,
        console: Console,
        message: str,
        options: Optional[List[str]] = None,
    ):
        super().__init__(console, "Confirm")
        self.message = message
        self.options = options or ["yes", "no"]

    def render(self) -> str:
        """Show confirmation and return choice."""
        self.console.print(f"\n[bold]{self.message}[/bold]")
        opts_display = "/".join(
            f"[bold]{o}[/bold]" if i == 0 else o
            for i, o in enumerate(self.options)
        )
        self.console.print(f"[dim]({opts_display}):[/dim] ", end="")

        try:
            raw = input().strip().lower()
        except (EOFError, KeyboardInterrupt):
            return self.options[-1]  # default to last (usually "no")

        for opt in self.options:
            if raw == opt.lower() or raw == opt[0].lower():
                return opt
        return self.options[0]  # default to first if unrecognized


# Utility functions for common operations

def show_file_selector(console: Console, files: List[str]) -> List[str]:
    """Show file selector and return selected files."""
    selector = FileSelector(console, files)
    return selector.render()


def show_branch_selector(console: Console, repo_path: str = ".") -> Optional[str]:
    """Show branch selector and return selected branch."""
    selector = BranchSelector(console, repo_path)
    return selector.render()


def show_search_results(console: Console, results: List[Dict]):
    """Display search results."""
    display = SearchResults(console, results)
    display.render()


def show_team_status(console: Console, teammates: Dict[str, Dict]):
    """Display team status."""
    display = TeammateStatus(console, teammates)
    display.render()


def show_task_monitor(console: Console, tasks: List[Dict]):
    """Display task monitor."""
    monitor = TaskMonitor(console, tasks)
    monitor.render()


def show_code(
    console: Console,
    code: str,
    language: str = "python",
    title: str = "Code",
):
    """Display code with syntax highlighting."""
    viewer = CodeViewer(console, code, language, title)
    viewer.render()


__all__ = [
    "FileSelector",
    "BranchSelector",
    "SearchResults",
    "TaskMonitor",
    "TeammateStatus",
    "CodeViewer",
    "ProgressMonitor",
    "InteractiveConfirm",
    "InteractiveComponent",
    "ComponentType",
    "SelectOption",
    # Utility functions
    "show_file_selector",
    "show_branch_selector",
    "show_search_results",
    "show_team_status",
    "show_task_monitor",
    "show_code",
]
