"""Export sessions to Markdown, JSON, or plain text."""
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from ..compat import get_default_export_dir


class SessionExporter:
    """
    Exports conversation history to various formats.

    Usage:
        exporter = SessionExporter()
        path = exporter.to_markdown(messages, "~/Desktop/chat.md")
        path = exporter.to_json(messages, "~/Desktop/chat.json")
        text = exporter.to_text(messages)
    """

    def to_markdown(self, messages: List[Dict], output_path: str = None,
                    title: str = None, model: str = "") -> Path:
        """
        Export to a Markdown file.
        If output_path is None, saves to default export directory.
        """
        if not output_path:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = get_default_export_dir() / f"free-claude-{ts}.md"

        path = Path(output_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)

        lines = []
        ts_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        doc_title = title or "Conversation Export"

        lines.append(f"# {doc_title}")
        lines.append("")
        lines.append(f"> **Exported:** {ts_str}  ")
        if model:
            lines.append(f"> **Model:** {model}  ")
        lines.append(f"> **Messages:** {len(messages)}")
        lines.append("")
        lines.append("---")
        lines.append("")

        for i, msg in enumerate(messages):
            role = msg.get("role", "?")
            content = msg.get("content", "")

            if role == "user":
                if isinstance(content, list):
                    # Tool results — skip or summarize
                    lines.append("**[Tool Results]**\n")
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "tool_result":
                            snippet = str(item.get("content", ""))[:200]
                            lines.append(f"```\n{snippet}\n```\n")
                else:
                    lines.append("## 👤 You\n")
                    lines.append(f"{content}\n")

            elif role == "assistant":
                lines.append("## 🤖 Claude\n")
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict):
                            if block.get("type") == "text":
                                lines.append(block.get("text", ""))
                            elif block.get("type") == "tool_use":
                                tool_name = block.get("name", "?")
                                tool_input = str(block.get("input", {}))[:100]
                                lines.append(f"\n*🔧 Tool: `{tool_name}` — `{tool_input}`*\n")
                else:
                    lines.append(f"{content}\n")

            lines.append("")
            if i < len(messages) - 1:
                lines.append("---\n")

        path.write_text("\n".join(lines), encoding="utf-8")
        return path

    def to_json(self, messages: List[Dict], output_path: str = None,
                model: str = "") -> Path:
        """Export raw conversation as JSON."""
        import json
        if not output_path:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = get_default_export_dir() / f"free-claude-{ts}.json"

        path = Path(output_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)

        payload = {
            "exported_at": datetime.now().isoformat(),
            "model": model,
            "message_count": len(messages),
            "messages": messages,
        }
        path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False),
            encoding="utf-8"
        )
        return path

    def to_text(self, messages: List[Dict]) -> str:
        """Return a plain text transcript."""
        lines = []
        for msg in messages:
            role = msg.get("role", "?").upper()
            content = msg.get("content", "")
            if isinstance(content, list):
                content = "[tool interaction]"
            lines.append(f"[{role}]: {content}")
            lines.append("")
        return "\n".join(lines)


__all__ = ["SessionExporter"]
