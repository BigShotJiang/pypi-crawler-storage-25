"""Checkpoint manager — quick save/resume of the current session."""
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from ..compat import CONFIG_DIR

_log = logging.getLogger(__name__)


_CHECKPOINT_FILE = CONFIG_DIR / "checkpoint.json"


class CheckpointManager:
    """
    Lightweight single-file checkpoint for the current session.
    Enables /save and /resume without managing session IDs.

    Unlike SessionHistory (which archives multiple named sessions),
    this always writes to the same file — the "last state".

    Usage:
        cp = CheckpointManager()
        cp.save(messages, model="claude-opus-4-6")
        data = cp.load()   # → {"messages": [...], "model": "...", "saved_at": "..."}
        cp.clear()
    """

    def __init__(self, path: Path = None):
        self._path = Path(path) if path else _CHECKPOINT_FILE

    def save(self, messages: List[Dict], model: str, system: str = "") -> bool:
        """Save current state to checkpoint file."""
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "messages": messages,
                "model": model,
                "system": system,
                "saved_at": datetime.now().isoformat(),
                "message_count": len(messages),
            }
            self._path.write_text(
                json.dumps(payload, indent=2, ensure_ascii=False),
                encoding="utf-8"
            )
            return True
        except PermissionError as e:
            _log.error("Permission denied writing checkpoint to %s: %s", self._path, e)
            return False
        except Exception as e:
            _log.error("Failed to save checkpoint: %s", e)
            return False

    def load(self) -> Optional[Dict]:
        """Load checkpoint. Returns None if no checkpoint exists."""
        if not self._path.exists():
            return None
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            _log.warning("Checkpoint file is corrupted, ignoring: %s", e)
            return None
        except Exception as e:
            _log.error("Failed to load checkpoint from %s: %s", self._path, e)
            return None

    def exists(self) -> bool:
        return self._path.exists()

    def clear(self) -> bool:
        """Delete the checkpoint file."""
        if self._path.exists():
            self._path.unlink()
            return True
        return False

    def info(self) -> Optional[Dict]:
        """Return metadata about the checkpoint (no messages)."""
        data = self.load()
        if not data:
            return None
        return {
            "model": data.get("model"),
            "saved_at": data.get("saved_at"),
            "message_count": data.get("message_count", 0),
        }


__all__ = ["CheckpointManager"]
