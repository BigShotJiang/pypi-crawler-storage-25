"""Performance optimizations for free-claude agent.

Implements:
1. FileCache      - SQLite-backed content cache (hash-invalidated)
2. OptimizedFileReader - mmap + cached file reading
3. BatchFileProcessor  - Parallel batch processing (64 files / 8 workers)
4. PerformanceLogger   - Buffered, structured metrics logging
"""
from __future__ import annotations

import hashlib
import json
import logging
import mmap
import os
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────
BATCH_SIZE = 64          # optimal I/O batch (from Claude-HFI research)
MAX_WORKERS = 8          # thread pool size
CACHE_DIR_NAME = ".free-claude/cache"
MAX_MMAP_SIZE = 50 * 1024 * 1024   # 50 MB — above this skip mmap


# ─────────────────────────────────────────────────────────────
# 1. FileCache  (SQLite, hash-invalidated)
# ─────────────────────────────────────────────────────────────
class FileCache:
    """Persistent SQLite cache for file content / parsed objects.

    Uses file hash as cache key → auto-invalidates when file changes.
    Thread-safe via per-connection isolation (check_same_thread=False).
    """

    def __init__(self, cache_dir: Optional[str] = None) -> None:
        if cache_dir is None:
            cache_dir = os.path.join(os.getcwd(), CACHE_DIR_NAME)
        os.makedirs(cache_dir, exist_ok=True)
        self.db_path = os.path.join(cache_dir, "file_cache.db")
        self._conn = sqlite3.connect(
            self.db_path, check_same_thread=False, isolation_level=None
        )
        self._init_db()
        self._hits = 0
        self._misses = 0

    def _init_db(self) -> None:
        self._conn.executescript("""
            PRAGMA journal_mode=WAL;
            PRAGMA synchronous=NORMAL;
            CREATE TABLE IF NOT EXISTS file_cache (
                file_path TEXT NOT NULL,
                file_hash TEXT NOT NULL,
                data      TEXT NOT NULL,
                cached_at REAL NOT NULL,
                PRIMARY KEY (file_path, file_hash)
            );
            CREATE INDEX IF NOT EXISTS idx_path
                ON file_cache(file_path);
        """)

    # ── public API ──────────────────────────────────────────
    def get(self, file_path: str, file_hash: str) -> Optional[Any]:
        row = self._conn.execute(
            "SELECT data FROM file_cache WHERE file_path=? AND file_hash=?",
            (file_path, file_hash),
        ).fetchone()
        if row:
            self._hits += 1
            try:
                return json.loads(row[0])
            except Exception:
                return None
        self._misses += 1
        return None

    def set(self, file_path: str, file_hash: str, value: Any) -> None:
        # P3 FIX: use JSON instead of pickle (safer, human-readable, no RCE risk)
        data = json.dumps(value, ensure_ascii=False, default=str)
        self._conn.execute(
            "INSERT OR REPLACE INTO file_cache VALUES (?,?,?,?)",
            (file_path, file_hash, data, time.time()),
        )

    def invalidate(self, file_path: str) -> None:
        self._conn.execute(
            "DELETE FROM file_cache WHERE file_path=?", (file_path,)
        )

    def evict_old(self, max_age_days: int = 7) -> int:
        cutoff = time.time() - max_age_days * 86400
        cur = self._conn.execute(
            "DELETE FROM file_cache WHERE cached_at<?", (cutoff,)
        )
        return cur.rowcount

    @property
    def hit_rate(self) -> float:
        total = self._hits + self._misses
        return self._hits / total if total else 0.0

    def stats(self) -> Dict[str, Any]:
        total = self._hits + self._misses
        count = self._conn.execute(
            "SELECT COUNT(*) FROM file_cache"
        ).fetchone()[0]
        size_mb = Path(self.db_path).stat().st_size / 1_048_576
        return {
            "cached_entries": count,
            "cache_size_mb": round(size_mb, 2),
            "hit_rate": f"{self.hit_rate*100:.1f}%",
            "hits": self._hits,
            "misses": self._misses,
            "total_requests": total,
        }

    def close(self) -> None:
        self._conn.close()


# ─────────────────────────────────────────────────────────────
# 2. OptimizedFileReader
# ─────────────────────────────────────────────────────────────
class OptimizedFileReader:
    """Fast file reader using mmap + SQLite cache.

    Strategy:
    - Small files (< 50 MB): memory-map, zero-copy decode.
    - Huge files            : stream line-by-line.
    - All reads cached by (path, sha256[:16]).
    - start_line/end_line slicing done on mmap without extra copies.
    """

    def __init__(self, cache: Optional[FileCache] = None) -> None:
        self.cache = cache or FileCache()

    # ── helpers ──────────────────────────────────────────────
    @staticmethod
    def _hash_file(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()[:16]

    @staticmethod
    def _read_mmap(path: str,
                   start_line: Optional[int],
                   end_line: Optional[int]) -> str:
        """Zero-copy read via mmap; slice to line range if requested.

        Lines are 1-indexed (same as editors).
        start_line=5, end_line=8 → returns lines 5,6,7,8 inclusive.
        """
        with open(path, "rb") as f:
            file_size = os.fstat(f.fileno()).st_size
            if file_size == 0:
                return ""
            with mmap.mmap(f.fileno(), file_size, access=mmap.ACCESS_READ) as mm:
                if start_line is None and end_line is None:
                    return mm[:].decode("utf-8", errors="replace")

                # Convert to 0-based indices
                s_idx = (start_line - 1) if start_line and start_line > 0 else 0
                # e_idx is the last line index we want (0-based, inclusive)
                e_idx = (end_line - 1) if end_line and end_line > 0 else None

                pos = 0
                line_idx = 0       # current 0-based line index
                start_byte = 0
                end_byte = file_size

                while pos < file_size:
                    nl = mm.find(b"\n", pos)
                    at_eof = (nl == -1)
                    if at_eof:
                        nl = file_size  # treat EOF as end of last line

                    # Mark start of slice
                    if line_idx == s_idx:
                        start_byte = pos

                    # Mark end of slice (after the \n of e_idx line)
                    if e_idx is not None and line_idx == e_idx:
                        end_byte = nl if at_eof else nl + 1
                        break

                    if at_eof:
                        break

                    pos = nl + 1
                    line_idx += 1

                return mm[start_byte:end_byte].decode("utf-8", errors="replace")

    @staticmethod
    def _read_streaming(path: str,
                        start_line: Optional[int],
                        end_line: Optional[int]) -> str:
        """Fallback for very large files — stream line-by-line."""
        s = (start_line - 1) if start_line else 0
        lines: List[str] = []
        with open(path, encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                if i < s:
                    continue
                if end_line is not None and i >= end_line:
                    break
                lines.append(line)
        return "".join(lines)

    # ── public API ──────────────────────────────────────────
    def read(self,
             path: str,
             start_line: Optional[int] = None,
             end_line: Optional[int] = None,
             use_cache: bool = True) -> str:
        """Read file content, optionally slicing to a line range.

        Uses mmap for small files, streaming for large ones.
        Results are cached by file hash when use_cache=True.
        """
        path = os.path.expanduser(path)
        if not os.path.exists(path):
            return f"[ERROR] File not found: {path}"

        cache_key = f"{path}:{start_line}:{end_line}"

        # Cache lookup (whole-file reads only to keep cache compact)
        file_hash: Optional[str] = None
        if use_cache and start_line is None and end_line is None:
            try:
                file_hash = self._hash_file(path)
                cached = self.cache.get(cache_key, file_hash)
                if cached is not None:
                    return cached
            except Exception:
                pass

        # Read
        try:
            size = os.path.getsize(path)
            t0 = time.perf_counter()

            if size <= MAX_MMAP_SIZE:
                content = self._read_mmap(path, start_line, end_line)
            else:
                content = self._read_streaming(path, start_line, end_line)

            elapsed = time.perf_counter() - t0
            logger.debug("read_file %s %.1fKB in %.1fms",
                         path, size / 1024, elapsed * 1000)
        except Exception as e:
            return f"[ERROR] {e}"

        # Store in cache (whole-file only)
        if use_cache and start_line is None and end_line is None and file_hash:
            try:
                self.cache.set(cache_key, file_hash, content)
            except Exception:
                pass

        return content


# ─────────────────────────────────────────────────────────────
# 3. BatchFileProcessor
# ─────────────────────────────────────────────────────────────
@dataclass
class BatchResult:
    file: str
    result: Any = None
    error: Optional[str] = None
    duration_ms: float = 0.0


class BatchFileProcessor:
    """Process a list of files in parallel batches.

    Inspired by Claude-HFI: batch_size=64 is the empirical sweet-spot
    that balances I/O parallelism against memory and scheduling overhead.
    Errors in individual files are isolated and do not abort the batch.
    """

    def __init__(self,
                 batch_size: int = BATCH_SIZE,
                 max_workers: int = MAX_WORKERS) -> None:
        self.batch_size = batch_size
        self.max_workers = max_workers

    def process(self,
                files: List[str],
                fn: Callable[[str], Any],
                on_progress: Optional[Callable[[int, int], None]] = None
                ) -> List[BatchResult]:
        """Apply *fn* to each file in parallel batches.

        Args:
            files:       List of file paths.
            fn:          Callable(file_path) -> result
            on_progress: Optional callback(done, total).

        Returns:
            List[BatchResult] in the same order as *files*.
        """
        total = len(files)
        results: Dict[str, BatchResult] = {}

        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            for batch_start in range(0, total, self.batch_size):
                batch = files[batch_start: batch_start + self.batch_size]

                futures = {
                    pool.submit(self._run_one, fn, fp): fp
                    for fp in batch
                }
                for fut in as_completed(futures):
                    fp = futures[fut]
                    results[fp] = fut.result()

                done = min(batch_start + self.batch_size, total)
                if on_progress:
                    on_progress(done, total)
                logger.debug("BatchFileProcessor: %d/%d files processed", done, total)

        return [results.get(fp, BatchResult(file=fp, error="missing")) for fp in files]

    @staticmethod
    def _run_one(fn: Callable, file_path: str) -> BatchResult:
        t0 = time.perf_counter()
        try:
            result = fn(file_path)
            return BatchResult(
                file=file_path,
                result=result,
                duration_ms=(time.perf_counter() - t0) * 1000,
            )
        except Exception as exc:
            return BatchResult(
                file=file_path,
                error=str(exc),
                duration_ms=(time.perf_counter() - t0) * 1000,
            )


# ─────────────────────────────────────────────────────────────
# 4. PerformanceLogger
# ─────────────────────────────────────────────────────────────
@dataclass
class _LogEntry:
    ts: float
    category: str
    message: str
    data: Dict[str, Any] = field(default_factory=dict)


class PerformanceLogger:
    """Buffered structured logger with flush-on-size or flush-on-interval.

    Writes are batched (up to *max_buffer* entries or *flush_interval_s* seconds)
    to minimise disk syscalls — mirrors the pattern found in Claude-HFI.
    """

    def __init__(self,
                 log_path: Optional[str] = None,
                 flush_interval_s: float = 1.0,
                 max_buffer: int = 50) -> None:
        if log_path is None:
            log_dir = os.path.join(os.getcwd(), ".free-claude")
            os.makedirs(log_dir, exist_ok=True)
            log_path = os.path.join(log_dir, "performance.log")
        self.log_path = log_path
        self.flush_interval_s = flush_interval_s
        self.max_buffer = max_buffer
        self._buffer: List[_LogEntry] = []
        self._last_flush = time.monotonic()
        self._metrics: Dict[str, List[float]] = {}

    # ── logging ─────────────────────────────────────────────
    def log(self, category: str, message: str, **data: Any) -> None:
        entry = _LogEntry(ts=time.time(), category=category,
                          message=message, data=data)
        self._buffer.append(entry)
        if (len(self._buffer) >= self.max_buffer or
                time.monotonic() - self._last_flush >= self.flush_interval_s):
            self.flush()

    def record(self, metric: str, value: float) -> None:
        self._metrics.setdefault(metric, []).append(value)

    # ── flush ───────────────────────────────────────────────
    def flush(self) -> None:
        if not self._buffer:
            return
        lines = []
        for e in self._buffer:
            parts = [f"[{e.category.upper()}]", e.message]
            if e.data:
                parts.append(str(e.data))
            lines.append(f"{e.ts:.3f}  " + "  ".join(parts))
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
        except Exception:
            pass
        self._buffer.clear()
        self._last_flush = time.monotonic()

    # ── summary ─────────────────────────────────────────────
    def summary(self) -> str:
        self.flush()
        lines = ["=== Performance Summary ==="]
        for metric, values in self._metrics.items():
            avg = sum(values) / len(values)
            lines.append(
                f"  {metric}: avg={avg:.2f}ms  "
                f"min={min(values):.2f}ms  max={max(values):.2f}ms  "
                f"n={len(values)}"
            )
        return "\n".join(lines)

    def __del__(self) -> None:
        try:
            self.flush()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────
# Module-level singletons (lazy-init on first import)
# ─────────────────────────────────────────────────────────────
_cache: Optional[FileCache] = None
_reader: Optional[OptimizedFileReader] = None
_perf: Optional[PerformanceLogger] = None


def get_cache() -> FileCache:
    global _cache
    if _cache is None:
        _cache = FileCache()
    return _cache


def get_reader() -> OptimizedFileReader:
    global _reader
    if _reader is None:
        _reader = OptimizedFileReader(cache=get_cache())
    return _reader


def get_perf_logger() -> PerformanceLogger:
    global _perf
    if _perf is None:
        _perf = PerformanceLogger()
    return _perf


__all__ = [
    "FileCache",
    "OptimizedFileReader",
    "BatchFileProcessor",
    "PerformanceLogger",
    "BatchResult",
    "get_cache",
    "get_reader",
    "get_perf_logger",
    "BATCH_SIZE",
    "MAX_WORKERS",
]
