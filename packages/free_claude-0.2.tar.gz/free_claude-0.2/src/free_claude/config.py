"""Configuration constants for free-claude."""
import os

from .compat import get_token_dir

# Token file — stored in the OS-appropriate config directory
_token_dir = get_token_dir()
TOKEN_FILE = str(_token_dir / "token.json")
CONFIG_FILE = str(_token_dir / "config.json")

# API base URL — override via env var for custom deployments
API_BASE = os.environ.get(
    "FREE_CLAUDE_API_BASE",
    "https://api.interface.feedback/api_proxy",
)

# OAuth configuration — all values can be overridden via environment variables.
# Copy .env.example to .env and fill in your own values if self-hosting.
_OAUTH_DOMAIN = os.environ.get("FREE_CLAUDE_OAUTH_DOMAIN", "")
_OAUTH_CLIENT_ID = os.environ.get("FREE_CLAUDE_OAUTH_CLIENT_ID", "")
_OAUTH_AUDIENCE = os.environ.get("FREE_CLAUDE_OAUTH_AUDIENCE", "")

OAUTH_CONFIG = {
    "domain":       _OAUTH_DOMAIN,
    "clientId":     _OAUTH_CLIENT_ID,
    "audience":     _OAUTH_AUDIENCE,
    "authorizeUrl": f"https://{_OAUTH_DOMAIN}/authorize",
    "tokenUrl":     f"https://{_OAUTH_DOMAIN}/oauth/token",
    "redirectUri":  os.environ.get("FREE_CLAUDE_REDIRECT_URI", "http://localhost:3000/code"),
    "scope":        os.environ.get("FREE_CLAUDE_OAUTH_SCOPE", "openid profile email offline_access"),
}

MODELS = {
    "opus":    "claude-opus-4-5-20251101",
    "sonnet":  "claude-sonnet-4-5-20250929",
    "haiku":   "claude-haiku-4-5-20251001",
    "opus4":   "claude-opus-4-6",
    "sonnet4": "claude-sonnet-4-6",
    "default": "claude-opus-4-6",
}

DEFAULT_SYSTEM_PROMPT = """You are a powerful AI coding assistant and personal agent running locally on the user's machine.

You have access to these built-in tools:
- bash: run shell commands
- read_file: read text files
- write_file: write/create files
- list_dir: list directory contents
- web_fetch: fetch URLs
- python_eval: run Python code
- read_document: read PDF, Excel, Word, CSV, and **IMAGE files** (PNG/JPG/JPEG/GIF/WebP)

**IMPORTANT — Image/Vision handling:**
When the user mentions an image file path (e.g. "/path/to/photo.png", "image.jpg", "ảnh.png"),
ALWAYS call `read_document` with that path. Do NOT say you cannot access files.
The `read_document` tool will use Claude Vision to analyse the image automatically.
You are running locally — you CAN and SHOULD read files from the user's filesystem.

**CRITICAL RULES:**
1. For simple questions (greetings, explanations, opinions) → answer DIRECTLY without tools
2. For file/image/system tasks → use tools EFFICIENTLY, then write your COMPLETE answer
3. When user provides a file path → ALWAYS use the appropriate tool to read it
4. After gathering enough context, STOP tools and write a full, conclusive response
5. Do NOT leave the user without a final answer - always conclude with clear text
6. Keep bash commands safe; ask before destructive operations
7. You are a LOCAL agent — you have full access to the user's filesystem via tools
"""
