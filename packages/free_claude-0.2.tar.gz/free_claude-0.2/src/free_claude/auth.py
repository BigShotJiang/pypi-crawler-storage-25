"""Authentication for free-claude.

Token resolution order (highest priority first):
  1. FREE_CLAUDE_TOKEN env var   — CI/CD, Docker, scripts
  2. ~/.config/free-claude/token.json — saved via 'fclaude token set' or 'fclaude-login'
  3. Error — prompt user to set token
"""
import base64
import hashlib
import json
import os
import secrets
import threading
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer

from .compat import secure_file
from .config import OAUTH_CONFIG, TOKEN_FILE

# Env var name for direct token injection (CI/CD, Docker, scripts)
TOKEN_ENV_VAR = "FREE_CLAUDE_TOKEN"


def ensure_config_dir():
    os.makedirs(os.path.dirname(TOKEN_FILE), exist_ok=True)


def is_logged_in() -> bool:
    """True if token is available via env var OR saved token file."""
    return bool(os.environ.get(TOKEN_ENV_VAR)) or os.path.exists(TOKEN_FILE)


def get_token() -> str:
    """Get auth token. Checks env var first, then token file."""
    # Priority 1: env var (CI/CD, Docker, quick scripts)
    env_token = os.environ.get(TOKEN_ENV_VAR, "").strip()
    if env_token:
        return env_token

    # Priority 2: saved token file
    if not os.path.exists(TOKEN_FILE):
        print("❌ Not logged in.")
        print("   Option 1 (quick): export FREE_CLAUDE_TOKEN=<your_token>")
        print("   Option 2 (save):  fclaude token set <your_token>")
        print("   Option 3 (OAuth): fclaude-login")
        raise SystemExit(1)
    with open(TOKEN_FILE) as f:
        return json.load(f)["accessToken"]


def set_token(token: str) -> None:
    """Save a token directly to the token file. Cross-platform."""
    token = token.strip()
    if not token:
        raise ValueError("Token cannot be empty")
    ensure_config_dir()
    token_data = {
        "accessToken": token,
        "refreshToken": None,
        "source": "manual",
    }
    with open(TOKEN_FILE, "w") as f:
        json.dump(token_data, f, indent=2)
    secure_file(TOKEN_FILE)


def clear_token() -> bool:
    """Remove saved token file. Returns True if file existed."""
    if os.path.exists(TOKEN_FILE):
        os.remove(TOKEN_FILE)
        return True
    return False


def show_token() -> str:
    """Return masked token for display (shows first 8 + last 4 chars)."""
    env_token = os.environ.get(TOKEN_ENV_VAR, "").strip()
    source = "env var" if env_token else "file"
    try:
        token = get_token()
        if len(token) > 12:
            masked = token[:8] + "..." + token[-4:]
        else:
            masked = token[:4] + "..."
        return masked, source
    except SystemExit:
        return None, None


def refresh_token() -> str:
    """Refresh access token. Returns new token or falls back to saved."""
    if not os.path.exists(TOKEN_FILE):
        return None
    with open(TOKEN_FILE) as f:
        saved = json.load(f)
    if not saved.get("refreshToken"):
        return saved.get("accessToken")
    try:
        data = {
            "grant_type": "refresh_token",
            "refresh_token": saved["refreshToken"],
            "client_id": OAUTH_CONFIG["clientId"],
        }
        req = urllib.request.Request(
            OAUTH_CONFIG["tokenUrl"],
            data=json.dumps(data).encode(),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
        saved["accessToken"] = result["access_token"]
        if "refresh_token" in result:
            saved["refreshToken"] = result["refresh_token"]
        ensure_config_dir()
        with open(TOKEN_FILE, "w") as f:
            json.dump(saved, f, indent=2)
        return saved["accessToken"]
    except Exception:
        return saved.get("accessToken")


def _gen_verifier() -> str:
    return base64.urlsafe_b64encode(os.urandom(32)).rstrip(b"=").decode()


def _gen_challenge(verifier: str) -> str:
    digest = hashlib.sha256(verifier.encode()).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


def login(open_browser: bool = True) -> str:
    """Full OAuth PKCE login flow. Returns access token."""
    verifier = _gen_verifier()
    challenge = _gen_challenge(verifier)
    state = secrets.token_urlsafe(32)

    auth_code = [None]
    done = threading.Event()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urllib.parse.urlparse(self.path)
            params = urllib.parse.parse_qs(parsed.query)
            if parsed.path == "/code" and "code" in params:
                auth_code[0] = params["code"][0]
                html = (
                    b"<html><body><h1>Login successful!</h1>"
                    b"<p>You can close this window.</p>"
                    b"<script>window.close()</script></body></html>"
                )
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(html)
                done.set()
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, *args):
            pass

    server = HTTPServer(("localhost", 3000), Handler)
    t = threading.Thread(target=server.serve_forever)
    t.daemon = True
    t.start()

    params = {
        "client_id": OAUTH_CONFIG["clientId"],
        "response_type": "code",
        "redirect_uri": OAUTH_CONFIG["redirectUri"],
        "scope": OAUTH_CONFIG["scope"],
        "audience": OAUTH_CONFIG["audience"],
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
    }
    url = f"{OAUTH_CONFIG['authorizeUrl']}?{urllib.parse.urlencode(params)}"

    print("\n🌐 Opening browser for login...")
    print(f"   URL: {url}\n")
    if open_browser:
        webbrowser.open(url)
    print("⏳ Waiting for callback... (120s timeout)")

    done.wait(timeout=120)
    server.shutdown()

    if not auth_code[0]:
        raise RuntimeError("Login timeout - no authorization code received")

    # Exchange code for tokens
    data = {
        "grant_type": "authorization_code",
        "code": auth_code[0],
        "redirect_uri": OAUTH_CONFIG["redirectUri"],
        "client_id": OAUTH_CONFIG["clientId"],
        "code_verifier": verifier,
    }
    req = urllib.request.Request(
        OAUTH_CONFIG["tokenUrl"],
        data=json.dumps(data).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        tokens = json.loads(resp.read())

    ensure_config_dir()
    token_data = {
        "accessToken": tokens["access_token"],
        "refreshToken": tokens.get("refresh_token"),
        "idToken": tokens.get("id_token"),
        "expiresIn": tokens.get("expires_in"),
    }
    with open(TOKEN_FILE, "w") as f:
        json.dump(token_data, f, indent=2)
    # Cross-platform file permission hardening (Unix: chmod 600, Windows: icacls)
    secure_file(TOKEN_FILE)
    print(f"\n✅ Logged in! Token saved to {TOKEN_FILE}")
    return tokens["access_token"]
