"""
User-editable configuration via config.toml

Supports:
  - Default model
  - Custom system prompt
  - Theme (dark / light / minimal)
  - Max tool iterations
  - Log level

On first run, creates the file with defaults so users can discover all options.
Config location follows OS conventions (see compat.py).
"""
import os
from pathlib import Path
from typing import Any, Dict

from .compat import CONFIG_DIR

# ── Config location ────────────────────────────────────────────────────────

_CONFIG_DIR = Path(os.environ.get("FREE_CLAUDE_CONFIG_DIR", str(CONFIG_DIR)))
_CONFIG_FILE = _CONFIG_DIR / "config.toml"

# ── Defaults ───────────────────────────────────────────────────────────────

DEFAULTS: Dict[str, Any] = {
    "model": "default",
    "theme": "dark",
    "max_tool_iterations": 25,
    "log_level": "WARNING",
    "auto_load_plugins": True,
    "show_token_usage": False,
    "system_prompt": "",  # empty = use built-in default
}

_DEFAULT_TOML = f"""\
# free-claude configuration
# Location: {_CONFIG_FILE}
#
# Available models: default, opus4, sonnet4, opus, sonnet, haiku

model = "default"

# Theme: dark | light | minimal
theme = "dark"

# Maximum tool call iterations per user turn
max_tool_iterations = 25

# Log level: DEBUG | INFO | WARNING | ERROR
log_level = "WARNING"

# Auto-load claude-hfi plugins on startup
auto_load_plugins = true

# Show token usage after each response
show_token_usage = false

# Custom system prompt (leave empty to use built-in default)
system_prompt = ""
"""


# ── TOML reader (stdlib only, no tomllib fallback for Python <3.11) ────────

def _parse_toml(text: str) -> Dict[str, Any]:
    """Minimal TOML parser — handles the simple key = value pairs we use."""
    result: Dict[str, Any] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        # Skip comments and blanks
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        raw_val = raw_val.strip()

        # Booleans
        if raw_val.lower() == "true":
            result[key] = True
        elif raw_val.lower() == "false":
            result[key] = False
        # Integers
        elif raw_val.isdigit():
            result[key] = int(raw_val)
        # Quoted strings
        elif (raw_val.startswith('"') and raw_val.endswith('"')) or \
             (raw_val.startswith("'") and raw_val.endswith("'")):
            result[key] = raw_val[1:-1]
        else:
            result[key] = raw_val

    return result


def _write_toml(text: str):
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(text, encoding="utf-8")


# ── Public API ─────────────────────────────────────────────────────────────

class AppConfig:
    """Singleton-like config object loaded from TOML file."""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._data = {}
            cls._instance._loaded = False
        return cls._instance

    def load(self) -> "AppConfig":
        """Load config from disk. Creates default file if missing."""
        if not _CONFIG_FILE.exists():
            _write_toml(_DEFAULT_TOML)

        try:
            text = _CONFIG_FILE.read_text(encoding="utf-8")
            parsed = _parse_toml(text)
        except Exception:
            parsed = {}

        # Merge with defaults (file values win)
        self._data = {**DEFAULTS, **parsed}
        self._loaded = True
        return self

    def get(self, key: str, fallback: Any = None) -> Any:
        if not self._loaded:
            self.load()
        return self._data.get(key, DEFAULTS.get(key, fallback))

    def set(self, key: str, value: Any):
        """Update a value in memory (not persisted to disk)."""
        self._data[key] = value

    def save(self):
        """Persist current in-memory config back to disk."""
        lines = ["# free-claude configuration\n"]
        for k, v in self._data.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, int):
                lines.append(f"{k} = {v}")
            else:
                lines.append(f'{k} = "{v}"')
        _write_toml("\n".join(lines) + "\n")

    # Convenience properties
    @property
    def model(self) -> str:
        return self.get("model", "default")

    @property
    def theme(self) -> str:
        return self.get("theme", "dark")

    @property
    def max_tool_iterations(self) -> int:
        return int(self.get("max_tool_iterations", 25))

    @property
    def log_level(self) -> str:
        return self.get("log_level", "WARNING")

    @property
    def auto_load_plugins(self) -> bool:
        return bool(self.get("auto_load_plugins", True))

    @property
    def show_token_usage(self) -> bool:
        return bool(self.get("show_token_usage", False))

    @property
    def system_prompt(self) -> str:
        return self.get("system_prompt", "")

    def __repr__(self) -> str:
        return f"AppConfig({self._data})"


# Module-level singleton
config = AppConfig()


__all__ = ["AppConfig", "config", "DEFAULTS"]
