"""Core agent loop for free-claude — streaming, tools, MCP, and rich UI.

Architecture:
  Agent           — public API: __init__, run(), chat(), cleanup()
  CommandMixin    — /slash command handling  (agent_cmds.py)
  PluginMixin     — MCP plugin loading       (agent_plugins.py)
  UIMixin         — display helpers          (agent_ui.py)
"""
import json
import os
import threading
import urllib.error
import urllib.request
from typing import Optional

from . import rich_ui as ui
from .adaptive_thinking import get_adaptive_thinking
from .agent_cmds import CommandMixin

# Mixin classes — each in its own file for maintainability
from .agent_plugins import PluginMixin
from .agent_ui import UIMixin
from .app_config import config as app_config
from .auth import get_token, refresh_token
from .config import API_BASE, DEFAULT_SYSTEM_PROMPT, MODELS
from .core import ContextManager, StreamingClient, ToolExecutor
from .git_index import get_file_index
from .hooks import PostHookContext, ToolHookContext, get_hooks
from .intelligence import ContextSummarizer, MemoryStore, TaskPlanner
from .logger import log
from .magic_doc import get_magic_doc
from .mcp import StdioMCPClient
from .permissions import get_permissions
from .session import CheckpointManager, SessionExporter, SessionHistory
from .tools import BUILTIN_TOOLS, execute_tool


class Agent(CommandMixin, PluginMixin, UIMixin):
    """Free Claude agent with tool use, MCP support, and rich UI.

    Inherits:
      CommandMixin  — /slash command implementations
      PluginMixin   — MCP plugin loading & management
      UIMixin       — display helpers (usage table, config, help…)
    """

    def __init__(self, model: str = "default", system: str = None,
                 mcp_servers: dict = None, mcp_clients: list = None,
                 auto_plugins: bool = True,
                 thinking_budget: int = 0):
        app_config.load()

        # ── Step 1: Auth ───────────────────────────────────────────────
        self.token = self._init_token()

        resolved_model = model if model != "default" else app_config.model
        self.model = MODELS.get(resolved_model, MODELS["default"])
        self.system = system or app_config.system_prompt or DEFAULT_SYSTEM_PROMPT
        log.info("Agent init: model=%s", self.model)

        self.mcp_clients: list = []
        self.tools: list = list(BUILTIN_TOOLS)
        self.thinking_budget: int = thinking_budget

        # Core subsystems
        self._ctx = ContextManager()
        self._rate_limits: dict = {}

        # Intelligence & Session
        self._memory = MemoryStore()
        self._planner = TaskPlanner()
        self._summarizer = ContextSummarizer()
        self._history = SessionHistory()
        self._checkpoint = CheckpointManager()
        self._exporter = SessionExporter()
        self._current_session_id: Optional[str] = None

        # Stability & Intelligence (Phase 3)
        self._hooks = get_hooks()
        self._permissions = get_permissions()
        self._magic_doc = get_magic_doc()
        self._git_index = get_file_index(os.getcwd(), start_background=True)
        self._adaptive = get_adaptive_thinking()
        self._adaptive.api_base = API_BASE

        # Inject project memory into system prompt
        doc_context = self._magic_doc.load_into_context()
        if doc_context:
            self.system = (self.system or "") + doc_context
            log.info("Agent: Magic Doc injected into system prompt")

        # ── Step 2: Plugin loading ─────────────────────────────────────
        self._bg_plugin_thread: Optional[threading.Thread] = None

        # Pre-created MCP clients (already started by cli.py)
        if mcp_clients:
            for client in mcp_clients:
                self.mcp_clients.append(client)
                self.tools.extend(client.get_tool_definitions())

        # stdio MCP servers from {name: [cmd, args...]} dict
        if mcp_servers:
            for name, cmd in mcp_servers.items():
                client = StdioMCPClient(name, cmd)
                if client.start():
                    self.mcp_clients.append(client)
                    self.tools.extend(client.get_tool_definitions())

    # ── Auth ───────────────────────────────────────────────────────────

    def _init_token(self) -> str:
        """Refresh/load auth token with a visible spinner."""
        from rich.text import Text

        from .config import TOKEN_FILE

        if not os.path.exists(TOKEN_FILE):
            return get_token()

        result_holder = [None]
        error_holder = [None]

        def _do_refresh():
            try:
                result_holder[0] = refresh_token() or get_token()
            except Exception as e:
                error_holder[0] = e

        t = threading.Thread(target=_do_refresh, daemon=True)
        t.start()
        t.join(timeout=0.3)
        if t.is_alive():
            status_text = Text.assemble(
                ("  🔐 ", "dim"), ("Authenticating", "dim cyan"), ("...", "dim")
            )
            with ui.console.status(status_text, spinner="dots"):
                t.join(timeout=12)

        if error_holder[0]:
            raise error_holder[0]
        if result_holder[0] is None:
            return get_token()
        return result_holder[0]

    # ── Compatibility shims ────────────────────────────────────────────

    @property
    def messages(self) -> list:
        return self._ctx.messages

    @messages.setter
    def messages(self, val: list):
        self._ctx.messages = val

    # ── Internal helpers ───────────────────────────────────────────────

    def _streamer(self) -> StreamingClient:
        return StreamingClient(API_BASE, self.token, self.model,
                               self.system, self.tools,
                               thinking_budget=self.thinking_budget)

    def _fast_streamer(self) -> StreamingClient:
        """Haiku streamer without tools — for simple queries (~1s TTFT)."""
        haiku_model = MODELS.get("haiku", self.model)
        fast_system = (
            "You are a concise AI assistant. "
            "Answer directly and briefly — no bullet lists, no preamble. "
            "Match the user's language (Vietnamese if they write Vietnamese)."
        )
        return StreamingClient(API_BASE, self.token, haiku_model,
                               fast_system, [], thinking_budget=0)

    def _is_simple_query(self, text: str) -> bool:
        """Heuristic: detect if a query needs tools or can be answered directly."""
        import re
        t = text.strip().lower()
        _continue_signals = (
            "continue", "tiếp tục", "tiep tuc", "keep going", "go on",
            "carry on", "proceed", "next", "finish", "complete", "done yet",
            "still working", "fix it", "fix that", "try again", "retry",
            "làm tiếp", "làm nốt", "hoàn thành", "xong chưa",
        )
        if any(sig in t for sig in _continue_signals):
            return False
        if len(t) < 60 and any(t.startswith(w) for w in (
            "hi", "hello", "hey", "xin chào", "chào", "cảm ơn", "thanks",
            "thank you", "ok", "okay", "yes", "no", "yep", "nope",
        )):
            return True
        if re.match(r'^[\d\s\+\-\*\/\^\(\)\%\.]+[=\?]?\s*$', t):
            return True
        simple_patterns = [
            r'^(what|who|when|where|why|how)\s+is\b',
            r'^(explain|define|describe|tell me about)\b',
            r'^(translate|dịch)\b',
            r'^(write a (poem|joke|story|haiku))',
            r'^(list|name) \d+ ',
            r'^\d+\s*[\+\-\*\/]\s*\d+',
        ]
        for pat in simple_patterns:
            if re.search(pat, t):
                return True
        complex_keywords = [
            "file", "folder", "directory", "path", "run", "execute", "install",
            "tệp", "thư mục", "chạy", "cài",
            "code", "script", "function", "class", "debug", "error", "fix",
            "git", "docker", "pip", "npm", "bash", "terminal",
            "read", "write", "open", "save", "delete", "create",
            "search", "find", "grep", "ls", "cd",
            "web", "url", "http", "api", "fetch",
            "excel", "pdf", "csv", "image",
            ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
            ".mp4", ".mp3", ".wav", ".pdf", ".docx", ".xlsx",
            "ảnh", "hình", "đọc", "xem", "phân tích", "mô tả",
            "tài liệu", "văn bản",
        ]
        if any(kw in t for kw in complex_keywords):
            return False
        return len(t) < 80

    def _maybe_summarize(self):
        """Auto-compress context if it's getting too large."""
        if self._summarizer.should_summarize(self._ctx.messages):
            ui.print_info("📝 Context large — summarizing older messages...")
            self._ctx.messages = self._summarizer.maybe_compress(
                self._ctx.messages, API_BASE, self.token
            )

    def _executor(self) -> ToolExecutor:
        return ToolExecutor(self.mcp_clients, execute_tool)

    # ── Public API ─────────────────────────────────────────────────────

    def run(self, user_input: str, max_iters: int = None, stream: bool = False) -> str:
        """Run the agent loop for a single user turn."""
        if max_iters is None:
            max_iters = app_config.max_tool_iterations
        self._ctx.add_user(user_input)
        header_printed = False

        # Phase 3: Adaptive thinking — auto-select budget if enabled
        if self._adaptive.enabled and self.thinking_budget == 0:
            conv_len = len(self._ctx.messages)
            auto_budget = self._adaptive.get_budget(user_input, conv_len)
            if auto_budget > 0:
                self.thinking_budget = auto_budget
                streamer = self._streamer()
                self.thinking_budget = 0
            else:
                streamer = self._streamer()
        else:
            streamer = self._streamer()

        executor = self._executor()
        self._maybe_summarize()

        all_turn_calls: set = set()

        for i in range(max_iters):
            try:
                if stream:
                    if not header_printed:
                        ui.print_assistant_header()
                        header_printed = True
                    response, rl = streamer.stream(self._ctx.get(), ui.console)
                else:
                    response, rl = streamer.call(self._ctx.get())
            except urllib.error.HTTPError as e:
                if e.code == 401:
                    self.token = refresh_token() or get_token()
                    streamer = self._streamer()
                    response, rl = streamer.call(self._ctx.get())
                else:
                    err = e.read().decode()
                    self._ctx.pop_last()
                    return f"❌ API Error {e.code}: {err[:200]}"
            except KeyboardInterrupt:
                self._ctx.pop_last()
                raise

            self._rate_limits = rl
            self._ctx.track_usage(response.get("usage", {}))

            stop_reason = response.get("stop_reason")
            content = response.get("content", [])
            self._ctx.add_assistant(content)

            if stop_reason == "end_turn":
                final_text = " ".join(
                    b.get("text", "") for b in content if b.get("type") == "text"
                ).strip()

                # Guard: empty response — re-prompt once without tools
                if not final_text:
                    self._ctx.add_user([{
                        "type": "text",
                        "text": (
                            "Please provide your analysis and response based on the "
                            "information you just retrieved. Write your answer now."
                        ),
                    }])
                    try:
                        if stream:
                            response2, _ = streamer.stream(
                                self._ctx.get(), ui.console, include_tools=False)
                            final_text = response2.get("full_text", "")
                        else:
                            response2, _ = streamer.call(
                                self._ctx.get(), include_tools=False)
                            final_text = " ".join(
                                b.get("text", "") for b in response2.get("content", [])
                                if b.get("type") == "text"
                            ).strip()
                        self._ctx.add_assistant(response2.get("content", []))
                    except Exception:
                        final_text = "(No response from model — please try again)"

                if stream:
                    ui.print_response_end()
                return final_text

            elif stop_reason == "tool_use":
                ui.print_step(i + 1, max_iters)
                tool_results = []

                for block in content:
                    if block.get("type") != "tool_use":
                        continue

                    # Deduplicate same tool+input across steps
                    call_key = (block["name"], json.dumps(block.get("input", {}), sort_keys=True))
                    if call_key in all_turn_calls:
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block["id"],
                            "content": (
                                "[Duplicate tool call skipped — result already provided. "
                                "Use the information already retrieved to write your answer.]"
                            ),
                        })
                        continue
                    all_turn_calls.add(call_key)

                    # Pre-tool hook
                    hook_ctx = ToolHookContext(
                        tool_name=block["name"],
                        tool_input=block.get("input", {}),
                        iteration=i,
                    )
                    hook_result = self._hooks.run_pre(hook_ctx)
                    if not hook_result.allowed:
                        ui.print_warning(f"🚫 Tool blocked by hook: {hook_result.reason}")
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block["id"],
                            "content": f"[Blocked] {hook_result.reason}",
                        })
                        continue
                    if hook_result.modified_input:
                        block = dict(block)
                        block["input"] = hook_result.modified_input

                    # Permission check
                    perm = self._permissions.check(block["name"], block.get("input", {}))
                    if perm == "confirm":
                        allowed = self._permissions.ask_user(
                            block["name"], block.get("input", {}),
                            description=block.get("detail", "")
                        )
                        if not allowed:
                            tool_results.append({
                                "type": "tool_result",
                                "tool_use_id": block["id"],
                                "content": "[Permission denied by user]",
                            })
                            continue

                    # Run tool with spinner
                    import time as _time

                    from rich.live import Live
                    from rich.text import Text as _RichText

                    _tool_name_display = block["name"].replace("mcp_serena_", "serena/").replace("mcp_", "")
                    _t0 = _time.perf_counter()
                    _tool_out_holder = [None]
                    _tool_error_holder = [None]

                    def _run_tool():
                        try:
                            _tool_out_holder[0] = executor.run(block)
                        except Exception as _e:
                            _tool_error_holder[0] = _e

                    _tool_thread = __import__("threading").Thread(target=_run_tool, daemon=True)
                    _tool_thread.start()

                    with Live(
                        _RichText.assemble(("  ⚙ ", "dim cyan"), (_tool_name_display, "cyan"), ("...", "dim")),
                        console=ui.console,
                        refresh_per_second=10,
                        transient=True,
                    ) as _live:
                        _spin_t = _time.monotonic()
                        _frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
                        _fi = 0
                        while _tool_thread.is_alive():
                            _elapsed = int(_time.monotonic() - _spin_t)
                            _frame = _frames[_fi % len(_frames)]
                            _fi += 1
                            _live.update(_RichText.assemble(
                                (f"  {_frame} ", "dim cyan"),
                                (_tool_name_display, "cyan"),
                                (f"  [{_elapsed}s]" if _elapsed > 0 else "  ", "dim yellow"),
                            ))
                            _tool_thread.join(timeout=0.1)

                    _tool_thread.join()
                    if _tool_error_holder[0]:
                        raise _tool_error_holder[0]
                    tool_out = _tool_out_holder[0]
                    _tool_ms = (_time.perf_counter() - _t0) * 1000

                    # Post-tool hook
                    post_ctx = PostHookContext(
                        tool_name=tool_out["name"],
                        tool_input=block.get("input", {}),
                        tool_output=tool_out["result"],
                        duration_ms=_tool_ms,
                    )
                    post_result = self._hooks.run_post(post_ctx)
                    if post_result.modified_output is not None:
                        tool_out["result"] = post_result.modified_output

                    ui.print_tool_call(tool_out["name"], tool_out["detail"])
                    if tool_out["dropped"]:
                        ui.print_warning(f"Tool result truncated ({tool_out['dropped']:,} chars dropped)")
                    if self._hooks.hook_count > 0:
                        stats = self._hooks.stats_line()
                        if stats:
                            ui.console.print(f"[dim]{stats}[/dim]")
                        self._hooks.reset_stats()
                    ui.print_tool_result(tool_out["result"])
                    tool_results.append(tool_out["payload"])

                self._ctx.add_user(tool_results)
                ui.print_step_end()
                if stream:
                    ui.console.print()
                continue

            else:
                text = " ".join(
                    b.get("text", "") for b in content if b.get("type") == "text"
                ).strip()
                return text or f"(stop: {stop_reason})"

        return self._force_summary(streamer, stream)

    def _force_summary(self, streamer: StreamingClient, stream: bool) -> str:
        """Called when max_iters is hit — get a final answer without tools."""
        ui.print_summarizing()
        summary_msgs = self._ctx.get() + [{
            "role": "user",
            "content": (
                "You have used all available steps. "
                "Summarize what you have done so far and what still needs to be done. "
                "Be explicit about any unfinished parts so the user knows what to ask next. "
                "Do NOT call any more tools - text only."
            ),
        }]
        try:
            if stream:
                ui.print_assistant_header()
                response, _ = streamer.stream(summary_msgs, ui.console, include_tools=False)
                ui.print_response_end()
                result = response.get("full_text", "")
            else:
                response, _ = streamer.call(summary_msgs)
                result = " ".join(
                    b.get("text", "") for b in response.get("content", [])
                    if b.get("type") == "text"
                ).strip()
            ui.console.print(
                "\n[dim]💡 Reached max tool steps. "
                "Type [bold cyan]'continue'[/bold cyan] to keep going, "
                "or [bold cyan]/save session[/bold cyan] to save progress.[/dim]\n"
            )
            return result
        except Exception:
            return "❌ Max iterations reached"

    # ── Interactive chat loop ──────────────────────────────────────────

    def chat(self):
        n_builtin = sum(1 for t in self.tools if not t["name"].startswith("mcp_"))
        n_mcp = len(self.tools) - n_builtin
        plugin_names = [c.name for c in self.mcp_clients] if self.mcp_clients else None
        ui.set_current_model(self.model)
        ui.print_banner(self.model, n_builtin, n_mcp, plugin_names=plugin_names,
                        thinking_budget=self.thinking_budget)

        while True:
            try:
                cwd = os.path.basename(os.getcwd())
                user_input = ui.print_user_prompt(cwd)
            except (KeyboardInterrupt, EOFError):
                ui.print_goodbye()
                self.cleanup()
                break

            stripped_input = user_input.strip()
            if not stripped_input:
                continue

            # "!" → run as shell command
            if stripped_input.startswith("!"):
                shell_cmd = stripped_input[1:].strip()
                if shell_cmd:
                    try:
                        result = os.popen(shell_cmd).read()
                        if result:
                            ui.console.print(result, end="")
                    except Exception as e:
                        ui.print_error(str(e))
                continue

            # Friendly aliases without leading slash
            lowered = stripped_input.lower()
            if lowered == "help" or lowered.startswith("help "):
                self._handle_cmd("/help")
                continue
            if lowered in ("models", "model") or lowered.startswith("model "):
                suffix = stripped_input[5:].strip() if len(stripped_input) > 5 else ""
                self._handle_cmd(f"/model {suffix}".rstrip())
                continue

            if stripped_input.startswith("/"):
                self._handle_cmd(stripped_input)
                continue

            try:
                self.run(user_input, stream=True)
            except KeyboardInterrupt:
                ui.print_interrupted()
                self._ctx.pop_last()

    def cleanup(self):
        for client in self.mcp_clients:
            client.stop()
