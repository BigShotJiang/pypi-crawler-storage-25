"""Message context management — history, trimming, usage tracking."""
from typing import Dict, List

_MAX_CONTEXT_CHARS = 400_000  # ~100k tokens, well within Claude's 200k window

# Rough chars-per-token estimate for Claude models (conservative)
_CHARS_PER_TOKEN = 3.5


def _estimate_tokens(text: str) -> int:
    """Estimate token count from character count."""
    return max(1, int(len(text) / _CHARS_PER_TOKEN))


class ContextManager:
    """Manages conversation history, context trimming, and token usage tracking."""

    def __init__(self):
        self.messages: List[Dict] = []
        self._total_input_tokens: int = 0
        self._total_output_tokens: int = 0
        self._total_requests: int = 0

    # ── Message history ────────────────────────────────────────────────

    def add_user(self, content) -> None:
        self.messages.append({"role": "user", "content": content})

    def add_assistant(self, content) -> None:
        self.messages.append({"role": "assistant", "content": content})

    def pop_last(self) -> None:
        if self.messages:
            self.messages.pop()

    def clear(self) -> None:
        self.messages.clear()

    def get(self) -> List[Dict]:
        """Return messages, trimmed to fit context window."""
        return self._trim(list(self.messages))

    # ── Context trimming ───────────────────────────────────────────────

    def _content_chars(self, msg: Dict) -> int:
        """Measure content size of a single message."""
        content = msg.get("content", "")
        if isinstance(content, list):
            return sum(len(str(c)) for c in content)
        return len(str(content))

    def _total_chars(self, messages: List[Dict]) -> int:
        return sum(self._content_chars(m) for m in messages)

    def estimated_tokens(self, messages: List[Dict] = None) -> int:
        """Estimate total token count for messages (or current history)."""
        msgs = messages if messages is not None else self.messages
        total_chars = sum(self._content_chars(m) for m in msgs)
        return max(1, int(total_chars / _CHARS_PER_TOKEN))

    def _trim(self, messages: List[Dict]) -> List[Dict]:
        """Drop oldest middle messages until under budget.

        Strategy: always keep the first user message for context,
        and at least the last 4 messages for continuity.
        Drop from the middle outward.
        """
        if self._total_chars(messages) <= _MAX_CONTEXT_CHARS:
            return messages

        trimmed = list(messages)
        # Never drop below 2 messages (first + last)
        while len(trimmed) > 2 and self._total_chars(trimmed) > _MAX_CONTEXT_CHARS:
            # Remove from index 1 (keep index 0 = first user msg)
            trimmed.pop(1)
        return trimmed

    def needs_trim(self) -> bool:
        return self._total_chars(self.messages) > _MAX_CONTEXT_CHARS

    # ── Usage tracking ─────────────────────────────────────────────────

    def track_usage(self, usage: dict) -> None:
        self._total_input_tokens += usage.get("input_tokens", 0)
        self._total_output_tokens += usage.get("output_tokens", 0)
        self._total_requests += 1

    @property
    def total_tokens(self) -> int:
        return self._total_input_tokens + self._total_output_tokens

    def usage_summary(self) -> Dict:
        return {
            "requests": self._total_requests,
            "input_tokens": self._total_input_tokens,
            "output_tokens": self._total_output_tokens,
            "total_tokens": self.total_tokens,
        }


__all__ = ["ContextManager"]
