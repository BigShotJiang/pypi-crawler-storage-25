"""Tool execution engine — dispatches built-in and MCP tool calls."""
from typing import Any, Callable, Dict, List, Tuple

_MAX_TOOL_RESULT_CHARS = 20_000
_IMAGE_SENTINEL = "__IMAGE_VISION__:"


class ToolExecutor:
    """
    Executes tool calls — both built-in and MCP plugin tools.
    Truncates oversized results to prevent context overflow.

    Vision support:
      When a tool returns a string starting with ``__IMAGE_VISION__:<mime>:<b64>``,
      the executor builds a multi-content ``tool_result`` block that includes both
      an image block (so Claude can actually *see* the image via Vision API) and a
      short text description.  All other results are plain text as before.
    """

    def __init__(self, mcp_clients: List, execute_builtin: Callable):
        self.mcp_clients = mcp_clients
        self._execute_builtin = execute_builtin

    def run(self, block: Dict) -> Dict:
        """
        Execute a tool_use block from the API response.

        Returns a dict with:
          - name:    tool name
          - detail:  short description for display
          - result:  truncated result string (for UI display)
          - payload: ready-to-send tool_result dict for the API
          - dropped: chars dropped by truncation (0 if none)
        """
        name: str = block["name"]
        inputs: Dict[str, Any] = block["input"]
        tool_id: str = block["id"]

        detail = (
            inputs.get("command")
            or inputs.get("path")
            or inputs.get("url")
            or str(inputs.get("code", ""))[:60]
            or ""
        )

        try:
            result = self._dispatch(name, inputs)
        except KeyboardInterrupt:
            result = "[INTERRUPTED] Tool was stopped by user"

        result_str = str(result)

        # ── Vision image sentinel ─────────────────────────────────────────
        # tools.py returns "__IMAGE_VISION__:<mime>:<base64>" for image files.
        # We convert this into a proper multi-content tool_result that Claude
        # can actually process with its vision capability.
        if result_str.startswith(_IMAGE_SENTINEL):
            payload, display = self._build_image_payload(tool_id, result_str, inputs)
            return {
                "name": name,
                "detail": str(detail),
                "result": display,
                "dropped": 0,
                "payload": payload,
            }

        # ── Normal text result ────────────────────────────────────────────
        result_str, dropped = self._truncate(result_str)

        return {
            "name": name,
            "detail": str(detail),
            "result": result_str,
            "dropped": dropped,
            "payload": {
                "type": "tool_result",
                "tool_use_id": tool_id,
                "content": result_str,
            },
        }

    def _build_image_payload(self, tool_id: str, sentinel: str,
                              inputs: Dict) -> Tuple[Dict, str]:
        """Build a vision-compatible tool_result from the image sentinel."""
        # sentinel format: "__IMAGE_VISION__:<mime>:<base64_data>"
        rest = sentinel[len(_IMAGE_SENTINEL):]
        mime, _, b64_data = rest.partition(":")

        from pathlib import Path
        path = inputs.get("path", "unknown")
        fname = Path(path).name
        size_kb = len(b64_data) * 3 // 4 // 1024  # approx decoded size

        display = f"[Vision] Sending {fname} ({size_kb} KB) to Claude Vision API"

        payload = {
            "type": "tool_result",
            "tool_use_id": tool_id,
            "content": [
                {
                    "type": "text",
                    "text": (
                        f"Image file: {fname}\n"
                        f"Please analyse the image below and describe what you see, "
                        f"extract any text, answer questions about it, etc."
                    ),
                },
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": mime,
                        "data": b64_data,
                    },
                },
            ],
        }
        return payload, display

    def _dispatch(self, name: str, inputs: Dict) -> Any:
        """Route tool call to built-in handler or MCP client."""
        if name.startswith("mcp_"):
            parts = name[4:].split("_", 1)
            client_name = parts[0]
            tool_name = parts[1] if len(parts) > 1 else ""
            for client in self.mcp_clients:
                if client.name == client_name:
                    return client.call_tool(tool_name, inputs)
            return f"[ERROR] MCP client '{client_name}' not found"
        return self._execute_builtin(name, inputs)

    def _truncate(self, result_str: str) -> Tuple[str, int]:
        """Truncate if over limit. Returns (result, dropped_chars)."""
        if len(result_str) <= _MAX_TOOL_RESULT_CHARS:
            return result_str, 0
        kept = result_str[:_MAX_TOOL_RESULT_CHARS]
        dropped = len(result_str) - _MAX_TOOL_RESULT_CHARS
        notice = f"\n\n[... {dropped:,} characters truncated to avoid context overflow ...]"
        return kept + notice, dropped


__all__ = ["ToolExecutor"]
