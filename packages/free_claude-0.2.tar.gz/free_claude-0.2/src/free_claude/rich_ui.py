"""Production-style Rich UI for free-claude CLI."""
import os
import subprocess
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

# Enable readline support for input() — cross-platform (Linux, macOS, Windows)
from .compat import setup_readline, setup_slash_completion

setup_readline()
setup_slash_completion()

from rich import box
from rich.console import Console, Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console(highlight=False, soft_wrap=True)
_current_model = ""
_tool_group_open = False
_tool_group_calls = 0


# ── Theme-ish style constants ──────────────────────────────────────────────
_ACCENT = "bold cyan"
_MUTED = "dim"
_BORDER = "dim cyan"
_WARN = "yellow"
_ERROR = "bold red"
_SUCCESS = "bold green"
_ASSISTANT = "bold cyan"
_TOOL = "bold magenta"


def _terminal_width() -> int:
    try:
        return max(console.size.width, 60)
    except Exception:
        return 100


def _fit(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    if max_len <= 1:
        return text[:max_len]
    return text[: max_len - 1] + "…"


def _app_version() -> str:
    try:
        from importlib.metadata import version
        return version("free-claude")
    except Exception:
        return "dev"


def _short_model_name(model: str) -> str:
    """Return a human-readable short model name, preserving version numbers."""
    m = (model or "").lower()
    if not m:
        return "unknown"
    # Extract version suffix like -4-5, -4-6, -3-5 etc → 4.5, 4.6, 3.5
    import re
    ver_match = re.search(r"-(\d)-(\d+)(?:-\d+)?$", m)
    ver = f" {ver_match.group(1)}.{ver_match.group(2)}" if ver_match else ""
    if "opus" in m:
        return f"opus{ver}" if ver else "opus"
    if "sonnet" in m:
        return f"sonnet{ver}" if ver else "sonnet"
    if "haiku" in m:
        return f"haiku{ver}" if ver else "haiku"
    if m.startswith("claude-"):
        m = m[len("claude-"):]
    return m


def _git_branch(cwd: Optional[str] = None) -> Optional[str]:
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=cwd or os.getcwd(),
            capture_output=True,
            text=True,
            timeout=2.0,   # Generous timeout for Windows (was 0.35s)
            check=False,
        )
    except Exception:
        return None
    if proc.returncode != 0:
        return None
    branch = (proc.stdout or "").strip()
    if not branch or branch == "HEAD":
        return None
    return branch


def _workspace_label(path: Optional[str] = None) -> str:
    path = path or os.getcwd()
    home = os.path.expanduser("~")
    display = path.replace(home, "~") if path.startswith(home) else path
    return _fit(display, max(28, _terminal_width() - 32))


def _plugin_summary(plugin_names: Sequence[str], max_items: int = 3) -> str:
    names = [n for n in plugin_names if n]
    if not names:
        return "none"
    if len(names) <= max_items:
        return ", ".join(names)
    return ", ".join(names[:max_items]) + f" +{len(names) - max_items} more"


def _summary_lines(text: str, max_lines: int = 3, max_width: Optional[int] = None) -> List[str]:
    if not text:
        return ["(no output)"]
    max_width = max_width or max(40, _terminal_width() - 16)
    raw_lines = [ln.rstrip() for ln in text.splitlines()]
    lines = [ln for ln in raw_lines if ln.strip()]
    if not lines:
        lines = ["(blank output)"]
    preview = [_fit(ln, max_width) for ln in lines[:max_lines]]
    remaining = len(lines) - len(preview)
    if remaining > 0:
        preview.append(f"… {remaining} more line{'s' if remaining != 1 else ''}")
    return preview


def _rule_line(left: str, label: str = "", right: str = "", style: str = _BORDER) -> Text:
    width = _terminal_width()
    plain_prefix = f"{left}{label}" if label else left
    remaining = max(width - len(plain_prefix) - len(right), 4)
    return Text.assemble((plain_prefix, style), ("─" * remaining, style), (right, style))


def _kv_line(icon: str, label: str, value: str, value_style: str = "white") -> Text:
    return Text.assemble(
        (f" {icon} ", _MUTED),
        (f"{label:<8} ", "bold white"),
        (value, value_style),
    )


def _help_table(title: str, rows: Sequence[Tuple[str, str, str]]) -> Table:
    table = Table(
        title=title,
        box=box.SIMPLE_HEAVY,
        show_header=True,
        header_style="bold cyan",
        border_style=_BORDER,
        padding=(0, 1),
        expand=True,
    )
    table.add_column("Command", style="yellow", no_wrap=True, width=22)
    table.add_column("What it does", style="white", ratio=2)
    table.add_column("Example", style="dim cyan", ratio=2)
    for cmd, desc, example in rows:
        table.add_row(Text(cmd, style="yellow"), Text(desc, style="white"), Text(example, style="dim cyan"))
    return table


# ── Shared stateful UI API ─────────────────────────────────────────────────

def set_current_model(model: str) -> None:
    global _current_model
    _current_model = model or ""


def render_markdown(text: str) -> None:
    if text:
        console.print(Markdown(text))


def print_banner(model: str, n_builtin: int, n_mcp: int,
                 plugin_names: Optional[Iterable[str]] = None,
                 thinking_budget: int = 0) -> None:
    plugin_names = list(plugin_names or [])
    console.print()
    top = Text.assemble(
        ("free-claude", "bold white"),
        (f" v{_app_version()}", _MUTED),
        ("  ·  ", _MUTED),
        (_fit(model, 24), "bold green"),
        ("  ·  ", _MUTED),
        (_workspace_label(), "yellow"),
    )
    console.print(top)

    think_value = f"on ({thinking_budget:,})" if thinking_budget else "off"
    body = Group(
        _kv_line("🤖", "Model", _fit(model, 40), "green"),
        _kv_line("🔧", "Tools", f"{n_builtin} built-in · {n_mcp} MCP", "white"),
        _kv_line("🔌", "Plugins", _plugin_summary(plugin_names), "cyan" if plugin_names else _MUTED),
        _kv_line("🧠", "Thinking", think_value, "magenta" if thinking_budget else _MUTED),
    )
    console.print(Panel(body, title="[bold cyan]free-claude[/bold cyan]", border_style="cyan", box=box.ROUNDED, padding=(0, 1)))
    quick = Text.assemble(
        ("Quick: ", _MUTED),
        ("/help", "cyan"), (" · ", _MUTED),
        ("/model", "cyan"), (" · ", _MUTED),
        ("/tools", "cyan"), (" · ", _MUTED),
        ("/plugins", "cyan"), (" · ", _MUTED),
        ("/quit", "cyan"),
        ("  ·  ", _MUTED),
        ("multiline: ", _MUTED),
        ("\\", "yellow"),
        (" or ", _MUTED),
        ("/paste", "cyan"),
    )
    console.print(quick)
    console.print()


def print_assistant_header() -> None:
    console.print()
    # Use a simple rule that doesn't create a "box" — typewriter writes directly
    # to sys.stdout in between, so we must NOT use Rich Panel or Live here.
    # A plain horizontal rule avoids the conflict between Rich and sys.stdout.
    console.print(Text("─" * min(80, _terminal_width()), style="dim cyan"))
    console.print(Text("  fclaude", style="bold cyan"))


def print_response_end() -> None:
    console.print()
    console.print(Text("─" * min(80, _terminal_width()), style="dim cyan"))
    console.print()


def print_step(step_num: int, max_steps: int) -> None:
    global _tool_group_open, _tool_group_calls
    _tool_group_open = True
    _tool_group_calls = 0
    console.print()
    console.print(_rule_line("┌ ", f"Step {step_num}/{max_steps} ", "", style=_BORDER))


def print_step_end() -> None:
    global _tool_group_open, _tool_group_calls
    if _tool_group_open:
        console.print(Text("└" + "─" * max(10, _terminal_width() - 2), style=_BORDER))
    _tool_group_open = False
    _tool_group_calls = 0


def print_tool_call(name: str, detail: str = "") -> None:
    global _tool_group_calls
    _tool_group_calls += 1
    prefix = "├"
    label = Text()
    label.append(f"{prefix} ⚙ ", style=_MUTED)
    label.append(name, style=_TOOL)
    if detail:
        compact = " ".join(detail.split())
        label.append(" → ", style=_MUTED)
        label.append(_fit(compact, max(24, _terminal_width() - 22)), style="white")
    console.print(label)


def print_tool_result(result: str) -> None:
    for idx, line in enumerate(_summary_lines(result)):
        prefix = "│   ↳ " if idx == 0 else "│     "
        style = "white" if idx == 0 else _MUTED
        console.print(Text.assemble((prefix, _MUTED), (line, style)))


_adaptive_enabled: bool = True   # mirrors AdaptiveThinkingManager.enabled


def set_adaptive_status(enabled: bool) -> None:
    global _adaptive_enabled
    _adaptive_enabled = enabled


def _get_prompt_session():
    """Lazily create and cache a prompt_toolkit PromptSession with multiline paste support."""
    global _pt_session
    if _pt_session is not None:
        return _pt_session
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import InMemoryHistory
        from prompt_toolkit.key_binding import KeyBindings
        from prompt_toolkit.filters import is_done

        bindings = KeyBindings()

        @bindings.add("escape", "enter")
        def _insert_newline(event):
            """Alt+Enter inserts a newline without submitting."""
            event.current_buffer.insert_text("\n")

        _pt_session = PromptSession(
            history=InMemoryHistory(),
            key_bindings=bindings,
            multiline=False,  # single-line by default; paste auto-expands
        )
    except Exception:
        _pt_session = None
    return _pt_session


_pt_session = None


def print_user_prompt(cwd: str) -> str:
    """Display the prompt and collect user input.

    Supports multiline input:
      - Paste multi-line text directly — all lines are captured automatically.
      - Press Alt+Enter (Escape then Enter) to insert a newline manually.
      - End a line with \\ (backslash) for manual line continuation.
    """
    cwd = cwd or os.path.basename(os.getcwd()) or os.getcwd()
    branch = _git_branch()
    model_short = _short_model_name(_current_model)

    top = Text()
    top.append("┌ ", style=_MUTED)
    top.append(cwd, style="bold green")
    if branch:
        top.append(" · ", style=_MUTED)
        top.append(branch, style="yellow")
    if model_short:
        top.append(" · ", style=_MUTED)
        top.append(model_short, style="magenta")
    # Adaptive thinking indicator
    top.append(" · ", style=_MUTED)
    if _adaptive_enabled:
        top.append("🧠 adaptive", style="dim magenta")
    else:
        top.append("think:off", style="dim")

    console.print(top)

    # Try prompt_toolkit for proper multiline/paste support
    pt = _get_prompt_session()
    if pt is not None:
        try:
            text = pt.prompt("└ ❯ ")
            # Strip trailing backslash continuations if user typed them
            if "\\" in text:
                lines = text.split("\n")
                result_lines = []
                for line in lines:
                    if line.endswith("\\"):
                        result_lines.append(line[:-1])
                    else:
                        result_lines.append(line)
                        break
                # If all lines ended with \, just strip the last backslash
                if len(result_lines) < len(lines):
                    result_lines.extend(lines[len(result_lines):])
                text = "\n".join(result_lines)
            return text
        except KeyboardInterrupt:
            raise
        except EOFError:
            raise
        except Exception:
            pass  # Fall through to input() fallback

    # Fallback: plain input() with backslash continuation
    first_line = input("└ ❯ ")
    if not first_line.endswith("\\"):
        return first_line

    lines = [first_line[:-1]]
    while True:
        try:
            next_line = input("  … ")
        except (KeyboardInterrupt, EOFError):
            break
        if next_line.endswith("\\"):
            lines.append(next_line[:-1])
        else:
            lines.append(next_line)
            break
    return "\n".join(lines)


def print_goodbye() -> None:
    console.print("\n[cyan]👋 Goodbye![/cyan]")


def _group_prefix() -> str:
    return "│   " if _tool_group_open else ""


def print_success(message: str) -> None:
    console.print(f"{_group_prefix()}[green]✓[/green] {message}")


def print_info(message: str) -> None:
    console.print(f"{_group_prefix()}[cyan]ℹ[/cyan] {message}")


def print_warning(message: str) -> None:
    console.print(f"{_group_prefix()}[yellow]⚠[/yellow] {message}")


def print_error(message: str) -> None:
    console.print(f"{_group_prefix()}[red]✗[/red] {message}")


def print_interrupted() -> None:
    console.print("\n[yellow]Interrupted. Input was cancelled.[/yellow]")


def print_summarizing() -> None:
    console.print("[cyan]Summarizing final answer...[/cyan]")


def print_plan(plan_text: str) -> None:
    console.print(Panel.fit(plan_text, title="Plan", border_style="cyan", box=box.ROUNDED))


def print_thinking_status(budget: int) -> None:
    state = f"🧠 Extended thinking enabled ({budget:,} tokens)"
    console.print(f"[magenta]{state}[/magenta]")


def _models_table(models: Dict[str, str], current_model: str) -> Table:
    table = Table(title="Models", box=box.ROUNDED, header_style="bold cyan", border_style=_BORDER, padding=(0, 2))
    table.add_column("Key", style="yellow")
    table.add_column("Model", style="white")
    table.add_column("Current", style="green", justify="center")
    for key, model in models.items():
        marker = "✓" if model == current_model or key == current_model else ""
        table.add_row(key, model, marker)
    return table


def print_models_table(models: Dict[str, str], current_model: str) -> None:
    console.print()
    console.print(_models_table(models, current_model))
    console.print("[dim]Switch in chat with:[/dim] [cyan]/model opus4[/cyan] [dim]or[/dim] [cyan]model claude-opus-4-6[/cyan]")
    console.print("[dim]Tip:[/dim] you can use either a short key ([cyan]opus4[/cyan], [cyan]sonnet4[/cyan]) or the full model name.")
    console.print()


def print_tools_table(tools: Iterable[Dict]) -> None:
    table = Table(title="Available tools", box=box.ROUNDED, header_style="bold cyan", border_style=_BORDER, padding=(0, 2), show_edge=True)
    table.add_column("Type", style="cyan", no_wrap=True)
    table.add_column("Tool", style="yellow", no_wrap=True)
    table.add_column("Description", style="white")
    for tool in tools:
        desc = tool.get("description", "") if isinstance(tool, dict) else str(tool)
        name = tool.get("name", "?") if isinstance(tool, dict) else str(tool)
        ttype = "MCP" if name.startswith("mcp_") else "Built-in"
        table.add_row(ttype, name, desc)
    console.print()
    console.print(table)
    console.print()


def print_plugins_table(plugins: Dict[str, Dict]) -> None:
    table = Table(title="Plugins", box=box.ROUNDED, header_style="bold cyan", border_style=_BORDER, padding=(0, 2), show_edge=True)
    table.add_column("Plugin", style="yellow", no_wrap=True)
    table.add_column("Type", style="cyan", no_wrap=True)
    table.add_column("Command / URL", style="white")
    if not plugins:
        console.print("[yellow]No plugins discovered[/yellow]")
        return
    for name, cfg in sorted(plugins.items()):
        transport = cfg.get("type", "stdio")
        location = cfg.get("command") or cfg.get("url") or ""
        table.add_row(name, transport, _fit(str(location), max(24, _terminal_width() - 42)))
    console.print()
    console.print(table)
    console.print()


def print_help() -> None:
    sections = [
        ("💬 Core chat", [
            ("/help", "Open this command guide", "/help"),
            ("/quit", "Exit the chat session", "/quit"),
            ("/clear", "Clear the current conversation", "/clear"),
            ("(multiline)", r"End a line with \ to continue on the next line", r"write a poem\↵about the sea↵"),
            ("/paste", r"Enter paste mode — paste multi-line text, end with . (dot)", "/paste"),
            ("/model [key|name]", "Show models or switch model immediately", "/model opus4"),
            ("model [key|name]", "Shortcut without the leading slash", "model claude-opus-4-6"),
            ("/system [text]", "Replace the active system prompt", "/system Be concise"),
            ("/think [off|budget]", "Enable or tune extended thinking manually", "/think 4000"),
            ("/adaptive [on|off|status]", "Auto-select thinking budget by query complexity", "/adaptive on"),
        ]),
        ("🔧 Tools & plugins", [
            ("/tools", "List built-in and MCP tools", "/tools"),
            ("/plugins", "List discoverable plugins", "/plugins"),
            ("/plugin <name>", "Load one plugin into the current chat", "/plugin playwright"),
            ("/mcp <name> <cmd>", "Register a custom stdio MCP server", "/mcp local node server.js"),
        ]),
        ("📁 Project workflow", [
            ("/search <query>", "Search the current project", "/search auth token --glob *.py"),
            ("/index [--force]", "Index the project for faster search", "/index --force"),
            ("/cd <path>", "Change working directory", "/cd ~/work/my-app"),
            ("!<command>", "Run one shell command directly", "!pytest -q"),
        ]),
        ("🧠 Planning & team", [
            ("/plan ...", "Manage a manual execution plan", "/plan new ship release"),
            ("/autoplan <goal>", "Generate a plan from a goal", "/autoplan refactor auth flow"),
            ("/teammate roles", "List teammate roles and what each one is for", "/teammate roles"),
            ("/teammate add <role> [name]", "Create one specialist AI teammate", "/teammate add debugger"),
            ("/teammate ask <role> <question>", "Ask one teammate directly inside chat", "/teammate ask architect how should we split auth?"),
            ("/teammate delegate <role> <task>", "Dispatch one async task to a teammate", "/teammate delegate debugger investigate MCP timeout"),
            ("/teammate list", "Show teammates and their live status", "/teammate list"),
            ("/teammate remove <name>", "Remove an idle teammate from the session", "/teammate remove debugger_1"),
            ("/tasks [status]", "List tasks by status (active, all, done, failed...)", "/tasks active"),
            ("/task <id>", "Open full detail for one task", "/task task_114200_123456"),
            ("/task result <id>", "Show only the stored task output", "/task result task_114200_123456"),
        ]),
        ("💾 Session & memory", [
            ("/save [json|session]", "Export or save the conversation", "/save session"),
            ("/resume [id]", "Resume a checkpoint or saved session", "/resume 20260327-101530"),
            ("/sessions", "List saved sessions", "/sessions"),
            ("/memory ...", "Store and recall long-term notes", "/memory set repo main-app"),
        ]),
        ("📊 Diagnostics", [
            ("/usage", "Show token usage and rate limits", "/usage"),
            ("/config", "Show effective runtime config", "/config"),
        ]),
    ]
    intro = Group(
        Text("Use slash commands to control the agent without leaving chat.", style="white"),
        Text("Model switching is available directly inside chat: /model opus4 or model sonnet4", style="dim cyan"),
        Text("Teammates are role-based AI specialists you can add, inspect, and delegate focused tasks to.", style="dim cyan"),
    )
    tables = [_help_table(title, rows) for title, rows in sections]
    teammate_note = Group(
        Text("Teammate roles:", style="bold white"),
        Text("code_reviewer, test_writer, docs_writer, debugger, refactorer, architect, security_auditor", style="dim cyan"),
        Text("Typical flow: /teammate add debugger → /teammate ask debugger what is the likely root cause? → /teammate delegate debugger investigate failing auth refresh", style="dim"),
        Text("Track work with /tasks active, inspect one item with /task <id>, and read final output with /task result <id>.", style="dim"),
    )
    footer = Text.assemble(
        ("Quick start: ", _MUTED),
        ("/model sonnet4", "cyan"), (" · ", _MUTED),
        ("/tools", "cyan"), (" · ", _MUTED),
        ("/search auth token --glob *.py", "cyan"), (" · ", _MUTED),
        ("/save session", "cyan"),
    )
    console.print()
    console.print(Panel(Group(intro, *tables, teammate_note, footer), title="[bold cyan]Help[/bold cyan]", border_style="cyan", box=box.ROUNDED, padding=(0, 1)))
    console.print()
