"""Advanced search & indexing for large codebases using ripgrep."""

import hashlib
import json
import os
import sqlite3
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional


def _time_now() -> float:
    return time.time()


@dataclass
class SearchResult:
    """Result from a search query."""
    file_path: str
    line_num: int
    column: int
    matched_text: str
    context_before: str = ""
    context_after: str = ""

    def __str__(self) -> str:
        return f"{self.file_path}:{self.line_num}:{self.column}"


class ProjectIndexer:
    """Fast full-text search indexing for code projects."""

    def __init__(self, project_root: Path):
        self.project_root = Path(project_root)
        self.index_dir = self.project_root / ".free-claude" / "index"
        self.index_dir.mkdir(parents=True, exist_ok=True)
        self.db_path = self.index_dir / "files.db"
        self.metadata_path = self.index_dir / "metadata.json"
        self._init_db()

    def _init_db(self):
        """Initialize SQLite database for index storage."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY,
                    file_path TEXT UNIQUE,
                    file_hash TEXT,
                    file_size INTEGER,
                    indexed_at REAL,
                    language TEXT
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS file_lines (
                    id INTEGER PRIMARY KEY,
                    file_id INTEGER,
                    line_num INTEGER,
                    content TEXT,
                    FOREIGN KEY (file_id) REFERENCES files(id)
                )
                """
            )
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_file_lines 
                ON file_lines(file_id, line_num)
                """
            )
            conn.commit()

    def get_stats(self) -> Dict:
        """Get indexing statistics."""
        with sqlite3.connect(self.db_path) as conn:
            file_count = conn.execute(
                "SELECT COUNT(*) FROM files"
            ).fetchone()[0]
            line_count = conn.execute(
                "SELECT COUNT(*) FROM file_lines"
            ).fetchone()[0]
        return {
            "indexed_files": file_count,
            "indexed_lines": line_count,
            "index_size_mb": self.db_path.stat().st_size / (1024 * 1024),
        }

    def _search_with_ripgrep(
        self, query: str, file_pattern: Optional[str], max_results: int
    ) -> List[SearchResult]:
        """Search using ripgrep (fast path)."""
        results = []
        cmd = ["rg", "--json", "--max-count", str(max_results), "--context", "3"]
        if file_pattern:
            cmd.extend(["--glob", file_pattern])
        cmd.extend([query, str(self.project_root)])

        output = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if output.returncode not in (0, 1):  # 1 = no matches, still ok
            return results

        for line in output.stdout.strip().split("\n"):
            if not line:
                continue
            try:
                data = json.loads(line)
                if data.get("type") == "match":
                    match = data.get("data", {})
                    results.append(SearchResult(
                        file_path=match.get("path", {}).get("text", ""),
                        line_num=match.get("line_number", 0),
                        column=match.get("start", {}).get("byte", 0),
                        matched_text=match.get("lines", {}).get("text", "").strip(),
                    ))
            except json.JSONDecodeError:
                continue
        return results

    def _search_with_grep(
        self, query: str, file_pattern: Optional[str], max_results: int
    ) -> List[SearchResult]:
        """Fallback search using Python's built-in grep-like walk."""
        import re
        results = []
        try:
            pattern = re.compile(query, re.IGNORECASE)
        except re.error:
            pattern = re.compile(re.escape(query), re.IGNORECASE)

        extensions = None
        if file_pattern:
            # Convert glob like "*.py" to set of extensions
            ext = file_pattern.lstrip("*")
            extensions = {ext} if ext else None

        for root, dirs, files in os.walk(self.project_root):
            # Skip hidden dirs
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for fname in files:
                if extensions and not any(fname.endswith(e) for e in extensions):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, encoding="utf-8", errors="ignore") as f:
                        for line_num, line in enumerate(f, 1):
                            if pattern.search(line):
                                results.append(SearchResult(
                                    file_path=fpath,
                                    line_num=line_num,
                                    column=0,
                                    matched_text=line.rstrip(),
                                ))
                                if len(results) >= max_results:
                                    return results
                except Exception:
                    continue
        return results

    def search(
        self, query: str, file_pattern: Optional[str] = None, max_results: int = 100
    ) -> List[SearchResult]:
        """
        Search using ripgrep (fast) with Python fallback if rg not available.

        Args:
            query: Search pattern (regex or literal)
            file_pattern: Optional glob pattern for files (e.g., "*.py")
            max_results: Max results to return

        Returns:
            List of SearchResult objects
        """
        try:
            results = self._search_with_ripgrep(query, file_pattern, max_results)
        except FileNotFoundError:
            # ripgrep not installed — fall back to Python walk
            results = self._search_with_grep(query, file_pattern, max_results)
        except subprocess.TimeoutExpired:
            results = []

        return results[:max_results]

    def search_many(
        self,
        queries: List[str],
        file_pattern: Optional[str] = None,
        max_results_each: int = 50,
        max_workers: int = 4,
    ) -> Dict[str, List[SearchResult]]:
        """Search multiple patterns in parallel using a thread pool.

        Inspired by Claude-HFI parallel search pattern — each query runs
        concurrently so N queries take ~1x time instead of N×.

        Args:
            queries:          List of search patterns.
            file_pattern:     Optional glob (e.g. "*.py").
            max_results_each: Max hits per query.
            max_workers:      Thread-pool size (default 4 — I/O bound).

        Returns:
            Dict mapping query → list of SearchResult.
        """
        results: Dict[str, List[SearchResult]] = {}

        def _search_one(q: str) -> tuple:
            return q, self.search(q, file_pattern, max_results_each)

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {pool.submit(_search_one, q): q for q in queries}
            for fut in as_completed(futures):
                try:
                    q, hits = fut.result()
                    results[q] = hits
                except Exception:
                    results[futures[fut]] = []

        return results

    def search_files(self, pattern: str) -> List[str]:
        """
        Search for files matching a glob pattern.
        Falls back to os.walk if ripgrep is unavailable.

        Args:
            pattern: Glob pattern (e.g. "*.py")

        Returns:
            List of matching file paths
        """
        try:
            cmd = ["rg", "--files", "--glob", pattern, str(self.project_root)]
            output = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
            if output.returncode == 0:
                return [p for p in output.stdout.strip().split("\n") if p]
        except FileNotFoundError:
            # ripgrep not available — use pathlib glob
            ext = pattern.lstrip("*")
            return [
                str(p) for p in self.project_root.rglob(f"*{ext}")
                if not any(part.startswith(".") for part in p.parts)
            ]
        except subprocess.TimeoutExpired:
            pass
        return []

    def get_file_context(
        self, file_path: str, line_num: int, context_lines: int = 5
    ) -> Dict:
        """
        Get context around a specific line in a file.
        
        Args:
            file_path: Path to file
            line_num: Line number to get context for
            context_lines: How many lines before/after to include
        
        Returns:
            Dict with file content and context
        """
        full_path = self.project_root / file_path
        if not full_path.exists():
            return {}
        
        try:
            with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
                all_lines = f.readlines()
            
            start = max(0, line_num - context_lines - 1)
            end = min(len(all_lines), line_num + context_lines)
            
            return {
                "file": file_path,
                "line_num": line_num,
                "before": all_lines[start:line_num - 1],
                "target": all_lines[line_num - 1] if line_num - 1 < len(all_lines) else "",
                "after": all_lines[line_num:end],
            }
        except Exception:
            return {}

    def index_project(self, force: bool = False) -> Dict:
        """
        Create/update index of entire project.
        
        Args:
            force: Force re-indexing even if unchanged
        
        Returns:
            Stats about indexing operation
        """
        stats = {
            "files_indexed": 0,
            "files_skipped": 0,
            "lines_indexed": 0,
            "errors": [],
        }
        
        # Load metadata about last index
        metadata = self._load_metadata()
        
        # Get all Python/JavaScript/TypeScript files
        patterns = ["*.py", "*.js", "*.ts", "*.jsx", "*.tsx", "*.md"]
        
        with sqlite3.connect(self.db_path) as conn:
            for pattern in patterns:
                try:
                    cmd = [
                        "rg",
                        "--files",
                        "--glob", pattern,
                        str(self.project_root),
                    ]
                    output = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        timeout=30,
                    )
                    
                    if output.returncode == 0:
                        for file_path_str in output.stdout.strip().split("\n"):
                            if not file_path_str:
                                continue
                            
                            file_path = Path(file_path_str)
                            relative_path = file_path.relative_to(self.project_root)
                            
                            # Check if we should skip
                            if not force:
                                file_hash = self._hash_file(file_path)
                                existing = conn.execute(
                                    "SELECT file_hash FROM files WHERE file_path = ?",
                                    (str(relative_path),),
                                ).fetchone()
                                
                                if existing and existing[0] == file_hash:
                                    stats["files_skipped"] += 1
                                    continue
                            
                            # Index the file
                            try:
                                self._index_file(conn, file_path, relative_path)
                                stats["files_indexed"] += 1
                            except Exception as e:
                                stats["errors"].append(f"{relative_path}: {str(e)}")
                
                except subprocess.TimeoutExpired:
                    stats["errors"].append(f"Timeout searching pattern: {pattern}")
            
            conn.commit()
        
        self._save_metadata(metadata)
        return stats

    def _index_file(self, conn: sqlite3.Connection, file_path: Path, relative_path: Path):
        """Index a single file into the database."""
        file_hash = self._hash_file(file_path)
        file_size = file_path.stat().st_size
        
        # Delete existing entry
        conn.execute("DELETE FROM files WHERE file_path = ?", (str(relative_path),))
        
        # Insert new entry
        cursor = conn.execute(
            """
            INSERT INTO files (file_path, file_hash, file_size, indexed_at, language)
            VALUES (?, ?, ?, ?, ?)
            """,
            (str(relative_path), file_hash, file_size, _time_now(), self._detect_language(relative_path)),
        )
        file_id = cursor.lastrowid
        
        # Index lines
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                for line_num, content in enumerate(f, start=1):
                    conn.execute(
                        """
                        INSERT INTO file_lines (file_id, line_num, content)
                        VALUES (?, ?, ?)
                        """,
                        (file_id, line_num, content.rstrip()),
                    )
        except Exception:
            pass

    @staticmethod
    def _hash_file(file_path: Path) -> str:
        """Compute SHA256 hash of file content."""
        hasher = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(8192), b""):
                    hasher.update(chunk)
        except Exception:
            pass
        return hasher.hexdigest()

    @staticmethod
    def _detect_language(file_path: Path) -> str:
        """Detect programming language from file extension."""
        ext = file_path.suffix.lower()
        lang_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".jsx": "jsx",
            ".tsx": "tsx",
            ".md": "markdown",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
        }
        return lang_map.get(ext, "unknown")

    def _load_metadata(self) -> Dict:
        """Load indexing metadata."""
        if self.metadata_path.exists():
            try:
                with open(self.metadata_path, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def _save_metadata(self, metadata: Dict):
        """Save indexing metadata."""
        try:
            with open(self.metadata_path, "w") as f:
                json.dump(metadata, f, indent=2)
        except Exception:
            pass


__all__ = ["ProjectIndexer", "SearchResult"]
