"""CLI entry point for free-claude."""
import argparse
import os
import sys

from . import __version__
from .config import MODELS
from .mcp import create_mcp_client, discover_hfi_plugins, list_hfi_plugins


def main():
    # Handle 'fclaude token ...' as a subcommand (before argparse)
    import sys as _sys
    if len(_sys.argv) >= 2 and _sys.argv[1] == "token":
        token_cmd()
        return

    parser = argparse.ArgumentParser(
        prog="fclaude",
        description="free-claude: Free Claude AI agent with tools and MCP support",
    )
    parser.add_argument("--version", action="version", version=f"free-claude {__version__}")
    parser.add_argument("-m", "--model", default="default", choices=list(MODELS.keys()),
                        help="Model to use (default: opus4 = claude-opus-4-6)")
    parser.add_argument("-q", "--query", help="Single query (non-interactive mode)")
    parser.add_argument("-s", "--system", help="System prompt")
    parser.add_argument("--mcp", nargs="+", action="append", metavar="ARG",
                        help="Add MCP server: --mcp name command [args...]")
    parser.add_argument("--plugin", action="append", nargs="+", metavar="NAME",
                        help="Enable plugin(s) by name (e.g. --plugin context7 playwright serena)")
    parser.add_argument("--plugins", action="store_true",
                        help="List available claude-hfi plugins and exit")
    parser.add_argument("--cwd", help="Set working directory")
    parser.add_argument("--no-tools", action="store_true", help="Disable built-in tools")
    parser.add_argument("--no-auto-plugins", action="store_true",
                        help="Disable auto-loading of claude-hfi plugins")
    parser.add_argument("--think", action="store_true",
                        help="Enable extended thinking (default budget: 8000 tokens)")
    parser.add_argument("--think-budget", type=int, default=0, metavar="N",
                        help="Extended thinking token budget (enables thinking if > 0)")

    args = parser.parse_args()

    if args.cwd:
        os.chdir(args.cwd)

    # List plugins and exit
    if args.plugins:
        print("\n🔌 Available claude-hfi plugins:")
        list_hfi_plugins()
        print("\nUsage: fclaude --plugin <name>")
        return

    # Parse manual MCP servers
    mcp_servers = {}
    if args.mcp:
        for mcp_args in args.mcp:
            if len(mcp_args) >= 2:
                mcp_servers[mcp_args[0]] = mcp_args[1:]

    # ── Load MCP plugins ─────────────────────────────────────────────────
    # BUG3 FIX: No auto-loading by default — avoids 5-15s startup delay.
    # Use --plugin <name> to explicitly enable plugins you need.
    _DEFAULT_PLUGINS = []  # empty: no auto-loading on startup

    # Flatten --plugin args: [[name1, name2], [name3]] → [name1, name2, name3]
    explicit_plugins = []
    if args.plugin:
        explicit_plugins = [name for group in args.plugin for name in group]

    # --no-auto-plugins: skip defaults, only load explicitly requested ones
    if args.no_auto_plugins:
        plugin_names_to_load = explicit_plugins
    else:
        # Merge: explicit overrides default (dedup, explicit wins order)
        plugin_names_to_load = list(dict.fromkeys(explicit_plugins or _DEFAULT_PLUGINS))

    hfi_plugin_clients = []
    available = discover_hfi_plugins()

    # Filter available candidates
    to_load = [n for n in plugin_names_to_load if n in available]
    not_found = [n for n in plugin_names_to_load if n not in available]
    for n in not_found:
        print(f"  ❌ Plugin '{n}' not found. Run: fclaude --plugins")

    if to_load:
        import shutil
        import threading
        import time as _time

        from rich.console import Console as _Console
        from rich.text import Text as _Text
        _con = _Console(highlight=False)

        # Filter out plugins whose command isn't installed
        runnable = []
        for name in to_load:
            cfg = available[name]
            transport = cfg.get("type", "stdio")
            cmd = cfg.get("command", "")
            from .compat import resolve_command
            if transport == "stdio" and cmd and not shutil.which(resolve_command(cmd)):
                _con.print(_Text.assemble(
                    ("  ⚠ ", "yellow"), (f"{name}", "bold"),
                    (f": command '{cmd}' not found", "dim"),
                ))
            else:
                runnable.append((name, cfg))

        if runnable:
            results_lock = threading.Lock()
            loaded = []  # list of (name, client, n_tools)
            failed = []  # list of (name, reason)

            def _connect_one(plugin_name, cfg):
                try:
                    client = create_mcp_client(plugin_name, cfg)
                    ok = client.start(verbose=False)
                    with results_lock:
                        if ok:
                            loaded.append((plugin_name, client, len(client.tools)))
                        else:
                            # BUG7 FIX: distinguish timeout vs other failure
                            failed.append((plugin_name, "timed out or failed to start"))
                except Exception as ex:
                    with results_lock:
                        failed.append((plugin_name, str(ex)))

            workers = [
                threading.Thread(target=_connect_one, args=(n, c), daemon=True)
                for n, c in runnable
            ]
            for w in workers:
                w.start()

            # BUG1+2 FIX: Use 60s timeout (first-run npx download needs 30-60s)
            # npx caches packages after first run; subsequent starts are <5s.
            _CONNECT_TIMEOUT = 60.0
            names_str = ", ".join(n for n, _ in runnable)
            with _con.status(
                _Text.assemble(
                    ("  🔌 ", "dim"),
                    ("Connecting MCP: ", "dim cyan"),
                    (names_str, "cyan"),
                    ("...", "dim"),
                ),
                spinner="dots",
            ):
                deadline = _time.monotonic() + _CONNECT_TIMEOUT
                while any(w.is_alive() for w in workers):
                    if _time.monotonic() > deadline:
                        break
                    _time.sleep(0.05)
            for w in workers:
                w.join(timeout=0.1)

            # Report results
            for name, client, n_tools in loaded:
                _con.print(_Text.assemble(
                    ("  ✓ ", "bold green"),
                    (f"{name}", "bold"),
                    (f" {n_tools} tools", "green"),
                ))
                hfi_plugin_clients.append(client)
            for name, reason in failed:
                _con.print(_Text.assemble(
                    ("  ✗ ", "bold red"),
                    (name, "dim"),
                    (f" — {reason}", "dim red"),
                ))

    # BUG3 hint: suggest --plugin if no plugins loaded and none requested
    elif not explicit_plugins and not args.no_auto_plugins and not mcp_servers:
        pass  # quiet startup — no hint spam

    try:
        from .agent import Agent
        from .core.streaming import DEFAULT_THINKING_BUDGET

        # Resolve thinking budget
        thinking_budget = 0
        if args.think_budget > 0:
            thinking_budget = args.think_budget
        elif args.think:
            thinking_budget = DEFAULT_THINKING_BUDGET

        agent = Agent(
            model=args.model,
            system=args.system,
            mcp_servers=mcp_servers or None,
            mcp_clients=hfi_plugin_clients or None,
            auto_plugins=not args.no_auto_plugins,
            thinking_budget=thinking_budget,
        )

        if args.query:
            # Single query: stream trực tiếp ra stdout
            agent.run(args.query, stream=True)
        else:
            agent.chat()

    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
        sys.exit(0)
    except SystemExit:
        raise
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        sys.exit(1)


def token_cmd():
    """fclaude token <subcommand> — manage your HFI API token.

    Subcommands:
      set <token>   Save token to config file (persists across sessions)
      show          Display masked token and source
      clear         Remove saved token file
      check         Verify token is valid by making a test API call
      env           Print shell export command for current platform
    """
    import sys
    args = sys.argv[2:]  # skip 'fclaude' and 'token'
    subcmd = args[0] if args else "show"

    from .auth import TOKEN_ENV_VAR, get_token, set_token, show_token
    from .config import TOKEN_FILE

    if subcmd == "set":
        if len(args) < 2:
            # Try reading from stdin (piped input)
            if not sys.stdin.isatty():
                token = sys.stdin.read().strip()
            else:
                print("Usage: fclaude token set <your_token>")
                print("       echo <token> | fclaude token set")
                sys.exit(1)
        else:
            token = args[1]
        try:
            set_token(token)
            masked = token[:8] + "..." + token[-4:] if len(token) > 12 else token[:4] + "..."
            print(f"✅ Token saved: {masked}")
            print(f"   File: {TOKEN_FILE}")
            print("   Run 'fclaude' to start chatting!")
        except ValueError as e:
            print(f"❌ {e}")
            sys.exit(1)

    elif subcmd == "show":
        masked, source = show_token()
        if masked:
            print(f"✅ Token:  {masked}")
            print(f"   Source: {source}")
            if source == "env var":
                print(f"   Var:    {TOKEN_ENV_VAR}")
            else:
                print(f"   File:   {TOKEN_FILE}")
        else:
            print("❌ No token found.")
            _print_token_help()
            sys.exit(1)

    elif subcmd == "clear":
        from .auth import clear_token as _clear
        if _clear():
            print(f"✅ Token file removed: {TOKEN_FILE}")
        else:
            print(f"ℹ  No token file found at {TOKEN_FILE}")
        env_token = __import__("os").environ.get(TOKEN_ENV_VAR)
        if env_token:
            print(f"⚠  {TOKEN_ENV_VAR} env var is still set in this shell.")
            print(f"   Unset it with: unset {TOKEN_ENV_VAR}  (Linux/Mac)")
            print(f"                  Remove-Item Env:{TOKEN_ENV_VAR}  (PowerShell)")

    elif subcmd == "check":
        import json as _json
        import urllib.error
        import urllib.request
        token = get_token()
        from .config import API_BASE
        masked = token[:8] + "..." + token[-4:] if len(token) > 12 else "***"
        print(f"🔍 Checking token: {masked}")
        try:
            req = urllib.request.Request(
                f"{API_BASE}/v1/messages",
                data=_json.dumps({
                    "model": "claude-haiku-4-5",
                    "max_tokens": 10,
                    "messages": [{"role": "user", "content": "hi"}],
                }).encode(),
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                _json.loads(resp.read())
            print("✅ Token is valid! API connection successful.")
        except urllib.error.HTTPError as e:
            if e.code == 401:
                print("❌ Token is INVALID (401 Unauthorized)")
                print("   Get a new token and run: fclaude token set <token>")
            elif e.code == 429:
                print("⚠  Token valid but rate limited (429) — try again later.")
            else:
                print(f"⚠  API returned HTTP {e.code} — token may still be valid.")
        except Exception as e:
            print(f"❌ Connection error: {e}")
            sys.exit(1)

    elif subcmd == "env":
        token = get_token()
        masked = token[:8] + "..." + token[-4:] if len(token) > 12 else "***"
        print(f"# Token: {masked}")
        print("# Add ONE of these to your shell profile:\n")
        print("# Linux/Mac (~/.bashrc or ~/.zshrc):")
        print(f'export {TOKEN_ENV_VAR}="{token}"\n')
        print("# Windows PowerShell ($PROFILE):")
        print(f'$Env:{TOKEN_ENV_VAR} = "{token}"\n')
        print("# Windows CMD:")
        print(f'setx {TOKEN_ENV_VAR} "{token}"')

    else:
        print(f"❌ Unknown subcommand: '{subcmd}'")
        print("Usage: fclaude token [set|show|clear|check|env]")
        sys.exit(1)


def _print_token_help():
    """Print token setup instructions for all platforms."""
    print()
    print("How to set your token:")
    print()
    print("  Method 1 — Save permanently (recommended):")
    print("    fclaude token set <your_token>")
    print()
    print("  Method 2 — Env var (CI/CD, Docker, scripts):")
    print("    Linux/Mac:  export FREE_CLAUDE_TOKEN=<token>")
    print("    PowerShell: $Env:FREE_CLAUDE_TOKEN = '<token>'")
    print("    CMD:        set FREE_CLAUDE_TOKEN=<token>")
    print()
    print("  Method 3 — OAuth browser login:")
    print("    fclaude-login")
    print()
    print("Get your token at: https://claude.ai/settings/keys")


def login_cmd():
    """fclaude-login command."""
    from .auth import is_logged_in, login, refresh_token

    print("🔐 free-claude Login")
    print("=" * 40)

    if is_logged_in():
        print("✅ Already logged in. Attempting to refresh token...")
        try:
            token = refresh_token()
            if token:
                print("✅ Token refreshed successfully!")
                print(f"   Token: {token[:30]}...")
                return
        except Exception as e:
            print(f"⚠️  Refresh failed: {e}")
        print("Starting fresh login...")

    try:
        token = login(open_browser=True)
        print("\n🎉 Login successful!")
        print(f"   Token: {token[:30]}...")
        print("\n💡 Now run: fclaude")
    except KeyboardInterrupt:
        print("\n❌ Login cancelled")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Login failed: {e}")
        sys.exit(1)
