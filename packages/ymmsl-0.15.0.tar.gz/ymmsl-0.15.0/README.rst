.. image:: https://readthedocs.org/projects/ymmsl-python/badge/?version=master
    :target: https://ymmsl-python.readthedocs.io/en/latest/?badge=master
    :alt: Documentation Build Status

.. image:: https://github.com/multiscale/ymmsl-python/workflows/continuous_integration/badge.svg
    :target: https://github.com/multiscale/ymmsl-python/actions
    :alt: Build Status

.. image:: https://app.codacy.com/project/badge/Grade/e8be82b26b1e44e19374a65a35c193bf
    :target: https://www.codacy.com/gh/multiscale/ymmsl-python/dashboard
    :alt: Codacy Grade

.. image:: https://app.codacy.com/project/badge/Coverage/e8be82b26b1e44e19374a65a35c193bf
    :target: https://www.codacy.com/gh/multiscale/ymmsl-python/dashboard
    :alt: Test Coverage

.. image:: https://zenodo.org/badge/153272345.svg
   :target: https://zenodo.org/badge/latestdoi/153272345

################################################################################
yMMSL Python bindings
################################################################################

Python bindings for the YAML version of the Multiscale Modeling and Simulation
Language.

This package provides a Python library for reading and writing yMMSL files.
These files describe multiscale models and/or parameter settings for
running such a model. This library is based on
`YAtiML <https://yatiml.rtd.io>`_, a Python library for making libraries for
YAML-based file formats like this one.

Documentation
*************

This is an ordinary Python library that can be installed via pip. It requires
Python 3.7 or higher. More information is available in the `online
documentation for ymmsl-python <https://ymmsl-python.readthedocs.io>`_.

Development
***********

This library is developed in `its public GitHub repository
<https://github.com/multiscale/ymmsl-python>`_. If you run into a problem or
something is unclear, please file an issue.

Legal
*****

ymmsl_python is Copyright 2018-2023 Netherlands eScience Center and University
of Amsterdam, Copyright 2022-2023, 2026 The ITER Organisation, and Copyright
2024-2026 Netherlands eScience Center. Licensed under the Apache 2.0 license.

