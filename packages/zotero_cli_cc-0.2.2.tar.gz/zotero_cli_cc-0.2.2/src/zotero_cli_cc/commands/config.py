from __future__ import annotations

import re
from pathlib import Path

import click

from zotero_cli_cc.config import (
    CONFIG_FILE,
    AppConfig,
    detect_zotero_data_dir,
    get_default_profile,
    list_profiles,
    load_config,
    save_config,
)


@click.group("config")
def config_group() -> None:
    """Manage zot configuration."""
    pass


@config_group.command("init")
@click.option("--config-path", type=click.Path(), default=None, help="Config file path")
@click.option("--data-dir", "data_dir", default=None, help="Zotero data directory (auto-detected if not set)")
@click.option("--library-id", default=None, help="Zotero library ID")
@click.option("--api-key", default=None, help="Zotero API key")
@click.pass_context
def config_init(
    ctx: click.Context,
    config_path: str | None,
    data_dir: str | None,
    library_id: str | None,
    api_key: str | None,
) -> None:
    """Initialize configuration interactively."""
    path = Path(config_path) if config_path else CONFIG_FILE
    no_interaction = ctx.obj.get("no_interaction", False) if ctx.obj else False

    detected_dir = detect_zotero_data_dir(AppConfig())

    if no_interaction:
        library_id = library_id or ""
        api_key = api_key or ""
        data_dir = data_dir or str(detected_dir)
    else:
        library_id = library_id or click.prompt("Zotero library ID", default="")
        api_key = api_key or click.prompt("Zotero API key", default="")
        if data_dir is None:
            data_dir = click.prompt(
                "Zotero data directory",
                default=str(detected_dir),
            )

    # Normalize path (resolve ~, convert to absolute) to avoid Windows backslash issues
    if data_dir:
        data_dir = str(Path(data_dir).expanduser().resolve())

    cfg = AppConfig(
        data_dir=data_dir or "",
        library_id=library_id or "",
        api_key=api_key or "",
    )
    save_config(cfg, path)
    click.echo(f"Configuration saved to {path}")
    click.echo(f"  Data directory: {cfg.data_dir or '(auto-detect)'}")

    # Validate the data directory
    if cfg.data_dir:
        dd = Path(cfg.data_dir)
        if not dd.exists():
            click.echo(click.style(f"  WARNING: Directory does not exist: {dd}", fg="yellow"))
        elif not (dd / "zotero.sqlite").exists():
            click.echo(click.style(f"  WARNING: zotero.sqlite not found in {dd}", fg="yellow"))


@config_group.command("show")
@click.option("--config-path", type=click.Path(), default=None, help="Config file path")
def config_show(config_path: str | None) -> None:
    """Show current configuration."""
    from zotero_cli_cc.config import get_data_dir

    path = Path(config_path) if config_path else CONFIG_FILE
    cfg = load_config(path)
    click.echo(f"Library ID: {cfg.library_id}")
    click.echo(f"API Key:    {'***' + cfg.api_key[-4:] if len(cfg.api_key) > 4 else '(not set)'}")
    click.echo(f"Data Dir:   {cfg.data_dir or '(auto-detect)'}")
    click.echo(f"Format:     {cfg.default_format}")
    click.echo(f"Limit:      {cfg.default_limit}")
    click.echo(f"Export:     {cfg.default_export_style}")

    # Path validation
    data_dir = get_data_dir(cfg)
    db_file = data_dir / "zotero.sqlite"
    if not data_dir.exists():
        click.echo(click.style(f"\nWARNING: Data directory not found: {data_dir}", fg="yellow"))
    elif not db_file.exists():
        click.echo(click.style(f"\nWARNING: zotero.sqlite not found in {data_dir}", fg="yellow"))
    else:
        click.echo(click.style(f"\nDatabase:   {db_file} (OK)", fg="green"))


@config_group.group("profile")
def profile_group() -> None:
    """Manage configuration profiles."""
    pass


@profile_group.command("list")
@click.option("--config-path", type=click.Path(), default=None)
def profile_list(config_path: str | None) -> None:
    """List all profiles."""
    path = Path(config_path) if config_path else CONFIG_FILE
    profiles = list_profiles(path)
    default = get_default_profile(path)
    if not profiles:
        click.echo("No profiles configured.")
        return
    for p in profiles:
        marker = " (default)" if p == default else ""
        click.echo(f"  {p}{marker}")


@config_group.group("cache")
def cache_group() -> None:
    """Manage PDF text cache."""
    pass


@cache_group.command("clear")
def cache_clear() -> None:
    """Clear the PDF text cache."""
    from zotero_cli_cc.core.pdf_cache import PdfCache

    cache = PdfCache()
    stats = cache.stats()
    cache.clear()
    cache.close()
    click.echo(f"Cache cleared. Removed {stats['entries']} entries.")


@cache_group.command("stats")
def cache_stats() -> None:
    """Show PDF cache statistics."""
    from zotero_cli_cc.core.pdf_cache import PdfCache

    cache = PdfCache()
    stats = cache.stats()
    cache.close()
    click.echo(f"Cached PDFs: {stats['entries']}")
    click.echo(f"Total chars: {stats['total_chars']:,}")


@profile_group.command("set")
@click.argument("name")
@click.option("--config-path", type=click.Path(), default=None)
def profile_set(name: str, config_path: str | None) -> None:
    """Set the default profile."""
    path = Path(config_path) if config_path else CONFIG_FILE
    from zotero_cli_cc.formatter import format_error
    from zotero_cli_cc.models import ErrorInfo

    profiles = list_profiles(path)
    if name not in profiles:
        click.echo(
            format_error(
                ErrorInfo(
                    message=f"Profile '{name}' not found",
                    context="config",
                    hint=f"Available profiles: {', '.join(profiles)}",
                )
            )
        )
        return
    content = path.read_text()
    if "[default]" in content:
        content = re.sub(r'(profile\s*=\s*)"[^"]*"', f'\\1"{name}"', content)
    else:
        content = f'[default]\nprofile = "{name}"\n\n' + content
    path.write_text(content)
    click.echo(f"Default profile set to '{name}'.")
