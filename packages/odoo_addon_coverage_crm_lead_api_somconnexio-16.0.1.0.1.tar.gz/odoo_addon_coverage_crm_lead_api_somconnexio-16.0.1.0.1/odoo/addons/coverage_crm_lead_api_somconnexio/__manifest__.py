{
    "name": "Coverage CRM Lead API - SomConnexio",
    "version": "16.0.1.0.1",
    "summary": """
        Create CRM Lead via API with fiber coverages informed
        in a broadband CRM Line
    """,
    "description": """
       This module provides utility to create CRM Lead via API
    with fiber coverages informed in a broadband CRM Line.
    """,
    "author": "Coopdevs Treball SCCL, " "Som Connexió SCCL",
    "website": "https://coopdevs.org",
    "license": "AGPL-3",
    "category": "Cooperative management",
    "depends": ["crm_lead_api_somconnexio", "otrs_somconnexio"],
    "data": [],
    "demo": [],
    "external_dependencies": {"python": ["otrs_somconnexio"]},
    "application": False,
    "installable": True,
}
