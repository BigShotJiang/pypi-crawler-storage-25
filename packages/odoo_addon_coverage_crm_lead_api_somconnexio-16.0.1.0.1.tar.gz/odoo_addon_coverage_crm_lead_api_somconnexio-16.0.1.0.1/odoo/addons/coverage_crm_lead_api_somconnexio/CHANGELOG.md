# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.1] - 2026-05-11
### Added
- [#1718](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1718) Add coverage_crm_lead_api_somconnexio module
