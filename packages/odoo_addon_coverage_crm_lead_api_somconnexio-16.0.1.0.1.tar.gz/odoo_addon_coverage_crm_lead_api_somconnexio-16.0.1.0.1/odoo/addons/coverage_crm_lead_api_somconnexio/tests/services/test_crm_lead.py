import json
from odoo.addons.base_rest_somconnexio.tests.common_service import BaseRestCaseAdmin


class TestCRMLeadServiceRestCase(BaseRestCaseAdmin):
    def setUp(self):
        super().setUp()
        self.partner = self.env.ref("somconnexio.res_partner_1_demo")
        self.url = "/api/crm-lead"
        self.fiber_product = self.env.ref("somconnexio.Fibra600Mb")
        self.ba_data = {
            "partner_id": self.partner.ref,
            "iban": "ES6621000418401234567891",
            "phone": "700284835",
            "lead_line_ids": [
                {
                    "product_code": self.fiber_product.default_code,
                    "mobile_isp_info": {},
                    "broadband_isp_info": {
                        "type": "portability",
                        "delivery_address": {
                            "street": "123",
                            "zip_code": "08000",
                            "city": "Barcelona",
                            "country": "ES",
                            "state": "B",
                        },
                        "service_address": {
                            "street": "123",
                            "zip_code": "08000",
                            "city": "Barcelona",
                            "country": "ES",
                            "state": "B",
                        },
                        "previous_provider": 39,
                        "previous_service": "adsl",
                        "previous_owner_name": "Newus",
                        "previous_owner_first_name": "Borgo",
                        "previous_owner_vat_number": "29461336S",
                        "previous_contract_type": "contract",
                        "fiber_coverage": {"mm_fiber_coverage": "fibraFTTH"},
                    },
                }
            ],
        }

    def test_route_right_create_with_fiber_coverage(self):
        response = self.http_post(self.url, data=self.ba_data)

        self.assertEqual(response.status_code, 200)

        content = json.loads(response.content.decode("utf-8"))
        self.assertIn("id", content)

        crm_lead = self.env["crm.lead"].browse(content["id"])
        crm_lead_line = crm_lead.lead_line_ids[0]

        self.assertEqual(
            crm_lead_line.broadband_isp_info.mm_fiber_coverage, "fibraFTTH"
        )

    def test_route_right_create_with_extended_fiber_coverage(self):
        extended_ba_data = self.ba_data.copy()
        extended_ba_data["lead_line_ids"][0]["broadband_isp_info"][
            "fiber_coverage"
        ].update(
            {
                "gescal37": "GESCAL37_CODE",
                "territory_owner": "Territory Owner Name",
            }
        )
        response = self.http_post(self.url, data=extended_ba_data)

        self.assertEqual(response.status_code, 200)

        content = json.loads(response.content.decode("utf-8"))
        self.assertIn("id", content)

        crm_lead = self.env["crm.lead"].browse(content["id"])
        crm_lead_line = crm_lead.lead_line_ids[0]

        self.assertEqual(
            crm_lead_line.broadband_isp_info.mm_fiber_coverage, "fibraFTTH"
        )
        self.assertEqual(crm_lead_line.broadband_isp_info.gescal37, "GESCAL37_CODE")
        self.assertEqual(
            crm_lead_line.broadband_isp_info.territory_owner, "Territory Owner Name"
        )
