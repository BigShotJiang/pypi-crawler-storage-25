from . import schemas
from odoo.addons.component.core import Component


class CRMLeadService(Component):
    _inherit = "crm.lead.services"

    def _prepare_create_broadband_isp_info(self, isp_info, without_fix=False):
        isp_info = super()._prepare_create_broadband_isp_info(isp_info, without_fix)
        if "fiber_coverage" in isp_info.keys():
            for k, v in isp_info["fiber_coverage"].items():
                if v is not None:
                    isp_info[k] = v
            isp_info.pop("fiber_coverage")

        return isp_info

    def _validator_create(self):
        create_schema = super()._validator_create()
        create_schema["lead_line_ids"]["schema"]["schema"]["broadband_isp_info"][
            "schema"
        ].update(schemas.S_BROADBAND_COVERAGE_ISP_INFO_CREATE)
        return create_schema
