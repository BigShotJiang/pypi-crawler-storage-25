from otrs_somconnexio.otrs_models.coverage.mm_fiber import MMFiberCoverage
from otrs_somconnexio.otrs_models.coverage.vdf_fiber import VdfFiberCoverage
from otrs_somconnexio.otrs_models.coverage.asociatel_fiber import AsociatelFiberCoverage
from otrs_somconnexio.otrs_models.coverage.orange_fiber import OrangeFiberCoverage


def get_allowed_mm_fiber_coverages():
    return [key for key, _ in MMFiberCoverage.VALUES]


def get_allowed_vdf_fiber_coverages():
    return [key for key, _ in VdfFiberCoverage.VALUES]


def get_allowed_asociatel_fiber_coverages():
    return [key for key, _ in AsociatelFiberCoverage.VALUES]


def get_allowed_orange_fiber_coverages():
    return [key for key, _ in OrangeFiberCoverage.VALUES]


S_FIBER_COVERAGE = {
    "mm_fiber_coverage": {
        "type": "string",
        "excludes": [
            "vdf_fiber_coverage",
            "asociatel_fiber_coverage",
            "orange_fiber_coverage",
        ],
        "allowed": get_allowed_mm_fiber_coverages(),
        "required": True,
    },
    "vdf_fiber_coverage": {
        "type": "string",
        "excludes": [
            "mm_fiber_coverage",
            "asociatel_fiber_coverage",
            "orange_fiber_coverage",
        ],
        "allowed": get_allowed_vdf_fiber_coverages(),
        "required": True,
    },
    "asociatel_fiber_coverage": {
        "type": "string",
        "excludes": [
            "mm_fiber_coverage",
            "vdf_fiber_coverage",
            "orange_fiber_coverage",
        ],
        "allowed": get_allowed_asociatel_fiber_coverages(),
        "required": True,
    },
    "orange_fiber_coverage": {
        "type": "string",
        "excludes": [
            "mm_fiber_coverage",
            "vdf_fiber_coverage",
            "asociatel_fiber_coverage",
        ],
        "allowed": get_allowed_orange_fiber_coverages(),
        "required": True,
    },
    "gescal37": {"type": "string", "required": False},
    "territory_owner": {"type": "string", "required": False},
}

S_BROADBAND_COVERAGE_ISP_INFO_CREATE = {
    "fiber_coverage": {"type": "dict", "schema": S_FIBER_COVERAGE}
}
