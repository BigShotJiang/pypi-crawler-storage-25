from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from magscope.scripting import ScriptStatus
    from magscope.settings import MagScopeSettings
    from magscope.utils import AcquisitionMode


@dataclass(frozen=True)
class Command:
    """Typed IPC payload sent between processes."""


@dataclass(frozen=True)
class QuitCommand(Command):
    """Request that all manager processes exit."""


@dataclass(frozen=True)
class SetSettingsCommand(Command):
    settings: "MagScopeSettings"


@dataclass(frozen=True)
class UpdateSettingsCommand(Command):
    settings: "MagScopeSettings"


@dataclass(frozen=True)
class UpdateTrackingOptionsCommand(Command):
    value: dict


@dataclass(frozen=True)
class SetAcquisitionOnCommand(Command):
    value: bool


@dataclass(frozen=True)
class WaitUntilAcquisitionOnCommand(Command):
    value: bool


@dataclass(frozen=True)
class SetAcquisitionDirOnCommand(Command):
    value: bool


@dataclass(frozen=True)
class SetAcquisitionModeCommand(Command):
    mode: "AcquisitionMode"


@dataclass(frozen=True)
class SetAcquisitionDirCommand(Command):
    value: str | None


@dataclass(frozen=True)
class UpdateBeadRoisCommand(Command):
    pass


@dataclass(frozen=True)
class LogExceptionCommand(Command):
    process_name: str
    details: str


@dataclass(frozen=True)
class StartupReadyCommand(Command):
    process_name: str = "UIManager"


@dataclass(frozen=True)
class UpdateCameraSettingCommand(Command):
    name: str
    value: str


@dataclass(frozen=True)
class SetSimulatedFocusCommand(Command):
    offset: float


@dataclass(frozen=True)
class MoveFocusMotorAbsoluteCommand(Command):
    z: float


@dataclass(frozen=True)
class RequestFocusMotorLimitsCommand(Command):
    pass


@dataclass(frozen=True)
class ReportFocusMotorLimitsCommand(Command):
    z_min: float
    z_max: float


@dataclass(frozen=True)
class UpdateVideoBufferPurgeCommand(Command):
    t: float


@dataclass(frozen=True)
class MoveBeadsCommand(Command):
    moves: list[tuple[int, int, int]]


@dataclass(frozen=True)
class AddRandomBeadsCommand(Command):
    count: int
    seed: int | None = None


@dataclass(frozen=True)
class UpdateXYLockEnabledCommand(Command):
    value: bool


@dataclass(frozen=True)
class UpdateXYLockIntervalCommand(Command):
    value: float


@dataclass(frozen=True)
class UpdateXYLockMaxCommand(Command):
    value: float


@dataclass(frozen=True)
class UpdateXYLockWindowCommand(Command):
    value: int


@dataclass(frozen=True)
class UpdateZLockEnabledCommand(Command):
    value: bool


@dataclass(frozen=True)
class UpdateZLockBeadCommand(Command):
    value: int


@dataclass(frozen=True)
class UpdateZLockTargetCommand(Command):
    value: float


@dataclass(frozen=True)
class UpdateZLockIntervalCommand(Command):
    value: float


@dataclass(frozen=True)
class UpdateZLockMaxCommand(Command):
    value: float


@dataclass(frozen=True)
class UpdateZLockWindowCommand(Command):
    value: int


@dataclass(frozen=True)
class UpdateScriptStatusCommand(Command):
    status: "ScriptStatus"


@dataclass(frozen=True)
class UpdateScriptStepCommand(Command):
    """Report the currently executing script step to the GUI."""

    current_step: int | None
    total_steps: int
    description: str | None


@dataclass(frozen=True)
class ShowMessageCommand(Command):
    text: str
    details: str | None = None


@dataclass(frozen=True)
class ShowErrorCommand(Command):
    text: str
    details: str | None = None


@dataclass(frozen=True)
class UpdateZLUTMetadataCommand(Command):
    filepath: str | None = None
    z_min: float | None = None
    z_max: float | None = None
    step_size: float | None = None
    profile_length: int | None = None


@dataclass(frozen=True)
class LoadZLUTCommand(Command):
    filepath: str


@dataclass(frozen=True)
class UnloadZLUTCommand(Command):
    """Clear the currently loaded Z-LUT."""


@dataclass(frozen=True)
class StartZLUTGenerationCommand(Command):
    start_nm: float
    step_nm: float
    stop_nm: float
    profiles_per_bead: int


@dataclass(frozen=True)
class CancelZLUTGenerationCommand(Command):
    pass


@dataclass(frozen=True)
class UpdateZLUTGenerationStateCommand(Command):
    status: str
    detail: str | None = None
    running: bool = False
    can_cancel: bool = False
    phase: str = 'idle'
    z_axis_min_nm: float | None = None
    z_axis_max_nm: float | None = None
    z_axis_descending: bool = False


@dataclass(frozen=True)
class UpdateZLUTGenerationProgressCommand(Command):
    current_step: int
    total_steps: int
    capture_count: int
    capture_capacity: int
    motor_z_value: float | None = None


@dataclass(frozen=True)
class UpdateZLUTGenerationEvaluationCommand(Command):
    active: bool
    bead_ids: list[int]
    selected_bead_id: int | None = None


@dataclass(frozen=True)
class SelectGeneratedZLUTBeadCommand(Command):
    bead_id: int


@dataclass(frozen=True)
class SaveGeneratedZLUTCommand(Command):
    filepath: str
    bead_id: int
    load_after_save: bool = True


@dataclass(frozen=True)
class CancelGeneratedZLUTEvaluationCommand(Command):
    pass


@dataclass(frozen=True)
class RequestProfileLengthCommand(Command):
    pass


@dataclass(frozen=True)
class ReportProfileLengthCommand(Command):
    profile_length: int | None = None


@dataclass(frozen=True)
class RequestZLUTProfileLengthCommand(Command):
    bead_ids: tuple[int, ...] = ()
    bead_rois: tuple[tuple[int, int, int, int], ...] = ()


@dataclass(frozen=True)
class ReportZLUTProfileLengthCommand(Command):
    profile_length: int | None = None


@dataclass(frozen=True)
class ClearPendingZLUTProfileLengthCommand(Command):
    pass


@dataclass(frozen=True)
class ArmZLUTSweepCaptureCommand(Command):
    step_index: int
    motor_z_value: float
    remaining_profiles_per_bead: int
    earliest_timestamp: float
    bead_ids: tuple[int, ...] = ()
    bead_rois: tuple[tuple[int, int, int, int], ...] = ()


@dataclass(frozen=True)
class DisarmZLUTSweepCaptureCommand(Command):
    pass


@dataclass(frozen=True)
class ZLUTSweepCaptureCompleteCommand(Command):
    step_index: int
    written_count: int
    written_profiles_per_bead: int
    error: str | None = None


@dataclass(frozen=True)
class RemoveBeadFromPendingMovesCommand(Command):
    id: int


@dataclass(frozen=True)
class RemoveBeadsFromPendingMovesCommand(Command):
    ids: list[int]


@dataclass(frozen=True)
class SetXYLockOnCommand(Command):
    value: bool


@dataclass(frozen=True)
class ExecuteXYLockCommand(Command):
    now: float | None = None


@dataclass(frozen=True)
class SetXYLockIntervalCommand(Command):
    value: float


@dataclass(frozen=True)
class SetXYLockMaxCommand(Command):
    value: float


@dataclass(frozen=True)
class SetXYLockWindowCommand(Command):
    value: int


@dataclass(frozen=True)
class SetZLockOnCommand(Command):
    value: bool


@dataclass(frozen=True)
class SetZLockBeadCommand(Command):
    value: int


@dataclass(frozen=True)
class SetZLockTargetCommand(Command):
    value: float


@dataclass(frozen=True)
class SetZLockIntervalCommand(Command):
    value: float


@dataclass(frozen=True)
class SetZLockMaxCommand(Command):
    value: float


@dataclass(frozen=True)
class SetZLockWindowCommand(Command):
    value: int


@dataclass(frozen=True)
class GetCameraSettingCommand(Command):
    name: str


@dataclass(frozen=True)
class SetCameraSettingCommand(Command):
    name: str
    value: str


@dataclass(frozen=True)
class LoadScriptCommand(Command):
    path: str


@dataclass(frozen=True)
class StartScriptCommand(Command):
    """Start the currently loaded script."""


@dataclass(frozen=True)
class PauseScriptCommand(Command):
    """Pause the running script."""


@dataclass(frozen=True)
class ResumeScriptCommand(Command):
    """Resume a paused script."""


@dataclass(frozen=True)
class SleepCommand(Command):
    duration: float


@dataclass(frozen=True)
class UpdateWaitingCommand(Command):
    """Signal that a wait condition has been satisfied."""
