__version__ = "0.3.6"
APP_TITLE = "Adbnik"
