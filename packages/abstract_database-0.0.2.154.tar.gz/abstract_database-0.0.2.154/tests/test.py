from imports import *
POSTGRES_DSN = {
    "name":"ae_clients_db",
    "user":"ae_ext_rw",

}
conn_mgr = get_db_vars_from_kwargs(name='TDD_docs',user='putkoff')
env_values = derive_db_vars(name='TDD_docs',user='putkoff')
input(env_values)
input(conn_mgr)
