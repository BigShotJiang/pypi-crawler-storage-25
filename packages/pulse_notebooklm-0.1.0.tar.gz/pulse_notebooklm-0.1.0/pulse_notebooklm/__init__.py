"""
PULSE-NotebookLM Adapter.

Google NotebookLM via PULSE Protocol — notebooks, sources, chat, content generation.

Auth (first time only):
    from notebooklm.auth import login
    import asyncio
    asyncio.run(login())   # opens browser, saves session

Example:
    >>> import asyncio
    >>> from pulse_notebooklm import NotebookLMAdapter
    >>> from pulse.message import PulseMessage

    >>> async def main():
    ...     async with NotebookLMAdapter() as adapter:
    ...         resp = await adapter.send_async(PulseMessage(
    ...             action="ACT.CREATE.NOTEBOOK",
    ...             parameters={"title": "My Research"},
    ...         ))
    ...         print(resp.content["parameters"]["notebook_id"])

    >>> asyncio.run(main())
"""

from pulse_notebooklm.adapter import NotebookLMAdapter
from pulse_notebooklm.version import __version__

__all__ = ["NotebookLMAdapter", "__version__"]
