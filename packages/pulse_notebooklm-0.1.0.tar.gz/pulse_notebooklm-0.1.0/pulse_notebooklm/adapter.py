"""Google NotebookLM adapter for PULSE Protocol.

Wraps notebooklm-py to expose NotebookLM capabilities as PULSE semantic messages.

Supported actions:
    Notebooks:
        ACT.CREATE.NOTEBOOK     — create a new notebook
        ACT.LIST.NOTEBOOKS      — list all notebooks
        ACT.DELETE.NOTEBOOK     — delete a notebook

    Sources:
        ACT.ADD.SOURCE          — add URL, text, or file as source
        ACT.LIST.SOURCES        — list sources in a notebook
        ACT.DELETE.SOURCE       — remove a source

    Chat:
        ACT.QUERY.NOTEBOOK      — ask a question, get a cited answer

    Content generation:
        ACT.GENERATE.AUDIO      — generate audio overview (podcast)
        ACT.GENERATE.VIDEO      — generate video overview
        ACT.GENERATE.QUIZ       — generate quiz
        ACT.GENERATE.FLASHCARDS — generate flashcards
        ACT.GENERATE.REPORT     — generate study guide / briefing
        ACT.GENERATE.MINDMAP    — generate mind map

Auth:
    NotebookLM requires Google account auth via browser (first time only).
    Credentials are stored locally by notebooklm-py.

    First run:
        from notebooklm.auth import login
        await login()   # opens browser, saves session

    Subsequent runs: session is reloaded automatically.

Example:
    >>> import asyncio
    >>> from pulse_notebooklm import NotebookLMAdapter
    >>> from pulse.message import PulseMessage

    >>> async def main():
    ...     async with NotebookLMAdapter() as adapter:
    ...         # Create notebook
    ...         resp = await adapter.send_async(PulseMessage(
    ...             action="ACT.CREATE.NOTEBOOK",
    ...             parameters={"title": "AI Research"},
    ...         ))
    ...         notebook_id = resp.content["parameters"]["notebook_id"]
    ...
    ...         # Add a source
    ...         await adapter.send_async(PulseMessage(
    ...             action="ACT.ADD.SOURCE",
    ...             parameters={
    ...                 "notebook_id": notebook_id,
    ...                 "url": "https://arxiv.org/abs/2303.08774",
    ...             },
    ...         ))
    ...
    ...         # Ask a question
    ...         resp = await adapter.send_async(PulseMessage(
    ...             action="ACT.QUERY.NOTEBOOK",
    ...             parameters={"notebook_id": notebook_id, "query": "What is GPT-4?"},
    ...         ))
    ...         print(resp.content["parameters"]["answer"])

    >>> asyncio.run(main())
"""

import asyncio
from typing import Any, Dict, List, Optional

from pulse.message import PulseMessage
from pulse.adapter import PulseAdapter, AdapterError, AdapterConnectionError


class NotebookLMAdapter(PulseAdapter):
    """PULSE adapter for Google NotebookLM via notebooklm-py.

    This adapter is async-native — NotebookLM API calls are all async.
    Use ``send_async()`` for async contexts, or ``send()`` which runs
    the event loop automatically for sync contexts.

    Args:
        config: Optional extra config dict.

    Example:
        >>> async with NotebookLMAdapter() as adapter:
        ...     resp = await adapter.send_async(PulseMessage(
        ...         action="ACT.LIST.NOTEBOOKS",
        ...         parameters={},
        ...     ))
        ...     print(resp.content["parameters"]["notebooks"])
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(
            name="notebooklm",
            base_url="https://notebooklm.google.com",
            config=config or {},
        )
        self._client: Optional[Any] = None

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def connect(self) -> None:
        """Synchronous connect — use async context manager instead."""
        asyncio.get_event_loop().run_until_complete(self._async_connect())

    async def _async_connect(self) -> None:
        """Initialize NotebookLM async client.

        Raises:
            AdapterConnectionError: If notebooklm-py is not installed or auth fails.
        """
        try:
            from notebooklm import NotebookLMClient  # noqa: PLC0415
        except ImportError as e:
            raise AdapterConnectionError(
                "notebooklm-py not installed. Run: pip install notebooklm-py"
            ) from e

        try:
            self._client = await NotebookLMClient.from_storage().__aenter__()
            self.connected = True
        except Exception as e:
            raise AdapterConnectionError(
                f"NotebookLM auth failed. Run 'notebooklm login' first. Error: {e}"
            ) from e

    async def __aenter__(self) -> "NotebookLMAdapter":
        await self._async_connect()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._async_disconnect()

    def disconnect(self) -> None:
        asyncio.get_event_loop().run_until_complete(self._async_disconnect())

    async def _async_disconnect(self) -> None:
        if self._client:
            try:
                await self._client.__aexit__(None, None, None)
            except Exception:
                pass
            self._client = None
        self.connected = False

    # ── PULSE send (async version) ─────────────────────────────────────────

    async def send_async(self, message: PulseMessage) -> PulseMessage:
        """Send a PULSE message and return the response (async).

        Args:
            message: PULSE message with action and parameters.

        Returns:
            PULSE response message with result.

        Raises:
            AdapterError: If action fails.
            AdapterConnectionError: If not connected.
        """
        if not self._client:
            await self._async_connect()

        native = self.to_native(message)
        result = await self._async_call_api(native)
        return self.from_native(result)

    def send(self, message: PulseMessage) -> PulseMessage:
        """Send a PULSE message synchronously (runs event loop).

        Args:
            message: PULSE message.

        Returns:
            PULSE response message.
        """
        return asyncio.get_event_loop().run_until_complete(self.send_async(message))

    # ── PULSE Protocol Interface ───────────────────────────────────────────

    def to_native(self, message: PulseMessage) -> Dict[str, Any]:
        """Extract operation details from a PULSE message.

        Args:
            message: PULSE message.

        Returns:
            Dict with ``op`` and params.

        Raises:
            AdapterError: If action unsupported or params missing.
        """
        action = message.content["action"]
        params = message.content.get("parameters", {})

        op = _ACTION_TO_OP.get(action)
        if not op:
            raise AdapterError(
                f"Unsupported action '{action}'. "
                f"Supported: {sorted(_ACTION_TO_OP.keys())}"
            )
        return {"op": op, "params": params}

    def call_api(self, native_request: Dict[str, Any]) -> Dict[str, Any]:
        """Sync wrapper — delegates to async."""
        return asyncio.get_event_loop().run_until_complete(
            self._async_call_api(native_request)
        )

    async def _async_call_api(self, native_request: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the NotebookLM operation.

        Args:
            native_request: Dict from to_native().

        Returns:
            Result dict.

        Raises:
            AdapterError: On operation failure.
        """
        op = native_request["op"]
        params = native_request["params"]

        try:
            handler = _OP_HANDLERS.get(op)
            if not handler:
                raise AdapterError(f"Unknown op '{op}'")
            return await handler(self._client, params)

        except AdapterError:
            raise
        except Exception as e:
            raise AdapterError(f"NotebookLM error in '{op}': {e}") from e

    def from_native(self, native_response: Dict[str, Any]) -> PulseMessage:
        """Wrap result in a PULSE response message."""
        return PulseMessage(
            action="ACT.RESPOND",
            parameters=native_response,
            validate=False,
        )

    @property
    def supported_actions(self) -> List[str]:
        return sorted(_ACTION_TO_OP.keys())

    def __repr__(self) -> str:
        return f"NotebookLMAdapter(connected={self.connected})"


# ── Operation Handlers ────────────────────────────────────────────────────

def _require(params: Dict, *keys: str) -> None:
    """Raise AdapterError if any required key is missing."""
    for key in keys:
        if not params.get(key):
            raise AdapterError(f"Required parameter '{key}' is missing")


async def _create_notebook(client: Any, params: Dict) -> Dict:
    _require(params, "title")
    nb = await client.notebooks.create(title=params["title"])
    return {
        "status": "META.STATUS.SUCCESS",
        "notebook_id": nb.id,
        "title": nb.title,
    }


async def _list_notebooks(client: Any, params: Dict) -> Dict:
    notebooks = await client.notebooks.list()
    return {
        "status": "META.STATUS.SUCCESS",
        "notebooks": [{"id": nb.id, "title": nb.title} for nb in notebooks],
        "count": len(notebooks),
    }


async def _delete_notebook(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    deleted = await client.notebooks.delete(params["notebook_id"])
    return {"status": "META.STATUS.SUCCESS", "deleted": deleted}


async def _add_source(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    nb_id = params["notebook_id"]

    if params.get("url"):
        sources = await client.sources.add_url(nb_id, params["url"])
    elif params.get("text"):
        title = params.get("title", "Pasted text")
        sources = await client.sources.add_text(nb_id, params["text"], title=title)
    elif params.get("file"):
        sources = await client.sources.add_file(nb_id, params["file"])
    else:
        raise AdapterError("One of 'url', 'text', or 'file' is required for ACT.ADD.SOURCE")

    # wait_for_sources returns a list
    if not isinstance(sources, list):
        sources = [sources]
    await client.sources.wait_for_sources(sources)

    return {
        "status": "META.STATUS.SUCCESS",
        "source_ids": [s.id for s in sources],
        "count": len(sources),
    }


async def _list_sources(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    sources = await client.sources.list(params["notebook_id"])
    return {
        "status": "META.STATUS.SUCCESS",
        "sources": [{"id": s.id, "title": getattr(s, "title", "")} for s in sources],
        "count": len(sources),
    }


async def _delete_source(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id", "source_id")
    deleted = await client.sources.delete(params["notebook_id"], params["source_id"])
    return {"status": "META.STATUS.SUCCESS", "deleted": deleted}


async def _query_notebook(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id", "query")
    result = await client.chat.ask(params["notebook_id"], params["query"])
    answer = result.answer if hasattr(result, "answer") else str(result)
    citations = getattr(result, "citations", [])
    return {
        "status": "META.STATUS.SUCCESS",
        "answer": answer,
        "citations": [str(c) for c in citations],
    }


async def _generate_audio(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    artifact = await client.artifacts.generate_audio(
        params["notebook_id"],
        audio_format=params.get("format", 0),      # 0 = deep-dive
        audio_length=params.get("length", 0),       # 0 = default
        language=params.get("language", "en"),
    )
    await client.artifacts.wait_for_completion(artifact)
    return {
        "status": "META.STATUS.SUCCESS",
        "artifact_id": artifact.id,
        "type": "audio",
    }


async def _generate_video(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    artifact = await client.artifacts.generate_video(
        params["notebook_id"],
        video_format=params.get("format", 0),
    )
    await client.artifacts.wait_for_completion(artifact)
    return {
        "status": "META.STATUS.SUCCESS",
        "artifact_id": artifact.id,
        "type": "video",
    }


async def _generate_quiz(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    artifact = await client.artifacts.generate_quiz(
        params["notebook_id"],
        num_questions=params.get("num_questions", 5),
        difficulty=params.get("difficulty", 1),
    )
    await client.artifacts.wait_for_completion(artifact)
    return {
        "status": "META.STATUS.SUCCESS",
        "artifact_id": artifact.id,
        "type": "quiz",
    }


async def _generate_flashcards(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    artifact = await client.artifacts.generate_flashcards(
        params["notebook_id"],
        num_cards=params.get("num_cards", 10),
    )
    await client.artifacts.wait_for_completion(artifact)
    return {
        "status": "META.STATUS.SUCCESS",
        "artifact_id": artifact.id,
        "type": "flashcards",
    }


async def _generate_report(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    artifact = await client.artifacts.generate_report(
        params["notebook_id"],
        report_type=params.get("report_type", "study_guide"),
    )
    await client.artifacts.wait_for_completion(artifact)
    return {
        "status": "META.STATUS.SUCCESS",
        "artifact_id": artifact.id,
        "type": "report",
    }


async def _generate_mindmap(client: Any, params: Dict) -> Dict:
    _require(params, "notebook_id")
    artifact = await client.artifacts.generate_mind_map(params["notebook_id"])
    await client.artifacts.wait_for_completion(artifact)
    return {
        "status": "META.STATUS.SUCCESS",
        "artifact_id": artifact.id,
        "type": "mind_map",
    }


# ── Mappings ───────────────────────────────────────────────────────────────

_ACTION_TO_OP: Dict[str, str] = {
    "ACT.CREATE.NOTEBOOK": "create_notebook",
    "ACT.LIST.NOTEBOOKS": "list_notebooks",
    "ACT.DELETE.NOTEBOOK": "delete_notebook",
    "ACT.ADD.SOURCE": "add_source",
    "ACT.LIST.SOURCES": "list_sources",
    "ACT.DELETE.SOURCE": "delete_source",
    "ACT.QUERY.NOTEBOOK": "query_notebook",
    "ACT.GENERATE.AUDIO": "generate_audio",
    "ACT.GENERATE.VIDEO": "generate_video",
    "ACT.GENERATE.QUIZ": "generate_quiz",
    "ACT.GENERATE.FLASHCARDS": "generate_flashcards",
    "ACT.GENERATE.REPORT": "generate_report",
    "ACT.GENERATE.MINDMAP": "generate_mindmap",
}

_OP_HANDLERS = {
    "create_notebook": _create_notebook,
    "list_notebooks": _list_notebooks,
    "delete_notebook": _delete_notebook,
    "add_source": _add_source,
    "list_sources": _list_sources,
    "delete_source": _delete_source,
    "query_notebook": _query_notebook,
    "generate_audio": _generate_audio,
    "generate_video": _generate_video,
    "generate_quiz": _generate_quiz,
    "generate_flashcards": _generate_flashcards,
    "generate_report": _generate_report,
    "generate_mindmap": _generate_mindmap,
}
