"""Tests for NotebookLMAdapter — all notebooklm-py calls mocked."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from pulse.message import PulseMessage
from pulse.adapter import AdapterError, AdapterConnectionError

from pulse_notebooklm import NotebookLMAdapter


# ── Fixtures ───────────────────────────────────────────────────────────────

def make_notebook(id="nb-123", title="My Notebook"):
    nb = MagicMock()
    nb.id = id
    nb.title = title
    return nb


def make_source(id="src-456", title="Source Title"):
    src = MagicMock()
    src.id = id
    src.title = title
    return src


def make_artifact(id="art-789", artifact_type="audio"):
    art = MagicMock()
    art.id = id
    art.type = artifact_type
    return art


def make_chat_result(answer="42", citations=None):
    r = MagicMock()
    r.answer = answer
    r.citations = citations or []
    return r


@pytest.fixture
def mock_client():
    client = MagicMock()

    # notebooks
    client.notebooks.create = AsyncMock(return_value=make_notebook())
    client.notebooks.list = AsyncMock(return_value=[make_notebook(), make_notebook(id="nb-2", title="Second")])
    client.notebooks.delete = AsyncMock(return_value=True)

    # sources
    client.sources.add_url = AsyncMock(return_value=[make_source()])
    client.sources.add_text = AsyncMock(return_value=[make_source()])
    client.sources.add_file = AsyncMock(return_value=[make_source()])
    client.sources.wait_for_sources = AsyncMock(return_value=None)
    client.sources.list = AsyncMock(return_value=[make_source()])
    client.sources.delete = AsyncMock(return_value=True)

    # chat
    client.chat.ask = AsyncMock(return_value=make_chat_result(answer="Deep answer"))

    # artifacts
    art = make_artifact()
    client.artifacts.generate_audio = AsyncMock(return_value=art)
    client.artifacts.generate_video = AsyncMock(return_value=art)
    client.artifacts.generate_quiz = AsyncMock(return_value=art)
    client.artifacts.generate_flashcards = AsyncMock(return_value=art)
    client.artifacts.generate_report = AsyncMock(return_value=art)
    client.artifacts.generate_mind_map = AsyncMock(return_value=art)
    client.artifacts.wait_for_completion = AsyncMock(return_value=None)

    return client


@pytest.fixture
def adapter(mock_client):
    a = NotebookLMAdapter()
    a._client = mock_client
    a.connected = True
    return a


# ── connect() ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_connect_raises_if_not_installed():
    with patch.dict("sys.modules", {"notebooklm": None}):
        a = NotebookLMAdapter()
        with pytest.raises(AdapterConnectionError, match="notebooklm-py"):
            await a._async_connect()


# ── ACT.CREATE.NOTEBOOK ───────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_create_notebook(adapter, mock_client):
    msg = PulseMessage(action="ACT.CREATE.NOTEBOOK", parameters={"title": "AI Research"}, validate=False)
    resp = await adapter.send_async(msg)
    mock_client.notebooks.create.assert_called_once_with(title="AI Research")
    p = resp.content["parameters"]
    assert p["notebook_id"] == "nb-123"
    assert p["title"] == "My Notebook"
    assert p["status"] == "META.STATUS.SUCCESS"


@pytest.mark.asyncio
async def test_create_notebook_requires_title(adapter):
    msg = PulseMessage(action="ACT.CREATE.NOTEBOOK", parameters={}, validate=False)
    with pytest.raises(AdapterError, match="'title'"):
        await adapter.send_async(msg)


# ── ACT.LIST.NOTEBOOKS ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_notebooks(adapter, mock_client):
    msg = PulseMessage(action="ACT.LIST.NOTEBOOKS", parameters={}, validate=False)
    resp = await adapter.send_async(msg)
    p = resp.content["parameters"]
    assert p["count"] == 2
    assert p["notebooks"][0]["id"] == "nb-123"
    assert p["notebooks"][1]["id"] == "nb-2"


# ── ACT.DELETE.NOTEBOOK ───────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_delete_notebook(adapter, mock_client):
    msg = PulseMessage(action="ACT.DELETE.NOTEBOOK", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    mock_client.notebooks.delete.assert_called_once_with("nb-123")
    assert resp.content["parameters"]["deleted"] is True


@pytest.mark.asyncio
async def test_delete_notebook_requires_id(adapter):
    msg = PulseMessage(action="ACT.DELETE.NOTEBOOK", parameters={}, validate=False)
    with pytest.raises(AdapterError, match="'notebook_id'"):
        await adapter.send_async(msg)


# ── ACT.ADD.SOURCE ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_add_source_url(adapter, mock_client):
    msg = PulseMessage(
        action="ACT.ADD.SOURCE",
        parameters={"notebook_id": "nb-123", "url": "https://example.com"},
        validate=False,
    )
    resp = await adapter.send_async(msg)
    mock_client.sources.add_url.assert_called_once_with("nb-123", "https://example.com")
    assert resp.content["parameters"]["count"] == 1
    assert resp.content["parameters"]["source_ids"] == ["src-456"]


@pytest.mark.asyncio
async def test_add_source_text(adapter, mock_client):
    msg = PulseMessage(
        action="ACT.ADD.SOURCE",
        parameters={"notebook_id": "nb-123", "text": "Some content", "title": "My doc"},
        validate=False,
    )
    await adapter.send_async(msg)
    mock_client.sources.add_text.assert_called_once_with("nb-123", "Some content", title="My doc")


@pytest.mark.asyncio
async def test_add_source_requires_notebook_id(adapter):
    msg = PulseMessage(action="ACT.ADD.SOURCE", parameters={"url": "https://x.com"}, validate=False)
    with pytest.raises(AdapterError, match="'notebook_id'"):
        await adapter.send_async(msg)


@pytest.mark.asyncio
async def test_add_source_requires_content(adapter):
    msg = PulseMessage(action="ACT.ADD.SOURCE", parameters={"notebook_id": "nb-123"}, validate=False)
    with pytest.raises(AdapterError, match="url.*text.*file"):
        await adapter.send_async(msg)


# ── ACT.LIST.SOURCES ──────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_sources(adapter, mock_client):
    msg = PulseMessage(action="ACT.LIST.SOURCES", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    mock_client.sources.list.assert_called_once_with("nb-123")
    assert resp.content["parameters"]["count"] == 1


# ── ACT.DELETE.SOURCE ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_delete_source(adapter, mock_client):
    msg = PulseMessage(
        action="ACT.DELETE.SOURCE",
        parameters={"notebook_id": "nb-123", "source_id": "src-456"},
        validate=False,
    )
    resp = await adapter.send_async(msg)
    mock_client.sources.delete.assert_called_once_with("nb-123", "src-456")
    assert resp.content["parameters"]["deleted"] is True


# ── ACT.QUERY.NOTEBOOK ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_query_notebook(adapter, mock_client):
    msg = PulseMessage(
        action="ACT.QUERY.NOTEBOOK",
        parameters={"notebook_id": "nb-123", "query": "What is PULSE?"},
        validate=False,
    )
    resp = await adapter.send_async(msg)
    mock_client.chat.ask.assert_called_once_with("nb-123", "What is PULSE?")
    assert resp.content["parameters"]["answer"] == "Deep answer"
    assert "citations" in resp.content["parameters"]


@pytest.mark.asyncio
async def test_query_requires_query(adapter):
    msg = PulseMessage(action="ACT.QUERY.NOTEBOOK", parameters={"notebook_id": "nb-123"}, validate=False)
    with pytest.raises(AdapterError, match="'query'"):
        await adapter.send_async(msg)


# ── Content generation ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_generate_audio(adapter, mock_client):
    msg = PulseMessage(action="ACT.GENERATE.AUDIO", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    mock_client.artifacts.generate_audio.assert_called_once()
    mock_client.artifacts.wait_for_completion.assert_called_once()
    assert resp.content["parameters"]["type"] == "audio"
    assert resp.content["parameters"]["artifact_id"] == "art-789"


@pytest.mark.asyncio
async def test_generate_video(adapter, mock_client):
    msg = PulseMessage(action="ACT.GENERATE.VIDEO", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    assert resp.content["parameters"]["type"] == "video"


@pytest.mark.asyncio
async def test_generate_quiz(adapter, mock_client):
    msg = PulseMessage(
        action="ACT.GENERATE.QUIZ",
        parameters={"notebook_id": "nb-123", "num_questions": 10},
        validate=False,
    )
    resp = await adapter.send_async(msg)
    mock_client.artifacts.generate_quiz.assert_called_once_with("nb-123", num_questions=10, difficulty=1)
    assert resp.content["parameters"]["type"] == "quiz"


@pytest.mark.asyncio
async def test_generate_flashcards(adapter, mock_client):
    msg = PulseMessage(action="ACT.GENERATE.FLASHCARDS", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    assert resp.content["parameters"]["type"] == "flashcards"


@pytest.mark.asyncio
async def test_generate_report(adapter, mock_client):
    msg = PulseMessage(action="ACT.GENERATE.REPORT", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    assert resp.content["parameters"]["type"] == "report"


@pytest.mark.asyncio
async def test_generate_mindmap(adapter, mock_client):
    msg = PulseMessage(action="ACT.GENERATE.MINDMAP", parameters={"notebook_id": "nb-123"}, validate=False)
    resp = await adapter.send_async(msg)
    assert resp.content["parameters"]["type"] == "mind_map"


# ── Misc ──────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_unsupported_action(adapter):
    msg = PulseMessage(action="ACT.QUERY.DATA", parameters={}, validate=False)
    with pytest.raises(AdapterError, match="Unsupported action"):
        await adapter.send_async(msg)


def test_supported_actions(adapter):
    actions = adapter.supported_actions
    assert "ACT.CREATE.NOTEBOOK" in actions
    assert "ACT.QUERY.NOTEBOOK" in actions
    assert "ACT.GENERATE.AUDIO" in actions
    assert len(actions) == 13


def test_repr(adapter):
    assert "NotebookLMAdapter" in repr(adapter)


@pytest.mark.asyncio
async def test_error_propagates(adapter, mock_client):
    mock_client.notebooks.list.side_effect = Exception("Network error")
    msg = PulseMessage(action="ACT.LIST.NOTEBOOKS", parameters={}, validate=False)
    with pytest.raises(AdapterError, match="NotebookLM error"):
        await adapter.send_async(msg)
