
# zen expression

放弃使用 pyparsing 来解析zen expression，因为zen expression的表达式语法没有明确定义.
等以后 zen expresion 稳定以后，考虑使用 lark 来定义 EBNF 语法格式. 考虑兼容 s-feel (feel lang)的语法格式.


```python
    ## 测试 zen 表达式 变量字符串 下标访问  不支持  结果为None
    assert zen.evaluate_expression('b[1]', {"a": [1,2,3,4,5],"b":"fccdjny"}) is None

    ## 测试 zen 表达式 变量字符串 切片  支持
    assert zen.evaluate_expression('b[0:0]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == "f"
    assert zen.evaluate_expression('b[1:]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == "ccdjny"
    assert zen.evaluate_expression('b[1:2]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == "cc"

    ## 测试 zen 表达式 常量数组 切片    支持
    assert zen.evaluate_expression('[1,2,3,4,5][1]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == 2
    assert zen.evaluate_expression('[1,2,3,4,5][1:]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == [2,3,4,5]
    assert zen.evaluate_expression('[1,2,3,4,5][1:2]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == [2,3]

    ## 测试 zen 表达式 常量字符串 切片  不支持
    with pytest.raises(RuntimeError, match="parserError"):
        assert zen.evaluate_expression('"fccdjny"[1]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == 'c' 
    with pytest.raises(RuntimeError, match="parserError"):
        assert zen.evaluate_expression('"fccdjny"[1:]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == 'ccdjny' 
    with pytest.raises(RuntimeError, match="parserError"):
        assert zen.evaluate_expression('"fccdjny"[1:2]', {"a": [1,2,3,4,5],"b":"fccdjny"}) == 'cc'
```