
# 对比压测

注意:  
richbench 的测试文件名都必须以 bench_ 开头

richbench my_benchmarks/