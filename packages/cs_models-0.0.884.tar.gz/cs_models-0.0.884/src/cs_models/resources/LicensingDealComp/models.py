from datetime import datetime

from sqlalchemy import (
    Column,
    BigInteger,
    DateTime,
    ForeignKey,
    Boolean,
    String,
    Text,
    DECIMAL,
    Index,
)

from ...database import Base


class LicensingDealCompModel(Base):
    __tablename__ = "licensing_deal_comps"

    id = Column(BigInteger, primary_key=True)
    licensing_deal_id = Column(
        BigInteger,
        ForeignKey('licensing_deals.id'),
        nullable=False,
    )
    news_id = Column(
        BigInteger,
        ForeignKey('newswires.id'),
        nullable=False,
    )
    extraction_version = Column(String(64), nullable=False)
    source_link = Column(Text, nullable=True)
    date_announced_mmm_yy = Column(String(16), nullable=True)
    licensor_name = Column(Text, nullable=True)
    licensee_name = Column(Text, nullable=True)
    asset_summary = Column(Text, nullable=True)
    asset_country_origin_summary = Column(Text, nullable=True)
    therapeutic_area = Column(String(64), nullable=True)
    indication_summary = Column(Text, nullable=True)
    mechanism_summary = Column(Text, nullable=True)
    modality_summary = Column(Text, nullable=True)
    geography_territory_summary = Column(Text, nullable=True)
    stage_at_signing_summary = Column(Text, nullable=True)
    deal_type_primary = Column(String(64), nullable=True)
    deal_type_secondary_summary = Column(Text, nullable=True)
    upfront_total_usd = Column(DECIMAL(18, 2), nullable=True)
    upfront_total_display = Column(String(64), nullable=True)
    upfront_cash_usd = Column(DECIMAL(18, 2), nullable=True)
    upfront_cash_display = Column(String(64), nullable=True)
    upfront_equity_usd = Column(DECIMAL(18, 2), nullable=True)
    upfront_equity_display = Column(String(64), nullable=True)
    milestones_total_usd = Column(DECIMAL(18, 2), nullable=True)
    milestones_total_display = Column(String(64), nullable=True)
    total_consideration_usd = Column(DECIMAL(18, 2), nullable=True)
    total_consideration_display = Column(String(64), nullable=True)
    royalty_percent_min = Column(DECIMAL(8, 4), nullable=True)
    royalty_percent_max = Column(DECIMAL(8, 4), nullable=True)
    royalty_display = Column(Text, nullable=True)
    has_co_co_structure = Column(Boolean, nullable=True)
    co_co_scope = Column(Text, nullable=True)
    economics_disclosure_status = Column(String(64), nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_comps_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_comps_news_id', 'news_id'),
        Index('idx_licensing_deal_comps_therapeutic_area', 'therapeutic_area'),
        Index('idx_licensing_deal_comps_deal_type_primary', 'deal_type_primary'),
    )
