from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    String,
    Text,
    Index,
)

from ...database import Base


class LicensingDealExtractionRunModel(Base):
    __tablename__ = "licensing_deal_extraction_runs"

    id = Column(Integer, primary_key=True)
    licensing_deal_id = Column(
        Integer,
        ForeignKey('licensing_deals.id'),
        nullable=True,
    )
    licensing_collab_outbox_id = Column(
        Integer,
        ForeignKey('licensing_collab_outbox.id'),
        nullable=True,
    )
    model_provider = Column(String(32), nullable=False)
    model_name = Column(String(64), nullable=False)
    prompt_version = Column(String(64), nullable=False)
    schema_version = Column(String(64), nullable=False)
    status = Column(String(32), nullable=False)
    raw_llm_output = Column(Text, nullable=True)
    parsed_output = Column(Text, nullable=True)
    validation_errors = Column(Text, nullable=True)
    started_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_extraction_runs_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_extraction_runs_outbox_id', 'licensing_collab_outbox_id'),
        Index('idx_licensing_deal_extraction_runs_status', 'status'),
    )
