from marshmallow import (
    Schema,
    fields,
    pre_load,
    validate,
)

from ...utils.utils import pre_load_date_fields


class LicensingDealExtractionRunResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_id = fields.Integer(allow_none=True)
    licensing_collab_outbox_id = fields.Integer(allow_none=True)
    model_provider = fields.String(required=True)
    model_name = fields.String(required=True)
    prompt_version = fields.String(required=True)
    schema_version = fields.String(required=True)
    status = fields.String(required=True)
    raw_llm_output = fields.String(allow_none=True)
    parsed_output = fields.String(allow_none=True)
    validation_errors = fields.String(allow_none=True)
    started_at = fields.DateTime(required=True)
    completed_at = fields.DateTime(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)

    @pre_load
    def convert_string_to_datetime(self, in_data, **kwargs):
        date_fields = ['started_at', 'completed_at']
        in_data = pre_load_date_fields(
            in_data,
            date_fields,
            date_format='%Y%m%dT%H%M%S',
        )
        return in_data

