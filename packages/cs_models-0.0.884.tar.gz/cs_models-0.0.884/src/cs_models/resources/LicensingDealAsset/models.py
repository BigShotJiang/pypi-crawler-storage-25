from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    Boolean,
    String,
    Text,
    Index,
)

from ...database import Base


class LicensingDealAssetModel(Base):
    __tablename__ = "licensing_deal_assets"

    id = Column(Integer, primary_key=True)
    licensing_deal_id = Column(
        Integer,
        ForeignKey('licensing_deals.id'),
        nullable=False,
    )
    asset_name = Column(Text, nullable=True)
    asset_label = Column(Text, nullable=False)
    asset_type = Column(String(32), nullable=True)
    scope_type = Column(String(32), nullable=True)
    asset_descriptor_raw = Column(Text, nullable=True)
    is_unnamed_asset = Column(Boolean, nullable=True)
    is_platform = Column(Boolean, nullable=True)
    program_descriptor = Column(Text, nullable=True)
    asset_country_origin = Column(String(64), nullable=True)
    mechanism_text = Column(Text, nullable=True)
    modality = Column(String(64), nullable=True)
    stage_at_signing = Column(String(64), nullable=True)
    stage_group = Column(String(32), nullable=True)
    launch_country_if_marketed = Column(String(64), nullable=True)
    therapeutic_area = Column(String(64), nullable=True)
    primary_indication_text = Column(Text, nullable=True)
    co_co_structure = Column(String(128), nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_assets_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_assets_stage_group', 'stage_group'),
        Index('idx_licensing_deal_assets_modality', 'modality'),
        Index('idx_licensing_deal_assets_therapeutic_area', 'therapeutic_area'),
    )
