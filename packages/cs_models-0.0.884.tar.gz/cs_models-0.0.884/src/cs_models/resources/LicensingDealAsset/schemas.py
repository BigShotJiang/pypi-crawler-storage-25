from marshmallow import (
    Schema,
    fields,
    validate,
)


class LicensingDealAssetResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_id = fields.Integer(required=True)
    asset_name = fields.String(allow_none=True)
    asset_label = fields.String(required=True, validate=not_blank)
    asset_type = fields.String(allow_none=True)
    scope_type = fields.String(allow_none=True)
    asset_descriptor_raw = fields.String(allow_none=True)
    is_unnamed_asset = fields.Boolean(allow_none=True)
    is_platform = fields.Boolean(allow_none=True)
    program_descriptor = fields.String(allow_none=True)
    asset_country_origin = fields.String(allow_none=True)
    mechanism_text = fields.String(allow_none=True)
    modality = fields.String(allow_none=True)
    stage_at_signing = fields.String(allow_none=True)
    stage_group = fields.String(allow_none=True)
    launch_country_if_marketed = fields.String(allow_none=True)
    therapeutic_area = fields.String(allow_none=True)
    primary_indication_text = fields.String(allow_none=True)
    co_co_structure = fields.String(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)
