from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    Boolean,
    String,
    Text,
    Float,
    Index,
)

from ...database import Base


class LicensingDealAssetIndicationModel(Base):
    __tablename__ = "licensing_deal_asset_indications"

    id = Column(Integer, primary_key=True)
    licensing_deal_asset_id = Column(
        Integer,
        ForeignKey('licensing_deal_assets.id'),
        nullable=False,
    )
    condition_id = Column(
        Integer,
        ForeignKey('conditions.id'),
        nullable=True,
    )
    indication_text = Column(Text, nullable=False)
    therapeutic_area = Column(String(64), nullable=True)
    is_primary = Column(Boolean, nullable=True)
    match_confidence = Column(Float, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_asset_indications_asset_id', 'licensing_deal_asset_id'),
        Index('idx_licensing_deal_asset_indications_condition_id', 'condition_id'),
    )
