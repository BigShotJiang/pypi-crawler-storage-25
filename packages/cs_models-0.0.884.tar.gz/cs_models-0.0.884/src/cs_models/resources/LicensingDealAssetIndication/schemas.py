from marshmallow import (
    Schema,
    fields,
    validate,
)


class LicensingDealAssetIndicationResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_asset_id = fields.Integer(required=True)
    condition_id = fields.Integer(allow_none=True)
    indication_text = fields.String(required=True, validate=not_blank)
    therapeutic_area = fields.String(allow_none=True)
    is_primary = fields.Boolean(allow_none=True)
    match_confidence = fields.Float(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)

