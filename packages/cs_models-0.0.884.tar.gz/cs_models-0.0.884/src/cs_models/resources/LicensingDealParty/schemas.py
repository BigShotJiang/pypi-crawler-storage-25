from marshmallow import (
    Schema,
    fields,
    validate,
    pre_load,
    ValidationError,
)


class LicensingDealPartyResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_id = fields.Integer(required=True)
    company_sec_id = fields.Integer(allow_none=True)
    company_ous_id = fields.Integer(allow_none=True)
    company_name_raw = fields.String(required=True, validate=not_blank)
    role = fields.String(required=True, validate=not_blank)
    party_type = fields.String(allow_none=True)
    role_detail = fields.String(allow_none=True)
    role_evidence_text = fields.String(allow_none=True)
    is_primary_counterparty = fields.Boolean(allow_none=True)
    country = fields.String(allow_none=True)
    region = fields.String(allow_none=True)
    company_size_bucket = fields.String(allow_none=True)
    match_method = fields.String(allow_none=True)
    match_confidence = fields.Float(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)

    @pre_load
    def check_company_ids(self, in_data, **kwargs):
        if self._get_number_of_company_fields(in_data) > 1:
            raise ValidationError('Provide either company_sec_id or company_ous_id, not both')
        return in_data

    def _get_number_of_company_fields(self, in_data, **kwargs):
        result = 0
        if 'company_sec_id' in in_data and in_data['company_sec_id'] is not None:
            result += 1
        if 'company_ous_id' in in_data and in_data['company_ous_id'] is not None:
            result += 1
        return result
