from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    Boolean,
    String,
    Text,
    Float,
    Index,
)

from ...database import Base


class LicensingDealPartyModel(Base):
    __tablename__ = "licensing_deal_parties"

    id = Column(Integer, primary_key=True)
    licensing_deal_id = Column(
        Integer,
        ForeignKey('licensing_deals.id'),
        nullable=False,
    )
    company_sec_id = Column(
        Integer,
        ForeignKey('companies_sec.id'),
        nullable=True,
    )
    company_ous_id = Column(
        Integer,
        ForeignKey('companies_ous.id'),
        nullable=True,
    )
    company_name_raw = Column(Text, nullable=False)
    role = Column(String(32), nullable=False)
    party_type = Column(String(32), nullable=True)
    role_detail = Column(String(64), nullable=True)
    role_evidence_text = Column(Text, nullable=True)
    is_primary_counterparty = Column(Boolean, nullable=True)
    country = Column(String(64), nullable=True)
    region = Column(String(64), nullable=True)
    company_size_bucket = Column(String(32), nullable=True)
    match_method = Column(String(32), nullable=True)
    match_confidence = Column(Float, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_parties_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_parties_role', 'role'),
        Index('idx_licensing_deal_parties_company_sec_id', 'company_sec_id'),
        Index('idx_licensing_deal_parties_company_ous_id', 'company_ous_id'),
    )
