from datetime import datetime

from sqlalchemy import (
    Column,
    BigInteger,
    DateTime,
    ForeignKey,
    Boolean,
    String,
    Text,
    DECIMAL,
    Index,
)

from ...database import Base


class LicensingDealEconomicTermModel(Base):
    __tablename__ = "licensing_deal_economic_terms"

    id = Column(BigInteger, primary_key=True)
    licensing_deal_id = Column(
        BigInteger,
        ForeignKey('licensing_deals.id'),
        nullable=False,
    )
    licensing_deal_asset_id = Column(
        BigInteger,
        ForeignKey('licensing_deal_assets.id'),
        nullable=True,
    )
    licensing_deal_territory_id = Column(
        BigInteger,
        ForeignKey('licensing_deal_territories.id'),
        nullable=True,
    )
    term_type = Column(String(32), nullable=False)
    term_subtype = Column(String(64), nullable=True)
    economic_bucket = Column(String(64), nullable=True)
    amount_original = Column(DECIMAL(18, 2), nullable=True)
    currency_original = Column(String(16), nullable=True)
    amount_usd = Column(DECIMAL(18, 2), nullable=True)
    is_range = Column(Boolean, nullable=True)
    range_min_original = Column(DECIMAL(18, 2), nullable=True)
    range_max_original = Column(DECIMAL(18, 2), nullable=True)
    range_min_usd = Column(DECIMAL(18, 2), nullable=True)
    range_max_usd = Column(DECIMAL(18, 2), nullable=True)
    percent_min = Column(DECIMAL(8, 4), nullable=True)
    percent_max = Column(DECIMAL(8, 4), nullable=True)
    milestone_category = Column(String(32), nullable=True)
    payment_timing = Column(String(64), nullable=True)
    is_disclosed = Column(Boolean, nullable=False, default=True)
    disclosure_status = Column(String(32), nullable=True)
    headline_included_in_total = Column(Boolean, nullable=True)
    royalty_text_raw = Column(Text, nullable=True)
    raw_text = Column(Text, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_economic_terms_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_economic_terms_asset_id', 'licensing_deal_asset_id'),
        Index('idx_licensing_deal_economic_terms_territory_id', 'licensing_deal_territory_id'),
        Index('idx_licensing_deal_economic_terms_term_type', 'term_type'),
    )
