from marshmallow import (
    Schema,
    fields,
    validate,
)


class LicensingDealEconomicTermResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_id = fields.Integer(required=True)
    licensing_deal_asset_id = fields.Integer(allow_none=True)
    licensing_deal_territory_id = fields.Integer(allow_none=True)
    term_type = fields.String(required=True, validate=not_blank)
    term_subtype = fields.String(allow_none=True)
    economic_bucket = fields.String(allow_none=True)
    amount_original = fields.Decimal(allow_none=True, as_string=True)
    currency_original = fields.String(allow_none=True)
    amount_usd = fields.Decimal(allow_none=True, as_string=True)
    is_range = fields.Boolean(allow_none=True)
    range_min_original = fields.Decimal(allow_none=True, as_string=True)
    range_max_original = fields.Decimal(allow_none=True, as_string=True)
    range_min_usd = fields.Decimal(allow_none=True, as_string=True)
    range_max_usd = fields.Decimal(allow_none=True, as_string=True)
    percent_min = fields.Decimal(allow_none=True, as_string=True)
    percent_max = fields.Decimal(allow_none=True, as_string=True)
    milestone_category = fields.String(allow_none=True)
    payment_timing = fields.String(allow_none=True)
    is_disclosed = fields.Boolean(required=True)
    disclosure_status = fields.String(allow_none=True)
    headline_included_in_total = fields.Boolean(allow_none=True)
    royalty_text_raw = fields.String(allow_none=True)
    raw_text = fields.String(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)
