from marshmallow import (
    Schema,
    fields,
    pre_load,
    validate,
)

from ...utils.utils import pre_load_date_fields


class LicensingDealResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    news_id = fields.Integer(required=True)
    headline = fields.String(allow_none=True)
    source_link = fields.String(allow_none=True)
    announcement_date = fields.DateTime(required=True)
    deal_type = fields.String(allow_none=True)
    deal_type_primary = fields.String(allow_none=True)
    deal_type_secondary = fields.String(allow_none=True)
    is_hybrid_deal = fields.Boolean(allow_none=True)
    scope_level = fields.String(allow_none=True)
    scope_description_raw = fields.String(allow_none=True)
    rights_summary_raw = fields.String(allow_none=True)
    geography_summary_raw = fields.String(allow_none=True)
    economics_summary_raw = fields.String(allow_none=True)
    disclosure_gaps = fields.String(allow_none=True)
    territory_scope = fields.String(allow_none=True)
    stage_summary = fields.String(allow_none=True)
    therapeutic_area_primary = fields.String(allow_none=True)
    modality_primary = fields.String(allow_none=True)
    is_option_deal = fields.Boolean(allow_none=True)
    is_platform_deal = fields.Boolean(allow_none=True)
    has_equity_component = fields.Boolean(allow_none=True)
    has_co_co_rights = fields.Boolean(allow_none=True)
    co_co_notes = fields.String(allow_none=True)
    co_co_scope = fields.String(allow_none=True)
    date_announced_mmm_yy = fields.String(allow_none=True)
    economics_disclosure_status = fields.String(allow_none=True)
    upfront_total_usd = fields.Decimal(allow_none=True, as_string=True)
    upfront_cash_usd = fields.Decimal(allow_none=True, as_string=True)
    upfront_equity_usd = fields.Decimal(allow_none=True, as_string=True)
    milestones_total_usd = fields.Decimal(allow_none=True, as_string=True)
    total_consideration_usd = fields.Decimal(allow_none=True, as_string=True)
    royalty_min_pct = fields.Decimal(allow_none=True, as_string=True)
    royalty_max_pct = fields.Decimal(allow_none=True, as_string=True)
    currency_conversion_fx_date = fields.Date(allow_none=True)
    currency_conversion_method = fields.String(allow_none=True)
    extraction_status = fields.String(allow_none=True)
    extraction_version = fields.String(allow_none=True)
    last_extracted_at = fields.DateTime(allow_none=True)
    is_deleted = fields.Boolean(allow_none=True)
    updated_at = fields.DateTime()

    @pre_load
    def convert_string_to_datetime(self, in_data, **kwargs):
        date_fields = ['announcement_date', 'last_extracted_at']
        in_data = pre_load_date_fields(
            in_data,
            date_fields,
            date_format='%Y%m%dT%H%M%S',
        )
        return in_data
