from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    Date,
    ForeignKey,
    Boolean,
    String,
    Text,
    DECIMAL,
    Index,
)

from ...database import Base


class LicensingDealModel(Base):
    __tablename__ = "licensing_deals"

    id = Column(Integer, primary_key=True)
    news_id = Column(
        Integer,
        ForeignKey('newswires.id'),
        nullable=False,
    )
    headline = Column(Text, nullable=True)
    source_link = Column(Text, nullable=True)
    announcement_date = Column(DateTime, nullable=False)
    deal_type = Column(String(64), nullable=True)
    deal_type_primary = Column(String(64), nullable=True)
    deal_type_secondary = Column(Text, nullable=True)
    is_hybrid_deal = Column(Boolean, nullable=True)
    scope_level = Column(String(64), nullable=True)
    scope_description_raw = Column(Text, nullable=True)
    rights_summary_raw = Column(Text, nullable=True)
    geography_summary_raw = Column(Text, nullable=True)
    economics_summary_raw = Column(Text, nullable=True)
    disclosure_gaps = Column(Text, nullable=True)
    territory_scope = Column(String(64), nullable=True)
    stage_summary = Column(String(64), nullable=True)
    therapeutic_area_primary = Column(String(64), nullable=True)
    modality_primary = Column(String(64), nullable=True)
    is_option_deal = Column(Boolean, nullable=True)
    is_platform_deal = Column(Boolean, nullable=True)
    has_equity_component = Column(Boolean, nullable=True)
    has_co_co_rights = Column(Boolean, nullable=True)
    co_co_notes = Column(Text, nullable=True)
    co_co_scope = Column(Text, nullable=True)
    date_announced_mmm_yy = Column(String(16), nullable=True)
    economics_disclosure_status = Column(String(64), nullable=True)
    upfront_total_usd = Column(DECIMAL(18, 2), nullable=True)
    upfront_cash_usd = Column(DECIMAL(18, 2), nullable=True)
    upfront_equity_usd = Column(DECIMAL(18, 2), nullable=True)
    milestones_total_usd = Column(DECIMAL(18, 2), nullable=True)
    total_consideration_usd = Column(DECIMAL(18, 2), nullable=True)
    royalty_min_pct = Column(DECIMAL(8, 4), nullable=True)
    royalty_max_pct = Column(DECIMAL(8, 4), nullable=True)
    currency_conversion_fx_date = Column(Date, nullable=True)
    currency_conversion_method = Column(String(64), nullable=True)
    extraction_status = Column(String(32), nullable=True)
    extraction_version = Column(String(64), nullable=True)
    last_extracted_at = Column(DateTime, nullable=True)
    is_deleted = Column(Boolean, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deals_news_id', 'news_id'),
        Index('idx_licensing_deals_announcement_date', 'announcement_date'),
        Index('idx_licensing_deals_deal_type', 'deal_type'),
    )
