from marshmallow import (
    Schema,
    fields,
    validate,
)


class LicensingDealTerritoryResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_id = fields.Integer(required=True)
    licensing_deal_party_id = fields.Integer(allow_none=True)
    scope_type = fields.String(required=True, validate=not_blank)
    territory_scope_type = fields.String(allow_none=True)
    territory_name = fields.String(required=True, validate=not_blank)
    territory_group = fields.String(allow_none=True)
    rights_type = fields.String(allow_none=True)
    rights_category = fields.String(allow_none=True)
    party_role = fields.String(allow_none=True)
    granted_to_party_role = fields.String(allow_none=True)
    retained_by_party_role = fields.String(allow_none=True)
    is_retained_right = fields.Boolean(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)
