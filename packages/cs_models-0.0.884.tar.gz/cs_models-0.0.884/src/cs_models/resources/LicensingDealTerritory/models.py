from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    Boolean,
    String,
    Index,
)

from ...database import Base


class LicensingDealTerritoryModel(Base):
    __tablename__ = "licensing_deal_territories"

    id = Column(Integer, primary_key=True)
    licensing_deal_id = Column(
        Integer,
        ForeignKey('licensing_deals.id'),
        nullable=False,
    )
    licensing_deal_party_id = Column(
        Integer,
        ForeignKey('licensing_deal_parties.id'),
        nullable=True,
    )
    scope_type = Column(String(32), nullable=False)
    territory_scope_type = Column(String(32), nullable=True)
    territory_name = Column(String(128), nullable=False)
    territory_group = Column(String(64), nullable=True)
    rights_type = Column(String(64), nullable=True)
    rights_category = Column(String(64), nullable=True)
    party_role = Column(String(32), nullable=True)
    granted_to_party_role = Column(String(32), nullable=True)
    retained_by_party_role = Column(String(32), nullable=True)
    is_retained_right = Column(Boolean, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_territories_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_territories_scope_type', 'scope_type'),
        Index('idx_licensing_deal_territories_name', 'territory_name'),
    )
