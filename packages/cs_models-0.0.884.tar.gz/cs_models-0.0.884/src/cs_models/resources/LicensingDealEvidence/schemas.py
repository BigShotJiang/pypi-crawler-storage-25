from marshmallow import (
    Schema,
    fields,
    validate,
)


class LicensingDealEvidenceResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_id = fields.Integer(required=True)
    licensing_deal_asset_id = fields.Integer(allow_none=True)
    extraction_run_id = fields.Integer(allow_none=True)
    field_path = fields.String(required=True, validate=not_blank)
    value_text = fields.String(allow_none=True)
    source_snippet = fields.String(required=True, validate=not_blank)
    char_start = fields.Integer(allow_none=True)
    char_end = fields.Integer(allow_none=True)
    confidence = fields.Float(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)

