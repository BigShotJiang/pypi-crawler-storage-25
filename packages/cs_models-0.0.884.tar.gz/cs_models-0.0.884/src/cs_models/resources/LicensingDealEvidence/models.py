from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    String,
    Text,
    Float,
    Index,
)

from ...database import Base


class LicensingDealEvidenceModel(Base):
    __tablename__ = "licensing_deal_evidence"

    id = Column(Integer, primary_key=True)
    licensing_deal_id = Column(
        Integer,
        ForeignKey('licensing_deals.id'),
        nullable=False,
    )
    licensing_deal_asset_id = Column(
        Integer,
        ForeignKey('licensing_deal_assets.id'),
        nullable=True,
    )
    extraction_run_id = Column(
        Integer,
        ForeignKey('licensing_deal_extraction_runs.id'),
        nullable=True,
    )
    field_path = Column(String(128), nullable=False)
    value_text = Column(Text, nullable=True)
    source_snippet = Column(Text, nullable=False)
    char_start = Column(Integer, nullable=True)
    char_end = Column(Integer, nullable=True)
    confidence = Column(Float, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_evidence_deal_id', 'licensing_deal_id'),
        Index('idx_licensing_deal_evidence_asset_id', 'licensing_deal_asset_id'),
        Index('idx_licensing_deal_evidence_run_id', 'extraction_run_id'),
        Index('idx_licensing_deal_evidence_field_path', 'field_path'),
    )
