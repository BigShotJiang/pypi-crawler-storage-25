from datetime import datetime

from sqlalchemy import (
    Column,
    Integer,
    DateTime,
    ForeignKey,
    String,
    Text,
    Float,
    Index,
)

from ...database import Base


class LicensingDealAssetTargetModel(Base):
    __tablename__ = "licensing_deal_asset_targets"

    id = Column(Integer, primary_key=True)
    licensing_deal_asset_id = Column(
        Integer,
        ForeignKey('licensing_deal_assets.id'),
        nullable=False,
    )
    target_id = Column(
        Integer,
        ForeignKey('targets.id'),
        nullable=True,
    )
    target_text = Column(Text, nullable=False)
    mechanism_class = Column(String(128), nullable=True)
    match_confidence = Column(Float, nullable=True)
    updated_at = Column(
        DateTime,
        nullable=False,
        default=lambda: datetime.utcnow(),
        onupdate=lambda: datetime.utcnow(),
    )

    __table_args__ = (
        Index('idx_licensing_deal_asset_targets_asset_id', 'licensing_deal_asset_id'),
        Index('idx_licensing_deal_asset_targets_target_id', 'target_id'),
    )
