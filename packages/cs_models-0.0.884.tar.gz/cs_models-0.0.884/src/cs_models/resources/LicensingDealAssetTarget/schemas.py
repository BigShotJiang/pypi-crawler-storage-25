from marshmallow import (
    Schema,
    fields,
    validate,
)


class LicensingDealAssetTargetResourceSchema(Schema):
    not_blank = validate.Length(min=1, error='Field cannot be blank')

    id = fields.Integer(dump_only=True)
    licensing_deal_asset_id = fields.Integer(required=True)
    target_id = fields.Integer(allow_none=True)
    target_text = fields.String(required=True, validate=not_blank)
    mechanism_class = fields.String(allow_none=True)
    match_confidence = fields.Float(allow_none=True)
    updated_at = fields.DateTime(dump_only=True)

