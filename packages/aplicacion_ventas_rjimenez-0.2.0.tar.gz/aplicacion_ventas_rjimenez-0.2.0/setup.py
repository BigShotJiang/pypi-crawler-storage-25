from setuptools import setup, find_packages
setup(
    name='aplicacion_ventas_rjimenez',
    version='0.2.0',
    author='Rosa Jimenez Valqui',
    author_email='rosajv50@gmail.com',
    description='Paquete para gestionar ventas, precios, impuestos y descuentos',
    packages=find_packages(),
    install_requires=[],
    
    python_requires='>=3.7'
)

