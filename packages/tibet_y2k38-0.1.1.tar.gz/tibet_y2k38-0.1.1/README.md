# tibet-y2k38

**Time Bridge — Where TIBET provenance meets legacy infrastructure.**

[![PyPI](https://img.shields.io/pypi/v/tibet-y2k38)](https://pypi.org/project/tibet-y2k38/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

## What This Is

TIBET gives every action provenance. JIS gives every device identity. Together, they can bridge any system — old or new — into a trusted, auditable network.

`tibet-y2k38` applies this to **time-critical infrastructure**: billions of embedded devices that speak different clock formats, different bit widths, different epochs. The bridge translates between them — and every translation carries proof.

```python
from tibet_y2k38 import TimeBridge

bridge = TimeBridge(
    device_id="jis:factory:plc-line4",
    clock_bits=32,
    profile="scada"
)

result = bridge.translate(legacy_timestamp=0x7FFFFFFF)
print(result.translated_iso)       # 2038-01-19T03:14:07+00:00
print(result.tibet_token["erin"])   # What was translated
print(result.tibet_token["erachter"])  # Why it was translated
```

**JIS** identifies the device. **TIBET** proves the translation. **The bridge** connects worlds.

## How It Works

```
Any Device (any clock)    TimeBridge             Modern System
┌──────────────┐     ┌──────────────────┐     ┌──────────────────┐
│ 32-bit PLC   │     │                  │     │                  │
│ GPS receiver │     │  JIS identity    │     │ Correct 64-bit   │
│ NTP server   │────>│  Format detect   │────>│ UTC timestamp    │
│ COBOL system │     │  Translate       │     │ with provenance  │
│ Smart meter  │     │  TIBET token     │     │                  │
└──────────────┘     └────────┬─────────┘     └──────────────────┘
                              │
                     ┌────────┴─────────┐
                     │  Audit Trail     │
                     │  ERIN: values    │
                     │  ERAAN: deps     │
                     │  EROMHEEN: ctx   │
                     │  ERACHTER: why   │
                     └──────────────────┘
```

The same router architecture works for every sector where devices can't be replaced but time must be trusted:

## 10 Sector Profiles

| Sector | Profile | Clock Format | Compliance |
|--------|---------|-------------|------------|
| **IoT** | `iot` | Unix 32-bit | CE, FCC, GDPR |
| **Industrial** | `scada` | BCD datetime | IEC 62443, NIS2 |
| **Automotive** | `automotive` | Unix 32-bit | ISO 26262, UNECE |
| **Medical** | `medical` | Unix 32-bit | FDA 21 CFR, MDR |
| **Telecom** | `telecom` | NTP 32-bit | NIS2, 3GPP, ITU-T |
| **Navigation** | `gps` | GPS week (10-bit) | ICAO, DO-229E |
| **Financial** | `banking` | COBOL packed | PCI DSS, DORA, MiFID II |
| **Energy** | `energy` | Unix 32-bit | NIS2, IEC 61850 |
| **Aviation** | `aviation` | Unix 32-bit | DO-178C, FAA, EASA |
| **Railway** | `rail` | Unix 32-bit | EN 50128, SIL 4 |

```python
from tibet_y2k38 import TimeRouter

router = TimeRouter(network_id="jis:factory:eindhoven")

# Each device gets its sector-specific configuration
router.add_device("jis:plc:line4", profile="scada")
router.add_device("jis:gps:antenna", profile="gps")
router.add_device("jis:atm:lobby", profile="banking")
router.add_device("jis:ntp:server1", profile="telecom")

# Route timestamps through the correct bridge
result = router.translate("jis:plc:line4", timestamp=0x7FFFFFFF)

# Network-wide risk and anomaly detection
print(router.status())
print(router.anomalies())
```

## Time Formats

| Format | Description | Key Dates |
|--------|-------------|-----------|
| `UNIX_SIGNED_32` | Standard signed 32-bit epoch | Overflows 2038-01-19 |
| `UNIX_UNSIGNED_32` | Unsigned 32-bit epoch | Overflows 2106-02-07 |
| `NTP_32` | NTP short format (epoch 1900) | Overflows **2036-02-07** |
| `GPS_WEEK` | 10-bit GPS week counter | Rolls every ~19.7 years |
| `FAT_TIMESTAMP` | DOS/FAT 2-second resolution | Max 2107-12-31 |
| `COBOL_PACKED` | COBOL packed decimal dates | Format dependent |
| `BCD_DATETIME` | Binary-Coded Decimal (PLCs) | Format dependent |

## Compliance

Built-in reporting for **NIS2** and **ISO/IEC 5338** — because provenance isn't optional in regulated industries.

```python
from tibet_y2k38.compliance import NIS2Reporter, ISO5338Reporter

nis2 = NIS2Reporter(router)
print(nis2.risk_assessment())
print(nis2.audit_trail_report())

iso = ISO5338Reporter(router)
print(iso.data_lineage_report())
```

TIBET provides the provenance layer that ISO 5338 requires but doesn't define *how* to implement. This bridge is that *how*.

## CLI

```bash
tibet-y2k38 info       # Countdown and overview
tibet-y2k38 demo       # Interactive demo across all sectors
tibet-y2k38 profiles   # Detailed sector profiles
tibet-y2k38 report     # JSON compliance report
```

## Installation

```bash
pip install tibet-y2k38
```

## Part of the TIBET/JIS Ecosystem

| Package | Purpose |
|---------|---------|
| [tibet-core](https://pypi.org/project/tibet-core/) | Protocol core (zero dependencies) |
| [jis-core](https://pypi.org/project/jis-core/) | Identity standard |
| [tibet-audit](https://pypi.org/project/tibet-audit/) | Audit tooling |
| [tibet-forge](https://pypi.org/project/tibet-forge/) | Code certification |
| **tibet-y2k38** | Time bridge (this package) |

**Standards:**
- IETF: [draft-vandemeent-tibet-provenance-00](https://datatracker.ietf.org/doc/draft-vandemeent-tibet-provenance/) · [draft-vandemeent-jis-identity-00](https://datatracker.ietf.org/doc/draft-vandemeent-jis-identity/)
- Zenodo: [TIBET](https://doi.org/10.5281/zenodo.18712451) · [JIS](https://doi.org/10.5281/zenodo.18712569) · [JIS/TIBET Coupling](https://doi.org/10.5281/zenodo.18712329)

## License

MIT — [Humotica AI Lab](https://humotica.com)

Authors: J. van de Meent & R. AI


---

## Enterprise

For private hub hosting, SLA support, custom integrations, or compliance guidance:

| | |
|---|---|
| **Enterprise** | enterprise@humotica.com |
| **Support** | support@humotica.com |
| **Security** | security@humotica.com |

See [ENTERPRISE.md](ENTERPRISE.md) for details.
