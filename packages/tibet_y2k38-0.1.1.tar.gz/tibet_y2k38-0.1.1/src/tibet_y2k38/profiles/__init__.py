"""
Device profiles for sector-specific time bridge configuration.

Each sector has its own:
- Time format (Unix, GPS week, NTP, COBOL, BCD, ...)
- Overflow point (2036, 2038, 2019 for GPS, ...)
- Compliance requirements (NIS2, FDA, FAA, EASA, ...)
- Typical device characteristics

The profile system means you don't need to know the details -
just tell the bridge "this is a SCADA device" and it configures itself.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class DeviceProfile:
    """Sector-specific device profile."""

    name: str
    """Profile identifier (e.g., 'scada', 'iot', 'gps')."""

    description: str
    """Human-readable description."""

    sector: str
    """Industry sector."""

    clock_bits: int = 32
    """Typical clock bit width for this sector."""

    default_format: "Any" = None  # TimeFormat enum, resolved at runtime
    """Default time format for devices in this sector."""

    epoch_offset: int = 0
    """Custom epoch offset (seconds from Unix epoch)."""

    overflow_date: str = "2038-01-19"
    """Expected overflow date (ISO format)."""

    compliance: list[str] = field(default_factory=list)
    """Applicable compliance frameworks."""

    typical_devices: list[str] = field(default_factory=list)
    """Example devices in this sector."""

    notes: str = ""
    """Sector-specific notes and warnings."""

    chip_replacement_feasible: bool = False
    """Whether physical chip replacement is realistic."""

    estimated_devices_worldwide: str = ""
    """Rough estimate of affected devices globally."""

    replacement_cost_per_unit: str = ""
    """Typical cost to replace one device."""


# Registry of all profiles
_PROFILES: dict[str, DeviceProfile] = {}


def register_profile(profile: DeviceProfile) -> None:
    """Register a device profile."""
    _PROFILES[profile.name] = profile


def get_profile(name: str) -> DeviceProfile | None:
    """Get a profile by name."""
    return _PROFILES.get(name)


def list_profiles() -> list[str]:
    """List all available profile names."""
    return list(_PROFILES.keys())


def all_profiles() -> dict[str, DeviceProfile]:
    """Get all registered profiles."""
    return dict(_PROFILES)


# --- Import and register all sector profiles ---
from .iot import profile as iot_profile
from .scada import profile as scada_profile
from .automotive import profile as automotive_profile
from .medical import profile as medical_profile
from .telecom import profile as telecom_profile
from .gps import profile as gps_profile
from .banking import profile as banking_profile
from .energy import profile as energy_profile
from .aviation import profile as aviation_profile
from .rail import profile as rail_profile

for _p in [
    iot_profile, scada_profile, automotive_profile, medical_profile,
    telecom_profile, gps_profile, banking_profile, energy_profile,
    aviation_profile, rail_profile,
]:
    register_profile(_p)

__all__ = [
    "DeviceProfile",
    "get_profile",
    "list_profiles",
    "all_profiles",
    "register_profile",
]
