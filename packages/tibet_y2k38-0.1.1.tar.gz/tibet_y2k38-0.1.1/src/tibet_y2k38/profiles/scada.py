"""SCADA / Industrial Control Systems profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="scada",
    description="SCADA systems, PLCs, and industrial controllers (Siemens, ABB, Rockwell, Schneider)",
    sector="Industrial / Manufacturing",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["IEC 62443", "NIS2", "ISO 27001", "NERC CIP"],
    typical_devices=[
        "Siemens S7-300/400 PLCs",
        "Allen-Bradley ControlLogix",
        "ABB AC500 controllers",
        "Schneider Modicon M340",
        "FANUC CNC controllers",
        "Yokogawa DCS systems",
        "Beckhoff TwinCAT PLCs",
        "Omron CP/CJ series",
    ],
    notes=(
        "Many PLCs use BCD (Binary-Coded Decimal) for timestamps. "
        "Some Siemens S7 use DATE_AND_TIME with BCD encoding. "
        "Modbus registers often carry 16-bit or 32-bit timestamps. "
        "Industrial systems run 20+ years without replacement. "
        "Downtime for upgrades costs €10k-100k per hour. "
        "Safety-critical: incorrect timestamps can cause physical harm."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="50+ million",
    replacement_cost_per_unit="€500-5,000 per PLC + downtime costs",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.BCD_DATETIME
