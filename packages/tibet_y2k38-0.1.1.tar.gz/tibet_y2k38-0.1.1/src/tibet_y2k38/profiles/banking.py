"""Banking / Financial systems profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="banking",
    description="Banking legacy - COBOL mainframes, ATMs, POS terminals, SWIFT messaging",
    sector="Financial Services",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["PCI DSS", "SOX", "MiFID II", "DORA", "NIS2", "Basel III"],
    typical_devices=[
        "IBM zSeries mainframes (COBOL)",
        "ATM controllers (NCR, Diebold)",
        "POS terminals",
        "SWIFT messaging gateways",
        "Core banking servers",
        "HSM (Hardware Security Modules)",
        "Card payment processors",
        "Check image processing systems",
    ],
    notes=(
        "COBOL systems use packed decimal dates (YYYYMMDD / YYMMDD) AND Unix "
        "timestamps for inter-system communication. Y2K was about COBOL dates; "
        "Y2K38 hits the Unix layer underneath. "
        "ATMs and POS terminals run embedded Windows/Linux with 32-bit time_t. "
        "Financial regulations require nanosecond-precision audit trails (MiFID II). "
        "Transaction timestamps are legally binding - incorrect time = invalid trade. "
        "SWIFT MT messages encode dates in YYMMDD format. "
        "Many banks still run COBOL code from the 1970s-80s."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="50+ million terminals + thousands of mainframes",
    replacement_cost_per_unit="€1,000-50,000 per terminal; mainframe migration = billions",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.COBOL_PACKED
