"""GPS / Satellite Navigation profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="gps",
    description="GPS receivers and satellite navigation - week number rollover (already happened twice!)",
    sector="Navigation / Positioning",
    clock_bits=10,  # GPS week number is 10-bit!
    epoch_offset=315964800,  # GPS epoch: Jan 6, 1980
    overflow_date="2038-11-20",  # Next 10-bit rollover
    compliance=["DO-229E", "RTCA", "ICAO", "IMO"],
    typical_devices=[
        "Consumer GPS receivers",
        "Aviation GPS (WAAS/SBAS)",
        "Maritime AIS transponders",
        "Survey-grade GNSS receivers",
        "Fleet tracking units",
        "Precision agriculture GPS",
        "Drone navigation modules",
        "Timing receivers (telecom, finance)",
    ],
    notes=(
        "GPS week number is only 10 bits (0-1023), rolling over every 1024 weeks "
        "(~19.7 years). ALREADY HAPPENED: Aug 1999 (rollover 1) and April 2019 "
        "(rollover 2). Many devices failed in 2019! Next rollover: Nov 2038. "
        "GPS is used as TIME SOURCE for other systems (telecom, finance, power grid). "
        "A GPS time error cascades to every system that syncs to it. "
        "LNAV messages use 10-bit week; CNAV uses 13-bit (8192 weeks = 157 years). "
        "Older receivers that can't be firmware-updated are vulnerable."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="4+ billion GPS receivers",
    replacement_cost_per_unit="€10-10,000 depending on application",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.GPS_WEEK
