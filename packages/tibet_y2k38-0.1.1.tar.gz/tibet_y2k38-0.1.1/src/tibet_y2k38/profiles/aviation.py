"""Aviation / Aerospace profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="aviation",
    description="Avionics, Air Traffic Control, flight data recorders, airport systems",
    sector="Aviation / Aerospace",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["DO-178C", "DO-254", "FAA AC 20-115D", "EASA CS-25", "ICAO Annex 10"],
    typical_devices=[
        "Flight Management Systems (FMS)",
        "ARINC 429 bus devices",
        "MIL-STD-1553 avionics",
        "Mode S transponders (ADS-B)",
        "ACARS messaging systems",
        "Flight Data Recorders (FDR)",
        "Air Traffic Control systems",
        "Airport baggage handling PLCs",
    ],
    notes=(
        "Aviation certification (DO-178C) is the strictest in any industry. "
        "Software changes require years of validation and millions in cost. "
        "ARINC 429 data words are 32-bit with encoded time labels. "
        "ADS-B transponders broadcast 32-bit UTC timestamps. "
        "Flight data recorders timestamp every parameter sample. "
        "ATC systems coordinate global air traffic on synchronized time. "
        "Aircraft have 30-40 year service lives - a 2010 A380 flies until 2050. "
        "Military avionics (MIL-STD-1553) deployed since the 1970s still in service."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="5+ million avionics units + ATC infrastructure",
    replacement_cost_per_unit="€10,000-1,000,000+ per LRU + FAA/EASA recertification",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.UNIX_SIGNED_32
