"""Energy / Smart Grid profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="energy",
    description="Smart meters, grid controllers, SCADA for power/gas/water utilities",
    sector="Energy / Utilities",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["NIS2", "IEC 61850", "IEC 62351", "NERC CIP", "GDPR"],
    typical_devices=[
        "Smart electricity meters (DLMS/COSEM)",
        "Distribution automation controllers",
        "Substation RTUs (Remote Terminal Units)",
        "Grid-scale battery controllers",
        "Wind turbine SCADA",
        "Solar inverter controllers",
        "Gas flow computers",
        "Water treatment PLCs",
    ],
    notes=(
        "Smart meters deployed in hundreds of millions of homes. "
        "Many use DLMS/COSEM protocol with 32-bit Unix timestamps for billing. "
        "IEC 61850 (substation automation) uses UTC time with nanosecond fields. "
        "Grid frequency regulation depends on synchronized timestamps. "
        "Regulatory frameworks (NIS2, NERC CIP) mandate timestamp integrity. "
        "Meters have 15-20 year deployment cycles - 2020 meters hit 2038. "
        "Rolling back smart meter firmware is often impossible OTA."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="500+ million smart meters + millions of grid devices",
    replacement_cost_per_unit="€50-500 per meter; grid controllers €5,000-50,000",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.UNIX_SIGNED_32
