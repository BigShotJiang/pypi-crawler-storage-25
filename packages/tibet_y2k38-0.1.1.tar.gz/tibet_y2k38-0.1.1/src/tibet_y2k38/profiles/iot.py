"""IoT / Smart Home device profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="iot",
    description="IoT sensors and smart home devices (ESP32, STM32, Arduino, Raspberry Pi Pico)",
    sector="Consumer Electronics / IoT",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["CE", "FCC", "GDPR"],
    typical_devices=[
        "ESP32 / ESP8266 sensors",
        "STM32 microcontrollers",
        "Arduino boards",
        "Zigbee/Z-Wave hubs",
        "LoRaWAN sensors",
        "Smart thermostats",
        "IP cameras",
        "Smart meters (consumer)",
    ],
    notes=(
        "Most IoT MCUs use 32-bit signed Unix timestamps via time_t. "
        "Many are deployed in unreachable locations (walls, ceilings, fields). "
        "OTA updates may not be available for older firmware. "
        "Battery-powered devices may sleep for months between wake-ups."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="15+ billion",
    replacement_cost_per_unit="€5-50 per device, but scale makes it impossible",
)

# Set default format at module level to avoid circular import
from ..bridge import TimeFormat
profile.default_format = TimeFormat.UNIX_SIGNED_32
