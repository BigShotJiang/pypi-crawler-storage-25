"""Medical device profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="medical",
    description="FDA/CE certified medical devices - monitors, pumps, imaging, lab equipment",
    sector="Healthcare / Medical",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["FDA 21 CFR Part 11", "IEC 62304", "MDR 2017/745", "HIPAA", "NIS2"],
    typical_devices=[
        "Patient monitors (Philips, GE, Dräger)",
        "Infusion pumps",
        "Ventilators",
        "Lab analyzers",
        "CT/MRI scanners",
        "PACS imaging servers",
        "Defibrillators",
        "Blood gas analyzers",
    ],
    notes=(
        "Medical devices require FDA 510(k) or CE marking - recertification "
        "takes 1-3 years and costs €100k-1M+. Firmware changes require "
        "new validation cycles. Patient safety depends on correct timestamps "
        "for medication timing, lab results, and alarm logs. "
        "DICOM imaging timestamps are critical for diagnostic accuracy. "
        "Many devices run embedded Linux or Windows XP/7 with 32-bit time_t."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="100+ million",
    replacement_cost_per_unit="€1,000-500,000 per device + recertification",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.UNIX_SIGNED_32
