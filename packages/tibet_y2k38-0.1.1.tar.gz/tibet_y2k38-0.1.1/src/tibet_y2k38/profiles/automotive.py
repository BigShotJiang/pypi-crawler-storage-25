"""Automotive ECU profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="automotive",
    description="Automotive Electronic Control Units - engine, transmission, ADAS, infotainment",
    sector="Automotive",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["ISO 26262", "UNECE R155/R156", "AUTOSAR"],
    typical_devices=[
        "Engine Control Module (ECM)",
        "Transmission Control Unit (TCU)",
        "Body Control Module (BCM)",
        "ADAS controllers",
        "Infotainment head units",
        "Telematics Control Units",
        "Battery Management Systems (BEV)",
        "CAN bus gateways",
    ],
    notes=(
        "Modern vehicles have 30-100+ ECUs, many sharing a CAN bus. "
        "CAN bus timestamps are 16-bit or 32-bit counters. "
        "Recalls for time-related issues cost manufacturers billions. "
        "Vehicles have 15-20 year lifespans - many 2020 cars will hit 2038. "
        "ISO 26262 (functional safety) requires timestamp integrity. "
        "OBD-II diagnostic timestamps are 32-bit Unix epoch."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="1+ billion ECUs (30+ per vehicle × 1.4B vehicles)",
    replacement_cost_per_unit="€100-1,000 per ECU + dealer labor",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.UNIX_SIGNED_32
