"""Telecom infrastructure profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="telecom",
    description="Telecom infrastructure - SS7, NTP, SIP, legacy switches, cell towers",
    sector="Telecommunications",
    clock_bits=32,
    overflow_date="2036-02-07",  # NTP overflow is earlier!
    compliance=["NIS2", "3GPP", "ITU-T", "ETSI"],
    typical_devices=[
        "SS7 signaling points",
        "NTP stratum servers",
        "SIP proxy servers",
        "Legacy PSTN switches",
        "Cell tower base stations (2G/3G)",
        "Diameter/RADIUS servers",
        "CDR (Call Detail Record) systems",
        "VoIP media gateways",
    ],
    notes=(
        "SS7 timestamps are 32-bit - critical for call routing and billing. "
        "NTP overflow hits EARLIER than Y2K38: Feb 7, 2036. "
        "SIP headers use text-based dates but backend often stores as 32-bit. "
        "CDR systems timestamp every call - billing depends on correct time. "
        "Telecom must maintain 99.999% uptime - no downtime for upgrades. "
        "JIS router already handles telecom identity - natural fit for time bridge. "
        "TIBET provenance proves billing accuracy for regulatory compliance."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="10+ million core network elements",
    replacement_cost_per_unit="€10,000-1,000,000+ per network element",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.NTP_32
