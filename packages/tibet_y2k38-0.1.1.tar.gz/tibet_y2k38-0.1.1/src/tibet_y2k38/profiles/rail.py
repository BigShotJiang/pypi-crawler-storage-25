"""Railway / Rail Signaling profile."""

from . import DeviceProfile

profile = DeviceProfile(
    name="rail",
    description="Railway signaling, ERTMS/ETCS, interlocking systems, passenger information",
    sector="Railway / Public Transport",
    clock_bits=32,
    overflow_date="2038-01-19",
    compliance=["EN 50128", "EN 50129", "CENELEC SIL 4", "NIS2", "ERA TSI"],
    typical_devices=[
        "ERTMS/ETCS onboard units",
        "Interlocking systems (Siemens, Alstom, Thales)",
        "Axle counters",
        "Level crossing controllers",
        "Passenger information displays",
        "Automatic Train Protection (ATP)",
        "Centralized Traffic Control (CTC)",
        "Point machines with controllers",
    ],
    notes=(
        "Railway signaling is SIL 4 (highest safety integrity level). "
        "ERTMS/ETCS (European Train Control System) uses GPS + odometry timestamps. "
        "Interlocking systems have 30+ year lifecycles. "
        "Safety certification (EN 50128/50129) makes changes extremely expensive. "
        "Balise (track transponder) data includes 32-bit timing information. "
        "Incorrect timestamps in signaling = wrong train spacing = collision risk. "
        "Legacy systems (some from the 1980s) still control major rail networks. "
        "ProRail, Network Rail, SNCF, DB Netz all face this challenge."
    ),
    chip_replacement_feasible=False,
    estimated_devices_worldwide="10+ million signaling elements worldwide",
    replacement_cost_per_unit="€5,000-500,000 per element + SIL 4 recertification",
)

from ..bridge import TimeFormat
profile.default_format = TimeFormat.UNIX_SIGNED_32
