"""
TimeRouter - Software router managing multiple TimeBridges.

The router is the central hub: it manages bridges for multiple devices,
routes incoming timestamps to the correct bridge, and maintains a
unified audit trail across all devices.

Think of it as a network switch, but for time:
- Each port = a legacy device with its own clock format
- The backplane = 64-bit reference clock
- Every packet (timestamp) gets a TIBET provenance stamp

This same router architecture works for ANY time-format mismatch:
- Y2K38 (32→64 bit Unix epoch)
- GPS week rollover (10-bit week counter)
- NTP era overflow (Feb 7, 2036)
- COBOL date formats (banking legacy)
- BCD datetime (industrial PLCs, even 16-bit)
- FAT timestamps (embedded DOS systems)
- SS7 timestamps (telecom - and you already have the JIS router!)
- Avionics time (ARINC 429, MIL-STD-1553)
- Railway signaling (ERTMS/ETCS timestamps)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .bridge import TimeBridge, BridgeResult, TimeFormat
from .provenance import Y2K38Provenance


@dataclass
class RouterStats:
    """Aggregated statistics across all bridges."""
    total_devices: int = 0
    total_translations: int = 0
    total_overflows: int = 0
    devices_at_risk: list[str] = field(default_factory=list)
    sectors: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_devices": self.total_devices,
            "total_translations": self.total_translations,
            "total_overflows": self.total_overflows,
            "devices_at_risk": self.devices_at_risk,
            "sectors": self.sectors,
        }


class TimeRouter:
    """
    Central time routing hub for heterogeneous legacy device networks.

    Manages multiple TimeBridge instances, each bound to a specific device.
    Provides unified translation, monitoring, and compliance reporting.

    Why a router instead of individual bridges?
    - Centralized audit trail (one TIBET chain for the whole network)
    - Cross-device anomaly detection (if one PLC jumps, others didn't)
    - Unified compliance reporting (NIS2, ISO 5338)
    - Device discovery and auto-profiling

    Usage:
        router = TimeRouter(network_id="jis:factory:eindhoven")

        # Register devices
        router.add_device("jis:plc:line4", profile="scada")
        router.add_device("jis:sensor:temp-hall-a", profile="iot")
        router.add_device("jis:gps:roof-antenna", profile="gps")

        # Route incoming timestamps
        result = router.translate("jis:plc:line4", timestamp=0x7FFFFFFF)

        # Network-wide status
        print(router.status())
    """

    def __init__(
        self,
        network_id: str = "jis:network:default",
        store=None,
        risk_threshold_days: float = 365.0,
    ):
        """
        Args:
            network_id: JIS identity for this router/network
            store: Optional tibet_core.FileStore for persistent audit
            risk_threshold_days: Days before overflow to flag as at-risk
        """
        self.network_id = network_id
        self.store = store
        self.risk_threshold_days = risk_threshold_days

        self._bridges: dict[str, TimeBridge] = {}
        self._provenance = Y2K38Provenance(actor=network_id, store=store)
        self._translation_log: list[dict[str, Any]] = []

    def add_device(
        self,
        device_id: str,
        *,
        profile: str | None = None,
        clock_bits: int = 32,
        time_format: TimeFormat = TimeFormat.UNIX_SIGNED_32,
        signed: bool = True,
        epoch_offset: int = 0,
        metadata: dict[str, Any] | None = None,
    ) -> TimeBridge:
        """
        Register a device with this router.

        Args:
            device_id: JIS identity (e.g., "jis:factory:plc-line4")
            profile: Device profile ("iot", "scada", "gps", etc.)
            clock_bits: Bit width of device clock
            time_format: Expected timestamp format
            signed: Whether device uses signed integers
            epoch_offset: Custom epoch offset
            metadata: Additional device metadata (firmware, location, etc.)

        Returns:
            The created TimeBridge instance
        """
        bridge = TimeBridge(
            device_id=device_id,
            clock_bits=clock_bits,
            profile=profile,
            time_format=time_format,
            signed=signed,
            epoch_offset=epoch_offset,
            store=self.store,
        )
        self._bridges[device_id] = bridge
        return bridge

    def translate(
        self,
        device_id: str,
        timestamp: int,
        *,
        era_hint: int | None = None,
        context: dict[str, Any] | None = None,
    ) -> BridgeResult:
        """
        Route a timestamp through the correct bridge.

        Args:
            device_id: JIS identity of the source device
            timestamp: Raw timestamp value from the device
            era_hint: Override era detection
            context: Additional TIBET context

        Returns:
            BridgeResult with translated time and provenance

        Raises:
            KeyError: If device_id is not registered
        """
        if device_id not in self._bridges:
            raise KeyError(
                f"Device {device_id} not registered. "
                f"Use router.add_device('{device_id}') first."
            )

        bridge = self._bridges[device_id]
        result = bridge.translate(
            legacy_timestamp=timestamp,
            era_hint=era_hint,
            context=context,
        )

        # Log for anomaly detection
        self._translation_log.append({
            "device_id": device_id,
            "original": timestamp,
            "translated": result.translated_timestamp,
            "overflow": result.overflow_detected,
            "confidence": result.confidence,
            "time": time.time(),
        })

        return result

    def translate_batch(
        self,
        translations: list[tuple[str, int]],
    ) -> list[BridgeResult]:
        """
        Translate multiple timestamps in batch.

        Args:
            translations: List of (device_id, timestamp) tuples

        Returns:
            List of BridgeResults
        """
        return [
            self.translate(device_id, ts)
            for device_id, ts in translations
        ]

    def status(self) -> RouterStats:
        """Get network-wide status and risk assessment."""
        stats = RouterStats()
        stats.total_devices = len(self._bridges)

        for device_id, bridge in self._bridges.items():
            bridge_stats = bridge.stats
            stats.total_translations += bridge_stats["translations"]
            stats.total_overflows += bridge_stats["overflows_detected"]

            # Track sectors
            profile = bridge_stats.get("profile") or "unknown"
            stats.sectors[profile] = stats.sectors.get(profile, 0) + 1

            # Risk assessment
            days = bridge.days_until_overflow()
            if days < self.risk_threshold_days:
                stats.devices_at_risk.append(device_id)

        return stats

    def at_risk_devices(self) -> list[dict[str, Any]]:
        """Get detailed info on devices approaching overflow."""
        devices = []
        for device_id, bridge in self._bridges.items():
            days = bridge.days_until_overflow()
            if days < self.risk_threshold_days:
                devices.append({
                    "device_id": device_id,
                    "days_until_overflow": days,
                    "profile": bridge.profile_name,
                    "format": bridge.time_format.value,
                    "clock_bits": bridge.clock_bits,
                    "translations_so_far": bridge.stats["translations"],
                })
        return sorted(devices, key=lambda d: d["days_until_overflow"])

    def anomalies(self, window_seconds: float = 60.0) -> list[dict[str, Any]]:
        """
        Detect time anomalies across the network.

        Looks for devices reporting timestamps that don't align with
        their peers - a sign of overflow, drift, or tampering.
        """
        now = time.time()
        recent = [
            log for log in self._translation_log
            if now - log["time"] < window_seconds
        ]

        if len(recent) < 2:
            return []

        # Calculate median translated time
        translated_times = [log["translated"] for log in recent]
        translated_times.sort()
        median = translated_times[len(translated_times) // 2]

        # Flag outliers (>1 hour deviation from median)
        anomalies = []
        for log in recent:
            deviation = abs(log["translated"] - median)
            if deviation > 3600:  # 1 hour
                anomalies.append({
                    "device_id": log["device_id"],
                    "expected_near": median,
                    "actual": log["translated"],
                    "deviation_seconds": deviation,
                    "severity": "critical" if deviation > 86400 else "warning",
                })

        return anomalies

    def export_audit(self) -> list[dict[str, Any]]:
        """Export the complete translation audit log."""
        return list(self._translation_log)

    @property
    def devices(self) -> list[str]:
        """List all registered device IDs."""
        return list(self._bridges.keys())

    def __len__(self) -> int:
        return len(self._bridges)

    def __repr__(self) -> str:
        stats = self.status()
        return (
            f"TimeRouter(network={self.network_id}, "
            f"devices={stats.total_devices}, "
            f"translations={stats.total_translations}, "
            f"at_risk={len(stats.devices_at_risk)})"
        )
