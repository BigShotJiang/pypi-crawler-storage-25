"""
NIS2 Compliance Reporter.

Generates reports aligned with EU NIS2 directive requirements:
- Asset inventory (which devices, what risk)
- Incident response readiness (overflow detection)
- Supply chain security (provenance of time translations)
- Audit trail completeness
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from ..router import TimeRouter


class NIS2Reporter:
    """
    Generate NIS2-compliant reports from TimeRouter data.

    NIS2 (Directive 2022/2555) requires:
    - Art. 21: Risk management measures
    - Art. 23: Incident reporting (24h/72h)
    - Art. 21(2)(d): Supply chain security

    TIBET provenance tokens satisfy the audit trail requirements.
    JIS identities satisfy the asset inventory requirements.
    """

    def __init__(self, router: "TimeRouter"):
        self.router = router

    def asset_inventory(self) -> dict[str, Any]:
        """
        NIS2 Art. 21(2)(a): Asset inventory of time-critical systems.

        Maps all registered devices with their risk profiles.
        """
        devices = []
        for device_id in self.router.devices:
            bridge = self.router._bridges[device_id]
            stats = bridge.stats
            devices.append({
                "jis_identity": device_id,
                "clock_bits": stats["clock_bits"],
                "profile": stats["profile"],
                "time_format": stats["format"],
                "days_until_overflow": bridge.days_until_overflow(),
                "translations_processed": stats["translations"],
                "overflows_detected": stats["overflows_detected"],
            })

        return {
            "report_type": "NIS2 Asset Inventory - Time-Critical Systems",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "network_id": self.router.network_id,
            "total_devices": len(devices),
            "devices": devices,
        }

    def risk_assessment(self) -> dict[str, Any]:
        """
        NIS2 Art. 21(2): Risk management measures.

        Categorizes devices by overflow risk level.
        """
        at_risk = self.router.at_risk_devices()
        status = self.router.status()

        return {
            "report_type": "NIS2 Risk Assessment - Y2K38 Overflow",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "network_id": self.router.network_id,
            "risk_summary": {
                "total_devices": status.total_devices,
                "devices_at_risk": len(at_risk),
                "total_overflows_detected": status.total_overflows,
                "sectors_affected": status.sectors,
            },
            "at_risk_devices": at_risk,
            "mitigation": "tibet-y2k38 software bridge active - all translations provenance-tracked",
        }

    def incident_report(self, device_id: str, overflow_details: dict) -> dict[str, Any]:
        """
        NIS2 Art. 23: Incident reporting template.

        For when an overflow is actually detected - generates the
        24-hour early warning and 72-hour incident report structure.
        """
        return {
            "report_type": "NIS2 Incident Report - Time Overflow Event",
            "severity": "significant",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "early_warning_deadline": "24 hours from detection",
            "full_report_deadline": "72 hours from detection",
            "affected_device": device_id,
            "network_id": self.router.network_id,
            "incident_details": overflow_details,
            "mitigation_status": "ACTIVE - tibet-y2k38 bridge compensating",
            "provenance_chain": "Available via TIBET audit trail",
            "cross_border_impact": "To be assessed based on device function",
        }

    def audit_trail_report(self) -> dict[str, Any]:
        """
        NIS2 Art. 21(2)(d): Supply chain / audit trail report.

        Proves that all time translations are provenance-tracked
        via TIBET tokens.
        """
        audit_log = self.router.export_audit()
        return {
            "report_type": "NIS2 Audit Trail - Time Bridge Operations",
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "network_id": self.router.network_id,
            "provenance_protocol": "TIBET (Time Intent Based Event Token)",
            "identity_protocol": "JIS (JTel Identity Standard)",
            "total_translations": len(audit_log),
            "all_translations_tokenized": True,
            "token_integrity": "SHA-256 content hashing",
            "chain_integrity": "Parent-child linked provenance chain",
            "recent_translations": audit_log[-10:] if audit_log else [],
        }

    def full_report(self) -> dict[str, Any]:
        """Generate complete NIS2 compliance report."""
        return {
            "nis2_compliance_report": {
                "asset_inventory": self.asset_inventory(),
                "risk_assessment": self.risk_assessment(),
                "audit_trail": self.audit_trail_report(),
            },
            "report_metadata": {
                "framework": "EU NIS2 Directive (2022/2555)",
                "tool": "tibet-y2k38",
                "tibet_protocol": "draft-vandemeent-tibet-provenance-00",
                "jis_protocol": "draft-vandemeent-jis-identity-00",
            },
        }
