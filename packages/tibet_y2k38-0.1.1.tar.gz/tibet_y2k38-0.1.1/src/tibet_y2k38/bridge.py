"""
TimeBridge - Core 32↔64 bit time translation engine.

The bridge intercepts 32-bit timestamps from legacy devices and translates
them to 64-bit, creating a TIBET provenance token for every translation.

The key insight: you don't need to replace the chip. You need a router
that understands the chip's limitations and compensates with provenance.
"""

from __future__ import annotations

import struct
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

from .provenance import Y2K38Provenance

# The epoch overflow point: 2038-01-19 03:14:07 UTC
Y2K38_EPOCH = 2_147_483_647  # 0x7FFFFFFF - max signed 32-bit int
Y2K38_UNSIGNED_MAX = 4_294_967_295  # 0xFFFFFFFF - max unsigned 32-bit int
Y2K38_DATE = datetime(2038, 1, 19, 3, 14, 7, tzinfo=timezone.utc)


class TimeFormat(Enum):
    """Time representation formats encountered in legacy systems."""
    UNIX_SIGNED_32 = "unix_signed_32"       # Standard Unix epoch (signed int32)
    UNIX_UNSIGNED_32 = "unix_unsigned_32"    # Unsigned 32-bit (overflows 2106)
    NTP_32 = "ntp_32"                       # NTP short format (epoch 1900)
    GPS_WEEK = "gps_week"                   # GPS week number (10-bit rollover)
    FAT_TIMESTAMP = "fat_timestamp"         # DOS/FAT 2-second resolution
    COBOL_PACKED = "cobol_packed"           # COBOL packed decimal dates
    BCD_DATETIME = "bcd_datetime"           # Binary-coded decimal (PLCs)
    CUSTOM = "custom"                       # Device-specific format


@dataclass
class BridgeResult:
    """Result of a time translation with full provenance."""

    original_value: int
    """Raw value from the legacy device."""

    original_bits: int
    """Bit width of the original timestamp (typically 32)."""

    translated_timestamp: float
    """64-bit Unix timestamp (the correct time)."""

    translated_iso: str
    """ISO 8601 formatted datetime string."""

    overflow_detected: bool
    """Whether the original value was in overflow territory."""

    overflow_count: int
    """Number of 32-bit epoch rollovers since Unix epoch."""

    format_used: TimeFormat
    """The time format that was decoded."""

    device_id: str
    """JIS identity of the source device."""

    tibet_token: dict[str, Any] | None = None
    """TIBET provenance token for this translation."""

    confidence: float = 1.0
    """Confidence in the translation (0.0-1.0). Lower if heuristics were used."""

    warnings: list[str] = field(default_factory=list)
    """Any warnings about the translation."""

    def __repr__(self) -> str:
        status = "OVERFLOW" if self.overflow_detected else "OK"
        return (
            f"BridgeResult({self.translated_iso} [{status}] "
            f"device={self.device_id} confidence={self.confidence:.2f})"
        )


class TimeBridge:
    """
    Software bridge for 32→64 bit time translation.

    Each bridge instance is bound to a specific device (via JIS identity)
    and creates TIBET provenance tokens for every translation.

    Args:
        device_id: JIS identity string (e.g., "jis:factory:plc-line4")
        clock_bits: Bit width of the device clock (default: 32)
        profile: Device profile name (e.g., "scada", "iot", "gps")
        time_format: Expected time format from device
        signed: Whether the device uses signed integers (default: True)
        epoch_offset: Custom epoch offset in seconds (0 = Unix epoch)
        store: Optional TIBET FileStore for persistent audit trail
    """

    def __init__(
        self,
        device_id: str,
        clock_bits: int = 32,
        profile: str | None = None,
        time_format: TimeFormat = TimeFormat.UNIX_SIGNED_32,
        signed: bool = True,
        epoch_offset: int = 0,
        store=None,
    ):
        self.device_id = device_id
        self.clock_bits = clock_bits
        self.profile_name = profile
        self.time_format = time_format
        self.signed = signed
        self.epoch_offset = epoch_offset

        # Load profile defaults if specified
        if profile:
            from .profiles import get_profile
            prof = get_profile(profile)
            if prof:
                if time_format == TimeFormat.UNIX_SIGNED_32:
                    self.time_format = prof.default_format
                if not epoch_offset:
                    self.epoch_offset = prof.epoch_offset
                if clock_bits == 32:
                    self.clock_bits = prof.clock_bits

        # TIBET provenance engine
        self.provenance = Y2K38Provenance(
            actor=device_id,
            store=store,
        )

        # Translation counters
        self._translations = 0
        self._overflows_detected = 0

        # Current assumed epoch rollover count
        # This is critical: after Y2K38, we need to know which
        # "era" the device thinks it's in
        self._assumed_era = self._detect_era()

    def _detect_era(self) -> int:
        """
        Detect which 32-bit epoch era we're currently in.

        Era 0: 1970-01-01 to 2038-01-19 (before overflow)
        Era 1: 2038-01-19 to 2106-02-07 (first overflow)
        Era N: subsequent rollovers (unsigned) or wrap-arounds
        """
        now = time.time()
        if self.signed:
            return int(now // (Y2K38_EPOCH + 1))
        else:
            return int(now // (Y2K38_UNSIGNED_MAX + 1))

    def translate(
        self,
        legacy_timestamp: int,
        *,
        era_hint: int | None = None,
        context: dict[str, Any] | None = None,
    ) -> BridgeResult:
        """
        Translate a legacy 32-bit timestamp to 64-bit with provenance.

        Args:
            legacy_timestamp: Raw timestamp value from the device
            era_hint: Override era detection (if you know which rollover cycle)
            context: Additional TIBET eromheen context

        Returns:
            BridgeResult with translated time and TIBET token
        """
        warnings: list[str] = []
        overflow_detected = False
        confidence = 1.0

        era = era_hint if era_hint is not None else self._assumed_era

        # --- Format-specific decoding ---
        if self.time_format == TimeFormat.GPS_WEEK:
            translated, overflow_detected, confidence, fmt_warnings = (
                self._translate_gps(legacy_timestamp, era)
            )
            warnings.extend(fmt_warnings)
        elif self.time_format == TimeFormat.NTP_32:
            translated, overflow_detected, confidence, fmt_warnings = (
                self._translate_ntp(legacy_timestamp, era)
            )
            warnings.extend(fmt_warnings)
        elif self.time_format == TimeFormat.FAT_TIMESTAMP:
            translated, overflow_detected, confidence, fmt_warnings = (
                self._translate_fat(legacy_timestamp)
            )
            warnings.extend(fmt_warnings)
        elif self.time_format == TimeFormat.COBOL_PACKED:
            translated, overflow_detected, confidence, fmt_warnings = (
                self._translate_cobol(legacy_timestamp)
            )
            warnings.extend(fmt_warnings)
        elif self.time_format == TimeFormat.BCD_DATETIME:
            translated, overflow_detected, confidence, fmt_warnings = (
                self._translate_bcd(legacy_timestamp)
            )
            warnings.extend(fmt_warnings)
        else:
            # Standard Unix epoch (signed or unsigned 32-bit)
            translated, overflow_detected, confidence, fmt_warnings = (
                self._translate_unix(legacy_timestamp, era)
            )
            warnings.extend(fmt_warnings)

        # Apply custom epoch offset
        translated += self.epoch_offset

        # Generate ISO string
        try:
            dt = datetime.fromtimestamp(translated, tz=timezone.utc)
            iso_str = dt.isoformat()
        except (OSError, OverflowError, ValueError):
            iso_str = f"EPOCH:{translated}"
            warnings.append("Timestamp outside representable datetime range")
            confidence *= 0.5

        # Update counters
        self._translations += 1
        if overflow_detected:
            self._overflows_detected += 1

        # Create TIBET provenance token
        tibet_token = self.provenance.create_translation_token(
            original_value=legacy_timestamp,
            translated_value=translated,
            device_id=self.device_id,
            format_used=self.time_format.value,
            overflow_detected=overflow_detected,
            era=era,
            confidence=confidence,
            profile=self.profile_name,
            context=context,
        )

        return BridgeResult(
            original_value=legacy_timestamp,
            original_bits=self.clock_bits,
            translated_timestamp=translated,
            translated_iso=iso_str,
            overflow_detected=overflow_detected,
            overflow_count=era,
            format_used=self.time_format,
            device_id=self.device_id,
            tibet_token=tibet_token,
            confidence=confidence,
            warnings=warnings,
        )

    def _translate_unix(
        self, value: int, era: int
    ) -> tuple[float, bool, float, list[str]]:
        """Translate standard Unix 32-bit timestamp."""
        warnings: list[str] = []
        overflow = False

        if self.signed:
            max_val = Y2K38_EPOCH
            # Check for negative (wrapped) values
            if value < 0:
                # Device has overflowed - signed wrap-around
                overflow = True
                translated = float((era * (max_val + 1)) + (max_val + 1 + value))
                warnings.append(
                    f"Signed overflow detected: device reports negative timestamp {value}"
                )
            elif era > 0:
                # We're past 2038 but device reports a positive value
                # Could be: device is still in pre-overflow range, or it wrapped
                now = time.time()
                direct = float(value)
                era_adjusted = float(era * (max_val + 1) + value)

                # Heuristic: if direct interpretation is far in the past, use era
                if abs(now - era_adjusted) < abs(now - direct):
                    translated = era_adjusted
                    overflow = True
                    warnings.append(
                        f"Era {era} adjustment applied: device value {value} "
                        f"mapped to {era_adjusted:.0f}"
                    )
                else:
                    translated = direct
            else:
                translated = float(value)
        else:
            max_val = Y2K38_UNSIGNED_MAX
            translated = float(era * (max_val + 1) + value)
            if era > 0:
                overflow = True
                warnings.append(f"Unsigned era {era}: value {value}")

        confidence = 0.7 if overflow else 1.0
        return translated, overflow, confidence, warnings

    def _translate_gps(
        self, value: int, era: int
    ) -> tuple[float, bool, float, list[str]]:
        """
        Translate GPS week number.

        GPS week number is 10-bit (0-1023), rolling over every ~19.7 years.
        First rollover: Aug 21, 1999. Second: April 6, 2019.
        Next: Nov 20, 2038.
        """
        GPS_EPOCH = 315964800  # Jan 6, 1980 00:00:00 UTC
        WEEK_SECONDS = 604800
        ROLLOVER_WEEKS = 1024

        warnings: list[str] = []

        # Determine rollover era from current date
        if era == 0:
            now = time.time()
            weeks_since_gps = (now - GPS_EPOCH) / WEEK_SECONDS
            era = int(weeks_since_gps / ROLLOVER_WEEKS)

        actual_weeks = (era * ROLLOVER_WEEKS) + value
        translated = float(GPS_EPOCH + (actual_weeks * WEEK_SECONDS))
        overflow = era > 0

        if overflow:
            warnings.append(
                f"GPS week rollover era {era}: week {value} → absolute week {actual_weeks}"
            )

        return translated, overflow, 0.95 if overflow else 1.0, warnings

    def _translate_ntp(
        self, value: int, era: int
    ) -> tuple[float, bool, float, list[str]]:
        """
        Translate NTP 32-bit timestamp.
        NTP epoch: Jan 1, 1900. Overflows Feb 7, 2036.
        """
        NTP_UNIX_DELTA = 2208988800  # seconds between 1900 and 1970
        NTP_MAX = Y2K38_UNSIGNED_MAX

        warnings: list[str] = []
        translated = float((era * (NTP_MAX + 1)) + value) - NTP_UNIX_DELTA
        overflow = era > 0

        if overflow:
            warnings.append(f"NTP era {era}: timestamp wrapped")

        return translated, overflow, 0.9 if overflow else 1.0, warnings

    def _translate_fat(
        self, value: int
    ) -> tuple[float, bool, float, list[str]]:
        """
        Translate DOS/FAT timestamp (2-second resolution, epoch 1980).
        Max date: 2107-12-31 (no overflow issue, but limited resolution).
        """
        warnings: list[str] = []

        second = (value & 0x1F) * 2
        minute = (value >> 5) & 0x3F
        hour = (value >> 11) & 0x1F
        day = (value >> 16) & 0x1F
        month = (value >> 21) & 0x0F
        year = ((value >> 25) & 0x7F) + 1980

        try:
            dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
            translated = dt.timestamp()
        except ValueError:
            translated = 0.0
            warnings.append(f"Invalid FAT timestamp: {value:#x}")

        return translated, False, 1.0, warnings

    def _translate_cobol(
        self, value: int
    ) -> tuple[float, bool, float, list[str]]:
        """
        Translate COBOL packed decimal date (YYYYMMDD or YYMMDD format).
        Y2K was about 2-digit years. Y2K38 hits COBOL systems using Unix calls.
        """
        warnings: list[str] = []
        s = str(value)

        if len(s) == 8:  # YYYYMMDD
            year, month, day = int(s[:4]), int(s[4:6]), int(s[6:8])
        elif len(s) == 6:  # YYMMDD
            yy = int(s[:2])
            year = 2000 + yy if yy < 70 else 1900 + yy
            month, day = int(s[2:4]), int(s[4:6])
            warnings.append(f"2-digit year {yy} interpreted as {year}")
        else:
            warnings.append(f"Unknown COBOL date format: {value}")
            return 0.0, False, 0.3, warnings

        try:
            dt = datetime(year, month, day, tzinfo=timezone.utc)
            translated = dt.timestamp()
        except ValueError:
            translated = 0.0
            warnings.append(f"Invalid COBOL date: {year}-{month}-{day}")

        return translated, False, 0.9, warnings

    def _translate_bcd(
        self, value: int
    ) -> tuple[float, bool, float, list[str]]:
        """
        Translate BCD (Binary-Coded Decimal) datetime from PLCs.
        Format: 7 bytes packed as integer - YY MM DD HH MM SS WD
        """
        warnings: list[str] = []

        def bcd_byte(v: int, shift: int) -> int:
            b = (v >> shift) & 0xFF
            return ((b >> 4) * 10) + (b & 0x0F)

        try:
            yy = bcd_byte(value, 48)
            month = bcd_byte(value, 40)
            day = bcd_byte(value, 32)
            hour = bcd_byte(value, 24)
            minute = bcd_byte(value, 16)
            second = bcd_byte(value, 8)

            year = 2000 + yy if yy < 70 else 1900 + yy
            dt = datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)
            translated = dt.timestamp()
        except (ValueError, OverflowError):
            translated = 0.0
            warnings.append(f"Invalid BCD datetime: {value:#x}")

        return translated, False, 0.85, warnings

    @property
    def stats(self) -> dict[str, Any]:
        """Bridge statistics."""
        return {
            "device_id": self.device_id,
            "clock_bits": self.clock_bits,
            "profile": self.profile_name,
            "format": self.time_format.value,
            "translations": self._translations,
            "overflows_detected": self._overflows_detected,
            "current_era": self._assumed_era,
        }

    def days_until_overflow(self) -> float:
        """Days remaining until this device's clock overflows."""
        if self.time_format == TimeFormat.GPS_WEEK:
            # Next GPS rollover
            GPS_EPOCH = 315964800
            WEEK_SECONDS = 604800
            next_rollover_week = (self._assumed_era + 1) * 1024
            next_rollover = GPS_EPOCH + (next_rollover_week * WEEK_SECONDS)
            return (next_rollover - time.time()) / 86400
        elif self.time_format == TimeFormat.NTP_32:
            # NTP era 1 starts Feb 7, 2036
            NTP_ERA1 = 2085978496  # Unix timestamp of NTP era 1
            return (NTP_ERA1 - time.time()) / 86400
        else:
            # Unix signed 32-bit
            return (Y2K38_EPOCH - time.time()) / 86400

    def __repr__(self) -> str:
        days = self.days_until_overflow()
        return (
            f"TimeBridge(device={self.device_id}, bits={self.clock_bits}, "
            f"profile={self.profile_name}, overflow_in={days:.0f}d)"
        )
