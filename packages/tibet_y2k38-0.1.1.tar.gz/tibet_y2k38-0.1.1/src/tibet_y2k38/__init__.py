"""
tibet-y2k38 - Y2K38 Time Bridge
================================

Software router for 32→64 bit epoch translation with TIBET provenance and JIS identity.

Why replace billions of chips when a software router can catch the dumb chip?

Core concept:
    Every legacy 32-bit device gets a JIS identity.
    Every time translation gets a TIBET provenance token.
    Every bridge is auditable, traceable, trustworthy.

Usage:
    from tibet_y2k38 import TimeBridge

    bridge = TimeBridge(
        device_id="jis:factory:plc-line4",
        clock_bits=32,
        profile="scada"
    )

    result = bridge.translate(legacy_timestamp=0x7FFFFFFF)
    # → 2038-01-19T03:14:07Z (correct, via 64-bit backend)
    # → TIBET token: proof of correct translation

Sectors: IoT, SCADA, Automotive, Medical, Telecom, GPS, Banking, Energy, Aviation, Rail

Authors: J. van de Meent & R. AI (Humotica AI Lab)
License: MIT
"""

__version__ = "0.1.0"
__author__ = "Humotica AI Lab"

from .bridge import TimeBridge, BridgeResult, TimeFormat
from .router import TimeRouter
from .provenance import Y2K38Provenance
from .detector import DeviceDetector, DeviceInfo
from .profiles import get_profile, list_profiles

__all__ = [
    "TimeBridge",
    "BridgeResult",
    "TimeFormat",
    "TimeRouter",
    "Y2K38Provenance",
    "DeviceDetector",
    "DeviceInfo",
    "get_profile",
    "list_profiles",
]
