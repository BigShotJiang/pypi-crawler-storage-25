"""
DeviceDetector - Scan networks for 32-bit time-vulnerable devices.

Discovers legacy devices and assesses their Y2K38 risk profile.
Each discovered device gets a JIS identity and risk score.
"""

from __future__ import annotations

import socket
import struct
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class DeviceInfo:
    """Information about a discovered legacy device."""

    address: str
    """Network address (IP, serial port, bus address)."""

    device_id: str
    """Assigned JIS identity."""

    clock_bits: int = 32
    """Detected clock bit width."""

    suggested_profile: str = "generic"
    """Suggested device profile based on detection."""

    time_format: str = "unix_signed_32"
    """Detected time format."""

    risk_level: str = "unknown"
    """Risk level: low, medium, high, critical."""

    days_until_overflow: float = 0.0
    """Estimated days until this device overflows."""

    firmware: str = ""
    """Detected firmware version if available."""

    protocol: str = ""
    """Communication protocol (modbus, snmp, bacnet, etc.)."""

    metadata: dict[str, Any] = field(default_factory=dict)
    """Additional detection metadata."""

    def __repr__(self) -> str:
        return (
            f"DeviceInfo({self.address}, profile={self.suggested_profile}, "
            f"risk={self.risk_level}, overflow_in={self.days_until_overflow:.0f}d)"
        )


class DeviceDetector:
    """
    Scan for 32-bit time-vulnerable devices on a network.

    Supports multiple discovery protocols:
    - SNMP sysDescr (network devices, servers)
    - Modbus device ID (PLCs, SCADA)
    - mDNS/Bonjour (IoT)
    - Manual registration

    Usage:
        detector = DeviceDetector(network="192.168.4.0/24")

        # Quick scan
        devices = detector.scan_snmp()

        # Or manual registration
        detector.register(
            address="192.168.4.50",
            device_id="jis:factory:plc-siemens-s7",
            profile="scada",
            firmware="S7-300 v4.2"
        )

        # Risk report
        for device in detector.at_risk():
            print(f"{device.device_id}: {device.days_until_overflow:.0f} days left")
    """

    def __init__(self, network: str | None = None):
        self.network = network
        self._devices: list[DeviceInfo] = []

    def register(
        self,
        address: str,
        device_id: str,
        profile: str = "generic",
        clock_bits: int = 32,
        time_format: str = "unix_signed_32",
        firmware: str = "",
        protocol: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> DeviceInfo:
        """
        Manually register a known device.

        For devices that can't be auto-discovered (air-gapped, serial, etc.)
        """
        from .bridge import Y2K38_EPOCH

        # Calculate risk
        if time_format == "unix_signed_32":
            days_left = (Y2K38_EPOCH - time.time()) / 86400
        elif time_format == "gps_week":
            # Next GPS rollover: ~Nov 2038
            days_left = (2174169600 - time.time()) / 86400
        elif time_format == "ntp_32":
            # NTP overflow: Feb 7, 2036
            days_left = (2085978496 - time.time()) / 86400
        else:
            days_left = (Y2K38_EPOCH - time.time()) / 86400

        if days_left < 365:
            risk = "critical"
        elif days_left < 365 * 3:
            risk = "high"
        elif days_left < 365 * 5:
            risk = "medium"
        else:
            risk = "low"

        device = DeviceInfo(
            address=address,
            device_id=device_id,
            clock_bits=clock_bits,
            suggested_profile=profile,
            time_format=time_format,
            risk_level=risk,
            days_until_overflow=days_left,
            firmware=firmware,
            protocol=protocol,
            metadata=metadata or {},
        )
        self._devices.append(device)
        return device

    def scan_ntp(self, targets: list[str] | None = None) -> list[DeviceInfo]:
        """
        Probe NTP servers to check their timestamp bit width.

        Sends NTP request and checks if response timestamp is in
        Era 0 (32-bit) or uses NTP extension fields (64-bit aware).
        """
        results = []
        probe_targets = targets or []

        for target in probe_targets:
            try:
                # NTP v4 request packet (48 bytes)
                # LI=0, VN=4, Mode=3 (client)
                ntp_packet = b'\x23' + b'\x00' * 47

                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(2.0)
                sock.sendto(ntp_packet, (target, 123))

                data, addr = sock.recvfrom(48)
                sock.close()

                if len(data) >= 48:
                    # Extract transmit timestamp (bytes 40-47)
                    tx_seconds = struct.unpack('!I', data[40:44])[0]
                    # NTP epoch: Jan 1, 1900
                    NTP_UNIX_DELTA = 2208988800
                    unix_time = tx_seconds - NTP_UNIX_DELTA

                    device = self.register(
                        address=target,
                        device_id=f"jis:ntp:{target.replace('.', '-')}",
                        profile="telecom",
                        time_format="ntp_32",
                        protocol="ntp",
                        metadata={"ntp_stratum": data[1], "raw_tx": tx_seconds},
                    )
                    results.append(device)

            except (socket.error, struct.error, OSError):
                continue

        return results

    def at_risk(self, threshold_days: float = 365 * 5) -> list[DeviceInfo]:
        """Get devices at risk of overflow within threshold."""
        return sorted(
            [d for d in self._devices if d.days_until_overflow < threshold_days],
            key=lambda d: d.days_until_overflow,
        )

    def by_profile(self, profile: str) -> list[DeviceInfo]:
        """Filter devices by profile."""
        return [d for d in self._devices if d.suggested_profile == profile]

    def risk_summary(self) -> dict[str, Any]:
        """Network-wide risk summary."""
        summary: dict[str, int] = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        profiles: dict[str, int] = {}

        for device in self._devices:
            summary[device.risk_level] = summary.get(device.risk_level, 0) + 1
            profiles[device.suggested_profile] = (
                profiles.get(device.suggested_profile, 0) + 1
            )

        return {
            "total_devices": len(self._devices),
            "risk_distribution": summary,
            "profiles": profiles,
            "most_urgent": self._devices[0].device_id if self._devices else None,
        }

    @property
    def devices(self) -> list[DeviceInfo]:
        return list(self._devices)

    def __len__(self) -> int:
        return len(self._devices)
