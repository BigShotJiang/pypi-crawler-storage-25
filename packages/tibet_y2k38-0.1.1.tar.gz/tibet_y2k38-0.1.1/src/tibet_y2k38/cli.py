"""
CLI for tibet-y2k38.

Commands:
    tibet-y2k38 demo     - Run interactive demo
    tibet-y2k38 scan     - Scan for at-risk devices
    tibet-y2k38 profiles - List available sector profiles
    tibet-y2k38 report   - Generate compliance report
    tibet-y2k38 info     - Show Y2K38 countdown and stats
"""

from __future__ import annotations

import json
import sys
import time
from datetime import datetime, timezone

from .bridge import TimeBridge, Y2K38_EPOCH, Y2K38_DATE, TimeFormat
from .router import TimeRouter
from .detector import DeviceDetector
from .profiles import list_profiles, all_profiles


def main():
    """Main CLI entry point."""
    args = sys.argv[1:]
    command = args[0] if args else "info"

    if command == "demo":
        run_demo()
    elif command == "scan":
        run_scan()
    elif command == "profiles":
        show_profiles()
    elif command == "report":
        run_report()
    elif command == "info":
        show_info()
    elif command in ("-h", "--help", "help"):
        show_help()
    else:
        print(f"Unknown command: {command}")
        show_help()


def scan_main():
    """Entry point for y2k38-scan command."""
    run_scan()


def show_info():
    """Show Y2K38 countdown and overview."""
    now = time.time()
    days_left = (Y2K38_EPOCH - now) / 86400
    years_left = days_left / 365.25

    print("=" * 60)
    print("  tibet-y2k38 - Y2K38 Time Bridge")
    print("  Software router for legacy time-critical systems")
    print("=" * 60)
    print()
    print(f"  Y2K38 Overflow:  {Y2K38_DATE.strftime('%B %d, %Y at %H:%M:%S UTC')}")
    print(f"  Days remaining:  {days_left:,.0f} days ({years_left:.1f} years)")
    print(f"  Max signed 32b:  {Y2K38_EPOCH} (0x7FFFFFFF)")
    print()
    print(f"  Sector profiles: {len(list_profiles())}")
    print(f"  Profiles:        {', '.join(list_profiles())}")
    print()
    print("  Protocols:")
    print("    TIBET: draft-vandemeent-tibet-provenance-00")
    print("    JIS:   draft-vandemeent-jis-identity-00")
    print()
    print("  Why replace billions of chips when a software")
    print("  router can catch the dumb chip?")
    print()
    print("  Run: tibet-y2k38 demo    - Interactive demonstration")
    print("  Run: tibet-y2k38 profiles - Show all sector profiles")
    print()
    print("  Humotica AI Lab - humotica.com")
    print("=" * 60)


def show_help():
    """Show CLI help."""
    print("tibet-y2k38 - Y2K38 Time Bridge with TIBET provenance")
    print()
    print("Commands:")
    print("  info      Show Y2K38 countdown (default)")
    print("  demo      Run interactive demonstration")
    print("  profiles  List all sector profiles")
    print("  scan      Scan for at-risk devices")
    print("  report    Generate compliance report (JSON)")
    print("  help      Show this help")


def run_demo():
    """Run the interactive demo."""
    print()
    print("=" * 60)
    print("  tibet-y2k38 Demo - Time Bridge in Action")
    print("=" * 60)
    print()

    # Create a factory network
    router = TimeRouter(network_id="jis:factory:eindhoven-demo")

    # Register diverse devices
    print("[1] Registering devices across sectors...")
    print()

    devices = [
        ("jis:plc:siemens-s7-line4", "scada", "Siemens S7-300 PLC"),
        ("jis:sensor:temp-hall-a", "iot", "ESP32 Temperature Sensor"),
        ("jis:gps:roof-antenna", "gps", "GPS Timing Receiver"),
        ("jis:atm:lobby-01", "banking", "NCR SelfServ ATM"),
        ("jis:meter:elec-building-c", "energy", "Smart Meter"),
        ("jis:monitor:icu-bed-3", "medical", "Patient Monitor"),
        ("jis:ecu:fleet-truck-47", "automotive", "Fleet ECU"),
        ("jis:signal:switch-a12", "rail", "Railway Interlocking"),
        ("jis:ntp:dc-server-1", "telecom", "NTP Stratum 2"),
        ("jis:fms:cockpit-left", "aviation", "Flight Management System"),
    ]

    for dev_id, profile, desc in devices:
        bridge = router.add_device(dev_id, profile=profile)
        days = bridge.days_until_overflow()
        print(f"    {desc}")
        print(f"    JIS: {dev_id} | Profile: {profile} | Overflow in: {days:,.0f} days")
        print()

    # Translate timestamps
    print("-" * 60)
    print("[2] Translating timestamps (including overflow scenarios)...")
    print()

    test_cases = [
        # Normal timestamps
        ("jis:plc:siemens-s7-line4", 1700000000, "Normal: Nov 2023"),
        ("jis:sensor:temp-hall-a", 1750000000, "Normal: Jun 2025"),
        # The critical moment
        ("jis:plc:siemens-s7-line4", 2147483647, "MAX: 2038-01-19 03:14:07"),
        ("jis:sensor:temp-hall-a", 2147483647, "MAX: Last second before overflow"),
        # Post-overflow (negative = wrapped)
        ("jis:plc:siemens-s7-line4", -2147483648, "OVERFLOW: First negative value"),
        ("jis:sensor:temp-hall-a", -1, "OVERFLOW: Device reads -1"),
        # GPS week rollover
        ("jis:gps:roof-antenna", 1023, "GPS: Week 1023 (last before rollover)"),
        ("jis:gps:roof-antenna", 0, "GPS: Week 0 (just rolled over)"),
        # COBOL date
        ("jis:atm:lobby-01", 20380119, "COBOL: 2038-01-19 packed decimal"),
    ]

    for dev_id, ts, desc in test_cases:
        result = router.translate(dev_id, ts)
        overflow_mark = " *** OVERFLOW ***" if result.overflow_detected else ""
        print(f"    [{desc}]")
        print(f"    Device: {dev_id}")
        print(f"    Input:  {ts} (0x{ts & 0xFFFFFFFF:08X})")
        print(f"    Output: {result.translated_iso}{overflow_mark}")
        print(f"    Confidence: {result.confidence:.0%}")
        if result.warnings:
            for w in result.warnings:
                print(f"    Warning: {w}")
        if result.tibet_token:
            print(f"    TIBET:  {result.tibet_token.get('erachter', '')[:60]}")
        print()

    # Network status
    print("-" * 60)
    print("[3] Network Status...")
    print()

    status = router.status()
    print(f"    Total devices:      {status.total_devices}")
    print(f"    Total translations: {status.total_translations}")
    print(f"    Overflows detected: {status.total_overflows}")
    print(f"    Devices at risk:    {len(status.devices_at_risk)}")
    print(f"    Sectors covered:    {status.sectors}")
    print()

    # Anomaly detection
    anomalies = router.anomalies()
    if anomalies:
        print(f"    Anomalies detected: {len(anomalies)}")
        for a in anomalies:
            print(f"      {a['device_id']}: {a['severity']} "
                  f"(deviation: {a['deviation_seconds']:.0f}s)")

    # Compliance preview
    print("-" * 60)
    print("[4] Compliance Report Preview...")
    print()

    from .compliance import NIS2Reporter, ISO5338Reporter

    nis2 = NIS2Reporter(router)
    risk = nis2.risk_assessment()
    print(f"    NIS2 Risk: {risk['risk_summary']['devices_at_risk']} devices at risk")
    print(f"    NIS2 Audit: {risk['mitigation']}")
    print()

    iso = ISO5338Reporter(router)
    lineage = iso.data_lineage_report()
    print(f"    ISO 5338: {len(lineage['devices'])} devices in lineage chain")
    print(f"    Provenance: {lineage['lineage_chain']['provenance_protocol']}")
    print()

    print("=" * 60)
    print("  Demo complete. Every translation has a TIBET token.")
    print("  Every device has a JIS identity.")
    print("  Full audit trail. Full provenance. Full compliance.")
    print()
    print("  Why replace chips when software can catch the overflow?")
    print("=" * 60)
    print()


def show_profiles():
    """Display all sector profiles with details."""
    profiles = all_profiles()
    print()
    print(f"tibet-y2k38 - {len(profiles)} Sector Profiles")
    print("=" * 60)

    for name, prof in profiles.items():
        print()
        print(f"  [{name.upper()}] {prof.description}")
        print(f"  Sector:     {prof.sector}")
        print(f"  Clock:      {prof.clock_bits}-bit")
        print(f"  Overflow:   {prof.overflow_date}")
        print(f"  Compliance: {', '.join(prof.compliance)}")
        print(f"  Devices:    {prof.estimated_devices_worldwide}")
        print(f"  Replace?    {'Yes' if prof.chip_replacement_feasible else 'No'} ({prof.replacement_cost_per_unit})")
        print(f"  Examples:   {', '.join(prof.typical_devices[:3])}")
        if prof.notes:
            # First sentence only
            first_sentence = prof.notes.split('. ')[0] + '.'
            print(f"  Note:       {first_sentence}")
        print(f"  {'─' * 56}")

    print()


def run_scan():
    """Scan and report on registered devices."""
    print("tibet-y2k38 network scan")
    print("(Register devices via Python API or provide NTP targets)")
    print()
    print("Example:")
    print("  from tibet_y2k38 import DeviceDetector")
    print("  d = DeviceDetector()")
    print("  d.register('192.168.4.50', 'jis:plc:line4', profile='scada')")
    print("  print(d.risk_summary())")


def run_report():
    """Generate a JSON compliance report for demo devices."""
    router = TimeRouter(network_id="jis:network:report-demo")

    # Add sample devices
    router.add_device("jis:plc:demo-1", profile="scada")
    router.add_device("jis:sensor:demo-2", profile="iot")
    router.add_device("jis:gps:demo-3", profile="gps")

    # Do some translations
    router.translate("jis:plc:demo-1", 2147483647)
    router.translate("jis:sensor:demo-2", 1700000000)
    router.translate("jis:gps:demo-3", 1023)

    from .compliance import NIS2Reporter, ISO5338Reporter

    report = {
        "nis2": NIS2Reporter(router).full_report(),
        "iso5338": ISO5338Reporter(router).full_report(),
    }

    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
