"""
Y2K38 Provenance - TIBET tokens for time translations.

Every 32→64 bit translation creates an immutable provenance record.
This is the audit trail that proves: this device sent this timestamp,
we translated it like this, and here's the proof.

ERIN:     What's in the translation (values, format)
ERAAN:    What depends on it (downstream systems)
EROMHEEN: Context (device state, network, firmware)
ERACHTER: Intent (why this translation was needed)
"""

from __future__ import annotations

import hashlib
import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any


@dataclass
class TranslationToken:
    """TIBET provenance token for a single time translation."""

    token_id: str
    timestamp: float
    actor: str
    action: str = "y2k38_translate"

    # TIBET provenance fields
    erin: dict[str, Any] = field(default_factory=dict)
    eraan: list[str] = field(default_factory=list)
    eromheen: dict[str, Any] = field(default_factory=dict)
    erachter: str = ""

    # Chain
    parent_id: str | None = None
    state: str = "CREATED"

    # Integrity
    content_hash: str = ""

    def __post_init__(self):
        if not self.content_hash:
            self.content_hash = self._compute_hash()

    def _compute_hash(self) -> str:
        """SHA-256 hash of the token content for integrity verification."""
        content = json.dumps(
            {
                "token_id": self.token_id,
                "actor": self.actor,
                "action": self.action,
                "erin": self.erin,
                "erachter": self.erachter,
                "timestamp": self.timestamp,
            },
            sort_keys=True,
        )
        return hashlib.sha256(content.encode()).hexdigest()

    def verify(self) -> bool:
        """Verify token integrity."""
        return self.content_hash == self._compute_hash()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), default=str)


class Y2K38Provenance:
    """
    Provenance engine for Y2K38 time translations.

    Creates TIBET tokens for each translation and maintains the audit chain.
    Optionally persists to a TIBET FileStore for compliance.
    """

    def __init__(self, actor: str, store=None):
        """
        Args:
            actor: JIS identity of the bridge device
            store: Optional tibet_core.FileStore for persistent audit
        """
        self.actor = actor
        self.store = store
        self._last_token_id: str | None = None
        self._token_count = 0

        # Try to use tibet-core Provider if available
        self._tibet_provider = None
        try:
            from tibet_core import Provider
            self._tibet_provider = Provider(actor=actor, store=store)
        except ImportError:
            pass

    def create_translation_token(
        self,
        original_value: int,
        translated_value: float,
        device_id: str,
        format_used: str,
        overflow_detected: bool,
        era: int,
        confidence: float,
        profile: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Create a TIBET provenance token for a time translation.

        Returns the token as a dict (compatible with both standalone
        and tibet-core Provider modes).
        """
        now = time.time()

        # ERIN: what's IN this translation
        erin = {
            "original_value": original_value,
            "original_hex": f"0x{original_value:08X}",
            "translated_value": translated_value,
            "translated_iso": datetime.fromtimestamp(
                translated_value, tz=timezone.utc
            ).isoformat()
            if translated_value > 0
            else "INVALID",
            "format": format_used,
            "overflow": overflow_detected,
            "era": era,
            "confidence": confidence,
        }

        # ERAAN: what depends on this translation
        eraan = [device_id]

        # EROMHEEN: context around the translation
        eromheen = {
            "bridge_actor": self.actor,
            "profile": profile or "generic",
            "bridge_time": datetime.fromtimestamp(now, tz=timezone.utc).isoformat(),
            "translation_sequence": self._token_count + 1,
        }
        if context:
            eromheen.update(context)

        # ERACHTER: why this translation happened
        erachter = (
            f"32→64 bit time bridge for device {device_id}"
            f"{' [OVERFLOW]' if overflow_detected else ''}"
            f", profile={profile or 'generic'}"
            f", confidence={confidence:.2f}"
        )

        # Use tibet-core Provider if available
        if self._tibet_provider:
            token = self._tibet_provider.create(
                action="y2k38_translate",
                erin=erin,
                eraan=eraan,
                eromheen=eromheen,
                erachter=erachter,
            )
            self._token_count += 1
            self._last_token_id = token.token_id if hasattr(token, 'token_id') else None
            return token.to_dict() if hasattr(token, 'to_dict') else erin
        else:
            # Standalone mode - create our own token
            token = TranslationToken(
                token_id=str(uuid.uuid4()),
                timestamp=now,
                actor=self.actor,
                action="y2k38_translate",
                erin=erin,
                eraan=eraan,
                eromheen=eromheen,
                erachter=erachter,
                parent_id=self._last_token_id,
            )
            self._token_count += 1
            self._last_token_id = token.token_id
            return token.to_dict()

    @property
    def stats(self) -> dict[str, Any]:
        return {
            "actor": self.actor,
            "tokens_created": self._token_count,
            "using_tibet_core": self._tibet_provider is not None,
            "last_token_id": self._last_token_id,
        }
