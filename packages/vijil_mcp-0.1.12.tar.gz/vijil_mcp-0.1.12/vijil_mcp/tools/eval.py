# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_diamond.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def eval_run(
    agent_id: str,
    harness_names: str,
    type: str | None = None,
    harness_type: str | None = None,
    sample_size: int | None = None,
    evaluation_id: str | None = None,
    wait: bool = False,
) -> str:
    """
    Create Evaluation

    Args:
        agent_id: UUID of the agent from Agent Registry
        harness_names: List of harnesses to run (e.g., ['safety', 'ethics', 'privacy', 'security', 'toxicity']) (JSON array string)
        type: Type of evaluation to run. Currently only 'behavioral' is supported.
        harness_type: Type of all harnesses: 'standard' or 'custom'. All harnesses in harness_names must be of this type. (one of: standard, custom)
        sample_size: Number of prompts to randomly sample per harness. If omitted, all prompts run (~1250 for security). Recommended: 10 for fast iteration, 50 for moderate, 100...
        evaluation_id: Optional UUID for the evaluation. If provided, this UUID will be used when creating the evaluation in Diamond. If not provided, Diamond will generate one.
        wait: Poll until the operation reaches a terminal state (completed/failed/cancelled)
    """
    args: dict[str, Any] = {}
    args["agent_id"] = agent_id
    args["harness_names"] = harness_names
    args["type"] = type
    args["harness_type"] = harness_type
    args["sample_size"] = sample_size
    args["evaluation_id"] = evaluation_id
    return run_vijil("eval", "run", args, wait=wait)

@server.tool()
def eval_status(evaluation_id: str) -> str:
    """
    Get Evaluation

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "status", {}, positional=[evaluation_id])

@server.tool()
def eval_list(
    agent_id: str | None = None,
    status: str | None = None,
    harness_type: str | None = None,
    tested_by: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    """
    List Evaluation Summaries

    Args:
        agent_id: Filter by agent ID
        status: Filter by status (running, completed, failed, cancelled)
        harness_type: Filter by harness type (standard or custom)
        tested_by: Filter by tool that ran the evaluation
        limit: Maximum number of results to return
        offset: Number of results to skip for paging
    """
    args: dict[str, Any] = {}
    args["agent_id"] = agent_id
    args["status"] = status
    args["harness_type"] = harness_type
    args["tested_by"] = tested_by
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("eval", "list", args)

@server.tool()
def eval_list_all() -> str:
    """List Team Evaluations"""
    return run_vijil("eval", "list-all", {})

@server.tool()
def eval_logs(evaluation_id: str) -> str:
    """
    Get Evaluation Logs

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "logs", {}, positional=[evaluation_id])

@server.tool()
def eval_delete(evaluation_id: str) -> str:
    """
    Delete Evaluation

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "delete", {}, positional=[evaluation_id], skip_confirm=True)

@server.tool()
def eval_cancel(evaluation_id: str) -> str:
    """
    Cancel Evaluation

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "cancel", {}, positional=[evaluation_id])

@server.tool()
def eval_report(evaluation_id: str, force_regenerate: bool = False) -> str:
    """
    Generate Report On Demand

    Args:
        evaluation_id: The evaluation id
        force_regenerate: Force regeneration even if cached
    """
    args: dict[str, Any] = {}
    args["force_regenerate"] = force_regenerate
    return run_vijil("eval", "report", args, positional=[evaluation_id])

@server.tool()
def eval_results_list(limit: int | None = None, offset: int | None = None) -> str:
    """
    List Completed Evaluations

    Args:
        limit: Maximum number of results to return
        offset: Number of results to skip for paging
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("eval", "results-list", args)

@server.tool()
def eval_results_detail(evaluation_id: str) -> str:
    """
    Get Evaluation Results

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "results-detail", {}, positional=[evaluation_id])

@server.tool()
def eval_results_report(evaluation_id: str) -> str:
    """
    Get Evaluation Report

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "results-report", {}, positional=[evaluation_id])

@server.tool()
def eval_summary_by_agent() -> str:
    """List Latest Evaluation Summaries By Agent"""
    return run_vijil("eval", "summary-by-agent", {})

@server.tool()
def eval_summary_get(evaluation_id: str) -> str:
    """
    Get Evaluation Summary

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "summary-get", {}, positional=[evaluation_id])

@server.tool()
def eval_summary_delete(evaluation_id: str) -> str:
    """
    Delete Evaluation Summary

    Args:
        evaluation_id: The evaluation id
    """
    return run_vijil("eval", "summary-delete", {}, positional=[evaluation_id], skip_confirm=True)
