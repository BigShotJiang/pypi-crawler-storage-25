# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_dome.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def dome_config_list(agent_id: str | None = None, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Dome Configs

    Args:
        agent_id: If set, only configs whose dome_configs.agent_id matches (paginated).
        limit: Page size
        offset: Pagination offset
    """
    args: dict[str, Any] = {}
    args["agent_id"] = agent_id
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("dome", "config-list", args)

@server.tool()
def dome_config_create(config_body: str | None = None, agent_id: str | None = None) -> str:
    """
    Create Dome Config

    Args:
        config_body: Guard configuration. If not provided, uses default config. (JSON object string)
        agent_id: Agent to bind this config to. When set, writes config_pending.json to storage.
    """
    args: dict[str, Any] = {}
    args["config_body"] = config_body
    args["agent_id"] = agent_id
    return run_vijil("dome", "config-create", args)

@server.tool()
def dome_config_get(config_id: str) -> str:
    """
    Get Dome Config

    Args:
        config_id: The config id
    """
    return run_vijil("dome", "config-get", {}, positional=[config_id])

@server.tool()
def dome_config_update(config_id: str, config_body: str) -> str:
    """
    Update Dome Config

    Args:
        config_id: The config id
        config_body: Updated guard configuration. (JSON object string)
    """
    args: dict[str, Any] = {}
    args["config_body"] = config_body
    return run_vijil("dome", "config-update", args, positional=[config_id])

@server.tool()
def dome_config_delete(config_id: str) -> str:
    """
    Delete Dome Config

    Args:
        config_id: The config id
    """
    return run_vijil("dome", "config-delete", {}, positional=[config_id], skip_confirm=True)

@server.tool()
def dome_config_patch(config_id: str, dome_instance_url: str) -> str:
    """
    Patch Dome Config

    Args:
        config_id: The config id
        dome_instance_url: Dome instance URL to set, or null to clear.
    """
    args: dict[str, Any] = {}
    args["dome_instance_url"] = dome_instance_url
    return run_vijil("dome", "config-patch", args, positional=[config_id])

@server.tool()
def dome_config_apply(config_id: str) -> str:
    """
    Apply Dome Config

    Args:
        config_id: The config id
    """
    return run_vijil("dome", "config-apply", {}, positional=[config_id])

@server.tool()
def dome_default_config() -> str:
    """Get Default Dome Config"""
    return run_vijil("dome", "default-config", {})

@server.tool()
def dome_detect(
    id: str,
    detector_id: str,
    detector_inputs: str,
    detector_params: str | None = None,
    wait: bool = False,
) -> str:
    """
    Create Detection

    Args:
        id: Id
        detector_id: Detector Id
        detector_inputs: Detector Inputs (JSON array string)
        detector_params: Parameters for a detection request. (JSON object string)
        wait: Poll until the operation reaches a terminal state (completed/failed/cancelled)
    """
    args: dict[str, Any] = {}
    args["id"] = id
    args["detector_id"] = detector_id
    args["detector_inputs"] = detector_inputs
    args["detector_params"] = detector_params
    return run_vijil("dome", "detect", args, wait=wait)

@server.tool()
def dome_detect_status(detection_id: str) -> str:
    """
    Get Detection

    Args:
        detection_id: The detection id
    """
    return run_vijil("dome", "detect-status", {}, positional=[detection_id])
