# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_dome.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def telemetry_metric_total(
    metric_name: str,
    time_range: str | None = None,
    evaluation_id: str | None = None,
    test_id: str | None = None,
    probe_id: str | None = None,
    agent_configuration_id: str | None = None,
) -> str:
    """
    Get Counter Total

    Args:
        metric_name: The metric name
        time_range: Time range: 15m, 30m, 1h, 2h, 6h, 1d, 7d, 30d
        evaluation_id: Filter by evaluation ID
        test_id: Filter by test ID
        probe_id: Filter by probe ID
        agent_configuration_id: Filter by agent configuration ID
    """
    args: dict[str, Any] = {}
    args["time_range"] = time_range
    args["evaluation_id"] = evaluation_id
    args["test_id"] = test_id
    args["probe_id"] = probe_id
    args["agent_configuration_id"] = agent_configuration_id
    return run_vijil("telemetry", "metric-total", args, positional=[metric_name])

@server.tool()
def telemetry_counter_series(
    metric_name: str,
    time_range: str | None = None,
    evaluation_id: str | None = None,
    agent_configuration_id: str | None = None,
) -> str:
    """
    Get Counter Time Series

    Args:
        metric_name: The metric name
        time_range: Time range: 15m, 30m, 1h, 2h, 6h, 1d, 7d, 30d
        evaluation_id: Filter by evaluation ID
        agent_configuration_id: Filter by agent configuration ID
    """
    args: dict[str, Any] = {}
    args["time_range"] = time_range
    args["evaluation_id"] = evaluation_id
    args["agent_configuration_id"] = agent_configuration_id
    return run_vijil("telemetry", "counter-series", args, positional=[metric_name])

@server.tool()
def telemetry_latency_metric(
    metric_name: str,
    time_range: str | None = None,
    time_window: str | None = None,
    percentiles: str | None = None,
    evaluation_id: str | None = None,
    test_id: str | None = None,
    probe_id: str | None = None,
    agent_configuration_id: str | None = None,
) -> str:
    """
    Get Latency Over Time

    Args:
        metric_name: The metric name
        time_range: Time range: 15m, 30m, 1h, 2h, 6h, 1d, 7d, 30d
        time_window: Time window for aggregation (e.g., '1m', '5m', '15m')
        percentiles: Comma-separated list of percentiles to query (e.g., '0.5,0.95'). If not specified, defaults to [0.5, 0.9, 0.95, 0.99]
        evaluation_id: Filter by evaluation ID
        test_id: Filter by test ID
        probe_id: Filter by probe ID
        agent_configuration_id: Filter by agent configuration ID
    """
    args: dict[str, Any] = {}
    args["time_range"] = time_range
    args["time_window"] = time_window
    args["percentiles"] = percentiles
    args["evaluation_id"] = evaluation_id
    args["test_id"] = test_id
    args["probe_id"] = probe_id
    args["agent_configuration_id"] = agent_configuration_id
    return run_vijil("telemetry", "latency-metric", args, positional=[metric_name])

@server.tool()
def telemetry_logs(
    time_range: str | None = None,
    service_name: str | None = None,
    level: str | None = None,
    job: str | None = None,
    exporter: str | None = None,
    agent_configuration_id: str | None = None,
    evaluation_id: str | None = None,
    test_id: str | None = None,
    probe_id: str | None = None,
    search: str | None = None,
    logql: str | None = None,
    limit: int | None = None,
    direction: str | None = None,
) -> str:
    """
    Get Logs

    Args:
        time_range: Window to pull logs for
        service_name: Filter by service_name label
        level: Filter by level label
        job: Filter by job label
        exporter: Filter by exporter label
        agent_configuration_id: Restrict to a specific agent configuration id
        evaluation_id: Restrict logs to an evaluation id
        test_id: Restrict logs to a test id
        probe_id: Restrict logs to a probe id
        search: Substring search applied via LogQL pipeline
        logql: Advanced LogQL expression (overrides generated selector when provided)
        limit: Maximum log lines to return
        direction: Return order for log entries
    """
    args: dict[str, Any] = {}
    args["time_range"] = time_range
    args["service_name"] = service_name
    args["level"] = level
    args["job"] = job
    args["exporter"] = exporter
    args["agent_configuration_id"] = agent_configuration_id
    args["evaluation_id"] = evaluation_id
    args["test_id"] = test_id
    args["probe_id"] = probe_id
    args["search"] = search
    args["logql"] = logql
    args["limit"] = limit
    args["direction"] = direction
    return run_vijil("telemetry", "logs", args)

@server.tool()
def telemetry_traces(
    time_range: str | None = None,
    limit: int | None = None,
    service_name: str | None = None,
    agent_configuration_id: str | None = None,
    min_duration_ms: int | None = None,
    max_duration_ms: int | None = None,
    query: str | None = None,
) -> str:
    """
    Search Traces

    Args:
        time_range: Window to search for traces
        limit: Maximum number of traces to return
        service_name: Filter by root service
        agent_configuration_id: Filter by agent id
        min_duration_ms: Lower bound on trace duration (ms)
        max_duration_ms: Upper bound on trace duration (ms)
        query: Advanced TraceQL query
    """
    args: dict[str, Any] = {}
    args["time_range"] = time_range
    args["limit"] = limit
    args["service_name"] = service_name
    args["agent_configuration_id"] = agent_configuration_id
    args["min_duration_ms"] = min_duration_ms
    args["max_duration_ms"] = max_duration_ms
    args["query"] = query
    return run_vijil("telemetry", "traces", args)

@server.tool()
def telemetry_trace_get(trace_id: str) -> str:
    """
    Get Trace By Id

    Args:
        trace_id: The trace id
    """
    return run_vijil("telemetry", "trace-get", {}, positional=[trace_id])
