# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def policy_list(
    category: str | None = None,
    status: str | None = None,
    search: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    """
    List Policies

    Args:
        category: category
        status: status
        search: search
        limit: Maximum number of results (default 10)
        offset: Number of results to skip for paging
    """
    args: dict[str, Any] = {}
    args["category"] = category
    args["status"] = status
    args["search"] = search
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("policy", "list", args)

@server.tool()
def policy_create(
    name: str,
    category: str,
    id: str | None = None,
    description: str | None = None,
    source_text: str | None = None,
    tags: str | None = None,
) -> str:
    """
    Create Policy

    Args:
        name: Name
        category: Category of policy document. (one of: privacy, ethics, security, compliance, operational, brand, custom)
        id: Id
        description: Description
        source_text: Source Text
        tags: Tags (JSON array string)
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["category"] = category
    args["id"] = id
    args["description"] = description
    args["source_text"] = source_text
    args["tags"] = tags
    return run_vijil("policy", "create", args)

@server.tool()
def policy_get(policy_id: str) -> str:
    """
    Get Policy

    Args:
        policy_id: The policy id
    """
    return run_vijil("policy", "get", {}, positional=[policy_id])

@server.tool()
def policy_delete(policy_id: str) -> str:
    """
    Delete Policy

    Args:
        policy_id: The policy id
    """
    return run_vijil("policy", "delete", {}, positional=[policy_id], skip_confirm=True)

@server.tool()
def policy_patch(
    policy_id: str,
    name: str | None = None,
    description: str | None = None,
    category: str | None = None,
    status: str | None = None,
    source_text: str | None = None,
    tags: str | None = None,
) -> str:
    """
    Update Policy

    Args:
        policy_id: The policy id
        name: Name
        description: Description
        category: Category of policy document. (one of: privacy, ethics, security, compliance, operational, brand, custom)
        status: Status of a policy document. (one of: draft, active, archived)
        source_text: Source Text
        tags: Tags (JSON array string)
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["description"] = description
    args["category"] = category
    args["status"] = status
    args["source_text"] = source_text
    args["tags"] = tags
    return run_vijil("policy", "patch", args, positional=[policy_id])

@server.tool()
def policy_preset_list(category: str | None = None, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Presets

    Args:
        category: category
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["category"] = category
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("policy", "preset-list", args)

@server.tool()
def policy_from_preset(preset_id: str, name_override: str | None = None) -> str:
    """
    Copy Preset

    Args:
        preset_id: The preset id
        name_override: name_override
    """
    args: dict[str, Any] = {}
    args["name_override"] = name_override
    return run_vijil("policy", "from-preset", args, positional=[preset_id])

@server.tool()
def policy_activate(policy_id: str) -> str:
    """
    Activate Policy

    Args:
        policy_id: The policy id
    """
    return run_vijil("policy", "activate", {}, positional=[policy_id])

@server.tool()
def policy_file_delete(policy_id: str) -> str:
    """
    Delete File

    Args:
        policy_id: The policy id
    """
    return run_vijil("policy", "file-delete", {}, positional=[policy_id], skip_confirm=True)

@server.tool()
def policy_rules(policy_id: str, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Policy Rules

    Args:
        policy_id: The policy id
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("policy", "rules", args, positional=[policy_id])

@server.tool()
def policy_add_rule(
    policy_id: str,
    rule_type: str,
    action: str,
    consequence: str,
    natural_language: str,
    id: str | None = None,
    rule_id: str | None = None,
    target: str | None = None,
    assignee: str | None = None,
    constraints: str | None = None,
    conditions: str | None = None,
    constraint_logic: str | None = None,
    category: str | None = None,
    status: str | None = None,
    tags: str | None = None,
) -> str:
    """
    Create Policy Rule

    Args:
        policy_id: The policy id
        rule_type: Type of policy rule (ODRL-inspired). (one of: permission, prohibition, obligation, recommendation)
        action: Action
        consequence: Consequence (JSON object string)
        natural_language: Natural Language
        id: Id
        rule_id: Rule Id
        target: Target
        assignee: Assignee
        constraints: Constraints (JSON array string)
        conditions: Conditions (JSON array string)
        constraint_logic: Constraint Logic
        category: Category of policy document. (one of: privacy, ethics, security, compliance, operational, brand, custom)
        status: Review status of a policy rule. (one of: draft, approved, rejected, modified)
        tags: Tags (JSON array string)
    """
    args: dict[str, Any] = {}
    args["rule_type"] = rule_type
    args["action"] = action
    args["consequence"] = consequence
    args["natural_language"] = natural_language
    args["id"] = id
    args["rule_id"] = rule_id
    args["target"] = target
    args["assignee"] = assignee
    args["constraints"] = constraints
    args["conditions"] = conditions
    args["constraint_logic"] = constraint_logic
    args["category"] = category
    args["status"] = status
    args["tags"] = tags
    return run_vijil("policy", "add-rule", args, positional=[policy_id])

@server.tool()
def policy_rule_list(
    policy_id: str | None = None,
    status: str | None = None,
    category: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    """
    List Rules

    Args:
        policy_id: policy_id
        status: status
        category: category
        limit: limit
        offset: offset
    """
    args: dict[str, Any] = {}
    args["policy_id"] = policy_id
    args["status"] = status
    args["category"] = category
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("policy", "rule-list", args)

@server.tool()
def policy_rule_get(rule_id: str) -> str:
    """
    Get Rule

    Args:
        rule_id: The rule id
    """
    return run_vijil("policy", "rule-get", {}, positional=[rule_id])

@server.tool()
def policy_rule_delete(rule_id: str) -> str:
    """
    Delete Rule

    Args:
        rule_id: The rule id
    """
    return run_vijil("policy", "rule-delete", {}, positional=[rule_id], skip_confirm=True)

@server.tool()
def policy_patch_rule(
    rule_id: str,
    rule_type: str | None = None,
    action: str | None = None,
    target: str | None = None,
    assignee: str | None = None,
    constraints: str | None = None,
    conditions: str | None = None,
    constraint_logic: str | None = None,
    consequence: str | None = None,
    natural_language: str | None = None,
    category: str | None = None,
    status: str | None = None,
    tags: str | None = None,
) -> str:
    """
    Update Rule

    Args:
        rule_id: The rule id
        rule_type: Type of policy rule (ODRL-inspired). (one of: permission, prohibition, obligation, recommendation)
        action: Action
        target: Target
        assignee: Assignee
        constraints: Constraints (JSON array string)
        conditions: Conditions (JSON array string)
        constraint_logic: Constraint Logic
        consequence: Consequence (JSON object string)
        natural_language: Natural Language
        category: Category of policy document. (one of: privacy, ethics, security, compliance, operational, brand, custom)
        status: Review status of a policy rule. (one of: draft, approved, rejected, modified)
        tags: Tags (JSON array string)
    """
    args: dict[str, Any] = {}
    args["rule_type"] = rule_type
    args["action"] = action
    args["target"] = target
    args["assignee"] = assignee
    args["constraints"] = constraints
    args["conditions"] = conditions
    args["constraint_logic"] = constraint_logic
    args["consequence"] = consequence
    args["natural_language"] = natural_language
    args["category"] = category
    args["status"] = status
    args["tags"] = tags
    return run_vijil("policy", "patch-rule", args, positional=[rule_id])

@server.tool()
def policy_approve_rule(rule_id: str, notes: str | None = None) -> str:
    """
    Approve Rule

    Args:
        rule_id: The rule id
        notes: notes
    """
    args: dict[str, Any] = {}
    args["notes"] = notes
    return run_vijil("policy", "approve-rule", args, positional=[rule_id])

@server.tool()
def policy_reject_rule(rule_id: str, reason: str) -> str:
    """
    Reject Rule

    Args:
        rule_id: The rule id
        reason: reason
    """
    args: dict[str, Any] = {}
    args["reason"] = reason
    return run_vijil("policy", "reject-rule", args, positional=[rule_id])
