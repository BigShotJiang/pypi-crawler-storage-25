# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Hand-written team tools — list and switch teams."""

from __future__ import annotations

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def team_list() -> str:
    """List all teams the authenticated user belongs to."""
    return run_vijil("team", "list", {})


@server.tool()
def team_use(team_id: str) -> str:
    """Switch the active team context.

    Args:
        team_id: UUID of the team to switch to
    """
    return run_vijil("team", "use", {}, positional=[team_id], json_output=False)
