# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Subprocess runner — executes vijil CLI commands and returns JSON output.

Security note: arguments (including API keys) are passed via command line
argv, which may be visible in local process listings. This matches how the
CLI is used directly by humans. For sensitive operations, prefer referencing
agents by ID (agent_id) rather than passing raw API keys through MCP tools.
"""

from __future__ import annotations

import shutil
import subprocess
from typing import Any


# Timeout for normal commands (seconds).
_DEFAULT_TIMEOUT = 120
# Timeout for commands with --wait (slightly longer than the CLI's 600s poll timeout).
_WAIT_TIMEOUT = 660


def run_vijil(
    group: str,
    command: str,
    args: dict[str, Any] | None = None,
    *,
    positional: list[str] | None = None,
    wait: bool = False,
    skip_confirm: bool = False,
    json_output: bool = True,
) -> str:
    """Run a vijil CLI command and return its stdout.

    Builds: vijil <group> <command> [positional...] [--key value ...] --json
    """
    vijil = shutil.which("vijil")
    if vijil is None:
        return (
            "Error: vijil CLI not found in PATH. "
            "Install it with: pip install vijil-console"
        )

    cmd: list[str] = [vijil, group, command]

    # Positional arguments first.
    if positional:
        cmd.extend(positional)

    # Named arguments.
    if args:
        for key, value in args.items():
            if value is None:
                continue
            flag = "--" + key.replace("_", "-")
            if isinstance(value, bool):
                if value:
                    cmd.append(flag)
            elif isinstance(value, list | tuple):
                for item in value:
                    cmd.extend([flag, str(item)])
            else:
                cmd.extend([flag, str(value)])

    # Request JSON output unless the command doesn't support it.
    if json_output:
        cmd.append("--json")

    # Auto-confirm destructive operations.
    if skip_confirm:
        cmd.append("--yes")

    # Wait for async operations to complete.
    if wait:
        cmd.append("--wait")

    timeout = _WAIT_TIMEOUT if wait else _DEFAULT_TIMEOUT

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after {timeout}s: {' '.join(cmd)}"
    except OSError as exc:
        return f"Error running vijil CLI: {exc}"

    if result.returncode != 0:
        return _format_error(result.stderr or result.stdout)

    return result.stdout


def _format_error(output: str) -> str:
    """Turn CLI error output into a helpful message."""
    lower = output.lower()
    if "not configured" in lower or "no console url" in lower:
        return f"Error: Vijil CLI not configured. Run 'vijil auth init' first.\n{output}"
    if "session expired" in lower or "please login" in lower or "run 'vijil auth login'" in lower:
        return f"Error: Session expired. Run 'vijil auth login' to re-authenticate.\n{output}"
    if "no team" in lower or "team_id" in lower:
        return f"Error: No team selected. Run 'vijil team use <team_id>' first.\n{output}"
    return f"Error: {output}"
