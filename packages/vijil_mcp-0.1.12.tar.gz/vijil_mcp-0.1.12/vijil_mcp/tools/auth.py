# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Hand-written auth tools — check CLI configuration status."""

from __future__ import annotations

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def vijil_status() -> str:
    """Check if the Vijil CLI is configured and authenticated.

    Returns the current team list if authenticated, or an error
    message with setup instructions if not configured.
    Call this before using other tools to verify the CLI is ready.
    """
    return run_vijil("team", "list", {})


@server.tool()
def auth_change_password(current_password: str, new_password: str) -> str:
    """Change the current account password.

    Args:
        current_password: Current account password
        new_password: New account password
    """
    return run_vijil(
        "auth",
        "change-password",
        {"current_password": current_password, "new_password": new_password},
    )
