# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_diamond.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def harness_list() -> str:
    """List Harnesses"""
    return run_vijil("harness", "list", {})

@server.tool()
def harness_custom_list(
    limit: int | None = None,
    offset: int | None = None,
    status: str | None = None,
    agent_id: str | None = None,
) -> str:
    """
    List Custom Harnesses

    Args:
        limit: Maximum number of results (default 10)
        offset: Number of results to skip for paging
        status: Filter by status
        agent_id: Filter by agent ID
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    args["status"] = status
    args["agent_id"] = agent_id
    return run_vijil("harness", "custom-list", args)

@server.tool()
def harness_custom_create(
    name: str,
    agent_id: str,
    id: str | None = None,
    description: str | None = None,
    persona_ids: str | None = None,
    policy_ids: str | None = None,
    system_prompt: str | None = None,
) -> str:
    """
    Create Custom Harness

    Args:
        name: Name
        agent_id: Agent Id
        id: Id
        description: Description
        persona_ids: Persona Ids (JSON array string)
        policy_ids: Policy Ids (JSON array string)
        system_prompt: AUT description or system prompt for harness generation. If not provided, agent description will be used.
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["agent_id"] = agent_id
    args["id"] = id
    args["description"] = description
    args["persona_ids"] = persona_ids
    args["policy_ids"] = policy_ids
    args["system_prompt"] = system_prompt
    return run_vijil("harness", "custom-create", args)

@server.tool()
def harness_custom_get(harness_id: str) -> str:
    """
    Get Custom Harness

    Args:
        harness_id: The harness id
    """
    return run_vijil("harness", "custom-get", {}, positional=[harness_id])

@server.tool()
def harness_custom_delete(harness_id: str) -> str:
    """
    Delete Custom Harness

    Args:
        harness_id: The harness id
    """
    return run_vijil("harness", "custom-delete", {}, positional=[harness_id], skip_confirm=True)

@server.tool()
def harness_custom_cancel(harness_id: str) -> str:
    """
    Cancel Custom Harness

    Args:
        harness_id: The harness id
    """
    return run_vijil("harness", "custom-cancel", {}, positional=[harness_id])

@server.tool()
def harness_custom_prompts(harness_id: str) -> str:
    """
    Get Custom Harness Prompts

    Args:
        harness_id: The harness id
    """
    return run_vijil("harness", "custom-prompts", {}, positional=[harness_id])
