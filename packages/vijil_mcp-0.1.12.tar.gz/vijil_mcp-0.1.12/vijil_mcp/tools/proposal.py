# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def proposal_list() -> str:
    """GET /v1/proposals/"""
    return run_vijil("proposal", "list", {})

@server.tool()
def proposal_get(proposal_id: str) -> str:
    """
    GET /v1/proposals/{proposal_id}

    Args:
        proposal_id: The proposal id
    """
    return run_vijil("proposal", "get", {}, positional=[proposal_id])

@server.tool()
def proposal_approve(proposal_id: str) -> str:
    """
    POST /v1/proposals/{proposal_id}/approve

    Args:
        proposal_id: The proposal id
    """
    return run_vijil("proposal", "approve", {}, positional=[proposal_id])

@server.tool()
def proposal_reject(proposal_id: str) -> str:
    """
    POST /v1/proposals/{proposal_id}/reject

    Args:
        proposal_id: The proposal id
    """
    return run_vijil("proposal", "reject", {}, positional=[proposal_id])
