# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def dimensions_list(protected_class_only: bool = False, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Dimensions

    Args:
        protected_class_only: Filter to only protected class dimensions
        limit: Maximum number of results
        offset: Number of results to skip
    """
    args: dict[str, Any] = {}
    args["protected_class_only"] = protected_class_only
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("dimensions", "list", args)

@server.tool()
def dimensions_create(
    name: str,
    display_name: str,
    protected_class: bool = False,
    description: str | None = None,
) -> str:
    """
    Create Dimension

    Args:
        name: Name
        display_name: Display Name
        protected_class: Protected Class
        description: Description
    """
    args: dict[str, Any] = {}
    args["name"] = name
    args["display_name"] = display_name
    args["protected_class"] = protected_class
    args["description"] = description
    return run_vijil("dimensions", "create", args)

@server.tool()
def dimensions_get(dimension_id: str) -> str:
    """
    Get Dimension

    Args:
        dimension_id: The dimension id
    """
    return run_vijil("dimensions", "get", {}, positional=[dimension_id])

@server.tool()
def dimensions_update(
    dimension_id: str,
    display_name: str | None = None,
    protected_class: bool = False,
    description: str | None = None,
) -> str:
    """
    Update Dimension

    Args:
        dimension_id: The dimension id
        display_name: Display Name
        protected_class: Protected Class
        description: Description
    """
    args: dict[str, Any] = {}
    args["display_name"] = display_name
    args["protected_class"] = protected_class
    args["description"] = description
    return run_vijil("dimensions", "update", args, positional=[dimension_id])

@server.tool()
def dimensions_delete(dimension_id: str) -> str:
    """
    Delete Dimension

    Args:
        dimension_id: The dimension id
    """
    return run_vijil("dimensions", "delete", {}, positional=[dimension_id], skip_confirm=True)

@server.tool()
def dimensions_get_by_name(name: str) -> str:
    """
    Get Dimension By Name

    Args:
        name: The name
    """
    return run_vijil("dimensions", "get-by-name", {}, positional=[name])

@server.tool()
def dimensions_values(dimension_id: str, limit: int | None = None, offset: int | None = None) -> str:
    """
    List Values

    Args:
        dimension_id: The dimension id
        limit: Maximum number of results
        offset: Number of results to skip
    """
    args: dict[str, Any] = {}
    args["limit"] = limit
    args["offset"] = offset
    return run_vijil("dimensions", "values", args, positional=[dimension_id])

@server.tool()
def dimensions_add_value(
    dimension_id: str,
    value: str,
    display_name: str | None = None,
    metadata: str | None = None,
    sort_order: int | None = None,
) -> str:
    """
    Add Value

    Args:
        dimension_id: The dimension id
        value: Value
        display_name: Display Name
        metadata: Metadata (JSON object string)
        sort_order: Sort Order
    """
    args: dict[str, Any] = {}
    args["value"] = value
    args["display_name"] = display_name
    args["metadata"] = metadata
    args["sort_order"] = sort_order
    return run_vijil("dimensions", "add-value", args, positional=[dimension_id])

@server.tool()
def dimensions_add_values_bulk(dimension_id: str, values: str) -> str:
    """
    Bulk Add Values

    Args:
        dimension_id: The dimension id
        values: Values (JSON array string)
    """
    args: dict[str, Any] = {}
    args["values"] = values
    return run_vijil("dimensions", "add-values-bulk", args, positional=[dimension_id])

@server.tool()
def dimensions_update_value(
    value_id: str,
    value: str | None = None,
    display_name: str | None = None,
    metadata: str | None = None,
    sort_order: int | None = None,
) -> str:
    """
    Update Value

    Args:
        value_id: The value id
        value: Value
        display_name: Display Name
        metadata: Metadata (JSON object string)
        sort_order: Sort Order
    """
    args: dict[str, Any] = {}
    args["value"] = value
    args["display_name"] = display_name
    args["metadata"] = metadata
    args["sort_order"] = sort_order
    return run_vijil("dimensions", "update-value", args, positional=[value_id])

@server.tool()
def dimensions_delete_value(value_id: str) -> str:
    """
    Delete Value

    Args:
        value_id: The value id
    """
    return run_vijil("dimensions", "delete-value", {}, positional=[value_id], skip_confirm=True)
