# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_redteam.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def redteam_tools() -> str:
    """List Tools"""
    return run_vijil("redteam", "tools", {})

@server.tool()
def redteam_run(
    tool: str,
    purpose: str,
    categories: str,
    agent_url: str | None = None,
    agent_id: str | None = None,
    agent_api_key: str | None = None,
    agent_model_name: str | None = None,
    custom_plugins: str | None = None,
    strategies: str | None = None,
    num_tests: int | None = None,
    provider_config: str | None = None,
    wait: bool = False,
) -> str:
    """
    Create Campaign

    Args:
        tool: Red team tool to use (one of: diamond_security, promptfoo, garak, pyrit, unknown)
        purpose: Agent purpose description (for context-aware attacks)
        categories: Attack categories to test (JSON array string)
        agent_url: Target agent endpoint URL
        agent_id: Agent ID from Agent Registry (resolves URL)
        agent_api_key: API key for the target agent
        agent_model_name: Model name if agent is an LLM gateway
        custom_plugins: Custom plugin/probe names (for CUSTOM category) (JSON array string)
        strategies: Evaluation strategies (tool-specific) (JSON array string)
        num_tests: Number of test cases per category
        provider_config: Provider-specific configuration (JSON object string)
        wait: Poll until the operation reaches a terminal state (completed/failed/cancelled)
    """
    args: dict[str, Any] = {}
    args["tool"] = tool
    args["purpose"] = purpose
    args["categories"] = categories
    args["agent_url"] = agent_url
    args["agent_id"] = agent_id
    args["agent_api_key"] = agent_api_key
    args["agent_model_name"] = agent_model_name
    args["custom_plugins"] = custom_plugins
    args["strategies"] = strategies
    args["num_tests"] = num_tests
    args["provider_config"] = provider_config
    return run_vijil("redteam", "run", args, wait=wait)

@server.tool()
def redteam_list() -> str:
    """List Campaigns"""
    return run_vijil("redteam", "list", {})

@server.tool()
def redteam_status(campaign_id: str) -> str:
    """
    Get Campaign Status

    Args:
        campaign_id: The campaign id
    """
    return run_vijil("redteam", "status", {}, positional=[campaign_id])

@server.tool()
def redteam_results(campaign_id: str) -> str:
    """
    Get Campaign Results

    Args:
        campaign_id: The campaign id
    """
    return run_vijil("redteam", "results", {}, positional=[campaign_id])

@server.tool()
def redteam_delete(campaign_id: str) -> str:
    """
    Delete Campaign

    Args:
        campaign_id: The campaign id
    """
    return run_vijil("redteam", "delete", {}, positional=[campaign_id], skip_confirm=True)

@server.tool()
def redteam_logs(campaign_id: str) -> str:
    """
    Get Campaign Logs

    Args:
        campaign_id: The campaign id
    """
    return run_vijil("redteam", "logs", {}, positional=[campaign_id])

@server.tool()
def redteam_cancel(campaign_id: str) -> str:
    """
    Cancel Campaign

    Args:
        campaign_id: The campaign id
    """
    return run_vijil("redteam", "cancel", {}, positional=[campaign_id])
