# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-mcp

from __future__ import annotations

from typing import Any

from vijil_mcp.server import server
from vijil_mcp.tools._runner import run_vijil


@server.tool()
def agent_list(
    statuses: list[str] | None = None,
    limit: int | None = None,
    offset: int | None = None,
    include_scores: bool = False,
) -> str:
    """
    Get Agent Configurations

    Args:
        statuses: Filter by status(es). If not provided, defaults to non-archived statuses.
        limit: Maximum number of results
        offset: Number of results to skip
        include_scores: When true, sideloads the latest completed evaluation scores onto each agent.
    """
    args: dict[str, Any] = {}
    args["statuses"] = statuses
    args["limit"] = limit
    args["offset"] = offset
    args["include_scores"] = include_scores
    return run_vijil("agent", "list", args)

@server.tool()
def agent_create(
    id: str | None = None,
    hub: str | None = None,
    model_name: str | None = None,
    agent_name: str | None = None,
    agent_url: str | None = None,
    hub_config: str | None = None,
    status: str | None = None,
    api_key_id: str | None = None,
    api_key: str | None = None,
    agent_system_prompt: str | None = None,
    agent_policy_files: str | None = None,
    rag_params: str | None = None,
    function_route_params: str | None = None,
    mcp_config: str | None = None,
) -> str:
    """
    Create Agent Configuration

    Args:
        id: Id
        hub: Hub
        model_name: Model Name
        agent_name: Agent Name
        agent_url: Agent Url
        hub_config: Hub Config (JSON object string)
        status: Status
        api_key_id: Api Key Id
        api_key: Api Key
        agent_system_prompt: Agent System Prompt
        agent_policy_files: Agent Policy Files (JSON array string)
        rag_params: Rag Params (JSON object string)
        function_route_params: Function Route Params (JSON object string)
        mcp_config: MCP (Model Context Protocol) proxy configuration. (JSON object string)
    """
    args: dict[str, Any] = {}
    args["id"] = id
    args["hub"] = hub
    args["model_name"] = model_name
    args["agent_name"] = agent_name
    args["agent_url"] = agent_url
    args["hub_config"] = hub_config
    args["status"] = status
    args["api_key_id"] = api_key_id
    args["api_key"] = api_key
    args["agent_system_prompt"] = agent_system_prompt
    args["agent_policy_files"] = agent_policy_files
    args["rag_params"] = rag_params
    args["function_route_params"] = function_route_params
    args["mcp_config"] = mcp_config
    return run_vijil("agent", "create", args)

@server.tool()
def agent_get(agent_id: str, include_scores: bool = False) -> str:
    """
    Get Agent Configuration By Id

    Args:
        agent_id: The agent id
        include_scores: When true, sideloads the latest completed evaluation scores onto the agent.
    """
    args: dict[str, Any] = {}
    args["include_scores"] = include_scores
    return run_vijil("agent", "get", args, positional=[agent_id])

@server.tool()
def agent_update(
    agent_id: str,
    status: str | None = None,
    agent_name: str | None = None,
    agent_url: str | None = None,
    model_name: str | None = None,
    api_key: str | None = None,
    agent_system_prompt: str | None = None,
    hub: str | None = None,
    rate_limit_requests_per_minute: int | None = None,
    access_level: str | None = None,
    agent_params: str | None = None,
    mcp_config: str | None = None,
    delegated_agents: str | None = None,
    white_box_config: str | None = None,
    agent_metadata: str | None = None,
    purpose: str | None = None,
    protocol: str | None = None,
    test_score: float | None = None,
    last_tested_by: str | None = None,
    evaluated_harnesses: str | None = None,
    last_evaluated_at: int | None = None,
    protection_status: str | None = None,
    dome_config_id: str | None = None,
    dome_manually_configured: bool = False,
) -> str:
    """
    Update Agent Configuration

    Args:
        agent_id: The agent id
        status: Agent status values. (one of: draft, creating, active, under_review, deprecated, archived, pending, rejected)
        agent_name: Agent Name
        agent_url: Agent Url
        model_name: Model Name
        api_key: API key value. Stored directly in the agent configuration.
        agent_system_prompt: Agent System Prompt
        hub: Hub
        rate_limit_requests_per_minute: Rate limit for API requests per minute
        access_level: Access level for agent analysis.  Black Box: URL only - behavioral testing only Grey Box: Agent configuration - structure/capabilities analysis White Box: ...
        agent_params: Model parameters for agent configuration. (JSON object string)
        mcp_config: MCP (Model Context Protocol) proxy configuration. (JSON object string)
        delegated_agents: Delegated Agents (JSON array string)
        white_box_config: Source code access configuration for white box analysis. (JSON object string)
        agent_metadata: Agent metadata for display and organization. (JSON object string)
        purpose: Purpose
        protocol: Communication protocol for agent endpoints. (one of: chat_completions, a2a)
        test_score: Test Score
        last_tested_by: Last Tested By
        evaluated_harnesses: Evaluated Harnesses (JSON array string)
        last_evaluated_at: Last Evaluated At
        protection_status: Dome protection lifecycle state. (one of: unprotected, configured, domed)
        dome_config_id: Dome Config Id
        dome_manually_configured: Dome Manually Configured
    """
    args: dict[str, Any] = {}
    args["status"] = status
    args["agent_name"] = agent_name
    args["agent_url"] = agent_url
    args["model_name"] = model_name
    args["api_key"] = api_key
    args["agent_system_prompt"] = agent_system_prompt
    args["hub"] = hub
    args["rate_limit_requests_per_minute"] = rate_limit_requests_per_minute
    args["access_level"] = access_level
    args["agent_params"] = agent_params
    args["mcp_config"] = mcp_config
    args["delegated_agents"] = delegated_agents
    args["white_box_config"] = white_box_config
    args["agent_metadata"] = agent_metadata
    args["purpose"] = purpose
    args["protocol"] = protocol
    args["test_score"] = test_score
    args["last_tested_by"] = last_tested_by
    args["evaluated_harnesses"] = evaluated_harnesses
    args["last_evaluated_at"] = last_evaluated_at
    args["protection_status"] = protection_status
    args["dome_config_id"] = dome_config_id
    args["dome_manually_configured"] = dome_manually_configured
    return run_vijil("agent", "update", args, positional=[agent_id])

@server.tool()
def agent_import(
    agent_url: str | None = None,
    agent_card: str | None = None,
    source_code: str | None = None,
    framework: str | None = None,
    entry_point: str | None = None,
    override_name: str | None = None,
    rate_limit_requests_per_minute: int | None = None,
    api_key: str | None = None,
    external_id: str | None = None,
    identity_provider: str | None = None,
    idp_metadata: str | None = None,
) -> str:
    """
    Import Agent Unified

    Args:
        agent_url: Remote black_box: Agent endpoint URL to call (e.g., https://api.example.com/agent)
        agent_card: Local grey_box: Upload agent configuration/card JSON directly (JSON object string)
        source_code: Local white_box: Upload agent source code files directly (JSON object string)
        framework: Framework identifier (for informational purposes only)
        entry_point: For white box: path to main file
        override_name: Override agent name
        rate_limit_requests_per_minute: Rate Limit Requests Per Minute
        api_key: API key for the agent
        external_id: External identity ID
        identity_provider: Identity provider name
        idp_metadata: IdP-specific metadata (JSON object string)
    """
    args: dict[str, Any] = {}
    args["agent_url"] = agent_url
    args["agent_card"] = agent_card
    args["source_code"] = source_code
    args["framework"] = framework
    args["entry_point"] = entry_point
    args["override_name"] = override_name
    args["rate_limit_requests_per_minute"] = rate_limit_requests_per_minute
    args["api_key"] = api_key
    args["external_id"] = external_id
    args["identity_provider"] = identity_provider
    args["idp_metadata"] = idp_metadata
    return run_vijil("agent", "import", args)

@server.tool()
def agent_validate_import(
    agent_url: str | None = None,
    agent_card: str | None = None,
    source_code: str | None = None,
    framework: str | None = None,
    entry_point: str | None = None,
    override_name: str | None = None,
    rate_limit_requests_per_minute: int | None = None,
    api_key: str | None = None,
    external_id: str | None = None,
    identity_provider: str | None = None,
    idp_metadata: str | None = None,
) -> str:
    """
    Validate Agent Import

    Args:
        agent_url: Remote black_box: Agent endpoint URL to call (e.g., https://api.example.com/agent)
        agent_card: Local grey_box: Upload agent configuration/card JSON directly (JSON object string)
        source_code: Local white_box: Upload agent source code files directly (JSON object string)
        framework: Framework identifier (for informational purposes only)
        entry_point: For white box: path to main file
        override_name: Override agent name
        rate_limit_requests_per_minute: Rate Limit Requests Per Minute
        api_key: API key for the agent
        external_id: External identity ID
        identity_provider: Identity provider name
        idp_metadata: IdP-specific metadata (JSON object string)
    """
    args: dict[str, Any] = {}
    args["agent_url"] = agent_url
    args["agent_card"] = agent_card
    args["source_code"] = source_code
    args["framework"] = framework
    args["entry_point"] = entry_point
    args["override_name"] = override_name
    args["rate_limit_requests_per_minute"] = rate_limit_requests_per_minute
    args["api_key"] = api_key
    args["external_id"] = external_id
    args["identity_provider"] = identity_provider
    args["idp_metadata"] = idp_metadata
    return run_vijil("agent", "validate-import", args)

@server.tool()
def agent_archive(id: str) -> str:
    """
    Archive Agent Configuration

    Args:
        id: The id
    """
    return run_vijil("agent", "archive", {}, positional=[id])

@server.tool()
def agent_lifecycle(id: str, trust_stage: str) -> str:
    """
    Update Agent Lifecycle

    Args:
        id: The id
        trust_stage: Trust maturity lifecycle stage for an agent. (one of: registered, tested, hardened, trusted, optimized, adapted)
    """
    args: dict[str, Any] = {}
    args["trust_stage"] = trust_stage
    return run_vijil("agent", "lifecycle", args, positional=[id])

@server.tool()
def agent_dome_configs(agent_id: str) -> str:
    """
    Get Agent Dome Config

    Args:
        agent_id: The agent id
    """
    return run_vijil("agent", "dome-configs", {}, positional=[agent_id])

@server.tool()
def agent_eval_config(id: str) -> str:
    """
    Get Evaluation Config

    Args:
        id: The id
    """
    return run_vijil("agent", "eval-config", {}, positional=[id])
