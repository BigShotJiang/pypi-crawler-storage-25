# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""FastMCP server for Vijil Console."""

from __future__ import annotations

from fastmcp import FastMCP

server = FastMCP(
    "Vijil Console",
    instructions=(
        "Interact with the Vijil AI trust platform — manage agents, "
        "run evaluations, red team attacks, configure guardrails, and more. "
        "Requires the vijil CLI to be installed and configured "
        "(vijil auth init + vijil auth login)."
    ),
)

# Tool modules must be imported AFTER the server object is created above,
# because each module uses @server.tool() decorators at import time.
from vijil_mcp.tools import (  # noqa: E402, F401
    agent,
    dashboard,
    demographics,
    dimensions,
    dome,
    eval,
    evolution,
    genome,
    harness,
    persona,
    policy,
    proposal,
    redteam,
    telemetry,
)

# Import hand-written tool modules.
from vijil_mcp.tools import auth, team  # noqa: E402, F401


def main() -> None:
    """Run the MCP server on stdio transport."""
    server.run(transport="stdio", show_banner=False)
