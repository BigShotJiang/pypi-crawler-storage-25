from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext

_PSQL = ["psql", "-U", "postgres", "-d", "postgres"]


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Insert seed/fixture data into local Supabase (truncates first)",
)
def supabase__db__seed(
    context: ExecutionContext,
    service: AppService,
) -> None:
    io = context.io
    app_addon = __import__(
        "wexample_wex_addon_app.app_addon_manager", fromlist=["AppAddonManager"]
    ).AppAddonManager.from_kernel(context.kernel)

    seed_path = service.app_workdir.get_path() / "supabase" / "seed.sql"
    if not seed_path.exists():
        io.error(message="supabase/seed.sql not found")
        return

    io.log("Seeding database…")
    app_addon.docker_cp("supabase_db", seed_path, "/tmp/_seed.sql")
    app_addon.docker_exec("supabase_db", _PSQL + ["-f", "/tmp/_seed.sql"])
    io.success(message="Seed applied.")
