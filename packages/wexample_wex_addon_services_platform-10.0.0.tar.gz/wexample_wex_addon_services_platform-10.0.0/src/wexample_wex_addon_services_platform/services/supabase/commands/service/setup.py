from __future__ import annotations

import secrets
from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Create required filesystem config for supabase/postgres container",
)
def supabase__service__setup(
    context: ExecutionContext,
    service: AppService,
) -> None:
    from wexample_helpers.helpers.file import (
        file_chown_as_real_user,
        file_mkdir_as_real_user,
    )

    db_config_path = service.app_workdir.get_path() / "supabase" / "db" / "config"
    file_mkdir_as_real_user(db_config_path)

    for conf_file in ["wal-g.conf", "read-replica.conf", "supautils.conf"]:
        conf_path = db_config_path / conf_file
        if not conf_path.exists():
            conf_path.touch()
            file_chown_as_real_user(conf_path)
            context.io.log(f"  ✓ db/config/{conf_file}")

    pgsodium_key_path = db_config_path / "pgsodium_root.key"
    if not pgsodium_key_path.exists():
        pgsodium_key_path.write_text(secrets.token_hex(32))
        file_chown_as_real_user(pgsodium_key_path)
        context.io.log("  ✓ db/config/pgsodium_root.key")
