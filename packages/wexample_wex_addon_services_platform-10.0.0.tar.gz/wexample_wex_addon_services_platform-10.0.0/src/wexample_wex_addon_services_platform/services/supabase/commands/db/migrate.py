from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext

_PSQL = ["psql", "-U", "postgres", "-d", "postgres"]
_ENSURE_TRACKING_TABLE = """
create table if not exists _migrations (
  filename text primary key,
  applied_at timestamptz not null default now()
);
"""


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Apply pending SQL migrations to local Supabase",
)
def supabase__db__migrate(
    context: ExecutionContext,
    service: AppService,
) -> None:
    pass

    from wexample_wex_addon_app.app_addon_manager import AppAddonManager

    io = context.io
    app_addon = AppAddonManager.from_kernel(context.kernel)

    migrations_path = service.app_workdir.get_path() / "supabase" / "migrations"
    if not migrations_path.exists():
        io.error(message="supabase/migrations/ directory not found")
        return

    app_addon.docker_exec("supabase_db", _PSQL + ["-c", _ENSURE_TRACKING_TABLE])

    result = app_addon.docker_exec(
        "supabase_db",
        _PSQL + ["-t", "-A", "-c", "select filename from _migrations;"],
    )
    applied = set(result.stdout.strip().splitlines())

    files = sorted(migrations_path.glob("*.sql"))
    pending = [f for f in files if f.name not in applied]

    if not pending:
        io.log("Nothing to migrate.")
        return

    for migration in pending:
        io.log(f"Applying {migration.name}...")
        app_addon.docker_cp("supabase_db", migration, "/tmp/_migration.sql")
        app_addon.docker_exec("supabase_db", _PSQL + ["-f", "/tmp/_migration.sql"])
        app_addon.docker_exec(
            "supabase_db",
            _PSQL
            + [
                "-c",
                f"insert into _migrations (filename) values ('{migration.name}');",
            ],
        )

    io.success(message=f"{len(pending)} migration(s) applied.")
