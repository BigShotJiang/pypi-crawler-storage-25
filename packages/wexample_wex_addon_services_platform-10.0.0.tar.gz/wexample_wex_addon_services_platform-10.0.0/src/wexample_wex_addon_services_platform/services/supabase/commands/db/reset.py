from __future__ import annotations

from typing import TYPE_CHECKING

from wexample_wex_core.const.globals import COMMAND_TYPE_SERVICE
from wexample_wex_core.decorator.command import command

if TYPE_CHECKING:
    from wexample_wex_addon_app.service.app_service import AppService
    from wexample_wex_core.context.execution_context import ExecutionContext

_PSQL = ["psql", "-U", "postgres", "-d", "postgres"]

_DROP_SCHEMA = "drop schema public cascade; create schema public;"
_ENSURE_TRACKING = """
create table if not exists _migrations (
  filename text primary key,
  applied_at timestamptz not null default now()
);
"""


@command(
    type=COMMAND_TYPE_SERVICE,
    description="Reset local Supabase: drop schema, re-run all migrations, apply seed",
)
def supabase__db__reset(
    context: ExecutionContext,
    service: AppService,
) -> None:
    pass

    from wexample_filestate.enum.scopes import Scope
    from wexample_filestate.item.abstract_item_target import AbstractItemTarget
    from wexample_wex_addon_app.app_addon_manager import AppAddonManager

    io = context.io
    app_addon = AppAddonManager.from_kernel(context.kernel)

    AbstractItemTarget.apply(
        service.app_workdir,
        interactive=False,
        scopes={Scope.PERMISSIONS, Scope.OWNERSHIP},
    )

    migrations_path = service.app_workdir.get_path() / "supabase" / "migrations"
    seed_path = service.app_workdir.get_path() / "supabase" / "seed.sql"

    if not migrations_path.exists():
        io.error(message="supabase/migrations/ not found")
        return

    # 1. Drop and recreate schema
    io.log("Dropping schema…")
    app_addon.docker_exec("supabase_db", _PSQL + ["-c", _DROP_SCHEMA])

    # 2. Recreate migration tracking table
    app_addon.docker_exec("supabase_db", _PSQL + ["-c", _ENSURE_TRACKING])

    # 3. Apply all migrations in order
    files = sorted(migrations_path.glob("*.sql"))
    for migration in files:
        io.log(f"Applying {migration.name}…")
        app_addon.docker_cp("supabase_db", migration, "/tmp/_migration.sql")
        app_addon.docker_exec("supabase_db", _PSQL + ["-f", "/tmp/_migration.sql"])
        app_addon.docker_exec(
            "supabase_db",
            _PSQL
            + [
                "-c",
                f"insert into _migrations (filename) values ('{migration.name}');",
            ],
        )

    io.success(message=f"{len(files)} migration(s) applied.")

    # 4. Apply seed if present
    if seed_path.exists():
        io.log("Applying seed…")
        app_addon.docker_cp("supabase_db", seed_path, "/tmp/_seed.sql")
        app_addon.docker_exec("supabase_db", _PSQL + ["-f", "/tmp/_seed.sql"])
        io.success(message="Seed applied.")
    else:
        io.log("No seed.sql found, skipping.")
