from __future__ import annotations

from wexample_wex_addon_app.service.app_service import AppService as BaseAppService


class AppService(BaseAppService):
    def get_workdir_contribution(self, workdir) -> dict:
        from wexample_filestate.const.disk import DiskItemType

        return {
            "children": [
                {
                    "name": "temporal",
                    "type": DiskItemType.DIRECTORY,
                    "should_exist": True,
                    "children": [
                        {
                            "name": ".gitignore",
                            "type": DiskItemType.FILE,
                            "should_exist": True,
                            "should_contain_lines": ["/db/"],
                        },
                        {
                            "name": "db",
                            "type": DiskItemType.DIRECTORY,
                            "should_exist": True,
                            "mode": {
                                "permissions": "750",
                                "recursive": True,
                            },
                        },
                    ],
                }
            ]
        }
