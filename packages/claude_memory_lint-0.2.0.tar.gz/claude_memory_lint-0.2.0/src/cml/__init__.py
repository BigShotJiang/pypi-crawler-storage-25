"""claude-memory-lint — static lint for Claude Code memory directories."""

__version__ = "0.1.2"
