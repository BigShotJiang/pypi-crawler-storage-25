"""``cml`` command-line entry point.

Sub-commands:
    cml check  PATH...     run all enabled rules and report findings
    cml fix    PATH...     attempt automatic fixes (frontmatter scaffolding only)
    cml stats  PATH...     emit summary counts (no file contents in output)
"""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from collections.abc import Iterable
from pathlib import Path

from cml import __version__
from cml.parser import ParsedFile, first_h1, parse_file
from cml.reporters import REPORTERS
from cml.rules import CORPUS_RULES, PER_FILE_RULES
from cml.violation import Severity, Violation

DEFAULT_CONFIG: dict = {
    "size_warn_kb": 25,
    "size_error_kb": 30,  # v0.1.2 lowered from 50; cli.py default was missed in that release.
    "stopword_density_pct": 40,
    "stale_days": 180,
    "check_orphan": True,
    # R010 dangling-link / R011 stale-backup are opt-in: see their
    # module docstrings for why they default off.
    "check_dangling_links": False,
    "check_stale_backup": False,
    "backup_stale_days": 7,
    "exclude": [],
    "rules": "all",  # "all" or list of rule ids
}


def _expand_paths(args: Iterable[str]) -> list[Path]:
    """Expand command-line PATH... arguments into a list of *.md files."""
    out: list[Path] = []
    for raw in args:
        p = Path(raw).expanduser()
        if p.is_dir():
            out.extend(sorted(m for m in p.glob("*.md") if not m.name.startswith(".")))
        elif p.is_file():
            out.append(p)
        else:
            print(f"warning: path does not exist: {p}", file=sys.stderr)
    return out


def _filter_rules(config: dict) -> tuple[set[str], set[str]]:
    """Return (per_file_ids, corpus_ids) selected by config.

    ``config["rules"]`` is either the string ``"all"`` or a list of rule ids.
    Anything else is rejected explicitly so a misspelled override does not
    silently disable every rule.
    """
    selected = config.get("rules", "all")
    if selected == "all":
        return set(PER_FILE_RULES), set(CORPUS_RULES)
    if not isinstance(selected, list):
        raise ValueError(
            f"config['rules'] must be 'all' or a list of rule ids; got {type(selected).__name__}"
        )
    ids = set(selected)
    unknown = ids - set(PER_FILE_RULES) - set(CORPUS_RULES)
    if unknown:
        raise ValueError(f"unknown rule ids: {sorted(unknown)}")
    return ids & set(PER_FILE_RULES), ids & set(CORPUS_RULES)


def run_check(paths: list[Path], config: dict) -> list[Violation]:
    files: list[ParsedFile] = []
    parse_errors: list[Violation] = []
    for p in paths:
        try:
            files.append(parse_file(p))
        except OSError as e:
            parse_errors.append(
                Violation(
                    rule_id="R000",
                    severity=Severity.ERROR,
                    path=p,
                    message=f"failed to read: {e}",
                    line=None,
                    fixable=False,
                )
            )

    per_file_ids, corpus_ids = _filter_rules(config)
    violations: list[Violation] = list(parse_errors)
    for parsed in files:
        for rule_id in per_file_ids:
            try:
                violations.extend(PER_FILE_RULES[rule_id](parsed, config))
            except Exception as e:
                violations.append(
                    Violation(
                        rule_id=rule_id,
                        severity=Severity.ERROR,
                        path=parsed.path,
                        message=f"rule crashed: {e}",
                        line=None,
                        fixable=False,
                    )
                )
    for rule_id in corpus_ids:
        try:
            violations.extend(CORPUS_RULES[rule_id](files, config))
        except Exception as e:
            violations.append(
                Violation(
                    rule_id=rule_id,
                    severity=Severity.ERROR,
                    path=Path("<corpus>"),
                    message=f"rule crashed: {e}",
                    line=None,
                    fixable=False,
                )
            )
    return violations


# --- Auto-fix ---------------------------------------------------------------

_GENERIC_STOP = {
    "memory", "project", "system", "notes", "log", "logs", "doc", "docs",
    "todo", "draft", "wip", "tmp", "test", "tests", "main", "common",
    "the", "and", "for", "with", "from", "into", "this", "that",
    "の", "を", "が", "は", "に", "で", "と", "も", "や",
}


def _candidate_aliases(stem: str, h1: str) -> list[str]:
    raw = re.split(r"[\s\-_,;:/／()（）\[\]]+", f"{stem} {h1}")
    seen: set[str] = set()
    out: list[str] = []
    for r in raw:
        t = r.strip().lower()
        if not t or len(t) < 3 or t.isdigit() or t in _GENERIC_STOP:
            continue
        if re.match(r"^\d{4}([-/]\d{1,2}){0,2}$", t):
            continue
        if t in seen:
            continue
        seen.add(t)
        out.append(t)
        if len(out) >= 6:
            break
    return out


def _atomic_write(path: Path, text: str, mode: int = 0o600) -> None:
    """Write *text* to *path* via tmpfile+replace, then chmod to *mode*.

    On error mid-write we leave *path* untouched. Guarantees no truncated
    state is observable.
    """
    import os as _os

    tmp = path.with_suffix(path.suffix + f".tmp.{_os.getpid()}.{_os.urandom(4).hex()}")
    try:
        tmp.write_text(text, encoding="utf-8")
        try:
            _os.chmod(tmp, mode)
        except OSError:
            pass
        tmp.replace(path)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def run_fix(paths: list[Path], config: dict, *, force: bool = False) -> int:
    changed = 0
    failed = 0
    for p in paths:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            print(f"skip {p}: {e}", file=sys.stderr)
            failed += 1
            continue

        h1 = first_h1(text)
        aliases = _candidate_aliases(p.stem, h1)
        if not aliases:
            print(f"skip {p}: no usable aliases derived", file=sys.stderr)
            continue

        if text.startswith("---\n"):
            try:
                end = text.index("\n---\n", 4)
            except ValueError:
                print(f"skip {p}: malformed frontmatter", file=sys.stderr)
                failed += 1
                continue
            head = text[:end]
            if "aliases:" in head and not force:
                continue
            new_text = head + f"\naliases: [{', '.join(aliases)}]" + text[end:]
        else:
            block = (
                "---\n"
                f"name: {h1 or p.stem.replace('-', ' ').replace('_', ' ')}\n"
                "description: (auto-generated; please review)\n"
                "type: project\n"
                f"aliases: [{', '.join(aliases)}]\n"
                "triggers: []\n"
                "---\n\n"
            )
            new_text = block + text

        # Backup with strict 600 permissions, then atomic write of the new text.
        bak = p.with_suffix(p.suffix + ".bak")
        try:
            if not bak.exists():
                bak.write_text(text, encoding="utf-8")
                try:
                    bak.chmod(0o600)
                except OSError:
                    pass
            _atomic_write(p, new_text, mode=0o600)
        except OSError as e:
            print(f"fail {p}: {e}", file=sys.stderr)
            failed += 1
            continue
        changed += 1
        print(f"fixed: {p}  aliases={aliases}")

    print(f"\n# applied frontmatter to {changed}/{len(paths)} files (failed: {failed})")
    # exit non-zero whenever any file failed *or* when fix found nothing to do
    # but at least one input was unparseable. callers should treat 0 as "all clean".
    return 1 if failed else 0


def run_stats(paths: list[Path], config: dict) -> int:
    violations = run_check(paths, config)
    counts: Counter = Counter(v.severity for v in violations)
    print(f"files scanned: {len(paths)}")
    for sev in (Severity.ERROR, Severity.WARN, Severity.INFO):
        print(f"  {sev.value:5s} {counts[sev]}")
    by_rule: Counter = Counter(v.rule_id for v in violations)
    print("by rule:")
    for rid, n in sorted(by_rule.items()):
        print(f"  {rid}: {n}")
    return 0


# --- Argument parsing -------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="cml",
        description="claude-memory-lint — static lint for Claude Code memory directories.",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    pc = sub.add_parser("check", help="run lint rules and report findings")
    pc.add_argument("paths", nargs="+", help="files or directories to scan")
    pc.add_argument("--format", choices=list(REPORTERS), default="text")
    pc.add_argument("--rule", action="append", default=None,
                     help="restrict to one rule id (repeatable)")
    pc.add_argument("--no-orphan", action="store_true", help="disable R005")
    pc.add_argument(
        "--dangling-links", action="store_true",
        help="enable R010 (dangling markdown link detection)",
    )
    pc.add_argument(
        "--stale-backup", action="store_true",
        help="enable R011 (stale .bak/.backup/.orig file detection)",
    )

    pf = sub.add_parser("fix", help="attempt to auto-fix R001/R002 with synthesised aliases")
    pf.add_argument("paths", nargs="+")
    pf.add_argument("--force", action="store_true",
                     help="overwrite existing aliases")

    ps = sub.add_parser("stats", help="emit summary counts (no file contents)")
    ps.add_argument("paths", nargs="+")

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    paths = _expand_paths(args.paths)
    if not paths:
        print("no markdown files found", file=sys.stderr)
        return 2

    config = dict(DEFAULT_CONFIG)
    if args.command == "check":
        if args.rule:
            config["rules"] = args.rule
        if args.no_orphan:
            config["check_orphan"] = False
        if args.dangling_links:
            config["check_dangling_links"] = True
        if args.stale_backup:
            config["check_stale_backup"] = True
        violations = run_check(paths, config)
        out = REPORTERS[args.format](violations)
        print(out)
        # exit 1 if any ERROR
        return 1 if any(v.severity is Severity.ERROR for v in violations) else 0
    if args.command == "fix":
        return run_fix(paths, config, force=args.force)
    if args.command == "stats":
        return run_stats(paths, config)
    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
