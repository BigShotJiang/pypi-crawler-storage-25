"""Lint rule registry. Each rule is callable: ``ParsedFile -> list[Violation]``."""

from __future__ import annotations

from collections.abc import Callable

from cml.parser import ParsedFile
from cml.violation import Violation

from .r001_frontmatter import check as _r001
from .r002_aliases import check as _r002
from .r003_size import check as _r003
from .r004_filename import check as _r004
from .r005_orphan import check as _r005
from .r006_stopword import check as _r006
from .r007_duplicate import check as _r007  # operates on the corpus, used separately
from .r008_stale import check as _r008
from .r009_secret import check as _r009
from .r010_dangling import check as _r010
from .r011_backup import check as _r011  # corpus-level

# Per-file rules — each takes a ParsedFile and config, returns a list of Violation.
PER_FILE_RULES: dict[str, Callable[[ParsedFile, dict], list[Violation]]] = {
    "R001": _r001,
    "R002": _r002,
    "R003": _r003,
    "R004": _r004,
    "R005": _r005,
    "R006": _r006,
    "R008": _r008,
    "R009": _r009,
    "R010": _r010,
}

# Corpus-level rules — take the full list of ParsedFile and config.
CORPUS_RULES: dict[str, Callable[[list[ParsedFile], dict], list[Violation]]] = {
    "R007": _r007,
    "R011": _r011,
}

ALL_RULE_IDS: list[str] = sorted(set(PER_FILE_RULES) | set(CORPUS_RULES))
