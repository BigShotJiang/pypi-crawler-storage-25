# CHANGELOG — claude-memory-lint

## v0.2.0 — 2026-05-09 (later)

Three new rules driven by a single live debugging session in which the
companion harness — and several memory files — degraded simultaneously
from a tangle of write-side anti-patterns the existing R001–R008 set
did not cover. Two of the three are opt-in; the third (R009) is on by
default because it backstops an R11-class privacy violation that
slipped past `.gitignore` for several days.

### Added — R009 secret literal detection (default ON, ERROR)

Catches credential-shaped strings (GitHub Classic / OAuth / fine-grained
PAT, AWS access + temporary keys, Anthropic / OpenAI keys, Google API
key, Slack `xox[abprs]-…` tokens, Stripe live / test keys) inside the
file body.

Three properties were non-negotiable in the design:

1. **The match itself is never written to the violation message.**
   Reporters print only file path, line, and the *type* of pattern
   that matched. A lint that leaks the secret it just caught is
   strictly worse than no lint at all — the leak now also lives in CI
   logs, SARIF artifacts, and pre-commit output. A regression test
   asserts the literal does not appear in the message for every
   supported pattern type.
2. **Allowlist for legitimate documentation context.** Lines whose
   surrounding text strongly indicates the literal is a placeholder
   (`<REVOKED-…>`, `<EXAMPLE-…>`, `<REDACTED-…>`, `[REDACTED]`,
   `your_token_here`, `dummy_token`, …) or a regex describing the
   *shape* of a secret (character classes like `[A-Za-z0-9]`,
   quantifiers like `{36}`, the words `regex` / `pattern`) are
   skipped. This keeps security-tooling repos that document token
   shapes from drowning in false positives.
3. **Default ON.** R009 backstops a TIER-1 privacy rule the OSS author
   already had in place. A user who genuinely needs to paste a token
   into a memory file (rare; nearly always a different pathology) can
   disable the rule via `--rule R001 --rule R002 …` selection or by
   marking the file appropriately for the allowlist.

### Added — R010 dangling markdown link (opt-in, WARN)

Reports markdown links of the form `](path.md)` whose target cannot be
resolved against the file's parent directory or against a sibling
`archive/` subtree (the convention used by `claude-memory-router`).

Opt-in via `--dangling-links` or `check_dangling_links: true` because
projects with multi-worktree memory layouts, symlinked corpora, or
non-standard archive paths produce false positives. The flat
`memory/` + `memory/archive/<bucket>/` layout — the one the router was
built around — gets the cleanest signal.

### Added — R011 stale backup file (opt-in, WARN, corpus-level)

Walks the active directory for files matching `*.bak`, `*.backup`,
`*.orig`, trailing `~`, or snapshot patterns like `foo.md.bak.<ts>`,
and warns when their mtime is older than `backup_stale_days` (default
7).

Opt-in because `cml fix` itself writes a sibling `.bak` while adding
frontmatter — turning the rule on by default would have the lint warn
about its own auto-fix output the moment the user ran it. Once an
archive flow exists, switching the rule on (`--stale-backup` or
`check_stale_backup: true`) catches the stragglers that never got
moved.

### Fixed — R003 default error threshold consistency

`cli.py` still carried the v0.1.1 default of `size_error_kb: 50`
despite the v0.1.2 release lowering the rule's effective threshold to
30 KiB elsewhere (rule docstring, README, CHANGELOG, tests). The CLI
default is now `30`, matching the rest of the release. Users who pin a
config file with `size_error_kb` set explicitly are unaffected.

### Tests

- 5 new R009 cases (clean / GitHub PAT / message-never-leaks-match
  defence-in-depth across 7 token types / placeholder allowlist / regex
  pattern allowlist).
- 5 new R010 cases (disabled-by-default / dangling / existing target /
  archive fallback / external URL skip).
- 5 new R011 cases (disabled-by-default / stale `.bak` /  fresh `.bak`
  ok / snapshot-style `.bak.<ts>` / `.orig` + `~` detection).
- Total: +15 tests, no existing test changed.

### Discussion record

The release went through R14 large-scope discussion (analyst + critic
agents debating in parallel before any code was written). Four
candidate rules — archive subdirectory naming consistency, completed
✅ task in active directory, a `MEMORY.md`-style required-reading
length cap, bare-text mentions of moved files — were rejected for
being either user-individual conventions (n=1 generalisation failures)
or for overlapping with R005 / R008. The two retained opt-in rules
(R010, R011) survived the same review because their detection logic
was cleanly orthogonal to existing rules and the false-positive risk
could be confined behind an explicit flag.

## v0.1.2 — 2026-05-09

Companion release to `claude-memory-router` v0.1.2. The router fixed
two pollution sources at *read time*; this release tightens the
*write-time* warning that the router itself relied on staying loose.

### Changed — R003 default error threshold lowered from 50 KiB to 30 KiB

A 50 KiB ceiling was generous to the point of letting one rule file
push past 30 KiB unchallenged. In real workloads, a 30 KiB pinned
file already costs 30 KiB on every single turn — orders of magnitude
more than any other line item in the auto-load budget — and the
warning fires too late to be useful. v0.1.2 lowers the default
**error** to 30 KiB so the lint flags the file before it becomes a
chronic context-pollution source. The 25 KiB warn threshold is
unchanged.

This is technically a breaking change (a file at 35 KiB that was
WARN under v0.1.1 is now ERROR under v0.1.2), but it is the kind of
breaking change you actually want — the file was almost certainly
contributing to the symptoms that bring users to this lint in the
first place. Users who explicitly want the v0.1.1 behaviour can opt
back in:

```yaml
# .pre-commit-config.yaml or equivalent
- id: cml
  args: [--config, cml.toml]
```

```toml
# cml.toml
[rules.R003]
size_error_kb = 50
```

No new rules are added in v0.1.2. The 5 candidate new rules
(safety-word-density / body-line-overrun / draft-in-active-file /
vocabulary-collision / opt-in-error-size) considered for this
release were rejected during a 2-agent design review for being
either user-specific symptom projections (not generalisable to the
OSS user base) or implementations whose false-positive rate would
overwhelm their signal — see [PR/discussion link] for the rationale.
The conservative outcome here is intentional: lint rules are easier
to add than to retract, and v0.1.1 was already addressing 90%+ of
the in-scope failure modes.

### Tests

- `test_R003_v012_default_error_30kb` — 28 KiB is now WARN (was WARN), the new ERROR threshold is 30 KiB.
- `test_R003_v012_legacy_50kb_opt_in` — verifies the `size_error_kb: 50` opt-in still works.
- Existing `test_R003_error_threshold` adjusted from 51 KiB to 31 KiB to match the new default.

## v0.1.1 — 2026-05-08

- **R007 false-positive fix**: pure-date stems (`2026-01-01.md`)
  fall back to the original stem when `_normalize_stem` returns
  empty.
- **CLI `run_fix` exit code**: now returns 1 when any rule failed,
  so CI integrations actually fail.
- **CLI `_filter_rules`**: invalid rule names raise `ValueError`
  instead of silently disabling all rules.
- **Atomic .bak**: tmpfile + replace, mode 600. SECURITY.md updated.

## v0.1.0 — 2026-05-08

Initial public release. 8 rules (R001–R008), pre-commit integration,
SARIF reporter, fix subcommand for R002 alias backfill.
