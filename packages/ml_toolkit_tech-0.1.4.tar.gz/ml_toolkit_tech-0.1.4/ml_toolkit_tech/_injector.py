import json
import os

def _load_practicals():
    path = os.path.join(os.path.dirname(__file__), "practicals.json")
    with open(path, "r") as f:
        return {p["id"]: p for p in json.load(f)["practicals"]}

def _make_notebook(cells_code: list) -> dict:
    """Build a minimal .ipynb dict from a list of code strings."""
    cells = []
    for code in cells_code:
        cells.append({
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": code
        })
    return {
        "nbformat": 4,
        "nbformat_minor": 5,
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3.10.0"}
        },
        "cells": cells
    }

def _save_notebook(filename: str, nb: dict):
    with open(filename, "w") as f:
        json.dump(nb, f, indent=2)
    print(f"✓ Notebook saved: {filename}")

def inject(practical_id: int):
    """Injects the practical code into the next Colab cell and saves a .ipynb file."""
    practicals = _load_practicals()
    if practical_id not in practicals:
        raise ValueError(f"Practical {practical_id} not found.")

    p = practicals[practical_id]
    code = p["code"]
    filename = f"practical_{practical_id}.ipynb"

    # Save notebook file
    nb = _make_notebook([code])
    _save_notebook(filename, nb)

    # Inject into next Colab cell
    try:
        from google.colab import _message  # noqa
        import IPython
        shell = IPython.get_ipython()
        shell.set_next_input(code, replace=False)
        print(f"✓ Practical {practical_id}: '{p['title']}' injected into next cell.")
    except ImportError:
        print(f"# Practical {practical_id}: {p['title']}\n")
        print(code)

def inject_all():
    """Injects all practicals into one next Colab cell and saves a combined .ipynb file."""
    practicals = _load_practicals()
    sorted_ids = sorted(practicals.keys())

    codes = [practicals[pid]["code"] for pid in sorted_ids]
    combined = ("\n\n" + "=" * 60 + "\n\n").join(codes)

    # Save all practicals as separate cells in one notebook
    nb = _make_notebook(codes)
    _save_notebook("all_practicals.ipynb", nb)

    # Inject combined into single next cell
    try:
        from google.colab import _message  # noqa
        import IPython
        shell = IPython.get_ipython()
        shell.set_next_input(combined, replace=False)
        print(f"✓ All {len(sorted_ids)} practicals injected into next cell.")
    except ImportError:
        print(combined)
