from setuptools import setup, find_packages

setup(
    name="ml_toolkit_tech",
    version="0.1.4",
    packages=find_packages(),
    package_data={"ml_toolkit_tech": ["practicals.json"]},
    install_requires=[],
    author="Your Name",
    author_email="your@email.com",
    python_requires=">=3.7",
)
