# ml_toolkit_tech

Inject ML practical code directly into the next Google Colab cell.

## Install

```bash
pip install ml_toolkit_tech
```

## Usage in Google Colab

```python
from ml_toolkit_tech import tech1  # injects Practical 1 code into next cell
from ml_toolkit_tech import tech2  # injects Practical 2 code into next cell
```

Each `techN` call writes the corresponding practical's code into the next cell automatically.

## Practicals

| Import | Title |
|--------|-------|
| `tech1` | TensorFlow Matrix Operations |
| `tech2` | XOR Neural Network with Keras |
| `tech3` | Binary Classification with Keras and Sklearn |
| `tech4` | Autoencoder on MNIST Dataset |
| `tech5` | CNN on MNIST Dataset |
| `tech6` | Convolutional Denoising Autoencoder on MNIST |
