import os
import shutil

def main():
    dest = os.getcwd()
    scaffold_dir = os.path.join(os.path.dirname(__file__), 'scaffold')
    
    for filename in os.listdir(scaffold_dir):
        src = os.path.join(scaffold_dir, filename)
        if os.path.isfile(src):
            shutil.copy2(src, dest)
            print(f"Copied: {filename}")
    
    print("Done.")
