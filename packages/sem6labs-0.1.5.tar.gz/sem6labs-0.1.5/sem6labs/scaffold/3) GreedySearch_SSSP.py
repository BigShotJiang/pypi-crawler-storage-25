class Dijkstra:
    def __init__(self) -> None:
        self.vertices = int(input("Enter number of vertices: "))
        self.graph = [[float('inf')]*self.vertices for _ in range(self.vertices)]

        self.edges = int(input("Enter number of edges: "))
        print()
        print("Start End Distance")

        edges_added = 0
        while edges_added < self.edges:
            try:
                v1, v2, e = input().split(" ")
                v1, v2, e = int(v1), int(v2), int(e)
                if v1 == v2:
                    print("Self-loops not allowed, re-enter")
                    continue
                if not (1 <= v1 <= self.vertices) or not (1 <= v2 <= self.vertices):
                    print(f"Invalid. Enter values between 1 and {self.vertices}")
                    continue
                self.graph[v1-1][v2-1] = e
                self.graph[v2-1][v1-1] = e
                edges_added += 1  # only increments on valid input
            except ValueError:
                print("Invalid input. Enter: start end distance")
        
        for i in range(self.vertices):
            self.graph[i][i] = 0
    
    def printMatrix(self):
        print()
        print("\t",end="")
        for i in range(self.vertices):
            print(i+1,end="\t")
        print()
        for i,row in enumerate(self.graph):
            print(i+1,end="\t")
            for ele in row:
                print(ele,end="\t")
            print()
        print()
    
    def solve(self):
        source = int(input("Enter starting node : "))
        print()
        if not (1 <= source <= self.vertices):
            print(f"Enter a value between 1 and {self.vertices}")
            return
        visited = set()
        distances = [float('inf')] * self.vertices
        distances[source - 1] = 0

        while True:
            minDist = float('inf')
            minId = -1
            for i,dist in enumerate(distances):
                if dist < minDist and i not in visited:
                    minDist = dist
                    minId = i
            
            if minId == -1:
                break

            for i,distance in enumerate(self.graph[minId]):
                if distances[i] > minDist + distance:
                    distances[i] = minDist + distance
            visited.add(minId)
        
        print(f"Distances from source {source}:")
        for i,distance in enumerate(distances):
            print(f"Distance to {i+1}: {distance}")



solver = Dijkstra()
solver.printMatrix()
solver.solve()

print('\n', '-' * 40)
