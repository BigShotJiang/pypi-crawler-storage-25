def get_float(prompt):
    while True:
        try: return float(input(prompt))
        except ValueError: print("Invalid input")

def analyze(price, ma, rsi, vol, avg_vol, pe, eps):
    signals = []
    if price < ma: signals.append("Price below moving average (bearish trend)")
    else: signals.append("Price above moving average (bullish trend)")
    if rsi < 30: signals.append("RSI oversold - potential buy opportunity")
    elif rsi > 70: signals.append("RSI overbought - potential sell opportunity")
    else: signals.append("RSI neutral")
    if vol > avg_vol * 1.5: signals.append("High volume - strong market conviction")
    elif vol < avg_vol * 0.5: signals.append("Low volume - weak market conviction")
    if pe < 15: signals.append("Low P/E - potentially undervalued")
    elif pe > 30: signals.append("High P/E - potentially overvalued")
    if eps > 0: signals.append("Positive EPS - company is profitable")
    else: signals.append("Negative EPS - company is at a loss")

    buys  = sum(1 for s in signals if "buy" in s.lower() or "undervalued" in s.lower() or "profitable" in s.lower())
    sells = sum(1 for s in signals if "sell" in s.lower() or "overvalued" in s.lower() or "loss" in s.lower())

    print("\n--- Analysis ---")
    for s in signals: print(f"  • {s}")
    print(f"\nBuy signals: {buys} | Sell signals: {sells}")
    if buys > sells + 1:   
        print("Recommendation: STRONG BUY")
    elif buys > sells:     
        print("Recommendation: BUY")
    elif sells > buys + 1: 
        print("Recommendation: STRONG SELL")
    elif sells > buys:     
        print("Recommendation: SELL")
    else:                  
        print("Recommendation: HOLD")

while True:
    print("\n=== Stock Market Expert System ===")
    print("1. Evaluate Stock\n2. Exit")
    choice = input("Choice: ")
    if choice == "2": break
    elif choice == "1":
        stock  = input("Stock symbol: ").upper()
        price  = get_float("Current price: ")
        ma     = get_float("50-day moving average: ")
        rsi    = get_float("RSI (0-100): ")
        vol    = get_float("Today's volume: ")
        avg    = get_float("Average volume: ")
        pe     = get_float("P/E ratio: ")
        eps    = get_float("EPS: ")
        print(f"\nEvaluating {stock}...")
        analyze(price, ma, rsi, vol, avg, pe, eps)
    else: print("Invalid choice")
