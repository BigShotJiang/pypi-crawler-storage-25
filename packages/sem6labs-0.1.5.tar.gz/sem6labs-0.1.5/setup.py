import os
from setuptools import setup, find_packages

setup(
    name='sem6labs',
    version='0.1.5',
    packages=find_packages(),
    package_data={'sem6labs': ['scaffold/*']},
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'sem6labs=sem6labs.cli:main',  # sem6labs command → runs main() in sem6/cli.py
        ],
    },
)
