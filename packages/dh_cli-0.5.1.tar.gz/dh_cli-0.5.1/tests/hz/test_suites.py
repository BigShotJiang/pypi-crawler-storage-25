"""Tests for dh hz test suite discovery and resolution."""

import pytest
from click.exceptions import Exit

from dh_cli.hz.test import _discover_suites, _resolve_suites


@pytest.fixture
def test_dir(tmp_path):
    """Create a fake test directory with numbered scripts."""
    scripts = [
        "1_fast.sh",
        "2_full_sets.sh",
        "3_custom_sets.sh",
        "10_error_handling.sh",
        "20_feature_bundle.sh",
        "common.sh",
        "run_all_tests.sh",
    ]
    for name in scripts:
        (tmp_path / name).write_text("#!/bin/bash\necho test")
    return tmp_path


class TestDiscoverSuites:
    def test_finds_numbered_scripts(self, test_dir):
        suites = _discover_suites(test_dir)
        numbers = [s[0] for s in suites]
        assert numbers == [1, 2, 3, 10, 20]

    def test_extracts_names(self, test_dir):
        suites = _discover_suites(test_dir)
        names = [s[1] for s in suites]
        assert "fast" in names
        assert "full_sets" in names
        assert "feature_bundle" in names

    def test_excludes_non_numbered_scripts(self, test_dir):
        suites = _discover_suites(test_dir)
        names = [s[1] for s in suites]
        assert "common" not in names
        assert "run_all_tests" not in names

    def test_returns_correct_paths(self, test_dir):
        suites = _discover_suites(test_dir)
        for num, name, path in suites:
            assert path.exists()
            assert path.name == f"{num}_{name}.sh"

    def test_sorted_by_number(self, test_dir):
        suites = _discover_suites(test_dir)
        numbers = [s[0] for s in suites]
        assert numbers == sorted(numbers)

    def test_empty_directory(self, tmp_path):
        assert _discover_suites(tmp_path) == []


class TestResolveSuites:
    @pytest.fixture
    def available(self, test_dir):
        return _discover_suites(test_dir)

    def test_resolve_by_number(self, available):
        result = _resolve_suites(available, ["1"])
        assert len(result) == 1
        assert result[0][0] == 1

    def test_resolve_multiple_numbers(self, available):
        result = _resolve_suites(available, ["1", "3", "20"])
        assert [s[0] for s in result] == [1, 3, 20]

    def test_resolve_by_name(self, available):
        result = _resolve_suites(available, ["fast"])
        assert len(result) == 1
        assert result[0][1] == "fast"

    def test_resolve_by_name_substring(self, available):
        result = _resolve_suites(available, ["error"])
        assert len(result) == 1
        assert result[0][1] == "error_handling"

    def test_resolve_mixed_numbers_and_names(self, available):
        result = _resolve_suites(available, ["1", "error"])
        assert len(result) == 2
        assert result[0][0] == 1
        assert result[1][1] == "error_handling"

    def test_unknown_selector_exits(self, available):
        with pytest.raises(Exit):
            _resolve_suites(available, ["999"])

    def test_unknown_name_exits(self, available):
        with pytest.raises(Exit):
            _resolve_suites(available, ["nonexistent"])

    def test_name_match_is_case_insensitive(self, available):
        result = _resolve_suites(available, ["FAST"])
        assert result[0][1] == "fast"
