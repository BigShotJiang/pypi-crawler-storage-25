"""Tests for dh hz workspace discovery and repo resolution."""

from pathlib import Path
from unittest.mock import patch

import pytest
from click.exceptions import Exit

from dh_cli.hz import _find_workspace_root, require_repo


class TestFindWorkspaceRoot:
    def test_uses_workspace_root_env_var(self, tmp_path):
        with patch.dict("os.environ", {"WORKSPACE_ROOT": str(tmp_path)}):
            assert _find_workspace_root() == tmp_path

    def test_falls_back_to_scanning_workspaces(self, tmp_path):
        user_dir = tmp_path / "alice"
        user_dir.mkdir()

        with (
            patch.dict("os.environ", {"WORKSPACE_ROOT": ""}),
            patch("dh_cli.hz.Path") as mock_path,
        ):
            # WORKSPACE_ROOT="" → falsy, so it hits the scan branch
            # Make Path("/workspaces") return something that iterates to user_dir
            def path_factory(arg):
                if arg == "/workspaces":
                    p = Path(tmp_path)
                    return p
                return Path(arg)

            mock_path.side_effect = path_factory

            result = _find_workspace_root()
            assert result == user_dir

    def test_exits_when_nothing_found(self, tmp_path):
        empty_ws = tmp_path / "empty_workspaces"
        empty_ws.mkdir()

        with (
            patch.dict("os.environ", {"WORKSPACE_ROOT": ""}),
            patch("dh_cli.hz.Path") as mock_path,
        ):

            def path_factory(arg):
                if arg == "/workspaces":
                    return Path(empty_ws)
                return Path(arg)

            mock_path.side_effect = path_factory

            with pytest.raises(Exit):
                _find_workspace_root()


class TestRequireRepo:
    def test_returns_repo_path(self, tmp_path):
        repo = tmp_path / "horizyn-api"
        repo.mkdir()

        with patch("dh_cli.hz._find_workspace_root", return_value=tmp_path):
            assert require_repo("horizyn-api") == repo

    def test_exits_when_repo_missing(self, tmp_path):
        with patch("dh_cli.hz._find_workspace_root", return_value=tmp_path):
            with pytest.raises(Exit):
                require_repo("horizyn-api")
