"""Tests for ProtMPNN scores flattening in _finalize_protmpnn()."""

import tempfile
from pathlib import Path

import pytest

from dh_cli.batch.commands.finalize import _finalize_protmpnn


@pytest.fixture
def temp_dir():
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


def _create_protmpnn_output(
    output_dir: Path,
    config_names: list[str],
    include_scores: bool = False,
    include_stats: bool = False,
):
    """Build a mock ProtMPNN output directory structure.

    Creates results_worker_0.csv and per-config subdirs with seqs/.
    Optionally adds scores/ and stats/ directories.
    """
    import csv

    rows = []
    for config_name in config_names:
        config_dir = output_dir / config_name
        seqs_dir = config_dir / "seqs"
        seqs_dir.mkdir(parents=True)
        (seqs_dir / f"{config_name}.fa").write_text(">wt\nACDE\n>var1\nACDG\n")

        if include_scores:
            scores_dir = config_dir / "scores"
            scores_dir.mkdir()
            (scores_dir / f"{config_name}_scores.csv").write_text(
                "sample,chain,position,native_AA,designed_AA,log_prob,score\n1,A,1,A,A,-0.1,0.1\n"
            )

        if include_stats:
            stats_dir = config_dir / "stats"
            stats_dir.mkdir()
            (stats_dir / f"{config_name}.pt").write_bytes(b"fake pt data")

        rows.append(
            {
                "config_name": config_name,
                "variant_id": 1,
                "sequence": "ACDG",
                "overall_confidence": 0.95,
                "ligand_confidence": float("nan"),
                "sequence_recovery": 0.75,
                "num_mutations": 1,
                "mutation_list": "E4G",
            }
        )

    csv_path = output_dir / "results_worker_0.csv"
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


class TestFinalizeProtmpnnCopiesScoresAndStats:
    def test_csv_and_pt_flattened_to_scores(self, temp_dir):
        output_dir = temp_dir / "output"
        output_dir.mkdir()
        dest = temp_dir / "final"

        _create_protmpnn_output(
            output_dir,
            ["config_000", "config_001"],
            include_scores=True,
            include_stats=True,
        )

        _finalize_protmpnn(output_dir, dest)

        scores_dir = dest / "scores"
        assert scores_dir.exists()

        csv_files = sorted(scores_dir.glob("*.csv"))
        pt_files = sorted(scores_dir.glob("*.pt"))

        assert len(csv_files) == 2
        assert len(pt_files) == 2
        assert csv_files[0].name == "config_000_scores.csv"
        assert csv_files[1].name == "config_001_scores.csv"
        assert pt_files[0].name == "config_000.pt"
        assert pt_files[1].name == "config_001.pt"

    def test_scores_only_no_stats(self, temp_dir):
        output_dir = temp_dir / "output"
        output_dir.mkdir()
        dest = temp_dir / "final"

        _create_protmpnn_output(
            output_dir,
            ["config_000"],
            include_scores=True,
            include_stats=False,
        )

        _finalize_protmpnn(output_dir, dest)

        scores_dir = dest / "scores"
        assert scores_dir.exists()
        assert len(list(scores_dir.glob("*.csv"))) == 1
        assert len(list(scores_dir.glob("*.pt"))) == 0

    def test_stats_only_no_scores(self, temp_dir):
        output_dir = temp_dir / "output"
        output_dir.mkdir()
        dest = temp_dir / "final"

        _create_protmpnn_output(
            output_dir,
            ["config_000"],
            include_scores=False,
            include_stats=True,
        )

        _finalize_protmpnn(output_dir, dest)

        scores_dir = dest / "scores"
        assert scores_dir.exists()
        assert len(list(scores_dir.glob("*.pt"))) == 1
        assert len(list(scores_dir.glob("*.csv"))) == 0


class TestFinalizeProtmpnnNoScoresNoDir:
    def test_no_scores_dir_when_absent(self, temp_dir):
        """When no scores/ or stats/ dirs exist, no scores/ dir is created."""
        output_dir = temp_dir / "output"
        output_dir.mkdir()
        dest = temp_dir / "final"

        _create_protmpnn_output(
            output_dir,
            ["config_000"],
            include_scores=False,
            include_stats=False,
        )

        _finalize_protmpnn(output_dir, dest)

        assert not (dest / "scores").exists()
        # But seqs/ and results.csv should still exist
        assert (dest / "results.csv").exists()
        assert (dest / "seqs").exists()
