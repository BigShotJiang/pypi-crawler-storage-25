"""Structural tests for GCP commands after service account removal.

These tests verify the interface contract: which commands exist, which
constants/functions were removed, and that docstrings no longer reference
service account impersonation. No GCP credentials required.
"""

import inspect


def test_gcp_app_has_exactly_four_commands():
    """After cleanup, gcp_app should have: login, status, use-user-adc, logout."""
    from dh_cli.cloud_commands import gcp_app

    registered = {cmd_info.name or cmd_info.callback.__name__ for cmd_info in gcp_app.registered_commands}
    expected = {"login", "status", "use-user-adc", "logout"}
    assert registered == expected, (
        f"Expected commands {expected}, got {registered}. "
        f"Extra: {registered - expected}, Missing: {expected - registered}"
    )


def test_devcon_sa_constant_removed():
    """GCP_DEVCON_SA constant should no longer exist."""
    import dh_cli.cloud_commands as mod

    assert not hasattr(mod, "GCP_DEVCON_SA"), "GCP_DEVCON_SA should be removed"


def test_get_current_gcp_impersonation_removed():
    """The impersonation helper should no longer exist."""
    import dh_cli.cloud_commands as mod

    assert not hasattr(mod, "_get_current_gcp_impersonation"), "_get_current_gcp_impersonation should be removed"


def test_test_gcp_credentials_no_impersonation_param():
    """_test_gcp_credentials should not accept an impersonation_sa parameter."""
    from dh_cli.cloud_commands import _test_gcp_credentials

    sig = inspect.signature(_test_gcp_credentials)
    assert "impersonation_sa" not in sig.parameters, "_test_gcp_credentials should not have impersonation_sa parameter"


def test_login_docstring_no_impersonation():
    """Login command docstring should not mention impersonation or devcon."""
    from dh_cli.cloud_commands import gcp_login

    doc = (gcp_login.__doc__ or "").lower()
    assert "impersonat" not in doc, f"Docstring still mentions impersonation: {doc}"
    assert "devcon" not in doc, f"Docstring still mentions devcon: {doc}"


def test_gcp_project_id_still_exists():
    """GCP_PROJECT_ID should still be present (we still need it)."""
    from dh_cli.cloud_commands import GCP_PROJECT_ID

    assert GCP_PROJECT_ID == "enzyme-discovery"
