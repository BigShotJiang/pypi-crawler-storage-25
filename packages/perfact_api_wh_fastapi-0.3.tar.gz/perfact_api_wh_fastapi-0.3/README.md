# perfact-api-wh-fastapi

FastAPI integration for the WH domain. Mounts WH routes into a `perfact-api-main` application as a plugin. Part of the `perfact.api.wh_fastapi` namespace.

## How it works

This package registers itself via the `perfact.api` entry point group. When `perfact-api-main` starts, it discovers and calls `mount(app)` automatically:

```
INFO - try to include plugin: perfact.api.wh_fastapi.routes:mount
INFO - finished plugin discovery, included 1 plugins
```

Routes are declared in `perfact.api.wh_fastapi.routes` using the `Auth` and `DBSession` dependencies from `perfact-api-main`:

```python
from perfact.api.main.auth import require_roles, Auth
from perfact.api.main.dbsession import DBSession

@router.get("/wh/something")
@require_roles("WHRole")
def my_endpoint(auth: Auth, session: DBSession) -> ...:
    ...
```

## Dependencies

- `perfact-api-wh`
- `perfact-api-main`

## Maintainers

- Alexander Rolfes <alexander.rolfes@perfact.de>
