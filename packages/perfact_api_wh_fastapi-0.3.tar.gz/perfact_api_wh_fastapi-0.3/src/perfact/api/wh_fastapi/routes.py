from fastapi import APIRouter, FastAPI

router = APIRouter(prefix="/wh")


def mount(app: FastAPI) -> None:
    app.include_router(router)
