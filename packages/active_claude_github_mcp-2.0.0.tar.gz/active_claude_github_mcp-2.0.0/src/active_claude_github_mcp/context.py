"""Per-session server context (#82 Phase 2a).

ServerContext bundles the state that `build_server` previously held in
its closure. Introducing it is a prerequisite for Phase 2b, where the
inner async handlers move out of `build_server` into their own modules
and receive `ctx` as an explicit parameter instead of closing over it.

Phase 2a itself is behavior-neutral: the handlers still live inside
`build_server`, still capture `ctx` by closure, and still read / mutate
the same underlying state — just through attribute access on `ctx`
rather than separate closure variables.

Concurrency model matches `SessionActivity`: one instance per
`build_server()` call (i.e. per MCP stdio subprocess). Serialized
handler dispatch means no locking is needed as long as that assumption
holds.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from .models import GithubConfig
from .utils import SessionActivity


@dataclass
class ServerContext:
    """Per-session server state.

    `config` is `None` only in pre-bootstrap mode (#156): the project
    has no `.claude/github-config.json` yet because `scaffold_project`
    has not run. The dispatch in `build_server` rejects every tool
    that requires config in this mode, allowing only `scaffold_project`
    and `check_skill_version` (which operate without config) through.
    """
    config: GithubConfig | None
    github_token: str
    anthropic_api_key: str
    project_dir: Path
    current_session: dict | None = None
    activity: SessionActivity = field(default_factory=SessionActivity)
    pre_bootstrap: bool = False
