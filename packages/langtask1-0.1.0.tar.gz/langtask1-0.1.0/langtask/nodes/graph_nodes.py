"""
langtask/nodes/graph_nodes.py
-----------------------------
LangGraph node functions — planner, dispatcher, tool, router, aggregator.
All timing and token data is captured into state.telemetry.

Token extraction is handled by token_utils.extract_usage_metadata so every
provider's quirky metadata layout is normalised in one place.
"""

from __future__ import annotations
import json
import time
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from langtask.core.models     import GraphState, Task, TaskStatus, PlannerOutput
from langtask.core.dag_engine import DAGEngine
from langtask.tools.registry  import run_tool, cache_key
from langtask.token_utils     import extract_usage_metadata


# ── Planner ───────────────────────────────────────────────────────────────────

PLANNER_SYSTEM_TEMPLATE = """You are a task planner. Given a user request, decompose it into
atomic tasks and return ONLY valid JSON matching this schema exactly:

{{
  "tasks": [
    {{
      "id":          "<short unique id like t1>",
      "description": "<what this task does>",
      "tool":        "<tool name from the available tools list>",
      "tool_input":  {{ <key-value pairs for the tool> }},
      "depends_on":  ["<id>", ...]   // empty list if no deps
    }}
  ],
  "execution_note": "<optional one-line reasoning>"
}}

Available tools: {tools}

Rules:
- Use ONLY the tool names listed above
- depends_on must reference IDs defined earlier in the same list
- No circular dependencies
- Maximise parallelism: only add depends_on when output is needed by another task
- Return ONLY the JSON, no markdown fences, no explanation"""


def planner_node(state: GraphState, llm: Any, available_tools: list[str]) -> GraphState:
    t0 = time.perf_counter()

    system_prompt = PLANNER_SYSTEM_TEMPLATE.format(tools=" | ".join(available_tools))
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=state.user_request),
    ]

    response   = llm.invoke(messages)
    raw_json   = response.content.strip()

    # Generalised metadata extraction — works for every provider
    input_toks, output_toks = extract_usage_metadata(response)

    try:
        plan = PlannerOutput.model_validate_json(raw_json)
    except Exception as e:
        raise ValueError(f"Planner emitted invalid JSON: {e}\nRaw: {raw_json}") from e

    elapsed_ms = (time.perf_counter() - t0) * 1000
    total_toks = input_toks + output_toks

    state.tasks        = {t.id: t for t in plan.tasks}
    state.total_tokens += total_toks
    state.telemetry.planner_tokens     = total_toks
    state.telemetry.planner_elapsed_ms = elapsed_ms
    state.telemetry.llm_calls         += 1

    return state


# ── Dispatcher ────────────────────────────────────────────────────────────────

def dispatcher_node(state: GraphState, dag: DAGEngine) -> GraphState:
    done_ids  = {tid for tid, t in state.tasks.items() if t.status == TaskStatus.DONE}
    ready_ids = dag.get_ready_tasks(done_ids)
    not_pending = {tid for tid, t in state.tasks.items()
                   if t.status != TaskStatus.PENDING}
    to_dispatch = [rid for rid in ready_ids if rid not in not_pending]

    for tid in to_dispatch:
        state.tasks[tid].status = TaskStatus.READY

    state.wave += 1
    return state


# ── Tool node ─────────────────────────────────────────────────────────────────

def tool_node(state: GraphState, task_id: str) -> GraphState:
    task        = state.tasks[task_id]
    task.status = TaskStatus.RUNNING
    task.wave   = state.wave

    ck = cache_key(task.tool, task.tool_input)
    if ck in state.cache:
        task.result      = state.cache[ck]
        task.status      = TaskStatus.DONE
        task.tokens_used = 0
        task.elapsed_ms  = 0.0
        state.telemetry.cache_hits += 1
        return state

    t0     = time.perf_counter()
    result = run_tool(task.tool, task.tool_input)
    elapsed = (time.perf_counter() - t0) * 1000

    task.result      = result.output
    task.tokens_used = result.tokens_used
    task.elapsed_ms  = elapsed
    task.status      = TaskStatus.DONE

    state.cache[ck]              = result.output
    state.total_tokens          += result.tokens_used
    state.telemetry.tool_tokens += result.tokens_used
    state.telemetry.tool_calls  += 1

    return state


# ── Router ────────────────────────────────────────────────────────────────────

def router_node(state: GraphState, dag: DAGEngine) -> str:
    statuses   = {tid: t.status for tid, t in state.tasks.items()}
    all_done   = all(s == TaskStatus.DONE   for s in statuses.values())
    any_failed = any(s == TaskStatus.FAILED for s in statuses.values())

    if any_failed or all_done:
        return "aggregator"

    done_ids  = {tid for tid, t in state.tasks.items() if t.status == TaskStatus.DONE}
    ready_ids = dag.get_ready_tasks(done_ids)
    pending   = [rid for rid in ready_ids
                 if state.tasks[rid].status == TaskStatus.PENDING]

    return "dispatcher" if pending else "wait"


# ── Aggregator ────────────────────────────────────────────────────────────────

AGGREGATOR_SYSTEM = """You are a result synthesiser. You receive a user's original
request and the compressed outputs of all tasks executed to fulfil it.
Write a clear, concise final answer.

Rules:
- Be direct and structured
- Do not re-explain the tasks, just present the answer
- If any task failed, acknowledge it briefly and continue with available results"""


def aggregator_node(state: GraphState, llm: Any) -> GraphState:
    results_summary = []
    for tid, task in state.tasks.items():
        if task.status == TaskStatus.DONE:
            result_str = json.dumps(task.result)
            if len(result_str) > 400:
                result_str = result_str[:400] + "...<truncated>"
            results_summary.append(
                f"Task {tid} [{task.tool}] — {task.description}:\n{result_str}"
            )
        elif task.status == TaskStatus.FAILED:
            results_summary.append(f"Task {tid} [{task.tool}] — FAILED: {task.error}")

    context = "\n\n".join(results_summary)
    t0 = time.perf_counter()

    messages = [
        SystemMessage(content=AGGREGATOR_SYSTEM),
        HumanMessage(content=(
            f"User request: {state.user_request}\n\nTask results:\n{context}"
        )),
    ]

    response = llm.invoke(messages)

    # Generalised metadata extraction — works for every provider
    input_toks, output_toks = extract_usage_metadata(response)
    total_toks = input_toks + output_toks
    elapsed_ms = (time.perf_counter() - t0) * 1000

    state.final_response = response.content
    state.total_tokens  += total_toks
    state.telemetry.aggregator_tokens = total_toks
    state.telemetry.agg_elapsed_ms    = elapsed_ms
    state.telemetry.llm_calls        += 1

    return state
