"""
langtask/runner.py
------------------
Primary entry point. Orchestrates the full planner → DAG → wave-executor → aggregator pipeline.

Usage:
    from langtask import build_and_run

    # Quick demo (no API key needed):
    state = build_and_run("Analyse our Q3 metrics")
    print(state.final_response)

    # With a real LLM via llm_factory:
    from langtask.llm_factory import make_llm
    llm = make_llm("openai", api_key="sk-...")
    state = build_and_run("Research AI trends", llm=llm, show_telemetry=True)

    # With a pre-built LangChain LLM:
    from langchain_openai import ChatOpenAI
    llm = ChatOpenAI(model="gpt-4o", temperature=0)
    state = build_and_run("Research AI trends", llm=llm, show_telemetry=True)

    # With custom tools:
    from langtask.tools.registry import register_tool, ToolResult
    register_tool("my_api", lambda inp: ToolResult({"data": "..."}, tokens_used=0))
    state = build_and_run("Use my_api to fetch data", llm=llm)
"""

from __future__ import annotations
import time
import concurrent.futures
import logging
from typing import Any

from langtask.core.models     import GraphState, TaskStatus
from langtask.core.dag_engine import DAGEngine
from langtask.nodes.graph_nodes import (
    planner_node,
    tool_node,
    aggregator_node,
)
from langtask.tools.registry  import list_tools
from langtask.llm_factory     import make_llm

logger = logging.getLogger(__name__)


def build_and_run(
    user_request: str,
    llm: Any = None,
    scenario: str = "analytics",
    show_telemetry: bool = False,
    verbose: bool = True,
    max_workers: int | None = None,
) -> GraphState:
    """
    Execute the full LangTask pipeline.

    Parameters
    ----------
    user_request  : Natural language request sent to the planner.
    llm           : Any LangChain-compatible LLM (invoke interface), a provider
                    string accepted by make_llm(), or None (defaults to MockLLM).
    scenario      : Passed to MockLLM only ("analytics" | "research").
    show_telemetry: Print a detailed telemetry report after execution.
    verbose       : Print progress logs during execution.
    max_workers   : Thread-pool size per wave. Defaults to wave task count.

    Returns
    -------
    GraphState with .final_response and .telemetry populated.
    """
    # Accept a provider string, a pre-built LLM object, or None (MockLLM)
    if llm is None or isinstance(llm, str):
        provider = llm or "mock"
        llm = make_llm(provider, scenario=scenario)

    available_tools = list_tools()
    state = GraphState(user_request=user_request)
    t_total = time.perf_counter()

    # ── Step 1: Plan ─────────────────────────────────────────────────────────
    if verbose:
        print(f"\n[Planner] Decomposing request...")
    state = planner_node(state, llm, available_tools)

    if verbose:
        print(f"[Planner] {len(state.tasks)} tasks planned "
              f"| tokens: {state.telemetry.planner_tokens} "
              f"| {state.telemetry.planner_elapsed_ms:.0f}ms")
        for tid, task in state.tasks.items():
            deps = task.depends_on or ["none"]
            print(f"  {tid}: [{task.tool}] '{task.description}' | deps: {deps}")

    # ── Step 2: Build DAG ─────────────────────────────────────────────────────
    dag = DAGEngine(list(state.tasks.values()))
    dag_info = dag.summary()

    if verbose:
        print(f"\n[DAG] {dag_info['total_tasks']} tasks | "
              f"{dag_info['wave_count']} waves | "
              f"max parallelism: {dag_info['max_parallelism']}")
        print(f"[DAG] Execution waves: {dag_info['execution_waves']}")
        print(f"[DAG] Critical path:   {dag_info['critical_path']}")

    # ── Step 3: Execute waves ─────────────────────────────────────────────────
    state.telemetry.waves = dag_info["wave_count"]

    for wave_num, wave_task_ids in enumerate(dag_info["execution_waves"], 1):
        if verbose:
            print(f"\n[Wave {wave_num}] Running {len(wave_task_ids)} task(s) "
                  f"in parallel: {wave_task_ids}")

        state.wave = wave_num
        for tid in wave_task_ids:
            state.tasks[tid].status = TaskStatus.READY

        wave_start = time.perf_counter()
        workers = max_workers or len(wave_task_ids)

        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(tool_node, state, tid): tid
                for tid in wave_task_ids
            }
            for future in concurrent.futures.as_completed(futures):
                tid = futures[future]
                try:
                    future.result()
                except Exception as exc:
                    state.tasks[tid].status = TaskStatus.FAILED
                    state.tasks[tid].error  = str(exc)
                    state.errors.append(f"{tid}: {exc}")
                    logger.error("Task %s failed: %s", tid, exc)
                    if verbose:
                        print(f"  [ERROR] {tid}: {exc}")

        wave_ms = (time.perf_counter() - wave_start) * 1000
        state.telemetry.wave_elapsed_ms.append(wave_ms)

        if verbose:
            for tid in wave_task_ids:
                task = state.tasks[tid]
                print(f"  [{task.status.upper():7}] {tid} ({task.tool}) "
                      f"| tokens: {task.tokens_used} | {task.elapsed_ms:.0f}ms")
            print(f"[Wave {wave_num}] completed in {wave_ms:.0f}ms")

    # ── Step 4: Aggregate ─────────────────────────────────────────────────────
    if verbose:
        print("\n[Aggregator] Synthesising final answer...")
    state = aggregator_node(state, llm)
    if verbose:
        print(f"[Aggregator] tokens: {state.telemetry.aggregator_tokens} "
              f"| {state.telemetry.agg_elapsed_ms:.0f}ms")

    # ── Finalise telemetry ────────────────────────────────────────────────────
    state.telemetry.total_elapsed_ms = (time.perf_counter() - t_total) * 1000
    state.telemetry.total_tokens     = state.total_tokens

    done_tasks = [t for t in state.tasks.values() if t.status == TaskStatus.DONE]
    state.telemetry.tool_calls = len(done_tasks)

    if show_telemetry:
        print("\n" + state.telemetry.display())

    return state
