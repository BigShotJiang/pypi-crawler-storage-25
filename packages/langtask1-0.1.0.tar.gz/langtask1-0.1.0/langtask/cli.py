"""
langtask/cli.py
---------------
Command-line interface: `langtask "your request" [options]`

Examples:
    langtask "Analyse Q3 metrics"
    langtask "Research AI trends" --scenario research --telemetry
    langtask "Custom request" --provider openai --model gpt-4o --telemetry
    langtask "Custom request" --provider anthropic --api-key sk-ant-...
    langtask "Custom request" --provider google --model gemini-1.5-pro

Security note:
    Prefer setting env vars (OPENAI_API_KEY, ANTHROPIC_API_KEY, etc.) over
    passing --api-key on the command line to avoid keys appearing in shell history.
    langtask never stores, logs, or transmits your API key.
"""

from __future__ import annotations
import argparse
import sys

from langtask.llm_factory import make_llm, list_providers


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="langtask",
        description="LLM-powered parallel multi-task execution",
    )
    parser.add_argument(
        "request",
        nargs="?",
        default="Give me a full analytics report: total users, Q3 revenue, and churn vs benchmarks.",
        help="Natural language request to execute",
    )
    parser.add_argument(
        "--provider", "-p",
        default="mock",
        choices=list_providers(),
        help="LLM provider (default: mock). Options: " + ", ".join(list_providers()),
    )
    parser.add_argument(
        "--model", "-m",
        default=None,
        help="Model name override (e.g. gpt-4o, claude-sonnet-4-20250514, gemini-1.5-pro)",
    )
    parser.add_argument(
        "--api-key", "-k",
        default=None,
        dest="api_key",
        help=(
            "API key for the chosen provider. "
            "Prefer env vars (OPENAI_API_KEY, ANTHROPIC_API_KEY, …) to avoid "
            "keys appearing in shell history. Never stored or logged by langtask."
        ),
    )
    parser.add_argument(
        "--scenario", "-s",
        default="analytics",
        choices=["analytics", "research"],
        help="Demo scenario when using MockLLM (default: analytics)",
    )
    parser.add_argument(
        "--telemetry", "-t",
        action="store_true",
        help="Print detailed token usage and timing report",
    )
    parser.add_argument(
        "--quiet", "-q",
        action="store_true",
        help="Suppress progress logs (only print final answer)",
    )

    args = parser.parse_args(argv)

    try:
        llm = make_llm(
            provider=args.provider,
            model=args.model,
            api_key=args.api_key,   # never stored, passed straight to LangChain
            scenario=args.scenario,
        )
    except (ImportError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    from langtask.runner import build_and_run

    state = build_and_run(
        user_request   = args.request,
        llm            = llm,
        scenario       = args.scenario,
        show_telemetry = args.telemetry,
        verbose        = not args.quiet,
    )

    print(f"\n{'='*56}")
    print("FINAL RESPONSE")
    print(f"{'='*56}")
    print(state.final_response)

    # Per-task summary
    print(f"\n{'─'*56}")
    print("TASK SUMMARY")
    print(f"{'─'*56}")
    for tid, task in state.tasks.items():
        status_icon = "✓" if task.status.value == "done" else "✗"
        print(f"  {status_icon} {tid} [{task.tool:12}] "
              f"tokens: {task.tokens_used:4} | "
              f"{task.elapsed_ms:6.0f}ms | {task.status.value}")


if __name__ == "__main__":
    main()
