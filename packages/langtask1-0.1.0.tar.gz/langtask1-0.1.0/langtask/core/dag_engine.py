"""
langtask/core/dag_engine.py
---------------------------
Rust-backed DAG engine via rustworkx (PyO3).
Handles topological ordering, wave-based parallelism, and critical path.
"""

from __future__ import annotations
from typing import TYPE_CHECKING
import rustworkx as rx

if TYPE_CHECKING:
    from langtask.core.models import Task


class DAGEngine:
    """
    Wraps a rustworkx PyDiGraph.
    Edge direction: dependency → dependent  (A → C means C depends on A)
    """

    def __init__(self, tasks: list["Task"]) -> None:
        self.tasks    = {t.id: t for t in tasks}
        self.graph    = rx.PyDiGraph(check_cycle=True)
        self._index:  dict[str, int] = {}
        self._reverse: dict[int, str] = {}
        self._build()

    def _build(self) -> None:
        for task_id in self.tasks:
            idx = self.graph.add_node(task_id)
            self._index[task_id]  = idx
            self._reverse[idx]    = task_id

        for task_id, task in self.tasks.items():
            for dep_id in task.depends_on:
                try:
                    self.graph.add_edge(
                        self._index[dep_id],
                        self._index[task_id],
                        f"{dep_id}→{task_id}",
                    )
                except rx.DAGWouldCycle:
                    raise ValueError(
                        f"Cycle detected: adding edge {dep_id}→{task_id} would create a cycle"
                    )

    def topological_order(self) -> list[str]:
        indices = rx.topological_sort(self.graph)
        return [self._reverse[i] for i in indices]

    def get_execution_waves(self) -> list[list[str]]:
        """BFS level-by-level grouping for maximal parallelism."""
        in_degree: dict[int, int] = {
            idx: self.graph.in_degree(idx)
            for idx in self.graph.node_indices()
        }
        waves:   list[list[str]] = []
        visited: set[int]        = set()

        while len(visited) < len(self.graph.node_indices()):
            wave_indices = [
                idx for idx in self.graph.node_indices()
                if in_degree[idx] == 0 and idx not in visited
            ]
            if not wave_indices:
                break
            waves.append([self._reverse[i] for i in wave_indices])
            visited.update(wave_indices)
            for idx in wave_indices:
                for s_task_id in self.graph.successors(idx):
                    s_idx = self._index[s_task_id]
                    in_degree[s_idx] -= 1

        return waves

    def get_ready_tasks(self, done_ids: set[str]) -> list[str]:
        ready = []
        done_indices = {self._index[d] for d in done_ids if d in self._index}
        for task_id, task in self.tasks.items():
            if task_id in done_ids:
                continue
            dep_indices = {self._index[d] for d in task.depends_on}
            if dep_indices.issubset(done_indices):
                ready.append(task_id)
        return ready

    def critical_path(self) -> list[str]:
        path_indices = rx.dag_longest_path(self.graph)
        return [self._reverse[i] for i in path_indices]

    def ancestors(self, task_id: str) -> set[str]:
        idx      = self._index[task_id]
        anc_idxs = rx.ancestors(self.graph, idx)
        return {self._reverse[i] for i in anc_idxs}

    def descendants(self, task_id: str) -> set[str]:
        idx      = self._index[task_id]
        desc_idx = rx.descendants(self.graph, idx)
        return {self._reverse[i] for i in desc_idx}

    def summary(self) -> dict:
        waves = self.get_execution_waves()
        cp    = self.critical_path()
        return {
            "total_tasks":       len(self.tasks),
            "total_edges":       len(self.graph.edge_list()),
            "execution_waves":   waves,
            "wave_count":        len(waves),
            "critical_path":     cp,
            "critical_path_len": len(cp),
            "max_parallelism":   max(len(w) for w in waves) if waves else 0,
        }
