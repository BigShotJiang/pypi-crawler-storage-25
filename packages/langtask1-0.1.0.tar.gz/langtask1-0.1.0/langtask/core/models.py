"""
langtask/core/models.py
-----------------------
Pydantic models for tasks, planner output, and graph state.
Includes optional telemetry fields for token usage and timing.
"""

from __future__ import annotations
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field, model_validator


class TaskStatus(str, Enum):
    PENDING = "pending"
    READY   = "ready"
    RUNNING = "running"
    DONE    = "done"
    FAILED  = "failed"


class ToolName(str, Enum):
    WEB_SEARCH  = "web_search"
    CODE_EXEC   = "code_exec"
    DB_LOOKUP   = "db_lookup"
    FILE_READ   = "file_read"
    SUMMARISE   = "summarise"
    CALCULATOR  = "calculator"
    CUSTOM      = "custom"        # for user-registered tools


class Task(BaseModel):
    id:          str            = Field(..., description="Unique short ID, e.g. 't1'")
    description: str            = Field(..., description="What this task does")
    tool:        str            = Field(..., description="Tool name to invoke")
    tool_input:  dict[str, Any] = Field(default_factory=dict)
    depends_on:  list[str]      = Field(default_factory=list)

    # Runtime fields
    status:      TaskStatus     = TaskStatus.PENDING
    result:      Optional[Any]  = None
    error:       Optional[str]  = None
    tokens_used: int            = 0
    elapsed_ms:  float          = 0.0    # wall-clock time for this task
    wave:        int            = 0      # which execution wave ran this task

    @model_validator(mode="after")
    def no_self_dep(self) -> "Task":
        if self.id in self.depends_on:
            raise ValueError(f"Task {self.id} cannot depend on itself")
        return self


class PlannerOutput(BaseModel):
    tasks:          list[Task] = Field(..., min_length=1)
    execution_note: str        = ""

    @model_validator(mode="after")
    def unique_ids(self) -> "PlannerOutput":
        ids = [t.id for t in self.tasks]
        if len(ids) != len(set(ids)):
            raise ValueError("Task IDs must be unique")
        all_ids = set(ids)
        for t in self.tasks:
            for dep in t.depends_on:
                if dep not in all_ids:
                    raise ValueError(f"Task {t.id} depends on unknown id '{dep}'")
        return self


class TelemetrySummary(BaseModel):
    """Optional per-run telemetry. Populated when show_telemetry=True."""
    total_tokens:       int   = 0
    planner_tokens:     int   = 0
    aggregator_tokens:  int   = 0
    tool_tokens:        int   = 0
    total_elapsed_ms:   float = 0.0
    planner_elapsed_ms: float = 0.0
    agg_elapsed_ms:     float = 0.0
    wave_elapsed_ms:    list[float] = Field(default_factory=list)
    llm_calls:          int   = 0
    tool_calls:         int   = 0
    cache_hits:         int   = 0
    waves:              int   = 0

    def display(self) -> str:
        lines = [
            "─" * 56,
            "  TELEMETRY REPORT",
            "─" * 56,
            f"  Total time         : {self.total_elapsed_ms:>8.0f} ms",
            f"  ├─ Planner         : {self.planner_elapsed_ms:>8.0f} ms",
            f"  ├─ Tool waves      : {sum(self.wave_elapsed_ms):>8.0f} ms",
        ]
        for i, ms in enumerate(self.wave_elapsed_ms, 1):
            lines.append(f"  │   Wave {i:<3}       : {ms:>8.0f} ms")
        lines += [
            f"  └─ Aggregator      : {self.agg_elapsed_ms:>8.0f} ms",
            f"  Total tokens       : {self.total_tokens:>8,}",
            f"  ├─ Planner tokens  : {self.planner_tokens:>8,}",
            f"  ├─ Tool tokens     : {self.tool_tokens:>8,}",
            f"  └─ Aggregator toks : {self.aggregator_tokens:>8,}",
            f"  LLM calls          : {self.llm_calls:>8}",
            f"  Tool calls         : {self.tool_calls:>8}",
            f"  Cache hits         : {self.cache_hits:>8}",
            f"  Execution waves    : {self.waves:>8}",
            "─" * 56,
        ]
        return "\n".join(lines)


class GraphState(BaseModel):
    """Shared state passed through every node."""
    user_request:   str                  = ""
    tasks:          dict[str, Task]      = Field(default_factory=dict)
    wave:           int                  = 0
    total_tokens:   int                  = 0
    final_response: str                  = ""
    errors:         list[str]            = Field(default_factory=list)
    cache:          dict[str, Any]       = Field(default_factory=dict)
    telemetry:      TelemetrySummary     = Field(default_factory=TelemetrySummary)

    model_config = {"arbitrary_types_allowed": True}
