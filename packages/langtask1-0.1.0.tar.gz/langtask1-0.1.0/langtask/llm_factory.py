"""
langtask/llm_factory.py
-----------------------
Central factory for building LangChain LLM objects.

Supported providers (selector widget labels):
    mock      – MockLLM (no API key needed, for demos / tests)
    openai    – OpenAI ChatGPT models (gpt-4o, gpt-4-turbo, …)
    anthropic – Anthropic Claude models (claude-sonnet-4-20250514, …)
    google    – Google Gemini models (gemini-1.5-pro, …)
    mistral   – Mistral AI models (mistral-large-latest, …)
    ollama    – Local Ollama models (llama3, mistral, …)

Usage:
    from langtask.llm_factory import make_llm, list_providers

    llm = make_llm("openai", api_key="sk-...")
    llm = make_llm("anthropic", model="claude-3-5-sonnet-20241022")
    llm = make_llm("google")              # reads GOOGLE_API_KEY env var
    providers = list_providers()           # ["mock", "openai", "anthropic", …]

API keys are NEVER stored, logged, or written to disk.
They are passed directly to the LangChain constructor and held only for the
duration of that function call. Prefer environment variables over passing
keys explicitly so they don't appear in shell history.

Environment variables checked per provider:
    openai    → OPENAI_API_KEY
    anthropic → ANTHROPIC_API_KEY
    google    → GOOGLE_API_KEY or GEMINI_API_KEY
    mistral   → MISTRAL_API_KEY
    ollama    → (no key required)
"""

from __future__ import annotations
import os
import sys
from typing import Any


# ── Provider catalogue ────────────────────────────────────────────────────────

# Each entry: (display_label, default_model, env_vars, pip_extra)
_PROVIDERS: dict[str, tuple[str, str, list[str], str]] = {
    "mock":      ("Mock (no API key)",         "",                              [],                                   ""),
    "openai":    ("OpenAI",                    "gpt-4o",                        ["OPENAI_API_KEY"],                   "openai"),
    "anthropic": ("Anthropic Claude",          "claude-sonnet-4-20250514",      ["ANTHROPIC_API_KEY"],                "anthropic"),
    "google":    ("Google Gemini",             "gemini-1.5-pro",                ["GOOGLE_API_KEY", "GEMINI_API_KEY"], "google"),
    "mistral":   ("Mistral AI",                "mistral-large-latest",          ["MISTRAL_API_KEY"],                  "mistral"),
    "ollama":    ("Ollama (local)",            "llama3",                        [],                                   "ollama"),
}


def list_providers() -> list[str]:
    """Return ordered list of provider keys (matches CLI choices=)."""
    return list(_PROVIDERS.keys())


def provider_display_names() -> dict[str, str]:
    """Return {provider_key: display_label} for use in selector widgets."""
    return {k: v[0] for k, v in _PROVIDERS.items()}


def default_model(provider: str) -> str:
    """Return the sensible default model string for a provider."""
    return _PROVIDERS.get(provider, ("", "", [], ""))[1]


def _resolve_api_key(provider: str, explicit_key: str | None) -> str | None:
    """
    Return the API key to use, without storing it anywhere.
    Priority: explicit_key > environment variable > None.
    """
    if explicit_key:
        return explicit_key
    env_vars = _PROVIDERS.get(provider, ("", "", [], ""))[2]
    for var in env_vars:
        val = os.environ.get(var)
        if val:
            return val
    return None


# ── Factory ───────────────────────────────────────────────────────────────────

def make_llm(
    provider: str = "mock",
    *,
    model: str | None = None,
    api_key: str | None = None,
    temperature: float = 0.0,
    scenario: str = "analytics",
    **extra_kwargs: Any,
) -> Any:
    """
    Build and return a LangChain-compatible LLM object.

    Parameters
    ----------
    provider    : One of list_providers() or a pre-built LLM (pass-through).
    model       : Model name; falls back to provider default when None.
    api_key     : API key. If omitted, the relevant env var is checked.
                  Never logged or stored by langtask.
    temperature : Sampling temperature (default 0 = deterministic).
    scenario    : MockLLM scenario ("analytics" | "research") — ignored for real providers.
    **extra_kwargs : Forwarded verbatim to the LangChain constructor.

    Returns
    -------
    An object with a .invoke(messages) method.

    Raises
    ------
    ValueError  : Unknown provider string.
    ImportError : Required package not installed (message includes pip hint).
    """
    # Pass-through: caller already built an LLM object
    if not isinstance(provider, str):
        return provider

    provider = provider.lower().strip()

    if provider not in _PROVIDERS:
        raise ValueError(
            f"Unknown provider '{provider}'. "
            f"Choose from: {list_providers()}"
        )

    # ── Mock ──────────────────────────────────────────────────────────────────
    if provider == "mock":
        from langtask.mock_llm import MockLLM
        return MockLLM(scenario=scenario)

    # Resolve API key (never stored)
    resolved_key = _resolve_api_key(provider, api_key)
    _, default_mdl, env_vars, pip_extra = _PROVIDERS[provider]
    chosen_model = model or default_mdl

    # ── OpenAI ────────────────────────────────────────────────────────────────
    if provider == "openai":
        try:
            from langchain_openai import ChatOpenAI  # type: ignore
        except ImportError:
            raise ImportError(
                "OpenAI support not installed. Run: pip install langtask[openai]"
            )
        kwargs: dict[str, Any] = dict(model=chosen_model, temperature=temperature, **extra_kwargs)
        if resolved_key:
            kwargs["api_key"] = resolved_key
        return ChatOpenAI(**kwargs)

    # ── Anthropic ────────────────────────────────────────────────────────────
    if provider == "anthropic":
        try:
            from langchain_anthropic import ChatAnthropic  # type: ignore
        except ImportError:
            raise ImportError(
                "Anthropic support not installed. Run: pip install langtask[anthropic]"
            )
        kwargs = dict(model=chosen_model, temperature=temperature, **extra_kwargs)
        if resolved_key:
            kwargs["api_key"] = resolved_key
        return ChatAnthropic(**kwargs)

    # ── Google ────────────────────────────────────────────────────────────────
    if provider == "google":
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI  # type: ignore
        except ImportError:
            raise ImportError(
                "Google support not installed. Run: pip install langtask[google]"
            )
        kwargs = dict(model=chosen_model, temperature=temperature, **extra_kwargs)
        if resolved_key:
            kwargs["google_api_key"] = resolved_key
        return ChatGoogleGenerativeAI(**kwargs)

    # ── Mistral ───────────────────────────────────────────────────────────────
    if provider == "mistral":
        try:
            from langchain_mistralai import ChatMistralAI  # type: ignore
        except ImportError:
            raise ImportError(
                "Mistral support not installed. Run: pip install langtask[mistral]"
            )
        kwargs = dict(model=chosen_model, temperature=temperature, **extra_kwargs)
        if resolved_key:
            kwargs["mistral_api_key"] = resolved_key
        return ChatMistralAI(**kwargs)

    # ── Ollama ────────────────────────────────────────────────────────────────
    if provider == "ollama":
        try:
            from langchain_ollama import ChatOllama  # type: ignore
        except ImportError:
            raise ImportError(
                "Ollama support not installed. Run: pip install langtask[ollama]"
            )
        # Ollama is local — no API key needed
        return ChatOllama(model=chosen_model, **extra_kwargs)

    # Should never reach here
    raise ValueError(f"Unhandled provider '{provider}'")
