"""
langtask/token_utils.py
-----------------------
Single source of truth for all token counting in langtask.

Three public functions:
    count_text_tokens(text)          -> int
    count_messages_tokens(messages)  -> int
    extract_usage_metadata(response) -> tuple[int, int]

Uses tiktoken (cl100k_base, compatible with GPT-4 / Claude) when available.
Falls back to a len(text)//4 heuristic in offline / sandboxed environments
so the import never fails.
"""

from __future__ import annotations
from typing import Any

# ── Lazy tiktoken loader ──────────────────────────────────────────────────────

_encoder = None
_tiktoken_available: bool | None = None


def _get_encoder():
    global _encoder, _tiktoken_available
    if _tiktoken_available is not None:
        return _encoder
    try:
        import tiktoken  # type: ignore
        _encoder = tiktoken.get_encoding("cl100k_base")
        _tiktoken_available = True
    except Exception:
        _encoder = None
        _tiktoken_available = False
    return _encoder


# ── Per-message overhead (matches OpenAI's accounting spec) ──────────────────
_MSG_OVERHEAD = 4   # every message: <role>, <content>, <sep>, <end>
_REPLY_OVERHEAD = 2  # priming tokens for the assistant reply


def count_text_tokens(text: str) -> int:
    """Count tokens in a plain string."""
    enc = _get_encoder()
    if enc is not None:
        return len(enc.encode(text))
    # Heuristic fallback: ~4 chars per token
    return max(1, len(text) // 4)


def count_messages_tokens(messages: list) -> int:
    """
    Count tokens across a full LangChain message list, including per-message
    overhead so the estimate matches OpenAI's token accounting.
    """
    total = _REPLY_OVERHEAD
    for msg in messages:
        # LangChain messages expose .content; plain dicts use "content"
        content = getattr(msg, "content", None) or (
            msg.get("content", "") if isinstance(msg, dict) else ""
        )
        total += _MSG_OVERHEAD + count_text_tokens(str(content))
    return total


def extract_usage_metadata(response: Any) -> tuple[int, int]:
    """
    Extract (input_tokens, output_tokens) from any LangChain response object.

    Tries three paths in order:
      1. response.usage_metadata          (most providers)
      2. response.response_metadata.usage (some providers)
      3. Direct count of response.content (final fallback)

    Returns (input_tokens, output_tokens).
    """
    # Path 1: usage_metadata dict
    meta = getattr(response, "usage_metadata", None)
    if isinstance(meta, dict) and meta:
        return (
            int(meta.get("input_tokens", 0)),
            int(meta.get("output_tokens", 0)),
        )

    # Path 2: response_metadata nested usage
    resp_meta = getattr(response, "response_metadata", None)
    if isinstance(resp_meta, dict):
        usage = resp_meta.get("usage") or resp_meta.get("token_usage") or {}
        if isinstance(usage, dict) and usage:
            return (
                int(usage.get("prompt_tokens", usage.get("input_tokens", 0))),
                int(usage.get("completion_tokens", usage.get("output_tokens", 0))),
            )

    # Path 3: count the response content directly
    content = getattr(response, "content", "") or ""
    output_toks = count_text_tokens(str(content))
    return 0, output_toks
