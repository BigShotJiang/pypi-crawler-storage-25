"""
langtask — LLM-powered parallel task execution via DAG-based planning.

Quick start:
    from langtask import build_and_run

    # No API key — runs with MockLLM
    state = build_and_run("Analyse our Q3 metrics", show_telemetry=True)
    print(state.final_response)

    # Choose a provider via the factory (reads env vars automatically)
    from langtask import make_llm
    llm = make_llm("openai")          # reads OPENAI_API_KEY
    llm = make_llm("anthropic", api_key="sk-ant-...")
    llm = make_llm("google", model="gemini-1.5-pro")
    state = build_and_run("Research AI trends", llm=llm, show_telemetry=True)

    # With a pre-built LangChain LLM
    from langchain_openai import ChatOpenAI
    state = build_and_run("Research AI trends",
                          llm=ChatOpenAI(model="gpt-4o", temperature=0),
                          show_telemetry=True)

Custom tools:
    from langtask.tools.registry import register_tool, ToolResult

    def my_crm(inputs: dict) -> ToolResult:
        return ToolResult({"contacts": 1234}, tokens_used=0)

    register_tool("crm_lookup", my_crm)
"""

from langtask.runner              import build_and_run
from langtask.core.models         import GraphState, Task, TaskStatus, TelemetrySummary
from langtask.tools.registry      import register_tool, list_tools, ToolResult
from langtask.mock_llm            import MockLLM
from langtask.llm_factory         import make_llm, list_providers, provider_display_names, default_model
from langtask.token_utils         import count_text_tokens, count_messages_tokens

__version__ = "0.1.0"
__author__  = "LangTask Contributors"
__all__ = [
    # Core pipeline
    "build_and_run",
    # Models
    "GraphState",
    "Task",
    "TaskStatus",
    "TelemetrySummary",
    # Tools
    "register_tool",
    "list_tools",
    "ToolResult",
    # LLM factory (provider selector widget support)
    "MockLLM",
    "make_llm",
    "list_providers",
    "provider_display_names",
    "default_model",
    # Token utilities
    "count_text_tokens",
    "count_messages_tokens",
]
