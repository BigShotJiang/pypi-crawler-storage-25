"""
langtask/tools/registry.py
--------------------------
Built-in mock tools + user-extensible registry.

Users can register their own tools:
    from langtask.tools.registry import register_tool, ToolResult

    def my_tool(inputs: dict) -> ToolResult:
        return ToolResult(output={"answer": 42}, tokens_used=0)

    register_tool("my_tool", my_tool)
"""

from __future__ import annotations
import time
import random
import hashlib
import json
from typing import Any, Callable


class ToolResult:
    """Return type for all tool implementations."""
    def __init__(self, output: Any, tokens_used: int = 0, latency_ms: float = 0.0):
        self.output      = output
        self.tokens_used = tokens_used
        self.latency_ms  = latency_ms


# ── Built-in mock implementations ────────────────────────────────────────────

def _mock_web_search(inputs: dict) -> ToolResult:
    query = inputs.get("query", "")
    t0    = time.perf_counter()
    time.sleep(random.uniform(0.05, 0.15))
    result = {
        "query":   query,
        "results": [
            {"title": f"Result 1 for '{query}'", "snippet": "First relevant snippet..."},
            {"title": f"Result 2 for '{query}'", "snippet": "Second relevant snippet..."},
        ],
    }
    return ToolResult(result, tokens_used=0, latency_ms=(time.perf_counter() - t0) * 1000)


def _mock_code_exec(inputs: dict) -> ToolResult:
    code = inputs.get("code", "")
    t0   = time.perf_counter()
    time.sleep(random.uniform(0.03, 0.08))
    try:
        result = eval(compile(code, "<string>", "eval"), {"__builtins__": {}}, {})  # noqa: S307
    except Exception as e:
        result = f"ERROR: {e}"
    return ToolResult({"code": code, "output": str(result)},
                      tokens_used=0, latency_ms=(time.perf_counter() - t0) * 1000)


def _mock_db_lookup(inputs: dict) -> ToolResult:
    key = inputs.get("key", "")
    t0  = time.perf_counter()
    time.sleep(random.uniform(0.02, 0.06))
    fake_db = {
        "user_count":   42_000,
        "revenue_q3":   1_250_000,
        "active_users": 18_500,
        "churn_rate":   0.032,
    }
    value = fake_db.get(key, f"<no record for '{key}'>")
    return ToolResult({"key": key, "value": value},
                      tokens_used=0, latency_ms=(time.perf_counter() - t0) * 1000)


def _mock_file_read(inputs: dict) -> ToolResult:
    path = inputs.get("path", "")
    t0   = time.perf_counter()
    time.sleep(random.uniform(0.01, 0.04))
    return ToolResult({"path": path, "content": f"<contents of {path}>"},
                      tokens_used=0, latency_ms=(time.perf_counter() - t0) * 1000)


def _mock_summarise(inputs: dict) -> ToolResult:
    text   = inputs.get("text", "")
    t0     = time.perf_counter()
    time.sleep(random.uniform(0.05, 0.1))
    tokens = max(50, len(text.split()) // 3)
    summary = f"[Summary of {len(text.split())} words in ~{tokens} tokens]"
    return ToolResult({"summary": summary},
                      tokens_used=tokens, latency_ms=(time.perf_counter() - t0) * 1000)


def _mock_calculator(inputs: dict) -> ToolResult:
    expression = inputs.get("expression", "0")
    t0         = time.perf_counter()
    try:
        result = eval(compile(expression, "<string>", "eval"),  # noqa: S307
                      {"__builtins__": {}}, {"__import__": None})
    except Exception as e:
        result = f"ERROR: {e}"
    return ToolResult({"expression": expression, "result": str(result)},
                      tokens_used=0, latency_ms=(time.perf_counter() - t0) * 1000)


# ── Registry (mutable — users can extend) ────────────────────────────────────

TOOL_REGISTRY: dict[str, Callable[[dict], ToolResult]] = {
    "web_search": _mock_web_search,
    "code_exec":  _mock_code_exec,
    "db_lookup":  _mock_db_lookup,
    "file_read":  _mock_file_read,
    "summarise":  _mock_summarise,
    "calculator": _mock_calculator,
}


def register_tool(name: str, fn: Callable[[dict], ToolResult]) -> None:
    """Register a custom tool so the planner can use it."""
    TOOL_REGISTRY[name] = fn


def list_tools() -> list[str]:
    """Return names of all registered tools."""
    return list(TOOL_REGISTRY.keys())


def run_tool(tool_name: str, inputs: dict) -> ToolResult:
    """Execute a tool by name. Falls back to error result if unknown."""
    fn = TOOL_REGISTRY.get(tool_name)
    if fn is None:
        return ToolResult({"error": f"Unknown tool: {tool_name}"}, tokens_used=0)
    return fn(inputs)


def cache_key(tool_name: str, inputs: dict) -> str:
    """Deterministic SHA-256 cache key for deduplication."""
    payload = json.dumps({"tool": tool_name, "inputs": inputs}, sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]
