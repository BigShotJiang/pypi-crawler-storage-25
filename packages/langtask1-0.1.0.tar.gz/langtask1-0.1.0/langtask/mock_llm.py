"""
langtask/mock_llm.py
--------------------
Mock LLM for testing without an API key.
Returns realistic planner + aggregator responses using real token counting.

Replace with a real LangChain LLM via llm_factory for production use:
    from langtask.llm_factory import make_llm
    llm = make_llm("openai", api_key="sk-...")
    llm = make_llm("anthropic", model="claude-sonnet-4-20250514")
    llm = make_llm("google")
"""

from __future__ import annotations
import json
from dataclasses import dataclass, field
from typing import Any

from langtask.token_utils import count_messages_tokens, count_text_tokens


# ── Module-level scenario definitions ────────────────────────────────────────

_SCENARIOS: dict[str, dict] = {
    "analytics": {
        "tasks": [
            {"id": "t1", "description": "Fetch user count from DB",
             "tool": "db_lookup", "tool_input": {"key": "user_count"}, "depends_on": []},
            {"id": "t2", "description": "Fetch Q3 revenue from DB",
             "tool": "db_lookup", "tool_input": {"key": "revenue_q3"}, "depends_on": []},
            {"id": "t3", "description": "Fetch active users from DB",
             "tool": "db_lookup", "tool_input": {"key": "active_users"}, "depends_on": []},
            {"id": "t4", "description": "Fetch churn rate from DB",
             "tool": "db_lookup", "tool_input": {"key": "churn_rate"}, "depends_on": []},
            {"id": "t5", "description": "Calculate revenue per active user",
             "tool": "calculator", "tool_input": {"expression": "1250000 / 18500"},
             "depends_on": ["t2", "t3"]},
            {"id": "t6", "description": "Search for industry churn benchmarks",
             "tool": "web_search",
             "tool_input": {"query": "SaaS churn rate industry benchmark 2024"},
             "depends_on": []},
            {"id": "t7", "description": "Summarise all metrics for report",
             "tool": "summarise",
             "tool_input": {"text": "user_count active_users revenue churn"},
             "depends_on": ["t1", "t2", "t3", "t4", "t5", "t6"]},
        ],
        "execution_note": "t1-t4 and t6 independent; t5 needs t2+t3; t7 needs all",
    },
    "research": {
        "tasks": [
            {"id": "t1", "description": "Search recent AI papers",
             "tool": "web_search",
             "tool_input": {"query": "latest AI research papers 2024"},
             "depends_on": []},
            {"id": "t2", "description": "Search competitor products",
             "tool": "web_search",
             "tool_input": {"query": "AI assistant products 2024 comparison"},
             "depends_on": []},
            {"id": "t3", "description": "Read internal research file",
             "tool": "file_read",
             "tool_input": {"path": "/data/research/internal_notes.txt"},
             "depends_on": []},
            {"id": "t4", "description": "Summarise findings",
             "tool": "summarise",
             "tool_input": {"text": "combined research findings"},
             "depends_on": ["t1", "t2", "t3"]},
        ],
        "execution_note": "t1-t3 parallel, t4 waits for all",
    },
}

_AGGREGATOR_RESPONSES: dict[str, str] = {
    "analytics": (
        "## Analysis Summary\n\n"
        "**User metrics:** 42,000 total users, 18,500 active (44% activity rate)\n"
        "**Revenue:** $1,250,000 Q3 | Revenue per active user: $67.57\n"
        "**Churn:** 3.2% — below the 5-7% SaaS industry benchmark\n\n"
        "**Recommendation:** Churn is healthy. Focus on converting the 56% "
        "inactive users to improve revenue per user."
    ),
    "research": (
        "## Research Summary\n\n"
        "**AI landscape:** Recent papers show strong advances in multi-modal "
        "reasoning and long-context retrieval.\n"
        "**Competitors:** Three major products identified with overlapping feature sets.\n"
        "**Internal notes:** Confirm priorities align with market direction.\n\n"
        "**Recommendation:** Prioritise differentiation on latency and "
        "domain-specific fine-tuning."
    ),
}


# ── Response dataclass ────────────────────────────────────────────────────────

@dataclass
class _MockResponse:
    """Lightweight stand-in for a LangChain AIMessage."""
    content: str
    usage_metadata: dict = field(default_factory=dict)


# ── MockLLM ───────────────────────────────────────────────────────────────────

class MockLLM:
    """
    Returns deterministic planner + aggregator responses with real token counts.

    Token counts are computed from the actual messages passed in (not hardcoded),
    using tiktoken when available and a character-based heuristic as fallback.

    Useful for unit tests, CI, and quick demos without any API key.
    """

    def __init__(self, scenario: str = "analytics") -> None:
        self.call_count = 0
        self.scenario   = scenario

    def invoke(self, messages: list) -> _MockResponse:
        self.call_count += 1
        if self.call_count == 1:
            return self._planner_response(messages)
        return self._aggregator_response(messages)

    def _planner_response(self, messages: list) -> _MockResponse:
        plan    = _SCENARIOS.get(self.scenario, _SCENARIOS["analytics"])
        content = json.dumps(plan)

        # Real token counts from the actual messages and generated content
        input_tokens  = count_messages_tokens(messages)
        output_tokens = count_text_tokens(content)

        return _MockResponse(
            content=content,
            usage_metadata={
                "input_tokens":  input_tokens,
                "output_tokens": output_tokens,
            },
        )

    def _aggregator_response(self, messages: list) -> _MockResponse:
        content = _AGGREGATOR_RESPONSES.get(
            self.scenario, _AGGREGATOR_RESPONSES["analytics"]
        )

        # Real token counts from the actual messages and generated content
        input_tokens  = count_messages_tokens(messages)
        output_tokens = count_text_tokens(content)

        return _MockResponse(
            content=content,
            usage_metadata={
                "input_tokens":  input_tokens,
                "output_tokens": output_tokens,
            },
        )
