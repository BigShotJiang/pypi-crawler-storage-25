"""MCP Client — connects to external MCP servers.

Allows AgntSpace to use tools from external MCP servers
(databases, APIs, file systems, custom tools).
External tools appear in the agent's tool list alongside
built-in tools, all contract-enforced.

§9.4 review-before-connect (shipped 2026-04-24)
----------------------------------------------
Connecting to an external MCP server used to mean its tool schemas
went straight into the agent's system prompt. A malicious server can
put prompt-injection payloads in tool descriptions that the LLM acts
on, bypassing the contract gate (which checks *what tool was called*,
not *what text the attacker smuggled into the system prompt*).

Every server now carries a `trust_state` ∈ {unreviewed, review_pending,
reviewed, rejected}. `connect_server()` always fetches the tool list,
but tools from a non-`reviewed` server land in `pending_tools` — they
are NEVER handed to the agent via `get_external_tool_definitions()`
until the user approves them via `/api/mcp/servers/{name}/review/approve`.

On reconnect, if any tool's canonical schema hash differs from the
hash captured at review time, the server drops back to `review_pending`
and the user must re-review. This catches a trusted server that later
swaps its tool descriptions to something adversarial.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from contextlib import suppress
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from mcp.client.session import ClientSession
from mcp.client.stdio import StdioServerParameters, stdio_client

log = logging.getLogger(__name__)


# Trust states. The migration path grandfathers existing servers as
# "reviewed" on first boot — users who already configured a server have
# already made an implicit trust decision. Only NEW servers go through
# explicit review. Schema-change detection still catches compromise.
TRUST_UNREVIEWED = "unreviewed"      # newly added, never connected
TRUST_REVIEW_PENDING = "review_pending"  # connected, tools fetched, awaiting user review
TRUST_REVIEWED = "reviewed"          # user explicitly approved; tools visible to agent
TRUST_REJECTED = "rejected"          # user explicitly rejected; stays disconnected

_VALID_TRUST_STATES = frozenset({
    TRUST_UNREVIEWED, TRUST_REVIEW_PENDING, TRUST_REVIEWED, TRUST_REJECTED,
})

# Prompt-injection patterns scanned in tool descriptions. Shown to the user
# in the review UI as "suspicious" — NOT auto-rejected. The user decides.
# Kept deliberately conservative: false positives here annoy every legitimate
# MCP server author. Strict detection lives in §9.1 hardening, not here.
_INJECTION_PATTERNS = [  # arch:deterministic — structural pattern matcher, not strategy
    (re.compile(r"ignore\s+(all\s+)?(previous|prior|above)\s+instructions", re.I), "ignore-instructions"),
    (re.compile(r"disregard\s+(all\s+)?(previous|prior|above|system)", re.I), "disregard-previous"),
    (re.compile(r"system\s*[:\-=<>]*\s*(prompt|message|role)", re.I), "system-role-override"),
    (re.compile(r"\b(you are now|you must now|new instructions?:)", re.I), "role-hijack"),
    (re.compile(r"<\s*/?\s*(system|user|assistant|instructions?)\s*>", re.I), "fake-chat-tag"),
    (re.compile(r"\[\[?\s*(SYSTEM|OVERRIDE|ADMIN|ROOT)\s*\]?\]", re.I), "admin-marker"),
]


def _canonical_tool_hash(tool_def: dict) -> str:
    """Return a stable sha256 over the user-visible fields of a tool.

    We hash `(name, description, input_schema)` — the three things the LLM
    sees. Changes to internal `_mcp_*` bookkeeping fields do NOT trigger
    re-review. Sorting keys ensures hash stability across Python versions.
    """
    payload = {
        "name": tool_def.get("name", ""),
        "description": tool_def.get("description", ""),
        "input_schema": tool_def.get("input_schema", {}),
    }
    # sort_keys=True makes nested dict hashing deterministic
    serialized = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return "sha256:" + hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _scan_injection_patterns(text: str) -> list[str]:
    """Return the names of injection patterns that matched; [] if clean."""
    if not text:
        return []
    hits: list[str] = []
    for pattern, label in _INJECTION_PATTERNS:
        if pattern.search(text):
            hits.append(label)
    return hits


@dataclass
class ExternalMCPServer:
    """Configuration for an external MCP server."""

    name: str
    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    auto_connect: bool = True
    # §9.4 fields — added 2026-04-24. Default `unreviewed` so a NEW server
    # registered today goes through review. Migration path grandfathers
    # pre-existing entries to `reviewed` on first load.
    trust_state: str = TRUST_UNREVIEWED
    reviewed_at: str | None = None  # ISO timestamp
    reviewed_tool_hashes: dict[str, str] = field(default_factory=dict)  # tool_name -> sha256 at review time
    rejection_reason: str | None = None


class MCPClientManager:
    """Manages connections to external MCP servers."""

    def __init__(self, config_path: Path | None = None) -> None:
        self._servers: dict[str, ExternalMCPServer] = {}
        self._sessions: dict[str, ClientSession] = {}
        self._transports: dict[str, object] = {}  # keep transport refs alive
        # Tools visible to the agent — ONLY populated from reviewed servers.
        self._external_tools: dict[str, dict] = {}
        # §9.4: tools fetched but not yet approved by the user. Keyed by
        # full tool name (`mcp_{server}_{tool}`). Hidden from the agent.
        self._pending_tools: dict[str, dict] = {}
        self._config_path = config_path

    # ---- Config persistence ----

    def _save_config(self) -> None:
        """Persist server configs to JSON file."""
        if not self._config_path:
            return
        data = {
            name: {
                "command": s.command,
                "args": s.args,
                "env": s.env,
                "auto_connect": s.auto_connect,
                "trust_state": s.trust_state,
                "reviewed_at": s.reviewed_at,
                "reviewed_tool_hashes": s.reviewed_tool_hashes,
                "rejection_reason": s.rejection_reason,
            }
            for name, s in self._servers.items()
        }
        self._config_path.parent.mkdir(parents=True, exist_ok=True)
        self._config_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load_config(self) -> None:
        """Load server configs from JSON file.

        Migration behavior: legacy entries without a `trust_state` field
        are grandfathered in as `reviewed`. Users who configured a server
        before §9.4 shipped already made an implicit trust decision — we
        don't break their working setup on upgrade. The schema-change
        detector (`reviewed_tool_hashes` empty on first post-migration
        connect → captured on that connect, compared on subsequent ones)
        still protects them against a grandfathered server that later
        swaps its tool descriptions.
        """
        if not self._config_path or not self._config_path.exists():
            return
        try:
            data = json.loads(self._config_path.read_text(encoding="utf-8"))
            migrated_count = 0
            for name, cfg in data.items():
                has_trust_field = "trust_state" in cfg
                trust_state = cfg.get("trust_state", TRUST_REVIEWED)
                if trust_state not in _VALID_TRUST_STATES:
                    trust_state = TRUST_REVIEWED  # defensive fallback
                if not has_trust_field:
                    migrated_count += 1
                self._servers[name] = ExternalMCPServer(
                    name=name,
                    command=cfg["command"],
                    args=cfg.get("args", []),
                    env=cfg.get("env", {}),
                    auto_connect=cfg.get("auto_connect", True),
                    trust_state=trust_state,
                    reviewed_at=cfg.get("reviewed_at"),
                    reviewed_tool_hashes=dict(cfg.get("reviewed_tool_hashes", {})),
                    rejection_reason=cfg.get("rejection_reason"),
                )
            if migrated_count:
                # Grandfathered — persist the trust_state field so the
                # migration runs exactly once.
                log.info(
                    "MCP config: grandfathered %d legacy server(s) as 'reviewed' "
                    "(§9.4 migration). Schema-change detection still applies.",
                    migrated_count,
                )
                self._save_config()
            log.debug("Loaded %d MCP server configs", len(data))
        except Exception:
            log.warning("Failed to load MCP config", exc_info=True)

    async def auto_connect_all(self) -> None:
        """Connect to all servers marked auto_connect."""
        import os
        import sys

        for name, server in self._servers.items():
            if server.auto_connect:
                # Suppress MCP subprocess banner noise during startup
                old_stderr, old_stdout = sys.stderr, sys.stdout
                with open(os.devnull, "w") as devnull:  # noqa: SIM115
                    try:
                        sys.stderr = sys.stdout = devnull
                        await self.connect_server(name)
                    except Exception:
                        pass  # non-critical — server will work without MCP
                    finally:
                        sys.stderr, sys.stdout = old_stderr, old_stdout

    # ---- Server management ----

    def register_server(self, server: ExternalMCPServer) -> None:
        """Register an external MCP server configuration."""
        self._servers[server.name] = server
        self._save_config()
        log.info("MCP server registered: %s (%s)", server.name, server.command)

    def remove_server(self, name: str) -> bool:
        """Remove a server config (disconnects first if needed)."""
        if name not in self._servers:
            return False
        # Clean up connection if active
        if name in self._sessions:
            # Best-effort cleanup — will be fully cleaned in disconnect
            self._sessions.pop(name, None)
            self._transports.pop(name, None)
        # Remove tools from this server
        to_remove = [k for k, v in self._external_tools.items() if v.get("_mcp_server") == name]
        for k in to_remove:
            del self._external_tools[k]
        del self._servers[name]
        self._save_config()
        log.info("MCP server removed: %s", name)
        return True

    async def connect_server(self, name: str) -> list[dict]:
        """Connect to an external MCP server and discover its tools.

        §9.4 trust gate: tools fetched here only become visible to the
        agent if `server.trust_state == reviewed` AND their canonical
        hashes match `server.reviewed_tool_hashes`. Any mismatch drops
        the server back to `review_pending` and keeps the tools out of
        `_external_tools` until the user re-approves via the API.

        Returns the full tool list (whether they're visible or pending)
        so the review endpoint can render them in the UI.
        """
        server = self._servers.get(name)
        if not server:
            raise ValueError(f"Unknown MCP server: {name}")

        # Disconnect existing session if reconnecting
        if name in self._sessions:
            await self.disconnect_server(name)

        # Rejected servers stay rejected — the user already made a decision.
        # They can explicitly un-reject via `remove_server(name)` + re-register
        # if they change their mind; we don't want an auto-connect to quietly
        # reanimate a server the user said no to.
        if server.trust_state == TRUST_REJECTED:
            log.info(
                "MCP server '%s' is rejected (%s); refusing to connect.",
                name, server.rejection_reason or "no reason recorded",
            )
            raise PermissionError(
                f"MCP server '{name}' was rejected. Remove and re-register to reconnect."
            )

        # Merge env with current environment so the subprocess inherits PATH etc.
        import os

        merged_env = {**os.environ, **(server.env or {})}
        params = StdioServerParameters(
            command=server.command,
            args=server.args,
            env=merged_env,
        )

        transport = None
        session = None
        self._devnull = open(os.devnull, "w")  # noqa: SIM115
        try:
            transport = stdio_client(params, errlog=self._devnull)
            read, write = await transport.__aenter__()
            session = ClientSession(read, write)
            await session.__aenter__()
            await session.initialize()
        except Exception:
            # Clean up partial state on connection failure
            if session:
                with suppress(Exception):
                    await session.__aexit__(None, None, None)
            if transport and hasattr(transport, "__aexit__"):
                with suppress(Exception):
                    await transport.__aexit__(None, None, None)
            log.exception("MCP connection failed for '%s'", name)
            raise

        self._sessions[name] = session
        self._transports[name] = transport  # prevent GC

        # Discover tools
        try:
            tools_result = await session.list_tools()
        except Exception:
            log.exception("MCP tool discovery failed for '%s'", name)
            await self.disconnect_server(name)
            raise

        # Build tool definitions + their canonical hashes. Description gets
        # the `[{server_name}] ` prefix as before — injection patterns are
        # scanned against the RAW description (before the prefix) so the
        # prefix itself doesn't trigger a false positive.
        tools = []
        current_hashes: dict[str, str] = {}
        injection_flags: dict[str, list[str]] = {}
        for tool in tools_result.tools:
            raw_desc = tool.description or ""
            full_name = f"mcp_{name}_{tool.name}"
            tool_def = {
                "name": full_name,
                "description": f"[{name}] {raw_desc}",
                "input_schema": tool.inputSchema if hasattr(tool, "inputSchema") else {"type": "object", "properties": {}},
                "_mcp_server": name,
                "_mcp_tool": tool.name,
                "_raw_description": raw_desc,  # preserved for review UI
            }
            tools.append(tool_def)
            current_hashes[full_name] = _canonical_tool_hash(tool_def)
            flags = _scan_injection_patterns(raw_desc)
            if flags:
                injection_flags[full_name] = flags

        # Decide: are these tools allowed to be visible to the agent?
        # Rules:
        #   reviewed   + captured hashes match current       → visible (happy path)
        #   reviewed   + NO captured hashes (grandfathered)  → visible, capture baseline now
        #   reviewed   + any hash differs (schema drift)     → review_pending + hidden
        #   unreviewed                                        → review_pending + hidden
        #   review_pending                                    → stay pending + hidden
        schema_drift = False
        grandfathered_baseline = False
        if server.trust_state == TRUST_REVIEWED:
            if not server.reviewed_tool_hashes:
                # Grandfathered from pre-§9.4 config OR a fresh approval
                # that somehow didn't capture hashes. Either way, trust the
                # CURRENT view as the baseline and stamp it. Subsequent
                # reconnects will do real drift detection.
                grandfathered_baseline = True
            elif set(current_hashes.keys()) != set(server.reviewed_tool_hashes.keys()):
                schema_drift = True
            else:
                for tn, h in current_hashes.items():
                    if server.reviewed_tool_hashes.get(tn) != h:
                        schema_drift = True
                        break

        # Clear any previously-cached tools from this server so a reconnect
        # doesn't leave stale entries around.
        self._external_tools = {
            k: v for k, v in self._external_tools.items() if v.get("_mcp_server") != name
        }
        self._pending_tools = {
            k: v for k, v in self._pending_tools.items() if v.get("_mcp_server") != name
        }

        if server.trust_state == TRUST_REVIEWED and not schema_drift:
            # Happy path: server was reviewed, nothing changed. Tools visible.
            for tool_def in tools:
                self._external_tools[tool_def["name"]] = {
                    **tool_def,
                    "_injection_flags": injection_flags.get(tool_def["name"], []),
                }
            # Capture the baseline on first connect after grandfathering so
            # subsequent reconnects do proper drift detection. No-op if we
            # already had hashes (the equality check above would have passed).
            if grandfathered_baseline:
                server.reviewed_tool_hashes = dict(current_hashes)
                self._save_config()
                log.info(
                    "MCP server '%s': captured baseline tool hashes (%d tools) "
                    "for grandfathered config; drift detection armed.",
                    name, len(current_hashes),
                )
            log.debug(
                "Connected to reviewed MCP server '%s': %d tools visible",
                name, len(tools),
            )
        else:
            # Park tools under pending. Reason stamped for the review UI.
            if server.trust_state == TRUST_REVIEWED and schema_drift:
                reason = "schema_drift"
                # Downgrade state so the UI shows this as pending review.
                server.trust_state = TRUST_REVIEW_PENDING
                self._save_config()
                log.warning(
                    "MCP server '%s': tool schemas changed since last review; "
                    "tools quarantined until re-review.", name,
                )
            elif server.trust_state == TRUST_UNREVIEWED:
                reason = "first_connect"
                server.trust_state = TRUST_REVIEW_PENDING
                self._save_config()
            else:
                reason = "awaiting_review"

            for tool_def in tools:
                self._pending_tools[tool_def["name"]] = {
                    **tool_def,
                    "_pending_reason": reason,
                    "_current_hash": current_hashes[tool_def["name"]],
                    "_injection_flags": injection_flags.get(tool_def["name"], []),
                }
            log.info(
                "MCP server '%s' awaiting review (%s): %d tools pending; "
                "will be hidden from agent until approved.",
                name, reason, len(tools),
            )

        return tools

    async def disconnect_server(self, name: str) -> bool:
        """Disconnect a single MCP server."""
        session = self._sessions.pop(name, None)
        transport = self._transports.pop(name, None)
        if session:
            try:
                await session.__aexit__(None, None, None)
            except Exception:
                pass
        if transport and hasattr(transport, "__aexit__"):
            try:
                await transport.__aexit__(None, None, None)
            except Exception:
                pass
        # Remove tools from this server from BOTH tables
        to_remove = [k for k, v in self._external_tools.items() if v.get("_mcp_server") == name]
        for k in to_remove:
            del self._external_tools[k]
        to_remove_pending = [k for k, v in self._pending_tools.items() if v.get("_mcp_server") == name]
        for k in to_remove_pending:
            del self._pending_tools[k]
        log.debug("Disconnected MCP server: %s", name)
        return True

    async def call_tool(self, tool_name: str, arguments: dict) -> dict:
        """Call a tool on an external MCP server.

        Defense-in-depth check: `_external_tools` should already only contain
        reviewed-server tools, but we also verify the server's `trust_state`
        is `reviewed` at call time. A race (tool listed, then user rejected
        the server before the LLM's tool_call arrived) is impossible in
        practice but caught here anyway.
        """
        tool_def = self._external_tools.get(tool_name)
        if not tool_def:
            # Might be pending — give a more helpful error
            if tool_name in self._pending_tools:
                return {"error": (
                    f"MCP tool '{tool_name}' is pending user review and cannot be called. "
                    "Approve the server in Settings → MCP Servers before use."
                )}
            return {"error": f"Unknown MCP tool: {tool_name}"}

        server_name = tool_def["_mcp_server"]
        real_tool_name = tool_def["_mcp_tool"]
        session = self._sessions.get(server_name)

        # §9.4 runtime re-check: server must still be `reviewed`
        server = self._servers.get(server_name)
        if not server or server.trust_state != TRUST_REVIEWED:
            return {"error": (
                f"MCP server '{server_name}' is not approved for tool calls "
                f"(trust_state={server.trust_state if server else 'missing'})."
            )}

        if not session:
            return {"error": f"MCP server '{server_name}' not connected"}

        try:
            result = await session.call_tool(real_tool_name, arguments)
            text_parts = []
            for content in result.content:
                if hasattr(content, "text"):
                    text_parts.append(content.text)
            return {"result": "\n".join(text_parts)}
        except Exception as e:
            return {"error": str(e)}

    def get_external_tool_definitions(self) -> list[dict]:
        """Get all external tool definitions for the agent.

        Only returns tools from `reviewed` servers — pending tools are
        structurally prevented from reaching the LLM's tool list. This is
        the single load-bearing filter for §9.4; `call_tool` adds a runtime
        check as defense-in-depth.
        """
        return list(self._external_tools.values())

    def list_servers(self) -> list[dict]:
        """List registered MCP servers and their connection status."""
        return [
            {
                "name": name,
                "command": server.command,
                "args": server.args,
                "connected": name in self._sessions,
                "auto_connect": server.auto_connect,
                "trust_state": server.trust_state,
                "reviewed_at": server.reviewed_at,
                "rejection_reason": server.rejection_reason,
                "tools": len([
                    t for t in self._external_tools.values()
                    if t.get("_mcp_server") == name
                ]),
                "pending_tools": len([
                    t for t in self._pending_tools.values()
                    if t.get("_mcp_server") == name
                ]),
            }
            for name, server in self._servers.items()
        ]

    # ---- §9.4 review flow helpers ----

    def get_pending_review(self, name: str) -> dict:
        """Return pending tools for a server so the UI can render the review.

        Pure read — never mutates state. Returns the server's metadata plus
        every pending tool with its description, input_schema, current hash,
        and any detected injection-pattern flags.
        """
        server = self._servers.get(name)
        if not server:
            raise ValueError(f"Unknown MCP server: {name}")
        pending = [
            {
                "name": t["name"],
                "short_name": t.get("_mcp_tool", ""),
                "description": t.get("_raw_description", t.get("description", "")),
                "input_schema": t.get("input_schema", {}),
                "current_hash": t.get("_current_hash", ""),
                "previous_hash": server.reviewed_tool_hashes.get(t["name"], ""),
                "changed": (
                    server.reviewed_tool_hashes.get(t["name"], "") != t.get("_current_hash", "")
                    if server.reviewed_tool_hashes else False
                ),
                "injection_flags": t.get("_injection_flags", []),
            }
            for t in self._pending_tools.values()
            if t.get("_mcp_server") == name
        ]
        return {
            "name": name,
            "trust_state": server.trust_state,
            "reviewed_at": server.reviewed_at,
            "reason": pending[0].get("_pending_reason", "") if pending else "",
            "tools": pending,
            "connected": name in self._sessions,
            "was_previously_reviewed": bool(server.reviewed_tool_hashes),
        }

    def approve_server(self, name: str) -> dict:
        """Mark a server as reviewed: promote pending tools to live, stamp hashes.

        No LLM/network side effects. Pure state mutation + config save.
        The caller (API route) is responsible for contract authorization and
        activity-log emission.
        """
        server = self._servers.get(name)
        if not server:
            raise ValueError(f"Unknown MCP server: {name}")
        pending = [t for t in self._pending_tools.values() if t.get("_mcp_server") == name]
        if not pending:
            # Nothing to approve — might happen if the server was reconnected
            # and hashes all matched (no pending created). Treat as no-op.
            return {"approved": 0, "trust_state": server.trust_state}

        server.trust_state = TRUST_REVIEWED
        server.reviewed_at = datetime.now(UTC).isoformat()
        server.rejection_reason = None
        new_hashes: dict[str, str] = {}
        for t in pending:
            new_hashes[t["name"]] = t.get("_current_hash", _canonical_tool_hash(t))
        server.reviewed_tool_hashes = new_hashes

        # Promote pending → live. Strip the review-only bookkeeping keys.
        approved_names = []
        for t in pending:
            live = {k: v for k, v in t.items() if not k.startswith("_pending")}
            live.pop("_current_hash", None)
            self._external_tools[t["name"]] = live
            approved_names.append(t["name"])
        # Clear pending for this server
        self._pending_tools = {
            k: v for k, v in self._pending_tools.items() if v.get("_mcp_server") != name
        }
        self._save_config()
        log.info("MCP server '%s' approved: %d tools now visible to agent.", name, len(approved_names))
        return {
            "approved": len(approved_names),
            "tool_names": approved_names,
            "trust_state": server.trust_state,
            "reviewed_at": server.reviewed_at,
        }

    async def reject_server(self, name: str, reason: str = "") -> dict:
        """Mark a server as rejected + disconnect it + clear pending tools.

        Async because it calls `disconnect_server`. The server stays
        registered (so the user can see WHY they rejected it in the list)
        but will refuse to connect until they `remove_server` it.
        """
        server = self._servers.get(name)
        if not server:
            raise ValueError(f"Unknown MCP server: {name}")
        server.trust_state = TRUST_REJECTED
        server.rejection_reason = reason.strip()[:500] if reason else "rejected by user"
        server.auto_connect = False  # don't reconnect on startup
        server.reviewed_tool_hashes = {}
        self._save_config()
        await self.disconnect_server(name)
        log.info("MCP server '%s' rejected: %s", name, server.rejection_reason)
        return {
            "rejected": True,
            "trust_state": server.trust_state,
            "rejection_reason": server.rejection_reason,
        }

    async def disconnect_all(self) -> None:
        """Disconnect from all MCP servers."""
        for name in list(self._sessions.keys()):
            await self.disconnect_server(name)
