"""File-type registry — one handler per file type, uniform output.

This is the frontier-shape contract that the whole ingest pipeline will
route through (decisions.md §2026-04-18, revised). Three concerns compose
per type:

    1. **Classify** — extensions, MIME types, magic-byte prefix, size cap,
       prompt_focus, default_source_type. Resolved from a FileTypeSpec.
    2. **Extract** — the registered extractor callable. Returns an
       ExtractResult carrying element-typed content (not just text),
       document-level metadata, embedded media refs, and provenance.
    3. **Render** — canvas_content_type + canvas_preview + ui_icon for
       downstream display. Consumed by Canvas and wiki surfaces.

The element-typed ExtractResult is load-bearing: downstream consumers (KB
compile, synthesize, graph population, canvas, multi-modal retrieval) will
add richer behaviour per element kind over time. Shipping text-only first
and "upgrading later" would require rewriting every consumer — doing it
right once is cheaper.

**Phase 1 goals (this commit)**:
- Define the dataclasses + registry shape.
- Port the 7 existing handlers as bundled registry entries (some emit a
  single Paragraph element — richness added per type in Phase 2+).
- Wire `_classify_source` + the three scattered extraction branches in
  `kb/service.py` through the registry.
- Emit provenance triples so later re-extraction decisions are queryable.

**Not in scope (later phases)**:
- Multi-extractor ladders per type (Phase 4).
- Multi-modal join with vision on embedded images (Phase 5).
- Canvas renderer registry + inverse rendering (Phase 6).
"""

from __future__ import annotations

import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

log = logging.getLogger(__name__)


# ── Element taxonomy ────────────────────────────────────────────────────

ElementKind = Literal[
    "title",           # Document title, single per doc by convention
    "heading",         # Section heading at any level (depth in attrs)
    "paragraph",       # Default narrative text element
    "table",           # Tabular data — rows/cols preserved in attrs
    "list_item",       # Single list entry (ordered or unordered)
    "code",            # Code block — language in attrs
    "equation",        # LaTeX / MathML expression
    "image",           # Embedded image reference (path in attrs)
    "captioned_media", # Audio/video segment with timestamp + caption
]


@dataclass
class Element:
    """One structural piece of an extracted document.

    Text-only extractors emit a single `paragraph` element containing the
    whole document body. Richer extractors (PDF with layout, DOCX, EPUB)
    emit multiple elements preserving structure.

    Attributes are open-ended per kind so extractors can carry format-specific
    hints without us pre-declaring every possible field. Stable keys by kind:

    - `heading`: `{depth: 1-6}`
    - `table`:   `{rows: list[list[str]], headers: list[str] | None}`
    - `list_item`: `{depth: int, ordered: bool, marker: str | None}`
    - `code`:    `{language: str | None}`
    - `image`:   `{path: str, alt: str | None, caption: str | None}`
    - `captioned_media`: `{start_ms: int, end_ms: int, kind: "audio" | "video"}`

    All elements may carry:
    - `page: int | None` — source page number (PDF, EPUB)
    - `bbox: tuple[int,int,int,int] | None` — bounding box on the page
    - `parent_id: str | None` — id of enclosing element (nesting)
    - `element_id: str | None` — stable id for cross-references
    """

    kind: ElementKind
    text: str
    attrs: dict[str, Any] = field(default_factory=dict)
    page: int | None = None
    bbox: tuple[int, int, int, int] | None = None
    parent_id: str | None = None
    element_id: str | None = None


# ── Media references (embedded assets) ──────────────────────────────────

@dataclass
class MediaRef:
    """Pointer to a binary asset referenced by a document.

    Kept separate from Elements because media are extracted separately
    (copied to disk or resolved to URLs) and may be processed by different
    pipelines (vision, transcription). Each MediaRef usually corresponds
    to an Image or CaptionedMedia element in the elements list.
    """

    path: str               # vault-relative path or remote URL
    kind: Literal["image", "audio", "video"]
    mime: str | None = None
    size_bytes: int | None = None
    element_id: str | None = None  # back-ref to owning element


# ── Extraction result (the frontier contract) ───────────────────────────

@dataclass
class ExtractResult:
    """What every extractor returns.

    Downstream (kb/service.py, compile, canvas, graph) may read either:
    - `.as_text()` — concatenated text for legacy LLM prompting
    - `.elements` — structured content for richer consumers

    Provenance is captured at extract time so re-ingest decisions can be
    made later ("this was extracted with pdfplumber@0.10 before tables
    worked — worth re-ingesting now that we have unstructured_hi_res").
    """

    elements: list[Element]
    doc_metadata: dict[str, Any] = field(default_factory=dict)
    media: list[MediaRef] = field(default_factory=list)
    provenance: dict[str, Any] = field(default_factory=dict)

    def as_text(self, joiner: str = "\n\n") -> str:
        """Concatenate element text for legacy string-based consumers."""
        return joiner.join(e.text for e in self.elements if e.text)

    @property
    def is_empty(self) -> bool:
        return not any(e.text.strip() for e in self.elements)


# ── File type spec (one per supported format) ──────────────────────────

@dataclass
class FileTypeSpec:
    """Declares how one file type is classified, extracted, and rendered.

    Initial registry entries are built programmatically (Phase 1). Phase 2
    migrates these to YAML at `defaults/skills/file-types/{name}/config/file-type.yaml`
    discovered through SkillLoader.
    """

    # Identity
    type_name: str
    display_name: str

    # — Classify layer —
    extensions: tuple[str, ...]                 # ".pdf", ".docx" — lowercased
    mime_types: tuple[str, ...] = ()            # optional MIME matches
    magic_prefix: bytes | None = None           # content-sniffing fallback
    default_source_type: str = "article"        # inherits kb-ingest taxonomy
    prompt_focus: str = "Extract main points, key facts, and context."
    max_bytes: int = 10 * 1024 * 1024           # per-type size cap (watcher consults this)
    requires_binary: bool = False               # True = don't read as utf-8

    # — Extract layer —
    extractor: str = "text_utf8"                # id into FileTypeRegistry._extractors
    extractor_options: dict[str, Any] = field(default_factory=dict)
    chunking_strategy: Literal["fixed", "structural", "semantic"] = "fixed"
    transcribe: bool = False                    # audio/video → whisper
    vision_capable: bool = False                # images → multimodal LLM

    # — Render layer (informs Canvas + wiki) —
    canvas_content_type: str = "markdown"
    canvas_preview: Literal["inline", "thumbnail", "link-only"] = "inline"
    ui_icon: str = "FileText"                   # lucide icon name
    thumbnail_generator: str | None = None


# ── Extractor callable contract ─────────────────────────────────────────

# Extractors receive (path, spec, context) and return an ExtractResult.
# `context` carries runtime deps the extractor may need (llm provider for
# vision/transcribe, vault paths for sibling-image resolution, options).
ExtractorContext = dict[str, Any]
Extractor = Callable[[Path, FileTypeSpec, ExtractorContext], Awaitable[ExtractResult]]


class FileTypeError(Exception):
    """Raised when a file type can't be resolved or extracted."""


# ── The registry ────────────────────────────────────────────────────────

class FileTypeRegistry:
    """Single source of truth for file-type classification + extraction.

    Populated at startup from bundled defaults (Phase 1) and — later —
    from skill YAMLs and plugin hooks.

    The registry is *inert* when initialized — no extractor is imported
    until its type is actually requested. This keeps boot fast and lets
    us ship formats with heavy deps (python-docx, ebooklib, whisper)
    without bloating the install for users who don't need them.
    """

    def __init__(self) -> None:
        self._specs: dict[str, FileTypeSpec] = {}
        self._by_ext: dict[str, str] = {}        # ".pdf" → type_name
        self._by_mime: dict[str, str] = {}       # mime → type_name
        self._by_magic: list[tuple[bytes, str]] = []  # (prefix, type_name) ordered
        self._extractors: dict[str, Extractor] = {}

    # ── Registration ────────────────────────────────────────────────

    def register_type(self, spec: FileTypeSpec, *, overwrite: bool = False) -> None:
        """Add a FileTypeSpec. Raises if type_name already registered unless
        `overwrite=True` (plugins opting into override semantics).
        """
        if spec.type_name in self._specs and not overwrite:
            raise FileTypeError(
                f"file type '{spec.type_name}' already registered "
                f"(set overwrite=True to replace)"
            )
        self._specs[spec.type_name] = spec
        for ext in spec.extensions:
            ext_lc = ext.lower()
            prior = self._by_ext.get(ext_lc)
            if prior and prior != spec.type_name and not overwrite:
                log.warning(
                    "file-type extension collision: '%s' claimed by both '%s' and '%s' "
                    "(keeping '%s' — first wins; plugins must pass overwrite=True)",
                    ext_lc, prior, spec.type_name, prior,
                )
                continue
            self._by_ext[ext_lc] = spec.type_name
        for mime in spec.mime_types:
            self._by_mime[mime.lower()] = spec.type_name
        if spec.magic_prefix:
            self._by_magic.append((spec.magic_prefix, spec.type_name))
        log.debug("FileTypeRegistry: registered '%s' (exts=%s)",
                  spec.type_name, list(spec.extensions))

    def register_extractor(self, extractor_id: str, fn: Extractor) -> None:
        """Attach an extractor callable by id. Multiple types may share an
        extractor (e.g. generic `text_utf8` serving md + txt + rst).
        """
        self._extractors[extractor_id] = fn

    # ── Resolution ─────────────────────────────────────────────────

    def resolve_type(self, path: Path, mime: str | None = None) -> FileTypeSpec | None:
        """Find the spec for a file. Order: extension → MIME → magic bytes.

        Returns None when the file's type is unknown — caller decides
        whether to park it in `library/unsupported/` or fall through to
        a default text-handler (see kb/service.py's watcher logic).
        """
        ext = path.suffix.lower()
        if ext and ext in self._by_ext:
            return self._specs[self._by_ext[ext]]
        if mime:
            type_name = self._by_mime.get(mime.lower())
            if type_name:
                return self._specs[type_name]
        if self._by_magic:
            try:
                with path.open("rb") as f:
                    head = f.read(16)
                for prefix, type_name in self._by_magic:
                    if head.startswith(prefix):
                        return self._specs[type_name]
            except OSError:
                pass
        return None

    def get_spec(self, type_name: str) -> FileTypeSpec | None:
        return self._specs.get(type_name)

    def all_types(self) -> list[FileTypeSpec]:
        return list(self._specs.values())

    def all_extensions(self) -> frozenset[str]:
        return frozenset(self._by_ext.keys())

    # ── Extraction ─────────────────────────────────────────────────

    async def extract(
        self,
        path: Path,
        spec: FileTypeSpec,
        context: ExtractorContext | None = None,
    ) -> ExtractResult:
        """Run the registered extractor for a spec.

        Enriches the returned ExtractResult's `provenance` dict with:
        - `extractor_id`: which callable ran
        - `extractor_version`: version of the handler (for re-ingest decisions)
        - `duration_ms`: wall-clock time to extract
        - `type_name`: which type this file matched

        Never raises on extractor error — returns an ExtractResult with
        `provenance["error"]` set and an empty elements list. The caller
        (kb/service.py) decides whether to fail the ingest or continue.
        """
        fn = self._extractors.get(spec.extractor)
        if not fn:
            raise FileTypeError(
                f"no extractor registered: '{spec.extractor}' "
                f"(type={spec.type_name}, file={path.name})"
            )

        started = time.perf_counter()
        ctx: ExtractorContext = dict(context or {})
        try:
            result = await fn(path, spec, ctx)
        except Exception as exc:
            duration_ms = int((time.perf_counter() - started) * 1000)
            log.warning(
                "FileTypeRegistry: extractor '%s' raised on %s: %s",
                spec.extractor, path.name, exc,
            )
            return ExtractResult(
                elements=[],
                doc_metadata={},
                media=[],
                provenance={
                    "extractor_id": spec.extractor,
                    "extractor_version": _extractor_version(spec.extractor),
                    "duration_ms": duration_ms,
                    "type_name": spec.type_name,
                    "error": f"{type(exc).__name__}: {exc}",
                },
            )

        # Merge provenance — caller's values take precedence over defaults
        # so extractors can stamp their own `extractor_version` etc.
        duration_ms = int((time.perf_counter() - started) * 1000)
        prov: dict[str, Any] = {
            "extractor_id": spec.extractor,
            "extractor_version": _extractor_version(spec.extractor),
            "duration_ms": duration_ms,
            "type_name": spec.type_name,
        }
        prov.update(result.provenance or {})
        result.provenance = prov
        return result


# ── Version tracking for provenance ─────────────────────────────────────

# Per-extractor version strings — bumped when the extractor's behaviour
# changes in a way that warrants re-ingesting older content. Format:
#   "<name>@<semver-ish>"
# Consulted by `registry.extract()` and stamped on the ExtractResult so
# later re-ingest decisions ("is this content extracted with the current
# best handler?") become queryable against the graph.
_EXTRACTOR_VERSIONS: dict[str, str] = {  # arch:deterministic — extractor-version registry, not user-tunable strategy
    "text_utf8":       "text_utf8@1.0.0",
    # 1.1.0 — emits Heading / Table / Paragraph elements via font-size
    # clustering + extract_tables(). Degrades to 1.0.0 per-page paragraphs
    # when char/font data is unavailable. Downstream consumers comparing
    # provenance can trigger a re-ingest when older content is below 1.1.0.
    "pdf_pdfplumber":  "pdf_pdfplumber@1.1.0",
    "vision_llm":      "vision_llm@1.0.0",
    "csv_tabular":     "csv_tabular@1.0.0",
    "json_pretty":     "json_pretty@1.0.0",
    "vtt_srt":         "vtt_srt@1.0.0",
    "html_parser":     "html_parser@1.0.0",
    # Phase 3 — new formats, element-aware from day one.
    "docx_python_docx":    "docx_python_docx@1.0.0",
    "epub_ebooklib":       "epub_ebooklib@1.0.0",
    "audio_whisper":       "audio_whisper@1.0.0",
    "video_ffmpeg_vision": "video_ffmpeg_vision@1.0.0",
}


def _extractor_version(extractor_id: str) -> str:
    return _EXTRACTOR_VERSIONS.get(extractor_id, f"{extractor_id}@unknown")


def register_extractor_version(extractor_id: str, version: str) -> None:
    """Plugins / Phase 3+ extractors register their version here so
    provenance triples carry the right lineage."""
    _EXTRACTOR_VERSIONS[extractor_id] = f"{extractor_id}@{version}"
