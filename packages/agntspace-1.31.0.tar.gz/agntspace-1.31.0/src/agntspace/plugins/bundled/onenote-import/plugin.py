"""OneNote Import plugin — Windows COM-based importer.

Uses the OneNote desktop app (via pywin32 COM) to read notebooks / sections /
pages directly from the local cache — no Azure app registration, no OAuth.
Writes markdown + original XML into ``<vault>/<target_folder>/...`` where
the existing inbox watcher picks them up for KB ingest.

Registers:
    - tool:  ``onenote_import``
    - routes: ``GET /api/plugins/onenote-import/status``,
              ``POST /api/plugins/onenote-import/run``

See README.md for requirements, flow, and parameters.
"""

from __future__ import annotations

import asyncio
import sys
from typing import TYPE_CHECKING, Any

from agntspace.plugins.base import PluginBase, PluginContext

from .importer import OneNoteImporter
from .jobs import JobRegistry
from .router import make_router

if TYPE_CHECKING:
    from fastapi import APIRouter


class OneNoteImportPlugin(PluginBase):
    def __init__(self) -> None:
        self._ctx: PluginContext | None = None
        self._lock: asyncio.Lock | None = None
        self._router: APIRouter | None = None
        # One registry per plugin instance, shared between HTTP routes and
        # the agent tool handler — so /progress works regardless of which
        # path started the import.
        self._jobs = JobRegistry()

    def init(self, ctx: PluginContext) -> None:
        self._ctx = ctx
        ctx.log.debug("onenote-import plugin initializing")

        if sys.platform != "win32":
            ctx.log.info(
                "onenote-import: non-Windows platform (%s) — the plugin loads "
                "but imports will fail. Use on Windows with OneNote desktop installed.",
                sys.platform,
            )

        ctx.registry.register_tool(
            name="onenote_import",
            description=(
                "Import Microsoft OneNote notebooks into the vault as markdown. "
                "Windows-only — uses the OneNote desktop app via COM; no Azure "
                "or OAuth setup. Writes to <vault>/<target_folder>/<notebook>/"
                "<section>/<page>.md with original .xml preserved alongside and "
                "inline images saved under .images/ (dot-prefixed so the "
                "inbox watcher skips them). The inbox watcher will "
                "auto-ingest the new markdown. Use when the user asks to "
                "'import OneNote', 'sync my OneNote notebooks', or 'pull "
                "notebooks into the vault'."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "target_folder": {
                        "type": "string",
                        "default": "OneNote",
                        "description": "Vault subfolder for imports.",
                    },
                    "notebooks": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": (
                            "Optional: notebook display names to restrict to. "
                            "Omit to import all accessible notebooks."
                        ),
                    },
                    "incremental": {
                        "type": "boolean",
                        "default": True,
                        "description": (
                            "Skip pages unchanged since last import. Set false "
                            "to force a full re-import."
                        ),
                    },
                },
                "required": [],
            },
            handler=self._sync_handler,
            async_handler=self._async_handler,
            contract_action="write_vault",
            category="onenote",
            namespace="integrations",
        )

        self._router = make_router(ctx, self._jobs)
        ctx.log.info("onenote-import plugin ready")

    async def async_init(self, ctx: PluginContext) -> None:
        # One lock per plugin instance — prevents two concurrent imports from
        # racing on the same state file. Created here so it binds to the
        # running event loop (asyncio.Lock binds eagerly on some Python
        # versions).
        self._lock = asyncio.Lock()

    def get_router(self) -> APIRouter | None:
        return self._router

    def shutdown(self) -> None:
        # Nothing to release — COM connections are acquired per-run.
        pass

    # ── tool handlers ────────────────────────────────────────────────

    async def _async_handler(self, inp: dict) -> dict:
        """Agent-invoked path. Runs the import with a per-plugin lock."""
        if self._ctx is None:
            return {"error": "plugin not initialized"}
        if sys.platform != "win32":
            return {
                "error": (
                    f"OneNote COM is Windows-only (this is {sys.platform}). "
                    "Run on a Windows machine with OneNote desktop installed."
                ),
            }

        target = str(inp.get("target_folder") or "OneNote").strip() or "OneNote"
        notebooks_raw = inp.get("notebooks")
        notebooks = [str(n) for n in notebooks_raw] if isinstance(notebooks_raw, list) else None
        incremental = bool(inp.get("incremental", True))

        # Register the job so /progress works while the agent waits for
        # completion. Agent-invoked runs are blocking from the LLM's POV
        # (the tool returns the summary), but the UI side can still poll.
        job = await self._jobs.create(
            target_folder=target,
            notebooks_filter=notebooks,
            incremental=incremental,
        )

        importer = OneNoteImporter(
            # root_dir is the user's chosen vault root (sibling of the
            # agntspace-* dirs), NOT root_dir/agntspace/ which is
            # ``settings.vault_dir`` (agent internals). We want OneNote
            # sitting next to agntspace-inbox, agntspace-journal, etc.
            # so the inbox watcher picks it up naturally.
            vault_dir=self._ctx.settings.root_dir,
            target_folder=target,
            notebooks_filter=notebooks,
            incremental=incremental,
            activity_logger=self._ctx.activity_logger,
            decisions=self._ctx.decisions,
            job_state=job,
        )

        lock = self._lock
        if lock is None:
            # async_init didn't run (or crashed) — fall back to no lock.
            summary = await importer.run()
        else:
            async with lock:
                summary = await importer.run()

        # Include the job_id in the tool response so the LLM can mention
        # "(you can also poll /api/plugins/onenote-import/progress/<id>)"
        # if a user asks for progress on a repeat run.
        result = summary.to_dict()
        result["job_id"] = job.job_id
        return result

    def _sync_handler(self, inp: dict) -> dict:
        """Sync fallback — required by some tool-dispatch paths.

        The agent's normal tool path uses ``async_handler`` directly (see
        ``agent.py``'s ``_dispatch_tool``), but the registry requires a
        ``handler`` too. This wraps the async version for those paths.
        """
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # In an async context, launching another loop explodes.
                # The async_handler path should be preferred; if we hit this,
                # surface an explicit error rather than hanging.
                return {
                    "error": (
                        "Sync dispatch of onenote_import from a running loop "
                        "is not supported. The dispatcher should prefer "
                        "async_handler for this tool."
                    ),
                }
        except RuntimeError:
            # No event loop on this thread — create one.
            loop = asyncio.new_event_loop()
            try:
                return loop.run_until_complete(self._async_handler(inp))
            finally:
                loop.close()
        return loop.run_until_complete(self._async_handler(inp))


plugin = OneNoteImportPlugin()
