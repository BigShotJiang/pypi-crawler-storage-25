"""OneNote COM client — wraps the OneNote desktop app's Automation interface.

Uses pywin32 to dispatch ``OneNote.Application`` and walk the notebook /
section / page hierarchy, then fetch per-page XML (with inline image binary
data) directly from the local cache. No OAuth, no Azure, no internet.

Windows-only. On other platforms, importing pywin32 fails at module load
(guarded so the plugin still discovers on macOS/Linux, it just can't run).

OneNote XML lives in the namespace
``http://schemas.microsoft.com/office/onenote/2013/onenote`` — every element
name is prefixed ``one:`` in XPath but bare in element.tag parsing.
"""

from __future__ import annotations

import logging
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)

_ONE_NS = "http://schemas.microsoft.com/office/onenote/2013/onenote"
_NS = {"one": _ONE_NS}

# Hierarchy scope constants from the OneNote COM type library.
# The desktop app's IApplication::GetHierarchy takes an integer enum; these
# numeric values are the canonical ones MS ships in the IDL and have not
# changed across OneNote 2013/2016/365. We hardcode them rather than pull
# them from the generated makepy cache because makepy isn't always available
# and the values are stable.
HS_SELF = 0
HS_CHILDREN = 1
HS_NOTEBOOKS = 2
HS_SECTIONS = 3
HS_PAGES = 4

# PageInfo enum for GetPageContent.
PI_BASIC = 0
PI_BINARY_DATA = 1
PI_ALL = 2
PI_SELECTION = 3
PI_BINARY_DATA_SELECTION = 4


class OneNoteCOMError(Exception):
    """Raised when COM dispatch to OneNote fails or returns unexpected state."""


@dataclass
class PageRef:
    notebook: str
    notebook_id: str
    section_path: list[str]  # ["Section Group", "Section Name"] — empty list if top-level section
    section_id: str
    page_name: str
    page_id: str
    last_modified: str = ""  # ISO 8601 from OneNote, empty if absent


@dataclass
class Hierarchy:
    notebooks: list[dict] = field(default_factory=list)
    pages: list[PageRef] = field(default_factory=list)


class OneNoteCOMClient:
    """Thin wrapper around OneNote.Application COM dispatch.

    Lifecycle:
        client = OneNoteCOMClient()
        client.connect()           # raises OneNoteCOMError if OneNote missing
        pages = client.list_pages()
        xml = client.get_page_xml(page.page_id)
        client.close()

    All COM calls run in the calling thread. If you use this from an async
    context, wrap calls in ``asyncio.to_thread`` so you don't block the event
    loop (COM calls can block for several seconds, especially first-dispatch
    which may launch OneNote.exe).
    """

    def __init__(self) -> None:
        self._app: Any = None
        self._initialized = False
        # True when EnsureDispatch (early binding) succeeded. Late-bound
        # Dispatch requires us to pass placeholder strings for [out] params
        # in some method calls — the helpers below branch on this flag.
        self._early_bound = False

    def connect(self) -> None:
        """Dispatch OneNote.Application. Launches OneNote.exe if not running.

        Prefers ``gencache.EnsureDispatch`` (early binding via the type
        library) so [out] BSTR parameters are mapped to function return
        values per the IDL — late-binding ``Dispatch`` requires the caller
        to pass placeholder strings for [out] params, which is brittle and
        position-dependent. Falls back to plain ``Dispatch`` if EnsureDispatch
        can't write the makepy cache (e.g. read-only Python install).
        """
        if sys.platform != "win32":
            raise OneNoteCOMError(
                "OneNote COM is Windows-only. This platform is "
                f"{sys.platform!r}."
            )
        try:
            import pythoncom  # type: ignore
            import win32com.client  # type: ignore
            import win32com.client.gencache  # type: ignore
        except ImportError as exc:
            raise OneNoteCOMError(
                "pywin32 is not installed. Run: pip install 'agntspace[onenote]'"
            ) from exc

        try:
            pythoncom.CoInitialize()
            self._initialized = True
        except Exception:
            # Already initialized on this thread — not fatal.
            pass

        # Try early binding first.
        try:
            self._app = win32com.client.gencache.EnsureDispatch("OneNote.Application")
            self._early_bound = True
            return
        except Exception as exc:
            log.debug(
                "EnsureDispatch failed (%s) — falling back to late binding", exc,
            )

        try:
            self._app = win32com.client.Dispatch("OneNote.Application")
            self._early_bound = False
        except Exception as exc:
            raise OneNoteCOMError(
                "Could not dispatch OneNote.Application. Is the OneNote desktop "
                "app installed? (The Store / 'OneNote for Windows 10' UWP "
                "version does NOT expose COM — you need OneNote 2016 / OneNote "
                f"Desktop.) Underlying error: {_format_com_error(exc)}"
            ) from exc

    def close(self) -> None:
        self._app = None
        if self._initialized:
            try:
                import pythoncom  # type: ignore

                pythoncom.CoUninitialize()
            except Exception:
                pass
            self._initialized = False

    def __enter__(self) -> OneNoteCOMClient:
        self.connect()
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        self.close()

    # ── hierarchy ────────────────────────────────────────────────────

    def _get_hierarchy_xml(self, start_node: str = "", scope: int = HS_PAGES) -> str:
        if self._app is None:
            raise OneNoteCOMError("Not connected. Call connect() first.")
        # OneNote IDL:
        #   GetHierarchy([in] BSTR start, [in] HierarchyScope scope, [out] BSTR xml)
        # The [out] BSTR is the LAST parameter. Under early binding (gencache),
        # pywin32 maps it to the function return value, so we call with 2 args.
        # Under late binding, the call still works with 2 args because the IDL
        # marks the out param with [retval] — pywin32's IDispatch::Invoke
        # surfaces it as the result either way.
        try:
            xml = self._app.GetHierarchy(start_node, scope)
        except Exception as exc:
            raise OneNoteCOMError(
                f"GetHierarchy failed: {_format_com_error(exc)}"
            ) from exc
        if not xml or not isinstance(xml, str):
            raise OneNoteCOMError(f"GetHierarchy returned unexpected value: {xml!r}")
        return xml

    def list_pages(self, *, notebooks_filter: list[str] | None = None) -> list[PageRef]:
        """Return one PageRef per page in every accessible notebook.

        ``notebooks_filter`` — if non-None, restricts to notebooks whose
        displayName appears in this list (case-insensitive match).

        Password-protected sections are skipped with a debug log — the
        hierarchy call returns them with an ``isPasswordProtected`` attribute
        and we can't read pages under them without user unlock.
        """
        xml = self._get_hierarchy_xml(scope=HS_PAGES)
        return parse_hierarchy(xml, notebooks_filter=notebooks_filter)

    # ── page content ─────────────────────────────────────────────────

    def get_page_xml(self, page_id: str, *, with_binary: bool = True) -> str:
        """Return the page's OneNote XML, optionally with inline image binaries.

        OneNote IDL:
            GetPageContent([in] BSTR id, [out] BSTR xml,
                           [in, default(piBasic)] PageInfo info,
                           [in, default(xs2013)] XMLSchema xs)
        The [out] BSTR is in the MIDDLE — position 2 — so under late binding
        we MUST pass a placeholder for it (otherwise the [in] info argument
        slips into the out slot and OneNote either returns the placeholder
        verbatim or rejects the call). Under early binding the type library
        knows the slot is [out] and the placeholder isn't needed.
        """
        if self._app is None:
            raise OneNoteCOMError("Not connected. Call connect() first.")
        info = PI_BINARY_DATA if with_binary else PI_BASIC
        try:
            if self._early_bound:
                xml = self._app.GetPageContent(page_id, info)
            else:
                xml = self._app.GetPageContent(page_id, "", info)
        except Exception as exc:
            raise OneNoteCOMError(
                f"GetPageContent failed for page {page_id}: {_format_com_error(exc)}"
            ) from exc
        if not xml or not isinstance(xml, str):
            raise OneNoteCOMError(
                f"GetPageContent returned unexpected value: {xml!r}"
            )
        return xml


# ── pure parsers (unit-testable without COM) ─────────────────────────


def parse_hierarchy(
    xml: str,
    *,
    notebooks_filter: list[str] | None = None,
) -> list[PageRef]:
    """Parse the hierarchy XML returned by GetHierarchy into flat PageRef list.

    Pure function — no COM. Testable with fixture XML.

    Handles SectionGroups by recursively walking into them and accumulating
    path segments so nested sections land at ``section_path=["Group", "Sub"]``.
    """
    filter_lower = {n.strip().lower() for n in notebooks_filter} if notebooks_filter else None
    root = ET.fromstring(xml)
    # Root may be <one:Notebooks> (the common case from GetHierarchy on the
    # root node) or a single <one:Notebook> if OneNote wraps differently.
    # Handle both.
    notebooks: list[ET.Element]
    if _localname(root) == "Notebooks":
        notebooks = list(root.findall("one:Notebook", _NS))
    elif _localname(root) == "Notebook":
        notebooks = [root]
    else:
        notebooks = list(root.findall(".//one:Notebook", _NS))

    pages: list[PageRef] = []
    for nb in notebooks:
        nb_name = nb.get("name") or "Untitled Notebook"
        nb_id = nb.get("ID") or ""
        if filter_lower and nb_name.strip().lower() not in filter_lower:
            continue
        _walk_sections(nb, nb_name, nb_id, section_path=[], pages=pages)
    return pages


def _walk_sections(
    parent: ET.Element,
    nb_name: str,
    nb_id: str,
    *,
    section_path: list[str],
    pages: list[PageRef],
) -> None:
    """Recursively walk Section + SectionGroup children of a notebook / group."""
    for section in parent.findall("one:Section", _NS):
        if _bool_attr(section, "isPasswordProtected"):
            log.debug(
                "Skipping password-protected section: %s/%s",
                nb_name,
                section.get("name"),
            )
            continue
        if _bool_attr(section, "isInRecycleBin"):
            continue
        sec_name = section.get("name") or "Untitled Section"
        sec_id = section.get("ID") or ""
        for page in section.findall("one:Page", _NS):
            if _bool_attr(page, "isInRecycleBin"):
                continue
            pages.append(
                PageRef(
                    notebook=nb_name,
                    notebook_id=nb_id,
                    section_path=[*section_path, sec_name],
                    section_id=sec_id,
                    page_name=page.get("name") or "Untitled Page",
                    page_id=page.get("ID") or "",
                    last_modified=page.get("lastModifiedTime") or "",
                )
            )

    for group in parent.findall("one:SectionGroup", _NS):
        if _bool_attr(group, "isInRecycleBin"):
            continue
        if _bool_attr(group, "isRecycleBin"):
            continue
        group_name = group.get("name") or "Untitled Group"
        _walk_sections(
            group,
            nb_name,
            nb_id,
            section_path=[*section_path, group_name],
            pages=pages,
        )


def _localname(elem: ET.Element) -> str:
    """Return the local (unprefixed) name of an Element's tag."""
    tag = elem.tag
    if "}" in tag:
        return tag.split("}", 1)[1]
    return tag


def _bool_attr(elem: ET.Element, name: str) -> bool:
    val = elem.get(name)
    return bool(val) and val.strip().lower() == "true"


def _format_com_error(exc: BaseException) -> str:
    """Render a pywin32 com_error with the actually-useful detail.

    ``pywintypes.com_error`` stringifies as something like
    ``"(-2147352567, 'Exception occurred.', None, None)"`` — the ``excepinfo``
    tuple inside is where the human-readable message lives. This helper
    extracts ``excepinfo[2]`` (the description) and ``excepinfo[5]`` (HRESULT)
    so callers see WHY the call failed instead of an opaque method name.
    """
    # Try the rich pywintypes format first.
    excepinfo = getattr(exc, "excepinfo", None)
    if isinstance(excepinfo, tuple) and len(excepinfo) >= 6:
        # excepinfo: (wCode, source, description, helpFile, helpContext, scode)
        source = excepinfo[1] or ""
        desc = excepinfo[2] or ""
        scode = excepinfo[5]
        parts: list[str] = []
        if desc.strip():
            parts.append(desc.strip())
        if source.strip() and source.strip() not in desc:
            parts.append(f"source={source.strip()}")
        if scode is not None:
            parts.append(f"hresult=0x{scode & 0xFFFFFFFF:08X}")
        if parts:
            return "; ".join(parts)
    # args[0] sometimes carries an HRESULT int; args[1] the description.
    args = getattr(exc, "args", ())
    if isinstance(args, tuple) and len(args) >= 2 and isinstance(args[1], str):
        return args[1]
    text = str(exc)
    return text or type(exc).__name__
