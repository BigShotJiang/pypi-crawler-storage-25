from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING
from warnings import warn

import pytz

import robocop.linter.reports
from robocop import exceptions

if TYPE_CHECKING:
    from robocop.config.schema import Config


class TimestampReport(robocop.linter.reports.Report):
    """
    **Report name**: ``timestamp``

    Report that returns Robocop execution timestamp.
    Timestamp follows local time in the format of
    ``Year-Month-Day Hours(24-hour clock):Minutes:Seconds ±hh:mm UTC offset`` as default.

    Example:
        Reported: 2022-07-10 21:25:00 +0300

    You can configure a timezone and timestamp format with ``timezone`` and ``format`` parameters:

        robocop check -c timestamp.timezone="Europe/Paris" -c timestamp.format="%Y-%m-%d %H:%M:%S %Z %z"

    This yields the following timestamp report::

         Reported: 2022-07-10 20:38:10 CEST +0200

    For timezone names, see https://en.wikipedia.org/wiki/List_of_tz_database_time_zones .

    For timestamp formats, see https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes .

    Useful configurations:

        Local time to ISO 8601 format:
        robocop check --configure timestamp.format="%Y-%m-%dT%H:%M:%S%z"

        UTC time:
        robocop check --configure timestamp.timezone="UTC" --configure timestamp.format="%Y-%m-%dT%H:%M:%S %Z %z"

        Timestamp with high precision:
        robocop check --configure timestamp.format="%Y-%m-%dT%H:%M:%S.%f %z"

        12-hour clock:
        robocop check --configure timestamp.format="%Y-%m-%d %I:%M:%S %p %Z %z"

        More human-readable format 'On 10 July 2022 07:26:24 +0300':
        robocop check --configure timestamp.format="On %d %B %Y %H:%M:%S %z"

    """

    def __init__(self, config: Config) -> None:
        self.name = "timestamp"
        self.description = "Returns Robocop execution timestamp."
        self.timezone = "local"
        self.format = "%Y-%m-%d %H:%M:%S %z"
        super().__init__(config)

    def configure(self, name: str, value: str) -> None:
        if name == "timezone":
            self.timezone = value
        elif name == "format":
            if value:
                self.format = value
            else:
                warn("Empty format string for `timestamp` report does not make sense. Default format used.")
        else:
            super().configure(name, value)

    def generate_report(self, **kwargs: object) -> None:  # noqa: ARG002
        if self.config.silent:
            return
        print(f"\nReported: {self._get_timestamp()}")

    def _get_timestamp(self) -> str:
        try:
            if self.timezone == "local":
                timezone_code = datetime.now(timezone.utc).astimezone().tzinfo
            else:
                timezone_code = pytz.timezone(self.timezone)
            return datetime.now(timezone_code).strftime(self.format)
        except pytz.exceptions.UnknownTimeZoneError:
            raise exceptions.ConfigurationError(
                f"Provided timezone '{self.timezone}' for report '{self.name}' is not valid. "
                "Use timezone names like `Europe\\Helsinki`."
                "See: https://en.wikipedia.org/wiki/List_of_tz_database_time_zone"
            ) from None
