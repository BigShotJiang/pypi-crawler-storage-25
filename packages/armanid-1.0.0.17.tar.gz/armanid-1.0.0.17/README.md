<div align="center">

<br>

<!-- Wordmark -->
<h1>Armanid</h1>

<p><em>Awesome Real-time Machine Analysis for Next-gen Intelligent Detection</em></p>

<br>

<!-- Badges — Apple palette: #1D1D1F, #0071E3, #6E6E73 -->
<a href="https://pypi.org/project/armanid"><img alt="PyPI" src="https://img.shields.io/pypi/v/armanid?style=flat-square&logo=pypi&logoColor=white&labelColor=1D1D1F&color=1D1D1F"></a>&nbsp;
<a href="https://pypi.org/project/armanid"><img alt="Python" src="https://img.shields.io/badge/Python-3.8%2B-0071E3?style=flat-square&labelColor=1D1D1F&color=0071E3"></a>&nbsp;
<a href="https://pypi.org/project/armanid"><img alt="PyTorch" src="https://img.shields.io/badge/PyTorch-2.0%2B-0071E3?style=flat-square&labelColor=1D1D1F&color=0071E3"></a>&nbsp;
<a href="https://www.gnu.org/licenses/agpl-3.0"><img alt="License" src="https://img.shields.io/badge/License-AGPL%203.0-6E6E73?style=flat-square&labelColor=1D1D1F&color=6E6E73"></a>

<br><br>

<!-- CTA row -->
<a href="https://armanid.ai/signup"><img alt="Start Free Trial" src="https://img.shields.io/badge/-Start%20Free%20Trial-0071E3?style=flat-square&logoColor=white"></a>&nbsp;&nbsp;
<a href="https://armanid.ai/demo"><img alt="Book a Demo" src="https://img.shields.io/badge/-Book%20a%20Demo-1D1D1F?style=flat-square&logoColor=white"></a>&nbsp;&nbsp;
<a href="https://docs.armanid.ai"><img alt="Documentation" src="https://img.shields.io/badge/-Documentation-6E6E73?style=flat-square&logoColor=white"></a>&nbsp;&nbsp;
<a href="https://www.linkedin.com/in/arman-guriyan-ceo-of-epicrabbit-6b37213a5/"><img alt="LinkedIn" src="https://img.shields.io/badge/-LinkedIn-0071E3?style=flat-square&logo=linkedin&logoColor=white"></a>

<br><br>

</div>

---

## Overview

Armanid is a production-grade object detection engine designed for enterprises that demand accuracy, speed, and reliability — from edge devices to cloud-scale deployments.

Built by **Epic Rabbit**, Armanid delivers **99.7% mAP** on the COCO dataset, real-time inference at **120 FPS**, and a developer-first Python API that gets you from install to first inference in under five minutes.

---

## Installation

```bash
# Standard install
pip install armanid

# With GPU acceleration (NVIDIA CUDA)
pip install armanid[cuda]

# Enterprise production suite
pip install armanid[enterprise]

# Full development environment
pip install armanid[dev]
```

---

## Quick Start

```python
from armanid import Armanid

# Initialize detector
model = Armanid("armanid-medium")

# Run on an image
results = model.detect("image.jpg", conf=0.85)

# Inspect results
for box in results[0].boxes:
    print(box.label, box.conf, box.xyxy)

# Save annotated output
results[0].save("output.jpg")
```

---

## Model Family

Five precision tiers — from ultra-fast edge deployment to maximum-accuracy research workloads.

| Model | Size | Speed | mAP | Use Case |
|---|---|---|---|---|
| `armanid-nano` | ~6 MB | 120 FPS | 85% | Mobile / Edge |
| `armanid-small` | ~22 MB | 80 FPS | 92% | Real-time |
| `armanid-medium` | ~50 MB | 45 FPS | 95% | General |
| `armanid-large` | ~84 MB | 25 FPS | 97% | High-quality |
| `armanid-xlarge` | ~131 MB | 15 FPS | 98% | Research |

Specialised variants also available: `armanid-nano-seg` (segmentation) and `armanid-nano-pose` (pose estimation).

---

## API Reference

### Detection

```python
from armanid import Armanid

model = Armanid("armanid-large")

# Image detection
results = model.detect("image.jpg", conf=0.25)

# Filter by class — 0: person, 2: car, 5: bus
results = model.detect(
    source="rtsp://your-camera",
    conf=0.85,
    iou=0.65,
    classes=[0, 2, 5]
)

# Result accessors
result = results[0]
result.boxes          # List of BoundingBox objects
result.labels         # ["person", "car", ...]
result.confidences    # [0.92, 0.87, ...]
result.summary()      # {"person": 2, "car": 1}
result.show()         # Display annotated image
result.save("out.jpg")
result.plot()         # Returns annotated numpy array
```

### Bounding Box Fields

```python
box = result.boxes[0]

box.label      # "person"
box.conf       # 0.92
box.xyxy       # (x1, y1, x2, y2)
box.xywh       # (cx, cy, w, h)
box.width
box.height
box.area
box.track_id   # Available when tracking
```

### Object Tracking

```python
from armanid import Armanid

model = Armanid("armanid-large")

# Stream video with persistent tracking
for result in model.track("video.mp4", stream=True):
    for box in result.boxes:
        print(box.track_id, box.label, box.conf)

# Live webcam with FPS overlay
from armanid.utils import run_webcam
run_webcam(model, conf=0.8, show_fps=True)
```

### Custom Training

```python
from armanid import Armanid

# Load base model
model = Armanid("armanid-large.yaml")

# Fine-tune on custom dataset
model.train(
    data="custom-dataset.yaml",
    epochs=100,
    batch_size=16,
    optimizer="adamw"
)

# Export for production
model.export(format="onnx")
```

### Enterprise Deployment

```bash
# Docker
docker run -p 8080:8080 armanid/enterprise:latest

# Kubernetes
kubectl apply -f armanid-deployment.yaml

# REST API
curl -X POST "http://localhost:8080/detect" \
     -H "Content-Type: application/json" \
     -d '{"image": "base64_encoded_image"}'
```

---

## Performance

<div align="center">

**Speed (FPS)**

| | |
|---|---|
| `armanid-nano` | 120 FPS |
| `armanid-small` | 80 FPS |
| `armanid-medium` | 45 FPS |
| `armanid-large` | 25 FPS |
| `armanid-xlarge` | 15 FPS |

**Accuracy (mAP on COCO)**

| | |
|---|---|
| `armanid-nano` | 85% |
| `armanid-small` | 92% |
| `armanid-medium` | 95% |
| `armanid-large` | 97% |
| `armanid-xlarge` | 98% |

</div>

---

## System Requirements

**Minimum**

| Requirement | Value |
|---|---|
| Python | 3.8+ |
| RAM | 4 GB |
| Storage | 500 MB |
| OS | Windows 10+, Ubuntu 18.04+, macOS 10.15+ |

**Recommended (Enterprise)**

| Requirement | Value |
|---|---|
| Python | 3.10+ |
| RAM | 16 GB+ |
| GPU | NVIDIA RTX 30-series or newer |
| Storage | 50 GB SSD |
| OS | Ubuntu 20.04 LTS |

---

## Industries

Armanid is deployed in production across six sectors where precision and uptime are non-negotiable.

- **Manufacturing** — Quality control and defect detection. Reduces inspection time by up to 85%.
- **Automotive** — ADAS and autonomous driving perception pipelines.
- **Healthcare** — Medical imaging analysis compatible with DICOM workflows.
- **Security** — Multi-camera surveillance and real-time threat detection.
- **Retail** — Inventory management, shelf analytics, and customer flow tracking.
- **Construction** — PPE compliance, safety monitoring, and project progress tracking.

---

## Support

| Channel | Link |
|---|---|
| Documentation | [docs.armanid.ai](https://docs.armanid.ai) |
| Community | [discord.armanid.ai](https://discord.armanid.ai) |
| Enterprise Email | enterprise@armanid.ai |
| Tutorials | [YouTube Channel](https://youtube.com/armanid) |

Enterprise plans include a dedicated success manager, 24/7 technical support, custom model training, performance optimization, and SLA guarantees.

---

## About

<div align="center">

Built by **[Epic Rabbit](https://epicrabbit.com)** — creators of next-generation AI solutions.

**Arman Guriyan** — Founder & CEO &nbsp;|&nbsp; [LinkedIn](https://www.linkedin.com/in/arman-guriyan-ceo-of-epicrabbit-6b37213a5/) &nbsp;|&nbsp; arman@epicrabbit.com

<br>

Licensed under the **GNU Affero General Public License v3.0 (AGPL-3.0)**.  
Copyright &copy; 2025 Arman Guriyan — Epic Rabbit.

</div>
