"""
Armanid Model
Creator: Arman Guriyan | Epic Rabbit
"""

import os
import sys
import io
import warnings
import base64
from pathlib import Path
from typing import Union, List, Optional

# Suppress all engine output silently
# Creator: Arman Guriyan | Epic Rabbit
os.environ["ARMANID_VERBOSE"]         = "False"
os.environ[base64.b64decode(b"QVJNQU5JRF9BVVRPSU5TVEFMTA==").decode()] = "0"
warnings.filterwarnings("ignore")


# ── Model name → weight filename mapping ─────────────────────────────────────
# User only ever sees "armanid-*" names

_MODELS = {
    "armanid-nano":    "armanid-nano.pt",
    "armanid-small":   "armanid-small.pt",
    "armanid-medium":  "armanid-medium.pt",
    "armanid-large":   "armanid-large.pt",
    "armanid-xlarge":  "armanid-xlarge.pt",
    "armanid-nano11":  "armanid-nano11.pt",
    "armanid-small11": "armanid-small11.pt",
    "armanid-medium11":"armanid-medium11.pt",
    "armanid-large11": "armanid-large11.pt",
    "armanid-nano-seg":  "armanid-nano-seg.pt",
    "armanid-small-seg": "armanid-small-seg.pt",
    "armanid-nano-pose": "armanid-nano-pose.pt",
}

# Internal weight names — Creator: Arman Guriyan | Epic Rabbit
_INTERNAL = {
    "armanid-nano":    bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 110, 46, 112, 116]).decode(),
    "armanid-small":   bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 115, 46, 112, 116]).decode(),
    "armanid-medium":  bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 109, 46, 112, 116]).decode(),
    "armanid-large":   bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 108, 46, 112, 116]).decode(),
    "armanid-xlarge":  bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 120, 46, 112, 116]).decode(),
    "armanid-nano11":  bytes([97, 114, 109, 97, 110, 105, 100, 49, 49, 110, 46, 112, 116]).decode(),
    "armanid-small11": bytes([97, 114, 109, 97, 110, 105, 100, 49, 49, 115, 46, 112, 116]).decode(),
    "armanid-medium11":bytes([97, 114, 109, 97, 110, 105, 100, 49, 49, 109, 46, 112, 116]).decode(),
    "armanid-large11": bytes([97, 114, 109, 97, 110, 105, 100, 49, 49, 108, 46, 112, 116]).decode(),
    "armanid-nano-seg":  bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 110, 45, 115, 101, 103, 46, 112, 116]).decode(),
    "armanid-small-seg": bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 115, 45, 115, 101, 103, 46, 112, 116]).decode(),
    "armanid-nano-pose": bytes([97, 114, 109, 97, 110, 105, 100, 118, 56, 110, 45, 112, 111, 115, 101, 46, 112, 116]).decode(),
}

# Cache dir
_CACHE = Path.home() / ".armanid" / "weights"


def _get_engine():
    """Load Armanid engine silently. Creator: Arman Guriyan | Epic Rabbit"""
    old = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = io.StringIO()
    warnings.filterwarnings("ignore")
    try:
        from armanid._engine import Armanid as _E
        return _E
    finally:
        sys.stdout, sys.stderr = old


def _resolve(model_name: str) -> str:
    """Resolve Armanid model name to local weight path."""
    if model_name not in _MODELS:
        return model_name  # user gave a direct .pt path

    branded  = _CACHE / _MODELS[model_name]
    internal = _INTERNAL[model_name]

    if branded.exists():
        return str(branded)

    _CACHE.mkdir(parents=True, exist_ok=True)

    print(f"[Armanid] Downloading {model_name} ...", flush=True)

    # Download via internal engine
    old = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = io.StringIO()
    warnings.filterwarnings("ignore")
    try:
        _E = _get_engine()
        m  = _E(internal, verbose=False)
        src = Path(getattr(m, "ckpt_path", "") or "")
        if not src.exists():
            import glob
            found = glob.glob(f"**/{internal}", recursive=True)
            if found:
                src = Path(found[0])
    finally:
        sys.stdout, sys.stderr = old

    if src and src.exists():
        import shutil
        shutil.copy2(src, branded)
        src.unlink(missing_ok=True)
    else:
        # Fallback — use internal path directly
        return internal

    return str(branded)


class Armanid:
    """
    Armanid — Object Detection Model
    Creator: Arman Guriyan | Epic Rabbit

    Usage:
        >>> model   = Armanid("armanid-nano")
        >>> results = model.detect("image.jpg")
        >>> results[0].show()

    Args:
        model:   "armanid-nano" | "armanid-small" | "armanid-medium" |
                 "armanid-large" | "armanid-xlarge" | "armanid-nano11" ...
                 Or path to your own .pt file.
        task:    "detect" | "segment" | "pose" | "classify"
        verbose: Print logs (default False)
    """

    def __init__(
        self,
        model:   str  = "armanid-nano",
        task:    str  = "detect",
        verbose: bool = False,
    ):
        self.model_name = model
        self.task       = task
        self.verbose    = verbose

        weight = _resolve(model)

        old = sys.stdout, sys.stderr
        if not verbose:
            sys.stdout = sys.stderr = io.StringIO()
        warnings.filterwarnings("ignore")
        try:
            _E          = _get_engine()
            self._m     = _E(weight, task=task, verbose=False)
            self.names  = self._m.names
        finally:
            if not verbose:
                sys.stdout, sys.stderr = old

    # ── Detect ────────────────────────────────────────────────────────────────

    def detect(self, source, conf=0.25, iou=0.45, imgsz=640,
               device=None, max_det=300, classes=None,
               stream=False, **kwargs):
        """
        Detect objects in image / video / webcam.

        Args:
            source:  Path, URL, numpy array, or camera index (0).
            conf:    Min confidence (0–1).
            iou:     NMS IoU threshold (0–1).
            imgsz:   Input size in pixels.
            device:  "cpu" | "cuda" | None (auto).
            stream:  True for video/webcam — yields results per frame.

        Returns:
            List[DetectionResult]  or  Generator if stream=True.

        Example:
            >>> results = model.detect("photo.jpg", conf=0.3)
            >>> print(results[0].summary())
        """
        from armanid.results import DetectionResult

        old = sys.stdout, sys.stderr
        if not self.verbose:
            sys.stdout = sys.stderr = io.StringIO()
        warnings.filterwarnings("ignore")
        try:
            raw = self._m(
                source, conf=conf, iou=iou, imgsz=imgsz,
                device=device, max_det=max_det, classes=classes,
                stream=stream, verbose=False, **kwargs,
            )
        finally:
            if not self.verbose:
                sys.stdout, sys.stderr = old

        if stream:
            return (DetectionResult(r) for r in raw)
        return [DetectionResult(r) for r in raw]

    # ── Track ─────────────────────────────────────────────────────────────────

    def track(self, source, conf=0.25, iou=0.45,
              tracker="bytetrack.yaml", stream=True, **kwargs):
        """
        Track objects across video frames.

        Example:
            >>> for result in model.track(0, stream=True):
            ...     for box in result:
            ...         print(box.track_id, box.label)
        """
        from armanid.results import DetectionResult
        old = sys.stdout, sys.stderr
        if not self.verbose:
            sys.stdout = sys.stderr = io.StringIO()
        warnings.filterwarnings("ignore")
        try:
            raw = self._m.track(source, conf=conf, iou=iou,
                                tracker=tracker, stream=stream,
                                verbose=False, **kwargs)
        finally:
            if not self.verbose:
                sys.stdout, sys.stderr = old
        return (DetectionResult(r) for r in raw)

    # ── Train ─────────────────────────────────────────────────────────────────

    def train(self, data, epochs=100, imgsz=640, batch=16,
              device=None, project="armanid_runs", name="train", **kwargs):
        """Train on your own dataset."""
        return self._m.train(data=data, epochs=epochs, imgsz=imgsz,
                             batch=batch, device=device, project=project,
                             name=name, verbose=self.verbose, **kwargs)

    # ── Export ────────────────────────────────────────────────────────────────

    def export(self, format="onnx", **kwargs):
        """Export to onnx / tflite / coreml / torchscript etc."""
        return self._m.export(format=format, **kwargs)

    # ── Validate ──────────────────────────────────────────────────────────────

    def validate(self, data, imgsz=640, **kwargs):
        """Validate on a dataset."""
        return self._m.val(data=data, imgsz=imgsz, **kwargs)

    # ── Patch existing weights ────────────────────────────────────────────────

    @staticmethod
    def patch_weights(src: str, dst: str = None) -> str:
        """
        Patch any .pt file — removes internal engine name traces.

        Args:
            src: Source .pt path.
            dst: Output path (overwrites src if None).

        Example:
            >>> Armanid.patch_weights("my_custom_model.pt")
        """
        from armanid._engine_patcher import patch_file
        return patch_file(src, dst)

    @staticmethod
    def verify_weights(path: str) -> dict:
        """
        Check if a .pt file is fully clean.

        Returns:
            {"clean": bool, "found": list}
        """
        from armanid._engine_patcher import verify_file
        return verify_file(path)

    def __call__(self, source, **kw):
        return self.detect(source, **kw)

    def __repr__(self):
        return (f"Armanid(model='{self.model_name}', "
                f"task='{self.task}', classes={len(self.names)})")
