"""
Armanid Utilities - Drawing, saving, and helper functions.
"""

from __future__ import annotations
from typing import List, Optional, Tuple, Union
from pathlib import Path
import time
import numpy as np


# ── Color palette (BGR) ───────────────────────────────────────────────────────
_PALETTE = [
    (255,  56,  56), (255, 157,  151), (255, 112,  31), (255, 178,  29),
    ( 207, 210,  49), ( 72, 249,  10), ( 146, 204,  23), ( 61, 219, 134),
    ( 26, 147,  52), (  0, 212, 187), ( 44, 153, 168), (  0,  194, 255),
    ( 52,  69, 147), (100,  115, 255), (  0,  24, 236), (132,  56, 255),
    ( 82,   0, 133), (203,  56, 255), (255, 149, 200), (255,  55, 199),
]


def _color_for(cls_id: int) -> Tuple[int, int, int]:
    return _PALETTE[cls_id % len(_PALETTE)]


# ── Drawing ───────────────────────────────────────────────────────────────────

def draw_detections(
    image: np.ndarray,
    result: "DetectionResult",
    line_width: int = 2,
    font_scale: float = 0.6,
    show_conf: bool = True,
) -> np.ndarray:
    """
    Draw bounding boxes and labels on *image* from an Armanid DetectionResult.

    Parameters
    ----------
    image : np.ndarray
        BGR image array (will NOT be modified in-place — a copy is returned).
    result : DetectionResult
        Output of Armanid.detect().
    line_width : int
        Box border thickness in pixels.
    font_scale : float
        Label text size multiplier.
    show_conf : bool
        Append confidence score to label.

    Returns
    -------
    np.ndarray  Annotated BGR image copy.
    """
    try:
        import cv2
    except ImportError:
        raise ImportError("[Armanid] draw_detections requires opencv-python. pip install opencv-python")

    img = image.copy()

    for box in result.boxes:
        color = _color_for(box.cls_id)
        x1, y1, x2, y2 = int(box.x1), int(box.y1), int(box.x2), int(box.y2)

        # Draw rectangle
        cv2.rectangle(img, (x1, y1), (x2, y2), color, line_width)

        # Build label text
        label_text = f"{box.label}"
        if box.track_id is not None:
            label_text += f" #{box.track_id}"
        if show_conf:
            label_text += f" {box.conf:.2f}"

        # Label background
        (tw, th), baseline = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, 1)
        top = max(y1 - th - baseline - 4, 0)
        cv2.rectangle(img, (x1, top), (x1 + tw + 4, y1), color, -1)

        # Label text
        cv2.putText(
            img, label_text,
            (x1 + 2, y1 - baseline - 2),
            cv2.FONT_HERSHEY_SIMPLEX, font_scale,
            (255, 255, 255), 1, cv2.LINE_AA,
        )

    return img


# ── Saving ────────────────────────────────────────────────────────────────────

def save_detections(
    result: "DetectionResult",
    output_path: Union[str, Path],
    draw: bool = True,
) -> Path:
    """
    Save a DetectionResult to disk.

    Parameters
    ----------
    result : DetectionResult
        Armanid inference result.
    output_path : str | Path
        File path to write (e.g. "out/frame.jpg").
    draw : bool
        If True, save annotated image. If False, save original.

    Returns
    -------
    Path  Resolved output path.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    img = result.plot() if draw else result.image

    try:
        import cv2
        cv2.imwrite(str(output_path), img)
    except ImportError:
        from PIL import Image
        Image.fromarray(img[..., ::-1]).save(str(output_path))

    print(f"[Armanid] Saved → {output_path}")
    return output_path


# ── JSON export ───────────────────────────────────────────────────────────────

def detections_to_json(result: "DetectionResult") -> list:
    """
    Convert a DetectionResult to a plain list-of-dicts (JSON-serializable).

    Returns
    -------
    list[dict]  Each dict has keys: label, conf, cls_id, x1, y1, x2, y2,
                width, height, track_id.
    """
    out = []
    for b in result.boxes:
        out.append({
            "label":    b.label,
            "conf":     round(b.conf, 4),
            "cls_id":   b.cls_id,
            "x1":       round(b.x1, 2),
            "y1":       round(b.y1, 2),
            "x2":       round(b.x2, 2),
            "y2":       round(b.y2, 2),
            "width":    round(b.width, 2),
            "height":   round(b.height, 2),
            "track_id": b.track_id,
        })
    return out


# ── Webcam helper ─────────────────────────────────────────────────────────────

def run_webcam(model: "Armanid", cam_index: int = 0, conf: float = 0.25, show_fps: bool = True):
    """
    Live webcam detection loop.

    Parameters
    ----------
    model : Armanid
        Loaded Armanid model.
    cam_index : int
        Camera index (0 = default webcam).
    conf : float
        Detection confidence threshold.
    show_fps : bool
        Show FPS counter.
    """
    try:
        import cv2
    except ImportError:
        raise ImportError("[Armanid] run_webcam requires opencv-python.")

    cap = cv2.VideoCapture(cam_index)
    if not cap.isOpened():
        raise RuntimeError(f"[Armanid] Cannot open camera index {cam_index}")

    print("[Armanid] Webcam started — press 'q' to quit.")
    print("   Model:", model.model_name)
    print("   Confidence:", conf)
    print("   Camera:", cam_index)

    fps_counter = []
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_count += 1
        start_time = time.time()

        # Run detection
        results = model.detect(frame, conf=conf)

        # Calculate FPS
        if show_fps:
            fps_counter.append(1.0 / (time.time() - start_time))
            if len(fps_counter) > 30:
                fps_counter.pop(0)
            avg_fps = sum(fps_counter) / len(fps_counter)

        # Draw detections
        if results:
            annotated = draw_detections(frame, results[0])
        else:
            annotated = frame

        # Add FPS counter
        if show_fps:
            fps_text = f"FPS: {avg_fps:.1f}"
            cv2.putText(annotated, fps_text, (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)

        cv2.imshow("Armanid Live Detection", annotated)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("[Armanid] Webcam closed.")
