# antarraksha-semantic-kernel

Antarraksha AI Agent Enforcement SDK for Microsoft Semantic Kernel.

## Installation

```bash
pip install antarraksha-semantic-kernel
```

## Quick Start

Attach Antarraksha as a prompt filter and function filter on your Semantic Kernel instance. Registration happens automatically on first use — no login, no API key, no signup required.

```python
from semantic_kernel import Kernel
from antarraksha_semantic_kernel import (
    AntarrakshaPromptFilter,
    AntarrakshaFunctionFilter,
)

prompt_filter = AntarrakshaPromptFilter(agent_id="my-sk-agent")
function_filter = AntarrakshaFunctionFilter(agent_id="my-sk-agent")

kernel = Kernel()
kernel.add_filter("prompt_rendering", prompt_filter.on_prompt_render)
kernel.add_filter("function_invocation", function_filter.on_function_invocation)
```

Run your kernel normally — every prompt render and function invocation is now enforced against Antarraksha policy. DENY raises `PermissionError`.

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `agent_id` | `None` | Unique identifier for your agent. Triggers auto-registration on first use. |
| `base_url` | `"https://antarraksha.ai"` | Antarraksha endpoint. Override for self-hosted / dev. |
| `passport_id` | `None` | Optional pre-issued passport ID (e.g. `ANTK-PASS-xxx`). |
| `sdk_key` | `None` | Optional pre-issued SDK key. If omitted and `agent_id` is set, the SDK auto-registers and obtains one. |
| `fail_closed` | `True` | If `True`, deny on enforcement-server unreachable. Set `False` for fail-open during early integration. |

## Corporate Network Note

If you're behind a corporate TLS-inspection proxy and see `SSLCertVerificationError`, install:

```bash
pip install pip-system-certs
```

This makes Python trust your Windows / macOS system certificate store.
