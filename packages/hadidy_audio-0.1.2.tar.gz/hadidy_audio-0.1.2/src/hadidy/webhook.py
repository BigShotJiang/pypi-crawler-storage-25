from __future__ import annotations

import hmac
import hashlib
from typing import Any


class WebhookVerifier:
    def __init__(self, secret: str) -> None:
        if not secret:
            raise ValueError("secret must not be empty")
        self._secret = secret.encode() if isinstance(secret, str) else secret

    def verify(self, raw_body: bytes | str, signature: str) -> bool:
        if not signature:
            return False
        sig = signature.removeprefix("sha256=")
        if isinstance(raw_body, str):
            raw_body = raw_body.encode()
        # L-4: Use hmac.digest() (Python 3.7+) — constant-time, faster than hmac.new()
        expected = hmac.digest(self._secret, raw_body, "sha256").hex()
        try:
            return hmac.compare_digest(sig, expected)
        except Exception:
            return False

    def flask_before_request(self) -> Any:
        from flask import request, abort

        def check() -> None:
            sig = request.headers.get("x-webhook-signature", "")
            if not self.verify(request.get_data(), sig):
                abort(401)

        return check

    def fastapi_dependency(self) -> Any:
        from fastapi import Request, HTTPException

        verifier = self

        async def _dep(request: Request) -> None:
            body = await request.body()
            sig = request.headers.get("x-webhook-signature", "")
            if not verifier.verify(body, sig):
                raise HTTPException(status_code=401, detail="Invalid webhook signature")

        return _dep
