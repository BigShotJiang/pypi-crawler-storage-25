from __future__ import annotations
from typing import Any, BinaryIO, Generator, AsyncGenerator, Callable
import time
import asyncio

from .._http import HttpTransport, AsyncHttpTransport, _validate_id

MAX_PAGES = 1_000  # M-4: safety ceiling to prevent infinite pagination loops


class JobsResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self, **params: Any) -> dict[str, Any]:
        return self._http.get("/api/v2/jobs", params=params)

    def list_all(self, **params: Any) -> Generator[dict[str, Any], None, None]:
        page = 1
        while True:
            if page > MAX_PAGES:
                raise RuntimeError(
                    f"list_all: exceeded {MAX_PAGES} pages. The server may be returning "
                    "incorrect pagination metadata."
                )
            resp = self.list(page=page, **params)
            data = resp.get("data", [])
            yield from data
            if not resp.get("meta", {}).get("has_next") or not data:
                break
            page += 1

    def get(self, job_id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v2/jobs/{_validate_id(job_id, 'job_id')}")

    def create(self, file: BinaryIO, output_format: str, filename: str | None = None, **options: Any) -> dict[str, Any]:
        fname = filename or getattr(file, "name", "upload.bin")
        files = {"file": (fname, file, "application/octet-stream")}
        data = {"output_format": output_format, **{k: str(v) for k, v in options.items() if v is not None}}
        return self._http.post("/api/v1/uploads/", data=data, files=files)

    def create_v2(self, file_key: str, output_format: str, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v2/jobs", json={"file_key": file_key, "output_format": output_format, **options})

    def re_transcode(self, job_id: str, output_format: str, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/uploads/re-transcode", json={"job_id": job_id, "output_format": output_format, **options})

    def delete(self, job_id: str) -> None:
        return self._http.delete(f"/api/v2/jobs/{_validate_id(job_id, 'job_id')}")

    def get_output(self, job_id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v2/jobs/{_validate_id(job_id, 'job_id')}/output")

    def wait_for_completion(
        self,
        job_id: str,
        timeout: float = 300.0,
        poll_interval: float = 2.0,
        on_progress: Callable[[dict[str, Any]], None] | None = None,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            job = self.get(job_id)
            if on_progress:
                on_progress(job)
            status = job.get("status")
            if status == "completed":
                return job
            if status in ("failed", "cancelled"):
                raise RuntimeError(f"Job {job_id} ended with status '{status}': {job.get('error_message')}")
            remaining = deadline - time.monotonic()
            time.sleep(min(poll_interval, max(0, remaining)))
        raise TimeoutError(f"Job {job_id} did not complete within {timeout}s")


class AsyncJobsResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list(self, **params: Any) -> dict[str, Any]:
        return await self._http.get("/api/v2/jobs", params=params)

    async def list_all(self, **params: Any) -> AsyncGenerator[dict[str, Any], None]:
        page = 1
        while True:
            if page > MAX_PAGES:
                raise RuntimeError(
                    f"list_all: exceeded {MAX_PAGES} pages. The server may be returning "
                    "incorrect pagination metadata."
                )
            resp = await self.list(page=page, **params)
            data = resp.get("data", [])
            for item in data:
                yield item
            if not resp.get("meta", {}).get("has_next") or not data:
                break
            page += 1

    async def get(self, job_id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v2/jobs/{_validate_id(job_id, 'job_id')}")

    async def delete(self, job_id: str) -> None:
        return await self._http.delete(f"/api/v2/jobs/{_validate_id(job_id, 'job_id')}")

    async def get_output(self, job_id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v2/jobs/{_validate_id(job_id, 'job_id')}/output")

    async def wait_for_completion(
        self,
        job_id: str,
        timeout: float = 300.0,
        poll_interval: float = 2.0,
        on_progress: Callable[[dict[str, Any]], None] | None = None,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            job = await self.get(job_id)
            if on_progress:
                on_progress(job)
            status = job.get("status")
            if status == "completed":
                return job
            if status in ("failed", "cancelled"):
                raise RuntimeError(f"Job {job_id} ended with status '{status}': {job.get('error_message')}")
            remaining = deadline - time.monotonic()
            await asyncio.sleep(min(poll_interval, max(0, remaining)))
        raise TimeoutError(f"Job {job_id} did not complete within {timeout}s")
