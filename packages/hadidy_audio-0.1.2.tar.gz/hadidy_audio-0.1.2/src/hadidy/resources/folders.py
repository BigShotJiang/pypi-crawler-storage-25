from __future__ import annotations
from typing import Any
from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class FoldersResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self) -> list[Any]: return self._http.get("/api/v1/folders")
    def get(self, id: str) -> dict[str, Any]: return self._http.get(f"/api/v1/folders/{_validate_id(id)}")
    def breadcrumb(self, id: str) -> list[Any]: return self._http.get(f"/api/v1/folders/{_validate_id(id)}/breadcrumb")
    def create(self, name: str, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/folders", json={"name": name, **options})
    def update(self, id: str, **fields: Any) -> dict[str, Any]:
        return self._http.patch(f"/api/v1/folders/{_validate_id(id)}", json=fields)
    def delete(self, id: str) -> None: return self._http.delete(f"/api/v1/folders/{_validate_id(id)}")
    def move_files(self, job_ids: list[str], folder_id: str | None) -> dict[str, Any]:
        return self._http.post("/api/v1/folders/move-files", json={"job_ids": job_ids, "folder_id": folder_id})


class AsyncFoldersResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list(self) -> list[Any]: return await self._http.get("/api/v1/folders")
    async def get(self, id: str) -> dict[str, Any]: return await self._http.get(f"/api/v1/folders/{_validate_id(id)}")
    async def breadcrumb(self, id: str) -> list[Any]: return await self._http.get(f"/api/v1/folders/{_validate_id(id)}/breadcrumb")
    async def create(self, name: str, **options: Any) -> dict[str, Any]:
        return await self._http.post("/api/v1/folders", json={"name": name, **options})
    async def update(self, id: str, **fields: Any) -> dict[str, Any]:
        return await self._http.patch(f"/api/v1/folders/{_validate_id(id)}", json=fields)
    async def delete(self, id: str) -> None: return await self._http.delete(f"/api/v1/folders/{_validate_id(id)}")
    async def move_files(self, job_ids: list[str], folder_id: str | None) -> dict[str, Any]:
        return await self._http.post("/api/v1/folders/move-files", json={"job_ids": job_ids, "folder_id": folder_id})
