from __future__ import annotations
from typing import Any
from .._http import HttpTransport, AsyncHttpTransport


class BillingResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def balance(self) -> dict[str, Any]: return self._http.get("/api/v1/billing/balance")
    def history(self, **params: Any) -> dict[str, Any]: return self._http.get("/api/v1/billing/history", params=params)
    def service_costs(self) -> list[Any]: return self._http.get("/api/v1/auth/service-costs")


class AsyncBillingResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def balance(self) -> dict[str, Any]: return await self._http.get("/api/v1/billing/balance")
    async def history(self, **params: Any) -> dict[str, Any]: return await self._http.get("/api/v1/billing/history", params=params)
    async def service_costs(self) -> list[Any]: return await self._http.get("/api/v1/auth/service-costs")
