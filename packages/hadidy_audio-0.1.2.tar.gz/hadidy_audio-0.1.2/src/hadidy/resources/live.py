from __future__ import annotations
from typing import Any, AsyncGenerator, Generator
from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class LiveResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list_sessions(self, **params: Any) -> dict[str, Any]:
        return self._http.get("/api/v1/live/sessions", params=params)

    def list_sessions_all(self, **params: Any) -> Generator[dict[str, Any], None, None]:
        page = 1
        while True:
            resp = self.list_sessions(page=page, **params)
            data = resp.get("data", [])
            yield from data
            if not resp.get("meta", {}).get("has_next"):
                break
            page += 1

    def get_session(self, id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}")

    def create_session(self, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/live/sessions", json=options)

    def update_session(self, id: str, **fields: Any) -> dict[str, Any]:
        return self._http.patch(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}", json=fields)

    def start_session(self, id: str) -> dict[str, Any]:
        return self._http.post(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/start")

    def stop_session(self, id: str) -> dict[str, Any]:
        return self._http.post(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/stop")

    def restart_session(self, id: str) -> dict[str, Any]:
        return self._http.post(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/restart")

    def delete_session(self, id: str) -> None:
        return self._http.delete(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}")

    def regenerate_key(self, id: str) -> dict[str, Any]:
        return self._http.post(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/regenerate-key")

    def update_now_playing(self, id: str, title: str, **fields: Any) -> None:
        return self._http.patch(
            f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/now-playing",
            json={"title": title, **fields},
        )

    def clear_now_playing(self, id: str) -> None:
        return self._http.delete(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/now-playing")

    def list_sources(self, session_id: str) -> list[Any]:
        return self._http.get(f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/sources")

    def add_source(self, session_id: str, role: str, display_name: str) -> dict[str, Any]:
        return self._http.post(
            f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/sources",
            json={"role": role, "display_name": display_name},
        )

    def list_participants(self, session_id: str) -> list[Any]:
        return self._http.get(f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/participants")

    def list_recordings(self, session_id: str) -> list[Any]:
        return self._http.get(f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/recordings")


class AsyncLiveResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list_sessions(self, **params: Any) -> dict[str, Any]:
        return await self._http.get("/api/v1/live/sessions", params=params)

    async def list_sessions_all(self, **params: Any) -> AsyncGenerator[dict[str, Any], None]:
        page = 1
        while True:
            resp = await self.list_sessions(page=page, **params)
            data = resp.get("data", [])
            for item in data:
                yield item
            if not resp.get("meta", {}).get("has_next"):
                break
            page += 1

    async def get_session(self, id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}")

    async def create_session(self, **options: Any) -> dict[str, Any]:
        return await self._http.post("/api/v1/live/sessions", json=options)

    async def start_session(self, id: str) -> dict[str, Any]:
        return await self._http.post(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/start")

    async def stop_session(self, id: str) -> dict[str, Any]:
        return await self._http.post(f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/stop")

    async def update_now_playing(self, id: str, title: str, **fields: Any) -> None:
        return await self._http.patch(
            f"/api/v1/live/sessions/{_validate_id(id, 'session_id')}/now-playing",
            json={"title": title, **fields},
        )

    async def list_sources(self, session_id: str) -> list[Any]:
        return await self._http.get(f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/sources")

    async def add_source(self, session_id: str, role: str, display_name: str) -> dict[str, Any]:
        return await self._http.post(
            f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/sources",
            json={"role": role, "display_name": display_name},
        )

    async def list_recordings(self, session_id: str) -> list[Any]:
        return await self._http.get(f"/api/v1/live/sessions/{_validate_id(session_id, 'session_id')}/recordings")
