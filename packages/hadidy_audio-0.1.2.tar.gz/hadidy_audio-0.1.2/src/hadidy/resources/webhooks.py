from __future__ import annotations
from typing import Any, Generator, AsyncGenerator
from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class WebhooksResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self) -> list[Any]: return self._http.get("/api/v1/webhooks/")
    def get(self, id: str) -> dict[str, Any]: return self._http.get(f"/api/v1/webhooks/{_validate_id(id)}")
    def create(self, url: str, events: list[str], **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/webhooks/", json={"url": url, "events": events, **options})
    def update(self, id: str, **fields: Any) -> dict[str, Any]:
        return self._http.put(f"/api/v1/webhooks/{_validate_id(id)}", json=fields)
    def delete(self, id: str) -> None: return self._http.delete(f"/api/v1/webhooks/{_validate_id(id)}")
    def deliveries(self, id: str, **params: Any) -> dict[str, Any]:
        return self._http.get(f"/api/v1/webhooks/{_validate_id(id)}/deliveries", params=params)
    def test(self, id: str) -> dict[str, Any]:
        return self._http.post(f"/api/v1/webhooks/{_validate_id(id)}/test")


class AsyncWebhooksResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list(self) -> list[Any]: return await self._http.get("/api/v1/webhooks/")
    async def get(self, id: str) -> dict[str, Any]: return await self._http.get(f"/api/v1/webhooks/{_validate_id(id)}")
    async def create(self, url: str, events: list[str], **options: Any) -> dict[str, Any]:
        return await self._http.post("/api/v1/webhooks/", json={"url": url, "events": events, **options})
    async def update(self, id: str, **fields: Any) -> dict[str, Any]:
        return await self._http.put(f"/api/v1/webhooks/{_validate_id(id)}", json=fields)
    async def delete(self, id: str) -> None: return await self._http.delete(f"/api/v1/webhooks/{_validate_id(id)}")
    async def deliveries(self, id: str, **params: Any) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/webhooks/{_validate_id(id)}/deliveries", params=params)
    async def test(self, id: str) -> dict[str, Any]:
        return await self._http.post(f"/api/v1/webhooks/{_validate_id(id)}/test")
