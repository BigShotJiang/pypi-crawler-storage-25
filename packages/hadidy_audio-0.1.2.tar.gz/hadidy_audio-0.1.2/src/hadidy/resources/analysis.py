from __future__ import annotations
from typing import Any, BinaryIO
from .._http import HttpTransport, AsyncHttpTransport


class AnalysisResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def analyze(self, file: BinaryIO, filename: str | None = None) -> dict[str, Any]:
        fname = filename or getattr(file, "name", "upload.bin")
        return self._http.post("/api/v1/audio/analyze", files={"file": (fname, file, "application/octet-stream")})


class AsyncAnalysisResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def analyze(self, file: BinaryIO, filename: str | None = None) -> dict[str, Any]:
        fname = filename or getattr(file, "name", "upload.bin")
        return await self._http.post("/api/v1/audio/analyze", files={"file": (fname, file, "application/octet-stream")})
