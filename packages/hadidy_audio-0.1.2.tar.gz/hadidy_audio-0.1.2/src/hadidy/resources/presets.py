from __future__ import annotations
from typing import Any, Generator, AsyncGenerator

from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class PresetsResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self, **params: Any) -> dict[str, Any]:
        return self._http.get("/api/v1/presets/", params=params)

    def list_all(self, **params: Any) -> Generator[dict[str, Any], None, None]:
        page = 1
        while True:
            resp = self.list(page=page, **params)
            data = resp.get("data", [])
            yield from data
            if not resp.get("meta", {}).get("has_next"):
                break
            page += 1

    def get(self, preset_id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v1/presets/{_validate_id(preset_id, 'preset_id')}")

    def create(self, name: str, output_format: str, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/presets/", json={"name": name, "output_format": output_format, **options})

    def update(self, preset_id: str, **fields: Any) -> dict[str, Any]:
        return self._http.put(f"/api/v1/presets/{_validate_id(preset_id, 'preset_id')}", json=fields)

    def delete(self, preset_id: str) -> None:
        return self._http.delete(f"/api/v1/presets/{_validate_id(preset_id, 'preset_id')}")


class AsyncPresetsResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list(self, **params: Any) -> dict[str, Any]:
        return await self._http.get("/api/v1/presets/", params=params)

    async def list_all(self, **params: Any) -> AsyncGenerator[dict[str, Any], None]:
        page = 1
        while True:
            resp = await self.list(page=page, **params)
            for item in resp.get("data", []):
                yield item
            if not resp.get("meta", {}).get("has_next"):
                break
            page += 1

    async def get(self, preset_id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/presets/{_validate_id(preset_id, 'preset_id')}")

    async def create(self, name: str, output_format: str, **options: Any) -> dict[str, Any]:
        return await self._http.post("/api/v1/presets/", json={"name": name, "output_format": output_format, **options})

    async def update(self, preset_id: str, **fields: Any) -> dict[str, Any]:
        return await self._http.put(f"/api/v1/presets/{_validate_id(preset_id, 'preset_id')}", json=fields)

    async def delete(self, preset_id: str) -> None:
        return await self._http.delete(f"/api/v1/presets/{_validate_id(preset_id, 'preset_id')}")
