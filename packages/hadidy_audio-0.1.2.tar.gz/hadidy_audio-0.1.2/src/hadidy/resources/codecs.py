from __future__ import annotations
from typing import Any
from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class CodecsResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list_codecs(self) -> list[Any]: return self._http.get("/api/v1/codecs")
    def get_codec(self, id: str) -> dict[str, Any]: return self._http.get(f"/api/v1/codecs/{_validate_id(id, 'codec_id')}")
    def list_formats(self) -> list[Any]: return self._http.get("/api/v1/formats")
    def get_format(self, id: str) -> dict[str, Any]: return self._http.get(f"/api/v1/formats/{_validate_id(id, 'format_id')}")
    def capabilities(self) -> dict[str, Any]: return self._http.get("/api/v1/capabilities")


class AsyncCodecsResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list_codecs(self) -> list[Any]: return await self._http.get("/api/v1/codecs")
    async def get_codec(self, id: str) -> dict[str, Any]: return await self._http.get(f"/api/v1/codecs/{_validate_id(id, 'codec_id')}")
    async def list_formats(self) -> list[Any]: return await self._http.get("/api/v1/formats")
    async def get_format(self, id: str) -> dict[str, Any]: return await self._http.get(f"/api/v1/formats/{_validate_id(id, 'format_id')}")
    async def capabilities(self) -> dict[str, Any]: return await self._http.get("/api/v1/capabilities")
