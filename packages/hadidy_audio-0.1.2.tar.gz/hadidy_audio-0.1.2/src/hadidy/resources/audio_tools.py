from __future__ import annotations
from typing import Any
from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class AudioToolsResource:
    def __init__(self, http: HttpTransport, base_url: str) -> None:
        self._http = http
        self._base_url = base_url.rstrip("/")

    def waveform_image_url(self, job_id: str) -> str:
        return f"{self._base_url}/api/v1/audio/{_validate_id(job_id, 'job_id')}/waveform"

    def waveform_data(self, job_id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/waveform-data")

    def silence(self, job_id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/silence")

    def get_metadata(self, job_id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/metadata")

    def update_metadata(self, job_id: str, **fields: Any) -> dict[str, Any]:
        return self._http.put(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/metadata", json=fields)

    def cover_art_url(self, job_id: str) -> str:
        return f"{self._base_url}/api/v1/audio/{_validate_id(job_id, 'job_id')}/cover-art"

    def concat(self, job_ids: list[str], output_format: str, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/audio/concat", json={"job_ids": job_ids, "output_format": output_format, **options})


class AsyncAudioToolsResource:
    def __init__(self, http: AsyncHttpTransport, base_url: str) -> None:
        self._http = http
        self._base_url = base_url.rstrip("/")

    def waveform_image_url(self, job_id: str) -> str:
        return f"{self._base_url}/api/v1/audio/{_validate_id(job_id, 'job_id')}/waveform"

    async def waveform_data(self, job_id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/waveform-data")

    async def silence(self, job_id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/silence")

    async def get_metadata(self, job_id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/metadata")

    async def update_metadata(self, job_id: str, **fields: Any) -> dict[str, Any]:
        return await self._http.put(f"/api/v1/audio/{_validate_id(job_id, 'job_id')}/metadata", json=fields)

    def cover_art_url(self, job_id: str) -> str:
        return f"{self._base_url}/api/v1/audio/{_validate_id(job_id, 'job_id')}/cover-art"

    async def concat(self, job_ids: list[str], output_format: str, **options: Any) -> dict[str, Any]:
        return await self._http.post("/api/v1/audio/concat", json={"job_ids": job_ids, "output_format": output_format, **options})
