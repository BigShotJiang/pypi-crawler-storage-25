from __future__ import annotations
from typing import Any
from .._http import HttpTransport, AsyncHttpTransport, _validate_id


class SharingResource:
    def __init__(self, http: HttpTransport) -> None:
        self._http = http

    def list(self) -> list[Any]: return self._http.get("/api/v1/sharing")
    def get(self, id: str) -> dict[str, Any]: return self._http.get(f"/api/v1/sharing/{_validate_id(id)}")
    def create(self, type: str, target_id: str, **options: Any) -> dict[str, Any]:
        return self._http.post("/api/v1/sharing", json={"type": type, "target_id": target_id, **options})
    def update(self, id: str, **fields: Any) -> dict[str, Any]:
        return self._http.patch(f"/api/v1/sharing/{_validate_id(id)}", json=fields)
    def delete(self, id: str) -> None: return self._http.delete(f"/api/v1/sharing/{_validate_id(id)}")
    def get_public_info(self, id: str) -> dict[str, Any]:
        return self._http.get(f"/api/v1/sharing/public/{_validate_id(id)}")
    def verify_passcode(self, id: str, passcode: str) -> dict[str, Any]:
        return self._http.post(f"/api/v1/sharing/public/{_validate_id(id)}/verify", json={"passcode": passcode})


class AsyncSharingResource:
    def __init__(self, http: AsyncHttpTransport) -> None:
        self._http = http

    async def list(self) -> list[Any]: return await self._http.get("/api/v1/sharing")
    async def get(self, id: str) -> dict[str, Any]: return await self._http.get(f"/api/v1/sharing/{_validate_id(id)}")
    async def create(self, type: str, target_id: str, **options: Any) -> dict[str, Any]:
        return await self._http.post("/api/v1/sharing", json={"type": type, "target_id": target_id, **options})
    async def update(self, id: str, **fields: Any) -> dict[str, Any]:
        return await self._http.patch(f"/api/v1/sharing/{_validate_id(id)}", json=fields)
    async def delete(self, id: str) -> None: return await self._http.delete(f"/api/v1/sharing/{_validate_id(id)}")
    async def get_public_info(self, id: str) -> dict[str, Any]:
        return await self._http.get(f"/api/v1/sharing/public/{_validate_id(id)}")
    async def verify_passcode(self, id: str, passcode: str) -> dict[str, Any]:
        return await self._http.post(f"/api/v1/sharing/public/{_validate_id(id)}/verify", json={"passcode": passcode})
