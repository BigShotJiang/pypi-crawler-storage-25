from __future__ import annotations

from ._http import AsyncHttpTransport, DEFAULT_BASE_URL, DEFAULT_TIMEOUT, DEFAULT_MAX_RETRIES
from .resources import (
    AsyncJobsResource, AsyncPresetsResource, AsyncCodecsResource, AsyncAnalysisResource,
    AsyncAudioToolsResource, AsyncWebhooksResource, AsyncBillingResource,
    AsyncFoldersResource, AsyncSharingResource, AsyncLiveResource,
)


class AsyncAudioClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._http = AsyncHttpTransport(api_key=api_key, base_url=base_url, timeout=timeout, max_retries=max_retries)
        base = base_url.rstrip("/")

        self.jobs = AsyncJobsResource(self._http)
        self.presets = AsyncPresetsResource(self._http)
        self.codecs = AsyncCodecsResource(self._http)
        self.analysis = AsyncAnalysisResource(self._http)
        self.audio = AsyncAudioToolsResource(self._http, base)
        self.webhooks = AsyncWebhooksResource(self._http)
        self.billing = AsyncBillingResource(self._http)
        self.folders = AsyncFoldersResource(self._http)
        self.sharing = AsyncSharingResource(self._http)
        self.live = AsyncLiveResource(self._http)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncAudioClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
