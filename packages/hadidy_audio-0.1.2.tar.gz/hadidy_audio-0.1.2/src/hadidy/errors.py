from __future__ import annotations

from typing import Any, Optional
import httpx

__all__ = [
    "HadidyError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "NetworkError",
]


class HadidyError(Exception):
    status: int | None
    code: str | None
    request_id: str | None

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: str | None = None,
        request_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.code = code
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"{type(self).__name__}(status={self.status}, code={self.code!r}, message={str(self)!r})"


class AuthenticationError(HadidyError):
    pass


class ForbiddenError(HadidyError):
    pass


class NotFoundError(HadidyError):
    pass


class RateLimitError(HadidyError):
    retry_after: float | None

    def __init__(self, message: str, *, retry_after: float | None = None, **kwargs: Any) -> None:
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class ValidationError(HadidyError):
    fields: dict[str, list[str]]

    def __init__(self, message: str, *, fields: dict[str, list[str]] | None = None, **kwargs: Any) -> None:
        super().__init__(message, **kwargs)
        self.fields = fields or {}


class ServerError(HadidyError):
    pass


class NetworkError(HadidyError):
    pass


def map_response_to_error(response: httpx.Response) -> HadidyError:
    request_id: str | None = response.headers.get("x-request-id")
    try:
        body: dict[str, Any] = response.json()
    except Exception:
        body = {}

    message: str = body.get("detail") or body.get("message") or response.reason_phrase or "Unknown error"
    code: str | None = body.get("code")

    status = response.status_code
    kwargs: dict[str, Any] = {"status": status, "code": code, "request_id": request_id}

    if status == 401:
        return AuthenticationError(message, **kwargs)
    if status == 403:
        return ForbiddenError(message, **kwargs)
    if status == 404:
        return NotFoundError(message, **kwargs)
    if status == 422:
        fields: dict[str, list[str]] = {}
        if isinstance(body.get("detail"), list):
            for err in body["detail"]:
                loc = ".".join(str(p) for p in err.get("loc", []))
                fields.setdefault(loc, []).append(err.get("msg", ""))
        return ValidationError(message, fields=fields, **kwargs)
    if status == 429:
        retry_after: float | None = None
        try:
            retry_after = float(response.headers.get("retry-after", "0"))
        except ValueError:
            pass
        return RateLimitError(message, retry_after=retry_after, **kwargs)
    if status >= 500:
        return ServerError(message, **kwargs)
    return HadidyError(message, **kwargs)
