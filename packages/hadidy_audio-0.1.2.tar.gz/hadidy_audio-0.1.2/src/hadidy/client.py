from __future__ import annotations

from ._http import HttpTransport, DEFAULT_BASE_URL, DEFAULT_TIMEOUT, DEFAULT_MAX_RETRIES
from .resources import (
    JobsResource, PresetsResource, CodecsResource, AnalysisResource,
    AudioToolsResource, WebhooksResource, BillingResource,
    FoldersResource, SharingResource, LiveResource,
)


class AudioClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._http = HttpTransport(api_key=api_key, base_url=base_url, timeout=timeout, max_retries=max_retries)
        base = base_url.rstrip("/")

        self.jobs = JobsResource(self._http)
        self.presets = PresetsResource(self._http)
        self.codecs = CodecsResource(self._http)
        self.analysis = AnalysisResource(self._http)
        self.audio = AudioToolsResource(self._http, base)
        self.webhooks = WebhooksResource(self._http)
        self.billing = BillingResource(self._http)
        self.folders = FoldersResource(self._http)
        self.sharing = SharingResource(self._http)
        self.live = LiveResource(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "AudioClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
