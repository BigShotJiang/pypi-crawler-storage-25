from .client import AudioClient
from .async_client import AsyncAudioClient
from .webhook import WebhookVerifier
from .errors import (
    HadidyError,
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    ServerError,
    NetworkError,
)

__all__ = [
    "AudioClient",
    "AsyncAudioClient",
    "WebhookVerifier",
    "HadidyError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "NetworkError",
]

__version__ = "0.1.2"
