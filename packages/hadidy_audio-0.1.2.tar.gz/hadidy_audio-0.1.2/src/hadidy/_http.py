from __future__ import annotations

import re
import time
from typing import Any
import httpx

from .errors import HadidyError, NetworkError, map_response_to_error

SDK_VERSION = "0.1.2"
SDK_NAME = "hadidy-audio-python"
DEFAULT_BASE_URL = "https://api.hadidy.com"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
MIN_RETRY_DELAY = 0.25  # floor to prevent spin-loops on retry-after: 0
MAX_RETRY_AFTER = 60.0  # cap Retry-After to prevent server-induced DoS sleep

RETRY_STATUS_CODES = {429, 500, 502, 503, 504}

# IDs from the API are UUIDs or short alphanumeric slugs — enforce this to
# prevent path-traversal via specially-crafted IDs (e.g. "../auth/me").
_SAFE_ID_RE = re.compile(r"^[A-Za-z0-9_\-]{1,256}$")


def _validate_id(value: str, name: str = "id") -> str:
    """Reject IDs that could cause path traversal or endpoint confusion."""
    if not value or not isinstance(value, str):
        raise ValueError(f"{name} must be a non-empty string")
    if not _SAFE_ID_RE.match(value):
        raise ValueError(
            f"Invalid {name}: must contain only alphanumeric characters, hyphens, "
            f"and underscores (got {value!r})"
        )
    return value


def _validate_api_key(api_key: str) -> None:
    """M-2: Reject empty or non-string API keys early with a clear error."""
    if not api_key or not isinstance(api_key, str) or not api_key.strip():
        raise ValueError(
            "api_key must be a non-empty string. "
            "Get your key from https://hadidy.com/dashboard/api-keys"
        )


def _backoff(retries: int, response: httpx.Response) -> float:
    """Compute retry delay. Respect Retry-After header when > 0, capped at MAX_RETRY_AFTER
    to prevent a hostile server from causing an indefinite sleep. Falls back to exponential
    backoff (0.5s, 1s, 2s, … up to 16s) with a minimum floor."""
    try:
        header_val = float(response.headers.get("retry-after", "0"))
        if header_val > 0:
            return max(min(header_val, MAX_RETRY_AFTER), MIN_RETRY_DELAY)
    except (ValueError, TypeError):
        pass
    # Exponential backoff: 0.5s, 1s, 2s, … capped at 16s
    return max(min(0.5 * (2 ** retries), 16.0), MIN_RETRY_DELAY)


def _clean(params: dict[str, Any] | None) -> dict[str, Any] | None:
    if params is None:
        return None
    return {k: v for k, v in params.items() if v is not None}


class HttpTransport:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        client: httpx.Client | None = None,
    ) -> None:
        _validate_api_key(api_key)  # M-2
        # H-4: store as private name-mangled to prevent accidental exposure in logs
        self.__api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = client or httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"{SDK_NAME}/{SDK_VERSION}",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        retries = 0
        while True:
            try:
                response = self._client.request(method, path, **kwargs)
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request timed out: {exc}") from exc
            except httpx.RequestError as exc:
                raise NetworkError(f"Network error: {exc}") from exc

            if response.status_code in RETRY_STATUS_CODES and retries < self.max_retries:
                delay = _backoff(retries, response)
                time.sleep(delay)
                retries += 1
                continue

            if not response.is_success:
                raise map_response_to_error(response)

            if response.status_code == 204 or not response.content:
                return None
            return response.json()

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return self.request("GET", path, params=_clean(params))

    def post(self, path: str, json: Any = None, data: Any = None, files: Any = None) -> Any:
        # M-6: removed dead-code ternary "GET" if False else "POST"
        return self.request("POST", path, json=json, data=data, files=files)

    def put(self, path: str, json: Any = None) -> Any:
        return self.request("PUT", path, json=json)

    def patch(self, path: str, json: Any = None) -> Any:
        return self.request("PATCH", path, json=json)

    def delete(self, path: str) -> Any:
        return self.request("DELETE", path)


class AsyncHttpTransport:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        _validate_api_key(api_key)  # M-2
        self.__api_key = api_key   # H-4: private
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = client or httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"{SDK_NAME}/{SDK_VERSION}",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def request(self, method: str, path: str, **kwargs: Any) -> Any:
        import asyncio
        retries = 0
        while True:
            try:
                response = await self._client.request(method, path, **kwargs)
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request timed out: {exc}") from exc
            except httpx.RequestError as exc:
                raise NetworkError(f"Network error: {exc}") from exc

            if response.status_code in RETRY_STATUS_CODES and retries < self.max_retries:
                delay = _backoff(retries, response)
                await asyncio.sleep(delay)
                retries += 1
                continue

            if not response.is_success:
                raise map_response_to_error(response)

            if response.status_code == 204 or not response.content:
                return None
            return response.json()

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        return await self.request("GET", path, params=_clean(params))

    async def post(self, path: str, json: Any = None, data: Any = None, files: Any = None) -> Any:
        return await self.request("POST", path, json=json, data=data, files=files)

    async def put(self, path: str, json: Any = None) -> Any:
        return await self.request("PUT", path, json=json)

    async def patch(self, path: str, json: Any = None) -> Any:
        return await self.request("PATCH", path, json=json)

    async def delete(self, path: str) -> Any:
        return await self.request("DELETE", path)
