from __future__ import annotations

import json
import os
from typing import Iterator

import httpx

from podflare.types import Event, Language

DEFAULT_HOST = "https://api.podflare.ai"


class Client:
    """Thin HTTP transport for the hostd contract.

    One Client per process is fine; it owns an httpx.Client.
    """

    def __init__(
        self,
        host: str | None = None,
        timeout: float = 30.0,
        traceparent: str | None = None,
        api_key: str | None = None,
    ):
        """
        Args:
            traceparent: W3C Trace Context string. Sent as `traceparent`
                header; also read from ``PODFLARE_TRACEPARENT`` env.
            api_key: Bearer token sent as ``Authorization: Bearer <key>`` on
                every request. Also read from ``PODFLARE_API_KEY`` env.
        """
        self.host = (
            host
            or os.environ.get("PODFLARE_HOSTD_URL")
            or os.environ.get("PODFLARE_HOST")  # legacy alias, removed in 0.1
            or DEFAULT_HOST
        ).rstrip("/")
        self.traceparent = traceparent or os.environ.get("PODFLARE_TRACEPARENT") or None
        self.api_key = api_key or os.environ.get("PODFLARE_API_KEY") or None
        default_headers: dict[str, str] = {}
        if self.traceparent:
            default_headers["traceparent"] = self.traceparent
        if self.api_key:
            default_headers["authorization"] = f"Bearer {self.api_key}"
        # HTTP/1.1 with keep-alive pool. We tried HTTP/2 multiplex + a
        # background warmup request in 0.0.12 to shave TLS off the first
        # call — both hurt cold-start because httpx's HTTP/2 serializes
        # concurrent requests on a single connection during setup. Plain
        # keep-alive is measurably faster cold and identical warm.
        # Limits tuned for typical agent workloads: many sequential
        # requests to the same origin, connection stays warm for ~60 s.
        #
        # Per-phase timeouts + retry (tuned in 0.0.19 — see history below).
        #
        # Problem: public-internet TCP SYN drops (~0.05–0.35 % across our
        # fleet) turn into 7-second OS-level retries, tanking p99.
        #
        # 0.0.17's fix was `connect=0.8s + retries=2`. That fixed the
        # SYN-drop case, but introduced a worse pathology: legitimate
        # slow TLS handshakes (800–2000 ms on congested wifi / cold
        # kernel TCP cache) were getting killed at 800 ms and retried
        # three times. Measured p99 with that config: 1.7–2.7 s on a
        # laptop, reproducible against a blackhole IP at 2,910 ms
        # (3 × 800 ms + backoff). Self-inflicted.
        #
        # 0.0.19's fix: widen connect to 2.5 s so the typical slow-but-
        # legitimate handshake completes on the first attempt, and drop
        # retries to 1 so a real unreachable-host failure isn't
        # compounded. Now:
        #   - fast case: ~50 ms connect → done
        #   - slow-but-fine case: up to 2.5 s connect → done, no retry
        #   - real SYN drop: 2.5 s timeout + fast retry = ~2.7 s max
        # p99 should stay under 1 s on healthy networks, max bounded at
        # ~3 s on genuinely broken ones. read/write/pool stay generous
        # so streaming exec isn't affected.
        timeouts = httpx.Timeout(
            connect=2.5,
            read=timeout,
            write=10.0,
            pool=5.0,
        )
        self._http = httpx.Client(
            base_url=self.host,
            timeout=timeouts,
            headers=default_headers or None,
            limits=httpx.Limits(
                max_keepalive_connections=8,
                max_connections=16,
                keepalive_expiry=60.0,
            ),
            transport=httpx.HTTPTransport(retries=1),
        )

    def close(self) -> None:
        self._http.close()

    def healthz(self) -> bool:
        r = self._http.get("/v1/healthz")
        return r.status_code == 200 and r.text.strip() == "ok"

    def create_sandbox(
        self,
        template: str | None = None,
        *,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        ram_mib: int | None = None,
        rootfs_gb: int | None = None,
        persistent: bool | None = None,
        egress: bool | None = None,
    ) -> str:
        """Return just the sandbox id — kept for back-compat."""
        return self.create_sandbox_info(
            template=template,
            timeout_seconds=timeout_seconds,
            idle_timeout_seconds=idle_timeout_seconds,
            ram_mib=ram_mib,
            rootfs_gb=rootfs_gb,
            persistent=persistent,
            egress=egress,
        )["id"]

    def create_sandbox_info(
        self,
        template: str | None = None,
        *,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        ram_mib: int | None = None,
        rootfs_gb: int | None = None,
        persistent: bool | None = None,
        egress: bool | None = None,
    ) -> dict:
        """Create a sandbox and return the full server response:
        ``{"id": "...", "state": "ready", "region": "eu", "endpoint":
        "https://api.podflare.ai"}``. ``region`` + ``endpoint`` are
        present only when hostd has PODFLARE_REGION + PODFLARE_PUBLIC_URL
        configured; used by Sandbox to pin subsequent calls so a
        Cloudflare-Geo-LB-routed session can't wander to a different
        region mid-sandbox.

        ``timeout_seconds`` and ``idle_timeout_seconds`` override the
        server defaults, capped by the caller's billing tier."""
        body: dict = {}
        if template:
            body["template"] = template
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if idle_timeout_seconds is not None:
            body["idle_timeout_seconds"] = idle_timeout_seconds
        if ram_mib is not None:
            body["ram_mib"] = ram_mib
        if rootfs_gb is not None:
            body["rootfs_gb"] = rootfs_gb
        if persistent is not None:
            body["persistent"] = persistent
        if egress is not None:
            body["egress"] = egress
        r = self._http.post("/v1/sandboxes", json=body)
        r.raise_for_status()
        return r.json()

    def resume_space(
        self,
        space_id: str,
        *,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        persistent: bool | None = None,
        egress: bool | None = None,
    ) -> dict:
        """Resume a frozen Space into a fresh live sandbox.

        Returns the same shape as ``create_sandbox_info``: ``{"id": "...",
        "state": "ready", "region": ..., "endpoint": ...}``. The returned
        id is a NEW sandbox — the space is consumed on successful resume.
        Pass ``persistent=True`` to have the resumed sandbox re-freeze on
        next idle (creating a new space with a new id)."""
        body: dict = {}
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if idle_timeout_seconds is not None:
            body["idle_timeout_seconds"] = idle_timeout_seconds
        if persistent is not None:
            body["persistent"] = persistent
        if egress is not None:
            body["egress"] = egress
        r = self._http.post(f"/v1/spaces/{space_id}/resume", json=body)
        r.raise_for_status()
        return r.json()

    def delete_space(self, space_id: str) -> None:
        r = self._http.delete(f"/v1/spaces/{space_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def destroy_sandbox(self, sandbox_id: str) -> None:
        r = self._http.delete(f"/v1/sandboxes/{sandbox_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def fork_sandbox(self, sandbox_id: str, n: int = 1) -> list[str]:
        r = self._http.post(
            f"/v1/sandboxes/{sandbox_id}/fork",
            json={"n": n},
            timeout=60.0,
        )
        r.raise_for_status()
        return r.json()["children"]

    def merge_into(self, parent_id: str, winner_id: str) -> None:
        r = self._http.post(f"/v1/sandboxes/{parent_id}/merge_into/{winner_id}")
        if r.status_code not in (200, 204):
            r.raise_for_status()

    def replay(self, sandbox_id: str) -> list[Event]:
        r = self._http.get(f"/v1/sandboxes/{sandbox_id}/replay")
        r.raise_for_status()
        events: list[Event] = []
        for line in r.text.splitlines():
            line = line.strip()
            if not line:
                continue
            events.append(Event.from_json(json.loads(line)))
        return events

    def exec_stream(
        self, sandbox_id: str, code: str, language: Language = "python"
    ) -> Iterator[Event]:
        body = {"code": code, "language": language}
        with self._http.stream("POST", f"/v1/sandboxes/{sandbox_id}/exec", json=body) as r:
            r.raise_for_status()
            for line in r.iter_lines():
                if not line:
                    continue
                yield Event.from_json(json.loads(line))

    # ── PTY (interactive pseudo-terminal) ──────────────────────────────
    #
    # `pty_create_stream` is the long-lived call: server holds the HTTP
    # response open for the PTY session's lifetime and emits NDJSON
    # events (pty_ready, pty_data, pty_exit, pty_error). The other
    # three are short POSTs that address the session by id.

    def pty_create_stream(
        self, sandbox_id: str, body: dict
    ) -> Iterator[dict]:
        """Open a PTY create stream. Yields raw event dicts — the SDK's
        `podflare.pty.PtyHandle` consumes these. Public callers should
        use `sandbox.pty.create(...)`, not this method directly."""
        r = self._http.stream("POST", f"/v1/sandboxes/{sandbox_id}/pty", json=body)
        # httpx streaming contexts release the response at __exit__; we
        # need the stream to outlive this function call, so we manage
        # the context manually and close in a finalizer.
        resp = r.__enter__()
        try:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if not line:
                    continue
                yield json.loads(line)
        finally:
            r.__exit__(None, None, None)

    def pty_input(self, sandbox_id: str, pty_id: str, data: bytes) -> None:
        import base64
        body = {"data_b64": base64.b64encode(data).decode("ascii")}
        r = self._http.post(
            f"/v1/sandboxes/{sandbox_id}/pty/{pty_id}/input", json=body
        )
        r.raise_for_status()

    def pty_resize(self, sandbox_id: str, pty_id: str, cols: int, rows: int) -> None:
        r = self._http.post(
            f"/v1/sandboxes/{sandbox_id}/pty/{pty_id}/resize",
            json={"cols": cols, "rows": rows},
        )
        r.raise_for_status()

    def pty_kill(self, sandbox_id: str, pty_id: str) -> None:
        r = self._http.post(f"/v1/sandboxes/{sandbox_id}/pty/{pty_id}/kill")
        r.raise_for_status()

    def pty_list(self, sandbox_id: str) -> list[dict]:
        r = self._http.get(f"/v1/sandboxes/{sandbox_id}/pty")
        r.raise_for_status()
        body = r.json()
        return body if isinstance(body, list) else []

    def pty_attach_stream(self, sandbox_id: str, pty_id: str) -> Iterator[dict]:
        """Reconnect to an existing PTY session. Yields raw event dicts —
        ring-buffer replay first, then live events until pty_exit."""
        r = self._http.stream(
            "GET", f"/v1/sandboxes/{sandbox_id}/pty/{pty_id}/attach"
        )
        resp = r.__enter__()
        try:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if not line:
                    continue
                yield json.loads(line)
        finally:
            r.__exit__(None, None, None)

    def pty_read(
        self,
        sandbox_id: str,
        pty_id: str,
        since_seq: int,
        max_bytes: int = 64 * 1024,
        timeout_ms: int = 10_000,
    ) -> dict:
        """Long-poll reader. Used by the MCP tool wrapper and any client
        that prefers discrete snapshots over a streaming connection."""
        body = {
            "since_seq": since_seq,
            "max_bytes": max_bytes,
            "timeout_ms": timeout_ms,
        }
        r = self._http.post(
            f"/v1/sandboxes/{sandbox_id}/pty/{pty_id}/read",
            json=body,
            # Server caps server-side at 30s, but the HTTP client
            # must let that complete — add a small margin for the
            # round-trip.
            timeout=max(30.0, timeout_ms / 1000 + 5.0),
        )
        r.raise_for_status()
        return r.json()
