"""Podflare PTY — first-class pseudo-terminal sessions inside a sandbox.

    pty = sandbox.pty.create(
        cmd="npm init",
        cols=120, rows=40,
        on_data=lambda b: print(b.decode(), end=""),
        timeout_ms=0,
    )
    pty.send_input(b"\\r")
    pty.resize(cols=200, rows=50)
    pty.wait()

See ``docs/concepts/pty.mdx`` for the full customer API reference.

Implementation notes
--------------------

The wire-level PTY protocol streams NDJSON events over a long-lived
HTTP response (the `POST /v1/sandboxes/{id}/pty` call stays open for
the session's lifetime). We consume that stream in a background
thread so ``send_input`` / ``resize`` / ``kill`` can interleave with
output arriving from the child process.

Phase 1 caveats (vs. the customer docs):
  * ``pty.attach(pty_id, ...)`` raises NotImplementedError — the
    reconnect + ring-buffer path is Phase 2.
  * ``timeout_ms=0`` currently maps to "no client-enforced cap"; the
    sandbox's own max_lifetime still applies.
  * ``pty.list()`` is available but returns only active sessions from
    the current hostd instance (no cross-region inventory).
"""

from __future__ import annotations

import base64
import json
import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Iterator

if TYPE_CHECKING:
    # Avoid circular import at runtime — Sandbox imports from this module.
    from podflare.sandbox import Sandbox


# Typed callback aliases. These are deliberately permissive (``Callable``
# not ``Protocol``) so users can pass a ``print`` or a lambda without
# pyright complaining.
OnDataCallback = Callable[[bytes], None]
OnExitCallback = Callable[[int], None]


@dataclass
class PtySessionInfo:
    """Metadata about an active PTY session — returned by ``pty.list()``."""

    pty_id: str
    cmd_label: str
    created_at_ms: int
    exit_code: int | None = None


@dataclass
class _StreamState:
    """Mutable state shared between the foreground handle and the
    background event-consumer thread."""

    ready_session_id: str | None = None
    exit_code: int | None = None
    error: str | None = None
    ready_event: threading.Event = field(default_factory=threading.Event)
    exit_event: threading.Event = field(default_factory=threading.Event)


class PtyHandle:
    """A live PTY session. Call ``send_input`` / ``resize`` / ``kill``
    to interact; ``wait`` blocks until the child exits.

    Lifecycle: constructed by ``PtyNamespace.create``. Do not instantiate
    directly.
    """

    def __init__(
        self,
        sandbox: "Sandbox",
        event_iter: Iterator[dict],
        on_data: OnDataCallback | None,
        on_exit: OnExitCallback | None,
    ):
        self._sandbox = sandbox
        self._state = _StreamState()
        self._on_data = on_data
        self._on_exit = on_exit

        # Spawn the consumer thread BEFORE returning — we don't return
        # to the caller until the first pty_ready event arrives (so .id
        # is populated).
        self._thread = threading.Thread(
            target=self._consume,
            args=(event_iter,),
            daemon=True,
            name="podflare-pty-consumer",
        )
        self._thread.start()

        # Wait up to 10 s for pty_ready — after that the agent is
        # almost certainly not going to respond.
        if not self._state.ready_event.wait(timeout=10.0):
            raise TimeoutError(
                "PTY did not emit pty_ready within 10 s — agent may be "
                "unreachable or `cmd` may have failed at spawn"
            )
        if self._state.error:
            raise RuntimeError(f"pty_create failed: {self._state.error}")

    @property
    def id(self) -> str:
        """Server-generated session id. Persist this across agent turns
        if you want to ``sandbox.pty.attach(id)`` later (Phase 2)."""
        assert self._state.ready_session_id is not None
        return self._state.ready_session_id

    def send_input(self, data: bytes | str) -> None:
        """Write bytes to the PTY's stdin. Accepts either ``bytes`` (raw
        keystrokes — ``b"\\x03"`` is Ctrl-C) or ``str`` (UTF-8 encoded
        automatically)."""
        if isinstance(data, str):
            data = data.encode("utf-8")
        self._sandbox._client.pty_input(self._sandbox.id, self.id, data)

    def resize(self, cols: int, rows: int) -> None:
        """Update terminal dimensions. Child receives SIGWINCH."""
        self._sandbox._client.pty_resize(self._sandbox.id, self.id, cols, rows)

    def kill(self) -> None:
        """SIGKILL the child's process group. The pty_exit event still
        fires and ``wait()`` resolves shortly after."""
        self._sandbox._client.pty_kill(self._sandbox.id, self.id)

    def wait(self, timeout: float | None = None) -> int:
        """Block until the child exits. Returns the exit code.

        Raises TimeoutError if ``timeout`` elapses first.
        """
        if not self._state.exit_event.wait(timeout=timeout):
            raise TimeoutError("pty session did not exit within the timeout")
        return self._state.exit_code if self._state.exit_code is not None else -1

    def close(self) -> None:
        """Stop dispatching events to callbacks. Does NOT kill the
        child — call ``.kill()`` first if you want that. Idempotent."""
        self._on_data = None
        self._on_exit = None

    # ── Thread target ────────────────────────────────────────────────

    def _consume(self, event_iter: Iterator[dict]) -> None:
        """Background-thread loop. Reads NDJSON events from the server
        stream, decodes base64 chunks, dispatches to callbacks, and
        flips ready/exit Events so the foreground thread can sync."""
        try:
            for ev in event_iter:
                t = ev.get("type")
                if t == "pty_ready":
                    self._state.ready_session_id = ev.get("session_id")
                    self._state.ready_event.set()
                elif t == "pty_data":
                    b = base64.b64decode(ev.get("data_b64", ""))
                    if self._on_data is not None:
                        try:
                            self._on_data(b)
                        except Exception:
                            # Never let a user callback kill the consumer
                            # thread — we still need to process pty_exit.
                            import traceback
                            traceback.print_exc()
                elif t == "pty_exit":
                    code = ev.get("data", -1)
                    try:
                        self._state.exit_code = int(code)
                    except (TypeError, ValueError):
                        self._state.exit_code = -1
                    if self._on_exit is not None:
                        try:
                            self._on_exit(self._state.exit_code)
                        except Exception:
                            import traceback
                            traceback.print_exc()
                    self._state.exit_event.set()
                    # Don't break — let the stream end naturally so we
                    # can surface any trailing pty_error messages.
                elif t == "pty_error":
                    msg = ev.get("message", "")
                    # If we haven't seen pty_ready yet, treat this as a
                    # create-time failure and surface via the gate Event.
                    if not self._state.ready_event.is_set():
                        self._state.error = msg
                        self._state.ready_event.set()
                # Unknown event types are ignored so new protocol fields
                # don't break old SDKs.
        finally:
            # Whatever happens, unblock waiters so `.wait()` doesn't hang
            # if the stream died abnormally.
            if not self._state.exit_event.is_set():
                if self._state.exit_code is None:
                    self._state.exit_code = -1
                self._state.exit_event.set()
            if not self._state.ready_event.is_set():
                self._state.error = self._state.error or "stream ended before pty_ready"
                self._state.ready_event.set()


class PtyNamespace:
    """``sandbox.pty.*`` surface. Instantiated as a member of ``Sandbox``.

    Two public methods: ``create`` (spawn a new session) and ``list``
    (inspect active sessions on this sandbox).
    """

    def __init__(self, sandbox: "Sandbox"):
        self._sandbox = sandbox

    def create(
        self,
        *,
        cmd: str | list[str],
        cols: int = 80,
        rows: int = 24,
        on_data: OnDataCallback | None = None,
        on_exit: OnExitCallback | None = None,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        timeout_ms: int = 300_000,
    ) -> PtyHandle:
        """Spawn a PTY session. See docs/concepts/pty.mdx for details.

        ``cmd``: a ``str`` is run under ``bash -lc``; a ``list[str]`` is
        ``execv``'d directly (skips the shell).

        ``timeout_ms=0`` disables the client-side timeout; the sandbox's
        max_lifetime still applies.
        """
        if isinstance(cmd, str):
            body: dict = {"shellCmd": cmd}
        else:
            if not cmd:
                raise ValueError("cmd list must not be empty")
            body = {"argv": list(cmd)}
        body["cols"] = cols
        body["rows"] = rows
        if env:
            body["env"] = [[k, v] for k, v in env.items()]
        if cwd is not None:
            body["cwd"] = cwd
        # timeout_ms is advisory on the client for Phase 1 — the server
        # doesn't enforce it yet; reaper-driven sandbox lifetime bounds it.

        event_iter = self._sandbox._client.pty_create_stream(self._sandbox.id, body)
        return PtyHandle(self._sandbox, event_iter, on_data, on_exit)

    def attach(
        self,
        pty_id: str,
        *,
        on_data: OnDataCallback | None = None,
        on_exit: OnExitCallback | None = None,
    ) -> PtyHandle:
        """Reconnect to an existing PTY session.

        Opens a new streaming HTTP connection to
        `/v1/sandboxes/{id}/pty/{pty_id}/attach`. The server replays the
        session's 1 MiB ring buffer first — so the first events you see
        are historical (anything emitted while you were disconnected) —
        then tails live until the child exits.

        Args:
            pty_id: The session id you got from an earlier
                ``pty.create(...)`` call (stored on ``PtyHandle.id``).
            on_data: New callback for incoming bytes. Previous listeners
                on the same session in other processes still get their
                own stream.
            on_exit: New callback for the child's exit code.

        Raises:
            RuntimeError: session doesn't exist, or the server rejected
                the attach for any other reason.
        """
        event_iter = self._sandbox._client.pty_attach_stream(
            self._sandbox.id, pty_id
        )

        # On attach, the server doesn't emit pty_ready (you already have
        # the id). Seed the ready state before the consumer thread starts
        # so PtyHandle's constructor wait doesn't trip.
        class _PreSeeded(PtyHandle):
            def __init__(
                self,
                sandbox: "Sandbox",
                event_iter_: "Iterator[dict]",
                pty_id_: str,
                on_data_: OnDataCallback | None,
                on_exit_: OnExitCallback | None,
            ):
                self._sandbox = sandbox
                self._state = _StreamState()
                self._state.ready_session_id = pty_id_
                self._state.ready_event.set()
                self._on_data = on_data_
                self._on_exit = on_exit_
                self._thread = threading.Thread(
                    target=self._consume,
                    args=(event_iter_,),
                    daemon=True,
                    name="podflare-pty-consumer",
                )
                self._thread.start()

        return _PreSeeded(self._sandbox, event_iter, pty_id, on_data, on_exit)

    def list(self) -> list[PtySessionInfo]:
        """Return active PTY sessions on this sandbox."""
        raw = self._sandbox._client.pty_list(self._sandbox.id)
        out = []
        for item in raw:
            out.append(
                PtySessionInfo(
                    pty_id=item.get("pty_id", ""),
                    cmd_label=item.get("cmd_label", ""),
                    created_at_ms=int(item.get("created_at_ms", 0)),
                    exit_code=item.get("exit_code"),
                )
            )
        return out
