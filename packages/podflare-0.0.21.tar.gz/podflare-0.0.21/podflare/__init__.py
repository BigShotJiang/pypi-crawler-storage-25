from podflare.client import Client
from podflare.pty import PtyHandle, PtyNamespace, PtySessionInfo
from podflare.regions import (
    REGIONS,
    RegionInfo,
    UnknownRegionError,
    detect_local_region,
    haversine_km,
    nearest_region_to,
    resolve_region,
)
from podflare.sandbox import Sandbox, close_default_client
from podflare.types import Event, ExecResult, Language

__all__ = [
    "Sandbox",
    "Client",
    "Event",
    "ExecResult",
    "Language",
    "PtyHandle",
    "PtyNamespace",
    "PtySessionInfo",
    "REGIONS",
    "RegionInfo",
    "UnknownRegionError",
    "close_default_client",
    "detect_local_region",
    "haversine_km",
    "nearest_region_to",
    "resolve_region",
]
# Note: provider integrations (anthropic, openai-agents, langchain,
# gemini, ...) live in their own submodules — `from podflare.langchain
# import PodflareTool`, `from podflare.gemini import run_function_call`,
# etc. They are NOT re-exported at the top level so the bare `import
# podflare` doesn't try to import optional deps (langchain-core,
# google-genai) the user hasn't installed.
__version__ = "0.0.21"
