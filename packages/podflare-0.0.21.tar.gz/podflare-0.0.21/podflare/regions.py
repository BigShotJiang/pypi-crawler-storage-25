"""Region resolution for the SDK.

Routing model
-------------

Two layers, in order of preference:

1. **Client-side nearest-region selection** (this module). The SDK
   embeds a coordinate registry that mirrors the Worker's
   ``api-router/src/regions.ts`` and uses **haversine distance** to pick
   the closest region for the caller. Detection is timezone-based
   (zero HTTP, zero permissions) — IANA timezones tell us the caller's
   approximate location accurately enough for "which DC is closest"
   decisions. Unknown timezones fall through to layer 2.

2. **Server-side geo routing via Cloudflare Worker** at
   ``api.podflare.ai``. When the SDK can't pick a region locally
   (unknown timezone, or caller passed ``host=...`` explicitly), it
   sends to the Worker which uses Cloudflare's per-request lat/lon
   to make the same haversine call.

Why client-side picking is worth it: skipping the Worker hop on the
first ``Sandbox.create()`` saves ~50 ms wall clock, and removes a
single point of routing dependency. After the first call, the SDK
already pins the resolved direct URL — so layer 1 only matters for
the *first* request after process start.

Override behavior:

* ``region="us-west"`` → explicit region (always wins)
* ``host="https://..."`` → explicit URL (always wins)
* ``PODFLARE_API_URL`` env var → override the public API base
* otherwise → client-side haversine via timezone

Adding a region: append to ``_REGION_REGISTRY`` here AND in
``api-router/src/regions.ts``. SDK publish required so existing
clients pick it up; until then the Worker still routes via continent
fallback.
"""
from __future__ import annotations

import math
import os
import time
from typing import NamedTuple
from urllib.parse import quote

_API_BASE_URL = os.environ.get("PODFLARE_API_URL", "https://api.podflare.ai")


class RegionInfo(NamedTuple):
    """Static metadata for one region. Mirror of api-router/src/regions.ts."""

    name: str
    direct_url: str
    lat: float
    lon: float


# Keep in sync with api-router/src/regions.ts. Coordinates are
# approximate datacenter locations, rounded to ~0.1° (≈ 11 km) — no
# point being more precise than client-side timezone resolution.
_REGION_REGISTRY: tuple[RegionInfo, ...] = (
    RegionInfo("us-west",    "https://usw1.podflare.ai",  37.4, -121.9),
    RegionInfo("us-central", "https://usc1.podflare.ai",  32.8,  -96.8),
    RegionInfo("us-east",    "https://use1.podflare.ai",  39.0,  -77.5),
    RegionInfo("eu",         "https://hel.podflare.ai",   60.2,   24.9),
    RegionInfo("sg",         "https://sing1.podflare.ai",  1.4,  103.8),
)

# Aliases for what callers might pass as `region=` strings — maps the
# colloquial form to the canonical name. Anything else is left
# untouched and forwarded to the edge for validation.
_ALIASES: dict[str, str] = {
    "us": "us-west",
    "usa": "us-west",
    "america": "us-west",
    "central": "us-central",
    "us-cen": "us-central",
    "east": "us-east",
    "us-e": "us-east",
    "europe": "eu",
    "asia": "sg",
    "singapore": "sg",
    "apac": "sg",
}


def resolve_region(region: str | None) -> str | None:
    """Return the base URL the SDK should target for the given region.

    Accepts canonical names (``us-west``), aliases (``us``, ``europe``),
    or any non-empty string (forwarded to the edge for validation).
    Returns ``None`` when no region was specified.
    """
    if region is None:
        return None
    key = region.strip().lower()
    if not key:
        return None
    canonical = _ALIASES.get(key, key)
    # Direct URL when we know the region — skips the Worker hop.
    for info in _REGION_REGISTRY:
        if info.name == canonical:
            return info.direct_url
    # Unknown but syntactically valid: route through the edge so it can
    # validate and either serve or 404. Backward-compatible with
    # custom regions registered server-side.
    return f"{_API_BASE_URL}/r/{quote(canonical, safe='')}"


# --- Client-side nearest-region selection ----------------------------------


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in kilometers. Same math the Worker runs."""
    r = 6371.0  # mean Earth radius, km
    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    s = (
        math.sin(d_lat / 2) ** 2
        + math.cos(math.radians(lat1))
        * math.cos(math.radians(lat2))
        * math.sin(d_lon / 2) ** 2
    )
    return 2 * r * math.asin(math.sqrt(s))


def nearest_region_to(lat: float, lon: float) -> RegionInfo:
    """Return the closest region to a (lat, lon) by haversine distance."""
    return min(
        _REGION_REGISTRY,
        key=lambda r: haversine_km(lat, lon, r.lat, r.lon),
    )


# IANA timezone → approximate coordinates of a major city in that
# zone. Covers the ~80 most common timezones; unknown ones return
# ``None`` and the SDK falls back to Worker-side routing.
#
# We don't need precision here — anything within the right metro is
# close enough that the haversine pick to one of our 5 regions is
# correct. (Wrong city in the right country still picks the right DC.)
_TIMEZONE_COORDS: dict[str, tuple[float, float]] = {
    # North America
    "America/Los_Angeles": (34.0, -118.2),  # LA
    "America/Vancouver":   (49.3, -123.1),
    "America/Tijuana":     (32.5, -117.0),
    "America/Phoenix":     (33.4, -112.1),
    "America/Denver":      (39.7, -105.0),
    "America/Edmonton":    (53.5, -113.5),
    "America/Boise":       (43.6, -116.2),
    "America/Anchorage":   (61.2, -149.9),
    "America/Chicago":     (41.9,  -87.6),
    "America/Mexico_City": (19.4,  -99.1),
    "America/Winnipeg":    (49.9,  -97.1),
    "America/Monterrey":   (25.7, -100.3),
    "America/New_York":    (40.7,  -74.0),
    "America/Toronto":     (43.7,  -79.4),
    "America/Montreal":    (45.5,  -73.6),
    "America/Halifax":     (44.6,  -63.6),
    "America/Detroit":     (42.3,  -83.0),
    "America/Indianapolis":(39.8,  -86.1),
    "America/Atlanta":     (33.7,  -84.4),
    "America/Miami":       (25.8,  -80.2),
    "America/Havana":      (23.1,  -82.4),
    # South America (most route to us-east via shorter Atlantic path)
    "America/Sao_Paulo":     (-23.5, -46.6),
    "America/Buenos_Aires":  (-34.6, -58.4),
    "America/Santiago":      (-33.5, -70.7),
    "America/Lima":          (-12.0, -77.0),
    "America/Bogota":         (4.7,  -74.1),
    "America/Caracas":        (10.5, -66.9),
    # Europe
    "Europe/London":     (51.5,  -0.1),
    "Europe/Dublin":     (53.3,  -6.2),
    "Europe/Paris":      (48.8,   2.3),
    "Europe/Madrid":     (40.4,  -3.7),
    "Europe/Lisbon":     (38.7,  -9.1),
    "Europe/Berlin":     (52.5,  13.4),
    "Europe/Amsterdam":  (52.4,   4.9),
    "Europe/Brussels":   (50.8,   4.4),
    "Europe/Zurich":     (47.4,   8.5),
    "Europe/Vienna":     (48.2,  16.4),
    "Europe/Rome":       (41.9,  12.5),
    "Europe/Stockholm":  (59.3,  18.1),
    "Europe/Oslo":       (59.9,  10.8),
    "Europe/Copenhagen": (55.7,  12.6),
    "Europe/Helsinki":   (60.2,  24.9),
    "Europe/Warsaw":     (52.2,  21.0),
    "Europe/Prague":     (50.1,  14.4),
    "Europe/Budapest":   (47.5,  19.0),
    "Europe/Athens":     (38.0,  23.7),
    "Europe/Istanbul":   (41.0,  29.0),
    "Europe/Moscow":     (55.8,  37.6),
    "Europe/Kiev":       (50.5,  30.5),
    # Africa + Middle East (mostly closer to eu)
    "Africa/Cairo":          (30.0,  31.2),
    "Africa/Lagos":           (6.5,   3.4),
    "Africa/Johannesburg": (-26.2,  28.0),
    "Africa/Nairobi":        (-1.3,  36.8),
    "Africa/Casablanca":     (33.6,  -7.6),
    "Asia/Dubai":            (25.3,  55.3),
    "Asia/Riyadh":           (24.7,  46.7),
    "Asia/Tehran":           (35.7,  51.4),
    "Asia/Jerusalem":        (31.8,  35.2),
    # South + Southeast Asia
    "Asia/Karachi":      (24.9,  67.0),
    "Asia/Kolkata":      (22.6,  88.4),  # routes via SG due to distance
    "Asia/Calcutta":     (22.6,  88.4),  # legacy alias
    "Asia/Mumbai":       (19.1,  72.9),  # not actually in IANA but defensive
    "Asia/Bangkok":      (13.8, 100.5),
    "Asia/Singapore":     (1.4, 103.8),
    "Asia/Jakarta":      (-6.2, 106.8),
    "Asia/Kuala_Lumpur":  (3.1, 101.7),
    "Asia/Manila":       (14.6, 121.0),
    "Asia/Ho_Chi_Minh":  (10.8, 106.7),
    "Asia/Hanoi":        (21.0, 105.8),
    # East Asia
    "Asia/Shanghai":   (31.2, 121.5),
    "Asia/Hong_Kong":  (22.3, 114.2),
    "Asia/Taipei":     (25.0, 121.5),
    "Asia/Tokyo":      (35.7, 139.7),
    "Asia/Seoul":      (37.6, 127.0),
    "Asia/Macau":      (22.2, 113.5),
    # Oceania (closest is SG; fallback to us-west via Pacific cable)
    "Australia/Sydney":     (-33.9, 151.2),
    "Australia/Melbourne":  (-37.8, 145.0),
    "Australia/Brisbane":   (-27.5, 153.0),
    "Australia/Perth":      (-31.9, 115.9),
    "Pacific/Auckland":     (-36.9, 174.8),
    "Pacific/Honolulu":     (21.3, -157.9),
    # UTC = unknown / containerized — fall through.
}


def _local_timezone_name() -> str | None:
    """Best-effort detection of the caller's IANA timezone.

    ``zoneinfo`` (Python 3.9+) doesn't expose the local zone name
    portably, so we walk a small ladder of conventional sources. None
    of these involve network calls.
    """
    # 1. TZ env var (always wins when set)
    tz = os.environ.get("TZ")
    if tz and "/" in tz:
        return tz
    # 2. /etc/localtime symlink → /usr/share/zoneinfo/<zone>
    try:
        link = os.readlink("/etc/localtime")
        if "zoneinfo/" in link:
            return link.split("zoneinfo/", 1)[1]
    except (OSError, FileNotFoundError):
        pass
    # 3. /etc/timezone (Debian/Ubuntu)
    try:
        with open("/etc/timezone", "r", encoding="utf-8") as f:
            name = f.read().strip()
            if name and "/" in name:
                return name
    except (OSError, FileNotFoundError):
        pass
    # 4. Python's tzname (often "PST" / "EST" — too coarse for routing,
    #    so we don't try to map it; just return None and fall through).
    _ = time.tzname  # touched for completeness; not used
    return None


def detect_local_region() -> RegionInfo | None:
    """Return the nearest region for the *caller's* machine, or None
    when we can't tell (unknown timezone, container with TZ=UTC, etc).

    Pure local — no HTTP, no permissions. Uses IANA timezone → coords
    → haversine. Result is stable for the process lifetime.
    """
    tz = _local_timezone_name()
    if not tz:
        return None
    coords = _TIMEZONE_COORDS.get(tz)
    if coords is None:
        return None
    return nearest_region_to(coords[0], coords[1])


def default_api_base() -> str:
    """Pick the best base URL for ``Sandbox()`` when no explicit
    ``host`` or ``region`` is given.

    Returns ``api.podflare.ai`` (the Cloudflare-fronted edge Worker).

    Rationale — we benched both vantages from residential wifi with
    SDK 0.0.19, n=100 per side:

        via Worker   p50=158  p95=174  p99=187  max=460  ms
        direct usw1  p50=158  p95=176  p99=232  max=319  ms

    Worker wins p99 by ~20%. Median is tied. Worker max is slightly
    worse (one 460ms outlier vs direct's 319ms) but still well under
    the 500ms bar. Plus, the Worker path gets you things that `direct`
    doesn't:

      * Automatic failover to the next-nearest region on 5xx (create
        requests only — non-idempotent calls aren't retried).
      * Per-request geo routing using Cloudflare's per-request
        lat/lon, more accurate than our client-side timezone guess.
      * Concurrent-limit enforcement + usage accounting (billing).

    SDK 0.0.16–0.0.19 defaulted to a direct region URL picked from
    the caller's timezone. That was a decent theory (skip the hop)
    but the measured numbers don't back it up — Cloudflare's edge is
    usually *closer* to the caller than the origin is, and CF's
    backbone to the origin is faster than most public-internet paths.
    0.0.20 restores ``api.podflare.ai`` as the default.

    Override via ``host=...``, ``region=...``, or the
    ``PODFLARE_API_URL`` env var — all still work identically.
    """
    # Explicit env override always wins.
    if "PODFLARE_API_URL" in os.environ:
        return _API_BASE_URL
    return _API_BASE_URL


# --- Backward-compat exports ----------------------------------------------

# Legacy export. Retained for code that read this dict directly.
# Prefer ``resolve_region()``. Now includes us-central + sg.
REGIONS: dict[str, str] = {
    info.name: info.direct_url for info in _REGION_REGISTRY
}
# Common aliases also exposed here so dict lookups don't surprise.
REGIONS["us"] = REGIONS["us-west"]
REGIONS["europe"] = REGIONS["eu"]
REGIONS["asia"] = REGIONS["sg"]


class UnknownRegionError(ValueError):
    """Raised only when a region value is syntactically invalid
    (empty / wrong type). Unknown-but-syntactically-valid regions
    are forwarded to the edge for validation."""

    pass
