# Podflare — Python SDK

Cloud sandbox for AI agents. Fork in 100 ms, persistent Python REPL, `run_code`, `upload`/`download`, `merge_into`.

- Docs: https://docs.podflare.ai
- Dashboard: https://dashboard.podflare.ai — mint an API key in seconds
- GitHub: https://github.com/PodFlare-ai/podflare

## Install

```bash
pip install podflare
```

## Quickstart

```python
from podflare import Sandbox

# Create a sandbox (persistent Python REPL, preloaded libs on python-datasci)
sbx = Sandbox(template="python-datasci")

# Execute code — state persists across calls
sbx.run_code("x = 42")
print(sbx.run_code("print(x * 2)").stdout)  # "84"

# Fork — spawn N copies of the running sandbox
children = sbx.fork(n=5)
children[0].run_code("x = 100")   # isolated per branch

# Merge a branch back into the parent
sbx.merge_into(children[0])

# Upload + download files
sbx.upload("data.csv", open("local.csv", "rb").read())
sbx.run_code("import pandas as pd; df = pd.read_csv('data.csv')")

# Destroy
sbx.close()
```

## Configuration

| Env var              | Default                       | What it does |
|----------------------|-------------------------------|--------------|
| `PODFLARE_API_KEY`   | *(none — required)*           | Bearer token from the dashboard (`pf_live_...`). |
| `PODFLARE_HOSTD_URL` | `https://api.podflare.ai`     | Override for self-hosted or staging deployments. |

You can also pass them as constructor arguments:

```python
from podflare import Sandbox

sbx = Sandbox(
    host="https://api.podflare.ai",
    api_key="pf_live_...",
    template="default",
)
```

## Streaming

```python
with Sandbox() as s:
    for ev in s.run_code_stream("for i in range(3): print(i)"):
        if ev.type == "stdout":
            print(ev.data, flush=True)
```

## Framework adapters

First-class integrations:

- OpenAI Agents SDK — `podflare.adapters.openai_agents`
- Anthropic `code_execution` tool — `podflare.adapters.anthropic`
- MCP server (`podflare-mcp` npm package) for Claude Desktop / Cursor / Cline / Zed

See the [integrations docs](https://docs.podflare.ai/integrations) for copy-paste examples.

## Links

- [Documentation](https://docs.podflare.ai)
- [API reference](https://docs.podflare.ai/api-reference/introduction)
- [Status](https://podflare.ai/status)
- [Issues](https://github.com/PodFlare-ai/podflare/issues)

## License

Proprietary.
