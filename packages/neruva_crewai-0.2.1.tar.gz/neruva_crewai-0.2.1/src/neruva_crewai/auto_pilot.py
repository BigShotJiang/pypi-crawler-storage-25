"""Auto-pilot integration for CrewAI.

Exposes:

  NeruvaAutoPilot       -- framework-agnostic core. Fetches substrate
                            prompts (route_intent, reflect, extract) and
                            runs them through a caller-supplied LLM.
                            Returns structured results.

  NeruvaAutoPilotHooks  -- helper that returns task-level callable
                            hooks: before_task (route intent) and
                            after_task (auto-extract from result text).
                            Use with `Task(callback=hooks.after_task)`.

Pattern-C: substrate emits prompt, caller LLM runs it, results pushed
back via the existing client. Substrate stays $0/call.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Optional

from neruva_crewai._client import NeruvaClient


_EXTRACTION_PROMPT = (
    "You are a precise triple extractor. Given input text, extract the "
    "factual (subject, predicate, object) triples it asserts. Use "
    "canonical lowercase tokens. Predicates are short verb phrases "
    "(e.g., 'lives_in', 'works_at', 'said', 'is_a').\n\n"
    "Output ONLY a JSON array. No prose. No commentary.\n\n"
    'Example input: "Alice told me she lives in Toronto and works at Acme."\n'
    'Example output: [["alice","lives_in","toronto"],["alice","works_at","acme"]]\n\n'
    "If the text contains no extractable facts, output []."
)


def _strip_json(s: str) -> str:
    s = s.strip()
    m = re.search(r"```(?:json)?\s*(.+?)```", s, re.DOTALL)
    if m:
        return m.group(1).strip()
    for opener, closer in (("{", "}"), ("[", "]")):
        i, j = s.find(opener), s.rfind(closer)
        if 0 <= i < j:
            return s[i:j + 1]
    return s


class NeruvaAutoPilot:
    """Framework-agnostic auto-pilot helper for CrewAI users."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        namespace: str = "default",
        llm_callable: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.client = NeruvaClient(api_key=api_key)
        self.namespace = namespace
        self.llm_callable = llm_callable
        self._auto_kg = f"{namespace}-auto-kg"

    def _invoke(self, prompt: str) -> str:
        if self.llm_callable is None:
            raise RuntimeError(
                "NeruvaAutoPilot needs llm_callable=. Pass a callable "
                "that takes a prompt and returns the LLM's text response "
                "(e.g., the .call() method of your CrewAI LLM)."
            )
        return self.llm_callable(prompt)

    def classify_intent(
        self,
        user_message: str,
        recent_context_summary: Optional[str] = None,
    ) -> dict[str, Any]:
        payload = self.client._post(
            "/v1/agent/route_intent_prompt",
            {
                "user_message": user_message,
                "recent_context_summary": recent_context_summary,
            },
        )
        raw = self._invoke(payload["prompt"])
        try:
            return json.loads(_strip_json(raw))
        except Exception:
            return {"primary_intent": "none", "confidence": 0.0}

    def reflect(
        self,
        recent_turns: list[dict[str, Any]],
        auto_write: bool = True,
    ) -> dict[str, Any]:
        payload = self.client._post(
            "/v1/agent/reflect_prompt",
            {"recent_turns": recent_turns},
        )
        raw = self._invoke(payload["prompt"])
        try:
            parsed = json.loads(_strip_json(raw))
        except Exception:
            return {"decisions": [], "facts": [], "mistakes": [], "open_questions": []}
        if auto_write:
            self._write_reflected(parsed)
        return parsed

    def _write_reflected(self, parsed: dict[str, Any]) -> None:
        items = []
        for d in parsed.get("decisions", []) or []:
            items.append({
                "kind": "decision",
                "text": d.get("text", ""),
                "tags": (d.get("tags") or []) + ["auto-reflected"],
            })
        for m in parsed.get("mistakes", []) or []:
            items.append({
                "kind": "mistake",
                "text": m.get("text", "") + (
                    f"  ROOT CAUSE: {m.get('root_cause')}" if m.get("root_cause") else ""
                ),
                "tags": ["auto-reflected"],
            })
        for q in parsed.get("open_questions", []) or []:
            items.append({
                "kind": "open_question",
                "text": q if isinstance(q, str) else q.get("text", ""),
                "tags": ["auto-reflected"],
            })
        if items:
            try:
                self.client._post(f"/v1/records/{self.namespace}", {"items": items})
            except Exception:
                pass
        facts = parsed.get("facts", []) or []
        triples = [
            [f.get("subject", ""), f.get("relation", ""), f.get("object", "")]
            for f in facts
            if f.get("subject") and f.get("relation") and f.get("object")
        ]
        if triples:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": triples},
                )
            except Exception:
                pass

    def extract_facts(self, text: str, auto_write: bool = True) -> list[list[str]]:
        prompt = _EXTRACTION_PROMPT + "\n\nINPUT:\n" + text
        raw = self._invoke(prompt)
        try:
            triples = json.loads(_strip_json(raw))
        except Exception:
            return []
        if not isinstance(triples, list):
            return []
        clean = [
            t for t in triples
            if isinstance(t, list) and len(t) == 3 and all(isinstance(x, str) for x in t)
        ]
        if auto_write and clean:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": clean},
                )
            except Exception:
                pass
        return clean


class NeruvaAutoPilotHooks:
    """Bundle of CrewAI task callbacks. Pass `after_task` to a Task's
    `callback=` argument to auto-extract facts from the task output.
    Pass `before_task` to a Task's `prompt_context_provider=` (or
    similar pre-task hook depending on your CrewAI version).

    Example:
        ap = NeruvaAutoPilot(api_key="nv_...", namespace="my_crew",
                             llm_callable=my_llm.call)
        hooks = NeruvaAutoPilotHooks(ap)
        task = Task(description="...", agent=agent,
                    callback=hooks.after_task)
    """

    def __init__(self, auto_pilot: NeruvaAutoPilot) -> None:
        self.ap = auto_pilot

    def after_task(self, task_output: Any) -> None:
        """CrewAI calls this with the task's TaskOutput. We extract facts
        from the output text and push to the auto-KG."""
        text = ""
        if hasattr(task_output, "raw"):
            text = str(task_output.raw or "")
        elif hasattr(task_output, "result"):
            text = str(task_output.result or "")
        else:
            text = str(task_output)
        if not text.strip() or len(text) < 20:
            return
        try:
            self.ap.extract_facts(text, auto_write=True)
        except Exception:
            pass

    def reflect_on_crew_finish(
        self,
        agent_outputs: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Call after `Crew().kickoff()` returns. Reflects over all
        agent outputs as turns and auto-writes structured records."""
        recent_turns = [
            {"role": "assistant", "text": str(o.get("output") or o.get("text") or "")[:4000]}
            for o in agent_outputs
            if (o.get("output") or o.get("text"))
        ]
        if len(recent_turns) < 2:
            return {}
        try:
            return self.ap.reflect(recent_turns, auto_write=True)
        except Exception:
            return {}
