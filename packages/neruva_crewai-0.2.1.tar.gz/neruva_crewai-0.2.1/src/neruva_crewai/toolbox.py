"""Toolbox: convenience wrappers over Neruva's code-graph + cognitive
primitive endpoints, framework-agnostic but bundled with this adapter
for ergonomic in-chain use.

Two classes:

  NeruvaCodeGraph    -- 5 sub-ms code navigation methods backed by
                        code KGs built by `neruva-record-code-index`.
                        callers / callees / class_of / module_of /
                        imports.

  NeruvaCognitive    -- 13 cognitive primitive methods covering
                        counterfactual rollouts, theory-of-mind
                        (nested belief), schema lifting, EFE planning,
                        continual K-gram, hierarchical chunking,
                        few-shot rule induction.

Both are thin wrappers over `_client.NeruvaClient`. Substrate stays
$0/call. For raw / advanced tools not surfaced here (PII rules,
snapshot/restore, KG admin, etc.) use the `@neruva/mcp` MCP server
directly from your framework's MCP integration.
"""
from __future__ import annotations

from typing import Any, Optional

from neruva_crewai._client import NeruvaClient


# ---------------------------------------------------------------------------
# Code-graph: 5 sub-ms navigation methods over KGs built by
# neruva-record-code-index. Wraps /v1/hd/kg/{kg}/query with the right
# (subject, relation) pair per intent.
# ---------------------------------------------------------------------------

class NeruvaCodeGraph:
    """Code-graph navigation. Works against any KG built by
    `neruva-record code-index` (Python + JS/TS/Go/Rust/Java/Ruby/C++)."""

    def __init__(
        self,
        kg: str,
        api_key: Optional[str] = None,
    ) -> None:
        self.kg = kg
        self.client = NeruvaClient(api_key=api_key)

    def _query(self, subject: str, relation: str) -> Any:
        return self.client._post(
            f"/v1/hd/kg/{self.kg}/query",
            {"subject": subject, "relation": relation},
        )

    def callers(self, qname: str) -> Any:
        """Who calls this function? `qname` = '<module>::<fn>' or
        '<module>::<Class>.<method>'."""
        return self._query(qname, "called_by")

    def callees(self, qname: str) -> Any:
        """What does this function call?"""
        return self._query(qname, "calls")

    def class_of(self, qname: str) -> Any:
        """What class does this method belong to?"""
        return self._query(qname, "defined_in_class")

    def module_of(self, qname: str) -> Any:
        """What module is this symbol defined in?"""
        return self._query(qname, "defined_in_module")

    def imports(self, module: str) -> Any:
        """What does this module import?"""
        return self._query(module, "imports_from")


# ---------------------------------------------------------------------------
# Cognitive primitives: 13 endpoints under /v1/agent/* (substrate v0.4.0+).
# Each is the moat -- frontier LLMs hallucinate at depth 4 on ToM,
# confabulate counterfactuals, need fine-tuning for rule induction,
# and don't ship EFE planning as a primitive at all.
# ---------------------------------------------------------------------------

class NeruvaCognitive:
    """13 cognitive primitive methods. Wraps /v1/agent/* endpoints."""

    def __init__(self, api_key: Optional[str] = None) -> None:
        self.client = NeruvaClient(api_key=api_key)

    # ---- counterfactual rollout ----
    def counterfactual_rollout(
        self,
        initial_state: list[int],
        action_seq: list[int],
        step_k: int,
        alternate_action: int,
        n_axes: int = 3,
        n_values: int = 8,
        seed: int = 0,
    ) -> Any:
        """Replay an action sequence with one action swapped at step_k.
        Returns the alternate final state. Deterministic from seed."""
        return self.client._post(
            "/v1/agent/counterfactual_rollout",
            {
                "initial_state": initial_state,
                "action_seq": action_seq,
                "step_k": step_k,
                "alternate_action": alternate_action,
                "n_axes": n_axes,
                "n_values": n_values,
                "seed": seed,
            },
        )

    # ---- theory of mind (nested belief) ----
    def model_belief_add(
        self,
        chain: list[int],
        prop: int,
        val: int,
        namespace: str = "tom",
        codebook: Optional[str] = None,
    ) -> Any:
        """Add a nested belief: chain=[holder_idx, ..., subject_idx].
        E.g., [Alice, Bob, Charlie] = 'Alice believes Bob believes Charlie'."""
        body = {"chain": chain, "prop": prop, "val": val, "namespace": namespace}
        if codebook:
            body["codebook"] = codebook
        return self.client._post("/v1/agent/model_belief_add", body)

    def model_belief(
        self,
        chain: list[int],
        prop: int,
        namespace: str = "tom",
        codebook: Optional[str] = None,
    ) -> Any:
        """Query a belief value for a given chain + property index."""
        body = {"chain": chain, "prop": prop, "namespace": namespace}
        if codebook:
            body["codebook"] = codebook
        return self.client._post("/v1/agent/model_belief", body)

    # ---- schema lifting ----
    def extract_schema(self, role_filler_pairs: list[tuple[int, int]]) -> Any:
        """Lift an abstract schema signature via UNBIND + cleanup."""
        return self.client._post(
            "/v1/agent/extract_schema",
            {"role_filler_pairs": role_filler_pairs},
        )

    # ---- EFE planning ----
    def register_action(
        self,
        action_id: int,
        add_effects: dict[int, float],
        del_effects: Optional[dict[int, float]] = None,
    ) -> Any:
        """Register an action's calibrated add/del effects (probabilities
        in [0,1]) on attribute indices."""
        body = {"action_id": action_id, "add_effects": add_effects}
        if del_effects:
            body["del_effects"] = del_effects
        return self.client._post("/v1/agent/register_action", body)

    def plan_efe(
        self,
        state: list[int],
        candidate_plans: list[list[int]],
        want_on: list[int],
        want_off: Optional[list[int]] = None,
    ) -> Any:
        """Score candidate action sequences via KL on attribute marginals.
        Returns ranked plans + EFE scores."""
        body = {
            "state": state,
            "candidate_plans": candidate_plans,
            "want_on": want_on,
        }
        if want_off:
            body["want_off"] = want_off
        return self.client._post("/v1/agent/plan_efe", body)

    # ---- continual K-gram ----
    def continual_train(
        self,
        stream: list[int],
        K: int = 3,
        namespace: str = "default",
    ) -> Any:
        """Sharded K-gram with integer-add no-forgetting."""
        return self.client._post(
            "/v1/agent/continual_train",
            {"stream": stream, "K": K, "namespace": namespace},
        )

    def continual_predict(
        self,
        context: list[int],
        K: int = 3,
        namespace: str = "default",
    ) -> Any:
        """Predict next token given last K-1 context tokens."""
        return self.client._post(
            "/v1/agent/continual_predict",
            {"context": context, "K": K, "namespace": namespace},
        )

    # ---- hierarchical chunking (L^K) ----
    def hierarchical_add(
        self,
        positions: list[int],
        values: list[int],
        namespace: str = "default",
    ) -> Any:
        """Compositional position-bind encode."""
        return self.client._post(
            "/v1/agent/hierarchical_add",
            {"positions": positions, "values": values, "namespace": namespace},
        )

    def hierarchical_decode(
        self,
        positions: list[int],
        namespace: str = "default",
    ) -> Any:
        """Walk K positions to decode the encoded sequence."""
        return self.client._post(
            "/v1/agent/hierarchical_decode",
            {"positions": positions, "namespace": namespace},
        )

    # ---- few-shot rule induction ----
    def induce_rule(self, examples: list[dict[str, Any]]) -> Any:
        """Induce a rule signature from few-shot (input, output) examples."""
        return self.client._post(
            "/v1/agent/induce_rule",
            {"examples": examples},
        )

    def persist_rule(
        self,
        rule_id: str,
        signature: list[float],
        namespace: str = "rules",
    ) -> Any:
        """Store an induced rule for later recall by rule_id."""
        return self.client._post(
            "/v1/agent/persist_rule",
            {"rule_id": rule_id, "signature": signature, "namespace": namespace},
        )

    def recall_rule(
        self,
        signature: list[float],
        namespace: str = "rules",
        top_k: int = 5,
    ) -> Any:
        """Recall top-K matching rules by signature similarity."""
        return self.client._post(
            "/v1/agent/recall_rule",
            {"signature": signature, "namespace": namespace, "top_k": top_k},
        )
