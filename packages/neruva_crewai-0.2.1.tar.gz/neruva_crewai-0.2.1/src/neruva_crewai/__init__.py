"""CrewAI integration for Neruva agent memory.

Drop-in replacement for CrewAI's default storage backends. Three memory
flavors backed by Neruva's Records + KG substrate:

  NeruvaShortTermMemory   -- per-crew-run scratchpad
  NeruvaLongTermMemory    -- persistent across runs (semantic recall)
  NeruvaEntityMemory      -- tracks entities + relationships via HD KG

Common storage backend:
  NeruvaStorage           -- implements CrewAI's Storage interface

Install:
    pip install neruva-crewai

Usage (3 lines):
    from neruva_crewai import NeruvaLongTermMemory
    memory = NeruvaLongTermMemory(namespace="my_crew", api_key="nv_...")
    # pass to Crew(memory=True, long_term_memory=memory)
"""
from neruva_crewai.storage import NeruvaStorage
from neruva_crewai.short_term import NeruvaShortTermMemory
from neruva_crewai.long_term import NeruvaLongTermMemory
from neruva_crewai.entity import NeruvaEntityMemory

try:
    from neruva_crewai.auto_pilot import (
        NeruvaAutoPilot,
        NeruvaAutoPilotHooks,
    )
    _AUTOPILOT = ["NeruvaAutoPilot", "NeruvaAutoPilotHooks"]
except Exception:  # pragma: no cover
    _AUTOPILOT = []

from neruva_crewai.toolbox import NeruvaCodeGraph, NeruvaCognitive

__all__ = [
    "NeruvaStorage",
    "NeruvaShortTermMemory",
    "NeruvaLongTermMemory",
    "NeruvaEntityMemory",
    "NeruvaCodeGraph",
    "NeruvaCognitive",
] + _AUTOPILOT

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("neruva-crewai")
except PackageNotFoundError:
    __version__ = "0.0.0+local"
