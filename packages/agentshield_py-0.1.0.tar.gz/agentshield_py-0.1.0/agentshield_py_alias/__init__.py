"""Alias package. Re-exports agentshield-guard."""
from agentshield import *  # noqa: F401,F403
from agentshield import AgentShield, AsyncAgentShield  # noqa: F401

__all__ = ["AgentShield", "AsyncAgentShield"]
