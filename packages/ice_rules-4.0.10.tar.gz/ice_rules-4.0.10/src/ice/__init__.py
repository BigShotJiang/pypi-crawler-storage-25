"""
Ice Rule Engine Python SDK

A Python implementation of the Ice rule engine, compatible with Java and Go SDKs.
"""

from ice.context.roam import Roam
from ice.enums import RunState, NodeType, TimeType
from ice.leaf.registry import leaf, register_leaf, get_leaf_nodes, LeafMeta, IceField, IceIgnore, FieldMeta
from ice.log import set_trace_id, get_trace_id, reset_trace_id
from ice.client.file_client import FileClient
from ice.client.async_file_client import AsyncFileClient
from ice.node.base import set_global_error_handler, ErrorHandler
from ice.dispatcher import (
    sync_process,
    async_process,
    process_roam,
    process_single_roam,
    get_handler_by_id,
    get_handlers_by_scene,
)

try:
    from importlib.metadata import version
    __version__ = version("ice-rules")
except Exception:
    __version__ = "0.0.0"  # fallback for development

__all__ = [
    # Context
    "Roam",
    # Enums
    "RunState",
    "NodeType",
    "TimeType",
    # Leaf registration
    "leaf",
    "register_leaf",
    "get_leaf_nodes",
    "IceField",
    "IceIgnore",
    "LeafMeta",
    # Logging
    "set_trace_id",
    "get_trace_id",
    "reset_trace_id",
    # Clients
    "FileClient",
    "AsyncFileClient",
    # Error handling
    "set_global_error_handler",
    "ErrorHandler",
    # Processing (main)
    "sync_process",
    "async_process",
    # Processing (convenience - matching Java/Go)
    "process_roam",
    "process_single_roam",
    # Handler access (matching Go)
    "get_handler_by_id",
    "get_handlers_by_scene",
]
