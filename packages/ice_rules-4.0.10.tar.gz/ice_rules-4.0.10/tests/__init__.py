"""Tests for Ice SDK."""

