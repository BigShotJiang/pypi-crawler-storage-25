"""
Routing decision: maps Complexity → (provider, model).

If model_hint is a known model (in pricing table or alias registry) it is
treated as a preference hint and complexity routing is still applied on top.
Unknown model hints pass through unchanged.
No model → pure complexity routing.
"""
from __future__ import annotations

import logging

from routiq.adapters.registry import _REGISTRY, is_registered
from routiq.config import get_settings
from routiq.pipeline.alias import resolve
from routiq.pipeline.analyzer import Complexity

logger = logging.getLogger(__name__)


class NoProviderAvailable(Exception):
    """Raised when no adapter is registered for any model in a routing tier."""


def _resolve_tier(csv: str, tier_name: str) -> tuple[str, str]:
    """Pick the first model in a comma-separated list whose provider is registered.

    E.g. "gemini-flash-latest,claude-haiku-latest,gpt-4o-mini"
    → walks left-to-right, returns the first whose adapter key is set.
    Raises NoProviderAvailable when nothing in the tier is registered.
    """
    candidates = [c.strip() for c in csv.split(",") if c.strip()]
    for alias in candidates:
        model, provider = resolve(alias)
        if is_registered(provider):
            return model, provider
    registered = list(_REGISTRY.keys())
    logger.warning(
        "router: no registered adapter for %s tier candidates=%s registered=%s — request will fail",
        tier_name, candidates, registered,
    )
    raise NoProviderAvailable(
        f"No provider configured for {tier_name} tier. "
        f"Set one of: {candidates} via API key in .env"
    )


def _known_models() -> frozenset[str]:
    """Returns all models we recognise: pricing table keys + alias registry keys."""
    from routiq.pipeline.cost import _PRICING
    from routiq.pipeline.alias import _load
    return frozenset(_PRICING.keys()) | frozenset(_load().keys())


def route(
    complexity: Complexity,
    model_hint: str | None = None,
) -> tuple[str, str, str]:
    """Return (provider, model, reason).

    Three-tier routing:
      SIMPLE  → settings.simple_model   (cheapest)
      MEDIUM  → settings.medium_model   (mid-tier)
      COMPLEX → settings.complex_model  (most capable)

    When the user provides a model hint and it resolves to a lower tier than
    the request complexity demands, Routiq upgrades it silently.  It never
    downgrades an explicit hint (e.g. user asked for complex_model on a simple
    request — their preference is respected).
    """
    settings = get_settings()
    complex_model, complex_provider = _resolve_tier(settings.complex_model, "complex")
    medium_model, medium_provider   = _resolve_tier(settings.medium_model, "medium")
    simple_model, simple_provider   = _resolve_tier(settings.simple_model, "simple")

    if model_hint is not None:
        if model_hint not in _known_models():
            model, provider = resolve(model_hint)
            reason = "unknown_model_passthrough"
            logger.info(
                "routing decision complexity=%s model=%s provider=%s reason=%s",
                complexity.value, model, provider, reason,
            )
            return provider, model, reason

        hint_model, hint_provider = resolve(model_hint)

        # Upgrade if complexity demands a higher tier than the hint.
        if complexity == Complexity.COMPLEX and hint_model in (simple_model, medium_model):
            model, provider = complex_model, complex_provider
            reason = "complexity_complex"
        elif complexity == Complexity.MEDIUM and hint_model == simple_model:
            model, provider = medium_model, medium_provider
            reason = "complexity_medium"
        else:
            model, provider = hint_model, hint_provider
            reason = "hint_respected"

        logger.info(
            "routing decision complexity=%s model=%s provider=%s reason=%s",
            complexity.value, model, provider, reason,
        )
        return provider, model, reason

    # No hint — pure three-tier complexity routing
    if complexity == Complexity.COMPLEX:
        model, provider, reason = complex_model, complex_provider, "complexity_complex"
    elif complexity == Complexity.MEDIUM:
        model, provider, reason = medium_model, medium_provider, "complexity_medium"
    else:
        model, provider, reason = simple_model, simple_provider, "complexity_simple"

    logger.info(
        "routing decision complexity=%s model=%s provider=%s reason=%s",
        complexity.value, model, provider, reason,
    )
    return provider, model, reason
