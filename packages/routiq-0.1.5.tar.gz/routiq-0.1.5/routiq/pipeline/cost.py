"""
Token cost accounting with async SQLite persistence.

Pricing is per-million tokens.  cache_read gets a 90% discount;
cache_creation pays a 25% premium over the standard input rate.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

import aiosqlite

from routiq.adapters.base import TokenUsage
from routiq.config import get_settings

logger = logging.getLogger(__name__)

# (input_per_million, output_per_million)
# Prices last verified: 2026-05-23
# Sources:
#   OpenAI:    https://openai.com/api/pricing/
#   Anthropic: https://www.anthropic.com/pricing
#   Gemini:    https://ai.google.dev/gemini-api/docs/pricing
#   DeepSeek:  https://api-docs.deepseek.com/quick_start/pricing
_PRICING: dict[str, tuple[float, float]] = {
    # OpenAI — https://openai.com/api/pricing/
    "gpt-4o":                         (2.50,  10.00),
    "gpt-4o-2024-11-20":              (2.50,  10.00),
    "gpt-4o-mini":                    (0.15,   0.60),

    # Anthropic — https://www.anthropic.com/pricing
    "claude-sonnet-4-20250514":       (3.00,  15.00),
    "claude-haiku-4-5-20251001":      (1.00,   5.00),  # was 0.80/4.00

    # DeepSeek — https://api-docs.deepseek.com/quick_start/pricing
    # deepseek-chat and deepseek-reasoner now alias deepseek-v4-flash (non-thinking/thinking)
    "deepseek-chat":                  (0.14,   0.28),
    "deepseek-reasoner":              (0.14,   0.28),  # was 0.55/2.19; now same as chat
    "deepseek-coder":                 (0.14,   0.28),

    # Google Gemini — https://ai.google.dev/gemini-api/docs/pricing
    # gemini-2.5-pro uses ≤200k token tier; >200k is 2.50/15.00
    "gemini-2.5-flash":               (0.30,   2.50),  # was 0.15/0.60
    "gemini-2.5-flash-lite":          (0.10,   0.40),
    "gemini-2.5-pro":                 (1.25,  10.00),
    "gemini-2.0-flash":               (0.10,   0.40),
}

_CACHE_READ_MULTIPLIER       = 0.10   # 90% discount
_CACHE_CREATION_MULTIPLIER   = 1.25   # 25% premium

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS cost_records (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id       TEXT    NOT NULL,
    model            TEXT    NOT NULL,
    provider         TEXT    NOT NULL,
    complexity       TEXT    NOT NULL,
    input_tokens     INTEGER NOT NULL,
    output_tokens    INTEGER NOT NULL,
    cache_read_tokens    INTEGER NOT NULL DEFAULT 0,
    cache_creation_tokens INTEGER NOT NULL DEFAULT 0,
    input_cost       REAL    NOT NULL,
    output_cost      REAL    NOT NULL,
    cache_read_cost  REAL    NOT NULL,
    cache_creation_cost REAL NOT NULL,
    total_cost       REAL    NOT NULL,
    baseline_cost    REAL    NOT NULL,
    saved_cost       REAL    NOT NULL,
    cache_hit        INTEGER NOT NULL,
    routing_reason   TEXT    NOT NULL,
    latency_ms       REAL    NOT NULL,
    pipeline_ms      REAL,
    provider_ms      REAL,
    overhead_ms      REAL,
    created_at       TEXT    NOT NULL DEFAULT (datetime('now'))
)
"""


@dataclass
class CostBreakdown:
    input_cost: float
    output_cost: float
    cache_read_cost: float
    cache_creation_cost: float
    total_cost: float
    baseline_cost: float
    saved_cost: float


def _price_per_token(model: str) -> tuple[float, float]:
    """Return (input_price_per_token, output_price_per_token)."""
    base = model.split(":")[-1]  # strip any version suffix like "openai:gpt-4o"
    input_pm, output_pm = _PRICING.get(base, _PRICING.get(model, (2.50, 10.00)))
    return input_pm / 1_000_000, output_pm / 1_000_000


def calculate_cost(usage: TokenUsage, model: str) -> CostBreakdown:
    inp_rate, out_rate = _price_per_token(model)

    input_cost          = usage.input_tokens              * inp_rate
    output_cost         = usage.output_tokens             * out_rate
    cache_read_cost     = usage.cache_read_tokens         * inp_rate * _CACHE_READ_MULTIPLIER
    cache_creation_cost = usage.cache_creation_tokens     * inp_rate * _CACHE_CREATION_MULTIPLIER

    total_cost = input_cost + output_cost + cache_read_cost + cache_creation_cost

    return CostBreakdown(
        input_cost=input_cost,
        output_cost=output_cost,
        cache_read_cost=cache_read_cost,
        cache_creation_cost=cache_creation_cost,
        total_cost=total_cost,
        baseline_cost=total_cost,   # placeholder; caller sets real baseline via calculate_baseline
        saved_cost=0.0,             # placeholder; caller computes saved = baseline - total
    )


def calculate_baseline(usage: TokenUsage, requested_model: str, actual_model: str) -> float:
    """What the request would have cost at the user's originally requested model rates.

    Falls back to actual_model's rates when requested_model is not in _PRICING
    (e.g. an unknown or passthrough model).

    Routing savings:  requested=gpt-4o, actual=gpt-4o-mini → baseline >> total_cost
    Cache savings:    caller sets total_cost=0.0, so saved = full baseline amount
    """
    base = requested_model.split(":")[-1]
    if base in _PRICING or requested_model in _PRICING:
        bl_inp, bl_out = _price_per_token(requested_model)
    else:
        bl_inp, bl_out = _price_per_token(actual_model)

    all_tokens = usage.input_tokens + usage.cache_read_tokens + usage.cache_creation_tokens
    return all_tokens * bl_inp + usage.output_tokens * bl_out


async def init_db() -> None:
    path = get_settings().sqlite_path
    async with aiosqlite.connect(path) as db:
        await _ensure_table(db)


async def _ensure_table(db: aiosqlite.Connection) -> None:
    await db.execute(_CREATE_TABLE_SQL)
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_cost_created_at ON cost_records(created_at)"
    )
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_cost_model ON cost_records(model)"
    )
    # Migrate existing databases — ignore error if column already exists
    for col in ("pipeline_ms REAL", "provider_ms REAL", "overhead_ms REAL"):
        try:
            await db.execute(f"ALTER TABLE cost_records ADD COLUMN {col}")
        except Exception:
            pass
    await db.commit()


async def _delete_old_records() -> None:
    path = get_settings().sqlite_path
    try:
        async with aiosqlite.connect(path) as db:
            await db.execute(
                "DELETE FROM cost_records WHERE created_at < datetime('now', '-45 days')"
            )
            await db.commit()
        logger.info("cost.cleanup: deleted records older than 45 days")
    except Exception as exc:
        logger.error("cost.cleanup failed: %s", exc)


async def _cleanup_loop() -> None:
    while True:
        await asyncio.sleep(86400)  # 24 h
        await _delete_old_records()


async def start_cleanup_task() -> None:
    """Run once on startup, then prune daily. Call from lifespan."""
    await _delete_old_records()
    asyncio.create_task(_cleanup_loop())


async def record(
    request_id: str,
    model: str,
    provider: str,
    complexity: str,
    usage: TokenUsage,
    requested_model: str,
    input_cost: float,
    output_cost: float,
    cache_read_cost: float,
    cache_creation_cost: float,
    total_cost: float,
    baseline_cost: float,
    saved_cost: float,
    cache_hit: bool,
    routing_reason: str,
    latency_ms: float,
    pipeline_ms: float | None = None,
    provider_ms: float | None = None,
    overhead_ms: float | None = None,
) -> None:
    """Persist a cost record.  Caller is responsible for all cost calculations.

    For routing savings: baseline_cost uses requested_model rates, total_cost
    uses the actual routed model — saved = baseline - total.

    For cache hits: total_cost = 0.0 (no API spend), individual costs = 0.0,
    saved_cost = baseline_cost (the entire request was served for free).
    """
    path = get_settings().sqlite_path
    try:
        async with aiosqlite.connect(path) as db:
            await _ensure_table(db)
            await db.execute(
                """
                INSERT INTO cost_records (
                    request_id, model, provider, complexity,
                    input_tokens, output_tokens,
                    cache_read_tokens, cache_creation_tokens,
                    input_cost, output_cost,
                    cache_read_cost, cache_creation_cost,
                    total_cost, baseline_cost, saved_cost,
                    cache_hit, routing_reason, latency_ms,
                    pipeline_ms, provider_ms, overhead_ms
                ) VALUES (
                    ?, ?, ?, ?,
                    ?, ?,
                    ?, ?,
                    ?, ?,
                    ?, ?,
                    ?, ?, ?,
                    ?, ?, ?,
                    ?, ?, ?
                )
                """,
                (
                    request_id, model, provider, complexity,
                    usage.input_tokens, usage.output_tokens,
                    usage.cache_read_tokens, usage.cache_creation_tokens,
                    input_cost, output_cost,
                    cache_read_cost, cache_creation_cost,
                    total_cost, baseline_cost, saved_cost,
                    int(cache_hit), routing_reason, latency_ms,
                    pipeline_ms, provider_ms, overhead_ms,
                ),
            )
            await db.commit()
    except Exception as exc:
        logger.error("cost.record failed request_id=%s: %s", request_id, exc)
