"""
Single-request pipeline: alias → cache → analyze → route → adapter → cache write → cost record.
"""
from __future__ import annotations

import logging
import time
import uuid
from typing import Any

from routiq.adapters.base import NormalizedRequest, TokenUsage
from routiq.adapters.registry import get_adapter
from routiq.pipeline import alias, cache, analyzer, cost, router

logger = logging.getLogger(__name__)


async def process(raw_request: dict[str, Any]) -> tuple[dict[str, Any], str]:
    request_id = str(uuid.uuid4())
    t_start = time.monotonic()
    latency_ms = 0.0
    pipeline_ms = 0.0
    provider_ms = 0.0
    overhead_ms = 0.0

    try:
        messages: list[dict] = raw_request.get("messages", [])
        raw_model: str = raw_request.get("model", "")

        # ── 1. Alias resolution ───────────────────────────────────────────────
        # "auto" is the RoutiqClient sentinel meaning "let Routiq decide" — treat
        # it the same as an absent model field so complexity routing kicks in.
        _has_model = raw_model not in ("", "auto")
        resolved_model, resolved_provider = alias.resolve(raw_model) if _has_model else ("", "")

        # ── 2. Exact cache lookup ─────────────────────────────────────────────
        ck = cache.cache_key(resolved_model, messages)
        cached = await cache.get(ck)
        if cached is not None:
            pipeline_ms = (time.monotonic() - t_start) * 1000
            # total_cost = 0.0: no API call was made, nothing was spent.
            # baseline  = what this request would have cost at the user's
            # requested model, so saved = full baseline amount.
            cache_baseline = cost.calculate_baseline(
                cached.usage, raw_model or cached.model, cached.model
            )
            await cost.record(
                request_id=request_id,
                model=cached.model,
                provider=cached.provider,
                complexity="cached",
                usage=cached.usage,
                requested_model=raw_model or cached.model,
                input_cost=0.0,
                output_cost=0.0,
                cache_read_cost=0.0,
                cache_creation_cost=0.0,
                total_cost=0.0,
                baseline_cost=cache_baseline,
                saved_cost=cache_baseline,
                cache_hit=True,
                routing_reason="cache_hit",
                latency_ms=pipeline_ms,
                pipeline_ms=pipeline_ms,
                provider_ms=0.0,
                overhead_ms=0.0,
            )
            logger.info(
                "decision_trace request_id=%s cache_hit=true model=%s "
                "latency_ms=%.1f total_cost=%.6f saved_cost=%.6f",
                request_id, cached.model, pipeline_ms,
                0.0, cache_baseline,
            )
            return _to_openai_response(cached, request_id), request_id

        # ── 2b. Semantic cache lookup ─────────────────────────────────────────
        sem_cached = await cache.semantic_get(messages)
        if sem_cached is not None:
            pipeline_ms = (time.monotonic() - t_start) * 1000
            sem_baseline = cost.calculate_baseline(
                sem_cached.usage, raw_model or sem_cached.model, sem_cached.model
            )
            await cost.record(
                request_id=request_id,
                model=sem_cached.model,
                provider=sem_cached.provider,
                complexity="cached",
                usage=sem_cached.usage,
                requested_model=raw_model or sem_cached.model,
                input_cost=0.0,
                output_cost=0.0,
                cache_read_cost=0.0,
                cache_creation_cost=0.0,
                total_cost=0.0,
                baseline_cost=sem_baseline,
                saved_cost=sem_baseline,
                cache_hit=True,
                routing_reason="semantic_hit",
                latency_ms=pipeline_ms,
                pipeline_ms=pipeline_ms,
                provider_ms=0.0,
                overhead_ms=0.0,
            )
            logger.info(
                "decision_trace request_id=%s semantic_hit=true model=%s "
                "latency_ms=%.1f total_cost=%.6f saved_cost=%.6f",
                request_id, sem_cached.model, pipeline_ms,
                0.0, sem_baseline,
            )
            return _to_openai_response(sem_cached, request_id), request_id

        # ── 3. Complexity classification ──────────────────────────────────────
        # Rough token estimate: 1 token ≈ 4 chars (good enough for routing)
        token_count = sum(
            len(str(m.get("content", ""))) // 4
            for m in messages
        )
        complexity, complexity_reason = analyzer.classify(messages, token_count)

        # ── 4. Routing ────────────────────────────────────────────────────────
        # Pass raw_model so the router can check it against the known-models
        # list (which includes alias keys like "gpt-4o-latest" as well as
        # canonical names like "gpt-4o").
        provider, model, routing_reason = router.route(complexity, raw_model if _has_model else None)

        # ── 5. Adapter call ───────────────────────────────────────────────────
        norm_request = NormalizedRequest(
            model=model,
            messages=messages,
            max_tokens=raw_request.get("max_tokens"),
            temperature=raw_request.get("temperature"),
            tools=raw_request.get("tools"),
            stream=raw_request.get("stream", False),
        )
        t_provider_start = time.monotonic()
        response = await get_adapter(provider).complete(norm_request)
        t_provider_end = time.monotonic()

        # ── 6. Cache write ────────────────────────────────────────────────────
        await cache.set(ck, response)
        await cache.semantic_set(messages, response)
        t_end = time.monotonic()

        pipeline_ms = (t_provider_start - t_start) * 1000
        provider_ms = (t_provider_end - t_provider_start) * 1000
        overhead_ms = (t_end - t_provider_end) * 1000
        latency_ms  = pipeline_ms + provider_ms + overhead_ms

        # ── 7. Cost record ────────────────────────────────────────────────────
        # total_cost: actual spend at the routed model's rates.
        # baseline_cost: what the user would have paid at their requested model's
        # rates -- captures routing savings (e.g. gpt-4o -> gpt-4o-mini).
        cost_breakdown = cost.calculate_cost(response.usage, model)
        baseline = cost.calculate_baseline(response.usage, raw_model or model, model)
        routing_saved = max(0.0, baseline - cost_breakdown.total_cost)
        await cost.record(
            request_id=request_id,
            model=model,
            provider=provider,
            complexity=complexity.value,
            usage=response.usage,
            requested_model=raw_model or model,
            input_cost=cost_breakdown.input_cost,
            output_cost=cost_breakdown.output_cost,
            cache_read_cost=cost_breakdown.cache_read_cost,
            cache_creation_cost=cost_breakdown.cache_creation_cost,
            total_cost=cost_breakdown.total_cost,
            baseline_cost=baseline,
            saved_cost=routing_saved,
            cache_hit=False,
            routing_reason=routing_reason,
            latency_ms=latency_ms,
            pipeline_ms=pipeline_ms,
            provider_ms=provider_ms,
            overhead_ms=overhead_ms,
        )

        # ── Decision trace ────────────────────────────────────────────────────
        logger.info(
            "decision_trace request_id=%s cache_hit=false "
            "complexity=%s complexity_reason=%s "
            "routing_reason=%s model=%s provider=%s "
            "input_tokens=%d output_tokens=%d "
            "latency_ms=%.1f pipeline_ms=%.1f provider_ms=%.1f overhead_ms=%.1f "
            "total_cost=%.6f saved_cost=%.6f",
            request_id, complexity.value, complexity_reason,
            routing_reason, model, provider,
            response.usage.input_tokens, response.usage.output_tokens,
            latency_ms, pipeline_ms, provider_ms, overhead_ms,
            cost_breakdown.total_cost, routing_saved,
        )

        # ── 8. OpenAI-compatible response ─────────────────────────────────────
        return _to_openai_response(response, request_id), request_id

    except Exception as exc:
        logger.error("pipeline error request_id=%s: %s", request_id, exc, exc_info=True)
        raise


def _to_openai_response(response, request_id: str) -> dict[str, Any]:
    return {
        "id": f"chatcmpl-{request_id}",
        "object": "chat.completion",
        "model": response.model,
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": response.content},
                "finish_reason": response.finish_reason,
            }
        ],
        "usage": {
            "prompt_tokens": response.usage.input_tokens,
            "completion_tokens": response.usage.output_tokens,
            "total_tokens": response.usage.input_tokens + response.usage.output_tokens,
        },
    }
