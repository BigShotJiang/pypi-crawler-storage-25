"""
Heuristic complexity classifier — no ML, no embeddings.

Rules are applied in order; first match wins.
"""
from __future__ import annotations

from enum import Enum
from typing import Any

COMPLEX_KEYWORDS = frozenset({
    "analyze", "compare", "explain", "debug", "refactor",
    "architecture", "design", "optimize", "research",
    "summarize", "write code", "implement",
})


class Complexity(str, Enum):
    SIMPLE = "simple"
    MEDIUM = "medium"
    COMPLEX = "complex"


def classify(messages: list[dict[str, Any]], token_count: int) -> tuple[Complexity, str]:
    """Return (Complexity, reason) for the given messages and token count."""

    # Rule 1 — tool use present
    for msg in messages:
        if "tool_use" in msg or "tools" in msg:
            return Complexity.COMPLEX, "tool_use_present"
        content = msg.get("content")
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    return Complexity.COMPLEX, "tool_use_present"

    # Rule 2 — large token count
    if token_count > 2000:
        return Complexity.COMPLEX, "token_count_gt_2000"

    # Rule 3 — medium token count
    if token_count > 800:
        return Complexity.MEDIUM, "token_count_gt_800"

    # Rule 4 — complexity keyword in any message content
    for msg in messages:
        content = msg.get("content", "")
        if isinstance(content, str):
            text = content.lower()
            for kw in COMPLEX_KEYWORDS:
                if kw in text:
                    return Complexity.COMPLEX, f"keyword:{kw}"
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, dict):
                    text = block.get("text", "").lower()
                    for kw in COMPLEX_KEYWORDS:
                        if kw in text:
                            return Complexity.COMPLEX, f"keyword:{kw}"

    return Complexity.SIMPLE, "default"
