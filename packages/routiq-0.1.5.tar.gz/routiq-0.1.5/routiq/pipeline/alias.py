"""
Model alias resolver.

Reads models.yml on first call and on every call if the file's mtime has
changed since the last read — no background threads, no watchfiles dependency.
"""
from __future__ import annotations

import importlib.resources as _pkg_resources
import os
import time
from typing import Any

import yaml

from routiq.config import get_settings

_cache: dict[str, Any] = {}        # parsed YAML aliases dict
_mtime: float = 0.0                 # mtime of last successful read
_last_checked: float = float("-inf")  # guarantees first call always reads the file
_CHECK_INTERVAL_S: float = 1.0     # re-stat at most once per second


def _find_models_path() -> str:
    """Package-bundled models.yml first; configured path (cwd) as fallback."""
    try:
        ref = _pkg_resources.files("routiq").joinpath("models.yml")
        path = str(ref)
        if os.path.exists(path):
            return path
    except Exception:
        pass
    return get_settings().models_yaml_path


def _load() -> dict[str, Any]:
    """Return aliases dict, re-reading from disk when mtime changes."""
    global _cache, _mtime, _last_checked

    now = time.monotonic()
    if now - _last_checked >= _CHECK_INTERVAL_S:
        _last_checked = now
        path = _find_models_path()
        try:
            current_mtime = os.path.getmtime(path)
        except OSError:
            return _cache  # file absent — keep whatever we had

        if current_mtime != _mtime:
            with open(path, "r") as fh:
                data = yaml.safe_load(fh) or {}
            _cache = data.get("aliases", {})
            _mtime = current_mtime

    return _cache


def infer_provider(model: str) -> str:
    if model.startswith(("gpt-", "o1", "o3")):
        return "openai"
    if model.startswith("claude-"):
        return "anthropic"
    raise ValueError(f"Cannot infer provider for model '{model}' — add it to models.yml")


def resolve(alias: str) -> tuple[str, str]:
    """Return (model, provider) for *alias*, reading models.yml if stale."""
    aliases = _load()
    if alias in aliases:
        entry = aliases[alias]
        return entry["model"], entry["provider"]
    return alias, infer_provider(alias)
