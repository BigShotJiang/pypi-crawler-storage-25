"""
Redis exact-match response cache + semantic similarity cache.

Both layers are fail-open: any error is logged and treated as a miss so
the request continues to the upstream provider.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import re
import time
from typing import Any

import redis.asyncio as aioredis

from routiq.adapters.base import NormalizedResponse, TokenUsage
from routiq.config import get_settings

logger = logging.getLogger(__name__)

_client: aioredis.Redis | None = None
_redis_available: bool = True
_redis_warned: bool = False


def is_redis_available() -> bool:
    return _redis_available


def _mark_redis_unavailable(exc: Exception) -> None:
    global _redis_available, _redis_warned
    _redis_available = False
    if not _redis_warned:
        _redis_warned = True
        logger.warning("Redis unavailable — cache disabled: %s", exc)


def _get_client() -> aioredis.Redis:
    global _client
    if _client is None:
        _client = aioredis.from_url(
            get_settings().redis_url,
            decode_responses=True,
            socket_connect_timeout=2,
        )
    return _client


def cache_key(model: str, messages: list[dict]) -> str:
    norm_model = model.lower().strip()
    norm_messages = [
        {**m, "content": re.sub(r" +", " ", str(m.get("content", "")).lower().strip())}
        for m in messages
    ]
    payload = json.dumps({"model": norm_model, "messages": norm_messages}, sort_keys=True)
    return "routiq:cache:" + hashlib.sha256(payload.encode()).hexdigest()


async def get(key: str) -> NormalizedResponse | None:
    try:
        raw = await _get_client().get(key)
    except Exception as exc:
        _mark_redis_unavailable(exc)
        return None

    if raw is None:
        return None

    try:
        data = json.loads(raw)
        usage = TokenUsage(**data["usage"])
        return NormalizedResponse(
            content=data["content"],
            model=data["model"],
            usage=usage,
            finish_reason=data["finish_reason"],
            provider=data["provider"],
            raw=data.get("raw", {}),
        )
    except Exception as exc:
        logger.warning("cache.get deserialise failed: %s", exc)
        return None


async def set(key: str, response: NormalizedResponse, ttl: int = 3600) -> None:
    try:
        payload = json.dumps({
            "content": response.content,
            "model": response.model,
            "finish_reason": response.finish_reason,
            "provider": response.provider,
            "raw": response.raw,
            "usage": {
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
                "cache_read_tokens": response.usage.cache_read_tokens,
                "cache_creation_tokens": response.usage.cache_creation_tokens,
            },
        })
        await _get_client().setex(key, ttl, payload)
    except Exception as exc:
        _mark_redis_unavailable(exc)


# ── Semantic cache ────────────────────────────────────────────────────────────

_sem_model: Any = None  # SentenceTransformer | None

_SEM_ENTRY_KEY = "semantic:{}:{}"   # user_id, entry_hash
_SEM_IDX_KEY   = "semantic:{}:_idx" # user_id  (sorted set, score = timestamp)


async def init_semantic_cache() -> None:
    global _sem_model
    logger.info("init_semantic_cache: STARTING")
    if not get_settings().semantic_cache_enabled:
        logger.info("semantic cache: disabled via SEMANTIC_CACHE_ENABLED")
        return
    try:
        from sentence_transformers import SentenceTransformer
        loop = asyncio.get_event_loop()
        model = await loop.run_in_executor(None, lambda: SentenceTransformer("all-MiniLM-L6-v2"))
        # Warmup: PyTorch JIT-compiles on first encode; doing it here means the
        # 50ms timeout in _embed() won't fire on the first real request.
        await loop.run_in_executor(None, lambda: model.encode("warmup"))
        _sem_model = model
        logger.info("init_semantic_cache: DONE, model_loaded=%s", _sem_model is not None)
    except Exception as exc:
        logger.error("init_semantic_cache FAILED: %s", exc, exc_info=True)
        _sem_model = None


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na  = math.sqrt(sum(x * x for x in a))
    nb  = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


def _last_user_text(messages: list[dict]) -> str:
    for m in reversed(messages):
        if m.get("role") == "user":
            return str(m.get("content", "")).strip()
    return ""


async def _embed(text: str) -> list[float] | None:
    if _sem_model is None:
        return None
    timeout_s = get_settings().semantic_timeout_ms / 1000.0
    t0 = time.monotonic()
    try:
        loop = asyncio.get_running_loop()
        fut  = loop.run_in_executor(None, lambda: _sem_model.encode(text).tolist())
        # asyncio.shield keeps the thread running if we time out — no zombie futures
        return await asyncio.wait_for(asyncio.shield(fut), timeout=timeout_s)
    except asyncio.TimeoutError:
        elapsed_ms = round((time.monotonic() - t0) * 1000)
        logger.warning(
            "semantic cache: embedding timeout %dms for len=%d", elapsed_ms, len(text)
        )
        return None
    except Exception as exc:
        logger.warning("semantic cache: embed failed: %s", exc)
        return None


def _deserialise_response(resp_data: dict) -> NormalizedResponse:
    return NormalizedResponse(
        content=resp_data["content"],
        model=resp_data["model"],
        usage=TokenUsage(**resp_data["usage"]),
        finish_reason=resp_data["finish_reason"],
        provider=resp_data["provider"],
        raw=resp_data.get("raw", {}),
    )


def _serialise_response(response: NormalizedResponse) -> dict:
    return {
        "content":      response.content,
        "model":        response.model,
        "finish_reason": response.finish_reason,
        "provider":     response.provider,
        "raw":          response.raw,
        "usage": {
            "input_tokens":          response.usage.input_tokens,
            "output_tokens":         response.usage.output_tokens,
            "cache_read_tokens":     response.usage.cache_read_tokens,
            "cache_creation_tokens": response.usage.cache_creation_tokens,
        },
    }


async def semantic_get(
    messages: list[dict],
    user_id: str = "default",
) -> NormalizedResponse | None:
    if _sem_model is None or not get_settings().semantic_cache_enabled:
        return None

    text = _last_user_text(messages)
    if not text:
        return None

    query_vec = await _embed(text)
    if query_vec is None:
        return None

    idx_key = _SEM_IDX_KEY.format(user_id)
    try:
        members = await _get_client().zrange(idx_key, 0, -1)
        if not members:
            return None

        keys   = [_SEM_ENTRY_KEY.format(user_id, m) for m in members]
        values = await _get_client().mget(*keys)

        threshold = get_settings().semantic_threshold
        best_sim  = 0.0
        best_hit  = None
        for member, raw in zip(members, values):
            if raw is None:
                await _get_client().zrem(idx_key, member)
                continue
            try:
                data = json.loads(raw)
                sim  = _cosine(query_vec, data["embedding"])
                if sim > best_sim:
                    best_sim = sim
                if sim >= threshold:
                    best_hit = (member, data)
                    break
            except Exception as exc:
                logger.warning("semantic cache: deserialise failed: %s", exc)

        logger.info(
            "semantic search: query='%s' entries=%d best_sim=%.3f threshold=%.2f hit=%s",
            text[:50], len(members), best_sim, threshold, best_hit is not None,
        )

        if best_hit is not None:
            member, data = best_hit
            await _get_client().zadd(idx_key, {member: time.time()})  # LRU touch
            return _deserialise_response(data["response"])

    except Exception as exc:
        _mark_redis_unavailable(exc)

    return None


async def semantic_set(
    messages: list[dict],
    response: NormalizedResponse,
    user_id: str = "default",
    ttl: int = 3600,
) -> None:
    if _sem_model is None or not get_settings().semantic_cache_enabled:
        return

    text = _last_user_text(messages)
    if not text:
        return

    vec = await _embed(text)
    if vec is None:
        return

    entry_hash = hashlib.sha256(text.encode()).hexdigest()[:16]
    entry_key  = _SEM_ENTRY_KEY.format(user_id, entry_hash)
    idx_key    = _SEM_IDX_KEY.format(user_id)

    try:
        payload = json.dumps({
            "embedding": vec,
            "response":  _serialise_response(response),
            "ts":        time.time(),
        })
        pipe = _get_client().pipeline()
        pipe.setex(entry_key, ttl, payload)
        pipe.zadd(idx_key, {entry_hash: time.time()})
        pipe.expire(idx_key, ttl)
        limit = get_settings().semantic_cache_limit
        if limit > 0:
            # Keep the `limit` newest entries; remove older overflow
            pipe.zremrangebyrank(idx_key, 0, -(limit + 1))
        await pipe.execute()
    except Exception as exc:
        _mark_redis_unavailable(exc)
