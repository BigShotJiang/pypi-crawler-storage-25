"""
Shared adapter contracts and retry machinery.

Retry policy: max 3 attempts, exponential backoff with one-directional jitter
(never early), only on 429 / 503.

Concrete adapters implement _call(); complete() wraps it with retry.
"""
from __future__ import annotations

import asyncio
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

_MAX_ATTEMPTS = 3
_BASE_DELAY_S = 0.2   # attempt 1 → ~200 ms
_MAX_DELAY_S = 8.0    # ceiling before jitter
_RETRYABLE = frozenset({429, 503})


@dataclass
class NormalizedRequest:
    model: str
    messages: list[dict[str, Any]]
    max_tokens: int | None = None
    temperature: float | None = None
    tools: list[dict[str, Any]] | None = None
    stream: bool = False


@dataclass
class TokenUsage:
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int = 0      # billed at 10 % of input rate
    cache_creation_tokens: int = 0  # billed at 125 % of input rate


@dataclass
class NormalizedResponse:
    content: str | None
    model: str
    usage: TokenUsage
    finish_reason: str | None
    provider: str
    raw: dict[str, Any] = field(default_factory=dict)


class ProviderError(Exception):
    """Raised by adapters for any non-2xx response from a provider."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(message)


def _backoff_s(attempt: int) -> float:
    """Exponential backoff with one-directional jitter (never early)."""
    delay = min(_MAX_DELAY_S, _BASE_DELAY_S * (2 ** (attempt - 1)))
    return delay + random.uniform(0, delay * 0.2)


class LLMAdapter(ABC):
    @property
    @abstractmethod
    def provider(self) -> str: ...

    @abstractmethod
    async def _call(self, request: NormalizedRequest) -> NormalizedResponse: ...

    @abstractmethod
    async def count_tokens(self, request: NormalizedRequest) -> int: ...

    async def complete(self, request: NormalizedRequest) -> NormalizedResponse:
        for attempt in range(1, _MAX_ATTEMPTS + 1):
            try:
                return await self._call(request)
            except ProviderError as exc:
                if exc.status_code not in _RETRYABLE or attempt == _MAX_ATTEMPTS:
                    raise
                await asyncio.sleep(_backoff_s(attempt))
        raise RuntimeError("unreachable")  # pragma: no cover
