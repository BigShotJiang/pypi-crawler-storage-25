"""Mock adapter — returns fake responses without any network calls."""
from __future__ import annotations

import asyncio
import random

from routiq.adapters.base import (
    LLMAdapter,
    NormalizedRequest,
    NormalizedResponse,
    TokenUsage,
)


class MockAdapter(LLMAdapter):
    @property
    def provider(self) -> str:
        return "mock"

    async def _call(self, request: NormalizedRequest) -> NormalizedResponse:
        await asyncio.sleep(random.uniform(0.05, 0.3))
        return NormalizedResponse(
            content="Hello! I am a mock response.",
            model=request.model,
            provider="mock",
            usage=TokenUsage(
                input_tokens=10,
                output_tokens=8,
                cache_read_tokens=0,
                cache_creation_tokens=0,
            ),
            finish_reason="stop",
        )

    async def count_tokens(self, request: NormalizedRequest) -> int:
        return len(request.messages) * 10
