"""DeepSeek adapter — OpenAI-compatible SDK, tiktoken for token counting."""
from __future__ import annotations

from typing import Any

import openai
import tiktoken
from openai import AsyncOpenAI

from routiq.adapters.base import (
    LLMAdapter,
    NormalizedRequest,
    NormalizedResponse,
    ProviderError,
    TokenUsage,
)

_ENC = tiktoken.get_encoding("cl100k_base")


class DeepSeekAdapter(LLMAdapter):
    def __init__(self, api_key: str) -> None:
        self._client = AsyncOpenAI(
            api_key=api_key,
            base_url="https://api.deepseek.com",
        )

    @property
    def provider(self) -> str:
        return "deepseek"

    async def _call(self, request: NormalizedRequest) -> NormalizedResponse:
        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": request.messages,
        }
        if request.max_tokens is not None:
            kwargs["max_tokens"] = request.max_tokens
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature
        if request.tools:
            kwargs["tools"] = request.tools

        try:
            response = await self._client.chat.completions.create(**kwargs)
        except openai.RateLimitError as exc:
            raise ProviderError(429, str(exc)) from exc
        except openai.APIStatusError as exc:
            raise ProviderError(exc.status_code, str(exc)) from exc

        choice = response.choices[0]
        usage_obj = response.usage

        cache_read = 0
        if usage_obj and usage_obj.prompt_tokens_details:
            cache_read = getattr(usage_obj.prompt_tokens_details, "cached_tokens", 0) or 0

        usage = TokenUsage(
            input_tokens=usage_obj.prompt_tokens if usage_obj else 0,
            output_tokens=usage_obj.completion_tokens if usage_obj else 0,
            cache_read_tokens=cache_read,
        )

        return NormalizedResponse(
            content=choice.message.content,
            model=response.model,
            usage=usage,
            finish_reason=choice.finish_reason,
            provider="deepseek",
            raw=response.model_dump(),
        )

    async def count_tokens(self, request: NormalizedRequest) -> int:
        total = 0
        for msg in request.messages:
            total += 3
            content = msg.get("content") or ""
            if isinstance(content, str):
                total += len(_ENC.encode(content))
            total += len(_ENC.encode(msg.get("role", "")))
        total += 3
        return total
