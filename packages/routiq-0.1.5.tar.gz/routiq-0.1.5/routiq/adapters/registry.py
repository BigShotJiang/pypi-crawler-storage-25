"""Provider adapter registry.

Call init_adapters() once at startup.  Adding a third provider later:
  1. import the adapter class
  2. add one _REGISTRY line in init_adapters()
"""
from __future__ import annotations

import logging

from routiq.adapters.anthropic import AnthropicAdapter
from routiq.adapters.base import LLMAdapter
from routiq.adapters.deepseek import DeepSeekAdapter
from routiq.adapters.gemini import GeminiAdapter
from routiq.adapters.mock import MockAdapter
from routiq.adapters.openai import OpenAIAdapter
from routiq.config import get_settings

_REGISTRY: dict[str, LLMAdapter] = {}

_log = logging.getLogger(__name__)


def init_adapters() -> None:
    settings = get_settings()
    if settings.routiq_mock_mode:
        _REGISTRY["openai"] = MockAdapter()
        _REGISTRY["anthropic"] = MockAdapter()
        _log.info("MOCK MODE — no real API calls will be made")
        return
    if settings.openai_api_key:
        _REGISTRY["openai"] = OpenAIAdapter(settings.openai_api_key)
        _log.info("OpenAI adapter registered")
    if settings.anthropic_api_key:
        _REGISTRY["anthropic"] = AnthropicAdapter(settings.anthropic_api_key)
        _log.info("Anthropic adapter registered")
    if settings.deepseek_api_key:
        _REGISTRY["deepseek"] = DeepSeekAdapter(settings.deepseek_api_key)
        _log.info("DeepSeek adapter registered")
    if settings.gemini_api_key:
        _REGISTRY["gemini"] = GeminiAdapter(settings.gemini_api_key)
        _log.info("Gemini adapter registered")


def is_registered(provider: str) -> bool:
    return provider in _REGISTRY


def get_adapter(provider: str) -> LLMAdapter:
    if not _REGISTRY:
        raise RuntimeError("Adapters not initialised — call init_adapters() at startup")
    try:
        return _REGISTRY[provider]
    except KeyError:
        raise KeyError(f"No adapter registered for provider '{provider}'")
