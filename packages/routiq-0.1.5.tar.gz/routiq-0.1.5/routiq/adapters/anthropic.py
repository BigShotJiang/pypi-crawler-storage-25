"""Anthropic adapter — uses AsyncAnthropic SDK.

System message is split from the messages list before every API call because
Anthropic's API requires it as a top-level field, not a role in the array.

count_tokens() calls client.messages.count_tokens() — a real API round-trip,
not a local character-count approximation.
"""
from __future__ import annotations

from typing import Any

import anthropic as _anthropic
from anthropic import AsyncAnthropic

from routiq.adapters.base import (
    LLMAdapter,
    NormalizedRequest,
    NormalizedResponse,
    ProviderError,
    TokenUsage,
)


class AnthropicAdapter(LLMAdapter):
    def __init__(self, api_key: str) -> None:
        self._client = AsyncAnthropic(api_key=api_key)

    @property
    def provider(self) -> str:
        return "anthropic"

    async def _call(self, request: NormalizedRequest) -> NormalizedResponse:
        system, messages = _split_system(request.messages)

        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": messages,
            "max_tokens": request.max_tokens or 4096,
        }
        if system:
            kwargs["system"] = system
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature
        if request.tools:
            kwargs["tools"] = request.tools

        try:
            response = await self._client.messages.create(**kwargs)
        except _anthropic.RateLimitError as exc:
            raise ProviderError(429, str(exc)) from exc
        except _anthropic.APIStatusError as exc:
            raise ProviderError(exc.status_code, str(exc)) from exc

        text = "".join(b.text for b in response.content if b.type == "text") or None

        u = response.usage
        usage = TokenUsage(
            input_tokens=u.input_tokens,
            output_tokens=u.output_tokens,
            cache_read_tokens=getattr(u, "cache_read_input_tokens", 0) or 0,
            cache_creation_tokens=getattr(u, "cache_creation_input_tokens", 0) or 0,
        )

        return NormalizedResponse(
            content=text,
            model=response.model,
            usage=usage,
            finish_reason=response.stop_reason,  # "end_turn" | "tool_use" | "max_tokens" | ...
            provider="anthropic",
            raw=response.model_dump(),
        )

    async def count_tokens(self, request: NormalizedRequest) -> int:
        system, messages = _split_system(request.messages)

        kwargs: dict[str, Any] = {
            "model": request.model,
            "messages": messages,
        }
        if system:
            kwargs["system"] = system
        if request.tools:
            kwargs["tools"] = request.tools

        try:
            result = await self._client.messages.count_tokens(**kwargs)
        except _anthropic.RateLimitError as exc:
            raise ProviderError(429, str(exc)) from exc
        except _anthropic.APIStatusError as exc:
            raise ProviderError(exc.status_code, str(exc)) from exc

        return result.input_tokens


def _split_system(
    messages: list[dict[str, Any]],
) -> tuple[str | None, list[dict[str, Any]]]:
    system = next((m["content"] for m in messages if m.get("role") == "system"), None)
    rest = [m for m in messages if m.get("role") != "system"]
    return system, rest
