"""
Routiq gateway settings loaded once from environment / .env file.
All variables are read as-is (no env_prefix) so names match exactly what is
documented in .env.example.
"""
from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Auth
    routiq_api_key: str = Field(..., description="Bearer token that callers must send")

    # Upstream providers (optional in mock mode)
    openai_api_key: str = Field(default="", description="OpenAI API key")
    anthropic_api_key: str = Field(default="", description="Anthropic API key")
    deepseek_api_key: str = Field(default="", description="DeepSeek API key")
    gemini_api_key: str = Field(default="", description="Gemini API key")

    # Storage
    redis_url: str = Field(default="redis://localhost:6379", description="Redis DSN")
    sqlite_path: str = Field(default="./routiq.db", description="SQLite database path")

    # Testing
    routiq_mock_mode: bool = Field(default=False, description="Return fake responses; no real API calls")

    # Observability
    log_level: str = Field(default="INFO", description="Python logging level")

    # Model aliases (legacy two-tier — kept for backwards compat)
    default_cheap_model: str = Field(default="gpt-4o-mini", description="Alias for the cost-optimised model")
    default_smart_model: str = Field(default="gpt-4o", description="Alias for the high-capability model")
    models_yaml_path: str = Field(default="./models.yml", description="Path to the model alias registry YAML")

    # Three-tier routing slots — override these to route across providers
    simple_model: str = Field(default="gpt-4o-mini", description="Model for SIMPLE requests")
    medium_model: str = Field(default="gpt-4o-mini", description="Model for MEDIUM requests")
    complex_model: str = Field(default="gpt-4o", description="Model for COMPLEX requests")

    # Semantic cache
    semantic_cache_enabled: bool = Field(default=True, description="Enable semantic similarity caching (SEMANTIC_CACHE_ENABLED=false to disable)")
    semantic_cache_limit: int = Field(default=100, description="Max cached entries per user; 0 = unlimited")
    semantic_threshold: float = Field(default=0.82, description="Cosine similarity threshold for a semantic hit (SEMANTIC_THRESHOLD env var)")
    semantic_timeout_ms: int = Field(default=250, description="Max ms to wait for an embedding before treating as a miss (SEMANTIC_TIMEOUT_MS env var)")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
