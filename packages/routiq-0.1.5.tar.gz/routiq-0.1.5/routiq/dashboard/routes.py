import os
from pathlib import Path

import aiosqlite
from fastapi import APIRouter, Query
from fastapi.responses import FileResponse, JSONResponse

from routiq.config import get_settings
import routiq.pipeline.cache as _cache
from routiq.pipeline.cache import _SEM_IDX_KEY, _get_client, is_redis_available

router = APIRouter()

_STATIC = Path(__file__).parent / "static"

_EMPTY_STATS = {
    "total_requests": 0,
    "cache_hits": 0,
    "semantic_hits": 0,
    "cache_hit_rate": 0.0,
    "total_cost_usd": 0.0,
    "total_saved_usd": 0.0,
    "savings_percent": 0.0,
    "latency": {"p50": 0.0, "p95": 0.0, "p99": 0.0},
    "requests_by_model": {},
    "requests_by_complexity": {},
    "recent_requests": [],
}


@router.get("/debug/semantic")
async def debug_semantic() -> JSONResponse:
    settings = get_settings()
    redis_ok = is_redis_available()
    stored_count = 0
    if redis_ok:
        try:
            keys = await _get_client().keys("semantic:*:_idx")
            for k in keys:
                stored_count += await _get_client().zcard(k)
        except Exception:
            pass
    return JSONResponse({
        "model_loaded": _cache._sem_model is not None,
        "redis_connected": redis_ok,
        "threshold": settings.semantic_threshold,
        "stored_count": stored_count,
        "enabled": settings.semantic_cache_enabled,
    })


@router.get("/dashboard")
async def dashboard() -> FileResponse:
    return FileResponse(_STATIC / "index.html")


_WINDOW_OFFSETS: dict[str, str | None] = {
    "24h": "-24 hours",
    "7d":  "-7 days",
    "30d": "-30 days",
    "all": None,
}


def _time_filter(window: str) -> str:
    """Return a SQL boolean expression for the requested time window."""
    offset = _WINDOW_OFFSETS.get(window, "-24 hours")
    if offset is None:
        return "1=1"
    return f"created_at >= datetime('now', '{offset}')"


@router.get("/api/stats")
async def api_stats(window: str = Query("24h")) -> JSONResponse:
    redis_ok = is_redis_available()
    path = get_settings().sqlite_path
    tf = _time_filter(window)

    if not os.path.exists(path):
        return JSONResponse({
            **_EMPTY_STATS,
            "redis_available": redis_ok,
            "cache_hit_rate": None if not redis_ok else 0.0,
        })

    async with aiosqlite.connect(path) as db:
        db.row_factory = aiosqlite.Row

        async with db.execute(f"""
            SELECT
                COUNT(*) AS total_requests,
                SUM(CASE WHEN routing_reason = 'cache_hit'    THEN 1 ELSE 0 END) AS cache_hits,
                SUM(CASE WHEN routing_reason = 'semantic_hit' THEN 1 ELSE 0 END) AS semantic_hits,
                SUM(total_cost)    AS total_cost_usd,
                SUM(saved_cost)    AS total_saved_usd,
                SUM(baseline_cost) AS total_baseline
            FROM cost_records
            WHERE {tf}
        """) as cur:
            summary = await cur.fetchone()

        if not summary or not summary["total_requests"]:
            return JSONResponse({
                **_EMPTY_STATS,
                "redis_available": redis_ok,
                "cache_hit_rate": None if not redis_ok else 0.0,
            })

        total         = summary["total_requests"]
        hits          = summary["cache_hits"] or 0
        semantic_hits = summary["semantic_hits"] or 0
        total_cost    = summary["total_cost_usd"] or 0.0
        total_saved   = summary["total_saved_usd"] or 0.0
        baseline      = summary["total_baseline"] or 0.0

        async with db.execute(f"""
            WITH overhead AS (
                SELECT (COALESCE(pipeline_ms, 0) + COALESCE(overhead_ms, 0)) AS ms
                FROM cost_records
                WHERE {tf}
            )
            SELECT
                COALESCE((
                    SELECT ms FROM overhead ORDER BY ms LIMIT 1
                    OFFSET (SELECT MAX(0, (COUNT(*) - 1) / 2) FROM overhead)
                ), 0) AS p50_ms,
                COALESCE((
                    SELECT ms FROM overhead ORDER BY ms LIMIT 1
                    OFFSET (SELECT MAX(0, COUNT(*) * 95 / 100 - 1) FROM overhead)
                ), 0) AS p95_ms,
                COALESCE((
                    SELECT ms FROM overhead ORDER BY ms LIMIT 1
                    OFFSET (SELECT MAX(0, COUNT(*) * 99 / 100 - 1) FROM overhead)
                ), 0) AS p99_ms
            FROM overhead LIMIT 1
        """) as cur:
            pct = await cur.fetchone()
        latency = {
            "p50": round((pct["p50_ms"] or 0.0) if pct else 0.0, 1),
            "p95": round((pct["p95_ms"] or 0.0) if pct else 0.0, 1),
            "p99": round((pct["p99_ms"] or 0.0) if pct else 0.0, 1),
        }

        by_model: dict = {}
        async with db.execute(f"""
            SELECT model, COUNT(*) AS cnt, SUM(total_cost) AS cost_usd
            FROM cost_records
            WHERE {tf}
            GROUP BY model
            ORDER BY cnt DESC
            LIMIT 20
        """) as cur:
            async for row in cur:
                by_model[row["model"]] = {
                    "count":    row["cnt"],
                    "cost_usd": round(row["cost_usd"] or 0.0, 6),
                }

        by_complexity: dict = {}
        async with db.execute(f"""
            SELECT complexity, COUNT(*) AS cnt
            FROM cost_records
            WHERE {tf}
            GROUP BY complexity
        """) as cur:
            async for row in cur:
                by_complexity[row["complexity"]] = row["cnt"]

        # Recent requests always show the last 50 regardless of window
        recent: list = []
        async with db.execute("""
            SELECT request_id, model, provider,
                   CASE WHEN complexity = 'cached' THEN NULL ELSE complexity END AS complexity,
                   cache_hit, routing_reason, total_cost, saved_cost,
                   latency_ms, pipeline_ms, provider_ms, overhead_ms, created_at
            FROM cost_records
            ORDER BY created_at DESC
            LIMIT 50
        """) as cur:
            async for row in cur:
                recent.append({
                    "request_id":    row["request_id"],
                    "model":         row["model"],
                    "provider":      row["provider"],
                    "complexity":    row["complexity"],
                    "cache_hit":     bool(row["cache_hit"]),
                    "routing_reason": row["routing_reason"],
                    "total_cost_usd": row["total_cost"],
                    "saved_cost_usd": row["saved_cost"],
                    "latency_ms":    row["latency_ms"],
                    "pipeline_ms":   row["pipeline_ms"],
                    "provider_ms":   row["provider_ms"],
                    "overhead_ms":   row["overhead_ms"],
                    "created_at":    row["created_at"],
                })

    total_cache_hits = hits + semantic_hits
    return JSONResponse({
        "total_requests":        total,
        "cache_hits":            hits,
        "semantic_hits":         semantic_hits,
        "cache_hit_rate":        (total_cache_hits / total if total else 0.0) if redis_ok else None,
        "total_cost_usd":        total_cost,
        "total_saved_usd":       total_saved,
        "savings_percent":       (total_saved / baseline * 100) if baseline else 0.0,
        "latency":               latency,
        "requests_by_model":     by_model,
        "requests_by_complexity": by_complexity,
        "recent_requests":       recent,
        "redis_available":       redis_ok,
    })
