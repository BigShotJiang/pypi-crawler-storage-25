import asyncio
import json
import logging
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from routiq.adapters.registry import init_adapters
from routiq.dashboard.routes import router as dashboard_router
from routiq.gateway.routes import router
from routiq.gateway.scrubber import scrub_keys_from_log
from routiq.gateway.security_headers import SecurityHeadersMiddleware
from routiq.pipeline.cache import init_semantic_cache
from routiq.pipeline.cost import init_db, start_cleanup_task


class _JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        message = scrub_keys_from_log(record.getMessage())
        if record.exc_info:
            message += "\n" + self.formatException(record.exc_info)
        return json.dumps({
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "message": message,
        })


def _configure_logging(level: str) -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(_JSONFormatter())
    logging.root.handlers = [handler]
    logging.root.setLevel(getattr(logging, level.upper(), logging.INFO))


_WARMUP_URLS: dict[str, str] = {
    "openai":    "https://api.openai.com/v1/models",
    "anthropic": "https://api.anthropic.com/v1/models",
    "gemini":    "https://generativelanguage.googleapis.com/v1beta/models",
    "deepseek":  "https://api.deepseek.com/v1/models",
}


async def _warm_adapter(name: str, url: str) -> None:
    from routiq.adapters.registry import _REGISTRY
    _log = logging.getLogger(__name__)
    try:
        adapter = _REGISTRY.get(name)
        if adapter is None:
            return
        http_client = adapter._client._client  # SDK client → httpx.AsyncClient
        await http_client.head(url, timeout=3.0)
        _log.info("warmup %s ok", name)
    except Exception as exc:
        _log.warning("warmup %s failed (non-fatal): %s", name, exc)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    from routiq.config import get_settings
    from routiq.adapters.registry import _REGISTRY
    _configure_logging(get_settings().log_level)
    init_adapters()
    await init_semantic_cache()
    await init_db()
    await start_cleanup_task()
    await asyncio.gather(*[
        _warm_adapter(name, url)
        for name, url in _WARMUP_URLS.items()
        if name in _REGISTRY
    ])
    logging.getLogger(__name__).info("Routiq started")
    yield
    logging.getLogger(__name__).info("Routiq stopped")


_STATIC_DIR = Path(__file__).parent / "dashboard" / "static"

app = FastAPI(title="Routiq", version="0.1.0", lifespan=lifespan)
app.add_middleware(SecurityHeadersMiddleware)
app.include_router(router)
app.include_router(dashboard_router)
app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")
