import subprocess
import sys
from pathlib import Path

BANNER = """
██████╗  ██████╗ ██╗   ██╗████████╗██╗ ██████╗
██╔══██╗██╔═══██╗██║   ██║╚══██╔══╝██║██╔═══██╗
██████╔╝██║   ██║██║   ██║   ██║   ██║██║   ██║
██╔══██╗██║   ██║██║   ██║   ██║   ██║██║▄▄ ██║
██║  ██║╚██████╔╝╚██████╔╝   ██║   ██║╚██████╔╝
╚═╝  ╚═╝ ╚═════╝  ╚═════╝    ╚═╝   ╚═╝ ╚══▀▀═╝
v0.1.0 — local LLM gateway
"""

ENV_TEMPLATE = """\
# Routiq configuration
# Get your keys from:
#   OpenAI:    https://platform.openai.com/api-keys
#   Anthropic: https://console.anthropic.com/api-keys

# Required: choose any secret string — this protects your gateway
ROUTIQ_API_KEY=change-me-to-any-secret

# Required: at least one provider key
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...

# Optional
REDIS_URL=redis://localhost:6379
SQLITE_PATH=./routiq.db
LOG_LEVEL=INFO
DEFAULT_CHEAP_MODEL=gpt-4o-mini
DEFAULT_SMART_MODEL=gpt-4o
MODELS_YAML_PATH=./models.yml
ROUTIQ_MOCK_MODE=false
"""

SETUP_GUIDE = """
┌─────────────────────────────────────────────┐
│  Routiq first-run setup                     │
└─────────────────────────────────────────────┘

No .env file found. Creating .env from template...

Next steps:
  1. Open .env and fill in your API keys
  2. Run: routiq start

Get your keys from:
  OpenAI:    https://platform.openai.com/api-keys
  Anthropic: https://console.anthropic.com/api-keys

Or test without keys:
  Set ROUTIQ_MOCK_MODE=true in .env
  OPENAI_API_KEY and ANTHROPIC_API_KEY can be left blank
"""

USAGE = """
Usage: routiq <command>

Commands:
  start          Start the gateway (default port 8001)
  start --port   Start on a custom port: routiq start --port 9000
  setup          Create a .env template and exit

After starting:
  Dashboard:  http://localhost:8001/dashboard
  API:        http://localhost:8001/v1/chat/completions

Change one line in your existing code:
  client = OpenAI(
      api_key="your-ROUTIQ_API_KEY",
      base_url="http://localhost:8001/v1"
  )
"""


def check_env() -> bool:
    env_path = Path(".env")
    if not env_path.exists():
        print(SETUP_GUIDE)
        env_path.write_text(ENV_TEMPLATE)
        print(f"  Created .env at {env_path.absolute()}")
        print("  Edit it, then run: routiq start\n")
        return False
    return True


def cmd_setup():
    env_path = Path(".env")
    if env_path.exists():
        print(".env already exists — edit it directly.")
    else:
        env_path.write_text(ENV_TEMPLATE)
        print(f"Created .env at {env_path.absolute()}")
        print("Fill in your API keys, then run: routiq start")


def cmd_start(port: int = 8001):
    if not check_env():
        return
    print(BANNER)
    print(f"  Gateway:   http://localhost:{port}/v1/chat/completions")
    print(f"  Dashboard: http://localhost:{port}/dashboard")
    print(f"  Health:    http://localhost:{port}/health")
    print("\n  Press Ctrl+C to stop\n")
    subprocess.run([
        sys.executable, "-m", "uvicorn",
        "routiq.main:app",
        "--host", "0.0.0.0",
        "--port", str(port),
    ])


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print(USAGE)
        return

    if args[0] == "setup":
        cmd_setup()
        return

    if args[0] == "start":
        port = 8001
        if "--port" in args:
            idx = args.index("--port")
            try:
                port = int(args[idx + 1])
            except (IndexError, ValueError):
                print("Error: --port requires a number")
                sys.exit(1)
        cmd_start(port)
        return

    print(f"Unknown command: {args[0]}")
    print(USAGE)
    sys.exit(1)
