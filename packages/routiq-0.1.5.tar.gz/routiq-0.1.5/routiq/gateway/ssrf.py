import ipaddress
import socket
from urllib.parse import urlparse

_BLOCKED_NETWORKS: list = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
]


def validate_url(url: str) -> None:
    parsed = urlparse(url)
    hostname = parsed.hostname
    if not hostname:
        raise ValueError(f"Invalid URL: {url}")
    try:
        resolved = socket.getaddrinfo(hostname, None)[0][4][0]
        ip = ipaddress.ip_address(resolved)
    except (socket.gaierror, ValueError) as exc:
        raise ValueError(f"Cannot resolve hostname: {hostname}") from exc
    for network in _BLOCKED_NETWORKS:
        if ip in network:
            raise ValueError(f"URL resolves to a blocked private address: {ip}")
