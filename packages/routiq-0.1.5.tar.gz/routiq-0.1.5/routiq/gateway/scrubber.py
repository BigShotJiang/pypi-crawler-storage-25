import re

_SK_PATTERN = re.compile(r"sk-(?:ant-api\d+-)?[A-Za-z0-9\-_]+")


def scrub_keys_from_log(text: str) -> str:
    return _SK_PATTERN.sub("sk-***", text)
