import logging
from importlib.metadata import version as _pkg_version

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse

from routiq.adapters.base import ProviderError
from routiq.gateway.auth import verify_api_key
from routiq.pipeline.orchestrator import process
from routiq.pipeline.router import NoProviderAvailable

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/v1")
async def v1_info() -> dict:
    return {
        "message": "Routiq API",
        "endpoints": {
            "chat_completions": "POST /v1/chat/completions",
            "health": "GET /health",
            "dashboard": "GET /dashboard",
        },
        "docs": "https://github.com/yashbafna/routiq-feedback",
    }


@router.post("/v1/chat/completions", dependencies=[Depends(verify_api_key)])
async def chat_completions(request: Request) -> JSONResponse:
    raw = await request.json()
    logger.info("chat_completion_start")

    messages = raw.get("messages")
    if not messages or not isinstance(messages, list):
        return JSONResponse(
            status_code=400,
            content={"error": {
                "message": "messages is required and must be a non-empty list",
                "type": "invalid_request_error",
            }},
        )
    if not isinstance(raw.get("model", ""), str):
        return JSONResponse(
            status_code=400,
            content={"error": {
                "message": "model must be a string",
                "type": "invalid_request_error",
            }},
        )

    if raw.get("stream", False):
        # streaming — future work
        return JSONResponse(
            status_code=501,
            content={"error": {"message": "Streaming not yet supported", "type": "not_implemented"}},
        )

    try:
        result, request_id = await process(raw)
        logger.info("chat_completion_done request_id=%s", request_id)
        return JSONResponse(content=result)
    except NoProviderAvailable:
        logger.error("chat_completion_error error=no_provider_available")
        return JSONResponse(
            status_code=503,
            content={"error": {
                "message": (
                    "No LLM provider configured. Add at least one API key "
                    "(OPENAI_API_KEY, GEMINI_API_KEY, ANTHROPIC_API_KEY, etc.) to your .env"
                ),
                "type": "configuration_error",
            }},
        )
    except ProviderError as exc:
        logger.error("chat_completion_error provider_error status=%d error=%s", exc.status_code, exc)
        return JSONResponse(
            status_code=502,
            content={"error": {
                "message": str(exc),
                "type": "provider_error",
                "provider_status": exc.status_code,
            }},
        )
    except Exception as exc:
        logger.error("chat_completion_error error=%s", exc)
        return JSONResponse(
            status_code=500,
            content={"error": {"message": str(exc), "type": "internal_error"}},
        )


@router.get("/health")
async def health() -> dict:
    return {"status": "ok", "version": _pkg_version("routiq")}
