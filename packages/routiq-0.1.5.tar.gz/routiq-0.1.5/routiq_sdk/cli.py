"""Routiq gateway manager CLI.

Commands:
    routiq start     — pull docker-compose.yml if needed, start gateway, wait for health
    routiq stop      — docker compose down
    routiq logs      — tail gateway logs
    routiq dashboard — open dashboard in default browser
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

import httpx

GREEN = "\033[32m"
ORANGE = "\033[38;5;208m"
BOLD = "\033[1m"
RESET = "\033[0m"

BANNER = r"""
  ____           ●
 |  _ \   ──●──→ ●
 | |_) | ──●──→ ●
 |  _ <   ──●──→ ●
 |_| \_\        ●

 R O U T I Q
 AI · LLM · Routing
"""

TAGLINE = "The LLM gateway — right model, right provider, right price."

DOCKER_COMPOSE_URL = (
    "https://raw.githubusercontent.com/yashbafna/routiq-feedback/main/docker-compose.yml"
)
HEALTH_URL = "http://localhost:8001/health"
ENV_TEMPLATE = """\
# Routiq Gateway Configuration
# Fill in the keys for whichever providers you want to use.
ROUTIQ_API_KEY=change-me
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
DEEPSEEK_API_KEY=
GEMINI_API_KEY=
"""


def _docker_available() -> bool:
    """Return True only if Docker is installed AND the daemon is reachable."""
    try:
        subprocess.run(["docker", "info"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _check_docker() -> None:
    if not _docker_available():
        print("Error: Docker is not installed or the daemon is not running.", file=sys.stderr)
        print(
            "Start Docker Desktop, or install Docker from https://docs.docker.com/get-docker/",
            file=sys.stderr,
        )
        sys.exit(1)


_COMPOSE_MANUAL = (
    "Could not download docker-compose.yml automatically.\n"
    "Download it manually from:\n"
    "  https://github.com/yashbafna/routiq-feedback/blob/main/docker-compose.yml\n"
    "Save it as docker-compose.yml in this directory, then run routiq start again."
)


def _download_compose(no_verify: bool = False) -> None:
    url = "https://raw.githubusercontent.com/yashbafna/routiq-feedback/main/docker-compose.yml"

    def _write(r: httpx.Response) -> None:
        r.raise_for_status()
        with open("docker-compose.yml", "w") as f:
            f.write(r.text)
        print("Downloaded docker-compose.yml")

    if no_verify:
        # Caller already requested no verification (e.g. --no-verify flag).
        try:
            _write(httpx.get(url, follow_redirects=True, verify=False))
            print(
                "Warning: SSL verification disabled for this download.\n"
                "Verify docker-compose.yml manually after download."
            )
            return
        except Exception as e:
            print(f"Download failed even without SSL verification: {e}")
            print(_COMPOSE_MANUAL)
            sys.exit(1)

    # 1. Normal request.
    try:
        _write(httpx.get(url, follow_redirects=True))
        return
    except httpx.ConnectError as ssl_err:
        if "SSL" not in str(ssl_err) and "CERTIFICATE" not in str(ssl_err).upper():
            print(f"Connection error: {ssl_err}")
            print(_COMPOSE_MANUAL)
            sys.exit(1)
        # Fall through to SSL-disabled retry.
    except Exception as e:
        print(f"Failed to download docker-compose.yml: {e}")
        print(_COMPOSE_MANUAL)
        sys.exit(1)

    # 2. SSL error — retry without verification.
    print(
        "Warning: SSL verification disabled for this download.\n"
        "Verify docker-compose.yml manually after download."
    )
    try:
        _write(httpx.get(url, follow_redirects=True, verify=False))
    except Exception as e:
        print(f"Download failed even without SSL verification: {e}")
        print(_COMPOSE_MANUAL)
        sys.exit(1)


def _ensure_compose_file(no_verify: bool = False) -> None:
    if not Path("docker-compose.yml").exists():
        print("No docker-compose.yml found — downloading from routiq-feedback...")
        _download_compose(no_verify=no_verify)


def _ensure_env_file() -> bool:
    """Return True if .env already existed (or was just created with real values)."""
    if not Path(".env").exists():
        Path(".env").write_text(ENV_TEMPLATE)
        print(
            ".env template created — edit it to add your API keys, then run `routiq start` again."
        )
        return False
    return True


def _poll_health(timeout: int = 30) -> bool:
    deadline = time.time() + timeout
    with httpx.Client(timeout=2) as client:
        while time.time() < deadline:
            try:
                if client.get(HEALTH_URL).status_code == 200:
                    return True
            except Exception:
                pass
            time.sleep(1)
    return False


def _start_local(port: int = 8001) -> None:
    """Fall back to running the gateway in-process via uvicorn."""
    try:
        import importlib
        importlib.import_module("routiq.main")
    except ModuleNotFoundError:
        print(
            "Docker daemon is not running and the local gateway source is not installed.\n"
            "Start Docker Desktop, then run routiq start again.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"{GREEN}✓{RESET} Docker unavailable — starting local gateway instead")
    print(f"  {BOLD}API:{RESET}        http://localhost:{port}/v1")
    print(f"  {BOLD}Dashboard:{RESET}  http://localhost:{port}/dashboard")
    print(f"  {BOLD}Health:{RESET}     http://localhost:{port}/health")
    print("\n  Press Ctrl+C to stop\n")
    subprocess.run([
        sys.executable, "-m", "uvicorn",
        "routiq.main:app",
        "--host", "0.0.0.0",
        "--port", str(port),
    ])


def _stop_containers_on_port(port: int) -> None:
    """Stop any Docker container publishing the given port."""
    result = subprocess.run(
        ["docker", "ps", "-q", "--filter", f"publish={port}"],
        capture_output=True, text=True,
    )
    for cid in result.stdout.strip().split():
        if cid:
            subprocess.run(["docker", "stop", cid], capture_output=True)


def _kill_local_port(port: int) -> None:
    """Kill non-Docker processes holding a port."""
    result = subprocess.run(["lsof", "-ti", f":{port}"], capture_output=True, text=True)
    killed = []
    for pid in result.stdout.strip().split():
        name = subprocess.run(
            ["ps", "-p", pid, "-o", "comm="], capture_output=True, text=True,
        ).stdout.strip().lower()
        if "docker" not in name:
            try:
                subprocess.run(["kill", pid], check=True)
                killed.append(pid)
            except subprocess.CalledProcessError:
                pass
    if killed:
        print(f"{GREEN}✓{RESET} Freed port {port}")


def _clear_ports(*ports: int) -> None:
    """Stop Docker containers and local processes on the given ports."""
    for port in ports:
        _stop_containers_on_port(port)
        _kill_local_port(port)


def cmd_start(args: argparse.Namespace) -> None:
    print(f"{ORANGE}{BOLD}{BANNER}{RESET}", flush=True)
    print(f"{ORANGE}{TAGLINE}{RESET}\n", flush=True)

    if not _docker_available():
        if not _ensure_env_file():
            sys.exit(0)
        _clear_ports(8001)
        _start_local()
        return

    print(f"{GREEN}✓{RESET} Docker check passed")

    # Stop our compose stack and any other containers/processes on required ports.
    subprocess.run(["docker", "compose", "down"], capture_output=True)
    _clear_ports(8001, 6379)

    _ensure_compose_file(no_verify=getattr(args, "no_verify", False))
    print(f"{GREEN}✓{RESET} docker-compose.yml ready")

    if not _ensure_env_file():
        sys.exit(0)

    try:
        subprocess.run(["docker", "compose", "up", "-d"], check=True)
    except subprocess.CalledProcessError:
        print(f"\nDocker Compose failed — falling back to local gateway.")
        _clear_ports(8001)
        _start_local()
        return
    print(f"{GREEN}✓{RESET} Container started")

    print("Waiting for gateway to be ready...", end="", flush=True)
    if _poll_health():
        print(f"\r{GREEN}✓{RESET} Gateway healthy at http://localhost:8001")
        print()
        print(f"  {BOLD}Dashboard:{RESET}  http://localhost:8001/dashboard")
        print(f"  {BOLD}API:{RESET}        http://localhost:8001/v1")
        print(f"  {BOLD}Health:{RESET}     http://localhost:8001/health")
        print()
        print(f"  Issues or feedback?  https://github.com/yashbafna/routiq-feedback")
        print(f"  Stop the gateway:    routiq stop")
        print()
    else:
        print(
            "\nWarning: gateway did not respond within 30 s — check logs with: routiq logs"
        )


def cmd_stop(_args: argparse.Namespace) -> None:
    _check_docker()
    subprocess.run(["docker", "compose", "down"], check=True)


def cmd_logs(_args: argparse.Namespace) -> None:
    _check_docker()
    subprocess.run(["docker", "compose", "logs", "--follow"])


def cmd_dashboard(_args: argparse.Namespace) -> None:
    url = "http://localhost:8001/dashboard"
    print(f"Opening {url} ...")
    webbrowser.open(url)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="routiq",
        description="Routiq gateway manager",
        epilog="For issues or feedback: https://github.com/yashbafna/routiq-feedback",
    )
    sub = parser.add_subparsers(dest="command")
    start_parser = sub.add_parser("start", help="Start the Routiq gateway via Docker Compose")
    start_parser.add_argument(
        "--no-verify",
        dest="no_verify",
        action="store_true",
        help="Disable SSL verification when downloading docker-compose.yml (debugging only)",
    )
    sub.add_parser("stop", help="Stop the Routiq gateway")
    sub.add_parser("logs", help="Tail gateway logs")
    sub.add_parser("dashboard", help="Open the gateway dashboard in your browser")

    args = parser.parse_args()

    dispatch = {
        "start": cmd_start,
        "stop": cmd_stop,
        "logs": cmd_logs,
        "dashboard": cmd_dashboard,
    }
    fn = dispatch.get(args.command)
    if fn:
        fn(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
