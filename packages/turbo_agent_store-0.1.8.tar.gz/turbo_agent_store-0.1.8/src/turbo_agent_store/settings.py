from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict
from pytz import timezone


class Settings(BaseSettings):
    # 文件管理后端选择：local | s3
    TA_STORE_FILE_BACKEND: str = "local"

    # S3 环境变量统一遵守 TA_STORE 前缀规范
    TA_STORE_S3_ENDPOINT: str = ""
    TA_STORE_S3_REGION: str = "us-east-1"
    TA_STORE_S3_ACCESS_KEY_ID: str = ""
    TA_STORE_S3_SECRET_ACCESS_KEY: str = ""
    TA_STORE_S3_SESSION_TOKEN: str = ""
    TA_STORE_S3_SECURE: bool = True
    TA_STORE_S3_ADDRESSING_STYLE: str = "path"
    TA_STORE_S3_PRIVATE_BUCKET: str = "turbo-agent-private"
    TA_STORE_S3_PUBLIC_BUCKET: str = "turbo-agent-public"

    # 外部访问地址（可走 Nginx 反向代理）
    # 例如：TA_STORE_EXTERNAL_BASE_URL=https://files.example.com
    #      TA_STORE_EXTERNAL_PATH_PREFIX=/files
    TA_STORE_EXTERNAL_BASE_URL: str = ""
    TA_STORE_EXTERNAL_PATH_PREFIX: str = ""
    TA_STORE_SECURE_LINK_SECRET: str = ""

    # 本地文件系统 file manager 配置
    TA_STORE_LOCAL_BASE_PATH: str = "/tmp/turbo_agent/file_manage"

    # 文件缓存 TTL 配置
    TA_STORE_CACHE_TTL_META_AVATAR_SECONDS: int = 604800
    TA_STORE_CACHE_TTL_OTHER_IMAGE_SECONDS: int = 86400
    TA_STORE_CACHE_TTL_DEFAULT_SECONDS: int = 3600

    TA_STORE_TIMEZONE: str = "Asia/Shanghai"

    model_config = SettingsConfigDict(
        env_file=str(".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

settings = Settings()
tz = timezone(settings.TA_STORE_TIMEZONE)
