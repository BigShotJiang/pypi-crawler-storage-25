# Metrana Protobuf Models for Python

This package provides Python bindings for Metrana's protobuf schemas, enabling type-safe communication with Metrana services via gRPC and REST.

## Installation

```bash
pip install metrana-proto-python
```

## Usage

```python
from metrana_protobuf.common.v1 import attributes_pb2
from metrana_protobuf.ingestion.v1 import svc

# Create protobuf messages
string_set = attributes_pb2.StringSet(values=["tag1", "tag2", "tag3"])

# Use gRPC service stubs
# stub = svc.IngestServiceStub(channel)
# response = stub.CreateRun(request)
```

## Included Schemas

- **common.v1** - Common types for series and attributes
- **ingestion.v1.types** - Common types for ingestion (run definitions, and update messages)
- **ingestion.v1.svc** - gRPC/REST service definitions for the Ingest API
- **management.v1.types** - Common types for management (series processing descriptor)
- **query.v1.svc** - gRPC/REST service definitions for the Query API

## Requirements

- Python 3.10+
- protobuf >= 4.25.0
- grpcio >= 1.60.0

## License

Apache-2.0
