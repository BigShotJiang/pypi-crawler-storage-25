from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SeriesProcessorDescriptor(_message.Message):
    __slots__ = ("metric_names", "scale", "cross_series_aggregators", "raw_series_storage")
    class CrossSeriesAggregators(_message.Message):
        __slots__ = ("raw_series_views", "aggregations")
        class RawSeriesView(_message.Message):
            __slots__ = ("name", "raw", "ema")
            class Raw(_message.Message):
                __slots__ = ()
                def __init__(self) -> None: ...
            class Ema(_message.Message):
                __slots__ = ("smoothing_factor",)
                SMOOTHING_FACTOR_FIELD_NUMBER: _ClassVar[int]
                smoothing_factor: float
                def __init__(self, smoothing_factor: _Optional[float] = ...) -> None: ...
            NAME_FIELD_NUMBER: _ClassVar[int]
            RAW_FIELD_NUMBER: _ClassVar[int]
            EMA_FIELD_NUMBER: _ClassVar[int]
            name: str
            raw: SeriesProcessorDescriptor.CrossSeriesAggregators.RawSeriesView.Raw
            ema: SeriesProcessorDescriptor.CrossSeriesAggregators.RawSeriesView.Ema
            def __init__(self, name: _Optional[str] = ..., raw: _Optional[_Union[SeriesProcessorDescriptor.CrossSeriesAggregators.RawSeriesView.Raw, _Mapping]] = ..., ema: _Optional[_Union[SeriesProcessorDescriptor.CrossSeriesAggregators.RawSeriesView.Ema, _Mapping]] = ...) -> None: ...
        class Aggregation(_message.Message):
            __slots__ = ("group_by_labels", "include_tdigest_stats", "store_as_run_metrics", "enabled_views")
            GROUP_BY_LABELS_FIELD_NUMBER: _ClassVar[int]
            INCLUDE_TDIGEST_STATS_FIELD_NUMBER: _ClassVar[int]
            STORE_AS_RUN_METRICS_FIELD_NUMBER: _ClassVar[int]
            ENABLED_VIEWS_FIELD_NUMBER: _ClassVar[int]
            group_by_labels: _containers.RepeatedScalarFieldContainer[str]
            include_tdigest_stats: bool
            store_as_run_metrics: bool
            enabled_views: _containers.RepeatedScalarFieldContainer[str]
            def __init__(self, group_by_labels: _Optional[_Iterable[str]] = ..., include_tdigest_stats: bool = ..., store_as_run_metrics: bool = ..., enabled_views: _Optional[_Iterable[str]] = ...) -> None: ...
        RAW_SERIES_VIEWS_FIELD_NUMBER: _ClassVar[int]
        AGGREGATIONS_FIELD_NUMBER: _ClassVar[int]
        raw_series_views: _containers.RepeatedCompositeFieldContainer[SeriesProcessorDescriptor.CrossSeriesAggregators.RawSeriesView]
        aggregations: _containers.RepeatedCompositeFieldContainer[SeriesProcessorDescriptor.CrossSeriesAggregators.Aggregation]
        def __init__(self, raw_series_views: _Optional[_Iterable[_Union[SeriesProcessorDescriptor.CrossSeriesAggregators.RawSeriesView, _Mapping]]] = ..., aggregations: _Optional[_Iterable[_Union[SeriesProcessorDescriptor.CrossSeriesAggregators.Aggregation, _Mapping]]] = ...) -> None: ...
    class RawSeriesStorage(_message.Message):
        __slots__ = ("disable_storage", "store_as_run_metrics")
        DISABLE_STORAGE_FIELD_NUMBER: _ClassVar[int]
        STORE_AS_RUN_METRICS_FIELD_NUMBER: _ClassVar[int]
        disable_storage: bool
        store_as_run_metrics: bool
        def __init__(self, disable_storage: bool = ..., store_as_run_metrics: bool = ...) -> None: ...
    METRIC_NAMES_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    CROSS_SERIES_AGGREGATORS_FIELD_NUMBER: _ClassVar[int]
    RAW_SERIES_STORAGE_FIELD_NUMBER: _ClassVar[int]
    metric_names: _containers.RepeatedScalarFieldContainer[str]
    scale: str
    cross_series_aggregators: SeriesProcessorDescriptor.CrossSeriesAggregators
    raw_series_storage: SeriesProcessorDescriptor.RawSeriesStorage
    def __init__(self, metric_names: _Optional[_Iterable[str]] = ..., scale: _Optional[str] = ..., cross_series_aggregators: _Optional[_Union[SeriesProcessorDescriptor.CrossSeriesAggregators, _Mapping]] = ..., raw_series_storage: _Optional[_Union[SeriesProcessorDescriptor.RawSeriesStorage, _Mapping]] = ...) -> None: ...
