"""Metrana protobuf models."""
