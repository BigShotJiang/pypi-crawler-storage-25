from metrana_protobuf.common.v1 import attributes_pb2 as _attributes_pb2
from metrana_protobuf.common.v1 import series_pb2 as _series_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class StepRange(_message.Message):
    __slots__ = ("from_step", "to_step")
    FROM_STEP_FIELD_NUMBER: _ClassVar[int]
    TO_STEP_FIELD_NUMBER: _ClassVar[int]
    from_step: int
    to_step: int
    def __init__(self, from_step: _Optional[int] = ..., to_step: _Optional[int] = ...) -> None: ...

class StepSelection(_message.Message):
    __slots__ = ("step_range", "per_series_from_the_beginning", "per_series_from_the_end")
    STEP_RANGE_FIELD_NUMBER: _ClassVar[int]
    PER_SERIES_FROM_THE_BEGINNING_FIELD_NUMBER: _ClassVar[int]
    PER_SERIES_FROM_THE_END_FIELD_NUMBER: _ClassVar[int]
    step_range: StepRange
    per_series_from_the_beginning: int
    per_series_from_the_end: int
    def __init__(self, step_range: _Optional[_Union[StepRange, _Mapping]] = ..., per_series_from_the_beginning: _Optional[int] = ..., per_series_from_the_end: _Optional[int] = ...) -> None: ...

class RunsFilter(_message.Message):
    __slots__ = ("directory_path", "experiment", "filter", "order_by", "limit", "offset")
    DIRECTORY_PATH_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ORDER_BY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    directory_path: str
    experiment: str
    filter: str
    order_by: str
    limit: int
    offset: int
    def __init__(self, directory_path: _Optional[str] = ..., experiment: _Optional[str] = ..., filter: _Optional[str] = ..., order_by: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class ListAttrFilter(_message.Message):
    __slots__ = ("kinds", "all", "regex", "prefix_path")
    class AllAttributes(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    KINDS_FIELD_NUMBER: _ClassVar[int]
    ALL_FIELD_NUMBER: _ClassVar[int]
    REGEX_FIELD_NUMBER: _ClassVar[int]
    PREFIX_PATH_FIELD_NUMBER: _ClassVar[int]
    kinds: _containers.RepeatedScalarFieldContainer[_attributes_pb2.AttributeKind]
    all: ListAttrFilter.AllAttributes
    regex: str
    prefix_path: str
    def __init__(self, kinds: _Optional[_Iterable[_Union[_attributes_pb2.AttributeKind, str]]] = ..., all: _Optional[_Union[ListAttrFilter.AllAttributes, _Mapping]] = ..., regex: _Optional[str] = ..., prefix_path: _Optional[str] = ...) -> None: ...

class BrowseAttrFilter(_message.Message):
    __slots__ = ("kinds",)
    KINDS_FIELD_NUMBER: _ClassVar[int]
    kinds: _containers.RepeatedScalarFieldContainer[_attributes_pb2.AttributeKind]
    def __init__(self, kinds: _Optional[_Iterable[_Union[_attributes_pb2.AttributeKind, str]]] = ...) -> None: ...

class AttrDefProjectSource(_message.Message):
    __slots__ = ("project",)
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    project: str
    def __init__(self, project: _Optional[str] = ...) -> None: ...

class AttrDefDirectorySource(_message.Message):
    __slots__ = ("project", "directory_path")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_PATH_FIELD_NUMBER: _ClassVar[int]
    project: str
    directory_path: str
    def __init__(self, project: _Optional[str] = ..., directory_path: _Optional[str] = ...) -> None: ...

class AttrDefExperimentSource(_message.Message):
    __slots__ = ("project", "experiment")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    project: str
    experiment: str
    def __init__(self, project: _Optional[str] = ..., experiment: _Optional[str] = ...) -> None: ...

class AttrDefRunSource(_message.Message):
    __slots__ = ("project", "experiment", "run")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    project: str
    experiment: str
    run: str
    def __init__(self, project: _Optional[str] = ..., experiment: _Optional[str] = ..., run: _Optional[str] = ...) -> None: ...

class AttrProjectSource(_message.Message):
    __slots__ = ("project",)
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    project: str
    def __init__(self, project: _Optional[str] = ...) -> None: ...

class AttrDirectorySource(_message.Message):
    __slots__ = ("project", "directory_path")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_PATH_FIELD_NUMBER: _ClassVar[int]
    project: str
    directory_path: str
    def __init__(self, project: _Optional[str] = ..., directory_path: _Optional[str] = ...) -> None: ...

class AttrExperimentSource(_message.Message):
    __slots__ = ("project", "experiment")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    project: str
    experiment: str
    def __init__(self, project: _Optional[str] = ..., experiment: _Optional[str] = ...) -> None: ...

class AttrRunSource(_message.Message):
    __slots__ = ("project", "run")
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    project: str
    run: str
    def __init__(self, project: _Optional[str] = ..., run: _Optional[str] = ...) -> None: ...

class AttributeDef(_message.Message):
    __slots__ = ("path", "kind")
    PATH_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    path: str
    kind: _attributes_pb2.AttributeKind
    def __init__(self, path: _Optional[str] = ..., kind: _Optional[_Union[_attributes_pb2.AttributeKind, str]] = ...) -> None: ...

class ListWorkspacesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListWorkspacesResponse(_message.Message):
    __slots__ = ("workspaces",)
    class Workspace(_message.Message):
        __slots__ = ("name", "projects_count")
        NAME_FIELD_NUMBER: _ClassVar[int]
        PROJECTS_COUNT_FIELD_NUMBER: _ClassVar[int]
        name: str
        projects_count: int
        def __init__(self, name: _Optional[str] = ..., projects_count: _Optional[int] = ...) -> None: ...
    WORKSPACES_FIELD_NUMBER: _ClassVar[int]
    workspaces: _containers.RepeatedCompositeFieldContainer[ListWorkspacesResponse.Workspace]
    def __init__(self, workspaces: _Optional[_Iterable[_Union[ListWorkspacesResponse.Workspace, _Mapping]]] = ...) -> None: ...

class ListProjectsRequest(_message.Message):
    __slots__ = ("workspace", "filter", "order_by", "limit", "offset", "attribute_paths")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ORDER_BY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_PATHS_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    filter: str
    order_by: str
    limit: int
    offset: int
    attribute_paths: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, workspace: _Optional[str] = ..., filter: _Optional[str] = ..., order_by: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., attribute_paths: _Optional[_Iterable[str]] = ...) -> None: ...

class ListProjectsResponse(_message.Message):
    __slots__ = ("projects", "total_count")
    class Project(_message.Message):
        __slots__ = ("name", "runs_count", "experiments_count", "attributes")
        NAME_FIELD_NUMBER: _ClassVar[int]
        RUNS_COUNT_FIELD_NUMBER: _ClassVar[int]
        EXPERIMENTS_COUNT_FIELD_NUMBER: _ClassVar[int]
        ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
        name: str
        runs_count: int
        experiments_count: int
        attributes: _containers.RepeatedCompositeFieldContainer[_attributes_pb2.Attribute]
        def __init__(self, name: _Optional[str] = ..., runs_count: _Optional[int] = ..., experiments_count: _Optional[int] = ..., attributes: _Optional[_Iterable[_Union[_attributes_pb2.Attribute, _Mapping]]] = ...) -> None: ...
    PROJECTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    projects: _containers.RepeatedCompositeFieldContainer[ListProjectsResponse.Project]
    total_count: int
    def __init__(self, projects: _Optional[_Iterable[_Union[ListProjectsResponse.Project, _Mapping]]] = ..., total_count: _Optional[int] = ...) -> None: ...

class ListRunsRequest(_message.Message):
    __slots__ = ("workspace", "project", "directory_path", "experiment", "filter", "order_by", "limit", "offset", "attribute_paths", "series_summaries")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_PATH_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ORDER_BY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_PATHS_FIELD_NUMBER: _ClassVar[int]
    SERIES_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    directory_path: str
    experiment: str
    filter: str
    order_by: str
    limit: int
    offset: int
    attribute_paths: _containers.RepeatedScalarFieldContainer[str]
    series_summaries: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., directory_path: _Optional[str] = ..., experiment: _Optional[str] = ..., filter: _Optional[str] = ..., order_by: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., attribute_paths: _Optional[_Iterable[str]] = ..., series_summaries: _Optional[_Iterable[str]] = ...) -> None: ...

class ListRunsResponse(_message.Message):
    __slots__ = ("runs", "total_count")
    class SeriesSummaryValue(_message.Message):
        __slots__ = ("series_summary", "value")
        SERIES_SUMMARY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        series_summary: str
        value: float
        def __init__(self, series_summary: _Optional[str] = ..., value: _Optional[float] = ...) -> None: ...
    class Run(_message.Message):
        __slots__ = ("name", "experiment", "attributes", "series_summaries")
        NAME_FIELD_NUMBER: _ClassVar[int]
        EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
        ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
        SERIES_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
        name: str
        experiment: str
        attributes: _containers.RepeatedCompositeFieldContainer[_attributes_pb2.Attribute]
        series_summaries: _containers.RepeatedCompositeFieldContainer[ListRunsResponse.SeriesSummaryValue]
        def __init__(self, name: _Optional[str] = ..., experiment: _Optional[str] = ..., attributes: _Optional[_Iterable[_Union[_attributes_pb2.Attribute, _Mapping]]] = ..., series_summaries: _Optional[_Iterable[_Union[ListRunsResponse.SeriesSummaryValue, _Mapping]]] = ...) -> None: ...
    RUNS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    runs: _containers.RepeatedCompositeFieldContainer[ListRunsResponse.Run]
    total_count: int
    def __init__(self, runs: _Optional[_Iterable[_Union[ListRunsResponse.Run, _Mapping]]] = ..., total_count: _Optional[int] = ...) -> None: ...

class ListExperimentsRequest(_message.Message):
    __slots__ = ("workspace", "project", "directory_path", "filter", "order_by", "limit", "offset", "attribute_paths")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_PATH_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ORDER_BY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_PATHS_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    directory_path: str
    filter: str
    order_by: str
    limit: int
    offset: int
    attribute_paths: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., directory_path: _Optional[str] = ..., filter: _Optional[str] = ..., order_by: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., attribute_paths: _Optional[_Iterable[str]] = ...) -> None: ...

class ListExperimentsResponse(_message.Message):
    __slots__ = ("experiments", "total_count")
    class Experiment(_message.Message):
        __slots__ = ("name", "attributes", "runs_count")
        NAME_FIELD_NUMBER: _ClassVar[int]
        ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
        RUNS_COUNT_FIELD_NUMBER: _ClassVar[int]
        name: str
        attributes: _containers.RepeatedCompositeFieldContainer[_attributes_pb2.Attribute]
        runs_count: int
        def __init__(self, name: _Optional[str] = ..., attributes: _Optional[_Iterable[_Union[_attributes_pb2.Attribute, _Mapping]]] = ..., runs_count: _Optional[int] = ...) -> None: ...
    EXPERIMENTS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    experiments: _containers.RepeatedCompositeFieldContainer[ListExperimentsResponse.Experiment]
    total_count: int
    def __init__(self, experiments: _Optional[_Iterable[_Union[ListExperimentsResponse.Experiment, _Mapping]]] = ..., total_count: _Optional[int] = ...) -> None: ...

class ListDirectoriesRequest(_message.Message):
    __slots__ = ("workspace", "project", "directory_path", "filter", "order_by", "limit", "offset", "attribute_paths")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_PATH_FIELD_NUMBER: _ClassVar[int]
    FILTER_FIELD_NUMBER: _ClassVar[int]
    ORDER_BY_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_PATHS_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    directory_path: str
    filter: str
    order_by: str
    limit: int
    offset: int
    attribute_paths: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., directory_path: _Optional[str] = ..., filter: _Optional[str] = ..., order_by: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., attribute_paths: _Optional[_Iterable[str]] = ...) -> None: ...

class ListDirectoriesResponse(_message.Message):
    __slots__ = ("directories", "total_count")
    class Directory(_message.Message):
        __slots__ = ("full_path", "attributes", "runs_count", "experiments_count", "directories_count")
        FULL_PATH_FIELD_NUMBER: _ClassVar[int]
        ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
        RUNS_COUNT_FIELD_NUMBER: _ClassVar[int]
        EXPERIMENTS_COUNT_FIELD_NUMBER: _ClassVar[int]
        DIRECTORIES_COUNT_FIELD_NUMBER: _ClassVar[int]
        full_path: str
        attributes: _containers.RepeatedCompositeFieldContainer[_attributes_pb2.Attribute]
        runs_count: int
        experiments_count: int
        directories_count: int
        def __init__(self, full_path: _Optional[str] = ..., attributes: _Optional[_Iterable[_Union[_attributes_pb2.Attribute, _Mapping]]] = ..., runs_count: _Optional[int] = ..., experiments_count: _Optional[int] = ..., directories_count: _Optional[int] = ...) -> None: ...
    DIRECTORIES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    directories: _containers.RepeatedCompositeFieldContainer[ListDirectoriesResponse.Directory]
    total_count: int
    def __init__(self, directories: _Optional[_Iterable[_Union[ListDirectoriesResponse.Directory, _Mapping]]] = ..., total_count: _Optional[int] = ...) -> None: ...

class ListAttributesDefinitionsRequest(_message.Message):
    __slots__ = ("workspace", "project_source", "directory_source", "experiment_source", "run_source", "attr_filter", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_SOURCE_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    RUN_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTR_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project_source: AttrDefProjectSource
    directory_source: AttrDefDirectorySource
    experiment_source: AttrDefExperimentSource
    run_source: AttrDefRunSource
    attr_filter: ListAttrFilter
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project_source: _Optional[_Union[AttrDefProjectSource, _Mapping]] = ..., directory_source: _Optional[_Union[AttrDefDirectorySource, _Mapping]] = ..., experiment_source: _Optional[_Union[AttrDefExperimentSource, _Mapping]] = ..., run_source: _Optional[_Union[AttrDefRunSource, _Mapping]] = ..., attr_filter: _Optional[_Union[ListAttrFilter, _Mapping]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListAttributesDefinitionsResponse(_message.Message):
    __slots__ = ("attribute_defs", "resume_token")
    ATTRIBUTE_DEFS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    attribute_defs: _containers.RepeatedCompositeFieldContainer[AttributeDef]
    resume_token: str
    def __init__(self, attribute_defs: _Optional[_Iterable[_Union[AttributeDef, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class BrowseAttributesDefinitionsRequest(_message.Message):
    __slots__ = ("workspace", "directory", "project_source", "directory_source", "experiment_source", "run_source", "attr_filter", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_SOURCE_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    RUN_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTR_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    directory: str
    project_source: AttrDefProjectSource
    directory_source: AttrDefDirectorySource
    experiment_source: AttrDefExperimentSource
    run_source: AttrDefRunSource
    attr_filter: BrowseAttrFilter
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., directory: _Optional[str] = ..., project_source: _Optional[_Union[AttrDefProjectSource, _Mapping]] = ..., directory_source: _Optional[_Union[AttrDefDirectorySource, _Mapping]] = ..., experiment_source: _Optional[_Union[AttrDefExperimentSource, _Mapping]] = ..., run_source: _Optional[_Union[AttrDefRunSource, _Mapping]] = ..., attr_filter: _Optional[_Union[BrowseAttrFilter, _Mapping]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class BrowseAttributesDefinitionsResponse(_message.Message):
    __slots__ = ("directories", "attribute_defs", "resume_token")
    DIRECTORIES_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTE_DEFS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    directories: _containers.RepeatedScalarFieldContainer[str]
    attribute_defs: _containers.RepeatedCompositeFieldContainer[AttributeDef]
    resume_token: str
    def __init__(self, directories: _Optional[_Iterable[str]] = ..., attribute_defs: _Optional[_Iterable[_Union[AttributeDef, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListAttributesRequest(_message.Message):
    __slots__ = ("workspace", "project_source", "directory_source", "experiment_source", "run_source", "attr_filter", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_SOURCE_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    RUN_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTR_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project_source: AttrProjectSource
    directory_source: AttrDirectorySource
    experiment_source: AttrExperimentSource
    run_source: AttrRunSource
    attr_filter: ListAttrFilter
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project_source: _Optional[_Union[AttrProjectSource, _Mapping]] = ..., directory_source: _Optional[_Union[AttrDirectorySource, _Mapping]] = ..., experiment_source: _Optional[_Union[AttrExperimentSource, _Mapping]] = ..., run_source: _Optional[_Union[AttrRunSource, _Mapping]] = ..., attr_filter: _Optional[_Union[ListAttrFilter, _Mapping]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListAttributesResponse(_message.Message):
    __slots__ = ("attributes", "resume_token")
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    attributes: _containers.RepeatedCompositeFieldContainer[_attributes_pb2.Attribute]
    resume_token: str
    def __init__(self, attributes: _Optional[_Iterable[_Union[_attributes_pb2.Attribute, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class BrowseAttributesRequest(_message.Message):
    __slots__ = ("workspace", "directory", "project_source", "directory_source", "experiment_source", "run_source", "attr_filter", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    PROJECT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_SOURCE_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_SOURCE_FIELD_NUMBER: _ClassVar[int]
    RUN_SOURCE_FIELD_NUMBER: _ClassVar[int]
    ATTR_FILTER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    directory: str
    project_source: AttrProjectSource
    directory_source: AttrDirectorySource
    experiment_source: AttrExperimentSource
    run_source: AttrRunSource
    attr_filter: BrowseAttrFilter
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., directory: _Optional[str] = ..., project_source: _Optional[_Union[AttrProjectSource, _Mapping]] = ..., directory_source: _Optional[_Union[AttrDirectorySource, _Mapping]] = ..., experiment_source: _Optional[_Union[AttrExperimentSource, _Mapping]] = ..., run_source: _Optional[_Union[AttrRunSource, _Mapping]] = ..., attr_filter: _Optional[_Union[BrowseAttrFilter, _Mapping]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class BrowseAttributesResponse(_message.Message):
    __slots__ = ("directories", "attributes", "resume_token")
    DIRECTORIES_FIELD_NUMBER: _ClassVar[int]
    ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    directories: _containers.RepeatedScalarFieldContainer[str]
    attributes: _containers.RepeatedCompositeFieldContainer[_attributes_pb2.Attribute]
    resume_token: str
    def __init__(self, directories: _Optional[_Iterable[str]] = ..., attributes: _Optional[_Iterable[_Union[_attributes_pb2.Attribute, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListMetricDefinitionsRequest(_message.Message):
    __slots__ = ("workspace", "project", "metric_name_prefixes", "scales", "experiment", "run", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    METRIC_NAME_PREFIXES_FIELD_NUMBER: _ClassVar[int]
    SCALES_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    metric_name_prefixes: _containers.RepeatedScalarFieldContainer[str]
    scales: _containers.RepeatedScalarFieldContainer[str]
    experiment: str
    run: str
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., metric_name_prefixes: _Optional[_Iterable[str]] = ..., scales: _Optional[_Iterable[str]] = ..., experiment: _Optional[str] = ..., run: _Optional[str] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class MetricDefinition(_message.Message):
    __slots__ = ("metric_name", "scale", "label_keys", "is_aggregated")
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    LABEL_KEYS_FIELD_NUMBER: _ClassVar[int]
    IS_AGGREGATED_FIELD_NUMBER: _ClassVar[int]
    metric_name: str
    scale: str
    label_keys: _containers.RepeatedScalarFieldContainer[str]
    is_aggregated: bool
    def __init__(self, metric_name: _Optional[str] = ..., scale: _Optional[str] = ..., label_keys: _Optional[_Iterable[str]] = ..., is_aggregated: bool = ...) -> None: ...

class ListMetricDefinitionsResponse(_message.Message):
    __slots__ = ("metric_definitions", "resume_token")
    METRIC_DEFINITIONS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    metric_definitions: _containers.RepeatedCompositeFieldContainer[MetricDefinition]
    resume_token: str
    def __init__(self, metric_definitions: _Optional[_Iterable[_Union[MetricDefinition, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class BrowseMetricDefinitionsRequest(_message.Message):
    __slots__ = ("workspace", "project", "directory", "experiment", "run", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    directory: str
    experiment: str
    run: str
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., directory: _Optional[str] = ..., experiment: _Optional[str] = ..., run: _Optional[str] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class BrowseMetricDefinitionsResponse(_message.Message):
    __slots__ = ("directories", "metric_definitions", "resume_token")
    DIRECTORIES_FIELD_NUMBER: _ClassVar[int]
    METRIC_DEFINITIONS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    directories: _containers.RepeatedScalarFieldContainer[str]
    metric_definitions: _containers.RepeatedCompositeFieldContainer[MetricDefinition]
    resume_token: str
    def __init__(self, directories: _Optional[_Iterable[str]] = ..., metric_definitions: _Optional[_Iterable[_Union[MetricDefinition, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesDefinitionsRequest(_message.Message):
    __slots__ = ("workspace", "project", "experiment", "run", "series_filters", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    SERIES_FILTERS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    experiment: str
    run: str
    series_filters: _containers.RepeatedScalarFieldContainer[str]
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., experiment: _Optional[str] = ..., run: _Optional[str] = ..., series_filters: _Optional[_Iterable[str]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesDefinitionsResponse(_message.Message):
    __slots__ = ("series_definitions", "resume_token")
    SERIES_DEFINITIONS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    series_definitions: _containers.RepeatedCompositeFieldContainer[_series_pb2.SeriesDefinition]
    resume_token: str
    def __init__(self, series_definitions: _Optional[_Iterable[_Union[_series_pb2.SeriesDefinition, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesLabelValuesRequest(_message.Message):
    __slots__ = ("workspace", "project", "run", "label_key_filters", "limit", "resume_token")
    class LabelKeyFilter(_message.Message):
        __slots__ = ("key", "value_prefix", "value_regex")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_PREFIX_FIELD_NUMBER: _ClassVar[int]
        VALUE_REGEX_FIELD_NUMBER: _ClassVar[int]
        key: str
        value_prefix: str
        value_regex: str
        def __init__(self, key: _Optional[str] = ..., value_prefix: _Optional[str] = ..., value_regex: _Optional[str] = ...) -> None: ...
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    LABEL_KEY_FILTERS_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    run: str
    label_key_filters: _containers.RepeatedCompositeFieldContainer[ListSeriesLabelValuesRequest.LabelKeyFilter]
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run: _Optional[str] = ..., label_key_filters: _Optional[_Iterable[_Union[ListSeriesLabelValuesRequest.LabelKeyFilter, _Mapping]]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesLabelValuesResponse(_message.Message):
    __slots__ = ("label_key_values", "resume_token")
    class LabelKeyValues(_message.Message):
        __slots__ = ("key", "values")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUES_FIELD_NUMBER: _ClassVar[int]
        key: str
        values: _containers.RepeatedScalarFieldContainer[str]
        def __init__(self, key: _Optional[str] = ..., values: _Optional[_Iterable[str]] = ...) -> None: ...
    LABEL_KEY_VALUES_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    label_key_values: _containers.RepeatedCompositeFieldContainer[ListSeriesLabelValuesResponse.LabelKeyValues]
    resume_token: str
    def __init__(self, label_key_values: _Optional[_Iterable[_Union[ListSeriesLabelValuesResponse.LabelKeyValues, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesSummariesRequest(_message.Message):
    __slots__ = ("workspace", "project", "run_names", "summary_queries", "limit", "resume_token")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_NAMES_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_QUERIES_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    run_names: _containers.RepeatedScalarFieldContainer[str]
    summary_queries: _containers.RepeatedScalarFieldContainer[str]
    limit: int
    resume_token: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run_names: _Optional[_Iterable[str]] = ..., summary_queries: _Optional[_Iterable[str]] = ..., limit: _Optional[int] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesSummariesResponse(_message.Message):
    __slots__ = ("run_series_summaries", "resume_token")
    class KeyedSeriesSummary(_message.Message):
        __slots__ = ("definition", "summary_values")
        DEFINITION_FIELD_NUMBER: _ClassVar[int]
        SUMMARY_VALUES_FIELD_NUMBER: _ClassVar[int]
        definition: _series_pb2.SeriesDefinition
        summary_values: _series_pb2.SeriesSummary
        def __init__(self, definition: _Optional[_Union[_series_pb2.SeriesDefinition, _Mapping]] = ..., summary_values: _Optional[_Union[_series_pb2.SeriesSummary, _Mapping]] = ...) -> None: ...
    class RunSeriesSummaries(_message.Message):
        __slots__ = ("run", "series_summaries")
        RUN_FIELD_NUMBER: _ClassVar[int]
        SERIES_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
        run: str
        series_summaries: _containers.RepeatedCompositeFieldContainer[ListSeriesSummariesResponse.KeyedSeriesSummary]
        def __init__(self, run: _Optional[str] = ..., series_summaries: _Optional[_Iterable[_Union[ListSeriesSummariesResponse.KeyedSeriesSummary, _Mapping]]] = ...) -> None: ...
    RUN_SERIES_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    run_series_summaries: _containers.RepeatedCompositeFieldContainer[ListSeriesSummariesResponse.RunSeriesSummaries]
    resume_token: str
    def __init__(self, run_series_summaries: _Optional[_Iterable[_Union[ListSeriesSummariesResponse.RunSeriesSummaries, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListSeriesSummariesAcrossRunsRequest(_message.Message):
    __slots__ = ("workspace", "project", "runs_filter", "summary_queries")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUNS_FILTER_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_QUERIES_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    runs_filter: RunsFilter
    summary_queries: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., runs_filter: _Optional[_Union[RunsFilter, _Mapping]] = ..., summary_queries: _Optional[_Iterable[str]] = ...) -> None: ...

class ListFloatSeriesRequest(_message.Message):
    __slots__ = ("workspace", "project", "run_names", "series_queries", "include_inherited", "include_timestamps", "max_points_per_page", "resume_token", "step_selection")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_NAMES_FIELD_NUMBER: _ClassVar[int]
    SERIES_QUERIES_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_INHERITED_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_TIMESTAMPS_FIELD_NUMBER: _ClassVar[int]
    MAX_POINTS_PER_PAGE_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    STEP_SELECTION_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    run_names: _containers.RepeatedScalarFieldContainer[str]
    series_queries: _containers.RepeatedScalarFieldContainer[str]
    include_inherited: bool
    include_timestamps: bool
    max_points_per_page: int
    resume_token: str
    step_selection: StepSelection
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run_names: _Optional[_Iterable[str]] = ..., series_queries: _Optional[_Iterable[str]] = ..., include_inherited: bool = ..., include_timestamps: bool = ..., max_points_per_page: _Optional[int] = ..., resume_token: _Optional[str] = ..., step_selection: _Optional[_Union[StepSelection, _Mapping]] = ...) -> None: ...

class ListFloatSeriesBucketsRequest(_message.Message):
    __slots__ = ("workspace", "project", "run_names", "series_queries", "include_inherited", "max_buckets_per_page", "buckets_count", "resume_token", "step_selection")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_NAMES_FIELD_NUMBER: _ClassVar[int]
    SERIES_QUERIES_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_INHERITED_FIELD_NUMBER: _ClassVar[int]
    MAX_BUCKETS_PER_PAGE_FIELD_NUMBER: _ClassVar[int]
    BUCKETS_COUNT_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    STEP_SELECTION_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    run_names: _containers.RepeatedScalarFieldContainer[str]
    series_queries: _containers.RepeatedScalarFieldContainer[str]
    include_inherited: bool
    max_buckets_per_page: int
    buckets_count: int
    resume_token: str
    step_selection: StepSelection
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run_names: _Optional[_Iterable[str]] = ..., series_queries: _Optional[_Iterable[str]] = ..., include_inherited: bool = ..., max_buckets_per_page: _Optional[int] = ..., buckets_count: _Optional[int] = ..., resume_token: _Optional[str] = ..., step_selection: _Optional[_Union[StepSelection, _Mapping]] = ...) -> None: ...

class ListFloatSeriesAcrossRunsRequest(_message.Message):
    __slots__ = ("workspace", "project", "runs_filter", "series_queries", "step_range", "include_inherited", "include_timestamps", "max_points_per_page", "resume_token", "max_points_per_series")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUNS_FILTER_FIELD_NUMBER: _ClassVar[int]
    SERIES_QUERIES_FIELD_NUMBER: _ClassVar[int]
    STEP_RANGE_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_INHERITED_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_TIMESTAMPS_FIELD_NUMBER: _ClassVar[int]
    MAX_POINTS_PER_PAGE_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    MAX_POINTS_PER_SERIES_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    runs_filter: RunsFilter
    series_queries: _containers.RepeatedScalarFieldContainer[str]
    step_range: StepRange
    include_inherited: bool
    include_timestamps: bool
    max_points_per_page: int
    resume_token: str
    max_points_per_series: int
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., runs_filter: _Optional[_Union[RunsFilter, _Mapping]] = ..., series_queries: _Optional[_Iterable[str]] = ..., step_range: _Optional[_Union[StepRange, _Mapping]] = ..., include_inherited: bool = ..., include_timestamps: bool = ..., max_points_per_page: _Optional[int] = ..., resume_token: _Optional[str] = ..., max_points_per_series: _Optional[int] = ...) -> None: ...

class ListFloatSeriesResponse(_message.Message):
    __slots__ = ("run_points", "resume_token")
    class SeriesPoints(_message.Message):
        __slots__ = ("definition", "points")
        DEFINITION_FIELD_NUMBER: _ClassVar[int]
        POINTS_FIELD_NUMBER: _ClassVar[int]
        definition: _series_pb2.SeriesDefinition
        points: _series_pb2.FloatSeriesPoints
        def __init__(self, definition: _Optional[_Union[_series_pb2.SeriesDefinition, _Mapping]] = ..., points: _Optional[_Union[_series_pb2.FloatSeriesPoints, _Mapping]] = ...) -> None: ...
    class RunPoints(_message.Message):
        __slots__ = ("run", "series")
        RUN_FIELD_NUMBER: _ClassVar[int]
        SERIES_FIELD_NUMBER: _ClassVar[int]
        run: str
        series: _containers.RepeatedCompositeFieldContainer[ListFloatSeriesResponse.SeriesPoints]
        def __init__(self, run: _Optional[str] = ..., series: _Optional[_Iterable[_Union[ListFloatSeriesResponse.SeriesPoints, _Mapping]]] = ...) -> None: ...
    RUN_POINTS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    run_points: _containers.RepeatedCompositeFieldContainer[ListFloatSeriesResponse.RunPoints]
    resume_token: str
    def __init__(self, run_points: _Optional[_Iterable[_Union[ListFloatSeriesResponse.RunPoints, _Mapping]]] = ..., resume_token: _Optional[str] = ...) -> None: ...

class ListFloatSeriesBucketsResponse(_message.Message):
    __slots__ = ("run_points", "resume_token", "first_step", "last_step", "bucket_step_width")
    class SeriesPoints(_message.Message):
        __slots__ = ("definition", "buckets")
        DEFINITION_FIELD_NUMBER: _ClassVar[int]
        BUCKETS_FIELD_NUMBER: _ClassVar[int]
        definition: _series_pb2.SeriesDefinition
        buckets: _series_pb2.FloatSeriesBuckets
        def __init__(self, definition: _Optional[_Union[_series_pb2.SeriesDefinition, _Mapping]] = ..., buckets: _Optional[_Union[_series_pb2.FloatSeriesBuckets, _Mapping]] = ...) -> None: ...
    class RunPoints(_message.Message):
        __slots__ = ("run", "series")
        RUN_FIELD_NUMBER: _ClassVar[int]
        SERIES_FIELD_NUMBER: _ClassVar[int]
        run: str
        series: _containers.RepeatedCompositeFieldContainer[ListFloatSeriesBucketsResponse.SeriesPoints]
        def __init__(self, run: _Optional[str] = ..., series: _Optional[_Iterable[_Union[ListFloatSeriesBucketsResponse.SeriesPoints, _Mapping]]] = ...) -> None: ...
    RUN_POINTS_FIELD_NUMBER: _ClassVar[int]
    RESUME_TOKEN_FIELD_NUMBER: _ClassVar[int]
    FIRST_STEP_FIELD_NUMBER: _ClassVar[int]
    LAST_STEP_FIELD_NUMBER: _ClassVar[int]
    BUCKET_STEP_WIDTH_FIELD_NUMBER: _ClassVar[int]
    run_points: _containers.RepeatedCompositeFieldContainer[ListFloatSeriesBucketsResponse.RunPoints]
    resume_token: str
    first_step: int
    last_step: int
    bucket_step_width: float
    def __init__(self, run_points: _Optional[_Iterable[_Union[ListFloatSeriesBucketsResponse.RunPoints, _Mapping]]] = ..., resume_token: _Optional[str] = ..., first_step: _Optional[int] = ..., last_step: _Optional[int] = ..., bucket_step_width: _Optional[float] = ...) -> None: ...

class GetRunLineageRequest(_message.Message):
    __slots__ = ("workspace", "project", "run")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    run: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run: _Optional[str] = ...) -> None: ...

class GetRunLineageResponse(_message.Message):
    __slots__ = ("parent_run", "fork_step", "children")
    class ForkChild(_message.Message):
        __slots__ = ("run", "fork_step")
        RUN_FIELD_NUMBER: _ClassVar[int]
        FORK_STEP_FIELD_NUMBER: _ClassVar[int]
        run: str
        fork_step: int
        def __init__(self, run: _Optional[str] = ..., fork_step: _Optional[int] = ...) -> None: ...
    PARENT_RUN_FIELD_NUMBER: _ClassVar[int]
    FORK_STEP_FIELD_NUMBER: _ClassVar[int]
    CHILDREN_FIELD_NUMBER: _ClassVar[int]
    parent_run: str
    fork_step: int
    children: _containers.RepeatedCompositeFieldContainer[GetRunLineageResponse.ForkChild]
    def __init__(self, parent_run: _Optional[str] = ..., fork_step: _Optional[int] = ..., children: _Optional[_Iterable[_Union[GetRunLineageResponse.ForkChild, _Mapping]]] = ...) -> None: ...
