from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegSeriesDefinition(_message.Message):
    __slots__ = ("metric_name", "scale", "labels")
    class LabelsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    metric_name: str
    scale: str
    labels: _containers.ScalarMap[str, str]
    def __init__(self, metric_name: _Optional[str] = ..., scale: _Optional[str] = ..., labels: _Optional[_Mapping[str, str]] = ...) -> None: ...

class AggSeriesDefinition(_message.Message):
    __slots__ = ("metric_name", "scale", "group_labels", "view")
    class GroupLabelsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    GROUP_LABELS_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    metric_name: str
    scale: str
    group_labels: _containers.ScalarMap[str, str]
    view: str
    def __init__(self, metric_name: _Optional[str] = ..., scale: _Optional[str] = ..., group_labels: _Optional[_Mapping[str, str]] = ..., view: _Optional[str] = ...) -> None: ...

class SeriesDefinition(_message.Message):
    __slots__ = ("regular", "aggregated")
    REGULAR_FIELD_NUMBER: _ClassVar[int]
    AGGREGATED_FIELD_NUMBER: _ClassVar[int]
    regular: RegSeriesDefinition
    aggregated: AggSeriesDefinition
    def __init__(self, regular: _Optional[_Union[RegSeriesDefinition, _Mapping]] = ..., aggregated: _Optional[_Union[AggSeriesDefinition, _Mapping]] = ...) -> None: ...

class RegSeriesSummary(_message.Message):
    __slots__ = ("last_step", "last_timestamp", "first", "last", "sum", "count", "min", "max", "std", "avg")
    LAST_STEP_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    FIRST_FIELD_NUMBER: _ClassVar[int]
    LAST_FIELD_NUMBER: _ClassVar[int]
    SUM_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    STD_FIELD_NUMBER: _ClassVar[int]
    AVG_FIELD_NUMBER: _ClassVar[int]
    last_step: int
    last_timestamp: _timestamp_pb2.Timestamp
    first: float
    last: float
    sum: float
    count: int
    min: float
    max: float
    std: float
    avg: float
    def __init__(self, last_step: _Optional[int] = ..., last_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., first: _Optional[float] = ..., last: _Optional[float] = ..., sum: _Optional[float] = ..., count: _Optional[int] = ..., min: _Optional[float] = ..., max: _Optional[float] = ..., std: _Optional[float] = ..., avg: _Optional[float] = ...) -> None: ...

class AggSeriesSummary(_message.Message):
    __slots__ = ("last_step", "last_timestamp", "sum", "count", "min", "max", "std", "avg", "last_count", "last_min", "last_max", "last_avg", "last_std", "first_count", "first_min", "first_max", "first_avg", "first_std")
    LAST_STEP_FIELD_NUMBER: _ClassVar[int]
    LAST_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    SUM_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    MIN_FIELD_NUMBER: _ClassVar[int]
    MAX_FIELD_NUMBER: _ClassVar[int]
    STD_FIELD_NUMBER: _ClassVar[int]
    AVG_FIELD_NUMBER: _ClassVar[int]
    LAST_COUNT_FIELD_NUMBER: _ClassVar[int]
    LAST_MIN_FIELD_NUMBER: _ClassVar[int]
    LAST_MAX_FIELD_NUMBER: _ClassVar[int]
    LAST_AVG_FIELD_NUMBER: _ClassVar[int]
    LAST_STD_FIELD_NUMBER: _ClassVar[int]
    FIRST_COUNT_FIELD_NUMBER: _ClassVar[int]
    FIRST_MIN_FIELD_NUMBER: _ClassVar[int]
    FIRST_MAX_FIELD_NUMBER: _ClassVar[int]
    FIRST_AVG_FIELD_NUMBER: _ClassVar[int]
    FIRST_STD_FIELD_NUMBER: _ClassVar[int]
    last_step: int
    last_timestamp: _timestamp_pb2.Timestamp
    sum: float
    count: int
    min: float
    max: float
    std: float
    avg: float
    last_count: int
    last_min: float
    last_max: float
    last_avg: float
    last_std: float
    first_count: int
    first_min: float
    first_max: float
    first_avg: float
    first_std: float
    def __init__(self, last_step: _Optional[int] = ..., last_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., sum: _Optional[float] = ..., count: _Optional[int] = ..., min: _Optional[float] = ..., max: _Optional[float] = ..., std: _Optional[float] = ..., avg: _Optional[float] = ..., last_count: _Optional[int] = ..., last_min: _Optional[float] = ..., last_max: _Optional[float] = ..., last_avg: _Optional[float] = ..., last_std: _Optional[float] = ..., first_count: _Optional[int] = ..., first_min: _Optional[float] = ..., first_max: _Optional[float] = ..., first_avg: _Optional[float] = ..., first_std: _Optional[float] = ...) -> None: ...

class SeriesSummary(_message.Message):
    __slots__ = ("regular", "aggregated")
    REGULAR_FIELD_NUMBER: _ClassVar[int]
    AGGREGATED_FIELD_NUMBER: _ClassVar[int]
    regular: RegSeriesSummary
    aggregated: AggSeriesSummary
    def __init__(self, regular: _Optional[_Union[RegSeriesSummary, _Mapping]] = ..., aggregated: _Optional[_Union[AggSeriesSummary, _Mapping]] = ...) -> None: ...

class FloatSeriesPoints(_message.Message):
    __slots__ = ("steps", "values", "timestamp_millis")
    STEPS_FIELD_NUMBER: _ClassVar[int]
    VALUES_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_MILLIS_FIELD_NUMBER: _ClassVar[int]
    steps: _containers.RepeatedScalarFieldContainer[int]
    values: _containers.RepeatedScalarFieldContainer[float]
    timestamp_millis: _containers.RepeatedScalarFieldContainer[int]
    def __init__(self, steps: _Optional[_Iterable[int]] = ..., values: _Optional[_Iterable[float]] = ..., timestamp_millis: _Optional[_Iterable[int]] = ...) -> None: ...

class FloatSeriesBuckets(_message.Message):
    __slots__ = ("buckets",)
    class BucketStats(_message.Message):
        __slots__ = ("count", "sum", "min", "max")
        COUNT_FIELD_NUMBER: _ClassVar[int]
        SUM_FIELD_NUMBER: _ClassVar[int]
        MIN_FIELD_NUMBER: _ClassVar[int]
        MAX_FIELD_NUMBER: _ClassVar[int]
        count: int
        sum: float
        min: float
        max: float
        def __init__(self, count: _Optional[int] = ..., sum: _Optional[float] = ..., min: _Optional[float] = ..., max: _Optional[float] = ...) -> None: ...
    class Bucket(_message.Message):
        __slots__ = ("y", "stats")
        Y_FIELD_NUMBER: _ClassVar[int]
        STATS_FIELD_NUMBER: _ClassVar[int]
        y: float
        stats: FloatSeriesBuckets.BucketStats
        def __init__(self, y: _Optional[float] = ..., stats: _Optional[_Union[FloatSeriesBuckets.BucketStats, _Mapping]] = ...) -> None: ...
    BUCKETS_FIELD_NUMBER: _ClassVar[int]
    buckets: _containers.RepeatedCompositeFieldContainer[FloatSeriesBuckets.Bucket]
    def __init__(self, buckets: _Optional[_Iterable[_Union[FloatSeriesBuckets.Bucket, _Mapping]]] = ...) -> None: ...
