from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AttributeKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ATTR_KIND_UNDEFINED: _ClassVar[AttributeKind]
    ATTR_KIND_BOOL: _ClassVar[AttributeKind]
    ATTR_KIND_STRING: _ClassVar[AttributeKind]
    ATTR_KIND_FLOAT: _ClassVar[AttributeKind]
    ATTR_KIND_INT: _ClassVar[AttributeKind]
    ATTR_KIND_STRING_SET: _ClassVar[AttributeKind]
    ATTR_KIND_TIMESTAMP: _ClassVar[AttributeKind]
ATTR_KIND_UNDEFINED: AttributeKind
ATTR_KIND_BOOL: AttributeKind
ATTR_KIND_STRING: AttributeKind
ATTR_KIND_FLOAT: AttributeKind
ATTR_KIND_INT: AttributeKind
ATTR_KIND_STRING_SET: AttributeKind
ATTR_KIND_TIMESTAMP: AttributeKind

class StringSet(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, values: _Optional[_Iterable[str]] = ...) -> None: ...

class Attribute(_message.Message):
    __slots__ = ("path", "bool_value", "string_value", "float_value", "int_value", "string_set_value", "timestamp_value")
    PATH_FIELD_NUMBER: _ClassVar[int]
    BOOL_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    FLOAT_VALUE_FIELD_NUMBER: _ClassVar[int]
    INT_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_SET_VALUE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_VALUE_FIELD_NUMBER: _ClassVar[int]
    path: str
    bool_value: bool
    string_value: str
    float_value: float
    int_value: int
    string_set_value: StringSet
    timestamp_value: _timestamp_pb2.Timestamp
    def __init__(self, path: _Optional[str] = ..., bool_value: bool = ..., string_value: _Optional[str] = ..., float_value: _Optional[float] = ..., int_value: _Optional[int] = ..., string_set_value: _Optional[_Union[StringSet, _Mapping]] = ..., timestamp_value: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
