from metrana_protobuf.common.v1 import attributes_pb2 as _attributes_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class OrderingMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ORDERING_MODE_UNDEFINED: _ClassVar[OrderingMode]
    ORDERING_MODE_RELATIVE_ORDERED: _ClassVar[OrderingMode]
    ORDERING_MODE_ABSOLUTE_UNORDERED: _ClassVar[OrderingMode]
ORDERING_MODE_UNDEFINED: OrderingMode
ORDERING_MODE_RELATIVE_ORDERED: OrderingMode
ORDERING_MODE_ABSOLUTE_UNORDERED: OrderingMode

class StringSetDelta(_message.Message):
    __slots__ = ("added_values", "removed_values")
    ADDED_VALUES_FIELD_NUMBER: _ClassVar[int]
    REMOVED_VALUES_FIELD_NUMBER: _ClassVar[int]
    added_values: _containers.RepeatedScalarFieldContainer[str]
    removed_values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, added_values: _Optional[_Iterable[str]] = ..., removed_values: _Optional[_Iterable[str]] = ...) -> None: ...

class AttributeUpdate(_message.Message):
    __slots__ = ("path", "bool_value", "string_value", "float_value", "int_value", "string_set_value", "string_set_delta_value", "timestamp_value")
    PATH_FIELD_NUMBER: _ClassVar[int]
    BOOL_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_VALUE_FIELD_NUMBER: _ClassVar[int]
    FLOAT_VALUE_FIELD_NUMBER: _ClassVar[int]
    INT_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_SET_VALUE_FIELD_NUMBER: _ClassVar[int]
    STRING_SET_DELTA_VALUE_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_VALUE_FIELD_NUMBER: _ClassVar[int]
    path: str
    bool_value: bool
    string_value: str
    float_value: float
    int_value: int
    string_set_value: _attributes_pb2.StringSet
    string_set_delta_value: StringSetDelta
    timestamp_value: _timestamp_pb2.Timestamp
    def __init__(self, path: _Optional[str] = ..., bool_value: bool = ..., string_value: _Optional[str] = ..., float_value: _Optional[float] = ..., int_value: _Optional[int] = ..., string_set_value: _Optional[_Union[_attributes_pb2.StringSet, _Mapping]] = ..., string_set_delta_value: _Optional[_Union[StringSetDelta, _Mapping]] = ..., timestamp_value: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Point(_message.Message):
    __slots__ = ("step", "timestamp", "float_value")
    STEP_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    FLOAT_VALUE_FIELD_NUMBER: _ClassVar[int]
    step: int
    timestamp: _timestamp_pb2.Timestamp
    float_value: float
    def __init__(self, step: _Optional[int] = ..., timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., float_value: _Optional[float] = ...) -> None: ...

class SeriesUpdate(_message.Message):
    __slots__ = ("metric_name", "scale", "labels", "points", "ordering")
    class LabelsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    LABELS_FIELD_NUMBER: _ClassVar[int]
    POINTS_FIELD_NUMBER: _ClassVar[int]
    ORDERING_FIELD_NUMBER: _ClassVar[int]
    metric_name: str
    scale: str
    labels: _containers.ScalarMap[str, str]
    points: _containers.RepeatedCompositeFieldContainer[Point]
    ordering: OrderingMode
    def __init__(self, metric_name: _Optional[str] = ..., scale: _Optional[str] = ..., labels: _Optional[_Mapping[str, str]] = ..., points: _Optional[_Iterable[_Union[Point, _Mapping]]] = ..., ordering: _Optional[_Union[OrderingMode, str]] = ...) -> None: ...
