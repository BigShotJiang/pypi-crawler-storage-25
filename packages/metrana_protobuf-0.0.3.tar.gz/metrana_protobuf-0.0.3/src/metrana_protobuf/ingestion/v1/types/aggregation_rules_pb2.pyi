from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AggregationFn(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    AGGREGATION_FN_UNSPECIFIED: _ClassVar[AggregationFn]
    AGGREGATION_FN_MEAN: _ClassVar[AggregationFn]
    AGGREGATION_FN_MAX: _ClassVar[AggregationFn]
    AGGREGATION_FN_SUM: _ClassVar[AggregationFn]
    AGGREGATION_FN_MIN: _ClassVar[AggregationFn]
    AGGREGATION_FN_STD_DEV: _ClassVar[AggregationFn]
    AGGREGATION_FN_COUNT: _ClassVar[AggregationFn]
AGGREGATION_FN_UNSPECIFIED: AggregationFn
AGGREGATION_FN_MEAN: AggregationFn
AGGREGATION_FN_MAX: AggregationFn
AGGREGATION_FN_SUM: AggregationFn
AGGREGATION_FN_MIN: AggregationFn
AGGREGATION_FN_STD_DEV: AggregationFn
AGGREGATION_FN_COUNT: AggregationFn

class AggregationRule(_message.Message):
    __slots__ = ("metric_name", "source_scale", "output_scale", "fns", "aggregate_over_labels", "output_metric_name", "output_name_suffix")
    METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    SOURCE_SCALE_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_SCALE_FIELD_NUMBER: _ClassVar[int]
    FNS_FIELD_NUMBER: _ClassVar[int]
    AGGREGATE_OVER_LABELS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_METRIC_NAME_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_NAME_SUFFIX_FIELD_NUMBER: _ClassVar[int]
    metric_name: str
    source_scale: str
    output_scale: str
    fns: _containers.RepeatedScalarFieldContainer[AggregationFn]
    aggregate_over_labels: _containers.RepeatedScalarFieldContainer[str]
    output_metric_name: str
    output_name_suffix: str
    def __init__(self, metric_name: _Optional[str] = ..., source_scale: _Optional[str] = ..., output_scale: _Optional[str] = ..., fns: _Optional[_Iterable[_Union[AggregationFn, str]]] = ..., aggregate_over_labels: _Optional[_Iterable[str]] = ..., output_metric_name: _Optional[str] = ..., output_name_suffix: _Optional[str] = ...) -> None: ...
