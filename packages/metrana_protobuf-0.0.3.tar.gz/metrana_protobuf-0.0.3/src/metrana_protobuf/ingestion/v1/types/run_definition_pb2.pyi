from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ForkPoint(_message.Message):
    __slots__ = ("parent_run_name", "fork_step")
    PARENT_RUN_NAME_FIELD_NUMBER: _ClassVar[int]
    FORK_STEP_FIELD_NUMBER: _ClassVar[int]
    parent_run_name: str
    fork_step: int
    def __init__(self, parent_run_name: _Optional[str] = ..., fork_step: _Optional[int] = ...) -> None: ...

class Run(_message.Message):
    __slots__ = ("workspace", "project", "run_name", "experiment", "creation_time", "fork_point", "directory", "exp_directory")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    RUN_NAME_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    CREATION_TIME_FIELD_NUMBER: _ClassVar[int]
    FORK_POINT_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    EXP_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    run_name: str
    experiment: str
    creation_time: _timestamp_pb2.Timestamp
    fork_point: ForkPoint
    directory: str
    exp_directory: str
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run_name: _Optional[str] = ..., experiment: _Optional[str] = ..., creation_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., fork_point: _Optional[_Union[ForkPoint, _Mapping]] = ..., directory: _Optional[str] = ..., exp_directory: _Optional[str] = ...) -> None: ...
