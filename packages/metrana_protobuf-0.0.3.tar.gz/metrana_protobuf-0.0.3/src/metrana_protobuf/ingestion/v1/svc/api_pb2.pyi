from metrana_protobuf.ingestion.v1.types import aggregation_rules_pb2 as _aggregation_rules_pb2
from metrana_protobuf.ingestion.v1.types import run_definition_pb2 as _run_definition_pb2
from metrana_protobuf.ingestion.v1.types import updates_pb2 as _updates_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateRunRequest(_message.Message):
    __slots__ = ("run", "create_project_if_missing", "aggregation_rules")
    RUN_FIELD_NUMBER: _ClassVar[int]
    CREATE_PROJECT_IF_MISSING_FIELD_NUMBER: _ClassVar[int]
    AGGREGATION_RULES_FIELD_NUMBER: _ClassVar[int]
    run: _run_definition_pb2.Run
    create_project_if_missing: bool
    aggregation_rules: _containers.RepeatedCompositeFieldContainer[_aggregation_rules_pb2.AggregationRule]
    def __init__(self, run: _Optional[_Union[_run_definition_pb2.Run, _Mapping]] = ..., create_project_if_missing: bool = ..., aggregation_rules: _Optional[_Iterable[_Union[_aggregation_rules_pb2.AggregationRule, _Mapping]]] = ...) -> None: ...

class CreateRunResponse(_message.Message):
    __slots__ = ("operation_id",)
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    operation_id: str
    def __init__(self, operation_id: _Optional[str] = ...) -> None: ...

class UpdateRunsRequest(_message.Message):
    __slots__ = ("session_id", "run_updates")
    class RunUpdate(_message.Message):
        __slots__ = ("workspace", "project", "run_name", "attributes", "series")
        WORKSPACE_FIELD_NUMBER: _ClassVar[int]
        PROJECT_FIELD_NUMBER: _ClassVar[int]
        RUN_NAME_FIELD_NUMBER: _ClassVar[int]
        ATTRIBUTES_FIELD_NUMBER: _ClassVar[int]
        SERIES_FIELD_NUMBER: _ClassVar[int]
        workspace: str
        project: str
        run_name: str
        attributes: _containers.RepeatedCompositeFieldContainer[_updates_pb2.AttributeUpdate]
        series: _containers.RepeatedCompositeFieldContainer[_updates_pb2.SeriesUpdate]
        def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., run_name: _Optional[str] = ..., attributes: _Optional[_Iterable[_Union[_updates_pb2.AttributeUpdate, _Mapping]]] = ..., series: _Optional[_Iterable[_Union[_updates_pb2.SeriesUpdate, _Mapping]]] = ...) -> None: ...
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    RUN_UPDATES_FIELD_NUMBER: _ClassVar[int]
    session_id: int
    run_updates: _containers.RepeatedCompositeFieldContainer[UpdateRunsRequest.RunUpdate]
    def __init__(self, session_id: _Optional[int] = ..., run_updates: _Optional[_Iterable[_Union[UpdateRunsRequest.RunUpdate, _Mapping]]] = ...) -> None: ...

class UpdateRunsResponse(_message.Message):
    __slots__ = ("operation_id",)
    OPERATION_ID_FIELD_NUMBER: _ClassVar[int]
    operation_id: str
    def __init__(self, operation_id: _Optional[str] = ...) -> None: ...

class CheckOpStatusesRequest(_message.Message):
    __slots__ = ("workspace", "project", "operation_ids")
    WORKSPACE_FIELD_NUMBER: _ClassVar[int]
    PROJECT_FIELD_NUMBER: _ClassVar[int]
    OPERATION_IDS_FIELD_NUMBER: _ClassVar[int]
    workspace: str
    project: str
    operation_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, workspace: _Optional[str] = ..., project: _Optional[str] = ..., operation_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class CheckOpStatusesResponse(_message.Message):
    __slots__ = ("operation_statuses",)
    class OperationStatusesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: bool
        def __init__(self, key: _Optional[str] = ..., value: bool = ...) -> None: ...
    OPERATION_STATUSES_FIELD_NUMBER: _ClassVar[int]
    operation_statuses: _containers.ScalarMap[str, bool]
    def __init__(self, operation_statuses: _Optional[_Mapping[str, bool]] = ...) -> None: ...
