# metrana-models-proto

Python protobuf models for Metrana.

## Building

To compile the protobuf files, first install the development dependencies:

```bash
pip install -e ".[dev]"
```

Then run the build script:

```bash
python build_protobuf.py
```

This will generate the Python protobuf files in:
* `src/metrana_protobuf/common/`.
* `src/metrana_protobuf/ingestion/`.
* `src/metrana_protobuf/management/`.
* `src/metrana_protobuf/query/`.

## Usage

```python
from metrana_protobuf.common.v1 import attributes_pb2
from metrana_protobuf.ingestion.v1 import svc

# Create a StringSet message
string_set = attributes_pb2.StringSet(values=["a", "b", "c"])

# Use the gRPC service stubs
# stub = svc.IngestServiceStub(channel)
```

## Development

The generated `*_pb2.py` and `*_pb2_grpc.py` files are created by the build script.
Type stubs (`*.pyi`) are also generated for better IDE support.
