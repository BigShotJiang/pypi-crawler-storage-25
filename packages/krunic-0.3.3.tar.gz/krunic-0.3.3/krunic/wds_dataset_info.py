#!/usr/bin/env python3
"""Generate dataset_info.json for a WebDataset directory.

Scans all shards in each split (train / val / test) and writes
wds/dataset_info.json containing class names, shard counts, and sample counts.

Usage:
    wds-dataset-info /path/to/dataset
    wds-dataset-info /path/to/dataset --splits train val
    wds-dataset-info /path/to/dataset --classes tumor normal
"""

import argparse
import json
import sys
import tarfile
from collections import Counter
from pathlib import Path


_VERSION = "0.1.0"


def _collect_split(wds_dir: Path, split: str) -> tuple[int, int, list[str]]:
    """Return (num_shards, num_samples, sorted_unique_classes) for a split."""
    split_dir = wds_dir / split
    shards = sorted(split_dir.glob("shard-*.tar"))
    if not shards:
        return 0, 0, []

    classes: set[str] = set()
    total = 0
    for shard in shards:
        with tarfile.open(shard) as tf:
            for member in tf.getmembers():
                if member.name.endswith(".cls"):
                    raw = tf.extractfile(member).read().decode().strip()
                    classes.add(raw)
                    total += 1

    return len(shards), total, sorted(classes)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--version", action="version", version=f"%(prog)s {_VERSION}")
    parser.add_argument("data", help="Dataset root containing a wds/ subdirectory")
    parser.add_argument("--splits", nargs="+", default=None,
                        help="Splits to scan (default: auto-detect train/val/test)")
    parser.add_argument("--classes", nargs="+", default=None,
                        help="Override class list (sets fixed ordering; skips class scan)")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing dataset_info.json without prompting")
    args = parser.parse_args()

    root = Path(args.data)
    wds_dir = root / "wds"
    if not wds_dir.is_dir():
        sys.exit(f"Error: {wds_dir} is not a directory")

    # Determine splits to scan
    if args.splits:
        splits = args.splits
    else:
        splits = [d.name for d in sorted(wds_dir.iterdir())
                  if d.is_dir() and d.name in ("train", "val", "test")]
    if not splits:
        sys.exit(f"Error: no train/val/test subdirectories found under {wds_dir}")

    out_path = wds_dir / "dataset_info.json"
    if out_path.exists() and not args.force:
        answer = input(f"{out_path} already exists. Overwrite? [y/N] ").strip().lower()
        if answer != "y":
            sys.exit("Aborted.")

    all_classes: list[str] | None = args.classes
    splits_meta: dict = {}

    for split in splits:
        split_dir = wds_dir / split
        if not split_dir.is_dir():
            print(f"Warning: {split_dir} not found, skipping", file=sys.stderr)
            continue
        print(f"Scanning {split}...", end="", flush=True)
        n_shards, n_samples, found_classes = _collect_split(wds_dir, split)
        print(f" {n_shards} shards, {n_samples:,} samples, {len(found_classes)} unique classes")

        splits_meta[split] = {"num_shards": n_shards, "num_samples": n_samples}

        if all_classes is None and found_classes:
            all_classes = found_classes
        elif all_classes is not None and found_classes:
            # Warn if this split has classes not seen before
            extra = set(found_classes) - set(all_classes)
            if extra:
                print(f"  Warning: {split} has classes not in others: {sorted(extra)}", file=sys.stderr)
                all_classes = sorted(set(all_classes) | extra)

    if not all_classes:
        sys.exit("Error: could not determine class list — use --classes to specify manually")

    info = {
        "format": "webdataset",
        "classes": all_classes,
        "splits": splits_meta,
    }

    with open(out_path, "w") as f:
        json.dump(info, f, indent=2)
        f.write("\n")

    print(f"\nWrote {out_path}")
    print(f"  classes ({len(all_classes)}): {all_classes}")
    for split, meta in splits_meta.items():
        print(f"  {split}: {meta['num_shards']} shards, {meta['num_samples']:,} samples")


if __name__ == "__main__":
    main()
