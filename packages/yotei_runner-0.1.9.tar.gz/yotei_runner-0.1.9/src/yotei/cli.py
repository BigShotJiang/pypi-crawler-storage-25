"""Where: CLI module. What: expose task management and scheduler-run commands. Why: keep the user-facing workflow scriptable inside a container."""

from __future__ import annotations

from argparse import ArgumentParser, RawDescriptionHelpFormatter, REMAINDER, SUPPRESS
from datetime import datetime
from pathlib import Path
from time import sleep
from urllib.parse import quote
import json
import sqlite3
import subprocess
import sys
import traceback
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from . import __version__
from .config import CONFIG_ENV_VAR, init_config, load_config, update_default_model
from .db import (
    SchemaVersionError,
    TaskRecord,
    advance_task_schedule,
    connect,
    create_task,
    delete_task,
    disable_task,
    dequeue_next,
    due_tasks,
    enqueue_run,
    finish_run,
    has_running_run,
    initialize,
    list_tasks,
    mark_stale_running_runs,
    record_notification_error,
    remove_queue_item,
    get_task,
    set_task_enabled,
    start_run,
    update_task,
    update_run_log_path,
    update_run_runner_pid,
    utc_now,
)
from .notify import format_notification, send_telegram_message
from .runner import run_codex_task
from .schedule import is_one_time, next_run_at, parse_schedule


SANDBOX_MODE_HELP = "Codex sandbox mode to use for task execution."
SANDBOX_MODES = ("read-only", "workspace-write", "danger-full-access")
CODEX_EXEC_ARGS_HELP = (
    "Additional raw arguments for codex exec. Place them after -- so Yotei can keep owning the prompt and session."
)
PUBLIC_COMMANDS_METAVAR = "{schedule,status,prompt,pause,resume,kickstart,edit,remove,config,run}"


SCHEDULE_GRAMMAR_HELP = """Supported schedules:
  in <int>m, in <int>h, once in <int>m, once in <int>h
  every <int>m, every <int>h
  daily H:MM, weekdays H:MM, mon,wed H:MM
  cron "<minute> <hour> <day-of-month> <month> <day-of-week>"

Cron supports five numeric fields with *, comma lists, ranges, and slash steps.
It does not support names, ?, L, W, #, wraparound ranges, or advanced cron semantics.
Day-of-month and day-of-week use AND semantics."""


CODEX_EXEC_PASSTHROUGH_HELP = """Codex exec passthrough:
  Append -- <codex exec options...> to schedule or edit to store raw options for codex exec.
  Example: yotei schedule --task repo --when "every 2h" --prompt "Review" -- --profile prod --ephemeral
  Yotei still owns the prompt, session selection, model, workspace, and JSONL output parsing."""


EDIT_CODEX_EXEC_PASSTHROUGH_HELP = (
    CODEX_EXEC_PASSTHROUGH_HELP
    + "\n  Use edit --clear-codex-exec-args to remove stored passthrough options."
)


def build_parser() -> ArgumentParser:
    parser = ArgumentParser(
        prog="yotei",
        description="Schedule coding-agent tasks inside a Linux container.",
        epilog="For scheduled Codex options, use: yotei schedule ... -- <codex exec options...>",
        formatter_class=RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--config",
        help=f"Path to config.toml. Defaults to {CONFIG_ENV_VAR}, then .automation/yotei/config.toml.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command", required=True, metavar=PUBLIC_COMMANDS_METAVAR)

    schedule_parser = subparsers.add_parser(
        "schedule",
        help="Register a scheduled task",
        description=f"{SCHEDULE_GRAMMAR_HELP}\n\n{CODEX_EXEC_PASSTHROUGH_HELP}",
        formatter_class=RawDescriptionHelpFormatter,
    )
    schedule_parser.add_argument("--task", required=True, help="Unique task identifier")
    schedule_parser.add_argument("--when", required=True, help="Human-friendly schedule string")
    schedule_parser.add_argument("--prompt", required=True, help="Inline prompt to send to Codex")
    schedule_parser.add_argument("--agent", default="codex", choices=["codex"], help="Agent to run")
    schedule_parser.add_argument("--model", help="Override the default model")
    schedule_parser.add_argument("--session-mode", choices=["fresh", "resume"], default="fresh")
    schedule_parser.add_argument("--chat-id", help="Telegram chat id for notifications. Defaults to telegram.chat_id.")
    schedule_parser.add_argument("--workspace", help="Workspace directory for this task. Defaults to the current directory.")
    _add_sandbox_arguments(schedule_parser)
    schedule_parser.add_argument(
        "codex_exec_args",
        nargs=REMAINDER,
        metavar="-- [CODEX_EXEC_ARG ...]",
        help=CODEX_EXEC_ARGS_HELP,
    )

    status_parser = subparsers.add_parser("status", help="Show scheduled task status")
    status_parser.add_argument("--json", action="store_true", help="Render task output as JSON")

    prompt_parser = subparsers.add_parser("prompt", help="Show a scheduled task prompt")
    prompt_parser.add_argument("--task", required=True, help="Task identifier to show")

    pause_parser = subparsers.add_parser("pause", help="Pause a scheduled task")
    pause_parser.add_argument("--task", required=True, help="Task identifier to pause")

    resume_parser = subparsers.add_parser("resume", help="Resume a paused scheduled task")
    resume_parser.add_argument("--task", required=True, help="Task identifier to resume")

    kickstart_parser = subparsers.add_parser(
        "kickstart",
        help="Start a scheduled task immediately once",
        description=(
            "Start a scheduled task immediately once without changing its normal next run time. "
            "If the task is already running, queue one immediate run instead."
        ),
    )
    kickstart_parser.add_argument("--task", required=True, help="Task identifier to start immediately")

    kickstart_worker_parser = subparsers.add_parser("_kickstart-worker", help=SUPPRESS)
    kickstart_worker_parser.add_argument("--task", required=True)
    kickstart_worker_parser.add_argument("--run-id", required=True)
    # argparse still lists suppressed subcommands unless their help action is removed.
    subparsers._choices_actions.pop()

    edit_parser = subparsers.add_parser(
        "edit",
        help="Edit editable fields on a scheduled task",
        description=f"{SCHEDULE_GRAMMAR_HELP}\n\n{EDIT_CODEX_EXEC_PASSTHROUGH_HELP}",
        formatter_class=RawDescriptionHelpFormatter,
    )
    edit_parser.add_argument("--task", required=True, help="Task identifier to edit")
    edit_parser.add_argument("--when", help="Replacement schedule string")
    edit_parser.add_argument("--prompt", help="Replacement inline prompt")
    edit_parser.add_argument("--agent", choices=["codex"], help="Replacement agent")
    edit_parser.add_argument("--model", help="Replacement model")
    edit_parser.add_argument("--session-mode", choices=["fresh", "resume"], help="Replacement session mode")
    edit_parser.add_argument("--chat-id", help="Replacement Telegram chat id")
    edit_parser.add_argument("--workspace", help="Replacement workspace directory")
    edit_parser.add_argument(
        "--clear-codex-exec-args",
        action="store_true",
        help="Remove previously configured raw codex exec passthrough arguments.",
    )
    _add_sandbox_arguments(edit_parser)
    edit_parser.add_argument(
        "codex_exec_args",
        nargs=REMAINDER,
        metavar="-- [CODEX_EXEC_ARG ...]",
        help=CODEX_EXEC_ARGS_HELP,
    )

    remove_parser = subparsers.add_parser("remove", help="Remove a scheduled task")
    remove_parser.add_argument("--task", required=True, help="Task identifier to remove")

    config_parser = subparsers.add_parser("config", help="Read or update config defaults")
    config_subparsers = config_parser.add_subparsers(dest="config_command", required=True)
    init_parser = config_subparsers.add_parser("init", help="Create a user-level config file")
    init_parser.add_argument("--path", help="Config path to write. Defaults to the user config path.")
    init_parser.add_argument("--force", action="store_true", help="Overwrite an existing config file")
    config_subparsers.add_parser("get-default-model", help="Print the default model")
    set_model = config_subparsers.add_parser("set-default-model", help="Update the default model")
    set_model.add_argument("model", help="Model name from the allowlist")

    run_parser = subparsers.add_parser(
        "run",
        help="Run the scheduler loop",
        description=(
            "Run the scheduler loop. Start only one active runner per state database; "
            "Yotei does not enforce cross-process locking yet."
        ),
    )
    run_parser.add_argument(
        "--once",
        action="store_true",
        help="Process one scheduling pass and exit; do not start a long-running scheduler.",
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    connection = None
    try:
        if args.command == "config" and args.config_command == "init":
            return _handle_config_init(args)
        config = load_config(Path(args.config) if args.config else None)
        connection = connect(config.paths.state_db)
        initialize(connection)

        if args.command == "schedule":
            return _handle_schedule(args, config, connection)
        if args.command == "status":
            return _handle_status(args, connection)
        if args.command == "prompt":
            return _handle_prompt(args, connection)
        if args.command == "pause":
            return _handle_pause(args, connection)
        if args.command == "resume":
            return _handle_resume(args, config, connection)
        if args.command == "kickstart":
            return _handle_kickstart(args, config, connection)
        if args.command == "_kickstart-worker":
            return _handle_kickstart_worker(args, config, connection)
        if args.command == "edit":
            return _handle_edit(args, config, connection)
        if args.command == "remove":
            return _handle_remove(args, connection)
        if args.command == "config":
            return _handle_config(args)
        if args.command == "run":
            return _handle_run(args, config, connection)
        parser.error(f"Unknown command {args.command!r}")
        return 2
    except (
        FileNotFoundError,
        KeyError,
        OSError,
        SchemaVersionError,
        ValueError,
        sqlite3.Error,
        ZoneInfoNotFoundError,
    ) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    finally:
        if connection is not None:
            connection.close()


def _handle_schedule(args, config, connection) -> int:
    schedule_spec = parse_schedule(args.when)
    model = args.model or config.codex.default_model
    if model not in config.codex.allowed_models:
        raise ValueError(f"Model {model!r} is not allowed. Allowed models: {', '.join(config.codex.allowed_models)}")
    chat_id = args.chat_id or config.telegram.chat_id
    if not chat_id:
        raise ValueError("Missing Telegram chat id. Pass --chat-id or set telegram.chat_id in config.")
    workspace_root = _resolve_workspace(args.workspace)
    sandbox_mode = _sandbox_mode_from_args(args, default=config.codex.default_sandbox_mode)
    codex_exec_args = _codex_exec_args_from_raw(args.codex_exec_args)
    now = datetime.now(ZoneInfo(config.scheduler.timezone))
    first_run = next_run_at(schedule_spec, now, config.scheduler.timezone)
    task = TaskRecord(
        task_id=args.task,
        schedule_text=args.when,
        schedule_kind=schedule_spec.kind,
        schedule_value=schedule_spec.value,
        prompt=args.prompt,
        agent=args.agent,
        model=model,
        session_mode=args.session_mode,
        session_id=None,
        chat_id=chat_id,
        workspace_root=str(workspace_root),
        sandbox_mode=sandbox_mode,
        codex_exec_args=codex_exec_args,
        next_run_at=_to_utc_iso(first_run),
        last_run_at=None,
        enabled=True,
    )
    create_task(connection, task)
    print(f"Scheduled task {task.task_id} with next run at {task.next_run_at}.")
    return 0


def _handle_status(args, connection) -> int:
    mark_stale_running_runs(connection)
    rows = list_tasks(connection)
    if args.json:
        print(json.dumps([dict(row) for row in rows], indent=2))
        return 0
    if not rows:
        print("No scheduled tasks.")
        return 0
    for row in rows:
        print(
            " | ".join(
                [
                    row["task_id"],
                    f"next={row['next_run_at']}",
                    f"model={row['model']}",
                    f"session_mode={row['session_mode']}",
                    f"session_id={row['session_id'] or '-'}",
                    f"sandbox={row['sandbox_mode']}",
                    f"codex_args={len(_decode_codex_exec_args(row['codex_exec_args']))}",
                    f"enabled={bool(row['enabled'])}",
                    f"workspace={row['workspace_root'] or 'needs workspace'}",
                    f"queued={row['queued_runs']}",
                    f"last_status={row['last_status'] or 'never'}",
                ]
            )
        )
    return 0


def _handle_prompt(args, connection) -> int:
    row = get_task(connection, args.task)
    if row is None:
        print(f"Task {args.task} was not found.")
        return 1
    print(row["prompt"])
    return 0


def _handle_remove(args, connection) -> int:
    deleted = delete_task(connection, args.task)
    if deleted == 0:
        print(f"Task {args.task} was not found.")
        return 1
    print(f"Removed task {args.task}.")
    return 0


def _handle_pause(args, connection) -> int:
    updated = set_task_enabled(connection, args.task, False)
    if updated == 0:
        print(f"Task {args.task} was not found.")
        return 1
    print(f"Paused task {args.task}.")
    return 0


def _handle_resume(args, config, connection) -> int:
    row = get_task(connection, args.task)
    if row is None:
        print(f"Task {args.task} was not found.")
        return 1
    spec = parse_schedule(row["schedule_text"])
    next_run = next_run_at(spec, datetime.now(ZoneInfo(config.scheduler.timezone)), config.scheduler.timezone)
    set_task_enabled(connection, args.task, True, _to_utc_iso(next_run))
    print(f"Resumed task {args.task} with next run at {_to_utc_iso(next_run)}.")
    return 0


def _handle_kickstart(args, config, connection) -> int:
    mark_stale_running_runs(connection)
    row = get_task(connection, args.task)
    if row is None:
        print(f"Task {args.task} was not found.")
        return 1
    due_at = utc_now()
    if has_running_run(connection, args.task):
        enqueue_run(connection, args.task, due_at)
        print(f"Queued immediate run for task {args.task}.")
        return 0
    run_id = start_run(connection, row["task_id"], str(config.paths.logs_dir / "pending.log"))
    try:
        process = _spawn_kickstart_worker(config, row["task_id"], run_id)
    except OSError as exc:
        message = f"Failed to start kickstart worker: {exc}"
        finish_run(
            connection,
            run_id,
            status="failed",
            summary=message,
            exit_code=127,
            session_id=row["session_id"],
            error_text=message,
        )
        raise ValueError(message) from exc
    update_run_runner_pid(connection, run_id, process.pid)
    print(f"Started immediate run for task {args.task}.")
    return 0


def _handle_kickstart_worker(args, config, connection) -> int:
    row = get_task(connection, args.task)
    if row is None:
        return 1
    try:
        _execute_task(config, connection, row, run_id=args.run_id)
    except KeyboardInterrupt:
        return _handle_user_interrupt()
    return 0


def _spawn_kickstart_worker(config, task_id: str, run_id: str) -> subprocess.Popen:
    command = [
        sys.executable,
        "-m",
        "yotei",
        "--config",
        str(config.config_path),
        "_kickstart-worker",
        "--task",
        task_id,
        "--run-id",
        run_id,
    ]
    return subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def _handle_edit(args, config, connection) -> int:
    row = get_task(connection, args.task)
    if row is None:
        print(f"Task {args.task} was not found.")
        return 1

    schedule_text = args.when or row["schedule_text"]
    schedule_spec = parse_schedule(schedule_text)
    model = args.model or row["model"]
    if model not in config.codex.allowed_models:
        raise ValueError(f"Model {model!r} is not allowed. Allowed models: {', '.join(config.codex.allowed_models)}")

    session_mode = args.session_mode or row["session_mode"]
    session_id = row["session_id"]
    if args.model and args.model != row["model"]:
        session_id = None
    if args.session_mode == "fresh":
        session_id = None

    next_run_at = row["next_run_at"]
    if args.when:
        next_run = next_run_at_for_edit(schedule_spec, config)
        next_run_at = _to_utc_iso(next_run)
    workspace_root = str(_resolve_workspace(args.workspace)) if args.workspace else row["workspace_root"]
    sandbox_mode = _sandbox_mode_from_args(args, default=row["sandbox_mode"])
    codex_exec_args = _codex_exec_args_for_edit(args, row)

    update_task(
        connection,
        args.task,
        schedule_text=schedule_text,
        schedule_kind=schedule_spec.kind,
        schedule_value=schedule_spec.value,
        prompt=args.prompt or row["prompt"],
        agent=args.agent or row["agent"],
        model=model,
        session_mode=session_mode,
        session_id=session_id,
        chat_id=args.chat_id or row["chat_id"],
        workspace_root=workspace_root,
        sandbox_mode=sandbox_mode,
        codex_exec_args=codex_exec_args,
        next_run_at=next_run_at,
    )
    print(f"Edited task {args.task}.")
    return 0


def _handle_config(args) -> int:
    if args.config_command == "get-default-model":
        config = load_config(Path(args.config) if args.config else None)
        print(config.codex.default_model)
        return 0
    if args.config_command == "set-default-model":
        config = update_default_model(Path(args.config) if args.config else None, args.model)
        print(config.codex.default_model)
        return 0
    raise AssertionError("Unreachable config command.")


def _handle_config_init(args) -> int:
    config_path = init_config(Path(args.path) if args.path else None, force=args.force)
    print(f"Wrote config to {config_path}.")
    return 0


def _handle_run(args, config, connection) -> int:
    mark_stale_running_runs(connection)
    while True:
        try:
            _process_due_tasks(config, connection)
        except KeyboardInterrupt:
            return _handle_user_interrupt()
        except Exception as exc:
            _log_scheduler_error(config, exc)
            if args.once:
                return 1
            if _sleep_or_interrupted(config.scheduler.error_backoff_seconds):
                return _handle_user_interrupt()
            continue
        if args.once:
            return 0
        if _sleep_or_interrupted(config.scheduler.poll_seconds):
            return _handle_user_interrupt()


def _process_due_tasks(config, connection) -> None:
    mark_stale_running_runs(connection)
    now_iso = utc_now()
    for row in due_tasks(connection, now_iso):
        spec = parse_schedule(row["schedule_text"])
        if has_running_run(connection, row["task_id"]):
            enqueue_run(connection, row["task_id"], row["next_run_at"])
        else:
            _execute_task(config, connection, row)

        if is_one_time(spec):
            disable_task(connection, row["task_id"])
        else:
            next_due = next_run_at(
                spec,
                datetime.fromisoformat(row["next_run_at"].replace("Z", "+00:00")),
                config.scheduler.timezone,
            )
            advance_task_schedule(connection, row["task_id"], _to_utc_iso(next_due))

    queued = dequeue_next(connection)
    if queued and not has_running_run(connection, queued["task_id"]):
        _execute_task(config, connection, queued)
        remove_queue_item(connection, queued["queue_id"])


def _execute_task(config, connection, row, *, run_id: str | None = None) -> None:
    if run_id is None:
        run_id = start_run(connection, row["task_id"], str(config.paths.logs_dir / "pending.log"))
    if not row["workspace_root"]:
        _finish_unavailable_workspace_run(
            config,
            connection,
            row,
            run_id,
            "Task is missing workspace_root.",
        )
        return
    workspace_root = Path(row["workspace_root"])
    if not workspace_root.exists() or not workspace_root.is_dir():
        _finish_unavailable_workspace_run(
            config,
            connection,
            row,
            run_id,
            f"Task workspace is unavailable: {workspace_root}",
        )
        return
    if config.notifications.send_on_start:
        notification_error = _send_notification(
            config,
            row["chat_id"],
            format_notification("start", row["task_id"], row["model"], "Run started.", row["session_id"]),
        )
        if notification_error:
            _handle_notification_error(config, connection, run_id, notification_error)
    try:
        result = run_codex_task(
            config,
            task_id=row["task_id"],
            prompt=row["prompt"],
            model=row["model"],
            session_mode=row["session_mode"],
            session_id=row["session_id"],
            sandbox_mode=row["sandbox_mode"],
            codex_exec_args=_decode_codex_exec_args(row["codex_exec_args"]),
            workspace_root=workspace_root,
            run_id=run_id,
        )
    except KeyboardInterrupt:
        _finish_interrupted_task_run(config, connection, row, run_id)
        raise
    except Exception as exc:
        error_text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        log_path = config.paths.logs_dir / f"{run_id}.log"
        try:
            log_path.write_text(error_text, encoding="utf-8")
            update_run_log_path(connection, run_id, str(log_path))
        except OSError as log_exc:
            print(f"failed to write task crash log: {log_exc}", file=sys.stderr)
        finish_run(
            connection,
            run_id,
            status="failed",
            summary=f"Task execution crashed: {exc}",
            exit_code=1,
            session_id=row["session_id"],
            error_text=error_text,
        )
        if config.notifications.send_on_failure:
            notification_error = _send_notification(
                config,
                row["chat_id"],
                format_notification("failure", row["task_id"], row["model"], str(exc), row["session_id"]),
            )
            if notification_error:
                _handle_notification_error(config, connection, run_id, notification_error)
        return
    update_run_log_path(connection, run_id, str(result.log_path))
    finish_run(
        connection,
        run_id,
        status="success" if result.success else "failed",
        summary=result.summary,
        exit_code=result.exit_code,
        session_id=result.session_id,
        error_text=result.error_text,
    )
    should_notify = (result.success and config.notifications.send_on_success) or (
        not result.success and config.notifications.send_on_failure
    )
    if should_notify:
        notification_error = _send_notification(
            config,
            row["chat_id"],
            format_notification(
                "success" if result.success else "failure",
                row["task_id"],
                row["model"],
                result.summary,
                result.session_id,
            ),
        )
        if notification_error:
            _handle_notification_error(config, connection, run_id, notification_error)


def _finish_interrupted_task_run(config, connection, row, run_id: str) -> None:
    message = "Task execution interrupted before the run finished."
    log_path = config.paths.logs_dir / f"{run_id}.log"
    try:
        with log_path.open("a", encoding="utf-8") as log_file:
            log_file.write(message + "\n")
        update_run_log_path(connection, run_id, str(log_path))
    except OSError as log_exc:
        print(f"failed to write task interrupt log: {log_exc}", file=sys.stderr)
    finish_run(
        connection,
        run_id,
        status="failed",
        summary=message,
        exit_code=130,
        session_id=row["session_id"],
        error_text=message,
    )
    if config.notifications.send_on_failure:
        notification_error = _send_notification(
            config,
            row["chat_id"],
            format_notification("failure", row["task_id"], row["model"], message, row["session_id"]),
        )
        if notification_error:
            _handle_notification_error(config, connection, run_id, notification_error)


def _finish_unavailable_workspace_run(config, connection, row, run_id: str, reason: str) -> None:
    message = f"{reason} Repair it with: yotei edit --task {row['task_id']} --workspace <path>"
    log_path = config.paths.logs_dir / f"{run_id}.log"
    try:
        log_path.write_text(message + "\n", encoding="utf-8")
        update_run_log_path(connection, run_id, str(log_path))
    except OSError as log_exc:
        print(f"failed to write workspace error log: {log_exc}", file=sys.stderr)
    finish_run(
        connection,
        run_id,
        status="failed",
        summary=message,
        exit_code=1,
        session_id=row["session_id"],
        error_text=message,
    )
    if config.notifications.send_on_failure:
        notification_error = _send_notification(
            config,
            row["chat_id"],
            format_notification("failure", row["task_id"], row["model"], message, row["session_id"]),
        )
        if notification_error:
            _handle_notification_error(config, connection, run_id, notification_error)


def _to_utc_iso(value: datetime) -> str:
    return value.astimezone(ZoneInfo("UTC")).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _resolve_workspace(raw_workspace: str | None) -> Path:
    try:
        workspace = Path(raw_workspace).expanduser() if raw_workspace else Path.cwd()
    except RuntimeError as exc:
        raise ValueError(f"Workspace path cannot be expanded: {raw_workspace}") from exc
    resolved = workspace.resolve()
    if not resolved.exists() or not resolved.is_dir():
        raise ValueError(f"Workspace path does not exist or is not a directory: {resolved}")
    return resolved


def _add_sandbox_arguments(parser: ArgumentParser) -> None:
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--sandbox", choices=SANDBOX_MODES, help=SANDBOX_MODE_HELP)
    group.add_argument("--read-only", action="store_true", help="Run Codex with read-only sandbox permissions.")
    group.add_argument(
        "--workspace-write",
        action="store_true",
        help="Allow Codex to write inside the task workspace while keeping sandboxing enabled.",
    )
    group.add_argument(
        "--yolo",
        action="store_true",
        help="Run Codex with danger-full-access sandbox permissions.",
    )


def _sandbox_mode_from_args(args, *, default: str) -> str:
    if args.sandbox:
        return args.sandbox
    if args.read_only:
        return "read-only"
    if args.workspace_write:
        return "workspace-write"
    if args.yolo:
        return "danger-full-access"
    return default


def _codex_exec_args_from_raw(raw_args: list[str]) -> list[str]:
    codex_exec_args = list(raw_args)
    if codex_exec_args and codex_exec_args[0] == "--":
        codex_exec_args = codex_exec_args[1:]
    if codex_exec_args and not codex_exec_args[0].startswith("-"):
        raise ValueError("Codex exec passthrough arguments must start with an option after --.")
    return codex_exec_args


def _codex_exec_args_for_edit(args, row) -> list[str]:
    raw_args = _codex_exec_args_from_raw(args.codex_exec_args)
    if raw_args and args.clear_codex_exec_args:
        raise ValueError("Pass either --clear-codex-exec-args or new codex exec arguments, not both.")
    if args.clear_codex_exec_args:
        return []
    if raw_args:
        return raw_args
    return _decode_codex_exec_args(row["codex_exec_args"])


def _decode_codex_exec_args(raw_value: str | None) -> list[str]:
    if raw_value is None:
        return []
    try:
        value = json.loads(raw_value)
    except json.JSONDecodeError as exc:
        raise ValueError("Stored codex_exec_args is not valid JSON.") from exc
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ValueError("Stored codex_exec_args must be a JSON array of strings.")
    return value


def _sleep_or_interrupted(seconds: int) -> bool:
    try:
        sleep(seconds)
    except KeyboardInterrupt:
        return True
    return False


def _handle_user_interrupt() -> int:
    print("scheduler interrupted by user.", file=sys.stderr)
    return 130


def next_run_at_for_edit(schedule_spec, config) -> datetime:
    now = datetime.now(ZoneInfo(config.scheduler.timezone))
    return next_run_at(schedule_spec, now, config.scheduler.timezone)


def _log_scheduler_error(config, exc: Exception) -> None:
    message = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    log_entry = f"[{utc_now()}] unexpected scheduler loop error\n{message}\n"
    try:
        config.paths.logs_dir.mkdir(parents=True, exist_ok=True)
        with (config.paths.logs_dir / "scheduler.log").open("a", encoding="utf-8") as log_file:
            log_file.write(log_entry)
    except OSError as log_exc:
        print(f"failed to write scheduler log: {log_exc}", file=sys.stderr)
    print(
        f"unexpected scheduler loop error; retrying after {config.scheduler.error_backoff_seconds}s: {exc}",
        file=sys.stderr,
    )


def _handle_notification_error(config, connection, run_id: str, message: str) -> None:
    sanitized = _sanitize_notification_error(config, message)
    try:
        record_notification_error(connection, run_id, sanitized)
    except sqlite3.Error as exc:
        print(f"failed to record notification error: {exc}", file=sys.stderr)
    _log_notification_error(config, run_id, sanitized)


def _send_notification(config, chat_id: str, text: str) -> str | None:
    try:
        return send_telegram_message(config, chat_id, text)
    except Exception as exc:
        return f"Telegram notification failed: {type(exc).__name__}."


def _sanitize_notification_error(config, message: str) -> str:
    token = getattr(getattr(config, "telegram", None), "bot_token", None)
    sanitized = message
    if token and token != "replace-me":
        sanitized = sanitized.replace(token, "[redacted]")
        sanitized = sanitized.replace(quote(token, safe=""), "[redacted]")
    return " ".join(sanitized.split())[:500]


def _log_notification_error(config, run_id: str, message: str) -> None:
    log_entry = f"[{utc_now()}] notification failure for run {run_id}: {message}\n"
    try:
        config.paths.logs_dir.mkdir(parents=True, exist_ok=True)
        with (config.paths.logs_dir / "scheduler.log").open("a", encoding="utf-8") as log_file:
            log_file.write(log_entry)
    except OSError as log_exc:
        print(f"failed to write notification log: {log_exc}", file=sys.stderr)
