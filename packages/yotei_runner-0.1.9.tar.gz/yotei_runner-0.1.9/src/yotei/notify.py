"""Where: notification module. What: send Telegram notifications for task lifecycle events. Why: keep operational visibility separate from execution logic."""

from __future__ import annotations

from urllib import parse, request

from .config import AppConfig


TELEGRAM_MESSAGE_LIMIT = 4096
TRUNCATION_SUFFIX = "\n..."


def send_telegram_message(config: AppConfig, chat_id: str, text: str) -> str | None:
    if not config.telegram.bot_token or config.telegram.bot_token == "replace-me":
        return None
    data = parse.urlencode({"chat_id": chat_id, "text": _fit_telegram_message(text)}).encode("utf-8")
    url = f"https://api.telegram.org/bot{config.telegram.bot_token}/sendMessage"
    req = request.Request(url, data=data, method="POST")
    try:
        with request.urlopen(req, timeout=10):
            return None
    except Exception as exc:
        return f"Telegram notification failed: {type(exc).__name__}."


def format_notification(event: str, task_id: str, model: str, summary: str, session_id: str | None) -> str:
    lines = [
        f"[task: {task_id}]",
        f"event: {event}",
        f"model: {model}",
    ]
    if session_id:
        lines.append(f"session: {session_id}")
    if summary:
        lines.extend(["summary:", summary.strip()])
    return _fit_telegram_message("\n".join(lines))


def _fit_telegram_message(text: str) -> str:
    if len(text) <= TELEGRAM_MESSAGE_LIMIT:
        return text
    return text[: TELEGRAM_MESSAGE_LIMIT - len(TRUNCATION_SUFFIX)].rstrip() + TRUNCATION_SUFFIX
