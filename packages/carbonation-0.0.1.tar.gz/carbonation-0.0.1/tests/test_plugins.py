"""Tests for plugin loading and registry."""

from __future__ import annotations

from pathlib import Path

import pytest

from carbonation.exceptions import PluginError
from carbonation.plugins import PluginRegistry


class TestPluginRegistry:
    def test_load_directory(self, tmp_plugins_dir: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        assert registry.has_function("hello")
        assert registry.has_function("add")

    def test_call_function(self, tmp_plugins_dir: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        assert registry.call("hello", name="World") == "Hello, World!"
        assert registry.call("add", a=2, b=3) == 5

    def test_missing_function_raises(self, tmp_plugins_dir: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        with pytest.raises(PluginError, match="Plugin function not found"):
            registry.call("nonexistent")

    def test_missing_module_raises(self, tmp_plugins_dir: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        with pytest.raises(PluginError, match="Plugin module not found"):
            registry.get_module("nonexistent")

    def test_get_module(self, tmp_plugins_dir: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        mod = registry.get_module("greeter")
        assert hasattr(mod, "hello")

    def test_skips_private_files(self, tmp_plugins_dir: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        assert not registry.has_function("secret")

    def test_handles_broken_plugin(self, tmp_plugins_dir: Path):
        """Broken plugins log an error but don't crash loading."""
        registry = PluginRegistry()
        registry.load_directory(tmp_plugins_dir)
        # greeter should still be loaded despite broken.py failing
        assert registry.has_function("hello")

    def test_nonexistent_directory(self, tmp_path: Path):
        registry = PluginRegistry()
        registry.load_directory(tmp_path / "nonexistent")
        assert not registry.has_function("anything")

    def test_empty_directory(self, tmp_path: Path):
        empty = tmp_path / "empty"
        empty.mkdir()
        registry = PluginRegistry()
        registry.load_directory(empty)
        assert not registry.has_function("anything")

    def test_function_redefinition_raises(self, tmp_path: Path):
        """If two plugins define the same function name, PluginError is raised."""
        from carbonation.exceptions import PluginError

        plugins = tmp_path / "plugins"
        plugins.mkdir()
        (plugins / "a_first.py").write_text("def dupe(): return 'a'\n")
        (plugins / "b_second.py").write_text("def dupe(): return 'b'\n")

        registry = PluginRegistry()
        with pytest.raises(PluginError, match="redefined"):
            registry.load_directory(plugins)
