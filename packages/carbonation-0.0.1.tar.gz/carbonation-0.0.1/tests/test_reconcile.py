"""Tests for delivery and archive reconciliation."""

from __future__ import annotations

from pathlib import Path

import pytest

from carbonation.config import ArchiveConfig, WatchConfig
from carbonation.db.models import FileStatus
from carbonation.db.queries import (
    get_component_by_source_path,
    get_components_in_delivery,
    get_delivery_count,
    record_component,
    update_component_status,
)
from carbonation.reconcile import reconcile_archive, reconcile_delivery, walk_directory


class TestWalkDirectory:
    def test_walk_flat(self, tmp_path: Path):
        (tmp_path / "a.csv").write_text("aaa")
        (tmp_path / "b.json").write_text("bbb")
        result = walk_directory(tmp_path, recursive=False)
        assert len(result) == 2
        for path_str, (size, mtime) in result.items():
            assert Path(path_str).is_absolute()
            assert size > 0

    def test_walk_recursive(self, tmp_path: Path):
        sub = tmp_path / "sub"
        sub.mkdir()
        (tmp_path / "a.csv").write_text("aaa")
        (sub / "b.csv").write_text("bbb")
        result = walk_directory(tmp_path, recursive=True)
        assert len(result) == 2

    def test_walk_nonexistent(self, tmp_path: Path):
        result = walk_directory(tmp_path / "nope")
        assert len(result) == 0

    def test_walk_empty(self, tmp_path: Path):
        result = walk_directory(tmp_path)
        assert len(result) == 0


class TestReconcileDelivery:
    @pytest.fixture
    def watch_dir(self, tmp_path: Path) -> Path:
        d = tmp_path / "delivery"
        d.mkdir()
        return d

    @pytest.fixture
    def watch_config(self, watch_dir: Path) -> WatchConfig:
        return WatchConfig(
            name="test-watch",
            path=watch_dir,
            rules="test-rules",
            archive="test-archive",
        )

    def test_detects_new_files(self, db_session, watch_config, watch_dir):
        (watch_dir / "new1.csv").write_text("data1")
        (watch_dir / "new2.csv").write_text("data2")

        stats = reconcile_delivery(db_session, watch_config)
        assert stats["new"] == 2
        assert stats["cleared"] == 0
        assert get_delivery_count(db_session) == 2

    def test_detects_cleared_files(self, db_session, watch_config, watch_dir):
        # Create a file, record it, then remove the file
        f = watch_dir / "gone.csv"
        f.write_text("data")
        path_str = str(f.resolve())

        record_component(
            db_session,
            watch_name="test-watch",
            filename="gone.csv",
            source_path=path_str,
            size_bytes=4,
        )
        f.unlink()

        stats = reconcile_delivery(db_session, watch_config)
        assert stats["cleared"] == 1

        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.CLEARED
        assert comp["in_delivery"] is False

    def test_preserves_archived_on_clear(self, db_session, watch_config, watch_dir):
        f = watch_dir / "archived.csv"
        f.write_text("data")
        path_str = str(f.resolve())

        cid = record_component(
            db_session,
            watch_name="test-watch",
            filename="archived.csv",
            source_path=path_str,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path="/archive/archived.csv"
        )
        f.unlink()

        reconcile_delivery(db_session, watch_config)
        comp = get_component_by_source_path(db_session, path_str)
        assert comp["status"] == FileStatus.ARCHIVED  # preserved

    def test_no_changes(self, db_session, watch_config, watch_dir):
        stats = reconcile_delivery(db_session, watch_config)
        assert stats["new"] == 0
        assert stats["cleared"] == 0

    def test_requeue_events(self, db_session, watch_config, watch_dir):
        from queue import Queue
        from carbonation.watcher import FileEvent

        (watch_dir / "pending.csv").write_text("data")
        event_queue: Queue[FileEvent] = Queue()

        stats = reconcile_delivery(db_session, watch_config, event_queue=event_queue)
        assert stats["requeued"] == 1
        assert not event_queue.empty()


class TestReconcileArchive:
    def test_registers_orphaned_files(self, db_session, tmp_path):
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        (archive_dir / "orphan.csv").write_text("data")

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=str(archive_dir),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["created"] == 1

    def test_finds_existing_records(self, db_session, tmp_path):
        archive_dir = tmp_path / "archive"
        archive_dir.mkdir()
        f = archive_dir / "known.csv"
        f.write_text("data")
        path_str = str(f.resolve())

        cid = record_component(
            db_session,
            watch_name="test",
            filename="known.csv",
            source_path=path_str,
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED, archive_path=path_str
        )
        db_session.commit()

        configs = [
            ArchiveConfig(
                name="test-archive",
                base_path=archive_dir,
                destination=str(archive_dir),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["found"] == 1
        assert stats["created"] == 0

    def test_empty_archive(self, db_session, tmp_path):
        configs = [
            ArchiveConfig(
                name="test-archive",
                destination=str(tmp_path / "nonexistent" / "{cat}"),
            )
        ]
        stats = reconcile_archive(db_session, configs)
        assert stats["found"] == 0
        assert stats["created"] == 0
