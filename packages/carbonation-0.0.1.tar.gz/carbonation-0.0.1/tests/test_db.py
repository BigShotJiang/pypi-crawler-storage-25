"""Tests for database models, engine, and queries."""

from __future__ import annotations

import pytest
from sqlalchemy import create_engine, inspect

from carbonation.db.engine import create_session_factory, init_db, verify_schema
from carbonation.db.models import (
    Base, FileBase, FileComponent, FileStatus,
    get_file_model, validate_extract_metadata,
)
from carbonation.db.queries import (
    bulk_insert_components,
    bulk_mark_cleared,
    get_archive_count,
    get_delivery_count,
    get_status_counts,
    record_component,
    update_component_status,
)
from carbonation.exceptions import PluginError


class TestFileModel:
    def test_get_file_model_returns_registered_subclass(self):
        model = get_file_model()
        assert issubclass(model, FileBase)
        assert model.__tablename__ == "files"

    def test_file_model_has_core_fields(self):
        model = get_file_model()
        column_names = {c.name for c in model.__table__.columns}
        assert "id" in column_names
        assert "watch_name" in column_names
        assert "group_key" in column_names
        assert "complete" in column_names
        assert "created_at" in column_names
        assert "modified_at" in column_names


class TestValidateExtractMetadata:
    def test_valid_metadata(self):
        from datetime import datetime
        errors = validate_extract_metadata({
            "label": "test",
            "start": datetime(2026, 1, 1),
            "stop": datetime(2026, 1, 2),
            "category": "alpha",
            "source": "sensor-1",
        })
        assert errors == []

    def test_none_for_nullable_column(self):
        errors = validate_extract_metadata({"label": None})
        assert errors == []

    def test_wrong_type(self):
        errors = validate_extract_metadata({"start": "not-a-datetime"})
        assert len(errors) == 1
        assert "expected datetime" in errors[0]
        assert "got str" in errors[0]

    def test_unknown_column(self):
        errors = validate_extract_metadata({"nonexistent": 42})
        assert len(errors) == 1
        assert "Unknown column" in errors[0]

    def test_base_column_rejected(self):
        errors = validate_extract_metadata({"watch_name": "sneaky"})
        assert len(errors) == 1
        assert "base column" in errors[0]

    def test_multiple_errors(self):
        errors = validate_extract_metadata({
            "start": "bad",
            "nonexistent": 42,
        })
        assert len(errors) == 2

    def test_empty_dict_valid(self):
        errors = validate_extract_metadata({})
        assert errors == []


class TestAlembicMigrations:
    def test_migration_creates_tables(self):
        """Alembic migration creates base tables on a fresh database."""
        from carbonation.db.engine import run_migrations

        engine = create_engine("sqlite:///:memory:")
        run_migrations(engine)

        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        assert "files" in tables
        assert "file_components" in tables
        assert "service_state" in tables
        assert "alembic_version" in tables
        engine.dispose()

    def test_init_db_adds_plugin_columns(self):
        """init_db runs migrations then adds plugin columns."""
        from carbonation.db.engine import init_db

        engine = create_engine("sqlite:///:memory:")
        init_db(engine)

        inspector = inspect(engine)
        file_columns = {c["name"] for c in inspector.get_columns("files")}
        # Plugin columns from _TestFile in conftest.py
        assert "label" in file_columns
        assert "start" in file_columns
        assert "category" in file_columns
        # Base columns from migration
        assert "watch_name" in file_columns
        assert "group_key" in file_columns
        engine.dispose()

    def test_init_db_idempotent(self):
        """Running init_db twice doesn't fail."""
        from carbonation.db.engine import init_db

        engine = create_engine("sqlite:///:memory:")
        init_db(engine)
        init_db(engine)  # should not raise
        engine.dispose()

    def test_no_drift_after_init(self):
        """No schema drift reported after a fresh init_db."""
        from carbonation.db.engine import check_schema_drift, init_db

        engine = create_engine("sqlite:///:memory:")
        init_db(engine)
        drift = check_schema_drift(engine)
        assert drift == []
        engine.dispose()

    def test_drift_detects_missing_plugin_column(self):
        """Schema drift detects a plugin column missing from the DB."""
        from carbonation.db.engine import check_schema_drift, run_migrations

        engine = create_engine("sqlite:///:memory:")
        run_migrations(engine)  # base tables only, no plugin columns
        drift = check_schema_drift(engine)
        # _TestFile defines label, start, stop, category, source
        missing = [d for d in drift if "Missing plugin column" in d]
        assert len(missing) >= 1
        assert any("label" in d for d in missing)
        engine.dispose()


class TestSchemaCreation:
    def test_creates_both_tables(self, db_engine):
        inspector = inspect(db_engine)
        tables = set(inspector.get_table_names())
        assert "files" in tables
        assert "file_components" in tables

    def test_file_components_columns(self, db_engine):
        inspector = inspect(db_engine)
        columns = {c["name"] for c in inspector.get_columns("file_components")}
        expected = {
            "id", "watch_name", "filename", "source_path", "archive_path",
            "size_bytes", "status", "in_delivery", "in_archive", "group_id",
            "error_message", "detected_at", "archived_at", "cleared_at", "metadata",
        }
        assert expected.issubset(columns)

    def test_file_components_has_fk_to_files(self, db_engine):
        inspector = inspect(db_engine)
        fks = inspector.get_foreign_keys("file_components")
        fk_tables = {fk["referred_table"] for fk in fks}
        assert "files" in fk_tables

    def test_verify_schema_succeeds(self, db_engine):
        assert verify_schema(db_engine) is True

    def test_verify_schema_fails_on_empty_db(self):
        engine = create_engine("sqlite:///:memory:")
        assert verify_schema(engine) is False
        engine.dispose()


class TestRecordComponent:
    def test_inserts_and_returns_id(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
            size_bytes=1024,
        )
        assert isinstance(cid, int)
        assert cid > 0

    def test_defaults_to_detected_status(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.DETECTED

    def test_unique_source_path(self, db_session):
        record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        with pytest.raises(Exception):  # IntegrityError
            record_component(
                db_session,
                watch_name="test",
                filename="data.csv",
                source_path="/delivery/data.csv",
            )


class TestUpdateComponentStatus:
    def test_updates_status(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(db_session, cid, FileStatus.WAITING)
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.WAITING

    def test_archived_sets_in_archive(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(
            db_session, cid, FileStatus.ARCHIVED,
            archive_path="/archive/data.csv",
        )
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.ARCHIVED
        assert row.in_archive is True
        assert row.archived_at is not None
        assert row.archive_path == "/archive/data.csv"

    def test_cleared_sets_in_delivery_false(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(db_session, cid, FileStatus.CLEARED)
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.status == FileStatus.CLEARED
        assert row.in_delivery is False
        assert row.cleared_at is not None

    def test_error_message_stored(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="data.csv",
            source_path="/delivery/data.csv",
        )
        update_component_status(
            db_session, cid, FileStatus.FAILED,
            error_message="disk full",
        )
        row = db_session.execute(
            FileComponent.__table__.select().where(FileComponent.__table__.c.id == cid)
        ).first()
        assert row.error_message == "disk full"


class TestBulkOperations:
    def _insert_three(self, db_session):
        """Helper: insert 3 components, return their ids."""
        ids = []
        for i in range(3):
            cid = record_component(
                db_session,
                watch_name="test",
                filename=f"file{i}.csv",
                source_path=f"/delivery/file{i}.csv",
                size_bytes=100 * (i + 1),
            )
            ids.append(cid)
        return ids

    def test_bulk_insert(self, db_session):
        records = [
            {
                "watch_name": "test",
                "filename": f"bulk{i}.csv",
                "source_path": f"/delivery/bulk{i}.csv",
                "size_bytes": 500,
                "status": FileStatus.DETECTED,
                "in_delivery": True,
                "in_archive": False,
            }
            for i in range(5)
        ]
        bulk_insert_components(db_session, records)
        assert get_delivery_count(db_session) == 5

    def test_bulk_insert_empty(self, db_session):
        bulk_insert_components(db_session, [])
        assert get_delivery_count(db_session) == 0

    def test_bulk_mark_cleared(self, db_session):
        ids = self._insert_three(db_session)
        bulk_mark_cleared(db_session, ids)

        for cid in ids:
            row = db_session.execute(
                FileComponent.__table__.select().where(
                    FileComponent.__table__.c.id == cid
                )
            ).first()
            assert row.in_delivery is False
            assert row.status == FileStatus.CLEARED

    def test_bulk_mark_cleared_preserves_archived(self, db_session):
        ids = self._insert_three(db_session)
        # Mark first as archived
        update_component_status(
            db_session, ids[0], FileStatus.ARCHIVED,
            archive_path="/archive/file0.csv",
        )
        bulk_mark_cleared(db_session, ids)

        # Archived should keep its status
        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[0]
            )
        ).first()
        assert row.status == FileStatus.ARCHIVED
        assert row.in_delivery is False  # still marked as not in delivery

    def test_bulk_mark_cleared_preserves_failed(self, db_session):
        ids = self._insert_three(db_session)
        update_component_status(
            db_session, ids[1], FileStatus.FAILED,
            error_message="disk full",
        )
        bulk_mark_cleared(db_session, ids)

        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[1]
            )
        ).first()
        assert row.status == FileStatus.FAILED

    def test_bulk_mark_cleared_replaces_timed_out(self, db_session):
        ids = self._insert_three(db_session)
        update_component_status(db_session, ids[2], FileStatus.TIMED_OUT)
        bulk_mark_cleared(db_session, ids)

        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[2]
            )
        ).first()
        assert row.status == FileStatus.CLEARED

    def test_bulk_mark_cleared_replaces_not_selected(self, db_session):
        ids = self._insert_three(db_session)
        update_component_status(db_session, ids[2], FileStatus.NOT_SELECTED)
        bulk_mark_cleared(db_session, ids)

        row = db_session.execute(
            FileComponent.__table__.select().where(
                FileComponent.__table__.c.id == ids[2]
            )
        ).first()
        assert row.status == FileStatus.CLEARED


class TestQueryHelpers:
    def test_get_status_counts(self, db_session):
        for i in range(3):
            record_component(
                db_session,
                watch_name="test",
                filename=f"f{i}.csv",
                source_path=f"/d/f{i}.csv",
            )
        update_component_status(db_session, 1, FileStatus.ARCHIVED, archive_path="/a/f0.csv")
        update_component_status(db_session, 2, FileStatus.WAITING)

        counts = get_status_counts(db_session)
        assert counts.get("archived", 0) == 1
        assert counts.get("waiting", 0) == 1
        assert counts.get("detected", 0) == 1

    def test_get_delivery_count(self, db_session):
        for i in range(3):
            record_component(
                db_session,
                watch_name="test",
                filename=f"f{i}.csv",
                source_path=f"/d/f{i}.csv",
            )
        assert get_delivery_count(db_session) == 3

        # Clear one
        update_component_status(db_session, 1, FileStatus.CLEARED)
        assert get_delivery_count(db_session) == 2

    def test_get_archive_count(self, db_session):
        cid = record_component(
            db_session,
            watch_name="test",
            filename="f.csv",
            source_path="/d/f.csv",
        )
        assert get_archive_count(db_session) == 0

        update_component_status(db_session, cid, FileStatus.ARCHIVED, archive_path="/a/f.csv")
        assert get_archive_count(db_session) == 1
