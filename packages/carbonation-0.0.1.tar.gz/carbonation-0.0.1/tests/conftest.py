"""Shared test fixtures for carbonation."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest
from sqlalchemy import DateTime, String, create_engine
from sqlalchemy.orm import Mapped, Session, mapped_column, sessionmaker

from carbonation.db.models import Base, FileBase


# Register a test File model once at module level.
# This is fine because SQLAlchemy models are global anyway.
# Includes fields used by both unit tests (label) and integration tests
# (start, stop, category, source).
class _TestFile(FileBase):
    __tablename__ = "files"
    label: Mapped[str | None] = mapped_column(String(255), nullable=True)
    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stop: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True)
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)


@pytest.fixture
def db_engine():
    """Create an in-memory SQLite engine with tables created."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    yield engine
    Base.metadata.drop_all(engine)
    engine.dispose()


@pytest.fixture
def db_session(db_engine):
    """Create a DB session for testing.

    Rolls back any uncommitted changes after the test to ensure isolation.
    """
    factory = sessionmaker(bind=db_engine)
    session = factory()
    yield session
    session.rollback()
    session.close()


@pytest.fixture
def tmp_config(tmp_path: Path) -> Path:
    """Create a minimal valid config.toml in a temp directory."""
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()
    rules_file = tmp_path / "rules.toml"
    rules_file.write_text(
        '[test-rules]\n'
        '[[test-rules.integrity]]\n'
        'type = "min_size"\n'
        'value = 10\n'
    )

    # Write a no-op plugin — the File model is already registered by
    # conftest.py's _TestFile, so this plugin just needs to exist.
    (plugins_dir / "test_model.py").write_text(
        "# File model is provided by the test harness (_TestFile in conftest.py)\n"
    )

    delivery_dir = tmp_path / "delivery"
    delivery_dir.mkdir()

    db_path = (tmp_path / "test.db").as_posix()
    config_file = tmp_path / "config.toml"
    config_file.write_text(
        '[service]\n'
        'poll_interval = "5s"\n'
        'reconcile_interval = "1h"\n'
        '\n'
        '[database]\n'
        f'name = "{db_path}"\n'
        '\n'
        '[plugins]\n'
        'directory = "plugins"\n'
        '\n'
        '[rules]\n'
        'file = "rules.toml"\n'
        '\n'
        '[[watch]]\n'
        'name = "test-watch"\n'
        'path = "delivery"\n'
        'rules = "test-rules"\n'
        'archive = "test-archive"\n'
        '\n'
        '[[archive]]\n'
        'name = "test-archive"\n'
        'destination = "archive/{label}"\n'
        'action = "copy"\n'
    )

    return config_file


@pytest.fixture
def tmp_plugins_dir(tmp_path: Path) -> Path:
    """Create a temp directory with test plugin files."""
    plugins_dir = tmp_path / "plugins"
    plugins_dir.mkdir()

    (plugins_dir / "greeter.py").write_text(
        "def hello(name: str) -> str:\n"
        "    return f'Hello, {name}!'\n"
        "\n"
        "def add(a: int, b: int) -> int:\n"
        "    return a + b\n"
    )

    (plugins_dir / "broken.py").write_text(
        "raise RuntimeError('plugin load failure')\n"
    )

    (plugins_dir / "_private.py").write_text(
        "def secret(): return 42\n"
    )

    return plugins_dir
