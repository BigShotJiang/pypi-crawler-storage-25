"""Tests for the service module — _process_event_inner pipeline."""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from carbonation.config import (
    AppConfig,
    ArchiveConfig,
    CompletenessConfig,
    IntegrityCheck,
    MetadataConfig,
    RuleSet,
    RulesConfig,
    SelectionRule,
    WatchConfig,
)
from carbonation.db.models import Base, FileComponent, FileStatus
from carbonation.db.queries import (
    get_component_by_source_path,
    get_group_components,
    record_component,
)
from carbonation.plugins import PluginRegistry
from carbonation.service import CarbonationService
from carbonation.watcher import FileEvent


def _make_service(
    tmp_path: Path,
    *,
    integrity: list[IntegrityCheck] | None = None,
    completeness: CompletenessConfig | None = None,
    metadata: MetadataConfig | None = None,
    selection: list[SelectionRule] | None = None,
    archive_action: str = "copy",
    archive_dest: str | None = None,
) -> tuple[CarbonationService, sessionmaker]:
    """Build a minimal CarbonationService for unit testing."""
    delivery_dir = tmp_path / "delivery"
    delivery_dir.mkdir(exist_ok=True)
    archive_dir = tmp_path / "archive"
    archive_dir.mkdir(exist_ok=True)

    app_config = AppConfig(
        watch=[
            WatchConfig(
                name="test-watch",
                path=delivery_dir,
                rules="test-rules",
                archive="test-archive",
            ),
        ],
        archive=[
            ArchiveConfig(
                name="test-archive",
                destination=archive_dest or str(archive_dir),
                action=archive_action,
            ),
        ],
    )
    rules_config = RulesConfig(
        rule_sets={
            "test-rules": RuleSet(
                integrity=integrity or [],
                completeness=completeness,
                metadata=metadata,
                selection=selection or [],
            ),
        }
    )
    registry = PluginRegistry()

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine)

    svc = CarbonationService(app_config, rules_config, registry, engine, factory)
    return svc, factory


class TestProcessEventStandalone:
    """Tests for standalone file processing (no completeness)."""

    def test_happy_path_archives_file(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.ARCHIVED
        assert comp["archive_path"] is not None
        session.close()

    def test_integrity_failure_marks_failed(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            integrity=[IntegrityCheck(type="min_size", value=10000)],
        )
        delivery = tmp_path / "delivery"
        f = delivery / "tiny.txt"
        f.write_text("x")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.INTEGRITY_FAILED
        assert "too small" in comp["error_message"].lower()
        session.close()

    def test_nonexistent_file_fails_integrity(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "ghost.txt"  # does not exist

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.INTEGRITY_FAILED
        session.close()

    def test_selection_rejection_skips(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            selection=[SelectionRule(has_keys=["nonexistent_key"])],
        )
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.NOT_SELECTED
        session.close()

    def test_unknown_watch_returns_early(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        f = tmp_path / "delivery" / "data.txt"
        f.write_text("content")

        event = FileEvent(watch_name="nonexistent-watch", path=f)
        session = factory()
        try:
            svc._process_event_inner(session, event)
            session.commit()
        finally:
            session.close()

        # No component should be recorded
        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is None
        session.close()

    def test_duplicate_event_skips_archived(self, tmp_path):
        svc, factory = _make_service(tmp_path)
        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content")
        event = FileEvent(watch_name="test-watch", path=f)

        # Process once
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        # Process again — should not fail
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        # Should still be archived
        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.ARCHIVED
        session.close()

    def test_missing_archive_config_fails(self, tmp_path):
        """If archive name doesn't match any config, components are marked FAILED."""
        delivery_dir = tmp_path / "delivery"
        delivery_dir.mkdir(exist_ok=True)

        app_config = AppConfig(
            watch=[
                WatchConfig(
                    name="test-watch",
                    path=delivery_dir,
                    rules="test-rules",
                    archive="nonexistent-archive",
                ),
            ],
            archive=[
                ArchiveConfig(
                    name="other-archive",
                    destination=str(tmp_path / "archive"),
                ),
            ],
        )
        rules_config = RulesConfig(rule_sets={"test-rules": RuleSet()})
        registry = PluginRegistry()
        engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)
        svc = CarbonationService(app_config, rules_config, registry, engine, factory)

        f = delivery_dir / "data.txt"
        f.write_text("content")
        event = FileEvent(watch_name="test-watch", path=f)

        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.FAILED
        assert "not found" in comp["error_message"].lower()
        session.close()


class TestProcessEventWithCompleteness:
    """Tests for group completeness handling."""

    def test_incomplete_group_waits(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
        )
        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("data content")

        event = FileEvent(watch_name="test-watch", path=f_txt)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f_txt.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.WAITING
        session.close()

    def test_complete_group_archives_all(self, tmp_path):
        svc, factory = _make_service(
            tmp_path,
            completeness=CompletenessConfig(
                group_by="stem",
                expected_extensions=[".txt", ".json"],
            ),
        )
        delivery = tmp_path / "delivery"
        f_txt = delivery / "sample_001.txt"
        f_txt.write_text("text data content here")
        f_json = delivery / "sample_001.json"
        f_json.write_text('{"key": "value"}')

        # Process first component
        session = factory()
        svc._process_event_inner(session, FileEvent(watch_name="test-watch", path=f_txt))
        session.commit()
        session.close()

        # Process second component — should complete the group
        session = factory()
        svc._process_event_inner(session, FileEvent(watch_name="test-watch", path=f_json))
        session.commit()
        session.close()

        # Both should be archived
        session = factory()
        comp_txt = get_component_by_source_path(session, str(f_txt.resolve()))
        comp_json = get_component_by_source_path(session, str(f_json.resolve()))
        assert comp_txt["status"] == FileStatus.ARCHIVED
        assert comp_json["status"] == FileStatus.ARCHIVED
        session.close()


class TestCompletenessTimeouts:
    """Tests for _check_completeness_timeouts."""

    def _make_service_with_timeout(
        self, tmp_path, *, on_timeout: str = "warn", timeout_minutes: int = 120,
    ):
        """Build a service with completeness + timeout config."""
        delivery = tmp_path / "delivery"
        delivery.mkdir(exist_ok=True)
        archive = tmp_path / "archive"
        archive.mkdir(exist_ok=True)

        app_config = AppConfig(
            watch=[
                WatchConfig(
                    name="test-watch",
                    path=delivery,
                    rules="test-rules",
                    archive="test-archive",
                ),
            ],
            archive=[
                ArchiveConfig(
                    name="test-archive",
                    destination=str(archive),
                ),
            ],
        )
        rules_config = RulesConfig(
            rule_sets={
                "test-rules": RuleSet(
                    completeness=CompletenessConfig(
                        group_by="stem",
                        expected_extensions=[".txt", ".json"],
                        timeout_minutes=timeout_minutes,
                        on_timeout=on_timeout,
                    ),
                ),
            }
        )
        registry = PluginRegistry()
        engine = create_engine("sqlite:///:memory:")
        Base.metadata.create_all(engine)
        factory = sessionmaker(bind=engine)
        svc = CarbonationService(app_config, rules_config, registry, engine, factory)
        return svc, factory, delivery

    def _create_incomplete_group(self, svc, factory, delivery):
        """Create an incomplete group (only .txt, no .json) and backdate it."""
        from datetime import datetime, timedelta, timezone
        from carbonation.db.queries import find_or_create_file_group, assign_component_to_group

        f = delivery / "old_signal.txt"
        f.write_text("some data content here")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()

        # Backdate the group's created_at to trigger timeout
        from carbonation.db.models import get_file_model
        FileModel = get_file_model()
        from sqlalchemy import update
        old_time = datetime.now(timezone.utc) - timedelta(hours=24)
        session.execute(
            update(FileModel).values(created_at=old_time)
        )
        session.commit()
        session.close()
        return f

    def test_warn_timeout_keeps_waiting(self, tmp_path):
        """on_timeout=warn logs but doesn't change component status."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path, on_timeout="warn",
        )
        f = self._create_incomplete_group(svc, factory, delivery)

        svc._check_completeness_timeouts()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.WAITING
        session.close()

    def test_skip_timeout_marks_timed_out(self, tmp_path):
        """on_timeout=skip marks all group components as TIMED_OUT."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path, on_timeout="skip",
        )
        f = self._create_incomplete_group(svc, factory, delivery)

        svc._check_completeness_timeouts()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.TIMED_OUT
        session.close()

    def test_archive_partial_requeues(self, tmp_path):
        """on_timeout=archive_partial re-enqueues components for archival."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path, on_timeout="archive_partial",
        )
        f = self._create_incomplete_group(svc, factory, delivery)

        svc._check_completeness_timeouts()

        # Event should be re-enqueued
        assert not svc.event_queue.empty()
        event = svc.event_queue.get_nowait()
        assert event.path == f

    def test_no_timeout_if_not_expired(self, tmp_path):
        """Groups within timeout_minutes are not affected."""
        svc, factory, delivery = self._make_service_with_timeout(
            tmp_path, on_timeout="skip", timeout_minutes=99999,
        )
        # Create group but DON'T backdate — it's fresh
        f = delivery / "fresh_signal.txt"
        f.write_text("some data content here")
        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        svc._check_completeness_timeouts()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp["status"] == FileStatus.WAITING  # not skipped
        session.close()


class TestRetryLogic:
    """Tests for archival retry behavior."""

    def test_archive_failure_marks_retry_pending(self, tmp_path):
        """First failure marks component RETRY_PENDING, not FAILED."""
        # Point archive at a non-writable destination
        svc, factory = _make_service(
            tmp_path,
            archive_dest=str(tmp_path / "nonexistent" / "deep" / "path"),
        )
        # Disable dir creation to force failure
        svc._archive_by_name["test-archive"].create_directories = False

        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")

        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.RETRY_PENDING
        session.close()

    def test_max_retries_marks_failed(self, tmp_path):
        """After max_retries, component is marked FAILED."""
        svc, factory = _make_service(tmp_path)
        svc.app_config.service.max_retries = 2
        svc._archive_by_name["test-archive"].create_directories = False
        svc._archive_by_name["test-archive"].destination = str(
            tmp_path / "nonexistent" / "path"
        )

        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")
        event = FileEvent(watch_name="test-watch", path=f)

        # Simulate: fail → periodic retry (increments count) → fail → retry → fail → FAILED
        for i in range(3):
            session = factory()
            svc._process_event_inner(session, event)
            session.commit()
            session.close()
            # Simulate periodic checker incrementing retry_count
            if i < 2:
                from carbonation.db.queries import mark_for_retry
                session = factory()
                comp = get_component_by_source_path(session, str(f.resolve()))
                mark_for_retry(session, comp["id"])
                session.commit()
                session.close()

        session = factory()
        comp = get_component_by_source_path(session, str(f.resolve()))
        assert comp is not None
        assert comp["status"] == FileStatus.FAILED
        session.close()

    def test_check_pending_retries_enqueues(self, tmp_path):
        """_check_pending_retries re-enqueues RETRY_PENDING components."""
        svc, factory = _make_service(tmp_path)
        svc._archive_by_name["test-archive"].create_directories = False
        svc._archive_by_name["test-archive"].destination = str(
            tmp_path / "nonexistent"
        )

        delivery = tmp_path / "delivery"
        f = delivery / "data.txt"
        f.write_text("some content here")

        # Process once to get RETRY_PENDING
        event = FileEvent(watch_name="test-watch", path=f)
        session = factory()
        svc._process_event_inner(session, event)
        session.commit()
        session.close()

        # Clear the queue
        while not svc.event_queue.empty():
            svc.event_queue.get_nowait()

        # Check retries should re-enqueue
        svc._check_pending_retries()
        assert not svc.event_queue.empty()
