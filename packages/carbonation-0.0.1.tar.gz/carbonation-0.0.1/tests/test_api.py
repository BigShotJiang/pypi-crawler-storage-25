"""Tests for the public Python query API."""

from __future__ import annotations

from pathlib import Path

import pytest

from carbonation.api import CarbonationDB, connect, query_files


@pytest.fixture
def initialized_config(tmp_config: Path) -> Path:
    """Return a config path with an initialized database."""
    from click.testing import CliRunner
    from carbonation.cli import cli

    runner = CliRunner()
    result = runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
    assert result.exit_code == 0
    return tmp_config


class TestConnect:
    def test_returns_carbonation_db(self, initialized_config: Path):
        db = connect(initialized_config)
        try:
            assert isinstance(db, CarbonationDB)
        finally:
            db.close()

    def test_context_manager(self, initialized_config: Path):
        with connect(initialized_config) as db:
            assert isinstance(db, CarbonationDB)
            # Query works inside the context
            db.query_files(limit=10)

    def test_missing_config_raises(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            connect(tmp_path / "nonexistent.toml")

    def test_uninitialized_db_raises(self, tmp_config: Path):
        # tmp_config exists but db init has NOT been run
        with pytest.raises(RuntimeError, match="not initialized"):
            connect(tmp_config)

    def test_accepts_string_path(self, initialized_config: Path):
        with connect(str(initialized_config)) as db:
            assert isinstance(db, CarbonationDB)


class TestQueryFiles:
    def test_empty_db_returns_empty_list(self, initialized_config: Path):
        with connect(initialized_config) as db:
            rows = db.query_files(limit=10)
            assert rows == []

    def test_count_only_returns_zero(self, initialized_config: Path):
        with connect(initialized_config) as db:
            count = db.query_files(count_only=True)
            assert count == 0

    def test_with_filters(self, initialized_config: Path):
        with connect(initialized_config) as db:
            rows = db.query_files({"watch_name": ["test-watch"]})
            assert rows == []

    def test_with_columns(self, initialized_config: Path):
        with connect(initialized_config) as db:
            rows = db.query_files({"watch_name": ["test"]}, columns=["group_key", "watch_name"])
            assert rows == []

    def test_with_order_by(self, initialized_config: Path):
        with connect(initialized_config) as db:
            rows = db.query_files({"watch_name": ["test"]}, order_by="-created_at")
            assert rows == []

    def test_session_reused_across_calls(self, initialized_config: Path):
        with connect(initialized_config) as db:
            session_id = id(db._session)
            db.query_files(limit=10)
            db.query_files(count_only=True)
            db.query_files({"watch_name": ["test"]})
            assert id(db._session) == session_id

    def test_unbounded_query_raises(self, initialized_config: Path):
        with connect(initialized_config) as db:
            with pytest.raises(ValueError, match="Unbounded query"):
                db.query_files()


class TestOneShotQueryFiles:
    def test_one_shot_returns_results(self, initialized_config: Path):
        rows = query_files(initialized_config, limit=10)
        assert rows == []

    def test_one_shot_count(self, initialized_config: Path):
        count = query_files(initialized_config, count_only=True)
        assert count == 0

    def test_one_shot_with_filters(self, initialized_config: Path):
        rows = query_files(
            initialized_config,
            {"watch_name": ["test-watch"]},
            limit=10,
        )
        assert rows == []


class TestQueryWithData:
    def test_insert_and_query_back(self, initialized_config: Path):
        """Insert data via internal API, query it back via public API."""
        from carbonation.config import load_app_config
        from carbonation.db.engine import create_engine_from_config, create_session_factory
        from carbonation.db.models import get_file_model
        from carbonation.db.queries import find_or_create_file_group, update_file_metadata

        config = load_app_config(initialized_config)
        engine = create_engine_from_config(config.database)
        factory = create_session_factory(engine)

        # Insert a test group
        session = factory()
        try:
            group_id = find_or_create_file_group(
                session,
                watch_name="test-watch",
                group_key="sample_001",
                file_type="test",
            )
            update_file_metadata(session, group_id, {
                "label": "test-label",
                "category": "alpha",
            })
            session.commit()
        finally:
            session.close()
        engine.dispose()

        # Query it back via public API
        with connect(initialized_config) as db:
            rows = db.query_files({"watch_name": ["test-watch"]})
            assert len(rows) == 1
            assert rows[0]["group_key"] == "sample_001"

            count = db.query_files({"watch_name": ["test-watch"]}, count_only=True)
            assert count == 1

            # Filter by plugin column
            rows = db.query_files({"category": ["alpha"]})
            assert len(rows) == 1

            # No match
            rows = db.query_files({"category": ["nonexistent"]})
            assert len(rows) == 0


class TestPluginQueryDefaults:
    @pytest.fixture
    def config_with_defaults(self, tmp_path: Path) -> Path:
        """Config whose plugin defines query_defaults()."""
        from click.testing import CliRunner
        from carbonation.cli import cli

        plugins_dir = tmp_path / "plugins"
        plugins_dir.mkdir()
        (plugins_dir / "test_model.py").write_text(
            "def query_defaults() -> dict:\n"
            "    return {'limit': 5, 'order_by': '-created_at'}\n"
        )

        rules_file = tmp_path / "rules.toml"
        rules_file.write_text('[test-rules]\n')

        delivery_dir = tmp_path / "delivery"
        delivery_dir.mkdir()

        db_path = (tmp_path / "test.db").as_posix()
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[service]\npoll_interval = "5s"\nreconcile_interval = "1h"\n\n'
            f'[database]\nname = "{db_path}"\n\n'
            '[plugins]\ndirectory = "plugins"\n\n'
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "test-watch"\npath = "delivery"\n'
            'rules = "test-rules"\narchive = "test-archive"\n\n'
            '[[archive]]\nname = "test-archive"\ndestination = "archive"\n'
        )

        runner = CliRunner()
        result = runner.invoke(cli, ["--config", str(config_file), "db", "init"])
        assert result.exit_code == 0
        return config_file

    def test_defaults_applied(self, config_with_defaults: Path):
        with connect(config_with_defaults) as db:
            assert db._query_defaults == {"limit": 5, "order_by": "-created_at"}

    def test_defaults_prevent_unbounded_query(self, config_with_defaults: Path):
        """Plugin default limit satisfies the unbounded query guard."""
        with connect(config_with_defaults) as db:
            # No explicit filter or limit — plugin default limit=5 kicks in
            rows = db.query_files()
            assert rows == []

    def test_explicit_overrides_default(self, config_with_defaults: Path):
        with connect(config_with_defaults) as db:
            # Explicit limit=10 overrides plugin default of 5
            rows = db.query_files(limit=10)
            assert rows == []

    def test_explicit_none_overrides_default(self, config_with_defaults: Path):
        """Passing limit=None explicitly overrides the plugin default."""
        with connect(config_with_defaults) as db:
            # limit=None + no filters → unbounded query error
            with pytest.raises(ValueError, match="Unbounded query"):
                db.query_files(limit=None)


class TestDescribeFilters:
    def test_returns_list_of_dicts(self, initialized_config: Path):
        with connect(initialized_config) as db:
            filters = db.describe_filters()
            assert isinstance(filters, list)
            assert len(filters) > 0
            assert all(isinstance(f, dict) for f in filters)

    def test_contains_expected_keys(self, initialized_config: Path):
        with connect(initialized_config) as db:
            filters = db.describe_filters()
            for f in filters:
                assert "filter_key" in f
                assert "type" in f
                assert "description" in f
                assert "column" in f
                assert "plugin" in f

    def test_includes_base_columns(self, initialized_config: Path):
        with connect(initialized_config) as db:
            filters = db.describe_filters()
            keys = {f["filter_key"] for f in filters}
            assert "watch_name" in keys
            assert "created_at_after" in keys
            assert "created_at_before" in keys

    def test_includes_plugin_columns(self, initialized_config: Path):
        """Plugin columns from _TestFile (label, start, stop, category, source)."""
        with connect(initialized_config) as db:
            filters = db.describe_filters()
            keys = {f["filter_key"] for f in filters}
            assert "category" in keys
            assert "source" in keys
            assert "start_after" in keys
            assert "stop_before" in keys

    def test_includes_daterange_for_start_stop(self, initialized_config: Path):
        with connect(initialized_config) as db:
            filters = db.describe_filters()
            keys = {f["filter_key"] for f in filters}
            assert "_daterange" in keys
            assert "_age" in keys

    def test_plugin_flag_set_correctly(self, initialized_config: Path):
        with connect(initialized_config) as db:
            filters = db.describe_filters()
            by_key = {f["filter_key"]: f for f in filters}
            assert by_key["watch_name"]["plugin"] is False
            assert by_key["category"]["plugin"] is True


class TestTopLevelImports:
    def test_connect_importable_from_package(self):
        from carbonation import connect as c
        assert callable(c)

    def test_query_files_importable_from_package(self):
        from carbonation import query_files as qf
        assert callable(qf)
