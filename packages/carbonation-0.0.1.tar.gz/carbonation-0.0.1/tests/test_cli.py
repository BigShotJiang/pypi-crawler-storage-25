"""Tests for CLI commands."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from carbonation.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


class TestCheckConfig:
    def test_valid_config(self, runner: CliRunner, tmp_config: Path):
        result = runner.invoke(cli, ["--config", str(tmp_config), "check-config"])
        assert result.exit_code == 0
        assert "Config is valid" in result.output

    def test_missing_config(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(
            cli, ["--config", str(tmp_path / "missing.toml"), "check-config"]
        )
        assert result.exit_code != 0

    def test_missing_rules_file(self, runner: CliRunner, tmp_path: Path):
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "nonexistent.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code != 0
        assert "Rules file not found" in result.output

    def test_bad_watch_rules_reference(self, runner: CliRunner, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[existing-rules]\n")

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\n'
            'rules = "nonexistent-rules"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code != 0
        assert "nonexistent-rules" in result.output

    def test_bad_watch_archive_reference(self, runner: CliRunner, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[r]\n")

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\n'
            'rules = "r"\narchive = "nonexistent-archive"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code != 0
        assert "nonexistent-archive" in result.output

    def test_warns_on_missing_completeness_extension(
        self, runner: CliRunner, tmp_path: Path
    ):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text(
            '[r]\n'
            '[r.completeness]\n'
            'group_by = "stem"\n'
            'expected_extensions = [".csv", ".json"]\n'
        )

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\n'
            'rules = "r"\narchive = "a"\n'
            'patterns = ["*.csv"]\n\n'  # missing *.json
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code == 0  # warnings don't fail
        assert "WARNING" in result.output
        assert ".json" in result.output


class TestDbInit:
    def test_creates_database(self, runner: CliRunner, tmp_config: Path):
        result = runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        assert result.exit_code == 0
        assert "Database initialized" in result.output

    def test_no_plugins_dir_errors(self, runner: CliRunner, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[r]\n")

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "db", "init"])
        assert result.exit_code != 0
        assert "plugins" in result.output.lower()


class TestDbStatus:
    def test_shows_status(self, runner: CliRunner, tmp_config: Path):
        # First init the database
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "db", "status"])
        assert result.exit_code == 0
        assert "In delivery:" in result.output
        assert "In archive:" in result.output

    def test_requires_initialized_db(self, runner: CliRunner, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[r]\n")
        plugins_dir = tmp_path / "plugins"
        plugins_dir.mkdir()

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            f'[database]\nname = "{(tmp_path / "empty.db").as_posix()}"\n\n'
            '[plugins]\ndirectory = "plugins"\n\n'
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "db", "status"])
        assert result.exit_code != 0
        assert "not initialized" in result.output.lower()


class TestStatus:
    def test_shows_status(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "status"])
        assert result.exit_code == 0
        assert "In delivery:" in result.output
        assert "Watch directories:" in result.output

    def test_shows_heartbeat_no_data(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "status"])
        assert "no data" in result.output.lower()


class TestRetry:
    def test_retry_no_failures(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "retry"])
        assert result.exit_code == 0
        assert "0 component(s)" in result.output

    def test_retry_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["retry", "--help"])
        assert result.exit_code == 0
        assert "--watch-name" in result.output
        assert "--group-key" in result.output


class TestCheckRules:
    def test_check_rules_no_groups(self, runner: CliRunner, tmp_config: Path, tmp_path: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        rules_file = tmp_path / "candidate.toml"
        rules_file.write_text(
            '[test-rules]\n'
            '[[test-rules.integrity]]\n'
            'type = "min_size"\n'
            'value = 5\n'
        )
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "check-rules", str(rules_file)]
        )
        assert result.exit_code == 0
        assert "No completed groups" in result.output

    def test_check_rules_invalid_file(self, runner: CliRunner, tmp_config: Path, tmp_path: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        bad_file = tmp_path / "bad.toml"
        bad_file.write_text("not valid {{{ toml")
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "check-rules", str(bad_file)]
        )
        assert result.exit_code != 0
        assert "Invalid rules file" in result.output

    def test_warns_on_bad_primary_extension(self, runner: CliRunner, tmp_path: Path):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text(
            '[r]\n'
            '[r.completeness]\n'
            'group_by = "stem"\n'
            'expected_extensions = [".csv", ".json"]\n'
            'primary_extension = ".txt"\n'
        )
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code == 0
        assert "primary_extension" in result.output
        assert ".txt" in result.output


class TestStatusOutput:
    def test_shows_time_buckets(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "status"])
        assert result.exit_code == 0
        # The rich table should contain time bucket headers
        assert "1h" in result.output or "No components" in result.output

    def test_shows_watch_health(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "status"])
        assert result.exit_code == 0
        assert "Watch directories:" in result.output


class TestStructuredLogging:
    def test_json_format_config(self):
        from carbonation.config import LoggingConfig
        cfg = LoggingConfig(format="json")
        assert cfg.format == "json"

    def test_invalid_format_rejected(self):
        from carbonation.config import LoggingConfig
        with pytest.raises(Exception):
            LoggingConfig(format="xml")

    def test_json_logging_produces_json(self, tmp_path: Path):
        import json
        from loguru import logger
        from carbonation.config import LoggingConfig
        from carbonation.log import setup_logging

        log_file = tmp_path / "test.log"
        cfg = LoggingConfig(level="INFO", file=log_file, format="json")
        setup_logging(cfg)
        logger.info("test message")
        logger.remove()  # flush

        lines = log_file.read_text(encoding="utf-8").strip().split("\n")
        assert len(lines) >= 1
        parsed = json.loads(lines[0])
        assert "text" in parsed
        assert "test message" in parsed["text"]


class TestInit:
    def test_scaffolds_project(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(cli, ["init", "--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert (tmp_path / "config.toml").exists()
        assert (tmp_path / "rules.toml").exists()
        assert (tmp_path / "plugins" / "file_model.py").exists()
        assert "CREATED" in result.output

    def test_skips_existing_files(self, runner: CliRunner, tmp_path: Path):
        (tmp_path / "config.toml").write_text("existing")
        result = runner.invoke(cli, ["init", "--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "SKIP" in result.output
        assert (tmp_path / "config.toml").read_text() == "existing"

    def test_systemd_flag(self, runner: CliRunner, tmp_path: Path):
        result = runner.invoke(cli, ["init", "--dir", str(tmp_path), "--systemd", "--user", "testuser"])
        assert result.exit_code == 0
        svc = (tmp_path / "carbonation.service").read_text()
        assert "User=testuser" in svc
        assert str(tmp_path) in svc

    def test_scaffolded_project_passes_check_config(self, runner: CliRunner, tmp_path: Path):
        """The scaffolded config + rules + plugin pass check-config validation."""
        # Scaffold
        runner.invoke(cli, ["init", "--dir", str(tmp_path)])
        # Create the delivery directory so the watch path exists
        (tmp_path / "delivery").mkdir()
        # Validate
        result = runner.invoke(cli, ["--config", str(tmp_path / "config.toml"), "check-config"])
        assert result.exit_code == 0
        assert "Config is valid" in result.output

    def test_scaffolded_project_db_init(self, runner: CliRunner, tmp_path: Path):
        """The scaffolded project can initialize its database."""
        runner.invoke(cli, ["init", "--dir", str(tmp_path)])
        (tmp_path / "delivery").mkdir()
        result = runner.invoke(cli, ["--config", str(tmp_path / "config.toml"), "db", "init"])
        assert result.exit_code == 0
        assert "Database initialized" in result.output


class TestRunDryRun:
    def test_dry_run_succeeds(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(cli, ["--config", str(tmp_config), "run", "--dry-run"])
        assert result.exit_code == 0
        assert "Dry run complete" in result.output

    def test_dry_run_requires_db(self, runner: CliRunner, tmp_config: Path):
        result = runner.invoke(cli, ["--config", str(tmp_config), "run", "--dry-run"])
        assert result.exit_code != 0
        assert "not initialized" in result.output.lower()

    def test_run_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["run", "--help"])
        assert result.exit_code == 0
        assert "--dry-run" in result.output


class TestReconcileDelivery:
    def test_reconcile_delivery(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "reconcile", "delivery"]
        )
        assert result.exit_code == 0
        assert "Delivery reconciliation complete" in result.output

    def test_reconcile_delivery_with_files(self, runner: CliRunner, tmp_config: Path):
        # Add a file to the delivery directory
        delivery_dir = tmp_config.parent / "delivery"
        (delivery_dir / "test_file.csv").write_text("hello world!")
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "reconcile", "delivery"]
        )
        assert result.exit_code == 0
        assert "new=1" in result.output


class TestReconcileArchive:
    def test_reconcile_archive(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "reconcile", "archive"]
        )
        assert result.exit_code == 0
        assert "Archive reconciliation complete" in result.output

    def test_reconcile_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["reconcile", "--help"])
        assert result.exit_code == 0
        assert "delivery" in result.output
        assert "archive" in result.output


class TestQueryFiles:
    def test_query_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["query", "--help"])
        assert result.exit_code == 0
        assert "files" in result.output

    def test_query_files_empty(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "query", "files"]
        )
        assert result.exit_code == 0
        assert "No results" in result.output

    def test_query_files_count(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "query", "files", "--count"]
        )
        assert result.exit_code == 0
        assert "0" in result.output

    def test_query_files_json_format(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "query", "files", "--format", "json"]
        )
        assert result.exit_code == 0

    def test_query_files_csv_format(self, runner: CliRunner, tmp_config: Path):
        runner.invoke(cli, ["--config", str(tmp_config), "db", "init"])
        result = runner.invoke(
            cli, ["--config", str(tmp_config), "query", "files", "--format", "csv"]
        )
        assert result.exit_code == 0


class TestHardlinkFileModeWarning:
    def test_warns_on_hardlink_with_custom_file_mode(
        self, runner: CliRunner, tmp_path: Path
    ):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[r]\n")

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
            'action = "hardlink"\nfile_mode = 0o440\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code == 0
        assert "file_mode has no effect" in result.output

    def test_no_warning_for_hardlink_with_default_mode(
        self, runner: CliRunner, tmp_path: Path
    ):
        rules_file = tmp_path / "rules.toml"
        rules_file.write_text("[r]\n")

        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[rules]\nfile = "rules.toml"\n\n'
            '[[watch]]\nname = "w"\npath = "."\nrules = "r"\narchive = "a"\n\n'
            '[[archive]]\nname = "a"\ndestination = "/tmp"\n'
            'action = "hardlink"\n'
        )
        result = runner.invoke(cli, ["--config", str(config_file), "check-config"])
        assert result.exit_code == 0
        assert "file_mode" not in result.output


class TestHelp:
    def test_main_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "Carbonation" in result.output

    def test_db_help(self, runner: CliRunner):
        result = runner.invoke(cli, ["db", "--help"])
        assert result.exit_code == 0
        assert "init" in result.output
