"""Configuration models and TOML loading for carbonation."""

from __future__ import annotations

import re
import tomllib
from datetime import datetime
from pathlib import Path
from typing import Any, ClassVar

from pydantic import BaseModel, Field, field_validator

from carbonation.exceptions import ConfigError


# Maximum allowed duration: 365 days.  This prevents unreasonable values
# that would overflow timers or timedelta arithmetic while still allowing
# any duration a real deployment would need.
_MAX_DURATION_SECONDS = 365 * 24 * 3600  # 31_536_000


def parse_duration(value: str) -> float:
    """Parse a duration string like '5s', '1m', '24h' into seconds.

    Raises :class:`ConfigError` for invalid formats or values exceeding 365 days.
    """
    match = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(s|m|h|d)", value.strip())
    if not match:
        raise ConfigError(f"Invalid duration: {value!r}. Use e.g. '5s', '1m', '24h'.")
    amount = float(match.group(1))
    unit = match.group(2)
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    result = amount * multipliers[unit]
    if result > _MAX_DURATION_SECONDS:
        raise ConfigError(
            f"Duration too large: {value!r} exceeds maximum of 365 days"
        )
    return result


def parse_daterange(value: str) -> tuple[datetime | None, datetime | None]:
    """Parse a daterange string into (start, end) datetimes.

    Formats:
        TIME              → (TIME, TIME) — exact instant
        START/END         → (START, END) — range
        START/            → (START, None) — open end
        /END              → (None, END) — open start

    Datetime values are ISO 8601 (e.g. 2026-01-15 or 2026-01-15T12:00:00).
    """
    if "/" in value:
        left, right = value.split("/", 1)
        start = datetime.fromisoformat(left) if left else None
        end = datetime.fromisoformat(right) if right else None
        return start, end
    # Single value — exact instant
    t = datetime.fromisoformat(value)
    return t, t


class ServiceConfig(BaseModel):
    poll_interval: str = "5s"
    reconcile_interval: str = "24h"
    heartbeat_interval: str = "60s"
    workers: int = 4
    max_retries: int = 3
    retry_delay: str = "30m"
    stale_threshold: str = "1d"

    @field_validator("poll_interval", "reconcile_interval", "heartbeat_interval", "retry_delay", "stale_threshold")
    @classmethod
    def validate_duration(cls, v: str) -> str:
        parse_duration(v)  # validate, but store as string
        return v

    @property
    def poll_interval_seconds(self) -> float:
        return parse_duration(self.poll_interval)

    @property
    def reconcile_interval_seconds(self) -> float:
        return parse_duration(self.reconcile_interval)

    @property
    def heartbeat_interval_seconds(self) -> float:
        return parse_duration(self.heartbeat_interval)

    @property
    def retry_delay_seconds(self) -> float:
        return parse_duration(self.retry_delay)

    @property
    def stale_threshold_seconds(self) -> float:
        return parse_duration(self.stale_threshold)


class LoggingConfig(BaseModel):
    level: str = "INFO"
    file: Path | None = None
    rotation: str = "10 MB"
    retention: str = "30 days"
    format: str = "text"

    @field_validator("format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        if v not in ("text", "json"):
            raise ValueError(f"format must be 'text' or 'json', got {v!r}")
        return v


class DatabaseConfig(BaseModel):
    drivername: str = "sqlite"
    username: str | None = None
    password: str | None = None
    host: str | None = None
    port: int | None = None
    name: str | None = "carbonation.db"
    echo: bool = False

    @property
    def url(self) -> str:
        from sqlalchemy.engine import URL
        return str(URL.create(
            drivername=self.drivername,
            username=self.username,
            password=self.password,
            host=self.host,
            port=self.port,
            database=self.name,
        ))


class PluginsConfig(BaseModel):
    directory: Path | None = None


class RulesFileConfig(BaseModel):
    file: Path = Path("rules.toml")


class WatchConfig(BaseModel):
    name: str
    type: str | None = None
    path: Path
    recursive: bool = False
    patterns: list[str] | None = None
    ignore_patterns: list[str] = Field(default_factory=lambda: ["*.tmp", ".*"])
    rules: str
    archive: str
    settle_seconds: float = Field(default=2.0, gt=0)


_ALLOWED_DIR_MODES = {0o700, 0o750, 0o755, 0o770, 0o777}
_ALLOWED_FILE_MODES = {0o600, 0o640, 0o644, 0o660, 0o666, 0o440, 0o444}


class ArchiveConfig(BaseModel):
    name: str
    destination: str
    base_path: Path | None = None
    action: str = "copy"
    create_directories: bool = True
    file_mode: int = 0o640
    dir_mode: int = 0o750

    @field_validator("action")
    @classmethod
    def validate_action(cls, v: str) -> str:
        allowed = {"copy", "move", "hardlink", "symlink"}
        if v not in allowed:
            raise ValueError(f"action must be one of {allowed}, got {v!r}")
        return v

    @field_validator("file_mode", mode="before")
    @classmethod
    def parse_file_mode(cls, v: int | str) -> int:
        if isinstance(v, str):
            v = int(v, 8)
        if v not in _ALLOWED_FILE_MODES:
            allowed = ", ".join(oct(m) for m in sorted(_ALLOWED_FILE_MODES))
            raise ValueError(
                f"file_mode {oct(v)} is not allowed. Choose from: {allowed}"
            )
        return v

    @field_validator("dir_mode", mode="before")
    @classmethod
    def parse_dir_mode(cls, v: int | str) -> int:
        if isinstance(v, str):
            v = int(v, 8)
        if v not in _ALLOWED_DIR_MODES:
            allowed = ", ".join(oct(m) for m in sorted(_ALLOWED_DIR_MODES))
            raise ValueError(
                f"dir_mode {oct(v)} is not allowed. Choose from: {allowed}"
            )
        return v


class AppConfig(BaseModel):
    service: ServiceConfig = Field(default_factory=ServiceConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    plugins: PluginsConfig = Field(default_factory=PluginsConfig)
    rules: RulesFileConfig = Field(default_factory=RulesFileConfig)
    watch: list[WatchConfig]
    archive: list[ArchiveConfig]


# --- Rules config models ---


class IntegrityCheck(BaseModel):
    type: str
    value: int | float | str | None = None


class CompletenessConfig(BaseModel):
    group_by: str = "stem"
    expected_extensions: list[str] = Field(default_factory=list)
    primary_extension: str | None = None
    timeout_minutes: int = 120
    on_timeout: str = "warn"
    group_function: str | None = None

    @field_validator("group_by")
    @classmethod
    def validate_group_by(cls, v: str) -> str:
        allowed = {"stem", "plugin"}
        if v not in allowed:
            raise ValueError(f"group_by must be one of {allowed}, got {v!r}")
        return v

    @field_validator("on_timeout")
    @classmethod
    def validate_on_timeout(cls, v: str) -> str:
        allowed = {"warn", "skip", "archive_partial"}
        if v not in allowed:
            raise ValueError(f"on_timeout must be one of {allowed}, got {v!r}")
        return v


class MetadataConfig(BaseModel):
    module: str | None = None


class SelectionRule(BaseModel):
    """A single selection rule. Multiple rules are ORed."""

    model_config: ClassVar = {"arbitrary_types_allowed": True}

    has_keys: list[str] | None = None
    field: str | None = None
    matches: list[str] | None = None
    compiled_patterns: list[re.Pattern[str]] = Field(default_factory=list, exclude=True)
    type: str | None = None
    function: str | None = None
    kwargs: dict[str, Any] = Field(default_factory=dict)

    def model_post_init(self, __context: Any) -> None:
        if self.matches is not None:
            object.__setattr__(
                self,
                "compiled_patterns",
                [re.compile(p) for p in self.matches],
            )


class RoutingRule(BaseModel):
    match: str | None = None
    archive: str | None = None
    type: str | None = None
    function: str | None = None


class RuleSet(BaseModel):
    integrity: list[IntegrityCheck] = Field(default_factory=list)
    completeness: CompletenessConfig | None = None
    metadata: MetadataConfig | None = None
    selection: list[SelectionRule] = Field(default_factory=list)
    routing: list[RoutingRule] = Field(default_factory=list)


class RulesConfig(BaseModel):
    """Top-level rules config. Keys are rule set names."""

    rule_sets: dict[str, RuleSet]


# --- Loading functions ---


def _resolve_path(path: Path, base_dir: Path) -> Path:
    """Resolve a path relative to a base directory if not absolute."""
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _load_secrets(db_data: dict) -> dict:
    """Layer database credentials from user secrets file.

    Reads ~/.config/carbonation/secrets.toml if it exists.
    Values in the secrets file have lower priority than values
    already in db_data (which come from config.toml).
    """
    secrets_dir = Path.home() / ".config" / "carbonation"
    secrets_path = secrets_dir / "secrets.toml"
    if secrets_path.is_file():
        with open(secrets_path, "rb") as f:
            secrets = tomllib.load(f)
        db_secrets = secrets.get("database", {})
        for key in ("username", "password", "host", "port", "name", "drivername"):
            if key in db_secrets and key not in db_data:
                db_data[key] = db_secrets[key]
    return db_data


def load_app_config(config_path: Path) -> AppConfig:
    """Load and validate config.toml.

    Credential resolution order (highest priority first):
    1. Values in config.toml
    2. User secrets (~/.config/carbonation/secrets.toml)
    3. Defaults
    """
    config_path = config_path.resolve()
    base_dir = config_path.parent

    with open(config_path, "rb") as f:
        raw = tomllib.load(f)

    # Layer in secrets before validation
    if "database" in raw:
        raw["database"] = _load_secrets(raw["database"])
    else:
        raw["database"] = _load_secrets({})

    config = AppConfig.model_validate(raw)

    # Resolve relative paths against config.toml location
    if config.logging.file is not None:
        config.logging.file = _resolve_path(config.logging.file, base_dir)
    if config.plugins.directory is not None:
        config.plugins.directory = _resolve_path(config.plugins.directory, base_dir)
    config.rules.file = _resolve_path(config.rules.file, base_dir)
    for w in config.watch:
        w.path = _resolve_path(w.path, base_dir)
    for a in config.archive:
        if a.base_path is not None:
            a.base_path = _resolve_path(a.base_path, base_dir)

    # Resolve SQLite relative database name to absolute path
    if (
        config.database.drivername == "sqlite"
        and config.database.name is not None
        and config.database.name != ":memory:"
        and not Path(config.database.name).is_absolute()
    ):
        config.database.name = str(_resolve_path(Path(config.database.name), base_dir))

    return config


def _parse_rule_set(name: str, raw: dict[str, Any]) -> RuleSet:
    """Parse a single rule set from the flat TOML structure."""
    integrity = raw.get("integrity", [])
    completeness = raw.get("completeness")
    metadata = raw.get("metadata")
    selection = raw.get("selection", [])
    routing = raw.get("routing", [])

    return RuleSet(
        integrity=[IntegrityCheck.model_validate(c) for c in integrity],
        completeness=(
            CompletenessConfig.model_validate(completeness) if completeness else None
        ),
        metadata=(MetadataConfig.model_validate(metadata) if metadata else None),
        selection=[SelectionRule.model_validate(s) for s in selection],
        routing=[RoutingRule.model_validate(r) for r in routing],
    )


def load_rules_config(rules_path: Path) -> RulesConfig:
    """Load and validate rules.toml."""
    with open(rules_path, "rb") as f:
        raw = tomllib.load(f)

    rule_sets = {}
    for name, value in raw.items():
        if isinstance(value, dict):
            rule_sets[name] = _parse_rule_set(name, value)

    return RulesConfig(rule_sets=rule_sets)
