"""Carbonation service orchestrator.

Ties together watcher, rules, archive, reconciliation, and the DB.
"""

from __future__ import annotations

import os
import signal
import threading
import weakref
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
from queue import Empty, Queue

import sdnotify
from loguru import logger
from sqlalchemy.engine import Engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, sessionmaker
from watchdog.events import FileModifiedEvent, FileSystemEventHandler
from watchdog.observers import Observer

from carbonation.archive import archive_file, resolve_destination
from carbonation.config import (
    AppConfig,
    ArchiveConfig,
    RulesConfig,
    WatchConfig,
    load_rules_config,
)
from carbonation.db.models import FileStatus
from carbonation.db.queries import (
    assign_component_to_group,
    find_or_create_file_group,
    get_component_by_source_path,
    get_group_components,
    get_not_selected_in_delivery,
    get_retry_pending,
    get_retry_pending_no_retry_yet,
    get_status_counts,
    get_timed_out_groups,
    mark_for_retry,
    mark_group_complete,
    record_component,
    update_component_status,
    update_file_metadata,
    update_heartbeat,
)
from carbonation.plugins import PluginRegistry
from carbonation.reconcile import reconcile_delivery
from carbonation.rules import (
    check_completeness,
    check_integrity,
    evaluate_selection,
    resolve_group_key,
    resolve_routing,
)
from carbonation.watcher import FileArrivalHandler, FileEvent, create_observers


class _RulesFileHandler(FileSystemEventHandler):
    """Watches rules.toml for changes and triggers a debounced reload."""

    def __init__(self, rules_path: Path, callback: Callable[[], None]) -> None:
        super().__init__()
        self._rules_path = rules_path
        self._callback = callback
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()

    def on_modified(self, event: FileModifiedEvent) -> None:
        if event.is_directory:
            return
        if Path(event.src_path).resolve() != self._rules_path.resolve():
            return
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(0.5, self._callback)
            self._timer.daemon = True
            self._timer.start()

    def cancel(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()


class CarbonationService:
    """Main service that orchestrates file monitoring, rules, and archiving."""

    def __init__(
        self,
        app_config: AppConfig,
        rules_config: RulesConfig,
        registry: PluginRegistry,
        engine: Engine,
        session_factory: sessionmaker[Session],
    ) -> None:
        self.app_config = app_config
        self.rules_config = rules_config
        self.registry = registry
        self.engine = engine
        self.session_factory = session_factory

        self.event_queue: Queue[FileEvent] = Queue()
        self._shutdown = threading.Event()
        self._group_locks: weakref.WeakValueDictionary[str, threading.Lock] = (
            weakref.WeakValueDictionary()
        )
        self._group_locks_lock = threading.Lock()
        self._observers: list[Observer] = []
        self._handlers: list[FileArrivalHandler] = []
        self._executor: ThreadPoolExecutor | None = None
        self._reconcile_timer: threading.Timer | None = None
        self._heartbeat_timer: threading.Timer | None = None
        self._rules_observer: Observer | None = None
        self._rules_handler: _RulesFileHandler | None = None
        self._notifier = sdnotify.SystemdNotifier()

        # Build lookup maps
        self._archive_by_name: dict[str, ArchiveConfig] = {
            a.name: a for a in app_config.archive
        }
        self._watch_by_name: dict[str, WatchConfig] = {
            w.name: w for w in app_config.watch
        }

    def run_once(self) -> int:
        """Run a single processing pass and exit.

        Reconciles delivery directories, checks timeouts and retries,
        processes all enqueued events, and exits.  Suitable for cron.

        Returns:
            0 if the pass completed successfully, 1 if carbonation
            itself encountered an error.
        """
        logger.info("Carbonation run-once starting...")

        session = self.session_factory()
        try:
            update_heartbeat(
                session,
                started_at=datetime.now(timezone.utc),
                queue_depth=self.event_queue.qsize(),
            )
            session.commit()
        finally:
            session.close()

        # Reconcile delivery directories
        stale_threshold = timedelta(
            seconds=self.app_config.service.stale_threshold_seconds
        )
        try:
            for wc in self.app_config.watch:
                session = self.session_factory()
                try:
                    stats = reconcile_delivery(
                        session,
                        wc,
                        event_queue=self.event_queue,
                        stale_threshold=stale_threshold,
                    )
                    logger.info(
                        f"Delivery reconcile [{wc.name}]: "
                        f"{stats['new']} new, {stats['cleared']} cleared, "
                        f"{stats['requeued']} requeued"
                    )
                finally:
                    session.close()

            # Check completeness timeouts and pending retries
            self._check_completeness_timeouts()
            self._check_pending_retries()

            # Drain the event queue with workers
            workers = self.app_config.service.workers
            executor = ThreadPoolExecutor(max_workers=workers)
            futures = []
            while not self.event_queue.empty():
                try:
                    event = self.event_queue.get_nowait()
                except Empty:
                    break
                futures.append(executor.submit(self._process_event, event))
            executor.shutdown(wait=True)

            # Update heartbeat
            self._update_heartbeat_and_stats()

            logger.info("Carbonation run-once complete.")
            return 0
        except Exception:
            logger.exception("Carbonation run-once failed")
            return 1

    def start(self, dry_run: bool = False) -> None:
        """Start the service."""
        logger.info("Carbonation service starting...")

        # Record service start in DB
        session = self.session_factory()
        try:
            update_heartbeat(
                session,
                started_at=datetime.now(timezone.utc),
                queue_depth=self.event_queue.qsize(),
            )
            session.commit()
        finally:
            session.close()

        # Reconcile delivery directories
        stale_threshold = timedelta(
            seconds=self.app_config.service.stale_threshold_seconds
        )
        for wc in self.app_config.watch:
            session = self.session_factory()
            try:
                stats = reconcile_delivery(
                    session,
                    wc,
                    event_queue=self.event_queue if not dry_run else None,
                    stale_threshold=stale_threshold,
                )
                logger.info(
                    f"Delivery reconcile [{wc.name}]: "
                    f"{stats['new']} new, {stats['cleared']} cleared, "
                    f"{stats['requeued']} requeued"
                )
            finally:
                session.close()

        if dry_run:
            logger.info("Dry run complete — exiting without starting watchers")
            return

        # Start watchdog observers
        obs_handlers = create_observers(self.app_config.watch, self.event_queue)
        for observer, handler in obs_handlers:
            observer.start()
            self._observers.append(observer)
            self._handlers.append(handler)

        # Watch rules.toml for hot-reload
        self._start_rules_watcher()

        # Start worker thread pool
        workers = self.app_config.service.workers
        self._executor = ThreadPoolExecutor(max_workers=workers)
        logger.info(f"Started {workers} worker threads")

        # Schedule periodic reconciliation and heartbeat
        self._schedule_reconciliation()
        self._schedule_heartbeat()

        # Install signal handlers (only works in main thread)
        try:
            signal.signal(signal.SIGINT, self._signal_handler)
            signal.signal(signal.SIGTERM, self._signal_handler)
        except ValueError:
            pass  # not in main thread — caller is responsible for shutdown

        logger.info("Carbonation service running. Press Ctrl+C to stop.")
        self._notifier.notify("READY=1")
        self._notifier.notify("STATUS=Running")

        # Main loop: dispatch events to worker pool
        try:
            while not self._shutdown.is_set():
                try:
                    event = self.event_queue.get(timeout=1.0)
                except Empty:
                    continue
                self._executor.submit(self._process_event, event)
        finally:
            self.stop()

    def stop(self) -> None:
        """Gracefully shut down the service."""
        if self._shutdown.is_set():
            return
        self._shutdown.set()
        self._notifier.notify("STOPPING=1")
        self._notifier.notify("STATUS=Shutting down")
        logger.info("Shutting down...")

        # Cancel timers
        if self._reconcile_timer is not None:
            self._reconcile_timer.cancel()
        if self._heartbeat_timer is not None:
            self._heartbeat_timer.cancel()

        # Stop rules watcher
        if self._rules_handler is not None:
            self._rules_handler.cancel()
        if self._rules_observer is not None:
            self._rules_observer.stop()
            self._rules_observer.join(timeout=5)

        # Stop delivery watchdog observers
        for handler in self._handlers:
            handler.cancel_all()
        for observer in self._observers:
            observer.stop()
        for observer in self._observers:
            observer.join(timeout=5)

        # Shut down worker pool
        if self._executor is not None:
            self._executor.shutdown(wait=True, cancel_futures=False)

        logger.info("Carbonation service stopped.")

    def _signal_handler(self, signum: int, frame: object) -> None:
        logger.info(f"Received signal {signum}")
        self._shutdown.set()

    def _start_rules_watcher(self) -> None:
        """Watch rules.toml for changes and hot-reload on modification."""
        rules_path = self.app_config.rules.file
        if not rules_path.is_file():
            logger.warning(f"Rules file not found, skipping hot-reload: {rules_path}")
            return

        self._rules_handler = _RulesFileHandler(rules_path, self._reload_rules)
        self._rules_observer = Observer()
        self._rules_observer.schedule(
            self._rules_handler,
            str(rules_path.parent),
            recursive=False,
        )
        self._rules_observer.start()
        logger.info(f"Watching rules file for changes: {rules_path}")

    def _reload_rules(self) -> None:
        """Attempt to reload and validate rules.toml, swapping on success."""
        if self._shutdown.is_set():
            return
        rules_path = self.app_config.rules.file
        try:
            new_rules = load_rules_config(rules_path)
        except Exception:
            logger.exception("Rules reload failed — keeping current rules")
            return

        # Validate that all watch configs still reference valid rule sets
        for wc in self.app_config.watch:
            if wc.rules not in new_rules.rule_sets:
                logger.error(
                    f"Rules reload rejected: watch '{wc.name}' references "
                    f"rule set '{wc.rules}' which is missing from the new rules file"
                )
                return

        self.rules_config = new_rules
        logger.info(f"Rules reloaded successfully from {rules_path}")

        # Re-enqueue NOT_SELECTED components for re-evaluation against new rules.
        # Only enqueue one representative component per group (primary extension
        # or first component) — the pipeline re-fetches all group components.
        self._reenqueue_not_selected()

    def _reenqueue_not_selected(self) -> None:
        """Re-enqueue one component per NOT_SELECTED group for re-evaluation."""
        session = self.session_factory()
        try:
            components = get_not_selected_in_delivery(session)
        finally:
            session.close()

        if not components:
            return

        # Group by group_id (None for standalone files)
        groups: dict[int | None, list[dict]] = {}
        for comp in components:
            groups.setdefault(comp["group_id"], []).append(comp)

        enqueued = 0
        for group_id, group_comps in groups.items():
            # Pick the primary extension component if configured, else first
            chosen = group_comps[0]
            watch_name = chosen["watch_name"]
            wc = self._watch_by_name.get(watch_name)
            if wc is not None:
                rs = self.rules_config.rule_sets.get(wc.rules)
                if rs and rs.completeness and rs.completeness.primary_extension:
                    primary_ext = rs.completeness.primary_extension
                    for comp in group_comps:
                        if Path(comp["source_path"]).suffix == primary_ext:
                            chosen = comp
                            break

            self.event_queue.put(
                FileEvent(
                    watch_name=chosen["watch_name"],
                    path=Path(chosen["source_path"]),
                )
            )
            enqueued += 1

        logger.info(
            f"Rules changed: re-enqueued {enqueued} NOT_SELECTED group(s) for re-evaluation"
        )

    def _schedule_reconciliation(self) -> None:
        """Schedule the next periodic reconciliation."""
        interval = self.app_config.service.reconcile_interval_seconds
        self._reconcile_timer = threading.Timer(interval, self._periodic_reconcile)
        self._reconcile_timer.daemon = True
        self._reconcile_timer.start()

    def _schedule_heartbeat(self) -> None:
        """Schedule the next heartbeat."""
        interval = self.app_config.service.heartbeat_interval_seconds
        self._heartbeat_timer = threading.Timer(interval, self._periodic_heartbeat)
        self._heartbeat_timer.daemon = True
        self._heartbeat_timer.start()

    def _periodic_heartbeat(self) -> None:
        """Update heartbeat in DB, ping systemd watchdog, and reschedule."""
        if self._shutdown.is_set():
            return
        self._update_heartbeat_and_stats()
        if not self._shutdown.is_set():
            self._schedule_heartbeat()

    def _periodic_reconcile(self) -> None:
        """Run periodic reconciliation, timeout checks, and reschedule."""
        if self._shutdown.is_set():
            return
        logger.info("Running periodic delivery reconciliation")
        for wc in self.app_config.watch:
            session = self.session_factory()
            try:
                reconcile_delivery(
                    session,
                    wc,
                    event_queue=self.event_queue,
                    stale_threshold=timedelta(
                        seconds=self.app_config.service.stale_threshold_seconds
                    ),
                )
            except Exception:
                logger.exception(f"Reconciliation failed for [{wc.name}]")
            finally:
                session.close()

        # Check for timed-out incomplete groups
        self._check_completeness_timeouts()

        # Retry pending components
        self._check_pending_retries()

        # Check watch directory health
        self._check_watch_health()

        # Reschedule
        if not self._shutdown.is_set():
            self._schedule_reconciliation()

    def _check_completeness_timeouts(self) -> None:
        """Check for incomplete groups that have exceeded their timeout."""
        for wc in self.app_config.watch:
            rule_set = self.rules_config.rule_sets.get(wc.rules)
            if rule_set is None or rule_set.completeness is None:
                continue
            completeness = rule_set.completeness
            if completeness.timeout_minutes <= 0:
                continue

            cutoff = datetime.now(timezone.utc) - timedelta(
                minutes=completeness.timeout_minutes
            )
            session = self.session_factory()
            try:
                timed_out = get_timed_out_groups(session, wc.name, cutoff)
                for group in timed_out:
                    group_key = group["group_key"]
                    group_id = group["id"]
                    action = completeness.on_timeout

                    if action == "warn":
                        logger.warning(f"Group '{group_key}' in [{wc.name}] timed out")
                    elif action == "skip":
                        components = get_group_components(session, group_id)
                        for comp in components:
                            update_component_status(
                                session, comp["id"], FileStatus.TIMED_OUT
                            )
                        mark_group_complete(session, group_id)
                        logger.info(f"Group '{group_key}' in [{wc.name}] timed out")
                    elif action == "archive_partial":
                        mark_group_complete(session, group_id)
                        components = get_group_components(session, group_id)
                        component_paths = [Path(c["source_path"]) for c in components]
                        # Re-enqueue components for archival
                        for comp_path in component_paths:
                            self.event_queue.put(
                                FileEvent(
                                    watch_name=wc.name,
                                    path=comp_path,
                                )
                            )
                        logger.info(
                            f"Group '{group_key}' in [{wc.name}] timed out — "
                            f"archiving {len(components)} partial component(s)"
                        )

                session.commit()
            except Exception:
                session.rollback()
                logger.exception(f"Completeness timeout check failed for [{wc.name}]")
            finally:
                session.close()

    def _check_pending_retries(self) -> None:
        """Re-enqueue components that are due for retry."""
        retry_delay = self.app_config.service.retry_delay_seconds
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=retry_delay)

        session = self.session_factory()
        try:
            # Components that have been retried before and are past the delay
            pending = get_retry_pending(session, cutoff)
            # Components that haven't been retried yet (just marked RETRY_PENDING)
            pending += get_retry_pending_no_retry_yet(session)

            for comp in pending:
                mark_for_retry(session, comp["id"])
                self.event_queue.put(
                    FileEvent(
                        watch_name=comp["watch_name"],
                        path=Path(comp["source_path"]),
                    )
                )

            if pending:
                session.commit()
                logger.info(f"Re-enqueued {len(pending)} component(s) for retry")
        except Exception:
            session.rollback()
            logger.exception("Retry check failed")
        finally:
            session.close()

    def _check_watch_health(self) -> None:
        """Verify each watch directory is accessible."""
        for wc in self.app_config.watch:
            if not wc.path.is_dir():
                logger.warning(f"Watch directory missing: {wc.path} [{wc.name}]")
            elif not os.access(wc.path, os.R_OK):
                logger.warning(f"Watch directory not readable: {wc.path} [{wc.name}]")

    def _update_heartbeat_and_stats(self) -> None:
        """Update heartbeat in DB and log a stats summary."""
        session = self.session_factory()
        try:
            update_heartbeat(
                session,
                queue_depth=self.event_queue.qsize(),
            )
            counts = get_status_counts(session)
            session.commit()

            parts = [f"{k}={v}" for k, v in sorted(counts.items())]
            logger.info(
                f"Stats: {', '.join(parts)}, queue_depth={self.event_queue.qsize()}"
            )
            self._notifier.notify("WATCHDOG=1")
            self._notifier.notify(
                f"STATUS=queue_depth={self.event_queue.qsize()}, " + ", ".join(parts)
            )
        except Exception:
            session.rollback()
            logger.exception("Heartbeat/stats update failed")
        finally:
            session.close()

    def _get_group_lock(self, group_key: str) -> threading.Lock:
        """Get or create a lock for a group key.

        Uses WeakValueDictionary so locks are automatically cleaned up
        when no thread holds a reference.
        """
        with self._group_locks_lock:
            lock = self._group_locks.get(group_key)
            if lock is None:
                lock = threading.Lock()
                self._group_locks[group_key] = lock
            return lock

    def _process_event(self, event: FileEvent) -> None:
        """Process a single file event through the full pipeline."""
        session = self.session_factory()
        try:
            self._process_event_inner(session, event)
            session.commit()
        except Exception:
            session.rollback()
            logger.exception(f"Error processing {event.path}")
        finally:
            session.close()

    def _process_event_inner(self, session: Session, event: FileEvent) -> None:
        path = event.path
        watch_config = self._watch_by_name.get(event.watch_name)
        if watch_config is None:
            logger.error(f"Unknown watch: {event.watch_name}")
            return

        rule_set = self.rules_config.rule_sets.get(watch_config.rules)
        if rule_set is None:
            logger.error(f"Unknown rule set: {watch_config.rules}")
            return

        # Record component (or find existing via unique constraint)
        source_path = str(path.resolve())

        try:
            try:
                size_bytes = path.stat().st_size
            except OSError:
                size_bytes = None
            component_id = record_component(
                session,
                watch_name=event.watch_name,
                filename=path.name,
                source_path=source_path,
                size_bytes=size_bytes,
            )
        except IntegrityError:
            session.rollback()
            existing = get_component_by_source_path(session, source_path)
            if existing is None:
                logger.error(f"Insert conflict but no existing record: {path.name}")
                return
            component_id = existing["id"]
            # Skip if already in a terminal state
            if existing["status"] in (
                FileStatus.ARCHIVED,
                FileStatus.FAILED,
            ):
                return

        # Stage 1: Integrity
        passed, error = check_integrity(path, rule_set.integrity)
        if not passed:
            update_component_status(
                session,
                component_id,
                FileStatus.INTEGRITY_FAILED,
                error_message=error,
            )
            logger.debug(f"Integrity failed: {path.name}: {error}")
            return

        # Stage 2: Completeness
        completeness = rule_set.completeness
        group_key = resolve_group_key(path, completeness, self.registry)

        if group_key is not None and completeness is not None:
            group_lock = self._get_group_lock(group_key)
            with group_lock:
                group_id = find_or_create_file_group(
                    session,
                    watch_name=event.watch_name,
                    file_type=watch_config.type,
                    group_key=group_key,
                )
                assign_component_to_group(session, component_id, group_id)
                update_component_status(session, component_id, FileStatus.WAITING)

                # Check if group is complete
                group_components = get_group_components(session, group_id)
                component_paths = [Path(c["source_path"]) for c in group_components]

                is_complete = check_completeness(
                    group_key,
                    event.watch_name,
                    completeness.expected_extensions,
                    component_paths,
                )

            if not is_complete:
                logger.debug(
                    f"Group '{group_key}' incomplete "
                    f"({len(component_paths)}/{len(completeness.expected_extensions)})"
                )
                return

            # Group is complete — proceed with all components
            mark_group_complete(session, group_id)
            component_ids = [c["id"] for c in group_components]
        else:
            # No completeness — standalone file
            group_components = []
            component_paths = [path]
            component_ids = [component_id]
            group_id = None

        # Stage 3: Metadata extraction
        metadata: dict = {}
        if rule_set.metadata and rule_set.metadata.module:
            try:
                module = self.registry.get_module(rule_set.metadata.module)
                if hasattr(module, "extract"):
                    metadata = module.extract(component_paths)
                    from carbonation.db.models import validate_extract_metadata

                    validation_errors = validate_extract_metadata(metadata)
                    if validation_errors:
                        for err in validation_errors:
                            logger.error(
                                f"extract() validation [{group_key or path.name}]: {err}"
                            )
                        raise ValueError(
                            f"extract() returned invalid metadata: "
                            f"{'; '.join(validation_errors)}"
                        )
                    if group_id is not None:
                        update_file_metadata(
                            session,
                            group_id,
                            metadata,
                            raw_metadata=metadata,
                        )
            except Exception:
                logger.exception(
                    f"Metadata extraction failed for group '{group_key or path.name}'"
                )

        # Stage 4: Selection
        selected = evaluate_selection(metadata, rule_set.selection, self.registry)
        if not selected:
            for cid in component_ids:
                update_component_status(session, cid, FileStatus.NOT_SELECTED)
            logger.debug(f"Group '{group_key or path.name}' not selected by rules")
            return

        # Stage 5 & 6: Routing + Archive (per component)
        routing_filename = group_key or path.name
        archive_name = resolve_routing(
            metadata,
            routing_filename,
            rule_set.routing,
            watch_config.archive,
            self.registry,
        )
        archive_config = self._archive_by_name.get(archive_name)
        if archive_config is None:
            for cid in component_ids:
                update_component_status(
                    session,
                    cid,
                    FileStatus.FAILED,
                    error_message=f"Archive not found: {archive_name}",
                )
            return

        dest_dir = resolve_destination(
            archive_config.destination,
            metadata,
            archive_config.base_path,
        )

        # Determine which extension is the primary file
        primary_ext = None
        if completeness is not None and completeness.primary_extension:
            primary_ext = completeness.primary_extension

        primary_archive_path: str | None = None

        for cid in component_ids:
            comp = (
                next((c for c in group_components if c["id"] == cid), None)
                if group_key
                else None
            )
            comp_path = Path(comp["source_path"]) if comp else path
            comp_size = comp["size_bytes"] if comp else size_bytes

            try:
                archived = archive_file(
                    comp_path,
                    dest_dir,
                    archive_config.action,
                    archive_config.create_directories,
                    file_mode=archive_config.file_mode,
                    dir_mode=archive_config.dir_mode,
                    expected_size=comp_size,
                )
                update_component_status(
                    session,
                    cid,
                    FileStatus.ARCHIVED,
                    archive_path=str(archived),
                )
                # Track primary file's archive path
                if primary_ext is not None and comp_path.suffix == primary_ext:
                    primary_archive_path = str(archived)
                elif primary_archive_path is None:
                    primary_archive_path = str(archived)
            except Exception as e:
                max_retries = self.app_config.service.max_retries
                comp_record = get_component_by_source_path(
                    session, str(comp_path.resolve())
                )
                current_retries = comp_record["retry_count"] if comp_record else 0
                if current_retries < max_retries:
                    update_component_status(
                        session,
                        cid,
                        FileStatus.RETRY_PENDING,
                        error_message=str(e),
                    )
                    logger.warning(
                        f"Archive failed for {comp_path.name} "
                        f"(attempt {current_retries + 1}/{max_retries}): {e}"
                    )
                else:
                    update_component_status(
                        session,
                        cid,
                        FileStatus.FAILED,
                        error_message=str(e),
                    )
                    logger.error(
                        f"Archive permanently failed for {comp_path.name} "
                        f"after {max_retries} retries: {e}"
                    )

        # Set archive_path on the group row (primary file or first archived)
        if group_id is not None and primary_archive_path is not None:
            update_file_metadata(
                session, group_id, {"archive_path": primary_archive_path}
            )

        logger.info(
            f"Archived group '{group_key or path.name}': "
            f"{len(component_ids)} component(s) -> {archive_name}"
        )
