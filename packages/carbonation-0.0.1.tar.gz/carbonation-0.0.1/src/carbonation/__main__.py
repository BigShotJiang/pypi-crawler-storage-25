"""Allow ``python -m carbonation``."""

from carbonation import main

main()
