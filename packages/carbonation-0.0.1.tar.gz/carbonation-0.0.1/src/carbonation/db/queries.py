"""Core-style database queries for carbonation."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import and_, insert, select, update, func
from sqlalchemy.orm import Session

from carbonation.db.models import FileComponent, FileStatus, ServiceState, get_file_model


def _row_to_dict(row: Any) -> dict[str, Any]:
    """Convert a SQLAlchemy row to a plain dict."""
    return dict(row._mapping)


def record_component(
    session: Session,
    *,
    watch_name: str | None,
    filename: str,
    source_path: str,
    size_bytes: int | None = None,
    status: FileStatus = FileStatus.DETECTED,
) -> int:
    """Insert a new file component record. Returns the new row id."""
    stmt = insert(FileComponent).values(
        watch_name=watch_name,
        filename=filename,
        source_path=source_path,
        size_bytes=size_bytes,
        status=status,
        in_delivery=True,
        in_archive=False,
    )
    result = session.execute(stmt)

    return result.inserted_primary_key[0]


def update_component_status(
    session: Session,
    component_id: int,
    status: FileStatus,
    *,
    error_message: str | None = None,
    archive_path: str | None = None,
) -> None:
    """Update a component's status and optional fields."""
    values: dict[str, Any] = {"status": status}
    if error_message is not None:
        values["error_message"] = error_message
    if archive_path is not None:
        values["archive_path"] = archive_path
    if status == FileStatus.ARCHIVED:
        values["archived_at"] = func.now()
        values["in_archive"] = True
    if status == FileStatus.CLEARED:
        values["cleared_at"] = func.now()
        values["in_delivery"] = False

    stmt = update(FileComponent).where(FileComponent.id == component_id).values(**values)
    session.execute(stmt)



def get_components_in_delivery(
    session: Session, watch_name: str | None = None
) -> list[dict[str, Any]]:
    """Get all components currently in delivery."""
    t = FileComponent.__table__
    stmt = select(
        t.c.id, t.c.source_path, t.c.size_bytes, t.c.status, t.c.detected_at,
    ).where(
        t.c.in_delivery.is_(True)
    )
    if watch_name is not None:
        stmt = stmt.where(t.c.watch_name == watch_name)
    return [_row_to_dict(row) for row in session.execute(stmt)]


def get_status_counts(session: Session) -> dict[str, int]:
    """Get counts of components by status."""
    t = FileComponent.__table__
    stmt = select(t.c.status, func.count()).group_by(t.c.status)
    return {row[0].value if hasattr(row[0], 'value') else row[0]: row[1] for row in session.execute(stmt)}


def get_status_counts_since(
    session: Session, since: datetime,
) -> dict[str, int]:
    """Get counts of components by status, only counting those detected after `since`."""
    t = FileComponent.__table__
    stmt = (
        select(t.c.status, func.count())
        .where(t.c.detected_at >= since)
        .group_by(t.c.status)
    )
    return {row[0].value if hasattr(row[0], 'value') else row[0]: row[1] for row in session.execute(stmt)}


def get_last_detected_at(session: Session) -> datetime | None:
    """Get the timestamp of the most recently detected component."""
    t = FileComponent.__table__
    result = session.execute(select(func.max(t.c.detected_at))).scalar()
    return result


def get_oldest_incomplete_group(session: Session) -> dict[str, Any] | None:
    """Get the oldest incomplete file group."""
    FileModel = get_file_model()
    t = FileModel.__table__
    stmt = (
        select(t.c.group_key, t.c.watch_name, t.c.created_at)
        .where(t.c.complete.is_(False))
        .order_by(t.c.created_at.asc())
        .limit(1)
    )
    row = session.execute(stmt).first()
    if row is None:
        return None
    return _row_to_dict(row)


def get_groups_missing_metadata(session: Session) -> int:
    """Count completed/archived groups where all domain metadata columns are NULL.

    Domain columns are those added by the plugin's FileBase subclass
    beyond the base columns defined in FileBase itself.
    """
    from carbonation.db.models import FILEBASE_COLUMNS

    FileModel = get_file_model()
    t = FileModel.__table__

    domain_columns = [
        t.c[col.name] for col in t.columns if col.name not in FILEBASE_COLUMNS
    ]

    if not domain_columns:
        return 0

    # All domain columns are NULL
    all_null = and_(*[col.is_(None) for col in domain_columns])
    stmt = select(func.count()).where(t.c.complete.is_(True), all_null)
    return session.execute(stmt).scalar_one()


def get_delivery_count(session: Session) -> int:
    """Count components currently in delivery."""
    t = FileComponent.__table__
    stmt = select(func.count()).where(t.c.in_delivery .is_(True))
    return session.execute(stmt).scalar_one()


def get_archive_count(session: Session) -> int:
    """Count components currently in archive."""
    t = FileComponent.__table__
    stmt = select(func.count()).where(t.c.in_archive .is_(True))
    return session.execute(stmt).scalar_one()


def _insert_ignore(session: Session, table: Any, records: list[dict[str, Any]]) -> None:
    """Insert records, ignoring rows that conflict on unique constraints.

    Dialect-aware: uses ON CONFLICT DO NOTHING for SQLite/PostgreSQL,
    INSERT IGNORE for MySQL/MariaDB.
    """
    dialect = session.bind.dialect.name if session.bind else "default"

    if dialect == "sqlite":
        from sqlalchemy.dialects.sqlite import insert as sqlite_insert
        stmt = sqlite_insert(table).values(records).on_conflict_do_nothing()
        session.execute(stmt)
    elif dialect == "postgresql":
        from sqlalchemy.dialects.postgresql import insert as pg_insert
        stmt = pg_insert(table).values(records).on_conflict_do_nothing()
        session.execute(stmt)
    elif dialect in ("mysql", "mariadb"):
        stmt = insert(table).values(records).prefix_with("IGNORE")
        session.execute(stmt)
    else:
        # Fallback: plain insert, caller handles IntegrityError
        session.execute(insert(table), records)


def bulk_insert_components(
    session: Session,
    records: list[dict[str, Any]],
    *,
    ignore_conflicts: bool = False,
) -> None:
    """Bulk insert file component records.

    If ignore_conflicts=True, silently skip rows that conflict on unique constraints.
    """
    if not records:
        return
    if ignore_conflicts:
        _insert_ignore(session, FileComponent, records)
    else:
        session.execute(insert(FileComponent), records)



def bulk_mark_cleared(
    session: Session,
    component_ids: list[int],
    preserve_statuses: set[FileStatus] | None = None,
) -> None:
    """Mark components as cleared. Preserves archived and failed statuses."""
    if not component_ids:
        return
    if preserve_statuses is None:
        preserve_statuses = {FileStatus.ARCHIVED, FileStatus.FAILED}

    # Update in_delivery for all
    stmt = (
        update(FileComponent)
        .where(FileComponent.id.in_(component_ids))
        .values(in_delivery=False, cleared_at=func.now())
    )
    session.execute(stmt)

    # Only update status for non-preserved statuses
    stmt = (
        update(FileComponent)
        .where(
            FileComponent.id.in_(component_ids),
            FileComponent.status.notin_(preserve_statuses),
        )
        .values(status=FileStatus.CLEARED)
    )
    session.execute(stmt)



# --- Group/File queries ---


def find_or_create_file_group(
    session: Session,
    *,
    watch_name: str,
    group_key: str,
    file_type: str | None = None,
) -> int:
    """Find or create a File group row. Returns the file group id."""
    from sqlalchemy.exc import IntegrityError

    FileModel = get_file_model()
    t = FileModel.__table__
    stmt = select(t.c.id).where(
        t.c.watch_name == watch_name,
        t.c.group_key == group_key,
    )
    row = session.execute(stmt).first()
    if row is not None:
        return row[0]

    try:
        stmt = insert(FileModel).values(
            watch_name=watch_name,
            file_type=file_type,
            group_key=group_key,
            complete=False,
        )
        result = session.execute(stmt)
        session.flush()
        return result.inserted_primary_key[0]
    except IntegrityError:
        session.rollback()
        row = session.execute(
            select(t.c.id).where(
                t.c.watch_name == watch_name,
                t.c.group_key == group_key,
            )
        ).first()
        if row is not None:
            return row[0]
        raise


def mark_group_complete(session: Session, group_id: int) -> None:
    """Mark a file group as complete."""
    FileModel = get_file_model()
    stmt = (
        update(FileModel)
        .where(FileModel.__table__.c.id == group_id)
        .values(complete=True, completed_at=func.now())
    )
    session.execute(stmt)



def update_file_metadata(
    session: Session,
    group_id: int,
    metadata: dict,
    *,
    raw_metadata: dict | None = None,
) -> None:
    """Update a File group row with extracted metadata (domain columns).

    If *raw_metadata* is provided, it is stored in the ``metadata`` JSON
    column alongside the typed domain column values.
    """
    FileModel = get_file_model()
    values = dict(metadata)
    if raw_metadata is not None:
        values["metadata"] = raw_metadata
    stmt = (
        update(FileModel)
        .where(FileModel.__table__.c.id == group_id)
        .values(**values)
    )
    session.execute(stmt)



def get_group_components(
    session: Session,
    group_id: int,
) -> list[dict[str, Any]]:
    """Get all components belonging to a group."""
    t = FileComponent.__table__
    stmt = select(
        t.c.id, t.c.filename, t.c.source_path, t.c.status, t.c.size_bytes
    ).where(t.c.group_id == group_id)
    return [_row_to_dict(row) for row in session.execute(stmt)]


def assign_component_to_group(
    session: Session, component_id: int, group_id: int
) -> None:
    """Set a component's group_id."""
    stmt = (
        update(FileComponent)
        .where(FileComponent.id == component_id)
        .values(group_id=group_id)
    )
    session.execute(stmt)



def get_component_by_source_path(
    session: Session, source_path: str
) -> dict[str, Any] | None:
    """Look up a component by its source path."""
    t = FileComponent.__table__
    stmt = select(t).where(t.c.source_path == source_path)
    row = session.execute(stmt).first()
    if row is None:
        return None
    return _row_to_dict(row)


def get_components_by_source_paths(
    session: Session, source_paths: set[str]
) -> dict[str, dict[str, Any]]:
    """Batch look up components by source paths. Returns {source_path: row_dict}."""
    if not source_paths:
        return {}
    t = FileComponent.__table__
    result = {}
    # Process in chunks to avoid SQLite variable limits
    path_list = list(source_paths)
    chunk_size = 500
    for i in range(0, len(path_list), chunk_size):
        chunk = path_list[i : i + chunk_size]
        stmt = select(t).where(t.c.source_path.in_(chunk))
        for row in session.execute(stmt):
            d = _row_to_dict(row)
            result[d["source_path"]] = d
    return result


def get_components_by_status(
    session: Session,
    watch_name: str,
    statuses: set[FileStatus],
    in_delivery: bool = True,
) -> list[dict[str, Any]]:
    """Get components by status and delivery state."""
    t = FileComponent.__table__
    stmt = select(t.c.id, t.c.source_path, t.c.filename, t.c.status, t.c.group_id).where(
        t.c.watch_name == watch_name,
        t.c.in_delivery == in_delivery,
        t.c.status.in_(statuses),
    )
    return [_row_to_dict(row) for row in session.execute(stmt)]


def get_not_selected_in_delivery(session: Session) -> list[dict[str, Any]]:
    """Get all NOT_SELECTED components still in delivery."""
    t = FileComponent.__table__
    stmt = select(
        t.c.id, t.c.source_path, t.c.filename, t.c.watch_name, t.c.group_id,
    ).where(
        t.c.status == FileStatus.NOT_SELECTED,
        t.c.in_delivery.is_(True),
    )
    return [_row_to_dict(row) for row in session.execute(stmt)]


def get_timed_out_groups(
    session: Session,
    watch_name: str,
    timeout_before: datetime,
) -> list[dict[str, Any]]:
    """Get incomplete groups created before the given cutoff time."""
    FileModel = get_file_model()
    t = FileModel.__table__
    stmt = select(
        t.c.id, t.c.group_key, t.c.created_at,
    ).where(
        t.c.watch_name == watch_name,
        t.c.complete.is_(False),
        t.c.created_at < timeout_before,
    )
    return [_row_to_dict(row) for row in session.execute(stmt)]


def query_files(
    session: Session,
    filters: dict[str, Any],
    *,
    columns: list[str] | None = None,
    limit: int | None = None,
    order_by: str | None = None,
    count_only: bool = False,
) -> list[dict[str, Any]] | int:
    """Query the File model with dynamic filters built from CLI options.

    Filter keys use suffixes to determine the operator:
        _after / _before  → >= / <= for DateTime columns
        _min / _max       → >= / <= for numeric columns
        (no suffix)       → exact match, IN for lists, LIKE if value contains %

    Returns a list of row dicts, or an int if count_only=True.
    """
    from sqlalchemy import or_

    FileModel = get_file_model()
    t = FileModel.__table__

    if count_only:
        stmt = select(func.count()).select_from(t)
    else:
        if columns:
            cols = [t.c[name] for name in columns if name in t.c]
        else:
            cols = [t.c[col.name] for col in t.columns]
        stmt = select(*cols)

    # Apply filters
    for key, value in filters.items():
        if value is None:
            continue
        if key.endswith("_after"):
            col_name = key[:-6]
            if col_name in t.c:
                stmt = stmt.where(t.c[col_name] >= value)
        elif key.endswith("_before"):
            col_name = key[:-7]
            if col_name in t.c:
                stmt = stmt.where(t.c[col_name] <= value)
        elif key.endswith("_min"):
            col_name = key[:-4]
            if col_name in t.c:
                stmt = stmt.where(t.c[col_name] >= value)
        elif key.endswith("_max"):
            col_name = key[:-4]
            if col_name in t.c:
                stmt = stmt.where(t.c[col_name] <= value)
        elif key == "_daterange":
            query_start, query_end = value
            if query_start is not None and query_start == query_end:
                # Exact instant
                stmt = stmt.where(t.c.start <= query_start, t.c.stop >= query_start)
            else:
                if query_start is not None:
                    stmt = stmt.where(t.c.stop > query_start)
                if query_end is not None:
                    stmt = stmt.where(t.c.start < query_end)
        elif key == "_age":
            stmt = stmt.where(t.c.stop > value)
        elif isinstance(value, (list, tuple)) and len(value) > 0:
            if key not in t.c:
                continue
            if any("%" in str(v) for v in value):
                stmt = stmt.where(or_(*[t.c[key].like(v) for v in value]))
            else:
                stmt = stmt.where(t.c[key].in_(value))
        elif isinstance(value, bool):
            if key in t.c:
                stmt = stmt.where(t.c[key].is_(value))

    if count_only:
        return session.execute(stmt).scalar_one()

    if order_by:
        col_name = order_by.lstrip("-")
        if col_name in t.c:
            col = t.c[col_name]
            stmt = stmt.order_by(col.desc() if order_by.startswith("-") else col)

    if limit is not None:
        stmt = stmt.limit(limit)
    return [_row_to_dict(row) for row in session.execute(stmt)]


# --- Cursor-based completed file queries ---


def query_completed_files(
    session: Session,
    *,
    cursor_ts: datetime | None = None,
    cursor_id: int | None = None,
    watch_name: str | None = None,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    """Query completed files using a composite (completed_at, id) cursor.

    Returns rows ordered by (completed_at ASC, id ASC).  Pass the last
    row's ``completed_at`` and ``id`` as ``cursor_ts`` and ``cursor_id``
    to paginate without gaps.
    """
    from sqlalchemy import or_

    FileModel = get_file_model()
    t = FileModel.__table__

    stmt = select(t).where(t.c.complete.is_(True))

    if cursor_ts is not None and cursor_id is not None:
        stmt = stmt.where(
            or_(
                t.c.completed_at > cursor_ts,
                and_(t.c.completed_at == cursor_ts, t.c.id > cursor_id),
            )
        )

    if watch_name is not None:
        stmt = stmt.where(t.c.watch_name == watch_name)

    stmt = stmt.order_by(t.c.completed_at.asc(), t.c.id.asc()).limit(limit)
    return [_row_to_dict(row) for row in session.execute(stmt)]


# --- Retry queries ---


def get_retry_pending(
    session: Session,
    retry_delay_cutoff: datetime,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Get components eligible for retry (RETRY_PENDING and past the delay)."""
    t = FileComponent.__table__
    stmt = select(t.c.id, t.c.source_path, t.c.watch_name, t.c.retry_count).where(
        t.c.status == FileStatus.RETRY_PENDING,
        t.c.last_retry_at < retry_delay_cutoff,
    ).limit(limit)
    return [_row_to_dict(row) for row in session.execute(stmt)]


def get_retry_pending_no_retry_yet(
    session: Session,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Get RETRY_PENDING components that haven't been retried yet (last_retry_at is NULL)."""
    t = FileComponent.__table__
    stmt = select(t.c.id, t.c.source_path, t.c.watch_name, t.c.retry_count).where(
        t.c.status == FileStatus.RETRY_PENDING,
        t.c.last_retry_at.is_(None),
    ).limit(limit)
    return [_row_to_dict(row) for row in session.execute(stmt)]


def mark_for_retry(
    session: Session,
    component_id: int,
) -> None:
    """Set a component to RETRY_PENDING and increment retry_count."""
    t = FileComponent.__table__
    stmt = (
        update(FileComponent)
        .where(t.c.id == component_id)
        .values(
            status=FileStatus.RETRY_PENDING,
            retry_count=t.c.retry_count + 1,
            last_retry_at=func.now(),
            error_message=None,
        )
    )
    session.execute(stmt)


def reset_failed_for_retry(
    session: Session,
    *,
    watch_name: str | None = None,
    group_key: str | None = None,
    statuses: set[FileStatus] | None = None,
) -> int:
    """Reset FAILED (or specified statuses) components to RETRY_PENDING for manual retry.

    Returns the number of components reset.
    """
    if statuses is None:
        statuses = {FileStatus.FAILED}

    conditions = [FileComponent.status.in_(statuses)]
    if watch_name is not None:
        conditions.append(FileComponent.watch_name == watch_name)
    if group_key is not None:
        conditions.append(FileComponent.group_id.in_(
            select(get_file_model().__table__.c.id).where(
                get_file_model().__table__.c.group_key == group_key
            )
        ))

    stmt = (
        update(FileComponent)
        .where(*conditions)
        .values(
            status=FileStatus.RETRY_PENDING,
            retry_count=0,
            last_retry_at=None,
            error_message=None,
        )
    )
    result = session.execute(stmt)
    return result.rowcount


# --- Service state queries ---


def update_heartbeat(
    session: Session,
    *,
    queue_depth: int = 0,
    workers_active: int = 0,
    started_at: datetime | None = None,
) -> None:
    """Update or create the service heartbeat row."""
    t = ServiceState.__table__
    row = session.execute(select(t.c.id).where(t.c.id == 1)).first()
    if row is None:
        stmt = insert(ServiceState).values(
            id=1,
            started_at=started_at or func.now(),
            last_heartbeat=func.now(),
            queue_depth=queue_depth,
            workers_active=workers_active,
        )
    else:
        values: dict[str, Any] = {
            "last_heartbeat": func.now(),
            "queue_depth": queue_depth,
            "workers_active": workers_active,
        }
        if started_at is not None:
            values["started_at"] = started_at
        stmt = update(ServiceState).where(ServiceState.id == 1).values(**values)
    session.execute(stmt)


def get_service_state(session: Session) -> dict[str, Any] | None:
    """Get the current service state row."""
    t = ServiceState.__table__
    row = session.execute(select(t).where(t.c.id == 1)).first()
    if row is None:
        return None
    return _row_to_dict(row)
