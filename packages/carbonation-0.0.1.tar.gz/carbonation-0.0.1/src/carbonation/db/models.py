"""SQLAlchemy ORM models for carbonation."""

from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    JSON,
    SmallInteger,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, declared_attr


class Base(DeclarativeBase):
    pass


class FileStatus(enum.Enum):
    DETECTED = "detected"
    INTEGRITY_FAILED = "integrity_failed"
    WAITING = "waiting"
    TIMED_OUT = "timed_out"
    NOT_SELECTED = "not_selected"
    ARCHIVED = "archived"
    RETRY_PENDING = "retry_pending"
    FAILED = "failed"
    CLEARED = "cleared"


class FileComponent(Base):
    __tablename__ = "file_components"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    watch_name: Mapped[str | None] = mapped_column(
        String(255), nullable=True, index=True
    )
    filename: Mapped[str] = mapped_column(String(1024))
    source_path: Mapped[str] = mapped_column(
        String(4096), unique=True, index=True
    )
    archive_path: Mapped[str | None] = mapped_column(
        String(4096), nullable=True
    )
    size_bytes: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    status: Mapped[FileStatus] = mapped_column(
        Enum(FileStatus), default=FileStatus.DETECTED, index=True
    )
    in_delivery: Mapped[bool] = mapped_column(Boolean, default=True)
    in_archive: Mapped[bool] = mapped_column(Boolean, default=False)
    group_id: Mapped[int | None] = mapped_column(
        Integer,
        ForeignKey("files.id"),
        nullable=True,
        index=True,
    )
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    retry_count: Mapped[int] = mapped_column(SmallInteger, default=0)
    last_retry_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )
    detected_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )
    archived_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )
    cleared_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )
    # Trailing underscore avoids collision with SQLAlchemy's Base.metadata attribute
    metadata_: Mapped[dict | None] = mapped_column(
        "metadata", JSON, nullable=True
    )

    __table_args__ = (
        Index("ix_fc_watch_filename", "watch_name", "filename"),
        Index("ix_fc_status_in_delivery", "status", "in_delivery"),
        Index("ix_fc_status_last_retry_at", "status", "last_retry_at"),
    )


class ServiceState(Base):
    """Single-row table tracking service heartbeat and runtime stats."""

    __tablename__ = "service_state"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, default=1)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_heartbeat: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    queue_depth: Mapped[int] = mapped_column(Integer, default=0)
    workers_active: Mapped[int] = mapped_column(Integer, default=0)


FILEBASE_COLUMNS = frozenset({
    "id", "watch_name", "file_type", "group_key",
    "complete", "archive_path", "metadata",
    "created_at", "completed_at", "modified_at", "retention_date",
})


class FileBase(Base):
    """Abstract base for the File model. Plugins subclass this to add domain columns."""

    __abstract__ = True

    @declared_attr.directive
    @classmethod
    def __table_args__(cls) -> tuple:
        return (
            Index(f"ix_{cls.__tablename__}_watch_group", "watch_name", "group_key"),
            UniqueConstraint("watch_name", "group_key", name=f"uq_{cls.__tablename__}_watch_group"),
        )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    watch_name: Mapped[str] = mapped_column(String(255), index=True)
    file_type: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    group_key: Mapped[str] = mapped_column(String(1024))
    complete: Mapped[bool] = mapped_column(Boolean, default=False)
    archive_path: Mapped[str | None] = mapped_column(
        String(4096), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now()
    )
    completed_at: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True
    )
    modified_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now()
    )
    retention_date: Mapped[datetime | None] = mapped_column(
        DateTime, nullable=True, index=True
    )
    # Raw extract() output, stored alongside the typed domain columns
    # defined by the plugin subclass.
    metadata_: Mapped[dict | None] = mapped_column(
        "metadata", JSON, nullable=True
    )


_SA_TYPE_TO_PYTHON: dict[type, tuple[type, ...]] = {
    String: (str,),
    Text: (str,),
    Integer: (int,),
    SmallInteger: (int,),
    BigInteger: (int,),
    Boolean: (bool,),
    DateTime: (datetime,),
    JSON: (dict, list, str, int, float, bool, type(None)),
}


def validate_extract_metadata(metadata: dict) -> list[str]:
    """Validate that an extract() dict matches the plugin File model's domain columns.

    Returns a list of error strings (empty if valid).  Checks:
    - Keys in the dict correspond to domain columns on the model.
    - Values have the correct Python type for the column's SA type.
    - None is accepted for nullable columns.
    """
    FileModel = get_file_model()
    table = FileModel.__table__
    col_by_name = {col.name: col for col in table.columns}
    errors: list[str] = []

    for key, value in metadata.items():
        if key not in col_by_name:
            errors.append(f"Unknown column {key!r}: not defined on {FileModel.__name__}")
            continue

        col = col_by_name[key]

        if key in FILEBASE_COLUMNS:
            errors.append(
                f"Column {key!r} is a base column and cannot be set by extract()"
            )
            continue

        if value is None:
            if not col.nullable:
                errors.append(f"Column {key!r} is not nullable but got None")
            continue

        expected = _SA_TYPE_TO_PYTHON.get(type(col.type))
        if expected is not None and not isinstance(value, expected):
            errors.append(
                f"Column {key!r}: expected {' | '.join(t.__name__ for t in expected)}, "
                f"got {type(value).__name__} ({value!r})"
            )

    return errors


def get_file_model() -> type[FileBase]:
    """Return the plugin-provided File model.

    A plugin must provide a FileBase subclass with __tablename__ = "files".
    This must be called AFTER plugins are loaded.

    Raises PluginError if no File model plugin has been loaded.
    """
    from carbonation.exceptions import PluginError

    for cls in FileBase.__subclasses__():
        if hasattr(cls, "__tablename__") and cls.__tablename__ == "files":
            return cls
    raise PluginError(
        "No File model plugin found. "
        "A plugin must provide a FileBase subclass with __tablename__ = 'files'. "
        "See examples/plugins/test_file_model.py for an example."
    )
