"""Alembic environment for carbonation.

This env is invoked programmatically by ``carbonation.db.engine.run_migrations``
— there is no ``alembic.ini``.  The engine/connection is passed in via the
``connectable`` key in Alembic's config attributes.
"""

from alembic import context

from carbonation.db.models import Base

target_metadata = Base.metadata


def run_migrations_online() -> None:
    connectable = context.config.attributes.get("connectable")
    if connectable is None:
        raise RuntimeError(
            "Alembic env.py requires a 'connectable' attribute — "
            "use carbonation.db.engine.run_migrations() instead of the alembic CLI"
        )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


run_migrations_online()
