"""Database engine and session factory for carbonation."""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine, inspect
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from carbonation.config import DatabaseConfig
from carbonation.db.models import Base

_MIGRATIONS_DIR = str(Path(__file__).parent / "migrations")


def create_engine_from_config(config: DatabaseConfig) -> Engine:
    """Create a SQLAlchemy engine from database config."""
    return create_engine(config.url, echo=config.echo)


def create_session_factory(engine: Engine) -> sessionmaker[Session]:
    """Create a session factory bound to the engine."""
    return sessionmaker(bind=engine)


def run_migrations(engine: Engine) -> None:
    """Run Alembic migrations programmatically (``upgrade head``)."""
    from alembic import command
    from alembic.config import Config

    cfg = Config()
    cfg.set_main_option("script_location", _MIGRATIONS_DIR)
    cfg.attributes["connectable"] = engine
    command.upgrade(cfg, "head")


def _add_plugin_columns(engine: Engine) -> None:
    """Add any plugin-defined columns missing from the ``files`` table.

    ``create_all`` only creates *tables* — it won't ALTER an existing table
    to add new columns.  This function inspects the model vs the live schema
    and issues ``ALTER TABLE ADD COLUMN`` for each missing column.
    """
    from sqlalchemy import text

    from carbonation.db.models import FILEBASE_COLUMNS, get_file_model

    FileModel = get_file_model()
    inspector = inspect(engine)
    existing_columns = {col["name"] for col in inspector.get_columns("files")}

    with engine.begin() as conn:
        for col in FileModel.__table__.columns:
            if col.name in existing_columns:
                continue
            # Only add plugin (domain) columns — base columns are managed by Alembic
            if col.name in FILEBASE_COLUMNS:
                continue
            col_type = col.type.compile(dialect=engine.dialect)
            nullable = "NULL" if col.nullable else "NOT NULL"
            conn.execute(text(
                f'ALTER TABLE files ADD COLUMN "{col.name}" {col_type} {nullable}'
            ))


def init_db(engine: Engine) -> None:
    """Initialise the database: run Alembic migrations, then add plugin columns.

    Alembic manages carbonation's base tables (``file_components``,
    ``service_state``, and the base ``files`` columns).  After migrations,
    any plugin-defined domain columns that don't yet exist on the ``files``
    table are added via ``ALTER TABLE ADD COLUMN``.

    Plugins must be loaded before calling this function.
    """
    from carbonation.db.models import get_file_model

    get_file_model()  # raises if no File model plugin loaded
    run_migrations(engine)
    _add_plugin_columns(engine)


def verify_schema(engine: Engine) -> bool:
    """Check that the expected tables exist in the database."""
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())
    required_tables = {"file_components", "files"}
    return required_tables.issubset(existing_tables)


def check_schema_drift(engine: Engine) -> list[str]:
    """Compare the plugin File model against the live database schema.

    Returns a list of human-readable drift descriptions.  An empty list
    means the model and database are in sync.  Each entry suggests a
    remediation (``carbonation db init`` or manual DDL).
    """
    from carbonation.db.models import FILEBASE_COLUMNS, get_file_model

    FileModel = get_file_model()
    inspector = inspect(engine)
    drift: list[str] = []

    if "files" not in set(inspector.get_table_names()):
        drift.append("Table 'files' does not exist. Run: carbonation db init")
        return drift

    db_columns = {col["name"]: col for col in inspector.get_columns("files")}
    model_columns = {col.name: col for col in FileModel.__table__.columns}

    # Columns in model but not in DB
    for name, col in model_columns.items():
        if name not in db_columns:
            if name in FILEBASE_COLUMNS:
                drift.append(
                    f"Missing base column '{name}'. "
                    f"Run: carbonation db upgrade"
                )
            else:
                drift.append(
                    f"Missing plugin column '{name}' ({col.type}). "
                    f"Run: carbonation db init"
                )

    # Columns in DB but not in model (plugin columns were removed)
    for name in db_columns:
        if name not in model_columns:
            drift.append(
                f"Orphaned column '{name}' exists in database but not in model. "
                f"If intentionally removed, drop manually: "
                f"ALTER TABLE files DROP COLUMN \"{name}\""
            )

    # Type mismatches for plugin columns
    for name, col in model_columns.items():
        if name in FILEBASE_COLUMNS or name not in db_columns:
            continue
        expected_type = col.type.compile(dialect=engine.dialect).upper()
        # Normalize common type aliases for comparison
        actual_type = str(db_columns[name]["type"]).upper()
        if expected_type != actual_type:
            drift.append(
                f"Column '{name}' type mismatch: model={expected_type}, "
                f"database={actual_type}. "
                f"Requires manual migration: ALTER TABLE files "
                f"ALTER COLUMN \"{name}\" TYPE {expected_type}"
            )

    return drift
