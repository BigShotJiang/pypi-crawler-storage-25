"""Public Python API for querying a carbonation database.

Provides :func:`connect` for persistent connections, :func:`query_files`
for one-shot queries, and :func:`session` for direct ORM access.

Example:
    >>> from carbonation import connect
    >>> with connect("config.toml") as db:
    ...     rows = db.query_files({"category": ["alpha"]})
    ...     print(db.describe_filters())
"""

from __future__ import annotations

from collections.abc import Generator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Integer,
    SmallInteger,
    String,
    Text,
)
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from carbonation.config import load_app_config
from carbonation.db.engine import (
    create_engine_from_config,
    create_session_factory,
    verify_schema,
)
from carbonation.db.queries import query_files as _query_files
from carbonation.plugins import PluginRegistry

# Sentinel for "caller did not pass this argument" — distinct from None.
_UNSET: Any = object()

# Maps SQLAlchemy column types to the filter keys they support and a
# human-readable description of each.
_SA_TYPE_FILTERS: dict[type, list[tuple[str, str, str]]] = {
    DateTime: [
        ("{name}_after", "datetime", "Filter where {name} >= value (ISO 8601)"),
        ("{name}_before", "datetime", "Filter where {name} <= value (ISO 8601)"),
    ],
    String: [
        ("{name}", "str | list[str]", "Exact match, or list for IN. Supports % wildcards for LIKE."),
    ],
    Text: [
        ("{name}", "str | list[str]", "Exact match, or list for IN. Supports % wildcards for LIKE."),
    ],
    Integer: [
        ("{name}_min", "int", "Filter where {name} >= value"),
        ("{name}_max", "int", "Filter where {name} <= value"),
    ],
    SmallInteger: [
        ("{name}_min", "int", "Filter where {name} >= value"),
        ("{name}_max", "int", "Filter where {name} <= value"),
    ],
    BigInteger: [
        ("{name}_min", "int", "Filter where {name} >= value"),
        ("{name}_max", "int", "Filter where {name} <= value"),
    ],
    Boolean: [
        ("{name}", "bool", "Filter where {name} is True or False"),
    ],
}


class CarbonationDB:
    """A connection to a carbonation database for querying.

    Created by :func:`connect`.  Use as a context manager or call
    :meth:`close` when done.  The database session is persistent —
    all :meth:`query_files` calls reuse the same session.

    Example:
        >>> with connect("config.toml") as db:
        ...     rows = db.query_files({"category": ["alpha"]})
        ...     count = db.query_files({"complete": True}, count_only=True)
    """

    def __init__(
        self,
        engine: Engine,
        session_factory: sessionmaker[Session],
        query_defaults: dict[str, Any],
    ) -> None:
        self._engine = engine
        self._session = session_factory()
        self._query_defaults = query_defaults

    def query_files(
        self,
        filters: dict[str, Any] | None = None,
        *,
        columns: list[str] | None = _UNSET,
        limit: int | None = _UNSET,
        order_by: str | None = _UNSET,
        count_only: bool = False,
    ) -> list[dict[str, Any]] | int:
        """Query the files table with optional filters.

        Parameters not explicitly passed fall back to plugin
        ``query_defaults()``, then to no constraint.

        Args:
            filters: Dict of filter criteria.  Keys use suffixes to select
                the operator — call :meth:`describe_filters` to see all
                available filter keys for the current plugin.  ``None``
                means no filters.
            columns: Column names to include in results.  ``None`` returns
                all columns.
            limit: Maximum number of rows to return.  ``None`` means no
                limit.
            order_by: Column name to sort by.  Prefix with ``-`` for
                descending (e.g. ``"-start"``).
            count_only: If ``True``, return the row count as an ``int``
                instead of the row data.

        Returns:
            A list of row dicts when ``count_only`` is ``False``, or an
            ``int`` when ``count_only`` is ``True``.

        Raises:
            ValueError: If no filters, no limit, and ``count_only`` is
                ``False`` (prevents accidentally fetching the entire table).
        """
        # Apply plugin defaults for any parameter the caller didn't pass.
        if columns is _UNSET:
            columns = self._query_defaults.get("columns")
        if limit is _UNSET:
            limit = self._query_defaults.get("limit")
        if order_by is _UNSET:
            order_by = self._query_defaults.get("order_by")

        has_filters = filters is not None and len(filters) > 0
        if not has_filters and not count_only and limit is None:
            raise ValueError(
                "Unbounded query: provide at least one filter, a limit, "
                "or count_only=True.  Example: db.query_files(limit=10) or "
                "db.query_files({'watch_name': ['incoming']})"
            )

        return _query_files(
            self._session,
            filters if filters is not None else {},
            columns=columns,
            limit=limit,
            order_by=order_by,
            count_only=count_only,
        )

    def describe_filters(self) -> list[dict[str, str]]:
        """Describe the available filter keys for :meth:`query_files`.

        Inspects the plugin's File model columns and returns a list of
        dicts describing each filter key, its expected Python type, and
        a short description.  Useful for building dynamic UIs or for
        interactive exploration in notebooks.

        Returns:
            A list of dicts, each with keys ``"filter_key"``, ``"type"``,
            and ``"description"``.

        Example:
            >>> with connect("config.toml") as db:
            ...     for f in db.describe_filters():
            ...         print(f"{f['filter_key']:30s} {f['type']:20s} {f['description']}")
        """
        from carbonation.db.models import FILEBASE_COLUMNS, get_file_model

        FileModel = get_file_model()
        result: list[dict[str, str]] = []

        for col in FileModel.__table__.columns:
            col_type = type(col.type)
            templates = _SA_TYPE_FILTERS.get(col_type)
            if templates is None:
                continue
            for key_tmpl, type_str, desc_tmpl in templates:
                result.append({
                    "filter_key": key_tmpl.format(name=col.name),
                    "type": type_str,
                    "description": desc_tmpl.format(name=col.name),
                    "column": col.name,
                    "plugin": col.name not in FILEBASE_COLUMNS,
                })

        # Add special filters if start/stop columns exist
        col_names = {col.name for col in FileModel.__table__.columns}
        col_types = {col.name: type(col.type) for col in FileModel.__table__.columns}
        if (
            "start" in col_names
            and "stop" in col_names
            and col_types["start"] is DateTime
            and col_types["stop"] is DateTime
        ):
            result.append({
                "filter_key": "_daterange",
                "type": "tuple[datetime | None, datetime | None]",
                "description": "Filter files whose start/stop range overlaps the given interval",
                "column": "start/stop",
                "plugin": True,
            })
            result.append({
                "filter_key": "_age",
                "type": "datetime",
                "description": "Filter files with stop > value (recency cutoff)",
                "column": "stop",
                "plugin": True,
            })

        return result

    def get_new_files(
        self,
        cursor: str | None = None,
        watch_name: str | None = None,
        limit: int = 1000,
    ) -> tuple[list[dict[str, Any]], str | None]:
        """Query for files completed since the last cursor position.

        Uses a composite cursor (completed_at, id) for gap-free pagination.
        Call repeatedly until the returned list is empty to consume all
        new files.

        Args:
            cursor: Opaque cursor from a previous call.  ``None`` starts
                from the beginning.
            watch_name: Filter to a specific watch.  ``None`` returns all.
            limit: Maximum rows per call.

        Returns:
            A tuple ``(rows, new_cursor)``.  Pass *new_cursor* to the
            next call.  *new_cursor* is ``None`` only when *cursor* was
            ``None`` and no rows exist.
        """
        from datetime import datetime as dt

        from carbonation.db.queries import query_completed_files

        cursor_ts: dt | None = None
        cursor_id: int | None = None
        if cursor is not None:
            ts_str, id_str = cursor.rsplit(":", 1)
            cursor_ts = dt.fromisoformat(ts_str)
            cursor_id = int(id_str)

        rows = query_completed_files(
            self._session,
            cursor_ts=cursor_ts,
            cursor_id=cursor_id,
            watch_name=watch_name,
            limit=limit,
        )

        if rows:
            last = rows[-1]
            completed_at = last["completed_at"]
            new_cursor = f"{completed_at.isoformat()}:{last['id']}"
        else:
            new_cursor = cursor

        return rows, new_cursor

    def get_service_status(self) -> dict[str, Any] | None:
        """Return the current service state.

        Returns a dict with ``started_at``, ``last_heartbeat``,
        ``queue_depth``, and ``workers_active``, or ``None`` if the
        service has never run.
        """
        from carbonation.db.queries import get_service_state

        return get_service_state(self._session)

    def close(self) -> None:
        """Close the session and dispose of the database engine."""
        self._session.close()
        self._engine.dispose()

    def __enter__(self) -> CarbonationDB:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()


def connect(config_path: str | Path) -> CarbonationDB:
    """Connect to a carbonation database for querying.

    Loads the configuration, creates a database engine, loads plugins,
    and returns a :class:`CarbonationDB` ready for queries.

    If the plugin defines a ``query_defaults()`` function, its values
    (``limit``, ``order_by``, ``columns``) are used as defaults for
    :meth:`CarbonationDB.query_files`.

    Args:
        config_path: Path to the carbonation ``config.toml`` file.

    Returns:
        A :class:`CarbonationDB` instance.  Use as a context manager
        or call :meth:`~CarbonationDB.close` when done.

    Raises:
        FileNotFoundError: If *config_path* does not exist.
        ConfigError: If the configuration is invalid.
        PluginError: If plugin loading fails.
        RuntimeError: If the database schema has not been initialized
            (run ``carbonation db init`` first).

    Example:
        >>> with connect("/opt/carbonation/config.toml") as db:
        ...     rows = db.query_files({"category": ["alpha"]}, limit=50)
    """
    config = load_app_config(Path(config_path))

    engine = create_engine_from_config(config.database)
    if not verify_schema(engine):
        engine.dispose()
        raise RuntimeError(
            "Database not initialized. Run 'carbonation db init' first."
        )

    registry = PluginRegistry()
    if config.plugins.directory:
        registry.load_directory(config.plugins.directory)

    query_defaults = registry.get_query_defaults()
    session_factory = create_session_factory(engine)
    return CarbonationDB(engine, session_factory, query_defaults)


@contextmanager
def session(config_path: str | Path) -> Generator[Session, None, None]:
    """Open an ORM session against a carbonation database.

    Loads the configuration, creates a database engine, loads plugins,
    and yields a SQLAlchemy :class:`~sqlalchemy.orm.Session`.  The
    session and engine are closed on exit.

    Use this when you need direct ORM access to query, modify, and
    commit changes to carbonation models (``FileComponent``,
    ``FileBase`` subclass, ``ServiceState``).

    Args:
        config_path: Path to the carbonation ``config.toml`` file.

    Yields:
        A :class:`~sqlalchemy.orm.Session` bound to the carbonation
        database.

    Example:
        >>> from carbonation import session
        >>> from carbonation.db.models import FileComponent, FileStatus
        >>> with session("config.toml") as s:
        ...     comps = s.query(FileComponent).filter_by(status=FileStatus.ARCHIVED).all()
        ...     for c in comps:
        ...         c.status = FileStatus.CLEARED
        ...     s.commit()
    """
    config = load_app_config(Path(config_path))

    engine = create_engine_from_config(config.database)
    if not verify_schema(engine):
        engine.dispose()
        raise RuntimeError(
            "Database not initialized. Run 'carbonation db init' first."
        )

    registry = PluginRegistry()
    if config.plugins.directory:
        registry.load_directory(config.plugins.directory)

    factory = create_session_factory(engine)
    s = factory()
    try:
        yield s
    finally:
        s.close()
        engine.dispose()


def query_files(
    config_path: str | Path,
    filters: dict[str, Any] | None = None,
    **kwargs: Any,
) -> list[dict[str, Any]] | int:
    """One-shot query: connect, query, and disconnect.

    Convenience function that creates a :class:`CarbonationDB`, runs a
    single query, and cleans up.  For repeated queries, use
    :func:`connect` instead to avoid per-call setup overhead.

    Args:
        config_path: Path to the carbonation ``config.toml`` file.
        filters: Filter criteria (see :meth:`CarbonationDB.query_files`).
        **kwargs: Forwarded to :meth:`CarbonationDB.query_files`
            (``columns``, ``limit``, ``order_by``, ``count_only``).

    Returns:
        A list of row dicts, or an ``int`` if ``count_only=True``.

    Example:
        >>> from carbonation import query_files
        >>> rows = query_files("config.toml", {"category": ["alpha"]}, limit=50)
    """
    with connect(config_path) as db:
        return db.query_files(filters, **kwargs)
