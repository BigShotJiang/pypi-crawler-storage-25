"""Custom exceptions for carbonation."""


class CarbonationError(Exception):
    """Base exception for all carbonation errors."""


class ConfigError(CarbonationError):
    """Error in config.toml or rules.toml validation."""


class PluginError(CarbonationError):
    """Error loading or executing a plugin."""


class DatabaseError(CarbonationError):
    """Database-related error (schema missing, init required, etc.)."""
