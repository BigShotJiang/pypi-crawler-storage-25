"""Delivery and archive reconciliation for carbonation."""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from queue import Queue
from typing import Any

from loguru import logger
from sqlalchemy.orm import Session

from carbonation.config import ArchiveConfig, WatchConfig
from carbonation.db.models import FileStatus
from carbonation.db.queries import (
    bulk_insert_components,
    bulk_mark_cleared,
    get_components_by_source_paths,
    get_components_in_delivery,
    update_component_status,
)
from carbonation.watcher import FileEvent

_DEFAULT_STALE_THRESHOLD = timedelta(days=1)


def walk_directory(path: Path, recursive: bool = False) -> dict[str, tuple[int, float]]:
    """Walk a directory and return {absolute_path_str: (size, mtime)} for all files.

    Uses os.scandir for efficiency.
    """
    result: dict[str, tuple[int, float]] = {}

    if not path.is_dir():
        logger.warning(f"Directory does not exist: {path}")
        return result

    if recursive:
        for dirpath, _, filenames in os.walk(path):
            for fname in filenames:
                fpath = Path(dirpath) / fname
                try:
                    stat = fpath.stat()
                    result[str(fpath.resolve())] = (stat.st_size, stat.st_mtime)
                except OSError:
                    continue
    else:
        try:
            for entry in os.scandir(path):
                if entry.is_file():
                    try:
                        stat = entry.stat()
                        fpath = Path(entry.path).resolve()
                        result[str(fpath)] = (stat.st_size, stat.st_mtime)
                    except OSError:
                        continue
        except OSError as e:
            logger.error(f"Cannot scan directory {path}: {e}")

    return result


def reconcile_delivery(
    session: Session,
    watch_config: WatchConfig,
    event_queue: Queue[FileEvent] | None = None,
    stale_threshold: timedelta | None = None,
) -> dict[str, int]:
    """Reconcile the delivery directory with the database.

    Args:
        stale_threshold: Components in transient states (DETECTED, WAITING)
            younger than this are skipped during re-enqueue to avoid
            double-processing actively-handled files.  Defaults to 1 day.

    Returns stats dict: {new, cleared, requeued}.
    """
    stats = {"new": 0, "cleared": 0, "requeued": 0}

    # Step 1: Walk the delivery directory
    on_disk = walk_directory(watch_config.path, watch_config.recursive)
    disk_paths = set(on_disk.keys())

    # Step 2: Query DB for components in delivery for this watch
    db_components = get_components_in_delivery(session, watch_name=watch_config.name)
    db_by_path: dict[str, dict[str, Any]] = {
        c["source_path"]: c for c in db_components
    }
    db_paths = set(db_by_path.keys())

    # New files on disk not in DB
    new_paths = disk_paths - db_paths
    if new_paths:
        records = []
        for path_str in new_paths:
            size, _ = on_disk[path_str]
            p = Path(path_str)
            records.append({
                "watch_name": watch_config.name,
                "filename": p.name,
                "source_path": path_str,
                "size_bytes": size,
                "status": FileStatus.DETECTED,
                "in_delivery": True,
                "in_archive": False,
            })
        bulk_insert_components(session, records)
        stats["new"] = len(records)
        logger.info(f"Reconcile [{watch_config.name}]: {len(records)} new files detected")

    # Files in DB but no longer on disk — mark cleared
    cleared_paths = db_paths - disk_paths
    if cleared_paths:
        cleared_ids = [db_by_path[p]["id"] for p in cleared_paths]
        bulk_mark_cleared(session, cleared_ids)
        stats["cleared"] = len(cleared_ids)
        logger.info(f"Reconcile [{watch_config.name}]: {len(cleared_ids)} files cleared")

    session.commit()

    # Re-enqueue in-delivery files for re-evaluation.
    #
    # Statuses and their reconciliation behavior:
    #   DETECTED / WAITING — actively being processed; skip unless stuck
    #                        longer than stale_threshold.
    #   INTEGRITY_FAILED   — re-assess; file may have finished writing.
    #   TIMED_OUT          — terminal; manual retry only.
    #   NOT_SELECTED       — terminal here; re-enqueued by rules hot-reload.
    #   RETRY_PENDING      — handled by _check_pending_retries, skip here.
    #   ARCHIVED / FAILED / CLEARED — terminal, skip.
    #
    # Components discovered by *this* reconciliation cycle are always
    # enqueued regardless of status (they are brand new).
    if event_queue is not None:
        now = datetime.now(timezone.utc)
        threshold = stale_threshold if stale_threshold is not None else _DEFAULT_STALE_THRESHOLD
        stale_cutoff = now - threshold

        # Statuses that are never re-enqueued by reconciliation.
        terminal_statuses = {
            FileStatus.ARCHIVED,
            FileStatus.FAILED,
            FileStatus.CLEARED,
            FileStatus.TIMED_OUT,
            FileStatus.NOT_SELECTED,
        }
        # Statuses managed by their own retry path — don't duplicate here.
        retry_managed = {FileStatus.RETRY_PENDING}
        # Transient statuses that indicate active processing.
        transient_statuses = {FileStatus.DETECTED, FileStatus.WAITING}

        # Re-query to get updated state after inserts/clears
        current = get_components_in_delivery(session, watch_name=watch_config.name)
        for comp in current:
            status = comp["status"]

            if status in terminal_statuses or status in retry_managed:
                continue

            source = comp["source_path"]
            is_newly_discovered = source in new_paths

            # Skip recently-touched transient states to avoid
            # double-processing files that workers are actively handling.
            if not is_newly_discovered and status in transient_statuses:
                detected_at = comp.get("detected_at")
                if detected_at is not None:
                    if hasattr(detected_at, "tzinfo") and detected_at.tzinfo is None:
                        detected_at = detected_at.replace(tzinfo=timezone.utc)
                    if detected_at > stale_cutoff:
                        continue

            event_queue.put(FileEvent(
                watch_name=watch_config.name,
                path=Path(comp["source_path"]),
            ))
            stats["requeued"] += 1
        if stats["requeued"]:
            logger.info(
                f"Reconcile [{watch_config.name}]: {stats['requeued']} files re-enqueued"
            )

    return stats


def reconcile_archive(
    session: Session,
    archive_configs: list[ArchiveConfig],
) -> dict[str, int]:
    """Reconcile archive directories with the database.

    Returns stats dict: {found, created, missing}.
    """
    stats = {"found": 0, "created": 0, "missing": 0}

    for archive_config in archive_configs:
        if archive_config.base_path is None:
            logger.warning(f"No base_path configured for archive '{archive_config.name}', skipping reconciliation")
            continue
        dest_base = archive_config.base_path
        if not dest_base.is_dir():
            logger.debug(f"Archive base does not exist: {dest_base}")
            continue

        # Walk the archive tree
        on_disk = walk_directory(dest_base, recursive=True)

        # Batch lookup existing components
        existing_by_path = get_components_by_source_paths(session, set(on_disk.keys()))

        # Separate into found (already in DB) and orphaned (need to create)
        orphan_records = []
        for path_str, (size, _) in on_disk.items():
            existing = existing_by_path.get(path_str)

            if existing is not None:
                # Ensure in_archive flag is correct
                if not existing.get("in_archive"):
                    update_component_status(
                        session, existing["id"], existing["status"],
                        archive_path=path_str,
                    )
                stats["found"] += 1
            else:
                p = Path(path_str)
                orphan_records.append({
                    "watch_name": None,
                    "filename": p.name,
                    "source_path": path_str,
                    "archive_path": path_str,
                    "size_bytes": size,
                    "status": FileStatus.ARCHIVED,
                    "in_delivery": False,
                    "in_archive": True,
                })

        if orphan_records:
            bulk_insert_components(session, orphan_records, ignore_conflicts=True)
            stats["created"] += len(orphan_records)

    session.commit()

    if stats["created"]:
        logger.info(f"Archive reconcile: {stats['created']} orphaned files registered")

    return stats
