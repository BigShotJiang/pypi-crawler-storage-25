"""Watchdog integration with settle timer for carbonation."""

from __future__ import annotations

import fnmatch
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from queue import Full, Queue

from loguru import logger
from watchdog.events import FileCreatedEvent, FileModifiedEvent, FileSystemEventHandler
from watchdog.observers import Observer

from carbonation.config import WatchConfig


@dataclass
class FileEvent:
    """Represents a settled file arrival event."""

    watch_name: str
    path: Path
    detected_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class FileArrivalHandler(FileSystemEventHandler):
    """Watchdog handler that debounces file events with a settle timer."""

    def __init__(self, watch_config: WatchConfig, event_queue: Queue[FileEvent]) -> None:
        super().__init__()
        self.config = watch_config
        self.queue = event_queue
        self._timers: dict[str, threading.Timer] = {}
        self._lock = threading.Lock()

    def on_created(self, event: FileCreatedEvent) -> None:
        if event.is_directory:
            return
        self._handle(event.src_path)

    def on_modified(self, event: FileModifiedEvent) -> None:
        if event.is_directory:
            return
        self._handle(event.src_path)

    def _handle(self, src_path: str) -> None:
        path = Path(src_path)
        if not self._matches_patterns(path):
            return

        key = str(path.resolve())
        with self._lock:
            # Cancel existing timer for this path
            if key in self._timers:
                self._timers[key].cancel()

            # Start a new settle timer
            timer = threading.Timer(
                self.config.settle_seconds,
                self._emit,
                args=(path, key),
            )
            timer.daemon = True
            self._timers[key] = timer
            timer.start()

    def _emit(self, path: Path, key: str) -> None:
        """Called when settle timer fires — enqueue the event."""
        with self._lock:
            self._timers.pop(key, None)

        event = FileEvent(
            watch_name=self.config.name,
            path=path,
        )
        try:
            self.queue.put_nowait(event)
        except Full:
            logger.warning(
                f"Event queue full — dropped event for {path.name} "
                f"(watch: {self.config.name}). It will be picked up on next reconciliation."
            )
            return
        logger.debug(f"File settled: {path.name} (watch: {self.config.name})")

    def _matches_patterns(self, path: Path) -> bool:
        """Check if a file matches the watch patterns and ignore patterns.

        Uses :func:`fnmatch.fnmatch` — case-sensitive on Linux/macOS,
        case-insensitive on Windows.
        """
        name = path.name

        # Check ignore patterns first
        for pattern in self.config.ignore_patterns:
            if fnmatch.fnmatch(name, pattern):
                return False

        # If no inclusion patterns specified, accept all
        if self.config.patterns is None:
            return True

        # Check inclusion patterns
        return any(fnmatch.fnmatch(name, p) for p in self.config.patterns)

    def cancel_all(self) -> None:
        """Cancel all pending settle timers."""
        with self._lock:
            for timer in self._timers.values():
                timer.cancel()
            self._timers.clear()


def create_observers(
    watch_configs: list[WatchConfig],
    event_queue: Queue[FileEvent],
) -> list[tuple[Observer, FileArrivalHandler]]:
    """Create and configure watchdog observers for all watch configs.

    Returns list of (observer, handler) tuples. Observers are NOT started.
    """
    result = []
    for wc in watch_configs:
        handler = FileArrivalHandler(wc, event_queue)
        observer = Observer()
        observer.schedule(handler, str(wc.path), recursive=wc.recursive)
        result.append((observer, handler))
        logger.info(f"Configured watcher: {wc.name} -> {wc.path}")
    return result
