"""Rules evaluation engine for carbonation.

Evaluates integrity, completeness, selection, and routing rules.
"""

from __future__ import annotations

import fnmatch
import os
import re
from pathlib import Path

from loguru import logger

from carbonation.config import (
    CompletenessConfig,
    IntegrityCheck,
    RoutingRule,
    SelectionRule,
)
from carbonation.plugins import PluginRegistry


def check_integrity(file_path: Path, checks: list[IntegrityCheck]) -> tuple[bool, str | None]:
    """Run built-in integrity checks on a file.

    Returns (passed, error_message). error_message is None if passed.
    """
    # Always check readability
    if not file_path.exists():
        return False, f"File does not exist: {file_path}"
    try:
        with open(file_path, "rb") as f:
            f.read(1)
    except (PermissionError, OSError) as e:
        return False, f"File not readable: {e}"

    for check in checks:
        if check.type == "min_size":
            min_bytes = int(check.value) if check.value is not None else 0
            actual = file_path.stat().st_size
            if actual < min_bytes:
                return False, f"File too small: {actual} bytes < {min_bytes} min_size"
        else:
            logger.warning(f"Unknown integrity check type: {check.type!r}")

    return True, None


def resolve_group_key(
    file_path: Path,
    completeness: CompletenessConfig | None,
    registry: PluginRegistry | None = None,
) -> str | None:
    """Resolve the group key for a file based on completeness config.

    Returns None if no completeness config (standalone file).
    """
    if completeness is None:
        return None

    if completeness.group_by == "stem":
        return file_path.stem
    elif completeness.group_by == "plugin":
        if registry is None or completeness.group_function is None:
            logger.error("Plugin grouping requires registry and group_function")
            return None
        return registry.call(completeness.group_function, file_path=file_path)
    else:
        logger.error(f"Unknown group_by: {completeness.group_by!r}")
        return None


def check_completeness(
    group_key: str,
    watch_name: str,
    expected_extensions: list[str],
    component_paths: list[Path],
) -> bool:
    """Check if all expected extensions are present for a group.

    Args:
        group_key: The shared stem/key for the group.
        watch_name: The watch name (for logging).
        expected_extensions: List of expected file extensions (e.g. [".txt", ".json"]).
        component_paths: List of file paths in the group that have passed integrity.

    Returns True if all expected extensions are present.
    """
    present_extensions = {p.suffix for p in component_paths}
    missing = set(expected_extensions) - present_extensions
    if missing:
        logger.debug(
            f"Group '{group_key}' in '{watch_name}' missing extensions: {missing}"
        )
        return False
    return True


def evaluate_selection(
    metadata: dict,
    rules: list[SelectionRule],
    registry: PluginRegistry | None = None,
) -> bool:
    """Evaluate selection rules against metadata. Rules are ORed.

    Returns True if any rule set passes (file should be archived).
    If no rules defined, defaults to True (accept all).
    """
    if not rules:
        return True

    for rule in rules:
        if _evaluate_single_selection(metadata, rule, registry):
            return True

    return False


def _evaluate_single_selection(
    metadata: dict,
    rule: SelectionRule,
    registry: PluginRegistry | None = None,
) -> bool:
    """Evaluate a single selection rule. All conditions within are ANDed."""
    # has_keys: all keys must be present and not None
    if rule.has_keys is not None:
        for key in rule.has_keys:
            if key not in metadata or metadata[key] is None:
                return False

    # field + matches: field value must match at least one compiled regex pattern
    if rule.field is not None and rule.compiled_patterns:
        value = metadata.get(rule.field)
        if value is None:
            return False
        value_str = str(value)
        if not any(p.search(value_str) for p in rule.compiled_patterns):
            return False

    # Plugin-based selection
    if rule.type == "plugin" and rule.function is not None:
        if registry is None:
            logger.error(f"Plugin selection requires registry: {rule.function}")
            return False
        try:
            result = registry.call(rule.function, metadata=metadata, **rule.kwargs)
        except Exception:
            logger.exception(
                f"Plugin selection function '{rule.function}' raised an exception — "
                f"rejecting file (fix the plugin and retry)"
            )
            return False
        if not result:
            return False

    return True


def resolve_routing(
    metadata: dict,
    filename: str,
    routing_rules: list[RoutingRule],
    default_archive: str,
    registry: PluginRegistry | None = None,
) -> str:
    """Resolve which archive to use for a file.

    Evaluates routing rules in order. First match wins.
    Returns the archive name.

    .. note:: Glob matching uses :func:`fnmatch.fnmatch`, which is
       **case-sensitive on Linux/macOS** and **case-insensitive on Windows**.
       For portable routing rules, use consistent casing or regex-based
       plugin routing instead.
    """
    for rule in routing_rules:
        # Glob-based routing
        if rule.match is not None and rule.archive is not None:
            if fnmatch.fnmatch(filename, rule.match):
                return rule.archive

        # Plugin-based routing
        if rule.type == "plugin" and rule.function is not None:
            if registry is None:
                logger.error(f"Plugin routing requires registry: {rule.function}")
                continue
            try:
                result = registry.call(rule.function, metadata=metadata)
            except Exception:
                logger.exception(
                    f"Plugin routing function '{rule.function}' raised an exception — "
                    f"skipping this routing rule"
                )
                continue
            if result is not None:
                return result

    return default_archive
