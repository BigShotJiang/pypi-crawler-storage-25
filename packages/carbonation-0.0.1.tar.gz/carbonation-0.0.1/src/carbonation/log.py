"""Loguru configuration for carbonation."""

from __future__ import annotations

import sys

from loguru import logger

from carbonation.config import LoggingConfig

TEXT_FORMAT = "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level:<8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
FILE_TEXT_FORMAT = "{time:YYYY-MM-DD HH:mm:ss} | {level:<8} | {name}:{function}:{line} - {message}"


def setup_logging(config: LoggingConfig) -> None:
    """Configure loguru from the logging config."""
    logger.remove()

    use_json = config.format == "json"

    # Always log to stderr
    logger.add(
        sys.stderr,
        level=config.level,
        format=TEXT_FORMAT,
        serialize=use_json,
    )

    # Optionally log to file
    if config.file is not None:
        config.file.parent.mkdir(parents=True, exist_ok=True)
        logger.add(
            str(config.file),
            level=config.level,
            rotation=config.rotation,
            retention=config.retention,
            format=FILE_TEXT_FORMAT,
            serialize=use_json,
        )
