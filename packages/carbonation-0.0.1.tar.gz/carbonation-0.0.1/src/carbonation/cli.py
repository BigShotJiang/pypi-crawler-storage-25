"""CLI entry point for carbonation."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import click
from loguru import logger
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from carbonation.config import AppConfig, RulesConfig, load_app_config, load_rules_config
from carbonation.log import setup_logging
from carbonation.plugins import PluginRegistry


@dataclass
class AppContext:
    """Container for objects shared across CLI commands."""

    config: AppConfig
    rules: RulesConfig
    registry: PluginRegistry
    engine: Engine
    session_factory: sessionmaker[Session]


@click.group()
@click.option(
    "--config",
    "-c",
    "config_path",
    default="config.toml",
    type=click.Path(path_type=Path),
    help="Path to config.toml (default: ./config.toml)",
)
@click.pass_context
def cli(ctx: click.Context, config_path: Path) -> None:
    """Carbonation — file delivery monitoring and archival service."""
    ctx.ensure_object(dict)
    ctx.obj["config_path"] = config_path


# ---------------------------------------------------------------------------
# Init / scaffold command
# ---------------------------------------------------------------------------

_CONFIG_TEMPLATE = """\
# Carbonation configuration file
# See https://github.com/jolsten/carbonation for full documentation.

[service]
# How often to poll for new events (used internally by watchdog settle timers)
poll_interval = "5s"

# How often to run delivery reconciliation (catches missed files, clears removed)
reconcile_interval = "1h"

# Maximum number of worker threads for processing events
workers = 4

# Retry policy for transient archive failures
max_retries = 3
retry_delay = "30m"

# How long a file can sit in DETECTED/WAITING before reconciliation
# considers it stuck and re-enqueues it for processing
stale_threshold = "1d"

[logging]
level = "INFO"

# Uncomment to log to a file (in addition to stderr)
# file = "carbonation.log"
# rotation = "10 MB"
# retention = "30 days"

# Set to "json" for structured JSON lines (for log aggregation)
format = "text"

[database]
# Structured database connection. Supported drivers: sqlite, mysql, postgresql
# For SQLite, only 'name' is needed (resolved relative to this config file).
# For MariaDB/PostgreSQL, set host, port, username, password (or use secrets file).
drivername = "sqlite"
name = "carbonation.db"
# host = "localhost"
# port = 3306
# username = "carbonation"
# password = "changeme"  # prefer ~/.config/carbonation/secrets.toml instead
# echo = false  # set true to log all SQL statements

[plugins]
# Directory containing plugin .py files. At minimum, a File model plugin
# is required — see plugins/file_model.py for an example.
directory = "plugins"

[rules]
# Path to the rules file (resolved relative to this config file)
file = "rules.toml"

# --- Watch directories ---
# Each [[watch]] block monitors a directory for incoming files.
# You can define multiple watches for different file sources.

[[watch]]
name = "my-watch"

# Optional file type label — stored on each group for filtering
# type = "signal"

# Directory to monitor for incoming files
# Use an absolute path for production; relative paths resolve from this config file.
path = "delivery"

# Watch subdirectories recursively
recursive = false

# Only process files matching these glob patterns (omit to accept all)
patterns = ["*.txt", "*.json"]

# Ignore files matching these patterns
ignore_patterns = ["*.tmp", ".*"]

# Name of the rule set in rules.toml to apply
rules = "my-rules"

# Name of the archive destination to use
archive = "my-archive"

# Seconds to wait after last file modification before processing
settle_seconds = 2.0

# --- Archive destinations ---
# Each [[archive]] block defines where and how files are archived.

[[archive]]
name = "my-archive"

# Root directory of the archive (used by reconcile archive)
# Use an absolute path for production; relative paths resolve from this config file.
base_path = "archive"

# Destination path template — {placeholders} are replaced with metadata values
# Resolved relative to base_path when set.
destination = "{category}/{start:%Y%m%d}"

# Archive action: copy, move, hardlink, or symlink
action = "copy"

# Create destination directories if they don't exist
create_directories = true

# File permissions (octal) applied after copy/move. Not applied to hardlink/symlink.
file_mode = 0o640
dir_mode = 0o750
"""

_RULES_TEMPLATE = """\
# Carbonation rules file
# Defines integrity checks, completeness grouping, metadata extraction,
# selection filters, and routing for each rule set.
#
# Rule sets are referenced by name in [[watch]] entries in config.toml.

[my-rules]

# --- Integrity checks ---
# Each [[my-rules.integrity]] entry is a check that must pass before
# a file is considered valid. All checks must pass.

[[my-rules.integrity]]
# Minimum file size in bytes — rejects truncated or empty files
type = "min_size"
value = 10

# --- Completeness ---
# Groups files by stem (e.g. sample_001.txt + sample_001.json)
# and waits until all expected extensions arrive.

[my-rules.completeness]
# Grouping strategy: "stem" (default) or "plugin" (custom function)
group_by = "stem"

# Extensions that must all be present for a group to be complete
expected_extensions = [".txt", ".json"]

# Which extension is the "primary" file — its archive path is stored on the group
primary_extension = ".json"

# How long to wait for a complete group before taking action
timeout_minutes = 60

# Action when timeout is reached: "warn" (log only), "skip", or "archive_partial"
on_timeout = "warn"

# --- Metadata extraction ---
# Module name (without .py) of the plugin that provides an extract() function.
# Called with all component paths once a group is complete.

[my-rules.metadata]
module = "file_model"

# --- Selection rules ---
# Determines whether a completed group should be archived.
# Multiple [[selection]] entries are ORed — any passing rule accepts the group.
# If no selection rules are defined, all groups are accepted.

[[my-rules.selection]]
# Require these metadata keys to be present and not None
has_keys = ["category"]

# [[my-rules.selection]]
# # Match a metadata field against regex patterns (any pattern match passes)
# field = "category"
# matches = ["^alpha", "^beta"]

# [[my-rules.selection]]
# # Plugin-based selection — call a function in a loaded plugin
# type = "plugin"
# function = "should_archive"

# --- Routing rules ---
# Determines which archive destination to use. Evaluated in order; first match wins.
# If no routing rules match, the default archive from the watch config is used.

# [[my-rules.routing]]
# # Glob-based routing — match against the group key / filename
# match = "calibration_*"
# archive = "calibration-archive"

# [[my-rules.routing]]
# # Plugin-based routing
# type = "plugin"
# function = "route_file"
"""

_PLUGIN_TEMPLATE = """\
\"\"\"File model plugin for carbonation.

This plugin defines:
  1. A File model (SQLAlchemy) with domain-specific columns
  2. An extract() function that reads metadata from component files

Domain columns MUST be nullable — they are populated after the group row
is created, not at creation time.
\"\"\"

import json
from datetime import datetime
from pathlib import Path

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from carbonation.db.models import FileBase


class File(FileBase):
    __tablename__ = "files"

    # Add your domain-specific columns here.
    # These will be populated by the extract() function below.
    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stop: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)


def query_defaults() -> dict:
    \"\"\"Default query parameters for ``carbonation query files`` and the Python API.

    Allowed keys: limit, order_by, columns.
    Applied when the caller doesn't pass them explicitly.
    \"\"\"
    return {
        # "limit": 1000,
        "order_by": "-start",
        # "columns": ["group_key", "category", "start", "stop", "source"],
    }


def extract(file_paths: list[Path]) -> dict:
    \"\"\"Extract metadata from a group of component files.

    Called once per group with ALL component paths. Returns a dict
    whose keys match the domain column names above.
    \"\"\"
    json_file = next(p for p in file_paths if p.suffix == ".json")
    data = json.loads(json_file.read_text())
    return {
        "start": datetime.fromisoformat(data["start"]),
        "stop": datetime.fromisoformat(data["stop"]),
        "category": data["category"],
        "source": data.get("source"),
    }
"""

_SYSTEMD_TEMPLATE = """\
[Unit]
Description=Carbonation file delivery monitoring and archival service
After=network.target

[Service]
Type=simple
User={user}
Group={user}
WorkingDirectory={workdir}
ExecStart={workdir}/.venv/bin/carbonation -c {workdir}/config.toml run
Restart=on-failure
RestartSec=10

# Logging (stdout/stderr captured by journald)
StandardOutput=journal
StandardError=journal
SyslogIdentifier=carbonation

# Security hardening
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
# Add your delivery and archive paths here:
# ReadWritePaths={workdir} /data/delivery /data/archive
PrivateTmp=true

[Install]
WantedBy=multi-user.target
"""


@cli.command("init")
@click.option("--dir", "target_dir", default=".", type=click.Path(path_type=Path),
              help="Directory to create files in (default: current directory)")
@click.option("--systemd", is_flag=True, help="Also generate a systemd service file")
@click.option("--user", default="carbonation", help="User for systemd service (default: carbonation)")
def init_project(target_dir: Path, systemd: bool, user: str) -> None:
    """Scaffold a new carbonation project with config, rules, and plugin templates."""
    target_dir = target_dir.resolve()
    target_dir.mkdir(parents=True, exist_ok=True)

    files_written = []

    # config.toml
    config_path = target_dir / "config.toml"
    if config_path.exists():
        click.echo(f"  SKIP {config_path} (already exists)")
    else:
        config_path.write_text(_CONFIG_TEMPLATE, encoding="utf-8")
        files_written.append(config_path)

    # rules.toml
    rules_path = target_dir / "rules.toml"
    if rules_path.exists():
        click.echo(f"  SKIP {rules_path} (already exists)")
    else:
        rules_path.write_text(_RULES_TEMPLATE, encoding="utf-8")
        files_written.append(rules_path)

    # plugins/file_model.py
    plugins_dir = target_dir / "plugins"
    plugins_dir.mkdir(exist_ok=True)
    plugin_path = plugins_dir / "file_model.py"
    if plugin_path.exists():
        click.echo(f"  SKIP {plugin_path} (already exists)")
    else:
        plugin_path.write_text(_PLUGIN_TEMPLATE, encoding="utf-8")
        files_written.append(plugin_path)

    # systemd service file
    if systemd:
        service_path = target_dir / "carbonation.service"
        if service_path.exists():
            click.echo(f"  SKIP {service_path} (already exists)")
        else:
            service_path.write_text(
                _SYSTEMD_TEMPLATE.format(user=user, workdir=str(target_dir)),
                encoding="utf-8",
            )
            files_written.append(service_path)

    for f in files_written:
        click.echo(f"  CREATED {f}")

    click.echo(f"\nProject initialized in {target_dir}")
    click.echo("Next steps:")
    click.echo("  1. Edit config.toml — set your watch paths and archive destination")
    click.echo("  2. Edit rules.toml — configure your integrity/selection rules")
    click.echo("  3. Edit plugins/file_model.py — define your File model columns")
    click.echo("  4. Run: carbonation check-config")
    click.echo("  5. Run: carbonation db init")
    click.echo("  6. Run: carbonation run")


@cli.command("check-config")
@click.pass_context
def check_config(ctx: click.Context) -> None:
    """Validate config.toml and rules.toml."""
    config_path: Path = ctx.obj["config_path"]

    try:
        config = load_app_config(config_path)
    except Exception as e:
        raise click.ClickException(f"Invalid config.toml: {e}") from e

    setup_logging(config.logging)

    try:
        rules = load_rules_config(config.rules.file)
    except FileNotFoundError:
        raise click.ClickException(
            f"Rules file not found: {config.rules.file}"
        )
    except Exception as e:
        raise click.ClickException(f"Invalid rules.toml: {e}") from e

    # Validate cross-references
    errors: list[str] = []
    warnings: list[str] = []

    rule_set_names = set(rules.rule_sets.keys())
    archive_names = {a.name for a in config.archive}

    for w in config.watch:
        if w.rules not in rule_set_names:
            errors.append(
                f"Watch '{w.name}' references rules '{w.rules}' "
                f"which does not exist in {config.rules.file}"
            )
        if w.archive not in archive_names:
            errors.append(
                f"Watch '{w.name}' references archive '{w.archive}' "
                f"which does not exist in config"
            )

        # Check that watch patterns cover completeness extensions
        if w.rules in rule_set_names and w.patterns is not None:
            rs = rules.rule_sets[w.rules]
            if rs.completeness and rs.completeness.expected_extensions:
                for ext in rs.completeness.expected_extensions:
                    pattern = f"*{ext}"
                    if pattern not in w.patterns:
                        warnings.append(
                            f"Watch '{w.name}' patterns {w.patterns} may not "
                            f"include completeness extension '{ext}'"
                        )

    # Validate primary_extension is in expected_extensions
    for rs_name, rs in rules.rule_sets.items():
        if (
            rs.completeness
            and rs.completeness.primary_extension
            and rs.completeness.expected_extensions
            and rs.completeness.primary_extension not in rs.completeness.expected_extensions
        ):
            warnings.append(
                f"Rule set '{rs_name}': primary_extension "
                f"'{rs.completeness.primary_extension}' is not in "
                f"expected_extensions {rs.completeness.expected_extensions}"
            )

    # Validate routing references
    for rs_name, rs in rules.rule_sets.items():
        for routing in rs.routing:
            if routing.archive and routing.archive not in archive_names:
                errors.append(
                    f"Rule set '{rs_name}' routing references archive "
                    f"'{routing.archive}' which does not exist in config"
                )

    # Warn if file_mode is set with hardlink/symlink actions
    for a in config.archive:
        if a.action in ("hardlink", "symlink") and a.file_mode != 0o640:
            warnings.append(
                f"Archive '{a.name}': file_mode has no effect with "
                f"action={a.action!r} (permissions come from the source file)"
            )

    # Check plugin directory
    if config.plugins.directory and not config.plugins.directory.is_dir():
        warnings.append(
            f"Plugin directory does not exist: {config.plugins.directory}"
        )

    for w in warnings:
        logger.warning(w)
        click.echo(f"WARNING: {w}", err=True)

    if errors:
        for e in errors:
            logger.error(e)
            click.echo(f"ERROR: {e}", err=True)
        raise click.ClickException(
            f"Config validation failed with {len(errors)} error(s)"
        )

    click.echo("Config is valid.")


@cli.group()
def db() -> None:
    """Database management commands."""


@db.command("init")
@click.pass_context
def db_init(ctx: click.Context) -> None:
    """Initialize the database schema."""
    from carbonation.db.engine import create_engine_from_config, init_db

    config_path: Path = ctx.obj["config_path"]
    config = load_app_config(config_path)
    setup_logging(config.logging)

    if not config.plugins.directory:
        raise click.ClickException(
            "No plugins directory configured. "
            "A File model plugin is required. Set [plugins] directory in config.toml."
        )

    registry = PluginRegistry()
    registry.load_directory(config.plugins.directory)

    engine = create_engine_from_config(config.database)
    init_db(engine)
    logger.info("Database initialized successfully")
    click.echo("Database initialized.")


@db.command("upgrade")
@click.pass_context
def db_upgrade(ctx: click.Context) -> None:
    """Apply pending database migrations (without plugin column sync)."""
    from carbonation.db.engine import create_engine_from_config, run_migrations

    config_path: Path = ctx.obj["config_path"]
    config = load_app_config(config_path)
    setup_logging(config.logging)

    engine = create_engine_from_config(config.database)
    run_migrations(engine)
    click.echo("Database migrations applied.")


@db.command("status")
@click.pass_context
def db_status(ctx: click.Context) -> None:
    """Show database summary statistics."""
    from carbonation.db.queries import (
        get_archive_count,
        get_delivery_count,
        get_groups_missing_metadata,
        get_status_counts,
    )

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)
    session = app.session_factory()
    try:
        click.echo("Component status:")
        counts = get_status_counts(session)
        for status, count in sorted(counts.items()):
            click.echo(f"  {status:<20s} {count:>6d}")

        delivery = get_delivery_count(session)
        archived = get_archive_count(session)
        click.echo(f"\nIn delivery: {delivery}")
        click.echo(f"In archive:  {archived}")

        missing = get_groups_missing_metadata(session)
        if missing:
            click.echo(
                f"\nWARNING: {missing} completed group(s) have no metadata"
            )
        else:
            click.echo(f"\nAll completed groups have metadata.")

        # Check for schema drift between plugin model and database
        from carbonation.db.engine import check_schema_drift
        drift = check_schema_drift(app.engine)
        if drift:
            click.echo(f"\nSchema drift detected ({len(drift)} issue(s)):")
            for issue in drift:
                click.echo(f"  WARNING: {issue}", err=True)
        else:
            click.echo("\nSchema: model and database are in sync.")
    finally:
        session.close()


def _load_service_context(config_path: Path) -> AppContext:
    """Shared setup for run and reconcile commands."""
    from carbonation.db.engine import (
        create_engine_from_config,
        create_session_factory,
        verify_schema,
    )

    config = load_app_config(config_path)
    setup_logging(config.logging)
    rules = load_rules_config(config.rules.file)

    engine = create_engine_from_config(config.database)
    if not verify_schema(engine):
        raise click.ClickException(
            "Database not initialized. Run 'carbonation db init' first."
        )

    registry = PluginRegistry()
    if config.plugins.directory:
        registry.load_directory(config.plugins.directory)

    session_factory = create_session_factory(engine)
    return AppContext(
        config=config,
        rules=rules,
        registry=registry,
        engine=engine,
        session_factory=session_factory,
    )


@cli.command()
@click.option("--dry-run", is_flag=True, help="Load, reconcile, then exit (no watchers)")
@click.option("--once", is_flag=True, help="Reconcile, process all pending events, then exit")
@click.pass_context
def run(ctx: click.Context, dry_run: bool, once: bool) -> None:
    """Start the carbonation file monitoring service."""
    import sys

    from carbonation.service import CarbonationService

    if dry_run and once:
        raise click.UsageError("--dry-run and --once are mutually exclusive")

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    service = CarbonationService(
        app.config, app.rules, app.registry, app.engine, app.session_factory,
    )
    if once:
        sys.exit(service.run_once())
    else:
        service.start(dry_run=dry_run)


@cli.group()
def reconcile() -> None:
    """Reconciliation commands."""


@reconcile.command("delivery")
@click.pass_context
def reconcile_delivery_cmd(ctx: click.Context) -> None:
    """Reconcile delivery directories with the database."""
    from carbonation.reconcile import reconcile_delivery

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    for wc in app.config.watch:
        session = app.session_factory()
        try:
            stats = reconcile_delivery(session, wc)
            click.echo(
                f"[{wc.name}] new={stats['new']} cleared={stats['cleared']}"
            )
        finally:
            session.close()

    click.echo("Delivery reconciliation complete.")


@reconcile.command("archive")
@click.pass_context
def reconcile_archive_cmd(ctx: click.Context) -> None:
    """Reconcile archive directories with the database."""
    from carbonation.reconcile import reconcile_archive

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    session = app.session_factory()
    try:
        stats = reconcile_archive(session, app.config.archive)
        click.echo(
            f"found={stats['found']} created={stats['created']} missing={stats['missing']}"
        )
    finally:
        session.close()

    click.echo("Archive reconciliation complete.")


# ---------------------------------------------------------------------------
# Status and retry commands
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show service and database status."""
    import os as _os
    from datetime import datetime as dt, timedelta, timezone as tz

    from rich.console import Console
    from rich.table import Table as RichTable

    from carbonation.db.queries import (
        get_archive_count,
        get_delivery_count,
        get_groups_missing_metadata,
        get_last_detected_at,
        get_oldest_incomplete_group,
        get_service_state,
        get_status_counts,
        get_status_counts_since,
    )

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)
    session = app.session_factory()
    console = Console()

    try:
        now = dt.now(tz.utc)

        # --- Service heartbeat ---
        state = get_service_state(session)
        if state is not None and state.get("last_heartbeat"):
            hb = state["last_heartbeat"]
            if hb.tzinfo is None:
                hb = hb.replace(tzinfo=tz.utc)
            age = now - hb
            age_str = _format_duration(age)
            if age.total_seconds() > 300:
                age_str += " (stale)"
            click.echo(f"Service heartbeat:  {age_str}")
            click.echo(f"  started:          {state['started_at']}")
            click.echo(f"  queue depth:      {state['queue_depth']}")
        else:
            click.echo("Service heartbeat:  no data (service has not run)")

        # --- Last activity ---
        last_detected = get_last_detected_at(session)
        if last_detected is not None:
            click.echo(f"  last new file:    {last_detected}")

        click.echo()

        # --- Status table by time bucket ---
        buckets = [
            ("1h", timedelta(hours=1)),
            ("4h", timedelta(hours=4)),
            ("1d", timedelta(days=1)),
            ("7d", timedelta(days=7)),
            ("30d", timedelta(days=30)),
        ]

        # Collect all statuses that appear in any bucket
        all_statuses: set[str] = set()
        bucket_data: list[dict[str, int]] = []
        for label, delta in buckets:
            counts = get_status_counts_since(session, now - delta)
            all_statuses.update(counts.keys())
            bucket_data.append(counts)

        # Also get all-time totals
        total_counts = get_status_counts(session)
        all_statuses.update(total_counts.keys())

        if all_statuses:
            table = RichTable(title="Component Status by Time Window")
            table.add_column("Status", style="bold")
            for label, _ in buckets:
                table.add_column(label, justify="right")
            table.add_column("Total", justify="right", style="bold")

            for s in sorted(all_statuses):
                row = [s]
                for counts in bucket_data:
                    v = counts.get(s, 0)
                    row.append(str(v) if v > 0 else "")
                row.append(str(total_counts.get(s, 0)))
                table.add_row(*row)

            console.print(table)
        else:
            click.echo("No components in database.")

        # --- Totals ---
        delivery = get_delivery_count(session)
        archived = get_archive_count(session)
        click.echo(f"\nIn delivery: {delivery}")
        click.echo(f"In archive:  {archived}")

        # --- Retry queue ---
        retry_count = total_counts.get("retry_pending", 0)
        if retry_count:
            click.echo(f"Retry queue: {retry_count}")

        # --- Oldest incomplete group ---
        oldest = get_oldest_incomplete_group(session)
        if oldest is not None:
            created = oldest["created_at"]
            if created is not None:
                if created.tzinfo is None:
                    created = created.replace(tzinfo=tz.utc)
                age = _format_duration(now - created)
                click.echo(
                    f"\nOldest incomplete group: {oldest['group_key']} "
                    f"[{oldest['watch_name']}] — {age}"
                )

        # --- Warnings ---
        missing = get_groups_missing_metadata(session)
        if missing:
            click.echo(f"\nWARNING: {missing} completed group(s) have no metadata")

        # --- Watch directory health ---
        click.echo("\nWatch directories:")
        for wc in app.config.watch:
            if not wc.path.is_dir():
                click.echo(f"  {wc.name}: MISSING ({wc.path})")
            elif not _os.access(wc.path, _os.R_OK):
                click.echo(f"  {wc.name}: NOT READABLE ({wc.path})")
            else:
                click.echo(f"  {wc.name}: OK ({wc.path})")
    finally:
        session.close()


def _format_duration(td: Any) -> str:
    """Format a timedelta as a human-readable string."""
    total = int(td.total_seconds())
    if total < 60:
        return f"{total}s ago"
    if total < 3600:
        return f"{total // 60}m ago"
    if total < 86400:
        return f"{total // 3600}h {(total % 3600) // 60}m ago"
    return f"{total // 86400}d {(total % 86400) // 3600}h ago"


@cli.command()
@click.option("--watch-name", default=None, help="Retry only this watch")
@click.option("--group-key", default=None, help="Retry only this group")
@click.option("--status", "retry_status", default=None,
              type=click.Choice(["failed", "integrity_failed", "timed_out", "not_selected"]),
              help="Retry components with this status (default: failed)")
@click.pass_context
def retry(ctx: click.Context, watch_name: str | None, group_key: str | None, retry_status: str | None) -> None:
    """Re-enqueue failed components for retry."""
    from carbonation.db.models import FileStatus
    from carbonation.db.queries import reset_failed_for_retry

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)
    session = app.session_factory()

    statuses = None
    if retry_status == "integrity_failed":
        statuses = {FileStatus.INTEGRITY_FAILED}
    elif retry_status == "timed_out":
        statuses = {FileStatus.TIMED_OUT}
    elif retry_status == "not_selected":
        statuses = {FileStatus.NOT_SELECTED}
    elif retry_status == "failed" or retry_status is None:
        statuses = {FileStatus.FAILED}

    try:
        count = reset_failed_for_retry(
            session,
            watch_name=watch_name,
            group_key=group_key,
            statuses=statuses,
        )
        session.commit()
        click.echo(f"Re-enqueued {count} component(s) for retry.")
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Check-rules dry-run command
# ---------------------------------------------------------------------------


@cli.command("check-rules")
@click.argument("rules_path", type=click.Path(exists=True, path_type=Path))
@click.pass_context
def check_rules_cmd(ctx: click.Context, rules_path: Path) -> None:
    """Dry-run a candidate rules file against existing DB groups.

    Shows which groups would be accepted, rejected, or routed differently
    compared to the current rules.
    """
    from carbonation.config import load_rules_config
    from carbonation.db.models import get_file_model
    from carbonation.db.queries import query_files
    from carbonation.rules import evaluate_selection, resolve_routing

    config_path: Path = ctx.obj["config_path"]
    app = _load_service_context(config_path)

    try:
        candidate = load_rules_config(rules_path)
    except Exception as e:
        raise click.ClickException(f"Invalid rules file: {e}") from e

    session = app.session_factory()
    try:
        # Get all completed file groups with their metadata
        FileModel = get_file_model()
        from sqlalchemy import select as sa_select
        t = FileModel.__table__
        rows = [
            dict(row._mapping)
            for row in session.execute(sa_select(t).where(t.c.complete.is_(True)))
        ]

        if not rows:
            click.echo("No completed groups in database to evaluate.")
            return

        changes = {"newly_accepted": [], "newly_rejected": [], "rerouted": []}

        watch_by_name = {w.name: w for w in app.config.watch}

        for row in rows:
            wc_name = row["watch_name"]
            wc = watch_by_name.get(wc_name)
            if wc is None:
                continue

            current_rs = app.rules.rule_sets.get(wc.rules)
            candidate_rs = candidate.rule_sets.get(wc.rules)
            if current_rs is None or candidate_rs is None:
                continue

            # Build metadata dict from domain columns
            from carbonation.db.models import FILEBASE_COLUMNS
            metadata = {k: v for k, v in row.items() if k not in FILEBASE_COLUMNS and v is not None}

            current_selected = evaluate_selection(metadata, current_rs.selection, app.registry)
            candidate_selected = evaluate_selection(metadata, candidate_rs.selection, app.registry)

            gk = row["group_key"]
            if current_selected and not candidate_selected:
                changes["newly_rejected"].append(gk)
            elif not current_selected and candidate_selected:
                changes["newly_accepted"].append(gk)

            if current_selected and candidate_selected:
                current_route = resolve_routing(metadata, gk, current_rs.routing, wc.archive, app.registry)
                candidate_route = resolve_routing(metadata, gk, candidate_rs.routing, wc.archive, app.registry)
                if current_route != candidate_route:
                    changes["rerouted"].append((gk, current_route, candidate_route))

        click.echo(f"Evaluated {len(rows)} completed group(s):")
        click.echo(f"  Newly accepted:  {len(changes['newly_accepted'])}")
        click.echo(f"  Newly rejected:  {len(changes['newly_rejected'])}")
        click.echo(f"  Rerouted:        {len(changes['rerouted'])}")

        if changes["newly_accepted"]:
            click.echo(f"\nNewly accepted: {', '.join(changes['newly_accepted'][:20])}")
        if changes["newly_rejected"]:
            click.echo(f"\nNewly rejected: {', '.join(changes['newly_rejected'][:20])}")
        if changes["rerouted"]:
            for gk, old, new in changes["rerouted"][:20]:
                click.echo(f"\n  {gk}: {old} -> {new}")
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Query commands
# ---------------------------------------------------------------------------


def _column_to_options(col: Any) -> list[click.Option]:
    """Generate Click options for a single SQLAlchemy column."""
    from sqlalchemy import DateTime as SADateTime, String as SAString
    from sqlalchemy import Integer, SmallInteger, BigInteger, Boolean

    name = col.name
    cli_name = name.replace("_", "-")
    col_type = type(col.type)
    opts: list[click.Option] = []

    if col_type is SADateTime:
        opts.append(click.Option(
            [f"--{cli_name}-after"],
            type=click.STRING,
            default=None,
            help=f"Filter {name} >= value (ISO 8601)",
        ))
        opts.append(click.Option(
            [f"--{cli_name}-before"],
            type=click.STRING,
            default=None,
            help=f"Filter {name} <= value (ISO 8601)",
        ))
    elif col_type is SAString:
        opts.append(click.Option(
            [f"--{cli_name}"],
            type=click.STRING,
            multiple=True,
            help=f"Filter by {name} (repeatable, supports % wildcards)",
        ))
    elif col_type in (Integer, SmallInteger, BigInteger):
        opts.append(click.Option(
            [f"--{cli_name}-min"],
            type=click.INT,
            default=None,
            help=f"Filter {name} >= value",
        ))
        opts.append(click.Option(
            [f"--{cli_name}-max"],
            type=click.INT,
            default=None,
            help=f"Filter {name} <= value",
        ))
    elif col_type is Boolean:
        opts.append(click.Option(
            [f"--{cli_name}/--no-{cli_name}"],
            default=None,
            help=f"Filter by {name}",
        ))

    return opts


class QueryFilesCommand(click.Command):
    """Click command that discovers filter options from the plugin File model at invoke time."""

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        from sqlalchemy import DateTime as SADateTime

        from carbonation.db.models import FILEBASE_COLUMNS, get_file_model  # noqa: F811

        # Load AppContext before parsing so we can discover columns
        config_path = ctx.parent.parent.params.get("config_path", Path("config.toml"))
        app = _load_service_context(config_path)
        ctx.ensure_object(dict)
        ctx.obj["app"] = app

        # Add dynamic options for domain columns.  The command object is
        # reused across invocations, so track which param names have already
        # been added to avoid duplicates.
        existing_names = {p.name for p in self.params}
        FileModel = get_file_model()
        table = FileModel.__table__
        has_start_stop = False
        for col in table.columns:
            if col.name in FILEBASE_COLUMNS:
                continue
            for opt in _column_to_options(col):
                if opt.name not in existing_names:
                    self.params.append(opt)
                    existing_names.add(opt.name)

        # Detect start/stop pair for --daterange
        col_names = {col.name for col in table.columns}
        col_types = {col.name: type(col.type) for col in table.columns}
        if (
            "start" in col_names
            and "stop" in col_names
            and col_types["start"] is SADateTime
            and col_types["stop"] is SADateTime
        ):
            has_start_stop = True
            if "daterange" not in existing_names:
                self.params.append(click.Option(
                    ["--daterange"],
                    type=click.STRING,
                    default=None,
                    help="Filter by start/stop overlap (TIME or START/END, ISO 8601)",
                ))
            if "age" not in existing_names:
                self.params.append(click.Option(
                    ["--age"],
                    type=click.STRING,
                    default=None,
                    help="Max age — files with stop > now - DURATION (e.g. 7d, 24h)",
                ))

        ctx.obj["has_start_stop"] = has_start_stop
        return super().parse_args(ctx, args)


def _build_filters(ctx: click.Context, params: dict[str, Any]) -> dict[str, Any]:
    """Convert parsed CLI params into the filter dict expected by query_files()."""
    from datetime import datetime as dt, timedelta, timezone

    from carbonation.config import parse_daterange, parse_duration
    from carbonation.db.models import FILEBASE_COLUMNS, get_file_model

    filters: dict[str, Any] = {}

    FileModel = get_file_model()
    table = FileModel.__table__
    col_names = {col.name for col in table.columns}

    for key, value in params.items():
        if key in ("format", "limit", "count", "columns", "order_by"):
            continue
        if value is None or value == () or value == []:
            continue

        # Convert CLI param name back to filter key
        filter_key = key.replace("-", "_")

        if filter_key == "daterange":
            filters["_daterange"] = parse_daterange(value)
        elif filter_key == "age":
            seconds = parse_duration(value)
            filters["_age"] = dt.now(timezone.utc) - timedelta(seconds=seconds)
        elif filter_key.endswith("_after") or filter_key.endswith("_before"):
            filters[filter_key] = dt.fromisoformat(value)
        else:
            filters[filter_key] = value

    return filters


def _format_output(
    rows: list[dict[str, Any]],
    fmt: str,
    columns: list[str] | None = None,
) -> None:
    """Format and print query results."""
    import csv
    import io
    import json as json_mod

    if not rows:
        click.echo("No results.")
        return

    if columns:
        rows = [{k: v for k, v in row.items() if k in columns} for row in rows]

    if fmt == "json":
        def _serialize(obj: Any) -> str:
            if hasattr(obj, "isoformat"):
                return obj.isoformat()
            return str(obj)
        click.echo(json_mod.dumps(rows, indent=2, default=_serialize))

    elif fmt == "csv":
        out = io.StringIO()
        keys = list(rows[0].keys())
        writer = csv.DictWriter(out, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
        click.echo(out.getvalue().rstrip())

    else:  # table (default)
        from rich.console import Console
        from rich.table import Table as RichTable

        console = Console()
        table = RichTable(show_lines=False)
        keys = list(rows[0].keys())
        for k in keys:
            table.add_column(k)
        for row in rows:
            table.add_row(*[str(v) if v is not None else "" for v in row.values()])
        console.print(table)


@cli.group()
def query() -> None:
    """Query the database."""


@query.command("files", cls=QueryFilesCommand)
@click.option("--watch-name", multiple=True, help="Filter by watch name (repeatable)")
@click.option("--type", "file_type", multiple=True, help="Filter by file type (repeatable)")
@click.option("--group-key", multiple=True, help="Filter by group key (repeatable)")
@click.option("--complete/--no-complete", default=None, help="Filter by completion status")
@click.option("--created-after", type=click.STRING, default=None, help="Groups created after (ISO 8601)")
@click.option("--created-before", type=click.STRING, default=None, help="Groups created before (ISO 8601)")
@click.option("--format", "fmt", type=click.Choice(["table", "csv", "json"]), default="table", help="Output format")
@click.option("--limit", type=click.INT, default=None, help="Max rows to return")
@click.option("--count", is_flag=True, help="Print count only")
@click.option("--columns", type=click.STRING, default=None, help="Comma-separated column names to display")
@click.option("--order-by", type=click.STRING, default=None, help="Column to sort by (prefix with - for descending)")
@click.pass_context
def query_files_cmd(ctx: click.Context, **params: Any) -> None:
    """Query the files table with dynamic plugin-based filters."""
    from carbonation.db.queries import query_files

    app: AppContext = ctx.obj["app"]
    session = app.session_factory()

    try:
        filters = _build_filters(ctx, params)
        fmt = params.get("fmt", "table")
        count = params.get("count", False)

        # Apply plugin query_defaults for params the user didn't pass
        qd = app.registry.get_query_defaults()
        limit = params.get("limit") if params.get("limit") is not None else qd.get("limit")
        order_by = params.get("order_by") if params.get("order_by") is not None else qd.get("order_by")
        columns_str = params.get("columns")
        if columns_str:
            display_columns = columns_str.split(",")
        elif "columns" in qd and qd["columns"] is not None:
            display_columns = qd["columns"]
        else:
            display_columns = None

        if count:
            n = query_files(session, filters, count_only=True)
            click.echo(n)
        else:
            rows = query_files(
                session, filters,
                columns=display_columns,
                limit=limit,
                order_by=order_by,
            )
            assert isinstance(rows, list)
            _format_output(rows, fmt, columns=display_columns)
    finally:
        session.close()
