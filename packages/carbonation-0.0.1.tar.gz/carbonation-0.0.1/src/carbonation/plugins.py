"""Plugin loading and registry for carbonation."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any, Callable

from loguru import logger

from carbonation.db.models import FileBase
from carbonation.exceptions import PluginError


class PluginRegistry:
    """Loads .py files from a directory and indexes their callable functions."""

    def __init__(self) -> None:
        self._functions: dict[str, Callable[..., Any]] = {}
        self._modules: dict[str, Any] = {}
        self._load_errors: list[Path] = []

    def load_directory(self, directory: Path) -> None:
        """Load all .py files from the plugin directory."""
        if not directory.is_dir():
            logger.warning(f"Plugin directory does not exist: {directory}")
            return
        for py_file in sorted(directory.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            self._load_module(py_file)

    def _load_module(self, path: Path) -> None:
        """Load a single .py plugin file."""
        module_name = f"carbonation_plugin_{path.stem}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, path)
            if spec is None or spec.loader is None:
                logger.error(f"Cannot load plugin: {path}")
                return
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
        except Exception:
            logger.exception(f"Failed to load plugin: {path}")
            self._load_errors.append(path)
            return

        self._modules[path.stem] = module

        # Index all public callables
        count = 0
        for name in dir(module):
            if name.startswith("_"):
                continue
            obj = getattr(module, name)
            if callable(obj) and not isinstance(obj, type):
                if name in self._functions:
                    raise PluginError(
                        f"Plugin function '{name}' redefined by {path.name}"
                    )
                self._functions[name] = obj
                count += 1

        logger.info(f"Loaded plugin: {path.name} ({count} functions)")

    def get_module(self, module_name: str) -> Any:
        """Get a loaded plugin module by name."""
        if module_name not in self._modules:
            raise PluginError(f"Plugin module not found: {module_name}")
        return self._modules[module_name]

    def call(self, function_name: str, **kwargs: Any) -> Any:
        """Call a registered plugin function by name."""
        fn = self._functions.get(function_name)
        if fn is None:
            raise PluginError(f"Plugin function not found: {function_name}")
        return fn(**kwargs)

    def has_function(self, function_name: str) -> bool:
        """Check if a function is registered."""
        return function_name in self._functions

    def get_query_defaults(self) -> dict[str, Any]:
        """Return query defaults from the plugin, if defined.

        The plugin may define a ``query_defaults()`` function that returns
        a dict with keys ``limit``, ``order_by``, and/or ``columns``.
        Returns an empty dict if no plugin defines it.
        """
        fn = self._functions.get("query_defaults")
        if fn is None:
            return {}
        defaults = fn()
        allowed = {"limit", "order_by", "columns"}
        unknown = set(defaults) - allowed
        if unknown:
            raise PluginError(
                f"query_defaults() returned unknown keys: {unknown}. "
                f"Allowed keys: {allowed}"
            )
        return defaults

    def get_file_model(self) -> type | None:
        """Find and return a FileBase subclass from loaded plugins, if any.

        Raises PluginError if no model found but plugins failed to load,
        since the model may be in a broken plugin.
        """
        for module in self._modules.values():
            for name in dir(module):
                obj = getattr(module, name)
                if (
                    isinstance(obj, type)
                    and issubclass(obj, FileBase)
                    and obj is not FileBase
                    and hasattr(obj, "__tablename__")
                    and obj.__tablename__ == "files"
                ):
                    return obj
        if self._load_errors:
            raise PluginError(
                f"No File model found, and {len(self._load_errors)} plugin(s) failed to load: "
                f"{', '.join(str(p) for p in self._load_errors)}. "
                f"Fix the plugin errors and try again."
            )
        return None
