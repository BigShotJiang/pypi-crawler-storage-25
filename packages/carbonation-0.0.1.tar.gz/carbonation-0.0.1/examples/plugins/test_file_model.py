"""Example File model plugin for testing carbonation."""

import json
from datetime import datetime
from pathlib import Path

from sqlalchemy import DateTime, String
from sqlalchemy.orm import Mapped, mapped_column

from carbonation.db.models import FileBase


class File(FileBase):
    __tablename__ = "files"

    start: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stop: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    category: Mapped[str | None] = mapped_column(String(255), nullable=True, index=True)
    source: Mapped[str | None] = mapped_column(String(255), nullable=True)


def query_defaults() -> dict:
    """Default query parameters for ``carbonation query files`` and the Python API.

    Allowed keys: limit, order_by, columns.
    These are applied when the caller doesn't pass them explicitly.
    """
    return {
        # "limit": 1000,
        "order_by": "-start",
        # "columns": ["group_key", "category", "start", "stop", "source"],
    }


def extract(file_paths: list[Path]) -> dict:
    """Extract metadata from a group of component files.

    Receives ALL component paths at once. Returns a single dict
    for the File row's domain columns.
    """
    json_file = next(p for p in file_paths if p.suffix == ".json")
    data = json.loads(json_file.read_text())
    return {
        "start": datetime.fromisoformat(data["start"]),
        "stop": datetime.fromisoformat(data["stop"]),
        "category": data["category"],
        "source": data.get("source"),
    }
