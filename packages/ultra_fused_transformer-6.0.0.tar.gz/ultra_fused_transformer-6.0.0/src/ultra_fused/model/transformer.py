"""
Ultra-Fused Transformer v6.1 — Full Model
Supports both SDLA and MLA baselines for comparison.
"""
import torch
import torch.nn as nn
from ultra_fused.config import UFTConfig
from ultra_fused.layers.parallel_block import ParallelBlock
from ultra_fused.layers.mla_baseline import MLABaselineAttention


class UltraFusedTransformer(nn.Module):
    def __init__(self, config: UFTConfig, use_mla_baseline=False):
        super().__init__()
        self.config = config
        self.use_mla_baseline = use_mla_baseline
        self.embed = nn.Embedding(config.vocab_size, config.d_model)

        if use_mla_baseline:
            # MLA baseline blocks (no parallel block, standard transformer block)
            self.blocks = nn.ModuleList([
                nn.ModuleDict({
                    'ln1': nn.RMSNorm(config.d_model),
                    'attn': MLABaselineAttention(
                        d_model=config.d_model,
                        n_heads=config.n_heads,
                        max_seq_len=config.max_seq_len,
                        kv_lora_rank=config.mla_latent_dim,
                        q_lora_rank=config.mla_latent_dim,
                        use_yarn=config.use_yarn,
                        yarn_scale=config.yarn_scale,
                        dropout=config.dropout,
                    ),
                    'ln2': nn.RMSNorm(config.d_model),
                    'ffn': nn.Sequential(
                        nn.Linear(config.d_model, 4 * config.d_model),
                        nn.GELU(),
                        nn.Linear(4 * config.d_model, config.d_model),
                        nn.Dropout(config.dropout) if config.dropout > 0 else nn.Identity(),
                    )
                })
                for _ in range(config.n_layers)
            ])
        else:
            # SDLA Parallel Blocks
            self.blocks = nn.ModuleList([
                ParallelBlock(
                    d_model=config.d_model,
                    n_heads=config.n_heads,
                    config=config,
                    dropout=config.dropout,
                )
                for _ in range(config.n_layers)
            ])

        self.ln_f = nn.RMSNorm(config.d_model)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)
        self.lm_head.weight = self.embed.weight  # Tied

        if not use_mla_baseline:
            self.register_buffer("_init_state",
                torch.zeros(1, config.n_heads, config.sdla_state_dim),
                persistent=False)

    def forward(self, input_ids, targets=None, states=None):
        x = self.embed(input_ids)
        B = x.size(0)

        if self.use_mla_baseline:
            for block in self.blocks:
                # Standard transformer block with MLA
                attn_out, _ = block['attn'](block['ln1'](x))
                x = x + attn_out
                x = x + block['ffn'](block['ln2'](x))
            new_states = None
        else:
            if states is None:
                states = [None] * self.config.n_layers
            new_states = []
            for i, block in enumerate(self.blocks):
                x, s = block(x, state=states[i])
                new_states.append(s)

        x = self.ln_f(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            loss = nn.functional.cross_entropy(
                logits.view(-1, logits.size(-1)), targets.view(-1)
            )
        return logits, loss, new_states

    @torch.no_grad()
    def generate(self, input_ids, max_new_tokens=20, temperature=1.0,
                 use_streaming=False):
        self.eval()
        if not self.use_mla_baseline and use_streaming:
            states = [self._init_state.expand(input_ids.size(0), -1, -1).clone()
                      for _ in range(self.config.n_layers)]
        else:
            states = None

        for _ in range(max_new_tokens):
            logits, _, states = self.forward(input_ids, states=states)
            logits = logits[:, -1, :] / temperature
            probs = torch.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=1)
        return input_ids
