"""
YaRN (Yet another RoPE extensioN) and SuFT (Super RoPE) implementation.
Enables 4-8x context length extension without retraining.
Based on: https://arxiv.org/abs/2309.00071
"""
import torch
import math


def compute_yarn_parameters(dim, max_position_embeddings=2048, base=10000.0,
                            scale_factor=1.0, original_max_position_embeddings=2048,
                            beta_fast=32.0, beta_slow=1.0, mscale=1.0):
    """
    Compute YaRN inverse frequencies and attention temperature scaling.
    """
    def get_mscale(scale, mscale=1.0):
        if scale <= 1:
            return 1.0
        return 0.1 * mscale * math.log(scale) + 1.0

    attention_factor = get_mscale(scale_factor, mscale)

    def find_correction_dim(num_rotations, dim, base, max_position_embeddings):
        return (dim * math.log(max_position_embeddings / (num_rotations * 2 * math.pi))) / (2 * math.log(base))

    def find_correction_range(low_rot, high_rot, dim, base, max_position_embeddings):
        low = find_correction_dim(low_rot, dim, base, max_position_embeddings)
        high = find_correction_dim(high_rot, dim, base, max_position_embeddings)
        low = max(math.floor(low), 0)
        high = min(math.ceil(high), dim - 1)
        return low, high

    def linear_ramp_factor(min_val, max_val, dim_val):
        if min_val == max_val:
            max_val += 0.001
        linear_func = (torch.arange(dim_val, dtype=torch.float32) - min_val) / (max_val - min_val)
        return torch.clamp(linear_func, 0, 1)

    # Base frequencies
    pos_freqs = base ** (torch.arange(0, dim, 2).float() / dim)
    inv_freq_extrap = 1.0 / pos_freqs
    inv_freq_interp = 1.0 / (scale_factor * pos_freqs)

    # Find transition range
    low, high = find_correction_range(beta_fast, beta_slow, dim, base, original_max_position_embeddings)
    inv_freq_mask = 1 - linear_ramp_factor(low, high, dim // 2)
    inv_freq = inv_freq_interp * (1 - inv_freq_mask) + inv_freq_extrap * inv_freq_mask

    return inv_freq, attention_factor


class YaRNRoPE(torch.nn.Module):
    """YaRN RoPE with context extension support."""
    def __init__(self, dim, max_position_embeddings=2048, base=10000.0,
                 scale_factor=1.0, original_max_position_embeddings=2048,
                 beta_fast=32.0, beta_slow=1.0, mscale=1.0):
        super().__init__()
        inv_freq, attention_factor = compute_yarn_parameters(
            dim=dim,
            max_position_embeddings=max_position_embeddings,
            base=base,
            scale_factor=scale_factor,
            original_max_position_embeddings=original_max_position_embeddings,
            beta_fast=beta_fast,
            beta_slow=beta_slow,
            mscale=mscale
        )
        self.register_buffer("inv_freq", inv_freq)
        self.attention_factor = attention_factor
        self.dim = dim
        self.max_position_embeddings = max_position_embeddings

    def forward(self, seq_len, device=None, dtype=torch.float32):
        t = torch.arange(seq_len, device=device).type_as(self.inv_freq)
        freqs = torch.einsum("i,j->ij", t, self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        cos = emb.cos() * self.attention_factor
        sin = emb.sin() * self.attention_factor
        return cos, sin


def apply_yarn_rope(x, cos, sin):
    """
    Apply YaRN RoPE to tensor x.
    x: (..., seq_len, dim) where dim is head_dim
    cos, sin: (seq_len, dim)
    """
    # x shape: (B, H, L, D) or (B, L, D)
    orig_shape = x.shape
    x = x.view(*orig_shape[:-1], -1, 2)  # Split into pairs

    # Reshape cos/sin to match
    cos = cos.view(1, 1, cos.shape[0], cos.shape[1] // 2, 2) if x.dim() == 5 else cos.view(1, cos.shape[0], cos.shape[1] // 2, 2)
    sin = sin.view(1, 1, sin.shape[0], sin.shape[1] // 2, 2) if x.dim() == 5 else sin.view(1, sin.shape[0], sin.shape[1] // 2, 2)

    # Apply rotation to each pair
    x_even = x[..., 0]
    x_odd = x[..., 1]
    cos_even = cos[..., 0]
    sin_even = sin[..., 0]

    x_rotated_even = cos_even * x_even - sin_even * x_odd
    x_rotated_odd = sin_even * x_even + cos_even * x_odd

    x_rotated = torch.stack([x_rotated_even, x_rotated_odd], dim=-1)
    return x_rotated.view(orig_shape)
