"""
Microscaling (MX) FP4/FP6/FP8 utilities — OCP v1.0 compliant.
Block-wise scale factor quantization with E8M0 / E4M3 / E5M2 scales.
"""
import math
import torch

# FP4-E2M1 lookup table (OCP standard)
_FP4_E2M1_TABLE = torch.tensor([
    0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
    -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0,
], dtype=torch.float32)

def _compute_mx_scale(block, format_bits=4):
    amax = block.abs().max()
    if amax == 0:
        return torch.tensor(1.0, dtype=torch.float32, device=block.device)
    max_repr = 6.0 if format_bits == 4 else 14.0
    exp = torch.floor(torch.log2(amax / max_repr))
    scale = 2.0 ** exp
    return scale.clamp_min(1e-12)

def quantize_mxfp4(weights, block_size=32):
    orig_shape = weights.shape
    w = weights.view(-1)
    numel = w.numel()
    pad = (block_size - numel % block_size) % block_size
    if pad:
        w = torch.cat([w, torch.zeros(pad, device=w.device, dtype=w.dtype)])
    blocks = w.view(-1, block_size)
    n_blocks = blocks.shape[0]
    scales = torch.zeros(n_blocks, dtype=torch.float32, device=w.device)
    quantized = torch.zeros_like(blocks, dtype=torch.int8)
    for i in range(n_blocks):
        blk = blocks[i]
        scale = _compute_mx_scale(blk, 4)
        scales[i] = scale
        vals = blk / scale
        flat = vals.view(-1).float()
        table = _FP4_E2M1_TABLE.to(flat.device)
        dist = (flat.unsqueeze(1) - table.unsqueeze(0)).abs()
        idx = dist.argmin(dim=1).to(torch.int8)
        quantized[i] = idx.view(block_size)
    flat_idx = quantized.view(-1)
    even = flat_idx[0::2]
    odd = flat_idx[1::2]
    packed = ((even & 0x0F) | ((odd & 0x0F) << 4)).to(torch.uint8)
    return packed, scales, orig_shape, pad

def dequantize_mxfp4(packed, scales, orig_shape, pad, block_size=32):
    flat = packed.view(-1).long()
    low = flat & 0x0F
    high = (flat >> 4) & 0x0F
    interleaved = torch.stack([low, high], dim=1).view(-1)
    vals = _FP4_E2M1_TABLE.to(packed.device)[interleaved]
    n_blocks = scales.numel()
    vals = vals.view(n_blocks, block_size)
    deq = vals * scales.unsqueeze(1)
    deq = deq.view(-1)
    if pad:
        deq = deq[:-pad]
    return deq.view(orig_shape)

def isolate_outliers(x, thresh=3.5):
    median = x.median(dim=-1, keepdim=True)[0]
    mad = (x - median).abs().median(dim=-1, keepdim=True)[0]
    std = x.std(dim=-1, keepdim=True)
    mad = torch.where(mad < 1e-6, std * 0.6745, mad)
    robust_z = (x - median).abs() / (mad + 1e-12)
    mask = robust_z > thresh
    dense = x.clone()
    dense[mask] = 0.0
    sparse = x.clone()
    sparse[~mask] = 0.0
    return mask, dense, sparse
