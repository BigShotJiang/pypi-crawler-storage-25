"""
Ultra-Fused Transformer v6.0 — Selective Differential Linear Attention (SDLA)
"""
__version__ = "6.0.0"

from ultra_fused.config import UFTConfig
from ultra_fused.model.transformer import UltraFusedTransformer

__all__ = ["UFTConfig", "UltraFusedTransformer", "__version__"]
