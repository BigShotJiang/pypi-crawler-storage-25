"""
Fused Triton Kernel for SDLA:
Gộp RMSNorm + QKV Projection + Differential Subtraction thành một kernel duy nhất.
Có thể tăng tốc 2-3x so với thực thi tuần tự.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _fused_sdla_kernel(
    x_ptr, q1_ptr, q2_ptr, k1_ptr, k2_ptr, v_ptr,
    w_q1_ptr, w_q2_ptr, w_k1_ptr, w_k2_ptr, w_v_ptr,
    gamma_ptr,  # RMSNorm weight
    out_diff_ptr,
    B, L, D,
    BLOCK_D: tl.constexpr,
    EPS: tl.constexpr = 1e-6,
):
    """
    Fused kernel: RMSNorm + QKV projection + Differential (Q1K1 - lambda*Q2K2 prep).
    Each program processes one (batch, seq) position.
    """
    pid_b = tl.program_id(0)
    pid_l = tl.program_id(1)

    # Compute base offset for this (b, l)
    base = (pid_b * L + pid_l) * D

    # --- RMSNorm ---
    # Load x and compute mean squared
    offs_d = tl.arange(0, BLOCK_D)
    mask_d = offs_d < D
    x = tl.load(x_ptr + base + offs_d, mask=mask_d, other=0.0).to(tl.float32)

    x_sq = x * x
    mean_sq = tl.sum(x_sq, axis=0) / D
    rms = tl.sqrt(mean_sq + EPS)
    x_norm = x / rms

    # Apply RMSNorm gamma scaling
    gamma = tl.load(gamma_ptr + offs_d, mask=mask_d, other=1.0).to(tl.float32)
    x_scaled = x_norm * gamma

    # --- QKV Projections (simplified matvec) ---
    # For each output dimension, compute dot product with weight row
    # Q1
    q1 = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for d_out in range(0, D, BLOCK_D):
        offs_w_col = tl.arange(0, BLOCK_D)
        mask_w = offs_w_col < D
        w_row = tl.load(w_q1_ptr + (d_out + offs_d[:, None]) * D + offs_w_col[None, :], 
                        mask=mask_w[None, :] & mask_d[:, None], other=0.0).to(tl.float32)
        q1_partial = tl.sum(w_row * x_scaled[None, :], axis=1)
        q1 = tl.where((d_out + offs_d) < D, q1 + q1_partial, q1)

    # Store Q1
    tl.store(q1_ptr + base + offs_d, q1.to(tl.float16), mask=mask_d)

    # Q2 (similar)
    q2 = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for d_out in range(0, D, BLOCK_D):
        offs_w_col = tl.arange(0, BLOCK_D)
        mask_w = offs_w_col < D
        w_row = tl.load(w_q2_ptr + (d_out + offs_d[:, None]) * D + offs_w_col[None, :], 
                        mask=mask_w[None, :] & mask_d[:, None], other=0.0).to(tl.float32)
        q2_partial = tl.sum(w_row * x_scaled[None, :], axis=1)
        q2 = tl.where((d_out + offs_d) < D, q2 + q2_partial, q2)
    tl.store(q2_ptr + base + offs_d, q2.to(tl.float16), mask=mask_d)

    # K1
    k1 = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for d_out in range(0, D, BLOCK_D):
        offs_w_col = tl.arange(0, BLOCK_D)
        mask_w = offs_w_col < D
        w_row = tl.load(w_k1_ptr + (d_out + offs_d[:, None]) * D + offs_w_col[None, :], 
                        mask=mask_w[None, :] & mask_d[:, None], other=0.0).to(tl.float32)
        k1_partial = tl.sum(w_row * x_scaled[None, :], axis=1)
        k1 = tl.where((d_out + offs_d) < D, k1 + k1_partial, k1)
    tl.store(k1_ptr + base + offs_d, k1.to(tl.float16), mask=mask_d)

    # K2
    k2 = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for d_out in range(0, D, BLOCK_D):
        offs_w_col = tl.arange(0, BLOCK_D)
        mask_w = offs_w_col < D
        w_row = tl.load(w_k2_ptr + (d_out + offs_d[:, None]) * D + offs_w_col[None, :], 
                        mask=mask_w[None, :] & mask_d[:, None], other=0.0).to(tl.float32)
        k2_partial = tl.sum(w_row * x_scaled[None, :], axis=1)
        k2 = tl.where((d_out + offs_d) < D, k2 + k2_partial, k2)
    tl.store(k2_ptr + base + offs_d, k2.to(tl.float16), mask=mask_d)

    # V
    v = tl.zeros((BLOCK_D,), dtype=tl.float32)
    for d_out in range(0, D, BLOCK_D):
        offs_w_col = tl.arange(0, BLOCK_D)
        mask_w = offs_w_col < D
        w_row = tl.load(w_v_ptr + (d_out + offs_d[:, None]) * D + offs_w_col[None, :], 
                        mask=mask_w[None, :] & mask_d[:, None], other=0.0).to(tl.float32)
        v_partial = tl.sum(w_row * x_scaled[None, :], axis=1)
        v = tl.where((d_out + offs_d) < D, v + v_partial, v)
    tl.store(v_ptr + base + offs_d, v.to(tl.float16), mask=mask_d)

    # --- Differential prep: store (q1 - q2) for later use ---
    diff = q1 - q2
    tl.store(out_diff_ptr + base + offs_d, diff.to(tl.float16), mask=mask_d)


def fused_sdla_rmsnorm_qkv(x, w_q1, w_q2, w_k1, w_k2, w_v, gamma, lambda_val=0.5):
    """
    Python wrapper for fused SDLA kernel.
    x: (B, L, D)
    w_*: (D, D) weight matrices
    gamma: (D,) RMSNorm scale
    Returns: q1, q2, k1, k2, v, diff_prep
    """
    B, L, D = x.shape
    assert D % 64 == 0, "D must be divisible by 64 for Triton block size"

    # Allocate outputs
    q1 = torch.empty_like(x)
    q2 = torch.empty_like(x)
    k1 = torch.empty_like(x)
    k2 = torch.empty_like(x)
    v = torch.empty_like(x)
    diff_prep = torch.empty_like(x)

    # Grid: (B, L)
    grid = (B, L)

    _fused_sdla_kernel[grid](
        x, q1, q2, k1, k2, v,
        w_q1, w_q2, w_k1, w_k2, w_v,
        gamma,
        diff_prep,
        B, L, D,
        BLOCK_D=64,
    )

    return q1, q2, k1, k2, v, diff_prep
