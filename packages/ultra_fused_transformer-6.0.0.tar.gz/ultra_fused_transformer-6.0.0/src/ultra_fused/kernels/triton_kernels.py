"""
Ultra-Fused Transformer v6.0 — Triton Kernels
Fused: MXFP4 GEMM, Dynamic Outlier Split, Online TTT Update.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _mxfp4_lookup(idx):
    sign = (idx >> 3) & 1
    exp = (idx >> 1) & 3
    mant = idx & 1
    val = tl.where(exp == 0, mant * 0.25, tl.exp2(exp - 1.0) * (1.0 + mant * 0.5))
    return tl.where(sign == 1, -val, val)


@triton.jit
def mxfp4_gemm_kernel(
    a_ptr, b_packed_ptr, c_ptr,
    a_scale_ptr, b_scale_ptr,
    M, N, K,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr,
    GROUP_SIZE: tl.constexpr = 32,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    n_blocks = tl.cdiv(K, BLOCK_K)
    for k_block in range(n_blocks):
        k_start = k_block * BLOCK_K
        k_offs = k_start + offs_k
        mask_k = k_offs[None, :] < K
        a_ptrs = a_ptr + (offs_m[:, None] * K + k_offs[None, :])
        a_tile = tl.load(a_ptrs, mask=mask_k, other=0.0).to(tl.float32)
        b_ptrs = b_packed_ptr + (offs_n[:, None] * (K // 2) + (k_offs // 2)[None, :])
        mask_b = (k_offs // 2)[None, :] < (K // 2)
        b_packed = tl.load(b_ptrs, mask=mask_b, other=0).to(tl.uint8)
        is_odd = (k_offs[None, :] % 2).to(tl.int1)
        b_idx = tl.where(
            is_odd == 0,
            (b_packed & 0x0F).to(tl.int32),
            ((b_packed >> 4) & 0x0F).to(tl.int32),
        )
        b_val = _mxfp4_lookup(b_idx)
        acc += tl.dot(a_tile, tl.trans(b_val), out_dtype=tl.float32)
        if k_block + 1 < n_blocks:
            k_next = (k_block + 1) * BLOCK_K
            k_offs_next = k_next + offs_k
            a_ptrs_next = a_ptr + (offs_m[:, None] * K + k_offs_next[None, :])
            mask_k_next = k_offs_next[None, :] < K
            _ = tl.load(a_ptrs_next, mask=mask_k_next, other=0.0)
    b_scale = tl.load(b_scale_ptr + pid_n, mask=pid_n < N, other=1.0)
    a_scale = tl.load(a_scale_ptr + pid_m, mask=pid_m < M, other=1.0)
    acc = acc * b_scale * a_scale * 0.0625
    c_ptrs = c_ptr + (offs_m[:, None] * N + offs_n[None, :])
    mask_out = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    tl.store(c_ptrs, acc.to(tl.float16), mask=mask_out)


@triton.jit
def online_ttt_update_kernel(
    grad_ptr, w_ptr, out_ptr,
    lr: tl.constexpr,
    M, N,
    BLOCK_M: tl.constexpr, BLOCK_N: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    offs_m = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    w_ptrs = w_ptr + (offs_m[:, None] * N + offs_n[None, :])
    g_ptrs = grad_ptr + (offs_m[:, None] * N + offs_n[None, :])
    mask = (offs_m[:, None] < M) & (offs_n[None, :] < N)
    w = tl.load(w_ptrs, mask=mask, other=0.0).to(tl.float32)
    g = tl.load(g_ptrs, mask=mask, other=0.0).to(tl.float32)
    w_new = w - lr * g
    tl.store(w_ptrs, w_new.to(tl.float16), mask=mask)
    tl.store(out_ptr, w_new.to(tl.float16), mask=mask)
