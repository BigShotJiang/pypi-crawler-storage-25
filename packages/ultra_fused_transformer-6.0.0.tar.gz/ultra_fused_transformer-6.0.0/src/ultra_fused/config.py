"""
Ultra-Fused Transformer v6.1 — Configuration with DeepSeek-MLA style compression
"""
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class UFTConfig:
    """Model and training configuration."""
    # Model
    vocab_size: int = 32000
    d_model: int = 512
    n_layers: int = 8
    n_heads: int = 8
    head_dim: int = 64
    max_seq_len: int = 2048
    dropout: float = 0.0

    # SDLA (Selective Differential Linear Attention)
    use_sdla: bool = True
    sdla_state_dim: int = 64          # Fixed-size recurrent state (Working Memory)
    sdla_gist_dim: int = 32           # Compressed gist dimension (Long-term gist)
    sdla_denoise_lambda: float = 0.5  # Base denoising strength
    sdla_use_taylor: bool = True      # TaylorShift linear approximation
    sdla_taylor_order: int = 2        # Taylor expansion order
    sdla_selective_gate: bool = True  # Entropy-based selective gate

    # DeepSeek-MLA style Low-rank Compression
    use_mla_compression: bool = True
    mla_compression_ratio: int = 4    # d_model -> d_model // ratio
    mla_latent_dim: int = None        # Auto-computed: d_model // mla_compression_ratio

    # Learnable lambda per head + RMSNorm stabilization
    learnable_lambda_per_head: bool = True
    differential_rmsnorm: bool = True

    # YaRN / SuFT Long Context Extension
    use_yarn: bool = True
    yarn_scale: float = 4.0           # Extend context by 4x
    yarn_beta: float = 0.5            # Temperature scaling

    # Dynamic Router (Entropy-based)
    use_dynamic_router: bool = True
    router_entropy_thresh_low: float = 0.3   # Early exit threshold
    router_entropy_thresh_high: float = 0.7  # Full compute threshold

    # Quantization: MX Block-wise FP4 / FP8
    weight_format: str = "mxfp4"      # mxfp4 | mxfp6 | mxfp8 | int8
    mx_block_size: int = 32           # OCP MX block size
    mx_scale_format: str = "e8m0"     # e8m0 | e4m3 | e5m2
    use_smoothquant: bool = True
    smoothquant_alpha: float = 0.5
    outlier_thresh: float = 3.5      # IQR-based outlier isolation

    # Fully Quantized Training (FQT)
    fqt_forward: str = "int8"         # int8 | fp8 | fp16
    fqt_backward: str = "fp8"         # fp8 | int8 | fp16
    fqt_block_size: int = 128         # Per-block quantization for gradients

    # Architecture switches
    use_parallel_block: bool = True
    use_speculative_draft: bool = True  # Parallel draft sub-network inside block
    draft_ratio: float = 0.3          # Draft FFN width ratio

    # Training
    lr: float = 1e-3
    weight_decay: float = 0.01
    grad_clip: float = 1.0
    warmup_steps: int = 100

    def __post_init__(self):
        if self.head_dim is None:
            self.head_dim = self.d_model // self.n_heads
        assert self.d_model % self.n_heads == 0, "d_model must be divisible by n_heads"
        assert self.sdla_gist_dim <= self.sdla_state_dim, "gist_dim must <= state_dim"

        # Auto-compute MLA latent dimension
        if self.mla_latent_dim is None:
            self.mla_latent_dim = self.d_model // self.mla_compression_ratio
