"""
MLA (Multi-Head Latent Attention) Baseline for comparison.
Based on DeepSeek-V3 architecture with low-rank KV compression.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from ultra_fused.utils.yarn_rope import YaRNRoPE, apply_yarn_rope


class MLABaselineAttention(nn.Module):
    """DeepSeek-style MLA for fair comparison with SDLA."""
    def __init__(self, d_model, n_heads, max_seq_len=2048, 
                 kv_lora_rank=512, q_lora_rank=512, rope_dim=None,
                 use_yarn=True, yarn_scale=4.0, dropout=0.0):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.kv_lora_rank = kv_lora_rank
        self.q_lora_rank = q_lora_rank
        # rope_dim defaults to head_dim for simplicity
        self.rope_dim = rope_dim if rope_dim is not None else self.head_dim

        # KV Compression
        self.kv_proj = nn.Linear(d_model, kv_lora_rank + self.rope_dim, bias=False)
        self.kv_norm = nn.RMSNorm(kv_lora_rank)
        self.k_decompress = nn.Linear(kv_lora_rank, n_heads * self.head_dim, bias=False)
        self.v_decompress = nn.Linear(kv_lora_rank, n_heads * self.head_dim, bias=False)

        # Query Compression
        self.q_proj = nn.Linear(d_model, q_lora_rank, bias=False)
        self.q_norm = nn.RMSNorm(q_lora_rank)
        self.q_decompress = nn.Linear(q_lora_rank, n_heads * self.head_dim, bias=False)
        self.q_rope_proj = nn.Linear(q_lora_rank, n_heads * self.rope_dim, bias=False)

        # RoPE for keys
        self.k_rope_proj = nn.Linear(d_model, n_heads * self.rope_dim, bias=False)

        # Output
        self.o_proj = nn.Linear(n_heads * self.head_dim, d_model, bias=False)

        # YaRN
        if use_yarn:
            self.yarn = YaRNRoPE(self.rope_dim, max_position_embeddings=max_seq_len, 
                                 scale_factor=yarn_scale,
                                 original_max_position_embeddings=max_seq_len // int(yarn_scale))
        else:
            self.yarn = None

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.scale = self.head_dim ** -0.5

    def forward(self, x, state=None):
        B, L, D = x.shape
        H = self.n_heads
        hd = self.head_dim

        # KV Compression
        kv = self.kv_proj(x)
        kv_compressed, k_rope = torch.split(kv, [self.kv_lora_rank, self.rope_dim], dim=-1)
        kv_compressed = self.kv_norm(kv_compressed)

        # Decompress K, V
        k_content = self.k_decompress(kv_compressed).view(B, L, H, hd).transpose(1, 2)
        v = self.v_decompress(kv_compressed).view(B, L, H, hd).transpose(1, 2)

        # Query Compression
        q_compressed = self.q_norm(self.q_proj(x))
        q_content = self.q_decompress(q_compressed).view(B, L, H, hd).transpose(1, 2)
        q_rope = self.q_rope_proj(q_compressed).view(B, L, H, self.rope_dim).transpose(1, 2)

        # Apply RoPE
        if self.yarn is not None:
            cos, sin = self.yarn(L, device=x.device, dtype=x.dtype)
            # k_rope needs to be reshaped: (B, L, rope_dim) -> (B, H, L, rope_dim)
            k_rope_input = k_rope.view(B, L, 1, self.rope_dim).expand(-1, -1, H, -1).transpose(1, 2)
            k_rope = apply_yarn_rope(k_rope_input, cos, sin)
            q_rope = apply_yarn_rope(q_rope, cos, sin)
        else:
            k_rope = k_rope.view(B, L, 1, self.rope_dim).expand(-1, -1, H, -1).transpose(1, 2)

        # Concatenate content + RoPE
        q = torch.cat([q_content, q_rope], dim=-1)
        k = torch.cat([k_content, k_rope], dim=-1)

        # Standard attention
        scores = torch.matmul(q, k.transpose(-2, -1)) * self.scale
        scores = scores - scores.max(dim=-1, keepdim=True)[0]
        probs = torch.softmax(scores, dim=-1)
        attn = torch.matmul(probs, v).transpose(1, 2).contiguous().view(B, L, -1)
        out = self.o_proj(attn)

        return self.dropout(out), None  # No recurrent state for MLA
