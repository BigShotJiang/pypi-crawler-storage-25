"""
Parallel Block with SDLA + Dynamic Router + Speculative Draft.
Dynamic Router uses entropy-based 3-level routing:
  Level 1: Cheap FFN only (Early Exit, 80% compute saved)
  Level 2: Alpha Blending (both branches, weighted)
  Level 3: Full Compute (both branches fully)
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from ultra_fused.layers.sdla_attention import SDLAAttention
from ultra_fused.layers.quant_linear import MXLinear


class ParallelBlock(nn.Module):
    def __init__(self, d_model, n_heads, config, dropout=0.0):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.config = config
        self.use_dynamic_router = config.use_dynamic_router

        self.ln = nn.RMSNorm(d_model)

        # SDLA Attention branch
        self.attn_branch = SDLAAttention(
            d_model=d_model,
            n_heads=n_heads,
            state_dim=config.sdla_state_dim,
            gist_dim=config.sdla_gist_dim,
            denoise_lambda=config.sdla_denoise_lambda,
            use_taylor=config.sdla_use_taylor,
            taylor_order=config.sdla_taylor_order,
            selective_gate=config.sdla_selective_gate,
            dropout=dropout,
            mla_compression_ratio=config.mla_compression_ratio,
            use_mla_compression=config.use_mla_compression,
            use_yarn=config.use_yarn,
            yarn_scale=config.yarn_scale,
            max_seq_len=config.max_seq_len,
            learnable_lambda_per_head=config.learnable_lambda_per_head,
            differential_rmsnorm=config.differential_rmsnorm,
        )

        # Main FFN (SwiGLU)
        hidden_dim = 4 * d_model
        self.gate_proj = MXLinear(d_model, hidden_dim, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
        self.up_proj = MXLinear(d_model, hidden_dim, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
        self.down_proj = MXLinear(hidden_dim, d_model, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)

        # Cheap FFN (Early Exit branch - 20% width)
        cheap_dim = int(hidden_dim * 0.2)
        self.cheap_gate = MXLinear(d_model, cheap_dim, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
        self.cheap_up = MXLinear(d_model, cheap_dim, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
        self.cheap_down = MXLinear(cheap_dim, d_model, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)

        # Speculative Draft (Medium branch)
        if config.use_speculative_draft:
            draft_dim = int(hidden_dim * config.draft_ratio)
            self.draft_ln = nn.RMSNorm(d_model)
            self.draft_gate = MXLinear(d_model, draft_dim, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
            self.draft_up = MXLinear(d_model, draft_dim, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
            self.draft_down = MXLinear(draft_dim, d_model, block_size=config.mx_block_size, fqt_backward=config.fqt_backward)
            self.draft_proj = nn.Linear(d_model, 1)
        else:
            self.draft_ln = None

        # Dynamic Router: entropy-based probability distribution
        if self.use_dynamic_router:
            self.router_ln = nn.RMSNorm(d_model)
            self.router_proj = nn.Linear(d_model, 3)  # 3 levels
            self.router_entropy_low = config.router_entropy_thresh_low
            self.router_entropy_high = config.router_entropy_thresh_high

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

    def compute_entropy(self, logits):
        """Compute normalized entropy of logits as difficulty measure."""
        probs = F.softmax(logits, dim=-1)
        entropy = -(probs * torch.log(probs + 1e-10)).sum(dim=-1)  # (B, L)
        # Normalize by log(vocab_size) to [0, 1]
        max_entropy = math.log(self.config.vocab_size)
        return entropy / max_entropy

    def forward(self, x, state=None, return_router_stats=False):
        normed = self.ln(x)

        # Always compute attention (needed for entropy)
        attn_out, new_state = self.attn_branch(normed, state=state)

        # Compute router probabilities based on attention output entropy
        router_stats = {}
        if self.use_dynamic_router:
            # Use attention output as proxy for token difficulty
            router_input = self.router_ln(attn_out)
            router_logits = self.router_proj(router_input)  # (B, L, 3)
            router_probs = F.softmax(router_logits, dim=-1)  # (B, L, 3)

            # Level 1: Cheap FFN only (index 0)
            # Level 2: Alpha blending (index 1)
            # Level 3: Full compute (index 2)
            level1_prob = router_probs[..., 0:1]  # (B, L, 1)
            level2_prob = router_probs[..., 1:2]
            level3_prob = router_probs[..., 2:3]

            router_stats = {
                'level1_ratio': level1_prob.mean().item(),
                'level2_ratio': level2_prob.mean().item(),
                'level3_ratio': level3_prob.mean().item(),
            }
        else:
            level1_prob = torch.zeros(x.shape[0], x.shape[1], 1, device=x.device)
            level2_prob = torch.zeros_like(level1_prob)
            level3_prob = torch.ones_like(level1_prob)

        # --- Level 1: Cheap FFN (Early Exit) ---
        cheap_gate = torch.sigmoid(self.cheap_gate(normed)[0])
        cheap_up = self.cheap_up(normed)[0]
        cheap_out = self.cheap_down(cheap_gate * cheap_up)[0]

        # --- Level 3: Main FFN (Full Compute) ---
        main_gate = torch.sigmoid(self.gate_proj(normed)[0])
        main_up = self.up_proj(normed)[0]
        main_out = self.down_proj(main_gate * main_up)[0]

        # --- Dynamic blending based on router ---
        # For each token: if level1_prob high -> use cheap; if level3 -> use main; if level2 -> blend
        ffn_out = level1_prob * cheap_out + level3_prob * main_out + level2_prob * (0.5 * cheap_out + 0.5 * main_out)

        # Speculative Draft (confidence-based mixing)
        if self.config.use_speculative_draft and self.draft_ln is not None:
            draft_normed = self.draft_ln(x)
            d_gate = torch.sigmoid(self.draft_gate(draft_normed)[0])
            d_up = self.draft_up(draft_normed)[0]
            draft_out = self.draft_down(d_gate * d_up)[0]
            confidence = torch.sigmoid(self.draft_proj(draft_out)).squeeze(-1).unsqueeze(-1)
            ffn_out = confidence * ffn_out + (1 - confidence) * draft_out

        # Parallel residual
        out = x + self.dropout(attn_out) + self.dropout(ffn_out)

        if return_router_stats:
            return out, new_state, router_stats
        return out, new_state
