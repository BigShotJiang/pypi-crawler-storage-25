"""
Selective Differential Linear Attention (SDLA) v2.0
With DeepSeek-MLA style Low-rank Compression, YaRN, and Dynamic Router.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional
from ultra_fused.utils.yarn_rope import YaRNRoPE, apply_yarn_rope


class SDLAAttention(nn.Module):
    """
    Selective Differential Linear Attention with:
    - MLA-style low-rank compression for KV cache
    - YaRN/SuFT long-context RoPE
    - Learnable lambda per head + RMSNorm stabilization
    - Entropy-based selective gating
    """
    def __init__(self, d_model, n_heads, state_dim=64,
                 gist_dim=32, denoise_lambda=0.5,
                 use_taylor=True, taylor_order=2,
                 selective_gate=True, dropout=0.0,
                 mla_compression_ratio=4,
                 use_mla_compression=True,
                 use_yarn=True,
                 yarn_scale=4.0,
                 max_seq_len=2048,
                 learnable_lambda_per_head=True,
                 differential_rmsnorm=True):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.state_dim = state_dim
        self.gist_dim = gist_dim
        self.denoise_lambda = denoise_lambda
        self.use_taylor = use_taylor
        self.taylor_order = taylor_order
        self.selective_gate = selective_gate
        self.use_mla_compression = use_mla_compression
        self.learnable_lambda_per_head = learnable_lambda_per_head
        self.differential_rmsnorm = differential_rmsnorm

        # --- MLA-style Low-rank Compression ---
        if use_mla_compression:
            self.latent_dim = d_model // mla_compression_ratio
            # Compress hidden state to latent space before attention
            self.latent_proj = nn.Linear(d_model, self.latent_dim, bias=False)
            # Decompress latent back to d_model for Q, K, V
            self.q_decompress = nn.Linear(self.latent_dim, d_model, bias=False)
            self.k_decompress = nn.Linear(self.latent_dim, d_model, bias=False)
            self.v_decompress = nn.Linear(self.latent_dim, d_model, bias=False)
            # Separate RoPE projections (decoupled like DeepSeek)
            self.q_rope_proj = nn.Linear(self.latent_dim, d_model, bias=False)
            self.k_rope_proj = nn.Linear(self.latent_dim, d_model, bias=False)
        else:
            self.latent_dim = d_model
            self.q_proj = nn.Linear(d_model, d_model, bias=False)
            self.k_proj = nn.Linear(d_model, d_model, bias=False)
            self.v_proj = nn.Linear(d_model, d_model, bias=False)

        # Differential projections (Q1, Q2, K1, K2 for denoising)
        self.q1_proj = nn.Linear(d_model, d_model, bias=False)
        self.q2_proj = nn.Linear(d_model, d_model, bias=False)
        self.k1_proj = nn.Linear(d_model, d_model, bias=False)
        self.k2_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj_main = nn.Linear(d_model, d_model, bias=False)

        # Output projection
        self.o_proj = nn.Linear(d_model, d_model, bias=False)

        # --- YaRN RoPE ---
        if use_yarn:
            self.yarn = YaRNRoPE(
                dim=self.head_dim,
                max_position_embeddings=max_seq_len,
                scale_factor=yarn_scale,
                original_max_position_embeddings=max_seq_len // int(yarn_scale)
            )
        else:
            self.yarn = None

        # --- Working Memory & Long-term Gist ---
        self.W_h = nn.Linear(d_model, n_heads * state_dim, bias=False)
        self.W_g = nn.Linear(state_dim * n_heads, gist_dim * n_heads, bias=False)
        self.W_mix = nn.Linear(d_model + d_model, d_model, bias=False)

        # Selective gate
        if selective_gate:
            self.gate_proj = nn.Linear(d_model + state_dim * n_heads, 1, bias=True)

        # --- Learnable Lambda per head ---
        if learnable_lambda_per_head:
            self.lambda_denoise = nn.Parameter(torch.ones(n_heads) * denoise_lambda)
            self.lambda_layer_scale = nn.Parameter(torch.tensor(1.0))
        else:
            self.lambda_denoise = nn.Parameter(torch.tensor(denoise_lambda))

        # --- RMSNorm after differential subtraction ---
        if differential_rmsnorm:
            self.diff_rmsnorm = nn.RMSNorm(d_model)

        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()
        self.scale = self.head_dim ** -0.5

    def taylor_softmax(self, x, dim=-1, order=2):
        x = torch.clamp(x, min=-4.0, max=4.0)
        if self.use_taylor:
            phi = 1.0 + x
            if order >= 2:
                phi = phi + (x ** 2) / 2.0
            if order >= 3:
                phi = phi + (x ** 3) / 6.0
            phi = F.relu(phi) + 1e-6
        else:
            phi = F.elu(x) + 1.0
        return phi

    def forward(self, x, state=None, position_ids=None):
        B, L, D = x.shape
        H = self.n_heads
        hd = self.head_dim

        # --- MLA Compression: d_model -> latent_dim ---
        if self.use_mla_compression:
            latent = self.latent_proj(x)  # (B, L, latent_dim)
            # Decompress for content
            q_content = self.q_decompress(latent)
            k_content = self.k_decompress(latent)
            v = self.v_decompress(latent)
            # Separate RoPE projections
            q_rope = self.q_rope_proj(latent)
            k_rope = self.k_rope_proj(latent)
            # Combine content + RoPE
            q = q_content + q_rope
            k = k_content + k_rope
        else:
            q = self.q_proj(x)
            k = self.k_proj(x)
            v = self.v_proj_main(x)

        # --- Apply YaRN RoPE if enabled ---
        if self.yarn is not None:
            cos, sin = self.yarn(L, device=x.device, dtype=x.dtype)
            # Reshape to (B, H, L, hd) for apply_yarn_rope
            q = apply_yarn_rope(q.view(B, L, H, hd).transpose(1, 2), cos, sin).transpose(1, 2).contiguous().view(B, L, D)
            k = apply_yarn_rope(k.view(B, L, H, hd).transpose(1, 2), cos, sin).transpose(1, 2).contiguous().view(B, L, D)

        # --- Differential Attention ---
        q1 = self.q1_proj(q).view(B, L, H, hd).transpose(1, 2)
        q2 = self.q2_proj(q).view(B, L, H, hd).transpose(1, 2)
        k1 = self.k1_proj(k).view(B, L, H, hd).transpose(1, 2)
        k2 = self.k2_proj(k).view(B, L, H, hd).transpose(1, 2)
        v = v.view(B, L, H, hd).transpose(1, 2)

        # Feature maps for linearization
        q1_f = self.taylor_softmax(q1 * self.scale, order=self.taylor_order)
        q2_f = self.taylor_softmax(q2 * self.scale, order=self.taylor_order)
        k1_f = self.taylor_softmax(k1 * self.scale, order=self.taylor_order)
        k2_f = self.taylor_softmax(k2 * self.scale, order=self.taylor_order)

        # Linear attention via cumulative sums
        kv1 = torch.einsum("bhld,bhle->bhlde", k1_f, v)
        kv2 = torch.einsum("bhld,bhle->bhlde", k2_f, v)
        kv1_cum = kv1.cumsum(dim=2)
        kv2_cum = kv2.cumsum(dim=2)
        k1_cum = k1_f.cumsum(dim=2)
        k2_cum = k2_f.cumsum(dim=2)

        num1 = torch.einsum("bhld,bhlde->bhle", q1_f, kv1_cum)
        den1 = torch.einsum("bhld,bhld->bhl", q1_f, k1_cum).unsqueeze(-1).clamp(min=1e-6)
        num2 = torch.einsum("bhld,bhlde->bhle", q2_f, kv2_cum)
        den2 = torch.einsum("bhld,bhld->bhl", q2_f, k2_cum).unsqueeze(-1).clamp(min=1e-6)

        attn1 = num1 / den1
        attn2 = num2 / den2

        # --- Learnable Lambda per head ---
        if self.learnable_lambda_per_head:
            lam = self.lambda_denoise.view(1, H, 1, 1) * self.lambda_layer_scale
        else:
            lam = self.lambda_denoise

        attn_out = attn1 - lam * attn2  # (B,H,L,hd)

        # --- RMSNorm after differential subtraction ---
        if self.differential_rmsnorm:
            attn_out = self.diff_rmsnorm(attn_out.transpose(1, 2).contiguous().view(B, L, D))
            attn_out = attn_out.view(B, L, H, hd).transpose(1, 2)

        # --- Working Memory: Recurrent State Update ---
        attn_flat = attn_out.transpose(1, 2).contiguous().view(B, L, D)
        h_input = self.W_h(attn_flat).view(B, L, H, self.state_dim)

        if state is None:
            state = torch.zeros(B, H, self.state_dim, device=x.device, dtype=x.dtype)

        h_list = []
        for t in range(L):
            z = torch.sigmoid(h_input[:, t] + state)
            state = (1 - z) * state + z * torch.tanh(h_input[:, t])
            h_list.append(state)
        h_seq = torch.stack(h_list, dim=1)  # (B,L,H,state_dim)

        # --- Long-term Gist Compression ---
        h_flat = h_seq.view(B, L, -1)
        gist = self.W_g(h_flat).view(B, L, H, self.gist_dim)
        if self.gist_dim < hd:
            gist = F.pad(gist, (0, hd - self.gist_dim))
        elif self.gist_dim > hd:
            gist = gist[:, :, :, :hd]
        gist = gist.transpose(1, 2)

        # --- Selective Gate (Entropy-based) ---
        if self.selective_gate:
            attn_diff = (attn1 - attn2).norm(dim=-1)
            entropy_proxy = attn_diff.mean(dim=1, keepdim=True)
            gate_input = torch.cat([x, h_flat], dim=-1)
            gate = torch.sigmoid(self.gate_proj(gate_input)).unsqueeze(1)
        else:
            gate = 0.5

        attn_mixed = gate * attn_out + (1 - gate) * gist
        attn_mixed = attn_mixed.transpose(1, 2).contiguous().view(B, L, D)

        mixed_input = torch.cat([x, attn_mixed], dim=-1)
        out = self.o_proj(self.W_mix(mixed_input))
        out = self.dropout(out)
        return out, state.detach()
