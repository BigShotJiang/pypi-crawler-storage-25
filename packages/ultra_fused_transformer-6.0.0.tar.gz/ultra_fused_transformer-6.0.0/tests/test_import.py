"""
Tests for Ultra-Fused Transformer v6.1
"""
import torch
from ultra_fused.config import UFTConfig
from ultra_fused.model.transformer import UltraFusedTransformer


def test_sdla_forward():
    config = UFTConfig(
        vocab_size=128, d_model=64, n_layers=2, n_heads=2,
        max_seq_len=32, sdla_state_dim=16, sdla_gist_dim=8,
        mla_latent_dim=16, use_mla_compression=True,
        use_yarn=True, yarn_scale=2.0,
        use_dynamic_router=True,
        learnable_lambda_per_head=True,
        differential_rmsnorm=True,
    )
    model = UltraFusedTransformer(config, use_mla_baseline=False)
    x = torch.randint(0, 128, (2, 16))
    logits, loss, states = model(x, targets=x)
    assert logits.shape == (2, 16, 128)
    assert not torch.isnan(loss)
    print("SDLA Forward pass OK.")


def test_mla_baseline_forward():
    config = UFTConfig(
        vocab_size=128, d_model=64, n_layers=2, n_heads=2,
        max_seq_len=32, mla_latent_dim=16,
        use_yarn=True, yarn_scale=2.0,
    )
    model = UltraFusedTransformer(config, use_mla_baseline=True)
    x = torch.randint(0, 128, (2, 16))
    logits, loss, _ = model(x, targets=x)
    assert logits.shape == (2, 16, 128)
    assert not torch.isnan(loss)
    print("MLA Baseline Forward pass OK.")


def test_sdla_recurrent():
    config = UFTConfig(
        vocab_size=128, d_model=64, n_layers=2, n_heads=2,
        max_seq_len=32, sdla_state_dim=16, sdla_gist_dim=8,
    )
    model = UltraFusedTransformer(config, use_mla_baseline=False)
    x = torch.randint(0, 128, (1, 8))
    out = model.generate(x, max_new_tokens=4, use_streaming=True)
    assert out.shape[1] == 12
    print("SDLA Recurrent generation OK.")


def test_yarn_long_context():
    config = UFTConfig(
        vocab_size=128, d_model=64, n_layers=1, n_heads=2,
        max_seq_len=128,  # Training length
        sdla_state_dim=16, sdla_gist_dim=8,
        use_yarn=True, yarn_scale=4.0,  # Extend to 512
    )
    model = UltraFusedTransformer(config, use_mla_baseline=False)
    # Test with sequence longer than training but within YaRN extension
    x = torch.randint(0, 128, (1, 64))  # 64 < 128*4 = 512
    logits, _, _ = model(x)
    assert logits.shape == (1, 64, 128)
    print("YaRN Long-context OK (64 tokens with 4x extension).")


if __name__ == "__main__":
    test_sdla_forward()
    test_mla_baseline_forward()
    test_sdla_recurrent()
    test_yarn_long_context()
    print("\nAll tests passed!")
