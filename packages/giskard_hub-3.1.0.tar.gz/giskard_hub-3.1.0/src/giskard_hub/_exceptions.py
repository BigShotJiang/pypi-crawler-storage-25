from __future__ import annotations

from typing import Literal

import httpx

__all__ = [
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "ConflictError",
    "UnprocessableEntityError",
    "RateLimitError",
    "InternalServerError",
]


class HubClientError(Exception):
    pass


class APIError(HubClientError):
    message: str
    request: httpx.Request

    body: object | None
    """The API response body.

    If the API responded with a valid JSON structure then this property will be the
    decoded result.

    If it isn't a valid JSON structure then this will be the raw response.

    If there was no response associated with this error then it will be `None`.
    """

    def __init__(self, message: str, request: httpx.Request, *, body: object | None) -> None:  # noqa: ARG002
        super().__init__(message)
        self.request = request
        self.message = message
        self.body = body


class APIResponseValidationError(APIError):
    response: httpx.Response
    status_code: int

    def __init__(
        self,
        response: httpx.Response,
        body: object | None,
        *,
        message: str | None = None,
    ) -> None:
        super().__init__(
            message or "Data returned by API invalid for expected schema.",
            response.request,
            body=body,
        )
        self.response = response
        self.status_code = response.status_code


class APIStatusError(APIError):
    """Raised when an API response has a status code of 4xx or 5xx."""

    response: httpx.Response
    status_code: int

    def __init__(self, message: str, *, response: httpx.Response, body: object | None) -> None:
        super().__init__(message, response.request, body=body)
        self.response = response
        self.status_code = response.status_code


class APIConnectionError(APIError):
    def __init__(self, *, message: str = "Connection error.", request: httpx.Request) -> None:
        super().__init__(message, request, body=None)


class APITimeoutError(APIConnectionError):
    def __init__(self, request: httpx.Request) -> None:
        super().__init__(message="Request timed out.", request=request)


class BadRequestError(APIStatusError):
    status_code: Literal[400] = 400  # type: ignore[assignment]


class AuthenticationError(APIStatusError):
    status_code: Literal[401] = 401  # type: ignore[assignment]


class PermissionDeniedError(APIStatusError):
    status_code: Literal[403] = 403  # type: ignore[assignment]


class NotFoundError(APIStatusError):
    status_code: Literal[404] = 404  # type: ignore[assignment]


class ConflictError(APIStatusError):
    status_code: Literal[409] = 409  # type: ignore[assignment]


class UnprocessableEntityError(APIStatusError):
    status_code: Literal[422] = 422  # type: ignore[assignment]


class RateLimitError(APIStatusError):
    status_code: Literal[429] = 429  # type: ignore[assignment]


class InternalServerError(APIStatusError):
    pass
