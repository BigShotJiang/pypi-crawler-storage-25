import os
import cv2
import numpy as np
from abc import ABC, abstractmethod

class BaseStorage(ABC):
    @abstractmethod
    def save_image(self, image_data, folder, filename):
        """Saves an image to the specified folder with the given filename."""
        pass

    @abstractmethod
    def get_url(self, folder, filename):
        """Returns the access URL or path for the image."""
        pass

class LocalStorage(BaseStorage):
    def __init__(self, base_path="store-faces"):
        self.base_path = os.path.abspath(base_path)
        os.makedirs(self.base_path, exist_ok=True)
        os.makedirs(os.path.join(self.base_path, "originals"), exist_ok=True)
        os.makedirs(os.path.join(self.base_path, "crops"), exist_ok=True)

    def save_image(self, image_data, folder, filename):
        path = os.path.join(self.base_path, folder, filename)
        if isinstance(image_data, bytes):
            with open(path, "wb") as f:
                f.write(image_data)
        elif isinstance(image_data, np.ndarray):
            cv2.imwrite(path, image_data)
        else:
            raise ValueError("Unsupported image data type for LocalStorage")
        return filename

    def get_url(self, folder, filename):
        return f"{folder}/{filename}"

class MinioStorage(BaseStorage):
    def __init__(self, endpoint, access_key, secret_key, bucket_name, secure=False):
        from minio import Minio
        self.client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)
        self.bucket = bucket_name
        if not self.client.bucket_exists(self.bucket):
            self.client.make_bucket(self.bucket)

    def save_image(self, image_data, folder, filename):
        import io
        object_name = f"{folder}/{filename}"
        
        if isinstance(image_data, np.ndarray):
            _, buffer = cv2.imencode('.jpg', image_data)
            data = io.BytesIO(buffer)
            length = len(buffer)
        else:
            data = io.BytesIO(image_data)
            length = len(image_data)

        self.client.put_object(self.bucket, object_name, data, length, content_type="image/jpeg")
        return object_name

    def get_url(self, folder, filename):
        return f"{folder}/{filename}"
