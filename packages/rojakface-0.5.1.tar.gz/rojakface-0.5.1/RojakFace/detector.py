import cv2
import numpy as np
import os
import uuid
import urllib.request
from PIL import Image
from imgbeddings import imgbeddings

# ──────────────────────────────────────────
# YuNet model constants
# ──────────────────────────────────────────
_YUNET_URL = (
    "https://github.com/opencv/opencv_zoo/raw/main/models/"
    "face_detection_yunet/face_detection_yunet_2023mar.onnx"
)
_YUNET_FILENAME = "yunet_face_detector.onnx"


def _yunet_model_path():
    """Return the cached YuNet model path (~/.cache/rojakface/)."""
    cache_dir = os.path.expanduser("~/.cache/rojakface")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, _YUNET_FILENAME)


def _ensure_yunet_model():
    """Download the YuNet ONNX model on first use (cached in ~/.cache/rojakface/)."""
    model_path = _yunet_model_path()
    if not os.path.exists(model_path):
        print(f"Downloading YuNet face detector from OpenCV Zoo...")
        urllib.request.urlretrieve(_YUNET_URL, model_path)
        print("Download complete.")
    return model_path


class RojakFace:
    def __init__(self):
        """Core detection and embedding logic using YuNet + imgbeddings."""

        # Load YuNet (modern deep-learning face detector)
        model_path = _ensure_yunet_model()
        self.yunet = cv2.FaceDetectorYN.create(model_path, "", (0, 0))

        # Default confidence threshold
        self.detection_threshold = 0.7
        # Minimum face size for reliable embedding
        self.min_embed_size = 50

        self.ibed = imgbeddings()

    def extract_features(self, image_source):
        """Detects faces with YuNet and returns 768-d embeddings."""
        if isinstance(image_source, str):
            img = cv2.imread(image_source)
        elif isinstance(image_source, bytes):
            nparr = np.frombuffer(image_source, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        elif isinstance(image_source, np.ndarray):
            img = image_source
        else:
            raise ValueError("Unsupported image source type")

        if img is None:
            return []

        h, w = img.shape[:2]

        # YuNet needs the input image size set per-call
        self.yunet.setInputSize((w, h))
        self.yunet.setScoreThreshold(self.detection_threshold)
        _, faces = self.yunet.detect(img)

        results = []
        if faces is not None:
            for face_data in faces:
                x = int(face_data[0])
                y = int(face_data[1])
                fw = int(face_data[2])
                fh = int(face_data[3])
                confidence = float(face_data[14])

                # Clamp to image boundaries
                x1 = max(0, x)
                y1 = max(0, y)
                x2 = min(w, x + fw)
                y2 = min(h, y + fh)
                if x2 <= x1 or y2 <= y1:
                    continue

                face_img = img[y1:y2, x1:x2]
                face_pil = Image.fromarray(cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB))

                # Only embed faces with at least one side >= min_embed_size
                # (YuNet gives tight non-square boxes; imgbeddings square_pads anyway)
                if max(fw, fh) >= self.min_embed_size:
                    embedding = self.ibed.to_embeddings(face_pil)
                    emb_list = embedding[0].tolist()
                else:
                    emb_list = []

                results.append({
                    "box": [x1, y1, fw, fh],
                    "confidence": confidence,
                    "embedding": emb_list,
                    "face_image": face_img,
                })

        return results

class RojakFaceManager:
    def __init__(self, db_client=None, qdrant_client=None, storage=None, table="faces", collection="faces"):
        """Manages storage, automatic learning, and recognition."""
        self.detector = RojakFace()
        self.pg_conn = None
        self.q_client = None
        
        # Initialize storage provider (default to LocalStorage)
        from .storage import LocalStorage
        self.storage = storage if storage else LocalStorage()
        
        for client in [db_client, qdrant_client]:
            if client is None: continue
            if hasattr(client, 'cursor'): self.pg_conn = client
            elif hasattr(client, 'upsert'): self.q_client = client

        self.table_name = table
        self.collection_name = collection

    def init_storage(self):
        """Initializes PostgreSQL table and Qdrant collection."""
        if self.pg_conn:
            cur = self.pg_conn.cursor()
            cur.execute(f"""
                CREATE TABLE IF NOT EXISTS {self.table_name} (
                    id SERIAL PRIMARY KEY,
                    identity TEXT NOT NULL,
                    filename TEXT,
                    crop_path TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            # Ensure crop_path column exists (if table was created with older version)
            cur.execute(f"SELECT column_name FROM information_schema.columns WHERE table_name='{self.table_name}' AND column_name='crop_path'")
            if not cur.fetchone():
                cur.execute(f"ALTER TABLE {self.table_name} ADD COLUMN crop_path TEXT")
            
            self.pg_conn.commit()
            cur.close()

        if self.q_client:
            from qdrant_client.models import Distance, VectorParams
            if not self.q_client.collection_exists(self.collection_name):
                self.q_client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=VectorParams(size=768, distance=Distance.COSINE),
                )

    def auto_learn(self, image_source, threshold=0.85, filename=None):
        """
        Processes an image, recognizes known faces, and automatically 
        learns any 'new' faces it hasn't seen before.
        """
        if not self.q_client:
            raise RuntimeError("Qdrant client required for automatic learning (deduplication).")

        # 1. Save original image
        if filename and image_source and isinstance(image_source, bytes):
            # Ensure unique filename to prevent overwrites
            filename = f"{uuid.uuid4().hex}_{filename}"
            self.storage.save_image(image_source, "originals", filename)

        results = self.detector.extract_features(image_source)
        if not results:
            return {"new_faces": 0, "known_faces": 0, "details": []}

        stats = {"new_faces": 0, "known_faces": 0, "details": []}

        for face in results:
            # Skip faces too small for reliable embedding
            if not face['embedding']:
                stats["details"].append({"status": "skipped", "box": face['box'], "reason": "face too small for reliable embedding"})
                continue

            # Check if this face exists in Qdrant
            if hasattr(self.q_client, 'query_points'):
                response = self.q_client.query_points(
                    collection_name=self.collection_name,
                    query=face['embedding'],
                    limit=1
                )
                search_result = response.points
            else:
                search_result = self.q_client.search(
                    collection_name=self.collection_name,
                    query_vector=face['embedding'],
                    limit=1
                )

            # If similarity is high, it's a known face
            if search_result and search_result[0].score >= threshold:
                identity = search_result[0].payload.get("identity", "Unknown")

                # Save face crop for gallery
                crop_name = f"{identity}_{uuid.uuid4().hex[:4]}.jpg"
                self.storage.save_image(face['face_image'], "crops", crop_name)
                crop_path = self.storage.get_url("crops", crop_name)

                # Record the sighting in Postgres
                if self.pg_conn:
                    cur = self.pg_conn.cursor()
                    cur.execute(
                        f"INSERT INTO {self.table_name} (identity, filename, crop_path) VALUES (%s, %s, %s)",
                        (identity, filename, crop_path)
                    )
                    self.pg_conn.commit()
                    cur.close()

                stats["known_faces"] += 1
                stats["details"].append({
                    "status": "known",
                    "identity": identity,
                    "confidence": float(search_result[0].score),
                    "matched_crop_path": search_result[0].payload.get("crop_path", None)
                })
            else:
                # It's a new face! Generate a unique identity
                new_identity = f"Person_{uuid.uuid4().hex[:8]}"
                crop_name = f"{new_identity}_{uuid.uuid4().hex[:4]}.jpg"
                
                # Save crop
                self.storage.save_image(face['face_image'], "crops", crop_name)
                crop_path = self.storage.get_url("crops", crop_name)

                internal_id = None
                if self.pg_conn:
                    cur = self.pg_conn.cursor()
                    cur.execute(
                        f"INSERT INTO {self.table_name} (identity, filename, crop_path) VALUES (%s, %s, %s) RETURNING id", 
                        (new_identity, filename, crop_path)
                    )
                    internal_id = cur.fetchone()[0]
                    self.pg_conn.commit()
                    cur.close()

                from qdrant_client.models import PointStruct
                point_id = internal_id if internal_id is not None else np.random.randint(0, 10**9)
                self.q_client.upsert(
                    collection_name=self.collection_name,
                    points=[PointStruct(
                        id=point_id,
                        vector=face['embedding'],
                        payload={"identity": new_identity, "filename": filename, "crop_path": crop_path}
                    )]
                )
                
                stats["new_faces"] += 1
                stats["details"].append({"status": "new", "identity": new_identity, "confidence": float(search_result[0].score) if search_result else 0.0})

        return stats

    def recognize(self, image_source, limit=1, threshold=0.7):
        """Recognizes faces in an image against the database."""
        if not self.q_client:
            raise RuntimeError("Qdrant client required for recognition.")
            
        import base64
        query_results = self.detector.extract_features(image_source)
        final_matches = []
        for face in query_results:
            # Skip faces too small for reliable embedding
            if not face['embedding']:
                final_matches.append({
                    "box": face['box'],
                    "identity": "Unknown",
                    "confidence": 0.0,
                    "crop_path": None,
                    "reason": "face too small for reliable embedding"
                })
                continue

            if hasattr(self.q_client, 'query_points'):
                response = self.q_client.query_points(
                    collection_name=self.collection_name,
                    query=face['embedding'],
                    limit=limit
                )
                search_result = response.points
            else:
                search_result = self.q_client.search(
                    collection_name=self.collection_name,
                    query_vector=face['embedding'],
                    limit=limit
                )
            
            # Convert face_image to base64 for UI display
            _, buffer = cv2.imencode('.jpg', face['face_image'])
            face_base64 = base64.b64encode(buffer).decode('utf-8')

            if search_result and search_result[0].score >= threshold:
                match = search_result[0]
                final_matches.append({
                    "box": face['box'],
                    "identity": match.payload.get("identity", "Unknown"),
                    "confidence": float(match.score),
                    "crop_path": match.payload.get("crop_path"),
                    "face_image": f"data:image/jpeg;base64,{face_base64}"
                })
            else:
                final_matches.append({
                    "box": face['box'], 
                    "identity": "Unknown", 
                    "confidence": 0.0,
                    "crop_path": None,
                    "face_image": f"data:image/jpeg;base64,{face_base64}"
                })
        
        return final_matches

    def update_identity(self, old_identity, new_identity):
        """Renames an identity in both Postgres and Qdrant."""
        if self.pg_conn:
            cur = self.pg_conn.cursor()
            cur.execute(f"UPDATE {self.table_name} SET identity = %s WHERE identity = %s", (new_identity, old_identity))
            self.pg_conn.commit()
            cur.close()
            
        if self.q_client:
            from qdrant_client.models import Filter, FieldCondition, MatchValue
            self.q_client.set_payload(
                collection_name=self.collection_name,
                payload={"identity": new_identity},
                points=Filter(
                    must=[
                        FieldCondition(key="identity", match=MatchValue(value=old_identity))
                    ]
                )
            )
        return True

    def process(self, image_source, mode="learn", threshold=0.85, filename=None):
        """
        Unified method to either learn or identify faces in an image.
        
        Args:
            image_source: Path to image, bytes, or numpy array.
            mode: 'learn' (default) to save new faces, or 'identify' to just recognize.
            threshold: Similarity threshold (default 0.96).
            filename: Original filename (used in learn mode).
        """
        if mode == "learn":
            return self.auto_learn(image_source, threshold=threshold, filename=filename)
        else:
            return self.recognize(image_source, threshold=threshold)
