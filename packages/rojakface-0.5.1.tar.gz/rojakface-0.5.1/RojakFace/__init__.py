# ──────────────────────────────────────────
# Pre-patch dependencies BEFORE importing imgbeddings
# (imgbeddings is unmaintained and uses removed APIs)
# ──────────────────────────────────────────
import logging
_log = logging.getLogger(__name__)

# Fix 1: huggingface_hub — add back cached_download if missing
import huggingface_hub as _hh
if not hasattr(_hh, 'cached_download'):
    _hh.cached_download = lambda url, **kw: _hh.hf_hub_download(
        repo_id=kw.pop('repo_id', 'minimaxir/imgbeddings'),
        filename=kw.pop('filename', kw.pop('force_filename', 'patch32_v1.onnx')),
        **kw
    )
    _log.info("Applied cached_download → hf_hub_download patch")

# Fix 2: transformers — add feature_extractor alias if missing
try:
    from transformers import CLIPProcessor
    if not hasattr(CLIPProcessor, 'feature_extractor'):
        CLIPProcessor.feature_extractor = property(
            lambda self: getattr(self, 'image_processor', None)
        )
        _log.info("Applied feature_extractor → image_processor patch")
except Exception:
    pass

# ──────────────────────────────────────────
# Main imports
# ──────────────────────────────────────────
from .detector import RojakFace, RojakFaceManager
from .storage import BaseStorage, LocalStorage, MinioStorage

__version__ = "0.5.1"
__all__ = ["RojakFace", "RojakFaceManager", "BaseStorage", "LocalStorage", "MinioStorage"]
