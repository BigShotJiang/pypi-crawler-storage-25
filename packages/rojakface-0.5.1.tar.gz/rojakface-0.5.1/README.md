# RojakFace

A powerful, manageable, and smart face recognition library for Python.

RojakFace simplifies the entire pipeline: from detecting faces in group photos to automatically learning new identities and storing them in PostgreSQL and Qdrant for high-scale (1M+) searching.

## Features

- **Automatic Learning**: Discover new people from photos and automatically assign unique IDs.
- **Smart Learning**: When uploading a photo, already-known faces (96%+ similarity) are recognized and recorded as sightings — no duplicate identity is created. Only truly new faces get a new identity.
- **Hybrid Storage**: PostgreSQL for metadata, Qdrant for lightning-fast vector search.
- **Pluggable Storage**: Swap between local filesystem and MinIO (S3-compatible) storage without changing your code.
- **Automatic Image Organization**: Originals and cropped faces are automatically saved into separate folders.
- **AI-Ready**: Optimized for integration with LLMs (like Ollama) to build interactive face-recognition assistants.
- **Identity Renaming**: Rename individuals across both PostgreSQL and Qdrant with one call.
- **Base64 Face Crops**: `recognize` returns cropped face images as base64 for direct display in web apps.
- **Bundled Haar Cascades**: Ready to use out of the box — no extra model downloads.

## Installation

```bash
pip install RojakFace
```

## Quick Start

```python
import RojakFace as RF
import psycopg2
from qdrant_client import QdrantClient

# 1. Setup your connections
pg_conn = psycopg2.connect(database="faces_db", user="dev", password="password")
q_client = QdrantClient("localhost", port=6333)

# 2. Initialize the Manager
manager = RF.RojakFaceManager(pg_conn, q_client)
manager.init_storage()

# 3. Automatic Discovery & Learning
stats = manager.auto_learn("group_photo.jpg", filename="photo_1.jpg")
print(f"Stats: {stats}")

# 4. Renaming an Identity
manager.update_identity("Person_123", "John Doe")

# 5. Identity Recognition
results = manager.recognize("unknown_face.jpg")
for face in results:
    print(f"Found: {face['identity']} (Confidence: {face['confidence']:.2f})")
```

## Storage Backends

By default, images are saved to `./store-faces/originals/` and `./store-faces/crops/`.

### LocalStorage

```python
from RojakFace import LocalStorage

storage = LocalStorage(base_path="/custom/path")
manager = RF.RojakFaceManager(pg_conn, q_client, storage=storage)
```

### MinIO (S3-compatible)

```python
from RojakFace import MinioStorage

storage = MinioStorage(
    endpoint="localhost:9000",
    access_key="minioadmin",
    secret_key="minioadmin",
    bucket_name="rojakface",
    secure=False,
)
manager = RF.RojakFaceManager(pg_conn, q_client, storage=storage)
```

### Custom Storage

Implement the `BaseStorage` abstract class:

```python
from RojakFace import BaseStorage

class MyStorage(BaseStorage):
    def save_image(self, image_data, folder, filename): ...
    def get_url(self, folder, filename): ...
```

## API Reference

### `RojakFace`

Low-level face detector.

```python
detector = RojakFace()
features = detector.extract_features("image.jpg")
# Returns list of: { 'box': [x,y,w,h], 'embedding': [768 floats], 'face_image': numpy_array }
```

### `RojakFaceManager`

High-level manager for automatic learning and recognition.

| Method | Description |
|--------|-------------|
| `init_storage()` | Creates PostgreSQL table and Qdrant collection |
| `auto_learn(image, threshold=0.96, filename=None)` | Detect, recognize known faces, learn new ones |
| `recognize(image, limit=1, threshold=0.7)` | Just recognize without saving |
| `update_identity(old, new)` | Rename across both PostgreSQL and Qdrant |
| `process(image, mode="learn", ...)` | Unified method for `learn` or `identify` |

### Storage Classes

| Class | Description |
|-------|-------------|
| `BaseStorage` | Abstract base — implement `save_image()` and `get_url()` |
| `LocalStorage` | Saves to local filesystem |
| `MinioStorage` | Saves to MinIO / S3-compatible object storage |
