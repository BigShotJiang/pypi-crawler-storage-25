from setuptools import setup, find_packages
import os

setup(
    name="RojakFace",
    version="0.5.1",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "RojakFace": ["*.xml"],
    },
    install_requires=[
        "opencv-python",
        "imgbeddings",
        "numpy",
        "Pillow",
        "onnxruntime",
        "huggingface_hub",
        "transformers",
    ],
    author="Luqman Hafiz",
    description="A simple face detection and embedding package renamed to RojakFace",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    python_requires=">=3.8",
)
