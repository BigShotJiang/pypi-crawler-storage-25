# Init for barplots
