"""Tests for the `agentberlin workflow` CLI subcommand group.

Covers manifest-shape validation, URL routing, and the combined create+publish
flow. HTTP calls are stubbed via the `responses` library so tests don't hit a
real backend.
"""

import json
from pathlib import Path
from typing import Any

import pytest
import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


# ---------------------------------------------------------------------------
# workflow create
# ---------------------------------------------------------------------------


class TestWorkflowCreate:
    @responses.activate
    def test_plan_only_create_writes_id_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "name": "Weekly Rank Tracking",
                "details": "Query GSC weekly and flag drops.",
                "schedule": {"type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC"},
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows",
            json={"success": True, "workflow_id": "wfl_123", "name": "Weekly Rank Tracking", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_123" in result.output
        assert _read_manifest(manifest)["id"] == "wfl_123"

        # Payload carried details + schedule
        body = json.loads(responses.calls[0].request.body)
        assert body["details"] == "Query GSC weekly and flag drops."
        assert body["schedule"]["type"] == "cron"

    def test_rejects_manifest_with_id(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"name": "Existing", "id": "wfl_abc", "details": "irrelevant"}
        )
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "already has an 'id'" in result.output

    def test_rejects_manifest_without_name(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "name" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow update
# ---------------------------------------------------------------------------


class TestWorkflowUpdate:
    @responses.activate
    def test_update_patches_metadata(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "id": "wfl_abc",
                "name": "Edited Name",
                "description": "new desc",
                "details": "revised spec",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/workflows/wfl_abc",
            json={"success": True, "workflow_id": "wfl_abc", "name": "Edited Name", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "update", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_abc" in result.output
        body = json.loads(responses.calls[0].request.body)
        assert body["name"] == "Edited Name"
        assert body["description"] == "new desc"
        assert body["details"] == "revised spec"

    def test_rejects_manifest_without_id(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"name": "X", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "update", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "id" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow publish
# ---------------------------------------------------------------------------


def _write_full_manifest(tmp_path: Path, include_id: bool) -> Path:
    instruction = tmp_path / "instruction.md"
    instruction.write_text("# do the thing")

    script = tmp_path / "analyze.py"
    script.write_text(
        "from agentberlin import script\n"
        "\n"
        "@script\n"
        "def main(url: str):\n"
        "    print('{\"ok\": true}')\n"
    )

    data: dict[str, Any] = {
        "name": "Full Workflow",
        "instruction_file": "instruction.md",
        "scripts": [
            {"name": "analyze", "description": "Analyzes page data", "file_path": "analyze.py"}
        ],
    }
    if include_id:
        data["id"] = "wfl_xyz"
    return _write_manifest(tmp_path, data)


class TestWorkflowPublish:
    @responses.activate
    def test_publish_creates_version(self, tmp_path: Path) -> None:
        manifest = _write_full_manifest(tmp_path, include_id=True)
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows/wfl_xyz/versions",
            json={"success": True, "workflow_id": "wfl_xyz", "version_id": "ver_1", "version_number": 1},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "publish", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "Version 1 created" in result.output
        body = json.loads(responses.calls[0].request.body)
        assert body["instruction"] == "# do the thing"
        assert len(body["scripts"]) == 1

    def test_rejects_manifest_without_id(self, tmp_path: Path) -> None:
        manifest = _write_full_manifest(tmp_path, include_id=False)
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "publish", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "id" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow create with inline version content
# ---------------------------------------------------------------------------


class TestWorkflowCreateWithVersion:
    @responses.activate
    def test_create_plus_publish_in_one_call(self, tmp_path: Path) -> None:
        manifest = _write_full_manifest(tmp_path, include_id=False)
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows",
            json={"success": True, "workflow_id": "wfl_new", "name": "Full Workflow", "phase": "ready"},
            status=200,
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows/wfl_new/versions",
            json={"success": True, "workflow_id": "wfl_new", "version_id": "ver_1", "version_number": 1},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_new" in result.output
        assert "Version 1 created" in result.output
        assert _read_manifest(manifest)["id"] == "wfl_new"
        assert len(responses.calls) == 2


