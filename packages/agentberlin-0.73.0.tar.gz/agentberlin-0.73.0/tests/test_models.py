"""Tests for Pydantic models."""

import pytest

from agentberlin.models import (
    AnalyticsResponse,
    BrandProfileResponse,
    BrandStatsResponse,
    ChannelBreakdown,
    ClusterKeywordResult,
    ClusterKeywordsResponse,
    ClusterListResponse,
    ClusterSummary,
    DataRange,
    KeywordListResponse,
    KeywordResult,
    KeywordSearchResponse,
    PageDetailResponse,
    PageSearchResponse,
    TrafficData,
    VisibilityData,
)


class TestAnalyticsModels:
    """Tests for analytics models."""

    def test_analytics_response_minimal(self):
        """Test AnalyticsResponse with minimal data."""
        data = {
            "domain": "example.com",
            "domain_authority": 50,
            "visibility": {
                "current_percentage": 75.5,
                "ranking_stability": 0.85,
                "share_of_voice": 12.3,
                "history": [],
            },
            "traffic": {
                "total_sessions": 10000,
                "llm_sessions": 500,
                "channel_breakdown": {
                    "direct": 2000,
                    "organic_search": 5000,
                    "referral": 1000,
                    "organic_social": 500,
                    "llm": 500,
                    "other": 1000,
                },
                "daily_trend": [],
            },
            "topics": [],
            "competitors": [],
            "data_range": {"start": "2024-01-01", "end": "2024-01-31"},
            "last_updated": "2024-01-31T12:00:00Z",
        }

        response = AnalyticsResponse.model_validate(data)
        assert response.domain == "example.com"
        assert response.domain_authority == 50
        assert response.visibility.current_percentage == 75.5

    def test_channel_breakdown_defaults(self):
        """Test ChannelBreakdown default values."""
        breakdown = ChannelBreakdown()
        assert breakdown.direct == 0
        assert breakdown.organic_search == 0
        assert breakdown.llm == 0


class TestSearchModels:
    """Tests for search models."""

    def test_page_search_response(self):
        """Test PageSearchResponse parsing."""
        data = {
            "similar_pages": [
                {
                    "target_page_url": "https://example.com/page1",
                    "similarity_score": 0.85,
                    "match_type": "page_to_page",
                },
                {
                    "target_page_url": "https://example.com/page2",
                    "similarity_score": 0.72,
                    "match_type": "chunk_to_page",
                    "chunk_text": "Sample chunk text",
                },
            ],
            "similar_chunks": [],
        }

        response = PageSearchResponse.model_validate(data)
        assert len(response.similar_pages) == 2
        assert response.similar_pages[0].target_page_url == "https://example.com/page1"
        assert response.similar_pages[0].similarity_score == 0.85

    def test_keyword_result_optional_fields(self):
        """Test KeywordResult with optional fields."""
        # With all fields (locations contains volume, difficulty, cpc)
        full_data = {
            "keyword": "seo tips",
            "intent": "informational",
            "locations": [
                {"code": "us", "volume": 1000, "difficulty": 45, "cpc": 2.50},
            ],
        }
        result = KeywordResult.model_validate(full_data)
        assert result.keyword == "seo tips"
        assert result.intent == "informational"
        assert len(result.locations) == 1
        assert result.locations[0].volume == 1000

        # With minimal fields
        minimal_data = {"keyword": "seo tips"}
        result = KeywordResult.model_validate(minimal_data)
        assert result.keyword == "seo tips"
        assert result.intent is None
        assert len(result.locations) == 0

    def test_cluster_list_response(self):
        """Test ClusterListResponse parsing."""
        data = {
            "clusters": [
                {
                    "cluster_id": 0,
                    "size": 47,
                    "representative_keywords": ["seo tools", "best seo platform", "seo software"],
                },
                {
                    "cluster_id": 1,
                    "size": 32,
                    "representative_keywords": ["content marketing", "blog strategy"],
                },
            ],
            "noise_count": 234,
            "total_keywords": 5000,
            "cluster_count": 15,
        }

        response = ClusterListResponse.model_validate(data)
        assert len(response.clusters) == 2
        assert response.clusters[0].cluster_id == 0
        assert response.clusters[0].size == 47
        assert len(response.clusters[0].representative_keywords) == 3
        assert response.noise_count == 234
        assert response.total_keywords == 5000
        assert response.cluster_count == 15

    def test_cluster_keywords_response(self):
        """Test ClusterKeywordsResponse parsing."""
        data = {
            "keywords": [
                {
                    "keyword": "seo tools",
                    "cluster_id": 0,
                    "locations": [{"code": "us", "volume": 1000, "difficulty": 45}],
                },
                {
                    "keyword": "best seo platform",
                    "cluster_id": 0,
                    "locations": [{"code": "us", "volume": 800}],
                },
                {"keyword": "seo software", "cluster_id": 0},
            ],
            "total": 47,
            "cluster_id": 0,
            "limit": 50,
            "offset": 0,
        }

        response = ClusterKeywordsResponse.model_validate(data)
        assert len(response.keywords) == 3
        assert response.keywords[0].keyword == "seo tools"
        assert response.keywords[0].locations[0].volume == 1000
        assert response.keywords[0].locations[0].difficulty == 45
        assert response.keywords[1].locations[0].difficulty is None  # Optional field
        assert len(response.keywords[2].locations) == 0  # No locations
        assert response.total == 47
        assert response.cluster_id == 0
        assert response.limit == 50
        assert response.offset == 0

    def test_page_detail_response(self):
        """Test PageDetailResponse with links."""
        data = {
            "url": "https://example.com/page",
            "title": "Test Page",
            "h1": "Welcome",
            "content_length": 5000,
            "links": {
                "inlinks": [
                    {
                        "source_url": "https://example.com/other",
                        "target_url": "https://example.com/page",
                        "domain_type": "internal",
                    }
                ],
                "outlinks": [],
            },
        }

        response = PageDetailResponse.model_validate(data)
        assert response.url == "https://example.com/page"
        assert len(response.links.inlinks) == 1


class TestBrandModels:
    """Tests for brand profile models."""

    def test_brand_profile_response(self):
        """Test BrandProfileResponse parsing."""
        data = {
            "domain": "example.com",
            "name": "Example Inc",
            "context": "A technology company",
            "domain_authority": 60,
            "competitors": ["competitor1.com", "competitor2.com"],
            "industries": ["technology", "saas"],
            "business_models": ["b2b"],
            "company_size": "startup",
            "target_customer_segments": ["enterprise"],
            "geographies": ["us", "eu"],
            "personas": ["cto", "developer"],
            "sitemaps": [],
            "profile_urls": [],
        }

        response = BrandProfileResponse.model_validate(data)
        assert response.domain == "example.com"
        assert len(response.competitors) == 2

    def test_brand_stats_response_full(self):
        """Test BrandStatsResponse parsing with every section populated."""
        data = {
            "brand_name": "example.com",
            "generated_at": 1713312000,
            "pages": {
                "total": 100,
                "crawl_health": {
                    "status_class_counts": {"2xx": 80, "3xx": 10, "4xx": 8, "5xx": 2},
                    "indexable_count": 75,
                    "non_indexable_count": 25,
                    "indexability_reasons": {"Canonicalised": 12, "Noindex": 8, "Redirected": 5},
                    "canonicalized_count": 12,
                },
                "content_structure": {
                    "missing_title_count": 2,
                    "missing_meta_description_count": 15,
                    "missing_h1_count": 4,
                    "duplicate_titles_count": 6,
                    "duplicate_h1_count": 3,
                    "duplicate_meta_description_count": 9,
                    "empty_content_count": 1,
                    "thin_content_count": 7,
                },
                "url_shape": {
                    "top_path_prefixes": [{"prefix": "/blog", "count": 40}, {"prefix": "/docs", "count": 20}],
                    "query_string_pages_count": 3,
                    "https_count": 100,
                    "http_count": 0,
                    "trailing_slash_count": 25,
                },
                "redirects": {"self_referential_redirects_count": 1},
                "performance": {
                    "response_time_stats": {"mean": 320.5, "p50": 280.0, "p90": 900.0, "p99": 2100.0},
                    "slow_pages_count": 4,
                    "freshness_distribution": {
                        "lt_7d": 2, "lt_30d": 8, "lt_90d": 20, "lt_1y": 50, "gt_1y": 15, "unknown": 5,
                    },
                    "oldest_page_last_modified": 1577836800,
                    "newest_page_last_modified": 1712000000,
                },
            },
            "links": {
                "total_inlinks": 500,
                "total_outlinks": 300,
                "orphan_pages_count": 5,
                "dead_end_pages_count": 3,
                "top_linked_pages": [{"url": "https://example.com/", "count": 80}],
                "top_linking_pages": [{"url": "https://example.com/sitemap", "count": 60}],
                "broken_outlink_count": 4,
                "internal_outlink_count": 220,
                "external_outlink_count": 80,
                "top_external_domains": [{"domain": "wikipedia.org", "count": 12}],
                "anchor_text_diversity": 180,
                "link_classification_counts": {"content": 400, "boilerplate": 350, "ambiguous": 50},
                "link_type_counts": {"Hyperlink": 780, "Image": 20},
            },
            "keywords": {
                "total": 200,
                "volume": {
                    "total_search_volume": 120000,
                    "volume_buckets": {
                        "zero": 5, "1_10": 10, "10_100": 30, "100_1k": 90,
                        "1k_10k": 50, "10k_100k": 13, "gte_100k": 2,
                    },
                    "total_cpc_weighted_volume": 45000.5,
                },
                "difficulty": {
                    "difficulty_buckets": {
                        "0_20": 20, "20_40": 60, "40_60": 70, "60_80": 40, "80_100": 5, "unknown": 5,
                    }
                },
                "ranking": {
                    "ranking_count": 150,
                    "position_buckets": {
                        "top_3": 10, "4_10": 40, "11_20": 50, "21_50": 30, "51_100": 20, "unranked": 50,
                    },
                    "top_3_count": 10,
                    "first_page_count": 50,
                },
                "intent": {
                    "counts": {
                        "informational": 120, "commercial": 40, "transactional": 30, "navigational": 5, "unknown": 5,
                    },
                    "volume_share": {
                        "informational": 60000, "commercial": 30000, "transactional": 25000, "navigational": 3000, "unknown": 2000,
                    },
                },
            },
            "cross": {
                "keyword_to_page_matches_count": 100,
                "ranking_pages_count": 45,
                "top_landing_pages": [
                    {"url": "https://example.com/", "keyword_count": 12, "total_volume": 25000},
                ],
                "topics_count": 20,
                "topics_with_pillar_page_count": 15,
                "topics_with_landing_page_count": 12,
            },
        }

        response = BrandStatsResponse.model_validate(data)
        assert response.brand_name == "example.com"
        assert response.generated_at == 1713312000
        assert response.pages is not None
        assert response.pages.total == 100
        assert response.pages.crawl_health is not None
        assert response.pages.crawl_health.status_class_counts.four_xx == 8
        assert response.pages.crawl_health.indexability_reasons["Canonicalised"] == 12
        assert response.pages.performance is not None
        assert response.pages.performance.response_time_stats is not None
        assert response.pages.performance.response_time_stats.p99 == 2100.0
        assert response.links is not None
        assert response.links.broken_outlink_count == 4
        assert response.links.top_external_domains[0].domain == "wikipedia.org"
        assert response.keywords is not None
        assert response.keywords.volume is not None
        assert response.keywords.volume.volume_buckets.ten_k_to_100k == 13
        assert response.keywords.ranking is not None
        assert response.keywords.ranking.top_3_count == 10
        assert response.keywords.intent is not None
        assert response.keywords.intent.counts.informational == 120
        assert response.cross is not None
        assert response.cross.top_landing_pages[0].keyword_count == 12

    def test_brand_stats_response_minimal(self):
        """Test BrandStatsResponse parsing when all sections are absent."""
        data = {"brand_name": "empty", "generated_at": 0}
        response = BrandStatsResponse.model_validate(data)
        assert response.brand_name == "empty"
        assert response.pages is None
        assert response.links is None
        assert response.keywords is None
        assert response.cross is None
