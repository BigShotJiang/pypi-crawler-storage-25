"""Tests for the log() function."""

import os
import re
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from agentberlin import log


class TestLogFunction:
    """Tests for the log() function."""

    def test_log_writes_to_file_when_env_var_set(self, tmp_path: Path) -> None:
        """Log writes entries to file when AGENTBERLIN_LOG_PATH is set."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("Test message")

        content = log_file.read_text()
        assert "Test message" in content
        assert "[INFO]" in content

    def test_log_is_noop_when_env_var_not_set(self, tmp_path: Path) -> None:
        """Log is silent no-op when AGENTBERLIN_LOG_PATH is not set."""
        # Ensure env var is not set
        env = os.environ.copy()
        env.pop("AGENTBERLIN_LOG_PATH", None)

        with patch.dict(os.environ, env, clear=True):
            # This should not raise any errors
            log("Test message")

        # Verify no file was created in tmp_path
        assert list(tmp_path.iterdir()) == []

    def test_log_level_info_default(self, tmp_path: Path) -> None:
        """Log uses INFO level by default."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("Info message")

        content = log_file.read_text()
        assert "[INFO]" in content

    def test_log_level_debug(self, tmp_path: Path) -> None:
        """Log supports debug level."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("Debug message", level="debug")

        content = log_file.read_text()
        assert "[DEBUG]" in content

    def test_log_level_warn(self, tmp_path: Path) -> None:
        """Log supports warn level."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("Warning message", level="warn")

        content = log_file.read_text()
        assert "[WARN]" in content

    def test_log_level_error(self, tmp_path: Path) -> None:
        """Log supports error level."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("Error message", level="error")

        content = log_file.read_text()
        assert "[ERROR]" in content

    def test_log_timestamp_format(self, tmp_path: Path) -> None:
        """Log entries have ISO 8601 timestamp format with milliseconds."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("Test message")

        content = log_file.read_text()
        # Match ISO 8601 format: 2026-03-27T14:30:22.123
        pattern = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}"
        assert re.search(pattern, content), f"Timestamp not found in: {content}"

    def test_log_appends_to_file(self, tmp_path: Path) -> None:
        """Multiple log calls append to the same file."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("First message")
            log("Second message")
            log("Third message")

        content = log_file.read_text()
        assert "First message" in content
        assert "Second message" in content
        assert "Third message" in content

        # Verify each message is on its own line
        lines = content.strip().split("\n")
        assert len(lines) == 3

    def test_log_entry_format(self, tmp_path: Path) -> None:
        """Log entries have correct format: timestamp [LEVEL] message."""
        log_file = tmp_path / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            log("My test message")

        content = log_file.read_text().strip()
        # Format: 2026-03-27T14:30:22.123 [INFO] My test message
        pattern = r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3} \[INFO\] My test message$"
        assert re.match(pattern, content), f"Format mismatch: {content}"

    def test_log_handles_invalid_path_silently(self, tmp_path: Path) -> None:
        """Log fails silently when path is invalid/unwritable."""
        invalid_path = "/nonexistent/directory/test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": invalid_path}):
            # Should not raise any errors
            log("Test message")

    def test_log_creates_parent_dirs_if_needed(self, tmp_path: Path) -> None:
        """Log does not create parent directories - caller must ensure they exist."""
        # The log function doesn't create directories; the CLI does
        # This test verifies the expected behavior
        log_file = tmp_path / "subdir" / "test.log"

        with patch.dict(os.environ, {"AGENTBERLIN_LOG_PATH": str(log_file)}):
            # This should fail silently since parent dir doesn't exist
            log("Test message")

        # File should not exist since parent wasn't created
        assert not log_file.exists()


class TestLogImport:
    """Tests for log import from package."""

    def test_log_importable_from_package(self) -> None:
        """log() can be imported from agentberlin package."""
        from agentberlin import log

        assert callable(log)

    def test_log_in_all(self) -> None:
        """log is included in __all__."""
        import agentberlin

        assert "log" in agentberlin.__all__
