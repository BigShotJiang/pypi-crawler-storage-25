"""Pydantic models for Google Sheets API responses."""

from typing import Any, List, Optional

from pydantic import BaseModel


class CreateSpreadsheetResponse(BaseModel):
    """Response for creating a spreadsheet."""

    spreadsheet_id: str
    spreadsheet_url: str
    title: str


class WriteResponse(BaseModel):
    """Response for writing to a spreadsheet."""

    spreadsheet_id: str
    updated_range: str
    updated_rows: int
    updated_columns: int
    updated_cells: int


class ReadResponse(BaseModel):
    """Response for reading from a spreadsheet."""

    range: str
    values: List[List[Any]]


class AppendResponse(BaseModel):
    """Response for appending to a spreadsheet."""

    spreadsheet_id: str
    table_range: str
    updated_rows: int
    updated_cells: int
