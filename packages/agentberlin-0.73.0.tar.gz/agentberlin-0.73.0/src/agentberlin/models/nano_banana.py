"""Pydantic models for Nano Banana (Gemini image generation) API responses."""

from typing import Optional

from pydantic import BaseModel, Field


class NanoBananaGenerateResponse(BaseModel):
    """Response from generate() - generated image URL."""

    image_url: str = Field(description="URL to the generated image")
    mime_type: str = Field(description="MIME type of the image (e.g., 'image/png')")
    text: Optional[str] = Field(
        default=None, description="Optional text commentary from the model"
    )
