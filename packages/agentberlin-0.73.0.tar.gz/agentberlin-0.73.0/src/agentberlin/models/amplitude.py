"""Pydantic models for Amplitude API responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class SessionsData(BaseModel):
    """Sessions analytics data."""

    total: int
    average_length: float = Field(description="Average session length in seconds")
    per_user: float


class UsersData(BaseModel):
    """Users analytics data."""

    active: int
    new: int


class AmplitudeResponse(BaseModel):
    """Response from get() - core analytics data."""

    sessions: SessionsData
    users: UsersData


class AmplitudeEvent(BaseModel):
    """An Amplitude event."""

    name: str
    totals: int = Field(description="Weekly total count")


class EventsListResponse(BaseModel):
    """Response from list_events()."""

    events: List[AmplitudeEvent] = Field(default_factory=list)


class AmplitudeCohort(BaseModel):
    """An Amplitude behavioral cohort."""

    id: str
    name: str
    size: int
    description: Optional[str] = None


class CohortsListResponse(BaseModel):
    """Response from list_cohorts()."""

    cohorts: List[AmplitudeCohort] = Field(default_factory=list)


class FunnelStep(BaseModel):
    """A single step in funnel analysis."""

    event: str
    users_entered: int
    users_completed: int
    conversion_rate: float = Field(description="Conversion rate as percentage")
    drop_off_rate: float = Field(description="Drop-off rate as percentage")


class FunnelResponse(BaseModel):
    """Response from get_funnel()."""

    steps: List[FunnelStep] = Field(default_factory=list)
    overall_conversion: float = Field(description="Overall funnel conversion rate as percentage")


class RetentionDay(BaseModel):
    """Retention data for a specific day."""

    day: int = Field(description="Day number (0, 1, 7, 14, 30)")
    retained: int
    retention_rate: float = Field(description="Retention rate as percentage")


class RetentionResponse(BaseModel):
    """Response from get_retention()."""

    cohort_size: int
    retention: List[RetentionDay] = Field(default_factory=list)
