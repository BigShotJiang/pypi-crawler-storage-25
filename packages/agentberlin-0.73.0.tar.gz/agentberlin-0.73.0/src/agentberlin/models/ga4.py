"""Pydantic models for GA4 API responses."""

from typing import Dict, List

from pydantic import BaseModel, Field


class GA4Row(BaseModel):
    """A single row of GA4 query results.

    Attributes:
        dimensions: Dictionary mapping dimension names to their values.
        metrics: Dictionary mapping metric names to their values.
    """

    dimensions: Dict[str, str] = Field(default_factory=dict)
    metrics: Dict[str, str] = Field(default_factory=dict)


class GA4QueryResponse(BaseModel):
    """Response from GA4 query endpoint.

    Attributes:
        rows: List of data rows with dimensions and metrics.
        row_count: Total number of rows returned.
        totals: Aggregate totals for all metrics across the date range.
    """

    rows: List[GA4Row] = Field(default_factory=list)
    row_count: int
    totals: Dict[str, str] = Field(default_factory=dict)
