"""Pydantic models for Google Search API responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class GoogleSearchResult(BaseModel):
    """Single search result from Google Search."""

    title: str
    url: str
    snippet: str
    displayed_link: Optional[str] = None
    date: Optional[str] = None
    thumbnail: Optional[str] = None


class GoogleSearchMetadata(BaseModel):
    """Metadata about the Google search."""

    id: Optional[str] = None
    status: Optional[str] = None
    total_time_taken: Optional[float] = None


class GoogleSearchWebResponse(BaseModel):
    """Response for Google web search."""

    query: str
    results: List[GoogleSearchResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchNewsResult(BaseModel):
    """Single news result from Google News search."""

    title: str
    url: str
    snippet: str
    source: Optional[str] = None
    date: Optional[str] = None
    thumbnail: Optional[str] = None


class GoogleSearchNewsResponse(BaseModel):
    """Response for Google News search."""

    query: str
    results: List[GoogleSearchNewsResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchImageResult(BaseModel):
    """Single image result from Google Images search."""

    title: str
    url: str
    original: Optional[str] = None
    thumbnail: Optional[str] = None
    source: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


class GoogleSearchImagesResponse(BaseModel):
    """Response for Google Images search."""

    query: str
    results: List[GoogleSearchImageResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchVideoResult(BaseModel):
    """Single video result from Google Videos search."""

    title: str
    url: str
    snippet: Optional[str] = None
    displayed_link: Optional[str] = None
    thumbnail: Optional[str] = None
    duration: Optional[str] = None
    platform: Optional[str] = None


class GoogleSearchVideosResponse(BaseModel):
    """Response for Google Videos search."""

    query: str
    results: List[GoogleSearchVideoResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchShoppingResult(BaseModel):
    """Single shopping result from Google Shopping search."""

    title: str
    url: str
    price: Optional[str] = None
    source: Optional[str] = None
    thumbnail: Optional[str] = None
    rating: Optional[float] = None
    reviews: Optional[int] = None


class GoogleSearchShoppingResponse(BaseModel):
    """Response for Google Shopping search."""

    query: str
    results: List[GoogleSearchShoppingResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchAIModeResponse(BaseModel):
    """Response for Google AI Mode search."""

    query: str
    answer: str
    sources: List[GoogleSearchResult] = Field(default_factory=list)
    search_metadata: Optional[GoogleSearchMetadata] = None
