"""Script decorator for Agent Berlin workflows.

The @script decorator marks a function as the entry point for a workflow script.
It extracts the function signature to generate a JSON schema that is used by the
LLM to understand the expected parameters.

Example:
    from agentberlin import AgentBerlin, script

    sdk = AgentBerlin()

    @script
    def main(url: str, depth: int = 3, include_images: bool = True):
        '''Crawl a website and extract data.'''
        # script logic here

    if __name__ == "__main__":
        main()
"""

import functools
import inspect
from typing import Any, Callable, Optional, TypeVar, Union, get_args, get_origin

F = TypeVar("F", bound=Callable[..., Any])


def _python_type_to_json_type(python_type: type) -> dict[str, Any]:
    """Convert a Python type hint to a JSON Schema type.

    Supports:
    - str -> string
    - int -> integer
    - float -> number
    - bool -> boolean
    - list -> array
    - list[X] -> array with items of type X
    - dict -> object
    - Optional[X] -> nullable version of X
    """
    # Handle None type
    if python_type is type(None):
        return {"type": "null"}

    # Handle Optional types (Union[X, None])
    origin = get_origin(python_type)
    if origin is Union:
        args = get_args(python_type)
        # Check if it's Optional (Union with None)
        non_none_args = [arg for arg in args if arg is not type(None)]
        if len(non_none_args) == 1:
            # It's Optional[X]
            inner_schema = _python_type_to_json_type(non_none_args[0])
            # For optional parameters, we don't add "null" to the type
            # The schema validator handles omitted parameters
            return inner_schema
        # For more complex unions, default to first non-None type
        if non_none_args:
            return _python_type_to_json_type(non_none_args[0])
        return {"type": "string"}

    # Handle list types
    if origin is list:
        args = get_args(python_type)
        if args:
            return {
                "type": "array",
                "items": _python_type_to_json_type(args[0]),
            }
        return {"type": "array"}

    # Handle dict types
    if origin is dict:
        args = get_args(python_type)
        if len(args) == 2:
            return {
                "type": "object",
                "additionalProperties": _python_type_to_json_type(args[1]),
            }
        return {"type": "object"}

    # Handle basic types
    type_mapping = {
        str: "string",
        int: "integer",
        float: "number",
        bool: "boolean",
        list: "array",
        dict: "object",
    }

    # Handle the type itself (not a generic)
    if python_type in type_mapping:
        return {"type": type_mapping[python_type]}

    # Default to string for unknown types
    return {"type": "string"}


def _extract_schema(func: Callable[..., Any]) -> dict[str, Any]:
    """Extract a JSON Schema from a function's signature.

    Args:
        func: The function to extract schema from.

    Returns:
        A JSON Schema dictionary describing the function's parameters.
    """
    sig = inspect.signature(func)
    hints = {}
    try:
        hints = func.__annotations__.copy() if hasattr(func, "__annotations__") else {}
    except Exception:
        pass

    properties: dict[str, Any] = {}
    required: list[str] = []

    for param_name, param in sig.parameters.items():
        # Skip *args and **kwargs
        if param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue

        # Get type hint
        param_type = hints.get(param_name, str)  # Default to str if no type hint

        # Build property schema
        prop_schema = _python_type_to_json_type(param_type)

        # Add description from docstring if available
        # (We could parse docstrings in the future)

        properties[param_name] = prop_schema

        # Check if required (no default value)
        if param.default is inspect.Parameter.empty:
            required.append(param_name)

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
        "additionalProperties": False,
    }

    if required:
        schema["required"] = required

    return schema


def script(func: F) -> F:
    """Decorator that marks a function as a workflow script entry point.

    The decorated function will have `_is_script = True` and `_script_schema`
    attributes set, which are used by the CLI to extract the schema and run
    the script.

    Args:
        func: The function to decorate.

    Returns:
        The decorated function with schema metadata attached.

    Example:
        @script
        def main(url: str, depth: int = 3):
            '''Crawl a URL to the specified depth.'''
            pass
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return func(*args, **kwargs)

    # Mark as a script function
    wrapper._is_script = True  # type: ignore[attr-defined]

    # Extract and attach the schema
    wrapper._script_schema = _extract_schema(func)  # type: ignore[attr-defined]

    return wrapper  # type: ignore[return-value]
