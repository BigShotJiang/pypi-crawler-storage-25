"""Google Sheets resource for Agent Berlin SDK."""

from typing import Any, List, Optional

from .._http import HTTPClient
from ..models.sheets import (
    AppendResponse,
    CreateSpreadsheetResponse,
    ReadResponse,
    WriteResponse,
)


class SheetsResource:
    """Resource for Google Sheets operations.

    Create, read, write, and append data to Google Sheets in the user's account.
    Requires Google Sheets integration to be connected for the project.

    Example:
        # Create a new spreadsheet
        sheet = client.sheets.create(title="My Report")
        print(f"Created: {sheet.spreadsheet_url}")

        # Write data
        client.sheets.write(
            spreadsheet_id=sheet.spreadsheet_id,
            range="Sheet1!A1:B2",
            values=[["Name", "Age"], ["Alice", 30]]
        )

        # Read data
        data = client.sheets.read(
            spreadsheet_id=sheet.spreadsheet_id,
            range="Sheet1!A1:B2"
        )
        print(data.values)

        # Append rows
        client.sheets.append(
            spreadsheet_id=sheet.spreadsheet_id,
            range="Sheet1!A1",
            values=[["Bob", 25]]
        )
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(self, title: str) -> CreateSpreadsheetResponse:
        """Create a new spreadsheet.

        Args:
            title: Title for the new spreadsheet.

        Returns:
            CreateSpreadsheetResponse with spreadsheet_id, spreadsheet_url, and title.

        Raises:
            AgentBerlinAPIError: On API errors.
        """
        data = self._http.post(
            "/sheets/create",
            json={"title": title},
        )
        return CreateSpreadsheetResponse.model_validate(data)

    def write(
        self,
        spreadsheet_id: str,
        range: str,
        values: List[List[Any]],
        *,
        input_option: Optional[str] = None,
    ) -> WriteResponse:
        """Write data to a spreadsheet range.

        Args:
            spreadsheet_id: The ID of the spreadsheet.
            range: The A1 notation of the range to write (e.g., "Sheet1!A1:B2").
            values: 2D array of values to write.
            input_option: How input data should be interpreted.
                "RAW" - Values are stored as-is.
                "USER_ENTERED" - Values are parsed as if typed into the UI (default).

        Returns:
            WriteResponse with updated_range, updated_rows, updated_columns, updated_cells.

        Raises:
            AgentBerlinAPIError: On API errors.
        """
        payload: dict = {
            "spreadsheet_id": spreadsheet_id,
            "range": range,
            "values": values,
        }
        if input_option is not None:
            payload["input_option"] = input_option

        data = self._http.post("/sheets/write", json=payload)
        return WriteResponse.model_validate(data)

    def read(self, spreadsheet_id: str, range: str) -> ReadResponse:
        """Read data from a spreadsheet range.

        Args:
            spreadsheet_id: The ID of the spreadsheet.
            range: The A1 notation of the range to read (e.g., "Sheet1!A1:B2").

        Returns:
            ReadResponse with range and values (2D array).

        Raises:
            AgentBerlinAPIError: On API errors.
        """
        data = self._http.post(
            "/sheets/read",
            json={
                "spreadsheet_id": spreadsheet_id,
                "range": range,
            },
        )
        return ReadResponse.model_validate(data)

    def append(
        self,
        spreadsheet_id: str,
        range: str,
        values: List[List[Any]],
        *,
        input_option: Optional[str] = None,
    ) -> AppendResponse:
        """Append rows to a spreadsheet.

        Args:
            spreadsheet_id: The ID of the spreadsheet.
            range: The A1 notation of a range to search for a table.
                Values are appended after the last row of the table.
            values: 2D array of values to append.
            input_option: How input data should be interpreted.
                "RAW" - Values are stored as-is.
                "USER_ENTERED" - Values are parsed as if typed into the UI (default).

        Returns:
            AppendResponse with table_range, updated_rows, updated_cells.

        Raises:
            AgentBerlinAPIError: On API errors.
        """
        payload: dict = {
            "spreadsheet_id": spreadsheet_id,
            "range": range,
            "values": values,
        }
        if input_option is not None:
            payload["input_option"] = input_option

        data = self._http.post("/sheets/append", json=payload)
        return AppendResponse.model_validate(data)
