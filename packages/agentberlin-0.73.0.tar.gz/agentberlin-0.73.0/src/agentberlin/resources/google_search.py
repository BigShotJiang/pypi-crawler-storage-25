"""Google Search resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.google_search import (
    GoogleSearchAIModeResponse,
    GoogleSearchImagesResponse,
    GoogleSearchNewsResponse,
    GoogleSearchShoppingResponse,
    GoogleSearchVideosResponse,
    GoogleSearchWebResponse,
)


class GoogleSearchResource:
    """Resource for Google Search operations.

    Search the web using Google - includes web results, news, images, videos,
    shopping, and AI features.

    Example:
        # Web search
        results = client.google_search.web(
            query="best seo tools",
            max_results=10,
        )

        # News search
        results = client.google_search.news(
            query="AI technology",
            country="us",
        )

        # Image search
        results = client.google_search.images(
            query="modern website design",
        )

        for result in results.results:
            print(f"{result.title}: {result.url}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def web(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchWebResponse:
        """Search the web using Google.

        Returns titles, URLs, and snippets of top-ranking pages.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-10, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code prefixed with 'lang_'
                     (e.g., 'lang_en', 'lang_de', 'lang_fr').

        Returns:
            GoogleSearchWebResponse with search results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/web", json=payload)
        return GoogleSearchWebResponse.model_validate(data)

    def news(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchNewsResponse:
        """Search Google News.

        Returns news articles matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleSearchNewsResponse with news results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/news", json=payload)
        return GoogleSearchNewsResponse.model_validate(data)

    def images(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> GoogleSearchImagesResponse:
        """Search Google Images.

        Returns image results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            GoogleSearchImagesResponse with image results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/google-search/images", json=payload)
        return GoogleSearchImagesResponse.model_validate(data)

    def videos(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> GoogleSearchVideosResponse:
        """Search Google Videos.

        Returns video results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            GoogleSearchVideosResponse with video results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/google-search/videos", json=payload)
        return GoogleSearchVideosResponse.model_validate(data)

    def shopping(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        country: Optional[str] = None,
    ) -> GoogleSearchShoppingResponse:
        """Search Google Shopping.

        Returns shopping/product results matching the query.

        Args:
            query: The search query to execute.
            max_results: Number of results (1-100, default: 10).
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            GoogleSearchShoppingResponse with shopping results.
        """
        payload: dict[str, object] = {"query": query}
        if max_results is not None:
            payload["max_results"] = max_results
        if country is not None:
            payload["country"] = country

        data = self._http.post("/google-search/shopping", json=payload)
        return GoogleSearchShoppingResponse.model_validate(data)

    def ai_mode(
        self,
        query: str,
        *,
        country: Optional[str] = None,
        language: Optional[str] = None,
    ) -> GoogleSearchAIModeResponse:
        """Use Google AI Mode for conversational search.

        Returns an AI-generated answer with source citations.

        Args:
            query: The search query to execute.
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleSearchAIModeResponse with AI-generated answer and sources.
        """
        payload: dict[str, object] = {"query": query}
        if country is not None:
            payload["country"] = country
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-search/ai-mode", json=payload)
        return GoogleSearchAIModeResponse.model_validate(data)
