"""Nano Banana resource for Agent Berlin SDK (Gemini image generation)."""

import base64
import mimetypes
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .._http import HTTPClient
from ..models.nano_banana import NanoBananaGenerateResponse
from ..utils import get_project_domain


class NanoBananaResource:
    """Resource for Nano Banana AI image generation.

    Provides access to Gemini's image generation capabilities through the Agent Berlin API.
    The project context is determined by the sandbox's PROJECT_DOMAIN environment
    variable, so methods don't require explicit project parameters.

    Supported aspect ratios: 1:1, 16:9, 9:16, 4:3, 3:4, 3:2, 2:3, 4:5, 5:4, 21:9
    Supported sizes: 1K (1024px), 2K (2048px), 4K (4096px)
    Reference images: Up to 14 for editing/style transfer

    Example:
        # Basic generation
        result = client.nano_banana.generate(
            prompt="A serene mountain landscape at sunset"
        )
        print(f"Image URL: {result.image_url}")

        # With options
        result = client.nano_banana.generate(
            prompt="Product photo of a smartphone",
            aspect_ratio="16:9",
            size="2K"
        )

        # With reference image (edit existing image)
        result = client.nano_banana.generate(
            prompt="Make this image more vibrant",
            reference_images=["input.png"]  # File path
        )

        # Download and save result
        import requests
        response = requests.get(result.image_url)
        with open("output.png", "wb") as f:
            f.write(response.content)
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def generate(
        self,
        prompt: str,
        *,
        aspect_ratio: Optional[str] = None,
        size: Optional[str] = None,
        reference_images: Optional[List[Union[str, bytes, Path]]] = None,
    ) -> NanoBananaGenerateResponse:
        """Generate an image using Gemini's image generation model.

        Args:
            prompt: The text prompt describing the image to generate.
            aspect_ratio: Optional aspect ratio. Supported: 1:1, 16:9, 9:16, 4:3, 3:4,
                         3:2, 2:3, 4:5, 5:4, 21:9. Defaults to "1:1".
            size: Optional image size. Supported: 1K (1024px), 2K (2048px), 4K (4096px).
                  Defaults to "1K".
            reference_images: Optional list of reference images for editing/style transfer.
                             Can be file paths (str or Path) or bytes. Maximum 14 images.

        Returns:
            NanoBananaGenerateResponse with image URL and mime type.

        Raises:
            AgentBerlinNotFoundError: If Nano Banana integration not found.
            AgentBerlinAPIError: If the API returns an error.
            ValueError: If more than 14 reference images provided.

        Example:
            # Generate from text
            result = client.nano_banana.generate(prompt="A sunset over mountains")
            print(f"Image URL: {result.image_url}")

            # Edit an existing image
            result = client.nano_banana.generate(
                prompt="Add a rainbow to this image",
                reference_images=["landscape.jpg"]
            )

            # Download and save the generated image
            import requests
            response = requests.get(result.image_url)
            with open("output.png", "wb") as f:
                f.write(response.content)
        """
        if reference_images and len(reference_images) > 14:
            raise ValueError("Maximum 14 reference images allowed")

        project_domain = get_project_domain()
        payload: Dict[str, Any] = {
            "project_domain": project_domain,
            "prompt": prompt,
        }

        if aspect_ratio is not None:
            payload["aspect_ratio"] = aspect_ratio
        if size is not None:
            payload["size"] = size

        if reference_images:
            processed_refs = []
            for ref in reference_images:
                processed_refs.append(self._process_reference_image(ref))
            payload["reference_images"] = processed_refs

        data = self._http.post("/nano-banana/generate", json=payload)

        return NanoBananaGenerateResponse(
            image_url=data["image_url"],
            mime_type=data["mime_type"],
            text=data.get("text"),
        )

    def _process_reference_image(
        self, image: Union[str, bytes, Path]
    ) -> Dict[str, str]:
        """Process a reference image into the API format.

        Args:
            image: File path (str or Path) or raw bytes

        Returns:
            Dict with 'data' (base64) and 'mime_type' keys
        """
        if isinstance(image, (str, Path)):
            # File path - read and encode
            path = Path(image)
            with open(path, "rb") as f:
                image_bytes = f.read()
            mime_type = mimetypes.guess_type(str(path))[0] or "image/png"
        else:
            # Raw bytes
            image_bytes = image
            # Try to detect image type from bytes
            mime_type = self._detect_mime_type(image_bytes)

        return {
            "data": base64.b64encode(image_bytes).decode("utf-8"),
            "mime_type": mime_type,
        }

    def _detect_mime_type(self, data: bytes) -> str:
        """Detect MIME type from image bytes.

        Args:
            data: Raw image bytes

        Returns:
            MIME type string
        """
        # Check magic bytes
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return "image/png"
        elif data[:2] == b"\xff\xd8":
            return "image/jpeg"
        elif data[:6] in (b"GIF87a", b"GIF89a"):
            return "image/gif"
        elif data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp"
        else:
            return "image/png"  # Default to PNG
