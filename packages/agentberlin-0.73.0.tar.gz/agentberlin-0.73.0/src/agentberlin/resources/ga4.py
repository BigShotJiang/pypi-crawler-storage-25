"""GA4 resource for Agent Berlin SDK."""

from typing import Any, Dict, List, Optional

from .._http import HTTPClient
from ..models.ga4 import GA4QueryResponse
from ..utils import get_project_domain


class GA4Resource:
    """Resource for GA4 operations.

    Provides direct access to Google Analytics 4 Data API through the `query()` method,
    enabling flexible reporting with custom metrics, dimensions, filters, and date ranges.

    Example:
        # Get organic traffic for the last week
        result = client.ga4.query(
            metrics=["totalUsers", "sessions"],
            start_date="2026-03-12",
            end_date="2026-03-19",
            dimension_filter={
                "field_name": "sessionDefaultChannelGroup",
                "string_filter": {"match_type": "EXACT", "value": "Organic Search"}
            }
        )
        for row in result.rows:
            print(f"Users: {row.metrics['totalUsers']}, Sessions: {row.metrics['sessions']}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def query(
        self,
        metrics: List[str],
        start_date: str,
        end_date: str,
        *,
        dimensions: Optional[List[str]] = None,
        dimension_filter: Optional[Dict[str, Any]] = None,
        order_bys: Optional[List[Dict[str, Any]]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        date_ranges: Optional[List[Dict[str, str]]] = None,
        currency_code: Optional[str] = None,
    ) -> GA4QueryResponse:
        """Query GA4 analytics data using the GA4 Data API.

        This method maps directly to Google Analytics 4's `runReport` API,
        providing full flexibility for analytics queries.

        Args:
            metrics: List of metric names to retrieve. Required.
                Examples: ["totalUsers", "sessions", "ecommercePurchases"]
            start_date: Start date in YYYY-MM-DD format. Required.
            end_date: End date in YYYY-MM-DD format. Required.
            dimensions: Optional list of dimension names to break down metrics.
                Examples: ["country", "sessionDefaultChannelGroup", "date"]
            dimension_filter: Optional filter to restrict results. Supports:
                - Simple filter: {"field_name": "country", "string_filter": {"match_type": "EXACT", "value": "US"}}
                - In-list filter: {"field_name": "country", "in_list_filter": {"values": ["US", "CA"]}}
                - AND group: {"and_group": {"expressions": [filter1, filter2]}}
                - OR group: {"or_group": {"expressions": [filter1, filter2]}}
                - NOT: {"not_expression": filter}
            order_bys: Optional list of ordering specifications.
                Example: [{"metric": "totalUsers", "desc": True}]
            limit: Maximum number of rows to return.
            offset: Number of rows to skip (for pagination).
            date_ranges: Optional list of date ranges for comparison.
                Example: [
                    {"start_date": "2026-03-12", "end_date": "2026-03-19", "name": "current"},
                    {"start_date": "2026-03-05", "end_date": "2026-03-12", "name": "previous"}
                ]
            currency_code: Optional currency code for monetary metrics (e.g., "USD").

        Returns:
            GA4QueryResponse containing rows with dimension and metric values,
            total row count, and aggregate totals.

        Raises:
            AgentBerlinValidationError: If mixing item-scoped dimensions with
                event-scoped metrics (scope conflict).
            AgentBerlinNotFoundError: If no GA4 integration found for the domain.
            AgentBerlinAPIError: If the GA4 API returns an error.

        Note:
            Item-scoped dimensions (e.g., itemName, itemId, itemBrand) cannot be
            combined with event-scoped metrics (e.g., totalUsers, sessions).
            Use item-scoped metrics (itemsViewed, itemRevenue) instead.

        Example:
            # Country breakdown with multiple metrics
            result = client.ga4.query(
                metrics=["totalUsers", "ecommercePurchases"],
                dimensions=["country"],
                start_date="2026-03-12",
                end_date="2026-03-19",
                order_bys=[{"metric": "totalUsers", "desc": True}],
                limit=10
            )

            # Date comparison
            result = client.ga4.query(
                metrics=["sessions"],
                start_date="2026-03-12",
                end_date="2026-03-19",
                date_ranges=[
                    {"start_date": "2026-03-12", "end_date": "2026-03-19", "name": "current"},
                    {"start_date": "2026-03-05", "end_date": "2026-03-12", "name": "previous"}
                ]
            )
        """
        payload: Dict[str, Any] = {
            "project_domain": get_project_domain(),
            "metrics": metrics,
            "start_date": start_date,
            "end_date": end_date,
        }

        if dimensions is not None:
            payload["dimensions"] = dimensions
        if dimension_filter is not None:
            payload["dimension_filter"] = dimension_filter
        if order_bys is not None:
            payload["order_bys"] = order_bys
        if limit is not None:
            payload["limit"] = limit
        if offset is not None:
            payload["offset"] = offset
        if date_ranges is not None:
            payload["date_ranges"] = date_ranges
        if currency_code is not None:
            payload["currency_code"] = currency_code

        data = self._http.post("/ga4/query", json=payload)
        return GA4QueryResponse.model_validate(data)
