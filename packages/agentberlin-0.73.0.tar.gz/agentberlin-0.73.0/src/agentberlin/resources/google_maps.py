"""Google Maps resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.google_maps import (
    GoogleMapsReviewsResponse,
    GoogleMapsSearchResponse,
)


class GoogleMapsResource:
    """Resource for Google Maps operations.

    Search for places and businesses, and retrieve reviews.

    Example:
        # Search for places
        results = client.google_maps.search(
            query="coffee shops",
            location="New York, NY",
        )

        # Get reviews for a place
        reviews = client.google_maps.reviews(
            data_id="0x89c259a9b1e8d3a7:0x1234567890abcdef",
        )

        for place in results.results:
            print(f"{place.title}: {place.rating} stars")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def search(
        self,
        query: str,
        *,
        location: Optional[str] = None,
        ll: Optional[str] = None,
        type: Optional[str] = None,
        language: Optional[str] = None,
        country: Optional[str] = None,
    ) -> GoogleMapsSearchResponse:
        """Search for places and businesses on Google Maps.

        Args:
            query: The search query (e.g., "coffee shops", "restaurants").
            location: Location to center the search (e.g., "New York, NY").
                     Mutually exclusive with ll.
            ll: GPS coordinates for search center as "@lat,lng,zoom"
               (e.g., "@40.7128,-74.0060,15z"). Mutually exclusive with location.
            type: Filter by place type (e.g., "restaurant", "cafe").
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').
            country: ISO 3166-1 alpha-2 country code (e.g., 'us', 'gb', 'de').

        Returns:
            GoogleMapsSearchResponse with place results.
        """
        payload: dict[str, object] = {"query": query}
        if location is not None:
            payload["location"] = location
        if ll is not None:
            payload["ll"] = ll
        if type is not None:
            payload["type"] = type
        if language is not None:
            payload["language"] = language
        if country is not None:
            payload["country"] = country

        data = self._http.post("/google-maps/search", json=payload)
        return GoogleMapsSearchResponse.model_validate(data)

    def reviews(
        self,
        *,
        data_id: Optional[str] = None,
        place_id: Optional[str] = None,
        sort_by: Optional[str] = None,
        num: Optional[int] = None,
        language: Optional[str] = None,
    ) -> GoogleMapsReviewsResponse:
        """Get reviews for a Google Maps place.

        You must provide either data_id or place_id.

        Args:
            data_id: The data_id from a search result (preferred, faster).
            place_id: The place_id from Google Maps.
            sort_by: Sort order for reviews. Options: 'most_relevant',
                    'newest', 'highest_rating', 'lowest_rating'.
            num: Number of reviews to return (default: 10).
            language: ISO 639-1 language code (e.g., 'en', 'de', 'fr').

        Returns:
            GoogleMapsReviewsResponse with reviews.
        """
        if data_id is None and place_id is None:
            raise ValueError("Either data_id or place_id must be provided")

        payload: dict[str, object] = {}
        if data_id is not None:
            payload["data_id"] = data_id
        if place_id is not None:
            payload["place_id"] = place_id
        if sort_by is not None:
            payload["sort_by"] = sort_by
        if num is not None:
            payload["num"] = num
        if language is not None:
            payload["language"] = language

        data = self._http.post("/google-maps/reviews", json=payload)
        return GoogleMapsReviewsResponse.model_validate(data)
