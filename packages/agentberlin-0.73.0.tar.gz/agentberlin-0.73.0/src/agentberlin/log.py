"""Logging utility for Agent Berlin SDK.

Provides a simple log() function that writes timestamped progress logs
to a file specified by the AGENTBERLIN_LOG_PATH environment variable.

When run via `agentberlin run`, logs are written to ~/.agentberlin/logs/<run_id>.log.
When run directly (outside agentberlin run), log() is a no-op (silent).

Example:
    from agentberlin import log

    log("Starting data fetch")
    for i, item in enumerate(items):
        log(f"Processing {i+1} of {len(items)}")
    log("Completed successfully")
    log("Item skipped due to missing data", level="warn")
"""

import os
from datetime import datetime
from typing import Literal

LogLevel = Literal["debug", "info", "warn", "error"]


def log(message: str, level: LogLevel = "info") -> None:
    """Write a timestamped log entry to the run log file.

    When run via `agentberlin run`, logs are written to the file specified
    by AGENTBERLIN_LOG_PATH. When run directly (outside agentberlin run),
    this function is a silent no-op.

    Args:
        message: The log message to write.
        level: Log level - "debug", "info" (default), "warn", or "error".

    Example:
        from agentberlin import log

        log("Starting phase 1")
        log(f"Processing {i+1} of {total}")
        log("Skipped invalid item", level="warn")
    """
    log_path = os.environ.get("AGENTBERLIN_LOG_PATH")
    if not log_path:
        # No log path configured - silent no-op
        return

    # Format timestamp in ISO 8601 format with milliseconds
    timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]

    # Format level for display
    level_upper = level.upper()

    # Write log entry with immediate flush
    log_entry = f"{timestamp} [{level_upper}] {message}\n"

    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(log_entry)
            f.flush()
    except (OSError, IOError):
        # If we can't write to the log file, fail silently
        # This matches the silent no-op behavior for missing env var
        pass
