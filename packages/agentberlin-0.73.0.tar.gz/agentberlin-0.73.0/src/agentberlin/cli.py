"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for downloading workflows, uploading reports,
and executing workflow scripts.
"""

import importlib.util
import json
import os
import secrets
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

import click
import requests

from . import __version__
from .config import DEFAULT_BASE_URL
from .session import configure_session as _configure_session
from .session import load_session_config


@click.group()
@click.version_option(version=__version__, prog_name="agentberlin")
def main() -> None:
    """Agent Berlin CLI - Download and manage workflows."""
    pass


@main.command()
@click.option("--token", "-t", required=True, help="Authentication token from get_auth_token MCP tool")
@click.option("--domain", "-d", required=True, help="Project domain (e.g., example.com)")
@click.option("--config-path", help="Custom config file path")
def configure(token: str, domain: str, config_path: Optional[str]) -> None:
    """Configure session credentials for Agent Berlin."""
    _configure_session(token, domain, config_path)
    click.echo(f"Session configured for domain: {domain}")


@main.command()
@click.argument("workflow_id")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--output", "-o", type=click.Path(), help="Output directory")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def download_workflow(
    workflow_id: str,
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a workflow to local files.

    WORKFLOW_ID is the workflow identifier.

    This downloads the workflow definition to local files that can be read
    by an LLM to understand and execute the workflow locally.
    """
    # Resolve token (same as SDK)
    if not token:
        config = load_session_config()
        token = config.get("token")

    if not token:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")

    # Fetch workflow from API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/workflows/{workflow_id}/download"

    try:
        resp = requests.get(url, headers=headers, timeout=30)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found or access denied.")
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    data = resp.json()

    # Determine output directory
    if output:
        out_dir = Path(output)
    else:
        out_dir = Path.cwd() / ".agentberlin" / "workflows" / workflow_id

    out_dir.mkdir(parents=True, exist_ok=True)
    scripts_dir = out_dir / "scripts"
    scripts_dir.mkdir(exist_ok=True)
    subagents_dir = out_dir / "subagents"
    subagents_dir.mkdir(exist_ok=True)

    # Write scripts as individual .py files
    script_files: list[str] = []
    for script in data.get("scripts", []):
        name = script["name"].replace(" ", "_").lower()
        filename = f"{name}.py"
        script_files.append(filename)

        # Add header comment to script
        deps = ", ".join(script.get("dependencies", []))
        header = f"""# Script: {script["name"]}
# Description: {script.get("description", "")}
# Dependencies: {deps}

"""
        (scripts_dir / filename).write_text(header + script.get("script", ""))

    # Write sub-agents as individual .md files
    subagent_files: list[str] = []
    for subagent in data.get("subagents", []):
        name = subagent["name"].replace(" ", "_").lower()
        filename = f"{name}.md"
        subagent_files.append(filename)

        header = f"# {subagent['name']}\n\n"
        (subagents_dir / filename).write_text(header + subagent.get("processing_guide", ""))

    # Write instruction to separate file
    (out_dir / "instruction.md").write_text(data.get("instruction", ""))

    # Build script entries with input_schema if available (format readable by
    # `agentberlin workflow publish`).
    script_entries = []
    for script in data.get("scripts", []):
        entry: dict[str, Any] = {
            "name": script["name"],
            "description": script.get("description", ""),
            "file_path": f"scripts/{script['name'].replace(' ', '_').lower()}.py",
        }
        if script.get("input_schema"):
            entry["input_schema"] = script["input_schema"]
        script_entries.append(entry)

    manifest: dict[str, Any] = {
        "id": data.get("id", workflow_id),
        "name": data.get("name", ""),
        "instruction_file": "instruction.md",
        "scripts": script_entries,
    }

    if data.get("subagents"):
        manifest["subagents"] = [
            {
                "name": sa["name"],
                "processing_guide_file": f"subagents/{sa['name'].replace(' ', '_').lower()}.md",
            }
            for sa in data.get("subagents", [])
        ]

    if data.get("built_in_tools"):
        manifest["built_in_tools"] = data["built_in_tools"]

    if data.get("inputs"):
        manifest["inputs"] = data["inputs"]

    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2))

    # Print confirmation
    click.echo(f"Downloaded workflow: {data.get('name', workflow_id)}")
    click.echo(f"Location: {out_dir}")
    click.echo("Files:")
    click.echo("  - manifest.json")
    click.echo("  - instruction.md")
    for sf in script_files:
        click.echo(f"  - scripts/{sf}")
    for sf in subagent_files:
        click.echo(f"  - subagents/{sf}")


@main.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--description", "-d", required=True, help="Report description")
@click.option("--project-domain", help="Project domain (reads from config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def save_report(
    file_path: str,
    description: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Upload a file as a report to Agent Berlin.

    FILE_PATH is the path to the file to upload.

    This uploads the file to Agent Berlin's storage and registers it
    so users can download it from the Agent Berlin UI.
    """
    # Resolve token and project_domain from config
    config = load_session_config()

    if not token:
        token = config.get("token")

    if not token:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")

    if not project_domain:
        project_domain = config.get("project_domain")

    if not project_domain:
        raise click.ClickException("No project domain found. Use --project-domain or configure session first.")

    source = Path(file_path)
    if not source.exists():
        raise click.ClickException(f"File not found: {file_path}")

    # Upload file to backend API
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{base_url}/reports/upload"

    try:
        with open(source, "rb") as f:
            files = {"file": (source.name, f)}
            form_data = {"description": description, "project_domain": project_domain}
            resp = requests.post(url, headers=headers, files=files, data=form_data, timeout=120)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_msg = resp.json().get("error", "Bad request")
        raise click.ClickException(f"Upload failed: {error_msg}")

    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"API request failed: {e}")

    result = resp.json()
    click.echo(f"Report uploaded: {source.name}")
    click.echo(f"Description: {description}")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


def _resolve_project_domain(project_domain: Optional[str]) -> str:
    """Resolve project_domain from CLI arg or session config."""
    if project_domain:
        return project_domain
    config = load_session_config()
    resolved = config.get("project_domain")
    if not resolved:
        raise click.ClickException(
            "No project domain found. Use --project-domain or configure session first."
        )
    return resolved


@main.group("brand-files")
def brand_files_group() -> None:
    """List and download brand context files (keywords, prompts, brand tone, etc.)."""
    pass


@brand_files_group.command("list")
@click.option("--project-domain", help="Project domain (reads from config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a table")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_files_list(
    project_domain: Optional[str],
    token: Optional[str],
    as_json: bool,
    base_url: str,
) -> None:
    """List all brand files attached to the project."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    _handle_api_error(resp, "Brand file list")
    files = resp.json().get("files", [])

    if as_json:
        click.echo(json.dumps(files, indent=2))
        return

    if not files:
        click.echo("No brand files found.")
        return

    id_w = max(len("ID"), max(len(f["id"]) for f in files))
    name_w = max(len("FILENAME"), max(len(f["filename"]) for f in files))
    click.echo(f"{'ID':<{id_w}}  {'FILENAME':<{name_w}}  {'SIZE':>10}  DESCRIPTION")
    for f in files:
        size_kb = f.get("size_bytes", 0) / 1024
        size_str = f"{size_kb:.1f} KB"
        desc = f.get("description", "") or ""
        click.echo(f"{f['id']:<{id_w}}  {f['filename']:<{name_w}}  {size_str:>10}  {desc}")


@brand_files_group.command("download")
@click.argument("file_id")
@click.option("--project-domain", help="Project domain (reads from config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path. Defaults to the original filename in the current directory.",
)
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_files_download(
    file_id: str,
    project_domain: Optional[str],
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a brand file's contents by its ID.

    FILE_ID is the file identifier shown by `agentberlin brand-files list`.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/content",
            headers=headers,
            json={"project_domain": project_domain, "file_id": file_id},
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Brand file '{file_id}' not found.")
    _handle_api_error(resp, "Brand file download")

    if output:
        out_path = Path(output)
    else:
        # Extract filename from Content-Disposition, fall back to file_id.
        disposition = resp.headers.get("Content-Disposition", "")
        filename = file_id
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        out_path = Path.cwd() / filename

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(resp.content)
    click.echo(f"Downloaded: {out_path} ({len(resp.content)} bytes)")


WORKFLOW_GROUP_HELP = """Manage workflows (create, update, publish).

\b
Commands:
  create    Create a new workflow (and optionally publish its first version)
  update    Update metadata of an existing workflow (name, description, details, schedule)
  publish   Create a new version of an existing workflow (instruction + scripts)

All three commands read from the same manifest file. The verb chooses which
parts of the manifest are sent to the API. Run `agentberlin workflow <cmd> --help`
for the specific fields each command reads.

MANIFEST FILE FORMAT
====================

The manifest is a JSON file that defines your workflow structure:

\b
{
  "name": "My Workflow",
  "description": "Optional description",
  "id": "wfl_abc123xyz",
  "details": "Natural-language spec (plan-only)",
  "schedule": {"type": "cron", "cron_expression": "...", "timezone": "UTC"},
  "instruction_file": "path/to/instructions.md",
  "scripts": [...],
  "subagents": [...],
  "built_in_tools": [...],
  "inputs": [...]
}

REQUIRED FIELDS
===============
  name             - Workflow name (always required)
  id               - Required by `update` and `publish`; absent for `create`
  instruction_file - Required by `publish` (and `create` when publishing a first version)
  scripts          - Required by `publish` (and `create` when publishing a first version)

OPTIONAL FIELDS
===============
  description      - Workflow description
  details          - Natural-language spec for pre-planning workflows (read by create/update)
  schedule         - {type: "cron"|"one_time"|"manual", cron_expression?, timezone?} (read by create/update)
  subagents        - LLM sub-agents (read by publish)
  built_in_tools   - Defaults to ["save_report"] (read by publish)
  inputs           - Configurable parameters (read by publish)

INSTRUCTION FILE
================
The instruction file (markdown) is the system prompt for the orchestrator LLM
that executes the workflow. It should describe:
- The workflow's goal
- The process/steps to follow
- Data flow between components
- Error handling behavior

Do NOT include tool documentation - it's auto-injected at runtime.

SCRIPTS (TOOLS)
===============
Python scripts that the orchestrator can call. Each script:
- MUST use the @script decorator with typed parameters
- Should write large outputs to files, not stdout
- Must print a JSON control envelope with metadata

Required fields per script:
  name         - Tool name the orchestrator will use
  description  - What the tool does (shown to orchestrator)
  file_path    - Path to the Python file

\b
Script structure:
  import json
  from agentberlin import AgentBerlin, script

  sdk = AgentBerlin()

  @script
  def main(param: str, limit: int = 100):
      # Parameters are passed directly as typed arguments
      # ... implementation ...
      print(json.dumps({"output_file": "results.json", "count": limit}))

  if __name__ == "__main__":
      main()

Parameter guidelines:
- Use simple types: str, int, float, bool, list[str]
- Avoid nested dicts or complex objects
- Prefer fewer parameters (under 10) for clarity, but not a hard limit

LOGGING
=======
Scripts can report progress using the log() function:

\b
  from agentberlin import log

  log("Starting data fetch")
  for i, item in enumerate(items):
      log(f"Processing {i+1} of {len(items)}")
  log("Completed successfully")
  log("Item skipped", level="warn")

When run via `agentberlin run`, logs are written to ~/.agentberlin/logs/<run_id>.log.
The log file path is printed before script output so agents can monitor progress.

Log levels: debug, info (default), warn, error

Guidelines:
- Log at phase boundaries and loop progress (e.g., "Processing 10 of 100"). It's extremely important to use the logs to inform about the progress so far and enough information to predict the remaining effort/time. There are calls like bifrost page.search which are computationally intensive and can take time. Without having this visibility of the progress, the script may look stuck.
- Use level="warn" for skipped items or recoverable issues
- Avoid logging every micro-operation or API call

SUBAGENTS
=========
LLM sub-agents for tasks requiring semantic understanding (classification,
summarization, content generation). Use when deterministic Python isn't enough.

Required fields per subagent:
  name                  - Subagent identifier
  processing_guide_file - Path to markdown file with instructions

The processing guide should describe the TASK and OUTPUT format, not
orchestration mechanics (batching is automatic).

BUILT-IN TOOLS
==============
Optional. Defaults to ["save_report"]. Valid options:
  save_report - Saves files from session directory as downloadable reports

INPUTS
======
Optional configurable parameters that make workflows reusable. Users provide
values when running the workflow.

\b
Fields per input:
  key          - Unique identifier (snake_case)
  label        - Human-readable name for UI
  description  - Help text
  type         - "text" or "file"
  default_value - Pre-filled value (optional, not for file type)
  required     - Whether parameter must be provided
  placeholder  - Input hint (optional)

EXAMPLE: FULL WORKFLOW
======================

\b
# manifest.json (no 'id' yet — the create command writes it back)
{
  "name": "My Workflow",
  "instruction_file": "./instructions.md",
  "scripts": [
    {"name": "analyze", "description": "Analyzes page data", "file_path": "./analyze.py"}
  ],
  "inputs": [
    {"key": "url", "label": "URL", "description": "Target URL", "type": "text", "required": true}
  ]
}

\b
# Create workflow + publish first version (writes 'id' back to manifest)
agentberlin workflow create --manifest manifest.json

\b
# Later: publish a new version after editing a script
agentberlin workflow publish --manifest manifest.json

EXAMPLE: PLAN-ONLY (PRE-PLANNING)
=================================

Capture a workflow idea as a natural-language spec; a planner/builder will
later turn it into an executable workflow. Omit `scripts`/`instruction_file`;
include `details` (and optionally `schedule`).

\b
# plan.json
{
  "name": "Weekly Keyword Rank Tracking",
  "description": "Track target keyword positions weekly",
  "details": "Read target keywords from the keywords resource. Every Monday query GSC for rank data for the past 7 days. Flag any keyword that dropped more than 3 positions WoW. Write a summary CSV and email it to the SEO lead.",
  "schedule": { "type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC" }
}

\b
agentberlin workflow create --manifest plan.json
# Later revise details or schedule:
agentberlin workflow update --manifest plan.json

Notes:
- `details` is the most important field: be thorough. Cover data sources,
  analysis logic, outputs, and any thresholds or decision criteria.
- `schedule.type` may be "cron", "one_time", or "manual". Schedules are stored
  disabled and start running only after the workflow reaches the "ready" phase.
"""


def _handle_api_error(resp: requests.Response, context: str = "API request") -> None:
    """Handle API error responses with appropriate messages."""
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_data = resp.json()
        # Check for validation errors (syntax/type check failures)
        if "validation_errors" in error_data:
            click.echo("Script validation failed:", err=True)
            for err in error_data["validation_errors"]:
                click.echo(f"  - {err}", err=True)
            raise click.ClickException("Fix the errors above and try again")
        error_msg = error_data.get("error", "Bad request")
        raise click.ClickException(f"{context} failed: {error_msg}")
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"{context} failed: {e}")


def _resolve_token(token: Optional[str]) -> str:
    """Resolve API token from CLI arg, env, or session config."""
    if token:
        return token
    config = load_session_config()
    resolved = config.get("token")
    if not resolved:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")
    return resolved


def _load_manifest(manifest: str) -> tuple[dict[str, Any], Path, Path]:
    """Load a manifest JSON file. Returns (data, path, parent_dir)."""
    manifest_path = Path(manifest)
    try:
        data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid manifest JSON: {e}")
    if not isinstance(data, dict):
        raise click.ClickException("Manifest must be a JSON object")
    if not data.get("name"):
        raise click.ClickException("manifest must include 'name' field")
    return data, manifest_path, manifest_path.parent


def _has_version_content(manifest_data: dict[str, Any]) -> bool:
    """Return True when the manifest carries executable version fields."""
    return bool(manifest_data.get("instruction_file")) or bool(manifest_data.get("scripts"))


def _build_metadata_payload(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Extract metadata fields (name, description, details, schedule) from a manifest.

    Only includes keys that are present and non-empty. Used as the body for both
    POST /workflows and PATCH /workflows/:id.
    """
    payload: dict[str, Any] = {"name": manifest_data["name"]}
    description = manifest_data.get("description")
    if description:
        payload["description"] = description
    details = manifest_data.get("details")
    if details:
        payload["details"] = details
    schedule = manifest_data.get("schedule")
    if schedule:
        payload["schedule"] = schedule
    return payload


def _build_version_payload(manifest_data: dict[str, Any], manifest_dir: Path) -> dict[str, Any]:
    """Read instruction + scripts + subagents from local files and assemble the version body.

    Validates that each script uses the @script decorator and that its schema
    is not too complex. Raises ClickException on any local-file error.
    """
    instruction_file = manifest_data.get("instruction_file")
    if not instruction_file:
        raise click.ClickException("manifest must include 'instruction_file' for publishing a version")

    instruction_path = manifest_dir / instruction_file
    if not instruction_path.exists():
        raise click.ClickException(f"Instruction file not found: {instruction_path}")
    instruction_content = instruction_path.read_text()

    scripts_raw = manifest_data.get("scripts") or []
    if not scripts_raw:
        raise click.ClickException("manifest must include at least one script for publishing a version")

    scripts: list[dict[str, Any]] = []
    for script in scripts_raw:
        if "name" not in script or "description" not in script or "file_path" not in script:
            raise click.ClickException("Each script must have 'name', 'description', and 'file_path'")

        script_path = manifest_dir / script["file_path"]
        if not script_path.exists():
            raise click.ClickException(f"Script file not found: {script_path}")

        script_content = script_path.read_text()

        module = _load_script_module(str(script_path))
        func = _find_script_function(module)
        if func is None:
            raise click.ClickException(
                f"Script '{script['name']}' ({script['file_path']}) has no @script decorator.\n"
                "All scripts must use the @script decorator pattern."
            )

        input_schema = getattr(func, "_script_schema", {})
        complexity_errors = _validate_schema_complexity(input_schema)
        if complexity_errors:
            error_str = "\n".join(f"  - {e}" for e in complexity_errors)
            raise click.ClickException(f"Script '{script['name']}' has a schema that is too complex:\n{error_str}")

        scripts.append(
            {
                "name": script["name"],
                "description": script["description"],
                "script": script_content,
                "input_schema": input_schema,
            }
        )

    subagents: list[dict[str, Any]] = []
    for sa in manifest_data.get("subagents", []):
        if "name" not in sa or "processing_guide_file" not in sa:
            raise click.ClickException("Each subagent must have 'name' and 'processing_guide_file'")
        guide_path = manifest_dir / sa["processing_guide_file"]
        if not guide_path.exists():
            raise click.ClickException(f"Processing guide not found: {guide_path}")
        subagents.append({"name": sa["name"], "processing_guide": guide_path.read_text()})

    return {
        "instruction": instruction_content,
        "scripts": scripts,
        "subagents": subagents,
        "built_in_tools": manifest_data.get("built_in_tools", ["save_report"]),
        "inputs": manifest_data.get("inputs", []),
    }


def _post_create_workflow(base_url: str, headers: dict[str, str], payload: dict[str, Any]) -> str:
    """Call POST /workflows. Returns the new workflow_id."""
    try:
        resp = requests.post(f"{base_url}/workflows", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Workflow creation")
    return resp.json()["workflow_id"]


def _patch_workflow(
    base_url: str, headers: dict[str, str], workflow_id: str, payload: dict[str, Any]
) -> dict[str, Any]:
    """Call PATCH /workflows/:id. Returns the response JSON."""
    try:
        resp = requests.patch(f"{base_url}/workflows/{workflow_id}", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found.")
    _handle_api_error(resp, "Workflow update")
    return resp.json()


def _post_workflow_version(
    base_url: str, headers: dict[str, str], workflow_id: str, payload: dict[str, Any]
) -> dict[str, Any]:
    """Call POST /workflows/:id/versions. Returns the response JSON."""
    try:
        resp = requests.post(
            f"{base_url}/workflows/{workflow_id}/versions", headers=headers, json=payload, timeout=60
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found. Remove 'id' from manifest to create new.")
    _handle_api_error(resp, "Version creation")
    return resp.json()


def _write_id_to_manifest(manifest_path: Path, manifest_data: dict[str, Any], workflow_id: str) -> None:
    """Persist the workflow_id back to the manifest file."""
    manifest_data["id"] = workflow_id
    manifest_path.write_text(json.dumps(manifest_data, indent=2))


@main.group("workflow")
def workflow_group() -> None:
    """Manage workflows (create, update, publish)."""
    pass


workflow_group.help = WORKFLOW_GROUP_HELP


_WORKFLOW_CREATE_HELP = """Create a new workflow from a manifest file.

The manifest must NOT include an 'id' field (the id is written back after creation).
Required: 'name'. Optional: 'description', 'details', 'schedule', and version fields
('instruction_file' + 'scripts' and friends).

Behavior:
- If the manifest has version content, a first version is published in the same call.
- If it only has metadata (e.g. 'details'+'schedule'), a draft workflow is created.

On success, the new 'id' is written back to the manifest file for future
`agentberlin workflow update` / `workflow publish` calls.

See `agentberlin workflow --help` for the full manifest format reference.
"""


@workflow_group.command("create", help=_WORKFLOW_CREATE_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_create(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, manifest_path, manifest_dir = _load_manifest(manifest)

    if manifest_data.get("id"):
        raise click.ClickException(
            "manifest already has an 'id'. Use `agentberlin workflow update` or "
            "`agentberlin workflow publish` instead."
        )

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    # Validate version payload up front (before creating any remote state) so that
    # local file errors don't leave a dangling empty workflow behind.
    version_payload: Optional[dict[str, Any]] = None
    if _has_version_content(manifest_data):
        version_payload = _build_version_payload(manifest_data, manifest_dir)

    metadata_payload = _build_metadata_payload(manifest_data)
    workflow_id = _post_create_workflow(base_url, headers, metadata_payload)
    _write_id_to_manifest(manifest_path, manifest_data, workflow_id)
    click.echo(f"Created workflow: {manifest_data['name']} ({workflow_id})")

    if version_payload is not None:
        result = _post_workflow_version(base_url, headers, workflow_id, version_payload)
        click.echo(f"Version {result['version_number']} created ({result['version_id']})")


_WORKFLOW_UPDATE_HELP = """Update metadata of an existing workflow.

Requires the manifest to have an 'id' field. Sends any of the following fields
present in the manifest: 'name', 'description', 'details', 'schedule'.

Does NOT create a new version. To publish a new version (instruction + scripts),
use `agentberlin workflow publish`.
"""


@workflow_group.command("update", help=_WORKFLOW_UPDATE_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_update(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, _, _ = _load_manifest(manifest)

    workflow_id = manifest_data.get("id")
    if not workflow_id:
        raise click.ClickException(
            "manifest must include 'id'. Use `agentberlin workflow create` for new workflows."
        )

    # PATCH payload is a subset of the metadata payload (name is always present but
    # is applied idempotently by the backend).
    payload = _build_metadata_payload(manifest_data)
    if len(payload) == 1 and "name" in payload:
        # Only `name` — allow; backend will still apply it. But if the manifest has
        # no details/description/schedule at all, warn the user they may have meant publish.
        pass

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _patch_workflow(base_url, headers, workflow_id, payload)
    click.echo(f"Workflow updated: {result.get('name', manifest_data['name'])} ({workflow_id})")
    phase = result.get("phase")
    if phase:
        click.echo(f"Phase: {phase}")


_WORKFLOW_PUBLISH_HELP = """Publish a new version of an existing workflow.

Requires the manifest to have an 'id' field. Reads 'instruction_file', 'scripts',
'subagents', 'built_in_tools', and 'inputs' from the manifest. Does NOT touch
metadata (name, description, details, schedule) — use `workflow update` for that.
"""


@workflow_group.command("publish", help=_WORKFLOW_PUBLISH_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_publish(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, _, manifest_dir = _load_manifest(manifest)

    workflow_id = manifest_data.get("id")
    if not workflow_id:
        raise click.ClickException(
            "manifest must include 'id'. Use `agentberlin workflow create` for new workflows."
        )

    payload = _build_version_payload(manifest_data, manifest_dir)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _post_workflow_version(base_url, headers, workflow_id, payload)
    click.echo(f"Version {result['version_number']} created ({result['version_id']})")


def _load_script_module(script_path: str) -> Any:
    """Dynamically load a Python script as a module.

    Args:
        script_path: Path to the Python script file.

    Returns:
        The loaded module object.

    Raises:
        click.ClickException: If the script cannot be loaded.
    """
    path = Path(script_path)
    if not path.exists():
        raise click.ClickException(f"Script not found: {script_path}")

    if not path.suffix == ".py":
        raise click.ClickException(f"Script must be a Python file (.py): {script_path}")

    spec = importlib.util.spec_from_file_location("_script_module", path)
    if spec is None or spec.loader is None:
        raise click.ClickException(f"Failed to load script: {script_path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules["_script_module"] = module

    try:
        spec.loader.exec_module(module)
    except Exception as e:
        raise click.ClickException(f"Failed to execute script: {e}")

    return module


def _find_script_function(module: Any) -> Optional[Callable[..., Any]]:
    """Find the function decorated with @script in a module.

    Args:
        module: The module to search.

    Returns:
        The decorated function, or None if not found.
    """
    script_funcs: list[Callable[..., Any]] = []

    for name in dir(module):
        obj = getattr(module, name)
        if callable(obj) and getattr(obj, "_is_script", False):
            script_funcs.append(obj)

    if len(script_funcs) == 0:
        return None
    if len(script_funcs) > 1:
        names = ", ".join(f.__name__ for f in script_funcs)
        raise click.ClickException(f"Multiple @script decorators found: {names}. Only one is allowed per script.")

    return script_funcs[0]


def _get_max_depth(schema: dict[str, Any], current_depth: int = 0) -> int:
    """Calculate the maximum nesting depth of a JSON schema.

    Args:
        schema: The JSON schema to analyze.
        current_depth: Current depth in the traversal.

    Returns:
        The maximum nesting depth.
    """
    max_depth = current_depth

    # Check properties (object nesting)
    if "properties" in schema:
        for prop_schema in schema["properties"].values():
            if isinstance(prop_schema, dict):
                prop_depth = _get_max_depth(prop_schema, current_depth + 1)
                max_depth = max(max_depth, prop_depth)

    # Check array items
    if "items" in schema and isinstance(schema["items"], dict):
        items_depth = _get_max_depth(schema["items"], current_depth + 1)
        max_depth = max(max_depth, items_depth)

    # Check additionalProperties (for dict types)
    if "additionalProperties" in schema and isinstance(schema["additionalProperties"], dict):
        add_props_depth = _get_max_depth(schema["additionalProperties"], current_depth + 1)
        max_depth = max(max_depth, add_props_depth)

    return max_depth


def _has_recursive_refs(schema: dict[str, Any], seen_refs: Optional[set[str]] = None) -> bool:
    """Check if a schema has recursive type definitions.

    Args:
        schema: The JSON schema to check.
        seen_refs: Set of refs already seen in this path.

    Returns:
        True if recursive refs are found.
    """
    if seen_refs is None:
        seen_refs = set()

    # Check for $ref
    if "$ref" in schema:
        ref = schema["$ref"]
        if ref in seen_refs:
            return True
        seen_refs = seen_refs | {ref}

    # Recursively check nested schemas
    for key in ["properties", "items", "additionalProperties"]:
        if key in schema:
            value = schema[key]
            if isinstance(value, dict):
                if key == "properties":
                    for prop_schema in value.values():
                        if isinstance(prop_schema, dict):
                            if _has_recursive_refs(prop_schema, seen_refs):
                                return True
                else:
                    if _has_recursive_refs(value, seen_refs):
                        return True

    return False


def _validate_schema_complexity(schema: dict[str, Any]) -> list[str]:
    """Validate that a schema isn't too complex for LLMs.

    Checks:
    - Maximum nesting depth of 2 levels
    - No recursive type definitions
    - Reasonable parameter count (max 10)

    Args:
        schema: The JSON schema to validate.

    Returns:
        List of error messages. Empty if valid.
    """
    errors: list[str] = []

    # Rule 1: Max nesting depth of 2 levels
    max_depth = _get_max_depth(schema)
    if max_depth > 2:
        errors.append(
            f"Schema nesting depth is {max_depth}, max allowed is 2. "
            "Flatten your parameters - use simple types (str, int, bool, list[str]) "
            "instead of nested dicts."
        )

    # Rule 2: No recursive types
    if _has_recursive_refs(schema):
        errors.append("Recursive type definitions are not supported by LLMs.")

    return errors


@main.command(name="extract-schema")
@click.argument("script_path", type=click.Path(exists=True))
def extract_schema(script_path: str) -> None:
    """Extract the JSON schema from a @script-decorated function.

    SCRIPT_PATH is the path to the Python script file.

    This command loads the script, finds the @script decorated function,
    and outputs its parameter schema as JSON to stdout.

    Exit codes:
        0: Success
        1: No @script decorator found (legacy script)
        2: Multiple @script decorators found
        3: Schema validation failed (too complex)
    """
    module = _load_script_module(script_path)
    func = _find_script_function(module)

    if func is None:
        click.echo(
            "ERROR: No @script decorator found in this script.\n\n"
            "This script uses the legacy INPUT variable pattern which is no longer supported.\n\n"
            "REQUIRED ACTION: This workflow/agent must be upgraded before execution.\n"
            "DO NOT attempt to run this workflow. Instead, upgrade it to use the @script decorator pattern.\n\n"
            "Example of required format:\n"
            "  from agentberlin import AgentBerlin, script\n\n"
            "  @script\n"
            "  def main(param1: str, param2: int = 10):\n"
            "      # script logic\n",
            err=True,
        )
        raise SystemExit(1)

    schema = getattr(func, "_script_schema", {})

    # Validate schema complexity
    complexity_errors = _validate_schema_complexity(schema)
    if complexity_errors:
        click.echo("ERROR: Schema is too complex for LLM tools:\n", err=True)
        for err in complexity_errors:
            click.echo(f"  - {err}", err=True)
        click.echo(
            "\nSimplify your function parameters to use basic types " "(str, int, float, bool, list[str]).",
            err=True,
        )
        raise SystemExit(3)

    # Output schema as JSON
    click.echo(json.dumps(schema, indent=2))


@main.command()
@click.argument("script_path", type=click.Path(exists=True))
@click.option(
    "--input",
    "-i",
    "input_json",
    help="Inline JSON string with input parameters (for simple inputs)",
)
@click.option(
    "--input-file",
    "-f",
    "input_file",
    type=click.Path(exists=True),
    help="Path to JSON file with input parameters (for complex/large inputs)",
)
def run(script_path: str, input_json: Optional[str], input_file: Optional[str]) -> None:
    """Execute a @script-decorated Python function from a workflow.

    SCRIPT_PATH is the path to the Python script file.

    \b
    Logging:
      On startup, prints the log file path: [LOG] ~/.agentberlin/logs/<run_id>.log
      Scripts can write progress via the log() function from agentberlin.
      For long-running operations, monitor progress by reading or tailing this file:
        tail -f <log_path>

    \b
    Input options (use one or neither):
      --input, -i     Inline JSON string (e.g., --input '{"url": "example.com"}')
      --input-file, -f  Path to JSON file (e.g., --input-file params.json)

    Use --input for simple parameters, --input-file for complex or large inputs.

    \b
    Exit codes:
        0: Success
        1: No @script decorator found
        2: Execution error
    """
    if input_json and input_file:
        raise click.ClickException("Cannot use both --input and --input-file")

    module = _load_script_module(script_path)
    func = _find_script_function(module)

    if func is None:
        click.echo(
            "ERROR: This script uses the legacy INPUT variable pattern which is no longer supported.\n\n"
            "REQUIRED ACTION: This workflow/agent must be upgraded before execution.\n"
            "DO NOT attempt to run this workflow. Instead, upgrade it to use the @script decorator pattern.\n\n"
            "Example of required format:\n"
            "  from agentberlin import AgentBerlin, script\n\n"
            "  @script\n"
            "  def main(param1: str, param2: int = 10):\n"
            "      # script logic\n",
            err=True,
        )
        raise SystemExit(1)

    # Parse input if provided (from --input or --input-file)
    kwargs: dict[str, Any] = {}
    if input_json:
        try:
            kwargs = json.loads(input_json)
        except json.JSONDecodeError as e:
            raise click.ClickException(f"Invalid JSON in --input: {e}")
        if not isinstance(kwargs, dict):
            raise click.ClickException("Input JSON must be an object (dict)")
    elif input_file:
        try:
            with open(input_file) as f:
                kwargs = json.load(f)
        except json.JSONDecodeError as e:
            raise click.ClickException(f"Invalid JSON in input file: {e}")
        except Exception as e:
            raise click.ClickException(f"Failed to read input file: {e}")
        if not isinstance(kwargs, dict):
            raise click.ClickException("Input JSON must be an object (dict)")

    # Set up logging for the run
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + secrets.token_hex(2)
    log_dir = Path.home() / ".agentberlin" / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{run_id}.log"

    # Set the log path environment variable for the log() function
    os.environ["AGENTBERLIN_LOG_PATH"] = str(log_path)

    # Print the log path so agents can monitor progress
    click.echo(f"[LOG] {log_path}")

    # Execute the function
    try:
        func(**kwargs)
    except TypeError as e:
        # Handle missing required arguments or unexpected arguments
        raise click.ClickException(f"Argument error: {e}")
    except Exception as e:
        click.echo(f"Script execution failed: {e}", err=True)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
