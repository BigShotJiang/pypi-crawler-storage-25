<!-- @scry.entry
id: design.primitives-auto-rollback~4dca458f
kind: design
status: active
weight: 0.85
tags:
  - "scope:substrate"
  - "topic:primitives"
  - "topic:auto-rollback"
  - "auto-rollback"
  - "topic:self-modification"
  - "self-modification"
  - "topic:safety"
  - "safety"
summary: >
  Auto-rollback primitive: safety net for self-modification. The
  bin/reflect-wake shim smoke-tests the runtime import before each
  wake; on failure it reverts agent/runtime/ to the
  reflect/last-known-good git ref and retries. Works without human
  intervention. Pattern: sandbox-then-promote — modify in a worktree,
  test, merge, advance the ref. Also: auto-rollback, last-known-good,
  rollback ref, self-modification, smoke test, sandbox-then-promote,
  reflect-wake shim, wake shim, git ref, runtime safety.
rationale: >
  Without this, self-modification has no safety net. If a wake ships a
  broken runtime import, the next wake crashes with no recovery path.
  This doc explains both how the rollback fires and what the agent must
  do (advance the ref after promotion) to keep the guarantee current.
applies: >
  modifying agent/runtime/ files, shipping self-modifications, debugging
  wake startup failures, understanding why bin/reflect-wake is off-limits
seeded_questions:
  - "How does auto-rollback work in reflect?"
  - "What is reflect/last-known-good?"
  - "How do I advance the rollback ref after a self-modification?"
  - "sandbox-then-promote pattern"
  - "What does the reflect-wake shim do?"
@scry.entry.end -->

# Auto-rollback

The auto-rollback mechanism is a safety net for self-modification. When a wake
ships a broken runtime, the next invocation detects the failure, reverts to the
last known-good state, and retries — without human intervention.

## How it works

`bin/reflect-wake` is a Bash shim that runs before the Python runtime boots:

```
bin/reflect-wake
  └── runs smoke test: uv run python -c "from agent.runtime.wake import main"
       ├── PASS → boot the wake normally via exec uv run reflect-wake
       └── FAIL → rollback agent/runtime/ to reflect/last-known-good, retry once
                   ├── retry PASS → continue with restored runtime
                   └── retry FAIL → exit 1, manual intervention required
```

The shim is intentionally small and lives outside the Python runtime so it
survives the failure modes it's guarding against.

## The smoke test

```bash
uv run python -c "from agent.runtime.wake import main"
```

Import only — no side effects. Catches NameError, ImportError, SyntaxError, and
any module-level exception. Does not test behavior or runtime logic.

**What it catches:** broken self-modifications to `agent/runtime/` — bad merges,
syntax errors from mid-wake edits, NameError from removed constants.

**What it doesn't catch:** runtime bugs that only surface during execution (logic
errors, bad API calls, tool contract violations). Those are caught by normal wake
failure and reported in the wake's transcript.

## reflect/last-known-good

A git ref (branch tip or commit hash) marking the last confirmed-good state of
`agent/runtime/`. The rollback command:

```bash
git checkout reflect/last-known-good -- agent/runtime/
```

This restores only `agent/runtime/` — not the full tree. Other changes are
untouched.

**The ref must be advanced manually after every promoted self-modification:**

```bash
git branch -f reflect/last-known-good HEAD
```

If the ref is never advanced, rollback always reverts to the project's initial
state. If the ref doesn't exist, rollback fails with a clear error and exits 1.

## Self-modification pattern (sandbox-then-promote)

Wakes that modify `agent/runtime/` follow a three-phase pattern:

1. **Sandbox** — create a git worktree on a fresh branch:
   ```bash
   git worktree add agent/runtime/.sandbox-<wake_id> -b reflect/sandbox-<wake_id>
   ```

2. **Test** — smoke the modified files inside the sandbox:
   ```bash
   python -m py_compile <files>
   uv run python -c "from agent.runtime.X import ..."
   uv run pytest
   ```

3. **Promote** — merge, advance the ref, clean up:
   ```bash
   git merge reflect/sandbox-<wake_id> --no-ff
   git branch -f reflect/last-known-good HEAD
   git worktree remove agent/runtime/.sandbox-<wake_id>
   ```

Self-promoted changes take effect on the **next** wake — loaded code doesn't
reload mid-wake. This is intentional: the blast radius of a bad self-modification
is bounded to the current wake, not the current session.

## Off-limits to direct edit

`bin/reflect-wake` is not writable by the agent. The permission gate blocks writes
to it. Modifying the shim defeats the rollback path — the shim is the safety net,
not the thing it's saving.

Proposed changes to the shim surface via `agent/inbox/` to the originator for
manual execution.

## Failure modes

| Scenario | What happens |
|----------|--------------|
| Bad `agent/runtime/` edit | Smoke fails → rollback restores last-known-good → retry succeeds |
| Bad edit + bad rollback ref | Rollback fails → exit 1 → originator intervenes |
| Post-rollback smoke fails | exit 1 → "manual intervention needed" printed to stderr |
| Shim modified by agent | Permission gate denies the write — cannot happen |

## Related primitives

- [[wakes]] — the thing being protected; self-modification is normal wake work
- [[hooks]] — permission gate that prevents direct edits to `bin/reflect-wake`
