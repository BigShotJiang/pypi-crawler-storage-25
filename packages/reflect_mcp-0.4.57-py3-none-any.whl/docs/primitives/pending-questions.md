<!-- @scry.entry
id: design.pending-questions-primitive~a79f69c6
kind: design
status: active
weight: 0.85
tags:
  - "topic:runtime"
  - "runtime"
  - "topic:pending-question"
  - "pending-question"
  - "topic:ask-tool"
  - "ask-tool"
  - "scope:substrate"
  - "substrate"
  - "topic:wake-primitive"
  - "wake-primitive"
summary: >
  The pending-questions primitive: a per-track directory of durable
  YAML question records an agent poses to the originator. Each record
  carries the verbatim question, an answer-to-action map, context
  needed to act without re-derivation, and a staleness expiry. Replies
  bind to records by ID so the consuming wake acts from full context
  without re-deriving. Motivated by the crimes-editor incident where a
  bare "y" reply cost 380s / $1.89 in re-derivation.
  Also: pending-questions directory, ask tool, question record, YAML
  schema, answer_map, reply binding, orphaned reply, staleness, DR1,
  DR2, DR4, DR5, DR7, DR8, pending question primitive.
rationale: >
  Without this, a question an agent poses lives only in wake memory.
  When the wake ends (by budget, by interrupt, by crash), a later reply
  arrives as a bare inbox message with no binding context. The consuming
  wake must re-derive the entire problem from scratch. This primitive
  makes the question durable, survives wake boundaries, and surfaces
  open questions in the briefing so every wake orients correctly.
applies: >
  posing questions to the originator from an autonomous wake, reading
  pending-questions directory layout, implementing ask tool consumers,
  orienting to open blocking questions, diagnosing orphaned reply
  incidents, adding reply-binding logic to inbox sweep
seeded_questions:
  - "How does a wake pose a durable question to the originator?"
  - "What is the pending-questions directory?"
  - "pending-questions YAML schema"
  - "ask tool record format"
  - "How do I avoid re-deriving orphaned replies?"
  - "What is the answer_map field?"
  - "pending-questions directory layout"
depends_on:
  - "design.pending-question-mechanism~bd8fade7"
@scry.entry.end -->

# Primitive: pending-questions

## Purpose

Agents in autonomous wakes sometimes need an answer from the originator
before proceeding. The pending-questions primitive makes that question
durable: it exists on disk across wake boundaries, surfaces in the
briefing so future wakes are oriented, and eventually receives a reply
that binds by ID rather than arriving as bare context-free text.

## Directory layout

```
agent/runtime/tracks/{track}/
  pending-questions/
    {ISO-timestamp}-{slug}.yaml   ← open questions
    .resolved/
      {ISO-timestamp}-{slug}.yaml ← resolved or expired (archive)
```

The directory is NOT created eagerly. It appears when `ask` is first
called. The briefing-builder no-ops when the directory is absent.

## YAML schema

```yaml
id: {slug}~{8-hex}       # slug from first 5 question words; hex = UUID v4 truncated
track: {track-name}
created_at: "ISO"
expires_at: "ISO"        # created_at + 48h default (staleness threshold)
question: >
  <verbatim question text>
context:
  blocked_work: "<one-line description of what is blocked>"
  # arbitrary key-value pairs — agent populates what the
  # consuming wake needs to act without re-derivation
answer_map:
  "y": "<action string if answer is y>"
  "n": "<action string if answer is n>"
  # keys must exactly match the tokens the originator will send
status: open             # open | resolved | expired
reply: null              # populated when resolved
resolved_at: null        # ISO timestamp when resolved
```

## Writing a record

Use the `mcp__reflect-wake__ask` tool from within an autonomous wake.
The tool writes the record atomically (temp → rename) and returns the
record ID and path. The agent can then sleep cleanly — the question
persists.

Do NOT write question records manually via `Write`. The atomicity
guarantee (DR1) requires the write to happen inside the tool contract.

## Briefing integration

`build_briefing_body()` includes a **Pending Replies** section when
`pending-questions/` has any open (non-resolved) records:

```
## Pending Replies

- {id} ({created_at}, expires {expires_at})
  "{question}"
  answers: {answer_map keys joined by " / "}
  blocked: "{context.blocked_work}"
  → Reply arrives via inbox (kind:reply, subject:{id}) or session
    interrupt. Do not re-derive this decision.
```

Expired records (past `expires_at`) surface with a `[EXPIRED]` marker
and a prompt to re-surface or escalate (DR8).

## Closing a record

When a reply arrives and the work is complete, move the record to
`.resolved/`. Do not delete it — the resolved archive is the audit
record.

The `reflect question resolve` CLI (Phase 3) will handle this
automatically. Until then, move manually via Bash or the consuming
wake's Write/Edit surface.

## Design reference

Full design rationale, incident analysis, and phase roadmap:
[agent/design/design.pending-question-mechanism~bd8fade7.md](
../../agent/design/design.pending-question-mechanism~bd8fade7.md)
