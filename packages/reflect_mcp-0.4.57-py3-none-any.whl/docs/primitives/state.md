<!-- @scry.entry
id: design.primitives-state~b851e931
kind: design
status: active
weight: 0.85
tags:
  - "scope:substrate"
  - "topic:primitives"
  - "topic:state"
  - "state"
  - "topic:storage"
  - "storage"
  - "topic:scry"
  - "scry"
summary: >
  State storage strategies primitive: the where-does-state-go? decision
  rule for reflection. Three mechanisms by lifecycle — scry markers
  (source-tracked, committed, slow-changing knowledge), scratch sqlite
  (volatile, gitignored, high-frequency operational state), and markdown
  docs with scry markers (default). Decision rule: git history? → scry.
  >10 writes/day? → sqlite. Neither? → doc with marker. Also: state
  storage, storage policy, where state goes, scry vs sqlite vs markdown,
  storage decision rule, knowledge graph, state.db, @scry.entry, state
  strategies.
rationale: >
  Without this, wakes reach for the wrong store (e.g. scry for telemetry,
  or markdown for high-frequency counters). The three-mechanism model and
  the decision rule prevent that drift.
applies: >
  deciding where to persist new data, scoping a feature that needs
  storage, reviewing storage architecture, creating new state files
seeded_questions:
  - "Where should reflection store high-frequency state?"
  - "When to use scry vs sqlite vs markdown?"
  - "What is the state storage decision rule?"
  - "storage strategies for reflect"
  - "state.db vs scry"
@scry.entry.end -->

# State storage strategies

> **Scope:** This doc covers the *where-does-state-go?* decision across three
> storage mechanisms. It does NOT cover per-track runtime state
> (`core.state.yaml`) — that is a separate primitive.

Reflection tracks state across wakes using three mechanisms:

## 1. Scry markers (`@scry.entry`)

Source-tracked, committed. Long-lived knowledge — designs, lessons, milestones,
patterns. Queryable via `scry_sql`. All marker IDs minted via `scry_mint`.

## 2. Scratch sqlite (`agent/runtime/state.db`)

Volatile, gitignored. High-frequency operational state — wake metrics,
cached research, telemetry. >10 writes/day goes here.

## 3. Markdown docs with `@scry.entry` marker

The default when unsure. Cheap, trackable, easy to migrate to sqlite later.

## Decision rule

- Want git history? → scry/doc
- >10 writes/day? → sqlite
- Both? → split (design doc in scry, telemetry in sqlite)
- Neither? → doc with marker

## Related primitives

- [[tracks]] — `core.state.yaml` per-track state lives in track directories
- [[wakes]] — wakes read and write state across all three mechanisms
