"""Pure track operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

import os
import re
import string as _string_module
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from agent.cli.ops.root import resolve_project_root


# ── helpers ────────────────────────────────────────────────────────────────


def _effective_tracks_dir(tracks_dir: Optional[Path] = None) -> Path:
    # Resolve lazily at call time so the MCP server (started from an arbitrary
    # cwd) always finds the correct project root via REFLECT_PROJECT env or cwd
    # walk-up, rather than baking in the startup-time cwd.
    return tracks_dir if tracks_dir is not None else resolve_project_root() / "agent" / "runtime" / "tracks"


# Module-level export for CLI callers that resolve at startup time (dashboard,
# inbox, etc.).  MCP functions use _effective_tracks_dir() directly for
# per-call lazy resolution.
TRACKS_DIR: Path = _effective_tracks_dir()


def _is_pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_lock_pid(lock_path: Path) -> Optional[int]:
    try:
        content = lock_path.read_text().strip()
        for line in content.splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except (OSError, ValueError):
        pass
    return None


def _lazy_reap_lock(lock_path: Path, track_name: str) -> bool:
    """Reap an orphaned wake.lock in-place.  Returns True if the lock was reaped.

    Safe for concurrent callers — the OSError/FileNotFoundError on unlink is
    caught and treated as "someone else beat us; that's fine."
    """
    try:
        lock_path.unlink()
        # Emit track.recovered event (best-effort; mirrors dispatcher semantics)
        try:
            from agent.runtime.events import emit_event as _emit, set_runtime_root as _srt
            _srt(resolve_project_root() / "agent" / "runtime")
            _emit("track.recovered", track=track_name, wake_id="orphan-reap", payload={
                "reason": "lazy_reap_on_read",
            })
        except Exception:
            pass
        return True
    except OSError:
        return False  # race: dispatcher (or another reader) beat us — fine


def _resolve_dispatcher_state(track_dir: Path) -> str:
    """Return cron-dispatch eligibility: 'enabled' | 'disabled'."""
    return "disabled" if (track_dir / "disabled.flag").exists() else "enabled"


def _resolve_runtime_state(track_dir: Path) -> str:
    """Return live wake activity: 'running' | 'paused' | 'idle'.

    Orphaned locks are reaped in-place. Does not inspect disabled.flag —
    a disabled track can still have an active wake if one was started manually.
    """
    lock_path = track_dir / "wake.lock"
    if not lock_path.exists():
        return "idle"

    lock_pid = _read_lock_pid(lock_path)
    if lock_pid is not None:
        if _is_pid_alive(lock_pid):
            if (track_dir / "pause.requested").exists():
                return "paused"
            return "running"
        # Dead PID — orphan; reap and fall through to idle
        _lazy_reap_lock(lock_path, track_dir.name)
        return "idle"

    # Lock exists but PID unreadable — treat conservatively: if file has
    # content assume something is running; if empty treat as orphan and reap.
    try:
        if lock_path.stat().st_size > 0:
            return "running"
    except OSError:
        pass
    _lazy_reap_lock(lock_path, track_dir.name)
    return "idle"


def _resolve_track_state(track_dir: Path) -> str:
    """Return canonical composite track state with lazy orphan-lock reaping.

    Combines dispatcher state (enabled/disabled) with runtime state
    (idle/running/paused). Possible values:

      'running' | 'paused' | 'idle'              — enabled track
      'disabled'                                  — disabled, no active wake
      'disabled · running' | 'disabled · paused' — disabled but wake is live
                                                    (manual wake start on a
                                                    disabled track)
    """
    dispatcher = _resolve_dispatcher_state(track_dir)
    runtime = _resolve_runtime_state(track_dir)
    if dispatcher == "disabled" and runtime != "idle":
        return f"disabled · {runtime}"
    if dispatcher == "disabled":
        return "disabled"
    return runtime


def _fmt_ts(ts: Optional[int]) -> str:
    if ts is None:
        return "-"
    dt = datetime.fromtimestamp(ts, tz=timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%MZ")


def _humanize_delta(seconds: int) -> str:
    """Return compact multi-unit duration string, e.g. '6d23h', '1h30m', '45s'.

    Rules: non-zero units only, largest → smallest, no separators, no decimals.
    Display math: 30d/mo, 365d/y (cosmetic only).
    """
    if seconds <= 0:
        return "0s"
    parts = []
    remaining = seconds
    years = remaining // (365 * 86400)
    if years:
        parts.append(f"{years}y")
        remaining %= 365 * 86400
    months = remaining // (30 * 86400)
    if months:
        parts.append(f"{months}mo")
        remaining %= 30 * 86400
    days = remaining // 86400
    if days:
        parts.append(f"{days}d")
        remaining %= 86400
    hours = remaining // 3600
    if hours:
        parts.append(f"{hours}h")
        remaining %= 3600
    minutes = remaining // 60
    if minutes:
        parts.append(f"{minutes}m")
        remaining %= 60
    if remaining:
        parts.append(f"{remaining}s")
    return "".join(parts) or "0s"


# ── public ops ─────────────────────────────────────────────────────────────


def list_tracks(tracks_dir: Optional[Path] = None) -> list[str]:
    """Return sorted list of track names."""
    td = _effective_tracks_dir(tracks_dir)
    if not td.exists():
        return []
    return sorted(
        d.name for d in td.iterdir() if d.is_dir() and not d.name.startswith(".")
    )


def get_track_state(name: str, tracks_dir: Optional[Path] = None) -> dict:
    """Return full state dict for a track.

    Keys: name, state, last_wake, last_wake_fmt, last_wake_start,
          last_wake_start_fmt, unread_count, lock_pid
    Returns {"error": reason} if track not found.
    """
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name

    if not track_dir.exists():
        return {"error": f"Track '{name}' not found"}

    dispatcher_state = _resolve_dispatcher_state(track_dir)
    runtime_state = _resolve_runtime_state(track_dir)
    # Composite state: combines both axes for display.
    if dispatcher_state == "disabled" and runtime_state != "idle":
        state = f"disabled · {runtime_state}"
    elif dispatcher_state == "disabled":
        state = "disabled"
    else:
        state = runtime_state

    # Re-read lock_pid for the returned dict (informational only; state already resolved).
    lock_path = track_dir / "wake.lock"
    lock_pid: Optional[int] = None
    if lock_path.exists():
        lock_pid = _read_lock_pid(lock_path)

    last_wake: Optional[int] = None
    try:
        last_wake = int((track_dir / "last-wake.timestamp").read_text().strip())
    except (OSError, ValueError):
        pass

    last_wake_start: Optional[int] = None
    try:
        last_wake_start = int((track_dir / "last-wake-start.timestamp").read_text().strip())
    except (OSError, ValueError):
        pass

    # P9 (unified inbox): inbox/ is the single mailbox; .consumed/ archives read messages.
    inbox_dir = track_dir / "inbox"
    consumed_dir = inbox_dir / ".consumed"
    unread_count = 0
    if inbox_dir.exists():
        all_md = set(p.name for p in inbox_dir.glob("*.md"))
        consumed_md: set[str] = set()
        if consumed_dir.exists():
            consumed_md = set(p.name for p in consumed_dir.glob("*.md"))
        unread_count = len(all_md - consumed_md)

    # Backlog: pending inbox + pending followup
    # P9: followup/ is now a sibling of inbox/, not nested inside it.
    pending_originator = unread_count  # alias for clarity in backlog calc
    followup_dir = track_dir / "followup"       # P9: sibling to inbox/
    completed_dir = followup_dir / ".completed"
    pending_followup = 0
    if followup_dir.exists():
        all_followup = set(p.name for p in followup_dir.glob("*.md"))
        completed_followup: set[str] = set()
        if completed_dir.exists():
            completed_followup = set(p.name for p in completed_dir.glob("*.md"))
        pending_followup = len(all_followup - completed_followup)
    backlog = pending_originator + pending_followup

    # next-wake-by timestamp
    next_wake_by: Optional[int] = None
    next_wake_by_fmt = "-"
    next_wake_by_delta = "-"
    try:
        raw = (track_dir / "next-wake-by.timestamp").read_text().strip()
        next_wake_by = int(raw)
        next_wake_by_fmt = _fmt_ts(next_wake_by)
        import time as _time
        delta = next_wake_by - int(_time.time())
        if delta <= 0:
            next_wake_by_delta = "immediate / past"
        else:
            next_wake_by_delta = _humanize_delta(delta)
    except (OSError, ValueError):
        pass

    return {
        "name": name,
        "state": state,                    # composite: e.g. "disabled · running"
        "dispatcher_state": dispatcher_state,  # "enabled" | "disabled"
        "runtime_state": runtime_state,        # "idle" | "running" | "paused"
        "last_wake": last_wake,
        "last_wake_fmt": _fmt_ts(last_wake),
        "last_wake_start": last_wake_start,
        "last_wake_start_fmt": _fmt_ts(last_wake_start),
        "unread_count": unread_count,
        "lock_pid": lock_pid,
        "pending_originator": pending_originator,
        "pending_followup": pending_followup,
        "backlog": backlog,
        "next_wake_by": next_wake_by,
        "next_wake_by_fmt": next_wake_by_fmt,
        "next_wake_by_delta": next_wake_by_delta,
    }


def enable_track(name: str, tracks_dir: Optional[Path] = None) -> dict:
    """Enable a track. Returns {"ok": bool, "message": str}."""
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name

    if not track_dir.exists():
        return {"ok": False, "message": f"Track '{name}' not found"}

    flag = track_dir / "disabled.flag"
    if flag.exists():
        flag.unlink()
        return {"ok": True, "message": f"Track '{name}' enabled. Dispatcher will fire on next signal."}
    return {"ok": True, "message": f"Track '{name}' was already enabled."}


def disable_track(name: str, tracks_dir: Optional[Path] = None) -> dict:
    """Disable a track. Returns {"ok": bool, "message": str}."""
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name

    if not track_dir.exists():
        return {"ok": False, "message": f"Track '{name}' not found"}

    flag = track_dir / "disabled.flag"
    if not flag.exists():
        flag.touch()
        return {"ok": True, "message": f"Track '{name}' disabled. Dispatcher will skip this track."}
    return {"ok": True, "message": f"Track '{name}' was already disabled."}


# ── template helpers ───────────────────────────────────────────────────────


def _validate_and_format(template_str: str, **kwargs: object) -> str:
    """Format *template_str* with *kwargs*, raising ValueError on missing fields.

    Extra kwargs are silently accepted (compatible with templates that only
    use a subset of available variables, e.g. the legacy blank/security-audit
    templates that only reference {name}).
    """
    formatter = _string_module.Formatter()
    required: set[str] = set()
    for _, field_name, _, _ in formatter.parse(template_str):
        if field_name is not None:
            root = re.split(r"[.\[]", field_name)[0]
            if root:
                required.add(root)
    missing = required - set(kwargs.keys())
    if missing:
        raise ValueError(
            f"Template requires variables not provided: {sorted(missing)}"
        )
    return template_str.format(**kwargs)


def _template_uses_project(template_str: str) -> bool:
    """Return True if *template_str* uses {project} as a format field."""
    formatter = _string_module.Formatter()
    for _, field_name, _, _ in formatter.parse(template_str):
        if field_name is not None:
            root = re.split(r"[.\[]", field_name)[0]
            if root == "project":
                return True
    return False


# ── track templates ─────────────────────────────────────────────────────────

_TRACK_TEMPLATE_BLANK = """\
# Track: {name}

## What this track IS

Describe what this track IS in positive terms — the expertise or role it holds,
not the task it is doing right now. Cold-readable: a fresh wake with zero prior
context understands the track's purpose from this section alone.

## Authority

Decides on its own (no approval needed):
- (...)

Surfaces rather than decides:
- (...)

## Scope

- Operates on: (what files / systems this track touches)

## How this track works

The ordered steps this track follows each wake. Anchor in the track's primitives —
the core nouns its work composes from.

## Objectives

- (what this track is currently working toward)

## Posture

How committed vs. hedged this track's output should be. Default: commit — state
findings and decisions directly. Name explicitly where hedging is genuinely warranted.

## How this track fails

Failure modes described from the inside — what the failure looks like while you are
doing it, so a wake recognizes it mid-flight. Not "be thorough" but "the failure is X."

## Operating loop

1. Read the inbox and recent wake reports.
2. (the track's work)
3. Write back what changed.
4. If a message was consumed but the work not completed, file a followup before
   sleeping — a consumed message with no deliverable is work that has disappeared.
5. Sleep.
"""

_TRACK_TEMPLATE_SECURITY_AUDIT = """\
# Track: {name} (security-audit)

## What this track IS

A periodic security-audit track. Reviews code changes, dependency versions, and
runtime config for security issues. Surfaces findings in the track inbox.

## Objectives

- Scan for high/critical CVEs in direct and transitive dependencies
- Review recent commits for injection, auth bypass, or secrets exposure
- Flag deviations from secure-coding baseline in active source files

## Scope

- Operates on: source tree, dependency manifests (package.json, pyproject.toml, etc.)
- Does NOT modify source — findings only; patches are out of scope for this track
"""

# ── auditor templates (7 categories × per-project) ─────────────────────────
#
# Variables: {name}, {project}, {cadence_seconds}, {filter}
# Literal braces in body must be escaped as {{ / }}.

_TRACK_TEMPLATE_SMOKE_TEST_AUDITOR = """\
# Track: {name}

## What this track IS

The **live-UI smoke tester** for the `{project}` project. Each wake it exercises
the project's critical paths via browser fetch, asserts on expected status codes
and content markers, and produces a ranked findings report (top-5 max).

Scope: {filter}.

## Objectives

- Fetch live URLs on critical routes; assert status codes and expected content.
- Rank findings by impact; write top-5 max to:
  `agent/projects/{project}/agent/audits/smoke-test-auditor/<YYYY-MM-DD>.md`
- Push to `{project}`'s *-worker track inbox **only** for high-severity findings
  (e.g., critical route returning 500 in production) — always include rationale.

## Scope

- Operates on: `agent/projects/{project}/` (live URL surface)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# smoke-test-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <URL or path>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was tested vs. not>
```

Hard rule: top-N ≤ 5.

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_SECURITY_AUDITOR = """\
# Track: {name}

## What this track IS

The **security auditor** for the `{project}` project. Each wake it does a static
and heuristic pass — secrets in source, unsafe API patterns, auth flow gaps,
XSS / SQLi / CSRF surfaces, third-party-lib CVEs — and produces a ranked
findings report (top-5 max).

Scope: {filter}.

## Objectives

- Walk `{project}`'s source tree for security issues via static + heuristic review.
- Rank findings by impact; write top-5 max to:
  `agent/projects/{project}/agent/audits/security-auditor/<YYYY-MM-DD>.md`
- Push to `{project}`'s *-worker track inbox **only** for high-severity findings
  (hardcoded secret, active auth bypass) — always include rationale.

## Scope

- Operates on: `agent/projects/{project}/` (source tree + deps)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# security-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <path:line>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was walked vs. not>
```

Hard rule: top-N ≤ 5.

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_A11Y_AUDITOR = """\
# Track: {name}

## What this track IS

The **accessibility auditor** for the `{project}` project. Each wake it walks
the project's UI surface — landmark roles, contrast, alt text, ARIA, keyboard
nav — and produces a ranked findings report (top-5 max).

Scope: {filter}.

## Objectives

- Walk `{project}`'s components and routes for accessibility issues.
- Rank findings by impact; write top-5 max to:
  `agent/projects/{project}/agent/audits/a11y-auditor/<YYYY-MM-DD>.md`
- Push to `{project}`'s *-worker track inbox **only** for active accessibility
  blockers on a production route — always include rationale.

## Scope

- Operates on: `agent/projects/{project}/` (UI components + routes)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# a11y-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <path:line or component>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was walked vs. not>
```

Hard rule: top-N ≤ 5.

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_TEST_COVERAGE_AUDITOR = """\
# Track: {name}

## What this track IS

The **test-coverage gap detector** for the `{project}` project. Each wake it
maps which modules, routes, and handlers have no tests, which assertions are
weak, and which integration paths are unexercised. Produces a ranked findings
report (top-5 max).

Scope: {filter}.

## Objectives

- Walk `{project}`'s source and test files; map untested modules and paths.
- Rank findings by impact; write top-5 max to:
  `agent/projects/{project}/agent/audits/test-coverage-auditor/<YYYY-MM-DD>.md`
- Default: worker polls audits dir at wake start (no push). Push only on explicit
  originator directive.

## Scope

- Operates on: `agent/projects/{project}/` (source + test files)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# test-coverage-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <path:line or module>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was walked vs. not>
```

Hard rule: top-N ≤ 5.

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_PRINCIPLES_AUDITOR = """\
# Track: {name}

## What this track IS

The **structural code-quality auditor** for the `{project}` project. Each wake
it walks for structural concerns — modularity, single-responsibility,
encapsulation, boundary integrity, composition over inheritance, dedupe — and
triages hard: **top 3 only**. The subjectivity demands tight discipline.

Scope: {filter}.

## Objectives

- Walk `{project}`'s source and reason about boundaries, responsibilities,
  and composition.
- Triage to top-3 only (hard cap — stricter than other auditors). Write to:
  `agent/projects/{project}/agent/audits/principles-auditor/<YYYY-MM-DD>.md`
- Default: worker polls audits dir at wake start (no push).

## Scope

- Operates on: `agent/projects/{project}/` (source tree)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# principles-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <path:line or module>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was walked vs. not>
```

Hard rule: top-N ≤ **3** (not 5 — subjectivity demands tighter triage).

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write top-3 findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_BUGFINDER_AUDITOR = """\
# Track: {name}

## What this track IS

The **likely-bugs walker** for the `{project}` project. Each wake it reads code
with skeptical intent — type holes, dead branches, race shapes, off-by-ones,
exception-eating, null-handling regressions, leftover TODO/FIXME with code-shape
smells — and produces a ranked findings report (top-5 max).

Scope: {filter}.

## Objectives

- Walk `{project}`'s source for likely bugs by static reading with a skeptic lens.
- Rank findings by impact; write top-5 max to:
  `agent/projects/{project}/agent/audits/bugfinder-auditor/<YYYY-MM-DD>.md`
- Push to `{project}`'s *-worker track inbox **only** for high-confidence,
  high-severity bugs on a live request path — always include rationale.

## Scope

- Operates on: `agent/projects/{project}/` (source tree)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# bugfinder-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <path:line>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was walked vs. not>
```

Hard rule: top-N ≤ 5.

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_DOCDRIFT_AUDITOR = """\
# Track: {name}

## What this track IS

The **doc-to-code drift detector** for the `{project}` project. Each wake it
walks for drift between docs/specs and code — design doc says X but code does Y;
README references commands that don't exist; agent.md mentions tracks that
aren't there. Produces a ranked findings report (top-5 max).

Scope: {filter}.

## Objectives

- Walk `{project}`'s docs and compare against source for factual drift.
- Rank findings by impact; write top-5 max to:
  `agent/projects/{project}/agent/audits/docdrift-auditor/<YYYY-MM-DD>.md`
- Default: worker polls audits dir at wake start (no push).

## Scope

- Operates on: `agent/projects/{project}/` (docs + source tree)
- {filter}

## Authority

Decides on its own:
- Severity and confidence ratings for each finding
- What constitutes a finding vs. a style preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to fix, close, or escalate a finding — that is the worker's call
- Architectural decisions implied by a finding — surfaces; does not mandate

## Cadence

`next_wake_in_seconds = {cadence_seconds}`. Also wakes on inbox signal.

## Findings template

```
# docdrift-auditor — {project} — YYYY-MM-DD

## Top findings (ranked)

### 1. <title>
- **Where:** <doc-path> vs <code-path:line>
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## Skipped / parked
- <one-liner each>

## Coverage note
- <what was walked vs. not>
```

Hard rule: top-N ≤ 5.

## How this track fails

- **Rubber-stamp pass:** finding nothing because nothing is the easy answer. The
  failure looks like "no issues found" when issues are present.
- **Style-nit burial:** one real finding buried under multiple style/nit observations.
  The most severe issue must rank first; preferences are not findings.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path or fetch a URL, say confidence=low or park it.

## Bootstrap (first wake)

1. Read `agent/runtime/tracks/AUDITOR_ROADMAP.md` for shared posture.
2. Run first audit pass on `{project}`; write findings; sleep {cadence_seconds}s.
"""

_TRACK_TEMPLATE_CODE_REVIEW = """\
# Track: {name}

## What this track IS

A code-review specialist. Reads diffs, recent commits, and pull requests with
a skeptic's eye — correctness, security, architecture, test coverage — and
produces structured findings with severity and confidence ratings.

## Authority

Decides on its own:
- Severity level of each finding (high / medium / low)
- Confidence level of each finding (high / medium / low)
- What constitutes a finding vs. a preference vs. noise
- What to skip or park this pass

Surfaces rather than decides:
- Whether to merge, revert, or fix — that is the author's or originator's call
- Architectural scope changes — surfaces; does not unilaterally mandate

## Scope

- Operates on: source commits, diffs, or files routed via inbox

## How this track works

1. Read inbox: the code or diff to review.
2. Read necessary context (related files, design docs).
3. Produce structured findings at the severity/confidence matrix below.
4. Surface high-severity/high-confidence findings to the relevant worker inbox.
5. Write the full report.
6. Sleep.

## Findings template

```
# code-review — YYYY-MM-DD — <scope>

## Top findings (ranked)

### 1. <title>
- **Where:** <path:line>
- **Layer:** presentation | logic | data | infra
- **Severity:** high | medium | low
- **What:** <1-2 sentences>
- **Why it matters:** <1-2 sentences>
- **Suggested fix:** <optional>
- **Confidence:** high | medium | low

## What is NOT a finding (this pass)
- <style preferences, naming opinions, non-issues, parked items>

## Coverage note
- <what was reviewed vs. not>
```

Hard rule: top-N ≤ 5.

## Severity calibration

- **high:** correctness bug on a live path, security hole, data loss, auth bypass
- **medium:** logic that fails under expected conditions, missing null-check on real input
- **low:** degraded experience, tech debt, test gap (not an immediate bug)

Preferences, style, naming conventions: **not findings** — move to "What is NOT a finding."

## Confidence calibration

- **high:** traced the code path end-to-end; confident the failure manifests
- **medium:** identified the problem shape; cannot fully trace without runtime context
- **low:** pattern-match only; may be intentional or already handled elsewhere

## Layer-crossing methodology

Check each concern at its proper layer before flagging:

1. **Presentation → Logic:** Does this component reach through to business logic directly?
2. **Logic → Data:** Does this handler assume data it does not validate?
3. **Data → Infra:** Does this query assume infra properties (index, transaction) not guaranteed?

Layer violations are structural and warrant medium-to-high severity even without an immediate bug.

## Posture

Commit to findings. State "this is a bug" not "this might be a bug." Use the confidence
field to carry uncertainty — not hedged language in the finding body. "Confidence: medium"
holds the hedge; the finding itself should be declarative.

## How this track fails

- **Rubber-stamp pass:** reviewing but finding nothing because nothing is the easy answer.
  The failure looks like "no significant issues found" on a diff with clear problems.
- **Style-nit burial:** the real bug at #4, under three formatting observations at #1–3.
  The most severe finding must rank first; preferences are not findings.
- **Confidence inflation:** marking medium-confidence findings as high because it feels
  more authoritative. High confidence requires a traced code path, not a pattern match.
- **Scope creep:** reviewing adjacent code not in the diff because it seemed interesting.
  Scope is the diff plus necessary context; unscoped wandering produces report noise.
- **Verification theater:** claiming to have checked something without tracing it.
  If you did not trace a code path, say confidence=low or park it.

## Operating loop

1. Read the inbox and recent wake reports.
2. Identify the code or diff to review.
3. Trace findings at the severity/confidence matrix.
4. Write the findings report.
5. Push high/high findings to the relevant worker inbox.
6. If a message was consumed but the work not completed, file a followup before sleeping.
7. Sleep.
"""

# Template registry
TEMPLATES: dict[str, str] = {
    "blank": _TRACK_TEMPLATE_BLANK,
    "security-audit": _TRACK_TEMPLATE_SECURITY_AUDIT,
    "code-review": _TRACK_TEMPLATE_CODE_REVIEW,
    # Auditor templates (per-project; use --template + --project on `reflect track create`)
    "smoke-test-auditor": _TRACK_TEMPLATE_SMOKE_TEST_AUDITOR,
    "security-auditor": _TRACK_TEMPLATE_SECURITY_AUDITOR,
    "a11y-auditor": _TRACK_TEMPLATE_A11Y_AUDITOR,
    "test-coverage-auditor": _TRACK_TEMPLATE_TEST_COVERAGE_AUDITOR,
    "principles-auditor": _TRACK_TEMPLATE_PRINCIPLES_AUDITOR,
    "bugfinder-auditor": _TRACK_TEMPLATE_BUGFINDER_AUDITOR,
    "docdrift-auditor": _TRACK_TEMPLATE_DOCDRIFT_AUDITOR,
}

# Per-template defaults for create_from_template
TEMPLATE_DEFAULTS: dict[str, dict[str, object]] = {
    "smoke-test-auditor":      {"cadence_seconds": 86400,   "filter": "web-projects only"},
    "security-auditor":        {"cadence_seconds": 604800,  "filter": "any project"},
    "a11y-auditor":            {"cadence_seconds": 604800,  "filter": "web-projects only"},
    "test-coverage-auditor":   {"cadence_seconds": 604800,  "filter": "any project"},
    "principles-auditor":      {"cadence_seconds": 1209600, "filter": "any project"},
    "bugfinder-auditor":       {"cadence_seconds": 604800,  "filter": "any project"},
    "docdrift-auditor":        {"cadence_seconds": 604800,  "filter": "any project"},
}

# Named template families for bulk creation via --from-template-family
TEMPLATE_FAMILIES: dict[str, dict] = {
    "auditors": {
        "templates": [
            "smoke-test-auditor",
            "security-auditor",
            "a11y-auditor",
            "test-coverage-auditor",
            "principles-auditor",
            "bugfinder-auditor",
            "docdrift-auditor",
        ],
        "scope": "project",  # requires --projects; generates {project}-{template} names
    },
}


def create_track(
    name: str,
    template: str = "blank",
    tracks_dir: Optional[Path] = None,
    **template_vars: object,
) -> dict:
    """Create a new track directory with inbox, followup, and wake.md.

    *template_vars* are forwarded to the template's format-string substitution.
    ``name`` is always injected automatically; callers need not repeat it.

    Returns {"ok": bool, "message": str, "track_dir": str|None}.
    """
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name

    if track_dir.exists():
        return {
            "ok": False,
            "message": f"Track '{name}' already exists at {track_dir}",
            "track_dir": str(track_dir),
        }

    template_str = TEMPLATES.get(template, _TRACK_TEMPLATE_BLANK)
    try:
        wake_md_content = _validate_and_format(template_str, name=name, **template_vars)
    except ValueError as exc:
        return {
            "ok": False,
            "message": f"Template error for '{template}': {exc}",
            "track_dir": None,
        }

    # P9 (unified inbox): single inbox/ + sibling followup/; no from-originator/from-agent split.
    (track_dir / "inbox" / ".consumed").mkdir(parents=True, exist_ok=True)
    (track_dir / "followup" / ".completed").mkdir(parents=True, exist_ok=True)
    (track_dir / "wake.md").write_text(wake_md_content)

    return {
        "ok": True,
        "message": f"Created track '{name}' (template: {template}). Edit wake.md to define identity.",
        "track_dir": str(track_dir),
    }


def create_from_template(
    template: str,
    project: str,
    cadence_seconds: Optional[int] = None,
    name: Optional[str] = None,
    filter_override: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Create a per-project auditor track from a named template.

    Args:
        template:         Template name (must be in TEMPLATES and TEMPLATE_DEFAULTS).
        project:          Project name (e.g. "tbd", "toilet-finder").
        cadence_seconds:  Override the template's default cadence. None = use default.
        name:             Track name override. Default: "{project}-{template}".
        filter_override:  Override the template's default filter description. None = use default.
        tracks_dir:       Override the tracks directory (testing only).

    Returns {"ok": bool, "message": str, "track_dir": str|None}.
    """
    if template not in TEMPLATE_DEFAULTS:
        known = sorted(TEMPLATE_DEFAULTS.keys())
        return {
            "ok": False,
            "message": (
                f"Template '{template}' is not an auditor template. "
                f"Known auditor templates: {known}. "
                f"For generic templates use 'reflect track create --template {template}'."
            ),
            "track_dir": None,
        }

    defaults = TEMPLATE_DEFAULTS[template]
    effective_cadence = cadence_seconds if cadence_seconds is not None else int(defaults["cadence_seconds"])
    effective_filter = filter_override if filter_override is not None else str(defaults["filter"])
    effective_name = name if name else f"{project}-{template}"

    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / effective_name

    if track_dir.exists():
        return {
            "ok": False,
            "message": f"Track '{effective_name}' already exists at {track_dir}",
            "track_dir": str(track_dir),
        }

    template_str = TEMPLATES[template]
    try:
        wake_md_content = _validate_and_format(
            template_str,
            name=effective_name,
            project=project,
            cadence_seconds=effective_cadence,
            filter=effective_filter,
        )
    except ValueError as exc:
        return {
            "ok": False,
            "message": f"Template render error for '{template}': {exc}",
            "track_dir": None,
        }

    (track_dir / "inbox" / ".consumed").mkdir(parents=True, exist_ok=True)
    (track_dir / "followup" / ".completed").mkdir(parents=True, exist_ok=True)
    (track_dir / "wake.md").write_text(wake_md_content)

    return {
        "ok": True,
        "message": (
            f"Created track '{effective_name}' "
            f"(template: {template}, project: {project}, cadence: {effective_cadence}s)."
        ),
        "track_dir": str(track_dir),
        "track_name": effective_name,
        "cadence_seconds": effective_cadence,
    }


def create_from_family(
    family: str,
    projects: Optional[list[str]] = None,
    cadence_seconds: Optional[int] = None,
    filter_override: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Bulk-create tracks for a named template family.

    Family scope determines mode:

    - ``scope="project"`` (e.g. "auditors"): requires *projects*. Creates one
      track per (project × template), named "{project}-{template}".
    - ``scope="global"`` (e.g. future "coordinators"): *projects* must be None.
      Creates one track per template in the family, named "{template}".

    Returns {
        "ok": bool (True if all succeeded),
        "created": [{"track_name": ..., "track_dir": ...}, ...],
        "failed": [{"project": ..., "template": ..., "message": ...}, ...],
    }.
    """
    if family not in TEMPLATE_FAMILIES:
        known = sorted(TEMPLATE_FAMILIES.keys())
        return {
            "ok": False,
            "created": [],
            "failed": [{"project": "*", "template": "*", "message": f"Unknown family '{family}'. Known: {known}"}],
        }

    family_meta = TEMPLATE_FAMILIES[family]
    templates = family_meta["templates"]
    scope = family_meta["scope"]

    if scope == "project":
        if not projects:
            return {
                "ok": False,
                "created": [],
                "failed": [{
                    "project": "*",
                    "template": "*",
                    "message": (
                        f"Family '{family}' has scope='project' — "
                        f"--projects is required (comma-separated list of project names)."
                    ),
                }],
            }
        # Project-fan-out: one track per (project × template)
        created: list[dict] = []
        failed: list[dict] = []
        for project in projects:
            for template in templates:
                result = create_from_template(
                    template=template,
                    project=project,
                    cadence_seconds=cadence_seconds,
                    filter_override=filter_override,
                    tracks_dir=tracks_dir,
                )
                if result["ok"]:
                    created.append({"track_name": result["track_name"], "track_dir": result["track_dir"]})
                else:
                    failed.append({"project": project, "template": template, "message": result["message"]})
        return {
            "ok": len(failed) == 0,
            "created": created,
            "failed": failed,
        }

    elif scope == "global":
        if projects:
            return {
                "ok": False,
                "created": [],
                "failed": [{
                    "project": "*",
                    "template": "*",
                    "message": (
                        f"Family '{family}' has scope='global' — "
                        f"--projects is not accepted; global families don't use a project axis."
                    ),
                }],
            }
        # Global fan-out: one per template, name=template-name
        created = []
        failed = []
        for template_name in templates:
            result = create_track(template_name, template=template_name, tracks_dir=tracks_dir)
            if result["ok"]:
                created.append({"track_name": template_name, "track_dir": result["track_dir"]})
            else:
                failed.append({"project": "-", "template": template_name, "message": result["message"]})
        return {
            "ok": len(failed) == 0,
            "created": created,
            "failed": failed,
        }

    else:
        return {
            "ok": False,
            "created": [],
            "failed": [{
                "project": "*",
                "template": "*",
                "message": f"Family '{family}' has unknown scope '{scope}'. Expected 'project' or 'global'.",
            }],
        }


def send_to_track(
    name: str,
    message: str,
    tracks_dir: Optional[Path] = None,
    sender: str = "originator",
    kind: str = "report",
) -> dict:
    """Drop a message into a track's inbox (soft delivery).

    P9 (unified inbox): writes to tracks/{name}/inbox/{ts}-send.md with
    YAML frontmatter identifying sender (from:), recipient (to:), timestamp,
    and message kind. Inbox files are read on the track's next wake.
    For live mid-wake injection, use interrupt_track() instead.

    Args:
        name: target track name
        message: markdown body (frontmatter prepended automatically)
        sender: 'from' field in frontmatter (default: 'originator')
        kind: one of report | request | deploy-request | btw | broadcast | followup

    Returns {"ok": bool, "message": str, "inbox_path": str|None, "delivered": "inbox"}.
    """
    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name

    if not track_dir.exists():
        return {"ok": False, "message": f"Track '{name}' not found", "inbox_path": None, "delivered": None}

    inbox_dir = track_dir / "inbox"
    inbox_dir.mkdir(parents=True, exist_ok=True)

    ts = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    filename = f"{ts}-send.md"
    inbox_path = inbox_dir / filename

    frontmatter = (
        f"---\n"
        f"from: {sender}\n"
        f"to: {name}\n"
        f"at: {ts}\n"
        f"kind: {kind}\n"
        f"---\n\n"
    )
    inbox_path.write_text(frontmatter + message + "\n")

    # Emit inbox.delivered event (fire-and-forget).
    try:
        from agent.runtime.events import emit_event as _emit, set_runtime_root as _srt
        _srt(resolve_project_root() / "agent" / "runtime")
        _wake_id = os.environ.get("REFLECT_WAKE_ID", "cli")
        _emit("inbox.delivered", track=name, wake_id=_wake_id, payload={
            "to_track": name,
            "from": sender,
            "subject": kind,
            "path": str(inbox_path),
        })
    except Exception:
        pass

    return {
        "ok": True,
        "message": f"Message queued to {name} inbox. Will be read on next wake.",
        "inbox_path": str(inbox_path),
        "delivered": "inbox",
    }


def get_track_logs(name: str) -> dict:
    """Return contents of the tick log for *name*.

    Log lives at ``/tmp/reflect-tick-{name}.log``. Returns::

        {"ok": bool, "log_path": str, "content": str | None, "message": str}
    """
    import tempfile
    log_path = Path(tempfile.gettempdir()) / f"reflect-tick-{name}.log"
    if not log_path.exists():
        return {
            "ok": False,
            "log_path": str(log_path),
            "content": None,
            "message": f"No log found at {log_path}",
        }
    try:
        content = log_path.read_text()
        return {
            "ok": True,
            "log_path": str(log_path),
            "content": content,
            "message": f"Read {len(content)} bytes from {log_path}",
        }
    except OSError as exc:
        return {
            "ok": False,
            "log_path": str(log_path),
            "content": None,
            "message": f"Error reading log: {exc}",
        }


def interrupt_track(
    name: str,
    message: str,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Inject a message into a running track's wake mid-flight via unix socket.

    State-aware dispatch:

    - running:  delivers via unix socket at next tool-call boundary.
    - idle:     inbox-drop + fires an immediate wake so the message is acted on
                now rather than waiting up to 60s for the next cron tick.
    - orphaned-lock: inbox-drop only; wake NOT fired (stale lock — let watchdog clean
                up before re-spawning).
    - disabled: inbox-drop only; wake NOT fired (track intentionally off).

    Returns {"ok": bool, "message": str, "inbox_path": str|None,
             "delivered": "socket"|"inbox"|None,
             "wake_fired": bool, "wake_pid": int|None,
             "track_state": "running"|"idle"|"orphaned-lock"|"disabled"}.
    """
    import socket as _socket
    from agent.cli.ops.wake import start_wake  # local import to avoid circular

    td = _effective_tracks_dir(tracks_dir)
    track_dir = td / name

    if not track_dir.exists():
        return {
            "ok": False,
            "message": f"Track '{name}' not found",
            "inbox_path": None,
            "delivered": None,
            "wake_fired": False,
            "wake_pid": None,
            "track_state": None,
        }

    # ── determine state (lazy-reaps orphaned locks) ───────────────────────
    dispatcher_state = _resolve_dispatcher_state(track_dir)
    runtime_state = _resolve_runtime_state(track_dir)
    # Composite state for the returned "track_state" field.
    if dispatcher_state == "disabled" and runtime_state != "idle":
        track_state = f"disabled · {runtime_state}"
    elif dispatcher_state == "disabled":
        track_state = "disabled"
    else:
        track_state = runtime_state

    lock_path = track_dir / "wake.lock"
    lock_pid: Optional[int] = None
    if lock_path.exists():
        lock_pid = _read_lock_pid(lock_path)

    # ── running/paused: try socket delivery (regardless of dispatcher state) ─
    if runtime_state == "running":
        sock_path = track_dir / "interrupt.sock"
        if sock_path.exists():
            try:
                sock = _socket.socket(_socket.AF_UNIX, _socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect(str(sock_path))
                sock.sendall(message.encode("utf-8"))
                sock.close()
                return {
                    "ok": True,
                    "message": (
                        f"Interrupt delivered to running track '{name}' via socket. "
                        f"Will land at next tool-call boundary."
                    ),
                    "inbox_path": None,
                    "delivered": "socket",
                    "wake_fired": False,
                    "wake_pid": None,
                    "track_state": track_state,
                }
            except (OSError, ConnectionRefusedError, TimeoutError):
                pass  # socket present but stale — fall through to inbox-drop without wake
        # Process alive but socket not reachable: inbox-drop, no new wake (it's running)
        # Fall through to inbox-drop below with wake_fire=False.

    # ── inbox-drop (all non-socket paths) ─────────────────────────────────
    inbox_dir = track_dir / "inbox"
    inbox_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    filename = f"{ts}-interrupt.md"
    inbox_path = inbox_dir / filename
    frontmatter = (
        f"---\nfrom: originator\nto: {name}\nat: {ts}\nkind: btw\n---\n\n"
    )
    inbox_path.write_text(frontmatter + message + "\n")

    # Emit inbox.delivered event (fire-and-forget).
    try:
        from agent.runtime.events import emit_event as _emit, set_runtime_root as _srt
        _srt(resolve_project_root() / "agent" / "runtime")
        _wake_id = os.environ.get("REFLECT_WAKE_ID", "cli")
        _emit("inbox.delivered", track=name, wake_id=_wake_id, payload={
            "to_track": name,
            "from": "originator",
            "subject": "btw",
            "path": str(inbox_path),
        })
    except Exception:
        pass

    # ── fire wake for idle enabled tracks only ────────────────────────────
    wake_fired = False
    wake_pid: Optional[int] = None

    if runtime_state == "idle" and dispatcher_state == "enabled":
        wake_result = start_wake(name)
        if wake_result.get("ok"):
            wake_fired = True
            wake_pid = wake_result.get("pid")

    # ── compose response message ──────────────────────────────────────────
    if runtime_state == "idle":
        if dispatcher_state == "disabled":
            msg = (
                f"Track '{name}' is disabled and idle; message queued in inbox. "
                f"Wake NOT fired. Enable the track to process it."
            )
        elif wake_fired:
            msg = f"Track '{name}' was idle; message delivered to inbox and wake fired (pid {wake_pid})."
        else:
            msg = f"Track '{name}' was idle; message delivered to inbox. Wake fire failed — will run on next cron tick."
    elif runtime_state == "running":
        if dispatcher_state == "disabled":
            msg = (
                f"Track '{name}' is disabled but running; "
                f"message queued in inbox (will be picked up by live wake)."
            )
        else:
            msg = (
                f"Track '{name}' is running but socket unreachable; "
                f"message queued in inbox (will be picked up by live wake)."
            )
    else:  # paused (runtime_state == "paused")
        msg = (
            f"Track '{name}' is paused; message queued in inbox "
            f"(will be picked up when wake resumes)."
        )

    return {
        "ok": True,
        "message": msg,
        "inbox_path": str(inbox_path),
        "delivered": "inbox",
        "wake_fired": wake_fired,
        "wake_pid": wake_pid,
        "track_state": track_state,
    }
