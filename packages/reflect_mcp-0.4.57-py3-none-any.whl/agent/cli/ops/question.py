"""Pure question operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI) format as needed.
"""
from __future__ import annotations

import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import yaml

from agent.cli.ops.root import resolve_project_root


# ── helpers ────────────────────────────────────────────────────────────────


def _effective_tracks_dir(tracks_dir: Optional[Path] = None) -> Path:
    return (
        tracks_dir
        if tracks_dir is not None
        else resolve_project_root() / "agent" / "runtime" / "tracks"
    )


def _open_questions_for_track(pq_dir: Path) -> list[dict]:
    """Return parsed YAML records for all open questions in *pq_dir*.

    Skips records in .resolved/ and any files that fail to parse.
    """
    if not pq_dir.exists():
        return []
    records = []
    for p in sorted(pq_dir.glob("*.yaml")):
        try:
            rec = yaml.safe_load(p.read_text())
        except Exception:
            continue
        if not isinstance(rec, dict):
            continue
        if rec.get("status") == "open":
            rec["_path"] = p
            records.append(rec)
    return records


def _find_question(pq_dir: Path, question_id: str) -> Optional[dict]:
    """Locate a question record by ID (slug~hash). Returns None if not found."""
    if not pq_dir.exists():
        return None
    for p in pq_dir.glob("*.yaml"):
        try:
            rec = yaml.safe_load(p.read_text())
        except Exception:
            continue
        if isinstance(rec, dict) and rec.get("id") == question_id:
            rec["_path"] = p
            return rec
    return None


def _write_yaml_atomic(path: Path, record: dict) -> None:
    """Write YAML to *path* atomically via tmp → rename."""
    tmp = path.parent / f".{path.name}.tmp.{os.getpid()}"
    tmp.write_text(yaml.dump(record, allow_unicode=True))
    os.replace(str(tmp), str(path))


# ── public ops ─────────────────────────────────────────────────────────────


def list_pending_questions(
    track: Optional[str] = None,
    tracks_dir: Optional[Path] = None,
) -> list[dict]:
    """Return open pending questions.

    If *track* is given, only that track is scanned. Otherwise all tracks.

    Each item in the returned list has:
      track, id, created_at, expires_at, question, answer_map,
      blocked_work (from context), status
    """
    td = _effective_tracks_dir(tracks_dir)
    if not td.exists():
        return []

    if track:
        track_names = [track]
    else:
        track_names = sorted(
            d.name
            for d in td.iterdir()
            if d.is_dir() and not d.name.startswith(".")
        )

    results = []
    for t in track_names:
        pq_dir = td / t / "pending-questions"
        for rec in _open_questions_for_track(pq_dir):
            results.append({
                "track": t,
                "id": rec.get("id", ""),
                "created_at": rec.get("created_at", ""),
                "expires_at": rec.get("expires_at", ""),
                "question": rec.get("question", ""),
                "answer_map": rec.get("answer_map", {}),
                "blocked_work": (rec.get("context") or {}).get("blocked_work", ""),
                "status": rec.get("status", ""),
            })
    return results


def show_pending_question(
    track: str,
    question_id: str,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Return the full YAML text of a question record.

    Returns {"ok": True, "content": <yaml-text>}
    or      {"ok": False, "message": <reason>}.
    """
    td = _effective_tracks_dir(tracks_dir)
    pq_dir = td / track / "pending-questions"

    rec = _find_question(pq_dir, question_id)
    if rec is None:
        return {
            "ok": False,
            "message": f"No question '{question_id}' found for track '{track}'",
        }
    # Re-read raw text for display
    path: Path = rec["_path"]
    return {"ok": True, "content": path.read_text()}


def resolve_pending_question_cli(
    track: str,
    question_id: str,
    reply_token: str,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Human-initiated resolution of a pending question.

    Steps:
      1. Locate the question. Return error if not found or already resolved.
      2. Validate reply_token is in answer_map. Return error if not.
      3. Write resolved YAML atomically.
      4. Move to .resolved/.
      5. Touch next-wake-by.timestamp to now-1 (DR6).

    Returns {"ok": bool, "message": str, "id": str|None}.
    """
    td = _effective_tracks_dir(tracks_dir)
    pq_dir = td / track / "pending-questions"

    rec = _find_question(pq_dir, question_id)
    if rec is None:
        return {
            "ok": False,
            "message": (
                f"No question '{question_id}' found for track '{track}'. "
                f"Check `reflect question list {track}` for open questions."
            ),
            "id": None,
        }

    if rec.get("status") != "open":
        return {
            "ok": False,
            "message": (
                f"Question '{question_id}' is already {rec.get('status', 'not open')}."
            ),
            "id": None,
        }

    answer_map: dict = rec.get("answer_map") or {}
    if reply_token not in answer_map:
        valid = " / ".join(sorted(answer_map.keys()))
        return {
            "ok": False,
            "message": (
                f"Invalid reply token '{reply_token}'. "
                f"Valid tokens: {valid}"
            ),
            "id": None,
        }

    # Write resolved record atomically
    path: Path = rec["_path"]
    now_ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    rec_clean = {k: v for k, v in rec.items() if k != "_path"}
    rec_clean["reply"] = reply_token
    rec_clean["status"] = "resolved"
    rec_clean["resolved_at"] = now_ts
    _write_yaml_atomic(path, rec_clean)

    # Move to .resolved/
    resolved_dir = pq_dir / ".resolved"
    resolved_dir.mkdir(parents=True, exist_ok=True)
    dest = resolved_dir / path.name
    os.replace(str(path), str(dest))

    # Touch next-wake-by.timestamp to now-1 (DR6)
    nw_path = td / track / "next-wake-by.timestamp"
    now_minus_1 = int(time.time()) - 1
    tmp_nw = nw_path.parent / f".next-wake-by.tmp.{os.getpid()}"
    tmp_nw.write_text(f"{now_minus_1}\n")
    os.replace(str(tmp_nw), str(nw_path))

    action = answer_map[reply_token]
    return {
        "ok": True,
        "message": f'resolved {question_id} → "{action}"',
        "id": question_id,
    }


def expire_pending_question(
    track: str,
    question_id: str,
    tracks_dir: Optional[Path] = None,
) -> dict:
    """Mark a question as expired and move it to .resolved/.

    Does NOT touch next-wake-by.timestamp — expiry is a bookkeeping action,
    not a wake trigger.

    Returns {"ok": bool, "message": str, "id": str|None}.
    """
    td = _effective_tracks_dir(tracks_dir)
    pq_dir = td / track / "pending-questions"

    rec = _find_question(pq_dir, question_id)
    if rec is None:
        return {
            "ok": False,
            "message": (
                f"No question '{question_id}' found for track '{track}'."
            ),
            "id": None,
        }

    # Write expired record atomically
    path: Path = rec["_path"]
    now_ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    rec_clean = {k: v for k, v in rec.items() if k != "_path"}
    rec_clean["status"] = "expired"
    rec_clean["resolved_at"] = now_ts
    _write_yaml_atomic(path, rec_clean)

    # Move to .resolved/
    resolved_dir = pq_dir / ".resolved"
    resolved_dir.mkdir(parents=True, exist_ok=True)
    dest = resolved_dir / path.name
    os.replace(str(path), str(dest))

    return {
        "ok": True,
        "message": f"expired {question_id}",
        "id": question_id,
    }
