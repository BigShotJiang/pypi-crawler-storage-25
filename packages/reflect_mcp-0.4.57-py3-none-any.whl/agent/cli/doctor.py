"""Health check subcommand for the reflect CLI."""
from __future__ import annotations

import fcntl
import json
import os
import socket
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

from .output import OutputMode, print_list
from .ops.track import (
    _is_pid_alive,
    _read_lock_pid,
)
from .ops.root import resolve_project_root

def _track_names():
    from .ops.track import list_tracks
    return list_tracks()

DISPATCH_LOG = Path("/tmp/reflect-dispatch.log")

# Module-level sentinels — None means "resolve lazily at call time".
# Tests override these via patch() to control which paths run_checks() sees
# without affecting the MCP server's lazy-resolution behavior (which sets
# REFLECT_PROJECT *before* calling run_checks, not before importing doctor).
PROJECT_ROOT: "Path | None" = None  # type: ignore[assignment]
TRACKS_DIR: "Path | None" = None  # type: ignore[assignment]
SCRY_DB: "Path | None" = None  # type: ignore[assignment]
STATE_DB: "Path | None" = None  # type: ignore[assignment]


def _check(check_id: str, condition: bool, pass_msg: str, warn_msg: str, status_if_fail: str = "WARN") -> dict:
    if condition:
        return {"check": check_id, "status": "PASS", "message": pass_msg}
    return {"check": check_id, "status": status_if_fail, "message": warn_msg}


def run_checks() -> list[dict]:
    # Lazy path resolution — must happen at call time, not import time, so that
    # the MCP server (which sets REFLECT_PROJECT before calling this) resolves to
    # the correct project root rather than the startup-time cwd.
    # Module-level sentinels (PROJECT_ROOT, TRACKS_DIR, SCRY_DB, STATE_DB) are
    # None by default; tests override them via patch() to inject test fixtures.
    import agent.cli.doctor as _mod
    _project_root = _mod.PROJECT_ROOT if _mod.PROJECT_ROOT is not None else resolve_project_root()
    _tracks_dir = _mod.TRACKS_DIR if _mod.TRACKS_DIR is not None else (_project_root / "agent" / "runtime" / "tracks")
    _scry_db = _mod.SCRY_DB if _mod.SCRY_DB is not None else (_project_root / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db")
    _state_db = _mod.STATE_DB if _mod.STATE_DB is not None else (_project_root / "agent" / "runtime" / "state.db")
    # Alias to local names for readability throughout this function
    PROJECT_ROOT = _project_root  # noqa: N806
    TRACKS_DIR = _tracks_dir  # noqa: N806
    SCRY_DB = _scry_db  # noqa: N806
    STATE_DB = _state_db  # noqa: N806

    results = []

    # 1. crontab line
    try:
        out = subprocess.run(
            ["crontab", "-l"],
            capture_output=True,
            text=True,
        )
        has_dispatch = "reflect-dispatch" in out.stdout
    except (OSError, subprocess.SubprocessError):
        has_dispatch = False
    results.append(_check(
        "crontab-line",
        has_dispatch,
        "crontab contains reflect-dispatch",
        "crontab does not contain reflect-dispatch — dispatcher may not be running",
    ))

    # 2. dispatch log freshness (5 min)
    if DISPATCH_LOG.exists():
        age = time.time() - DISPATCH_LOG.stat().st_mtime
        fresh = age < 300
        results.append(_check(
            "dispatch-log-fresh",
            fresh,
            f"dispatch log updated {int(age)}s ago",
            f"dispatch log is stale ({int(age)}s ago) — cron may not be firing",
        ))
    else:
        results.append({
            "check": "dispatch-log-fresh",
            "status": "WARN",
            "message": f"dispatch log not found at {DISPATCH_LOG}",
        })

    # Per-track checks
    now = time.time()
    for name in _track_names():
        track_dir = TRACKS_DIR / name
        lock_path = track_dir / "wake.lock"

        is_disabled = (track_dir / "disabled.flag").exists()

        if lock_path.exists() and not is_disabled:
            # Zombie lock: try to acquire a non-blocking flock.
            # If we CAN acquire it, no wake is holding it (idle — fine).
            # If we CANNOT, a wake is running — that's expected when active.
            # A "zombie" is: flock held, but the pid that should own it is dead.
            # Since pids aren't written to the lock file, we detect this by
            # checking if the lock is held AND no reflect-wake process for this
            # track is running.
            try:
                with open(lock_path, "r") as fd:
                    held = False
                    try:
                        fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        fcntl.flock(fd.fileno(), fcntl.LOCK_UN)
                        # Lock not held — track is idle, no check needed
                    except BlockingIOError:
                        held = True
                if held:
                    # Lock IS held — check if a reflect-wake process exists for this track
                    try:
                        ps_out = subprocess.run(
                            ["pgrep", "-f", f"REFLECT_TRACK={name}"],
                            capture_output=True, text=True
                        )
                        has_process = ps_out.returncode == 0 and ps_out.stdout.strip()
                    except OSError:
                        has_process = True  # can't check; assume OK
                    results.append(_check(
                        f"zombie-lock-{name}",
                        bool(has_process),
                        f"lock held by live wake process",
                        f"lock held but no reflect-wake process found for {name} — zombie lock",
                    ))
            except OSError:
                pass

            # Stuck lock: mtime > 1 hour
            try:
                lock_age = now - lock_path.stat().st_mtime
                results.append(_check(
                    f"stuck-lock-{name}",
                    lock_age < 3600,
                    f"lock age {int(lock_age)}s is within 1 hour",
                    f"lock has been held for {int(lock_age)}s (>{3600}s) — possible stuck wake",
                ))
            except OSError:
                pass

    # Proxy: TCP reachability
    proxy_reachable = False
    try:
        with socket.create_connection(("127.0.0.1", 9000), timeout=1):
            proxy_reachable = True
    except (OSError, socket.timeout):
        proxy_reachable = False
    results.append(_check(
        "proxy-running",
        proxy_reachable,
        "Claude OAuth proxy is reachable at 127.0.0.1:9000",
        "Claude OAuth proxy not reachable at 127.0.0.1:9000 — start with ~/scripts/claude/proxy.py or the systemd unit; set REFLECT_USE_API=1 to bypass",
        status_if_fail="WARN",
    ))

    # Proxy: credentials validity
    creds_path = Path.home() / ".claude" / ".credentials.json"
    if creds_path.exists():
        try:
            creds = json.loads(creds_path.read_text())
            expires_at = creds.get("claudeAiOauth", {}).get("expiresAt", 0)
            # expiresAt is in milliseconds
            expires_ts = expires_at / 1000.0
            now_ts = time.time()
            if expires_ts > now_ts + 7 * 86400:
                results.append({"check": "proxy-credentials-valid", "status": "PASS",
                                 "message": f"OAuth token valid; expires {time.strftime('%Y-%m-%dT%H:%MZ', time.gmtime(expires_ts))}"})
            elif expires_ts > now_ts:
                days_left = int((expires_ts - now_ts) / 86400)
                results.append({"check": "proxy-credentials-valid", "status": "WARN",
                                 "message": f"OAuth token expires in {days_left}d — run `claude --version` to refresh"})
            else:
                results.append({"check": "proxy-credentials-valid", "status": "FAIL",
                                 "message": "OAuth token expired — run `claude --version` to refresh, or set REFLECT_USE_API=1 to bypass"})
        except (json.JSONDecodeError, OSError, KeyError, TypeError) as e:
            results.append({"check": "proxy-credentials-valid", "status": "WARN",
                             "message": f"Could not parse {creds_path}: {e}"})
    else:
        results.append({"check": "proxy-credentials-valid", "status": "WARN",
                         "message": f"Credentials file not found at {creds_path} — proxy may not authenticate"})

    # scry DB + state DB — check per project root.
    #
    # When reflect-mcp is installed via `uv tool install` without REFLECT_PROJECT
    # set, PROJECT_ROOT resolves to the install-site directory (not the user's
    # project).  In that case SCRY_DB won't exist at the install site, so we fall
    # back to iterating linked project targets (agent/projects/ symlinks).
    # This produces per-project PASS/WARN entries rather than one spurious WARN
    # pointing at the install-site.  See v0.3.2 CHANGELOG.
    _db_roots: list[tuple[str, Path]] = []  # (label_suffix, project_root)
    if SCRY_DB.exists():
        # Primary root is correct (in-tree dev or REFLECT_PROJECT set) — use it.
        _db_roots.append(("", PROJECT_ROOT))
    else:
        # Primary root has no scry DB — look at linked project targets.
        _projects_dir = PROJECT_ROOT / "agent" / "projects"
        if _projects_dir.is_dir():
            for _entry in sorted(_projects_dir.iterdir()):
                if _entry.name.startswith("."):
                    continue
                if _entry.is_dir() and (
                    _entry.is_symlink() or (_entry / "agent").is_dir()
                ):
                    _db_roots.append((f"-{_entry.name}", _entry.resolve()))
        if not _db_roots:
            # No linked projects found; fall back to primary root so we at least
            # emit a diagnostic (WARN) rather than silently skipping.
            _db_roots.append(("", PROJECT_ROOT))

    for _suffix, _root in _db_roots:
        _scry_db = _root / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db"
        results.append(_check(
            f"scry-db{_suffix}",
            _scry_db.exists() and os.access(_scry_db, os.R_OK),
            f"scry DB readable at {_scry_db}",
            f"scry DB not readable at {_scry_db}",
        ))
        # Integrity check: verify the DB is a valid SQLite file, and warn about
        # stale WAL/SHM sidecars that can corrupt a newly-swapped-in database.
        #
        # WAL/SHM files are NORMAL SQLite WAL-mode artifacts — they are created
        # and managed by SQLite during ordinary operation.  They only become
        # problematic when they are STALE: left over from a previous DB session
        # after the DB file itself was replaced (e.g. during scry recovery).
        # Staleness heuristic: a sidecar whose mtime is more than 60s older
        # than the DB's mtime was probably not written alongside the current DB.
        _STALE_THRESHOLD_S = 60
        if _scry_db.exists():
            _wal = Path(str(_scry_db) + "-wal")
            _shm = Path(str(_scry_db) + "-shm")
            # Auto-cleanup: delete any 0-byte WAL/SHM sidecars immediately.
            # A 0-byte WAL contains no committed data; leaving it causes
            # "disk I/O error" on the next MCP connection. Deletion is safe.
            for _sc_path in (_wal, _shm):
                if _sc_path.exists() and _sc_path.stat().st_size == 0:
                    try:
                        _sc_path.unlink()
                        results.append({
                            "check": f"scry-db-wal-cleanup{_suffix}",
                            "status": "PASS",
                            "message": f"stale 0-byte WAL deleted: {_sc_path.name}",
                        })
                    except OSError as _e:
                        results.append({
                            "check": f"scry-db-wal-cleanup{_suffix}",
                            "status": "WARN",
                            "message": (
                                f"0-byte WAL sidecar found but could not delete "
                                f"{_sc_path.name}: {_e}"
                            ),
                        })
            _sidecar_paths = [f for f in (_wal, _shm) if f.exists()]
            _has_sidecars = bool(_sidecar_paths)
            # Determine staleness: sidecars are stale if the DB is more than
            # _STALE_THRESHOLD_S newer than the newest sidecar.
            _stale_sidecars: list[Path] = []
            if _has_sidecars:
                _db_mtime = _scry_db.stat().st_mtime
                for _sc in _sidecar_paths:
                    if _db_mtime - _sc.stat().st_mtime > _STALE_THRESHOLD_S:
                        _stale_sidecars.append(_sc)
            try:
                _conn = sqlite3.connect(str(_scry_db), timeout=2)
                _conn.execute("SELECT 1")
                _conn.close()
                _integrity_ok = True
            except sqlite3.DatabaseError:
                _integrity_ok = False
            if _integrity_ok and not _stale_sidecars:
                _note = (
                    " (WAL mode active)"
                    if _has_sidecars and not _stale_sidecars
                    else ""
                )
                results.append({
                    "check": f"scry-db-integrity{_suffix}",
                    "status": "PASS",
                    "message": f"scry DB is valid SQLite{_note}",
                })
            elif _integrity_ok and _stale_sidecars:
                _stale_names = " ".join(f.name for f in _stale_sidecars)
                results.append({
                    "check": f"scry-db-integrity{_suffix}",
                    "status": "WARN",
                    "message": (
                        f"scry DB valid but stale WAL/SHM sidecars present "
                        f"({_stale_names}) — these predate the current DB and "
                        "may corrupt it after a swap; delete them if corruption "
                        "occurs"
                    ),
                })
            else:
                _msg = f"scry DB at {_scry_db} is not a valid SQLite database"
                if _has_sidecars:
                    _sidecar_names = " ".join(f.name for f in _sidecar_paths)
                    _msg += (
                        f" — WAL/SHM sidecars detected ({_sidecar_names}): "
                        f"delete them in {_scry_db.parent}, "
                        "restore from backup, then run scry_surface"
                    )
                else:
                    _msg += " — run `scry surface` from project root to rebuild"
                results.append({
                    "check": f"scry-db-integrity{_suffix}",
                    "status": "ERROR",
                    "message": _msg,
                })
        _state_db = _root / "agent" / "runtime" / "state.db"
        results.append(_check(
            f"state-db{_suffix}",
            _state_db.exists(),
            f"state DB exists at {_state_db}",
            f"state DB not found at {_state_db} (optional)",
        ))

    # Multi-project checks
    projects_dir = PROJECT_ROOT / "agent" / "projects"
    if projects_dir.is_dir():
        for entry in sorted(projects_dir.iterdir()):
            if entry.name.startswith("."):
                continue
            if entry.is_symlink():
                alive = entry.is_dir()
                results.append(_check(
                    f"project-link-{entry.name}",
                    alive,
                    f"symlink {entry.name} -> {os.readlink(str(entry))} resolves",
                    f"dead symlink {entry.name} -> {os.readlink(str(entry))} (target gone)",
                    status_if_fail="ERROR",
                ))
                if alive:
                    # Check reverse-pointer marker exists
                    from .project import _marker_path, _orch_hash, PROJECT_ROOT as PR
                    target = entry.resolve()
                    marker = _marker_path(target)
                    results.append(_check(
                        f"project-marker-{entry.name}",
                        marker.exists(),
                        f"orchestrator marker exists for {entry.name}",
                        f"orchestrator marker missing for {entry.name} — run `reflect project link {entry.name}` to heal",
                    ))
            elif entry.is_dir() and (entry / "agent").is_dir():
                # Nested project — real dir at agent/projects/<name> with its own agent/ subtree.
                from .project import _marker_path
                marker = _marker_path(entry)
                results.append(_check(
                    f"project-nested-{entry.name}",
                    marker.exists(),
                    f"nested project {entry.name} registered",
                    f"nested project {entry.name} missing marker — run `reflect project link {entry}` to heal",
                ))
            else:
                results.append({
                    "check": f"project-entry-{entry.name}",
                    "status": "WARN",
                    "message": f"agent/projects/{entry.name} is not a symlink or nested project",
                })

    # Inbox staleness: unread .md files older than 60min in active track inboxes
    STALE_INBOX_THRESHOLD = 3600  # 60 minutes
    for name in _track_names():
        track_dir = TRACKS_DIR / name
        if (track_dir / "human.flag").exists():
            continue
        if (track_dir / "disabled.flag").exists():
            continue
        inbox_dir = track_dir / "inbox"
        if not inbox_dir.is_dir():
            continue
        unread = [f for f in inbox_dir.iterdir() if f.is_file() and f.suffix == ".md"]
        for msg in unread:
            try:
                age = now - msg.stat().st_mtime
            except OSError:
                continue
            if age > STALE_INBOX_THRESHOLD:
                results.append({
                    "check": f"stale-inbox-{name}",
                    "status": "WARN",
                    "message": f"unread inbox message {msg.name} in {name} is {int(age/60)}min old",
                })

    # Stale sandbox worktrees
    try:
        wt_out = subprocess.run(
            ["git", "worktree", "list", "--porcelain"],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
        )
        for line in wt_out.stdout.splitlines():
            if line.startswith("worktree ") and ".sandbox-" in line:
                wt_path = line.split("worktree ", 1)[1]
                results.append({
                    "check": "stale-sandbox",
                    "status": "WARN",
                    "message": f"stale sandbox worktree: {wt_path} — run `git worktree remove {wt_path}` to clean up",
                })
    except (OSError, subprocess.SubprocessError):
        pass

    # Orphaned sandbox branches (reflect/sandbox-* with no worktree)
    try:
        br_out = subprocess.run(
            ["git", "branch", "--list", "reflect/sandbox-*"],
            capture_output=True, text=True, cwd=str(PROJECT_ROOT),
        )
        active_sandboxes = set()
        for line in wt_out.stdout.splitlines():
            if line.startswith("branch refs/heads/reflect/sandbox-"):
                active_sandboxes.add(line.split("refs/heads/")[1])
        for line in br_out.stdout.splitlines():
            branch = line.strip().lstrip("* ")
            if branch and branch not in active_sandboxes:
                results.append({
                    "check": "orphan-sandbox-branch",
                    "status": "WARN",
                    "message": f"orphaned sandbox branch: {branch} — run `git branch -D {branch}` to clean up",
                })
    except (OSError, subprocess.SubprocessError):
        pass

    return results


def cmd_doctor(args) -> None:
    mode = OutputMode(args.output)
    checks = run_checks()

    if mode == OutputMode.JSON:
        print(json.dumps(checks, indent=2))
    else:
        # Human output
        from rich.console import Console
        from rich.table import Table

        try:
            console = Console()
            table = Table(show_header=True, header_style="bold")
            table.add_column("check")
            table.add_column("status")
            table.add_column("message")
            for c in checks:
                status = c["status"]
                style = ""
                if status == "PASS":
                    style = "green"
                elif status == "WARN":
                    style = "yellow"
                elif status == "ERROR":
                    style = "red"
                table.add_row(c["check"], f"[{style}]{status}[/{style}]", c["message"])
            console.print(table)
        except ImportError:
            # Plain text fallback
            for c in checks:
                print(f"[{c['status']}] {c['check']}: {c['message']}")

    # Exit codes
    statuses = {c["status"] for c in checks}
    if "ERROR" in statuses:
        sys.exit(2)
    elif "WARN" in statuses:
        sys.exit(1)
    else:
        sys.exit(0)
