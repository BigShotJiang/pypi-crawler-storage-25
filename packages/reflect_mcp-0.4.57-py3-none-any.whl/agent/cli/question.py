"""Question subcommands for the reflect CLI.

Thin adapter — all business logic lives in agent.cli.ops.question.
"""
from __future__ import annotations

import sys
from pathlib import Path

from .ops.question import (
    list_pending_questions,
    show_pending_question,
    resolve_pending_question_cli,
    expire_pending_question,
)


def _fmt_question_line(q: str, max_len: int = 80) -> str:
    """Truncate question to max_len chars, appending '…' if needed."""
    q = q.strip()
    if len(q) > max_len:
        return q[:max_len - 1] + "…"
    return q


def cmd_question_list(args) -> None:
    track = getattr(args, "track", None)
    results = list_pending_questions(track=track)
    if not results:
        print("(no open pending questions)")
        return
    for item in results:
        answers = " / ".join(item.get("answer_map", {}).keys())
        created = item.get("created_at", "")
        expires = item.get("expires_at", "")
        q_line = _fmt_question_line(item.get("question", ""))
        id_ = item.get("id", "")
        t = item.get("track", "")
        # Two-line block per directive format
        print(f"{t}  {id_}  {created}")
        print(f'         "{q_line}"')
        print(f"         answers: {answers}   expires: {expires}")


def cmd_question_show(args) -> None:
    result = show_pending_question(
        track=args.track,
        question_id=args.id,
    )
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["content"], end="")


def cmd_question_resolve(args) -> None:
    result = resolve_pending_question_cli(
        track=args.track,
        question_id=args.id,
        reply_token=args.reply_token,
    )
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["message"])


def cmd_question_expire(args) -> None:
    result = expire_pending_question(
        track=args.track,
        question_id=args.id,
    )
    if not result["ok"]:
        print(result["message"], file=sys.stderr)
        sys.exit(1)
    print(result["message"])
