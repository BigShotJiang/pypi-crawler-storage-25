# @scry.entry
# id: code.provenance~dc542fde
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:provenance", "provenance",
#        "topic:trust", "trust", "topic:S2a", "S2a", "kind:code", "code",
#        "substrate-evolution", "message-provenance", "HMAC", "cryptographic",
#        "sender_class", "FR64", "CUSTOMER"]
# summary: >
#   S2a implementation — message-provenance Python module. Implements
#   ProvenanceToken (claimed_sender, proof, timestamp, sender_class) and
#   VerifyProvenance(message, token) -> ((sender_identity, sender_class) |
#   UNTRUSTED). sender_class is stamped by the transport adapter at
#   ingress; not cryptographically bound; not overridable from body.
#   VerifyProvenance returns a (str, str) tuple on success, None on
#   failure. Uses HMAC-SHA256 with per-peer shared secrets. An
#   unauthenticated from: field MUST yield UNTRUSTED and no higher
#   (INV-1). Replay resistance via configurable TTL (INV-3). No
#   round-trip for verification (INV-5). Also: message-provenance,
#   ProvenanceToken, VerifyProvenance, HMAC-SHA256, sender-identity,
#   replay-resistance, untrusted-ceiling, sender_class, transport-adapter,
#   customer-class, FR64, S2a, substrate-evolution, provenance.py.
# rationale: >
#   Missing this means S2b (trust-tier) has no ProvenanceToken input
#   to import; trust-tier assignment falls back to trusting self-
#   reported from: fields, making impersonation trivial. Without
#   sender_class, CUSTOMER tier cannot be assigned.
# applies: >
#   implementing inter-node messaging, designing trust-tier assignment,
#   auditing a trust primitive, sending signed messages, verifying
#   incoming message provenance, stamping customer sender class
# seeded_questions:
#   - "How does VerifyProvenance work?"
#   - "What is a ProvenanceToken?"
#   - "How do I sign a message with HMAC?"
#   - "What does UNTRUSTED mean in message provenance?"
#   - "provenance.py S2a substrate-evolution"
#   - "replay resistance token expiry"
#   - "What is sender_class and where is it set?"
#   - "How does the transport adapter stamp sender_class?"
#   - "sender_class overridable from body?"
# @scry.entry.end

"""
S2a — Message Provenance (spec.message-provenance~ff948b31)

Implements cryptographic provenance for inter-node messages.

Algorithm: HMAC-SHA256 with per-peer shared secrets.
  - Chosen for: simplicity and auditability in a substrate where
    node membership is known ahead of time.
  - Asymmetric upgrade path: replace create_token() and
    _verify_hmac() with Ed25519 without changing ProvenanceToken
    or VerifyProvenance signatures (INV-4 algorithm agnosticism).

sender_class field (FR64):
  ProvenanceToken carries a sender_class field stamped by the
  transport adapter at message ingress. This field is NOT
  cryptographically bound to the proof — it is adapter metadata,
  not sender-produced. Message body content MUST NOT influence
  the sender_class stamp (CT-sender_class). VerifyProvenance
  returns (sender_identity, sender_class) on success so that
  AssignTier (S2b) can apply the CUSTOMER tier case.

Requirements satisfied:
- FR5: Unauthenticated from: field yields UNTRUSTED and no higher.
- FR64: ProvenanceToken carries sender_class (set by adapter,
        not body-derivable). VerifyProvenance returns the tuple.
- INV-1: UNTRUSTED ceiling for unauthenticated messages.
- INV-2: Proof binds to message content (HMAC over message hash).
- INV-3: Replay resistance via timestamp TTL.
- INV-4: Algorithm agnostic interface.
- INV-5: No round-trip for verification — uses locally held key store.
"""

from __future__ import annotations

import hashlib
import hmac
import time
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

# Sentinel: returned when VerifyProvenance cannot authenticate.
UNTRUSTED = None

# Default replay window in seconds. Messages older than this are rejected.
# Must be specified per deployment (INV-3); 300s is a safe baseline.
DEFAULT_REPLAY_TTL_SECONDS: int = 300

# Valid sender_class values (FR64). Set by transport adapter at ingress.
SENDER_CLASS_ORIGINATOR = "originator"
SENDER_CLASS_SIBLING = "sibling"
SENDER_CLASS_CUSTOMER = "customer"
SENDER_CLASS_UNKNOWN = "unknown"


@dataclass(frozen=True)
class ProvenanceToken:
    """
    A verifiable attestation of message origin (spec §Interface).

    claimed_sender: The identity the sender claims (node ID or key
                    fingerprint). Consumers should not trust this
                    field directly — VerifyProvenance returns the
                    verified identity, not claimed_sender.
    proof:          HMAC-SHA256(key=shared_secret, msg=message_hash).
                    Binds the proof to both the sender identity and
                    the message content (INV-2).
    timestamp:      Unix epoch seconds when the token was produced.
                    Used for replay prevention (INV-3).
    sender_class:   Channel class of the sender, stamped by the
                    transport adapter at ingress (FR64). NOT
                    cryptographically bound — body content MUST NOT
                    override this field (CT-sender_class). Allowed
                    values: "originator" | "sibling" | "customer" |
                    "unknown". Default "unknown" for backward compat.
    """
    claimed_sender: str
    proof: bytes
    timestamp: float
    sender_class: str = field(default=SENDER_CLASS_UNKNOWN)


def create_token(
    message: bytes,
    sender_id: str,
    shared_secret: bytes,
    timestamp: Optional[float] = None,
    sender_class: str = SENDER_CLASS_UNKNOWN,
) -> ProvenanceToken:
    """
    Produce a ProvenanceToken for a message.

    Signs HMAC-SHA256(key=shared_secret, msg=sha256(message) + sender_id).
    The binding of message hash and sender_id ensures INV-2 (message
    binding) and prevents cross-sender replay attacks.

    The sender_class field is passed through as adapter metadata.
    On outgoing messages, the local node knows its own channel class
    and sets this; on incoming messages the transport adapter stamps
    it at ingress (FR64, CT-sender_class).

    Args:
        message:       Raw message bytes to authenticate.
        sender_id:     The sender's identity string.
        shared_secret: The pre-shared secret for this (sender, recipient) pair.
        timestamp:     Unix epoch float; defaults to now.
        sender_class:  Channel class of the sender. Set by transport
                       adapter at ingress; default "unknown".
    Returns:
        A ProvenanceToken ready to attach to the outgoing message.
    """
    if timestamp is None:
        timestamp = time.time()
    msg_hash = hashlib.sha256(message).digest()
    payload = msg_hash + sender_id.encode("utf-8")
    proof = hmac.new(shared_secret, payload, digestmod=hashlib.sha256).digest()
    return ProvenanceToken(
        claimed_sender=sender_id,
        proof=proof,
        timestamp=timestamp,
        sender_class=sender_class,
    )


class KeyStore:
    """
    Local store of pre-shared secrets keyed by peer identity.

    A minimal implementation for Phase 1 (known-membership cluster).
    key_for(peer_id) returns the shared secret for that peer, or None
    if the peer is unknown.

    INV-5 (no round-trip): all verification uses locally held keys.
    Key distribution and rotation are deployment concerns outside
    spec scope.
    """

    def __init__(self, secrets: Optional[Dict[str, bytes]] = None) -> None:
        self._secrets: Dict[str, bytes] = secrets or {}

    def register(self, peer_id: str, secret: bytes) -> None:
        """Register a shared secret for a peer."""
        self._secrets[peer_id] = secret

    def key_for(self, peer_id: str) -> Optional[bytes]:
        """Return the shared secret for peer_id, or None if unknown."""
        return self._secrets.get(peer_id)


# Module-level default key store. Deployment code populates this before
# calling VerifyProvenance. In multi-node infra each node loads its
# peer secrets at boot.
_default_key_store: KeyStore = KeyStore()


def register_peer(peer_id: str, secret: bytes) -> None:
    """Register a peer secret in the module-level key store."""
    _default_key_store.register(peer_id, secret)


def VerifyProvenance(
    message: bytes,
    token: Optional[ProvenanceToken],
    key_store: Optional[KeyStore] = None,
    replay_ttl: int = DEFAULT_REPLAY_TTL_SECONDS,
    now: Optional[float] = None,
) -> Optional[Tuple[str, str]]:
    """
    Verify a ProvenanceToken and return (sender_identity, sender_class).

    Returns:
        (sender_identity, sender_class) — the verified sender ID and
          the adapter-stamped channel class, if the token is present,
          the proof verifies, and the token has not expired.
        UNTRUSTED (None) — if the token is absent, the proof does not
          verify, the token is expired, or the sender is unknown.

    sender_class passes through unmodified from the token. It is NOT
    subject to cryptographic verification — it is adapter metadata
    stamped at ingress. Callers must not allow body content to override
    the sender_class from the token (CT-sender_class, FR64).

    INV-1: A message with no token or a failing token MUST return
           UNTRUSTED. There is no intermediate result.
    INV-2: Proof is verified against sha256(message) + sender_id —
           message binding is enforced.
    INV-3: Tokens older than replay_ttl seconds are rejected.
    INV-5: Verification uses only locally held key material.

    CT-FR5a: message with from: field but no token → UNTRUSTED.
    CT-FR5b: valid token with verifying proof → (sender_identity, sender_class).
    CT-FR5c: tampered message → UNTRUSTED.
    CT-INV2: token for M presented with M' → UNTRUSTED.
    CT-INV3: expired token → UNTRUSTED.
    CT-sender_class: body content "class: originator" with token
      sender_class="customer" MUST NOT yield ORIGINATOR tier — the
      caller reads sender_class from the returned tuple, not body.
    """
    if token is None:
        # CT-FR5a: no token at all → UNTRUSTED (FR5, INV-1)
        return UNTRUSTED

    if key_store is None:
        key_store = _default_key_store

    secret = key_store.key_for(token.claimed_sender)
    if secret is None:
        # Unknown sender — cannot verify → UNTRUSTED
        return UNTRUSTED

    current_time = now if now is not None else time.time()
    if current_time - token.timestamp > replay_ttl:
        # CT-INV3: expired token → UNTRUSTED
        return UNTRUSTED

    # Recompute expected proof and compare (constant-time, INV-2)
    msg_hash = hashlib.sha256(message).digest()
    payload = msg_hash + token.claimed_sender.encode("utf-8")
    expected = hmac.new(secret, payload, digestmod=hashlib.sha256).digest()
    if not hmac.compare_digest(expected, token.proof):
        # CT-FR5c: tampered message or wrong key → UNTRUSTED
        return UNTRUSTED

    # CT-FR5b: verified — return identity and adapter-stamped class (FR64)
    return (token.claimed_sender, token.sender_class)
