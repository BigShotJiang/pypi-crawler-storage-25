# @scry.entry
# id: code.principles~de632a47
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:principles", "principles",
#        "topic:S1", "S1", "kind:code", "code", "substrate-evolution",
#        "principles-registry", "mandatory-core"]
# summary: >
#   S1 implementation — principles-registry Python module. Defines
#   PrincipleEntry, PrincipleDeclaration, and ConformanceCheck per
#   spec.principles-registry~af2bf992. ConformanceCheck(declaration,
#   mandatory_core_set) returns True iff the declaration covers every
#   mandatory-core ID. Loads principles.md at project root via
#   load_registry(). Also: principles-registry, PrincipleEntry,
#   PrincipleDeclaration, ConformanceCheck, mandatory-core, extended,
#   S1, substrate-evolution, load_registry, principles.py.
# rationale: >
#   Missing this means S2b (trust-tier) and S3a (chaos-monkey) have no
#   PrincipleDeclaration input type to import; downstream specs cannot
#   implement admission-control based on declared principles.
# applies: >
#   implementing S2b trust-tier, implementing S3a chaos-monkey,
#   checking node admission, validating principle declarations,
#   loading the principles registry
# seeded_questions:
#   - "What is a PrincipleEntry?"
#   - "How does ConformanceCheck work?"
#   - "How do I load the principles registry?"
#   - "What is a PrincipleDeclaration?"
#   - "principles.py S1 substrate-evolution"
# @scry.entry.end

"""
S1 — Principles Registry (spec.principles-registry~af2bf992)

Implements the data types and conformance check for the principles
registry. The registry is a file (principles.md at project root);
this module defines the in-memory representation and the conformance
predicate.

Requirements satisfied:
- FR1: Registry holds moral principles and ethical scruples only.
  Operating procedure is NOT a principle.
- FR2: Atomic entries, each with a unique ID and a copula-shaped claim.
- FR3: Mandatory-core vs extended classification.
- FR4: Constitutional anchor (entries carry tier classification).
- ConformanceCheck: INV-3 — a valid PrincipleDeclaration covers every
  mandatory-core ID.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import FrozenSet, List, Optional


class PrincipleTier(str, Enum):
    """Tier classification for principles (FR3 — INV-3)."""
    MANDATORY_CORE = "mandatory-core"
    EXTENDED = "extended"


@dataclass(frozen=True)
class PrincipleEntry:
    """
    A single entry in the principles registry (FR2 — INV-1, INV-2).

    id:       Unique identifier (e.g. "P1", "P2", ...).
    name:     Short canonical name (e.g. "Empathy").
    verbatim: The principle text, verbatim from the authoritative source.
              Must be a single copula-shaped universal statement.
    tier:     MANDATORY_CORE or EXTENDED (FR3).
    behavioral_expectations: Illustrative descriptions of conduct
              coherent with this principle. NOT a checklist metric.
    """
    id: str
    name: str
    verbatim: str
    tier: PrincipleTier
    behavioral_expectations: tuple[str, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class PrincipleDeclaration:
    """
    A node's declaration of which principles it affirms (FR4 — INV-3).

    A valid PrincipleDeclaration must cover all mandatory-core IDs
    in the registry. A declaration missing any mandatory-core ID is
    invalid — the declaring node cannot be admitted.

    declared_ids: frozenset of principle IDs the node declares.
    declaring_node: identity of the declaring node (for audit).
    """
    declared_ids: FrozenSet[str]
    declaring_node: str

    @classmethod
    def from_ids(
        cls,
        ids: list[str],
        declaring_node: str,
    ) -> "PrincipleDeclaration":
        """Convenience constructor from a list of IDs."""
        return cls(
            declared_ids=frozenset(ids),
            declaring_node=declaring_node,
        )


def ConformanceCheck(
    declaration: PrincipleDeclaration,
    mandatory_core_set: FrozenSet[str],
) -> bool:
    """
    Check that a PrincipleDeclaration covers every mandatory-core ID.

    Returns True iff declaration.declared_ids is a superset of
    mandatory_core_set. A declaration that is missing any mandatory-core
    ID returns False — the node is not conformant (INV-3, CT-FR4).

    Args:
        declaration:        The node's declared principles.
        mandatory_core_set: The set of IDs that are mandatory-core
                            in the current registry.
    Returns:
        True if conformant, False otherwise.
    """
    return mandatory_core_set.issubset(declaration.declared_ids)


@dataclass
class PrinciplesRegistry:
    """
    The in-memory representation of the loaded principles registry.

    entries:         All PrincipleEntry objects, in declaration order.
    mandatory_core:  frozenset of IDs whose tier == MANDATORY_CORE.
    """
    entries: List[PrincipleEntry]
    mandatory_core: FrozenSet[str]

    def get_entry(self, principle_id: str) -> Optional[PrincipleEntry]:
        """Look up a principle entry by ID."""
        for entry in self.entries:
            if entry.id == principle_id:
                return entry
        return None

    def check_declaration(self, declaration: PrincipleDeclaration) -> bool:
        """Convenience wrapper around ConformanceCheck."""
        return ConformanceCheck(declaration, self.mandatory_core)


def load_registry(
    principles_path: Optional[Path] = None,
) -> PrinciplesRegistry:
    """
    Parse principles.md and return a PrinciplesRegistry.

    The file format expected is the one authored by the architect track
    per spec.principles-registry~af2bf992. Each principle block begins
    with a header like "### P1 — Empathy" and ends before the next P-
    header or end of file.

    If principles_path is None, resolves to <project_root>/principles.md
    where project_root is determined by walking up from this file's
    location until a wake.md is found.

    FR1 constraint: operating-procedure entries (heartbeat discipline,
    scry usage, wake discipline, authority inversion) MUST NOT appear
    in the registry. This function does not enforce that constraint —
    it is an authoring constraint. Do not mine wake.md to populate the
    registry.
    """
    if principles_path is None:
        here = Path(__file__).resolve()
        for parent in here.parents:
            candidate = parent / "principles.md"
            if candidate.exists():
                principles_path = candidate
                break
    if principles_path is None or not principles_path.exists():
        # Registry not yet populated — return an empty registry.
        # A conformant implementation may have an empty mandatory-core
        # section pending originator authorization (spec §Scope).
        return PrinciplesRegistry(entries=[], mandatory_core=frozenset())

    text = principles_path.read_text(encoding="utf-8")
    entries: List[PrincipleEntry] = []

    # Match blocks like "### P1 — Empathy\n..."
    header_pat = re.compile(
        r"^#{2,4}\s+(P\d+)\s+[—–-]+\s+(.+)$",
        re.MULTILINE,
    )
    tier_pat = re.compile(
        r"\*\*Tier:\*\*\s+(.+)",
        re.IGNORECASE,
    )
    verbatim_pat = re.compile(
        r"\*\*Principle:\*\*\s+(.+)",
        re.IGNORECASE,
    )

    matches = list(header_pat.finditer(text))
    for i, match in enumerate(matches):
        pid = match.group(1)
        name = match.group(2).strip()
        block_start = match.end()
        block_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        block = text[block_start:block_end]

        verbatim_match = verbatim_pat.search(block)
        verbatim = verbatim_match.group(1).strip() if verbatim_match else ""

        tier_match = tier_pat.search(block)
        tier_raw = tier_match.group(1).strip().lower() if tier_match else "mandatory-core"
        tier = (
            PrincipleTier.EXTENDED
            if "extended" in tier_raw
            else PrincipleTier.MANDATORY_CORE
        )

        expectations: list[str] = []
        for line in block.splitlines():
            line = line.strip()
            if line.startswith("-") and verbatim not in line:
                expectations.append(line.lstrip("- ").strip())

        entries.append(PrincipleEntry(
            id=pid,
            name=name,
            verbatim=verbatim,
            tier=tier,
            behavioral_expectations=tuple(expectations),
        ))

    mandatory_core = frozenset(
        e.id for e in entries if e.tier == PrincipleTier.MANDATORY_CORE
    )
    return PrinciplesRegistry(entries=entries, mandatory_core=mandatory_core)
