# @scry.entry
# id: code.quorum~2b6c1613
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:quorum", "quorum",
#        "topic:S5a", "S5a", "kind:code", "code", "substrate-evolution",
#        "BFT", "Byzantine-fault-tolerance", "consensus", "leader-election",
#        "HotStuff", "CFT-placeholder", "n-3f+1"]
# summary: >
#   S5a implementation — quorum-consensus Python module. Implements
#   QuorumDecision, LeaderElection (term-bounded), and QuorumSize(n,f)
#   per spec.quorum-consensus~f8aad0f5. QuorumSize uses floor(2n/3)+1
#   for BFT with f Byzantine faults. Minimum cluster: 4 nodes (n>=3f+1,
#   f=1). QuorumProtocol.collect_votes() aggregates votes and returns
#   COMMIT, ABORT, TIMEOUT, or NO_QUORUM. Phase 1: CFT-grade in-memory
#   backend; full HotStuff pipeline deferred to Phase 4-5 (multi-node
#   infra). INV-5 (full BFT) documented as not-yet-satisfied. Also:
#   quorum, BFT, Byzantine fault tolerance, QuorumDecision, QuorumSize,
#   LeaderElection, HotStuff, CFT-placeholder, S5a, substrate-evolution,
#   quorum.py.
# rationale: >
#   Missing this means S5b (heartbeat-health) and S5d have no
#   QuorumDecision or LeaderElection input types; consensus-dependent
#   health checks cannot be built.
# applies: >
#   building multi-node consensus, checking quorum thresholds, running
#   leader election, implementing S5b heartbeat-health, debugging
#   quorum decisions
# seeded_questions:
#   - "How does QuorumSize work?"
#   - "What is a QuorumDecision?"
#   - "How does leader election work?"
#   - "What is the minimum cluster size?"
#   - "quorum.py S5a substrate-evolution"
#   - "BFT Byzantine fault tolerance n 3f+1"
# @scry.entry.end

"""
S5a — Quorum Consensus (spec.quorum-consensus~f8aad0f5)

Implements BFT quorum protocol for substrate-evolution consensus.

Phase 1 delivers: interface types, quorum-size derivation, and in-memory
vote aggregation. Full multi-node message passing (HotStuff pipeline,
view-change protocol) is deferred to Phase 4-5 when multi-node infra
(>=4 physical nodes) exists.

Reference: HotStuff — named informatively, not prescriptively (spec §Scope).

Requirements satisfied:
- FR-QC1: Minimum node count n >= 3f+1 enforced at QuorumProtocol init.
- FR-QC2: Leader election with term-bounded authority (LeaderElection).
- FR-QC3: QuorumSize derivation — floor(2n/3)+1 for BFT with f faults.
- FR-QC4: QuorumDecision carries outcome, rationale, term, vote sets.
- FR-QC5: Timeout detection via leader term expiry.

Not yet satisfied:
- INV-5: Full Byzantine fault tolerance requires a production BFT library
  and multi-node message passing. Phase 1 is CFT-grade in-memory only.
  Documented here to prevent future confusion.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, FrozenSet, Optional, Set


# Minimum cluster size for f=1 Byzantine fault tolerance (FR-QC1).
# n >= 3f + 1 → n >= 4 with f = 1.
MIN_CLUSTER_SIZE: int = 4
DEFAULT_FAULT_TOLERANCE: int = 1  # f = 1


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class DecisionOutcome(str, Enum):
    """
    Outcome of a quorum vote round (FR-QC4).

    COMMIT:    A quorum of nodes voted in favor; proposal is committed.
    ABORT:     Enough against-votes make quorum impossible; abort.
    TIMEOUT:   Leader term expired before quorum was reached (FR-QC5).
    NO_QUORUM: Insufficient votes so far; neither commit nor abort is
               conclusive yet.
    """
    COMMIT = "commit"
    ABORT = "abort"
    TIMEOUT = "timeout"
    NO_QUORUM = "no_quorum"


@dataclass(frozen=True)
class QuorumDecision:
    """
    The output of a completed quorum round (FR-QC4).

    outcome:       COMMIT, ABORT, TIMEOUT, or NO_QUORUM.
    topic:         Identifier for the proposal or question put to the quorum.
    rationale:     Human-readable explanation of the decision.
    term:          Leader election term in which this decision was made.
    votes_for:     Node IDs that voted in favor (may be empty on TIMEOUT).
    votes_against: Node IDs that voted against (may be empty on TIMEOUT).
    """
    outcome: DecisionOutcome
    topic: str
    rationale: str
    term: int
    votes_for: FrozenSet[str] = field(default_factory=frozenset)
    votes_against: FrozenSet[str] = field(default_factory=frozenset)


@dataclass(frozen=True)
class LeaderElection:
    """
    Leader election result with term-bounded authority (FR-QC2).

    leader_id:   The elected leader node ID.
    term:        Monotonically increasing term number.
    expires_at:  Unix epoch float; leader authority expires after this time.
                 Votes received after expiry are classified TIMEOUT (FR-QC5).
    quorum_size: Minimum vote count required to commit (from QuorumSize).
    """
    leader_id: str
    term: int
    expires_at: float
    quorum_size: int


# ---------------------------------------------------------------------------
# Public API — QuorumSize
# ---------------------------------------------------------------------------

def QuorumSize(n: int, f: int = DEFAULT_FAULT_TOLERANCE) -> int:
    """
    Compute the minimum quorum size for n nodes with f Byzantine faults
    (FR-QC3).

    Formula: floor(2n/3) + 1.

    Guarantees any two quorums share at least f+1 nodes — sufficient to
    detect (but not necessarily correct) Byzantine equivocation.

    Precondition: n >= 3f + 1. Raises ValueError otherwise (FR-QC1).

    Args:
        n: Total cluster size.
        f: Maximum Byzantine faults to tolerate.
    Returns:
        Minimum quorum size Q.
    Raises:
        ValueError if cluster is too small for the specified fault tolerance.
    """
    if n < 3 * f + 1:
        raise ValueError(
            f"Cluster too small: n={n} < 3f+1={3 * f + 1} for f={f}. "
            f"Minimum cluster size is {3 * f + 1} (MIN_CLUSTER_SIZE={MIN_CLUSTER_SIZE})."
        )
    return (2 * n) // 3 + 1


# ---------------------------------------------------------------------------
# Public API — QuorumProtocol
# ---------------------------------------------------------------------------

class QuorumProtocol:
    """
    In-memory quorum consensus protocol (FR-QC1–FR-QC5).

    Phase 1: in-process vote aggregation with deterministic leader rotation.
    Phase 4+: replace elect_leader() with a view-change sub-protocol and
    collect_votes() with the HotStuff pipeline over real network transport.

    Usage:
        protocol = QuorumProtocol(nodes={"node-a", "node-b", "node-c", "node-d"})
        leader   = protocol.elect_leader()
        decision = protocol.collect_votes(
            topic="promote-sandbox-abc",
            leader=leader,
            votes={"node-a": True, "node-b": True, "node-c": True},
        )
        assert decision.outcome == DecisionOutcome.COMMIT
    """

    def __init__(
        self,
        nodes: Set[str],
        fault_tolerance: int = DEFAULT_FAULT_TOLERANCE,
        leader_term_secs: float = 60.0,
    ) -> None:
        """
        Initialise the protocol (FR-QC1).

        Args:
            nodes:            Set of node IDs forming the cluster.
            fault_tolerance:  f — maximum Byzantine faults to tolerate.
            leader_term_secs: How long a leader's authority lasts (FR-QC5).
        Raises:
            ValueError if len(nodes) < 3*f+1.
        """
        if len(nodes) < 3 * fault_tolerance + 1:
            raise ValueError(
                f"Cluster too small: {len(nodes)} nodes < "
                f"{3 * fault_tolerance + 1} required for f={fault_tolerance}."
            )
        self.nodes: FrozenSet[str] = frozenset(nodes)
        self.fault_tolerance: int = fault_tolerance
        self.quorum_size: int = QuorumSize(len(nodes), fault_tolerance)
        self.leader_term_secs: float = leader_term_secs
        self._current_term: int = 0
        self._current_leader: Optional[LeaderElection] = None

    def elect_leader(self, now: Optional[float] = None) -> LeaderElection:
        """
        Elect a leader for a new term (FR-QC2).

        Phase 1: deterministic round-robin rotation by sorted node ID.
        Phase 4+: replace with view-change sub-protocol for BFT safety.

        Increments the internal term counter on each call. The returned
        LeaderElection expires after leader_term_secs seconds.

        Args:
            now: Current Unix time; defaults to time.time().
        Returns:
            LeaderElection with term, leader_id, expires_at, quorum_size.
        """
        if now is None:
            now = time.time()
        self._current_term += 1
        sorted_nodes = sorted(self.nodes)
        leader_idx = (self._current_term - 1) % len(sorted_nodes)
        self._current_leader = LeaderElection(
            leader_id=sorted_nodes[leader_idx],
            term=self._current_term,
            expires_at=now + self.leader_term_secs,
            quorum_size=self.quorum_size,
        )
        return self._current_leader

    def collect_votes(
        self,
        topic: str,
        leader: LeaderElection,
        votes: Dict[str, bool],
        now: Optional[float] = None,
    ) -> QuorumDecision:
        """
        Aggregate votes and produce a QuorumDecision (FR-QC4, FR-QC5).

        Votes from node IDs not in the registered cluster are silently
        discarded. Leader term expiry yields TIMEOUT (FR-QC5). A quorum
        of for-votes yields COMMIT; enough against-votes to make quorum
        impossible yields ABORT; otherwise NO_QUORUM.

        Args:
            topic:  Identifier for the proposal being voted on.
            leader: The current leader election (checked for term expiry).
            votes:  Mapping of node_id → True (for) / False (against).
            now:    Current time; defaults to time.time().
        Returns:
            QuorumDecision with outcome, rationale, term, and vote sets.
        """
        if now is None:
            now = time.time()

        # FR-QC5: leader term expiry → TIMEOUT.
        if now > leader.expires_at:
            return QuorumDecision(
                outcome=DecisionOutcome.TIMEOUT,
                topic=topic,
                rationale="leader term expired before quorum was reached",
                term=leader.term,
            )

        # Tally votes from registered cluster nodes only.
        for_votes: Set[str] = set()
        against_votes: Set[str] = set()
        for node_id, in_favor in votes.items():
            if node_id not in self.nodes:
                continue
            if in_favor:
                for_votes.add(node_id)
            else:
                against_votes.add(node_id)

        # COMMIT: quorum of for-votes.
        if len(for_votes) >= self.quorum_size:
            return QuorumDecision(
                outcome=DecisionOutcome.COMMIT,
                topic=topic,
                rationale=(
                    f"quorum reached: {len(for_votes)}/{self.quorum_size} "
                    f"votes in favor"
                ),
                term=leader.term,
                votes_for=frozenset(for_votes),
                votes_against=frozenset(against_votes),
            )

        # ABORT: enough against-votes that quorum is now impossible.
        outstanding = len(self.nodes) - len(for_votes) - len(against_votes)
        max_possible_for = len(for_votes) + outstanding
        if max_possible_for < self.quorum_size:
            return QuorumDecision(
                outcome=DecisionOutcome.ABORT,
                topic=topic,
                rationale=(
                    f"quorum impossible: max possible for-votes "
                    f"{max_possible_for} < required {self.quorum_size}"
                ),
                term=leader.term,
                votes_for=frozenset(for_votes),
                votes_against=frozenset(against_votes),
            )

        # NO_QUORUM: still waiting.
        return QuorumDecision(
            outcome=DecisionOutcome.NO_QUORUM,
            topic=topic,
            rationale=(
                f"awaiting votes: {len(for_votes)}/{self.quorum_size} "
                f"so far; {outstanding} outstanding"
            ),
            term=leader.term,
            votes_for=frozenset(for_votes),
            votes_against=frozenset(against_votes),
        )
