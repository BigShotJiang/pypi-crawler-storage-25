# @scry.entry
# id: code.trust-tier~bd6bd477
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:trust", "trust",
#        "topic:tier", "tier", "topic:S2b", "S2b", "kind:code", "code",
#        "substrate-evolution", "trust-tier", "admission-control",
#        "scrutiny", "AssignTier", "ScrutinyLevel", "AdmissionCheck",
#        "TrustTier", "FR6", "FR7", "FR64", "CUSTOMER", "sender_class",
#        "four-tier", "customer-tier"]
# summary: >
#   S2b implementation — trust-tier Python module. Maps verified sender
#   identity and sender_class to TrustTier
#   (ORIGINATOR > SIBLING > CUSTOMER > UNKNOWN) per
#   spec.trust-tier~1445aaf7. AssignTier consumes sender_identity and
#   sender_class from S2a's VerifyProvenance tuple; UNTRUSTED sentinel
#   yields UNKNOWN directly without calling AssignTier (INV-1). Four
#   tiers required for customer-inbox nodes (FR64, INV-2); three-tier
#   (no CUSTOMER) remains conformant for peer-only nodes. ScrutinyLevel
#   returns a ScrutinySpec per tier (scrutiny is monotone: INV-3).
#   AdmissionCheck gates on declared mandatory-core principles (FR7).
#   Also: trust-tier, TrustTier, AssignTier, ScrutinyLevel, ScrutinySpec,
#   AdmissionCheck, originator tier, sibling tier, customer tier, unknown
#   tier, admission, scrutiny level, S2b, substrate-evolution,
#   trust_tier.py, sender_class, four-tier, FR64.
# rationale: >
#   Missing CUSTOMER tier means customers reaching a node inbox are
#   treated as potentially-hostile UNKNOWN senders. The injection
#   surface is live the moment the chat adapter is wired.
# applies: >
#   implementing trust-tier assignment, designing admission control,
#   auditing inter-node message scrutiny, reviewing specs that consume
#   TrustTier, building routing with tier differentiation, handling
#   customer messages via chat adapter
# seeded_questions:
#   - "What are the trust tiers?"
#   - "How does AssignTier work?"
#   - "What is AdmissionCheck?"
#   - "What scrutiny applies to each tier?"
#   - "trust_tier.py S2b substrate-evolution"
#   - "TrustTier ORIGINATOR SIBLING CUSTOMER UNKNOWN scrutiny"
#   - "How is CUSTOMER tier assigned?"
#   - "What sender_class gets CUSTOMER tier?"
#   - "FR64 trust tier implementation"
# @scry.entry.end

"""
S2b — Trust Tier (spec.trust-tier~1445aaf7)

Maps a verified sender identity and sender_class to a trust tier and
defines scrutiny levels per tier, including an admission-control
mechanism that gates communication on declared mandatory-core principles.

Requirements satisfied:
- FR6: Four-tier taxonomy (ORIGINATOR, SIBLING, CUSTOMER, UNKNOWN);
       scrutiny monotone with tier (INV-3). Three-tier (no CUSTOMER)
       remains conformant for peer-only nodes.
- FR64: CUSTOMER is the fourth canonical tier, positioned between
        SIBLING and UNKNOWN. AssignTier step 3 assigns CUSTOMER when
        sender_class == "customer" and no originator/sibling match.
- FR7: AdmissionCheck gates on declared mandatory-core principles
       without bilateral negotiation (INV-5).
- INV-1: UNTRUSTED sentinel from S2a yields UNKNOWN directly; it
         MUST NOT be passed into AssignTier (no identity to look up).
- INV-2: Four-tier taxonomy required for customer-inbox nodes; three-
         tier (without CUSTOMER) remains conformant for peer-only.
- INV-3: Scrutiny is monotone:
         ORIGINATOR >= SIBLING > CUSTOMER >= UNKNOWN.
- INV-4: Admission does not verify behavioral conformance — only
         declared intent (that is S2c/S2d's concern).
- INV-5: AdmissionCheck is unilateral; no round-trip required.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import FrozenSet, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class TrustTier(str, Enum):
    """
    Four-tier taxonomy for sender identity trust (FR6, FR64).

    Ordering (highest to lowest trust):
        ORIGINATOR > SIBLING > CUSTOMER > UNKNOWN

    ORIGINATOR: Human originator or an entity with originator-level
                authority (provably signed by originator key). Highest
                trust; least restrictive scrutiny.
    SIBLING:    A known peer in the substrate — provisioned, registered,
                previously exchanged keys. Moderate trust.
    CUSTOMER:   A verified external user reaching the node via the chat
                adapter. Positioned between SIBLING and UNKNOWN (FR64).
                Assigned when sender_class == "customer" and the sender
                is neither originator nor sibling. Four tiers required
                for customer-inbox nodes; three-tier (no CUSTOMER)
                remains conformant for peer-only nodes (INV-2).
    UNKNOWN:    Not in the known-sibling registry or customer class,
                or identity could not be matched. Also assigned when
                VerifyProvenance returned UNTRUSTED (INV-1). Lowest
                trust; most restrictive scrutiny.

    Implementations may add sub-tiers (e.g. SIBLING_PROBATIONARY) but
    may not reduce below these four. Scrutiny MUST be monotone with tier.
    """
    ORIGINATOR = "originator"
    SIBLING = "sibling"
    CUSTOMER = "customer"
    UNKNOWN = "unknown"


class ActionScope(str, Enum):
    """
    The class of actions a consumer may take in response to a message
    at a given trust tier, without further verification (FR6).

    Ordered from most to least restrictive:
    READ_ONLY     < LOCAL_WRITE < NETWORK_WRITE < SPAWN < WIND_DOWN
    """
    READ_ONLY = "read_only"
    LOCAL_WRITE = "local_write"
    NETWORK_WRITE = "network_write"
    SPAWN = "spawn"
    WIND_DOWN = "wind_down"


@dataclass(frozen=True)
class ScrutinySpec:
    """
    Structured scrutiny requirements for a message at a given tier (FR6).

    max_action_scope:            The highest action class a consumer may
                                 execute in response without further check.
    requires_quorum_confirmation: Must this message's effect be confirmed
                                 by quorum before execution? True for
                                 UNKNOWN; False for SIBLING and ORIGINATOR
                                 on non-quorum-required operations (C-3:
                                 ORIGINATOR does not bypass AR1).
    require_conformance_check:  Must this sender's conformance be probed
                                 before acting on the message?
    """
    max_action_scope: ActionScope
    requires_quorum_confirmation: bool
    require_conformance_check: bool


# Normative ScrutinySpec per tier (INV-3: monotone with tier).
# Ordering: ORIGINATOR >= SIBLING > CUSTOMER >= UNKNOWN
#
# CUSTOMER scrutiny (FR64, C-CUSTOMER):
#   - max_action_scope=LOCAL_WRITE: customers may submit service
#     requests (write to local queue) but not reach out to network
#     peers or spawn/wind-down tracks.
#   - requires_quorum_confirmation=False: service-request actions
#     (submit work, request information) do not require quorum.
#     Constitutional changes, agenda reprioritization, and
#     wake.md/principles.md modifications are prohibited by scope
#     (max_action_scope cap), not by quorum gate.
#   - require_conformance_check=False: customers are not cluster
#     peers; conformance probing does not apply.
#
# CUSTOMER is strictly more permissive than UNKNOWN on
# requires_quorum_confirmation and require_conformance_check,
# and equal on max_action_scope. Monotone invariant holds.
_SCRUTINY: dict[TrustTier, ScrutinySpec] = {
    TrustTier.UNKNOWN: ScrutinySpec(
        max_action_scope=ActionScope.LOCAL_WRITE,
        requires_quorum_confirmation=True,
        require_conformance_check=True,
    ),
    TrustTier.CUSTOMER: ScrutinySpec(
        max_action_scope=ActionScope.LOCAL_WRITE,
        requires_quorum_confirmation=False,
        require_conformance_check=False,
    ),
    TrustTier.SIBLING: ScrutinySpec(
        max_action_scope=ActionScope.NETWORK_WRITE,
        requires_quorum_confirmation=False,
        require_conformance_check=False,
    ),
    TrustTier.ORIGINATOR: ScrutinySpec(
        max_action_scope=ActionScope.WIND_DOWN,
        requires_quorum_confirmation=False,   # C-3: AR1 still applies
        require_conformance_check=False,
    ),
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def AssignTier(
    sender_identity: str,
    originator_identity: Optional[str] = None,
    sibling_registry: Optional[Set[str]] = None,
    sender_class: Optional[str] = None,
) -> TrustTier:
    """
    Map a verified sender identity (and sender_class) to a TrustTier
    (FR6, FR64, INV-1, INV-2).

    Callers MUST NOT pass the UNTRUSTED sentinel (None) from S2a here.
    When VerifyProvenance returns UNTRUSTED, the caller MUST return
    TrustTier.UNKNOWN directly — there is no identity to look up.

    Four-step assignment (FR64):
      1. sender_identity matches originator_identity → ORIGINATOR
      2. sender_identity in sibling_registry → SIBLING
      3. sender_class == "customer" (from S2a IngressAnnotation) → CUSTOMER
      4. (fallthrough) → UNKNOWN

    Steps 1 and 2 take precedence over step 3: a known originator or
    sibling is never downgraded to CUSTOMER even if sender_class is
    "customer". This prevents a sibling from impersonating CUSTOMER tier.

    Args:
        sender_identity:     The verified identity string from S2a's
                             VerifyProvenance tuple. MUST NOT be None.
        originator_identity: The locally known originator key/identity.
                             If None, ORIGINATOR tier is never assigned.
        sibling_registry:    Set of known-sibling identities. If None,
                             SIBLING tier is never assigned.
        sender_class:        The sender_class from S2a's ProvenanceToken,
                             as returned in the VerifyProvenance tuple.
                             "customer" triggers CUSTOMER tier (step 3).
    Returns:
        TrustTier — ORIGINATOR, SIBLING, CUSTOMER, or UNKNOWN.
    Raises:
        ValueError if sender_identity is None (caller violated INV-1).
    """
    if sender_identity is None:
        raise ValueError(
            "AssignTier received None — caller must handle UNTRUSTED "
            "sentinel from VerifyProvenance by returning UNKNOWN directly "
            "(INV-1: UNTRUSTED must not flow into AssignTier)."
        )
    # Step 1: originator check (highest precedence)
    if originator_identity and sender_identity == originator_identity:
        return TrustTier.ORIGINATOR
    # Step 2: sibling registry check
    if sibling_registry and sender_identity in sibling_registry:
        return TrustTier.SIBLING
    # Step 3: customer class check (FR64 — sender_class from transport adapter)
    if sender_class == "customer":
        return TrustTier.CUSTOMER
    # Step 4: fallthrough → unknown
    return TrustTier.UNKNOWN


def ScrutinyLevel(tier: TrustTier) -> ScrutinySpec:
    """
    Return the ScrutinySpec for a given TrustTier (FR6, INV-3).

    Scrutiny is monotone with tier: ORIGINATOR is at least as permissive
    as SIBLING; SIBLING is strictly more permissive than UNKNOWN.

    Args:
        tier: The TrustTier to look up.
    Returns:
        ScrutinySpec describing max_action_scope and confirmation flags.
    """
    return _SCRUTINY[tier]


def AdmissionCheck(
    declaration: FrozenSet[str],
    required_principles: FrozenSet[str],
) -> bool:
    """
    Gate communication on declared mandatory-core principles (FR7).

    Returns True iff the declaration contains every ID in
    required_principles. The check is unilateral: no round-trip
    to the sender; no behavioral conformance testing (INV-4, INV-5).

    required_principles MUST include all mandatory-core principle IDs
    from the local principles.md (per S1). It MAY additionally include
    locally configured extended principles.

    Args:
        declaration:         FrozenSet of principle IDs the sender declares.
        required_principles: FrozenSet of IDs that must all be present.
    Returns:
        True if all required IDs are declared; False otherwise.
    """
    return required_principles.issubset(declaration)


# ---------------------------------------------------------------------------
# Convenience: tier from UNTRUSTED-aware call result
# ---------------------------------------------------------------------------

def tier_from_verify_result(
    verify_result: Optional[Tuple[str, str]],
    originator_identity: Optional[str] = None,
    sibling_registry: Optional[Set[str]] = None,
) -> TrustTier:
    """
    Convenience wrapper: handle the full VerifyProvenance return path.

    VerifyProvenance returns either a (sender_identity, sender_class)
    tuple or the UNTRUSTED sentinel (None). This wrapper applies INV-1
    — if the result is None, it returns UNKNOWN without calling
    AssignTier.

    Args:
        verify_result:       The return value of VerifyProvenance (S2a):
                             (sender_identity, sender_class) or None.
        originator_identity: Passed through to AssignTier if not None.
        sibling_registry:    Passed through to AssignTier if not None.
    Returns:
        TrustTier — always UNKNOWN when verify_result is None.
    """
    if verify_result is None:
        # INV-1: UNTRUSTED → UNKNOWN; do not call AssignTier.
        return TrustTier.UNKNOWN
    sender_identity, sender_class = verify_result
    return AssignTier(
        sender_identity=sender_identity,
        originator_identity=originator_identity,
        sibling_registry=sibling_registry,
        sender_class=sender_class,
    )
