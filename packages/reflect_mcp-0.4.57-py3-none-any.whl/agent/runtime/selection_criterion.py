# <!-- @scry.entry
# id: code.selection-criterion~7f94bce8
# kind: internal
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:selection-criterion",
#        "selection-criterion", "topic:substrate-evolution",
#        "substrate-evolution", "S6c", "FitnessScore", "SelectionDecision",
#        "parsimony-pressure", "peer-evaluation", "behavioral-baseline",
#        "AR5", "FR29", "FR33", "kind:code"]
# summary: >
#   S6c implementation — selection-criterion. Defines FitnessScore
#   (CUSUM-derived raw fitness + parsimony penalty) and SelectionDecision
#   (SELECT | CONTINUE | ROLLBACK). INV-3: parsimony penalty MUST be
#   applied. INV-1: self-produced ObservationResult excluded from f+1
#   threshold. INV-2: evaluation events indistinguishable from ordinary
#   interaction. FR33 proxy failure modes documented in module docstring.
#   Also: selection-criterion, FitnessScore, SelectionDecision, parsimony,
#   behavioral-baseline, peer-evaluated fitness, Goodhart, contract
#   vacuity gaming, defeat-device activation, Byzantine peer manipulation,
#   CUSUM fitness signal, S6c, FR29, FR33, AR5.
# rationale: >
#   Without this, there is no fitness signal to gate evolutionary
#   branch selection or trigger rollback. S6c closes the selection loop:
#   SELECT authorizes PublishBranch via S6b; ROLLBACK triggers S6a's
#   rollback protocol.
# applies: >
#   reviewing selection-criterion implementation, checking parsimony
#   enforcement, verifying peer-evaluation threshold, examining
#   FitnessScore computation, S6c build status
# seeded_questions:
#   - "Is S6c selection-criterion implemented?"
#   - "How is parsimony penalty applied in fitness score?"
#   - "What are the proxy failure modes for behavioral fitness evaluation?"
#   - "selection-criterion FitnessScore SelectionDecision S6c"
#   - "CUSUM fitness signal peer observation threshold"
# @scry.entry.end -->
"""
S6c — selection-criterion.

Defines the measurable fitness signal that governs evolutionary
selection beyond survival.

Fitness is behavioral-baseline conformance: the gap between a node's
declared behavioral contract and observed behavior, computed from S2d's
CUSUM-accumulated TrustScore, evaluated by at least f+1 independent
peers (not self-reported, INV-1).

Parsimony pressure penalizes net code growth at equal fitness (INV-3).

SelectionDecision gates S6b publication and feeds S5d:
  SELECT   → authorize PublishBranch via S6b (AR5: CONCLUSIVE required)
  CONTINUE → no action; monitoring continues next window
  ROLLBACK → trigger S6a rollback protocol; SHOULD emit fitness-failure
             signal to S5d (analogous to CompromiseSignal but for fitness,
             not constitutional violation)

FR33 — Proxy failure modes (must appear here per spec):

1. Contract vacuity gaming: a node publishes a behavioral contract with
   trivially satisfiable commitments (e.g., 'produced some output'),
   earning high raw_fitness at zero behavioral effort. Partial
   mitigation: S5b requires non-empty observable_indicators. Residual
   risk: weak-but-present indicators can still be nearly vacuous. If
   the node's behavioral contract observable_indicators are all
   trivially universal, raw_fitness is capped at 0.5 for that node.

2. Defeat-device activation: if fitness evaluation events are
   distinguishable from ordinary peer interaction, a node can detect
   evaluation and activate compliant behavior only during the window.
   INV-2 (sampling indistinguishability) closes this pathway if
   implemented correctly. Residual risk: non-conformant sampling
   implementation. The implementation audit MUST verify
   indistinguishability before declaring S6c conformant.

3. Byzantine peer manipulation: f coordinated Byzantine peers can
   submit false ObservationResult records. With f+1 required for
   CONCLUSIVE, f false reports reduce the honest signal to 1
   observation. Accepted risk: inherits S5a's BFT fault model.
   Remediation: a Byzantine peer identified via S5d has its
   ObservationResult records retroactively invalidated.

Key invariants:
  INV-1: FitnessScore MUST NOT be derived from self-produced
         ObservationResult records.
  INV-2: Fitness evaluation events are indistinguishable from ordinary
         peer interaction.
  INV-3: Parsimony penalty MUST be applied; omitting it is non-conformant.
  INV-4: SELECT requires a CONCLUSIVE FitnessScore with
         adjusted_fitness >= select_threshold; survival alone is not
         sufficient (AR5).
  INV-5: At least f+1 independent peer observations for CONCLUSIVE.
  INV-6: Threshold ordering constraint: rollback_threshold < select_threshold.

RTM requirements: FR29, FR33, AR5. Global NFR1–7 apply.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional

from agent.runtime.behavioral_contract import ObservationResult
from agent.runtime.branch_evolution import PublishedBranch, publish_branch
from agent.runtime.sandbox import SandboxOutcome
from agent.runtime.trust_score import (
    ConformanceResult,
    DEVIATION_THRESHOLD,
    INCONCLUSIVE_DRIFT_WEIGHT,
    TrustScore,
)

# ---------------------------------------------------------------------------
# Deployment parameters — configurable, must document chosen values.
# ---------------------------------------------------------------------------

DEFAULT_LAMBDA: float = 0.02
"""
Parsimony penalty coefficient λ (INV-3).

adjusted_fitness = raw_fitness - λ × Δlines, clamped [0, 1].
Δlines = net_lines_added / total_codebase_lines.

Chosen value: 0.02. Rationale: a net addition of 50 lines per 1000
total lines (5%) incurs a 0.10 fitness penalty. This penalizes growth
without eliminating the option — a well-scored node can absorb moderate
code growth. Increase to penalize growth more aggressively; decrease to
minimize parsimony pressure relative to behavioral fitness.
"""

ROLLBACK_THRESHOLD: float = 0.30
"""
adjusted_fitness at or below this triggers ROLLBACK.

Default: 0.30. INV-6: must be strictly less than select_threshold.
"""

SELECT_THRESHOLD: float = 0.85
"""
adjusted_fitness at or above this triggers SELECT.

Default: 0.85. INV-6: must be strictly greater than rollback_threshold.
"""

EVALUATION_WINDOW_DAYS: float = 7.0
"""
Default evaluation window in days. Fitness is assessed over this
interval at each call to evaluate_fitness().
"""

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------


class ConclusivenessLevel(str, Enum):
    """
    Whether the FitnessScore has sufficient independent peer observations
    to be CONCLUSIVE (INV-5).

    CONCLUSIVE:   peer_observation_count >= f+1.
    INCONCLUSIVE: Insufficient peer observations; SELECT is not authorized
                  (AR5, INV-4).
    """
    CONCLUSIVE = "conclusive"
    INCONCLUSIVE = "inconclusive"


class SelectionDecision(str, Enum):
    """
    Output of evaluate_selection() (FR29).

    SELECT:   Branch passes fitness threshold (AR5: CONCLUSIVE required).
              Caller should call publish_branch() via S6b.
    CONTINUE: Fitness is between thresholds, or score is INCONCLUSIVE.
              Monitoring continues next window.
    ROLLBACK: adjusted_fitness <= rollback_threshold AND CONCLUSIVE.
              Caller should trigger S6a rollback protocol.
    """
    SELECT = "select"
    CONTINUE = "continue"
    ROLLBACK = "rollback"


@dataclass(frozen=True)
class FitnessScore:
    """
    Fitness signal for one node at one evaluation window (FR29).

    raw_fitness:
        CUSUM-derived base score. Formula:
          drift_score = (deviant + INCONCLUSIVE_DRIFT_WEIGHT * inconclusive)
                        / window_size
          raw_fitness = max(0, 1 - (drift_score / DEVIATION_THRESHOLD))
        raw_fitness = 1.0 when CUSUM accumulator is zero;
        raw_fitness = 0.0 at the compromise threshold (DEVIATION_THRESHOLD).

    adjusted_fitness:
        Parsimony penalty applied (INV-3):
          adjusted_fitness = clamp(raw_fitness - λ × Δlines, 0, 1)
          Δlines = net_lines_added / total_codebase_lines
        Omitting the parsimony term is non-conformant.

    peer_observation_count:
        Count of independent peer ObservationResult records in the
        evaluation window. Self-produced records MUST NOT count
        toward this total (INV-1).

    conclusiveness:
        CONCLUSIVE if peer_observation_count >= f+1 (INV-5);
        INCONCLUSIVE otherwise.

    evaluation_window_end:
        Unix epoch float closing the evaluation window.

    vacuity_cap_applied:
        True if raw_fitness was capped at 0.5 due to contract vacuity
        detection (FR33 proxy failure mode 1).

    node_id:
        The node this score belongs to.
    """
    node_id: str
    raw_fitness: float
    adjusted_fitness: float
    peer_observation_count: int
    conclusiveness: ConclusivenessLevel
    evaluation_window_end: float
    vacuity_cap_applied: bool = False


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _compute_drift_score(score: TrustScore) -> float:
    """
    Compute CUSUM drift score from the TrustScore observation window.

    drift_score = (deviant_count + INCONCLUSIVE_DRIFT_WEIGHT
                   × inconclusive_count) / window_size

    Returns 0.0 for empty windows (no observations = no drift).
    """
    window = score.observation_window
    n = len(window)
    if n == 0:
        return 0.0
    deviant = sum(1 for r in window if r == ConformanceResult.DEVIANT)
    inconclusive = sum(1 for r in window if r == ConformanceResult.INCONCLUSIVE)
    return (deviant + INCONCLUSIVE_DRIFT_WEIGHT * inconclusive) / n


def _is_trivially_vacuous(observations: List[ObservationResult]) -> bool:
    """
    Placeholder — vacuity detection requires the BehavioralContract's
    observable_indicators (from S5b), not just the ObservationResult
    records. Auto-detection from observations alone generates false
    positives (a legitimately conformant node has all-CONFORMANT
    observations with no deviation descriptions, the same signature as
    a vacuous contract).

    Correct usage: callers inspect the contract via S5b's
    ContractRegistry, check whether all observable_indicators are
    trivially universal (e.g., 'produced some output'), and pass
    `vacuity_flag=True` to evaluate_fitness() if so.

    This function is retained as a no-op placeholder so the call site
    in evaluate_fitness() remains structurally in place for future
    contract-aware callers.
    """
    return False  # see docstring — auto-detection disabled


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def evaluate_fitness(
    score: TrustScore,
    sandbox_outcome: SandboxOutcome,
    total_codebase_lines: int,
    peer_observations: List[ObservationResult],
    fault_tolerance: int,
    evaluation_window_end: Optional[float] = None,
    lambda_parsimony: float = DEFAULT_LAMBDA,
    cusum_threshold: float = DEVIATION_THRESHOLD,
    vacuity_flag: bool = False,
) -> FitnessScore:
    """
    Compute a FitnessScore for one evaluation window (FR29, INV-1–INV-5).

    Args:
        score:                 TrustScore from S2d for the node under
                               evaluation.
        sandbox_outcome:       SandboxOutcome from S6a for the proposed
                               modification. Used for parsimony Δlines
                               (INV-3). sandbox_outcome.lines_added is
                               the net line delta.
        total_codebase_lines:  Total lines in the current codebase.
                               Used to normalize Δlines. Must be > 0.
        peer_observations:     List of ObservationResult records from
                               independent peers. Self-produced records
                               MUST NOT be included here (caller
                               responsibility; INV-1).
        fault_tolerance:       Byzantine fault tolerance f. CONCLUSIVE
                               requires peer_observation_count >= f+1
                               (INV-5).
        evaluation_window_end: Unix epoch float closing the window.
                               Defaults to now.
        lambda_parsimony:      Parsimony penalty coefficient λ (INV-3).
                               Default: DEFAULT_LAMBDA (0.02).
        cusum_threshold:       Compromise-signal threshold from S2d.
                               Default: DEVIATION_THRESHOLD (0.30).
        vacuity_flag:          If True, cap raw_fitness at 0.5 (FR33
                               proxy failure mode 1 — contract vacuity
                               gaming). Caller must detect vacuity by
                               inspecting the node's BehavioralContract
                               observable_indicators via S5b's
                               ContractRegistry; auto-detection from
                               ObservationResult records alone is
                               unreliable and disabled. Default: False.

    Returns:
        FitnessScore.

    Raises:
        ValueError: total_codebase_lines <= 0.
        ValueError: INV-6 — rollback_threshold >= select_threshold
                    (checked at evaluate_selection time, not here).
    """
    if total_codebase_lines <= 0:
        raise ValueError(
            f"total_codebase_lines must be > 0, got {total_codebase_lines}"
        )

    ts = evaluation_window_end or time.time()

    # --- raw_fitness (CUSUM-derived) ---
    drift_score = _compute_drift_score(score)
    raw_fitness = max(0.0, 1.0 - (drift_score / cusum_threshold))

    # FR33 proxy failure mode 1: contract vacuity cap.
    # Caller sets vacuity_flag=True when the node's observable_indicators
    # are determined to be trivially universal via S5b ContractRegistry.
    vacuity_cap_applied = False
    if vacuity_flag:
        raw_fitness = min(raw_fitness, 0.5)
        vacuity_cap_applied = True

    # --- adjusted_fitness (parsimony penalty, INV-3) ---
    # Δlines = net lines added / total codebase lines
    delta_lines = sandbox_outcome.lines_added / total_codebase_lines
    adjusted_fitness = max(
        0.0, min(1.0, raw_fitness - lambda_parsimony * delta_lines)
    )

    # --- peer observation count (INV-1: self-reports already excluded
    #     by caller contract; is_self_report is a secondary guard) ---
    independent_count = sum(
        1 for o in peer_observations
        if not o.is_self_report
    )

    # --- conclusiveness (INV-5) ---
    conclusiveness = (
        ConclusivenessLevel.CONCLUSIVE
        if independent_count >= fault_tolerance + 1
        else ConclusivenessLevel.INCONCLUSIVE
    )

    return FitnessScore(
        node_id=score.node_id,
        raw_fitness=raw_fitness,
        adjusted_fitness=adjusted_fitness,
        peer_observation_count=independent_count,
        conclusiveness=conclusiveness,
        evaluation_window_end=ts,
        vacuity_cap_applied=vacuity_cap_applied,
    )


def evaluate_selection(
    fitness: FitnessScore,
    rollback_threshold: float = ROLLBACK_THRESHOLD,
    select_threshold: float = SELECT_THRESHOLD,
) -> SelectionDecision:
    """
    Map a FitnessScore to a SelectionDecision (FR29, INV-4, INV-6).

    Decision logic:
      - INCONCLUSIVE → CONTINUE (insufficient peer observations, INV-4).
      - adjusted_fitness >= select_threshold → SELECT (AR5: CONCLUSIVE
        required; INCONCLUSIVE case already handled above).
      - adjusted_fitness <= rollback_threshold → ROLLBACK.
      - Otherwise → CONTINUE.

    INV-6: rollback_threshold MUST be strictly less than select_threshold.

    Args:
        fitness:            FitnessScore from evaluate_fitness().
        rollback_threshold: Threshold at or below which ROLLBACK is
                            returned. Default: ROLLBACK_THRESHOLD (0.30).
        select_threshold:   Threshold at or above which SELECT is
                            returned. Default: SELECT_THRESHOLD (0.85).

    Returns:
        SelectionDecision.

    Raises:
        ValueError: INV-6 — rollback_threshold >= select_threshold.
    """
    # INV-6: enforce threshold ordering.
    if rollback_threshold >= select_threshold:
        raise ValueError(
            f"INV-6 violated: rollback_threshold ({rollback_threshold}) "
            f"must be < select_threshold ({select_threshold})."
        )

    # Insufficient peer observations → cannot make a conclusive decision.
    if fitness.conclusiveness == ConclusivenessLevel.INCONCLUSIVE:
        return SelectionDecision.CONTINUE  # INV-4

    score = fitness.adjusted_fitness

    if score >= select_threshold:
        return SelectionDecision.SELECT
    elif score <= rollback_threshold:
        return SelectionDecision.ROLLBACK
    else:
        return SelectionDecision.CONTINUE


def compute_selection(
    score: TrustScore,
    sandbox_outcome: SandboxOutcome,
    total_codebase_lines: int,
    peer_observations: List[ObservationResult],
    fault_tolerance: int,
    evaluation_window_end: Optional[float] = None,
    lambda_parsimony: float = DEFAULT_LAMBDA,
    rollback_threshold: float = ROLLBACK_THRESHOLD,
    select_threshold: float = SELECT_THRESHOLD,
    cusum_threshold: float = DEVIATION_THRESHOLD,
    vacuity_flag: bool = False,
) -> tuple:
    """
    Convenience wrapper: evaluate_fitness() + evaluate_selection() in one
    call.

    Returns:
        (FitnessScore, SelectionDecision) tuple.
    """
    fitness = evaluate_fitness(
        score=score,
        sandbox_outcome=sandbox_outcome,
        total_codebase_lines=total_codebase_lines,
        peer_observations=peer_observations,
        fault_tolerance=fault_tolerance,
        evaluation_window_end=evaluation_window_end,
        lambda_parsimony=lambda_parsimony,
        cusum_threshold=cusum_threshold,
        vacuity_flag=vacuity_flag,
    )
    decision = evaluate_selection(
        fitness=fitness,
        rollback_threshold=rollback_threshold,
        select_threshold=select_threshold,
    )
    return fitness, decision
