# @scry.entry
# id: code.test-substrate-s8~1afbf850
# kind: code
# status: active
# weight: 0.85
# tags: ["scope:substrate", "substrate", "topic:tests", "tests",
#        "topic:S8", "S8", "kind:code", "code",
#        "substrate-evolution", "customer-chat-adapter", "pytest",
#        "send_message", "create_session", "get_or_resume_session",
#        "is_session_expired", "close_session", "make_reply_to_url",
#        "TransportAdapter", "ChatMessage", "Session", "WebhookEvent",
#        "IngressAnnotation", "INV-1", "INV-2", "INV-3", "INV-4",
#        "INV-5", "FR65", "FR66", "FR67", "FR68", "FR69", "FR70",
#        "FR71", "FR72"]
# summary: >
#   S8 substrate-evolution test suite. Covers customer_chat_adapter.py:
#   create_session (state=active, distinct UUIDs, FR65), get_or_resume_session
#   (INV-4 stable session_id on reconnect, different node_id isolation,
#   closed-session exclusion, FR66-FR68), is_session_expired (false for
#   fresh, true for stale, custom timeout, FR69), close_session (state=closed
#   immutability, FR70), make_reply_to_url (FR72 canonical https form),
#   send_message (INV-1 fire-and-forget, inbox file written, FR71),
#   dataclass sanity (IngressAnnotation, ChatMessage, WebhookEvent fields),
#   TransportAdapter Protocol satisfiability. Also: test_substrate_s8,
#   pytest, S8 tests, customer-chat-adapter, send_message, create_session,
#   get_or_resume_session, is_session_expired, close_session,
#   make_reply_to_url, TransportAdapter, Session, ChatMessage,
#   IngressAnnotation, WebhookEvent, INV-1 INV-2 INV-4 FR72.
# rationale: >
#   Without this, S8 has zero test coverage. Broken INV-4 (session_id
#   drift on reconnect) breaks reply_to webhook routing silently.
#   Broken INV-1 (blocking send_message) deadlocks delivery with no error.
# applies: >
#   running substrate-evolution tests, auditing FR65-FR72 compliance,
#   verifying INV-1 fire-and-forget, checking INV-4 session_id stability,
#   debugging customer-chat-adapter behavior
# seeded_questions:
#   - "Are there tests for customer_chat_adapter.py?"
#   - "Are there tests for S8?"
#   - "Is INV-4 session_id stability tested?"
#   - "Is send_message INV-1 fire-and-forget tested?"
#   - "S8 test coverage customer chat adapter"
#   - "test_substrate_s8"
# @scry.entry.end

"""
Test suite for S8 — customer_chat_adapter.py.

Each test cites the FR or invariant it exercises in its docstring.
"""

import os
import time

import pytest

from agent.runtime.customer_chat_adapter import (
    ChatMessage,
    IngressAnnotation,
    Session,
    TransportAdapter,
    WebhookEvent,
    close_session,
    create_session,
    get_or_resume_session,
    is_session_expired,
    make_reply_to_url,
    send_message,
)


# ---------------------------------------------------------------------------
# create_session
# ---------------------------------------------------------------------------

def test_create_session_returns_active_session():
    """FR65: create_session returns Session with state='active'."""
    session = create_session("cust-1", "main")
    assert session.state == "active"
    assert session.customer_id == "cust-1"
    assert session.node_id == "main"
    assert isinstance(session.session_id, str)
    assert len(session.session_id) > 0


def test_create_session_last_active_is_recent():
    """FR65: last_active is within 2 seconds of now."""
    before = time.time()
    session = create_session("cust-2", "main")
    after = time.time()
    assert before <= session.last_active <= after + 0.1


def test_create_session_distinct_uuids():
    """FR65: two create_session calls produce different session_ids."""
    s1 = create_session("cust-3", "main")
    s2 = create_session("cust-3", "main")
    assert s1.session_id != s2.session_id


# ---------------------------------------------------------------------------
# get_or_resume_session
# ---------------------------------------------------------------------------

def test_get_or_resume_session_creates_new_when_empty():
    """INV-4, FR66: creates and stores a new session when dict is empty."""
    sessions = {}
    session = get_or_resume_session("cust-a", "main", sessions)
    assert session.state == "active"
    assert session.customer_id == "cust-a"
    assert session.session_id in sessions


def test_get_or_resume_session_reuses_session_id():
    """INV-4, FR67: second call with same (customer_id, node_id) returns
    the SAME session_id, not a new one."""
    sessions = {}
    s1 = get_or_resume_session("cust-b", "main", sessions)
    s2 = get_or_resume_session("cust-b", "main", sessions)
    assert s1.session_id == s2.session_id


def test_get_or_resume_session_different_node_gets_different_session():
    """FR66: different node_id gets a different session_id."""
    sessions = {}
    s1 = get_or_resume_session("cust-c", "node-a", sessions)
    s2 = get_or_resume_session("cust-c", "node-b", sessions)
    assert s1.session_id != s2.session_id


def test_get_or_resume_session_closed_not_reused():
    """INV-4, FR68: closed session is NOT reused; a new session is
    created for the same (customer_id, node_id) pair."""
    sessions = {}
    s1 = get_or_resume_session("cust-d", "main", sessions)
    sessions[s1.session_id] = close_session(s1)
    s2 = get_or_resume_session("cust-d", "main", sessions)
    assert s2.session_id != s1.session_id
    assert s2.state == "active"


# ---------------------------------------------------------------------------
# is_session_expired
# ---------------------------------------------------------------------------

def test_is_session_expired_returns_false_for_fresh_session():
    """FR69: session with last_active=now is NOT expired."""
    session = create_session("cust-e", "main")
    assert is_session_expired(session) is False


def test_is_session_expired_returns_true_for_stale_session():
    """FR69: session with last_active 1801 seconds ago IS expired
    (just over the 1800 second default timeout)."""
    session = create_session("cust-f", "main")
    session.last_active = time.time() - 1801
    assert is_session_expired(session) is True


def test_is_session_expired_respects_custom_timeout():
    """FR69: custom timeout_secs parameter is respected."""
    session = create_session("cust-g", "main")
    session.last_active = time.time() - 61
    # 60-second timeout: should be expired
    assert is_session_expired(session, timeout_secs=60) is True
    # 120-second timeout: should NOT be expired
    assert is_session_expired(session, timeout_secs=120) is False


# ---------------------------------------------------------------------------
# close_session
# ---------------------------------------------------------------------------

def test_close_session_returns_closed_state():
    """FR70: close_session returns a Session with state='closed'."""
    session = create_session("cust-h", "main")
    closed = close_session(session)
    assert closed.state == "closed"


def test_close_session_does_not_mutate_original():
    """FR70: close_session does not mutate the original Session."""
    session = create_session("cust-i", "main")
    original_state = session.state
    close_session(session)
    assert session.state == original_state == "active"


# ---------------------------------------------------------------------------
# make_reply_to_url
# ---------------------------------------------------------------------------

def test_make_reply_to_url_canonical_form():
    """FR72: make_reply_to_url returns the canonical
    https://<domain>/webhook/<session_id> form."""
    url = make_reply_to_url("chat.example.com", "abc-123")
    assert url == "https://chat.example.com/webhook/abc-123"


def test_make_reply_to_url_round_trip():
    """FR72: URL contains domain and session_id in expected positions."""
    domain = "chat.myapp.io"
    session_id = "deadbeef-1234"
    url = make_reply_to_url(domain, session_id)
    assert url.startswith("https://")
    assert domain in url
    assert session_id in url
    assert f"/webhook/{session_id}" in url


# ---------------------------------------------------------------------------
# send_message
# ---------------------------------------------------------------------------

def test_send_message_writes_inbox_file_and_returns_none(tmp_path, monkeypatch):
    """INV-1, FR71: send_message writes a file to the node inbox and
    returns None (fire-and-forget). Uses tmp_path + REFLECT_PROJECT_ROOT
    env var to avoid writing to the actual working directory."""
    monkeypatch.setenv("REFLECT_PROJECT_ROOT", str(tmp_path))

    result = send_message(to="main", body="hello from customer")

    # INV-1: must return None
    assert result is None

    # File was written to the expected inbox directory
    inbox_dir = tmp_path / "agent" / "runtime" / "tracks" / "main" / "inbox"
    assert inbox_dir.exists()
    files = list(inbox_dir.glob("*-customer.md"))
    assert len(files) == 1

    content = files[0].read_text(encoding="utf-8")
    assert "to: main" in content
    assert "from: customer" in content
    assert "hello from customer" in content


def test_send_message_includes_reply_to(tmp_path, monkeypatch):
    """FR71, FR72: send_message embeds reply_to in the written file."""
    monkeypatch.setenv("REFLECT_PROJECT_ROOT", str(tmp_path))
    reply_url = "https://chat.example.com/webhook/session-99"

    send_message(to="portal", body="hi", reply_to=reply_url)

    inbox_dir = tmp_path / "agent" / "runtime" / "tracks" / "portal" / "inbox"
    files = list(inbox_dir.glob("*-customer.md"))
    content = files[0].read_text(encoding="utf-8")
    assert reply_url in content


# ---------------------------------------------------------------------------
# Dataclass sanity
# ---------------------------------------------------------------------------

def test_ingress_annotation_sender_class_round_trips():
    """INV-2: IngressAnnotation.sender_class is set and accessible."""
    ann = IngressAnnotation(sender_class="customer")
    assert ann.sender_class == "customer"


def test_webhook_event_fields_accessible():
    """FR72, INV-5: WebhookEvent fields (type, session_id, body)
    are accessible after construction."""
    event = WebhookEvent(type="reply", session_id="sess-42", body="ok")
    assert event.type == "reply"
    assert event.session_id == "sess-42"
    assert event.body == "ok"


def test_chat_message_transport_preserved():
    """FR65: ChatMessage.transport value is preserved after construction."""
    msg = ChatMessage(
        session_id="s-1",
        customer_id="cust-j",
        body="test body",
        transport="chat",
    )
    assert msg.transport == "chat"
    assert msg.body == "test body"


# ---------------------------------------------------------------------------
# TransportAdapter Protocol satisfiability
# ---------------------------------------------------------------------------

def test_transport_adapter_protocol_satisfiable():
    """INV-2, INV-3: A minimal conformant class with the correct deliver()
    signature is constructible and callable without raising."""

    class MockAdapter:
        def deliver(
            self,
            msg: ChatMessage,
            node_id: str,
            sender_class: str,
        ) -> None:
            """Minimal conformant deliver implementation."""
            pass

    adapter = MockAdapter()
    msg = ChatMessage(
        session_id="s-2",
        customer_id="cust-k",
        body="mock body",
        transport="chat",
    )
    # Should not raise
    result = adapter.deliver(msg, "main", "customer")
    assert result is None
