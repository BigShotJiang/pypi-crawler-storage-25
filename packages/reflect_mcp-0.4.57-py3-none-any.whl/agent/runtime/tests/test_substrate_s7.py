# @scry.entry
# id: code.test-substrate-s7~b088cdcf
# kind: code
# status: active
# weight: 0.85
# tags: ["scope:substrate", "substrate", "topic:tests", "tests",
#        "topic:S7a", "S7a", "topic:S7b", "S7b", "topic:S7c", "S7c",
#        "kind:code", "code", "substrate-evolution", "pytest",
#        "node-runtime", "inter-node-transport", "cluster-harness",
#        "NodeIdentity", "NodeEndpoint", "Node", "generate_keypair",
#        "MessageEnvelope", "VoteMessage", "HeartbeatMessage",
#        "LoopbackBackend", "build_envelope", "LoopbackHarness",
#        "ClusterSnapshot", "ClusterConfig", "NodeState",
#        "AR9", "FR34", "FR35", "FR36", "FR38", "FR39",
#        "FR41", "FR42", "FR43", "FR46", "FR47", "FR52"]
# summary: >
#   S7 substrate-evolution test suite. Covers S7a (node_runtime.py:
#   generate_keypair distinct keys, Node stable node_id, NodeIdentity
#   public_key, NodeEndpoint addressable, join/leave cluster state,
#   rotate_keypair updates identity, FR34-FR39), S7b (inter_node_
#   transport.py: build_envelope MessageEnvelope, LoopbackBackend
#   send+receive loopback delivery, _verify_envelope_signature tamper
#   rejection, FR41-FR46, FR57-FR63), S7c (cluster_harness.py:
#   LoopbackHarness provision+deprovision, ClusterSnapshot state,
#   NodeState STARTING/ACTIVE, AR9 harness-not-quorum, _quorum_params
#   quorum_size+fault_budget, FR47-FR56, AR9, AR10). Also:
#   test_substrate_s7, pytest, S7a S7b S7c tests, node runtime
#   transport cluster harness keypair identity endpoint loopback
#   envelope quorum params.
# rationale: >
#   Without this, S7a/S7b/S7c have zero test coverage. Broken AR9
#   (harness-not-quorum) or key-rotation identity contamination
#   go undetected.
# applies: >
#   running substrate-evolution tests, auditing FR34-FR56 compliance,
#   verifying AR9 harness-not-quorum, checking keypair rotation,
#   debugging node identity or transport envelope behavior
# seeded_questions:
#   - "Are there tests for node_runtime.py?"
#   - "Are there tests for inter_node_transport.py?"
#   - "Are there tests for cluster_harness.py?"
#   - "test_substrate_s7 what does it cover"
#   - "S7a S7b S7c test suite"
#   - "AR9 harness not quorum node tests"
#   - "generate_keypair distinct keys tests"
#   - "LoopbackBackend send receive loopback tests"
#   - "_quorum_params quorum_size fault_budget tests"
# @scry.entry.end

"""
S7 substrate-evolution tests.

Covers:
  S7a — node_runtime.py        (NodeIdentity, NodeEndpoint, Node,
                                 generate_keypair, FR34-FR39)
  S7b — inter_node_transport.py (MessageEnvelope, VoteMessage,
                                  HeartbeatMessage, ObservationMessage,
                                  BranchMessage, LoopbackBackend,
                                  build_envelope, FR41-FR46, FR57-FR63)
  S7c — cluster_harness.py     (ClusterSnapshot, ClusterConfig,
                                  LoopbackHarness, NodeState, NodeStatus,
                                  _quorum_params, AR9, FR47-FR56)

All loopback / in-process paths only — no SSH, no real DO API.

Version history:
  v0.1.0 — initial S7a + S7b + S7c coverage
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# S7a — Node Runtime
# ---------------------------------------------------------------------------

from agent.runtime.node_runtime import (
    Node,
    NodeEndpoint,
    NodeIdentity,
    generate_keypair,
)


class TestGenerateKeypair:
    """S7a — generate_keypair (FR37)."""

    def test_returns_two_bytes_objects(self):
        """FR37: generate_keypair returns a (public_key, private_key) pair."""
        pub, priv = generate_keypair()
        assert isinstance(pub, bytes)
        assert isinstance(priv, bytes)

    def test_keys_are_distinct(self):
        """FR37: public key and private key are not identical bytes."""
        pub, priv = generate_keypair()
        assert pub != priv

    def test_each_call_produces_unique_keys(self):
        """FR37: two generate_keypair calls produce different key pairs."""
        pub1, _ = generate_keypair()
        pub2, _ = generate_keypair()
        assert pub1 != pub2


class TestNodeIdentity:
    """S7a — NodeIdentity fields (FR34, FR35)."""

    def test_identity_has_node_id_and_public_key(self):
        """FR34/FR35: NodeIdentity carries node_id and public_key."""
        pub, _ = generate_keypair()
        identity = NodeIdentity(node_id="test-node", public_key=pub)
        assert identity.node_id == "test-node"
        assert identity.public_key == pub

    def test_identity_node_id_is_string(self):
        """FR34: node_id is a string type."""
        pub, _ = generate_keypair()
        identity = NodeIdentity(node_id="n-001", public_key=pub)
        assert isinstance(identity.node_id, str)


class TestNodeEndpoint:
    """S7a — NodeEndpoint addressability (FR36)."""

    def test_endpoint_has_address(self):
        """FR36: NodeEndpoint carries a transport address string."""
        endpoint = NodeEndpoint(node_id="n-001", address="127.0.0.1:9000")
        assert endpoint.address == "127.0.0.1:9000"

    def test_endpoint_carries_node_id(self):
        """FR36: NodeEndpoint references its owner by node_id."""
        endpoint = NodeEndpoint(node_id="n-002", address="127.0.0.1:9001")
        assert endpoint.node_id == "n-002"


class TestNodeLifecycle:
    """S7a — Node creation, join, leave, and keypair rotation (FR38, FR39)."""

    def _make_node(self, tmpdir: Path, name: str = "node-alpha") -> Node:
        state_path = tmpdir / f"{name}.json"
        return Node(state_path=state_path, address=f"127.0.0.1:9500")

    def test_node_has_stable_node_id(self, tmp_path):
        """FR38: A Node's node_id is stable across instantiations."""
        node = self._make_node(tmp_path)
        node_id_first = node.get_identity().node_id
        # Reconstruct from same state path.
        node2 = Node(
            state_path=tmp_path / "node-alpha.json",
            address="127.0.0.1:9501",
        )
        assert node2.get_identity().node_id == node_id_first

    def test_node_get_identity_returns_node_identity(self, tmp_path):
        """FR34: get_identity() returns a NodeIdentity."""
        node = self._make_node(tmp_path)
        identity = node.get_identity()
        assert isinstance(identity, NodeIdentity)

    def test_node_get_endpoint_returns_node_endpoint(self, tmp_path):
        """FR36: get_endpoint() returns a NodeEndpoint with the node's address."""
        node = self._make_node(tmp_path)
        endpoint = node.get_endpoint()
        assert isinstance(endpoint, NodeEndpoint)

    def test_join_cluster_marks_node_active(self, tmp_path):
        """FR38: join_cluster transitions the node into an active state."""
        node = self._make_node(tmp_path)
        peer_endpoint = NodeEndpoint(node_id="peer-1", address="127.0.0.1:9600")
        node.join_cluster([peer_endpoint])
        assert node.is_active

    def test_leave_cluster_marks_node_inactive(self, tmp_path):
        """FR38: leave_cluster deactivates the node."""
        node = self._make_node(tmp_path)
        peer_endpoint = NodeEndpoint(node_id="peer-1", address="127.0.0.1:9600")
        node.join_cluster([peer_endpoint])
        node.leave_cluster()
        assert not node.is_active

    def test_rotate_keypair_updates_public_key(self, tmp_path):
        """FR39: rotate_keypair changes the node's public key in NodeIdentity."""
        node = self._make_node(tmp_path)
        old_pub = node.get_identity().public_key
        node.rotate_keypair()
        new_pub = node.get_identity().public_key
        assert old_pub != new_pub

    def test_rotate_keypair_preserves_node_id(self, tmp_path):
        """FR39/INV-S7a-5: key rotation does NOT change the node_id."""
        node = self._make_node(tmp_path)
        node_id_before = node.get_identity().node_id
        node.rotate_keypair()
        assert node.get_identity().node_id == node_id_before


# ---------------------------------------------------------------------------
# S7b — Inter-Node Transport
# ---------------------------------------------------------------------------

from agent.runtime.inter_node_transport import (
    BranchMessage,
    HeartbeatMessage,
    LoopbackBackend,
    MessageEnvelope,
    ObservationMessage,
    VoteMessage,
    build_envelope,
    _verify_envelope_signature,
)


class TestBuildEnvelope:
    """S7b — build_envelope produces a valid MessageEnvelope (FR40)."""

    def _make_node(self, tmp_path: Path, name: str = "n") -> Node:
        return Node(state_path=tmp_path / f"{name}.json", address="127.0.0.1:9800")

    def test_build_envelope_returns_message_envelope(self, tmp_path):
        """FR40: build_envelope wraps a payload in a MessageEnvelope."""
        node = self._make_node(tmp_path)
        payload = HeartbeatMessage(sequence=1, timestamp=int(time.time()))
        to_endpoint = NodeEndpoint(node_id="peer", address="127.0.0.1:9801")
        envelope = build_envelope(
            from_node=node.get_identity(),
            to_node=to_endpoint,
            payload=payload,
            private_key_bytes=node.get_private_key_bytes(),
        )
        assert isinstance(envelope, MessageEnvelope)

    def test_envelope_contains_signature(self, tmp_path):
        """FR40: envelope carries a non-empty signature of the payload."""
        node = self._make_node(tmp_path)
        payload = HeartbeatMessage(sequence=2, timestamp=int(time.time()))
        to_endpoint = NodeEndpoint(node_id="peer", address="127.0.0.1:9801")
        envelope = build_envelope(
            from_node=node.get_identity(),
            to_node=to_endpoint,
            payload=payload,
            private_key_bytes=node.get_private_key_bytes(),
        )
        assert isinstance(envelope.signature, bytes) and len(envelope.signature) > 0

    def test_envelope_carries_sender_node_id(self, tmp_path):
        """FR40: envelope includes the sender's node_id via from_node."""
        node = self._make_node(tmp_path)
        payload = HeartbeatMessage(sequence=3, timestamp=int(time.time()))
        to_endpoint = NodeEndpoint(node_id="peer", address="127.0.0.1:9801")
        envelope = build_envelope(
            from_node=node.get_identity(),
            to_node=to_endpoint,
            payload=payload,
            private_key_bytes=node.get_private_key_bytes(),
        )
        assert envelope.from_node.node_id == node.get_identity().node_id


class TestSignatureVerification:
    """S7b — signature verification (INV-S7b-1, FR40)."""

    def _build(self, tmp_path: Path):
        node = Node(state_path=tmp_path / "n.json", address="127.0.0.1:9900")
        payload = HeartbeatMessage(sequence=1, timestamp=int(time.time()))
        to_ep = NodeEndpoint(node_id="peer", address="127.0.0.1:9901")
        envelope = build_envelope(
            from_node=node.get_identity(),
            to_node=to_ep,
            payload=payload,
            private_key_bytes=node.get_private_key_bytes(),
        )
        return envelope

    def test_valid_envelope_passes_verification(self, tmp_path):
        """FR40: A freshly built envelope passes signature verification."""
        envelope = self._build(tmp_path)
        assert _verify_envelope_signature(envelope)

    def test_tampered_signature_fails_verification(self, tmp_path):
        """INV-S7b-1: A tampered signature fails signature verification."""
        from dataclasses import replace as dc_replace
        envelope = self._build(tmp_path)
        bad = dc_replace(envelope, signature=b"\x00" * len(envelope.signature))
        assert not _verify_envelope_signature(bad)


class TestMessageTypes:
    """S7b — message type constructors (FR41-FR44)."""

    def test_vote_message_type_exists(self):
        """FR43: VoteMessage is a distinct, constructible message type."""
        vm = VoteMessage(proposal_id="p-001", vote="accept", term=1)
        assert vm.term == 1
        assert vm.proposal_id == "p-001"

    def test_heartbeat_message_type_exists(self):
        """FR42: HeartbeatMessage is a distinct, constructible message type."""
        hm = HeartbeatMessage(sequence=5, timestamp=int(time.time()))
        assert hm.sequence == 5

    def test_observation_message_type_exists(self):
        """FR44: ObservationMessage is a distinct, constructible message type."""
        om = ObservationMessage(
            target_node="node-b",
            result={"conformance": "CONFORMANT"},
            observed_at=int(time.time()),
        )
        assert om.target_node == "node-b"

    def test_branch_message_type_exists(self):
        """FR44: BranchMessage is a distinct, constructible message type."""
        bm = BranchMessage(
            branch_ref="refs/heads/reflect/sandbox-123",
            fitness=0.85,
            published_at=int(time.time()),
        )
        assert bm.fitness == 0.85
        assert "reflect" in bm.branch_ref


class TestLoopbackBackendDelivery:
    """S7b — LoopbackBackend send + receive (FR42-FR44, INV-S7b-1)."""

    def test_send_places_envelope_in_inbox(self, tmp_path):
        """FR42: LoopbackBackend.send() delivers a message to the
        receiver's in-process inbox queue."""
        sender_node = Node(
            state_path=tmp_path / "sender.json", address="127.0.0.1:9700"
        )
        receiver_node = Node(
            state_path=tmp_path / "receiver.json", address="127.0.0.1:9701"
        )

        sender_backend = LoopbackBackend.register(sender_node.get_identity())
        receiver_backend = LoopbackBackend.register(receiver_node.get_identity())

        payload = HeartbeatMessage(sequence=1, timestamp=int(time.time()))
        to_ep = receiver_node.get_endpoint()

        envelope = build_envelope(
            from_node=sender_node.get_identity(),
            to_node=to_ep,
            payload=payload,
            private_key_bytes=sender_node.get_private_key_bytes(),
        )

        sender_backend.connect([to_ep])
        sender_backend.send(to=to_ep, msg=envelope)

        # Confirm the message lands in the receiver's inbox.
        received = receiver_backend._inbox.get(timeout=2.0)
        assert received.from_node.node_id == sender_node.get_identity().node_id


# ---------------------------------------------------------------------------
# S7c — Cluster Harness
# ---------------------------------------------------------------------------

from agent.runtime.cluster_harness import (
    ClusterConfig,
    ClusterSnapshot,
    LoopbackHarness,
    NodeState,
    NodeStatus,
    _quorum_params,
)


class TestQuorumParams:
    """S7c — _quorum_params correctness (AR9: quorum_size + fault_budget)."""

    def test_four_node_cluster(self):
        """n=4 → quorum_size=3, fault_budget=1."""
        quorum, f = _quorum_params(4)
        assert quorum == 3
        assert f == 1

    def test_seven_node_cluster(self):
        """n=7 → quorum_size=5, fault_budget=2."""
        quorum, f = _quorum_params(7)
        assert quorum == 5
        assert f == 2

    def test_quorum_bft_formula(self):
        """quorum_threshold = 2f+1 where f = (n-1)//3 (BFT formula).

        This is the formula from AR9: n >= 3f+1; quorum = 2f+1.
        """
        for cluster_size in (4, 5, 6, 7, 10, 13):
            quorum, f = _quorum_params(cluster_size)
            expected_quorum = 2 * f + 1
            assert quorum == expected_quorum, (
                f"_quorum_params({cluster_size}) = ({quorum}, {f}), "
                f"expected quorum 2*{f}+1 = {expected_quorum}"
            )

    def test_fault_budget_positive_for_bft_sizes(self):
        """n >= 4 always yields fault_budget >= 1."""
        for cluster_size in (4, 7, 10):
            _, f = _quorum_params(cluster_size)
            assert f >= 1


class TestLoopbackHarness:
    """S7c — LoopbackHarness provision + deprovision (FR52, AR9)."""

    def _config(self, n: int = 4) -> ClusterConfig:
        return ClusterConfig(backend="loopback", node_count=n)

    def test_provision_loopback_cluster(self, tmp_path):
        """FR52: LoopbackHarness provisions n nodes, returns n endpoints."""
        harness = LoopbackHarness(state_dir=tmp_path)
        endpoints = harness.provision_cluster(
            n=4, config=self._config(4), allow_non_bft=False
        )
        assert len(endpoints) == 4

    def test_endpoints_have_addresses(self, tmp_path):
        """FR52/FR36: Provisioned NodeEndpoints carry non-empty addresses."""
        harness = LoopbackHarness(state_dir=tmp_path)
        endpoints = harness.provision_cluster(
            n=4, config=self._config(4), allow_non_bft=False
        )
        for ep in endpoints:
            assert ep.address and isinstance(ep.address, str)

    def test_observe_cluster_returns_snapshot(self, tmp_path):
        """FR53: observe_cluster() returns a ClusterSnapshot."""
        harness = LoopbackHarness(state_dir=tmp_path)
        harness.provision_cluster(n=4, config=self._config(4), allow_non_bft=False)
        snapshot = harness.observe_cluster()
        assert isinstance(snapshot, ClusterSnapshot)

    def test_snapshot_reflects_provisioned_count(self, tmp_path):
        """FR53: ClusterSnapshot.nodes count matches the provisioned cluster size."""
        harness = LoopbackHarness(state_dir=tmp_path)
        harness.provision_cluster(n=4, config=self._config(4), allow_non_bft=False)
        snapshot = harness.observe_cluster()
        assert len(snapshot.nodes) == 4

    def test_teardown_stops_all_nodes(self, tmp_path):
        """FR54: teardown_cluster leaves no ACTIVE/STARTING nodes."""
        harness = LoopbackHarness(state_dir=tmp_path)
        harness.provision_cluster(n=4, config=self._config(4), allow_non_bft=False)
        harness.teardown_cluster()
        snapshot = harness.observe_cluster()
        still_running = [
            n for n in snapshot.nodes
            if n.state in (NodeState.ACTIVE, NodeState.STARTING)
        ]
        assert len(still_running) == 0

    def test_ar9_endpoint_count_equals_n(self, tmp_path):
        """AR9: The harness host MUST NOT appear in the returned endpoints
        (INV-S7c-1). Exactly n endpoints are returned — no harness-self entry."""
        harness = LoopbackHarness(state_dir=tmp_path)
        endpoints = harness.provision_cluster(
            n=4, config=self._config(4), allow_non_bft=False
        )
        # Exactly n — no extra harness entry.
        assert len(endpoints) == 4

    def test_node_state_enum_has_active(self):
        """S7c: NodeState enum includes ACTIVE (used in cluster lifecycle)."""
        assert hasattr(NodeState, "ACTIVE")

    def test_node_state_enum_has_departing(self):
        """S7c: NodeState enum includes DEPARTING (used in leave_cluster)."""
        assert hasattr(NodeState, "DEPARTING")
