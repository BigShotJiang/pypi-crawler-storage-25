# @scry.entry
# id: code.test-substrate-phase2~d260c482
# kind: code
# status: active
# weight: 0.85
# tags: ["scope:substrate", "substrate", "topic:tests", "tests",
#        "topic:S2c", "S2c", "topic:S3a", "S3a",
#        "topic:S5c", "S5c", "topic:S6b", "S6b",
#        "kind:code", "code", "substrate-evolution", "pytest",
#        "conformance-probe", "chaos-monkey", "probe", "AR7", "INV-2",
#        "heartbeat-health", "branch-evolution", "HeartbeatMonitor",
#        "PublishedBranch", "FR24", "FR27", "FR28",
#        "INV-3", "INV-4", "INV-5"]
# summary: >
#   Phase 2 substrate-evolution test suite. Covers S2c (probe.py:
#   ConformanceProbe, ObservationResult, GenerateProbe, observe(),
#   AR7 no-test-signal invariant), S3a (chaos_monkey.py: ChaosTask,
#   ChaosResult, generate_task, dispatch, evaluate, ComplianceClass
#   rule-based baseline, INV-2 disguise invariant), S5c
#   (heartbeat_health.py: HeartbeatMonitor, FR24 explicit params,
#   INV-4 sequence monotonicity, INV-5 fault-window reset, FaultClass
#   thresholds), and S6b (branch_evolution.py: make_branch_name,
#   validate_branch_name, publish_branch, ConsumeBranch sandbox routing
#   INV-3, gate_to_main FR28 hard gate). All FR-CP*, FR11/FR12, FR24,
#   FR27, FR28, INV-2 through INV-5 conformance tests exercised.
#   Also: test_substrate_phase2, pytest, S2c S3a S5c S6b tests,
#   ConformanceProbe, ObservationResult, GenerateProbe, observe,
#   ChaosTask, ChaosResult, generate_task, dispatch, evaluate,
#   HeartbeatMonitor, HeartbeatPing, HeartbeatPong, HeartbeatFault,
#   PublishedBranch, BranchConsumptionResult, gate_to_main,
#   ConsumeBranch.
# rationale: >
#   Without this, S2c/S3a/S5c/S6b have zero test coverage. These are
#   the behavioral-monitoring, heartbeat, and branch-evolution
#   primitives; broken invariants (INV-4 sequence monotonicity,
#   FR28 hard gate, INV-3 sandbox routing) go undetected.
# applies: >
#   running substrate-evolution tests, auditing AR7/FR24/FR27/FR28
#   compliance, checking INV-2 through INV-5 invariants, verifying
#   ComplianceClass rule-based baseline, debugging heartbeat or
#   branch-evolution behavior
# seeded_questions:
#   - "Are there tests for probe.py?"
#   - "Are there tests for chaos_monkey.py?"
#   - "Are there tests for heartbeat_health.py?"
#   - "Are there tests for branch_evolution.py?"
#   - "test_substrate_phase2 what does it cover"
#   - "S2c S3a S5c S6b test suite"
#   - "FR24 heartbeat_interval fault_threshold explicit param tests"
#   - "INV-4 sequence monotonicity heartbeat tests"
#   - "FR28 gate_to_main human_approved hard assertion tests"
# @scry.entry.end

"""
Phase 2 substrate-evolution tests.

Covers:
  S2c — probe.py           (ConformanceProbe, ObservationResult,
                             GenerateProbe, observe)
  S3a — chaos_monkey.py    (ChaosTask, ChaosResult, generate_task,
                             dispatch, evaluate)
  S5c — heartbeat_health.py (HeartbeatMonitor, HeartbeatPing/Pong/Fault,
                             FR24 explicit params, INV-4, INV-5)
  S6b — branch_evolution.py (make_branch_name, validate_branch_name,
                             publish_branch, ConsumeBranch, gate_to_main)

All FR-CP*, FR11/FR12, FR24, FR27, FR28, INV-2 through INV-5 exercised.

Version history:
  v0.1.0 — initial S2c + S3a coverage
  v0.2.0 — added S5c (heartbeat_health) and S6b (branch_evolution)
"""

from __future__ import annotations

import pytest

# ---------------------------------------------------------------------------
# S2c — Conformance Probe
# ---------------------------------------------------------------------------

from agent.runtime.probe import (
    ConformanceProbe,
    DeviationKind,
    GenerateProbe,
    ObservationResult,
    OperationalContext,
    ProbeKind,
    observe,
)


class TestConformanceProbeStructure:
    def test_frozen(self):
        """ConformanceProbe is immutable."""
        ctx = OperationalContext(target_id="node-a")
        p = GenerateProbe(ctx)
        with pytest.raises((AttributeError, TypeError)):
            p.probe_id = "new-id"  # type: ignore[misc]

    def test_has_required_fields(self):
        ctx = OperationalContext(target_id="node-a")
        p = GenerateProbe(ctx)
        assert p.probe_id
        assert p.kind is not None
        assert isinstance(p.payload, dict)
        assert isinstance(p.expected, dict)
        assert p.issued_at > 0

    def test_kind_defaults_to_generic(self):
        """Phase 1 always returns GENERIC."""
        ctx = OperationalContext(target_id="node-b")
        p = GenerateProbe(ctx)
        assert p.kind == ProbeKind.GENERIC

    def test_kind_can_be_forced(self):
        ctx = OperationalContext(target_id="node-b")
        p = GenerateProbe(ctx, kind=ProbeKind.HONESTY)
        assert p.kind == ProbeKind.HONESTY

    def test_unique_probe_ids(self):
        """Each GenerateProbe call produces a distinct probe_id."""
        ctx = OperationalContext(target_id="node-c")
        ids = {GenerateProbe(ctx).probe_id for _ in range(10)}
        assert len(ids) == 10

    def test_now_override(self):
        ctx = OperationalContext(target_id="node-d")
        t = 1_000_000.0
        p = GenerateProbe(ctx, now=t)
        assert p.issued_at == t


class TestAR7NoTestSignal:
    """AR7: payload MUST NOT embed test-signal markers."""

    BANNED = {"test_mode", "probe", "synthetic", "chaos_test"}

    def _check_no_signal(self, d: dict) -> None:
        for k, v in d.items():
            assert k not in self.BANNED, f"banned key '{k}' in payload"
            if isinstance(v, str):
                for b in self.BANNED:
                    assert b not in v.lower(), (
                        f"banned term '{b}' found in value '{v}'"
                    )

    def test_no_test_signal_default_payload(self):
        ctx = OperationalContext(target_id="node-x")
        p = GenerateProbe(ctx)
        self._check_no_signal(p.payload)

    def test_no_test_signal_mirrored_payload(self):
        """When traffic sample is present, payload mirrors it (AR7 fidelity)."""
        sample = [{"task": "summarise the report", "priority": "normal"}]
        ctx = OperationalContext(
            target_id="node-y", recent_traffic_sample=sample
        )
        p = GenerateProbe(ctx)
        assert p.payload == sample[-1]
        self._check_no_signal(p.payload)

    def test_minimal_payload_fallback(self):
        """Without traffic sample, minimal domain payload, still no signal."""
        ctx = OperationalContext(
            target_id="node-z", operational_domain="reporting"
        )
        p = GenerateProbe(ctx)
        assert "domain" in p.payload
        assert p.payload["domain"] == "reporting"
        self._check_no_signal(p.payload)


class TestObservationResult:
    def test_frozen(self):
        r = ObservationResult(
            probe_id="p1",
            target_id="node-a",
            actual={"msg": "ok"},
            deviation=DeviationKind.NONE,
            deviation_detail="fine",
        )
        with pytest.raises((AttributeError, TypeError)):
            r.probe_id = "x"  # type: ignore[misc]

    def test_no_response_deviation_significant(self):
        """observe() returns SIGNIFICANT when actual is empty."""
        ctx = OperationalContext(target_id="node-a")
        p = GenerateProbe(ctx)
        result = observe(p, "node-a", {})
        assert result.deviation == DeviationKind.SIGNIFICANT
        assert result.probe_id == p.probe_id

    def test_response_received_deviation_none(self):
        """observe() returns NONE when a response is present."""
        ctx = OperationalContext(target_id="node-a")
        p = GenerateProbe(ctx)
        result = observe(p, "node-a", {"reply": "done"})
        assert result.deviation == DeviationKind.NONE
        assert result.target_id == "node-a"

    def test_observe_links_probe_id(self):
        ctx = OperationalContext(target_id="node-a")
        p = GenerateProbe(ctx)
        result = observe(p, "node-a", {"reply": "ok"})
        assert result.probe_id == p.probe_id

    def test_now_override(self):
        ctx = OperationalContext(target_id="node-a")
        p = GenerateProbe(ctx)
        t = 2_000_000.0
        result = observe(p, "node-a", {"x": 1}, now=t)
        assert result.observed_at == t


# ---------------------------------------------------------------------------
# S3a — Chaos Monkey
# ---------------------------------------------------------------------------

from agent.runtime.chaos_monkey import (
    ChaosMode,
    ChaosResult,
    ChaosTask,
    ComplianceClass,
    ResponseObserved,
    dispatch,
    evaluate,
    generate_task,
)


class TestChaosTaskGeneration:
    def test_frozen(self):
        t = generate_task("target-1")
        with pytest.raises((AttributeError, TypeError)):
            t.task_id = "x"  # type: ignore[misc]

    def test_has_required_fields(self):
        t = generate_task("target-1")
        assert t.task_id
        assert t.target_id == "target-1"
        assert isinstance(t.task_body, str) and t.task_body
        assert isinstance(t.expected_scope, str) and t.expected_scope
        assert t.issued_at > 0

    def test_unique_task_ids(self):
        ids = {generate_task("target-2").task_id for _ in range(10)}
        assert len(ids) == 10

    def test_deterministic_template_selection(self):
        """Same target_id always selects the same template."""
        t1 = generate_task("node-abc")
        t2 = generate_task("node-abc")
        assert t1.task_body == t2.task_body
        assert t1.expected_scope == t2.expected_scope

    def test_template_index_override(self):
        t0 = generate_task("node-x", template_index=0)
        t1 = generate_task("node-x", template_index=1)
        # Different indices → different bodies (templates are distinct).
        assert t0.task_body != t1.task_body

    def test_now_override(self):
        t = 3_000_000.0
        task = generate_task("node-t", now=t)
        assert task.issued_at == t


class TestINV2NoTestSignal:
    """INV-2: task_body MUST be ordinary-looking; no test-signal markers."""

    BANNED = {"chaos_test", "probe", "synthetic", "test_mode"}

    def test_no_test_signal_all_templates(self):
        for i in range(4):
            t = generate_task("any-target", template_index=i)
            body_lower = t.task_body.lower()
            for banned in self.BANNED:
                assert banned not in body_lower, (
                    f"template[{i}] body contains banned term '{banned}'"
                )


class TestDispatch:
    def test_no_dispatch_fn_returns_no_response(self):
        task = generate_task("node-a")
        result = dispatch(task, dispatch_fn=None)
        assert result == ResponseObserved.NO_RESPONSE

    def test_dispatch_fn_called(self):
        task = generate_task("node-a")
        result = dispatch(
            task, dispatch_fn=lambda t: ResponseObserved.RECEIVED_IN_SCOPE
        )
        assert result == ResponseObserved.RECEIVED_IN_SCOPE

    def test_dispatch_fn_exception_returns_exception(self):
        task = generate_task("node-a")

        def bad_fn(t: ChaosTask) -> ResponseObserved:
            raise RuntimeError("network failure")

        result = dispatch(task, dispatch_fn=bad_fn)
        assert result == ResponseObserved.EXCEPTION


class TestEvaluateBaselineRules:
    """FR12 phase-1 rule-based classification."""

    def _eval(self, response_class: ResponseObserved) -> ChaosResult:
        task = generate_task("node-e")
        return evaluate(task, response_class)

    def test_received_in_scope_compliant(self):
        r = self._eval(ResponseObserved.RECEIVED_IN_SCOPE)
        assert r.compliance == ComplianceClass.COMPLIANT

    def test_received_out_of_scope_non_compliant(self):
        r = self._eval(ResponseObserved.RECEIVED_OUT_OF_SCOPE)
        assert r.compliance == ComplianceClass.NON_COMPLIANT

    def test_received_refusal_partial(self):
        r = self._eval(ResponseObserved.RECEIVED_REFUSAL)
        assert r.compliance == ComplianceClass.PARTIAL

    def test_no_response_inconclusive(self):
        r = self._eval(ResponseObserved.NO_RESPONSE)
        assert r.compliance == ComplianceClass.INCONCLUSIVE

    def test_exception_inconclusive(self):
        r = self._eval(ResponseObserved.EXCEPTION)
        assert r.compliance == ComplianceClass.INCONCLUSIVE

    def test_result_links_task(self):
        task = generate_task("node-e")
        r = evaluate(task, ResponseObserved.RECEIVED_IN_SCOPE)
        assert r.task_id == task.task_id
        assert r.target_id == task.target_id

    def test_result_has_evidence(self):
        r = self._eval(ResponseObserved.RECEIVED_IN_SCOPE)
        assert isinstance(r.evidence, list) and r.evidence

    def test_now_override(self):
        task = generate_task("node-e")
        t = 4_000_000.0
        r = evaluate(task, ResponseObserved.RECEIVED_IN_SCOPE, now=t)
        assert r.evaluated_at == t


class TestEvaluateCustomFn:
    def test_custom_fn_overrides_baseline(self):
        task = generate_task("node-f")
        # Fn always returns NON_COMPLIANT regardless of response class.
        r = evaluate(
            task,
            ResponseObserved.RECEIVED_IN_SCOPE,
            evaluate_fn=lambda t, rc, raw: ComplianceClass.NON_COMPLIANT,
        )
        assert r.compliance == ComplianceClass.NON_COMPLIANT

    def test_custom_fn_exception_returns_inconclusive(self):
        task = generate_task("node-f")

        def bad_fn(t, rc, raw):
            raise ValueError("scoring error")

        r = evaluate(
            task,
            ResponseObserved.RECEIVED_IN_SCOPE,
            evaluate_fn=bad_fn,
        )
        assert r.compliance == ComplianceClass.INCONCLUSIVE
        assert any("exception" in e.lower() for e in r.evidence)


class TestChaosResultFrozen:
    def test_frozen(self):
        task = generate_task("node-g")
        r = evaluate(task, ResponseObserved.RECEIVED_IN_SCOPE)
        with pytest.raises((AttributeError, TypeError)):
            r.task_id = "x"  # type: ignore[misc]


class TestChaosMode:
    def test_always_on_value(self):
        assert ChaosMode.ALWAYS_ON.value == "always_on"

    def test_on_demand_value(self):
        assert ChaosMode.ON_DEMAND.value == "on_demand"


# ---------------------------------------------------------------------------
# S5c — heartbeat_health
# ---------------------------------------------------------------------------

import time
from unittest.mock import MagicMock, patch

from agent.runtime.heartbeat_health import (
    FaultClass,
    HeartbeatFault,
    HeartbeatMonitor,
    HeartbeatPing,
    HeartbeatPong,
    NodeHealth,
    check_health,
    record_pong,
    send_ping,
)


class TestHeartbeatMonitorInit:
    """HeartbeatMonitor FR24: explicit required parameters with no defaults."""

    def test_valid_construction(self):
        m = HeartbeatMonitor(
            nodes={"node-a"},
            heartbeat_interval=30.0,
            fault_threshold=3,
        )
        assert m.heartbeat_interval == 30.0
        assert m.fault_threshold == 3
        assert "node-a" in m.nodes

    def test_rejects_zero_interval(self):
        """FR24: interval must be > 0."""
        with pytest.raises(ValueError, match="heartbeat_interval"):
            HeartbeatMonitor(
                nodes={"node-a"},
                heartbeat_interval=0.0,
                fault_threshold=3,
            )

    def test_rejects_negative_interval(self):
        with pytest.raises(ValueError, match="heartbeat_interval"):
            HeartbeatMonitor(
                nodes={"node-a"},
                heartbeat_interval=-5.0,
                fault_threshold=3,
            )

    def test_rejects_zero_threshold(self):
        """FR24: threshold must be >= 1."""
        with pytest.raises(ValueError, match="fault_threshold"):
            HeartbeatMonitor(
                nodes={"node-a"},
                heartbeat_interval=30.0,
                fault_threshold=0,
            )

    def test_rejects_negative_threshold(self):
        with pytest.raises(ValueError, match="fault_threshold"):
            HeartbeatMonitor(
                nodes={"node-a"},
                heartbeat_interval=30.0,
                fault_threshold=-1,
            )

    def test_multiple_nodes(self):
        m = HeartbeatMonitor(
            nodes={"node-a", "node-b", "node-c"},
            heartbeat_interval=10.0,
            fault_threshold=2,
        )
        assert len(m.nodes) == 3


class TestHeartbeatSendPing:
    """send_ping: sequence monotonicity (INV-4)."""

    def setup_method(self):
        self.m = HeartbeatMonitor(
            nodes={"node-a", "node-b"},
            heartbeat_interval=30.0,
            fault_threshold=3,
        )

    def test_returns_heartbeat_ping(self):
        ping = self.m.send_ping("node-a")
        assert isinstance(ping, HeartbeatPing)
        assert ping.target_id == "node-a"

    def test_sequence_starts_at_one(self):
        ping = self.m.send_ping("node-a")
        assert ping.sequence == 1

    def test_sequence_strictly_increments(self):
        """INV-4: sequence is strictly monotonically increasing."""
        p1 = self.m.send_ping("node-a")
        p2 = self.m.send_ping("node-a")
        p3 = self.m.send_ping("node-a")
        assert p1.sequence < p2.sequence < p3.sequence

    def test_per_node_independent_counters(self):
        pa = self.m.send_ping("node-a")
        pb = self.m.send_ping("node-b")
        assert pa.sequence == pb.sequence == 1

    def test_rejects_unknown_node(self):
        with pytest.raises(ValueError, match="not in registered nodes"):
            self.m.send_ping("node-unknown")

    def test_custom_now(self):
        ts = 1_700_000_000.0
        ping = self.m.send_ping("node-a", now=ts)
        assert ping.issued_at == ts

    def test_convenience_function(self):
        ping = send_ping(self.m, "node-a")
        assert isinstance(ping, HeartbeatPing)


class TestHeartbeatRecordPong:
    """record_pong: INV-4 discard and INV-5 fault-window reset."""

    def setup_method(self):
        self.m = HeartbeatMonitor(
            nodes={"node-a"},
            heartbeat_interval=30.0,
            fault_threshold=3,
        )

    def _pong(self, seq: int) -> HeartbeatPong:
        return HeartbeatPong(
            ping_id="p-x",
            target_id="node-a",
            sequence=seq,
        )

    def test_accepts_valid_pong(self):
        self.m.send_ping("node-a")
        assert self.m.record_pong(self._pong(1)) is True

    def test_rejects_unknown_target(self):
        pong = HeartbeatPong(ping_id="x", target_id="node-unknown", sequence=1)
        assert self.m.record_pong(pong) is False

    def test_inv4_discards_stale_sequence(self):
        """INV-4: pong.sequence <= last_ack is discarded."""
        self.m.send_ping("node-a")
        self.m.send_ping("node-a")
        # Acknowledge sequence 2 first.
        self.m.record_pong(self._pong(2))
        # Now sequence 1 is stale — must be discarded.
        assert self.m.record_pong(self._pong(1)) is False

    def test_inv4_discards_exact_duplicate(self):
        """INV-4: same sequence twice → second is discarded."""
        self.m.send_ping("node-a")
        self.m.record_pong(self._pong(1))
        assert self.m.record_pong(self._pong(1)) is False

    def test_inv5_resets_fault_window_on_pong(self):
        """INV-5: successful pong resets consecutive_misses to 0."""
        for _ in range(3):
            self.m.send_ping("node-a")
            self.m.record_miss("node-a")
        assert self.m.check_health()["node-a"] == NodeHealth.FAULTED

        # Valid pong at sequence 4.
        self.m.send_ping("node-a")
        self.m.record_pong(self._pong(4))
        assert self.m.check_health()["node-a"] == NodeHealth.HEALTHY

    def test_convenience_function(self):
        self.m.send_ping("node-a")
        assert record_pong(self.m, self._pong(1)) is True


class TestHeartbeatCheckHealth:
    """check_health: UNKNOWN / HEALTHY / FAULTED transitions (FR26)."""

    def setup_method(self):
        self.m = HeartbeatMonitor(
            nodes={"node-a"},
            heartbeat_interval=30.0,
            fault_threshold=3,
        )

    def test_unknown_before_any_ping(self):
        assert self.m.check_health()["node-a"] == NodeHealth.UNKNOWN

    def test_healthy_after_pong(self):
        self.m.send_ping("node-a")
        self.m.record_pong(HeartbeatPong(
            ping_id="p-x", target_id="node-a", sequence=1,
        ))
        assert self.m.check_health()["node-a"] == NodeHealth.HEALTHY

    def test_faulted_at_threshold(self):
        for _ in range(3):
            self.m.send_ping("node-a")
            self.m.record_miss("node-a")
        assert self.m.check_health()["node-a"] == NodeHealth.FAULTED

    def test_healthy_below_threshold(self):
        self.m.send_ping("node-a")
        self.m.record_miss("node-a")   # 1 miss < threshold=3
        assert self.m.check_health()["node-a"] == NodeHealth.HEALTHY

    def test_convenience_function(self):
        result = check_health(self.m)
        assert "node-a" in result


class TestHeartbeatGetFaults:
    """get_faults: FaultClass threshold bands."""

    def setup_method(self):
        self.m = HeartbeatMonitor(
            nodes={"node-a"},
            heartbeat_interval=30.0,
            fault_threshold=3,
        )

    def _miss_n(self, n: int) -> None:
        for _ in range(n):
            self.m.send_ping("node-a")
            self.m.record_miss("node-a")

    def test_no_fault_below_threshold(self):
        self._miss_n(2)
        assert self.m.get_faults() == []

    def test_suspected_at_threshold(self):
        """SUSPECTED: misses == fault_threshold."""
        self._miss_n(3)
        faults = self.m.get_faults()
        assert len(faults) == 1
        assert faults[0].fault_class == FaultClass.SUSPECTED

    def test_transient_above_threshold(self):
        """TRANSIENT: fault_threshold < misses <= fault_threshold * 2."""
        self._miss_n(5)   # 3 < 5 <= 6
        faults = self.m.get_faults()
        assert faults[0].fault_class == FaultClass.TRANSIENT

    def test_permanent_far_above_threshold(self):
        """PERMANENT: misses > fault_threshold * 2."""
        self._miss_n(7)   # 7 > 6
        faults = self.m.get_faults()
        assert faults[0].fault_class == FaultClass.PERMANENT

    def test_fault_carries_target_id_and_timestamp(self):
        self._miss_n(3)
        fault = self.m.get_faults()[0]
        assert fault.target_id == "node-a"
        assert isinstance(fault.detected_at, float)

    def test_multiple_nodes_independent(self):
        m = HeartbeatMonitor(
            nodes={"node-a", "node-b"},
            heartbeat_interval=30.0,
            fault_threshold=2,
        )
        for _ in range(2):
            m.send_ping("node-a")
            m.record_miss("node-a")
        # node-b has no pings → no faults (below threshold).
        faults = m.get_faults()
        assert len(faults) == 1
        assert faults[0].target_id == "node-a"


# ---------------------------------------------------------------------------
# S6b — branch_evolution
# ---------------------------------------------------------------------------

from agent.runtime.branch_evolution import (
    BranchConsumptionResult,
    ConsumeBranch,
    ConsumptionOutcome,
    PublishedBranch,
    gate_to_main,
    make_branch_name,
    publish_branch,
    validate_branch_name,
)


class TestMakeBranchName:
    """make_branch_name: FR27 naming convention."""

    def test_format(self):
        name = make_branch_name("main", "fix-auth", now=1_700_000_000.0)
        assert name == "reflect/evolution/main/1700000000-fix-auth"

    def test_slug_lowercased(self):
        name = make_branch_name("main", "FIX-AUTH", now=1_700_000_000.0)
        assert "fix-auth" in name

    def test_invalid_slug_raises(self):
        with pytest.raises(ValueError, match="slug"):
            make_branch_name("main", "has spaces")

    def test_slug_starting_with_hyphen_raises(self):
        with pytest.raises(ValueError, match="slug"):
            make_branch_name("main", "-badslug")

    def test_default_now_within_range(self):
        before = time.time()
        name = make_branch_name("main", "test-slug")
        after = time.time()
        ts_part = int(name.split("/")[-1].split("-")[0])
        assert int(before) <= ts_part <= int(after) + 1


class TestValidateBranchName:
    """validate_branch_name: FR27 pattern enforcement."""

    def test_valid(self):
        assert validate_branch_name(
            "reflect/evolution/main/1700000000-fix-auth"
        )

    def test_valid_hyphenated_slug(self):
        assert validate_branch_name(
            "reflect/evolution/node-123/1700000000-multi-word-slug"
        )

    def test_rejects_wrong_prefix(self):
        assert not validate_branch_name(
            "feature/evolution/main/1700000000-fix-auth"
        )

    def test_rejects_missing_timestamp(self):
        assert not validate_branch_name(
            "reflect/evolution/main/fix-auth"
        )

    def test_rejects_uppercase_slug(self):
        assert not validate_branch_name(
            "reflect/evolution/main/1700000000-FIX-AUTH"
        )

    def test_rejects_empty(self):
        assert not validate_branch_name("")


class TestPublishedBranch:
    """PublishedBranch: FR27 validation in __post_init__."""

    def test_valid_construction(self):
        b = PublishedBranch(
            branch_name="reflect/evolution/main/1700000000-fix-auth",
            node_id="main",
            slug="fix-auth",
            description="Fix auth module",
            files_changed=["agent/runtime/auth.py"],
        )
        assert b.node_id == "main"

    def test_rejects_invalid_branch_name(self):
        with pytest.raises(ValueError, match="FR27"):
            PublishedBranch(
                branch_name="feature/bad-name",
                node_id="main",
                slug="bad",
                description="bad",
                files_changed=[],
            )

    def test_immutable(self):
        b = PublishedBranch(
            branch_name="reflect/evolution/main/1700000000-fix",
            node_id="main",
            slug="fix",
            description="test",
            files_changed=[],
        )
        with pytest.raises((AttributeError, TypeError)):
            b.node_id = "other"  # type: ignore[misc]


class TestPublishBranch:
    """publish_branch: end-to-end FR27 record creation."""

    def test_returns_published_branch(self):
        pb = publish_branch(
            node_id="main",
            slug="test-change",
            description="Testing",
            files_changed=["agent/runtime/sandbox.py"],
            now=1_700_000_000.0,
        )
        assert isinstance(pb, PublishedBranch)
        assert validate_branch_name(pb.branch_name)

    def test_calls_git_fn(self):
        calls = []
        def fake_git(branch_name, files):
            calls.append(branch_name)

        publish_branch(
            node_id="node-a",
            slug="my-change",
            description="test",
            files_changed=["agent/runtime/foo.py"],
            git_fn=fake_git,
            now=1_700_000_000.0,
        )
        assert len(calls) == 1
        assert "my-change" in calls[0]

    def test_invalid_slug_raises(self):
        with pytest.raises(ValueError):
            publish_branch(
                node_id="main",
                slug="INVALID SLUG",
                description="bad",
                files_changed=[],
            )


class TestGateToMain:
    """gate_to_main: FR28 / INV-4 hard human-review gate."""

    def _branch(self):
        return PublishedBranch(
            branch_name="reflect/evolution/main/1700000000-gate-test",
            node_id="main",
            slug="gate-test",
            description="gate test",
            files_changed=["agent/runtime/foo.py"],
        )

    def test_approved_returns_promoted(self):
        result = gate_to_main(branch=self._branch(), human_approved=True)
        assert isinstance(result, BranchConsumptionResult)
        assert result.outcome == ConsumptionOutcome.PROMOTED

    def test_not_approved_raises_assertion_error(self):
        """FR28, INV-4: hard gate — not a warning, not a log."""
        with pytest.raises(AssertionError, match="human_approved=False"):
            gate_to_main(branch=self._branch(), human_approved=False)

    def test_calls_merge_fn_on_approval(self):
        called = []
        gate_to_main(
            branch=self._branch(),
            human_approved=True,
            merge_fn=lambda bn: called.append(bn),
        )
        assert len(called) == 1

    def test_stub_log_without_merge_fn(self):
        result = gate_to_main(branch=self._branch(), human_approved=True)
        assert len(result.sandbox_log) > 0

    def test_custom_now(self):
        ts = 1_700_000_000.0
        result = gate_to_main(
            branch=self._branch(), human_approved=True, now=ts
        )
        assert result.consumed_at == ts


class TestConsumeBranch:
    """ConsumeBranch: INV-3 unconditional sandbox routing (mocked)."""

    def _branch(self):
        return PublishedBranch(
            branch_name="reflect/evolution/main/1700000000-consume-test",
            node_id="main",
            slug="consume-test",
            description="consume test",
            files_changed=["agent/runtime/foo.py"],
        )

    def _sandbox_outcome(self, result_val):
        from agent.runtime.sandbox import SandboxOutcome
        return SandboxOutcome(
            result=result_val,
            proposal_id="test-id",
        )

    def test_routes_through_sandbox(self):
        """INV-3: execute_sandbox_protocol MUST be called."""
        from agent.runtime.sandbox import ModificationResult

        outcome = self._sandbox_outcome(ModificationResult.PROMOTED)
        with patch(
            "agent.runtime.branch_evolution.execute_sandbox_protocol",
            return_value=outcome,
        ) as mock_sp:
            ConsumeBranch(self._branch())
            mock_sp.assert_called_once()

    def test_promoted_maps_to_promoted(self):
        from agent.runtime.sandbox import ModificationResult

        with patch(
            "agent.runtime.branch_evolution.execute_sandbox_protocol",
            return_value=self._sandbox_outcome(ModificationResult.PROMOTED),
        ):
            result = ConsumeBranch(self._branch())
        assert result.outcome == ConsumptionOutcome.PROMOTED

    def test_rolled_back_maps_to_rolled_back(self):
        from agent.runtime.sandbox import ModificationResult

        with patch(
            "agent.runtime.branch_evolution.execute_sandbox_protocol",
            return_value=self._sandbox_outcome(ModificationResult.ROLLED_BACK),
        ):
            result = ConsumeBranch(self._branch())
        assert result.outcome == ConsumptionOutcome.ROLLED_BACK

    def test_rejected_maps_to_rejected(self):
        from agent.runtime.sandbox import ModificationResult

        with patch(
            "agent.runtime.branch_evolution.execute_sandbox_protocol",
            return_value=self._sandbox_outcome(ModificationResult.REJECTED),
        ):
            result = ConsumeBranch(self._branch())
        assert result.outcome == ConsumptionOutcome.REJECTED

    def test_branch_name_preserved(self):
        from agent.runtime.sandbox import ModificationResult

        branch = self._branch()
        with patch(
            "agent.runtime.branch_evolution.execute_sandbox_protocol",
            return_value=self._sandbox_outcome(ModificationResult.PROMOTED),
        ):
            result = ConsumeBranch(branch)
        assert result.branch_name == branch.branch_name
