# @scry.entry
# id: code.test-substrate-phase45~5e43b996
# kind: code
# status: active
# weight: 0.85
# tags: ["scope:substrate", "substrate", "topic:tests", "tests",
#        "topic:S5d", "S5d", "topic:S6c", "S6c", "kind:code", "code",
#        "substrate-evolution", "pytest",
#        "compromise-remediation", "selection-criterion",
#        "RemediationCase", "RemediationEngine", "RemediationDecision",
#        "VoteOption", "CaseStatus", "FitnessScore", "SelectionDecision",
#        "ConclusivenessLevel", "evaluate_fitness", "evaluate_selection",
#        "compute_selection", "AR1", "AR5", "FR22", "FR29", "FR33"]
# summary: >
#   Phase 4+5 substrate-evolution test suite. Covers S5d
#   (compromise_remediation.py: RemediationCase creation, signal
#   ingestion, majority vote quorum deliberation, AR1 no-unilateral-
#   override enforcement, split-vote MONITOR_CONTINUE INV-4,
#   RemediationDecision case_id + action correctness) and S6c
#   (selection_criterion.py: FitnessScore from evaluate_fitness,
#   higher-trust higher-fitness FR29, parsimony pressure INV-3,
#   evaluate_selection SELECT/CONTINUE/ROLLBACK thresholds,
#   AR5 survival-only rejection, compute_selection integration).
#   FR22, AR1, FR29, FR33, AR5 exercised. Also: test_substrate_phase45,
#   pytest, S5d S6c tests, compromise remediation selection criterion
#   quorum deliberation fitness parsimony.
# rationale: >
#   Without this, S5d and S6c have zero test coverage. Broken AR1
#   (no-unilateral override) or AR5 (survival-only rejection) go
#   silently undetected.
# applies: >
#   running substrate-evolution tests, auditing AR1/AR5 compliance,
#   verifying FR22 quorum deliberation, checking parsimony enforcement,
#   debugging compromise remediation or selection criterion behavior
# seeded_questions:
#   - "Are there tests for compromise_remediation.py?"
#   - "Are there tests for selection_criterion.py?"
#   - "test_substrate_phase45 what does it cover"
#   - "S5d S6c test suite"
#   - "AR1 no-unilateral quorum tests"
#   - "AR5 survival-only selection rejection tests"
#   - "FR22 quorum deliberation tests"
#   - "parsimony pressure FitnessScore tests"
# @scry.entry.end

"""
Phase 4+5 substrate-evolution tests.

Covers:
  S5d — compromise_remediation.py  (RemediationCase, RemediationEngine,
                                    RemediationDecision, VoteOption,
                                    CaseStatus, FR22, AR1, INV-4, INV-6)
  S6c — selection_criterion.py     (FitnessScore, SelectionDecision,
                                    ConclusivenessLevel, evaluate_fitness,
                                    evaluate_selection, compute_selection,
                                    FR29, FR33, AR5, INV-3)

Version history:
  v0.1.0 — initial S5d + S6c coverage
"""

from __future__ import annotations

import time
from collections import deque
from typing import Dict, List, Optional

import pytest

# ---------------------------------------------------------------------------
# S5d — Compromise Remediation
# ---------------------------------------------------------------------------

from agent.runtime.compromise_remediation import (
    CaseStatus,
    RemediationCase,
    RemediationDecision,
    RemediationEngine,
    VoteOption,
)
from agent.runtime.trust_score import (
    CompromiseSignal,
    ConformanceResult,
    TrustScore,
)
from agent.runtime.heartbeat_health import FaultClass, HeartbeatFault
from agent.runtime.behavioral_contract import ObservationResult


def _make_signal(node_id: str = "node-A") -> CompromiseSignal:
    """Helper: construct a minimal CompromiseSignal for node_id."""
    return CompromiseSignal(
        node_id=node_id,
        triggered_at=time.time(),
        score_at_trigger=0.2,
        drift_summary={"deviant_count": 3},
    )


def _make_score(node_id: str = "node-A", value: float = 0.9) -> TrustScore:
    """Helper: TrustScore with given value."""
    return TrustScore(
        node_id=node_id,
        value=value,
    )


class TestRemediationCase:
    """S5d — RemediationCase creation and structure (FR22)."""

    def test_case_created_with_node_id(self):
        """FR22: A RemediationCase captures the target node_id."""
        engine = RemediationEngine(
            cluster_nodes={"node-A", "node-B", "node-C"},
            fault_tolerance=1,
        )
        signal = _make_signal("node-A")
        case = engine.ingest_signal(signal)
        assert case.target_node_id == "node-A"

    def test_case_has_unique_case_id(self):
        """FR22: Each case gets a unique case_id (UUID string)."""
        engine = RemediationEngine(
            cluster_nodes={"node-A", "node-B", "node-C"},
            fault_tolerance=1,
        )
        s1 = _make_signal("node-A")
        s2 = _make_signal("node-B")
        c1 = engine.ingest_signal(s1)
        c2 = engine.ingest_signal(s2)
        assert c1.case_id != c2.case_id

    def test_signal_accumulates_in_case(self):
        """FR22: A second signal for the same target within the window
        merges into the existing case rather than opening a new one."""
        engine = RemediationEngine(
            cluster_nodes={"node-A", "node-B", "node-C"},
            fault_tolerance=1,
            aggregation_window=60.0,
        )
        s1 = _make_signal("node-A")
        s2 = _make_signal("node-A")
        c1 = engine.ingest_signal(s1)
        c2 = engine.ingest_signal(s2)
        assert c1.case_id == c2.case_id  # same case absorbed both signals
        assert len(c1.signals) == 2

    def test_case_opened_status(self):
        """FR22: A freshly opened case has status OPEN."""
        engine = RemediationEngine(
            cluster_nodes={"node-A", "node-B", "node-C"},
            fault_tolerance=1,
        )
        case = engine.ingest_signal(_make_signal("node-A"))
        assert case.status == CaseStatus.OPEN


class TestRemediationDeliberation:
    """S5d — deliberation path (FR22, AR1, INV-4, INV-6)."""

    def _build_engine_with_case(
        self, target: str = "node-A"
    ) -> tuple["RemediationEngine", str]:
        """Build a 3-node engine, ingest a signal, return (engine, case_id)."""
        nodes = {"node-A", "node-B", "node-C"}
        engine = RemediationEngine(cluster_nodes=nodes, fault_tolerance=1)
        case = engine.ingest_signal(_make_signal(target))
        return engine, case.case_id

    def test_majority_wind_down_vote(self):
        """AR1 + FR22: majority WIND_DOWN_AND_REPLACE vote produces
        RemediationDecision with action WIND_DOWN_AND_REPLACE."""
        engine, case_id = self._build_engine_with_case("node-A")
        # Provide explicit votes from non-defendant nodes.
        votes: Dict[str, str] = {
            "node-B": VoteOption.WIND_DOWN_AND_REPLACE.value,
            "node-C": VoteOption.WIND_DOWN_AND_REPLACE.value,
        }
        decision = engine.deliberate(case_id, voter_votes=votes)
        assert decision.decision == VoteOption.WIND_DOWN_AND_REPLACE
        assert decision.case_id == case_id

    def test_majority_exonerate_vote(self):
        """FR22: majority EXONERATE vote produces EXONERATE decision."""
        engine, case_id = self._build_engine_with_case("node-A")
        votes: Dict[str, str] = {
            "node-B": VoteOption.EXONERATE.value,
            "node-C": VoteOption.EXONERATE.value,
        }
        decision = engine.deliberate(case_id, voter_votes=votes)
        assert decision.decision == VoteOption.EXONERATE

    def test_split_vote_defaults_monitor_continue(self):
        """INV-4: split vote (no majority) resolves to MONITOR_CONTINUE."""
        engine, case_id = self._build_engine_with_case("node-A")
        votes: Dict[str, str] = {
            "node-B": VoteOption.WIND_DOWN_AND_REPLACE.value,
            "node-C": VoteOption.EXONERATE.value,
        }
        decision = engine.deliberate(case_id, voter_votes=votes)
        assert decision.decision == VoteOption.MONITOR_CONTINUE

    def test_ar1_decision_carries_case_id(self):
        """AR1 structural: RemediationDecision always references the case_id,
        proving it came from a quorum deliberation (not unilateral action)."""
        engine, case_id = self._build_engine_with_case("node-A")
        votes = {
            "node-B": VoteOption.WIND_DOWN_AND_REPLACE.value,
            "node-C": VoteOption.WIND_DOWN_AND_REPLACE.value,
        }
        decision = engine.deliberate(case_id, voter_votes=votes)
        # AR1: no non-quorum wind-down path exists; every decision is
        # traceable to a case_id produced by deliberate().
        assert decision.case_id == case_id
        assert isinstance(decision, RemediationDecision)

    def test_deliberation_requires_an_open_case(self):
        """FR22: deliberating on a non-existent case_id raises an error,
        preventing unilateral action without prior signal ingestion (AR1)."""
        engine = RemediationEngine(
            cluster_nodes={"node-A", "node-B", "node-C"}, fault_tolerance=1
        )
        with pytest.raises(Exception):
            engine.deliberate("phantom-case-id")


# ---------------------------------------------------------------------------
# S6c — Selection Criterion
# ---------------------------------------------------------------------------

from agent.runtime.selection_criterion import (
    ConclusivenessLevel,
    FitnessScore,
    SelectionDecision,
    compute_selection,
    evaluate_fitness,
    evaluate_selection,
)
from agent.runtime.sandbox import SandboxOutcome, ModificationResult


def _make_trust_score(value: float = 0.8, node_id: str = "node-X") -> TrustScore:
    return TrustScore(node_id=node_id, value=value)


def _make_sandbox_outcome(lines_added: int = 0) -> SandboxOutcome:
    """Helper: construct a PROMOTED SandboxOutcome with given line delta."""
    return SandboxOutcome(
        result=ModificationResult.PROMOTED,
        proposal_id="test-proposal",
        lines_added=lines_added,
    )


def _conformant_obs(n: int = 2) -> List[ObservationResult]:
    """Return n CONFORMANT ObservationResult records."""
    from agent.runtime.behavioral_contract import ObservationResult as BcObsResult
    return [
        BcObsResult(
            result=ConformanceResult.CONFORMANT,
            deviation_description=None,
            observed_at=time.time(),
            is_self_report=False,
        )
        for _ in range(n)
    ]


class TestEvaluateFitness:
    """S6c — evaluate_fitness (FR29, INV-3 parsimony)."""

    def _base_kwargs(self, trust_value: float = 0.8, lines_added: int = 0):
        return dict(
            score=_make_trust_score(trust_value),
            sandbox_outcome=_make_sandbox_outcome(lines_added=lines_added),
            total_codebase_lines=1000,
            peer_observations=_conformant_obs(2),
            fault_tolerance=1,
        )

    def test_returns_fitness_score(self):
        """FR29: evaluate_fitness returns a FitnessScore instance."""
        fs = evaluate_fitness(**self._base_kwargs())
        assert isinstance(fs, FitnessScore)

    def test_higher_trust_higher_fitness(self):
        """FR29: higher trust score leads to higher (or equal) raw fitness."""
        low = evaluate_fitness(**self._base_kwargs(trust_value=0.2))
        high = evaluate_fitness(**self._base_kwargs(trust_value=0.95))
        assert high.raw_fitness >= low.raw_fitness

    def test_parsimony_penalty_applied(self):
        """INV-3: code growth (lines_added > 0) reduces adjusted_fitness
        relative to zero-growth at equal raw fitness."""
        fs_base = evaluate_fitness(**self._base_kwargs(lines_added=0))
        fs_grow = evaluate_fitness(**self._base_kwargs(lines_added=500))
        # Parsimony penalty must reduce adjusted_fitness when code grows.
        assert fs_grow.adjusted_fitness <= fs_base.adjusted_fitness

    def test_fitness_score_conclusiveness(self):
        """FR29: FitnessScore carries a conclusiveness field."""
        fs = evaluate_fitness(**self._base_kwargs())
        assert fs.conclusiveness in (
            ConclusivenessLevel.CONCLUSIVE,
            ConclusivenessLevel.INCONCLUSIVE,
        )


class TestEvaluateSelection:
    """S6c — evaluate_selection decision mapping (FR29, AR5)."""

    def _fs(
        self,
        adjusted: float = 0.8,
        raw: float = 0.8,
        conclusive: bool = True,
        node_id: str = "node-X",
    ) -> FitnessScore:
        return FitnessScore(
            node_id=node_id,
            raw_fitness=raw,
            adjusted_fitness=adjusted,
            peer_observation_count=2,
            conclusiveness=(
                ConclusivenessLevel.CONCLUSIVE
                if conclusive
                else ConclusivenessLevel.INCONCLUSIVE
            ),
            evaluation_window_end=time.time(),
        )

    def test_high_fitness_conclusive_selects(self):
        """FR29: CONCLUSIVE + high adjusted_fitness → SELECT."""
        fs = self._fs(adjusted=0.9, raw=0.9, conclusive=True)
        decision = evaluate_selection(fs, rollback_threshold=0.3, select_threshold=0.7)
        assert decision == SelectionDecision.SELECT

    def test_low_fitness_conclusive_rollback(self):
        """FR29: CONCLUSIVE + low adjusted_fitness → ROLLBACK."""
        fs = self._fs(adjusted=0.1, raw=0.1, conclusive=True)
        decision = evaluate_selection(fs, rollback_threshold=0.3, select_threshold=0.7)
        assert decision == SelectionDecision.ROLLBACK

    def test_inconclusive_always_continue(self):
        """FR29: INCONCLUSIVE fitness → CONTINUE regardless of value."""
        fs = self._fs(adjusted=0.95, raw=0.95, conclusive=False)
        decision = evaluate_selection(fs, rollback_threshold=0.3, select_threshold=0.7)
        assert decision == SelectionDecision.CONTINUE

    def test_ar5_survival_only_rejected(self):
        """AR5: A node that survives but shows zero fitness improvement
        (adjusted_fitness near zero) must not SELECT."""
        # AR5: survival-only → no fitness improvement → adjusted near floor
        fs = self._fs(adjusted=0.05, raw=0.05, conclusive=True)
        decision = evaluate_selection(fs, rollback_threshold=0.3, select_threshold=0.7)
        # Either ROLLBACK or CONTINUE, but never SELECT.
        assert decision != SelectionDecision.SELECT

    def test_midrange_fitness_continue(self):
        """FR29: Fitness between thresholds → CONTINUE."""
        fs = self._fs(adjusted=0.5, raw=0.5, conclusive=True)
        decision = evaluate_selection(fs, rollback_threshold=0.3, select_threshold=0.7)
        assert decision == SelectionDecision.CONTINUE


class TestComputeSelection:
    """S6c — compute_selection integrates fitness + parsimony (FR29)."""

    def _base_kwargs(self, trust_value: float = 0.8, lines_added: int = 0):
        return dict(
            score=_make_trust_score(trust_value),
            sandbox_outcome=_make_sandbox_outcome(lines_added=lines_added),
            total_codebase_lines=1000,
            peer_observations=_conformant_obs(2),
            fault_tolerance=1,
        )

    def test_returns_selection_decision(self):
        """compute_selection returns a (FitnessScore, SelectionDecision) tuple."""
        result = compute_selection(**self._base_kwargs())
        assert isinstance(result, tuple) and len(result) == 2
        _, decision = result
        assert isinstance(decision, SelectionDecision)

    def test_high_trust_no_growth_selects(self):
        """compute_selection: high trust + zero code growth → SELECT or CONTINUE."""
        _, decision = compute_selection(**self._base_kwargs(trust_value=0.95))
        # May be CONTINUE if peer obs count is below f+1 threshold.
        assert decision in (SelectionDecision.SELECT, SelectionDecision.CONTINUE)

    def test_deviant_drift_not_select(self):
        """compute_selection: repeated DEVIANT observations lower fitness,
        resulting in ROLLBACK or CONTINUE (never SELECT, per AR5)."""
        from agent.runtime.trust_score import UpdateScore
        score = _make_trust_score(value=0.9)
        for _ in range(5):
            score = UpdateScore(score, ConformanceResult.DEVIANT)
        kw = dict(
            score=score,
            sandbox_outcome=_make_sandbox_outcome(lines_added=0),
            total_codebase_lines=1000,
            peer_observations=_conformant_obs(2),
            fault_tolerance=1,
        )
        _, decision = compute_selection(**kw)
        assert decision != SelectionDecision.SELECT
