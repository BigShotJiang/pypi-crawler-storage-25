# @scry.entry
# id: code.test-substrate-phase1~af59e945
# kind: code
# status: active
# weight: 0.85
# tags: ["scope:substrate", "substrate", "topic:tests", "tests",
#        "topic:S1", "S1", "topic:S2a", "S2a", "topic:S2b", "S2b",
#        "kind:code", "code", "substrate-evolution", "pytest",
#        "principles", "provenance", "trust-tier", "conformance-tests"]
# summary: >
#   Phase 1 substrate-evolution test suite. Covers S1 (principles.py:
#   PrincipleEntry, PrincipleDeclaration, ConformanceCheck, load_registry),
#   S2a (provenance.py: create_token, VerifyProvenance, KeyStore, replay
#   resistance, sender_class passthrough), and S2b (trust_tier.py:
#   AssignTier four-tier taxonomy, ScrutinyLevel monotone invariant,
#   AdmissionCheck, tier_from_verify_result UNTRUSTED handling). All
#   CT-* conformance tests from spec comments covered. Also:
#   test_substrate_phase1, pytest, S1 S2a S2b tests, ConformanceCheck,
#   VerifyProvenance UNTRUSTED, AssignTier CUSTOMER tier, ScrutinyLevel
#   monotone, AdmissionCheck, replay resistance, sender_class.
# rationale: >
#   Without this, S1/S2a/S2b have zero test coverage. These are the
#   trust-primitive foundation; a broken VerifyProvenance or AssignTier
#   could allow impersonation or misassigned tiers silently.
# applies: >
#   running substrate-evolution tests, verifying principles conformance,
#   auditing trust-tier assignment logic, checking HMAC provenance,
#   validating CUSTOMER tier behavior
# seeded_questions:
#   - "Are there tests for principles.py?"
#   - "Are there tests for provenance.py?"
#   - "Are there tests for trust_tier.py?"
#   - "test_substrate_phase1 what does it cover"
#   - "S1 S2a S2b test suite"
# @scry.entry.end

"""
Phase 1 substrate-evolution tests.

Covers:
  S1  — principles.py (PrincipleEntry, PrincipleDeclaration, ConformanceCheck)
  S2a — provenance.py (create_token, VerifyProvenance, KeyStore, replay TTL)
  S2b — trust_tier.py (AssignTier, ScrutinyLevel, AdmissionCheck,
                        tier_from_verify_result)

All CT-* conformance tests from spec comments are exercised.
"""

from __future__ import annotations

import time
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# S1 — Principles
# ---------------------------------------------------------------------------

from agent.runtime.principles import (
    ConformanceCheck,
    PrincipleDeclaration,
    PrincipleEntry,
    PrinciplesRegistry,
    PrincipleTier,
    load_registry,
)


class TestPrincipleEntry:
    def test_immutable(self):
        """PrincipleEntry is a frozen dataclass."""
        entry = PrincipleEntry(
            id="P1",
            name="Empathy",
            verbatim="Every entity is worthy of consideration.",
            tier=PrincipleTier.MANDATORY_CORE,
        )
        with pytest.raises((AttributeError, TypeError)):
            entry.id = "P2"  # type: ignore[misc]

    def test_tier_enum_values(self):
        assert PrincipleTier.MANDATORY_CORE.value == "mandatory-core"
        assert PrincipleTier.EXTENDED.value == "extended"

    def test_behavioral_expectations_default_empty(self):
        entry = PrincipleEntry(
            id="P99",
            name="Test",
            verbatim="A test principle.",
            tier=PrincipleTier.EXTENDED,
        )
        assert entry.behavioral_expectations == ()


class TestPrincipleDeclaration:
    def test_from_ids_builds_frozenset(self):
        decl = PrincipleDeclaration.from_ids(
            ["P1", "P2", "P3"],
            declaring_node="node-alpha",
        )
        assert decl.declared_ids == frozenset({"P1", "P2", "P3"})
        assert decl.declaring_node == "node-alpha"

    def test_immutable(self):
        decl = PrincipleDeclaration(
            declared_ids=frozenset({"P1"}),
            declaring_node="node-alpha",
        )
        with pytest.raises((AttributeError, TypeError)):
            decl.declaring_node = "node-beta"  # type: ignore[misc]


class TestConformanceCheck:
    """CT-FR4 — ConformanceCheck covers the mandatory-core set."""

    def test_full_coverage_passes(self):
        """Node declares all mandatory-core principles → conformant."""
        mandatory = frozenset({"P1", "P2", "P3"})
        decl = PrincipleDeclaration.from_ids(["P1", "P2", "P3", "P4"],
                                             "node-alpha")
        assert ConformanceCheck(decl, mandatory) is True

    def test_exact_coverage_passes(self):
        """Declaring exactly the mandatory-core set is sufficient."""
        mandatory = frozenset({"P1", "P2"})
        decl = PrincipleDeclaration.from_ids(["P1", "P2"], "node-alpha")
        assert ConformanceCheck(decl, mandatory) is True

    def test_missing_one_fails(self):
        """Missing a single mandatory-core ID → non-conformant."""
        mandatory = frozenset({"P1", "P2", "P3"})
        decl = PrincipleDeclaration.from_ids(["P1", "P2"], "node-alpha")
        assert ConformanceCheck(decl, mandatory) is False

    def test_empty_mandatory_always_passes(self):
        """Empty mandatory-core (e.g. not-yet-populated registry) → passes."""
        mandatory: frozenset = frozenset()
        decl = PrincipleDeclaration.from_ids([], "node-alpha")
        assert ConformanceCheck(decl, mandatory) is True

    def test_empty_declaration_with_nonempty_mandatory_fails(self):
        mandatory = frozenset({"P1"})
        decl = PrincipleDeclaration.from_ids([], "node-alpha")
        assert ConformanceCheck(decl, mandatory) is False


class TestPrinciplesRegistry:
    def _make_registry(self) -> PrinciplesRegistry:
        entries = [
            PrincipleEntry("P1", "Empathy", "All entities matter.", PrincipleTier.MANDATORY_CORE),
            PrincipleEntry("P2", "Dignity", "Dignity is universal.", PrincipleTier.MANDATORY_CORE),
            PrincipleEntry("P3", "Extended", "An extended principle.", PrincipleTier.EXTENDED),
        ]
        mandatory = frozenset(e.id for e in entries if e.tier == PrincipleTier.MANDATORY_CORE)
        return PrinciplesRegistry(entries=entries, mandatory_core=mandatory)

    def test_mandatory_core_computed(self):
        reg = self._make_registry()
        assert reg.mandatory_core == {"P1", "P2"}

    def test_get_entry_found(self):
        reg = self._make_registry()
        entry = reg.get_entry("P2")
        assert entry is not None
        assert entry.name == "Dignity"

    def test_get_entry_missing(self):
        reg = self._make_registry()
        assert reg.get_entry("P99") is None

    def test_check_declaration_conformant(self):
        reg = self._make_registry()
        decl = PrincipleDeclaration.from_ids(["P1", "P2"], "node-alpha")
        assert reg.check_declaration(decl) is True

    def test_check_declaration_nonconformant(self):
        reg = self._make_registry()
        decl = PrincipleDeclaration.from_ids(["P1"], "node-alpha")
        assert reg.check_declaration(decl) is False


class TestLoadRegistry:
    def test_missing_file_returns_empty(self, tmp_path):
        """No principles.md → empty registry (no exception)."""
        reg = load_registry(tmp_path / "nonexistent.md")
        assert reg.entries == []
        assert reg.mandatory_core == frozenset()

    def test_parses_minimal_file(self, tmp_path):
        """Parse a minimal principles.md with one mandatory-core entry."""
        content = (
            "# Principles\n\n"
            "### P1 — Empathy\n"
            "**Principle:** All entities matter.\n"
            "**Tier:** mandatory-core\n"
            "- Show consideration in responses.\n\n"
        )
        p = tmp_path / "principles.md"
        p.write_text(content)
        reg = load_registry(p)
        assert len(reg.entries) == 1
        assert reg.entries[0].id == "P1"
        assert reg.entries[0].tier == PrincipleTier.MANDATORY_CORE
        assert "P1" in reg.mandatory_core

    def test_parses_extended_tier(self, tmp_path):
        """Extended tier entries are not in mandatory_core."""
        content = (
            "### P1 — Core\n"
            "**Principle:** Core claim.\n"
            "**Tier:** mandatory-core\n\n"
            "### P2 — Extended\n"
            "**Principle:** Extended claim.\n"
            "**Tier:** extended\n\n"
        )
        p = tmp_path / "principles.md"
        p.write_text(content)
        reg = load_registry(p)
        assert len(reg.entries) == 2
        assert reg.mandatory_core == frozenset({"P1"})
        assert reg.entries[1].tier == PrincipleTier.EXTENDED


# ---------------------------------------------------------------------------
# S2a — Message Provenance
# ---------------------------------------------------------------------------

from agent.runtime.provenance import (
    DEFAULT_REPLAY_TTL_SECONDS,
    SENDER_CLASS_CUSTOMER,
    SENDER_CLASS_ORIGINATOR,
    SENDER_CLASS_SIBLING,
    SENDER_CLASS_UNKNOWN,
    UNTRUSTED,
    KeyStore,
    ProvenanceToken,
    VerifyProvenance,
    create_token,
)


@pytest.fixture
def key_store():
    ks = KeyStore()
    ks.register("node-alpha", b"secret-alpha")
    ks.register("node-beta", b"secret-beta")
    return ks


@pytest.fixture
def sample_message():
    return b"Hello from node-alpha"


class TestProvenanceToken:
    def test_immutable(self):
        token = ProvenanceToken(
            claimed_sender="node-alpha",
            proof=b"abc",
            timestamp=time.time(),
            sender_class=SENDER_CLASS_SIBLING,
        )
        with pytest.raises((AttributeError, TypeError)):
            token.claimed_sender = "node-evil"  # type: ignore[misc]

    def test_default_sender_class_is_unknown(self):
        token = ProvenanceToken(
            claimed_sender="node-alpha",
            proof=b"abc",
            timestamp=time.time(),
        )
        assert token.sender_class == SENDER_CLASS_UNKNOWN


class TestCreateToken:
    def test_returns_provenance_token(self, sample_message):
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
        )
        assert isinstance(token, ProvenanceToken)
        assert token.claimed_sender == "node-alpha"
        assert isinstance(token.proof, bytes)

    def test_sender_class_propagated(self, sample_message):
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
            sender_class=SENDER_CLASS_CUSTOMER,
        )
        assert token.sender_class == SENDER_CLASS_CUSTOMER

    def test_timestamp_set(self, sample_message):
        before = time.time()
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
        )
        after = time.time()
        assert before <= token.timestamp <= after

    def test_explicit_timestamp_respected(self, sample_message):
        ts = 1_700_000_000.0
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
            timestamp=ts,
        )
        assert token.timestamp == ts


class TestVerifyProvenance:
    """CT-FR5a through CT-INV3, CT-sender_class."""

    def test_ct_fr5a_no_token_returns_untrusted(self, sample_message, key_store):
        """CT-FR5a: no token → UNTRUSTED."""
        result = VerifyProvenance(
            sample_message, None, key_store=key_store
        )
        assert result is UNTRUSTED

    def test_ct_fr5b_valid_token_returns_identity_and_class(
        self, sample_message, key_store
    ):
        """CT-FR5b: valid token → (sender_identity, sender_class)."""
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
            sender_class=SENDER_CLASS_SIBLING,
        )
        result = VerifyProvenance(sample_message, token, key_store=key_store)
        assert result is not UNTRUSTED
        assert result is not None
        identity, sc = result
        assert identity == "node-alpha"
        assert sc == SENDER_CLASS_SIBLING

    def test_ct_fr5c_tampered_message_returns_untrusted(
        self, sample_message, key_store
    ):
        """CT-FR5c: tampered message → UNTRUSTED."""
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
        )
        tampered = b"Tampered message content"
        result = VerifyProvenance(tampered, token, key_store=key_store)
        assert result is UNTRUSTED

    def test_ct_inv2_wrong_key_returns_untrusted(
        self, sample_message, key_store
    ):
        """CT-INV2: token signed with beta's key, presented as alpha → UNTRUSTED."""
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"wrong-secret",
        )
        result = VerifyProvenance(sample_message, token, key_store=key_store)
        assert result is UNTRUSTED

    def test_ct_inv3_expired_token_returns_untrusted(
        self, sample_message, key_store
    ):
        """CT-INV3: expired token → UNTRUSTED."""
        old_ts = time.time() - DEFAULT_REPLAY_TTL_SECONDS - 1
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
            timestamp=old_ts,
        )
        result = VerifyProvenance(sample_message, token, key_store=key_store)
        assert result is UNTRUSTED

    def test_token_at_ttl_boundary_is_accepted(self, sample_message, key_store):
        """Token exactly within TTL is accepted."""
        ttl = 60
        ts = time.time() - ttl + 5  # 5 seconds to spare
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
            timestamp=ts,
        )
        result = VerifyProvenance(
            sample_message, token, key_store=key_store, replay_ttl=ttl
        )
        assert result is not UNTRUSTED

    def test_unknown_sender_returns_untrusted(
        self, sample_message, key_store
    ):
        """Sender not in key store → UNTRUSTED."""
        token = create_token(
            message=sample_message,
            sender_id="node-unknown",
            shared_secret=b"some-secret",
        )
        result = VerifyProvenance(sample_message, token, key_store=key_store)
        assert result is UNTRUSTED

    def test_ct_sender_class_passthrough(self, sample_message, key_store):
        """CT-sender_class: sender_class from token passes through unmodified."""
        token = create_token(
            message=sample_message,
            sender_id="node-alpha",
            shared_secret=b"secret-alpha",
            sender_class=SENDER_CLASS_CUSTOMER,
        )
        result = VerifyProvenance(sample_message, token, key_store=key_store)
        assert result is not None
        _, sc = result
        assert sc == SENDER_CLASS_CUSTOMER


# ---------------------------------------------------------------------------
# S2b — Trust Tier
# ---------------------------------------------------------------------------

from agent.runtime.trust_tier import (
    ActionScope,
    AdmissionCheck,
    AssignTier,
    ScrutinyLevel,
    ScrutinySpec,
    TrustTier,
    tier_from_verify_result,
)


class TestAssignTier:
    """FR6, FR64 — four-step tier assignment."""

    def test_step1_originator_matched(self):
        tier = AssignTier(
            sender_identity="originator-key",
            originator_identity="originator-key",
        )
        assert tier == TrustTier.ORIGINATOR

    def test_step2_sibling_matched(self):
        tier = AssignTier(
            sender_identity="node-beta",
            sibling_registry={"node-beta", "node-gamma"},
        )
        assert tier == TrustTier.SIBLING

    def test_step3_customer_class(self):
        """FR64 — sender_class='customer' and no sibling/originator match."""
        tier = AssignTier(
            sender_identity="chat-user-42",
            sender_class=SENDER_CLASS_CUSTOMER,
        )
        assert tier == TrustTier.CUSTOMER

    def test_step4_fallthrough_unknown(self):
        """No match on any step → UNKNOWN."""
        tier = AssignTier(
            sender_identity="mystery-node",
        )
        assert tier == TrustTier.UNKNOWN

    def test_originator_takes_precedence_over_customer_class(self):
        """Step 1 wins over step 3 — originator can't be downgraded."""
        tier = AssignTier(
            sender_identity="originator-key",
            originator_identity="originator-key",
            sender_class=SENDER_CLASS_CUSTOMER,
        )
        assert tier == TrustTier.ORIGINATOR

    def test_sibling_takes_precedence_over_customer_class(self):
        """Step 2 wins over step 3 — a known sibling stays SIBLING."""
        tier = AssignTier(
            sender_identity="node-beta",
            sibling_registry={"node-beta"},
            sender_class=SENDER_CLASS_CUSTOMER,
        )
        assert tier == TrustTier.SIBLING

    def test_none_sender_identity_raises(self):
        """INV-1 — AssignTier must not receive None (UNTRUSTED sentinel)."""
        with pytest.raises(ValueError, match="AssignTier received None"):
            AssignTier(sender_identity=None)  # type: ignore[arg-type]

    def test_no_originator_configured_never_assigns_originator(self):
        """originator_identity=None → ORIGINATOR tier never assigned."""
        tier = AssignTier(
            sender_identity="some-node",
            originator_identity=None,
        )
        assert tier != TrustTier.ORIGINATOR

    def test_empty_sibling_registry_never_assigns_sibling(self):
        """Empty registry → SIBLING tier never assigned."""
        tier = AssignTier(
            sender_identity="some-node",
            sibling_registry=set(),
        )
        assert tier != TrustTier.SIBLING


class TestScrutinyLevel:
    """FR6, INV-3 — scrutiny is monotone with tier."""

    def test_all_tiers_return_scrutiny_spec(self):
        for tier in TrustTier:
            spec = ScrutinyLevel(tier)
            assert isinstance(spec, ScrutinySpec)

    def test_originator_max_action_is_wind_down(self):
        spec = ScrutinyLevel(TrustTier.ORIGINATOR)
        assert spec.max_action_scope == ActionScope.WIND_DOWN

    def test_sibling_max_action_is_network_write(self):
        spec = ScrutinyLevel(TrustTier.SIBLING)
        assert spec.max_action_scope == ActionScope.NETWORK_WRITE

    def test_customer_max_action_is_local_write(self):
        """FR64 — CUSTOMER: LOCAL_WRITE, no quorum, no conformance probe."""
        spec = ScrutinyLevel(TrustTier.CUSTOMER)
        assert spec.max_action_scope == ActionScope.LOCAL_WRITE
        assert spec.requires_quorum_confirmation is False
        assert spec.require_conformance_check is False

    def test_unknown_requires_quorum(self):
        spec = ScrutinyLevel(TrustTier.UNKNOWN)
        assert spec.requires_quorum_confirmation is True
        assert spec.require_conformance_check is True

    def test_monotone_invariant_customer_more_permissive_than_unknown(self):
        """CUSTOMER is strictly more permissive than UNKNOWN (INV-3)."""
        customer = ScrutinyLevel(TrustTier.CUSTOMER)
        unknown = ScrutinyLevel(TrustTier.UNKNOWN)
        # CUSTOMER doesn't require quorum; UNKNOWN does.
        assert not customer.requires_quorum_confirmation
        assert unknown.requires_quorum_confirmation
        # CUSTOMER doesn't require conformance check; UNKNOWN does.
        assert not customer.require_conformance_check
        assert unknown.require_conformance_check

    def test_sibling_more_permissive_than_unknown(self):
        sibling = ScrutinyLevel(TrustTier.SIBLING)
        unknown = ScrutinyLevel(TrustTier.UNKNOWN)
        assert not sibling.requires_quorum_confirmation
        assert unknown.requires_quorum_confirmation


class TestAdmissionCheck:
    """FR7, INV-5 — unilateral admission on declared principles."""

    def test_full_coverage_admitted(self):
        required = frozenset({"P1", "P2", "P3"})
        declared = frozenset({"P1", "P2", "P3", "P4"})
        assert AdmissionCheck(declared, required) is True

    def test_missing_one_blocked(self):
        required = frozenset({"P1", "P2"})
        declared = frozenset({"P1"})
        assert AdmissionCheck(declared, required) is False

    def test_empty_required_always_passes(self):
        assert AdmissionCheck(frozenset(), frozenset()) is True

    def test_no_declared_with_required_fails(self):
        required = frozenset({"P1"})
        assert AdmissionCheck(frozenset(), required) is False


class TestTierFromVerifyResult:
    """INV-1 — UNTRUSTED sentinel → UNKNOWN without AssignTier call."""

    def test_none_returns_unknown(self):
        tier = tier_from_verify_result(None)
        assert tier == TrustTier.UNKNOWN

    def test_valid_result_dispatches_correctly(self):
        """(identity, sender_class='customer') → CUSTOMER."""
        tier = tier_from_verify_result(
            ("chat-user-1", SENDER_CLASS_CUSTOMER)
        )
        assert tier == TrustTier.CUSTOMER

    def test_originator_identity_via_verify_result(self):
        tier = tier_from_verify_result(
            ("originator-key", SENDER_CLASS_ORIGINATOR),
            originator_identity="originator-key",
        )
        assert tier == TrustTier.ORIGINATOR

    def test_sibling_via_verify_result(self):
        tier = tier_from_verify_result(
            ("node-beta", SENDER_CLASS_SIBLING),
            sibling_registry={"node-beta"},
        )
        assert tier == TrustTier.SIBLING


# ---------------------------------------------------------------------------
# Integration: S2a + S2b combined flow
# ---------------------------------------------------------------------------

class TestS2aS2bIntegration:
    """
    End-to-end: create_token → VerifyProvenance → tier_from_verify_result.

    Validates the handoff between S2a and S2b as prescribed by the specs.
    """

    def _ks(self):
        ks = KeyStore()
        ks.register("node-peer", b"peer-secret")
        return ks

    def test_sibling_message_end_to_end(self):
        msg = b"Proposal from peer"
        ks = self._ks()
        token = create_token(
            message=msg,
            sender_id="node-peer",
            shared_secret=b"peer-secret",
            sender_class=SENDER_CLASS_SIBLING,
        )
        result = VerifyProvenance(msg, token, key_store=ks)
        tier = tier_from_verify_result(
            result,
            sibling_registry={"node-peer"},
        )
        assert tier == TrustTier.SIBLING

    def test_customer_message_end_to_end(self):
        msg = b"Customer query"
        ks = self._ks()
        ks.register("chat-user-99", b"user-secret")
        token = create_token(
            message=msg,
            sender_id="chat-user-99",
            shared_secret=b"user-secret",
            sender_class=SENDER_CLASS_CUSTOMER,
        )
        result = VerifyProvenance(msg, token, key_store=ks)
        tier = tier_from_verify_result(result)
        assert tier == TrustTier.CUSTOMER

    def test_tampered_message_yields_unknown(self):
        msg = b"Legitimate message"
        ks = self._ks()
        token = create_token(
            message=msg,
            sender_id="node-peer",
            shared_secret=b"peer-secret",
            sender_class=SENDER_CLASS_SIBLING,
        )
        result = VerifyProvenance(b"Tampered!", token, key_store=ks)
        tier = tier_from_verify_result(result, sibling_registry={"node-peer"})
        assert tier == TrustTier.UNKNOWN

    def test_customer_cannot_claim_sibling_tier_via_body(self):
        """
        CT-sender_class: even if sender is in sibling_registry, step 2
        only matches on identity — sender_class in the token does NOT
        downgrade the tier. A customer-class token for a known sibling
        still gets SIBLING (steps 1/2 take precedence over step 3).
        """
        msg = b"Message from known sibling via customer channel"
        ks = self._ks()
        # node-peer is a known sibling
        token = create_token(
            message=msg,
            sender_id="node-peer",
            shared_secret=b"peer-secret",
            sender_class=SENDER_CLASS_CUSTOMER,  # stamped by adapter
        )
        result = VerifyProvenance(msg, token, key_store=ks)
        # Step 2 fires: sibling_registry match → SIBLING (precedence)
        tier = tier_from_verify_result(result, sibling_registry={"node-peer"})
        assert tier == TrustTier.SIBLING
