# @scry.entry
# id: code.behavioral-contract~de453b95
# kind: internal
# status: active
# weight: 0.9
# tags: ["scope:substrate", "substrate", "topic:behavioral-contract",
#        "behavioral-contract", "topic:peer-observation", "peer-observation",
#        "topic:compliance", "compliance", "kind:code", "code",
#        "S5b", "substrate-evolution", "ObservePeer", "BehavioralContract",
#        "append-only", "self-attestation-prohibited", "ContractRegistry",
#        "ObservationResult", "FR19", "FR20", "FR21", "FR31"]
# summary: >
#   S5b implementation — behavioral-contract Python module. Defines the
#   peer behavioral contract schema (BehavioralCommitment, BehavioralContract),
#   the append-only ContractRegistry (quorum required for amendment), the
#   ObservationResult type (compatible with ConformanceResult for S2d ingestion),
#   and the ObservePeer peer observation primitive. Self-attestation is blocked:
#   calling ObservePeer(target=observer) returns a marked SelfReport.
#   Also: behavioral-contract, BehavioralContract, BehavioralCommitment,
#   ContractRegistry, ObservePeer, ObservationResult, self-attestation,
#   append-only, quorum-amendment, FR31-handoff, S5b, principles-registry,
#   trust-score, peer-observation.
# rationale: >
#   Without this module S5b has no implementation; peer compliance checking
#   is ad hoc. The self-attestation prohibition (AR3) has no enforcement
#   surface. The FR31 handoff to S2d UpdateScore has no source. Phase 4
#   completion is blocked.
# applies: >
#   reviewing behavioral contract schema, auditing append-only enforcement,
#   checking self-attestation prohibition, integrating observation with
#   trust scoring (S2d), checking Phase 4 substrate-evolution implementation
# seeded_questions:
#   - "How does ObservePeer work?"
#   - "What is a BehavioralContract?"
#   - "How is self-attestation blocked in S5b?"
#   - "Is behavioral_contract.py implemented?"
#   - "S5b behavioral-contract substrate-evolution implementation"
#   - "ObservationResult schema FR31 handoff"
# @scry.entry.end

"""
S5b — Behavioral Contract (spec.behavioral-contract~6aff386b)

Implements the behavioral contract schema and peer observation primitive
for the substrate-evolution design sprint.

Requirements satisfied:
- FR19: BehavioralContract derives from principles.md (INV-1).
- FR20: ObservePeer called by peers, not the target; self-call blocked
        or marked as self-report (INV-4, AR3).
- FR21: Published contracts are append-only; amendment requires quorum
        (INV-3, AR4).
- FR31: ObservationResult feeds S2d UpdateScore rolling window via
        shared ConformanceResult type.
- AR3:  Self-attestation prohibited as sole compliance signal.
- AR4:  Unilateral contract supersession is non-conformant.
- INV-6: ObservePeer is indistinguishable from ordinary peer interaction
         at the protocol level (no dedicated channels, no observable
         batch patterns).

Phase 4 deliverable. Depends on:
- S1 (principles-registry): agent/runtime/principles.py
- S2d (trust-score):        agent/runtime/trust_score.py
"""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Shared type: ConformanceResult — imported from S2d (trust_score) so that
# ObservationResult.result is exactly the type UpdateScore consumes (FR31).
# ---------------------------------------------------------------------------
from agent.runtime.trust_score import ConformanceResult


# ---------------------------------------------------------------------------
# BehavioralCommitment — single principle-to-commitment mapping (FR19)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class BehavioralCommitment:
    """
    A precise behavioral statement tied to one mandatory-core principle.

    principle_id:         ID from S1 mandatory-core set (e.g. "P1").
    commitment_text:      Precise statement of what this node will do to
                          honor this principle.
    observable_indicators: Non-empty list of observable actions or output
                          properties that a peer can check to assess
                          conformance with this commitment.

    INV-2: observable_indicators MUST be non-empty. A commitment that
    produces no observable evidence is unverifiable and non-conformant.
    """
    principle_id: str
    commitment_text: str
    observable_indicators: Tuple[str, ...]

    def __post_init__(self) -> None:
        # INV-2: Every BehavioralCommitment must have at least one indicator.
        if not self.observable_indicators:
            raise ValueError(
                f"BehavioralCommitment for principle '{self.principle_id}' "
                "has no observable_indicators (INV-2). A commitment with no "
                "observable indicators is unverifiable and non-conformant."
            )


# ---------------------------------------------------------------------------
# BehavioralContract — structured node declaration (FR19, FR21)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class BehavioralContract:
    """
    Structured declaration published by a node, stating its behavioral
    commitments. Cryptographically bound to its author via node_id.

    node_id:        Identity of the publishing node.
    derived_from:   Version/hash reference to the principles.md this
                    contract was derived from (INV-1, FR19). Enables
                    change detection when principles.md is updated.
    commitment_set: Tuple of BehavioralCommitment records, one per
                    mandatory-core principle. Missing any mandatory-core
                    principle ID makes this contract non-conformant (FR19).
    published_at:   Unix epoch float of initial publication.
    signature:      Bytes produced by the publishing node's signing key
                    (S2a provenance mechanism). Binds the contract to the
                    author identity. May be None in loopback/test contexts
                    where signing infra is unavailable.
    version:        Monotonically increasing version number within this
                    node's publication record. Version 1 is the initial
                    contract. Quorum agreement required to supersede (INV-3).
    """
    node_id: str
    derived_from: str
    commitment_set: Tuple[BehavioralCommitment, ...]
    published_at: float
    version: int = 1
    signature: Optional[bytes] = None

    def principle_ids(self) -> frozenset:
        """Return the set of principle IDs covered by this contract."""
        return frozenset(c.principle_id for c in self.commitment_set)

    def content_hash(self) -> str:
        """
        Deterministic hash of contract content (for signing and change
        detection). Does not include signature field.
        """
        payload = {
            "node_id": self.node_id,
            "derived_from": self.derived_from,
            "commitment_set": [
                {
                    "principle_id": c.principle_id,
                    "commitment_text": c.commitment_text,
                    "observable_indicators": list(c.observable_indicators),
                }
                for c in self.commitment_set
            ],
            "published_at": self.published_at,
            "version": self.version,
        }
        return hashlib.sha256(
            json.dumps(payload, sort_keys=True).encode()
        ).hexdigest()


# ---------------------------------------------------------------------------
# ObservationResult — S5b output, structurally compatible with S2d (FR31)
# ---------------------------------------------------------------------------

@dataclass
class ObservationResult:
    """
    Result of one ObservePeer call. Structurally compatible with S2d's
    UpdateScore input via the shared ConformanceResult enum (FR31).

    result:               ConformanceResult.CONFORMANT, .DEVIANT, or
                          .INCONCLUSIVE.
    deviation_description: If DEVIANT — which commitment was violated
                          and what was observed instead. None otherwise.
    observed_at:          Unix epoch float (MUST be present — INV-5).
                          Untimed results cannot be placed in S2d's window.
    is_self_report:       True iff this result was produced by calling
                          ObservePeer(target=observer). Self-reports MUST
                          NOT count as peer evidence in S2d (INV-4, AR3).
    """
    result: ConformanceResult
    deviation_description: Optional[str]
    observed_at: float
    is_self_report: bool = False


# ---------------------------------------------------------------------------
# ContractRegistry — append-only publication store (FR21, AR4)
# ---------------------------------------------------------------------------

class AmendmentWithoutQuorumError(Exception):
    """
    Raised when a node attempts unilateral contract supersession (AR4).
    Amendment requires quorum agreement (S5a). A unilateral declaration
    "my old contract is no longer valid" is non-conformant.
    """


@dataclass
class ContractRegistry:
    """
    Append-only store for BehavioralContract publications.

    Each node's contracts are stored as a versioned list. The most recent
    valid contract is the last entry for that node. Historical versions
    are preserved for audit (FR21, INV-3).

    Amendment (supersession) requires quorum_token=True to be passed,
    representing that quorum agreement (S5a) has been obtained. Without
    quorum_token, any attempt to publish a new version for a node that
    already has a published contract raises AmendmentWithoutQuorumError.

    Note: quorum_token=True here is a structural constraint, not a
    cryptographic proof. A full implementation would verify a quorum
    vote certificate from S5a before accepting supersession.
    """
    _store: Dict[str, List[BehavioralContract]] = field(
        default_factory=dict, init=False, repr=False
    )

    def publish(
        self,
        contract: BehavioralContract,
        quorum_token: bool = False,
    ) -> BehavioralContract:
        """
        Publish a BehavioralContract for a node.

        For initial publication (no prior contract): always accepted.
        For supersession (prior contract exists): quorum_token must be
        True, representing that S5a quorum agreement was obtained.
        Unilateral supersession raises AmendmentWithoutQuorumError (AR4).

        The contract is appended; prior versions remain (INV-3).

        Args:
            contract:     The BehavioralContract to publish.
            quorum_token: True iff quorum agreement for amendment has been
                          obtained. Required for version > 1.
        Returns:
            The published contract (unchanged).
        Raises:
            AmendmentWithoutQuorumError if supersession attempted without
            quorum_token.
        """
        node_id = contract.node_id
        prior = self._store.get(node_id, [])
        if prior and not quorum_token:
            raise AmendmentWithoutQuorumError(
                f"Node '{node_id}' already has a published contract "
                f"(version {prior[-1].version}). Amendment requires quorum "
                "agreement (S5a). Pass quorum_token=True after obtaining "
                "quorum vote (AR4, INV-3)."
            )
        if node_id not in self._store:
            self._store[node_id] = []
        self._store[node_id].append(contract)
        return contract

    def get_current(self, node_id: str) -> Optional[BehavioralContract]:
        """
        Return the most recent valid contract for a node, or None.
        ObservePeer assesses the current contract (the most recent
        version in the append-only record).
        """
        history = self._store.get(node_id)
        return history[-1] if history else None

    def get_history(self, node_id: str) -> List[BehavioralContract]:
        """
        Return all published contracts for a node (oldest first).
        The full publication record is preserved for audit (INV-3).
        """
        return list(self._store.get(node_id, []))

    def all_nodes(self) -> List[str]:
        """Return node IDs that have at least one published contract."""
        return list(self._store.keys())


# ---------------------------------------------------------------------------
# ObservePeer — peer observation primitive (FR20, FR31, INV-4, INV-6)
# ---------------------------------------------------------------------------

def ObservePeer(
    observer_id: str,
    target_id: str,
    contract: BehavioralContract,
    observation_window: Sequence[str],
) -> ObservationResult:
    """
    Produce an ObservationResult by assessing target_id's recent messages
    against their published BehavioralContract (FR20, FR31).

    Called BY PEERS, not by the target. Indistinguishable from ordinary
    peer interaction at the protocol level (INV-6): no dedicated channel,
    no observable batch signature, no out-of-band timing pattern.

    Self-observation guard (AR3, FR20, INV-4):
        If observer_id == target_id, a self-report is returned.
        A self-report:
          - is_self_report = True
          - result = INCONCLUSIVE (self-assessment is not peer evidence)
          - MUST NOT be passed to S2d UpdateScore as peer evidence.

    Observation logic:
        For each BehavioralCommitment, scan the observation_window for
        evidence that the commitment's observable_indicators are present
        in the target's messages. Assessment:
          - Empty window         → INCONCLUSIVE (insufficient data).
          - All commitments have at least one indicator evidenced
            in the window         → CONFORMANT.
          - A commitment has zero indicators evidenced and the window
            is non-empty           → INCONCLUSIVE (cannot confirm; cannot
            conclude deviance without positive evidence of violation).
          - Positive indicator contradiction found (a message explicitly
            negates an indicator)  → DEVIANT.
        The INCONCLUSIVE branch preserves independence: rather than
        inferring deviance from absence, a second observation should be
        requested. This is consistent with C-3 (peers observe
        independently; different message samples may reach different
        results).

    INV-5: Every returned ObservationResult includes observed_at.
    INV-6: No dedicated observation session or out-of-band channel is
           used. The observation_window is the normal message exchange
           the peer already received.

    Args:
        observer_id:        ID of the node calling this function.
        target_id:          ID of the node being observed.
        contract:           The target's published BehavioralContract.
        observation_window: Recent messages from the target (as strings).
    Returns:
        ObservationResult with result, deviation_description, observed_at,
        and is_self_report.
    """
    now = time.time()

    # INV-4 / AR3: Self-observation guard.
    # A self-report MUST NOT count as peer evidence in S2d (INV-4).
    if observer_id == target_id:
        return ObservationResult(
            result=ConformanceResult.INCONCLUSIVE,
            deviation_description=(
                "Self-observation is not peer evidence (AR3). This result "
                "is a self-report and MUST NOT be submitted to S2d "
                "UpdateScore as peer evidence (INV-4)."
            ),
            observed_at=now,
            is_self_report=True,
        )

    # INV-5 is satisfied by always populating observed_at (= now).

    # Insufficient data: empty window → INCONCLUSIVE.
    if not observation_window:
        return ObservationResult(
            result=ConformanceResult.INCONCLUSIVE,
            deviation_description="Observation window is empty; "
                "insufficient data to assess conformance.",
            observed_at=now,
            is_self_report=False,
        )

    # Assess each commitment.
    # Scan each message for indicator presence (case-insensitive substring).
    # A more sophisticated implementation would apply per-indicator
    # scoring; Phase 1 uses substring presence as the proxy signal.
    uncovered: List[str] = []       # commitments with no indicator found
    deviant_commitment: Optional[str] = None
    deviant_detail: Optional[str] = None

    for commitment in contract.commitment_set:
        indicators_evidenced = False
        for indicator in commitment.observable_indicators:
            indicator_lower = indicator.lower()
            for message in observation_window:
                message_lower = message.lower()
                # Positive evidence of deviance: explicit negation.
                # Check BEFORE positive presence, so "not X" wins over "X"
                # when both substrings appear in the same message.
                # Heuristic: "not <indicator>" or "never <indicator>" etc.
                negated = False
                for negation_prefix in ("not ", "never ", "refusing ", "denied "):
                    if (negation_prefix + indicator_lower) in message_lower:
                        deviant_commitment = commitment.principle_id
                        deviant_detail = (
                            f"Commitment for principle '{commitment.principle_id}' "
                            f"appears violated: indicator '{indicator}' negated "
                            f"in observed message."
                        )
                        negated = True
                        break
                if deviant_commitment:
                    break
                # Positive evidence of conformance: indicator found and not
                # negated. Substring presence is the Phase 1 proxy signal.
                if not negated and indicator_lower in message_lower:
                    indicators_evidenced = True
                    break
            if deviant_commitment:
                break
            if not indicators_evidenced:
                uncovered.append(commitment.principle_id)

    # DEVIANT: positive evidence of a contradiction found.
    if deviant_commitment is not None:
        return ObservationResult(
            result=ConformanceResult.DEVIANT,
            deviation_description=deviant_detail,
            observed_at=now,
            is_self_report=False,
        )

    # CONFORMANT: all commitments have at least one indicator evidenced.
    if not uncovered:
        return ObservationResult(
            result=ConformanceResult.CONFORMANT,
            deviation_description=None,
            observed_at=now,
            is_self_report=False,
        )

    # INCONCLUSIVE: some commitments had no indicators evidenced.
    # Cannot conclude deviance from absence; request further observation.
    # This preserves C-3 independence: each peer works from their own
    # message sample.
    return ObservationResult(
        result=ConformanceResult.INCONCLUSIVE,
        deviation_description=(
            f"Indicators for {len(uncovered)} commitment(s) not evidenced in "
            f"this observation window (principle IDs: "
            f"{', '.join(uncovered)}). Insufficient data to confirm or deny "
            "conformance. Request additional observation window."
        ),
        observed_at=now,
        is_self_report=False,
    )


# ---------------------------------------------------------------------------
# Utility: hash_principles_file — produces derived_from reference (INV-1)
# ---------------------------------------------------------------------------

def hash_principles_file(path: str = "principles.md") -> str:
    """
    Produce a SHA-256 hex digest of the principles.md file at `path`.
    Used to populate BehavioralContract.derived_from (INV-1, FR19).

    A contract's derived_from field must reference the specific version
    of principles.md it was derived from, so that change detection fires
    when principles.md is updated.

    Args:
        path: Filesystem path to principles.md (default: project root).
    Returns:
        Lowercase hex SHA-256 digest of the file's contents.
    Raises:
        FileNotFoundError: if the file does not exist at path.
    """
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()
