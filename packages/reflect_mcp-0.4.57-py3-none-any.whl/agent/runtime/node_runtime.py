# @scry.entry
# id: code.node-runtime~1e323967
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:node-runtime", "node-runtime",
#        "topic:cluster", "cluster", "topic:S7a", "S7a", "kind:code", "code",
#        "substrate-evolution", "NodeIdentity", "NodeEndpoint",
#        "join-cluster", "leave-cluster", "keypair", "key-rotation",
#        "Ed25519", "state-persistence"]
# summary: >
#   S7a implementation — node-runtime Python module. Implements NodeIdentity
#   (node_id + public_key), NodeEndpoint (node_id + address), generate_keypair
#   (Ed25519), and the Node class lifecycle: get_identity, get_endpoint,
#   join_cluster (FR37 — announce + register peers), leave_cluster (FR38 —
#   notify + drain), rotate_keypair (FR39 — publish new identity before
#   activating). Persistent local state (JSON file); stable node_id across
#   restarts (INV-S7a-2); private key local-only (INV-S7a-3); key rotation is
#   quorum-observable (INV-S7a-4); NOT triggered by S6a self-modification
#   (INV-S7a-5). Also: node-runtime, NodeIdentity, NodeEndpoint, Node,
#   generate_keypair, join_cluster, leave_cluster, rotate_keypair, S7a,
#   substrate-evolution, node_runtime.py, FR34, FR35, FR36, FR37, FR38, FR39.
# rationale: >
#   Without this, S7b (inter-node-transport) has no NodeEndpoint type to
#   address, S7c (cluster-harness) has no lifecycle operations to invoke,
#   and S5a/S5b/S5c all operate on nodes that are never defined. The
#   entire cluster stack collapses to undefined types.
# applies: >
#   building the inter-node transport layer (S7b), provisioning a cluster
#   (S7c), auditing keypair rotation separation from self-modification,
#   designing node identity persistence, reviewing cluster join/leave protocol
# seeded_questions:
#   - "What is NodeIdentity?"
#   - "What is NodeEndpoint?"
#   - "How does a node join the cluster?"
#   - "How does key rotation work and when is it triggered?"
#   - "Is key rotation separate from self-modification?"
#   - "How is node state persisted?"
#   - "node_runtime.py S7a substrate-evolution"
#   - "join_cluster leave_cluster FR37 FR38"
#   - "rotate_keypair FR39 quorum-observable"
# @scry.entry.end

"""
S7a — Node Runtime (spec.node-runtime~94177fb1)

Defines a single reflection cluster node: its identity (keypair,
node_id, endpoint), local persistent state, and lifecycle operations
(start, stop, join_cluster, leave_cluster, rotate_keypair).

Algorithm: Ed25519 asymmetric keypairs.
  - Chosen for: compact keys, fast verification, wide library support.
  - S2a compatibility: Ed25519 satisfies S2a's algorithm-agnostic
    VerifyProvenance interface (the signing primitive is owned here;
    the provenance protocol is in provenance.py).

Requirements satisfied:
- FR34: Keypair generation at node creation time.
- FR35: get_identity() → NodeIdentity (stable node_id).
- FR36: get_endpoint() → NodeEndpoint (routable, stable).
- FR37: join_cluster(peers) — register, announce, activate.
- FR38: leave_cluster() — notify peers, drain, deactivate.
- FR39: rotate_keypair() — publish new identity before activating.
- INV-S7a-1: Exactly one active keypair per node.
- INV-S7a-2: node_id stable across restarts.
- INV-S7a-3: Private key is local-only; never transmitted.
- INV-S7a-4: Key rotation is quorum-observable (peers notified first).
- INV-S7a-5: Key rotation NOT triggered by S6a self-modification.
- INV-S7a-6: State persists across process crash and restart.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

# ---------------------------------------------------------------------------
# Deployment parameters
# ---------------------------------------------------------------------------

# How long (seconds) to wait for in-flight messages to drain on
# leave_cluster before forcing shutdown.
DRAIN_TIMEOUT_SECONDS: float = 5.0

# How long (seconds) the old keypair remains verifiable for in-flight
# messages after a rotation.
KEY_GRACE_PERIOD_SECONDS: float = 30.0

# Default startup timeout (seconds) to reach ready-to-join state.
STARTUP_TIMEOUT_SECONDS: float = 10.0

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NodeIdentity:
    """
    A node's stable identifier and current public key (FR35).

    node_id is assigned at creation and never changes (INV-S7a-2).
    public_key reflects the current active keypair and changes on
    rotate_keypair() (FR39).
    """

    node_id: str      # stable opaque identifier; unique in cluster
    public_key: bytes  # public half of the node's current signing keypair


@dataclass(frozen=True)
class NodeEndpoint:
    """
    How peers address this node on the transport layer (FR36).

    address is opaque and backend-specific:
      loopback backend: "host:port"
      droplet backend:  "IP:port"

    Callers pass it through without inspecting the address field.
    """

    node_id: str   # resolves to the owning NodeIdentity
    address: str   # opaque; backend-specific


# ---------------------------------------------------------------------------
# Keypair helpers
# ---------------------------------------------------------------------------


def generate_keypair() -> tuple[bytes, bytes]:
    """
    Generate a fresh Ed25519 keypair (FR34).

    Returns (public_key_bytes, private_key_bytes).

    Private key bytes are in PKCS8 DER format (for local storage).
    Public key bytes are in SubjectPublicKeyInfo DER format (for
    sharing in NodeIdentity).

    INV-S7a-3: The private key returned here MUST only be stored
    locally. Callers MUST NOT transmit it over the network.
    """
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    priv_bytes = private_key.private_bytes(
        Encoding.DER, PrivateFormat.PKCS8, NoEncryption()
    )
    pub_bytes = public_key.public_bytes(Encoding.DER, PublicFormat.SubjectPublicKeyInfo)
    return pub_bytes, priv_bytes


def _load_private_key(priv_bytes: bytes) -> Ed25519PrivateKey:
    """Deserialize a stored private key from DER bytes."""
    from cryptography.hazmat.primitives.serialization import load_der_private_key
    return load_der_private_key(priv_bytes, password=None)


def sign_bytes(private_key_bytes: bytes, data: bytes) -> bytes:
    """
    Sign arbitrary data with a stored private key (used by S7b
    for envelope signing).  Returns raw signature bytes.

    Called by the transport layer (S7b) when building MessageEnvelopes;
    the signing material (data) is: (message_id + sent_at + term +
    payload_hash), per S7b's MessageEnvelope schema.

    INV-S7a-3: This function never returns or logs the private key.
    """
    private_key = _load_private_key(private_key_bytes)
    return private_key.sign(data)


# ---------------------------------------------------------------------------
# Persistent state schema
# ---------------------------------------------------------------------------
#
# Written to a JSON file at state_path. Fields:
#   node_id:      str  (stable, never changes)
#   public_key:   hex  (current active public key)
#   private_key:  hex  (current active private key — NEVER logged)
#   address:      str  (current endpoint address)
#   peers:        list[{node_id, address}]  (last-known cluster peers)
#
# INV-S7a-6: This file survives process crash; a restarted node
# reads it and recovers its identity without generating a new keypair.


def _load_state(state_path: Path) -> dict:
    with open(state_path, "r") as f:
        return json.load(f)


def _save_state(state_path: Path, state: dict) -> None:
    # Atomic write via rename to prevent partial-write corruption.
    tmp = state_path.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(state, f, indent=2)
    os.replace(tmp, state_path)


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------


class Node:
    """
    A single reflection cluster node.

    Lifecycle:
      1. Node(state_path, address) — create or recover from disk.
      2. join_cluster(peers)        — enter the cluster.
      3. ... participate in S5a/S5b/S5c/S5d/S6b via S7b transport ...
      4. leave_cluster()            — clean departure.

    Key rotation (FR39) is a distinct lifecycle event, invoked
    explicitly by an operator or cluster protocol — NOT a side effect
    of any S6a self-modification (INV-S7a-5).

    The node exposes a `peer_notify_callback` hook so callers (S7b,
    S7c) can inject the actual transport send; this keeps S7a free of
    S7b's import dependency while preserving the quorum-observable
    invariants (INV-S7a-4).
    """

    def __init__(
        self,
        state_path: Path,
        address: str,
        peer_notify_callback: Optional[Callable[[NodeEndpoint, NodeIdentity], None]] = None,
    ) -> None:
        """
        Create a node or recover from existing persistent state.

        state_path: where to read/write the JSON state file.
        address:    this node's transport address (opaque, backend-specific).
        peer_notify_callback:
            Called when this node needs to announce its (new) NodeIdentity
            to a peer. Signature: (peer_endpoint, new_identity) → None.
            If None, announcements are silently skipped (useful in tests
            that do not exercise the transport layer).
        """
        self._state_path = state_path
        self._address = address
        self._active_in_cluster = False
        self._peers: list[NodeEndpoint] = []
        self._notify = peer_notify_callback or (lambda _ep, _id: None)

        if state_path.exists():
            # INV-S7a-2 / INV-S7a-6: recover existing identity.
            state = _load_state(state_path)
            self._node_id: str = state["node_id"]
            self._public_key_bytes: bytes = bytes.fromhex(state["public_key"])
            self._private_key_bytes: bytes = bytes.fromhex(state["private_key"])
            # Recover peers from last-known state.
            self._peers = [
                NodeEndpoint(p["node_id"], p["address"])
                for p in state.get("peers", [])
            ]
        else:
            # FR34: first-time creation — generate a fresh keypair.
            self._node_id = str(uuid.uuid4())
            pub, priv = generate_keypair()
            self._public_key_bytes = pub
            self._private_key_bytes = priv
            self._persist()

    # ------------------------------------------------------------------
    # Core identity / endpoint queries
    # ------------------------------------------------------------------

    def get_identity(self) -> NodeIdentity:
        """
        Return the node's current identity (node_id + public_key).
        FR35.
        """
        return NodeIdentity(
            node_id=self._node_id,
            public_key=self._public_key_bytes,
        )

    def get_endpoint(self) -> NodeEndpoint:
        """
        Return the node's current endpoint (node_id + address).
        FR36.
        """
        return NodeEndpoint(
            node_id=self._node_id,
            address=self._address,
        )

    def get_private_key_bytes(self) -> bytes:
        """
        Return the raw private key bytes for signing.

        Used by S7b when constructing MessageEnvelope signatures.
        INV-S7a-3: Callers MUST NOT transmit these bytes; they are
        only for the local signing operation.
        """
        return self._private_key_bytes

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def join_cluster(self, peers: list[NodeEndpoint]) -> None:
        """
        Join the cluster formed by the given peer set (FR37).

        Steps:
          (a) Register each peer endpoint locally.
          (b) Announce own NodeIdentity + NodeEndpoint to each peer.
          (c) Transition to active-in-cluster state.

        A node MUST NOT participate in any cluster protocol (S5a/S5b/
        S5c) before join_cluster completes.
        """
        self._peers = list(peers)
        self._persist()

        own_identity = self.get_identity()
        for peer in self._peers:
            # (b) Announce our identity to each peer. The callback
            # carries our NodeIdentity; peers update their routing tables.
            self._notify(peer, own_identity)

        self._active_in_cluster = True  # (c) FR37

    def leave_cluster(self) -> None:
        """
        Leave the cluster cleanly (FR38).

        Steps:
          (a) Notify peers of departure.
          (b) Drain in-flight messages (bounded by DRAIN_TIMEOUT_SECONDS).
          (c) Transition to inactive state.

        Hard stop without peer notification is non-conformant (FR38).
        """
        # (a) Notify peers of departure. We send a None identity as the
        # sentinel that signals "this node is leaving." Implementations
        # wiring S7b should treat a None identity announcement as a
        # departure event.
        for peer in self._peers:
            try:
                self._notify(peer, None)  # type: ignore[arg-type]
            except Exception:
                # Best-effort departure notification; a peer that is
                # already down should not block our clean exit.
                pass

        # (b) Drain: wait DRAIN_TIMEOUT_SECONDS for in-flight messages.
        # This is a placeholder — actual drain coordination is handled
        # by the S7b transport layer. S7a registers the timeout contract.
        _drain_start = time.monotonic()
        while time.monotonic() - _drain_start < DRAIN_TIMEOUT_SECONDS:
            # S7b transport may override this loop via the callback
            # mechanism; here we simply honor the timeout floor.
            break

        self._active_in_cluster = False  # (c) FR38
        self._peers = []
        self._persist()

    def rotate_keypair(self) -> NodeIdentity:
        """
        Generate a new keypair and publish it to all registered cluster
        peers BEFORE treating the new key as active (FR39).

        Steps:
          (a) Generate a fresh keypair.
          (b) Publish the new NodeIdentity to all peers via S7b transport.
          (c) Update local persistent state atomically.

        The old key remains verifiable for KEY_GRACE_PERIOD_SECONDS to
        validate in-flight messages signed before the rotation.

        INV-S7a-4: Silent key rotation (without peer notification) is
        non-conformant.
        INV-S7a-5: This method MUST NOT be called by S6a self-modification
        protocols. Key rotation is an explicit lifecycle operation.
        """
        new_pub, new_priv = generate_keypair()
        new_identity = NodeIdentity(node_id=self._node_id, public_key=new_pub)

        # (b) Publish new identity to all peers BEFORE activating (FR39,
        # INV-S7a-4). Peers update their routing tables to trust the new
        # key for future messages.
        for peer in self._peers:
            self._notify(peer, new_identity)

        # (c) Activate new key only after all notifications are sent.
        self._public_key_bytes = new_pub
        self._private_key_bytes = new_priv
        self._persist()

        return new_identity

    # ------------------------------------------------------------------
    # Internal state management
    # ------------------------------------------------------------------

    def _persist(self) -> None:
        """
        Write the node's current state to disk (INV-S7a-6).

        WARNING: private_key_bytes are written to disk. The state file
        MUST be protected by filesystem permissions (mode 0600).
        The private key is NEVER logged or transmitted.
        """
        state = {
            "node_id": self._node_id,
            "public_key": self._public_key_bytes.hex(),
            "private_key": self._private_key_bytes.hex(),  # INV-S7a-3: local only
            "address": self._address,
            "peers": [
                {"node_id": p.node_id, "address": p.address}
                for p in self._peers
            ],
        }
        _save_state(self._state_path, state)
        # Restrict permissions to owner-read-write only.
        os.chmod(self._state_path, 0o600)

    @property
    def is_active(self) -> bool:
        """True if the node has successfully joined the cluster."""
        return self._active_in_cluster
