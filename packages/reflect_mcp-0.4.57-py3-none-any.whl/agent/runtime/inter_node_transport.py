# @scry.entry
# id: code.inter-node-transport~56216847
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:transport", "transport",
#        "topic:cluster", "cluster", "topic:S7b", "S7b", "kind:code", "code",
#        "substrate-evolution", "NodeMessage", "MessageEnvelope",
#        "TransportBackend", "LoopbackBackend", "DropletBackend",
#        "VoteMessage", "HeartbeatMessage", "ObservationMessage",
#        "BranchMessage", "at-least-once", "exactly-once", "delivery-semantics"]
# summary: >
#   S7b implementation — inter-node-transport Python module. Implements
#   MessageEnvelope (FR40), envelope signature verification (FR41),
#   VoteMessage / HeartbeatMessage / ObservationMessage / BranchMessage
#   message types, TransportBackend abstract class (FR45), LoopbackBackend
#   (N processes on one host via thread-safe queue, FR45), and DropletBackend
#   (stub — Stage 2, DigitalOcean infra required, FR60-FR62). Delivery
#   semantics enforced: HeartbeatMessage at-least-once (FR42), VoteMessage
#   exactly-once per term with no transparent retry (FR43, INV-S7b-4),
#   ObservationMessage / BranchMessage at-least-once (FR44). Envelope
#   integrity via Ed25519 signature (INV-S7b-1). Wire format per FR57:
#   JSON/HTTP/1.1 for DropletBackend; LoopbackBackend uses in-process queues
#   (bypasses wire format for dev/test). Two-tier transport (FR58, FR59):
#   consensus tier (VoteMessage, HeartbeatMessage) sync HTTP POST; deliberative
#   tier (ObservationMessage, BranchMessage) async inbox write to node-{node_id}
#   tracks — applies to DropletBackend (Stage 2). Also: inter-node-transport,
#   MessageEnvelope, TransportBackend, LoopbackBackend, DropletBackend, send,
#   receive, Ack, TransportError, S7b, substrate-evolution,
#   inter_node_transport.py, FR40, FR41, FR42, FR43, FR44, FR45, FR57, FR58,
#   FR59, FR60, FR61, FR62, JSON HTTP wire format, two-tier transport,
#   consensus tier, deliberative tier, REFLECT_TRANSPORT_PORT, VPC private IP.
# rationale: >
#   Without this, S5a/S5b/S5c/S6b all imply a transport layer that is
#   never defined. Delivery-semantic violations (silently discarded
#   heartbeats, duplicate votes) would be invisible until consensus breaks.
#   The LoopbackBackend enables multi-node testing on a single host without
#   DigitalOcean infra.
# applies: >
#   implementing cluster protocols (S5a quorum, S5b behavioral observation,
#   S5c heartbeat health, S6b branch exchange), adding a new message type
#   to the cluster, auditing vote deduplication, reviewing signature
#   verification for envelope integrity, choosing a transport backend for
#   local vs. real-cluster tests
# seeded_questions:
#   - "How are inter-node messages delivered?"
#   - "What delivery guarantee does VoteMessage have?"
#   - "How are heartbeats guaranteed not-silently-discarded?"
#   - "What is TransportBackend?"
#   - "How does LoopbackBackend work?"
#   - "How is the MessageEnvelope signed?"
#   - "inter_node_transport.py S7b substrate-evolution"
#   - "VoteMessage exactly-once FR43"
#   - "HeartbeatMessage at-least-once FR42"
#   - "envelope signature verification FR41"
#   - "inter_node_transport FR57 wire format JSON HTTP"
#   - "two-tier transport consensus deliberative S7b"
#   - "FR58 FR59 FR60 FR61 FR62 inter-node-transport"
# @scry.entry.end

"""
S7b — Inter-Node Transport (spec.inter-node-transport~4fa38738)

Defines the message exchange layer between cluster nodes: message
types, delivery semantics, envelope format + signing, and the
abstract TransportBackend with two concrete implementations.

Wire format (FR57): JSON/HTTP/1.1 for the DropletBackend (Stage 2).
The LoopbackBackend uses in-process Python queues, bypassing the
wire format for dev/test purposes — the TransportBackend abstraction
(INV-S7b-5) ensures no consumer code changes when switching backends.

Two-tier transport (FR58, FR59 — DropletBackend / Stage 2):
  - Consensus tier (VoteMessage, HeartbeatMessage): synchronous
    HTTP POST to the peer's REFLECT_TRANSPORT_PORT (default 9400)
    endpoint; in-band Ack on success.
  - Deliberative tier (ObservationMessage, BranchMessage): async
    inbox write to tracks/node-{node_id}/inbox/ on the peer host.

Algorithm: Ed25519 signatures (via node_runtime.sign_bytes).

Requirements satisfied:
- FR40: MessageEnvelope with all required fields; rejected if
        incomplete.
- FR41: Inbound envelopes verified against from_node.public_key.
- FR42: HeartbeatMessage at-least-once (timeout surfaces as error).
- FR43: VoteMessage exactly-once per (message_id, term); no retry.
- FR44: ObservationMessage, BranchMessage at-least-once.
- FR45: TransportBackend abstract; LoopbackBackend + DropletBackend.
- FR57: Wire format JSON/HTTP/1.1 (DropletBackend, Stage 2).
- FR58: Consensus tier sync HTTP POST (DropletBackend, Stage 2).
- FR59: Deliberative tier async inbox write (DropletBackend, Stage 2).
- FR60-FR62: VPC private IP, REFLECT_TRANSPORT_PORT=9400, peer mesh
             (DropletBackend stub — Stage 2, DO infra required).
- INV-S7b-1: No consumer sees an unverified envelope.
- INV-S7b-2: message_id globally unique per envelope.
- INV-S7b-3: VoteMessage term field always present.
- INV-S7b-4: No transparent retry on VoteMessage timeout.
- INV-S7b-5: Consumer code references only TransportBackend.
"""

from __future__ import annotations

import hashlib
import queue
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, Union

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
    load_der_public_key,
)
from cryptography.exceptions import InvalidSignature

from agent.runtime.node_runtime import NodeEndpoint, NodeIdentity, sign_bytes

# ---------------------------------------------------------------------------
# Deployment parameters
# ---------------------------------------------------------------------------

# Maximum time (seconds) to wait for an Ack on a send call.
SEND_TIMEOUT_SECONDS: float = 5.0

# ---------------------------------------------------------------------------
# Message types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class VoteMessage:
    """
    A consensus vote, exactly-once per (message_id, term) (FR43).

    term MUST be present (INV-S7b-3). The transport does NOT retry
    on timeout (INV-S7b-4).
    """

    proposal_id: str           # what is being voted on
    vote: str                  # "ACCEPT" | "REJECT"
    term: int                  # consensus term this vote belongs to


@dataclass(frozen=True)
class HeartbeatMessage:
    """
    A liveness heartbeat, at-least-once delivery (FR42).

    Duplicate delivery is acceptable; consumers must be idempotent
    on sequence numbers.
    """

    sequence: int   # monotonically increasing per sender
    timestamp: int  # unix timestamp (ms)


@dataclass(frozen=True)
class ObservationMessage:
    """
    A peer observation result, at-least-once delivery (FR44).

    target_node: node_id of the observed peer.
    result: dict representation of ObservationResult from S5b.
    observed_at: unix timestamp (ms).

    Duplicate delivery acceptable; consumers must be idempotent on
    (target_node, observed_at).
    """

    target_node: str   # node_id of the observed node
    result: dict       # ObservationResult from S5b (opaque at this layer)
    observed_at: int   # unix timestamp (ms)


@dataclass(frozen=True)
class BranchMessage:
    """
    A published self-modification branch notification, at-least-once (FR44).

    Duplicate delivery acceptable; consumers must be idempotent on
    branch_ref.
    """

    branch_ref: str    # git ref of the published branch
    fitness: float     # fitness score from S6c
    published_at: int  # unix timestamp (ms)


# Sum type: all message payloads.
NodeMessage = Union[VoteMessage, HeartbeatMessage, ObservationMessage, BranchMessage]


# ---------------------------------------------------------------------------
# Transport error / ack
# ---------------------------------------------------------------------------


class TransportErrorKind(Enum):
    TIMEOUT = auto()
    UNREACHABLE = auto()
    REJECTED = auto()


@dataclass(frozen=True)
class TransportError:
    kind: TransportErrorKind
    message_id: str
    reason: Optional[str] = None


@dataclass(frozen=True)
class Ack:
    message_id: str
    delivered_at: int  # unix timestamp (ms)


SendResult = Union[Ack, TransportError]


# ---------------------------------------------------------------------------
# Message envelope
# ---------------------------------------------------------------------------


def _payload_fingerprint(payload: NodeMessage) -> bytes:
    """
    Produce a stable fingerprint of the payload for signing.

    Uses a deterministic string representation hashed with SHA-256.
    A real implementation would use a canonical serialization.
    """
    return hashlib.sha256(repr(payload).encode()).digest()


def build_envelope(
    from_node: NodeIdentity,
    to_node: NodeEndpoint,
    payload: NodeMessage,
    private_key_bytes: bytes,
    term: Optional[int] = None,
) -> "MessageEnvelope":
    """
    Construct a signed MessageEnvelope (FR40).

    The signature covers: message_id + sent_at + term + payload_fingerprint.
    INV-S7b-2: a fresh UUID is generated per call.
    """
    message_id = str(uuid.uuid4())
    sent_at = int(time.time() * 1000)

    # VoteMessage MUST carry a term (INV-S7b-3).
    if isinstance(payload, VoteMessage):
        if term is None:
            term = payload.term

    # Build the signing material.
    sign_material = (
        message_id.encode()
        + str(sent_at).encode()
        + str(term).encode()
        + _payload_fingerprint(payload)
    )
    signature = sign_bytes(private_key_bytes, sign_material)

    return MessageEnvelope(
        from_node=from_node,
        to_node=to_node,
        message_id=message_id,
        sent_at=sent_at,
        term=term,
        payload=payload,
        signature=signature,
    )


def _verify_envelope_signature(envelope: "MessageEnvelope") -> bool:
    """
    Verify the envelope's signature against from_node.public_key (FR41).

    Returns True if valid; False if the signature does not verify.
    """
    sign_material = (
        envelope.message_id.encode()
        + str(envelope.sent_at).encode()
        + str(envelope.term).encode()
        + _payload_fingerprint(envelope.payload)
    )
    try:
        pub_key: Ed25519PublicKey = load_der_public_key(envelope.from_node.public_key)  # type: ignore[assignment]
        pub_key.verify(envelope.signature, sign_material)
        return True
    except (InvalidSignature, Exception):
        return False


@dataclass
class MessageEnvelope:
    """
    The transport envelope wrapping every NodeMessage (FR40).

    All fields MUST be present; an envelope with any missing required
    field MUST be rejected before transmission.
    """

    from_node: NodeIdentity    # sender identity (for S2a / FR41 verification)
    to_node: NodeEndpoint      # recipient address
    message_id: str            # globally unique (INV-S7b-2)
    sent_at: int               # unix timestamp (ms)
    term: Optional[int]        # consensus term (required for VoteMessage)
    payload: NodeMessage       # the actual message
    signature: bytes           # Ed25519 over (message_id + sent_at + term + payload_fp)

    def validate(self) -> Optional[str]:
        """
        Check that all required fields are present and VoteMessage
        has a non-null term (INV-S7b-3).

        Returns None if valid; an error string if not.
        """
        if not self.message_id:
            return "missing message_id"
        if not self.signature:
            return "missing signature"
        if isinstance(self.payload, VoteMessage) and self.term is None:
            return "VoteMessage requires a non-null term (INV-S7b-3)"
        return None


# ---------------------------------------------------------------------------
# TransportBackend (abstract)
# ---------------------------------------------------------------------------


class TransportBackend(ABC):
    """
    Abstract transport interface (FR45).

    Consumer code (S5a, S5b, S5c, S6b) MUST depend only on this
    abstract class — not on any backend-specific type (INV-S7b-5).
    """

    @abstractmethod
    def send(self, to: NodeEndpoint, msg: MessageEnvelope) -> SendResult:
        """
        Send a MessageEnvelope to the given endpoint.

        Returns Ack on successful delivery or TransportError on failure.

        VoteMessage: MUST NOT be transparently retried (INV-S7b-4).
        HeartbeatMessage / ObservationMessage / BranchMessage: timeout
        MUST surface as TransportError(TIMEOUT).
        """
        ...

    @abstractmethod
    def receive(self) -> MessageEnvelope:
        """
        Block until a verified MessageEnvelope is available for this node.

        INV-S7b-1: Only envelopes that pass signature verification are
        returned. All others are silently discarded (REJECTED is logged
        by the backend).
        """
        ...

    @abstractmethod
    def connect(self, peers: list[NodeEndpoint]) -> None:
        """Register peer endpoints with the backend."""
        ...

    @abstractmethod
    def disconnect(self) -> None:
        """Clean disconnect from all peers."""
        ...


# ---------------------------------------------------------------------------
# LoopbackBackend — N processes on one host, via in-process queues
# ---------------------------------------------------------------------------

# Global registry: node_id → queue, populated by LoopbackBackend.register().
_LOOPBACK_REGISTRY: dict[str, "queue.Queue[MessageEnvelope]"] = {}
# Deduplication store: (message_id, term) → delivered_at
_VOTE_DEDUP: dict[tuple[str, int], int] = {}
_DEDUP_LOCK = __import__("threading").Lock()


class LoopbackBackend(TransportBackend):
    """
    In-process loopback transport for dev / test (FR45).

    Each LoopbackBackend instance represents one node's transport
    endpoint. Envelopes are passed via thread-safe queues.

    Usage:
      backend_a = LoopbackBackend.register(node_a_identity)
      backend_b = LoopbackBackend.register(node_b_identity)
      backend_a.connect([node_b_endpoint])
      backend_b.connect([node_a_endpoint])
      result = backend_a.send(node_b_endpoint, envelope)
      received = backend_b.receive()
    """

    def __init__(self, own_identity: NodeIdentity) -> None:
        self._own_identity = own_identity
        self._inbox: queue.Queue[MessageEnvelope] = queue.Queue()
        _LOOPBACK_REGISTRY[own_identity.node_id] = self._inbox

    @classmethod
    def register(cls, own_identity: NodeIdentity) -> "LoopbackBackend":
        """Create and register a LoopbackBackend for a node."""
        return cls(own_identity)

    def send(self, to: NodeEndpoint, msg: MessageEnvelope) -> SendResult:
        """
        Deliver an envelope to the recipient's in-process queue.

        FR42/FR44: HeartbeatMessage, ObservationMessage, BranchMessage —
        at-least-once; timeout surfaces as TransportError.
        FR43: VoteMessage — exactly-once per (message_id, term);
        no transparent retry.

        FR40: Envelope is validated before transmission.
        """
        # Validate envelope before sending.
        err = msg.validate()
        if err:
            return TransportError(
                kind=TransportErrorKind.REJECTED,
                message_id=msg.message_id or "<missing>",
                reason=f"envelope validation failed: {err}",
            )

        # VoteMessage: check deduplication (FR43).
        if isinstance(msg.payload, VoteMessage):
            dedup_key = (msg.message_id, msg.payload.term)
            with _DEDUP_LOCK:
                if dedup_key in _VOTE_DEDUP:
                    # Already delivered; do NOT re-deliver (FR43).
                    return Ack(
                        message_id=msg.message_id,
                        delivered_at=_VOTE_DEDUP[dedup_key],
                    )

        target_queue = _LOOPBACK_REGISTRY.get(to.node_id)
        if target_queue is None:
            return TransportError(
                kind=TransportErrorKind.UNREACHABLE,
                message_id=msg.message_id,
                reason=f"no loopback endpoint registered for {to.node_id}",
            )

        delivered_at = int(time.time() * 1000)
        target_queue.put(msg)

        # Record dedup entry for VoteMessage.
        if isinstance(msg.payload, VoteMessage):
            dedup_key = (msg.message_id, msg.payload.term)
            with _DEDUP_LOCK:
                _VOTE_DEDUP[dedup_key] = delivered_at

        return Ack(message_id=msg.message_id, delivered_at=delivered_at)

    def receive(self) -> MessageEnvelope:
        """
        Block until a signature-verified envelope is available (INV-S7b-1).

        Envelopes that fail verification are discarded; this call loops
        until a valid envelope is found.
        """
        while True:
            envelope = self._inbox.get(timeout=SEND_TIMEOUT_SECONDS)
            if _verify_envelope_signature(envelope):
                return envelope
            # INV-S7b-1: discard unverified envelopes; log rejection.
            _log_rejected(envelope)

    def connect(self, peers: list[NodeEndpoint]) -> None:
        """Register peer endpoints (no-op for loopback — registry is global)."""
        pass  # All nodes share the global _LOOPBACK_REGISTRY.

    def disconnect(self) -> None:
        """Deregister this node from the loopback registry."""
        _LOOPBACK_REGISTRY.pop(self._own_identity.node_id, None)


def _log_rejected(envelope: MessageEnvelope) -> None:
    """Log an envelope that failed signature verification (INV-S7b-1)."""
    import sys
    print(
        f"[inter_node_transport] REJECTED envelope {envelope.message_id} "
        f"from {envelope.from_node.node_id}: signature verification failed",
        file=sys.stderr,
    )


# ---------------------------------------------------------------------------
# DropletBackend — N DigitalOcean droplets (stub)
# ---------------------------------------------------------------------------


class DropletBackend(TransportBackend):
    """
    DigitalOcean droplet transport for real fault-independent clusters
    (FR45, FR60-FR62). Stage 2 — blocked on Stage 1 loopback integration
    tests passing.

    Wire format (FR57): JSON/HTTP/1.1. Two-tier transport (FR58, FR59):
      - Consensus tier (VoteMessage, HeartbeatMessage): synchronous
        HTTP POST to http://{vpc_ip}:{REFLECT_TRANSPORT_PORT}/transport.
        REFLECT_TRANSPORT_PORT defaults to 9400 (FR61).
      - Deliberative tier (ObservationMessage, BranchMessage): async
        inbox write to tracks/node-{node_id}/inbox/ on the peer.

    Network (FR60, FR62): VPC private IP (10.x.x.x range, DigitalOcean
    private network). Peer-to-peer mesh — harness is NOT a quorum node
    and does NOT participate in the mesh (AR9).

    A complete Stage 2 implementation requires:
      - DigitalOcean droplets provisioned with SSH keys by S7c.
      - HTTP server listening on REFLECT_TRANSPORT_PORT per node.
      - Inbox write API per node for deliberative-tier messages.
      - Signature verification (INV-S7b-1) unchanged from LoopbackBackend.

    INV-S7b-5: Consumer code (S5a, S5b, S5c, S6b) references only
    TransportBackend — switching from loopback to droplet requires
    no changes in consumer code.
    """

    def __init__(self, own_identity: NodeIdentity) -> None:
        self._own_identity = own_identity
        self._peers: list[NodeEndpoint] = []

    def send(self, to: NodeEndpoint, msg: MessageEnvelope) -> SendResult:
        raise NotImplementedError(
            "DropletBackend.send requires live DigitalOcean droplet infrastructure. "
            "Use LoopbackBackend for local development and testing."
        )

    def receive(self) -> MessageEnvelope:
        raise NotImplementedError(
            "DropletBackend.receive requires live DigitalOcean droplet infrastructure."
        )

    def connect(self, peers: list[NodeEndpoint]) -> None:
        # FR45: Record peers; actual SSH-tunneled connections established here
        # in a real implementation.
        self._peers = list(peers)

    def disconnect(self) -> None:
        self._peers = []
