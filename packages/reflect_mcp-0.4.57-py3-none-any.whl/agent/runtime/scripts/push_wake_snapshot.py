#!/usr/bin/env python3
"""Push wake.md snapshot to the terminal portal via wrangler D1.

Reads reflection's root wake.md and writes it to the chat_persona table in
theterminal-chat-db (D1) using `wrangler d1 execute --remote`. The Worker reads
this field and prepends it to the system prompt (5-min TTL cache).

Can be run standalone:
    python agent/runtime/scripts/push_wake_snapshot.py

Or imported and called programmatically (from wake.py finally block):
    from agent.runtime.scripts.push_wake_snapshot import push
    push()

Called for main track only — wake.md is reflection's shared identity file.

No API secrets required — wrangler authenticates via CLOUDFLARE_API_TOKEN or
~/.wrangler/config.toml (already set in the environment).
"""
import os
import subprocess
import sys
from pathlib import Path


def _resolve_project_root() -> Path:
    """Walk up from __file__ until wake.md is found, or use CLAUDE_PROJECT_DIR."""
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        p = Path(env)
        if (p / "wake.md").exists():
            return p

    # __file__ = agent/runtime/scripts/push_wake_snapshot.py
    # → scripts/ → runtime/ → agent/ → project_root/
    candidate = Path(__file__).resolve().parent.parent.parent.parent
    if (candidate / "wake.md").exists():
        return candidate

    # Fallback: walk up from CWD
    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / "wake.md").exists():
            return parent

    return candidate  # best guess


PROJECT_ROOT = _resolve_project_root()
WAKE_MD_PATH = PROJECT_ROOT / "wake.md"
D1_DB = "theterminal-chat-db"


def push() -> bool:
    """Read wake.md and write it to the portal's D1 chat_persona table.

    Uses `wrangler d1 execute --remote` — no HTTP admin endpoint or secret needed.
    Returns True on success, False on any error (non-fatal caller contract).
    All failures are logged to stderr only — never raises.
    """
    # Read wake.md
    try:
        wake_md = WAKE_MD_PATH.read_text()
    except Exception as e:
        print(f"[push-wake-snapshot] could not read wake.md ({WAKE_MD_PATH}): {e}", file=sys.stderr)
        return False

    # Escape single quotes for SQL (double them: ' → '')
    escaped = wake_md.replace("'", "''")

    sql = (
        f"UPDATE chat_persona SET wake_md_snapshot='{escaped}', "
        f"updated_at=CURRENT_TIMESTAMP WHERE id=1"
    )

    cmd = [
        "wrangler", "d1", "execute", D1_DB,
        "--remote",
        "--command", sql,
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode == 0:
            print(
                f"[push-wake-snapshot] ✓ pushed wake.md → {D1_DB} via wrangler",
                file=sys.stderr,
            )
            return True
        else:
            stderr_snippet = (result.stderr or "")[:200]
            print(
                f"[push-wake-snapshot] wrangler exited {result.returncode}: {stderr_snippet}",
                file=sys.stderr,
            )
            return False
    except FileNotFoundError:
        print("[push-wake-snapshot] wrangler not found in PATH — skipping", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print("[push-wake-snapshot] wrangler timed out after 60s — skipping", file=sys.stderr)
        return False
    except Exception as e:
        print(f"[push-wake-snapshot] unexpected error: {e}", file=sys.stderr)
        return False


if __name__ == "__main__":
    ok = push()
    sys.exit(0 if ok else 1)
