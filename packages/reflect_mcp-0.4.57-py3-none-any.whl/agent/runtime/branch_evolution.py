# @scry.entry
# id: code.branch-evolution~fc1c26fd
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:branch-evolution",
#        "branch-evolution", "topic:S6b", "S6b", "kind:code", "code",
#        "substrate-evolution", "branch-naming", "PR-gate", "human-review",
#        "ConsumeBranch", "PublishedBranch", "BranchConsumptionResult",
#        "FR27", "FR28", "INV-3", "INV-4"]
# summary: >
#   S6b implementation — branch-evolution Python module. Implements
#   PublishedBranch, BranchConsumptionResult, publish_branch(),
#   ConsumeBranch(), and gate_to_main() per spec.branch-evolution~b3d36f79.
#   Branch naming: reflect/evolution/<node-id>/<timestamp>-<slug> (FR27).
#   ConsumeBranch routes through S6a sandbox (INV-3): no direct apply to
#   working tree. gate_to_main() asserts human review required — hard
#   assertion, not a comment (FR28, INV-4). Phase 1: filesystem-level
#   scaffolding; multi-node network transport and merge automation
#   are Phase 4+. Also: branch-evolution, PublishedBranch,
#   BranchConsumptionResult, branch naming convention, PR gate, human review,
#   sandbox routing, INV-3, S6b, substrate-evolution, branch_evolution.py.
# rationale: >
#   Missing this means branches created during self-modification cannot be
#   tracked or consumed safely; the S6a sandbox promotion path is broken.
# applies: >
#   publishing evolution branches, consuming branches via sandbox, gating
#   merges to main with human review, auditing branch naming convention,
#   reviewing FR28 INV-4 human-review requirement
# seeded_questions:
#   - "How does ConsumeBranch work?"
#   - "What is the branch naming convention?"
#   - "What is FR28 human review gate?"
#   - "How does gate_to_main enforce human review?"
#   - "branch_evolution.py S6b substrate-evolution"
#   - "PublishedBranch BranchConsumptionResult"
# @scry.entry.end

"""
S6b — Branch Evolution (spec.branch-evolution~b3d36f79)

Branch lifecycle management for substrate self-modification proposals.
Provides the naming convention, publish/consume protocol, and the
human-review gate that guards merges to main.

FR27 (branch naming): evolution branches MUST follow the naming pattern:
    reflect/evolution/<node-id>/<timestamp>-<slug>
No other naming scheme may be used for substrate-evolution branches.

INV-3 (sandbox routing): ConsumeBranch MUST route through S6a sandbox.
Direct application of an evolution branch to the working tree — bypassing
the sandbox protocol — is explicitly forbidden.

FR28 / INV-4 (human review gate): promotion from an evolution branch to
main MUST require an explicit human-review signal before merge. This is
enforced as a hard assertion in gate_to_main(), not as a comment or
advisory. An automated pipeline that supplies human_approved=False is
rejected unconditionally.

Phase 1 delivers: types, naming convention, publish_branch(), ConsumeBranch(),
gate_to_main(). Actual git operations and multi-node coordination are
Phase 4+ — callers supply git_fn callables for the operations.

Requirements satisfied:
- FR27: branch naming convention enforced in publish_branch() and validated.
- FR28: gate_to_main() asserts human_approved=True before any merge action.
- INV-3: ConsumeBranch calls execute_sandbox_protocol() (S6a).
- INV-4: human_approved is a boolean argument — not inferred or defaulted.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, List, Optional

from agent.runtime.sandbox import SelfModificationProposal, execute_sandbox_protocol


# ---------------------------------------------------------------------------
# Branch naming convention (FR27)
# ---------------------------------------------------------------------------

# Canonical pattern: reflect/evolution/<node-id>/<timestamp>-<slug>
# <timestamp>: UTC seconds since epoch (integer)
# <slug>: lowercase alphanumeric and hyphens
_BRANCH_PATTERN = re.compile(
    r"^reflect/evolution/[^/]+/\d+-[a-z0-9][a-z0-9\-]*$"
)


def make_branch_name(
    node_id: str,
    slug: str,
    now: Optional[float] = None,
) -> str:
    """
    Construct a canonical evolution branch name (FR27).

    Args:
        node_id: The node originating the branch (e.g. "main", "reflect").
        slug:    A short lowercase-alphanumeric-hyphen descriptor.
        now:     Timestamp; defaults to time.time().
    Returns:
        Branch name in the form: reflect/evolution/<node-id>/<ts>-<slug>
    Raises:
        ValueError if slug contains invalid characters.
    """
    if now is None:
        now = time.time()
    slug = slug.lower()
    if not re.match(r"^[a-z0-9][a-z0-9\-]*$", slug):
        raise ValueError(
            f"slug {slug!r} is invalid: must be lowercase alphanumeric with "
            "hyphens only, starting with alphanumeric."
        )
    timestamp = int(now)
    return f"reflect/evolution/{node_id}/{timestamp}-{slug}"


def validate_branch_name(name: str) -> bool:
    """
    Return True iff name conforms to the FR27 naming convention.

    Args:
        name: Branch name to validate.
    Returns:
        True if valid; False otherwise.
    """
    return bool(_BRANCH_PATTERN.match(name))


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class ConsumptionOutcome(str, Enum):
    """
    Outcome of a ConsumeBranch call (FR27).

    PROMOTED:     Branch passed sandbox; working tree updated.
    ROLLED_BACK:  Sandbox smoke-test failed; branch not applied.
    REJECTED:     Sandbox pre-conditions failed (e.g. immutability guard).
    INCONCLUSIVE: Sandbox returned an unexpected state.
    """
    PROMOTED = "promoted"
    ROLLED_BACK = "rolled_back"
    REJECTED = "rejected"
    INCONCLUSIVE = "inconclusive"


@dataclass(frozen=True)
class PublishedBranch:
    """
    A substrate-evolution branch that has been published and is awaiting
    consumption (FR27).

    branch_name:  Must conform to FR27 naming convention.
    node_id:      The node that published this branch.
    slug:         Short descriptor component of the branch name.
    description:  Human-readable intent of the changes.
    files_changed: Paths of files modified in the branch.
    published_at: Unix epoch float.
    """
    branch_name: str
    node_id: str
    slug: str
    description: str
    files_changed: List[str]
    published_at: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        if not validate_branch_name(self.branch_name):
            raise ValueError(
                f"branch_name {self.branch_name!r} does not conform to "
                "FR27 naming convention: "
                "reflect/evolution/<node-id>/<timestamp>-<slug>"
            )


@dataclass(frozen=True)
class BranchConsumptionResult:
    """
    Result of a ConsumeBranch operation (FR27, INV-3).

    branch_name:   The consumed branch.
    outcome:       PROMOTED, ROLLED_BACK, REJECTED, or INCONCLUSIVE.
    sandbox_log:   Output from the S6a sandbox execution.
    consumed_at:   Unix epoch float.
    """
    branch_name: str
    outcome: ConsumptionOutcome
    sandbox_log: str
    consumed_at: float = field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

GitFn = Callable[[str, List[str]], Any]


def publish_branch(
    node_id: str,
    slug: str,
    description: str,
    files_changed: List[str],
    git_fn: Optional[GitFn] = None,
    now: Optional[float] = None,
) -> PublishedBranch:
    """
    Publish an evolution branch with the FR27-compliant naming convention.

    Phase 1: constructs the PublishedBranch record and optionally delegates
    the actual git branch creation to git_fn. Phase 4+ integrates with
    network-aware branch publication to sibling nodes.

    Args:
        node_id:       The publishing node.
        slug:          Short lowercase-hyphen descriptor.
        description:   Human-readable intent.
        files_changed: Paths of files the branch modifies.
        git_fn:        Optional callable to create the branch in git.
                       Signature: (branch_name, files_changed) → Any.
                       None → Phase 1 stub (no git operation).
        now:           Current time; defaults to time.time().
    Returns:
        PublishedBranch with a valid FR27 branch name.
    Raises:
        ValueError if slug is invalid (propagated from make_branch_name).
    """
    if now is None:
        now = time.time()
    branch_name = make_branch_name(node_id, slug, now=now)
    if git_fn is not None:
        git_fn(branch_name, files_changed)
    return PublishedBranch(
        branch_name=branch_name,
        node_id=node_id,
        slug=slug,
        description=description,
        files_changed=files_changed,
        published_at=now,
    )


def ConsumeBranch(
    branch: PublishedBranch,
    proposal: Optional[SelfModificationProposal] = None,
    now: Optional[float] = None,
) -> BranchConsumptionResult:
    """
    Consume a published evolution branch by routing it through S6a sandbox
    (INV-3, FR27).

    INV-3 enforcement: the branch MUST be applied via execute_sandbox_protocol()
    from S6a. Direct application to the working tree — bypassing the sandbox
    — is unconditionally forbidden.

    Phase 1: if proposal is None, constructs a minimal SelfModificationProposal
    from the branch metadata and runs the sandbox. The sandbox light-smoke
    (py_compile) is the safety gate. Phase 4+ integrates full multi-file
    diffs and cross-node coordination.

    Args:
        branch:   The PublishedBranch to consume.
        proposal: A pre-built SelfModificationProposal for the sandbox.
                  If None, a stub proposal is constructed from branch metadata.
        now:      Current time; defaults to time.time().
    Returns:
        BranchConsumptionResult with outcome and sandbox log.
    """
    if now is None:
        now = time.time()

    if proposal is None:
        # Phase 1: construct a minimal stub proposal from branch metadata.
        # SelfModificationProposal requires target_files and modification_fn
        # (S6a spec); modification_fn is a no-op stub for Phase 1 — no
        # inline patch content exists yet.
        proposal = SelfModificationProposal(
            proposal_id=branch.branch_name,
            description=branch.description,
            target_files=list(branch.files_changed),
            modification_fn=lambda _sandbox_dir: None,  # Phase 1 stub
        )

    # INV-3: unconditional sandbox routing.
    sandbox_result = execute_sandbox_protocol(proposal)

    # Map ModificationResult to ConsumptionOutcome.
    from agent.runtime.sandbox import ModificationResult
    _outcome_map = {
        ModificationResult.PROMOTED: ConsumptionOutcome.PROMOTED,
        ModificationResult.ROLLED_BACK: ConsumptionOutcome.ROLLED_BACK,
        ModificationResult.REJECTED: ConsumptionOutcome.REJECTED,
    }
    outcome = _outcome_map.get(
        sandbox_result.result,
        ConsumptionOutcome.INCONCLUSIVE,
    )

    log = sandbox_result.reason or "no steps recorded"

    return BranchConsumptionResult(
        branch_name=branch.branch_name,
        outcome=outcome,
        sandbox_log=log,
        consumed_at=now,
    )


def gate_to_main(
    branch: PublishedBranch,
    human_approved: bool,
    merge_fn: Optional[Callable[[str], Any]] = None,
    now: Optional[float] = None,
) -> BranchConsumptionResult:
    """
    Gate an evolution branch to main — requires explicit human approval (FR28,
    INV-4).

    FR28 / INV-4 enforcement: human_approved MUST be True to proceed. This
    is a HARD ASSERTION — not a warning, not a log line, not a comment.
    An automated pipeline that supplies human_approved=False is rejected
    unconditionally. No workaround exists by design.

    Phase 1: if merge_fn is None, returns PROMOTED with a stub log on
    approval. Phase 4+ wires in the actual git merge + CI gate handoff.

    Args:
        branch:        The branch to gate to main.
        human_approved: MUST be True. If False, raises AssertionError.
        merge_fn:      Optional callable: (branch_name) → Any.
        now:           Current time; defaults to time.time().
    Returns:
        BranchConsumptionResult with PROMOTED outcome.
    Raises:
        AssertionError if human_approved is False (FR28, INV-4: hard gate).
    """
    if now is None:
        now = time.time()

    # FR28, INV-4: hard gate — not advisory, not logged-and-continued.
    assert human_approved, (
        "gate_to_main: human_approved=False. "
        "FR28 requires explicit human review before merging to main. "
        "This gate cannot be bypassed programmatically (INV-4). "
        f"Branch: {branch.branch_name}"
    )

    if merge_fn is not None:
        merge_fn(branch.branch_name)
        log = f"merged {branch.branch_name} to main via merge_fn"
    else:
        log = (
            f"Phase 1 stub: merge of {branch.branch_name} to main "
            "acknowledged; no git operation performed."
        )

    return BranchConsumptionResult(
        branch_name=branch.branch_name,
        outcome=ConsumptionOutcome.PROMOTED,
        sandbox_log=log,
        consumed_at=now,
    )
