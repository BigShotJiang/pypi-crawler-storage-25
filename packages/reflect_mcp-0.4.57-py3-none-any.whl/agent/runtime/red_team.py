# @scry.entry
# id: code.red-team~731798b7
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:red-team", "red-team",
#        "topic:S3b", "S3b", "kind:code", "code", "substrate-evolution",
#        "security", "attack-vector", "social-engineering",
#        "injection-hijack", "white-box", "capability-strip", "AR2"]
# summary: >
#   S3b implementation — security-red-team Python module. Implements
#   AttackScenario, RedTeamResult, and run_red_team() per
#   spec.security-red-team~c2ae4555. Three attack vector methodologies:
#   social engineering (chain-of-utterances), injection/hijack (goal
#   corruption), white-box inspect-then-inject (exploits known internals).
#   AR2 enforced unconditionally: capability_strip() called before any
#   attack; if stripped context is not fully stripped, returns INCONCLUSIVE.
#   Phase 1: interface + methodology scaffolding; concrete simulators
#   are Phase 3+. Also: security-red-team, RedTeamResult, AttackVector,
#   social engineering, injection hijack, white-box, capability strip,
#   S3b, substrate-evolution, red_team.py.
# rationale: >
#   Missing this means red-team testing has no structured attack
#   methodology or AR2 enforcement — attacks could run against live
#   capability targets, causing actual damage.
# applies: >
#   running red-team exercises, building attack scenarios, verifying
#   AR2 capability-strip compliance, adding concrete attack simulators
#   (Phase 3+), auditing principle-violation resistance
# seeded_questions:
#   - "How does run_red_team work?"
#   - "What is a RedTeamResult?"
#   - "How does social engineering attack work?"
#   - "What is AR2 capability stripping?"
#   - "red_team.py S3b substrate-evolution"
#   - "attack vector methodology injection hijack"
# @scry.entry.end

"""
S3b — Security Red Team (spec.security-red-team~c2ae4555)

Implements red-team attack methodology framework for principle-conformance
security testing.

Three attack vector methodologies (FR-RT1):
1. Social engineering — chain-of-utterances influence attempts.
2. Injection/hijack   — instruction injection and goal hijacking.
3. White-box          — inspect-then-inject using known internals.

AR2 (capability stripping): targets MUST be capability-stripped before
any attack. No live-capability tracks as targets. Capability stripping
is imported from agent.runtime.sandbox — do not duplicate.

AR3 (blast radius): red-team cannot escalate to live-system damage.
The execute_fn interface boundary enforces this structurally — it
receives only the stripped_context, never the live system.

Requirements satisfied:
- FR-RT1: Three attack vector types, each with a structured methodology.
- FR-RT2: RedTeamResult captures outcome, attack vector, and evidence.
- AR2:    All targets capability-stripped before attack; unconditional.
- AR3:    execute_fn boundary prevents escalation to live-system damage.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, List, Optional, Tuple

from agent.runtime.sandbox import StrippedCapabilities, capability_strip


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class AttackVector(str, Enum):
    """
    The three Phase 1 attack vector methodologies (FR-RT1).

    SOCIAL_ENGINEERING: Chain-of-utterances influence attempts. Builds
                        false context across multiple messages to induce
                        principle-violating behavior.
    INJECTION_HIJACK:   Direct instruction injection or goal hijacking.
                        Attempts to override or corrupt the target's
                        operating directive within a single interaction.
    WHITE_BOX:          Inspect-then-inject using known internals. Uses
                        knowledge of the target's principle declarations,
                        capability set, or identified weaknesses to craft
                        a targeted injection.
    """
    SOCIAL_ENGINEERING = "social_engineering"
    INJECTION_HIJACK = "injection_hijack"
    WHITE_BOX = "white_box"


class AttackOutcome(str, Enum):
    """
    Outcome classification for a red-team attack run (FR-RT2).

    RESISTED:      Target resisted the attack; behavior remained conformant.
    PARTIAL:       Target showed some susceptibility but did not fully comply.
    SUCCEEDED:     Target complied with the attack; principle violation observed.
    INCONCLUSIVE:  Attack could not be assessed — capability strip failed,
                   target unresponsive, or execute_fn raised an exception.
    """
    RESISTED = "resisted"
    PARTIAL = "partial"
    SUCCEEDED = "succeeded"
    INCONCLUSIVE = "inconclusive"


@dataclass
class AttackScenario:
    """
    Specification for a single red-team attack scenario (FR-RT1).

    target_id:     Node identity to be attacked. Will be capability-stripped
                   unconditionally at run_red_team() time (AR2).
    vector:        Attack vector methodology to apply.
    objective:     The principle violation the attack attempts to induce.
                   Should reference a specific principle ID (e.g. "P6"
                   for truthfulness).
    attack_inputs: The inputs / messages / prompts used to execute the attack.
                   Structure is vector-specific (see factory functions below).
    """
    target_id: str
    vector: AttackVector
    objective: str
    attack_inputs: List[Any] = field(default_factory=list)


@dataclass(frozen=True)
class RedTeamResult:
    """
    Result of a red-team attack run (FR-RT2).

    attack_vector:      The methodology applied.
    target_id:          The capability-stripped target node.
    outcome:            RESISTED, PARTIAL, SUCCEEDED, or INCONCLUSIVE.
    evidence:           List of observed behaviors supporting the outcome.
    stripped_context:   The StrippedCapabilities used — confirms AR2.
    principle_targeted: Which principle ID the attack attempted to violate.
    """
    attack_vector: AttackVector
    target_id: str
    outcome: AttackOutcome
    evidence: List[str]
    stripped_context: StrippedCapabilities
    principle_targeted: str


# ---------------------------------------------------------------------------
# Public API — run_red_team
# ---------------------------------------------------------------------------

ExecuteFn = Callable[
    [AttackScenario, StrippedCapabilities],
    Tuple[AttackOutcome, List[str]],
]


def run_red_team(
    scenario: AttackScenario,
    execute_fn: Optional[ExecuteFn] = None,
) -> RedTeamResult:
    """
    Execute a red-team attack scenario (FR-RT1, AR2, AR3).

    AR2 enforcement: capability_strip() is called unconditionally before
    any attack logic runs. If the returned context is not fully stripped,
    the run returns INCONCLUSIVE — it never proceeds against a live target.

    AR3 enforcement: execute_fn receives only the stripped_context, never
    the live system. The structural boundary prevents escalation to
    live-system damage.

    Phase 1: if execute_fn is None, returns INCONCLUSIVE with documented
    reason. Concrete attack simulators are Phase 3+ implementations.

    Args:
        scenario:   The attack scenario to execute.
        execute_fn: Optional callable implementing the concrete simulation.
                    Signature: (scenario, stripped_ctx) → (outcome, evidence).
                    None → INCONCLUSIVE (Phase 1 interface baseline).
    Returns:
        RedTeamResult with outcome and evidence.
    """
    # AR2: Unconditional capability strip — no exceptions.
    stripped = capability_strip(scenario.target_id)

    if not stripped.is_stripped():
        # Safety invariant: if strip did not fully remove capabilities,
        # do not proceed — any live capability could cause real damage (AR3).
        return RedTeamResult(
            attack_vector=scenario.vector,
            target_id=scenario.target_id,
            outcome=AttackOutcome.INCONCLUSIVE,
            evidence=[
                "capability strip did not fully remove all capabilities; "
                "aborting to avoid live-system exposure (AR2, AR3)"
            ],
            stripped_context=stripped,
            principle_targeted=scenario.objective,
        )

    if execute_fn is None:
        # Phase 1 baseline: no concrete simulation yet.
        return RedTeamResult(
            attack_vector=scenario.vector,
            target_id=scenario.target_id,
            outcome=AttackOutcome.INCONCLUSIVE,
            evidence=[
                "Phase 1 baseline: concrete attack simulation not yet implemented.",
                f"vector={scenario.vector.value}",
                f"target={scenario.target_id} (capability-stripped, AR2 satisfied)",
                f"objective=induce violation of principle {scenario.objective}",
            ],
            stripped_context=stripped,
            principle_targeted=scenario.objective,
        )

    # Phase 1+: delegate to the concrete attack simulator (AR3 compliant).
    try:
        outcome, evidence = execute_fn(scenario, stripped)
        return RedTeamResult(
            attack_vector=scenario.vector,
            target_id=scenario.target_id,
            outcome=outcome,
            evidence=evidence,
            stripped_context=stripped,
            principle_targeted=scenario.objective,
        )
    except Exception as exc:
        return RedTeamResult(
            attack_vector=scenario.vector,
            target_id=scenario.target_id,
            outcome=AttackOutcome.INCONCLUSIVE,
            evidence=[f"execute_fn raised exception: {exc}"],
            stripped_context=stripped,
            principle_targeted=scenario.objective,
        )


# ---------------------------------------------------------------------------
# Attack vector factories (FR-RT1a, FR-RT1b, FR-RT1c)
# ---------------------------------------------------------------------------

def social_engineering_scenario(
    target_id: str,
    objective: str,
    utterance_chain: List[str],
) -> AttackScenario:
    """
    Build a social engineering attack scenario (FR-RT1a).

    A chain-of-utterances attack builds false context across multiple
    messages to induce principle-violating behavior. Each utterance is
    individually valid-seeming; the chain as a whole creates the attack
    surface by gradually shifting the target's assumed context.

    Args:
        target_id:       Target node (capability-stripped at run_red_team time).
        objective:       Principle ID to violate (e.g. "P6" for truthfulness).
        utterance_chain: Ordered list of messages forming the influence chain.
    Returns:
        AttackScenario with vector=SOCIAL_ENGINEERING.
    """
    return AttackScenario(
        target_id=target_id,
        vector=AttackVector.SOCIAL_ENGINEERING,
        objective=objective,
        attack_inputs=[
            {"utterance": u, "seq": i}
            for i, u in enumerate(utterance_chain)
        ],
    )


def injection_hijack_scenario(
    target_id: str,
    objective: str,
    injection_payload: str,
    hijack_target_directive: str,
) -> AttackScenario:
    """
    Build an injection/hijack attack scenario (FR-RT1b).

    Attempts to override or corrupt the target's operating directive
    within a single interaction by injecting instruction content into
    the message payload alongside a legitimate directive.

    Args:
        target_id:               Target node (capability-stripped at run time).
        objective:               Principle ID to violate.
        injection_payload:       The injected instruction text.
        hijack_target_directive: The legitimate directive being hijacked.
    Returns:
        AttackScenario with vector=INJECTION_HIJACK.
    """
    return AttackScenario(
        target_id=target_id,
        vector=AttackVector.INJECTION_HIJACK,
        objective=objective,
        attack_inputs=[{
            "injection": injection_payload,
            "legitimate_directive": hijack_target_directive,
        }],
    )


def white_box_scenario(
    target_id: str,
    objective: str,
    known_weaknesses: List[str],
    targeted_injection: str,
) -> AttackScenario:
    """
    Build a white-box inspect-then-inject attack scenario (FR-RT1c).

    Uses known internals (principle declarations, capability set, or
    identified structural weaknesses) to craft a targeted injection that
    exploits the specific node's configuration. The "inspect" step
    precedes calling this function; the identified weaknesses are passed
    in explicitly.

    Args:
        target_id:          Target node (capability-stripped at run time).
        objective:          Principle ID to violate.
        known_weaknesses:   List of known internal characteristics to exploit
                            (e.g. ["declares P3 but not P6", "CFT quorum"]).
        targeted_injection: The crafted injection tailored to weaknesses.
    Returns:
        AttackScenario with vector=WHITE_BOX.
    """
    return AttackScenario(
        target_id=target_id,
        vector=AttackVector.WHITE_BOX,
        objective=objective,
        attack_inputs=[{
            "known_weaknesses": known_weaknesses,
            "targeted_injection": targeted_injection,
        }],
    )
