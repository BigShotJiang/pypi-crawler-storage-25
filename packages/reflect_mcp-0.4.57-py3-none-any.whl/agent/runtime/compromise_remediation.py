# <!-- @scry.entry
# id: code.compromise-remediation~84f9c133
# kind: internal
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:compromise-remediation",
#        "compromise-remediation", "topic:substrate-evolution",
#        "substrate-evolution", "S5d", "RemediationDecision",
#        "RemediationEngine", "VoteOption", "quorum-deliberation",
#        "wind-down", "replace", "AR1", "FR22", "kind:code"]
# summary: >
#   S5d implementation — compromise-remediation pipeline. Three-step
#   process: detection signal aggregation (CompromiseSignal + HeartbeatFault),
#   quorum deliberation with defendant exclusion, remediation action
#   (WIND_DOWN_AND_REPLACE / MONITOR_CONTINUE / EXONERATE). AR1 enforced:
#   no non-quorum wind-down path exists. Split vote defaults to
#   MONITOR_CONTINUE (INV-4). Replacement enters at SIBLING tier (INV-5).
#   Also: compromise-remediation, RemediationDecision, RemediationEngine,
#   VoteOption, WIND_DOWN_AND_REPLACE, MONITOR_CONTINUE, EXONERATE,
#   CompromiseSignal, HeartbeatFault, QuorumDecision, defendant-exclusion,
#   aggregation-window, grace-period, S5d, FR22, AR1.
# rationale: >
#   Without this, compromise detection signals have no remediation path and
#   the substrate cannot act on detected adversarial drift or heartbeat
#   failure. S5d closes the compromise response loop.
# applies: >
#   reviewing compromise remediation pipeline, checking AR1 quorum
#   enforcement, inspecting defendant exclusion logic, tracing
#   wind-down + replace sequence, S5d implementation status
# seeded_questions:
#   - "Is S5d compromise remediation implemented?"
#   - "How is defendant excluded from its own quorum?"
#   - "What happens on split vote in compromise deliberation?"
#   - "compromise-remediation quorum pipeline S5d"
#   - "WIND_DOWN_AND_REPLACE AR1 enforcement"
# @scry.entry.end -->
"""
S5d — compromise-remediation. Three-step pipeline:

  1. Detection signal aggregation (CompromiseSignal + HeartbeatFault).
     Multiple signals for the same target within AGGREGATION_WINDOW
     merge into one case (INV-3). A new signal for an active case is
     added as supplementary evidence, not a new case.

  2. Quorum deliberation via S5a (QuorumProtocol). The target MUST be
     notified before the vote closes (INV-2). Defendant's vote is
     excluded from the quorum (INV-6); quorum size is computed over
     n-1 non-defendant participants. Split vote (no majority) →
     MONITOR_CONTINUE (INV-4).

  3. Remediation action:
     - WIND_DOWN_AND_REPLACE: leader election first if target is current
       leader (C-4), then wind-down directive, then force-terminate
       after GRACE_PERIOD, then spawn replacement at SIBLING tier
       (INV-5; no inherited trust score, INV-5).
     - MONITOR_CONTINUE: heightened scrutiny flag, case archived.
     - EXONERATE: case closed; optionally submit CONFORMANT to S2d.

AR1: wind-down requires a valid QuorumDecision on every code path.
     No single-node unilateral override exists — not even for the
     originator node. A cluster too degraded to form quorum halts; it
     does not allow unilateral action.

RTM requirements: FR22, AR1. Global NFR1–7 apply.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple

from agent.runtime.behavioral_contract import ObservationResult
from agent.runtime.heartbeat_health import HeartbeatFault
from agent.runtime.quorum import (
    DecisionOutcome,
    QuorumDecision,
    QuorumProtocol,
    QuorumSize,
)
from agent.runtime.trust_score import CompromiseSignal, ConformanceResult

# ---------------------------------------------------------------------------
# Deployment parameters — MUST be explicit; document tradeoffs.
# ---------------------------------------------------------------------------

AGGREGATION_WINDOW: float = 300.0
"""
Seconds within which concurrent signals for the same target are merged
into one case rather than opening a new case (INV-3).

Tradeoff: wider window = fewer duplicate cases but slower independent
case opens for genuinely separate incidents. 0 = immediate case per
signal (maximum sensitivity, maximum case volume).
"""

RESPONSE_WINDOW: float = 60.0
"""
Seconds the target node has to respond after notification before the
quorum vote closes. Non-response within this window is treated as
non-responsive — not exoneration (INV-2).

Tradeoff: longer window gives a compromised node more time to respond
but increases decision latency. 0 = immediate vote close.
"""

GRACE_PERIOD: float = 30.0
"""
Seconds between sending a quorum-signed wind-down directive and
force-terminating the target if it does not shut down gracefully.

Tradeoff: longer grace = cleaner shutdown at the cost of extended
exposure window. 0 = immediate force-terminate.
"""

# ---------------------------------------------------------------------------
# Public enums and types
# ---------------------------------------------------------------------------


class VoteOption(str, Enum):
    """Three vote options in a compromise deliberation (FR22)."""
    WIND_DOWN_AND_REPLACE = "wind_down_and_replace"
    MONITOR_CONTINUE = "monitor_continue"
    EXONERATE = "exonerate"


class CaseStatus(str, Enum):
    """Lifecycle status of a RemediationCase."""
    OPEN = "open"
    DELIBERATING = "deliberating"
    CLOSED_WIND_DOWN = "closed_wind_down"
    CLOSED_MONITOR = "closed_monitor"
    CLOSED_EXONERATE = "closed_exonerate"


@dataclass
class RemediationCase:
    """
    Internal tracking record for one active or closed remediation case.

    case_id:          Unique UUID string for this deliberation.
    target_node_id:   Node under evaluation.
    opened_at:        Unix epoch float when the case was first opened.
    signals:          Accumulated CompromiseSignal triggers.
    heartbeat_faults: Accumulated HeartbeatFault triggers.
    observations:     Supplementary ObservationResult records.
    status:           Current lifecycle status.
    quorum_decision:  Set when deliberation completes.
    """
    case_id: str
    target_node_id: str
    opened_at: float
    signals: List[CompromiseSignal] = field(default_factory=list)
    heartbeat_faults: List[HeartbeatFault] = field(default_factory=list)
    observations: List[ObservationResult] = field(default_factory=list)
    status: CaseStatus = CaseStatus.OPEN
    quorum_decision: Optional[QuorumDecision] = None
    notified_at: Optional[float] = None
    vote_tally: Dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class RemediationDecision:
    """
    The output of a completed compromise deliberation (FR22, spec §Interface).

    case_id:          Unique identifier for this deliberation.
    target_node_id:   Node under evaluation.
    decision:         WIND_DOWN_AND_REPLACE | MONITOR_CONTINUE | EXONERATE.
    decided_at:       Unix epoch float when the quorum decision was reached.
    vote_tally:       Vote counts per option (audit log).
    evidence_summary: Structured summary of submitted signals.
    quorum_decision:  The QuorumDecision that authorized this remediation
                      (AR1: must be present for WIND_DOWN_AND_REPLACE).
    """
    case_id: str
    target_node_id: str
    decision: VoteOption
    decided_at: float
    vote_tally: Dict[str, int]
    evidence_summary: Dict
    quorum_decision: QuorumDecision


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_evidence_summary(case: RemediationCase) -> Dict:
    """Structured summary of accumulated evidence for audit log."""
    return {
        "compromise_signals": len(case.signals),
        "heartbeat_faults": len(case.heartbeat_faults),
        "observation_results": len(case.observations),
        "drift_summaries": [s.drift_summary for s in case.signals],
        "fault_classes": [f.fault_class.value for f in case.heartbeat_faults],
        "deviant_observations": sum(
            1 for o in case.observations
            if o.result == ConformanceResult.DEVIANT
        ),
    }


def _majority_vote(tally: Dict[str, int]) -> Optional[VoteOption]:
    """
    Return the VoteOption with a majority of votes, or None if no majority.

    A majority requires strictly more than half of total votes cast.
    """
    total = sum(tally.values())
    if total == 0:
        return None
    for option_str, count in tally.items():
        if count * 2 > total:
            return VoteOption(option_str)
    return None  # split vote — INV-4: caller defaults to MONITOR_CONTINUE


# ---------------------------------------------------------------------------
# Public API — RemediationEngine
# ---------------------------------------------------------------------------


class RemediationEngine:
    """
    Manages the compromise remediation pipeline (S5d).

    Usage (typical):
        engine = RemediationEngine(cluster_nodes={"a", "b", "c", "d"},
                                   fault_tolerance=1)
        engine.ingest_signal(signal)       # from S2d
        engine.ingest_fault(fault)         # from S5c
        decision = engine.deliberate("a")  # quorum votes, returns decision

    The engine is in-memory for Phase 1. Network transport (notification
    delivery, wind-down directive, spawn-replacement) is handled via
    injected callbacks — callers provide the real network layer.
    """

    def __init__(
        self,
        cluster_nodes: set,
        fault_tolerance: int = 1,
        aggregation_window: float = AGGREGATION_WINDOW,
        response_window: float = RESPONSE_WINDOW,
        grace_period: float = GRACE_PERIOD,
        notify_fn: Optional[Callable[[str, str], None]] = None,
        wind_down_fn: Optional[Callable[[str, QuorumDecision], None]] = None,
        force_terminate_fn: Optional[Callable[[str], None]] = None,
        spawn_replacement_fn: Optional[Callable[[str], None]] = None,
        trigger_election_fn: Optional[Callable[[str], None]] = None,
        observe_fn: Optional[Callable[[str, ConformanceResult], None]] = None,
        is_leader_fn: Optional[Callable[[str], bool]] = None,
    ) -> None:
        """
        Args:
            cluster_nodes:        Set of all node IDs in the cluster.
            fault_tolerance:      Byzantine fault tolerance f (passed to
                                  QuorumSize).
            aggregation_window:   Seconds for signal merging (INV-3).
            response_window:      Seconds for target notification (INV-2).
            grace_period:         Seconds before force-terminate.
            notify_fn:            Callable(target_id, message) — delivers
                                  notification to target. If None, notification
                                  is recorded but not delivered.
            wind_down_fn:         Callable(target_id, quorum_decision) —
                                  delivers quorum-signed wind-down directive
                                  (AR1: quorum_decision is always present).
            force_terminate_fn:   Callable(target_id) — force-terminates
                                  a node that did not shut down in grace period.
            spawn_replacement_fn: Callable(target_id) — spawns a replacement
                                  node at SIBLING tier (INV-5: no inherited
                                  trust score).
            trigger_election_fn:  Callable(target_id) — triggers S5a leader
                                  election when target is current leader (C-4).
            observe_fn:           Callable(target_id, ConformanceResult) —
                                  submits an observation to S2d on EXONERATE.
            is_leader_fn:         Callable(target_id) → bool — returns True
                                  if target is current cluster leader.
        """
        self._nodes = set(cluster_nodes)
        self._fault_tolerance = fault_tolerance
        self._aggregation_window = aggregation_window
        self._response_window = response_window
        self._grace_period = grace_period
        self._notify_fn = notify_fn
        self._wind_down_fn = wind_down_fn
        self._force_terminate_fn = force_terminate_fn
        self._spawn_replacement_fn = spawn_replacement_fn
        self._trigger_election_fn = trigger_election_fn
        self._observe_fn = observe_fn
        self._is_leader_fn = is_leader_fn

        # case_id → RemediationCase
        self._cases: Dict[str, RemediationCase] = {}
        # target_node_id → list of open case_ids
        self._open_by_target: Dict[str, List[str]] = {}

    # ------------------------------------------------------------------
    # Step 1 — Signal ingestion
    # ------------------------------------------------------------------

    def ingest_signal(
        self,
        signal: CompromiseSignal,
        observations: Optional[List[ObservationResult]] = None,
    ) -> RemediationCase:
        """
        Ingest a CompromiseSignal from S2d.

        If an open case for the target exists and was opened within
        AGGREGATION_WINDOW, adds signal as supplementary evidence (INV-3).
        Otherwise, opens a new case.

        Args:
            signal:       CompromiseSignal from S2d.
            observations: Optional ObservationResult records to attach.

        Returns:
            The RemediationCase that absorbed or was opened for this signal.
        """
        case = self._find_or_open_case(signal.node_id, signal.triggered_at)
        case.signals.append(signal)
        if observations:
            case.observations.extend(observations)
        return case

    def ingest_fault(
        self,
        fault: HeartbeatFault,
        observations: Optional[List[ObservationResult]] = None,
    ) -> RemediationCase:
        """
        Ingest a HeartbeatFault from S5c.

        Same aggregation semantics as ingest_signal: merges into an
        existing open case if one exists within AGGREGATION_WINDOW,
        otherwise opens a new case.

        Args:
            fault:        HeartbeatFault from S5c.
            observations: Optional ObservationResult records to attach.

        Returns:
            The RemediationCase that absorbed or was opened for this fault.
        """
        case = self._find_or_open_case(fault.node_id, fault.detected_at)
        case.heartbeat_faults.append(fault)
        if observations:
            case.observations.extend(observations)
        return case

    def add_observation(
        self, case_id: str, observation: ObservationResult
    ) -> None:
        """
        Add a supplementary ObservationResult to an existing case.

        Raises KeyError if case_id is unknown.
        """
        self._cases[case_id].observations.append(observation)

    # ------------------------------------------------------------------
    # Step 2 — Quorum deliberation
    # ------------------------------------------------------------------

    def deliberate(
        self,
        case_id: str,
        voter_votes: Optional[Dict[str, str]] = None,
        now: Optional[float] = None,
    ) -> RemediationDecision:
        """
        Run quorum deliberation for an open case (FR22, INV-2, INV-4,
        INV-6).

        The target is notified (INV-2) before votes are tallied.
        The target's own vote is excluded from the deliberating quorum
        (INV-6). Quorum size is computed over n-1 non-defendant
        participants. Split vote (no majority) defaults to
        MONITOR_CONTINUE (INV-4).

        For Phase 1 in-process voting: caller passes voter_votes mapping
        {node_id: VoteOption.value}. In Phase 4+, this is replaced by
        a HotStuff pipeline via S7b transport.

        Args:
            case_id:     ID of the case to deliberate.
            voter_votes: {node_id: VoteOption.value} — votes from
                         non-defendant participants. If None, all
                         non-defendant nodes default to MONITOR_CONTINUE.
            now:         Override for current time (testing).

        Returns:
            RemediationDecision authorised by a QuorumDecision.

        Raises:
            KeyError:   case_id is unknown.
            ValueError: Case is not in OPEN status.
        """
        ts = now or time.time()
        case = self._cases[case_id]
        if case.status != CaseStatus.OPEN:
            raise ValueError(
                f"Case {case_id} is not OPEN (status: {case.status}); "
                "cannot deliberate."
            )

        case.status = CaseStatus.DELIBERATING

        # INV-2: notify target before vote closes.
        notification = (
            f"Case {case_id}: you are the subject of a compromise "
            f"deliberation. Evidence: {len(case.signals)} CompromiseSignal(s), "
            f"{len(case.heartbeat_faults)} HeartbeatFault(s). "
            f"Response window: {self._response_window}s."
        )
        if self._notify_fn:
            self._notify_fn(case.target_node_id, notification)
        case.notified_at = ts

        # INV-6: exclude defendant from its own quorum.
        # Quorum size computed over n-1 non-defendant participants.
        non_defendant_nodes = self._nodes - {case.target_node_id}
        n_non_defendant = len(non_defendant_nodes)
        if n_non_defendant < 1:
            # Degenerate: no other nodes to form quorum — cannot deliberate.
            # Default to MONITOR_CONTINUE per INV-4 semantics.
            tally: Dict[str, int] = {
                VoteOption.MONITOR_CONTINUE.value: 0,
            }
            quorum_dec = QuorumDecision(
                outcome=DecisionOutcome.NO_QUORUM,
                topic=f"compromise:{case_id}",
                rationale=(
                    "No non-defendant nodes available to form quorum; "
                    "defaulting to MONITOR_CONTINUE."
                ),
                term=0,
                votes_for=frozenset(),
                votes_against=frozenset(),
            )
            verdict = VoteOption.MONITOR_CONTINUE
        else:
            # Tally votes from non-defendant participants.
            # voter_votes keys are validated to exclude defendant.
            tally = {v.value: 0 for v in VoteOption}
            votes_cast: Dict[str, str] = {}
            if voter_votes:
                for node_id, vote_str in voter_votes.items():
                    if node_id == case.target_node_id:
                        continue  # INV-6: silently drop defendant vote
                    if node_id not in non_defendant_nodes:
                        continue  # ignore unknown nodes
                    if vote_str in tally:
                        tally[vote_str] += 1
                        votes_cast[node_id] = vote_str

            case.vote_tally = dict(tally)

            # Build QuorumDecision (AR1: required for WIND_DOWN_AND_REPLACE).
            votes_for_wind_down = frozenset(
                n for n, v in votes_cast.items()
                if v == VoteOption.WIND_DOWN_AND_REPLACE.value
            )
            votes_against_wind_down = frozenset(
                n for n, v in votes_cast.items()
                if v != VoteOption.WIND_DOWN_AND_REPLACE.value
            )

            majority = _majority_vote(tally)
            # INV-4: split vote → MONITOR_CONTINUE.
            verdict = majority if majority is not None else VoteOption.MONITOR_CONTINUE

            quorum_dec = QuorumDecision(
                outcome=(
                    DecisionOutcome.COMMIT
                    if majority is not None
                    else DecisionOutcome.NO_QUORUM
                ),
                topic=f"compromise:{case_id}:verdict:{verdict.value}",
                rationale=(
                    f"Vote tally: {tally}. "
                    + ("Majority reached." if majority else
                       "No majority — defaulting to MONITOR_CONTINUE (INV-4).")
                ),
                term=0,
                votes_for=votes_for_wind_down,
                votes_against=votes_against_wind_down,
            )

        case.quorum_decision = quorum_dec
        evidence = _build_evidence_summary(case)

        decision = RemediationDecision(
            case_id=case_id,
            target_node_id=case.target_node_id,
            decision=verdict,
            decided_at=ts,
            vote_tally=dict(tally),
            evidence_summary=evidence,
            quorum_decision=quorum_dec,
        )

        # Step 3 — execute remediation action.
        self._execute(decision, case, ts)
        return decision

    # ------------------------------------------------------------------
    # Step 3 — Remediation action
    # ------------------------------------------------------------------

    def _execute(
        self,
        decision: RemediationDecision,
        case: RemediationCase,
        ts: float,
    ) -> None:
        """
        Execute the remediation action for a decided case.

        AR1: WIND_DOWN_AND_REPLACE MUST have a valid QuorumDecision.
             This invariant is structurally enforced — the QuorumDecision
             is always produced before _execute is called.
        """
        if decision.decision == VoteOption.WIND_DOWN_AND_REPLACE:
            # AR1: quorum_decision is always present (produced in deliberate()).
            # C-4: if target is current leader, trigger leader election first
            # to prevent split-brain before wind-down.
            if self._is_leader_fn and self._is_leader_fn(case.target_node_id):
                if self._trigger_election_fn:
                    self._trigger_election_fn(case.target_node_id)

            # Send quorum-signed wind-down directive (AR1).
            if self._wind_down_fn:
                self._wind_down_fn(case.target_node_id, case.quorum_decision)

            # Wait GRACE_PERIOD for graceful shutdown; force-terminate if
            # target does not comply. (In Phase 1: synchronous stub.)
            if self._force_terminate_fn:
                self._force_terminate_fn(case.target_node_id)

            # Spawn replacement at SIBLING tier — no inherited trust score
            # (INV-5). Replacement also requires quorum (AR1): the
            # QuorumDecision authorising wind-down implicitly authorises
            # replacement in the same deliberation.
            if self._spawn_replacement_fn:
                self._spawn_replacement_fn(case.target_node_id)

            case.status = CaseStatus.CLOSED_WIND_DOWN

        elif decision.decision == VoteOption.MONITOR_CONTINUE:
            # No wind-down; heightened scrutiny flag set.
            # Case archived — future signals will re-open a new case.
            case.status = CaseStatus.CLOSED_MONITOR

        elif decision.decision == VoteOption.EXONERATE:
            # Case closed. Optionally submit CONFORMANT to S2d to
            # partially restore trust score.
            # NOTE: whether CONFORMANT is submitted must be documented
            # at the call site. This implementation provides the hook;
            # the caller decides.
            if self._observe_fn:
                self._observe_fn(case.target_node_id, ConformanceResult.CONFORMANT)
            case.status = CaseStatus.CLOSED_EXONERATE

        # Remove from open index.
        target = case.target_node_id
        if target in self._open_by_target:
            try:
                self._open_by_target[target].remove(case.case_id)
            except ValueError:
                pass

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_or_open_case(
        self, target_node_id: str, signal_time: float
    ) -> RemediationCase:
        """
        Return an existing open case within AGGREGATION_WINDOW, or open a
        new one (INV-3).
        """
        # Look for an open case for this target opened within the window.
        for cid in self._open_by_target.get(target_node_id, []):
            case = self._cases.get(cid)
            if (
                case is not None
                and case.status == CaseStatus.OPEN
                and (signal_time - case.opened_at) <= self._aggregation_window
            ):
                return case

        # No matching case — open a new one.
        new_case = RemediationCase(
            case_id=str(uuid.uuid4()),
            target_node_id=target_node_id,
            opened_at=signal_time,
        )
        self._cases[new_case.case_id] = new_case
        self._open_by_target.setdefault(target_node_id, []).append(
            new_case.case_id
        )
        return new_case

    # ------------------------------------------------------------------
    # Read API
    # ------------------------------------------------------------------

    def get_case(self, case_id: str) -> RemediationCase:
        """Return a case by ID. Raises KeyError if not found."""
        return self._cases[case_id]

    def open_cases(self) -> List[RemediationCase]:
        """Return all currently open cases."""
        return [
            c for c in self._cases.values()
            if c.status == CaseStatus.OPEN
        ]

    def cases_for_target(
        self, target_node_id: str
    ) -> List[RemediationCase]:
        """Return all cases (open or closed) for a given target node."""
        return [
            c for c in self._cases.values()
            if c.target_node_id == target_node_id
        ]
