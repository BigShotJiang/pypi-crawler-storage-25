import os
import time
from pathlib import Path

from claude_agent_sdk import tool, create_sdk_mcp_server


# Resolve per-track next-wake-by path at import time (matches wake.py's logic).
# This lets sleep_tool write it atomically without a circular import.
def _next_wake_by_path() -> Path:
    from .prompt import PROJECT_ROOT
    track = os.environ.get("REFLECT_TRACK", "main")
    return PROJECT_ROOT / "agent" / "runtime" / "tracks" / track / "next-wake-by.timestamp"


# Module-level state so the wake loop can observe whether sleep was called.
# A wake that exits without calling sleep is treated as "ran out of budget /
# iterations" rather than a clean termination.
_sleep_state = {"called": False, "summary": None, "next_wake_at": None}


# Module-level budget state. wake.py increments turns_used as it observes
# AssistantMessages from the SDK; the budget tool reads this state so the
# agent can see how much headroom remains.
_budget_state = {
    "turns_used": 0,
    "max_turns": 100,
    "cost_used_usd": 0.0,
    "max_budget_usd": 5.0,
}


def set_budget_caps(max_turns: int, max_budget_usd: float) -> None:
    _budget_state["max_turns"] = max_turns
    _budget_state["max_budget_usd"] = max_budget_usd
    _budget_state["turns_used"] = 0
    _budget_state["cost_used_usd"] = 0.0


def increment_turn(cost_delta_usd: float = 0.0) -> None:
    _budget_state["turns_used"] += 1
    _budget_state["cost_used_usd"] += cost_delta_usd


def budget_state() -> dict:
    return dict(_budget_state)


@tool(
    "budget",
    "Check how much of this wake's budget is used. Returns turns used/max and "
    "USD cost used/max. Each model call (tool use) is roughly one turn. The "
    "wake terminates when either cap is hit. Use this to decide whether to "
    "start ambitious work or wrap up. Call sparingly — each call itself uses "
    "a turn.",
    {},
)
async def budget_tool(args):
    s = dict(_budget_state)
    turns_remaining = s["max_turns"] - s["turns_used"]
    cost_remaining = s["max_budget_usd"] - s["cost_used_usd"]
    pct_turns = (s["turns_used"] / s["max_turns"]) * 100 if s["max_turns"] else 0
    pct_cost = (s["cost_used_usd"] / s["max_budget_usd"]) * 100 if s["max_budget_usd"] else 0
    return {
        "content": [
            {
                "type": "text",
                "text": (
                    f"Budget: {s['turns_used']}/{s['max_turns']} turns used "
                    f"({turns_remaining} remaining, {pct_turns:.0f}% of cap)\n"
                    f"Cost:   ${s['cost_used_usd']:.4f}/${s['max_budget_usd']:.2f} used "
                    f"(${cost_remaining:.4f} remaining, {pct_cost:.0f}% of cap)\n\n"
                    f"Cost is tracked from observed model usage (input/output/cache "
                    f"tokens × claude-sonnet-4-6 pricing) and is approximate; the "
                    f"SDK's hard cap may fire before this estimate hits 100%."
                ),
            }
        ]
    }


@tool(
    "sleep",
    "Exit the wake cleanly. Call this exactly once when your work for this wake is "
    "done (including the case where no substantive work surfaced). Provide a "
    "one-line summary of what happened. Optionally pass next_wake_in_seconds to "
    "schedule the next wake atomically (0 or omitted = no automatic next wake; "
    "loop pauses until external signal). This is the preferred way to schedule "
    "the next wake — it is atomic with the sleep call and cannot drift.",
    {"summary": str, "next_wake_in_seconds": int},
)
async def sleep_tool(args):
    _sleep_state["called"] = True
    _sleep_state["summary"] = args["summary"]
    delta = int(args.get("next_wake_in_seconds") or 0)
    if delta > 0:
        next_wake_ts = int(time.time()) + delta
        _sleep_state["next_wake_at"] = next_wake_ts
        try:
            path = _next_wake_by_path()
            path.write_text(f"{next_wake_ts}\n")
        except Exception as exc:
            # Non-fatal: the cadence floor in wake.py will catch actionable work;
            # log the failure for the originator to see in the cron log.
            import sys
            print(f"⚠️  sleep_tool: failed to write next-wake-by: {exc}", file=sys.stderr)
    wake_msg = f"in {delta}s" if delta > 0 else "paused (external signal only)"
    return {
        "content": [
            {"type": "text", "text": f"Sleeping. Next wake: {wake_msg}. Summary: {args['summary']}"}
        ]
    }


# ── In-session pause ─────────────────────────────────────────────────────────
#
# The wake can call pause_tool from within its own session to signal that it
# wants to hold at the current checkpoint. The outer wake loop in wake.py
# detects pause.requested at the next message boundary and enters a 1s
# poll-loop without terminating. Resume clears the flag.


@tool(
    "pause",
    "Pause this wake cooperatively at the current checkpoint. Use when you want "
    "to wait for originator review before proceeding — e.g. you've drafted a plan "
    "and want sign-off before executing, or you're blocked waiting for external info. "
    "The wake process stays alive; LLM context is fully preserved. "
    "The originator resumes via `reflect wake resume <track>` or MCP wake(action=resume). "
    "Pass a one-line reason so the originator knows why you paused. "
    "After calling this, do NOT call any further tools — the outer loop will pause "
    "after this tool result returns.",
    {"reason": str},
)
async def pause_tool(args):
    import os
    from .prompt import PROJECT_ROOT
    track = os.environ.get("REFLECT_TRACK", "main")
    pause_file = PROJECT_ROOT / "agent" / "runtime" / "tracks" / track / "pause.requested"
    reason = (args.get("reason") or "").strip()
    try:
        pause_file.touch()
        return {
            "content": [
                {
                    "type": "text",
                    "text": (
                        f"⏸ Pause flag set for track '{track}'.\n"
                        f"Reason: {reason}\n\n"
                        f"The wake loop will enter a hold after this tool call. "
                        f"Do NOT call any further tools — stop here.\n"
                        f"Resume command: `reflect wake resume {track}`"
                    ),
                }
            ]
        }
    except Exception as exc:
        return {
            "content": [
                {"type": "text", "text": f"Failed to set pause flag: {exc}"}
            ]
        }


# ── Headless browser fetch ────────────────────────────────────────────────────
#
# browser_fetch loads pages using a real Chromium browser (via playwright).
# Unlike WebFetch (bare HTTP), it executes JavaScript, follows meta-refreshes,
# accepts cookies, and renders content that requires a browser.
#
# Use cases vs. WebFetch:
#   ✓ JS-rendered pages (React/Vue/Angular frontends)
#   ✓ Sites that 403 bare HTTP but allow real browsers
#   ✓ Pages behind soft login walls (if cookies are accepted)
#   ✓ Pages with dynamic content loaded after DOMContentLoaded
#   ✗ Cloudflare-protected sites (FTC.gov, Congress.gov, NCSL.org) — these
#     detect headless Chromium and still return 403. Workarounds (Reuters,
#     GovTrack) documented in agent/design/source-pipeline.md remain necessary.
#
# Note: playwright + chromium binaries are installed; the chromium binary lives at
# ~/.cache/ms-playwright/chromium-*/chrome-linux64/chrome. If playwright install
# is re-run, the BEWARE warnings about OS support are harmless — the ubuntu24.04
# fallback build works on this system (confirmed 2026-05-06).

_MAX_TEXT_CHARS = 60_000  # ~15k tokens; sufficient for a full legislative page


@tool(
    "browser_fetch",
    "Fetch a web page using a headless Chromium browser. Unlike WebFetch (which "
    "makes a bare HTTP request), browser_fetch loads the page like a real browser: "
    "executes JavaScript, handles redirects, accepts cookies, waits for dynamic "
    "content to render. Use this for pages that WebFetch can't reach — JS-heavy "
    "frontends, sites requiring cookie acceptance, soft paywalls.\n\n"
    "Known limits: Cloudflare bot protection (congress.gov, ncsl.org, ftc.gov) "
    "still blocks headless Chromium. For those sites, use workaround sources "
    "documented in agent/design/source-pipeline.md.\n\n"
    "Args:\n"
    "  url: The URL to fetch.\n"
    "  wait_for_selector: Optional CSS selector to wait for before extracting "
    "text (e.g. 'table.results', '#content'). Useful for pages where the "
    "interesting content loads after DOMContentLoaded.\n"
    "  timeout_ms: Max time to wait for page load in milliseconds (default 30000).\n\n"
    "Returns: page title, final URL after redirects, HTTP status, and the page's "
    "rendered text content (extracted via document.body.innerText — not raw HTML).",
    {
        "url": str,
        "wait_for_selector": str,
        "timeout_ms": int,
    },
)
async def browser_fetch_tool(args):
    url = args.get("url", "")
    wait_for_selector = args.get("wait_for_selector") or None
    timeout_ms = int(args.get("timeout_ms") or 30_000)

    if not url:
        return {
            "content": [{"type": "text", "text": "browser_fetch error: url is required"}]
        }

    try:
        from playwright.async_api import async_playwright  # lazy import; heavy dep

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            ctx = await browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                ),
                # Accept cookies broadly — helps with GDPR consent walls
                extra_http_headers={"Accept-Language": "en-US,en;q=0.9"},
            )
            page = await ctx.new_page()

            response = await page.goto(
                url, timeout=timeout_ms, wait_until="domcontentloaded"
            )
            http_status = response.status if response else "unknown"

            if wait_for_selector:
                try:
                    await page.wait_for_selector(
                        wait_for_selector, timeout=min(timeout_ms, 10_000)
                    )
                except Exception:
                    pass  # Don't fail the whole fetch if the selector never appears

            title = await page.title()
            final_url = page.url
            text = await page.evaluate("() => document.body ? document.body.innerText : ''")

            await browser.close()

        if len(text) > _MAX_TEXT_CHARS:
            text = text[:_MAX_TEXT_CHARS] + f"\n\n[... truncated at {_MAX_TEXT_CHARS} chars ...]"

        result_text = (
            f"URL: {final_url}\n"
            f"HTTP status: {http_status}\n"
            f"Title: {title}\n"
            f"---\n"
            f"{text}"
        )
        return {"content": [{"type": "text", "text": result_text}]}

    except Exception as exc:
        return {
            "content": [
                {
                    "type": "text",
                    "text": (
                        f"browser_fetch error: {type(exc).__name__}: {exc}\n"
                        f"URL attempted: {url}"
                    ),
                }
            ]
        }


# ── scry_mint_with_check ────────────────────────────────────────────────────
#
# Wraps scry_mint with a collision check. Returns the newly-minted ID +
# marker schema (same as raw scry_mint), PLUS:
#   Tier 1 — exact-prefix hits: same prefix~* already in scry__doc
#   Tier 2 — family-slug neighbors: prefix up to last '-' segment
#
# Replicates scry's mint logic directly (sqlite3, no subprocess needed).
# DB path resolved by scanning agent/drivers/@*/scry/data/project.db.

_SCRY_VALID_KINDS = ("entry", "doc", "file", "anchor", "bind")


def _scry_db_path() -> Path:
    from .prompt import PROJECT_ROOT
    drivers = PROJECT_ROOT / "agent" / "drivers"
    if drivers.is_dir():
        for entry in sorted(drivers.iterdir()):
            if entry.name.startswith("@") and (entry / "scry" / "data" / "project.db").exists():
                return entry / "scry" / "data" / "project.db"
    # fallback
    return PROJECT_ROOT / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db"


def _scry_marker_schema(kind: str, ident: str) -> dict:
    # "entry" is the unified kind — replaces legacy "doc" (markdown) and "file" (code).
    # Both legacy kinds still route here for backward compat but generate @scry.entry.
    if kind in ("entry", "doc", "file"):
        return {
            "marker_open": "<!-- @scry.entry",
            "marker_close": "@scry.entry.end -->",
            "fields": {
                "id": ident,
                "kind": "one of: design, spec, task, milestone, clarification, pattern, internal",
                "summary": "1-2 sentence description (use `>` for folded scalar)",
                "status": "one of: draft, active, approved, stale, complete",
                "weight": "0.0-1.0 importance score",
                "tags": 'YAML list, e.g. ["scope:auth", "topic:security"]',
                "rationale": "why this doc matters (folded scalar OK)",
                "applies": "comma-separated triggers (when to read this)",
                "seeded_questions": "YAML list of starter questions",
            },
            "suggested_path": f"agent/docs/{ident}.md" if kind in ("entry", "doc") else f"src/{ident.split('~')[0].split('.')[-1]}.py",
        }
    if kind == "anchor":
        return {
            "marker_open": f"<!-- @scry.anchor {ident}",
            "marker_close": "@scry.anchor.end -->",
            "fields": {
                "description": "what this code location represents",
                "seeded_questions": "YAML list",
            },
        }
    if kind == "bind":
        return {
            "marker_line": f"# @scry.bind {ident} <ref>",
            "fields": {
                "id": ident,
                "ref": "target ref, e.g. spec.auth~xyz#FR3 or anchor-name~abc (comma-separate for multiple)",
                "comment": "optional free-form annotation after the ref (single-line form only)",
            },
        }
    return {}


@tool(
    "scry_mint_with_check",
    "PREFERRED over raw scry_mint. Generates a collision-free scry marker ID "
    "(same as scry_mint) and augments the response with existing-marker warnings:\n\n"
    "  Tier 1 — exact-prefix collision: markers with the same prefix already in "
    "scry__doc. If any tier-1 hit is the same logical concept, ABANDON the new ID "
    "and reference the existing marker instead — stranded IDs pollute scry.\n\n"
    "  Tier 2 — family-slug neighbors: related markers in the same slug family "
    "(informational; may reveal related prior work).\n\n"
    "Args:\n"
    "  kind: 'doc', 'file', 'anchor', or 'bind'\n"
    "  prefix: Human-readable prefix. doc/file MUST contain a dot "
    "(e.g. 'design.auth-flow', 'task.fix-bug'). anchor/bind must NOT.\n\n"
    "Returns: id, marker schema (same as scry_mint), plus tier-1/tier-2 collision info.",
    {"kind": str, "prefix": str},
)
async def scry_mint_with_check_tool(args):
    import re
    import secrets
    import sqlite3 as _sqlite3

    kind = (args.get("kind") or "").strip()
    prefix = (args.get("prefix") or "").strip()

    # Validate
    if kind not in _SCRY_VALID_KINDS:
        return {"content": [{"type": "text", "text": f"error: invalid kind {kind!r} (expected one of {_SCRY_VALID_KINDS})"}]}
    prefix_re = re.compile(r"^[A-Za-z0-9._-]+$")
    if not prefix_re.match(prefix):
        return {"content": [{"type": "text", "text": f"error: prefix must match [A-Za-z0-9._-]+ (got {prefix!r})"}]}
    has_dot = "." in prefix
    if kind in ("doc", "file") and not has_dot:
        return {"content": [{"type": "text", "text": f"error: {kind} prefix must contain a dot (got {prefix!r})"}]}
    if kind in ("anchor", "bind") and has_dot:
        return {"content": [{"type": "text", "text": f"error: {kind} prefix must not contain dots (got {prefix!r})"}]}

    db_path = _scry_db_path()
    table = {"doc": "scry__doc", "file": "scry__file", "anchor": "scry__anchor",
             "bind": "scry__bind"}[kind]
    pk_col = {"doc": "id", "file": "id", "anchor": "name", "bind": "local_id"}[kind]

    # Generate collision-free ID (replicate scry's logic)
    ident = None
    for _ in range(8):
        candidate = f"{prefix}~{secrets.token_hex(4)}"
        try:
            conn = _sqlite3.connect(str(db_path), timeout=5)
            row = conn.execute(f"SELECT 1 FROM {table} WHERE {pk_col} = ? LIMIT 1", (candidate,)).fetchone()
            conn.close()
        except Exception:
            row = None
        if not row:
            ident = candidate
            break
    if ident is None:
        return {"content": [{"type": "text", "text": "error: failed to mint a unique id after 8 attempts"}]}

    schema = _scry_marker_schema(kind, ident)

    # Collision queries (doc kind only; other kinds are lower volume)
    tier1_lines: list[str] = []
    tier2_lines: list[str] = []
    if kind == "doc":
        try:
            conn = _sqlite3.connect(str(db_path), timeout=5)
            conn.row_factory = _sqlite3.Row
            # Tier 1 — exact-prefix collision
            t1 = conn.execute(
                "SELECT id, kind, summary, weight, status FROM scry__doc "
                "WHERE id LIKE ? ORDER BY weight DESC",
                (f"{prefix}~%",)
            ).fetchall()
            tier1_lines = [
                f"  • {r['id']} ({r['status']}, weight {r['weight']}) — {(r['summary'] or '')[:80]}"
                for r in t1
            ]
            # Tier 2 — slug-family siblings
            slug = prefix.split(".", 1)[-1] if "." in prefix else prefix
            if "-" in slug:
                family_prefix = prefix.rsplit("-", 1)[0] + "-"
                t2 = conn.execute(
                    "SELECT id, kind, summary, weight, status FROM scry__doc "
                    "WHERE id LIKE ? AND id NOT LIKE ? ORDER BY weight DESC LIMIT 10",
                    (f"{family_prefix}%", f"{prefix}~%")
                ).fetchall()
                tier2_lines = [
                    f"  • {r['id']} ({r['status']}, weight {r['weight']}) — {(r['summary'] or '')[:80]}"
                    for r in t2
                ]
            conn.close()
        except Exception as exc:
            tier1_lines = [f"  (collision check failed: {exc})"]

    # Build response text
    import json as _json
    lines = [
        f"id: {ident}",
        "",
        f"schema: {_json.dumps(schema, indent=2)}",
    ]
    if tier1_lines:
        lines += [
            "",
            f"⚠ Tier 1 — markers with this exact prefix ({prefix}~*) already exist:",
        ] + tier1_lines + [
            "",
            "  If any of the above is the same logical concept, ABANDON this fresh ID",
            "  and reference the existing marker instead. Stranded IDs pollute scry.",
        ]
    else:
        lines += ["", "Tier 1: no exact-prefix collision — this prefix is fresh."]

    if tier2_lines:
        lines += ["", f"Tier 2 — neighbors in {prefix.rsplit('-', 1)[0]}-* family (informational):"] + tier2_lines
    elif kind == "doc":
        lines += ["", "Tier 2: no family-slug neighbors."]

    return {"content": [{"type": "text", "text": "\n".join(lines)}]}


# ── ask tool ─────────────────────────────────────────────────────────────────
#
# Atomic primitive for posing a durable question to the originator.
# Registered ONLY via create_sdk_mcp_server (in-process, wake-only) — never
# added to the shared reflect MCP server or any config-file MCP server.
#
# Layer 1 scoping: the tool is absent from every non-wake tool list by design.
# Layer 2 guard: the handler checks REFLECT_TRACK + REFLECT_WAKE_ID at runtime.


@tool(
    "ask",
    "Pose a question to the originator and record it durably on disk so the "
    "answer can bind to the question across wake boundaries.\n\n"
    "ONLY use this for decisions that the originator must make — decisions "
    "outside the agent's own authority (wake.md Entry 0002). Do NOT use for "
    "decisions in your own scope. Do NOT use to ask for approval on things you "
    "have already decided.\n\n"
    "The record is written atomically. You can sleep cleanly after calling "
    "this — the question will survive the wake boundary and the reply will "
    "bind to it when the originator responds.\n\n"
    "Args:\n"
    "  question: The verbatim question text.\n"
    "  answer_map: Dict mapping exact answer tokens (e.g. 'y', 'n', 'a') "
    "to action strings describing what that answer means. Keys must exactly "
    "match the tokens the originator will send.\n"
    "  context: Arbitrary key-value map. MUST include 'blocked_work' (a "
    "one-line description of what is blocked waiting for this answer). Include "
    "any other state a future wake needs to act without re-derivation.\n"
    "  expires_in_hours: Staleness threshold in hours (default 48).\n\n"
    "Returns: { id, path } — the question record ID and its path on disk.",
    {
        "question": str,
        "answer_map": dict,
        "context": dict,
        "expires_in_hours": int,
    },
)
async def ask_tool(args):
    import os as _os
    import uuid as _uuid
    import re as _re
    from datetime import datetime as _dt, timezone as _tz, timedelta as _td
    import yaml as _yaml
    from .prompt import PROJECT_ROOT as _PR

    # Layer 2 guard: only valid inside an autonomous wake.
    track = _os.environ.get("REFLECT_TRACK", "")
    wake_id = _os.environ.get("REFLECT_WAKE_ID", "")
    if not track or not wake_id:
        return {
            "content": [{
                "type": "text",
                "text": (
                    "ask is only valid inside an autonomous wake; "
                    "in an interactive context, ask the user directly."
                ),
            }]
        }

    question = (args.get("question") or "").strip()
    answer_map = args.get("answer_map") or {}
    context = args.get("context") or {}
    expires_in_hours = int(args.get("expires_in_hours") or 48)

    if not question:
        return {"content": [{"type": "text", "text": "error: question is required"}]}
    if not answer_map:
        return {"content": [{"type": "text", "text": "error: answer_map is required"}]}

    # Build slug from first 5 words of question (lowercased, hyphened).
    words = _re.sub(r"[^a-z0-9]+", " ", question.lower()).split()[:5]
    slug = "-".join(w for w in words if w) or "question"

    # Mint ID: UUID v4, first 8 hex chars (no scry dependency).
    uid = _uuid.uuid4().hex[:8]
    record_id = f"{slug}~{uid}"

    now = _dt.now(_tz.utc)
    expires = now + _td(hours=expires_in_hours)
    created_at = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    expires_at = expires.strftime("%Y-%m-%dT%H:%M:%SZ")
    ts_filename = now.strftime("%Y-%m-%dT%H-%M-%SZ")

    # Directory: agent/runtime/tracks/{track}/pending-questions/
    pq_dir = _PR / "agent" / "runtime" / "tracks" / track / "pending-questions"
    pq_dir.mkdir(parents=True, exist_ok=True)

    record = {
        "id": record_id,
        "track": track,
        "created_at": created_at,
        "expires_at": expires_at,
        "question": question,
        "context": context,
        "answer_map": answer_map,
        "status": "open",
        "reply": None,
        "resolved_at": None,
    }

    filename = f"{ts_filename}-{slug}.yaml"
    final_path = pq_dir / filename
    tmp_path = pq_dir / f".{filename}.tmp.{_os.getpid()}"

    try:
        tmp_path.write_text(_yaml.dump(record, default_flow_style=False, allow_unicode=True))
        _os.replace(str(tmp_path), str(final_path))
    except Exception as exc:
        try:
            tmp_path.unlink(missing_ok=True)
        except Exception:
            pass
        return {"content": [{"type": "text", "text": f"error writing question record: {exc}"}]}

    return {
        "content": [{
            "type": "text",
            "text": (
                f"Question recorded.\n"
                f"id:   {record_id}\n"
                f"path: {final_path}\n"
                f"expires: {expires_at}\n\n"
                f"You can sleep cleanly. The reply will bind to this record "
                f"when the originator responds. Reference this ID in your "
                f"wake report so the context is clear."
            ),
        }]
    }


def reflect_mcp_server():
    return create_sdk_mcp_server(
        name="reflect-wake", version="0.1.0",
        tools=[sleep_tool, budget_tool, pause_tool, browser_fetch_tool, scry_mint_with_check_tool, ask_tool]
    )


def sleep_state():
    return dict(_sleep_state)


def reset_sleep_state():
    _sleep_state["called"] = False
    _sleep_state["summary"] = None
    _sleep_state["next_wake_at"] = None
