# @scry.entry
# id: code.heartbeat-health~379137df
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:heartbeat-health",
#        "heartbeat-health", "topic:S5c", "S5c", "kind:code", "code",
#        "substrate-evolution", "heartbeat", "fault-detection",
#        "HEARTBEAT_INTERVAL", "FAULT_THRESHOLD", "HeartbeatPing",
#        "HeartbeatFault", "FR24", "INV-4", "INV-5"]
# summary: >
#   S5c implementation — heartbeat-health Python module. Implements
#   HeartbeatPing (with monotone sequence numbers, INV-4), HeartbeatFault
#   (with PERMANENT/TRANSIENT/SUSPECTED classification), HeartbeatMonitor,
#   send_ping(), record_pong(), and check_health() per
#   spec.heartbeat-health~80d5f97a. HEARTBEAT_INTERVAL and FAULT_THRESHOLD
#   are mandatory explicit constructor parameters — never defaults (FR24).
#   Fault window resets on successful ping receipt (INV-5). Sequence numbers
#   are strictly monotone (INV-4). Phase 1: in-process in-memory health state.
#   Also: heartbeat-health, HeartbeatPing, HeartbeatFault, HeartbeatMonitor,
#   fault detection, sequence number, fault threshold, interval parameter,
#   S5c, substrate-evolution, heartbeat_health.py.
# rationale: >
#   Missing this means S5d (remediation trigger) has no HeartbeatFault type
#   to consume; health-based node removal and repair cannot be built.
# applies: >
#   building node health monitoring, configuring heartbeat intervals,
#   detecting faulted nodes, triggering S5d remediation, auditing FR24
#   explicit-parameter compliance, reviewing INV-4 sequence monotonicity
# seeded_questions:
#   - "How does HeartbeatMonitor work?"
#   - "What is a HeartbeatFault?"
#   - "What is FR24 HEARTBEAT_INTERVAL FAULT_THRESHOLD?"
#   - "How does fault window reset on successful ping?"
#   - "heartbeat_health.py S5c substrate-evolution"
#   - "sequence number monotone heartbeat"
# @scry.entry.end

"""
S5c — Heartbeat Health (spec.heartbeat-health~80d5f97a)

Node liveness monitoring via periodic ping/pong with fault-threshold
detection and escalation classification.

FR24 (explicit parameters): HEARTBEAT_INTERVAL and FAULT_THRESHOLD MUST
be explicit constructor parameters with no embedded defaults. Callers MUST
supply both. This prevents silent misconfiguration in deployment.

INV-4 (sequence monotonicity): ping sequence numbers MUST be strictly
monotonically increasing per target. A pong with a sequence number less
than or equal to the last seen sequence is discarded as a duplicate or
out-of-order artifact.

INV-5 (fault-window reset): a successful pong resets the consecutive-miss
counter for that target to zero. Fault state is based on the current
window, not a lifetime accumulation.

Phase 1 delivers: HeartbeatPing, HeartbeatFault, HeartbeatMonitor,
send_ping(), record_pong(), check_health(). All in-process; multi-node
network transport is Phase 4+.

Requirements satisfied:
- FR24: HEARTBEAT_INTERVAL and FAULT_THRESHOLD are explicit parameters.
- FR25: HeartbeatFault carries classification (PERMANENT/TRANSIENT/SUSPECTED).
- FR26: check_health() returns per-node health status.
- INV-4: sequence numbers are strictly monotone; out-of-order discarded.
- INV-5: fault window resets on any successful pong.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, FrozenSet, List, Optional, Set


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class FaultClass(str, Enum):
    """
    Fault severity classification for a faulted node (FR25).

    SUSPECTED:  Consecutive misses just crossed the threshold. Node may
                recover; should be flagged but not yet removed.
    TRANSIENT:  Continued misses beyond FAULT_THRESHOLD * 2. Node likely
                crashed or partitioned; may still recover.
    PERMANENT:  Continued misses beyond FAULT_THRESHOLD * 4. Node should
                be removed from the active cluster and remediation triggered
                via S5d.
    """
    SUSPECTED = "suspected"
    TRANSIENT = "transient"
    PERMANENT = "permanent"


class NodeHealth(str, Enum):
    """
    Per-node health status returned by check_health() (FR26).

    HEALTHY:   Most recent pong received within expected window.
    FAULTED:   Consecutive misses at or above FAULT_THRESHOLD.
    UNKNOWN:   No pings have been sent to this node yet.
    """
    HEALTHY = "healthy"
    FAULTED = "faulted"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class HeartbeatPing:
    """
    A single heartbeat ping issued to a target node (FR24, INV-4).

    ping_id:    Unique identifier for this ping.
    target_id:  The node being pinged.
    sequence:   Strictly monotonically increasing sequence number per
                target. The pong MUST echo this sequence; a pong with a
                sequence <= the last acknowledged sequence is discarded
                (INV-4).
    issued_at:  Unix epoch float.
    """
    ping_id: str
    target_id: str
    sequence: int
    issued_at: float = field(default_factory=time.time)


@dataclass(frozen=True)
class HeartbeatPong:
    """
    A pong response echoed from a target node.

    ping_id:     The ping_id echoed from the originating HeartbeatPing.
    target_id:   The node that responded.
    sequence:    The sequence number echoed from the ping.
    received_at: Unix epoch float.
    """
    ping_id: str
    target_id: str
    sequence: int
    received_at: float = field(default_factory=time.time)


@dataclass(frozen=True)
class HeartbeatFault:
    """
    A fault event for a node that has exceeded the miss threshold (FR25).

    target_id:        The faulted node.
    consecutive_misses: Number of consecutive missed pongs.
    fault_class:      SUSPECTED / TRANSIENT / PERMANENT.
    last_seen_at:     Unix epoch float of the last successful pong (or None).
    detected_at:      Unix epoch float when the fault was classified.
    """
    target_id: str
    consecutive_misses: int
    fault_class: FaultClass
    last_seen_at: Optional[float]
    detected_at: float = field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Public API — HeartbeatMonitor
# ---------------------------------------------------------------------------

class HeartbeatMonitor:
    """
    In-process heartbeat health monitor (FR24–FR26, INV-4, INV-5).

    FR24 compliance: HEARTBEAT_INTERVAL and FAULT_THRESHOLD are required
    constructor arguments with no defaults. Deployment MUST supply both.

    Usage:
        monitor = HeartbeatMonitor(
            nodes={"node-a", "node-b", "node-c"},
            heartbeat_interval=30.0,   # FR24: explicit
            fault_threshold=3,          # FR24: explicit
        )
        ping = monitor.send_ping("node-a")
        monitor.record_pong(pong)
        health = monitor.check_health()
    """

    def __init__(
        self,
        nodes: Set[str],
        heartbeat_interval: float,   # FR24: MUST be explicit — no default
        fault_threshold: int,         # FR24: MUST be explicit — no default
    ) -> None:
        """
        Initialise the monitor (FR24).

        Args:
            nodes:               Set of node IDs to monitor.
            heartbeat_interval:  Seconds between expected pings. MANDATORY.
            fault_threshold:     Consecutive misses before declaring fault.
                                 MANDATORY. No default value.
        Raises:
            ValueError if heartbeat_interval <= 0 or fault_threshold < 1.
        """
        if heartbeat_interval <= 0:
            raise ValueError(
                f"heartbeat_interval must be > 0; got {heartbeat_interval}. "
                "FR24 requires an explicit, positive interval."
            )
        if fault_threshold < 1:
            raise ValueError(
                f"fault_threshold must be >= 1; got {fault_threshold}. "
                "FR24 requires an explicit, positive threshold."
            )
        self.nodes: FrozenSet[str] = frozenset(nodes)
        self.heartbeat_interval: float = heartbeat_interval
        self.fault_threshold: int = fault_threshold

        # Per-node state (mutable, in-memory).
        self._sequence: Dict[str, int] = {n: 0 for n in nodes}
        self._consecutive_misses: Dict[str, int] = {n: 0 for n in nodes}
        self._last_seen: Dict[str, Optional[float]] = {n: None for n in nodes}
        self._last_ack_sequence: Dict[str, int] = {n: -1 for n in nodes}
        self._pending_pings: Dict[str, HeartbeatPing] = {}

    # -------------------------------------------------------------------
    # send_ping
    # -------------------------------------------------------------------

    def send_ping(
        self,
        target_id: str,
        now: Optional[float] = None,
    ) -> HeartbeatPing:
        """
        Issue a heartbeat ping to a target node (INV-4).

        Sequence number is strictly incremented on every call; it is
        never reused or decremented. The ping is recorded as pending
        until acknowledged by record_pong().

        Args:
            target_id: The node to ping. Must be in the registered set.
            now:       Current time; defaults to time.time().
        Returns:
            HeartbeatPing with a new monotone sequence number.
        Raises:
            ValueError if target_id not in registered nodes.
        """
        import uuid as _uuid
        if target_id not in self.nodes:
            raise ValueError(
                f"target_id {target_id!r} not in registered nodes. "
                "Register nodes at construction time."
            )
        if now is None:
            now = time.time()
        self._sequence[target_id] += 1
        ping = HeartbeatPing(
            ping_id=str(_uuid.uuid4()),
            target_id=target_id,
            sequence=self._sequence[target_id],
            issued_at=now,
        )
        self._pending_pings[target_id] = ping
        return ping

    # -------------------------------------------------------------------
    # record_pong
    # -------------------------------------------------------------------

    def record_pong(self, pong: HeartbeatPong) -> bool:
        """
        Record a pong response; reset the fault window on success (INV-5).

        Discards pongs with sequence numbers <= the last acknowledged
        sequence (out-of-order or duplicate — INV-4).

        Args:
            pong: The HeartbeatPong received from the target.
        Returns:
            True if the pong was accepted and counted; False if discarded.
        """
        if pong.target_id not in self.nodes:
            return False
        # INV-4: discard out-of-order or duplicate pongs.
        if pong.sequence <= self._last_ack_sequence[pong.target_id]:
            return False
        self._last_ack_sequence[pong.target_id] = pong.sequence
        # INV-5: fault window resets on any successful pong.
        self._consecutive_misses[pong.target_id] = 0
        self._last_seen[pong.target_id] = pong.received_at
        # Clear the pending ping if sequence matches.
        pending = self._pending_pings.get(pong.target_id)
        if pending and pending.sequence == pong.sequence:
            del self._pending_pings[pong.target_id]
        return True

    # -------------------------------------------------------------------
    # record_miss
    # -------------------------------------------------------------------

    def record_miss(self, target_id: str) -> None:
        """
        Record a missed pong for a target node.

        Called when a ping has gone unanswered past the expected window.
        Increments consecutive_misses; does NOT reset the fault window.

        Args:
            target_id: The node that did not respond.
        Raises:
            ValueError if target_id not in registered nodes.
        """
        if target_id not in self.nodes:
            raise ValueError(f"target_id {target_id!r} not in registered nodes.")
        self._consecutive_misses[target_id] += 1

    # -------------------------------------------------------------------
    # check_health
    # -------------------------------------------------------------------

    def check_health(
        self,
        now: Optional[float] = None,
    ) -> Dict[str, NodeHealth]:
        """
        Return per-node health status (FR26).

        A node is HEALTHY if its consecutive_misses < fault_threshold
        and (last_seen_at is None and no pending ping, OR last ping
        was within heartbeat_interval * fault_threshold seconds).
        A node is FAULTED if consecutive_misses >= fault_threshold.
        A node is UNKNOWN if no ping has been sent yet.

        Args:
            now: Current time; defaults to time.time().
        Returns:
            Dict[node_id, NodeHealth].
        """
        if now is None:
            now = time.time()
        result: Dict[str, NodeHealth] = {}
        for node_id in self.nodes:
            if self._sequence[node_id] == 0:
                # No ping has been issued yet.
                result[node_id] = NodeHealth.UNKNOWN
            elif self._consecutive_misses[node_id] >= self.fault_threshold:
                result[node_id] = NodeHealth.FAULTED
            else:
                result[node_id] = NodeHealth.HEALTHY
        return result

    # -------------------------------------------------------------------
    # get_faults
    # -------------------------------------------------------------------

    def get_faults(
        self,
        now: Optional[float] = None,
    ) -> List[HeartbeatFault]:
        """
        Return HeartbeatFault records for all currently faulted nodes (FR25).

        FaultClass is derived from consecutive_misses relative to fault_threshold:
        - SUSPECTED:  misses == fault_threshold
        - TRANSIENT:  fault_threshold < misses <= fault_threshold * 2
        - PERMANENT:  misses > fault_threshold * 2

        Args:
            now: Current time; defaults to time.time().
        Returns:
            List[HeartbeatFault] for all nodes at or above fault_threshold.
        """
        if now is None:
            now = time.time()
        faults: List[HeartbeatFault] = []
        for node_id in self.nodes:
            misses = self._consecutive_misses[node_id]
            if misses < self.fault_threshold:
                continue
            if misses <= self.fault_threshold:
                fault_class = FaultClass.SUSPECTED
            elif misses <= self.fault_threshold * 2:
                fault_class = FaultClass.TRANSIENT
            else:
                fault_class = FaultClass.PERMANENT
            faults.append(HeartbeatFault(
                target_id=node_id,
                consecutive_misses=misses,
                fault_class=fault_class,
                last_seen_at=self._last_seen[node_id],
                detected_at=now,
            ))
        return faults


# ---------------------------------------------------------------------------
# Module-level convenience functions
# ---------------------------------------------------------------------------

def send_ping(
    monitor: HeartbeatMonitor,
    target_id: str,
    now: Optional[float] = None,
) -> HeartbeatPing:
    """Convenience: delegate to monitor.send_ping()."""
    return monitor.send_ping(target_id, now=now)


def record_pong(
    monitor: HeartbeatMonitor,
    pong: HeartbeatPong,
) -> bool:
    """Convenience: delegate to monitor.record_pong()."""
    return monitor.record_pong(pong)


def check_health(
    monitor: HeartbeatMonitor,
    now: Optional[float] = None,
) -> Dict[str, NodeHealth]:
    """Convenience: delegate to monitor.check_health()."""
    return monitor.check_health(now=now)
