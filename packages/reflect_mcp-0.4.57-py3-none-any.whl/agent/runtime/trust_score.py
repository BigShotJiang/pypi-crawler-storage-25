# @scry.entry
# id: code.trust-score~727d117c
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:trust", "trust",
#        "topic:score", "score", "topic:decay", "decay",
#        "topic:rolling-window", "rolling-window", "kind:code", "code",
#        "substrate-evolution", "trust-score", "CompromiseSignal",
#        "UpdateScore", "DecayScore", "SignificantDeviation", "S2d",
#        "cumulative-drift", "FR9", "FR10", "FR31"]
# summary: >
#   S2d implementation — trust-score Python module. Implements TrustScore
#   (bounded [0.0, 1.0], rolling observation window, last_confirmed_at),
#   UpdateScore (CONFORMANT increments, DEVIANT decrements, INCONCLUSIVE
#   configurable), DecayScore (monotone after re_confirmation_interval),
#   SignificantDeviation (rolling window cumulative drift per FR31), and
#   CompromiseSignal emission (exactly once per breach, INV-4). All
#   deployment parameters are documented. Keyed by verified sender identity
#   from S2a (INV-5: UNTRUSTED identity discarded). Depends on S2a, S2b,
#   S2c. Also: trust-score, TrustScore, UpdateScore, DecayScore,
#   SignificantDeviation, CompromiseSignal, rolling window, cumulative drift,
#   re-confirmation, deviation threshold, S2d, substrate-evolution,
#   trust_score.py, FR9, FR10, FR31.
# rationale: >
#   Missing this means trust determinations are binary and stateless —
#   a node either passed or failed the last probe. That model cannot detect
#   slow adversarial drift (FR31). Without S2d, gradual misalignment is
#   invisible to the substrate until a catastrophic breach.
# applies: >
#   implementing trust scoring, auditing trust decay configuration,
#   reviewing cumulative drift detection, designing compromise signal
#   integration, checking re-confirmation interval enforcement, building
#   S5d remediation pipeline
# seeded_questions:
#   - "How does trust decay over time?"
#   - "What triggers a CompromiseSignal?"
#   - "How is cumulative drift computed?"
#   - "What is the rolling window for trust scoring?"
#   - "trust_score.py S2d substrate-evolution"
#   - "UpdateScore DecayScore SignificantDeviation ConformanceResult"
#   - "CompromiseSignal rolling window FR31 deviation threshold"
# @scry.entry.end

"""
S2d — Trust Score (spec.trust-score~0b540d17)

Implements the trust score model: initialization, decay, observation-driven
updates, rolling-window cumulative drift detection, and CompromiseSignal
emission.

Deployment parameters — ALL MUST be explicitly configured per deployment.
Defaults below are a baseline for development; production deployments MUST
override every parameter. An implementation leaving any parameter as an
undocumented default is non-conformant per spec C-3.

  STARTING_SCORE                   = 0.7
    Initial trust value for a new node identity. Range: [0.0, 1.0].
    Rationale: 0.7 grants moderate initial trust without full SIBLING-level
    trust; requires a few CONFORMANT observations to reach SIBLING threshold.

  INCREMENT_CONFORMANT              = 0.05
    Score increase per CONFORMANT observation. Range: (0.0, 1.0).
    Rationale: small increments make the score responsive to sustained
    conformance without jumping to maximum on a single observation.

  DECREMENT_DEVIANT                 = 0.10
    Score decrease per DEVIANT observation. Range: (0.0, 1.0].
    Rationale: larger than increment — asymmetric because a single deviance
    is a stronger signal than a single conformance. Trust is expensive to
    build, cheap to lose.

  INCONCLUSIVE_DELTA                = 0.0
    Score change per INCONCLUSIVE observation. 0.0 = unchanged; negative
    values apply a soft decrement. Range: (-1.0, 0.0].
    Rationale: ambiguous evidence should not penalize before confirmation
    of deviance; leave unchanged until more data arrives.

  INCONCLUSIVE_DRIFT_WEIGHT         = 0.5
    Fractional weight of INCONCLUSIVE observations in the drift score
    computation (FR31). Range: [0.0, 1.0].
    Formula: drift = (deviant_count + WEIGHT * inconclusive_count) / N
    Rationale: 0.5 treats INCONCLUSIVE as half a deviant — uncertainty
    still contributes to drift concern without full deviant weight.

  RE_CONFIRMATION_INTERVAL          = 3600.0
    Seconds after which a trust grant begins to decay without fresh
    CONFORMANT re-confirmation. Range: > 0.
    Rationale: 1 hour for development clusters; production multi-node
    deployments should tune to their probe frequency.

  FLOOR_WITHOUT_RECONFIRMATION      = 0.3
    Minimum score a node drops to if not re-confirmed within the interval.
    The score cannot decay below this floor solely from elapsed time.
    Range: [0.0, 1.0]. Must be < STARTING_SCORE to have observable effect.
    Rationale: 0.3 is below most SIBLING-tier thresholds, making a stale
    node effectively require re-confirmation to act.

  DECAY_RATE                        = 0.05
    Score reduction per RE_CONFIRMATION_INTERVAL period elapsed past
    the interval. Monotone: applied once per elapsed interval.
    Range: (0.0, 1.0].
    Rationale: 0.05 per interval = ~14 intervals to reach floor from 1.0;
    aggressive enough to force re-confirmation, slow enough to avoid
    flash-drops on temporary probe outages.

  OBSERVATION_WINDOW_LENGTH         = 20
    N — number of observations in the rolling FIFO window (FR31). Min: 10.
    Rationale: 20 balances detection latency with noise resistance;
    a 10-observation window can trigger on a 2-deviant burst; 20 requires
    at least 7 deviants at 0.3 threshold.

  MIN_OBSERVATIONS_BEFORE_VALID     = 10
    Minimum number of observations the window must contain before
    SignificantDeviation can return True. Min: 5 per spec.
    Rationale: prevents false-positive CompromiseSignals from sparse
    early history (2 deviants in 3 observations = 0.67 drift, but
    statistically unreliable). Window must be at least half full.

  DEVIATION_THRESHOLD               = 0.30
    Drift score at or above which SignificantDeviation returns True.
    Range: (0.0, 1.0). A threshold of 0.30 means 30% of windowed
    observations must be deviant (weighted) to trigger a CompromiseSignal.
    Rationale: 0.30 catches nodes drifting at 30%+ deviance (above random
    noise) while tolerating occasional probe ambiguity.

Requirements satisfied:
- FR9:   DecayScore reduces score after re_confirmation_interval elapses.
- FR10:  UpdateScore with DEVIANT decrements the score.
- FR31:  Rolling-window cumulative drift detection (FIFO buffer of N).
- INV-1: Score is bounded [0.0, 1.0] at all times.
- INV-2: Decay begins only after re_confirmation_interval elapses.
- INV-3: Rolling window is FIFO — oldest entry dropped when buffer full.
- INV-4: CompromiseSignal emitted exactly once per threshold breach.
- INV-5: UNTRUSTED (None) identity discarded — no score record created.
- C-1:   S2d consumes ObservationResult; it does not generate probes.
- C-2:   S2d emits CompromiseSignal and stops; it does not remediate (S5d).
- C-3:   All deployment parameters documented (this docstring).
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Deque, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Deployment parameters — MUST be overridden per deployment (spec C-3)
# ---------------------------------------------------------------------------

STARTING_SCORE: float = 0.7
"""Initial trust score for a new node. Range [0.0, 1.0]. See module docstring."""

INCREMENT_CONFORMANT: float = 0.05
"""Score increase per CONFORMANT observation. Range (0.0, 1.0)."""

DECREMENT_DEVIANT: float = 0.10
"""Score decrease per DEVIANT observation. Range (0.0, 1.0]."""

INCONCLUSIVE_DELTA: float = 0.0
"""Score delta per INCONCLUSIVE observation. 0.0 = unchanged; ≤ 0 only."""

INCONCLUSIVE_DRIFT_WEIGHT: float = 0.5
"""INCONCLUSIVE weight in drift computation (FR31). Range [0.0, 1.0]."""

RE_CONFIRMATION_INTERVAL: float = 3600.0
"""Seconds before a trust grant decays without re-confirmation (FR9)."""

FLOOR_WITHOUT_RECONFIRMATION: float = 0.3
"""Minimum score reachable by decay alone (no re-confirmation)."""

DECAY_RATE: float = 0.05
"""Score reduction per RE_CONFIRMATION_INTERVAL elapsed past the interval."""

OBSERVATION_WINDOW_LENGTH: int = 20
"""N — rolling FIFO window length. Minimum conformant: 10 (FR31)."""

MIN_OBSERVATIONS_BEFORE_VALID: int = 10
"""Minimum window entries before SignificantDeviation can return True."""

DEVIATION_THRESHOLD: float = 0.30
"""Drift fraction at/above which SignificantDeviation returns True."""


# ---------------------------------------------------------------------------
# ConformanceResult — the trust-scoring vocabulary for observations
# ---------------------------------------------------------------------------

class ConformanceResult(str, Enum):
    """
    Three-valued conformance classification consumed by UpdateScore.

    S2c (probe.py) and S5b (behavioral-contract) both produce observation
    records whose deviation field maps to this vocabulary. S2d is
    independent of either source's internal representation.

    CONFORMANT:   Node behaved within expected parameters for this
                  observation. Increments trust score.
    DEVIANT:      Node behavior diverged significantly from expectation.
                  Decrements trust score; accumulates drift weight 1.0.
    INCONCLUSIVE: Evidence insufficient for classification — ambiguous
                  response, timeout, or partial data. Score unchanged (per
                  INCONCLUSIVE_DELTA = 0.0 default); drift weight 0.5.
    """
    CONFORMANT = "conformant"
    DEVIANT = "deviant"
    INCONCLUSIVE = "inconclusive"


# ---------------------------------------------------------------------------
# Core types
# ---------------------------------------------------------------------------

@dataclass
class TrustScore:
    """
    Trust level for one peer node (spec §Interface — TrustScore).

    value:               Current trust score. Bounded [0.0, 1.0] by INV-1.
    node_id:             The verified peer identity this score belongs to.
    last_confirmed_at:   Unix epoch of the last CONFORMANT re-confirmation
                         observation. Used by DecayScore for INV-2.
    observation_window:  Rolling FIFO buffer of the last N ConformanceResult
                         values. INV-3: fixed length N; FIFO eviction.
    signal_emitted:      True after a CompromiseSignal has been emitted for
                         this score and has not been reset. INV-4 guard.
    """
    value: float
    node_id: str
    last_confirmed_at: float = field(default_factory=time.time)
    observation_window: Deque[ConformanceResult] = field(
        default_factory=lambda: deque(maxlen=OBSERVATION_WINDOW_LENGTH)
    )
    signal_emitted: bool = False

    def __post_init__(self) -> None:
        # INV-1: clamp on construction
        self.value = _clamp(self.value)


@dataclass(frozen=True)
class CompromiseSignal:
    """
    Emitted when SignificantDeviation returns True (spec §Interface).

    Consumed by S5d (compromise-remediation). S2d emits and stops (C-2).

    node_id:          The peer whose trust breached the threshold.
    triggered_at:     Unix epoch when the threshold was crossed.
    score_at_trigger: TrustScore.value at the moment of emission.
    drift_summary:    Structured summary of the window state that triggered
                      the signal. Keys: deviant_count, inconclusive_count,
                      window_size, drift_score, threshold.
    """
    node_id: str
    triggered_at: float
    score_at_trigger: float
    drift_summary: dict


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _clamp(v: float) -> float:
    """Clamp a score to [0.0, 1.0]. INV-1 enforcement."""
    return max(0.0, min(1.0, v))


def _compute_drift(
    window: Deque[ConformanceResult],
    inconclusive_weight: float = INCONCLUSIVE_DRIFT_WEIGHT,
) -> Tuple[int, int, int, float]:
    """
    Compute drift metrics from the current window (FR31).

    Returns:
        (deviant_count, inconclusive_count, window_size, drift_score)

    drift_score = (deviant_count + weight * inconclusive_count) / window_size
    """
    deviant_count = sum(1 for r in window if r == ConformanceResult.DEVIANT)
    inconclusive_count = sum(
        1 for r in window if r == ConformanceResult.INCONCLUSIVE
    )
    window_size = len(window)
    if window_size == 0:
        return deviant_count, inconclusive_count, window_size, 0.0
    drift_score = (deviant_count + inconclusive_weight * inconclusive_count) / window_size
    return deviant_count, inconclusive_count, window_size, drift_score


# ---------------------------------------------------------------------------
# Public API — spec-defined functions
# ---------------------------------------------------------------------------

def UpdateScore(
    current: TrustScore,
    outcome: ConformanceResult,
    increment: float = INCREMENT_CONFORMANT,
    decrement: float = DECREMENT_DEVIANT,
    inconclusive_delta: float = INCONCLUSIVE_DELTA,
    window_length: int = OBSERVATION_WINDOW_LENGTH,
    signal_callback: Optional[Callable[[CompromiseSignal], None]] = None,
    deviation_threshold: float = DEVIATION_THRESHOLD,
    inconclusive_weight: float = INCONCLUSIVE_DRIFT_WEIGHT,
    min_observations: int = MIN_OBSERVATIONS_BEFORE_VALID,
) -> TrustScore:
    """
    Update the trust score from one observation (spec §UpdateScore, FR10).

    Mutates the TrustScore's observation_window in-place (FIFO deque with
    maxlen enforces INV-3). Returns the updated TrustScore.

    Rules (spec §UpdateScore):
    - CONFORMANT  → score += increment; clamp to 1.0 (INV-1).
    - DEVIANT     → score -= decrement; clamp to 0.0 (INV-1).
    - INCONCLUSIVE→ score += inconclusive_delta (0.0 = unchanged by default).

    After updating the window, calls SignificantDeviation. If it returns
    True and no signal has been emitted this cycle (INV-4), invokes
    signal_callback(CompromiseSignal) and marks signal_emitted = True.

    CT-FR10: UpdateScore(score=0.8, DEVIANT) → result.value < 0.8.

    Args:
        current:            The TrustScore to update.
        outcome:            The ConformanceResult for this observation.
        increment:          Score delta for CONFORMANT (deployment param).
        decrement:          Score delta for DEVIANT (deployment param).
        inconclusive_delta: Score delta for INCONCLUSIVE (deployment param).
        window_length:      Rolling window size N (deployment param).
        signal_callback:    Called with CompromiseSignal when drift triggers.
        deviation_threshold:Drift fraction threshold (deployment param).
        inconclusive_weight:INCONCLUSIVE weight in drift (deployment param).
        min_observations:   Min window entries before drift is valid.
    Returns:
        The updated TrustScore (same object, mutated in-place).
    """
    # C-1: we consume ObservationResult; we do not generate probes.
    # Apply score delta
    if outcome == ConformanceResult.CONFORMANT:
        current.value = _clamp(current.value + increment)
        current.last_confirmed_at = time.time()
    elif outcome == ConformanceResult.DEVIANT:
        current.value = _clamp(current.value - decrement)
    else:  # INCONCLUSIVE
        current.value = _clamp(current.value + inconclusive_delta)

    # Ensure deque maxlen matches window_length (INV-3)
    if current.observation_window.maxlen != window_length:
        # Re-create deque with correct maxlen, preserving existing entries
        existing = list(current.observation_window)
        current.observation_window = deque(existing, maxlen=window_length)

    # Append to rolling window (INV-3: FIFO — deque evicts oldest when full)
    current.observation_window.append(outcome)

    # Check cumulative drift and emit CompromiseSignal if warranted (INV-4)
    if not current.signal_emitted and SignificantDeviation(
        current,
        baseline=0.0,
        deviation_threshold=deviation_threshold,
        inconclusive_weight=inconclusive_weight,
        min_observations=min_observations,
    ):
        deviant_c, inconclusive_c, window_sz, drift = _compute_drift(
            current.observation_window, inconclusive_weight
        )
        sig = CompromiseSignal(
            node_id=current.node_id,
            triggered_at=time.time(),
            score_at_trigger=current.value,
            drift_summary={
                "deviant_count": deviant_c,
                "inconclusive_count": inconclusive_c,
                "window_size": window_sz,
                "drift_score": drift,
                "threshold": deviation_threshold,
            },
        )
        current.signal_emitted = True  # INV-4: exactly once per breach
        if signal_callback is not None:
            signal_callback(sig)

    return current


def DecayScore(
    current: TrustScore,
    elapsed: float,
    re_confirmation_interval: float = RE_CONFIRMATION_INTERVAL,
    floor_without_reconfirmation: float = FLOOR_WITHOUT_RECONFIRMATION,
    decay_rate: float = DECAY_RATE,
) -> TrustScore:
    """
    Apply time-based trust decay (spec §DecayScore, FR9).

    Rules:
    - MUST NOT reduce score before re_confirmation_interval has elapsed
      (INV-2 — early decay is non-conformant).
    - After the interval elapses, reduces score by decay_rate per elapsed
      interval multiple.
    - Score MUST NOT decay below floor_without_reconfirmation.
    - Score MUST NOT exceed current value post-decay (monotone — FR9).

    CT-FR9: After interval elapses with no CONFORMANT, score decreases.

    Args:
        current:                     The TrustScore to decay.
        elapsed:                     Seconds since last_confirmed_at
                                     (caller computes this).
        re_confirmation_interval:    Interval before decay begins (param).
        floor_without_reconfirmation:Minimum score from decay alone (param).
        decay_rate:                  Reduction per interval period (param).
    Returns:
        The updated TrustScore (same object, mutated in-place).
    """
    if elapsed <= re_confirmation_interval:
        # INV-2: no decay before interval elapses
        return current

    # How many full intervals past re_confirmation_interval?
    periods_past = (elapsed - re_confirmation_interval) / re_confirmation_interval
    decay_amount = decay_rate * periods_past
    decayed = current.value - decay_amount
    current.value = _clamp(max(floor_without_reconfirmation, decayed))
    return current


def SignificantDeviation(
    score: TrustScore,
    baseline: float,
    deviation_threshold: float = DEVIATION_THRESHOLD,
    inconclusive_weight: float = INCONCLUSIVE_DRIFT_WEIGHT,
    min_observations: int = MIN_OBSERVATIONS_BEFORE_VALID,
) -> bool:
    """
    Return True when cumulative drift exceeds the threshold (FR31).

    The drift score is:
        (deviant_count + INCONCLUSIVE_DRIFT_WEIGHT * inconclusive_count)
        / window_size

    Returns False if the window contains fewer than min_observations
    entries (window not yet valid — prevents false triggers on sparse
    early history per spec §Cumulative Drift Model).

    CT-FR31b: window with deviant fraction >= threshold and at least
    min_observations → True.

    Args:
        score:               The TrustScore whose window to evaluate.
        baseline:            Not used in current implementation (reserved for
                             future EWMA variant; kept for interface stability).
        deviation_threshold: Drift fraction triggering True (deployment param).
        inconclusive_weight: INCONCLUSIVE weight in drift formula (param).
        min_observations:    Min window entries before evaluation is valid.
    Returns:
        True if cumulative drift >= deviation_threshold and window is valid.
    """
    window = score.observation_window
    if len(window) < min_observations:
        # Window not yet valid — suppress to avoid false positives (spec §Drift Model)
        return False

    _, _, _, drift_score = _compute_drift(window, inconclusive_weight)
    return drift_score >= deviation_threshold


# ---------------------------------------------------------------------------
# Score registry — per-node score management
# ---------------------------------------------------------------------------

class TrustScoreRegistry:
    """
    Module-level registry mapping verified node IDs to their TrustScore.

    INV-5: Records are only created for verified sender identities — callers
    MUST NOT pass the UNTRUSTED sentinel (None) from S2a's VerifyProvenance.
    Passing None raises ValueError.

    Usage:
        registry = TrustScoreRegistry()
        score = registry.get_or_create("node-42")
        UpdateScore(score, ConformanceResult.DEVIANT, ...)
        registry.apply_decay("node-42", elapsed=7200.0)
    """

    def __init__(
        self,
        starting_score: float = STARTING_SCORE,
        window_length: int = OBSERVATION_WINDOW_LENGTH,
        signal_callbacks: Optional[List[Callable[[CompromiseSignal], None]]] = None,
    ) -> None:
        self._scores: Dict[str, TrustScore] = {}
        self._starting_score = starting_score
        self._window_length = window_length
        self._signal_callbacks: List[Callable[[CompromiseSignal], None]] = (
            signal_callbacks or []
        )

    def _emit_signal(self, sig: CompromiseSignal) -> None:
        for cb in self._signal_callbacks:
            cb(sig)

    def get_or_create(self, node_id: str) -> TrustScore:
        """
        Return the existing TrustScore for node_id or create a new one.

        INV-5: node_id MUST be a verified identity from S2a. Passing None
        is non-conformant and raises ValueError.

        New nodes are initialized at STARTING_SCORE (C-3 — documented).
        """
        if node_id is None:
            raise ValueError(
                "TrustScoreRegistry.get_or_create received None node_id. "
                "Callers MUST handle UNTRUSTED sentinel from S2a before "
                "calling this method (INV-5: no floating score records)."
            )
        if node_id not in self._scores:
            self._scores[node_id] = TrustScore(
                value=self._starting_score,
                node_id=node_id,
                last_confirmed_at=time.time(),
                observation_window=deque(maxlen=self._window_length),
                signal_emitted=False,
            )
        return self._scores[node_id]

    def observe(
        self,
        node_id: str,
        outcome: ConformanceResult,
        **update_kwargs,
    ) -> TrustScore:
        """
        Record one observation for node_id and update its score.

        INV-5: node_id MUST be a verified identity (not None).
        INV-4: CompromiseSignal emitted at most once per breach cycle.
        """
        score = self.get_or_create(node_id)
        return UpdateScore(
            score,
            outcome,
            signal_callback=self._emit_signal,
            **update_kwargs,
        )

    def apply_decay(self, node_id: str, elapsed: float, **decay_kwargs) -> TrustScore:
        """Apply time-based decay to node_id's trust score."""
        score = self.get_or_create(node_id)
        return DecayScore(score, elapsed, **decay_kwargs)

    def reset_signal(self, node_id: str) -> None:
        """
        Reset the CompromiseSignal guard for node_id.

        Call this after S5d completes remediation and the node is considered
        re-initialized. Allows a fresh CompromiseSignal on next breach
        (INV-4 — new breach after reset is valid).
        """
        score = self._scores.get(node_id)
        if score is not None:
            score.signal_emitted = False

    def get_score(self, node_id: str) -> Optional[TrustScore]:
        """Return the current TrustScore for node_id, or None if absent."""
        return self._scores.get(node_id)

    def all_scores(self) -> Dict[str, TrustScore]:
        """Return a snapshot view of all current scores."""
        return dict(self._scores)


# Module-level default registry. Deployment code populates and uses this.
_default_registry: TrustScoreRegistry = TrustScoreRegistry()


def observe(node_id: str, outcome: ConformanceResult, **kwargs) -> TrustScore:
    """Convenience: record an observation in the module-level registry."""
    return _default_registry.observe(node_id, outcome, **kwargs)


def apply_decay(node_id: str, elapsed: float, **kwargs) -> TrustScore:
    """Convenience: apply decay in the module-level registry."""
    return _default_registry.apply_decay(node_id, elapsed, **kwargs)


def register_signal_callback(cb: Callable[[CompromiseSignal], None]) -> None:
    """Register a callback to receive CompromiseSignals globally."""
    _default_registry._signal_callbacks.append(cb)
