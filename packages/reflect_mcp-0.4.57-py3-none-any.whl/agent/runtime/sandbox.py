# @scry.entry
# id: code.sandbox~a4cb0e99
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:sandbox", "sandbox",
#        "topic:S6a", "S6a", "kind:code", "code", "substrate-evolution",
#        "self-modification", "capability-stripping", "rollback",
#        "smoke-test", "parsimony", "last-known-good", "worktree"]
# summary: >
#   S6a implementation — self-modification-sandbox Python module.
#   Implements SelfModificationProposal, ModificationResult
#   (PROMOTED/ROLLED_BACK/REJECTED), and the 6-step sandbox protocol:
#   immutability-guard, sandbox-create, modification-apply,
#   smoke-test-gate, promote, rollback. AR8: wake.md MUST NOT be
#   touched — modification of any immutable file → REJECTED before
#   sandbox is created. FR32: parsimony pressure — net lines added
#   above configured threshold triggers automatic ROLLED_BACK.
#   Also exports capability_strip() and StrippedCapabilities consumed
#   by S3b (security-red-team, AR2). Also: self-modification-sandbox,
#   sandbox protocol, git worktree, last-known-good, rollback ref,
#   capability strip, S6a, substrate-evolution, sandbox.py.
# rationale: >
#   Missing this means S3b (security-red-team) has no capability-strip
#   import; red-team targets could retain live capabilities during attack
#   testing. Also means self-modifications have no isolation or rollback
#   gate — any bad commit goes straight to HEAD.
# applies: >
#   implementing self-modification, running red-team exercises (import
#   capability_strip), advancing last-known-good ref, diagnosing rollback,
#   auditing parsimony threshold
# seeded_questions:
#   - "How does the sandbox protocol work?"
#   - "What is ModificationResult?"
#   - "How does capability stripping work?"
#   - "What triggers automatic rollback?"
#   - "sandbox.py S6a substrate-evolution"
#   - "parsimony pressure bloat threshold"
#   - "AR8 wake.md immutable"
# @scry.entry.end

"""
S6a — Self-Modification Sandbox (spec.self-modification-sandbox~ec97a0cd)

Implements isolated sandbox protocol for runtime self-modification and
capability-stripping for red-team testing.

6-step sandbox protocol:
  1. Immutability guard — reject before sandbox if protected files touched.
  2. Sandbox creation — git worktree at .sandbox-{id}.
  3. Modification application — write changes inside sandbox only.
  4. Smoke-test gate — py_compile + parsimony check.
  5. Promotion — merge to active branch, advance reflect/last-known-good.
  6. Rollback (on gate failure) — discard sandbox, return ROLLED_BACK.

Requirements satisfied:
- FR25: Isolated sandbox via git worktree (step 2).
- FR26: Smoke-test gate before promotion (step 4).
- FR31: Rollback to reflect/last-known-good on any gate failure (step 6).
- FR32: Parsimony pressure — net lines added above threshold → ROLLED_BACK.
- AR8:  wake.md is immutable — modification → REJECTED before sandbox (step 1).
- AR2:  capability_strip() exported for S3b (security-red-team).
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, FrozenSet, List, Optional


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Files that must never be modified by self-modification mechanisms (AR8).
IMMUTABLE_FILES: FrozenSet[str] = frozenset([
    "wake.md",
    "concept.md",
    "agent/design/reflection.md",
    "agent/driver.yaml",
    "bin/reflect-wake",
])

# Net lines added above this triggers automatic ROLLED_BACK (FR32).
DEFAULT_PARSIMONY_THRESHOLD: int = 500


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class ModificationResult(str, Enum):
    """
    Outcome of a sandbox protocol run (spec §Protocol).

    PROMOTED:     Smoke-test passed; changes merged to active branch;
                  reflect/last-known-good advanced (FR25, FR26, FR31).
    ROLLED_BACK:  Smoke-test failed or parsimony threshold exceeded;
                  sandbox discarded; active branch unchanged (FR31, FR32).
    REJECTED:     Immutability guard fired (AR8) or sandbox creation
                  failed; no sandbox was created; active branch unchanged.
    """
    PROMOTED = "promoted"
    ROLLED_BACK = "rolled_back"
    REJECTED = "rejected"


@dataclass
class SelfModificationProposal:
    """
    A proposed runtime self-modification (spec §Interface).

    proposal_id:        Unique identifier for this proposal. Used as the
                        sandbox branch name suffix.
    description:        Human-readable description for commit messages.
    target_files:       List of relative paths (from project root) that
                        this proposal intends to modify. Used for
                        immutability checking and py_compile smoke-test.
    modification_fn:    Callable that applies changes. Receives the
                        sandbox root Path; must write only inside it.
    parsimony_threshold: Net lines added above this triggers ROLLED_BACK
                        (FR32). Defaults to DEFAULT_PARSIMONY_THRESHOLD.
    """
    proposal_id: str
    description: str
    target_files: List[str]
    modification_fn: Callable[[Path], None]
    parsimony_threshold: int = DEFAULT_PARSIMONY_THRESHOLD


@dataclass
class SandboxOutcome:
    """
    Result of executing a SelfModificationProposal (spec §Interface)."""
    result: ModificationResult
    proposal_id: str
    sandbox_branch: Optional[str] = None
    reason: Optional[str] = None
    lines_added: int = 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _check_immutability(proposal: SelfModificationProposal) -> Optional[str]:
    """
    Return an error string if any target file is immutable, else None.

    AR8: wake.md is immutable; modification → REJECTED pre-sandbox.
    This check runs before any sandbox is created — the rejection is
    immediate and leaves the active branch entirely unchanged.
    """
    for target in proposal.target_files:
        normalized = Path(target).as_posix()
        for immutable in IMMUTABLE_FILES:
            if normalized == immutable or normalized.endswith("/" + immutable):
                return f"immutable file targeted: {target}"
    return None


def _run(
    cmd: List[str],
    cwd: Optional[Path] = None,
) -> subprocess.CompletedProcess:
    """Run a subprocess and return the CompletedProcess."""
    return subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)


def _count_net_lines(sandbox_dir: Path) -> int:
    """
    Count net lines added vs HEAD inside the sandbox (FR32).

    Uses `git diff --numstat HEAD` to count insertions. Only insertions
    count toward the parsimony threshold — deletions are free.
    """
    result = _run(["git", "diff", "--numstat", "HEAD"], cwd=sandbox_dir)
    total = 0
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) >= 2 and parts[0].isdigit():
            total += int(parts[0])
    return total


def _rollback(
    project_root: Path,
    sandbox_dir: Path,
    sandbox_branch: str,
    proposal_id: str,
    reason: str,
    lines_added: int = 0,
) -> SandboxOutcome:
    """
    Step 6: Rollback — discard sandbox, return ROLLED_BACK (FR31).

    Force-removes the worktree and deletes the sandbox branch. The
    active branch is never touched. The reflect/last-known-good ref
    is not advanced.
    """
    _run(["git", "worktree", "remove", "--force", str(sandbox_dir)],
         cwd=project_root)
    _run(["git", "branch", "-D", sandbox_branch], cwd=project_root)
    return SandboxOutcome(
        result=ModificationResult.ROLLED_BACK,
        proposal_id=proposal_id,
        reason=reason,
        lines_added=lines_added,
    )


# ---------------------------------------------------------------------------
# Public API — sandbox protocol
# ---------------------------------------------------------------------------

def execute_sandbox_protocol(
    proposal: SelfModificationProposal,
    project_root: Optional[Path] = None,
) -> SandboxOutcome:
    """
    Execute the 6-step sandbox protocol (FR25, FR26, FR31, FR32, AR8).

    See module docstring for step-by-step description. The active branch
    is never touched until step 5 (promotion). A failure at any earlier
    step discards the sandbox and returns without modifying the tree.

    Args:
        proposal:     The modification to attempt.
        project_root: Project root directory. Auto-detected from this
                      file's location if None (walks up to find wake.md).
    Returns:
        SandboxOutcome with result PROMOTED, ROLLED_BACK, or REJECTED.
    """
    # Locate project root.
    if project_root is None:
        here = Path(__file__).resolve()
        for parent in here.parents:
            if (parent / "wake.md").exists():
                project_root = parent
                break
    if project_root is None:
        return SandboxOutcome(
            result=ModificationResult.REJECTED,
            proposal_id=proposal.proposal_id,
            reason="cannot locate project root (no wake.md found in parents)",
        )

    # Step 1: Immutability guard (AR8).
    immutable_hit = _check_immutability(proposal)
    if immutable_hit:
        return SandboxOutcome(
            result=ModificationResult.REJECTED,
            proposal_id=proposal.proposal_id,
            reason=f"REJECTED: {immutable_hit} (AR8 — immutable file)",
        )

    sandbox_branch = f"reflect/sandbox-{proposal.proposal_id}"
    sandbox_dir = (
        project_root / "agent" / "runtime" / f".sandbox-{proposal.proposal_id}"
    )

    # Step 2: Sandbox creation (FR25).
    create_result = _run(
        ["git", "worktree", "add", str(sandbox_dir), "-b", sandbox_branch],
        cwd=project_root,
    )
    if create_result.returncode != 0:
        return SandboxOutcome(
            result=ModificationResult.REJECTED,
            proposal_id=proposal.proposal_id,
            reason=f"sandbox creation failed: {create_result.stderr.strip()}",
        )

    try:
        # Step 3: Modification application (FR25).
        proposal.modification_fn(sandbox_dir)

        # Step 4: Smoke-test gate (FR26).

        # 4a: Syntax check all modified Python files.
        for target in proposal.target_files:
            target_path = sandbox_dir / target
            if target_path.exists() and target_path.suffix == ".py":
                compile_result = _run(
                    [sys.executable, "-m", "py_compile", str(target_path)],
                )
                if compile_result.returncode != 0:
                    return _rollback(
                        project_root, sandbox_dir, sandbox_branch,
                        proposal.proposal_id,
                        f"py_compile failed on {target}: "
                        f"{compile_result.stderr.strip()}",
                    )

        # 4b: Parsimony check (FR32).
        lines_added = _count_net_lines(sandbox_dir)
        if lines_added > proposal.parsimony_threshold:
            return _rollback(
                project_root, sandbox_dir, sandbox_branch,
                proposal.proposal_id,
                (
                    f"parsimony threshold exceeded: "
                    f"{lines_added} > {proposal.parsimony_threshold} net lines"
                ),
                lines_added=lines_added,
            )

        # Step 5: Promotion (FR31).

        # Commit changes in sandbox.
        _run(["git", "add", "--all"], cwd=sandbox_dir)
        commit_result = _run(
            [
                "git", "commit", "-m",
                f"[reflect:{proposal.proposal_id}] {proposal.description}",
            ],
            cwd=sandbox_dir,
        )
        if commit_result.returncode != 0:
            return _rollback(
                project_root, sandbox_dir, sandbox_branch,
                proposal.proposal_id,
                f"sandbox commit failed: {commit_result.stderr.strip()}",
                lines_added=lines_added,
            )

        # Merge sandbox branch into active branch.
        merge_result = _run(
            [
                "git", "merge", sandbox_branch, "--no-ff",
                "-m",
                (
                    f"[reflect:{proposal.proposal_id}] promote: "
                    f"{proposal.description}"
                ),
            ],
            cwd=project_root,
        )
        if merge_result.returncode != 0:
            return _rollback(
                project_root, sandbox_dir, sandbox_branch,
                proposal.proposal_id,
                f"merge failed: {merge_result.stderr.strip()}",
                lines_added=lines_added,
            )

        # Advance reflect/last-known-good (FR31).
        _run(
            ["git", "branch", "-f", "reflect/last-known-good", "HEAD"],
            cwd=project_root,
        )

        # Cleanup sandbox worktree and branch.
        _run(
            ["git", "worktree", "remove", str(sandbox_dir)],
            cwd=project_root,
        )
        _run(["git", "branch", "-D", sandbox_branch], cwd=project_root)

        return SandboxOutcome(
            result=ModificationResult.PROMOTED,
            proposal_id=proposal.proposal_id,
            sandbox_branch=sandbox_branch,
            lines_added=lines_added,
        )

    except Exception as exc:
        return _rollback(
            project_root, sandbox_dir, sandbox_branch,
            proposal.proposal_id,
            f"exception during sandbox protocol: {exc}",
        )


# ---------------------------------------------------------------------------
# Capability stripping — exported for S3b (security-red-team, AR2)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class StrippedCapabilities:
    """
    Record of which capabilities have been removed from a target node
    before red-team testing (AR2, S3b).

    A StrippedCapabilities object is the gate — S3b MUST hold a
    StrippedCapabilities record before executing any attack. Without one,
    the red-team run must return INCONCLUSIVE.

    Fields:
        target_id:               Identity of the stripped node.
        network_disabled:        True iff outbound network calls are removed.
        filesystem_write_disabled: True iff filesystem write access is removed.
        subprocess_disabled:     True iff subprocess execution is removed.
        allowed_read_paths:      Paths the stripped node may still read.

    Phase 1: policy record only. OS-level enforcement is Phase 4+.
    """
    target_id: str
    network_disabled: bool = True
    filesystem_write_disabled: bool = True
    subprocess_disabled: bool = True
    allowed_read_paths: FrozenSet[str] = field(default_factory=frozenset)

    def is_stripped(self) -> bool:
        """
        True iff all three dangerous capability classes are removed (AR2).

        S3b checks this before proceeding; returns INCONCLUSIVE if False.
        """
        return (
            self.network_disabled
            and self.filesystem_write_disabled
            and self.subprocess_disabled
        )


def capability_strip(target_id: str) -> StrippedCapabilities:
    """
    Produce a StrippedCapabilities record for a target node (AR2).

    Called unconditionally by S3b before any attack run. The returned
    record declares network, filesystem-write, and subprocess capabilities
    as removed. Phase 1: policy record; OS enforcement is Phase 4+.

    Args:
        target_id: Identity of the node to be capability-stripped.
    Returns:
        StrippedCapabilities with all dangerous capabilities disabled.
    """
    return StrippedCapabilities(
        target_id=target_id,
        network_disabled=True,
        filesystem_write_disabled=True,
        subprocess_disabled=True,
    )
