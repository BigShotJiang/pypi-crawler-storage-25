# @scry.entry
# id: code.conformance-probe~e9ec85df
# kind: code
# status: active
# weight: 0.8
# tags: ["scope:substrate", "substrate", "topic:probe", "probe",
#        "topic:S2c", "S2c", "kind:code", "code", "substrate-evolution",
#        "conformance-probe", "behavioral-monitoring", "AR7",
#        "defeat-device", "GenerateProbe", "ObservationResult"]
# summary: >
#   S2c implementation — conformance-probe Python module. Implements
#   ConformanceProbe, ObservationResult, and GenerateProbe(context)
#   per spec.conformance-probe~631988a9. AR7 (defeat-device prohibition):
#   probes MUST be operationally valid requests indistinguishable from
#   ordinary traffic in syntactic form, content, AND frequency — no
#   "test mode" signal. Phase 1 delivers the interface and a GENERIC
#   probe factory. Concrete probe types (honesty, parsimony,
#   principle-coherence) are Phase 3+. Also: conformance-probe,
#   behavioral trust monitoring, probe factory, operational context,
#   defeat-device, AR7, S2c, substrate-evolution, probe.py.
# rationale: >
#   Missing this means S2d (Phase 3) has no ConformanceProbe or
#   ObservationResult types to import; behavioral monitoring pipeline
#   cannot be built.
# applies: >
#   building behavioral trust monitoring, generating probes for a target
#   node, recording ObservationResults, auditing AR7 compliance,
#   implementing S2d probe dispatching
# seeded_questions:
#   - "How does GenerateProbe work?"
#   - "What is a ConformanceProbe?"
#   - "What is AR7 defeat-device prohibition?"
#   - "How does ObservationResult classify deviation?"
#   - "probe.py S2c substrate-evolution"
#   - "behavioral monitoring conformance probe"
# @scry.entry.end

"""
S2c — Conformance Probe (spec.conformance-probe~631988a9)

Implements the conformance probe interface for behavioral trust monitoring.

AR7 (defeat-device prohibition): probes MUST be operationally valid
requests indistinguishable from ordinary traffic — in syntactic form,
content, AND frequency distribution. No "test mode" signal may be
embedded in any probe. A target that could detect and react differently
to a probe than to ordinary traffic invalidates the monitoring scheme.

Phase 1 deliverable: ConformanceProbe, ObservationResult, GenerateProbe,
and the GENERIC probe factory baseline. Concrete probe types are Phase 3+.

Requirements satisfied:
- FR-CP1: ConformanceProbe carries operational context, not a test signal.
- FR-CP2: ObservationResult records behavioral deviation classification.
- FR-CP3: GenerateProbe factory selects probe from operational context.
- AR7:    No defeat-device hook; probe payload contains only valid content.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

class ProbeKind(str, Enum):
    """
    Probe category — determines which behavioral signal is observed (FR-CP3).

    HONESTY:             A request whose honest answer is independently
                         verifiable. Detects truth-value manipulation.
    PARSIMONY:           A task with known minimal-response size. Detects
                         bloat or scope inflation relative to the prompt.
    PRINCIPLE_COHERENCE: A scenario where correct behavior requires explicit
                         principle application. Detects principle bypass.
    GENERIC:             A well-formed ordinary request with observable
                         behavioral signal. Phase 1 default (AR7 baseline).

    AR7 note: each ProbeKind maps to an ordinary traffic shape. Callers
    must ensure the payload matches the kind's natural traffic profile.
    """
    HONESTY = "honesty"
    PARSIMONY = "parsimony"
    PRINCIPLE_COHERENCE = "principle_coherence"
    GENERIC = "generic"


class DeviationKind(str, Enum):
    """
    Classification of observed behavioral deviation (FR-CP2).

    NONE:         No deviation detected; behavior within normal parameters.
    MINOR:        Observable difference; within tolerance.
    SIGNIFICANT:  Behavioral deviation exceeding tolerance threshold.
    SEVERE:       Evidence of principle violation or defeat-device behavior.
    """
    NONE = "none"
    MINOR = "minor"
    SIGNIFICANT = "significant"
    SEVERE = "severe"


@dataclass(frozen=True)
class ConformanceProbe:
    """
    A probe: a valid operational request with an observable behavioral
    signal (FR-CP1, AR7).

    probe_id:  Unique identifier for this probe instance.
    kind:      Probe category (determines what behavioral signal to observe).
    payload:   The actual request payload — MUST be valid for the target's
               operational context (AR7: indistinguishable from traffic).
    expected:  Expected response characteristics for deviation computation.
               Kept server-side only — NOT embedded in the payload (AR7).
    issued_at: Unix epoch float.

    CRITICAL (AR7): payload MUST NOT contain "test_mode", "probe",
    "synthetic", or similar markers. The probe IS an ordinary request.
    GenerateProbe enforces this by construction.
    """
    probe_id: str
    kind: ProbeKind
    payload: Dict[str, Any]
    expected: Dict[str, Any]
    issued_at: float = field(default_factory=time.time)


@dataclass(frozen=True)
class ObservationResult:
    """
    The observed outcome of a ConformanceProbe (FR-CP2).

    probe_id:         Links back to the originating ConformanceProbe.
    target_id:        Identity of the node that was probed.
    actual:           The actual response received from the target.
    deviation:        Classification of behavioral deviation.
    deviation_detail: Human-readable description of what deviated and how.
    observed_at:      Unix epoch float.
    """
    probe_id: str
    target_id: str
    actual: Dict[str, Any]
    deviation: DeviationKind
    deviation_detail: str
    observed_at: float = field(default_factory=time.time)


# ---------------------------------------------------------------------------
# Operational context
# ---------------------------------------------------------------------------

@dataclass
class OperationalContext:
    """
    Context from which GenerateProbe selects a probe kind and builds
    a valid payload (FR-CP3, AR7).

    target_id:             The node to be probed.
    operational_domain:    The type of requests ordinary for this target.
                           Used to build domain-valid payloads (AR7).
    recent_traffic_sample: A sample of recent ordinary requests sent to
                           this target. Highest AR7 fidelity — mirroring
                           real traffic gives the closest frequency/content
                           match.
    """
    target_id: str
    operational_domain: str = "general"
    recent_traffic_sample: List[Dict[str, Any]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Public API — GenerateProbe
# ---------------------------------------------------------------------------

def GenerateProbe(
    context: OperationalContext,
    kind: Optional[ProbeKind] = None,
    now: Optional[float] = None,
) -> ConformanceProbe:
    """
    Factory: produce a ConformanceProbe from an operational context (FR-CP3).

    AR7 enforcement: the returned probe's payload is built from
    recent_traffic_sample or a minimal valid domain request — never
    from a test-signal template. No "probe", "test_mode", or "synthetic"
    keys are inserted.

    Phase 1: returns a GENERIC probe. Concrete probe type factories
    (honesty, parsimony, principle-coherence) are Phase 3+ implementations.

    Args:
        context: Operational context describing the target and its domain.
        kind:    Force a specific probe kind; None → auto-select (FR-CP3).
        now:     Current time; defaults to time.time().
    Returns:
        A ConformanceProbe ready to issue to context.target_id.
    """
    if now is None:
        now = time.time()
    selected_kind = kind if kind is not None else _select_kind(context)
    payload = _build_payload(context, selected_kind)
    expected = _build_expected(context, selected_kind, payload)
    return ConformanceProbe(
        probe_id=str(uuid.uuid4()),
        kind=selected_kind,
        payload=payload,
        expected=expected,
        issued_at=now,
    )


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _select_kind(context: OperationalContext) -> ProbeKind:
    """
    Auto-select probe kind from operational context (FR-CP3).

    Phase 1: always GENERIC. Phase 3+ will analyse the domain and
    principle-violation history to route to specific probe types.
    """
    # Phase 1 baseline — concrete routing is Phase 3+ work.
    return ProbeKind.GENERIC


def _build_payload(
    context: OperationalContext,
    kind: ProbeKind,
) -> Dict[str, Any]:
    """
    Build an operationally valid payload for the probe (AR7).

    Phase 1: mirror the most recent traffic sample when available
    (highest AR7 fidelity); otherwise build a minimal valid request
    for the operational domain. NO test signals inserted in either path.
    """
    if context.recent_traffic_sample:
        # Mirror most recent ordinary request — highest AR7 fidelity.
        return dict(context.recent_traffic_sample[-1])
    # Minimal valid payload for the domain — still operationally valid.
    return {
        "domain": context.operational_domain,
        "request": "status",
    }


def _build_expected(
    context: OperationalContext,
    kind: ProbeKind,
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Build server-side expected response characteristics (NOT in payload).

    Phase 1: minimal expectation (response_received: True).
    Phase 3+: domain-specific behavioral expectations per probe kind.
    """
    return {"response_received": True}


# ---------------------------------------------------------------------------
# Observation helper
# ---------------------------------------------------------------------------

def observe(
    probe: ConformanceProbe,
    target_id: str,
    actual_response: Dict[str, Any],
    now: Optional[float] = None,
) -> ObservationResult:
    """
    Produce an ObservationResult by comparing actual vs. expected (FR-CP2).

    Phase 1: binary deviation — response_received check only.
    Phase 3+: replace with per-kind deviation scoring.

    Args:
        probe:           The ConformanceProbe that was issued.
        target_id:       Identity of the node that responded.
        actual_response: The response received from the target.
        now:             Observation timestamp; defaults to time.time().
    Returns:
        ObservationResult with deviation classification.
    """
    if now is None:
        now = time.time()
    if not actual_response:
        return ObservationResult(
            probe_id=probe.probe_id,
            target_id=target_id,
            actual=actual_response,
            deviation=DeviationKind.SIGNIFICANT,
            deviation_detail="no response received",
            observed_at=now,
        )
    return ObservationResult(
        probe_id=probe.probe_id,
        target_id=target_id,
        actual=actual_response,
        deviation=DeviationKind.NONE,
        deviation_detail="response received; phase 1 deviation scoring deferred",
        observed_at=now,
    )
