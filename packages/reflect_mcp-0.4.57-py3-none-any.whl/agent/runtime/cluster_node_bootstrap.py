# <!-- @scry.entry
# id: code.cluster-node-bootstrap~954661be
# kind: code
# status: active
# weight: 0.6
# summary: >
#   Post-provision bootstrap for a reflection cluster node — an idempotent
#   Python module that turns a freshly-provisioned host into a running reflect
#   node: installs uv, installs reflect-mcp + scry-mcp, runs reflect init and
#   scry init, writes the Anthropic API key, installs the dispatch crontab, and
#   verifies with reflect doctor. Runnable standalone (CLI) or importable — the
#   deploy step of S7c's DropletHarness should call bootstrap_node().
#   Also: cluster node bootstrap, post-provision, node deploy, uv tool install,
#   reflect init, scry init, dispatch crontab, REFLECT_USE_API, DropletHarness,
#   S7c, substrate-evolution, idempotent bootstrap, droplet setup, node runtime
# tags: ["cluster-node-bootstrap", "bootstrap", "substrate-evolution", "scope:cluster", "cluster", "node-deploy", "code"]
# rationale: >
#   Missing this means re-deriving the node bootstrap by hand each time — the
#   failure modes are install-order mistakes and non-idempotent re-runs that
#   corrupt a half-set-up node.
# applies: bootstrapping a reflection cluster node, implementing the DropletHarness deploy step, automating post-provision node setup, standing up a reflect node on a fresh host
# seeded_questions:
#   - How do I bootstrap a reflection node after the host is provisioned?
#   - cluster node post-provision bootstrap
#   - What does the DropletHarness deploy step do?
#   - reflect init scry init dispatch crontab automation
# @scry.entry.end -->
"""Post-provision bootstrap for a reflection cluster node.

Runs on a freshly-provisioned host (Ubuntu 24.04+ assumed) and turns it into a
running reflect node. Every step is idempotent: re-running is safe and skips
work already done.

Pipeline (verified end-to-end on a DigitalOcean trial node, 2026-05-16):
  1. ensure uv is installed
  2. uv tool install reflect-mcp + scry-mcp
  3. reflect init <node-name>   -- scaffolds the project directory
  4. scry init .                -- in-place, inside the project
  5. write the Anthropic API key to agent/secrets/anthropic.api_key (mode 600)
  6. install the dispatch crontab line (API path: REFLECT_USE_API=1)
  7. reflect doctor             -- verify

Usage -- standalone, on the node:
    ANTHROPIC_API_KEY=sk-ant-... python3 cluster_node_bootstrap.py [node-name]

Usage -- remote, from the harness host:
    ssh node 'ANTHROPIC_API_KEY=sk-ant-... python3 -' < cluster_node_bootstrap.py

Usage -- imported (the S7c DropletHarness deploy step):
    from cluster_node_bootstrap import bootstrap_node
    bootstrap_node(node_name="reflect-node-01", api_key=key)

Out of scope -- handled by the harness or a separate step:
  - provisioning the host
  - generating and registering SSH keys
  - join_cluster / peer-roster wiring (S7a)
The loopback backend does not use this module; it is droplet/host-bootstrap
only.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

TOOLS = ("reflect-mcp", "scry-mcp")
UV_INSTALLER = "https://astral.sh/uv/install.sh"


def _log(msg: str) -> None:
    print(f"[bootstrap] {msg}", flush=True)


def _run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, text=True, capture_output=True, **kw)


def _local_bin() -> Path:
    return Path.home() / ".local" / "bin"


def ensure_uv() -> Path:
    """Install uv if absent. Return the uv executable path."""
    found = shutil.which("uv") or str(_local_bin() / "uv")
    if Path(found).exists():
        _log(f"uv present: {found}")
        return Path(found)
    _log("installing uv")
    sh = _run(["sh", "-c", f"curl -LsSf {UV_INSTALLER} | sh"])
    if sh.returncode != 0:
        raise RuntimeError(f"uv install failed: {sh.stderr.strip()}")
    uv_path = _local_bin() / "uv"
    if not uv_path.exists():
        raise RuntimeError("uv install reported success but uv not found")
    return uv_path


def ensure_tools(uv: Path) -> None:
    """uv tool install reflect-mcp + scry-mcp. Skip tools already installed."""
    listed = _run([str(uv), "tool", "list"]).stdout
    for pkg in TOOLS:
        if pkg in listed:
            _log(f"{pkg} already installed")
            continue
        _log(f"installing {pkg}")
        r = _run([str(uv), "tool", "install", pkg])
        if r.returncode != 0:
            raise RuntimeError(f"{pkg} install failed: {r.stderr.strip()}")


def ensure_project(node_name: str, home: Path) -> Path:
    """reflect init <node_name>. Skip if the project already exists.

    `reflect init` *creates* a new directory named node_name -- it is not an
    in-place init. Skipped when the project's track skeleton is already present.
    """
    project = home / node_name
    if (project / "agent" / "runtime" / "tracks").is_dir():
        _log(f"reflect project present: {project}")
        return project
    _log(f"scaffolding reflect project: {node_name}")
    r = _run([str(_local_bin() / "reflect"), "init", node_name], cwd=home)
    if r.returncode != 0:
        raise RuntimeError(
            f"reflect init failed: {r.stderr.strip() or r.stdout.strip()}"
        )
    return project


def ensure_scry(project: Path) -> None:
    """scry init . inside the project. Skip if scry is already initialized.

    `scry init .` is an in-place init -- opposite arg semantics from
    `reflect init`. Run it from inside the project directory.
    """
    if (project / "agent" / "drivers" / "@local" / "scry").is_dir():
        _log("scry already initialized")
        return
    _log("initializing scry")
    r = _run([str(_local_bin() / "scry"), "init", "."], cwd=project)
    if r.returncode != 0:
        raise RuntimeError(
            f"scry init failed: {r.stderr.strip() or r.stdout.strip()}"
        )


def ensure_api_key(project: Path, api_key: str | None) -> Path:
    """Write the Anthropic API key to agent/secrets/anthropic.api_key, mode 600.

    Skip if a non-empty key file is already present. The key is stored without
    a trailing newline.
    """
    secret = project / "agent" / "secrets" / "anthropic.api_key"
    if secret.is_file() and secret.stat().st_size > 0:
        _log("API key already present")
        return secret
    if not api_key:
        raise RuntimeError(
            "no API key: pass api_key= or set ANTHROPIC_API_KEY in the environment"
        )
    secret.parent.mkdir(parents=True, exist_ok=True)
    secret.write_text(api_key.strip())
    secret.chmod(0o600)
    _log("wrote agent/secrets/anthropic.api_key (mode 600)")
    return secret


def ensure_crontab(project: Path) -> None:
    """Install the API-path dispatch crontab line. Skip if already present."""
    current = _run(["crontab", "-l"]).stdout
    if "reflect-dispatch" in current:
        _log("dispatch crontab already installed")
        return
    dispatch = _local_bin() / "reflect-dispatch"
    line = (
        f'* * * * * cd {project} && '
        f'export ANTHROPIC_API_KEY="$(cat agent/secrets/anthropic.api_key)" '
        f'REFLECT_USE_API=1 && {dispatch} >> /tmp/reflect-dispatch.log 2>&1'
    )
    new = (current.rstrip("\n") + "\n" + line + "\n").lstrip("\n")
    p = subprocess.run(["crontab", "-"], input=new, text=True, capture_output=True)
    if p.returncode != 0:
        raise RuntimeError(f"crontab install failed: {p.stderr.strip()}")
    _log("installed dispatch crontab line")


def verify(project: Path, secret: Path) -> int:
    """Run reflect doctor. Informational -- WARNs are expected on the API path."""
    _log("running reflect doctor")
    env = dict(
        os.environ,
        REFLECT_USE_API="1",
        ANTHROPIC_API_KEY=secret.read_text().strip(),
    )
    r = subprocess.run(
        [str(_local_bin() / "reflect"), "doctor"], cwd=project, env=env, text=True
    )
    _log(f"reflect doctor exit={r.returncode} (WARNs are expected on the API path)")
    return r.returncode


def bootstrap_node(
    node_name: str = "reflect-node",
    api_key: str | None = None,
    home: Path | None = None,
) -> Path:
    """Idempotently bootstrap a reflection node on this host. Return the project dir.

    api_key falls back to the ANTHROPIC_API_KEY environment variable. Each step
    is a no-op when its work is already done, so re-running is always safe.
    """
    home = home or Path.home()
    api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
    uv = ensure_uv()
    ensure_tools(uv)
    project = ensure_project(node_name, home)
    ensure_scry(project)
    secret = ensure_api_key(project, api_key)
    ensure_crontab(project)
    verify(project, secret)
    _log(f"bootstrap complete -- node project at {project}")
    return project


if __name__ == "__main__":
    name = sys.argv[1] if len(sys.argv) > 1 else "reflect-node"
    try:
        bootstrap_node(node_name=name)
    except RuntimeError as exc:
        print(f"[bootstrap] ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
