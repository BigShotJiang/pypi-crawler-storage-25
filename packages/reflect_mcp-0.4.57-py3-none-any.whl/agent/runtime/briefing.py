"""Wake briefing builder.

Synthesizes inbox files, recent reports, recent commits, and heartbeat tail
into a deterministic content list for a synthetic user message, with
cache_control on the final body block for prompt cache stability.

Cache stability rules (FR16):
- No ISO timestamps in the cached body — only in the uncached footer block
- All lists sorted alphabetically or descending-by-name (never by mtime)
- Two calls with identical inputs → byte-for-byte identical cached body

Failure fallback (FR17):
- If build_briefing_content() raises, returns stub body + logs to health.log
"""

import subprocess
from datetime import datetime, timezone
from pathlib import Path

from agent.lib.root import resolve_project_root

PROJECT_ROOT = resolve_project_root()
HEALTH_LOG = PROJECT_ROOT / "agent" / "runtime" / "health.log"
HEARTBEAT_LOG = (
    PROJECT_ROOT / "agent" / "drivers" / "@local" / "scry" / "runtime" / "heartbeat.log"
)
REPORTS_DIR = PROJECT_ROOT / "agent" / "reports"

_2KB = 2048


# ---------------------------------------------------------------------------
# Inbox path resolution (mirrors prompt.py logic)
# ---------------------------------------------------------------------------

def _inbox_base(track: str) -> list[Path]:
    """All from-originator directories for the given track."""
    per_track = PROJECT_ROOT / "agent" / "runtime" / "tracks" / track / "inbox" / "from-originator"
    if track == "main":
        legacy = PROJECT_ROOT / "agent" / "inbox" / "from-originator"
        return [legacy, per_track]
    return [per_track]


def _followup_dirs(track: str) -> list[Path]:
    # P9: followup/ is a sibling of inbox/, not nested inside it.
    # Also check legacy inbox/followup/ for backward compat during migration.
    track_dir = PROJECT_ROOT / "agent" / "runtime" / "tracks" / track
    dirs = [track_dir / "followup"]
    legacy = track_dir / "inbox" / "followup"
    if legacy.is_dir():
        dirs.append(legacy)
    return dirs


def _from_agent_dirs(track: str) -> list[Path]:
    if track == "main":
        return [PROJECT_ROOT / "agent" / "inbox" / "from-agent"]
    return [PROJECT_ROOT / "agent" / "runtime" / "tracks" / track / "inbox" / "from-agent"]


# ---------------------------------------------------------------------------
# Helper: collect unread files from a directory
# ---------------------------------------------------------------------------

def _collect_files(directory: Path, exclude_subdir: str | None = None) -> list[Path]:
    """Return *.md files in `directory`, sorted alphabetically by basename.

    Excludes files inside `exclude_subdir` (e.g. `.consumed`, `.completed`).
    Returns empty list if directory does not exist.
    """
    if not directory.is_dir():
        return []
    excluded: set[str] = set()
    if exclude_subdir:
        excl_dir = directory / exclude_subdir
        if excl_dir.is_dir():
            excluded = {p.name for p in excl_dir.glob("*.md") if p.is_file()}
    return sorted(
        (p for p in directory.glob("*.md") if p.is_file() and p.name not in excluded),
        key=lambda p: p.name,
    )


def _first_nonempty_line(text: str) -> str:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return ""


# ---------------------------------------------------------------------------
# Section builders (all deterministic, no timestamps)
# ---------------------------------------------------------------------------

def _inbox_section(track: str) -> str:
    lines: list[str] = ["## Inbox"]

    def _section(label: str, files: list[Path], verbatim: bool) -> list[str]:
        if not files:
            return [f"\n### {label}\n(empty)"]
        out = [f"\n### {label}"]
        for f in files:
            try:
                size = f.stat().st_size
                hint = ""
                if size < _2KB:
                    text = f.read_text(errors="replace")
                    hint = f" — {_first_nonempty_line(text)!r}"
                out.append(f"- {f.name} ({size}B){hint}")
                if verbatim and size < _2KB:
                    content = f.read_text(errors="replace").strip()
                    out.append(f"\n  **Contents of {f.name}:**\n  ```\n{content}\n  ```")
            except Exception:
                out.append(f"- {f.name} (unreadable)")
        return out

    # from-originator (multiple dirs for main)
    all_originator: list[Path] = []
    for d in _inbox_base(track):
        all_originator.extend(_collect_files(d, exclude_subdir=".consumed"))
    # deduplicate by name (shouldn't overlap, but be safe)
    seen: set[str] = set()
    deduped: list[Path] = []
    for p in sorted(all_originator, key=lambda p: p.name):
        if p.name not in seen:
            seen.add(p.name)
            deduped.append(p)
    lines.extend(_section("from-originator", deduped, verbatim=True))

    # followup
    followup_files: list[Path] = []
    for d in _followup_dirs(track):
        followup_files.extend(_collect_files(d, exclude_subdir=".completed"))
    followup_files.sort(key=lambda p: p.name)
    lines.extend(_section("followup", followup_files, verbatim=True))

    # from-agent (listing only, no verbatim)
    from_agent_files: list[Path] = []
    for d in _from_agent_dirs(track):
        from_agent_files.extend(_collect_files(d))
    from_agent_files.sort(key=lambda p: p.name)
    lines.extend(_section("from-agent (listing only)", from_agent_files, verbatim=False))

    return "\n".join(lines)


def _first_h2(text: str) -> str:
    for line in text.splitlines():
        if line.startswith("## "):
            return line[3:].strip()
    return ""


def _reports_section() -> str:
    if not REPORTS_DIR.is_dir():
        return "## Recent Reports\n(none)"
    reports = sorted(
        (p for p in REPORTS_DIR.iterdir() if p.suffix == ".md" and p.is_file()),
        key=lambda p: p.name,
        reverse=True,
    )[:5]
    if not reports:
        return "## Recent Reports\n(none)"
    lines = ["## Recent Reports"]
    for r in reports:
        try:
            heading = _first_h2(r.read_text(errors="replace"))
        except Exception:
            heading = "(unreadable)"
        lines.append(f"- {r.name}: {heading}")
    return "\n".join(lines)


def _commits_section() -> str:
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", "-10"],
            capture_output=True,
            text=True,
            cwd=str(PROJECT_ROOT),
            timeout=10,
        )
        log = result.stdout.strip() or "(no commits)"
    except Exception as exc:
        log = f"(git log failed: {exc})"
    return f"## Recent Commits\n```\n{log}\n```"


def _pending_questions_section(track: str) -> str | None:
    """Emit a 'Pending Replies' section listing open and expired question records.

    Returns None if the pending-questions/ directory is absent or empty — the
    section is a no-op in the common case (DR4, DR8).
    """
    from datetime import datetime, timezone

    pq_dir = PROJECT_ROOT / "agent" / "runtime" / "tracks" / track / "pending-questions"
    if not pq_dir.is_dir():
        return None

    resolved_dir = pq_dir / ".resolved"
    resolved_names: set[str] = set()
    if resolved_dir.is_dir():
        resolved_names = {p.name for p in resolved_dir.glob("*.yaml") if p.is_file()}

    yaml_files = sorted(
        (p for p in pq_dir.glob("*.yaml")
         if p.is_file() and p.name not in resolved_names and not p.name.startswith(".")),
        key=lambda p: p.name,
    )
    if not yaml_files:
        return None

    try:
        import yaml as _yaml
    except ImportError:
        return None

    now = datetime.now(timezone.utc)
    lines = ["## Pending Replies"]

    for f in yaml_files:
        try:
            rec = _yaml.safe_load(f.read_text()) or {}
        except Exception:
            continue

        rec_id = rec.get("id", f.stem)
        created_at = rec.get("created_at", "?")
        expires_at = rec.get("expires_at", "")
        question = (rec.get("question") or "").strip()
        answer_map = rec.get("answer_map") or {}
        context = rec.get("context") or {}
        blocked_work = context.get("blocked_work", "")

        # Staleness check (DR8)
        expired = False
        if expires_at:
            try:
                exp_dt = datetime.fromisoformat(expires_at.replace("Z", "+00:00"))
                expired = now > exp_dt
            except Exception:
                pass

        if expired:
            lines.append(
                f"\n- {rec_id} [EXPIRED {expires_at}]\n"
                f'  "{question[:120]}"\n'
                f"  → Re-surface this question or escalate."
            )
        else:
            answer_keys = " / ".join(answer_map.keys()) if answer_map else "(none)"
            blocked_note = f'\n  blocked: "{blocked_work}"' if blocked_work else ""
            lines.append(
                f"\n- {rec_id} ({created_at}, expires {expires_at})\n"
                f'  "{question[:120]}"\n'
                f"  answers: {answer_keys}"
                f"{blocked_note}\n"
                f"  → Reply arrives via inbox (kind:reply, subject:{rec_id}) or\n"
                f"    session interrupt. Do not re-derive this decision."
            )

    if len(lines) == 1:
        return None  # Only header, no valid records

    return "\n".join(lines)


def _heartbeat_section() -> str:
    if not HEARTBEAT_LOG.exists():
        return "## Heartbeat (last 10)\n(no log)"
    try:
        lines = HEARTBEAT_LOG.read_text(errors="replace").splitlines()
        tail = lines[-10:] if len(lines) > 10 else lines
        body = "\n".join(tail) if tail else "(empty)"
    except Exception as exc:
        body = f"(read failed: {exc})"
    return f"## Heartbeat (last 10)\n```\n{body}\n```"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_briefing_body(track: str) -> str:
    """Deterministic cached body — no timestamps anywhere inside."""
    sections = [
        "# Wake Briefing",
        _inbox_section(track),
        _reports_section(),
        _commits_section(),
        _heartbeat_section(),
    ]
    pq = _pending_questions_section(track)
    if pq is not None:
        sections.append(pq)
    return "\n\n".join(sections)


def build_briefing_footer() -> str:
    """Uncached footer — contains the current timestamp."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f"_Briefing snapshot taken at {now} — re-read files if staleness matters._"


def _log_health_error(exc: Exception) -> None:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        HEALTH_LOG.parent.mkdir(parents=True, exist_ok=True)
        with HEALTH_LOG.open("a") as fh:
            fh.write(f"{now} [briefing-builder] ERROR: {exc}\n")
    except Exception:
        pass


def build_briefing_content(track: str) -> list[dict]:
    """Return content blocks for the briefing synthetic user message.

    The final body block carries cache_control=ephemeral so the deterministic
    body is cached across wakes. The footer block has no cache_control and
    re-reads fresh each call (it contains the current timestamp).

    FR17: any exception → stub briefing + health.log entry; never propagates.
    """
    try:
        body = build_briefing_body(track)
        footer = build_briefing_footer()
        return [
            {
                "type": "text",
                "text": body,
                "cache_control": {"type": "ephemeral"},
            },
            {
                "type": "text",
                "text": footer,
            },
        ]
    except Exception as exc:
        _log_health_error(exc)
        return [
            {
                "type": "text",
                "text": "# Briefing unavailable — builder error",
                "cache_control": {"type": "ephemeral"},
            }
        ]
