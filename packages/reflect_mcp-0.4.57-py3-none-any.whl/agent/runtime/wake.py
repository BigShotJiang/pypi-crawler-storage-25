"""Reflection's autonomous wake entry point.

Run via `uv run reflect-wake`. Boots one wake — Claude Agent SDK loop bounded by
token/iteration caps, with reflection's identity baseline as the system prompt and
a heartbeat-shaped output contract.

Track support (Phase 1):
    Set REFLECT_TRACK env var to run as a named track (e.g. "creative", "sidequest").
    Defaults to "main". Each track has isolated state files under
    `agent/runtime/tracks/{track}/`. Shared resources (wakes/, wakes.tsv) stay
    at the runtime root and are safe to access concurrently across tracks.
"""
import asyncio
import importlib.util
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from agent.lib.root import resolve_project_root


def _load_shared_env_file() -> None:
    """Load agent/runtime/reflect.env if it exists.

    Provides a project-level credential config file so both cron-dispatched
    wakes and manual `reflect wake start` invocations read from the same
    source of truth. Uses setdefault semantics: any env var already set
    in the process environment (from crontab, shell, or parent process)
    takes precedence and is never overwritten.

    File format: KEY=value lines. Comments (#) and blank lines ignored.
    Quoted values (single or double) are stripped.
    """
    env_file = resolve_project_root() / "agent" / "runtime" / "reflect.env"
    if not env_file.exists():
        return
    try:
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip()
            # Strip optional surrounding quotes
            if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
                val = val[1:-1]
            if key:
                os.environ.setdefault(key, val)
    except Exception:
        pass  # Never crash on env file read; credentials handled below


_load_shared_env_file()

# Credential scheme — three paths:
#
#   proxy (default)  Route through localhost:9000 OAuth proxy. Bills against
#                    the Claude Max subscription. No API key needed.
#
#   api              Use ANTHROPIC_API_KEY from environment directly.
#                    Activate with REFLECT_USE_API=1.
#
#   aws_bedrock      Authenticate via AWS Bedrock (SigV4). The Claude Code
#                    subprocess inherits AWS credential env vars and uses
#                    them for Bedrock auth. Activate with:
#                        REFLECT_CREDENTIAL_SCHEME=aws_bedrock
#                    Optionally pair with:
#                        REFLECT_AWS_PROFILE=<profile>
#                        REFLECT_AWS_REGION=<region>
#                        REFLECT_MODEL=us.anthropic.claude-opus-4-6-v1
#
# All three can be set via agent/runtime/reflect.env so both dispatch
# and manual wake paths read from the same source of truth.

_CREDENTIAL_SCHEME: str = os.environ.get("REFLECT_CREDENTIAL_SCHEME", "")

if _CREDENTIAL_SCHEME == "aws_bedrock":
    # AWS Bedrock path: skip proxy; propagate AWS credential env vars so
    # the Claude Code subprocess can authenticate via SigV4.
    _aws_profile = os.environ.get("REFLECT_AWS_PROFILE", "")
    _aws_region = os.environ.get("REFLECT_AWS_REGION", "us-east-1")
    if _aws_profile:
        os.environ.setdefault("AWS_PROFILE", _aws_profile)
    if _aws_region:
        os.environ.setdefault("AWS_REGION", _aws_region)
        os.environ.setdefault("AWS_DEFAULT_REGION", _aws_region)
    # ANTHROPIC_BASE_URL and ANTHROPIC_API_KEY intentionally not set —
    # Bedrock uses AWS credentials, not an Anthropic API key.
elif not os.environ.get("REFLECT_USE_API"):
    # Proxy path (default): route through local Claude OAuth proxy.
    os.environ.setdefault("ANTHROPIC_BASE_URL", "http://localhost:9000")
    os.environ.setdefault("ANTHROPIC_API_KEY", "dummy")
# else: api path — ANTHROPIC_API_KEY already in env, nothing to do.

from claude_agent_sdk import (
    AssistantMessage,
    ClaudeAgentOptions,
    ClaudeSDKClient,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
    UserMessage,
)

from .briefing import build_briefing_content
from .hooks import can_use_tool
from .prompt import PROJECT_ROOT, build_system_prompt, build_wake_directive
from ..lib.status import mark_running, mark_idle, mark_paused, mark_unhealthy


def _resolve_project_dirs(orchestrator_root: Path) -> list[str]:
    """
    Walk agent/projects/*, return the resolved abspaths of any directory
    symlinks. SDK's add_dirs checks the resolved path against its allowlist,
    not the symlink path — so the symlink itself doesn't grant access.
    Skips dead links, non-symlinks, cycles (target contains orchestrator_root).
    """
    proj_dir = orchestrator_root / "agent" / "projects"
    if not proj_dir.is_dir():
        return []
    orch_real = orchestrator_root.resolve()
    out: list[str] = []
    for entry in sorted(proj_dir.iterdir()):
        if not entry.is_symlink():
            continue
        try:
            target = entry.resolve(strict=True)
        except (FileNotFoundError, OSError):
            continue  # dead link
        if not target.is_dir():
            continue
        # Cycle guard: skip if target is or contains the orchestrator
        if target == orch_real or orch_real.is_relative_to(target):
            continue
        out.append(str(target))
    return out
from .tools import (
    increment_turn,
    reflect_mcp_server,
    reset_sleep_state,
    set_budget_caps,
    sleep_state,
)
from .events import emit_event, set_runtime_root as _events_set_runtime_root


# claude-sonnet-4-6 pricing (USD per token). Update if Anthropic changes prices.
SONNET_46_INPUT = 3.0 / 1_000_000
SONNET_46_OUTPUT = 15.0 / 1_000_000
SONNET_46_CACHE_WRITE = 3.75 / 1_000_000
SONNET_46_CACHE_READ = 0.30 / 1_000_000


def _cost_from_usage(usage) -> float:
    """API-equivalent USD cost from a single AssistantMessage's usage block.

    Computed using Sonnet 4.6 API pricing even when routing through the local
    OAuth proxy (which draws from Max subscription, not API credits). Labeled
    'api_equivalent_usd' in wakes.tsv for transparency."""
    if usage is None:
        return 0.0
    # SDK's usage object — mostly a dict-like or attribute carrier.
    def g(key):
        if isinstance(usage, dict):
            return usage.get(key, 0) or 0
        return getattr(usage, key, 0) or 0
    inp = g("input_tokens")
    out = g("output_tokens")
    cw = g("cache_creation_input_tokens")
    cr = g("cache_read_input_tokens")
    return (
        inp * SONNET_46_INPUT
        + out * SONNET_46_OUTPUT
        + cw * SONNET_46_CACHE_WRITE
        + cr * SONNET_46_CACHE_READ
    )


def _ctx_tokens_from_usage(usage) -> int:
    """Resident context token count from a single AssistantMessage usage block.

    Sums input + cache_creation + cache_read tokens — all three are resident
    in the active context window. Output tokens are not counted (they come after
    the window, not inside it)."""
    if usage is None:
        return 0
    def g(key):
        if isinstance(usage, dict):
            return usage.get(key, 0) or 0
        return getattr(usage, key, 0) or 0
    return (
        g("input_tokens")
        + g("cache_creation_input_tokens")
        + g("cache_read_input_tokens")
    )


# Current track — set via REFLECT_TRACK env var (e.g. by reflect-wake --track <name>
# passing it through, or by reflect-dispatch for parallel tracks). Defaults to "main"
# for backward compatibility with the existing single-track setup.
REFLECT_TRACK: str = os.environ.get("REFLECT_TRACK", "main")

# Per-track state directory. Each track gets its own isolated state files.
TRACK_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks" / REFLECT_TRACK

# Per-track state files (each track's isolated read/write surface)
LAST_WAKE_TIMESTAMP = TRACK_DIR / "last-wake.timestamp"
NEXT_WAKE_BY = TRACK_DIR / "next-wake-by.timestamp"

# Per-track interrupt socket and audit log for mid-wake message injection.
INTERRUPT_SOCK = TRACK_DIR / "interrupt.sock"
INTERRUPT_LOG = TRACK_DIR / "interrupt.log"

# DR18.1: Per-execution project context. In multi-project mode, the dispatcher
# sets REFLECT_PROJECT_ROOT to the project that owns this track's logs. Defaults
# to PROJECT_ROOT (orchestrator) for backward compatibility in scoped mode.
REFLECT_PROJECT_ROOT = Path(os.environ.get("REFLECT_PROJECT_ROOT", str(PROJECT_ROOT)))

# Shared across tracks (one knowledge graph, one audit ledger, one wakes archive).
# Written to the project root that owns this track's logs (DR18.1).
WAKES_DIR = REFLECT_PROJECT_ROOT / "agent" / "runtime" / "wakes"
WAKES_TSV = REFLECT_PROJECT_ROOT / "agent" / "runtime" / "wakes.tsv"
WAKES_TSV_HEADER = "wake_id\ttrack\tstarted_at\tended_at\tslept_clean\tnum_turns\tcost_usd\tearly_break_reason\ttranscript_path\n"

# Allow model override via REFLECT_MODEL env var.
# For AWS Bedrock, use cross-region inference IDs, e.g.:
#   REFLECT_MODEL=us.anthropic.claude-opus-4-6-v1
MODEL: str = os.environ.get("REFLECT_MODEL", "claude-sonnet-4-6")
MAX_TURNS = 500
MAX_BUDGET_USD = 10.00


def _wake_id() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")


# ---------------------------------------------------------------------------
# Scry WAL pre-flight cleanup
# ---------------------------------------------------------------------------

def _cleanup_scry_wal() -> None:
    """Delete 0-byte WAL/SHM sidecars from the scry DB before the agent starts.

    A 0-byte WAL left by a previous MCP session causes 'disk I/O error' on
    the next connection. Cleaning it here — before the agent's first scry_sql
    call — prevents that failure without requiring an explicit `reflect doctor`
    run. Silent on success; logs to stderr if cleanup was needed.
    """
    db_path = (
        PROJECT_ROOT / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db"
    )
    if not db_path.exists():
        return
    for sidecar in (Path(str(db_path) + "-wal"), Path(str(db_path) + "-shm")):
        if sidecar.exists() and sidecar.stat().st_size == 0:
            try:
                sidecar.unlink()
                print(
                    f"⚠️  scry WAL cleanup: deleted 0-byte {sidecar.name} before wake",
                    file=sys.stderr,
                )
            except OSError as exc:
                print(
                    f"⚠️  scry WAL cleanup: could not delete {sidecar.name}: {exc}",
                    file=sys.stderr,
                )


# ---------------------------------------------------------------------------
# Cadence floor — enforces "wake fast when actionable work exists"
# ---------------------------------------------------------------------------

def _count_draft_markers() -> int:
    """Count scry docs with status='draft' (actionable pending work).

    Excludes markers from test files and template files. Test suites
    intentionally embed draft-status example markers as fixtures; these
    are not real work items and must not trigger the cadence floor.
    """
    import sqlite3
    db_path = PROJECT_ROOT / "agent" / "drivers" / "@local" / "scry" / "data" / "project.db"
    if not db_path.exists():
        return 0
    try:
        con = sqlite3.connect(str(db_path))
        try:
            row = con.execute(
                "SELECT COUNT(*) FROM scry__doc "
                "WHERE status = 'draft' "
                "AND current_path NOT LIKE '%/test/%' "
                "AND current_path NOT LIKE '%/tests/%' "
                "AND current_path NOT LIKE '%.test.%' "
                "AND current_path NOT LIKE '%template%'"
            ).fetchone()
            return row[0] if row else 0
        finally:
            con.close()
    except Exception:
        return 0


def _count_unread_inbox() -> int:
    """Count unread .md files in main track's inbox/ (not in .consumed/).

    P9 (unified inbox): reads from tracks/main/inbox/ directly.
    Also checks agent/inbox/ for messages the agent has surfaced
    or that arrived at the project-level inbox.
    """
    count = 0
    # P9 path: per-track unified inbox
    main_inbox = PROJECT_ROOT / "agent" / "runtime" / "tracks" / "main" / "inbox"
    if main_inbox.is_dir():
        count += sum(1 for p in main_inbox.iterdir() if p.suffix == ".md" and p.is_file())
    # Project-level inbox (agent/inbox/ — P9 unified, no from-originator/ subdir)
    global_inbox = PROJECT_ROOT / "agent" / "inbox"
    if global_inbox.is_dir():
        count += sum(1 for p in global_inbox.iterdir() if p.suffix == ".md" and p.is_file())
    return count


def _count_open_threads_in_latest_report() -> int:
    """Count non-empty bullet lines under 'What's still open' in the latest report.

    Scans agent/reports/ for the most recent file, finds the '## What's still open'
    or '## Open' heading, counts non-empty bullet lines (- ...) until next heading
    or EOF. Returns 0 on any parse failure.
    """
    reports_dir = PROJECT_ROOT / "agent" / "reports"
    if not reports_dir.is_dir():
        return 0
    reports = sorted(
        (p for p in reports_dir.iterdir() if p.suffix == ".md" and p.is_file()),
        key=lambda p: p.name,
    )
    if not reports:
        return 0
    latest = reports[-1]
    try:
        lines = latest.read_text().splitlines()
    except Exception:
        return 0

    in_section = False
    count = 0
    for line in lines:
        if line.startswith("## ") or line.startswith("# "):
            # Enter/exit section
            heading_lower = line.lower()
            if any(kw in heading_lower for kw in ("still open", "open items", "open threads", "what's open")):
                in_section = True
            elif in_section:
                # Hit a new heading — stop
                break
        elif in_section and line.strip().startswith("-") and line.strip() != "-":
            # Non-empty bullet
            bullet_content = line.strip().lstrip("-").strip()
            if bullet_content:
                count += 1
    return count


def _apply_cadence_floor() -> None:
    """Clamp next-wake-by to +300s if actionable work exists and agent scheduled longer.

    Logs a warning to stderr when it overrides the agent's choice so the
    originator can see the override in /tmp/reflect-tick-*.log and the agent
    reads its own log tail on next wake.

    Preserves agent agency: does nothing if no actionable work exists.
    """
    # NEXT_WAKE_BY is unlinked at wake start. If it still doesn't exist
    # here, the agent called sleep(0) (explicit pause) or exhausted
    # budget. Both mean "pause until external signal." The real-backlog
    # case (inbox/followup files) is handled by _apply_backlog_override
    # separately. Respect the explicit pause; do not override.
    if not NEXT_WAKE_BY.exists():
        return

    drafts = _count_draft_markers()
    unread = _count_unread_inbox()
    threads = _count_open_threads_in_latest_report()

    if drafts == 0 and unread == 0 and threads == 0:
        return  # Genuinely nothing actionable — agent's wake schedule stands.

    now = int(time.time())
    cap = now  # immediate: next cron tick (≤60s) fires it

    requested: int | None = None
    if NEXT_WAKE_BY.exists():
        try:
            requested = int(NEXT_WAKE_BY.read_text().strip())
        except ValueError:
            requested = None

    if requested is None or requested > cap:
        NEXT_WAKE_BY.write_text(f"{cap}\n")
        original = "absent" if requested is None else f"+{requested - now}s"
        print(
            f"⚠️ next-wake-by clamped: {original} → immediate — "
            f"actionable work exists (drafts={drafts}, unread={unread}, "
            f"threads={threads})",
            file=sys.stderr,
        )


def _migrate_legacy_followup_dir() -> None:
    """One-time migration: move inbox/followup/ → followup/ (P9 sibling layout).

    Pre-P9 code wrote followup files to inbox/followup/. P9 spec places them at
    followup/ (sibling to inbox/). This function is idempotent: if inbox/followup/
    is empty or absent, it does nothing. Runs at wake start before sweep so the
    backlog counter immediately sees P9 paths.
    """
    legacy_dir = TRACK_DIR / "inbox" / "followup"
    target_dir = TRACK_DIR / "followup"
    if not legacy_dir.is_dir():
        return

    # Migrate .completed/ first (so target dir exists for active files).
    legacy_completed = legacy_dir / ".completed"
    target_completed = target_dir / ".completed"
    if legacy_completed.is_dir():
        target_completed.mkdir(parents=True, exist_ok=True)
        for f in legacy_completed.glob("*.md"):
            dest = target_completed / f.name
            if not dest.exists():
                try:
                    f.rename(dest)
                except Exception as e:
                    print(f"⚠️  followup-migrate: could not move {f} → {dest}: {e}", file=sys.stderr)

    # Migrate active followup files.
    target_dir.mkdir(parents=True, exist_ok=True)
    for f in legacy_dir.glob("*.md"):
        dest = target_dir / f.name
        if not dest.exists():
            try:
                f.rename(dest)
                print(f"📦 followup-migrate: {f.name} → followup/", file=sys.stderr)
            except Exception as e:
                print(f"⚠️  followup-migrate: could not move {f} → {dest}: {e}", file=sys.stderr)


def _parse_inbox_frontmatter(inbox_file: Path) -> dict:
    """Parse YAML frontmatter from an inbox file.

    Returns the parsed dict, or {} if no frontmatter or parse error.
    Frontmatter is the YAML block between the first two '---' lines.
    """
    try:
        text = inbox_file.read_text(errors="replace")
        if not text.startswith("---"):
            return {}
        rest = text[3:]  # skip opening ---
        idx = rest.find("---")
        if idx < 0:
            return {}
        import yaml
        return yaml.safe_load(rest[:idx]) or {}
    except Exception:
        return {}


def _resolve_pending_question(
    track_dir: Path,
    question_id: str,
    reply: str,
    now_ts: str,
) -> bool:
    """Resolve an open pending question by ID.

    Scans track_dir/pending-questions/*.yaml for a record whose `id`
    field equals question_id and whose `status` is 'open'. If found,
    updates the record atomically (reply, status=resolved, resolved_at),
    moves it to pending-questions/.resolved/, and touches NEXT_WAKE_BY
    so the dispatcher fires within ~60s (DR6).

    Returns True if resolved, False if not found or already resolved.
    """
    import yaml
    pq_dir = track_dir / "pending-questions"
    if not pq_dir.is_dir():
        return False

    match_file: Path | None = None
    match_rec: dict | None = None
    for p in sorted(pq_dir.glob("*.yaml")):
        if not p.is_file() or p.name.startswith("."):
            continue
        try:
            rec = yaml.safe_load(p.read_text()) or {}
            if rec.get("id") == question_id and rec.get("status") == "open":
                match_file = p
                match_rec = rec
                break
        except Exception:
            continue

    if match_file is None or match_rec is None:
        return False

    # Update record fields
    match_rec["reply"] = reply
    match_rec["status"] = "resolved"
    match_rec["resolved_at"] = (
        datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    )

    # Atomic write via tmp + rename
    tmp = match_file.parent / f"{match_file.name}.tmp"
    try:
        tmp.write_text(yaml.dump(match_rec))
        os.replace(str(tmp), str(match_file))
    except Exception:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return False

    # Move to .resolved/
    resolved_dir = pq_dir / ".resolved"
    resolved_dir.mkdir(parents=True, exist_ok=True)
    try:
        match_file.rename(resolved_dir / match_file.name)
    except Exception:
        pass

    # Touch NEXT_WAKE_BY to now-1 so dispatcher fires within ~60s (DR6)
    now_unix = int(time.time())
    override_ts = now_unix - 1
    tmp_nw = NEXT_WAKE_BY.parent / f".next-wake-by-reply.tmp.{os.getpid()}"
    try:
        tmp_nw.write_text(f"{override_ts}\n")
        os.replace(str(tmp_nw), str(NEXT_WAKE_BY))
    except Exception:
        try:
            tmp_nw.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            NEXT_WAKE_BY.write_text(f"{override_ts}\n")
        except Exception:
            pass

    return True


def _sweep_inbox_to_followup(wake_id: str = "unknown") -> int:
    """Solution E: auto-file followup for every unread inbox message, then consume.

    Write-then-move ordering is crash-safe:
    - crash after write, before move → followup exists; inbox file still present;
      next wake re-scans, sees inbox file, skips write (idempotent slug check), moves.
    - crash before write → neither happened; inbox file stays unread; clean retry.

    Scans both unified inbox/*.md (P9) and inbox/from-originator/*.md (pre-P9 compat).
    Writes followups to followup/<timestamp>-<slug>.md (P9: sibling to inbox/, not nested).
    Returns count of messages swept.
    """
    now_ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    inbox_dir = TRACK_DIR / "inbox"
    followup_dir = TRACK_DIR / "followup"  # P9: sibling to inbox/
    consumed_dir = inbox_dir / ".consumed"
    from_orig_dir = inbox_dir / "from-originator"
    from_orig_consumed = from_orig_dir / ".consumed"

    followup_dir.mkdir(parents=True, exist_ok=True)
    consumed_dir.mkdir(parents=True, exist_ok=True)

    # Collect (source_file, target_consumed_dir) pairs from both locations
    candidates: list[tuple[Path, Path]] = []

    if inbox_dir.is_dir():
        c_names = {p.name for p in consumed_dir.glob("*.md")} if consumed_dir.is_dir() else set()
        for p in sorted(inbox_dir.glob("*.md")):
            if p.is_file() and p.name not in c_names:
                candidates.append((p, consumed_dir))

    if from_orig_dir.is_dir():
        from_orig_consumed.mkdir(parents=True, exist_ok=True)
        fc_names = (
            {p.name for p in from_orig_consumed.glob("*.md")}
            if from_orig_consumed.is_dir() else set()
        )
        for p in sorted(from_orig_dir.glob("*.md")):
            if p.is_file() and p.name not in fc_names:
                candidates.append((p, from_orig_consumed))

    swept = 0
    for inbox_file, consumed_target in candidates:
        slug = inbox_file.stem  # e.g. "2026-05-13T11-02-52Z-btw"

        # Pre-pass: check for kind:reply binding to a pending question
        reply_bound_id: str | None = None
        fm = _parse_inbox_frontmatter(inbox_file)
        if fm.get("kind") == "reply" and fm.get("subject"):
            question_id = str(fm["subject"])
            try:
                raw_body = inbox_file.read_text(errors="replace")
                parts = raw_body.split("---", 2)
                reply_token = parts[2].strip() if len(parts) >= 3 else raw_body.strip()
            except Exception:
                reply_token = ""
            bound = _resolve_pending_question(
                TRACK_DIR, question_id, reply_token, now_ts
            )
            if bound:
                reply_bound_id = question_id
                print(
                    f"📬 reply bound [{REFLECT_TRACK}]: "
                    f"{question_id} → '{reply_token[:40]}'",
                    file=sys.stderr,
                )

        # Step 1: write followup (idempotent — skip if any followup for this slug exists)
        existing_followups = list(followup_dir.glob(f"*{slug}.md"))
        if not existing_followups:
            followup_path = followup_dir / f"{now_ts}-{slug}.md"
            try:
                body = inbox_file.read_text(errors="replace")
                rel_consumed = consumed_target / inbox_file.name
                reply_bound_line = (
                    f"reply_bound: {reply_bound_id}\n" if reply_bound_id else ""
                )
                followup_content = (
                    f"---\n"
                    f"consumed_from: {rel_consumed}\n"
                    f"consumed_at: {now_ts}\n"
                    f"status: open\n"
                    f"provenance: auto-created\n"
                    f"{reply_bound_line}"
                    f"---\n\n"
                    f"# Followup: {slug}\n\n"
                    f"> **AUTO-CREATED FOLLOWUP — read before acting**\n"
                    f">\n"
                    f"> This file was written by the wake-loop at inbox-consume\n"
                    f"> time (BOOT phase), before agent reasoning began.\n"
                    f">\n"
                    f"> Empty Progress = work NOT yet started, not stalled\n"
                    f"> prior work from a previous wake.\n"
                    f">\n"
                    f"> Action: verify the work described below is complete,\n"
                    f"> then close by moving this file to followup/.completed/.\n\n"
                    f"{body}\n\n"
                    f"## Progress\n\n"
                    f"(empty on creation)\n\n"
                    f"## Remaining\n\n"
                    f"(populated as items ship)\n"
                )
                followup_path.write_text(followup_content)
            except Exception as e:
                print(
                    f"⚠️  sweep: failed to write followup for {inbox_file.name}: {e}",
                    file=sys.stderr,
                )
                continue  # Don't move if followup write failed

        # Step 2: move original to .consumed/
        dest = consumed_target / inbox_file.name
        try:
            inbox_file.rename(dest)
            swept += 1
            # Emit inbox.consumed event (fire-and-forget).
            try:
                from .events import emit_event as _emit
                _emit("inbox.consumed", track=REFLECT_TRACK, wake_id=wake_id, payload={
                    "track": REFLECT_TRACK,
                    "path": str(dest),
                    "wake_id": wake_id,
                })
            except Exception:
                pass
        except Exception as e:
            print(
                f"⚠️  sweep: failed to consume {inbox_file.name}: {e}",
                file=sys.stderr,
            )

    if swept:
        print(
            f"📥 inbox-sweep [{REFLECT_TRACK}]: {swept} message(s) → followup",
            file=sys.stderr,
        )
    return swept


def _apply_backlog_override() -> None:
    """Force next-wake to immediate (now-1) if the track has un-drained backlog.

    Backlog = pending_originator + pending_followup:
      - pending_originator: *.md files in inbox/ and inbox/from-originator/ (not consumed)
      - pending_followup:   *.md files in followup/ (P9 sibling to inbox/; not in .completed/)

    Uses atomic rename (os.replace) so concurrent readers never see a half-written file.
    Logs the decision to stderr for debuggability in /tmp/reflect-tick-*.log.
    """
    inbox_dir = TRACK_DIR / "inbox"
    consumed_dir = inbox_dir / ".consumed"
    from_orig_dir = inbox_dir / "from-originator"
    from_orig_consumed_dir = from_orig_dir / ".consumed"
    followup_dir = TRACK_DIR / "followup"    # P9: sibling to inbox/
    completed_dir = followup_dir / ".completed"

    pending_originator = 0
    if inbox_dir.exists():
        consumed_names: set[str] = set()
        if consumed_dir.exists():
            consumed_names = {p.name for p in consumed_dir.glob("*.md") if p.is_file()}
        # Count .md files directly in inbox/ (not subdirs)
        pending_originator += sum(
            1 for p in inbox_dir.glob("*.md")
            if p.is_file() and p.name not in consumed_names
        )
    # Also count from-originator/ subdir (pre-P9 messages land here)
    if from_orig_dir.exists():
        from_orig_consumed: set[str] = set()
        if from_orig_consumed_dir.exists():
            from_orig_consumed = {p.name for p in from_orig_consumed_dir.glob("*.md") if p.is_file()}
        pending_originator += sum(
            1 for p in from_orig_dir.glob("*.md")
            if p.is_file() and p.name not in from_orig_consumed
        )

    pending_followup = 0
    blocked_followup = 0
    if followup_dir.exists():
        completed_names: set[str] = set()
        if completed_dir.exists():
            completed_names = {p.name for p in completed_dir.glob("*.md") if p.is_file()}
        for p in followup_dir.glob("*.md"):
            if not p.is_file() or p.name in completed_names:
                continue
            if (followup_dir / f"{p.name}.blocked").exists():
                # Blocked followup: cannot be advanced without external actor.
                # Excluded from backlog so the supervisor respects the agent's sleep choice.
                blocked_followup += 1
            else:
                pending_followup += 1

    backlog = pending_originator + pending_followup
    if backlog == 0:
        if blocked_followup:
            print(
                f"✋ backlog-override [{REFLECT_TRACK}]: skipped — "
                f"{blocked_followup} blocked followup(s) excluded from backlog "
                f"(originator={pending_originator}, active_followup={pending_followup})",
                file=sys.stderr,
            )
        return  # Nothing actionable; respect the agent's own sleep choice.

    now = int(time.time())
    override_ts = now - 1  # Defensive: guarantees dispatcher sees it as already-elapsed.

    # Atomic write via temp file + os.replace.
    tmp = NEXT_WAKE_BY.parent / f".next-wake-by.tmp.{os.getpid()}"
    try:
        tmp.write_text(f"{override_ts}\n")
        os.replace(str(tmp), str(NEXT_WAKE_BY))
    except Exception as exc:
        # Clean up temp; fall back to non-atomic write.
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            NEXT_WAKE_BY.write_text(f"{override_ts}\n")
        except Exception:
            pass
        print(f"⚠️  backlog-override: atomic rename failed ({exc}), used fallback", file=sys.stderr)

    blocked_note = f", blocked={blocked_followup}" if blocked_followup else ""
    print(
        f"⏩ backlog-override [{REFLECT_TRACK}]: backlog={backlog} "
        f"(originator={pending_originator}, followup={pending_followup}{blocked_note}) "
        f"→ next-wake forced immediate (ts={override_ts})",
        file=sys.stderr,
    )


def _to_jsonable(obj):
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    if isinstance(obj, (list, tuple)):
        return [_to_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _to_jsonable(v) for k, v in obj.items()}
    if hasattr(obj, "__dict__"):
        return {k: _to_jsonable(v) for k, v in vars(obj).items()}
    return repr(obj)


# ---------------------------------------------------------------------------
# Interrupt socket — mid-wake message injection
# ---------------------------------------------------------------------------

def _append_interrupt_log(msg: str) -> None:
    """Append a timestamped entry to the track's interrupt.log."""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        with INTERRUPT_LOG.open("a") as fh:
            fh.write(f"{ts}\t{msg}\n")
    except Exception as exc:
        print(f"⚠️  interrupt-log write failed: {exc}", file=sys.stderr)


def _augment_interrupt_with_pending_questions(msg: str) -> str:
    """Prepend pending-question context to an interrupt message (DR6 augmentation).

    - 0 open questions → msg unchanged
    - 1 open question  → full context block prepended
    - 2+ open questions → ID list prepended so agent can disambiguate
    """
    import yaml
    pq_dir = TRACK_DIR / "pending-questions"
    if not pq_dir.is_dir():
        return msg

    open_questions: list[dict] = []
    for p in sorted(pq_dir.glob("*.yaml")):
        if not p.is_file() or p.name.startswith("."):
            continue
        try:
            rec = yaml.safe_load(p.read_text()) or {}
            if rec.get("status") == "open":
                open_questions.append(rec)
        except Exception:
            continue

    if len(open_questions) == 0:
        return msg

    if len(open_questions) == 1:
        q = open_questions[0]
        qid = q.get("id", "unknown")
        question = q.get("question", "")
        answer_map = q.get("answer_map", {})
        answers = " / ".join(str(k) for k in answer_map.keys())
        blocked = q.get("context", {}).get("blocked_work", "unspecified")
        prefix = (
            f"[Pending question {qid}:\n"
            f' "{question}"\n'
            f" answers: {answers}\n"
            f' blocked: "{blocked}"]\n\n'
            f"Originator said: "
        )
        return prefix + msg

    # Multiple open questions — list them
    lines = [
        "[Multiple pending questions open — determine which this"
        " reply addresses:"
    ]
    for q in open_questions:
        qid = q.get("id", "unknown")
        question = q.get("question", "")
        lines.append(f'  {qid}: "{question[:60]}..."')
    lines.append("]")
    lines.append("")
    lines.append(f"Originator said: {msg}")
    return "\n".join(lines)


async def _deliver_interrupt(client: "ClaudeSDKClient", msg: str) -> bool:
    """Try to inject *msg* into client; retry on transport-busy errors.

    Returns True on success, False if dropped after max retries.
    Total backoff budget: ~5s across 12 attempts (0.1s initial, 1.5× growth, 1.0s cap).
    """
    delay = 0.1
    for _attempt in range(12):
        try:
            await client.interrupt()
            await client.query(msg)
            return True
        except Exception as exc:
            msg_lower = str(exc).lower()
            transient = (
                "not ready" in msg_lower
                or "processtransport" in msg_lower
                or ("transport" in msg_lower and "writ" in msg_lower)
            )
            if not transient:
                raise
            await asyncio.sleep(min(delay, 1.0))
            delay *= 1.5
    return False


async def _handle_interrupt_conn(
    client: "ClaudeSDKClient",
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
) -> None:
    """Handle a single interrupt socket connection.

    Reads the full message, logs it, closes the writer, then calls
    _deliver_interrupt() which retries on transport-busy errors so the
    injected message lands as the next user turn.
    """
    try:
        data = await reader.read(65536)
        msg = data.decode("utf-8").strip()
        if not msg:
            return
        _append_interrupt_log(msg)
        print(f"⚡ interrupt received: {msg[:120]}", file=sys.stderr)
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass
        augmented_msg = _augment_interrupt_with_pending_questions(msg)
        delivered = await _deliver_interrupt(client, augmented_msg)
        if not delivered:
            print(
                f"⚠️  interrupt DROPPED after retries — agent did NOT see: {msg[:120]}",
                file=sys.stderr,
            )
            _append_interrupt_log(f"[DROPPED] {msg}")
    except Exception as exc:
        print(f"⚠️  interrupt handler error: {exc}", file=sys.stderr)


async def _listen_interrupt_socket(client: "ClaudeSDKClient") -> None:
    """Background asyncio task: listen on INTERRUPT_SOCK for injected messages.

    Lifecycle:
    - Unlinks any stale socket from a previous crashed wake on startup.
    - Creates a unix-domain server and serves until cancelled.
    - Cancelled when the wake loop exits (normally or via exception).
    """
    sock_path = INTERRUPT_SOCK

    # Stale socket cleanup: unlink before binding so bind doesn't fail.
    if sock_path.exists():
        try:
            sock_path.unlink()
        except OSError:
            pass

    try:
        server = await asyncio.start_unix_server(
            lambda r, w: _handle_interrupt_conn(client, r, w),
            path=str(sock_path),
        )
    except Exception as exc:
        print(f"⚠️  interrupt socket could not bind ({sock_path}): {exc}", file=sys.stderr)
        return

    print(f"   interrupt socket: {sock_path.relative_to(PROJECT_ROOT)}", file=sys.stderr)
    try:
        async with server:
            await server.serve_forever()
    except asyncio.CancelledError:
        pass
    finally:
        # Clean up socket file so CLI callers get "track is sleeping" instead
        # of a stale connection-refused error.
        try:
            if sock_path.exists():
                sock_path.unlink()
        except OSError:
            pass


def _serialize(message) -> dict:
    return {"type": type(message).__name__, "data": _to_jsonable(message)}


async def _as_stream(wake_id: str, briefing_content: list[dict]):
    """Yield the briefing synthetic turn then the wake directive.

    Two-turn structure:
    1. Briefing — deterministic content blocks with cache_control on the body
       block so prompt cache hits are reliable across wakes.
    2. Wake directive — terse user message that opens the wake loop.

    The SDK requires an AsyncIterable when can_use_tool is set.
    """
    # Briefing synthetic turn (cached body + uncached footer)
    yield {"type": "user", "message": {"role": "user", "content": briefing_content}}
    # Wake directive (the actual prompt the agent acts on)
    directive = build_wake_directive(wake_id)
    yield {"type": "user", "message": {"role": "user", "content": directive}}


def _print_event(message) -> None:
    """Stream the agent's events to stderr, full content (no truncation).

    Text blocks (`💭`) and thinking blocks (`🧠`) get their full body — the
    originator wants to actually see what the agent is thinking. Tool calls
    (`🔧`) get a one-line hint with the relevant input (file path for file
    tools, full command for Bash). The transcript JSONL is still authoritative;
    this is the live view.
    """
    if isinstance(message, AssistantMessage):
        for block in getattr(message, "content", []) or []:
            if isinstance(block, TextBlock):
                text = (block.text or "").rstrip()
                if text:
                    for line in text.splitlines():
                        print(f"💭 {line}", file=sys.stderr)
            elif isinstance(block, ThinkingBlock):
                thinking = (getattr(block, "thinking", "") or "").rstrip()
                if thinking:
                    lines = thinking.splitlines()
                    if lines:
                        print(f"🧠 {lines[0]}", file=sys.stderr)
                        for line in lines[1:]:
                            print(f"   {line}", file=sys.stderr)
            elif isinstance(block, ToolUseBlock):
                arg_hint = ""
                if block.name == "Bash":
                    cmd = block.input.get("command", "")
                    # Bash commands can span multiple lines (heredocs) — print
                    # the whole thing on continuation lines so cron logs stay
                    # legible.
                    cmd_lines = cmd.splitlines() if cmd else []
                    if cmd_lines:
                        print(f"🔧 {block.name}: {cmd_lines[0]}", file=sys.stderr)
                        for line in cmd_lines[1:]:
                            print(f"        {line}", file=sys.stderr)
                    else:
                        print(f"🔧 {block.name}", file=sys.stderr)
                elif block.name in ("Read", "Write", "Edit"):
                    arg_hint = f": {block.input.get('file_path', '')}"
                    print(f"🔧 {block.name}{arg_hint}", file=sys.stderr)
                else:
                    print(f"🔧 {block.name}", file=sys.stderr)
    elif isinstance(message, SystemMessage):
        # Permission denials and similar surface as SystemMessage.
        subtype = getattr(message, "subtype", None)
        if subtype:
            print(f"ℹ️  system: {subtype}", file=sys.stderr)


# ---------------------------------------------------------------------------
# Worktree-per-wake helpers (P7)
# ---------------------------------------------------------------------------

def _load_track_config(track_dir: Path) -> dict:
    """Return the parsed config.yaml for this track, or {} if absent/malformed."""
    config_path = track_dir / "config.yaml"
    if not config_path.exists():
        return {}
    try:
        import yaml
        return yaml.safe_load(config_path.read_text()) or {}
    except Exception as e:
        print(f"⚠️  track config parse error ({config_path}): {e}", file=sys.stderr)
        return {}


def _run_scry_script(script_name: str, params: dict) -> dict:
    """Invoke a global scry_script atom directly (no MCP round-trip).

    Scripts live at agent/drivers/@local/scry/scripts/<name>.py.
    Each exports `run(db, params) -> dict`. We call with db=None since
    the global worktree scripts only use subprocess, never the DB.
    """
    script_path = (
        PROJECT_ROOT / "agent" / "drivers" / "@local" / "scry" / "scripts"
        / f"{script_name}.py"
    )
    if not script_path.exists():
        return {"error": f"script_not_found: {script_name}"}
    try:
        spec = importlib.util.spec_from_file_location(
            f"scry_script_{script_name}", str(script_path)
        )
        if spec is None or spec.loader is None:
            return {"error": f"could not load spec for {script_name}"}
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
        return mod.run(None, params)
    except Exception as e:
        return {"error": f"script execution error: {e}"}


def _ensure_commit_msg_hook() -> None:
    """Install the reflect commit-msg hook if not already present.

    The hook appends a Wake-Id trailer to every git commit made within
    a reflect wake. It reads REFLECT_TRACK and REFLECT_WAKE_ID from the
    process environment — so it fires only on reflect commits, not on
    human commits.

    Idempotent: if the hook already contains the v2 reflect marker, it
    is left unchanged. A v1 hook (Co-Authored-By era) is replaced with
    v2. If a non-reflect hook already exists, we skip with a warning.
    """
    try:
        git_dir_result = subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True, text=True,
            cwd=str(PROJECT_ROOT), timeout=5,
        )
        if git_dir_result.returncode != 0:
            return  # Not a git repo; skip silently.

        git_dir_str = git_dir_result.stdout.strip()
        git_dir = (
            Path(git_dir_str)
            if Path(git_dir_str).is_absolute()
            else PROJECT_ROOT / git_dir_str
        )
        hooks_dir = git_dir / "hooks"
        hooks_dir.mkdir(parents=True, exist_ok=True)
        hook_path = hooks_dir / "commit-msg"

        _HOOK_MARKER = "# reflect-attribution-hook-v2"
        _OLD_HOOK_MARKER = "# reflect-attribution-hook-v1"

        if hook_path.exists():
            try:
                existing = hook_path.read_text()
                if _HOOK_MARKER in existing:
                    return  # v2 already installed; nothing to do.
                if _OLD_HOOK_MARKER not in existing:
                    # Non-reflect hook — don't overwrite; warn instead.
                    print(
                        "⚠️  commit-msg hook exists without reflect marker — "
                        "trailers will not be injected; chain manually if needed",
                        file=sys.stderr,
                    )
                    return
                # v1 hook found — fall through to replace with v2.
                print(
                    "   commit-msg hook: upgrading v1 → v2 (removing Co-Authored-By)",
                    file=sys.stderr,
                )
            except Exception:
                pass

        hook_script = (
            "#!/bin/sh\n"
            f"{_HOOK_MARKER}\n"
            "# Do not remove the marker line above.\n"
            "# Reads REFLECT_TRACK and REFLECT_WAKE_ID from env.\n"
            "# No-op when those vars are absent (human commits unaffected).\n"
            "\n"
            'TRACK="${REFLECT_TRACK:-}"\n'
            'WAKE_ID="${REFLECT_WAKE_ID:-}"\n'
            "\n"
            'if [ -z "$TRACK" ] || [ -z "$WAKE_ID" ]; then\n'
            "    exit 0\n"
            "fi\n"
            "\n"
            "# Add Wake-Id if no Wake-Id trailer is already present.\n"
            'grep -q "^Wake-Id:" "$1" || '
            'git interpret-trailers --in-place --trailer "Wake-Id: ${TRACK}/${WAKE_ID}" "$1"\n'
            "\n"
            "exit 0\n"
        )

        hook_path.write_text(hook_script)
        hook_path.chmod(0o755)
        print(
            f"   commit-msg hook installed: "
            f"{hook_path.relative_to(PROJECT_ROOT)}",
            file=sys.stderr,
        )
    except Exception as exc:
        print(
            f"⚠️  commit-msg hook setup failed (non-fatal): {exc}",
            file=sys.stderr,
        )


def _advance_last_known_good(project_root: Path) -> None:
    """Advance the reflect/last-known-good ref to current HEAD.

    Called after a successful worktree promotion so rollback always targets
    the most recent good state.
    """
    try:
        result = subprocess.run(
            ["git", "branch", "-f", "reflect/last-known-good", "HEAD"],
            cwd=str(project_root),
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            print(
                f"⚠️  advance last-known-good failed: {result.stderr.strip()}",
                file=sys.stderr,
            )
        else:
            head_sha = subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
                cwd=str(project_root),
            ).decode().strip()
            print(f"   last-known-good → {head_sha}", file=sys.stderr)
    except Exception as e:
        print(f"⚠️  advance last-known-good exception: {e}", file=sys.stderr)


def _file_promotion_blocked_report(
    track: str,
    wake_id: str,
    conflicts: list,
    track_dir: Path,
) -> None:
    """Write a promotion-blocked inbox message so the next wake can resolve conflicts.

    P9 (unified inbox): writes to inbox/ directly with frontmatter (from: system).
    """
    inbox_dir = track_dir / "inbox"
    inbox_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    fname = f"{ts}-promotion-blocked-{wake_id[:16]}.md"
    worktree_path = (
        PROJECT_ROOT / "agent" / "runtime" / "tracks" / track
        / ".sandbox-worktrees" / wake_id
    )
    conflict_lines = "\n".join(f"- `{c}`" for c in conflicts) if conflicts else "- (no conflict details)"
    content = f"""---
from: system
to: {track}
at: {ts}
kind: report
subject: promotion blocked — worktree conflict
---

# Promotion blocked — worktree conflict

**Wake ID**: `{wake_id}`
**Track**: `{track}`
**Worktree**: `{worktree_path.relative_to(PROJECT_ROOT)}`

The wake completed cleanly but `worktree_promote` detected a merge conflict.
The worktree has been left intact. A conflict-resolution wake has been scheduled
with a reduced budget (25 turns / $1.50) to resolve and re-promote.

## Conflicting files

{conflict_lines}

## Resolution steps

1. Review conflicts in the worktree at `{worktree_path.relative_to(PROJECT_ROOT)}`
2. Resolve each conflict file manually or accept one side
3. Commit the resolution in the worktree
4. Call `scry_script("worktree_promote", {{...}})` again
5. If clean, call `scry_script("worktree_cleanup", {{...}})` and advance `reflect/last-known-good`

This inbox message was generated automatically by the post-wake promotion hook.
"""
    try:
        (inbox_dir / fname).write_text(content)
        print(f"   promotion-blocked report filed: {fname}", file=sys.stderr)
    except Exception as e:
        print(f"⚠️  failed to write promotion-blocked report: {e}", file=sys.stderr)


async def _receive_with_stall_timeout(client, stall_seconds: float):
    """Yield messages from client.receive_messages() with a per-message stall timeout.

    If no message arrives within stall_seconds, raises asyncio.TimeoutError.
    Caller catches this and sets early_break_reason='stall' before the exception
    propagates to the outer finally (which emits wake.failed).
    """
    aiter = client.receive_messages().__aiter__()
    while True:
        try:
            msg = await asyncio.wait_for(aiter.__anext__(), timeout=stall_seconds)
        except StopAsyncIteration:
            break
        except asyncio.TimeoutError:
            raise asyncio.TimeoutError(
                f"no SDK message in {stall_seconds:.0f}s — subprocess may be hung"
            )
        yield msg


def _get_git_head() -> str | None:
    """Return current git HEAD SHA, or None on failure."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True,
            cwd=str(PROJECT_ROOT), timeout=5,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except Exception:
        return None


def _print_artifact_summary(
    wake_id: str,
    track: str,
    files_written: "list[tuple[str, str]]",
    inbox_sent: "list[tuple[str, str]]",
    wake_start_sha: "str | None",
) -> None:
    """Print a wake-end artifact summary to stdout.

    Lists every file written/edited, every inbox message sent, every commit
    made, and the wake report path. Substrate-enforced: the agent cannot skip
    or modify this output. Prints to stdout (not stderr) so it's easy to
    capture separately from the live event stream.

    Format:
        === ARTIFACTS — <track> wake <wake_id> ===
        Files written: ...
        Commits: ...
        Inbox sent: ...
        Wake report: ...
        === END ARTIFACTS ===
    """
    import re as _re

    # Partition written files into wake-report files vs everything else.
    # Wake report pattern: agent/reports/*-wake-*.md
    report_files: list[tuple[str, str]] = []
    non_report_files: list[tuple[str, str]] = []
    for path, tool in files_written:
        if "/agent/reports/" in path and "-wake-" in path and path.endswith(".md"):
            report_files.append((path, tool))
        else:
            non_report_files.append((path, tool))

    # Commits made during this wake.
    commits: list[str] = []
    if wake_start_sha:
        try:
            result = subprocess.run(
                ["git", "log", f"{wake_start_sha}..HEAD", "--oneline"],
                capture_output=True, text=True,
                cwd=str(PROJECT_ROOT), timeout=10,
            )
            if result.returncode == 0:
                commits = [ln for ln in result.stdout.strip().splitlines() if ln]
        except Exception:
            pass

    # Build output lines
    lines: list[str] = [f"=== ARTIFACTS — {track} wake {wake_id} ===", ""]

    if non_report_files:
        lines.append("Files written:")
        for path, tool in non_report_files:
            lines.append(f"  {path} ({tool})")
    else:
        lines.append("Files written: (none)")

    lines.append("")

    if commits:
        lines.append("Commits:")
        for c in commits:
            lines.append(f"  {c}")
    else:
        lines.append("Commits: (none)")

    lines.append("")

    if inbox_sent:
        lines.append("Inbox sent:")
        for recipient, path in inbox_sent:
            lines.append(f"  → {recipient}: {path}")
    else:
        lines.append("Inbox sent: (none)")

    lines.append("")

    if report_files:
        lines.append("Wake report:")
        for path, _ in report_files:
            lines.append(f"  {path}")
    else:
        lines.append("Wake report: (none)")

    lines.append("")
    lines.append("=== END ARTIFACTS ===")

    # stdout intentionally — separate from the stderr event stream so the
    # originator can capture artifacts independently of the live log.
    print("\n".join(lines))


def _count_remaining_work() -> int:
    """Count pending inbox messages + open followups for the current track.

    Same semantics as _apply_backlog_override — used by the work-produced guard
    to decide whether a check-back wake is warranted after work was shipped.

    Checks:
      - inbox/*.md (not in .consumed/)
      - inbox/from-originator/*.md (not in .consumed/)  [pre-P9 compat]
      - followup/*.md (not in .completed/)               [P9: sibling to inbox/]
    """
    inbox_dir = TRACK_DIR / "inbox"
    consumed_dir = inbox_dir / ".consumed"
    from_orig_dir = inbox_dir / "from-originator"
    from_orig_consumed_dir = from_orig_dir / ".consumed"
    followup_dir = TRACK_DIR / "followup"
    completed_dir = followup_dir / ".completed"

    count = 0

    if inbox_dir.exists():
        consumed_names: set[str] = (
            {p.name for p in consumed_dir.glob("*.md") if p.is_file()}
            if consumed_dir.exists() else set()
        )
        count += sum(
            1 for p in inbox_dir.glob("*.md")
            if p.is_file() and p.name not in consumed_names
        )

    if from_orig_dir.exists():
        from_orig_consumed: set[str] = (
            {p.name for p in from_orig_consumed_dir.glob("*.md") if p.is_file()}
            if from_orig_consumed_dir.exists() else set()
        )
        count += sum(
            1 for p in from_orig_dir.glob("*.md")
            if p.is_file() and p.name not in from_orig_consumed
        )

    if followup_dir.exists():
        completed_names: set[str] = (
            {p.name for p in completed_dir.glob("*.md") if p.is_file()}
            if completed_dir.exists() else set()
        )
        count += sum(
            1 for p in followup_dir.glob("*.md")
            if p.is_file()
            and p.name not in completed_names
            and not (followup_dir / f"{p.name}.blocked").exists()
        )

    return count


def _apply_work_produced_guard(start_head: str | None) -> None:
    """Force next-wake to check-back if this wake made commits AND remaining work exists.

    Gated on remaining queue (refined from unconditional HEAD-change guard):
      - Work produced AND remaining > 0 → fire in 60s (if not already more urgent).
      - Work produced AND remaining == 0 → track has fully drained; respect sleep.
      - No work produced (HEAD unchanged) → always a no-op.

    The backlog-override runs before this and sets immediate (now-1) when
    followups are pending, so we defer to its timestamp rather than overriding
    with a later one.
    """
    if start_head is None:
        return  # Can't compare; skip guard
    end_head = _get_git_head()
    if end_head is None or end_head == start_head:
        return  # No commits this wake; no override

    remaining = _count_remaining_work()
    if remaining == 0:
        # Queue empty — track has fully drained. Let the agent's sleep choice stand.
        print(
            f"✅ work-produced-guard [{REFLECT_TRACK}]: HEAD {start_head[:8]}→{end_head[:8]}"
            f" but queue empty — natural cadence",
            file=sys.stderr,
        )
        return

    # Remaining > 0: guarantee a check-back wake.
    # _apply_backlog_override already ran and may have set immediate (now-1).
    # Don't override with a later timestamp — defer when already more urgent.
    now = int(time.time())
    override_ts = now + 60  # 60s — fast follow-up, not truly immediate

    if NEXT_WAKE_BY.exists():
        try:
            current_ts = int(NEXT_WAKE_BY.read_text().strip())
            if current_ts <= now:
                # Backlog-override already set immediate; don't worsen it.
                print(
                    f"⚡ work-produced-guard [{REFLECT_TRACK}]: HEAD {start_head[:8]}→{end_head[:8]}"
                    f", remaining={remaining} — backlog-override already immediate, deferring",
                    file=sys.stderr,
                )
                return
        except ValueError:
            pass

    tmp = NEXT_WAKE_BY.parent / f".next-wake-by-wpg.tmp.{os.getpid()}"
    try:
        tmp.write_text(f"{override_ts}\n")
        os.replace(str(tmp), str(NEXT_WAKE_BY))
    except Exception as exc:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            NEXT_WAKE_BY.write_text(f"{override_ts}\n")
        except Exception:
            pass
        print(
            f"⚠️  work-produced-guard: atomic rename failed ({exc}), used fallback",
            file=sys.stderr,
        )
    print(
        f"⚡ work-produced-guard [{REFLECT_TRACK}]: HEAD {start_head[:8]}→{end_head[:8]}"
        f", remaining={remaining} → next-wake in 60s",
        file=sys.stderr,
    )


# ---------------------------------------------------------------------------
# Dormant wake detection + exponential backoff (Layer 2 noop-loop fix)
# See agent/design/dormant-wake-detection.md for the full diagnosis.
# ---------------------------------------------------------------------------

# Paths considered runtime-bookkeeping; writes to these do NOT count as
# "external effect" for dormancy classification.  Keep this list stable —
# additions should be narrower (substrings that match only bookkeeping paths),
# never so broad they mask genuine output.
_BOOKKEEPING_FRAGMENTS = (
    "/agent/reports/",               # wake report
    "/agent/drivers/@local/scry/runtime/",  # heartbeat.log, scry runtime
    "/agent/runtime/",               # wake state, wakes/, events.jsonl, etc.
    "heartbeat.log",                 # belt-and-suspenders
    "events.jsonl",                  # event stream
    "dormant-count.txt",             # the state file itself
)

# Dormant grace period: don't start backing off until this many consecutive
# dormant wakes have been observed.  Allows a short "nothing today" rhythm
# (e.g. inbox lands one minute after a dormant check) without penalty.
_DORMANT_GRACE_WAKES = 3

# Backoff parameters.
_DORMANT_BASE_SECONDS = 120    # 2 minutes at first backoff step
_DORMANT_CAP_SECONDS  = 3600  # 1 hour max


def _is_wake_dormant(
    wake_start_sha: "str | None",
    artifact_files: "list[tuple[str, str]]",
    artifact_inbox_sent: "list[tuple[str, str]]",
) -> bool:
    """Return True if this wake produced zero external effect.

    A wake is dormant when all three hold:
      1. No git commits were made (HEAD unchanged).
      2. No inbox messages were sent to other tracks.
      3. Every Write/Edit artifact is a runtime-bookkeeping path.

    This matches the output-based dormant definition in
    design.dormant-wake-detection~cd9f495c.  The bookkeeping exclusion
    list (_BOOKKEEPING_FRAGMENTS) covers: the wake report, heartbeat.log,
    events.jsonl, and everything under agent/runtime/.
    """
    # Criterion 1: no commits
    end_head = _get_git_head()
    if wake_start_sha is not None and end_head is not None:
        if end_head != wake_start_sha:
            return False

    # Criterion 2: no inbox messages sent
    if artifact_inbox_sent:
        return False

    # Criterion 3: no non-bookkeeping file writes
    for abs_fp, _ in artifact_files:
        is_bookkeeping = any(frag in abs_fp for frag in _BOOKKEEPING_FRAGMENTS)
        if not is_bookkeeping:
            return False

    return True


def _apply_dormant_backoff(is_dormant: bool) -> None:
    """Apply exponential backoff to next-wake-by on consecutive dormant wakes.

    Maintains a per-track counter in TRACK_DIR/dormant-count.txt.
    On each dormant wake (after _DORMANT_GRACE_WAKES grace), clamps
    next-wake-by upward using exponential backoff:
        2m → 4m → 8m → … capped at 1h.

    Any non-dormant wake resets the counter to 0.

    Does NOT override when backlog-override already set immediate (<=now)
    because real work exists in that case.

    Does NOT add a wake when the agent explicitly chose to pause
    (next-wake-by absent, i.e. next_wake_in_seconds=0).
    """
    dormant_count_file = TRACK_DIR / "dormant-count.txt"

    # Read current consecutive count
    try:
        count = int(dormant_count_file.read_text().strip())
    except Exception:
        count = 0

    if not is_dormant:
        # Reset counter on any productive wake
        if count > 0:
            try:
                dormant_count_file.write_text("0\n")
            except Exception:
                pass
            print(
                f"✅ dormant-backoff [{REFLECT_TRACK}]: reset"
                f" (was {count} consecutive dormant wake(s))",
                file=sys.stderr,
            )
        return

    # Dormant wake — increment counter
    new_count = count + 1
    try:
        dormant_count_file.write_text(f"{new_count}\n")
    except Exception:
        pass

    # Grace: don't backoff yet
    if new_count <= _DORMANT_GRACE_WAKES:
        print(
            f"😴 dormant-backoff [{REFLECT_TRACK}]: dormant wake #{new_count}"
            f" (grace {new_count}/{_DORMANT_GRACE_WAKES}, no backoff yet)",
            file=sys.stderr,
        )
        return

    # Compute backoff ceiling (2^(step) * base, capped)
    step = new_count - _DORMANT_GRACE_WAKES - 1  # 0-indexed after grace
    backoff_seconds = min(_DORMANT_BASE_SECONDS * (2 ** step), _DORMANT_CAP_SECONDS)

    now = int(time.time())

    # If next-wake-by is absent (agent paused), nothing to clamp — respect it.
    if not NEXT_WAKE_BY.exists():
        print(
            f"😴 dormant-backoff [{REFLECT_TRACK}]: dormant wake #{new_count}"
            f", backoff={backoff_seconds}s — agent paused, no next-wake-by to clamp",
            file=sys.stderr,
        )
        return

    try:
        current_ts = int(NEXT_WAKE_BY.read_text().strip())
    except (ValueError, OSError):
        return

    # If backlog-override already set immediate, don't fight it.
    if current_ts <= now:
        print(
            f"😴 dormant-backoff [{REFLECT_TRACK}]: dormant wake #{new_count}"
            f" — backlog-override already immediate, skipping backoff",
            file=sys.stderr,
        )
        return

    # Clamp upward: apply backoff only if it would push the timestamp later.
    clamped_ts = now + backoff_seconds
    if clamped_ts <= current_ts:
        print(
            f"😴 dormant-backoff [{REFLECT_TRACK}]: dormant wake #{new_count}"
            f", backoff={backoff_seconds}s — next-wake-by already >= floor, no change",
            file=sys.stderr,
        )
        return

    tmp = NEXT_WAKE_BY.parent / f".next-wake-by-dormant.tmp.{os.getpid()}"
    try:
        tmp.write_text(f"{clamped_ts}\n")
        os.replace(str(tmp), str(NEXT_WAKE_BY))
    except Exception as exc:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            NEXT_WAKE_BY.write_text(f"{clamped_ts}\n")
        except Exception:
            pass
        print(
            f"⚠️  dormant-backoff: atomic rename failed ({exc}), used fallback",
            file=sys.stderr,
        )

    print(
        f"😴 dormant-backoff [{REFLECT_TRACK}]: dormant wake #{new_count}"
        f", backoff={backoff_seconds}s"
        f" (was {current_ts - now}s → now {backoff_seconds}s)",
        file=sys.stderr,
    )


async def _run_wake() -> int:
    started_at = int(time.time())
    _cleanup_scry_wal()  # Remove 0-byte WAL sidecars before first scry call
    wake_id = _wake_id()
    _wake_start_git_head = _get_git_head()  # defensive next-wake guard baseline
    transcript_dir = WAKES_DIR / REFLECT_TRACK / wake_id

    # Artifact accumulators — populated as tool calls are observed in the loop.
    # Printed to stdout at wake-end via _print_artifact_summary().
    _artifact_files: list[tuple[str, str]] = []  # (abs_path, tool_name)
    _artifact_inbox_sent: list[tuple[str, str]] = []  # (recipient, abs_path)
    _pending_send_ids: dict[str, str] = {}  # tool_use_id → recipient
    transcript_dir.mkdir(parents=True, exist_ok=True)
    transcript_path = transcript_dir / "transcript.jsonl"

    # Ensure per-track state dir exists (no-op for main if already created at
    # migration; idempotent for new tracks created after the dispatcher ships).
    TRACK_DIR.mkdir(parents=True, exist_ok=True)

    # Status channel (DR6): mark this track running at wake start.
    try:
        mark_running(REFLECT_TRACK, wake_id)
    except Exception as _se:
        print(f"⚠️  status.json mark_running failed (non-fatal): {_se}", file=sys.stderr)

    # Event stream: emit wake.started and track.running.
    _events_set_runtime_root(PROJECT_ROOT / "agent" / "runtime")
    emit_event("track.running", track=REFLECT_TRACK, wake_id=wake_id, payload={
        "pid": os.getpid(),
    })
    emit_event("wake.started", track=REFLECT_TRACK, wake_id=wake_id, payload={
        "pid": os.getpid(),
        "kickoff_source": os.environ.get("REFLECT_KICKOFF_SOURCE", "scheduled"),
    })

    # Signal handlers: catch SIGTERM/SIGINT so the finally block can emit wake.failed.
    import signal as _signal
    _sig_received: list[int] = []

    def _handle_term_signal(signum: int) -> None:
        _sig_received.append(signum)
        # Cancel all running tasks so the finally block can emit wake.failed
        for t in asyncio.all_tasks():
            t.cancel()

    try:
        loop = asyncio.get_event_loop()
        loop.add_signal_handler(_signal.SIGTERM, lambda: _handle_term_signal(_signal.SIGTERM))
        loop.add_signal_handler(_signal.SIGINT, lambda: _handle_term_signal(_signal.SIGINT))
    except Exception as _she:
        print(f"⚠️  signal handler setup failed (non-fatal): {_she}", file=sys.stderr)

    # Persist wake-start time so tick.py can use it for inbox signal checks.
    # last-wake-start.timestamp records when THIS wake began; tick.py compares
    # unread inbox file mtimes against this value, not against last-wake-end.
    # This prevents mid-wake message drops from being silently missed.
    LAST_WAKE_START = TRACK_DIR / "last-wake-start.timestamp"
    try:
        LAST_WAKE_START.write_text(f"{started_at}\n")
    except Exception as e:
        print(f"⚠️  failed to write last-wake-start.timestamp: {e}", file=sys.stderr)

    # Write PID to wake.lock so tick.py can detect live vs orphaned wakes.
    # This replaces the flock-only approach which breaks across exec() boundaries.
    _wake_lock_file = TRACK_DIR / "wake.lock"
    try:
        _wake_lock_file.write_text(f"{os.getpid()}\n")
    except Exception as _wle:
        print(f"⚠️  failed to write wake.lock PID: {_wle}", file=sys.stderr)

    track_label = f" [track:{REFLECT_TRACK}]" if REFLECT_TRACK != "main" else ""
    print(f"🫀 reflect-wake {wake_id}{track_label}", file=sys.stderr)
    print(f"   transcript: {transcript_path.relative_to(PROJECT_ROOT)}", file=sys.stderr)
    print(f"   model: {MODEL}  caps: {MAX_TURNS} turns / ${MAX_BUDGET_USD:.2f}", file=sys.stderr)
    print("", file=sys.stderr)

    # Clear any prior next-wake-by ref. If the agent wants to schedule another
    # wake, it must write this file during this wake — that's the self-pacing
    # contract. Absent file = "no automatic next wake; pause until external signal."
    if NEXT_WAKE_BY.exists():
        NEXT_WAKE_BY.unlink()

    # Pre-wake stop check: if the originator touched the stop file before this
    # wake fired, treat it as "don't run this cycle." Delete the file and exit
    # immediately — the dispatcher has already fired, but we bail before querying
    # the model at all.
    stop_file = TRACK_DIR / "stop.requested"
    if stop_file.exists():
        try:
            stop_file.unlink()
        except FileNotFoundError:
            pass
        print(
            f"⚠️  stop.requested present at wake start — aborting wake{track_label}",
            file=sys.stderr,
        )
        ended_at = int(time.time())
        try:
            LAST_WAKE_TIMESTAMP.write_text(f"{ended_at}\n")
        except Exception as e:
            print(f"⚠️  failed to write last-wake.timestamp: {e}", file=sys.stderr)
        try:
            emit_event("wake.failed", track=REFLECT_TRACK, wake_id=wake_id, payload={
                "duration_seconds": ended_at - started_at,
                "early_break_reason": "stop_requested",
            })
        except Exception as _ee:
            print(f"⚠️  events: stop-requested emit failed (non-fatal): {_ee}", file=sys.stderr)
        return 0

    # P7: Wake override caps for conflict-resolution wakes.
    # A preceding wake that encountered a promotion conflict writes
    # wake_override.yaml with reduced max_turns/max_budget_usd before
    # scheduling this wake. We read and consume it here (delete after read).
    effective_max_turns = MAX_TURNS
    effective_max_budget = MAX_BUDGET_USD
    wake_override_path = TRACK_DIR / "wake_override.yaml"
    if wake_override_path.exists():
        try:
            import yaml as _yaml
            override = _yaml.safe_load(wake_override_path.read_text()) or {}
            if "max_turns" in override:
                effective_max_turns = int(override["max_turns"])
            if "max_budget_usd" in override:
                effective_max_budget = float(override["max_budget_usd"])
            wake_override_path.unlink()
            print(
                f"   wake_override applied: max_turns={effective_max_turns} "
                f"max_budget_usd={effective_max_budget:.2f}{track_label}",
                file=sys.stderr,
            )
        except Exception as e:
            print(f"⚠️  wake_override read failed (ignored): {e}", file=sys.stderr)

    # P7: Worktree-per-wake — opt-in per track via config.yaml.
    track_config = _load_track_config(TRACK_DIR)
    worktree_per_wake: bool = bool(track_config.get("worktree_per_wake", False))
    worktree_path: str | None = None

    if worktree_per_wake:
        create_result = _run_scry_script(
            "worktree_create",
            {"track": REFLECT_TRACK, "wake_id": wake_id, "project_root": str(PROJECT_ROOT)},
        )
        if "error" in create_result:
            print(
                f"⚠️  worktree_create failed: {create_result['error']} — "
                f"falling back to no-worktree mode{track_label}",
                file=sys.stderr,
            )
            worktree_per_wake = False
        else:
            worktree_path = create_result["worktree_path"]
            branch_name = create_result.get("branch_name", "?")
            created = create_result.get("created", True)
            action = "created" if created else "resumed"
            print(
                f"   worktree {action}: {Path(worktree_path).relative_to(PROJECT_ROOT)} "
                f"[{branch_name}]{track_label}",
                file=sys.stderr,
            )

    # Agent CWD: worktree when isolated; PROJECT_ROOT otherwise.
    agent_cwd = worktree_path if worktree_path else str(PROJECT_ROOT)

    reset_sleep_state()
    set_budget_caps(effective_max_turns, effective_max_budget)

    # Attribution: inject track author identity and wake provenance into the
    # process environment. GIT_AUTHOR_*/GIT_COMMITTER_* override git config
    # for all commits made in this wake's process tree (harness, SDK subprocess,
    # and every Bash call the agent makes). REFLECT_WAKE_ID is read by the
    # commit-msg hook to inject the Wake-Id trailer.
    _track_email = f"{REFLECT_TRACK}@reflecttech.ai"
    os.environ["GIT_AUTHOR_NAME"] = REFLECT_TRACK
    os.environ["GIT_AUTHOR_EMAIL"] = _track_email
    os.environ["GIT_COMMITTER_NAME"] = REFLECT_TRACK
    os.environ["GIT_COMMITTER_EMAIL"] = _track_email
    os.environ["REFLECT_WAKE_ID"] = wake_id
    os.environ["REFLECT_MODEL"] = MODEL  # model selection; available to subprocesses

    # Ensure the commit-msg hook is in place to inject trailer lines.
    _ensure_commit_msg_hook()

    # For aws_bedrock scheme: pass AWS credential env vars explicitly via
    # ClaudeAgentOptions.env so they survive the SDK subprocess chain even
    # if the process environment doesn't have them set.
    _sdk_env: dict[str, str] = {}
    if _CREDENTIAL_SCHEME == "aws_bedrock":
        for _k in (
            "AWS_PROFILE",
            "AWS_REGION",
            "AWS_DEFAULT_REGION",
            "AWS_ACCESS_KEY_ID",
            "AWS_SECRET_ACCESS_KEY",
            "AWS_SESSION_TOKEN",
        ):
            _v = os.environ.get(_k)
            if _v:
                _sdk_env[_k] = _v

    # The SDK passes a str system_prompt inline as an argv string to the
    # bundled claude binary. Linux caps a single argv string at MAX_ARG_STRLEN
    # (128 KiB); the assembled prompt exceeds it and execve fails with E2BIG.
    # Writing it to a file and passing the file form makes the SDK forward
    # --system-prompt-file, so only the path crosses the argv boundary.
    _system_prompt_path = transcript_dir / "system-prompt.md"
    _system_prompt_path.write_text(build_system_prompt())
    # @scry.bind system-prompt-file-form~f45988bf lesson.wake-e2big-system-prompt~af8f6b21 file form avoids the 128 KiB argv limit

    options = ClaudeAgentOptions(
        system_prompt={"type": "file", "path": str(_system_prompt_path)},
        cwd=agent_cwd,
        add_dirs=_resolve_project_dirs(PROJECT_ROOT),
        model=MODEL,
        max_turns=effective_max_turns,
        max_budget_usd=effective_max_budget,
        permission_mode="acceptEdits",
        env=_sdk_env,
        allowed_tools=[
            "Read",
            "Write",
            "Edit",
            "Glob",
            "Grep",
            "Bash",
            "WebFetch",
            "mcp__reflect-wake__sleep",
            "mcp__reflect-wake__budget",
            "mcp__reflect-wake__pause",
            "mcp__reflect-wake__browser_fetch",
            "mcp__scry__scry_sql",
            "mcp__scry__scry_mint",
            "mcp__reflect-wake__scry_mint_with_check",
            "mcp__reflect-wake__ask",
        ],
        # Wakes do their work in their own loop — no opaque sub-agents.
        # A sub-agent's turns never reach the wake stream, so the originator
        # cannot inspect the reasoning. can_use_tool denies Agent as a
        # guaranteed backstop (allowed_tools is not a hard gate).
        disallowed_tools=["Agent"],
        mcp_servers={
            "reflect-wake": reflect_mcp_server(),
            "scry": {
                "type": "stdio",
                "command": "scry",
                "args": ["serve"],
            },
        },
        can_use_tool=can_use_tool,
        # Enable extended thinking so the agent can deliberate before tool calls
        # and the originator can see that deliberation via the 🧠 stream.
        # ThinkingConfigEnabled is a TypedDict, so construct as a dict literal.
        thinking={"type": "enabled", "budget_tokens": 8000},
    )

    final_result: ResultMessage | None = None
    sleep_observed = False
    sleep_next_wake_seconds: int | None = None  # extracted from sleep tool input
    early_break_reason: str | None = None
    # Initialized here so print/return below have a valid reference even if the
    # finally block is interrupted by an exception before _exit_state is assigned.
    _exit_state: dict = {"called": False, "summary": ""}
    try:
        with transcript_path.open("w") as fh:
            client = ClaudeSDKClient(options=options)
            interrupt_task: asyncio.Task | None = None
            try:
                # Migrate legacy inbox/followup/ → followup/ (P9 sibling layout).
                # Idempotent; no-op if already migrated.
                _migrate_legacy_followup_dir()

                # Solution E: sweep unread inbox messages → followups before briefing.
                # All messages get a followup + consumed atomically (write-then-move).
                # Briefing then shows followup dir as the agent's work queue.
                _sweep_inbox_to_followup(wake_id=wake_id)

                briefing = build_briefing_content(REFLECT_TRACK)
                await client.connect(_as_stream(wake_id, briefing))
                # Start interrupt socket listener as a background task.
                interrupt_task = asyncio.create_task(
                    _listen_interrupt_socket(client),
                    name=f"interrupt-socket-{REFLECT_TRACK}",
                )
                stall_timeout = float(track_config.get("wake_stall_timeout_seconds", 3600))
                try:
                    async for message in _receive_with_stall_timeout(client, stall_timeout):
                        fh.write(json.dumps(_serialize(message), default=str) + "\n")
                        fh.flush()
                        _print_event(message)
                        if isinstance(message, ResultMessage):
                            final_result = message

                        # Track turns + cumulative cost for the budget tool. Every
                        # AssistantMessage represents one model call (turn).
                        if isinstance(message, AssistantMessage):
                            _usage_obj = getattr(message, "usage", None)
                            increment_turn(
                                cost_delta_usd=_cost_from_usage(_usage_obj)
                            )
                            # Emit per-turn context usage for the session TUI gauge.
                            try:
                                if _usage_obj is not None:
                                    _ctx_toks = _ctx_tokens_from_usage(_usage_obj)
                                    _ctx_lim = (
                                        1_000_000
                                        if any(x in MODEL for x in ("1M", "1-million"))
                                        else 200_000
                                    )
                                    emit_event(
                                        "wake.usage",
                                        track=REFLECT_TRACK,
                                        wake_id=wake_id,
                                        payload={
                                            "context_tokens": _ctx_toks,
                                            "context_pct": round(
                                                _ctx_toks / _ctx_lim * 100, 1
                                            ),
                                        },
                                    )
                            except Exception:
                                pass

                        # Detect the agent's sleep tool call. Once observed, break out
                        # after the corresponding tool result (UserMessage) — without
                        # this, the agent can keep calling sleep indefinitely and
                        # burn the entire budget cap on a no-op loop.
                        #
                        # Also track artifact-producing tool calls for the wake-end
                        # artifact summary (_print_artifact_summary):
                        #   • Write / Edit  → file written or edited
                        #   • mcp__reflect__track / mcp__reflect__inbox (action=send)
                        #     → inbox message dispatched; pending_send_ids holds
                        #       tool_use_id → recipient until result arrives
                        if isinstance(message, AssistantMessage):
                            for block in getattr(message, "content", []) or []:
                                if not isinstance(block, ToolUseBlock):
                                    continue
                                # Sleep detection
                                if block.name == "mcp__reflect-wake__sleep":
                                    sleep_observed = True
                                    try:
                                        nwis = block.input.get("next_wake_in_seconds")
                                        if nwis is not None:
                                            sleep_next_wake_seconds = int(nwis)
                                    except Exception:
                                        pass
                                # File write/edit tracking
                                elif block.name in ("Write", "Edit"):
                                    try:
                                        fp = block.input.get("file_path", "")
                                        if fp:
                                            abs_fp = (
                                                fp if Path(fp).is_absolute()
                                                else str(Path(agent_cwd) / fp)
                                            )
                                            _artifact_files.append((abs_fp, block.name))
                                    except Exception:
                                        pass
                                # Inbox send tracking
                                elif block.name in ("mcp__reflect__track", "mcp__reflect__inbox"):
                                    try:
                                        if block.input.get("action") == "send":
                                            recipient = (
                                                block.input.get("to")
                                                or block.input.get("track")
                                                or "?"
                                            )
                                            tool_id = getattr(block, "id", None) or ""
                                            if tool_id:
                                                _pending_send_ids[tool_id] = recipient
                                    except Exception:
                                        pass

                        # Extract inbox-send result paths from UserMessage tool results.
                        # Correlates tool_use_id from AssistantMessage with result content.
                        if isinstance(message, UserMessage) and _pending_send_ids:
                            try:
                                content = getattr(message, "content", None) or []
                                if isinstance(content, list):
                                    for item in content:
                                        item_d = (
                                            item if isinstance(item, dict)
                                            else (vars(item) if hasattr(item, "__dict__") else {})
                                        )
                                        if item_d.get("type") != "tool_result":
                                            continue
                                        tuid = item_d.get("tool_use_id", "")
                                        if tuid not in _pending_send_ids:
                                            continue
                                        recipient = _pending_send_ids.pop(tuid)
                                        # Try to extract .md path from result text
                                        result_content = item_d.get("content", "") or ""
                                        path_found = ""
                                        if isinstance(result_content, list):
                                            for rc in result_content:
                                                rc_text = (
                                                    rc.get("text", "") if isinstance(rc, dict)
                                                    else str(rc)
                                                )
                                                import re as _re
                                                m = _re.search(r"/[^\s]+\.md", rc_text)
                                                if m:
                                                    path_found = m.group(0)
                                                    break
                                        elif isinstance(result_content, str):
                                            import re as _re
                                            m = _re.search(r"/[^\s]+\.md", result_content)
                                            if m:
                                                path_found = m.group(0)
                                        _artifact_inbox_sent.append(
                                            (recipient, path_found or "(path unavailable)")
                                        )
                            except Exception:
                                pass

                        if sleep_observed and isinstance(message, UserMessage):
                            early_break_reason = "sleep observed; loop terminated by wake.py"
                            break

                        # Stop-requested check: fires between SDK messages (not mid-tool-call).
                        # The originator touches agent/runtime/tracks/{track}/stop.requested to
                        # request a graceful abort. We check here so a tool call in flight
                        # finishes before we exit — "abort" means "don't start another iteration."
                        stop_file = TRACK_DIR / "stop.requested"
                        if stop_file.exists():
                            early_break_reason = "stop requested by originator"
                            try:
                                stop_file.unlink()
                            except FileNotFoundError:
                                pass
                            break

                        # Pause-requested check: cooperative pause at a safe checkpoint.
                        # The originator (or the agent itself via mcp__reflect-wake__pause)
                        # touches pause.requested. The process stays alive; the LLM session
                        # (Claude Code subprocess) is idle while we poll. Resume by removing
                        # pause.requested (via `reflect wake resume` or MCP wake(action=resume)).
                        #
                        # Semantics:
                        #   - Flag is in-process: if the wake crashes while paused, the next
                        #     wake is a fresh start (no auto-resume).
                        #   - Stop during pause: honoured — breaks out of both loops.
                        #   - Multiple pause requests: idempotent (already paused → still paused).
                        #   - Inbox during pause: accumulates; read on resume (no auto-fire).
                        pause_file = TRACK_DIR / "pause.requested"
                        if pause_file.exists():
                            print(f"⏸  paused [{REFLECT_TRACK}] — waiting for `reflect wake resume {REFLECT_TRACK}`", file=sys.stderr)
                            try:
                                mark_paused(REFLECT_TRACK, wake_id)
                            except Exception as _pe:
                                print(f"⚠️  mark_paused failed (non-fatal): {_pe}", file=sys.stderr)
                            try:
                                emit_event("track.paused", track=REFLECT_TRACK, wake_id=wake_id, payload={})
                            except Exception:
                                pass

                            _paused = True
                            while _paused:
                                await asyncio.sleep(1)
                                # Stop check inside pause loop
                                _stop_inner = TRACK_DIR / "stop.requested"
                                if _stop_inner.exists():
                                    early_break_reason = "stop requested while paused"
                                    try:
                                        _stop_inner.unlink()
                                    except FileNotFoundError:
                                        pass
                                    _paused = False
                                elif not pause_file.exists():
                                    # Resume signal received
                                    _paused = False

                            if early_break_reason:
                                # Stop-during-pause: exit the outer message loop
                                break

                            # Resumed normally
                            print(f"▶  resumed [{REFLECT_TRACK}]", file=sys.stderr)
                            try:
                                mark_running(REFLECT_TRACK, wake_id)
                            except Exception as _re:
                                print(f"⚠️  mark_running on resume failed (non-fatal): {_re}", file=sys.stderr)
                            try:
                                emit_event("track.running", track=REFLECT_TRACK, wake_id=wake_id, payload={
                                    "pid": os.getpid(),
                                })
                            except Exception:
                                pass

                except asyncio.TimeoutError as _te:
                    early_break_reason = f"stall: {_te}"
                    print(f"⚠️  stall watchdog fired: {_te}", file=sys.stderr)
            finally:
                # Cancel interrupt socket listener (cleans up socket file in its own finally).
                if interrupt_task is not None and not interrupt_task.done():
                    interrupt_task.cancel()
                    try:
                        await interrupt_task
                    except (asyncio.CancelledError, Exception):
                        pass
                # Disconnect the SDK client cleanly.
                try:
                    await client.disconnect()
                except Exception:
                    pass
    finally:
        # P7: Worktree promotion — only on clean sleep (agent called sleep tool).
        # On non-clean exits (exception, budget cap, stop-request) we leave the
        # worktree intact so the next wake can inspect or continue from it.
        if worktree_per_wake and worktree_path and sleep_observed:
            try:
                print(f"   promoting worktree{track_label}…", file=sys.stderr)
                promote_result = _run_scry_script(
                    "worktree_promote",
                    {"track": REFLECT_TRACK, "wake_id": wake_id, "project_root": str(PROJECT_ROOT)},
                )
                if "error" in promote_result and "status" not in promote_result:
                    print(
                        f"⚠️  worktree_promote error: {promote_result['error']}{track_label}",
                        file=sys.stderr,
                    )
                elif promote_result.get("status") == "clean":
                    merged_sha = promote_result.get("merged_sha", "?")
                    print(
                        f"   worktree promoted cleanly → {merged_sha}{track_label}",
                        file=sys.stderr,
                    )
                    # Event stream: emit commit.made for the promoted worktree merge.
                    emit_event("commit.made", track=REFLECT_TRACK, wake_id=wake_id, payload={
                        "sha": merged_sha,
                        "message": f"[worktree promote] {wake_id}",
                        "branch": "main",
                        "repo_path": str(PROJECT_ROOT),
                        "files": promote_result.get("files", []),
                        "additions": promote_result.get("additions", 0),
                        "deletions": promote_result.get("deletions", 0),
                    })
                    cleanup_result = _run_scry_script(
                        "worktree_cleanup",
                        {
                            "worktree_path": worktree_path,
                            "project_root": str(PROJECT_ROOT),
                            "delete_branch": True,
                        },
                    )
                    if cleanup_result.get("removed"):
                        print(f"   worktree cleaned up{track_label}", file=sys.stderr)
                    else:
                        reason = cleanup_result.get("reason") or cleanup_result.get("error", "unknown")
                        print(
                            f"⚠️  worktree_cleanup: {reason}{track_label}",
                            file=sys.stderr,
                        )
                    _advance_last_known_good(PROJECT_ROOT)
                else:
                    # Conflict: file report + schedule conflict-resolution wake
                    conflicts = promote_result.get("conflicts", [])
                    print(
                        f"⚠️  worktree promotion conflict: {len(conflicts)} file(s){track_label}",
                        file=sys.stderr,
                    )
                    _file_promotion_blocked_report(
                        REFLECT_TRACK, wake_id, conflicts, TRACK_DIR
                    )
                    # Conflict-resolution wake: reduced budget, fire immediately
                    try:
                        import yaml as _yaml
                        wake_override_path = TRACK_DIR / "wake_override.yaml"
                        wake_override_path.write_text(
                            _yaml.dump({"max_turns": 25, "max_budget_usd": 1.50})
                        )
                    except Exception as ov_err:
                        print(
                            f"⚠️  could not write wake_override.yaml: {ov_err}",
                            file=sys.stderr,
                        )
                    # Force immediate next wake (backlog override will pick this up)
                    override_ts = int(time.time()) - 1
                    try:
                        NEXT_WAKE_BY.write_text(f"{override_ts}\n")
                    except Exception as ts_err:
                        print(
                            f"⚠️  could not write next-wake-by for conflict resolution: {ts_err}",
                            file=sys.stderr,
                        )
                    print(
                        f"   conflict-resolution wake scheduled (25t/$1.50){track_label}",
                        file=sys.stderr,
                    )
            except Exception as promote_exc:
                print(
                    f"⚠️  worktree post-wake hook exception: {promote_exc}{track_label}",
                    file=sys.stderr,
                )

        # Artifact summary — print to stdout before any other cleanup.
        # Substrate-enforced; agent cannot skip. stdout only (not stderr).
        try:
            _print_artifact_summary(
                wake_id=wake_id,
                track=REFLECT_TRACK,
                files_written=_artifact_files,
                inbox_sent=_artifact_inbox_sent,
                wake_start_sha=_wake_start_git_head,
            )
        except Exception as _ae:
            # Non-fatal: a broken summary must not crash the wake cleanup path.
            print(f"⚠️  artifact-summary failed (non-fatal): {_ae}", file=sys.stderr)

        # Always write the completion timestamp, even on exception. Without
        # this, a crashing wake leaves a stale timestamp and the cron loop
        # re-fires the same signal every minute — the doom loop we just escaped.
        ended_at = int(time.time())
        try:
            LAST_WAKE_TIMESTAMP.write_text(f"{ended_at}\n")
        except Exception as e:
            print(f"⚠️  failed to write last-wake.timestamp: {e}", file=sys.stderr)
        # next-wake-by is the agent's choice. If the agent wrote one during
        # the wake, it stays. If not, the file is absent (cleared at start)
        # and the loop pauses until an external signal arrives.
        # Cadence floor: clamp to +300s when actionable work exists and the
        # agent scheduled longer (or no wake at all). Preserves agency in the
        # genuinely-blocked case; catches drift automatically.
        try:
            _apply_cadence_floor()
        except Exception as e:
            print(f"⚠️  cadence-floor check failed (non-fatal): {e}", file=sys.stderr)
        # Backlog override: if the track has un-drained originator inbox or
        # unfinished followups, force next wake to immediate regardless of what
        # the agent or cadence-floor wrote. Runs after cadence-floor so it wins.
        try:
            _apply_backlog_override()
        except Exception as e:
            print(f"⚠️  backlog-override check failed (non-fatal): {e}", file=sys.stderr)
        # Work-produced guard: if this wake made any git commits, force a
        # follow-up wake in 60s so the agent can confirm no work is still open.
        # Runs after backlog-override (backlog override may have already set
        # immediate; if so, 60s is still reasonable as a lower bound).
        try:
            _apply_work_produced_guard(_wake_start_git_head)
        except Exception as e:
            print(f"⚠️  work-produced-guard check failed (non-fatal): {e}", file=sys.stderr)
        # Dormant wake backoff: classify this wake as dormant or productive, then
        # clamp next-wake-by upward with exponential backoff for consecutive dormant
        # wakes.  Runs last so it can read the final next-wake-by value written by
        # the guards above — it clamps UP, never down, and yields to backlog-override
        # when that has already set immediate (<=now).
        # See design.dormant-wake-detection~cd9f495c for the full rationale.
        try:
            _dormant = _is_wake_dormant(
                _wake_start_git_head,
                _artifact_files,
                _artifact_inbox_sent,
            )
            _apply_dormant_backoff(_dormant)
        except Exception as e:
            print(f"⚠️  dormant-backoff check failed (non-fatal): {e}", file=sys.stderr)

        # Push wake.md snapshot to the terminal portal (main track only).
        # The portal reads wake_md_snapshot from D1 and prepends it to the
        # chat system prompt (5-min TTL). Running post-wake keeps the portal
        # in sync whenever wake.md changes without a separate cron job.
        if REFLECT_TRACK == "main":
            try:
                from .scripts.push_wake_snapshot import push as _push_wake_snapshot
                _push_wake_snapshot()
            except Exception as e:
                print(f"⚠️  push-wake-snapshot failed (non-fatal): {e}", file=sys.stderr)

        # Append wake metrics to the runtime's audit ledger. Source of truth for
        # cost/turns even when the wake exits via exception — final_result
        # may be missing, so fall back to our own tracked counters.
        # Initialize here so they're always defined for the event emitter below.
        num_turns = None
        cost_usd = None
        try:
            from .tools import budget_state as _bs

            slept_clean = 1 if sleep_observed else 0
            if final_result is not None:
                num_turns = getattr(final_result, "num_turns", None)
                cost_usd = getattr(final_result, "total_cost_usd", None)
            if num_turns is None or cost_usd is None:
                bs = _bs()
                if num_turns is None:
                    num_turns = bs["turns_used"]
                if cost_usd is None:
                    cost_usd = bs["cost_used_usd"]

            if not WAKES_TSV.exists():
                WAKES_TSV.write_text(WAKES_TSV_HEADER)
            with WAKES_TSV.open("a") as fh:
                fh.write(
                    f"{wake_id}\t{REFLECT_TRACK}\t{started_at}\t{ended_at}\t{slept_clean}\t"
                    f"{num_turns}\t{cost_usd:.6f}\t{early_break_reason or ''}\t"
                    f"{transcript_path.relative_to(PROJECT_ROOT)}\n"
                )
        except Exception as e:
            print(f"⚠️  failed to append wakes.tsv: {e}", file=sys.stderr)

        # Event stream: emit wake.completed or wake.failed.
        # NOTE: Inside the finally block so it emits on ALL exit paths, including
        # exceptions that propagate out of the agent loop before the normal return.
        _exit_state = sleep_state()
        try:
            duration_seconds = ended_at - started_at
            if _exit_state["called"]:
                _wake_summary = _exit_state.get("summary") or ""
                emit_event("wake.completed", track=REFLECT_TRACK, wake_id=wake_id, payload={
                    "duration_seconds": duration_seconds,
                    "cost_usd": cost_usd,
                    "num_turns": num_turns,
                    "summary": _wake_summary,
                })
                if sleep_next_wake_seconds is not None and sleep_next_wake_seconds > 0:
                    next_at_ts = ended_at + sleep_next_wake_seconds
                    next_at_iso = datetime.fromtimestamp(next_at_ts, tz=timezone.utc).strftime(
                        "%Y-%m-%dT%H:%M:%SZ"
                    )
                    emit_event("wake.scheduled", track=REFLECT_TRACK, wake_id=wake_id, payload={
                        "next_wake_at": next_at_iso,
                        "next_wake_in_seconds": sleep_next_wake_seconds,
                        "reason": "agent sleep call",
                    })
            else:
                emit_event("wake.failed", track=REFLECT_TRACK, wake_id=wake_id, payload={
                    "duration_seconds": duration_seconds,
                    "early_break_reason": early_break_reason or "no sleep call",
                })
        except Exception as _ee:
            print(f"⚠️  events: wake exit event failed (non-fatal): {_ee}", file=sys.stderr)

        # Status channel (DR6): update status.json to idle or unhealthy based on exit.
        try:
            if _exit_state["called"]:
                mark_idle(REFLECT_TRACK, _exit_state.get("summary") or "")
                emit_event("track.idle", track=REFLECT_TRACK, wake_id=wake_id, payload={
                    "summary": _exit_state.get("summary") or "",
                })
            else:
                # Determine exit reason from early_break_reason if available
                if early_break_reason and "stop" in early_break_reason.lower():
                    _exit_reason = "signal"
                elif early_break_reason and "budget" in early_break_reason.lower():
                    _exit_reason = "budget"
                else:
                    _exit_reason = "error"
                mark_unhealthy(REFLECT_TRACK, _exit_reason, error=early_break_reason, wake_id=wake_id)
        except Exception as _se:
            print(f"⚠️  status.json exit update failed (non-fatal): {_se}", file=sys.stderr)

        # Remove PID lock file so next wake can acquire it.
        try:
            _wake_lock_file = TRACK_DIR / "wake.lock"
            if _wake_lock_file.exists():
                _wake_lock_file.unlink()
        except Exception as _wle:
            print(f"⚠️  failed to remove wake.lock: {_wle}", file=sys.stderr)

    # _exit_state was assigned inside the finally block. Falls back to the default
    # {"called": False, "summary": ""} if the finally block was interrupted by a
    # secondary exception before _exit_state = sleep_state() was reached.
    state = _exit_state

    # If a signal was received and no other early_break_reason was set, record it.
    if _sig_received and not early_break_reason:
        early_break_reason = f"signal:{_sig_received[0]}"

    print("", file=sys.stderr)
    if state["called"]:
        print(f"💤 sleep: {state['summary']}", file=sys.stderr)
    else:
        print("⚠️  wake exited without calling sleep — hit a cap or other stop", file=sys.stderr)
    if early_break_reason:
        print(f"   {early_break_reason}", file=sys.stderr)

    if final_result is not None:
        cost = getattr(final_result, "total_cost_usd", None)
        if cost is not None:
            print(f"   cost: ${cost:.4f}", file=sys.stderr)
        turns = getattr(final_result, "num_turns", None)
        if turns is not None:
            print(f"   turns: {turns}", file=sys.stderr)

    # Log next-wake-by timestamp so the originator can see it in the tail log
    try:
        if NEXT_WAKE_BY.exists():
            ts_raw = NEXT_WAKE_BY.read_text().strip()
            ts_unix = int(ts_raw)
            now_unix = int(datetime.now(timezone.utc).timestamp())
            delta = ts_unix - now_unix
            if delta >= 0:
                mins, secs = divmod(delta, 60)
                hours, mins = divmod(mins, 60)
                if hours:
                    rel = f"in {hours}h{mins:02d}m{secs:02d}s"
                elif mins:
                    rel = f"in {mins}m{secs:02d}s"
                else:
                    rel = f"in {secs}s"
            else:
                rel = "immediate / past"
            ts_iso = datetime.fromtimestamp(ts_unix, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            print(f"   next-wake-by: {ts_iso} ({rel})", file=sys.stderr)
        else:
            print("   next-wake-by: not set (paused; fires only on external signal)", file=sys.stderr)
    except Exception as e:
        print(f"   next-wake-by: (read failed: {e})", file=sys.stderr)

    return 0 if state["called"] else 1


def main() -> int:
    return asyncio.run(_run_wake())


if __name__ == "__main__":
    sys.exit(main())
