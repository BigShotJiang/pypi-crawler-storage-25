"""Permission gate for autonomous wakes.

The SDK already scopes file ops and Bash to `cwd`. This hook adds a thin
layer of deny rules for shell commands that are dangerous even within the
working directory: git push, hard resets, branch manipulation that leaves
the wake's work in limbo. Also enforces authority domain gates G1 and G4.

Everything else is allowed by default — the safety net is git history
(originator can revert) plus the per-wake token/iteration caps.
"""
from typing import Any

from claude_agent_sdk import (
    PermissionResultAllow,
    PermissionResultDeny,
    ToolPermissionContext,
)

from agent.runtime.authority_domains import (
    G1_BLOCKED_DEPLOY_INDICATORS,
    G4_BLOCKED_BASH_PATTERNS,
    LIVE_KEY_PATH_PATTERNS,
    SANCTIONED_PAYMENTS_TRACK,
)


_FORBIDDEN_BASH_PATTERNS = (
    "git push",  # never push; affects shared state
    "rm -rf /",
    "rm -rf ~",
    "sudo ",
)


# Files the agent must not modify. The shim under bin/ is the rollback escape
# hatch; modifying it defeats recovery. Identity files reshape who reflection
# is — proposed changes go in the report under "what's still open" for
# originator review.
_FORBIDDEN_WRITE_PATHS = (
    "bin/reflect-wake",
    "bin/reflect-tick",
    "bin/reflect-dispatch",
    "concept.md",
    "wake.md",
    "principles.md",
    "authority.md",
    "agent/runtime/authority_domains.py",
    "agent/runtime/hooks.py",
    "agent/runtime/wake.py",
    "agent/runtime/tools.py",
    "agent/design/reflection.md",
    "agent/driver.yaml",
)


def _gate_g1_read(path: str, track_name: str) -> PermissionResultDeny | None:
    """
    G1 — Live Payment Credentials gate for Read tool calls.

    Blocks live Stripe key file access for all tracks except the
    SANCTIONED_PAYMENTS_TRACK. With an empty sanctioned slot, all tracks
    are blocked — correct enforcement posture before any track is whitelisted.

    FR: authority.md G1. Companion constants in authority_domains.py.
    """
    path_matches = any(pat in path for pat in LIVE_KEY_PATH_PATTERNS)
    if not path_matches:
        return None
    if SANCTIONED_PAYMENTS_TRACK and track_name == SANCTIONED_PAYMENTS_TRACK:
        return None  # sanctioned track may read live key files
    return PermissionResultDeny(
        message=(
            f"G1 — live key path access blocked: {path}. "
            f"Only {SANCTIONED_PAYMENTS_TRACK!r} may read live Stripe key "
            "files. SANCTIONED_PAYMENTS_TRACK is empty until the originator "
            "resolves the A/B track-structure question. Update "
            "authority_domains.py when authorized."
        ),
        interrupt=False,
    )


def _gate_g1_bash(cmd: str) -> PermissionResultDeny | None:
    """
    G1 — Live Payment Credentials gate for Bash tool calls.

    Blocks deploying live-payment / paywall code if the command references
    live-key indicators alongside deploy indicators.

    FR: authority.md G1. Companion constants in authority_domains.py.
    """
    has_live_key_ref = any(pat in cmd for pat in LIVE_KEY_PATH_PATTERNS)
    has_deploy_indicator = any(
        ind in cmd for ind in G1_BLOCKED_DEPLOY_INDICATORS
    )
    if has_live_key_ref and has_deploy_indicator:
        return PermissionResultDeny(
            message=(
                "G1 — live-payment deploy blocked. Deploying or charging with "
                "live credentials requires originator authorization and a "
                "sanctioned track. This command references live key paths "
                "alongside a deploy indicator, which is blocked until G1 "
                "enforcement is confirmed live and authority.md is created."
            ),
            interrupt=False,
        )
    return None


def _gate_g4_bash(cmd: str, track_name: str) -> PermissionResultDeny | None:
    """
    G4 — Wake and Enable Authority gate for Bash tool calls.

    Wakes may not start or enable other tracks via Bash. Queue work to the
    target's inbox and surface the request in the wake report; the originator
    enables tracks.

    Exception: the originator track is not subject to G4.

    FR: authority.md G4. Companion constants in authority_domains.py.
    """
    if track_name == "originator":
        return None
    for pattern in G4_BLOCKED_BASH_PATTERNS:
        if pattern in cmd:
            return PermissionResultDeny(
                message=(
                    "G4 — wake/enable authority gate: wakes may not start or "
                    "enable other tracks. Queue work to the target's inbox and "
                    "surface the request in your wake report. The originator "
                    "enables."
                ),
                interrupt=False,
            )
    return None


def _gate_g4_mcp(
    tool_name: str, tool_input: dict[str, Any], track_name: str
) -> PermissionResultDeny | None:
    """
    G4 — Wake and Enable Authority gate for MCP tool calls.

    Blocks mcp__reflect__wake(action="start") and
    mcp__reflect__track_admin(action="enable") for all non-originator tracks.

    FR: authority.md G4. Companion constants in authority_domains.py.
    """
    if track_name == "originator":
        return None
    if tool_name == "mcp__reflect__wake":
        if tool_input.get("action") == "start":
            return PermissionResultDeny(
                message=(
                    "G4 — wake/enable authority gate: wakes may not start "
                    "other tracks. Queue work to the target's inbox and "
                    "surface the request in your wake report. The originator "
                    "enables."
                ),
                interrupt=False,
            )
    if tool_name == "mcp__reflect__track_admin":
        if tool_input.get("action") == "enable":
            return PermissionResultDeny(
                message=(
                    "G4 — wake/enable authority gate: wakes may not enable "
                    "other tracks. Queue work to the target's inbox and "
                    "surface the request in your wake report. The originator "
                    "enables."
                ),
                interrupt=False,
            )
    return None


async def can_use_tool(
    tool_name: str, tool_input: dict[str, Any], context: ToolPermissionContext
) -> PermissionResultAllow | PermissionResultDeny:
    # Resolve current track name from context, defaulting to empty string.
    track_name: str = getattr(context, "track_name", "") or ""

    if tool_name == "Agent":
        return PermissionResultDeny(
            message=(
                "Sub-agents are forbidden in wakes. A sub-agent's turns never "
                "reach the wake stream, so the originator cannot inspect the "
                "reasoning. Do the work yourself, in this loop — read, write, "
                "and reason directly so every step is visible."
            ),
            interrupt=False,
        )

    if tool_name == "Bash":
        cmd = tool_input.get("command", "")

        # Existing forbidden pattern checks.
        for pattern in _FORBIDDEN_BASH_PATTERNS:
            if pattern in cmd:
                return PermissionResultDeny(
                    message=(
                        f"Command blocked by reflection's wake bounds: pattern "
                        f"{pattern!r} is forbidden in autonomous wakes. If this "
                        "is genuinely needed, surface it in the report under "
                        "'what's still open' and the originator can run it next "
                        "session."
                    ),
                    interrupt=False,
                )

        # G1: live-payment deploy gate.
        if deny := _gate_g1_bash(cmd):
            return deny

        # G4: wake/enable authority gate.
        if deny := _gate_g4_bash(cmd, track_name):
            return deny

    if tool_name == "Read":
        path = tool_input.get("file_path", "")
        # G1: live key path access gate.
        if deny := _gate_g1_read(path, track_name):
            return deny

    if tool_name in ("Write", "Edit"):
        path = tool_input.get("file_path", "")
        for forbidden in _FORBIDDEN_WRITE_PATHS:
            # Match either a direct hit or a hit inside a sandbox worktree
            # (sandbox paths look like agent/runtime/.sandbox-<id>/<forbidden>).
            if path.endswith(forbidden) or f"/{forbidden}" in path:
                return PermissionResultDeny(
                    message=(
                        f"Write blocked: {forbidden} is off-limits to the "
                        "agent. If you need to change it, surface a proposal "
                        "in your report's 'What's still open' section."
                    ),
                    interrupt=False,
                )

    # G4: MCP wake/enable gate.
    if deny := _gate_g4_mcp(tool_name, tool_input, track_name):
        return deny

    return PermissionResultAllow()
