"""ScreenSearchSystem — S-expression query language over screening data.

Operators::

    (kind "diff")           — items matching directive kind (substring)
    (category "issue")      — items in a category
    (type "diverge")        — items matching issue/warning type (substring)
    (issues)                — shorthand for (category "issue")
    (warnings)              — shorthand for (category "warning")
    (danglings)             — shorthand for (category "dangling")
    (focus "engine.")       — namespace prefix filter
    (consistent)            — True if no issues
    (ns)                    — all top-level namespaces as text
    (find "pattern")        — regex search over item names (enriched strings)
    (fuzzy "query")         — ranked substring search over item names

Registered as ``(scope screen ...)`` in the main search system.
Also accepts ``(scope diagnose ...)`` as an alias.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from parseltongue.core.atoms import Symbol
from parseltongue.core.system import System

from .bench_system import BenchSubsystem

if TYPE_CHECKING:
    from ..screen import Screen, ScreenItem


class ScreenSearchSystem:
    """Parseltongue System with posting-set operators over screening data."""

    tag = Symbol("dx")

    def __init__(self, dx: "Screen"):
        from parseltongue.core.quote_verifier.index import DocumentIndex

        self._idx = DocumentIndex()
        self._dx = dx

        # Group items by category → each category becomes a "document"
        by_cat: dict[str, list[str]] = {}
        for item in dx._items:
            kind_str = f"[{item.kind}] " if item.kind else ""
            detail_str = f": {item.detail}" if item.detail else ""
            line = f"{item.name} {kind_str}{item.type}{detail_str}"
            by_cat.setdefault(item.category, []).append(line)
        for cat, lines in by_cat.items():
            self._idx.add(cat, "\n".join(lines))

        # Build item lookup by (category_doc, line_number)
        self._item_index: dict[tuple[str, int], "ScreenItem"] = {}
        for item in dx._items:
            cat = item.category
            cat_items = [i for i in dx._items if i.category == cat]
            line_num = cat_items.index(item) + 1
            self._item_index[(cat, line_num)] = item
        item_index = self._item_index

        idx = self._idx

        def _posting(key: tuple[str, int]) -> dict:
            doc = idx.documents.get(key[0])
            if not doc:
                return {}
            lines = doc.original_text.splitlines()
            if key[1] > len(lines):
                return {}
            return {
                "document": key[0],
                "line": key[1],
                "column": 1,
                "context": lines[key[1] - 1],
                "callers": [],
                "total_callers": 0,
            }

        def _kind(kind_pattern, posting=None):
            if posting is None:
                return {
                    k: _posting(k)
                    for k, it in item_index.items()
                    if it.kind and kind_pattern in it.kind and _posting(k)
                }
            return {
                k: v
                for k, v in posting.items()
                if k in item_index and item_index[k].kind is not None and kind_pattern in str(item_index[k].kind)
            }

        def _category(cat_name, posting=None):
            if posting is None:
                return {k: _posting(k) for k, it in item_index.items() if it.category == cat_name and _posting(k)}
            return {k: v for k, v in posting.items() if k in item_index and item_index[k].category == cat_name}

        def _type(type_pattern, posting=None):
            if posting is None:
                return {k: _posting(k) for k, it in item_index.items() if type_pattern in it.type and _posting(k)}
            return {k: v for k, v in posting.items() if k in item_index and type_pattern in item_index[k].type}

        def _issues():
            return _category("issue")

        def _warnings():
            return _category("warning")

        def _danglings():
            return _category("dangling")

        def _loader():
            return _category("loader")

        def _focus(prefix, posting=None):
            if posting is None:
                return {k: _posting(k) for k, it in item_index.items() if it.name.startswith(prefix) and _posting(k)}
            return {k: v for k, v in posting.items() if k in item_index and item_index[k].name.startswith(prefix)}

        def _consistent():
            return dx._consistent

        def _ns():
            return ", ".join(sorted(dx._all_namespaces))

        # Also build a name-keyed index for find/fuzzy
        self._name_idx = DocumentIndex()
        for item in dx._items:
            if item.name not in self._name_idx.documents:
                kind_str = f"[{item.kind}] " if item.kind else ""
                detail_str = f": {item.detail}" if item.detail else ""
                self._name_idx.add(item.name, f"{item.category} {kind_str}{item.type}{detail_str}")

        def _find(pattern, max_results=50):
            """Regex search over item names — returns posting set."""
            import re as _re_mod

            rx = _re_mod.compile(str(pattern))
            matches = set(sorted(n for n in sys._name_idx.documents if rx.search(n))[: int(max_results)])
            return {k: _posting(k) for k, it in item_index.items() if it.name in matches and _posting(k)}

        def _fuzzy(query, max_results=10):
            """Ranked substring search over item names — returns posting set."""
            query_lower = str(query).lower()
            scored = []
            for name in sys._name_idx.documents:
                name_lower = name.lower()
                if query_lower not in name_lower:
                    continue
                if name_lower == query_lower:
                    score = 0
                elif name_lower.endswith(query_lower):
                    score = 1
                elif name_lower.startswith(query_lower):
                    score = 2
                else:
                    score = 3
                scored.append((score, len(name), name))
            scored.sort()
            matches = {name for _, _, name in scored[: int(max_results)]}
            return {k: _posting(k) for k, it in item_index.items() if it.name in matches and _posting(k)}

        sys = self  # capture for closures

        ops = {
            Symbol("kind"): _kind,
            Symbol("category"): _category,
            Symbol("type"): _type,
            Symbol("issues"): _issues,
            Symbol("warnings"): _warnings,
            Symbol("danglings"): _danglings,
            Symbol("loader"): _loader,
            Symbol("focus"): _focus,
            Symbol("consistent"): _consistent,
            Symbol("ns"): _ns,
            Symbol("find"): _find,
            Symbol("fuzzy"): _fuzzy,
        }
        self._system = System(initial_env=ops, name="ScreenSearch")
        self.posting_morphism = self._DxPostingMorphism(self._item_index)
        self.ops_morphism = self._DxOpsMorphism()

        _raw_eval = self._system.evaluate
        _to_dx = self._posting_to_dx

        def _sexp_evaluate(expr):
            result = _raw_eval(expr)
            if isinstance(result, dict):
                return _to_dx(result)
            return result

        self._system.evaluate = _sexp_evaluate  # type: ignore[method-assign, assignment]

    def _enrich(self, name: str) -> str:
        """Enrich a name with category, type, and location."""
        for item in self._dx._items:
            if item.name == name:
                return f"{name}  {item.category}/{item.type}  {item.loc}"
        return name

    def find(self, pattern: str, max_results: int = 50) -> list[str]:
        """Regex search over item names via the index."""
        import re as _re

        rx = _re.compile(pattern)
        names = sorted(n for n in self._name_idx.documents if rx.search(n))[:max_results]
        return [self._enrich(n) for n in names]

    def fuzzy(self, query: str, max_results: int = 10) -> list[str]:
        """Ranked substring search over item names via the index."""
        query_lower = query.lower()
        scored = []
        for name in self._name_idx.documents:
            name_lower = name.lower()
            if query_lower not in name_lower:
                continue
            if name_lower == query_lower:
                score = 0
            elif name_lower.endswith(query_lower):
                score = 1
            elif name_lower.startswith(query_lower):
                score = 2
            else:
                score = 3
            scored.append((score, len(name), name))
        scored.sort()
        return [self._enrich(name) for _, _, name in scored[:max_results]]

    def evaluate(self, expr, local_env=None):
        """Evaluate a query — string or s-expression."""
        if isinstance(expr, str):
            from parseltongue.core.lang import PGStringParser

            parsed = PGStringParser.translate(expr)
            if isinstance(parsed, str):
                results = self._idx.search(parsed)
                return {(r["document"], r["line"]): r for r in results}
            return self._system.evaluate(parsed)
        return self._system.evaluate(expr)

    class _DxOpsMorphism:
        """OpsMorphism: dx identity is name (form[1])."""

        __slots__ = ()

        def key(self, form):
            return form[1]

    class _DxPostingMorphism:
        """PostingMorphism: posting ↔ dx forms."""

        def __init__(self, item_index):
            self._item_index = item_index

        def transform(self, posting: dict) -> list:
            from parseltongue.core.atoms import Symbol

            tag = Symbol("dx")
            result = []
            for key in posting:
                item = self._item_index.get(key)
                if not item:
                    continue
                result.append([tag, item.name, item.category, item.kind or "", item.type, item.detail or ""])
            return result

        def inverse(self, forms: list) -> dict:
            from parseltongue.core.atoms import Symbol

            tag = Symbol("dx")
            posting: dict = {}
            for item in forms:
                if not isinstance(item, (list, tuple)) or len(item) < 2:
                    continue
                if not (isinstance(item[0], Symbol) and BenchSubsystem.matches_tag(item[0], tag)):
                    continue
                name = str(item[1])
                category = str(item[2]) if len(item) > 2 else ""
                detail = str(item[5]) if len(item) > 5 else ""
                posting[(name, 1)] = {
                    "document": name,
                    "line": 1,
                    "column": 1,
                    "context": f"{category}: {detail}" if detail else category,
                    "callers": [],
                    "total_callers": 0,
                }
            return posting

    def _posting_to_dx(self, posting: dict) -> list:
        return self.posting_morphism.transform(posting)
