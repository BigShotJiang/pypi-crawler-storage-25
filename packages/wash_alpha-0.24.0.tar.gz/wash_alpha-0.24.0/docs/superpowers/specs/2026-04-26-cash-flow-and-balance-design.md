# Cash Flow & Balance Tracking — Design

**Date:** 2026-04-26
**Status:** Draft (spec phase)
**Scope:** Add running cash balance, net-contributions-vs-growth, and cash-share-of-portfolio tracking. Persist non-trade Schwab CSV rows that the parser currently discards. Surface the new data in the existing Portfolio web page.

## Goals

1. Show the user a **running cash balance** over time per account, derived from broker CSV events.
2. Show **net external contributions vs. portfolio growth** so the user can answer "of my account's value, how much did I deposit vs. earn?"
3. Show **cash as a share of total account value** in the existing allocation donut.

## Non-goals

- Separate "Income" page or dividend-by-ticker breakdown. Data is persisted to enable a future spec; not visualized here.
- Backfill of pre-CSV history. The user imports full account history; starting balance = $0.
- Multi-currency support. Schwab CSVs are USD only.
- Reconciliation against Schwab's online balance display. Numbers are derived from imported events; there is no live broker API.

## Definition of "cash"

Schwab1 cash sweep account only. The `Futures MM Sweep` action moves money between Schwab1 and the futures sub-account; sweeps OUT count as outflows and sweeps IN count as inflows. This matches how Schwab's own balance display reads.

## Data model

### New table: `cash_events`

| Column | Type | Notes |
|---|---|---|
| `id` | int PK | |
| `import_id` | int FK→`imports` | same import lineage as trades; supports `imports rm` cleanup |
| `account_id` | int FK→`accounts` | per-account scoping reuses existing toolbar |
| `event_date` | str (YYYY-MM-DD) | as-is from broker; no timezone conversion (matches `trades.trade_date`) |
| `kind` | str | `transfer_in` · `transfer_out` · `dividend` · `interest` · `fee` · `sweep_in` · `sweep_out` |
| `amount` | float | always positive; sign comes from `kind` |
| `ticker` | str nullable | populated for `dividend` and `fee` (e.g. ADR Mgmt Fee, Foreign Tax Paid) |
| `description` | str | raw broker text for traceability and disambiguating rows on the same date |
| `natural_key` | str | SHA256 of `(account_id, event_date, kind, amount, ticker, description)` |

**Indexes:** `(account_id, event_date)`, `natural_key` unique-per-account.

**Constraint:** `UNIQUE(account_id, natural_key)` for idempotent re-import (same as `trades`).

### Schwab parser additions

The parser at `src/net_alpha/brokers/schwab.py` currently `continue`s on non-trade rows (lines 124–126). Extend it to emit `CashEvent` objects in parallel with `Trade` objects.

| Schwab `Action` | `CashEvent.kind` | Sign source |
|---|---|---|
| `MoneyLink Transfer` | `transfer_in` / `transfer_out` | sign of CSV `Amount` |
| `Wire Received` / `Wire Sent` | `transfer_in` / `transfer_out` | sign of CSV `Amount` |
| `Futures MM Sweep` | `sweep_in` / `sweep_out` | sign of CSV `Amount` |
| `Qualified Dividend` | `dividend` | always + |
| `Non-Qualified Div` | `dividend` | always + |
| `Pr Yr Non-Qual Div` | `dividend` | always + (prior-year reclassification) |
| `Cash Dividend` | `dividend` | always + |
| `Cash In Lieu` | `dividend` | always + (cash from fractional-share corporate actions) |
| `Credit Interest` | `interest` | always + |
| `Bank Interest` | `interest` | always + |
| `Margin Interest` | `fee` | always − (stored positive) |
| `ADR Mgmt Fee` | `fee` | always − |
| `Foreign Tax Paid` | `fee` | always − |
| `Service Fee` | `fee` | always − |
| `Journal` | `transfer_in` / `transfer_out` | sign of `Amount` (catch-all internal) |

**Untouched non-trade actions** (handled by existing trade-side parser logic):
- `Security Transfer`, `Journaled Shares` — share-quantity transfers (existing `_TRANSFER_ACTIONS` path).
- `Reverse Split`, `Assigned`, `Expired` — corporate actions / option lifecycle (existing logic).

**Unknown actions** — emit a parse warning via the existing `parse_warnings_json` mechanism on `imports`. Row is skipped, never silently dropped.

### `imports` table extension

Add nullable column `cash_event_count: int | None = Field(default=0)` to `ImportRecordRow`. Surfaced in `_imports_table.html` and `_imports_detail_row.html` next to `trade_count`.

### `trades` table extension

Add nullable column `gross_cash_impact: float | None` to `TradeRow`. This stores the **signed** cash debit/credit reported on the broker CSV `Amount` column at parse time, before any tax-basis adjustments.

**Why this is needed:** the existing Schwab parser reduces `cost_basis` by the previously-received premium when a put is assigned (`schwab.py:199–203`). That adjustment is correct for IRS basis tracking but means `cost_basis ≠ actual cash debit`. Example: put on RR sold for $87 premium, then assigned 100 shares at $3 strike → `cost_basis = 213`, but the cash debit at assignment is $300. Without `gross_cash_impact`, the cash balance line would drift wrong on every put assignment.

`gross_cash_impact` is null for trades imported before this migration (cash-flow computation falls back to `proceeds or -cost_basis` for those, which is correct for non-assigned trades). The wash-sale engine never reads this column.

## Computation layer

New file: `src/net_alpha/portfolio/cash_flow.py`. Pure functions, no DB access, mirrors `equity_curve.py` style.

### Models (`portfolio/models.py` additions)

```python
class CashBalancePoint(BaseModel):
    on: date
    cash_balance: Decimal           # running sum of all signed cash impacts
    cumulative_contributions: Decimal  # running sum of transfer_in − transfer_out

class CashFlowKPIs(BaseModel):
    cash_balance: Decimal           # today's number
    net_contributions: Decimal      # cumulative external in − out
    holdings_value: Decimal         # from existing positions module
    account_value: Decimal          # cash + holdings
    growth: Decimal                 # account_value − net_contributions
    growth_pct: Decimal | None      # growth / net_contributions, None if contributions == 0
    cash_share_pct: Decimal         # cash / account_value
```

### Functions

- `build_cash_balance_series(events, trades, *, account=None, period) -> list[CashBalancePoint]` — sorts events + trades by date; emits one point per event date with running cash balance and running contribution baseline.
- `compute_cash_kpis(events, trades, holdings_value, *, account=None, period) -> CashFlowKPIs` — single-shot summary for the KPI strip.
- `cash_allocation_slice(events, trades, *, account=None) -> Decimal` — returns the current cash balance, fed to the existing donut as one extra slice.

### Sign convention

Both `cash_events` and `trades` move cash. Cash balance is the running sum:

```
balance += amount  for transfer_in, dividend, interest, sweep_in
balance -= amount  for transfer_out, fee, sweep_out

balance += trade.gross_cash_impact  for any trade with the column populated
       OR += proceeds      for Sell trades (legacy fallback)
       OR -= cost_basis    for Buy trades  (legacy fallback)

contributions += amount  for transfer_in only
contributions -= amount  for transfer_out only
```

Wash-sale-adjusted basis is **not** used here; cash flow uses the broker-reported gross amount.

### Period and account scoping

The existing toolbar's Period filter (YTD / specific year / Lifetime) and Account filter (All / per-account) clip the series and KPIs. Implemented identically to `equity_curve.py` — clip events outside the window; carry forward the opening balance from the cutoff.

## Web UI

### Layout — `_portfolio_body.html`

```jinja
{# KPIs strip — cash, net contributions, growth tiles added #}
<div id="portfolio-kpis" class="mb-4">{% include "_portfolio_kpis.html" %}</div>

{# Top row — two charts side by side #}
<div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1fr;">
  <div id="portfolio-equity" class="panel">{% include "_portfolio_equity_curve.html" %}</div>
  <div id="portfolio-cash"   class="panel">{% include "_portfolio_cash_curve.html" %}</div>
</div>

{# Allocation moved to its own row, full width #}
<div id="portfolio-allocation" class="panel mb-4">{% include "_portfolio_allocation.html" %}</div>

{# Wash watch unchanged #}
<div id="portfolio-wash-watch" class="panel mb-4">{% include "_portfolio_wash_watch.html" %}</div>
```

### New fragment: `_portfolio_cash_curve.html`

Inline SVG line chart, same Alpine + Jinja idiom as `_portfolio_equity_curve.html`. Two series:
- **Solid line** — running cash balance.
- **Dashed line** — cumulative net contributions baseline.

Hover tooltip on each event date: cash balance, contributions, and the most recent event description (e.g. "Buy SPIR −$158.80" or "Dividend +$4.47"). When the solid drops below the dashed, the user has spent cash on positions; when it rises above, trading + dividends + interest have grown cash beyond contributions.

### KPI strip additions — `_portfolio_kpis.html`

Three new tiles inserted alongside existing P&L tiles:
- **Cash** — today's cash balance; subtitle = delta vs period start.
- **Net contributed** — cumulative deposits minus withdrawals (period-respecting if user picks YTD).
- **Growth** — `account_value − net_contributed`; subtitle = `growth_pct`; color green/red.

### Allocation donut — `_portfolio_allocation.html`

Add a single "Cash" slice using a neutral gray, visually distinct from ticker colors. Cash also appears as a row in the leaderboard table with `% of account value`. Existing per-ticker rows unchanged.

### Routes — `web/routes/portfolio.py`

`/portfolio/body` already returns the bundled body. Extend the context to include `cash_balance_series`, `cash_kpis`, and `cash_slice`. No new endpoints for v1; if lazy loading is later desired, a `/portfolio/cash` partial endpoint can be added — same pattern as other panels.

**No business logic in `web/`** — routes assemble cash events from `Repository` and call pure functions in `portfolio/cash_flow.py`. Per CLAUDE.md.

## Repository

`src/net_alpha/db/repository.py` — three new methods, mirroring trade methods:

- `add_cash_events(events: list[CashEvent], import_id: int) -> int` — bulk insert with `INSERT OR IGNORE` on `(account_id, natural_key)`. Returns count of newly inserted rows.
- `list_cash_events(*, account_id=None, since=None, until=None) -> list[CashEvent]` — supports the same period/account scoping as `list_trades`.
- `delete_cash_events_by_import(import_id: int) -> int` — wired into the existing `imports rm` flow so removing an import cleans cash events too.

## Migration

`db/migrations.py` — bump `schema_version` (next int after current). Add a new migration block that:

1. `CREATE TABLE IF NOT EXISTS cash_events` with the columns above.
2. `CREATE INDEX IF NOT EXISTS` on `(account_id, event_date)` and on `natural_key`.
3. `CREATE UNIQUE INDEX IF NOT EXISTS uq_cash_event_account_natkey ON cash_events(account_id, natural_key)`.
4. `ALTER TABLE imports ADD COLUMN cash_event_count INTEGER DEFAULT 0` (idempotent — wrapped in a `PRAGMA table_info` check or try/except, matching the file's existing pattern).
5. `ALTER TABLE trades ADD COLUMN gross_cash_impact REAL` (idempotent; nullable).

Idempotent: re-running on an already-migrated DB is a no-op.

## Import pipeline

`src/net_alpha/import_/` — the parser interface changes from returning `list[Trade]` to returning `ImportResult`:

```python
class ImportResult(BaseModel):
    trades: list[Trade]
    cash_events: list[CashEvent]
    parse_warnings: list[str]
```

The CLI import flow becomes:

1. Parse CSV → `ImportResult`.
2. Insert trades (existing path, unchanged behavior).
3. Insert cash events (new, idempotent).
4. Update `imports` row stats — `trade_count`, `cash_event_count`, and `parse_warnings_json`.

## CLI surfaces

- `net-alpha imports` — show `cash_event_count` alongside `trade_count` so the user can see what each CSV brought in.
- `net-alpha imports rm <id>` — already removes by `import_id`; with `delete_cash_events_by_import` wired in, it removes both kinds in one transaction. No UX change.

## What this does NOT touch

- `trades`, `lots`, `wash_sale_violations`, `realized_gl_lots` schemas — completely separate concerns.
- The wash-sale engine — never reads `cash_events`. Verified by the existing engine tests passing unchanged.
- Existing `_portfolio_equity_curve.html` rendering — only its grid neighbor changes.

## Testing

### Unit tests — `tests/portfolio/test_cash_flow.py`

No mocks; factory_boy fixtures; mirrors `equity_curve.py` test style.

- Empty events → empty series, zero KPIs.
- Single deposit → balance jumps; contributions jumps the same amount; growth = 0.
- Deposit + buy + sell at gain → balance reflects net; growth = trading P&L.
- Deposit + buy + dividend → growth = dividend amount (the buy moved cash to holdings, didn't change account value at the buy moment).
- Sweep out + sweep in same day → balance dips and recovers (validates Schwab1-only definition).
- Put-assignment buy → cash balance reflects strike × qty (gross), not basis-adjusted `cost_basis`. Specifically: Sell-to-Open premium of $87, then Assigned Buy at $3 strike for 100 shares → cash impact at assignment date is exactly −$300, not −$213.
- Period clipping: YTD scope on multi-year events returns only this year's segment with correct opening cash.
- Account scoping: events from account A don't appear in account B's series.
- Cash slice + sum(holdings) = account value within rounding (consistency check).

### Parser tests — `tests/brokers/test_schwab.py`

- Each new action → expected `CashEvent.kind` and sign. Golden-file tests against anonymized fixtures.
- Unknown non-trade action → emits parse warning, doesn't crash.
- Re-import same CSV → zero new cash events (`natural_key` dedup works).
- Trade rows still parse identically (regression check).

### Integration tests — `tests/integration/test_import_cash_events.py`

Fixtures: anonymize the user's two real CSVs into `tests/fixtures/schwab_short_term.csv` and `tests/fixtures/schwab_long_term.csv` (mask account number digits; optionally mask tickers). These two files together cover all 13 distinct non-trade action types we map.

- Import both fixture CSVs → expected total counts of trades AND cash events.
- All 13 action types appear in `cash_events` with the correct `kind`.
- Per-account totals: ST cash balance ≠ LT cash balance; no cross-account leakage.
- Cash balance at the most recent event date matches a hand-computed value.
- Allocation donut shows the correct cash slice for each account when filtered.
- `imports rm` removes both trades and cash events for that import; the other account's data is untouched.

### Error handling

- Malformed `Amount` value on a non-trade row → parse warning, row skipped (consistent with existing trade-row behavior on optional fields; raises only on the required `Date` field).
- Empty `Symbol` on a dividend row → log warning and store `ticker=None`. Dividend still counts toward balance.
- Conflicting same-day sweep_in and sweep_out → both stored; both contribute to series. Different `natural_key` (different amounts/descriptions) so dedup works correctly.

## Disclaimer

The existing footer disclaimer (CLAUDE.md "every command output ends with…") covers this feature. Web UI shows the same disclaimer; no new copy needed.

## Out of scope (deferred to future specs)

- Separate "Cash" / "Income" page with dividend-by-ticker breakdown.
- Reconciliation tooling against Schwab's online balance.
- Multi-broker support for cash events (only Schwab parser updated here).
- Historical holdings market value for a true historical account-value chart (currently approximated using today's holdings only — same Phase-1 limitation as the equity curve).
- Per-period "growth attribution" breakdown (trading P&L vs. dividends vs. interest).
