# Provenance, Forward Tax Planner, and Style-Aware Density

**Date:** 2026-04-27
**Status:** Design — pending implementation plan
**Scope:** Three new feature areas embedded into existing pages (zero new top-level routes); one route rename (`/wash-sales` → `/tax`); one DB migration (v8 → v9); one new optional config section (`tax`).
**Phasing:** Three phases shipped in dependency order — Provenance → Tax Planner → Density.

---

## Motivation

`net-alpha` is repositioning from "wash-sale detector with a UI" to **"portfolio tracker + tax tool for self-directed power users."** Three gaps currently block that positioning:

1. **Numbers aren't drillable.** Wash-sale logic silently adjusts basis; KPIs don't expose contributing trades; the user (and any non-author user) can't reconstruct *why* a number is what it is. Without provenance, the rest of the product can't be trusted at higher stakes.
2. **The tax tool is retrospective, not proactive.** Wash-sale detection runs *after* trades are imported. The existing `simulate sell` command answers "what about *this* trade." Nothing answers "what should I do this quarter / before December 31 / where am I against the $3,000 cap." The wash-sale graph already exists; running it forward unlocks most of the tax-planning value with relatively little new logic.
3. **One dashboard for three styles is underserving all three.** The current UI splits the difference between buy-and-hold investors, active equity traders, and options/wheel users. The audience explicitly mixes all three. Profile-aware defaults (with everything still reachable) are the IA fix.

## Audience and constraints

- **Users:** the author + a small handful of investing friends. Local install (no auth, no SaaS), but UX must survive a non-author user — defaults and error messages matter; raw config-file edits should not be required for the common path.
- **Investing styles to handle gracefully:** buy-and-hold, active equity, options/wheel.
- **Local-first preserved.** Trade data, accounts, and P&L never leave the box. The existing remote-price relaxation (Yahoo for prices only) is unchanged.
- **Wash-sale awareness depth for options:** wheel-strategy aware. Assignment events flow basis correctly; premium-collected ledger feeds harvest-queue context. Spreads, constructive sale, qualified-covered-call, and straddle disallowance rules are explicitly **out of scope** — flagged for CPA review when detected, not computed.
- **Existing specs respected.** The 2026-04-26 UI/UX redesign and 2026-04-14 tax-optimization-suite specs continue to apply where they intersect; this spec extends rather than replaces them. Cash-flow tracking (just shipped) is reused, not redesigned.

---

## Architecture overview

### Module layout

```
src/net_alpha/
├── audit/                          # NEW
│   ├── __init__.py
│   ├── provenance.py               # ProvenanceTrace + provenance_for(MetricRef)
│   ├── reconciliation.py           # net-alpha vs broker G/L diff
│   ├── hygiene.py                  # data-quality checks
│   └── brokers/
│       ├── __init__.py
│       ├── base.py                 # BrokerGLProvider ABC + BrokerLot
│       └── schwab.py               # Schwab implementation (uses existing G/L data)
├── portfolio/
│   └── tax_planner.py              # NEW — harvest queue, offset budget, projection,
│                                   #       traffic-light scoring, premium ledger
├── prefs/                          # NEW
│   ├── __init__.py
│   └── profile.py                  # per-account profile + density preferences
├── engine/                         # unchanged (detector, stitch, recompute, simulator, etf_pairs, ...)
└── web/
    ├── routes/
    │   ├── tax.py                  # NEW — replaces wash_sales.py
    │   ├── wash_sales.py           # KEPT briefly as 301 → /tax
    │   ├── imports.py              # MODIFIED — embeds data-hygiene section
    │   ├── ticker.py               # MODIFIED — embeds reconciliation strip
    │   ├── portfolio.py            # MODIFIED — embeds offset budget + projection tiles
    │   ├── sim.py                  # MODIFIED — embeds traffic-light header
    │   └── preferences.py          # NEW — POST /preferences (form handler)
    └── templates/
        ├── tax.html                # NEW (sections: wash sales | harvest queue | budget | projection)
        ├── _provenance_modal.html  # NEW (HTMX fragment)
        ├── _reconciliation_strip.html  # NEW
        ├── _harvest_queue.html     # NEW
        ├── _offset_budget_tile.html # NEW
        ├── _projection_card.html   # NEW
        ├── _traffic_light.html     # NEW
        ├── _data_hygiene.html      # NEW (embedded on imports.html)
        ├── _profile_switcher.html  # NEW (embedded in base.html toolbar)
        └── _density_toggle.html    # NEW (embedded in table-heavy pages)
```

**Convention preserved:** no business logic in `web/`. Routes call into `audit/`, `portfolio/`, `prefs/`, `engine/` via the existing `Repository` / pure-function seams.

### Information architecture (zero new top-level pages)

| Existing route | Change |
|---|---|
| `GET /portfolio` | + offset-budget tile (KPI row), + year-end projection card |
| `GET /holdings` | + density toggle, + LT/ST split column under "Tax-view" density |
| `GET /ticker/{symbol}` | + reconciliation strip (top), + drillable KPI tiles (modals) |
| `GET /sim` | + tax traffic-light header on result panel |
| `GET /imports` | + Data Quality section above import history; nav-item count badge |
| `GET /wash-sales` | **renamed `GET /tax`**; old route returns 301 redirect for bookmarks |

| New routes | Purpose |
|---|---|
| `GET /tax` | Tabbed page: Wash sales (existing) \| Harvest queue \| Offset budget \| Projection |
| `GET /provenance/{metric_ref}` | HTMX fragment for KPI drill-down modal |
| `POST /preferences` | Form handler — sets profile / density (no UI page) |
| `GET /reconciliation/{symbol}` | HTMX fragment for per-lot diff (expanded from strip) |

No standalone `/audit/{symbol}`, `/health`, `/tax-planner`, or `/preferences` pages. Every new feature lands in a context where the user already has a reason to be.

### Database

One new table; one schema bump (v8 → v9).

```sql
CREATE TABLE user_preferences (
  account_id INTEGER PRIMARY KEY,         -- per-account, FK -> accounts(id)
  profile TEXT NOT NULL DEFAULT 'active', -- 'conservative' | 'active' | 'options'
  density TEXT NOT NULL DEFAULT 'comfortable', -- 'compact' | 'comfortable' | 'tax'
  updated_at TEXT NOT NULL,
  FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
);
```

A row is inserted lazily on first preference write for an account; absence means defaults (`active` / `comfortable`). Per-page density may also be overridden in `localStorage` for ephemeral tweaks; the DB row is the persistent default.

No schema changes to `trades`, `lots`, `wash_sale_violations`, `cash_events`, or `imports`. Provenance and tax-planner features are computed on read.

### Configuration

New optional `tax` section in `~/.net_alpha/config.yaml`:

```yaml
tax:
  filing_status: single        # single | mfj | mfs | hoh
  state: CA                    # ISO state code; "" or omitted = federal-only
  federal_marginal_rate: 0.32  # explicit; we don't auto-compute brackets v1
  state_marginal_rate: 0.093
  ltcg_rate: 0.15
  qualified_div_rate: 0.15     # equals ltcg_rate for most filers; left explicit
  reconciliation_tolerance: 0.50   # $ delta below this is treated as ~match
```

Absence of the section disables the year-end projection card with a banner directing the user to set it (a row in the data-hygiene queue). All other tax-planner features (harvest queue, offset budget, traffic light) work without bracket configuration — they degrade to "advisory only, no $-impact estimate."

`etf_replacements.yaml` — new bundled file at the package root (alongside `etf_pairs.yaml`). User-extensible at `~/.net_alpha/etf_replacements.yaml` (additive, never replaces defaults — same convention as `etf_pairs.yaml`).

```yaml
# Substantially-SIMILAR replacements: similar exposure, NOT substantially identical.
# Use to suggest harvest replacements that don't trigger wash-sale rules.
# This is a judgment call — every suggestion is labeled "discuss with CPA."
SPY:
  - VTI    # total US market vs S&P 500
  - SCHB
QQQ:
  - VGT    # tech sector vs Nasdaq-100
  - SPYG   # S&P 500 growth
# ... conservative defaults for ~10 popular harvest sources
```

Important: **`etf_replacements.yaml` is the inverse intent of `etf_pairs.yaml`.** The latter says "these are wash-sale-equivalent — don't pair them." The former says "these are similar exposure but legally distinct — safe(r) for harvesting." The two files must be kept consistent: a symbol must never appear in the replacement list of one of its own substantially-identical pairs.

---

## Section 1 — Provenance layer

Three independently-shippable sub-pieces. All share a single `ProvenanceTrace` data type.

### 1a. Drillable KPI tiles

**What.** Every dollar figure on `/portfolio`, `/holdings`, `/ticker/{symbol}`, and `/tax` becomes drillable. A small ⓘ icon (always visible, low-contrast) sits to the right of the number. Click → modal opens with three blocks:

1. **Contributing trades** — rows of `(date, account, action, qty, $ amount, import id)`. Sortable by date.
2. **Applied adjustments** — wash-sale basis transfers. Each row shows source loss trade → destination buy trade, $ rolled, rule citation (e.g., "IRS Pub 550 §1091 — 30-day window"), confidence label, and a link to the violation in `/tax`.
3. **Contributing cash events** — dividends, interest, transfers, fees that flowed into the figure (only relevant for cash-flow KPIs and net-contributed totals).

**How.** A single function in `audit/provenance.py`:

```python
def provenance_for(metric: MetricRef, repo: Repository) -> ProvenanceTrace: ...
```

`MetricRef` is a typed Pydantic union (not a string), so the call sites are explicit and refactor-safe:

```python
class RealizedPLRef(BaseModel):
    kind: Literal["realized_pl"]
    period: Period   # YTD | year(int) | Lifetime
    account_id: int | None
    symbol: str | None  # None = aggregate

class UnrealizedPLRef(BaseModel):
    kind: Literal["unrealized_pl"]
    account_id: int | None
    symbol: str | None

class WashImpactRef(BaseModel):
    kind: Literal["wash_impact"]
    period: Period
    account_id: int | None

class CashRef(BaseModel):
    kind: Literal["cash"]
    account_id: int | None

class NetContributedRef(BaseModel):
    kind: Literal["net_contributed"]
    period: Period
    account_id: int | None

MetricRef = (
    RealizedPLRef | UnrealizedPLRef | WashImpactRef | CashRef | NetContributedRef
)
```

Templates use a `{{ provenance_link(metric_ref) }}` Jinja macro that emits the ⓘ affordance and the HTMX `hx-get="/provenance/<encoded>"` attribute. Encoding is a base64-url-safe JSON of the metric ref (no secrets — purely read-only data anyway).

**Modal frame.** New template `_provenance_modal.html` renders inside a `<dialog>` element with HTMX `hx-target` swap. ESC closes; click-outside closes. Skeleton renders immediately; trace populates on response.

**Failure mode.** If the trace function raises (e.g., a logic gap on a new metric type), the modal renders an error block: "Couldn't reconstruct trace — file a bug." with a link to the GitHub issues page. Never blocks the rest of the page.

### 1b. Reconciliation strip

**What.** On `/ticker/{symbol}`, top-of-page strip:

```
net-alpha computed: $702.54  ·  Schwab G/L: $702.54  ✓
```

Or with a divergence:

```
net-alpha computed: $702.54  ·  Schwab G/L: $701.34  △ $1.20  [investigate]
```

"Investigate" expands an HTMX fragment (`/reconciliation/{symbol}`) showing per-lot diffs: each lot the broker reports vs each lot net-alpha tracks, with the delta and a likely-cause hint ("partial fill not represented", "fee allocation difference", "options assignment basis").

**How.** New abstraction:

```python
# audit/brokers/base.py
class BrokerLot(BaseModel):
    symbol: str
    account_id: int
    acquired: date
    closed: date | None
    qty: Decimal
    cost_basis: Decimal
    proceeds: Decimal | None
    wash_disallowed: Decimal | None
    source_label: str  # e.g. "Schwab Realized G/L", "Schwab Unrealized"

class BrokerGLProvider(ABC):
    @abstractmethod
    def get_lot_detail(self, account_id: int, symbol: str) -> list[BrokerLot]: ...

    @abstractmethod
    def supports(self, account_id: int) -> bool: ...
```

```python
# audit/brokers/schwab.py
class SchwabGLProvider(BrokerGLProvider):
    """Reads broker-supplied lot detail from imported Schwab G/L CSVs."""
    def supports(self, account_id: int) -> bool:
        return self._account_has_schwab_gl(account_id)

    def get_lot_detail(self, account_id: int, symbol: str) -> list[BrokerLot]:
        # Reuses the data already populating _schwab_lot_detail.html.
```

```python
# audit/reconciliation.py
def reconcile(symbol: str, account_id: int, repo: Repository) -> ReconciliationResult: ...
```

Provider registry chooses by detection (Schwab today; Fidelity/IBKR/etc. plug in later by implementing the ABC and registering). When no provider supports the account, the strip renders: `Schwab G/L: not available for this account` (no ✓/△, just an info dash) — does not imply a problem.

**Tolerance.** Differences below a configurable threshold (default $0.50, `tax.reconciliation_tolerance`) are treated as `~match` — not a green ✓ but not a yellow △ either. Floating-point and rounding artifacts shouldn't trigger investigation prompts.

### 1c. Data hygiene queue (embedded on `/imports`)

**What.** New section above the import-history list on `/imports`. Categories shown only if non-empty:

- Unpriced symbols (e.g., delisted, OTC) — already detected; existing yellow toolbar badge becomes a link into this list.
- Low-confidence trade parses — parser emits a `parse_confidence` flag; surfaces when below threshold.
- Basis-unknown lots — transfers in without basis. Each row offers a "Set basis" inline form (date + cost) that writes a Trade-class `basis_correction` event.
- Orphan sells — sells with no matching buy lot in scope. Usually means a missing prior-year import or a transfer not yet hydrated.
- Duplicate natural-key warnings — soft-detected dedup conflicts.
- Missing tax bracket configuration (if `~/.net_alpha/config.yaml` lacks the `tax` section).

**How.** `audit/hygiene.py` exposes:

```python
def collect_issues(repo: Repository, settings: Settings) -> list[HygieneIssue]: ...

class HygieneIssue(BaseModel):
    category: Literal["unpriced", "low_parse", "basis_unknown",
                      "orphan_sell", "dup_key", "tax_config_missing"]
    severity: Literal["info", "warn", "error"]
    summary: str
    detail: str
    fix_url: str | None      # e.g. "/holdings?symbol=BITF"
    fix_form: HygieneFixForm | None
```

Each `HygieneIssue` is rendered with category, severity badge, summary, and either a `fix_url` link or an inline `fix_form` (HTMX-submitted; success swaps the row out).

**Nav badge.** When `collect_issues` returns ≥1 `error` or ≥3 `warn` items, the `Imports` nav item shows a count badge: `Imports • 3`. Tooltip lists the top categories. Computed at request time; cached for 30s to avoid recomputing on every page.

**Why on `/imports`.** Data quality issues originate from imports. Users already visit `/imports` after CSV ingestion — it's the natural moment to surface "by the way, three things need attention from this batch." A separate `/health` page would have no obvious entry trigger.

---

## Section 2 — Forward tax planner (wheel-aware)

Single new page (`/tax`, replacing `/wash-sales`) plus three embeddings on `/portfolio` and `/sim`. The page has four tabbed sections:

```
[ Wash sales | Harvest queue | Offset budget | Projection ]
```

The Wash sales tab preserves the existing `?view=table|calendar` toggle and all current behavior. The other three tabs are new.

### 2a. Harvest queue (tab on `/tax`)

**What.** Table of open positions at unrealized loss, columns:

| Symbol | Loss $ (current) | LT/ST | Account | Lockout-clear date | Premium offset (if any) | Actions |

- **Loss $ (current)**: market-value − adjusted basis at the latest available price. Negative values only (closed positions excluded).
- **LT/ST**: badge based on lot acquisition date.
- **Lockout-clear date**: the first date the symbol can be sold without triggering a wash-sale violation given existing buy activity in the past 30 days. Empty when already clear.
- **Premium offset**: for positions originating from CSP assignments (wheel-strategy awareness), shows premium received in muted text — e.g., `−$120 (CSP premium received 2025-08-14)`. Indicates the *real* economic loss is the displayed loss minus collected premium, even though the tax loss is the displayed loss only.
- **Actions**: `Simulate harvest` (drops into existing `/sim` flow with values prefilled); `Mark planned` (adds to projection in tab 4).

Filter row: `[ ] Currently harvestable only` (excludes positions inside a 30-day buy window). Sort default by Loss $ desc.

**Substantially-similar replacement column (optional).** When `etf_replacements.yaml` has an entry for the symbol, a "Suggested replacement" inline expansion shows safer-to-buy alternatives, each labeled "discuss with CPA — substantial-identity is a judgment call." No replacement column for non-ETF tickers.

**How.**

```python
# portfolio/tax_planner.py
def compute_harvest_queue(
    repo: Repository,
    pricing: PricingService,
    as_of: date,
    account_id: int | None = None,
    only_harvestable: bool = False,
) -> list[HarvestOpportunity]: ...

class HarvestOpportunity(BaseModel):
    symbol: str
    account_id: int
    qty: Decimal
    loss: Decimal              # negative
    lt_st: Literal["LT", "ST"]
    lockout_clear: date | None
    premium_offset: Decimal | None
    premium_origin_event: PremiumOriginEvent | None
    suggested_replacements: list[str]    # from etf_replacements.yaml
```

Pure function. Reuses `engine/detector.py` for lockout-window math.

### 2b. Offset budget gauge (tile on `/portfolio`, mirror on `/tax`)

**What.** Compact tile in the existing KPI row:

```
Loss harvested YTD: $1,420 of $3,000 cap
[████████░░░░░░] 47%
Carryforward projection: $0
```

When YTD harvested losses exceed $3,000, gauge wraps and the carryforward line begins growing.

**How.**

```python
# portfolio/tax_planner.py
def compute_offset_budget(
    repo: Repository,
    year: int,
    planned_trades: list[PlannedTrade] | None = None,
) -> OffsetBudget: ...

class OffsetBudget(BaseModel):
    year: int
    realized_losses_ytd: Decimal     # negative magnitude
    realized_gains_ytd: Decimal      # positive
    net_realized: Decimal
    cap_against_ordinary: Decimal = Decimal("3000")
    used_against_ordinary: Decimal
    carryforward_projection: Decimal
    planned_delta: Decimal           # if planned_trades provided
```

`PlannedTrade` is a transient struct from the harvest-queue "Mark planned" action; not persisted to DB across sessions in v1 (kept in `localStorage`).

### 2c. Year-end tax-bill projection (card on `/portfolio`, full version on `/tax`)

**What.** Card on portfolio dashboard:

```
Projected 2026 tax (Dec 31): $4,820
Federal: $3,940 · State (CA): $880
Based on: realized YTD + 0 planned harvests
[ Edit assumptions ]
```

Full tab on `/tax` shows:
- Breakdown by ST/LT, qualified-div, ordinary
- Side-by-side scenarios: "current path" vs "after planned harvests"
- Marginal-bracket annotation when a planned trade pushes the user into a new bracket

**How.**

```python
def project_year_end_tax(
    repo: Repository,
    year: int,
    brackets: TaxBrackets,
    planned_trades: list[PlannedTrade] | None = None,
) -> TaxProjection: ...

class TaxBrackets(BaseModel):
    filing_status: Literal["single", "mfj", "mfs", "hoh"]
    state: str  # ISO; "" for federal-only
    federal_marginal_rate: Decimal
    state_marginal_rate: Decimal
    ltcg_rate: Decimal
    qualified_div_rate: Decimal

class TaxProjection(BaseModel):
    year: int
    realized_st_gain: Decimal
    realized_lt_gain: Decimal
    qualified_div: Decimal
    ordinary_div: Decimal
    interest_income: Decimal
    federal_tax: Decimal
    state_tax: Decimal
    total_tax: Decimal
    bracket_warnings: list[str]
```

Loaded from the new `tax:` config section. When config is absent, `project_year_end_tax` raises `MissingTaxConfig`; the card on `/portfolio` renders a placeholder linking to the data-hygiene row.

**Limits.** This is a **single-marginal-rate estimate**, not a tax return. Multi-bracket calculation, AMT, NIIT, qualified-dividend stacking with cap-gains brackets, and state-specific quirks are all out of scope. The card and tab carry a persistent caveat: "Estimate only — single marginal rate. Consult a tax professional."

### 2d. Pre-trade traffic light (header on `/sim` result panel)

**What.** When the user runs a sim with the existing form, the result panel grows a header strip:

```
🟢  Tax-efficient — LT loss; offsets ST gains; lot strategy: HIFO recommended
🟡  Caution — would create ST gain; closer to next bracket boundary
🔴  Stop — triggers wash-sale violation; lockout until 2026-MM-DD
```

Plus a one-line explanation and (when 🟡/🔴) a suggested alternative ("delay 11 days to avoid", "switch to FIFO to use LT lot first").

**How.** Decision tree in `portfolio/tax_planner.py`:

```python
def assess_trade(
    proposed: PlannedTrade,
    repo: Repository,
    brackets: TaxBrackets | None,
    as_of: date,
) -> TaxLightSignal: ...

class TaxLightSignal(BaseModel):
    color: Literal["green", "yellow", "red"]
    reason_codes: list[str]   # e.g. "WASH_RISK", "ST_GAIN_BRACKET_PUSH"
    explanation: str          # rendered prose
    suggestion: str | None
    lot_method_recommended: Literal["FIFO", "HIFO", "LIFO"] | None
```

Composes existing `engine/detector.py` (wash check) + `engine/etf_pairs.py` (substantial-identity check) + new bracket-boundary check. When `brackets is None`, never returns yellow on bracket-push reasons; falls through to neutral guidance.

### 2e. Wheel-strategy awareness

Concretely required behaviors (some may already partially exist; verify during implementation):

- **CSP assignment** → long stock lot acquired with basis = `strike − premium_received`; lot's `acquisition_date` = assignment date; lot carries `origin_event = CSPAssigned(option_natural_key, premium_received, strike)`.
- **Covered-call assignment** → stock sale with proceeds = `strike + premium_received`; sell trade carries `origin_event = CCAssigned(option_natural_key, premium_received, strike)`.
- **Harvest queue** displays `premium_offset` and `premium_origin_event` for any open lot whose origin is a CSP assignment.
- **Lockout calendar** treats option-on-underlying as substantially identical for wash-sale purposes: closing assigned shares at a loss locks out new CSP openings on the same underlying for 30 days. (This is the most-missed wheel pitfall.)
- **Premium ledger** (cross-cutting helper, used by harvest queue): per-position summary of premium received from option activity that resulted in stock holdings. Lives on the `HarvestOpportunity` row, not as a standalone panel.

Out of scope (flag-only, no math): spread leg interactions, qualified covered-call rules (deep-ITM call disallowance), constructive-sale doctrine, straddle disallowance. When the engine detects one of these patterns, it tags the affected position with a "complex options situation — review with CPA" marker that surfaces as 🟡 in the traffic light. No structured analysis.

### 2f. Substantially-similar replacement suggestions

Already covered above (`etf_replacements.yaml`, harvest-queue inline expansion). Crucial implementation note: the loader **must** validate that no replacement appears in `etf_pairs.yaml` for the source symbol — i.e., the two files cannot contradict each other. Validation runs at app startup; conflicts log a warning and exclude the offending pair from suggestions (fail-soft, not crash).

---

## Section 3 — Style-aware density

**Per-account profile picker + per-page density toggle.** Smart auto-suggestion is **deferred** to a future phase.

### 3a. Per-account profile picker

**What.** First time the user visits any page after the v9 migration, a one-time modal appears:

> *Pick a default profile per account — switch anytime.* Profiles change *defaults*; nothing is hidden permanently.
>
> ⚪ **Conservative** — long-term investing, periodic rebalance, taxes once a year.
> ⚪ **Active** — frequent equity trading; wash-sale watch is your friend.
> ⚪ **Options** — wheel/CSP/CC strategies; premium tracking matters.
>
> *Use the same profile for all accounts* / *Pick per-account*

If "all accounts," writes the same profile to every `user_preferences` row. If "per-account," shows a list of accounts with a profile dropdown each.

Default if dismissed without choosing: `active` for every account.

**Switcher.** Toolbar dropdown next to the existing account chip:

```
[ 2 accounts · YTD · Active ▾ ]
```

Click expands to per-account profile pickers. POSTs to `/preferences` (form handler), returns 204 + HTMX trigger to refresh the current page fragment.

### 3b. Profile-driven defaults

Profile drives **default visibility/ordering**, never permanent hiding. Switching profile = re-ordering and re-collapsing default state.

| Surface | Conservative | Active | Options |
|---|---|---|---|
| `/portfolio` hero KPIs | Open Position $, Lifetime Growth, Cash | YTD Realized, YTD Unrealized, Wash Impact, Open Position $ | YTD Realized, Wash Impact, Open Position $, Cash |
| `/portfolio` wash-sale watch panel | Collapsed (auto-expands when violation present) | Expanded | Expanded |
| `/portfolio` lockout calendar | Hidden | Visible | Hero panel |
| `/portfolio` LTCG-approaching | Visible | Visible | Demoted |
| `/portfolio` offset budget tile | Visible | Visible | Visible |
| `/portfolio` year-end projection | Visible | Visible | Visible |
| `/holdings` extra columns | — | Days held, LT/ST split | + Premium received per position, + Origin event icon |
| `/tax` default tab | Wash sales | Harvest queue | Harvest queue |
| `/sim` traffic light | Visible | Visible | Visible |

When an account is mixed (e.g., "Active" but the account has ≥30% option trades), the profile system never auto-switches — only smart-suggestion (deferred) would propose a change.

**Implementation.** Each rendered page receives `profile: ProfileSettings` in its template context. Templates use `{% if profile.shows("lockout_calendar") %}` style guards. The `ProfileSettings` object encapsulates the table above in code (not in templates) so the rules live in one place:

```python
# prefs/profile.py
class ProfileSettings(BaseModel):
    profile: Literal["conservative", "active", "options"]
    density: Literal["compact", "comfortable", "tax"]

    def shows(self, surface: str) -> bool: ...
    def order(self, surface_group: str) -> list[str]: ...
    def default_columns(self, table: str) -> list[str]: ...
```

### 3c. Per-page density toggle

**What.** On `/holdings`, `/tax`, `/imports`:

```
[ Compact | Comfortable | Tax-view ]
```

- **Compact** — minimum columns, dense rows.
- **Comfortable** — default; profile-driven columns.
- **Tax-view** — adds LT/ST split, days-until-LTCG, harvestable flag, premium offset (where applicable). Overrides profile defaults for that page.

**Where stored.** Persistent per-account default in `user_preferences.density`; transient per-page override in `localStorage` (`density:/holdings:account_id`). Refresh respects localStorage if present, else falls back to DB default.

### 3d. Smart suggestion — deferred

After 30 days of usage, observed pattern (% of trades that are options, % that are short-term, etc.) could surface a one-time toast: *"You've placed 80% option trades — switch to the Options profile?"* — **not in v1**. Listed here for future reference; do not implement.

---

## Cross-cutting concerns

### Data flow

All three sections read from the existing `Repository` and engine functions plus the `PricingService` (provenance and harvest queue need current quotes for unrealized math). Cash events (just shipped) flow into:
- The cash-flow KPIs and net-contributed totals already on `/portfolio` (unchanged)
- The contributing-cash-events block in provenance modals (Section 1a)
- The realized/unrealized inputs to `compute_offset_budget` and `project_year_end_tax` (Section 2)

No new DB writes outside `user_preferences`. Provenance and tax-planner are pure-read features.

### Error handling

| Failure mode | Behavior |
|---|---|
| Provenance trace function raises | Modal shows "couldn't reconstruct trace — file a bug" with GH link; rest of page unaffected |
| Broker-GL provider unavailable for an account | Reconciliation strip renders `"Schwab G/L: not available for this account"` (info dash, not warning) |
| Tax bracket config missing | Year-end projection card shows placeholder + link to data-hygiene row; harvest queue / offset budget / traffic-light still work without $-impact estimates |
| Pricing unavailable for a symbol | Harvest queue excludes that row; toolbar yellow badge already handles this |
| `etf_replacements.yaml` conflict with `etf_pairs.yaml` | Startup warning logged; conflicting pair excluded from suggestions; app continues |
| `user_preferences` row missing | Defaults to `active` / `comfortable`; first preference write creates the row |
| Profile-driven template guard hits an unknown surface key | Defaults to `True` (show); logs a warning so missing surface keys are caught in dev |

### Privacy

Unchanged from existing policy. Trade data, accounts, cash events, P&L, broker G/L data, tax-bracket config, and preferences remain local. Only Yahoo (prices) and the configured provider are remote, both governed by the existing `prices.enable_remote` toggle. The new tax bracket configuration **never leaves the box** — calculations are entirely local. Provenance modals contain potentially-sensitive trade detail; they are local browser renderings, not network-sent.

### Disclaimer

Footer disclaimer remains unchanged: *"This is informational only. Consult a tax professional before filing."* Year-end projection card and `/tax` projection tab carry an additional persistent caveat: *"Estimate only — single marginal rate."*

### Testing

Following the existing project pattern:

- **Pure functions** (`audit/provenance.py`, `audit/reconciliation.py`, `audit/hygiene.py`, `portfolio/tax_planner.py`, `prefs/profile.py`) get 100%-style unit coverage with `factory_boy` fixtures. No mocks; integration with real `Repository` against an in-memory SQLite.
- **Wheel-strategy specific tests** for Section 2e: CSP-assignment basis, CC-assignment proceeds, lockout cross-asset (close stock at loss → CSP wash trigger), premium-offset rendering. Each as its own focused test.
- **Reconciliation** tested with anonymized Schwab G/L fixture (already present under `tests/brokers/`).
- **`etf_replacements.yaml` / `etf_pairs.yaml` consistency** validated by a dedicated startup-config test.
- **Web routes** get golden-fragment tests like the existing `tests/web/test_holdings_routes.py`. Each new template gets at least one happy-path render test plus one missing-data degradation test.
- **Migration v8 → v9** tested by spinning a v8 schema, running migration, and asserting `user_preferences` table exists with correct constraints and defaults.

---

## Migration v8 → v9

```sql
-- v8 → v9: per-account user preferences
CREATE TABLE user_preferences (
  account_id INTEGER PRIMARY KEY,
  profile TEXT NOT NULL DEFAULT 'active',
  density TEXT NOT NULL DEFAULT 'comfortable',
  updated_at TEXT NOT NULL,
  FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
);

UPDATE meta SET value = '9' WHERE key = 'schema_version';
```

Migration is idempotent (`CREATE TABLE IF NOT EXISTS` is acceptable, but the canonical migration uses `CREATE TABLE` and surfaces re-run errors). No data backfill — preference rows are created lazily on first write.

Downgrade is not supported (consistent with existing migration policy).

---

## Phasing

Ship in dependency order. Each phase is a separately mergeable PR set with its own implementation plan.

### Phase 1 — Provenance layer (Section 1)

Foundational. Everything in Phase 2 and Phase 3 references back to provenance traces (e.g., harvest-queue rows can drill into the contributing trades).

Sub-deliverables:
- 1a Drillable KPI tiles (modal + macro + `MetricRef` types + `provenance_for`)
- 1b Reconciliation strip + `BrokerGLProvider` ABC + Schwab implementation
- 1c Data hygiene queue on `/imports` + nav-item badge

### Phase 2 — Forward tax planner (Section 2)

Includes the `/wash-sales` → `/tax` rename and tabbed page restructure.

Sub-deliverables:
- 2a Harvest queue tab on `/tax`
- 2b Offset budget gauge tile on `/portfolio` and `/tax`
- 2c Year-end projection card + tab; new `tax:` config section
- 2d Pre-trade traffic light on `/sim`
- 2e Wheel-strategy awareness (basis flow + lockout cross-asset)
- 2f `etf_replacements.yaml` + replacement suggestions in harvest queue
- Route rename + 301 redirect from `/wash-sales`

### Phase 3 — Style-aware density (Section 3)

Lays out features that exist as a result of Phase 1 and Phase 2.

Sub-deliverables:
- v8 → v9 migration + `user_preferences` table
- 3a Per-account profile picker + toolbar switcher + `POST /preferences`
- 3b Profile-driven defaults (the visibility/ordering rule table)
- 3c Per-page density toggle (DB default + localStorage override)
- 3d **Deferred** — smart suggestion

---

## Out of scope (explicit)

These are intentionally not in this spec, even though they're related and previously-discussed:

- **Benchmark / TWR / after-tax return overlay.** Excluded by user direction. Historical EOD price snapshots remain deferred per the 2026-04-26 UI/UX redesign.
- **Income / dividend panel as a feature.** Dividends, interest, and option premium continue rolling into existing cash KPIs and net-contributed totals (accounting requirement). No separate income panel, no qualified-vs-ordinary split UI, no yield-on-cost column.
- **Spread tax accounting.** Multi-leg basis interactions are not modeled. Spreads import correctly as individual trades, but the planner does not understand them as a unit.
- **Constructive sale, qualified-covered-call deep-ITM rules, straddle disallowance.** Flagged as "complex — review with CPA" via 🟡 in the traffic light when detected; no structured analysis.
- **Auto-execution of harvests.** This is a planner; never a broker.
- **Trade journal / per-trade tags / decision diary.** Strong follow-up candidate; not in this spec.
- **Asset-location advisor.** Requires account-role metadata not present in the schema.
- **CPA export bundle / 8949 PDF.** Strong follow-up candidate; not in this spec.
- **Notifications / digest / cron.** Adds scheduling and side effects; defer until Phase 1+2 are proven.
- **Smart profile suggestion.** Section 3d — deferred.
- **Multi-bracket federal tax calculation, AMT, NIIT, qualified-dividend stacking with cap-gains brackets, state-specific quirks.** Year-end projection is a single-marginal-rate estimate.
- **Per-user profiles.** This is a single-user local product; profile granularity is per-account, not per-user.

---

## Open questions

None remaining at this stage. All scope decisions resolved during brainstorming:
- Audience: author + small power-user circle (B); local install, no auth.
- Pain points addressed: A (deferred — no benchmark), B (forward tax), C (provenance).
- Investing styles: design gracefully handles all three via Section 3.
- Options depth: wheel-strategy aware (Q4 = ii); spreads/constructive-sale/straddle out of scope.
- Reconciliation scope: Schwab today, abstraction in place for future brokers (Q5 = b).
- IA: zero new top-level pages; everything embedded into existing pages or under the renamed `/tax`.
- Profile granularity: per-account.
- Smart suggestion: deferred.
