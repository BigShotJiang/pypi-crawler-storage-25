# Manual trade CRUD on the Timeline — design

**Date:** 2026-04-26
**Status:** Draft → ready for plan
**Scope:** Let users add manually-entered trades, edit incomplete imported transfer rows, and delete manual trades — all from the per-symbol Timeline at `/ticker/{symbol}`.

This is **Spec B** of two. Spec A (`2026-04-26-portfolio-polish-and-perf-design.md`) covers the unrelated UI polish + perf work and is independent of this one.

## Problem

`net-alpha` ingests trades exclusively from broker CSVs today. That breaks down in two real cases:

1. **Transferred-in positions show $0 cost basis.** Schwab Transaction History records inbound transfers (`Security Transfer`, `Journaled Shares`) without basis or with a stub date (the receipt date, not the original acquisition date). The parser tags these with `basis_source="transfer_in"` and `action="Buy"` so the engine treats them, but the values shown to the user are wrong for tax purposes.
2. **Trades that aren't in any CSV at all.** Shares transferred in from non-Schwab brokers, DRIP shares the broker didn't report as discrete buys, manually-tracked ESPP entries, etc. Users have no way to enter these.

This spec addresses both.

## Goals

1. Let users edit `date` and `cost_basis` (or `proceeds`) on imported transfer rows so the wash-sale engine and reports use accurate numbers.
2. Let users add manual trades for things not in any import.
3. Let users edit and delete the manual trades they've added.
4. Survive re-imports of the same Schwab CSV without losing user edits.
5. Make the Timeline display honest about transfers — show "Transfer In" / "Transfer Out" instead of collapsing to "Buy" / "Sell".

## Non-goals

- Editing arbitrary fields on regular imported (Buy/Sell) rows. Users can't change a Schwab buy's qty or date — that would invalidate the audit trail of "this is what your 1099 will say". To remove a regular imported row, use the existing `/imports rm` flow.
- Deleting individual imported rows of any kind. Whole-import removal only.
- Undo / soft-delete / history table. Single-user local app; delete-confirm dialog is the safety net.
- Option-trade entry from the manual form. The data model already supports it (`Trade.option_details` is optional), so adding a future toggle is purely additive — no schema change required.
- Bulk operations (no "delete all manual", "import all from another tool", etc.).

## 1. Operation matrix

| Row type                                                                       | Add | Edit                                                | Delete |
| ------------------------------------------------------------------------------ | --- | --------------------------------------------------- | ------ |
| `is_manual=True` (any kind: manual buy/sell/transfer)                          | n/a | all fields                                          | yes    |
| `is_manual=False` AND `basis_source == "transfer_in"`                          | n/a | `date`, `cost_basis`                                | no     |
| `is_manual=False` AND `basis_source == "transfer_out"`                         | n/a | `date`, `proceeds`                                  | no     |
| `is_manual=False`, other (regular imported Buy/Sell)                           | n/a | no                                                  | no     |

`is_manual` takes precedence over `basis_source` when matching the rule. The Add operation creates `is_manual=True` rows.

## 2. Data model changes

`Trade` (Pydantic) and `TradeRow` (SQLModel) gain one column:

- `is_manual: bool = False` — true when the row was created by the user via the Add form. Distinct from `basis_source` (which describes *where the basis number came from*); `is_manual` describes *whether the row was user-created from scratch*.

`TradeRow.import_id` becomes nullable. A manual row has no `ImportRecord` parent. Rationale: a manual row doesn't belong to any import; coordinating a synthetic "manual" import per account adds bookkeeping for no UX benefit.

### Schema migration

Bumps `meta.schema_version` to the next integer. Migration logic in `db/migrations.py` follows the existing hand-written pattern:

1. `ALTER TABLE traderow ADD COLUMN is_manual INTEGER NOT NULL DEFAULT 0;`
2. Relax `import_id` `NOT NULL` constraint via SQLite's standard rebuild dance (`CREATE TABLE traderow_new ...; INSERT INTO traderow_new SELECT ...; DROP traderow; RENAME traderow_new TO traderow;`).
3. Recreate the existing `UniqueConstraint("account_id", "natural_key")` and the `natural_key` index in the new table.

### Display label (derivation, no new column)

A pure helper in the rendering layer derives the user-facing action label from existing fields:

```python
def display_action(t: Trade) -> str:
    if t.basis_source == "transfer_in":
        return "Transfer In"
    if t.basis_source == "transfer_out":
        return "Transfer Out"
    return t.action  # "Buy" or "Sell"
```

The Timeline column uses this. Engine code keeps using `Trade.action` and is unchanged.

## 3. Re-import idempotency

When a user edits an imported transfer row's `date` or basis, the row's stored `natural_key` must **not** be recomputed. On re-import of the same Schwab CSV:

1. The parser produces the same per-row `natural_key` as before (computed from the original CSV content).
2. The repository's insert path runs into the existing `UniqueConstraint("account_id", "natural_key")` and skips the row.
3. The user's edited row remains.

Implementation: the repository's update method writes only the explicitly-passed columns (`date`, `cost_basis`, etc.) and never touches `natural_key`. Add a unit test that asserts this — load fixture CSV, edit a transfer-in row, re-import the same CSV bytes, assert exactly one row at that `(account, natural_key)` and that the user's edit persists.

## 4. Wash-sale recompute

Every successful write — manual add, manual edit, manual delete, imported-transfer edit — calls the existing `engine.recompute.recompute_all_violations(repo, etf_pairs)` after the row mutation commits. This is the same hook the import and import-removal flows already use.

Why whole-history rather than a tighter pivot window: the existing implementation recomputes from `min(date)` to `max(date)` over all trades, intentionally, because Schwab G/L lot data can downgrade violations outside any single ±30-day window. Adding a per-pivot path would diverge from the import flow's behavior and risk leaving stale labels for the same reason. We pay the cost of a full recompute for consistency.

If recompute time becomes a UX issue post-rollout (delete-confirm spinner > 1s on a representative DB), the optimization is to introduce `recompute_around_dates(repo, dates)` and migrate both the import flow and the new write paths to it together — out of scope for this spec.

(Note: `CLAUDE.md` currently describes recompute as "incremental ±30-day window" which is stale relative to `recompute.py`. Updating that doc is a separate housekeeping item, not part of this spec.)

## 5. UI surface

### Ticker page (`/ticker/{symbol}`)

**Toolbar.** Existing "Simulate sale" button stays. New **"Add trade"** button to its left.

**Timeline table.** Existing columns stay. The Action column renders `display_action(t)` instead of `t.action`. A new rightmost column shows row affordances:

- `is_manual=True` → "Edit" link, "Delete" link.
- `is_manual=False` AND `basis_source ∈ {"transfer_in","transfer_out"}` → "Set basis & date" link.
- Otherwise → empty.

A small inline badge column (between Account and Action) shows provenance:

- `manual` (rows with `is_manual=True`)
- `edited` (transfer rows with `basis_source ∈ {"transfer_in","transfer_out"}` whose `(date, basis|proceeds)` differs from values that would come from re-parsing the CSV — see implementation note below)
- (no badge for plain imported rows)

*Implementation note for `edited` badge.* Detecting "differs from CSV values" cheaply: store a `transfer_basis_user_set: bool` flag on transfer rows that flips to True the first time the user updates basis or date. The badge keys off that flag. Avoids re-parsing the CSV on every render. Add as a second new column in the same migration as `is_manual`.

### Forms

All forms are HTMX-swap modals consistent with the existing `_import_modal.html` pattern. They submit to dedicated routes and the success response swaps the Timeline panel + KPI tiles + violations block on the ticker page (stable `hx-target` IDs).

| Route                              | Payload fields                                              | Side effects                                                 |
| ---------------------------------- | ----------------------------------------------------------- | ------------------------------------------------------------ |
| `POST /trades`                     | account, ticker, date, action_choice, qty, basis_or_proceeds | Insert manual row; recompute around `{date}`.                |
| `POST /trades/{id}/edit-transfer`  | date, cost_basis (or proceeds, if `basis_source="transfer_out"`) | Update row; recompute around `{old_date, new_date}`. Server validates `is_manual=False AND basis_source ∈ {"transfer_in","transfer_out"}`. |
| `POST /trades/{id}/edit-manual`    | account, date, action_choice, qty, basis_or_proceeds         | Update row; recompute around `{old_date, new_date}`. Server validates `is_manual=True`. |
| `POST /trades/{id}/delete`         | (none)                                                      | Delete row; recompute around `{date}`. Server validates `is_manual=True`. |

`action_choice` on the manual forms is one of: `Buy`, `Sell`, `Transfer In`, `Transfer Out`. Mapped to storage:

| `action_choice` | stored `action` | stored `basis_source` | stored `is_manual` |
| --------------- | --------------- | --------------------- | ------------------ |
| Buy             | `Buy`           | `user`                | `True`             |
| Sell            | `Sell`          | `user`                | `True`             |
| Transfer In     | `Buy`           | `transfer_in`         | `True`             |
| Transfer Out    | `Sell`          | `transfer_out`        | `True`             |

The form lays out fields conditionally:

- `Buy` and `Transfer In` → show `cost_basis`, hide `proceeds`.
- `Sell` and `Transfer Out` → show `proceeds`, hide `cost_basis`.

Implemented with Alpine.js for the conditional rendering (consistent with existing modal patterns).

### Confirmation dialog

Delete fires through a small Alpine-driven confirm dialog (`Are you sure? This can't be undone.`). No soft-delete.

## 6. Validation

Server-side, returning 400 with field-level errors as HTMX-swap fragments:

- **Add (manual):** `account` required and must be one of the existing account labels (no creating new accounts via this form). `date` ≤ today. `qty > 0`. `cost_basis ≥ 0` for Buy/Transfer-In. `proceeds ≥ 0` for Sell/Transfer-Out. `ticker` non-empty.
- **Edit transfer:** `date` ≤ today. `cost_basis ≥ 0` (or `proceeds ≥ 0`). All other fields locked.
- **Edit manual:** same as Add.
- **Delete:** server verifies `is_manual=True`.

All other constraints already enforced by Pydantic on `Trade` (e.g., `quantity` is a float; type validation by SQLModel).

## 7. File-level change map

| File                                                       | Change                                                                                                |
| ---------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `src/net_alpha/models/domain.py`                           | Add `is_manual: bool = False` and `transfer_basis_user_set: bool = False` to `Trade`.                |
| `src/net_alpha/db/tables.py`                               | Add the same two fields to `TradeRow`. Make `import_id` nullable.                                    |
| `src/net_alpha/db/migrations.py`                           | New migration to next `schema_version`: add columns, rebuild table for nullable `import_id`.         |
| `src/net_alpha/db/repository.py`                           | New methods: `create_manual_trade`, `update_imported_transfer`, `update_manual_trade`, `delete_manual_trade`. Each commits in a single transaction and triggers recompute. |
| `src/net_alpha/engine/recompute.py` (existing)             | No change — the existing whole-history `recompute_all_violations` is reused by the new write paths. |
| `src/net_alpha/web/routes/trades.py` *(new)*               | The four POST routes listed in Section 5.                                                             |
| `src/net_alpha/web/routes/ticker.py`                       | Pass `display_action` helper to the Timeline template; render new affordance + badge columns.         |
| `src/net_alpha/web/routes/__init__.py`                     | Register the trades router.                                                                           |
| `src/net_alpha/web/templates/ticker.html`                  | Add "Add trade" button; add affordance + badge columns; use `display_action`.                         |
| `src/net_alpha/web/templates/_trade_form.html` *(new)*     | Shared form fragment for add + edit-manual; conditional fields via Alpine.                            |
| `src/net_alpha/web/templates/_trade_transfer_form.html` *(new)* | Two-field form for edit-transfer.                                                                |
| `src/net_alpha/web/templates/_trade_delete_confirm.html` *(new)* | Confirm dialog for delete.                                                                       |
| `tests/db/test_repository.py` (extend)                     | Manual create/update/delete; immutable `natural_key` on edit; transfer-edit allowed only on transfer rows; manual-edit allowed only on manual rows. |
| `tests/db/test_migration.py` (extend)                      | Migration round-trip including new columns and nullable FK.                                           |
| `tests/engine/test_recompute.py` (extend)                  | Add: manual write paths trigger `recompute_all_violations` and the resulting violations match a fresh import of equivalent CSV data. |
| `tests/web/test_trades.py` *(new)*                         | Route-level happy paths and validation errors for all four POST endpoints.                            |
| `tests/integration/test_reimport_idempotency.py` *(new)*   | Import → edit transfer-in row → re-import same CSV → verify edit survives and no duplicate row.       |

## 8. Testing strategy

- **Unit:** repository writes (each operation, including `natural_key` immutability on edit), `display_action` helper, validation rule helpers.
- **Migration:** existing v* DB → new schema, verify columns and nullable FK; verify a v_prev fixture upgrades cleanly.
- **Route:** all four POST endpoints — happy path, every validation rule, every authorization rule (`edit-transfer` rejects manual rows, `edit-manual` and `delete` reject imported rows).
- **Integration:** the re-import idempotency test described in Section 3.
- **No mocks for the engine.** Continue the project's "100% unit test coverage of pure functions, no mocks" rule for engine code.

## 9. Rollout

Single PR. The schema migration is forward-only (no rollback path needed for a personal local DB — the user can `git revert` and re-import if necessary). The new fields default to safe values (`is_manual=False`, `transfer_basis_user_set=False`) so existing rows keep their current semantics. Once merged, the Timeline immediately shows "Transfer In" / "Transfer Out" labels for already-imported transfer rows — first user-visible change.

## Open questions deferred to follow-up

- Option-trade manual entry. Schema permits it; UI gate is left in place. Add when needed.
- Bulk import of manual trades from a tiny CSV/JSON file. Niche; defer until requested.
- Editing imported regular Buy/Sell rows. Out of scope per goals; revisit only if the audit-trail concern stops mattering.
