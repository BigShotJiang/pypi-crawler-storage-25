# Portfolio polish + performance — design

**Date:** 2026-04-26
**Status:** Draft → ready for plan
**Scope:** Web UI polish across imports + portfolio + holdings, and a fix for the slow `/portfolio` page load.

This is **Spec A** of two. Spec B (manual trade CRUD on the ticker timeline) is intentionally out of scope and will be designed separately.

## Goals

1. Fix the ~10s `/portfolio` page-to-paint time. Target: warm-load page-to-paint under 2s.
2. Promote the holdings table to its own top-level tab.
3. Replace the holdings symbol filter with a multi-select popover.
4. Restyle the import-modal "Choose Files" button to match the rest of the dark theme.
5. Make the equity-curve and allocation panels equal width.

## Non-goals

- No changes to wash-sale engine, repository, broker parsers, or any business logic.
- No new dependencies (no node, no npm, no CDN; Alpine.js + HTMX + ApexCharts already vendored).
- No table redesign; columns/sort/FIFO logic stay as-is.
- No manual trade add/edit/delete (that is Spec B).

## 1. Portfolio page slowness

### Diagnosis

The page shell at `/portfolio` issues 5 concurrent HTMX fragment requests on load:

| Fragment route             | Calls inside the handler                                                                  |
| -------------------------- | ----------------------------------------------------------------------------------------- |
| `/portfolio/kpis`          | `repo.all_trades()`, `repo.all_lots()`, `svc.get_prices(...)`, `compute_kpis`, `compute_wash_impact` |
| `/portfolio/equity-curve`  | `repo.all_trades()`, `repo.all_lots()`, `svc.get_prices(...)`, `compute_kpis`, `build_equity_curve` |
| `/portfolio/allocation`    | `repo.all_trades()`, `repo.all_lots()`, `svc.get_prices(...)`, `compute_open_positions`, `build_allocation` |
| `/portfolio/wash-watch`    | `recent_loss_closes(repo, ...)` (its own scans inside)                                    |
| `/portfolio/positions`     | `repo.all_trades()`, `repo.all_lots()`, `repo.get_equity_gl_closures()`, `svc.get_prices(...)`, `compute_open_positions` |

Each handler does the same large reads and (in 4 cases) the same Yahoo price call. With FastAPI dependency injection re-instantiating `Repository` per request, the work is duplicated ~5×. User reports load time is consistent at ~10s, independent of cache temperature, which matches duplication-bound behavior.

### Fix

Add a single bundled fragment endpoint:

```
GET /portfolio/body?period=...&account=...&group_options=...
```

This handler:

1. Loads `trades`, `lots`, `prices` once.
2. Filters `trades` and `lots` by `account` once.
3. Calls `compute_kpis`, `compute_wash_impact`, `build_equity_curve`, and `build_allocation` on the shared `trades`/`lots`/`prices`. Calls `recent_loss_closes(repo, ...)` directly — its internal scans are cheap relative to the duplicated work above and a refactor to share inputs is not required for the perf target.
4. Renders a new `_portfolio_body.html` template that includes the existing `_portfolio_kpis.html`, `_portfolio_equity_curve.html`, `_portfolio_allocation.html`, `_portfolio_wash_watch.html` partials. The positions block moves to `/holdings` (Section 2) and is no longer rendered here.
5. Returns the assembled HTML.

The page shell `portfolio.html` issues exactly one HTMX request on load:

```html
<div id="portfolio-body"
     hx-get="/portfolio/body?period={{ selected_period }}&account={{ selected_account }}"
     hx-trigger="load" hx-swap="innerHTML"></div>
```

The 5 individual fragment routes stay in `routes/portfolio.py` (positions stays for the holdings page; the others stay for toolbar swaps that change a single panel). They share the same compute functions; only the page-load fan-out is consolidated.

### Acceptance

- `/portfolio` warm-load page-to-paint < 2s on a database with the user's typical scale.
- Toolbar swaps (period change, account change) re-fire `/portfolio/body` once, not 5 fragments.
- All existing `_portfolio_*.html` partials continue to render unchanged.
- Existing per-fragment routes (`/portfolio/kpis`, `/portfolio/equity-curve`, `/portfolio/allocation`, `/portfolio/wash-watch`) remain reachable for direct fragment use; tests covering them stay green.

## 2. Holdings as its own tab

### Routing

| Route        | Renders                                                                  |
| ------------ | ------------------------------------------------------------------------ |
| `/portfolio` | KPIs row, equity curve + allocation row, wash-watch panel. **No positions table.** |
| `/holdings`  | Toolbar (Period + Account + symbol multi-select + show=open/all + page-size + paginator) and the positions table. |

`/holdings` reuses the existing `/portfolio/positions` HTMX fragment for toolbar-driven swaps — no duplicate data path. The new page route loads `holdings.html`, which renders the toolbar and a `<div id="holdings-positions" hx-get="/portfolio/positions?...">` that fetches the existing fragment on load.

### Navigation

`base.html` topbar nav gains a "Holdings" link between "Portfolio" and "Calendar". Active token: `'holdings'`.

### Empty state

If `imports` is empty, `/holdings` shows the same pointer to `/imports` that `/portfolio` shows today.

### Acceptance

- Visiting `/holdings` shows the table with the same data, columns, and behavior as today's portfolio-bottom holdings table.
- The topbar's "Holdings" link is highlighted on `/holdings`.
- `/portfolio` no longer shows a holdings table or its toolbar.
- The existing `/portfolio/positions` fragment route is unchanged.

## 3. Multi-select symbol filter

Replaces the current text input on the holdings toolbar.

### UI

- Trigger button on the toolbar: `Symbols: All` when nothing selected, `Symbols: AAPL, MSFT +3` when 5 selected, etc.
- Click opens a popover anchored under the trigger:
  - Search input at top (typeahead-narrows the list, debounce 200ms).
  - Scrollable checkbox list of in-scope symbols (i.e., symbols present in the current period+account result set, **before** the symbol filter is applied).
  - Footer: "Clear" and "Done" buttons.
- "Done" closes the popover and fires an HTMX request that swaps the table.
- "Clear" empties the selection and closes; same swap fires.
- Click-outside closes without applying.
- Keyboard: `Esc` closes; arrow keys + `Space` navigate and toggle.

### Backend

`/portfolio/positions` gains one query parameter:

```
&symbols=AAPL,MSFT,GOOG
```

Filtering happens after `compute_open_positions` and before pagination, replacing today's `q` substring filter. The `q` query parameter and its UI input are removed; `symbols` is the only filter on this dimension going forward.

### State persistence

- The selection is part of the URL (`?symbols=...`), so reload preserves it.
- When a selected symbol drops out of scope (e.g., user switches to a year where it wasn't held), it is silently removed from the chip list. A one-render hint `(2 symbols out of scope)` appears next to the trigger.
- Period/account toolbar swaps preserve the current `symbols` selection.

### Implementation

Alpine.js component for popover open/close + checkbox state; HTMX for the swap. No new vendored libraries.

### Acceptance

- Selecting symbols narrows the table to those tickers; clearing returns to "All".
- Reloading the page with `?symbols=AAPL,MSFT` restores the chip and filter.
- Switching to a period where a selected symbol has no rows shows the out-of-scope hint and the symbol is gone from the chip list on the next interaction.

## 4. "Choose Files" button restyle

### Problem

`templates/_import_modal.html` uses a raw `<input type="file">`. On dark surface, the OS-default button is nearly invisible (see screenshot 2026-04-26).

### Fix

Hide the native input, add a styled button that proxies clicks, and show a file-count chip beside it. Pattern mirrors the existing `_drop_zone.html` "click to browse" link.

```html
<div class="flex items-center gap-3">
  <button type="button" class="btn-ghost" onclick="this.nextElementSibling.click()">
    Choose files
  </button>
  <input type="file" name="files" accept=".csv" multiple required class="hidden"
         onchange="(function(el){
           const c = el.files.length;
           const span = el.parentElement.querySelector('.file-chip');
           if (c === 0) { span.textContent = 'No files selected'; return; }
           const names = Array.from(el.files).slice(0, 2).map(f => f.name).join(', ');
           span.textContent = c + ' file' + (c === 1 ? '' : 's') + ': ' + names + (c > 2 ? ' +' + (c - 2) : '');
         })(this)"/>
  <span class="file-chip text-[12px] text-label-2">No files selected</span>
</div>
```

The input is still `required` and its `name="files"` is unchanged, so the form submit path is unaffected.

### Acceptance

- Modal opens on the dark surface; the "Choose files" button is clearly visible (not relying on OS chrome).
- Clicking it opens the OS file picker.
- File count + a sample of names appears in the chip.
- Submitting still posts the files to `/imports` exactly as today.

## 5. Equity curve & allocation equal width

`templates/portfolio.html` line 28: `grid-template-columns: 1fr 1.55fr;` → `grid-template-columns: 1fr 1fr;`.

The allocation panel becomes narrower. The 148px donut still fits; the chip leaderboard wraps. Spot-check at 1280, 1440, 1920 viewport widths and tighten chip `gap` only if cramped — no template structural change.

### Acceptance

- The two panels render at equal width on the `/portfolio` page across the spot-checked viewports.

## File-level change map

| File                                                           | Change                                                                       |
| -------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| `src/net_alpha/web/routes/portfolio.py`                        | Add `/portfolio/body` handler that bundles the existing compute calls.       |
| `src/net_alpha/web/routes/holdings.py` *(new)*                 | New `/holdings` page route. Reuses `/portfolio/positions` fragment.          |
| `src/net_alpha/web/routes/__init__.py`                         | Register the new holdings router.                                            |
| `src/net_alpha/web/templates/portfolio.html`                   | Single `hx-get` to `/portfolio/body`; equity/allocation columns to `1fr 1fr`. |
| `src/net_alpha/web/templates/_portfolio_body.html` *(new)*     | Includes existing `_portfolio_*` partials sans positions.                    |
| `src/net_alpha/web/templates/holdings.html` *(new)*            | Toolbar + `<div id="holdings-positions" hx-get="...">`.                       |
| `src/net_alpha/web/templates/_portfolio_table.html`            | Replace `<input type="search" name="q">` with the multi-select popover.       |
| `src/net_alpha/web/templates/base.html`                        | Add "Holdings" nav link.                                                     |
| `src/net_alpha/web/templates/_import_modal.html`               | Restyle the file input as button + chip.                                      |
| `tests/web/test_portfolio.py` *(extend)*                       | Add tests for `/portfolio/body`, `/holdings`, `&symbols=` filter.             |

## Testing strategy

- **Unit tests:** the symbol-filter list logic in `/portfolio/positions` (case-insensitive match, comma-split, empty-string handled). Pure Python.
- **Route tests** (existing `tests/web/`): add cases for
  - `GET /portfolio/body` returns 200 and contains the expected panel IDs.
  - `GET /holdings` returns 200 and includes the table.
  - `GET /portfolio/positions?symbols=AAPL,MSFT` filters to the two symbols.
  - `GET /portfolio` no longer contains the positions table markup.
  - Topbar nav contains the "Holdings" link.
- **Snapshot/spot-check (manual):** load `/portfolio` on a representative DB; record warm-load time; verify < 2s.

## Rollout

Single PR. No data migration. No config flag. The 5 existing fragment routes stay reachable, so the change is reversible by reverting the page template alone.

## Out of scope (Spec B)

Manual trade add/edit/delete on the ticker timeline. That feature touches the data-write story (idempotent natural-key, wash-sale incremental recompute, audit/provenance, import-vs-manual reconciliation) and gets its own design.
