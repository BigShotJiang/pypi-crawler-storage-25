# Portfolio bugfixes + Wash Sales merge + Split handling — design

**Date:** 2026-04-26
**Status:** Draft → ready for plan
**Scope:** Six items reported against the Portfolio / Holdings / Detail / Calendar pages: column cleanup, two HTML/Alpine bugs, a top-nav restructure that merges Detail and Calendar into a single "Wash sales" page, and the introduction of stock-split handling (Yahoo-sourced, with a manual-edit fallback).

Item 3 ("what else to put on Portfolio") is intentionally **deferred** — the user opted out of that work for this batch. This spec covers items 1, 2, 4, 5, 6 from the original report.

## Problem

The web UI has two clusters of issues:

**Bugs and small UI tweaks (items 1, 4, 6):**
- Holdings table shows an unhelpful `YTD 2026 Realized` column and the `Unrealized` column shows only dollars, not percent — hard to compare positions of different sizes.
- The multi-symbol search dropdown on the Holdings toolbar renders in the wrong place (the Apr 26 screenshot shows it pinned to the viewport's left edge, far from its trigger button) and the inline Alpine `x-data` expression is leaking as visible text into the page body.
- The page-scoped toolbar (Period / Account selectors) is shared between Portfolio and Holdings, but its form `action` is hard-coded to `/`. Changing Account on Holdings bounces the user to Portfolio.

**Structural cleanup (item 2):**
- Three top-nav pages — Detail, Calendar, Sim — feel poorly named and uncombined. Detail and Calendar are two views of the same wash-sale violation data (one tabular, one date-ribbon). They should merge.

**Data correctness (item 5):**
- `wash-alpha` has no concept of stock splits. The wash-sale engine and `compute_open_positions` operate on raw broker quantities. Schwab CSVs record splits in non-Buy/non-Sell rows that the parser silently drops. A symbol like SQQQ (1-for-10 reverse split during the user's holding period) currently shows ~10× the real share count.

## Goals

1. Drop the `{period} Realized` column from Holdings; combine $ and % into the `Unrealized` cell.
2. Fix the multi-symbol search dropdown so it positions under its trigger button and stops leaking JS text into the page.
3. Fix the toolbar form so submitting it stays on the current page.
4. Rename `Detail` → `Wash sales`. Merge Calendar into the same page as a `view=calendar` mode. Keep Sim as a separate page.
5. Add a `splits` table fed by Yahoo Finance via the existing pricing pipeline, mutate lots in place when a split is recorded, and re-apply on re-import. Manual lot edits available on the per-ticker page as the override path.

## Non-goals

- Item 3 (additional Portfolio panels) — explicitly deferred by the user.
- A general-purpose corporate-actions framework. Splits only. No spinoffs, mergers, dividend reinvestment, name changes.
- Multi-broker split detection. Schwab CSVs do contain split rows, but parsing them is broker-specific and Yahoo gives us the same data uniformly. Rely on Yahoo.
- Backfilling splits before the user's earliest import date — only splits whose ex-date falls on or after the earliest open lot's date for that symbol matter.
- Undo for split application. Re-running sync is idempotent (keyed on `(symbol, date)`); manual lot edits provide the escape hatch.

---

## Item 1 — Holdings table columns

**Files:** `src/net_alpha/web/templates/_portfolio_table.html`

Drop the `{{ period_label }} Realized` column entirely. Today it occupies one `<th>` (line 145) and one `<td>` (lines 175–177). Remove both. Realized P/L is already on the Portfolio page KPIs and on the per-ticker Timeline; in the Holdings table it just adds noise.

Update the `Unrealized` cell to show two stacked lines:

```
+$1,234.56
+12.3%
```

Both lines use the same color (pos/neg/neutral). Percent is computed from the existing data already on `PositionRow`:

```python
unrealized_pct = (unrealized_pl / open_cost) if open_cost else None
```

When `open_cost` is zero or `unrealized_pl is None`, render `—` for the percent line (the dollar line already handles `None` with `—`).

No change to `PositionRow` or the route — purely template work.

## Item 4 — Multi-symbol search dropdown

**Files:** `src/net_alpha/web/templates/_portfolio_table.html`, new `src/net_alpha/web/static/holdings_filter.js`

The current dropdown lives in a 27-line inline `x-data` block (lines 21–47) defining state and four methods. The screenshot shows two failures:
- The dropdown panel appears at the page's left edge instead of below its button.
- The body of the `x-data` expression renders as visible text — meaning Alpine couldn't evaluate the expression, so `x-text="label()"` left the button empty *and* nothing was wired up to suppress the surrounding text from rendering.

Both symptoms point to the same root cause: a parse failure of the inline multi-line `x-data` (probably due to Jinja-injected `{{ … |tojson }}` content interacting badly with HTML attribute quoting on a long, multi-line attribute).

**Fix:** Extract the component to a named Alpine component in a small static file:

```js
// src/net_alpha/web/static/holdings_filter.js
document.addEventListener('alpine:init', () => {
  Alpine.data('symbolFilter', (config) => ({
    open: false,
    query: '',
    selected: config.selected,
    all: config.all,
    qsTemplate: config.qsTemplate,
    show: config.show,
    pageSize: config.pageSize,
    toggle(s) { /* ... */ },
    filtered() { /* ... */ },
    label() { /* ... */ },
    apply() { /* ... */ },
    clear() { this.selected = []; this.apply(); },
  }));
});
```

The template becomes:

```html
<div x-data='symbolFilter({{ symbol_filter_config|tojson }})' class="relative inline-block">
```

The route passes a single `symbol_filter_config` dict containing `selected`, `all`, `qsTemplate`, `show`, `pageSize`. The template `x-data` reduces to one short attribute — no multi-line embedded JS.

Add `<script src="/static/holdings_filter.js" defer></script>` to `base.html` alongside the existing alpine/htmx scripts.

This eliminates the inline-parse fragility (root cause of the text leak) and standardizes the component for future reuse. The dropdown's `class="absolute z-20 mt-1 left-0 w-64"` stays — once Alpine evaluates correctly, the button renders with width and `left-0` anchors the panel under it as intended.

If after extraction the dropdown still mis-positions, the secondary fix is to verify the `relative inline-block` parent isn't being collapsed by `flex-wrap` — but the inline-evaluation failure is the primary suspect and fixing it should make the symptom go away.

## Item 6 — Toolbar form action

**Files:** `src/net_alpha/web/templates/_portfolio_toolbar.html`, `src/net_alpha/web/routes/portfolio.py`, `src/net_alpha/web/routes/holdings.py`

Change the form's hard-coded `action="/"` to `action="{{ toolbar_action }}"`.

Each page route that includes `_portfolio_toolbar.html` passes its own path:
- `portfolio.py:portfolio_page` → `toolbar_action="/"`
- `holdings.py:holdings_page` → `toolbar_action="/holdings"`

The Wash Sales page (item 2) has its own filter form (`ticker / account / year / confidence`) and does not use `_portfolio_toolbar.html`, so this change is scoped to the Portfolio and Holdings pages only.

## Item 2 — Wash sales page (merge Detail + Calendar)

**Files:**
- New: `src/net_alpha/web/routes/wash_sales.py`, `src/net_alpha/web/templates/wash_sales.html`
- Move/rename: `_detail_table.html`, `_calendar_ribbon.html`, `_calendar_focus.html`, `_calendar_pl_ribbon.html` stay as fragments under their existing names — only their parent template changes.
- Delete: `src/net_alpha/web/routes/detail.py`, `src/net_alpha/web/routes/calendar.py`, `src/net_alpha/web/templates/detail.html`, `src/net_alpha/web/templates/calendar.html`
- Edit: `src/net_alpha/web/templates/base.html` (nav links), `src/net_alpha/web/app.py` (router registration), any internal links pointing to `/detail` or `/calendar`.

### Routing

| URL | Behavior |
|---|---|
| `/wash-sales` | Renders the merged page. Default view = table. |
| `/wash-sales?view=calendar` | Same page, calendar view. |
| `/wash-sales?view=table` | Same page, table view. (Explicit form for completeness.) |
| `/detail` | 301 redirect → `/wash-sales` (preserving query string) |
| `/calendar` | 301 redirect → `/wash-sales?view=calendar` (preserving query string) |

The redirects let any browser bookmark or external link survive. They are minimal `RedirectResponse(url, status_code=301)` handlers that the new `wash_sales` router owns.

### Template structure

```jinja
{# wash_sales.html #}
{% extends "base.html" %}
{% set active_page = 'wash_sales' %}

  <h1>Wash sales</h1>

  {# Unified filter bar — used by both views #}
  <form method="get" class="panel ...">
    <input type="hidden" name="view" value="{{ view }}"/>
    {# ticker / account / year / confidence — same fields both views need #}
  </form>

  {# View toggle — segmented control #}
  <div class="seg">
    <a href="/wash-sales?{{ filter_qs }}&view=table"     class="{% if view == 'table'    %}seg-active{% endif %}">Table</a>
    <a href="/wash-sales?{{ filter_qs }}&view=calendar"  class="{% if view == 'calendar' %}seg-active{% endif %}">Calendar</a>
  </div>

  {% if view == 'calendar' %}
    {% include "_calendar_ribbon.html" %}
    <div id="focus-strip" class="mt-6"></div>
  {% else %}
    {# totals bar + detail table #}
    {% if summary.violation_count > 0 %}<div class="panel ..."> ... </div>{% endif %}
    {% include "_detail_table.html" %}
  {% endif %}
```

The route consolidates both old routes' context-building into one function. Filters are unified — `ticker`, `account`, `year`, `confidence` apply identically to both views. The Calendar's `year` filter and the Detail's `year` filter become the same field.

### Top-nav

`base.html:21-28` — replace the two links:

```diff
-  <a href="/calendar" class="...">Calendar</a>
   <a href="/imports" class="...">Imports</a>
   <a href="/sim" class="...">Sim</a>
-  <a href="/detail" class="...">Detail</a>
+  <a href="/wash-sales" class="...">Wash sales</a>
```

`active_page` flag becomes `'wash_sales'`.

### Internal references

Grep the codebase for hardcoded `/detail` and `/calendar` (in templates and Python). Each is rewritten to point at `/wash-sales` (with `?view=calendar` where appropriate). Likely candidates: violation card, KPI links on Portfolio, any `htmx-get` URL in fragments. The grep is done as part of execution.

---

## Item 5 — Stock-split handling

This is the largest change. It touches the data model, the import pipeline, the wash-sale engine's incremental recompute, the pricing service, and adds a manual-edit UI on the ticker page.

### Data model

New SQLite table:

```sql
CREATE TABLE splits (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol      TEXT NOT NULL,
    split_date  TEXT NOT NULL,         -- YYYY-MM-DD ex-date
    ratio       REAL NOT NULL,         -- new shares ÷ old shares; 2.0 = 2-for-1; 0.1 = 1-for-10 reverse
    source      TEXT NOT NULL,         -- 'yahoo' | 'manual'
    fetched_at  TEXT NOT NULL,         -- ISO8601 UTC timestamp
    UNIQUE(symbol, split_date)
);
CREATE INDEX idx_splits_symbol ON splits(symbol);
```

Schema bump `schema_version` to N+1. Migration: `CREATE TABLE` only; no backfill. Existing lots stay as-is until a split is sync'd.

New `lot_overrides` table for manual lot edits (audit trail):

```sql
CREATE TABLE lot_overrides (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    lot_id          TEXT NOT NULL,
    field           TEXT NOT NULL,         -- 'quantity' | 'adjusted_basis'
    old_value       REAL NOT NULL,
    new_value       REAL NOT NULL,
    reason          TEXT NOT NULL,         -- 'split' | 'manual' | 'transfer_basis_fix'
    edited_at       TEXT NOT NULL,
    FOREIGN KEY(lot_id) REFERENCES lot(id)
);
```

`reason='split'` rows are written automatically when a split is applied; `reason='manual'` rows when a user uses the per-lot edit UI.

### Yahoo split fetch

**File:** `src/net_alpha/pricing/provider.py` (extend `YahooPriceProvider`), `src/net_alpha/pricing/service.py`

`yfinance.Ticker(sym).splits` returns a pandas Series indexed by date with the ratio as the value (Yahoo emits `2.0` for a 2-for-1 forward split, `0.1` for a 1-for-10 reverse — same convention we'll store in the `splits` table). Same call cost as `Ticker.history`. Wrap in `try/except` like the existing quote fetch.

New small Pydantic model in `pricing/provider.py`:

```python
class SplitEvent(BaseModel):
    symbol: str
    split_date: date
    ratio: float  # new shares ÷ old shares; matches Yahoo's convention
```

```python
def fetch_splits(self, symbol: str) -> list[SplitEvent]:
    """Returns list of SplitEvent(symbol, split_date, ratio). Empty list on error or no splits."""
```

`PricingService` gets a sibling method to `refresh()`:

```python
def sync_splits(self, symbols: list[str]) -> SplitSyncResult:
    """For each symbol, fetch from Yahoo, upsert into splits table on (symbol, split_date),
    and apply any newly-discovered splits to existing open lots."""
```

`SplitSyncResult` returns: `applied_count`, `skipped_count` (already-recorded), `error_symbols`. Honors `prices.enable_remote: false` — when disabled, returns immediately with all error_symbols and no network call.

### Application logic

**File:** new `src/net_alpha/splits/apply.py`

When a split `(symbol, split_date, ratio)` is newly inserted into the `splits` table, apply it to lots:

```python
# src/net_alpha/splits/apply.py
def apply_split(repo: Repository, split: Split) -> int:
    """Mutate every open lot for `split.symbol` whose date < split.split_date.
    For each affected lot:
        new_qty   = old_qty * split.ratio
        new_basis = old_basis           (unchanged — total basis is dollars, not per-share)
    Write ONE lot_overrides row per affected lot, field='quantity', reason='split'.
    (No row written for basis since it didn't change.)
    Returns count of lots affected.
    After all mutations, trigger one incremental wash-sale recompute on the ±30-day
    window around split.split_date.
    """
```

Note: total `adjusted_basis` is preserved (basis is dollar value, not per-share). Quantity changes; per-share avg basis derives from the new ratio at read time via `compute_open_positions`'s existing `avg_basis = open_cost / qty`.

### Re-import safety

When `csv_loader` creates new lots for a symbol (e.g., user `imports rm`'d then re-imported), it must re-apply existing recorded splits. Add to the import flow:

```python
# After lots are persisted
for sym in {lot.ticker for lot in new_lots if lot.option_details is None}:
    splits = repo.get_splits(sym)
    for sp in splits:
        apply_split(repo, sp)  # idempotent — checks lot_overrides for existing reason='split' rows
```

`apply_split` checks for an existing `lot_overrides` row with matching `(lot_id, field, reason='split')` for that exact split before mutating, so calling it twice is a no-op. Splits applied to lots dated *after* the split's ex-date are skipped (lot already reflects post-split shares).

### Toolbar Sync button

**Files:** `_portfolio_toolbar.html`, `src/net_alpha/web/routes/portfolio.py`

Add a `Sync splits` button next to `Refresh` (price) on the toolbar:

```html
<button type="button"
        hx-post="/splits/sync?symbols=ALL"
        hx-target="body" hx-swap="none"
        onclick="window.location.reload()"
        class="btn-ghost">⇅ Sync splits</button>
```

New endpoint `POST /splits/sync`:

```python
@router.post("/splits/sync")
def sync_splits(symbols: str | None = "ALL", svc: PricingService, repo: Repository):
    if symbols == "ALL":
        sym_list = sorted({lot.ticker for lot in repo.all_lots() if lot.option_details is None})
    else:
        sym_list = [s.strip() for s in symbols.split(",") if s.strip()]
    return svc.sync_splits(sym_list)
```

### Auto-sync on first import of a symbol

Inside the import command (CLI default + `imports` flow), after lots are persisted:

```python
new_symbols = {lot.ticker for lot in new_lots if lot.option_details is None} - existing_symbols
if new_symbols and config.prices.enable_remote:
    pricing_service.sync_splits(sorted(new_symbols))
```

`existing_symbols` = set of symbols present in `lots` *before* this import. So subsequent imports of the same symbol don't re-fetch; only the first time we see a symbol triggers an auto-fetch.

### Manual lot edit UI

**Files:** `src/net_alpha/web/templates/_lots_table.html`, `src/net_alpha/web/routes/ticker.py`

Reuse the manual-trade CRUD machinery from spec `2026-04-26-manual-trade-crud-design.md` (commit `2123f5e`). On the per-ticker page, each row in the lots table gets an "Edit" pencil icon. Click → HTMX swap to an inline form with two fields: `quantity` and `adjusted_basis`. Save → POST to `/lots/{lot_id}/edit` → write a `lot_overrides` row with `reason='manual'` → mutate the lot → trigger incremental wash-sale recompute on ±30 days → swap row back.

A small text in the lot row footer notes any prior `lot_overrides` entries: "Edited 2× (manual, split)". Hover for details.

The endpoint:

```python
@router.post("/lots/{lot_id}/edit")
def edit_lot(lot_id: str, quantity: float, adjusted_basis: float, repo: Repository):
    lot = repo.get_lot(lot_id)
    if lot is None: raise HTTPException(404)
    repo.add_lot_override(lot.id, "quantity", lot.quantity, quantity, "manual")
    repo.add_lot_override(lot.id, "adjusted_basis", lot.adjusted_basis, adjusted_basis, "manual")
    repo.update_lot(lot_id, quantity=quantity, adjusted_basis=adjusted_basis)
    repo.recompute_wash_sales_for_window(lot.ticker, lot.date)
    return _render_lot_row(lot_id)
```

### Wash-sale recompute interaction

The existing `engine.recompute_window` works on a date-centered ±30 day window. After applying splits, the window is centered on `split.split_date`. After manual edits, on `lot.date`. This is already the model used by import / unimport, so we reuse it.

Splits don't introduce wash-sale violations themselves (no realized gain/loss on a split), but the changed lot quantity/basis can affect existing violations' calculations. Recomputing the window is the safe path.

---

## Component boundaries

| Module | Owns | Doesn't own |
|---|---|---|
| `pricing/provider.py` | Yahoo `Ticker.splits` fetch, error handling | Persistence, application |
| `pricing/service.py` | Orchestration: fetch → upsert → call `apply_split` | Mutation logic itself |
| `db/repository.py` | `splits` and `lot_overrides` table CRUD; `get_splits(sym)`, `add_lot_override`, `update_lot` | Business rules |
| `splits/apply.py` (new) | `apply_split(repo, split)` — pure mutation logic, idempotent | Network, scheduling |
| `web/routes/wash_sales.py` (new) | Merged Detail+Calendar route | Filter UI specifics (template) |
| `web/routes/portfolio.py` | `/splits/sync` endpoint (existing module owns price-related routes) | Application logic |
| `web/templates/_portfolio_table.html` | Holdings table layout (item 1) | |
| `web/static/holdings_filter.js` (new) | `symbolFilter` Alpine component (item 4) | |

---

## Testing

**Unit tests (new):**
- `tests/splits/test_apply.py` — `apply_split` correctness:
  - Forward 2-for-1 doubles qty, preserves total basis.
  - Reverse 1-for-10 (ratio=0.1) shrinks qty to 1/10, preserves total basis.
  - Idempotency: applying the same split twice writes only one `lot_overrides` row.
  - Lots dated after the ex-date are not touched.
  - Lots in non-matching symbol are not touched.
  - Wash-sale recompute is invoked on the correct window.
- `tests/db/test_repository_splits.py` — table CRUD, `(symbol, split_date)` unique constraint.
- `tests/pricing/test_yahoo_splits.py` — mocked `yfinance.Ticker.splits` fixture; verifies parsing and error fallback.

**Integration tests (new):**
- `tests/integration/test_split_e2e.py` — import a CSV with SQQQ-style holdings → call `sync_splits` with a fixture that returns a known split → assert lot quantities are reduced and wash-sale violations are recomputed.
- `tests/integration/test_reimport_preserves_splits.py` — import → sync split → `imports rm` → re-import → verify lots arrive split-adjusted.

**Web tests (new/extended):**
- `tests/web/test_wash_sales_route.py` — `/wash-sales` renders both views; `view=` toggle works; filters apply to both. `/detail` and `/calendar` redirect 301 with query string preserved.
- `tests/web/test_holdings_template.py` — Holdings table no longer renders the realized column; Unrealized cell shows both $ and %.
- `tests/web/test_toolbar_action.py` — toolbar form's `action` matches the page it's embedded in.

**Manual smoke (after implementation):**
- Open `/holdings`, change Account, verify URL stays on `/holdings`.
- Open the multi-symbol search dropdown, verify it appears below the trigger button and contains the symbol list.
- Click `Sync splits`, verify SQQQ shrinks to the correct count.
- Visit `/detail` and `/calendar` directly, verify both 301 to the new page.

---

## Migration

Schema version bump (next free integer in `meta`). Migration is additive — two new tables, no changes to existing tables. Run on first DB open after upgrade. No data backfill; existing lots remain as-is until the user runs `Sync splits`.

The user's existing SQQQ situation is fixed by clicking `Sync splits` after the upgrade. No manual intervention.

## Risks

| Risk | Mitigation |
|---|---|
| Yahoo returns a split we already applied via a different ratio (data correction). | The unique `(symbol, split_date)` constraint blocks duplicates; on conflict, we leave the existing row (don't rewrite history without user intent). User can manually edit the lot if Yahoo's data was wrong the first time. |
| Yahoo split data lags or is missing for a symbol. | Manual lot-edit UI is the escape hatch. |
| Schwab CSV has its own split rows that we now ignore. | Continue to ignore. Yahoo is canonical. Document this in the CLAUDE.md note about parser behavior. |
| Wash-sale recompute on a split window is slow on a large DB. | Existing recompute is already incremental and bounded; splits are rare events. No new perf concern. |
| Inline `x-data` extraction (item 4) breaks the component on browsers. | Covered by manual smoke. The Alpine component pattern is well-documented and we already use Alpine elsewhere; this is a routine refactor. |
| `/detail` and `/calendar` 301s break someone's bookmarks. | The redirects preserve query strings; this is a strict improvement. |

## Open questions

None. All design decisions confirmed in the brainstorm.
