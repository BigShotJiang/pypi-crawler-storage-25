# Portfolio bugfixes + Wash Sales merge + Split handling — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship items 1, 2, 4, 5, 6 from the user's bug/improvement report against the local web UI: clean up the Holdings table, fix the multi-symbol filter dropdown, fix the toolbar form action, merge Detail+Calendar into a single `/wash-sales` page, and add stock-split handling (Yahoo-sourced + manual lot-edit fallback).

**Architecture:** Five logical groups, executed in phase order so each phase is independently shippable: (1) tiny template/route fixes, (2) Alpine component extraction, (3) page merge with 301 redirects, (4) split-handling subsystem (new `splits` and `lot_overrides` tables, Yahoo fetcher, post-recompute mutation step), (5) per-lot manual edit UI.

**Tech Stack:** Python 3.11, FastAPI, Jinja2, HTMX, Alpine.js, SQLModel/SQLite, yfinance, pytest. Existing patterns reused: `recompute_all_violations` for wash-sale recompute, `_migrate_vN_to_vNplus1` for hand-written migrations, `Repository` for all DB access.

**Spec:** `docs/superpowers/specs/2026-04-26-portfolio-bugfixes-and-wash-sales-merge-design.md`

**Refinements vs spec (discovered during planning):**

- `recompute_all_violations` calls `replace_lots_in_window` which **fully replaces lots** in the date window every time — lots are derived from trades, not stable rows. So split application must happen as the **final step inside `recompute_all_violations`**, not just at re-import. This is the only architecturally correct place. The user-visible behavior described in the spec is unchanged.
- `lot_overrides` records are keyed by `trade_id` (the BUY trade that produced the lot), not `lot_id`, since `lot_id` is regenerated on each recompute. `trade_id` is stable.

---

## Pre-flight

- [ ] **Step 0.1: Read the spec end-to-end before starting**

```bash
cat docs/superpowers/specs/2026-04-26-portfolio-bugfixes-and-wash-sales-merge-design.md
```

- [ ] **Step 0.2: Confirm the test suite is green at HEAD**

```bash
uv run pytest -q
```

Expected: all tests pass. If anything fails, stop and surface it before starting work.

---

## Phase 1 — Quick UI fixes (Items 1 + 6)

These are template-only and ship independently.

### Task 1: Fix toolbar form action (Item 6)

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_toolbar.html:1`
- Modify: `src/net_alpha/web/routes/portfolio.py` (portfolio_page handler)
- Modify: `src/net_alpha/web/routes/holdings.py` (holdings_page handler)
- Test: `tests/web/test_toolbar_action.py` (new)

- [ ] **Step 1.1: Write the failing test**

```python
# tests/web/test_toolbar_action.py
"""The shared period/account toolbar must POST back to the page that rendered it,
not always to /. Otherwise changing Account on /holdings bounces to /."""

from fastapi.testclient import TestClient


def test_toolbar_form_action_on_portfolio_page(client: TestClient, builders, repo):
    from datetime import date
    builders.seed_import(repo, "schwab", "lt", [builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5))])
    res = client.get("/")
    assert res.status_code == 200
    assert 'action="/"' in res.text


def test_toolbar_form_action_on_holdings_page(client: TestClient, builders, repo):
    from datetime import date
    builders.seed_import(repo, "schwab", "lt", [builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5))])
    res = client.get("/holdings")
    assert res.status_code == 200
    assert 'action="/holdings"' in res.text
    assert 'action="/"' not in res.text
```

- [ ] **Step 1.2: Run test to verify it fails**

```bash
uv run pytest tests/web/test_toolbar_action.py -v
```

Expected: `test_toolbar_form_action_on_holdings_page` FAILS (currently `action="/"`).

- [ ] **Step 1.3: Edit the toolbar template**

Replace `_portfolio_toolbar.html:1`:

```html
<form method="get" action="{{ toolbar_action }}" class="kpi-card flex gap-3 flex-wrap items-end text-sm">
```

- [ ] **Step 1.4: Pass `toolbar_action` from portfolio_page**

In `src/net_alpha/web/routes/portfolio.py`, in the context dict returned by `portfolio_page` (around line 78), add:

```python
"toolbar_action": "/",
```

- [ ] **Step 1.5: Pass `toolbar_action` from holdings_page**

Open `src/net_alpha/web/routes/holdings.py` and locate the context dict in `holdings_page`. Add:

```python
"toolbar_action": "/holdings",
```

(If the route is rendered another way, ensure `toolbar_action` is in the template context one way or another.)

- [ ] **Step 1.6: Run test to verify it passes**

```bash
uv run pytest tests/web/test_toolbar_action.py -v
```

Expected: both tests PASS.

- [ ] **Step 1.7: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_toolbar.html \
        src/net_alpha/web/routes/portfolio.py \
        src/net_alpha/web/routes/holdings.py \
        tests/web/test_toolbar_action.py
git commit -m "fix(web): toolbar form stays on the current page (item 6)

Previously the period/account toolbar always submitted to /, bouncing the
user from /holdings back to portfolio when they changed Account. Now each
page passes its own toolbar_action."
```

### Task 2: Holdings table — drop Realized column, add % to Unrealized (Item 1)

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_table.html:138-181`
- Test: `tests/web/test_holdings_template.py` (new)

- [ ] **Step 2.1: Write the failing test**

```python
# tests/web/test_holdings_template.py
"""Holdings table layout: no Realized column, Unrealized shows $ + %."""

from datetime import date

from fastapi.testclient import TestClient


def test_holdings_table_omits_realized_column(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5), qty=10, cost=1500),
    ])
    res = client.get("/portfolio/positions?period=ytd&account=&group_options=merge&show=open&page=1")
    assert res.status_code == 200
    # Header text "YTD 2026 Realized" must not appear.
    assert "Realized" not in res.text or "Realized P/L" not in res.text
    # And the column header tooltip text from the spec is gone:
    assert "Sum of (proceeds − cost basis)" not in res.text


def test_holdings_unrealized_shows_dollars_and_percent(client: TestClient, builders, repo, monkeypatch):
    """When a quote is available, Unrealized shows $ on top and % below."""
    from decimal import Decimal
    from datetime import datetime, timezone
    from net_alpha.pricing.provider import Quote

    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5), qty=10, cost=1000),
    ])

    def fake_get_prices(self, symbols):
        return {"AAPL": Quote(
            symbol="AAPL",
            price=Decimal("150"),  # MV = 1500, unrealized = +500, +50%
            as_of=datetime.now(timezone.utc),
            source="yahoo",
        )}

    monkeypatch.setattr("net_alpha.pricing.service.PricingService.get_prices", fake_get_prices)

    res = client.get("/portfolio/positions?period=ytd&account=&group_options=merge&show=open&page=1")
    assert res.status_code == 200
    # Both dollar and percent should appear in the rendered cell.
    assert "+$500.00" in res.text
    assert "+50.0%" in res.text
```

- [ ] **Step 2.2: Run test to verify it fails**

```bash
uv run pytest tests/web/test_holdings_template.py -v
```

Expected: `test_holdings_unrealized_shows_dollars_and_percent` FAILS (no percent rendered today).

- [ ] **Step 2.3: Edit `_portfolio_table.html` — remove Realized column header**

Delete the `<th>` at line 145:

```html
          <th class="r" title="Sum of (proceeds − cost basis) on Sell trades within the selected period. Wash-sale-disallowed losses are excluded (they roll into the replacement lot).">{{ period_label }} Realized</th>
```

- [ ] **Step 2.4: Edit `_portfolio_table.html` — remove Realized column body cell**

Delete the `<td>` block at lines 175-177:

```html
            <td class="r num {% if r.realized_pl < 0 %}text-neg{% elif r.realized_pl > 0 %}text-pos{% endif %}">
              {% if r.realized_pl != 0 %}{% if r.realized_pl < 0 %}-{% else %}+{% endif %}${{ "%.2f"|format(r.realized_pl|float|abs) }}{% else %}—{% endif %}
            </td>
```

- [ ] **Step 2.5: Edit `_portfolio_table.html` — Unrealized cell shows $ + %**

Replace lines 178-181 (the existing Unrealized `<td>`):

```html
            <td class="r num {% if r.unrealized_pl is not none and r.unrealized_pl < 0 %}text-neg{% elif r.unrealized_pl is not none and r.unrealized_pl > 0 %}text-pos{% endif %}">
              {% if r.unrealized_pl is none %}
                <span class="text-label-3">—</span>
              {% else %}
                <div>{% if r.unrealized_pl < 0 %}-{% else %}+{% endif %}${{ "%.2f"|format(r.unrealized_pl|float|abs) }}</div>
                {% if r.open_cost and r.open_cost|float != 0 %}
                  {% set pct = (r.unrealized_pl|float / r.open_cost|float) * 100 %}
                  <div class="text-[11px] opacity-80">{% if pct < 0 %}-{% else %}+{% endif %}{{ "%.1f"|format(pct|abs) }}%</div>
                {% else %}
                  <div class="text-[11px] text-label-3">—</div>
                {% endif %}
              {% endif %}
            </td>
```

- [ ] **Step 2.6: Run test to verify it passes**

```bash
uv run pytest tests/web/test_holdings_template.py -v
```

Expected: both tests PASS.

- [ ] **Step 2.7: Run the full holdings/portfolio test suite to catch regressions**

```bash
uv run pytest tests/web/test_holdings_routes.py tests/web/test_portfolio_routes.py -v
```

Expected: PASS. If any test asserts on the Realized column being present, update it to match the new layout.

- [ ] **Step 2.8: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_table.html tests/web/test_holdings_template.py
git commit -m "feat(web): drop Realized col, add % to Unrealized on Holdings (item 1)

The {period} Realized column was redundant with Portfolio KPIs and the
Timeline. Unrealized now stacks dollar and percent inline, color-coded
together. Percent is unrealized_pl / open_cost."
```

---

## Phase 2 — Multi-symbol filter refactor (Item 4)

Extract the inline `x-data` block to a named Alpine component. This fixes both the position bug and the text leak.

### Task 3: Extract symbolFilter Alpine component

**Files:**
- Create: `src/net_alpha/web/static/holdings_filter.js`
- Modify: `src/net_alpha/web/templates/base.html` (add script tag)
- Modify: `src/net_alpha/web/templates/_portfolio_table.html:21-79` (replace inline x-data)
- Modify: `src/net_alpha/web/routes/portfolio.py` (build symbol_filter_config dict)
- Test: `tests/web/test_holdings_filter.py` (new)

- [ ] **Step 3.1: Write the failing test**

```python
# tests/web/test_holdings_filter.py
"""The multi-symbol filter on the Holdings toolbar must:
1. Render with no leaked Alpine expression text in the page body.
2. Reference the named Alpine component (symbolFilter) — not a 30-line inline x-data.
"""

from datetime import date

from fastapi.testclient import TestClient


def test_no_alpine_expression_text_leaks(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5)),
    ])
    res = client.get("/portfolio/positions?period=ytd&account=&group_options=merge&show=open&page=1")
    assert res.status_code == 200
    # The body of the old x-data leaked these strings to the rendered page.
    # After extraction, only the call site `symbolFilter({...})` should appear.
    assert "this.selected.indexOf" not in res.text
    assert "this.all.filter" not in res.text
    assert "filtered()" not in res.text  # method body should not appear in page text
    # The Alpine component name should be present as the x-data value.
    assert "symbolFilter(" in res.text


def test_static_holdings_filter_js_served(client: TestClient):
    res = client.get("/static/holdings_filter.js")
    assert res.status_code == 200
    assert "Alpine.data" in res.text
    assert "symbolFilter" in res.text


def test_base_template_loads_holdings_filter_script(client: TestClient, builders, repo):
    res = client.get("/")
    assert res.status_code == 200
    assert "/static/holdings_filter.js" in res.text
```

- [ ] **Step 3.2: Run test to verify it fails**

```bash
uv run pytest tests/web/test_holdings_filter.py -v
```

Expected: all three FAIL.

- [ ] **Step 3.3: Create the static JS file**

```js
// src/net_alpha/web/static/holdings_filter.js
//
// Named Alpine component for the multi-symbol filter on the Holdings toolbar.
// Extracted from inline x-data so the multi-line JS doesn't leak as visible text
// when Alpine fails to evaluate the expression.

document.addEventListener('alpine:init', () => {
  Alpine.data('symbolFilter', (config) => ({
    open: false,
    query: '',
    selected: config.selected || [],
    all: config.all || [],
    qsTemplate: config.qsTemplate || '',
    show: config.show || 'open',
    pageSize: config.pageSize || 25,

    toggle(s) {
      const i = this.selected.indexOf(s);
      if (i === -1) this.selected.push(s);
      else this.selected.splice(i, 1);
    },

    filtered() {
      const q = this.query.trim().toUpperCase();
      return q ? this.all.filter((s) => s.toUpperCase().includes(q)) : this.all;
    },

    label() {
      if (this.selected.length === 0) return 'Symbols: All';
      if (this.selected.length <= 2) return 'Symbols: ' + this.selected.join(', ');
      return (
        'Symbols: ' +
        this.selected.slice(0, 2).join(', ') +
        ' +' +
        (this.selected.length - 2)
      );
    },

    apply() {
      this.open = false;
      const url =
        '/portfolio/positions?' +
        this.qsTemplate.replace(
          /symbols=[^&]*/,
          'symbols=' + encodeURIComponent(this.selected.join(','))
        ) +
        '&show=' +
        this.show +
        '&page=1&page_size=' +
        this.pageSize;
      htmx.ajax('GET', url, { target: '#holdings-positions', swap: 'innerHTML' });
    },

    clear() {
      this.selected = [];
      this.apply();
    },
  }));
});
```

- [ ] **Step 3.4: Add the script tag to base.html**

In `src/net_alpha/web/templates/base.html`, after the existing alpine script tag (line 10), add:

```html
  <script src="/static/holdings_filter.js" defer></script>
```

(The `defer` ordering matters — alpine.min.js needs to load and fire `alpine:init`, then this file registers the component. Since both have `defer` and are in document order, ordering is preserved.)

- [ ] **Step 3.5: Replace the inline x-data block in `_portfolio_table.html`**

Replace lines 21-79 (the `<div x-data="{...}">` through its closing `</div>`):

```html
    <div x-data='symbolFilter({{ symbol_filter_config|tojson }})'
         class="relative inline-block">
      <button type="button"
              @click="open = !open"
              class="px-2 py-1 text-[12px] rounded-md"
              style="background: var(--color-surface); color: var(--color-text); border: 0.5px solid var(--color-hairline);"
              x-text="label()"></button>
      <div x-show="open" @click.outside="open = false"
           class="absolute z-20 mt-1 left-0 w-64 rounded-md p-2"
           style="background: var(--color-surface); border: 0.5px solid var(--color-hairline); box-shadow: 0 4px 24px rgba(0,0,0,0.4);">
        <input type="text" x-model="query" placeholder="Search…"
               class="w-full px-2 py-1 text-[12px] rounded-md mb-2"
               style="background: var(--color-bg); color: var(--color-text); border: 0.5px solid var(--color-hairline);"/>
        <div class="max-h-56 overflow-y-auto">
          <template x-for="s in filtered()" :key="s">
            <label class="flex items-center gap-2 py-[3px] text-[12px] cursor-pointer">
              <input type="checkbox"
                     :checked="selected.indexOf(s) !== -1"
                     @change="toggle(s)"/>
              <span x-text="s" class="font-mono"></span>
            </label>
          </template>
          <template x-if="filtered().length === 0">
            <div class="text-[11px] text-label-3 py-2 text-center">No matches.</div>
          </template>
        </div>
        <div class="flex justify-end gap-2 pt-2 mt-2" style="border-top: 0.5px solid var(--color-hairline);">
          <button type="button" @click="clear()" class="px-2 py-1 text-[11px] text-label-2 hover:text-text">Clear</button>
          <button type="button" @click="apply()" class="px-2 py-1 text-[11px] rounded-md"
                  style="background: var(--color-accent); color: var(--color-bg);">Done</button>
        </div>
      </div>
    </div>
```

(Note the use of single quotes around the `x-data` value so that the inner `tojson` output's double quotes don't conflict.)

- [ ] **Step 3.6: Build the symbol_filter_config dict in `portfolio_positions`**

In `src/net_alpha/web/routes/portfolio.py:178-196`, in the context dict for `_portfolio_table.html`, replace `selected_symbols` and `all_in_scope_symbols` with one structured config plus keep `selected_symbols` (still used by the count text below):

```python
        symbol_filter_config = {
            "selected": sorted(selected_symbols),
            "all": sorted({r.symbol for r in rows} | selected_symbols),
            "qsTemplate": (
                f"period={period or 'ytd'}&account={account or ''}"
                f"&group_options={group_options}"
                f"&symbols={'%2C'.join(sorted(selected_symbols))}"
            ),
            "show": show,
            "pageSize": page_size,
        }
        return request.app.state.templates.TemplateResponse(
            request,
            "_portfolio_table.html",
            {
                "rows": page_rows,
                "period_label": period_label,
                "show": show,
                "page": page,
                "total_pages": total_pages,
                "total_rows": total_rows,
                "page_size": page_size,
                "page_size_options": PAGE_SIZE_OPTIONS,
                "selected_symbols": sorted(selected_symbols),
                "symbol_filter_config": symbol_filter_config,
                "selected_period": period or "ytd",
                "selected_account": account or "",
                "group_options": group_options,
            },
        )
```

(`all_in_scope_symbols` no longer needs to be a separate context key — it's now nested inside `symbol_filter_config.all`.)

- [ ] **Step 3.7: Run the test to verify it passes**

```bash
uv run pytest tests/web/test_holdings_filter.py -v
```

Expected: all three PASS.

- [ ] **Step 3.8: Run the full web suite to catch regressions**

```bash
uv run pytest tests/web/ -v
```

Expected: PASS. (The test file `test_holdings_routes.py` that asserts on the position cell is sensitive to layout — should still pass since cell semantics are unchanged.)

- [ ] **Step 3.9: Commit**

```bash
git add src/net_alpha/web/static/holdings_filter.js \
        src/net_alpha/web/templates/base.html \
        src/net_alpha/web/templates/_portfolio_table.html \
        src/net_alpha/web/routes/portfolio.py \
        tests/web/test_holdings_filter.py
git commit -m "fix(web): extract holdings symbol filter to named Alpine component (item 4)

Inline 27-line x-data block was leaking its expression body as visible text
on the Holdings page when Alpine couldn't evaluate it. Move to a separate
JS file as a named Alpine.data('symbolFilter', ...) component, so the only
inline content is the call site. Also fixes the dropdown's mis-positioning
(secondary symptom of the same parse failure)."
```

---

## Phase 3 — Wash sales page merge (Item 2)

Combine Detail + Calendar into a single `/wash-sales` page with a `?view=table|calendar` toggle. Old paths 301-redirect.

### Task 4: New wash_sales route + template (table view)

**Files:**
- Create: `src/net_alpha/web/routes/wash_sales.py`
- Create: `src/net_alpha/web/templates/wash_sales.html`
- Test: `tests/web/test_wash_sales_route.py` (new)

- [ ] **Step 4.1: Write the failing test (table view + filters)**

```python
# tests/web/test_wash_sales_route.py
"""The merged Wash Sales page renders both views via ?view=table|calendar
and applies a unified filter bar."""

from datetime import date

from fastapi.testclient import TestClient


def test_wash_sales_default_renders_table_view(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5)),
    ])
    res = client.get("/wash-sales")
    assert res.status_code == 200
    assert "Wash sales" in res.text
    # Default view = table; the segmented control should mark Table active.
    assert "seg-active" in res.text
    # Table-only fragment marker (totals bar/table); calendar ribbon shouldn't show.
    assert "calendar-ribbon" not in res.text or 'view=calendar' in res.text


def test_wash_sales_view_calendar_renders_calendar(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5)),
    ])
    res = client.get("/wash-sales?view=calendar")
    assert res.status_code == 200
    # Calendar ribbon include marker — exact element will be the year-ribbon container.
    assert "calendar" in res.text.lower()


def test_wash_sales_filter_ticker_propagates(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5)),
    ])
    res = client.get("/wash-sales?ticker=AAPL")
    assert res.status_code == 200
    assert 'value="AAPL"' in res.text
```

- [ ] **Step 4.2: Run test to verify it fails**

```bash
uv run pytest tests/web/test_wash_sales_route.py -v
```

Expected: all three FAIL — `/wash-sales` returns 404.

- [ ] **Step 4.3: Create the route**

```python
# src/net_alpha/web/routes/wash_sales.py
"""Merged /wash-sales route — combines the old /detail (table) and /calendar
(year ribbon) views under a single URL with ?view=table|calendar toggle.

Filters (ticker, account, year, confidence) apply identically to both views.
"""

from __future__ import annotations

from datetime import date as _date

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from net_alpha.db.repository import Repository
from net_alpha.portfolio.detail_aggregations import (
    compute_detail_summary,
    group_violations_by_ticker,
    lag_days,
    source_label,
)
from net_alpha.web.dependencies import get_repository

router = APIRouter()

EXPAND_THRESHOLD = 5


def _day_of_year_pct(day: _date) -> float:
    start = _date(day.year, 1, 1)
    end = _date(day.year, 12, 31)
    total = (end - start).days
    return ((day - start).days / total) * 100 if total else 0


def _sort_key(sort: str | None):
    if sort == "lag":
        return lambda v: (lag_days(v) is None, lag_days(v) or 0)
    return lambda v: v.loss_sale_date or _date.min


@router.get("/wash-sales", response_class=HTMLResponse)
def wash_sales_page(
    request: Request,
    repo: Repository = Depends(get_repository),
    view: str = Query("table"),
    ticker: str | None = Query(None),
    account: str | None = Query(None),
    year: int | None = Query(None),
    confidence: str | None = Query(None),
    sort: str | None = Query(None),
    order: str | None = Query("desc"),
) -> HTMLResponse:
    if view not in ("table", "calendar"):
        view = "table"

    today = _date.today()
    all_v = repo.all_violations()

    violations = list(all_v)
    if ticker:
        violations = [v for v in violations if v.ticker == ticker.upper()]
    if account:
        violations = [v for v in violations if account in (v.loss_account, v.buy_account)]
    if year:
        violations = [v for v in violations if v.loss_sale_date and v.loss_sale_date.year == year]
    if confidence:
        violations = [v for v in violations if v.confidence.lower() == confidence.lower()]

    # Year list spans every year with trade or violation activity, plus the current year.
    year_set = {v.loss_sale_date.year for v in all_v if v.loss_sale_date}
    year_set.update(t.date.year for t in repo.all_trades())
    year_set.add(today.year)
    years = sorted(year_set, reverse=True)
    selected_year = year or today.year

    ctx: dict = {
        "view": view,
        "filter_ticker": ticker or "",
        "filter_account": account or "",
        "filter_year": year or "",
        "filter_confidence": confidence or "",
        "tickers": repo.list_distinct_tickers(),
        "accounts": [a.display() for a in repo.list_accounts()],
        "years": years,
        "selected_year": selected_year,
    }

    if view == "calendar":
        # Calendar additionally needs a per-year filter applied if no `year` was passed.
        cal_violations = (
            violations
            if year is not None
            else [v for v in violations if v.loss_sale_date and v.loss_sale_date.year == selected_year]
        )
        markers = [
            {
                "id": v.id,
                "ticker": v.ticker,
                "date": v.loss_sale_date,
                "left_pct": _day_of_year_pct(v.loss_sale_date),
                "confidence": v.confidence,
                "loss_account": v.loss_account or "-",
                "disallowed": v.disallowed_loss,
            }
            for v in cal_violations
        ]
        ctx.update({"markers": markers})
    else:
        # Table view: sort + group + summary.
        reverse = (order or "desc").lower() != "asc"
        key = _sort_key(sort)
        violations.sort(key=key, reverse=reverse)
        summary = compute_detail_summary(violations)
        groups = group_violations_by_ticker(violations)
        for g in groups:
            g.violations.sort(key=key, reverse=reverse)
        expand_default = len(groups) <= EXPAND_THRESHOLD
        ctx.update({
            "violations": violations,
            "summary": summary,
            "groups": groups,
            "expand_default": expand_default,
            "lag_days": lag_days,
            "source_label": source_label,
            "sort": sort or "",
            "order": order or "desc",
            "next_lag_order": "asc" if (sort == "lag" and (order or "desc") == "desc") else "desc",
        })

    return request.app.state.templates.TemplateResponse(request, "wash_sales.html", ctx)


# 301 redirects from old paths -- preserve query string by appending request.url.query.

@router.get("/detail")
def detail_redirect(request: Request) -> RedirectResponse:
    qs = request.url.query
    return RedirectResponse(url=f"/wash-sales?{qs}" if qs else "/wash-sales", status_code=301)


@router.get("/calendar")
def calendar_redirect(request: Request) -> RedirectResponse:
    qs = request.url.query
    target = f"/wash-sales?view=calendar&{qs}" if qs else "/wash-sales?view=calendar"
    return RedirectResponse(url=target, status_code=301)
```

- [ ] **Step 4.4: Create the template**

```jinja
{# src/net_alpha/web/templates/wash_sales.html #}
{% extends "base.html" %}
{% set active_page = 'wash_sales' %}
{% block title %}Wash sales · net-alpha{% endblock %}
{% block content %}
  <h1 class="text-2xl mb-4">Wash sales</h1>

  {# Unified filter bar — fields used by both views #}
  <form method="get" class="panel mb-4 flex gap-3 flex-wrap items-end">
    <input type="hidden" name="view" value="{{ view }}"/>
    <div>
      <label class="block label-uc">Ticker</label>
      <input type="text" name="ticker" value="{{ filter_ticker }}" list="ticker-list"
             class="bg-surface text-text rounded-md px-2 py-1 font-mono text-[13px] w-32"
             style="border:0.5px solid rgba(255,255,255,0.08);"/>
      <datalist id="ticker-list">
        {% for t in tickers %}<option value="{{ t }}">{% endfor %}
      </datalist>
    </div>
    <div>
      <label class="block label-uc">Account</label>
      <input type="text" name="account" value="{{ filter_account }}" list="account-list"
             class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-40"
             style="border:0.5px solid rgba(255,255,255,0.08);"/>
      <datalist id="account-list">
        {% for a in accounts %}<option value="{{ a }}">{{ a }}</option>{% endfor %}
      </datalist>
    </div>
    <div>
      <label class="block label-uc">Year</label>
      {% if view == 'calendar' %}
        <select name="year" class="bg-surface text-text rounded-md px-2 py-1 text-[13px] font-mono"
                style="border:0.5px solid rgba(255,255,255,0.08);">
          {% for y in years %}
            <option value="{{ y }}" {% if y == selected_year %}selected{% endif %}>{{ y }}</option>
          {% endfor %}
        </select>
      {% else %}
        <input type="number" name="year" value="{{ filter_year }}"
               class="bg-surface text-text rounded-md px-2 py-1 font-mono text-[13px] w-24"
               style="border:0.5px solid rgba(255,255,255,0.08);"/>
      {% endif %}
    </div>
    <div>
      <label class="block label-uc">Confidence</label>
      <select name="confidence" class="bg-surface text-text rounded-md px-2 py-1 text-[13px]"
              style="border:0.5px solid rgba(255,255,255,0.08);">
        <option value="">All</option>
        <option value="confirmed" {% if filter_confidence=='confirmed' %}selected{% endif %}>Confirmed</option>
        <option value="probable" {% if filter_confidence=='probable' %}selected{% endif %}>Probable</option>
        <option value="unclear" {% if filter_confidence=='unclear' %}selected{% endif %}>Unclear</option>
      </select>
    </div>
    {% if sort %}<input type="hidden" name="sort" value="{{ sort }}"/>{% endif %}
    {% if order %}<input type="hidden" name="order" value="{{ order }}"/>{% endif %}
    <button type="submit" class="btn">Apply</button>
    <a href="/wash-sales?view={{ view }}" class="btn-ghost">Reset</a>
  </form>

  {# View toggle — segmented control. Reset filters when toggling? No: preserve them. #}
  {% set qs_no_view %}ticker={{ filter_ticker }}&account={{ filter_account }}&year={{ filter_year }}&confidence={{ filter_confidence }}{% endset %}
  <div class="seg mb-4 inline-flex">
    <a href="/wash-sales?view=table&{{ qs_no_view }}"
       class="px-3 py-1.5 text-sm {% if view == 'table' %}seg-active{% endif %}">Table</a>
    <a href="/wash-sales?view=calendar&{{ qs_no_view }}"
       class="px-3 py-1.5 text-sm {% if view == 'calendar' %}seg-active{% endif %}">Calendar</a>
  </div>

  {% if view == 'calendar' %}
    {% include "_calendar_ribbon.html" %}
    <div id="focus-strip" class="mt-6"></div>
  {% else %}
    {% if summary and summary.violation_count > 0 %}
      <div class="panel mb-4 text-sm flex gap-4 items-baseline">
        <div><span class="font-medium">{{ summary.violation_count }}</span> violations</div>
        <div><span class="font-medium text-confirmed num">${{ "%.2f"|format(summary.disallowed_total|float) }}</span> disallowed</div>
        <div><span class="chip-confirm">{{ summary.confirmed_count }} confirmed</span></div>
        <div><span class="chip-probable">{{ summary.probable_count }} probable</span></div>
        <div><span class="chip-unclear">{{ summary.unclear_count }} unclear</span></div>
      </div>
    {% endif %}
    {% include "_detail_table.html" %}
  {% endif %}
{% endblock %}
```

- [ ] **Step 4.5: Wire the new router into the app and remove the old ones**

In `src/net_alpha/web/app.py:16-18`:

```python
from net_alpha.web.routes import holdings, sim, system, ticker, trades, wash_sales
from net_alpha.web.routes import imports as imports_routes
from net_alpha.web.routes import portfolio as portfolio_routes
```

(Remove `calendar, detail` from the import.)

In `src/net_alpha/web/app.py:50-58`, replace the existing `app.include_router(calendar.router)` and `app.include_router(detail.router)` lines with:

```python
    app.include_router(wash_sales.router)
```

Keep all other `include_router(...)` calls.

- [ ] **Step 4.6: Delete old route + template files**

```bash
rm src/net_alpha/web/routes/calendar.py
rm src/net_alpha/web/routes/detail.py
rm src/net_alpha/web/templates/calendar.html
rm src/net_alpha/web/templates/detail.html
```

(The fragments `_calendar_ribbon.html`, `_calendar_focus.html`, `_calendar_pl_ribbon.html`, `_detail_table.html` stay — they're included by `wash_sales.html`. The route at `/calendar/focus/{violation_id}` from `calendar.py` needs to move; see step 4.7.)

- [ ] **Step 4.7: Move the calendar focus route into wash_sales router**

The old `calendar.py` had a `/calendar/focus/{violation_id}` endpoint that returns the `_calendar_focus.html` fragment. Re-add it to `wash_sales.py` under the new path `/wash-sales/focus/{violation_id}`. The `_calendar_ribbon.html` template references this URL — search for `/calendar/focus` in the templates and update.

Append to `src/net_alpha/web/routes/wash_sales.py`:

```python
@router.get("/wash-sales/focus/{violation_id}", response_class=HTMLResponse)
def wash_sales_focus(
    violation_id: str,
    request: Request,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    from datetime import timedelta
    from fastapi import HTTPException

    target = next((v for v in repo.all_violations() if v.id == violation_id), None)
    if target is None or not target.loss_sale_date:
        raise HTTPException(status_code=404, detail=f"Violation {violation_id} not found")

    window_start = target.loss_sale_date - timedelta(days=30)
    window_end = target.loss_sale_date + timedelta(days=30)
    related_trades = [
        t for t in repo.get_trades_for_ticker(target.ticker)
        if window_start <= t.date <= window_end
    ]

    markers = []
    for t in related_trades:
        offset_days = (t.date - target.loss_sale_date).days
        left_pct = ((offset_days + 30) / 60) * 100
        is_loss_sale = t.date == target.loss_sale_date
        is_triggering = t.date == target.triggering_buy_date
        markers.append({
            "trade": t,
            "left_pct": left_pct,
            "is_loss_sale": is_loss_sale,
            "is_triggering": is_triggering,
            "offset_label": f"day {offset_days:+d}",
        })

    return request.app.state.templates.TemplateResponse(
        request,
        "_calendar_focus.html",
        {
            "violation": target,
            "markers": markers,
            "window_start": window_start,
            "window_end": window_end,
        },
    )
```

- [ ] **Step 4.8: Find and rewrite all internal references to /detail and /calendar**

```bash
grep -rn "/detail\|/calendar/focus\|/calendar\b" src/net_alpha/web/templates/ src/net_alpha/web/routes/
```

For each hit:
- Direct page links to `/detail` → `/wash-sales`
- Direct page links to `/calendar` → `/wash-sales?view=calendar`
- HTMX/JS links to `/calendar/focus/{id}` → `/wash-sales/focus/{id}`

Likely files to update: `_calendar_ribbon.html`, `_violation_card.html`, `_portfolio_kpis.html`. Update each in-place. Show no diff here — the change is mechanical and exact paths emerge from the grep.

- [ ] **Step 4.9: Update the top-nav in base.html**

In `src/net_alpha/web/templates/base.html:21-28`, replace the Detail and Calendar links:

```diff
       <nav class="flex gap-1">
         <a href="/" class="nav-link{% if active_page == 'portfolio' %} active{% endif %}">Portfolio</a>
         <a href="/holdings" class="nav-link{% if active_page == 'holdings' %} active{% endif %}">Holdings</a>
-        <a href="/calendar" class="nav-link{% if active_page == 'calendar' %} active{% endif %}">Calendar</a>
+        <a href="/wash-sales" class="nav-link{% if active_page == 'wash_sales' %} active{% endif %}">Wash sales</a>
         <a href="/imports" class="nav-link{% if active_page == 'imports' %} active{% endif %}">Imports</a>
         <a href="/sim" class="nav-link{% if active_page == 'sim' %} active{% endif %}">Sim</a>
-        <a href="/detail" class="nav-link{% if active_page == 'detail' %} active{% endif %}">Detail</a>
       </nav>
```

- [ ] **Step 4.10: Run tests**

```bash
uv run pytest tests/web/test_wash_sales_route.py -v
```

Expected: all three PASS.

- [ ] **Step 4.11: Add redirect tests**

```python
# Append to tests/web/test_wash_sales_route.py

def test_detail_redirects_to_wash_sales(client: TestClient):
    res = client.get("/detail", follow_redirects=False)
    assert res.status_code == 301
    assert res.headers["location"] == "/wash-sales"


def test_detail_redirect_preserves_query_string(client: TestClient):
    res = client.get("/detail?ticker=AAPL", follow_redirects=False)
    assert res.status_code == 301
    assert res.headers["location"] == "/wash-sales?ticker=AAPL"


def test_calendar_redirects_to_wash_sales_calendar_view(client: TestClient):
    res = client.get("/calendar", follow_redirects=False)
    assert res.status_code == 301
    assert res.headers["location"] == "/wash-sales?view=calendar"


def test_calendar_redirect_preserves_query_string(client: TestClient):
    res = client.get("/calendar?ticker=AAPL", follow_redirects=False)
    assert res.status_code == 301
    assert res.headers["location"] == "/wash-sales?view=calendar&ticker=AAPL"
```

- [ ] **Step 4.12: Run all tests; fix any references in test files**

```bash
uv run pytest tests/web/ -v
```

The old test files (`test_detail_routes.py`, `test_calendar.py`, `test_detail_enhancements.py`) hit `/detail` and `/calendar` directly. Either:
- (a) Update each one's URL to `/wash-sales` (or `/wash-sales?view=calendar`).
- (b) Delete the old files if they're now fully replaced by `test_wash_sales_route.py`.

Pick (a) — preserve coverage. Edit each test to use the new URL. Don't delete unless duplicate.

Run again:

```bash
uv run pytest tests/web/ -v
```

Expected: PASS.

- [ ] **Step 4.13: Commit**

```bash
git add -A
git commit -m "feat(web): merge Detail+Calendar into /wash-sales (item 2)

New route /wash-sales with ?view=table|calendar toggle and a unified
filter bar (ticker, account, year, confidence). Old paths 301-redirect
preserving query string. Top-nav 'Detail' becomes 'Wash sales';
'Calendar' link removed."
```

---

## Phase 4 — Stock-split handling (Item 5)

The largest piece. Subdivided into:
- 4a: schema migration (splits + lot_overrides tables)
- 4b: Yahoo split fetcher
- 4c: apply_splits + apply_lot_overrides + recompute integration
- 4d: /splits/sync endpoint + toolbar button
- 4e: auto-sync on first import of a symbol
- 4f: manual lot edit UI on /ticker/{sym}

### Task 5: Schema migration v6→v7 (splits + lot_overrides tables)

**Files:**
- Modify: `src/net_alpha/db/tables.py`
- Modify: `src/net_alpha/db/migrations.py`
- Test: `tests/db/test_v6_to_v7_migration.py` (new)

- [ ] **Step 5.1: Write the failing test**

```python
# tests/db/test_v6_to_v7_migration.py
"""v6 → v7: adds splits + lot_overrides tables."""

import pytest
from sqlalchemy import text
from sqlmodel import Session

from net_alpha.db.connection import get_engine
from net_alpha.db.migrations import migrate, set_schema_version


def test_v7_creates_splits_table(tmp_path):
    db_path = tmp_path / "v6.db"
    eng = get_engine(db_path)
    # Bootstrap empty DB at v6 (no schema present yet — set_schema_version expects meta to exist).
    with Session(eng) as s:
        s.exec(text("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)"))
        s.commit()
        set_schema_version(s, 6)

    with Session(eng) as s:
        migrate(s)

    with Session(eng) as s:
        row = s.exec(text("SELECT name FROM sqlite_master WHERE type='table' AND name='splits'")).first()
        assert row is not None, "splits table not created"
        cols = {r[1] for r in s.exec(text("PRAGMA table_info(splits)")).all()}
        assert {"symbol", "split_date", "ratio", "source", "fetched_at"} <= cols


def test_v7_creates_lot_overrides_table(tmp_path):
    db_path = tmp_path / "v6.db"
    eng = get_engine(db_path)
    with Session(eng) as s:
        s.exec(text("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)"))
        s.commit()
        set_schema_version(s, 6)

    with Session(eng) as s:
        migrate(s)

    with Session(eng) as s:
        row = s.exec(text("SELECT name FROM sqlite_master WHERE type='table' AND name='lot_overrides'")).first()
        assert row is not None
        cols = {r[1] for r in s.exec(text("PRAGMA table_info(lot_overrides)")).all()}
        assert {"trade_id", "field", "old_value", "new_value", "reason", "edited_at"} <= cols


def test_v7_splits_unique_symbol_split_date(tmp_path):
    db_path = tmp_path / "v6.db"
    eng = get_engine(db_path)
    with Session(eng) as s:
        s.exec(text("CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT)"))
        s.commit()
        set_schema_version(s, 6)
    with Session(eng) as s:
        migrate(s)

    with Session(eng) as s:
        s.exec(text(
            "INSERT INTO splits (symbol, split_date, ratio, source, fetched_at) "
            "VALUES ('AAPL', '2020-08-31', 4.0, 'yahoo', '2026-04-26T00:00:00Z')"
        ))
        s.commit()
        with pytest.raises(Exception):  # IntegrityError on duplicate key
            s.exec(text(
                "INSERT INTO splits (symbol, split_date, ratio, source, fetched_at) "
                "VALUES ('AAPL', '2020-08-31', 5.0, 'yahoo', '2026-04-26T00:00:00Z')"
            ))
            s.commit()
```

- [ ] **Step 5.2: Run test to verify it fails**

```bash
uv run pytest tests/db/test_v6_to_v7_migration.py -v
```

Expected: all FAIL — table doesn't exist.

- [ ] **Step 5.3: Add SQLModel rows for the new tables**

Append to `src/net_alpha/db/tables.py`:

```python
class SplitRow(SQLModel, table=True):
    __tablename__ = "splits"
    __table_args__ = (UniqueConstraint("symbol", "split_date", name="uq_splits_symbol_date"),)

    id: int | None = Field(default=None, primary_key=True)
    symbol: str = Field(index=True)
    split_date: str  # YYYY-MM-DD ex-date
    ratio: float    # new shares ÷ old shares; 2.0 = 2-for-1; 0.1 = 1-for-10 reverse
    source: str     # 'yahoo' | 'manual'
    fetched_at: str # ISO 8601 UTC timestamp


class LotOverrideRow(SQLModel, table=True):
    __tablename__ = "lot_overrides"

    id: int | None = Field(default=None, primary_key=True)
    trade_id: int = Field(foreign_key="trades.id", index=True)
    field: str          # 'quantity' | 'adjusted_basis'
    old_value: float
    new_value: float
    reason: str         # 'split' | 'manual' | 'transfer_basis_fix'
    edited_at: str      # ISO 8601 UTC timestamp
    split_id: int | None = Field(default=None, foreign_key="splits.id", index=True)
    # split_id is set when reason='split'; lets apply_split check idempotency.
```

- [ ] **Step 5.4: Add the v6→v7 migration**

In `src/net_alpha/db/migrations.py`:

Bump `CURRENT_SCHEMA_VERSION` from `6` to `7`. Update the docstring's schema-versions list:

```python
CURRENT_SCHEMA_VERSION = 7
```

```python
"""...
  v7 — Adds splits and lot_overrides tables for stock-split handling and
       manual lot edits.
"""
```

Add the new migration function before `def migrate`:

```python
def _migrate_v6_to_v7(session: Session) -> None:
    if not _table_exists(session, "splits"):
        session.exec(text(
            "CREATE TABLE splits ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "symbol TEXT NOT NULL, "
            "split_date TEXT NOT NULL, "
            "ratio REAL NOT NULL, "
            "source TEXT NOT NULL, "
            "fetched_at TEXT NOT NULL, "
            "CONSTRAINT uq_splits_symbol_date UNIQUE (symbol, split_date))"
        ))
        session.exec(text("CREATE INDEX ix_splits_symbol ON splits(symbol)"))
    if not _table_exists(session, "lot_overrides"):
        session.exec(text(
            "CREATE TABLE lot_overrides ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "trade_id INTEGER NOT NULL REFERENCES trades(id), "
            "field TEXT NOT NULL, "
            "old_value REAL NOT NULL, "
            "new_value REAL NOT NULL, "
            "reason TEXT NOT NULL, "
            "edited_at TEXT NOT NULL, "
            "split_id INTEGER NULL REFERENCES splits(id))"
        ))
        session.exec(text("CREATE INDEX ix_lot_overrides_trade_id ON lot_overrides(trade_id)"))
        session.exec(text("CREATE INDEX ix_lot_overrides_split_id ON lot_overrides(split_id)"))
    session.commit()
```

In `def migrate`, add the v6→v7 step (and update the existing v5→v6 chain so it doesn't `return` early):

```python
    if current < 6:
        _migrate_v5_to_v6(session)
        set_schema_version(session, 6)
        current = 6
    if current < 7:
        _migrate_v6_to_v7(session)
        set_schema_version(session, 7)
        return
```

- [ ] **Step 5.5: Run test to verify it passes**

```bash
uv run pytest tests/db/test_v6_to_v7_migration.py -v
```

Expected: PASS.

- [ ] **Step 5.6: Run full DB test suite to catch regression on prior migrations**

```bash
uv run pytest tests/db/ -v
```

Expected: PASS.

- [ ] **Step 5.7: Commit**

```bash
git add src/net_alpha/db/tables.py src/net_alpha/db/migrations.py tests/db/test_v6_to_v7_migration.py
git commit -m "feat(db): schema v7 — splits + lot_overrides tables (item 5)

splits: keyed (symbol, split_date) UNIQUE, holds ratio + source + fetched_at.
lot_overrides: audit trail of qty/basis changes, keyed by trade_id (stable
across recompute since lots are regenerated). split_id FK lets apply_split
check idempotency."
```

### Task 6: Repository methods for splits + lot_overrides

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_splits.py` (new)

- [ ] **Step 6.1: Write the failing test**

```python
# tests/db/test_repository_splits.py
"""Repository CRUD for splits + lot_overrides."""

from datetime import date

from net_alpha.models.splits import Split


def test_add_and_list_splits(repo):
    sp_id = repo.add_split(
        symbol="AAPL",
        split_date=date(2020, 8, 31),
        ratio=4.0,
        source="yahoo",
    )
    assert sp_id > 0

    rows = repo.get_splits("AAPL")
    assert len(rows) == 1
    assert rows[0].symbol == "AAPL"
    assert rows[0].ratio == 4.0
    assert rows[0].source == "yahoo"


def test_add_split_idempotent_on_duplicate_key(repo):
    repo.add_split("AAPL", date(2020, 8, 31), 4.0, "yahoo")
    # Same (symbol, date) but different ratio: existing row wins, no exception.
    sp_id = repo.add_split("AAPL", date(2020, 8, 31), 5.0, "yahoo")
    assert sp_id is not None
    rows = repo.get_splits("AAPL")
    assert len(rows) == 1
    assert rows[0].ratio == 4.0  # unchanged


def test_get_splits_for_unknown_symbol_returns_empty(repo):
    assert repo.get_splits("NVDA") == []


def test_add_and_list_lot_overrides(repo, builders):
    a, _ = builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5)),
    ])
    trade = repo.get_trades_for_ticker("AAPL")[0]

    repo.add_lot_override(
        trade_id=int(trade.id),
        field="quantity",
        old_value=10.0,
        new_value=1.0,
        reason="split",
        split_id=None,
    )
    overrides = repo.get_lot_overrides_for_trade(int(trade.id))
    assert len(overrides) == 1
    assert overrides[0].field == "quantity"
    assert overrides[0].old_value == 10.0
    assert overrides[0].new_value == 1.0
```

(Note: `Split` is a Pydantic domain model — defined in step 6.2.)

- [ ] **Step 6.2: Define the Split + LotOverride domain models**

Create `src/net_alpha/models/splits.py`:

```python
"""Domain models for stock splits and lot overrides."""

from __future__ import annotations

from datetime import date as _date
from datetime import datetime

from pydantic import BaseModel


class Split(BaseModel):
    id: int
    symbol: str
    split_date: _date
    ratio: float
    source: str  # 'yahoo' | 'manual'
    fetched_at: datetime


class LotOverride(BaseModel):
    id: int
    trade_id: int
    field: str  # 'quantity' | 'adjusted_basis'
    old_value: float
    new_value: float
    reason: str  # 'split' | 'manual' | 'transfer_basis_fix'
    edited_at: datetime
    split_id: int | None = None
```

- [ ] **Step 6.3: Add Repository methods**

Append to `src/net_alpha/db/repository.py` (after the existing methods, in a logical section near the bottom but before any `from net_alpha.engine.recompute import` imports):

```python
    # --- Splits ---

    def add_split(
        self,
        symbol: str,
        split_date: date,
        ratio: float,
        source: str,
    ) -> int | None:
        """Insert a split. Returns the new id, or the existing id if (symbol, split_date)
        already exists (no-op for re-fetch). Returns None only on unexpected failure."""
        from datetime import datetime as _dt
        from datetime import UTC
        from net_alpha.db.tables import SplitRow

        with Session(self.engine) as s:
            existing = s.exec(
                select(SplitRow).where(
                    SplitRow.symbol == symbol,
                    SplitRow.split_date == split_date.isoformat(),
                )
            ).first()
            if existing is not None:
                return existing.id
            row = SplitRow(
                symbol=symbol,
                split_date=split_date.isoformat(),
                ratio=ratio,
                source=source,
                fetched_at=_dt.now(UTC).isoformat(),
            )
            s.add(row)
            s.commit()
            s.refresh(row)
            return row.id

    def get_splits(self, symbol: str | None = None) -> list:
        """Return all splits (optionally filtered by symbol), oldest first."""
        from datetime import datetime as _dt

        from net_alpha.db.tables import SplitRow
        from net_alpha.models.splits import Split as SplitDomain

        with Session(self.engine) as s:
            stmt = select(SplitRow)
            if symbol is not None:
                stmt = stmt.where(SplitRow.symbol == symbol)
            stmt = stmt.order_by(SplitRow.split_date)
            rows = s.exec(stmt).all()
            return [
                SplitDomain(
                    id=r.id,
                    symbol=r.symbol,
                    split_date=date.fromisoformat(r.split_date),
                    ratio=r.ratio,
                    source=r.source,
                    fetched_at=_dt.fromisoformat(r.fetched_at),
                )
                for r in rows
            ]

    # --- Lot overrides ---

    def add_lot_override(
        self,
        trade_id: int,
        field: str,
        old_value: float,
        new_value: float,
        reason: str,
        split_id: int | None = None,
    ) -> int:
        from datetime import datetime as _dt
        from datetime import UTC
        from net_alpha.db.tables import LotOverrideRow

        with Session(self.engine) as s:
            row = LotOverrideRow(
                trade_id=trade_id,
                field=field,
                old_value=old_value,
                new_value=new_value,
                reason=reason,
                split_id=split_id,
                edited_at=_dt.now(UTC).isoformat(),
            )
            s.add(row)
            s.commit()
            s.refresh(row)
            return row.id

    def get_lot_overrides_for_trade(self, trade_id: int) -> list:
        from datetime import datetime as _dt

        from net_alpha.db.tables import LotOverrideRow
        from net_alpha.models.splits import LotOverride

        with Session(self.engine) as s:
            rows = s.exec(
                select(LotOverrideRow)
                .where(LotOverrideRow.trade_id == trade_id)
                .order_by(LotOverrideRow.edited_at)
            ).all()
            return [
                LotOverride(
                    id=r.id,
                    trade_id=r.trade_id,
                    field=r.field,
                    old_value=r.old_value,
                    new_value=r.new_value,
                    reason=r.reason,
                    edited_at=_dt.fromisoformat(r.edited_at),
                    split_id=r.split_id,
                )
                for r in rows
            ]

    def all_lot_overrides(self) -> list:
        """All overrides across all trades, used by the post-recompute applier."""
        from datetime import datetime as _dt

        from net_alpha.db.tables import LotOverrideRow
        from net_alpha.models.splits import LotOverride

        with Session(self.engine) as s:
            rows = s.exec(select(LotOverrideRow).order_by(LotOverrideRow.edited_at)).all()
            return [
                LotOverride(
                    id=r.id,
                    trade_id=r.trade_id,
                    field=r.field,
                    old_value=r.old_value,
                    new_value=r.new_value,
                    reason=r.reason,
                    edited_at=_dt.fromisoformat(r.edited_at),
                    split_id=r.split_id,
                )
                for r in rows
            ]

    def get_split_overrides_for_trade(self, trade_id: int, split_id: int) -> list:
        """Used by apply_split to check idempotency: 'have I already applied this split to this trade?'"""
        from net_alpha.db.tables import LotOverrideRow

        with Session(self.engine) as s:
            rows = s.exec(
                select(LotOverrideRow).where(
                    LotOverrideRow.trade_id == trade_id,
                    LotOverrideRow.split_id == split_id,
                )
            ).all()
            return list(rows)
```

- [ ] **Step 6.4: Run test to verify it passes**

```bash
uv run pytest tests/db/test_repository_splits.py -v
```

Expected: PASS.

- [ ] **Step 6.5: Commit**

```bash
git add src/net_alpha/db/repository.py src/net_alpha/models/splits.py tests/db/test_repository_splits.py
git commit -m "feat(db): repository methods for splits + lot_overrides (item 5)

add_split is idempotent on (symbol, split_date). lot_overrides keyed by
trade_id since lots are regenerated on every recompute."
```

### Task 7: YahooPriceProvider — fetch_splits

**Files:**
- Modify: `src/net_alpha/pricing/provider.py`
- Modify: `src/net_alpha/pricing/yahoo.py`
- Test: `tests/pricing/test_yahoo_splits.py` (new)

- [ ] **Step 7.1: Write the failing test**

```python
# tests/pricing/test_yahoo_splits.py
"""YahooPriceProvider.fetch_splits parses yfinance.Ticker.splits."""

from datetime import date
from unittest.mock import patch

import pandas as pd

from net_alpha.pricing.yahoo import YahooPriceProvider


class _FakeTicker:
    def __init__(self, splits_series: pd.Series) -> None:
        self.splits = splits_series


def test_fetch_splits_returns_split_events_in_date_order():
    provider = YahooPriceProvider()
    series = pd.Series(
        [4.0, 7.0],
        index=pd.to_datetime(["2020-08-31", "2014-06-09"]),
    )
    fake = _FakeTicker(series)
    with patch("net_alpha.pricing.yahoo.yf.Ticker", return_value=fake):
        events = provider.fetch_splits("AAPL")

    assert len(events) == 2
    assert events[0].split_date == date(2014, 6, 9)
    assert events[0].ratio == 7.0
    assert events[1].split_date == date(2020, 8, 31)
    assert events[1].ratio == 4.0


def test_fetch_splits_empty_when_no_splits():
    provider = YahooPriceProvider()
    fake = _FakeTicker(pd.Series([], dtype=float))
    with patch("net_alpha.pricing.yahoo.yf.Ticker", return_value=fake):
        events = provider.fetch_splits("AAPL")
    assert events == []


def test_fetch_splits_swallows_per_symbol_error():
    """Network/parse error for one symbol returns []; doesn't raise."""
    provider = YahooPriceProvider()
    with patch("net_alpha.pricing.yahoo.yf.Ticker", side_effect=RuntimeError("boom")):
        events = provider.fetch_splits("BAD")
    assert events == []
```

- [ ] **Step 7.2: Run test to verify it fails**

```bash
uv run pytest tests/pricing/test_yahoo_splits.py -v
```

Expected: FAIL — `fetch_splits` doesn't exist.

- [ ] **Step 7.3: Define SplitEvent in provider.py**

Append to `src/net_alpha/pricing/provider.py`:

```python
from datetime import date as _date


class SplitEvent(BaseModel):
    """A single stock-split event for a symbol. Yahoo convention:
    ratio = new shares ÷ old shares (so 0.1 = 1-for-10 reverse, 4.0 = 4-for-1 forward)."""
    model_config = {"frozen": True}
    symbol: str
    split_date: _date
    ratio: float
```

Also extend `PriceProvider` ABC with the new method:

```python
class PriceProvider(ABC):
    @abstractmethod
    def get_quotes(self, symbols: list[str]) -> dict[str, Quote]:
        ...

    def fetch_splits(self, symbol: str) -> list[SplitEvent]:
        """Optional: providers without split data return [] (default)."""
        return []
```

(Default implementation `return []` — providers that don't support splits are unaffected.)

- [ ] **Step 7.4: Implement fetch_splits in YahooPriceProvider**

In `src/net_alpha/pricing/yahoo.py`, add:

```python
from datetime import date as _date

from net_alpha.pricing.provider import PriceFetchError, PriceProvider, Quote, SplitEvent


class YahooPriceProvider(PriceProvider):
    source_name = "yahoo"

    def get_quotes(self, symbols: list[str]) -> dict[str, Quote]:
        # ...existing code unchanged...

    def fetch_splits(self, symbol: str) -> list[SplitEvent]:
        """Fetch all known splits for a symbol from yfinance. Returns [] on any error."""
        try:
            ticker = yf.Ticker(symbol)
            series = ticker.splits  # pandas Series indexed by datetime
        except Exception as exc:
            logger.warning("yahoo: split fetch error for {}: {}", symbol, exc)
            return []
        events: list[SplitEvent] = []
        try:
            for ts, ratio in series.items():
                d = ts.date() if hasattr(ts, "date") else _date.fromisoformat(str(ts)[:10])
                events.append(SplitEvent(symbol=symbol, split_date=d, ratio=float(ratio)))
        except Exception as exc:
            logger.warning("yahoo: split parse error for {}: {}", symbol, exc)
            return []
        events.sort(key=lambda e: e.split_date)
        return events
```

- [ ] **Step 7.5: Run test to verify it passes**

```bash
uv run pytest tests/pricing/test_yahoo_splits.py -v
```

Expected: PASS.

- [ ] **Step 7.6: Commit**

```bash
git add src/net_alpha/pricing/provider.py src/net_alpha/pricing/yahoo.py tests/pricing/test_yahoo_splits.py
git commit -m "feat(pricing): YahooPriceProvider.fetch_splits (item 5)

Wraps yfinance.Ticker.splits with the same error-swallowing pattern as
get_quotes (per-symbol failures return empty list, never raise). Default
on the ABC is to return [] so providers without split data are unaffected."
```

### Task 8: apply_splits + apply_lot_overrides (post-recompute mutation)

**Files:**
- Create: `src/net_alpha/splits/__init__.py`
- Create: `src/net_alpha/splits/apply.py`
- Modify: `src/net_alpha/db/repository.py` (add helpers used by apply_splits)
- Modify: `src/net_alpha/engine/recompute.py` (call apply step at end)
- Test: `tests/splits/__init__.py` (new, empty)
- Test: `tests/splits/test_apply.py` (new)

- [ ] **Step 8.1: Write the failing test**

```python
# tests/splits/test_apply.py
"""apply_splits is the post-recompute step that mutates regenerated lots
to reflect known stock splits. It's idempotent (lot_overrides serves as
the de-dup key) and a no-op on lots dated >= the split's ex-date."""

from datetime import date

from net_alpha.splits.apply import apply_splits


def test_forward_2_for_1_doubles_qty_preserves_basis(repo, builders):
    """A 2-for-1 split on a 10-share, $1500 lot bought before the ex-date should
    yield 20 shares with $1500 unchanged total adjusted_basis."""
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2020, 8, 1), qty=10, cost=1500),
    ])
    repo.add_split("AAPL", date(2020, 8, 31), 2.0, "yahoo")

    # Trigger initial wash-sale recompute so lots exist.
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    apply_splits(repo)

    lots = repo.get_lots_for_ticker("AAPL")
    assert len(lots) == 1
    assert lots[0].quantity == 20.0
    assert lots[0].adjusted_basis == 1500.0


def test_reverse_1_for_10_shrinks_qty(repo, builders):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "SQQQ", date(2024, 1, 5), qty=100, cost=2000),
    ])
    repo.add_split("SQQQ", date(2025, 1, 13), 0.1, "yahoo")

    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    apply_splits(repo)

    lots = repo.get_lots_for_ticker("SQQQ")
    assert len(lots) == 1
    assert lots[0].quantity == 10.0
    assert lots[0].adjusted_basis == 2000.0


def test_lot_dated_after_split_is_untouched(repo, builders):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2021, 1, 5), qty=10, cost=1500),
    ])
    repo.add_split("AAPL", date(2020, 8, 31), 2.0, "yahoo")  # ex-date BEFORE the buy

    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    apply_splits(repo)

    lots = repo.get_lots_for_ticker("AAPL")
    assert len(lots) == 1
    assert lots[0].quantity == 10.0  # unchanged


def test_other_symbol_lots_untouched(repo, builders):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2020, 1, 1), qty=10, cost=1500),
        builders.make_buy("schwab/lt", "NVDA", date(2020, 1, 1), qty=10, cost=2000),
    ])
    repo.add_split("AAPL", date(2020, 8, 31), 2.0, "yahoo")

    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    apply_splits(repo)

    nvda_lots = repo.get_lots_for_ticker("NVDA")
    assert nvda_lots[0].quantity == 10.0


def test_apply_splits_is_idempotent(repo, builders):
    """Calling apply_splits twice produces the same result. lot_overrides is
    written exactly once per (split, trade) pair."""
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2020, 1, 1), qty=10, cost=1500),
    ])
    repo.add_split("AAPL", date(2020, 8, 31), 2.0, "yahoo")

    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    apply_splits(repo)
    apply_splits(repo)  # second call should be a no-op

    lots = repo.get_lots_for_ticker("AAPL")
    assert lots[0].quantity == 20.0  # not 40
    trade_id = int(repo.get_trades_for_ticker("AAPL")[0].id)
    overrides = repo.get_lot_overrides_for_trade(trade_id)
    # Exactly one quantity override row written for the split.
    qty_overrides = [o for o in overrides if o.field == "quantity" and o.reason == "split"]
    assert len(qty_overrides) == 1
```

- [ ] **Step 8.2: Run test to verify it fails**

```bash
uv run pytest tests/splits/test_apply.py -v
```

Expected: all FAIL — module doesn't exist.

- [ ] **Step 8.3: Add helper Repository methods**

In `src/net_alpha/db/repository.py`, add inside the Repository class:

```python
    def get_lot_rows_for_symbol(self, symbol: str) -> list:
        """Return raw LotRow records (NOT domain Lot) so the splits applier
        can mutate them by id. Open-only is the default since closed lots are
        irrelevant to the user's current holdings; for split application we
        also want closed lots so historical wash-sale data stays correct."""
        from net_alpha.db.tables import LotRow
        with Session(self.engine) as s:
            rows = s.exec(select(LotRow).where(LotRow.ticker == symbol)).all()
            # Detach from session by copying to dicts; caller will mutate via update_lot_qty_and_basis.
            return [
                {
                    "id": r.id,
                    "trade_id": r.trade_id,
                    "ticker": r.ticker,
                    "trade_date": r.trade_date,
                    "quantity": r.quantity,
                    "adjusted_basis": r.adjusted_basis,
                    "cost_basis": r.cost_basis,
                }
                for r in rows
            ]

    def update_lot_qty_and_basis(self, lot_id: int, *, quantity: float, adjusted_basis: float) -> None:
        from net_alpha.db.tables import LotRow
        with Session(self.engine) as s:
            row = s.get(LotRow, lot_id)
            if row is None:
                return
            row.quantity = quantity
            row.adjusted_basis = adjusted_basis
            s.add(row)
            s.commit()
```

- [ ] **Step 8.4: Implement apply_splits**

```python
# src/net_alpha/splits/__init__.py
"""Stock-split application — mutate regenerated lots based on the splits
table and record an audit trail in lot_overrides.

Intended call site: as the final step of recompute_all_violations, after
detect_in_window has produced fresh lots and they've been persisted via
replace_lots_in_window. Idempotent — safe to call repeatedly.
"""
```

```python
# src/net_alpha/splits/apply.py
from __future__ import annotations

from datetime import date

from net_alpha.db.repository import Repository


def apply_splits(repo: Repository) -> int:
    """Mutate every persisted lot whose date < a known split's ex-date by
    multiplying quantity by the split ratio. adjusted_basis is preserved
    (basis is dollars, not per-share). Writes a lot_overrides row per
    mutation, keyed by (trade_id, split_id), for idempotency.

    Returns the count of lot mutations applied (0 on a steady state).
    """
    splits = repo.get_splits()  # all symbols
    if not splits:
        return 0

    mutations = 0
    for split in splits:
        lots = repo.get_lot_rows_for_symbol(split.symbol)
        for lot in lots:
            lot_date = date.fromisoformat(lot["trade_date"])
            if lot_date >= split.split_date:
                continue  # lot is already post-split
            existing = repo.get_split_overrides_for_trade(int(lot["trade_id"]), int(split.id))
            if existing:
                continue  # already applied
            old_qty = float(lot["quantity"])
            new_qty = old_qty * split.ratio
            old_basis = float(lot["adjusted_basis"])
            # Mutate the lot row.
            repo.update_lot_qty_and_basis(
                int(lot["id"]),
                quantity=new_qty,
                adjusted_basis=old_basis,  # unchanged
            )
            # Audit row.
            repo.add_lot_override(
                trade_id=int(lot["trade_id"]),
                field="quantity",
                old_value=old_qty,
                new_value=new_qty,
                reason="split",
                split_id=int(split.id),
            )
            mutations += 1
    return mutations
```

- [ ] **Step 8.5: Wire apply_splits into recompute_all_violations**

In `src/net_alpha/engine/recompute.py`:

```python
from __future__ import annotations

from datetime import timedelta

from net_alpha.db.repository import Repository
from net_alpha.engine.detector import detect_in_window
from net_alpha.engine.merge import merge_violations
from net_alpha.splits.apply import apply_splits


def recompute_all_violations(repo: Repository, etf_pairs: dict[str, list[str]]) -> None:
    all_trades = repo.all_trades()
    accounts = repo.list_accounts()
    gl_by_account = {a.id: repo.get_gl_lots_for_account(a.id) for a in accounts}

    all_dates: list = [t.date for t in all_trades]
    for lots in gl_by_account.values():
        all_dates.extend(lot.closed_date for lot in lots)

    if not all_dates:
        return

    win_start = min(all_dates) - timedelta(days=30)
    win_end = max(all_dates) + timedelta(days=30)

    det = detect_in_window(
        repo.trades_in_window(win_start, win_end),
        win_start,
        win_end,
        etf_pairs=etf_pairs,
    )
    merged = merge_violations(
        engine_violations=det.violations,
        gl_lots_by_account=gl_by_account,
    )
    repo.replace_violations_in_window(win_start, win_end, merged)
    repo.replace_lots_in_window(win_start, win_end, det.lots)

    # Re-apply known splits to the freshly-regenerated lots. Idempotent.
    apply_splits(repo)
    # Manual overrides take precedence over splits (latest-wins).
    # apply_manual_overrides is added in Task 11; the import below works
    # even before Task 11 because the function exists by then.
    # Until Task 11 is done, only apply_splits runs.
```

- [ ] **Step 8.6: Run tests**

```bash
uv run pytest tests/splits/test_apply.py -v
```

Expected: all PASS.

- [ ] **Step 8.7: Run wider engine tests to catch regressions**

```bash
uv run pytest tests/engine/ tests/integration/ -v
```

Expected: PASS. The only behavior change in `recompute_all_violations` is the trailing `apply_splits` call, which is a no-op when the splits table is empty.

- [ ] **Step 8.8: Commit**

```bash
git add src/net_alpha/splits/__init__.py src/net_alpha/splits/apply.py \
        src/net_alpha/db/repository.py src/net_alpha/engine/recompute.py \
        tests/splits/__init__.py tests/splits/test_apply.py
git commit -m "feat(engine): apply_splits as final step of recompute (item 5)

apply_splits mutates regenerated lots whose date is before each known
split's ex-date. Multiplies qty by ratio, preserves total basis (basis is
dollar, not per-share). Idempotent via (trade_id, split_id) check in
lot_overrides. Wired into recompute_all_violations so re-imports and
unimports keep the split-adjustment intact."
```

### Task 9: PricingService.sync_splits + /splits/sync endpoint + toolbar button

**Files:**
- Modify: `src/net_alpha/pricing/service.py`
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Modify: `src/net_alpha/web/templates/_portfolio_toolbar.html`
- Modify: `src/net_alpha/web/dependencies.py` (if needed for repo dep on the new endpoint)
- Test: `tests/pricing/test_split_sync.py` (new)
- Test: `tests/web/test_split_sync_route.py` (new)

- [ ] **Step 9.1: Write the failing test for service**

```python
# tests/pricing/test_split_sync.py
"""PricingService.sync_splits orchestrates fetch + persist + apply."""

from dataclasses import dataclass
from datetime import date

from net_alpha.pricing.provider import SplitEvent
from net_alpha.pricing.service import PricingService


@dataclass
class _StubProvider:
    events_by_symbol: dict[str, list[SplitEvent]]

    def get_quotes(self, symbols):
        return {}

    def fetch_splits(self, symbol):
        return self.events_by_symbol.get(symbol, [])


def test_sync_splits_inserts_new_splits_and_applies_them(repo, builders, tmp_path):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2020, 1, 5), qty=10, cost=1500),
    ])
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    provider = _StubProvider({"AAPL": [SplitEvent(symbol="AAPL", split_date=date(2020, 8, 31), ratio=2.0)]})
    from net_alpha.pricing.cache import PriceCache
    cache = PriceCache(repo.engine, ttl_seconds=300)
    svc = PricingService(provider=provider, cache=cache, enabled=True)

    result = svc.sync_splits(["AAPL"], repo=repo)

    assert result.applied_count == 1
    assert result.skipped_count == 0
    assert result.error_symbols == []

    lots = repo.get_lots_for_ticker("AAPL")
    assert lots[0].quantity == 20.0


def test_sync_splits_returns_skipped_for_already_known(repo, builders):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2020, 1, 5), qty=10, cost=1500),
    ])
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())
    repo.add_split("AAPL", date(2020, 8, 31), 2.0, "yahoo")  # pre-existing

    provider = _StubProvider({"AAPL": [SplitEvent(symbol="AAPL", split_date=date(2020, 8, 31), ratio=2.0)]})
    from net_alpha.pricing.cache import PriceCache
    cache = PriceCache(repo.engine, ttl_seconds=300)
    svc = PricingService(provider=provider, cache=cache, enabled=True)

    result = svc.sync_splits(["AAPL"], repo=repo)
    assert result.skipped_count == 1


def test_sync_splits_disabled_returns_immediately(repo):
    from net_alpha.pricing.cache import PriceCache
    cache = PriceCache(repo.engine, ttl_seconds=300)
    svc = PricingService(
        provider=_StubProvider({"AAPL": [SplitEvent(symbol="AAPL", split_date=date(2020, 8, 31), ratio=2.0)]}),
        cache=cache,
        enabled=False,
    )

    result = svc.sync_splits(["AAPL"], repo=repo)

    assert result.applied_count == 0
    assert result.skipped_count == 0
    assert "AAPL" in result.error_symbols  # treated as unable-to-fetch
```

- [ ] **Step 9.2: Run test — expect failure**

```bash
uv run pytest tests/pricing/test_split_sync.py -v
```

Expected: FAIL — `sync_splits` doesn't exist.

- [ ] **Step 9.3: Implement PricingService.sync_splits**

Append to `src/net_alpha/pricing/service.py`:

```python
from dataclasses import dataclass


@dataclass
class SplitSyncResult:
    applied_count: int = 0
    skipped_count: int = 0
    error_symbols: list[str] = None

    def __post_init__(self):
        if self.error_symbols is None:
            self.error_symbols = []


class PricingService:
    # ... (existing methods unchanged) ...

    def sync_splits(self, symbols: list[str], *, repo) -> SplitSyncResult:
        """For each symbol: fetch splits from provider, upsert into repo,
        and call apply_splits to mutate freshly-loaded lots.

        When pricing is disabled, returns a result with all symbols listed
        as errors (no network call attempted)."""
        from net_alpha.splits.apply import apply_splits

        result = SplitSyncResult()
        if not self._enabled:
            result.error_symbols = list(symbols)
            return result

        for sym in symbols:
            try:
                events = self._provider.fetch_splits(sym)
            except Exception as exc:
                logger.warning("pricing: split fetch failed for {}: {}", sym, exc)
                result.error_symbols.append(sym)
                continue
            for ev in events:
                # add_split is idempotent — returns existing id when (symbol, date) is known.
                existing = [s for s in repo.get_splits(sym) if s.split_date == ev.split_date]
                if existing:
                    result.skipped_count += 1
                else:
                    repo.add_split(ev.symbol, ev.split_date, ev.ratio, "yahoo")
                    result.applied_count += 1

        # Apply all pending mutations now (idempotent over already-applied splits).
        apply_splits(repo)
        return result
```

- [ ] **Step 9.4: Run service test to verify it passes**

```bash
uv run pytest tests/pricing/test_split_sync.py -v
```

Expected: PASS.

- [ ] **Step 9.5: Write the failing test for the route**

```python
# tests/web/test_split_sync_route.py
"""POST /splits/sync triggers PricingService.sync_splits and returns counts."""

from datetime import date
from unittest.mock import patch

from fastapi.testclient import TestClient


def test_post_splits_sync_with_all_returns_summary(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2020, 1, 5), qty=10, cost=1500),
    ])
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    # Stub the provider's fetch_splits to return one event for AAPL.
    from net_alpha.pricing.provider import SplitEvent
    def fake_fetch(self, symbol):
        if symbol == "AAPL":
            return [SplitEvent(symbol="AAPL", split_date=date(2020, 8, 31), ratio=2.0)]
        return []
    with patch("net_alpha.pricing.yahoo.YahooPriceProvider.fetch_splits", fake_fetch):
        res = client.post("/splits/sync?symbols=ALL")

    assert res.status_code == 200
    body = res.json()
    assert body["applied_count"] == 1
    assert body["skipped_count"] == 0
    assert body["error_symbols"] == []


def test_post_splits_sync_with_specific_symbol(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "NVDA", date(2020, 1, 5), qty=10, cost=2000),
    ])
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    with patch("net_alpha.pricing.yahoo.YahooPriceProvider.fetch_splits", return_value=[]):
        res = client.post("/splits/sync?symbols=NVDA")

    assert res.status_code == 200
```

- [ ] **Step 9.6: Add the endpoint to portfolio.py**

In `src/net_alpha/web/routes/portfolio.py`, append a new endpoint (mirrors `/prices/refresh`):

```python
@router.post("/splits/sync")
def sync_splits(
    symbols: str | None = Query(default="ALL"),
    svc: PricingService = Depends(get_pricing_service),
    repo: Repository = Depends(get_repository),
) -> dict[str, object]:
    if not symbols:
        raise HTTPException(status_code=400, detail="symbols query param required")
    if symbols.strip().upper() == "ALL":
        sym_list = sorted({lot.ticker for lot in repo.all_lots() if lot.option_details is None})
    else:
        sym_list = [s.strip() for s in symbols.split(",") if s.strip()]
    if not sym_list:
        return {"applied_count": 0, "skipped_count": 0, "error_symbols": []}
    result = svc.sync_splits(sym_list, repo=repo)
    return {
        "applied_count": result.applied_count,
        "skipped_count": result.skipped_count,
        "error_symbols": result.error_symbols,
    }
```

- [ ] **Step 9.7: Add the Sync splits button to the toolbar**

In `src/net_alpha/web/templates/_portfolio_toolbar.html`, in the right-side button group near `Refresh`, add before or after the `Refresh` button:

```html
    <button type="button"
            hx-post="/splits/sync?symbols=ALL"
            hx-target="body" hx-swap="none"
            onclick="window.location.reload()"
            class="btn-ghost">⇅ Sync splits</button>
```

- [ ] **Step 9.8: Run route test to verify it passes**

```bash
uv run pytest tests/web/test_split_sync_route.py -v
```

Expected: PASS.

- [ ] **Step 9.9: Commit**

```bash
git add src/net_alpha/pricing/service.py \
        src/net_alpha/web/routes/portfolio.py \
        src/net_alpha/web/templates/_portfolio_toolbar.html \
        tests/pricing/test_split_sync.py \
        tests/web/test_split_sync_route.py
git commit -m "feat(splits): /splits/sync endpoint + toolbar Sync splits button (item 5)

PricingService.sync_splits orchestrates fetch -> upsert -> apply. Honors
the prices.enable_remote flag (returns error_symbols when disabled, no
network call). Toolbar button POSTs symbols=ALL and reloads the page."
```

### Task 10: Auto-sync on first import of a symbol

**Files:**
- Modify: `src/net_alpha/web/routes/imports.py` (the upload handler)
- Modify: `src/net_alpha/cli/default.py` (the CLI default-command import flow)
- Test: `tests/integration/test_split_autosync_on_import.py` (new)

- [ ] **Step 10.1: Write the failing test**

```python
# tests/integration/test_split_autosync_on_import.py
"""When a CSV brings in a NEW symbol (not previously seen in any import),
the import flow should auto-call sync_splits for that symbol so existing
splits are applied immediately. Existing symbols should NOT trigger
auto-fetch (avoids burning network on every re-import)."""

from datetime import date
from unittest.mock import patch

import pytest


def test_first_import_triggers_split_autosync(client, builders, repo):
    """A brand-new symbol triggers fetch_splits during import."""
    fetch_calls = []

    def fake_fetch(self, symbol):
        fetch_calls.append(symbol)
        return []

    with patch("net_alpha.pricing.yahoo.YahooPriceProvider.fetch_splits", fake_fetch):
        builders.seed_import(repo, "schwab", "lt", [
            builders.make_buy("schwab/lt", "NEWSYM", date(2026, 1, 5)),
        ], csv_filename="first.csv")
        # The seed_import helper mimics the import flow but skips the route's
        # auto-sync hook. Test the import route directly via CLI default flow.
        from net_alpha.cli.default import _post_import_autosync_splits
        _post_import_autosync_splits(repo, new_symbols={"NEWSYM"}, existing_symbols=set())

    assert "NEWSYM" in fetch_calls


def test_reimport_of_existing_symbol_skips_autosync(builders, repo):
    fetch_calls = []

    def fake_fetch(self, symbol):
        fetch_calls.append(symbol)
        return []

    with patch("net_alpha.pricing.yahoo.YahooPriceProvider.fetch_splits", fake_fetch):
        from net_alpha.cli.default import _post_import_autosync_splits
        _post_import_autosync_splits(repo, new_symbols={"AAPL"}, existing_symbols={"AAPL"})

    assert fetch_calls == []
```

- [ ] **Step 10.2: Run test to verify it fails**

```bash
uv run pytest tests/integration/test_split_autosync_on_import.py -v
```

Expected: FAIL — function doesn't exist.

- [ ] **Step 10.3: Add the helper function**

In `src/net_alpha/cli/default.py` (or wherever the default import handler lives — confirm with `grep -n "def default" src/net_alpha/cli/default.py`), add:

```python
def _post_import_autosync_splits(
    repo,
    *,
    new_symbols: set[str],
    existing_symbols: set[str],
) -> None:
    """If pricing is enabled and there are symbols seen for the first time
    in this DB, fetch their splits so the user doesn't have to remember to
    click Sync splits."""
    from net_alpha.config import load_pricing_config
    from net_alpha.pricing.cache import PriceCache
    from net_alpha.pricing.service import PricingService
    from net_alpha.pricing.yahoo import YahooPriceProvider

    truly_new = new_symbols - existing_symbols
    if not truly_new:
        return

    cfg = load_pricing_config()
    if not cfg.enable_remote:
        return

    cache = PriceCache(repo.engine, ttl_seconds=cfg.cache_ttl_seconds)
    svc = PricingService(provider=YahooPriceProvider(), cache=cache, enabled=True)
    try:
        svc.sync_splits(sorted(truly_new), repo=repo)
    except Exception:
        # Auto-sync is best-effort; never block import on a failure.
        pass
```

- [ ] **Step 10.4: Wire the helper into the default CLI import flow**

Locate the existing import handler in `src/net_alpha/cli/default.py` (search for `repo.add_import` or `recompute_all_violations`). After the trades are persisted and the recompute call runs, but before the rendered output, capture symbol sets and call the helper:

```python
# Before add_import
existing_symbols = {lot.ticker for lot in repo.all_lots() if lot.option_details is None}

# After add_import + recompute_all_violations
new_symbols = {t.ticker for t in trades_imported if t.option_details is None}
_post_import_autosync_splits(repo, new_symbols=new_symbols, existing_symbols=existing_symbols)
```

(`trades_imported` is the list returned from `add_import` or extracted from the AddImportResult — adjust to match the existing variable name.)

- [ ] **Step 10.5: Same wiring for the web import route**

In `src/net_alpha/web/routes/imports.py:57` (where `recompute_all_violations` is called), add the same hook. Reuse `_post_import_autosync_splits` from `cli.default` (import it).

```python
from net_alpha.cli.default import _post_import_autosync_splits
# ...
existing_symbols = {lot.ticker for lot in repo.all_lots() if lot.option_details is None}
# ... existing add_import + recompute ...
new_symbols = {t.ticker for t in newly_imported_trades if t.option_details is None}
_post_import_autosync_splits(repo, new_symbols=new_symbols, existing_symbols=existing_symbols)
```

- [ ] **Step 10.6: Run integration test**

```bash
uv run pytest tests/integration/test_split_autosync_on_import.py -v
```

Expected: PASS.

- [ ] **Step 10.7: Run full integration suite**

```bash
uv run pytest tests/integration/ -v
```

Expected: PASS.

- [ ] **Step 10.8: Commit**

```bash
git add src/net_alpha/cli/default.py src/net_alpha/web/routes/imports.py tests/integration/test_split_autosync_on_import.py
git commit -m "feat(splits): auto-sync on first import of a new symbol (item 5)

When a CSV brings in symbols never seen in any prior import, fire
sync_splits for those symbols so existing wash-sale data stays accurate
without manual intervention. Re-imports of known symbols do NOT trigger
fetch -- avoids burning network on every CSV upload."
```

### Task 11: Manual lot edit UI on /ticker/{sym}

**Files:**
- Modify: `src/net_alpha/web/templates/_lots_table.html`
- Modify: `src/net_alpha/web/routes/ticker.py` (add /lots/{lot_id}/edit endpoint)
- Modify: `src/net_alpha/db/repository.py` (add edit_lot method that touches both lot row + override audit)
- Test: `tests/web/test_lot_edit_route.py` (new)

- [ ] **Step 11.1: Write the failing test**

```python
# tests/web/test_lot_edit_route.py
"""Per-lot manual edit on the ticker page lets the user override
quantity and adjusted_basis. Writes a lot_overrides row with reason='manual'
and triggers wash-sale recompute."""

from datetime import date

from fastapi.testclient import TestClient


def test_post_lot_edit_updates_qty_and_basis(client: TestClient, builders, repo):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5), qty=10, cost=1500),
    ])
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    lot = repo.get_lots_for_ticker("AAPL")[0]
    res = client.post(
        f"/lots/{lot.id}/edit",
        data={"quantity": "1.0", "adjusted_basis": "1500.0"},
    )
    assert res.status_code in (200, 204)

    # Recompute is triggered, which regenerates lots from trades + applies
    # overrides. Verify the override was recorded:
    trades = repo.get_trades_for_ticker("AAPL")
    overrides = repo.get_lot_overrides_for_trade(int(trades[0].id))
    assert any(o.field == "quantity" and o.reason == "manual" for o in overrides)


def test_post_lot_edit_returns_404_on_missing_lot(client: TestClient):
    res = client.post(
        "/lots/99999/edit",
        data={"quantity": "1.0", "adjusted_basis": "1.0"},
    )
    assert res.status_code == 404
```

- [ ] **Step 11.2: Run test — expect failure**

```bash
uv run pytest tests/web/test_lot_edit_route.py -v
```

Expected: FAIL — endpoint doesn't exist.

- [ ] **Step 11.3: Note on persistence model for manual overrides**

Manual lot edits face the same regenerated-lots problem as splits: a `replace_lots_in_window` from any future recompute will blow away the manual edit. So manual edits must also be **re-applied as a final step of recompute**. We extend `apply_splits` to be `apply_lot_mutations` that handles both:

In `src/net_alpha/splits/apply.py`, append:

```python
def apply_manual_overrides(repo: Repository) -> int:
    """Re-apply ANY 'manual' lot_overrides row to the corresponding lot,
    keyed by trade_id. Idempotent — applies the LATEST manual override per
    (trade_id, field). Returns count of mutations actually written."""
    overrides = repo.all_lot_overrides()
    if not overrides:
        return 0

    # Latest-wins per (trade_id, field) for reason='manual'.
    latest: dict[tuple[int, str], "LotOverride"] = {}
    for o in overrides:
        if o.reason != "manual":
            continue
        key = (o.trade_id, o.field)
        prev = latest.get(key)
        if prev is None or o.edited_at > prev.edited_at:
            latest[key] = o

    mutations = 0
    # Group by trade_id so we read each lot once.
    from collections import defaultdict
    by_trade: dict[int, list] = defaultdict(list)
    for (tid, _field), o in latest.items():
        by_trade[tid].append(o)

    for tid, applicable in by_trade.items():
        # Find the lot row for this trade.
        from net_alpha.db.tables import LotRow
        from sqlmodel import Session, select
        with Session(repo.engine) as s:
            row = s.exec(select(LotRow).where(LotRow.trade_id == tid)).first()
            if row is None:
                continue
            new_qty = row.quantity
            new_basis = row.adjusted_basis
            for o in applicable:
                if o.field == "quantity":
                    new_qty = o.new_value
                elif o.field == "adjusted_basis":
                    new_basis = o.new_value
            if new_qty != row.quantity or new_basis != row.adjusted_basis:
                row.quantity = new_qty
                row.adjusted_basis = new_basis
                s.add(row)
                s.commit()
                mutations += 1
    return mutations
```

Then in `src/net_alpha/engine/recompute.py`, replace the trailing-comment placeholder added in Task 8 (Step 8.5) with the actual call. The final body of `recompute_all_violations` should end with:

```python
    repo.replace_violations_in_window(win_start, win_end, merged)
    repo.replace_lots_in_window(win_start, win_end, det.lots)

    apply_splits(repo)
    apply_manual_overrides(repo)
```

And add the import at the top of `recompute.py`:

```python
from net_alpha.splits.apply import apply_manual_overrides, apply_splits
```

(Order matters — apply_splits first so the lots reflect the split-adjusted baseline; manual overrides then take precedence.)

- [ ] **Step 11.4: Add /lots/{lot_id}/edit endpoint**

In `src/net_alpha/web/routes/ticker.py` (or a new file `lots.py` if you prefer; either is fine), add:

```python
from fastapi import Form, HTTPException

@router.post("/lots/{lot_id}/edit", response_class=HTMLResponse)
def edit_lot(
    lot_id: int,
    request: Request,
    quantity: float = Form(...),
    adjusted_basis: float = Form(...),
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    from net_alpha.db.tables import LotRow
    from sqlmodel import Session, select
    from net_alpha.engine.recompute import recompute_all_violations

    with Session(repo.engine) as s:
        row = s.exec(select(LotRow).where(LotRow.id == lot_id)).first()
        if row is None:
            raise HTTPException(status_code=404, detail=f"Lot {lot_id} not found")
        old_qty = row.quantity
        old_basis = row.adjusted_basis
        trade_id = row.trade_id

    # Persist the override audit BEFORE the lot mutation so the recompute
    # below picks it up on the way back through.
    if old_qty != quantity:
        repo.add_lot_override(
            trade_id=int(trade_id), field="quantity",
            old_value=old_qty, new_value=quantity, reason="manual",
        )
    if old_basis != adjusted_basis:
        repo.add_lot_override(
            trade_id=int(trade_id), field="adjusted_basis",
            old_value=old_basis, new_value=adjusted_basis, reason="manual",
        )

    # Trigger a full recompute. apply_manual_overrides will replay our edit.
    recompute_all_violations(repo, request.app.state.etf_pairs)

    # Return the updated lot row fragment (or full lots table) for HTMX swap.
    # If you didn't structure the table for fragment swap, return 204 No Content
    # and let the client window.location.reload() (matches the toolbar buttons).
    return HTMLResponse(status_code=204)
```

- [ ] **Step 11.5: Add the Edit UI to _lots_table.html**

In `src/net_alpha/web/templates/_lots_table.html`, find each row's last cell (or add a new cell). Add an Alpine-toggled inline form:

```html
<td x-data="{ editing: false }">
  <button type="button" x-show="!editing" @click="editing = true"
          class="btn-ghost text-[11px]">Edit</button>
  <form x-show="editing"
        method="post" action="/lots/{{ lot.id }}/edit"
        hx-post="/lots/{{ lot.id }}/edit"
        hx-target="body" hx-swap="none"
        @htmx:after-request="window.location.reload()">
    <input type="number" name="quantity" step="0.0001" value="{{ lot.quantity }}"
           class="bg-surface text-text rounded-md px-1 py-[1px] text-[11px] w-20"/>
    <input type="number" name="adjusted_basis" step="0.01" value="{{ lot.adjusted_basis }}"
           class="bg-surface text-text rounded-md px-1 py-[1px] text-[11px] w-24"/>
    <button type="submit" class="btn-ghost text-[11px]">Save</button>
    <button type="button" @click="editing = false" class="btn-ghost text-[11px]">Cancel</button>
  </form>
</td>
```

(Adapt classes/spacing to the existing `_lots_table.html` style. The exact column placement is at engineer discretion.)

- [ ] **Step 11.6: Run route test**

```bash
uv run pytest tests/web/test_lot_edit_route.py -v
```

Expected: PASS.

- [ ] **Step 11.7: Add a unit test for apply_manual_overrides**

```python
# Append to tests/splits/test_apply.py

from datetime import date


def test_apply_manual_overrides_replays_latest_edit(repo, builders):
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "AAPL", date(2026, 1, 5), qty=10, cost=1500),
    ])
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    trade_id = int(repo.get_trades_for_ticker("AAPL")[0].id)
    repo.add_lot_override(
        trade_id=trade_id, field="quantity",
        old_value=10.0, new_value=2.0, reason="manual",
    )

    # A subsequent recompute would otherwise blow away the qty=2 edit; the
    # apply_manual_overrides call inside recompute_all_violations should
    # re-apply it.
    recompute_all_violations(repo, load_etf_pairs())

    lots = repo.get_lots_for_ticker("AAPL")
    assert lots[0].quantity == 2.0
```

```bash
uv run pytest tests/splits/test_apply.py -v
```

Expected: PASS.

- [ ] **Step 11.8: Commit**

```bash
git add src/net_alpha/splits/apply.py src/net_alpha/engine/recompute.py \
        src/net_alpha/web/routes/ticker.py src/net_alpha/web/templates/_lots_table.html \
        tests/web/test_lot_edit_route.py tests/splits/test_apply.py
git commit -m "feat(splits): manual per-lot edit UI on /ticker/{sym} (item 5)

Inline edit form on each lot row writes a lot_overrides record with
reason='manual'. apply_manual_overrides replays the latest edit per
(trade_id, field) at the end of every recompute, so manual edits survive
re-import / unimport / future recomputes."
```

---

## Phase 5 — End-to-end smoke + cleanup

### Task 12: Integration test — full flow

**Files:**
- Test: `tests/integration/test_split_e2e.py` (new)

- [ ] **Step 12.1: Write the test**

```python
# tests/integration/test_split_e2e.py
"""End-to-end: import -> sync_splits -> verify lot adjusted -> imports rm
-> re-import -> verify lot still split-adjusted on the way back through
recompute."""

from datetime import date
from unittest.mock import patch


def test_split_survives_unimport_reimport_cycle(builders, repo, client):
    from net_alpha.pricing.provider import SplitEvent

    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "SQQQ", date(2024, 1, 5), qty=100, cost=2000),
    ], csv_filename="initial.csv")
    from net_alpha.engine.recompute import recompute_all_violations
    from net_alpha.engine.etf_pairs import load_etf_pairs
    recompute_all_violations(repo, load_etf_pairs())

    with patch(
        "net_alpha.pricing.yahoo.YahooPriceProvider.fetch_splits",
        return_value=[SplitEvent(symbol="SQQQ", split_date=date(2025, 1, 13), ratio=0.1)],
    ):
        client.post("/splits/sync?symbols=SQQQ")

    lots = repo.get_lots_for_ticker("SQQQ")
    assert lots[0].quantity == 10.0  # 100 * 0.1

    # Unimport.
    imports = repo.list_imports()
    repo.remove_import(imports[0].id)

    # Re-import the same trade.
    builders.seed_import(repo, "schwab", "lt", [
        builders.make_buy("schwab/lt", "SQQQ", date(2024, 1, 5), qty=100, cost=2000),
    ], csv_filename="reimport.csv")
    recompute_all_violations(repo, load_etf_pairs())

    # Lot should still be split-adjusted (split is in the splits table; recompute
    # calls apply_splits at the end).
    lots = repo.get_lots_for_ticker("SQQQ")
    assert lots[0].quantity == 10.0
```

- [ ] **Step 12.2: Run**

```bash
uv run pytest tests/integration/test_split_e2e.py -v
```

Expected: PASS.

- [ ] **Step 12.3: Run the FULL test suite**

```bash
uv run pytest -q
```

Expected: PASS. If anything fails, diagnose before committing.

- [ ] **Step 12.4: Lint check**

```bash
uv run ruff check . && uv run ruff format --check .
```

Expected: clean. If format complains, run `uv run ruff format .` and re-stage.

- [ ] **Step 12.5: Commit**

```bash
git add tests/integration/test_split_e2e.py
git commit -m "test(splits): e2e split survival across unimport/reimport (item 5)"
```

### Task 13: Manual smoke checklist (no code; document run)

After all of the above merges to master:

- [ ] **Step 13.1:** Run `uv run net-alpha ui --no-browser` and open `http://127.0.0.1:8765` (or whatever default).

- [ ] **Step 13.2:** On `/holdings`, change the Account dropdown — verify URL stays `/holdings?account=...&period=ytd`.

- [ ] **Step 13.3:** Click the multi-symbol "Symbols: All" button — dropdown opens directly under the button, not at the page's left edge. No raw JS text visible anywhere on the page.

- [ ] **Step 13.4:** Click "Sync splits" on the toolbar — wait for reload — observe SQQQ shrinks to its true count.

- [ ] **Step 13.5:** Visit `/detail` directly in the browser — gets 301-redirected to `/wash-sales` (table view).

- [ ] **Step 13.6:** Visit `/calendar` directly — 301-redirected to `/wash-sales?view=calendar`.

- [ ] **Step 13.7:** On `/ticker/SQQQ` (or any held symbol), click "Edit" on a lot row, change quantity to a new value, save — page reloads, the new quantity persists.

If anything fails, file a follow-up bug.

---

## Self-Review Checklist

After completing all tasks, verify:

- [ ] Every spec section is covered by a task above. (Items 1, 2, 4, 5, 6.)
- [ ] No "TBD" / "TODO" / "fill in" markers anywhere in plan steps.
- [ ] All function/method/property names are consistent across tasks (e.g., `apply_splits`, `apply_manual_overrides`, `add_split`, `get_splits`, `add_lot_override`, `_post_import_autosync_splits`).
- [ ] Every test step has actual test code, not "test the above".
- [ ] Every code step has actual code blocks.
- [ ] Migrations go v6→v7 (single bump) with rollback considered (no, rollback not needed; additive only).
- [ ] The `recompute_all_violations` integration appends `apply_splits` then `apply_manual_overrides` at the bottom, and is tested for both.
- [ ] Test file paths exist before importing fixtures (e.g., `tests/web/conftest.py` provides `builders` and `repo`).
- [ ] `tests/splits/__init__.py` is created (Step 8 lists it but the empty file matters for pytest discovery).
- [ ] No `_calendar_focus.html` template references break after Task 4's URL rewrite.

If any item fails, fix inline and re-run the relevant test command.
