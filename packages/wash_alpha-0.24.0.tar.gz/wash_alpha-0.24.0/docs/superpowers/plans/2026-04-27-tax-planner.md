# Phase 2 — Forward Tax Planner Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a forward-looking tax planner — harvest queue, offset budget, year-end tax projection, and pre-trade traffic light — by extending the existing `/wash-sales` page into a tabbed `/tax` page and embedding two new tiles on `/portfolio`.

**Architecture:** All new logic lives in two new pure-function modules (`portfolio/tax_planner.py`, plus extensions to `engine/`); the web layer only renders. Wheel-strategy awareness reuses the existing `option_short_open_assigned` / `option_short_close_assigned` synthetic-trade pairs already produced by the Schwab broker parser — no schema changes. The existing `/wash-sales` route is renamed to `/tax`, gains three new tabs, and leaves a 301 redirect behind for bookmarks.

**Tech Stack:** Python 3.11, pydantic v2, FastAPI + Jinja2 + HTMX, pytest + factory_boy, ruff. Reads from existing `Repository`, `PricingService`, `engine.detector`, `engine.etf_pairs`. New optional `tax:` section in `~/.net_alpha/config.yaml`. New bundled `etf_replacements.yaml` (similar-but-not-identical replacements for harvest suggestions).

**Reference docs:** Spec at `docs/superpowers/specs/2026-04-27-provenance-tax-planner-density-design.md` (Section 2). Phase 1 plan at `docs/superpowers/plans/2026-04-27-provenance-layer.md` for patterns to mirror (templates, tests, route conventions).

**Out of scope (per spec):** Per-account profile picker, density toggle, `user_preferences` table, schema bump v8→v9 — all Phase 3. Spread tax accounting, constructive-sale doctrine, qualified-covered-call deep-ITM rules, straddle disallowance — flag-only, no math (covered by `assess_trade` returning yellow when detected). Multi-bracket federal tax — single-marginal-rate estimate only.

---

## File Structure

```
src/net_alpha/
├── etf_replacements.yaml             # NEW (bundled, similar-but-not-identical pairs)
├── config.py                         # MODIFY (add TaxConfig + load_tax_config)
├── engine/
│   ├── etf_pairs.py                  # MODIFY (add load_etf_replacements + consistency check)
│   └── lockout.py                    # NEW (compute_lockout_clear_date — same- and cross-asset)
├── portfolio/
│   └── tax_planner.py                # NEW (entire forward-tax-planner compute layer)
├── audit/
│   └── hygiene.py                    # MODIFY (add 'tax_config_missing' category)
└── web/
    ├── app.py                        # MODIFY (load tax config + replacements at startup;
    │                                  # register tax_routes; rename nav)
    ├── routes/
    │   ├── tax.py                    # NEW (replaces wash_sales.py public surface;
    │   │                              # GET /tax with tabbed view dispatch)
    │   ├── wash_sales.py             # MODIFY → 301 redirect shim only
    │   ├── sim.py                    # MODIFY (prepend traffic-light fragment to results)
    │   └── portfolio.py              # MODIFY (add offset-budget tile + projection card to KPI fragment)
    └── templates/
        ├── tax.html                  # NEW (replaces wash_sales.html — 4-tab page)
        ├── _tax_wash_sales_tab.html  # NEW (extracted from old wash_sales.html — table+calendar branch)
        ├── _harvest_queue.html       # NEW
        ├── _offset_budget_tile.html  # NEW
        ├── _offset_budget_tab.html   # NEW (full tab variant on /tax)
        ├── _projection_card.html     # NEW
        ├── _projection_tab.html      # NEW (full tab variant on /tax)
        ├── _traffic_light.html       # NEW
        ├── _portfolio_kpis.html      # MODIFY (insert tile + card slots)
        ├── _sim_sell_result.html     # MODIFY (prepend traffic-light fragment)
        ├── _sim_buy_result.html      # MODIFY (prepend traffic-light fragment)
        └── base.html                 # MODIFY (rename nav "Wash sales" → "Tax")

tests/
├── engine/
│   └── test_lockout.py               # NEW
├── portfolio/
│   ├── conftest.py                   # MODIFY (extend with tax-planner fixture if not already present)
│   ├── test_tax_planner_harvest.py   # NEW
│   ├── test_tax_planner_offset.py    # NEW
│   ├── test_tax_planner_projection.py # NEW
│   ├── test_tax_planner_traffic_light.py # NEW
│   └── test_tax_planner_wheel.py     # NEW
├── config/
│   └── test_tax_config.py            # NEW
├── audit/
│   └── test_hygiene_tax_config.py    # NEW
└── web/
    ├── test_tax_route.py             # NEW
    ├── test_tax_redirects.py         # NEW
    ├── test_harvest_queue_render.py  # NEW
    ├── test_offset_budget_render.py  # NEW
    ├── test_projection_render.py     # NEW
    ├── test_traffic_light_sim.py     # NEW
    └── test_phase2_smoke.py          # NEW
```

**Total new tasks:** 30 (TDD-paced).

---

## Section A — Foundation

### Task 1: TaxConfig model + loader

**Files:**
- Modify: `src/net_alpha/config.py`
- Create: `tests/config/__init__.py` (if missing)
- Create: `tests/config/test_tax_config.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/config/test_tax_config.py
from decimal import Decimal
from pathlib import Path

from net_alpha.config import TaxConfig, load_tax_config


def test_load_tax_config_returns_none_when_missing(tmp_path: Path) -> None:
    assert load_tax_config(tmp_path / "config.yaml") is None


def test_load_tax_config_returns_none_when_section_absent(tmp_path: Path) -> None:
    p = tmp_path / "config.yaml"
    p.write_text("prices:\n  enable_remote: true\n")
    assert load_tax_config(p) is None


def test_load_tax_config_parses_full_section(tmp_path: Path) -> None:
    p = tmp_path / "config.yaml"
    p.write_text(
        "tax:\n"
        "  filing_status: single\n"
        "  state: CA\n"
        "  federal_marginal_rate: 0.32\n"
        "  state_marginal_rate: 0.093\n"
        "  ltcg_rate: 0.15\n"
        "  qualified_div_rate: 0.15\n"
        "  reconciliation_tolerance: 0.50\n"
    )
    cfg = load_tax_config(p)
    assert cfg is not None
    assert cfg.filing_status == "single"
    assert cfg.state == "CA"
    assert cfg.federal_marginal_rate == Decimal("0.32")
    assert cfg.reconciliation_tolerance == Decimal("0.50")


def test_load_tax_config_defaults(tmp_path: Path) -> None:
    p = tmp_path / "config.yaml"
    p.write_text("tax:\n  filing_status: single\n  federal_marginal_rate: 0.22\n")
    cfg = load_tax_config(p)
    assert cfg is not None
    assert cfg.state == ""
    assert cfg.state_marginal_rate == Decimal("0")
    assert cfg.ltcg_rate == Decimal("0.15")
    assert cfg.qualified_div_rate == Decimal("0.15")
    assert cfg.reconciliation_tolerance == Decimal("0.50")


def test_load_tax_config_invalid_yaml_returns_none(tmp_path: Path) -> None:
    p = tmp_path / "config.yaml"
    p.write_text("tax: {{not yaml")
    assert load_tax_config(p) is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/config/test_tax_config.py -v`
Expected: FAIL — `cannot import name 'TaxConfig' from 'net_alpha.config'`

- [ ] **Step 3: Implement TaxConfig and loader**

In `src/net_alpha/config.py`, append:

```python
from decimal import Decimal
from typing import Literal


class TaxConfig(BaseModel):
    """Optional tax configuration loaded from `~/.net_alpha/config.yaml` `tax:` section."""

    model_config = {"extra": "ignore"}

    filing_status: Literal["single", "mfj", "mfs", "hoh"] = "single"
    state: str = ""  # ISO state code; "" = federal-only
    federal_marginal_rate: Decimal = Decimal("0")
    state_marginal_rate: Decimal = Decimal("0")
    ltcg_rate: Decimal = Decimal("0.15")
    qualified_div_rate: Decimal = Decimal("0.15")
    reconciliation_tolerance: Decimal = Decimal("0.50")


def load_tax_config(path: Path) -> TaxConfig | None:
    """Load TaxConfig from a YAML file's ``tax:`` section. None if missing/invalid/absent."""
    if not path.exists():
        return None
    try:
        data = yaml.safe_load(path.read_text()) or {}
    except yaml.YAMLError:
        return None
    section = data.get("tax")
    if not section:
        return None
    try:
        return TaxConfig(**section)
    except ValidationError:
        return None
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/config/test_tax_config.py -v`
Expected: PASS (5 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/config.py tests/config/__init__.py tests/config/test_tax_config.py
git commit -m "feat(config): add TaxConfig model and loader"
```

---

### Task 2: Hygiene `tax_config_missing` category

**Files:**
- Modify: `src/net_alpha/audit/hygiene.py`
- Create: `tests/audit/test_hygiene_tax_config.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_hygiene_tax_config.py
from pathlib import Path

from net_alpha.audit.hygiene import HygieneIssue, collect_issues
from net_alpha.config import Settings


def test_collect_issues_includes_tax_config_missing(tmp_path: Path, repo) -> None:
    settings = Settings(data_dir=tmp_path)
    # No config.yaml at all -> tax_config_missing surfaces as info.
    issues = collect_issues(repo, settings=settings)
    matching = [i for i in issues if i.category == "tax_config_missing"]
    assert len(matching) == 1
    issue: HygieneIssue = matching[0]
    assert issue.severity == "info"
    assert "tax bracket" in issue.summary.lower()


def test_collect_issues_omits_tax_config_missing_when_present(tmp_path: Path, repo) -> None:
    settings = Settings(data_dir=tmp_path)
    (tmp_path / "config.yaml").write_text(
        "tax:\n  filing_status: single\n  federal_marginal_rate: 0.22\n"
    )
    issues = collect_issues(repo, settings=settings)
    assert all(i.category != "tax_config_missing" for i in issues)


def test_collect_issues_works_without_settings_kwarg(repo) -> None:
    # Backwards-compatible: callers that don't pass settings still work.
    issues = collect_issues(repo)
    # No settings -> we cannot determine config presence; we omit the row entirely.
    assert all(i.category != "tax_config_missing" for i in issues)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/audit/test_hygiene_tax_config.py -v`
Expected: FAIL — `collect_issues()` does not accept `settings` kwarg / category not present.

- [ ] **Step 3: Implement the category**

In `src/net_alpha/audit/hygiene.py`:

1. Extend the `category` Literal of `HygieneIssue` to include `"tax_config_missing"`.
2. Change `collect_issues` signature to `def collect_issues(repo: Repository, settings: Settings | None = None) -> list[HygieneIssue]:`.
3. Add a private check:

```python
from net_alpha.config import Settings, load_tax_config


def _check_tax_config_missing(settings: Settings) -> list[HygieneIssue]:
    if load_tax_config(settings.config_yaml_path) is not None:
        return []
    return [
        HygieneIssue(
            category="tax_config_missing",
            severity="info",
            summary="Tax bracket configuration not set",
            detail=(
                "Add a `tax:` section to ~/.net_alpha/config.yaml to enable the "
                "year-end tax projection card. The harvest queue, offset budget, "
                "and trade traffic light still work without it."
            ),
            fix_url="/imports#tax-config",
            fix_form=None,
        )
    ]
```

4. In `collect_issues`, when `settings is not None`, append `_check_tax_config_missing(settings)`.

- [ ] **Step 4: Update existing call site**

In `src/net_alpha/web/app.py`, update the imports-badge Jinja global to pass settings:

```python
def imports_badge_count() -> int | None:
    return get_imports_badge_count(repo, settings=settings)
```

And in `src/net_alpha/audit/_badge_cache.py`, extend `get_imports_badge_count(repo, settings=None)` to forward to `collect_issues(repo, settings=settings)`.

- [ ] **Step 5: Run all hygiene tests to verify no regression**

Run: `uv run pytest tests/audit/test_hygiene*.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/audit/hygiene.py src/net_alpha/audit/_badge_cache.py \
        src/net_alpha/web/app.py tests/audit/test_hygiene_tax_config.py
git commit -m "feat(audit): hygiene category 'tax_config_missing'"
```

---

### Task 3: `etf_replacements.yaml` + `load_etf_replacements()` with cross-validation

**Files:**
- Create: `src/net_alpha/etf_replacements.yaml`
- Modify: `src/net_alpha/engine/etf_pairs.py`
- Create: `tests/engine/test_etf_replacements.py`

- [ ] **Step 1: Create bundled YAML**

```yaml
# src/net_alpha/etf_replacements.yaml
# Substantially-SIMILAR replacements: similar exposure, NOT substantially identical.
# Use to suggest harvest replacements that should not trigger wash-sale rules.
# This is a judgment call — every suggestion is labeled "discuss with CPA."

SPY:
  - VTI    # total US market vs S&P 500
  - SCHB
VOO:
  - VTI
  - SCHB
IVV:
  - VTI
  - SCHB
QQQ:
  - VGT    # tech sector vs Nasdaq-100
  - SPYG   # S&P 500 growth
QQQM:
  - VGT
  - SPYG
VTI:
  - SPY    # S&P 500 vs total US
  - SCHX
DIA:
  - VTV    # value vs Dow 30
SCHD:
  - VYM    # different methodology, similar exposure
EFA:
  - VEA    # developed-market ex-US, distinct index families
EEM:
  - VWO    # emerging markets, distinct index families
```

- [ ] **Step 2: Write the failing test**

```python
# tests/engine/test_etf_replacements.py
from pathlib import Path

import pytest

from net_alpha.engine.etf_pairs import (
    ReplacementsConflictWarning,
    load_etf_pairs,
    load_etf_replacements,
)


def test_load_etf_replacements_bundled() -> None:
    repls = load_etf_replacements()
    assert "SPY" in repls
    assert "VTI" in repls["SPY"]


def test_user_replacements_extend_bundled(tmp_path: Path) -> None:
    user = tmp_path / "etf_replacements.yaml"
    user.write_text("SPY:\n  - SCHX\n")
    repls = load_etf_replacements(user_path=user)
    assert "VTI" in repls["SPY"]
    assert "SCHX" in repls["SPY"]


def test_replacements_consistency_filters_conflicts(tmp_path: Path) -> None:
    """A replacement must NEVER appear in the source's substantially-identical pairs."""
    user = tmp_path / "etf_replacements.yaml"
    # SPY's pairs include VOO/IVV/SPLG. If user adds VOO as a replacement, that's a conflict.
    user.write_text("SPY:\n  - VOO\n")
    pairs = load_etf_pairs()
    with pytest.warns(ReplacementsConflictWarning):
        repls = load_etf_replacements(user_path=user, etf_pairs=pairs)
    # Conflicting replacement must be filtered out (fail-soft).
    assert "VOO" not in repls.get("SPY", [])


def test_replacements_no_conflict_when_pairs_omitted() -> None:
    # When etf_pairs is None, no validation runs.
    repls = load_etf_replacements()
    assert isinstance(repls, dict)
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/engine/test_etf_replacements.py -v`
Expected: FAIL — `cannot import name 'load_etf_replacements'`

- [ ] **Step 4: Implement loader**

In `src/net_alpha/engine/etf_pairs.py`, append:

```python
import warnings


class ReplacementsConflictWarning(UserWarning):
    """Raised when a replacement appears in the source's substantially-identical pairs."""


def load_etf_replacements(
    user_path: str | Path | None = None,
    etf_pairs: dict[str, list[str]] | None = None,
) -> dict[str, list[str]]:
    """Load bundled ETF replacement suggestions, optionally extended with user file.

    If *etf_pairs* is provided, validate that no replacement appears in the source
    symbol's pair list; conflicts emit a warning and are excluded (fail-soft).
    """
    bundled_text = resources.files("net_alpha").joinpath("etf_replacements.yaml").read_text()
    repls: dict[str, list[str]] = yaml.safe_load(bundled_text) or {}

    if user_path:
        p = Path(user_path)
        if p.exists():
            user: dict[str, list[str]] = yaml.safe_load(p.read_text()) or {}
            for source, tickers in user.items():
                existing = set(repls.get(source, []))
                for ticker in tickers:
                    if ticker not in existing:
                        repls.setdefault(source, []).append(ticker)
                        existing.add(ticker)

    if etf_pairs:
        for source, replacements in list(repls.items()):
            forbidden = set(etf_pairs.get(source, []))
            kept = [r for r in replacements if r not in forbidden]
            dropped = set(replacements) - set(kept)
            if dropped:
                warnings.warn(
                    f"etf_replacements.yaml: {source} has conflicting replacements "
                    f"{sorted(dropped)} (also in etf_pairs.yaml); dropped.",
                    ReplacementsConflictWarning,
                    stacklevel=2,
                )
            repls[source] = kept

    return repls
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/engine/test_etf_replacements.py -v`
Expected: PASS (4 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/etf_replacements.yaml src/net_alpha/engine/etf_pairs.py \
        tests/engine/test_etf_replacements.py
git commit -m "feat(engine): bundled etf_replacements.yaml + loader with consistency check"
```

---

## Section B — Wheel-aware compute helpers

These compute on read from the existing trade chain. No schema changes.

### Task 4: `PremiumOriginEvent` + `extract_premium_origin()`

**Files:**
- Create: `src/net_alpha/portfolio/tax_planner.py`
- Create: `tests/portfolio/test_tax_planner_wheel.py` (start of file)

- [ ] **Step 1: Write the failing test**

```python
# tests/portfolio/test_tax_planner_wheel.py
from datetime import date
from decimal import Decimal

from net_alpha.models.domain import OptionDetails, Trade
from net_alpha.portfolio.tax_planner import (
    CSPAssigned,
    extract_premium_origin,
)


def test_extract_premium_origin_for_csp_assigned_buy() -> None:
    """A Buy trade with basis_source 'option_short_open_assigned' is CSP-originated.

    Schwab parser emits this synthetic Buy when a sold put is assigned. We must
    pair it back to the originating STO leg to recover premium received.
    """
    sto = Trade(
        account="Schwab Tax",
        date=date(2025, 8, 14),
        ticker="UUUU",
        action="Sell to Open",
        quantity=Decimal("1"),
        proceeds=Decimal("120"),
        cost_basis=Decimal("0"),
        option_details=OptionDetails(strike=Decimal("5"), expiry=date(2025, 9, 19), call_put="P"),
        basis_source="option_short_open",
    )
    btc_assigned = Trade(
        account="Schwab Tax",
        date=date(2025, 9, 19),
        ticker="UUUU",
        action="Buy to Close",
        quantity=Decimal("1"),
        proceeds=Decimal("0"),
        cost_basis=Decimal("0"),
        option_details=OptionDetails(strike=Decimal("5"), expiry=date(2025, 9, 19), call_put="P"),
        basis_source="option_short_close_assigned",
    )
    assigned_buy = Trade(
        account="Schwab Tax",
        date=date(2025, 9, 19),
        ticker="UUUU",
        action="Buy",
        quantity=Decimal("100"),
        proceeds=Decimal("0"),
        cost_basis=Decimal("380"),  # 5*100 - 120 = 380 (basis already premium-reduced)
        basis_source="option_short_open_assigned",
    )

    origin = extract_premium_origin(
        lot_trade=assigned_buy,
        all_trades=[sto, btc_assigned, assigned_buy],
    )
    assert isinstance(origin, CSPAssigned)
    assert origin.premium_received == Decimal("120")
    assert origin.strike == Decimal("5")
    assert origin.option_natural_key == "UUUU 09/19/2025 5.00 P"


def test_extract_premium_origin_returns_none_for_normal_buy() -> None:
    normal_buy = Trade(
        account="Schwab Tax",
        date=date(2025, 1, 1),
        ticker="AAPL",
        action="Buy",
        quantity=Decimal("100"),
        proceeds=Decimal("0"),
        cost_basis=Decimal("15000"),
        basis_source="unknown",
    )
    assert extract_premium_origin(normal_buy, []) is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_tax_planner_wheel.py -v`
Expected: FAIL — `cannot import 'extract_premium_origin'`

- [ ] **Step 3: Create `src/net_alpha/portfolio/tax_planner.py`**

```python
"""Forward tax planner — harvest queue, offset budget, projection, traffic light.

All compute is pure-function over Repository / PricingService reads. No DB writes.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel

from net_alpha.models.domain import Trade


class CSPAssigned(BaseModel):
    """Origin event for a long-stock lot acquired via cash-secured-put assignment."""

    kind: Literal["csp_assigned"] = "csp_assigned"
    option_natural_key: str  # e.g. "UUUU 09/19/2025 5.00 P"
    premium_received: Decimal
    strike: Decimal
    assignment_date: date


class CCAssigned(BaseModel):
    """Origin event for a stock SELL caused by covered-call assignment."""

    kind: Literal["cc_assigned"] = "cc_assigned"
    option_natural_key: str
    premium_received: Decimal
    strike: Decimal
    assignment_date: date


PremiumOriginEvent = CSPAssigned | CCAssigned


def _option_natural_key(t: Trade) -> str | None:
    od = t.option_details
    if od is None:
        return None
    cp = od.call_put.upper()
    return f"{t.ticker} {od.expiry.strftime('%m/%d/%Y')} {od.strike:.2f} {cp}"


def extract_premium_origin(
    lot_trade: Trade,
    all_trades: list[Trade],
) -> PremiumOriginEvent | None:
    """Recover the premium-origin event for a lot, if any.

    Looks at *lot_trade.basis_source*:
      - "option_short_open_assigned": Buy from CSP assignment. Premium = sum of STO
        proceeds minus BTC proceeds for the same option natural key, same account,
        on or before the assignment date.
      - Otherwise: returns None.
    """
    if lot_trade.basis_source != "option_short_open_assigned":
        return None

    # The synthetic Buy carries no option_details — recover them from any matching
    # STO/BTC chain by date+account+strike if the parser emitted hints, else by
    # finding the unique closed STO chain on the same date and account.
    candidates = [
        t for t in all_trades
        if t.account == lot_trade.account
        and t.ticker == lot_trade.ticker
        and t.option_details is not None
        and t.option_details.call_put.upper() == "P"
        and t.option_details.expiry == lot_trade.date
    ]
    if not candidates:
        return None

    # Group by option natural key; choose the chain that closes on lot_trade.date.
    by_key: dict[str, list[Trade]] = {}
    for t in candidates:
        key = _option_natural_key(t)
        if key:
            by_key.setdefault(key, []).append(t)

    chosen_key: str | None = None
    chosen_chain: list[Trade] = []
    for key, chain in by_key.items():
        has_assigned_close = any(t.basis_source == "option_short_close_assigned" for t in chain)
        if has_assigned_close:
            chosen_key = key
            chosen_chain = chain
            break

    if chosen_key is None:
        return None

    sto_proceeds = sum(
        (t.proceeds for t in chosen_chain if t.basis_source == "option_short_open"),
        start=Decimal("0"),
    )
    btc_proceeds = sum(
        (t.proceeds for t in chosen_chain if t.basis_source == "option_short_close_assigned"),
        start=Decimal("0"),
    )
    premium = sto_proceeds - btc_proceeds

    sample = chosen_chain[0].option_details
    assert sample is not None
    return CSPAssigned(
        option_natural_key=chosen_key,
        premium_received=premium,
        strike=sample.strike,
        assignment_date=lot_trade.date,
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/portfolio/test_tax_planner_wheel.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_wheel.py
git commit -m "feat(tax): premium origin extraction for CSP-assigned lots"
```

---

### Task 5: `compute_lockout_clear_date()` — same-symbol baseline

**Files:**
- Create: `src/net_alpha/engine/lockout.py`
- Create: `tests/engine/test_lockout.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/engine/test_lockout.py
from datetime import date
from decimal import Decimal

import pytest

from net_alpha.engine.lockout import compute_lockout_clear_date
from net_alpha.models.domain import Trade


def _buy(account: str, ticker: str, on: date, qty: int = 10) -> Trade:
    return Trade(
        account=account, date=on, ticker=ticker, action="Buy",
        quantity=Decimal(qty), proceeds=Decimal("0"), cost_basis=Decimal(qty * 10),
    )


def test_no_recent_buys_returns_none() -> None:
    assert compute_lockout_clear_date(
        symbol="AAPL", account="Schwab Tax",
        all_trades=[],
        as_of=date(2026, 5, 1),
        etf_pairs={},
    ) is None


def test_recent_buy_extends_lockout_30_days() -> None:
    buy = _buy("Schwab Tax", "AAPL", date(2026, 4, 15))
    clear = compute_lockout_clear_date(
        symbol="AAPL", account="Schwab Tax",
        all_trades=[buy],
        as_of=date(2026, 5, 1),
        etf_pairs={},
    )
    # 31 days after the most recent buy (day 0 is buy date; sale on day 31 is safe).
    assert clear == date(2026, 5, 16)


def test_buy_in_substantially_identical_pair_extends_lockout() -> None:
    buy = _buy("Schwab Tax", "VOO", date(2026, 4, 15))
    clear = compute_lockout_clear_date(
        symbol="SPY", account="Schwab Tax",
        all_trades=[buy],
        as_of=date(2026, 5, 1),
        etf_pairs={"S&P 500": ["SPY", "VOO", "IVV", "SPLG"]},
    )
    assert clear == date(2026, 5, 16)


def test_cross_account_buy_also_locks_out() -> None:
    buy = _buy("Fidelity Tax", "AAPL", date(2026, 4, 15))
    clear = compute_lockout_clear_date(
        symbol="AAPL", account="Schwab Tax",
        all_trades=[buy],
        as_of=date(2026, 5, 1),
        etf_pairs={},
    )
    # Wash-sale rules apply across accounts of the same taxpayer.
    assert clear == date(2026, 5, 16)


def test_old_buy_ignored() -> None:
    buy = _buy("Schwab Tax", "AAPL", date(2026, 1, 1))
    clear = compute_lockout_clear_date(
        symbol="AAPL", account="Schwab Tax",
        all_trades=[buy],
        as_of=date(2026, 5, 1),
        etf_pairs={},
    )
    assert clear is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/engine/test_lockout.py -v`
Expected: FAIL — module does not exist.

- [ ] **Step 3: Implement `compute_lockout_clear_date`**

```python
# src/net_alpha/engine/lockout.py
"""Forward lockout-clear-date computation for the harvest queue and traffic light.

A symbol is "in lockout" if a closing sale at a loss today would trigger a wash-sale
violation under IRS Pub 550 §1091. The lockout-clear date is the first date on which
such a sale would be safe given the most recent qualifying buy in the past 30 days.
"""

from __future__ import annotations

from datetime import date, timedelta

from net_alpha.models.domain import Trade

WASH_SALE_WINDOW_DAYS = 30
_BUY_ACTIONS = {"Buy", "Buy to Open"}


def _substantially_identical(symbol: str, etf_pairs: dict[str, list[str]]) -> set[str]:
    """Symbols treated as substantially identical to *symbol* per etf_pairs."""
    related = {symbol}
    for group_members in etf_pairs.values():
        if symbol in group_members:
            related.update(group_members)
    return related


def compute_lockout_clear_date(
    symbol: str,
    account: str,
    all_trades: list[Trade],
    as_of: date,
    etf_pairs: dict[str, list[str]],
) -> date | None:
    """Earliest date a sale of *symbol* in *account* will be wash-sale-clear.

    Returns None when no qualifying buy in the past 30 days exists (already clear).

    Cross-account buys also lock out (wash-sale rules apply across the taxpayer's
    accounts). Substantially-identical symbols (per etf_pairs) extend the lockout.
    """
    related = _substantially_identical(symbol, etf_pairs)
    cutoff = as_of - timedelta(days=WASH_SALE_WINDOW_DAYS)

    most_recent: date | None = None
    for t in all_trades:
        if t.action not in _BUY_ACTIONS:
            continue
        if t.option_details is not None:
            continue  # option opens handled by the cross-asset extension (Task 6).
        if t.ticker not in related:
            continue
        if t.date < cutoff or t.date > as_of:
            continue
        if most_recent is None or t.date > most_recent:
            most_recent = t.date

    if most_recent is None:
        return None
    return most_recent + timedelta(days=WASH_SALE_WINDOW_DAYS + 1)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/engine/test_lockout.py -v`
Expected: PASS (5 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/lockout.py tests/engine/test_lockout.py
git commit -m "feat(engine): same-symbol lockout-clear date computation"
```

---

### Task 6: Cross-asset lockout extension (option ↔ underlying)

**Files:**
- Modify: `src/net_alpha/engine/lockout.py`
- Modify: `tests/engine/test_lockout.py`

- [ ] **Step 1: Add the failing test**

Append to `tests/engine/test_lockout.py`:

```python
def test_open_csp_locks_out_stock_loss_close() -> None:
    """Selling a put (CSP open) creates a wash-sale exposure for the underlying.

    Closing the underlying stock at a loss within 30 days of an open short put on
    the same name is a wash sale. This is the key wheel-strategy pitfall.
    """
    sto = Trade(
        account="Schwab Tax", date=date(2026, 4, 15),
        ticker="UUUU", action="Sell to Open",
        quantity=Decimal("1"),
        proceeds=Decimal("60"), cost_basis=Decimal("0"),
        basis_source="option_short_open",
    )
    # Patch in OptionDetails so the trade looks like a real put.
    from net_alpha.models.domain import OptionDetails
    sto = sto.model_copy(update={"option_details": OptionDetails(
        strike=Decimal("5"), expiry=date(2026, 5, 16), call_put="P",
    )})
    clear = compute_lockout_clear_date(
        symbol="UUUU", account="Schwab Tax",
        all_trades=[sto],
        as_of=date(2026, 4, 20),
        etf_pairs={},
    )
    assert clear == date(2026, 5, 16)


def test_long_call_open_does_not_lock_out_underlying() -> None:
    from net_alpha.models.domain import OptionDetails
    bto = Trade(
        account="Schwab Tax", date=date(2026, 4, 15),
        ticker="UUUU", action="Buy to Open",
        quantity=Decimal("1"),
        proceeds=Decimal("0"), cost_basis=Decimal("60"),
        option_details=OptionDetails(
            strike=Decimal("8"), expiry=date(2026, 5, 16), call_put="C",
        ),
        basis_source="option_long_open",
    )
    clear = compute_lockout_clear_date(
        symbol="UUUU", account="Schwab Tax",
        all_trades=[bto],
        as_of=date(2026, 4, 20),
        etf_pairs={},
    )
    # A long call open is NOT substantially identical to the underlying for §1091
    # purposes (call long is not auto-deemed S/I; we conservatively excluded it).
    assert clear is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/engine/test_lockout.py -v`
Expected: FAIL — CSP test returns None; option opens are skipped.

- [ ] **Step 3: Extend `compute_lockout_clear_date`**

Replace the option skip in the loop. After the existing same-symbol block, add a second pass that checks short-put opens (CSPs) on the same underlying:

```python
_OPTION_OPEN_ACTIONS = {"Sell to Open", "Buy to Open"}


def _csp_open_locks_underlying(t: Trade, symbol: str) -> bool:
    """A short-put open (CSP) on *symbol* extends wash-sale lockout for the stock.

    Closing the underlying at a loss while a CSP is open on the same name creates
    a wash-sale violation. (Long calls are NOT treated as substantially identical.)
    """
    if t.option_details is None:
        return False
    if t.action != "Sell to Open":
        return False
    if t.option_details.call_put.upper() != "P":
        return False
    return t.ticker == symbol
```

In `compute_lockout_clear_date`, after the existing loop, add:

```python
    for t in all_trades:
        if t.option_details is None:
            continue
        if not _csp_open_locks_underlying(t, symbol):
            continue
        if t.date < cutoff or t.date > as_of:
            continue
        if most_recent is None or t.date > most_recent:
            most_recent = t.date

    if most_recent is None:
        return None
    return most_recent + timedelta(days=WASH_SALE_WINDOW_DAYS + 1)
```

(Remove the duplicate trailing return; consolidate into a single tail.)

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/engine/test_lockout.py -v`
Expected: PASS (7 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/engine/lockout.py tests/engine/test_lockout.py
git commit -m "feat(engine): cross-asset lockout — open CSP locks out underlying"
```

---

## Section C — 2a Harvest queue

### Task 7: `HarvestOpportunity` model

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Create: `tests/portfolio/conftest.py` (extend if exists)
- Create: `tests/portfolio/test_tax_planner_harvest.py` (start)

- [ ] **Step 1: Define the model + write a constructor smoke test**

```python
# tests/portfolio/test_tax_planner_harvest.py
from datetime import date
from decimal import Decimal

from net_alpha.portfolio.tax_planner import HarvestOpportunity


def test_harvest_opportunity_minimal() -> None:
    opp = HarvestOpportunity(
        symbol="UUUU",
        account_id=1,
        account_label="Schwab Tax",
        qty=Decimal("100"),
        loss=Decimal("-220"),
        lt_st="ST",
        lockout_clear=None,
        premium_offset=None,
        premium_origin_event=None,
        suggested_replacements=[],
    )
    assert opp.symbol == "UUUU"
    assert opp.loss < 0
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_tax_planner_harvest.py -v`
Expected: FAIL — `HarvestOpportunity` not defined.

- [ ] **Step 3: Add the model to `tax_planner.py`**

```python
class HarvestOpportunity(BaseModel):
    """One open lot at unrealized loss, eligible for tax-loss harvesting."""

    symbol: str
    account_id: int
    account_label: str
    qty: Decimal
    loss: Decimal  # negative (open_basis - market_value, signed loss)
    lt_st: Literal["LT", "ST"]
    lockout_clear: date | None
    premium_offset: Decimal | None  # absolute amount of premium received from origin event
    premium_origin_event: PremiumOriginEvent | None
    suggested_replacements: list[str]
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/portfolio/test_tax_planner_harvest.py -v`
Expected: PASS (1 test)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_harvest.py
git commit -m "feat(tax): HarvestOpportunity model"
```

---

### Task 8: `compute_harvest_queue()` — happy path with LT/ST split

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Modify: `tests/portfolio/test_tax_planner_harvest.py`

- [ ] **Step 1: Add the failing tests**

Append to `tests/portfolio/test_tax_planner_harvest.py`:

```python
from datetime import timedelta
from unittest.mock import Mock

from net_alpha.models.domain import Trade
from net_alpha.portfolio.tax_planner import compute_harvest_queue


class _StubPricing:
    def __init__(self, prices: dict[str, Decimal]) -> None:
        self._p = prices

    def get_prices(self, symbols):
        from net_alpha.pricing.provider import Quote
        from datetime import datetime
        out = {}
        for s in symbols:
            if s in self._p:
                out[s] = Quote(symbol=s, price=self._p[s], as_of=datetime.now(), source="stub")
        return out


def test_compute_harvest_queue_returns_only_losses(repo, schwab_account, seed_import) -> None:
    today = date(2026, 5, 1)
    # Two buys: AAPL at 200 (will be at gain), UUUU at 6 (will be at loss).
    aapl_buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=60),
        ticker="AAPL", action="Buy",
        quantity=Decimal("10"), proceeds=Decimal("0"), cost_basis=Decimal("2000"),
    )
    uuuu_buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [aapl_buy, uuuu_buy])

    pricing = _StubPricing({"AAPL": Decimal("250"), "UUUU": Decimal("4")})
    rows = compute_harvest_queue(
        repo=repo,
        pricing=pricing,
        as_of=today,
        etf_pairs={},
        etf_replacements={},
    )
    symbols = [r.symbol for r in rows]
    assert symbols == ["UUUU"]  # AAPL is at gain, excluded.
    assert rows[0].loss == Decimal("-200")  # 100 * (4 - 6)
    assert rows[0].lt_st == "ST"  # 10 days < 365


def test_compute_harvest_queue_lt_classification(repo, schwab_account, seed_import) -> None:
    today = date(2026, 5, 1)
    long_buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=400),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [long_buy])

    pricing = _StubPricing({"UUUU": Decimal("4")})
    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  etf_pairs={}, etf_replacements={})
    assert rows[0].lt_st == "LT"


def test_compute_harvest_queue_excludes_when_pricing_unavailable(repo, schwab_account, seed_import) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    pricing = _StubPricing({})  # No prices.
    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  etf_pairs={}, etf_replacements={})
    assert rows == []


def test_compute_harvest_queue_filter_account(repo, schwab_account, seed_import) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    pricing = _StubPricing({"UUUU": Decimal("4")})

    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  account_id=schwab_account.id,
                                  etf_pairs={}, etf_replacements={})
    assert len(rows) == 1
    other_id = schwab_account.id + 999
    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  account_id=other_id,
                                  etf_pairs={}, etf_replacements={})
    assert rows == []
```

- [ ] **Step 2: Reuse the audit conftest fixtures**

In `tests/portfolio/conftest.py`, add (or extend if file exists):

```python
"""Shared fixtures for portfolio.tax_planner tests."""
import pytest
from tests.audit.conftest import repo, schwab_account, seed_import  # re-export
__all__ = ["repo", "schwab_account", "seed_import"]
```

Confirm `tests/audit/conftest.py` defines all three; if `seed_import` is a function, re-export it as a fixture by wrapping:

```python
@pytest.fixture
def seed_import():
    from tests.audit.conftest import seed_import as _impl
    return _impl
```

(Match the existing pattern from `tests/audit/conftest.py`; if `seed_import` is already a fixture, the re-export is a no-op.)

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_tax_planner_harvest.py -v`
Expected: FAIL — `compute_harvest_queue` not defined.

- [ ] **Step 4: Implement `compute_harvest_queue`**

Append to `src/net_alpha/portfolio/tax_planner.py`:

```python
from net_alpha.db.repository import Repository
from net_alpha.engine.lockout import compute_lockout_clear_date
from net_alpha.models.domain import Lot
from net_alpha.portfolio.positions import consume_lots_fifo
from net_alpha.pricing.service import PricingService

LT_HOLDING_DAYS = 365  # tax long-term threshold (>365 days held)


def _account_lookup(repo: Repository) -> dict[str, int]:
    return {a.display(): a.id for a in repo.list_accounts() if a.id is not None}


def _open_lots_with_loss(
    repo: Repository,
    pricing: PricingService,
    as_of: date,
    account_id: int | None,
) -> list[tuple[Lot, Decimal, Decimal, Decimal]]:
    """Return (lot, remaining_qty, remaining_basis, market_value) for open loss lots.

    Filters out gains. Filters out lots without a current price.
    """
    lots = repo.all_lots()
    trades = repo.all_trades()
    gl_eq = repo.get_equity_gl_closures()
    gl_opt = repo.get_option_gl_closures()
    consumed = consume_lots_fifo(lots, trades, gl_closures=gl_eq, gl_option_closures=gl_opt)

    accounts = _account_lookup(repo)
    candidates = []
    symbols = sorted({lot.ticker for (lot, qty, _basis) in consumed if qty > 0 and lot.option_details is None})
    quotes = pricing.get_prices(symbols)

    for lot, remaining_qty, remaining_basis in consumed:
        if remaining_qty <= 0:
            continue
        if lot.option_details is not None:
            continue  # harvest queue is equity-only in v1.
        if account_id is not None and accounts.get(lot.account) != account_id:
            continue
        quote = quotes.get(lot.ticker)
        if quote is None:
            continue
        market_value = Decimal(remaining_qty) * quote.price
        if market_value >= remaining_basis:
            continue  # at gain or flat; not a harvest target.
        candidates.append((lot, Decimal(remaining_qty), remaining_basis, market_value))
    return candidates


def compute_harvest_queue(
    repo: Repository,
    pricing: PricingService,
    as_of: date,
    etf_pairs: dict[str, list[str]],
    etf_replacements: dict[str, list[str]],
    account_id: int | None = None,
    only_harvestable: bool = False,
) -> list[HarvestOpportunity]:
    """Open lots at unrealized loss, sortable, with lockout-clear date and premium offset.

    Pure read. Returns rows sorted by absolute loss descending.
    """
    candidates = _open_lots_with_loss(repo, pricing, as_of, account_id)
    accounts = _account_lookup(repo)
    inverse_accounts = {v: k for k, v in accounts.items()}
    all_trades = repo.all_trades()

    rows: list[HarvestOpportunity] = []
    for lot, qty, basis, market_value in candidates:
        loss = market_value - basis
        days_held = (as_of - lot.date).days
        lt_st: Literal["LT", "ST"] = "LT" if days_held > LT_HOLDING_DAYS else "ST"
        clear = compute_lockout_clear_date(
            symbol=lot.ticker, account=lot.account,
            all_trades=all_trades, as_of=as_of, etf_pairs=etf_pairs,
        )
        if only_harvestable and clear is not None:
            continue

        # Premium offset: only meaningful if origin trade is a CSP-assigned buy.
        # Recover the originating Trade by lot.trade_id.
        origin_event: PremiumOriginEvent | None = None
        premium_offset: Decimal | None = None
        for t in all_trades:
            if t.id is not None and lot.trade_id is not None and str(t.id) == str(lot.trade_id):
                origin_event = extract_premium_origin(t, all_trades)
                if origin_event is not None:
                    premium_offset = origin_event.premium_received
                break

        rows.append(HarvestOpportunity(
            symbol=lot.ticker,
            account_id=accounts.get(lot.account, 0),
            account_label=lot.account,
            qty=qty,
            loss=loss,
            lt_st=lt_st,
            lockout_clear=clear,
            premium_offset=premium_offset,
            premium_origin_event=origin_event,
            suggested_replacements=list(etf_replacements.get(lot.ticker, [])),
        ))

    rows.sort(key=lambda r: r.loss)  # most-negative first
    return rows
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/portfolio/test_tax_planner_harvest.py -v`
Expected: PASS (5 tests including model test from Task 7)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_harvest.py \
        tests/portfolio/conftest.py
git commit -m "feat(tax): compute_harvest_queue with LT/ST split + account filter"
```

---

### Task 9: Harvest queue — premium offset wiring + only_harvestable filter

**Files:**
- Modify: `tests/portfolio/test_tax_planner_harvest.py`

- [ ] **Step 1: Add focused tests**

Append:

```python
def test_compute_harvest_queue_premium_offset_for_csp_assigned(
    repo, schwab_account, seed_import,
) -> None:
    """An assigned-put origin lot carries the premium_offset back through to the row."""
    today = date(2026, 5, 1)
    from net_alpha.models.domain import OptionDetails
    sto = Trade(
        account=schwab_account.display(), date=date(2025, 8, 14),
        ticker="UUUU", action="Sell to Open",
        quantity=Decimal("1"), proceeds=Decimal("120"), cost_basis=Decimal("0"),
        option_details=OptionDetails(strike=Decimal("5"), expiry=date(2025, 9, 19), call_put="P"),
        basis_source="option_short_open",
    )
    btc = Trade(
        account=schwab_account.display(), date=date(2025, 9, 19),
        ticker="UUUU", action="Buy to Close",
        quantity=Decimal("1"), proceeds=Decimal("0"), cost_basis=Decimal("0"),
        option_details=OptionDetails(strike=Decimal("5"), expiry=date(2025, 9, 19), call_put="P"),
        basis_source="option_short_close_assigned",
    )
    assigned_buy = Trade(
        account=schwab_account.display(), date=date(2025, 9, 19),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("380"),  # 5*100 - 120
        basis_source="option_short_open_assigned",
    )
    seed_import(repo, schwab_account, [sto, btc, assigned_buy])

    pricing = _StubPricing({"UUUU": Decimal("3")})
    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  etf_pairs={}, etf_replacements={})
    assert len(rows) == 1
    assert rows[0].premium_offset == Decimal("120")
    assert rows[0].premium_origin_event is not None


def test_only_harvestable_filter_excludes_locked_positions(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    # Recent buy ⇒ symbol still locked out.
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=5),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    pricing = _StubPricing({"UUUU": Decimal("4")})
    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  etf_pairs={}, etf_replacements={},
                                  only_harvestable=True)
    assert rows == []
    rows = compute_harvest_queue(repo=repo, pricing=pricing, as_of=today,
                                  etf_pairs={}, etf_replacements={},
                                  only_harvestable=False)
    assert len(rows) == 1
    assert rows[0].lockout_clear is not None
```

- [ ] **Step 2: Run test to verify both pass**

Run: `uv run pytest tests/portfolio/test_tax_planner_harvest.py -v`
Expected: PASS (7 tests). The implementation from Task 8 already supports both behaviors; this task validates them explicitly.

- [ ] **Step 3: Commit**

```bash
git add tests/portfolio/test_tax_planner_harvest.py
git commit -m "test(tax): premium offset and only_harvestable filter coverage"
```

---

### Task 10: Harvest queue — replacement suggestion test

**Files:**
- Modify: `tests/portfolio/test_tax_planner_harvest.py`

- [ ] **Step 1: Add the test**

Append:

```python
def test_suggested_replacements_populated_from_dict(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="SPY", action="Buy",
        quantity=Decimal("10"), proceeds=Decimal("0"), cost_basis=Decimal("4500"),
    )
    seed_import(repo, schwab_account, [buy])
    pricing = _StubPricing({"SPY": Decimal("400")})
    rows = compute_harvest_queue(
        repo=repo, pricing=pricing, as_of=today,
        etf_pairs={}, etf_replacements={"SPY": ["VTI", "SCHB"]},
    )
    assert rows[0].suggested_replacements == ["VTI", "SCHB"]


def test_suggested_replacements_empty_when_no_entry(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    pricing = _StubPricing({"UUUU": Decimal("4")})
    rows = compute_harvest_queue(
        repo=repo, pricing=pricing, as_of=today,
        etf_pairs={}, etf_replacements={"SPY": ["VTI"]},
    )
    assert rows[0].suggested_replacements == []
```

- [ ] **Step 2: Run tests**

Run: `uv run pytest tests/portfolio/test_tax_planner_harvest.py -v`
Expected: PASS (9 tests)

- [ ] **Step 3: Commit**

```bash
git add tests/portfolio/test_tax_planner_harvest.py
git commit -m "test(tax): replacement-suggestion wiring in harvest queue"
```

---

### Task 11: `_harvest_queue.html` template

**Files:**
- Create: `src/net_alpha/web/templates/_harvest_queue.html`
- Create: `tests/web/test_harvest_queue_render.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_harvest_queue_render.py
from datetime import date
from decimal import Decimal

from jinja2 import Environment, FileSystemLoader, select_autoescape

from net_alpha.portfolio.tax_planner import CSPAssigned, HarvestOpportunity


def _env():
    return Environment(
        loader=FileSystemLoader("src/net_alpha/web/templates"),
        autoescape=select_autoescape(),
    )


def test_harvest_queue_renders_loss_amounts() -> None:
    rows = [
        HarvestOpportunity(
            symbol="UUUU", account_id=1, account_label="Schwab Tax",
            qty=Decimal("100"), loss=Decimal("-220"), lt_st="ST",
            lockout_clear=None, premium_offset=None, premium_origin_event=None,
            suggested_replacements=[],
        )
    ]
    env = _env()
    out = env.get_template("_harvest_queue.html").render(rows=rows, only_harvestable=False)
    assert "UUUU" in out
    assert "-$220" in out or "$-220" in out or "-220" in out
    assert "ST" in out


def test_harvest_queue_renders_lockout_clear_when_present() -> None:
    rows = [
        HarvestOpportunity(
            symbol="UUUU", account_id=1, account_label="Schwab Tax",
            qty=Decimal("100"), loss=Decimal("-220"), lt_st="ST",
            lockout_clear=date(2026, 5, 16),
            premium_offset=None, premium_origin_event=None,
            suggested_replacements=[],
        )
    ]
    out = _env().get_template("_harvest_queue.html").render(rows=rows, only_harvestable=False)
    assert "2026-05-16" in out


def test_harvest_queue_renders_premium_offset_for_csp_origin() -> None:
    rows = [
        HarvestOpportunity(
            symbol="UUUU", account_id=1, account_label="Schwab Tax",
            qty=Decimal("100"), loss=Decimal("-220"), lt_st="ST",
            lockout_clear=None,
            premium_offset=Decimal("120"),
            premium_origin_event=CSPAssigned(
                option_natural_key="UUUU 09/19/2025 5.00 P",
                premium_received=Decimal("120"),
                strike=Decimal("5"),
                assignment_date=date(2025, 9, 19),
            ),
            suggested_replacements=[],
        )
    ]
    out = _env().get_template("_harvest_queue.html").render(rows=rows, only_harvestable=False)
    assert "CSP" in out or "premium" in out.lower()
    assert "120" in out


def test_harvest_queue_empty_state() -> None:
    out = _env().get_template("_harvest_queue.html").render(rows=[], only_harvestable=False)
    assert "no harvest" in out.lower() or "no losses" in out.lower() or "nothing" in out.lower()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_harvest_queue_render.py -v`
Expected: FAIL — template missing.

- [ ] **Step 3: Create the template**

```html
{# src/net_alpha/web/templates/_harvest_queue.html #}
<section class="harvest-queue">
  <div class="filters">
    <label>
      <input type="checkbox" name="only_harvestable" {% if only_harvestable %}checked{% endif %}
        hx-get="/tax?view=harvest" hx-target="#tab-content" hx-trigger="change">
      Currently harvestable only
    </label>
  </div>
  {% if rows %}
  <table class="harvest-table">
    <thead>
      <tr>
        <th>Symbol</th>
        <th>Loss</th>
        <th>LT/ST</th>
        <th>Account</th>
        <th>Lockout-clear</th>
        <th>Premium offset</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {% for row in rows %}
      <tr>
        <td>{{ row.symbol }}</td>
        <td class="loss">${{ "%.2f"|format(row.loss) }}</td>
        <td><span class="badge badge-{{ row.lt_st|lower }}">{{ row.lt_st }}</span></td>
        <td>{{ row.account_label }}</td>
        <td>
          {% if row.lockout_clear %}<span class="locked">{{ row.lockout_clear }}</span>
          {% else %}<span class="clear">clear</span>{% endif %}
        </td>
        <td>
          {% if row.premium_offset %}
            <span class="premium">−${{ "%.2f"|format(row.premium_offset) }}
              {% if row.premium_origin_event %}
                <span class="muted">CSP premium received {{ row.premium_origin_event.assignment_date }}</span>
              {% endif %}
            </span>
          {% else %}<span class="muted">—</span>{% endif %}
        </td>
        <td>
          <a href="/sim?ticker={{ row.symbol }}&qty={{ row.qty }}" class="btn">Simulate harvest</a>
          {% if row.suggested_replacements %}
            <details class="replacements">
              <summary>Replacements</summary>
              <ul>
                {% for r in row.suggested_replacements %}
                  <li>{{ r }} <span class="muted">— discuss with CPA</span></li>
                {% endfor %}
              </ul>
            </details>
          {% endif %}
        </td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
  {% else %}
  <p class="empty">No harvest opportunities — all open positions are at gain or flat.</p>
  {% endif %}
</section>
```

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/web/test_harvest_queue_render.py -v`
Expected: PASS (4 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/templates/_harvest_queue.html tests/web/test_harvest_queue_render.py
git commit -m "feat(web): _harvest_queue.html template"
```

---

## Section D — 2b Offset budget

### Task 12: `OffsetBudget` + `PlannedTrade` models

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Create: `tests/portfolio/test_tax_planner_offset.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/portfolio/test_tax_planner_offset.py
from datetime import date
from decimal import Decimal

from net_alpha.portfolio.tax_planner import OffsetBudget, PlannedTrade


def test_offset_budget_constructs() -> None:
    b = OffsetBudget(
        year=2026, realized_losses_ytd=Decimal("-1000"), realized_gains_ytd=Decimal("500"),
        net_realized=Decimal("-500"), used_against_ordinary=Decimal("500"),
        carryforward_projection=Decimal("0"), planned_delta=Decimal("0"),
    )
    assert b.cap_against_ordinary == Decimal("3000")  # default


def test_planned_trade_constructs() -> None:
    pt = PlannedTrade(
        symbol="UUUU", account_id=1, action="Sell",
        qty=Decimal("100"), price=Decimal("4"),
        on=date(2026, 6, 1),
    )
    assert pt.action == "Sell"
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/portfolio/test_tax_planner_offset.py -v`
Expected: FAIL — models not defined.

- [ ] **Step 3: Add models to `tax_planner.py`**

```python
class PlannedTrade(BaseModel):
    """Transient struct: a hypothetical sell/buy that hasn't been imported yet.

    Used by the harvest queue 'Mark planned' action and by the traffic light.
    Stored only in the user's localStorage for the session.
    """

    symbol: str
    account_id: int
    action: Literal["Buy", "Sell"]
    qty: Decimal
    price: Decimal
    on: date


class OffsetBudget(BaseModel):
    """YTD realized loss vs the $3,000-against-ordinary-income cap."""

    year: int
    realized_losses_ytd: Decimal  # signed (negative magnitude)
    realized_gains_ytd: Decimal  # positive
    net_realized: Decimal  # gains + losses (signed)
    cap_against_ordinary: Decimal = Decimal("3000")
    used_against_ordinary: Decimal  # min(|net_loss|, cap), >= 0
    carryforward_projection: Decimal  # |net_loss| - cap, clamped to >= 0
    planned_delta: Decimal  # change in net_realized that would result from planned_trades
```

- [ ] **Step 4: Run test to verify passing**

Run: `uv run pytest tests/portfolio/test_tax_planner_offset.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_offset.py
git commit -m "feat(tax): OffsetBudget and PlannedTrade models"
```

---

### Task 13: `compute_offset_budget()` pure function

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Modify: `tests/portfolio/test_tax_planner_offset.py`

- [ ] **Step 1: Add failing tests**

Append:

```python
from datetime import timedelta

from net_alpha.models.domain import Trade
from net_alpha.portfolio.tax_planner import compute_offset_budget


def test_compute_offset_budget_no_trades(repo) -> None:
    b = compute_offset_budget(repo=repo, year=2026)
    assert b.realized_losses_ytd == Decimal("0")
    assert b.realized_gains_ytd == Decimal("0")
    assert b.net_realized == Decimal("0")
    assert b.used_against_ordinary == Decimal("0")
    assert b.carryforward_projection == Decimal("0")


def test_compute_offset_budget_aggregates_realized_in_year(
    repo, schwab_account, seed_import,
) -> None:
    # Buy at 100, Sell at 80 -> $20 loss in 2026.
    # Buy at 100, Sell at 130 -> $30 gain in 2026.
    buys = [
        Trade(account=schwab_account.display(), date=date(2026, 1, 5),
              ticker="UUUU", action="Buy", quantity=Decimal("1"),
              proceeds=Decimal("0"), cost_basis=Decimal("100")),
        Trade(account=schwab_account.display(), date=date(2026, 1, 5),
              ticker="AAPL", action="Buy", quantity=Decimal("1"),
              proceeds=Decimal("0"), cost_basis=Decimal("100")),
    ]
    sells = [
        Trade(account=schwab_account.display(), date=date(2026, 3, 1),
              ticker="UUUU", action="Sell", quantity=Decimal("1"),
              proceeds=Decimal("80"), cost_basis=Decimal("100")),
        Trade(account=schwab_account.display(), date=date(2026, 4, 1),
              ticker="AAPL", action="Sell", quantity=Decimal("1"),
              proceeds=Decimal("130"), cost_basis=Decimal("100")),
    ]
    seed_import(repo, schwab_account, buys + sells)
    b = compute_offset_budget(repo=repo, year=2026)
    assert b.realized_losses_ytd == Decimal("-20")
    assert b.realized_gains_ytd == Decimal("30")
    assert b.net_realized == Decimal("10")
    assert b.used_against_ordinary == Decimal("0")  # net is positive


def test_compute_offset_budget_clamps_loss_at_3000_cap(
    repo, schwab_account, seed_import,
) -> None:
    # Loss of $5,000 against zero gains.
    buy = Trade(account=schwab_account.display(), date=date(2026, 1, 5),
                ticker="UUUU", action="Buy", quantity=Decimal("100"),
                proceeds=Decimal("0"), cost_basis=Decimal("10000"))
    sell = Trade(account=schwab_account.display(), date=date(2026, 3, 1),
                 ticker="UUUU", action="Sell", quantity=Decimal("100"),
                 proceeds=Decimal("5000"), cost_basis=Decimal("10000"))
    seed_import(repo, schwab_account, [buy, sell])
    b = compute_offset_budget(repo=repo, year=2026)
    assert b.realized_losses_ytd == Decimal("-5000")
    assert b.used_against_ordinary == Decimal("3000")
    assert b.carryforward_projection == Decimal("2000")


def test_compute_offset_budget_planned_trades_shift_delta(
    repo, schwab_account, seed_import,
) -> None:
    buy = Trade(account=schwab_account.display(), date=date(2026, 1, 5),
                ticker="UUUU", action="Buy", quantity=Decimal("100"),
                proceeds=Decimal("0"), cost_basis=Decimal("1000"))
    seed_import(repo, schwab_account, [buy])
    planned = [PlannedTrade(
        symbol="UUUU", account_id=schwab_account.id or 0,
        action="Sell", qty=Decimal("100"), price=Decimal("8"),
        on=date(2026, 6, 1),
    )]
    b = compute_offset_budget(repo=repo, year=2026, planned_trades=planned)
    # Planned: sell 100 at 8 vs basis 10/sh = -200 realized.
    assert b.planned_delta == Decimal("-200")
```

- [ ] **Step 2: Run test to verify failure**

Run: `uv run pytest tests/portfolio/test_tax_planner_offset.py -v`
Expected: FAIL — `compute_offset_budget` not defined.

- [ ] **Step 3: Implement `compute_offset_budget`**

Append to `tax_planner.py`:

```python
def _realized_in_year(repo: Repository, year: int) -> tuple[Decimal, Decimal]:
    """Return (gross_losses_ytd_signed_negative, gross_gains_ytd_positive)."""
    losses = Decimal("0")
    gains = Decimal("0")
    for t in repo.all_trades():
        if t.action.lower() not in {"sell", "sell to close"}:
            continue
        if t.date.year != year:
            continue
        pnl = t.proceeds - t.cost_basis
        if pnl < 0:
            losses += pnl
        else:
            gains += pnl
    return losses, gains


def _planned_pnl(planned_trades: list[PlannedTrade], repo: Repository) -> Decimal:
    """Best-effort realized delta: for each planned sell, compute (price - avg_basis) * qty.

    Uses repo.get_lots_for_ticker to derive average basis at the planning moment.
    """
    delta = Decimal("0")
    for p in planned_trades:
        if p.action != "Sell":
            continue
        lots = repo.get_lots_for_ticker(p.symbol)
        # Approximate: weighted-average adjusted basis across the open lots.
        total_qty = sum((Decimal(l.quantity) for l in lots), Decimal("0"))
        if total_qty <= 0:
            continue
        total_basis = sum(
            (Decimal(l.adjusted_basis) for l in lots), Decimal("0"),
        )
        avg_basis = total_basis / total_qty
        delta += (p.price - avg_basis) * p.qty
    return delta


def compute_offset_budget(
    repo: Repository,
    year: int,
    planned_trades: list[PlannedTrade] | None = None,
) -> OffsetBudget:
    """YTD realized P&L vs the $3,000-against-ordinary cap, optionally with planned trades.

    Pure read. Cap is fixed at $3,000 (single/MFJ; same for these in v1).
    """
    losses, gains = _realized_in_year(repo, year)
    net = losses + gains
    cap = Decimal("3000")
    used = Decimal("0")
    carry = Decimal("0")
    if net < 0:
        used = min(-net, cap)
        carry = max(-net - cap, Decimal("0"))
    planned_delta = _planned_pnl(planned_trades or [], repo)

    return OffsetBudget(
        year=year,
        realized_losses_ytd=losses,
        realized_gains_ytd=gains,
        net_realized=net,
        cap_against_ordinary=cap,
        used_against_ordinary=used,
        carryforward_projection=carry,
        planned_delta=planned_delta,
    )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/portfolio/test_tax_planner_offset.py -v`
Expected: PASS (6 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_offset.py
git commit -m "feat(tax): compute_offset_budget with $3K cap + carryforward + planned delta"
```

---

### Task 14: `_offset_budget_tile.html` + portfolio embed

**Files:**
- Create: `src/net_alpha/web/templates/_offset_budget_tile.html`
- Modify: `src/net_alpha/web/templates/_portfolio_kpis.html`
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `tests/web/test_offset_budget_render.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_offset_budget_render.py
from decimal import Decimal

from jinja2 import Environment, FileSystemLoader, select_autoescape

from net_alpha.portfolio.tax_planner import OffsetBudget


def _env():
    return Environment(
        loader=FileSystemLoader("src/net_alpha/web/templates"),
        autoescape=select_autoescape(),
    )


def test_offset_budget_tile_renders_progress() -> None:
    b = OffsetBudget(
        year=2026, realized_losses_ytd=Decimal("-1420"), realized_gains_ytd=Decimal("0"),
        net_realized=Decimal("-1420"), used_against_ordinary=Decimal("1420"),
        carryforward_projection=Decimal("0"), planned_delta=Decimal("0"),
    )
    out = _env().get_template("_offset_budget_tile.html").render(budget=b)
    assert "1,420" in out or "1420" in out
    assert "3,000" in out or "3000" in out
    assert "47" in out  # 1420/3000 ≈ 47%


def test_offset_budget_tile_shows_carryforward() -> None:
    b = OffsetBudget(
        year=2026, realized_losses_ytd=Decimal("-5000"), realized_gains_ytd=Decimal("0"),
        net_realized=Decimal("-5000"), used_against_ordinary=Decimal("3000"),
        carryforward_projection=Decimal("2000"), planned_delta=Decimal("0"),
    )
    out = _env().get_template("_offset_budget_tile.html").render(budget=b)
    assert "2,000" in out or "2000" in out
    assert "carryforward" in out.lower()


def test_offset_budget_tile_zero_state_friendly() -> None:
    b = OffsetBudget(
        year=2026, realized_losses_ytd=Decimal("0"), realized_gains_ytd=Decimal("0"),
        net_realized=Decimal("0"), used_against_ordinary=Decimal("0"),
        carryforward_projection=Decimal("0"), planned_delta=Decimal("0"),
    )
    out = _env().get_template("_offset_budget_tile.html").render(budget=b)
    assert "0" in out
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/web/test_offset_budget_render.py -v`
Expected: FAIL — template missing.

- [ ] **Step 3: Create the template**

```html
{# src/net_alpha/web/templates/_offset_budget_tile.html #}
<div class="kpi-tile offset-budget">
  <div class="kpi-label">Loss harvested YTD</div>
  <div class="kpi-value">
    ${{ "{:,.0f}".format(budget.used_against_ordinary) }}
    <span class="muted">of ${{ "{:,.0f}".format(budget.cap_against_ordinary) }} cap</span>
  </div>
  {% set pct = (budget.used_against_ordinary / budget.cap_against_ordinary * 100) if budget.cap_against_ordinary else 0 %}
  <div class="progress" role="progressbar"
       aria-valuenow="{{ pct|round(0,'floor') }}" aria-valuemin="0" aria-valuemax="100">
    <div class="bar" style="width: {{ pct|round(0,'floor') }}%"></div>
    <span class="pct">{{ pct|round(0,'floor') }}%</span>
  </div>
  <div class="carryforward">
    Carryforward projection:
    ${{ "{:,.0f}".format(budget.carryforward_projection) }}
  </div>
</div>
```

- [ ] **Step 4: Embed in portfolio**

In `src/net_alpha/web/templates/_portfolio_kpis.html`, after the existing wash-impact tile, add:

```html
{% if offset_budget is defined and offset_budget %}
  {% include "_offset_budget_tile.html" with context %}
{% endif %}
```

In `src/net_alpha/web/routes/portfolio.py`, in the `kpis` route, compute and pass `offset_budget`:

```python
from datetime import date

from net_alpha.portfolio.tax_planner import compute_offset_budget

# ... inside the kpis route, after existing context build:
offset_budget = compute_offset_budget(repo=repo, year=date.today().year)
ctx["offset_budget"] = offset_budget
```

- [ ] **Step 5: Run tests**

Run: `uv run pytest tests/web/test_offset_budget_render.py tests/web/test_portfolio*.py -v`
Expected: PASS — render tests pass; existing portfolio route tests unaffected (offset_budget always present).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_offset_budget_tile.html \
        src/net_alpha/web/templates/_portfolio_kpis.html \
        src/net_alpha/web/routes/portfolio.py \
        tests/web/test_offset_budget_render.py
git commit -m "feat(web): offset-budget tile on portfolio KPI strip"
```

---

## Section E — 2c Year-end projection

### Task 15: `TaxBrackets` + `TaxProjection` models + `MissingTaxConfig`

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Create: `tests/portfolio/test_tax_planner_projection.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/portfolio/test_tax_planner_projection.py
from decimal import Decimal

import pytest

from net_alpha.portfolio.tax_planner import (
    MissingTaxConfig,
    TaxBrackets,
    TaxProjection,
    project_year_end_tax,
)


def test_tax_brackets_construct() -> None:
    b = TaxBrackets(
        filing_status="single", state="CA",
        federal_marginal_rate=Decimal("0.32"),
        state_marginal_rate=Decimal("0.093"),
        ltcg_rate=Decimal("0.15"),
        qualified_div_rate=Decimal("0.15"),
    )
    assert b.filing_status == "single"


def test_missing_tax_config_raises_when_brackets_none(repo) -> None:
    with pytest.raises(MissingTaxConfig):
        project_year_end_tax(repo=repo, year=2026, brackets=None)
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/portfolio/test_tax_planner_projection.py -v`
Expected: FAIL — types not defined.

- [ ] **Step 3: Add to `tax_planner.py`**

```python
class MissingTaxConfig(Exception):
    """Raised by project_year_end_tax when no TaxBrackets provided."""


class TaxBrackets(BaseModel):
    """Single-marginal-rate tax inputs (loaded from config.yaml `tax:` section)."""

    filing_status: Literal["single", "mfj", "mfs", "hoh"]
    state: str  # ISO; "" for federal-only
    federal_marginal_rate: Decimal
    state_marginal_rate: Decimal
    ltcg_rate: Decimal
    qualified_div_rate: Decimal


class TaxProjection(BaseModel):
    """Single-marginal-rate year-end estimate. NOT a tax return."""

    year: int
    realized_st_gain: Decimal  # signed
    realized_lt_gain: Decimal  # signed
    qualified_div: Decimal
    ordinary_div: Decimal
    interest_income: Decimal
    federal_tax: Decimal
    state_tax: Decimal
    total_tax: Decimal
    bracket_warnings: list[str] = []
```

- [ ] **Step 4: Add a stub `project_year_end_tax` that raises if no brackets**

```python
def project_year_end_tax(
    repo: Repository,
    year: int,
    brackets: TaxBrackets | None,
    planned_trades: list[PlannedTrade] | None = None,
) -> TaxProjection:
    if brackets is None:
        raise MissingTaxConfig("TaxBrackets required; set tax: section in config.yaml")
    raise NotImplementedError  # filled in Task 16
```

- [ ] **Step 5: Run test to verify passing**

Run: `uv run pytest tests/portfolio/test_tax_planner_projection.py -v`
Expected: PASS (2 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_projection.py
git commit -m "feat(tax): TaxBrackets, TaxProjection, MissingTaxConfig"
```

---

### Task 16: `project_year_end_tax()` — base computation

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Modify: `tests/portfolio/test_tax_planner_projection.py`

- [ ] **Step 1: Add failing tests**

Append:

```python
from datetime import date, timedelta

from net_alpha.models.domain import Trade


_BRACKETS = TaxBrackets(
    filing_status="single", state="CA",
    federal_marginal_rate=Decimal("0.32"),
    state_marginal_rate=Decimal("0.093"),
    ltcg_rate=Decimal("0.15"),
    qualified_div_rate=Decimal("0.15"),
)


def test_projection_zero_when_no_realized(repo) -> None:
    p = project_year_end_tax(repo=repo, year=2026, brackets=_BRACKETS)
    assert p.realized_st_gain == 0
    assert p.realized_lt_gain == 0
    assert p.federal_tax == 0
    assert p.state_tax == 0
    assert p.total_tax == 0


def test_projection_short_term_gain_taxed_ordinary_plus_state(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(account=schwab_account.display(), date=today - timedelta(days=10),
                ticker="UUUU", action="Buy", quantity=Decimal("1"),
                proceeds=Decimal("0"), cost_basis=Decimal("100"))
    sell = Trade(account=schwab_account.display(), date=today,
                 ticker="UUUU", action="Sell", quantity=Decimal("1"),
                 proceeds=Decimal("200"), cost_basis=Decimal("100"))
    seed_import(repo, schwab_account, [buy, sell])

    p = project_year_end_tax(repo=repo, year=2026, brackets=_BRACKETS)
    assert p.realized_st_gain == Decimal("100")
    # Federal: 100 * 0.32 = 32. State: 100 * 0.093 = 9.30.
    assert p.federal_tax == Decimal("32.00")
    assert p.state_tax == Decimal("9.30")
    assert p.total_tax == Decimal("41.30")


def test_projection_long_term_gain_taxed_ltcg_rate(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(account=schwab_account.display(), date=today - timedelta(days=400),
                ticker="UUUU", action="Buy", quantity=Decimal("1"),
                proceeds=Decimal("0"), cost_basis=Decimal("100"))
    sell = Trade(account=schwab_account.display(), date=today,
                 ticker="UUUU", action="Sell", quantity=Decimal("1"),
                 proceeds=Decimal("200"), cost_basis=Decimal("100"))
    seed_import(repo, schwab_account, [buy, sell])

    p = project_year_end_tax(repo=repo, year=2026, brackets=_BRACKETS)
    assert p.realized_lt_gain == Decimal("100")
    # Federal: 100 * 0.15 = 15. State: 100 * 0.093 = 9.30.
    assert p.federal_tax == Decimal("15.00")
    assert p.state_tax == Decimal("9.30")
```

- [ ] **Step 2: Run to verify failures**

Run: `uv run pytest tests/portfolio/test_tax_planner_projection.py -v`
Expected: FAIL — NotImplementedError.

- [ ] **Step 3: Implement projection**

(`LT_HOLDING_DAYS` was added in Task 8 — reuse it.) Replace the stub in `tax_planner.py`:

```python
def _classify_st_lt_gains(repo: Repository, year: int) -> tuple[Decimal, Decimal]:
    """Return (st_gain, lt_gain) — both signed, by sell-trade holding period."""
    st = Decimal("0")
    lt = Decimal("0")
    # Build a buy index by (account, ticker) for FIFO holding-period lookup.
    buys: dict[tuple[str, str], list[Trade]] = {}
    for t in repo.all_trades():
        if t.action.lower() in {"buy", "buy to open"} and t.option_details is None:
            buys.setdefault((t.account, t.ticker), []).append(t)
    for chain in buys.values():
        chain.sort(key=lambda x: x.date)

    for sell in repo.all_trades():
        if sell.action.lower() not in {"sell"}:
            continue
        if sell.option_details is not None:
            continue
        if sell.date.year != year:
            continue
        chain = buys.get((sell.account, sell.ticker), [])
        if not chain:
            # No buy chain visible — treat conservatively as ST.
            st += sell.proceeds - sell.cost_basis
            continue
        oldest_buy_date = chain[0].date
        days_held = (sell.date - oldest_buy_date).days
        pnl = sell.proceeds - sell.cost_basis
        if days_held > LT_HOLDING_DAYS:
            lt += pnl
        else:
            st += pnl
    return st, lt


def _quantize(d: Decimal) -> Decimal:
    return d.quantize(Decimal("0.01"))


def project_year_end_tax(
    repo: Repository,
    year: int,
    brackets: TaxBrackets | None,
    planned_trades: list[PlannedTrade] | None = None,
) -> TaxProjection:
    if brackets is None:
        raise MissingTaxConfig("TaxBrackets required; set tax: section in config.yaml")

    st, lt = _classify_st_lt_gains(repo, year)

    # Cash events: dividends and interest only contribute to projection if positive.
    qualified_div = Decimal("0")
    ordinary_div = Decimal("0")
    interest_income = Decimal("0")
    for ev in repo.list_cash_events():
        if ev.event_date.year != year:
            continue
        kind = (ev.kind or "").lower()
        amt = Decimal(ev.amount)
        if amt <= 0:
            continue
        if "qualified" in kind:
            qualified_div += amt
        elif "dividend" in kind:
            ordinary_div += amt
        elif "interest" in kind:
            interest_income += amt

    federal = Decimal("0")
    state = Decimal("0")
    if st > 0:
        federal += st * brackets.federal_marginal_rate
        state += st * brackets.state_marginal_rate
    if lt > 0:
        federal += lt * brackets.ltcg_rate
        state += lt * brackets.state_marginal_rate
    federal += qualified_div * brackets.qualified_div_rate
    state += qualified_div * brackets.state_marginal_rate
    federal += ordinary_div * brackets.federal_marginal_rate
    state += ordinary_div * brackets.state_marginal_rate
    federal += interest_income * brackets.federal_marginal_rate
    state += interest_income * brackets.state_marginal_rate

    return TaxProjection(
        year=year,
        realized_st_gain=st,
        realized_lt_gain=lt,
        qualified_div=qualified_div,
        ordinary_div=ordinary_div,
        interest_income=interest_income,
        federal_tax=_quantize(federal),
        state_tax=_quantize(state),
        total_tax=_quantize(federal + state),
        bracket_warnings=[],  # filled in Task 17
    )
```

- [ ] **Step 4: Run tests to verify pass**

Run: `uv run pytest tests/portfolio/test_tax_planner_projection.py -v`
Expected: PASS (5 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_projection.py
git commit -m "feat(tax): year-end tax projection (single marginal rate)"
```

---

### Task 17: Projection — bracket-push warnings + planned trades

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Modify: `tests/portfolio/test_tax_planner_projection.py`

- [ ] **Step 1: Add failing tests**

Append:

```python
def test_projection_planned_trade_increases_st_gain(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(account=schwab_account.display(), date=today - timedelta(days=10),
                ticker="UUUU", action="Buy", quantity=Decimal("100"),
                proceeds=Decimal("0"), cost_basis=Decimal("100"))
    seed_import(repo, schwab_account, [buy])
    planned = [PlannedTrade(
        symbol="UUUU", account_id=schwab_account.id or 0,
        action="Sell", qty=Decimal("100"), price=Decimal("3"),
        on=date(2026, 6, 1),
    )]
    p = project_year_end_tax(
        repo=repo, year=2026, brackets=_BRACKETS, planned_trades=planned,
    )
    # Planned -200 added to ST realized: 0 - 200 = -200; loss reduces tax to 0.
    assert p.realized_st_gain == Decimal("-200")
    assert p.federal_tax == Decimal("0")


def test_projection_emits_bracket_warning_when_st_swings_large(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(account=schwab_account.display(), date=today - timedelta(days=10),
                ticker="UUUU", action="Buy", quantity=Decimal("1"),
                proceeds=Decimal("0"), cost_basis=Decimal("1000"))
    sell = Trade(account=schwab_account.display(), date=today,
                 ticker="UUUU", action="Sell", quantity=Decimal("1"),
                 proceeds=Decimal("21000"), cost_basis=Decimal("1000"))
    seed_import(repo, schwab_account, [buy, sell])
    p = project_year_end_tax(repo=repo, year=2026, brackets=_BRACKETS)
    assert any("bracket" in w.lower() for w in p.bracket_warnings)
```

- [ ] **Step 2: Run to verify failures**

Run: `uv run pytest tests/portfolio/test_tax_planner_projection.py -v`
Expected: FAIL — planned not applied; no warnings.

- [ ] **Step 3: Extend projection**

In `project_year_end_tax`, after computing `st, lt`:

```python
    if planned_trades:
        for p in planned_trades:
            if p.action != "Sell":
                continue
            # Look up basis via the same helper used in offset budget.
            lots = repo.get_lots_for_ticker(p.symbol)
            total_qty = sum((Decimal(l.quantity) for l in lots), Decimal("0"))
            if total_qty <= 0:
                continue
            total_basis = sum((Decimal(l.adjusted_basis) for l in lots), Decimal("0"))
            avg_basis = total_basis / total_qty
            pnl = (p.price - avg_basis) * p.qty
            # Default conservatively to ST classification for planned trades.
            st += pnl
```

And before constructing the return value:

```python
    warnings_list: list[str] = []
    BRACKET_PUSH_THRESHOLD = Decimal("20000")
    if st > BRACKET_PUSH_THRESHOLD:
        warnings_list.append(
            f"Short-term gain of ${st:,.0f} may push you into a higher federal bracket."
        )
    if lt > BRACKET_PUSH_THRESHOLD:
        warnings_list.append(
            f"Long-term gain of ${lt:,.0f} may approach the 20% LTCG bracket boundary."
        )
```

Pass `bracket_warnings=warnings_list` into the `TaxProjection(...)` constructor.

- [ ] **Step 4: Run tests to verify**

Run: `uv run pytest tests/portfolio/test_tax_planner_projection.py -v`
Expected: PASS (7 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_projection.py
git commit -m "feat(tax): projection respects planned trades + bracket-push warnings"
```

---

### Task 18: `_projection_card.html` + portfolio embed

**Files:**
- Create: `src/net_alpha/web/templates/_projection_card.html`
- Modify: `src/net_alpha/web/templates/_portfolio_kpis.html`
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Modify: `src/net_alpha/web/app.py`
- Create: `tests/web/test_projection_render.py`

- [ ] **Step 1: Write failing test**

```python
# tests/web/test_projection_render.py
from decimal import Decimal

from jinja2 import Environment, FileSystemLoader, select_autoescape

from net_alpha.portfolio.tax_planner import TaxProjection


def _env():
    return Environment(
        loader=FileSystemLoader("src/net_alpha/web/templates"),
        autoescape=select_autoescape(),
    )


def test_projection_card_renders_total_and_breakdown() -> None:
    p = TaxProjection(
        year=2026,
        realized_st_gain=Decimal("10000"),
        realized_lt_gain=Decimal("0"),
        qualified_div=Decimal("0"),
        ordinary_div=Decimal("0"),
        interest_income=Decimal("0"),
        federal_tax=Decimal("3200"),
        state_tax=Decimal("930"),
        total_tax=Decimal("4130"),
    )
    out = _env().get_template("_projection_card.html").render(projection=p, has_tax_config=True)
    assert "4,130" in out
    assert "3,200" in out
    assert "930" in out


def test_projection_card_placeholder_when_config_missing() -> None:
    out = _env().get_template("_projection_card.html").render(projection=None, has_tax_config=False)
    assert "tax bracket" in out.lower() or "config" in out.lower()
    assert "/imports" in out
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/web/test_projection_render.py -v`
Expected: FAIL — template missing.

- [ ] **Step 3: Create template**

```html
{# src/net_alpha/web/templates/_projection_card.html #}
<div class="kpi-card projection-card">
  {% if has_tax_config and projection %}
    <div class="kpi-label">Projected {{ projection.year }} tax (Dec 31)</div>
    <div class="kpi-value">${{ "{:,.0f}".format(projection.total_tax) }}</div>
    <div class="breakdown">
      Federal: ${{ "{:,.0f}".format(projection.federal_tax) }}
      · State: ${{ "{:,.0f}".format(projection.state_tax) }}
    </div>
    {% if projection.bracket_warnings %}
      <ul class="bracket-warnings">
        {% for w in projection.bracket_warnings %}<li>{{ w }}</li>{% endfor %}
      </ul>
    {% endif %}
    <div class="caveat muted">Estimate only — single marginal rate.</div>
  {% else %}
    <div class="kpi-label">Year-end tax projection</div>
    <p class="placeholder">
      Set the <code>tax:</code> section in <code>~/.net_alpha/config.yaml</code>
      to enable the projection. <a href="/imports#tax-config">Open data hygiene</a>.
    </p>
  {% endif %}
</div>
```

- [ ] **Step 4: Wire in portfolio route**

The `app.state.tax_brackets_cfg` startup hook is added in Task 25 (consolidated with `etf_replacements`); skip the startup edit here. In `src/net_alpha/web/routes/portfolio.py` `kpis` route:

```python
from net_alpha.portfolio.tax_planner import (
    MissingTaxConfig, TaxBrackets, project_year_end_tax,
)

cfg = request.app.state.tax_brackets_cfg  # may be None
projection = None
if cfg is not None:
    brackets = TaxBrackets(
        filing_status=cfg.filing_status, state=cfg.state,
        federal_marginal_rate=cfg.federal_marginal_rate,
        state_marginal_rate=cfg.state_marginal_rate,
        ltcg_rate=cfg.ltcg_rate, qualified_div_rate=cfg.qualified_div_rate,
    )
    try:
        projection = project_year_end_tax(repo=repo, year=date.today().year, brackets=brackets)
    except MissingTaxConfig:
        projection = None
ctx["projection"] = projection
ctx["has_tax_config"] = cfg is not None
```

In `src/net_alpha/web/templates/_portfolio_kpis.html`, after the offset budget tile slot:

```html
{% include "_projection_card.html" with context %}
```

- [ ] **Step 5: Run tests**

Run: `uv run pytest tests/web/test_projection_render.py tests/web/test_portfolio*.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_projection_card.html \
        src/net_alpha/web/templates/_portfolio_kpis.html \
        src/net_alpha/web/routes/portfolio.py \
        src/net_alpha/web/app.py \
        tests/web/test_projection_render.py
git commit -m "feat(web): year-end projection card on portfolio (with config-missing placeholder)"
```

---

## Section F — 2d Pre-trade traffic light

### Task 19: `TaxLightSignal` model + reason codes

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Create: `tests/portfolio/test_tax_planner_traffic_light.py`

- [ ] **Step 1: Write failing test**

```python
# tests/portfolio/test_tax_planner_traffic_light.py
from datetime import date
from decimal import Decimal

from net_alpha.portfolio.tax_planner import TaxLightSignal


def test_tax_light_signal_constructs() -> None:
    s = TaxLightSignal(
        color="green", reason_codes=["LT_LOSS"],
        explanation="Tax-efficient — LT loss; offsets ST gains",
        suggestion=None, lot_method_recommended="HIFO",
    )
    assert s.color == "green"
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/portfolio/test_tax_planner_traffic_light.py -v`
Expected: FAIL — model missing.

- [ ] **Step 3: Add to `tax_planner.py`**

```python
class TaxLightSignal(BaseModel):
    """Traffic-light verdict for a hypothetical trade."""

    color: Literal["green", "yellow", "red"]
    reason_codes: list[str]
    explanation: str
    suggestion: str | None
    lot_method_recommended: Literal["FIFO", "HIFO", "LIFO"] | None
```

- [ ] **Step 4: Run test**

Run: `uv run pytest tests/portfolio/test_tax_planner_traffic_light.py -v`
Expected: PASS (1 test)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_traffic_light.py
git commit -m "feat(tax): TaxLightSignal model"
```

---

### Task 20: `assess_trade()` — wash-sale path (red)

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Modify: `tests/portfolio/test_tax_planner_traffic_light.py`

- [ ] **Step 1: Add failing test**

Append:

```python
from datetime import timedelta

from net_alpha.models.domain import Trade
from net_alpha.portfolio.tax_planner import (
    PlannedTrade, TaxBrackets, assess_trade,
)


def test_red_when_proposed_sell_triggers_wash(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    # Recent buy on UUUU within 30 days will lock the loss sale.
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    proposed = PlannedTrade(
        symbol="UUUU", account_id=schwab_account.id or 0,
        action="Sell", qty=Decimal("100"), price=Decimal("4"),
        on=today,
    )
    s = assess_trade(
        proposed=proposed, repo=repo, brackets=None, as_of=today, etf_pairs={},
    )
    assert s.color == "red"
    assert "WASH_RISK" in s.reason_codes
    assert "lockout" in (s.explanation or "").lower() or "wash" in (s.explanation or "").lower()


def test_green_when_no_loss_no_wash(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=400),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("100"),
    )
    seed_import(repo, schwab_account, [buy])
    proposed = PlannedTrade(
        symbol="UUUU", account_id=schwab_account.id or 0,
        action="Sell", qty=Decimal("100"), price=Decimal("8"),  # gain
        on=today,
    )
    s = assess_trade(
        proposed=proposed, repo=repo, brackets=None, as_of=today, etf_pairs={},
    )
    assert s.color == "green"
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/portfolio/test_tax_planner_traffic_light.py -v`
Expected: FAIL — `assess_trade` missing.

- [ ] **Step 3: Implement `assess_trade`**

Append to `tax_planner.py`:

```python
def _avg_basis(repo: Repository, symbol: str) -> Decimal | None:
    lots = repo.get_lots_for_ticker(symbol)
    total_qty = sum((Decimal(l.quantity) for l in lots), Decimal("0"))
    if total_qty <= 0:
        return None
    total_basis = sum((Decimal(l.adjusted_basis) for l in lots), Decimal("0"))
    return total_basis / total_qty


def assess_trade(
    proposed: PlannedTrade,
    repo: Repository,
    brackets: TaxBrackets | None,
    as_of: date,
    etf_pairs: dict[str, list[str]],
) -> TaxLightSignal:
    """Pre-trade traffic-light: green/yellow/red verdict with explanation."""
    if proposed.action != "Sell":
        return TaxLightSignal(
            color="green", reason_codes=["BUY"],
            explanation="Buy trades aren't tax-blocking on the sell side.",
            suggestion=None, lot_method_recommended=None,
        )

    avg_basis = _avg_basis(repo, proposed.symbol)
    pnl_per_share = (proposed.price - avg_basis) if avg_basis is not None else None
    is_loss = pnl_per_share is not None and pnl_per_share < 0

    if is_loss:
        clear = compute_lockout_clear_date(
            symbol=proposed.symbol, account="",  # cross-account check inside
            all_trades=repo.all_trades(),
            as_of=as_of, etf_pairs=etf_pairs,
        )
        if clear is not None and clear > as_of:
            return TaxLightSignal(
                color="red", reason_codes=["WASH_RISK"],
                explanation=(
                    f"Selling at a loss today triggers wash-sale lockout until "
                    f"{clear.isoformat()} due to a recent qualifying buy."
                ),
                suggestion=f"Delay sell until {clear.isoformat()} to avoid the lockout.",
                lot_method_recommended=None,
            )

    return TaxLightSignal(
        color="green", reason_codes=["CLEAR"],
        explanation="No wash-sale risk detected for this proposed sale.",
        suggestion=None,
        lot_method_recommended="HIFO" if is_loss else None,
    )
```

- [ ] **Step 4: Run test to verify**

Run: `uv run pytest tests/portfolio/test_tax_planner_traffic_light.py -v`
Expected: PASS (3 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_traffic_light.py
git commit -m "feat(tax): assess_trade — wash-sale red verdict"
```

---

### Task 21: `assess_trade()` — bracket-push yellow + lot-method recommendation

**Files:**
- Modify: `src/net_alpha/portfolio/tax_planner.py`
- Modify: `tests/portfolio/test_tax_planner_traffic_light.py`

- [ ] **Step 1: Add failing test**

Append:

```python
def test_yellow_when_proposed_sell_creates_large_st_gain(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=30),
        ticker="UUUU", action="Buy",
        quantity=Decimal("1"), proceeds=Decimal("0"), cost_basis=Decimal("1000"),
    )
    seed_import(repo, schwab_account, [buy])
    proposed = PlannedTrade(
        symbol="UUUU", account_id=schwab_account.id or 0,
        action="Sell", qty=Decimal("1"), price=Decimal("21000"),  # 20K gain
        on=today,
    )
    brackets = TaxBrackets(
        filing_status="single", state="CA",
        federal_marginal_rate=Decimal("0.32"),
        state_marginal_rate=Decimal("0.093"),
        ltcg_rate=Decimal("0.15"),
        qualified_div_rate=Decimal("0.15"),
    )
    s = assess_trade(
        proposed=proposed, repo=repo, brackets=brackets, as_of=today, etf_pairs={},
    )
    assert s.color == "yellow"
    assert any(c in s.reason_codes for c in ["ST_GAIN_BRACKET_PUSH", "LARGE_GAIN"])


def test_green_lot_method_HIFO_when_loss_clear(
    repo, schwab_account, seed_import,
) -> None:
    today = date(2026, 5, 1)
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=400),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    proposed = PlannedTrade(
        symbol="UUUU", account_id=schwab_account.id or 0,
        action="Sell", qty=Decimal("100"), price=Decimal("4"),  # loss but no recent buys
        on=today,
    )
    s = assess_trade(
        proposed=proposed, repo=repo, brackets=None, as_of=today, etf_pairs={},
    )
    assert s.color == "green"
    assert s.lot_method_recommended == "HIFO"
```

- [ ] **Step 2: Run to verify**

Run: `uv run pytest tests/portfolio/test_tax_planner_traffic_light.py -v`
Expected: FAIL — yellow path missing.

- [ ] **Step 3: Extend `assess_trade`**

In `assess_trade`, after the wash-risk red branch:

```python
    days_held: int | None = None
    if avg_basis is not None:
        # Estimate ST/LT by oldest open lot date.
        lots = repo.get_lots_for_ticker(proposed.symbol)
        if lots:
            oldest = min(lots, key=lambda l: l.date).date
            days_held = (as_of - oldest).days

    if pnl_per_share is not None and pnl_per_share > 0:
        gain = pnl_per_share * proposed.qty
        is_st = days_held is not None and days_held <= LT_HOLDING_DAYS
        BRACKET_PUSH_THRESHOLD = Decimal("20000")
        if gain > BRACKET_PUSH_THRESHOLD and is_st and brackets is not None:
            return TaxLightSignal(
                color="yellow", reason_codes=["ST_GAIN_BRACKET_PUSH"],
                explanation=(
                    f"Proposed sale would create a ${gain:,.0f} short-term gain "
                    "— may push you into a higher federal bracket."
                ),
                suggestion="Consider holding past the long-term threshold to switch to LTCG rate.",
                lot_method_recommended="FIFO",
            )
```

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/portfolio/test_tax_planner_traffic_light.py -v`
Expected: PASS (5 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/portfolio/tax_planner.py tests/portfolio/test_tax_planner_traffic_light.py
git commit -m "feat(tax): assess_trade — bracket-push yellow + lot-method hint"
```

---

### Task 22: `_traffic_light.html` + `/sim` route embed

**Files:**
- Create: `src/net_alpha/web/templates/_traffic_light.html`
- Modify: `src/net_alpha/web/templates/_sim_sell_result.html`
- Modify: `src/net_alpha/web/templates/_sim_buy_result.html`
- Modify: `src/net_alpha/web/routes/sim.py`
- Create: `tests/web/test_traffic_light_sim.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/web/test_traffic_light_sim.py
from datetime import date, timedelta
from decimal import Decimal

from net_alpha.models.domain import Trade


def test_sim_sell_post_shows_red_traffic_light_on_wash(
    client, repo, schwab_account, seed_import,
):
    today = date.today()
    buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600"),
    )
    seed_import(repo, schwab_account, [buy])
    resp = client.post(
        "/sim",
        data={
            "action": "sell", "ticker": "UUUU", "qty": "100", "price": "4",
            "account": schwab_account.display(),
            "trade_date": today.isoformat(),
        },
    )
    assert resp.status_code == 200
    assert "traffic-light" in resp.text or "Stop" in resp.text or "🔴" in resp.text


def test_sim_buy_post_shows_traffic_light_fragment(
    client, repo, schwab_account, seed_import,
):
    today = date.today()
    resp = client.post(
        "/sim",
        data={
            "action": "buy", "ticker": "UUUU", "qty": "10", "price": "5",
            "account": schwab_account.display(),
            "trade_date": today.isoformat(),
        },
    )
    assert resp.status_code == 200
    assert "traffic-light" in resp.text or "🟢" in resp.text
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/web/test_traffic_light_sim.py -v`
Expected: FAIL — fragment not rendered.

- [ ] **Step 3: Create `_traffic_light.html`**

```html
{# src/net_alpha/web/templates/_traffic_light.html #}
{% if signal %}
<div class="traffic-light traffic-light--{{ signal.color }}">
  <span class="dot" aria-hidden="true">
    {%- if signal.color == 'green' -%}🟢
    {%- elif signal.color == 'yellow' -%}🟡
    {%- else -%}🔴{%- endif -%}
  </span>
  <span class="explanation">{{ signal.explanation }}</span>
  {% if signal.suggestion %}
    <div class="suggestion">{{ signal.suggestion }}</div>
  {% endif %}
  {% if signal.lot_method_recommended %}
    <div class="muted">Lot method recommended: {{ signal.lot_method_recommended }}</div>
  {% endif %}
</div>
{% endif %}
```

- [ ] **Step 4: Embed in sim result templates**

At the very top of `_sim_sell_result.html` and `_sim_buy_result.html`:

```html
{% include "_traffic_light.html" with context %}
```

- [ ] **Step 5: Build the signal in `routes/sim.py`**

In the POST handler, after computing the simulation options, before rendering:

```python
from datetime import date as _date

from net_alpha.engine.etf_pairs import load_etf_pairs
from net_alpha.portfolio.tax_planner import (
    PlannedTrade, TaxBrackets, assess_trade,
)

# After parsing form fields:
account_id = 0  # display string look-up
for a in repo.list_accounts():
    if a.display() == account_str:
        account_id = a.id or 0
        break

planned = PlannedTrade(
    symbol=ticker.upper(), account_id=account_id, action="Sell" if action == "sell" else "Buy",
    qty=Decimal(qty), price=Decimal(price),
    on=_date.fromisoformat(trade_date) if trade_date else _date.today(),
)
cfg = request.app.state.tax_brackets_cfg
brackets = None
if cfg is not None:
    brackets = TaxBrackets(
        filing_status=cfg.filing_status, state=cfg.state,
        federal_marginal_rate=cfg.federal_marginal_rate,
        state_marginal_rate=cfg.state_marginal_rate,
        ltcg_rate=cfg.ltcg_rate, qualified_div_rate=cfg.qualified_div_rate,
    )
signal = assess_trade(
    proposed=planned, repo=repo, brackets=brackets,
    as_of=planned.on, etf_pairs=load_etf_pairs(settings.user_etf_pairs_path),
)
ctx["signal"] = signal
```

- [ ] **Step 6: Run tests**

Run: `uv run pytest tests/web/test_traffic_light_sim.py -v`
Expected: PASS (2 tests)

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/_traffic_light.html \
        src/net_alpha/web/templates/_sim_sell_result.html \
        src/net_alpha/web/templates/_sim_buy_result.html \
        src/net_alpha/web/routes/sim.py \
        tests/web/test_traffic_light_sim.py
git commit -m "feat(web): pre-trade traffic-light on /sim result"
```

---

## Section G — 2e Wheel awareness extension tests

The compute layer is already in Section B. These tests harden the cross-asset flows that are easy to regress.

### Task 23: Cross-asset lockout — close stock at loss locks new CSP

**Files:**
- Modify: `tests/portfolio/test_tax_planner_wheel.py`

- [ ] **Step 1: Add failing test**

Append:

```python
from datetime import timedelta

from net_alpha.engine.lockout import compute_lockout_clear_date
from net_alpha.models.domain import OptionDetails


def test_close_stock_at_loss_locks_out_new_csp_open(
    repo, schwab_account, seed_import,
) -> None:
    """
    Spec section 2e: closing assigned shares at a loss should lock out new CSP
    opens on the same underlying for 30 days.

    Test mechanism: a Sell-to-Open put trade today on UUUU is wash-sale-blocked
    if there's a stock-loss-close on UUUU within the past 30 days.

    The lockout function answers symmetrically: given the stock close as a
    'recent buy' analog won't trigger; instead we look at the proposed action
    via simulator. Here we verify via assess_trade.
    """
    today = date(2026, 5, 1)
    stock_buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=60),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("1000"),
    )
    stock_sell_at_loss = Trade(
        account=schwab_account.display(), date=today - timedelta(days=10),
        ticker="UUUU", action="Sell",
        quantity=Decimal("100"), proceeds=Decimal("400"), cost_basis=Decimal("1000"),
    )
    seed_import(repo, schwab_account, [stock_buy, stock_sell_at_loss])
    # Symmetric check: at this point a CSP open today on UUUU would be a wash-sale risk.
    # Currently `compute_lockout_clear_date` looks for forward locks of *new sells*; the
    # symmetric "blocked open" surfaces in the simulator. Verify via the lockout helper
    # that the open CSP detection sees the chain.
    proposed_csp = Trade(
        account=schwab_account.display(), date=today,
        ticker="UUUU", action="Sell to Open",
        quantity=Decimal("1"), proceeds=Decimal("60"), cost_basis=Decimal("0"),
        option_details=OptionDetails(
            strike=Decimal("5"), expiry=today + timedelta(days=30), call_put="P",
        ),
        basis_source="option_short_open",
    )
    # If we add the proposed CSP into all_trades, the lockout for UUUU stock should
    # have been re-extended (open CSP locks underlying).
    all_trades = [stock_buy, stock_sell_at_loss, proposed_csp]
    clear = compute_lockout_clear_date(
        symbol="UUUU", account=schwab_account.display(),
        all_trades=all_trades, as_of=today, etf_pairs={},
    )
    assert clear is not None
    assert clear == today + timedelta(days=31)
```

- [ ] **Step 2: Run to verify**

Run: `uv run pytest tests/portfolio/test_tax_planner_wheel.py -v`
Expected: PASS — already covered by Task 6's CSP-open extension.

- [ ] **Step 3: Commit**

```bash
git add tests/portfolio/test_tax_planner_wheel.py
git commit -m "test(tax): cross-asset wheel-strategy lockout coverage"
```

---

### Task 24: CSP-origin from synthetic trade chain — round-trip via Repository

**Files:**
- Modify: `tests/portfolio/test_tax_planner_wheel.py`

- [ ] **Step 1: Add the failing test**

Append:

```python
def test_csp_origin_round_trip_through_repo(
    repo, schwab_account, seed_import,
) -> None:
    """End-to-end: CSP chain seeded into repo, harvest queue surfaces premium."""
    today = date(2026, 5, 1)
    sto = Trade(
        account=schwab_account.display(), date=date(2025, 8, 14),
        ticker="UUUU", action="Sell to Open",
        quantity=Decimal("1"), proceeds=Decimal("120"), cost_basis=Decimal("0"),
        option_details=OptionDetails(
            strike=Decimal("5"), expiry=date(2025, 9, 19), call_put="P",
        ),
        basis_source="option_short_open",
    )
    btc = Trade(
        account=schwab_account.display(), date=date(2025, 9, 19),
        ticker="UUUU", action="Buy to Close",
        quantity=Decimal("1"), proceeds=Decimal("0"), cost_basis=Decimal("0"),
        option_details=OptionDetails(
            strike=Decimal("5"), expiry=date(2025, 9, 19), call_put="P",
        ),
        basis_source="option_short_close_assigned",
    )
    assigned = Trade(
        account=schwab_account.display(), date=date(2025, 9, 19),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("380"),
        basis_source="option_short_open_assigned",
    )
    seed_import(repo, schwab_account, [sto, btc, assigned])

    # Reload the assigned-buy trade from repo to confirm round-trip.
    all_t = repo.all_trades()
    assigned_buys = [t for t in all_t if t.basis_source == "option_short_open_assigned"]
    assert len(assigned_buys) == 1

    from net_alpha.portfolio.tax_planner import extract_premium_origin

    origin = extract_premium_origin(assigned_buys[0], all_t)
    assert origin is not None
    assert origin.premium_received == Decimal("120")
```

- [ ] **Step 2: Run**

Run: `uv run pytest tests/portfolio/test_tax_planner_wheel.py -v`
Expected: PASS

- [ ] **Step 3: Commit**

```bash
git add tests/portfolio/test_tax_planner_wheel.py
git commit -m "test(tax): CSP origin round-trips through Repository"
```

---

## Section H — 2f Replacements consumed in UI

Already wired into `compute_harvest_queue` (Task 8) and the template (Task 11). One remaining task:

### Task 25: Wire `etf_replacements` from app state into the harvest-queue route call

**Files:**
- Modify: `src/net_alpha/web/app.py`

- [ ] **Step 1: Load replacements at startup**

`app.state.etf_pairs` is already populated by the existing `app.py` (line ~26). Only `etf_replacements` and `tax_brackets_cfg` need to be added — and the existing pairs need to be re-used for the consistency check. Edit `src/net_alpha/web/app.py`, immediately after the existing `app.state.etf_pairs = load_etf_pairs(...)` line:

```python
from net_alpha.config import load_tax_config
from net_alpha.engine.etf_pairs import load_etf_replacements

app.state.etf_replacements = load_etf_replacements(
    user_path=settings.data_dir / "etf_replacements.yaml",
    etf_pairs=app.state.etf_pairs,
)
app.state.tax_brackets_cfg = load_tax_config(settings.config_yaml_path)
```

(The `tax_brackets_cfg` line replaces the standalone load_tax_config wiring referenced in Task 18 — keep this single startup hook as the source of truth.)

- [ ] **Step 2: Verify with quick smoke**

Run: `uv run pytest tests/web/ -v -k "test_phase1_smoke"`
Expected: PASS — no regression.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/app.py
git commit -m "feat(web): load etf_pairs and etf_replacements into app.state"
```

---

## Section I — Page rename + tabbed `/tax`

### Task 26: New `tax_routes.py` with tabbed dispatcher

**Files:**
- Create: `src/net_alpha/web/routes/tax.py`
- Modify: `src/net_alpha/web/app.py`
- Create: `tests/web/test_tax_route.py`

- [ ] **Step 1: Write failing test**

```python
# tests/web/test_tax_route.py
from datetime import date, timedelta
from decimal import Decimal

from net_alpha.models.domain import Trade


def test_get_tax_default_view_renders_wash_sales_tab(client, repo, schwab_account, seed_import):
    today = date.today()
    seed_import(repo, schwab_account, [
        Trade(account=schwab_account.display(), date=today - timedelta(days=10),
              ticker="UUUU", action="Buy",
              quantity=Decimal("10"), proceeds=Decimal("0"), cost_basis=Decimal("100")),
    ])
    resp = client.get("/tax")
    assert resp.status_code == 200
    body = resp.text
    assert "Tax" in body
    assert "Wash sales" in body or "wash-sales" in body.lower()


def test_get_tax_view_harvest_renders_harvest_queue(
    client, repo, schwab_account, seed_import,
):
    today = date.today()
    seed_import(repo, schwab_account, [
        Trade(account=schwab_account.display(), date=today - timedelta(days=10),
              ticker="UUUU", action="Buy",
              quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("600")),
    ])
    resp = client.get("/tax?view=harvest")
    assert resp.status_code == 200
    assert "harvest" in resp.text.lower()


def test_get_tax_view_budget_renders_offset_budget(client, repo, schwab_account, seed_import):
    resp = client.get("/tax?view=budget")
    assert resp.status_code == 200
    assert "harvested" in resp.text.lower() or "cap" in resp.text.lower()


def test_get_tax_view_projection_renders_card_or_placeholder(client):
    resp = client.get("/tax?view=projection")
    assert resp.status_code == 200
    assert "projection" in resp.text.lower() or "tax bracket" in resp.text.lower()
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/web/test_tax_route.py -v`
Expected: FAIL — `/tax` not registered.

- [ ] **Step 3: Create `tax.py`**

Match the existing FastAPI wiring (verified by reading `src/net_alpha/web/dependencies.py`): dep helpers are `get_repository`, `get_pricing_service`, `get_etf_pairs`, `get_settings`. Templates are obtained from `request.app.state.templates`, not via a dependency.

```python
# src/net_alpha/web/routes/tax.py
from __future__ import annotations

from datetime import date
from typing import Literal

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse

from net_alpha.db.repository import Repository
from net_alpha.portfolio.tax_planner import (
    MissingTaxConfig, TaxBrackets,
    compute_harvest_queue, compute_offset_budget, project_year_end_tax,
)
from net_alpha.pricing.service import PricingService
from net_alpha.web.dependencies import (
    get_etf_pairs, get_pricing_service, get_repository,
)

router = APIRouter()


@router.get("/tax", response_class=HTMLResponse)
def get_tax(
    request: Request,
    view: Literal["wash-sales", "harvest", "budget", "projection"] = "wash-sales",
    account: str | None = None,
    year: int | None = None,
    repo: Repository = Depends(get_repository),
    pricing: PricingService = Depends(get_pricing_service),
    etf_pairs: dict[str, list[str]] = Depends(get_etf_pairs),
):
    """Tabbed tax page. Replaces /wash-sales — preserves existing wash-sales UI as default tab."""
    today = date.today()
    ctx: dict = {
        "request": request,
        "view": view,
        "active_page": "tax",
        "selected_account": account,
        "selected_year": year,
    }

    if view == "wash-sales":
        # Reuse the legacy wash-sales context-builder (extracted to a helper).
        from net_alpha.web.routes.wash_sales import _wash_sales_context

        ctx.update(_wash_sales_context(repo=repo, account=account, year=year))
    elif view == "harvest":
        rows = compute_harvest_queue(
            repo=repo, pricing=pricing, as_of=today,
            etf_pairs=etf_pairs,
            etf_replacements=request.app.state.etf_replacements,
        )
        ctx["harvest_rows"] = rows
        ctx["only_harvestable"] = False
    elif view == "budget":
        ctx["budget"] = compute_offset_budget(repo=repo, year=today.year)
    elif view == "projection":
        cfg = request.app.state.tax_brackets_cfg
        if cfg is not None:
            brackets = TaxBrackets(
                filing_status=cfg.filing_status, state=cfg.state,
                federal_marginal_rate=cfg.federal_marginal_rate,
                state_marginal_rate=cfg.state_marginal_rate,
                ltcg_rate=cfg.ltcg_rate, qualified_div_rate=cfg.qualified_div_rate,
            )
            try:
                ctx["projection"] = project_year_end_tax(
                    repo=repo, year=today.year, brackets=brackets,
                )
                ctx["has_tax_config"] = True
            except MissingTaxConfig:
                ctx["projection"] = None
                ctx["has_tax_config"] = False
        else:
            ctx["projection"] = None
            ctx["has_tax_config"] = False

    return request.app.state.templates.TemplateResponse(request, "tax.html", ctx)
```

- [ ] **Step 4: Extract `_wash_sales_context` helper**

In `src/net_alpha/web/routes/wash_sales.py`, expose the existing context builder as a helper without the route decorator. Keep the route decorator's body as a one-liner:

```python
def _wash_sales_context(repo: Repository, account: str | None = None, year: int | None = None,
                       ticker: str | None = None, confidence: str | None = None,
                       sort: str | None = None, order: str = "desc") -> dict:
    # ... move existing context-build code here, return ctx dict ...
```

(The current GET handler stays — see Task 28 — it returns the new redirect; the helper above is what `tax.py` invokes.)

- [ ] **Step 5: Register router in `app.py`**

In `app.py`:

```python
from net_alpha.web.routes import tax as tax_routes

app.include_router(tax_routes.router)
```

- [ ] **Step 6: Run tests**

Run: `uv run pytest tests/web/test_tax_route.py -v`
Expected: PASS — but template `tax.html` is missing; expect a separate template-not-found error. Proceed to Task 27.

If templates step fails before this, mark this task PASS-WITH-CONCERNS and proceed.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/tax.py src/net_alpha/web/routes/wash_sales.py \
        src/net_alpha/web/app.py tests/web/test_tax_route.py
git commit -m "feat(web): add /tax route with tabbed view dispatcher"
```

---

### Task 27: `tax.html` template with 4 tabs

**Files:**
- Create: `src/net_alpha/web/templates/tax.html`
- Create: `src/net_alpha/web/templates/_tax_wash_sales_tab.html`
- Create: `src/net_alpha/web/templates/_offset_budget_tab.html`
- Create: `src/net_alpha/web/templates/_projection_tab.html`

- [ ] **Step 1: Extract wash-sales tab content**

Move the existing inner content of `wash_sales.html` (the table+calendar block, NOT the page wrapper) into `_tax_wash_sales_tab.html`. Keep the `{% if view == "calendar" %} ... {% else %} ... {% endif %}` branches.

- [ ] **Step 2: Create `_offset_budget_tab.html`**

```html
{# src/net_alpha/web/templates/_offset_budget_tab.html #}
<section class="offset-budget-tab">
  <h2>Loss harvest budget — {{ budget.year }}</h2>
  {% include "_offset_budget_tile.html" with context %}
  <div class="details">
    <div>Realized losses YTD: ${{ "{:,.2f}".format(budget.realized_losses_ytd) }}</div>
    <div>Realized gains YTD: ${{ "{:,.2f}".format(budget.realized_gains_ytd) }}</div>
    <div>Net realized: ${{ "{:,.2f}".format(budget.net_realized) }}</div>
    {% if budget.planned_delta %}
      <div class="planned">
        Planned-trade delta: ${{ "{:,.2f}".format(budget.planned_delta) }}
      </div>
    {% endif %}
  </div>
</section>
```

- [ ] **Step 3: Create `_projection_tab.html`**

```html
{# src/net_alpha/web/templates/_projection_tab.html #}
<section class="projection-tab">
  {% include "_projection_card.html" with context %}
  {% if has_tax_config and projection %}
    <h3>Breakdown</h3>
    <dl>
      <dt>Short-term gain</dt><dd>${{ "{:,.2f}".format(projection.realized_st_gain) }}</dd>
      <dt>Long-term gain</dt><dd>${{ "{:,.2f}".format(projection.realized_lt_gain) }}</dd>
      <dt>Qualified div</dt><dd>${{ "{:,.2f}".format(projection.qualified_div) }}</dd>
      <dt>Ordinary div</dt><dd>${{ "{:,.2f}".format(projection.ordinary_div) }}</dd>
      <dt>Interest income</dt><dd>${{ "{:,.2f}".format(projection.interest_income) }}</dd>
    </dl>
  {% endif %}
</section>
```

- [ ] **Step 4: Create `tax.html` wrapper**

```html
{# src/net_alpha/web/templates/tax.html #}
{% extends "base.html" %}
{% block content %}
<div class="tax-page">
  <h1>Tax</h1>
  <nav class="tabs" role="tablist">
    {% set tabs = [
      ("wash-sales","Wash sales"),
      ("harvest","Harvest queue"),
      ("budget","Offset budget"),
      ("projection","Projection"),
    ] %}
    {% for slug, label in tabs %}
      <a role="tab"
         class="tab {% if view == slug %}tab--active{% endif %}"
         href="/tax?view={{ slug }}{% if selected_account %}&account={{ selected_account }}{% endif %}">
        {{ label }}
      </a>
    {% endfor %}
  </nav>
  <div id="tab-content" class="tab-content" role="tabpanel">
    {% if view == "wash-sales" %}
      {% include "_tax_wash_sales_tab.html" with context %}
    {% elif view == "harvest" %}
      {% set rows = harvest_rows %}
      {% include "_harvest_queue.html" with context %}
    {% elif view == "budget" %}
      {% include "_offset_budget_tab.html" with context %}
    {% elif view == "projection" %}
      {% include "_projection_tab.html" with context %}
    {% endif %}
  </div>
</div>
{% endblock %}
```

- [ ] **Step 5: Run tax-route tests**

Run: `uv run pytest tests/web/test_tax_route.py -v`
Expected: PASS (4 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/tax.html \
        src/net_alpha/web/templates/_tax_wash_sales_tab.html \
        src/net_alpha/web/templates/_offset_budget_tab.html \
        src/net_alpha/web/templates/_projection_tab.html
git commit -m "feat(web): tax.html 4-tab page (wash-sales | harvest | budget | projection)"
```

---

### Task 28: 301 redirects from `/wash-sales` to `/tax`

**Files:**
- Modify: `src/net_alpha/web/routes/wash_sales.py`
- Create: `tests/web/test_tax_redirects.py`

- [ ] **Step 1: Write failing test**

```python
# tests/web/test_tax_redirects.py
def test_wash_sales_redirects_to_tax(client):
    resp = client.get("/wash-sales", follow_redirects=False)
    assert resp.status_code == 301
    assert resp.headers["location"].startswith("/tax")


def test_wash_sales_preserves_query_string(client):
    resp = client.get("/wash-sales?account=Schwab%20Tax&year=2025", follow_redirects=False)
    assert resp.status_code == 301
    loc = resp.headers["location"]
    assert "view=wash-sales" in loc
    assert "account=Schwab" in loc
    assert "year=2025" in loc


def test_wash_sales_calendar_redirects_with_view_param(client):
    resp = client.get("/wash-sales?view=calendar", follow_redirects=False)
    assert resp.status_code == 301
    assert "/tax?view=calendar" in resp.headers["location"]
```

- [ ] **Step 2: Run to verify failure**

Run: `uv run pytest tests/web/test_tax_redirects.py -v`
Expected: FAIL — current `/wash-sales` returns 200.

- [ ] **Step 3: Replace the route body with a redirect**

In `src/net_alpha/web/routes/wash_sales.py`, replace the GET handler:

```python
from urllib.parse import urlencode

from fastapi.responses import RedirectResponse


@router.get("/wash-sales")
def wash_sales_legacy(request: Request) -> RedirectResponse:
    """301 redirect — /wash-sales has been renamed to /tax (Phase 2)."""
    qs = dict(request.query_params)
    if "view" not in qs:
        qs["view"] = "wash-sales"
    return RedirectResponse(url="/tax?" + urlencode(qs), status_code=301)
```

(Keep `_wash_sales_context` and the `/detail`, `/calendar`, `/wash-sales/focus/...` routes intact; they still produce inline fragments needed by `_tax_wash_sales_tab.html`.)

- [ ] **Step 4: Run tests**

Run: `uv run pytest tests/web/test_tax_redirects.py tests/web/test_wash_sales*.py -v`
Expected: PASS (redirects pass; existing wash-sales fragment routes unaffected).

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/wash_sales.py tests/web/test_tax_redirects.py
git commit -m "feat(web): /wash-sales -> /tax 301 redirect (preserves query string)"
```

---

### Task 29: Update `base.html` nav

**Files:**
- Modify: `src/net_alpha/web/templates/base.html`
- Modify: `tests/web/test_phase1_smoke.py` (if it references "Wash sales" link text)

- [ ] **Step 1: Locate and update the nav link**

In `src/net_alpha/web/templates/base.html`, change:

```html
<a href="/wash-sales" class="nav-link {% if active_page == 'wash-sales' %}nav-link--active{% endif %}">Wash sales</a>
```

to:

```html
<a href="/tax" class="nav-link {% if active_page == 'tax' %}nav-link--active{% endif %}">Tax</a>
```

- [ ] **Step 2: Update any test that checks for the old text**

```bash
grep -rn "Wash sales" tests/web/
```

For each match in a smoke test, change the assertion to check for "Tax". For tests specifically about the wash-sales filter UI inside the tax page, leave them — the tab label "Wash sales" is still rendered inside `tax.html`.

- [ ] **Step 3: Run smoke tests**

Run: `uv run pytest tests/web/test_phase1_smoke.py tests/web/test_tax_route.py -v`
Expected: PASS

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/web/templates/base.html tests/web/test_phase1_smoke.py
git commit -m "feat(web): rename nav 'Wash sales' to 'Tax'"
```

---

## Phase 2 smoke test

### Task 30: End-to-end smoke covering /tax tabs + portfolio embeds + /sim

**Files:**
- Create: `tests/web/test_phase2_smoke.py`

- [ ] **Step 1: Write the smoke test**

```python
# tests/web/test_phase2_smoke.py
"""Phase 2 end-to-end smoke: every new surface renders without 500s, on a small
multi-account dataset that exercises wheel awareness, harvest queue, projection."""

from datetime import date, timedelta
from decimal import Decimal

from net_alpha.models.domain import OptionDetails, Trade


def test_phase2_full_smoke(client, repo, schwab_account, seed_import, tmp_path, monkeypatch):
    today = date.today()

    # Seed: one stock loss, one stock gain, one CSP-assigned chain.
    sto = Trade(
        account=schwab_account.display(), date=today - timedelta(days=180),
        ticker="UUUU", action="Sell to Open",
        quantity=Decimal("1"), proceeds=Decimal("120"), cost_basis=Decimal("0"),
        option_details=OptionDetails(
            strike=Decimal("5"), expiry=today - timedelta(days=120), call_put="P"),
        basis_source="option_short_open",
    )
    btc = Trade(
        account=schwab_account.display(), date=today - timedelta(days=120),
        ticker="UUUU", action="Buy to Close",
        quantity=Decimal("1"), proceeds=Decimal("0"), cost_basis=Decimal("0"),
        option_details=OptionDetails(
            strike=Decimal("5"), expiry=today - timedelta(days=120), call_put="P"),
        basis_source="option_short_close_assigned",
    )
    assigned = Trade(
        account=schwab_account.display(), date=today - timedelta(days=120),
        ticker="UUUU", action="Buy",
        quantity=Decimal("100"), proceeds=Decimal("0"), cost_basis=Decimal("380"),
        basis_source="option_short_open_assigned",
    )
    spy_buy = Trade(
        account=schwab_account.display(), date=today - timedelta(days=400),
        ticker="SPY", action="Buy",
        quantity=Decimal("10"), proceeds=Decimal("0"), cost_basis=Decimal("4500"),
    )
    seed_import(repo, schwab_account, [sto, btc, assigned, spy_buy])

    # /tax — every tab renders.
    for view in ("wash-sales", "harvest", "budget", "projection"):
        resp = client.get(f"/tax?view={view}")
        assert resp.status_code == 200, f"/tax?view={view} returned {resp.status_code}"

    # /portfolio/kpis — offset budget tile and projection card both render.
    resp = client.get("/portfolio/kpis")
    assert resp.status_code == 200

    # /wash-sales -> /tax 301.
    resp = client.get("/wash-sales", follow_redirects=False)
    assert resp.status_code == 301

    # /sim — POST renders traffic light.
    resp = client.post("/sim", data={
        "action": "sell", "ticker": "UUUU", "qty": "100", "price": "3",
        "account": schwab_account.display(),
        "trade_date": today.isoformat(),
    })
    assert resp.status_code == 200
    assert "traffic-light" in resp.text
```

- [ ] **Step 2: Run all tests**

Run: `uv run pytest tests/ -v --tb=short`
Expected: PASS — full project test suite passes (Phase 1's 49 audit tests, plus Phase 2's new tests).

- [ ] **Step 3: Run ruff**

Run: `uv run ruff check src/ tests/ && uv run ruff format src/ tests/`
Expected: clean.

- [ ] **Step 4: Commit**

```bash
git add tests/web/test_phase2_smoke.py
git commit -m "test(tax): phase-2 smoke — /tax tabs, portfolio embeds, /sim traffic light"
```

---

## Phase 2 acceptance checklist

After all 30 tasks complete:

- [ ] `uv run pytest tests/ -v` passes with no regressions vs `master`.
- [ ] `uv run ruff check src/ tests/` is clean.
- [ ] `GET /tax` returns 200 and renders all 4 tab templates.
- [ ] `GET /wash-sales` returns 301 → `/tax?view=wash-sales` (preserves query).
- [ ] `/portfolio` shows offset-budget tile and projection card (or placeholder if no `tax:` config).
- [ ] `POST /sim` result panel shows the traffic-light fragment (green/yellow/red).
- [ ] Harvest queue surfaces premium offset for CSP-assigned positions.
- [ ] Open-CSP on underlying extends the underlying's lockout-clear date by 30 days.
- [ ] `etf_replacements.yaml` ships bundled; user override at `~/.net_alpha/etf_replacements.yaml` extends it; conflict with `etf_pairs.yaml` is filtered with a warning, not an exception.
- [ ] Missing `tax:` config: harvest queue / offset budget / traffic-light still work; projection card shows placeholder linking to data-hygiene row; data-hygiene row "tax_config_missing" is present.
- [ ] Phase 1 audit tests (49) still pass; Phase 1 smoke test still passes.

---

**Total tasks:** 30 (TDD-paced, ~2-5 min per step).

**Architectural note for the executor:** All the new compute (`portfolio/tax_planner.py` + `engine/lockout.py`) is pure-function and operates on the existing `Repository` reads. No DB schema changes. Wheel awareness reuses the existing `option_short_open_assigned` / `option_short_close_assigned` synthetic trades produced by the Schwab parser — Section 2e is fundamentally a *read-side* feature. Phase 2 ships with no migrations.
