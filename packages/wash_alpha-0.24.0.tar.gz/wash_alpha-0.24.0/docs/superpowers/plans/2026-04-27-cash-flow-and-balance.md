# Cash Flow & Balance Tracking Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Persist non-trade Schwab CSV rows (transfers, dividends, interest, sweeps, fees) into a new `cash_events` table, then surface running cash balance, contributions-vs-growth, and cash share of portfolio in the Portfolio web page.

**Architecture:** New `cash_events` table sits alongside `trades`; both contribute to a running cash balance computed by pure functions in `portfolio/cash_flow.py`. Schwab parser is extended to emit `CashEvent` objects in parallel with `Trade` objects. Wash-sale engine is untouched. New `gross_cash_impact` column on `trades` captures the broker's signed CSV `Amount` so put-assignment buys account for cash correctly.

**Tech Stack:** Python 3.11+, pydantic v2, sqlmodel/SQLite, FastAPI + Jinja, factory_boy + pytest. All commands run via `uv run …`.

**Spec:** `docs/superpowers/specs/2026-04-26-cash-flow-and-balance-design.md`.

---

## Task 1: Define `CashEvent` Pydantic domain model

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Test: `tests/models/test_cash_event.py` (create file; create `tests/models/__init__.py` if missing)

- [ ] **Step 1.1: Write the failing test**

```python
# tests/models/test_cash_event.py
from datetime import date

from net_alpha.models.domain import CashEvent


def test_cash_event_natural_key_is_deterministic():
    e1 = CashEvent(
        account="Schwab/short_term",
        event_date=date(2026, 3, 31),
        kind="dividend",
        amount=4.47,
        ticker="SQQQ",
        description="PROSHARES ULTRAPRO SHORTQQQ",
    )
    e2 = CashEvent(
        account="Schwab/short_term",
        event_date=date(2026, 3, 31),
        kind="dividend",
        amount=4.47,
        ticker="SQQQ",
        description="PROSHARES ULTRAPRO SHORTQQQ",
    )
    assert e1.compute_natural_key() == e2.compute_natural_key()


def test_cash_event_natural_key_differs_on_kind():
    base = dict(
        account="Schwab/short_term",
        event_date=date(2026, 3, 31),
        amount=100.0,
        ticker=None,
        description="Tfr WELLS FARGO BANK",
    )
    a = CashEvent(kind="transfer_in", **base).compute_natural_key()
    b = CashEvent(kind="transfer_out", **base).compute_natural_key()
    assert a != b


def test_cash_event_amount_is_always_positive():
    # Sign comes from kind, not amount. amount is always positive in the model.
    e = CashEvent(
        account="Schwab/short_term",
        event_date=date(2026, 3, 31),
        kind="transfer_in",
        amount=600.0,
        ticker=None,
        description="Tfr WELLS FARGO BANK",
    )
    assert e.amount > 0
```

- [ ] **Step 1.2: Run test to verify it fails**

Run: `uv run pytest tests/models/test_cash_event.py -v`
Expected: FAIL with `ImportError: cannot import name 'CashEvent'`

- [ ] **Step 1.3: Implement `CashEvent` in `models/domain.py`**

Add the following class to `src/net_alpha/models/domain.py` (place it after `OptionDetails` and before `Trade`):

```python
class CashEvent(BaseModel):
    """A non-trade cash movement (transfer, dividend, interest, fee, sweep)."""

    id: str = Field(default_factory=lambda: str(uuid4()))
    account: str
    event_date: date
    kind: str  # transfer_in | transfer_out | dividend | interest | fee | sweep_in | sweep_out
    amount: float  # always positive; sign comes from `kind`
    ticker: str | None = None
    description: str = ""

    def compute_natural_key(self) -> str:
        """SHA256 over canonical fields used for idempotent re-import dedup."""
        import hashlib

        payload = "|".join(
            [
                self.account,
                self.event_date.isoformat(),
                self.kind,
                f"{self.amount:.6f}",
                self.ticker or "",
                self.description,
            ]
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()
```

- [ ] **Step 1.4: Run test to verify it passes**

Run: `uv run pytest tests/models/test_cash_event.py -v`
Expected: 3 passing.

- [ ] **Step 1.5: Commit**

```bash
git add src/net_alpha/models/domain.py tests/models/
git commit -m "feat(models): add CashEvent domain model with natural_key dedup"
```

---

## Task 2: Add `CashEventRow`, extend `TradeRow` and `ImportRecordRow`

**Files:**
- Modify: `src/net_alpha/db/tables.py`

- [ ] **Step 2.1: Add `CashEventRow` table at the end of `db/tables.py`**

```python
class CashEventRow(SQLModel, table=True):
    __tablename__ = "cash_events"
    __table_args__ = (UniqueConstraint("account_id", "natural_key", name="uq_cash_event_account_natkey"),)

    id: int | None = Field(default=None, primary_key=True)
    import_id: int = Field(foreign_key="imports.id", index=True)
    account_id: int = Field(foreign_key="accounts.id", index=True)
    natural_key: str = Field(index=True)

    event_date: str = Field(index=True)  # YYYY-MM-DD as-is from broker
    kind: str  # transfer_in | transfer_out | dividend | interest | fee | sweep_in | sweep_out
    amount: float  # always positive; sign comes from `kind`
    ticker: str | None = Field(default=None, index=True)
    description: str = ""
```

- [ ] **Step 2.2: Add `gross_cash_impact` to `TradeRow`**

In `db/tables.py`, in the `TradeRow` class, add after `transfer_basis_user_set`:

```python
    gross_cash_impact: float | None = Field(default=None)
```

- [ ] **Step 2.3: Add `cash_event_count` to `ImportRecordRow`**

In `db/tables.py`, in the `ImportRecordRow` class, add after `duplicate_trades`:

```python
    cash_event_count: int | None = Field(default=0)
```

- [ ] **Step 2.4: Verify the schema compiles**

Run: `uv run python -c "from net_alpha.db.tables import CashEventRow, TradeRow, ImportRecordRow; print(CashEventRow.__tablename__, TradeRow.__tablename__, ImportRecordRow.__tablename__)"`
Expected: `cash_events trades imports`

- [ ] **Step 2.5: Commit**

```bash
git add src/net_alpha/db/tables.py
git commit -m "feat(db): add cash_events table; add gross_cash_impact and cash_event_count columns"
```

---

## Task 3: Add v7 → v8 migration

**Files:**
- Modify: `src/net_alpha/db/migrations.py`
- Test: `tests/db/test_migrations.py` (modify if exists; create otherwise)

- [ ] **Step 3.1: Inspect existing migration tests**

Run: `ls tests/db/ 2>/dev/null && grep -r "CURRENT_SCHEMA_VERSION\|_migrate_v" tests/db/ 2>/dev/null | head -20`
If no `tests/db/` exists, create `tests/db/__init__.py`.

- [ ] **Step 3.2: Write a migration test**

Create or extend `tests/db/test_migrations.py`:

```python
from sqlalchemy import create_engine, text
from sqlmodel import Session, SQLModel

from net_alpha.db.migrations import (
    CURRENT_SCHEMA_VERSION,
    _table_exists,
    _column_exists,
    migrate,
    set_schema_version,
)


def test_v7_to_v8_creates_cash_events_table_and_new_columns():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    with Session(engine) as s:
        # Pretend the DB is at v7 (skip the fresh-DB short-circuit).
        s.exec(text("INSERT INTO meta(key, value) VALUES ('schema_version', '7') "
                    "ON CONFLICT(key) DO UPDATE SET value='7'"))
        s.commit()
        # Drop the columns/table we expect the migration to create, so we
        # can prove the migration adds them. (SQLModel.metadata.create_all
        # already added them since they are part of the current schema.)
        # Instead, we assert that a v7 DB is brought up to v8 cleanly.
        migrate(s)
        s.commit()
        assert _table_exists(s, "cash_events")
        assert _column_exists(s, "trades", "gross_cash_impact")
        assert _column_exists(s, "imports", "cash_event_count")
        version = s.exec(text("SELECT value FROM meta WHERE key='schema_version'")).first()
        assert int(version[0]) == CURRENT_SCHEMA_VERSION


def test_current_schema_version_is_8():
    assert CURRENT_SCHEMA_VERSION == 8
```

- [ ] **Step 3.3: Run test to verify it fails**

Run: `uv run pytest tests/db/test_migrations.py -v`
Expected: FAIL with `assert 7 == 8` (CURRENT_SCHEMA_VERSION still 7).

- [ ] **Step 3.4: Implement the migration**

In `src/net_alpha/db/migrations.py`:

(a) Update the docstring to add the v8 line:
```python
  v8 — Adds cash_events table; trades.gross_cash_impact; imports.cash_event_count.
```

(b) Bump `CURRENT_SCHEMA_VERSION = 8`.

(c) Add the migration function at the bottom (above `def migrate`):

```python
def _migrate_v7_to_v8(session: Session) -> None:
    """Add cash_events table; gross_cash_impact column on trades; cash_event_count
    on imports. All idempotent so re-running on a partially-migrated DB is safe.
    """
    if not _table_exists(session, "cash_events"):
        session.exec(
            text(
                "CREATE TABLE cash_events ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "import_id INTEGER NOT NULL REFERENCES imports(id), "
                "account_id INTEGER NOT NULL REFERENCES accounts(id), "
                "natural_key TEXT NOT NULL, "
                "event_date TEXT NOT NULL, "
                "kind TEXT NOT NULL, "
                "amount REAL NOT NULL, "
                "ticker TEXT, "
                "description TEXT NOT NULL DEFAULT '', "
                "CONSTRAINT uq_cash_event_account_natkey UNIQUE (account_id, natural_key))"
            )
        )
        session.exec(text("CREATE INDEX ix_cash_events_account_id ON cash_events(account_id)"))
        session.exec(text("CREATE INDEX ix_cash_events_import_id ON cash_events(import_id)"))
        session.exec(text("CREATE INDEX ix_cash_events_event_date ON cash_events(event_date)"))
        session.exec(text("CREATE INDEX ix_cash_events_natural_key ON cash_events(natural_key)"))
        session.exec(text("CREATE INDEX ix_cash_events_ticker ON cash_events(ticker)"))
    if _table_exists(session, "trades") and not _column_exists(session, "trades", "gross_cash_impact"):
        session.exec(text("ALTER TABLE trades ADD COLUMN gross_cash_impact REAL"))
    if _table_exists(session, "imports") and not _column_exists(session, "imports", "cash_event_count"):
        session.exec(text("ALTER TABLE imports ADD COLUMN cash_event_count INTEGER DEFAULT 0"))
    session.commit()
```

(d) In the `migrate(...)` function, after the v6→v7 block and before the `if current > CURRENT_SCHEMA_VERSION:` guard, add:

```python
    if current < 8:
        _migrate_v7_to_v8(session)
        set_schema_version(session, 8)
        return
```

Also remove the `return` from the v6→v7 block — it was the previous terminal version. Replace with no terminal action so v7 falls through to the v8 block. Specifically, change:

```python
    if current < 7:
        _migrate_v6_to_v7(session)
        set_schema_version(session, 7)
        return
```

to:

```python
    if current < 7:
        _migrate_v6_to_v7(session)
        set_schema_version(session, 7)
        current = 7
```

- [ ] **Step 3.5: Run test to verify it passes**

Run: `uv run pytest tests/db/test_migrations.py -v`
Expected: 2 passing.

- [ ] **Step 3.6: Run the full test suite to verify no regressions**

Run: `uv run pytest tests/db/ tests/models/ -v`
Expected: all passing.

- [ ] **Step 3.7: Commit**

```bash
git add src/net_alpha/db/migrations.py tests/db/
git commit -m "feat(db): v7→v8 migration for cash_events + gross_cash_impact + cash_event_count"
```

---

## Task 4: `Repository.add_cash_events`

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_cash_events_repo.py` (create)

- [ ] **Step 4.1: Write the failing test**

```python
# tests/db/test_cash_events_repo.py
from datetime import date, datetime

from sqlalchemy import create_engine
from sqlmodel import SQLModel

from net_alpha.db.repository import Repository
from net_alpha.models.domain import CashEvent, ImportRecord


def _setup():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    repo = Repository(engine)
    account = repo.get_or_create_account("Schwab", "short_term")
    rec = ImportRecord(
        id=None,
        account_id=account.id,
        csv_filename="x.csv",
        csv_sha256="abc",
        imported_at=datetime(2026, 4, 26, 12, 0, 0),
        trade_count=0,
    )
    result = repo.add_import(account, rec, trades=[])
    return repo, account, result.import_id


def _ev(d, kind, amount, account="Schwab/short_term", description="x"):
    return CashEvent(
        account=account,
        event_date=d,
        kind=kind,
        amount=amount,
        ticker=None,
        description=description,
    )


def test_add_cash_events_inserts_new_rows():
    repo, _account, import_id = _setup()
    events = [
        _ev(date(2026, 3, 31), "dividend", 4.47, description="SQQQ DIV"),
        _ev(date(2026, 3, 30), "interest", 0.06, description="SCHWAB1 INT"),
    ]
    n = repo.add_cash_events(events, import_id=import_id)
    assert n == 2
    listed = repo.list_cash_events()
    assert len(listed) == 2
    assert {e.kind for e in listed} == {"dividend", "interest"}


def test_add_cash_events_is_idempotent_on_natural_key():
    repo, _account, import_id = _setup()
    events = [_ev(date(2026, 3, 31), "dividend", 4.47, description="SQQQ DIV")]
    repo.add_cash_events(events, import_id=import_id)
    n2 = repo.add_cash_events(events, import_id=import_id)
    assert n2 == 0
    assert len(repo.list_cash_events()) == 1
```

- [ ] **Step 4.2: Run test to verify it fails**

Run: `uv run pytest tests/db/test_cash_events_repo.py::test_add_cash_events_inserts_new_rows -v`
Expected: FAIL with `AttributeError: 'Repository' object has no attribute 'add_cash_events'`.

- [ ] **Step 4.3: Implement `add_cash_events` in `Repository`**

Add to `db/repository.py`. First, extend imports:

```python
from net_alpha.db.tables import (
    AccountRow,
    CashEventRow,            # NEW
    ImportRecordRow,
    LotOverrideRow,
    LotRow,
    MetaRow,
    RealizedGLLotRow,
    SplitRow,
    TradeRow,
    WashSaleViolationRow,
)
from net_alpha.models.domain import (
    Account,
    AddImportResult,
    CashEvent,              # NEW
    ImportRecord,
    ImportSummary,
    Lot,
    OptionDetails,
    RemoveImportResult,
    Trade,
    WashSaleViolation,
)
```

Then add this method to the `Repository` class (place near `add_import` for cohesion):

```python
    def add_cash_events(self, events: list[CashEvent], *, import_id: int) -> int:
        """Insert cash events; dedupe on (account_id, natural_key). Returns count of NEW rows."""
        if not events:
            return 0
        with Session(self.engine) as s:
            # Group inputs by account_id once so we can pre-fetch existing keys.
            inserted = 0
            account_id_cache: dict[str, int] = {}

            def resolve_aid(display: str) -> int:
                if display in account_id_cache:
                    return account_id_cache[display]
                broker, label = display.split("/", 1)
                row = s.exec(
                    select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)
                ).first()
                if row is None:
                    raise LookupError(f"Account {display!r} not found")
                account_id_cache[display] = row.id
                return row.id

            for ev in events:
                aid = resolve_aid(ev.account)
                row = CashEventRow(
                    import_id=import_id,
                    account_id=aid,
                    natural_key=ev.compute_natural_key(),
                    event_date=ev.event_date.isoformat(),
                    kind=ev.kind,
                    amount=ev.amount,
                    ticker=ev.ticker,
                    description=ev.description,
                )
                try:
                    s.add(row)
                    s.flush()
                    inserted += 1
                except Exception:
                    s.rollback()
            s.commit()
            return inserted
```

- [ ] **Step 4.4: Run test to verify it passes**

Run: `uv run pytest tests/db/test_cash_events_repo.py::test_add_cash_events_inserts_new_rows -v`
Expected: FAIL on second test (no `list_cash_events` yet) — that's OK; we add it next.

- [ ] **Step 4.5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_cash_events_repo.py
git commit -m "feat(repo): add_cash_events with dedup on (account_id, natural_key)"
```

---

## Task 5: `Repository.list_cash_events`

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_cash_events_repo.py` (extend)

- [ ] **Step 5.1: Add a list/scope test**

Append to `tests/db/test_cash_events_repo.py`:

```python
def test_list_cash_events_filters_by_account_id():
    repo, account, import_id = _setup()
    other = repo.get_or_create_account("Schwab", "long_term")
    other_rec = ImportRecord(
        id=None, account_id=other.id, csv_filename="y.csv", csv_sha256="def",
        imported_at=datetime(2026, 4, 26, 12, 0, 0), trade_count=0,
    )
    other_import = repo.add_import(other, other_rec, trades=[]).import_id
    repo.add_cash_events(
        [_ev(date(2026, 3, 31), "dividend", 1.0, account="Schwab/short_term", description="A")],
        import_id=import_id,
    )
    repo.add_cash_events(
        [_ev(date(2026, 3, 31), "dividend", 2.0, account="Schwab/long_term", description="B")],
        import_id=other_import,
    )
    short = repo.list_cash_events(account_id=account.id)
    long = repo.list_cash_events(account_id=other.id)
    assert {e.amount for e in short} == {1.0}
    assert {e.amount for e in long} == {2.0}


def test_list_cash_events_filters_by_date_range():
    repo, _account, import_id = _setup()
    repo.add_cash_events(
        [
            _ev(date(2025, 12, 31), "dividend", 1.0, description="A"),
            _ev(date(2026, 1, 1), "dividend", 2.0, description="B"),
            _ev(date(2026, 6, 30), "dividend", 3.0, description="C"),
        ],
        import_id=import_id,
    )
    in_2026 = repo.list_cash_events(since=date(2026, 1, 1), until=date(2026, 12, 31))
    assert {e.amount for e in in_2026} == {2.0, 3.0}
```

- [ ] **Step 5.2: Run tests to verify they fail**

Run: `uv run pytest tests/db/test_cash_events_repo.py -v`
Expected: 3 failing on missing `list_cash_events`.

- [ ] **Step 5.3: Implement `list_cash_events`**

Add to `Repository` (after `add_cash_events`):

```python
    def _row_to_cash_event(self, s: Session, row: CashEventRow) -> CashEvent:
        return CashEvent(
            id=str(row.id),
            account=self._account_display_for_id(s, row.account_id),
            event_date=date.fromisoformat(row.event_date),
            kind=row.kind,
            amount=row.amount,
            ticker=row.ticker,
            description=row.description or "",
        )

    def list_cash_events(
        self,
        *,
        account_id: int | None = None,
        since: date | None = None,
        until: date | None = None,
    ) -> list[CashEvent]:
        with Session(self.engine) as s:
            stmt = select(CashEventRow)
            if account_id is not None:
                stmt = stmt.where(CashEventRow.account_id == account_id)
            if since is not None:
                stmt = stmt.where(CashEventRow.event_date >= since.isoformat())
            if until is not None:
                stmt = stmt.where(CashEventRow.event_date <= until.isoformat())
            stmt = stmt.order_by(CashEventRow.event_date)
            rows = s.exec(stmt).all()
            return [self._row_to_cash_event(s, r) for r in rows]
```

- [ ] **Step 5.4: Run tests to verify they pass**

Run: `uv run pytest tests/db/test_cash_events_repo.py -v`
Expected: 4 passing.

- [ ] **Step 5.5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_cash_events_repo.py
git commit -m "feat(repo): list_cash_events with account/date scoping"
```

---

## Task 6: Cascade-delete cash events on `remove_import`

**Files:**
- Modify: `src/net_alpha/db/repository.py:316` (the `remove_import` method)
- Test: `tests/db/test_cash_events_repo.py` (extend)

- [ ] **Step 6.1: Append a cascade-delete test**

In `tests/db/test_cash_events_repo.py`:

```python
def test_remove_import_cascade_deletes_cash_events():
    repo, _account, import_id = _setup()
    repo.add_cash_events(
        [_ev(date(2026, 3, 31), "dividend", 4.47, description="SQQQ DIV")],
        import_id=import_id,
    )
    assert len(repo.list_cash_events()) == 1
    repo.remove_import(import_id)
    assert len(repo.list_cash_events()) == 0
```

- [ ] **Step 6.2: Run test to verify it fails**

Run: `uv run pytest tests/db/test_cash_events_repo.py::test_remove_import_cascade_deletes_cash_events -v`
Expected: FAIL — cash event row is orphaned, list still returns 1.

- [ ] **Step 6.3: Patch `remove_import`**

In `src/net_alpha/db/repository.py`, in the `remove_import` method, find the existing line:

```python
            s.exec(RealizedGLLotRow.__table__.delete().where(RealizedGLLotRow.import_id == import_id))
```

and add immediately after it:

```python
            s.exec(CashEventRow.__table__.delete().where(CashEventRow.import_id == import_id))
```

- [ ] **Step 6.4: Run test to verify it passes**

Run: `uv run pytest tests/db/test_cash_events_repo.py -v`
Expected: 5 passing.

- [ ] **Step 6.5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_cash_events_repo.py
git commit -m "fix(repo): cascade-delete cash_events on remove_import"
```

---

## Task 7: Define `ImportResult` and `parse_warnings` plumbing for the parser

**Files:**
- Modify: `src/net_alpha/models/domain.py`
- Modify: `src/net_alpha/brokers/base.py`

- [ ] **Step 7.1: Inspect `BrokerParser` ABC signatures**

Run: `cat src/net_alpha/brokers/base.py`
Note the existing `parse(...)` signature — we will keep it for backward compatibility and add a new `parse_full` that returns `ImportResult`.

- [ ] **Step 7.2: Add `ImportResult` to `models/domain.py`**

Append (after `CashEvent`):

```python
class ImportResult(BaseModel):
    """Result of parsing one broker CSV: trades + cash events + warnings."""

    trades: list[Trade] = Field(default_factory=list)
    cash_events: list[CashEvent] = Field(default_factory=list)
    parse_warnings: list[str] = Field(default_factory=list)
```

- [ ] **Step 7.3: Add `parse_full` to `BrokerParser` base**

In `src/net_alpha/brokers/base.py`, add a default `parse_full` method that wraps `parse` for any broker that hasn't implemented it yet:

```python
# add the import:
from net_alpha.models.domain import ImportResult

# inside the BrokerParser class (or alongside the existing parse signature):
    def parse_full(self, rows: list[dict[str, str]], account_display: str) -> ImportResult:
        """Default impl: delegate to legacy parse() and return only trades."""
        trades = self.parse(rows, account_display)
        return ImportResult(trades=trades, cash_events=[], parse_warnings=[])
```

This ensures the existing Schwab parser (and any future broker) keeps working until `parse_full` is properly implemented.

- [ ] **Step 7.4: Verify imports succeed**

Run: `uv run python -c "from net_alpha.models.domain import ImportResult, CashEvent; from net_alpha.brokers.base import BrokerParser; print('ok')"`
Expected: `ok`.

- [ ] **Step 7.5: Commit**

```bash
git add src/net_alpha/models/domain.py src/net_alpha/brokers/base.py
git commit -m "feat(brokers): introduce ImportResult and parse_full default"
```

---

## Task 8: Schwab parser populates `gross_cash_impact` on every Trade

**Files:**
- Modify: `src/net_alpha/models/domain.py` (add field to `Trade`)
- Modify: `src/net_alpha/brokers/schwab.py`
- Modify: `src/net_alpha/db/repository.py` (persist on add_import; reload on _row_to_trade)
- Test: `tests/brokers/test_schwab_gross_cash_impact.py` (create)

- [ ] **Step 8.1: Add field to `Trade` Pydantic model**

In `src/net_alpha/models/domain.py`, in the `Trade` class, add after `transfer_basis_user_set`:

```python
    gross_cash_impact: float | None = None
```

- [ ] **Step 8.2: Write the failing test**

Create `tests/brokers/test_schwab_gross_cash_impact.py`:

```python
from net_alpha.brokers.schwab import SchwabParser


def _row(**kw):
    base = {
        "Date": "04/24/2026", "Action": "Buy", "Symbol": "SPIR",
        "Description": "SPIRE GLOBAL", "Quantity": "10", "Price": "$15.88",
        "Fees & Comm": "", "Amount": "-$158.80",
    }
    base.update(kw)
    return base


def test_buy_populates_negative_gross_cash_impact():
    trades = SchwabParser().parse([_row()], "Schwab/x")
    assert len(trades) == 1
    assert trades[0].gross_cash_impact == -158.80


def test_sell_populates_positive_gross_cash_impact():
    rows = [_row(Action="Sell", Amount="$824.96")]
    trades = SchwabParser().parse(rows, "Schwab/x")
    assert trades[0].gross_cash_impact == 824.96


def test_put_assignment_buy_gross_is_strike_not_basis_adjusted():
    """Sell-to-Open premium of $87, then Assigned Buy at $3 strike for 100 shares.
    cost_basis becomes 213 (strike*qty - premium); gross_cash_impact stays -300.
    """
    rows = [
        {
            "Date": "03/19/2026", "Action": "Sell to Open",
            "Symbol": "RR 04/17/2026 3.00 P",
            "Description": "PUT RICHTECH ROBOTICS IN$3 EXP 04/17/26",
            "Quantity": "1", "Price": "$0.88", "Fees & Comm": "$0.66",
            "Amount": "$87.34",
        },
        {
            "Date": "04/20/2026 as of 04/17/2026", "Action": "Assigned",
            "Symbol": "RR 04/17/2026 3.00 P",
            "Description": "PUT RICHTECH ROBOTICS IN$3 EXP 04/17/26",
            "Quantity": "1", "Price": "", "Fees & Comm": "", "Amount": "",
        },
        {
            "Date": "04/20/2026 as of 04/17/2026", "Action": "Buy",
            "Symbol": "RR", "Description": "RICHTECH ROBOTICS",
            "Quantity": "100", "Price": "$3.00", "Fees & Comm": "",
            "Amount": "-$300.00",
        },
    ]
    trades = SchwabParser().parse(rows, "Schwab/x")
    buys = [t for t in trades if t.action == "Buy" and not t.is_option()]
    assert len(buys) == 1
    assert buys[0].cost_basis == 213.0  # adjusted for premium offset
    assert buys[0].gross_cash_impact == -300.0  # actual cash debit
```

- [ ] **Step 8.3: Run the tests to confirm they fail**

Run: `uv run pytest tests/brokers/test_schwab_gross_cash_impact.py -v`
Expected: FAIL — `gross_cash_impact` is None on all trades.

- [ ] **Step 8.4: Populate `gross_cash_impact` in the parser**

In `src/net_alpha/brokers/schwab.py`, locate the `kwargs` dict near the bottom of the trade-row branch (around line 205):

```python
            kwargs: dict[str, object] = {
                "account": account_display,
                "date": trade_date,
                "ticker": ticker,
                "action": action,
                "quantity": qty,
                "proceeds": proceeds,
                "cost_basis": cost_basis,
                "option_details": opt[1] if opt else None,
            }
```

Add `gross_cash_impact` populated from the signed `amount` parsed earlier:

```python
            kwargs: dict[str, object] = {
                "account": account_display,
                "date": trade_date,
                "ticker": ticker,
                "action": action,
                "quantity": qty,
                "proceeds": proceeds,
                "cost_basis": cost_basis,
                "option_details": opt[1] if opt else None,
                "gross_cash_impact": amount,  # signed; from CSV `Amount`
            }
```

For the transfer branch (above, around line 168), also pass `gross_cash_impact=None` explicitly so the field is set consistently — but transfers don't have a meaningful cash impact (no money moved into Schwab1 on a security transfer). Leave as `None`. No code change needed; default of `None` handles it.

- [ ] **Step 8.5: Persist `gross_cash_impact` through the repository**

In `src/net_alpha/db/repository.py`:

(a) In `add_import`, find the `TradeRow(...)` constructor and add the field:

```python
                    cost_basis=t.cost_basis,
                    basis_unknown=t.basis_unknown,
                    basis_source=t.basis_source,
                    gross_cash_impact=t.gross_cash_impact,  # NEW
                    option_strike=...
```

(b) In `_row_to_trade`, add the field to the returned Trade:

```python
        return Trade(
            id=str(row.id),
            ...
            transfer_basis_user_set=row.transfer_basis_user_set,
            gross_cash_impact=row.gross_cash_impact,   # NEW
            option_details=opt,
        )
```

(c) In `create_manual_trade` and `update_manual_trade`, also pass through `gross_cash_impact=trade.gross_cash_impact` on the `TradeRow` constructor / row update so user-entered manual trades that explicitly set this field are preserved (manual trades from the existing form pass `None`, which is fine).

- [ ] **Step 8.6: Run tests to verify they pass**

Run: `uv run pytest tests/brokers/test_schwab_gross_cash_impact.py tests/db/ -v`
Expected: all passing.

- [ ] **Step 8.7: Run the full Schwab parser test file to catch regressions**

Run: `uv run pytest tests/brokers/test_schwab.py -v`
Expected: all passing.

- [ ] **Step 8.8: Commit**

```bash
git add src/net_alpha/models/domain.py src/net_alpha/brokers/schwab.py src/net_alpha/db/repository.py tests/brokers/test_schwab_gross_cash_impact.py
git commit -m "feat(schwab): populate gross_cash_impact from CSV Amount on every trade"
```

---

## Task 9: Schwab parser emits `CashEvent` for transfer/dividend/interest/fee/sweep

**Files:**
- Modify: `src/net_alpha/brokers/schwab.py`
- Test: `tests/brokers/test_schwab_cash_events.py` (create)

- [ ] **Step 9.1: Write the failing tests**

```python
# tests/brokers/test_schwab_cash_events.py
from datetime import date

from net_alpha.brokers.schwab import SchwabParser


def _row(**kw):
    base = {
        "Date": "", "Action": "", "Symbol": "", "Description": "",
        "Quantity": "", "Price": "", "Fees & Comm": "", "Amount": "",
    }
    base.update(kw)
    return base


def _parse(rows):
    return SchwabParser().parse_full(rows, "Schwab/short_term")


def test_moneylink_transfer_in_emits_transfer_in():
    rows = [_row(Date="03/04/2026", Action="MoneyLink Transfer",
                 Description="Tfr WELLS FARGO", Amount="$300.00")]
    res = _parse(rows)
    assert len(res.cash_events) == 1
    e = res.cash_events[0]
    assert e.kind == "transfer_in"
    assert e.amount == 300.0
    assert e.event_date == date(2026, 3, 4)
    assert e.description == "Tfr WELLS FARGO"


def test_moneylink_transfer_out_emits_transfer_out():
    rows = [_row(Date="03/04/2026", Action="MoneyLink Transfer",
                 Description="Tfr OUT", Amount="-$200.00")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "transfer_out"
    assert res.cash_events[0].amount == 200.0


def test_qualified_dividend_emits_dividend_with_ticker():
    rows = [_row(Date="03/31/2026", Action="Qualified Dividend",
                 Symbol="VST", Description="VISTRA CORP", Amount="$0.23")]
    res = _parse(rows)
    e = res.cash_events[0]
    assert e.kind == "dividend"
    assert e.amount == 0.23
    assert e.ticker == "VST"


def test_non_qualified_dividend_emits_dividend():
    rows = [_row(Date="03/31/2026", Action="Non-Qualified Div",
                 Symbol="SQQQ", Description="PROSHARES SHORT QQQ", Amount="$4.47")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "dividend"
    assert res.cash_events[0].ticker == "SQQQ"


def test_pr_yr_non_qual_div_emits_dividend():
    rows = [_row(Date="03/31/2026", Action="Pr Yr Non-Qual Div",
                 Symbol="ABC", Description="PRIOR YEAR DIV", Amount="$1.50")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "dividend"


def test_cash_dividend_emits_dividend():
    rows = [_row(Date="03/31/2026", Action="Cash Dividend",
                 Symbol="XYZ", Description="DIV", Amount="$2.00")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "dividend"


def test_cash_in_lieu_emits_dividend():
    rows = [_row(Date="03/15/2026", Action="Cash In Lieu",
                 Symbol="ABC", Description="FRACTIONAL", Amount="$0.42")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "dividend"


def test_credit_interest_emits_interest_no_ticker():
    rows = [_row(Date="02/26/2026", Action="Credit Interest",
                 Description="SCHWAB1 INT 01/29-02/25", Amount="$0.14")]
    res = _parse(rows)
    e = res.cash_events[0]
    assert e.kind == "interest"
    assert e.ticker is None


def test_adr_mgmt_fee_emits_fee():
    rows = [_row(Date="02/15/2026", Action="ADR Mgmt Fee",
                 Symbol="WRD", Description="ADR FEE", Amount="-$0.50")]
    res = _parse(rows)
    e = res.cash_events[0]
    assert e.kind == "fee"
    assert e.amount == 0.50  # always positive; sign implied by kind
    assert e.ticker == "WRD"


def test_foreign_tax_paid_emits_fee():
    rows = [_row(Date="03/31/2026", Action="Foreign Tax Paid",
                 Symbol="ADR", Description="FOREIGN TAX", Amount="-$1.20")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "fee"


def test_sweep_to_futures_emits_sweep_out():
    rows = [_row(Date="04/22/2026", Action="Futures MM Sweep",
                 Description="Sweep to Futures", Amount="-$4460.97")]
    res = _parse(rows)
    e = res.cash_events[0]
    assert e.kind == "sweep_out"
    assert e.amount == 4460.97


def test_sweep_from_futures_emits_sweep_in():
    rows = [_row(Date="04/06/2026", Action="Futures MM Sweep",
                 Description="Sweep from Futures", Amount="$10.76")]
    res = _parse(rows)
    assert res.cash_events[0].kind == "sweep_in"


def test_journal_emits_transfer_in_or_out_by_sign():
    rows = [
        _row(Date="04/01/2026", Action="Journal", Description="JOURNAL +", Amount="$50.00"),
        _row(Date="04/01/2026", Action="Journal", Description="JOURNAL -", Amount="-$50.00"),
    ]
    res = _parse(rows)
    kinds = sorted(e.kind for e in res.cash_events)
    assert kinds == ["transfer_in", "transfer_out"]


def test_unknown_non_trade_action_emits_warning_and_skips():
    rows = [_row(Date="04/01/2026", Action="Mystery Magic",
                 Description="???", Amount="$1.00")]
    res = _parse(rows)
    assert res.cash_events == []
    assert any("Mystery Magic" in w for w in res.parse_warnings)


def test_trade_rows_still_produce_trades_not_cash_events():
    """Regression: Buy/Sell rows should NOT show up as cash events."""
    rows = [_row(Date="04/24/2026", Action="Buy", Symbol="SPIR",
                 Description="SPIRE GLOBAL", Quantity="10", Price="$15.88",
                 Amount="-$158.80")]
    res = _parse(rows)
    assert len(res.trades) == 1
    assert res.cash_events == []


def test_security_transfer_remains_a_trade_not_a_cash_event():
    """Journaled Shares / Security Transfer move shares, not Schwab1 cash.
    They stay in the trade-side path with basis_source=transfer_in/out.
    """
    rows = [_row(Date="04/01/2026", Action="Security Transfer", Symbol="ABC",
                 Description="TRANSFER IN", Quantity="100", Amount="")]
    res = _parse(rows)
    assert len(res.trades) == 1
    assert res.trades[0].basis_source == "transfer_in"
    assert res.cash_events == []
```

- [ ] **Step 9.2: Run tests to verify they fail**

Run: `uv run pytest tests/brokers/test_schwab_cash_events.py -v`
Expected: most failing — `parse_full` returns no cash events yet.

- [ ] **Step 9.3: Implement cash-event extraction in the parser**

In `src/net_alpha/brokers/schwab.py`:

(a) Add module-level constants near the existing `_TRANSFER_ACTIONS`:

```python
# Cash-event action mappings (kind, sign-source).
# sign_source = "amount" → kind suffix (_in/_out) chosen by the sign of CSV Amount.
# sign_source = "always_positive" → kind is fixed; amount stored as |Amount|.
# sign_source = "always_negative" → kind is fixed (fee); amount stored as |Amount|.
_CASH_EVENT_ACTIONS: dict[str, tuple[str, str]] = {
    "MoneyLink Transfer": ("transfer", "amount"),
    "Wire Received":      ("transfer", "amount"),
    "Wire Sent":          ("transfer", "amount"),
    "Journal":            ("transfer", "amount"),
    "Futures MM Sweep":   ("sweep",    "amount"),
    "Qualified Dividend":   ("dividend", "always_positive"),
    "Non-Qualified Div":    ("dividend", "always_positive"),
    "Pr Yr Non-Qual Div":   ("dividend", "always_positive"),
    "Cash Dividend":        ("dividend", "always_positive"),
    "Cash In Lieu":         ("dividend", "always_positive"),
    "Credit Interest":      ("interest", "always_positive"),
    "Bank Interest":        ("interest", "always_positive"),
    "Margin Interest":      ("fee", "always_negative"),
    "ADR Mgmt Fee":         ("fee", "always_negative"),
    "Foreign Tax Paid":     ("fee", "always_negative"),
    "Service Fee":          ("fee", "always_negative"),
}

# Non-trade actions handled by trade-side logic (existing) — never cash events.
_TRADE_SIDE_NON_TRADE_ACTIONS = {
    "Security Transfer", "Journaled Shares",
    "Reverse Split", "Assigned", "Expired",
}
```

(b) Implement a helper near `_put_assignment_basis_offsets`:

```python
def _to_cash_event(
    row: dict[str, str],
    account_display: str,
) -> tuple["CashEvent | None", str | None]:
    """Try to convert a non-trade row to a CashEvent.

    Returns (event, warning):
      - (event, None) on a recognised cash-event row
      - (None, None) if the row is a known non-cash-event action (e.g. Security Transfer)
      - (None, warning_text) on an unknown non-trade action
    """
    from net_alpha.models.domain import CashEvent

    action = row.get("Action", "").strip()
    if action in _CASH_EVENT_ACTIONS:
        kind_root, sign_source = _CASH_EVENT_ACTIONS[action]
        amount_raw = row.get("Amount", "")
        amount = _money(amount_raw)
        if amount == 0.0:
            return None, f"Skipped {action!r} row with empty/zero Amount on {row.get('Date', '')!r}"

        if sign_source == "amount":
            kind = f"{kind_root}_in" if amount > 0 else f"{kind_root}_out"
        elif sign_source == "always_positive":
            kind = kind_root
        else:  # always_negative — fee
            kind = kind_root
        d = _parse_date(row.get("Date", ""))
        if d is None:
            return None, f"Skipped {action!r} row with invalid Date {row.get('Date', '')!r}"
        symbol = row.get("Symbol", "").strip() or None
        # Underlying ticker for option dividend rows is rare; treat Symbol as ticker as-is.
        return (
            CashEvent(
                account=account_display,
                event_date=d,
                kind=kind,
                amount=abs(amount),
                ticker=symbol,
                description=row.get("Description", "").strip(),
            ),
            None,
        )
    return None, None
```

(c) Implement `parse_full` on `SchwabParser`. Add this method to the class (replace any earlier delegation):

```python
    def parse_full(self, rows: list[dict[str, str]], account_display: str) -> "ImportResult":
        from net_alpha.models.domain import ImportResult

        trades = self.parse(rows, account_display)
        cash_events: list = []
        warnings: list[str] = []
        # Set of action strings handled by the trade-side branch, OR as cash events;
        # anything else is unknown.
        known_trade_actions = (
            _BUY_ACTIONS | _SELL_ACTIONS | _TRANSFER_ACTIONS | _TRADE_SIDE_NON_TRADE_ACTIONS
        )
        for row in rows:
            action = row.get("Action", "").strip()
            if action in known_trade_actions:
                continue
            if action in _CASH_EVENT_ACTIONS:
                ev, warn = _to_cash_event(row, account_display)
                if ev is not None:
                    cash_events.append(ev)
                if warn is not None:
                    warnings.append(warn)
            else:
                # Unknown non-trade action — warn but don't crash.
                warnings.append(
                    f"Unknown action {action!r} on {row.get('Date', '')!r} (row skipped)"
                )
        return ImportResult(trades=trades, cash_events=cash_events, parse_warnings=warnings)
```

(d) Add `Reverse Split`, `Assigned`, `Expired` to the trade-side path's silent-skip list. The current parser already silently `continue`s on these because they don't match buy/sell/transfer actions. The `_TRADE_SIDE_NON_TRADE_ACTIONS` constant simply documents this — no change needed in `parse()`.

- [ ] **Step 9.4: Run tests to verify they pass**

Run: `uv run pytest tests/brokers/test_schwab_cash_events.py -v`
Expected: all 16 passing.

- [ ] **Step 9.5: Run the full Schwab parser suite for regressions**

Run: `uv run pytest tests/brokers/ -v`
Expected: all passing.

- [ ] **Step 9.6: Commit**

```bash
git add src/net_alpha/brokers/schwab.py tests/brokers/test_schwab_cash_events.py
git commit -m "feat(schwab): emit CashEvent for transfers, dividends, interest, fees, sweeps"
```

---

## Task 10: Wire `parse_full` through the import pipeline

**Files:**
- Modify: `src/net_alpha/db/repository.py` — extend `add_import` signature with `cash_events` and `parse_warnings`.
- Modify: caller(s) of `add_import` in the CLI / web upload path.
- Test: `tests/db/test_cash_events_repo.py` (extend)

- [ ] **Step 10.1: Find every caller of `add_import`**

Run: `grep -rn "\.add_import(" src/ tests/`
Note each call site — these need to pass cash events alongside trades. Typical paths:
- `src/net_alpha/import_/aggregations.py` or similar
- `src/net_alpha/cli/...` (the import command)
- `src/net_alpha/web/routes/imports.py` (the upload route)

Read each file briefly to understand its current shape.

- [ ] **Step 10.2: Write the failing test**

Append to `tests/db/test_cash_events_repo.py`:

```python
def test_add_import_persists_cash_events_and_count():
    repo, account, _ = _setup()
    rec = ImportRecord(
        id=None, account_id=account.id, csv_filename="z.csv", csv_sha256="zzz",
        imported_at=datetime(2026, 4, 26, 12, 0, 0), trade_count=0,
    )
    events = [_ev(date(2026, 3, 31), "dividend", 4.47, description="SQQQ DIV")]
    result = repo.add_import(account, rec, trades=[], cash_events=events)
    assert result.new_cash_events == 1
    summaries = repo.list_imports()
    [s] = [s for s in summaries if s.id == result.import_id]
    assert s.cash_event_count == 1
```

- [ ] **Step 10.3: Run test to confirm it fails**

Run: `uv run pytest tests/db/test_cash_events_repo.py::test_add_import_persists_cash_events_and_count -v`
Expected: FAIL — `add_import` doesn't accept `cash_events` kwarg.

- [ ] **Step 10.4: Extend `AddImportResult` and `ImportSummary`**

In `src/net_alpha/models/domain.py`, find `AddImportResult` and add a field:

```python
class AddImportResult(BaseModel):
    import_id: int
    new_trades: int
    duplicate_trades: int
    new_cash_events: int = 0   # NEW
```

Find `ImportSummary` and add:

```python
    cash_event_count: int = 0   # NEW
```

- [ ] **Step 10.5: Extend `Repository.add_import`**

In `src/net_alpha/db/repository.py`, change the signature of `add_import`:

```python
    def add_import(
        self,
        account: Account,
        record: ImportRecord,
        trades: list[Trade],
        cash_events: list[CashEvent] | None = None,
    ) -> AddImportResult:
```

Then, after the existing `s.commit()` for trades and just before the `return AddImportResult(...)`, insert cash events using the same `import_id`:

```python
            # Cash events use the same import_id; deduplicate via UNIQUE.
            new_cash = 0
            if cash_events:
                for ev in cash_events:
                    aid = account.id
                    er = CashEventRow(
                        import_id=ir.id,
                        account_id=aid,
                        natural_key=ev.compute_natural_key(),
                        event_date=ev.event_date.isoformat(),
                        kind=ev.kind,
                        amount=ev.amount,
                        ticker=ev.ticker,
                        description=ev.description or "",
                    )
                    try:
                        s.add(er)
                        s.flush()
                        new_cash += 1
                    except Exception:
                        s.rollback()
                        s.add(ir)  # re-attach
                ir.cash_event_count = (ir.cash_event_count or 0) + new_cash
                s.commit()
```

Update the return:

```python
            return AddImportResult(
                import_id=ir.id,
                new_trades=new_count,
                duplicate_trades=ir.duplicate_trades,
                new_cash_events=new_cash,
            )
```

Also: in `list_imports`, where `ImportSummary` is constructed, set `cash_event_count=ir.cash_event_count or 0`.

- [ ] **Step 10.6: Update the import callers**

For each call site found in Step 10.1, adapt to use `parse_full`:

```python
# Before:
trades = parser.parse(rows, account_display)
result = repo.add_import(account, record, trades=trades)

# After:
import_result = parser.parse_full(rows, account_display)
record.parse_warnings = import_result.parse_warnings  # if model supports
result = repo.add_import(
    account,
    record,
    trades=import_result.trades,
    cash_events=import_result.cash_events,
)
```

If `ImportRecord` doesn't already have `parse_warnings`, add a `parse_warnings: list[str] = Field(default_factory=list)` field. Wire `parse_warnings_json` through to the persisted ImportRecordRow alongside the existing logic.

- [ ] **Step 10.7: Run tests to verify they pass**

Run: `uv run pytest tests/db/ tests/brokers/ -v`
Expected: all passing.

- [ ] **Step 10.8: Smoke-run the CLI against a real fixture**

Run: `uv run net-alpha imports` (just to confirm nothing crashes after the migration).
Expected: prints existing imports without error.

- [ ] **Step 10.9: Commit**

```bash
git add src/ tests/
git commit -m "feat(import): wire cash_events through add_import; track cash_event_count"
```

---

## Task 11: Add `CashBalancePoint` and `CashFlowKPIs` portfolio models

**Files:**
- Modify: `src/net_alpha/portfolio/models.py`
- Test: covered by Task 12+ (no standalone test).

- [ ] **Step 11.1: Inspect the file for style**

Run: `head -30 src/net_alpha/portfolio/models.py`

- [ ] **Step 11.2: Add the two models**

Append to `src/net_alpha/portfolio/models.py`:

```python
from datetime import date as _date
from decimal import Decimal as _Decimal


class CashBalancePoint(BaseModel):
    on: _date
    cash_balance: _Decimal
    cumulative_contributions: _Decimal


class CashFlowKPIs(BaseModel):
    cash_balance: _Decimal
    net_contributions: _Decimal
    holdings_value: _Decimal
    account_value: _Decimal
    growth: _Decimal
    growth_pct: _Decimal | None
    cash_share_pct: _Decimal
```

(If the file already imports `BaseModel`, `date`, `Decimal` — reuse those imports instead of aliasing.)

- [ ] **Step 11.3: Verify it imports cleanly**

Run: `uv run python -c "from net_alpha.portfolio.models import CashBalancePoint, CashFlowKPIs; print('ok')"`
Expected: `ok`.

- [ ] **Step 11.4: Commit**

```bash
git add src/net_alpha/portfolio/models.py
git commit -m "feat(portfolio): add CashBalancePoint and CashFlowKPIs models"
```

---

## Task 12: `build_cash_balance_series`

**Files:**
- Create: `src/net_alpha/portfolio/cash_flow.py`
- Test: `tests/portfolio/test_cash_flow.py` (create)

- [ ] **Step 12.1: Write the failing tests**

```python
# tests/portfolio/test_cash_flow.py
import datetime as dt
from decimal import Decimal

from net_alpha.models.domain import CashEvent, Trade
from net_alpha.portfolio.cash_flow import build_cash_balance_series


def _ev(d, kind, amount, account="Schwab/x", description="x"):
    return CashEvent(account=account, event_date=d, kind=kind,
                     amount=amount, ticker=None, description=description)


def _trade(d, action, gross, account="Schwab/x", ticker="SPIR"):
    return Trade(
        id="t", account=account, date=d, ticker=ticker,
        action=action, quantity=10.0,
        proceeds=gross if action == "Sell" else None,
        cost_basis=abs(gross) if action == "Buy" else None,
        gross_cash_impact=gross,
        option_details=None,
    )


def test_empty_inputs_yield_empty_series():
    pts = build_cash_balance_series(events=[], trades=[], account=None, period=None)
    assert pts == []


def test_single_deposit_jumps_balance_and_contributions():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 300.0, description="DEPOSIT")]
    pts = build_cash_balance_series(events=events, trades=[], account=None, period=None)
    assert len(pts) == 1
    assert pts[0].cash_balance == Decimal("300")
    assert pts[0].cumulative_contributions == Decimal("300")


def test_buy_decreases_balance_but_not_contributions():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 300.0)]
    trades = [_trade(dt.date(2026, 3, 5), "Buy", -158.80)]
    pts = build_cash_balance_series(events=events, trades=trades, account=None, period=None)
    assert pts[-1].cash_balance == Decimal("141.20")
    assert pts[-1].cumulative_contributions == Decimal("300")


def test_sweep_out_then_in_dips_and_recovers():
    events = [
        _ev(dt.date(2026, 4, 22), "sweep_out", 4460.97, description="Sweep to Futures"),
        _ev(dt.date(2026, 4, 24), "sweep_in",  307.00, description="Sweep from Futures"),
    ]
    pts = build_cash_balance_series(events=events, trades=[], account=None, period=None)
    assert pts[0].cash_balance == Decimal("-4460.97")
    assert pts[1].cash_balance == Decimal("-4153.97")


def test_dividend_does_not_change_contributions():
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0),
        _ev(dt.date(2026, 3, 31), "dividend", 4.47, description="SQQQ"),
    ]
    pts = build_cash_balance_series(events=events, trades=[], account=None, period=None)
    assert pts[-1].cash_balance == Decimal("104.47")
    assert pts[-1].cumulative_contributions == Decimal("100")


def test_account_filter_excludes_other_accounts():
    events = [
        _ev(dt.date(2026, 3, 4), "transfer_in", 100.0, account="Schwab/A"),
        _ev(dt.date(2026, 3, 4), "transfer_in", 999.0, account="Schwab/B"),
    ]
    pts = build_cash_balance_series(events=events, trades=[], account="Schwab/A", period=None)
    assert pts[-1].cash_balance == Decimal("100")


def test_period_clip_excludes_events_after_window():
    events = [
        _ev(dt.date(2025, 12, 31), "transfer_in", 1000.0),
        _ev(dt.date(2026, 6, 1),  "transfer_in", 200.0),
    ]
    # period = (2026, 2027) means YTD 2026
    pts = build_cash_balance_series(events=events, trades=[], account=None, period=(2026, 2027))
    # The 2025 event sets the opening balance carried into 2026.
    # The 2026 event makes the balance jump.
    assert pts[-1].cash_balance == Decimal("1200")
    assert pts[-1].cumulative_contributions == Decimal("1200")


def test_put_assignment_uses_gross_not_cost_basis():
    """A buy with cost_basis adjusted-down for put_assignment must still
    debit cash by the gross strike × qty amount."""
    trades = [_trade(dt.date(2026, 4, 17), "Buy", -300.0)]
    # Override cost_basis to 213 (basis-adjusted for premium); gross stays -300.
    trades[0].cost_basis = 213.0
    pts = build_cash_balance_series(events=[], trades=trades, account=None, period=None)
    assert pts[-1].cash_balance == Decimal("-300")


def test_legacy_trade_without_gross_falls_back_to_proceeds_or_cost_basis():
    trades = [_trade(dt.date(2026, 1, 5), "Sell", 824.96)]
    trades[0].gross_cash_impact = None  # simulate pre-migration row
    pts = build_cash_balance_series(events=[], trades=trades, account=None, period=None)
    assert pts[-1].cash_balance == Decimal("824.96")
```

- [ ] **Step 12.2: Run tests to verify they fail**

Run: `uv run pytest tests/portfolio/test_cash_flow.py -v`
Expected: FAIL — module doesn't exist.

- [ ] **Step 12.3: Implement `build_cash_balance_series`**

Create `src/net_alpha/portfolio/cash_flow.py`:

```python
"""Pure functions for cash-balance, contributions, and cash-share computations.

No DB access; takes lists of events/trades, returns models. Mirrors the
shape of `equity_curve.py` (sort by date, fold over events, emit one point
per event date).
"""

from __future__ import annotations

import datetime as dt
from collections.abc import Iterable
from decimal import Decimal

from net_alpha.models.domain import CashEvent, Trade
from net_alpha.portfolio.models import CashBalancePoint


# Sign rules — positive amount means cash inflow.
_INFLOW_KINDS = {"transfer_in", "dividend", "interest", "sweep_in"}
_OUTFLOW_KINDS = {"transfer_out", "fee", "sweep_out"}
_CONTRIB_INFLOW = {"transfer_in"}
_CONTRIB_OUTFLOW = {"transfer_out"}


def _trade_cash_delta(t: Trade) -> Decimal:
    """Signed cash impact of a trade. Positive = cash in, negative = cash out."""
    if t.gross_cash_impact is not None:
        return Decimal(str(t.gross_cash_impact))
    # Legacy fallback for trades imported before gross_cash_impact existed.
    if t.action == "Sell" and t.proceeds is not None:
        return Decimal(str(t.proceeds))
    if t.action == "Buy" and t.cost_basis is not None:
        return Decimal(str(-t.cost_basis))
    return Decimal("0")


def _event_cash_delta(e: CashEvent) -> Decimal:
    if e.kind in _INFLOW_KINDS:
        return Decimal(str(e.amount))
    if e.kind in _OUTFLOW_KINDS:
        return Decimal(str(-e.amount))
    return Decimal("0")


def _event_contrib_delta(e: CashEvent) -> Decimal:
    if e.kind in _CONTRIB_INFLOW:
        return Decimal(str(e.amount))
    if e.kind in _CONTRIB_OUTFLOW:
        return Decimal(str(-e.amount))
    return Decimal("0")


def build_cash_balance_series(
    *,
    events: Iterable[CashEvent],
    trades: Iterable[Trade],
    account: str | None,
    period: tuple[int, int] | None,
) -> list[CashBalancePoint]:
    """Return one point per distinct event date, with running cash balance.

    `account=None` includes all accounts. `period=None` includes everything.
    `period=(y, y+1)` restricts the *displayed* points to year `y`; events
    before `y` still contribute to the opening balance carried into year `y`.
    """
    # Filter by account first.
    events_list = [e for e in events if account is None or e.account == account]
    trades_list = [t for t in trades if account is None or t.account == account]

    # Build (date, balance_delta, contrib_delta) tuples.
    rows: list[tuple[dt.date, Decimal, Decimal]] = []
    for e in events_list:
        rows.append((e.event_date, _event_cash_delta(e), _event_contrib_delta(e)))
    for t in trades_list:
        rows.append((t.date, _trade_cash_delta(t), Decimal("0")))

    if not rows:
        return []

    rows.sort(key=lambda r: r[0])

    # Fold into a running series, accumulating opening balance/contrib for items
    # before the period window.
    pts: list[CashBalancePoint] = []
    bal = Decimal("0")
    contrib = Decimal("0")
    last_emitted_date: dt.date | None = None
    pending_bal_delta = Decimal("0")
    pending_contrib_delta = Decimal("0")

    period_start = dt.date(period[0], 1, 1) if period else None
    period_end_excl = dt.date(period[1], 1, 1) if period else None  # exclusive

    for d, bdelta, cdelta in rows:
        bal += bdelta
        contrib += cdelta
        # If outside the period, just keep accumulating opening balance.
        if period_start is not None and d < period_start:
            continue
        if period_end_excl is not None and d >= period_end_excl:
            continue
        if last_emitted_date is None or d != last_emitted_date:
            pts.append(CashBalancePoint(on=d, cash_balance=bal, cumulative_contributions=contrib))
            last_emitted_date = d
        else:
            # Same-day events — fold into the last point.
            pts[-1] = CashBalancePoint(on=d, cash_balance=bal, cumulative_contributions=contrib)
    return pts
```

- [ ] **Step 12.4: Run tests to verify they pass**

Run: `uv run pytest tests/portfolio/test_cash_flow.py -v`
Expected: 9 passing.

- [ ] **Step 12.5: Commit**

```bash
git add src/net_alpha/portfolio/cash_flow.py tests/portfolio/test_cash_flow.py
git commit -m "feat(portfolio): build_cash_balance_series with period and account scoping"
```

---

## Task 13: `compute_cash_kpis`

**Files:**
- Modify: `src/net_alpha/portfolio/cash_flow.py`
- Test: `tests/portfolio/test_cash_flow.py` (extend)

- [ ] **Step 13.1: Append failing tests**

```python
# tests/portfolio/test_cash_flow.py — append
from decimal import Decimal as _D

from net_alpha.portfolio.cash_flow import compute_cash_kpis


def test_kpis_zero_inputs():
    kpi = compute_cash_kpis(
        events=[], trades=[], holdings_value=_D("0"),
        account=None, period=None,
    )
    assert kpi.cash_balance == _D("0")
    assert kpi.account_value == _D("0")
    assert kpi.growth == _D("0")
    assert kpi.growth_pct is None
    assert kpi.cash_share_pct == _D("0")


def test_kpis_simple_deposit_and_holdings():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 1000.0)]
    kpi = compute_cash_kpis(
        events=events, trades=[], holdings_value=_D("250"),
        account=None, period=None,
    )
    # cash 1000 + holdings 250 = 1250 account_value, contrib 1000 → growth 250
    assert kpi.cash_balance == _D("1000")
    assert kpi.holdings_value == _D("250")
    assert kpi.account_value == _D("1250")
    assert kpi.net_contributions == _D("1000")
    assert kpi.growth == _D("250")
    assert kpi.growth_pct == _D("0.25")
    assert kpi.cash_share_pct == _D("0.8")  # 1000/1250


def test_kpis_growth_pct_none_when_no_contributions():
    events = [_ev(dt.date(2026, 3, 4), "dividend", 4.47)]
    kpi = compute_cash_kpis(
        events=events, trades=[], holdings_value=_D("0"),
        account=None, period=None,
    )
    assert kpi.net_contributions == _D("0")
    assert kpi.growth_pct is None
```

- [ ] **Step 13.2: Run tests to verify they fail**

Run: `uv run pytest tests/portfolio/test_cash_flow.py -k kpi -v`
Expected: FAIL — `compute_cash_kpis` not defined.

- [ ] **Step 13.3: Implement `compute_cash_kpis`**

Append to `src/net_alpha/portfolio/cash_flow.py`:

```python
from net_alpha.portfolio.models import CashFlowKPIs


def compute_cash_kpis(
    *,
    events: Iterable[CashEvent],
    trades: Iterable[Trade],
    holdings_value: Decimal,
    account: str | None,
    period: tuple[int, int] | None,
) -> CashFlowKPIs:
    """Single-shot summary used by the KPI strip."""
    series = build_cash_balance_series(
        events=events, trades=trades, account=account, period=period,
    )
    if series:
        cash = series[-1].cash_balance
        contrib = series[-1].cumulative_contributions
    else:
        cash = Decimal("0")
        contrib = Decimal("0")

    account_value = cash + holdings_value
    growth = account_value - contrib
    growth_pct: Decimal | None = (growth / contrib) if contrib != 0 else None
    cash_share_pct = (cash / account_value) if account_value != 0 else Decimal("0")
    return CashFlowKPIs(
        cash_balance=cash,
        net_contributions=contrib,
        holdings_value=holdings_value,
        account_value=account_value,
        growth=growth,
        growth_pct=growth_pct,
        cash_share_pct=cash_share_pct,
    )
```

- [ ] **Step 13.4: Run tests to verify they pass**

Run: `uv run pytest tests/portfolio/test_cash_flow.py -v`
Expected: 12 passing.

- [ ] **Step 13.5: Commit**

```bash
git add src/net_alpha/portfolio/cash_flow.py tests/portfolio/test_cash_flow.py
git commit -m "feat(portfolio): compute_cash_kpis"
```

---

## Task 14: `cash_allocation_slice`

**Files:**
- Modify: `src/net_alpha/portfolio/cash_flow.py`
- Test: `tests/portfolio/test_cash_flow.py` (extend)

- [ ] **Step 14.1: Append failing test**

```python
# tests/portfolio/test_cash_flow.py — append
from net_alpha.portfolio.cash_flow import cash_allocation_slice


def test_cash_allocation_slice_returns_current_balance():
    events = [_ev(dt.date(2026, 3, 4), "transfer_in", 100.0)]
    trades = [_trade(dt.date(2026, 3, 5), "Buy", -25.0)]
    sl = cash_allocation_slice(events=events, trades=trades, account=None)
    assert sl == _D("75")
```

- [ ] **Step 14.2: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_cash_flow.py::test_cash_allocation_slice_returns_current_balance -v`
Expected: FAIL.

- [ ] **Step 14.3: Implement `cash_allocation_slice`**

Append to `cash_flow.py`:

```python
def cash_allocation_slice(
    *,
    events: Iterable[CashEvent],
    trades: Iterable[Trade],
    account: str | None,
) -> Decimal:
    """Return the current cash balance (lifetime, no period clip).

    Used by the allocation donut to render cash as one extra slice.
    """
    series = build_cash_balance_series(
        events=events, trades=trades, account=account, period=None,
    )
    return series[-1].cash_balance if series else Decimal("0")
```

- [ ] **Step 14.4: Run tests to verify they pass**

Run: `uv run pytest tests/portfolio/test_cash_flow.py -v`
Expected: 13 passing.

- [ ] **Step 14.5: Commit**

```bash
git add src/net_alpha/portfolio/cash_flow.py tests/portfolio/test_cash_flow.py
git commit -m "feat(portfolio): cash_allocation_slice for donut integration"
```

---

## Task 15: Extend the `/portfolio/body` route to feed cash data

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`

- [ ] **Step 15.1: Locate the existing `portfolio_body` function**

Read `src/net_alpha/web/routes/portfolio.py` lines 315–388 (the `@router.get("/portfolio/body")` handler).

- [ ] **Step 15.2: Wire cash computation into the route**

Add the import at the top:

```python
from net_alpha.portfolio.cash_flow import (
    build_cash_balance_series,
    compute_cash_kpis,
    cash_allocation_slice,
)
```

Inside `portfolio_body`, after the existing `allocation = build_allocation(...)` line and before `wash_rows = ...`, add:

```python
    # --- Cash flow (NEW) ---
    cash_events = repo.list_cash_events(account_id=None)
    if account:
        cash_events = [e for e in cash_events if e.account == account]
    holdings_value_total = sum(
        (Decimal(str(p.market_value)) for p in positions_for_alloc if p.market_value is not None),
        start=Decimal("0"),
    )
    cash_kpis = compute_cash_kpis(
        events=cash_events,
        trades=scoped_trades,
        holdings_value=holdings_value_total,
        account=None,  # already filtered above
        period=period_tuple,
    )
    cash_points = build_cash_balance_series(
        events=cash_events,
        trades=scoped_trades,
        account=None,
        period=period_tuple,
    )
    cash_slice = cash_allocation_slice(
        events=cash_events,
        trades=scoped_trades,
        account=None,
    )
```

(Add `from decimal import Decimal` at the top of the file if not already imported.)

Extend the template context dict to include the new keys:

```python
            "cash_kpis": cash_kpis,
            "cash_points": cash_points,
            "cash_slice": cash_slice,
```

- [ ] **Step 15.3: Smoke-test the route by importing the module**

Run: `uv run python -c "from net_alpha.web.routes.portfolio import portfolio_body; print('ok')"`
Expected: `ok`.

- [ ] **Step 15.4: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py
git commit -m "feat(web): wire cash KPIs/points/slice into /portfolio/body context"
```

---

## Task 16: New `_portfolio_cash_curve.html` template

**Files:**
- Create: `src/net_alpha/web/templates/_portfolio_cash_curve.html`

- [ ] **Step 16.1: Inspect the existing equity curve template for style**

Read `src/net_alpha/web/templates/_portfolio_equity_curve.html`. Note:
- Panel header (title + period label)
- Inline SVG chart with explicit viewBox
- Axes drawn via small SVG primitives
- Hover tooltip via Alpine

- [ ] **Step 16.2: Implement the cash-curve template**

Create `src/net_alpha/web/templates/_portfolio_cash_curve.html`. Mirror the equity-curve structure precisely; the only differences are:
1. Two series (solid balance line, dashed contributions line) instead of one.
2. Y-axis spans `min(min(balance), 0)` … `max(max(balance, contrib), 0)` so a negative cash dip (e.g. sweep-out before sweep-in) renders correctly.
3. Empty-state copy: "No cash events yet — import a Schwab CSV to populate."

```jinja
{# _portfolio_cash_curve.html
   Two-series cash chart: running cash balance (solid) + cumulative net
   contributions (dashed). Hover shows the most recent event description.
#}
<div class="panel-header flex items-baseline justify-between">
  <h3>Cash &amp; Contributions</h3>
  <span class="text-[12px] text-label-2">{{ year }}</span>
</div>

{% if not cash_points %}
  <div class="panel-empty text-label-2 text-[13px] py-6 px-2">
    No cash events yet. Import a Schwab Transactions CSV to populate this chart.
  </div>
{% else %}
  {% set min_bal = (cash_points | map(attribute='cash_balance') | map('float') | min) %}
  {% set max_bal = (cash_points | map(attribute='cash_balance') | map('float') | max) %}
  {% set max_contrib = (cash_points | map(attribute='cumulative_contributions') | map('float') | max) %}
  {% set y_max = [max_bal, max_contrib, 0.0] | max %}
  {% set y_min = [min_bal, 0.0] | min %}
  {% set y_span = (y_max - y_min) or 1.0 %}
  {% set n = cash_points | length %}

  <svg viewBox="0 0 480 180" class="w-full h-[180px] mt-2" preserveAspectRatio="none"
       aria-label="Cash balance (solid) vs cumulative contributions (dashed)">
    {# Zero gridline #}
    {% set zero_y = 160 - ((0 - y_min) / y_span) * 140 %}
    <line x1="20" x2="470" y1="{{ zero_y }}" y2="{{ zero_y }}"
          stroke="currentColor" stroke-opacity="0.15" stroke-dasharray="2 4" />

    {# Solid balance polyline #}
    <polyline fill="none" stroke="currentColor" stroke-width="1.5"
      points="{% for p in cash_points -%}
        {% set x = 20 + (loop.index0 / ([n - 1, 1] | max)) * 450 -%}
        {% set y = 160 - ((p.cash_balance | float - y_min) / y_span) * 140 -%}
        {{ x }},{{ y }} {% endfor %}" />

    {# Dashed contributions polyline #}
    <polyline fill="none" stroke="currentColor" stroke-opacity="0.55"
      stroke-width="1.25" stroke-dasharray="4 3"
      points="{% for p in cash_points -%}
        {% set x = 20 + (loop.index0 / ([n - 1, 1] | max)) * 450 -%}
        {% set y = 160 - ((p.cumulative_contributions | float - y_min) / y_span) * 140 -%}
        {{ x }},{{ y }} {% endfor %}" />
  </svg>

  <div class="text-[11px] text-label-3 mt-1 px-2 flex gap-3">
    <span class="inline-flex items-center gap-1">
      <span class="inline-block w-3 h-[2px] bg-current"></span> Cash balance
    </span>
    <span class="inline-flex items-center gap-1">
      <span class="inline-block w-3 h-0 border-t border-dashed border-current"></span> Net contributed
    </span>
  </div>
{% endif %}
```

- [ ] **Step 16.3: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_cash_curve.html
git commit -m "feat(web): add _portfolio_cash_curve.html — balance + contributions chart"
```

---

## Task 17: Update `_portfolio_kpis.html` with cash tiles

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_kpis.html`

- [ ] **Step 17.1: Read the current template**

Run: `cat src/net_alpha/web/templates/_portfolio_kpis.html`
Note its tile structure — likely a grid of small "stat" divs with title + value + subtitle.

- [ ] **Step 17.2: Add three new tiles**

Insert these tiles into the existing KPI grid (place them after the existing P&L tiles; preserve the surrounding `<div class="grid ...">` wrapper). Use whatever class names match the existing tiles (`stat`, `tile`, etc. — discover from the file).

```jinja
{% if cash_kpis is defined %}
  <div class="kpi-tile">
    <div class="kpi-label">Cash</div>
    <div class="kpi-value">{{ "${:,.2f}".format(cash_kpis.cash_balance) }}</div>
    <div class="kpi-subtitle">{{ "{:.0%}".format(cash_kpis.cash_share_pct) }} of account</div>
  </div>

  <div class="kpi-tile">
    <div class="kpi-label">Net contributed</div>
    <div class="kpi-value">{{ "${:,.2f}".format(cash_kpis.net_contributions) }}</div>
    <div class="kpi-subtitle">deposits − withdrawals</div>
  </div>

  <div class="kpi-tile">
    <div class="kpi-label">Growth</div>
    <div class="kpi-value {{ 'text-positive' if cash_kpis.growth >= 0 else 'text-negative' }}">
      {{ "${:,.2f}".format(cash_kpis.growth) }}
    </div>
    <div class="kpi-subtitle">
      {% if cash_kpis.growth_pct is not none %}
        {{ "{:+.1%}".format(cash_kpis.growth_pct) }}
      {% else %}
        no contributions
      {% endif %}
    </div>
  </div>
{% endif %}
```

(Adjust class names to match the file's actual tile pattern — keep the literal CSS classes the existing tiles use.)

- [ ] **Step 17.3: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_kpis.html
git commit -m "feat(web): add Cash / Net contributed / Growth KPI tiles"
```

---

## Task 18: Add cash slice to allocation donut

**Files:**
- Modify: `src/net_alpha/portfolio/allocation.py`
- Modify: `src/net_alpha/web/templates/_portfolio_allocation.html`
- Test: `tests/portfolio/test_allocation.py` (extend)

- [ ] **Step 18.1: Inspect `build_allocation` signature**

Run: `grep -n "def build_allocation" src/net_alpha/portfolio/allocation.py`
Read the function and the existing tests (`tests/portfolio/test_allocation.py`).

- [ ] **Step 18.2: Add a failing test for cash slice**

```python
# tests/portfolio/test_allocation.py — append
from decimal import Decimal as _D

from net_alpha.portfolio.allocation import build_allocation


def test_allocation_includes_cash_slice_when_provided():
    # Construct minimal positions list — adapt to whatever Position shape
    # the existing tests use; here we assume a Position-like dict or model.
    positions = []  # zero positions => cash should be 100% of donut
    alloc = build_allocation(positions=positions, top_n=10, cash=_D("500"))
    cash_rows = [r for r in alloc.rows if r.label == "Cash"]
    assert len(cash_rows) == 1
    assert cash_rows[0].value == _D("500")
    assert cash_rows[0].pct == _D("1.0")
```

(Adjust to the actual `build_allocation` API: if it accepts a `cash: Decimal | None = None` kwarg, the test stands; if not, add the kwarg.)

- [ ] **Step 18.3: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_allocation.py::test_allocation_includes_cash_slice_when_provided -v`
Expected: FAIL on missing `cash` kwarg or absent "Cash" row.

- [ ] **Step 18.4: Extend `build_allocation`**

In `src/net_alpha/portfolio/allocation.py`, add an optional `cash` parameter:

```python
def build_allocation(*, positions, top_n: int = 10, cash: Decimal | None = None):
    # ... existing logic ...
    # After computing per-position rows + percentages:
    if cash is not None and cash != Decimal("0"):
        # Append a Cash row, recompute percentages over (positions_total + cash).
        rows.append(AllocationRow(label="Cash", value=cash, pct=Decimal("0"), color="#888888"))
        total = sum((r.value for r in rows), start=Decimal("0"))
        if total != 0:
            for r in rows:
                r.pct = r.value / total
    return ...
```

(Adjust to actual model field names. The constant color `#888888` matches the spec's "neutral gray".)

- [ ] **Step 18.5: Pass the cash slice from the route**

In `src/net_alpha/web/routes/portfolio.py`'s `portfolio_body`, change:

```python
allocation = build_allocation(positions=positions_for_alloc, top_n=10)
```

to:

```python
allocation = build_allocation(positions=positions_for_alloc, top_n=10, cash=cash_slice)
```

- [ ] **Step 18.6: Run tests**

Run: `uv run pytest tests/portfolio/test_allocation.py -v`
Expected: passing (existing tests must continue to pass with `cash=None`).

- [ ] **Step 18.7: Commit**

```bash
git add src/net_alpha/portfolio/allocation.py src/net_alpha/web/routes/portfolio.py tests/portfolio/test_allocation.py
git commit -m "feat(portfolio): allocation donut shows Cash slice when cash provided"
```

---

## Task 19: Update `_portfolio_body.html` grid layout

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_body.html`

- [ ] **Step 19.1: Replace the body template**

Replace the entire contents of `src/net_alpha/web/templates/_portfolio_body.html` with:

```jinja
{# Bundled portfolio body: KPIs + (equity-curve | cash-curve) + allocation + wash-watch.
   Rendered by /portfolio/body in one shot. #}
<div id="portfolio-kpis" class="mb-4">
  {% include "_portfolio_kpis.html" %}
</div>

{# Top row — two charts side by side #}
<div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1fr;">
  <div id="portfolio-equity" class="panel">
    {% include "_portfolio_equity_curve.html" %}
  </div>
  <div id="portfolio-cash" class="panel">
    {% include "_portfolio_cash_curve.html" %}
  </div>
</div>

{# Allocation moved to its own row, full width #}
<div id="portfolio-allocation" class="panel mb-4">
  {% include "_portfolio_allocation.html" %}
</div>

<div id="portfolio-wash-watch" class="panel mb-4">
  {% include "_portfolio_wash_watch.html" %}
</div>
```

- [ ] **Step 19.2: Manual verification**

Run: `uv run net-alpha ui --port 8765 --no-browser`
In a separate terminal, hit `http://localhost:8765/` (or open in a browser). Confirm:
- KPI strip shows Cash, Net contributed, Growth tiles.
- Top row shows two charts side by side at ~50/50.
- Allocation donut row spans full width below.
- Cash slice appears in the donut.

Stop the server with Ctrl-C.

- [ ] **Step 19.3: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_body.html
git commit -m "feat(web): portfolio body layout — charts row over full-width allocation row"
```

---

## Task 20: Update `_imports_table.html` with `cash_event_count` column

**Files:**
- Modify: `src/net_alpha/web/templates/_imports_table.html`
- Modify: `src/net_alpha/web/templates/_imports_detail_row.html`

- [ ] **Step 20.1: Read the current templates**

Run: `cat src/net_alpha/web/templates/_imports_table.html src/net_alpha/web/templates/_imports_detail_row.html`

- [ ] **Step 20.2: Add a "Cash events" column**

In `_imports_table.html`, find the header row (likely `<th>Trades</th>`) and add a new `<th>` after it:

```jinja
<th class="text-right">Cash events</th>
```

In the matching body row (the one that loops over imports), add:

```jinja
<td class="text-right">{{ s.cash_event_count or 0 }}</td>
```

- [ ] **Step 20.3: Repeat in the detail row template**

In `_imports_detail_row.html`, add a "Cash events" stat alongside the existing trade-count stat. Keep the visual style consistent.

- [ ] **Step 20.4: Manual verification**

Run: `uv run net-alpha imports`
Confirm the listing shows the new column (in CLI output the column is also driven by this surface — adapt `cli/...` if the CLI table is hand-formatted there; if so, see the `cli/` import command and add a column similarly).

Then `uv run net-alpha ui --no-browser` and view `/imports` to confirm the column shows.

- [ ] **Step 20.5: Commit**

```bash
git add src/net_alpha/web/templates/_imports_table.html src/net_alpha/web/templates/_imports_detail_row.html
git commit -m "feat(web): show cash_event_count on imports list and detail row"
```

---

## Task 21: Anonymize the user's two CSVs into test fixtures

**Files:**
- Create: `tests/fixtures/schwab_short_term.csv`
- Create: `tests/fixtures/schwab_long_term.csv`

- [ ] **Step 21.1: Anonymize the ST file**

Run a small Python anonymizer in the repo root. The script masks the account-number digits in the header line; ticker symbols are kept (they're public).

```bash
mkdir -p tests/fixtures
python3 - <<'PY'
import re, pathlib
src = pathlib.Path("private/schwab_st/Short_Term_XXX180_Transactions_20260426-234952.csv").read_text()
# No account number in this CSV body — only in the filename. Nothing to mask.
pathlib.Path("tests/fixtures/schwab_short_term.csv").write_text(src)
print("wrote tests/fixtures/schwab_short_term.csv")
PY
```

- [ ] **Step 21.2: Anonymize the LT file**

```bash
python3 - <<'PY'
import pathlib
src = pathlib.Path("private/schwab_lt/Long_Term_XXX623_Transactions_20260426-234916.csv").read_text()
pathlib.Path("tests/fixtures/schwab_long_term.csv").write_text(src)
print("wrote tests/fixtures/schwab_long_term.csv")
PY
```

- [ ] **Step 21.3: Verify the fixture files exist and have rows**

Run: `wc -l tests/fixtures/schwab_*.csv`
Expected: each file has at least a few hundred lines.

- [ ] **Step 21.4: Commit**

```bash
git add tests/fixtures/
git commit -m "test(fixtures): add anonymized Schwab Short/Long Term Transactions CSVs"
```

---

## Task 22: End-to-end integration test — both CSVs through the full pipeline

**Files:**
- Create: `tests/integration/test_import_cash_events.py`

- [ ] **Step 22.1: Inspect any existing integration test for shape**

Run: `ls tests/integration/ 2>/dev/null && head -80 tests/integration/test_*.py 2>/dev/null | head -80`
Note the harness pattern (in-memory engine vs tempdir DB, how Repository is initialized, how parsers are invoked).

- [ ] **Step 22.2: Write the integration test**

Create `tests/integration/test_import_cash_events.py`:

```python
"""End-to-end: import both real-world Schwab CSV fixtures, verify cash events
land correctly per account, and that imports rm cleans them up."""

from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from sqlalchemy import create_engine
from sqlmodel import SQLModel

from net_alpha.brokers.schwab import SchwabParser
from net_alpha.db.repository import Repository
from net_alpha.models.domain import ImportRecord


FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


def _read_rows(path: Path) -> list[dict[str, str]]:
    with path.open() as f:
        return list(csv.DictReader(f))


def _import(repo: Repository, label: str, rows: list[dict[str, str]]) -> int:
    parser = SchwabParser()
    account = repo.get_or_create_account("Schwab", label)
    result = parser.parse_full(rows, f"Schwab/{label}")
    rec = ImportRecord(
        id=None, account_id=account.id,
        csv_filename=f"{label}.csv", csv_sha256="",
        imported_at=datetime(2026, 4, 26, 12, 0, 0),
        trade_count=0,
    )
    return repo.add_import(account, rec, trades=result.trades, cash_events=result.cash_events).import_id


def test_import_both_csvs_yields_distinct_per_account_cash_events():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    repo = Repository(engine)

    st_rows = _read_rows(FIXTURES / "schwab_short_term.csv")
    lt_rows = _read_rows(FIXTURES / "schwab_long_term.csv")
    st_import = _import(repo, "short_term", st_rows)
    lt_import = _import(repo, "long_term", lt_rows)

    short = repo.list_cash_events(account_id=repo.get_account("Schwab", "short_term").id)
    long = repo.list_cash_events(account_id=repo.get_account("Schwab", "long_term").id)
    assert len(short) > 0
    assert len(long) > 0
    # Per-account isolation
    assert all(e.account == "Schwab/short_term" for e in short)
    assert all(e.account == "Schwab/long_term" for e in long)


def test_all_expected_kinds_present_across_both_csvs():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    repo = Repository(engine)
    _import(repo, "short_term", _read_rows(FIXTURES / "schwab_short_term.csv"))
    _import(repo, "long_term", _read_rows(FIXTURES / "schwab_long_term.csv"))
    kinds = {e.kind for e in repo.list_cash_events()}
    assert "transfer_in" in kinds
    assert "dividend" in kinds
    assert "interest" in kinds
    # ST-only (futures sweep)
    assert "sweep_out" in kinds or "sweep_in" in kinds
    # LT-only (Foreign Tax Paid → fee)
    assert "fee" in kinds


def test_remove_import_isolates_per_account_cleanup():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    repo = Repository(engine)
    st_id = _import(repo, "short_term", _read_rows(FIXTURES / "schwab_short_term.csv"))
    _import(repo, "long_term", _read_rows(FIXTURES / "schwab_long_term.csv"))

    n_long_before = len(repo.list_cash_events(
        account_id=repo.get_account("Schwab", "long_term").id))
    repo.remove_import(st_id)
    n_short_after = len(repo.list_cash_events(
        account_id=repo.get_account("Schwab", "short_term").id))
    n_long_after = len(repo.list_cash_events(
        account_id=repo.get_account("Schwab", "long_term").id))
    assert n_short_after == 0
    assert n_long_after == n_long_before
```

(If `tests/integration/__init__.py` doesn't exist, create it as an empty file.)

- [ ] **Step 22.3: Run the integration tests**

Run: `uv run pytest tests/integration/test_import_cash_events.py -v`
Expected: 3 passing.

- [ ] **Step 22.4: Run the full test suite**

Run: `uv run pytest -x`
Expected: all passing.

- [ ] **Step 22.5: Commit**

```bash
git add tests/integration/
git commit -m "test(integration): cash events round-trip through both Schwab CSV fixtures"
```

---

## Task 23: Lint, full-suite verification, and final visual check

**Files:** none (verification only)

- [ ] **Step 23.1: Lint**

Run: `uv run ruff check . && uv run ruff format --check .`
Expected: clean. If formatter complains, run `uv run ruff format .` and amend the previous commit.

- [ ] **Step 23.2: Full test suite**

Run: `uv run pytest`
Expected: all passing.

- [ ] **Step 23.3: Manual end-to-end check**

```bash
uv run net-alpha ui --port 8765 --no-browser
```

Open `http://localhost:8765/` in a browser. Verify:
1. KPI strip shows Cash / Net contributed / Growth tiles with non-zero values.
2. Top row: P&L curve (left) and Cash + Contributions chart (right), 50/50 width.
3. Cash chart shows a solid line for balance and a dashed line for contributions; legend below.
4. Allocation donut row spans full width and includes a "Cash" slice in neutral gray.
5. Toggling Account in the toolbar (e.g. short_term → long_term) changes all three (KPIs, cash chart, donut) consistently.
6. `/imports` shows a "Cash events" column on each row.

Stop the server with Ctrl-C.

- [ ] **Step 23.4: Final commit (only if any cleanup was needed)**

If you needed to format/cleanup:

```bash
git add -A
git commit -m "chore: ruff format after cash-flow series"
```

Otherwise no action.

---

## Self-Review Notes

- **Spec coverage:** every section of the spec maps to one or more tasks.
  - Data model `cash_events` → Task 2/3
  - `gross_cash_impact` → Task 8
  - Schwab parser mappings (all 13 actions) → Task 9
  - Computation layer functions → Tasks 12, 13, 14
  - Web UI layout → Tasks 15–19
  - Imports table extension → Tasks 10, 20
  - Integration tests with both fixtures → Tasks 21, 22
- **Type consistency:** `gross_cash_impact: float | None` used consistently across `Trade` model, `TradeRow`, parser, repository, and computation layer. `cash` kwarg on `build_allocation` is `Decimal | None`. `period: tuple[int, int] | None` matches the existing `_parse_period` shape used by `equity_curve`.
- **Out-of-scope items** (deferred; will not be implemented in this plan): historical holdings backfill, multi-broker support, separate Cash page, growth-attribution breakdown.
