# Provenance Layer Implementation Plan (Phase 1)

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make every dollar figure in net-alpha drillable, every Schwab G/L number reconcilable against net-alpha's own computation, and every data-quality issue surfaced in the workflow that creates it.

**Architecture:** New `audit/` package with three pure-function modules (`provenance.py`, `reconciliation.py`, `hygiene.py`) plus a broker-G/L abstraction (`audit/brokers/`). One new web router (`audit_routes.py`) exposing three HTMX-fragment endpoints. Templates embed via a Jinja macro. No DB schema changes (Phase 1 reads only). All new code TDD'd against the existing `Repository` + in-memory SQLite pattern.

**Tech Stack:** Python 3.11+, Pydantic v2, FastAPI, Jinja2, HTMX, pytest, factory_boy, sqlmodel.

**Source spec:** `docs/superpowers/specs/2026-04-27-provenance-tax-planner-density-design.md` — Sections 1a, 1b, 1c.

---

## File Structure

### New files

```
src/net_alpha/audit/
├── __init__.py                    # exports public API: provenance_for, reconcile, collect_issues
├── provenance.py                  # MetricRef union, ProvenanceTrace, provenance_for(), encode/decode
├── reconciliation.py              # ReconciliationResult, LotDiff, reconcile(), per_lot_diffs()
├── hygiene.py                     # HygieneIssue, HygieneFixForm, collect_issues()
├── _badge_cache.py                # 30-second TTL cache for nav-badge counts
└── brokers/
    ├── __init__.py
    ├── base.py                    # BrokerLot, BrokerGLProvider ABC
    ├── schwab.py                  # SchwabGLProvider implementation
    └── registry.py                # get_provider_for_account() dispatcher

src/net_alpha/web/routes/
└── audit_routes.py                # GET /provenance/{encoded}, GET /reconciliation/{symbol}, POST /audit/set-basis

src/net_alpha/web/templates/
├── _provenance_macros.html        # provenance_link() macro
├── _provenance_modal.html         # HTMX fragment: contributing trades + adjustments + cash events
├── _reconciliation_strip.html     # top-of-ticker strip
├── _reconciliation_diff.html      # HTMX fragment: per-lot diff table (expanded)
├── _data_hygiene.html             # imports-page section
└── _data_hygiene_set_basis.html   # HTMX fragment: inline fix form

tests/audit/
├── __init__.py
├── conftest.py                    # shared in-memory Repository fixture
├── test_provenance_realized.py
├── test_provenance_unrealized.py
├── test_provenance_wash_impact.py
├── test_provenance_cash.py
├── test_provenance_net_contributed.py
├── test_metric_ref_encoding.py
├── test_brokers_schwab.py
├── test_reconciliation.py
├── test_per_lot_diff.py
├── test_hygiene_unpriced.py
├── test_hygiene_basis_unknown.py
├── test_hygiene_orphan_sell.py
├── test_hygiene_dup_key.py
└── test_badge_cache.py

tests/web/
├── test_provenance_route.py
├── test_reconciliation_route.py
├── test_data_hygiene_section.py
└── test_nav_badge.py
```

### Modified files

```
src/net_alpha/web/app.py                          # register audit_routes
src/net_alpha/web/dependencies.py                 # add get_audit_badge_count
src/net_alpha/web/templates/base.html             # Imports nav-link gets badge
src/net_alpha/web/templates/_portfolio_kpis.html  # wrap KPI numbers with provenance_link
src/net_alpha/web/templates/ticker.html           # add reconciliation strip + provenance links
src/net_alpha/web/templates/imports.html          # embed _data_hygiene above import list
```

### Out of scope for Phase 1 (deferred)

- Hygiene categories `low_parse` (requires Trade.parse_confidence field — not in current schema) and `tax_config_missing` (requires Phase 2 tax config). The `HygieneIssue.category` Literal in Phase 1 includes only `unpriced | basis_unknown | orphan_sell | dup_key`. Phase 2 widens it.
- Wiring provenance into `/holdings` rows. Phase 1 wires only `/portfolio` KPIs and `/ticker/{symbol}` numbers (the highest-value drill-downs). `/holdings` provenance lands when Phase 3 (Density) reorders that page.
- `etf_replacements.yaml` / harvest queue / tax planner — Phase 2.

---

## Task Sequence

Tasks are ordered so every commit leaves the tree green. Each task is one logical TDD cycle (write failing test → minimal impl → confirm pass → commit). Section 1a runs first (foundation — provenance is referenced by 1b reconciliation reasoning), then 1b, then 1c.

---

### Task 1: Set up `audit/` package skeleton

**Files:**
- Create: `src/net_alpha/audit/__init__.py`
- Create: `src/net_alpha/audit/brokers/__init__.py`
- Create: `tests/audit/__init__.py`
- Create: `tests/audit/conftest.py`

- [ ] **Step 1: Create empty package files**

```python
# src/net_alpha/audit/__init__.py
"""Audit subsystem: provenance, reconciliation, data hygiene.

All public API re-exported here for stable import paths.
"""
```

```python
# src/net_alpha/audit/brokers/__init__.py
```

```python
# tests/audit/__init__.py
```

- [ ] **Step 2: Write shared test fixture for an in-memory Repository**

```python
# tests/audit/conftest.py
from __future__ import annotations

import pytest
from sqlmodel import Session

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository


@pytest.fixture
def repo(tmp_path) -> Repository:
    """A clean Repository backed by a tmp_path SQLite DB."""
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    return Repository(engine)


@pytest.fixture
def schwab_account(repo: Repository):
    """A pre-created Schwab account row for tests that need an account_id."""
    return repo.get_or_create_account(broker="Schwab", label="Tax")
```

- [ ] **Step 3: Verify pytest collects the new package**

Run: `uv run pytest tests/audit -v --collect-only`
Expected: 0 tests collected (no test files yet) but no collection errors.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/audit/__init__.py src/net_alpha/audit/brokers/__init__.py tests/audit/__init__.py tests/audit/conftest.py
git commit -m "feat(audit): scaffold audit package with shared test fixture"
```

---

### Task 2: Define `MetricRef` Pydantic union + `ProvenanceTrace`

**Files:**
- Create: `src/net_alpha/audit/provenance.py`
- Create: `tests/audit/test_metric_ref_encoding.py`

- [ ] **Step 1: Write the failing test for MetricRef discrimination**

```python
# tests/audit/test_metric_ref_encoding.py
from datetime import date

from net_alpha.audit.provenance import (
    CashRef,
    NetContributedRef,
    Period,
    RealizedPLRef,
    UnrealizedPLRef,
    WashImpactRef,
    decode_metric_ref,
    encode_metric_ref,
)


def test_realized_ref_round_trip():
    ref = RealizedPLRef(
        kind="realized_pl",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=1,
        symbol="AAPL",
    )
    encoded = encode_metric_ref(ref)
    decoded = decode_metric_ref(encoded)
    assert decoded == ref
    assert isinstance(decoded, RealizedPLRef)


def test_unrealized_ref_round_trip():
    ref = UnrealizedPLRef(kind="unrealized_pl", account_id=None, symbol=None)
    assert decode_metric_ref(encode_metric_ref(ref)) == ref


def test_wash_impact_ref_round_trip():
    ref = WashImpactRef(
        kind="wash_impact",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=2,
    )
    assert decode_metric_ref(encode_metric_ref(ref)) == ref


def test_cash_ref_round_trip():
    ref = CashRef(kind="cash", account_id=None)
    assert decode_metric_ref(encode_metric_ref(ref)) == ref


def test_net_contributed_ref_round_trip():
    ref = NetContributedRef(
        kind="net_contributed",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=None,
    )
    assert decode_metric_ref(encode_metric_ref(ref)) == ref


def test_decode_rejects_garbage():
    import pytest

    with pytest.raises(ValueError):
        decode_metric_ref("not-a-valid-encoding")
```

- [ ] **Step 2: Run the tests and confirm failure**

Run: `uv run pytest tests/audit/test_metric_ref_encoding.py -v`
Expected: ImportError or ModuleNotFoundError for `net_alpha.audit.provenance`.

- [ ] **Step 3: Implement MetricRef union + encoding**

```python
# src/net_alpha/audit/provenance.py
"""Provenance: 'why is this number what it is?' for every KPI in the app.

`MetricRef` is a discriminated Pydantic union; one variant per drillable metric
type. `provenance_for(metric_ref, repo)` returns a `ProvenanceTrace` containing
the trades, wash-sale adjustments, and cash events that produced the number.
The trace is rendered as an HTMX modal fragment.
"""

from __future__ import annotations

import base64
import json
from datetime import date
from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, TypeAdapter, ValidationError


class Period(BaseModel):
    """A date window for KPI scoping. ``end`` is exclusive."""

    start: date
    end: date
    label: str  # e.g. "YTD 2026", "Lifetime", "2025"


class RealizedPLRef(BaseModel):
    kind: Literal["realized_pl"]
    period: Period
    account_id: int | None  # None = aggregate across accounts
    symbol: str | None       # None = aggregate across symbols


class UnrealizedPLRef(BaseModel):
    kind: Literal["unrealized_pl"]
    account_id: int | None
    symbol: str | None


class WashImpactRef(BaseModel):
    kind: Literal["wash_impact"]
    period: Period
    account_id: int | None


class CashRef(BaseModel):
    kind: Literal["cash"]
    account_id: int | None


class NetContributedRef(BaseModel):
    kind: Literal["net_contributed"]
    period: Period
    account_id: int | None


MetricRef = Annotated[
    Union[RealizedPLRef, UnrealizedPLRef, WashImpactRef, CashRef, NetContributedRef],
    Field(discriminator="kind"),
]

_metric_ref_adapter: TypeAdapter[MetricRef] = TypeAdapter(MetricRef)


def encode_metric_ref(ref: MetricRef) -> str:
    """Serialize a MetricRef to a URL-safe base64 string for the route path."""
    payload = _metric_ref_adapter.dump_json(ref).decode("utf-8")
    return base64.urlsafe_b64encode(payload.encode("utf-8")).decode("ascii").rstrip("=")


def decode_metric_ref(encoded: str) -> MetricRef:
    """Inverse of encode_metric_ref. Raises ValueError on invalid input."""
    try:
        padded = encoded + "=" * (-len(encoded) % 4)
        payload = base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")
        data = json.loads(payload)
        return _metric_ref_adapter.validate_python(data)
    except (ValueError, ValidationError, UnicodeDecodeError) as e:
        raise ValueError(f"invalid metric ref: {e}") from e
```

- [ ] **Step 4: Run tests, confirm pass**

Run: `uv run pytest tests/audit/test_metric_ref_encoding.py -v`
Expected: 6 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/provenance.py tests/audit/test_metric_ref_encoding.py
git commit -m "feat(audit): add MetricRef discriminated union + base64 encoding"
```

---

### Task 3: Define `ProvenanceTrace` data type

**Files:**
- Modify: `src/net_alpha/audit/provenance.py`

- [ ] **Step 1: Append ProvenanceTrace types to provenance.py**

```python
# Append to src/net_alpha/audit/provenance.py


class ContributingTrade(BaseModel):
    trade_id: str
    trade_date: date
    account: str
    action: str       # "Buy" | "Sell"
    quantity: float
    amount: float     # signed: positive for proceeds, negative for cost
    symbol: str
    import_id: int | None


class AppliedAdjustment(BaseModel):
    """A wash-sale basis transfer applied to one of the contributing trades."""

    violation_id: str
    loss_trade_id: str
    replacement_trade_id: str
    rolled_amount: float          # disallowed loss rolled into replacement basis
    confidence: str               # "Confirmed" | "Probable" | "Unclear"
    rule_citation: str = "IRS Pub 550 §1091 — 30-day window"


class ContributingCashEvent(BaseModel):
    event_id: str
    event_date: date
    account: str
    kind: str                      # transfer_in | transfer_out | dividend | interest | fee | sweep_in | sweep_out
    amount: float                  # signed
    description: str = ""


class ProvenanceTrace(BaseModel):
    """The complete 'why is this number what it is' record for one MetricRef."""

    metric_label: str              # human-readable, e.g. "YTD 2026 Realized P/L · AAPL"
    total: float                   # the number the user sees on the page
    trades: list[ContributingTrade] = Field(default_factory=list)
    adjustments: list[AppliedAdjustment] = Field(default_factory=list)
    cash_events: list[ContributingCashEvent] = Field(default_factory=list)
```

- [ ] **Step 2: Write a test confirming the types compose**

```python
# tests/audit/test_provenance_trace_shape.py
from datetime import date

from net_alpha.audit.provenance import (
    AppliedAdjustment,
    ContributingTrade,
    ProvenanceTrace,
)


def test_provenance_trace_serializes():
    trace = ProvenanceTrace(
        metric_label="YTD 2026 Realized P/L · AAPL",
        total=702.54,
        trades=[
            ContributingTrade(
                trade_id="t1",
                trade_date=date(2026, 1, 15),
                account="Schwab/Tax",
                action="Sell",
                quantity=10.0,
                amount=1500.0,
                symbol="AAPL",
                import_id=1,
            )
        ],
        adjustments=[
            AppliedAdjustment(
                violation_id="v1",
                loss_trade_id="t1",
                replacement_trade_id="t2",
                rolled_amount=120.0,
                confidence="Confirmed",
            )
        ],
    )
    dumped = trace.model_dump()
    assert dumped["metric_label"].startswith("YTD")
    assert len(dumped["trades"]) == 1
    assert dumped["adjustments"][0]["rule_citation"].startswith("IRS Pub 550")
```

- [ ] **Step 3: Run test, confirm pass**

Run: `uv run pytest tests/audit/test_provenance_trace_shape.py -v`
Expected: 1 test passes.

- [ ] **Step 4: Commit**

```bash
git add src/net_alpha/audit/provenance.py tests/audit/test_provenance_trace_shape.py
git commit -m "feat(audit): add ProvenanceTrace, ContributingTrade, AppliedAdjustment types"
```

---

### Task 4: `provenance_for(RealizedPLRef, repo)` — realized P/L variant

**Files:**
- Modify: `src/net_alpha/audit/provenance.py`
- Create: `tests/audit/test_provenance_realized.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_provenance_realized.py
from datetime import date

from net_alpha.audit.provenance import Period, RealizedPLRef, provenance_for
from net_alpha.models.domain import Trade


def test_realized_provenance_filters_by_period_and_symbol(repo, schwab_account):
    # Two AAPL sells (one in scope, one out), one MSFT sell (different symbol).
    trades_in = [
        Trade(account="Schwab/Tax", date=date(2026, 3, 1), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=1000.0),
        Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
              action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        Trade(account="Schwab/Tax", date=date(2025, 12, 1), ticker="AAPL",
              action="Sell", quantity=5, proceeds=600.0, cost_basis=400.0),
        Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="MSFT",
              action="Sell", quantity=5, proceeds=2000.0, cost_basis=1500.0),
    ]
    repo.add_import(
        trades=trades_in,
        cash_events=[],
        account_id=schwab_account.id,
        csv_filename="t.csv",
        csv_sha256="h",
    )

    ref = RealizedPLRef(
        kind="realized_pl",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=schwab_account.id,
        symbol="AAPL",
    )
    trace = provenance_for(ref, repo)

    # Exactly one in-scope sell (2026-04-01 AAPL), realized = 500.
    assert len(trace.trades) == 1
    assert trace.trades[0].symbol == "AAPL"
    assert trace.trades[0].action == "Sell"
    assert trace.total == 500.0


def test_realized_provenance_aggregate_account(repo, schwab_account):
    # account_id=None means aggregate across accounts.
    trades = [
        Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
              action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
    ]
    repo.add_import(
        trades=trades, cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )

    ref = RealizedPLRef(
        kind="realized_pl",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=None,
        symbol=None,
    )
    trace = provenance_for(ref, repo)
    assert trace.total == 500.0
    assert len(trace.trades) == 1
```

- [ ] **Step 2: Run the test, confirm failure**

Run: `uv run pytest tests/audit/test_provenance_realized.py -v`
Expected: ImportError for `provenance_for` (not yet defined).

- [ ] **Step 3: Implement `provenance_for` with RealizedPLRef variant**

Append to `src/net_alpha/audit/provenance.py`:

```python
# Append to src/net_alpha/audit/provenance.py

from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade


def provenance_for(metric: MetricRef, repo: Repository) -> ProvenanceTrace:
    """Return the trades / adjustments / cash events that produced ``metric``.

    Dispatches on the discriminator field. Raises ``KeyError`` if a new
    MetricRef variant is added without a matching dispatch — caller surfaces
    this as the modal's failure block.
    """
    if isinstance(metric, RealizedPLRef):
        return _realized_pl(metric, repo)
    raise KeyError(f"no provenance dispatcher for {metric.kind!r}")


def _trade_in_period(t: Trade, period: Period) -> bool:
    return period.start <= t.date < period.end


def _trade_account_match(t: Trade, account_id: int | None, repo: Repository) -> bool:
    if account_id is None:
        return True
    # Trade.account is the display string; convert to id via repo.list_accounts().
    accounts = {a.label and f"{a.broker}/{a.label}" or a.broker: a.id for a in repo.list_accounts()}
    return accounts.get(t.account) == account_id


def _to_contributing(t: Trade, import_id: int | None) -> ContributingTrade:
    amount = (t.proceeds or 0.0) if t.action.lower() == "sell" else -(t.cost_basis or 0.0)
    return ContributingTrade(
        trade_id=t.id,
        trade_date=t.date,
        account=t.account,
        action=t.action,
        quantity=t.quantity,
        amount=amount,
        symbol=t.ticker,
        import_id=import_id,
    )


def _realized_pl(metric: RealizedPLRef, repo: Repository) -> ProvenanceTrace:
    contributing: list[ContributingTrade] = []
    total = 0.0
    for t in repo.all_trades():
        if t.action.lower() != "sell":
            continue
        if not _trade_in_period(t, metric.period):
            continue
        if metric.symbol is not None and t.ticker != metric.symbol:
            continue
        if not _trade_account_match(t, metric.account_id, repo):
            continue
        realized = (t.proceeds or 0.0) - (t.cost_basis or 0.0)
        total += realized
        contributing.append(_to_contributing(t, import_id=None))

    label_bits = [metric.period.label, "Realized P/L"]
    if metric.symbol:
        label_bits.append(f"· {metric.symbol}")
    return ProvenanceTrace(
        metric_label=" ".join(label_bits),
        total=round(total, 2),
        trades=contributing,
    )
```

- [ ] **Step 4: Run the test, confirm pass**

Run: `uv run pytest tests/audit/test_provenance_realized.py -v`
Expected: 2 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/provenance.py tests/audit/test_provenance_realized.py
git commit -m "feat(audit): provenance_for handles RealizedPLRef variant"
```

---

### Task 5: `provenance_for(UnrealizedPLRef, repo)` variant

**Files:**
- Modify: `src/net_alpha/audit/provenance.py`
- Create: `tests/audit/test_provenance_unrealized.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_provenance_unrealized.py
from datetime import date

from net_alpha.audit.provenance import UnrealizedPLRef, provenance_for
from net_alpha.models.domain import Trade


def test_unrealized_provenance_lists_open_lot_buys(repo, schwab_account):
    # Two buys, one full sell that consumes nothing — both buys remain open.
    trades = [
        Trade(account="Schwab/Tax", date=date(2026, 1, 15), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=1000.0),
        Trade(account="Schwab/Tax", date=date(2026, 2, 1), ticker="AAPL",
              action="Buy", quantity=5, cost_basis=520.0),
    ]
    repo.add_import(
        trades=trades, cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )

    ref = UnrealizedPLRef(kind="unrealized_pl", account_id=schwab_account.id, symbol="AAPL")
    trace = provenance_for(ref, repo)

    # Two contributing buys.
    assert len(trace.trades) == 2
    assert all(t.action == "Buy" for t in trace.trades)
    assert all(t.symbol == "AAPL" for t in trace.trades)
    # Total is the adjusted basis of open lots (no price-side computation here;
    # provenance shows what *makes up* the basis side of unrealized).
    # Expected: 1000 + 520 = 1520 (negative since these are cost-side amounts).
    assert trace.total == -1520.0
```

- [ ] **Step 2: Run the test, confirm failure**

Run: `uv run pytest tests/audit/test_provenance_unrealized.py -v`
Expected: KeyError ("no provenance dispatcher for 'unrealized_pl'").

- [ ] **Step 3: Add the variant**

In `src/net_alpha/audit/provenance.py`, extend `provenance_for`:

```python
# In provenance_for, add the next branch:
    if isinstance(metric, UnrealizedPLRef):
        return _unrealized_pl(metric, repo)
```

Append:

```python
def _unrealized_pl(metric: UnrealizedPLRef, repo: Repository) -> ProvenanceTrace:
    """Open lots' contributing buys (cost basis side of unrealized math).

    Note: unrealized P/L = market_value − adjusted_basis. This trace surfaces
    the adjusted_basis component (the trades) — the price/market component is
    a single "today" quote and isn't a 'trade' to provenance against.
    """
    contributing: list[ContributingTrade] = []
    total = 0.0
    for lot in repo.all_lots():
        if metric.symbol is not None and lot.ticker != metric.symbol:
            continue
        if not _account_id_match(lot.account, metric.account_id, repo):
            continue
        # The lot was created by the buy trade with id == lot.trade_id.
        buy = next((t for t in repo.all_trades() if t.id == lot.trade_id), None)
        if buy is None:
            continue
        contributing.append(
            ContributingTrade(
                trade_id=buy.id,
                trade_date=buy.date,
                account=buy.account,
                action="Buy",
                quantity=lot.quantity,
                amount=-lot.adjusted_basis,
                symbol=lot.ticker,
                import_id=None,
            )
        )
        total -= lot.adjusted_basis

    label_bits = ["Unrealized P/L"]
    if metric.symbol:
        label_bits.append(f"· {metric.symbol}")
    return ProvenanceTrace(
        metric_label=" ".join(label_bits),
        total=round(total, 2),
        trades=contributing,
    )


def _account_id_match(account_display: str, account_id: int | None, repo: Repository) -> bool:
    """Same logic as _trade_account_match but for Lot.account / display strings."""
    if account_id is None:
        return True
    for a in repo.list_accounts():
        full = f"{a.broker}/{a.label}" if a.label else a.broker
        if full == account_display and a.id == account_id:
            return True
    return False
```

- [ ] **Step 4: Run the test, confirm pass**

Run: `uv run pytest tests/audit/test_provenance_unrealized.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/provenance.py tests/audit/test_provenance_unrealized.py
git commit -m "feat(audit): provenance_for handles UnrealizedPLRef variant"
```

---

### Task 6: `provenance_for(WashImpactRef, repo)` variant

**Files:**
- Modify: `src/net_alpha/audit/provenance.py`
- Create: `tests/audit/test_provenance_wash_impact.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_provenance_wash_impact.py
from datetime import date

from net_alpha.audit.provenance import Period, WashImpactRef, provenance_for
from net_alpha.models.domain import Trade, WashSaleViolation


def test_wash_impact_provenance_lists_violations_in_period(repo, schwab_account):
    trades = [
        Trade(id="loss-1", account="Schwab/Tax", date=date(2026, 3, 1), ticker="AAPL",
              action="Sell", quantity=10, proceeds=900.0, cost_basis=1000.0),
        Trade(id="repl-1", account="Schwab/Tax", date=date(2026, 3, 15), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=950.0),
    ]
    repo.add_import(
        trades=trades, cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )
    repo.replace_violations_in_window(
        date(2026, 1, 1), date(2027, 1, 1),
        [WashSaleViolation(
            id="v1",
            loss_trade_id="loss-1",
            replacement_trade_id="repl-1",
            confidence="Confirmed",
            disallowed_loss=100.0,
            matched_quantity=10.0,
            loss_account="Schwab/Tax",
            buy_account="Schwab/Tax",
            loss_sale_date=date(2026, 3, 1),
            triggering_buy_date=date(2026, 3, 15),
            ticker="AAPL",
        )],
    )

    ref = WashImpactRef(
        kind="wash_impact",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=schwab_account.id,
    )
    trace = provenance_for(ref, repo)
    assert trace.total == 100.0
    assert len(trace.adjustments) == 1
    assert trace.adjustments[0].rolled_amount == 100.0
    assert trace.adjustments[0].confidence == "Confirmed"
    assert "Pub 550" in trace.adjustments[0].rule_citation
```

- [ ] **Step 2: Run the test, confirm failure**

Run: `uv run pytest tests/audit/test_provenance_wash_impact.py -v`
Expected: KeyError ("no provenance dispatcher for 'wash_impact'").

- [ ] **Step 3: Add the variant**

In `provenance_for`, add:

```python
    if isinstance(metric, WashImpactRef):
        return _wash_impact(metric, repo)
```

Append:

```python
def _wash_impact(metric: WashImpactRef, repo: Repository) -> ProvenanceTrace:
    adjustments: list[AppliedAdjustment] = []
    total = 0.0
    for v in repo.all_violations():
        if v.loss_sale_date is None or not (
            metric.period.start <= v.loss_sale_date < metric.period.end
        ):
            continue
        if metric.account_id is not None:
            # Either side of the violation must belong to the scoped account.
            scoped = _account_display_for_id(metric.account_id, repo)
            if scoped not in (v.loss_account, v.buy_account):
                continue
        total += v.disallowed_loss
        adjustments.append(
            AppliedAdjustment(
                violation_id=v.id,
                loss_trade_id=v.loss_trade_id,
                replacement_trade_id=v.replacement_trade_id,
                rolled_amount=v.disallowed_loss,
                confidence=v.confidence,
            )
        )
    return ProvenanceTrace(
        metric_label=f"{metric.period.label} Wash Impact",
        total=round(total, 2),
        adjustments=adjustments,
    )


def _account_display_for_id(account_id: int, repo: Repository) -> str:
    for a in repo.list_accounts():
        if a.id == account_id:
            return f"{a.broker}/{a.label}" if a.label else a.broker
    return ""
```

- [ ] **Step 4: Run test, confirm pass**

Run: `uv run pytest tests/audit/test_provenance_wash_impact.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/provenance.py tests/audit/test_provenance_wash_impact.py
git commit -m "feat(audit): provenance_for handles WashImpactRef variant"
```

---

### Task 7: `provenance_for(CashRef, repo)` and `(NetContributedRef, repo)` variants

These two are symmetric (both surface cash events) so they ship together.

**Files:**
- Modify: `src/net_alpha/audit/provenance.py`
- Create: `tests/audit/test_provenance_cash.py`
- Create: `tests/audit/test_provenance_net_contributed.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/audit/test_provenance_cash.py
from datetime import date

from net_alpha.audit.provenance import CashRef, provenance_for
from net_alpha.models.domain import CashEvent


def test_cash_provenance_lists_all_events(repo, schwab_account):
    events = [
        CashEvent(account="Schwab/Tax", event_date=date(2026, 1, 5),
                  kind="transfer_in", amount=10000.0),
        CashEvent(account="Schwab/Tax", event_date=date(2026, 2, 1),
                  kind="dividend", amount=42.0, ticker="AAPL"),
    ]
    repo.add_import(
        trades=[], cash_events=events, account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )

    ref = CashRef(kind="cash", account_id=schwab_account.id)
    trace = provenance_for(ref, repo)
    assert len(trace.cash_events) == 2
    assert trace.total == 10042.0
```

```python
# tests/audit/test_provenance_net_contributed.py
from datetime import date

from net_alpha.audit.provenance import NetContributedRef, Period, provenance_for
from net_alpha.models.domain import CashEvent


def test_net_contributed_only_includes_transfers(repo, schwab_account):
    events = [
        CashEvent(account="Schwab/Tax", event_date=date(2026, 1, 5),
                  kind="transfer_in", amount=10000.0),
        CashEvent(account="Schwab/Tax", event_date=date(2026, 2, 1),
                  kind="dividend", amount=42.0),
        CashEvent(account="Schwab/Tax", event_date=date(2026, 3, 1),
                  kind="transfer_out", amount=2000.0),
    ]
    repo.add_import(
        trades=[], cash_events=events, account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )

    ref = NetContributedRef(
        kind="net_contributed",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=schwab_account.id,
    )
    trace = provenance_for(ref, repo)
    # Net contributed = transfer_in − transfer_out; dividend excluded.
    assert trace.total == 8000.0
    kinds = {e.kind for e in trace.cash_events}
    assert kinds == {"transfer_in", "transfer_out"}
```

- [ ] **Step 2: Run tests, confirm failure**

Run: `uv run pytest tests/audit/test_provenance_cash.py tests/audit/test_provenance_net_contributed.py -v`
Expected: KeyError on both.

- [ ] **Step 3: Implement both variants**

In `provenance_for` add:

```python
    if isinstance(metric, CashRef):
        return _cash(metric, repo)
    if isinstance(metric, NetContributedRef):
        return _net_contributed(metric, repo)
```

Append:

```python
_TRANSFER_KINDS = frozenset({"transfer_in", "transfer_out"})


def _cash_event_account_match(ev_account: str, account_id: int | None, repo: Repository) -> bool:
    if account_id is None:
        return True
    return _account_id_match(ev_account, account_id, repo)


def _to_contributing_cash(ev) -> ContributingCashEvent:
    sign = -1.0 if ev.kind in {"transfer_out", "fee", "sweep_out"} else 1.0
    return ContributingCashEvent(
        event_id=ev.id,
        event_date=ev.event_date,
        account=ev.account,
        kind=ev.kind,
        amount=sign * ev.amount,
        description=ev.description,
    )


def _cash(metric: CashRef, repo: Repository) -> ProvenanceTrace:
    events = []
    total = 0.0
    for ev in repo.list_cash_events(account_id=metric.account_id):
        contrib = _to_contributing_cash(ev)
        events.append(contrib)
        total += contrib.amount
    return ProvenanceTrace(
        metric_label="Cash balance",
        total=round(total, 2),
        cash_events=events,
    )


def _net_contributed(metric: NetContributedRef, repo: Repository) -> ProvenanceTrace:
    events = []
    total = 0.0
    for ev in repo.list_cash_events(account_id=metric.account_id):
        if ev.kind not in _TRANSFER_KINDS:
            continue
        if not (metric.period.start <= ev.event_date < metric.period.end):
            continue
        contrib = _to_contributing_cash(ev)
        events.append(contrib)
        total += contrib.amount
    return ProvenanceTrace(
        metric_label=f"{metric.period.label} Net Contributed",
        total=round(total, 2),
        cash_events=events,
    )
```

- [ ] **Step 4: Run tests, confirm pass**

Run: `uv run pytest tests/audit/test_provenance_cash.py tests/audit/test_provenance_net_contributed.py -v`
Expected: 2 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/provenance.py tests/audit/test_provenance_cash.py tests/audit/test_provenance_net_contributed.py
git commit -m "feat(audit): provenance_for handles CashRef and NetContributedRef variants"
```

---

### Task 8: Re-export public API from `audit/__init__.py`

**Files:**
- Modify: `src/net_alpha/audit/__init__.py`

- [ ] **Step 1: Write a smoke test for the re-export**

```python
# tests/audit/test_public_api.py
def test_public_api_imports():
    from net_alpha.audit import (
        ProvenanceTrace,
        decode_metric_ref,
        encode_metric_ref,
        provenance_for,
    )

    assert callable(provenance_for)
    assert callable(encode_metric_ref)
    assert callable(decode_metric_ref)
    assert ProvenanceTrace.__name__ == "ProvenanceTrace"
```

- [ ] **Step 2: Run the test, confirm failure**

Run: `uv run pytest tests/audit/test_public_api.py -v`
Expected: ImportError.

- [ ] **Step 3: Update `__init__.py`**

```python
# src/net_alpha/audit/__init__.py
"""Audit subsystem: provenance, reconciliation, data hygiene.

All public API re-exported here for stable import paths.
"""

from net_alpha.audit.provenance import (
    AppliedAdjustment,
    CashRef,
    ContributingCashEvent,
    ContributingTrade,
    MetricRef,
    NetContributedRef,
    Period,
    ProvenanceTrace,
    RealizedPLRef,
    UnrealizedPLRef,
    WashImpactRef,
    decode_metric_ref,
    encode_metric_ref,
    provenance_for,
)

__all__ = [
    "AppliedAdjustment",
    "CashRef",
    "ContributingCashEvent",
    "ContributingTrade",
    "MetricRef",
    "NetContributedRef",
    "Period",
    "ProvenanceTrace",
    "RealizedPLRef",
    "UnrealizedPLRef",
    "WashImpactRef",
    "decode_metric_ref",
    "encode_metric_ref",
    "provenance_for",
]
```

- [ ] **Step 4: Run test, confirm pass**

Run: `uv run pytest tests/audit/test_public_api.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Run the full audit test suite**

Run: `uv run pytest tests/audit -v`
Expected: All tests so far pass (Tasks 2–8).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/audit/__init__.py tests/audit/test_public_api.py
git commit -m "feat(audit): re-export public API from package root"
```

---

### Task 9: GET /provenance/{encoded} HTMX route

**Files:**
- Create: `src/net_alpha/web/routes/audit_routes.py`
- Modify: `src/net_alpha/web/app.py`
- Create: `tests/web/test_provenance_route.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_provenance_route.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.audit.provenance import Period, RealizedPLRef, encode_metric_ref
from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade
from net_alpha.web.app import create_app


def _seed(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    repo = Repository(engine)
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                      action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0)],
        cash_events=[],
        account_id=acct.id,
        csv_filename="t.csv",
        csv_sha256="h",
    )
    return acct


def test_provenance_route_returns_modal_fragment(tmp_path):
    acct = _seed(tmp_path)
    client = TestClient(create_app(Settings(data_dir=tmp_path)))
    ref = RealizedPLRef(
        kind="realized_pl",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=acct.id,
        symbol="AAPL",
    )
    encoded = encode_metric_ref(ref)
    resp = client.get(f"/provenance/{encoded}")
    assert resp.status_code == 200
    assert "$500.00" in resp.text or "500.00" in resp.text
    assert "AAPL" in resp.text


def test_provenance_route_handles_garbage_id(tmp_path):
    client = TestClient(create_app(Settings(data_dir=tmp_path)))
    resp = client.get("/provenance/not-a-ref")
    # Renders error fragment, not a 5xx — modal must always succeed.
    assert resp.status_code == 200
    assert "Couldn't reconstruct trace" in resp.text
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_provenance_route.py -v`
Expected: 404 (route not registered yet).

- [ ] **Step 3: Implement the route**

```python
# src/net_alpha/web/routes/audit_routes.py
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse

from net_alpha.audit import decode_metric_ref, provenance_for
from net_alpha.db.repository import Repository
from net_alpha.web.dependencies import get_repository

router = APIRouter()
log = logging.getLogger(__name__)


@router.get("/provenance/{encoded}", response_class=HTMLResponse)
def provenance_modal(
    encoded: str,
    request: Request,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    """HTMX fragment: provenance trace for one MetricRef.

    Always returns 200; failures render an error block inside the modal so the
    rest of the page is unaffected.
    """
    try:
        ref = decode_metric_ref(encoded)
        trace = provenance_for(ref, repo)
    except Exception as e:  # noqa: BLE001 — defensive: never bubble to 5xx
        log.exception("provenance trace failed: %s", e)
        return request.app.state.templates.TemplateResponse(
            request,
            "_provenance_modal.html",
            {"trace": None, "error": str(e)},
        )
    return request.app.state.templates.TemplateResponse(
        request,
        "_provenance_modal.html",
        {"trace": trace, "error": None},
    )
```

- [ ] **Step 4: Register the router in `app.py`**

In `src/net_alpha/web/app.py`, modify the `from net_alpha.web.routes import ...` line to add `audit_routes`:

```python
from net_alpha.web.routes import audit_routes, holdings, sim, system, ticker, trades, wash_sales
```

And add the registration call where other routers are registered (find `app.include_router(...)` calls and add):

```python
app.include_router(audit_routes.router)
```

- [ ] **Step 5: Create a placeholder `_provenance_modal.html`**

```html
{# src/net_alpha/web/templates/_provenance_modal.html — placeholder; full
   styling comes in Task 10. This is enough for the route test to pass. #}
{% if error %}
  <div class="text-neg">Couldn't reconstruct trace — file a bug.</div>
  <div class="text-label-3 text-xs">{{ error }}</div>
{% else %}
  <div data-testid="provenance-trace">
    <h3>{{ trace.metric_label }}</h3>
    <div class="num">${{ "%.2f"|format(trace.total) }}</div>
    {% if trace.trades %}
      <ul>
        {% for t in trace.trades %}
          <li>{{ t.trade_date }} · {{ t.symbol }} · {{ t.action }} · ${{ "%.2f"|format(t.amount) }}</li>
        {% endfor %}
      </ul>
    {% endif %}
  </div>
{% endif %}
```

- [ ] **Step 6: Run, confirm pass**

Run: `uv run pytest tests/web/test_provenance_route.py -v`
Expected: 2 tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/audit_routes.py src/net_alpha/web/app.py src/net_alpha/web/templates/_provenance_modal.html tests/web/test_provenance_route.py
git commit -m "feat(audit): GET /provenance/{encoded} returns trace fragment with error fallback"
```

---

### Task 10: Full `_provenance_modal.html` template (3 sections)

**Files:**
- Modify: `src/net_alpha/web/templates/_provenance_modal.html`

- [ ] **Step 1: Write a render test for the three blocks**

```python
# tests/web/test_provenance_modal_render.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.audit.provenance import Period, RealizedPLRef, WashImpactRef, encode_metric_ref
from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade, WashSaleViolation
from net_alpha.web.app import create_app


def test_modal_renders_trades_and_adjustments(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[
            Trade(id="loss-1", account="Schwab/Tax", date=date(2026, 3, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=900.0, cost_basis=1000.0),
            Trade(id="repl-1", account="Schwab/Tax", date=date(2026, 3, 15), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=950.0),
        ],
        cash_events=[],
        account_id=acct.id,
        csv_filename="t.csv",
        csv_sha256="h",
    )
    repo.replace_violations_in_window(
        date(2026, 1, 1), date(2027, 1, 1),
        [WashSaleViolation(
            id="v1", loss_trade_id="loss-1", replacement_trade_id="repl-1",
            confidence="Confirmed", disallowed_loss=100.0, matched_quantity=10.0,
            loss_account="Schwab/Tax", buy_account="Schwab/Tax",
            loss_sale_date=date(2026, 3, 1), triggering_buy_date=date(2026, 3, 15),
            ticker="AAPL",
        )],
    )

    client = TestClient(create_app(settings))
    encoded = encode_metric_ref(WashImpactRef(
        kind="wash_impact",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=acct.id,
    ))
    resp = client.get(f"/provenance/{encoded}")
    assert resp.status_code == 200
    assert "Confirmed" in resp.text
    assert "Pub 550" in resp.text
    assert "$100.00" in resp.text or "100.00" in resp.text
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_provenance_modal_render.py -v`
Expected: assertion fails on "Pub 550" — placeholder template doesn't render adjustments yet.

- [ ] **Step 3: Replace the placeholder with the full template**

```html
{# src/net_alpha/web/templates/_provenance_modal.html #}
<div class="provenance-modal" data-testid="provenance-modal">
  {% if error %}
    <div class="panel p-4">
      <div class="text-neg font-medium">Couldn't reconstruct trace — file a bug.</div>
      <div class="text-label-3 text-xs mt-1">{{ error }}</div>
      <a class="text-xs underline mt-2 inline-block"
         href="https://github.com/anthropics/net-alpha/issues" target="_blank" rel="noopener">
        Open an issue
      </a>
    </div>
  {% else %}
    <div class="panel p-4 space-y-4">
      <header class="flex items-baseline justify-between gap-3 pb-3"
              style="border-bottom:0.5px solid rgba(255,255,255,0.08);">
        <h3 class="text-lg font-semibold">{{ trace.metric_label }}</h3>
        <div class="num text-2xl font-bold">${{ "%.2f"|format(trace.total) }}</div>
      </header>

      {% if trace.trades %}
      <section>
        <h4 class="label-uc">Contributing trades</h4>
        <table class="net-table text-sm w-full">
          <thead>
            <tr><th>Date</th><th>Account</th><th>Action</th><th class="r">Qty</th>
                <th class="r">Amount</th><th>Symbol</th></tr>
          </thead>
          <tbody>
            {% for t in trace.trades %}
              <tr>
                <td class="font-mono">{{ t.trade_date.isoformat() }}</td>
                <td>{{ t.account }}</td>
                <td>{{ t.action }}</td>
                <td class="r num font-mono">{{ "%.4f"|format(t.quantity) }}</td>
                <td class="r num font-mono {% if t.amount < 0 %}text-neg{% else %}text-pos{% endif %}">
                  ${{ "%.2f"|format(t.amount|abs) }}
                </td>
                <td class="font-mono">{{ t.symbol }}</td>
              </tr>
            {% endfor %}
          </tbody>
        </table>
      </section>
      {% endif %}

      {% if trace.adjustments %}
      <section>
        <h4 class="label-uc">Applied adjustments</h4>
        <table class="net-table text-sm w-full">
          <thead>
            <tr><th>Loss trade</th><th>Replacement</th><th class="r">Rolled $</th>
                <th>Confidence</th><th>Rule</th></tr>
          </thead>
          <tbody>
            {% for a in trace.adjustments %}
              <tr>
                <td class="font-mono text-xs">{{ a.loss_trade_id[:8] }}…</td>
                <td class="font-mono text-xs">{{ a.replacement_trade_id[:8] }}…</td>
                <td class="r num font-mono">${{ "%.2f"|format(a.rolled_amount) }}</td>
                <td>{{ a.confidence }}</td>
                <td class="text-xs text-label-3">{{ a.rule_citation }}</td>
              </tr>
            {% endfor %}
          </tbody>
        </table>
      </section>
      {% endif %}

      {% if trace.cash_events %}
      <section>
        <h4 class="label-uc">Contributing cash events</h4>
        <table class="net-table text-sm w-full">
          <thead>
            <tr><th>Date</th><th>Account</th><th>Kind</th>
                <th class="r">Amount</th><th>Description</th></tr>
          </thead>
          <tbody>
            {% for e in trace.cash_events %}
              <tr>
                <td class="font-mono">{{ e.event_date.isoformat() }}</td>
                <td>{{ e.account }}</td>
                <td>{{ e.kind }}</td>
                <td class="r num font-mono {% if e.amount < 0 %}text-neg{% else %}text-pos{% endif %}">
                  ${{ "%.2f"|format(e.amount|abs) }}
                </td>
                <td class="text-xs text-label-3">{{ e.description }}</td>
              </tr>
            {% endfor %}
          </tbody>
        </table>
      </section>
      {% endif %}
    </div>
  {% endif %}
</div>
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/web/test_provenance_modal_render.py tests/web/test_provenance_route.py -v`
Expected: 3 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/templates/_provenance_modal.html tests/web/test_provenance_modal_render.py
git commit -m "feat(audit): full provenance modal template with three sections"
```

---

### Task 11: Jinja `provenance_link()` macro

**Files:**
- Create: `src/net_alpha/web/templates/_provenance_macros.html`

- [ ] **Step 1: Write a Jinja-env unit test for the macro**

Render the macro through the app's Jinja environment directly — no HTTP round-trip needed. This avoids exposing a test-only debug route.

```python
# tests/web/test_provenance_macro.py
from datetime import date

from net_alpha.audit.provenance import Period, RealizedPLRef, encode_metric_ref
from net_alpha.config import Settings
from net_alpha.web.app import create_app


def test_macro_emits_correct_hx_get(tmp_path):
    app = create_app(Settings(data_dir=tmp_path))
    env = app.state.templates.env
    template = env.from_string(
        '{% from "_provenance_macros.html" import provenance_link %}'
        "{{ provenance_link(ref) }}"
    )
    ref = RealizedPLRef(
        kind="realized_pl",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=1,
        symbol=None,
    )
    rendered = template.render(ref=ref)
    expected_path = f"/provenance/{encode_metric_ref(ref)}"
    assert f'hx-get="{expected_path}"' in rendered
    assert "provenance-trigger" in rendered
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_provenance_macro.py -v`
Expected: TemplateNotFound for `_provenance_macros.html`.

- [ ] **Step 3: Add the macro template + register `encode_metric_ref` as a Jinja global**

Create `src/net_alpha/web/templates/_provenance_macros.html`:

```html
{# Reusable macro: emit a small "ⓘ" affordance next to a number that opens
   the provenance modal. Caller supplies a MetricRef instance. #}

{% macro provenance_link(ref) -%}
  {%- set encoded = encode_metric_ref(ref) -%}
  <button type="button"
          class="provenance-trigger ml-1 text-label-3 hover:text-text"
          aria-label="Why is this number what it is?"
          hx-get="/provenance/{{ encoded }}"
          hx-target="#provenance-dialog-body"
          hx-swap="innerHTML"
          onclick="document.getElementById('provenance-dialog').showModal()">
    ⓘ
  </button>
{%- endmacro %}
```

Modify `src/net_alpha/web/app.py` to register the global. Find where `templates.env.globals[...]` is set and add:

```python
from net_alpha.audit import encode_metric_ref
templates.env.globals["encode_metric_ref"] = encode_metric_ref
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/web/test_provenance_macro.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/templates/_provenance_macros.html src/net_alpha/web/app.py tests/web/test_provenance_macro.py
git commit -m "feat(audit): provenance_link Jinja macro with HTMX trigger"
```

---

### Task 12: `<dialog>` element + wire into `base.html`; integrate macro on portfolio KPIs and ticker page

**Files:**
- Modify: `src/net_alpha/web/templates/base.html`
- Modify: `src/net_alpha/web/templates/_portfolio_kpis.html`
- Modify: `src/net_alpha/web/templates/ticker.html`

- [ ] **Step 1: Write an integration test that the portfolio page renders provenance triggers next to KPIs**

```python
# tests/web/test_portfolio_provenance_wired.py
from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.web.app import create_app


def test_portfolio_kpis_have_provenance_triggers(tmp_path):
    client = TestClient(create_app(Settings(data_dir=tmp_path)))
    resp = client.get("/")
    assert resp.status_code == 200
    # At least one provenance trigger and the dialog mount-point.
    assert "provenance-trigger" in resp.text
    assert 'id="provenance-dialog"' in resp.text


def test_ticker_page_has_provenance_triggers(tmp_path):
    client = TestClient(create_app(Settings(data_dir=tmp_path)))
    # Ticker page renders even with empty data, just shows "no trades" etc.
    resp = client.get("/ticker/AAPL")
    assert resp.status_code == 200
    # Page must mount the dialog (because base.html provides it).
    assert 'id="provenance-dialog"' in resp.text
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_portfolio_provenance_wired.py -v`
Expected: assertions fail (no triggers and no dialog).

- [ ] **Step 3: Add a `<dialog>` mount-point to `base.html`**

In `src/net_alpha/web/templates/base.html`, just before `</body>`:

```html
  <dialog id="provenance-dialog"
          class="provenance-dialog backdrop:bg-black/40 bg-bg text-text rounded p-0">
    <form method="dialog" class="flex justify-end px-3 py-2">
      <button class="text-label-3 hover:text-text">close ✕</button>
    </form>
    <div id="provenance-dialog-body" class="px-4 pb-4 min-w-[640px]">
      <div class="text-label-3 text-sm">Loading…</div>
    </div>
  </dialog>
```

(The `<form method="dialog">` makes the close button work natively without JS.)

- [ ] **Step 4: Wire the macro into `_portfolio_kpis.html`**

In `src/net_alpha/web/templates/_portfolio_kpis.html`, at the very top, add the import:

```jinja
{% from "_provenance_macros.html" import provenance_link %}
```

The KPIs in this template need MetricRefs. The portfolio route already passes `kpis` and `period_label` via context; modify the route in `src/net_alpha/web/routes/portfolio.py` to also build and pass `metric_refs` (a dict with one ref per KPI). Then in the template, append `{{ provenance_link(metric_refs.realized_period) }}` next to each number.

Add to the route the necessary builder. Find the context dict and add:

```python
from datetime import date as _date

from net_alpha.audit import (
    CashRef,
    NetContributedRef,
    Period,
    RealizedPLRef,
    UnrealizedPLRef,
    WashImpactRef,
)


def _build_metric_refs(period_tuple, period_label, account_id):
    period = None
    if period_tuple is not None:
        period = Period(
            start=_date(period_tuple[0], 1, 1),
            end=_date(period_tuple[1], 1, 1),
            label=period_label,
        )
    lifetime = Period(
        start=_date(1970, 1, 1), end=_date(2100, 1, 1), label="Lifetime",
    )
    refs: dict[str, object] = {
        "unrealized_period": UnrealizedPLRef(
            kind="unrealized_pl", account_id=account_id, symbol=None,
        ),
        "lifetime_realized": RealizedPLRef(
            kind="realized_pl", period=lifetime, account_id=account_id, symbol=None,
        ),
        "lifetime_unrealized": UnrealizedPLRef(
            kind="unrealized_pl", account_id=account_id, symbol=None,
        ),
        "cash": CashRef(kind="cash", account_id=account_id),
    }
    if period is not None:
        refs["realized_period"] = RealizedPLRef(
            kind="realized_pl", period=period, account_id=account_id, symbol=None,
        )
        refs["wash_impact_period"] = WashImpactRef(
            kind="wash_impact", period=period, account_id=account_id,
        )
        refs["net_contributed_period"] = NetContributedRef(
            kind="net_contributed", period=period, account_id=account_id,
        )
    return refs
```

Pass `metric_refs=_build_metric_refs(...)` into the template context. Then in `_portfolio_kpis.html`, alongside the realized period number, add:

```jinja
{% if metric_refs.realized_period %}{{ provenance_link(metric_refs.realized_period) }}{% endif %}
```

(Repeat for each KPI cell — lifetime_realized, period_unrealized, lifetime_unrealized, open_position_value (no ref needed — it's a market price snapshot), wash_impact_total, cash, net_contributed.)

The Open Position $ KPI does *not* get a provenance trigger — it's a price × quantity snapshot, not a sum of trades. Add a comment in the template explaining this so it isn't filed as a bug later.

- [ ] **Step 5: Wire macro into `ticker.html`**

At the top of `src/net_alpha/web/templates/ticker.html`:

```jinja
{% from "_provenance_macros.html" import provenance_link %}
```

For the YTD Realized P&L block (per-symbol), modify the ticker route to pass a `realized_ref = RealizedPLRef(..., symbol=symbol)` and render `{{ provenance_link(realized_ref) }}` next to it.

(The exact render location depends on the existing ticker.html structure; the rule is: every dollar number that comes from a sum of trades gets a `provenance_link` next to it. Open lots' adjusted basis *does* get a link — it's a sum of basis adjustments.)

- [ ] **Step 6: Run all related tests**

Run: `uv run pytest tests/web/test_portfolio_provenance_wired.py tests/web/test_portfolio_routes.py tests/web/test_ticker.py -v`
Expected: all pass; no regression in existing portfolio/ticker tests.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/base.html src/net_alpha/web/templates/_portfolio_kpis.html src/net_alpha/web/templates/ticker.html src/net_alpha/web/routes/portfolio.py src/net_alpha/web/routes/ticker.py tests/web/test_portfolio_provenance_wired.py
git commit -m "feat(audit): wire provenance triggers into Portfolio KPIs and Ticker page"
```

---

### Task 13: `BrokerLot` + `BrokerGLProvider` ABC

**Files:**
- Create: `src/net_alpha/audit/brokers/base.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_brokers_base.py
import pytest

from net_alpha.audit.brokers.base import BrokerGLProvider, BrokerLot


def test_broker_lot_validates():
    from datetime import date
    lot = BrokerLot(
        symbol="AAPL", account_id=1, acquired=date(2026, 1, 1), closed=date(2026, 4, 1),
        qty=10.0, cost_basis=1000.0, proceeds=1500.0, wash_disallowed=None,
        source_label="Schwab Realized G/L",
    )
    assert lot.symbol == "AAPL"


def test_abc_cannot_be_instantiated():
    with pytest.raises(TypeError):
        BrokerGLProvider()


def test_abc_subclass_must_implement_both_methods():
    class Half(BrokerGLProvider):
        def supports(self, account_id): return True
    with pytest.raises(TypeError):
        Half()
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_brokers_base.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement**

```python
# src/net_alpha/audit/brokers/base.py
from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date

from pydantic import BaseModel


class BrokerLot(BaseModel):
    """One broker-supplied lot row, normalized across brokers."""

    symbol: str
    account_id: int
    acquired: date
    closed: date | None
    qty: float
    cost_basis: float
    proceeds: float | None
    wash_disallowed: float | None
    source_label: str  # e.g. "Schwab Realized G/L", "Schwab Unrealized"


class BrokerGLProvider(ABC):
    """Source of broker-truth lot detail for reconciliation."""

    @abstractmethod
    def supports(self, account_id: int) -> bool:
        """Whether this provider has data for the given account."""

    @abstractmethod
    def get_lot_detail(self, account_id: int, symbol: str) -> list[BrokerLot]:
        """Return all broker lots (open + closed) for the account/symbol."""
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_brokers_base.py -v`
Expected: 3 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/brokers/base.py tests/audit/test_brokers_base.py
git commit -m "feat(audit): BrokerLot + BrokerGLProvider ABC"
```

---

### Task 14: `SchwabGLProvider` implementation

**Files:**
- Create: `src/net_alpha/audit/brokers/schwab.py`
- Create: `tests/audit/test_brokers_schwab.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_brokers_schwab.py
from datetime import date

from net_alpha.audit.brokers.schwab import SchwabGLProvider
from net_alpha.models.realized_gl import RealizedGLLot


def test_schwab_provider_translates_gl_lots(repo, schwab_account):
    repo.add_gl_lots(
        schwab_account,
        import_id=1,  # arbitrary; FK not enforced for this test
        lots=[
            RealizedGLLot(
                account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
                closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
                quantity=10.0, proceeds=1500.0, cost_basis=1000.0,
                unadjusted_cost_basis=1000.0, wash_sale=False, disallowed_loss=0.0,
                term="Long Term",
            )
        ],
    )
    provider = SchwabGLProvider(repo)
    assert provider.supports(schwab_account.id) is True

    lots = provider.get_lot_detail(schwab_account.id, "AAPL")
    assert len(lots) == 1
    bl = lots[0]
    assert bl.symbol == "AAPL"
    assert bl.account_id == schwab_account.id
    assert bl.cost_basis == 1000.0
    assert bl.proceeds == 1500.0
    assert bl.source_label.startswith("Schwab")


def test_schwab_provider_supports_only_schwab(repo):
    other = repo.get_or_create_account(broker="Fidelity", label="Roth")
    provider = SchwabGLProvider(repo)
    assert provider.supports(other.id) is False
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_brokers_schwab.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement**

```python
# src/net_alpha/audit/brokers/schwab.py
from __future__ import annotations

from net_alpha.audit.brokers.base import BrokerGLProvider, BrokerLot
from net_alpha.db.repository import Repository


class SchwabGLProvider(BrokerGLProvider):
    """Reads broker-supplied lot detail from imported Schwab Realized G/L CSVs."""

    def __init__(self, repo: Repository):
        self._repo = repo

    def supports(self, account_id: int) -> bool:
        for a in self._repo.list_accounts():
            if a.id == account_id and a.broker == "Schwab":
                return True
        return False

    def get_lot_detail(self, account_id: int, symbol: str) -> list[BrokerLot]:
        gl_lots = self._repo.get_gl_lots_for_ticker(account_id, symbol)
        return [
            BrokerLot(
                symbol=lot.ticker,
                account_id=account_id,
                acquired=lot.opened_date,
                closed=lot.closed_date,
                qty=lot.quantity,
                cost_basis=lot.cost_basis,
                proceeds=lot.proceeds,
                wash_disallowed=lot.disallowed_loss if lot.wash_sale else None,
                source_label="Schwab Realized G/L",
            )
            for lot in gl_lots
        ]
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_brokers_schwab.py -v`
Expected: 2 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/brokers/schwab.py tests/audit/test_brokers_schwab.py
git commit -m "feat(audit): SchwabGLProvider over existing get_gl_lots_for_ticker"
```

---

### Task 15: Provider registry / dispatcher

**Files:**
- Create: `src/net_alpha/audit/brokers/registry.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_brokers_registry.py
from net_alpha.audit.brokers.registry import get_provider_for_account
from net_alpha.audit.brokers.schwab import SchwabGLProvider


def test_returns_schwab_provider_for_schwab_account(repo, schwab_account):
    provider = get_provider_for_account(schwab_account.id, repo)
    assert isinstance(provider, SchwabGLProvider)


def test_returns_none_for_unsupported_broker(repo):
    fid = repo.get_or_create_account(broker="Fidelity", label="Roth")
    provider = get_provider_for_account(fid.id, repo)
    assert provider is None
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_brokers_registry.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement**

```python
# src/net_alpha/audit/brokers/registry.py
from __future__ import annotations

from net_alpha.audit.brokers.base import BrokerGLProvider
from net_alpha.audit.brokers.schwab import SchwabGLProvider
from net_alpha.db.repository import Repository


def get_provider_for_account(account_id: int, repo: Repository) -> BrokerGLProvider | None:
    """Return the first registered provider that supports ``account_id``.

    Future brokers add a candidate to ``_CANDIDATES`` (in priority order). When
    no provider matches, returns ``None`` — the reconciliation strip renders
    'not available for this account' rather than implying a problem.
    """
    candidates: list[BrokerGLProvider] = [SchwabGLProvider(repo)]
    for p in candidates:
        if p.supports(account_id):
            return p
    return None
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_brokers_registry.py -v`
Expected: 2 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/brokers/registry.py tests/audit/test_brokers_registry.py
git commit -m "feat(audit): broker provider registry"
```

---

### Task 16: `ReconciliationResult` + `reconcile()` with tolerance

**Files:**
- Create: `src/net_alpha/audit/reconciliation.py`
- Create: `tests/audit/test_reconciliation.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_reconciliation.py
from datetime import date

from net_alpha.audit.reconciliation import ReconciliationStatus, reconcile
from net_alpha.models.domain import Trade
from net_alpha.models.realized_gl import RealizedGLLot


def test_reconcile_clean_match(repo, schwab_account):
    repo.add_import(
        trades=[
            Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        ],
        cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        schwab_account, import_id=1,
        lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1500.0, cost_basis=1000.0,
            unadjusted_cost_basis=1000.0, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )

    r = reconcile(symbol="AAPL", account_id=schwab_account.id, repo=repo)
    assert r.status == ReconciliationStatus.MATCH
    assert r.net_alpha_total == 500.0
    assert r.broker_total == 500.0
    assert r.delta == 0.0


def test_reconcile_within_tolerance(repo, schwab_account):
    repo.add_import(
        trades=[
            Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        ],
        cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        schwab_account, import_id=1,
        lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1500.0, cost_basis=999.70,  # $0.30 short
            unadjusted_cost_basis=999.70, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )

    r = reconcile(symbol="AAPL", account_id=schwab_account.id, repo=repo, tolerance=0.50)
    assert r.status == ReconciliationStatus.NEAR_MATCH
    assert abs(r.delta) < 0.50


def test_reconcile_diff_exceeds_tolerance(repo, schwab_account):
    repo.add_import(
        trades=[
            Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        ],
        cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        schwab_account, import_id=1,
        lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1498.80, cost_basis=1000.0,
            unadjusted_cost_basis=1000.0, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )

    r = reconcile(symbol="AAPL", account_id=schwab_account.id, repo=repo, tolerance=0.50)
    assert r.status == ReconciliationStatus.DIFF
    assert abs(r.delta) > 0.50


def test_reconcile_no_provider_returns_unavailable(repo):
    fid = repo.get_or_create_account(broker="Fidelity", label="Roth")
    r = reconcile(symbol="AAPL", account_id=fid.id, repo=repo)
    assert r.status == ReconciliationStatus.UNAVAILABLE
    assert r.broker_total is None
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_reconciliation.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement**

```python
# src/net_alpha/audit/reconciliation.py
from __future__ import annotations

from enum import Enum

from pydantic import BaseModel

from net_alpha.audit.brokers.registry import get_provider_for_account
from net_alpha.db.repository import Repository

DEFAULT_TOLERANCE = 0.50


class ReconciliationStatus(str, Enum):
    MATCH = "match"
    NEAR_MATCH = "near_match"      # within tolerance
    DIFF = "diff"                  # exceeds tolerance
    UNAVAILABLE = "unavailable"    # no broker provider for this account


class ReconciliationResult(BaseModel):
    symbol: str
    account_id: int
    net_alpha_total: float
    broker_total: float | None
    delta: float
    status: ReconciliationStatus
    tolerance: float
    source_label: str | None       # e.g. "Schwab Realized G/L"


def reconcile(
    *,
    symbol: str,
    account_id: int,
    repo: Repository,
    tolerance: float = DEFAULT_TOLERANCE,
) -> ReconciliationResult:
    provider = get_provider_for_account(account_id, repo)
    net_alpha_total = _net_alpha_realized(repo, account_id, symbol)

    if provider is None:
        return ReconciliationResult(
            symbol=symbol, account_id=account_id,
            net_alpha_total=net_alpha_total, broker_total=None,
            delta=0.0, status=ReconciliationStatus.UNAVAILABLE,
            tolerance=tolerance, source_label=None,
        )

    broker_lots = provider.get_lot_detail(account_id, symbol)
    broker_total = sum(
        (lot.proceeds or 0.0) - lot.cost_basis for lot in broker_lots
    )
    delta = round(net_alpha_total - broker_total, 4)
    if abs(delta) < 0.005:
        status = ReconciliationStatus.MATCH
    elif abs(delta) < tolerance:
        status = ReconciliationStatus.NEAR_MATCH
    else:
        status = ReconciliationStatus.DIFF

    source_label = broker_lots[0].source_label if broker_lots else None
    return ReconciliationResult(
        symbol=symbol, account_id=account_id,
        net_alpha_total=round(net_alpha_total, 2),
        broker_total=round(broker_total, 2),
        delta=delta, status=status, tolerance=tolerance,
        source_label=source_label,
    )


def _net_alpha_realized(repo: Repository, account_id: int, symbol: str) -> float:
    """Sum realized P/L for the (account, symbol) pair across all time."""
    total = 0.0
    accounts = {a.id: f"{a.broker}/{a.label}" if a.label else a.broker for a in repo.list_accounts()}
    target_display = accounts.get(account_id)
    for t in repo.get_trades_for_ticker(symbol):
        if t.action.lower() != "sell":
            continue
        if target_display is not None and t.account != target_display:
            continue
        total += (t.proceeds or 0.0) - (t.cost_basis or 0.0)
    return total
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_reconciliation.py -v`
Expected: 4 tests pass.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/reconciliation.py tests/audit/test_reconciliation.py
git commit -m "feat(audit): reconcile() with tolerance + status enum"
```

---

### Task 17: Per-lot diff with cause hints

**Files:**
- Modify: `src/net_alpha/audit/reconciliation.py`
- Create: `tests/audit/test_per_lot_diff.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_per_lot_diff.py
from datetime import date

from net_alpha.audit.reconciliation import per_lot_diffs
from net_alpha.models.domain import Trade
from net_alpha.models.realized_gl import RealizedGLLot


def test_per_lot_diff_pairs_by_close_date(repo, schwab_account):
    repo.add_import(
        trades=[
            Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        ],
        cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        schwab_account, import_id=1,
        lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1500.0, cost_basis=999.20,  # $0.80 short
            unadjusted_cost_basis=999.20, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )
    diffs = per_lot_diffs(symbol="AAPL", account_id=schwab_account.id, repo=repo)
    assert len(diffs) == 1
    d = diffs[0]
    assert abs(d.delta) > 0.5
    assert d.likely_cause is not None
    assert d.broker_basis == 999.20
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_per_lot_diff.py -v`
Expected: ImportError for `per_lot_diffs`.

- [ ] **Step 3: Implement**

Append to `src/net_alpha/audit/reconciliation.py`:

```python
class LotDiff(BaseModel):
    """One pair of (broker lot, net-alpha-derived realized) with a delta."""

    closed_date: object | None              # date | str
    opened_date: object | None
    qty: float
    broker_basis: float
    broker_proceeds: float | None
    net_alpha_basis: float | None
    net_alpha_proceeds: float | None
    delta: float
    likely_cause: str | None


def per_lot_diffs(
    *, symbol: str, account_id: int, repo: Repository,
) -> list[LotDiff]:
    provider = get_provider_for_account(account_id, repo)
    if provider is None:
        return []
    broker_lots = provider.get_lot_detail(account_id, symbol)
    accounts = {a.id: f"{a.broker}/{a.label}" if a.label else a.broker for a in repo.list_accounts()}
    target_display = accounts.get(account_id)
    sells = [
        t for t in repo.get_trades_for_ticker(symbol)
        if t.action.lower() == "sell" and (target_display is None or t.account == target_display)
    ]
    sells_by_date: dict[date, Trade] = {t.date: t for t in sells}

    diffs: list[LotDiff] = []
    for bl in broker_lots:
        if bl.closed is None:
            continue
        match = sells_by_date.get(bl.closed)
        if match is None:
            diffs.append(LotDiff(
                closed_date=bl.closed, opened_date=bl.acquired, qty=bl.qty,
                broker_basis=bl.cost_basis, broker_proceeds=bl.proceeds,
                net_alpha_basis=None, net_alpha_proceeds=None,
                delta=0.0, likely_cause="net-alpha has no matching sell on this date",
            ))
            continue
        na_basis = match.cost_basis or 0.0
        na_proceeds = match.proceeds or 0.0
        delta = round(
            ((na_proceeds - na_basis) - ((bl.proceeds or 0.0) - bl.cost_basis)),
            4,
        )
        diffs.append(LotDiff(
            closed_date=bl.closed, opened_date=bl.acquired, qty=bl.qty,
            broker_basis=bl.cost_basis, broker_proceeds=bl.proceeds,
            net_alpha_basis=na_basis, net_alpha_proceeds=na_proceeds,
            delta=delta, likely_cause=_cause_hint(delta, bl, match),
        ))
    return diffs


def _cause_hint(delta: float, bl, na: Trade) -> str | None:
    """Lightweight heuristic — rendered as 'investigate' guidance."""
    if abs(delta) < 0.005:
        return None
    if bl.proceeds is not None and na.proceeds is not None:
        if abs((na.proceeds or 0) - (bl.proceeds or 0)) > abs((na.cost_basis or 0) - bl.cost_basis):
            return "proceeds mismatch — possible fee allocation difference"
    if bl.cost_basis != (na.cost_basis or 0.0):
        return "cost basis mismatch — possibly a wash-sale adjustment net-alpha applied differently"
    return "small numerical drift"
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_per_lot_diff.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/reconciliation.py tests/audit/test_per_lot_diff.py
git commit -m "feat(audit): per_lot_diffs() with cause hints"
```

---

### Task 18: GET /reconciliation/{symbol} route + strip template

**Files:**
- Modify: `src/net_alpha/web/routes/audit_routes.py`
- Create: `src/net_alpha/web/templates/_reconciliation_strip.html`
- Create: `src/net_alpha/web/templates/_reconciliation_diff.html`
- Create: `tests/web/test_reconciliation_route.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_reconciliation_route.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade
from net_alpha.models.realized_gl import RealizedGLLot
from net_alpha.web.app import create_app


def test_reconciliation_route_returns_match_strip(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[
            Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        ],
        cash_events=[], account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        acct, import_id=1, lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1500.0, cost_basis=1000.0,
            unadjusted_cost_basis=1000.0, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )

    client = TestClient(create_app(settings))
    resp = client.get(f"/reconciliation/AAPL?account_id={acct.id}")
    assert resp.status_code == 200
    assert "✓" in resp.text or "match" in resp.text.lower()
    assert "$500.00" in resp.text or "500.00" in resp.text


def test_reconciliation_route_renders_diff_state(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[
            Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
        ],
        cash_events=[], account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        acct, import_id=1, lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1495.00, cost_basis=1000.0,
            unadjusted_cost_basis=1000.0, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )

    client = TestClient(create_app(settings))
    resp = client.get(f"/reconciliation/AAPL?account_id={acct.id}")
    assert resp.status_code == 200
    assert "△" in resp.text or "investigate" in resp.text.lower()
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_reconciliation_route.py -v`
Expected: 404.

- [ ] **Step 3: Add the route**

Append to `src/net_alpha/web/routes/audit_routes.py`:

```python
from fastapi import Query

from net_alpha.audit.reconciliation import per_lot_diffs, reconcile


@router.get("/reconciliation/{symbol}", response_class=HTMLResponse)
def reconciliation_strip(
    symbol: str,
    account_id: int = Query(...),
    expanded: bool = Query(False),
    request: Request = None,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    result = reconcile(symbol=symbol.upper(), account_id=account_id, repo=repo)
    diffs = per_lot_diffs(symbol=symbol.upper(), account_id=account_id, repo=repo) if expanded else []
    template = "_reconciliation_diff.html" if expanded else "_reconciliation_strip.html"
    return request.app.state.templates.TemplateResponse(
        request, template, {"result": result, "diffs": diffs},
    )
```

- [ ] **Step 4: Implement the strip template**

```html
{# src/net_alpha/web/templates/_reconciliation_strip.html #}
<div class="recon-strip flex items-center gap-3 px-4 py-2 panel" data-status="{{ result.status.value }}">
  <span class="text-xs text-label-3">net-alpha computed:</span>
  <span class="num font-mono">${{ "%.2f"|format(result.net_alpha_total) }}</span>
  <span class="text-xs text-label-3">·</span>
  {% if result.status.value == "unavailable" %}
    <span class="text-xs text-label-3">{{ result.source_label or "Broker G/L" }}: not available for this account</span>
  {% else %}
    <span class="text-xs text-label-3">{{ result.source_label or "Broker G/L" }}:</span>
    <span class="num font-mono">${{ "%.2f"|format(result.broker_total) }}</span>
    {% if result.status.value == "match" %}
      <span class="text-pos">✓</span>
    {% elif result.status.value == "near_match" %}
      <span class="text-label-3 text-xs">~match (within tolerance)</span>
    {% else %}
      <span class="text-warn">△ ${{ "%.2f"|format(result.delta|abs) }}</span>
      <button class="text-xs underline ml-2"
              hx-get="/reconciliation/{{ result.symbol }}?account_id={{ result.account_id }}&expanded=true"
              hx-target="closest .recon-strip"
              hx-swap="outerHTML">
        investigate
      </button>
    {% endif %}
  {% endif %}
</div>
```

- [ ] **Step 5: Implement the diff fragment template**

```html
{# src/net_alpha/web/templates/_reconciliation_diff.html #}
<div class="recon-strip recon-strip-expanded panel">
  <div class="px-4 py-2 flex items-center gap-3" style="border-bottom:0.5px solid rgba(255,255,255,0.08);">
    <span class="text-xs text-label-3">net-alpha:</span>
    <span class="num font-mono">${{ "%.2f"|format(result.net_alpha_total) }}</span>
    <span class="text-xs text-label-3">·</span>
    <span class="text-xs text-label-3">{{ result.source_label }}:</span>
    <span class="num font-mono">${{ "%.2f"|format(result.broker_total) }}</span>
    <span class="text-warn">△ ${{ "%.2f"|format(result.delta|abs) }}</span>
    <button class="text-xs underline ml-auto"
            hx-get="/reconciliation/{{ result.symbol }}?account_id={{ result.account_id }}&expanded=false"
            hx-target="closest .recon-strip-expanded"
            hx-swap="outerHTML">
      collapse
    </button>
  </div>
  <table class="net-table text-sm w-full">
    <thead>
      <tr><th>Closed</th><th>Opened</th><th class="r">Qty</th>
          <th class="r">Broker basis</th><th class="r">Broker proceeds</th>
          <th class="r">net-alpha basis</th><th class="r">net-alpha proceeds</th>
          <th class="r">Δ</th><th>Likely cause</th></tr>
    </thead>
    <tbody>
      {% for d in diffs %}
        <tr>
          <td class="font-mono">{{ d.closed_date }}</td>
          <td class="font-mono">{{ d.opened_date }}</td>
          <td class="r num font-mono">{{ "%.4f"|format(d.qty) }}</td>
          <td class="r num font-mono">${{ "%.2f"|format(d.broker_basis) }}</td>
          <td class="r num font-mono">{% if d.broker_proceeds is not none %}${{ "%.2f"|format(d.broker_proceeds) }}{% endif %}</td>
          <td class="r num font-mono">{% if d.net_alpha_basis is not none %}${{ "%.2f"|format(d.net_alpha_basis) }}{% endif %}</td>
          <td class="r num font-mono">{% if d.net_alpha_proceeds is not none %}${{ "%.2f"|format(d.net_alpha_proceeds) }}{% endif %}</td>
          <td class="r num font-mono {% if d.delta < 0 %}text-neg{% elif d.delta > 0 %}text-pos{% endif %}">
            {% if d.delta != 0 %}${{ "%.2f"|format(d.delta|abs) }}{% else %}—{% endif %}
          </td>
          <td class="text-xs text-label-3">{{ d.likely_cause or "—" }}</td>
        </tr>
      {% endfor %}
    </tbody>
  </table>
</div>
```

- [ ] **Step 6: Run, confirm pass**

Run: `uv run pytest tests/web/test_reconciliation_route.py -v`
Expected: 2 tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/audit_routes.py src/net_alpha/web/templates/_reconciliation_strip.html src/net_alpha/web/templates/_reconciliation_diff.html tests/web/test_reconciliation_route.py
git commit -m "feat(audit): /reconciliation/{symbol} route + strip + diff fragments"
```

---

### Task 19: Wire reconciliation strip into ticker page

**Files:**
- Modify: `src/net_alpha/web/templates/ticker.html`

- [ ] **Step 1: Write the integration test**

```python
# tests/web/test_ticker_recon_strip.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade
from net_alpha.web.app import create_app


def test_ticker_page_includes_reconciliation_strip(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                      action="Buy", quantity=10, cost_basis=1000.0)],
        cash_events=[], account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    client = TestClient(create_app(settings))
    resp = client.get("/ticker/AAPL")
    assert resp.status_code == 200
    # Strip is loaded lazily via HTMX so the page should reference the endpoint.
    assert "/reconciliation/AAPL" in resp.text
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_ticker_recon_strip.py -v`
Expected: assertion fails — strip not embedded.

- [ ] **Step 3: Embed the strip in `ticker.html`**

In `src/net_alpha/web/templates/ticker.html`, near the top of the page (after the symbol heading and before the KPI tiles), add:

```jinja
{# Reconciliation strip — one per account that holds this symbol. Loads lazily. #}
{% if accounts %}
  {% for account_id in accounts %}
    <div class="mb-3"
         hx-get="/reconciliation/{{ symbol }}?account_id={{ account_id }}"
         hx-trigger="load"
         hx-swap="innerHTML">
      <div class="text-label-3 text-xs">Loading reconciliation…</div>
    </div>
  {% endfor %}
{% endif %}
```

The ticker route currently passes `accounts = sorted({lot.account for lot in lots})` — those are display strings (e.g. `"Schwab/Tax"`), not ids. The reconciliation route needs ids. Add the conversion in `src/net_alpha/web/routes/ticker.py`:

```python
# Inside ticker_drilldown, after computing `lots`:
holding_displays = {lot.account for lot in lots}
account_ids: list[int] = []
for a in repo.list_accounts():
    display = f"{a.broker}/{a.label}" if a.label else a.broker
    if display in holding_displays and a.id is not None:
        account_ids.append(a.id)
account_ids.sort()
```

Add `account_ids` to the template context dict (separate from the existing `accounts` display-string list — both are useful: `accounts` for the Accounts heading, `account_ids` for HTMX URL building).

In `ticker.html`, the snippet from Step 3 references `account_ids` (rename `account_id` in the loop to match):

```jinja
{% if account_ids %}
  {% for account_id in account_ids %}
    <div class="mb-3"
         hx-get="/reconciliation/{{ symbol }}?account_id={{ account_id }}"
         hx-trigger="load"
         hx-swap="innerHTML">
      <div class="text-label-3 text-xs">Loading reconciliation…</div>
    </div>
  {% endfor %}
{% endif %}
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/web/test_ticker_recon_strip.py tests/web/test_ticker.py -v`
Expected: existing ticker tests still pass; new strip test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/templates/ticker.html src/net_alpha/web/routes/ticker.py tests/web/test_ticker_recon_strip.py
git commit -m "feat(audit): embed reconciliation strip on ticker page (lazy HTMX load)"
```

---

### Task 20: `HygieneIssue` model + skeleton `collect_issues`

**Files:**
- Create: `src/net_alpha/audit/hygiene.py`

- [ ] **Step 1: Write the failing test for the empty case**

```python
# tests/audit/test_hygiene_skeleton.py
from net_alpha.audit.hygiene import collect_issues


def test_empty_repo_returns_no_issues(repo):
    issues = collect_issues(repo)
    assert issues == []
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_hygiene_skeleton.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement skeleton**

```python
# src/net_alpha/audit/hygiene.py
"""Data hygiene: surface trade/lot/cash data quality issues for triage."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from net_alpha.db.repository import Repository

HygieneCategory = Literal["unpriced", "basis_unknown", "orphan_sell", "dup_key"]
HygieneSeverity = Literal["info", "warn", "error"]


class HygieneFixForm(BaseModel):
    """An inline HTMX form rendered on a hygiene row."""

    action: str                   # POST endpoint, e.g. /audit/set-basis
    fields: dict[str, str]        # field name -> field type ("date" | "number" | "text")
    hidden: dict[str, str]        # hidden form values, e.g. {"trade_id": "..."}


class HygieneIssue(BaseModel):
    category: HygieneCategory
    severity: HygieneSeverity
    summary: str
    detail: str
    fix_url: str | None = None
    fix_form: HygieneFixForm | None = None


def collect_issues(repo: Repository) -> list[HygieneIssue]:
    """Run all category checks against the current Repository state."""
    issues: list[HygieneIssue] = []
    issues.extend(_check_unpriced(repo))
    issues.extend(_check_basis_unknown(repo))
    issues.extend(_check_orphan_sells(repo))
    issues.extend(_check_dup_keys(repo))
    return issues


def _check_unpriced(repo: Repository) -> list[HygieneIssue]:
    """Open lots whose ticker has no current price quote."""
    return []


def _check_basis_unknown(repo: Repository) -> list[HygieneIssue]:
    """Buy trades flagged ``basis_unknown=True`` (transfer-in without basis)."""
    return []


def _check_orphan_sells(repo: Repository) -> list[HygieneIssue]:
    """Sell trades with no buy lot of the same ticker in the repository."""
    return []


def _check_dup_keys(repo: Repository) -> list[HygieneIssue]:
    """Same-day repeat clusters of ≥3 identical trades — possible re-import."""
    return []
```

This skeleton ships green (the empty-repo test passes); each category is filled in its own follow-up task with a focused test.

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_hygiene_skeleton.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/hygiene.py tests/audit/test_hygiene_skeleton.py
git commit -m "feat(audit): hygiene scaffold with HygieneIssue model + collect_issues dispatcher"
```

---

### Task 21: `_check_unpriced` — surface unpriced symbols

**Files:**
- Modify: `src/net_alpha/audit/hygiene.py`
- Create: `tests/audit/test_hygiene_unpriced.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_hygiene_unpriced.py
from datetime import date

from net_alpha.audit.hygiene import collect_issues
from net_alpha.models.domain import Trade


def test_unpriced_symbol_surfaces_warn_issue(repo, schwab_account, monkeypatch):
    repo.add_import(
        trades=[Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="DEAD",
                      action="Buy", quantity=10, cost_basis=1000.0)],
        cash_events=[], account_id=schwab_account.id, csv_filename="t.csv", csv_sha256="h",
    )
    # Stub the unpriced check to declare DEAD unpriced.
    from net_alpha.audit import hygiene as h
    monkeypatch.setattr(h, "_get_unpriced_symbols", lambda repo: ["DEAD"])

    issues = collect_issues(repo)
    unpriced = [i for i in issues if i.category == "unpriced"]
    assert len(unpriced) == 1
    assert unpriced[0].severity == "warn"
    assert "DEAD" in unpriced[0].summary
    assert unpriced[0].fix_url == "/holdings?symbol=DEAD"
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_hygiene_unpriced.py -v`
Expected: AttributeError ("no attribute '_get_unpriced_symbols'") OR assertion failure (empty list).

- [ ] **Step 3: Implement**

In `src/net_alpha/audit/hygiene.py`, replace the placeholder `_check_unpriced`:

```python
def _get_unpriced_symbols(repo: Repository) -> list[str]:
    """Symbols held in open lots without a cached price quote.

    Reads from the existing PriceCache. Only equity lots are checked (option
    lots don't drive the unpriced badge).
    """
    from net_alpha.db.connection import get_engine
    from net_alpha.pricing.cache import PriceCache

    engine = repo.engine
    cache = PriceCache(engine, ttl_seconds=86400)  # generous TTL — we just want presence
    symbols = sorted({lot.ticker for lot in repo.all_lots() if lot.option_details is None})
    missing: list[str] = []
    for s in symbols:
        if cache.get_price(s) is None:
            missing.append(s)
    return missing


def _check_unpriced(repo: Repository) -> list[HygieneIssue]:
    issues: list[HygieneIssue] = []
    for sym in _get_unpriced_symbols(repo):
        issues.append(HygieneIssue(
            category="unpriced",
            severity="warn",
            summary=f"{sym} has no price quote",
            detail=(
                "Unrealized P&L for this symbol is excluded from totals. "
                "Common causes: delisted, OTC, or symbol mismatch with Yahoo."
            ),
            fix_url=f"/holdings?symbol={sym}",
        ))
    return issues
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_hygiene_unpriced.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/hygiene.py tests/audit/test_hygiene_unpriced.py
git commit -m "feat(audit): hygiene check — unpriced symbols"
```

---

### Task 22: `_check_basis_unknown` — surface lots without basis + inline fix form

**Files:**
- Modify: `src/net_alpha/audit/hygiene.py`
- Create: `tests/audit/test_hygiene_basis_unknown.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_hygiene_basis_unknown.py
from datetime import date

from net_alpha.audit.hygiene import collect_issues
from net_alpha.models.domain import Trade


def test_basis_unknown_trade_surfaces_with_fix_form(repo, schwab_account):
    repo.add_import(
        trades=[
            Trade(id="t-x", account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=None,
                  basis_unknown=True, basis_source="transfer_in"),
        ],
        cash_events=[], account_id=schwab_account.id, csv_filename="t.csv", csv_sha256="h",
    )
    issues = [i for i in collect_issues(repo) if i.category == "basis_unknown"]
    assert len(issues) == 1
    issue = issues[0]
    assert issue.severity == "error"
    assert "AAPL" in issue.summary
    assert issue.fix_form is not None
    assert issue.fix_form.action == "/audit/set-basis"
    assert "trade_id" in issue.fix_form.hidden
    assert issue.fix_form.hidden["trade_id"] == "t-x"
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_hygiene_basis_unknown.py -v`
Expected: assertion fails (empty list).

- [ ] **Step 3: Implement**

Replace `_check_basis_unknown` in `src/net_alpha/audit/hygiene.py`:

```python
def _check_basis_unknown(repo: Repository) -> list[HygieneIssue]:
    issues: list[HygieneIssue] = []
    for t in repo.all_trades():
        if not t.basis_unknown:
            continue
        # Buy-side transfers in particular need basis to compute realized P&L
        # when sold. Sell-side basis_unknown is rarer (transfer_out) and
        # doesn't need user fix.
        if t.action.lower() != "buy":
            continue
        issues.append(HygieneIssue(
            category="basis_unknown",
            severity="error",
            summary=f"{t.ticker} buy on {t.date.isoformat()} has unknown basis",
            detail=(
                f"Account: {t.account} · Qty: {t.quantity:.4f} · Source: {t.basis_source}. "
                "Until basis is set, realized P&L for this lot can't be computed."
            ),
            fix_form=HygieneFixForm(
                action="/audit/set-basis",
                fields={"cost_basis": "number"},
                hidden={"trade_id": t.id},
            ),
        ))
    return issues
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_hygiene_basis_unknown.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/hygiene.py tests/audit/test_hygiene_basis_unknown.py
git commit -m "feat(audit): hygiene check — basis-unknown buys with inline fix form"
```

---

### Task 23: `_check_orphan_sells` — sells without matching buy lots

**Files:**
- Modify: `src/net_alpha/audit/hygiene.py`
- Create: `tests/audit/test_hygiene_orphan_sell.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_hygiene_orphan_sell.py
from datetime import date

from net_alpha.audit.hygiene import collect_issues
from net_alpha.models.domain import Trade


def test_sell_without_prior_buy_surfaces_warn(repo, schwab_account):
    # A sell of XYZ but no buy lots for XYZ — orphan.
    repo.add_import(
        trades=[Trade(account="Schwab/Tax", date=date(2026, 4, 1), ticker="XYZ",
                      action="Sell", quantity=5, proceeds=500.0, cost_basis=400.0)],
        cash_events=[], account_id=schwab_account.id, csv_filename="t.csv", csv_sha256="h",
    )
    issues = [i for i in collect_issues(repo) if i.category == "orphan_sell"]
    assert len(issues) == 1
    assert issues[0].severity == "warn"
    assert "XYZ" in issues[0].summary
    assert "missing prior-year import" in issues[0].detail.lower()
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_hygiene_orphan_sell.py -v`
Expected: assertion failure (empty list).

- [ ] **Step 3: Implement**

```python
def _check_orphan_sells(repo: Repository) -> list[HygieneIssue]:
    """A sell with no buy lot of the same ticker on/before its date.

    The wash-sale engine already tracks buy lots; if a Sell has no
    corresponding Lot row at all, the basis came from somewhere outside
    net-alpha's view (most often a missing prior-year import).
    """
    lots_by_ticker: dict[str, bool] = {}
    for lot in repo.all_lots():
        lots_by_ticker[lot.ticker] = True

    issues: list[HygieneIssue] = []
    for t in repo.all_trades():
        if t.action.lower() != "sell":
            continue
        if t.ticker in lots_by_ticker:
            continue
        issues.append(HygieneIssue(
            category="orphan_sell",
            severity="warn",
            summary=f"{t.ticker} sell on {t.date.isoformat()} has no matching buy lot",
            detail=(
                "Usually means a missing prior-year import or a transfer not yet "
                "hydrated. Realized P&L for this trade may be incorrect."
            ),
            fix_url=f"/imports",
        ))
    return issues
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_hygiene_orphan_sell.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/hygiene.py tests/audit/test_hygiene_orphan_sell.py
git commit -m "feat(audit): hygiene check — orphan sells"
```

---

### Task 24: `_check_dup_keys` — duplicate natural-key warnings

**Files:**
- Modify: `src/net_alpha/audit/hygiene.py`
- Create: `tests/audit/test_hygiene_dup_key.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/audit/test_hygiene_dup_key.py
from datetime import date

from net_alpha.audit.hygiene import collect_issues
from net_alpha.models.domain import Trade


def test_two_trades_same_natural_key_surface_info(repo, schwab_account, monkeypatch):
    # Two trades that *would* collide on natural key (same date, account,
    # ticker, qty, etc.). The DB dedup rejects exact dupes on insert; this
    # check surfaces *occurrence_index > 0* trades, which the parser uses
    # for legitimate same-day repeats — but a high count is suspicious.
    trades = [
        Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=1000.0, occurrence_index=0),
        Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=1000.0, occurrence_index=1),
        Trade(account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
              action="Buy", quantity=10, cost_basis=1000.0, occurrence_index=2),
    ]
    repo.add_import(
        trades=trades, cash_events=[], account_id=schwab_account.id,
        csv_filename="t.csv", csv_sha256="h",
    )
    issues = [i for i in collect_issues(repo) if i.category == "dup_key"]
    # 3 occurrences on the same day → 1 cluster surfaced (info severity).
    assert len(issues) == 1
    assert issues[0].severity == "info"
    assert "AAPL" in issues[0].summary
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_hygiene_dup_key.py -v`
Expected: assertion fails.

- [ ] **Step 3: Implement**

```python
def _check_dup_keys(repo: Repository) -> list[HygieneIssue]:
    """Cluster of trades with the same natural-key signature on the same day.

    Same-day repeats with occurrence_index > 0 are normal — most parsers emit
    them when a single CSV row produces multiple Trades. But ≥3 trades sharing
    (date, account, ticker, action, quantity) is unusually dense and worth
    surfacing as info — could be a re-import that escaped dedup.
    """
    from collections import defaultdict

    clusters: dict[tuple, int] = defaultdict(int)
    for t in repo.all_trades():
        key = (t.date, t.account, t.ticker, t.action, round(t.quantity, 4))
        clusters[key] += 1

    issues: list[HygieneIssue] = []
    for (d, acct, ticker, action, qty), count in clusters.items():
        if count < 3:
            continue
        issues.append(HygieneIssue(
            category="dup_key",
            severity="info",
            summary=f"{count} {action} trades for {ticker} on {d.isoformat()}",
            detail=(
                f"Account: {acct} · Qty per trade: {qty}. Same-day repeats are "
                "usually normal but ≥3 occurrences suggests a possible re-import."
            ),
            fix_url=f"/imports",
        ))
    return issues
```

- [ ] **Step 4: Run, confirm pass**

Run: `uv run pytest tests/audit/test_hygiene_dup_key.py -v`
Expected: 1 test passes.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/audit/hygiene.py tests/audit/test_hygiene_dup_key.py
git commit -m "feat(audit): hygiene check — duplicate natural-key clusters"
```

---

### Task 25: `_data_hygiene.html` template + embed on `/imports`

**Files:**
- Create: `src/net_alpha/web/templates/_data_hygiene.html`
- Modify: `src/net_alpha/web/templates/imports.html`
- Modify: `src/net_alpha/web/routes/imports.py`

- [ ] **Step 1: Write the integration test**

```python
# tests/web/test_data_hygiene_section.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade
from net_alpha.web.app import create_app


def test_imports_page_shows_hygiene_section_when_issues_exist(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[Trade(id="t-x", account="Schwab/Tax", date=date(2026, 1, 1),
                      ticker="AAPL", action="Buy", quantity=10, cost_basis=None,
                      basis_unknown=True, basis_source="transfer_in")],
        cash_events=[], account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    client = TestClient(create_app(settings))
    resp = client.get("/imports")
    assert resp.status_code == 200
    assert "Data quality" in resp.text
    assert "AAPL" in resp.text
    assert "set-basis" in resp.text  # the inline form action


def test_imports_page_hides_hygiene_section_when_clean(tmp_path):
    settings = Settings(data_dir=tmp_path)
    client = TestClient(create_app(settings))
    resp = client.get("/imports")
    assert resp.status_code == 200
    assert "Data quality" not in resp.text
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_data_hygiene_section.py -v`
Expected: assertion fails.

- [ ] **Step 3: Build the template**

```html
{# src/net_alpha/web/templates/_data_hygiene.html #}
{% if issues %}
  <section class="panel mb-4" data-testid="data-hygiene">
    <div class="px-4 py-3" style="border-bottom:0.5px solid rgba(255,255,255,0.08);">
      <h2 class="text-lg">Data quality</h2>
      <p class="text-xs text-label-3 mt-1">
        {{ issues|length }} item{{ "s" if issues|length != 1 else "" }} need attention from your imports.
      </p>
    </div>
    <ul class="divide-y" style="border-color: rgba(255,255,255,0.06);">
      {% for issue in issues %}
        <li class="px-4 py-3 flex items-start gap-3" data-category="{{ issue.category }}">
          <span class="badge badge-{{ issue.severity }}">{{ issue.severity }}</span>
          <div class="flex-1">
            <div class="text-sm font-medium">{{ issue.summary }}</div>
            <div class="text-xs text-label-3 mt-1">{{ issue.detail }}</div>
            {% if issue.fix_url %}
              <a class="text-xs underline mt-2 inline-block" href="{{ issue.fix_url }}">go fix →</a>
            {% endif %}
            {% if issue.fix_form %}
              <form class="mt-2 flex gap-2 items-center"
                    hx-post="{{ issue.fix_form.action }}"
                    hx-target="closest li"
                    hx-swap="outerHTML">
                {% for k, v in issue.fix_form.hidden.items() %}
                  <input type="hidden" name="{{ k }}" value="{{ v }}">
                {% endfor %}
                {% for name, ftype in issue.fix_form.fields.items() %}
                  <label class="text-xs">
                    {{ name|replace("_", " ") }}:
                    <input type="{{ ftype }}" name="{{ name }}"
                           class="border border-label-3 px-1 py-0.5 text-xs ml-1"
                           required>
                  </label>
                {% endfor %}
                <button type="submit" class="text-xs px-2 py-0.5 bg-pos text-bg rounded">save</button>
              </form>
            {% endif %}
          </div>
        </li>
      {% endfor %}
    </ul>
  </section>
{% endif %}
```

- [ ] **Step 4: Embed in `imports.html`**

In `src/net_alpha/web/templates/imports.html`, near the top of the content block (above the existing import history list), include:

```jinja
{% include "_data_hygiene.html" %}
```

- [ ] **Step 5: Pass `issues` from the imports route**

Modify `src/net_alpha/web/routes/imports.py` `imports_page` function:

```python
from net_alpha.audit.hygiene import collect_issues


@router.get("/imports", response_class=HTMLResponse)
def imports_page(
    request: Request,
    flash: str | None = None,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    records = repo.list_imports()
    issues = collect_issues(repo)
    return request.app.state.templates.TemplateResponse(
        request,
        "imports.html",
        {"imports": records, "flash": flash, "issues": issues},
    )
```

- [ ] **Step 6: Run, confirm pass**

Run: `uv run pytest tests/web/test_data_hygiene_section.py tests/web/test_imports_routes.py -v`
Expected: new tests pass; existing imports tests unaffected.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/_data_hygiene.html src/net_alpha/web/templates/imports.html src/net_alpha/web/routes/imports.py tests/web/test_data_hygiene_section.py
git commit -m "feat(audit): embed data-hygiene section on /imports"
```

---

### Task 26: POST `/audit/set-basis` for the inline fix form

**Files:**
- Modify: `src/net_alpha/web/routes/audit_routes.py`
- Create: `src/net_alpha/web/templates/_data_hygiene_set_basis.html`

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_set_basis_route.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade
from net_alpha.web.app import create_app


def test_set_basis_updates_trade_and_returns_swap_fragment(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[Trade(id="t-x", account="Schwab/Tax", date=date(2026, 1, 1),
                      ticker="AAPL", action="Buy", quantity=10, cost_basis=None,
                      basis_unknown=True, basis_source="transfer_in")],
        cash_events=[], account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    client = TestClient(create_app(settings))
    resp = client.post("/audit/set-basis", data={"trade_id": "t-x", "cost_basis": "1234.56"})
    assert resp.status_code == 200
    assert "saved" in resp.text.lower()

    # Verify DB state
    repo2 = Repository(get_engine(settings.db_path))
    trade = next((t for t in repo2.all_trades() if t.id == "t-x"), None)
    assert trade is not None
    assert trade.cost_basis == 1234.56
    assert trade.basis_unknown is False
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/web/test_set_basis_route.py -v`
Expected: 404.

- [ ] **Step 3: Implement**

Append to `src/net_alpha/web/routes/audit_routes.py`:

```python
from fastapi import Form


@router.post("/audit/set-basis", response_class=HTMLResponse)
def set_basis(
    request: Request,
    trade_id: str = Form(...),
    cost_basis: float = Form(...),
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    repo.update_trade_basis(
        trade_id=trade_id,
        cost_basis=cost_basis,
        basis_source="user_set",
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_data_hygiene_set_basis.html",
        {"trade_id": trade_id, "cost_basis": cost_basis},
    )
```

- [ ] **Step 4: Implement the swap fragment template**

```html
{# src/net_alpha/web/templates/_data_hygiene_set_basis.html #}
<li class="px-4 py-3 flex items-start gap-3" data-saved="true">
  <span class="badge badge-info">saved</span>
  <div class="flex-1">
    <div class="text-sm">Basis set on trade <code class="font-mono">{{ trade_id[:8] }}…</code> to ${{ "%.2f"|format(cost_basis) }}.</div>
    <div class="text-xs text-label-3 mt-1">Reload the page to recompute totals.</div>
  </div>
</li>
```

- [ ] **Step 5: Run, confirm pass**

Run: `uv run pytest tests/web/test_set_basis_route.py -v`
Expected: 1 test passes.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/audit_routes.py src/net_alpha/web/templates/_data_hygiene_set_basis.html tests/web/test_set_basis_route.py
git commit -m "feat(audit): POST /audit/set-basis updates trade basis with HTMX swap"
```

---

### Task 27: Nav badge for `/imports` with 30s TTL cache

**Files:**
- Create: `src/net_alpha/audit/_badge_cache.py`
- Modify: `src/net_alpha/web/dependencies.py`
- Modify: `src/net_alpha/web/templates/base.html`
- Create: `tests/audit/test_badge_cache.py`
- Create: `tests/web/test_nav_badge.py`

- [ ] **Step 1: Write the failing tests**

```python
# tests/audit/test_badge_cache.py
import time

from net_alpha.audit._badge_cache import BadgeCache


def test_cache_returns_fresh_value_within_ttl():
    calls = {"n": 0}
    def compute():
        calls["n"] += 1
        return 5

    cache = BadgeCache(ttl_seconds=0.5)
    assert cache.get(compute) == 5
    assert cache.get(compute) == 5
    assert calls["n"] == 1


def test_cache_recomputes_after_ttl():
    calls = {"n": 0}
    def compute():
        calls["n"] += 1
        return calls["n"]

    cache = BadgeCache(ttl_seconds=0.05)
    assert cache.get(compute) == 1
    time.sleep(0.06)
    assert cache.get(compute) == 2
```

```python
# tests/web/test_nav_badge.py
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade
from net_alpha.web.app import create_app


def test_imports_nav_shows_badge_count_when_errors(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[Trade(id="t-x", account="Schwab/Tax", date=date(2026, 1, 1),
                      ticker="AAPL", action="Buy", quantity=10, cost_basis=None,
                      basis_unknown=True, basis_source="transfer_in")],
        cash_events=[], account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    client = TestClient(create_app(settings))
    resp = client.get("/")
    assert resp.status_code == 200
    # Imports nav-link should show a count badge.
    assert 'data-testid="imports-badge"' in resp.text


def test_imports_nav_hides_badge_when_clean(tmp_path):
    settings = Settings(data_dir=tmp_path)
    client = TestClient(create_app(settings))
    resp = client.get("/")
    assert resp.status_code == 200
    assert 'data-testid="imports-badge"' not in resp.text
```

- [ ] **Step 2: Run, confirm failure**

Run: `uv run pytest tests/audit/test_badge_cache.py tests/web/test_nav_badge.py -v`
Expected: ImportError + assertion failure.

- [ ] **Step 3: Implement the cache**

```python
# src/net_alpha/audit/_badge_cache.py
"""30-second TTL cache for the nav-bar issue count.

Module-level singleton (one process, one cache) is fine for a local
loopback-only app — no concurrency to worry about beyond FastAPI's
threadpool. Recomputing on every request would walk all_trades / all_lots
and that's wasteful.
"""
from __future__ import annotations

import time
from threading import Lock
from typing import Callable, TypeVar

T = TypeVar("T")


class BadgeCache:
    def __init__(self, ttl_seconds: float = 30.0):
        self._ttl = ttl_seconds
        self._lock = Lock()
        self._value: object | None = None
        self._expires_at: float = 0.0

    def get(self, compute: Callable[[], T]) -> T:
        now = time.monotonic()
        with self._lock:
            if self._value is None or now >= self._expires_at:
                self._value = compute()
                self._expires_at = now + self._ttl
            return self._value  # type: ignore[return-value]

    def invalidate(self) -> None:
        with self._lock:
            self._value = None
            self._expires_at = 0.0


# Module-level singleton.
_cache = BadgeCache(ttl_seconds=30.0)


def get_imports_badge_count(repo) -> int:
    """Count of issues that warrant a nav badge: ≥1 error or ≥3 warns."""
    from net_alpha.audit.hygiene import collect_issues

    def compute() -> int:
        issues = collect_issues(repo)
        errors = sum(1 for i in issues if i.severity == "error")
        warns = sum(1 for i in issues if i.severity == "warn")
        if errors >= 1 or warns >= 3:
            return errors + warns
        return 0

    return _cache.get(compute)
```

- [ ] **Step 4: Expose the badge count to every template via a Jinja global**

Add a closure in `src/net_alpha/web/app.py` that returns the badge count when called from a template. The closure captures `settings` (already in scope at app-creation time) and constructs a fresh `Repository` per call — fine because the cache short-circuits the expensive work.

In `src/net_alpha/web/app.py`, after the existing `templates.env.globals["asset_v"] = ...` line:

```python
from net_alpha.audit._badge_cache import get_imports_badge_count
from net_alpha.db.repository import Repository as _Repository


def _imports_badge_count() -> int:
    engine = get_engine(settings.db_path)
    return get_imports_badge_count(_Repository(engine))


templates.env.globals["imports_badge_count"] = _imports_badge_count
```

`base.html` calls `imports_badge_count()` (no arguments) directly — see Step 5.

- [ ] **Step 5: Render the badge in `base.html`**

In `src/net_alpha/web/templates/base.html`, modify the Imports nav link:

```html
        <a href="/imports" class="nav-link{% if active_page == 'imports' %} active{% endif %}">
          Imports
          {% set _badge = imports_badge_count() %}
          {% if _badge > 0 %}
            <span data-testid="imports-badge" class="ml-1 inline-flex items-center px-1.5 py-0.5 text-[10px] rounded bg-warn text-bg">{{ _badge }}</span>
          {% endif %}
        </a>
```

- [ ] **Step 6: Run, confirm pass**

Run: `uv run pytest tests/audit/test_badge_cache.py tests/web/test_nav_badge.py -v`
Expected: 4 tests pass.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/audit/_badge_cache.py src/net_alpha/web/dependencies.py src/net_alpha/web/app.py src/net_alpha/web/templates/base.html tests/audit/test_badge_cache.py tests/web/test_nav_badge.py
git commit -m "feat(audit): nav-bar Imports badge with 30s TTL cache"
```

---

### Task 28: Phase 1 smoke test — full end-to-end against fixture data

**Files:**
- Create: `tests/web/test_phase1_smoke.py`

- [ ] **Step 1: Write a smoke test that exercises all three sub-features**

```python
# tests/web/test_phase1_smoke.py
"""End-to-end smoke for Phase 1: provenance modal + reconciliation strip + hygiene section.

Catches integration regressions when any of the three sub-features is touched.
"""
from datetime import date

from fastapi.testclient import TestClient

from net_alpha.audit.provenance import Period, RealizedPLRef, encode_metric_ref
from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.db.repository import Repository
from net_alpha.models.domain import CashEvent, Trade
from net_alpha.models.realized_gl import RealizedGLLot
from net_alpha.web.app import create_app


def test_phase1_smoke(tmp_path):
    settings = Settings(data_dir=tmp_path)
    repo = Repository(get_engine(settings.db_path))
    acct = repo.get_or_create_account(broker="Schwab", label="Tax")
    repo.add_import(
        trades=[
            Trade(id="b1", account="Schwab/Tax", date=date(2026, 1, 1), ticker="AAPL",
                  action="Buy", quantity=10, cost_basis=1000.0),
            Trade(id="s1", account="Schwab/Tax", date=date(2026, 4, 1), ticker="AAPL",
                  action="Sell", quantity=10, proceeds=1500.0, cost_basis=1000.0),
            Trade(id="orph", account="Schwab/Tax", date=date(2026, 4, 5), ticker="XYZ",
                  action="Sell", quantity=5, proceeds=500.0, cost_basis=400.0),
            Trade(id="bad", account="Schwab/Tax", date=date(2026, 1, 1), ticker="MSFT",
                  action="Buy", quantity=10, cost_basis=None,
                  basis_unknown=True, basis_source="transfer_in"),
        ],
        cash_events=[
            CashEvent(account="Schwab/Tax", event_date=date(2026, 1, 1),
                      kind="transfer_in", amount=10000.0),
        ],
        account_id=acct.id, csv_filename="t.csv", csv_sha256="h",
    )
    repo.add_gl_lots(
        acct, import_id=1, lots=[RealizedGLLot(
            account_display="Schwab/Tax", symbol_raw="AAPL", ticker="AAPL",
            closed_date=date(2026, 4, 1), opened_date=date(2026, 1, 1),
            quantity=10.0, proceeds=1500.0, cost_basis=1000.0,
            unadjusted_cost_basis=1000.0, wash_sale=False, disallowed_loss=0.0,
            term="Long Term",
        )],
    )

    client = TestClient(create_app(settings))

    # Provenance modal renders with contributing trade.
    encoded = encode_metric_ref(RealizedPLRef(
        kind="realized_pl",
        period=Period(start=date(2026, 1, 1), end=date(2027, 1, 1), label="YTD 2026"),
        account_id=acct.id, symbol="AAPL",
    ))
    r1 = client.get(f"/provenance/{encoded}")
    assert r1.status_code == 200 and "AAPL" in r1.text

    # Reconciliation strip resolves to MATCH.
    r2 = client.get(f"/reconciliation/AAPL?account_id={acct.id}")
    assert r2.status_code == 200 and ("✓" in r2.text or "match" in r2.text.lower())

    # Imports page surfaces 2 issues (basis_unknown error + orphan_sell warn).
    r3 = client.get("/imports")
    assert r3.status_code == 200
    assert "Data quality" in r3.text
    assert "MSFT" in r3.text  # basis_unknown
    assert "XYZ" in r3.text   # orphan sell

    # Nav-bar badge appears on every page (one error → badge).
    r4 = client.get("/")
    assert 'data-testid="imports-badge"' in r4.text
```

- [ ] **Step 2: Run**

Run: `uv run pytest tests/web/test_phase1_smoke.py -v`
Expected: 1 test passes.

- [ ] **Step 3: Run the full suite to catch regressions**

Run: `uv run pytest`
Expected: all tests pass.

- [ ] **Step 4: Run the linter**

Run: `uv run ruff check . && uv run ruff format --check .`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add tests/web/test_phase1_smoke.py
git commit -m "test(audit): phase-1 smoke test — provenance + reconciliation + hygiene"
```

---

## Phase 1 done

Verification at this point:

- A user can click any KPI on `/portfolio` or `/ticker/{symbol}` and see contributing trades + adjustments + cash events in a modal.
- A user on `/ticker/{symbol}` sees a reconciliation strip per account that holds the symbol; on divergence, "investigate" expands a per-lot diff with cause hints.
- A user on `/imports` sees a Data Quality section above the import history when issues exist (basis-unknown buys with inline fix forms; orphan sells; unpriced symbols; duplicate-key clusters).
- The Imports nav link shows a count badge when ≥1 error or ≥3 warns exist; cached 30s.
- All new code has TDD coverage; existing tests still pass; ruff is clean.

**What ships next (Phase 2):** the forward tax planner. The `BrokerGLProvider` abstraction added here is reused (Phase 2 uses `SchwabGLProvider` lot data for harvest queue origin events). The hygiene categories `low_parse` and `tax_config_missing` widen in Phase 2 alongside the new tax config and parser confidence flag.
