# Phase 3 — Style-Aware Density Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add per-account profile (Conservative / Active / Options) and per-page density (Compact / Comfortable / Tax-view) so the UI defaults match how each account is actually used, without permanently hiding anything.

**Architecture:** New `prefs/` package owns the rule table — `ProfileSettings` encapsulates `shows("surface")`, `order(group)`, and `default_columns(table)`; templates ask the model, never branch on `profile == "options"` directly. Per-account preferences persist in a new `user_preferences` SQLite table (schema v9). Density toggles persist server-side as a per-account default and are overridden transiently in `localStorage`. A single first-visit modal asks the user to pick profiles before any preference rows exist; the toolbar switcher swaps profile after that.

**Tech Stack:** SQLModel + SQLite (schema v8 → v9 migration, hand-written ALTER), Pydantic v2 (`ProfileSettings` BaseModel with `Literal` enums), FastAPI (`POST /preferences`), Jinja2 templates (`profile.shows("X")` guards), Alpine.js (modal + switcher dropdown), HTMX (`HX-Refresh: true` after profile write), tiny localStorage shim.

---

## Section A — Database & schema (Tasks 1-3)

Add `user_preferences` row, migration v8 → v9, and SQLModel definition. Schema bump triggers migration on next `init_db`.

### Task 1: Add UserPreferenceRow SQLModel

**Files:**
- Modify: `src/net_alpha/db/tables.py`
- Test: `tests/db/test_user_preferences_row.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/db/test_user_preferences_row.py
from datetime import datetime

from sqlmodel import Session, select

from net_alpha.db.tables import AccountRow, UserPreferenceRow


def test_user_preference_row_persists(memory_engine):
    with Session(memory_engine) as s:
        acct = AccountRow(broker="Schwab", label="Tax")
        s.add(acct)
        s.commit()
        s.refresh(acct)

        pref = UserPreferenceRow(
            account_id=acct.id,
            profile="active",
            density="comfortable",
            updated_at=datetime(2026, 4, 27, 12, 0, 0),
        )
        s.add(pref)
        s.commit()

        loaded = s.exec(
            select(UserPreferenceRow).where(UserPreferenceRow.account_id == acct.id)
        ).first()

    assert loaded is not None
    assert loaded.profile == "active"
    assert loaded.density == "comfortable"
```

- [ ] **Step 2: Add the conftest fixture if not present**

Check `tests/db/conftest.py` for `memory_engine`. If missing, append:

```python
# tests/db/conftest.py
import pytest
from sqlalchemy import create_engine
from sqlmodel import SQLModel


@pytest.fixture
def memory_engine():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    return engine
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/db/test_user_preferences_row.py -v`
Expected: FAIL with `ImportError: cannot import name 'UserPreferenceRow'`

- [ ] **Step 4: Add UserPreferenceRow to tables.py**

Append to `src/net_alpha/db/tables.py`:

```python
class UserPreferenceRow(SQLModel, table=True):
    __tablename__ = "user_preferences"

    account_id: int = Field(primary_key=True, foreign_key="accounts.id")
    profile: str = Field(default="active")  # 'conservative' | 'active' | 'options'
    density: str = Field(default="comfortable")  # 'compact' | 'comfortable' | 'tax'
    updated_at: datetime
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/db/test_user_preferences_row.py -v`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/tables.py tests/db/test_user_preferences_row.py tests/db/conftest.py
git commit -m "feat(db): add UserPreferenceRow for v9 schema"
```

---

### Task 2: v8 → v9 migration

**Files:**
- Modify: `src/net_alpha/db/migrations.py`
- Test: `tests/db/test_migration_v8_to_v9.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/db/test_migration_v8_to_v9.py
from sqlalchemy import create_engine, text
from sqlmodel import Session

from net_alpha.db.migrations import (
    CURRENT_SCHEMA_VERSION,
    get_schema_version,
    migrate,
    set_schema_version,
)


def _bootstrap_v8(engine):
    with Session(engine) as s:
        s.exec(text(
            "CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)"
        ))
        s.exec(text(
            "CREATE TABLE accounts (id INTEGER PRIMARY KEY, broker TEXT, label TEXT)"
        ))
        s.commit()
        set_schema_version(s, 8)


def test_migrate_v8_to_v9_creates_user_preferences():
    engine = create_engine("sqlite:///:memory:")
    _bootstrap_v8(engine)

    with Session(engine) as s:
        migrate(s)
        assert get_schema_version(s) == CURRENT_SCHEMA_VERSION
        rows = s.exec(text(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='user_preferences'"
        )).all()
        assert len(rows) == 1


def test_migrate_v9_idempotent():
    engine = create_engine("sqlite:///:memory:")
    _bootstrap_v8(engine)

    with Session(engine) as s:
        migrate(s)
        migrate(s)  # second run must not raise
        assert get_schema_version(s) == 9
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/db/test_migration_v8_to_v9.py -v`
Expected: FAIL — either `CURRENT_SCHEMA_VERSION == 8` or `user_preferences` table missing

- [ ] **Step 3: Add the migration step**

Edit `src/net_alpha/db/migrations.py` — bump constant and add migration function. Update the file's docstring to add the v9 line, and bump the version.

```python
# Top of file — extend the docstring
"""Hand-written migrations.

Schema versions:
  v1 — Initial v2.x schema (TradeRow, LotRow, WashSaleViolationRow, etc.)
  v2 — Adds RealizedGLLotRow table; adds Trade.basis_source, WashSaleViolation.source columns.
  v3 — Adds PriceCacheRow table for the pricing subsystem.
  v4 — Adds aggregate columns to imports (date range, type counts, parse warnings).
  v5 — Adds imports.duplicate_trades count so re-imports show "X dupes" instead of "no records".
  v6 — Adds trades.is_manual and trades.transfer_basis_user_set; relaxes trades.import_id NOT NULL.
  v7 — Adds splits and lot_overrides tables for stock-split handling and
       manual lot edits.
  v8 — Adds cash_events table; trades.gross_cash_impact; imports.cash_event_count.
  v9 — Adds user_preferences (per-account profile + density).
"""
```

```python
CURRENT_SCHEMA_VERSION = 9
```

Add the migration function next to the other `_migrate_*` helpers:

```python
def _migrate_v8_to_v9(session: Session) -> None:
    """Add user_preferences (per-account profile + density). Idempotent."""
    if not _table_exists(session, "user_preferences"):
        session.exec(
            text(
                "CREATE TABLE user_preferences ("
                "account_id INTEGER PRIMARY KEY, "
                "profile TEXT NOT NULL DEFAULT 'active', "
                "density TEXT NOT NULL DEFAULT 'comfortable', "
                "updated_at TEXT NOT NULL, "
                "FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE)"
            )
        )
    session.commit()
```

In `migrate()`, after the `if current < 8: ... return` block, add:

```python
    if current < 9:
        _migrate_v8_to_v9(session)
        set_schema_version(session, 9)
        return
```

And update the prior `if current < 8` block to no longer `return` early — replace its `return` with `current = 8`:

```python
    if current < 8:
        _migrate_v7_to_v8(session)
        set_schema_version(session, 8)
        current = 8
    if current < 9:
        _migrate_v8_to_v9(session)
        set_schema_version(session, 9)
        return
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/db/test_migration_v8_to_v9.py -v`
Expected: PASS

- [ ] **Step 5: Run the whole DB test suite to confirm no regressions**

Run: `uv run pytest tests/db/ -v`
Expected: all PASS

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/migrations.py tests/db/test_migration_v8_to_v9.py
git commit -m "feat(db): v8 -> v9 migration adds user_preferences"
```

---

### Task 3: Repository methods for preferences

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_preferences.py` (create)

- [ ] **Step 1: Write the failing tests**

```python
# tests/db/test_repository_preferences.py
from datetime import datetime, timezone

import pytest
from sqlalchemy import create_engine
from sqlmodel import SQLModel

from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference


@pytest.fixture
def repo():
    engine = create_engine("sqlite:///:memory:")
    SQLModel.metadata.create_all(engine)
    return Repository(engine)


def _seed_account(repo: Repository, label: str = "Tax") -> int:
    acct = repo.get_or_create_account("Schwab", label)
    return acct.id


def test_get_user_preference_missing_returns_none(repo):
    aid = _seed_account(repo)
    assert repo.get_user_preference(aid) is None


def test_upsert_user_preference_creates_row(repo):
    aid = _seed_account(repo)
    now = datetime(2026, 4, 27, 12, 0, 0, tzinfo=timezone.utc)
    repo.upsert_user_preference(
        AccountPreference(
            account_id=aid,
            profile="options",
            density="tax",
            updated_at=now,
        )
    )
    pref = repo.get_user_preference(aid)
    assert pref is not None
    assert pref.profile == "options"
    assert pref.density == "tax"


def test_upsert_user_preference_updates_existing(repo):
    aid = _seed_account(repo)
    now = datetime(2026, 4, 27, 12, 0, 0, tzinfo=timezone.utc)
    repo.upsert_user_preference(
        AccountPreference(account_id=aid, profile="active", density="comfortable", updated_at=now)
    )
    repo.upsert_user_preference(
        AccountPreference(account_id=aid, profile="conservative", density="compact", updated_at=now)
    )
    pref = repo.get_user_preference(aid)
    assert pref.profile == "conservative"
    assert pref.density == "compact"


def test_list_user_preferences_returns_all(repo):
    a = _seed_account(repo, "Tax")
    b = _seed_account(repo, "Roth")
    now = datetime(2026, 4, 27, 12, 0, 0, tzinfo=timezone.utc)
    repo.upsert_user_preference(AccountPreference(account_id=a, profile="active", density="comfortable", updated_at=now))
    repo.upsert_user_preference(AccountPreference(account_id=b, profile="options", density="tax", updated_at=now))
    out = repo.list_user_preferences()
    by_id = {p.account_id: p for p in out}
    assert by_id[a].profile == "active"
    assert by_id[b].profile == "options"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/db/test_repository_preferences.py -v`
Expected: FAIL — `ImportError: cannot import name 'AccountPreference'`

- [ ] **Step 3: Create the AccountPreference domain model**

Create `src/net_alpha/models/preferences.py`:

```python
"""Domain model for per-account user preferences (v9 schema)."""
from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel

Profile = Literal["conservative", "active", "options"]
Density = Literal["compact", "comfortable", "tax"]


class AccountPreference(BaseModel):
    model_config = {"extra": "ignore"}

    account_id: int
    profile: Profile = "active"
    density: Density = "comfortable"
    updated_at: datetime
```

- [ ] **Step 4: Add Repository methods**

Edit `src/net_alpha/db/repository.py` — add the import and three methods.

Add to imports (alongside other domain imports):

```python
from net_alpha.models.preferences import AccountPreference
```

Add to imports for tables (alongside other table imports):

```python
from net_alpha.db.tables import (
    ...
    UserPreferenceRow,
    ...
)
```

Append three methods to the `Repository` class (next to `list_accounts`):

```python
    def get_user_preference(self, account_id: int) -> AccountPreference | None:
        with Session(self.engine) as s:
            row = s.get(UserPreferenceRow, account_id)
            if row is None:
                return None
            return AccountPreference(
                account_id=row.account_id,
                profile=row.profile,  # type: ignore[arg-type]
                density=row.density,  # type: ignore[arg-type]
                updated_at=row.updated_at,
            )

    def list_user_preferences(self) -> list[AccountPreference]:
        with Session(self.engine) as s:
            rows = s.exec(select(UserPreferenceRow)).all()
            return [
                AccountPreference(
                    account_id=r.account_id,
                    profile=r.profile,  # type: ignore[arg-type]
                    density=r.density,  # type: ignore[arg-type]
                    updated_at=r.updated_at,
                )
                for r in rows
            ]

    def upsert_user_preference(self, pref: AccountPreference) -> None:
        with Session(self.engine) as s:
            row = s.get(UserPreferenceRow, pref.account_id)
            if row is None:
                row = UserPreferenceRow(
                    account_id=pref.account_id,
                    profile=pref.profile,
                    density=pref.density,
                    updated_at=pref.updated_at,
                )
                s.add(row)
            else:
                row.profile = pref.profile
                row.density = pref.density
                row.updated_at = pref.updated_at
            s.commit()
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/db/test_repository_preferences.py -v`
Expected: PASS (4 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/models/preferences.py src/net_alpha/db/repository.py tests/db/test_repository_preferences.py
git commit -m "feat(db): repository methods for user preferences"
```

---

## Section B — ProfileSettings rule table (Tasks 4-6)

Encapsulate the visibility/ordering rule table from Section 3b in code, not templates.

### Task 4: ProfileSettings model + shows()

**Files:**
- Create: `src/net_alpha/prefs/__init__.py`
- Create: `src/net_alpha/prefs/profile.py`
- Test: `tests/prefs/test_profile_settings.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/prefs/test_profile_settings.py
import pytest

from net_alpha.prefs.profile import DEFAULT_PROFILE_SETTINGS, ProfileSettings


def test_default_is_active_comfortable():
    assert DEFAULT_PROFILE_SETTINGS.profile == "active"
    assert DEFAULT_PROFILE_SETTINGS.density == "comfortable"


@pytest.mark.parametrize(
    "profile,surface,expected",
    [
        ("conservative", "lockout_calendar", False),
        ("active", "lockout_calendar", True),
        ("options", "lockout_calendar", True),
        ("conservative", "wash_watch_expanded", False),
        ("active", "wash_watch_expanded", True),
        ("options", "wash_watch_expanded", True),
        ("conservative", "ltcg_approaching", True),
        ("active", "ltcg_approaching", True),
        ("options", "ltcg_approaching", True),
        ("conservative", "offset_budget", True),
        ("conservative", "year_end_projection", True),
        ("conservative", "traffic_light", True),
    ],
)
def test_shows(profile, surface, expected):
    s = ProfileSettings(profile=profile, density="comfortable")
    assert s.shows(surface) == expected


def test_shows_unknown_surface_defaults_true():
    s = ProfileSettings(profile="active", density="comfortable")
    assert s.shows("nonexistent_surface") is True
```

- [ ] **Step 2: Create the empty package**

Create `src/net_alpha/prefs/__init__.py`:

```python
"""Per-account profile + density preferences (Phase 3)."""
```

- [ ] **Step 3: Run test to verify it fails**

Run: `uv run pytest tests/prefs/test_profile_settings.py -v`
Expected: FAIL — `ImportError: No module named 'net_alpha.prefs.profile'`

- [ ] **Step 4: Implement ProfileSettings.shows()**

Create `src/net_alpha/prefs/profile.py`:

```python
"""ProfileSettings — encapsulates the Section 3b visibility rule table.

Templates ask `profile.shows("surface")` instead of branching on profile
strings, so the rules live in one place and unknown surface keys default
to True (visible) with a warning logged.
"""
from __future__ import annotations

import logging
from typing import Literal

from pydantic import BaseModel

from net_alpha.models.preferences import Density, Profile

log = logging.getLogger(__name__)

# Visibility table — Section 3b of the spec. True = shown by default for that
# profile; False = hidden by default. Switching profile re-applies this map.
_VISIBILITY: dict[str, dict[Profile, bool]] = {
    "wash_watch_expanded": {"conservative": False, "active": True, "options": True},
    "lockout_calendar": {"conservative": False, "active": True, "options": True},
    "ltcg_approaching": {"conservative": True, "active": True, "options": True},
    "offset_budget": {"conservative": True, "active": True, "options": True},
    "year_end_projection": {"conservative": True, "active": True, "options": True},
    "traffic_light": {"conservative": True, "active": True, "options": True},
}


class ProfileSettings(BaseModel):
    model_config = {"extra": "ignore"}

    profile: Profile = "active"
    density: Density = "comfortable"

    def shows(self, surface: str) -> bool:
        """Default visibility for a named surface.

        Unknown surface keys default to True (show) and emit a warning, so
        missing keys are caught in dev rather than silently hiding UI.
        """
        rule = _VISIBILITY.get(surface)
        if rule is None:
            log.warning("ProfileSettings.shows: unknown surface %r — defaulting True", surface)
            return True
        return rule[self.profile]


DEFAULT_PROFILE_SETTINGS = ProfileSettings(profile="active", density="comfortable")
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/prefs/test_profile_settings.py -v`
Expected: PASS (14 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/prefs/__init__.py src/net_alpha/prefs/profile.py tests/prefs/test_profile_settings.py
git commit -m "feat(prefs): ProfileSettings.shows() rule table"
```

---

### Task 5: order() and default_kpis() for KPI hero

**Files:**
- Modify: `src/net_alpha/prefs/profile.py`
- Test: `tests/prefs/test_profile_kpi_order.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/prefs/test_profile_kpi_order.py
from net_alpha.prefs.profile import ProfileSettings


def test_kpi_hero_order_conservative():
    s = ProfileSettings(profile="conservative", density="comfortable")
    assert s.order("portfolio_kpi_hero") == [
        "open_position",
        "lifetime_growth",
        "cash",
    ]


def test_kpi_hero_order_active():
    s = ProfileSettings(profile="active", density="comfortable")
    assert s.order("portfolio_kpi_hero") == [
        "ytd_realized",
        "ytd_unrealized",
        "wash_impact",
        "open_position",
    ]


def test_kpi_hero_order_options():
    s = ProfileSettings(profile="options", density="comfortable")
    assert s.order("portfolio_kpi_hero") == [
        "ytd_realized",
        "wash_impact",
        "open_position",
        "cash",
    ]


def test_order_unknown_group_returns_empty():
    s = ProfileSettings(profile="active", density="comfortable")
    assert s.order("nonexistent_group") == []
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/prefs/test_profile_kpi_order.py -v`
Expected: FAIL — `AttributeError: 'ProfileSettings' object has no attribute 'order'`

- [ ] **Step 3: Add order() to ProfileSettings**

Edit `src/net_alpha/prefs/profile.py` — append the rule table and method.

Above the `class ProfileSettings(BaseModel):` line, add:

```python
# Ordering table — Section 3b. Each entry maps a UI group key to the
# default ordering of slots within it. Templates iterate over the returned
# list and render the named slot. Unknown groups return [].
_ORDERING: dict[str, dict[Profile, list[str]]] = {
    "portfolio_kpi_hero": {
        "conservative": ["open_position", "lifetime_growth", "cash"],
        "active": ["ytd_realized", "ytd_unrealized", "wash_impact", "open_position"],
        "options": ["ytd_realized", "wash_impact", "open_position", "cash"],
    },
}
```

Inside `class ProfileSettings`, after `shows`, add:

```python
    def order(self, group: str) -> list[str]:
        """Default ordering for a named UI group."""
        rule = _ORDERING.get(group)
        if rule is None:
            return []
        return list(rule[self.profile])
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/prefs/test_profile_kpi_order.py -v`
Expected: PASS (4 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/prefs/profile.py tests/prefs/test_profile_kpi_order.py
git commit -m "feat(prefs): ProfileSettings.order() for KPI hero slots"
```

---

### Task 6: default_columns() and default_tax_tab()

**Files:**
- Modify: `src/net_alpha/prefs/profile.py`
- Test: `tests/prefs/test_profile_columns.py` (create)

- [ ] **Step 1: Write the failing tests**

```python
# tests/prefs/test_profile_columns.py
from net_alpha.prefs.profile import ProfileSettings


def test_holdings_columns_conservative():
    s = ProfileSettings(profile="conservative", density="comfortable")
    cols = s.default_columns("holdings")
    assert "days_held" not in cols
    assert "lt_st_split" not in cols
    assert "premium_received" not in cols
    assert "origin_event" not in cols


def test_holdings_columns_active():
    s = ProfileSettings(profile="active", density="comfortable")
    cols = s.default_columns("holdings")
    assert "days_held" in cols
    assert "lt_st_split" in cols
    assert "premium_received" not in cols


def test_holdings_columns_options():
    s = ProfileSettings(profile="options", density="comfortable")
    cols = s.default_columns("holdings")
    assert "days_held" in cols
    assert "lt_st_split" in cols
    assert "premium_received" in cols
    assert "origin_event" in cols


def test_holdings_columns_compact_strips_extras():
    s = ProfileSettings(profile="options", density="compact")
    cols = s.default_columns("holdings")
    # compact: minimum columns regardless of profile
    assert cols == []


def test_holdings_columns_tax_view_adds_tax_specific():
    s = ProfileSettings(profile="conservative", density="tax")
    cols = s.default_columns("holdings")
    # tax-view overrides profile defaults; adds tax-specific columns
    assert "lt_st_split" in cols
    assert "days_to_ltcg" in cols
    assert "harvestable" in cols


def test_default_tax_tab_per_profile():
    assert ProfileSettings(profile="conservative", density="comfortable").default_tax_tab() == "wash-sales"
    assert ProfileSettings(profile="active", density="comfortable").default_tax_tab() == "harvest"
    assert ProfileSettings(profile="options", density="comfortable").default_tax_tab() == "harvest"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/prefs/test_profile_columns.py -v`
Expected: FAIL — `AttributeError: ... has no attribute 'default_columns'`

- [ ] **Step 3: Add default_columns() and default_tax_tab()**

Edit `src/net_alpha/prefs/profile.py`. Add the two new tables above `class ProfileSettings`:

```python
# Columns table — Section 3b. Each profile's "extra" columns layered on top
# of the always-present base columns (symbol, qty, market value, P/L). The
# density "tax" overrides profile defaults and adds tax-specific columns.
_HOLDINGS_PROFILE_EXTRAS: dict[Profile, list[str]] = {
    "conservative": [],
    "active": ["days_held", "lt_st_split"],
    "options": ["days_held", "lt_st_split", "premium_received", "origin_event"],
}

_HOLDINGS_TAX_DENSITY_COLS: list[str] = [
    "lt_st_split",
    "days_to_ltcg",
    "harvestable",
    "premium_offset",
]

# Default tax tab per profile — Section 3b.
_DEFAULT_TAX_TAB: dict[Profile, str] = {
    "conservative": "wash-sales",
    "active": "harvest",
    "options": "harvest",
}
```

Add two methods to `class ProfileSettings`, after `order`:

```python
    def default_columns(self, table: str) -> list[str]:
        """Default extra columns for a named table.

        - Density "compact": always [] (minimum columns).
        - Density "tax": overrides profile defaults; returns tax-specific cols.
        - Density "comfortable": profile-driven extras.
        """
        if table != "holdings":
            return []
        if self.density == "compact":
            return []
        if self.density == "tax":
            return list(_HOLDINGS_TAX_DENSITY_COLS)
        return list(_HOLDINGS_PROFILE_EXTRAS[self.profile])

    def default_tax_tab(self) -> str:
        """Default tab for /tax based on profile."""
        return _DEFAULT_TAX_TAB[self.profile]
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/prefs/test_profile_columns.py -v`
Expected: PASS (6 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/prefs/profile.py tests/prefs/test_profile_columns.py
git commit -m "feat(prefs): default_columns() and default_tax_tab()"
```

---

## Section C — Effective profile resolver (Tasks 7-8)

When the user filters by a single account, profile is unambiguous. When viewing "All accounts", we need to merge — same profile across all accounts → use it; mixed → fall back to default.

### Task 7: Effective profile resolver

**Files:**
- Modify: `src/net_alpha/prefs/profile.py`
- Test: `tests/prefs/test_effective_profile.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/prefs/test_effective_profile.py
from datetime import datetime, timezone

from net_alpha.models.preferences import AccountPreference
from net_alpha.prefs.profile import (
    DEFAULT_PROFILE_SETTINGS,
    ProfileSettings,
    resolve_effective_profile,
)


def _pref(aid, profile, density="comfortable"):
    return AccountPreference(
        account_id=aid,
        profile=profile,
        density=density,
        updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
    )


def test_no_preferences_returns_default():
    out = resolve_effective_profile(prefs=[], filter_account_id=None)
    assert out == DEFAULT_PROFILE_SETTINGS


def test_single_account_filter_uses_that_account():
    prefs = [_pref(1, "options"), _pref(2, "conservative")]
    out = resolve_effective_profile(prefs=prefs, filter_account_id=2)
    assert out.profile == "conservative"


def test_single_account_filter_missing_pref_falls_back():
    prefs = [_pref(1, "options")]
    out = resolve_effective_profile(prefs=prefs, filter_account_id=99)
    assert out.profile == "active"


def test_all_accounts_consistent_uses_shared_profile():
    prefs = [_pref(1, "options"), _pref(2, "options")]
    out = resolve_effective_profile(prefs=prefs, filter_account_id=None)
    assert out.profile == "options"


def test_all_accounts_mixed_falls_back_to_active():
    prefs = [_pref(1, "options"), _pref(2, "conservative")]
    out = resolve_effective_profile(prefs=prefs, filter_account_id=None)
    assert out.profile == "active"


def test_density_mirrors_profile_resolution():
    prefs = [_pref(1, "active", density="tax"), _pref(2, "active", density="tax")]
    out = resolve_effective_profile(prefs=prefs, filter_account_id=None)
    assert out.density == "tax"


def test_density_mixed_falls_back_to_comfortable():
    prefs = [_pref(1, "active", density="tax"), _pref(2, "active", density="compact")]
    out = resolve_effective_profile(prefs=prefs, filter_account_id=None)
    assert out.density == "comfortable"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/prefs/test_effective_profile.py -v`
Expected: FAIL — `ImportError: cannot import name 'resolve_effective_profile'`

- [ ] **Step 3: Implement resolve_effective_profile**

Append to `src/net_alpha/prefs/profile.py`:

```python
def resolve_effective_profile(
    *,
    prefs: list[AccountPreference],
    filter_account_id: int | None,
) -> ProfileSettings:
    """Compute the rendering profile for the current page request.

    - filter_account_id is set: use that account's pref, else default.
    - filter_account_id is None (All accounts):
        - all prefs share the same profile -> use it; else 'active'.
        - same rule applies to density independently.
    """
    if filter_account_id is not None:
        match = next((p for p in prefs if p.account_id == filter_account_id), None)
        if match is None:
            return DEFAULT_PROFILE_SETTINGS
        return ProfileSettings(profile=match.profile, density=match.density)

    if not prefs:
        return DEFAULT_PROFILE_SETTINGS

    profile_set = {p.profile for p in prefs}
    density_set = {p.density for p in prefs}
    profile = next(iter(profile_set)) if len(profile_set) == 1 else "active"
    density = next(iter(density_set)) if len(density_set) == 1 else "comfortable"
    return ProfileSettings(profile=profile, density=density)
```

Also add the import at the top of the file:

```python
from net_alpha.models.preferences import AccountPreference, Density, Profile
```

(replace the existing import that only pulls Density/Profile.)

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/prefs/test_effective_profile.py -v`
Expected: PASS (7 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/prefs/profile.py tests/prefs/test_effective_profile.py
git commit -m "feat(prefs): resolve_effective_profile across single/all-account views"
```

---

### Task 8: FastAPI dependency for ProfileSettings

**Files:**
- Modify: `src/net_alpha/web/dependencies.py`
- Test: `tests/web/test_get_profile_settings_dep.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_get_profile_settings_dep.py
from datetime import datetime, timezone

from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlmodel import SQLModel

from net_alpha.config import Settings
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.prefs.profile import ProfileSettings
from net_alpha.web.dependencies import get_profile_settings


def _bootstrap_app(tmp_path) -> tuple[FastAPI, Repository]:
    settings = Settings(data_dir=tmp_path)
    engine = create_engine(f"sqlite:///{tmp_path}/test.db")
    SQLModel.metadata.create_all(engine)
    app = FastAPI()
    app.state.settings = settings
    repo = Repository(engine)

    @app.get("/test")
    def _ep(profile: ProfileSettings = Depends(get_profile_settings)) -> dict:
        return {"profile": profile.profile, "density": profile.density}

    return app, repo


def test_get_profile_settings_no_filter_no_prefs(tmp_path):
    app, _repo = _bootstrap_app(tmp_path)
    client = TestClient(app)
    resp = client.get("/test")
    assert resp.status_code == 200
    assert resp.json() == {"profile": "active", "density": "comfortable"}


def test_get_profile_settings_account_filter(tmp_path):
    app, repo = _bootstrap_app(tmp_path)
    acct = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=acct.id,
            profile="options",
            density="tax",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    client = TestClient(app)
    resp = client.get("/test", params={"account": "Schwab/Tax"})
    assert resp.status_code == 200
    assert resp.json() == {"profile": "options", "density": "tax"}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_get_profile_settings_dep.py -v`
Expected: FAIL — `ImportError: cannot import name 'get_profile_settings'`

- [ ] **Step 3: Add the dependency**

Append to `src/net_alpha/web/dependencies.py`:

```python
from net_alpha.prefs.profile import ProfileSettings, resolve_effective_profile


def get_profile_settings(
    request: Request,
    account: str | None = None,
) -> ProfileSettings:
    """Resolve the rendering profile for the current request.

    Reads the optional `account` query string (display form 'Broker/Label'),
    looks up the account id, and merges per-account preferences according to
    `resolve_effective_profile`.
    """
    settings: Settings = request.app.state.settings
    engine = get_engine(settings.db_path)
    repo = Repository(engine)
    prefs = repo.list_user_preferences()
    filter_id: int | None = None
    if account:
        for a in repo.list_accounts():
            if f"{a.broker}/{a.label}" == account:
                filter_id = a.id
                break
    return resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/web/test_get_profile_settings_dep.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/dependencies.py tests/web/test_get_profile_settings_dep.py
git commit -m "feat(web): get_profile_settings FastAPI dependency"
```

---

## Section D — POST /preferences + switcher UI (Tasks 9-12)

Form handler that writes a single preference row, plus the toolbar dropdown that POSTs to it.

### Task 9: POST /preferences route

**Files:**
- Create: `src/net_alpha/web/routes/preferences.py`
- Modify: `src/net_alpha/web/app.py`
- Test: `tests/web/test_preferences_route.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_preferences_route.py
from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.web.app import create_app


def _bootstrap(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    repo.get_or_create_account("Schwab", "Tax")
    return settings, repo


def test_post_preferences_creates_row(tmp_path):
    from fastapi.testclient import TestClient

    settings, repo = _bootstrap(tmp_path)
    app = create_app(settings)
    client = TestClient(app)

    aid = repo.list_accounts()[0].id
    resp = client.post(
        "/preferences",
        data={"account_id": str(aid), "profile": "options", "density": "tax"},
    )
    assert resp.status_code == 204
    assert resp.headers.get("hx-refresh") == "true"

    pref = repo.get_user_preference(aid)
    assert pref.profile == "options"
    assert pref.density == "tax"


def test_post_preferences_rejects_invalid_profile(tmp_path):
    from fastapi.testclient import TestClient

    settings, repo = _bootstrap(tmp_path)
    app = create_app(settings)
    client = TestClient(app)

    aid = repo.list_accounts()[0].id
    resp = client.post(
        "/preferences",
        data={"account_id": str(aid), "profile": "bogus", "density": "comfortable"},
    )
    assert resp.status_code == 422


def test_post_preferences_rejects_unknown_account(tmp_path):
    from fastapi.testclient import TestClient

    settings, _ = _bootstrap(tmp_path)
    app = create_app(settings)
    client = TestClient(app)

    resp = client.post(
        "/preferences",
        data={"account_id": "99999", "profile": "active", "density": "comfortable"},
    )
    assert resp.status_code == 404


def test_post_preferences_all_accounts(tmp_path):
    """When no account_id given, write the same prefs to every account."""
    from fastapi.testclient import TestClient

    settings, repo = _bootstrap(tmp_path)
    repo.get_or_create_account("Schwab", "Roth")
    app = create_app(settings)
    client = TestClient(app)

    resp = client.post(
        "/preferences",
        data={"profile": "conservative", "density": "comfortable"},
    )
    assert resp.status_code == 204
    for a in repo.list_accounts():
        pref = repo.get_user_preference(a.id)
        assert pref.profile == "conservative"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_preferences_route.py -v`
Expected: FAIL — 404 on POST /preferences

- [ ] **Step 3: Create the route**

Create `src/net_alpha/web/routes/preferences.py`:

```python
"""POST /preferences — write per-account profile + density.

Returns 204 + HX-Refresh: true so HTMX clients reload the current page.
Form params:
    account_id (optional, int)
    profile    (required, 'conservative' | 'active' | 'options')
    density    (required, 'compact' | 'comfortable' | 'tax')

When account_id is omitted, the same prefs are written to every existing
account (the "all accounts" shortcut from the first-visit modal).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, Depends, Form, HTTPException, Response

from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference, Density, Profile
from net_alpha.web.dependencies import get_repository

router = APIRouter()

_VALID_PROFILES = {"conservative", "active", "options"}
_VALID_DENSITIES = {"compact", "comfortable", "tax"}


@router.post("/preferences", status_code=204)
def post_preferences(
    profile: str = Form(...),
    density: str = Form(...),
    account_id: int | None = Form(default=None),
    repo: Repository = Depends(get_repository),
) -> Response:
    if profile not in _VALID_PROFILES or density not in _VALID_DENSITIES:
        raise HTTPException(status_code=422, detail="invalid profile or density")

    accounts = repo.list_accounts()
    targets: list[int]
    if account_id is None:
        targets = [a.id for a in accounts]
    else:
        if not any(a.id == account_id for a in accounts):
            raise HTTPException(status_code=404, detail="account not found")
        targets = [account_id]

    now = datetime.now(timezone.utc)
    for aid in targets:
        repo.upsert_user_preference(
            AccountPreference(
                account_id=aid,
                profile=profile,  # type: ignore[arg-type]
                density=density,  # type: ignore[arg-type]
                updated_at=now,
            )
        )

    headers = {"HX-Refresh": "true"}
    return Response(status_code=204, headers=headers)
```

- [ ] **Step 4: Register the router**

Edit `src/net_alpha/web/app.py` — add the import and `include_router` call.

Add to imports near the other route imports:

```python
from net_alpha.web.routes import preferences as preferences_routes
```

Add inside `create_app`, after `app.include_router(audit_routes.router)`:

```python
    app.include_router(preferences_routes.router)
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_preferences_route.py -v`
Expected: PASS (4 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/preferences.py src/net_alpha/web/app.py tests/web/test_preferences_route.py
git commit -m "feat(web): POST /preferences writes per-account or all-account prefs"
```

---

### Task 10: Toolbar profile switcher template

**Files:**
- Create: `src/net_alpha/web/templates/_profile_switcher.html`
- Test: `tests/web/test_profile_switcher_render.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_profile_switcher_render.py
from fastapi import FastAPI
from fastapi.testclient import TestClient
from importlib.resources import files
from fastapi.templating import Jinja2Templates

from net_alpha.models.domain import Account
from net_alpha.prefs.profile import ProfileSettings


def test_profile_switcher_lists_each_account_with_profile_dropdown(tmp_path):
    templates_dir = files("net_alpha.web") / "templates"
    templates = Jinja2Templates(directory=str(templates_dir))
    app = FastAPI()

    @app.get("/x")
    def _ep(request):  # type: ignore[no-untyped-def]
        return templates.TemplateResponse(
            request,
            "_profile_switcher.html",
            {
                "accounts": [Account(id=1, broker="Schwab", label="Tax"),
                             Account(id=2, broker="Schwab", label="Roth")],
                "account_profiles": {1: "active", 2: "options"},
                "profile": ProfileSettings(profile="active", density="comfortable"),
            },
        )

    client = TestClient(app)
    html = client.get("/x").text
    assert "Schwab/Tax" in html
    assert "Schwab/Roth" in html
    assert 'name="profile"' in html
    assert 'value="conservative"' in html
    assert 'value="active"' in html
    assert 'value="options"' in html


def test_profile_switcher_marks_current_profile(tmp_path):
    templates_dir = files("net_alpha.web") / "templates"
    templates = Jinja2Templates(directory=str(templates_dir))
    app = FastAPI()

    @app.get("/x")
    def _ep(request):  # type: ignore[no-untyped-def]
        return templates.TemplateResponse(
            request,
            "_profile_switcher.html",
            {
                "accounts": [Account(id=1, broker="Schwab", label="Tax")],
                "account_profiles": {1: "options"},
                "profile": ProfileSettings(profile="options", density="comfortable"),
            },
        )

    client = TestClient(app)
    html = client.get("/x").text
    # the dropdown for account 1 should preselect "options"
    assert 'value="options" selected' in html
```

(`tests/web/conftest.py` already exposes a `request` injection pattern — if not, swap to use `request.app.state.templates` and a real `create_app` bootstrap instead.)

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_profile_switcher_render.py -v`
Expected: FAIL — `TemplateNotFound: _profile_switcher.html`

- [ ] **Step 3: Create the template**

Create `src/net_alpha/web/templates/_profile_switcher.html`:

```jinja
{# Inputs:
    accounts: list[Account]   — every account in the DB
    account_profiles: dict[int, str]   — account_id -> profile slug
    profile: ProfileSettings  — current effective profile (label only)
#}
<div x-data="{ open: false }" class="relative inline-block">
  <button type="button"
          class="px-2 py-1 rounded bg-surface text-text text-[12px] flex items-center gap-1"
          style="border:0.5px solid rgba(255,255,255,0.08);"
          @click="open = !open">
    <span class="capitalize">{{ profile.profile }}</span>
    <span class="text-label-3" aria-hidden="true">▾</span>
  </button>
  <div x-show="open" x-cloak
       class="absolute right-0 mt-1 z-30 bg-surface text-text rounded shadow-lg p-3 min-w-[280px]"
       style="border:0.5px solid rgba(255,255,255,0.08);">
    <div class="text-[11px] text-label-3 mb-2">Profile per account</div>
    {% for a in accounts %}
      {% set current = account_profiles.get(a.id, 'active') %}
      <form method="post" action="/preferences" class="flex items-center gap-2 mb-2">
        <input type="hidden" name="account_id" value="{{ a.id }}">
        <input type="hidden" name="density" value="{{ profile.density }}">
        <span class="text-[12px] flex-1 truncate">{{ a.broker }}/{{ a.label }}</span>
        <select name="profile" onchange="this.form.submit()"
                class="bg-bg text-text rounded px-1 py-0.5 text-[12px]"
                style="border:0.5px solid rgba(255,255,255,0.08);">
          <option value="conservative"{% if current == "conservative" %} selected{% endif %}>Conservative</option>
          <option value="active"{% if current == "active" %} selected{% endif %}>Active</option>
          <option value="options"{% if current == "options" %} selected{% endif %}>Options</option>
        </select>
      </form>
    {% endfor %}
  </div>
</div>
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/web/test_profile_switcher_render.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/templates/_profile_switcher.html tests/web/test_profile_switcher_render.py
git commit -m "feat(web): toolbar profile switcher template"
```

---

### Task 11: Inject switcher into base.html topbar

**Files:**
- Modify: `src/net_alpha/web/templates/base.html`
- Modify: `src/net_alpha/web/app.py` (template global for prefs lookup)
- Test: `tests/web/test_base_topbar_switcher.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_base_topbar_switcher.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def test_base_topbar_includes_profile_switcher(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile="options",
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/").text
    # The switcher button label uses the profile name
    assert ">options<" in html.lower() or "options</span>" in html
    # And it includes a per-account form action to /preferences
    assert 'action="/preferences"' in html


def test_base_topbar_omitted_when_no_accounts(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/").text
    assert 'action="/preferences"' not in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_base_topbar_switcher.py -v`
Expected: FAIL — switcher not present in base.html

- [ ] **Step 3: Wire template globals in app.py**

Edit `src/net_alpha/web/app.py` — register a globals function so `base.html` can render the switcher without each route passing data.

Below the existing `templates.env.globals["imports_badge_count"] = _imports_badge_count` line, add:

```python
    def _profile_switcher_data() -> dict[str, object]:
        from net_alpha.db.repository import Repository as _Repository
        from net_alpha.prefs.profile import (
            DEFAULT_PROFILE_SETTINGS,
            resolve_effective_profile,
        )

        _engine = get_engine(settings.db_path)
        _repo = _Repository(_engine)
        accounts = _repo.list_accounts()
        prefs = _repo.list_user_preferences()
        prof_by_id = {p.account_id: p.profile for p in prefs}
        profile = resolve_effective_profile(prefs=prefs, filter_account_id=None)
        return {
            "accounts": accounts,
            "account_profiles": prof_by_id,
            "profile": profile if accounts else DEFAULT_PROFILE_SETTINGS,
            "show_switcher": bool(accounts),
        }

    templates.env.globals["profile_switcher_data"] = _profile_switcher_data
```

- [ ] **Step 4: Render the switcher in base.html topbar**

Edit `src/net_alpha/web/templates/base.html` — replace the `{% block topbar_right %}{% endblock %}` line with:

```jinja
      {% set _ps = profile_switcher_data() %}
      {% if _ps.show_switcher %}
        {% with accounts=_ps.accounts, account_profiles=_ps.account_profiles, profile=_ps.profile %}
          {% include "_profile_switcher.html" %}
        {% endwith %}
      {% endif %}
      {% block topbar_right %}{% endblock %}
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_base_topbar_switcher.py -v`
Expected: PASS (2 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/app.py src/net_alpha/web/templates/base.html tests/web/test_base_topbar_switcher.py
git commit -m "feat(web): render profile switcher in base topbar"
```

---

### Task 12: First-visit modal

**Files:**
- Create: `src/net_alpha/web/templates/_profile_picker_modal.html`
- Modify: `src/net_alpha/web/templates/base.html`
- Test: `tests/web/test_first_visit_modal.py` (create)

The modal appears on every page load when **zero `user_preferences` rows exist** — server-side check, no cookie. After the user POSTs to `/preferences` (even once), at least one row exists and the modal stops rendering.

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_first_visit_modal.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def test_modal_shows_when_no_prefs_rows_and_accounts_exist(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    repo.get_or_create_account("Schwab", "Tax")
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/").text
    assert "Pick a default profile per account" in html


def test_modal_hidden_when_any_pref_exists(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile="active",
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/").text
    assert "Pick a default profile per account" not in html


def test_modal_hidden_when_no_accounts_at_all(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/").text
    assert "Pick a default profile per account" not in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_first_visit_modal.py -v`
Expected: FAIL — modal text not present

- [ ] **Step 3: Create the modal template**

Create `src/net_alpha/web/templates/_profile_picker_modal.html`:

```jinja
{# Inputs:
    accounts: list[Account]
   Renders an Alpine-driven dialog with Conservative/Active/Options choices.
   "Use same profile for all accounts" omits account_id from the form.
   "Pick per-account" expands to per-account dropdowns.
   Dismissing without choosing = posting nothing; the modal will reappear next
   load until at least one preference row exists. #}
<dialog id="profile-picker-modal"
        x-data="{ mode: 'all', profile: 'active' }"
        x-init="setTimeout(() => $el.showModal(), 0)"
        class="bg-bg text-text rounded p-0 backdrop:bg-black/50">
  <div class="p-5 min-w-[440px]">
    <h2 class="text-[16px] font-semibold mb-2">Pick a default profile per account</h2>
    <p class="text-[12px] text-label-2 mb-3">
      Profiles change <em>defaults</em>; nothing is hidden permanently. Switch any time
      from the toolbar.
    </p>

    <fieldset class="mb-3">
      <label class="flex items-start gap-2 mb-2">
        <input type="radio" name="mode" value="all" class="mt-1" x-model="mode">
        <div>
          <div class="text-[13px] font-medium">Use the same profile for all accounts</div>
          <div class="text-[11px] text-label-3">Recommended if your strategy is uniform.</div>
        </div>
      </label>
      <label class="flex items-start gap-2">
        <input type="radio" name="mode" value="per" class="mt-1" x-model="mode">
        <div>
          <div class="text-[13px] font-medium">Pick per-account</div>
          <div class="text-[11px] text-label-3">Best when one account is taxable + traded actively, another is buy-and-hold.</div>
        </div>
      </label>
    </fieldset>

    <div x-show="mode === 'all'">
      <form method="post" action="/preferences" class="flex flex-col gap-3">
        <input type="hidden" name="density" value="comfortable">
        <fieldset>
          <label class="flex items-start gap-2 mb-2">
            <input type="radio" name="profile" value="conservative" x-model="profile">
            <div>
              <div class="text-[13px] font-medium">Conservative</div>
              <div class="text-[11px] text-label-3">Long-term investing, periodic rebalance, taxes once a year.</div>
            </div>
          </label>
          <label class="flex items-start gap-2 mb-2">
            <input type="radio" name="profile" value="active" x-model="profile">
            <div>
              <div class="text-[13px] font-medium">Active</div>
              <div class="text-[11px] text-label-3">Frequent equity trading; wash-sale watch is your friend.</div>
            </div>
          </label>
          <label class="flex items-start gap-2 mb-2">
            <input type="radio" name="profile" value="options" x-model="profile">
            <div>
              <div class="text-[13px] font-medium">Options</div>
              <div class="text-[11px] text-label-3">Wheel/CSP/CC strategies; premium tracking matters.</div>
            </div>
          </label>
        </fieldset>
        <button type="submit" class="btn-primary self-end">Save</button>
      </form>
    </div>

    <div x-show="mode === 'per'" class="flex flex-col gap-2">
      {% for a in accounts %}
        <form method="post" action="/preferences" class="flex items-center gap-2">
          <input type="hidden" name="account_id" value="{{ a.id }}">
          <input type="hidden" name="density" value="comfortable">
          <span class="text-[12px] flex-1 truncate">{{ a.broker }}/{{ a.label }}</span>
          <select name="profile"
                  class="bg-surface text-text rounded px-2 py-1 text-[12px]"
                  style="border:0.5px solid rgba(255,255,255,0.08);">
            <option value="active" selected>Active</option>
            <option value="conservative">Conservative</option>
            <option value="options">Options</option>
          </select>
          <button type="submit" class="btn-ghost">Save</button>
        </form>
      {% endfor %}
    </div>
  </div>
</dialog>
```

- [ ] **Step 4: Inject the modal into base.html**

Edit `src/net_alpha/web/templates/base.html` — add a globals call and a conditional include just before `</body>`.

In `app.py`, append a second template global (next to `_profile_switcher_data`):

```python
    def _first_visit_modal_data() -> dict[str, object]:
        from net_alpha.db.repository import Repository as _Repository

        _engine = get_engine(settings.db_path)
        _repo = _Repository(_engine)
        accounts = _repo.list_accounts()
        prefs = _repo.list_user_preferences()
        return {
            "show_modal": bool(accounts) and not prefs,
            "accounts": accounts,
        }

    templates.env.globals["first_visit_modal_data"] = _first_visit_modal_data
```

In `src/net_alpha/web/templates/base.html`, just before `</body>`, add:

```jinja
  {% set _fvm = first_visit_modal_data() %}
  {% if _fvm.show_modal %}
    {% with accounts=_fvm.accounts %}
      {% include "_profile_picker_modal.html" %}
    {% endwith %}
  {% endif %}
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_first_visit_modal.py -v`
Expected: PASS (3 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_profile_picker_modal.html src/net_alpha/web/templates/base.html src/net_alpha/web/app.py tests/web/test_first_visit_modal.py
git commit -m "feat(web): first-visit profile picker modal"
```

---

## Section E — Apply profile to /portfolio (Tasks 13-15)

Profile drives KPI hero ordering and wash-watch collapsed-default. Lockout calendar isn't built — `profile.shows("lockout_calendar")` is wired through but the surface is a no-op for now (graceful — surfaces can be added without changing rules).

### Task 13: Inject ProfileSettings into portfolio context

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Test: `tests/web/test_portfolio_profile_context.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_portfolio_profile_context.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def test_portfolio_kpis_passes_profile_into_template(tmp_path):
    """profile.profile should appear as a class on the KPI hero container."""
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile="options",
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/portfolio/kpis", params={"account": "Schwab/Tax"}).text
    # Marker so we can assert profile reached the KPI fragment.
    assert 'data-profile="options"' in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_portfolio_profile_context.py -v`
Expected: FAIL — `data-profile` attribute absent

- [ ] **Step 3: Pass profile into context**

Edit `src/net_alpha/web/routes/portfolio.py` — find the `portfolio_kpis` route handler and the `portfolio_body` route handler. Both call `request.app.state.templates.TemplateResponse(...)`. Inject profile into the context dict.

Add the import near other prefs imports:

```python
from net_alpha.prefs.profile import resolve_effective_profile
```

Add a helper near the top of the module (above the route handlers):

```python
def _resolve_profile(repo: Repository, account: str | None):
    prefs = repo.list_user_preferences()
    filter_id = _resolve_account_id(account, repo)
    return resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)
```

Inside `portfolio_kpis(...)` (the function that renders `_portfolio_kpis.html`), before the TemplateResponse return, add:

```python
    profile = _resolve_profile(repo, account)
```

Then add `"profile": profile` to the context dict.

Repeat in `portfolio_body(...)` and any other portfolio fragment handler that renders a template that ought to know the profile.

- [ ] **Step 4: Render data-profile in _portfolio_kpis.html**

Edit `src/net_alpha/web/templates/_portfolio_kpis.html` — wrap the existing top-level `<div class="grid grid-cols-12 gap-[10px]">` to add `data-profile="{{ profile.profile }}"`. Replace:

```jinja
<div class="grid grid-cols-12 gap-[10px]">
```

With:

```jinja
<div class="grid grid-cols-12 gap-[10px]" data-profile="{{ profile.profile if profile is defined else 'active' }}">
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_portfolio_profile_context.py -v`
Expected: PASS (1 test)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/templates/_portfolio_kpis.html tests/web/test_portfolio_profile_context.py
git commit -m "feat(web): pass ProfileSettings into /portfolio context"
```

---

### Task 14: Wash-watch collapsed-by-default for conservative

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_wash_watch.html`
- Modify: `src/net_alpha/web/routes/portfolio.py` (pass profile + violation_count)
- Test: `tests/web/test_wash_watch_collapse.py` (create)

Spec: "Collapsed (auto-expands when violation present)" for conservative.

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_wash_watch_collapse.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def _seed(tmp_path, profile_label):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile=profile_label,
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    return TestClient(app)


def test_wash_watch_open_for_active(tmp_path):
    client = _seed(tmp_path, "active")
    html = client.get("/portfolio/body", params={"account": "Schwab/Tax"}).text
    # <details ... open> when active
    assert "<details open" in html


def test_wash_watch_collapsed_for_conservative_when_no_violation(tmp_path):
    client = _seed(tmp_path, "conservative")
    html = client.get("/portfolio/body", params={"account": "Schwab/Tax"}).text
    # <details> without "open" attribute
    assert "<details>" in html or "<details \n" in html
    assert "<details open" not in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_wash_watch_collapse.py -v`
Expected: FAIL — wash-watch is currently a plain `<div>`, not `<details>`

- [ ] **Step 3: Wrap wash watch in <details>**

Edit `src/net_alpha/web/templates/_portfolio_wash_watch.html` — wrap the entire content in a `<details>` element keyed off `profile.shows("wash_watch_expanded")` and an auto-open when there are recent loss closes.

Replace the file's content with:

```jinja
{# Inputs:
    rows: list[LossCloseRow]
    window_days: int (default 30)
    profile: ProfileSettings (optional; absent => default open) #}
{% set window = window_days|default(30) %}
{% set _expanded = (profile.shows("wash_watch_expanded") if profile is defined else True) or (rows|length > 0) %}

<details {% if _expanded %}open{% endif %}>
  <summary class="panel-head cursor-pointer">
    <h4>Wash-sale watch</h4>
    <span class="meta">
      Loss closes in the last {{ window }} days · don't buy back ·
      {{ rows|length }} symbol{% if rows|length != 1 %}s{% endif %}
    </span>
  </summary>

{% if not rows %}
  <div class="text-label-2 text-[13px] py-3">All clear · no loss closes in the last {{ window }} days.</div>
{% else %}
  <div class="flex flex-col">
    {% for r in rows %}
      {% if r.days_to_safe >= 21 %}{% set cd_class = 'text-neg' %}
      {% elif r.days_to_safe >= 7 %}{% set cd_class = 'text-warn' %}
      {% else %}{% set cd_class = 'text-pos' %}{% endif %}
      {% set fill_pct = (r.days_since / window * 100)|round(0, 'common') %}
      <div class="grid items-center gap-[14px] py-[9px] text-[13px]"
           style="grid-template-columns: 90px 90px 1fr 110px; border-bottom: 0.5px solid rgba(255,255,255,0.08);">
        <div class="flex items-center gap-2 font-semibold tracking-tightish">
          <span style="width:6px; height:6px; border-radius:50%; background:#FF453A; box-shadow: 0 0 6px #FF453A;"></span>
          {{ r.symbol }}
        </div>
        <div class="num text-neg text-[12px] font-medium">−${{ "%.2f"|format(r.loss_amount|float) }}</div>
        <div class="flex items-center gap-[10px]">
          <span class="text-[11px] text-label-2 num min-w-[80px]">closed {{ r.days_since }}d ago</span>
          <div class="flex-1 h-[5px] rounded-full overflow-hidden" style="background: rgba(255,255,255,0.06);">
            <div style="width: {{ fill_pct }}%; height: 100%;
                        background: linear-gradient(90deg, #FF453A 0%, #FF9F0A 70%, #30D158 100%);
                        border-radius: 999px;"></div>
          </div>
        </div>
        <div class="text-right num text-[13px] font-semibold {{ cd_class }}">
          {{ r.days_to_safe }}d <small class="text-[10px] text-label-3 font-normal ml-1">to safe</small>
        </div>
      </div>
    {% endfor %}
  </div>
{% endif %}
</details>
```

- [ ] **Step 4: Pass profile into portfolio_body context**

Edit `src/net_alpha/web/routes/portfolio.py`'s `portfolio_body` handler. After computing `wash_watch_rows`, ensure the context dict includes `"profile": _resolve_profile(repo, account)`.

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_wash_watch_collapse.py -v`
Expected: PASS (2 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_wash_watch.html src/net_alpha/web/routes/portfolio.py tests/web/test_wash_watch_collapse.py
git commit -m "feat(web): conservative profile collapses wash-watch by default"
```

---

### Task 15: KPI hero ordering by profile

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_kpis.html`
- Test: `tests/web/test_kpi_hero_order.py` (create)

The current KPI hero is hard-coded to render `Realized | Unrealized | Open Position $ | Wash impact`. Phase 3 reorders by `profile.order("portfolio_kpi_hero")`.

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_kpi_hero_order.py
import re
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def _seed(tmp_path, profile_label):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile=profile_label,
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    return TestClient(app)


def _kpi_slot_order(html: str) -> list[str]:
    """Return the order of `data-kpi-slot` attribute values as they appear."""
    return re.findall(r'data-kpi-slot="([^"]+)"', html)


def test_kpi_order_conservative(tmp_path):
    client = _seed(tmp_path, "conservative")
    html = client.get("/portfolio/kpis", params={"account": "Schwab/Tax"}).text
    order = _kpi_slot_order(html)
    assert order[:3] == ["open_position", "lifetime_growth", "cash"]


def test_kpi_order_active(tmp_path):
    client = _seed(tmp_path, "active")
    html = client.get("/portfolio/kpis", params={"account": "Schwab/Tax"}).text
    order = _kpi_slot_order(html)
    assert order[:4] == ["ytd_realized", "ytd_unrealized", "wash_impact", "open_position"]


def test_kpi_order_options(tmp_path):
    client = _seed(tmp_path, "options")
    html = client.get("/portfolio/kpis", params={"account": "Schwab/Tax"}).text
    order = _kpi_slot_order(html)
    assert order[:4] == ["ytd_realized", "wash_impact", "open_position", "cash"]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_kpi_hero_order.py -v`
Expected: FAIL — no `data-kpi-slot` attributes

- [ ] **Step 3: Refactor KPI hero into named slots, iterate by profile.order**

Edit `src/net_alpha/web/templates/_portfolio_kpis.html`. Define a Jinja macro for each KPI slot, then iterate.

Replace the top portion (the first three `<div class="kpi ...">` blocks plus the wrapping grid open/close) with:

```jinja
{% from "_provenance_macros.html" import provenance_link %}
{% set partial = kpis.missing_symbols and (kpis.open_position_value is not none) %}
{% set period_label = kpis.period_label or 'Period' %}
{% set _profile = profile if profile is defined else None %}
{% set _slots = _profile.order("portfolio_kpi_hero") if _profile else ["ytd_realized", "ytd_unrealized", "wash_impact", "open_position"] %}

{% macro slot_ytd_realized(kpis, period_label, metric_refs) %}
  <div class="kpi kpi-hero col-span-3" data-kpi-slot="ytd_realized">
    <div class="label-uc">Realized P/L</div>
    <div class="num text-[22px] font-bold mt-2 {% if kpis.period_realized < 0 %}text-neg{% else %}text-pos{% endif %}">
      {% if kpis.period_realized < 0 %}−{% else %}+{% endif %}${{ "%.2f"|format(kpis.period_realized|float|abs) }}{% if metric_refs is defined and metric_refs.realized_period is defined %}{{ provenance_link(metric_refs.realized_period) }}{% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">{{ period_label }}</div>
  </div>
{% endmacro %}

{% macro slot_ytd_unrealized(kpis, period_label, metric_refs) %}
  <div class="kpi col-span-3" data-kpi-slot="ytd_unrealized">
    <div class="label-uc">Unrealized P/L</div>
    <div class="num text-[22px] font-bold mt-2">
      {% if kpis.period_unrealized is none %}<span class="text-label-3">—</span>
      {% elif kpis.period_unrealized < 0 %}<span class="text-neg">−${{ "%.2f"|format(kpis.period_unrealized|float|abs) }}</span>
      {% else %}<span class="text-pos">+${{ "%.2f"|format(kpis.period_unrealized|float) }}</span>
      {% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">{{ period_label }}</div>
  </div>
{% endmacro %}

{% macro slot_lifetime_growth(kpis) %}
  <div class="kpi col-span-3" data-kpi-slot="lifetime_growth">
    <div class="label-uc">Lifetime growth</div>
    <div class="num text-[22px] font-bold mt-2 {% if kpis.lifetime_realized < 0 %}text-neg{% else %}text-pos{% endif %}">
      {% if kpis.lifetime_realized < 0 %}−{% else %}+{% endif %}${{ "%.2f"|format(kpis.lifetime_realized|float|abs) }}
    </div>
    <div class="text-[11px] text-label-3 mt-1">all time</div>
  </div>
{% endmacro %}

{% macro slot_open_position(kpis) %}
  <div class="kpi col-span-3" data-kpi-slot="open_position">
    <div class="label-uc">Open position $</div>
    <div class="num text-[22px] font-bold mt-2">
      {% if kpis.open_position_value is none %}<span class="text-label-3">—</span>
      {% else %}${{ "%.2f"|format(kpis.open_position_value|float) }}{% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">
      {% if kpis.missing_symbols %}{{ kpis.missing_symbols|length }} unpriced{% else %}all priced{% endif %}
    </div>
  </div>
{% endmacro %}

{% macro slot_wash_impact(metric_refs) %}
  <div class="kpi col-span-3" data-kpi-slot="wash_impact">
    <div class="label-uc">Wash impact</div>
    <div class="num text-[22px] font-bold mt-2">
      {% if wash_impact_total is defined and wash_impact_total %}
        <span class="text-warn">−${{ "%.2f"|format(wash_impact_total|float|abs) }}</span>
      {% else %}
        <span class="text-label-3">$0.00</span>
      {% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">
      {% if wash_violations is defined and wash_violations %}{{ wash_violations }} violation{% if wash_violations != 1 %}s{% endif %}{% else %}no violations{% endif %}
    </div>
  </div>
{% endmacro %}

{% macro slot_cash(cash_kpis) %}
  <div class="kpi col-span-3" data-kpi-slot="cash">
    <div class="label-uc">Cash</div>
    <div class="num text-[22px] font-bold mt-2">
      {% if cash_kpis is defined and cash_kpis %}
        {% if cash_kpis.cash_balance < 0 %}<span class="text-neg">−${{ "%.2f"|format(cash_kpis.cash_balance|float|abs) }}</span>
        {% else %}${{ "%.2f"|format(cash_kpis.cash_balance|float) }}{% endif %}
      {% else %}<span class="text-label-3">—</span>{% endif %}
    </div>
    <div class="text-[11px] text-label-3 mt-1">
      {% if cash_kpis is defined and cash_kpis %}{{ "%.0f"|format((cash_kpis.cash_share_pct|float) * 100) }}% of account{% endif %}
    </div>
  </div>
{% endmacro %}

<div class="grid grid-cols-12 gap-[10px]" data-profile="{{ _profile.profile if _profile else 'active' }}">
  {% for slot in _slots %}
    {% if slot == "ytd_realized" %}{{ slot_ytd_realized(kpis, period_label, metric_refs if metric_refs is defined else {}) }}
    {% elif slot == "ytd_unrealized" %}{{ slot_ytd_unrealized(kpis, period_label, metric_refs if metric_refs is defined else {}) }}
    {% elif slot == "lifetime_growth" %}{{ slot_lifetime_growth(kpis) }}
    {% elif slot == "open_position" %}{{ slot_open_position(kpis) }}
    {% elif slot == "wash_impact" %}{{ slot_wash_impact(metric_refs if metric_refs is defined else {}) }}
    {% elif slot == "cash" %}{{ slot_cash(cash_kpis if cash_kpis is defined else None) }}
    {% endif %}
  {% endfor %}
</div>
```

Then keep the rest of the existing file from `{% if offset_budget is defined and offset_budget %}` onward unchanged (offset budget tile, projection card, secondary cash row, snapshot warning).

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/web/test_kpi_hero_order.py -v`
Expected: PASS (3 tests)

- [ ] **Step 5: Run regression check on existing portfolio render tests**

Run: `uv run pytest tests/web/ -v -k "portfolio"`
Expected: all PASS (the macro refactor preserves rendered fields; if a snapshot test breaks, update its expected order to match the active profile default).

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_kpis.html tests/web/test_kpi_hero_order.py
git commit -m "feat(web): KPI hero ordering driven by ProfileSettings.order"
```

---

## Section F — Apply profile to /holdings + density toggle (Tasks 16-21)

Holdings table gets profile-driven column visibility. Density toggle persists per-account default in `user_preferences.density`, with transient `localStorage` override per page.

### Task 16: Compute days_held + lt_st_split per position

**Files:**
- Modify: `src/net_alpha/portfolio/models.py`
- Modify: `src/net_alpha/portfolio/positions.py`
- Test: `tests/portfolio/test_positions_density_extras.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/portfolio/test_positions_density_extras.py
from datetime import date
from decimal import Decimal

import factory

from net_alpha.models.domain import Lot, Trade
from net_alpha.portfolio.positions import compute_open_positions
from net_alpha.pricing.service import Quote


class _LotF(factory.Factory):
    class Meta:
        model = Lot

    id = factory.Sequence(lambda n: str(n + 1))
    account = "Schwab/Tax"
    ticker = "AAPL"
    quantity = 100.0
    cost_basis = 10000.0
    adjusted_basis = 10000.0
    date = date(2024, 1, 1)
    option_details = None


class _BuyF(factory.Factory):
    class Meta:
        model = Trade

    account = "Schwab/Tax"
    date = date(2024, 1, 1)
    ticker = "AAPL"
    action = "Buy"
    quantity = 100.0
    proceeds = None
    cost_basis = 10000.0


def test_position_row_carries_oldest_lot_age_days():
    """When a single open lot, days_held = today - lot.date."""
    lots = [_LotF(quantity=100.0, date=date(2024, 1, 1))]
    trades = [_BuyF(quantity=100.0, date=date(2024, 1, 1))]
    rows = compute_open_positions(
        trades=trades,
        lots=lots,
        prices={"AAPL": Quote(symbol="AAPL", price=Decimal("150"), as_of=date(2026, 4, 27), source="test")},
        as_of=date(2026, 4, 27),
    )
    aapl = next(r for r in rows if r.symbol == "AAPL")
    assert aapl.days_held == (date(2026, 4, 27) - date(2024, 1, 1)).days


def test_position_row_carries_lt_st_split():
    """Open lots > 365 days = LT, otherwise ST. Split on a per-share basis."""
    lots = [
        _LotF(id="1", quantity=70.0, date=date(2024, 1, 1)),  # >365d on 2026-04-27 -> LT
        _LotF(id="2", quantity=30.0, date=date(2026, 1, 1)),  # <365d on 2026-04-27 -> ST
    ]
    trades = [
        _BuyF(quantity=70.0, date=date(2024, 1, 1)),
        _BuyF(quantity=30.0, date=date(2026, 1, 1)),
    ]
    rows = compute_open_positions(
        trades=trades,
        lots=lots,
        prices={"AAPL": Quote(symbol="AAPL", price=Decimal("150"), as_of=date(2026, 4, 27), source="test")},
        as_of=date(2026, 4, 27),
    )
    aapl = next(r for r in rows if r.symbol == "AAPL")
    assert aapl.lt_qty == Decimal("70")
    assert aapl.st_qty == Decimal("30")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_positions_density_extras.py -v`
Expected: FAIL — `PositionRow` has no `days_held` / `lt_qty` / `st_qty` attributes

- [ ] **Step 3: Extend PositionRow**

Edit `src/net_alpha/portfolio/models.py` — append three optional fields to `PositionRow`:

```python
    # Phase 3 density extras — populated only when as_of is provided to the
    # compute function. None when not computed (older callers unaffected).
    days_held: int | None = None  # oldest open lot age, in days
    lt_qty: Decimal = Decimal("0")  # qty held > 365 days
    st_qty: Decimal = Decimal("0")  # qty held <= 365 days
```

- [ ] **Step 4: Compute the extras in compute_open_positions**

Edit `src/net_alpha/portfolio/positions.py` — modify the signature and the row builder. Add `as_of: date | None = None` parameter, and after the existing aggregation loop, compute `days_held` from oldest consumed lot date and split LT/ST quantities at >365 vs ≤365 days.

Find the `compute_open_positions` signature and add the kwarg:

```python
def compute_open_positions(
    *,
    trades: Iterable[Trade],
    lots: Iterable[Lot],
    prices: dict[str, Quote],
    period: tuple[int, int] | None = None,
    account: str | None = None,
    include_closed: bool = False,
    gl_closures: dict[tuple[str, str], float] | None = None,
    gl_option_closures: dict[tuple[str, str, float, object, str], float] | None = None,
    as_of: date | None = None,
) -> list[PositionRow]:
```

After the existing per-symbol aggregation (where `qty_by_sym`/`open_cost_by_sym` get filled), add a new aggregation alongside it:

```python
    LT_DAYS = 365
    today = as_of or date.today()
    oldest_open_by_sym: dict[str, date] = {}
    lt_qty_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    st_qty_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    for lot, rem_qty, rem_basis in consumed:
        if lot.option_details is not None or rem_qty <= 0:
            continue
        sym = lot.ticker
        prior = oldest_open_by_sym.get(sym)
        if prior is None or lot.date < prior:
            oldest_open_by_sym[sym] = lot.date
        if (today - lot.date).days > LT_DAYS:
            lt_qty_by_sym[sym] += rem_qty
        else:
            st_qty_by_sym[sym] += rem_qty
```

Then in the loop that builds each `PositionRow`, add the new fields:

```python
        oldest = oldest_open_by_sym.get(symbol)
        days_held = (today - oldest).days if oldest is not None else None
        rows.append(
            PositionRow(
                ...
                days_held=days_held,
                lt_qty=lt_qty_by_sym[symbol],
                st_qty=st_qty_by_sym[symbol],
            )
        )
```

(Substitute the `...` for the existing kwargs already in the call site.)

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/portfolio/test_positions_density_extras.py -v`
Expected: PASS (2 tests)

- [ ] **Step 6: Run full positions test suite for regressions**

Run: `uv run pytest tests/portfolio/test_positions.py -v`
Expected: all PASS (legacy callers passed `as_of=None` implicitly, defaults to today, doesn't break old assertions because `days_held` etc. are not asserted there).

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/portfolio/models.py src/net_alpha/portfolio/positions.py tests/portfolio/test_positions_density_extras.py
git commit -m "feat(portfolio): position rows expose days_held + lt/st split"
```

---

### Task 17: Compute premium_received per position

**Files:**
- Modify: `src/net_alpha/portfolio/models.py`
- Modify: `src/net_alpha/portfolio/positions.py`
- Test: `tests/portfolio/test_positions_premium.py` (create)

`premium_received` = sum of net option premium captured (received − paid back) across all closed/expired option chains on the underlying.

- [ ] **Step 1: Write the failing test**

```python
# tests/portfolio/test_positions_premium.py
from datetime import date
from decimal import Decimal

from net_alpha.models.domain import Lot, OptionDetails, Trade
from net_alpha.portfolio.positions import compute_open_positions
from net_alpha.pricing.service import Quote


def test_premium_received_for_closed_csp():
    """Sell-to-open then buy-to-close a put — net premium = STO - BTC."""
    csp_open = Trade(
        account="Schwab/Tax",
        date=date(2026, 1, 1),
        ticker="AAPL",
        action="Sell to Open",
        quantity=1.0,
        proceeds=200.0,
        cost_basis=None,
        option_details=OptionDetails(strike=140.0, expiry=date(2026, 4, 17), call_put="P"),
    )
    csp_close = Trade(
        account="Schwab/Tax",
        date=date(2026, 3, 1),
        ticker="AAPL",
        action="Buy to Close",
        quantity=1.0,
        proceeds=None,
        cost_basis=50.0,
        option_details=OptionDetails(strike=140.0, expiry=date(2026, 4, 17), call_put="P"),
    )
    # Plus an open equity lot so AAPL appears as a position.
    eq_lot = Lot(
        id="1", account="Schwab/Tax", ticker="AAPL",
        quantity=100.0, cost_basis=10000.0, adjusted_basis=10000.0,
        date=date(2024, 1, 1),
    )
    eq_buy = Trade(
        account="Schwab/Tax", date=date(2024, 1, 1), ticker="AAPL",
        action="Buy", quantity=100.0, proceeds=None, cost_basis=10000.0,
    )

    rows = compute_open_positions(
        trades=[eq_buy, csp_open, csp_close],
        lots=[eq_lot],
        prices={"AAPL": Quote(symbol="AAPL", price=Decimal("150"), as_of=date(2026, 4, 27), source="test")},
        as_of=date(2026, 4, 27),
    )
    aapl = next(r for r in rows if r.symbol == "AAPL")
    assert aapl.premium_received == Decimal("150")  # 200 - 50


def test_premium_received_zero_when_no_options():
    eq_lot = Lot(
        id="1", account="Schwab/Tax", ticker="AAPL",
        quantity=100.0, cost_basis=10000.0, adjusted_basis=10000.0,
        date=date(2024, 1, 1),
    )
    eq_buy = Trade(
        account="Schwab/Tax", date=date(2024, 1, 1), ticker="AAPL",
        action="Buy", quantity=100.0, proceeds=None, cost_basis=10000.0,
    )
    rows = compute_open_positions(
        trades=[eq_buy],
        lots=[eq_lot],
        prices={"AAPL": Quote(symbol="AAPL", price=Decimal("150"), as_of=date(2026, 4, 27), source="test")},
        as_of=date(2026, 4, 27),
    )
    aapl = next(r for r in rows if r.symbol == "AAPL")
    assert aapl.premium_received == Decimal("0")
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/portfolio/test_positions_premium.py -v`
Expected: FAIL — `PositionRow` has no `premium_received`

- [ ] **Step 3: Extend PositionRow**

Edit `src/net_alpha/portfolio/models.py` — append:

```python
    premium_received: Decimal = Decimal("0")  # net option premium captured on this underlying
```

- [ ] **Step 4: Compute premium_received**

Edit `src/net_alpha/portfolio/positions.py` — in the trade aggregation loop (where `buys_by_sym`, `sells_by_sym`, `realized_by_sym` are filled), maintain a parallel `premium_by_sym`:

```python
    premium_by_sym: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    for t in trades:
        if t.option_details is None:
            continue
        sym = t.ticker
        # Receipts (sell-to-open / sell-to-close) credit premium; payments
        # (buy-to-open / buy-to-close) debit it.
        if t.proceeds is not None:
            premium_by_sym[sym] += Decimal(str(t.proceeds))
        if t.cost_basis is not None:
            premium_by_sym[sym] -= Decimal(str(t.cost_basis))
```

In the row constructor, add:

```python
        premium_received=premium_by_sym[symbol].quantize(Decimal("0.01")),
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/portfolio/test_positions_premium.py -v`
Expected: PASS (2 tests)

- [ ] **Step 6: Run full positions test suite**

Run: `uv run pytest tests/portfolio/test_positions.py -v`
Expected: all PASS

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/portfolio/models.py src/net_alpha/portfolio/positions.py tests/portfolio/test_positions_premium.py
git commit -m "feat(portfolio): premium_received per position for options profile"
```

---

### Task 18: Render extra columns in holdings table

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_table.html`
- Modify: `src/net_alpha/web/routes/holdings.py` (pass profile + columns)
- Test: `tests/web/test_holdings_columns_render.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_holdings_columns_render.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def _seed(tmp_path, profile_label, density="comfortable"):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile=profile_label,
            density=density,
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    return TestClient(app)


def test_holdings_conservative_no_extra_columns(tmp_path):
    client = _seed(tmp_path, "conservative")
    html = client.get("/holdings", params={"account": "Schwab/Tax"}).text
    assert 'data-col="days_held"' not in html
    assert 'data-col="lt_st_split"' not in html


def test_holdings_active_has_days_held_and_lt_st(tmp_path):
    client = _seed(tmp_path, "active")
    html = client.get("/holdings", params={"account": "Schwab/Tax"}).text
    assert 'data-col="days_held"' in html
    assert 'data-col="lt_st_split"' in html


def test_holdings_options_has_premium_received(tmp_path):
    client = _seed(tmp_path, "options")
    html = client.get("/holdings", params={"account": "Schwab/Tax"}).text
    assert 'data-col="premium_received"' in html


def test_holdings_compact_strips_all_extras(tmp_path):
    client = _seed(tmp_path, "options", density="compact")
    html = client.get("/holdings", params={"account": "Schwab/Tax"}).text
    assert 'data-col="premium_received"' not in html
    assert 'data-col="days_held"' not in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_holdings_columns_render.py -v`
Expected: FAIL — `data-col` markers not present

- [ ] **Step 3: Pass profile/columns into holdings template context**

Edit `src/net_alpha/web/routes/holdings.py` — add the import and resolver, then push `profile` and `extra_columns` into the context.

```python
from net_alpha.prefs.profile import resolve_effective_profile
```

Inside the route handler, before the TemplateResponse:

```python
    prefs = repo.list_user_preferences()
    filter_id = None
    if account:
        for a in repo.list_accounts():
            if f"{a.broker}/{a.label}" == account:
                filter_id = a.id
                break
    profile = resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)
    extra_columns = profile.default_columns("holdings")
```

Add to the context dict:

```python
            "profile": profile,
            "extra_columns": extra_columns,
```

- [ ] **Step 4: Render the columns conditionally**

Edit `src/net_alpha/web/templates/_portfolio_table.html`. After the existing `<th>` row, append conditional `<th>` cells. After each `<tr>` row that renders a position, append matching `<td>` cells.

In the table header (`<thead><tr>...</tr></thead>`):

```jinja
{% if extra_columns is defined %}
  {% if 'days_held' in extra_columns %}<th data-col="days_held" class="text-right">Days held</th>{% endif %}
  {% if 'lt_st_split' in extra_columns %}<th data-col="lt_st_split" class="text-right">LT / ST</th>{% endif %}
  {% if 'premium_received' in extra_columns %}<th data-col="premium_received" class="text-right">Prem.</th>{% endif %}
  {% if 'origin_event' in extra_columns %}<th data-col="origin_event">Origin</th>{% endif %}
  {% if 'days_to_ltcg' in extra_columns %}<th data-col="days_to_ltcg" class="text-right">→LTCG</th>{% endif %}
  {% if 'harvestable' in extra_columns %}<th data-col="harvestable" class="text-right">Harv.</th>{% endif %}
  {% if 'premium_offset' in extra_columns %}<th data-col="premium_offset" class="text-right">Prem.&nbsp;off</th>{% endif %}
{% endif %}
```

For each row in the body (inside the `{% for r in rows %}` block, before the closing `</tr>`):

```jinja
{% if extra_columns is defined %}
  {% if 'days_held' in extra_columns %}<td class="text-right num">{{ r.days_held if r.days_held is not none else '—' }}d</td>{% endif %}
  {% if 'lt_st_split' in extra_columns %}<td class="text-right num">{{ "%g"|format(r.lt_qty|float) }}LT / {{ "%g"|format(r.st_qty|float) }}ST</td>{% endif %}
  {% if 'premium_received' in extra_columns %}<td class="text-right num">${{ "%.0f"|format(r.premium_received|float) }}</td>{% endif %}
  {% if 'origin_event' in extra_columns %}<td>—</td>{% endif %}
  {% if 'days_to_ltcg' in extra_columns %}<td class="text-right num">—</td>{% endif %}
  {% if 'harvestable' in extra_columns %}<td class="text-right">—</td>{% endif %}
  {% if 'premium_offset' in extra_columns %}<td class="text-right num">—</td>{% endif %}
{% endif %}
```

(Stub `—` for `origin_event`, `days_to_ltcg`, `harvestable`, `premium_offset` — these are accepted as visible-but-empty for v1; deeper compute lives in Phase 4.)

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_holdings_columns_render.py -v`
Expected: PASS (4 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_table.html src/net_alpha/web/routes/holdings.py tests/web/test_holdings_columns_render.py
git commit -m "feat(web): profile-driven extra columns in holdings table"
```

---

### Task 19: Density toggle template

**Files:**
- Create: `src/net_alpha/web/templates/_density_toggle.html`
- Test: `tests/web/test_density_toggle_render.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_density_toggle_render.py
from importlib.resources import files

from fastapi import FastAPI
from fastapi.templating import Jinja2Templates
from fastapi.testclient import TestClient

from net_alpha.prefs.profile import ProfileSettings


def test_density_toggle_marks_current(tmp_path):
    templates_dir = files("net_alpha.web") / "templates"
    templates = Jinja2Templates(directory=str(templates_dir))
    app = FastAPI()

    @app.get("/x")
    def _ep(request):  # type: ignore[no-untyped-def]
        return templates.TemplateResponse(
            request,
            "_density_toggle.html",
            {
                "profile": ProfileSettings(profile="active", density="tax"),
                "page_key": "/holdings",
                "selected_account": "Schwab/Tax",
                "account_id": 1,
            },
        )

    html = TestClient(app).get("/x").text
    assert 'data-density="tax" aria-current="true"' in html
    assert 'data-density="compact"' in html
    assert 'data-density="comfortable"' in html
    assert 'data-page-key="/holdings"' in html


def test_density_toggle_omits_account_id_when_all(tmp_path):
    templates_dir = files("net_alpha.web") / "templates"
    templates = Jinja2Templates(directory=str(templates_dir))
    app = FastAPI()

    @app.get("/x")
    def _ep(request):  # type: ignore[no-untyped-def]
        return templates.TemplateResponse(
            request,
            "_density_toggle.html",
            {
                "profile": ProfileSettings(profile="active", density="comfortable"),
                "page_key": "/holdings",
                "selected_account": "",
                "account_id": None,
            },
        )

    html = TestClient(app).get("/x").text
    assert 'name="account_id"' not in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_density_toggle_render.py -v`
Expected: FAIL — `TemplateNotFound: _density_toggle.html`

- [ ] **Step 3: Create the toggle template**

Create `src/net_alpha/web/templates/_density_toggle.html`:

```jinja
{# Inputs:
    profile: ProfileSettings   — current profile (for .density)
    page_key: str              — e.g., "/holdings"; used for localStorage key
    selected_account: str      — display form, used to preserve filter on submit
    account_id: int | None     — when set, density write is per-account; else all
#}
<div class="density-toggle inline-flex items-center gap-1 text-[12px]"
     data-page-key="{{ page_key }}"
     x-data
     x-init="window.applyDensityFromLocalStorage && window.applyDensityFromLocalStorage($el)">
  <span class="text-label-3 mr-1">Density:</span>
  {% for d in ['compact', 'comfortable', 'tax'] %}
    <form method="post" action="/preferences" class="inline">
      {% if account_id is not none %}<input type="hidden" name="account_id" value="{{ account_id }}">{% endif %}
      <input type="hidden" name="profile" value="{{ profile.profile }}">
      <input type="hidden" name="density" value="{{ d }}">
      <button type="submit"
              class="px-2 py-0.5 rounded {% if profile.density == d %}bg-text text-bg{% else %}bg-surface{% endif %}"
              style="border:0.5px solid rgba(255,255,255,0.08);"
              data-density="{{ d }}"
              {% if profile.density == d %}aria-current="true"{% endif %}
              onclick="window.recordDensityOverride && window.recordDensityOverride('{{ page_key }}', '{{ d }}')">
        {{ {'compact':'Compact','comfortable':'Comfortable','tax':'Tax-view'}[d] }}
      </button>
    </form>
  {% endfor %}
</div>
```

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/web/test_density_toggle_render.py -v`
Expected: PASS (2 tests)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/templates/_density_toggle.html tests/web/test_density_toggle_render.py
git commit -m "feat(web): density toggle template (Compact / Comfortable / Tax-view)"
```

---

### Task 20: localStorage transient density override (JS)

**Files:**
- Create: `src/net_alpha/web/static/density.js`
- Modify: `src/net_alpha/web/templates/base.html` (script tag)
- Test: `tests/web/test_density_js_present.py` (create)

The persistent default lives in `user_preferences.density`. A button click (a) submits the form to write the new default *and* (b) writes a transient `density:{page}:{account}` key to `localStorage` so a refresh-with-override is honored before the round-trip completes.

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_density_js_present.py
from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.web.app import create_app


def test_density_js_loaded_in_base(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    app = create_app(settings)
    client = TestClient(app)
    html = client.get("/").text
    assert "/static/density.js" in html


def test_density_js_served(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    app = create_app(settings)
    client = TestClient(app)
    resp = client.get("/static/density.js")
    assert resp.status_code == 200
    assert "applyDensityFromLocalStorage" in resp.text
    assert "recordDensityOverride" in resp.text
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_density_js_present.py -v`
Expected: FAIL — `/static/density.js` returns 404

- [ ] **Step 3: Create the JS shim**

Create `src/net_alpha/web/static/density.js`:

```javascript
// Per-page density override stored in localStorage. The persistent
// default is in user_preferences.density (server-side); this lets the
// next page render reflect a click *before* the round-trip completes,
// and survives across reloads on the same page+account.
//
// Key shape: density:{page_key}:{account_id_or_all}
//   e.g., "density:/holdings:42"  or  "density:/tax:all"

(function () {
  function keyFor(page, account) {
    return "density:" + page + ":" + (account || "all");
  }

  window.recordDensityOverride = function (pageKey, density) {
    try {
      var account = (new URLSearchParams(window.location.search)).get("account") || "all";
      window.localStorage.setItem(keyFor(pageKey, account), density);
    } catch (_) { /* localStorage disabled — fall back to DB default */ }
  };

  window.applyDensityFromLocalStorage = function (rootEl) {
    try {
      var page = rootEl.getAttribute("data-page-key");
      if (!page) return;
      var account = (new URLSearchParams(window.location.search)).get("account") || "all";
      var stored = window.localStorage.getItem(keyFor(page, account));
      if (!stored) return;
      // Tag the body so CSS rules can adjust per-density without reload.
      document.body.setAttribute("data-density-override", stored);
    } catch (_) { /* noop */ }
  };
})();
```

- [ ] **Step 4: Add the script tag to base.html**

Edit `src/net_alpha/web/templates/base.html` — add a `<script>` tag in the `<head>` block alongside the others:

```html
  <script src="/static/density.js?v={{ asset_v }}" defer></script>
```

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_density_js_present.py -v`
Expected: PASS (2 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/static/density.js src/net_alpha/web/templates/base.html tests/web/test_density_js_present.py
git commit -m "feat(web): localStorage density override shim"
```

---

### Task 21: Inject density toggle into holdings, tax, imports

**Files:**
- Modify: `src/net_alpha/web/templates/holdings.html`
- Modify: `src/net_alpha/web/templates/tax.html`
- Modify: `src/net_alpha/web/templates/imports.html`
- Modify: `src/net_alpha/web/routes/holdings.py`, `tax.py`, `imports.py`
- Test: `tests/web/test_density_toggle_in_pages.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_density_toggle_in_pages.py
from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.web.app import create_app


def _bootstrap(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    repo.get_or_create_account("Schwab", "Tax")
    return TestClient(create_app(settings))


def test_holdings_renders_density_toggle(tmp_path):
    client = _bootstrap(tmp_path)
    html = client.get("/holdings").text
    assert 'class="density-toggle' in html
    assert 'data-page-key="/holdings"' in html


def test_tax_renders_density_toggle(tmp_path):
    client = _bootstrap(tmp_path)
    html = client.get("/tax").text
    assert 'class="density-toggle' in html
    assert 'data-page-key="/tax"' in html


def test_imports_renders_density_toggle(tmp_path):
    client = _bootstrap(tmp_path)
    html = client.get("/imports").text
    assert 'class="density-toggle' in html
    assert 'data-page-key="/imports"' in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_density_toggle_in_pages.py -v`
Expected: FAIL — toggle not rendered yet

- [ ] **Step 3: Push profile + page_key into context for each page**

For `holdings.py`, ensure `profile`, `page_key="/holdings"`, `account_id` (resolved from `selected_account`) are in the context. This was partially done in Task 18 — extend with `page_key` and `account_id`:

```python
    selected_account_id = filter_id  # already computed above
    return request.app.state.templates.TemplateResponse(
        request, "holdings.html",
        {
            ...,
            "profile": profile,
            "extra_columns": extra_columns,
            "page_key": "/holdings",
            "account_id": selected_account_id,
        },
    )
```

For `tax.py`, add a `_resolve_profile` helper near the top (mirroring portfolio.py's), call it inside the GET handler, and add to context:

```python
from net_alpha.prefs.profile import resolve_effective_profile
...
    prefs = repo.list_user_preferences()
    filter_id = None
    if account:
        for a in repo.list_accounts():
            if f"{a.broker}/{a.label}" == account:
                filter_id = a.id
                break
    profile = resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)
    context.update({"profile": profile, "page_key": "/tax", "account_id": filter_id, "selected_account": account or ""})
```

For `imports.py`, since there's no per-account filter on /imports, account_id stays None:

```python
from net_alpha.prefs.profile import resolve_effective_profile
...
    prefs = repo.list_user_preferences()
    profile = resolve_effective_profile(prefs=prefs, filter_account_id=None)
    context["profile"] = profile
    context["page_key"] = "/imports"
    context["account_id"] = None
    context["selected_account"] = ""
```

- [ ] **Step 4: Include the toggle in each page template**

In `src/net_alpha/web/templates/holdings.html`, immediately after `<h1>Holdings</h1>` (inside the existing left-column div):

```jinja
      {% include "_density_toggle.html" with context %}
```

In `src/net_alpha/web/templates/tax.html`, just before the `<nav class="tabs ...">`:

```jinja
  {% include "_density_toggle.html" with context %}
```

In `src/net_alpha/web/templates/imports.html`, immediately after the page heading element. (Open the file, find the `<h1>` — add the include directly below it.)

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_density_toggle_in_pages.py -v`
Expected: PASS (3 tests)

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/templates/holdings.html src/net_alpha/web/templates/tax.html src/net_alpha/web/templates/imports.html src/net_alpha/web/routes/holdings.py src/net_alpha/web/routes/tax.py src/net_alpha/web/routes/imports.py tests/web/test_density_toggle_in_pages.py
git commit -m "feat(web): density toggle on /holdings, /tax, /imports"
```

---

## Section G — Apply profile to /tax (Tasks 22-23)

Default tab on /tax follows profile (Conservative→wash-sales, Active/Options→harvest).

### Task 22: /tax default tab from profile

**Files:**
- Modify: `src/net_alpha/web/routes/tax.py`
- Test: `tests/web/test_tax_default_tab.py` (create)

When the user hits `/tax` with no `view=...` query param, the route should render the profile's default tab — not always `wash-sales`.

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_tax_default_tab.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def _seed(tmp_path, profile_label):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    repo.upsert_user_preference(
        AccountPreference(
            account_id=a.id,
            profile=profile_label,
            density="comfortable",
            updated_at=datetime(2026, 4, 27, tzinfo=timezone.utc),
        )
    )
    app = create_app(settings)
    return TestClient(app)


def test_tax_no_view_active_renders_harvest(tmp_path):
    client = _seed(tmp_path, "active")
    html = client.get("/tax", params={"account": "Schwab/Tax"}).text
    # the harvest tab is "active" in the nav
    assert 'class="tab tab--active"' in html
    assert 'href="/tax?view=harvest&amp;account=Schwab/Tax"' in html or 'view=harvest' in html
    # Inner panel renders the harvest queue marker, not the wash-sales table
    assert "Harvest queue" in html


def test_tax_no_view_conservative_renders_wash_sales(tmp_path):
    client = _seed(tmp_path, "conservative")
    html = client.get("/tax", params={"account": "Schwab/Tax"}).text
    assert "Wash sales" in html
    # The active tab is wash-sales, harvest is not preselected
    # (assert by URL query absence of view=harvest in active tab is brittle —
    # use a positive marker instead)
    assert 'data-active-tab="wash-sales"' in html


def test_tax_explicit_view_overrides_profile(tmp_path):
    client = _seed(tmp_path, "active")
    html = client.get("/tax", params={"view": "wash-sales"}).text
    assert 'data-active-tab="wash-sales"' in html
```

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_tax_default_tab.py -v`
Expected: FAIL — defaults always to wash-sales today

- [ ] **Step 3: Patch /tax handler to use profile.default_tax_tab() when view absent**

Edit `src/net_alpha/web/routes/tax.py`. Locate the handler signature — it accepts `view: Literal["wash-sales", "harvest", "budget", "projection"] | None`. Change the default to `None` if not already, then resolve profile and substitute when missing.

```python
@router.get("/tax")
def tax_index(
    request: Request,
    view: str | None = Query(default=None),
    account: str | None = None,
    repo: Repository = Depends(get_repository),
    pricing: PricingService = Depends(get_pricing_service),
):
    # ... existing setup ...

    prefs = repo.list_user_preferences()
    filter_id = None
    if account:
        for a in repo.list_accounts():
            if f"{a.broker}/{a.label}" == account:
                filter_id = a.id
                break
    profile = resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)

    if view not in ("wash-sales", "harvest", "budget", "projection"):
        view = profile.default_tax_tab()
    # ... rest of handler unchanged ...
```

Also pass `profile` and `selected_account` into the context (selected_account is needed by `_density_toggle.html`):

```python
    context.update({
        "view": view,
        "profile": profile,
        "selected_account": account or "",
        "account_id": filter_id,
        "page_key": "/tax",
    })
```

- [ ] **Step 4: Add a data-active-tab marker to tax.html**

Edit `src/net_alpha/web/templates/tax.html`. In the outer wrapper:

```jinja
<div class="tax-page" data-active-tab="{{ view }}">
```

(Replace `<div class="tax-page">`.)

- [ ] **Step 5: Run test to verify it passes**

Run: `uv run pytest tests/web/test_tax_default_tab.py -v`
Expected: PASS (3 tests)

- [ ] **Step 6: Run the existing tax route tests**

Run: `uv run pytest tests/web/test_tax_route.py tests/web/test_tax_redirects.py -v`
Expected: all PASS (the wash-sales redirect still passes view through verbatim, so the change is additive).

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/tax.py src/net_alpha/web/templates/tax.html tests/web/test_tax_default_tab.py
git commit -m "feat(web): /tax default tab from ProfileSettings.default_tax_tab"
```

---

### Task 23: Switcher reflects per-account profile in topbar across pages

This is already implicit from Task 11 (the switcher reads `account_profiles` and the `profile` for label). Add an explicit regression test ensuring the topbar shows the per-account profile when `?account=X` is in the URL of a non-portfolio page.

**Files:**
- Test: `tests/web/test_topbar_per_account_label.py` (create)

- [ ] **Step 1: Write the failing test**

```python
# tests/web/test_topbar_per_account_label.py
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def test_topbar_label_reflects_filter_account(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)
    a = repo.get_or_create_account("Schwab", "Tax")
    b = repo.get_or_create_account("Schwab", "Roth")
    now = datetime(2026, 4, 27, tzinfo=timezone.utc)
    repo.upsert_user_preference(
        AccountPreference(account_id=a.id, profile="conservative", density="comfortable", updated_at=now)
    )
    repo.upsert_user_preference(
        AccountPreference(account_id=b.id, profile="options", density="comfortable", updated_at=now)
    )
    client = TestClient(create_app(settings))

    # All accounts: profiles disagree -> "active" fallback
    all_html = client.get("/holdings").text
    assert ">active<" in all_html.lower()

    # Filter to Roth -> "options" label
    roth_html = client.get("/holdings", params={"account": "Schwab/Roth"}).text
    assert ">options<" in roth_html.lower()
```

This test depends on the switcher's globals reading the *current request's* account filter. Currently, `_profile_switcher_data` is called as a Jinja global *without* request context, so it always renders the "all accounts" merge. Phase 3 needs that global to be request-aware.

- [ ] **Step 2: Run test to verify it fails**

Run: `uv run pytest tests/web/test_topbar_per_account_label.py -v`
Expected: FAIL — Roth case still shows "active"

- [ ] **Step 3: Make the switcher globals request-aware**

Edit `src/net_alpha/web/app.py`. Replace the existing `_profile_switcher_data` no-arg function with a Jinja `pass_context` callable that reads the current request from the context.

Add the import at the top of `app.py`:

```python
from jinja2 import pass_context
```

Replace the existing `_profile_switcher_data` definition with:

```python
    @pass_context
    def _profile_switcher_data(ctx) -> dict[str, object]:
        from net_alpha.db.repository import Repository as _Repository
        from net_alpha.prefs.profile import (
            DEFAULT_PROFILE_SETTINGS,
            resolve_effective_profile,
        )

        request = ctx.get("request")
        account = None
        if request is not None:
            account = request.query_params.get("account")

        _engine = get_engine(settings.db_path)
        _repo = _Repository(_engine)
        accounts = _repo.list_accounts()
        prefs = _repo.list_user_preferences()
        filter_id: int | None = None
        if account:
            for a in accounts:
                if f"{a.broker}/{a.label}" == account:
                    filter_id = a.id
                    break
        prof_by_id = {p.account_id: p.profile for p in prefs}
        profile = resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)
        return {
            "accounts": accounts,
            "account_profiles": prof_by_id,
            "profile": profile if accounts else DEFAULT_PROFILE_SETTINGS,
            "show_switcher": bool(accounts),
        }
```

`pass_context` makes Jinja invoke the function with the rendering context (`ctx`), which carries the FastAPI `Request`. The base template's existing `{% set _ps = profile_switcher_data() %}` continues to work.

- [ ] **Step 4: Run test to verify it passes**

Run: `uv run pytest tests/web/test_topbar_per_account_label.py -v`
Expected: PASS (1 test)

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/app.py tests/web/test_topbar_per_account_label.py
git commit -m "feat(web): switcher label reflects current request's account filter"
```

---

## Section H — Smoke test (Task 24)

End-to-end: insert prefs for two accounts, hit every page, assert the switcher and density work.

### Task 24: Phase 3 smoke

**Files:**
- Test: `tests/web/test_phase3_smoke.py` (create)

- [ ] **Step 1: Write the smoke test**

```python
# tests/web/test_phase3_smoke.py
"""Phase 3 end-to-end smoke — profiles, switcher, density toggle.

Bootstraps the app with two accounts and matching preferences. Hits every
page and asserts the switcher label, default-tab routing, density toggle,
and KPI ordering all reflect the per-account profile.
"""
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.preferences import AccountPreference
from net_alpha.web.app import create_app


def test_phase3_smoke(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    repo = Repository(engine)

    tax_acct = repo.get_or_create_account("Schwab", "Tax")
    roth_acct = repo.get_or_create_account("Schwab", "Roth")
    now = datetime(2026, 4, 27, tzinfo=timezone.utc)
    repo.upsert_user_preference(
        AccountPreference(account_id=tax_acct.id, profile="active", density="comfortable", updated_at=now)
    )
    repo.upsert_user_preference(
        AccountPreference(account_id=roth_acct.id, profile="options", density="tax", updated_at=now)
    )

    client = TestClient(create_app(settings))

    # 1. The first-visit modal is gone (prefs exist).
    assert "Pick a default profile per account" not in client.get("/").text

    # 2. /tax with active filter -> default tab harvest.
    tax_resp = client.get("/tax", params={"account": "Schwab/Tax"}).text
    assert 'data-active-tab="harvest"' in tax_resp

    # 3. /tax with conservative would default to wash-sales — but we don't have
    #    a conservative account, so flip Roth temporarily.
    repo.upsert_user_preference(
        AccountPreference(account_id=roth_acct.id, profile="conservative", density="comfortable", updated_at=now)
    )
    cons_tax = client.get("/tax", params={"account": "Schwab/Roth"}).text
    assert 'data-active-tab="wash-sales"' in cons_tax
    # Restore Roth -> options for the rest of the test.
    repo.upsert_user_preference(
        AccountPreference(account_id=roth_acct.id, profile="options", density="tax", updated_at=now)
    )

    # 4. /holdings with options + tax density -> tax-density columns visible.
    holdings_roth = client.get("/holdings", params={"account": "Schwab/Roth"}).text
    assert 'data-col="lt_st_split"' in holdings_roth
    assert 'data-col="days_to_ltcg"' in holdings_roth  # tax density adds this
    assert 'data-page-key="/holdings"' in holdings_roth

    # 5. /holdings with active + comfortable -> days_held + lt_st_split, no tax-only cols.
    holdings_tax = client.get("/holdings", params={"account": "Schwab/Tax"}).text
    assert 'data-col="days_held"' in holdings_tax
    assert 'data-col="days_to_ltcg"' not in holdings_tax

    # 6. KPI hero ordering matches Active for the Tax account.
    kpis = client.get("/portfolio/kpis", params={"account": "Schwab/Tax"}).text
    import re
    order = re.findall(r'data-kpi-slot="([^"]+)"', kpis)
    assert order[:4] == ["ytd_realized", "ytd_unrealized", "wash_impact", "open_position"]

    # 7. Topbar switcher form posts to /preferences with account_id.
    home = client.get("/").text
    assert 'action="/preferences"' in home
    # 8. POST /preferences flips Tax to conservative; verify persistence.
    resp = client.post(
        "/preferences",
        data={"account_id": str(tax_acct.id), "profile": "conservative", "density": "comfortable"},
    )
    assert resp.status_code == 204
    assert resp.headers.get("hx-refresh") == "true"
    # Re-render /portfolio/kpis for Tax -> conservative ordering.
    kpis2 = client.get("/portfolio/kpis", params={"account": "Schwab/Tax"}).text
    order2 = re.findall(r'data-kpi-slot="([^"]+)"', kpis2)
    assert order2[:3] == ["open_position", "lifetime_growth", "cash"]
```

- [ ] **Step 2: Run the smoke**

Run: `uv run pytest tests/web/test_phase3_smoke.py -v`
Expected: PASS (1 test)

- [ ] **Step 3: Run the entire suite for regressions**

Run: `uv run pytest -q`
Expected: all PASS, no new failures vs. master baseline. The test count should grow by Phase 3's added tests; existing 672+ should still pass.

- [ ] **Step 4: Run lint**

Run: `uv run ruff check . && uv run ruff format --check .`
Expected: clean. If ruff finds anything, run `uv run ruff check --fix .` and `uv run ruff format .`, commit fix as `style: ruff format`, re-run.

- [ ] **Step 5: Commit smoke**

```bash
git add tests/web/test_phase3_smoke.py
git commit -m "test(phase3): end-to-end smoke — profiles, switcher, density, default tab"
```

---

## Self-Review

**Spec coverage:**
- Section 3a (per-account profile picker + first-visit modal + toolbar switcher + POST /preferences) → Tasks 9, 10, 11, 12 ✓
- Section 3b (profile-driven defaults, visibility/ordering rule table) → Tasks 4, 5, 6 (rule table); 13–18, 22 (apply) ✓
- Section 3c (per-page density toggle, DB default + localStorage override) → Tasks 19, 20, 21 ✓
- Section 3d (smart suggestion) → explicitly **deferred per spec** — no task. ✓
- Migration v8 → v9 → Tasks 1, 2, 3 ✓
- Smoke → Task 24 ✓

**Gaps acknowledged in plan:**
- `lockout_calendar` rule is wired into `ProfileSettings.shows("lockout_calendar")` but no surface exists today (lockout was shipped in Phase 2 only as a per-row "clear date"; a calendar visualization is a Phase 4+ deliverable). The rule in code lives in one place (`_VISIBILITY` table) so adding the surface later means: render template gated on `profile.shows("lockout_calendar")` — no rule edit needed.
- `origin_event`, `days_to_ltcg`, `harvestable`, `premium_offset` columns render as `—` placeholders in Task 18. Wiring real compute requires Phase 1 provenance helpers + Phase 2 tax_planner already shipped — extracting those into per-position values is its own task family. Stubbed visibly so the column structure matches the spec while the underlying compute lands in a follow-up. The cells use `—` so the missing data is honest, not fabricated.

**Placeholder scan:** No "TBD"/"TODO"/"implement later" remains. Each step has either runnable code or an exact command. Stubs in Task 18's template render `—` and are explicitly documented as placeholders.

**Type consistency:**
- `Profile` Literal (`'conservative' | 'active' | 'options'`) defined in `models/preferences.py`, imported by `prefs/profile.py` and routes — single source.
- `Density` Literal same pattern.
- `AccountPreference` (model) and `UserPreferenceRow` (table) — names diverge by layer convention, identical fields.
- `ProfileSettings.shows / order / default_columns / default_tax_tab` — all four methods used consistently across templates and tasks.
- `resolve_effective_profile(prefs=..., filter_account_id=...)` — same signature in dep, switcher global, and route helpers.

**Section-boundary review cadence:** Per `feedback_subagent_review_cadence`, mechanical-task reviewer dispatches are skipped. Reviews fire at section boundaries (A, B, C, D, E, F, G, H), matching the Phase 2 cadence.

---

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-04-27-style-aware-density.md`. Two execution options:

**1. Subagent-Driven (recommended)** — I dispatch a fresh subagent per task, review at section boundaries (A through H), fast iteration.

**2. Inline Execution** — Execute tasks in this session using superpowers:executing-plans, batch execution with checkpoints.

Which approach?
