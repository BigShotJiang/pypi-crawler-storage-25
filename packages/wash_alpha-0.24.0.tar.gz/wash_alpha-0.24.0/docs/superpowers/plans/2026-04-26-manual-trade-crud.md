# Manual trade CRUD on the Timeline — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let users (a) edit `date` and `cost_basis` (or `proceeds`) on imported transfer rows, (b) add manually-entered trades for symbols not in any import, (c) edit and delete the manual trades they've added — all from the per-symbol Timeline at `/ticker/{symbol}`. Display "Transfer In" / "Transfer Out" labels on transfers instead of collapsing them to "Buy" / "Sell".

**Architecture:** Schema gains two columns on `trades` (`is_manual`, `transfer_basis_user_set`); `import_id` becomes nullable. Repository gains four write methods (`create_manual_trade`, `update_imported_transfer`, `update_manual_trade`, `delete_manual_trade`), each preserving `natural_key` so re-imports of the same CSV don't disturb edits. After every successful write, the existing `recompute_all_violations(repo, etf_pairs)` runs to keep wash-sale state coherent. UI surface is on the ticker page: an "Add trade" button + per-row affordance/badge columns + four POST routes that swap the Timeline panel.

**Tech Stack:** Python 3.11, Pydantic v2, SQLModel/SQLite, FastAPI, Jinja2, HTMX, Alpine.js (no new deps).

**Spec:** `docs/superpowers/specs/2026-04-26-manual-trade-crud-design.md`

---

## File Structure

| File                                                             | Role                                                                                       |
| ---------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `src/net_alpha/models/domain.py` (modify)                        | `Trade.is_manual` and `Trade.transfer_basis_user_set` fields.                              |
| `src/net_alpha/db/tables.py` (modify)                            | Same two fields on `TradeRow`. `import_id` nullable.                                       |
| `src/net_alpha/db/migrations.py` (modify)                        | New `_migrate_v5_to_v6` adds columns + rebuilds `trades` for nullable FK.                  |
| `src/net_alpha/db/repository.py` (modify)                        | `create_manual_trade`, `update_imported_transfer`, `update_manual_trade`, `delete_manual_trade`; plumb new fields through `_row_to_trade`. |
| `src/net_alpha/web/routes/trades.py` (create)                    | The four POST routes.                                                                      |
| `src/net_alpha/web/routes/ticker.py` (modify)                    | Pass `display_action` helper + provenance flags into `ticker.html`.                        |
| `src/net_alpha/web/app.py` (modify)                              | Register the trades router.                                                                |
| `src/net_alpha/web/templates/ticker.html` (modify)               | "Add trade" button; new affordance + badge columns; `display_action` rendering.            |
| `src/net_alpha/web/templates/_trade_form.html` (create)          | Shared form fragment for add + edit-manual.                                                |
| `src/net_alpha/web/templates/_trade_transfer_form.html` (create) | Two-field form for edit-transfer.                                                          |
| `src/net_alpha/web/templates/_trade_delete_confirm.html` (create)| Confirm dialog for delete.                                                                 |
| `src/net_alpha/web/format.py` (modify or create)                 | `display_action(t: Trade) -> str` pure helper.                                             |
| `tests/db/test_v5_to_v6_migration.py` (create)                   | Schema migration round-trip.                                                                |
| `tests/db/test_repository_manual_trades.py` (create)             | Each new write method, including `natural_key` immutability on edit.                        |
| `tests/web/test_trades_routes.py` (create)                       | Route-level happy paths and authorization rules.                                            |
| `tests/web/test_ticker_display_action.py` (create)               | Timeline shows "Transfer In" / "Transfer Out" labels.                                        |
| `tests/integration/test_reimport_preserves_edits.py` (create)    | Import → edit transfer-in row → re-import same CSV → edit survives, no duplicate.           |

---

## Task 1: Schema migration v5 → v6

Adds two columns and relaxes `import_id` `NOT NULL` on `trades`. Standard SQLite rebuild dance for column relaxation.

**Files:**
- Modify: `src/net_alpha/db/migrations.py`
- Test: `tests/db/test_v5_to_v6_migration.py` (create)

- [ ] **Step 1: Write the failing test**

Create `tests/db/test_v5_to_v6_migration.py`:

```python
from __future__ import annotations

from sqlalchemy import text
from sqlmodel import Session

from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.migrations import (
    CURRENT_SCHEMA_VERSION,
    _column_exists,
    get_schema_version,
    migrate,
    set_schema_version,
)


def _force_v5(session: Session) -> None:
    """Pretend the DB is v5: drop the new v6 columns if present, set version."""
    set_schema_version(session, 5)


def test_v5_to_v6_adds_new_columns(tmp_path):
    db_path = tmp_path / "db.sqlite"
    engine = get_engine(db_path)
    init_db(engine)  # creates v6 tables (since CURRENT == 6 after this change)
    # Simulate a pre-v6 DB: rebuild trades without the new columns + drop version
    with Session(engine) as s:
        s.exec(text("ALTER TABLE trades DROP COLUMN is_manual"))
        s.exec(text("ALTER TABLE trades DROP COLUMN transfer_basis_user_set"))
        _force_v5(s)
        s.commit()
    with Session(engine) as s:
        assert get_schema_version(s) == 5
        migrate(s)
        assert get_schema_version(s) == CURRENT_SCHEMA_VERSION
        assert _column_exists(s, "trades", "is_manual")
        assert _column_exists(s, "trades", "transfer_basis_user_set")


def test_v5_to_v6_relaxes_import_id_not_null(tmp_path):
    """After migration, inserting a trade with import_id=NULL must succeed."""
    db_path = tmp_path / "db.sqlite"
    engine = get_engine(db_path)
    init_db(engine)
    with Session(engine) as s:
        s.exec(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        s.commit()
    with Session(engine) as s:
        s.exec(
            text(
                "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, "
                "action, quantity, basis_source, is_manual, transfer_basis_user_set) "
                "VALUES (NULL, 1, 'manual:abc', 'AAPL', '2026-01-15', 'Buy', 10, 'user', 1, 0)"
            )
        )
        s.commit()
        row = s.exec(text("SELECT id, import_id, is_manual FROM trades WHERE natural_key='manual:abc'")).first()
        assert row is not None
        assert row[1] is None
        assert row[2] == 1
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/db/test_v5_to_v6_migration.py -v`

Expected: FAIL — `CURRENT_SCHEMA_VERSION` is 5 today, columns don't exist.

- [ ] **Step 3: Add the migration function**

Edit `src/net_alpha/db/migrations.py`. Bump the version constant:

```python
CURRENT_SCHEMA_VERSION = 6
```

Update the docstring:

```python
"""Hand-written migrations.

Schema versions:
  v1 — Initial v2.x schema (TradeRow, LotRow, WashSaleViolationRow, etc.)
  v2 — Adds RealizedGLLotRow table; adds Trade.basis_source, WashSaleViolation.source columns.
  v3 — Adds PriceCacheRow table for the pricing subsystem.
  v4 — Adds aggregate columns to imports (date range, type counts, parse warnings).
  v5 — Adds imports.duplicate_trades count so re-imports show "X dupes" instead of "no records".
  v6 — Adds trades.is_manual and trades.transfer_basis_user_set; relaxes trades.import_id NOT NULL.
"""
```

Append the migration function before the `migrate` function:

```python
def _migrate_v5_to_v6(session: Session) -> None:
    if not _table_exists(session, "trades"):
        return
    if not _column_exists(session, "trades", "is_manual"):
        session.exec(text("ALTER TABLE trades ADD COLUMN is_manual INTEGER NOT NULL DEFAULT 0"))
    if not _column_exists(session, "trades", "transfer_basis_user_set"):
        session.exec(text("ALTER TABLE trades ADD COLUMN transfer_basis_user_set INTEGER NOT NULL DEFAULT 0"))
    # Relax import_id NOT NULL via SQLite rebuild dance.
    info = session.exec(text("PRAGMA table_info(trades)")).all()
    import_id_notnull = next((r for r in info if r[1] == "import_id"), None)
    if import_id_notnull and import_id_notnull[3] == 1:  # notnull flag is column 3
        session.exec(text("PRAGMA foreign_keys=OFF"))
        session.exec(text("""
            CREATE TABLE trades_new (
              id INTEGER PRIMARY KEY,
              import_id INTEGER NULL REFERENCES imports(id),
              account_id INTEGER NOT NULL REFERENCES accounts(id),
              natural_key TEXT NOT NULL,
              ticker TEXT NOT NULL,
              trade_date TEXT NOT NULL,
              action TEXT NOT NULL,
              quantity FLOAT NOT NULL,
              proceeds FLOAT,
              cost_basis FLOAT,
              basis_unknown INTEGER NOT NULL DEFAULT 0,
              option_strike FLOAT,
              option_expiry TEXT,
              option_call_put TEXT,
              basis_source TEXT NOT NULL DEFAULT 'unknown',
              is_manual INTEGER NOT NULL DEFAULT 0,
              transfer_basis_user_set INTEGER NOT NULL DEFAULT 0,
              CONSTRAINT uq_trade_account_natkey UNIQUE (account_id, natural_key)
            )
        """))
        session.exec(text("""
            INSERT INTO trades_new
            SELECT id, import_id, account_id, natural_key, ticker, trade_date, action,
                   quantity, proceeds, cost_basis, basis_unknown,
                   option_strike, option_expiry, option_call_put,
                   basis_source, is_manual, transfer_basis_user_set
            FROM trades
        """))
        session.exec(text("DROP TABLE trades"))
        session.exec(text("ALTER TABLE trades_new RENAME TO trades"))
        session.exec(text("CREATE INDEX ix_trades_account_id ON trades(account_id)"))
        session.exec(text("CREATE INDEX ix_trades_import_id ON trades(import_id)"))
        session.exec(text("CREATE INDEX ix_trades_natural_key ON trades(natural_key)"))
        session.exec(text("CREATE INDEX ix_trades_ticker ON trades(ticker)"))
        session.exec(text("CREATE INDEX ix_trades_trade_date ON trades(trade_date)"))
        session.exec(text("PRAGMA foreign_keys=ON"))
    session.commit()
```

Wire it into the `migrate` orchestrator. Find the block:

```python
    if current < 5:
        _migrate_v4_to_v5(session)
        set_schema_version(session, 5)
```

Add immediately after:

```python
    if current < 6:
        _migrate_v5_to_v6(session)
        set_schema_version(session, 6)
```

- [ ] **Step 4: Run the migration tests to verify they pass**

Run: `uv run pytest tests/db/test_v5_to_v6_migration.py -v`

Expected: PASS.

- [ ] **Step 5: Run the full migration suite to confirm no regression**

Run: `uv run pytest tests/db/test_migration_v1_v2.py tests/db/test_migration_v2_v3.py tests/db/test_v3_to_v4_migration.py tests/db/test_v5_to_v6_migration.py -v`

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/migrations.py tests/db/test_v5_to_v6_migration.py
git commit -m "feat(db): v5→v6 — add trades.is_manual + transfer_basis_user_set; nullable import_id"
```

---

## Task 2: Add `is_manual` + `transfer_basis_user_set` to models

Pydantic and SQLModel definitions, plus propagation through `_row_to_trade` so reads carry the fields.

**Files:**
- Modify: `src/net_alpha/models/domain.py:18-34` (Trade fields)
- Modify: `src/net_alpha/db/tables.py:43-65` (TradeRow fields, nullable import_id)
- Modify: `src/net_alpha/db/repository.py:138-200` (insert path, `_row_to_trade`)
- Test: `tests/db/test_repository_reads.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/db/test_repository_reads.py`:

```python
def test_all_trades_includes_is_manual_and_transfer_flag(tmp_path):
    """Reads should propagate the new flags."""
    from net_alpha.config import Settings
    from net_alpha.db.connection import get_engine, init_db
    from net_alpha.db.repository import Repository
    from sqlalchemy import text

    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, basis_source, is_manual, transfer_basis_user_set) "
            "VALUES (NULL, 1, 'manual:1', 'AAPL', '2026-01-15', 'Buy', 10, 'user', 1, 0)"
        ))
    repo = Repository(engine)
    trades = repo.all_trades()
    assert len(trades) == 1
    t = trades[0]
    assert t.is_manual is True
    assert t.transfer_basis_user_set is False
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/db/test_repository_reads.py::test_all_trades_includes_is_manual_and_transfer_flag -v`

Expected: FAIL — `Trade` has no `is_manual` field.

- [ ] **Step 3: Add fields to the Pydantic Trade model**

Edit `src/net_alpha/models/domain.py`. Find the `Trade` class (around line 18). Add two fields after `basis_source`:

```python
    is_manual: bool = False
    transfer_basis_user_set: bool = False
```

- [ ] **Step 4: Add fields to TradeRow + relax import_id**

Edit `src/net_alpha/db/tables.py`. Change line 48:

```python
    import_id: int = Field(foreign_key="imports.id", index=True)
```

to:

```python
    import_id: int | None = Field(default=None, foreign_key="imports.id", index=True)
```

Add two fields after `basis_source` (around line 64):

```python
    is_manual: bool = Field(default=False)
    transfer_basis_user_set: bool = Field(default=False)
```

- [ ] **Step 5: Propagate fields through `_row_to_trade`**

Edit `src/net_alpha/db/repository.py`, the `_row_to_trade` method (around lines 180-200). Replace the `return Trade(...)` block with:

```python
        return Trade(
            id=str(row.id),
            account=account_display,
            date=date.fromisoformat(row.trade_date),
            ticker=row.ticker,
            action=row.action,
            quantity=row.quantity,
            proceeds=row.proceeds,
            cost_basis=row.cost_basis,
            basis_unknown=row.basis_unknown,
            basis_source=row.basis_source,
            is_manual=row.is_manual,
            transfer_basis_user_set=row.transfer_basis_user_set,
            option_details=opt,
        )
```

- [ ] **Step 6: Run the test to verify it passes**

Run: `uv run pytest tests/db/test_repository_reads.py::test_all_trades_includes_is_manual_and_transfer_flag -v`

Expected: PASS.

- [ ] **Step 7: Run the full DB suite**

Run: `uv run pytest tests/db/ -v`

Expected: all PASS.

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/models/domain.py src/net_alpha/db/tables.py src/net_alpha/db/repository.py tests/db/test_repository_reads.py
git commit -m "feat(models): Trade.is_manual + Trade.transfer_basis_user_set"
```

---

## Task 3: Repository.create_manual_trade

Inserts a manual trade with `import_id=None`, `is_manual=True`, and a `manual:<uuid>` natural_key. Calls `recompute_all_violations` after.

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_manual_trades.py` (create)

- [ ] **Step 1: Write the failing test**

Create `tests/db/test_repository_manual_trades.py`:

```python
from __future__ import annotations

from datetime import date

from sqlalchemy import text

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine, init_db
from net_alpha.db.repository import Repository
from net_alpha.models.domain import Trade


def _setup(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    init_db(engine)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
    return Repository(engine)


def test_create_manual_trade_persists_and_marks_is_manual(tmp_path):
    repo = _setup(tmp_path)
    t = Trade(
        account="Schwab/Tax",
        date=date(2026, 1, 15),
        ticker="AAPL",
        action="Buy",
        quantity=10,
        cost_basis=1500.0,
        basis_source="user",
        is_manual=True,
    )
    saved = repo.create_manual_trade(t, etf_pairs={})
    assert saved.id is not None
    assert saved.is_manual is True
    assert saved.basis_source == "user"
    # natural_key is the manual: namespace.
    trades = repo.all_trades()
    assert len(trades) == 1
    # Round-trip read carries the flag.
    assert trades[0].is_manual is True


def test_create_manual_trade_uses_manual_namespace_natural_key(tmp_path):
    repo = _setup(tmp_path)
    t = Trade(
        account="Schwab/Tax",
        date=date(2026, 1, 15),
        ticker="AAPL",
        action="Buy",
        quantity=10,
        cost_basis=1500.0,
        basis_source="user",
        is_manual=True,
    )
    repo.create_manual_trade(t, etf_pairs={})
    # Inspect natural_key column directly.
    with repo.engine.begin() as conn:
        row = conn.execute(text("SELECT natural_key FROM trades")).first()
    assert row[0].startswith("manual:")
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/db/test_repository_manual_trades.py -v`

Expected: FAIL — `create_manual_trade` does not exist.

- [ ] **Step 3: Add `create_manual_trade` to Repository**

Edit `src/net_alpha/db/repository.py`. Add imports near the top (alongside existing imports):

```python
from uuid import uuid4

from net_alpha.engine.recompute import recompute_all_violations
```

Add a new method to the `Repository` class. Place it after `update_trade_basis` (around line 647):

```python
    def create_manual_trade(self, trade: Trade, etf_pairs: dict[str, list[str]]) -> Trade:
        """Insert a user-entered trade. import_id is NULL; natural_key uses the
        'manual:' namespace so it never collides with a CSV-derived key.

        Triggers a full wash-sale recompute after insertion. Returns the
        persisted Trade with its database id populated.
        """
        with Session(self.engine) as s:
            account = self._resolve_account(s, trade.account)
            nk = f"manual:{uuid4().hex}"
            tr = TradeRow(
                import_id=None,
                account_id=account.id,
                natural_key=nk,
                ticker=trade.ticker,
                trade_date=trade.date.isoformat(),
                action=trade.action,
                quantity=trade.quantity,
                proceeds=trade.proceeds,
                cost_basis=trade.cost_basis,
                basis_unknown=trade.basis_unknown,
                basis_source=trade.basis_source,
                option_strike=(trade.option_details.strike if trade.option_details else None),
                option_expiry=(trade.option_details.expiry.isoformat() if trade.option_details else None),
                option_call_put=(trade.option_details.call_put if trade.option_details else None),
                is_manual=True,
                transfer_basis_user_set=False,
            )
            s.add(tr)
            s.commit()
            s.refresh(tr)
            saved = self._row_to_trade(tr, self._account_display_for_id(s, tr.account_id))
        recompute_all_violations(self, etf_pairs)
        return saved
```

If `_resolve_account` doesn't exist, look for whatever helper the existing `add_import` flow uses (around line 120-140) and reuse the pattern. If there's an inline `Account.from_display(...)` lookup, copy that approach instead. The intent is: split `"Schwab/Tax"` → `(broker, label)` and find or create the account row.

If no helper exists, add this private method to `Repository`:

```python
    def _resolve_account(self, s: Session, display: str) -> "AccountRow":
        if "/" in display:
            broker, label = display.split("/", 1)
        else:
            broker, label = "Manual", display
        row = s.exec(
            select(AccountRow).where(AccountRow.broker == broker, AccountRow.label == label)
        ).first()
        if row is None:
            raise LookupError(f"Account {display!r} not found — create it via /imports first")
        return row
```

(`AccountRow` is already imported in `repository.py`.)

- [ ] **Step 4: Run the test to verify it passes**

Run: `uv run pytest tests/db/test_repository_manual_trades.py -v`

Expected: PASS (both tests).

- [ ] **Step 5: Run the full DB + engine suites**

Run: `uv run pytest tests/db/ tests/engine/ -v`

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_manual_trades.py
git commit -m "feat(db): Repository.create_manual_trade + manual: natural_key namespace"
```

---

## Task 4: Repository.update_imported_transfer

Edits `date` (and `cost_basis` for transfer-in / `proceeds` for transfer-out) on imported transfer rows. Verifies row is `is_manual=False` AND `basis_source ∈ {"transfer_in","transfer_out"}`. Sets `transfer_basis_user_set=True`. Preserves `natural_key`.

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_manual_trades.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/db/test_repository_manual_trades.py`:

```python
def test_update_imported_transfer_in_keeps_natural_key(tmp_path):
    """Editing a transfer_in row updates date+basis but never natural_key."""
    repo = _setup(tmp_path)
    # Insert a transfer-in row directly (bypass parser).
    with repo.engine.begin() as conn:
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual, transfer_basis_user_set) "
            "VALUES (1, 1, 'csv:nk1', 'AAPL', '2026-02-01', 'Buy', 10, NULL, 'transfer_in', 0, 0)"
        ))
        row = conn.execute(text("SELECT id FROM trades")).first()
        trade_id = str(row[0])

    repo.update_imported_transfer(
        trade_id=trade_id,
        new_date=date(2024, 6, 15),
        new_basis_or_proceeds=2500.0,
        etf_pairs={},
    )

    with repo.engine.begin() as conn:
        row = conn.execute(text(
            "SELECT trade_date, cost_basis, natural_key, transfer_basis_user_set FROM trades"
        )).first()
    assert row[0] == "2024-06-15"
    assert abs(row[1] - 2500.0) < 1e-9
    assert row[2] == "csv:nk1"  # preserved
    assert row[3] == 1


def test_update_imported_transfer_rejects_non_transfer_row(tmp_path):
    repo = _setup(tmp_path)
    with repo.engine.begin() as conn:
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:nk2', 'AAPL', '2024-06-15', 'Buy', 10, 1000, 'broker_csv', 0)"
        ))
        trade_id = str(conn.execute(text("SELECT id FROM trades")).first()[0])

    import pytest

    with pytest.raises(ValueError):
        repo.update_imported_transfer(
            trade_id=trade_id,
            new_date=date(2024, 6, 15),
            new_basis_or_proceeds=2500.0,
            etf_pairs={},
        )
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/db/test_repository_manual_trades.py::test_update_imported_transfer_in_keeps_natural_key tests/db/test_repository_manual_trades.py::test_update_imported_transfer_rejects_non_transfer_row -v`

Expected: FAIL — method does not exist.

- [ ] **Step 3: Add the method**

Edit `src/net_alpha/db/repository.py`. Add after `create_manual_trade`:

```python
    def update_imported_transfer(
        self,
        trade_id: str,
        new_date: date,
        new_basis_or_proceeds: float,
        etf_pairs: dict[str, list[str]],
    ) -> Trade:
        """Update date + basis (or proceeds) on an imported transfer row.

        Raises ValueError if the row is is_manual=True or basis_source is not
        in {'transfer_in','transfer_out'}.

        Preserves natural_key explicitly so a future re-import of the original
        CSV dedupes against the user's edit.

        Triggers a full wash-sale recompute. Returns the updated Trade.
        """
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            if row.is_manual:
                raise ValueError("Use update_manual_trade for manual rows")
            if row.basis_source not in ("transfer_in", "transfer_out"):
                raise ValueError(
                    f"update_imported_transfer requires a transfer row; basis_source={row.basis_source!r}"
                )
            row.trade_date = new_date.isoformat()
            if row.basis_source == "transfer_in":
                row.cost_basis = new_basis_or_proceeds
            else:  # transfer_out
                row.proceeds = new_basis_or_proceeds
            row.transfer_basis_user_set = True
            # natural_key intentionally untouched.
            s.add(row)
            s.commit()
            s.refresh(row)
            saved = self._row_to_trade(row, self._account_display_for_id(s, row.account_id))
        recompute_all_violations(self, etf_pairs)
        return saved
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/db/test_repository_manual_trades.py -v`

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_manual_trades.py
git commit -m "feat(db): Repository.update_imported_transfer (date + basis|proceeds, immutable natural_key)"
```

---

## Task 5: Repository.update_manual_trade

Full edit on rows where `is_manual=True`. Updates all editable fields (date, action, quantity, cost_basis, proceeds, basis_source, account, option fields) but never `natural_key` and never `is_manual`.

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_manual_trades.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/db/test_repository_manual_trades.py`:

```python
def test_update_manual_trade_full_edit(tmp_path):
    repo = _setup(tmp_path)
    t = Trade(
        account="Schwab/Tax",
        date=date(2026, 1, 15),
        ticker="AAPL",
        action="Buy",
        quantity=10,
        cost_basis=1500.0,
        basis_source="user",
        is_manual=True,
    )
    saved = repo.create_manual_trade(t, etf_pairs={})

    updated = Trade(
        id=saved.id,
        account="Schwab/Tax",
        date=date(2025, 12, 20),
        ticker="AAPL",
        action="Buy",
        quantity=12,
        cost_basis=1900.0,
        basis_source="user",
        is_manual=True,
    )
    repo.update_manual_trade(updated, etf_pairs={})

    refetched = repo.all_trades()[0]
    assert refetched.date == date(2025, 12, 20)
    assert refetched.quantity == 12
    assert abs(refetched.cost_basis - 1900.0) < 1e-9


def test_update_manual_trade_rejects_imported_row(tmp_path):
    repo = _setup(tmp_path)
    with repo.engine.begin() as conn:
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:x', 'AAPL', '2024-06-15', 'Buy', 10, 1000, 'broker_csv', 0)"
        ))
        trade_id = str(conn.execute(text("SELECT id FROM trades")).first()[0])

    t = Trade(
        id=trade_id,
        account="Schwab/Tax",
        date=date(2024, 1, 1),
        ticker="AAPL",
        action="Buy",
        quantity=10,
        cost_basis=999.0,
        basis_source="user",
        is_manual=True,
    )
    import pytest
    with pytest.raises(ValueError):
        repo.update_manual_trade(t, etf_pairs={})
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/db/test_repository_manual_trades.py::test_update_manual_trade_full_edit tests/db/test_repository_manual_trades.py::test_update_manual_trade_rejects_imported_row -v`

Expected: FAIL — method does not exist.

- [ ] **Step 3: Add the method**

Edit `src/net_alpha/db/repository.py`. Add after `update_imported_transfer`:

```python
    def update_manual_trade(self, trade: Trade, etf_pairs: dict[str, list[str]]) -> Trade:
        """Update a manual trade. Verifies is_manual=True. Preserves natural_key."""
        if trade.id is None:
            raise ValueError("update_manual_trade requires Trade.id")
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade.id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade.id} not found")
            if not row.is_manual:
                raise ValueError("update_manual_trade requires is_manual=True row")
            account = self._resolve_account(s, trade.account)
            row.account_id = account.id
            row.ticker = trade.ticker
            row.trade_date = trade.date.isoformat()
            row.action = trade.action
            row.quantity = trade.quantity
            row.proceeds = trade.proceeds
            row.cost_basis = trade.cost_basis
            row.basis_unknown = trade.basis_unknown
            row.basis_source = trade.basis_source
            row.option_strike = trade.option_details.strike if trade.option_details else None
            row.option_expiry = (
                trade.option_details.expiry.isoformat() if trade.option_details else None
            )
            row.option_call_put = trade.option_details.call_put if trade.option_details else None
            # is_manual stays True; natural_key untouched.
            s.add(row)
            s.commit()
            s.refresh(row)
            saved = self._row_to_trade(row, self._account_display_for_id(s, row.account_id))
        recompute_all_violations(self, etf_pairs)
        return saved
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/db/test_repository_manual_trades.py -v`

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_manual_trades.py
git commit -m "feat(db): Repository.update_manual_trade"
```

---

## Task 6: Repository.delete_manual_trade

Deletes a row where `is_manual=True`. Rejects deletion of imported rows.

**Files:**
- Modify: `src/net_alpha/db/repository.py`
- Test: `tests/db/test_repository_manual_trades.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/db/test_repository_manual_trades.py`:

```python
def test_delete_manual_trade_removes_row(tmp_path):
    repo = _setup(tmp_path)
    t = Trade(
        account="Schwab/Tax", date=date(2026, 1, 15), ticker="AAPL",
        action="Buy", quantity=10, cost_basis=1500.0, basis_source="user", is_manual=True,
    )
    saved = repo.create_manual_trade(t, etf_pairs={})
    repo.delete_manual_trade(saved.id, etf_pairs={})
    assert repo.all_trades() == []


def test_delete_manual_trade_rejects_imported_row(tmp_path):
    repo = _setup(tmp_path)
    with repo.engine.begin() as conn:
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:x', 'AAPL', '2024-06-15', 'Buy', 10, 1000, 'broker_csv', 0)"
        ))
        trade_id = str(conn.execute(text("SELECT id FROM trades")).first()[0])

    import pytest
    with pytest.raises(ValueError):
        repo.delete_manual_trade(trade_id, etf_pairs={})
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/db/test_repository_manual_trades.py -v`

Expected: 2 new tests FAIL — method does not exist.

- [ ] **Step 3: Add the method**

Edit `src/net_alpha/db/repository.py`. Add after `update_manual_trade`:

```python
    def delete_manual_trade(self, trade_id: str, etf_pairs: dict[str, list[str]]) -> None:
        """Delete a manual trade. Verifies is_manual=True."""
        with Session(self.engine) as s:
            row = s.exec(select(TradeRow).where(TradeRow.id == int(trade_id))).first()
            if row is None:
                raise LookupError(f"Trade id {trade_id} not found")
            if not row.is_manual:
                raise ValueError("delete_manual_trade requires is_manual=True row")
            s.delete(row)
            s.commit()
        recompute_all_violations(self, etf_pairs)
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/db/test_repository_manual_trades.py -v`

Expected: all PASS.

- [ ] **Step 5: Run the full DB + engine suites**

Run: `uv run pytest tests/db/ tests/engine/ -v`

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/db/repository.py tests/db/test_repository_manual_trades.py
git commit -m "feat(db): Repository.delete_manual_trade"
```

---

## Task 7: `display_action` helper

Pure function for the Timeline column derivation. Lives in `web/format.py` so it's importable from both routes and templates (via context).

**Files:**
- Create: `src/net_alpha/web/format.py`
- Test: `tests/web/test_ticker_display_action.py` (create)

- [ ] **Step 1: Write the failing test**

Create `tests/web/test_ticker_display_action.py`:

```python
from __future__ import annotations

from datetime import date

from net_alpha.models.domain import Trade
from net_alpha.web.format import display_action


def _t(action="Buy", basis_source="broker_csv"):
    return Trade(
        account="Schwab/Tax", date=date(2026, 1, 15), ticker="AAPL",
        action=action, quantity=10, basis_source=basis_source,
    )


def test_display_action_transfer_in():
    assert display_action(_t(action="Buy", basis_source="transfer_in")) == "Transfer In"


def test_display_action_transfer_out():
    assert display_action(_t(action="Sell", basis_source="transfer_out")) == "Transfer Out"


def test_display_action_regular_buy():
    assert display_action(_t(action="Buy", basis_source="broker_csv")) == "Buy"


def test_display_action_regular_sell():
    assert display_action(_t(action="Sell", basis_source="broker_csv")) == "Sell"


def test_display_action_user_manual_buy():
    assert display_action(_t(action="Buy", basis_source="user")) == "Buy"
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_ticker_display_action.py -v`

Expected: FAIL — module `net_alpha.web.format` does not exist.

- [ ] **Step 3: Create the helper**

Create `src/net_alpha/web/format.py`:

```python
"""Pure presentation helpers for web templates."""

from __future__ import annotations

from net_alpha.models.domain import Trade


def display_action(t: Trade) -> str:
    """User-facing action label.

    Transfers are stored as Buy/Sell with basis_source set to transfer_in /
    transfer_out so engine logic treats them uniformly. The Timeline column
    re-expands the label for clarity.
    """
    if t.basis_source == "transfer_in":
        return "Transfer In"
    if t.basis_source == "transfer_out":
        return "Transfer Out"
    return t.action
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_ticker_display_action.py -v`

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/format.py tests/web/test_ticker_display_action.py
git commit -m "feat(web): display_action helper for transfer-aware Timeline labels"
```

---

## Task 8: Wire `display_action` + provenance badges into ticker.html

Use `display_action` for the Action column. Add a provenance badge column. Add an affordance column (filled in by Tasks 9–13).

**Files:**
- Modify: `src/net_alpha/web/routes/ticker.py`
- Modify: `src/net_alpha/web/templates/ticker.html:43-72`
- Test: `tests/web/test_ticker_display_action.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_ticker_display_action.py`:

```python
def test_ticker_timeline_renders_transfer_in_label(tmp_path):
    """A transfer_in row in the Timeline should render 'Transfer In', not 'Buy'."""
    from fastapi.testclient import TestClient
    from sqlalchemy import text

    from net_alpha.config import Settings
    from net_alpha.db.connection import get_engine
    from net_alpha.web.app import create_app

    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:t1', 'AAPL', '2026-02-01', 'Buy', 10, NULL, 'transfer_in', 0)"
        ))
    client = TestClient(create_app(settings))
    response = client.get("/ticker/AAPL")
    assert response.status_code == 200
    html = response.text
    assert "Transfer In" in html
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/web/test_ticker_display_action.py::test_ticker_timeline_renders_transfer_in_label -v`

Expected: FAIL — Timeline currently renders "Buy" for the transfer row.

- [ ] **Step 3: Pass `display_action` into the ticker template context**

Edit `src/net_alpha/web/routes/ticker.py`. Find the `TemplateResponse` call that renders `ticker.html`. Add a context key:

```python
from net_alpha.web.format import display_action
```

(Add at top of imports.)

In the context dict passed to `TemplateResponse`, add:

```python
            "display_action": display_action,
```

- [ ] **Step 4: Update the Timeline template**

Edit `src/net_alpha/web/templates/ticker.html`. Replace the entire Timeline `<table>` block (lines 44-72):

```html
  <div class="panel mb-6" style="padding:0;">
    <table class="net-table text-sm">
      <thead>
        <tr>
          <th>Date</th>
          <th>Account</th>
          <th>Provenance</th>
          <th>Action</th>
          <th>Qty</th>
          <th>Basis</th>
          <th>Proceeds</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {% for t in trades %}
          <tr>
            <td class="px-2 py-1 font-mono">{{ t.date }}</td>
            <td class="px-2 py-1">{{ t.account }}</td>
            <td class="px-2 py-1 text-[11px]">
              {% if t.is_manual %}<span class="pill" style="color: var(--color-accent);">manual</span>
              {% elif t.transfer_basis_user_set %}<span class="pill" style="color: var(--color-warn);">edited</span>
              {% endif %}
            </td>
            <td class="px-2 py-1">{{ display_action(t) }}</td>
            <td class="px-2 py-1 num font-mono">{{ t.quantity }}</td>
            <td class="px-2 py-1 num font-mono">{{ t.cost_basis if t.cost_basis is not none else "-" }}</td>
            <td class="px-2 py-1 num font-mono">{{ t.proceeds if t.proceeds is not none else "-" }}</td>
            <td class="px-2 py-1 text-[11px]" id="trade-affordance-{{ t.id }}">
              {# Filled in by Task 13 (Add trade button + affordances). Empty for now. #}
            </td>
          </tr>
        {% endfor %}
        {% if not trades %}
          <tr><td colspan="8" class="px-2 py-4 text-center text-label-2">No trades for {{ symbol }} yet.</td></tr>
        {% endif %}
      </tbody>
    </table>
  </div>
```

- [ ] **Step 5: Run the test to verify it passes**

Run: `uv run pytest tests/web/test_ticker_display_action.py -v`

Expected: all PASS.

- [ ] **Step 6: Run the full ticker suite**

Run: `uv run pytest tests/web/test_ticker.py tests/web/test_ticker_lot_detail.py tests/web/test_ticker_display_action.py -v`

Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/ticker.py src/net_alpha/web/templates/ticker.html tests/web/test_ticker_display_action.py
git commit -m "feat(web): Timeline shows Transfer In/Out + provenance badges"
```

---

## Task 9: POST /trades — create manual trade

Form-driven creation. The route accepts the form fields, maps the four `action_choice` values to the storage shape (per spec), validates, calls `create_manual_trade`, and returns a redirect (`303 See Other`) or HX-Redirect to `/ticker/{symbol}`.

**Files:**
- Create: `src/net_alpha/web/routes/trades.py`
- Modify: `src/net_alpha/web/app.py`
- Test: `tests/web/test_trades_routes.py` (create)

- [ ] **Step 1: Write the failing test**

Create `tests/web/test_trades_routes.py`:

```python
from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import text

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.web.app import create_app


def _client(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
    return TestClient(create_app(settings))


def test_post_trades_creates_manual_buy(tmp_path):
    client = _client(tmp_path)
    r = client.post(
        "/trades",
        data={
            "account": "Schwab/Tax",
            "ticker": "AAPL",
            "trade_date": "2026-01-15",
            "action_choice": "Buy",
            "quantity": "10",
            "basis_or_proceeds": "1500",
        },
        follow_redirects=False,
    )
    assert r.status_code in (200, 303)
    # Verify it persisted.
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        row = conn.execute(text(
            "SELECT ticker, action, basis_source, is_manual, cost_basis FROM trades"
        )).first()
    assert row[0] == "AAPL"
    assert row[1] == "Buy"
    assert row[2] == "user"
    assert row[3] == 1
    assert abs(row[4] - 1500.0) < 1e-9


def test_post_trades_creates_manual_transfer_in(tmp_path):
    """Transfer In selection stores action=Buy + basis_source=transfer_in."""
    client = _client(tmp_path)
    r = client.post(
        "/trades",
        data={
            "account": "Schwab/Tax",
            "ticker": "AAPL",
            "trade_date": "2024-06-15",
            "action_choice": "Transfer In",
            "quantity": "10",
            "basis_or_proceeds": "2500",
        },
        follow_redirects=False,
    )
    assert r.status_code in (200, 303)
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        row = conn.execute(text(
            "SELECT action, basis_source, is_manual, cost_basis FROM trades"
        )).first()
    assert row[0] == "Buy"
    assert row[1] == "transfer_in"
    assert row[2] == 1
    assert abs(row[3] - 2500.0) < 1e-9


def test_post_trades_rejects_unknown_account(tmp_path):
    client = _client(tmp_path)
    r = client.post(
        "/trades",
        data={
            "account": "Schwab/Bogus",
            "ticker": "AAPL",
            "trade_date": "2026-01-15",
            "action_choice": "Buy",
            "quantity": "10",
            "basis_or_proceeds": "1500",
        },
    )
    assert r.status_code == 400


def test_post_trades_rejects_future_date(tmp_path):
    from datetime import date, timedelta
    client = _client(tmp_path)
    future = (date.today() + timedelta(days=30)).isoformat()
    r = client.post(
        "/trades",
        data={
            "account": "Schwab/Tax",
            "ticker": "AAPL",
            "trade_date": future,
            "action_choice": "Buy",
            "quantity": "10",
            "basis_or_proceeds": "1500",
        },
    )
    assert r.status_code == 400
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_trades_routes.py -v`

Expected: FAIL — `/trades` route not registered.

- [ ] **Step 3: Create the trades router**

Create `src/net_alpha/web/routes/trades.py`:

```python
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from net_alpha.db.repository import Repository
from net_alpha.engine.etf_pairs import load_etf_pairs
from net_alpha.models.domain import Trade
from net_alpha.web.dependencies import get_repository

router = APIRouter()


_ACTION_MAP = {
    "Buy": ("Buy", "user"),
    "Sell": ("Sell", "user"),
    "Transfer In": ("Buy", "transfer_in"),
    "Transfer Out": ("Sell", "transfer_out"),
}


def _validate_account(repo: Repository, account: str) -> None:
    """Reject accounts that don't already exist."""
    accounts = {imp.account_display for imp in repo.list_imports()}
    if account not in accounts:
        raise HTTPException(status_code=400, detail=f"unknown account: {account!r}")


def _parse_date(raw: str) -> date:
    try:
        d = date.fromisoformat(raw)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"invalid date: {raw!r}") from None
    if d > date.today():
        raise HTTPException(status_code=400, detail="date must not be in the future")
    return d


@router.post("/trades", response_class=HTMLResponse)
def create_trade(
    request: Request,
    account: str = Form(...),
    ticker: str = Form(...),
    trade_date: str = Form(...),
    action_choice: str = Form(...),
    quantity: float = Form(...),
    basis_or_proceeds: float = Form(...),
    repo: Repository = Depends(get_repository),
) -> HTMLResponse | RedirectResponse:
    if action_choice not in _ACTION_MAP:
        raise HTTPException(status_code=400, detail=f"invalid action: {action_choice!r}")
    if not ticker.strip():
        raise HTTPException(status_code=400, detail="ticker required")
    if quantity <= 0:
        raise HTTPException(status_code=400, detail="quantity must be > 0")
    if basis_or_proceeds < 0:
        raise HTTPException(status_code=400, detail="basis/proceeds must be >= 0")
    _validate_account(repo, account)
    d = _parse_date(trade_date)

    action, basis_source = _ACTION_MAP[action_choice]
    is_buy_side = action == "Buy"
    trade = Trade(
        account=account,
        date=d,
        ticker=ticker.strip().upper(),
        action=action,
        quantity=quantity,
        cost_basis=basis_or_proceeds if is_buy_side else None,
        proceeds=basis_or_proceeds if not is_buy_side else None,
        basis_source=basis_source,
        is_manual=True,
    )
    etf_pairs = load_etf_pairs()
    repo.create_manual_trade(trade, etf_pairs=etf_pairs)
    response = RedirectResponse(url=f"/ticker/{trade.ticker}", status_code=303)
    # Allow HTMX to follow the redirect or fall back to plain navigation.
    response.headers["HX-Redirect"] = f"/ticker/{trade.ticker}"
    return response
```

- [ ] **Step 4: Register the trades router**

Edit `src/net_alpha/web/app.py`. Add to the imports:

```python
from net_alpha.web.routes import calendar, detail, holdings, sim, system, ticker, trades
```

(Insert `trades` alphabetically.) And add to the `include_router` block:

```python
    app.include_router(trades.router)
```

- [ ] **Step 5: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_trades_routes.py -v`

Expected: all 4 PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/trades.py src/net_alpha/web/app.py tests/web/test_trades_routes.py
git commit -m "feat(web): POST /trades — create manual trade"
```

---

## Task 10: POST /trades/{id}/edit-transfer

Date + basis (or proceeds) edit on imported transfer rows.

**Files:**
- Modify: `src/net_alpha/web/routes/trades.py`
- Test: `tests/web/test_trades_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_trades_routes.py`:

```python
def test_edit_transfer_updates_imported_row(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:k1', 'AAPL', '2026-02-01', 'Buy', 10, NULL, 'transfer_in', 0)"
        ))
        trade_id = conn.execute(text("SELECT id FROM trades")).first()[0]
    client = TestClient(create_app(settings))
    r = client.post(
        f"/trades/{trade_id}/edit-transfer",
        data={"trade_date": "2024-06-15", "basis_or_proceeds": "2500"},
        follow_redirects=False,
    )
    assert r.status_code in (200, 303)
    with engine.begin() as conn:
        row = conn.execute(text(
            "SELECT trade_date, cost_basis, transfer_basis_user_set, natural_key FROM trades"
        )).first()
    assert row[0] == "2024-06-15"
    assert abs(row[1] - 2500.0) < 1e-9
    assert row[2] == 1
    assert row[3] == "csv:k1"  # natural_key preserved


def test_edit_transfer_rejects_non_transfer_row(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:k2', 'AAPL', '2024-06-15', 'Buy', 10, 1000, 'broker_csv', 0)"
        ))
        trade_id = conn.execute(text("SELECT id FROM trades")).first()[0]
    client = TestClient(create_app(settings))
    r = client.post(
        f"/trades/{trade_id}/edit-transfer",
        data={"trade_date": "2024-06-15", "basis_or_proceeds": "2500"},
    )
    assert r.status_code == 400
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_trades_routes.py::test_edit_transfer_updates_imported_row tests/web/test_trades_routes.py::test_edit_transfer_rejects_non_transfer_row -v`

Expected: FAIL — route not registered.

- [ ] **Step 3: Add the route handler**

Edit `src/net_alpha/web/routes/trades.py`. Append:

```python
@router.post("/trades/{trade_id}/edit-transfer", response_class=HTMLResponse)
def edit_transfer(
    request: Request,
    trade_id: str,
    trade_date: str = Form(...),
    basis_or_proceeds: float = Form(...),
    repo: Repository = Depends(get_repository),
) -> RedirectResponse:
    if basis_or_proceeds < 0:
        raise HTTPException(status_code=400, detail="basis/proceeds must be >= 0")
    d = _parse_date(trade_date)
    etf_pairs = load_etf_pairs()
    try:
        saved = repo.update_imported_transfer(
            trade_id=trade_id,
            new_date=d,
            new_basis_or_proceeds=basis_or_proceeds,
            etf_pairs=etf_pairs,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    response = RedirectResponse(url=f"/ticker/{saved.ticker}", status_code=303)
    response.headers["HX-Redirect"] = f"/ticker/{saved.ticker}"
    return response
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_trades_routes.py -v`

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/trades.py tests/web/test_trades_routes.py
git commit -m "feat(web): POST /trades/{id}/edit-transfer"
```

---

## Task 11: POST /trades/{id}/edit-manual

Full edit on manual rows.

**Files:**
- Modify: `src/net_alpha/web/routes/trades.py`
- Test: `tests/web/test_trades_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_trades_routes.py`:

```python
def test_edit_manual_updates_user_row(tmp_path):
    client = _client(tmp_path)
    # Create one first.
    client.post(
        "/trades",
        data={
            "account": "Schwab/Tax", "ticker": "AAPL", "trade_date": "2026-01-15",
            "action_choice": "Buy", "quantity": "10", "basis_or_proceeds": "1500",
        },
        follow_redirects=False,
    )
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        trade_id = conn.execute(text("SELECT id FROM trades")).first()[0]
    r = client.post(
        f"/trades/{trade_id}/edit-manual",
        data={
            "account": "Schwab/Tax", "ticker": "AAPL", "trade_date": "2025-12-20",
            "action_choice": "Buy", "quantity": "12", "basis_or_proceeds": "1900",
        },
        follow_redirects=False,
    )
    assert r.status_code in (200, 303)
    with engine.begin() as conn:
        row = conn.execute(text(
            "SELECT trade_date, quantity, cost_basis, is_manual FROM trades"
        )).first()
    assert row[0] == "2025-12-20"
    assert abs(row[1] - 12.0) < 1e-9
    assert abs(row[2] - 1900.0) < 1e-9
    assert row[3] == 1


def test_edit_manual_rejects_imported_row(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:k', 'AAPL', '2024-06-15', 'Buy', 10, 1000, 'broker_csv', 0)"
        ))
        trade_id = conn.execute(text("SELECT id FROM trades")).first()[0]
    client = TestClient(create_app(settings))
    r = client.post(
        f"/trades/{trade_id}/edit-manual",
        data={
            "account": "Schwab/Tax", "ticker": "AAPL", "trade_date": "2024-01-01",
            "action_choice": "Buy", "quantity": "10", "basis_or_proceeds": "999",
        },
    )
    assert r.status_code == 400
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_trades_routes.py::test_edit_manual_updates_user_row tests/web/test_trades_routes.py::test_edit_manual_rejects_imported_row -v`

Expected: FAIL — route not registered.

- [ ] **Step 3: Add the route handler**

Edit `src/net_alpha/web/routes/trades.py`. Append:

```python
@router.post("/trades/{trade_id}/edit-manual", response_class=HTMLResponse)
def edit_manual(
    request: Request,
    trade_id: str,
    account: str = Form(...),
    ticker: str = Form(...),
    trade_date: str = Form(...),
    action_choice: str = Form(...),
    quantity: float = Form(...),
    basis_or_proceeds: float = Form(...),
    repo: Repository = Depends(get_repository),
) -> RedirectResponse:
    if action_choice not in _ACTION_MAP:
        raise HTTPException(status_code=400, detail=f"invalid action: {action_choice!r}")
    if not ticker.strip():
        raise HTTPException(status_code=400, detail="ticker required")
    if quantity <= 0:
        raise HTTPException(status_code=400, detail="quantity must be > 0")
    if basis_or_proceeds < 0:
        raise HTTPException(status_code=400, detail="basis/proceeds must be >= 0")
    _validate_account(repo, account)
    d = _parse_date(trade_date)

    action, basis_source = _ACTION_MAP[action_choice]
    is_buy_side = action == "Buy"
    trade = Trade(
        id=trade_id,
        account=account,
        date=d,
        ticker=ticker.strip().upper(),
        action=action,
        quantity=quantity,
        cost_basis=basis_or_proceeds if is_buy_side else None,
        proceeds=basis_or_proceeds if not is_buy_side else None,
        basis_source=basis_source,
        is_manual=True,
    )
    etf_pairs = load_etf_pairs()
    try:
        saved = repo.update_manual_trade(trade, etf_pairs=etf_pairs)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    response = RedirectResponse(url=f"/ticker/{saved.ticker}", status_code=303)
    response.headers["HX-Redirect"] = f"/ticker/{saved.ticker}"
    return response
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_trades_routes.py -v`

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add src/net_alpha/web/routes/trades.py tests/web/test_trades_routes.py
git commit -m "feat(web): POST /trades/{id}/edit-manual"
```

---

## Task 12: POST /trades/{id}/delete

Delete manual rows; reject deletes of imported rows.

**Files:**
- Modify: `src/net_alpha/web/routes/trades.py`
- Test: `tests/web/test_trades_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_trades_routes.py`:

```python
def test_delete_manual_removes_row(tmp_path):
    client = _client(tmp_path)
    client.post(
        "/trades",
        data={
            "account": "Schwab/Tax", "ticker": "AAPL", "trade_date": "2026-01-15",
            "action_choice": "Buy", "quantity": "10", "basis_or_proceeds": "1500",
        },
        follow_redirects=False,
    )
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        trade_id = conn.execute(text("SELECT id FROM trades")).first()[0]
    r = client.post(f"/trades/{trade_id}/delete", follow_redirects=False)
    assert r.status_code in (200, 303)
    with engine.begin() as conn:
        n = conn.execute(text("SELECT COUNT(*) FROM trades")).first()[0]
    assert n == 0


def test_delete_imported_row_rejected(tmp_path):
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab','Tax')"))
        conn.execute(text(
            "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
            "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 1)"
        ))
        conn.execute(text(
            "INSERT INTO trades(import_id, account_id, natural_key, ticker, trade_date, action, "
            "quantity, cost_basis, basis_source, is_manual) "
            "VALUES (1, 1, 'csv:k', 'AAPL', '2024-06-15', 'Buy', 10, 1000, 'broker_csv', 0)"
        ))
        trade_id = conn.execute(text("SELECT id FROM trades")).first()[0]
    client = TestClient(create_app(settings))
    r = client.post(f"/trades/{trade_id}/delete")
    assert r.status_code == 400
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_trades_routes.py::test_delete_manual_removes_row tests/web/test_trades_routes.py::test_delete_imported_row_rejected -v`

Expected: FAIL — route not registered.

- [ ] **Step 3: Add the route handler**

Edit `src/net_alpha/web/routes/trades.py`. Append:

```python
@router.post("/trades/{trade_id}/delete", response_class=HTMLResponse)
def delete_trade(
    request: Request,
    trade_id: str,
    repo: Repository = Depends(get_repository),
) -> RedirectResponse:
    etf_pairs = load_etf_pairs()
    # Look up the ticker before deleting so we can redirect back.
    target_ticker = "?"
    for t in repo.all_trades():
        if t.id == trade_id:
            target_ticker = t.ticker
            break
    try:
        repo.delete_manual_trade(trade_id, etf_pairs=etf_pairs)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    response = RedirectResponse(url=f"/ticker/{target_ticker}", status_code=303)
    response.headers["HX-Redirect"] = f"/ticker/{target_ticker}"
    return response
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_trades_routes.py -v`

Expected: all PASS.

- [ ] **Step 5: Run the full web suite**

Run: `uv run pytest tests/web/ -v`

Expected: all PASS.

- [ ] **Step 6: Commit**

```bash
git add src/net_alpha/web/routes/trades.py tests/web/test_trades_routes.py
git commit -m "feat(web): POST /trades/{id}/delete"
```

---

## Task 13: Trade form templates + "Add trade" button + per-row affordances

The full-edit form (used for Add and Edit-manual) and the transfer-edit form. Also wires the "Add trade" button on `/ticker/{symbol}` and fills the per-row affordance column from Task 8.

**Files:**
- Create: `src/net_alpha/web/templates/_trade_form.html`
- Create: `src/net_alpha/web/templates/_trade_transfer_form.html`
- Create: `src/net_alpha/web/templates/_trade_delete_confirm.html`
- Modify: `src/net_alpha/web/templates/ticker.html`

- [ ] **Step 1: Create the shared full-edit form**

Create `src/net_alpha/web/templates/_trade_form.html`:

```html
{# Used for Add (POST /trades) and Edit-manual (POST /trades/{id}/edit-manual).
   Caller passes:
     form_action     — the POST URL
     accounts        — list[str] of account display names
     submit_label    — button text
     trade           — optional Trade for prefill (None for Add)
     symbol          — default ticker for Add
#}
<div class="bg-surface rounded-lg shadow-xl max-w-md w-full mx-4 p-6"
     style="border:0.5px solid rgba(255,255,255,0.08);"
     onclick="event.stopPropagation()"
     x-data="{ choice: '{{ trade.basis_source if trade else 'user' }}' === 'transfer_in' ? 'Transfer In'
              : '{{ trade.basis_source if trade else 'user' }}' === 'transfer_out' ? 'Transfer Out'
              : '{{ trade.action if trade else 'Buy' }}' }">
  <div class="flex justify-between items-center mb-4">
    <h2 class="text-xl">{{ submit_label }}</h2>
    <button type="button" onclick="document.getElementById('trade-modal').classList.add('hidden')"
            class="text-label-2 hover:text-text text-2xl leading-none">&times;</button>
  </div>
  <form action="{{ form_action }}" method="post" class="space-y-3">
    <div>
      <label class="block label-uc mb-1">Account</label>
      <select name="account" required
              class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full"
              style="border:0.5px solid rgba(255,255,255,0.08);">
        {% for a in accounts %}
          <option value="{{ a }}" {% if trade and trade.account == a %}selected{% endif %}>{{ a }}</option>
        {% endfor %}
      </select>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="block label-uc mb-1">Ticker</label>
        <input type="text" name="ticker" required
               value="{{ trade.ticker if trade else (symbol or '') }}"
               class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full font-mono"
               style="border:0.5px solid rgba(255,255,255,0.08);"/>
      </div>
      <div>
        <label class="block label-uc mb-1">Date</label>
        <input type="date" name="trade_date" required
               value="{{ trade.date.isoformat() if trade else '' }}"
               class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full"
               style="border:0.5px solid rgba(255,255,255,0.08);"/>
      </div>
    </div>
    <div>
      <label class="block label-uc mb-1">Action</label>
      <select name="action_choice" x-model="choice" required
              class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full"
              style="border:0.5px solid rgba(255,255,255,0.08);">
        <option>Buy</option>
        <option>Sell</option>
        <option>Transfer In</option>
        <option>Transfer Out</option>
      </select>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="block label-uc mb-1">Quantity</label>
        <input type="number" name="quantity" step="any" required min="0.0001"
               value="{{ trade.quantity if trade else '' }}"
               class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full font-mono"
               style="border:0.5px solid rgba(255,255,255,0.08);"/>
      </div>
      <div>
        <label class="block label-uc mb-1">
          <span x-text="(choice === 'Buy' || choice === 'Transfer In') ? 'Cost basis' : 'Proceeds'"></span>
          ($)
        </label>
        <input type="number" name="basis_or_proceeds" step="any" required min="0"
               value="{{ (trade.cost_basis if trade and trade.cost_basis is not none else trade.proceeds) if trade else '' }}"
               class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full font-mono"
               style="border:0.5px solid rgba(255,255,255,0.08);"/>
      </div>
    </div>
    <p class="text-xs text-label-3">&#9888; This is informational only. Consult a tax professional before filing.</p>
    <div class="flex justify-end gap-2 pt-2">
      <button type="button" class="btn-ghost"
              onclick="document.getElementById('trade-modal').classList.add('hidden')">Cancel</button>
      <button type="submit" class="btn">{{ submit_label }}</button>
    </div>
  </form>
</div>
```

- [ ] **Step 2: Create the transfer-edit form**

Create `src/net_alpha/web/templates/_trade_transfer_form.html`:

```html
{# Caller passes:
     trade           — the imported transfer Trade row
     form_action     — POST /trades/{id}/edit-transfer
#}
<div class="bg-surface rounded-lg shadow-xl max-w-md w-full mx-4 p-6"
     style="border:0.5px solid rgba(255,255,255,0.08);"
     onclick="event.stopPropagation()">
  <div class="flex justify-between items-center mb-4">
    <h2 class="text-xl">Set basis &amp; date</h2>
    <button type="button" onclick="document.getElementById('trade-modal').classList.add('hidden')"
            class="text-label-2 hover:text-text text-2xl leading-none">&times;</button>
  </div>
  <p class="text-[12px] text-label-2 mb-3">
    {{ trade.ticker }} &middot; {{ trade.account }} &middot; {{ trade.quantity }} sh
  </p>
  <form action="{{ form_action }}" method="post" class="space-y-3">
    <div>
      <label class="block label-uc mb-1">Acquisition date</label>
      <input type="date" name="trade_date" required
             value="{{ trade.date.isoformat() }}"
             class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full"
             style="border:0.5px solid rgba(255,255,255,0.08);"/>
    </div>
    <div>
      <label class="block label-uc mb-1">
        {% if trade.basis_source == "transfer_in" %}Cost basis ($){% else %}Proceeds ($){% endif %}
      </label>
      <input type="number" name="basis_or_proceeds" step="any" required min="0"
             value="{{ (trade.cost_basis if trade.cost_basis is not none else trade.proceeds) or '' }}"
             class="bg-surface text-text rounded-md px-2 py-1 text-[13px] w-full font-mono"
             style="border:0.5px solid rgba(255,255,255,0.08);"/>
    </div>
    <p class="text-xs text-label-3">&#9888; This is informational only. Consult a tax professional before filing.</p>
    <div class="flex justify-end gap-2 pt-2">
      <button type="button" class="btn-ghost"
              onclick="document.getElementById('trade-modal').classList.add('hidden')">Cancel</button>
      <button type="submit" class="btn">Save</button>
    </div>
  </form>
</div>
```

- [ ] **Step 3: Create the delete-confirm dialog**

Create `src/net_alpha/web/templates/_trade_delete_confirm.html`:

```html
{# Caller passes:
     trade           — the manual Trade row
     form_action     — POST /trades/{id}/delete
#}
<div class="bg-surface rounded-lg shadow-xl max-w-sm w-full mx-4 p-6"
     style="border:0.5px solid rgba(255,255,255,0.08);"
     onclick="event.stopPropagation()">
  <h2 class="text-lg mb-2">Delete trade?</h2>
  <p class="text-[13px] text-label-2 mb-4">
    {{ trade.ticker }} &middot; {{ trade.action }} {{ trade.quantity }} on {{ trade.date }}.<br>
    This can't be undone.
  </p>
  <form action="{{ form_action }}" method="post">
    <div class="flex justify-end gap-2">
      <button type="button" class="btn-ghost"
              onclick="document.getElementById('trade-modal').classList.add('hidden')">Cancel</button>
      <button type="submit" class="btn" style="background:var(--color-neg);">Delete</button>
    </div>
  </form>
</div>
```

- [ ] **Step 4: Wire the "Add trade" button + per-row affordances on the ticker page**

Edit `src/net_alpha/web/templates/ticker.html`. Find the toolbar block at the top (around lines 4-7):

```html
  <div class="flex justify-between items-baseline mb-4">
    <h1 class="text-2xl font-mono text-primary">{{ symbol }}</h1>
    <a href="/sim?ticker={{ symbol }}" class="btn">Simulate sale</a>
  </div>
```

Replace with:

```html
  <div class="flex justify-between items-baseline mb-4">
    <h1 class="text-2xl font-mono text-primary">{{ symbol }}</h1>
    <div class="flex gap-2">
      <button type="button" class="btn"
              onclick="
                fetch('/ticker/{{ symbol }}/add-form').then(r => r.text()).then(html => {
                  document.getElementById('trade-modal-content').innerHTML = html;
                  document.getElementById('trade-modal').classList.remove('hidden');
                });
              ">Add trade</button>
      <a href="/sim?ticker={{ symbol }}" class="btn">Simulate sale</a>
    </div>
  </div>
```

Replace the empty affordance cell from Task 8 (look for `id="trade-affordance-{{ t.id }}"`):

```html
            <td class="px-2 py-1 text-[11px] r" id="trade-affordance-{{ t.id }}">
              {% if t.is_manual %}
                <a href="#" class="text-label-2 hover:text-text mr-2"
                   onclick="event.preventDefault();
                     fetch('/ticker/{{ symbol }}/edit-manual-form/{{ t.id }}').then(r => r.text()).then(html => {
                       document.getElementById('trade-modal-content').innerHTML = html;
                       document.getElementById('trade-modal').classList.remove('hidden');
                     });">edit</a>
                <a href="#" class="text-confirmed hover:text-text"
                   onclick="event.preventDefault();
                     fetch('/ticker/{{ symbol }}/delete-confirm/{{ t.id }}').then(r => r.text()).then(html => {
                       document.getElementById('trade-modal-content').innerHTML = html;
                       document.getElementById('trade-modal').classList.remove('hidden');
                     });">delete</a>
              {% elif t.basis_source in ['transfer_in', 'transfer_out'] %}
                <a href="#" class="text-label-2 hover:text-text"
                   onclick="event.preventDefault();
                     fetch('/ticker/{{ symbol }}/edit-transfer-form/{{ t.id }}').then(r => r.text()).then(html => {
                       document.getElementById('trade-modal-content').innerHTML = html;
                       document.getElementById('trade-modal').classList.remove('hidden');
                     });">set basis &amp; date</a>
              {% endif %}
            </td>
```

Append the modal container at the bottom of the `{% block content %}` block, just before `{% endblock %}`:

```html
  <div id="trade-modal" class="hidden fixed inset-0 bg-black/60 z-50 flex items-center justify-center"
       onclick="this.classList.add('hidden')">
    <div id="trade-modal-content"></div>
  </div>
```

- [ ] **Step 5: Add the four GET form-fragment routes**

Edit `src/net_alpha/web/routes/ticker.py`. Add four GET routes that render each form fragment. Add the imports near the top:

```python
from fastapi import HTTPException
```

Near the existing route definitions, append:

```python
@router.get("/ticker/{symbol}/add-form", response_class=HTMLResponse)
def trade_add_form(
    request: Request,
    symbol: str,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    accounts = sorted({imp.account_display for imp in repo.list_imports()})
    return request.app.state.templates.TemplateResponse(
        request,
        "_trade_form.html",
        {
            "form_action": "/trades",
            "accounts": accounts,
            "submit_label": "Add trade",
            "trade": None,
            "symbol": symbol.upper(),
        },
    )


def _find_trade(repo: Repository, trade_id: str):
    for t in repo.all_trades():
        if t.id == trade_id:
            return t
    return None


@router.get("/ticker/{symbol}/edit-manual-form/{trade_id}", response_class=HTMLResponse)
def trade_edit_manual_form(
    request: Request, symbol: str, trade_id: str,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    t = _find_trade(repo, trade_id)
    if t is None or not t.is_manual:
        raise HTTPException(status_code=404, detail="manual trade not found")
    accounts = sorted({imp.account_display for imp in repo.list_imports()})
    return request.app.state.templates.TemplateResponse(
        request,
        "_trade_form.html",
        {
            "form_action": f"/trades/{trade_id}/edit-manual",
            "accounts": accounts,
            "submit_label": "Save changes",
            "trade": t,
            "symbol": symbol.upper(),
        },
    )


@router.get("/ticker/{symbol}/edit-transfer-form/{trade_id}", response_class=HTMLResponse)
def trade_edit_transfer_form(
    request: Request, symbol: str, trade_id: str,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    t = _find_trade(repo, trade_id)
    if t is None or t.basis_source not in ("transfer_in", "transfer_out") or t.is_manual:
        raise HTTPException(status_code=404, detail="transfer row not found")
    return request.app.state.templates.TemplateResponse(
        request,
        "_trade_transfer_form.html",
        {
            "form_action": f"/trades/{trade_id}/edit-transfer",
            "trade": t,
        },
    )


@router.get("/ticker/{symbol}/delete-confirm/{trade_id}", response_class=HTMLResponse)
def trade_delete_confirm(
    request: Request, symbol: str, trade_id: str,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    t = _find_trade(repo, trade_id)
    if t is None or not t.is_manual:
        raise HTTPException(status_code=404, detail="manual trade not found")
    return request.app.state.templates.TemplateResponse(
        request,
        "_trade_delete_confirm.html",
        {
            "form_action": f"/trades/{trade_id}/delete",
            "trade": t,
        },
    )
```

- [ ] **Step 6: Smoke-check via existing tests**

Run: `uv run pytest tests/web/ -v`

Expected: all PASS.

- [ ] **Step 7: Visual sanity check**

Run: `uv run net-alpha ui --no-browser`. Visit a ticker page.
- Confirm "Add trade" button appears.
- Click it; the modal opens with the form.
- Submit a Buy with 1 share and basis 100; verify it appears in the Timeline as `Buy` with the `manual` badge.
- Add a Transfer In; verify it shows as `Transfer In`.
- For an existing transfer-in row (if any in the DB), confirm the "set basis & date" link opens the smaller form.
- Click `delete` on the manual row; confirm dialog appears; confirm; row is gone.

Stop the server.

- [ ] **Step 8: Commit**

```bash
git add src/net_alpha/web/templates/_trade_form.html src/net_alpha/web/templates/_trade_transfer_form.html src/net_alpha/web/templates/_trade_delete_confirm.html src/net_alpha/web/templates/ticker.html src/net_alpha/web/routes/ticker.py
git commit -m "feat(web): Add-trade button + per-row affordances + form modals on ticker page"
```

---

## Task 14: Re-import preserves edits — integration test

End-to-end check that editing a transfer-in row's date+basis survives a re-import of the same Schwab CSV. This is the spec's signature acceptance test.

**Files:**
- Create: `tests/integration/test_reimport_preserves_edits.py`

- [ ] **Step 1: Inspect available Schwab fixtures**

Run: `cat tests/fixtures/schwab_sample.csv | head -20`

If the fixture contains a `Security Transfer` or `Journaled Shares` row, use it directly. If not, write a small inline CSV in the test (the parser handles CSV strings). The test below uses an inline CSV for self-containment.

- [ ] **Step 2: Write the integration test**

Create `tests/integration/test_reimport_preserves_edits.py`:

```python
from __future__ import annotations

from datetime import date
from io import BytesIO

from fastapi.testclient import TestClient
from sqlalchemy import text

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.web.app import create_app


# A minimal Schwab Transaction History CSV with one Security Transfer row
# (the parser maps this to a Buy with basis_source='transfer_in' and basis=None).
_CSV = b"""Date,Action,Symbol,Description,Quantity,Price,Fees & Comm,Amount
01/15/2026,Security Transfer,AAPL,APPLE INC,10,,,
"""


def test_reimport_preserves_user_edits_to_transfer_row(tmp_path):
    settings = Settings(data_dir=tmp_path)
    client = TestClient(create_app(settings))

    # First import.
    client.post(
        "/imports",
        data={"account": "Tax"},
        files={"files": ("schwab.csv", BytesIO(_CSV), "text/csv")},
    )
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        rows = conn.execute(text(
            "SELECT id, trade_date, cost_basis, natural_key, basis_source FROM trades"
        )).all()
    assert len(rows) == 1
    trade_id, original_date, original_basis, original_nk, src = rows[0]
    assert src == "transfer_in"
    assert original_basis is None  # broker didn't supply basis

    # User fixes date (acquisition date) and basis.
    r = client.post(
        f"/trades/{trade_id}/edit-transfer",
        data={"trade_date": "2024-06-15", "basis_or_proceeds": "2500"},
        follow_redirects=False,
    )
    assert r.status_code in (200, 303)
    with engine.begin() as conn:
        row = conn.execute(text(
            "SELECT trade_date, cost_basis, natural_key, transfer_basis_user_set FROM trades"
        )).first()
    assert row[0] == "2024-06-15"
    assert abs(row[1] - 2500.0) < 1e-9
    assert row[2] == original_nk  # immutable
    assert row[3] == 1

    # Re-import the same CSV: idempotency should skip the row.
    r = client.post(
        "/imports",
        data={"account": "Tax"},
        files={"files": ("schwab.csv", BytesIO(_CSV), "text/csv")},
    )
    with engine.begin() as conn:
        rows = conn.execute(text(
            "SELECT trade_date, cost_basis, natural_key FROM trades"
        )).all()
    assert len(rows) == 1  # no duplicate
    assert rows[0][0] == "2024-06-15"  # user's date survived
    assert abs(rows[0][1] - 2500.0) < 1e-9  # user's basis survived
    assert rows[0][2] == original_nk
```

- [ ] **Step 3: Run the integration test**

Run: `uv run pytest tests/integration/test_reimport_preserves_edits.py -v`

If the import endpoint signature differs (`/imports` may want a different field name for files or account — the existing `_imports_table.html` and `_drop_zone.html` reveal the actual contract), adjust the request body to match. Re-run.

Expected: PASS.

- [ ] **Step 4: Run the full suite**

Run: `uv run pytest -v`

Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add tests/integration/test_reimport_preserves_edits.py
git commit -m "test(integration): re-import preserves user edits to transfer rows"
```

---

## Final verification

- [ ] **Run full test suite**

Run: `uv run pytest -v`

Expected: all PASS.

- [ ] **Run lint**

Run: `uv run ruff check . && uv run ruff format --check .`

Expected: clean.

- [ ] **Smoke test the app end-to-end**

Run: `uv run net-alpha ui --no-browser`. Walk through:
- Visit a ticker page; verify Timeline now shows Transfer In/Out labels for any existing transfer rows.
- Click "Add trade"; add a manual Buy; verify it appears with the `manual` badge and edit/delete affordances.
- For a transfer row with no basis (if you have one), click "set basis & date"; enter values; verify the row updates and the `edited` badge appears.
- Edit the manual trade; verify the change persists.
- Delete the manual trade; verify it's gone.
- Re-import the same Schwab CSV that contained the edited transfer row; verify the user's edit is not reverted (manually inspect via `/ticker/<symbol>` after re-import).

Stop the server.

---

## Self-review notes

- All operations from spec Section 1 are implemented:
  - Manual: add (Task 9), edit (Task 11), delete (Task 12). ✓
  - Imported transfer: edit date+basis (Task 10). ✓
  - Imported other: read-only — enforced by `update_imported_transfer` rejection in Task 4 and by the UI (no affordance link). ✓
- All four routes verified against the spec's authorization rules.
- `natural_key` immutability is tested at the repo layer (Task 4) and the integration layer (Task 14).
- Spec Section 5 display label "Transfer In" / "Transfer Out": Task 7 adds the helper, Task 8 wires it into the template, Task 8's test asserts the label appears.
- Spec Section 5 provenance badges (`manual`, `edited`): rendered in Task 8's template; the `edited` badge keys off `transfer_basis_user_set`, set in Task 4.
- The `recompute_all_violations` hook is invoked from each of the four repository write methods (Tasks 3-6) — matches Section 4 of the spec.
- Type/symbol consistency check:
  - `create_manual_trade(trade, etf_pairs)` — used in Tasks 3, 9.
  - `update_imported_transfer(trade_id, new_date, new_basis_or_proceeds, etf_pairs)` — used in Tasks 4, 10.
  - `update_manual_trade(trade, etf_pairs)` — used in Tasks 5, 11.
  - `delete_manual_trade(trade_id, etf_pairs)` — used in Tasks 6, 12.
  - `_ACTION_MAP` is the same in Tasks 9 and 11.
  - `display_action(t)` — used in Tasks 7, 8.
- The plan does not cover Spec A (UI polish + perf) — that is `2026-04-26-portfolio-polish-and-perf.md`.

## Open questions deferred to follow-up (per spec)

- Option-trade manual entry — schema permits, UI hides. Add when needed.
- Bulk import of manual trades from a tiny CSV/JSON file.
- Editing imported regular Buy/Sell rows.
