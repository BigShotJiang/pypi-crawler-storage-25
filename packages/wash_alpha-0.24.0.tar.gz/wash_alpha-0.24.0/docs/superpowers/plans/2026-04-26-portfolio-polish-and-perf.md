# Portfolio polish + perf — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Cut `/portfolio` page-to-paint from ~10s to <2s, move the holdings table to its own `/holdings` tab, replace the symbol text-search with a multi-select popover, fix the invisible "Choose Files" button in the import modal, and equalize the equity-curve and allocation panel widths.

**Architecture:** Replace the 5-fragment fan-out on `/portfolio` with a single bundled `/portfolio/body` endpoint that loads `trades`/`lots`/`prices` once and renders all panels. Promote the holdings table to a new `/holdings` page that reuses the existing `/portfolio/positions` fragment for in-page swaps. UI changes are contained to existing Jinja templates.

**Tech Stack:** FastAPI, Jinja2, HTMX, Alpine.js, Tailwind (no new deps).

**Spec:** `docs/superpowers/specs/2026-04-26-portfolio-polish-and-perf-design.md`

---

## File Structure

| File                                                       | Role                                                                  |
| ---------------------------------------------------------- | --------------------------------------------------------------------- |
| `src/net_alpha/web/routes/portfolio.py` (modify)           | Add `/portfolio/body` handler; change `q` → `symbols` filter.         |
| `src/net_alpha/web/routes/holdings.py` (create)            | `/holdings` page route; reuses `/portfolio/positions` fragment.       |
| `src/net_alpha/web/app.py` (modify)                        | Register the holdings router.                                         |
| `src/net_alpha/web/templates/portfolio.html` (modify)      | Single `hx-get` to `/portfolio/body`; equity/allocation columns 1fr 1fr. |
| `src/net_alpha/web/templates/_portfolio_body.html` (create) | Bundles the four overview panels (no positions table).               |
| `src/net_alpha/web/templates/holdings.html` (create)       | Wraps existing toolbar + positions fragment.                          |
| `src/net_alpha/web/templates/_portfolio_table.html` (modify) | Replace text input with multi-select popover (Alpine).              |
| `src/net_alpha/web/templates/base.html` (modify)           | Add "Holdings" nav link.                                              |
| `src/net_alpha/web/templates/_import_modal.html` (modify)  | Replace native `<input type="file">` with styled button + chip.       |
| `tests/web/test_portfolio_routes.py` (extend)              | `/portfolio/body` smoke; symbol filter; `/portfolio` no positions.    |
| `tests/web/test_holdings_routes.py` (create)               | `/holdings` smoke and nav link.                                       |
| `tests/web/test_imports_routes.py` (extend)                | Modal contains styled "Choose files" button, native input hidden.     |

---

## Task 1: Equal-width equity & allocation panels

CSS-only change. No test needed — pure visual.

**Files:**
- Modify: `src/net_alpha/web/templates/portfolio.html:28`

- [ ] **Step 1: Update grid-template-columns**

Edit `src/net_alpha/web/templates/portfolio.html` line 28, change:

```html
<div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1.55fr;">
```

to:

```html
<div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1fr;">
```

- [ ] **Step 2: Sanity check**

Run: `uv run net-alpha ui --no-browser` then visit `http://127.0.0.1:8000/`. Confirm equity-curve and allocation panels are visually equal width. Stop the server.

- [ ] **Step 3: Commit**

```bash
git add src/net_alpha/web/templates/portfolio.html
git commit -m "feat(web): equalize equity-curve and allocation panel widths"
```

---

## Task 2: Restyle "Choose Files" button in import modal

The current native `<input type="file">` renders nearly invisible on the dark surface. Replace with the same pattern used in `_drop_zone.html`: hidden native input + styled button + file-count chip.

**Files:**
- Modify: `src/net_alpha/web/templates/_import_modal.html:34-40`
- Test: `tests/web/test_imports_routes.py` (extend)

- [ ] **Step 1: Find an existing modal-rendering test to extend**

Run: `grep -n "import-modal\|_import_modal" tests/web/test_imports_routes.py`

If no test renders the modal directly, add the new test in step 2.

- [ ] **Step 2: Write the failing test**

Append to `tests/web/test_imports_routes.py`:

```python
def test_import_modal_uses_styled_choose_files_button(tmp_path):
    """The modal should hide the native file input and expose a styled button."""
    client = _client(tmp_path)
    # Trigger the preview endpoint that renders the modal fragment.
    csv_bytes = b"Date,Action,Symbol,Quantity,Price,Amount\n"
    response = client.post(
        "/imports/preview",
        files={"files": ("x.csv", csv_bytes, "text/csv")},
    )
    assert response.status_code == 200
    html = response.text
    # Native input is hidden, not naked.
    assert 'type="file"' in html
    assert 'class="hidden"' in html
    # Styled button is present and labeled.
    assert ">Choose files<" in html
    # File-count chip is present.
    assert "file-chip" in html
```

If `tests/web/test_imports_routes.py` doesn't already define `_client`, copy the helper from `tests/web/test_portfolio_routes.py` to the top of the file (only if missing).

- [ ] **Step 3: Run the test to verify it fails**

Run: `uv run pytest tests/web/test_imports_routes.py::test_import_modal_uses_styled_choose_files_button -v`

Expected: FAIL with `AssertionError` on `">Choose files<"`.

- [ ] **Step 4: Replace the file-input markup**

Edit `src/net_alpha/web/templates/_import_modal.html`. Replace lines 36-39 (the `<label>` + `<input type="file">` + `<p>` block):

```html
      <div>
        <label class="block label-uc mb-1">Files (re-attach to confirm)</label>
        <input type="file" name="files" accept=".csv" multiple required class="text-sm text-label-2"/>
        <p class="text-xs text-label-3 mt-1">Browser security requires re-attaching the files at submit time.</p>
      </div>
```

with:

```html
      <div>
        <label class="block label-uc mb-1">Files (re-attach to confirm)</label>
        <div class="flex items-center gap-3">
          <button type="button" class="btn-ghost"
                  onclick="this.nextElementSibling.click()">Choose files</button>
          <input type="file" name="files" accept=".csv" multiple required class="hidden"
                 onchange="(function(el){
                   const c = el.files.length;
                   const span = el.parentElement.querySelector('.file-chip');
                   if (c === 0) { span.textContent = 'No files selected'; return; }
                   const names = Array.from(el.files).slice(0, 2).map(f => f.name).join(', ');
                   span.textContent = c + ' file' + (c === 1 ? '' : 's') + ': ' + names + (c > 2 ? ' +' + (c - 2) : '');
                 })(this)"/>
          <span class="file-chip text-[12px] text-label-2">No files selected</span>
        </div>
        <p class="text-xs text-label-3 mt-1">Browser security requires re-attaching the files at submit time.</p>
      </div>
```

- [ ] **Step 5: Run the test to verify it passes**

Run: `uv run pytest tests/web/test_imports_routes.py::test_import_modal_uses_styled_choose_files_button -v`

Expected: PASS.

- [ ] **Step 6: Run the wider import-route test suite to confirm nothing else broke**

Run: `uv run pytest tests/web/test_imports_routes.py tests/web/test_multi_file_upload.py tests/web/test_upload_flow.py -v`

Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/_import_modal.html tests/web/test_imports_routes.py
git commit -m "feat(web): styled Choose Files button + file-count chip in import modal"
```

---

## Task 3: Add `/portfolio/body` bundled fragment

Single endpoint that loads `trades`/`lots`/`prices` once and renders KPIs + equity curve + allocation + wash-watch in one HTML response. Replaces the 5-way page-load fan-out.

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Create: `src/net_alpha/web/templates/_portfolio_body.html`
- Test: `tests/web/test_portfolio_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_portfolio_routes.py`:

```python
def test_portfolio_body_fragment_returns_all_panels(tmp_path):
    """The bundled body fragment renders the four overview panels."""
    client = _client(tmp_path)
    response = client.get("/portfolio/body?period=ytd&account=")
    assert response.status_code == 200
    html = response.text
    # KPIs panel marker (label appears in _portfolio_kpis.html).
    assert "Realized" in html
    assert "Unrealized" in html
    # Equity curve panel.
    assert "Equity curve" in html
    # Wash-watch panel marker (panel head text or empty-state copy).
    assert "wash" in html.lower()
    # Positions table is NOT in the body — it lives on /holdings.
    assert "No open positions" not in html
    assert 'id="portfolio-positions"' not in html
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/web/test_portfolio_routes.py::test_portfolio_body_fragment_returns_all_panels -v`

Expected: FAIL with 404 on `/portfolio/body`.

- [ ] **Step 3: Create the bundled body template**

Create `src/net_alpha/web/templates/_portfolio_body.html` with:

```html
{# Bundled portfolio body: KPIs + equity-curve + allocation + wash-watch.
   Rendered by /portfolio/body in one shot. The positions table lives on
   /holdings now and is NOT included here. #}
<div id="portfolio-kpis" class="mb-4">
  {% include "_portfolio_kpis.html" %}
</div>

<div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1fr;">
  <div id="portfolio-equity" class="panel">
    {% include "_portfolio_equity_curve.html" %}
  </div>
  <div id="portfolio-allocation" class="panel">
    {% include "_portfolio_allocation.html" %}
  </div>
</div>

<div id="portfolio-wash-watch" class="panel mb-4">
  {% include "_portfolio_wash_watch.html" %}
</div>
```

- [ ] **Step 4: Add the `/portfolio/body` route handler**

Add to `src/net_alpha/web/routes/portfolio.py` (after the existing `portfolio_wash_watch_fragment` handler, before end of file):

```python
@router.get("/portfolio/body", response_class=HTMLResponse)
def portfolio_body(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    """Bundled fragment: KPIs + equity-curve + allocation + wash-watch.

    Loads trades/lots/prices ONCE and feeds the existing pure compute
    functions, replacing the 5-way page-load fan-out on /portfolio.
    """
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    year = period_tuple[0] if period_tuple else today.year

    all_trades = repo.all_trades()
    all_lots = repo.all_lots()
    if account:
        scoped_trades = [t for t in all_trades if t.account == account]
        scoped_lots = [lot for lot in all_lots if lot.account == account]
    else:
        scoped_trades = all_trades
        scoped_lots = all_lots
    symbols = sorted({lot.ticker for lot in scoped_lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    snap = svc.last_snapshot()

    kpis = compute_kpis(
        trades=scoped_trades,
        lots=scoped_lots,
        prices=prices,
        period_label=period_label,
        period=period_tuple,
        account=None,  # already filtered above
    )
    wi = compute_wash_impact(
        violations=repo.all_violations(),
        period_label=period_label,
        period=period_tuple,
        account=account or None,
    )
    points = build_equity_curve(
        trades=scoped_trades, year=year, present_unrealized=kpis.period_unrealized
    )
    positions_for_alloc = compute_open_positions(
        trades=scoped_trades,
        lots=scoped_lots,
        prices=prices,
        period=(today.year, today.year + 1),
        account=None,
    )
    allocation = build_allocation(positions=positions_for_alloc, top_n=10)
    wash_rows = recent_loss_closes(
        repo=repo,
        today=today,
        window_days=30,
        account=account or None,
    )

    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_body.html",
        {
            "kpis": kpis,
            "snapshot": snap,
            "wash_impact_total": wi.disallowed_total,
            "wash_violations": wi.violation_count,
            "points": points,
            "year": year,
            "allocation": allocation,
            "rows": wash_rows,
            "window_days": 30,
        },
    )
```

- [ ] **Step 5: Run the test to verify it passes**

Run: `uv run pytest tests/web/test_portfolio_routes.py::test_portfolio_body_fragment_returns_all_panels -v`

Expected: PASS.

- [ ] **Step 6: Run the broader portfolio test suite**

Run: `uv run pytest tests/web/test_portfolio_routes.py tests/web/test_allocation_route.py tests/web/test_wash_watch_route.py -v`

Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/templates/_portfolio_body.html tests/web/test_portfolio_routes.py
git commit -m "feat(web): /portfolio/body bundled fragment"
```

---

## Task 4: Switch portfolio.html to single-fragment load

Replace the 5 individual `hx-get` calls in `portfolio.html` with one call to `/portfolio/body`. This is the change that actually delivers the perf win.

**Files:**
- Modify: `src/net_alpha/web/templates/portfolio.html`
- Test: `tests/web/test_portfolio_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_portfolio_routes.py`:

```python
def test_portfolio_page_uses_single_bundled_fragment(tmp_path):
    """The /portfolio shell should issue ONE hx-get to /portfolio/body, not five."""
    settings = Settings(data_dir=tmp_path)
    engine = get_engine(settings.db_path)
    with engine.begin() as conn:
        conn.execute(text("INSERT INTO accounts(broker, label) VALUES ('Schwab', 'Tax')"))
        conn.execute(
            text(
                "INSERT INTO imports(account_id, csv_filename, csv_sha256, imported_at, trade_count) "
                "VALUES (1, 'x.csv', 'h', '2026-04-26T00:00:00', 0)"
            )
        )
    client = _client(tmp_path)
    response = client.get("/")
    assert response.status_code == 200
    html = response.text
    assert "/portfolio/body" in html
    # The old per-panel page-load triggers should be gone from the shell.
    assert html.count('hx-get="/portfolio/kpis') == 0
    assert html.count('hx-get="/portfolio/equity-curve') == 0
    assert html.count('hx-get="/portfolio/allocation') == 0
    assert html.count('hx-get="/portfolio/wash-watch') == 0
    assert html.count('hx-get="/portfolio/positions') == 0
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/web/test_portfolio_routes.py::test_portfolio_page_uses_single_bundled_fragment -v`

Expected: FAIL — `/portfolio/body` not in HTML.

- [ ] **Step 3: Replace the body block in portfolio.html**

Edit `src/net_alpha/web/templates/portfolio.html`. Replace the block from line 22 (`{% else %}`) through line 44 (`{% endif %}`):

```html
  {% if not imports %}
    {% include "_portfolio_empty_state.html" %}
  {% else %}
    <div id="portfolio-kpis"
         hx-get="/portfolio/kpis?period={{ selected_period }}&account={{ selected_account }}"
         hx-trigger="load" hx-swap="innerHTML"
         class="mb-4"></div>

    <div class="grid gap-3 mb-4" style="grid-template-columns: 1fr 1fr;">
      <div id="portfolio-equity" class="panel"
           hx-get="/portfolio/equity-curve?period={{ selected_period }}&account={{ selected_account }}"
           hx-trigger="load" hx-swap="innerHTML"></div>
      <div id="portfolio-allocation" class="panel"
           hx-get="/portfolio/allocation?account={{ selected_account }}"
           hx-trigger="load" hx-swap="innerHTML"></div>
    </div>

    <div id="portfolio-wash-watch" class="panel mb-4"
         hx-get="/portfolio/wash-watch?account={{ selected_account }}"
         hx-trigger="load" hx-swap="innerHTML"></div>

    <div id="portfolio-positions"
         hx-get="/portfolio/positions?period={{ selected_period }}&account={{ selected_account }}&group_options={{ group_options }}&show=open&page=1"
         hx-trigger="load" hx-swap="innerHTML"></div>
  {% endif %}
```

with:

```html
  {% if not imports %}
    {% include "_portfolio_empty_state.html" %}
  {% else %}
    <div id="portfolio-body"
         hx-get="/portfolio/body?period={{ selected_period }}&account={{ selected_account }}"
         hx-trigger="load" hx-swap="innerHTML"></div>
  {% endif %}
```

- [ ] **Step 4: Run the test to verify it passes**

Run: `uv run pytest tests/web/test_portfolio_routes.py::test_portfolio_page_uses_single_bundled_fragment -v`

Expected: PASS.

- [ ] **Step 5: Run the full portfolio suite**

Run: `uv run pytest tests/web/ -v`

Expected: all PASS. (Per-fragment routes still exist and their tests still pass; only the page-load fan-out changed.)

- [ ] **Step 6: Visual sanity check**

Run: `uv run net-alpha ui --no-browser`. Open `http://127.0.0.1:8000/` and confirm the page renders KPIs, equity, allocation, and wash-watch. Confirm the page-to-paint feels well under 2s. Stop the server.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/portfolio.html tests/web/test_portfolio_routes.py
git commit -m "feat(web): single-fragment load on /portfolio (5x→1x request)"
```

---

## Task 5: Create `/holdings` page route + template + nav link

`/holdings` reuses the existing `/portfolio/positions` fragment for in-page swaps. The page route just renders the toolbar + a `<div hx-get>` that pulls the fragment on load.

**Files:**
- Create: `src/net_alpha/web/routes/holdings.py`
- Create: `src/net_alpha/web/templates/holdings.html`
- Modify: `src/net_alpha/web/app.py`
- Modify: `src/net_alpha/web/templates/base.html`
- Test: `tests/web/test_holdings_routes.py` (create)

- [ ] **Step 1: Write the failing test**

Create `tests/web/test_holdings_routes.py`:

```python
from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import text

from net_alpha.config import Settings
from net_alpha.db.connection import get_engine
from net_alpha.web.app import create_app


def _client(tmp_path):
    return TestClient(create_app(Settings(data_dir=tmp_path)))


def test_holdings_page_returns_200(tmp_path):
    client = _client(tmp_path)
    response = client.get("/holdings")
    assert response.status_code == 200
    # The page wires the existing positions fragment.
    assert "/portfolio/positions" in response.text
    assert 'id="holdings-positions"' in response.text


def test_holdings_page_active_in_nav(tmp_path):
    client = _client(tmp_path)
    response = client.get("/holdings")
    assert response.status_code == 200
    # The Holdings nav link is present and marked active.
    assert ">Holdings<" in response.text
    assert 'class="nav-link active"' in response.text


def test_holdings_link_appears_on_other_pages(tmp_path):
    client = _client(tmp_path)
    response = client.get("/")
    assert response.status_code == 200
    assert ">Holdings<" in response.text
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `uv run pytest tests/web/test_holdings_routes.py -v`

Expected: FAIL with 404 on `/holdings`.

- [ ] **Step 3: Create the holdings router**

Create `src/net_alpha/web/routes/holdings.py`:

```python
from __future__ import annotations

from datetime import date

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse

from net_alpha.db.repository import Repository
from net_alpha.web.dependencies import get_repository

router = APIRouter()


@router.get("/holdings", response_class=HTMLResponse)
def holdings_page(
    request: Request,
    period: str | None = None,
    account: str | None = None,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    imports = repo.list_imports()
    accounts = sorted({imp.account_display for imp in imports})

    today = date.today()
    current_year = today.year
    import_years = {imp.imported_at.year for imp in imports}
    available_years = sorted(import_years | {current_year}, reverse=True)

    selected_period = period or "ytd"
    return request.app.state.templates.TemplateResponse(
        request,
        "holdings.html",
        {
            "imports": imports,
            "accounts": accounts,
            "available_years": available_years,
            "current_year": current_year,
            "selected_period": selected_period,
            "selected_account": account or "",
            "group_options": "merge",
        },
    )
```

- [ ] **Step 4: Create the holdings template**

Create `src/net_alpha/web/templates/holdings.html`:

```html
{% extends "base.html" %}
{% set active_page = 'holdings' %}
{% block title %}Holdings · net-alpha{% endblock %}
{% block topbar_right %}
  {% if accounts %}<span class="pill">{{ accounts|length }} account{% if accounts|length != 1 %}s{% endif %}</span>{% endif %}
  <span class="pill">{{ selected_period|default('YTD')|upper }}</span>
{% endblock %}
{% block content %}
  <div class="flex items-end justify-between flex-wrap gap-3 mb-4">
    <div>
      <h1>Holdings</h1>
      <div class="text-[13px] text-label-2 mt-[3px]">
        {% if selected_account %}{{ selected_account }}{% else %}All accounts{% endif %} ·
        {{ selected_period|default('YTD')|upper }}
      </div>
    </div>
    {% if imports %}{% include "_portfolio_toolbar.html" %}{% endif %}
  </div>

  {% if not imports %}
    {% include "_portfolio_empty_state.html" %}
  {% else %}
    <div id="holdings-positions"
         hx-get="/portfolio/positions?period={{ selected_period }}&account={{ selected_account }}&group_options={{ group_options }}&show=open&page=1"
         hx-trigger="load" hx-swap="innerHTML"></div>
  {% endif %}
{% endblock %}
```

- [ ] **Step 5: Register the holdings router**

Edit `src/net_alpha/web/app.py`. Add to the router-import block (around line 16-18):

```python
from net_alpha.web.routes import calendar, detail, holdings, sim, system, ticker
```

(Insert `holdings` alphabetically.) Then add to the `include_router` block (around line 50-56):

```python
    app.include_router(holdings.router)
```

(Insert near the other `app.include_router(...)` lines.)

- [ ] **Step 6: Add the "Holdings" nav link**

Edit `src/net_alpha/web/templates/base.html`. Replace line 23:

```html
        <a href="/calendar" class="nav-link{% if active_page == 'calendar' %} active{% endif %}">Calendar</a>
```

with:

```html
        <a href="/holdings" class="nav-link{% if active_page == 'holdings' %} active{% endif %}">Holdings</a>
        <a href="/calendar" class="nav-link{% if active_page == 'calendar' %} active{% endif %}">Calendar</a>
```

- [ ] **Step 7: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_holdings_routes.py -v`

Expected: all 3 PASS.

- [ ] **Step 8: Run the full web suite**

Run: `uv run pytest tests/web/ -v`

Expected: all PASS.

- [ ] **Step 9: Commit**

```bash
git add src/net_alpha/web/routes/holdings.py src/net_alpha/web/templates/holdings.html src/net_alpha/web/app.py src/net_alpha/web/templates/base.html tests/web/test_holdings_routes.py
git commit -m "feat(web): /holdings page + nav link"
```

---

## Task 6: Symbol multi-select query param on /portfolio/positions

Replace the `q` substring filter with a `symbols` comma-separated set filter on the existing fragment route. The UI swap comes in Task 7.

**Files:**
- Modify: `src/net_alpha/web/routes/portfolio.py`
- Test: `tests/web/test_portfolio_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_portfolio_routes.py`:

```python
def test_positions_symbols_filter(tmp_path):
    """?symbols=AAPL,MSFT keeps only those tickers (case-insensitive)."""
    client = _client(tmp_path)
    # No data yet — empty list returns. We just check the param is accepted
    # and returns 200; behavior with data is covered in detail tests.
    r = client.get("/portfolio/positions?period=ytd&symbols=aapl,MSFT")
    assert r.status_code == 200


def test_positions_no_q_param(tmp_path):
    """The legacy q substring filter must be gone (replaced by symbols)."""
    client = _client(tmp_path)
    r = client.get("/portfolio/positions?period=ytd")
    assert r.status_code == 200
    # The toolbar markup should NOT include a search input named 'q'.
    assert 'name="q"' not in r.text
    # And the route should not interpolate {{ search_q }} anywhere.
    assert "search_q" not in r.text.lower()
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_portfolio_routes.py::test_positions_symbols_filter tests/web/test_portfolio_routes.py::test_positions_no_q_param -v`

Expected: `test_positions_no_q_param` FAILS — `name="q"` is in current markup.
(`test_positions_symbols_filter` likely passes since extra params are ignored.)

- [ ] **Step 3: Update the route handler signature and filter logic**

Edit `src/net_alpha/web/routes/portfolio.py`. Replace the `portfolio_positions` function definition (around lines 136-194). Change the parameter list from:

```python
    show: str = "open",  # "open" | "all"
    page: int = 1,
    page_size: int = PAGE_SIZE,
    q: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
```

to:

```python
    show: str = "open",  # "open" | "all"
    page: int = 1,
    page_size: int = PAGE_SIZE,
    symbols: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
```

Then replace the `q` filter block:

```python
    if q:
        needle = q.strip().upper()
        if needle:
            rows = [r for r in rows if needle in r.symbol.upper()]
```

with:

```python
    selected_symbols: set[str] = set()
    if symbols:
        selected_symbols = {s.strip().upper() for s in symbols.split(",") if s.strip()}
    if selected_symbols:
        rows = [r for r in rows if r.symbol.upper() in selected_symbols]
```

And replace the template-context `"search_q": q or "",` line with:

```python
            "selected_symbols": sorted(selected_symbols),
            "all_in_scope_symbols": sorted({r.symbol for r in rows} | selected_symbols),
```

(Sort gives deterministic order in the popover.)

- [ ] **Step 4: Update `_portfolio_table.html` to drop the `q` input and accept `selected_symbols`**

Edit `src/net_alpha/web/templates/_portfolio_table.html`. Remove lines 1-3 (the `{% set qs %}` lines that include `&q=`) and replace with:

```html
{# Common HTMX query string for swapping pages/toggle. #}
{% set sym_qs %}{{ selected_symbols|join(',') }}{% endset %}
{% set qs %}period={{ selected_period }}&account={{ selected_account }}&group_options={{ group_options }}&symbols={{ sym_qs|urlencode }}{% endset %}
{% set qs_full %}{{ qs }}&show={{ show }}&page_size={{ page_size }}{% endset %}
```

Then remove the entire `<input type="search" name="q" ...>` block (around lines 20-29) — the popover replaces it in Task 7. Leave a placeholder `<span></span>` for now so the toolbar layout doesn't collapse:

```html
    <span id="symbol-filter-slot"></span>
```

Also update the small status hint that references `search_q`. Change:

```html
    <span class="text-[11px] text-label-2 ml-1">
      {{ total_rows }} {% if show == 'all' %}total{% else %}open{% endif %}
      {% if search_q %}· filter “{{ search_q }}”{% endif %}
      · account: {% if selected_account %}{{ selected_account }}{% else %}all{% endif %}
    </span>
```

to:

```html
    <span class="text-[11px] text-label-2 ml-1">
      {{ total_rows }} {% if show == 'all' %}total{% else %}open{% endif %}
      {% if selected_symbols %}· {{ selected_symbols|length }} symbol{% if selected_symbols|length != 1 %}s{% endif %} filtered{% endif %}
      · account: {% if selected_account %}{{ selected_account }}{% else %}all{% endif %}
    </span>
```

Search the rest of the file for any remaining `search_q` references and remove them.

- [ ] **Step 5: Run the tests**

Run: `uv run pytest tests/web/test_portfolio_routes.py -v`

Expected: PASS.

- [ ] **Step 6: Run the full web suite**

Run: `uv run pytest tests/web/ -v`

Expected: all PASS.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/routes/portfolio.py src/net_alpha/web/templates/_portfolio_table.html tests/web/test_portfolio_routes.py
git commit -m "feat(web): replace ?q= with ?symbols= multi-select filter on /portfolio/positions"
```

---

## Task 7: Multi-select symbol popover UI

The actual popover. Alpine.js component, anchored where the placeholder span is. Single trigger button shows the selection summary; a popover panel has typeahead + checkbox list. "Done" fires the HTMX swap.

**Files:**
- Modify: `src/net_alpha/web/templates/_portfolio_table.html`
- Test: `tests/web/test_holdings_routes.py` (extend)

- [ ] **Step 1: Write the failing test**

Append to `tests/web/test_holdings_routes.py`:

```python
def test_holdings_renders_symbol_multiselect_trigger(tmp_path):
    """The holdings positions fragment should expose a multi-select trigger."""
    client = _client(tmp_path)
    # Fragment endpoint renders the toolbar inline.
    r = client.get("/portfolio/positions?period=ytd")
    assert r.status_code == 200
    html = r.text
    # Trigger button is present.
    assert "Symbols:" in html
    # Alpine state hook for the popover.
    assert "x-data" in html
    # No native search input.
    assert 'name="q"' not in html


def test_holdings_symbol_filter_with_selection_in_url(tmp_path):
    """When ?symbols= is present, the trigger summarizes the selection."""
    client = _client(tmp_path)
    r = client.get("/portfolio/positions?period=ytd&symbols=AAPL,MSFT")
    assert r.status_code == 200
    html = r.text
    # The summary names the selected symbols.
    assert "AAPL" in html
    assert "MSFT" in html
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `uv run pytest tests/web/test_holdings_routes.py::test_holdings_renders_symbol_multiselect_trigger tests/web/test_holdings_routes.py::test_holdings_symbol_filter_with_selection_in_url -v`

Expected: FAIL — "Symbols:" not yet in markup.

- [ ] **Step 3: Replace the slot placeholder with the popover component**

Edit `src/net_alpha/web/templates/_portfolio_table.html`. Replace `<span id="symbol-filter-slot"></span>` with:

```html
    <div x-data="{
           open: false,
           query: '',
           selected: {{ selected_symbols|tojson }},
           all: {{ all_in_scope_symbols|tojson }},
           toggle(s) {
             const i = this.selected.indexOf(s);
             if (i === -1) this.selected.push(s); else this.selected.splice(i, 1);
           },
           filtered() {
             const q = this.query.trim().toUpperCase();
             return q ? this.all.filter(s => s.toUpperCase().includes(q)) : this.all;
           },
           label() {
             if (this.selected.length === 0) return 'Symbols: All';
             if (this.selected.length <= 2) return 'Symbols: ' + this.selected.join(', ');
             return 'Symbols: ' + this.selected.slice(0,2).join(', ') + ' +' + (this.selected.length - 2);
           },
           apply() {
             this.open = false;
             const url = '/portfolio/positions?{{ qs|safe }}'.replace(
               /symbols=[^&]*/, 'symbols=' + encodeURIComponent(this.selected.join(','))
             ) + '&show={{ show }}&page=1&page_size={{ page_size }}';
             htmx.ajax('GET', url, { target: '#holdings-positions', swap: 'innerHTML' });
           },
           clear() { this.selected = []; this.apply(); },
         }"
         class="relative inline-block">
      <button type="button"
              @click="open = !open"
              class="px-2 py-1 text-[12px] rounded-md"
              style="background: var(--color-surface); color: var(--color-text); border: 0.5px solid var(--color-hairline);"
              x-text="label()"></button>
      <div x-show="open" @click.outside="open = false"
           class="absolute z-20 mt-1 left-0 w-64 rounded-md p-2"
           style="background: var(--color-surface); border: 0.5px solid var(--color-hairline); box-shadow: 0 4px 24px rgba(0,0,0,0.4);">
        <input type="text" x-model="query" placeholder="Search…"
               class="w-full px-2 py-1 text-[12px] rounded-md mb-2"
               style="background: var(--color-bg); color: var(--color-text); border: 0.5px solid var(--color-hairline);"/>
        <div class="max-h-56 overflow-y-auto">
          <template x-for="s in filtered()" :key="s">
            <label class="flex items-center gap-2 py-[3px] text-[12px] cursor-pointer">
              <input type="checkbox"
                     :checked="selected.indexOf(s) !== -1"
                     @change="toggle(s)"/>
              <span x-text="s" class="font-mono"></span>
            </label>
          </template>
          <template x-if="filtered().length === 0">
            <div class="text-[11px] text-label-3 py-2 text-center">No matches.</div>
          </template>
        </div>
        <div class="flex justify-end gap-2 pt-2 mt-2" style="border-top: 0.5px solid var(--color-hairline);">
          <button type="button" @click="clear()" class="px-2 py-1 text-[11px] text-label-2 hover:text-text">Clear</button>
          <button type="button" @click="apply()" class="px-2 py-1 text-[11px] rounded-md"
                  style="background: var(--color-accent); color: var(--color-bg);">Done</button>
        </div>
      </div>
    </div>
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `uv run pytest tests/web/test_holdings_routes.py -v`

Expected: all PASS.

- [ ] **Step 5: Run the full web suite**

Run: `uv run pytest tests/web/ -v`

Expected: all PASS.

- [ ] **Step 6: Visual sanity check**

Run: `uv run net-alpha ui --no-browser`. Visit `http://127.0.0.1:8000/holdings`. Confirm:
- The "Symbols: All" trigger button is visible in the toolbar.
- Clicking opens a popover with a search box and checkbox list.
- Selecting two symbols and clicking "Done" filters the table.
- The URL updates with `?symbols=...`.
- Reload preserves the selection.

Stop the server.

- [ ] **Step 7: Commit**

```bash
git add src/net_alpha/web/templates/_portfolio_table.html tests/web/test_holdings_routes.py
git commit -m "feat(web): multi-select symbol filter popover on holdings table"
```

---

## Final verification

- [ ] **Run the full test suite**

Run: `uv run pytest -v`

Expected: all PASS.

- [ ] **Run lint**

Run: `uv run ruff check . && uv run ruff format --check .`

Expected: clean.

- [ ] **Smoke check the running app**

Run: `uv run net-alpha ui --no-browser`. Visit each page:
- `/` (Portfolio) — fast load, equity & allocation equal width.
- `/holdings` — table renders with new toolbar, popover works.
- `/imports` (then click "Re-attach to confirm") — modal shows styled "Choose files" button.
- `/calendar`, `/sim`, `/imports`, `/ticker/<symbol>` — unchanged.

Stop the server.

---

## Self-review notes

- All 5 spec items have at least one task: equal-width (1), Choose Files restyle (2), bundled body (3+4), holdings tab (5), symbols filter (6+7).
- The 5 individual fragment routes (`/portfolio/kpis`, `/portfolio/equity-curve`, `/portfolio/allocation`, `/portfolio/wash-watch`, `/portfolio/positions`) are **kept** for toolbar swap reuse, per spec.
- No type/symbol mismatches between tasks: `selected_symbols` and `all_in_scope_symbols` are introduced together in Task 6 and consumed in Task 7.
- The plan does not cover Spec B (manual trade CRUD) — that is `2026-04-26-manual-trade-crud.md`.
