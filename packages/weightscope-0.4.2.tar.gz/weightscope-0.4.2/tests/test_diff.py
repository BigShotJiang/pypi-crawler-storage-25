"""Smoke tests for diff logic — synthetic tensors, no HF download."""
from __future__ import annotations

from pathlib import Path

import torch
from safetensors.torch import save_file

from weightscope.diff import ModelDiff, diff_models, diff_tensor
from weightscope.report import render_markdown


def test_identical_tensors_are_fully_sparse():
    a = torch.randn(100, 100)
    d = diff_tensor("layer.weight", a, a.clone(), threshold=1e-9)
    assert d.n_changed == 0
    assert d.sparsity == 1.0


def test_random_tensors_are_almost_fully_changed():
    torch.manual_seed(0)
    a = torch.randn(100, 100)
    b = torch.randn(100, 100)
    d = diff_tensor("layer.weight", a, b, threshold=1e-6)
    assert d.n_changed >= 9000  # essentially all 10000 elements differ
    assert d.sparsity < 0.1


def test_lora_like_change_is_99_percent_sparse():
    """LoRA-like: only a few % of weights are perturbed."""
    torch.manual_seed(0)
    a = torch.randn(100, 100)
    b = a.clone()
    mask = torch.rand_like(b) < 0.01
    b = torch.where(mask, b + 0.5, b)
    d = diff_tensor("layer.weight", a, b, threshold=1e-6)
    assert 50 < d.n_changed < 150  # ~1% of 10000
    assert d.sparsity > 0.95


def test_shape_mismatch_treats_as_full_change():
    a = torch.randn(100, 100)
    b = torch.randn(101, 100)
    d = diff_tensor("layer.weight", a, b, threshold=1e-6)
    assert d.n_changed == d.n_params


def test_compressed_size_smaller_than_full_for_sparse():
    torch.manual_seed(0)
    a = torch.randn(1000, 1000)
    b = a.clone()
    mask = torch.rand_like(b) < 0.001  # 0.1% changed
    b = torch.where(mask, b + 0.5, b)
    d = diff_tensor("w", a, b, threshold=1e-6)
    assert d.compressed_bytes < d.full_bytes


def test_diff_pairs_tensors_across_shard_boundaries(tmp_path: Path):
    """Cross-shard lookup smoke.

    Real multi-shard HF models (e.g. Qwen2.5-3B, Llama-3.1-8B) split tensors
    across model-00001-of-00002.safetensors etc. The loader builds a single
    name->file index per model, but we only exercise cross-shard pairing if
    a tensor sits in shard 1 on side A and shard 2 on side B. This test
    constructs that exact asymmetry so a regression in ``diff_models`` or
    ``index_tensors`` can't slip through the synthetic-single-shard tests.
    """
    torch.manual_seed(7)
    w1 = torch.randn(8, 8)
    w2 = torch.randn(8, 8)

    dir_a = tmp_path / "a"
    dir_a.mkdir()
    save_file({"layer.0.weight": w1}, str(dir_a / "model-00001-of-00002.safetensors"))
    save_file({"layer.1.weight": w2}, str(dir_a / "model-00002-of-00002.safetensors"))

    # B has the SAME tensors but grouped differently across shards — layer 1
    # is in shard 1 on B but shard 2 on A. Tiny LoRA-ish perturbation only on
    # layer.0 so we can assert the diff picks up the right magnitudes.
    w1_b = w1.clone()
    w1_b[0, 0] += 0.5
    dir_b = tmp_path / "b"
    dir_b.mkdir()
    save_file({"layer.1.weight": w2}, str(dir_b / "model-00001-of-00002.safetensors"))
    save_file({"layer.0.weight": w1_b}, str(dir_b / "model-00002-of-00002.safetensors"))

    md = diff_models(str(dir_a), str(dir_b), threshold=1e-6)

    assert len(md.tensors) == 2
    assert not md.only_in_a
    assert not md.only_in_b
    by_name = {t.name: t for t in md.tensors}
    assert by_name["layer.0.weight"].n_changed == 1
    assert by_name["layer.1.weight"].n_changed == 0


def test_render_markdown_smoke():
    torch.manual_seed(0)
    a = torch.randn(50, 50)
    b = a.clone()
    b[0, 0] += 1.0
    td = diff_tensor("layer.weight", a, b, threshold=1e-6)
    md = ModelDiff(
        model_a="dummy/a",
        model_b="dummy/b",
        threshold=1e-6,
        tensors=[td],
    )
    report = render_markdown(md)
    assert "Model diff:" in report
    assert "dummy/a" in report
    assert "dummy/b" in report
    assert "layer.weight" in report
