"""Tests for lineage detection.

Uses synthetic safetensors on disk — no HF download, no network.
"""
from __future__ import annotations

from pathlib import Path

import torch
from safetensors.torch import save_file

from weightscope import find_lineage, render_lineage_markdown
from weightscope.lineage import LineageCandidate


def _save(dir_: Path, tensors: dict[str, torch.Tensor]) -> None:
    dir_.mkdir(parents=True, exist_ok=True)
    save_file(tensors, str(dir_ / "model.safetensors"))


def test_lineage_ranks_sparse_parent_first(tmp_path: Path):
    torch.manual_seed(5)
    base = {"w": torch.randn(32, 32, dtype=torch.float32)}

    # The real parent: perturb ~1% of the base (LoRA-style).
    real_parent = {"w": base["w"].clone()}
    mask = torch.rand_like(real_parent["w"]) < 0.01
    real_parent["w"] = real_parent["w"] + mask.float() * 0.5

    # An unrelated candidate: entirely different weights.
    stranger = {"w": torch.randn(32, 32, dtype=torch.float32)}

    target_dir = tmp_path / "target"; _save(target_dir, base)
    parent_dir = tmp_path / "parent"; _save(parent_dir, real_parent)
    stranger_dir = tmp_path / "stranger"; _save(stranger_dir, stranger)

    # Note: find_lineage treats ``target`` as B and each candidate as A.
    # We built base = target and real_parent ~= target, so real_parent has
    # ~99% sparsity vs target.
    ranked = find_lineage(
        target=str(target_dir),
        candidates=[str(stranger_dir), str(parent_dir)],
    )
    assert ranked[0].parent_id == str(parent_dir)
    assert ranked[0].verdict == "derived_from_base"
    assert ranked[0].sparsity >= 0.95
    assert ranked[1].parent_id == str(stranger_dir)
    assert ranked[1].verdict == "independent"


def test_lineage_architecture_mismatch_when_tensors_differ(tmp_path: Path):
    base = {"w": torch.randn(8, 8)}
    target = {"w": base["w"].clone(), "extra.head": torch.randn(4, 4)}
    base_dir = tmp_path / "base"; _save(base_dir, base)
    target_dir = tmp_path / "target"; _save(target_dir, target)
    ranked = find_lineage(target=str(target_dir), candidates=[str(base_dir)])
    assert ranked[0].verdict == "architecture_mismatch"


def test_lineage_marks_failures(tmp_path: Path):
    target = {"w": torch.randn(4, 4)}
    target_dir = tmp_path / "target"; _save(target_dir, target)
    ranked = find_lineage(
        target=str(target_dir),
        candidates=[str(tmp_path / "nonexistent_model_dir")],
    )
    assert ranked[0].verdict == "failed"
    assert ranked[0].error


def test_lineage_verdict_from_diff_sparsity_brackets():
    """Verdict boundaries: >=0.95 derived, >0.01 descendant, else independent."""
    from weightscope.diff import ModelDiff, TensorDiff

    def _md_with_sparsity(s: float) -> ModelDiff:
        # One tensor of 1000 params, chosen changed count to hit target sparsity.
        n_changed = int(round(1000 * (1 - s)))
        td = TensorDiff(name="w", shape=(1000,), n_params=1000,
                        n_changed=n_changed, max_delta=0.01,
                        mean_abs_delta=0.005, dtype="torch.float32")
        return ModelDiff(model_a="a", model_b="b", threshold=1e-6, tensors=[td])

    assert LineageCandidate.from_diff("x", _md_with_sparsity(0.99)).verdict \
        == "derived_from_base"
    assert LineageCandidate.from_diff("x", _md_with_sparsity(0.5)).verdict \
        == "likely_descendant"
    assert LineageCandidate.from_diff("x", _md_with_sparsity(0.02)).verdict \
        == "likely_descendant"
    assert LineageCandidate.from_diff("x", _md_with_sparsity(0.005)).verdict \
        == "independent"


def test_render_lineage_markdown_includes_best_match_headline(tmp_path: Path):
    torch.manual_seed(9)
    base = {"w": torch.randn(16, 16)}
    parent = {"w": base["w"].clone()}  # identical
    base_dir = tmp_path / "target"; _save(base_dir, base)
    parent_dir = tmp_path / "parent"; _save(parent_dir, parent)
    ranked = find_lineage(target=str(base_dir), candidates=[str(parent_dir)])
    report = render_lineage_markdown(str(base_dir), ranked)
    assert "Likely derived from" in report
    assert "Ranking" in report
