"""Tests for the plain-English interpretation layer.

We build ModelDiff instances directly from synthetic TensorDiff stats so
the tests exercise classification logic in isolation — no HF download,
no real tensors.
"""
from __future__ import annotations

import pytest

from weightscope import ModelDiff, TensorDiff, collect_facts, infer, render_interpretation
from weightscope.report import render_markdown


def _td(name: str, n_params: int, n_changed: int, dtype: str = "torch.float32",
        shape: tuple[int, ...] = (0,), max_delta: float = 0.01) -> TensorDiff:
    return TensorDiff(
        name=name,
        shape=shape,
        n_params=n_params,
        n_changed=n_changed,
        max_delta=max_delta,
        mean_abs_delta=max_delta / 2,
        dtype=dtype,
    )


# ---- identical ----------------------------------------------------------

def test_identical_models_get_identical_label():
    md = ModelDiff(
        model_a="a", model_b="b",
        threshold=1e-6,
        tensors=[_td("w", 1000, 0), _td("b", 100, 0)],
    )
    inf = infer(md)
    assert inf.label == "identical"
    assert inf.confidence == "high"
    assert "bit-identical" in inf.headline.lower()


# ---- LoRA-like ----------------------------------------------------------

def test_lora_like_pattern():
    """Attention-focused sparse delta — classic LoRA signature.

    Model has 20 tensors; 99% sparsity overall; all the change sits in two
    attn projections across a few blocks.
    """
    tensors = []
    # Dense MLP layers, completely unchanged
    for i in range(10):
        tensors.append(_td(f"model.layers.{i}.mlp.up_proj.weight", 10_000_000, 0))
        tensors.append(_td(f"model.layers.{i}.mlp.down_proj.weight", 10_000_000, 0))
    # Attention projections, tiny delta on q_proj + v_proj only
    for i in range(10):
        tensors.append(_td(f"model.layers.{i}.self_attn.q_proj.weight",
                           4_000_000, 20_000))
        tensors.append(_td(f"model.layers.{i}.self_attn.v_proj.weight",
                           4_000_000, 20_000))
    md = ModelDiff(model_a="a", model_b="b-lora", threshold=1e-6, tensors=tensors)
    inf = infer(md)
    assert inf.label == "lora_like"
    assert any("sparse" in e.lower() or "99" in e for e in inf.evidence)


# ---- Targeted ------------------------------------------------------------

def test_targeted_fine_tune_when_only_a_subset_moved():
    """Only a handful of tensors have non-zero change — but denser than LoRA."""
    tensors = [_td(f"model.layers.{i}.mlp.up_proj.weight", 1_000_000, 0)
               for i in range(20)]
    # Three tensors fully fine-tuned (100% changed)
    tensors.append(_td("model.lm_head.weight", 500_000, 500_000))
    tensors.append(_td("model.embed_tokens.weight", 500_000, 500_000))
    tensors.append(_td("model.norm.weight", 10_000, 10_000))
    md = ModelDiff(model_a="a", model_b="b", threshold=1e-6, tensors=tensors)
    inf = infer(md)
    assert inf.label == "targeted_fine_tune"
    assert inf.confidence == "medium"


# ---- Continued pretraining ----------------------------------------------

def test_continued_pretraining_touches_all_tensors_with_small_changes():
    """Every tensor nudged, but each only partially."""
    tensors = [
        _td(f"model.layers.{i}.mlp.up_proj.weight",
            1_000_000,
            300_000)  # 30% of each tensor drifts
        for i in range(10)
    ]
    tensors += [
        _td(f"model.layers.{i}.self_attn.q_proj.weight",
            500_000,
            150_000)
        for i in range(10)
    ]
    md = ModelDiff(model_a="a", model_b="b-cpt", threshold=1e-6, tensors=tensors)
    inf = infer(md)
    assert inf.label == "continued_pretraining"
    # Every tensor should be reported as touched.
    assert any("20 of 20" in e or "100.0%" in e for e in inf.evidence)


# ---- Post-training (SFT / DPO from shared base) -------------------------

def test_post_training_when_every_weight_nudged_by_a_little():
    """Every weight moved, but max_delta stays small — classic SFT signature."""
    tensors = [
        _td(f"model.layers.{i}.mlp.up_proj.weight",
            100_000, 99_500, max_delta=0.12)
        for i in range(8)
    ]
    md = ModelDiff(model_a="base", model_b="base-instruct",
                   threshold=1e-6, tensors=tensors)
    inf = infer(md)
    assert inf.label == "post_training"
    assert any("shared initialization" in e.lower() or "post-training" in e.lower()
               for e in inf.evidence + [inf.headline])


# ---- Full retrain --------------------------------------------------------

def test_full_retrain_when_everything_changed_a_lot():
    """Every weight moved AND moved by a lot — independent init, not SFT."""
    tensors = [
        _td(f"layer_{i}.weight", 100_000, 99_500, max_delta=1.5) for i in range(8)
    ]
    md = ModelDiff(model_a="a", model_b="b-retrain", threshold=1e-6, tensors=tensors)
    inf = infer(md)
    assert inf.label == "full_retrain"


# ---- Architecture change dominates --------------------------------------

def test_architecture_change_overrides_sparsity_signal():
    """Even if most weights match, an added/removed tensor flags arch change."""
    tensors = [_td("layer.weight", 1_000_000, 0)]
    md = ModelDiff(
        model_a="a", model_b="b",
        threshold=1e-6,
        tensors=tensors,
        only_in_b=["model.new_head.weight"],
    )
    inf = infer(md)
    assert inf.label == "architecture_change"
    assert inf.confidence == "high"


def test_shape_mismatch_counts_as_architecture_change():
    td = _td("layer.weight", 100, 100, max_delta=float("inf"))
    md = ModelDiff(model_a="a", model_b="b", threshold=1e-6, tensors=[td])
    inf = infer(md)
    assert inf.label == "architecture_change"


# ---- Inconclusive --------------------------------------------------------

def test_empty_diff_is_inconclusive():
    md = ModelDiff(model_a="a", model_b="b", threshold=1e-6, tensors=[])
    inf = infer(md)
    assert inf.label == "inconclusive"


# ---- Facts ---------------------------------------------------------------

def test_facts_cover_arch_and_parameter_count():
    tensors = [_td("w", 1000, 100)]
    md = ModelDiff(model_a="a", model_b="b", threshold=1e-6, tensors=tensors,
                   only_in_b=["new_layer.weight"])
    facts = collect_facts(md)
    titles = {f.title for f in facts}
    assert "Architecture change" in titles
    assert "Parameter footprint" in titles


# ---- Rendering integrates into the main report --------------------------

def test_render_interpretation_contains_headline_and_evidence():
    md = ModelDiff(
        model_a="foo/a", model_b="foo/b",
        threshold=1e-6,
        tensors=[_td("w", 1000, 0)],
    )
    section = render_interpretation(md)
    assert "## Interpretation" in section
    assert "Why we think this" in section


def test_render_markdown_embeds_interpretation():
    md = ModelDiff(
        model_a="foo/a", model_b="foo/b",
        threshold=1e-6,
        tensors=[_td("model.layers.0.self_attn.q_proj.weight", 10_000, 100)],
    )
    report = render_markdown(md)
    assert "## Interpretation" in report
    # Confidence label should be present for the emitted inference.
    assert "confidence:" in report
