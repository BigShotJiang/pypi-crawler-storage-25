"""Plain-English interpretation of a ModelDiff.

The goal: turn the numbers into a story a non-ML engineer can read. We split
that story into two sections:

    Facts       — deterministic observations from the numbers. Always true.
    Inferences  — heuristic classifications with a confidence label and the
                  specific numbers that led to them.

Inferences are deliberately conservative — "looks like a LoRA-style
fine-tune" rather than "is a LoRA." Anyone can check our work because every
inference cites the stats it's reading.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from weightscope.diff import ModelDiff, TensorDiff


# ---- Facts ---------------------------------------------------------------

@dataclass(frozen=True)
class Fact:
    """A statement that is true by construction from the diff numbers."""
    title: str
    detail: str


def _shape_changes(diff: ModelDiff) -> list[TensorDiff]:
    # max_delta==inf is the sentinel we use in diff_tensor for shape mismatch.
    return [t for t in diff.tensors if t.max_delta == float("inf")]


def collect_facts(diff: ModelDiff) -> list[Fact]:
    facts: list[Fact] = []

    renames = getattr(diff, "renames", [])
    if renames:
        sample = renames[0]
        facts.append(Fact(
            title="Name normalization",
            detail=(
                f"{len(renames)} tensor(s) paired across different naming "
                f"conventions (e.g. `{sample[0]}` ↔ `{sample[1]}`). "
                "Wrapper prefixes (`module.`, `_orig_mod.`, `model.`, "
                "`transformer.`) were stripped to match — this is how "
                "re-uploads sometimes differ from the original."
            ),
        ))

    n_a = len(diff.only_in_a)
    n_b = len(diff.only_in_b)
    if n_a or n_b:
        parts = []
        if n_a:
            parts.append(f"{n_a} tensor(s) present in A but removed in B")
        if n_b:
            parts.append(f"{n_b} tensor(s) added in B that weren't in A")
        facts.append(Fact(
            title="Architecture change",
            detail=". ".join(parts) + ".",
        ))

    shape_mism = _shape_changes(diff)
    if shape_mism:
        names = ", ".join(f"`{t.name}`" for t in shape_mism[:3])
        extra = "" if len(shape_mism) <= 3 else f" (and {len(shape_mism) - 3} more)"
        facts.append(Fact(
            title="Shape change",
            detail=(
                f"{len(shape_mism)} tensor(s) have different shapes between A "
                f"and B{extra}: {names}. These are counted as fully changed."
            ),
        ))

    if diff.total_params == 0:
        facts.append(Fact(
            title="Empty comparison",
            detail="No matching tensors were compared. A and B may share no names.",
        ))
        return facts

    pct = (1 - diff.overall_sparsity) * 100
    facts.append(Fact(
        title="Parameter footprint",
        detail=(
            f"{diff.total_params:,} parameters compared across "
            f"{len(diff.tensors):,} tensor(s). {diff.total_changed:,} "
            f"({pct:.2f}%) differ beyond the threshold of "
            f"{diff.threshold:g}."
        ),
    ))

    return facts


# ---- Inferences ----------------------------------------------------------

Confidence = Literal["low", "medium", "high"]
Label = Literal[
    "identical",
    "architecture_change",
    "lora_like",
    "targeted_fine_tune",
    "continued_pretraining",
    "post_training",
    "full_retrain",
    "inconclusive",
]


@dataclass(frozen=True)
class Inference:
    """A heuristic classification with evidence."""
    label: Label
    headline: str              # one-line plain-English summary
    confidence: Confidence
    evidence: list[str]        # bullets citing numbers that led here


# Tensor-name patterns we use to bucket changes by component. Regex rather
# than prefix matching because different uploaders name things differently
# (e.g. "model.layers.0.self_attn.q_proj" vs "layers.0.self_attn.q_proj").
_ATTN_RE = re.compile(r"(self_)?attn|attention|(q|k|v|o|qkv)_proj", re.IGNORECASE)
_MLP_RE = re.compile(r"\b(mlp|ffn|feed_forward|gate_proj|up_proj|down_proj|fc\d?)\b", re.IGNORECASE)
_EMBED_RE = re.compile(r"(embed|wte|wpe|tok_embeddings|position_embeddings)", re.IGNORECASE)
_NORM_RE = re.compile(r"(layer[_]?norm|rms[_]?norm|\.ln_|ln[12]|post_attention_layernorm)", re.IGNORECASE)


def _classify_tensor(name: str) -> str:
    if _ATTN_RE.search(name):
        return "attn"
    if _MLP_RE.search(name):
        return "mlp"
    if _EMBED_RE.search(name):
        return "embed"
    if _NORM_RE.search(name):
        return "norm"
    return "other"


@dataclass
class _Bucket:
    n_params: int = 0
    n_changed: int = 0
    n_tensors: int = 0
    n_touched_tensors: int = 0  # tensors with at least one changed param


def _bucket_stats(diff: ModelDiff) -> dict[str, _Bucket]:
    out: dict[str, _Bucket] = {
        k: _Bucket() for k in ("attn", "mlp", "embed", "norm", "other")
    }
    for t in diff.tensors:
        b = out[_classify_tensor(t.name)]
        b.n_params += t.n_params
        b.n_changed += t.n_changed
        b.n_tensors += 1
        if t.n_changed > 0:
            b.n_touched_tensors += 1
    return out


def _pct(changed: int, total: int) -> float:
    if total <= 0:
        return 0.0
    return (changed / total) * 100


def _top_affected(diff: ModelDiff, k: int = 3) -> list[tuple[str, float]]:
    """Return up to k (name, pct-changed) for the most-touched tensors."""
    entries = [
        (t.name, _pct(t.n_changed, t.n_params))
        for t in diff.tensors
        if t.n_params > 0
    ]
    entries.sort(key=lambda nv: nv[1], reverse=True)
    return entries[:k]


def infer(diff: ModelDiff) -> Inference:
    """Pick the single best-fitting label for the diff, with evidence."""
    if diff.total_params == 0:
        return Inference(
            label="inconclusive",
            headline="No matching tensors — nothing to interpret.",
            confidence="low",
            evidence=["0 tensors were compared between A and B."],
        )

    overall_changed_pct = _pct(diff.total_changed, diff.total_params)

    # Exact match: overrides everything else.
    if diff.total_changed == 0 and not diff.only_in_a and not diff.only_in_b:
        return Inference(
            label="identical",
            headline="A and B are bit-identical across every compared tensor.",
            confidence="high",
            evidence=[
                f"0 of {diff.total_params:,} parameters differ beyond threshold "
                f"{diff.threshold:g}.",
                f"No tensors are present in only one side "
                f"({len(diff.only_in_a)} / {len(diff.only_in_b)}).",
            ],
        )

    # Architecture change dominates when tensors are added/removed OR shapes
    # mismatch. We still report a secondary signal if many weights are close.
    if diff.only_in_a or diff.only_in_b or _shape_changes(diff):
        parts = []
        if diff.only_in_a:
            parts.append(f"{len(diff.only_in_a)} tensor(s) removed from A")
        if diff.only_in_b:
            parts.append(f"{len(diff.only_in_b)} tensor(s) added in B")
        n_shape = len(_shape_changes(diff))
        if n_shape:
            parts.append(f"{n_shape} shape mismatch(es)")
        return Inference(
            label="architecture_change",
            headline=(
                "B is not a weight-only update of A — the model architecture "
                "itself changed."
            ),
            confidence="high",
            evidence=[
                "; ".join(parts) + ".",
                f"{overall_changed_pct:.2f}% of matching-shape parameters also "
                "differ, but the architectural delta is the dominant signal.",
            ],
        )

    buckets = _bucket_stats(diff)
    top3 = _top_affected(diff, 3)
    n_tensors = max(len(diff.tensors), 1)
    attn_pct = _pct(buckets["attn"].n_changed, max(buckets["attn"].n_params, 1))
    mlp_pct = _pct(buckets["mlp"].n_changed, max(buckets["mlp"].n_params, 1))

    # Heuristic: LoRA-like. The real signal is not "few tensors touched" —
    # LoRA updates every attention block across the depth, so lots of tensors
    # see changes. Instead: MLP is essentially untouched, attention sees
    # changes, and each touched tensor is itself sparse (a LoRA merge only
    # nudges a tiny fraction of each matrix).
    touched_tensors = [t for t in diff.tensors if t.n_changed > 0]
    mean_internal_sparsity = (
        sum(1 - (t.n_changed / max(t.n_params, 1)) for t in touched_tensors)
        / max(len(touched_tensors), 1)
    ) if touched_tensors else 1.0
    if (
        diff.overall_sparsity >= 0.98
        and mlp_pct < 0.05              # MLP effectively untouched
        and attn_pct > mlp_pct          # attention is where the change is
        and mean_internal_sparsity >= 0.95  # each touched tensor is sparse
    ):
        names = ", ".join(f"`{n}` ({v:.1f}%)" for n, v in top3)
        return Inference(
            label="lora_like",
            headline=(
                "Looks like a LoRA or adapter-style fine-tune — attention "
                "projections drifted a little, MLP stayed put."
            ),
            confidence="high" if mlp_pct == 0 else "medium",
            evidence=[
                f"{diff.overall_sparsity * 100:.2f}% of parameters are "
                f"unchanged (LoRA deltas are typically >99% sparse).",
                f"MLP weights are {'untouched' if mlp_pct == 0 else f'{mlp_pct:.3f}% changed'}; "
                f"attention weights are {attn_pct:.3f}% changed.",
                f"Among the {len(touched_tensors)} touched tensors, the "
                f"average internal sparsity is "
                f"{mean_internal_sparsity * 100:.2f}% — consistent with a "
                "low-rank update.",
                f"Most-touched tensors: {names}.",
            ],
        )

    # Heuristic: targeted fine-tune — fewer than half the tensors touched,
    # and sparsity moderate-to-high. Not obviously LoRA, not a full retrain.
    touched = sum(1 for t in diff.tensors if t.n_changed > 0)
    touched_frac = touched / n_tensors
    if diff.overall_sparsity >= 0.5 and touched_frac < 0.5:
        names = ", ".join(f"`{n}` ({v:.1f}%)" for n, v in top3)
        return Inference(
            label="targeted_fine_tune",
            headline=(
                "Looks like a targeted fine-tune — only a subset of tensors "
                "changed."
            ),
            confidence="medium",
            evidence=[
                f"{touched} of {n_tensors} tensors have at least one "
                f"changed parameter ({touched_frac * 100:.1f}%).",
                f"Overall sparsity: {diff.overall_sparsity * 100:.2f}%.",
                f"Most-touched tensors: {names}.",
            ],
        )

    # Heuristic: continued pretraining — almost every tensor touched, but
    # sparsity stays above ~50% (i.e. not a random reset).
    if diff.overall_sparsity >= 0.25 and touched_frac >= 0.8:
        return Inference(
            label="continued_pretraining",
            headline=(
                "Looks like continued pretraining — most tensors drifted, but "
                "individual parameters mostly stayed close to their original "
                "values."
            ),
            confidence="medium",
            evidence=[
                f"{touched} of {n_tensors} tensors changed "
                f"({touched_frac * 100:.1f}%).",
                f"Overall sparsity: {diff.overall_sparsity * 100:.2f}% — "
                "not a clean reset, which would be near-0%.",
                f"Attention changed {attn_pct:.2f}%, MLP {mlp_pct:.2f}%, "
                f"embed {_pct(buckets['embed'].n_changed, max(buckets['embed'].n_params, 1)):.2f}%.",
            ],
        )

    # Fallback: near-universal change. Distinguish full post-training (SFT /
    # DPO / RLHF from a common base) from true independent retrain. SFT nudges
    # every weight but the nudges stay small; independent init gives deltas on
    # the order of the weight magnitudes themselves (typically >>0.5).
    if overall_changed_pct >= 90:
        finite_max_deltas = sorted(
            t.max_delta for t in diff.tensors
            if t.n_params > 0 and t.max_delta != float("inf")
        )
        median_max_delta = (
            finite_max_deltas[len(finite_max_deltas) // 2]
            if finite_max_deltas else float("inf")
        )
        if median_max_delta < 0.5:
            return Inference(
                label="post_training",
                headline=(
                    "Looks like full-parameter post-training (SFT / DPO / "
                    "continued training) from a common base — every weight "
                    "moved, but only by a little."
                ),
                confidence="medium" if overall_changed_pct < 99 else "high",
                evidence=[
                    f"{overall_changed_pct:.2f}% of parameters changed beyond "
                    f"threshold {diff.threshold:g}.",
                    f"Median per-tensor max delta is {median_max_delta:.4g} — "
                    "small relative to typical weight magnitudes, consistent "
                    "with gradient updates from a shared initialization.",
                    f"Attention changed {attn_pct:.2f}%, MLP {mlp_pct:.2f}%, "
                    f"embed {_pct(buckets['embed'].n_changed, max(buckets['embed'].n_params, 1)):.2f}%.",
                ],
            )
        return Inference(
            label="full_retrain",
            headline=(
                "Looks like a full retrain or independently trained model — "
                "almost every parameter moved, and moved a lot."
            ),
            confidence="medium" if overall_changed_pct < 99 else "high",
            evidence=[
                f"{overall_changed_pct:.2f}% of parameters changed beyond "
                f"threshold {diff.threshold:g}.",
                f"Median per-tensor max delta is {median_max_delta:.4g} — "
                "on the order of weight magnitudes themselves, consistent "
                "with independent initialization rather than shared ancestry.",
                f"Attention changed {attn_pct:.2f}%, MLP {mlp_pct:.2f}%, "
                f"embed {_pct(buckets['embed'].n_changed, max(buckets['embed'].n_params, 1)):.2f}%.",
            ],
        )

    # Nothing matched cleanly.
    return Inference(
        label="inconclusive",
        headline=(
            "The change pattern doesn't match any of our standard profiles "
            "(LoRA, targeted, continued pretraining, full retrain)."
        ),
        confidence="low",
        evidence=[
            f"Overall sparsity: {diff.overall_sparsity * 100:.2f}%.",
            f"Touched tensors: {touched} of {n_tensors} "
            f"({touched_frac * 100:.1f}%).",
            f"Attention {attn_pct:.2f}%, MLP {mlp_pct:.2f}%.",
        ],
    )


# ---- Rendering -----------------------------------------------------------

def render_interpretation(diff: ModelDiff) -> str:
    """Markdown section: Interpretation (Facts + one Inference)."""
    facts = collect_facts(diff)
    inference = infer(diff)

    lines: list[str] = []
    lines.append("## Interpretation")
    lines.append("")
    lines.append(f"> **{inference.headline}**")
    lines.append(f"> *(classification: `{inference.label}`, "
                 f"confidence: **{inference.confidence}**)*")
    lines.append("")

    if facts:
        lines.append("### Facts")
        lines.append("")
        for f in facts:
            lines.append(f"- **{f.title}.** {f.detail}")
        lines.append("")

    lines.append("### Why we think this")
    lines.append("")
    for ev in inference.evidence:
        lines.append(f"- {ev}")
    lines.append("")

    return "\n".join(lines)
