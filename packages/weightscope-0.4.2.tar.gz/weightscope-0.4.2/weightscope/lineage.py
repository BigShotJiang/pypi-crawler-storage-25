"""Model-lineage detection.

Given a target model B and a list of candidate parents, diff each candidate
against B and rank by overall sparsity. A high-sparsity match means most of
B's weights are still A's weights — so A is very likely B's base.

This is deliberately simple. It does NOT try to search HuggingFace for
candidates — the user provides them. A public registry + parameter-count
pre-filter can come later as a lookup service; the CLI stays HF-agnostic.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal

from weightscope.diff import ModelDiff, diff_models


LineageVerdict = Literal[
    "derived_from_base",      # sparsity >= 0.95 — B is A + small delta (LoRA-like)
    "likely_descendant",      # arch matches AND sparsity > ~1% — shared ancestry,
                              # but heavy post-training / fine-tuning
    "independent",            # arch matches but ~no shared weights
    "architecture_mismatch",  # tensors added/removed/shape-changed
    "failed",                 # diff raised
]


@dataclass
class LineageCandidate:
    parent_id: str
    verdict: LineageVerdict
    sparsity: float                # 0.0 .. 1.0; -1 if diff failed
    total_params: int
    total_changed: int
    only_in_a: int                 # tensors in candidate but not in target
    only_in_b: int                 # tensors in target but not in candidate
    error: str | None = None       # set when verdict == "failed"

    @classmethod
    def from_diff(cls, parent_id: str, md: ModelDiff) -> "LineageCandidate":
        has_arch_change = bool(md.only_in_a or md.only_in_b)
        sparsity = md.overall_sparsity
        verdict: LineageVerdict
        if has_arch_change:
            verdict = "architecture_mismatch"
        elif sparsity >= 0.95:
            verdict = "derived_from_base"
        elif sparsity > 0.01:
            # Architecture matches exactly and at least 1% of weights are
            # still identical (well above chance for fp16/bf16 at threshold
            # 1e-6). That's post-training / continued pretraining on top of
            # this base — a clear descendant, just not a light touch.
            verdict = "likely_descendant"
        else:
            verdict = "independent"
        return cls(
            parent_id=parent_id,
            verdict=verdict,
            sparsity=sparsity,
            total_params=md.total_params,
            total_changed=md.total_changed,
            only_in_a=len(md.only_in_a),
            only_in_b=len(md.only_in_b),
        )

    @classmethod
    def failed(cls, parent_id: str, error: str) -> "LineageCandidate":
        return cls(
            parent_id=parent_id,
            verdict="failed",
            sparsity=-1.0,
            total_params=0,
            total_changed=0,
            only_in_a=0,
            only_in_b=0,
            error=error,
        )


def find_lineage(
    target: str,
    candidates: list[str],
    threshold: float = 1e-6,
    cache_dir: str | None = None,
    progress: Callable[[int, str], None] | None = None,
) -> list[LineageCandidate]:
    """Rank candidates by how likely each is to be the parent of ``target``.

    Returns the list sorted best-match-first. Failed candidates go to the
    end with verdict ``failed`` and ``error`` populated.
    """
    out: list[LineageCandidate] = []
    for i, cand in enumerate(candidates, start=1):
        try:
            md = diff_models(cand, target, threshold=threshold, cache_dir=cache_dir)
            out.append(LineageCandidate.from_diff(cand, md))
        except Exception as e:  # noqa: BLE001 — we want to continue past any error
            out.append(LineageCandidate.failed(cand, str(e)))
        if progress is not None:
            progress(i, cand)
    # Successful candidates first, ranked by sparsity desc; failures last.
    out.sort(key=lambda c: (c.verdict == "failed", -c.sparsity))
    return out


def render_lineage_markdown(target: str, candidates: list[LineageCandidate]) -> str:
    """Markdown report of a lineage ranking."""
    lines: list[str] = []
    lines.append(f"# Lineage of `{target}`")
    lines.append("")
    ok = [c for c in candidates if c.verdict != "failed"]
    best = ok[0] if ok else None
    if best is None:
        lines.append("> **No candidate could be compared against the target.**")
    elif best.verdict == "derived_from_base":
        lines.append(
            f"> **Likely derived from `{best.parent_id}`** — "
            f"{best.sparsity * 100:.2f}% of parameters unchanged."
        )
    elif best.verdict == "likely_descendant":
        lines.append(
            f"> **Likely a descendant of `{best.parent_id}`** — "
            f"architecture matches exactly and {best.sparsity * 100:.2f}% "
            "of weights survived unchanged, consistent with post-training "
            "(SFT / DPO / continued pretraining) on that base."
        )
    elif best.verdict == "architecture_mismatch":
        lines.append(
            f"> **Architecture differs from every candidate.** Best partial "
            f"overlap with `{best.parent_id}` "
            f"({best.sparsity * 100:.2f}% sparsity), but tensor sets do not "
            "match — this is not a simple parent."
        )
    else:
        lines.append(
            f"> **Looks independent of all candidates.** Best sparsity "
            f"against `{best.parent_id}` was only "
            f"{best.sparsity * 100:.2f}%."
        )
    lines.append("")
    lines.append("## Ranking")
    lines.append("")
    lines.append("| Rank | Candidate | Sparsity | Changed | Verdict |")
    lines.append("|---:|---|---:|---:|---|")
    for i, c in enumerate(candidates, start=1):
        if c.verdict == "failed":
            lines.append(
                f"| {i} | `{c.parent_id}` | — | — | failed: {c.error or 'error'} |"
            )
        else:
            pct = (1 - c.sparsity) * 100
            lines.append(
                f"| {i} | `{c.parent_id}` | {c.sparsity * 100:.2f}% | "
                f"{c.total_changed:,} / {c.total_params:,} ({pct:.2f}%) | "
                f"`{c.verdict}` |"
            )
    lines.append("")
    return "\n".join(lines)
