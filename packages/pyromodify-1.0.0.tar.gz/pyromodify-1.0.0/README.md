# Pyrogram

Telegram MTProto API framework for Python.

Elegant, modern, and asynchronous framework for users and bots.

## What This Fork Is

This project is a mix of Pyrogram + Pyromod, with latest features from Telegram Bot API.

## Example

```python
from pyrogram import Client, filters

app = Client("my_account")


@app.on_message(filters.private)
async def hello(client, message):
	await message.reply("Hello from Pyrogram!")


app.run()
```

## Key Points

- Async-first framework (sync usage also possible)
- Simple API with access to advanced Telegram features
- Type-hinted methods and models
- Supports both user accounts and bots

## Install

> **Note**: This package is not yet available on PyPI. Installation is done via Git.

```bash
pip install git+https://github.com/Snowball-01/Pyromodify.git
```