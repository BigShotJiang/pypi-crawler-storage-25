class ListenerStopped(Exception):
    pass