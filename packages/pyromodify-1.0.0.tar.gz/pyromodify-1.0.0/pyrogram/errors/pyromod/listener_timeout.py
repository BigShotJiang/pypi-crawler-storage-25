class ListenerTimeout(Exception):
    pass