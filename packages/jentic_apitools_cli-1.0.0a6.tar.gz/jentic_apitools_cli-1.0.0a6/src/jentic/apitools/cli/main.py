"""
Command-line interface for Jentic API Tools.

This module provides a full-featured CLI for scoring, importing,
validating, and repairing OpenAPI specifications.
"""

import click

from jentic.apitools.cli.helpers import quiet_option


__all__ = ["cli"]


@click.group()
@click.version_option(version="1.0.0-alpha.1")
def cli() -> None:
    """Jentic API Tools - OpenAPI specification analysis and repair."""
    pass


@cli.command(name="bulk-rescore")
@click.argument("local_repo_path", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--github-repo-url",
    default="https://github.com/jentic/jentic-public-apis",
    help="GitHub repository URL.",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False),
    default=None,
    help="Output directory for rescore results (defaults to __data__/rescore_<datetime>).",
)
@click.option(
    "--github-repo-branch",
    default="main",
    help="GitHub repository branch.",
)
@click.option(
    "--base-dir",
    default="apis/openapi",
    help="Base directory for OpenAPI specs within the repo.",
)
@click.option(
    "--max-iterations",
    type=int,
    default=None,
    help="Maximum number of APIs to process (for testing).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Run without copying results to the local repo.",
)
def bulk_rescore_cmd(
    local_repo_path: str,
    github_repo_url: str,
    output_dir: str | None,
    github_repo_branch: str,
    base_dir: str,
    max_iterations: int | None,
    dry_run: bool,
) -> None:
    """Bulk rescore all OpenAPI specs in a local repository clone."""
    import sys
    from pathlib import Path

    from jentic.apitools.cli.helpers import (
        EXIT_RUNTIME_ERROR,
        validate_llm_credentials,
        warn_npx_not_found,
    )
    from jentic.apitools.pipelines.bulk_rescore import BulkRescoreConfig, bulk_rescore

    warn_npx_not_found()

    try:
        validate_llm_credentials()
    except click.UsageError as exc:
        click.echo(str(exc), err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    config = BulkRescoreConfig(
        local_repo_path=Path(local_repo_path),
        github_repo_url=github_repo_url,
        output_dir=Path(output_dir) if output_dir else None,
        github_repo_branch=github_repo_branch,
        base_dir=base_dir,
        max_iterations=max_iterations,
        dry_run=dry_run,
    )
    result = bulk_rescore(config)
    click.echo(
        f"Bulk rescore complete: {result.succeeded}/{result.total} succeeded, {result.failed} failed"
    )
    if result.report_path:
        click.echo(f"Report: {result.report_path}")


@cli.command(name="recalculate-scores")
@click.argument("local_repo_path", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--base-dir",
    default="apis/openapi",
    help="Base directory for OpenAPI specs within the repo.",
)
def recalculate_scores_cmd(local_repo_path: str, base_dir: str) -> None:
    """Recalculate scores.json from all scorecard.json files in a local repository clone."""
    from pathlib import Path

    from jentic.apitools.pipelines.bulk_rescore import recalculate_scores

    scores = recalculate_scores(Path(local_repo_path), base_dir)
    click.echo(f"Wrote {len(scores)} entries to {Path(local_repo_path) / base_dir / 'scores.json'}")


@cli.command(name="rebuild-scores-json")
@click.argument("local_repo_path", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--base-dir",
    default="apis/openapi",
    help="Base directory for OpenAPI specs within the repo.",
)
def rebuild_scores_json_cmd(local_repo_path: str, base_dir: str) -> None:
    """Rebuild scores.json from all scorecard.json files in a local repository clone."""
    from pathlib import Path

    from jentic.apitools.pipelines.repo_tools import rebuild_scores_json

    scores = rebuild_scores_json(
        Path(local_repo_path),
        base_dir=base_dir,
    )
    click.echo(f"Wrote {len(scores)} entries to {Path(local_repo_path) / base_dir / 'scores.json'}")


@cli.command(name="rebuild-apis-json")
@click.argument("local_repo_path", type=click.Path(exists=True, file_okay=False))
@click.option(
    "--base-dir",
    default="apis/openapi",
    help="Base directory for OpenAPI specs within the repo.",
)
@click.option(
    "--github-repo-url",
    default="https://github.com/jentic/jentic-public-apis",
    help="GitHub repository URL.",
)
@click.option(
    "--github-repo-branch",
    default="main",
    help="GitHub repository branch.",
)
def rebuild_apis_json_cmd(
    local_repo_path: str, base_dir: str, github_repo_url: str, github_repo_branch: str
) -> None:
    """Rebuild apis.json from all version-level apis.json files in a local repository clone."""
    from pathlib import Path

    from jentic.apitools.pipelines.repo_tools import rebuild_apis_json

    root = rebuild_apis_json(
        Path(local_repo_path),
        github_repo_url=github_repo_url,
        github_repo_branch=github_repo_branch,
        base_dir=base_dir,
    )
    entry_count = len(root.get("include", []))
    click.echo(
        f"Wrote {entry_count} include entries to {Path(local_repo_path) / base_dir / 'apis.json'}"
    )


# ---------------------------------------------------------------------------
# analyze command
# ---------------------------------------------------------------------------


@cli.command(name="analyze")
@click.argument("spec")
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["json", "text"]),
    default="json",
    help="Output format (default: json).",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Write output to FILE instead of stdout.",
)
@click.option(
    "--stdin-filepath",
    default=None,
    help="Virtual filepath when reading from stdin (for format detection).",
)
@click.option(
    "--base-url",
    default=None,
    help="Base URL for resolving references. Defaults to the spec URL.",
)
@click.option(
    "--enable-llm-analysis",
    is_flag=True,
    default=False,
    help="Enable LLM-based semantic analysis.",
)
@click.option(
    "--fail-on",
    type=click.Choice(["error", "warn", "info", "hint", "none"]),
    default="none",
    help="Exit with code 2 if any diagnostic meets or exceeds this severity.",
)
@quiet_option
def analyze_cmd(
    spec: str,
    output_format: str,
    output: str | None,
    stdin_filepath: str | None,
    base_url: str | None,
    enable_llm_analysis: bool,
    fail_on: str,
) -> None:
    """Analyze an OpenAPI specification and produce validation diagnostics.

    SPEC can be a local file path, an HTTP(S) URL, or '-' for stdin.
    When using stdin, pass --stdin-filepath to hint the file format.
    """
    import json
    import sys

    from jentic.apitools.analyze.openapi_analyzer import OpenAPIAnalyzer
    from jentic.apitools.cli.helpers import (
        EXIT_POLICY_FAILURE,
        EXIT_RUNTIME_ERROR,
        check_fail_on,
        count_diagnostics_by_severity,
        format_diagnostics_text,
        resolve_spec_input,
        serialize_diagnostics,
        warn_npx_not_found,
        write_output,
    )
    from jentic.apitools.common.models import DiagnosticTarget

    warn_npx_not_found()

    temp_path = None
    try:
        spec_url, temp_path = resolve_spec_input(spec, stdin_filepath)
    except click.BadParameter as exc:
        click.echo(str(exc), err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    input_name = stdin_filepath or spec
    resolved_base_url = base_url or spec_url

    if enable_llm_analysis:
        from jentic.apitools.cli.helpers import validate_llm_credentials

        try:
            validate_llm_credentials()
        except click.UsageError as exc:
            click.echo(str(exc), err=True)
            sys.exit(EXIT_RUNTIME_ERROR)

    try:
        analyzer = OpenAPIAnalyzer()
        diagnostics = analyzer.analyze(
            spec_url,
            base_url=resolved_base_url,
            target=DiagnosticTarget.IMPORTED_SPEC,
            enable_llm_analysis=enable_llm_analysis,
        )
    except Exception as exc:
        click.echo(f"Analysis failed: {exc}", err=True)
        sys.exit(EXIT_RUNTIME_ERROR)
    finally:
        if temp_path and temp_path.exists():
            temp_path.unlink()

    serialized = serialize_diagnostics(diagnostics)
    counts = count_diagnostics_by_severity(serialized)

    if output_format == "text":
        text = format_diagnostics_text(serialized, input_name)
        write_output(text, output)
    else:
        result = {
            "input": input_name,
            "diagnostics": serialized,
            "summary": {
                "errors": counts.get("error", 0),
                "warnings": counts.get("warning", 0),
                "informations": counts.get("information", 0),
                "hints": counts.get("hint", 0),
                "total": len(serialized),
            },
        }
        write_output(json.dumps(result, indent=2), output)

    if check_fail_on(serialized, fail_on):
        sys.exit(EXIT_POLICY_FAILURE)


# ---------------------------------------------------------------------------
# score command
# ---------------------------------------------------------------------------


@cli.command(name="score")
@click.argument("spec")
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["json", "text"]),
    default="json",
    help="Output format (default: json).",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Write output to FILE instead of stdout.",
)
@click.option(
    "--stdin-filepath",
    default=None,
    help="Virtual filepath when reading from stdin (for format detection).",
)
@click.option(
    "--enable-llm-analysis",
    is_flag=True,
    default=False,
    help="Enable LLM-based semantic analysis.",
)
@click.option(
    "--include-diagnostics",
    is_flag=True,
    default=False,
    help="Include diagnostics in score output.",
)
@click.option(
    "--skip-bundle",
    is_flag=True,
    default=False,
    help="Skip bundling and score the input spec directly.",
)
@click.option(
    "--label",
    default=None,
    help="Vendor/API label (e.g. 'acme.com/main'). Mutually exclusive with --vendor.",
)
@click.option(
    "--vendor",
    default=None,
    help="Vendor name (e.g. 'acme.com'). Combined with --api to form the label.",
)
@click.option(
    "--api",
    default=None,
    help="API name (default: 'main'). Requires --vendor.",
)
@click.option(
    "--min-score",
    type=float,
    default=None,
    help="Exit with code 2 if the overall score is below this threshold.",
)
@click.option("--original-url", default=None, help="Original spec URL for provenance tracking.")
@click.option("--api-id", default=None, help="Logical API identifier.")
@click.option("--api-version-id", default=None, help="Logical API version identifier.")
@click.option("--canonical-source-url", default=None, help="Canonical source URL for metadata.")
@click.option(
    "--canonical-artifacts-base-url",
    default="https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/apis/openapi",
    help="Canonical base URL for raw artifacts.",
)
@click.option(
    "--canonical-artifacts-base-url-ui",
    default="https://github.com/jentic/jentic-public-apis/tree/main/apis/openapi",
    help="Canonical base URL for UI artifact links.",
)
@quiet_option
def score_cmd(
    spec: str,
    output_format: str,
    output: str | None,
    stdin_filepath: str | None,
    enable_llm_analysis: bool,
    include_diagnostics: bool,
    skip_bundle: bool,
    label: str | None,
    vendor: str | None,
    api: str | None,
    min_score: float | None,
    original_url: str | None,
    api_id: str | None,
    api_version_id: str | None,
    canonical_source_url: str | None,
    canonical_artifacts_base_url: str | None,
    canonical_artifacts_base_url_ui: str | None,
) -> None:
    """Calculate the AI-readiness score for an OpenAPI specification.

    SPEC can be a local file path, an HTTP(S) URL, or '-' for stdin.
    When using stdin, pass --stdin-filepath to hint the file format.
    """
    import json
    import sys
    import tempfile

    from jentic.apitools.cli.helpers import (
        EXIT_POLICY_FAILURE,
        EXIT_RUNTIME_ERROR,
        format_score_text,
        resolve_label,
        resolve_spec_input,
        warn_npx_not_found,
        write_output,
    )

    warn_npx_not_found()

    from jentic.apitools.common.models import (
        OASJsonRequest,
        OASProcessConfiguration,
        OASRequestMeta,
        SpecSourceUrl,
    )
    from jentic.apitools.pipelines import score_openapi

    try:
        derived_label = resolve_label(label, vendor, api, stdin_filepath or spec)
    except click.UsageError as exc:
        click.echo(str(exc), err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    temp_input = None
    try:
        spec_url, temp_input = resolve_spec_input(spec, stdin_filepath)
    except click.BadParameter as exc:
        click.echo(str(exc), err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    # Default original_url to the raw SPEC arg if it's an HTTP URL
    resolved_original_url = original_url
    if not resolved_original_url and spec.startswith(("http://", "https://")):
        resolved_original_url = spec

    if enable_llm_analysis:
        from jentic.apitools.cli.helpers import validate_llm_credentials

        try:
            validate_llm_credentials()
        except click.UsageError as exc:
            click.echo(str(exc), err=True)
            sys.exit(EXIT_RUNTIME_ERROR)

    process_config = OASProcessConfiguration(
        enable_llm_analysis=enable_llm_analysis,
        include_diagnostics_in_score=include_diagnostics,
        skip_bundle=skip_bundle,
    )

    with tempfile.TemporaryDirectory(prefix="jentic-score-") as output_dir:
        oas_request = OASJsonRequest(
            spec=SpecSourceUrl(kind="url", url=spec_url),
            meta=OASRequestMeta(
                label=derived_label,
                output_dir=output_dir,
                original_url=resolved_original_url,
                api_id=api_id,
                api_version_id=api_version_id,
                canonical_source_url=canonical_source_url,
                canonical_artifacts_base_url=canonical_artifacts_base_url,
                canonical_artifacts_base_url_ui=canonical_artifacts_base_url_ui,
                oas_process_configuration=process_config,
            ),
        )
        try:
            result = score_openapi(oas_request, spec_url=spec_url)
        except Exception as exc:
            click.echo(f"Scoring failed: {exc}", err=True)
            sys.exit(EXIT_RUNTIME_ERROR)
        finally:
            if temp_input and temp_input.exists():
                temp_input.unlink()
        if not result.success:
            click.echo(
                f"Scoring failed: {result.error_message or 'Unknown error'}",
                err=True,
            )
            sys.exit(EXIT_RUNTIME_ERROR)
        scorecard = _find_scorecard(result, output_dir)
        if scorecard is None:
            click.echo("Scorecard not found in pipeline output", err=True)
            sys.exit(EXIT_RUNTIME_ERROR)

    if output_format == "text":
        write_output(format_score_text(scorecard), output)
    else:
        write_output(json.dumps(scorecard, indent=2), output)

    if min_score is not None:
        actual_score = scorecard.get("summary", {}).get("score", 0)
        if actual_score < min_score:
            click.echo(
                f"Score {actual_score} is below minimum threshold {min_score}",
                err=True,
            )
            sys.exit(EXIT_POLICY_FAILURE)


def _find_scorecard(result, output_dir: str) -> dict | None:
    """Load scorecard.json from pipeline output."""
    import json
    from pathlib import Path

    if result.version_dir:
        path = Path(result.version_dir) / "scorecard.json"
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))

    for candidate in Path(output_dir).rglob("scorecard.json"):
        return json.loads(candidate.read_text(encoding="utf-8"))

    return None


# ---------------------------------------------------------------------------
# import command
# ---------------------------------------------------------------------------


@cli.command(name="import")
@click.argument("spec")
@click.option(
    "--output",
    "-o",
    "output_dir",
    type=click.Path(file_okay=False, writable=True),
    default=None,
    help="Output directory for import artifacts.",
)
@click.option(
    "--archive",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Write artifacts as a ZIP archive.",
)
@click.option(
    "--label",
    default=None,
    help="Vendor/API label (e.g. 'acme.com/main'). Mutually exclusive with --vendor.",
)
@click.option(
    "--vendor",
    default=None,
    help="Vendor name (e.g. 'acme.com'). Combined with --api to form the label.",
)
@click.option(
    "--api",
    default=None,
    help="API name (default: 'main'). Requires --vendor.",
)
@click.option(
    "--stdin-filepath",
    default=None,
    help="Virtual filepath when reading from stdin (for format detection).",
)
@click.option(
    "--enable-llm-analysis",
    is_flag=True,
    default=False,
    help="Enable LLM-based semantic analysis.",
)
@click.option(
    "--skip-bundle",
    is_flag=True,
    default=False,
    help="Skip bundling and process the input spec directly.",
)
@click.option(
    "--reject-invalid-server-urls/--no-reject-invalid-server-urls",
    default=True,
    help="Reject specs with invalid server URLs (default: enabled).",
)
@click.option(
    "--overwrite",
    is_flag=True,
    default=False,
    help="Overwrite existing output directory or archive.",
)
@click.option("--original-url", default=None, help="Original spec URL for provenance tracking.")
@click.option("--api-id", default=None, help="Logical API identifier.")
@click.option("--api-version-id", default=None, help="Logical API version identifier.")
@click.option("--canonical-source-url", default=None, help="Canonical source URL for metadata.")
@click.option(
    "--canonical-artifacts-base-url",
    default="https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/apis/openapi",
    help="Canonical base URL for raw artifacts.",
)
@click.option(
    "--canonical-artifacts-base-url-ui",
    default="https://github.com/jentic/jentic-public-apis/tree/main/apis/openapi",
    help="Canonical base URL for UI artifact links.",
)
@quiet_option
def import_cmd(
    spec: str,
    output_dir: str | None,
    archive: str | None,
    label: str | None,
    vendor: str | None,
    api: str | None,
    stdin_filepath: str | None,
    enable_llm_analysis: bool,
    skip_bundle: bool,
    reject_invalid_server_urls: bool,
    overwrite: bool,
    original_url: str | None,
    api_id: str | None,
    api_version_id: str | None,
    canonical_source_url: str | None,
    canonical_artifacts_base_url: str | None,
    canonical_artifacts_base_url_ui: str | None,
) -> None:
    """Import an OpenAPI specification, producing scored and cataloged artifacts.

    SPEC can be a local file path, an HTTP(S) URL, or '-' for stdin.
    Either --output DIR or --archive FILE.zip must be specified.
    """
    import json
    import shutil
    import sys
    import tempfile
    from pathlib import Path

    from jentic.apitools.cli.helpers import (
        EXIT_RUNTIME_ERROR,
        resolve_label,
        resolve_spec_input,
        warn_npx_not_found,
    )

    warn_npx_not_found()

    from jentic.apitools.common.models import (
        OASJsonRequest,
        OASProcessConfiguration,
        OASRequestMeta,
        SpecSourceUrl,
    )
    from jentic.apitools.pipelines import import_openapi

    if not output_dir and not archive:
        click.echo("Either --output DIR or --archive FILE.zip is required.", err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    out_path = Path(output_dir) if output_dir else None
    arch_path = Path(archive) if archive else None
    if out_path and out_path.exists():
        if not overwrite:
            click.echo(
                f"Output directory already exists: {output_dir}. Use --overwrite to replace.",
                err=True,
            )
            sys.exit(EXIT_RUNTIME_ERROR)
        else:
            if out_path.is_dir():
                shutil.rmtree(out_path)
            else:
                click.echo(
                    f"Output path exists and is not a directory: {output_dir}.",
                    err=True,
                )
                sys.exit(EXIT_RUNTIME_ERROR)
    if arch_path and arch_path.exists():
        if not overwrite:
            click.echo(
                f"Archive already exists: {archive}. Use --overwrite to replace.",
                err=True,
            )
            sys.exit(EXIT_RUNTIME_ERROR)
        else:
            arch_path.unlink()

    try:
        derived_label = resolve_label(label, vendor, api, stdin_filepath or spec)
    except click.UsageError as exc:
        click.echo(str(exc), err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    temp_input = None
    try:
        spec_url, temp_input = resolve_spec_input(spec, stdin_filepath)
    except click.BadParameter as exc:
        click.echo(str(exc), err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    # Default original_url to the raw SPEC arg if it's an HTTP URL
    resolved_original_url = original_url
    if not resolved_original_url and spec.startswith(("http://", "https://")):
        resolved_original_url = spec

    # Determine the actual output directory for the pipeline
    if output_dir:
        pipeline_output_dir = str(Path(output_dir).resolve())
    else:
        pipeline_output_dir = tempfile.mkdtemp(prefix="jentic-import-")

    if enable_llm_analysis:
        from jentic.apitools.cli.helpers import validate_llm_credentials

        try:
            validate_llm_credentials()
        except click.UsageError as exc:
            click.echo(str(exc), err=True)
            sys.exit(EXIT_RUNTIME_ERROR)

    process_config = OASProcessConfiguration(
        enable_llm_analysis=enable_llm_analysis,
        skip_bundle=skip_bundle,
        bundled_spec=not skip_bundle,
        reject_invalid_server_urls=reject_invalid_server_urls,
    )

    raw_base = (
        canonical_artifacts_base_url
        or "https://raw.githubusercontent.com/jentic/jentic-public-apis/refs/heads/main/apis/openapi"
    )
    ui_base = (
        canonical_artifacts_base_url_ui
        or "https://github.com/jentic/jentic-public-apis/tree/main/apis/openapi"
    )

    oas_request = OASJsonRequest(
        spec=SpecSourceUrl(kind="url", url=spec_url),
        meta=OASRequestMeta(
            label=derived_label,
            output_dir=pipeline_output_dir,
            original_url=resolved_original_url,
            api_id=api_id,
            api_version_id=api_version_id,
            canonical_source_url=canonical_source_url,
            canonical_artifacts_base_url=raw_base,
            canonical_artifacts_base_url_ui=ui_base,
            oas_process_configuration=process_config,
        ),
    )

    try:
        result = import_openapi(oas_request, spec_url=spec_url)
    except Exception as exc:
        click.echo(f"Import failed: {exc}", err=True)
        sys.exit(EXIT_RUNTIME_ERROR)
    finally:
        if temp_input and temp_input.exists():
            temp_input.unlink()

    if not result.success:
        click.echo(f"Import failed: {result.error_message or 'Unknown error'}", err=True)
        sys.exit(EXIT_RUNTIME_ERROR)

    if archive:
        # Zip the pipeline output and write to the archive path
        archive_path = Path(archive).resolve()
        # Ensure the archive has a .zip suffix, since shutil.make_archive will append .zip
        desired_archive_path = (
            archive_path if archive_path.suffix == ".zip" else archive_path.with_suffix(".zip")
        )
        desired_archive_path.parent.mkdir(parents=True, exist_ok=True)
        base_name = str(desired_archive_path.with_suffix(""))
        created_archive = shutil.make_archive(base_name, "zip", pipeline_output_dir)
        actual_archive_path = Path(created_archive)
        # Clean up temp dir if we created one (i.e., no --output was given)
        if not output_dir:
            shutil.rmtree(pipeline_output_dir, ignore_errors=True)
    else:
        actual_archive_path = None
    manifest = {
        "success": True,
        "output": str(actual_archive_path) if actual_archive_path else str(pipeline_output_dir),
        "version_path": result.version_dir,
    }
    click.echo(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    cli()
