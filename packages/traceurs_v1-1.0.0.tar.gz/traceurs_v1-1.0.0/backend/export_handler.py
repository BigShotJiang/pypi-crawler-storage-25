"""
PDF export handler for incident postmortems.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Any


class IncidentExporter:
    """Export incidents to PDF format."""
    
    def __init__(self, output_dir: str = "exports"):
        self.output_dir = output_dir
        Path(output_dir).mkdir(exist_ok=True)
    
    def export_to_pdf(self, trace_id: str, timeline: Dict[str, Any]) -> str:
        """
        Export incident to PDF.
        
        For v1, we'll create a simple text-based PDF.
        Upgrade to reportlab or weasyprint for better formatting.
        """
        # For now, return a placeholder
        # In production, use reportlab or weasyprint to generate proper PDF
        
        pdf_path = os.path.join(self.output_dir, f"incident_{trace_id}.pdf")
        
        # Create a simple text representation
        content = self._generate_text_report(timeline)
        
        # Write as text file for now
        with open(pdf_path, 'w') as f:
            f.write(content)
        
        return pdf_path
    
    def _generate_text_report(self, timeline: Dict[str, Any]) -> str:
        """Generate text-based incident report."""
        lines = [
            "=" * 80,
            "TRACEURS INCIDENT POSTMORTEM",
            "=" * 80,
            "",
            f"Incident ID: {timeline.get('trace_id')}",
            f"Agent: {timeline.get('agent_name', timeline.get('agent_id'))}",
            f"Status: {timeline.get('status')}",
            f"Duration: {timeline.get('total_duration_ms')}ms",
            f"Total Cost: ${timeline.get('total_cost_usd', 0):.4f}",
            "",
            "SUMMARY",
            "-" * 80,
            f"Root Cause: {timeline.get('root_cause_summary', 'Analysis pending...')}",
            f"Error Count: {timeline.get('error_count', 0)}",
            f"Warning Count: {timeline.get('warning_count', 0)}",
            f"Guardrail Blocks: {timeline.get('guardrail_blocks', 0)}",
            "",
            "TIMELINE",
            "-" * 80,
        ]
        
        for span in timeline.get('spans', []):
            span_type = span.get('span_type', 'unknown')
            status = span.get('status', 'unknown')
            timestamp = span.get('timestamp_ms', 0)
            data = span.get('data', {})
            
            lines.append(f"[{timestamp}ms] {span_type.upper()} ({status})")
            
            if span_type == "token":
                lines.append(f"  Model: {data.get('model')}")
                lines.append(f"  Tokens: {data.get('total_tokens')}")
                lines.append(f"  Cost: ${data.get('cost_usd', 0):.4f}")
            
            elif span_type == "tool_call":
                lines.append(f"  Tool: {data.get('tool_name')}")
                if data.get('tool_error'):
                    lines.append(f"  Error: {data.get('tool_error')}")
            
            elif span_type == "guardrail":
                lines.append(f"  Guardrail: {data.get('guardrail_name')}")
                lines.append(f"  Reason: {data.get('reason')}")
            
            lines.append("")
        
        lines.extend([
            "",
            "METRICS",
            "-" * 80,
            f"Total Tokens: {timeline.get('total_tokens', 0)}",
            f"Total Cost: ${timeline.get('total_cost_usd', 0):.4f}",
            f"Errors: {timeline.get('error_count', 0)}",
            f"Warnings: {timeline.get('warning_count', 0)}",
            "",
            f"Generated: {datetime.now().isoformat()}",
            "=" * 80,
        ])
        
        return "\n".join(lines)
