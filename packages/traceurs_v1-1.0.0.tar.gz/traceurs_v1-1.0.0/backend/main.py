"""
Traceurs v1 Incident OS - Main FastAPI Application

Production-ready API for incident ingestion, replay, and export.
"""

import os
import json
import time
from datetime import datetime, timedelta
from typing import Optional, List
import asyncio
import logging

from fastapi import FastAPI, HTTPException, Header, Query, BackgroundTasks
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import ValidationError

try:
    # Package import path (installed usage)
    from .models import IngestRunRequest, SpanDetail, IncidentTimeline, HealthStatus
    from .database import IncidentDatabase
    from .root_cause import RootCauseAnalyzer
    from .export_handler import IncidentExporter
except ImportError:
    # Local import path (direct script usage)
    from models import IngestRunRequest, SpanDetail, IncidentTimeline, HealthStatus
    from database import IncidentDatabase
    from root_cause import RootCauseAnalyzer
    from export_handler import IncidentExporter


# ─────────────────────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("traceurs.v1")


# ─────────────────────────────────────────────────────────────────
# FastAPI App Setup
# ─────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Traceurs v1 Incident OS",
    description="Production incident replay and root cause analysis for AI agents",
    version="1.0.0"
)

# CORS for development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(RequestValidationError)
async def request_validation_exception_handler(request, exc):
    """Normalize body validation failures to 400 for client-facing API consistency."""
    return JSONResponse(status_code=400, content={"detail": exc.errors()})


# ─────────────────────────────────────────────────────────────────
# Globals
# ─────────────────────────────────────────────────────────────────

db = IncidentDatabase(
    db_path=os.environ.get("TRACEURS_DB_PATH", "traceurs_incidents.db")
)

analyzer = RootCauseAnalyzer()
exporter = IncidentExporter()

start_time = time.time()
ingest_counter = 0


# ─────────────────────────────────────────────────────────────────
# Health & Status
# ─────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthStatus, tags=["Health"])
async def health_check():
    """Health check endpoint."""
    stats = db.get_stats()
    return HealthStatus(
        status="healthy",
        version="1.0.0",
        uptime_ms=int((time.time() - start_time) * 1000),
        incidents_ingested=stats.get("total_incidents", 0),
        db_connected=True,
        last_error=None
    )


@app.get("/stats", tags=["Health"])
async def get_stats():
    """Get service statistics."""
    stats = db.get_stats()
    return {
        "incidents": stats.get("total_incidents", 0),
        "spans": stats.get("total_spans", 0),
        "total_cost_usd": round(stats.get("total_cost_usd", 0), 4),
        "errored_incidents": stats.get("errored_incidents", 0),
        "uptime_seconds": int(time.time() - start_time)
    }


# ─────────────────────────────────────────────────────────────────
# Incident Ingestion
# ─────────────────────────────────────────────────────────────────

async def _analyze_root_cause_async(trace_id: str, timeline: dict):
    """Background task to analyze root cause."""
    try:
        logger.info(f"Analyzing root cause for {trace_id}...")
        root_cause, confidence = analyzer.analyze_incident(timeline)
        db.update_root_cause(trace_id, root_cause, confidence)
        logger.info(f"Root cause analyzed for {trace_id}: {root_cause[:100]}...")
    except Exception as e:
        logger.error(f"Error analyzing root cause for {trace_id}: {str(e)}")


@app.post("/v1/runs", tags=["Ingestion"])
async def ingest_run(
    request: IngestRunRequest,
    background_tasks: BackgroundTasks,
    x_api_key: Optional[str] = Header(None)
):
    """
    Ingest a complete agent run (incident).
    
    Accepts:
    - trace_id: Unique identifier for this run
    - agent_id: The agent that executed this run
    - spans: List of execution spans (tokens, tool calls, guardrails, etc.)
    - status: "success", "errored", "partial", "timeout"
    
    Returns: Incident metadata with trace_id for replay.
    """
    global ingest_counter
    
    try:
        # Validate trace_id
        if not request.trace_id:
            raise HTTPException(status_code=400, detail="trace_id is required")
        
        if not request.agent_id:
            raise HTTPException(status_code=400, detail="agent_id is required")
        
        if not request.spans:
            raise HTTPException(status_code=400, detail="spans list cannot be empty")
        
        logger.info(f"Ingesting run: trace_id={request.trace_id}, agent_id={request.agent_id}, spans={len(request.spans)}")
        
        # Store incident
        trace_id = db.store_incident(
            incident_data={
                "trace_id": request.trace_id,
                "agent_id": request.agent_id,
                "agent_name": request.agent_name,
                "model": request.model,
                "status": request.status,
                "run_started_at": request.run_started_at,
                "run_ended_at": request.run_ended_at,
                "error_message": request.error_message,
                "total_input_tokens": request.total_input_tokens or 0,
                "total_output_tokens": request.total_output_tokens or 0,
                "total_cost_usd": request.total_cost_usd or 0.0,
                "environment": request.environment or "prod",
                "source": request.source or "sdk",
                "metadata": request.metadata or {}
            },
            spans=request.spans
        )
        
        ingest_counter += 1
        
        # Retrieve timeline for root cause analysis
        timeline = db.get_incident_timeline(trace_id)
        
        # Schedule async root cause analysis (don't block response)
        background_tasks.add_task(_analyze_root_cause_async, trace_id, timeline)
        
        logger.info(f"Ingested run {trace_id} successfully")
        
        return {
            "trace_id": trace_id,
            "status": "ingested",
            "span_count": len(request.spans),
            "replay_url": f"/replay/{trace_id}",
            "timeline_api": f"/v1/runs/{trace_id}/timeline"
        }
    
    except ValidationError as e:
        logger.error(f"Validation error: {str(e)}")
        raise HTTPException(status_code=422, detail=str(e))

    except HTTPException:
        raise
    
    except Exception as e:
        logger.error(f"Error ingesting run: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to ingest run: {str(e)}")


# ─────────────────────────────────────────────────────────────────
# Incident Retrieval & Replay
# ─────────────────────────────────────────────────────────────────

@app.get("/v1/runs", tags=["Replay"])
async def list_incidents(
    agent_id: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0)
):
    """List incidents."""
    incidents = db.list_incidents(agent_id=agent_id, limit=limit, offset=offset)
    return {"incidents": incidents, "count": len(incidents)}


@app.get("/v1/runs/{trace_id}/timeline", response_model=IncidentTimeline, tags=["Replay"])
async def get_incident_timeline(trace_id: str):
    """
    Retrieve complete incident timeline for replay.
    
    Returns all spans in chronological order with computed root cause.
    """
    timeline = db.get_incident_timeline(trace_id)
    
    if not timeline:
        raise HTTPException(status_code=404, detail=f"Incident {trace_id} not found")
    
    # Convert spans to SpanDetail format
    span_details = []
    for span in timeline.get("spans", []):
        span_details.append(SpanDetail(
            span_id=span.get("span_id"),
            trace_id=span.get("trace_id"),
            parent_span_id=span.get("parent_span_id"),
            span_type=span.get("span_type"),
            status=span.get("status"),
            timestamp_ms=span.get("timestamp_ms"),
            duration_ms=span.get("duration_ms"),
            title=_generate_span_title(span),
            description=_generate_span_description(span),
            data=span.get("data", {}),
            cost_usd=span.get("data", {}).get("cost_usd"),
            error_detail=_extract_error(span),
            warning_detail=_extract_warning(span)
        ))
    
    return IncidentTimeline(
        trace_id=timeline.get("trace_id"),
        agent_id=timeline.get("agent_id"),
        agent_name=timeline.get("agent_name"),
        status=timeline.get("status"),
        run_started_at=timeline.get("run_started_at"),
        run_ended_at=timeline.get("run_ended_at"),
        total_duration_ms=timeline.get("total_duration_ms"),
        spans=span_details,
        total_tokens=timeline.get("total_tokens", 0),
        total_cost_usd=timeline.get("total_cost_usd", 0.0),
        error_count=timeline.get("error_count", 0),
        warning_count=timeline.get("warning_count", 0),
        guardrail_blocks=timeline.get("guardrail_blocks", 0),
        root_cause_summary=timeline.get("root_cause_summary"),
        root_cause_confidence=timeline.get("root_cause_confidence")
    )


@app.get("/v1/runs/{trace_id}/export.json", tags=["Export"])
async def export_incident_json(trace_id: str):
    """Export incident as JSON."""
    timeline = db.get_incident_timeline(trace_id)
    
    if not timeline:
        raise HTTPException(status_code=404, detail=f"Incident {trace_id} not found")
    
    # Create export format
    export_data = {
        "trace_id": trace_id,
        "exported_at": datetime.now().isoformat(),
        "incident": timeline,
        "format_version": "1.0"
    }
    
    filename = f"incident_{trace_id}.json"
    return JSONResponse(
        content=export_data,
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@app.get("/v1/runs/{trace_id}/export.pdf", tags=["Export"])
async def export_incident_pdf(trace_id: str):
    """Export incident as PDF postmortem."""
    timeline = db.get_incident_timeline(trace_id)
    
    if not timeline:
        raise HTTPException(status_code=404, detail=f"Incident {trace_id} not found")
    
    # Generate PDF
    pdf_path = exporter.export_to_pdf(trace_id, timeline)
    
    if not os.path.exists(pdf_path):
        raise HTTPException(status_code=500, detail="Failed to generate PDF")
    
    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=incident_{trace_id}.pdf"}
    )


# ─────────────────────────────────────────────────────────────────
# Helper Functions
# ─────────────────────────────────────────────────────────────────

def _generate_span_title(span: dict) -> str:
    """Generate human-readable title for span."""
    span_type = span.get("span_type", "unknown")
    data = span.get("data", {})
    
    if span_type == "token":
        model = data.get("model", "model").split("/")[-1]
        tokens = data.get("total_tokens", 0)
        return f"Token call: {model} ({tokens} tokens)"
    
    elif span_type == "tool_call":
        tool = data.get("tool_name", "tool")
        return f"Tool: {tool}"
    
    elif span_type == "guardrail":
        guardrail = data.get("guardrail_name", "guardrail")
        action = data.get("action", "check")
        return f"Guardrail: {guardrail} ({action})"
    
    elif span_type == "lifecycle":
        event = data.get("event", "event")
        iteration = data.get("loop_iteration")
        if iteration is not None:
            return f"Loop {iteration}: {event}"
        return f"Lifecycle: {event}"
    
    elif span_type == "override":
        override_type = data.get("override_type", "override")
        return f"Human override: {override_type}"
    
    elif span_type == "cost":
        cost = data.get("cost_usd", 0)
        return f"Cost: ${cost:.4f}"
    
    else:
        return f"{span_type.replace('_', ' ').title()}"


def _generate_span_description(span: dict) -> Optional[str]:
    """Generate description for span."""
    span_type = span.get("span_type", "unknown")
    data = span.get("data", {})
    
    if span_type == "token":
        ttft = data.get("ttft_ms")
        finish_reason = data.get("finish_reason", "unknown")
        if ttft:
            return f"TTFT: {ttft}ms, Finish: {finish_reason}"
        return f"Finish: {finish_reason}"
    
    elif span_type == "tool_call":
        error = data.get("tool_error")
        if error:
            return f"Error: {error}"
        return None
    
    elif span_type == "guardrail":
        reason = data.get("reason")
        return reason
    
    return None


def _extract_error(span: dict) -> Optional[str]:
    """Extract error message from span."""
    data = span.get("data", {})
    
    if span.get("status") == "errored":
        if "tool_error" in data:
            return data["tool_error"]
        return "Span execution failed"
    
    return None


def _extract_warning(span: dict) -> Optional[str]:
    """Extract warning message from span."""
    data = span.get("data", {})
    
    if span.get("status") == "warned":
        return data.get("reason", "Warning")
    
    if span.get("span_type") == "guardrail" and span.get("status") == "blocked":
        return f"Blocked: {data.get('reason', 'Guardrail violated')}"
    
    return None


# ─────────────────────────────────────────────────────────────────
# Root endpoint
# ─────────────────────────────────────────────────────────────────

@app.get("/", tags=["Info"])
async def root():
    """Root endpoint with API info."""
    return {
        "name": "Traceurs v1 Incident OS",
        "version": "1.0.0",
        "description": "Production incident replay and root cause analysis for AI agents",
        "docs": "/docs",
        "health": "/health",
        "ingest": "/v1/runs",
        "timeline": "/v1/runs/{trace_id}/timeline",
        "export_json": "/v1/runs/{trace_id}/export.json",
        "export_pdf": "/v1/runs/{trace_id}/export.pdf"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


def run() -> None:
    """Console-script entrypoint for running the API server."""
    import uvicorn

    host = os.environ.get("API_HOST", "0.0.0.0")
    port = int(os.environ.get("API_PORT", "8000"))
    uvicorn.run("backend.main:app", host=host, port=port)
