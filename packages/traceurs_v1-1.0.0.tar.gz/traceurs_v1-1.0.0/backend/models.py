"""
Traceurs v1 Incident OS - Data Models

Core domain models for incident ingestion, storage, and replay.
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from enum import Enum
from datetime import datetime


class SpanType(str, Enum):
    """Types of agent execution spans."""
    TOKEN = "token"
    TOOL_CALL = "tool_call"
    GUARDRAIL = "guardrail"
    LIFECYCLE = "lifecycle"
    POLICY = "policy"
    OVERRIDE = "override"
    COST = "cost"


class SpanStatus(str, Enum):
    """Status of a span execution."""
    STARTED = "started"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ERRORED = "errored"
    WARNED = "warned"
    BLOCKED = "blocked"


# ─────────────────────────────────────────────────────────────────
# Inbound API Models (what agents send)
# ─────────────────────────────────────────────────────────────────

class TokenSpan(BaseModel):
    """A model invocation span (tokens, latency, cost)."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    timestamp_ms: int
    span_type: str = SpanType.TOKEN
    status: str = SpanStatus.COMPLETED
    
    model: str  # gpt-4o, claude-3, etc.
    input_tokens: int
    output_tokens: int
    total_tokens: int
    ttft_ms: Optional[int] = None  # Time to first token
    total_duration_ms: int
    finish_reason: Optional[str] = None  # stop, length, tool_calls, etc.
    cost_usd: Optional[float] = None
    
    # Content
    prompt_tokens_preview: Optional[str] = None  # First 500 chars
    completion_preview: Optional[str] = None  # First 500 chars
    tool_calls: Optional[List[Dict[str, Any]]] = None
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ToolCallSpan(BaseModel):
    """An agent tool invocation span."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    timestamp_ms: int
    span_type: str = SpanType.TOOL_CALL
    status: str = SpanStatus.COMPLETED
    
    tool_name: str
    tool_input: Dict[str, Any]
    tool_output: Optional[Dict[str, Any]] = None
    tool_error: Optional[str] = None
    duration_ms: int
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class GuardrailSpan(BaseModel):
    """A guardrail/policy check span."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    timestamp_ms: int
    span_type: str = SpanType.GUARDRAIL
    status: str  # "blocked", "warned", "allowed"
    
    guardrail_name: str
    check_category: str  # "jailbreak", "pii", "cost", "rate_limit", "policy"
    severity: str  # "info", "warning", "critical"
    action: str  # "block", "warn", "log"
    reason: str  # Why it triggered
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class LifecycleSpan(BaseModel):
    """Agent lifecycle event span."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    timestamp_ms: int
    span_type: str = SpanType.LIFECYCLE
    status: str  # started, in_loop, loop_complete, errored, etc.
    
    event: str  # "agent_started", "loop_iteration", "loop_complete", "error", "timeout"
    loop_iteration: Optional[int] = None
    agent_id: str
    agent_name: Optional[str] = None
    reason: Optional[str] = None  # Why loop ended, error message, etc.
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class OverrideSpan(BaseModel):
    """Human override/intervention span."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    timestamp_ms: int
    span_type: str = SpanType.OVERRIDE
    status: str = SpanStatus.COMPLETED
    
    override_type: str  # "correction", "approval", "abort", "resume"
    override_reason: str
    override_by: Optional[str] = None  # User ID or system
    changed_value: Optional[Dict[str, Any]] = None
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


class CostSpan(BaseModel):
    """Cost tracking span."""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    timestamp_ms: int
    span_type: str = SpanType.COST
    status: str = SpanStatus.COMPLETED
    
    cost_category: str  # "tokens", "tool_calls", "api_calls", "storage"
    cost_usd: float
    units: int  # tokens, calls, etc.
    cost_per_unit: Optional[float] = None
    budget_remaining: Optional[float] = None
    budget_exceeded: bool = False
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


# Union of all span types
AnySpan = TokenSpan | ToolCallSpan | GuardrailSpan | LifecycleSpan | OverrideSpan | CostSpan


# ─────────────────────────────────────────────────────────────────
# Ingest API Request
# ─────────────────────────────────────────────────────────────────

class IngestRunRequest(BaseModel):
    """Ingest a complete agent run (collection of spans)."""
    trace_id: str
    agent_id: str
    agent_name: Optional[str] = None
    model: Optional[str] = None
    spans: List[Dict[str, Any]]  # Flexible: any span type
    run_started_at: int  # milliseconds
    run_ended_at: int  # milliseconds
    status: str  # "success", "errored", "partial", "timeout"
    error_message: Optional[str] = None
    
    # Cost/usage summary
    total_input_tokens: Optional[int] = None
    total_output_tokens: Optional[int] = None
    total_cost_usd: Optional[float] = None
    
    # Environment
    environment: Optional[str] = None  # "dev", "staging", "prod"
    source: Optional[str] = None  # SDK version or tool name
    
    metadata: Dict[str, Any] = Field(default_factory=dict)


# ─────────────────────────────────────────────────────────────────
# Replay API Response Models
# ─────────────────────────────────────────────────────────────────

class SpanDetail(BaseModel):
    """Detailed span for replay view."""
    span_id: str
    trace_id: str
    parent_span_id: Optional[str] = None
    span_type: str
    status: str
    timestamp_ms: int
    duration_ms: Optional[int] = None
    
    # Enriched content for display
    title: str  # Human-readable title
    description: Optional[str] = None
    data: Dict[str, Any]  # Full span data
    
    # Computed fields
    cost_usd: Optional[float] = None
    error_detail: Optional[str] = None
    warning_detail: Optional[str] = None


class IncidentTimeline(BaseModel):
    """Complete incident timeline for replay."""
    trace_id: str
    agent_id: str
    agent_name: Optional[str] = None
    status: str
    
    run_started_at: int
    run_ended_at: int
    total_duration_ms: int
    
    spans: List[SpanDetail]
    
    # Summary stats
    total_tokens: int
    total_cost_usd: float
    error_count: int
    warning_count: int
    guardrail_blocks: int
    
    # Root cause (generated by LLM)
    root_cause_summary: Optional[str] = None
    root_cause_confidence: Optional[float] = None


class IncidentExport(BaseModel):
    """Incident export for postmortem."""
    trace_id: str
    exported_at: str
    
    # Summary
    agent_name: str
    agent_id: str
    incident_duration_ms: int
    status: str
    error_message: Optional[str] = None
    
    # Timeline
    spans: List[SpanDetail]
    
    # Metrics
    total_tokens: int
    total_cost_usd: float
    error_count: int
    guardrail_violations: int
    
    # Root cause
    root_cause: str
    
    # Evidence
    recommendations: List[str]
    evidence_urls: List[str]


class HealthStatus(BaseModel):
    """Service health status."""
    status: str  # "healthy", "degraded", "unhealthy"
    version: str
    uptime_ms: int
    incidents_ingested: int
    db_connected: bool
    last_error: Optional[str] = None
