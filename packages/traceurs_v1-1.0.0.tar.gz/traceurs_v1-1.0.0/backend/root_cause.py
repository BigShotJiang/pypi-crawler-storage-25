"""
Root cause analysis using Claude API.

Generates human-readable root cause summaries from incident timelines.
"""

import os
from typing import Dict, Any

try:
    import anthropic
except ImportError:  # pragma: no cover - dependency is optional during local bootstrapping
    anthropic = None


class RootCauseAnalyzer:
    """Uses Claude to analyze incidents and generate root cause summaries."""
    
    def __init__(self, model: str = "claude-3-5-sonnet-20241022"):
        self.model = model
        self.api_key = os.environ.get("ANTHROPIC_API_KEY")
        self.client = None

        if anthropic is not None and self.api_key:
            self.client = anthropic.Anthropic(api_key=self.api_key)
    
    def analyze_incident(self, timeline_data: Dict[str, Any]) -> tuple[str, float]:
        """
        Analyze an incident timeline and generate root cause summary.
        
        Returns: (root_cause_summary, confidence_score)
        """
        # Extract key information from timeline
        spans = timeline_data.get("spans", [])
        agent_name = timeline_data.get("agent_name", "Agent")
        status = timeline_data.get("status", "unknown")
        error_message = timeline_data.get("error_message", "")
        
        # Build incident summary for Claude
        incident_summary = self._build_incident_context(
            spans, agent_name, status, error_message, timeline_data
        )

        if self.client is None:
            return self._fallback_summary(timeline_data), self._calculate_confidence(spans, status, error_message)
        
        # Call Claude
        message = self.client.messages.create(
            model=self.model,
            max_tokens=500,
            system="""You are an expert AI systems engineer analyzing production incidents.
Given a detailed incident timeline, provide a concise (1-3 sentence) root cause summary.
Focus on: what happened, why it happened, and what prevented recovery.
Be precise and avoid speculation.""",
            messages=[
                {
                    "role": "user",
                    "content": f"""Analyze this incident and provide a root cause summary:

{incident_summary}

Root cause (1-3 sentences):"""
                }
            ]
        )
        
        root_cause = message.content[0].text.strip()
        
        # Confidence is based on how many error signals we found
        confidence = self._calculate_confidence(spans, status, error_message)
        
        return root_cause, confidence

    def _fallback_summary(self, timeline_data: Dict[str, Any]) -> str:
        """Return a deterministic summary when Anthropic is unavailable."""
        spans = timeline_data.get("spans", [])
        errored_tool = next(
            (
                span for span in spans
                if span.get("span_type") == "tool_call" and span.get("status") == "errored"
            ),
            None,
        )
        blocked_guardrail = next(
            (
                span for span in spans
                if span.get("span_type") == "guardrail" and span.get("status") == "blocked"
            ),
            None,
        )

        if errored_tool:
            data = errored_tool.get("data", errored_tool)
            tool_name = data.get("tool_name", "unknown tool")
            tool_error = data.get("tool_error", "tool execution failed")
            return f"The incident failed because the tool '{tool_name}' errored: {tool_error}. Traceurs captured the failure path for replay and export."

        if blocked_guardrail:
            data = blocked_guardrail.get("data", blocked_guardrail)
            guardrail_name = data.get("guardrail_name", "guardrail")
            reason = data.get("reason", "policy blocked the run")
            return f"The incident was blocked by the guardrail '{guardrail_name}' because {reason}. Review the replay timeline for the exact sequence."

        status = timeline_data.get("status", "unknown")
        return f"Traceurs recorded a '{status}' run and assembled the replay timeline. Configure ANTHROPIC_API_KEY for an LLM-generated root-cause explanation."
    
    def _build_incident_context(
        self, 
        spans: list,
        agent_name: str,
        status: str,
        error_message: str,
        timeline_data: Dict[str, Any]
    ) -> str:
        """Build context string for Claude."""
        lines = [
            f"Agent: {agent_name}",
            f"Status: {status}",
            f"Duration: {timeline_data.get('total_duration_ms', 0)}ms",
            f"Total Cost: ${timeline_data.get('total_cost_usd', 0):.4f}",
            "",
            "Key Events:"
        ]
        
        # Extract significant spans
        for span in spans[-20:]:  # Last 20 spans for context
            span_type = span.get("span_type", "unknown")
            span_status = span.get("status", "unknown")
            data = span.get("data", {})
            
            if span_type == "token":
                model = data.get("model", "unknown")
                tokens = data.get("total_tokens", 0)
                finish_reason = data.get("finish_reason", "")
                lines.append(f"  - Token call to {model}: {tokens} tokens ({finish_reason})")
            
            elif span_type == "tool_call":
                tool = data.get("tool_name", "unknown")
                error = data.get("tool_error", "")
                if error:
                    lines.append(f"  - Tool {tool}: ERROR - {error}")
                else:
                    lines.append(f"  - Tool {tool}: Success")
            
            elif span_type == "guardrail":
                guardrail = data.get("guardrail_name", "unknown")
                action = data.get("action", "unknown")
                reason = data.get("reason", "")
                lines.append(f"  - Guardrail {guardrail} ({action}): {reason}")
            
            elif span_type == "lifecycle":
                event = data.get("event", "unknown")
                iteration = data.get("loop_iteration")
                if iteration is not None:
                    lines.append(f"  - Loop iteration {iteration}: {event}")
                else:
                    lines.append(f"  - Lifecycle: {event}")
            
            elif span_status == "errored":
                lines.append(f"  - {span_type}: ERROR - {span.get('data', {})}")
        
        if error_message:
            lines.append("")
            lines.append(f"Error Message: {error_message}")
        
        return "\n".join(lines)
    
    def _calculate_confidence(self, spans: list, status: str, error_message: str) -> float:
        """Calculate confidence score (0.0 - 1.0)."""
        confidence = 0.5  # Base confidence
        
        # More error signals = higher confidence
        error_spans = sum(1 for s in spans if s.get("status") in ["errored", "blocked"])
        if error_spans > 0:
            confidence += min(0.3, error_spans * 0.1)
        
        # Status indicates root cause
        if status == "errored":
            confidence += 0.1
        
        # Error message available
        if error_message:
            confidence += 0.1
        
        return min(0.95, confidence)
