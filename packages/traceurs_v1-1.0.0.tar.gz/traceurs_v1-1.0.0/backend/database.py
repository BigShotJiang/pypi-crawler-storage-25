"""
Database layer for Traceurs v1 Incident OS.

SQLite-based storage for development/self-hosted; can upgrade to PostgreSQL.
"""

import sqlite3
import json
import os
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional
import threading


class IncidentDatabase:
    """SQLite database for incident storage."""
    
    def __init__(self, db_path: str = "traceurs_incidents.db"):
        self.db_path = db_path
        self.lock = threading.RLock()
        self._init_schema()
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get a database connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def _init_schema(self):
        """Initialize database schema."""
        with self.lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            # Incidents table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS incidents (
                    trace_id TEXT PRIMARY KEY,
                    agent_id TEXT NOT NULL,
                    agent_name TEXT,
                    model TEXT,
                    status TEXT NOT NULL,
                    run_started_at INTEGER,
                    run_ended_at INTEGER,
                    total_duration_ms INTEGER,
                    error_message TEXT,
                    total_tokens INTEGER,
                    total_cost_usd REAL,
                    environment TEXT,
                    source TEXT,
                    ingested_at INTEGER,
                    metadata TEXT,
                    root_cause_summary TEXT,
                    root_cause_confidence REAL
                )
            """)
            
            # Spans table (normalized)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS spans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trace_id TEXT NOT NULL,
                    span_id TEXT NOT NULL,
                    parent_span_id TEXT,
                    span_type TEXT NOT NULL,
                    status TEXT,
                    timestamp_ms INTEGER,
                    duration_ms INTEGER,
                    data TEXT NOT NULL,
                    created_at INTEGER,
                    UNIQUE(trace_id, span_id),
                    FOREIGN KEY (trace_id) REFERENCES incidents(trace_id)
                )
            """)
            
            # Indexes for common queries
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_spans_trace_id 
                ON spans(trace_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_spans_timestamp 
                ON spans(trace_id, timestamp_ms)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_incidents_agent 
                ON incidents(agent_id)
            """)
            cursor.execute("""
                CREATE INDEX IF NOT EXISTS idx_incidents_ingested 
                ON incidents(ingested_at)
            """)
            
            conn.commit()
            conn.close()
    
    def store_incident(self, incident_data: Dict[str, Any], spans: List[Dict[str, Any]]) -> str:
        """Store a complete incident (metadata + all spans)."""
        with self.lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            trace_id = incident_data.get("trace_id")
            now_ms = int(datetime.now().timestamp() * 1000)
            
            try:
                # Replace any prior copy of the same trace so reruns and tests are idempotent.
                cursor.execute("DELETE FROM spans WHERE trace_id = ?", (trace_id,))
                cursor.execute("DELETE FROM incidents WHERE trace_id = ?", (trace_id,))

                # Insert incident metadata
                cursor.execute("""
                    INSERT INTO incidents (
                        trace_id, agent_id, agent_name, model, status,
                        run_started_at, run_ended_at, total_duration_ms,
                        error_message, total_tokens, total_cost_usd,
                        environment, source, ingested_at, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    trace_id,
                    incident_data.get("agent_id"),
                    incident_data.get("agent_name"),
                    incident_data.get("model"),
                    incident_data.get("status"),
                    incident_data.get("run_started_at"),
                    incident_data.get("run_ended_at"),
                    incident_data.get("run_ended_at", 0) - incident_data.get("run_started_at", 0),
                    incident_data.get("error_message"),
                    incident_data.get("total_input_tokens", 0) + incident_data.get("total_output_tokens", 0),
                    incident_data.get("total_cost_usd"),
                    incident_data.get("environment", "prod"),
                    incident_data.get("source"),
                    now_ms,
                    json.dumps(incident_data.get("metadata", {}))
                ))
                
                # Insert all spans
                for span in spans:
                    cursor.execute("""
                        INSERT INTO spans (
                            trace_id, span_id, parent_span_id, span_type,
                            status, timestamp_ms, duration_ms, data, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        trace_id,
                        span.get("span_id"),
                        span.get("parent_span_id"),
                        span.get("span_type"),
                        span.get("status"),
                        span.get("timestamp_ms"),
                        span.get("duration_ms", 0),
                        json.dumps(span),
                        now_ms
                    ))
                
                conn.commit()
                return trace_id
            
            except Exception as e:
                conn.rollback()
                raise RuntimeError(f"Failed to store incident: {str(e)}")
            
            finally:
                conn.close()
    
    def get_incident_timeline(self, trace_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve complete incident timeline."""
        with self.lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            # Get incident metadata
            cursor.execute("SELECT * FROM incidents WHERE trace_id = ?", (trace_id,))
            incident_row = cursor.fetchone()
            
            if not incident_row:
                conn.close()
                return None
            
            # Get all spans, ordered by timestamp
            cursor.execute("""
                SELECT * FROM spans 
                WHERE trace_id = ? 
                ORDER BY timestamp_ms ASC
            """, (trace_id,))
            span_rows = cursor.fetchall()
            
            conn.close()
            
            # Parse spans
            spans = []
            for row in span_rows:
                span_data = json.loads(row["data"])
                spans.append({
                    "span_id": row["span_id"],
                    "trace_id": row["trace_id"],
                    "parent_span_id": row["parent_span_id"],
                    "span_type": row["span_type"],
                    "status": row["status"],
                    "timestamp_ms": row["timestamp_ms"],
                    "duration_ms": row["duration_ms"],
                    "data": span_data
                })
            
            # Compute statistics
            error_count = sum(1 for s in spans if s["status"] in ["errored", "blocked"])
            warning_count = sum(1 for s in spans if s["status"] == "warned")
            guardrail_blocks = sum(1 for s in spans if s["span_type"] == "guardrail" and s["status"] == "blocked")
            total_tokens = incident_row["total_tokens"] or 0
            total_cost = incident_row["total_cost_usd"] or 0.0
            
            return {
                "trace_id": trace_id,
                "agent_id": incident_row["agent_id"],
                "agent_name": incident_row["agent_name"],
                "status": incident_row["status"],
                "run_started_at": incident_row["run_started_at"],
                "run_ended_at": incident_row["run_ended_at"],
                "total_duration_ms": incident_row["total_duration_ms"],
                "spans": spans,
                "total_tokens": total_tokens,
                "total_cost_usd": total_cost,
                "error_count": error_count,
                "warning_count": warning_count,
                "guardrail_blocks": guardrail_blocks,
                "root_cause_summary": incident_row["root_cause_summary"],
                "root_cause_confidence": incident_row["root_cause_confidence"]
            }
    
    def list_incidents(self, agent_id: Optional[str] = None, limit: int = 50, offset: int = 0) -> List[Dict[str, Any]]:
        """List incidents."""
        with self.lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            if agent_id:
                cursor.execute("""
                    SELECT trace_id, agent_id, agent_name, status, 
                           run_started_at, run_ended_at, total_duration_ms,
                           error_message, total_tokens, total_cost_usd, ingested_at
                    FROM incidents 
                    WHERE agent_id = ?
                    ORDER BY ingested_at DESC
                    LIMIT ? OFFSET ?
                """, (agent_id, limit, offset))
            else:
                cursor.execute("""
                    SELECT trace_id, agent_id, agent_name, status,
                           run_started_at, run_ended_at, total_duration_ms,
                           error_message, total_tokens, total_cost_usd, ingested_at
                    FROM incidents
                    ORDER BY ingested_at DESC
                    LIMIT ? OFFSET ?
                """, (limit, offset))
            
            incidents = []
            for row in cursor.fetchall():
                incidents.append({
                    "trace_id": row["trace_id"],
                    "agent_id": row["agent_id"],
                    "agent_name": row["agent_name"],
                    "status": row["status"],
                    "run_started_at": row["run_started_at"],
                    "run_ended_at": row["run_ended_at"],
                    "total_duration_ms": row["total_duration_ms"],
                    "error_message": row["error_message"],
                    "total_tokens": row["total_tokens"],
                    "total_cost_usd": row["total_cost_usd"],
                    "ingested_at": row["ingested_at"]
                })
            
            conn.close()
            return incidents
    
    def update_root_cause(self, trace_id: str, root_cause: str, confidence: float = 0.95):
        """Update root cause summary after LLM analysis."""
        with self.lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute("""
                UPDATE incidents 
                SET root_cause_summary = ?, root_cause_confidence = ?
                WHERE trace_id = ?
            """, (root_cause, confidence, trace_id))
            
            conn.commit()
            conn.close()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        with self.lock:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) as count FROM incidents")
            incident_count = cursor.fetchone()["count"]
            
            cursor.execute("SELECT COUNT(*) as count FROM spans")
            span_count = cursor.fetchone()["count"]
            
            cursor.execute("""
                SELECT SUM(total_cost_usd) as total_cost 
                FROM incidents 
                WHERE total_cost_usd IS NOT NULL
            """)
            total_cost = cursor.fetchone()["total_cost"] or 0.0
            
            cursor.execute("""
                SELECT COUNT(*) as count FROM incidents 
                WHERE status = 'errored'
            """)
            error_count = cursor.fetchone()["count"]
            
            conn.close()
            
            return {
                "total_incidents": incident_count,
                "total_spans": span_count,
                "total_cost_usd": total_cost,
                "errored_incidents": error_count
            }
