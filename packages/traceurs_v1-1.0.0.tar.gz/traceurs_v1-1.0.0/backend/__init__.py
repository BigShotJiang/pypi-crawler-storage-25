"""
Traceurs v1 Incident OS Backend

Production incident replay and root cause analysis for AI agents.
"""

__version__ = "1.0.0"
__author__ = "Traceurs Team"
__license__ = "MIT"
