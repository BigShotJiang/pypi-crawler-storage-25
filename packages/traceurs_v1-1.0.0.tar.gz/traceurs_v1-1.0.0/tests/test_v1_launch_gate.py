"""
Traceurs v1 Launch Gate Tests

These tests verify the core v1 incident OS functionality.
Everything here must pass to ship v1.0.
"""

import pytest
import json
import time
from datetime import datetime
from fastapi.testclient import TestClient
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from main import app
from database import IncidentDatabase
from models import IngestRunRequest


@pytest.fixture
def client():
    """FastAPI test client."""
    return TestClient(app)


@pytest.fixture
def db():
    """Test database."""
    db = IncidentDatabase(db_path=":memory:")
    return db


@pytest.fixture
def sample_run():
    """Sample incident run for testing."""
    now_ms = int(time.time() * 1000)
    return {
        "trace_id": "test-trace-001",
        "agent_id": "agent-research",
        "agent_name": "ResearchBot",
        "model": "gpt-4o",
        "status": "success",
        "run_started_at": now_ms,
        "run_ended_at": now_ms + 5000,
        "total_input_tokens": 1200,
        "total_output_tokens": 800,
        "total_cost_usd": 0.045,
        "environment": "prod",
        "source": "sdk/python/1.0.0",
        "spans": [
            {
                "trace_id": "test-trace-001",
                "span_id": "span-1",
                "parent_span_id": None,
                "timestamp_ms": now_ms,
                "span_type": "lifecycle",
                "status": "started",
                "event": "agent_started",
                "agent_id": "agent-research",
                "agent_name": "ResearchBot"
            },
            {
                "trace_id": "test-trace-001",
                "span_id": "span-2",
                "parent_span_id": "span-1",
                "timestamp_ms": now_ms + 100,
                "span_type": "token",
                "status": "completed",
                "model": "gpt-4o",
                "input_tokens": 1200,
                "output_tokens": 800,
                "total_tokens": 2000,
                "ttft_ms": 450,
                "total_duration_ms": 2300,
                "finish_reason": "tool_calls",
                "cost_usd": 0.045,
                "tool_calls": [
                    {"name": "search_web", "arguments": "{\"query\": \"AI safety\"}"}
                ]
            },
            {
                "trace_id": "test-trace-001",
                "span_id": "span-3",
                "parent_span_id": "span-2",
                "timestamp_ms": now_ms + 2400,
                "span_type": "tool_call",
                "status": "completed",
                "tool_name": "search_web",
                "tool_input": {"query": "AI safety"},
                "tool_output": {"results": ["result1", "result2"]},
                "duration_ms": 800
            },
            {
                "trace_id": "test-trace-001",
                "span_id": "span-4",
                "parent_span_id": "span-1",
                "timestamp_ms": now_ms + 5000,
                "span_type": "lifecycle",
                "status": "completed",
                "event": "agent_completed",
                "agent_id": "agent-research",
                "agent_name": "ResearchBot"
            }
        ]
    }


@pytest.fixture
def error_run():
    """Sample incident run with error."""
    now_ms = int(time.time() * 1000)
    return {
        "trace_id": "test-trace-error",
        "agent_id": "agent-payment",
        "agent_name": "PaymentBot",
        "model": "claude-3",
        "status": "errored",
        "run_started_at": now_ms,
        "run_ended_at": now_ms + 3000,
        "error_message": "Tool execution failed: rate_limit_exceeded",
        "total_input_tokens": 800,
        "total_output_tokens": 200,
        "total_cost_usd": 0.015,
        "environment": "prod",
        "source": "sdk/python/1.0.0",
        "spans": [
            {
                "trace_id": "test-trace-error",
                "span_id": "span-1",
                "parent_span_id": None,
                "timestamp_ms": now_ms,
                "span_type": "lifecycle",
                "status": "started",
                "event": "agent_started",
                "agent_id": "agent-payment"
            },
            {
                "trace_id": "test-trace-error",
                "span_id": "span-2",
                "parent_span_id": "span-1",
                "timestamp_ms": now_ms + 100,
                "span_type": "token",
                "status": "completed",
                "model": "claude-3",
                "input_tokens": 800,
                "output_tokens": 200,
                "total_tokens": 1000,
                "cost_usd": 0.015
            },
            {
                "trace_id": "test-trace-error",
                "span_id": "span-3",
                "parent_span_id": "span-2",
                "timestamp_ms": now_ms + 1500,
                "span_type": "tool_call",
                "status": "errored",
                "tool_name": "process_payment",
                "tool_error": "rate_limit_exceeded: Stripe API limit reached",
                "duration_ms": 1400
            },
            {
                "trace_id": "test-trace-error",
                "span_id": "span-4",
                "parent_span_id": "span-1",
                "timestamp_ms": now_ms + 3000,
                "span_type": "lifecycle",
                "status": "errored",
                "event": "agent_failed",
                "agent_id": "agent-payment",
                "reason": "Tool execution failed"
            }
        ]
    }


# ─────────────────────────────────────────────────────────────────
# Test: Health Check
# ─────────────────────────────────────────────────────────────────

class TestHealth:
    def test_health_check(self, client):
        """Health check endpoint works."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert data["version"] == "1.0.0"
        assert data["db_connected"] is True
    
    def test_root_endpoint(self, client):
        """Root endpoint returns API info."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Traceurs v1 Incident OS"
        assert "ingest" in data
        assert "timeline" in data


# ─────────────────────────────────────────────────────────────────
# Test: Incident Ingestion
# ─────────────────────────────────────────────────────────────────

class TestIngestion:
    def test_ingest_valid_run(self, client, sample_run):
        """Can ingest a valid incident run."""
        response = client.post("/v1/runs", json=sample_run)
        assert response.status_code == 200
        data = response.json()
        assert data["trace_id"] == "test-trace-001"
        assert data["status"] == "ingested"
        assert data["span_count"] == 4
        assert "timeline_api" in data
    
    def test_ingest_error_run(self, client, error_run):
        """Can ingest error runs."""
        response = client.post("/v1/runs", json=error_run)
        assert response.status_code == 200
        data = response.json()
        assert data["trace_id"] == "test-trace-error"
        assert data["span_count"] == 4
    
    def test_ingest_missing_trace_id(self, client, sample_run):
        """Reject ingestion without trace_id."""
        del sample_run["trace_id"]
        response = client.post("/v1/runs", json=sample_run)
        assert response.status_code == 400
    
    def test_ingest_missing_agent_id(self, client, sample_run):
        """Reject ingestion without agent_id."""
        del sample_run["agent_id"]
        response = client.post("/v1/runs", json=sample_run)
        assert response.status_code == 400
    
    def test_ingest_empty_spans(self, client, sample_run):
        """Reject ingestion with empty spans."""
        sample_run["spans"] = []
        response = client.post("/v1/runs", json=sample_run)
        assert response.status_code == 400


# ─────────────────────────────────────────────────────────────────
# Test: Timeline Assembly
# ─────────────────────────────────────────────────────────────────

class TestTimeline:
    def test_get_timeline(self, client, sample_run):
        """Can retrieve incident timeline."""
        # Ingest
        ingest_response = client.post("/v1/runs", json=sample_run)
        assert ingest_response.status_code == 200
        
        # Retrieve timeline
        trace_id = ingest_response.json()["trace_id"]
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        assert response.status_code == 200
        data = response.json()
        
        # Verify structure
        assert data["trace_id"] == trace_id
        assert data["agent_id"] == "agent-research"
        assert len(data["spans"]) == 4
        assert data["total_tokens"] > 0
        assert data["total_cost_usd"] > 0
    
    def test_timeline_spans_ordered(self, client, sample_run):
        """Spans are ordered by timestamp."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        data = response.json()
        
        spans = data["spans"]
        for i in range(1, len(spans)):
            assert spans[i]["timestamp_ms"] >= spans[i-1]["timestamp_ms"]
    
    def test_timeline_stats(self, client, sample_run):
        """Timeline includes computed statistics."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        data = response.json()
        
        # Check stats
        assert "error_count" in data
        assert "warning_count" in data
        assert "guardrail_blocks" in data
        assert data["total_tokens"] == 2000  # From sample
    
    def test_timeline_nonexistent(self, client):
        """Returns 404 for nonexistent incident."""
        response = client.get("/v1/runs/nonexistent-trace/timeline")
        assert response.status_code == 404
    
    def test_timeline_error_incidents(self, client, error_run):
        """Timeline includes error information."""
        ingest_response = client.post("/v1/runs", json=error_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        data = response.json()
        
        assert data["status"] == "errored"
        assert data["error_count"] > 0


# ─────────────────────────────────────────────────────────────────
# Test: Replay API (Span Details)
# ─────────────────────────────────────────────────────────────────

class TestReplay:
    def test_span_has_title(self, client, sample_run):
        """Spans have human-readable titles for UI."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        data = response.json()
        
        for span in data["spans"]:
            assert "title" in span
            assert len(span["title"]) > 0
    
    def test_span_has_data(self, client, sample_run):
        """Spans include full data for detail views."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        data = response.json()
        
        for span in data["spans"]:
            assert "data" in span
            assert isinstance(span["data"], dict)
    
    def test_token_span_details(self, client, sample_run):
        """Token spans include model, tokens, cost."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/timeline")
        data = response.json()
        
        token_spans = [s for s in data["spans"] if s["span_type"] == "token"]
        assert len(token_spans) > 0
        
        token_span = token_spans[0]
        assert "model" in token_span["data"]
        assert "total_tokens" in token_span["data"]
        assert token_span["cost_usd"] is not None


# ─────────────────────────────────────────────────────────────────
# Test: Export
# ─────────────────────────────────────────────────────────────────

class TestExport:
    def test_export_json(self, client, sample_run):
        """Can export incident as JSON."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/export.json")
        assert response.status_code == 200
        assert response.headers["content-disposition"]
        
        data = response.json()
        assert data["trace_id"] == trace_id
        assert "incident" in data
    
    def test_export_pdf(self, client, sample_run):
        """Can export incident as PDF."""
        ingest_response = client.post("/v1/runs", json=sample_run)
        trace_id = ingest_response.json()["trace_id"]
        
        response = client.get(f"/v1/runs/{trace_id}/export.pdf")
        assert response.status_code == 200
        assert "application/pdf" in response.headers["content-type"]


# ─────────────────────────────────────────────────────────────────
# Test: List Incidents
# ─────────────────────────────────────────────────────────────────

class TestList:
    def test_list_incidents(self, client, sample_run):
        """Can list incidents."""
        # Ingest a run
        client.post("/v1/runs", json=sample_run)
        
        response = client.get("/v1/runs")
        assert response.status_code == 200
        data = response.json()
        assert "incidents" in data
        assert len(data["incidents"]) > 0
    
    def test_list_by_agent(self, client, sample_run):
        """Can filter incidents by agent."""
        client.post("/v1/runs", json=sample_run)
        
        response = client.get("/v1/runs?agent_id=agent-research")
        assert response.status_code == 200
        data = response.json()
        assert len(data["incidents"]) > 0
        assert all(i["agent_id"] == "agent-research" for i in data["incidents"])


# ─────────────────────────────────────────────────────────────────
# Integration: End-to-End
# ─────────────────────────────────────────────────────────────────

class TestEndToEnd:
    def test_full_incident_workflow(self, client, sample_run):
        """Complete workflow: ingest → retrieve → export."""
        # Step 1: Ingest
        ingest_response = client.post("/v1/runs", json=sample_run)
        assert ingest_response.status_code == 200
        trace_id = ingest_response.json()["trace_id"]
        
        # Step 2: Retrieve timeline
        timeline_response = client.get(f"/v1/runs/{trace_id}/timeline")
        assert timeline_response.status_code == 200
        timeline = timeline_response.json()
        assert timeline["trace_id"] == trace_id
        assert len(timeline["spans"]) == 4
        
        # Step 3: Export JSON
        export_json_response = client.get(f"/v1/runs/{trace_id}/export.json")
        assert export_json_response.status_code == 200
        
        # Step 4: Export PDF
        export_pdf_response = client.get(f"/v1/runs/{trace_id}/export.pdf")
        assert export_pdf_response.status_code == 200
    
    def test_multiple_incidents(self, client, sample_run, error_run):
        """Can handle multiple simultaneous incidents."""
        # Ingest both
        r1 = client.post("/v1/runs", json=sample_run)
        r2 = client.post("/v1/runs", json=error_run)
        
        assert r1.status_code == 200
        assert r2.status_code == 200
        
        # List all
        list_response = client.get("/v1/runs")
        assert len(list_response.json()["incidents"]) == 2
        
        # Retrieve each separately
        trace1 = r1.json()["trace_id"]
        trace2 = r2.json()["trace_id"]
        
        t1_response = client.get(f"/v1/runs/{trace1}/timeline")
        t2_response = client.get(f"/v1/runs/{trace2}/timeline")
        
        assert t1_response.json()["status"] == "success"
        assert t2_response.json()["status"] == "errored"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
