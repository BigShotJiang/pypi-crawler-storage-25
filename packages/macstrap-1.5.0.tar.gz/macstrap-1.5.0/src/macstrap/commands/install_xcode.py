"""macstrap local install-xcode – install Xcode Command Line Tools."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console

console = Console()

_CLT_GIT = Path("/Library/Developer/CommandLineTools/usr/bin/git")
_TRIGGER = Path("/tmp/.com.apple.dt.CommandLineTools.installondemand.in-progress")


def _clt_installed() -> bool:
    return _CLT_GIT.exists()


def _find_clt_package() -> str | None:
    """Ask softwareupdate for the latest CLT package label."""
    result = subprocess.run(
        ["softwareupdate", "-l"],
        capture_output=True,
        text=True,
    )
    # Combine stdout+stderr — softwareupdate writes to both
    output = result.stdout + "\n" + result.stderr
    candidates = []
    for line in output.splitlines():
        if "Command Line Tools" in line and "Label:" in line:
            label = line.split("Label:")[-1].strip()
            candidates.append(label)
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0]


@click.command("install-xcode")
def cmd_install_xcode() -> None:
    """Install Xcode Command Line Tools (git, compilers, etc.).

    \b
    This installs the same CLT package that 'xcode-select --install'
    would, but non-interactively via softwareupdate.
    """
    if sys.platform != "darwin":
        console.print("[red]✗[/]  This command is only available on macOS.")
        raise SystemExit(1)

    if _clt_installed():
        # Show version
        result = subprocess.run(
            ["pkgutil", "--pkg-info", "com.apple.pkg.CLTools_Executables"],
            capture_output=True,
            text=True,
        )
        version = ""
        for line in result.stdout.splitlines():
            if line.startswith("version:"):
                version = line.split(":", 1)[1].strip()
                break
        suffix = f" (v{version})" if version else ""
        console.print(f"[green]✓[/]  Xcode Command Line Tools already installed{suffix}.\n")
        return

    console.print("  Installing Xcode Command Line Tools...")
    console.print("  [dim]This may take a few minutes.[/]\n")

    # Create trigger file so softwareupdate lists CLT
    console.print("  [dim]Looking for CLT package...[/]")
    try:
        subprocess.run(
            ["sudo", "touch", str(_TRIGGER)],
        )
    except Exception:
        pass

    label = _find_clt_package()
    # Clean up trigger regardless
    _TRIGGER.unlink(missing_ok=True)

    if not label:
        console.print(
            "[red]✗[/]  No CLT package found via softwareupdate.\n"
            "    Try the interactive installer instead:\n"
            "    [cyan]xcode-select --install[/]"
        )
        raise SystemExit(1)

    console.print(f"  Installing: [bold]{label}[/]\n")
    result = subprocess.run(
        ["sudo", "softwareupdate", "-i", label, "--verbose"],
    )

    if result.returncode != 0:
        console.print(
            "\n[red]✗[/]  Installation failed.\n"
            "    Try the interactive installer:\n"
            "    [cyan]xcode-select --install[/]"
        )
        raise SystemExit(1)

    if _clt_installed():
        console.print("\n[green]✓[/]  Xcode Command Line Tools installed.\n")
    else:
        console.print(
            "\n[yellow]⚠[/]  softwareupdate completed but CLT not detected.\n"
            "    Try: [cyan]xcode-select --install[/]"
        )
        raise SystemExit(1)
