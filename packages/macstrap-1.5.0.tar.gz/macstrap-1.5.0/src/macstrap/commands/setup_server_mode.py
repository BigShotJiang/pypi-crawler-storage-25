"""macstrap local setup-server-mode – configure macOS for always-on server use."""

from __future__ import annotations

import subprocess
import sys

import click
from rich.console import Console

console = Console()

# Each entry: (description, pmset/command args)
_PMSET_SETTINGS: list[tuple[str, list[str]]] = [
    ("永不休眠 (system sleep disabled)",      ["sleep", "0"]),
    ("螢幕永不關閉 (display sleep disabled)", ["displaysleep", "0"]),
    ("硬碟永不休眠 (disk sleep disabled)",     ["disksleep", "0"]),
    ("斷電後自動重新開機 (auto restart on power loss)", ["autorestart", "1"]),
    ("網路喚醒 (Wake-on-LAN enabled)",        ["womp", "1"]),
]


def _run_pmset(args: list[str]) -> bool:
    """Run a pmset command with sudo. Returns True on success."""
    result = subprocess.run(
        ["sudo", "pmset", "-a"] + args,
        capture_output=True,
        text=True,
    )
    return result.returncode == 0


def _get_current_pmset() -> dict[str, str]:
    """Parse current pmset settings into a dict."""
    result = subprocess.run(
        ["pmset", "-g", "custom"],
        capture_output=True,
        text=True,
    )
    settings = {}
    for line in result.stdout.splitlines():
        line = line.strip()
        if not line or line.startswith("Battery") or line.startswith("AC"):
            continue
        parts = line.split()
        if len(parts) >= 2:
            settings[parts[0]] = parts[1]
    return settings


@click.command("setup-server-mode")
def cmd_setup_server_mode() -> None:
    """Configure this Mac for always-on server use.

    \b
    Applies recommended pmset settings for a headless Mac mini
    or any Mac used as an always-on server:

      - Disable system, display, and disk sleep
      - Auto-restart after power failure
      - Enable Wake-on-LAN
    """
    if sys.platform != "darwin":
        console.print("[red]\u2717[/]  This command is only available on macOS.")
        raise SystemExit(1)

    console.print()
    console.print("[bold]Configuring server mode...[/]")
    console.print("  [dim]You may be prompted for your sudo password.[/]\n")

    current = _get_current_pmset()
    applied = 0
    skipped = 0

    for description, args in _PMSET_SETTINGS:
        key = args[0]
        desired = args[1]
        current_val = current.get(key)

        if current_val == desired:
            console.print(f"  [green]\u2713[/]  {description}  [dim](already set)[/]")
            skipped += 1
            continue

        if _run_pmset(args):
            console.print(f"  [green]\u2713[/]  {description}")
            applied += 1
        else:
            console.print(f"  [red]\u2717[/]  {description}  [dim](failed)[/]")

    console.print()
    if applied > 0:
        console.print(f"  [green]\u2713[/]  {applied} setting(s) applied, {skipped} already correct.\n")
    else:
        console.print("  [green]\u2713[/]  All settings already configured for server mode.\n")

    # Show summary
    console.print("[bold]Current power settings:[/]")
    subprocess.run(["pmset", "-g"])
    console.print()
