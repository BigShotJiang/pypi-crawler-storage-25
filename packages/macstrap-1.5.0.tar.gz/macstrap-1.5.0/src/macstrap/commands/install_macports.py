"""macstrap local install-macports – install MacPorts."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError

import click
from rich.console import Console

console = Console()

_PORT_BIN = Path("/opt/local/bin/port")

# macOS major version → codename (must match Ansible role defaults)
_MACOS_NAME_MAP = {
    "13": "Ventura",
    "14": "Sonoma",
    "15": "Sequoia",
    "16": "Tahoe",
    "26": "Tahoe",
}


def _port_installed() -> bool:
    return _PORT_BIN.exists()


def _macos_major() -> str:
    result = subprocess.run(
        ["sw_vers", "-productVersion"],
        capture_output=True,
        text=True,
    )
    return result.stdout.strip().split(".")[0]


def _latest_macports_version() -> str | None:
    """Fetch latest MacPorts version tag from GitHub."""
    req = Request(
        "https://api.github.com/repos/macports/macports-base/releases/latest",
        headers={"Accept": "application/vnd.github.v3+json"},
    )
    try:
        with urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read())
            return data["tag_name"].lstrip("v")
    except (URLError, KeyError, json.JSONDecodeError):
        return None


@click.command("install-macports")
def cmd_install_macports() -> None:
    """Install MacPorts package manager.

    \b
    Auto-detects macOS version and downloads the matching
    MacPorts .pkg installer from GitHub releases.
    """
    if sys.platform != "darwin":
        console.print("[red]✗[/]  This command is only available on macOS.")
        raise SystemExit(1)

    if _port_installed():
        result = subprocess.run(
            [str(_PORT_BIN), "version"],
            capture_output=True,
            text=True,
        )
        version = result.stdout.strip() if result.stdout else "MacPorts"
        console.print(f"[green]✓[/]  MacPorts is already installed ({version}).\n")
        return

    # ── Detect macOS version ──────────────────────────────────────────────
    major = _macos_major()
    codename = _MACOS_NAME_MAP.get(major)
    if not codename:
        console.print(
            f"[red]✗[/]  macOS {major} is not in the known version map.\n"
            "    Please install MacPorts manually:\n"
            "    [cyan]https://www.macports.org/install.php[/]"
        )
        raise SystemExit(1)

    # ── Fetch latest version ──────────────────────────────────────────────
    console.print("  [dim]Checking latest MacPorts release...[/]")
    version = _latest_macports_version()
    if not version:
        console.print(
            "[red]✗[/]  Could not fetch latest MacPorts version from GitHub.\n"
            "    Please install manually:\n"
            "    [cyan]https://www.macports.org/install.php[/]"
        )
        raise SystemExit(1)

    pkg_name = f"MacPorts-{version}-{major}-{codename}.pkg"
    pkg_url = f"https://github.com/macports/macports-base/releases/download/v{version}/{pkg_name}"
    pkg_path = f"/tmp/{pkg_name}"

    console.print(f"  Installing MacPorts {version} for macOS {major} ({codename})")
    console.print(f"  [dim]{pkg_url}[/]\n")

    # ── Download ──────────────────────────────────────────────────────────
    console.print("  Downloading...")
    result = subprocess.run(
        ["curl", "-fSL", "-o", pkg_path, pkg_url],
    )
    if result.returncode != 0:
        console.print(
            f"\n[red]✗[/]  Download failed. The installer may not exist for macOS {major}.\n"
            "    Check: [cyan]https://github.com/macports/macports-base/releases/latest[/]\n"
            "    Or install manually: [cyan]https://www.macports.org/install.php[/]"
        )
        raise SystemExit(1)

    # ── Install ───────────────────────────────────────────────────────────
    console.print("  Installing (requires sudo)...\n")
    result = subprocess.run(
        ["sudo", "installer", "-pkg", pkg_path, "-target", "/"],
    )
    if result.returncode != 0:
        console.print(
            "\n[red]✗[/]  MacPorts installation failed.\n"
            "    Try running manually:\n"
            f"    [cyan]sudo installer -pkg {pkg_path} -target /[/]"
        )
        raise SystemExit(1)

    # ── Clean up ──────────────────────────────────────────────────────────
    Path(pkg_path).unlink(missing_ok=True)

    if _port_installed():
        console.print("[green]✓[/]  MacPorts installed.\n")
        console.print(
            "  Add to your PATH if not already present:\n"
            "    [cyan]export PATH=/opt/local/bin:/opt/local/sbin:$PATH[/]\n"
        )
    else:
        console.print(
            "[yellow]⚠[/]  Installer completed but /opt/local/bin/port not found.\n"
            "    Try opening a new terminal or check the installation."
        )
        raise SystemExit(1)
