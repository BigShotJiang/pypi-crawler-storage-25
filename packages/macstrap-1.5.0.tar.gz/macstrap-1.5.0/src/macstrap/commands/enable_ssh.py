"""macstrap enable-ssh – enable the macOS SSH server (Remote Login)."""

from __future__ import annotations

import getpass
import subprocess
import sys

import click
from rich.console import Console

console = Console()


def _is_ssh_running() -> bool:
    """Return True if sshd is listening on port 22."""
    result = subprocess.run(
        ["nc", "-z", "-w2", "localhost", "22"],
        capture_output=True,
    )
    return result.returncode == 0


def _get_local_hostname() -> str:
    """Return the Bonjour/mDNS hostname (e.g. 'mac-mini')."""
    result = subprocess.run(
        ["scutil", "--get", "LocalHostName"],
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


@click.command("enable-ssh")
def cmd_enable_ssh() -> None:
    """Enable the macOS SSH server (Remote Login).

    \b
    Run this on a fresh Mac so other machines can reach it via SSH.
    After enabling, use macstrap ssh-auth from another machine to
    set up key-based auth and store credentials.
    """
    if sys.platform != "darwin":
        console.print("[red]✗[/]  This command is only available on macOS.")
        raise SystemExit(1)

    hostname = _get_local_hostname()
    user = getpass.getuser()

    if _is_ssh_running():
        console.print("[green]✓[/]  Remote Login (SSH) is already enabled.\n")
    else:
        console.print("  Enabling Remote Login (SSH)...")
        console.print("  [dim]You will be prompted for your sudo password.[/]\n")
        result = subprocess.run(
            ["sudo", "systemsetup", "-setremotelogin", "on"],
        )
        if result.returncode != 0:
            console.print(
                "\n[red]✗[/]  Failed to enable Remote Login.\n"
                "    Try running manually:\n"
                "    [cyan]sudo systemsetup -setremotelogin on[/]"
            )
            raise SystemExit(1)
        console.print("\n[green]✓[/]  Remote Login (SSH) enabled.\n")

    console.print(f"  This Mac is reachable at:  [bold]{hostname}.local[/]")
    console.print(f"  SSH user:                  [bold]{user}[/]\n")
    console.print("  Test from another machine:")
    console.print(f"    [cyan]ssh {user}@{hostname}.local[/]\n")
    console.print("[bold]Next step:[/] on the other machine, run:")
    console.print(f"    [cyan]macstrap ssh-auth {hostname}.local[/]\n")
