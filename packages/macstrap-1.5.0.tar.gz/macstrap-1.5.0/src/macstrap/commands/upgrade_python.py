"""macstrap local upgrade-python – install a newer Python via Homebrew."""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

import click
from rich.console import Console

from macstrap import MIN_PYTHON_REMOTE
from macstrap.commands.install_brew import _brew_installed, _add_shellenv, _BREW_BIN, _INSTALL_URL

console = Console()

DEFAULT_BREW_PYTHON = "python3"
_BREW_PYTHON3 = Path("/opt/homebrew/bin/python3")


def _install_homebrew() -> bool:
    """Install Homebrew. Returns True on success."""
    console.print("  Homebrew is not installed. Installing now...\n")
    console.print("  [dim]You may be prompted for your sudo password.[/]\n")

    # Download to a temp file and execute, so stdin stays connected to the
    # TTY and Homebrew's installer can prompt for sudo interactively.
    with tempfile.NamedTemporaryFile(suffix=".sh", delete=False) as tmp:
        tmp_path = Path(tmp.name)

    curl = subprocess.run(
        ["curl", "-fsSL", "-o", str(tmp_path), _INSTALL_URL],
    )
    if curl.returncode != 0:
        tmp_path.unlink(missing_ok=True)
        console.print(
            "\n[red]\u2717[/]  Failed to download the Homebrew installer.\n"
            f"    Try manually: [cyan]/bin/bash -c \"$(curl -fsSL {_INSTALL_URL})\"[/]\n"
        )
        return False

    result = subprocess.run(["/bin/bash", str(tmp_path)])
    tmp_path.unlink(missing_ok=True)

    if result.returncode != 0 or not _brew_installed():
        console.print(
            "\n[red]\u2717[/]  Homebrew installation failed.\n"
            "    Try installing manually:\n"
            f"    [cyan]/bin/bash -c \"$(curl -fsSL {_INSTALL_URL})\"[/]\n"
        )
        return False

    _add_shellenv()
    console.print("\n[green]\u2713[/]  Homebrew installed.\n")
    return True


@click.command("upgrade-python")
def cmd_upgrade_python() -> None:
    """Ensure Python meets the minimum version for remote commands.

    \b
    Checks the running Python version against the minimum required
    for remote features (ansible-core). If too old, installs Homebrew
    (if needed) and then a newer Python via Homebrew.
    """
    major, minor = MIN_PYTHON_REMOTE
    current = sys.version_info

    if current >= MIN_PYTHON_REMOTE:
        console.print(
            f"[green]\u2713[/]  Python {current[0]}.{current[1]} "
            f"already meets the minimum ({major}.{minor}+).\n"
        )
        # Check if remote extra is installed
        try:
            import ansible  # noqa: F401
            console.print("  [green]\u2713[/]  ansible-core is installed. Remote commands are ready.\n")
        except ImportError:
            console.print(
                "  [yellow]\u26a0[/]  ansible-core is not installed.\n"
                "    To enable remote commands:\n"
                "      [cyan]pip install macstrap\\[remote][/]\n"
            )
        return

    console.print(
        f"  Current Python: [bold]{current[0]}.{current[1]}.{current[2]}[/]\n"
        f"  Required:       [bold]{major}.{minor}+[/] (for remote commands)\n"
    )

    # Install Homebrew if needed
    if not _brew_installed():
        if not _install_homebrew():
            raise SystemExit(1)

    console.print(f"  Installing [bold]{DEFAULT_BREW_PYTHON}[/] via Homebrew...\n")
    result = subprocess.run(
        [str(_BREW_BIN), "install", DEFAULT_BREW_PYTHON],
    )

    if result.returncode != 0:
        console.print(
            f"\n[red]\u2717[/]  Failed to install {DEFAULT_BREW_PYTHON}.\n"
            f"    Try manually: [cyan]brew install {DEFAULT_BREW_PYTHON}[/]\n"
        )
        raise SystemExit(1)

    # Verify
    if _BREW_PYTHON3.exists():
        ver_result = subprocess.run(
            [str(_BREW_PYTHON3), "--version"],
            capture_output=True,
            text=True,
        )
        ver = ver_result.stdout.strip() if ver_result.stdout else "Python"
        console.print(f"\n[green]\u2713[/]  {ver} installed via Homebrew.\n")
    else:
        console.print(f"\n[green]\u2713[/]  {DEFAULT_BREW_PYTHON} installed.\n")

    console.print(
        "[bold]Next steps:[/]\n\n"
        "  1. Exit the current venv and start a new shell (so Homebrew Python takes effect):\n"
        "       [cyan]deactivate && exec zsh[/]\n\n"
        "  2. Reinstall macstrap with remote support:\n"
        f"       [cyan]{_BREW_PYTHON3} -m pip install macstrap\\[remote][/]\n"
    )
