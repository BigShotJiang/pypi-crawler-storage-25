"""macstrap CLI commands."""
