"""macstrap local install-brew – install Homebrew."""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

import click
from rich.console import Console

console = Console()

_BREW_BIN = Path("/opt/homebrew/bin/brew")
_SHELLENV_LINE = 'eval "$(/opt/homebrew/bin/brew shellenv)"'
_INSTALL_URL = "https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh"


def _brew_installed() -> bool:
    return _BREW_BIN.exists()


def _add_shellenv() -> None:
    """Ensure Homebrew shellenv is in .zshenv, .zprofile, and .zshrc."""
    home = Path.home()
    for rc in [home / ".zshenv", home / ".zprofile", home / ".zshrc"]:
        if rc.exists() and _SHELLENV_LINE in rc.read_text():
            continue
        with rc.open("a") as f:
            f.write(f"\n{_SHELLENV_LINE}\n")
        console.print(f"  [dim]Added shellenv to {rc.name}[/]")


@click.command("install-brew")
def cmd_install_brew() -> None:
    """Install Homebrew package manager.

    \b
    Installs Homebrew to /opt/homebrew and adds shellenv to
    .zprofile and .zshrc so it's available in new shells.
    """
    if sys.platform != "darwin":
        console.print("[red]✗[/]  This command is only available on macOS.")
        raise SystemExit(1)

    if _brew_installed():
        result = subprocess.run(
            [str(_BREW_BIN), "--version"],
            capture_output=True,
            text=True,
        )
        version = result.stdout.splitlines()[0] if result.stdout else "Homebrew"
        console.print(f"[green]✓[/]  {version} is already installed.\n")
        _add_shellenv()
        return

    console.print("  Installing Homebrew...")
    console.print("  [dim]You may be prompted for your sudo password.[/]\n")

    # Download to a temp file and execute, so stdin stays connected to the
    # TTY and Homebrew's installer can prompt for sudo interactively.
    with tempfile.NamedTemporaryFile(suffix=".sh", delete=False) as tmp:
        tmp_path = Path(tmp.name)

    curl = subprocess.run(
        ["curl", "-fsSL", "-o", str(tmp_path), _INSTALL_URL],
    )
    if curl.returncode != 0:
        tmp_path.unlink(missing_ok=True)
        console.print(
            "\n[red]\u2717[/]  Failed to download the Homebrew installer.\n"
            f"    Try manually: [cyan]/bin/bash -c \"$(curl -fsSL {_INSTALL_URL})\"[/]"
        )
        raise SystemExit(1)

    result = subprocess.run(["/bin/bash", str(tmp_path)])
    tmp_path.unlink(missing_ok=True)

    if result.returncode != 0 or not _brew_installed():
        console.print(
            "\n[red]✗[/]  Homebrew installation failed.\n"
            "    Try installing manually:\n"
            f"    [cyan]/bin/bash -c \"$(curl -fsSL {_INSTALL_URL})\"[/]"
        )
        raise SystemExit(1)

    _add_shellenv()
    console.print("\n[green]✓[/]  Homebrew installed.\n")
    console.print("  Run [cyan]exec zsh[/] or open a new terminal to use [bold]brew[/].\n")
