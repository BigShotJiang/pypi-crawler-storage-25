"""macstrap – main CLI entry point."""

from __future__ import annotations

import click
from rich.console import Console

from macstrap import __version__
from macstrap.commands.enable_ssh import cmd_enable_ssh
from macstrap.commands.install_brew import cmd_install_brew
from macstrap.commands.install_macports import cmd_install_macports
from macstrap.commands.install_xcode import cmd_install_xcode
from macstrap.commands.setup_server_mode import cmd_setup_server_mode
from macstrap.commands.upgrade_python import cmd_upgrade_python

# Remote commands may fail to import on Python 3.9 without ansible-core.
# All current remote modules import fine on 3.9, but wrap defensively so
# future changes don't cause a traceback at startup.
try:
    from macstrap.commands.hosts import cmd_delete, cmd_delete_all, cmd_list
    from macstrap.commands.init import cmd_init
    from macstrap.commands.run import cmd_run
    from macstrap.commands.ssh_auth import cmd_ssh_auth
    from macstrap.commands.verify import cmd_verify
    _REMOTE_AVAILABLE = True
except ImportError:
    _REMOTE_AVAILABLE = False

console = Console()

CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}


def _make_stub(name: str) -> click.Command:
    """Create a placeholder command that prints an upgrade hint."""
    @click.command(name)
    @click.argument("args", nargs=-1, type=click.UNPROCESSED)
    def stub(**kwargs):  # type: ignore[no-untyped-def]
        console.print(
            f"[red]\u2717[/]  [bold]{name}[/] requires Python 3.10+ and ansible-core.\n\n"
            "    To set up:\n"
            "      1. [cyan]macstrap local upgrade-python[/]\n"
            "      2. [cyan]pip install macstrap\\[remote][/]\n"
        )
        raise SystemExit(1)
    return stub


@click.group(context_settings=CONTEXT_SETTINGS)
@click.version_option(__version__, "-V", "--version")
def main() -> None:
    """macstrap – Mac setup tool.

    \b
    Local commands (run on the Mac itself):

      macstrap local enable-ssh            enable SSH server (Remote Login)
      macstrap local install-xcode         install Xcode Command Line Tools
      macstrap local install-brew          install Homebrew
      macstrap local install-macports      install MacPorts
      macstrap local upgrade-python        ensure Python meets remote requirements
      macstrap local setup-server-mode     configure always-on server settings

    \b
    Remote commands (run from another machine):

      macstrap init                        generate package list files
      macstrap ssh-auth <host>             store sudo password
      macstrap run [host]                  apply setup to a Mac
      macstrap verify [host]               check packages are installed
      macstrap list                        show registered hosts
      macstrap delete <host>               remove credentials for a host
      macstrap delete-all                  remove all credentials

    \b
    Package files (edit to customise what gets installed):

      packages-macports.txt
      packages-brew.txt
      packages-brew-casks.txt
      packages-npm-global.txt
      packages-pip-global.txt
    """


# ── Local subcommand group ────────────────────────────────────────────────

@click.group("local", context_settings=CONTEXT_SETTINGS)
def local_group() -> None:
    """Commands that run on this Mac locally."""


local_group.add_command(cmd_enable_ssh,       name="enable-ssh")
local_group.add_command(cmd_install_brew,     name="install-brew")
local_group.add_command(cmd_install_macports, name="install-macports")
local_group.add_command(cmd_install_xcode,    name="install-xcode")
local_group.add_command(cmd_setup_server_mode, name="setup-server-mode")
local_group.add_command(cmd_upgrade_python,   name="upgrade-python")

main.add_command(local_group,    name="local")

# ── Remote commands ───────────────────────────────────────────────────────

if _REMOTE_AVAILABLE:
    main.add_command(cmd_init,       name="init")
    main.add_command(cmd_ssh_auth,   name="ssh-auth")
    main.add_command(cmd_run,        name="run")
    main.add_command(cmd_verify,     name="verify")
    main.add_command(cmd_list,       name="list")
    main.add_command(cmd_delete,     name="delete")
    main.add_command(cmd_delete_all, name="delete-all")
else:
    for _name in ("init", "ssh-auth", "run", "verify", "list", "delete", "delete-all"):
        main.add_command(_make_stub(_name), name=_name)
