"""macstrap – Remote Mac setup and package management via SSH."""

__version__ = "1.5.0"
__author__ = "changyy"
__email__ = "changyy.csie@gmail.com"

# Minimum Python version required for remote commands (ansible-core).
# Bump this when upstream dependencies raise their floor.
MIN_PYTHON_REMOTE = (3, 10)
