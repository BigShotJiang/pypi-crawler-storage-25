"""macstrap compatibility helpers – runtime checks for remote features."""

from __future__ import annotations

import sys

from rich.console import Console

from macstrap import MIN_PYTHON_REMOTE

console = Console()


def require_remote() -> None:
    """Check that the current environment supports remote commands.

    Verifies Python version and ansible-core availability.
    Prints a helpful message and exits if either check fails.
    """
    major, minor = MIN_PYTHON_REMOTE
    if sys.version_info < MIN_PYTHON_REMOTE:
        console.print(
            f"[red]\u2717[/]  This command requires Python {major}.{minor}+.\n"
            f"    Current: Python {sys.version_info[0]}.{sys.version_info[1]}\n\n"
            "    To upgrade:\n"
            "      [cyan]macstrap local upgrade-python[/]\n"
        )
        raise SystemExit(1)

    try:
        import ansible  # noqa: F401
    except ImportError:
        console.print(
            "[red]\u2717[/]  ansible-core is not installed.\n"
            "    Remote commands require the [bold]remote[/] extra:\n\n"
            "      [cyan]pip install macstrap\\[remote][/]\n"
        )
        raise SystemExit(1)
