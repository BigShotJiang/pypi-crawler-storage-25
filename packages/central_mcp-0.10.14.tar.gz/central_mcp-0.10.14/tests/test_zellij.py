"""Tests for the Zellij observation backend.

Unit tests exercise the KDL layout generation (pure function, no
subprocess). The module's session helpers (`has_session`, `kill_session`,
etc.) require a real zellij binary and aren't covered here — those
are reserved for a live test once a zellij-equivalent of tmux live
testing infrastructure is in place.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from central_mcp import registry, zellij
from central_mcp.layout import OrchestratorPane, window_name, HUB_SUFFIX


class TestBuildLayout:
    def test_empty_registry_produces_single_placeholder_tab(
        self, fake_home: Path
    ) -> None:
        kdl = zellij.build_layout()
        assert kdl.startswith("layout {")
        assert kdl.rstrip().endswith("}")
        assert "cmcp-1" in kdl

    def test_orchestrator_tab_has_hub_suffix(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        d = tmp_path / "proj"
        d.mkdir()
        registry.add_project("proj", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(orchestrator=orch)
        assert f'tab name="{window_name(0, has_orchestrator=True)}"' in kdl
        assert HUB_SUFFIX in kdl
        assert "Central MCP Orchestrator" in kdl
        assert "proj" in kdl

    def test_hub_flattens_orchestrator_with_projects(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        """0.6.3+: orchestrator is no longer fixed at 50% of the hub
        tab; it sits in the flat grid alongside project panes, equal
        width with its row mates.
        """
        for i in range(2):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(
            orchestrator=orch, term_size=(200, 50),
        )
        # With 3 panes (orch + 2 projects) on a wide terminal,
        # pick_rows returns 1, yielding a single row with a single
        # vertical split encompassing all three panes equally.
        assert 'split_direction="vertical"' in kdl
        # Orchestrator should appear before project panes in KDL order.
        orch_idx = kdl.index("Central MCP Orchestrator")
        p0_idx = kdl.index('"p0"')
        assert orch_idx < p0_idx

    def test_overflow_tabs_follow_cmcp_n_naming(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        # 1 orch + 6 projects = 1 orch + 2 in hub + 4 in overflow tab (panes_per_window=4).
        for i in range(6):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(orchestrator=orch)
        assert f'tab name="{window_name(0, has_orchestrator=True)}"' in kdl
        assert f'tab name="{window_name(1, has_orchestrator=True)}"' in kdl

    def test_no_orchestrator_uses_plain_cmcp_1(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        for i in range(3):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        kdl = zellij.build_layout()
        assert f'tab name="{window_name(0)}"' in kdl
        assert HUB_SUFFIX not in kdl

    def test_invalid_panes_per_window_rejected(self, fake_home: Path) -> None:
        with pytest.raises(ValueError, match="panes_per_window"):
            zellij.build_layout(panes_per_window=0)

    def test_first_tab_holds_panes_per_window_panes(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        """0.6.3+: the orchestrator no longer gets a 2-cell visual
        weight, so the first tab holds the full `panes_per_window`
        count — orchestrator plus (panes_per_window - 1) projects.
        """
        for i in range(6):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(orchestrator=orch, panes_per_window=4)

        # First tab: orch + p0, p1, p2 (4 panes total).
        first_start = kdl.index(f'tab name="{window_name(0, has_orchestrator=True)}"')
        next_tab = kdl.find('tab name="', first_start + 1)
        first_block = kdl[first_start:next_tab] if next_tab != -1 else kdl[first_start:]
        assert "Central MCP Orchestrator" in first_block
        for i in range(3):
            assert f'"p{i}"' in first_block
        assert '"p3"' not in first_block
        # p3, p4, p5 should be in the overflow tab.
        tail = kdl[next_tab:] if next_tab != -1 else ""
        for i in range(3, 6):
            assert f'"p{i}"' in tail

    def test_project_pane_invokes_central_mcp_watch(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        d = tmp_path / "alpha"
        d.mkdir()
        registry.add_project("alpha", str(d), agent="shell")

        kdl = zellij.build_layout()
        # Each project pane is wrapped in `sh -c '<cmd> </dev/null; sleep infinity'`
        # so the pane is read-only (stdin piped from /dev/null) and
        # stays alive on exit without dropping to a shell.
        assert 'command="sh"' in kdl
        assert "central-mcp watch alpha" in kdl
        assert "</dev/null" in kdl
        assert "sleep infinity" in kdl


class TestTilingShape:
    """Verify the 2-row wide-column tiling algorithm.

    The underlying `_tile_panes` helper is internal, so we inspect the
    generated KDL to assert the structural contract: at most `rows=2`
    rows, columns grow horizontally, small pane counts collapse to a
    single horizontal row.
    """

    def _count(self, kdl: str, needle: str) -> int:
        return kdl.count(needle)

    def test_overflow_four_panes_build_2x2_grid(
        self, fake_home, tmp_path
    ) -> None:
        # 4 projects total = 4 in overflow tab (no orchestrator).
        for i in range(4):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        # Force wide-terminal regime so the 2×2 grid actually fires —
        # on a narrow terminal we'd fall back to a pure vertical stack.
        kdl = zellij.build_layout(panes_per_window=4, term_size=(200, 100))
        # 4 panes should produce 2 rows, each a vertical (side-by-side)
        # split — i.e., one outer horizontal + two inner vertical splits.
        assert 'split_direction="horizontal"' in kdl
        assert self._count(kdl, 'split_direction="vertical"') >= 2, (
            "expected at least two vertical splits for a 2x2 grid"
        )

    def test_overflow_ten_panes_grow_horizontally(
        self, fake_home, tmp_path
    ) -> None:
        # 10 projects with panes_per_window=10 → one overflow tab with
        # 10 panes, which should render as 2 rows × 5 cols (wide),
        # not 5 rows × 2 cols (tall).
        for i in range(10):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        kdl = zellij.build_layout(panes_per_window=10, term_size=(300, 60))
        # The top row contains p0..p4; the bottom row contains p5..p9.
        # Find the order of project names in the KDL and assert the
        # expected grouping.
        positions = [kdl.index(f'"p{i}"') for i in range(10)]
        # Top row (p0..p4) should appear before the bottom row (p5..p9).
        assert max(positions[:5]) < min(positions[5:]), (
            f"top row panes should come before bottom row panes; positions={positions}"
        )

    def test_hub_with_three_projects_uses_grid_on_right(
        self, fake_home, tmp_path
    ) -> None:
        # Orchestrator + 3 project panes in hub (panes_per_window=5 →
        # hub holds orch + 3 projects).
        for i in range(3):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(
            orchestrator=orch, panes_per_window=5, term_size=(200, 50),
        )

        # When the right half has 3 panes, we should see the 2-row grid:
        # outer vertical (orch | right-block), right-block is horizontal
        # (top row | bot row), top row is vertical (p0 p1).
        # At minimum: at least 3 `split_direction="vertical"` occurrences
        # (outer orch-vs-right + top row + any other row-internal splits).
        assert self._count(kdl, 'split_direction="vertical"') >= 2

    def test_hub_with_two_projects_keeps_vertical_stack(
        self, fake_home, tmp_path
    ) -> None:
        """Regression guard: orch + 2 projects should NOT trigger the
        new 2-row grid — halving a narrow right column into a 2-col
        row would make each project pane unreadably thin."""
        for i in range(2):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(
            orchestrator=orch, panes_per_window=4, term_size=(200, 50),
        )
        # Stack-style right block uses exactly one horizontal split
        # (the right-side children); the outer vertical is the
        # orchestrator-vs-right divider. So total vertical splits = 1.
        # Project panes appear in order top-to-bottom, stacked.
        p0_idx = kdl.index('"p0"')
        p1_idx = kdl.index('"p1"')
        assert p0_idx < p1_idx


class TestOrchestratorColumn:
    """0.6.4+: orchestrator pane gets a full-height left column sized
    to match one project column, instead of the 0.6.3 flat grid that
    treated it as just one of N equal-width cells.
    """

    def test_orch_column_has_size_attribute(
        self, fake_home, tmp_path
    ) -> None:
        # 2 projects → rows=1, top_cols=2. Orch column = 1/(2+1) = 33%.
        for i in range(2):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(
            orchestrator=orch, term_size=(200, 50), panes_per_window=4,
        )
        # The orchestrator's pane block should carry `size="<N>%"`.
        orch_line_idx = kdl.index("Central MCP Orchestrator")
        # Walk back to the containing `pane name=...` line, then check
        # the same line has a size attribute.
        line_start = kdl.rfind("pane name=", 0, orch_line_idx)
        line_end = kdl.find("\n", line_start)
        orch_line = kdl[line_start:line_end]
        assert 'size="' in orch_line, f"orch line missing size attr: {orch_line!r}"

    def test_orch_with_one_project_is_fifty_fifty(
        self, fake_home, tmp_path
    ) -> None:
        # 1 project → rows=1, top_cols=1. Orch = 1/(1+1) = 50%.
        d = tmp_path / "solo"
        d.mkdir()
        registry.add_project("solo", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(
            orchestrator=orch, term_size=(200, 50), panes_per_window=4,
        )
        # Find the orch pane's size attribute and assert 50.
        orch_idx = kdl.index("Central MCP Orchestrator")
        line_start = kdl.rfind("pane name=", 0, orch_idx)
        line_end = kdl.find("\n", line_start)
        orch_line = kdl[line_start:line_end]
        assert 'size="50%"' in orch_line, orch_line

    def test_overflow_tab_does_not_use_orch_column(
        self, fake_home, tmp_path
    ) -> None:
        # 6 projects with panes_per_window=4 → tab 0 (orch + 3 projects)
        # uses the orch column, tab 1 (3 projects, no orch) does NOT.
        for i in range(6):
            d = tmp_path / f"p{i}"
            d.mkdir()
            registry.add_project(f"p{i}", str(d), agent="shell")

        orch = OrchestratorPane(command="echo hi", cwd=str(tmp_path), label="stub")
        kdl = zellij.build_layout(
            orchestrator=orch, term_size=(200, 50), panes_per_window=4,
        )
        # Split the KDL at the overflow tab and inspect only that block.
        overflow_tab_name = window_name(1, has_orchestrator=True)
        overflow_start = kdl.index(f'tab name="{overflow_tab_name}"')
        overflow_block = kdl[overflow_start:]
        # Orchestrator shouldn't appear in the overflow, and no project
        # pane there should carry a manually-set size attribute (they
        # default to equal-share within the grid).
        assert "Central MCP Orchestrator" not in overflow_block
        # `size="` attributes only appear on the orch column — absent
        # in the overflow tab.
        assert 'size="' not in overflow_block


class TestWriteLayout:
    def test_creates_parent_and_writes_kdl(
        self, fake_home: Path, tmp_path: Path
    ) -> None:
        target = tmp_path / "nested" / "layout.kdl"
        assert not target.exists()
        path = zellij.write_layout(target)
        assert path == target
        assert target.exists()
        body = target.read_text()
        assert body.startswith("layout {")
