from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from ..errors import AgentTimeoutError, UsageLimitError
from ..status_display import StatusDisplay


class PhaseRow:
    def __init__(self, status_display: StatusDisplay, caller: str) -> None:
        self._status_display = status_display
        self._caller = caller
        self._closed = False

    def close(self, shutdown_message: str, shutdown_style: str = "success") -> None:
        if self._closed:
            return
        self._status_display.remove(self._caller, shutdown_message, shutdown_style)
        self._closed = True


@asynccontextmanager
async def phase_row(
    status_display: StatusDisplay,
    caller: str,
    initial_phase: str = "Setup",
    startup_message: str = "started",
) -> AsyncGenerator[PhaseRow, None]:
    status_display.register(
        caller, "phase", startup_message=startup_message, initial_phase=initial_phase
    )
    row = PhaseRow(status_display, caller)
    try:
        yield row
    except UsageLimitError:
        row.close("usage limit reached", shutdown_style="interrupted")
        raise
    except AgentTimeoutError:
        row.close("timed out", shutdown_style="interrupted")
        raise
    except BaseException:
        row.close("failed", shutdown_style="error")
        raise
    else:
        if not row._closed:
            row.close("failed", shutdown_style="error")


@asynccontextmanager
async def agent_row(
    status_display: StatusDisplay,
    caller: str,
    work_body: str,
) -> AsyncGenerator[None, None]:
    status_display.register(caller, "agent", work_body=work_body)
    try:
        yield None
    except BaseException:
        status_display.remove(caller, "failed", shutdown_style="error")
        raise
    else:
        status_display.remove(caller)
