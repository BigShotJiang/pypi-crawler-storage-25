## Agent skills

### Issue tracker

Issues live in GitHub Issues (`Johannes-Kutsch/pycastle`). See `docs/agents/issue-tracker.md`.

### Domain docs

Single-context repo — `CONTEXT.md` at the root plus `docs/adr/`. See `docs/agents/domain.md`.
