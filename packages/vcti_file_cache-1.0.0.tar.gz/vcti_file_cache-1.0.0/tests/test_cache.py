# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for FileCache, ModelDir, CacheManager, and eviction policies."""

import json
import logging
import os
import sys
import threading
import time
from pathlib import Path

import pytest

from vcti.filecache import (
    CacheManagerConfig,
    CacheObserver,
    CacheSnapshot,
    FileCache,
    LfuPolicy,
    LocalStorage,
    LoggingObserver,
    LruPolicy,
    ModelDir,
    ModelInfo,
    SizedLruPolicy,
    run_eviction,
)
from vcti.filecache.manager import CacheManager
from vcti.filecache.storage import CACHE_META, _is_process_alive


def _test_config(evict_above: int = 10000, **kwargs) -> CacheManagerConfig:
    """Create a CacheManagerConfig with a long interval for tests."""
    return CacheManagerConfig(evict_above=evict_above, interval=9999, **kwargs)


def _storage(tmp_path: Path) -> LocalStorage:
    """Create a LocalStorage rooted at tmp_path."""
    return LocalStorage(tmp_path)


class _RecordingObserver(CacheObserver):
    """Test observer that records all events and signals on cycle complete."""

    def __init__(self) -> None:
        self.evictions: list[str] = []
        self.size_updates: list[tuple[str, int]] = []
        self.errors: list[tuple[Exception, str]] = []
        self.cycles: list[tuple[int, int]] = []
        self.cycle_event = threading.Event()

    def on_evict(self, path: str) -> None:
        self.evictions.append(path)

    def on_size_update(self, path: str, size: int) -> None:
        self.size_updates.append((path, size))

    def on_error(self, error: Exception, context: str) -> None:
        self.errors.append((error, context))

    def on_cycle_complete(self, total_size: int, entry_count: int) -> None:
        self.cycles.append((total_size, entry_count))
        self.cycle_event.set()

    def wait_for_cycle(self, timeout: float = 5.0) -> bool:
        """Wait for the next cycle to complete. Returns True if signalled."""
        result = self.cycle_event.wait(timeout=timeout)
        self.cycle_event.clear()
        return result


class _FailingStorage:
    """Fake storage that raises on delete_dir for testing observer errors."""

    def __init__(self, real_storage: LocalStorage) -> None:
        self._real = real_storage

    def key(self) -> str:
        return self._real.key()

    def create_dir(self, rel_path: str) -> None:
        self._real.create_dir(rel_path)

    def delete_dir(self, rel_path: str) -> None:
        raise PermissionError(f"Cannot delete {rel_path}")

    def dir_exists(self, rel_path: str) -> bool:
        return self._real.dir_exists(rel_path)

    def model_path(self, rel_path: str) -> str:
        return self._real.model_path(rel_path)

    def read_meta(self, rel_path: str) -> dict:
        return self._real.read_meta(rel_path)

    def write_meta(self, rel_path: str, data: dict, *, preserve_mtime: bool = False) -> None:
        self._real.write_meta(rel_path, data, preserve_mtime=preserve_mtime)

    def touch_access(self, rel_path: str) -> None:
        self._real.touch_access(rel_path)

    def scan_entries(self) -> list[ModelInfo]:
        return self._real.scan_entries()

    def compute_dir_size(self, rel_path: str) -> int:
        return self._real.compute_dir_size(rel_path)

    def cleanup_temp_files(self) -> None:
        self._real.cleanup_temp_files()


# -- CacheManagerConfig tests --------------------------------------------------


class TestCacheManagerConfig:
    def test_defaults(self):
        config = CacheManagerConfig(evict_above=1000)
        assert config.evict_above == 1000
        assert config.interval == 60.0

    def test_evict_above_must_be_positive(self):
        with pytest.raises(ValueError, match="positive"):
            CacheManagerConfig(evict_above=0)
        with pytest.raises(ValueError, match="positive"):
            CacheManagerConfig(evict_above=-1)

    def test_interval_must_be_positive(self):
        with pytest.raises(ValueError, match="interval.*positive"):
            CacheManagerConfig(evict_above=1000, interval=0)
        with pytest.raises(ValueError, match="interval.*positive"):
            CacheManagerConfig(evict_above=1000, interval=-5.0)

    def test_frozen(self):
        config = CacheManagerConfig(evict_above=1000)
        with pytest.raises(AttributeError):
            config.evict_above = 2000


# -- ModelInfo tests -----------------------------------------------------------


class TestModelInfo:
    def test_creation(self):
        info = ModelInfo(path="a/b", size=1000, last_access=time.time(), access_count=5)
        assert info.path == "a/b"
        assert info.size == 1000
        assert info.access_count == 5

    def test_age(self):
        info = ModelInfo(path="a", size=100, last_access=time.time() - 60, access_count=0)
        assert info.age >= 59


# -- LocalStorage tests --------------------------------------------------------


class TestLocalStorage:
    def test_create_and_exists(self, tmp_path: Path):
        s = _storage(tmp_path)
        assert not s.dir_exists("model1")
        s.create_dir("model1")
        assert s.dir_exists("model1")

    def test_delete_dir(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.delete_dir("model1")
        assert not s.dir_exists("model1")

    def test_delete_dir_with_readonly_files(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        ro_file = tmp_path / "model1" / "data.bin"
        ro_file.write_bytes(b"x" * 100)
        ro_file.chmod(0o444)
        s.delete_dir("model1")
        assert not s.dir_exists("model1")

    def test_model_path(self, tmp_path: Path):
        s = _storage(tmp_path)
        assert s.model_path("a/b") == str(tmp_path.resolve() / "a/b")

    def test_key(self, tmp_path: Path):
        s = _storage(tmp_path)
        assert s.key() == str(tmp_path.resolve())

    def test_path_traversal_rejected(self, tmp_path: Path):
        s = _storage(tmp_path)
        with pytest.raises(ValueError, match="outside cache root"):
            s.create_dir("../../etc/passwd")
        with pytest.raises(ValueError, match="outside cache root"):
            s.model_path("../secret")
        with pytest.raises(ValueError, match="outside cache root"):
            s.read_meta("../../etc")
        with pytest.raises(ValueError, match="outside cache root"):
            s.write_meta("../../etc", {"size": 0})
        with pytest.raises(ValueError, match="outside cache root"):
            s.delete_dir("../outside")

    def test_read_write_meta(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 500, "access_count": 3})
        data = s.read_meta("model1")
        assert data["size"] == 500
        assert data["access_count"] == 3

    def test_read_meta_missing(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        assert s.read_meta("model1") == {"size": 0, "access_count": 0}

    def test_read_meta_corrupted(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / CACHE_META).write_text("not json")
        assert s.read_meta("model1") == {"size": 0, "access_count": 0}

    def test_write_meta_preserve_mtime(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 100})
        meta_path = tmp_path / "model1" / CACHE_META
        old_mtime = meta_path.stat().st_mtime
        time.sleep(0.05)
        s.write_meta("model1", {"size": 200}, preserve_mtime=True)
        assert meta_path.stat().st_mtime == old_mtime
        assert json.loads(meta_path.read_text())["size"] == 200

    def test_touch_access(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 0, "access_count": 1})
        meta_path = tmp_path / "model1" / CACHE_META
        old_mtime = meta_path.stat().st_mtime
        time.sleep(0.05)
        s.touch_access("model1")
        assert meta_path.stat().st_mtime > old_mtime

    def test_scan_entries(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("a/b")
        s.write_meta("a/b", {"size": 500, "access_count": 2})
        s.create_dir("c/d")
        s.write_meta("c/d", {"size": 300, "access_count": 1})
        entries = s.scan_entries()
        assert len(entries) == 2
        paths = {e.path for e in entries}
        assert "a/b" in paths
        assert "c/d" in paths

    def test_scan_entries_skips_root_meta(self, tmp_path: Path):
        s = _storage(tmp_path)
        (tmp_path / CACHE_META).write_text('{"size": 0, "access_count": 0}')
        assert s.scan_entries() == []

    def test_compute_dir_size(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model")
        (tmp_path / "model" / "data.bin").write_bytes(b"x" * 1000)
        (tmp_path / "model" / "meta.json").write_bytes(b"x" * 50)
        s.write_meta("model", {"size": 0})
        assert s.compute_dir_size("model") == 1050

    def test_compute_dir_size_empty(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("empty")
        assert s.compute_dir_size("empty") == 0

    def test_cleanup_stale_temp_files(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 0, "access_count": 1})
        stale = tmp_path / "model1" / f"{CACHE_META}.99999999.0.tmp"
        stale.write_text("{}")
        s.cleanup_temp_files()
        assert not stale.exists()

    def test_cleanup_keeps_live_process_temp_files(self, tmp_path: Path):
        s = _storage(tmp_path)
        sub = tmp_path / "scratch"
        sub.mkdir()
        ppid = os.getppid()
        live = sub / f"{CACHE_META}.{ppid}.0.tmp"
        live.write_text("{}")
        s.cleanup_temp_files()
        assert live.exists()
        live.unlink()

    def test_cleanup_removes_malformed_temp_files(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 0, "access_count": 1})
        bad = tmp_path / "model1" / f"{CACHE_META}.notapid.tmp"
        bad.write_text("{}")
        s.cleanup_temp_files()
        assert not bad.exists()

    def test_repr(self, tmp_path: Path):
        s = _storage(tmp_path)
        assert str(tmp_path.resolve()) in repr(s)


# -- ModelDir tests ------------------------------------------------------------


class TestModelDir:
    def test_creates_directory(self, tmp_path: Path):
        s = _storage(tmp_path)
        md = ModelDir(s, "a/b/model1")
        assert not md.exists
        with md:
            assert md.exists

    def test_path_returns_string(self, tmp_path: Path):
        s = _storage(tmp_path)
        md = ModelDir(s, "a/b/model1")
        assert md.path == str(tmp_path.resolve() / "a/b/model1")

    def test_creates_cache_meta(self, tmp_path: Path):
        s = _storage(tmp_path)
        with ModelDir(s, "model1"):
            meta_path = tmp_path / "model1" / CACHE_META
            assert meta_path.exists()
            data = json.loads(meta_path.read_text())
            assert data["access_count"] == 1

    def test_increments_access_count(self, tmp_path: Path):
        s = _storage(tmp_path)
        for _ in range(3):
            with ModelDir(s, "model1"):
                pass
        data = json.loads((tmp_path / "model1" / CACHE_META).read_text())
        assert data["access_count"] == 3

    def test_updates_mtime_on_exit(self, tmp_path: Path):
        s = _storage(tmp_path)
        with ModelDir(s, "model1"):
            pass
        meta_path = tmp_path / "model1" / CACHE_META
        old_mtime = meta_path.stat().st_mtime
        time.sleep(0.05)
        with ModelDir(s, "model1"):
            pass
        assert meta_path.stat().st_mtime > old_mtime

    def test_rejects_path_traversal(self, tmp_path: Path):
        s = _storage(tmp_path)
        md = ModelDir(s, "../../etc/passwd")
        with pytest.raises(ValueError, match="outside cache root"):
            md.__enter__()

    def test_repr(self, tmp_path: Path):
        s = _storage(tmp_path)
        md = ModelDir(s, "a/b/model1")
        assert "a/b/model1" in repr(md)


# -- Eviction policy tests (parametrized) -------------------------------------


class TestEvictionPolicies:
    """Shared behavior across all eviction policies."""

    @pytest.mark.parametrize("policy", [LruPolicy(), LfuPolicy(), SizedLruPolicy()])
    def test_empty_entries(self, policy):
        assert policy.select_evictions([], required_free=100) == []

    @pytest.mark.parametrize("policy", [LruPolicy(), LfuPolicy(), SizedLruPolicy()])
    def test_returns_all_when_required_exceeds_total(self, policy):
        now = time.time()
        entries = [
            ModelInfo(path="a", size=100, last_access=now - 20, access_count=1),
            ModelInfo(path="b", size=100, last_access=now - 10, access_count=2),
        ]
        result = policy.select_evictions(entries, required_free=500)
        assert len(result) == 2

    @pytest.mark.parametrize("policy", [LruPolicy(), LfuPolicy(), SizedLruPolicy()])
    def test_stops_when_required_met(self, policy):
        now = time.time()
        entries = [
            ModelInfo(path="a", size=100, last_access=now - 30, access_count=1),
            ModelInfo(path="b", size=100, last_access=now - 20, access_count=2),
            ModelInfo(path="c", size=100, last_access=now - 10, access_count=3),
        ]
        result = policy.select_evictions(entries, required_free=100)
        assert len(result) == 1  # one entry (size=100) is enough


class TestLruPolicy:
    def test_evicts_oldest(self):
        now = time.time()
        entries = [
            ModelInfo(path="old", size=100, last_access=now - 100, access_count=0),
            ModelInfo(path="new", size=100, last_access=now, access_count=0),
            ModelInfo(path="mid", size=100, last_access=now - 50, access_count=0),
        ]
        result = LruPolicy().select_evictions(entries, required_free=150)
        assert [e.path for e in result] == ["old", "mid"]

    def test_exact_free(self):
        now = time.time()
        entries = [ModelInfo(path="a", size=100, last_access=now - 10, access_count=0)]
        result = LruPolicy().select_evictions(entries, required_free=100)
        assert len(result) == 1


class TestLfuPolicy:
    def test_evicts_least_accessed(self):
        now = time.time()
        entries = [
            ModelInfo(path="popular", size=100, last_access=now, access_count=50),
            ModelInfo(path="rare", size=100, last_access=now, access_count=1),
            ModelInfo(path="medium", size=100, last_access=now, access_count=10),
        ]
        result = LfuPolicy().select_evictions(entries, required_free=150)
        assert result[0].path == "rare"
        assert result[1].path == "medium"

    def test_tie_breaks_by_last_access(self):
        now = time.time()
        entries = [
            ModelInfo(path="newer", size=100, last_access=now, access_count=5),
            ModelInfo(path="older", size=100, last_access=now - 100, access_count=5),
        ]
        result = LfuPolicy().select_evictions(entries, required_free=100)
        assert result[0].path == "older"  # same count, older evicted first


class TestSizedLruPolicy:
    def test_prefers_old_and_large(self):
        now = time.time()
        entries = [
            ModelInfo(path="old_small", size=10, last_access=now - 100, access_count=0),
            ModelInfo(path="old_large", size=1000, last_access=now - 100, access_count=0),
            ModelInfo(path="new_large", size=1000, last_access=now, access_count=0),
        ]
        result = SizedLruPolicy().select_evictions(entries, required_free=500)
        assert result[0].path == "old_large"

    def test_tie_breaks_by_size_descending(self):
        now = time.time()
        entries = [
            ModelInfo(path="small", size=50, last_access=now - 100, access_count=0),
            ModelInfo(path="large", size=500, last_access=now - 100, access_count=0),
        ]
        result = SizedLruPolicy().select_evictions(entries, required_free=50)
        assert result[0].path == "large"  # same time, larger evicted first

    def test_prefers_older_over_larger_new(self):
        now = time.time()
        entries = [
            ModelInfo(path="old_tiny", size=10, last_access=now - 1000, access_count=0),
            ModelInfo(path="new_huge", size=9999, last_access=now, access_count=0),
        ]
        result = SizedLruPolicy().select_evictions(entries, required_free=5)
        assert result[0].path == "old_tiny"  # older wins despite smaller size


# -- run_eviction tests --------------------------------------------------------


class TestRunEviction:
    def test_evicts_over_threshold(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("old")
        (tmp_path / "old" / "data.bin").write_bytes(b"x" * 600)
        s.write_meta("old", {"size": 600, "access_count": 1})
        entries = s.scan_entries()

        evicted = run_eviction(s, entries, evict_above=100, policy=LruPolicy())
        assert "old" in evicted
        assert not s.dir_exists("old")

    def test_no_eviction_within_budget(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 50, "access_count": 1})
        entries = s.scan_entries()

        evicted = run_eviction(s, entries, evict_above=1000, policy=LruPolicy())
        assert evicted == []

    def test_notifies_observer(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("old")
        s.write_meta("old", {"size": 500, "access_count": 1})
        entries = s.scan_entries()

        obs = _RecordingObserver()
        run_eviction(s, entries, evict_above=100, policy=LruPolicy(), observer=obs)
        assert "old" in obs.evictions

    def test_reports_error_on_delete_failure(self, tmp_path: Path):
        real = _storage(tmp_path)
        real.create_dir("model1")
        real.write_meta("model1", {"size": 500, "access_count": 1})
        entries = real.scan_entries()

        failing = _FailingStorage(real)
        obs = _RecordingObserver()
        evicted = run_eviction(failing, entries, evict_above=100, policy=LruPolicy(), observer=obs)
        assert evicted == []  # nothing actually deleted
        assert len(obs.errors) == 1
        assert "eviction" in obs.errors[0][1]
        assert real.dir_exists("model1")  # still exists


# -- CacheManager tests --------------------------------------------------------


class TestCacheManager:
    def test_updates_sizes(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 500)
        s.write_meta("model1", {"size": 0, "access_count": 1})

        mgr = CacheManager(storage=s, config=CacheManagerConfig(evict_above=10000))
        mgr.run_once()

        assert s.read_meta("model1")["size"] == 500

    def test_preserves_mtime_on_size_update(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.write_meta("model1", {"size": 0, "access_count": 1})
        old_mtime = (tmp_path / "model1" / CACHE_META).stat().st_mtime
        time.sleep(0.05)

        mgr = CacheManager(storage=s, config=CacheManagerConfig(evict_above=10000))
        mgr.run_once()

        assert (tmp_path / "model1" / CACHE_META).stat().st_mtime == old_mtime

    def test_evicts_when_over(self, tmp_path: Path):
        s = _storage(tmp_path)
        for name, data_size in [("old", 600), ("new", 400)]:
            s.create_dir(name)
            (tmp_path / name / "data.bin").write_bytes(b"x" * data_size)

        s.write_meta("old", {"size": 600, "access_count": 1})
        time.sleep(0.05)
        s.write_meta("new", {"size": 400, "access_count": 1})

        mgr = CacheManager(storage=s, config=CacheManagerConfig(evict_above=500))
        mgr.run_once()

        assert not (tmp_path / "old").exists()
        assert (tmp_path / "new").exists()

    def test_no_eviction_when_within_budget(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.write_meta("model1", {"size": 100, "access_count": 1})

        mgr = CacheManager(storage=s, config=CacheManagerConfig(evict_above=10000))
        mgr.run_once()

        assert s.dir_exists("model1")

    def test_skips_root_meta(self, tmp_path: Path):
        s = _storage(tmp_path)
        (tmp_path / CACHE_META).write_text('{"size": 0, "access_count": 0}')
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.write_meta("model1", {"size": 100, "access_count": 1})

        mgr = CacheManager(storage=s, config=CacheManagerConfig(evict_above=10000))
        mgr.run_once()

        assert len(s.scan_entries()) == 1


# -- CacheManager lifecycle + thread tests -------------------------------------


class TestCacheManagerLifecycle:
    def test_acquire_starts_thread(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.ensure_root()
        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10000, observer=obs, interval=60.0)

        CacheManager.acquire(s, config)
        try:
            obs.wait_for_cycle(timeout=10.0)
            key = s.key()
            with CacheManager._global_lock:
                mgr = CacheManager._instances[key]
                assert mgr._thread is not None
                assert mgr._thread.is_alive()
                assert mgr._thread.daemon
                assert mgr._refcount == 1
        finally:
            CacheManager.release(s)

    def test_release_stops_thread(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.ensure_root()
        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10000, observer=obs, interval=60.0)

        CacheManager.acquire(s, config)
        obs.wait_for_cycle(timeout=10.0)

        key = s.key()
        with CacheManager._global_lock:
            thread = CacheManager._instances[key]._thread

        CacheManager.release(s)

        if thread is not None:
            thread.join(timeout=10.0)
            assert not thread.is_alive()
        with CacheManager._global_lock:
            assert key not in CacheManager._instances

    def test_multiple_acquires_share_singleton(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.ensure_root()
        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10000, observer=obs, interval=60.0)

        CacheManager.acquire(s, config)
        CacheManager.acquire(s, config)
        try:
            obs.wait_for_cycle(timeout=10.0)
            key = s.key()
            with CacheManager._global_lock:
                assert key in CacheManager._instances
                assert CacheManager._instances[key]._refcount == 2
        finally:
            CacheManager.release(s)
            with CacheManager._global_lock:
                assert key in CacheManager._instances
            CacheManager.release(s)
            with CacheManager._global_lock:
                assert key not in CacheManager._instances

    def test_background_thread_updates_sizes(self, tmp_path: Path):
        """Verify the background thread actually updates sizes."""
        s = _storage(tmp_path)
        s.ensure_root()
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.write_meta("model1", {"size": 0, "access_count": 1})

        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10000, observer=obs, interval=60.0)

        CacheManager.acquire(s, config)
        try:
            obs.wait_for_cycle(timeout=10.0)
            assert s.read_meta("model1")["size"] == 100
        finally:
            CacheManager.release(s)


# -- Concurrency tests ---------------------------------------------------------


class TestConcurrency:
    def test_concurrent_different_models(self, tmp_path: Path):
        """Multiple threads each working on their own model directory."""
        s = _storage(tmp_path)
        s.ensure_root()
        errors: list[Exception] = []

        def work_on_model(name: str) -> None:
            try:
                with ModelDir(s, name):
                    (Path(s.model_path(name)) / "data.bin").write_bytes(b"x" * 50)
            except Exception as exc:
                errors.append(exc)

        names = [f"model_{i}" for i in range(10)]
        threads = [threading.Thread(target=work_on_model, args=(n,)) for n in names]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        assert len(s.scan_entries()) == 10


# -- Observer tests ------------------------------------------------------------


class TestObserver:
    def test_on_size_update(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 500)
        s.write_meta("model1", {"size": 0, "access_count": 1})

        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10000, observer=obs)
        mgr = CacheManager(storage=s, config=config)
        mgr.run_once()

        assert len(obs.size_updates) == 1
        assert obs.size_updates[0] == ("model1", 500)

    def test_on_evict(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("old")
        (tmp_path / "old" / "data.bin").write_bytes(b"x" * 600)
        s.write_meta("old", {"size": 600, "access_count": 1})

        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=100, observer=obs)
        mgr = CacheManager(storage=s, config=config)
        mgr.run_once()

        assert "old" in obs.evictions

    def test_on_cycle_complete(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.write_meta("model1", {"size": 100, "access_count": 1})

        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10000, observer=obs)
        mgr = CacheManager(storage=s, config=config)
        mgr.run_once()

        assert len(obs.cycles) == 1
        total_size, entry_count = obs.cycles[0]
        assert entry_count == 1
        assert total_size == 100

    def test_on_error_during_eviction(self, tmp_path: Path):
        """Use a mock storage to guarantee delete_dir raises."""
        real = _storage(tmp_path)
        real.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 500)
        real.write_meta("model1", {"size": 500, "access_count": 1})

        failing = _FailingStorage(real)
        obs = _RecordingObserver()
        config = CacheManagerConfig(evict_above=10, observer=obs)
        mgr = CacheManager(storage=failing, config=config)
        mgr.run_once()

        assert len(obs.errors) >= 1
        assert any("eviction" in ctx for _, ctx in obs.errors)
        assert real.dir_exists("model1")  # not deleted

    def test_on_evict_via_filecache(self, tmp_path: Path):
        obs = _RecordingObserver()
        config = _test_config(100, observer=obs)
        with FileCache(root=tmp_path, config=config) as cache:
            obs.wait_for_cycle()
            with cache.model("old") as m:
                (Path(m.path) / "data.bin").write_bytes(b"x" * 200)
            cache.storage.write_meta("old", {"size": 200, "access_count": 1})
            cache.evict()

        assert "old" in obs.evictions

    def test_default_observer_methods_are_noop(self):
        obs = CacheObserver()
        obs.on_evict("path")
        obs.on_size_update("path", 100)
        obs.on_error(RuntimeError("test"), "context")
        obs.on_cycle_complete(0, 0)

    def test_is_process_alive(self):
        assert _is_process_alive(os.getpid())
        assert not _is_process_alive(99999999)

    def test_cache_manager_release_when_not_acquired(self, tmp_path: Path):
        s = _storage(tmp_path / "never_acquired")
        CacheManager.release(s)

    def test_error_without_observer_does_not_crash(self, tmp_path: Path):
        s = _storage(tmp_path)
        s.create_dir("model1")
        meta_path = tmp_path / "model1" / CACHE_META
        meta_path.write_text('{"size": 0, "access_count": 1}')
        meta_path.chmod(0o444)

        config = CacheManagerConfig(evict_above=10000)
        mgr = CacheManager(storage=s, config=config)
        mgr.run_once()

        meta_path.chmod(0o644)

    def test_crashing_observer_does_not_kill_manager(self, tmp_path: Path):
        """Observer that raises should not crash the background cycle."""

        class _CrashingObserver(CacheObserver):
            def on_size_update(self, path: str, size: int) -> None:
                raise RuntimeError("observer crash")

            def on_cycle_complete(self, total_size: int, entry_count: int) -> None:
                raise RuntimeError("observer crash")

            def on_evict(self, path: str) -> None:
                raise RuntimeError("observer crash")

            def on_error(self, error: Exception, context: str) -> None:
                raise RuntimeError("observer crash")

        s = _storage(tmp_path)
        s.create_dir("model1")
        (tmp_path / "model1" / "data.bin").write_bytes(b"x" * 100)
        s.write_meta("model1", {"size": 100, "access_count": 1})

        config = CacheManagerConfig(evict_above=10000, observer=_CrashingObserver())
        mgr = CacheManager(storage=s, config=config)
        mgr.run_once()  # should not raise

        # Verify the cycle still completed (sizes updated despite observer crash)
        assert s.read_meta("model1")["size"] == 100

    def test_safe_run_once_catches_unexpected_errors(self, tmp_path: Path):
        """_safe_run_once catches errors from run_once to keep thread alive."""
        s = _storage(tmp_path)
        config = CacheManagerConfig(evict_above=10000)
        mgr = CacheManager(storage=s, config=config)

        # Monkey-patch run_once to raise
        original = mgr.run_once
        call_count = 0

        def failing_run_once() -> None:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RuntimeError("unexpected failure")
            original()

        mgr.run_once = failing_run_once
        mgr._safe_run_once()  # should not raise
        assert call_count == 1

    def test_safe_run_once_notifies_observer_on_error(self, tmp_path: Path):
        """_safe_run_once reports errors to observer even if observer crashes."""
        s = _storage(tmp_path)

        class _CrashingOnError(CacheObserver):
            called = False

            def on_error(self, error: Exception, context: str) -> None:
                _CrashingOnError.called = True
                raise RuntimeError("observer also crashes")

        obs = _CrashingOnError()
        config = CacheManagerConfig(evict_above=10000, observer=obs)
        mgr = CacheManager(storage=s, config=config)

        # Make run_once raise
        mgr.run_once = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        mgr._safe_run_once()  # should not raise
        assert _CrashingOnError.called

    def test_crashing_observer_on_evict_in_run_eviction(self, tmp_path: Path):
        """_safe_notify suppresses observer.on_evict exceptions."""

        class _CrashOnEvict(CacheObserver):
            def on_evict(self, path: str) -> None:
                raise RuntimeError("crash on evict")

        s = _storage(tmp_path)
        s.create_dir("model1")
        s.write_meta("model1", {"size": 500, "access_count": 1})
        entries = s.scan_entries()

        evicted = run_eviction(
            s, entries, evict_above=100, policy=LruPolicy(), observer=_CrashOnEvict()
        )
        assert "model1" in evicted  # eviction succeeded despite observer crash

    def test_check_pid_clears_stale_instances(self, tmp_path: Path):
        """_check_pid discards singleton entries when PID changes."""
        s = _storage(tmp_path)
        s.ensure_root()
        config = CacheManagerConfig(evict_above=10000, interval=9999)

        # Manually insert a stale entry and fake the owner PID
        CacheManager._instances["stale_key"] = CacheManager(storage=s, config=config)
        original_pid = CacheManager._owner_pid
        CacheManager._owner_pid = -1  # fake a different PID

        CacheManager._check_pid()

        assert "stale_key" not in CacheManager._instances
        assert CacheManager._owner_pid == os.getpid()

        # Restore
        CacheManager._owner_pid = original_pid

    def test_rmtree_onerror_directly(self, tmp_path: Path):
        """_rmtree_onerror clears read-only flag and deletes file."""
        from vcti.filecache.storage import _rmtree_onerror

        ro_file = tmp_path / "readonly.bin"
        ro_file.write_bytes(b"x" * 10)
        ro_file.chmod(0o444)

        _rmtree_onerror(None, str(ro_file), None)
        assert not ro_file.exists()

    @pytest.mark.skipif(sys.platform == "win32", reason="Unix-only os.kill path")
    def test_is_process_alive_permission_error(self):
        """Cover PermissionError branch in _is_process_alive (Unix only)."""
        from unittest.mock import patch

        with patch("os.kill", side_effect=PermissionError("no access")):
            assert _is_process_alive(12345) is True


# -- LoggingObserver tests -----------------------------------------------------


class TestLoggingObserver:
    def test_default_logger(self):
        obs = LoggingObserver()
        assert obs._log.name == "vcti.filecache"

    def test_custom_logger(self):
        logger = logging.getLogger("test.custom")
        obs = LoggingObserver(logger=logger)
        assert obs._log is logger

    def test_logs_eviction(self, caplog):
        obs = LoggingObserver()
        with caplog.at_level(logging.INFO, logger="vcti.filecache"):
            obs.on_evict("model1")
        assert "Evicted model1" in caplog.text

    def test_logs_error(self, caplog):
        obs = LoggingObserver()
        with caplog.at_level(logging.WARNING, logger="vcti.filecache"):
            obs.on_error(RuntimeError("disk full"), "eviction of model1")
        assert "eviction of model1" in caplog.text
        assert "disk full" in caplog.text

    def test_logs_size_update(self, caplog):
        obs = LoggingObserver()
        with caplog.at_level(logging.DEBUG, logger="vcti.filecache"):
            obs.on_size_update("model1", 1024)
        assert "model1" in caplog.text

    def test_logs_cycle_complete(self, caplog):
        obs = LoggingObserver()
        with caplog.at_level(logging.DEBUG, logger="vcti.filecache"):
            obs.on_cycle_complete(1024 * 1024 * 100, 5)
        assert "5 entries" in caplog.text


# -- CacheSnapshot tests ------------------------------------------------------


class TestCacheSnapshot:
    def test_snapshot_properties(self):
        entries = [
            ModelInfo(path="a", size=300, last_access=0, access_count=0),
            ModelInfo(path="b", size=200, last_access=0, access_count=0),
        ]
        snap = CacheSnapshot(entries=entries, evict_above=400)
        assert snap.total_size == 500
        assert snap.entry_count == 2
        assert snap.is_over_limit
        assert snap.overage == 100

    def test_snapshot_within_budget(self):
        entries = [
            ModelInfo(path="a", size=100, last_access=0, access_count=0),
        ]
        snap = CacheSnapshot(entries=entries, evict_above=1000)
        assert not snap.is_over_limit
        assert snap.overage == 0

    def test_filecache_snapshot(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config()) as cache:
            with cache.model("a"):
                pass
            with cache.model("b"):
                pass
            snap = cache.snapshot()
            assert snap.entry_count == 2


# -- FileCache tests -----------------------------------------------------------


class TestFileCache:
    def test_creates_root(self, tmp_path: Path):
        root = tmp_path / "cache"
        with FileCache(root=root, config=_test_config(1000)):
            assert root.is_dir()

    def test_requires_root_or_storage(self):
        with pytest.raises(TypeError, match="storage.*root"):
            FileCache(config=_test_config())

    def test_model_creates_directory(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config(1000)) as cache:
            with cache.model("a/b/model1") as model:
                assert Path(model.path).is_dir()

    def test_model_write_files(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config(1000)) as cache:
            with cache.model("model1") as model:
                (Path(model.path) / "data.bin").write_bytes(b"x" * 100)
            assert (tmp_path / "model1" / "data.bin").exists()

    def test_with_explicit_storage(self, tmp_path: Path):
        s = LocalStorage(tmp_path)
        with FileCache(storage=s, config=_test_config()) as cache:
            with cache.model("model1") as model:
                assert Path(model.path).is_dir()
            assert cache.entry_count == 1

    def test_entries(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config()) as cache:
            with cache.model("model1"):
                pass
            with cache.model("model2"):
                pass
            entries = cache.entries()
            assert len(entries) == 2
            paths = {e.path for e in entries}
            assert "model1" in paths
            assert "model2" in paths

    def test_entry_count(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config()) as cache:
            with cache.model("a"):
                pass
            with cache.model("b"):
                pass
            assert cache.entry_count == 2

    def test_total_size_before_manager_update(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config()) as cache:
            with cache.model("model1") as model:
                (Path(model.path) / "data.bin").write_bytes(b"x" * 100)
            assert cache.total_size == 0

    def test_is_over_limit(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config(200)) as cache:
            with cache.model("a") as m:
                (Path(m.path) / "data.bin").write_bytes(b"x" * 300)
            assert not cache.is_over_limit

    def test_overage(self, tmp_path: Path):
        obs = _RecordingObserver()
        with FileCache(root=tmp_path, config=_test_config(200, observer=obs)) as cache:
            with cache.model("a"):
                pass
            obs.wait_for_cycle()
            cache.storage.write_meta("a", {"size": 300, "access_count": 1})
            assert cache.overage == 100

    def test_evict(self, tmp_path: Path):
        obs = _RecordingObserver()
        with FileCache(root=tmp_path, config=_test_config(100, observer=obs)) as cache:
            obs.wait_for_cycle()
            with cache.model("old") as m:
                (Path(m.path) / "data.bin").write_bytes(b"x" * 200)
            time.sleep(0.05)
            with cache.model("new") as m:
                (Path(m.path) / "data.bin").write_bytes(b"x" * 50)

            s = cache.storage
            for name in ["old", "new"]:
                size = s.compute_dir_size(name)
                s.write_meta(name, {"size": size, "access_count": 1})

            evicted = cache.evict()
            assert "old" in evicted
            assert not (tmp_path / "old").exists()
            assert (tmp_path / "new").exists()

    def test_evict_within_budget(self, tmp_path: Path):
        obs = _RecordingObserver()
        with FileCache(root=tmp_path, config=_test_config(observer=obs)) as cache:
            obs.wait_for_cycle()
            with cache.model("a"):
                pass
            cache.storage.write_meta("a", {"size": 100, "access_count": 1})
            assert cache.evict() == []

    def test_evict_with_custom_policy(self, tmp_path: Path):
        obs = _RecordingObserver()
        with FileCache(root=tmp_path, config=_test_config(100, observer=obs)) as cache:
            obs.wait_for_cycle()
            with cache.model("rare") as m:
                (Path(m.path) / "data.bin").write_bytes(b"x" * 200)
            with cache.model("popular") as m:
                (Path(m.path) / "data.bin").write_bytes(b"x" * 200)

            s = cache.storage
            s.write_meta("rare", {"size": 200, "access_count": 1})
            s.write_meta("popular", {"size": 200, "access_count": 50})

            evicted = cache.evict(policy=LfuPolicy())
            assert "rare" in evicted

    def test_repr(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config(1024**3)) as cache:
            assert "FileCache" in repr(cache)
            assert "1.0 GB" in repr(cache)

    def test_hierarchical_paths(self, tmp_path: Path):
        with FileCache(root=tmp_path, config=_test_config()) as cache:
            with cache.model("ab/cd/model_001"):
                pass
            with cache.model("ab/ef/model_002"):
                pass
            with cache.model("gh/ij/model_003"):
                pass
            assert cache.entry_count == 3
