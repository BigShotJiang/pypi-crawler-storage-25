# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Version tests for vcti-file-cache."""

import re

import vcti.filecache


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.filecache, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.filecache.__version__)
