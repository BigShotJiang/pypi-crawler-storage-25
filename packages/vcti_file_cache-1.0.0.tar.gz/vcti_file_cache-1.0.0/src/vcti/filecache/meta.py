# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""ModelInfo — metadata dataclass for cached model directories."""

from dataclasses import dataclass
from time import time


@dataclass
class ModelInfo:
    """Metadata for a cached model directory.

    Attributes:
        path: Relative path from cache root (forward-slash separated).
        size: Total size in bytes of the directory contents.
        last_access: Unix timestamp of last access.
        access_count: Number of times the directory has been accessed.
    """

    path: str
    size: int
    last_access: float
    access_count: int

    @property
    def age(self) -> float:
        """Seconds since last access."""
        return time() - self.last_access
