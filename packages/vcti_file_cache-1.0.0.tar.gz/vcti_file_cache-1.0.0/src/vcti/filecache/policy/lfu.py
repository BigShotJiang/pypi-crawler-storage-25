# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""LFU eviction policy — evicts least frequently accessed entries first."""

from ..meta import ModelInfo


class LfuPolicy:
    """Least Frequently Used eviction policy.

    Sorts entries by access_count ascending (least accessed first),
    breaking ties by last_access (oldest first).
    """

    def select_evictions(
        self,
        entries: list[ModelInfo],
        required_free: int,
    ) -> list[ModelInfo]:
        sorted_entries = sorted(entries, key=lambda e: (e.access_count, e.last_access))
        selected: list[ModelInfo] = []
        freed = 0
        for entry in sorted_entries:
            if freed >= required_free:
                break
            selected.append(entry)
            freed += entry.size
        return selected
