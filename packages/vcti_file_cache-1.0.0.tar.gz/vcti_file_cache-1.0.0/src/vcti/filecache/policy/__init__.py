# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Eviction policies."""

from .base import EvictionPolicy
from .lfu import LfuPolicy
from .lru import LruPolicy
from .sized_lru import SizedLruPolicy

__all__ = ["EvictionPolicy", "LfuPolicy", "LruPolicy", "SizedLruPolicy"]
