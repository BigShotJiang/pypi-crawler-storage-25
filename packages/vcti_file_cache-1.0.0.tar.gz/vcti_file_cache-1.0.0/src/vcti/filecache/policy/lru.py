# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""LRU eviction policy — evicts least recently accessed entries first."""

from ..meta import ModelInfo


class LruPolicy:
    """Least Recently Used eviction policy.

    Sorts entries by last_access ascending (oldest first) and selects
    enough to free the required space.
    """

    def select_evictions(
        self,
        entries: list[ModelInfo],
        required_free: int,
    ) -> list[ModelInfo]:
        sorted_entries = sorted(entries, key=lambda e: e.last_access)
        selected: list[ModelInfo] = []
        freed = 0
        for entry in sorted_entries:
            if freed >= required_free:
                break
            selected.append(entry)
            freed += entry.size
        return selected
