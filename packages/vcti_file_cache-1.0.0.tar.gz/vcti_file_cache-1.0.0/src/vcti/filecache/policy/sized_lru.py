# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Size-weighted LRU — evicts largest old entries first for faster space recovery."""

from ..meta import ModelInfo


class SizedLruPolicy:
    """Size-weighted LRU eviction policy.

    Sorts entries by last_access ascending, breaking ties by size
    descending. This means old entries are evicted first, and among
    entries with the same access time, larger ones go first —
    recovering space faster than pure LRU.
    """

    def select_evictions(
        self,
        entries: list[ModelInfo],
        required_free: int,
    ) -> list[ModelInfo]:
        if not entries:
            return []

        # Sort by last_access ascending, then by size descending (large old items first)
        sorted_entries = sorted(entries, key=lambda e: (e.last_access, -e.size))
        selected: list[ModelInfo] = []
        freed = 0
        for entry in sorted_entries:
            if freed >= required_free:
                break
            selected.append(entry)
            freed += entry.size
        return selected
