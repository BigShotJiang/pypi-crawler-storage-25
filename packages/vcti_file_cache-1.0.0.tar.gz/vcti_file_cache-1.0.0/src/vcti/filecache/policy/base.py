# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Eviction policy protocol."""

from typing import Protocol

from ..meta import ModelInfo


class EvictionPolicy(Protocol):
    """Protocol for cache eviction strategies.

    Implementations receive a list of model entries and a space target,
    and return an ordered list of entries to evict.
    """

    def select_evictions(self, entries: list[ModelInfo], required_free: int) -> list[ModelInfo]:
        """Return entries to evict to free at least ``required_free`` bytes."""
        ...
