# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.filecache — Directory-level cache with pluggable eviction policies."""

from importlib.metadata import version

from .cache import CacheSnapshot, FileCache
from .manager import CacheManager, CacheManagerConfig, run_eviction
from .meta import ModelInfo
from .model import ModelDir
from .observer import CacheObserver, LoggingObserver
from .policy import EvictionPolicy, LfuPolicy, LruPolicy, SizedLruPolicy
from .storage import CacheStorage, LocalStorage

__version__ = version("vcti-file-cache")

__all__ = [
    "__version__",
    "CacheManager",
    "CacheManagerConfig",
    "CacheObserver",
    "CacheSnapshot",
    "CacheStorage",
    "EvictionPolicy",
    "FileCache",
    "LfuPolicy",
    "LocalStorage",
    "LoggingObserver",
    "LruPolicy",
    "ModelDir",
    "ModelInfo",
    "SizedLruPolicy",
    "run_eviction",
]
