# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""ModelDir — context manager for accessing a cached model directory."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .storage import CacheStorage


class ModelDir:
    """Context manager for a cached model directory.

    Creates the directory on first use. Tracks access count and
    last-access time via the storage backend.

    Example:
        >>> with cache.model("ab/cd/model_abc123") as model:
        ...     save_mesh(model.path / "mesh.vtu")
    """

    def __init__(self, storage: CacheStorage, rel_path: str) -> None:
        self._storage = storage
        self._rel_path = rel_path

    @property
    def path(self) -> str:
        """Full path or URI to the model directory."""
        return self._storage.model_path(self._rel_path)

    @property
    def exists(self) -> bool:
        """Whether the model directory exists."""
        return self._storage.dir_exists(self._rel_path)

    def __enter__(self) -> ModelDir:
        self._storage.create_dir(self._rel_path)
        meta = self._storage.read_meta(self._rel_path)
        meta["access_count"] = meta.get("access_count", 0) + 1
        self._storage.write_meta(self._rel_path, meta)
        return self

    def __exit__(self, *exc: object) -> None:
        self._storage.touch_access(self._rel_path)

    def __repr__(self) -> str:
        return f"ModelDir({self._rel_path!r})"
