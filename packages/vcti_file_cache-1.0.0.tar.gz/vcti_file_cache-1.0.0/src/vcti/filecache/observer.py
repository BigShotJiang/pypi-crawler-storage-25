# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""CacheObserver — base class and built-in observers for cache lifecycle events."""

import logging


class CacheObserver:
    """Base observer for cache lifecycle events.

    Subclass and override the methods you need. All methods are no-ops
    by default, so you only implement the events you care about.

    **Thread safety:** Observer methods are called from the background
    ``CacheManager`` thread (for automatic eviction) or from the
    caller's thread (for ``FileCache.evict()``). Implementations must
    be safe for both contexts. Avoid long-running operations — they
    block the background cycle. Exceptions raised by observer methods
    are caught and suppressed to prevent crashing the manager.

    Example:
        >>> class MyObserver(CacheObserver):
        ...     def on_evict(self, path: str) -> None:
        ...         print(f"Evicted: {path}")
        ...     def on_error(self, error: Exception, context: str) -> None:
        ...         print(f"Error in {context}: {error}")
    """

    def on_evict(self, path: str) -> None:
        """Called for each directory evicted."""

    def on_size_update(self, path: str, size: int) -> None:
        """Called when a directory's recorded size is updated."""

    def on_error(self, error: Exception, context: str) -> None:
        """Called when an operation fails (eviction, size scan, etc.)."""

    def on_cycle_complete(self, total_size: int, entry_count: int) -> None:
        """Called after each background update/eviction cycle."""


class LoggingObserver(CacheObserver):
    """Observer that logs cache events via stdlib logging.

    Args:
        logger: A ``logging.Logger`` instance. If not provided, uses
            ``logging.getLogger("vcti.filecache")``.

    Example:
        >>> config = CacheManagerConfig(
        ...     evict_above=50 * 1024**3,
        ...     observer=LoggingObserver(),
        ... )
    """

    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._log = logger or logging.getLogger("vcti.filecache")

    def on_evict(self, path: str) -> None:
        self._log.info("Evicted %s", path)

    def on_size_update(self, path: str, size: int) -> None:
        self._log.debug("Size update %s → %d bytes", path, size)

    def on_error(self, error: Exception, context: str) -> None:
        self._log.warning("%s: %s", context, error)

    def on_cycle_complete(self, total_size: int, entry_count: int) -> None:
        self._log.debug(
            "Cycle complete: %d entries, %.1f MB total",
            entry_count,
            total_size / (1024**2),
        )
