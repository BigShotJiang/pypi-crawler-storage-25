# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""CacheManager — background thread for cache size tracking and eviction."""

from __future__ import annotations

import os
import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .meta import ModelInfo
from .observer import CacheObserver
from .policy.base import EvictionPolicy
from .policy.lru import LruPolicy

if TYPE_CHECKING:
    from .storage import CacheStorage


@dataclass(frozen=True)
class CacheManagerConfig:
    """Configuration for the background cache manager.

    Attributes:
        evict_above: Size threshold in bytes. When the total cache size
            exceeds this value, eviction candidates are selected and
            their directories deleted. Must be positive.
        policy: Eviction policy. Defaults to LRU.
        interval: Seconds between background update/eviction cycles.
        observer: Optional observer notified of lifecycle events
            (eviction, size updates, errors, cycle completion).
    """

    evict_above: int
    policy: EvictionPolicy = field(default_factory=LruPolicy)
    interval: float = 60.0
    observer: CacheObserver | None = None

    def __post_init__(self) -> None:
        if self.evict_above <= 0:
            raise ValueError(f"evict_above must be positive, got {self.evict_above}")
        if self.interval <= 0:
            raise ValueError(f"interval must be positive, got {self.interval}")


def run_eviction(
    storage: CacheStorage,
    entries: list[ModelInfo],
    evict_above: int,
    policy: EvictionPolicy,
    observer: CacheObserver | None = None,
) -> list[str]:
    """Select and delete eviction candidates.

    Shared by ``CacheManager`` (background) and ``FileCache.evict()``
    (manual). Returns relative paths of directories that were deleted.
    """
    total = sum(e.size for e in entries)
    overage = total - evict_above
    if overage <= 0:
        return []
    candidates = policy.select_evictions(entries, overage)
    evicted: list[str] = []
    for entry in candidates:
        try:
            storage.delete_dir(entry.path)
            evicted.append(entry.path)
            _safe_notify(observer, "on_evict", entry.path)
        except Exception as exc:
            _safe_notify(observer, "on_error", exc, f"eviction of {entry.path}")
    return evicted


def _safe_notify(observer: CacheObserver | None, method: str, *args: object) -> None:
    """Call an observer method, suppressing any exception it raises."""
    if observer:
        try:
            getattr(observer, method)(*args)
        except Exception:
            pass


class CacheManager:
    """Background cache manager that tracks directory sizes and runs eviction.

    One instance per storage root. Multiple ``FileCache`` instances sharing
    the same storage share one ``CacheManager``. Runs as a daemon thread
    that periodically scans model directories, updates their recorded
    sizes, and evicts when the total exceeds the configured threshold.

    The first cycle runs immediately on thread start; subsequent cycles
    run at the configured interval.

    Uses PID-guarding to detect ``fork()`` — if the current PID differs
    from the PID that created the singleton, the stale entry is discarded
    and a new manager is created for the child process.
    """

    _instances: dict[str, CacheManager] = {}
    _global_lock = threading.Lock()
    _owner_pid: int = os.getpid()

    def __init__(self, storage: CacheStorage, config: CacheManagerConfig) -> None:
        self._storage = storage
        self._config = config
        self._observer = config.observer
        self._refcount = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    @classmethod
    def _check_pid(cls) -> None:
        """Discard stale singletons after fork()."""
        current_pid = os.getpid()
        if current_pid != cls._owner_pid:
            cls._instances.clear()
            cls._owner_pid = current_pid

    @classmethod
    def acquire(cls, storage: CacheStorage, config: CacheManagerConfig) -> None:
        """Register a FileCache and start the background thread if needed."""
        key = storage.key()
        with cls._global_lock:
            cls._check_pid()
            if key not in cls._instances:
                cls._instances[key] = cls(storage, config)
            mgr = cls._instances[key]
            mgr._refcount += 1
            if mgr._thread is None or not mgr._thread.is_alive():
                mgr._start()

    @classmethod
    def release(cls, storage: CacheStorage) -> None:
        """Unregister a FileCache. Stops the thread when all are released."""
        key = storage.key()
        with cls._global_lock:
            cls._check_pid()
            if key not in cls._instances:
                return
            mgr = cls._instances[key]
            mgr._refcount -= 1
            if mgr._refcount <= 0:
                mgr._stop.set()
                thread = mgr._thread
                del cls._instances[key]
        # Join outside the lock to avoid deadlock
        if mgr._refcount <= 0 and thread is not None:
            thread.join(timeout=5.0)

    def _start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name=f"cache-manager-{self._storage.key()[-20:]}",
        )
        self._thread.start()

    def _run(self) -> None:
        # First cycle runs immediately
        self._safe_run_once()
        while not self._stop.is_set():
            self._stop.wait(timeout=self._config.interval)
            if self._stop.is_set():
                break
            self._safe_run_once()
        # Final cycle on shutdown
        self._safe_run_once()

    def _safe_run_once(self) -> None:
        """Run a cycle, catching unexpected exceptions to keep the thread alive."""
        try:
            self.run_once()
        except Exception as exc:
            self._notify_error(exc, "background cycle")

    def run_once(self) -> None:
        """Run a single update-sizes-then-evict cycle.

        Scans entries once and reuses the list for size updates,
        eviction, and cycle-complete notification.
        """
        self._storage.cleanup_temp_files()
        entries = self._storage.scan_entries()
        self._update_sizes(entries)
        # Re-scan after size updates so eviction sees current sizes
        entries = self._storage.scan_entries()
        run_eviction(
            self._storage,
            entries,
            self._config.evict_above,
            self._config.policy,
            self._observer,
        )
        # Post-eviction scan for accurate cycle-complete totals
        entries = self._storage.scan_entries()
        total = sum(e.size for e in entries)
        self._notify_cycle(total, len(entries))

    def _update_sizes(self, entries: list[ModelInfo]) -> None:
        for entry in entries:
            try:
                size = self._storage.compute_dir_size(entry.path)
                meta = self._storage.read_meta(entry.path)
                meta["size"] = size
                self._storage.write_meta(entry.path, meta, preserve_mtime=True)
                self._notify_size_update(entry.path, size)
            except Exception as exc:
                self._notify_error(exc, f"size update for {entry.path}")

    # -- Observer helpers (isolate observer exceptions) --

    def _notify_error(self, error: Exception, context: str) -> None:
        if self._observer:
            try:
                self._observer.on_error(error, context)
            except Exception:
                pass  # observer must not crash the manager

    def _notify_size_update(self, path: str, size: int) -> None:
        if self._observer:
            try:
                self._observer.on_size_update(path, size)
            except Exception:
                pass

    def _notify_cycle(self, total_size: int, entry_count: int) -> None:
        if self._observer:
            try:
                self._observer.on_cycle_complete(total_size, entry_count)
            except Exception:
                pass
