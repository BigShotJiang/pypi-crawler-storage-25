# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""FileCache — directory-level cache with background eviction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .manager import CacheManager, CacheManagerConfig, run_eviction
from .meta import ModelInfo
from .model import ModelDir
from .policy.base import EvictionPolicy
from .storage import CacheStorage, LocalStorage

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class CacheSnapshot:
    """Point-in-time snapshot of cache state.

    Use ``FileCache.snapshot()`` to scan entries once and then query
    multiple properties without redundant scans.
    """

    entries: list[ModelInfo]
    evict_above: int

    @property
    def total_size(self) -> int:
        """Total size of all cached entries in bytes."""
        return sum(e.size for e in self.entries)

    @property
    def entry_count(self) -> int:
        """Number of cached model directories."""
        return len(self.entries)

    @property
    def is_over_limit(self) -> bool:
        """Whether total cache size exceeds the eviction threshold."""
        return self.total_size > self.evict_above

    @property
    def overage(self) -> int:
        """Bytes over the eviction threshold, or 0 if within budget."""
        return max(0, self.total_size - self.evict_above)


class FileCache:
    """Directory-level cache with pluggable eviction and background management.

    Use as a context manager. Model directories are accessed via
    ``model()``, which returns a ``ModelDir`` context manager.

    Example:
        >>> from vcti.filecache import FileCache, CacheManagerConfig
        >>> config = CacheManagerConfig(evict_above=50 * 1024**3)
        >>> with FileCache(root=Path("/data/cache"), config=config) as cache:
        ...     with cache.model("ab/cd/model_abc123") as model:
        ...         save_mesh(Path(model.path) / "mesh.vtu")
    """

    def __init__(
        self,
        config: CacheManagerConfig,
        storage: CacheStorage | None = None,
        root: Path | str | None = None,
    ) -> None:
        """Initialize the file cache.

        Provide either ``storage`` (any ``CacheStorage`` backend) or
        ``root`` (shorthand that creates a ``LocalStorage``). If both
        are given, ``storage`` takes precedence.

        Args:
            config: Configuration for the background cache manager.
            storage: Storage backend. Defaults to ``LocalStorage(root)``.
            root: Root directory for local storage (convenience shorthand).
        """
        if storage is not None:
            self._storage = storage
        elif root is not None:
            from pathlib import Path as _Path

            self._storage = LocalStorage(_Path(root))
        else:
            raise TypeError("Either 'storage' or 'root' must be provided")
        self._config = config

    @property
    def storage(self) -> CacheStorage:
        """The storage backend used by this cache."""
        return self._storage

    def __enter__(self) -> FileCache:
        if isinstance(self._storage, LocalStorage):
            self._storage.ensure_root()
        CacheManager.acquire(self._storage, self._config)
        return self

    def __exit__(self, *exc: object) -> None:
        CacheManager.release(self._storage)

    def model(self, path: str) -> ModelDir:
        """Return a context manager for a model directory.

        Creates the directory on first use. Each entry/exit updates the
        access metadata automatically.

        Args:
            path: Relative path from cache root (e.g., ``"ab/cd/model_001"``).
        """
        return ModelDir(self._storage, path)

    def entries(self) -> list[ModelInfo]:
        """Return metadata for all cached model directories."""
        return self._storage.scan_entries()

    def snapshot(self) -> CacheSnapshot:
        """Scan entries once and return a frozen snapshot.

        Use this instead of querying ``total_size``, ``entry_count``,
        ``is_over_limit``, and ``overage`` individually — each of those
        properties triggers a separate scan.
        """
        return CacheSnapshot(
            entries=self._storage.scan_entries(),
            evict_above=self._config.evict_above,
        )

    @property
    def total_size(self) -> int:
        """Total size of all cached entries in bytes."""
        return sum(e.size for e in self.entries())

    @property
    def entry_count(self) -> int:
        """Number of cached model directories."""
        return len(self.entries())

    @property
    def is_over_limit(self) -> bool:
        """Whether total cache size exceeds the eviction threshold."""
        return self.total_size > self._config.evict_above

    @property
    def overage(self) -> int:
        """Bytes over the eviction threshold, or 0 if within budget."""
        return max(0, self.total_size - self._config.evict_above)

    def evict(self, policy: EvictionPolicy | None = None) -> list[str]:
        """Manually evict directories until within budget.

        Args:
            policy: Override eviction policy. Defaults to the config's policy.

        Returns:
            Relative paths of evicted directories.
        """
        return run_eviction(
            self._storage,
            self.entries(),
            self._config.evict_above,
            policy or self._config.policy,
            self._config.observer,
        )

    def __repr__(self) -> str:
        limit_gb = self._config.evict_above / (1024**3)
        return f"FileCache(storage={self._storage!r}, evict_above={limit_gb:.1f} GB)"
