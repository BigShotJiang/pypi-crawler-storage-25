# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""CacheStorage protocol and LocalStorage implementation."""

import json
import os
import shutil
import stat
import sys
import threading
from pathlib import Path
from typing import Protocol

from .meta import ModelInfo

CACHE_META = ".cache_meta"


class CacheStorage(Protocol):
    """Protocol for cache storage backends.

    Abstracts all storage operations so that ``FileCache``,
    ``ModelDir``, and ``CacheManager`` work identically across
    local filesystem, S3, or any other backend.
    """

    def key(self) -> str:
        """Return a unique key identifying this storage root.

        Used by ``CacheManager`` to maintain one background thread
        per distinct storage root.
        """
        ...

    def create_dir(self, rel_path: str) -> None:
        """Create a model directory (and parents). No-op if it exists."""
        ...

    def delete_dir(self, rel_path: str) -> None:
        """Delete a model directory and all its contents."""
        ...

    def dir_exists(self, rel_path: str) -> bool:
        """Check if a model directory exists."""
        ...

    def model_path(self, rel_path: str) -> str:
        """Return the full path or URI for a model directory.

        For local storage this is a filesystem path; for S3 it would
        be an ``s3://`` URI.
        """
        ...

    def read_meta(self, rel_path: str) -> dict:
        """Read the .cache_meta file for a model directory.

        Returns ``{"size": 0, "access_count": 0}`` on any error.
        """
        ...

    def write_meta(self, rel_path: str, data: dict, *, preserve_mtime: bool = False) -> None:
        """Write the .cache_meta file for a model directory.

        Args:
            rel_path: Relative model directory path.
            data: Metadata dictionary to serialize.
            preserve_mtime: If True, restore the original last-access
                timestamp after writing. Used by the background manager
                when updating sizes.
        """
        ...

    def touch_access(self, rel_path: str) -> None:
        """Update the last-access timestamp for a model directory.

        Called on context exit to record end of access without
        modifying the metadata contents.
        """
        ...

    def scan_entries(self) -> list[ModelInfo]:
        """Discover all model directories and return their metadata."""
        ...

    def compute_dir_size(self, rel_path: str) -> int:
        """Compute the total size of files in a model directory.

        Excludes metadata files from the count.
        """
        ...

    def cleanup_temp_files(self) -> None:
        """Remove stale temporary files left by crashed processes."""
        ...


class LocalStorage:
    """Local filesystem storage backend.

    Stores cached model directories under a root path. Metadata is
    tracked via ``.cache_meta`` JSON files; last-access time uses
    the file's mtime.
    """

    def __init__(self, root: Path | str) -> None:
        self._root = Path(root).resolve()

    @property
    def root(self) -> Path:
        """Root directory on disk."""
        return self._root

    def key(self) -> str:
        return str(self._root)

    def _safe_path(self, rel_path: str) -> Path:
        """Resolve rel_path under root and verify it stays within bounds.

        Raises:
            ValueError: If the resolved path escapes the root.
        """
        resolved = (self._root / rel_path).resolve()
        if not resolved.is_relative_to(self._root):
            raise ValueError(f"Path {rel_path!r} resolves outside cache root")
        return resolved

    def ensure_root(self) -> None:
        """Create the root directory if it does not exist."""
        self._root.mkdir(parents=True, exist_ok=True)

    def create_dir(self, rel_path: str) -> None:
        self._safe_path(rel_path).mkdir(parents=True, exist_ok=True)

    def delete_dir(self, rel_path: str) -> None:
        shutil.rmtree(self._safe_path(rel_path), onerror=_rmtree_onerror)

    def dir_exists(self, rel_path: str) -> bool:
        return self._safe_path(rel_path).is_dir()

    def model_path(self, rel_path: str) -> str:
        return str(self._safe_path(rel_path))

    def read_meta(self, rel_path: str) -> dict:
        meta_path = self._safe_path(rel_path) / CACHE_META
        try:
            data: dict = json.loads(meta_path.read_text())
            return data
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {"size": 0, "access_count": 0}

    def write_meta(self, rel_path: str, data: dict, *, preserve_mtime: bool = False) -> None:
        meta_path = self._safe_path(rel_path) / CACHE_META
        mtime = None
        if preserve_mtime:
            try:
                mtime = meta_path.stat().st_mtime
            except OSError:
                pass
        tid = threading.get_ident()
        tmp = meta_path.with_suffix(f".{os.getpid()}.{tid}.tmp")
        tmp.write_text(json.dumps(data))
        tmp.replace(meta_path)
        if mtime is not None:
            os.utime(meta_path, (mtime, mtime))

    def touch_access(self, rel_path: str) -> None:
        meta_path = self._safe_path(rel_path) / CACHE_META
        try:
            os.utime(meta_path)
        except OSError:
            pass

    def scan_entries(self) -> list[ModelInfo]:
        entries: list[ModelInfo] = []
        for meta_path in self._root.rglob(CACHE_META):
            model_dir = meta_path.parent
            if model_dir == self._root:
                continue
            rel = model_dir.relative_to(self._root).as_posix()
            meta = self.read_meta(rel)
            try:
                mtime = meta_path.stat().st_mtime
            except OSError:
                continue
            entries.append(
                ModelInfo(
                    path=rel,
                    size=meta.get("size", 0),
                    last_access=mtime,
                    access_count=meta.get("access_count", 0),
                )
            )
        return entries

    def compute_dir_size(self, rel_path: str) -> int:
        dir_path = self._safe_path(rel_path)
        total = 0
        try:
            for f in dir_path.rglob("*"):
                if f.is_file() and not f.name.startswith(CACHE_META):
                    try:
                        total += f.stat().st_size
                    except OSError:
                        continue
        except OSError:
            pass
        return total

    def cleanup_temp_files(self) -> None:
        for tmp_path in self._root.rglob(f"{CACHE_META}.*.tmp"):
            try:
                parts = tmp_path.name.split(".")
                pid = int(parts[-3])
                if not _is_process_alive(pid):
                    tmp_path.unlink(missing_ok=True)
            except (ValueError, IndexError):
                tmp_path.unlink(missing_ok=True)

    def __repr__(self) -> str:
        return f"LocalStorage({self._root})"


def _rmtree_onerror(func: object, path: str, exc_info: object) -> None:
    """Handle read-only files on Windows during rmtree."""
    os.chmod(path, stat.S_IWRITE)
    os.unlink(path)


def _is_process_alive(pid: int) -> bool:
    """Check if a process is still running (cross-platform).

    On Unix, uses ``os.kill(pid, 0)``. On Windows, uses
    ``OpenProcess`` via ctypes because ``os.kill(pid, 0)`` sends
    ``CTRL_C_EVENT`` instead of checking liveness.
    """
    if sys.platform == "win32":
        import ctypes

        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        SYNCHRONIZE = 0x00100000
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            kernel32.CloseHandle(handle)
            return True
        return False
    try:
        os.kill(pid, 0)
    except PermissionError:
        return True  # exists but we can't signal it
    except OSError:
        return False
    return True
