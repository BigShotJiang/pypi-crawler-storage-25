# Citations

If you use DockSuiteX (Python package or GUI application) in your research, please cite it as:

**Sinha, M. G. (2025). *DockSuiteX: An all-in-one protein-ligand docking package and GUI application* [Computer software]. GitHub. https://github.com/MangalamGSinha/DockSuiteX**

DockSuiteX builds upon the following excellent tools. Please cite them as appropriate:

### AutoDock Vina

**Reference:** Trott, O., & Olson, A. J. (2010). AutoDock Vina: improving the speed and accuracy of docking with a new scoring function, efficient optimization, and multithreading. *Journal of computational chemistry*, 31(2), 455-461.

### AutoDock4

**Reference:** Morris, G. M., Huey, R., Lindstrom, W., Sanner, M. F., Belew, R. K., Goodsell, D. S., & Olson, A. J. (2009). AutoDock4 and AutoDockTools4: Automated docking with selective receptor flexibility. *Journal of computational chemistry*, 30(16), 2785-2791.

### P2Rank

**Reference:** Krivák, R., & Hoksza, D. (2018). P2Rank: machine learning based tool for rapid and accurate prediction of ligand binding sites from protein structure. *Journal of cheminformatics*, 10(1), 1-12.

### Open Babel

**Reference:** O'Boyle, N. M., Banck, M., James, C. A., Morley, C., Vandermeersch, T., & Hutchison, G. R. (2011). Open Babel: An open chemical toolbox. *Journal of cheminformatics*, 3(1), 1-14.

### MGLTools

**Reference:** MGLTools. (n.d.). MGLTools software suite. Center for Computational Structural Biology, The Scripps Research Institute. Retrieved November 28, 2025, from https://ccsb.scripps.edu/mgltools/

### PDBFixer

**Reference:** PDBFixer development team. (n.d.). PDBFixer [software]. https://github.com/openmm/pdbfixer

### NGLView

**Reference:** Nguyen, H., Case, D. A., & Rose, A. S. (2018). NGLview–interactive molecular graphics for Jupyter notebooks. Bioinformatics, 34(7), 1241-1242.

### ProLIF

**Reference:** Bouysset, C., & Fiorucci, S. (2021). ProLIF: a library to encode molecular interactions as fingerprints. *Journal of Cheminformatics*, 13(1), 72.

---

## Data Sources

### RCSB Protein Data Bank

**Reference:** Berman, H. M., Westbrook, J., Feng, Z., Gilliland, G., Bhat, T. N., Weissig, H., ... & Bourne, P. E. (2000). The protein data bank. *Nucleic acids research*, 28(1), 235-242.

### PubChem

**Reference:** Kim, S., Chen, J., Cheng, T., Gindulyte, A., He, J., He, S., ... & Bolton, E. E. (2025). PubChem 2025 update. Nucleic acids research, 53(D1), D1516-D1525.

### ChEMBL

**Reference:** Mendez, D., Gaulton, A., Bento, A. P., Chambers, J., De Veij, M., Félix, E., ... & Leach, A. R. (2019). ChEMBL: towards direct deposition of bioassay data. *Nucleic acids research*, 47(D1), D930-D940.

---

## How to Cite

When using DockSuiteX in your research, we recommend citing:

1. **DockSuiteX** (main package)
2. **The specific docking engine(s)** you used (AutoDock Vina and/or AutoDock4)
3. **P2Rank** if you used pocket prediction
4. **ProLIF** if you used interaction profiling
5. **Other tools** as appropriate for your workflow

