# BatchLigand API

::: docksuitex.batch_docking.batch_ligand.BatchLigand