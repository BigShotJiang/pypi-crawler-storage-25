# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

gistfs is a Python library that uses GitHub Gists as a persistent key-value filesystem, designed for AI agent memory. It provides a layered architecture:

- **GistFS** (`gistfs/core.py`) — Low-level filesystem abstraction over a single gist. Handles CRUD on gist files via the GitHub API, with local caching and a context manager interface. Also provides `GistFile`, a `io.StringIO` subclass for file-like read/write/append.
- **GistMemory** (`gistfs/memory.py`) — Higher-level key-value store built on GistFS. Supports collections (each collection = one JSON file in the gist).
- **Integrations** (`gistfs/integrations/`) — Adapters that implement third-party store interfaces:
  - `GistKVStore` (LlamaIndex `BaseKVStore`) — delegates to GistMemory
  - `GistStore` (LangGraph `BaseStore`) — uses GistFS directly, maps namespace tuples to filenames (`("user", "prefs")` → `user__prefs.json`)

## Commands

```bash
# Install (uses uv, hatchling build backend)
uv pip install -e ".[dev,all]"

# Run all tests (requires GITHUB_TOKEN — tests hit the live GitHub API)
uv run pytest

# Run a single test file or test
uv run pytest tests/test_core.py
uv run pytest tests/test_core.py::test_write_and_read -v
```

## Testing

Tests are **live integration tests** — they create a real gist, run operations, then delete it. The `test_gist` session-scoped fixture in `tests/conftest.py` handles gist lifecycle. A `GITHUB_TOKEN` env var with `gist` scope is required; tests skip if it's missing. A `.env` file is loaded via `python-dotenv`.

## Key design decisions

- All gist file content is JSON-serialized. Non-JSON content is stored/returned as raw strings.
- GistFS uses an in-memory `_cache` dict synced from the API. The cache is populated on `sync()` / context manager entry and cleared on exit.
- Write operations (`write`, `delete`) hit the GitHub API immediately then update the local cache — there is no batching or deferred flush.
- `GistFile.close()` flushes writes to the gist; the context manager calls `close()` automatically.
