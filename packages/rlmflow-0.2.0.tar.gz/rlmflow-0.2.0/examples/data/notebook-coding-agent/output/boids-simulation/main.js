// output/boids-simulation/main.js
import { Simulation } from './sim.js';

function setup() {
  const canvas = document.getElementById('boids-canvas');
  const sim = new Simulation(canvas);

  function onResize() {
    sim.resize();
  }
  window.addEventListener('resize', onResize);

  sim.start();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setup);
} else {
  setup();
}
