from typing import Optional

__version__ = '0.0.4'

__seed__: Optional[int] = None
