###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

"""TriggerCalib: Trigger efficiency calculation and validation package

This package provides tools for calculating trigger efficiencies in HEP experiments
and validating the calculations through various statistical tests.
"""

from triggercalib.core import (
    Binning,
    Sideband,
    Model,
    Fitter,
    SidebandEff,
    FitCountEff,
    SWeightsEff,
)

__all__ = [
    "Binning",
    "Sideband",
    "Model",
    "Fitter",
    "SidebandEff",
    "FitCountEff",
    "SWeightsEff",
]
