###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from ctypes import c_double
import json
import pytest
import os

import matplotlib.pyplot as plt
import mplhep as hep
import numpy as np
import ROOT as R

hep.style.use("LHCb2")
R.gROOT.SetBatch(True)

os.makedirs("results", exist_ok=True)


def test_regex(example_file):
    from triggercalib import SidebandEff

    tree, path = example_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_regex = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1.*",
        tos="Hlt1.*One",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        uncertainty_method="poisson",
    )

    sideband_explicit = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis=["Hlt1DummyOne", "Hlt1DummyTwo"],
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        uncertainty_method="poisson",
    )

    assert sideband_regex.tis == sideband_explicit.tis
    assert sideband_regex.tos == sideband_explicit.tos


def test_uncertainty_methods(example_file):
    import yaml
    from triggercalib import SidebandEff

    tree, path = example_file
    sideband = {
        "variable": "discrim",
        "signal": [5100, 5300],
        "sidebands": [[5000, 5100], [5300, 5400]],
    }
    binning = {"variables": ["observ1"], "bins": [np.linspace(0, 8, 5)]}

    sideband_eff_poisson_errors = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        uncertainty_method="poisson",
    )

    sideband_eff_generalised_wilson_errors = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        uncertainty_method="generalised_wilson",
    )

    sideband_eff_standard_wilson_errors = SidebandEff(
        path=path,
        tree=tree,
        binning=binning,
        tis="Hlt1DummyOne",
        tos="Hlt1DummyOne",
        particle="P",
        sideband=sideband,
        cut="discrim > 5000 && discrim < 5400",
        uncertainty_method="standard_wilson",
    )

    x = c_double(0)
    y = c_double(0)
    values = {
        "x": [],
        "poisson": [],
        "poisson_error": [],
        "generalised_wilson": [],
        "generalised_wilson_error": [],
        "standard_wilson": [],
        "standard_wilson_error": [],
    }

    for label, efficiency_obj in zip(
        ("poisson", "generalised_wilson", "standard_wilson"),
        (
            sideband_eff_poisson_errors,
            sideband_eff_generalised_wilson_errors,
            sideband_eff_standard_wilson_errors,
        ),
    ):
        hist_tgraph = efficiency_obj.efficiencies["trig_efficiency_observ1"]
        for point in range(hist_tgraph.GetN()):
            hist_tgraph.GetPoint(point, x, y)
            if label == "poisson":
                values["x"].append(x.value)
            values[label].append(y.value)
            values[f"{label}_error"].append(hist_tgraph.GetErrorY(point))

    with open("results/test_uncertainty_methods_results.json", "w") as outfile:
        json.dump(values, outfile, indent=4)

    plt.figure()
    for label, capsize in zip(
        ("poisson", "generalised_wilson", "standard_wilson"), (12, 9, 6)
    ):
        plt.errorbar(
            values["x"],
            values[label],
            yerr=values[f"{label}_error"],
            label=label,
            capsize=capsize,
        )
    plt.xlabel("Observable 1")
    plt.ylabel("Efficiency")
    plt.legend()
    plt.savefig("results/test_uncertainty_methods_results.png")

    assert (
        values["poisson"] == values["generalised_wilson"]
        and values["poisson"] == values["standard_wilson"]
    )


def _check_selection(selection, lines, category):
    from triggercalib.utils.helpers import parse_selection

    if category:
        correct = (
            selection.replace(" ", "")
            == f"({'||'.join(f'P_{line}Decision_{category}' for line in lines)})"
        )
    else:
        correct = (
            selection.replace(" ", "")
            == f"({'||'.join(f'{line}Decision' for line in lines)})"
        )

    if not correct:
        print(
            f"Selection '{selection}' was not produced correctly, instead as '{selection}"
        )
        raise RuntimeError
    return


def test_parse_selection_no_trig():
    from triggercalib.utils.helpers import parse_selection

    lines = ("Hlt1DummyOne", "Hlt1DummyTwo")
    branches = {
        "Hlt1DummyOneDecision",
        "P_Hlt1DummyOneDecision_TOS",
        "P_Hlt1DummyOneDecision_TIS",
        "P_Hlt1DummyTwoDecision_TOS",
        "P_Hlt1DummyTwoDecision_TIS",
    }

    for category in ("TIS", "TOS"):
        selection = parse_selection(
            "P",
            lines,
            category,
            branches,
        )
        _check_selection(selection, lines, category)

    with pytest.raises(RuntimeError):
        parse_selection(
            "P",
            lines,
            "",
            branches,
        )


def test_parse_selection_with_trig():
    from triggercalib.utils.helpers import parse_selection

    lines = ("Hlt1DummyOne", "Hlt1DummyTwo")
    branches = {
        "Hlt1DummyOneDecision",
        "P_Hlt1DummyOneDecision_TOS",
        "P_Hlt1DummyOneDecision_TIS",
        "Hlt1DummyTwoDecision",
        "P_Hlt1DummyTwoDecision_TOS",
        "P_Hlt1DummyTwoDecision_TIS",
    }

    for category in ("TIS", "TOS", ""):
        selection = parse_selection("P", lines, category, branches)
        _check_selection(selection, lines, category)


def test_parse_selection_regex_with_trig():
    from triggercalib.utils.helpers import parse_selection

    lines = "Hlt1Dummy.*"
    branches = {
        "Hlt1DummyOneDecision",
        "P_Hlt1DummyOneDecision_TOS",
        "P_Hlt1DummyOneDecision_TIS",
        "Hlt1DummyTwoDecision",
        "P_Hlt1DummyTwoDecision_TOS",
        "P_Hlt1DummyTwoDecision_TIS",
    }

    for category in ("TIS", "TOS", ""):
        selection = parse_selection("P", lines, category, branches)
        _check_selection(selection, ["Hlt1DummyOne", "Hlt1DummyTwo"], category)


def test_loading_multiple_files(example_file, example_sparse_file):
    from triggercalib.utils.io import configure_rdf

    path, tree = example_file
    second_path, _ = example_sparse_file
    rdf = configure_rdf(
        [path, second_path],
        tree,
    )
