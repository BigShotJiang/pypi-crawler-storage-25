###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################


import itertools as it
import os
import subprocess

import numpy as np
import ROOT as R

from triggercalib.utils.tests import check_result

os.makedirs("results", exist_ok=True)
R.gROOT.SetBatch(True)


def test_cli_sideband_command(example_file):
    tree, path = example_file

    tests_path = os.path.dirname(os.path.realpath(__file__))

    binning_config = os.path.join(tests_path, "config/binning.yaml")
    sideband_config = os.path.join(tests_path, "config/sideband.yaml")

    command = " ".join(
        [
            "triggercalib.sideband",
            f"--path {path}",
            f"--tree {tree}",
            f"--binning {binning_config}",
            f"--sideband {sideband_config}",
            "--particle P",
            "--tis Hlt1DummyOne",
            "--tos Hlt1DummyOne",
            '--cut "discrim > 5000 && discrim < 5400"',
            "--output results/output_test_cli_sideband.root",
            "--threads 4",
        ]
    )

    subprocess.Popen("rm results/output_test_cli_sideband.root", shell=True)
    subprocess.Popen("sleep 3", shell=True)
    p = subprocess.Popen(command, shell=True)
    print(f"Running command: {command}")
    p.wait()

    with R.TFile.Open("results/output_test_cli_sideband.root", "READ") as f:
        effs = f.Get("efficiencies")
        hist = effs.Get("trig_total_efficiency_observ1")
        val = hist.GetPointY(0)
        err_low = hist.GetErrorYlow(0)
        err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError


def test_cli_fit_and_count_command(example_file):
    tree, path = example_file

    tests_path = os.path.dirname(os.path.realpath(__file__))

    binning_config = os.path.join(tests_path, "config/binning.yaml")
    model_config = os.path.join(tests_path, "config/model.yaml")

    command = " ".join(
        [
            "triggercalib.fit_and_count",
            f"--path {path}",
            f"--tree {tree}",
            f"--binning {binning_config}",
            f"--fit-description {model_config}",
            "--particle P",
            "--tis Hlt1DummyOne",
            "--tos Hlt1DummyOne",
            '--cut "discrim > 5000 && discrim < 5400"',
            "--output results/output_test_cli_fit_and_count.root",
            "--threads 4",
        ]
    )

    subprocess.Popen("rm results/output_test_cli_fit_and_count.root", shell=True)
    subprocess.Popen("sleep 3", shell=True)
    p = subprocess.Popen(command, shell=True)
    print(f"Running command: {command}")
    p.wait()

    with R.TFile.Open("results/output_test_cli_fit_and_count.root", "READ") as f:
        effs = f.Get("efficiencies")
        hist = effs.Get("trig_total_efficiency_observ1_N_signal")
        val = hist.GetPointY(0)
        err_low = hist.GetErrorYlow(0)
        err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError


def test_cli_sweights_command(example_file):
    tree, path = example_file

    tests_path = os.path.dirname(os.path.realpath(__file__))

    binning_config = os.path.join(tests_path, "config/binning.yaml")
    model_config = os.path.join(tests_path, "config/model.yaml")

    command = " ".join(
        [
            "triggercalib.sweights",
            f"--path {path}",
            f"--tree {tree}",
            f"--binning {binning_config}",
            f"--fit-description {model_config}",
            "--particle P",
            "--tis Hlt1DummyOne",
            "--tos Hlt1DummyOne",
            '--cut "discrim > 5000 && discrim < 5400"',
            "--output results/output_test_cli_sweights.root",
            "--threads 4",
        ]
    )

    subprocess.Popen("rm results/output_test_cli_sweights.root", shell=True)
    subprocess.Popen("sleep 3", shell=True)
    p = subprocess.Popen(command, shell=True)
    print(f"Running command: {command}")
    p.wait()

    with R.TFile.Open("results/output_test_cli_sweights.root", "READ") as f:
        effs = f.Get("efficiencies")
        hist = effs.Get("trig_total_efficiency_observ1_N_signal")
        val = hist.GetPointY(0)
        err_low = hist.GetErrorYlow(0)
        err_high = hist.GetErrorYhigh(0)

    result_okay, (true, lower, upper) = check_result(
        val,
        (err_low, err_high),
        f"{path}:{tree}",
        cut="discrim > 5100 && discrim < 5300 && observ1 > 0 && observ1 < 8",
    )
    if not result_okay:
        print(f"Computed efficiency out of bounds: {true} not in ({lower}-{upper})")
        raise RuntimeError
