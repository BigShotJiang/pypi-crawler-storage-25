###############################################################################
# (c) Copyright 2024-2026 CERN for the benefit of the LHCb Collaboration      #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import json
import os
from typing import List, Union
import yaml

import ROOT as R


def load_config(path: str):
    """
    Load a configuration file from a JSON or YAML file

    Args:
        path (str): Path to the configuration file

    Returns:
        (dict): Configuration as a dictionary
    """

    if path.endswith(".json"):
        with open(path, "r") as config_file:
            config = json.load(config_file)
    elif path.endswith(".yaml"):
        with open(path, "r") as config_file:
            config = yaml.safe_load(config_file)
    else:
        raise ValueError(f"Config '{path}' must be a '.json' or '.yaml' file")

    if config is None:
        raise RuntimeError
    return config


def configure_rdf(
    path: Union[str, List[str]],
    tree: str,
    friend_path: Union[str, List[str]] = None,
    friend_tree: str = None,
    cut: Union[List, str] = None,
):
    """
    Create and store ROOT RDataFrame object from the input files

    Args:
        path (List[str], str): Input file path
        tree (str): Tree name
        friend_path (List[str], str): Friend file path
        friend_tree (str): Friend tree name
        cut (str, optional): Cut expression

    Returns:
        (ROOT.RDataFrame): Loaded data with any specified cuts applied

    Note:
        `friend_path` and `friend_tree` must be specified together if provided
    """

    print(f"INFO: Loading '{tree}' from '{path}'")

    has_friend = friend_path is not None or friend_tree is not None
    if has_friend:
        assert (
            friend_path is not None and friend_tree is not None
        ), "Must provide both `friend_path` and `friend_tree`"
        assert (isinstance(path, str) or len(path) == 1) and (
            isinstance(friend_path, str) or len(friend_path) == 1
        ), "Friend feature works only with 1 main and 1 friend file"

        _file = R.TFile(path[0] if isinstance(path, List) else path)
        _tree = _file.Get(tree)
        _tree.ResetBit(R.TTree.kEntriesReshuffled)

        print(f"INFO: Adding friend tree '{friend_tree}' from '{friend_path}'")

        _friend_file = R.TFile(
            friend_path[0] if isinstance(friend_path, List) else friend_path
        )
        _friend_tree = _friend_file.Get(friend_tree)
        _tree.AddFriend(_friend_tree)

        rdf = R.RDataFrame(_tree)
    else:
        rdf = R.RDataFrame(tree, path)

    if cut is not None:
        if not isinstance(cut, List):
            cut = [cut]

        for c in cut:
            rdf = rdf.Filter(c)

    if has_friend:
        rdf._file = _file
        rdf._tree = _tree
        rdf._friend_file = _friend_file
        rdf._friend_tree = _friend_tree
    return rdf


def is_in_rdf(branch: Union[str, List[str]], rdf: R.RDataFrame):
    """
    Check if a branch is in an RDataFrame

    Args:
        branch (str): Branch to check
        rdf (ROOT.RDataFrame): RDataFrame to check

    Returns:
        (bool): True if the branch is in the RDataFrame
    """
    rdf_branches = [str(col) for col in rdf.GetColumnNames()]

    if not isinstance(branch, List):
        branch = [branch]

    clean_branches = []
    for b in branch:
        if b.endswith(
            "]"
        ):  # Handles the possibility of RVec weights, which would be referenced by [i]
            clean_branches.append(b.rsplit("[", 1)[0])
        else:
            clean_branches.append(b)

    return all([b in rdf_branches for b in clean_branches])


def write_config(config: dict, path: str):

    if "/" in path:
        os.makedirs(path.rsplit("/", 1)[0], exist_ok=True)

    if path.endswith(".json"):
        with open(path, "w") as config_file:
            json.dump(config, config_file, indent=4)
    elif path.endswith(".yaml"):
        with open(path, "w") as config_file:
            yaml.dump(config, config_file, default_flow_style=False)
    else:
        raise ValueError(f"Config '{path}' must be a '.json' or '.yaml' file")


def split_paths(paths: Union[List[str], str], require_same_tree: bool = True):
    """Split ROOT file paths into tree names and file paths

    Args:
        paths: Path(s) to ROOT file(s) of the form <path>:<tree>
        require_same_tree: Whether all paths must reference the same tree

    Returns:
        (Union[str, List[str]]): Tree name(s)
        (Union[List[str], str]): File path(s)

    Raises:
        ValueError: If require_same_tree is True and different trees are provided
    """
    if isinstance(paths, str):
        paths = [paths]

    split_trees = []
    split_paths = []

    for p in paths:
        split_path, split_tree = p.rsplit(":", 1)
        split_trees.append(split_tree)
        split_paths.append(split_path)

    if len(set(split_trees)) == 1 and require_same_tree:
        return split_trees[0], split_paths
    elif not require_same_tree:
        return split_trees, split_paths

    raise ValueError(
        f"Same tree must be provided for all paths. Trees '{split_trees}' were provided."
    )
