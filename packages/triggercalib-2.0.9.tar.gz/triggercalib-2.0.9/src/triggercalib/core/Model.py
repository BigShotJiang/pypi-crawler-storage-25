###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from typing import Dict, List

import ROOT as R


class Model:
    """
    Class for creating and holding models used in fits for trigger efficiencies

    Attributes:
        pdf (R.RooAbsPdf): total PDF to be fit
        pdfs (List[R.RooAbsPdf]): List of PDFs from which `pdf` is formed
        yields (List[R.RooAbsReal]): List of yields used to construct `pdf` from `pdfs`
    """

    def __init__(
        self,
        observable,
        components: Dict = None,
        pdf: R.RooAddPdf = None,
        n_evts: int = 1e6,
    ):
        """
        Constructor for the `Model` class

        Args:
            observable (R.RooAbsReal): observable to be used in the fit
            components (Dict): dictionary of components from which to construct the model
            pdf (R.RooAddPdf): an existing extended PDF to import and use
            n_evts (int): total number of events, used to set maxima of yields
        """

        assert (components is not None) + (pdf is not None) == 1

        if components is not None:
            self.build_model(observable, components, n_evts=n_evts)
        elif pdf is not None:
            self.pdf = pdf
            self.pdfs = pdf.pdfList()
            self.yields = pdf.coefList()
            for yield_var in self.yields:
                yield_var.setMin(0.0)
                if yield_var.getVal() > n_evts * 1.5:
                    yield_var.setVal(n_evts / len(self.yields))
                    yield_var.setMax(n_evts * 1.5)
                else:
                    yield_var.setMax(n_evts * 1.5)
                    yield_var.setVal(n_evts / len(self.yields))

    def build_model(self, observable, components, n_evts):
        """
        Build a model from a given description

        Args:
            observable (R.RooAbsReal): observable to be used in the fit
            components (Dict): dictionary of components from which to construct the model
            n_evts (int): total number of events, used to set maxima of yields
        """

        self.pdfs = []
        self.yields = []
        self.ws = R.RooWorkspace("")
        self.ws.Import(observable)
        for name, component in components.items():
            param_strings = []
            for param_name, param_values in component["parameters"].items():
                if not isinstance(param_values, List):
                    param_values = [param_values]
                param_strings.append(
                    f"{param_name}[{', '.join([str(v) for v in param_values])}]"
                )
            self.ws.factory(
                f"Roo{component['function']}::{name}_pdf({observable.GetName()}, {', '.join(param_strings)})"
            )
            self.ws.factory(
                f"N_{name}[{n_evts * 1 / len(components.keys())}, 0.0, {n_evts * 1.2}]"
            )

            self.pdfs.append(self.ws.pdf(f"{name}_pdf"))
            self.yields.append(self.ws.var(f"N_{name}"))

            # TODO: make a more comprehensive model builder (composite components for example)
        self.pdf = self.ws.factory(
            f"SUM::total_pdf({', '.join(f'N_{name} * {name}_pdf' for name in components.keys())})"
        )
