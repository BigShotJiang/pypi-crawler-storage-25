###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

from typing import List, Union

import numpy as np
import ROOT as R


class Binning:
    """
    A class for representing a binning scheme.

    Attributes:
        variables (List[str]): A list of variable names.
        bins (List[List[float]]): A list of lists of bin edges for each variable.
        labels (List[str]): A list of labels for each variable.
        edges (List[List[List[float]]]): A list of lists of bin edges for each variable.
        midpoints (List[List[float]]): A list of lists of bin midpoints for each variable.
    """

    def __init__(
        self,
        variables: List[str],
        bins: List[List[float]],
        labels: List[str] = None,
    ):
        """
        Constructor for the Binning class.

        Args:
            variables (List[str]): A list of variable names.
            bins (List[List[float]]): A list of lists of bin edges for each variable.
            labels (List[str], optional): A list of labels for each variable.
        """
        self.variables = variables
        self.bins = bins
        self.labels = labels if labels is not None else variables

        self.edges = [
            [[_bins[i], _bins[i + 1]] for i in range(len(_bins) - 1)]
            for _bins in self.bins
        ]

        self.midpoints = [
            [(_bins[i] + _bins[i + 1]) / 2 for i in range(len(_bins) - 1)]
            for _bins in self.bins
        ]

    @classmethod
    def generate(
        cls,
        rdf: R.RDataFrame,
        variables: List[str],
        limits: List[List[float]],
        n_bins: List[int],
        cut: Union[str, List[str]] = None,
    ):
        """
        Generates a Binning object based on an RDataFrame and a list of variables.

        Args:
            rdf (R.RDataFrame): to generate the Binning object from.
            variables (List[str]): The list of variables to generate the Binning object for.
            limits (List[List[float]]): The list of limits for each variable.
            n_bins (List[int]): The number of bins for each variable.
            cut (Union[str, List[str]], optional): The cuts to apply to the RDataFrame before generating the Binning object.

        Returns:
            (Binning): The generated Binning object.
        """
        if (
            len(variables) != len(limits)
            or len(variables) != len(n_bins)
            or len(limits) != len(n_bins)
        ):
            raise ValueError(
                "Arguments `variables`, `limits` and n_bins must be the same length"
            )
        for variable, lims in zip(variables, limits):
            if len(lims) != 2:
                raise ValueError("Limits must be given in pairs")
            rdf = rdf.Filter(f"{variable} > {lims[0]} & {variable} < {lims[1]}")

        if cut is not None:
            if not isinstance(cut, List):
                cut = [cut]

            for _cut in cut:
                rdf = rdf.Filter(_cut)

        np_df = rdf.AsNumpy(variables)

        bins = []
        for variable, lims, n in zip(variables, limits, n_bins):
            edges = np.quantile(np_df[variable], np.arange(1, n) / n)
            edges = np.append(lims[0], edges)
            edges = np.append(edges, lims[1])
            bins.append(edges)

        return cls(variables, bins)
