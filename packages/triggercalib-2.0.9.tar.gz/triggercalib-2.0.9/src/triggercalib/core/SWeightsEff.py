###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration           #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import itertools as it
from typing import Dict, List, Union

import numpy as np
import ROOT as R

from triggercalib.core.BaseEff import BaseEff
from triggercalib.core.Fitter import Fitter

from triggercalib.utils import helpers, io


class SWeightsEff(BaseEff):
    """
    Class for calculating trigger efficiencies using the sWeights method to mitigate background contributions.

    This class is a subclass of `BaseEff` and inherits all its methods and properties.

    Attributes:
        fitters (dict): A dictionary containing the sWeights fitters for each category.
        fit_results (dict): A dictionary containing the fit results for each category.
        sweights (dict): A dictionary containing the sWeights for each category.
        counts (dict): A dictionary containing the counts histograms for each category.
        fit_kwargs (dict): A dictionary containing the keyword arguments for the fit.
        plot_kwargs (dict): A dictionary containing the keyword arguments for the plot.
    """

    def __init__(
        self,
        fit_description: Union[Dict[str, List[float]], str] = None,
        pdf: R.RooAddPdf = None,
        observable: R.RooAbsReal = None,
        workspace: Union[R.RooWorkspace, str] = None,
        ws_observable: str = None,
        ws_pdf: str = None,
        fit_kwargs: Dict = {},
        plot_kwargs: Dict = {},
        max_attempts: int = 5,
        *args,
        **kwargs,
    ):
        """
        Constructor for the `SWeightsEff` class

        Args:
            fit_description (Union[Dict[str, List[float]], str], optional): Description of the fit. Defaults to None.
            pdf (R.RooAddPdf, optional): The PDF used for fitting. Defaults to None.
            observable (R.RooAbsReal, optional): The observable used for fitting. Defaults to None.
            workspace (Union[R.RooWorkspace, str], optional): The workspace used for fitting. Defaults to None.
            ws_observable (str, optional): The observable name in the workspace. Defaults to None.
            ws_pdf (str, optional): The PDF name in the workspace. Defaults to None.
            fit_kwargs (Dict, optional): The keyword arguments for the fit. Defaults to {}.
            plot_kwargs (Dict, optional): The keyword arguments for the plot. Defaults to {}.

        Note:
            Exactly one of fit_description, pdf and observable together, or workspace, ws_pdf and ws_observable together must be passed.
        """
        super().__init__(*args, **kwargs)

        self.fitters = {}
        self.fit_results = {}
        self.sweights = {}
        assert (
            int(fit_description is not None)
            + int(pdf is not None and observable is not None)
            + int(
                workspace is not None
                and ws_observable is not None
                and ws_pdf is not None
            )
            == 1
        ), "Exactly one of fit_description, pdf and observable together, or workspace, ws_pdf and ws_observable together must be passed"

        self.fit_kwargs = fit_kwargs
        self.plot_kwargs = plot_kwargs
        self.max_attempts = max_attempts

        self.fit_description = None
        self.pdf = None
        self.observable = None
        if fit_description is not None:
            if isinstance(fit_description, str):
                fit_description = io.load_config(fit_description)
            self.fit_description = fit_description

            self.observable = R.RooRealVar(
                self.fit_description["data"]["variable"],
                self.fit_description["data"][
                    "label" if "label" in self.fit_description["data"] else "variable"
                ],
                *self.fit_description["data"]["range"],
            )
            obs_lims = self.fit_description["data"]["range"]
            if "cuts" in self.fit_description["data"]:
                for cut in self.fit_description["data"]["cuts"]:
                    self.rdf = self.rdf.Filter(cut)
        else:
            if pdf and observable:
                self.observable = observable
                self.pdf = pdf
            elif (
                (workspace is not None)
                and (ws_observable is not None)
                and (ws_pdf is not None)
            ):
                if isinstance(workspace, str):
                    path, ws_name = workspace.rsplit(":", 1)
                    with R.TFile.Open(path, "READ") as f:
                        if ws_name in [k.GetName() for k in f.GetListOfKeys()]:
                            ws = f.Get(ws_name)
                        else:
                            raise RuntimeError
                else:
                    ws = workspace

                self.observable = ws.var(ws_observable)
                self.pdf = ws.pdf(ws_pdf)

                assert (
                    self.observable is not R.nullptr and self.pdf is not R.nullptr
                ), "Could not find observable or pdf in workspace"

            obs_lims = [self.observable.getMin(), self.observable.getMax()]

        self.rdf = self.rdf.Filter(
            f"{self.observable.GetName()} > {obs_lims[0]} && {self.observable.GetName()} < {obs_lims[1]}"
        )

        self._configure_fitters()
        self._sweight_counts()
        for yield_var in self.fitters["tos"].model.yields:
            self.compute_efficiencies(suffix=yield_var.GetName())

    def _configure_fitters(self):
        observables_list = [self.observable.GetName()]
        if self.weight is not None:  # Make a helper for this
            weight_branch = "total_weight"
            if isinstance(self.weight, List):
                self.rdf = self.rdf.Define(weight_branch, "*".join(self.weight))
            else:
                self.rdf = self.rdf.Define(weight_branch, self.weight)
            observables_list += [weight_branch]
        else:
            weight_branch = None

        if not io.is_in_rdf(observables_list, self.rdf):
            raise ValueError(
                f"Could not find all observable(s) {', '.join(observables_list)} not found in the RDataFrame"
            )

        # Book construction of datasets
        dataset_ptrs = {}
        for category in self.get_categories():
            category_rdf = (
                self.rdf.Filter(self.trigger_cut(category))
                if category != "sel"
                else self.rdf
            )

            dataset_ptrs[category] = category_rdf.AsNumpy(
                observables_list + self.binning.variables,
                lazy=True,
            )  # TODO: replace with R.RooDataSet

        bin_observables = [
            R.RooRealVar(var, var, bins[0], bins[-1])
            for var, bins in zip(self.binning.variables, self.binning.bins)
        ]

        # Now get the datasets and use to construct the fitters
        datasets = {
            key: helpers.create_dataset(
                ptr.GetValue(),
                [self.observable] + bin_observables,
                weight=weight_branch,
            )
            for key, ptr in dataset_ptrs.items()
        }

        for name, dataset in datasets.items():
            self.fitters[name] = Fitter(
                self.observable,
                dataset,
                (
                    self.fit_description["model"]
                    if self.fit_description is not None
                    else None
                ),
                (
                    self.pdf.cloneTree(name.replace("_dataset_bin_", "_pdf_"))
                    if self.pdf is not None
                    else None
                ),
                self.max_attempts,
            )

    def _sweight_counts(self):
        for category, fitter in self.fitters.items():

            if fitter.data.sumEntries() < self.min_entries:
                raise RuntimeError("Too few entries to perform sWeight fit")
            self.fit_results[category] = fitter.fit(**self.fit_kwargs)
            splot = fitter.splot()
            sweights = splot.GetSDataSet().to_numpy()
            yields = fitter.model.yields
            for yield_var in yields:
                count_name = f"{category}_count_{'_'.join(self.binning.variables)}_{yield_var.GetName()}"
                self.counts[count_name] = helpers.empty_histogram(
                    count_name, self.binning
                )
                for edges in it.product(*self.binning.edges):
                    indices = np.ones(
                        len(sweights[self.observable.GetName()]), dtype=bool
                    )
                    for variable, edge in zip(self.binning.variables, edges):
                        indices = np.logical_and(indices, sweights[variable] > edge[0])
                        indices = np.logical_and(indices, sweights[variable] < edge[1])

                    weights = sweights[f"{yield_var.GetName()}_sw"][indices]
                    if self.weight is not None:
                        weights *= sweights["total_weight"][indices]

                    midpoints = [(edge[0] + edge[1]) / 2 for edge in edges]
                    nbin = self.counts[count_name].FindBin(*midpoints)

                    self.counts[count_name].SetBinContent(nbin, np.sum(weights))
                    self.counts[count_name].SetBinError(
                        nbin, np.sqrt(np.sum(weights**2))
                    )

        for yield_var in self.fitters["tos"].model.yields:
            self._process_counts(self.observable.GetName(), suffix=yield_var.GetName())

    def write(
        self,
        path,
        prefix: str = "",
        fit_results: bool = True,
        plots: bool = True,
        workspaces: bool = True,
    ):
        """
        Write counts, efficiencies and (optionally) plots and fit results to ROOT file.

        Args:
            path (str): Path to the output file.
            prefix (str, optional): Prefix to add to the output file name. Defaults to "".
            fit_results (bool, optional): Whether to write the fit results to the output file. Defaults to True.
            plots (bool, optional): Whether to write the plots to the output file. Defaults to True.
            workspaces (bool, optional): Whether to write the workspaces to the output file. Defaults to True.
        """
        additional_objects = {}
        if plots:
            additional_objects["plots"] = {
                name: fitter.plot(**self.plot_kwargs)
                for name, fitter in self.fitters.items()
            }
        if fit_results:
            additional_objects["fit_results"] = {
                name: fitter.fit_result for name, fitter in self.fitters.items()
            }
        super().write(path, prefix, additional_objects=additional_objects)
