###############################################################################
# (c) Copyright 2026 CERN for the benefit of the LHCb Collaboration.          #
#                                                                             #
# This software is distributed under the terms of the GNU General Public      #
# Licence version 3 (GPL Version 3), copied verbatim in the file "COPYING".   #
#                                                                             #
# In applying this licence, CERN does not waive the privileges and immunities #
# granted to it by virtue of its status as an Intergovernmental Organization  #
# or submit itself to any jurisdiction.                                       #
###############################################################################

import argparse
from types import SimpleNamespace


def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--path", type=str, required=True, nargs="+")
    parser.add_argument("--tree", type=str, required=True)
    parser.add_argument("--binning", type=str, required=True)
    parser.add_argument("--sideband", type=str, required=True)
    parser.add_argument("--particle", type=str, required=True)
    parser.add_argument("--tis", type=str, required=True, nargs="+")
    parser.add_argument("--tos", type=str, required=True, nargs="+")

    parser.add_argument("--output", type=str, required=True)

    parser.add_argument("--friend-path", type=str, nargs="+", default=None)
    parser.add_argument("--friend-tree", type=str, default=None)
    parser.add_argument("--cut", type=str, default=None, nargs="+")
    parser.add_argument("--weight", type=str, default=None, nargs="+")
    parser.add_argument("--threads", type=int, default=1)

    parser.add_argument("--no-trig", action="store_true")

    return parser.parse_args()


def main(args=None):
    import ROOT as R

    from triggercalib import SidebandEff

    if args is None:
        args = parse_args()
    elif isinstance(args, dict):
        args["threads"] = args.get("threads", 1)
        args["friend_path"] = args.get("friend_path", None)
        args["friend_tree"] = args.get("friend_tree", None)
        args["cut"] = args.get("cut", None)
        args["weight"] = args.get("weight", None)
        args = SimpleNamespace(**args)

    if args.friend_path is not None or args.friend_tree is not None:
        print("INFO: disabling implicit multi-threading")
        R.DisableImplicitMT()
    elif args.threads > 1:
        print(f"INFO: enabling implicit multi-threading with {args.threads} threads")
        R.EnableImplicitMT(args.threads)
        R.DisableImplicitMT()

    sideband_eff = SidebandEff(
        path=args.path,
        tree=args.tree,
        particle=args.particle,
        tis=args.tis,
        tos=args.tos,
        binning=args.binning,
        sideband=args.sideband,
        cut=args.cut,
        friend_path=args.friend_path,
        friend_tree=args.friend_tree,
        trig_effs=not (args.no_trig),
        weight=args.weight,
    )
    sideband_eff.write(args.output)

    return


if __name__ == "__main__":
    main()
