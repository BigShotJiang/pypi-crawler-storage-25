# repo-analyzer

A fast CLI tool for GitHub repository due diligence. It analyzes repository health, engineering hygiene, ownership risk, contributor signals, and recruiter-facing trust indicators directly from the terminal.

```bash
$ repo-analyzer https://github.com/facebook/react --recruiter
```

## Install

```bash
pip install repo-analyzer
```

Or clone and install locally:

```bash
git clone https://github.com/khodorrHajj/GithubRepoAnalyzer.git
cd GithubRepoAnalyzer
pip install -e .
```

## Usage

### Analyze a repo

```bash
repo-analyzer https://github.com/pallets/flask
```

### Recruiter mode

```bash
repo-analyzer https://github.com/pallets/flask --recruiter
```

### Compare two repos

```bash
repo-analyzer compare https://github.com/pallets/flask https://github.com/django/django
```

### Export to JSON

```bash
repo-analyzer https://github.com/torvalds/linux --export json
```

### Export to PDF

```bash
repo-analyzer https://github.com/torvalds/linux --export pdf -o report.pdf
```

### Skip cache

```bash
repo-analyzer https://github.com/pallets/flask --no-cache
```

## GitHub Token

Without a token you are limited to 60 API requests per hour. With a token you get 5,000.

Create a local `.env` file:

```env
GITHUB_TOKEN=ghp_your_token_here
```

Or export it in your shell:

```bash
export GITHUB_TOKEN=ghp_your_token_here
```

The token is loaded from the user machine at runtime. It is not bundled into the package by default.

## What makes it different

- Decision-ready verdicts with strengths, concerns, and concrete recommendations.
- Contributor risk analysis with lead contributor share, bus factor, and ownership concentration.
- Engineering hygiene checks for CI, tests, README, CONTRIBUTING, SECURITY, CODEOWNERS, issue templates, PR templates, releases, and changelog presence.
- Repository scorecard covering maintainability, collaboration, production readiness, onboarding quality, and overall health.
- Trend-aware activity analysis across recent windows instead of only a single snapshot.
- Recruiter mode for evaluating candidate and portfolio repositories with hiring-oriented signals.
- Side-by-side comparison output that includes stronger decision metrics, not only stars and forks.

## Health Score

The health score is a weighted average of five factors:

| Factor | Weight | What it looks at |
| --- | --- | --- |
| Activity | 2.0 | Recent commits and last push recency |
| Community | 2.0 | Stars, forks, and contributor count |
| Maintenance | 2.0 | Open issues, PR pressure, and freshness |
| Quality | 2.5 | CI, tests, docs, license, and operational hygiene |
| Documentation | 1.5 | README, description, topics, and discoverability |

## Project Structure

```text
repo_analyzer/
  cli.py
  api.py
  analyzer.py
  health.py
  display.py
  cache.py
  compare.py
  export.py
tests/
```

## Running Tests

```bash
pip install -e ".[dev]"
pytest -k "not Live"
```

Run the full suite, including live GitHub API checks, only when network access is available:

```bash
pytest
```

## Built With

- Click
- Rich
- Requests
- fpdf2
- pytest

## License

MIT. See [LICENSE](LICENSE).
