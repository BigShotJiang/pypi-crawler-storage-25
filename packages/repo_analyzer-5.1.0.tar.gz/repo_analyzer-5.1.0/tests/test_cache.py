"""
Tests for the cache module.
"""

import os
import json
import time
import tempfile
import shutil

import pytest
from repo_analyzer.cache import CacheManager


class TestCacheManager:
    """Tests for the file-based cache manager."""

    def setup_method(self):
        """Create a temporary cache directory for each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.cache = CacheManager(enabled=True, ttl=60)
        self.cache.CACHE_DIR = self.temp_dir

    def teardown_method(self):
        """Clean up temporary cache directory."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_cache_enabled_by_default(self):
        cm = CacheManager()
        assert cm.enabled is True

    def test_cache_can_be_disabled(self):
        cm = CacheManager(enabled=False)
        assert cm.enabled is False

    def test_set_and_get(self):
        """Test basic cache write and read."""
        url = "https://api.github.com/repos/test/repo"
        data = {"name": "repo", "stars": 100}

        self.cache.set(url, None, data)
        result = self.cache.get(url, None)

        assert result is not None
        assert result["name"] == "repo"
        assert result["stars"] == 100

    def test_set_and_get_with_params(self):
        """Test cache with query parameters."""
        url = "https://api.github.com/repos/test/repo/contributors"
        params = {"per_page": 10, "anon": "false"}
        data = [{"login": "user1", "contributions": 50}]

        self.cache.set(url, params, data)
        result = self.cache.get(url, params)

        assert result is not None
        assert len(result) == 1
        assert result[0]["login"] == "user1"

    def test_different_params_different_cache(self):
        """Different params should produce different cache entries."""
        url = "https://api.github.com/repos/test/repo"
        data1 = {"page": 1}
        data2 = {"page": 2}

        self.cache.set(url, {"page": 1}, data1)
        self.cache.set(url, {"page": 2}, data2)

        result1 = self.cache.get(url, {"page": 1})
        result2 = self.cache.get(url, {"page": 2})

        assert result1["page"] == 1
        assert result2["page"] == 2

    def test_cache_miss_returns_none(self):
        """Non-existent cache entry should return None."""
        result = self.cache.get("https://api.github.com/nonexistent", None)
        assert result is None

    def test_cache_expiry(self):
        """Expired cache entries should return None."""
        self.cache.ttl = 1  # 1 second TTL
        url = "https://api.github.com/repos/test/repo"
        data = {"name": "repo"}

        self.cache.set(url, None, data)

        # Should be available immediately
        result = self.cache.get(url, None)
        assert result is not None

        # Wait for expiry
        time.sleep(1.5)

        # Should be expired now
        result = self.cache.get(url, None)
        assert result is None

    def test_disabled_cache_returns_none(self):
        """Disabled cache should always return None."""
        disabled_cache = CacheManager(enabled=False)
        disabled_cache.set("https://example.com", None, {"data": "test"})
        result = disabled_cache.get("https://example.com", None)
        assert result is None

    def test_clear_all(self):
        """Clear should remove all cache entries."""
        url1 = "https://api.github.com/repos/test/repo1"
        url2 = "https://api.github.com/repos/test/repo2"

        self.cache.set(url1, None, {"name": "repo1"})
        self.cache.set(url2, None, {"name": "repo2"})

        count = self.cache.clear()
        assert count == 2

        assert self.cache.get(url1, None) is None
        assert self.cache.get(url2, None) is None

    def test_clear_empty_cache(self):
        """Clearing an empty cache should return 0."""
        count = self.cache.clear()
        assert count == 0

    def test_clear_expired(self):
        """Clear expired should only remove expired entries."""
        self.cache.ttl = 1  # 1 second TTL
        url_old = "https://api.github.com/repos/test/old"
        url_new = "https://api.github.com/repos/test/new"

        self.cache.set(url_old, None, {"name": "old"})
        time.sleep(1.5)
        self.cache.set(url_new, None, {"name": "new"})

        count = self.cache.clear_expired()
        assert count == 1

        # Old should be gone
        assert self.cache.get(url_old, None) is None
        # New should still be there
        assert self.cache.get(url_new, None) is not None

    def test_corrupted_cache_file(self):
        """Corrupted cache files should be handled gracefully."""
        key = self.cache._make_key("https://example.com", None)
        path = self.cache._cache_path(key)

        # Write corrupted data
        with open(path, "w") as f:
            f.write("not valid json{{{")

        result = self.cache.get("https://example.com", None)
        assert result is None

        # Corrupted file should be removed
        assert not os.path.exists(path)

    def test_make_key_deterministic(self):
        """Same URL and params should always produce the same key."""
        key1 = self.cache._make_key("https://example.com", {"a": 1})
        key2 = self.cache._make_key("https://example.com", {"a": 1})
        assert key1 == key2

    def test_make_key_different_for_different_inputs(self):
        """Different URLs should produce different keys."""
        key1 = self.cache._make_key("https://example.com/1", None)
        key2 = self.cache._make_key("https://example.com/2", None)
        assert key1 != key2

    def test_cache_stores_complex_data(self):
        """Cache should handle complex nested data structures."""
        url = "https://api.github.com/repos/test/repo"
        data = {
            "name": "repo",
            "languages": {"Python": 5000, "JavaScript": 3000},
            "contributors": [
                {"login": "user1", "contributions": 100},
                {"login": "user2", "contributions": 50},
            ],
            "nested": {"deep": {"value": True}},
        }

        self.cache.set(url, None, data)
        result = self.cache.get(url, None)

        assert result["languages"]["Python"] == 5000
        assert len(result["contributors"]) == 2
        assert result["nested"]["deep"]["value"] is True
