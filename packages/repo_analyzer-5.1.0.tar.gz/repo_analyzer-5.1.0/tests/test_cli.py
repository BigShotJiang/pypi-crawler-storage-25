"""
Tests for the CLI entry point.
"""

import pytest
from click.testing import CliRunner
from repo_analyzer.cli import main


class TestCLI:
    """Tests for CLI commands."""

    def setup_method(self):
        self.runner = CliRunner()

    def test_no_args_shows_error(self):
        """Running without arguments should show an error."""
        result = self.runner.invoke(main, [])
        assert result.exit_code != 0

    def test_invalid_url_shows_error(self):
        """Running with an invalid URL should show an error."""
        result = self.runner.invoke(main, ["not-a-valid-url"])
        assert result.exit_code != 0

    def test_help_flag(self):
        """Running with --help should show help text."""
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Analyze any GitHub repository" in result.output

    def test_compare_help(self):
        """Running compare --help should show help text."""
        result = self.runner.invoke(main, ["compare", "--help"])
        assert result.exit_code == 0
        assert "Compare two GitHub repositories" in result.output

    def test_help_includes_recruiter_flag(self):
        result = self.runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "--recruiter" in result.output
