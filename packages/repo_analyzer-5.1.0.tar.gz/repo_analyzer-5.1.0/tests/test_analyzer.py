"""
Tests for the core analyzer module.
"""

import pytest
from repo_analyzer.analyzer import RepoAnalyzer


class TestLanguagePercentages:
    """Tests for language percentage calculation."""

    def setup_method(self):
        self.analyzer = RepoAnalyzer.__new__(RepoAnalyzer)

    def test_single_language(self):
        languages = {"Python": 10000}
        result = self.analyzer._calculate_language_percentages(languages)
        assert len(result) == 1
        assert result[0]["language"] == "Python"
        assert result[0]["percentage"] == 100.0

    def test_multiple_languages(self):
        languages = {"Python": 7000, "JavaScript": 3000}
        result = self.analyzer._calculate_language_percentages(languages)
        assert len(result) == 2
        assert result[0]["language"] == "Python"
        assert result[0]["percentage"] == 70.0
        assert result[1]["language"] == "JavaScript"
        assert result[1]["percentage"] == 30.0

    def test_empty_languages(self):
        languages = {}
        result = self.analyzer._calculate_language_percentages(languages)
        assert result == []

    def test_sorted_by_percentage_descending(self):
        languages = {"HTML": 100, "Python": 5000, "CSS": 500}
        result = self.analyzer._calculate_language_percentages(languages)
        percentages = [r["percentage"] for r in result]
        assert percentages == sorted(percentages, reverse=True)


class TestFormatContributors:
    """Tests for contributor formatting."""

    def setup_method(self):
        self.analyzer = RepoAnalyzer.__new__(RepoAnalyzer)

    def test_format_contributors(self):
        contributors = [
            {"login": "user1", "contributions": 100, "avatar_url": "url1", "html_url": "profile1"},
            {"login": "user2", "contributions": 50, "avatar_url": "url2", "html_url": "profile2"},
        ]
        result = self.analyzer._format_contributors(contributors)
        assert len(result) == 2
        assert result[0]["login"] == "user1"
        assert result[0]["contributions"] == 100
        assert result[1]["login"] == "user2"

    def test_empty_contributors(self):
        result = self.analyzer._format_contributors([])
        assert result == []


class TestGetLicenseName:
    """Tests for license name extraction."""

    def setup_method(self):
        self.analyzer = RepoAnalyzer.__new__(RepoAnalyzer)

    def test_mit_license(self):
        repo_info = {"license": {"spdx_id": "MIT", "name": "MIT License"}}
        assert self.analyzer._get_license_name(repo_info) == "MIT"

    def test_no_license(self):
        repo_info = {"license": None}
        assert self.analyzer._get_license_name(repo_info) == "None"

    def test_missing_license_key(self):
        repo_info = {}
        assert self.analyzer._get_license_name(repo_info) == "None"


class TestDaysSince:
    """Tests for date calculation."""

    def setup_method(self):
        self.analyzer = RepoAnalyzer.__new__(RepoAnalyzer)

    def test_invalid_date(self):
        result = self.analyzer._days_since("not-a-date")
        assert result == -1

    def test_empty_string(self):
        result = self.analyzer._days_since("")
        assert result == -1


class TestContributorInsights:
    def setup_method(self):
        self.analyzer = RepoAnalyzer.__new__(RepoAnalyzer)

    def test_contributor_insights_detect_high_risk(self):
        contributors = [
            {"login": "owner", "contributions": 90},
            {"login": "helper", "contributions": 10},
        ]
        result = self.analyzer._build_contributor_insights(contributors)
        assert result["risk_level"] == "high"
        assert result["bus_factor"] == 1

    def test_contributor_insights_detect_low_risk(self):
        contributors = [
            {"login": "a", "contributions": 40},
            {"login": "b", "contributions": 35},
            {"login": "c", "contributions": 25},
        ]
        result = self.analyzer._build_contributor_insights(contributors)
        assert result["risk_level"] == "low"
        assert result["bus_factor"] >= 2


class TestTrendAnalysis:
    def setup_method(self):
        self.analyzer = RepoAnalyzer.__new__(RepoAnalyzer)

    def test_trend_accelerating(self):
        result = self.analyzer._build_trend_analysis(
            {"last_30_days": 60, "last_90_days": 90, "last_180_days": 120},
            {"days_since_last_commit": 3},
        )
        assert result["activity_trend"] == "accelerating"
        assert result["maintenance_status"] == "active"

    def test_trend_inactive(self):
        result = self.analyzer._build_trend_analysis(
            {"last_30_days": 0, "last_90_days": 0, "last_180_days": 0},
            {"days_since_last_commit": 200},
        )
        assert result["activity_trend"] == "inactive"
        assert result["maintenance_status"] == "stale"
