"""
End-to-end integration tests using the live GitHub API.
These tests require a valid GITHUB_TOKEN in .env or environment.

Tests are marked with pytest.mark.e2e so they can be run separately:
    pytest tests/test_e2e.py -v
"""

import os
import json
import tempfile
import shutil

import pytest
from click.testing import CliRunner
from dotenv import load_dotenv

load_dotenv()

from repo_analyzer.api import GitHubAPI
from repo_analyzer.analyzer import RepoAnalyzer
from repo_analyzer.cache import CacheManager
from repo_analyzer.export import Exporter
from repo_analyzer.cli import main


# Skip all tests if no token is available
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
pytestmark = pytest.mark.skipif(
    not GITHUB_TOKEN,
    reason="GITHUB_TOKEN not set - skipping live API tests",
)


class TestLiveAPIBasic:
    """Test basic API calls against the live GitHub API."""

    def setup_method(self):
        self.api = GitHubAPI(token=GITHUB_TOKEN)

    def test_get_repo_info_live(self):
        """Fetch real repo info for a well-known repository."""
        result = self.api.get_repo_info("octocat", "Hello-World")
        assert result["full_name"] == "octocat/Hello-World"
        assert "stargazers_count" in result
        assert "forks_count" in result
        assert "open_issues_count" in result

    def test_get_languages_live(self):
        """Fetch real language data."""
        result = self.api.get_languages("octocat", "Hello-World")
        assert isinstance(result, dict)

    def test_get_contributors_live(self):
        """Fetch real contributor data."""
        result = self.api.get_contributors("octocat", "Hello-World", per_page=5)
        assert isinstance(result, list)

    def test_get_commits_live(self):
        """Fetch real commit data."""
        result = self.api.get_commits("octocat", "Hello-World", per_page=5)
        assert isinstance(result, list)

    def test_get_open_pulls_live(self):
        """Fetch real pull request data."""
        result = self.api.get_open_pulls("octocat", "Hello-World")
        assert isinstance(result, list)

    def test_get_workflows_live(self):
        """Fetch workflow data (may be empty for Hello-World)."""
        result = self.api.get_workflows("octocat", "Hello-World")
        assert "total_count" in result

    def test_get_rate_limit_live(self):
        """Check rate limit status."""
        result = self.api.get_rate_limit()
        assert "rate" in result
        assert "remaining" in result["rate"]
        assert result["rate"]["remaining"] >= 0

    def test_get_contents_live(self):
        """Fetch repository root contents."""
        result = self.api.get_contents("octocat", "Hello-World")
        assert isinstance(result, list)
        # Hello-World should have a README
        names = [item["name"] for item in result]
        assert "README" in names or "README.md" in names


class TestLiveAPIErrorPaths:
    """Test API error handling against the live GitHub API."""

    def setup_method(self):
        self.api = GitHubAPI(token=GITHUB_TOKEN)

    def test_nonexistent_repo(self):
        """Requesting a non-existent repo should raise an error."""
        with pytest.raises(Exception):
            self.api.get_repo_info("this-owner-does-not-exist-12345", "nonexistent-repo-xyz")

    def test_nonexistent_contents_path(self):
        """Requesting a non-existent path should raise an error."""
        with pytest.raises(Exception):
            self.api.get_contents("octocat", "Hello-World", path="this/path/does/not/exist")

    def test_empty_owner(self):
        """Empty owner should raise an error."""
        with pytest.raises(Exception):
            self.api.get_repo_info("", "Hello-World")

    def test_empty_repo(self):
        """Empty repo name should raise an error."""
        with pytest.raises(Exception):
            self.api.get_repo_info("octocat", "")


class TestLiveFullAnalysis:
    """Test the full analysis pipeline against a live repository."""

    def setup_method(self):
        self.cache = CacheManager(enabled=True, ttl=300)
        self.api = GitHubAPI(token=GITHUB_TOKEN, cache_manager=self.cache)
        self.analyzer = RepoAnalyzer(api=self.api)

    def teardown_method(self):
        self.cache.clear()

    def test_full_analysis_hello_world(self):
        """Run full analysis on octocat/Hello-World."""
        result = self.analyzer.analyze("octocat", "Hello-World")

        # Verify all expected keys are present
        expected_keys = [
            "owner", "repo", "full_name", "description", "stars", "forks",
            "watchers", "open_issues", "open_prs", "commits_this_month",
            "language_breakdown", "top_contributors", "quality_signals",
            "health_score", "created_at", "updated_at", "pushed_at",
            "default_branch", "license", "topics",
        ]
        for key in expected_keys:
            assert key in result, f"Missing key: {key}"

        # Verify types
        assert isinstance(result["stars"], int)
        assert isinstance(result["forks"], int)
        assert isinstance(result["health_score"], float)
        assert isinstance(result["language_breakdown"], list)
        assert isinstance(result["top_contributors"], list)
        assert isinstance(result["quality_signals"], dict)

        # Verify health score is in valid range
        assert 0.0 <= result["health_score"] <= 10.0

        # Verify quality signals structure
        qs = result["quality_signals"]
        assert "has_ci_cd" in qs
        assert "has_tests" in qs
        assert "has_readme" in qs
        assert "license" in qs
        assert isinstance(qs["has_readme"], bool)

    def test_full_analysis_larger_repo(self):
        """Run full analysis on a larger, more active repository."""
        result = self.analyzer.analyze("pallets", "flask")

        assert result["full_name"] == "pallets/flask"
        assert result["stars"] > 0
        assert result["forks"] > 0
        assert len(result["language_breakdown"]) > 0
        assert len(result["top_contributors"]) > 0
        assert result["health_score"] > 0

    def test_analysis_caching_works(self):
        """Second analysis should use cached data (faster)."""
        import time

        start1 = time.time()
        result1 = self.analyzer.analyze("octocat", "Hello-World")
        time1 = time.time() - start1

        start2 = time.time()
        result2 = self.analyzer.analyze("octocat", "Hello-World")
        time2 = time.time() - start2

        # Results should be identical
        assert result1["stars"] == result2["stars"]
        assert result1["health_score"] == result2["health_score"]

        # Cached call should be significantly faster
        # (allowing generous margin for CI environments)
        assert time2 < time1 or time2 < 1.0


class TestLiveExport:
    """Test export functionality with live data."""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.cache = CacheManager(enabled=True, ttl=300)
        self.api = GitHubAPI(token=GITHUB_TOKEN, cache_manager=self.cache)
        self.analyzer = RepoAnalyzer(api=self.api)
        self.exporter = Exporter()

    def teardown_method(self):
        self.cache.clear()
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_export_json_live(self):
        """Export live analysis to JSON."""
        data = self.analyzer.analyze("octocat", "Hello-World")
        output_path = os.path.join(self.temp_dir, "hello_world.json")
        self.exporter.export(data, format="json", output_path=output_path)

        assert os.path.exists(output_path)
        with open(output_path, "r", encoding="utf-8") as f:
            exported = json.load(f)

        assert exported["analysis"]["full_name"] == "octocat/Hello-World"
        assert "exported_at" in exported

    def test_export_pdf_live(self):
        """Export live analysis to PDF."""
        data = self.analyzer.analyze("octocat", "Hello-World")
        output_path = os.path.join(self.temp_dir, "hello_world.pdf")
        self.exporter.export(data, format="pdf", output_path=output_path)

        assert os.path.exists(output_path)
        assert os.path.getsize(output_path) > 0

        # Verify PDF header
        with open(output_path, "rb") as f:
            assert f.read(5) == b"%PDF-"


class TestLiveCLI:
    """Test the CLI with live API calls."""

    def test_cli_analyze_hello_world(self):
        """CLI should successfully analyze a real repository."""
        runner = CliRunner()
        result = runner.invoke(main, ["https://github.com/octocat/Hello-World"])

        # Should exit successfully (or with a handled error)
        # Note: may fail if rate limited without token
        if result.exit_code == 0:
            assert "Hello-World" in result.output or "hello" in result.output.lower()

    def test_cli_analyze_with_json_export(self):
        """CLI should export to JSON."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(
                main,
                [
                    "https://github.com/octocat/Hello-World",
                    "--export", "json",
                    "--output", "test_output.json",
                ],
            )

            if result.exit_code == 0:
                assert os.path.exists("test_output.json")
                with open("test_output.json", "r") as f:
                    data = json.load(f)
                assert "analysis" in data

    def test_cli_short_format(self):
        """CLI should accept owner/repo format."""
        runner = CliRunner()
        result = runner.invoke(main, ["octocat/Hello-World"])

        if result.exit_code == 0:
            assert "Hello-World" in result.output or "hello" in result.output.lower()


class TestLiveAPIEdgeCases:
    """Edge case tests with live API."""

    def setup_method(self):
        self.api = GitHubAPI(token=GITHUB_TOKEN)

    def test_repo_with_no_license(self):
        """Some repos may have no license."""
        # octocat/Hello-World may or may not have a license
        result = self.api.get_repo_info("octocat", "Hello-World")
        # Just verify the field exists and doesn't crash
        license_info = result.get("license")
        assert license_info is None or isinstance(license_info, dict)

    def test_repo_with_many_languages(self):
        """Test a repo known to have multiple languages."""
        result = self.api.get_languages("pallets", "flask")
        assert isinstance(result, dict)
        assert len(result) >= 1

    def test_contributors_pagination(self):
        """Test fetching different page sizes of contributors."""
        result_small = self.api.get_contributors("pallets", "flask", per_page=2)
        result_large = self.api.get_contributors("pallets", "flask", per_page=10)

        assert len(result_small) <= 2
        assert len(result_large) <= 10
        assert len(result_large) >= len(result_small)

    def test_unauthenticated_api(self):
        """Test that unauthenticated API still works (lower rate limit)."""
        unauth_api = GitHubAPI(token=None)
        result = unauth_api.get_repo_info("octocat", "Hello-World")
        assert result["full_name"] == "octocat/Hello-World"
