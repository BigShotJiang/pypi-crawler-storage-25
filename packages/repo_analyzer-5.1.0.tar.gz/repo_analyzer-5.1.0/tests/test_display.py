"""
Tests for the terminal display module.
"""

import re
import pytest
from io import StringIO
from rich.console import Console

from repo_analyzer.display import Display


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from text."""
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


# Sample analysis data for testing
SAMPLE_DATA = {
    "owner": "facebook",
    "repo": "react",
    "full_name": "facebook/react",
    "description": "A declarative, efficient, and flexible JavaScript library.",
    "stars": 210000,
    "forks": 44000,
    "watchers": 6500,
    "open_issues": 892,
    "open_prs": 234,
    "commits_this_month": 47,
    "default_branch": "main",
    "license": "MIT",
    "language_breakdown": [
        {"language": "JavaScript", "percentage": 78.5, "bytes": 5000000},
        {"language": "TypeScript", "percentage": 14.2, "bytes": 900000},
        {"language": "HTML", "percentage": 4.1, "bytes": 260000},
    ],
    "top_contributors": [
        {"login": "dan-abramov", "contributions": 1245, "avatar_url": "", "profile_url": ""},
        {"login": "acdlite", "contributions": 987, "avatar_url": "", "profile_url": ""},
        {"login": "bvaughn", "contributions": 654, "avatar_url": "", "profile_url": ""},
    ],
    "quality_signals": {
        "has_ci_cd": True,
        "has_tests": True,
        "has_readme": True,
        "has_contributing": True,
        "has_security": True,
        "has_codeowners": True,
        "has_issue_templates": True,
        "has_pr_template": True,
        "has_changelog": True,
        "has_releases": True,
        "license": "MIT",
        "days_since_last_commit": 2,
    },
    "contributor_insights": {
        "contributor_count": 3,
        "total_top_contributions": 2886,
        "lead_contributor_share": 43.1,
        "top_three_share": 100.0,
        "bus_factor": 2,
        "risk_level": "medium",
    },
    "trend_analysis": {
        "activity_trend": "steady",
        "maintenance_status": "active",
        "last_30_days": 47,
        "last_90_days": 120,
        "last_180_days": 220,
    },
    "repository_scores": {
        "maintainability": 8.8,
        "collaboration": 7.4,
        "production_readiness": 9.0,
        "onboarding": 8.2,
        "recruiter_signal": 8.6,
    },
    "narrative_insights": {
        "verdict": "Well-maintained and low-risk.",
        "strengths": [
            "Engineering hygiene is backed by CI and tests.",
            "New contributors get solid onboarding signals.",
        ],
        "concerns": [
            "Contribution history is somewhat concentrated around a small set of maintainers.",
        ],
        "recommendations": [
            "Reduce ownership concentration by broadening review and merge responsibility.",
            "Add a pull request template to improve review quality.",
        ],
        "recruiter_summary": "facebook/react scores 8.6/10 for recruiter-facing signals.",
    },
    "health_score": 9.2,
}


def _capture_display_output(method, *args, **kwargs):
    """Helper to capture Rich console output as plain text (ANSI stripped)."""
    string_io = StringIO()
    console = Console(file=string_io, force_terminal=True, width=100)
    display = Display(console=console)
    method_func = getattr(display, method)
    method_func(*args, **kwargs)
    return _strip_ansi(string_io.getvalue())


class TestDisplayAnalysis:
    """Tests for the full analysis display."""

    def test_show_analysis_runs_without_error(self):
        """show_analysis should complete without raising exceptions."""
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True, width=100)
        display = Display(console=console)
        display.show_analysis(SAMPLE_DATA)
        output = string_io.getvalue()
        assert len(output) > 0

    def test_show_analysis_contains_repo_name(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "facebook/react" in output

    def test_show_analysis_contains_languages(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "JavaScript" in output
        assert "TypeScript" in output

    def test_show_analysis_contains_contributors(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "dan-abramov" in output
        assert "acdlite" in output

    def test_show_analysis_contains_activity_metrics(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "47" in output  # commits this month
        assert "892" in output  # open issues

    def test_show_analysis_contains_quality_signals(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "ci/cd" in output
        assert "tests" in output
        assert "readme" in output
        assert "MIT" in output

    def test_show_analysis_contains_health_score(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "9.2" in output

    def test_show_analysis_contains_description(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "declarative" in output

    def test_show_analysis_contains_branch(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "main" in output

    def test_show_analysis_contains_summary(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "summary" in output
        assert "verdict" in output

    def test_show_analysis_recruiter_mode(self):
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True, width=100)
        display = Display(console=console)
        display.show_analysis(SAMPLE_DATA, recruiter_mode=True)
        output = _strip_ansi(string_io.getvalue())
        assert "recruiter" in output
        assert "8.6/10" in output


class TestDisplayLanguageBreakdown:
    """Tests for language breakdown display."""

    def test_empty_languages(self):
        data = {**SAMPLE_DATA, "language_breakdown": []}
        output = _capture_display_output("show_analysis", data)
        assert "no language data" in output

    def test_single_language(self):
        data = {
            **SAMPLE_DATA,
            "language_breakdown": [
                {"language": "Python", "percentage": 100.0, "bytes": 10000}
            ],
        }
        output = _capture_display_output("show_analysis", data)
        assert "Python" in output
        assert "100.0%" in output

    def test_many_languages_limited_to_eight(self):
        """Should display at most 8 languages, with a +N more note."""
        languages = [
            {"language": f"Lang{i}", "percentage": round(100 / 12, 1), "bytes": 1000}
            for i in range(12)
        ]
        data = {**SAMPLE_DATA, "language_breakdown": languages}
        output = _capture_display_output("show_analysis", data)
        assert "Lang0" in output
        assert "Lang7" in output
        # Lang8+ should not appear as bars
        assert "Lang8" not in output.split("+")[0] or "+4 more" in output

    def test_language_bar_present(self):
        """Language bars should contain block characters."""
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "█" in output

    def test_language_dot_marker(self):
        """Each language should have a dot marker."""
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "●" in output


class TestDisplayContributors:
    """Tests for contributor display."""

    def test_empty_contributors(self):
        data = {**SAMPLE_DATA, "top_contributors": []}
        output = _capture_display_output("show_analysis", data)
        assert "contributor data unavailable" in output

    def test_contributor_names_shown(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "dan-abramov" in output
        assert "acdlite" in output
        assert "bvaughn" in output

    def test_contributor_commit_counts(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "1,245" in output
        assert "987" in output

    def test_contributors_section_header(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "contributors" in output


class TestDisplayHealthScore:
    """Tests for health score display."""

    def test_high_score_display(self):
        data = {**SAMPLE_DATA, "health_score": 9.5}
        output = _capture_display_output("show_analysis", data)
        assert "9.5" in output

    def test_low_score_display(self):
        data = {**SAMPLE_DATA, "health_score": 2.1}
        output = _capture_display_output("show_analysis", data)
        assert "2.1" in output

    def test_zero_score_display(self):
        data = {**SAMPLE_DATA, "health_score": 0.0}
        output = _capture_display_output("show_analysis", data)
        assert "0.0" in output

    def test_health_bar_present(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "█" in output

    def test_health_label(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "health" in output


class TestDisplayQualitySignals:
    """Tests for quality signals display."""

    def test_all_positive_signals(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "yes" in output

    def test_negative_signals(self):
        data = {
            **SAMPLE_DATA,
            "quality_signals": {
                "has_ci_cd": False,
                "has_tests": False,
                "has_readme": False,
                "license": "None",
                "days_since_last_commit": 500,
            },
        }
        output = _capture_display_output("show_analysis", data)
        assert "no" in output

    def test_last_commit_today(self):
        data = {
            **SAMPLE_DATA,
            "quality_signals": {
                **SAMPLE_DATA["quality_signals"],
                "days_since_last_commit": 0,
            },
        }
        output = _capture_display_output("show_analysis", data)
        assert "today" in output

    def test_last_commit_yesterday(self):
        data = {
            **SAMPLE_DATA,
            "quality_signals": {
                **SAMPLE_DATA["quality_signals"],
                "days_since_last_commit": 1,
            },
        }
        output = _capture_display_output("show_analysis", data)
        assert "yesterday" in output

    def test_last_commit_days_ago(self):
        data = {
            **SAMPLE_DATA,
            "quality_signals": {
                **SAMPLE_DATA["quality_signals"],
                "days_since_last_commit": 5,
            },
        }
        output = _capture_display_output("show_analysis", data)
        assert "5d ago" in output

    def test_quality_section_header(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "quality" in output

    def test_quality_contains_extended_signals(self):
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "contributing" in output
        assert "security" in output
        assert "codeowners" in output


class TestDisplayComparison:
    """Tests for comparison display."""

    def test_comparison_runs_without_error(self):
        data1 = {**SAMPLE_DATA, "full_name": "facebook/react"}
        data2 = {
            **SAMPLE_DATA,
            "full_name": "vuejs/vue",
            "stars": 205000,
            "health_score": 8.8,
        }
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True, width=120)
        display = Display(console=console)
        display.show_comparison(data1, data2)
        output = string_io.getvalue()
        assert "facebook/react" in output
        assert "vuejs/vue" in output

    def test_comparison_contains_metrics(self):
        data1 = {**SAMPLE_DATA, "full_name": "repo1/test"}
        data2 = {**SAMPLE_DATA, "full_name": "repo2/test", "stars": 100}
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True, width=120)
        display = Display(console=console)
        display.show_comparison(data1, data2)
        output = _strip_ansi(string_io.getvalue())
        assert "stars" in output
        assert "forks" in output

    def test_comparison_contains_license(self):
        data1 = {**SAMPLE_DATA, "full_name": "repo1/test", "license": "MIT"}
        data2 = {**SAMPLE_DATA, "full_name": "repo2/test", "license": "Apache-2.0"}
        string_io = StringIO()
        console = Console(file=string_io, force_terminal=True, width=120)
        display = Display(console=console)
        display.show_comparison(data1, data2)
        output = _strip_ansi(string_io.getvalue())
        assert "license" in output


class TestFormatNumber:
    """Tests for number formatting utility."""

    def setup_method(self):
        self.display = Display()

    def test_format_millions(self):
        assert self.display._format_number(1500000) == "1.5M"

    def test_format_thousands(self):
        assert self.display._format_number(210000) == "210.0K"

    def test_format_small_number(self):
        assert self.display._format_number(500) == "500"

    def test_format_exact_thousand(self):
        assert self.display._format_number(1000) == "1.0K"

    def test_format_exact_million(self):
        assert self.display._format_number(1000000) == "1.0M"

    def test_format_zero(self):
        assert self.display._format_number(0) == "0"


class TestDisplaySeparators:
    """Tests for visual structure."""

    def test_separators_present(self):
        """Output should contain separator lines."""
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "─" in output

    def test_section_headers_present(self):
        """Output should contain section headers."""
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "summary" in output
        assert "langs" in output
        assert "contributors" in output
        assert "quality" in output
        assert "signals" in output
        assert "health" in output

    def test_stats_line_present(self):
        """Output should contain the compact stats line."""
        output = _capture_display_output("show_analysis", SAMPLE_DATA)
        assert "stars" in output
        assert "forks" in output
        assert "issues" in output
        assert "prs" in output
        assert "commits/mo" in output
