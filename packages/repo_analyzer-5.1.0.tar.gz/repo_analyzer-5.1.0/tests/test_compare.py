"""
Tests for the comparison module.
"""

import pytest
from unittest.mock import MagicMock, patch

from repo_analyzer.compare import Comparator
from repo_analyzer.analyzer import RepoAnalyzer
from repo_analyzer.display import Display


SAMPLE_DATA_1 = {
    "owner": "facebook",
    "repo": "react",
    "full_name": "facebook/react",
    "description": "React library",
    "stars": 210000,
    "forks": 44000,
    "watchers": 6500,
    "open_issues": 892,
    "open_prs": 234,
    "commits_this_month": 47,
    "language_breakdown": [
        {"language": "JavaScript", "percentage": 78.5, "bytes": 5000000},
    ],
    "top_contributors": [
        {"login": "dan-abramov", "contributions": 1245},
    ],
    "quality_signals": {
        "has_ci_cd": True,
        "has_tests": True,
        "has_readme": True,
        "license": "MIT",
        "days_since_last_commit": 2,
    },
    "health_score": 9.2,
    "license": "MIT",
    "repository_scores": {"maintainability": 8.9, "collaboration": 7.5},
    "narrative_insights": {"strengths": ["Engineering hygiene is backed by CI and tests."]},
}

SAMPLE_DATA_2 = {
    "owner": "vuejs",
    "repo": "vue",
    "full_name": "vuejs/vue",
    "description": "Vue.js framework",
    "stars": 205000,
    "forks": 33000,
    "watchers": 6200,
    "open_issues": 600,
    "open_prs": 150,
    "commits_this_month": 30,
    "language_breakdown": [
        {"language": "TypeScript", "percentage": 85.0, "bytes": 4000000},
    ],
    "top_contributors": [
        {"login": "yyx990803", "contributions": 3500},
    ],
    "quality_signals": {
        "has_ci_cd": True,
        "has_tests": True,
        "has_readme": True,
        "license": "MIT",
        "days_since_last_commit": 5,
    },
    "health_score": 8.8,
    "license": "MIT",
    "repository_scores": {"maintainability": 7.1, "collaboration": 6.8},
    "narrative_insights": {"strengths": ["Repository is active."]},
}


class TestComparator:
    """Tests for the Comparator class."""

    def setup_method(self):
        self.mock_analyzer = MagicMock(spec=RepoAnalyzer)
        self.mock_display = MagicMock(spec=Display)
        self.comparator = Comparator(
            analyzer=self.mock_analyzer,
            display=self.mock_display,
        )

    def test_compare_calls_analyze_twice(self):
        """Compare should analyze both repositories."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        self.comparator.compare("facebook", "react", "vuejs", "vue")

        assert self.mock_analyzer.analyze.call_count == 2
        self.mock_analyzer.analyze.assert_any_call("facebook", "react")
        self.mock_analyzer.analyze.assert_any_call("vuejs", "vue")

    def test_compare_calls_display(self):
        """Compare should call display.show_comparison."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        self.comparator.compare("facebook", "react", "vuejs", "vue")

        self.mock_display.show_comparison.assert_called_once_with(
            SAMPLE_DATA_1, SAMPLE_DATA_2
        )

    def test_compare_returns_result_dict(self):
        """Compare should return a dictionary with both analyses and summary."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        result = self.comparator.compare("facebook", "react", "vuejs", "vue")

        assert "repo1" in result
        assert "repo2" in result
        assert "summary" in result
        assert result["repo1"]["full_name"] == "facebook/react"
        assert result["repo2"]["full_name"] == "vuejs/vue"

    def test_summary_has_metric_winners(self):
        """Summary should contain metric winners."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        result = self.comparator.compare("facebook", "react", "vuejs", "vue")
        summary = result["summary"]

        assert "metric_winners" in summary
        assert "overall_winner" in summary
        assert "repo1_wins" in summary
        assert "repo2_wins" in summary
        assert "comparison_summary" in summary

    def test_summary_correct_winner_stars(self):
        """Repo with more stars should win the Stars metric."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        result = self.comparator.compare("facebook", "react", "vuejs", "vue")
        summary = result["summary"]

        assert summary["metric_winners"]["Stars"] == "facebook/react"

    def test_summary_correct_winner_health(self):
        """Repo with higher health score should win the Health Score metric."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        result = self.comparator.compare("facebook", "react", "vuejs", "vue")
        summary = result["summary"]

        assert summary["metric_winners"]["Health Score"] == "facebook/react"

    def test_summary_overall_winner(self):
        """Overall winner should be the repo that wins more metrics."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_2]

        result = self.comparator.compare("facebook", "react", "vuejs", "vue")
        summary = result["summary"]

        # facebook/react has more stars, forks, issues, PRs, commits, health score
        assert summary["overall_winner"] == "facebook/react"
        assert summary["repo1_wins"] > summary["repo2_wins"]

    def test_summary_tie(self):
        """Identical repos should result in a tie."""
        self.mock_analyzer.analyze.side_effect = [SAMPLE_DATA_1, SAMPLE_DATA_1.copy()]

        result = self.comparator.compare("facebook", "react", "facebook", "react")
        summary = result["summary"]

        assert summary["overall_winner"] == "Tie"

    def test_compare_with_different_strengths(self):
        """Each repo winning different metrics should be handled correctly."""
        data1 = {
            **SAMPLE_DATA_1,
            "stars": 100,
            "forks": 50000,
            "health_score": 5.0,
            "repository_scores": {"maintainability": 4.0, "collaboration": 8.0},
        }
        data2 = {
            **SAMPLE_DATA_2,
            "stars": 200000,
            "forks": 100,
            "health_score": 9.0,
            "repository_scores": {"maintainability": 9.0, "collaboration": 5.0},
        }

        self.mock_analyzer.analyze.side_effect = [data1, data2]

        result = self.comparator.compare("owner1", "repo1", "owner2", "repo2")
        summary = result["summary"]

        assert summary["metric_winners"]["Stars"] == "vuejs/vue"
        assert summary["metric_winners"]["Forks"] == "facebook/react"
        assert "Maintainability" in summary["metric_winners"]
