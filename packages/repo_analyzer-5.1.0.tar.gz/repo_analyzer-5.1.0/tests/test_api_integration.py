"""
Integration tests for the GitHub API client using mocked HTTP responses.
"""

import pytest
import responses
from responses import matchers

from repo_analyzer.api import GitHubAPI


GITHUB_API = "https://api.github.com"

# Sample API response data
SAMPLE_REPO_INFO = {
    "id": 10270250,
    "name": "react",
    "full_name": "facebook/react",
    "description": "A declarative, efficient, and flexible JavaScript library.",
    "stargazers_count": 210000,
    "forks_count": 44000,
    "subscribers_count": 6500,
    "open_issues_count": 892,
    "language": "JavaScript",
    "default_branch": "main",
    "created_at": "2013-05-24T16:15:54Z",
    "updated_at": "2024-01-15T12:00:00Z",
    "pushed_at": "2024-01-15T10:00:00Z",
    "license": {"key": "mit", "name": "MIT License", "spdx_id": "MIT"},
    "topics": ["react", "javascript", "frontend"],
}

SAMPLE_LANGUAGES = {
    "JavaScript": 5000000,
    "TypeScript": 900000,
    "HTML": 260000,
    "CSS": 200000,
}

SAMPLE_CONTRIBUTORS = [
    {"login": "dan-abramov", "contributions": 1245, "avatar_url": "https://avatar1.com", "html_url": "https://github.com/dan-abramov"},
    {"login": "acdlite", "contributions": 987, "avatar_url": "https://avatar2.com", "html_url": "https://github.com/acdlite"},
    {"login": "bvaughn", "contributions": 654, "avatar_url": "https://avatar3.com", "html_url": "https://github.com/bvaughn"},
]

SAMPLE_COMMITS = [
    {"sha": "abc123", "commit": {"message": "Fix bug", "author": {"date": "2024-01-15T10:00:00Z"}}},
    {"sha": "def456", "commit": {"message": "Add feature", "author": {"date": "2024-01-14T09:00:00Z"}}},
]

SAMPLE_PULLS = [
    {"number": 1, "title": "Fix typo", "state": "open"},
    {"number": 2, "title": "Add docs", "state": "open"},
]

SAMPLE_WORKFLOWS = {
    "total_count": 2,
    "workflows": [
        {"id": 1, "name": "CI", "state": "active"},
        {"id": 2, "name": "Deploy", "state": "active"},
    ],
}

SAMPLE_RATE_LIMIT = {
    "resources": {
        "core": {"limit": 60, "remaining": 55, "reset": 1700000000},
    },
    "rate": {"limit": 60, "remaining": 55, "reset": 1700000000},
}


class TestGitHubAPIGetRepoInfo:
    """Tests for fetching repository info."""

    @responses.activate
    def test_get_repo_info(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react",
            json=SAMPLE_REPO_INFO,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_repo_info("facebook", "react")

        assert result["full_name"] == "facebook/react"
        assert result["stargazers_count"] == 210000
        assert result["license"]["spdx_id"] == "MIT"

    @responses.activate
    def test_get_repo_info_not_found(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/nonexistent/repo",
            json={"message": "Not Found"},
            status=404,
        )

        api = GitHubAPI()
        with pytest.raises(Exception):
            api.get_repo_info("nonexistent", "repo")


class TestGitHubAPIGetLanguages:
    """Tests for fetching language breakdown."""

    @responses.activate
    def test_get_languages(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/languages",
            json=SAMPLE_LANGUAGES,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_languages("facebook", "react")

        assert result["JavaScript"] == 5000000
        assert result["TypeScript"] == 900000
        assert len(result) == 4

    @responses.activate
    def test_get_languages_empty(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/test/empty/languages",
            json={},
            status=200,
        )

        api = GitHubAPI()
        result = api.get_languages("test", "empty")
        assert result == {}


class TestGitHubAPIGetContributors:
    """Tests for fetching contributors."""

    @responses.activate
    def test_get_contributors(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/contributors",
            json=SAMPLE_CONTRIBUTORS,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_contributors("facebook", "react", per_page=10)

        assert len(result) == 3
        assert result[0]["login"] == "dan-abramov"
        assert result[0]["contributions"] == 1245

    @responses.activate
    def test_get_contributors_empty(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/test/empty/contributors",
            json=[],
            status=200,
        )

        api = GitHubAPI()
        result = api.get_contributors("test", "empty")
        assert result == []


class TestGitHubAPIGetCommits:
    """Tests for fetching commits."""

    @responses.activate
    def test_get_commits(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/commits",
            json=SAMPLE_COMMITS,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_commits("facebook", "react")

        assert len(result) == 2
        assert result[0]["sha"] == "abc123"

    @responses.activate
    def test_get_commits_with_since(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/commits",
            json=SAMPLE_COMMITS,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_commits("facebook", "react", since="2024-01-01T00:00:00Z")
        assert len(result) == 2

    @responses.activate
    def test_get_commits_this_month(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/commits",
            json=SAMPLE_COMMITS,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_commits_this_month("facebook", "react")
        assert isinstance(result, list)


class TestGitHubAPIGetPulls:
    """Tests for fetching pull requests."""

    @responses.activate
    def test_get_open_pulls(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/pulls",
            json=SAMPLE_PULLS,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_open_pulls("facebook", "react")

        assert len(result) == 2
        assert result[0]["title"] == "Fix typo"

    @responses.activate
    def test_get_open_pulls_empty(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/test/empty/pulls",
            json=[],
            status=200,
        )

        api = GitHubAPI()
        result = api.get_open_pulls("test", "empty")
        assert result == []


class TestGitHubAPIGetWorkflows:
    """Tests for fetching CI/CD workflows."""

    @responses.activate
    def test_get_workflows(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/actions/workflows",
            json=SAMPLE_WORKFLOWS,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_workflows("facebook", "react")

        assert result["total_count"] == 2
        assert len(result["workflows"]) == 2

    @responses.activate
    def test_get_workflows_not_found(self):
        """Repos without workflows should return empty result."""
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/test/noci/actions/workflows",
            json={"message": "Not Found"},
            status=404,
        )

        api = GitHubAPI()
        result = api.get_workflows("test", "noci")
        assert result["total_count"] == 0


class TestGitHubAPIGetContents:
    """Tests for fetching repository contents."""

    @responses.activate
    def test_get_contents(self):
        contents = [
            {"name": "README.md", "type": "file"},
            {"name": "src", "type": "dir"},
        ]
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/contents/",
            json=contents,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_contents("facebook", "react")
        assert len(result) == 2

    @responses.activate
    def test_get_contents_specific_path(self):
        contents = [
            {"name": "index.js", "type": "file"},
        ]
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react/contents/src",
            json=contents,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_contents("facebook", "react", path="src")
        assert len(result) == 1


class TestGitHubAPIGetRateLimit:
    """Tests for rate limit checking."""

    @responses.activate
    def test_get_rate_limit(self):
        responses.add(
            responses.GET,
            f"{GITHUB_API}/rate_limit",
            json=SAMPLE_RATE_LIMIT,
            status=200,
        )

        api = GitHubAPI()
        result = api.get_rate_limit()
        assert result["rate"]["remaining"] == 55


class TestGitHubAPIAuthentication:
    """Tests for API authentication."""

    def test_token_from_constructor(self):
        api = GitHubAPI(token="test-token-123")
        assert api.token == "test-token-123"
        assert "Authorization" in api.session.headers

    def test_no_token(self):
        api = GitHubAPI(token=None)
        # Should still work without token (unauthenticated)
        assert api.session.headers.get("Accept") == "application/vnd.github.v3+json"


class TestGitHubAPICaching:
    """Tests for API response caching."""

    @responses.activate
    def test_cached_response_avoids_second_request(self):
        """Second call should use cache, not make another HTTP request."""
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react",
            json=SAMPLE_REPO_INFO,
            status=200,
        )

        from repo_analyzer.cache import CacheManager
        cache = CacheManager(enabled=True, ttl=300)
        api = GitHubAPI(cache_manager=cache)

        # First call - hits the API
        result1 = api.get_repo_info("facebook", "react")
        # Second call - should use cache
        result2 = api.get_repo_info("facebook", "react")

        assert result1["full_name"] == result2["full_name"]
        # Only one HTTP request should have been made
        assert len(responses.calls) == 1

        # Clean up cache
        cache.clear()

    @responses.activate
    def test_no_cache_makes_multiple_requests(self):
        """With cache disabled, each call should make an HTTP request."""
        responses.add(
            responses.GET,
            f"{GITHUB_API}/repos/facebook/react",
            json=SAMPLE_REPO_INFO,
            status=200,
        )

        from repo_analyzer.cache import CacheManager
        cache = CacheManager(enabled=False)
        api = GitHubAPI(cache_manager=cache)

        api.get_repo_info("facebook", "react")
        api.get_repo_info("facebook", "react")

        assert len(responses.calls) == 2
