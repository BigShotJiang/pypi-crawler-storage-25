"""
Tests for the health score algorithm.
"""

import pytest
from repo_analyzer.health import HealthScorer


class TestHealthScorer:
    """Tests for health score calculation."""

    def setup_method(self):
        self.scorer = HealthScorer()

    def test_perfect_score(self):
        """A highly active, well-maintained repo should score high."""
        score = self.scorer.calculate(
            repo_info={
                "stargazers_count": 50000,
                "forks_count": 5000,
                "open_issues_count": 100,
                "description": "A great project with lots of features",
                "topics": ["python", "cli", "tool", "github"],
            },
            language_breakdown=[{"language": "Python", "percentage": 100, "bytes": 50000}],
            contributors=[{"login": f"user{i}"} for i in range(25)],
            commits_this_month=60,
            open_pulls_count=10,
            quality_signals={
                "has_ci_cd": True,
                "has_tests": True,
                "has_readme": True,
                "license": "MIT",
                "days_since_last_commit": 1,
            },
        )
        assert score >= 8.0

    def test_low_score(self):
        """An inactive, poorly maintained repo should score low."""
        score = self.scorer.calculate(
            repo_info={
                "stargazers_count": 0,
                "forks_count": 0,
                "open_issues_count": 0,
                "description": "",
                "topics": [],
            },
            language_breakdown=[],
            contributors=[],
            commits_this_month=0,
            open_pulls_count=0,
            quality_signals={
                "has_ci_cd": False,
                "has_tests": False,
                "has_readme": False,
                "license": "None",
                "days_since_last_commit": 500,
            },
        )
        assert score <= 3.0

    def test_score_range(self):
        """Score should always be between 0 and 10."""
        score = self.scorer.calculate(
            repo_info={
                "stargazers_count": 100,
                "forks_count": 20,
                "open_issues_count": 15,
                "description": "A test project",
                "topics": ["test"],
            },
            language_breakdown=[{"language": "Python", "percentage": 100, "bytes": 1000}],
            contributors=[{"login": "user1"}, {"login": "user2"}],
            commits_this_month=5,
            open_pulls_count=2,
            quality_signals={
                "has_ci_cd": True,
                "has_tests": False,
                "has_readme": True,
                "license": "MIT",
                "days_since_last_commit": 15,
            },
        )
        assert 0.0 <= score <= 10.0

    def test_score_is_float(self):
        """Score should be a float."""
        score = self.scorer.calculate(
            repo_info={"stargazers_count": 0, "forks_count": 0, "open_issues_count": 0},
            language_breakdown=[],
            contributors=[],
            commits_this_month=0,
            open_pulls_count=0,
            quality_signals={
                "has_ci_cd": False,
                "has_tests": False,
                "has_readme": False,
                "license": "None",
                "days_since_last_commit": None,
            },
        )
        assert isinstance(score, float)
