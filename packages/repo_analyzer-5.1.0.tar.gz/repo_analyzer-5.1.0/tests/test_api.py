"""
Tests for the GitHub API client.
"""

import pytest
from repo_analyzer.api import GitHubAPI


class TestParseRepoUrl:
    """Tests for URL parsing."""

    def test_parse_full_url(self):
        api = GitHubAPI()
        owner, repo = api.parse_repo_url("https://github.com/facebook/react")
        assert owner == "facebook"
        assert repo == "react"

    def test_parse_url_with_git_extension(self):
        api = GitHubAPI()
        owner, repo = api.parse_repo_url("https://github.com/facebook/react.git")
        assert owner == "facebook"
        assert repo == "react"

    def test_parse_url_with_trailing_slash(self):
        api = GitHubAPI()
        owner, repo = api.parse_repo_url("https://github.com/facebook/react/")
        assert owner == "facebook"
        assert repo == "react"

    def test_parse_short_format(self):
        api = GitHubAPI()
        owner, repo = api.parse_repo_url("facebook/react")
        assert owner == "facebook"
        assert repo == "react"

    def test_parse_invalid_url_raises(self):
        api = GitHubAPI()
        with pytest.raises(ValueError):
            api.parse_repo_url("not-a-valid-url")

    def test_parse_empty_string_raises(self):
        api = GitHubAPI()
        with pytest.raises(ValueError):
            api.parse_repo_url("")
