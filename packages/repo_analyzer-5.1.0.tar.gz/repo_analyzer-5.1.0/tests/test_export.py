"""
Tests for the export module (JSON and PDF).
"""

import os
import json
import tempfile
import shutil

import pytest
from repo_analyzer.export import Exporter


# Sample analysis data for testing
SAMPLE_DATA = {
    "owner": "facebook",
    "repo": "react",
    "full_name": "facebook/react",
    "description": "A declarative, efficient, and flexible JavaScript library for building user interfaces.",
    "stars": 210000,
    "forks": 44000,
    "watchers": 6500,
    "open_issues": 892,
    "open_prs": 234,
    "commits_this_month": 47,
    "language_breakdown": [
        {"language": "JavaScript", "percentage": 78.5, "bytes": 5000000},
        {"language": "TypeScript", "percentage": 14.2, "bytes": 900000},
        {"language": "HTML", "percentage": 4.1, "bytes": 260000},
        {"language": "CSS", "percentage": 3.2, "bytes": 200000},
    ],
    "top_contributors": [
        {"login": "dan-abramov", "contributions": 1245, "avatar_url": "", "profile_url": ""},
        {"login": "acdlite", "contributions": 987, "avatar_url": "", "profile_url": ""},
        {"login": "bvaughn", "contributions": 654, "avatar_url": "", "profile_url": ""},
    ],
    "quality_signals": {
        "has_ci_cd": True,
        "has_tests": True,
        "has_readme": True,
        "license": "MIT",
        "days_since_last_commit": 2,
    },
    "health_score": 9.2,
    "created_at": "2013-05-24T16:15:54Z",
    "updated_at": "2024-01-15T12:00:00Z",
    "pushed_at": "2024-01-15T10:00:00Z",
    "default_branch": "main",
    "license": "MIT",
    "topics": ["react", "javascript", "frontend", "ui"],
}


class TestExporterJSON:
    """Tests for JSON export functionality."""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.exporter = Exporter()

    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_export_json_creates_file(self):
        """JSON export should create a file."""
        output_path = os.path.join(self.temp_dir, "test_output.json")
        self.exporter.export(SAMPLE_DATA, format="json", output_path=output_path)
        assert os.path.exists(output_path)

    def test_export_json_valid_json(self):
        """Exported JSON file should contain valid JSON."""
        output_path = os.path.join(self.temp_dir, "test_output.json")
        self.exporter.export(SAMPLE_DATA, format="json", output_path=output_path)

        with open(output_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        assert "exported_at" in data
        assert "analysis" in data

    def test_export_json_contains_analysis_data(self):
        """Exported JSON should contain all analysis fields."""
        output_path = os.path.join(self.temp_dir, "test_output.json")
        self.exporter.export(SAMPLE_DATA, format="json", output_path=output_path)

        with open(output_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        analysis = data["analysis"]
        assert analysis["full_name"] == "facebook/react"
        assert analysis["stars"] == 210000
        assert analysis["health_score"] == 9.2
        assert len(analysis["language_breakdown"]) == 4
        assert len(analysis["top_contributors"]) == 3

    def test_export_json_preserves_nested_data(self):
        """Nested data structures should be preserved in JSON export."""
        output_path = os.path.join(self.temp_dir, "test_output.json")
        self.exporter.export(SAMPLE_DATA, format="json", output_path=output_path)

        with open(output_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        analysis = data["analysis"]
        assert analysis["quality_signals"]["has_ci_cd"] is True
        assert analysis["quality_signals"]["license"] == "MIT"
        assert analysis["language_breakdown"][0]["language"] == "JavaScript"

    def test_export_json_empty_data(self):
        """Export should handle empty/minimal data."""
        output_path = os.path.join(self.temp_dir, "test_empty.json")
        minimal_data = {"owner": "test", "repo": "test", "full_name": "test/test"}
        self.exporter.export(minimal_data, format="json", output_path=output_path)

        with open(output_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        assert data["analysis"]["full_name"] == "test/test"

    def test_export_json_has_timestamp(self):
        """Exported JSON should include an export timestamp."""
        output_path = os.path.join(self.temp_dir, "test_output.json")
        self.exporter.export(SAMPLE_DATA, format="json", output_path=output_path)

        with open(output_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        assert "exported_at" in data
        assert len(data["exported_at"]) > 0


class TestExporterPDF:
    """Tests for PDF export functionality."""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.exporter = Exporter()

    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_export_pdf_creates_file(self):
        """PDF export should create a file."""
        output_path = os.path.join(self.temp_dir, "test_output.pdf")
        self.exporter.export(SAMPLE_DATA, format="pdf", output_path=output_path)
        assert os.path.exists(output_path)

    def test_export_pdf_file_not_empty(self):
        """Exported PDF file should not be empty."""
        output_path = os.path.join(self.temp_dir, "test_output.pdf")
        self.exporter.export(SAMPLE_DATA, format="pdf", output_path=output_path)
        file_size = os.path.getsize(output_path)
        assert file_size > 0

    def test_export_pdf_is_valid_pdf(self):
        """Exported file should start with PDF magic bytes."""
        output_path = os.path.join(self.temp_dir, "test_output.pdf")
        self.exporter.export(SAMPLE_DATA, format="pdf", output_path=output_path)

        with open(output_path, "rb") as f:
            header = f.read(5)

        assert header == b"%PDF-"

    def test_export_pdf_minimal_data(self):
        """PDF export should handle minimal data without errors."""
        output_path = os.path.join(self.temp_dir, "test_minimal.pdf")
        minimal_data = {
            "owner": "test",
            "repo": "test",
            "full_name": "test/test",
            "description": "",
            "stars": 0,
            "forks": 0,
            "open_issues": 0,
            "open_prs": 0,
            "commits_this_month": 0,
            "language_breakdown": [],
            "top_contributors": [],
            "quality_signals": {},
            "health_score": 0.0,
            "default_branch": "main",
            "license": "None",
        }
        self.exporter.export(minimal_data, format="pdf", output_path=output_path)
        assert os.path.exists(output_path)

    def test_export_pdf_with_all_sections(self):
        """PDF export with full data should produce a larger file."""
        output_path = os.path.join(self.temp_dir, "test_full.pdf")
        self.exporter.export(SAMPLE_DATA, format="pdf", output_path=output_path)
        file_size = os.path.getsize(output_path)
        # Full report should be at least 1KB
        assert file_size > 1000


class TestExporterGeneral:
    """General exporter tests."""

    def setup_method(self):
        self.temp_dir = tempfile.mkdtemp()
        self.exporter = Exporter()

    def teardown_method(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)

    def test_unsupported_format_raises(self):
        """Unsupported export format should raise ValueError."""
        output_path = os.path.join(self.temp_dir, "test.xml")
        with pytest.raises(ValueError, match="Unsupported export format"):
            self.exporter.export(SAMPLE_DATA, format="xml", output_path=output_path)

    def test_export_creates_output_directory(self):
        """Export should work even if the output directory doesn't exist yet."""
        output_path = os.path.join(self.temp_dir, "subdir", "test_output.json")
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        self.exporter.export(SAMPLE_DATA, format="json", output_path=output_path)
        assert os.path.exists(output_path)
