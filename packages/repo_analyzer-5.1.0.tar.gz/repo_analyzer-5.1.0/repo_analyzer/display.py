from typing import Dict, Any, List

from rich.console import Console
from rich.table import Table
from rich import box

LANG_COLORS = {
    "JavaScript": "yellow",
    "TypeScript": "blue",
    "Python": "green",
    "Java": "red",
    "C++": "magenta",
    "C": "bright_blue",
    "C#": "green",
    "Go": "cyan",
    "Rust": "#dea584",
    "Ruby": "red",
    "PHP": "#8892be",
    "Swift": "bright_red",
    "Kotlin": "bright_magenta",
    "HTML": "#e34c26",
    "CSS": "#563d7c",
    "Shell": "green",
    "Dart": "cyan",
    "Scala": "red",
    "Lua": "blue",
    "R": "bright_blue",
    "Assembly": "#6E4C13",
    "Makefile": "green",
    "Perl": "#0298c3",
}

SEPARATOR = "\u2500" * 45
BAR_FILLED = "\u2588"
BAR_EMPTY = "\u2591"
DOT = "\u25cf"
EM_DASH = "\u2014"


class Display:
    def __init__(self, console: Console = None):
        self.console = console or Console()

    def show_analysis(self, data: Dict[str, Any], recruiter_mode: bool = False) -> None:
        self.console.print()
        self._show_header(data)
        self._show_separator()
        self._show_summary(data.get("narrative_insights", {}))
        self._show_separator()
        self._show_stats(data)
        self._show_separator()
        self._show_languages(data.get("language_breakdown", []))
        self._show_separator()
        self._show_contributors(data.get("top_contributors", []), data.get("contributor_insights", {}))
        self._show_separator()
        self._show_quality(data.get("quality_signals", {}), data.get("license", "None"))
        self._show_separator()
        self._show_scores(data.get("repository_scores", {}), data.get("trend_analysis", {}))
        if recruiter_mode:
            self._show_separator()
            self._show_recruiter(data.get("repository_scores", {}), data.get("narrative_insights", {}))
        self._show_separator()
        self._show_health(data.get("health_score", 0))
        self.console.print()

    def _show_separator(self) -> None:
        self.console.print(f"[dim]{SEPARATOR}[/dim]")

    def _show_header(self, data: Dict[str, Any]) -> None:
        name = data.get("full_name", "unknown/unknown")
        desc = data.get("description", "")
        branch = data.get("default_branch", "main")

        self.console.print(f"[bold white]{name}[/bold white] [dim]({branch})[/dim]")
        if desc:
            if len(desc) > 80:
                desc = desc[:77] + "..."
            self.console.print(f"[dim italic]{desc}[/dim italic]")

    def _show_summary(self, insights: Dict[str, Any]) -> None:
        verdict = insights.get("verdict")
        strengths = insights.get("strengths", [])
        concerns = insights.get("concerns", [])

        self.console.print("[bold]summary[/bold]")
        if verdict:
            self.console.print(f"  [bold]verdict:[/bold] {verdict}")
        if strengths:
            self.console.print(f"  [green]strengths[/green] {strengths[0]}")
        if concerns:
            self.console.print(f"  [red]concerns[/red] {concerns[0]}")

    def _show_stats(self, data: Dict[str, Any]) -> None:
        stars = data.get("stars", 0)
        forks = data.get("forks", 0)
        issues = data.get("open_issues", 0)
        prs = data.get("open_prs", 0)
        commits = data.get("commits_this_month", 0)

        stars_s = self._format_number(stars)
        forks_s = self._format_number(forks)

        self.console.print(
            f"[dim]stars[/dim] [bold yellow]{stars_s}[/bold yellow]  "
            f"[dim]forks[/dim] [bold]{forks_s}[/bold]  "
            f"[dim]issues[/dim] [bold]{issues:,}[/bold]  "
            f"[dim]prs[/dim] [bold]{prs:,}[/bold]  "
            f"[dim]commits/mo[/dim] [bold cyan]{commits}[/bold cyan]"
        )

    def _show_languages(self, languages: List[Dict[str, Any]]) -> None:
        if not languages:
            self.console.print("[dim]no language data[/dim]")
            return

        self.console.print("[bold]langs[/bold]")

        for lang_data in languages[:8]:
            lang = lang_data["language"]
            pct = lang_data["percentage"]
            color = LANG_COLORS.get(lang, "white")

            filled = int(pct / 5)
            bar = BAR_FILLED * filled + BAR_EMPTY * (20 - filled)

            self.console.print(
                f"  [{color}]{DOT}[/{color}] {lang:<14} [{color}]{bar}[/{color}] [dim]{pct:>5.1f}%[/dim]"
            )

        if len(languages) > 8:
            remaining = len(languages) - 8
            self.console.print(f"  [dim]  +{remaining} more[/dim]")

    def _show_contributors(self, contributors: List[Dict[str, Any]], insights: Dict[str, Any]) -> None:
        if not contributors:
            self.console.print("[dim]contributor data unavailable[/dim]")
            return

        self.console.print("[bold]contributors[/bold]")

        for i, contrib in enumerate(contributors[:5], 1):
            login = contrib.get("login", "unknown")
            count = contrib.get("contributions", 0)

            if i == 1:
                marker = "[yellow]>[/yellow]"
            elif i <= 3:
                marker = "[dim]>[/dim]"
            else:
                marker = " "

            self.console.print(
                f"  {marker} [bold]{login}[/bold] [dim]{EM_DASH}[/dim] {count:,} commits"
            )

        lead_share = insights.get("lead_contributor_share")
        risk_level = insights.get("risk_level")
        if lead_share is not None and risk_level:
            self.console.print(
                f"  [dim]lead share[/dim] {lead_share:.1f}%  [dim]bus factor[/dim] {insights.get('bus_factor', 0)}  "
                f"[dim]risk[/dim] [bold]{risk_level}[/bold]"
            )

    def _show_quality(self, signals: Dict[str, Any], license_name: str = "None") -> None:
        self.console.print("[bold]quality[/bold]")

        ci = signals.get("has_ci_cd", False)
        tests = signals.get("has_tests", False)
        readme = signals.get("has_readme", False)
        lic = signals.get("license", license_name)
        days = signals.get("days_since_last_commit")

        def _yn(val):
            return "[green]yes[/green]" if val else "[red]no[/red]"

        self.console.print(
            f"  ci/cd {_yn(ci)}  "
            f"tests {_yn(tests)}  "
            f"readme {_yn(readme)}  "
            f"license [bold]{lic}[/bold]"
        )
        self.console.print(
            f"  contributing {_yn(signals.get('has_contributing'))}  "
            f"security {_yn(signals.get('has_security'))}  "
            f"codeowners {_yn(signals.get('has_codeowners'))}  "
            f"releases {_yn(signals.get('has_releases'))}"
        )

        if days is not None and days >= 0:
            if days == 0:
                age = "[green]today[/green]"
            elif days == 1:
                age = "[green]yesterday[/green]"
            elif days <= 7:
                age = f"[green]{days}d ago[/green]"
            elif days <= 30:
                age = f"[yellow]{days}d ago[/yellow]"
            elif days <= 365:
                age = f"[bright_red]{days}d ago[/bright_red]"
            else:
                age = f"[red]{days}d ago[/red]"
            self.console.print(f"  last push {age}")

    def _show_scores(self, scores: Dict[str, float], trend_analysis: Dict[str, Any]) -> None:
        if not scores:
            return

        self.console.print("[bold]signals[/bold]")
        self.console.print(
            f"  maintainability [bold]{scores.get('maintainability', 0):.1f}[/bold]/10  "
            f"collaboration [bold]{scores.get('collaboration', 0):.1f}[/bold]/10"
        )
        self.console.print(
            f"  production [bold]{scores.get('production_readiness', 0):.1f}[/bold]/10  "
            f"onboarding [bold]{scores.get('onboarding', 0):.1f}[/bold]/10"
        )
        if trend_analysis:
            self.console.print(
                f"  trend [bold]{trend_analysis.get('activity_trend', 'unknown')}[/bold]  "
                f"maintenance [bold]{trend_analysis.get('maintenance_status', 'unknown')}[/bold]"
            )

    def _show_recruiter(self, scores: Dict[str, float], insights: Dict[str, Any]) -> None:
        self.console.print("[bold]recruiter[/bold]")
        self.console.print(
            f"  signal [bold cyan]{scores.get('recruiter_signal', 0):.1f}/10[/bold cyan]"
        )
        summary = insights.get("recruiter_summary")
        if summary:
            self.console.print(f"  {summary}")

        recommendations = insights.get("recommendations", [])
        for recommendation in recommendations[:2]:
            self.console.print(f"  [dim]>[/dim] {recommendation}")

    def _show_health(self, score: float) -> None:
        if score >= 8.0:
            color = "green"
        elif score >= 6.0:
            color = "yellow"
        elif score >= 4.0:
            color = "bright_red"
        else:
            color = "red"

        filled = int(score * 2)
        bar = BAR_FILLED * filled + BAR_EMPTY * (20 - filled)

        self.console.print(
            f"[bold]health[/bold] [{color}]{bar}[/{color}] [{color} bold]{score}/10[/{color} bold]"
        )

    def show_comparison(self, data1: Dict[str, Any], data2: Dict[str, Any]) -> None:
        name1 = data1.get("full_name", "repo-1")
        name2 = data2.get("full_name", "repo-2")

        table = Table(
            box=box.SIMPLE_HEAVY,
            show_header=True,
            header_style="bold",
            pad_edge=False,
            padding=(0, 1),
        )

        table.add_column("", style="dim", width=18)
        table.add_column(name1, justify="right", width=20)
        table.add_column(name2, justify="right", width=20)

        metrics = [
            ("stars", "stars"),
            ("forks", "forks"),
            ("open issues", "open_issues"),
            ("open prs", "open_prs"),
            ("commits/mo", "commits_this_month"),
            ("health", "health_score"),
            ("maintainability", "repository_scores.maintainability"),
            ("collaboration", "repository_scores.collaboration"),
        ]

        for label, key in metrics:
            v1 = self._get_nested_value(data1, key)
            v2 = self._get_nested_value(data2, key)

            s1 = self._fmt_val(v1)
            s2 = self._fmt_val(v2)

            if isinstance(v1, (int, float)) and isinstance(v2, (int, float)):
                if v1 > v2:
                    s1 = f"[bold green]{s1}[/bold green]"
                    s2 = f"[dim]{s2}[/dim]"
                elif v2 > v1:
                    s2 = f"[bold green]{s2}[/bold green]"
                    s1 = f"[dim]{s1}[/dim]"

            table.add_row(label, s1, s2)

        l1 = data1.get("license", "None")
        l2 = data2.get("license", "None")
        table.add_row("license", l1, l2)

        self.console.print()
        self.console.print(table)

        winner = self._comparison_winner(data1, data2)
        if winner == "Tie":
            self.console.print("[bold]comparison[/bold] Tie on the core decision signals.")
        else:
            self.console.print(f"[bold]comparison[/bold] {winner} looks stronger on the current signal mix.")
        self.console.print()

    def _comparison_winner(self, data1: Dict[str, Any], data2: Dict[str, Any]) -> str:
        score1 = (
            float(data1.get("health_score", 0))
            + float(self._get_nested_value(data1, "repository_scores.maintainability") or 0)
            + float(self._get_nested_value(data1, "repository_scores.collaboration") or 0)
        )
        score2 = (
            float(data2.get("health_score", 0))
            + float(self._get_nested_value(data2, "repository_scores.maintainability") or 0)
            + float(self._get_nested_value(data2, "repository_scores.collaboration") or 0)
        )
        if score1 > score2:
            return data1.get("full_name", "Repo 1")
        if score2 > score1:
            return data2.get("full_name", "Repo 2")
        return "Tie"

    def _get_nested_value(self, data: Dict[str, Any], key: str):
        value = data
        for part in key.split("."):
            if not isinstance(value, dict):
                return None
            value = value.get(part)
        return value

    def _fmt_val(self, val) -> str:
        if isinstance(val, float):
            return str(val)
        if isinstance(val, int):
            return self._format_number(val) if val >= 1000 else f"{val:,}"
        if val is None:
            return "-"
        return str(val)

    def _format_number(self, num: int) -> str:
        if num >= 1_000_000:
            return f"{num / 1_000_000:.1f}M"
        elif num >= 1_000:
            return f"{num / 1_000:.1f}K"
        return str(num)
