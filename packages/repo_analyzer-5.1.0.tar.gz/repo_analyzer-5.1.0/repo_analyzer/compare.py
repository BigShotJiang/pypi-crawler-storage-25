from typing import Dict, Any

from repo_analyzer.analyzer import RepoAnalyzer
from repo_analyzer.display import Display


class Comparator:
    def __init__(self, analyzer: RepoAnalyzer, display: Display):
        self.analyzer = analyzer
        self.display = display

    def compare(self, owner1: str, repo1: str, owner2: str, repo2: str) -> Dict[str, Any]:
        data1 = self.analyzer.analyze(owner1, repo1)
        data2 = self.analyzer.analyze(owner2, repo2)

        self.display.show_comparison(data1, data2)

        summary = self._generate_summary(data1, data2)

        return {
            "repo1": data1,
            "repo2": data2,
            "summary": summary,
        }

    def _generate_summary(self, data1: Dict[str, Any], data2: Dict[str, Any]) -> Dict[str, Any]:
        metrics = {
            "stars": "Stars",
            "forks": "Forks",
            "open_issues": "Open Issues",
            "open_prs": "Open PRs",
            "commits_this_month": "Monthly Commits",
            "health_score": "Health Score",
            "repository_scores.maintainability": "Maintainability",
            "repository_scores.collaboration": "Collaboration",
        }

        winners = {}
        for key, label in metrics.items():
            val1 = self._get_nested_value(data1, key, 0)
            val2 = self._get_nested_value(data2, key, 0)

            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                if val1 > val2:
                    winners[label] = data1.get("full_name", "Repo 1")
                elif val2 > val1:
                    winners[label] = data2.get("full_name", "Repo 2")
                else:
                    winners[label] = "Tie"

        repo1_wins = sum(1 for v in winners.values() if v == data1.get("full_name", "Repo 1"))
        repo2_wins = sum(1 for v in winners.values() if v == data2.get("full_name", "Repo 2"))

        if repo1_wins > repo2_wins:
            overall_winner = data1.get("full_name", "Repo 1")
        elif repo2_wins > repo1_wins:
            overall_winner = data2.get("full_name", "Repo 2")
        else:
            overall_winner = "Tie"

        return {
            "metric_winners": winners,
            "overall_winner": overall_winner,
            "repo1_wins": repo1_wins,
            "repo2_wins": repo2_wins,
            "comparison_summary": self._build_comparison_summary(data1, data2, overall_winner),
        }

    def _get_nested_value(self, data: Dict[str, Any], key: str, default: Any = None) -> Any:
        value: Any = data
        for part in key.split("."):
            if not isinstance(value, dict):
                return default
            value = value.get(part, default)
        return value

    def _build_comparison_summary(
        self,
        data1: Dict[str, Any],
        data2: Dict[str, Any],
        overall_winner: str,
    ) -> str:
        if overall_winner == "Tie":
            return "Both repositories look broadly comparable on the current metrics."

        winner = data1 if overall_winner == data1.get("full_name", "Repo 1") else data2
        strengths = winner.get("narrative_insights", {}).get("strengths", [])
        if strengths:
            return f"{overall_winner} stands out because {strengths[0].lower()}"
        return f"{overall_winner} wins more of the decision-oriented metrics."
