import os
import re
from datetime import datetime
from typing import Tuple, Dict, List, Any, Optional

import requests
from dotenv import load_dotenv

load_dotenv()


class GitHubAPI:
    BASE_URL = "https://api.github.com"

    def __init__(self, token: Optional[str] = None, cache_manager=None):
        self.token = token or os.getenv("GITHUB_TOKEN")
        self.cache_manager = cache_manager
        self.session = requests.Session()

        headers = {"Accept": "application/vnd.github.v3+json"}
        if self.token:
            headers["Authorization"] = f"token {self.token}"
        self.session.headers.update(headers)

    def parse_repo_url(self, url: str) -> Tuple[str, str]:
        match = re.match(
            r"(?:https?://)?(?:www\.)?github\.com/([^/]+)/([^/.]+)(?:\.git)?/?",
            url,
        )
        if match:
            return match.group(1), match.group(2)

        match = re.match(r"^([^/]+)/([^/]+)$", url)
        if match:
            return match.group(1), match.group(2)

        raise ValueError(
            f"Invalid GitHub repository URL or format: '{url}'. "
            "Expected format: https://github.com/owner/repo or owner/repo"
        )

    def _get(self, endpoint: str, params: Optional[Dict] = None) -> Any:
        url = f"{self.BASE_URL}{endpoint}"

        if self.cache_manager and self.cache_manager.enabled:
            cached = self.cache_manager.get(url, params)
            if cached is not None:
                return cached

        response = self.session.get(url, params=params)
        response.raise_for_status()
        data = response.json()

        if self.cache_manager and self.cache_manager.enabled:
            self.cache_manager.set(url, params, data)

        return data

    def get_repo_info(self, owner: str, repo: str) -> Dict:
        return self._get(f"/repos/{owner}/{repo}")

    def get_languages(self, owner: str, repo: str) -> Dict[str, int]:
        return self._get(f"/repos/{owner}/{repo}/languages")

    def get_contributors(self, owner: str, repo: str, per_page: int = 10) -> List[Dict]:
        return self._get(
            f"/repos/{owner}/{repo}/contributors",
            params={"per_page": per_page, "anon": "false"},
        )

    def get_commits(self, owner: str, repo: str, since: Optional[str] = None, per_page: int = 100) -> List[Dict]:
        params: Dict[str, Any] = {"per_page": per_page}
        if since:
            params["since"] = since
        return self._get(f"/repos/{owner}/{repo}/commits", params=params)

    def get_commits_this_month(self, owner: str, repo: str) -> List[Dict]:
        first_of_month = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        since = first_of_month.isoformat() + "Z"
        return self.get_commits(owner, repo, since=since)

    def get_open_issues_count(self, owner: str, repo: str) -> int:
        repo_info = self.get_repo_info(owner, repo)
        return repo_info.get("open_issues_count", 0)

    def get_open_pulls(self, owner: str, repo: str) -> List[Dict]:
        return self._get(
            f"/repos/{owner}/{repo}/pulls",
            params={"state": "open", "per_page": 100},
        )

    def get_releases(self, owner: str, repo: str, per_page: int = 10) -> List[Dict]:
        try:
            return self._get(
                f"/repos/{owner}/{repo}/releases",
                params={"per_page": per_page},
            )
        except requests.exceptions.HTTPError:
            return []

    def get_contents(self, owner: str, repo: str, path: str = "") -> List[Dict]:
        return self._get(f"/repos/{owner}/{repo}/contents/{path}")

    def get_community_profile(self, owner: str, repo: str) -> Dict:
        try:
            return self._get(f"/repos/{owner}/{repo}/community/profile")
        except requests.exceptions.HTTPError:
            return {}

    def get_workflows(self, owner: str, repo: str) -> Dict:
        try:
            return self._get(f"/repos/{owner}/{repo}/actions/workflows")
        except requests.exceptions.HTTPError:
            return {"total_count": 0, "workflows": []}

    def get_rate_limit(self) -> Dict:
        return self._get("/rate_limit")
