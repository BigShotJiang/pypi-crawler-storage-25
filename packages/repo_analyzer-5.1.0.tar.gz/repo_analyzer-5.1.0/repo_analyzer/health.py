from typing import Dict, Any, List


class HealthScorer:
    WEIGHTS = {
        "activity": 2.0,
        "community": 2.0,
        "maintenance": 2.0,
        "quality": 2.5,
        "documentation": 1.5,
    }

    def calculate(
        self,
        repo_info: Dict,
        language_breakdown: List[Dict],
        contributors: List[Dict],
        commits_this_month: int,
        open_pulls_count: int,
        quality_signals: Dict[str, Any],
    ) -> float:
        scores = {}

        scores["activity"] = self._score_activity(
            commits_this_month=commits_this_month,
            days_since_last_commit=quality_signals.get("days_since_last_commit"),
        )

        scores["community"] = self._score_community(
            stars=repo_info.get("stargazers_count", 0),
            forks=repo_info.get("forks_count", 0),
            contributors_count=len(contributors),
        )

        scores["maintenance"] = self._score_maintenance(
            open_issues=repo_info.get("open_issues_count", 0),
            open_prs=open_pulls_count,
            days_since_last_commit=quality_signals.get("days_since_last_commit"),
        )

        scores["quality"] = self._score_quality(quality_signals)

        scores["documentation"] = self._score_documentation(
            has_readme=quality_signals.get("has_readme", False),
            description=repo_info.get("description", ""),
            topics=repo_info.get("topics", []),
            license_name=quality_signals.get("license", "None"),
        )

        total_weight = sum(self.WEIGHTS.values())
        weighted_sum = sum(scores[factor] * self.WEIGHTS[factor] for factor in scores)
        health_score = weighted_sum / total_weight

        return round(health_score, 1)

    def _score_activity(self, commits_this_month: int, days_since_last_commit: int = None) -> float:
        score = 0.0

        if commits_this_month >= 50:
            score += 6.0
        elif commits_this_month >= 20:
            score += 5.0
        elif commits_this_month >= 10:
            score += 4.0
        elif commits_this_month >= 5:
            score += 3.0
        elif commits_this_month >= 1:
            score += 2.0

        if days_since_last_commit is not None:
            if days_since_last_commit <= 7:
                score += 4.0
            elif days_since_last_commit <= 30:
                score += 3.0
            elif days_since_last_commit <= 90:
                score += 2.0
            elif days_since_last_commit <= 365:
                score += 1.0

        return min(score, 10.0)

    def _score_community(self, stars: int, forks: int, contributors_count: int) -> float:
        score = 0.0

        if stars >= 10000:
            score += 4.0
        elif stars >= 1000:
            score += 3.0
        elif stars >= 100:
            score += 2.0
        elif stars >= 10:
            score += 1.0

        if forks >= 1000:
            score += 3.0
        elif forks >= 100:
            score += 2.0
        elif forks >= 10:
            score += 1.0

        if contributors_count >= 20:
            score += 3.0
        elif contributors_count >= 10:
            score += 2.5
        elif contributors_count >= 5:
            score += 2.0
        elif contributors_count >= 2:
            score += 1.0

        return min(score, 10.0)

    def _score_maintenance(self, open_issues: int, open_prs: int, days_since_last_commit: int = None) -> float:
        score = 5.0

        if open_issues > 1000:
            score -= 2.0
        elif open_issues > 500:
            score -= 1.0

        if open_prs > 100:
            score -= 2.0
        elif open_prs > 50:
            score -= 1.0

        if days_since_last_commit is not None:
            if days_since_last_commit <= 7:
                score += 3.0
            elif days_since_last_commit <= 30:
                score += 2.0
            elif days_since_last_commit <= 90:
                score += 1.0
            else:
                score -= 1.0

        if 1 <= open_issues <= 50:
            score += 2.0
        elif 51 <= open_issues <= 200:
            score += 1.0

        return max(0.0, min(score, 10.0))

    def _score_quality(self, quality_signals: Dict[str, Any]) -> float:
        score = 0.0

        if quality_signals.get("has_ci_cd"):
            score += 2.5
        if quality_signals.get("has_tests"):
            score += 2.5
        if quality_signals.get("has_readme"):
            score += 1.5

        license_name = quality_signals.get("license", "None")
        if license_name and license_name != "None" and license_name != "NOASSERTION":
            score += 1.0

        if quality_signals.get("has_contributing"):
            score += 1.0
        if quality_signals.get("has_security"):
            score += 1.0
        if quality_signals.get("has_codeowners"):
            score += 0.75
        if quality_signals.get("has_releases"):
            score += 0.5
        if quality_signals.get("has_issue_templates"):
            score += 0.5
        if quality_signals.get("has_pr_template"):
            score += 0.25

        return min(score, 10.0)

    def _score_documentation(self, has_readme: bool, description: str, topics: list, license_name: str) -> float:
        score = 0.0

        if has_readme:
            score += 4.0
        if description and len(description) > 10:
            score += 3.0
        if topics and len(topics) >= 3:
            score += 2.0
        elif topics and len(topics) >= 1:
            score += 1.0
        if license_name and license_name != "None" and license_name != "NOASSERTION":
            score += 1.0

        return min(score, 10.0)
