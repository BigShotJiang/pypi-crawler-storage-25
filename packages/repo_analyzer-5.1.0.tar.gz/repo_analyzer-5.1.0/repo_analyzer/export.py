import json
from typing import Dict, Any
from datetime import datetime


class Exporter:
    def export(self, data: Dict[str, Any], format: str, output_path: str) -> None:
        if format == "json":
            self._export_json(data, output_path)
        elif format == "pdf":
            self._export_pdf(data, output_path)
        else:
            raise ValueError(f"Unsupported export format: {format}")

    def _export_json(self, data: Dict[str, Any], output_path: str) -> None:
        export_data = {
            "exported_at": datetime.now().isoformat(),
            "analysis": data,
        }
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(export_data, f, indent=2, default=str)

    def _export_pdf(self, data: Dict[str, Any], output_path: str) -> None:
        from fpdf import FPDF
        from fpdf.enums import XPos, YPos

        pdf = FPDF()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)

        pdf.set_font("Helvetica", "B", 20)
        pdf.cell(0, 15, "Repository Analysis Report", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
        pdf.ln(5)

        full_name = data.get("full_name", "Unknown")
        pdf.set_font("Helvetica", "B", 16)
        pdf.cell(0, 10, full_name, new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
        pdf.ln(5)

        description = data.get("description", "No description")
        if description:
            pdf.set_font("Helvetica", "", 10)
            pdf.multi_cell(0, 6, description, align="C")
            pdf.ln(5)

        pdf.set_draw_color(100, 100, 100)
        pdf.line(10, pdf.get_y(), 200, pdf.get_y())
        pdf.ln(5)

        self._pdf_section_header(pdf, "Overview")
        overview_items = [
            ("Stars", f"{data.get('stars', 0):,}"),
            ("Forks", f"{data.get('forks', 0):,}"),
            ("Open Issues", f"{data.get('open_issues', 0):,}"),
            ("Open PRs", f"{data.get('open_prs', 0):,}"),
            ("Commits This Month", str(data.get("commits_this_month", 0))),
            ("License", data.get("license", "None")),
            ("Default Branch", data.get("default_branch", "main")),
        ]
        for label, value in overview_items:
            self._pdf_key_value(pdf, label, value)
        pdf.ln(5)

        languages = data.get("language_breakdown", [])
        if languages:
            self._pdf_section_header(pdf, "Language Breakdown")
            for lang_data in languages[:10]:
                lang = lang_data["language"]
                pct = lang_data["percentage"]
                self._pdf_key_value(pdf, lang, f"{pct}%")
            pdf.ln(5)

        contributors = data.get("top_contributors", [])
        if contributors:
            self._pdf_section_header(pdf, "Top Contributors")
            for i, contrib in enumerate(contributors[:5], 1):
                login = contrib.get("login", "Unknown")
                contributions = contrib.get("contributions", 0)
                self._pdf_key_value(pdf, f"{i}. {login}", f"{contributions:,} commits")
            pdf.ln(5)

        quality = data.get("quality_signals", {})
        if quality:
            self._pdf_section_header(pdf, "Code Quality Signals")
            signals = [
                ("Has CI/CD", "Yes" if quality.get("has_ci_cd") else "No"),
                ("Has Tests", "Yes" if quality.get("has_tests") else "No"),
                ("Has README", "Yes" if quality.get("has_readme") else "No"),
                ("License", quality.get("license", "None")),
            ]
            days = quality.get("days_since_last_commit")
            if days is not None and days >= 0:
                signals.append(("Last Commit", f"{days} days ago"))
            for label, value in signals:
                self._pdf_key_value(pdf, label, value)
            pdf.ln(5)

        health_score = data.get("health_score", 0)
        self._pdf_section_header(pdf, "Health Score")
        pdf.set_font("Helvetica", "B", 24)
        pdf.cell(0, 15, f"{health_score}/10", new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C")
        pdf.ln(5)

        pdf.set_font("Helvetica", "I", 8)
        pdf.cell(
            0, 10,
            f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} by Repo Analyzer",
            new_x=XPos.LMARGIN, new_y=YPos.NEXT, align="C",
        )

        pdf.output(output_path)

    def _pdf_section_header(self, pdf, title: str) -> None:
        from fpdf.enums import XPos, YPos
        pdf.set_font("Helvetica", "B", 14)
        pdf.set_text_color(0, 102, 204)
        pdf.cell(0, 10, title, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
        pdf.set_text_color(0, 0, 0)

    def _pdf_key_value(self, pdf, key: str, value: str) -> None:
        from fpdf.enums import XPos, YPos
        pdf.set_font("Helvetica", "B", 10)
        pdf.cell(80, 7, f"  {key}:", new_x=XPos.RIGHT, new_y=YPos.TOP)
        pdf.set_font("Helvetica", "", 10)
        pdf.cell(0, 7, value, new_x=XPos.LMARGIN, new_y=YPos.NEXT)
