import json
import hashlib
import os
import time
import tempfile
from typing import Any, Dict, Optional
from pathlib import Path


class CacheManager:
    DEFAULT_TTL = 300
    CACHE_DIR = os.path.join(Path.home(), ".repo_analyzer_cache")

    def __init__(self, enabled: bool = True, ttl: int = None):
        self.enabled = enabled
        self.ttl = ttl or self.DEFAULT_TTL
        if self.enabled:
            self.CACHE_DIR = self._resolve_cache_dir()

    def _resolve_cache_dir(self) -> str:
        candidates = [
            self.CACHE_DIR,
            os.path.join(tempfile.gettempdir(), ".repo_analyzer_cache"),
        ]

        for candidate in candidates:
            try:
                os.makedirs(candidate, exist_ok=True)
                probe_path = os.path.join(candidate, ".write_test")
                with open(probe_path, "w", encoding="utf-8") as f:
                    f.write("ok")
                os.remove(probe_path)
                return candidate
            except IOError:
                continue

        return self.CACHE_DIR

    def _make_key(self, url: str, params: Optional[Dict] = None) -> str:
        key_data = url
        if params:
            key_data += json.dumps(params, sort_keys=True)
        return hashlib.md5(key_data.encode()).hexdigest()

    def _cache_path(self, key: str) -> str:
        return os.path.join(self.CACHE_DIR, f"{key}.json")

    def get(self, url: str, params: Optional[Dict] = None) -> Optional[Any]:
        if not self.enabled:
            return None

        key = self._make_key(url, params)
        path = self._cache_path(key)

        if not os.path.exists(path):
            return None

        try:
            with open(path, "r", encoding="utf-8") as f:
                cached = json.load(f)

            cached_time = cached.get("timestamp", 0)
            if time.time() - cached_time > self.ttl:
                os.remove(path)
                return None

            return cached.get("data")

        except (json.JSONDecodeError, IOError, KeyError):
            if os.path.exists(path):
                os.remove(path)
            return None

    def set(self, url: str, params: Optional[Dict], data: Any) -> None:
        if not self.enabled:
            return

        key = self._make_key(url, params)
        path = self._cache_path(key)

        cache_entry = {
            "timestamp": time.time(),
            "url": url,
            "data": data,
        }

        try:
            os.makedirs(self.CACHE_DIR, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(cache_entry, f, indent=2)
        except IOError:
            pass

    def clear(self) -> int:
        if not os.path.exists(self.CACHE_DIR):
            return 0

        count = 0
        for filename in os.listdir(self.CACHE_DIR):
            if filename.endswith(".json"):
                filepath = os.path.join(self.CACHE_DIR, filename)
                try:
                    os.remove(filepath)
                    count += 1
                except IOError:
                    pass
        return count

    def clear_expired(self) -> int:
        if not os.path.exists(self.CACHE_DIR):
            return 0

        count = 0
        for filename in os.listdir(self.CACHE_DIR):
            if filename.endswith(".json"):
                filepath = os.path.join(self.CACHE_DIR, filename)
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        cached = json.load(f)
                    cached_time = cached.get("timestamp", 0)
                    if time.time() - cached_time > self.ttl:
                        os.remove(filepath)
                        count += 1
                except (json.JSONDecodeError, IOError):
                    os.remove(filepath)
                    count += 1
        return count
