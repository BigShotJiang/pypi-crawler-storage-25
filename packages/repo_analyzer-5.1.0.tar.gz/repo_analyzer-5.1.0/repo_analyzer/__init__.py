"""GitHub Repository Analyzer CLI Tool."""

__version__ = "5.1.0"
__author__ = "Khodor El Hajj Moussa"
