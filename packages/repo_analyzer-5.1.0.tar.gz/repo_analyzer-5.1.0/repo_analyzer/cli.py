import click
from rich.console import Console

from repo_analyzer.api import GitHubAPI
from repo_analyzer.analyzer import RepoAnalyzer
from repo_analyzer.display import Display
from repo_analyzer.export import Exporter
from repo_analyzer.cache import CacheManager

console = Console()


class RepoCLI(click.Group):
    COMMANDS = {"compare": None, "analyze": None}

    def list_commands(self, ctx):
        return sorted(self.COMMANDS.keys())

    def get_command(self, ctx, cmd_name):
        if cmd_name == "compare":
            return compare_cmd
        if cmd_name == "analyze":
            return analyze_cmd
        ctx.obj = ctx.obj or {}
        ctx.obj["implicit_repo_url"] = cmd_name
        return analyze_cmd


@click.command(cls=RepoCLI, invoke_without_command=True)
@click.option("--no-cache", is_flag=True, help="Bypass cache and fetch fresh data.")
@click.option("--export", "export_format", type=click.Choice(["json", "pdf"]), help="Export results to JSON or PDF.")
@click.option("--output", "-o", type=click.Path(), help="Output file path for export.")
@click.option("--recruiter", is_flag=True, help="Show recruiter-focused evaluation insights.")
@click.pass_context
def main(ctx, no_cache, export_format, output, recruiter):
    """Analyze any GitHub repository from the command line.

    \b
    Usage:
      repo-analyzer <github-url>
      repo-analyzer analyze <github-url>
      repo-analyzer compare <url-1> <url-2>

    \b
    Examples:
      repo-analyzer https://github.com/facebook/react
      repo-analyzer https://github.com/pallets/flask --export json
      repo-analyzer compare https://github.com/pallets/flask https://github.com/django/django
    """
    ctx.ensure_object(dict)
    ctx.obj["no_cache"] = no_cache
    ctx.obj["export_format"] = export_format
    ctx.obj["output"] = output
    ctx.obj["recruiter"] = recruiter

    if ctx.invoked_subcommand is None and not ctx.obj.get("implicit_repo_url"):
        console.print("[red]error:[/red] missing repository url")
        console.print("[dim]usage: repo-analyzer <github-url>[/dim]")
        console.print("[dim]       repo-analyzer compare <url-1> <url-2>[/dim]")
        console.print("[dim]try:   repo-analyzer --help[/dim]")
        raise SystemExit(1)


@click.command("analyze")
@click.argument("repo_url", required=False)
@click.option("--no-cache", is_flag=True, help="Bypass cache and fetch fresh data.")
@click.option("--export", "export_format", type=click.Choice(["json", "pdf"]), help="Export results to JSON or PDF.")
@click.option("--output", "-o", type=click.Path(), help="Output file path for export.")
@click.option("--recruiter", is_flag=True, help="Show recruiter-focused evaluation insights.")
@click.pass_context
def analyze_cmd(ctx, repo_url, no_cache, export_format, output, recruiter):
    """Analyze a single GitHub repository."""
    ctx.ensure_object(dict)

    url = repo_url or ctx.obj.get("implicit_repo_url")
    no_cache = no_cache or ctx.obj.get("no_cache", False)
    export_format = export_format or ctx.obj.get("export_format")
    output = output or ctx.obj.get("output")
    recruiter = recruiter or ctx.obj.get("recruiter", False)

    if not url:
        console.print("[red]error:[/red] missing repository url")
        raise SystemExit(1)

    try:
        cache_manager = CacheManager(enabled=not no_cache)
        api = GitHubAPI(cache_manager=cache_manager)
        analyzer = RepoAnalyzer(api=api)
        display = Display(console=console)

        owner, repo = api.parse_repo_url(url)

        with console.status(f"[dim]fetching {owner}/{repo}...[/dim]"):
            repo_data = analyzer.analyze(owner, repo)

        display.show_analysis(repo_data, recruiter_mode=recruiter)

        if export_format:
            exporter = Exporter()
            output_path = output or f"{owner}_{repo}_analysis.{export_format}"
            exporter.export(repo_data, format=export_format, output_path=output_path)
            console.print(f"[dim]wrote {output_path}[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]error:[/red] {str(e)}")
        raise SystemExit(1)


@click.command("compare")
@click.argument("repo_url_1")
@click.argument("repo_url_2")
@click.option("--no-cache", is_flag=True, help="Bypass cache and fetch fresh data.")
@click.pass_context
def compare_cmd(ctx, repo_url_1, repo_url_2, no_cache):
    """Compare two GitHub repositories side by side."""
    try:
        from repo_analyzer.compare import Comparator

        ctx.ensure_object(dict)
        no_cache = no_cache or ctx.obj.get("no_cache", False)

        cache_manager = CacheManager(enabled=not no_cache)
        api = GitHubAPI(cache_manager=cache_manager)
        analyzer = RepoAnalyzer(api=api)
        display = Display(console=console)
        comparator = Comparator(analyzer=analyzer, display=display)

        owner1, repo1 = api.parse_repo_url(repo_url_1)
        owner2, repo2 = api.parse_repo_url(repo_url_2)

        with console.status("[dim]fetching repos...[/dim]"):
            comparator.compare(owner1, repo1, owner2, repo2)

    except Exception as e:
        console.print(f"[red]error:[/red] {str(e)}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
