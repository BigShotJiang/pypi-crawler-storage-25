from datetime import datetime, timedelta
from typing import Dict, Any, List

from repo_analyzer.api import GitHubAPI
from repo_analyzer.health import HealthScorer


class RepoAnalyzer:
    def __init__(self, api: GitHubAPI):
        self.api = api
        self.health_scorer = HealthScorer()

    def analyze(self, owner: str, repo: str) -> Dict[str, Any]:
        repo_info = self.api.get_repo_info(owner, repo)

        try:
            languages = self.api.get_languages(owner, repo)
            language_breakdown = self._calculate_language_percentages(languages)
        except Exception:
            language_breakdown = []

        try:
            contributors = self.api.get_contributors(owner, repo, per_page=25)
            top_contributors = self._format_contributors(contributors)
        except Exception:
            top_contributors = []

        open_pulls = self._safe_list_call(self.api.get_open_pulls, owner, repo)
        releases = self._safe_list_call(self.api.get_releases, owner, repo)
        commit_activity = self._get_commit_activity(owner, repo)
        quality_signals = self._check_quality_signals(owner, repo, repo_info, releases)
        contributor_insights = self._build_contributor_insights(top_contributors)
        trend_analysis = self._build_trend_analysis(commit_activity, quality_signals)

        health_score = self.health_scorer.calculate(
            repo_info=repo_info,
            language_breakdown=language_breakdown,
            contributors=top_contributors,
            commits_this_month=commit_activity["last_30_days"],
            open_pulls_count=len(open_pulls),
            quality_signals=quality_signals,
        )

        repository_scores = self._build_repository_scores(
            repo_info=repo_info,
            quality_signals=quality_signals,
            contributor_insights=contributor_insights,
            commit_activity=commit_activity,
            open_pulls_count=len(open_pulls),
            health_score=health_score,
        )

        narrative_insights = self._build_narrative_insights(
            repo_info=repo_info,
            quality_signals=quality_signals,
            contributor_insights=contributor_insights,
            trend_analysis=trend_analysis,
            repository_scores=repository_scores,
            health_score=health_score,
        )

        return {
            "owner": owner,
            "repo": repo,
            "full_name": repo_info.get("full_name", f"{owner}/{repo}"),
            "description": repo_info.get("description", "No description"),
            "stars": repo_info.get("stargazers_count", 0),
            "forks": repo_info.get("forks_count", 0),
            "watchers": repo_info.get("subscribers_count", 0),
            "open_issues": repo_info.get("open_issues_count", 0),
            "open_prs": len(open_pulls),
            "commits_this_month": commit_activity["last_30_days"],
            "language_breakdown": language_breakdown,
            "top_contributors": top_contributors,
            "quality_signals": quality_signals,
            "contributor_insights": contributor_insights,
            "trend_analysis": trend_analysis,
            "repository_scores": repository_scores,
            "narrative_insights": narrative_insights,
            "health_score": health_score,
            "created_at": repo_info.get("created_at", ""),
            "updated_at": repo_info.get("updated_at", ""),
            "pushed_at": repo_info.get("pushed_at", ""),
            "default_branch": repo_info.get("default_branch", "main"),
            "license": self._get_license_name(repo_info),
            "topics": repo_info.get("topics", []),
            "release_count": len(releases),
        }

    def _safe_list_call(self, fn, *args, **kwargs) -> List[Dict[str, Any]]:
        try:
            return fn(*args, **kwargs)
        except Exception:
            return []

    def _calculate_language_percentages(self, languages: Dict[str, int]) -> List[Dict[str, Any]]:
        total_bytes = sum(languages.values())
        if total_bytes == 0:
            return []

        breakdown = []
        for lang, bytes_count in sorted(languages.items(), key=lambda x: x[1], reverse=True):
            percentage = (bytes_count / total_bytes) * 100
            breakdown.append({
                "language": lang,
                "percentage": round(percentage, 1),
                "bytes": bytes_count,
            })
        return breakdown

    def _format_contributors(self, contributors: List[Dict]) -> List[Dict[str, Any]]:
        formatted = []
        for contributor in contributors:
            formatted.append({
                "login": contributor.get("login", "Unknown"),
                "contributions": contributor.get("contributions", 0),
                "avatar_url": contributor.get("avatar_url", ""),
                "profile_url": contributor.get("html_url", ""),
            })
        return formatted

    def _get_commit_activity(self, owner: str, repo: str) -> Dict[str, int]:
        now = datetime.utcnow()
        windows = {
            "last_30_days": 30,
            "last_90_days": 90,
            "last_180_days": 180,
        }
        activity: Dict[str, int] = {}

        for label, days in windows.items():
            since = (now - timedelta(days=days)).replace(microsecond=0).isoformat() + "Z"
            try:
                commits = self.api.get_commits(owner, repo, since=since, per_page=100)
                activity[label] = len(commits)
            except Exception:
                activity[label] = 0

        return activity

    def _check_quality_signals(
        self,
        owner: str,
        repo: str,
        repo_info: Dict,
        releases: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        workflows = self.api.get_workflows(owner, repo)
        has_ci_cd = workflows.get("total_count", 0) > 0

        has_tests = self._check_any_paths_exist(
            owner,
            repo,
            ["tests", "test", "__tests__", "spec"],
        )
        has_readme = self._check_any_paths_exist(
            owner,
            repo,
            ["README.md", "README.rst", "README"],
        )
        has_contributing = self._check_any_paths_exist(
            owner,
            repo,
            ["CONTRIBUTING.md", "CONTRIBUTING.rst", ".github/CONTRIBUTING.md"],
        )
        has_security = self._check_any_paths_exist(
            owner,
            repo,
            ["SECURITY.md", ".github/SECURITY.md"],
        )
        has_codeowners = self._check_any_paths_exist(
            owner,
            repo,
            ["CODEOWNERS", ".github/CODEOWNERS", "docs/CODEOWNERS"],
        )
        has_issue_templates = self._check_any_paths_exist(
            owner,
            repo,
            [
                ".github/ISSUE_TEMPLATE",
                ".github/ISSUE_TEMPLATE.md",
                ".github/ISSUE_TEMPLATE.yml",
                ".github/ISSUE_TEMPLATE.yaml",
                ".github/ISSUE_TEMPLATE/config.yml",
            ],
        )
        has_pr_template = self._check_any_paths_exist(
            owner,
            repo,
            [
                ".github/pull_request_template.md",
                "pull_request_template.md",
                "docs/pull_request_template.md",
            ],
        )
        has_changelog = self._check_any_paths_exist(
            owner,
            repo,
            ["CHANGELOG.md", "CHANGES.md", "HISTORY.md"],
        )

        license_name = self._get_license_name(repo_info)
        last_push = repo_info.get("pushed_at", "")
        days_since_last_commit = self._days_since(last_push) if last_push else None

        return {
            "has_ci_cd": has_ci_cd,
            "has_tests": has_tests,
            "has_readme": has_readme,
            "has_contributing": has_contributing,
            "has_security": has_security,
            "has_codeowners": has_codeowners,
            "has_issue_templates": has_issue_templates,
            "has_pr_template": has_pr_template,
            "has_changelog": has_changelog,
            "has_releases": len(releases) > 0,
            "license": license_name,
            "days_since_last_commit": days_since_last_commit,
        }

    def _build_contributor_insights(self, contributors: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not contributors:
            return {
                "contributor_count": 0,
                "total_top_contributions": 0,
                "lead_contributor_share": 0.0,
                "top_three_share": 0.0,
                "bus_factor": 0,
                "risk_level": "unknown",
            }

        total_contributions = sum(item.get("contributions", 0) for item in contributors)
        lead_contributions = contributors[0].get("contributions", 0)
        top_three = contributors[:3]
        top_three_contributions = sum(item.get("contributions", 0) for item in top_three)

        lead_share = round((lead_contributions / total_contributions) * 100, 1) if total_contributions else 0.0
        top_three_share = round((top_three_contributions / total_contributions) * 100, 1) if total_contributions else 0.0

        running_total = 0
        bus_factor = 0
        threshold = total_contributions * 0.5
        for contributor in contributors:
            running_total += contributor.get("contributions", 0)
            bus_factor += 1
            if running_total >= threshold:
                break

        if lead_share >= 70 or len(contributors) <= 1:
            risk_level = "high"
        elif lead_share >= 45 or bus_factor <= 1:
            risk_level = "medium"
        else:
            risk_level = "low"

        return {
            "contributor_count": len(contributors),
            "total_top_contributions": total_contributions,
            "lead_contributor_share": lead_share,
            "top_three_share": top_three_share,
            "bus_factor": bus_factor,
            "risk_level": risk_level,
        }

    def _build_trend_analysis(
        self,
        commit_activity: Dict[str, int],
        quality_signals: Dict[str, Any],
    ) -> Dict[str, Any]:
        commits_30 = commit_activity.get("last_30_days", 0)
        commits_90 = commit_activity.get("last_90_days", 0)
        commits_180 = commit_activity.get("last_180_days", 0)

        rate_30 = commits_30 / 30 if commits_30 else 0
        rate_90 = commits_90 / 90 if commits_90 else 0
        rate_180 = commits_180 / 180 if commits_180 else 0

        if commits_30 == commits_90 == commits_180 == 0:
            activity_trend = "inactive"
        elif rate_30 >= rate_90 * 1.25 and rate_30 >= rate_180 * 1.25:
            activity_trend = "accelerating"
        elif rate_30 <= rate_90 * 0.75 and rate_30 <= rate_180 * 0.75:
            activity_trend = "cooling"
        else:
            activity_trend = "steady"

        days = quality_signals.get("days_since_last_commit")
        if days is None or days < 0:
            maintenance_status = "unknown"
        elif days <= 14:
            maintenance_status = "active"
        elif days <= 90:
            maintenance_status = "watch"
        else:
            maintenance_status = "stale"

        return {
            "activity_trend": activity_trend,
            "maintenance_status": maintenance_status,
            "last_30_days": commits_30,
            "last_90_days": commits_90,
            "last_180_days": commits_180,
        }

    def _build_repository_scores(
        self,
        repo_info: Dict[str, Any],
        quality_signals: Dict[str, Any],
        contributor_insights: Dict[str, Any],
        commit_activity: Dict[str, int],
        open_pulls_count: int,
        health_score: float,
    ) -> Dict[str, float]:
        maintainability = 0.0
        maintainability += 2.5 if quality_signals.get("has_ci_cd") else 0.0
        maintainability += 2.0 if quality_signals.get("has_tests") else 0.0
        maintainability += 1.0 if quality_signals.get("has_codeowners") else 0.0
        maintainability += 1.0 if quality_signals.get("has_releases") else 0.0
        maintainability += 1.0 if quality_signals.get("has_changelog") else 0.0
        maintainability += 2.5 if (quality_signals.get("days_since_last_commit") or 9999) <= 30 else 0.5
        maintainability -= 1.0 if open_pulls_count > 100 else 0.0

        collaboration = 0.0
        contributor_count = contributor_insights.get("contributor_count", 0)
        collaboration += 1.5 if contributor_count >= 5 else (1.0 if contributor_count >= 2 else 0.0)
        collaboration += 3.0 if contributor_insights.get("bus_factor", 0) >= 2 else 1.0
        collaboration += 2.5 if contributor_insights.get("lead_contributor_share", 100.0) <= 45 else 0.5
        collaboration += 1.5 if quality_signals.get("has_contributing") else 0.0
        collaboration += 1.0 if quality_signals.get("has_issue_templates") else 0.0
        collaboration += 1.0 if quality_signals.get("has_pr_template") else 0.0
        collaboration += 1.0 if quality_signals.get("has_codeowners") else 0.0

        production_readiness = 0.0
        production_readiness += 2.0 if quality_signals.get("has_ci_cd") else 0.0
        production_readiness += 2.0 if quality_signals.get("has_tests") else 0.0
        production_readiness += 1.5 if quality_signals.get("has_security") else 0.0
        production_readiness += 1.0 if quality_signals.get("has_releases") else 0.0
        production_readiness += 1.0 if quality_signals.get("has_codeowners") else 0.0
        production_readiness += 1.0 if quality_signals.get("has_changelog") else 0.0
        production_readiness += 1.5 if quality_signals.get("license") not in ("None", "NOASSERTION") else 0.0

        onboarding = 0.0
        onboarding += 3.0 if quality_signals.get("has_readme") else 0.0
        onboarding += 2.0 if quality_signals.get("has_contributing") else 0.0
        onboarding += 1.0 if quality_signals.get("has_issue_templates") else 0.0
        onboarding += 1.0 if quality_signals.get("has_pr_template") else 0.0
        onboarding += 1.0 if repo_info.get("description") else 0.0
        onboarding += 2.0 if len(repo_info.get("topics", [])) >= 3 else (1.0 if repo_info.get("topics") else 0.0)

        recruiter_signal = (
            health_score * 0.35
            + min(maintainability, 10.0) * 0.2
            + min(collaboration, 10.0) * 0.2
            + min(production_readiness, 10.0) * 0.15
            + min(onboarding, 10.0) * 0.1
        )

        if contributor_insights.get("risk_level") == "high":
            recruiter_signal -= 0.8
        elif contributor_insights.get("risk_level") == "medium":
            recruiter_signal -= 0.3

        if commit_activity.get("last_30_days", 0) == 0:
            recruiter_signal -= 0.5

        return {
            "maintainability": round(max(0.0, min(maintainability, 10.0)), 1),
            "collaboration": round(max(0.0, min(collaboration, 10.0)), 1),
            "production_readiness": round(max(0.0, min(production_readiness, 10.0)), 1),
            "onboarding": round(max(0.0, min(onboarding, 10.0)), 1),
            "recruiter_signal": round(max(0.0, min(recruiter_signal, 10.0)), 1),
        }

    def _build_narrative_insights(
        self,
        repo_info: Dict[str, Any],
        quality_signals: Dict[str, Any],
        contributor_insights: Dict[str, Any],
        trend_analysis: Dict[str, Any],
        repository_scores: Dict[str, float],
        health_score: float,
    ) -> Dict[str, Any]:
        strengths: List[str] = []
        concerns: List[str] = []
        recommendations: List[str] = []

        if health_score >= 8.0:
            strengths.append("Strong overall repository health.")
        if quality_signals.get("has_ci_cd") and quality_signals.get("has_tests"):
            strengths.append("Engineering hygiene is backed by CI and tests.")
        if quality_signals.get("has_security"):
            strengths.append("Security policy is documented.")
        if contributor_insights.get("risk_level") == "low":
            strengths.append("Contribution ownership is reasonably distributed.")
        if trend_analysis.get("activity_trend") == "accelerating":
            strengths.append("Commit activity is accelerating.")
        if repository_scores.get("onboarding", 0) >= 7.0:
            strengths.append("New contributors get solid onboarding signals.")

        if contributor_insights.get("risk_level") == "high":
            concerns.append(
                f"High bus-factor risk: lead contributor accounts for {contributor_insights.get('lead_contributor_share', 0):.1f}% of tracked commits."
            )
            recommendations.append("Reduce ownership concentration by broadening review and merge responsibility.")
        elif contributor_insights.get("risk_level") == "medium":
            concerns.append("Contribution history is somewhat concentrated around a small set of maintainers.")

        if not quality_signals.get("has_tests"):
            concerns.append("No test footprint was detected.")
            recommendations.append("Add an automated test suite to improve trust and production readiness.")
        if not quality_signals.get("has_ci_cd"):
            concerns.append("No CI workflow was detected.")
            recommendations.append("Add CI checks so changes are validated automatically.")
        if not quality_signals.get("has_contributing"):
            concerns.append("Contributor guidance is missing.")
            recommendations.append("Add CONTRIBUTING.md to make external contributions easier.")
        if not quality_signals.get("has_security"):
            concerns.append("Security disclosure guidance is missing.")
            recommendations.append("Add SECURITY.md to improve operational maturity.")
        if trend_analysis.get("maintenance_status") == "stale":
            concerns.append("Recent maintenance appears stale.")
            recommendations.append("Revive activity or clarify maintenance status in the README.")
        if not quality_signals.get("has_issue_templates"):
            recommendations.append("Add issue templates to standardize incoming bug reports.")
        if not quality_signals.get("has_pr_template"):
            recommendations.append("Add a pull request template to improve review quality.")

        if not strengths:
            strengths.append("Repository has baseline public metadata and can still be assessed.")
        if not concerns:
            concerns.append("No major repository risks stand out from the available signals.")
        if not recommendations:
            recommendations.append("Keep release cadence, docs, and contributor experience visible as the repo grows.")

        if health_score >= 8.0 and contributor_insights.get("risk_level") == "low":
            verdict = "Well-maintained and low-risk."
        elif health_score >= 7.0:
            verdict = "Promising repository with a few operational gaps."
        elif health_score >= 5.0:
            verdict = "Usable project, but diligence is needed before trusting maintainability."
        else:
            verdict = "Repository shows material maturity or maintenance risks."

        recruiter_summary = (
            f"{repo_info.get('full_name', 'This repo')} scores {repository_scores.get('recruiter_signal', 0):.1f}/10 "
            f"for recruiter-facing signals, with {trend_analysis.get('maintenance_status', 'unknown')} maintenance "
            f"and {contributor_insights.get('risk_level', 'unknown')} ownership risk."
        )

        return {
            "verdict": verdict,
            "strengths": strengths[:3],
            "concerns": concerns[:3],
            "recommendations": recommendations[:4],
            "recruiter_summary": recruiter_summary,
        }

    def _check_any_paths_exist(self, owner: str, repo: str, paths: List[str]) -> bool:
        return any(self._check_path_exists(owner, repo, path) for path in paths)

    def _check_path_exists(self, owner: str, repo: str, path: str) -> bool:
        try:
            self.api.get_contents(owner, repo, path)
            return True
        except Exception:
            return False

    def _get_license_name(self, repo_info: Dict) -> str:
        license_info = repo_info.get("license")
        if license_info and isinstance(license_info, dict):
            return license_info.get("spdx_id", "Unknown")
        return "None"

    def _days_since(self, date_str: str) -> int:
        try:
            date = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
            now = datetime.now(date.tzinfo)
            delta = now - date
            return delta.days
        except (ValueError, TypeError):
            return -1
