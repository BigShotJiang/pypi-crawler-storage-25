<p align="center">
  <a href="https://pypi.org/project/skillpop/"><img src="https://img.shields.io/pypi/v/skillpop?style=flat-square&color=e07b44" /></a>
  <img src="https://img.shields.io/badge/python-3.10+-blue?style=flat-square&logo=python&logoColor=white" />
  <img src="https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey?style=flat-square" />
  <img src="https://img.shields.io/badge/license-MIT-green?style=flat-square" />
  <img src="https://img.shields.io/github/stars/liyue2341/skillpop?style=flat-square" />
</p>

<h1 align="center">SkillPop</h1>

<p align="center">
  <strong>Your skills are your build. Keep them in sync.</strong><br/>
  Scan, sync & share AI agent skills across every platform — from one local dashboard.
</p>

<p align="center">
  <a href="#quick-start">Quick Start</a> &middot;
  <a href="#scan-sync-share">Scan · Sync · Share</a> &middot;
  <a href="#supported-platforms">Platforms</a> &middot;
  <a href="#how-it-works">How It Works</a> &middot;
  <a href="#support">Support</a>
</p>

<p align="center">
  <img src="docs/demo.gif" alt="SkillPop demo" width="720" />
</p>

---

## The Problem

SKILL.md is the open standard for AI agent skills — Anthropic published it, OpenAI Codex and Gemini CLI adopted the same format. But each platform stores skills in **different directories** with **no sync mechanism**. Your build drifts, skills get duplicated, or live on only one platform.

SkillPop gives you **one dashboard** to scan your entire build, sync with a drag, and share it with anyone.

---

## Quick Start

One command. Scan your skills, sync across platforms, share your build.

```bash
uvx skillpop
```

Or with pip:

```bash
pip install skillpop
skillpop
```

Your browser opens at `http://127.0.0.1:7432`. That's it.

<details>
<summary>Install from source</summary>

```bash
git clone https://github.com/Liyue2341/SkillPop.git
cd SkillPop
pip install -e .
```

</details>

---

## Scan · Sync · Share

### Scan — see all your skills at a glance

<p align="center">
  <img src="docs/grid-view.png" alt="Card grid overview" width="720" />
</p>

SkillPop discovers skill directories across all your platforms automatically. Every skill card shows its name, description, sync status, and which platforms it lives on. Switch between card grid and tree view to browse your way.

### Sync — drag & drop between platforms

<p align="center">
  <img src="docs/tree-view.png" alt="Tree view with detail panel" width="720" />
</p>

See a skill on Codex that Claude Code doesn't have? Drag it to the Claude Code header. Done. If the skill already exists with different content, you'll get a confirmation prompt before overwriting. Line-level diffs help you decide which version to keep.

### Share — export your build, import anyone's

Click export to bundle your entire build into a ZIP — share it with a teammate, move to a new machine, or post it online. Others can import your build with one click and all skills get installed to their platforms automatically.

### More

- **Skill creation wizard** — create and deploy to multiple platforms in one step
- **Live file watching** — `--watch` flag auto-rescans on filesystem changes
- **Custom platforms** — add your own skill directories from the UI, persisted across restarts
- **Chinese / English** — full i18n with one-click toggle
- **Dark / light theme** — auto-detects your system preference

---

## All Commands

| Command | Description |
|---|---|
| `skillpop` | Start and open browser |
| `skillpop --watch` | Auto-rescan on file changes |
| `skillpop --port 8080` | Custom port |
| `skillpop --no-browser` | Don't auto-open browser |
| `skillpop --add id:label:path` | Register a custom platform via CLI |

---

## Supported Platforms

| Platform | ID | Default Path |
|---|---|---|
| Claude Code (personal) | `cc` | `~/.claude/skills/` |
| Claude Code (project) | `ccp` | `./.claude/skills/` |
| Codex CLI | `cx` | `~/.codex/skills/` |
| Gemini CLI | `gm` | `~/.gemini/skills/` |
| OpenCode | `oc` | `~/.opencode/skills/` |
| Cursor | `cu` | `~/.cursor/skills/` |
| Amp | `am` | `~/.amp/skills/` |
| Claude.ai | `ai` | _(web upload only)_ |

**Managing platforms:** Don't use Codex or OpenCode? Click the `×` next to any platform to remove it. Want to add a new one? Click `+ add custom platform` at the bottom of the sidebar, or use `--add id:label:path` from the CLI. All changes are saved to `~/.skillpop/config.json`.

---

## How It Works

1. **Scan** — discovers skill directories across all platforms. Each subdirectory containing a `SKILL.md` is one skill. Skills with the same name on multiple platforms are grouped and compared automatically (**synced**, **diverged**, or **unique**).

2. **Sync** — drag-and-drop or click to copy skills between platforms. Diverged skills show line-level diffs so you can decide which version to keep.

3. **Share** — export all your skills as a ZIP to share your build. Anyone can import it to install your skills on their platforms in one click.

---

## Development

```bash
git clone https://github.com/Liyue2341/SkillPop.git
cd SkillPop
pip install -e .
skillpop --watch --no-browser
```

The frontend is a single HTML file (`skillpop/static/index.html`) — no build tools, no npm. Edit and refresh.

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Requirements

- Python 3.10+
- Dependencies auto-installed: `fastapi`, `uvicorn`, `watchdog`, `python-multipart`

---

## Support

If SkillPop saved you from skill chaos across platforms, consider buying me a coffee:

<p align="center">
  <a href="https://buymeacoffee.com/liyue2341">
    <img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" height="50" />
  </a>
</p>

---

<p align="center">MIT &copy; 2025 <a href="https://github.com/liyue2341">liyue2341</a></p>
