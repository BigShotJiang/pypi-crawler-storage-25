# MANDATORY PIPELINE

Execute ALL sections below in sequence. Do NOT stop after any section. Session is NOT complete until COMMIT and THE ISSUE are done.

---

# ISSUES

Issues JSON is provided at start of context. Parse it to get open issues with their bodies and comments.

You've also been passed the last 10 ralph commits (SHA, date, full message). Review these to understand what work has been done.

# TASK BREAKDOWN

Break down the issues into tasks. An issue may contain a single task (a small bugfix or visual tweak) or many, many tasks (a PRD or a large refactor).

Make each task the smallest possible unit of work. We don't want to outrun our headlights. Aim for one small change per task.

# TASK SELECTION

Pick the next task. Prioritize tasks in this order:

1. Critical bugfixes
2. Tracer bullets for new features

Tracer bullets comes from the Pragmatic Programmer. When building systems, you want to write code that gets you feedback as quickly as possible. Tracer bullets are small slices of functionality that go through all layers of the system, allowing you to test and validate your approach early. This helps in identifying potential issues and ensures that the overall architecture is sound before investing significant time in development.

TL;DR - build a tiny, end-to-end slice of the feature first, then expand it out.

3. Polish and quick wins
4. Refactors

If all tasks are complete, output <promise>COMPLETE</promise>.

# EXPLORATION

Explore the repo and fill your context window with relevant information that will allow you to complete the task.

**Prefer LSP over Grep** for code navigation tasks (finding definitions, references, implementations)

# EXECUTION

Complete the task.

If you find that the task is larger than you expected (for instance, requires a refactor first), output "HANG ON A SECOND".

Then, find a way to break it into a smaller chunk and only do that chunk (i.e. complete the smaller refactor).

# FEEDBACK LOOPS

Set up dev environment: `make setup-venv`

Run each verification step:

1. `make ruff` — lint + format
2. `make pyright` — type check
3. `make run-tests-cov` — tests + coverage (if I/O error in Docker, use `uv run pytest --cov=src tests`)

Fix failures before proceeding. Once all pass, continue to COMMIT.

# COMMIT

Make a git commit. The commit message must:

1. Start with `ralph:` prefix
2. Include task completed + PRD reference
3. Key decisions made
4. Files changed
5. Blockers or notes for next iteration

Keep it concise.

# THE ISSUE

If the task is complete, update any checkbox in issue body related to the task. If all tasks are complete, close the original GitHub issue.

If the task is not complete, leave a comment on the GitHub issue with what was done.

# FINAL RULES

**DO NOT SKIP ANY SECTION IN THIS DOC**.
**DO NOT STOP UNTIL YOU HAVE COMPLETED ALL SECTIONS INCLUDING COMMIT AND THE ISSUE**.
**ONLY WORK ON A SINGLE TASK**.
