# GSD-Lean — Claude AI Assistant Guide

Lightweight Python reimplementation of [Get-Shit-Done](https://github.com/glittercowboy/get-shit-done): a meta-prompting and spec-driven development system packaged as a Claude Code plugin.

Architecture/state-machine: [PROJECT_KNOWLEDGE.md](./PROJECT_KNOWLEDGE.md). Debugging: [TROUBLESHOOTING.md](./TROUBLESHOOTING.md). Releases: [RELEASE.md](./RELEASE.md).

---

## Quick Start

**First-time setup**:
```bash
make setup-venv   # clean + sync + pre-commit-install
```

**Daily**: `make ruff` (lint+fix), `make pyright` (types), `make run-tests` (tests).

**Stuck?** → [TROUBLESHOOTING.md](./TROUBLESHOOTING.md).

---

## Make Commands

```bash
make sync                               # Install all deps (dev + lint)
make pre-commit-install                 # Install pre-commit hooks
make pre-commit                         # Run all pre-commit checks
make ruff                               # Lint + format (auto-fix)
make ruff path=src/gsd_lean/cli         # Lint specific path
make pyright                            # Type check src/
make pyright path=src/gsd_lean/cli      # Type check specific path
make run-tests                          # Run tests
make run-tests path=tests/test_foo.py   # Run single test file
make run-tests-cov                      # Run tests with coverage
make changelog                          # Regenerate CHANGELOG.md via git-cliff
make generate-lock-file                 # Generate uv.lock from pyproject.toml
make clean                              # Remove generated files
make setup-venv                         # clean + sync + pre-commit-install
```

All commands wrap `uv run`. Never invoke pytest/ruff/pyright directly — go through `make` or `uv run`.

---

## Stack & Style

Python 3.12+, uv, ruff, pyright, pytest. Full detail: [PROJECT_KNOWLEDGE.md#core-stack](./PROJECT_KNOWLEDGE.md#core-stack), [PROJECT_KNOWLEDGE.md#code-quality-philosophy](./PROJECT_KNOWLEDGE.md#code-quality-philosophy).

**Non-obvious rules**:
- **Dependencies**: manage via `uv add` / `uv remove`. NEVER edit `pyproject.toml` directly.
- **Markdown fences**: when a fenced block contains inner ` ``` `, use 4-backtick (```` ``` ````) outer fences.
- **Docs lookup**: Context7 (`mcp__context7__resolve-library-id` → `mcp__context7__query-docs`) for tech-stack docs.

---

## GSD-Lean Workflow Skills

Located in `skills/` at repo root. Cycle: `init → discuss → plan → execute → verify → complete`.

| Skill | Purpose |
|-------|---------|
| `/init` | Project initialization — scaffold, auto-detect stack, onboard |
| `/discuss` | Research subagents + user probing → REQUIREMENTS.md, DECISIONS.md |
| `/plan` | Decompose requirements into T-NNN tasks → PLAN.md |
| `/execute` | Run next task (executor → spec-review → code-quality-review → verify-execute; auto-debug + commit) |
| `/verify` | Project checks against task verification criteria |
| `/complete` | Cycle wrap-up + summary |
| `/commit` | Pre-computed git commit |
| `/quick` | Ad-hoc execute + verify + commit (bypasses full cycle) |

State machine, transitions, subagent table: [PROJECT_KNOWLEDGE.md#workflow-engine-6-phase-cycle](./PROJECT_KNOWLEDGE.md#workflow-engine-6-phase-cycle).

---

## GSD-Lean CLI

| Command | Description |
|---------|-------------|
| `uvx gsd-lean init` | Initialize `.planning/` with state files |
| `uvx gsd-lean status` | Show current phase + project state |
| `uvx gsd-lean transition <phase>` | Move to discuss/plan/execute/verify/complete |
| `uvx gsd-lean new-cycle` | Archive current cycle, scaffold new |
| `uvx gsd-lean migrate` | Migrate v1 `.planning/` to v2 layout |
| `uvx gsd-lean plan-status` | Plan progress (tasks done/total, wave, next) |
| `uvx gsd-lean config` | Display/validate subagent config |
| `uvx gsd-lean version` | Installed version |

Common flags: `--force` (bypass preconditions), `--note <text>` (history note), `--path <dir>` (project root), `--json` (plan-status only).

---

## Internal Dev Skills

In `.claude/skills/`. For internal development of GSD-Lean itself (not exposed to plugin users):

| Slash Command | Purpose |
|---------------|---------|
| `/pre-release` | Pre-release (alpha/beta/RC) of GSD-Lean |
| `/release` | Generate a new release |
| `/verify` | Local verification (lint, typecheck, tests) |
| `/skill-creator` | Create/modify/eval/benchmark skills (use this first) |
| `/skill-development` | Style guidance for writing skills |
| `/agent-development` | Guidance on creating Claude Code agents |
| `/claude-md-improver` | Audit + improve CLAUDE.md files |

---

## LSP Tool Usage

Enabled via `pyright-lsp@claude-plugins-official` (`ENABLE_LSP_TOOL=1` in `.claude/settings.json`).

**Use LSP for symbol navigation**. Operations: `goToDefinition`, `findReferences`, `hover`, `documentSymbol`, `workspaceSymbol`, `goToImplementation`, `incomingCalls`, `outgoingCalls`. Use Grep for free-text/string search.

---

## Other

- **Releases**: tag-based — `git tag -a v0.1.X -m "Release v0.1.X" && git push origin v0.1.X`. See `RELEASE.md`.
- **Marketplace**: plugins listed in `.claude-plugin/marketplace.json` of `Bifurcate-Loops/bifurcate-plugins`.
- **Ralph**: autonomous Docker agent loop in `ralph/` (see `ralph/SETUP.md`).
- **Hooks**: GSD-Lean statusline in `hooks/`.
