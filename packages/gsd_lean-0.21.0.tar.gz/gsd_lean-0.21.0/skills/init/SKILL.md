---
description: This skill should be used when the user runs "/gsd-lean:init" or asks to "initialize project", "scaffold planning directory", or "detect tech stack". Two-phase project initialization — scaffold + LSP check, then detect stack + populate docs.
argument-hint: ["project path, defaults to current directory"]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(command -v uvx), Bash(uvx gsd-lean:*), Bash(git:*), Agent, AskUserQuestion, LSP, EnterPlanMode, ExitPlanMode
disable-model-invocation: true
---

## Instructions

**/init** scaffolds `.planning/`, checks LSP/statusline, auto-detects tech stack, populates `PROJECT.md`, and onboards user to 5-phase workflow.

Two phases:
- **Phase A (Scaffold):** Create `.planning/`, check LSP and statusline. If LSP not configured, stop with setup guidance.
- **Phase B (Populate):** Detect stack, populate planning docs, onboard. Runs only when LSP already enabled or on second `/init` run.

## Contract

Execute every step in order. You MUST NOT skip Step 2 (PlanMode entry), Step 3 (docs reads), Step 5 (init-explore spawn) — regardless of task size. No exceptions for "trivial" or "obvious" changes.

If a step names a file, read it. If a step names a subagent, spawn it. If a step names a verification gate, run it.

You are a protocol executor, not a judge of which steps apply.

### Step 0: Prerequisites

Run:
```
command -v uvx
```

**If fails (exit code != 0):** Print error below and **STOP**:

````markdown
## Error: `uvx` is not installed

GSD-Lean requires [uv](https://github.com/astral-sh/uv) to run. Install it:

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

After installing, restart your terminal and run `/gsd-lean:init` again.
````

**If succeeds:** Proceed to Step 1.

### Step 1: Initialization Gate

Check whether `.planning/STATE.md` exists and whether LSP is enabled.

**1a. Check `.planning/STATE.md` existence.**

**If STATE.md does NOT exist (first run):**

Run:
```
uvx gsd-lean init --path .
```

Read `.claude/settings.json` (if exists) and check whether `env.ENABLE_LSP_TOOL` is `"1"`.

- **If LSP NOT enabled:** Print Phase A output (Step 1b), then **STOP**.
- **If LSP enabled:** Check statusline (Step 1c), then proceed to Step 2.

**If STATE.md exists (subsequent run):**

Print: "Project already initialized. Running in populate mode (non-destructive)."

Read `.claude/settings.json` (if exists) and check `env.ENABLE_LSP_TOOL`.

- **If LSP NOT enabled:** Warn: "LSP not enabled — detection will rely on Glob/Grep/Read instead of LSP tools."
- Continue to Step 2 regardless.

### Step 1b: Phase A Output (LSP Not Configured)

Print setup guidance below, then STOP:

````markdown
## Setup Required

GSD-Lean works best with LSP tools enabled. Three steps needed:

### 1. Install an LSP server

| Language | Install command |
|----------|----------------|
| TypeScript/JavaScript | `npm i -g typescript-language-server@latest` |
| Python | `pip install pyright` or `npm i -g pyright` |

### 2. Install the Claude Code LSP plugin

Run `/plugin` in Claude Code and install:

| Language | Plugin name |
|----------|-------------|
| TypeScript/JavaScript | `typescript-lsp@claude-plugins-official` |
| Python | `pyright-lsp@claude-plugins-official` |

### 3. Enable LSP in settings

Add to `.claude/settings.json`:

```json
{
  "enabledPlugins": {
    "<plugin-name>@claude-plugins-official": true
  },
  "env": {
    "ENABLE_LSP_TOOL": "1"
  }
}
```

## What's Next

1. Complete LSP setup above
2. Edit `.planning/config.yaml` if you want to tune subagent settings (model overrides per subagent)
3. Run `/gsd-lean:init` again to detect project stack and populate planning docs
````

Also check statusline (Step 1c) and append statusline guidance if not configured.

### Step 1c: Statusline Check

Check `.claude/settings.json` for `statusLine` key.

- If not configured, append:
  > **Recommendation:** Install GSD-Lean statusline hook for phase/branch visibility. Run: `uvx gsd-lean init --force-statusline`
- If already configured, append:
  > **Note:** Statusline is already configured.

---

## Phase B: Populate

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. All codebase exploration, stack detection, and user confirmation happens in plan mode. Exit plan mode before writing state files.

### Step 3: Read Project Documentation

Read available project docs to understand existing conventions before detection:

1. **`CLAUDE.md`** at repo root (if exists) — extract:
   - Dev commands (build, test, lint, format, typecheck)
   - Code style conventions, tech stack details, CI/CD info, tooling config

   **Conflict check:** Scan for development workflow instructions (branching strategy, commit conventions, PR workflows, test-before-push, feature dev flow). If found, print:

   > **Warning:** `CLAUDE.md` contains development workflow instructions that may conflict with GSD-Lean's phased development cycle. Consider removing or commenting out these instructions before proceeding. See the [Caveats section in the README](./README.md#caveats) for details.

   Continue without blocking.

2. **Other docs** (if exists): `PROJECT_KNOWLEDGE.md`, `CONTRIBUTING.md`, `README.md`, `TROUBLESHOOTING.md`

If `CLAUDE.md` exists, treat as canonical source for tooling and conventions. Step 5 detection fills gaps, not duplicates.

Reference `CLAUDE.md` in onboarding summary rather than recreating content in `.planning/` files.

### Step 4: Read Subagent Config

Read `.planning/config.yaml` if exists. Resolve `model` for each subagent:

| Subagent | Config key |
|----------|------------|
| init-explore | `skills.init.subagents.init-explore` |

Fallback to `defaults` section, then omit (inherit from session).

### Step 5: Auto-Detect Project Stack

Spawn `subagent_type=gsd-lean:init-explore`. If config loaded, pass resolved `model`. Omit null/unset parameters.

Pass the prompt: "Detect project stack and conventions."

### Step 6: Present Findings & Confirm

Present subagent findings:

```
## Detected Project Stack

- **Language:** <language> <version>
- **Framework:** <framework>
- **Build tool:** <tool>
- **Key dependencies:** <deps>
- **Test runner:** <runner>
- **Linter:** <linter>
- **Formatter:** <formatter (if different from linter)>
- **Type checker:** <checker>
- **CI:** <platform>
- **Runtime manager:** <manager>
- **MCP servers:** <servers>
- **Plugins:** <plugins>
- **CLI tools:** <tools discovered from project docs>
- **Custom skills:** <skills discovered>
```

Use `AskUserQuestion`: "Does this look correct? Should I update PROJECT.md with these details?"

Options:
- "Yes, update PROJECT.md"
- "Edit first — I'll make corrections"
- "Skip — leave PROJECT.md unchanged"

If "Edit first", ask follow-up questions about what to change.

### Step 7: Exit Plan Mode

Call `ExitPlanMode`. Steps below write to `.planning/` files.

### Step 8: Write State Files

If user confirmed:

1. **Update PROJECT.md** — Fill Stack section with confirmed values. Only fill template placeholders (empty `**Language:**`, `**Framework:**`, `**Key dependencies:**`). If a field already has user-edited content, leave it unchanged.

2. **Seed CONTEXT.md ## Architecture** — If the Architecture section still contains the `(none yet)` placeholder, seed detected entries (e.g., ruff config, mypy strict, Makefile targets) such as:
   - "Linting via ruff (configured in pyproject.toml)"
   - "Strict type checking via mypy"
   - "CI via GitHub Actions"
   Otherwise skip.

3. **Seed CONTEXT.md ## Tooling** — If the Tooling section still contains the `(none yet)` placeholder, seed detected MCP servers, plugins, and CLI tools such as:
   - "MCP servers: context7, filesystem"
   - "Plugins: pyright-lsp (type checking)"
   - "CLI tools: gh (GitHub), docker"
   Include CLI tools discovered by subagent. Otherwise skip.

4. **Seed CONTEXT.md ## Skills** — If the Skills section still contains the `(none yet)` placeholder, seed detected custom skills such as:
   - "backend-dev-guidelines: Guidelines on hono routing in backend API"
   - "ci-debugger: Custom skill for debugging CI failures"
   - "frontend-design: Custom skill on building production-grade frontend interfaces"
   Otherwise skip.

5. **Seed CONTEXT.md ## Commands** — If the Commands section still contains the `(none yet)` placeholder, seed detected dev commands. Format: backtick-wrapped command + dash + brief purpose:
   - `` `make test` — run pytest suite ``
   - `` `npm run dev` — start dev server on port 3000 ``
   Otherwise skip.

6. **Seed CONTEXT.md ## Gotchas** — If the Gotchas section still contains the `(none yet)` placeholder, seed detected non-obvious patterns such as:
   - "Tests must run sequentially due to shared DB state"
   - "`yarn.lock` authoritative; delete `node_modules` if deps mismatch"
   Generic advice must not be seeded. Otherwise skip.

For all sections above: only add if section is still a placeholder — user-edited content must be left unchanged.

> Refer to [references/seeding-guidelines.md](references/seeding-guidelines.md) for what TO/NOT seed. Key principle: only seed info that would genuinely help a fresh agent session. Duplicate CLAUDE.md content is out of scope — reference it instead.

If user chose "Skip", leave all state files unchanged.

### Step 9: Quality Evaluation

If seeding performed in Step 8 (skip if user chose "Skip" in Step 6):

1. Read `.planning/CONTEXT.md` after seeding
2. Score each dimension per [references/quality-criteria.md](references/quality-criteria.md):
   - Architecture Clarity (0-25), Commands/Workflows (0-25), Non-Obvious Patterns (0-25), Actionability (0-25)
3. Calculate total, assign grade (A: 90-100, B: 70-89, C: 50-69, D: 30-49, F: 0-29)
4. Present report:

```
## CONTEXT.md Quality: XX/100 (Grade: X)

| Dimension | Score | Notes |
|-----------|-------|-------|
| Architecture Clarity | X/25 | ... |
| Commands/Workflows | X/25 | ... |
| Non-Obvious Patterns | X/25 | ... |
| Actionability | X/25 | ... |

Sections with placeholders remaining: X/5
```

5. If score < 50: suggest user manually enrich CONTEXT.md later

### Step 10: Onboarding Summary

Print:

```
## GSD-Lean Initialized

Project is ready for the 5-phase development workflow:

1. `/gsd-lean:discuss` — Research and capture requirements
2. `/gsd-lean:plan` — Decompose into structured tasks
3. `/gsd-lean:execute` — Implement tasks with auto-verification
4. `/gsd-lean:verify` — Run project checks
5. `/gsd-lean:complete` — Summarize and wrap up

**Next step:** Run `/gsd-lean:discuss <feature description>` to start the first workflow.
```
