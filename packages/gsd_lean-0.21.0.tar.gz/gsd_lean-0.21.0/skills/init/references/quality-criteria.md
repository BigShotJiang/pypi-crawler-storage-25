# CONTEXT.md Quality Criteria

> Adapted from `/claude-md-improver` rubric. Evaluates seeded `.planning/CONTEXT.md` across 4 dimensions (25 pts each, 100 total).

## Scoring Rubric

### 1. Architecture Clarity (25 points)

**25**: Clear codebase map — entry points identified, module relationships documented, key data flow described; not just directory listing
**20**: Good structure, minor gaps (e.g., data flow missing)
**15**: Entry points + directories but no relationships
**10**: Basic directory listing only
**5**: Vague or incomplete
**0**: `(none yet)` placeholder or empty

### 2. Commands/Workflows (25 points)

**25**: All essential dev commands documented — build, test, lint, deploy present; copy-paste ready (backtick-wrapped, with flags); brief purpose each; common failure modes noted where relevant
**20**: Most commands present, some missing context/flags
**15**: Key commands present but not copy-paste ready
**10**: Basic commands only, no workflow context
**5**: Few commands, many missing
**0**: `(none yet)` placeholder or empty

### 3. Non-Obvious Patterns (25 points)

**25**: Gotchas and quirks captured — ordering dependencies, shared state/test isolation, env vars required at build/test time, "why we do it this way" for unusual patterns, workarounds for known issues
**20**: Most gotchas captured, minor omissions
**15**: Some patterns documented
**10**: One or two gotchas only
**5**: Minimal, generic advice
**0**: `(none yet)` placeholder or empty

### 4. Actionability (25 points)

**25**: Content is project-specific and executable — no `(none yet)` placeholders, every entry project-specific, commands reference real scripts/targets, fresh agent session would find this immediately useful
**20**: Mostly actionable, one or two generic entries
**15**: Mix of actionable and placeholder content
**10**: Mostly generic advice
**5**: Mostly placeholders
**0**: All sections still `(none yet)`

## Grading Scale

| Grade | Score | Interpretation |
|-------|-------|----------------|
| A | 90-100 | Excellent — rich, project-specific context |
| B | 70-89 | Good — useful but has gaps |
| C | 50-69 | Adequate — basics present, needs enrichment |
| D | 30-49 | Poor — mostly placeholders or generic |
| F | 0-29 | Insufficient — no meaningful content seeded |

## Assessment Process

1. Read `.planning/CONTEXT.md` after seeding
2. Score each dimension using rubric above
3. Calculate total and assign grade
4. List specific issues found
5. If score < 50: suggest user manually enrich CONTEXT.md

## Red Flags

- `(none yet)` placeholders still present after seeding
- Generic advice not specific to project ("write tests", "use meaningful names")
- Commands referencing nonexistent scripts or targets
- Obvious-from-code info restated (class names, directory purposes clear from naming)
- Info already in CLAUDE.md duplicated instead of referenced
- Verbose explanations where one-liners suffice
