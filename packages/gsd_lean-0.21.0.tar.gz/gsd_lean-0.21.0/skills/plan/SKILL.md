---
description: This skill should be used when the user runs "/gsd-lean:plan" or asks to "create a plan", "decompose requirements into tasks", or "generate PLAN.md". Also used from the execute phase to update an existing plan with new information or encountered issues. Decomposes requirements into structured tasks, writes cycle/PLAN.md, and verifies it passes review.
argument-hint: [additional planning context or update details]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(uvx gsd-lean:*), Bash(git:*), Agent, LSP, EnterPlanMode, ExitPlanMode
disable-model-invocation: true
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`

## Instructions

Run **plan phase** of GSD-Lean's development workflow.

## Contract

Execute every step in order. You MUST NOT skip Step 2 (PlanMode entry), Step 3 (file reads), Step 7 (plan-review spawn) — regardless of task size. No exceptions for "trivial" or "obvious" changes.

If a step names a file, read it. If a step names a subagent, spawn it. If a step names a verification gate, run it.

You are a protocol executor, not a judge of which steps apply.

### Step 1: Transition Phase

Run:
```
uvx gsd-lean transition plan --path .
```

If this fails with a precondition error, direct user to run `/gsd-lean:discuss` first.

### Step 1.5: Detect Mode

Check if `.planning/cycle/PLAN.md` exists and its Status header is `in-progress`. If both are true, follow **[Update Mode](#update-mode)** below. Otherwise continue with Step 2.

---

## Update Mode

Use when returning from execute phase to revise existing PLAN.md. `$ARGUMENTS` must describe what changed — new information affecting tasks, or encountered issues to document. If empty, ask user before proceeding.

### U-1: Read Existing Plan

Call `EnterPlanMode`. Read `.planning/cycle/PLAN.md`, `.planning/cycle/DECISIONS.md`, `.planning/cycle/REQUIREMENTS.md`.

### U-2: Apply Updates

**New information** — user describes new insights, changed requirements, or missing details:
- Modify relevant task(s) in both summary table and Task Details sections
- Update Description, Files, and/or Verification fields as needed
- Add new tasks if required (use next available T-NNN ID)
- Preserve all existing task statuses (`done`, `in-progress`, etc.) — only modify content, not progress

**Encountered issues** — user describes execution problems and resolutions:
- Append `## Encountered Issues` section at bottom of PLAN.md (or add to existing)
- Each issue: subsection with **Problem** and **Fix** descriptions

### U-3: Set Status to Draft

Call `ExitPlanMode`. Update PLAN.md Status header from `in-progress` to `draft`.

### U-4: Continue to Verification

Read `.planning/config.yaml` if it exists; resolve `model` for `skills.plan.subagents.plan-review` (fallback to `defaults`, then omit). Skip to [Step 7](#step-7-verify-plan).

---

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. Task decomposition happens in plan mode (read-only). Exit before writing PLAN.md.

### Step 3: Read Inputs

Read:
- `.planning/cycle/REQUIREMENTS.md` — User Intent, Goals, Non-Goals, Functional Requirements, Affected Files, Key Interfaces, Edge Cases, Testing Strategy, Non-Functional Requirements
- `.planning/cycle/DECISIONS.md` — Style & Preferences, Constraints, Dependencies
- `.planning/PROJECT.md` — filter constraints for `[plan]`-tagged + untagged items; read all notes
- `.planning/CONTEXT.md` — static architecture, tooling, skills context (persists across cycles)

### Step 4: Decompose Into Tasks

If `$ARGUMENTS` provided, treat as extra planning context (scope constraints, priority hints, focus areas).

Break requirements into discrete, committable tasks. For each task:
- **ID:** `T-NNN` (zero-padded 3 digits)
- **Wave:** integer for execution ordering
- **Title:** short imperative description
- **Files:** which files are created/modified
- **Verification:** specific, runnable criteria (test commands, lint checks, manual checks)
- **Dependencies:** which T-NNN tasks must complete first (or "none")

Guidelines:
- Each task touches at most ~5 files (split larger tasks)
- Wave 1 = foundational (modules, types, core logic); Wave 2 = features on wave 1; Wave 3 = skills, docs, polish
- **Tracer bullet:** Identify thinnest end-to-end slice through all system layers — production code, not a prototype. Create 1–3 tasks for this slice, prefix titles with `[tracer]`, assign wave 1, lowest T-NNN IDs. If feature is single-layered or too small, skip tracer and note why.
- Every requirement maps to at least one task; every decision respected in task design
- Every `[plan]`-tagged or untagged PROJECT.md constraint reflected in task design
- Every goal maps to at least one task; exclude Non-Goals from task scope
- Affected Files informs Files column; Testing Strategy informs verification; Edge Cases covered by tasks or verification

#### Affected Files Discovery

Before finalizing tasks, identify ALL files each task will touch. Run `findReferences` via LSP on key exported symbols (classes, functions, types) in each modified source file — reveals test files, downstream consumers, re-export files.

Supplement with this checklist:

1. **Test files** — `src/foo.py` → `tests/test_foo.py`, `src/foo.ts` → `src/foo.test.ts`, `src/foo.rs` → `tests/foo_test.rs`. Add if exists; add "create" entry if tests required but missing.
2. **Config files** — `pyproject.toml`, `package.json`, `Cargo.toml`, `Makefile`, `mise.toml`, etc. Add if affected.
3. **CI files** — New test matrix, lint rule, or build step? Add `.github/workflows/ci.yml`.
4. **Documentation** — `CLAUDE.md`, `PROJECT_KNOWLEDGE.md`, `README.md`, docstrings need updates? Add them.
5. **Init/export files** — `__init__.py`, `index.ts`, `mod.rs` need new exports? Add them.

Cross-reference REQUIREMENTS.md "Affected Files" table and "Testing Strategy" — every file listed there must appear in at least one task.

### Step 5: Exit Plan Mode

Call `ExitPlanMode`. Following steps write PLAN.md and run verification.

### Step 6: Write PLAN.md

Write `.planning/cycle/PLAN.md` using this exact format:

````markdown
# Plan

> **Status:** draft
> **Created:** <ISO 8601 UTC timestamp>
> **Waves:** <total wave count>
> **Source:** cycle/REQUIREMENTS.md

## Context

> This section enables zero-context handoff to `/execute`. A fresh session reads this + CLAUDE.md + PROJECT.md + CONTEXT.md.

**What:** <1-2 sentence summary of what's being built, from REQUIREMENTS.md User Intent>

**Why:** <1 sentence motivation, from REQUIREMENTS.md Motivation>

**Key decisions:**
- <Decision 1 from DECISIONS.md that affects implementation — one line with rationale>
- <Decision 2...>

**Critical files to understand:**
- `path/to/key/file` — <why it matters>
- `path/to/another/file` — <why it matters>

## Tasks

| ID | Wave | Status | Title | Files | Verification |
|----|------|--------|-------|-------|-------------|
| T-001 | 1 | pending | [tracer] <minimal end-to-end title> | `<file1>`, `<file2>` | <brief verification> |
| T-002 | 1 | pending | <title> | `<file>` | <brief verification> |
| T-003 | 2 | pending | <title> | `<file>` | <brief verification> |

## Task Details

### T-001: [tracer] <minimal end-to-end title>

**Description:** <1-3 sentences explaining what this task does. Include: approach notes (which patterns to follow, which existing code to reference via `path/to/file`), and any relevant decisions from DECISIONS.md that affect implementation.>

**Files:**
- `path/to/file` (create | modify)

**Verification:**
- [ ] <specific check, e.g. "unit tests in tests/test_foo.py pass">
- [ ] <specific check, e.g. "mypy src/module/ clean">

**Dependencies:** none

---

### T-002: <title>

**Description:** <1-3 sentences. Include approach notes: patterns to follow, existing code to reference (`path/to/file`), relevant decisions from DECISIONS.md.>

**Files:**
- `path/to/file` (modify)

**Verification:**
- [ ] ...

**Dependencies:** T-001

---
````

Important:
- Status header MUST be `draft` initially
- Every task in summary table MUST have a corresponding Task Details section
- Task IDs must be sequential and zero-padded to 3 digits
- Status values: `pending`, `in-progress`, `done`, `blocked`
- Files column uses backtick-wrapped paths, comma-separated

### Step 6.5: Read Subagent Config

Read `.planning/config.yaml` if it exists; resolve `model` for `skills.plan.subagents.plan-review` (fallback to `defaults` section, then omit).

### Step 7: Verify Plan

Spawn `subagent_type=gsd-lean:plan-review`. Pass resolved model if set. Prompt: "Review the plan for completeness, correctness, and requirement coverage."

### Step 8: Handle Review Result

**If PASS:** Update Status from `draft` to `verified`. Print: "Plan verified. {N} tasks across {W} waves. Run `/gsd-lean:execute` when ready."

**If FAIL:** Print issues, revise cycle/PLAN.md, re-run verification. If second review fails: print issues and ask user to resolve. If passes: update Status to `verified`. Maximum 1 revision loop (2 total attempts).

Step 1 transition already updated STATE.md. No further updates needed.
