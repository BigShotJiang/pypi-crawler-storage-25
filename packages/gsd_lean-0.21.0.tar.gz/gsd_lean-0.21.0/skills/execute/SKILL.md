---
description: This skill should be used when the user asks to "execute a task", "run the next task", "implement the plan", or runs /gsd-lean:execute. Spawns executor subagent, verifies, auto-debugs on failure, and commits.
argument-hint: ["task ID(s) to execute, e.g. 'T-003' or 'T-001 T-003'"]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash, Agent, LSP
disable-model-invocation: true
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Plan:** !`uvx gsd-lean plan-status --path . 2>/dev/null || echo "No plan"`

## Instructions

Execute phase of GSD-Lean. Pick next task, implement via subagent, verify, auto-debug if needed, commit.

## Contract

Execute every step in order. You MUST NOT skip Step 4 (file reads), Step 6 (executor spawn), Steps 8–10 (spec-review, code-quality-review, verify-execute chain), Step 12 (auto-debug on failure) — regardless of task size. No exceptions for "trivial" or "obvious" changes.

If a step names a file, read it. If a step names a subagent, spawn it. If a step names a verification gate, run it.

You are a protocol executor, not a judge of which steps apply.

### Step 1: Ensure Execute Phase

**Branch guard:** Run `git rev-parse --abbrev-ref HEAD`. If current branch equals repo's default branch (e.g. `main`), **stop immediately** and tell user:
> You are on the default branch. Create a feature branch before running /gsd-lean:execute.

Leave branch creation to the user so they can choose the branch name.

Read `.planning/STATE.md`. If not in `execute` phase, run:
```
uvx gsd-lean transition execute --path .
```
If this fails (plan not verified), tell user to run `/gsd-lean:plan` first.

### Step 2: Identify Target Task

**Build target set from arguments:**
1. Extract all task IDs matching `T-\d{3}` from $ARGUMENTS
2. If IDs found → build **target set**:
   - Read Task Details for each task in target set
   - Check **Dependencies:** field; add any dep task IDs whose status is not `done`
   - Repeat expansion transitively until no new tasks added
   - Print which tasks are in target set (including auto-added deps)
3. If no IDs in $ARGUMENTS → no target set (execute all pending tasks as before)

**Select next task:**
- If target set exists:
  1. Check for `in-progress` task within target set
  2. Else find first `pending` task in target set (wave order, then ID order)
- If no target set:
  1. Check for `in-progress` task in cycle/PLAN.md
  2. Else find first `pending` task in wave order

If no task available:
- Target set → "All specified tasks complete: {IDs}." Stop.
- No target set → "All tasks complete. Run `/gsd-lean:complete`." Stop.

### Step 3: Update Task Status

If task is `pending`, update its status to `in-progress` in cycle/PLAN.md summary table.
If this is the first task being executed (plan status is `verified`), update plan Status header to `in-progress`.

### Step 4: Read Task Details

Read Task Details for target task in `.planning/cycle/PLAN.md`. Extract Description, Files, Verification, Dependencies.

Also read: `CLAUDE.md`, `.planning/PROJECT.md` (constraints: `[execute]`-tagged + untagged), `.planning/CONTEXT.md`.

### Step 5: Read Subagent Config

Read `.planning/config.yaml` if it exists. Resolve `model` for each subagent from `skills.execute.subagents.<name>`, fallback to `defaults`, else omit (inherit from session).

| Subagent | Config key |
|----------|------------|
| executor | `skills.execute.subagents.executor` |
| spec-review | `skills.execute.subagents.spec-review` |
| code-quality-review | `skills.execute.subagents.code-quality-review` |
| auto-debug | `skills.execute.subagents.auto-debug` |
| verify-execute | `skills.execute.subagents.verify-execute` |

### Step 6: Spawn Executor Subagent

Spawn `gsd-lean:executor` via Agent tool; pass `model` from resolved config for `skills.execute.subagents.executor` if set.

Pass the following as the prompt (dynamic task context only):

**Task:** {task_id}: {task_title}

**Description:** {task_description}

**Files to create/modify:**
{files_list}

**Verification criteria:**
{verification_checklist}

### Step 7: Collect Changed Files

Parse executor output for list of changed files. Store as `{changed_files}` — passed to verify subagent to stage only these files (not unrelated user changes).

### Step 8: Spec Review

Spawn `gsd-lean:spec-review` via Agent tool; pass `model` from resolved config for `skills.execute.subagents.spec-review` if set.

Pass the following as the prompt (dynamic task context only):

**Task:** {task_id}: {task_title}

**Task description:** {task_description}

**Verification criteria:**
{verification_checklist}

**Files changed during implementation:**
{changed_files}

**Executor summary:** {brief summary extracted from executor output}

Parse `**Overall:` line for PASS/FAIL. Missing/ambiguous → treat as FAIL.

**If FAIL:** Capture issue table → Step 12 (Auto-Debug).

### Step 9: Code Quality Review

Only runs if spec-review passed.

Spawn `gsd-lean:code-quality-review` via Agent tool; pass `model` from resolved config for `skills.execute.subagents.code-quality-review` if set.

Pass the following as the prompt (dynamic task context only):

**Task:** {task_id}: {task_title}

**Files changed during implementation:**
{changed_files}

**Spec review result:** PASSED

Parse `**Overall:` line for PASS/FAIL. Missing/ambiguous → treat as FAIL.

**If FAIL:** Capture issue table → Step 12 (Auto-Debug).

### Step 10: Mechanical Verify

After both semantic reviews pass.

Spawn `gsd-lean:verify-execute` via Agent tool; pass `model` from resolved config for `skills.execute.subagents.verify-execute` if set.

Pass the following as the prompt (dynamic task context only):

**Task:** {task_id}: {task_title}

**Files changed during implementation:**
{changed_files}

**Verification criteria:**
{verification_checklist}

Parse `**Overall:` line for PASS/FAIL. Missing/ambiguous → treat as FAIL.

### Step 11: Handle Verification Result

**If PASS:**
1. Parse verify subagent output. Confirm it includes "Plan Updated" and a commit hash (or "nothing to commit").
2. If subagent failed to update PLAN.md or commit, fall back:
   - Update task status to `done` in `cycle/PLAN.md` summary table
   - Tick all `- [ ]` to `- [x]` in Task Details section for this task
   - Stage only files listed in {changed_files}, then commit with conventional message and footer
3. Go to Step 13

**If FAIL:**
1. Capture error output from verify subagent
2. Identify files touched by executor subagent
3. Delegate fixes to auto-debug subagent — proceed to Step 12.

### Step 12: Auto-Debug

Spawn `gsd-lean:auto-debug` via Agent tool; pass `model` from resolved config for `skills.execute.subagents.auto-debug` if set.

Pass the following as the prompt (dynamic task context only):

**Task:** {task_id}: {task_title}

**Original task description:** {task_description}

**Verification error output:**
{error_output}

**Files touched by the implementation:**
{touched_files}

After auto-debug subagent completes, merge its modified files into `{changed_files}`, then re-run from **Step 8** (spec-review). This ensures both semantic reviews re-run after any fix.

**If PASS (all three stages):** Go to Step 11 (PASS path).

**If still FAIL after one full auto-debug cycle:**
1. Report diagnosis: root cause + what was tried + remaining errors
2. Task stays `in-progress`
3. Ask user: "Auto-debug failed. Would you like to fix manually, skip this task, or retry?"
4. Stop the loop — await user guidance before continuing

### Step 13: Check for More Tasks

**If target set was defined:**
1. Check if any tasks in target set still `pending` or `in-progress`
2. If yes → print "Task {task_id} complete. {remaining} target tasks remaining. Continuing..." → loop to Step 2
3. If no → print "All specified tasks complete: {IDs}." → proceed to **Plan completion check** below

**If no target set:**
1. Check for more `pending` tasks in cycle/PLAN.md
2. If yes → print "Task {task_id} complete. {remaining} tasks remaining. Continuing..." → loop to Step 2
3. If no → proceed to **Plan completion check** below

**Plan completion check:**
1. Read `.planning/cycle/PLAN.md`. Check summary table: are ALL tasks in `done` status?
2. If yes → update Status header in `.planning/cycle/PLAN.md`: find `> **Status:** in-progress` and change to `> **Status:** complete`. Print "All tasks complete. Run `/gsd-lean:complete` to finish the workflow." Stop.
3. If no → Stop (remaining tasks exist for future execution).
