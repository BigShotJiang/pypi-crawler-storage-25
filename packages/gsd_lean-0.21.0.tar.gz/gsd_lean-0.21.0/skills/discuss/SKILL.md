---
description: This skill should be used when the user asks to "discuss a feature", "research requirements", "probe preferences", or runs /gsd-lean:discuss. Runs enriched discuss phase — research, probe preferences, populate requirements and decisions.
argument-hint: [feature or change description]
allowed-tools: Read, Write, Edit, Glob, Grep, Bash(uvx gsd-lean:*), Bash(git:*), Agent, WebSearch, WebFetch, LSP, EnterPlanMode, ExitPlanMode, mcp__context7__resolve-library-id, mcp__context7__query-docs
disable-model-invocation: true
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Project:** !`head -1 .planning/PROJECT.md 2>/dev/null || echo "Not initialized"`

## Instructions

**Discuss phase** of GSD-Lean. Goal: understand what user wants, explore codebase, research externally, probe preferences, capture in cycle/REQUIREMENTS.md + cycle/DECISIONS.md. Documents must be **self-contained** — `/plan` reads only these + PROJECT.md + CONTEXT.md.

## Contract

Execute every step in order. You MUST NOT skip Step 2 (PlanMode entry), Step 3 (file reads), Step 5 (three research subagents in parallel), Step 9 (verify-discuss spawn) — regardless of task size. No exceptions for "trivial" or "obvious" changes.

If a step names a file, read it. If a step names a subagent, spawn it. If a step names a verification gate, run it.

You are a protocol executor, not a judge of which steps apply.

### Step 1: Verify Phase

Read `.planning/STATE.md`. If not in `discuss` phase, run:
```
uvx gsd-lean transition discuss --path . --force
```

### Step 2: Enter Plan Mode

Call `EnterPlanMode`. All exploration, research, and user probing happens in plan mode (read-only). No writes.

> `EnterPlanMode` is a read-only research bracket — unrelated to GSD-Lean's `/plan` phase.
>
> Scope while in EnterPlanMode: exploration, research, and user probing only — design happens in /plan

### Step 3: Read Existing State

Read:
- `.planning/PROJECT.md` — constraints (`[discuss]`-tagged + untagged), notes
- `.planning/CONTEXT.md` — architecture, tooling, skills context
- `.planning/cycle/REQUIREMENTS.md` — template to populate
- `.planning/cycle/DECISIONS.md` — template to populate
- `CLAUDE.md` — dev commands, code style, conventions
- `PROJECT_KNOWLEDGE.md` if exists
- `README.md` if exists

Static docs persist across cycles — reference, don't modify. Cycle docs are fresh templates.

### Step 4: Read Subagent Config

Read `.planning/config.yaml` if it exists. Resolve `model` per subagent from `skills.discuss.subagents.<name>`, fall back to `defaults`, else omit:

| Subagent | Config key |
|----------|------------|
| codebase-explore | `skills.discuss.subagents.codebase-explore` |
| domain-research | `skills.discuss.subagents.domain-research` |
| technical-research | `skills.discuss.subagents.technical-research` |
| verify-discuss | `skills.discuss.subagents.verify-discuss` |

### Step 5: Spawn Research Subagents (Parallel)

Spawn all three in one message (three parallel Agent tool calls):

1. Spawn `subagent_type=gsd-lean:codebase-explore`. Pass `model` from config if set.
   Prompt: **Feature:** {feature_description from $ARGUMENTS}

2. Spawn `subagent_type=gsd-lean:domain-research`. Pass `model` from config if set.
   Prompt: **Feature:** {feature_description from $ARGUMENTS}

3. Spawn `subagent_type=gsd-lean:technical-research`. Pass `model` from config if set.
   Prompt: **Feature:** {feature_description from $ARGUMENTS}

### Step 5b: Merge Research Outputs

Combine findings from all three subagents. Ground domain/technical findings in codebase structure. Flag conflicts between existing patterns and best practices for Step 6.

If subagents failed, use output from successful ones. If all failed, proceed with Step 3 context only.

### Step 6: Probe User Preferences

Use `AskUserQuestion` with specific options (not open-ended). 2-4 questions per round. Cover: architecture, error handling, testing, naming, constraints, scope.

### Step 7: Exit Plan Mode

Call `ExitPlanMode`. Following steps write to `.planning/` files.

> Scope after ExitPlanMode: write discuss-phase documents only — user approval of ExitPlanMode does not authorize moving to the next workflow phase

### Step 8: Update State Files

Merge research findings + user answers into sections below. Replace template placeholders with real content. If section can't be fully populated, use `(to be determined during /plan)` only for Affected Files — all other sections must have substantive content.

**`.planning/cycle/REQUIREMENTS.md`** — update these 10 sections:

1. **User Intent** — 1-2 paragraph summary of what + why
2. **Motivation** — why this change is needed, link to issues/PRDs if relevant
3. **Goals** — bulleted list of what this aims to achieve
4. **Non-Goals** — explicit out-of-scope items (prevents scope creep in /plan)
5. **Functional Requirements** — detailed feature requirements
6. **Affected Files** — table of files to create/modify with descriptions
7. **Key Interfaces** — proposed function signatures, class definitions, API contracts
8. **Edge Cases & Error Handling** — numbered list of edge cases + handling
9. **Testing Strategy** — test files, test cases, coverage notes
10. **Non-Functional Requirements** — performance, security, backwards compatibility

**`.planning/cycle/DECISIONS.md`** — update these 3 sections:

1. **Style & Preferences** — code style, naming, pattern preferences
2. **Constraints** — limits, backwards compatibility, API surface
3. **Dependencies** — new packages/tools needed; if none, state "None"

Each decision needs a one-line rationale.

> Architecture, Tooling, and Skills context lives in `.planning/CONTEXT.md` (static, persists across cycles). Keep cycle/DECISIONS.md focused on cycle-specific choices only.

### Step 9: Verify Documents

Spawn `subagent_type=gsd-lean:verify-discuss`. Pass `model` from config if set.

Pass the prompt: "Verify discuss phase output."

**If PASS:** proceed to Step 10.

**If FAIL:** fix issues and re-verify (max 1 retry). If second attempt fails, print issues and ask user to resolve manually.

### Step 10: Summary

Print summary:
- Key requirements (bulleted)
- Key decisions (bulleted)
- Gaps or open questions

Then suggest: "Requirements and decisions captured. Run `/gsd-lean:plan` when ready to generate a plan."

Scope after summary: wait for user's next command — the discuss phase is complete.
