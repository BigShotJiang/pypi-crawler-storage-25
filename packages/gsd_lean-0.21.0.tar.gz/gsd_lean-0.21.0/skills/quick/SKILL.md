---
description: This skill should be used when the user wants to execute a small, well-scoped task with verification and auto-commit — bypasses the full GSD-Lean cycle. Use when the user runs /quick with a task description.
argument-hint: "task description, e.g. 'fix null check in parse_config'"
disable-model-invocation: true
allowed-tools: Read, Glob, Grep, Bash, Agent, EnterPlanMode, ExitPlanMode
---

## Instructions

Run `/quick` — lightweight, stateless execution. Implement small task, verify (lint + typecheck + tests), auto-commit on pass. No `.planning/` state writes — traceability via git history only.

## Contract

Execute every step in order. You MUST NOT skip Step 4 (PlanMode + file reads), Step 5 (quick-executor spawn), Step 9 (auto-debug on failure) — regardless of task size. No exceptions for "trivial" or "obvious" changes.

If a step names a file, read it. If a step names a subagent, spawn it. If a step names a verification gate, run it.

You are a protocol executor, not a judge of which steps apply.

### Step 1: Validate Task Description

Check `$ARGUMENTS`. If empty or vague (e.g. "clean up code", "fix stuff"), stop and ask:
> Please provide a concrete task description. Example: `/quick "fix null check in parse_config"`

### Step 2: Check for Active Cycle (Advisory)

Run:
```
uvx gsd-lean status --path . 2>/dev/null
```

If current phase is `execute` or `verify`, print advisory (proceed regardless):
> **Advisory:** A full cycle is active (phase: {phase}). `/quick` runs independently — changes won't be tracked in the cycle. Proceeding...

### Step 3: Check for Uncommitted Changes (Advisory)

Run `git status --porcelain`. If uncommitted changes exist, warn (proceed regardless):
> **Advisory:** Your working tree has uncommitted changes. These may be included in the auto-commit. Proceeding...

### Step 4: Plan (PlanMode)

Enter PlanMode. Perform the following reads and exploration, then exit PlanMode. Store the result as `{implementation_plan}`.

- Read `CLAUDE.md` — dev commands, code style, conventions. Skip if absent.
- Read `.planning/PROJECT.md` — stack, constraints (apply `[execute]`-tagged + untagged), notes. Skip if absent.
- Read `.planning/CONTEXT.md` — architecture, tooling, skills context. Skip if absent.
- Explore codebase: use LSP tools (`goToDefinition`, `findReferences`) when the symbol is known; fall back to Grep for free-text search when no symbol is available.
- Formulate concise plan: affected files, changes needed, applicable constraints.

### Step 5: Spawn Quick-Executor Subagent

Spawn `subagent_type=gsd-lean:quick-executor` via Agent tool.

Pass the following as the prompt:

**Task:** $ARGUMENTS

**Implementation plan:**
{implementation_plan}

### Step 6: Count Files Changed (Advisory)

Parse executor output for changed files. If 4 or more, print advisory (proceed regardless — continue to verification):
> **Advisory:** This task touched {N} files. For changes of this scope, consider using the full cycle (`/discuss`) for better traceability. Continuing with verification...

Store changed files as `{changed_files}`.

### Step 7: Discover Verification Commands

Read project config to determine checks: `CLAUDE.md` (lint, format, typecheck, test commands), then first match per category from: `Makefile`, `package.json`, `.pre-commit-config.yaml` (lint/format); `tsconfig.json`, `pyproject.toml` (typecheck/mypy/pyright); `pytest.ini`, `Cargo.toml` (tests). If no commands found, ask user.

### Step 8: Run Verification

Run each discovered check sequentially. Report **PASS** or **FAIL** with file paths and error details.

**If all checks PASS:** Go to Step 10 (auto-commit).

**If any check FAILS:** Capture full error output as `{error_output}` and go to Step 9.

### Step 9: Auto-Debug (One Attempt)

Only reached on verification FAIL. Spawn exactly one auto-debug round.

Spawn `subagent_type=gsd-lean:auto-debug` via Agent tool.

Pass the following as the prompt:

**Task:** $ARGUMENTS

**Verification error output:**
{error_output}

**Files touched by the implementation:**
{changed_files}

After subagent completes, merge newly modified files into `{changed_files}`, then re-run verification (Step 8) once.

**If re-verification PASS:** Go to Step 10 (auto-commit).

**If re-verification still FAIL:**
1. Report:
   ```
   ## Quick: FAILED

   Auto-debug did not resolve all errors. Halting — no commit made.

   **Remaining errors:**
   {error_output}

   Fix the issues manually and re-run `/quick` or commit with `/gsd-lean:commit`.
   ```
2. Stop. Commit is skipped.

### Step 10: Auto-Commit

Stage only files modified by executor and auto-debug subagents. Stage only non-sensitive files; if any `.env`/credential path is detected, warn the user and stop.

Create commit following conventional commit style. Keep message concise (1-2 sentences). Use `git log --oneline -5` as style reference.

End commit message with:

```
[Generated with Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <model-revision> <noreply@anthropic.com>
```

Replace `<model-revision>` with the current session model name (e.g. `Sonnet 4.6`). Then print:

```
## Quick: DONE

Task complete. Committed: {commit_hash}
```
