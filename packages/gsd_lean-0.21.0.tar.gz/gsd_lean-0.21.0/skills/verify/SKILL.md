---
description: This skill should be used when the user asks to "verify a task", "run verification", "check task criteria", "validate task", or wants to confirm a task passes its checks and project-level linting/tests.
argument-hint: ["task ID, e.g. T-003"]
allowed-tools: Read, Glob, Grep, Bash
disable-model-invocation: true
---

## Current State

**Phase:** !`uvx gsd-lean status --path . 2>/dev/null | grep -A1 "Current Phase" | tail -1 | tr -d '\140'`
**Plan:** !`uvx gsd-lean plan-status --path . 2>/dev/null || echo "No plan"`

## Instructions

Run **verify phase** of GSD-Lean workflow. Confirm current (or specified) task meets verification criteria and passes project-level checks.

## Contract

Execute every step in order. You MUST NOT skip Step 2 (read verification criteria), Step 3 (discover commands from config files) — regardless of task size. No exceptions for "trivial" or "obvious" changes.

If a step names a file, read it. If a step names a verification gate, run it.

You are a protocol executor, not a judge of which steps apply.

### Step 1: Identify Target Task

If $ARGUMENTS contains a task ID (e.g. `T-003`), verify that task. Otherwise find task with status `in-progress` in `.planning/cycle/PLAN.md`. If none in-progress, report and stop.

### Step 2: Read Verification Criteria

Read Task Details section for target task in `.planning/cycle/PLAN.md`. Extract **Verification** checklist items.

Read `.planning/PROJECT.md` → `## Constraints` (tags `[verify]` or untagged) and `## Notes` — use as context when evaluating implementation.

### Step 3: Discover Verification Commands

Read project config to determine checks: `CLAUDE.md` (lint, format, typecheck, test commands), then first match per category from: `Makefile`, `package.json`, `.pre-commit-config.yaml` (lint/format); `tsconfig.json`, `pyproject.toml` (typecheck); `pytest.ini`, `Cargo.toml` (tests). If no commands found, ask user.

### Step 4: Run Verification

Run each discovered check sequentially. Report **PASS** or **FAIL** with file paths and error details.

For each verification checklist item, map to the run check that covers it. Mark PASS, FAIL, or SKIP (state the reason when SKIP). Every checklist item must have a disposition.

### Step 5: Report Results

Output:

```
## Verification: T-NNN — <title>

| Check | Result | Details |
|-------|--------|---------|
| <check 1> | PASS/FAIL | <brief detail> |
| <check 2> | PASS/FAIL | <brief detail> |

**Overall: PASS / FAIL (X/Y checks passed)**
```

If all pass: suggest "Task T-NNN verified. Update status to `done` in cycle/PLAN.md and run `/gsd-lean:commit`."
If any fail: list specific errors and suggest fixes.
