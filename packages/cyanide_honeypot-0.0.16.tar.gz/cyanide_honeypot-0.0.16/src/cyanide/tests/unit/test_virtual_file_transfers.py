from unittest.mock import AsyncMock, MagicMock

import pytest

from cyanide.vfs.engine import FakeFilesystem
from cyanide.vfs.rsync import RsyncHandler
from cyanide.vfs.sftp import CyanideSFTPHandler


@pytest.fixture
def mock_session(mock_logger):
    session = MagicMock()
    session.honeypot = MagicMock()
    session.honeypot.config = {
        "ssh": {
            "allow_upload": True,
            "allow_download": True,
            "max_upload_size_mb": 50,
            "max_total_upload_mb_per_session": 200,
        }
    }
    session.honeypot.logger = MagicMock()
    session.honeypot.save_quarantine_file = MagicMock()
    session.fs = FakeFilesystem()
    session.src_ip = "192.168.1.100"
    session.username = "root"
    session.conn_id = "test_conn"
    session.channel = MagicMock()

    conn = MagicMock()
    conn.get_extra_info.return_value = "root"
    session.channel.get_connection.return_value = conn
    conn.cyanide_factory = MagicMock()
    conn.cyanide_factory.honeypot = session.honeypot
    conn.cyanide_factory.fs = session.fs
    conn.cyanide_factory.conn_id = session.conn_id
    conn.cyanide_factory.src_ip = session.src_ip

    return session


@pytest.fixture
def mock_process():
    process = MagicMock()
    process.stdin = AsyncMock()
    process.stdout = MagicMock()
    process.stderr = MagicMock()
    process.channel = MagicMock()
    return process


@pytest.mark.asyncio
async def test_rsync_handshake_and_error(mock_session, mock_process):
    import struct

    mock_process.stdin.read.return_value = struct.pack("<i", 31)

    handler = RsyncHandler(mock_session, process=mock_process)
    rc = await handler.handle("rsync --server . /tmp/test")

    assert rc == 13

    mock_process.channel.write.assert_any_call(struct.pack("<i", 31).decode("latin-1"))

    mock_session.honeypot.logger.log_event.assert_called()


@pytest.mark.asyncio
async def test_sftp_upload_via_handler(mock_session):
    handler = CyanideSFTPHandler(mock_session.channel)
    mock_session.fs.mkdir_p("/tmp")

    import asyncssh

    handle = await handler.open(
        "/tmp/test.txt", asyncssh.FXF_WRITE | asyncssh.FXF_CREAT, asyncssh.SFTPAttrs()
    )
    await handler.write(handle, 0, b"hello sftp/scp")
    await handler.close(handle)

    assert mock_session.fs.exists("/tmp/test.txt")
    assert mock_session.fs.get_content("/tmp/test.txt") == b"hello sftp/scp"

    mock_session.honeypot.save_quarantine_file.assert_called_with(
        "test.txt", b"hello sftp/scp", "conn_test_conn", "192.168.1.100"
    )
