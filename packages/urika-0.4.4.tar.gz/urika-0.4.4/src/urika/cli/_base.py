"""Click group definition for Urika CLI."""

from __future__ import annotations

import sys

import click


def _ensure_utf8_streams() -> None:
    """Reconfigure stdout/stderr to UTF-8 with replacement on Windows.

    The CLI banner, spinners, agent-output framing, and TUI surfaces
    all use box-drawing characters (``╭`` ``─`` ``╮``,
    etc.). On Windows, ``sys.stdout`` defaults to the active console
    code page (typically ``cp1252``), which does not encode those
    glyphs and raises ``UnicodeEncodeError`` on the very first
    ``print``. We reconfigure both streams to UTF-8 with
    ``errors="replace"`` so a stray non-encodable byte degrades to
    ``?`` rather than crashing the CLI.

    No-op on Linux/macOS where stdout is already UTF-8.
    """
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        encoding = (getattr(stream, "encoding", "") or "").lower().replace("-", "")
        if encoding in ("utf8", ""):
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            # If reconfigure fails (e.g. closed stream, frozen
            # interpreter, exotic test harness wrapping), silently
            # leave the stream alone. Box-drawing chars will fall
            # back to ``?`` once we wire that path in cli_display,
            # but the CLI must not refuse to start because of this.
            pass


# Run before Click parses anything so even ``--help`` and version
# output survive a cp1252 console.
_ensure_utf8_streams()


def _is_interactive_stderr() -> bool:
    """Whether the CLI is running attached to a real terminal.

    Returns False under pytest's ``CliRunner`` (which replaces
    ``sys.stderr`` with a ``StringIO`` whose ``isatty()`` returns
    False) and when stderr is piped or redirected. Returns True only
    in real interactive shells.

    Used by the API-key warning gate. Extracted as a top-level helper
    so tests can monkey-patch it cleanly without poking at sys.stderr.
    """
    return bool(getattr(sys.stderr, "isatty", lambda: False)())


def _print_api_key_warning_if_needed(stream, is_interactive: bool) -> None:
    """Print the Anthropic Consumer Terms §3.7 reminder if needed.

    Conditions for printing:
      - ``ANTHROPIC_API_KEY`` is unset, AND
      - ``URIKA_ACK_API_KEY_REQUIRED`` is unset (user hasn't ack'd), AND
      - ``is_interactive`` is True (real TTY — the warning is for humans
        to see, not for log scrapers / JSON parsers / CliRunner.output).

    Suppressing in non-interactive contexts is critical: ``CliRunner``
    mixes stderr into ``result.output`` by default, so without this
    gate every ``--json`` test on a machine without ``ANTHROPIC_API_KEY``
    set fails with a JSON parse error. CI hit this on every push because
    runners don't inherit our keyring; the local dev machine had the
    key set so the breakage was invisible.
    """
    import os

    if (
        os.environ.get("ANTHROPIC_API_KEY")
        or os.environ.get("URIKA_ACK_API_KEY_REQUIRED")
        or not is_interactive
    ):
        return

    stream.write(
        "\n"
        "  \033[33m⚠ ANTHROPIC_API_KEY not set\033[0m\n"
        "\n"
        "  Urika requires an Anthropic API key. Per Anthropic's Consumer\n"
        "  Terms (§3.7) and the April 2026 Agent SDK clarification, a\n"
        "  Claude Pro/Max subscription cannot be used to authenticate the\n"
        "  Claude Agent SDK that Urika depends on.\n"
        "\n"
        "  Get a key:  https://console.anthropic.com (Settings → API Keys)\n"
        "  Save it:    urika config api-key   (interactive)\n"
        "              # or: export ANTHROPIC_API_KEY=sk-ant-...\n"
        "\n"
        "  To silence this warning permanently after acknowledging:\n"
        "    export URIKA_ACK_API_KEY_REQUIRED=1\n"
        "\n"
    )


class _UrikaCLI(click.Group):
    """Custom CLI group that catches UserCancelled + UrikaError globally.

    UrikaError subclasses (ConfigError, AgentError, ValidationError) are
    rendered as a message line plus an optional hint line, then exit 2.
    No traceback for these — they are user-facing by definition. Anything
    else falls through to Click's default handling.
    """

    def invoke(self, ctx: click.Context) -> object:
        try:
            return super().invoke(ctx)
        except SystemExit:
            raise  # Let clean exits through
        except Exception as exc:
            # Catch UserCancelled from any command — exit cleanly. Pre-
            # v0.4.2 used ``type(exc).__name__ == "UserCancelled"``
            # which would match any class anywhere named UserCancelled
            # and brittlely bypassed isinstance for no benefit.
            from urika.cli_helpers import UserCancelled

            if isinstance(exc, UserCancelled):
                raise SystemExit(0)
            # UrikaError — render message + hint without traceback
            from urika.core.errors import UrikaError

            if isinstance(exc, UrikaError):
                from urika.cli_display import print_error

                print_error(str(exc))
                if exc.hint:
                    click.echo(f"  hint: {exc.hint}", err=True)
                # Surface the chained __cause__ when present — pre-v0.4
                # a ConfigError raised "from" a tomllib decode error
                # showed only the friendly message, hiding which line
                # of TOML failed. The cause is one click.echo away.
                cause = exc.__cause__
                if cause is not None:
                    click.echo(
                        f"  caused by: {type(cause).__name__}: {cause}",
                        err=True,
                    )
                raise SystemExit(2)
            raise


@click.group(cls=_UrikaCLI, invoke_without_command=True)
@click.option(
    "--classic",
    is_flag=True,
    hidden=True,
    help="Use classic prompt_toolkit REPL instead of the Textual TUI.",
)
@click.version_option(package_name="urika")
@click.pass_context
def cli(ctx, classic: bool) -> None:
    """Urika: Agentic scientific analysis platform."""
    # Load credentials from ~/.urika/secrets.env
    from urika.core.secrets import load_secrets

    load_secrets()

    # One-shot migration: rewrite stale ``claude-opus-4-7`` pins (a
    # 0.3.0/0.3.1 dashboard default) to ``claude-opus-4-6`` so users
    # with the bundled CLI don't keep hitting "Fatal error in message
    # reader" after upgrading. Idempotent — see ``migrate_settings``.
    from urika.core.settings import migrate_settings

    migrate_settings()

    # One-time compliance reminder: Anthropic Consumer Terms §3.7 + the
    # April 2026 Agent SDK clarification prohibit using a Pro/Max
    # subscription to authenticate the Claude Agent SDK that Urika
    # depends on. We don't block — users may be running in private mode
    # only or have already acknowledged the requirement — but we surface
    # the missing key on every invocation until ack'd.
    #
    # Pre-fix the warning leaked into ``CliRunner.result.output``
    # (which mixes stderr into stdout by default), polluting every
    # ``--json`` test on any machine without ``ANTHROPIC_API_KEY``
    # set. CI hit this on every push because runners don't inherit
    # our keyring; the local dev machine had the key set so the
    # breakage was invisible.
    import sys as _sys

    _print_api_key_warning_if_needed(_sys.stderr, _is_interactive_stderr())

    # Check for updates on every CLI invocation (cached, non-blocking).
    # Skip when stdout isn't a TTY (catches CI runs, piped consumers,
    # the test suite) AND when the user passed --json explicitly: a
    # user running ``urika list --json`` interactively (TTY attached)
    # otherwise gets a banner prepended to the JSON document, breaking
    # any downstream parser. The argv check is a string sweep rather
    # than a Click introspection because at this point the subcommand
    # hasn't been dispatched yet \u2014 we don't yet know which command's
    # ``--json`` flag is in play.
    try:
        import sys as _sys
        from urika.core.updates import (
            check_for_updates,
            format_update_message,
        )

        json_mode = "--json" in _sys.argv
        if _sys.stdout.isatty() and not json_mode:
            update_info = check_for_updates()
            if update_info:
                from urika.cli_display import _C

                msg = format_update_message(update_info)
                click.echo(f"{_C.DIM}  \u2191 {msg}{_C.RESET}")
    except Exception:
        pass

    if ctx.invoked_subcommand is None:
        # Default path: launch the Textual TUI. Falls back to the
        # classic prompt_toolkit REPL if Textual isn't installed
        # (the [tui] extra is optional) or if the user passed
        # --classic explicitly.
        if classic:
            from urika.repl import run_repl

            run_repl()
            return
        try:
            from urika.tui import run_tui
        except ImportError:
            from urika.repl import run_repl

            run_repl()
            return
        run_tui()
