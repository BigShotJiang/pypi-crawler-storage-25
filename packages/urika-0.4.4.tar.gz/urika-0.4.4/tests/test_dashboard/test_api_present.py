"""Tests for POST /api/projects/<name>/present.

Spawns are stubbed via monkeypatch so tests never invoke a real
``urika present`` subprocess. We assert: (a) the spawn helper gets
called with the right args when the experiment dir exists, (b) form
validation rejects missing/unknown experiments and bogus audiences,
and (c) 404 is returned for unknown projects.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from urika.dashboard import runs as runs_module
from urika.dashboard.app import create_app


def _make_project_with_experiment(
    tmp_path: Path, name: str = "alpha", exp_id: str = "exp-001"
) -> Path:
    proj = tmp_path / name
    proj.mkdir(parents=True)
    (proj / "urika.toml").write_text(
        f'[project]\nname = "{name}"\nquestion = "q"\nmode = "exploratory"\n'
        f'description = ""\n\n[preferences]\naudience = "expert"\n'
    )
    exp_dir = proj / "experiments" / exp_id
    exp_dir.mkdir(parents=True)
    (exp_dir / "experiment.json").write_text("{}")
    return proj


@pytest.fixture
def present_client(tmp_path: Path, monkeypatch) -> tuple[TestClient, list[dict], Path]:
    proj = _make_project_with_experiment(tmp_path, "alpha", "exp-001")
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("URIKA_HOME", str(home))
    (home / "projects.json").write_text(json.dumps({"alpha": str(proj)}))

    spawn_calls: list[dict] = []

    def fake_spawn(
        project_name,
        project_path,
        experiment_id,
        *,
        instructions="",
        audience=None,
        **_,
    ):
        spawn_calls.append(
            {
                "project_name": project_name,
                "project_path": project_path,
                "experiment_id": experiment_id,
                "instructions": instructions,
                "audience": audience,
            }
        )
        exp_dir = project_path / "experiments" / experiment_id
        exp_dir.mkdir(parents=True, exist_ok=True)
        (exp_dir / ".present.lock").write_text("77777")
        (exp_dir / "present.log").write_text("Spawned\n")
        return 77777

    monkeypatch.setattr(runs_module, "spawn_present", fake_spawn)
    from urika.dashboard.routers import api as api_module

    monkeypatch.setattr(api_module, "spawn_present", fake_spawn)

    app = create_app(project_root=tmp_path)
    return TestClient(app), spawn_calls, proj


def test_present_post_started(present_client):
    client, spawn_calls, proj = present_client
    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "started"
    assert body["pid"] == 77777
    assert body["experiment_id"] == "exp-001"
    assert len(spawn_calls) == 1
    assert spawn_calls[0]["project_name"] == "alpha"
    assert spawn_calls[0]["project_path"] == proj
    assert spawn_calls[0]["experiment_id"] == "exp-001"


def test_present_post_passes_instructions_and_audience(present_client):
    client, spawn_calls, _ = present_client
    r = client.post(
        "/api/projects/alpha/present",
        data={
            "experiment_id": "exp-001",
            "instructions": "emphasize ensembles",
            "audience": "expert",
        },
    )
    assert r.status_code == 200
    assert spawn_calls[0]["instructions"] == "emphasize ensembles"
    assert spawn_calls[0]["audience"] == "expert"


def test_present_post_forwards_instructions_audience(present_client):
    """The dashboard's per-experiment presentation modal posts the
    CLI-mirroring instructions + audience fields. Confirm both flow
    through to spawn_present unchanged across all valid audience
    values."""
    client, spawn_calls, _ = present_client
    for aud in ("novice", "standard", "expert"):
        spawn_calls.clear()
        r = client.post(
            "/api/projects/alpha/present",
            data={
                "experiment_id": "exp-001",
                "instructions": f"steer for {aud}",
                "audience": aud,
            },
        )
        assert r.status_code == 200
        assert len(spawn_calls) == 1
        assert spawn_calls[0]["instructions"] == f"steer for {aud}"
        assert spawn_calls[0]["audience"] == aud


def test_present_post_404_unknown_project(present_client):
    client, _, _ = present_client
    r = client.post(
        "/api/projects/nonexistent/present",
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 404


def test_present_post_missing_experiment_id(present_client):
    client, spawn_calls, _ = present_client
    r = client.post("/api/projects/alpha/present", data={})
    assert r.status_code == 422
    assert "experiment_id" in r.json()["detail"]
    assert spawn_calls == []


def test_present_post_unknown_experiment(present_client):
    client, spawn_calls, _ = present_client
    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-does-not-exist"},
    )
    assert r.status_code == 422
    assert spawn_calls == []


def test_present_post_invalid_audience(present_client):
    client, spawn_calls, _ = present_client
    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-001", "audience": "alien"},
    )
    assert r.status_code == 422
    assert spawn_calls == []


def test_present_post_blank_audience_passes_as_none(present_client):
    client, spawn_calls, _ = present_client
    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-001", "audience": ""},
    )
    assert r.status_code == 200
    assert spawn_calls[0]["audience"] is None


def test_present_post_hx_request_emits_redirect_header(present_client):
    """When the request comes from HTMX, the response should redirect
    the whole page to the experiment log so the user sees streaming
    output instead of a JSON body dumped into the modal."""
    client, spawn_calls, _ = present_client
    r = client.post(
        "/api/projects/alpha/present",
        headers={"hx-request": "true"},
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 200
    assert r.headers.get("hx-redirect", "").endswith(
        "/projects/alpha/experiments/exp-001/log?type=present"
    )
    assert len(spawn_calls) == 1


# ---- Privacy pre-flight check ---------------------------------------------


def _make_private_project_with_experiment(
    tmp_path: Path, name: str = "alpha", exp_id: str = "exp-001"
) -> Path:
    proj = tmp_path / name
    proj.mkdir(parents=True)
    (proj / "urika.toml").write_text(
        f'[project]\nname = "{name}"\nquestion = "q"\nmode = "exploratory"\n'
        f'description = ""\n\n[preferences]\naudience = "expert"\n\n'
        f'[privacy]\nmode = "private"\n'
    )
    exp_dir = proj / "experiments" / exp_id
    exp_dir.mkdir(parents=True)
    (exp_dir / "experiment.json").write_text("{}")
    return proj


def test_present_post_private_mode_without_endpoint_returns_422(
    tmp_path: Path, monkeypatch
):
    """Pre-flight gate: present on a private-mode project with no
    private endpoint must 422 before the spawn helper runs."""
    proj = _make_private_project_with_experiment(tmp_path, "alpha", "exp-001")
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("URIKA_HOME", str(home))
    (home / "projects.json").write_text(json.dumps({"alpha": str(proj)}))
    (home / "settings.toml").write_text("", encoding="utf-8")

    spawn_calls: list[dict] = []

    def fake_spawn(*a, **kw):
        spawn_calls.append({"args": a, "kwargs": kw})
        return 1234

    monkeypatch.setattr(runs_module, "spawn_present", fake_spawn)
    from urika.dashboard.routers import api as api_module

    monkeypatch.setattr(api_module, "spawn_present", fake_spawn)

    app = create_app(project_root=tmp_path)
    client = TestClient(app)

    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 422
    assert spawn_calls == []


# ---- Idempotent spawn: redirect to live log when already running ---------


def test_present_post_when_already_running_redirects_to_log(present_client):
    """HTMX POST while a present is already running for this experiment
    must NOT spawn a duplicate. Instead, redirect to the live log."""
    import os

    client, spawn_calls, proj = present_client
    exp_dir = proj / "experiments" / "exp-001"
    exp_dir.mkdir(parents=True, exist_ok=True)
    (exp_dir / ".present.lock").write_text(str(os.getpid()))

    r = client.post(
        "/api/projects/alpha/present",
        headers={"hx-request": "true"},
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 200
    assert (
        r.headers.get("hx-redirect")
        == "/projects/alpha/experiments/exp-001/log?type=present"
    )
    assert spawn_calls == []


def test_present_post_when_already_running_returns_409_without_hx(
    present_client,
):
    """Non-HTMX caller (curl, scripts) must get a 409 with a JSON body
    so they can detect the duplicate explicitly instead of a 200."""
    import os

    client, spawn_calls, proj = present_client
    exp_dir = proj / "experiments" / "exp-001"
    exp_dir.mkdir(parents=True, exist_ok=True)
    (exp_dir / ".present.lock").write_text(str(os.getpid()))

    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 409
    body = r.json()
    assert body["status"] == "already_running"
    assert body["log_url"] == "/projects/alpha/experiments/exp-001/log?type=present"
    assert body["type"] == "present"
    assert spawn_calls == []


def test_present_post_other_experiment_running_does_not_block(present_client):
    """A live present lock on a *different* experiment must NOT block
    a fresh present spawn for this experiment — locks are per-experiment."""
    import os

    client, spawn_calls, proj = present_client
    other = proj / "experiments" / "exp-OTHER"
    other.mkdir(parents=True, exist_ok=True)
    (other / "experiment.json").write_text("{}")
    (other / ".present.lock").write_text(str(os.getpid()))

    r = client.post(
        "/api/projects/alpha/present",
        data={"experiment_id": "exp-001"},
    )
    assert r.status_code == 200
    assert len(spawn_calls) == 1
