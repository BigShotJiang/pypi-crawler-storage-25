import copy
from typing import Any, Optional

from layoutml.base import BaseElement
from layoutml.base.css.CSSSelectors import StyleType
from layoutml.layout import Layout
from .Body import Body
from .Head import Head


class Page(BaseElement):
    """
    Полный HTML документ
    Объединяет Head и Body
    """

    object_type: str

    doctype: str
    head: Head
    body: Body

    def __init__(self, object_name, doctype: str = "html", title: str = "LayoutML", lang="ru", **kwargs):
        super().__init__(tag="html", object_name=object_name, lang=lang, **kwargs)

        self.object_type = "Page"
        self.doctype = doctype
        self.head = Head(title=title)
        self.body = Body()

        self.need_css_file = True

        self.head.set_icon("https://raw.githubusercontent.com/feed619/LayoutML/refs/heads/main/ico/logo.ico")

    def copy(self, copy_element: "Page" = None) -> "Page":
        if copy_element is None:
            copy_element = Page(object_name=self.object_name)
        super().copy(copy_element=copy_element)

        copy_element.doctype = self.doctype
        copy_element.head = self.head.copy()
        copy_element.body = self.body.copy()
        copy_element.need_css_file = self.need_css_file

        return copy_element

    def set_head(self, head: Head) -> "Page":
        self.head = head
        return self

    def set_body(self, body: Body) -> "Page":
        self.body = body
        return self

    def set_doctype(self, doctype: str) -> "Page":
        """
        Установить doctype
        """
        self.doctype = doctype
        return self

    def set_language(self, lang: str) -> "Page":
        """Установить язык документа"""
        self.add_attributes(lang=lang)
        return self

    def add_stylesheet(self, href: str, media: str = "all") -> "Head":
        """Добавить CSS файл"""
        self.head.add_link(rel="stylesheet", href=href, media=media)
        return self

    def del_stylesheet(self, href: str):
        self.head.del_link(href=href)
        return self

    def add_script(self, src: Optional[str] = None, content: Optional[str] = None, **attributes) -> "Page":
        """
        Добавить script тег а атрибут Head
        Примеры:
        - add_script(src="app.js", defer=True)
        - add_script(content="console.log('Hello');", type="module")
        """
        self.head.add_script(src=src, content=content, **attributes)
        return self

    def add_element(self, element: Any) -> "Body":
        """
        Добавить HTML элемент для body
        """
        self.body.add_element(element)
        return self

    def get_element(self, object_name: str) -> Layout | BaseElement:
        for element in self.body.elements:
            if element.get_object_name() == object_name:
                return element
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{object_name}'")

    def remove_element(self, object_name: str) -> None:
        for index in range(len(self.body.elements)):
            if self.body.elements[index].get_object_name() == object_name:
                return self.body.elements.pop(index)

    def _get_doctype(self) -> str:
        """Получить строку doctype"""
        doctypes = {
            "html": "<!DOCTYPE html>",
            "html5": "<!DOCTYPE html>",
            "xhtml": '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',
            "strict": '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">',
            "transitional": '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">',
        }
        return doctypes.get(self.doctype, "<!DOCTYPE html>")

    def render(self) -> str:
        """Рендеринг полного HTML документа"""

        css_text = self.get_css_file()
        if css_text:
            css_file_name = f"styles/{self.body.object_name}.css" if self.body.object_name else f"styles/{self.body.object_type}.css"
            with open(css_file_name, "w") as f:
                f.write(css_text)
            self.head.add_stylesheet(css_file_name)

        return self.get_html()

    def get_styles(self, styles_type: StyleType = StyleType.EXTERNAL):
        css_styles: dict = {}
        css_styles.update(super().get_styles(styles_type=styles_type))
        css_styles.update(self.head.get_styles(styles_type=styles_type))
        css_styles.update(self.body.get_styles(styles_type=styles_type))
        return css_styles

    def get_css_file(self, styles_type: StyleType = StyleType.EXTERNAL):
        css_text: str = ""
        for selector_name, css in self.get_styles(styles_type=styles_type).items():
            css_text += f"{selector_name} " + "{\n" + css + "}\n"
        return css_text

    def create_css_file(self, path: str):
        with open(path, "w") as f:
            css_text = self.get_css_file()
            f.write(css_text)

    def render_css_file(self, styles_dirname: str, file_name: str):
        css_file_name = f"{styles_dirname}/{file_name}.css"
        self.create_css_file(path=css_file_name)
        self.head.add_stylesheet(css_file_name)

    def get_html(self):
        parts = []
        parts.append(self._get_doctype())

        attrs = self.get_attributes_string()
        parts.append(f"<{self.tag} {attrs}>")

        global_styles = self.body.get_styles(styles_type=StyleType.GLOBAL)
        parts.append(self.head.get_html(styles=global_styles))
        parts.append(self.body.get_html())

        parts.append("</html>")

        return "\n".join(parts)

    def save(self, filename: str, encoding: str = "utf-8") -> None:
        """Сохранить документ в файл"""
        with open(filename, "w", encoding=encoding) as f:
            f.write(self.get_html())
        print(f"Документ сохранен в {filename}")

    def __str__(self) -> str:
        return self.get_html()

    def __repr__(self) -> str:
        return f'{self.get_object_name()}", title="{self.head.title}")'
