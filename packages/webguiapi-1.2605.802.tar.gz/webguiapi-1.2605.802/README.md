#WebGUIAPI

## History of version
Version 1.2605.0802: 2026/05/08<BR>
Add TMediaPlayer, TProgressBar


Version 1.2605.0801: 2026/05/08<BR>
Fixed problem: TPanel, TImage layer 
Fixed container : TVLayout

Version 1.2604.2901: 2026/04/29<BR>
Fixed TCheckBox problem.

Version 1.2604.2811: 2026/04/28<BR>
Fixed TVLayout/THLayout/TGridLayout Undefined error.


Version 1.2604.2810: 2026/04/28<BR>
Add TPageControl, TGroupBox, TRadioButton, TCheckBox


Version 1.2604.2808: 2026/04/28<BR>
Add TGridLayout
Fixed THLayout and TVLayout many problems.

Version 1.2604.2807: 2026/04/28<BR>
Fixed: TListBox-->_refresh_items(self) items issue.


Version 1.2604.2806: 2026/04/28<BR>
Fixed: TListBox-->Remove _onclick()

Version 1.2604.2805: 2026/04/28<BR>
Re-write&design TListBox code
Fix problem:TComboBox compatible with vcl framework<BR>
            remove option and value property.

Version 1.2604.2803: 2026/04/28<BR>
Fix problem:
TEdit component err --> NameError: name 'v' is not defined

Version 1.2604.2802: 2026/04/28<BR>
1.Add TListBox component.
2.Improve TButton add TButtonShape property.

Version 1.2604.2801: 2026/04/28<BR>
Create WebGUI component for VCL framework like.