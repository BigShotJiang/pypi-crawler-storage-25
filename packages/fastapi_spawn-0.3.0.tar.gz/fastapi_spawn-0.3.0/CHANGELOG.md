# Changelog

All notable changes to `fastapi-spawn` will be documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [0.1.0] — 2026-05-10

### Added
- Interactive TUI with questionary + Rich styling
- Database support: PostgreSQL, MySQL, MongoDB, SQLite
- ORM support: SQLAlchemy 2.x (async), Tortoise ORM, Beanie
- Migration support: Alembic (async-compatible), Aerich
- Auth: JWT, OAuth2, API Key
- Message brokers: Redis (Celery), RabbitMQ (Celery), Kafka (aiokafka)
- Cache layer: Redis, Memcached
- File storage: AWS S3 (boto3) with presigned URLs
- AI integration: OpenAI (chat + embeddings, custom base URL), Anthropic Claude
- Root-level `main.py` entry point (`uv run main.py`)
- Root-level `tasks/` directory for Celery workers
- Individual env fields per service with `@property` URL assembly
- `OPENAI_BASE_URL` support for Azure, LM Studio, local endpoints
- `--dry-run` flag with rich tree preview
- `--force` flag to overwrite existing projects
- Stack options: minimal, standard, full (Helm + Terraform)
- CI/CD: GitHub Actions, GitLab CI
- Logging: loguru, structlog, standard library
- Docker: multi-service compose with health checks
- infra/: docker/, helm/, terraform/ structure
- `uv`-compatible `pyproject.toml` with `[tool.uv]`
- `list-templates` and `validate` subcommands
- `ENVIRONMENT=dev` style env naming
- Professional README, CHANGELOG, CONTRIBUTING
