"""Config — surface and inspect CLI configuration."""

import typer

from hl_cli.output import output

config_app = typer.Typer(
    name="config",
    no_args_is_help=True,
    help="View CLI configuration.",
)

DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"


@config_app.command()
def show():
    """Show current configuration."""
    from hl_cli.client import _load_settings_env

    settings = _load_settings_env()
    custom_rpc = settings.get("POLYGON_RPC")

    killswitch_addr = settings.get("KILLSWITCH_ADDRESS")

    result = {
        "polygon_rpc": {
            "current": custom_rpc or DEFAULT_POLYGON_RPC,
            "source": "settings" if custom_rpc else "default",
            "default": DEFAULT_POLYGON_RPC,
        },
        "killswitch_address": {
            "current": killswitch_addr or None,
            "configured": killswitch_addr is not None,
        },
    }
    output(result, None)
