"""Tests for act commands — order, cancel, cancel-all, leverage, transfer, preflight."""

import json
import os
from unittest.mock import patch

import pytest

from hl_cli.main import app

ACTIVE_ASSET_DATA_EMPTY = {
    "user": "0xTEST",
    "coin": "xyz:CL",
    "leverage": {"type": "isolated", "value": 20, "rawUsd": "0.0"},
    "maxTradeSzs": ["0.0", "0.0"],
    "availableToTrade": ["0.0", "0.0"],
    "markPx": "100.50",
}


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


@pytest.fixture(autouse=True)
def _use_tmp_dir(tmp_path):
    """Run act tests in a temp dir so trade log doesn't pollute the project."""
    original = os.getcwd()
    os.chdir(tmp_path)
    yield
    os.chdir(original)


class TestOrder:
    def test_market_buy(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "--market"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_limit_buy(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "65000"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_side_aliases(self, runner, patched):
        for side in ["buy", "long", "sell", "short"]:
            result = runner.invoke(app, ["hl", "order", "BTC", side, "0.1", "--market"])
            assert result.exit_code == 0, f"Failed for side={side}"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "BTC", "yolo", "0.1", "65000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_SIDE"

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "FAKECOIN", "buy", "0.1", "--market"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "UNKNOWN_ASSET"


class TestCancel:
    def test_by_oid_auto_lookup(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "cancel", "100001"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_by_oid_with_asset(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "cancel", "BTC", "100001"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_oid_not_found(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel", "999999"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "ORDER_NOT_FOUND"


class TestCancelAll:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "cancel-all"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filtered(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel-all", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert d["cancelled"] == 1
        assert d["assets"] == ["BTC"]

    def test_empty(self, runner, patched):
        patched["info"].frontend_open_orders.return_value = []
        result = runner.invoke(app, ["hl", "cancel-all"])
        assert result.exit_code == 0
        d = data(result)
        assert d["cancelled"] == 0


class TestLeverage:
    def test_cross_default(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_isolated(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--isolated"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_both_flags_error(self, runner, patched):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--cross", "--isolated"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "CONFLICTING_OPTIONS"


class TestPreflight:
    def test_can_trade(self, runner, patched):
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert d["can_trade"] is True
        assert d["asset"] == "BTC"
        assert d["dex"] == "default"
        assert float(d["max_size"]) > 0

    def test_cannot_trade_hip3(self, runner, patched):
        # Add xyz:CL to resolver's known coins
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("hl_cli.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5"])
            assert result.exit_code == 0
            d = data(result)
            assert d["can_trade"] is False
            assert d["dex"] == "xyz"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["hl", "preflight", "BTC", "sideways", "1.0"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_SIDE"


class TestTransfer:
    def test_missing_direction(self, runner, patched):
        result = runner.invoke(app, ["hl", "transfer", "5.00"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_OPTION"

    def test_both_from_and_to(self, runner, patched):
        """Both --from and --to is valid (e.g. --from spot --to flx)."""
        mock_exchange = patched["exchange"]
        mock_exchange.send_asset.return_value = {"status": "ok"}
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz", "--from", "default"])
        assert result.exit_code == 0

    def test_successful_transfer(self, runner, patched):
        """Transfer between USDC dexes succeeds."""
        mock_exchange = patched["exchange"]
        mock_exchange.send_asset.return_value = {"status": "ok"}
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz"])
        assert result.exit_code == 0
        d = data(result)
        assert d["token"] == "USDC"
        assert d["to_dex"] == "xyz"
        assert d["from_dex"] == "default"

    def test_collateral_mismatch(self, runner, patched):
        """Transfer between dexes with different collateral tokens fails."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "flx"])
        assert result.exit_code == 2
        err = parse(result)["error"]
        assert err["code"] == "COLLATERAL_MISMATCH"
        assert "USDC" in err["message"]
        assert "USDH" in err["message"]
