"""Tests for regard killswitch command."""

import json
from unittest.mock import patch, MagicMock

from typer.testing import CliRunner

from hl_cli.main import app

runner = CliRunner()


def _parse_json(result):
    """Extract JSON from runner output, skipping any stderr progress lines."""
    # Typer's CliRunner mixes stderr into output. Find the JSON line.
    for line in reversed(result.output.strip().splitlines()):
        line = line.strip()
        if line.startswith("{"):
            return json.loads(line)
    return _parse_json(result)

# Patch paths — _kill_hl imports from these modules at call time
_C = "hl_cli.client"
_R = "hl_cli.resolver"
_K = "hl_cli.commands.killswitch"


def test_killswitch_no_address():
    """killswitch dies with clear error when no KILLSWITCH_ADDRESS configured."""
    with patch(f"{_K}._get_killswitch_address", return_value=None):
        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 2
        data = _parse_json(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "NO_KILLSWITCH_ADDRESS"
        assert "config" in data["error"]["hint"]


def test_killswitch_with_address_hl_no_positions():
    """killswitch succeeds with no positions/orders to close."""
    with patch(f"{_K}._get_killswitch_address", return_value="0x1234567890abcdef1234567890abcdef12345678"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["destination"] == "0x1234567890abcdef1234567890abcdef12345678"
        assert data["data"]["hl"]["cancelled_orders"] == 0
        assert data["data"]["hl"]["closed_positions"] == []
        assert data["data"]["poly"]["skipped"] == "not configured"


def test_killswitch_hl_error_does_not_crash():
    """HL errors are caught and reported, poly still runs."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl", side_effect=Exception("connection failed")), \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["hl"]["error"] == "connection failed"
        assert data["data"]["poly"]["skipped"] == "not configured"


def test_killswitch_poly_error_does_not_crash():
    """Poly errors are caught and reported, HL still runs."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly", side_effect=Exception("geo-blocked")):

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [],
            "key_mode": "agent",
        }

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["hl"]["cancelled_orders"] == 0
        assert data["data"]["poly"]["error"] == "geo-blocked"


def test_killswitch_reports_key_mode():
    """killswitch output includes key_mode so user knows agent key limitations."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 2,
            "closed_positions": [{"asset": "BTC", "side": "sell", "size": 0.1}],
            "transferred": [{"source": "perp", "token": "USDC", "amount": 500.0}],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        data = _parse_json(result)
        assert data["data"]["hl"]["key_mode"] == "agent"


def test_killswitch_reports_stranded_dex_balances():
    """killswitch with agent key reports HIP-3 dex balances as stranded."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [
                {"source": "perp", "token": "USDC", "amount": 100.0},
                {"source": "dex:flx", "amount": 50.0,
                 "error": "agent key cannot transfer HIP-3 dex funds — use master key or withdraw via Hyperliquid UI"},
            ],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        data = _parse_json(result)
        transfers = data["data"]["hl"]["transferred"]
        assert len(transfers) == 2
        assert transfers[0]["source"] == "perp"
        stranded = transfers[1]
        assert stranded["source"] == "dex:flx"
        assert "agent key" in stranded["error"]


def test_is_agent_key_detection(tmp_path, monkeypatch):
    """_is_agent_key correctly detects agent vs master key."""
    from hl_cli.commands.killswitch import _is_agent_key

    monkeypatch.delenv("HYPERLIQUID_AGENT_KEY", raising=False)
    monkeypatch.delenv("HYPERLIQUID_PRIVATE_KEY", raising=False)

    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)

    settings.write_text(json.dumps({"env": {"HYPERLIQUID_AGENT_KEY": "0xabc"}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    assert _is_agent_key() is True

    settings.write_text(json.dumps({"env": {"HYPERLIQUID_PRIVATE_KEY": "0xabc"}}))
    assert _is_agent_key() is False

    monkeypatch.setenv("HYPERLIQUID_AGENT_KEY", "0xabc")
    assert _is_agent_key() is True


# ---------------------------------------------------------------------------
# Close logic tests — test _kill_hl internals with mocked SDK
# ---------------------------------------------------------------------------

def _mock_kill_hl(positions, close_response, orders=None):
    """Run _kill_hl with mocked SDK. Returns the result dict."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.return_value = close_response

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=positions), \
         patch(f"{_C}.get_all_orders", return_value=orders or []), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True):

        from hl_cli.commands.killswitch import _kill_hl
        return _kill_hl("0xdest")


def test_close_filled():
    """Position close that fills reports avg_price and status."""
    result = _mock_kill_hl(
        positions=[{"coin": "BTC", "szi": "-0.1"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"filled": {"totalSz": "0.1", "avgPx": "95100.5", "oid": 123}}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert closed["status"] == "filled"
    assert closed["avg_price"] == "95100.5"
    assert closed["side"] == "buy"


def test_close_error_from_exchange():
    """Exchange returns error status."""
    result = _mock_kill_hl(
        positions=[{"coin": "ETH", "szi": "1.0"}],
        close_response={"status": "err", "response": "Insufficient margin"},
    )
    closed = result["closed_positions"][0]
    assert "error" in closed
    assert "Insufficient margin" in closed["error"]


def test_close_ioc_expired():
    """IOC order expires without filling — resting instead of filled."""
    result = _mock_kill_hl(
        positions=[{"coin": "SOL", "szi": "-10.0"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"resting": {"oid": 456}}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert "error" in closed
    assert "no fill" in closed["error"]


def test_close_order_error_in_status():
    """Exchange returns error inside statuses array."""
    result = _mock_kill_hl(
        positions=[{"coin": "xyz:NATGAS", "szi": "-12.0"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"error": "reduce only order would increase position"}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert closed["error"] == "reduce only order would increase position"


def test_close_market_close_returns_none():
    """market_close returns None when position not found by SDK."""
    result = _mock_kill_hl(
        positions=[{"coin": "UNKNOWN", "szi": "5.0"}],
        close_response=None,
    )
    closed = result["closed_positions"][0]
    assert "not found" in closed["error"]


def test_close_zero_position_skipped():
    """Positions with szi=0 are skipped."""
    result = _mock_kill_hl(
        positions=[{"coin": "BTC", "szi": "0.0"}],
        close_response=None,
    )
    assert result["closed_positions"] == []


def test_close_exception_caught():
    """SDK exception during market_close is caught and reported."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.side_effect = Exception("connection reset")

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[{"coin": "BTC", "szi": "0.5"}]), \
         patch(f"{_C}.get_all_orders", return_value=[]), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True):

        from hl_cli.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")

    closed = result["closed_positions"][0]
    assert closed["error"] == "connection reset"
    assert closed["side"] == "sell"


# ---------------------------------------------------------------------------
# Dry run tests
# ---------------------------------------------------------------------------

def test_dry_run_does_not_execute():
    """--dry-run reports what would happen without calling exchange methods."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 2,
            "closed_positions": [{"asset": "BTC", "side": "sell", "size": 0.1, "status": "dry_run"}],
            "transferred": [{"source": "spot", "token": "USDC", "amount": 100, "status": "dry_run"}],
            "key_mode": "agent",
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch", "--dry-run"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["data"]["dry_run"] is True
        # Verify _kill_hl was called with dry_run=True
        mock_hl.assert_called_once_with("0xdead", dry_run=True)


def test_dry_run_close_logic():
    """Dry run skips market_close and reports dry_run status."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[{"coin": "BTC", "szi": "-0.5"}]), \
         patch(f"{_C}.get_all_orders", return_value=[{"coin": "BTC", "oid": 123}]), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_K}._is_agent_key", return_value=True), \
         patch(f"{_C}.get_account_mode", return_value="default"):

        from hl_cli.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest", dry_run=True)

    # Orders counted but not cancelled
    assert result["cancelled_orders"] == 1
    mock_exchange.bulk_cancel.assert_not_called()

    # Position reported but not closed
    assert result["closed_positions"][0]["status"] == "dry_run"
    mock_exchange.market_close.assert_not_called()


# ---------------------------------------------------------------------------
# Contract tests — envelope shape, no tracebacks
# ---------------------------------------------------------------------------

def test_killswitch_no_address_envelope():
    """killswitch error produces valid JSON envelope with correct shape."""
    with patch(f"{_K}._get_killswitch_address", return_value=None):
        result = runner.invoke(app, ["killswitch"])
        assert "Traceback" not in result.output
        data = _parse_json(result)
        assert "ok" in data
        assert data["ok"] is False
        assert "error" in data
        assert "type" in data["error"]
        assert "code" in data["error"]
        assert "message" in data["error"]


def test_killswitch_success_envelope():
    """killswitch success produces valid JSON envelope with meta."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl", return_value={"cancelled_orders": 0, "closed_positions": [], "transferred": [], "key_mode": "agent"}), \
         patch(f"{_K}._kill_poly", return_value={"skipped": "not configured"}):

        result = runner.invoke(app, ["killswitch"])
        assert "Traceback" not in result.output
        data = _parse_json(result)
        assert data["ok"] is True
        assert "data" in data
        assert "meta" in data
        assert "timestamp" in data["meta"]


def test_killswitch_unknown_option_produces_json():
    """Unknown flags produce JSON error, not Rich/Click text."""
    result = runner.invoke(app, ["killswitch", "--nonexistent"])
    assert "Traceback" not in result.output
    data = _parse_json(result)
    assert data["ok"] is False


# ---------------------------------------------------------------------------
# Config integration tests
# ---------------------------------------------------------------------------

def test_config_show_includes_killswitch_address(tmp_path, monkeypatch):
    """config show surfaces killswitch_address field."""
    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {"KILLSWITCH_ADDRESS": "0xdead"}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = _parse_json(result)
    ks = data["data"]["killswitch_address"]
    assert ks["current"] == "0xdead"
    assert ks["configured"] is True


def test_config_show_killswitch_not_configured(tmp_path, monkeypatch):
    """config show shows killswitch_address as null when not set."""
    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    data = _parse_json(result)
    ks = data["data"]["killswitch_address"]
    assert ks["configured"] is False
