"""Integration test fixtures — real staging API."""

import os
import pytest

from nudg3_mcp.client import NudgClient

DEFAULT_URL = "https://nudg3-backend-staging-dw7geboxla-uc.a.run.app"
STAGING_URL = os.environ.get("NUDG3_TEST_API_URL", DEFAULT_URL)
STAGING_KEY = os.environ.get("NUDG3_TEST_API_KEY", "")


def staging_available() -> bool:
    return bool(STAGING_KEY)


skip_no_key = pytest.mark.skipif(
    not staging_available(),
    reason="NUDG3_TEST_API_KEY not set — skipping integration tests",
)


@pytest.fixture
def staging_client() -> NudgClient:
    return NudgClient(
        api_key=STAGING_KEY,
        base_url=STAGING_URL,
        timeout=30.0,
    )
