"""
Integration tests against the staging API.

Run with:
  NUDG3_TEST_API_KEY=nudg3_live_ak_... pytest tests/integration/ -v
"""

import pytest
import httpx

from nudg3_mcp.tools.overview import execute_overview
from nudg3_mcp.tools.competitors import execute_competitor_analysis
from nudg3_mcp.tools.prompts import execute_prompt_analysis
from nudg3_mcp.tools.sources import execute_source_analysis
from nudg3_mcp.tools.responses import execute_response_analysis
from nudg3_mcp.tools.export_data import execute_export
from nudg3_mcp.tools.metric_catalog import get_catalog
from nudg3_mcp.routing import MEASURE_ROUTES

from .conftest import skip_no_key


# ─── Catalog consistency ─────────────────────────────────────────────────


def test_catalog_is_consistent_with_routing():
    catalog = get_catalog()
    catalog_names = {m["name"] for m in catalog["measures"]}
    route_names = set(MEASURE_ROUTES.keys())
    assert catalog_names == route_names


# ─── get_overview ────────────────────────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_overview_returns_organic_and_branded(staging_client):
    result = await execute_overview(staging_client)

    assert "workspace" in result
    assert "organic_visibility" in result
    assert "branded_visibility" in result
    assert "top_sources" in result
    assert "alerts" in result
    assert "suggested_investigations" in result
    assert "date_range" in result

    # Both sections should have descriptions
    assert "description" in result["organic_visibility"]
    assert "description" in result["branded_visibility"]

    # Scores are compact — no time-series arrays
    for section in [result["organic_visibility"], result["branded_visibility"]]:
        for score in section["brand_scores"]:
            assert isinstance(score["visibility_sma"], (int, float))
            assert "brand_id" in score

    # Suggestions have tool names
    for s in result["suggested_investigations"]:
        assert "tool" in s
        assert "reason" in s


@skip_no_key
@pytest.mark.asyncio
async def test_overview_rate_limit_present(staging_client):
    result = await execute_overview(staging_client)
    assert "rate_limit" in result
    info = result["rate_limit"]
    assert "minute_remaining" in info


# ─── analyze_competitors ─────────────────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_competitors_returns_rankings(staging_client):
    result = await execute_competitor_analysis(staging_client)

    assert "rankings" in result
    assert "context" in result
    assert len(result["rankings"]) > 0
    assert result["rankings"][0]["rank"] == 1
    assert "brand_id" in result["rankings"][0]


# ─── analyze_prompts ─────────────────────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_prompts_requires_brand_id(staging_client):
    """Get brand_id from overview, then analyze prompts."""
    overview = await execute_overview(staging_client)
    brand_id = overview["workspace"]["primary_brand_id"]
    assert brand_id

    result = await execute_prompt_analysis(staging_client, brand_id=brand_id)

    assert "by_stage" in result
    assert result["total_prompts"] > 0
    assert "context" in result


# ─── analyze_sources ─────────────────────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_sources_returns_domains(staging_client):
    result = await execute_source_analysis(staging_client)

    assert "top_domains" in result
    assert len(result["top_domains"]) > 0
    assert "domain" in result["top_domains"][0]
    assert "usage_pct" in result["top_domains"][0]
    assert "content_gaps" in result


# ─── analyze_responses ───────────────────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_responses_groups_by_provider(staging_client):
    result = await execute_response_analysis(staging_client, limit=10)

    assert "by_provider" in result
    assert "total_responses" in result
    assert "patterns" in result

    # Samples should be truncated
    for provider, summary in result["by_provider"].items():
        for sample in summary["samples"]:
            assert len(sample["text"]) <= 303


# ─── Investigation flow (end-to-end) ────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_investigation_flow(staging_client):
    """Test the intended usage: overview → follow suggestion → drill down."""
    # Step 1: Overview (organic + branded split)
    overview = await execute_overview(staging_client)
    organic = overview["organic_visibility"]["brand_scores"]
    branded = overview["branded_visibility"]["brand_scores"]
    assert len(organic) > 0 or len(branded) > 0

    brand_id = overview["workspace"]["primary_brand_id"]
    assert brand_id

    # Step 2: Analyze organic prompts
    prompts = await execute_prompt_analysis(staging_client, brand_id=brand_id, visibility_type="organic")
    assert prompts["total_prompts"] >= 0
    assert prompts["visibility_type"] == "organic"

    # Step 3: Analyze sources
    sources = await execute_source_analysis(staging_client)
    assert len(sources["top_domains"]) > 0

    # All responses should have suggested_investigations
    assert "suggested_investigations" in overview
    assert "suggested_investigations" in prompts
    assert "suggested_investigations" in sources


# ─── Export ──────────────────────────────────────────────────────────────


@skip_no_key
@pytest.mark.asyncio
async def test_export_handles_scope(staging_client):
    result = await execute_export(
        client=staging_client,
        dataset="dashboard_graph",
        date_from="2026-03-01",
        date_to="2026-03-31",
    )

    assert result is not None
    if result.get("error"):
        assert "scope" in result["message"].lower() or "403" in result["message"]
    else:
        assert result["format"] == "csv"
