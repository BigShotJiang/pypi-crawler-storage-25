"""Tests for insights tools (get_reports, get_insights, get_actions) with mocked HTTP."""

import pytest
import respx
import httpx

from nudg3_mcp.client import NudgClient
from nudg3_mcp.tools.reports import execute_get_reports, _format_report_summary, _format_report_detail
from nudg3_mcp.tools.insights import execute_get_insights, _count_items, _summarize_insight_list
from nudg3_mcp.tools.actions import execute_get_actions, _format_action_summary, _format_action_detail
from nudg3_mcp.tools.metric_catalog import get_catalog


@pytest.fixture
def client():
    return NudgClient(
        api_key="nudg3_test_ak_abc123",
        base_url="https://test.nudg3.ai",
        timeout=5.0,
    )


# ─── Mock data ─────────────────────────────────────────────────────────

MOCK_REPORT = {
    "id": "rpt-001",
    "report_type": "weekly_report",
    "brand_name": "TestBrand",
    "visibility_score": 42,
    "competitive_position": 3,
    "total_mentions": 156,
    "total_responses": 412,
    "mention_rate": 0.3786,
    "analysis_confidence": "high",
    "executive_summary": "Visibility improved 3 points this week.",
    "has_insights": True,
    "calculated_at": "2026-03-24T04:00:00Z",
    "start_date": "2026-03-17",
    "end_date": "2026-03-24",
    "created_at": "2026-03-24T04:05:00Z",
    "provider_scores": {"ChatGPT": {"score": 55}, "Gemini": {"score": 30}},
    "ranked_brands": [{"name": "Brand24", "score": 89}, {"name": "TestBrand", "score": 42}],
    "sentiment_summary": {"ChatGPT": {"positive": 0.65}},
    "data_quality_notes": ["Limited sample for Perplexity"],
}

MOCK_INSIGHTS = {
    "schema_version": "2026-04-02",
    "opportunities": [
        {"title": "No presence in AI monitoring queries", "description": "Competitors appear in 80%...", "priority": "high", "category": "content"},
        {"title": "Wikipedia gap", "description": "No Wikipedia presence", "priority": "medium", "category": "content"},
    ],
    "threats": [
        {"title": "Brand24 gaining fast", "description": "+5pts in 7d", "priority": "high", "category": "marketing"},
    ],
    "quick_wins": [
        {"title": "Add comparison page", "description": "Easy content win", "priority": "high"},
    ],
    "provider_strategies": [
        {"provider": "ChatGPT", "strategy": "Focus on authoritative sources", "priority": "high", "current_score": 55.0},
    ],
    "content_recommendations": [
        {"title": "Write comparison blog", "description": "Target AI monitoring queries", "content_format": "blog_post", "target_platform": "website", "priority": "high"},
    ],
    "prompt_edit_suggestions": [],
}

MOCK_ACTION = {
    "id": "act-001",
    "recommendation_type": "opportunity",
    "action_text": "Publish comparison blog post targeting AI monitoring queries",
    "status": "pending",
    "priority": "high",
    "content_format": "blog_post",
    "target_platform": "website",
    "owner_team": "content",
    "source_report_id": "rpt-001",
    "created_at": "2026-03-24T04:00:00Z",
    "updated_at": "2026-03-25T10:30:00Z",
    "action_context": {"insight": "Competitors appear in 80% of queries"},
    "brief_iterations": 0,
    "assigned_to_user_id": None,
    "started_at": None,
    "completed_at": None,
}


# ─── Report formatting ─────────────────────────────────────────────────


def test_format_report_summary():
    s = _format_report_summary(MOCK_REPORT)
    assert s["id"] == "rpt-001"
    assert s["visibility_score"] == 42
    assert s["has_insights"] is True
    assert "provider_scores" not in s


def test_format_report_detail():
    d = _format_report_detail(MOCK_REPORT)
    assert d["id"] == "rpt-001"
    assert d["provider_scores"] == {"ChatGPT": {"score": 55}, "Gemini": {"score": 30}}
    assert d["executive_summary"] == "Visibility improved 3 points this week."


# ─── Insight helpers ───────────────────────────────────────────────────


def test_count_items():
    counts = _count_items(MOCK_INSIGHTS)
    assert counts["opportunities"] == 2
    assert counts["threats"] == 1
    assert counts["quick_wins"] == 1
    assert counts["provider_strategies"] == 1
    assert counts["content_recommendations"] == 1
    assert "prompt_edit_suggestions" not in counts  # empty list excluded


def test_summarize_insight_list_caps_at_max():
    items = [{"title": f"Item {i}", "description": f"Desc {i}"} for i in range(10)]
    result = _summarize_insight_list(items, max_items=3)
    assert len(result) == 3


def test_summarize_insight_list_includes_priority():
    items = [{"title": "Test", "description": "Desc", "priority": "high", "category": "tech"}]
    result = _summarize_insight_list(items)
    assert result[0]["priority"] == "high"
    assert result[0]["category"] == "tech"


# ─── Action formatting ────────────────────────────────────────────────


def test_format_action_summary():
    s = _format_action_summary(MOCK_ACTION)
    assert s["id"] == "act-001"
    assert s["status"] == "pending"
    assert s["priority"] == "high"
    assert "action_context" not in s


def test_format_action_detail():
    d = _format_action_detail(MOCK_ACTION)
    assert d["action_context"] == {"insight": "Competitors appear in 80% of queries"}
    assert d["brief_iterations"] == 0


# ─── Catalog includes insights ────────────────────────────────────────


def test_catalog_has_insights_section():
    catalog = get_catalog()
    assert "insights" in catalog
    tools = catalog["insights"]["tools"]
    names = [t["name"] for t in tools]
    assert "get_reports" in names
    assert "get_insights" in names
    assert "get_actions" in names


# ─── Reports tool (mocked HTTP) ──────────────────────────────────────


@respx.mock
@pytest.mark.asyncio
async def test_get_reports_list(client):
    respx.get("https://test.nudg3.ai/api/v1/reports").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "reports": [MOCK_REPORT],
                "pagination": {"page": 1, "per_page": 20, "total": 1, "total_pages": 1, "has_next": False, "has_prev": False},
            },
        })
    )

    result = await execute_get_reports(client=client)
    assert len(result["reports"]) == 1
    assert result["reports"][0]["id"] == "rpt-001"
    assert result["total_with_insights"] == 1
    assert "suggested_investigations" in result


@respx.mock
@pytest.mark.asyncio
async def test_get_reports_latest(client):
    respx.get("https://test.nudg3.ai/api/v1/reports/latest").mock(
        return_value=httpx.Response(200, json={"success": True, "data": MOCK_REPORT})
    )

    result = await execute_get_reports(client=client, latest=True)
    assert result["report"]["id"] == "rpt-001"
    assert result["report"]["visibility_score"] == 42
    assert any(s["tool"] == "get_insights" for s in result["suggested_investigations"])


@respx.mock
@pytest.mark.asyncio
async def test_get_reports_latest_none(client):
    respx.get("https://test.nudg3.ai/api/v1/reports/latest").mock(
        return_value=httpx.Response(200, json={"success": True, "data": None})
    )

    result = await execute_get_reports(client=client, latest=True)
    assert result["report"] is None
    assert "No reports found" in result["message"]


@respx.mock
@pytest.mark.asyncio
async def test_get_reports_detail(client):
    respx.get("https://test.nudg3.ai/api/v1/reports/rpt-001").mock(
        return_value=httpx.Response(200, json={"success": True, "data": MOCK_REPORT})
    )

    result = await execute_get_reports(client=client, report_id="rpt-001")
    assert result["report"]["executive_summary"] == "Visibility improved 3 points this week."
    assert result["report"]["provider_scores"] is not None


@respx.mock
@pytest.mark.asyncio
async def test_get_reports_detail_with_insights(client):
    report_with_insights = {**MOCK_REPORT, "insights": MOCK_INSIGHTS}
    respx.get("https://test.nudg3.ai/api/v1/reports/rpt-001").mock(
        return_value=httpx.Response(200, json={"success": True, "data": report_with_insights})
    )

    result = await execute_get_reports(client=client, report_id="rpt-001", include_insights=True)
    assert "insights" in result["report"]
    assert result["report"]["insights"]["schema_version"] == "2026-04-02"


# ─── Insights tool (mocked HTTP) ─────────────────────────────────────


@respx.mock
@pytest.mark.asyncio
async def test_get_insights_full(client):
    respx.get("https://test.nudg3.ai/api/v1/reports/rpt-001/insights").mock(
        return_value=httpx.Response(200, json={"success": True, "data": MOCK_INSIGHTS})
    )

    result = await execute_get_insights(client=client, report_id="rpt-001")
    assert result["report_id"] == "rpt-001"
    assert result["counts"]["opportunities"] == 2
    assert result["counts"]["threats"] == 1
    assert len(result["opportunities"]) == 2
    assert result["opportunities"][0]["title"] == "No presence in AI monitoring queries"
    assert "suggested_investigations" in result


@respx.mock
@pytest.mark.asyncio
async def test_get_insights_filtered_by_priority(client):
    filtered = {
        "schema_version": "2026-04-02",
        "opportunities": [MOCK_INSIGHTS["opportunities"][0]],  # only high-priority
        "threats": [MOCK_INSIGHTS["threats"][0]],
        "quick_wins": [MOCK_INSIGHTS["quick_wins"][0]],
        "provider_strategies": [],
        "content_recommendations": [],
        "prompt_edit_suggestions": [],
    }
    respx.get("https://test.nudg3.ai/api/v1/reports/rpt-001/insights").mock(
        return_value=httpx.Response(200, json={"success": True, "data": filtered})
    )

    result = await execute_get_insights(client=client, report_id="rpt-001", priority="high")
    assert "filters_applied" in result
    assert result["filters_applied"]["priority"] == "high"


@respx.mock
@pytest.mark.asyncio
async def test_get_insights_empty(client):
    respx.get("https://test.nudg3.ai/api/v1/reports/rpt-001/insights").mock(
        return_value=httpx.Response(200, json={"success": True, "data": {}})
    )

    result = await execute_get_insights(client=client, report_id="rpt-001")
    assert "No AI insights available" in result["message"]


# ─── Actions tool (mocked HTTP) ──────────────────────────────────────


@respx.mock
@pytest.mark.asyncio
async def test_get_actions_list(client):
    respx.get("https://test.nudg3.ai/api/v1/actions").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "actions": [MOCK_ACTION],
                "pagination": {"page": 1, "per_page": 20, "total": 1, "total_pages": 1, "has_next": False, "has_prev": False},
            },
        })
    )

    result = await execute_get_actions(client=client)
    assert len(result["actions"]) == 1
    assert result["actions"][0]["id"] == "act-001"
    assert result["status_breakdown"]["pending"] == 1
    assert result["priority_breakdown"]["high"] == 1
    assert "suggested_investigations" in result


@respx.mock
@pytest.mark.asyncio
async def test_get_actions_detail(client):
    respx.get("https://test.nudg3.ai/api/v1/actions/act-001").mock(
        return_value=httpx.Response(200, json={"success": True, "data": MOCK_ACTION})
    )

    result = await execute_get_actions(client=client, action_id="act-001")
    assert result["action"]["id"] == "act-001"
    assert result["action"]["action_context"]["insight"] == "Competitors appear in 80% of queries"
    # Should suggest viewing source report
    assert any(s["tool"] == "get_reports" for s in result["suggested_investigations"])
    assert any(s["tool"] == "get_insights" for s in result["suggested_investigations"])


@respx.mock
@pytest.mark.asyncio
async def test_get_actions_filtered(client):
    respx.get("https://test.nudg3.ai/api/v1/actions").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "actions": [MOCK_ACTION],
                "pagination": {"page": 1, "per_page": 20, "total": 1, "total_pages": 1, "has_next": False, "has_prev": False},
            },
        })
    )

    result = await execute_get_actions(client=client, status="pending", priority="high")
    assert "filters_applied" in result
    assert result["filters_applied"]["status"] == "pending"
    assert result["filters_applied"]["priority"] == "high"


@respx.mock
@pytest.mark.asyncio
async def test_get_actions_empty_list(client):
    respx.get("https://test.nudg3.ai/api/v1/actions").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "actions": [],
                "pagination": {"page": 1, "per_page": 20, "total": 0, "total_pages": 0, "has_next": False, "has_prev": False},
            },
        })
    )

    result = await execute_get_actions(client=client)
    assert result["actions"] == []
    assert result["status_breakdown"] == {}


# ─── Error handling (403 scope error for insights) ───────────────────


@respx.mock
@pytest.mark.asyncio
async def test_get_reports_scope_error(client):
    respx.get("https://test.nudg3.ai/api/v1/reports").mock(
        return_value=httpx.Response(403, json={
            "success": False,
            "error": {"code": "INSUFFICIENT_SCOPE", "message": "Missing read:insights scope"},
        })
    )

    with pytest.raises(httpx.HTTPStatusError):
        await execute_get_reports(client=client)
