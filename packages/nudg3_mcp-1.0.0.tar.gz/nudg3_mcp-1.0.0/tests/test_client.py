"""Tests for NudgClient HTTP wrapper."""

import pytest
import respx
import httpx

from nudg3_mcp.client import NudgClient


@pytest.fixture
def client():
    return NudgClient(
        api_key="nudg3_test_ak_abc123",
        base_url="https://test.nudg3.ai",
        timeout=5.0,
    )


@respx.mock
@pytest.mark.asyncio
async def test_get_unwraps_envelope(client):
    respx.get("https://test.nudg3.ai/api/v1/filters").mock(
        return_value=httpx.Response(
            200,
            json={
                "success": True,
                "data": {"providers": ["ChatGPT", "Gemini"]},
                "message": "Success",
            },
        )
    )

    result = await client.get_filters()
    assert "providers" in result
    assert "ChatGPT" in result["providers"]


@respx.mock
@pytest.mark.asyncio
async def test_rate_limit_headers_captured(client):
    respx.get("https://test.nudg3.ai/api/v1/filters").mock(
        return_value=httpx.Response(
            200,
            json={"success": True, "data": {}, "message": "Success"},
            headers={
                "X-RateLimit-Remaining-Minute": "28",
                "X-RateLimit-Limit-Minute": "30",
                "X-RateLimit-Remaining-Hour": "295",
                "X-RateLimit-Limit-Hour": "300",
            },
        )
    )

    await client.get_filters()
    info = client.rate_limit_info
    assert info["minute_remaining"] == 28
    assert info["minute_limit"] == 30
    assert info["hour_remaining"] == 295


@respx.mock
@pytest.mark.asyncio
async def test_auth_header_sent(client):
    route = respx.get("https://test.nudg3.ai/api/v1/filters").mock(
        return_value=httpx.Response(
            200,
            json={"success": True, "data": {}, "message": "Success"},
        )
    )

    await client.get_filters()
    assert route.calls[0].request.headers["Authorization"] == "Bearer nudg3_test_ak_abc123"
    assert route.calls[0].request.headers["X-Client-Type"] == "mcp"


@respx.mock
@pytest.mark.asyncio
async def test_http_error_raises(client):
    respx.get("https://test.nudg3.ai/api/v1/filters").mock(
        return_value=httpx.Response(401, json={"error": "Unauthorized"})
    )

    with pytest.raises(httpx.HTTPStatusError):
        await client.get_filters()


@respx.mock
@pytest.mark.asyncio
async def test_none_params_excluded(client):
    route = respx.get("https://test.nudg3.ai/api/v1/dashboard").mock(
        return_value=httpx.Response(
            200,
            json={"success": True, "data": {"brands": {}}, "message": "Success"},
        )
    )

    await client.get_dashboard(start_date="2026-01-01", end_date=None)
    url = str(route.calls[0].request.url)
    assert "start_date=2026-01-01" in url
    assert "end_date" not in url
