"""Tests for investigation tools with mocked HTTP responses."""

import pytest
import respx
import httpx

from nudg3_mcp.client import NudgClient
from nudg3_mcp.tools.overview import execute_overview, _extract_brand_score, _detect_alerts
from nudg3_mcp.tools.competitors import execute_competitor_analysis
from nudg3_mcp.tools.prompts import execute_prompt_analysis
from nudg3_mcp.tools.sources import execute_source_analysis
from nudg3_mcp.tools.responses import execute_response_analysis
from nudg3_mcp.tools.metric_catalog import get_catalog
from nudg3_mcp.tools.date_utils import parse_date_range


@pytest.fixture
def client():
    return NudgClient(
        api_key="nudg3_test_ak_abc123",
        base_url="https://test.nudg3.ai",
        timeout=5.0,
    )


# ─── Catalog ────────────────────────────────────────────────────────────


def test_catalog_has_all_sections():
    catalog = get_catalog()
    assert "measures" in catalog
    assert "filters" in catalog
    assert "export_datasets" in catalog


def test_catalog_measure_count():
    catalog = get_catalog()
    assert len(catalog["measures"]) == 14


# ─── Date parsing ───────────────────────────────────────────────────────


def test_parse_relative():
    start, end = parse_date_range("7d")
    assert start < end


def test_parse_absolute():
    start, end = parse_date_range("2026-01-01:2026-03-01")
    assert start == "2026-01-01"
    assert end == "2026-03-01"


def test_parse_invalid():
    with pytest.raises(ValueError, match="Invalid date_range"):
        parse_date_range("invalid")


# ─── Brand score extraction ─────────────────────────────────────────────


MOCK_BRAND_METRICS = {
    "brand_id": "abc-123",
    "domain": "test.com",
    "sentiment": 0.58,
    "position": 1.05,
    "visibility_score_sma": {
        "2026-03-27": 30.0, "2026-03-28": 31.0, "2026-03-29": 32.0,
        "2026-03-30": 33.0, "2026-03-31": 34.0, "2026-04-01": 34.5,
        "2026-04-02": 34.2, "2026-04-03": 34.0,
    },
    "visibility_change": -1.85,
}


def test_extract_brand_score_current():
    score = _extract_brand_score("TestBrand", MOCK_BRAND_METRICS)
    assert score["name"] == "TestBrand"
    assert score["brand_id"] == "abc-123"
    assert score["visibility_sma"] == 34.0  # last value


def test_extract_brand_score_7d_change():
    score = _extract_brand_score("TestBrand", MOCK_BRAND_METRICS)
    # 34.0 (last) - 30.0 (8th from end) = 4.0
    assert score["visibility_7d_change"] == 4.0


def test_extract_brand_score_30d_change():
    score = _extract_brand_score("TestBrand", MOCK_BRAND_METRICS)
    assert score["visibility_30d_change"] == -1.85


# ─── Alert detection ────────────────────────────────────────────────────


def test_detect_alerts_big_gainer():
    organic = [{"name": "A", "visibility_30d_change": 7.5, "visibility_7d_change": 1.0}]
    alerts = _detect_alerts(organic, branded=[])
    assert len(alerts) == 1
    assert "+7.5" in alerts[0]
    assert "[Organic]" in alerts[0]


def test_detect_alerts_no_issues():
    organic = [{"name": "A", "visibility_30d_change": 1.0, "visibility_7d_change": 0.5}]
    alerts = _detect_alerts(organic, branded=[])
    assert alerts == []


def test_detect_alerts_weak_branded_sentiment():
    branded = [{"name": "A", "visibility_30d_change": 0, "sentiment": 0.3}]
    alerts = _detect_alerts(organic=[], branded=branded)
    assert any("[Branded]" in a and "sentiment" in a for a in alerts)


# ─── Overview tool ───────────────────────────────────────────────────────


MOCK_OVERALL_DASHBOARD = {
    "success": True,
    "data": {
        "brands": {
            "Nudg3": {**MOCK_BRAND_METRICS},
            "Competitor": {
                "brand_id": "def-456",
                "domain": "comp.com",
                "sentiment": 0.45,
                "position": 2.3,
                "visibility_score_sma": {"2026-04-03": 25.0},
                "visibility_change": 7.5,
            },
        },
    },
    "message": "Success",
}

# Organic: Nudg3 absent (zero organic visibility), only Competitor appears
MOCK_ORGANIC_DASHBOARD = {
    "success": True,
    "data": {
        "brands": {
            "Competitor": {
                "brand_id": "def-456",
                "domain": "comp.com",
                "sentiment": 0.45,
                "position": 2.3,
                "visibility_score_sma": {"2026-04-03": 25.0},
                "visibility_change": 7.5,
            },
        },
    },
    "message": "Success",
}

MOCK_BRANDED_DASHBOARD = {
    "success": True,
    "data": {
        "brands": {
            "Nudg3": {
                "brand_id": "abc-123",
                "domain": "test.com",
                "sentiment": 0.65,
                "position": 1.1,
                "visibility_score_sma": {"2026-04-03": 45.0},
                "visibility_change": 2.0,
            },
        },
    },
    "message": "Success",
}

MOCK_SOURCES = {
    "success": True,
    "data": {
        "sources": [
            {"domain": "test.com", "usage_percentage": 28.2, "source_type": "reference"},
            {"domain": "reddit.com", "usage_percentage": 12.8, "source_type": "social"},
        ],
        "total_sources": 50,
    },
    "message": "Success",
}


def _mock_overview_endpoints():
    """Set up mocks for overview's 4 parallel calls: overall, organic, branded, sources."""
    respx.get("https://test.nudg3.ai/api/v1/dashboard").mock(
        side_effect=[
            httpx.Response(200, json=MOCK_OVERALL_DASHBOARD),   # overall
            httpx.Response(200, json=MOCK_ORGANIC_DASHBOARD),   # organic (discovery)
            httpx.Response(200, json=MOCK_BRANDED_DASHBOARD),   # branded (research+purchase)
        ]
    )
    respx.get("https://test.nudg3.ai/api/v1/sources").mock(
        return_value=httpx.Response(200, json=MOCK_SOURCES)
    )


@respx.mock
@pytest.mark.asyncio
async def test_overview_returns_organic_and_branded(client):
    _mock_overview_endpoints()

    result = await execute_overview(client)

    assert "workspace" in result
    assert "organic_visibility" in result
    assert "branded_visibility" in result
    assert "top_sources" in result
    assert "alerts" in result
    assert "suggested_investigations" in result

    # Primary brand should be Nudg3 (from overall), not Competitor
    assert result["workspace"]["primary_brand"] == "Nudg3"

    # Both sections should have descriptions
    assert "unbranded" in result["organic_visibility"]["description"].lower()
    assert "research" in result["branded_visibility"]["description"].lower()


@respx.mock
@pytest.mark.asyncio
async def test_overview_detects_primary_missing_from_organic(client):
    """When primary brand is absent from organic results, flag it."""
    _mock_overview_endpoints()

    result = await execute_overview(client)

    # Nudg3 is in overall but not in organic mock — should trigger alert
    assert any("Nudg3" in a and "does not appear in organic" in a for a in result["alerts"])


@respx.mock
@pytest.mark.asyncio
async def test_overview_detects_organic_gainer(client):
    _mock_overview_endpoints()

    result = await execute_overview(client)
    assert any("Competitor" in a and "7.5" in a for a in result["alerts"])


@respx.mock
@pytest.mark.asyncio
async def test_overview_suggests_investigations(client):
    _mock_overview_endpoints()

    result = await execute_overview(client)
    tools_suggested = [s["tool"] for s in result["suggested_investigations"]]
    assert "analyze_prompts" in tools_suggested


# ─── Competitors tool ────────────────────────────────────────────────────


@respx.mock
@pytest.mark.asyncio
async def test_competitors_returns_rankings(client):
    respx.get("https://test.nudg3.ai/api/v1/dashboard").mock(
        return_value=httpx.Response(200, json=MOCK_ORGANIC_DASHBOARD)
    )

    result = await execute_competitor_analysis(client)

    assert "rankings" in result
    assert "context" in result
    assert "organic" in result["context"].lower()
    assert result["rankings"][0]["rank"] == 1
    positions = [r["position"] for r in result["rankings"] if r["position"] > 0]
    assert positions == sorted(positions)


@respx.mock
@pytest.mark.asyncio
async def test_competitors_no_discovery_data(client):
    """When no discovery data exists, return clear message, not fallback."""
    respx.get("https://test.nudg3.ai/api/v1/dashboard").mock(
        return_value=httpx.Response(200, json={"success": True, "data": {"brands": {}}, "message": "Success"})
    )

    result = await execute_competitor_analysis(client)

    assert result["rankings"] == []
    assert "no organic" in result["context"].lower() or "no organic" in result.get("detail", "").lower()


# ─── Prompts tool ────────────────────────────────────────────────────────


MOCK_PROMPTS = {
    "success": True,
    "data": {
        "prompts": [
            {"id": "p1", "template_text": "best AI monitoring tools", "tags": ["discovery"],
             "visibility_percentage": 65.2, "sentiment_avg": 0.72, "avg_position": 1.2, "total_responses": 100},
            {"id": "p2", "template_text": "Nudg3 vs Semrush comparison", "tags": ["research"],
             "visibility_percentage": 45.0, "sentiment_avg": 0.55, "avg_position": 2.1, "total_responses": 50},
            {"id": "p3", "template_text": "best smartphones for business", "tags": ["discovery"],
             "visibility_percentage": 0, "sentiment_avg": 0, "avg_position": 0, "total_responses": 20},
        ],
    },
    "message": "Success",
}


@respx.mock
@pytest.mark.asyncio
async def test_prompts_groups_by_stage(client):
    respx.get("https://test.nudg3.ai/api/v1/prompts").mock(
        return_value=httpx.Response(200, json=MOCK_PROMPTS)
    )

    result = await execute_prompt_analysis(client, brand_id="abc-123")

    assert "by_stage" in result
    assert result["total_prompts"] == 3
    assert "discovery" in result["by_stage"]
    assert result["by_stage"]["discovery"]["count"] == 2


@respx.mock
@pytest.mark.asyncio
async def test_prompts_flags_underperformers(client):
    respx.get("https://test.nudg3.ai/api/v1/prompts").mock(
        return_value=httpx.Response(200, json=MOCK_PROMPTS)
    )

    result = await execute_prompt_analysis(client, brand_id="abc-123")

    underperformers = result["by_stage"]["discovery"]["underperformers"]
    assert len(underperformers) >= 1
    assert any("zero visibility" in u["reasons"] for u in underperformers)


# ─── Sources tool ────────────────────────────────────────────────────────


@respx.mock
@pytest.mark.asyncio
async def test_sources_returns_top_domains(client):
    respx.get("https://test.nudg3.ai/api/v1/sources").mock(
        return_value=httpx.Response(200, json=MOCK_SOURCES)
    )

    result = await execute_source_analysis(client)

    assert "top_domains" in result
    assert result["top_domains"][0]["domain"] == "test.com"
    assert "content_gaps" in result
    assert "suggested_investigations" in result


# ─── Responses tool ──────────────────────────────────────────────────────


MOCK_RESPONSES = {
    "success": True,
    "data": {
        "provider_responses": [
            {"id": "r1", "provider": "ChatGPT", "response_text": "Nudg3 is a brand monitoring platform " * 20,
             "brand_mentions": [{"name": "Nudg3"}], "sentiment": 0.71, "prompt_text": "best AI tools"},
            {"id": "r2", "provider": "Gemini", "response_text": "Several tools exist for brand monitoring...",
             "brand_mentions": [], "sentiment": 0.45, "prompt_text": "brand monitoring comparison"},
        ],
        "total_responses": 200,
    },
    "message": "Success",
}


@respx.mock
@pytest.mark.asyncio
async def test_responses_groups_by_provider(client):
    respx.get("https://test.nudg3.ai/api/v1/responses").mock(
        return_value=httpx.Response(200, json=MOCK_RESPONSES)
    )

    result = await execute_response_analysis(client)

    assert "by_provider" in result
    assert "ChatGPT" in result["by_provider"]
    assert "Gemini" in result["by_provider"]
    assert result["total_responses"] == 200


@respx.mock
@pytest.mark.asyncio
async def test_responses_truncates_text(client):
    respx.get("https://test.nudg3.ai/api/v1/responses").mock(
        return_value=httpx.Response(200, json=MOCK_RESPONSES)
    )

    result = await execute_response_analysis(client)

    for provider, summary in result["by_provider"].items():
        for sample in summary["samples"]:
            assert len(sample["text"]) <= 303  # 300 + "..."


@respx.mock
@pytest.mark.asyncio
async def test_responses_detects_patterns(client):
    respx.get("https://test.nudg3.ai/api/v1/responses").mock(
        return_value=httpx.Response(200, json=MOCK_RESPONSES)
    )

    result = await execute_response_analysis(client)
    assert "patterns" in result
    assert isinstance(result["patterns"], list)
