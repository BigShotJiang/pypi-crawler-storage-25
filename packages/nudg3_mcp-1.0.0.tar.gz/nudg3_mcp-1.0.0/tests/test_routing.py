"""Tests for measure → endpoint routing."""

import pytest

from nudg3_mcp.routing import MEASURE_ROUTES, resolve_routes, validate_requirements


def test_resolve_single_measure():
    routes = resolve_routes(["visibility_score"])
    assert "dashboard" in routes
    assert routes["dashboard"].method == "get_dashboard"


def test_resolve_multiple_dashboard_measures_deduplicates():
    """Multiple dashboard measures should resolve to a single endpoint call."""
    routes = resolve_routes(["visibility_score", "sentiment_avg", "mention_count"])
    assert len(routes) == 1
    assert "dashboard" in routes


def test_resolve_cross_endpoint_measures():
    """Measures from different endpoints should resolve to multiple routes."""
    routes = resolve_routes(["visibility_score", "source_citations"])
    assert len(routes) == 2
    assert "dashboard" in routes
    assert "sources" in routes


def test_resolve_unknown_measure_raises():
    with pytest.raises(ValueError, match="Unknown measure"):
        resolve_routes(["nonexistent_measure"])


def test_validate_requirements_passes():
    routes = resolve_routes(["visibility_score"])
    errors = validate_requirements(routes, {})
    assert errors == []


def test_validate_requirements_missing_brand_id():
    routes = resolve_routes(["prompt_performance"])
    errors = validate_requirements(routes, {})
    assert len(errors) == 1
    assert "brand_id" in errors[0]


def test_validate_requirements_with_brand_id():
    routes = resolve_routes(["prompt_performance"])
    errors = validate_requirements(routes, {"brand_id": "some-uuid"})
    assert errors == []


def test_all_measures_have_method():
    """Every measure in the route map should reference a valid method name."""
    for name, route in MEASURE_ROUTES.items():
        assert route.method, f"Measure '{name}' has no method"
        assert route.endpoint, f"Measure '{name}' has no endpoint"
