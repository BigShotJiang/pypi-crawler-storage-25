"""Shared date parsing utility."""

import re
from datetime import date, timedelta


def parse_date_range(date_range: str) -> tuple[str, str]:
    """Parse date_range into (start_date, end_date) ISO strings.

    Accepts:
      - Relative: "7d", "30d", "90d"
      - Absolute: "YYYY-MM-DD:YYYY-MM-DD"
    """
    relative_match = re.match(r"^(\d+)d$", date_range)
    if relative_match:
        days = int(relative_match.group(1))
        end = date.today()
        start = end - timedelta(days=days)
        return start.isoformat(), end.isoformat()

    if ":" in date_range:
        parts = date_range.split(":")
        if len(parts) == 2:
            return parts[0], parts[1]

    raise ValueError(
        f"Invalid date_range: '{date_range}'. "
        f"Use relative (e.g. '7d', '30d') or absolute (e.g. '2026-01-01:2026-03-01')"
    )
