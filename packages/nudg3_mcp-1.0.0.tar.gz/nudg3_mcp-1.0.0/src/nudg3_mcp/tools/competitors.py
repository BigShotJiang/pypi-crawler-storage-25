"""
analyze_competitors — competitive landscape on organic (discovery/unbranded) queries.

Strictly uses discovery-tagged data. Does NOT fall back to all prompts,
because branded data inflates metrics and misrepresents organic discoverability.
"""

import logging
from typing import Any

from ..client import NudgClient
from .date_utils import parse_date_range

logger = logging.getLogger(__name__)


def _collapse_visibility(metrics: dict[str, Any]) -> float:
    """Collapse visibility_score dict to single average."""
    vis = metrics.get("visibility_score", {})
    if not vis:
        return 0
    return round(sum(vis.values()) / len(vis), 1)


async def execute_competitor_analysis(
    client: NudgClient,
    date_range: str = "30d",
    providers: list[str] | None = None,
) -> dict[str, Any]:
    """Execute competitive landscape analysis — organic queries only."""
    start_date, end_date = parse_date_range(date_range)

    # Strictly discovery (unbranded) — no fallback
    dashboard = await client.get_dashboard(
        start_date=start_date,
        end_date=end_date,
        models=providers,
        tags=["discovery"],
    )

    brands_raw = dashboard.get("brands", {})

    # If no discovery data, return clear message
    if not brands_raw:
        return {
            "context": "No organic (discovery/unbranded) data available.",
            "detail": (
                "This workspace has no prompts tagged as 'discovery'. "
                "Organic competitive analysis requires unbranded queries — "
                "branded prompts inflate rankings and don't reflect true AI discoverability. "
                "Add discovery-tagged prompts to enable organic competitive tracking."
            ),
            "rankings": [],
            "gaps": [],
            "movers": {"gaining": [], "losing": []},
            "suggested_investigations": [
                {"tool": "analyze_prompts", "params": {"visibility_type": "all"}, "reason": "Check what prompts exist and how they're tagged"},
            ],
            "date_range": {"start": start_date, "end": end_date},
            "rate_limit": client.rate_limit_info,
        }

    # Build rankings
    rankings = []
    for name, metrics in brands_raw.items():
        rankings.append({
            "name": name,
            "brand_id": metrics.get("brand_id", ""),
            "visibility": _collapse_visibility(metrics),
            "position": round(metrics.get("position") or 0, 2),
            "sentiment": round(metrics.get("sentiment") or 0, 2),
            "visibility_30d_change": metrics.get("visibility_change"),
        })

    # Sort by position (lower = better), 0 = worst
    rankings.sort(key=lambda x: x["position"] if x["position"] > 0 else 999)

    for i, r in enumerate(rankings, 1):
        r["rank"] = i

    # Identify gaps and movers
    primary = rankings[0] if rankings else None
    gaps = []
    gaining = []
    losing = []

    for r in rankings[1:]:
        if primary and r["position"] > 0 and r["position"] < primary["position"]:
            gaps.append(f"{r['name']} outranks {primary['name']} (position {r['position']} vs {primary['position']})")

        change = r.get("visibility_30d_change")
        if change is not None:
            if change > 3:
                gaining.append(f"{r['name']} +{change:.1f}pts")
            elif change < -3:
                losing.append(f"{r['name']} {change:.1f}pts")

    # Suggestions
    suggestions = []
    if primary:
        suggestions.append({
            "tool": "analyze_prompts",
            "params": {"brand_id": primary["brand_id"], "visibility_type": "organic"},
            "reason": f"See which discovery prompts drive {primary['name']}'s organic ranking",
        })
    if gaining:
        suggestions.append({
            "tool": "analyze_responses",
            "params": {"tags": ["discovery"]},
            "reason": "Read how AI models describe competitors on unbranded queries",
        })

    return {
        "context": "Rankings based on organic (discovery/unbranded) queries only — measures true AI discoverability without brand name inflation.",
        "rankings": rankings,
        "gaps": gaps,
        "movers": {"gaining": gaining, "losing": losing},
        "suggested_investigations": suggestions,
        "date_range": {"start": start_date, "end": end_date},
        "rate_limit": client.rate_limit_info,
    }
