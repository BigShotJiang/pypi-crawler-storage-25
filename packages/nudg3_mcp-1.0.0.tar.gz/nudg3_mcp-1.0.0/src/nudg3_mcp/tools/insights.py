"""
get_insights -- AI-generated actionable insights from a visibility report.

Returns categorized opportunities, threats, quick wins, provider strategies,
content recommendations, and prompt edit suggestions. Supports filtering
by type, priority, and category.
"""

import logging
from typing import Any, Optional

from ..client import NudgClient

logger = logging.getLogger(__name__)


def _count_items(insights: dict[str, Any]) -> dict[str, int]:
    """Count items per insight category."""
    categories = [
        "opportunities", "threats", "quick_wins",
        "provider_strategies", "content_recommendations",
        "prompt_edit_suggestions",
    ]
    return {
        cat: len(insights.get(cat, []))
        for cat in categories
        if insights.get(cat)
    }


def _summarize_insight_list(items: list[dict[str, Any]], max_items: int = 5) -> list[dict[str, Any]]:
    """Compact insight items to key fields, capped for token efficiency."""
    result = []
    for item in items[:max_items]:
        entry: dict[str, Any] = {"title": item.get("title", "Untitled")}
        if item.get("description"):
            entry["description"] = item["description"]
        if item.get("priority"):
            entry["priority"] = item["priority"]
        if item.get("category"):
            entry["category"] = item["category"]
        if item.get("impact"):
            entry["impact"] = item["impact"]
        result.append(entry)
    return result


def _summarize_provider_strategies(strategies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Compact provider strategy items."""
    return [
        {
            "provider": s.get("provider", "Unknown"),
            "strategy": s.get("strategy", ""),
            "priority": s.get("priority"),
            "current_score": s.get("current_score"),
        }
        for s in strategies[:6]
    ]


def _summarize_content_recommendations(recs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Compact content recommendation items."""
    return [
        {
            "title": r.get("title", "Untitled"),
            "description": r.get("description", ""),
            "content_format": r.get("content_format"),
            "target_platform": r.get("target_platform"),
            "priority": r.get("priority"),
        }
        for r in recs[:5]
    ]


async def execute_get_insights(
    client: NudgClient,
    report_id: str,
    type: Optional[str] = None,
    priority: Optional[str] = None,
    category: Optional[str] = None,
) -> dict[str, Any]:
    """Execute insight retrieval for a report."""

    data = await client.get_report_insights(
        report_id=report_id,
        type=type,
        priority=priority,
        category=category,
    )

    if not data or data.get("schema_version") is None and not any(
        data.get(k) for k in ["opportunities", "threats", "quick_wins"]
    ):
        return {
            "report_id": report_id,
            "message": "No AI insights available for this report. Insights are generated during visibility analysis and may not exist for older reports.",
            "suggested_investigations": [
                {
                    "tool": "get_reports",
                    "params": {"latest": True},
                    "reason": "Check the latest report which is more likely to have insights",
                },
            ],
            "rate_limit": client.rate_limit_info,
        }

    counts = _count_items(data)

    # Build response with summarized items per category
    result: dict[str, Any] = {
        "report_id": report_id,
        "counts": counts,
    }

    if data.get("opportunities"):
        result["opportunities"] = _summarize_insight_list(data["opportunities"])
    if data.get("threats"):
        result["threats"] = _summarize_insight_list(data["threats"])
    if data.get("quick_wins"):
        result["quick_wins"] = _summarize_insight_list(data["quick_wins"])
    if data.get("provider_strategies"):
        result["provider_strategies"] = _summarize_provider_strategies(data["provider_strategies"])
    if data.get("content_recommendations"):
        result["content_recommendations"] = _summarize_content_recommendations(data["content_recommendations"])
    if data.get("prompt_edit_suggestions"):
        result["prompt_edit_suggestions"] = _summarize_insight_list(data["prompt_edit_suggestions"])

    # Suggestions
    suggestions = []

    if data.get("opportunities"):
        suggestions.append({
            "tool": "get_actions",
            "params": {"recommendation_type": "opportunity", "status": "pending"},
            "reason": "See which opportunities have already been turned into actions",
        })

    if data.get("threats"):
        suggestions.append({
            "tool": "get_actions",
            "params": {"recommendation_type": "threat", "priority": "high"},
            "reason": "Check if high-priority threats have been addressed",
        })

    if data.get("provider_strategies"):
        suggestions.append({
            "tool": "get_overview",
            "reason": "Compare current provider scores to the strategies recommended here",
        })

    if data.get("content_recommendations"):
        suggestions.append({
            "tool": "get_actions",
            "params": {"content_format": "blog_post"},
            "reason": "See content actions in progress",
        })

    # Always suggest viewing the source report
    suggestions.append({
        "tool": "get_reports",
        "params": {"report_id": report_id},
        "reason": "View the full report metrics behind these insights",
    })

    result["suggested_investigations"] = suggestions
    result["rate_limit"] = client.rate_limit_info

    # Filters applied
    applied = {}
    if type:
        applied["type"] = type
    if priority:
        applied["priority"] = priority
    if category:
        applied["category"] = category
    if applied:
        result["filters_applied"] = applied

    return result
