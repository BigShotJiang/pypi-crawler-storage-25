"""
get_overview — compact workspace health check with investigation suggestions.

First tool any agent should call. Returns two distinct visibility views:
  - Organic visibility (discovery/unbranded queries) — the competitive metric
  - Branded visibility (research + purchase queries) — brand presence when asked by name

Organic is presented first per the Nudg3 visibility analysis system card:
"Executive summary must lead with organic competitive rank, not overall."
"""

import asyncio
import logging
from typing import Any

from ..client import NudgClient
from .date_utils import parse_date_range

logger = logging.getLogger(__name__)


def _extract_brand_score(name: str, metrics: dict[str, Any]) -> dict[str, Any]:
    """Collapse a brand's raw dashboard metrics into compact stats."""
    vis_sma = metrics.get("visibility_score_sma", {})
    vis_raw = metrics.get("visibility_score", {})
    sentiment_sma = metrics.get("sentiment_data_sma", {})

    sma_values = list(vis_sma.values()) if vis_sma else list(vis_raw.values())
    current_vis = round(sma_values[-1], 1) if sma_values else 0

    vis_7d_change = round(sma_values[-1] - sma_values[-8], 1) if len(sma_values) >= 8 else None

    vis_30d_change = metrics.get("visibility_change")

    sent_values = list(sentiment_sma.values()) if sentiment_sma else []
    current_sentiment = round(sent_values[-1] / 100, 2) if sent_values else (metrics.get("sentiment") or 0)

    return {
        "name": name,
        "brand_id": metrics.get("brand_id", ""),
        "domain": metrics.get("domain", ""),
        "visibility_sma": current_vis,
        "visibility_7d_change": vis_7d_change,
        "visibility_30d_change": vis_30d_change,
        "sentiment": round(current_sentiment, 2) if isinstance(current_sentiment, float) else current_sentiment,
        "position": round(metrics.get("position") or 0, 2),
    }


def _extract_scores_from_dashboard(dashboard: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract and sort brand scores from a dashboard response."""
    brands_raw = dashboard.get("brands", {})
    scores = [_extract_brand_score(name, metrics) for name, metrics in brands_raw.items()]
    scores.sort(key=lambda x: x["visibility_sma"], reverse=True)
    return scores


def _detect_alerts(
    organic: list[dict[str, Any]],
    branded: list[dict[str, Any]],
) -> list[str]:
    """Detect noteworthy patterns across both visibility types."""
    alerts = []

    for s in organic:
        change_30d = s.get("visibility_30d_change")
        change_7d = s.get("visibility_7d_change")

        if change_30d is not None and change_30d > 5:
            alerts.append(f"[Organic] {s['name']} gained +{change_30d:.1f} pts in 30d — fast mover on unbranded queries")
        elif change_30d is not None and change_30d < -5:
            alerts.append(f"[Organic] {s['name']} dropped {change_30d:.1f} pts in 30d on unbranded queries")

        if change_7d is not None and abs(change_7d) > 3:
            direction = "up" if change_7d > 0 else "down"
            alerts.append(f"[Organic] {s['name']} moved {direction} {abs(change_7d):.1f} pts in 7 days")

    for s in branded:
        change_30d = s.get("visibility_30d_change")
        if change_30d is not None and change_30d < -5:
            alerts.append(f"[Branded] {s['name']} branded visibility dropped {change_30d:.1f} pts — AI narrative may be shifting")

        if s.get("sentiment") is not None and s["sentiment"] < 0.4:
            alerts.append(f"[Branded] {s['name']} has weak branded sentiment ({s['sentiment']:.2f}) — investigate AI narrative")

    return alerts


def _suggest_investigations(
    organic: list[dict[str, Any]],
    branded: list[dict[str, Any]],
    top_sources: list,
) -> list[dict[str, Any]]:
    """Generate investigation suggestions based on both visibility types."""
    suggestions = []
    primary_organic = organic[0] if organic else None
    primary_branded = branded[0] if branded else None

    # Organic: competitor gaining
    competitors = organic[1:] if len(organic) > 1 else []
    gainers = [c for c in competitors if (c.get("visibility_30d_change") or 0) > 3]
    if gainers:
        g = max(gainers, key=lambda x: x.get("visibility_30d_change", 0))
        suggestions.append({
            "tool": "analyze_competitors",
            "reason": f"{g['name']} gained +{g['visibility_30d_change']:.1f} pts organically — see competitive rankings on unbranded queries",
        })

    # Organic: prompt analysis
    if primary_organic:
        suggestions.append({
            "tool": "analyze_prompts",
            "params": {"brand_id": primary_organic["brand_id"], "visibility_type": "organic"},
            "reason": f"See which unbranded prompts drive {primary_organic['name']}'s organic position",
        })

    # Branded: if sentiment is weak
    if primary_branded and primary_branded.get("sentiment", 1) < 0.5:
        suggestions.append({
            "tool": "analyze_responses",
            "params": {"tags": ["research", "purchase"]},
            "reason": f"Branded sentiment is weak ({primary_branded['sentiment']:.2f}) — investigate what AI says about {primary_branded['name']}",
        })

    # Source analysis
    if top_sources and primary_organic:
        own_domain = primary_organic.get("domain", "")
        own_pct = next((s["usage_pct"] for s in top_sources if s["domain"] == own_domain), 0)
        if own_pct > 0:
            suggestions.append({
                "tool": "analyze_sources",
                "reason": f"Your domain ({own_domain}) accounts for {own_pct:.1f}% of citations — check content gaps",
            })

    return suggestions


def _identify_primary_brand(overall_scores: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Identify the primary brand from overall dashboard scores.

    The primary brand is the workspace owner — not necessarily the highest
    scoring brand. We identify it as the brand whose domain appears as
    the top-cited source (the workspace owner's domain dominates citations),
    or fall back to the first brand in the overall results if unclear.

    In practice the public API returns the primary brand first or it can
    be identified by domain matching the workspace. Since we don't have
    a dedicated primary-brand endpoint on the public API, we use a heuristic:
    the brand that appears in overall but NOT in organic (discovery) results
    is likely the primary brand (competitors appear in discovery; the primary
    brand may not if it lacks organic discoverability).
    """
    # Simple: return first brand from overall — the API consistently
    # returns the primary brand in the overall dashboard
    return overall_scores[0] if overall_scores else None


async def execute_overview(
    client: NudgClient,
    date_range: str = "30d",
    providers: list[str] | None = None,
) -> dict[str, Any]:
    """Execute the overview health check with organic/branded split."""
    start_date, end_date = parse_date_range(date_range)

    base_kwargs: dict[str, Any] = {
        "start_date": start_date,
        "end_date": end_date,
        "models": providers,
    }

    # Parallel fetch: overall (for primary brand ID) + organic + branded + sources (organic-filtered)
    overall_task = client.get_dashboard(**base_kwargs)
    organic_task = client.get_dashboard(**base_kwargs, tags=["discovery"])
    branded_task = client.get_dashboard(**base_kwargs, tags=["research", "purchase"])
    sources_task = client.get_sources(**base_kwargs, tags=["discovery"], per_page=5)

    results = await asyncio.gather(
        overall_task, organic_task, branded_task, sources_task,
        return_exceptions=True,
    )

    overall_dash = results[0] if not isinstance(results[0], Exception) else {}
    organic_dash = results[1] if not isinstance(results[1], Exception) else {}
    branded_dash = results[2] if not isinstance(results[2], Exception) else {}
    sources_data = results[3] if not isinstance(results[3], Exception) else {}

    # Extract scores
    overall_scores = _extract_scores_from_dashboard(overall_dash)
    organic_scores = _extract_scores_from_dashboard(organic_dash)
    branded_scores = _extract_scores_from_dashboard(branded_dash)

    organic_available = bool(organic_scores and any(s["visibility_sma"] > 0 for s in organic_scores))
    branded_available = bool(branded_scores and any(s["visibility_sma"] > 0 for s in branded_scores))

    # Primary brand from overall dashboard (not from organic — primary may not appear there)
    primary = _identify_primary_brand(overall_scores)
    primary_name = primary["name"] if primary else "Unknown"
    primary_id = primary["brand_id"] if primary else ""

    # Check if primary brand is missing from organic results
    organic_brand_names = {s["name"] for s in organic_scores}
    primary_missing_from_organic = primary_name != "Unknown" and primary_name not in organic_brand_names

    # Top sources (filtered to organic/discovery)
    source_list = sources_data.get("sources", []) if isinstance(sources_data, dict) else []
    top_sources = [
        {"domain": s.get("domain", ""), "usage_pct": round(s.get("usage_percentage", 0), 1)}
        for s in source_list[:5]
    ]

    # Workspace info — always derived from overall, not organic
    workspace = {
        "primary_brand": primary_name,
        "primary_brand_id": primary_id,
        "competitors": [
            {"name": s["name"], "brand_id": s["brand_id"]}
            for s in overall_scores if s["name"] != primary_name
        ],
    }

    alerts = _detect_alerts(organic_scores, branded_scores)

    # Add alert if primary brand is absent from organic results
    if primary_missing_from_organic:
        alerts.insert(0, (
            f"[Organic] {primary_name} does not appear in organic (discovery) results — "
            f"competitors are visible on unbranded queries but {primary_name} is not yet. "
            f"This is the most critical gap to address."
        ))

    suggestions = _suggest_investigations(organic_scores, branded_scores, top_sources)

    # If primary is missing from organic, add specific suggestion
    if primary_missing_from_organic and primary_id:
        suggestions.insert(0, {
            "tool": "analyze_prompts",
            "params": {"brand_id": primary_id, "visibility_type": "all"},
            "reason": f"{primary_name} has zero organic visibility — investigate prompt coverage and collection status",
        })

    response: dict[str, Any] = {
        "workspace": workspace,
        "organic_visibility": {
            "description": "Unbranded/discovery queries — measures whether AI can find your brand without being asked about it by name. This is the true competitive metric.",
            "available": organic_available,
            "brand_scores": organic_scores,
        },
        "branded_visibility": {
            "description": "Research + purchase queries — measures what AI says when someone asks about your brand by name. Covers evaluation, comparison, and buy-intent queries.",
            "available": branded_available,
            "brand_scores": branded_scores,
        },
        "top_sources": top_sources,
        "alerts": alerts,
        "suggested_investigations": suggestions,
        "date_range": {"start": start_date, "end": end_date},
        "rate_limit": client.rate_limit_info,
    }

    if not organic_available and not branded_available:
        response["warning"] = (
            "No data returned for either organic or branded visibility. "
            "This workspace may not have prompts tagged by funnel stage (discovery/research/purchase). "
            "Use analyze_prompts to see all prompts regardless of tagging."
        )

    return response
