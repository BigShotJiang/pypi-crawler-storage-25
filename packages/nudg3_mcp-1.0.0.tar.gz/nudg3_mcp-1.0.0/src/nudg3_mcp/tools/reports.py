"""
get_reports -- list and inspect visibility audit reports.

Routes to list, latest, or detail endpoints based on params.
Returns scores, competitive position, executive summaries,
and suggests drilling into insights for reports that have them.
"""

import logging
from typing import Any, Optional

from ..client import NudgClient

logger = logging.getLogger(__name__)


def _format_report_summary(report: dict[str, Any]) -> dict[str, Any]:
    """Compact a report dict into the key fields for list display."""
    return {
        "id": report.get("id", ""),
        "report_type": report.get("report_type", "unknown"),
        "brand_name": report.get("brand_name"),
        "visibility_score": report.get("visibility_score"),
        "competitive_position": report.get("competitive_position"),
        "mention_rate": report.get("mention_rate"),
        "analysis_confidence": report.get("analysis_confidence"),
        "has_insights": report.get("has_insights", False),
        "calculated_at": report.get("calculated_at"),
    }


def _format_report_detail(report: dict[str, Any]) -> dict[str, Any]:
    """Full report detail with all metric fields."""
    result = _format_report_summary(report)
    result.update({
        "total_mentions": report.get("total_mentions"),
        "total_responses": report.get("total_responses"),
        "executive_summary": report.get("executive_summary"),
        "provider_scores": report.get("provider_scores"),
        "ranked_brands": report.get("ranked_brands"),
        "sentiment_summary": report.get("sentiment_summary"),
        "data_quality_notes": report.get("data_quality_notes"),
        "start_date": report.get("start_date"),
        "end_date": report.get("end_date"),
    })
    return result


async def execute_get_reports(
    client: NudgClient,
    report_id: Optional[str] = None,
    latest: bool = False,
    report_type: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    include_insights: bool = False,
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """Execute report retrieval -- routes to the right endpoint."""

    # Single report by ID
    if report_id:
        data = await client.get_report_detail(
            report_id=report_id,
            include_insights=include_insights,
        )
        if data is None:
            return {"error": True, "message": "Report not found"}

        report = _format_report_detail(data)
        if include_insights and "insights" in data:
            report["insights"] = data["insights"]

        suggestions = _build_detail_suggestions(report)
        return {
            "report": report,
            "suggested_investigations": suggestions,
            "rate_limit": client.rate_limit_info,
        }

    # Latest report shortcut
    if latest:
        data = await client.get_latest_report(
            report_type=report_type,
            include_insights=include_insights,
        )
        if data is None:
            return {
                "report": None,
                "message": "No reports found for this workspace",
                "suggested_investigations": [],
                "rate_limit": client.rate_limit_info,
            }

        report = _format_report_detail(data)
        if include_insights and "insights" in data:
            report["insights"] = data["insights"]

        suggestions = _build_detail_suggestions(report)
        return {
            "report": report,
            "suggested_investigations": suggestions,
            "rate_limit": client.rate_limit_info,
        }

    # Paginated list
    data = await client.get_reports(
        report_type=report_type,
        start_date=start_date,
        end_date=end_date,
        page=page,
        per_page=per_page,
    )

    reports_raw = data.get("reports", [])
    pagination = data.get("pagination", {})

    reports = [_format_report_summary(r) for r in reports_raw]
    reports_with_insights = [r for r in reports if r.get("has_insights")]

    suggestions = []
    if reports_with_insights:
        top = reports_with_insights[0]
        suggestions.append({
            "tool": "get_insights",
            "params": {"report_id": top["id"]},
            "reason": f"View AI-generated insights for the {top['report_type']} report ({top.get('brand_name', 'unknown')} at {top.get('visibility_score', '?')}%)",
        })
    if reports:
        suggestions.append({
            "tool": "get_reports",
            "params": {"report_id": reports[0]["id"], "include_insights": True},
            "reason": "View full detail of the most recent report",
        })

    return {
        "reports": reports,
        "pagination": pagination,
        "total_with_insights": len(reports_with_insights),
        "suggested_investigations": suggestions,
        "rate_limit": client.rate_limit_info,
    }


def _build_detail_suggestions(report: dict[str, Any]) -> list[dict[str, Any]]:
    """Build investigation suggestions from a report detail."""
    suggestions = []
    report_id = report.get("id", "")

    if report.get("has_insights"):
        suggestions.append({
            "tool": "get_insights",
            "params": {"report_id": report_id},
            "reason": "View AI-generated opportunities, threats, and quick wins from this report",
        })
        suggestions.append({
            "tool": "get_insights",
            "params": {"report_id": report_id, "priority": "high"},
            "reason": "Focus on high-priority insights only",
        })

    suggestions.append({
        "tool": "get_actions",
        "params": {"source_report_id": report_id},
        "reason": "See which actions have been created from this report's insights",
    })

    if report.get("visibility_score") is not None:
        suggestions.append({
            "tool": "analyze_competitors",
            "reason": "Compare current competitive rankings to this report's snapshot",
        })

    return suggestions
