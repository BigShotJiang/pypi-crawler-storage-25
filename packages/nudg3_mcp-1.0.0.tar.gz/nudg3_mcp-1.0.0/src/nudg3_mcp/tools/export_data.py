"""
export_data tool — CSV export wrapper.

For small datasets, returns data inline. For large datasets (>10k rows),
returns statistics first and requires confirm_large_export=True to proceed.
"""

import logging
from typing import Any

from ..client import NudgClient
from ..routing import EXPORT_ROUTES

logger = logging.getLogger(__name__)

LARGE_EXPORT_THRESHOLD = 2_500
# MCP protocol response cap is ~1MB; budget conservatively after JSON wrapping
INLINE_BYTE_BUDGET = 500_000


async def execute_export(
    client: NudgClient,
    dataset: str,
    date_from: str,
    date_to: str,
    providers: list[str] | None = None,
    confirm_large_export: bool = False,
) -> dict[str, Any]:
    """Execute a data export.

    Returns CSV data inline for small exports, or statistics with a
    confirmation prompt for large ones.
    """
    # Validate dataset
    if dataset not in EXPORT_ROUTES:
        return {
            "error": True,
            "message": f"Unknown dataset: '{dataset}'. Available: {sorted(EXPORT_ROUTES.keys())}",
        }

    # Pre-flight: check row count
    try:
        stats = await client.get_export_statistics(dataset, date_from, date_to)
        row_count = stats.get("total_rows", 0)
    except Exception:
        # Statistics endpoint may not be available for all datasets
        row_count = 0

    # Large export guard
    if row_count > LARGE_EXPORT_THRESHOLD and not confirm_large_export:
        return {
            "large_export_warning": True,
            "row_count": row_count,
            "dataset": dataset,
            "date_range": f"{date_from} to {date_to}",
            "message": (
                f"This export contains {row_count:,} rows. "
                f"Set confirm_large_export=true to proceed, "
                f"or narrow the date range."
            ),
        }

    # Execute export
    method_name = EXPORT_ROUTES[dataset]
    method = getattr(client, method_name)

    kwargs: dict[str, Any] = {"date_from": date_from, "date_to": date_to}
    if providers:
        kwargs["models"] = providers

    try:
        csv_bytes = await method(**kwargs)
    except Exception as e:
        import httpx
        if isinstance(e, httpx.HTTPStatusError):
            if e.response.status_code == 403:
                return {
                    "error": True,
                    "message": "Insufficient scope. Export requires the export:data scope (Professional tier or above).",
                }
            return {
                "error": True,
                "message": f"Export failed ({e.response.status_code}): {e.response.text[:200]}",
            }
        raise

    csv_text = csv_bytes.decode("utf-8")

    # Count rows in result
    lines = csv_text.strip().split("\n")
    actual_rows = max(0, len(lines) - 1)  # subtract header

    # Hard byte cap — MCP responses over ~1MB are rejected by Claude Desktop.
    # Truncate from the bottom and surface a clear note so the caller narrows the range.
    truncated = False
    bytes_total = len(csv_text.encode("utf-8"))
    if bytes_total > INLINE_BYTE_BUDGET and len(lines) > 1:
        header = lines[0]
        kept: list[str] = [header]
        running = len(header.encode("utf-8")) + 1
        for line in lines[1:]:
            line_bytes = len(line.encode("utf-8")) + 1
            if running + line_bytes > INLINE_BYTE_BUDGET:
                break
            kept.append(line)
            running += line_bytes
        csv_text = "\n".join(kept)
        truncated_rows = actual_rows - (len(kept) - 1)
        actual_rows = len(kept) - 1
        truncated = True

    response: dict[str, Any] = {
        "dataset": dataset,
        "date_range": f"{date_from} to {date_to}",
        "row_count": actual_rows,
        "format": "csv",
        "data": csv_text,
        "metadata": {
            "rate_limit": client.rate_limit_info,
            "byte_size": len(csv_text.encode("utf-8")),
        },
    }

    if truncated:
        response["truncated"] = True
        response["truncated_rows"] = truncated_rows  # type: ignore[name-defined]
        response["message"] = (
            f"Response exceeded the {INLINE_BYTE_BUDGET // 1000}KB inline budget. "
            f"Returned the first {actual_rows:,} rows; {truncated_rows:,} rows omitted. "
            f"Narrow the date range or use the underlying export endpoint directly."
        )

    return response
