"""
get_actions -- workspace actions derived from report insights.

Lists and inspects actions with filtering by status, priority, team,
and source report. Links back to originating reports and insights.
"""

import logging
from typing import Any, Optional

from ..client import NudgClient

logger = logging.getLogger(__name__)


def _format_action_summary(action: dict[str, Any]) -> dict[str, Any]:
    """Compact an action dict for list display."""
    return {
        "id": action.get("id", ""),
        "recommendation_type": action.get("recommendation_type", "unknown"),
        "action_text": action.get("action_text", ""),
        "status": action.get("status", "pending"),
        "priority": action.get("priority", "medium"),
        "content_format": action.get("content_format"),
        "owner_team": action.get("owner_team"),
        "source_report_id": action.get("source_report_id"),
        "created_at": action.get("created_at"),
    }


def _format_action_detail(action: dict[str, Any]) -> dict[str, Any]:
    """Full action detail with context."""
    result = _format_action_summary(action)
    result.update({
        "target_platform": action.get("target_platform"),
        "action_context": action.get("action_context"),
        "brief_iterations": action.get("brief_iterations", 0),
        "assigned_to_user_id": action.get("assigned_to_user_id"),
        "started_at": action.get("started_at"),
        "completed_at": action.get("completed_at"),
        "updated_at": action.get("updated_at"),
    })
    return result


async def execute_get_actions(
    client: NudgClient,
    action_id: Optional[str] = None,
    status: Optional[str] = None,
    priority: Optional[str] = None,
    recommendation_type: Optional[str] = None,
    owner_team: Optional[str] = None,
    source_report_id: Optional[str] = None,
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """Execute action retrieval -- single detail or filtered list."""

    # Single action by ID
    if action_id:
        data = await client.get_action_detail(action_id)
        if data is None:
            return {"error": True, "message": "Action not found"}

        action = _format_action_detail(data)
        suggestions = _build_detail_suggestions(action)

        return {
            "action": action,
            "suggested_investigations": suggestions,
            "rate_limit": client.rate_limit_info,
        }

    # Paginated list with filters
    data = await client.get_actions(
        status=status,
        priority=priority,
        recommendation_type=recommendation_type,
        owner_team=owner_team,
        source_report_id=source_report_id,
        page=page,
        per_page=per_page,
    )

    actions_raw = data.get("actions", [])
    pagination = data.get("pagination", {})

    actions = [_format_action_summary(a) for a in actions_raw]

    # Status breakdown
    status_counts: dict[str, int] = {}
    for a in actions:
        s = a.get("status", "unknown")
        status_counts[s] = status_counts.get(s, 0) + 1

    # Priority breakdown
    priority_counts: dict[str, int] = {}
    for a in actions:
        p = a.get("priority", "unknown")
        priority_counts[p] = priority_counts.get(p, 0) + 1

    suggestions = _build_list_suggestions(actions, status, priority)

    # Filters applied
    applied = {}
    if status:
        applied["status"] = status
    if priority:
        applied["priority"] = priority
    if recommendation_type:
        applied["recommendation_type"] = recommendation_type
    if owner_team:
        applied["owner_team"] = owner_team
    if source_report_id:
        applied["source_report_id"] = source_report_id
    if applied:
        pass  # included below

    result: dict[str, Any] = {
        "actions": actions,
        "pagination": pagination,
        "status_breakdown": status_counts,
        "priority_breakdown": priority_counts,
        "suggested_investigations": suggestions,
        "rate_limit": client.rate_limit_info,
    }
    if applied:
        result["filters_applied"] = applied

    return result


def _build_detail_suggestions(action: dict[str, Any]) -> list[dict[str, Any]]:
    """Build suggestions from a single action detail."""
    suggestions = []

    source_report = action.get("source_report_id")
    if source_report:
        suggestions.append({
            "tool": "get_reports",
            "params": {"report_id": source_report},
            "reason": "View the visibility report that generated this action",
        })
        suggestions.append({
            "tool": "get_insights",
            "params": {"report_id": source_report},
            "reason": "See all insights from the source report",
        })

    if action.get("status") == "pending":
        suggestions.append({
            "tool": "get_actions",
            "params": {"status": "pending", "priority": "high"},
            "reason": "See all high-priority pending actions",
        })

    if action.get("owner_team"):
        suggestions.append({
            "tool": "get_actions",
            "params": {"owner_team": action["owner_team"]},
            "reason": f"See all actions assigned to the {action['owner_team']} team",
        })

    return suggestions


def _build_list_suggestions(
    actions: list[dict[str, Any]],
    current_status: Optional[str],
    current_priority: Optional[str],
) -> list[dict[str, Any]]:
    """Build suggestions from a list of actions."""
    suggestions = []

    # If not filtered by status, suggest pending/high-priority
    if not current_status:
        pending = [a for a in actions if a.get("status") == "pending"]
        if pending:
            suggestions.append({
                "tool": "get_actions",
                "params": {"status": "pending"},
                "reason": f"{len(pending)} pending actions -- filter to see what needs attention",
            })

    if not current_priority:
        high = [a for a in actions if a.get("priority") == "high"]
        if high:
            suggestions.append({
                "tool": "get_actions",
                "params": {"priority": "high"},
                "reason": f"{len(high)} high-priority actions -- focus on these first",
            })

    # Suggest detail for first action
    if actions:
        top = actions[0]
        suggestions.append({
            "tool": "get_actions",
            "params": {"action_id": top["id"]},
            "reason": f"View full detail of: {top.get('action_text', '')[:60]}...",
        })

    # Suggest latest report
    report_ids = {a["source_report_id"] for a in actions if a.get("source_report_id")}
    if report_ids:
        suggestions.append({
            "tool": "get_reports",
            "params": {"latest": True},
            "reason": "View the latest visibility report that may have generated new actions",
        })

    return suggestions
