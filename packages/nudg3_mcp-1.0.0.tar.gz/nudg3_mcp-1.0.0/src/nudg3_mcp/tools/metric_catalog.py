"""
get_metric_catalog tool — static discovery catalog.

Returns available measures, dimensions, filters, and export datasets
so the AI client can understand what data is queryable without docs.
No API call needed.
"""

from typing import Any


def get_catalog() -> dict[str, Any]:
    """Build the static metric catalog."""
    return {
        "measures": [
            {
                "name": "visibility_score",
                "description": "Brand visibility percentage across AI providers (7-day SMA smoothed)",
                "unit": "percentage",
                "dimensions": ["provider", "date", "brand"],
                "example_query": "Show my visibility score by provider for the last 7 days",
            },
            {
                "name": "sentiment_avg",
                "description": "Average sentiment score from AI provider responses (-1 to 1)",
                "unit": "score",
                "dimensions": ["provider", "date", "brand"],
                "example_query": "What's the sentiment trend for my brand over 30 days?",
            },
            {
                "name": "mention_count",
                "description": "Total number of times brand is mentioned across AI responses",
                "unit": "count",
                "dimensions": ["provider", "date", "brand"],
                "example_query": "How many times was my brand mentioned this week?",
            },
            {
                "name": "position_rank",
                "description": "Average ranking position when brand appears in AI responses",
                "unit": "rank",
                "dimensions": ["provider", "date", "brand"],
                "example_query": "What position does my brand rank across providers?",
            },
            {
                "name": "brand_detail",
                "description": "Detailed visibility metrics for a specific brand (requires brand_id)",
                "unit": "composite",
                "dimensions": ["provider", "date"],
                "requires": ["brand_id"],
                "example_query": "Show detailed metrics for brand X",
            },
            {
                "name": "prompt_performance",
                "description": "Per-prompt visibility, sentiment, and mention metrics (requires brand_id)",
                "unit": "composite",
                "dimensions": ["prompt", "provider"],
                "requires": ["brand_id"],
                "example_query": "Which prompts perform best for my brand?",
            },
            {
                "name": "prompt_detail",
                "description": "Single prompt breakdown by provider and brand (requires prompt_id)",
                "unit": "composite",
                "dimensions": ["provider", "brand"],
                "requires": ["prompt_id"],
                "example_query": "How does prompt X perform across providers?",
            },
            {
                "name": "source_citations",
                "description": "Domain-level source citation analytics — which websites AI models cite",
                "unit": "composite",
                "dimensions": ["source", "provider"],
                "example_query": "Which sources are cited most by AI models?",
            },
            {
                "name": "url_mentions",
                "description": "URL-level citation counts and metadata",
                "unit": "composite",
                "dimensions": ["url", "source"],
                "example_query": "Which specific URLs are cited?",
            },
            {
                "name": "url_trends",
                "description": "URL analytics with daily usage trends (includes top 5 line chart)",
                "unit": "composite",
                "dimensions": ["url", "date"],
                "example_query": "Show URL citation trends over time",
            },
            {
                "name": "aio_coverage",
                "description": "Google AI Overview coverage rate and brand visibility within AI Overviews",
                "unit": "percentage",
                "dimensions": ["date"],
                "example_query": "What's my Google AI Overview coverage rate?",
            },
            {
                "name": "aio_prompt",
                "description": "AI Overview metrics for a specific prompt (requires prompt_id)",
                "unit": "composite",
                "dimensions": ["date"],
                "requires": ["prompt_id"],
                "example_query": "How does prompt X perform in AI Overviews?",
            },
            {
                "name": "responses",
                "description": "Raw AI provider response text (truncated to 200 chars) with brand mentions",
                "unit": "text",
                "dimensions": ["provider", "prompt", "date"],
                "example_query": "Show me what ChatGPT says about my brand",
            },
            {
                "name": "filters",
                "description": "Available filter values for this workspace (providers, tags, brands, dates)",
                "unit": "metadata",
                "dimensions": [],
                "example_query": "What filters are available?",
            },
        ],
        "filters": {
            "date_range": {
                "type": "string",
                "description": "Relative (7d, 30d, 90d) or absolute (YYYY-MM-DD:YYYY-MM-DD)",
                "examples": ["7d", "30d", "2026-01-01:2026-03-01"],
            },
            "providers": {
                "type": "list[str]",
                "description": "AI provider display names",
                "examples": ["ChatGPT", "Gemini", "Claude", "Perplexity", "Google"],
            },
            "tags": {
                "type": "list[str]",
                "description": "Prompt tags or funnel stages",
                "examples": ["discovery", "research", "purchase"],
            },
            "brand_id": {
                "type": "string (UUID)",
                "description": "Required for brand_detail and prompt_performance. Get from filters measure.",
            },
            "prompt_id": {
                "type": "string (UUID)",
                "description": "Required for prompt_detail and aio_prompt. Get from prompt_performance.",
            },
        },
        "export_datasets": [
            {
                "name": "chat_responses",
                "description": "Full AI response text with brand mentions, sentiment, citations",
                "scope": "export:data",
            },
            {
                "name": "sources_citations",
                "description": "Source URLs, domains, citation context",
                "scope": "export:data",
            },
            {
                "name": "dashboard_graph",
                "description": "Time-series: date, brand, visibility_score, sentiment, position",
                "scope": "export:data",
            },
            {
                "name": "prompts_mentions",
                "description": "Prompt text, brand mentioned, sentiment, position, response context",
                "scope": "export:data",
            },
        ],
        "insights": {
            "description": "AI-generated intelligence from visibility audit reports. Requires read:insights scope (Professional tier or above).",
            "tools": [
                {
                    "name": "get_reports",
                    "description": "List/fetch visibility audit reports — scores, competitive position, executive summaries",
                    "scope": "read:insights",
                    "example_queries": [
                        "What did my latest visibility report find?",
                        "List my reports from the last month",
                        "Show me the full detail of report X",
                    ],
                },
                {
                    "name": "get_insights",
                    "description": "AI-generated opportunities, threats, quick wins, provider strategies, content recommendations from a report",
                    "scope": "read:insights",
                    "example_queries": [
                        "What opportunities did the AI find?",
                        "Show me high-priority threats",
                        "What content should I create based on the latest report?",
                    ],
                },
                {
                    "name": "get_actions",
                    "description": "Workspace actions derived from insights — status tracking, priority, team assignment",
                    "scope": "read:insights",
                    "example_queries": [
                        "What actions are pending?",
                        "Show high-priority actions for the content team",
                        "What actions came from the last report?",
                    ],
                },
            ],
        },
        "workspace_info": "All data is scoped to the workspace linked to your API key. Use the 'filters' measure to discover available brands, providers, and tags. Insights tools require the read:insights scope (Professional tier or above).",
    }
