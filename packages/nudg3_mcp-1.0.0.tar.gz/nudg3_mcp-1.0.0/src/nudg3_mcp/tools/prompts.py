"""
analyze_prompts — prompt-level performance grouped by funnel stage.

Flags underperformers and zero-visibility prompts.
Explains funnel stages inline for external LLMs.
"""

import logging
from typing import Any

from ..client import NudgClient
from .date_utils import parse_date_range

logger = logging.getLogger(__name__)

STAGE_DESCRIPTIONS = {
    "discovery": "unbranded category queries (e.g. 'best AI monitoring tools')",
    "research": "evaluation/comparison queries (e.g. 'Nudg3 vs Semrush')",
    "purchase": "buy-intent queries (e.g. 'Nudg3 pricing plans')",
}

MAX_PROMPTS_PER_STAGE = 5


VISIBILITY_TYPE_TAGS = {
    "organic": ["discovery"],
    "branded": ["research", "purchase"],
    "all": None,  # no tag filter
}


async def _resolve_primary_brand_id(client: NudgClient) -> str | None:
    """Resolve the workspace's primary brand_id from the dashboard.

    The public API returns the primary brand first in the overall dashboard.
    """
    try:
        dashboard = await client.get_dashboard()
        brands_raw = dashboard.get("brands", {})
        for _name, metrics in brands_raw.items():
            bid = metrics.get("brand_id")
            if bid:
                return bid
    except Exception:
        logger.exception("primary brand resolution failed")
    return None


async def execute_prompt_analysis(
    client: NudgClient,
    brand_id: str | None = None,
    date_range: str = "30d",
    providers: list[str] | None = None,
    visibility_type: str = "organic",
) -> dict[str, Any]:
    """Execute prompt performance analysis grouped by funnel stage.

    visibility_type controls which prompts to analyze:
      - "organic": discovery (unbranded) prompts only — the competitive metric
      - "branded": research + purchase prompts — brand presence when asked by name
      - "all": all prompts regardless of tagging

    If brand_id is omitted, the workspace's primary brand is auto-resolved.
    """
    start_date, end_date = parse_date_range(date_range)

    if not brand_id:
        brand_id = await _resolve_primary_brand_id(client)
        if not brand_id:
            return {
                "error": True,
                "message": (
                    "Could not auto-resolve primary brand_id. "
                    "Call get_overview first and pass the brand_id from the response."
                ),
            }

    tag_filter = VISIBILITY_TYPE_TAGS.get(visibility_type)

    prompts_data = await client.get_prompts(
        brand_id=brand_id,
        start_date=start_date,
        end_date=end_date,
        models=providers,
        tags=tag_filter,
        per_page=100,
    )

    prompt_list = prompts_data.get("prompts", [])

    # Group by funnel stage tag
    by_stage: dict[str, list] = {"discovery": [], "research": [], "purchase": [], "untagged": []}

    for p in prompt_list:
        tags = p.get("tags", []) or []
        stage = "untagged"
        for s in ["discovery", "research", "purchase"]:
            if s in tags:
                stage = s
                break

        # /v1/prompts nests analytics under "metrics"; fall back to top-level for compatibility
        m = p.get("metrics") or {}

        entry = {
            "text": (p.get("prompt_text") or p.get("template_text") or p.get("name") or "")[:120],
            "prompt_id": p.get("id") or p.get("prompt_template_id", ""),
            "visibility": round(
                m.get("visibility_percentage")
                or p.get("visibility_percentage")
                or p.get("avg_mentions")
                or 0,
                1,
            ),
            "sentiment": round(
                m.get("avg_sentiment_score")
                or m.get("sentiment_avg")
                or p.get("sentiment_avg")
                or p.get("avg_sentiment_score")
                or 0,
                2,
            ),
            "position": round(
                m.get("avg_position_rank")
                or m.get("avg_position")
                or p.get("avg_position")
                or p.get("avg_position_rank")
                or 0,
                1,
            ),
            "total_responses": (
                m.get("total_responses")
                or p.get("total_responses")
                or p.get("usage_count")
                or 0
            ),
        }
        by_stage[stage].append(entry)

    # Build stage summaries
    stage_summaries = {}
    all_underperformers = []

    for stage, prompts in by_stage.items():
        if not prompts:
            continue

        # Sort by visibility descending
        prompts.sort(key=lambda x: x["visibility"], reverse=True)

        avg_vis = sum(p["visibility"] for p in prompts) / len(prompts)

        # Identify underperformers
        underperformers = []
        for p in prompts:
            reasons = []
            if p["visibility"] == 0:
                reasons.append("zero visibility")
            elif p["visibility"] < 10:
                reasons.append("low visibility (<10%)")
            if p["sentiment"] < 0:
                reasons.append("negative sentiment")
            if p["position"] > 5 and p["position"] > 0:
                reasons.append(f"weak position ({p['position']})")

            if reasons:
                underperformers.append({**p, "reasons": reasons})

        all_underperformers.extend(underperformers)

        desc = STAGE_DESCRIPTIONS.get(stage, "prompts without funnel stage classification")
        stage_summaries[stage] = {
            "description": desc,
            "count": len(prompts),
            "avg_visibility": round(avg_vis, 1),
            "top_prompts": prompts[:MAX_PROMPTS_PER_STAGE],
            "underperformers": underperformers[:3],
            "remaining_count": max(0, len(prompts) - MAX_PROMPTS_PER_STAGE),
        }

    # Suggestions
    suggestions = []
    if all_underperformers:
        worst = all_underperformers[0]
        suggestions.append({
            "tool": "analyze_responses",
            "params": {"tags": ["discovery"]},
            "reason": f"Investigate why '{worst['text'][:60]}...' has {', '.join(worst['reasons'])}",
        })

    top_prompt = prompt_list[0] if prompt_list else None
    if top_prompt:
        pid = top_prompt.get("id") or top_prompt.get("prompt_template_id", "")
        if pid:
            suggestions.append({
                "tool": "analyze_responses",
                "params": {"providers": ["ChatGPT"]},
                "reason": "See what ChatGPT says for your top-performing prompts",
            })

    type_desc = {
        "organic": "Showing only organic (discovery/unbranded) prompts — the true AI discoverability metric. Branded prompts excluded to avoid inflated scores.",
        "branded": "Showing research + purchase prompts — what AI says when someone asks about your brand by name.",
        "all": "Showing all prompts. Discovery = unbranded category queries, Research = evaluation/comparison, Purchase = buy-intent queries.",
    }

    return {
        "context": type_desc.get(visibility_type, type_desc["all"]),
        "visibility_type": visibility_type,
        "brand_id": brand_id,
        "total_prompts": len(prompt_list),
        "by_stage": stage_summaries,
        "suggested_investigations": suggestions,
        "date_range": {"start": start_date, "end": end_date},
        "rate_limit": client.rate_limit_info,
    }
