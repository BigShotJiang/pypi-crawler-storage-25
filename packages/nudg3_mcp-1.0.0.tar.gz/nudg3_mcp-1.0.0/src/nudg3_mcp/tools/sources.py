"""
analyze_sources — citation source analysis with content gap detection.

Shows which websites AI models cite, type distribution,
and identifies content gaps and competitor domain bleed-through.
"""

import logging
from typing import Any

from ..client import NudgClient
from .date_utils import parse_date_range

logger = logging.getLogger(__name__)


async def execute_source_analysis(
    client: NudgClient,
    date_range: str = "30d",
    providers: list[str] | None = None,
    tags: list[str] | None = None,
) -> dict[str, Any]:
    """Execute source citation analysis."""
    start_date, end_date = parse_date_range(date_range)

    sources = await client.get_sources(
        start_date=start_date,
        end_date=end_date,
        models=providers,
        tags=tags,
        per_page=20,
    )

    source_list = sources.get("sources", [])
    total = sources.get("total_sources", len(source_list))
    type_dist = sources.get("source_type_distribution", [])

    # Top 10 domains
    top_domains = []
    for s in source_list[:10]:
        top_domains.append({
            "domain": s.get("domain", "unknown"),
            "usage_pct": round(s.get("usage_percentage", 0), 1),
            "source_type": s.get("source_type", "unknown"),
            "citation_count": s.get("citation_count", 0),
        })

    # Type distribution
    type_summary = {}
    if type_dist:
        for td in type_dist:
            if isinstance(td, dict):
                stype = td.get("source_type", "unknown")
                type_summary[stype] = td.get("count", 0)

    # Content gap detection
    content_gaps = []
    news_found = any(s.get("source_type") == "news" for s in source_list)
    if not news_found:
        content_gaps.append("No news sources cited by AI models — press coverage could boost AI citations")

    review_found = any(s.get("source_type") == "review" for s in source_list)
    if not review_found:
        content_gaps.append("No review sites citing your brand — product reviews on authoritative sites improve AI trust signals")

    # Competitor domain detection (domains that aren't the primary brand's)
    # We can't know the primary domain here, so flag well-known competitor domains
    competitor_domains = []
    known_competitors = {"semrush.com", "ahrefs.com", "moz.com", "hubspot.com",
                         "profound.ai", "otterly.ai", "peec.ai", "siftly.ai"}
    for s in source_list:
        domain = s.get("domain", "")
        if domain in known_competitors:
            competitor_domains.append({
                "domain": domain,
                "usage_pct": round(s.get("usage_percentage", 0), 1),
                "context": "Competitor domain appearing in your brand's AI responses",
            })

    # Suggestions
    suggestions = []
    if top_domains:
        suggestions.append({
            "tool": "analyze_responses",
            "params": {"providers": ["Perplexity"]},
            "reason": "Perplexity cites the most sources — see which URLs it references for your brand",
        })
    if content_gaps:
        suggestions.append({
            "tool": "analyze_prompts",
            "params": {},
            "reason": "Check which prompts drive the most citations to find content opportunities",
        })

    return {
        "total_sources": total,
        "top_domains": top_domains,
        "type_distribution": type_summary,
        "content_gaps": content_gaps,
        "competitor_domains_cited": competitor_domains,
        "suggested_investigations": suggestions,
        "date_range": {"start": start_date, "end": end_date},
        "rate_limit": client.rate_limit_info,
    }
