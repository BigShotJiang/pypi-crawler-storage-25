"""
analyze_responses — provider-grouped AI response samples.

Groups responses by provider, truncates text, detects sentiment patterns
and co-mention patterns across providers.
"""

import logging
from typing import Any

from ..client import NudgClient
from .date_utils import parse_date_range

logger = logging.getLogger(__name__)

MAX_TEXT_LENGTH = 300
MAX_SAMPLES_PER_PROVIDER = 3


async def execute_response_analysis(
    client: NudgClient,
    date_range: str = "30d",
    providers: list[str] | None = None,
    tags: list[str] | None = None,
    limit: int = 15,
) -> dict[str, Any]:
    """Execute response analysis grouped by provider."""
    start_date, end_date = parse_date_range(date_range)

    responses = await client.get_responses(
        start_date=start_date,
        end_date=end_date,
        models=providers,
        tags=tags,
        per_page=min(limit, 20),
    )

    response_list = responses.get("provider_responses", [])
    total = responses.get("total_responses", len(response_list))

    # Group by provider
    by_provider: dict[str, list] = {}
    for r in response_list:
        provider = r.get("provider") or r.get("model", "unknown")
        if provider not in by_provider:
            by_provider[provider] = []
        by_provider[provider].append(r)

    # Build provider summaries
    provider_summaries = {}
    all_mentions: dict[str, int] = {}

    for provider, resps in by_provider.items():
        samples = []
        provider_mentions: dict[str, int] = {}

        for r in resps[:MAX_SAMPLES_PER_PROVIDER]:
            text = r.get("response_text", "") or r.get("response_text_truncated", "")
            if len(text) > MAX_TEXT_LENGTH:
                text = text[:MAX_TEXT_LENGTH] + "..."

            mentions = []
            for m in r.get("brand_mentions", []):
                brand_name = m if isinstance(m, str) else m.get("name", "")
                if brand_name:
                    mentions.append(brand_name)
                    provider_mentions[brand_name] = provider_mentions.get(brand_name, 0) + 1
                    all_mentions[brand_name] = all_mentions.get(brand_name, 0) + 1

            samples.append({
                "text": text,
                "mentions": mentions,
                "sentiment": round(r.get("sentiment") or r.get("sentiment_score") or 0, 2),
                "prompt": (r.get("prompt_text") or "")[:80],
                "response_id": r.get("id") or r.get("provider_response_id", ""),
            })

        # Average sentiment for this provider
        sentiments = [r.get("sentiment") or r.get("sentiment_score") or 0 for r in resps]
        avg_sentiment = round(sum(sentiments) / len(sentiments), 2) if sentiments else 0

        provider_summaries[provider] = {
            "count": len(resps),
            "avg_sentiment": avg_sentiment,
            "brand_mentions": provider_mentions,
            "samples": samples,
        }

    # Detect patterns
    patterns = []
    for provider, summary in provider_summaries.items():
        if summary["avg_sentiment"] > 0.7:
            patterns.append(f"{provider} shows strong positive sentiment ({summary['avg_sentiment']:.2f})")
        elif summary["avg_sentiment"] < 0.3:
            patterns.append(f"{provider} shows weak sentiment ({summary['avg_sentiment']:.2f}) — investigate responses")

        # Co-mention detection
        mentions = summary.get("brand_mentions", {})
        for brand, count in mentions.items():
            if count >= 2:
                patterns.append(f"{provider} frequently co-mentions {brand} ({count} times)")

    # Suggestions
    suggestions = []
    if provider_summaries:
        suggestions.append({
            "tool": "analyze_prompts",
            "reason": "See which prompts drive the strongest brand mentions across providers",
        })
    weakest = min(provider_summaries.items(), key=lambda x: x[1]["avg_sentiment"], default=None)
    if weakest and weakest[1]["avg_sentiment"] < 0.5:
        suggestions.append({
            "tool": "analyze_sources",
            "params": {"providers": [weakest[0]]},
            "reason": f"{weakest[0]} has the weakest sentiment — check what sources it relies on",
        })

    return {
        "total_responses": total,
        "by_provider": provider_summaries,
        "patterns": patterns,
        "suggested_investigations": suggestions,
        "date_range": {"start": start_date, "end": end_date},
        "rate_limit": client.rate_limit_info,
    }
