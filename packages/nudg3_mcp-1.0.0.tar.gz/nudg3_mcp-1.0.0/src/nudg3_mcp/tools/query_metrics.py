"""
query_metrics tool — composable analytics query.

Routes measure+dimension+filter combinations to the appropriate
NudgClient method(s), calls them (in parallel if multiple), and
merges results into a single response with a factual summary.
"""

import asyncio
import logging
import re
from datetime import date, timedelta
from typing import Any

from ..client import NudgClient
from ..routing import MEASURE_ROUTES, resolve_routes, validate_requirements

logger = logging.getLogger(__name__)


def _parse_date_range(date_range: str) -> tuple[str, str]:
    """Parse date_range filter into (start_date, end_date) strings.

    Accepts:
      - Relative: "7d", "30d", "90d"
      - Absolute: "YYYY-MM-DD:YYYY-MM-DD"
    """
    # Relative: "7d", "30d", etc.
    relative_match = re.match(r"^(\d+)d$", date_range)
    if relative_match:
        days = int(relative_match.group(1))
        end = date.today()
        start = end - timedelta(days=days)
        return start.isoformat(), end.isoformat()

    # Absolute: "2026-01-01:2026-03-01"
    if ":" in date_range:
        parts = date_range.split(":")
        if len(parts) == 2:
            return parts[0], parts[1]

    raise ValueError(
        f"Invalid date_range: '{date_range}'. "
        f"Use relative (e.g. '7d', '30d') or absolute (e.g. '2026-01-01:2026-03-01')"
    )


def _build_params(filters: dict[str, Any], limit: int) -> dict[str, Any]:
    """Convert tool filters to API query parameters."""
    params: dict[str, Any] = {}

    # Date range
    date_range = filters.get("date_range")
    if date_range:
        start, end = _parse_date_range(date_range)
        params["start_date"] = start
        params["end_date"] = end

    # Provider filter
    providers = filters.get("providers")
    if providers:
        params["models"] = providers if isinstance(providers, list) else [providers]

    # Tag filter
    tags = filters.get("tags")
    if tags:
        params["tags"] = tags if isinstance(tags, list) else [tags]

    # ID filters
    if filters.get("brand_id"):
        params["brand_id"] = filters["brand_id"]
    if filters.get("prompt_id"):
        params["prompt_id"] = filters["prompt_id"]

    # Pagination
    params["per_page"] = limit

    return params


async def _call_endpoint(
    client: NudgClient, route_method: str, params: dict[str, Any]
) -> dict[str, Any]:
    """Call a single NudgClient method with the resolved parameters."""
    method = getattr(client, route_method)

    # Build kwargs from params, matching the method signature
    kwargs: dict[str, Any] = {}
    if "start_date" in params:
        kwargs["start_date"] = params["start_date"]
    if "end_date" in params:
        kwargs["end_date"] = params["end_date"]
    if "models" in params:
        kwargs["models"] = params["models"]
    if "tags" in params:
        kwargs["tags"] = params["tags"]

    # ID-based methods
    if "brand_id" in params and "brand_id" in method.__code__.co_varnames:
        kwargs["brand_id"] = params["brand_id"]
    if "prompt_id" in params and "prompt_id" in method.__code__.co_varnames:
        kwargs["prompt_id"] = params["prompt_id"]

    # Pagination
    if "per_page" in params and "per_page" in method.__code__.co_varnames:
        kwargs["per_page"] = params["per_page"]
    if "page" in params and "page" in method.__code__.co_varnames:
        kwargs["page"] = params["page"]

    return await method(**kwargs)


async def execute_query(
    client: NudgClient,
    measures: list[str],
    filters: dict[str, Any],
    limit: int = 50,
    sort_by: str | None = None,
    sort_order: str = "desc",
) -> dict[str, Any]:
    """Execute a composable metrics query.

    Routes to the appropriate endpoint(s), merges results,
    and returns structured data with metadata.
    """
    # Resolve which endpoints we need to call
    routes = resolve_routes(measures)

    # Validate required parameters
    errors = validate_requirements(routes, filters)
    if errors:
        return {
            "error": True,
            "messages": errors,
            "hint": "Call get_metric_catalog to see required parameters for each measure.",
        }

    # Build API parameters
    params = _build_params(filters, limit)

    # Call endpoints (parallel if multiple)
    results: dict[str, Any] = {}

    if len(routes) == 1:
        endpoint, route = next(iter(routes.items()))
        data = await _call_endpoint(client, route.method, params)
        results[endpoint] = data
    else:
        tasks = {
            endpoint: _call_endpoint(client, route.method, params)
            for endpoint, route in routes.items()
        }
        gathered = await asyncio.gather(*tasks.values(), return_exceptions=True)
        for endpoint, result in zip(tasks.keys(), gathered):
            if isinstance(result, Exception):
                results[endpoint] = {"error": str(result)}
            else:
                results[endpoint] = result

    # Build response
    return {
        "data": results,
        "metadata": {
            "measures_requested": measures,
            "endpoints_called": list(routes.keys()),
            "filters_applied": {k: v for k, v in filters.items() if v},
            "limit": limit,
            "rate_limit": client.rate_limit_info,
        },
    }
