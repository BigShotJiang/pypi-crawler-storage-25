"""Configuration from environment variables."""

import os


def get_api_key() -> str:
    """Get Nudg3 API key from environment."""
    key = os.environ.get("NUDG3_API_KEY", "")
    if not key:
        raise ValueError(
            "NUDG3_API_KEY environment variable is required. "
            "Create one at https://app.nudg3.ai/api-keys"
        )
    return key


def get_base_url() -> str:
    """Get Nudg3 API base URL."""
    return os.environ.get("NUDG3_API_URL", "https://api.nudg3.ai")


def get_timeout() -> float:
    """Get HTTP request timeout in seconds."""
    return float(os.environ.get("NUDG3_TIMEOUT", "30"))
