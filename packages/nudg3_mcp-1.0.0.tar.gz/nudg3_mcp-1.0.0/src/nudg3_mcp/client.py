"""
HTTP client for Nudg3 Public API v1.

Thin async wrapper over the 13 analytics + 4 export endpoints.
All methods unwrap the {"success": true, "data": {...}} envelope
and return the data dict. Rate limit info extracted from response headers.
"""

import logging
from datetime import date
from typing import Any, Optional

import httpx

from .config import get_api_key, get_base_url, get_timeout

logger = logging.getLogger(__name__)


class NudgClient:
    """Authenticated HTTP client for Nudg3 Public API v1."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
    ):
        self._api_key = api_key or get_api_key()
        self._base_url = (base_url or get_base_url()).rstrip("/")
        self._timeout = timeout or get_timeout()
        self._last_rate_limit: dict[str, Any] = {}

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "X-Client-Type": "mcp",
            "Accept": "application/json",
        }

    async def _get(self, path: str, params: Optional[dict] = None) -> dict[str, Any]:
        """Make GET request, unwrap envelope, capture rate limit headers."""
        url = f"{self._base_url}/api/v1{path}"
        params = {k: v for k, v in (params or {}).items() if v is not None}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.get(url, params=params, headers=self._headers())
            self._last_rate_limit = self._extract_rate_limits(response)
            response.raise_for_status()
            result = response.json()

        if isinstance(result, dict) and "data" in result:
            return result["data"]
        return result

    async def _get_raw(self, path: str, params: Optional[dict] = None) -> bytes:
        """Make GET request, return raw bytes (for CSV exports)."""
        url = f"{self._base_url}/api/v1{path}"
        params = {k: v for k, v in (params or {}).items() if v is not None}

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.get(url, params=params, headers=self._headers())
            self._last_rate_limit = self._extract_rate_limits(response)
            response.raise_for_status()
            return response.content

    @staticmethod
    def _extract_rate_limits(response: httpx.Response) -> dict[str, Any]:
        """Parse X-RateLimit-* headers from response."""
        limits: dict[str, Any] = {}
        for window in ("Minute", "Hour", "Month"):
            remaining = response.headers.get(f"X-RateLimit-Remaining-{window}")
            if remaining is not None:
                limits[f"{window.lower()}_remaining"] = int(remaining)
                limit_val = response.headers.get(f"X-RateLimit-Limit-{window}")
                if limit_val:
                    limits[f"{window.lower()}_limit"] = int(limit_val)
        return limits

    @property
    def rate_limit_info(self) -> dict[str, Any]:
        """Most recent rate limit info from last API call."""
        return self._last_rate_limit

    # ─── Analytics Endpoints ─────────────────────────────────────────────

    async def get_dashboard(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """GET /v1/dashboard — Brand visibility scores, sentiment, rankings."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/dashboard", params)

    async def get_brands(
        self, page: int = 1, per_page: int = 50
    ) -> dict[str, Any]:
        """GET /v1/brands — Competitor list with domains/icons."""
        return await self._get("/brands", {"page": page, "per_page": per_page})

    async def get_brand_detail(
        self,
        brand_id: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """GET /v1/brands/{id} — Single brand visibility metrics."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get(f"/brands/{brand_id}", params)

    async def get_prompts(
        self,
        brand_id: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict[str, Any]:
        """GET /v1/prompts — Prompt templates with performance metrics."""
        params: dict[str, Any] = {
            "brand_id": brand_id,
            "start_date": start_date,
            "end_date": end_date,
            "page": page,
            "per_page": per_page,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/prompts", params)

    async def get_prompt_detail(
        self,
        prompt_id: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """GET /v1/prompts/{id} — Per-prompt brand visibility breakdown."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if models:
            params["models"] = ",".join(models)
        return await self._get(f"/prompts/{prompt_id}", params)

    async def get_sources(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict[str, Any]:
        """GET /v1/sources — Domain-level source analytics."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "page": page,
            "per_page": per_page,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/sources", params)

    async def get_urls(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        page: int = 1,
        per_page: int = 100,
    ) -> dict[str, Any]:
        """GET /v1/urls — URL citations with counts."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "page": page,
            "per_page": per_page,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/urls", params)

    async def get_urls_detailed(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict[str, Any]:
        """GET /v1/urls-detailed — URL analytics with daily trends."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "page": page,
            "per_page": per_page,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/urls-detailed", params)

    async def get_responses(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
        page: int = 1,
        per_page: int = 20,
    ) -> dict[str, Any]:
        """GET /v1/responses — Provider responses (truncated to 200 chars)."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
            "page": page,
            "per_page": per_page,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/responses", params)

    async def get_aio_metrics(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """GET /v1/aio-metrics — Google AI Overview coverage metrics."""
        params: dict[str, Any] = {
            "start_date": start_date,
            "end_date": end_date,
        }
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get("/aio-metrics", params)

    async def get_aio_prompt_metrics(
        self,
        prompt_id: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> dict[str, Any]:
        """GET /v1/aio-metrics/prompt/{id} — Per-prompt AIO metrics."""
        return await self._get(
            f"/aio-metrics/prompt/{prompt_id}",
            {"start_date": start_date, "end_date": end_date},
        )

    async def get_filters(self) -> dict[str, Any]:
        """GET /v1/filters — Available filter values for this workspace."""
        return await self._get("/filters")

    # ─── Export Endpoints ────────────────────────────────────────────────

    async def export_chat_responses(
        self,
        date_from: str,
        date_to: str,
        models: Optional[list[str]] = None,
        tags: Optional[list[str]] = None,
    ) -> bytes:
        """GET /v1/exports/chat-responses — Full response text CSV."""
        params: dict[str, Any] = {"date_from": date_from, "date_to": date_to}
        if models:
            params["models"] = ",".join(models)
        if tags:
            params["tags"] = ",".join(tags)
        return await self._get_raw("/exports/chat-responses", params)

    async def export_sources_citations(
        self,
        date_from: str,
        date_to: str,
        models: Optional[list[str]] = None,
    ) -> bytes:
        """GET /v1/exports/sources-citations — Source/citation CSV."""
        params: dict[str, Any] = {"date_from": date_from, "date_to": date_to}
        if models:
            params["models"] = ",".join(models)
        return await self._get_raw("/exports/sources-citations", params)

    async def export_dashboard_graph(
        self,
        date_from: str,
        date_to: str,
    ) -> bytes:
        """GET /v1/exports/dashboard-graph — Time-series visibility CSV."""
        return await self._get_raw(
            "/exports/dashboard-graph",
            {"date_from": date_from, "date_to": date_to},
        )

    async def export_prompts_mentions(
        self,
        date_from: str,
        date_to: str,
        models: Optional[list[str]] = None,
    ) -> bytes:
        """GET /v1/exports/prompts-mentions — Prompt/mention pairs CSV."""
        params: dict[str, Any] = {"date_from": date_from, "date_to": date_to}
        if models:
            params["models"] = ",".join(models)
        return await self._get_raw("/exports/prompts-mentions", params)

    # ─── Insights Endpoints ───────────────────────────────────────────────

    async def get_reports(
        self,
        report_type: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        page: int = 1,
        per_page: int = 20,
    ) -> dict[str, Any]:
        """GET /v1/reports — List visibility audit reports."""
        return await self._get("/reports", {
            "report_type": report_type,
            "start_date": start_date,
            "end_date": end_date,
            "page": page,
            "per_page": per_page,
        })

    async def get_latest_report(
        self,
        report_type: Optional[str] = None,
        include_insights: bool = False,
    ) -> dict[str, Any]:
        """GET /v1/reports/latest — Most recent visibility report."""
        return await self._get("/reports/latest", {
            "report_type": report_type,
            "include_insights": include_insights,
        })

    async def get_report_detail(
        self,
        report_id: str,
        include_insights: bool = False,
    ) -> dict[str, Any]:
        """GET /v1/reports/{id} — Full report detail."""
        return await self._get(f"/reports/{report_id}", {
            "include_insights": include_insights,
        })

    async def get_report_insights(
        self,
        report_id: str,
        type: Optional[str] = None,
        priority: Optional[str] = None,
        category: Optional[str] = None,
    ) -> dict[str, Any]:
        """GET /v1/reports/{id}/insights — AI-generated insights from a report."""
        return await self._get(f"/reports/{report_id}/insights", {
            "type": type,
            "priority": priority,
            "category": category,
        })

    async def get_actions(
        self,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        recommendation_type: Optional[str] = None,
        owner_team: Optional[str] = None,
        content_format: Optional[str] = None,
        source_report_id: Optional[str] = None,
        page: int = 1,
        per_page: int = 20,
    ) -> dict[str, Any]:
        """GET /v1/actions — List workspace actions."""
        return await self._get("/actions", {
            "status": status,
            "priority": priority,
            "recommendation_type": recommendation_type,
            "owner_team": owner_team,
            "content_format": content_format,
            "source_report_id": source_report_id,
            "page": page,
            "per_page": per_page,
        })

    async def get_action_detail(
        self,
        action_id: str,
    ) -> dict[str, Any]:
        """GET /v1/actions/{id} — Full action detail with context."""
        return await self._get(f"/actions/{action_id}")

    # ─── Export Statistics (for pre-flight checks) ───────────────────────

    async def get_export_statistics(
        self,
        dataset: str,
        date_from: str,
        date_to: str,
    ) -> dict[str, Any]:
        """GET /v1/exports/{dataset}/statistics — Row counts before export."""
        return await self._get(
            f"/exports/{dataset}/statistics",
            {"date_from": date_from, "date_to": date_to},
        )
