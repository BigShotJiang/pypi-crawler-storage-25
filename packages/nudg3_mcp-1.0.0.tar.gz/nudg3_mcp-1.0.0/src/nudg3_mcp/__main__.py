"""stdio entry point for the Nudg3 MCP server.

Usage:
  uvx nudg3-mcp          # via uvx (no install)
  nudg3-mcp              # after pip install
  python -m nudg3_mcp    # direct module execution
"""

from .server import mcp


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
