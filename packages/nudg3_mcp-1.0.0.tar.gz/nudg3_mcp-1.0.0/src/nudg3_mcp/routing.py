"""
Measure+dimension → endpoint routing.

Maps the composable query_metrics parameters to the appropriate
NudgClient method(s). For multi-measure queries spanning multiple
endpoints, returns multiple routes to be called in parallel.
"""

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class Route:
    """A single endpoint route with its required parameters."""

    endpoint: str
    method: str
    requires: list[str] = field(default_factory=list)
    description: str = ""


# Measure → endpoint mapping (validated against production codebase 2026-03-09)
MEASURE_ROUTES: dict[str, Route] = {
    # Dashboard metrics — all served by GET /v1/dashboard
    "visibility_score": Route(
        endpoint="dashboard",
        method="get_dashboard",
        description="Brand visibility percentage across AI providers (7-day SMA smoothed)",
    ),
    "sentiment_avg": Route(
        endpoint="dashboard",
        method="get_dashboard",
        description="Average sentiment score across provider responses",
    ),
    "mention_count": Route(
        endpoint="dashboard",
        method="get_dashboard",
        description="Total brand mentions across all providers",
    ),
    "position_rank": Route(
        endpoint="dashboard",
        method="get_dashboard",
        description="Average ranking position in AI responses",
    ),
    # Per-brand detail
    "brand_detail": Route(
        endpoint="brand_detail",
        method="get_brand_detail",
        requires=["brand_id"],
        description="Detailed metrics for a specific brand",
    ),
    # Prompt performance
    "prompt_performance": Route(
        endpoint="prompts",
        method="get_prompts",
        requires=["brand_id"],
        description="Per-prompt visibility, sentiment, and mention metrics",
    ),
    # Prompt drill-down
    "prompt_detail": Route(
        endpoint="prompt_detail",
        method="get_prompt_detail",
        requires=["prompt_id"],
        description="Single prompt brand visibility breakdown by provider",
    ),
    # Source analytics
    "source_citations": Route(
        endpoint="sources",
        method="get_sources",
        description="Domain-level source citation analytics",
    ),
    # URL analytics
    "url_mentions": Route(
        endpoint="urls",
        method="get_urls",
        description="URL-level citation counts and metadata",
    ),
    # URL trends
    "url_trends": Route(
        endpoint="urls_detailed",
        method="get_urls_detailed",
        description="URL analytics with daily usage line chart data",
    ),
    # AI Overview metrics
    "aio_coverage": Route(
        endpoint="aio_metrics",
        method="get_aio_metrics",
        description="Google AI Overview coverage and visibility rates",
    ),
    # Per-prompt AIO
    "aio_prompt": Route(
        endpoint="aio_prompt",
        method="get_aio_prompt_metrics",
        requires=["prompt_id"],
        description="AI Overview metrics scoped to a single prompt",
    ),
    # Raw responses
    "responses": Route(
        endpoint="responses",
        method="get_responses",
        description="AI provider response text (truncated to 200 chars)",
    ),
    # Filter values
    "filters": Route(
        endpoint="filters",
        method="get_filters",
        description="Available filter options (providers, tags, brands, date ranges)",
    ),
}

# Export dataset → method mapping
EXPORT_ROUTES: dict[str, str] = {
    "chat_responses": "export_chat_responses",
    "sources_citations": "export_sources_citations",
    "dashboard_graph": "export_dashboard_graph",
    "prompts_mentions": "export_prompts_mentions",
}


def resolve_routes(measures: list[str]) -> dict[str, Route]:
    """Resolve measures to unique endpoint routes (deduplicates shared endpoints)."""
    routes: dict[str, Route] = {}
    for measure in measures:
        route = MEASURE_ROUTES.get(measure)
        if route is None:
            raise ValueError(
                f"Unknown measure: '{measure}'. "
                f"Available: {sorted(MEASURE_ROUTES.keys())}"
            )
        # Deduplicate by endpoint — dashboard metrics all share one call
        if route.endpoint not in routes:
            routes[route.endpoint] = route
    return routes


def validate_requirements(
    routes: dict[str, Route], filters: dict[str, Any]
) -> list[str]:
    """Check that required parameters are present. Returns list of errors."""
    errors = []
    for endpoint, route in routes.items():
        for req in route.requires:
            if req not in filters or not filters[req]:
                errors.append(
                    f"Measure '{endpoint}' requires '{req}' filter. "
                    f"Get available values with get_metric_catalog."
                )
    return errors
