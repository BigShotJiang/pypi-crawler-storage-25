"""Pydantic models for tool inputs and outputs."""

from typing import Any, Optional

from pydantic import BaseModel, Field


class QueryMetricsInput(BaseModel):
    """Input schema for the query_metrics tool."""

    measures: list[str] = Field(
        description=(
            "Metrics to retrieve. Options: visibility_score, sentiment_avg, "
            "mention_count, position_rank, brand_detail, prompt_performance, "
            "prompt_detail, source_citations, url_mentions, url_trends, "
            "aio_coverage, aio_prompt, responses, filters"
        ),
    )
    filters: dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Query filters. Common keys: "
            "date_range (e.g. '7d', '30d', '2026-01-01:2026-03-01'), "
            "providers (list, e.g. ['ChatGPT', 'Gemini']), "
            "tags (list, e.g. ['discovery', 'purchase']), "
            "brand_id (UUID string, required for prompt_performance and brand_detail), "
            "prompt_id (UUID string, required for prompt_detail and aio_prompt)"
        ),
    )
    limit: int = Field(default=50, ge=1, le=100, description="Max rows to return")
    sort_by: Optional[str] = Field(default=None, description="Sort field name")
    sort_order: str = Field(default="desc", description="Sort order: asc or desc")


class ExportDataInput(BaseModel):
    """Input schema for the export_data tool."""

    dataset: str = Field(
        description=(
            "Dataset to export. Options: chat_responses, sources_citations, "
            "dashboard_graph, prompts_mentions"
        ),
    )
    date_from: str = Field(description="Start date (YYYY-MM-DD)")
    date_to: str = Field(description="End date (YYYY-MM-DD)")
    providers: Optional[list[str]] = Field(
        default=None,
        description="Filter by provider display names (e.g. ['ChatGPT', 'Gemini'])",
    )
    confirm_large_export: bool = Field(
        default=False,
        description="Set to true to proceed with exports over 10,000 rows",
    )
