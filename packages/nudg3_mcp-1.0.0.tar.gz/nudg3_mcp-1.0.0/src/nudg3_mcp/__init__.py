"""Nudg3 MCP Server — Brand visibility intelligence for AI assistants."""

__version__ = "0.1.0"
