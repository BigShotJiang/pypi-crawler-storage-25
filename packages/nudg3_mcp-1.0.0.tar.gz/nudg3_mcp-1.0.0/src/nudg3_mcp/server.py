"""
Nudg3 MCP Server — transport-agnostic.

Registers 10 investigation-oriented tools on a FastMCP instance.
This module defines the server but does NOT start it.

Entry points:
  - stdio:  __main__.py (uvx nudg3-mcp)
  - remote: uvicorn nudg3_mcp.server:app (Streamable HTTP, v2)

Tool design: Investigation-oriented (overview → suggest → drill-down).
Each tool returns summarized data (~500-800 tokens) with explicit
suggestions for what to investigate next, including parameters.
"""

import logging
from typing import Any

import httpx
from fastmcp import FastMCP

from .client import NudgClient
from .tools.metric_catalog import get_catalog
from .tools.overview import execute_overview
from .tools.competitors import execute_competitor_analysis
from .tools.prompts import execute_prompt_analysis
from .tools.sources import execute_source_analysis
from .tools.responses import execute_response_analysis
from .tools.export_data import execute_export
from .tools.reports import execute_get_reports
from .tools.insights import execute_get_insights
from .tools.actions import execute_get_actions

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "nudg3",
    instructions=(
        "Nudg3 brand visibility intelligence — tracks how brands appear across "
        "AI search providers (ChatGPT, Gemini, Claude, Perplexity, Google AI Overviews). "
        "\n\n"
        "KEY CONCEPT: Nudg3 separates two types of visibility:\n"
        "- Organic visibility (discovery/unbranded queries): Can AI find your brand without being asked by name? This is the true competitive metric.\n"
        "- Branded visibility (research + purchase queries): What does AI say when someone asks about your brand specifically?\n"
        "Always present organic visibility first — it reflects real AI discoverability.\n"
        "\n"
        "Investigation flow:\n"
        "1. Start with get_overview for organic + branded health check with investigation suggestions\n"
        "2. Follow the suggested_investigations in each response to drill deeper\n"
        "3. Use analyze_competitors (organic only), analyze_prompts, analyze_sources, or analyze_responses\n"
        "4. Use get_reports to view visibility audit reports with scores and executive summaries\n"
        "5. Use get_insights to see AI-generated opportunities, threats, and recommendations from a report\n"
        "6. Use get_actions to see workspace action items derived from insights\n"
        "7. Use export_data only when the user wants raw CSV data\n"
        "\n"
        "Each tool returns summarized data (not raw time-series) with explicit next-step suggestions.\n"
        "Reports/insights/actions require the read:insights scope (Professional tier or above)."
    ),
)

# Lazy-init client (created on first tool call so env vars are read at runtime)
_client: NudgClient | None = None


def _get_client() -> NudgClient:
    global _client
    if _client is None:
        _client = NudgClient()
    return _client


def _format_error(e: Exception) -> dict[str, Any]:
    """Map API errors to user-friendly MCP responses."""
    if isinstance(e, httpx.HTTPStatusError):
        status = e.response.status_code
        if status == 401:
            return {
                "error": True,
                "message": "Invalid or expired API key. Generate a new one at https://app.nudg3.ai/api-keys",
            }
        if status == 403:
            return {
                "error": True,
                "message": "Insufficient scope for this operation. Check your API key tier at https://app.nudg3.ai/api-keys",
            }
        if status == 429:
            return {
                "error": True,
                "message": "Rate limit exceeded. Check rate_limit info in previous responses for reset times.",
            }
        return {
            "error": True,
            "message": f"Nudg3 API error ({status}): {e.response.text[:200]}",
        }
    if isinstance(e, httpx.ConnectError):
        return {
            "error": True,
            "message": "Could not reach Nudg3 API. Check your internet connection.",
        }
    if isinstance(e, httpx.TimeoutException):
        return {
            "error": True,
            "message": "Nudg3 API request timed out. Try again or narrow your query.",
        }
    return {
        "error": True,
        "message": f"Unexpected error: {str(e)}",
    }


# ─── Tool: get_metric_catalog ───────────────────────────────────────────


@mcp.tool()
async def get_metric_catalog() -> dict[str, Any]:
    """Discover what data is available in this Nudg3 workspace.

    Returns available investigation tools, filters, and export datasets.
    No API call is made — this is a static catalog.
    """
    return get_catalog()


# ─── Tool: get_overview ─────────────────────────────────────────────────


@mcp.tool()
async def get_overview(
    date_range: str = "30d",
    providers: list[str] | None = None,
) -> dict[str, Any]:
    """Compact workspace health check — start here.

    Returns current visibility scores for all tracked brands (primary + competitors),
    7-day and 30-day trends as single numbers (not raw time-series), top cited sources,
    anomaly alerts, and suggested next investigations with parameters.

    This is the first tool to call. Follow the suggested_investigations in the response
    to drill deeper into specific areas.

    Args:
        date_range: "7d", "30d", "90d", or "YYYY-MM-DD:YYYY-MM-DD"
        providers: Filter by AI provider names (e.g. ["ChatGPT", "Gemini"])
    """
    try:
        return await execute_overview(
            client=_get_client(),
            date_range=date_range,
            providers=providers,
        )
    except Exception as e:
        logger.exception("get_overview error")
        return _format_error(e)


# ─── Tool: analyze_competitors ──────────────────────────────────────────


@mcp.tool()
async def analyze_competitors(
    date_range: str = "30d",
    providers: list[str] | None = None,
) -> dict[str, Any]:
    """Competitive landscape — how brands rank on discovery (unbranded) queries.

    Shows position rankings, visibility gaps, and which competitors are gaining
    or losing ground. "Discovery" means unbranded category queries where brands
    compete on relevance, not brand recognition (e.g., "best AI monitoring tools").

    Args:
        date_range: "7d", "30d", "90d", or "YYYY-MM-DD:YYYY-MM-DD"
        providers: Filter by AI provider names (e.g. ["ChatGPT", "Gemini"])
    """
    try:
        return await execute_competitor_analysis(
            client=_get_client(),
            date_range=date_range,
            providers=providers,
        )
    except Exception as e:
        logger.exception("analyze_competitors error")
        return _format_error(e)


# ─── Tool: analyze_prompts ──────────────────────────────────────────────


@mcp.tool()
async def analyze_prompts(
    brand_id: str | None = None,
    date_range: str = "30d",
    providers: list[str] | None = None,
    visibility_type: str = "organic",
) -> dict[str, Any]:
    """Prompt-level performance grouped by funnel stage.

    Shows which tracking prompts perform best/worst for a specific brand.

    visibility_type controls the analysis scope:
    - "organic" (default): Discovery/unbranded prompts only — the true competitive metric.
      Branded prompts are excluded because they inflate scores artificially.
    - "branded": Research + purchase prompts — what AI says when asked about you by name.
    - "all": All prompts regardless of tagging.

    Funnel stages explained:
    - Discovery: unbranded category queries ("best AI monitoring tools")
    - Research: evaluation/comparison queries ("Nudg3 vs Semrush")
    - Purchase: buy-intent queries ("Nudg3 pricing")

    Args:
        brand_id: Optional. UUID of the brand to analyze. If omitted, the
            workspace's primary brand is auto-resolved — call this tool
            without brand_id when the user just asks about "our prompts"
            or "we" without naming a competitor.
        date_range: "7d", "30d", "90d", or "YYYY-MM-DD:YYYY-MM-DD"
        providers: Filter by AI provider names
        visibility_type: "organic" (default), "branded", or "all"
    """
    try:
        return await execute_prompt_analysis(
            client=_get_client(),
            brand_id=brand_id,
            date_range=date_range,
            providers=providers,
            visibility_type=visibility_type,
        )
    except Exception as e:
        logger.exception("analyze_prompts error")
        return _format_error(e)


# ─── Tool: analyze_sources ──────────────────────────────────────────────


@mcp.tool()
async def analyze_sources(
    date_range: str = "30d",
    providers: list[str] | None = None,
    tags: list[str] | None = None,
) -> dict[str, Any]:
    """Citation source analysis — which websites AI models cite.

    Shows top cited domains, source type distribution (reference, social, news,
    review, commerce), content gaps (missing source types), and competitor
    domains appearing in your brand's AI responses.

    Args:
        date_range: "7d", "30d", "90d", or "YYYY-MM-DD:YYYY-MM-DD"
        providers: Filter by AI provider names
        tags: Filter by funnel stage (e.g. ["discovery", "research"])
    """
    try:
        return await execute_source_analysis(
            client=_get_client(),
            date_range=date_range,
            providers=providers,
            tags=tags,
        )
    except Exception as e:
        logger.exception("analyze_sources error")
        return _format_error(e)


# ─── Tool: analyze_responses ────────────────────────────────────────────


@mcp.tool()
async def analyze_responses(
    date_range: str = "30d",
    providers: list[str] | None = None,
    tags: list[str] | None = None,
    limit: int = 15,
) -> dict[str, Any]:
    """Read what AI models actually say — provider-grouped response samples.

    Groups AI responses by provider with truncated text, sentiment scores,
    brand mention patterns, and co-mention detection (which competitors
    appear alongside your brand).

    Args:
        date_range: "7d", "30d", "90d", or "YYYY-MM-DD:YYYY-MM-DD"
        providers: Filter by AI provider names (e.g. ["ChatGPT"])
        tags: Filter by funnel stage (e.g. ["discovery"])
        limit: Max responses to analyze (default 15, max 20)
    """
    try:
        return await execute_response_analysis(
            client=_get_client(),
            date_range=date_range,
            providers=providers,
            tags=tags,
            limit=limit,
        )
    except Exception as e:
        logger.exception("analyze_responses error")
        return _format_error(e)


# ─── Tool: export_data ──────────────────────────────────────────────────


@mcp.tool()
async def export_data(
    dataset: str,
    date_from: str,
    date_to: str,
    providers: list[str] | None = None,
    confirm_large_export: bool = False,
) -> dict[str, Any]:
    """Export raw workspace data as CSV.

    Use this only when the user wants raw data for spreadsheets or BI tools.
    For analysis, use the investigation tools (get_overview, analyze_*) instead.

    Datasets: chat_responses, sources_citations, dashboard_graph, prompts_mentions.
    Requires the export:data scope (Professional tier or above).

    Args:
        dataset: One of: chat_responses, sources_citations, dashboard_graph, prompts_mentions
        date_from: Start date (YYYY-MM-DD)
        date_to: End date (YYYY-MM-DD)
        providers: Filter by provider names
        confirm_large_export: Set true to proceed with exports over 10,000 rows
    """
    try:
        return await execute_export(
            client=_get_client(),
            dataset=dataset,
            date_from=date_from,
            date_to=date_to,
            providers=providers,
            confirm_large_export=confirm_large_export,
        )
    except Exception as e:
        logger.exception("export_data error")
        return _format_error(e)


# ─── Tool: get_reports ─────────────────────────────────────────────────


@mcp.tool()
async def get_reports(
    report_id: str | None = None,
    latest: bool = False,
    report_type: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    include_insights: bool = False,
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """List or retrieve visibility audit reports.

    Reports contain point-in-time snapshots of brand visibility including
    scores, competitive position, executive summaries, and AI-generated insights.

    Three modes:
    - List: returns paginated report summaries (default)
    - Latest: set latest=True to get the most recent report
    - Detail: pass report_id for full report with optional insights

    Requires read:insights scope (Professional tier or above).

    Args:
        report_id: UUID of a specific report (returns full detail)
        latest: If true, returns the most recent report
        report_type: Filter: "free_audit", "weekly_report", or "on_demand"
        start_date: Filter by report date (YYYY-MM-DD)
        end_date: Filter by report date (YYYY-MM-DD)
        include_insights: Embed AI insights in the report detail response
        page: Page number for list mode
        per_page: Results per page (max 50)
    """
    try:
        return await execute_get_reports(
            client=_get_client(),
            report_id=report_id,
            latest=latest,
            report_type=report_type,
            start_date=start_date,
            end_date=end_date,
            include_insights=include_insights,
            page=page,
            per_page=per_page,
        )
    except Exception as e:
        logger.exception("get_reports error")
        return _format_error(e)


# ─── Tool: get_insights ───────────────────────────────────────────────


@mcp.tool()
async def get_insights(
    report_id: str,
    type: str | None = None,
    priority: str | None = None,
    category: str | None = None,
) -> dict[str, Any]:
    """Get AI-generated actionable insights from a visibility report.

    Returns categorized recommendations: opportunities (gaps to exploit),
    threats (competitive risks), quick wins (low-effort improvements),
    provider strategies (per-AI-provider tactics), content recommendations
    (what to create), and prompt edit suggestions.

    Requires read:insights scope (Professional tier or above).

    Args:
        report_id: UUID of the report to get insights for (required)
        type: Filter by category: "opportunities", "threats", "quick_wins", "provider_strategies", "content_recommendations", or "all"
        priority: Filter by priority: "high", "medium", or "low"
        category: Filter by team: "tech", "content", "marketing", or "leadership"
    """
    try:
        return await execute_get_insights(
            client=_get_client(),
            report_id=report_id,
            type=type,
            priority=priority,
            category=category,
        )
    except Exception as e:
        logger.exception("get_insights error")
        return _format_error(e)


# ─── Tool: get_actions ─────────────────────────────────────────────────


@mcp.tool()
async def get_actions(
    action_id: str | None = None,
    status: str | None = None,
    priority: str | None = None,
    recommendation_type: str | None = None,
    owner_team: str | None = None,
    source_report_id: str | None = None,
    page: int = 1,
    per_page: int = 20,
) -> dict[str, Any]:
    """List or retrieve workspace actions derived from report insights.

    Actions are recommendations that have been created from AI-generated
    insights or manually. Each action tracks status, priority, owner team,
    and links back to the source report.

    Two modes:
    - List: returns paginated actions with filters (default)
    - Detail: pass action_id for full action with context and brief info

    Requires read:insights scope (Professional tier or above).

    Args:
        action_id: UUID of a specific action (returns full detail with context)
        status: Filter: "pending", "in_progress", "ready", "completed", or "dismissed"
        priority: Filter: "high", "medium", or "low"
        recommendation_type: Filter: "opportunity", "threat", "quick_win", or "prompt_edit"
        owner_team: Filter: "tech", "content", "marketing", or "leadership"
        source_report_id: Filter by originating report UUID
        page: Page number for list mode
        per_page: Results per page (max 50)
    """
    try:
        return await execute_get_actions(
            client=_get_client(),
            action_id=action_id,
            status=status,
            priority=priority,
            recommendation_type=recommendation_type,
            owner_team=owner_team,
            source_report_id=source_report_id,
            page=page,
            per_page=per_page,
        )
    except Exception as e:
        logger.exception("get_actions error")
        return _format_error(e)


# ASGI app for Streamable HTTP transport (v2)
# Usage: uvicorn nudg3_mcp.server:app --host 0.0.0.0 --port 8080
app = mcp.http_app()
