This guide assumes that you have moderate knowledge of running servers, installing software and how TLS
certificates work.

The guide assumes you use a dedicated server to set up your certificate authority and does not account for
potential conflicts with other software like ports, directories or container names.

A certificate authority needs :ref:`plain HTTP <http-explanation>` for CRL and OCSP access and HTTPS for
ACMEv2. Using standard ports are strongly recommended (clients might fail otherwise). If you do not need any
of the mentioned features, you can use all other features from the command line and do not need a web server.

Setup DNS
=========

*Before* you set up your certificate authority, you need a domain name that points to the server where you
install django-ca. Since the domain is encoded in CA certificates, it cannot be easily changed later.

This guide assumes that ``ca.example.com`` is the name that points to the server where you are setting up your
certificate authority.
