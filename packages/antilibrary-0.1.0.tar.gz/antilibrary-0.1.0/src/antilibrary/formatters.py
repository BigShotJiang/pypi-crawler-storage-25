"""Output formatting for BibTeX entries."""

from __future__ import annotations

from antilibrary.core import Entry


def format_citation(entry: Entry, style: str = "bibtex") -> str:
    """Format a citation reference in the given style."""
    key = entry.key
    match style:
        case "bibtex":
            return key
        case "latex":
            return f"\\cite{{{key}}}"
        case "org-cite":
            return f"[cite:@{key}]"
        case "pandoc":
            return f"[@{key}]"
        case _:
            return key


def format_display(entry: Entry) -> str:
    """Format entry for display in search results."""
    return entry.display_string()
