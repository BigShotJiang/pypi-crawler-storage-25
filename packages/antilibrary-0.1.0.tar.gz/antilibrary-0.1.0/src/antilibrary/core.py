"""Core BibTeX entry/library management.

`Entry` and `bibfile` provide the data class and low-level .bib I/O;
this module wraps them in a higher-level `Library` used across antilibrary's
CLI and search.
"""

from __future__ import annotations

from pathlib import Path
from datetime import datetime

from antilibrary import bibfile
from antilibrary.entry import Entry

__all__ = ["Entry", "Library", "make_entry"]


class Library:
    """A BibTeX library backed by a .bib file."""

    def __init__(self, path: Path, label: str | None = None):
        self.path = path
        self.label = label or path.stem
        self._entries: list[Entry] | None = None

    def entries(self, *, reload: bool = False) -> list[Entry]:
        if self._entries is not None and not reload:
            return self._entries
        self._entries = bibfile.load(self.path)
        return self._entries

    def find(self, key: str) -> Entry | None:
        for e in self.entries():
            if e.key == key:
                return e
        return None

    def has_duplicate(self, entry: Entry) -> Entry | None:
        return bibfile.find_duplicate(entry, self.entries())

    def add(self, entry: Entry, *, merge: bool = True, force: bool = False) -> bibfile.AppendResult:
        """Append an entry, deduplicating against existing ones."""
        result = bibfile.append(self.path, entry, merge=merge, force=force)
        self._entries = None
        return result

    def remove(self, key: str) -> bool:
        """Remove an entry by key. Rewrites the file."""
        entries = self.entries(reload=True)
        filtered = [e for e in entries if e.key != key]
        if len(filtered) == len(entries):
            return False
        from antilibrary.bibfile import _rewrite
        _rewrite(self.path, filtered)
        self._entries = None
        return True

    @property
    def count(self) -> int:
        return len(self.entries())


def make_entry(
    entry_type: str = "misc",
    title: str = "Untitled",
    author: str = "",
    year: str | None = None,
    key: str | None = None,
    **extra_fields: str,
) -> Entry:
    """Create an Entry with sensible defaults."""
    if year is None:
        year = str(datetime.now().year)
    if key is None:
        if author:
            last = author.split(",")[0].split()[-1].lower() if author else "unknown"
        else:
            last = "unknown"
        safe_title = "".join(c for c in title[:20] if c.isalnum())
        key = f"{last}{year}{safe_title}".lower()
    fields = {"title": title, "year": year}
    if author:
        fields["author"] = author
    fields.update(extra_fields)
    return Entry(key=key, entry_type=entry_type, fields=fields)
