"""BibTeX Entry data class."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Entry:
    """A single BibTeX entry."""

    key: str
    entry_type: str
    fields: dict[str, str] = field(default_factory=dict)
    raw: str = ""
    source_file: Path | None = None

    def display_string(self) -> str:
        author = self.fields.get("author", "Unknown")
        if "," in author:
            author = author.split(",")[0].strip()
        elif " and " in author:
            author = author.split(" and ")[0].strip()
        year = self.fields.get("year", "n.d.")
        title = self.fields.get("title", "Untitled")
        return f"{author} ({year}) - {title}"

    @property
    def tags(self) -> list[str]:
        kw = self.fields.get("keywords", "")
        if not kw:
            return []
        return [t.strip() for t in kw.split(",") if t.strip()]

    @tags.setter
    def tags(self, value: list[str]) -> None:
        self.fields["keywords"] = ", ".join(value)

    def to_bibtex(self) -> str:
        lines = [f"@{self.entry_type}{{{self.key},"]
        for k, v in self.fields.items():
            lines.append(f"  {k} = {{{v}}},")
        lines.append("}")
        return "\n".join(lines)
