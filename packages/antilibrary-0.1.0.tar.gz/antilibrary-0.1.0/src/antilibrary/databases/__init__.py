"""External database integrations (OMDB, MusicBrainz, etc.) - to be implemented."""
