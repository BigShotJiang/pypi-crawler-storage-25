"""Antilibrary - Manage BibTeX libraries from the terminal."""

__version__ = "0.1.0"
