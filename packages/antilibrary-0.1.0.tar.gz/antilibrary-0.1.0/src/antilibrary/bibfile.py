"""Read, dedup, and append BibTeX entries to a .bib file."""

from __future__ import annotations

from pathlib import Path

import bibtexparser

from antilibrary.entry import Entry


def _btp_to_entry(e, source: Path | None = None) -> Entry:
    fields = {f.key: f.value for f in e.fields}
    return Entry(key=e.key, entry_type=e.entry_type, fields=fields, source_file=source)


def load(path: Path) -> list[Entry]:
    """Load all entries from a .bib file. Returns [] if missing/empty."""
    if not path.exists():
        return []
    text = path.read_text()
    if not text.strip():
        return []
    lib = bibtexparser.parse_string(text)
    return [_btp_to_entry(e, path) for e in lib.entries]


def _norm(s: str) -> str:
    return s.strip().lower()


def find_duplicate(entry: Entry, existing: list[Entry]) -> Entry | None:
    """Return an existing entry that matches by identifier or title+author."""
    new_doi = _norm(entry.fields.get("doi", ""))
    new_arxiv = _norm(entry.fields.get("eprint", ""))
    new_isbn = _norm(entry.fields.get("isbn", ""))
    new_title = _norm(entry.fields.get("title", ""))
    new_author = _norm(entry.fields.get("author", ""))

    for e in existing:
        if e.key == entry.key:
            return e
        if new_doi and _norm(e.fields.get("doi", "")) == new_doi:
            return e
        if new_arxiv and _norm(e.fields.get("eprint", "")) == new_arxiv:
            return e
        if new_isbn and _norm(e.fields.get("isbn", "")) == new_isbn:
            return e
        if (
            new_title
            and _norm(e.fields.get("title", "")) == new_title
            and new_author
            and _norm(e.fields.get("author", "")) == new_author
        ):
            return e
    return None


def make_unique_key(base: str, existing: list[Entry]) -> str:
    """Suffix a, b, c... if `base` collides with any key in existing."""
    keys = {e.key for e in existing}
    if base not in keys:
        return base
    for suffix in "abcdefghijklmnopqrstuvwxyz":
        candidate = f"{base}{suffix}"
        if candidate not in keys:
            return candidate
    n = 1
    while f"{base}{n}" in keys:
        n += 1
    return f"{base}{n}"


def _append_entry(path: Path, entry: Entry) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = path.read_text() if path.exists() else ""
    separator = "\n\n" if text.strip() else ""
    with open(path, "a") as f:
        f.write(separator + entry.to_bibtex() + "\n")
    entry.source_file = path


def _rewrite(path: Path, entries: list[Entry]) -> None:
    content = "\n\n".join(e.to_bibtex() for e in entries)
    path.write_text(content + "\n" if content else "")


def merge_missing(target: Entry, source: Entry) -> bool:
    """Fill empty/absent fields on `target` from `source`. Returns True if changed."""
    changed = False
    for k, v in source.fields.items():
        if not v:
            continue
        if not target.fields.get(k, "").strip():
            target.fields[k] = v
            changed = True
    return changed


class AppendResult:
    __slots__ = ("status", "entry", "duplicate_of")

    def __init__(self, status: str, entry: Entry, duplicate_of: Entry | None = None):
        self.status = status  # "added" | "skipped" | "merged"
        self.entry = entry
        self.duplicate_of = duplicate_of


def append(
    path: Path,
    entry: Entry,
    *,
    merge: bool = True,
    force: bool = False,
) -> AppendResult:
    """Append `entry` to the .bib at `path` with dedup.

    - If a duplicate exists and `force` is False:
        - If `merge` is True (default), fill missing/empty fields on the existing entry
          and rewrite the file. Returns status="merged" if anything changed,
          otherwise "skipped".
        - If `merge` is False, returns status="skipped".
    - Otherwise auto-suffixes the key on collision and appends.
    """
    existing = load(path)
    dup = find_duplicate(entry, existing) if not force else None

    if dup is not None:
        if merge:
            if merge_missing(dup, entry):
                _rewrite(path, existing)
                return AppendResult("merged", dup, duplicate_of=dup)
        return AppendResult("skipped", dup, duplicate_of=dup)

    entry.key = make_unique_key(entry.key, existing)
    _append_entry(path, entry)
    return AppendResult("added", entry)
