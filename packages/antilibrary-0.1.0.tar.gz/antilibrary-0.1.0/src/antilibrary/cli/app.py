"""Antilibrary CLI — manage a BibTeX file.

Commands operate on a single .bib file resolved in this order:
  1. -f/--file FILE argument
  2. $ANTILIBRARY_BIB environment variable
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from rich import box
from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table

from antilibrary.core import Library, make_entry
from antilibrary.formatters import format_citation
from antilibrary.search import fuzzy_search, filter_by_tags

console = Console()


def _resolve_file(arg: str | None) -> Path:
    if arg:
        return Path(arg).expanduser()
    env = os.environ.get("ANTILIBRARY_BIB")
    if env:
        return Path(env).expanduser()
    console.print(
        "[red]no .bib file specified[/]  "
        "[dim]pass -f FILE or set ANTILIBRARY_BIB[/]"
    )
    sys.exit(2)


def _prompt(label: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        val = input(f"{label}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(130)
    return val or default


# ── add ─────────────────────────────────────────────────────────────────────


def cmd_add(args: argparse.Namespace) -> int:
    path = _resolve_file(args.file)
    lib = Library(path)

    entry_type = args.type or _prompt("type", "article")
    title = _prompt("title")
    if not title:
        console.print("[red]title required[/]")
        return 2
    author = _prompt("author")
    year = _prompt("year")
    key = args.key or _prompt("key (blank = auto)")

    entry = make_entry(
        entry_type=entry_type,
        title=title,
        author=author,
        year=year or None,
        key=key or None,
    )

    while True:
        extra = _prompt("extra field (blank to finish)")
        if not extra:
            break
        val = _prompt(f"  {extra}")
        if val:
            entry.fields[extra] = val

    result = lib.add(entry, merge=not args.no_merge, force=args.force)
    if result.status == "added":
        console.print(f"[green]added[/] [bold]{result.entry.key}[/] → {path}")
    elif result.status == "merged":
        console.print(f"[green]merged[/] missing fields into [bold]{result.entry.key}[/]")
    else:
        console.print(f"[yellow]duplicate[/] of [bold]{result.duplicate_of.key}[/] — skipped")
    return 0


# ── get ─────────────────────────────────────────────────────────────────────


def cmd_get(args: argparse.Namespace) -> int:
    path = _resolve_file(args.file)
    lib = Library(path)
    entry = lib.find(args.key)
    if entry is None:
        console.print(f"[red]no entry with key {args.key!r}[/]")
        return 1

    if args.style == "bibtex-full":
        console.print(
            Syntax(entry.to_bibtex(), "bibtex", theme="monokai", line_numbers=False, padding=(0, 1))
        )
    else:
        print(format_citation(entry, args.style))
    return 0


# ── browse ──────────────────────────────────────────────────────────────────


def cmd_browse(args: argparse.Namespace) -> int:
    path = _resolve_file(args.file)
    lib = Library(path)
    entries = lib.entries()

    if args.tags:
        tags = [t.strip() for t in args.tags.split(",") if t.strip()]
        entries = filter_by_tags(entries, tags)

    if args.query:
        entries = fuzzy_search(entries, args.query, limit=args.limit)
    else:
        entries = entries[: args.limit]

    if not entries:
        console.print("[dim]no matching entries[/]")
        return 0

    table = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan", padding=(0, 1))
    table.add_column("key", style="bold cyan", max_width=28)
    table.add_column("title", ratio=3)
    table.add_column("author", ratio=2)
    table.add_column("year", width=6, justify="center")
    table.add_column("tags", style="blue", max_width=20)

    for e in entries:
        table.add_row(
            e.key,
            e.fields.get("title", ""),
            e.fields.get("author", "")[:40],
            e.fields.get("year", ""),
            ", ".join(e.tags) if e.tags else "",
        )
    console.print(table)
    console.print(f"[dim]{len(entries)} entries · {path}[/]")
    return 0


# ── remove ──────────────────────────────────────────────────────────────────


def cmd_remove(args: argparse.Namespace) -> int:
    path = _resolve_file(args.file)
    lib = Library(path)
    entry = lib.find(args.key)
    if entry is None:
        console.print(f"[red]no entry with key {args.key!r}[/]")
        return 1

    if not args.yes:
        confirm = _prompt(f"remove {entry.display_string()!r}? (y/N)", "n")
        if confirm.lower() not in ("y", "yes"):
            console.print("[dim]cancelled[/]")
            return 0

    lib.remove(args.key)
    console.print(f"[green]removed[/] {args.key}")
    return 0


# ── argparse wiring ─────────────────────────────────────────────────────────


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="antilibrary",
        description="Manage a BibTeX file.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    def add_file(sp: argparse.ArgumentParser) -> None:
        sp.add_argument(
            "-f", "--file",
            help="Path to .bib file (default: $ANTILIBRARY_BIB)",
        )

    sp_add = sub.add_parser("add", help="Add a new entry interactively")
    add_file(sp_add)
    sp_add.add_argument("--type", help="Entry type (default: article)")
    sp_add.add_argument("--key", help="Citation key (default: auto-generated)")
    sp_add.add_argument("--no-merge", action="store_true",
                        help="On duplicate, skip without filling missing fields")
    sp_add.add_argument("--force", action="store_true",
                        help="Append even if a duplicate exists")
    sp_add.set_defaults(func=cmd_add)

    sp_get = sub.add_parser("get", help="Fetch an entry by key")
    add_file(sp_get)
    sp_get.add_argument("key")
    sp_get.add_argument(
        "--style",
        choices=("bibtex", "bibtex-full", "latex", "org-cite", "pandoc"),
        default="bibtex-full",
        help="Output format (default: bibtex-full — the whole entry)",
    )
    sp_get.set_defaults(func=cmd_get)

    sp_br = sub.add_parser("browse", help="List / search entries")
    add_file(sp_br)
    sp_br.add_argument("--query", "-q", help="Fuzzy-match query")
    sp_br.add_argument("--tags", "-t", help="Filter by tags (comma-separated)")
    sp_br.add_argument("--limit", type=int, default=50)
    sp_br.set_defaults(func=cmd_browse)

    sp_rm = sub.add_parser("remove", help="Remove an entry by key")
    add_file(sp_rm)
    sp_rm.add_argument("key")
    sp_rm.add_argument("-y", "--yes", action="store_true", help="Skip confirmation")
    sp_rm.set_defaults(func=cmd_remove)

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
