"""Fuzzy search over BibTeX entries."""

from __future__ import annotations

from rapidfuzz import fuzz, process

from antilibrary.core import Entry


def fuzzy_search(
    entries: list[Entry],
    query: str,
    limit: int = 30,
    score_cutoff: float = 30.0,
) -> list[Entry]:
    """Fuzzy search entries by their display string.

    Returns entries sorted by match quality (best first).
    """
    if not query.strip():
        return entries[:limit]

    display_map = {e.display_string(): e for e in entries}
    results = process.extract(
        query,
        display_map.keys(),
        scorer=fuzz.WRatio,
        limit=limit,
        score_cutoff=score_cutoff,
    )
    return [display_map[r[0]] for r in results]


def filter_by_tags(entries: list[Entry], tags: list[str]) -> list[Entry]:
    """Filter entries that have ALL of the specified tags."""
    if not tags:
        return entries
    tag_set = {t.lower() for t in tags}
    return [
        e for e in entries
        if tag_set.issubset({t.lower() for t in e.tags})
    ]


def all_tags(entries: list[Entry]) -> list[str]:
    """Collect all unique tags across entries, sorted."""
    tags: set[str] = set()
    for e in entries:
        tags.update(e.tags)
    return sorted(tags)
