# antilibrary

Manage a BibTeX file from the terminal.

## Install

```bash
pip install antilibrary
# or
uv tool install antilibrary
```

## Usage

Antilibrary operates on a single `.bib` file resolved in this order:

1. `-f / --file FILE` argument
2. `$ANTILIBRARY_BIB` environment variable

```bash
export ANTILIBRARY_BIB=~/refs/main.bib

antilibrary add                          # interactively add an entry
antilibrary get smith2024                # print citation for a key
antilibrary browse                       # list entries
antilibrary browse -q "attention"        # fuzzy search
antilibrary browse -t "nlp,transformers" # filter by tags
antilibrary remove smith2024             # delete an entry
```

### Citation styles

`antilibrary get KEY --style {bibtex|bibtex-full|latex|org-cite|pandoc}` prints
a citation in the requested format:

| style          | output                  |
|----------------|-------------------------|
| `bibtex`       | `smith2024`             |
| `bibtex-full`  | the whole entry         |
| `latex`        | `\cite{smith2024}`      |
| `org-cite`     | `[cite:@smith2024]`     |
| `pandoc`       | `[@smith2024]`          |

## Adding entries

`antilibrary add` is interactive — it prompts for type, title, author, year,
key, and any extra fields. Adding an entry that matches an existing one
(by DOI, arXiv ID, ISBN, or normalized title+author) silently fills any
empty fields on the existing entry rather than creating a duplicate. Pass
`--no-merge` to skip on duplicate, or `--force` to append anyway with an
auto-suffixed key.

Companion tools (planned):

- **bibzapper** — batch extraction from PDFs, EPUBs, URLs, DOIs, arXiv IDs, or
  ISBNs into a `.bib` file.
- **bibsearcher** — online search (movies, TV, music, papers, books) → BibTeX.

## License

MIT
