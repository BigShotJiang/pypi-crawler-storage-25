"""Tests for core BibTeX parsing and library management."""

from pathlib import Path

from antilibrary.core import Library, make_entry
from antilibrary.search import fuzzy_search, filter_by_tags, all_tags
from antilibrary.formatters import format_citation

FIXTURES = Path(__file__).parent / "fixtures"
SAMPLE_BIB = FIXTURES / "sample.bib"


class TestLibrary:
    def test_parse_sample(self):
        lib = Library(SAMPLE_BIB)
        entries = lib.entries()
        assert len(entries) == 5

    def test_find_by_key(self):
        lib = Library(SAMPLE_BIB)
        entry = lib.find("knuth1997art")
        assert entry is not None
        assert entry.fields["title"] == "The Art of Computer Programming"

    def test_find_missing(self):
        lib = Library(SAMPLE_BIB)
        assert lib.find("nonexistent") is None

    def test_display_string(self):
        lib = Library(SAMPLE_BIB)
        entry = lib.find("knuth1997art")
        assert "Knuth" in entry.display_string()
        assert "1997" in entry.display_string()

    def test_tags(self):
        lib = Library(SAMPLE_BIB)
        entry = lib.find("vaswani2017attention")
        assert "transformers" in entry.tags
        assert "deep-learning" in entry.tags

    def test_add_entry(self, tmp_path):
        bib = tmp_path / "test.bib"
        bib.touch()
        lib = Library(bib)
        entry = make_entry(title="Test Paper", author="Author, A.", year="2024")
        lib.add(entry)
        lib2 = Library(bib)
        assert lib2.count == 1
        assert lib2.entries()[0].fields["title"] == "Test Paper"

    def test_remove_entry(self, tmp_path):
        bib = tmp_path / "test.bib"
        bib.touch()
        lib = Library(bib)
        e1 = make_entry(title="Paper One", author="A", year="2024", key="one2024")
        e2 = make_entry(title="Paper Two", author="B", year="2024", key="two2024")
        lib.add(e1)
        lib.add(e2)
        assert lib.count == 2
        assert lib.remove("one2024")
        lib2 = Library(bib)
        assert lib2.count == 1
        assert lib2.entries()[0].key == "two2024"

    def test_to_bibtex_roundtrip(self):
        entry = make_entry(title="Roundtrip", author="Test, A.", year="2024", key="test2024")
        bib_str = entry.to_bibtex()
        assert "@misc{test2024," in bib_str
        assert "Roundtrip" in bib_str


class TestSearch:
    def test_fuzzy_search(self):
        lib = Library(SAMPLE_BIB)
        results = fuzzy_search(lib.entries(), "attention")
        assert len(results) > 0
        assert results[0].key == "vaswani2017attention"

    def test_fuzzy_search_partial(self):
        lib = Library(SAMPLE_BIB)
        results = fuzzy_search(lib.entries(), "knuth art prog")
        assert any(e.key == "knuth1997art" for e in results)

    def test_filter_by_tags(self):
        lib = Library(SAMPLE_BIB)
        results = filter_by_tags(lib.entries(), ["nlp"])
        assert len(results) == 2

    def test_all_tags(self):
        lib = Library(SAMPLE_BIB)
        tags = all_tags(lib.entries())
        assert "transformers" in tags
        assert "film" in tags

    def test_empty_query_returns_all(self):
        lib = Library(SAMPLE_BIB)
        results = fuzzy_search(lib.entries(), "")
        assert len(results) == 5


class TestFormatters:
    def test_bibtex_format(self):
        entry = make_entry(title="T", key="k2024")
        assert format_citation(entry, "bibtex") == "k2024"

    def test_latex_format(self):
        entry = make_entry(title="T", key="k2024")
        assert format_citation(entry, "latex") == "\\cite{k2024}"

    def test_org_cite_format(self):
        entry = make_entry(title="T", key="k2024")
        assert format_citation(entry, "org-cite") == "[cite:@k2024]"

    def test_pandoc_format(self):
        entry = make_entry(title="T", key="k2024")
        assert format_citation(entry, "pandoc") == "[@k2024]"
