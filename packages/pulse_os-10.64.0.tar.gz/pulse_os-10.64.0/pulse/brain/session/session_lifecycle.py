#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
"""Session Lifecycle — cross-session memory for PULSE agents.


P47: Every conversation gets a session record in SQLite. When a new agent
boots, it sees the last 3 sessions from ANY agent — not just its own.

Tables: sessions, session_turns (created by brain_db.init_db)
"""
import logging
log = logging.getLogger("pulse.brain.session.session_lifecycle")


import json
import hashlib
from datetime import datetime, timezone
from typing import Optional


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _session_id(agent: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    h = hashlib.md5(f"{agent}:{ts}".encode()).hexdigest()[:6]
    return f"ses_{agent}_{ts}_{h}"


def start_session(agent: str, task: str = "", domain: str = "general") -> str:
    """Create a new session row. Returns session_id.

    Also detects orphaned 'active' sessions from the same agent and
    marks them as 'abandoned' (crash recovery).
    """
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    sid = _session_id(agent)
    now = _now()

    # Orphan recovery: close any stale 'active' sessions from this agent
    try:
        with conn:
            conn.execute(
                "UPDATE sessions SET status='abandoned', ended_at=? "
                "WHERE agent=? AND status='active'",
                (now, agent),
            )
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)

    # Find predecessor (most recent completed session from any agent)
    predecessor = None
    try:
        row = conn.execute(
            "SELECT id FROM sessions WHERE status IN ('completed','abandoned') "
            "ORDER BY started_at DESC LIMIT 1"
        ).fetchone()
        if row:
            predecessor = row[0]
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)

    with conn:
        conn.execute(
            "INSERT OR IGNORE INTO sessions "
            "(id, agent, started_at, domain, status, predecessor_session, metadata) "
            "VALUES (?, ?, ?, ?, 'active', ?, '{}')",
            (sid, agent, now, domain, predecessor),
        )
    return sid


def record_turn(
    session_id: str,
    role: str,
    text: str,
    domain: str = "general",
    timestamp: str = "",
) -> None:
    """Record a conversation turn. Called by the bridge on each flush."""
    if not session_id or not text:
        return
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    ts = timestamp or _now()

    # Get next turn index
    row = conn.execute(
        "SELECT MAX(turn_index) FROM session_turns WHERE session_id=?",
        (session_id,),
    ).fetchone()
    next_idx = (row[0] or 0) + 1 if row else 1

    # Truncate to 5000 chars to keep DB manageable
    trimmed = text[:5000]

    with conn:
        conn.execute(
            "INSERT INTO session_turns "
            "(session_id, turn_index, role, content, content_len, timestamp, domain) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (session_id, next_idx, role.lower(), trimmed, len(text), ts, domain),
        )
        # Update turn count on session
        conn.execute(
            "UPDATE sessions SET turn_count=turn_count+1 WHERE id=?", (session_id,)
        )


def _get_recent_turns(session_id: str, limit: int = 15) -> list:
    """Fetch recent turns for a session (for summary generation)."""
    try:
        from pulse.core.brain_db import get_conn
        conn = get_conn()
        rows = conn.execute(
            "SELECT role, content FROM session_turns WHERE session_id=? "
            "ORDER BY turn_index DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
        return [{"role": r[0], "content": r[1]} for r in reversed(rows)]
    except Exception:
        return []


def _synthesize_summary(turns: list, agent: str) -> str:
    """Generate a 2-sentence session summary from recent turns via LLM.

    Falls back to keyword extraction if LLM unavailable.
    """
    turn_text = "\n".join([
        f"{t['role'].upper()}: {t['content'][:200]}" for t in turns[-10:]
    ])
    prompt = (
        "Summarize this AI session in 2 sentences: what was shipped or decided, "
        "and what the next step is.\n\n" + turn_text
    )
    try:
        from pulse.core.llm_router import dispatch
        result = dispatch(prompt, task_type="fast", max_tokens=150)
        if result and len(result.strip()) > 10:
            return result.strip()[:500]
    except Exception as _exc:
        pass  # QR14: silent — consider log.debug("%s", _exc)
    # Fallback: extract meaningful keywords
    keywords = set()
    for t in turns:
        for word in t.get("content", "").split():
            if len(word) > 6 and word.isalpha() and word.lower() not in {
                "because", "should", "always", "getting", "through", "another",
                "between", "without", "however", "already", "before", "during",
            }:
                keywords.add(word.lower())
    kw_list = sorted(keywords)[:8]
    return f"Session with {len(turns)} turns. Topics: {', '.join(kw_list)}" if kw_list else ""


def end_session(
    session_id: str,
    summary: str = "",
    user_intent: str = "",
    key_decisions: list = None,
    key_discoveries: list = None,
    files_touched: list = None,
    status: str = "completed",
) -> None:
    """Mark session as completed with summary data.

    QR11 FIX 4: Auto-generates summary if empty and turns exist.
    """
    if not session_id:
        return
    from pulse.core.brain_db import get_conn

    # QR11 FIX 4: Auto-generate summary if caller didn't provide one
    if not summary:
        try:
            turns = _get_recent_turns(session_id, limit=15)
            if len(turns) >= 2:
                summary = _synthesize_summary(turns, "")
        except Exception as _exc:
            pass  # QR14: silent — consider log.debug("%s", _exc)

    conn = get_conn()
    now = _now()

    with conn:
        conn.execute(
            "UPDATE sessions SET "
            "ended_at=?, summary=?, user_intent=?, "
            "key_decisions=?, key_discoveries=?, files_touched=?, "
            "status=? "
            "WHERE id=?",
            (
                now,
                (summary or "")[:2000],
                (user_intent or "")[:500],
                json.dumps((key_decisions or [])[:20]),
                json.dumps((key_discoveries or [])[:20]),
                json.dumps((files_touched or [])[:30]),
                status,
                session_id,
            ),
        )


def get_recent_sessions(limit: int = 5, agent: str = None) -> list:
    """Get most recent completed/abandoned sessions across ALL agents.

    This is the core cross-session query. Returns dicts with:
    id, agent, started_at, ended_at, summary, user_intent, turn_count, domain, status
    """
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    # QR11 FIX 4: Filter ghost sessions (0 turns + empty summary = noise in boot context)
    _ghost_filter = "AND (turn_count > 0 OR (summary != '' AND summary IS NOT NULL))"
    if agent:
        rows = conn.execute(
            "SELECT id, agent, started_at, ended_at, summary, user_intent, "
            "turn_count, domain, status FROM sessions "
            "WHERE agent=? AND status IN ('completed','abandoned') "
            f"{_ghost_filter} "
            "ORDER BY started_at DESC LIMIT ?",
            (agent, limit),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT id, agent, started_at, ended_at, summary, user_intent, "
            "turn_count, domain, status FROM sessions "
            "WHERE status IN ('completed','abandoned') "
            f"{_ghost_filter} "
            "ORDER BY started_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]


def get_active_session(agent: str) -> Optional[str]:
    """Get the active session ID for an agent, if any.

    Uses a prefix LIKE match so "claude" finds both "claude" and
    "claude_interactive_20020", "claude_daemon", etc.  This resolves
    the mismatch where pulse_boot.py creates sessions with a full
    qualified name while the bridge looks them up by bare agent prefix.
    """
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    row = conn.execute(
        "SELECT id FROM sessions WHERE (agent = ? OR agent LIKE ? || '_%') "
        "AND status='active' ORDER BY started_at DESC LIMIT 1",
        (agent, agent),
    ).fetchone()
    return row[0] if row else None


def _get_session_turns(session_id: str, limit: int = 20) -> list:
    """Get the most recent turns from a session."""
    from pulse.core.brain_db import get_conn

    conn = get_conn()
    rows = conn.execute(
        "SELECT turn_index, role, content, timestamp FROM session_turns "
        "WHERE session_id=? ORDER BY turn_index DESC LIMIT ?",
        (session_id, limit),
    ).fetchall()
    return [dict(r) for r in reversed(rows)]


def _record_interaction(agent: str, user_text: str, agent_text: str = "",
                       domain: str = "general", timestamp: str = "") -> None:
    """Record a full interaction (user+agent turns) for the given agent.
    Called from bridge._flush_interaction. Auto-finds active session."""
    sid = get_active_session(agent)
    if not sid:
        return
    record_turn(sid, "user", user_text, domain=domain, timestamp=timestamp)
    if agent_text:
        record_turn(sid, "agent", agent_text, domain=domain, timestamp=timestamp)
