"""
Custom build command to bundle backend/ and frontend/ into the Python package.

At build time, copies source files (excluding node_modules, .env, logs, etc.)
into khy_quant/bundled/ so they ship inside the wheel.
"""
import shutil
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py

ROOT = Path(__file__).parent

# Patterns to exclude from the bundle
EXCLUDE_PATTERNS = (
    "node_modules",
    "__pycache__",
    ".env",
    ".env.local",
    "logs",
    "temp",
    "data",
    ".DS_Store",
    "Thumbs.db",
    "*.pyc",
    "*.db",
    "*.sqlite",
    "*.sqlite3",
    "*.joblib",
    "*.log",
)

# Directories to skip entirely
PRUNE_DIRS = {
    "node_modules",
    "__pycache__",
    "logs",
    "temp",
    "data",
    ".git",
    "android",
    "android-sdk",
    "dist",
}


class BuildWithBundle(build_py):
    """Copy backend/ and frontend/ into khy_quant/bundled/ before building."""

    def run(self):
        bundled = ROOT / "khy_quant" / "bundled"

        for name in ("backend", "frontend"):
            src = ROOT / name
            dst = bundled / name
            if src.exists() and not dst.exists():
                shutil.copytree(
                    src,
                    dst,
                    ignore=shutil.ignore_patterns(*EXCLUDE_PATTERNS),
                    dirs_exist_ok=False,
                )

                # Remove pruned directories that ignore_patterns may have missed
                for prune_dir in PRUNE_DIRS:
                    for match in dst.rglob(prune_dir):
                        if match.is_dir():
                            shutil.rmtree(match, ignore_errors=True)

        # Ensure bundled dirs are included as package data
        self.package_data = self.package_data or {}
        self.package_data.setdefault("khy_quant", []).append("bundled/**/*")

        super().run()


setup(
    cmdclass={"build_py": BuildWithBundle},
    package_data={"khy_quant": ["bundled/**/*"]},
)
