# KHY-Quant

Quantitative trading system built with Vue 3 + Express + Multi-Agent.

## Quick Start

```bash
# Docker (recommended)
docker compose up --build

# Development
cd backend  && npm install && npm run dev
cd frontend && npm install && npm run dev
```

- Frontend: http://localhost:18080
- Backend API: http://localhost:3000
- Default login: admin / admin123
