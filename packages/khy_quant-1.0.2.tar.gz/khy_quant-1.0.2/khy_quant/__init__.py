"""KHY-Quant: Quantitative trading system."""
__version__ = "1.0.2"
