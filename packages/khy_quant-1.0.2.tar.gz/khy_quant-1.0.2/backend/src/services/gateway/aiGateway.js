/**
 * AI Gateway — central service that routes AI requests through
 * a priority-ordered cascade of adapters:
 *   1. CLI tools (Claude Code, Codex, Aider)
 *   2. Cloud API providers (MultiFreeService)
 *   3. Web relay (manual browser-based relay, always available)
 *
 * Singleton export — matches project convention.
 */
const cliToolAdapter = require('./adapters/cliToolAdapter');
const ollamaAdapter = require('./adapters/ollamaAdapter');
const apiAdapter = require('./adapters/apiAdapter');
const webRelayAdapter = require('./adapters/webRelayAdapter');

class AIGateway {
  constructor() {
    this._adapters = [
      { key: 'cli', adapter: cliToolAdapter, priority: 1, enabled: true },
      { key: 'ollama', adapter: ollamaAdapter, priority: 2, enabled: true },
      { key: 'api', adapter: apiAdapter, priority: 3, enabled: true },
      { key: 'relay', adapter: webRelayAdapter, priority: 4, enabled: true },
    ];
    this._initialized = false;
    this._initPromise = null;
  }

  /**
   * Initialize the gateway: detect available adapters.
   * Safe to call multiple times (idempotent after first, race-safe).
   */
  async init() {
    if (this._initialized) return;
    if (this._initPromise) return this._initPromise;
    this._initPromise = this._doInit();
    return this._initPromise;
  }

  async _doInit() {

    // Respect environment toggles
    if (process.env.GATEWAY_CLI_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'cli').enabled = false;
    }
    if (process.env.GATEWAY_OLLAMA_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'ollama').enabled = false;
    }
    if (process.env.GATEWAY_RELAY_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'relay').enabled = false;
    }

    // Run detection on each enabled adapter
    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      try {
        // Ollama uses async HTTP detection (no curl dependency)
        if (entry.key === 'ollama' && entry.adapter.detectAsync) {
          entry.available = await entry.adapter.detectAsync();
        } else {
          entry.available = entry.adapter.detect();
        }
      } catch {
        entry.available = false;
      }
    }

    this._initialized = true;
    this._initPromise = null;
  }

  /**
   * Generate a response by cascading through adapters.
   * Returns the same shape as MultiFreeService.generateResponse().
   */
  async generate(prompt, options = {}) {
    if (!this._initialized) await this.init();

    const allAttempts = [];

    for (const entry of this._adapters) {
      if (!entry.enabled) continue;

      // Re-check availability for api adapter (keys might have changed)
      if (entry.key === 'api') {
        entry.available = entry.adapter.detect();
      }

      if (!entry.available && entry.key !== 'relay') continue;

      try {
        const result = await entry.adapter.generate(prompt, { ...options });
        if (result.attempts) allAttempts.push(...result.attempts);

        if (result.success) {
          return {
            success: true,
            content: result.content,
            provider: result.provider,
            adapter: result.adapter,
            attempts: allAttempts,
          };
        }
      } catch (err) {
        allAttempts.push({
          provider: entry.adapter.getStatus().name,
          success: false,
          error: err.message,
        });
      }
    }

    // All adapters failed
    return {
      success: false,
      content: '所有 AI 通道均不可用。请检查 CLI 工具、API 密钥或启动 Web 中转服务。',
      provider: 'none',
      adapter: 'none',
      attempts: allAttempts,
    };
  }

  /**
   * Get status of all adapters (for display).
   */
  getStatus() {
    return this._adapters.map(entry => {
      const status = entry.adapter.getStatus();
      return {
        ...status,
        enabled: entry.enabled,
        priority: entry.priority,
      };
    });
  }

  /**
   * Get the first available adapter (for banner display).
   */
  getActiveAdapter() {
    if (!this._initialized) {
      // Quick sync detection (no async needed for status display)
      try {
        for (const entry of this._adapters) {
          if (!entry.enabled) continue;
          if (entry.adapter.detect()) {
            return entry.adapter.getStatus();
          }
        }
      } catch { /* ignore */ }
      return null;
    }

    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      const status = entry.adapter.getStatus();
      if (status.available) return status;
    }
    return null;
  }

  /**
   * Get the web relay adapter directly (for `gateway relay` command).
   */
  getRelayAdapter() {
    return webRelayAdapter;
  }

  /**
   * Tear down all adapters.
   */
  async destroy() {
    for (const entry of this._adapters) {
      if (entry.adapter.destroy) {
        await entry.adapter.destroy();
      }
    }
    this._initialized = false;
  }
}

module.exports = new AIGateway();
