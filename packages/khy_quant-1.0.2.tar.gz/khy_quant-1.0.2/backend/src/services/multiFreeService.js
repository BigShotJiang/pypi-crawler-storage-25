const axios = require('axios');
const jwt = require('jsonwebtoken');

class MultiFreeService {
  constructor() {
    this.baiduToken = null;
    this.baiduTokenExpireAt = 0;

    this.providers = {
      google: {
        name: 'Google Gemini',
        apiKey: process.env.GOOGLE_GEMINI_API_KEY || process.env.GEMINI_API_KEY,
        enabled: !!(process.env.GOOGLE_GEMINI_API_KEY || process.env.GEMINI_API_KEY),
        model: 'gemini-2.5-flash',
        priority: 1
      },
      groq: {
        name: 'Groq',
        apiKey: process.env.GROQ_API_KEY,
        enabled: !!process.env.GROQ_API_KEY,
        model: 'llama-3.3-70b-versatile',
        priority: 2
      },
      openrouter: {
        name: 'OpenRouter',
        apiKey: process.env.OPENROUTER_API_KEY,
        enabled: !!process.env.OPENROUTER_API_KEY,
        model: 'meta-llama/llama-3.3-70b-instruct',
        priority: 3
      },
      openai: {
        name: 'OpenAI',
        apiKey: process.env.OPENAI_API_KEY,
        enabled: !!process.env.OPENAI_API_KEY,
        model: 'gpt-4o-mini',
        priority: 4
      },
      anthropic: {
        name: 'Anthropic',
        apiKey: process.env.ANTHROPIC_API_KEY,
        enabled: !!process.env.ANTHROPIC_API_KEY,
        model: 'claude-3-5-sonnet-20241022',
        priority: 4
      },
      zhipu: {
        name: '智谱AI',
        apiKey: process.env.ZHIPU_API_KEY,
        enabled: !!process.env.ZHIPU_API_KEY,
        model: 'glm-4',
        priority: 5
      },
      xunfei: {
        name: '讯飞星火',
        apiKey: process.env.XUNFEI_API_KEY,
        enabled: !!process.env.XUNFEI_API_KEY,
        model: 'lite',
        priority: 6
      },
      baidu: {
        name: '百度文心',
        apiKey: process.env.BAIDU_API_KEY,
        secretKey: process.env.BAIDU_SECRET_KEY || process.env.BAIDU_API_SECRET || process.env.BAIDU_SECRET || '',
        enabled: !!process.env.BAIDU_API_KEY,
        model: 'ERNIE-Bot',
        priority: 7
      },
      alibaba: {
        name: '通义千问',
        apiKey: process.env.ALIBABA_API_KEY,
        enabled: !!process.env.ALIBABA_API_KEY,
        model: 'qwen-turbo',
        priority: 8
      },
      huggingface: {
        name: 'HuggingFace',
        apiKey: process.env.HUGGINGFACE_TOKEN,
        enabled: !!process.env.HUGGINGFACE_TOKEN,
        model: 'mistralai/Mistral-7B-Instruct-v0.2',
        priority: 9
      }
    };
  }

  getAvailableProviders() {
    return Object.entries(this.providers)
      .filter(([, provider]) => provider.enabled)
      .sort(([, a], [, b]) => a.priority - b.priority)
      .map(([key, provider]) => ({ key, ...provider }));
  }

  getAvailableProvider() {
    const providers = this.getAvailableProviders();
    return providers.length > 0 ? providers[0] : null;
  }

  getStatus() {
    const available = this.getAvailableProviders();
    return {
      available: available.length > 0,
      provider: available[0]?.name || 'local-fallback',
      configuredProviders: available.map((p) => p.name),
      message: available.length > 0
        ? `${available.length} provider(s) configured`
        : 'No cloud providers configured, using local fallback'
    };
  }

  async testConnection() {
    const availableProviders = this.getAvailableProviders().map((p) => p.name);
    if (availableProviders.length === 0) {
      return {
        success: false,
        message: 'No LLM providers configured',
        provider: 'local-fallback',
        response: null,
        availableProviders,
        results: []
      };
    }

    const result = await this.generateResponse('Reply with one short sentence: connection ok.', {
      temperature: 0,
      maxTokens: 64
    });

    return {
      success: result.success,
      message: result.success ? 'LLM connection test completed' : 'LLM connection test failed',
      provider: result.provider,
      response: result.content,
      availableProviders,
      results: result.attempts || []
    };
  }

  async analyze(payload = {}) {
    const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
    const stockCode = payload.stockCode || 'UNKNOWN';
    const result = await this.generateResponse(prompt, {
      temperature: payload.temperature ?? 0.4,
      maxTokens: payload.maxTokens ?? 1500
    });

    if (result.success && result.content) {
      return result.content;
    }

    return this.localFallback(payload.agentId, stockCode);
  }

  async generateResponse(prompt, options = {}) {
    const temperature = options.temperature ?? 0.4;
    const maxTokens = options.maxTokens ?? 1024;

    if (!prompt || !prompt.trim()) {
      return {
        success: false,
        content: 'Prompt is empty',
        provider: 'none',
        attempts: []
      };
    }

    const providers = this.getAvailableProviders();
    const attempts = [];

    for (const provider of providers) {
      try {
        const content = await this.callProvider(provider, prompt, { temperature, maxTokens });
        if (typeof content === 'string' && content.trim()) {
          attempts.push({ provider: provider.name, success: true });
          return {
            success: true,
            content: content.trim(),
            provider: provider.name,
            attempts,
            availableProviders: providers.map((p) => p.name)
          };
        }

        attempts.push({ provider: provider.name, success: false, error: 'Empty response' });
      } catch (error) {
        attempts.push({ provider: provider.name, success: false, error: error.message });
      }
    }

    return {
      success: false,
      content: this.localFallback('general', 'UNKNOWN'),
      provider: 'local-fallback',
      attempts,
      availableProviders: providers.map((p) => p.name)
    };
  }

  async callProvider(provider, prompt, opts) {
    switch (provider.key) {
      case 'google':
        return this.callGoogle(provider, prompt, opts);
      case 'groq':
        return this.callGroq(provider, prompt, opts);
      case 'openrouter':
        return this.callOpenRouter(provider, prompt, opts);
      case 'openai':
        return this.callOpenAI(provider, prompt, opts);
      case 'anthropic':
        return this.callAnthropic(provider, prompt, opts);
      case 'zhipu':
        return this.callZhipu(provider, prompt, opts);
      case 'xunfei':
        return this.callXunfei(provider, prompt, opts);
      case 'baidu':
        return this.callBaidu(provider, prompt, opts);
      case 'alibaba':
        return this.callAlibaba(provider, prompt, opts);
      case 'huggingface':
        return this.callHuggingFace(provider, prompt, opts);
      default:
        throw new Error(`Unsupported provider: ${provider.key}`);
    }
  }

  async callGoogle(provider, prompt, opts) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${provider.apiKey}`;
    const response = await axios.post(url, {
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: {
        temperature: opts.temperature,
        maxOutputTokens: opts.maxTokens
      }
    }, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });

    return response.data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
  }

  async callGroq(provider, prompt, opts) {
    const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
      model: 'llama-3.3-70b-versatile',
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data?.choices?.[0]?.message?.content || '';
  }

  async callOpenRouter(provider, prompt, opts) {
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: provider.model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://khyquant.com',
        'X-Title': 'KHY-Quant'
      },
      timeout: 30000
    });

    return response.data?.choices?.[0]?.message?.content || '';
  }

  async callOpenAI(provider, prompt, opts) {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: provider.model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data?.choices?.[0]?.message?.content || '';
  }

  async callAnthropic(provider, prompt, opts) {
    const response = await axios.post('https://api.anthropic.com/v1/messages', {
      model: provider.model,
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      messages: [{ role: 'user', content: prompt }]
    }, {
      headers: {
        'x-api-key': provider.apiKey,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data?.content?.[0]?.text || '';
  }

  generateZhipuJWT(apiKey) {
    const [id, secret] = apiKey.split('.');
    if (!id || !secret) {
      throw new Error('Invalid Zhipu API key format, expected id.secret');
    }

    const payload = {
      api_key: id,
      exp: Math.round(Date.now() / 1000) + 3600,
      timestamp: Math.round(Date.now() / 1000)
    };

    return jwt.sign(payload, secret, {
      algorithm: 'HS256',
      header: { alg: 'HS256', sign_type: 'SIGN' }
    });
  }

  async callZhipu(provider, prompt, opts) {
    const token = this.generateZhipuJWT(provider.apiKey);
    const response = await axios.post('https://open.bigmodel.cn/api/paas/v4/chat/completions', {
      model: provider.model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data?.choices?.[0]?.message?.content || '';
  }

  async callXunfei(provider, prompt, opts) {
    const response = await axios.post('https://spark-api-open.xf-yun.com/v1/chat/completions', {
      model: 'lite',
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data?.choices?.[0]?.message?.content || response.data?.result || '';
  }

  async callAlibaba(provider, prompt, opts) {
    const response = await axios.post('https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation', {
      model: 'qwen-turbo',
      input: {
        messages: [{ role: 'user', content: prompt }]
      },
      parameters: {
        result_format: 'message',
        temperature: opts.temperature,
        max_tokens: opts.maxTokens
      }
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    return response.data?.output?.choices?.[0]?.message?.content || '';
  }

  async getBaiduAccessToken(provider) {
    const now = Date.now();
    if (this.baiduToken && now < this.baiduTokenExpireAt) {
      return this.baiduToken;
    }

    if (!provider.secretKey) {
      throw new Error('Missing BAIDU_SECRET_KEY for OAuth flow');
    }

    const tokenUrl = `https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${provider.apiKey}&client_secret=${provider.secretKey}`;
    const tokenResponse = await axios.get(tokenUrl, { timeout: 20000 });
    const accessToken = tokenResponse.data?.access_token;

    if (!accessToken) {
      throw new Error('Failed to obtain Baidu access token');
    }

    const expiresIn = Number(tokenResponse.data?.expires_in || 2592000);
    this.baiduToken = accessToken;
    this.baiduTokenExpireAt = now + Math.max(60, expiresIn - 300) * 1000;
    return accessToken;
  }

  async callBaidu(provider, prompt, opts) {
    const accessToken = await this.getBaiduAccessToken(provider);
    const response = await axios.post(
      `https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token=${accessToken}`,
      {
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature,
        top_p: 0.8
      },
      {
        headers: { 'Content-Type': 'application/json' },
        timeout: 30000
      }
    );

    return response.data?.result || '';
  }

  async callHuggingFace(provider, prompt, opts) {
    const response = await axios.post(
      `https://api-inference.huggingface.co/models/${provider.model}`,
      {
        inputs: prompt,
        parameters: {
          max_new_tokens: Math.min(opts.maxTokens, 512),
          temperature: opts.temperature
        }
      },
      {
        headers: {
          Authorization: `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 45000
      }
    );

    if (Array.isArray(response.data) && response.data[0]?.generated_text) {
      return response.data[0].generated_text;
    }

    if (typeof response.data?.generated_text === 'string') {
      return response.data.generated_text;
    }

    return '';
  }

  localFallback(agentId = 'general', stockCode = 'UNKNOWN') {
    const templates = {
      fundamentals: `【基本面分析】${stockCode} 估值与盈利能力处于可追踪区间，建议结合季报数据和行业对比后再做加仓决策。`,
      market: `【市场分析】${stockCode} 当前处于震荡整理结构，建议等待放量突破信号确认后再积极布局。`,
      social: `【情绪分析】${stockCode} 市场情绪分歧较大，建议避免情绪化操作，严格执行既定交易规则。`,
      news: `【新闻分析】${stockCode} 当前暂无明确单边催化剂，建议密切关注官方公告及政策变化动向。`,
      strategy: `【策略分析】${stockCode} 适合采用分批建仓策略，严格设置止损位并控制风险预算。`,
      risk: `【风险分析】${stockCode} 主要风险来自波动率扩张和流动性变化，建议保持保守仓位管理。`
    };

    return templates[agentId] || `【综合分析】${stockCode} 在线大模型服务暂时不可用，已返回本地规则兜底分析结果。`;
  }
}

module.exports = MultiFreeService;
