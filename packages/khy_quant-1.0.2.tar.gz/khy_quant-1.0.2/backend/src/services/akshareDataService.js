﻿/**
 * AKShare数据服务
 * 通过Python子进程调用AKShare获取真实金融数据
 */
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

class AKShareDataService {
  constructor() {
    this.cache = new Map();
    this.cacheTimeout = 300000; // 5分钟缓存
    this.scriptTimeoutMs = parseInt(process.env.AKSHARE_SCRIPT_TIMEOUT_MS || '30000', 10);
    // Windows: 优先使用py (Python Launcher)
    this.pythonPath = require('../utils/pythonPath').findPython();
    this.scriptsDir = path.join(__dirname, '../../akshare_scripts');
    
    // 确保脚本目录存在
    this.ensureScriptsDirectory();
  }

  // 确保AKShare脚本目录存在
  ensureScriptsDirectory() {
    if (!fs.existsSync(this.scriptsDir)) {
      fs.mkdirSync(this.scriptsDir, { recursive: true });
    }
    
    // 创建必要的Python脚本
    this.createPythonScripts();
  }

  // 创建Python脚本文件
  createPythonScripts() {
    // 股票实时数据脚本
    const realtimeScript = `
import akshare as ak
import json
import sys
import pandas as pd
from datetime import datetime, timedelta

def get_stock_realtime(symbol):
    """获取股票实时数据"""
    try:
        # 去掉 sh/sz 前缀
        pure_code = symbol.lower().lstrip('sh').lstrip('sz') if symbol[:2].lower() in ('sh', 'sz') else symbol
        # 获取实时数据
        df = ak.stock_zh_a_spot_em()
        stock_data = df[df['代码'] == pure_code]
        
        if stock_data.empty:
            return {"error": "股票代码不存在: " + pure_code}
        
        row = stock_data.iloc[0]
        
        result = {
            "symbol": symbol,
            "name": row['名称'],
            "current_price": float(row['最新价']),
            "open": float(row['今开']),
            "high": float(row['最高']),
            "low": float(row['最低']),
            "close": float(row['昨收']),
            "volume": int(row['成交量']),
            "amount": float(row['成交额']),
            "change": float(row['涨跌额']),
            "change_percent": float(row['涨跌幅']),
            "source": "AKShare实时数据"
        }
        
        return result
        
    except Exception as e:
        return {"error": str(e)}

def get_stock_kline(symbol, period='daily', count=100):
    """获取股票K线数据"""
    try:
        # 去掉 sh/sz 前缀
        pure_code = symbol.lower().lstrip('sh').lstrip('sz') if symbol[:2].lower() in ('sh', 'sz') else symbol
        # 根据周期选择不同的接口
        if period == 'daily':
            df = ak.stock_zh_a_hist(symbol=pure_code, period="daily", adjust="qfq")
        elif period == 'weekly':
            df = ak.stock_zh_a_hist(symbol=pure_code, period="weekly", adjust="qfq")
        elif period == 'monthly':
            df = ak.stock_zh_a_hist(symbol=pure_code, period="monthly", adjust="qfq")
        else:
            df = ak.stock_zh_a_hist(symbol=pure_code, period="daily", adjust="qfq")
        
        if df.empty:
            return {"error": "无法获取K线数据"}
        
        # 取最近的数据
        df = df.tail(count)
        
        kline_data = []
        for _, row in df.iterrows():
            kline_data.append({
                "time": row['日期'].strftime('%Y-%m-%d'),
                "open": float(row['开盘']),
                "high": float(row['最高']),
                "low": float(row['最低']),
                "close": float(row['收盘']),
                "volume": int(row['成交量'])
            })
        
        return {
            "symbol": symbol,
            "kline": kline_data,
            "source": "AKShare历史数据"
        }
        
    except Exception as e:
        return {"error": str(e)}

def get_index_realtime(symbol):
    """获取指数实时数据"""
    try:
        # 去掉 sh/sz 前缀，akshare 只用纯数字代码
        pure_code = symbol.lower().lstrip('sh').lstrip('sz') if symbol[:2].lower() in ('sh', 'sz') else symbol
        # 获取指数实时数据
        df = ak.stock_zh_index_spot_em()
        index_data = df[df['代码'] == pure_code]
        
        if index_data.empty:
            return {"error": "指数代码不存在: " + pure_code}
        
        row = index_data.iloc[0]
        
        result = {
            "symbol": symbol,
            "name": row['名称'],
            "current_price": float(row['最新价']),
            "open": float(row['今开']),
            "high": float(row['最高']),
            "low": float(row['最低']),
            "close": float(row['昨收']),
            "volume": int(row['成交量']) if '成交量' in row else 0,
            "amount": float(row['成交额']) if '成交额' in row else 0,
            "change": float(row['涨跌额']),
            "change_percent": float(row['涨跌幅']),
            "source": "AKShare指数数据"
        }
        
        return result
        
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "参数不足"}))
        sys.exit(1)
    
    action = sys.argv[1]
    symbol = sys.argv[2]
    
    if action == "realtime":
        result = get_stock_realtime(symbol)
    elif action == "kline":
        count = int(sys.argv[3]) if len(sys.argv) > 3 else 100
        period = sys.argv[4] if len(sys.argv) > 4 else 'daily'
        result = get_stock_kline(symbol, period, count)
    elif action == "index":
        result = get_index_realtime(symbol)
    else:
        result = {"error": "未知操作"}
    
    print(json.dumps(result, ensure_ascii=False, default=str))
`;

    const scriptPath = path.join(this.scriptsDir, 'akshare_data.py');
    fs.writeFileSync(scriptPath, realtimeScript, 'utf8');

    // 创建requirements.txt
    const requirements = `akshare>=1.12.0
pandas>=1.3.0
requests>=2.25.0
`;
    fs.writeFileSync(path.join(this.scriptsDir, 'requirements.txt'), requirements, 'utf8');
  }

  // 执行Python脚本
  async executePythonScript(action, symbol, ...args) {
    return new Promise((resolve, reject) => {
      const scriptPath = path.join(this.scriptsDir, 'akshare_data.py');
      const pythonArgs = [scriptPath, action, symbol, ...args];
      
      console.log(`执行AKShare脚本: ${this.pythonPath} ${pythonArgs.join(' ')}`);
      
      let pythonProcess;
      try {
        pythonProcess = spawn(this.pythonPath, pythonArgs);
      } catch (spawnError) {
        console.error('❌ 无法启动Python进程:', spawnError.message);
        reject(new Error(`Python不可用: ${spawnError.message}`));
        return;
      }
      
      let stdout = '';
      let stderr = '';
      
      // 🔥 添加错误事件监听器
      pythonProcess.on('error', (error) => {
        console.error('❌ Python进程错误:', error.message);
        reject(new Error(`Python进程错误: ${error.message}`));
      });
      
      pythonProcess.stdout.on('data', (data) => {
        stdout += data.toString();
      });
      
      pythonProcess.stderr.on('data', (data) => {
        stderr += data.toString();
      });
      
      pythonProcess.on('close', (code) => {
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        if (code !== 0) {
          console.error(`Python脚本执行失败，退出码: ${code}`);
          console.error(`错误信息: ${stderr}`);
          reject(new Error(`Python脚本执行失败: ${stderr}`));
          return;
        }
        
        try {
          const result = JSON.parse(stdout);
          if (result.error) {
            reject(new Error(result.error));
          } else {
            resolve(result);
          }
        } catch (error) {
          console.error('解析Python脚本输出失败:', stdout);
          reject(new Error(`解析输出失败: ${error.message}`));
        }
      });
      
      const timeoutId = setTimeout(() => {
        try { pythonProcess.kill('SIGKILL'); } catch {}
        reject(new Error(`Python脚本执行超时(${Math.round(this.scriptTimeoutMs / 1000)}s)`));
      }, this.scriptTimeoutMs);
    });
  }

  // 获取股票实时数据
  async getStockRealtime(symbol) {
    const cacheKey = `realtime_${symbol}`;
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      console.log(`使用AKShare缓存数据: ${symbol}`);
      return cached.data;
    }

    try {
      console.log(`从AKShare获取实时数据: ${symbol}`);
      const result = await this.executePythonScript('realtime', symbol);
      
      // 缓存数据
      this.cache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });
      
      return result;
    } catch (error) {
      console.error(`AKShare获取实时数据失败: ${error.message}`);
      throw error;
    }
  }

  // 获取股票K线数据
  async getStockKline(symbol, period = 'daily', count = 100) {
    const cacheKey = `kline_${symbol}_${period}_${count}`;
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      console.log(`使用AKShare K线缓存数据: ${symbol}`);
      return cached.data;
    }

    try {
      console.log(`从AKShare获取K线数据: ${symbol}, 周期: ${period}, 数量: ${count}`);
      const result = await this.executePythonScript('kline', symbol, count.toString(), period);
      
      // 缓存数据
      this.cache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });
      
      return result;
    } catch (error) {
      console.error(`AKShare获取K线数据失败: ${error.message}`);
      throw error;
    }
  }

  // 获取指数实时数据
  async getIndexRealtime(symbol) {
    const cacheKey = `index_${symbol}`;
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      console.log(`使用AKShare指数缓存数据: ${symbol}`);
      return cached.data;
    }

    try {
      console.log(`从AKShare获取指数数据: ${symbol}`);
      const result = await this.executePythonScript('index', symbol);
      
      // 缓存数据
      this.cache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });
      
      return result;
    } catch (error) {
      console.error(`AKShare获取指数数据失败: ${error.message}`);
      throw error;
    }
  }

  // 获取指数历史数据
  async getIndexHistory(symbol, options = {}) {
    const { startDate, endDate, period = 'daily' } = options;
    const cacheKey = `index_history_${symbol}_${startDate}_${endDate}_${period}`;
    const cached = this.cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
      console.log(`使用AKShare指数历史缓存数据: ${symbol}`);
      return cached.data;
    }

    try {
      console.log(`从AKShare获取指数历史数据: ${symbol}, 周期: ${period}`);
      
      // 格式化日期为YYYYMMDD
      const formattedStartDate = startDate ? startDate.replace(/-/g, '') : null;
      const formattedEndDate = endDate ? endDate.replace(/-/g, '') : null;
      
      const args = [formattedStartDate, formattedEndDate, period].filter(arg => arg !== null);
      const result = await this.executePythonScript('index_history', symbol, ...args);
      
      // 缓存数据
      this.cache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });
      
      return result;
    } catch (error) {
      console.error(`AKShare获取指数历史数据失败: ${error.message}`);
      throw error;
    }
  }

  // 获取综合股票数据（实时+K线）
  async getStockData(symbol, options = {}) {
    try {
      // 判断是否为指数
      const isIndex = this.isIndexSymbol(symbol);
      
      let realtimeData;
      if (isIndex) {
        realtimeData = await this.getIndexRealtime(symbol);
      } else {
        realtimeData = await this.getStockRealtime(symbol);
      }
      
      // 获取K线数据，支持日期范围
      const { startDate, endDate, period = 'daily' } = options;
      let klineData;
      
      if (startDate || endDate) {
        // 格式化日期为YYYYMMDD
        const formattedStartDate = startDate ? startDate.replace(/-/g, '') : null;
        const formattedEndDate = endDate ? endDate.replace(/-/g, '') : null;
        
        const args = [formattedStartDate, formattedEndDate, period].filter(arg => arg !== null);
        klineData = await this.executePythonScript('kline', symbol, ...args);
      } else {
        klineData = await this.getStockKline(symbol, period, 100);
      }
      
      return {
        symbol: symbol,
        name: realtimeData.name,
        currentPrice: realtimeData.current_price,
        open: realtimeData.open,
        high: realtimeData.high,
        low: realtimeData.low,
        volume: realtimeData.volume,
        amount: realtimeData.amount,
        change: realtimeData.change,
        changePercent: realtimeData.change_percent,
        kline: klineData.kline,
        source: 'AKShare'
      };
    } catch (error) {
      console.error(`AKShare获取股票数据失败: ${error.message}`);
      throw error;
    }
  }

  // 判断是否为指数代码
  isIndexSymbol(symbol) {
    const indexPrefixes = ['sh000', 'sz399', '000001', '399001', '399006'];
    return indexPrefixes.some(prefix => symbol.startsWith(prefix));
  }

  // 检查AKShare环境
  async checkEnvironment() {
    try {
      const result = await this.executePythonScript('realtime', '000001');
      return {
        available: true,
        message: 'AKShare环境正常'
      };
    } catch (error) {
      return {
        available: false,
        message: `AKShare环境检查失败: ${error.message}`,
        suggestion: '请确保已安装Python和AKShare库: pip install akshare'
      };
    }
  }

  // 安装AKShare依赖
  async installDependencies() {
    return new Promise((resolve, reject) => {
      const requirementsPath = path.join(this.scriptsDir, 'requirements.txt');
      const installProcess = spawn(this.pythonPath, ['-m', 'pip', 'install', '-r', requirementsPath]);
      
      let stdout = '';
      let stderr = '';
      
      installProcess.stdout.on('data', (data) => {
        stdout += data.toString();
      });
      
      installProcess.stderr.on('data', (data) => {
        stderr += data.toString();
      });
      
      installProcess.on('close', (code) => {
        if (code === 0) {
          resolve({
            success: true,
            message: 'AKShare依赖安装成功',
            output: stdout
          });
        } else {
          reject(new Error(`依赖安装失败: ${stderr}`));
        }
      });
    });
  }

  // 清理过期缓存
  clearExpiredCache() {
    const now = Date.now();
    for (const [key, value] of this.cache.entries()) {
      if (now - value.timestamp > this.cacheTimeout) {
        this.cache.delete(key);
      }
    }
  }

  // 获取支持的股票列表
  getSupportedStocks() {
    return [
      // 主要指数
      { symbol: '000001', name: '上证指数', type: 'index' },
      { symbol: '399001', name: '深证成指', type: 'index' },
      { symbol: '399006', name: '创业板指', type: 'index' },
      { symbol: '000300', name: '沪深300', type: 'index' },
      
      // 热门股票
      { symbol: '000001', name: '平安银行', type: 'stock' },
      { symbol: '000002', name: '万科A', type: 'stock' },
      { symbol: '600000', name: '浦发银行', type: 'stock' },
      { symbol: '600036', name: '招商银行', type: 'stock' },
      { symbol: '600519', name: '贵州茅台', type: 'stock' },
      { symbol: '000858', name: '五粮液', type: 'stock' }
    ];
  }
}

module.exports = new AKShareDataService();
