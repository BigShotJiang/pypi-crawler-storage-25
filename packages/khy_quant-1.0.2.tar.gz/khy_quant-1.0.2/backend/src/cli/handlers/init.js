/**
 * CLI Handlers: init (setup wizard) and doctor (environment diagnostic).
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const chalk = require('chalk');
const {
  printSuccess, printError, printWarn, printInfo, printTable, withSpinner,
  MASCOT_MINI, ICON_HEART, ICON_GEAR,
} = require('../formatters');

const ROOT = path.resolve(__dirname, '../../../');
const ENV_FILE = path.join(ROOT, '.env');

// ── Helper: silent command execution ─────────────────────────────────────────

function runSilent(cmd, args = []) {
  try {
    return execFileSync(cmd, args, { encoding: 'utf-8', timeout: 15000, stdio: ['pipe', 'pipe', 'pipe'] }).trim();
  } catch {
    return null;
  }
}

// ── khy init ─────────────────────────────────────────────────────────────────

/**
 * Interactive initialization wizard using inquirer.
 * Lighter than setup.js — assumes Node deps are already installed.
 */
async function handleInit(options = {}) {
  const inquirer = require('inquirer');

  console.log('');
  console.log(`  ${ICON_GEAR} ${chalk.cyan.bold('KHY-Quant 初始化向导')}`);
  console.log(chalk.dim('     快速配置环境，让系统正常运行'));
  console.log('');

  // Check what needs initialization
  const checks = runDoctorChecks();
  const issues = checks.filter(c => !c.ok);

  if (issues.length === 0 && !options.force) {
    printSuccess('环境检测正常，无需初始化');
    printInfo('如需强制重新初始化，请使用 init --force');
    return;
  }

  // Show current issues
  if (issues.length > 0) {
    console.log(chalk.yellow('  发现以下问题:'));
    issues.forEach(issue => {
      console.log(chalk.red('    ✗ ') + issue.label + ': ' + issue.detail);
    });
    console.log('');
  }

  // .env configuration
  if (!fs.existsSync(ENV_FILE) || options.force) {
    const { dbType } = await inquirer.prompt([{
      type: 'list',
      name: 'dbType',
      message: '选择数据库类型:',
      choices: [
        { name: 'SQLite (零配置，推荐开发)', value: 'sqlite' },
        { name: 'PostgreSQL (生产推荐)', value: 'postgres' },
      ],
    }]);

    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: '服务端口:',
      default: '8080',
      validate: (v) => /^\d+$/.test(v) ? true : '请输入数字',
    }]);

    let pgConfig = {};
    if (dbType === 'postgres') {
      pgConfig = (await inquirer.prompt([
        { type: 'input', name: 'dbHost', message: 'PostgreSQL 地址:', default: '127.0.0.1' },
        { type: 'input', name: 'dbPort', message: 'PostgreSQL 端口:', default: '5432' },
        { type: 'input', name: 'dbName', message: '数据库名称:', default: 'quant_trading' },
        { type: 'input', name: 'dbUser', message: '数据库用户:', default: 'postgres' },
        { type: 'password', name: 'dbPassword', message: '数据库密码 (留空自动生成):' },
      ]));
    }

    // Generate secure JWT secret
    const crypto = require('crypto');
    const jwtSecret = crypto.randomBytes(32).toString('hex');
    if (!pgConfig.dbPassword) pgConfig.dbPassword = crypto.randomBytes(16).toString('hex');

    const lines = [
      '# KHY-Quant Environment Configuration',
      `# Generated: ${new Date().toISOString()}`,
      '',
      `DB_TYPE=${dbType}`,
    ];

    if (dbType === 'postgres') {
      lines.push(`DB_HOST=${pgConfig.dbHost}`);
      lines.push(`DB_PORT=${pgConfig.dbPort}`);
      lines.push(`DB_NAME=${pgConfig.dbName}`);
      lines.push(`DB_USER=${pgConfig.dbUser}`);
      lines.push(`DB_PASSWORD=${pgConfig.dbPassword}`);
    }

    lines.push('', `PORT=${port}`, 'NODE_ENV=development', 'LOG_LEVEL=info');
    lines.push('', `JWT_SECRET=${jwtSecret}`, 'JWT_EXPIRES_IN=7d');
    lines.push('', 'ENABLE_AKSHARE=true', 'ENABLE_TUSHARE=false', 'DEFAULT_DATA_SOURCE=reliable');
    lines.push('', '# AI Providers', '# GEMINI_API_KEY=', '# GROQ_API_KEY=');

    fs.writeFileSync(ENV_FILE, lines.join('\n') + '\n');
    // Restrict .env permissions to owner only (Unix)
    if (process.platform !== 'win32') {
      try { fs.chmodSync(ENV_FILE, 0o600); } catch { /* ignore */ }
    }
    printSuccess('.env 配置文件已生成');
  } else {
    printInfo('.env 已存在，跳过');
  }

  // Database initialization
  const { shouldInitDb } = await inquirer.prompt([{
    type: 'confirm',
    name: 'shouldInitDb',
    message: '初始化数据库结构?',
    default: true,
  }]);

  if (shouldInitDb) {
    await withSpinner('初始化数据库...', async () => {
      const { bootstrap } = require('../bootstrap');
      await bootstrap({ syncSchema: true, silent: true });
    }, { muteOutput: true });
  }

  // Seed data
  const { shouldSeed } = await inquirer.prompt([{
    type: 'confirm',
    name: 'shouldSeed',
    message: '填充示例数据（策略、品种）?',
    default: true,
  }]);

  if (shouldSeed) {
    await withSpinner('填充示例数据...', async () => {
      const { execFileSync } = require('child_process');
      execFileSync(process.execPath, [path.join(ROOT, 'scripts', 'seed.js')], {
        cwd: ROOT,
        stdio: 'pipe',
        timeout: 60000,
      });
    }, { muteOutput: true });
  }

  // AI key configuration
  const { configAi } = await inquirer.prompt([{
    type: 'confirm',
    name: 'configAi',
    message: '现在配置 AI 密钥?',
    default: false,
  }]);

  if (configAi) {
    const { handleAiConfig } = require('../ai');
    await handleAiConfig();
  }

  console.log('');
  printSuccess('初始化完成！输入 help 查看可用命令');
  console.log('');
}

// ── khy doctor ───────────────────────────────────────────────────────────────

/**
 * Run all environment diagnostic checks and display results.
 */
async function handleDoctor() {
  console.log('');
  console.log(`  ${ICON_HEART} ${chalk.cyan.bold('KHY-Quant 环境诊断')}`);
  console.log(chalk.dim('     检查系统环境是否满足运行要求'));
  console.log('');

  const checks = runDoctorChecks();

  // Group by category
  const categories = {};
  checks.forEach(check => {
    if (!categories[check.category]) categories[check.category] = [];
    categories[check.category].push(check);
  });

  let totalOk = 0;
  let totalFail = 0;
  let totalWarn = 0;

  for (const [category, items] of Object.entries(categories)) {
    console.log(chalk.cyan(`  ${category}`));
    items.forEach(item => {
      const icon = item.ok ? chalk.green('✓') : (item.level === 'warn' ? chalk.yellow('⚠') : chalk.red('✗'));
      const detail = item.detail ? chalk.dim(` — ${item.detail}`) : '';
      console.log(`    ${icon} ${item.label}${detail}`);
      if (item.ok) totalOk++;
      else if (item.level === 'warn') totalWarn++;
      else totalFail++;
    });
    console.log('');
  }

  // Summary
  const summary = [];
  if (totalOk > 0) summary.push(chalk.green(`${totalOk} 通过`));
  if (totalWarn > 0) summary.push(chalk.yellow(`${totalWarn} 警告`));
  if (totalFail > 0) summary.push(chalk.red(`${totalFail} 失败`));
  console.log(`  ${chalk.bold('总计:')} ${summary.join(' · ')}`);

  if (totalFail > 0) {
    console.log('');
    printInfo('运行 khy init 修复问题');
  } else if (totalWarn > 0) {
    console.log('');
    printInfo('所有核心功能正常，部分可选功能不可用');
  } else {
    console.log('');
    printSuccess('所有检查通过，系统就绪');
  }
  console.log('');
}

/**
 * Run all diagnostic checks, return array of { category, label, ok, detail, level }.
 */
function runDoctorChecks() {
  const results = [];

  // ── Runtime ──────────────────────────────────────────────────────────────
  const nodeVer = process.version;
  const nodeMajor = parseInt(nodeVer.slice(1), 10);
  results.push({
    category: '运行环境',
    label: 'Node.js',
    ok: nodeMajor >= 16,
    detail: `${nodeVer} ${nodeMajor >= 16 ? '(≥16)' : '(需要 ≥16)'}`,
    level: 'error',
  });

  // Python
  let pythonCmd = null;
  for (const cmd of ['python3', 'python', 'py']) {
    const ver = runSilent(cmd, ['--version']);
    if (ver && ver.includes('Python 3')) {
      pythonCmd = cmd;
      const match = ver.match(/Python (\d+\.\d+\.\d+)/);
      results.push({
        category: '运行环境',
        label: 'Python',
        ok: true,
        detail: `${match ? match[1] : ver} (${cmd})`,
        level: 'warn',
      });
      break;
    }
  }
  if (!pythonCmd) {
    results.push({
      category: '运行环境',
      label: 'Python',
      ok: false,
      detail: '未安装 — 数据获取功能不可用',
      level: 'warn',
    });
  }

  // Git
  const gitVer = runSilent('git', ['--version']);
  results.push({
    category: '运行环境',
    label: 'Git',
    ok: !!gitVer,
    detail: gitVer || '未安装',
    level: 'warn',
  });

  // ── Python packages ──────────────────────────────────────────────────────
  if (pythonCmd) {
    const pipCmd = `${pythonCmd} -m pip`;
    for (const pkg of ['akshare']) {
      const installed = !!runSilent(pythonCmd, ['-m', 'pip', 'show', pkg]);
      results.push({
        category: 'Python 依赖',
        label: pkg,
        ok: installed,
        detail: installed ? '已安装' : '未安装',
        level: 'warn',
      });
    }
  }

  // ── Configuration ────────────────────────────────────────────────────────
  results.push({
    category: '项目配置',
    label: '.env 文件',
    ok: fs.existsSync(ENV_FILE),
    detail: fs.existsSync(ENV_FILE) ? '已配置' : '未找到 — 运行 khy init 生成',
    level: 'error',
  });

  // Check node_modules
  const hasNodeModules = fs.existsSync(path.join(ROOT, 'node_modules'));
  results.push({
    category: '项目配置',
    label: 'Node 依赖',
    ok: hasNodeModules,
    detail: hasNodeModules ? '已安装' : '未安装 — 运行 npm install',
    level: 'error',
  });

  // ── Database ─────────────────────────────────────────────────────────────
  // Check if .env has DB_TYPE and if SQLite file exists
  if (fs.existsSync(ENV_FILE)) {
    const envContent = fs.readFileSync(ENV_FILE, 'utf-8');
    const dbType = envContent.match(/DB_TYPE=(\w+)/)?.[1] || 'auto';

    results.push({
      category: '数据库',
      label: '数据库类型',
      ok: true,
      detail: dbType,
      level: 'info',
    });

    if (dbType === 'sqlite' || dbType === 'auto') {
      // Check for SQLite file in common locations
      const sqliteLocations = [
        path.join(ROOT, 'data', 'khy-quant.db'),
        path.join(ROOT, 'khy-quant.db'),
        path.join(ROOT, 'data', 'database.sqlite'),
      ];
      const dbExists = sqliteLocations.some(p => fs.existsSync(p));
      results.push({
        category: '数据库',
        label: 'SQLite 数据文件',
        ok: dbExists,
        detail: dbExists ? '已创建' : '未创建 — 运行 khy db init',
        level: 'warn',
      });
    }
  }

  // ── Network services ─────────────────────────────────────────────────────
  // Redis check
  const redisOk = !!runSilent('redis-cli', ['ping']);
  results.push({
    category: '可选服务',
    label: 'Redis',
    ok: redisOk,
    detail: redisOk ? '运行中' : '未运行 — 将使用内存缓存',
    level: 'warn',
  });

  // AI provider check
  if (fs.existsSync(ENV_FILE)) {
    const envContent = fs.readFileSync(ENV_FILE, 'utf-8');
    const aiKeys = [
      'GEMINI_API_KEY', 'GROQ_API_KEY', 'OPENROUTER_API_KEY',
      'ZHIPU_API_KEY', 'OPENAI_API_KEY', 'ANTHROPIC_API_KEY',
    ];
    const hasAiKey = aiKeys.some(key => {
      const match = envContent.match(new RegExp(`^${key}=(.+)$`, 'm'));
      return match && match[1] && !match[1].startsWith('#');
    });
    results.push({
      category: '可选服务',
      label: 'AI 密钥',
      ok: hasAiKey,
      detail: hasAiKey ? '已配置' : '未配置 — 运行 khy ai config',
      level: 'warn',
    });
  }

  return results;
}

module.exports = { handleInit, handleDoctor, runDoctorChecks };
