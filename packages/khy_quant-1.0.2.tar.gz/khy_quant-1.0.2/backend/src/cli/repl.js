/**
 * Interactive REPL — the heart of the CLI.
 * Combines command mode, menu mode, and AI conversation mode.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const { printBanner, printError, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell } = require('./formatters');
const { parseInput, route, getCompletions } = require('./router');
const { getActiveProvider, handleAiStatus, handleAiConfig, chat } = require('./ai');
const { runMenuLoop } = require('./menu');

const os = require('os');
const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;
const VERSION = require('../../package.json').version;

/**
 * Load command history from file.
 */
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

/**
 * Save command history to file.
 */
function saveHistory(history) {
  try {
    const lines = history.slice(-MAX_HISTORY);
    fs.writeFileSync(HISTORY_FILE, lines.join('\n') + '\n');
  } catch { /* ignore */ }
}

/**
 * Execute a menu result by mapping it back to command handlers.
 */
async function executeMenuResult(result) {
  if (!result) return;

  switch (result.action) {
    case 'quote': {
      const { handleQuote } = require('./handlers/data');
      await handleQuote(result.symbol);
      break;
    }
    case 'backtest-run': {
      const { handleBacktestRun } = require('./handlers/backtest');
      await handleBacktestRun(result.symbol, {
        strategy: result.strategy,
        start: result.start,
        end: result.end,
        capital: result.capital,
      });
      break;
    }
    case 'data-fetch': {
      const { handleDataFetch } = require('./handlers/data');
      await handleDataFetch(result.symbol);
      break;
    }
    case 'data-list': {
      const { handleDataList } = require('./handlers/data');
      await handleDataList();
      break;
    }
    case 'cache-clear': {
      const { handleCacheClear } = require('./handlers/data');
      await handleCacheClear();
      break;
    }
    case 'server-start': {
      const { handleServerStart } = require('./handlers/service');
      await handleServerStart();
      break;
    }
    case 'server-status': {
      const { handleServerStatus } = require('./handlers/service');
      await handleServerStatus();
      break;
    }
    case 'db-init': {
      const { handleDbInit } = require('./handlers/service');
      await handleDbInit();
      break;
    }
    case 'db-seed': {
      const { handleDbSeed } = require('./handlers/service');
      await handleDbSeed();
      break;
    }
    case 'db-status': {
      const { handleDbStatus } = require('./handlers/service');
      await handleDbStatus();
      break;
    }
    case 'ai-status':
      await handleAiStatus();
      break;
    case 'ai-config':
      await handleAiConfig();
      break;
    case 'doctor': {
      const { handleDoctor } = require('./handlers/init');
      await handleDoctor();
      break;
    }
    case 'gateway-status': {
      const { handleGatewayStatus } = require('./handlers/gateway');
      await handleGatewayStatus();
      break;
    }
    case 'gateway-config': {
      const { handleGatewayConfig } = require('./handlers/gateway');
      await handleGatewayConfig();
      break;
    }
    case 'gateway-relay': {
      const { handleGatewayRelay } = require('./handlers/gateway');
      await handleGatewayRelay();
      break;
    }
  }
}

/**
 * Start the interactive REPL loop.
 */
async function startRepl() {
  // Show banner
  const aiProvider = getActiveProvider();
  printBanner(VERSION, aiProvider);

  // Setup readline
  const history = loadHistory();

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: chalk.cyan(MASCOT_MINI + ' khy') + chalk.dim(` ${ICON_PROMPT} `),
    historySize: MAX_HISTORY,
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });

  // Prepopulate history
  history.forEach(line => rl.history.push(line));

  rl.prompt();

  let _busy = false;

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (!trimmed) {
      rl.prompt();
      return;
    }

    // Prevent concurrent command execution
    if (_busy) return;
    _busy = true;

    // Save to history
    history.push(trimmed);

    // Parse and route the command
    const parsed = parseInput(trimmed);
    if (!parsed) {
      _busy = false;
      rl.prompt();
      return;
    }

    try {
      const result = await route(parsed);

      if (result === 'exit') {
        saveHistory(history);
        console.log('');
        console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
        console.log('');
        process.exit(0);
      }

      if (result === 'menu') {
        const menuResult = await runMenuLoop();
        await executeMenuResult(menuResult);
        rl.prompt();
        return;
      }

      if (result === 'ai-status') {
        await handleAiStatus();
        rl.prompt();
        return;
      }

      if (result === 'ai-config') {
        await handleAiConfig();
        rl.prompt();
        return;
      }

      if (result === true) {
        // Command was handled
        rl.prompt();
        return;
      }

      // result.aiForward → a command generated a prompt for AI
      const aiInput = (result && result.aiForward) ? result.aiForward : trimmed;

      // result === false or aiForward → send to AI
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false };

      const onChunk = (chunk) => {
        if (chunk.type === 'thinking') {
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState.phase = 'thinking';
            console.log('');
            console.log(chalk.yellow(`  ${ICON_BOT} 思考过程:`));
            console.log(chalk.dim('  ┌──'));
          }
          // Print thinking text inline (may arrive in small fragments)
          const thinkLines = chunk.text.split('\n');
          thinkLines.forEach(l => process.stdout.write(chalk.dim('  │ ') + chalk.yellow(l) + '\n'));
        } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            console.log(chalk.dim('  └──'));
            console.log('');
            streamState.phase = 'text';
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            // Header will be printed after streaming completes
          }
        } else if (chunk.type === 'cost') {
          streamState.cost = chunk.cost;
        }
      };

      console.log(chalk.dim(`  ${ICON_BOT} 请求中...`));

      const aiResult = await chat(aiInput, { onChunk });

      // Close thinking block if it was still open
      if (streamState.phase === 'thinking') {
        console.log(chalk.dim('  └──'));
        console.log('');
      }

      if (aiResult.reply) {
        const adapterTag = aiResult.adapter ? ` via ${aiResult.adapter}` : '';
        const costTag = streamState.cost ? chalk.dim(` [$${streamState.cost.toFixed(4)}]`) : '';
        console.log(chalk.magenta(`  ${ICON_BOT} AI`) + chalk.dim(` (${aiResult.provider || 'local'}${adapterTag})`) + costTag + chalk.magenta(':'));
        console.log(chalk.dim('  ┌──'));
        const lines = aiResult.reply.split('\n');
        lines.forEach(l => console.log(chalk.dim('  │ ') + l));
        console.log(chalk.dim('  └──'));
        console.log('');
      }

      // Execute any embedded commands
      if (aiResult.commands && aiResult.commands.length > 0) {
        for (const cmd of aiResult.commands) {
          console.log(chalk.dim(`  → 执行: ${cmd}`));
          try {
            const cmdParsed = parseInput(cmd);
            if (cmdParsed) {
              await route(cmdParsed);
            }
          } catch (cmdErr) {
            printError(cmdErr.message || '命令执行失败');
          }
        }
      }

    } catch (err) {
      printError(err.message || '执行出错');
    }

    _busy = false;
    rl.prompt();
  });

  // Handle Ctrl+D or unexpected close — only exit if not already handled
  rl.on('close', () => {
    saveHistory(history);
    // Avoid double-printing if already exiting via 'exit' command
    if (!rl._exiting) {
      console.log('');
      console.log(chalk.cyan(`  ${MASCOT_MINI} `) + chalk.dim(getRandomFarewell()));
      console.log('');
    }
    process.exit(0);
  });
}

module.exports = { startRepl };
