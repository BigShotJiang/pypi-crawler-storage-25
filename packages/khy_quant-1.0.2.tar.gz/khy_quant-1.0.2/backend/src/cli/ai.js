/**
 * AI conversational mode for the CLI.
 * When user input doesn't match a known command, it's sent to the LLM
 * with a quant-trading system prompt. The AI can also invoke tools
 * (quote, backtest, data fetch) by returning structured commands.
 */
const path = require('path');
const chalk = require('chalk');
const { printInfo, printError, printSuccess, withSpinner } = require('./formatters');

let _service = null;
let _gateway = null;
let _messages = []; // conversation history (capped at MAX_HISTORY)
const MAX_HISTORY = 10;

const SYSTEM_PROMPT = `你是 KHY-Quant 量化交易终端的 AI 助手。你可以帮助用户进行股票/期货分析、策略回测、数据查询等操作。

你有以下工具可以使用（通过在回复中包含特殊指令）：
- [CMD:quote <代码>] — 查询实时行情
- [CMD:backtest <代码> --strategy <id> --start <日期> --end <日期>] — 运行回测
- [CMD:data fetch <代码>] — 下载K线数据
- [CMD:strategy list] — 查看策略列表
- [CMD:data list] — 查看品种列表

当用户的请求需要执行操作时，在你的回复中包含上述指令，系统会自动执行并展示结果。

规则：
1. 用中文回复
2. 简洁专业，像资深量化交易员一样交流
3. 如果用户问到具体股票，先建议查看行情数据
4. 对于投资建议，明确说明这是基于技术分析，不构成投资建议`;

function getService() {
  if (!_service) {
    const MultiFreeService = require('../services/multiFreeService');
    _service = new MultiFreeService();
  }
  return _service;
}

function getGateway() {
  if (!_gateway) {
    _gateway = require('../services/gateway/aiGateway');
  }
  return _gateway;
}

/**
 * Check AI availability and return provider info.
 */
function getAiStatus() {
  const svc = getService();
  return svc.getStatus();
}

/**
 * Get the name of the active AI provider (for banner display).
 * Checks gateway adapters first, then direct MultiFreeService.
 */
function getActiveProvider() {
  // Check gateway adapters (CLI tools, API, relay)
  try {
    const gw = getGateway();
    const active = gw.getActiveAdapter();
    if (active) return `${active.name}`;
  } catch { /* gateway not available */ }

  // Fallback to direct service check
  const svc = getService();
  const provider = svc.getAvailableProvider();
  return provider ? provider.name : null;
}

/**
 * Show AI status in terminal.
 */
async function handleAiStatus() {
  const status = getAiStatus();

  if (status.available) {
    printSuccess(`AI 服务可用 — ${status.provider}`);
    if (status.configuredProviders.length > 1) {
      printInfo(`已配置 ${status.configuredProviders.length} 个提供商: ${status.configuredProviders.join(', ')}`);
    }

    // Test connection
    const svc = getService();
    const test = await withSpinner('测试 AI 连接...', () => svc.testConnection());
    if (test.success) {
      printSuccess(`连接正常 (${test.provider})`);
    } else {
      printError('连接测试失败');
    }
  } else {
    printError('未配置 AI 密钥');
    printInfo('运行 ai config 配置 API 密钥');
  }
}

/**
 * Interactive API key configuration.
 */
async function handleAiConfig() {
  const inquirer = require('inquirer');
  const fs = require('fs');

  const envPath = path.resolve(__dirname, '../../.env');
  let envContent = '';
  try {
    envContent = fs.readFileSync(envPath, 'utf-8');
  } catch {
    envContent = '';
  }

  const providers = [
    { env: 'GEMINI_API_KEY', name: 'Google Gemini (推荐, 免费额度)' },
    { env: 'GROQ_API_KEY', name: 'Groq (免费, 快速)' },
    { env: 'OPENROUTER_API_KEY', name: 'OpenRouter' },
    { env: 'OPENAI_API_KEY', name: 'OpenAI' },
    { env: 'ANTHROPIC_API_KEY', name: 'Anthropic Claude' },
    { env: 'ZHIPU_API_KEY', name: '智谱AI' },
    { env: 'ALIBABA_API_KEY', name: '通义千问' },
  ];

  const { selected } = await inquirer.prompt([{
    type: 'list',
    name: 'selected',
    message: '选择要配置的 AI 提供商:',
    choices: providers.map(p => {
      const current = process.env[p.env];
      const status = current ? chalk.green(' [已配置]') : chalk.dim(' [未配置]');
      return { name: p.name + status, value: p.env };
    }),
  }]);

  const { apiKey } = await inquirer.prompt([{
    type: 'password',
    name: 'apiKey',
    message: `输入 ${selected} 密钥:`,
    mask: '*',
    validate: v => v.trim().length > 0 || '密钥不能为空',
  }]);

  // Update .env file
  const regex = new RegExp(`^${selected}=.*$`, 'm');
  const newLine = `${selected}=${apiKey.trim()}`;

  if (regex.test(envContent)) {
    envContent = envContent.replace(regex, newLine);
  } else {
    envContent = envContent.trimEnd() + '\n' + newLine + '\n';
  }

  fs.writeFileSync(envPath, envContent);
  process.env[selected] = apiKey.trim();

  // Reinitialize services to pick up new key
  _service = null;
  try {
    const apiAdapter = require('../services/gateway/adapters/apiAdapter');
    apiAdapter.resetService();
  } catch { /* gateway not loaded yet */ }

  printSuccess(`${selected} 已保存到 .env`);
  printInfo('密钥已生效，可以开始使用 AI 功能');
}

/**
 * Send a message to the AI and get a response.
 * Uses the AI Gateway for routing (CLI tools → API → Web relay).
 * Returns { reply, commands, provider, adapter }.
 *
 * @param {string} userMessage
 * @param {object} [opts]
 * @param {function} [opts.onChunk] - streaming callback { type: 'thinking'|'text'|'cost', text }
 */
async function chat(userMessage, opts = {}) {
  // Build conversation prompt with history
  _messages.push({ role: 'user', content: userMessage });

  const recentMessages = _messages.slice(-10);
  const conversationPrompt = [
    SYSTEM_PROMPT,
    '',
    ...recentMessages.map(m => `${m.role === 'user' ? '用户' : 'AI'}: ${m.content}`),
  ].join('\n');

  // Try gateway first (CLI tools → API → Web relay)
  let result;
  try {
    const gw = getGateway();
    if (!gw._initialized) await gw.init();
    result = await gw.generate(conversationPrompt, {
      temperature: 0.4,
      maxTokens: 2048,
      onChunk: opts.onChunk,
    });
  } catch {
    // Gateway failed entirely, try direct service
    const svc = getService();
    const status = svc.getStatus();
    if (!status.available) {
      return {
        reply: '所有 AI 通道不可用。请运行 ai config 配置密钥，或 gateway relay 启动中转服务。',
        commands: [],
      };
    }
    result = await svc.generateResponse(conversationPrompt, {
      temperature: 0.4,
      maxTokens: 2048,
    });
  }

  if (!result.success) {
    return {
      reply: 'AI 请求失败。可尝试: ai config (配置密钥) 或 gateway relay (启动中转服务)',
      commands: [],
    };
  }

  const reply = result.content;
  _messages.push({ role: 'assistant', content: reply });

  // Trim history to prevent memory leak
  if (_messages.length > MAX_HISTORY) {
    _messages = _messages.slice(-MAX_HISTORY);
  }

  // Extract embedded commands [CMD:...]
  const cmdRegex = /\[CMD:([^\]]+)\]/g;
  const commands = [];
  let match;
  while ((match = cmdRegex.exec(reply)) !== null) {
    commands.push(match[1].trim());
  }

  // Clean display text (remove CMD markers)
  const displayReply = reply.replace(/\[CMD:[^\]]+\]/g, '').trim();

  return {
    reply: displayReply,
    commands,
    provider: result.provider,
    adapter: result.adapter,
  };
}

/**
 * Clear conversation history.
 */
function clearHistory() {
  _messages = [];
}

module.exports = {
  getAiStatus,
  getActiveProvider,
  handleAiStatus,
  handleAiConfig,
  chat,
  clearHistory,
};
