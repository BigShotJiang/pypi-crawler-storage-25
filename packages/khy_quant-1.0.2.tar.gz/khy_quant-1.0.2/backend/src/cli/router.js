/**
 * CLI Command Router — parses user input, resolves aliases & symbols,
 * dispatches to handlers or user plugins.
 */
const { printError, printHelp, printInfo, printTable, printSuccess, withSpinner } = require('./formatters');
const { resolveAlias, getAllAliasKeys } = require('./aliases');
const { resolveSymbol, searchInstruments } = require('./symbolResolver');
const { tryPlugin } = require('./plugins');

// Canonical command list (used for routing + auto-complete)
const COMMANDS = [
  'quote', 'data', 'cache', 'backtest', 'strategy',
  'server', 'db', 'ai', 'gateway', 'menu', 'help', 'clear', 'exit', 'quit',
  'account', 'position', 'order', 'search', 'watch', 'rank',
  'analyze', 'plugin', 'init', 'doctor',
];

const SUB_COMMANDS = {
  data: ['fetch', 'list'],
  cache: ['clear'],
  backtest: ['list'],
  strategy: ['list'],
  server: ['start', 'status'],
  db: ['init', 'seed', 'status'],
  ai: ['status', 'config'],
  gateway: ['status', 'config', 'relay'],
  plugin: ['list', 'reload'],
};

/**
 * Parse raw input into { command, subCommand, args, options }.
 * Resolves aliases before returning.
 */
function parseInput(line) {
  const parts = line.trim().split(/\s+/);
  if (parts.length === 0 || parts[0] === '') return null;

  let command = parts[0];
  const rest = parts.slice(1);

  // Parse options (--key value) and positional args
  const args = [];
  const options = {};
  for (let i = 0; i < rest.length; i++) {
    if (rest[i].startsWith('--')) {
      const key = rest[i].slice(2);
      const nextVal = rest[i + 1];
      if (nextVal && !nextVal.startsWith('--')) {
        options[key] = nextVal;
        i++;
      } else {
        options[key] = true;
      }
    } else {
      args.push(rest[i]);
    }
  }

  // Resolve alias → canonical command
  const alias = resolveAlias(command);
  if (alias) {
    command = alias.command;
    // If alias implies a sub-command, prepend it
    if (alias.subCommand) {
      args.unshift(alias.subCommand);
    }
    // Merge default args from alias (e.g. buy → order --side buy)
    if (alias.defaultArgs) {
      Object.assign(options, alias.defaultArgs);
    }
  } else {
    command = command.toLowerCase();
  }

  // Detect sub-command
  let subCommand = null;
  if (SUB_COMMANDS[command] && args.length > 0 && SUB_COMMANDS[command].includes(args[0])) {
    subCommand = args.shift();
  }

  return { command, subCommand, args, options, rawInput: line.trim() };
}

/**
 * Resolve the first positional arg as a symbol (name → code).
 * Prints a note if name-to-code translation happened.
 */
async function resolveArg0(args) {
  if (!args[0]) return args[0];
  const result = await resolveSymbol(args[0]);
  if (result.matched && result.symbol !== args[0]) {
    printInfo(`${args[0]} → ${result.symbol} (${result.name})`);
    if (result.alternatives) {
      printInfo(`其他匹配: ${result.alternatives.join(', ')}`);
    }
  }
  return result.symbol;
}

/**
 * Route parsed input to the appropriate handler.
 * Returns: true (handled), false (→ AI), 'exit', 'menu', 'ai-status', 'ai-config'
 */
async function route(parsed, context = {}) {
  const { command, subCommand, args, options } = parsed;

  try {
    switch (command) {
      // ── Meta ──
      case 'help':
        printHelp();
        return true;
      case 'clear':
        console.clear();
        return true;
      case 'exit':
      case 'quit':
        return 'exit';
      case 'menu':
        return 'menu';

      // ── Quote ──
      case 'quote': {
        if (!args[0]) { printError('用法: quote <代码|名称>  (如: hq 茅台, quote sh600519)'); return true; }
        const sym = await resolveArg0(args);
        const { handleQuote } = require('./handlers/data');
        await handleQuote(sym);
        return true;
      }

      // ── Data ──
      case 'data': {
        const { handleDataFetch, handleDataList } = require('./handlers/data');
        if (subCommand === 'fetch') {
          if (!args[0]) { printError('用法: data fetch <代码|名称>'); return true; }
          const sym = await resolveArg0(args);
          await handleDataFetch(sym, options);
        } else if (subCommand === 'list') {
          await handleDataList();
        } else {
          printError('用法: data fetch <代码> | data list  (别名: xz, sj)');
        }
        return true;
      }

      case 'cache': {
        const { handleCacheClear } = require('./handlers/data');
        if (subCommand === 'clear') {
          await handleCacheClear();
        } else {
          printError('用法: cache clear  (别名: hc)');
        }
        return true;
      }

      // ── Backtest ──
      case 'backtest': {
        if (subCommand === 'list') {
          const { handleBacktestList } = require('./handlers/backtest');
          await handleBacktestList(options);
        } else {
          const rawSym = args[0] || subCommand;
          if (!rawSym) { printError('用法: backtest <代码|名称> [--strategy --start --end --capital --verbose]'); return true; }
          args[0] = rawSym;
          const sym = await resolveArg0(args);
          const { handleBacktestRun } = require('./handlers/backtest');
          await handleBacktestRun(sym, options);
        }
        return true;
      }

      case 'strategy': {
        if (subCommand === 'list' || !subCommand) {
          const { handleStrategyList } = require('./handlers/backtest');
          await handleStrategyList();
        } else {
          printError('用法: strategy list  (别名: cl)');
        }
        return true;
      }

      // ── Search ──
      case 'search': {
        if (!args[0]) { printError('用法: search <关键词>  (别名: ss, sousuo)'); return true; }
        const results = await searchInstruments(args[0]);
        if (results.length === 0) {
          printError(`未找到匹配 "${args[0]}" 的品种`);
        } else {
          printSuccess(`找到 ${results.length} 个匹配`);
          const chalk = require('chalk');
          printTable(
            ['代码', '名称', '类型', '市场'],
            results.slice(0, 20).map(i => [i.symbol, i.name || '-', i.type || '-', i.market || '-'])
          );
        }
        return true;
      }

      // ── Account / Position / Order (production placeholders) ──
      case 'account': {
        const service = require('./handlers/service');
        // Delegate to server API if running, otherwise show DB info
        await handleAccountInfo();
        return true;
      }

      case 'position': {
        await handlePositionInfo();
        return true;
      }

      case 'order': {
        printInfo('下单功能需要连接交易接口，当前为预览模式');
        printInfo('用法: order <代码> --side buy|sell --qty 100 --price 50.00');
        return true;
      }

      // ── Watch ──
      case 'watch': {
        if (!args[0]) { printError('用法: watch <代码|名称>  (别名: jk, jiankong)'); return true; }
        const sym = await resolveArg0(args);
        printInfo(`监控 ${sym} — 功能开发中，敬请期待`);
        return true;
      }

      // ── Rank ──
      case 'rank': {
        printInfo('排行功能开发中 — 将显示涨幅榜、跌幅榜、成交量榜');
        return true;
      }

      // ── Analyze (AI shortcut) ──
      case 'analyze': {
        if (!args[0]) { printError('用法: analyze <代码|名称>  (别名: fx, fenxi)'); return true; }
        const sym = await resolveArg0(args);
        // Forward to AI with a structured prompt
        return { aiForward: `分析一下 ${sym} 的走势和交易机会` };
      }

      // ── Server / DB ──
      case 'server': {
        const service = require('./handlers/service');
        if (subCommand === 'start') await service.handleServerStart(options);
        else if (subCommand === 'status') await service.handleServerStatus();
        else printError('用法: server start [--port N] | server status  (别名: fw)');
        return true;
      }

      case 'db': {
        const service = require('./handlers/service');
        if (subCommand === 'init') await service.handleDbInit();
        else if (subCommand === 'seed') await service.handleDbSeed();
        else if (subCommand === 'status') await service.handleDbStatus();
        else printError('用法: db init | db seed | db status  (别名: sjk)');
        return true;
      }

      // ── AI ──
      case 'ai': {
        if (subCommand === 'status') return 'ai-status';
        if (subCommand === 'config') return 'ai-config';
        return false;
      }

      // ── Gateway ──
      case 'gateway': {
        const gw = require('./handlers/gateway');
        if (subCommand === 'status') await gw.handleGatewayStatus();
        else if (subCommand === 'config') await gw.handleGatewayConfig();
        else if (subCommand === 'relay') await gw.handleGatewayRelay();
        else {
          // Default to status when no sub-command
          await gw.handleGatewayStatus();
        }
        return true;
      }

      // ── Init / Doctor ──
      case 'init': {
        const { handleInit } = require('./handlers/init');
        await handleInit(options);
        return true;
      }

      case 'doctor': {
        const { handleDoctor } = require('./handlers/init');
        await handleDoctor();
        return true;
      }

      // ── Plugin management ──
      case 'plugin': {
        const { getPluginList, reloadPlugins, PLUGINS_DIR } = require('./plugins');
        if (subCommand === 'list') {
          const list = getPluginList();
          if (list.length === 0) {
            printInfo(`暂无自定义命令，请在 ${PLUGINS_DIR}/ 中添加 .js 文件`);
          } else {
            printSuccess(`已加载 ${list.length} 个自定义命令`);
            printTable(
              ['命令', '别名', '说明'],
              list.map(p => [p.name, (p.aliases || []).join(', '), p.description || ''])
            );
          }
        } else if (subCommand === 'reload') {
          reloadPlugins();
          printSuccess('插件已重新加载');
        } else {
          printInfo(`插件目录: ${PLUGINS_DIR}/`);
          printInfo('用法: plugin list | plugin reload');
        }
        return true;
      }

      default: {
        // Try user plugins
        const pluginHandled = await tryPlugin(command, args, options);
        if (pluginHandled) return true;
        return false; // → AI
      }
    }
  } catch (err) {
    printError(err.message || '命令执行失败');
    return true;
  }
}

// ── Inline handlers for account/position ──

async function handleAccountInfo() {
  const { bootstrap, muteDbLogs, restoreDbLogs } = require('./bootstrap');
  await bootstrap({ silent: true });
  muteDbLogs();
  const { Trade } = require('../models');
  restoreDbLogs();

  const trades = await Trade.findAll({ where: { status: 'filled' }, raw: true });

  let totalProfit = 0;
  let positionCost = 0;
  trades.forEach(t => {
    if (t.isClosed && t.profit) totalProfit += parseFloat(t.profit);
    else if (!t.isClosed && t.side === 'buy') positionCost += parseFloat(t.amount || 0);
  });

  const initial = 1000000;
  const available = initial + totalProfit - positionCost;
  const chalk = require('chalk');

  printTable(
    ['项目', '金额'],
    [
      ['初始资金', '¥' + initial.toLocaleString()],
      ['累计盈亏', (totalProfit >= 0 ? chalk.red('+') : chalk.green('')) + '¥' + totalProfit.toFixed(2)],
      ['持仓占用', '¥' + positionCost.toFixed(2)],
      ['可用资金', chalk.bold('¥' + available.toFixed(2))],
      ['总成交笔数', String(trades.length)],
    ]
  );
}

async function handlePositionInfo() {
  const { bootstrap, muteDbLogs, restoreDbLogs } = require('./bootstrap');
  await bootstrap({ silent: true });
  muteDbLogs();
  const { Trade } = require('../models');
  restoreDbLogs();

  const openTrades = await Trade.findAll({
    where: { status: 'filled', isClosed: false, side: 'buy' },
    raw: true,
  });

  if (!openTrades || openTrades.length === 0) {
    printInfo('当前无持仓');
    return;
  }

  printSuccess(`当前 ${openTrades.length} 笔持仓`);
  printTable(
    ['品种', '方向', '数量', '成本价', '金额', '时间'],
    openTrades.map(t => [
      t.symbol || '-',
      t.side || '-',
      String(t.quantity || 0),
      '¥' + Number(t.price || 0).toFixed(2),
      '¥' + Number(t.amount || 0).toFixed(2),
      t.createdAt ? new Date(t.createdAt).toLocaleDateString('zh-CN') : '-',
    ])
  );
}

/**
 * Get auto-complete suggestions for partial input.
 */
function getCompletions(partial) {
  const parts = partial.split(/\s+/);
  const allKeys = [...COMMANDS, ...getAllAliasKeys()];
  const unique = [...new Set(allKeys)];

  if (parts.length <= 1) {
    return unique.filter(c => c.startsWith(parts[0].toLowerCase()));
  }

  const cmd = parts[0].toLowerCase();
  // Resolve alias to find sub-commands
  const alias = resolveAlias(cmd);
  const canonicalCmd = alias ? alias.command : cmd;
  const sub = parts[1] || '';

  if (SUB_COMMANDS[canonicalCmd]) {
    return SUB_COMMANDS[canonicalCmd]
      .filter(s => s.startsWith(sub.toLowerCase()))
      .map(s => `${parts[0]} ${s}`);
  }

  return [];
}

module.exports = { parseInput, route, getCompletions, COMMANDS };
