/**
 * Command Alias Registry
 *
 * Maps pinyin, English abbreviations, and Chinese to canonical commands.
 * Users type whatever feels natural; the router normalizes via this table.
 *
 *   huice sh600519         → backtest sh600519
 *   hq 茅台                → quote 茅台
 *   xz sh000001            → data fetch sh000001
 *   cl                     → strategy list
 */

// { alias → { command, [subCommand] } }
const ALIAS_MAP = {
  // ── 行情 ──
  hq:        { command: 'quote' },
  hangqing:  { command: 'quote' },
  '行情':    { command: 'quote' },
  price:     { command: 'quote' },
  p:         { command: 'quote' },

  // ── 回测 ──
  bt:        { command: 'backtest' },
  huice:     { command: 'backtest' },
  '回测':    { command: 'backtest' },

  // ── 策略 ──
  cl:        { command: 'strategy', subCommand: 'list' },
  celue:     { command: 'strategy', subCommand: 'list' },
  '策略':    { command: 'strategy', subCommand: 'list' },

  // ── 数据下载 ──
  xz:        { command: 'data', subCommand: 'fetch' },
  xiazai:    { command: 'data', subCommand: 'fetch' },
  download:  { command: 'data', subCommand: 'fetch' },
  dl:        { command: 'data', subCommand: 'fetch' },
  '下载':    { command: 'data', subCommand: 'fetch' },

  // ── 数据列表 ──
  sj:        { command: 'data', subCommand: 'list' },
  shuju:     { command: 'data', subCommand: 'list' },
  '数据':    { command: 'data', subCommand: 'list' },

  // ── 持仓 ──
  cc:        { command: 'position' },
  chicang:   { command: 'position' },
  '持仓':    { command: 'position' },
  pos:       { command: 'position' },

  // ── 下单 ──
  xd:        { command: 'order' },
  xiadan:    { command: 'order' },
  '下单':    { command: 'order' },
  buy:       { command: 'order', defaultArgs: { side: 'buy' } },
  sell:      { command: 'order', defaultArgs: { side: 'sell' } },
  '买入':    { command: 'order', defaultArgs: { side: 'buy' } },
  '卖出':    { command: 'order', defaultArgs: { side: 'sell' } },
  mai:       { command: 'order', defaultArgs: { side: 'buy' } },
  mairu:     { command: 'order', defaultArgs: { side: 'buy' } },
  maichu:    { command: 'order', defaultArgs: { side: 'sell' } },

  // ── 账户 ──
  zh:        { command: 'account' },
  zhanghu:   { command: 'account' },
  '账户':    { command: 'account' },
  acc:       { command: 'account' },

  // ── 分析 (AI) ──
  fx:        { command: 'analyze' },
  fenxi:     { command: 'analyze' },
  '分析':    { command: 'analyze' },
  analyze:   { command: 'analyze' },

  // ── 服务 ──
  fw:        { command: 'server' },
  fuwu:      { command: 'server' },
  '服务':    { command: 'server' },

  // ── 数据库 ──
  sjk:       { command: 'db' },
  shujuku:   { command: 'db' },
  '数据库':  { command: 'db' },

  // ── 缓存 ──
  hc:        { command: 'cache', subCommand: 'clear' },
  huancun:   { command: 'cache', subCommand: 'clear' },
  '清缓存':  { command: 'cache', subCommand: 'clear' },

  // ── 菜单 ──
  cd:        { command: 'menu' },
  caidan:    { command: 'menu' },
  '菜单':    { command: 'menu' },

  // ── 帮助 ──
  bz:        { command: 'help' },
  bangzhu:   { command: 'help' },
  '帮助':    { command: 'help' },
  h:         { command: 'help' },

  // ── 退出 ──
  q:         { command: 'exit' },
  tuichu:    { command: 'exit' },
  '退出':    { command: 'exit' },

  // ── 清屏 ──
  cls:       { command: 'clear' },
  qp:        { command: 'clear' },
  qingping:  { command: 'clear' },
  '清屏':    { command: 'clear' },

  // ── 监控 ──
  jk:        { command: 'watch' },
  jiankong:  { command: 'watch' },
  '监控':    { command: 'watch' },
  watch:     { command: 'watch' },

  // ── 排行 ──
  ph:        { command: 'rank' },
  paihang:   { command: 'rank' },
  '排行':    { command: 'rank' },
  rank:      { command: 'rank' },
  top:       { command: 'rank' },

  // ── 搜索 ──
  ss:        { command: 'search' },
  sousuo:    { command: 'search' },
  '搜索':    { command: 'search' },
  find:      { command: 'search' },

  // ── 网关 ──
  wg:        { command: 'gateway' },
  wangguan:  { command: 'gateway' },
  '网关':    { command: 'gateway' },
  relay:     { command: 'gateway', subCommand: 'relay' },
  '中转':    { command: 'gateway', subCommand: 'relay' },
  zhongzhuan: { command: 'gateway', subCommand: 'relay' },

  // ── 初始化 ──
  '初始化':  { command: 'init' },
  chushihua: { command: 'init' },
  setup:     { command: 'init' },
  anzhuang:  { command: 'init' },
  '安装':    { command: 'init' },

  // ── 诊断 ──
  '诊断':    { command: 'doctor' },
  zhenduan:  { command: 'doctor' },
  check:     { command: 'doctor' },
  jiankang:  { command: 'doctor' },
  '健康':    { command: 'doctor' },
};

/**
 * Resolve an alias to its canonical command.
 * @param {string} input - The raw command token
 * @returns {{ command: string, subCommand?: string, defaultArgs?: object } | null}
 */
function resolveAlias(input) {
  if (!input) return null;
  const key = input.toLowerCase();
  return ALIAS_MAP[key] || ALIAS_MAP[input] || null;
}

/**
 * Get all aliases for a canonical command (for help display).
 */
function getAliasesForCommand(canonicalCmd) {
  return Object.entries(ALIAS_MAP)
    .filter(([, v]) => v.command === canonicalCmd)
    .map(([k]) => k);
}

/**
 * Get all alias keys for auto-complete.
 */
function getAllAliasKeys() {
  return Object.keys(ALIAS_MAP);
}

module.exports = { resolveAlias, getAliasesForCommand, getAllAliasKeys, ALIAS_MAP };
