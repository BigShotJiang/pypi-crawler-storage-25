/**
 * CLI output formatting utilities.
 * All user-facing prose is in Chinese.
 */
const chalk = require('chalk');
const Table = require('cli-table3');

// ── Mascot & themed icons ────────────────────────────────────────────────────

const MASCOT = [
  '  ╭─────╮    ',
  '  │ ◉ ◉ │    ',
  '╭─┤ ▽▽▽ ├─╮  ',
  '│ ╰─┬─┬─╯ │  ',
  '╰───┤ ├───╯  ',
  '  ╭─┴─┴─╮    ',
  '  │ KHY │    ',
  '  ╰─────╯    ',
];

const MASCOT_MINI = '◉';       // for status lines
const ICON_PROMPT = '❯';       // prompt arrow
const ICON_AI = '⚡';           // AI indicator
const ICON_BULL = '📈';        // market up
const ICON_BEAR = '📉';        // market down
const ICON_BOT = '🤖';         // AI bot head
const ICON_CHART = '📊';       // chart / backtest
const ICON_GEAR = '⚙';         // system
const ICON_PLUG = '🔌';        // plugin
const ICON_HEART = '💚';       // health / doctor
const ICON_ROCKET = '🚀';      // launch / start
const ICON_KEY = '🔑';         // API key
const ICON_DB = '🗄';           // database
const ICON_SEARCH = '🔍';      // search
const ICON_GATEWAY = '🌐';     // gateway / relay

// Random startup tips shown below banner
const TIPS = [
  '输入股票名称或拼音即可查询，如: hq 茅台',
  '支持拼音命令: huice = 回测, hangqing = 行情',
  '输入 menu 打开交互式菜单，鼠标点击操作',
  '直接输入自然语言问题，AI 会理解并执行',
  '运行 doctor 随时检查系统环境健康状态',
  '自定义命令放到 ~/.khyquant/commands/ 即可加载',
  '输入 bt 茅台 --strategy 1 快速回测',
];

function printBanner(version, aiProvider) {
  const b = chalk.cyan;
  const g = chalk.green;
  const y = chalk.yellow;
  const w = chalk.bold.white;
  const d = chalk.dim;

  const aiTag = aiProvider
    ? g(`${ICON_AI} AI 就绪 (${aiProvider})`)
    : y('AI 未配置 — ai config 设置密钥');

  const tip = TIPS[Math.floor(Math.random() * TIPS.length)];

  console.log('');
  // Mascot on the left, info on the right
  const info = [
    w(`KHY-Quant`) + d(` 量化交易终端 `) + b(`v${version}`),
    d('输入 ') + w('help') + d(' 查看命令 · ') + w('menu') + d(' 菜单'),
    aiTag,
    '',
    d(`${MASCOT_MINI} ${tip}`),
  ];

  const mascotLines = MASCOT.map(l => b(l));
  const maxLines = Math.max(mascotLines.length, info.length);

  for (let i = 0; i < maxLines; i++) {
    const left = mascotLines[i] || ' '.repeat(14);
    const right = info[i] || '';
    console.log(`    ${left}${right}`);
  }

  console.log('');
  console.log(b('  ') + d('─'.repeat(52)));
  console.log('');
}

function stripAnsi(str) {
  // eslint-disable-next-line no-control-regex
  return str.replace(/\u001b\[[0-9;]*m/g, '');
}

function printSuccess(msg) {
  console.log(chalk.green('  ✓ ') + msg);
}

function printError(msg) {
  console.log(chalk.red('  ✗ ') + msg);
}

function printWarn(msg) {
  console.log(chalk.yellow('  ⚠ ') + msg);
}

function printInfo(msg) {
  console.log(chalk.blue('  ℹ ') + msg);
}

function printTable(headers, rows) {
  const table = new Table({
    head: headers.map(h => chalk.cyan(h)),
    style: { 'padding-left': 1, 'padding-right': 1 },
  });
  rows.forEach(row => table.push(row));
  console.log(table.toString());
}

function printQuote(quote) {
  const change = quote.current - quote.preClose;
  const changePct = quote.preClose > 0 ? (change / quote.preClose) * 100 : 0;
  const color = change >= 0 ? chalk.red : chalk.green; // Chinese market: red = up
  const icon = change >= 0 ? ICON_BULL : ICON_BEAR;
  const arrow = change >= 0 ? '▲' : '▼';

  console.log('');
  console.log(`  ${icon} ${chalk.bold(quote.name)} ${chalk.dim('(' + quote.symbol + ')')}`);
  console.log(chalk.dim('  ┌──────────────────────────────────────'));
  console.log(`  │ 现价  ${color(chalk.bold('¥' + quote.current.toFixed(2)))}  ${color(arrow + ' ' + (change >= 0 ? '+' : '') + changePct.toFixed(2) + '%')}`);
  console.log(`  │ 开盘  ¥${quote.open.toFixed(2)}  最高  ${chalk.red('¥' + quote.high.toFixed(2))}  最低  ${chalk.green('¥' + quote.low.toFixed(2))}`);
  console.log(`  │ 昨收  ¥${quote.preClose.toFixed(2)}  成交量  ${chalk.bold(formatVolume(quote.volume))}`);
  if (quote.date) console.log(`  │ 时间  ${chalk.dim(quote.date + ' ' + (quote.time || ''))}`);
  console.log(chalk.dim('  └──────────────────────────────────────'));
  console.log('');
}

function printBacktestResult(result) {
  const returnColor = result.totalReturn >= 0 ? chalk.red : chalk.green;
  const icon = result.totalReturn >= 0 ? ICON_BULL : ICON_BEAR;

  console.log('');
  console.log(`  ${ICON_CHART} ${chalk.bold('回测结果')} ${icon}`);
  console.log(chalk.dim('  ┌──────────────────────────────────────'));

  const rows = [
    ['品种', result.symbol],
    ['区间', `${result.startDate} → ${result.endDate}`],
    ['', ''],
    ['初始资金', formatCurrency(result.initialCapital)],
    ['最终资金', chalk.bold(formatCurrency(result.finalCapital))],
    ['总收益率', returnColor(chalk.bold(safePercent(result.totalReturn)))],
    ['年化收益', returnColor(safePercent(result.annualizedReturn))],
    ['', ''],
    ['最大回撤', chalk.yellow(safePercent(result.maxDrawdown, false))],
    ['夏普比率', safeNum(result.sharpeRatio, 4)],
    ['胜率', safePercent(result.winRate, false)],
    ['', ''],
    ['交易次数', String(result.totalTrades || 0)],
    ['盈利次数', chalk.red(String(result.winningTrades || 0))],
    ['亏损次数', chalk.green(String(result.losingTrades || 0))],
    ['交易天数', String(result.tradingDays || 0)],
  ];

  rows.forEach(([label, value]) => {
    if (!label && !value) {
      console.log(chalk.dim('  ├╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌'));
      return;
    }
    console.log(`  │ ${chalk.dim(label.padEnd(10))} ${value}`);
  });

  console.log(chalk.dim('  └──────────────────────────────────────'));
  console.log('');
}

function safePercent(value, showSign = true) {
  if (value === undefined || value === null || isNaN(value)) return '-';
  const prefix = showSign && value >= 0 ? '+' : '';
  return prefix + Number(value).toFixed(2) + '%';
}

function safeNum(value, decimals = 2) {
  if (value === undefined || value === null || isNaN(value)) return '-';
  return Number(value).toFixed(decimals);
}

function formatCurrency(value) {
  return '¥' + Number(value).toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatVolume(vol) {
  if (!vol) return '0';
  if (vol >= 1e8) return (vol / 1e8).toFixed(2) + '亿';
  if (vol >= 1e4) return (vol / 1e4).toFixed(2) + '万';
  return String(vol);
}

function printHelp() {
  const pkg = require('../../package.json');
  console.log('');
  console.log(`  ${MASCOT_MINI} ${chalk.bold('KHY-Quant')} ${chalk.dim('量化交易终端')} ${chalk.cyan('v' + pkg.version)}`);
  console.log(chalk.dim('     https://github.com/khyquant · 作者: 孔浩原'));
  console.log('');
  console.log(chalk.dim('  用法: khy [命令] [参数] [--选项]'));
  console.log(chalk.dim('  支持中文/拼音/英文命令，标的支持代码或名称'));
  console.log(chalk.dim('  ─────────────────────────────────────────'));
  console.log('');

  const groups = [
    {
      name: `${ICON_BULL} 行情数据`,
      cmds: [
        ['quote <代码|名称>', '实时行情', 'hq, hangqing, 行情, p'],
        ['search <关键词>', '搜索品种', 'ss, sousuo, find, 搜索'],
        ['data fetch <代码>', '下载K线数据', 'xz, xiazai, dl, 下载'],
        ['data list', '查看品种列表', 'sj, shuju, 数据'],
        ['watch <代码>', '实时监控 (开发中)', 'jk, jiankong, 监控'],
        ['rank', '涨跌排行 (开发中)', 'ph, paihang, top, 排行'],
        ['cache clear', '清理缓存', 'hc, huancun, 清缓存'],
      ]
    },
    {
      name: `${ICON_CHART} 策略回测`,
      cmds: [
        ['backtest <代码>', '运行策略回测', 'bt, huice, 回测'],
        ['  --strategy <id|文件>', '指定策略 (ID 或 .js 文件路径)', ''],
        ['  --start / --end', '起止日期 (默认近一年)', ''],
        ['  --capital <金额>', '初始资金 (默认 100000)', ''],
        ['  --verbose', '显示详细交易记录', ''],
        ['backtest list', '历史回测记录', ''],
        ['strategy list', '查看可用策略', 'cl, celue, 策略'],
      ]
    },
    {
      name: `${ICON_ROCKET} 交易 (实盘预留)`,
      cmds: [
        ['account', '查看账户资金', 'zh, zhanghu, acc, 账户'],
        ['position', '查看当前持仓', 'cc, chicang, pos, 持仓'],
        ['order <代码> --side buy|sell', '委托下单', 'xd, xiadan, 下单'],
        ['buy <代码> --qty 100', '快捷买入', '买入, mairu'],
        ['sell <代码> --qty 100', '快捷卖出', '卖出, maichu'],
      ]
    },
    {
      name: `${ICON_BOT} AI 助手`,
      cmds: [
        ['analyze <代码>', 'AI分析走势', 'fx, fenxi, 分析'],
        ['ai status', 'AI 服务状态', ''],
        ['ai config', '配置 API 密钥', ''],
        ['<任意自然语言>', 'AI 理解并执行', ''],
      ]
    },
    {
      name: `${ICON_GATEWAY} AI 网关`,
      cmds: [
        ['gateway status', 'AI网关状态 (CLI/API/中转)', 'wg, 网关'],
        ['gateway config', '配置网关参数', ''],
        ['gateway relay', '启动Web中转服务', 'relay, 中转, zhongzhuan'],
      ]
    },
    {
      name: `${ICON_GEAR} 系统管理`,
      cmds: [
        ['server start [--port N]', '启动后端服务', 'fw, fuwu, 服务'],
        ['server status', '查看服务状态', ''],
        ['db init', '初始化数据库', 'sjk, shujuku, 数据库'],
        ['db seed', '填充示例数据', ''],
        ['db status', '数据库状态', ''],
      ]
    },
    {
      name: `${ICON_HEART} 环境管理`,
      cmds: [
        ['init', '初始化向导 (配置、数据库、种子)', 'setup, 初始化, chushihua, 安装'],
        ['init --force', '强制重新初始化', ''],
        ['doctor', '环境诊断检查', 'check, 诊断, zhenduan, 健康'],
      ]
    },
    {
      name: `${ICON_PLUG} 扩展与其他`,
      cmds: [
        ['plugin list', '查看自定义命令', ''],
        ['plugin reload', '重新加载插件', ''],
        ['menu', '打开交互菜单', 'cd, caidan, 菜单'],
        ['help', '显示此帮助', 'bz, bangzhu, h, 帮助'],
        ['clear', '清屏', 'cls, qp, 清屏'],
        ['exit', '退出', 'q, tuichu, quit, 退出'],
      ]
    },
  ];

  groups.forEach(group => {
    console.log(`  ${chalk.cyan.bold(group.name)}`);
    group.cmds.forEach(([cmd, desc, aliases]) => {
      const aliasStr = aliases ? chalk.dim(` (${aliases})`) : '';
      console.log(`    ${chalk.white(cmd.padEnd(28))} ${chalk.dim(desc)}${aliasStr}`);
    });
    console.log('');
  });

  console.log(chalk.dim('  示例:'));
  console.log(chalk.dim('    khy hq 茅台                  查询茅台行情'));
  console.log(chalk.dim('    khy huice sh600519            回测沪深300'));
  console.log(chalk.dim('    khy ss 银行                   搜索含"银行"的品种'));
  console.log(chalk.dim('    khy bt 茅台 --strategy 1      用策略1回测茅台'));
  console.log('');

  // Show user plugins
  try {
    const { getPluginList, PLUGINS_DIR } = require('./plugins');
    const plugins = getPluginList();
    if (plugins.length > 0) {
      console.log(`  ${chalk.cyan.bold('自定义命令')} (${PLUGINS_DIR}/)`);
      plugins.forEach(p => {
        console.log(`    ${chalk.white((p.name).padEnd(28))} ${chalk.dim(p.description || '')}`);
      });
      console.log('');
    }
  } catch { /* plugins not loaded */ }
}

async function withSpinner(text, fn, { muteOutput = false } = {}) {
  // On Windows, ora's ANSI cursor control conflicts with readline in REPL mode,
  // causing all output to be swallowed. Use a simple text fallback instead.
  const useSimpleSpinner = process.platform === 'win32' && process.stdin.isTTY;

  let spinner;
  if (useSimpleSpinner) {
    // Simple fallback: just print the text, no animated spinner
    process.stdout.write(chalk.cyan(`  ◌ ${text}...`));
    spinner = {
      succeed: (msg) => { process.stdout.write('\r' + chalk.green(`  ✓ ${msg || text}`) + '\n'); },
      fail: (msg) => { process.stdout.write('\r' + chalk.red(`  ✗ ${msg || text}`) + '\n'); },
    };
  } else {
    const ora = (await import('ora')).default;
    // discardStdin: false prevents ora from pausing/closing stdin,
    // which would destroy any active readline interface and crash the REPL.
    spinner = ora({ text, indent: 2, discardStdin: false }).start();
  }

  // Suppress noisy service logs (console + winston) while spinner runs
  let origLog, origWarn, origError, origLogLevel;
  if (muteOutput) {
    origLog = console.log;
    origWarn = console.warn;
    origError = console.error;
    console.log = () => {};
    console.warn = () => {};
    console.error = () => {};
    // Also silence winston console transport
    try {
      const logger = require('../utils/logger');
      origLogLevel = logger.level;
      logger.level = 'silent';
    } catch { /* logger not available */ }
  }

  const restore = () => {
    if (!muteOutput) return;
    console.log = origLog;
    console.warn = origWarn;
    console.error = origError;
    try {
      const logger = require('../utils/logger');
      logger.level = origLogLevel || 'info';
    } catch { /* ignore */ }
  };

  try {
    const result = await fn();
    restore();
    spinner.succeed();
    return result;
  } catch (err) {
    restore();
    spinner.fail(err.message);
    throw err;
  }
}

function printDivider(label) {
  if (label) {
    const line = '─'.repeat(Math.max(0, 22 - stripAnsi(label).length));
    console.log(chalk.dim(`  ── ${label} ${line}`));
  } else {
    console.log(chalk.dim('  ' + '─'.repeat(40)));
  }
}

// Farewell messages (randomly chosen on exit)
const FAREWELLS = [
  '祝你投资顺利，下次见！',
  '量化之路，一步一个脚印。再见！',
  '市场永远在，机会随时来。再见！',
  '稳健投资，长期致胜。下次见！',
  '数据驱动决策，理性战胜情绪。再见！',
];

function getRandomFarewell() {
  return FAREWELLS[Math.floor(Math.random() * FAREWELLS.length)];
}

module.exports = {
  // Output functions
  printBanner,
  printSuccess,
  printError,
  printWarn,
  printInfo,
  printTable,
  printQuote,
  printBacktestResult,
  printHelp,
  printDivider,
  // Formatting helpers
  formatCurrency,
  formatVolume,
  stripAnsi,
  // Spinner
  withSpinner,
  // Theme icons (for use in other modules)
  MASCOT_MINI,
  ICON_PROMPT,
  ICON_AI,
  ICON_BOT,
  ICON_CHART,
  ICON_GEAR,
  ICON_ROCKET,
  ICON_KEY,
  ICON_DB,
  ICON_SEARCH,
  ICON_HEART,
  ICON_PLUG,
  ICON_BULL,
  ICON_BEAR,
  ICON_GATEWAY,
  // Farewell
  getRandomFarewell,
};
