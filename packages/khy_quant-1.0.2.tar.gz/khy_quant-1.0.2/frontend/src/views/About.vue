<template>
  <div class="about-page">
    <!-- 头部横幅 -->
    <div class="hero-section">
      <div class="hero-content">
        <div class="logo-container">
          <el-icon class="logo-icon"><TrendCharts /></el-icon>
        </div>
        <h1 class="title">KHY-Quant 量化交易系统</h1>
        <p class="subtitle">专业的量化交易平台，助力您的投资决策</p>
        <div class="version-info">
          <el-tag type="primary" size="large">v{{ version }}</el-tag>
        </div>
      </div>
    </div>

    <!-- 功能特性 -->
    <div class="features-section">
      <h2 class="section-title">核心功能</h2>
      <el-row :gutter="24">
        <el-col :xs="24" :sm="12" :md="8" v-for="feature in features" :key="feature.title">
          <div class="feature-card">
            <div class="feature-icon" :style="{ background: feature.color }">
              <el-icon :size="32"><component :is="feature.icon" /></el-icon>
            </div>
            <h3 class="feature-title">{{ feature.title }}</h3>
            <p class="feature-desc">{{ feature.description }}</p>
          </div>
        </el-col>
      </el-row>
    </div>

    <!-- 技术栈 -->
    <div class="tech-section">
      <h2 class="section-title">技术栈</h2>
      <div class="tech-grid">
        <div class="tech-category" v-for="category in techStack" :key="category.name">
          <h3 class="tech-category-title">{{ category.name }}</h3>
          <div class="tech-items">
            <el-tag 
              v-for="tech in category.items" 
              :key="tech"
              class="tech-tag"
              type="info"
            >
              {{ tech }}
            </el-tag>
          </div>
        </div>
      </div>
    </div>

    <!-- 系统信息 -->
    <div class="info-section">
      <h2 class="section-title">系统信息</h2>
      <el-descriptions :column="2" border>
        <el-descriptions-item label="系统版本">{{ version }}</el-descriptions-item>
        <el-descriptions-item label="发布日期">{{ releaseDate }}</el-descriptions-item>
        <el-descriptions-item label="运行环境">{{ environment }}</el-descriptions-item>
        <el-descriptions-item label="数据库">PostgreSQL 18.1</el-descriptions-item>
        <el-descriptions-item label="开发框架">Vue 3 + Node.js</el-descriptions-item>
        <el-descriptions-item label="UI框架">Element Plus</el-descriptions-item>
      </el-descriptions>
    </div>

    <!-- Multi-Agent Architecture -->
    <div class="agents-section">
      <h2 class="section-title">多智能体架构</h2>
      <p class="agents-intro">系统采用六角色多智能体协同分析框架，通过加权融合生成综合交易建议</p>
      <el-row :gutter="24">
        <el-col :xs="24" :sm="12" :md="8" v-for="agent in agents" :key="agent.name">
          <div class="agent-card">
            <div class="agent-icon" :style="{ background: agent.color }">
              <span class="agent-emoji">{{ agent.emoji }}</span>
            </div>
            <h3 class="agent-name">{{ agent.name }}</h3>
            <p class="agent-model">{{ agent.model }}</p>
            <p class="agent-desc">{{ agent.description }}</p>
          </div>
        </el-col>
      </el-row>
    </div>

    <!-- Contact -->
    <div class="contact-section">
      <h2 class="section-title">联系我们</h2>
      <div class="contact-cards">
        <div class="contact-card">
          <el-icon class="contact-icon" :size="40"><Message /></el-icon>
          <h3>技术支持</h3>
          <p>2578974124@qq.com</p>
        </div>
        <div class="contact-card">
          <el-icon class="contact-icon" :size="40"><Link /></el-icon>
          <h3>官方网站</h3>
          <p>khyquant.top</p>
        </div>
        <div class="contact-card">
          <el-icon class="contact-icon" :size="40"><ChatDotRound /></el-icon>
          <h3>在线客服</h3>
          <p>工作日 9:00-18:00</p>
        </div>
      </div>
    </div>

    <!-- 版权信息 -->
    <div class="footer-section">
      <p class="copyright">© 2026 KHY-Quant 量化交易系统 版权所有</p>
      <p class="disclaimer">本系统仅供学习研究使用，投资有风险，入市需谨慎</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { 
  TrendCharts, 
  DataAnalysis, 
  Monitor, 
  Setting, 
  Document, 
  Connection,
  Message,
  Link,
  ChatDotRound
} from '@element-plus/icons-vue'

// 系统信息
const version = ref('1.0.0')
const releaseDate = ref('2026-02-20')
const environment = ref('生产环境')

// 功能特性
const features = ref([
  {
    icon: 'TrendCharts',
    title: '智能交易',
    description: '支持多种订单类型，包括限价单、市价单、算法交易等，满足不同交易需求',
    color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
  },
  {
    icon: 'DataAnalysis',
    title: '策略回测',
    description: '强大的回测引擎，支持历史数据回测，验证策略有效性',
    color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'
  },
  {
    icon: 'Monitor',
    title: '实时监控',
    description: '实时监控市场行情、持仓状态、交易信号，把握每一个交易机会',
    color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)'
  },
  {
    icon: 'Setting',
    title: '策略管理',
    description: '灵活的策略编辑器，支持Python和JavaScript，轻松创建和管理交易策略',
    color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)'
  },
  {
    icon: 'Document',
    title: '数据分析',
    description: '丰富的图表和指标，深入分析市场数据，辅助投资决策',
    color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)'
  },
  {
    icon: 'Connection',
    title: '多数据源',
    description: '支持AData、AKShare与增强模拟数据，确保稳定可用的数据供给',
    color: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)'
  }
])

// Agents
const agents = ref([
  { name: '市场分析师', model: 'Random Forest', emoji: '📊', description: '分析市场趋势与宏观指标，判断整体行情方向', color: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
  { name: '技术分析师', model: 'LSTM', emoji: '📈', description: '基于价格序列的深度学习预测，捕捉时序特征', color: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' },
  { name: '基本面分析师', model: 'XGBoost', emoji: '📋', description: '估值因子分析，评估资产内在价值与成长性', color: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' },
  { name: '新闻分析师', model: 'LightGBM', emoji: '📰', description: '新闻情绪分析，量化市场舆论对价格的影响', color: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)' },
  { name: '风险分析师', model: 'SVM', emoji: '🛡️', description: '风险分类与评估，控制回撤和波动率', color: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)' },
  { name: '策略分析师', model: 'Neural Network', emoji: '🧠', description: '策略模式识别，优化仓位管理与交易信号', color: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)' }
])

// Tech stack
const techStack = ref([
  {
    name: '前端技术',
    items: ['Vue 3', 'Element Plus', 'Vite', 'Pinia', 'Vue Router', 'Axios', 'ECharts', 'Lightweight Charts']
  },
  {
    name: '后端技术',
    items: ['Node.js', 'Express', 'Sequelize', 'PostgreSQL', 'JWT', 'Bcrypt']
  },
  {
    name: '数据处理',
    items: ['Python', 'AKShare', 'Pandas', 'NumPy', 'TA-Lib']
  },
  {
    name: '开发工具',
    items: ['Git', 'VS Code', 'Postman', 'pgAdmin']
  }
])
</script>

<style scoped>
.about-page {
  --theme-primary-rgb: 99, 102, 241;
  --theme-banner-start: #e8f4fd;
  --theme-banner-mid: #dbeafe;
  --theme-banner-end: #c7d2fe;
  --theme-banner-far: #e0e7ff;
  --theme-text: #1e293b;

  min-height: 100vh;
  background: linear-gradient(to bottom, #f8f9fa 0%, #ffffff 100%);
}

/* 头部横幅 */
.hero-section {
  background: linear-gradient(135deg, var(--theme-banner-start) 0%, var(--theme-banner-mid) 30%, var(--theme-banner-end) 60%, var(--theme-banner-far) 100%);
  color: var(--theme-text);
  padding: 80px 20px;
  text-align: center;
  position: relative;
  overflow: hidden;
}

.hero-section::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(99,102,241,0.08)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,138.7C960,139,1056,117,1152,106.7C1248,96,1344,96,1392,96L1440,96L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
  background-size: cover;
  opacity: 0.5;
}

.hero-content {
  position: relative;
  z-index: 1;
}

.logo-container {
  margin-bottom: 20px;
}

.logo-icon {
  font-size: 80px;
  animation: float 3s ease-in-out infinite;
}

@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-20px); }
}

.title {
  font-size: 48px;
  font-weight: 700;
  margin: 20px 0;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
}

.subtitle {
  font-size: 20px;
  margin: 10px 0 30px;
  opacity: 0.95;
}

.version-info {
  margin-top: 20px;
}

/* 功能特性 */
.features-section {
  width: 100%;
  margin-top: 60px;
  margin-bottom: 60px;
  padding: 0 20px;
}

.section-title {
  font-size: 32px;
  font-weight: 600;
  text-align: center;
  margin-bottom: 40px;
  color: #2c3e50;
  position: relative;
  padding-bottom: 15px;
}

.section-title::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 60px;
  height: 4px;
  background: linear-gradient(90deg, #667eea, #764ba2);
  border-radius: 2px;
}

.feature-card {
  background: white;
  border-radius: var(--radius-md);
  padding: 30px;
  margin-bottom: 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  transition: all 0.3s ease;
  text-align: center;
}

.feature-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}

.feature-icon {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px;
  color: white;
}

.feature-title {
  font-size: 20px;
  font-weight: 600;
  margin: 15px 0;
  color: #2c3e50;
}

.feature-desc {
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
}

/* 技术栈 */
.tech-section {
  width: 100%;
  margin-top: 60px;
  margin-bottom: 60px;
  padding: 0 20px;
}

.tech-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 24px;
}

.tech-category {
  background: white;
  border-radius: var(--radius-md);
  padding: 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
}

.tech-category-title {
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 16px;
  color: #2c3e50;
  padding-bottom: 12px;
  border-bottom: 2px solid #f0f0f0;
}

.tech-items {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.tech-tag {
  font-size: 13px;
}

/* 系统信息 */
.info-section {
  width: 100%;
  margin-top: 60px;
  margin-bottom: 60px;
  padding: 0 20px;
}

:deep(.el-descriptions) {
  background: white;
  border-radius: var(--radius-md);
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
}

/* Multi-Agent Architecture */
.agents-section {
  width: 100%;
  margin-top: 60px;
  margin-bottom: 60px;
  padding: 0 20px;
}

.agents-intro {
  text-align: center;
  color: #606266;
  font-size: 15px;
  margin-bottom: 32px;
  margin-top: -20px;
}

.agent-card {
  background: white;
  border-radius: var(--radius-md, 12px);
  padding: 28px 24px;
  margin-bottom: 24px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  transition: all 0.3s ease;
  text-align: center;
}

.agent-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}

.agent-icon {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 16px;
}

.agent-emoji {
  font-size: 28px;
}

.agent-name {
  font-size: 17px;
  font-weight: 600;
  color: #2c3e50;
  margin: 8px 0 4px;
}

.agent-model {
  font-size: 12px;
  color: #909399;
  margin: 0 0 10px;
  font-family: 'SF Mono', 'Fira Code', monospace;
}

.agent-desc {
  font-size: 13px;
  color: #606266;
  line-height: 1.5;
  margin: 0;
}

/* Contact */
.contact-section {
  width: 100%;
  margin-top: 60px;
  margin-bottom: 60px;
  padding: 0 20px;
}

.contact-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 24px;
}

.contact-card {
  background: white;
  border-radius: var(--radius-md);
  padding: 40px 24px;
  text-align: center;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
  transition: all 0.3s ease;
}

.contact-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}

.contact-icon {
  color: #667eea;
  margin-bottom: 16px;
}

.contact-card h3 {
  font-size: 18px;
  font-weight: 600;
  margin: 12px 0;
  color: #2c3e50;
}

.contact-card p {
  font-size: 14px;
  color: #606266;
}

/* 版权信息 */
.footer-section {
  background: #2c3e50;
  color: white;
  padding: 40px 20px;
  text-align: center;
  margin-top: 60px;
}

.copyright {
  font-size: 14px;
  margin-bottom: 8px;
}

.disclaimer {
  font-size: 12px;
  opacity: 0.8;
  color: #ffd700;
}

/* 响应式 */
@media (max-width: 768px) {
  .title {
    font-size: 32px;
  }
  
  .subtitle {
    font-size: 16px;
  }
  
  .section-title {
    font-size: 24px;
  }
  
  .tech-grid,
  .contact-cards {
    grid-template-columns: 1fr;
  }
}
</style>
