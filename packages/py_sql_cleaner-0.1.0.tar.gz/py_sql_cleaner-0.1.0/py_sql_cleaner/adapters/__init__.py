"""External library adapters."""
