#!/usr/bin/env python3
"""
Generate the static GitHub Pages preview.

Produces:
  docs/preview/index.html   — landing page
  docs/preview/report.html  — full self-contained sovereignty report

Both files are fully self-contained: no external CDNs, no external
fonts, no external scripts. Safe to serve as GitHub Pages or from
any static file host — including air-gapped environments.

Run:
  python scripts/generate_preview.py
"""

from __future__ import annotations

import contextlib
import random
import sys
from datetime import date
from pathlib import Path

from sentinel import DataResidency, Sentinel
from sentinel.compliance import EUAIActChecker
from sentinel.compliance.euaiact import ENFORCEMENT_DATE
from sentinel.dashboard import HTMLReport
from sentinel.manifesto import (
    AcknowledgedGap,
    EUOnly,
    OnPremiseOnly,
    Required,
    SentinelManifesto,
    Targeting,
)
from sentinel.policy.evaluator import SimpleRuleEvaluator
from sentinel.scanner import RuntimeScanner
from sentinel.storage import SQLiteStorage

OUT_DIR = Path(__file__).resolve().parents[1] / "docs" / "preview"


class PreviewPolicy(SentinelManifesto):
    jurisdiction = EUOnly()
    kill_switch = Required()
    storage = OnPremiseOnly(country="EU")
    bsi = Targeting(by="2026-12-31")
    ci_cd = AcknowledgedGap(
        provider="Managed SaaS CI",
        migrating_to="Self-hosted Forgejo",
        by="2027-Q2",
        reason="No EU-sovereign CI alternative with comparable UX today",
    )


def _policy(inputs: dict) -> tuple[bool, str | None]:
    req = inputs.get("request", {})
    if req.get("amount", 0) > 10_000:
        return False, "amount_exceeds_cap"
    return True, None


def _build_sentinel_with_sample_data() -> Sentinel:
    sentinel = Sentinel(
        storage=SQLiteStorage(":memory:"),
        project="sentinel-preview",
        data_residency=DataResidency.EU_DE,
        sovereign_scope="EU",
        policy_evaluator=SimpleRuleEvaluator({"policies/approval.py": _policy}),
    )

    @sentinel.trace(policy="policies/approval.py")
    def approve(request: dict) -> dict:
        return {"decision": "approved", "amount": request["amount"]}

    rng = random.Random(42)
    for _ in range(200):
        amount = int(rng.triangular(100, 20_000, 5_000))
        with contextlib.suppress(Exception):
            approve(request={"amount": amount, "requester": "sample"})
    return sentinel


def _countdown_days() -> int:
    return max(0, (ENFORCEMENT_DATE - date.today()).days)


# ---------------------------------------------------------------------------
# CSS — design system
# ---------------------------------------------------------------------------

CSS = r"""
:root {
  --bg: #0a0e14;
  --surface: #111827;
  --surface2: #1a2332;
  --border: #1f2937;
  --text: #e5e7eb;
  --text2: #9ca3af;
  --text3: #6b7280;
  --green: #00d084;
  --green-dim: #00a368;
  --red: #ff3b3b;
  --amber: #f5a623;
  --blue: #3b82f6;
  --purple: #a78bfa;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body {
  background: var(--bg);
  color: var(--text);
  font-family: system-ui, -apple-system, "Segoe UI", Helvetica, Arial, sans-serif;
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
}
a { color: var(--green); text-decoration: none; }
a:hover { text-decoration: underline; }
.container { max-width: 1200px; margin: 0 auto; padding: 0 1.5rem; }
.mono { font-family: ui-monospace, "Cascadia Code", "Fira Code", "Menlo", monospace; }

/* ---------- SENTINEL MARK ---------- */
.sentinel-mark {
  width: 52px;
  height: 62px;
  margin-bottom: 1.6rem;
  display: block;
}
.sentinel-mark svg { width: 100%; height: 100%; display: block; }
.sentinel-mark-sm {
  width: 22px;
  height: 26px;
  display: inline-block;
  vertical-align: middle;
  margin-right: 0.5rem;
}

/* ---------- HERO ---------- */
.hero {
  min-height: 100vh;
  display: flex;
  align-items: center;
  padding: 4rem 0 3rem;
  border-bottom: 1px solid var(--border);
}
.hero-grid {
  display: grid;
  grid-template-columns: 55fr 45fr;
  gap: 3rem;
  align-items: center;
  width: 100%;
}
.eyebrow {
  font-size: 0.85rem;
  color: var(--green);
  font-weight: 600;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  margin-bottom: 1.2rem;
}
.hero h1 {
  font-size: clamp(3rem, 6vw, 5rem);
  font-weight: 800;
  line-height: 1.02;
  letter-spacing: -0.03em;
  margin-bottom: 1.8rem;
}
.hero h1 span { display: block; }
.hero h1 .underline { color: var(--green); }
.hero p.lead {
  color: var(--text2);
  font-size: 1.1rem;
  max-width: 52ch;
  margin-bottom: 2rem;
}
.stats {
  display: flex;
  gap: 0.6rem;
  flex-wrap: wrap;
  margin-bottom: 2rem;
}
.stat-pill {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 999px;
  padding: 0.4rem 0.9rem;
  font-size: 0.85rem;
  color: var(--text2);
}
.stat-pill .ok { color: var(--green); margin-right: 0.3rem; }
.cta-row { display: flex; align-items: center; gap: 1.2rem; flex-wrap: wrap; }
.btn-primary {
  background: var(--green);
  color: #001b0e;
  border: 0;
  padding: 0.9rem 1.4rem;
  border-radius: 8px;
  font-weight: 700;
  font-family: inherit;
  font-size: 0.95rem;
  cursor: pointer;
  transition: transform 0.1s, background 0.2s;
}
.btn-primary:hover { background: #00ec95; transform: translateY(-1px); }
.btn-primary:active { transform: translateY(0); }
.btn-primary .mono-inline { font-family: ui-monospace, monospace; font-weight: 600; }
.link-secondary { color: var(--text); font-weight: 500; }
.link-tertiary { color: var(--text2); }

/* ---------- TERMINAL ---------- */
.terminal {
  background: #0d1117;
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 30px 80px rgba(0, 208, 132, 0.08), 0 10px 30px rgba(0, 0, 0, 0.5);
}
.terminal-bar {
  background: #161b22;
  padding: 0.7rem 1rem;
  display: flex;
  align-items: center;
  gap: 0.4rem;
  border-bottom: 1px solid var(--border);
}
.terminal-bar .dot {
  width: 12px; height: 12px; border-radius: 50%;
}
.dot-red { background: #ff5f56; }
.dot-amber { background: #ffbd2e; }
.dot-green { background: #27c93f; }
.terminal-bar .title {
  margin-left: 0.8rem;
  font-size: 0.8rem;
  color: var(--text3);
  font-family: ui-monospace, monospace;
}
.terminal-body {
  padding: 1.2rem 1.4rem;
  font-family: ui-monospace, "Cascadia Code", monospace;
  font-size: 0.85rem;
  line-height: 1.7;
  color: var(--text);
  min-height: 420px;
}
.terminal-body .line {
  opacity: 0;
  animation: fade-in 0.35s ease forwards;
}
.terminal-body .prompt { color: var(--green); }
.terminal-body .py { color: var(--purple); }
.terminal-body .str { color: #c3e88d; }
.terminal-body .kw { color: var(--purple); }
.terminal-body .fn { color: #82aaff; }
.terminal-body .cm { color: var(--text3); }
.terminal-body .json { color: #f78c6c; }
.terminal-body .success { color: var(--green); font-weight: 600; }
.l1 { animation-delay: 0.2s; }
.l2 { animation-delay: 1.6s; }
.l3 { animation-delay: 2.7s; }
.l4 { animation-delay: 3.7s; }
.l5 { animation-delay: 4.7s; }
.l6 { animation-delay: 5.2s; }
.l7 { animation-delay: 5.7s; }
.l8 { animation-delay: 6.5s; }
.l9 { animation-delay: 7.1s; }
.l10 { animation-delay: 8.1s; }
.l11 { animation-delay: 9.5s; }
@keyframes fade-in {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ---------- ENFORCEMENT BANNER ---------- */
.enforce {
  background: #2d1f00;
  border-top: 1px solid var(--amber);
  border-bottom: 1px solid var(--amber);
  padding: 1.1rem 0;
}
.enforce-inner {
  display: flex;
  align-items: center;
  gap: 2rem;
  justify-content: space-between;
  flex-wrap: wrap;
}
.enforce-text { color: #ffd580; font-size: 0.95rem; max-width: 80ch; }
.enforce-text strong { color: var(--amber); }
.enforce-days {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: rgba(245, 166, 35, 0.1);
  border: 1px solid var(--amber);
  border-radius: 8px;
  padding: 0.5rem 1.2rem;
}
.enforce-days .n {
  font-size: 2rem;
  font-weight: 800;
  color: var(--amber);
  line-height: 1;
}
.enforce-days .label { font-size: 0.7rem; color: #ffd580; text-transform: uppercase; }

/* ---------- SECTIONS ---------- */
section.block {
  padding: 5rem 0;
  border-bottom: 1px solid var(--border);
}
.block h2 {
  font-size: 2.2rem;
  font-weight: 800;
  letter-spacing: -0.02em;
  margin-bottom: 0.6rem;
}
.block .sub {
  color: var(--text2);
  font-size: 1.05rem;
  margin-bottom: 2.5rem;
  max-width: 72ch;
}

/* ---------- COMPARISON TABLE ---------- */
.compare {
  width: 100%;
  border-collapse: collapse;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  overflow: hidden;
}
.compare th, .compare td {
  padding: 0.85rem 1rem;
  text-align: left;
  border-bottom: 1px solid var(--border);
  font-size: 0.92rem;
}
.compare thead th {
  background: var(--surface2);
  font-size: 0.82rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text2);
}
.compare thead th.col-bad { color: var(--red); }
.compare thead th.col-good { color: var(--green); }
.compare tbody tr:last-child td { border-bottom: none; }
.compare .yes { color: var(--green); font-weight: 600; }
.compare .no { color: var(--red); font-weight: 600; }
.compare .partial { color: var(--amber); font-weight: 600; }
.compare .row-label { color: var(--text); font-weight: 500; }
.compare .col-good-cell {
  background: rgba(0, 208, 132, 0.04);
}
.note {
  margin-top: 1.5rem;
  padding: 1rem 1.2rem;
  background: var(--surface);
  border-left: 3px solid var(--amber);
  border-radius: 4px;
  color: var(--text2);
  font-size: 0.9rem;
}

/* ---------- DASHBOARD PANELS ---------- */
.panels {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
}
.panel {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.5rem;
}
.panel h3 {
  font-size: 0.85rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text2);
  font-weight: 700;
  margin-bottom: 1rem;
}
.panel h3 .big { display: block; font-size: 2.4rem; color: var(--text); margin-top: 0.3rem; text-transform: none; letter-spacing: -0.02em; }
.gauge-svg { display: block; margin: 0.5rem auto; }
.gauge-ring { fill: none; stroke: #1f2937; stroke-width: 14; }
.gauge-fill { fill: none; stroke: var(--green); stroke-width: 14; stroke-linecap: round;
              stroke-dasharray: 440; stroke-dashoffset: 440; transform: rotate(-90deg); transform-origin: 100px 100px;
              animation: gauge-draw 2s ease-out forwards; animation-delay: 0.3s; }
@keyframes gauge-draw { to { stroke-dashoffset: calc(440 - 440 * var(--g, 0.78)); } }
.gauge-text {
  font-family: ui-monospace, monospace;
  font-size: 2.4rem;
  font-weight: 800;
  fill: var(--text);
}
.gauge-label {
  text-align: center;
  color: var(--text2);
  font-size: 0.9rem;
  margin-top: 0.4rem;
}
.gauge-sub {
  text-align: center;
  color: var(--text3);
  font-size: 0.75rem;
  margin-top: 0.2rem;
}

/* Bars panel */
.bars { display: flex; flex-direction: column; gap: 0.7rem; }
.bar-row { display: grid; grid-template-columns: 60px 1fr 120px; align-items: center; gap: 0.8rem; font-size: 0.85rem; }
.bar-row .art { color: var(--text2); font-family: ui-monospace, monospace; font-weight: 600; }
.bar-track { background: #0a0e14; height: 18px; border-radius: 4px; position: relative; overflow: hidden; }
.bar-fill {
  position: absolute; left: 0; top: 0; bottom: 0;
  width: 0;
  animation: bar-grow 1.4s ease-out forwards;
  animation-delay: 0.4s;
}
@keyframes bar-grow { to { width: var(--w, 0%); } }
.bar-fill.green { background: var(--green); }
.bar-fill.amber { background: var(--amber); }
.bar-fill.blue  { background: var(--blue); }
.bar-row .status { font-size: 0.75rem; font-weight: 600; color: var(--text2); letter-spacing: 0.05em; text-transform: uppercase; text-align: right; }

/* Feed table */
.feed-table { width: 100%; border-collapse: collapse; font-size: 0.8rem; }
.feed-table th, .feed-table td {
  padding: 0.5rem 0.6rem;
  text-align: left;
  border-bottom: 1px solid var(--border);
  font-family: ui-monospace, monospace;
}
.feed-table th { color: var(--text3); font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.06em; }
.feed-table td.ms { text-align: right; color: var(--text3); }
.feed-row {
  opacity: 0;
  animation: fade-in 0.5s ease forwards;
}
.feed-row:nth-child(1) { animation-delay: 0.1s; }
.feed-row:nth-child(2) { animation-delay: 0.3s; }
.feed-row:nth-child(3) { animation-delay: 0.5s; }
.feed-row:nth-child(4) { animation-delay: 0.7s; }
.feed-row:nth-child(5) { animation-delay: 0.9s; }
.feed-row:nth-child(6) { animation-delay: 1.1s; }
.feed-row:nth-child(7) { animation-delay: 1.3s; }
.feed-row:nth-child(8) { animation-delay: 1.5s; }
.pill {
  display: inline-block;
  padding: 0.12rem 0.55rem;
  border-radius: 999px;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.04em;
}
.pill.allow { background: rgba(0, 208, 132, 0.15); color: var(--green); }
.pill.deny { background: rgba(255, 59, 59, 0.15); color: var(--red); }
.pill.exc  { background: rgba(245, 166, 35, 0.15); color: var(--amber); }

/* Deps list */
.dep-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 1.2rem; }
.dep-cols h4 { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.6rem; }
.dep-cols h4.ok { color: var(--green); }
.dep-cols h4.warn { color: var(--amber); }
.dep-list { list-style: none; display: flex; flex-direction: column; gap: 0.4rem; font-size: 0.82rem; }
.dep-list li { font-family: ui-monospace, monospace; color: var(--text2); }
.dep-list li::before { content: "● "; color: var(--green); margin-right: 0.3rem; }
.dep-list.warn li::before { content: "○ "; color: var(--amber); }
.dep-list li .residency { color: var(--text3); font-size: 0.75rem; }
.dep-note { margin-top: 0.9rem; font-size: 0.75rem; color: var(--text3); }

/* Kill switch */
.killswitch {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.6rem;
  padding: 1rem 0;
}
.ks-indicator {
  width: 56px; height: 56px; border-radius: 50%;
  background: radial-gradient(circle at 30% 30%, var(--green), #006b42);
  box-shadow: 0 0 0 0 rgba(0, 208, 132, 0.6);
  animation: pulse 2.2s ease-out infinite;
}
@keyframes pulse {
  0%   { box-shadow: 0 0 0 0 rgba(0, 208, 132, 0.5); }
  70%  { box-shadow: 0 0 0 18px rgba(0, 208, 132, 0); }
  100% { box-shadow: 0 0 0 0 rgba(0, 208, 132, 0); }
}
.ks-label { color: var(--green); font-weight: 700; letter-spacing: 0.05em; }
.ks-sub { color: var(--text2); font-size: 0.85rem; text-align: center; }
.ks-code {
  font-family: ui-monospace, monospace;
  font-size: 0.78rem;
  background: #0a0e14;
  padding: 0.5rem 0.8rem;
  border-radius: 4px;
  color: var(--text2);
  border: 1px solid var(--border);
}

/* Countdown panel */
.count-big {
  font-size: 5rem;
  font-weight: 800;
  color: var(--amber);
  line-height: 1;
  text-align: center;
  letter-spacing: -0.03em;
  font-family: ui-monospace, monospace;
}
.count-label { text-align: center; color: var(--text); font-weight: 600; margin-top: 0.4rem; }
.count-sub { text-align: center; color: var(--text3); font-size: 0.8rem; margin-top: 0.3rem; }

/* ---------- CODE TABS ---------- */
.tabs { margin-top: 1rem; }
.tab-headers { display: flex; gap: 0.4rem; margin-bottom: 0; }
.tab-btn {
  background: var(--surface);
  border: 1px solid var(--border);
  border-bottom: none;
  color: var(--text2);
  padding: 0.7rem 1.2rem;
  font-family: inherit;
  font-size: 0.9rem;
  font-weight: 600;
  cursor: pointer;
  border-radius: 8px 8px 0 0;
}
.tab-btn.active { background: var(--surface2); color: var(--text); border-color: var(--border); }
.tab-panel {
  display: none;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 0 12px 12px 12px;
  padding: 1.4rem;
}
.tab-panel.active { display: block; }
.tab-panel pre {
  font-family: ui-monospace, "Cascadia Code", monospace;
  font-size: 0.85rem;
  line-height: 1.6;
  color: var(--text);
  overflow-x: auto;
  white-space: pre;
}
.kw { color: #c792ea; }
.fn { color: #82aaff; }
.st { color: #c3e88d; }
.cm { color: #546e7a; }
.nu { color: #f78c6c; }
.cls { color: #ffcb6b; }

/* ---------- INDUSTRY CARDS ---------- */
.industry-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
}
.industry-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.8rem;
}
.industry-card .icon { width: 48px; height: 48px; margin-bottom: 1rem; color: var(--green); }
.industry-card h3 { font-size: 1.2rem; margin-bottom: 0.6rem; }
.industry-card p { color: var(--text2); font-size: 0.92rem; }

/* ---------- INSIDE SECTION ---------- */
.inside-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 3rem;
}
.feature-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.feature-list li {
  color: var(--text2);
  font-size: 0.92rem;
  padding-left: 1.6rem;
  position: relative;
}
.feature-list li::before {
  content: "✓";
  position: absolute;
  left: 0;
  color: var(--green);
  font-weight: 700;
}
.compliance-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.88rem;
}
.compliance-table th {
  background: var(--surface);
  color: var(--text2);
  font-size: 0.75rem;
  text-transform: uppercase;
  text-align: left;
  padding: 0.6rem 0.8rem;
  border-bottom: 1px solid var(--border);
}
.compliance-table td {
  padding: 0.55rem 0.8rem;
  border-bottom: 1px solid var(--border);
  color: var(--text2);
}
.compliance-table .art { color: var(--text); font-family: ui-monospace, monospace; font-weight: 600; }
.compliance-table .full    { color: var(--green); font-weight: 600; }
.compliance-table .partial { color: var(--amber); font-weight: 600; }
.compliance-table .human   { color: var(--blue); font-weight: 600; }

/* ---------- KERNEL DIAGRAM ---------- */
.kernel-wrap {
  max-width: 760px;
  margin: 0 auto;
}
.kernel-wrap svg {
  width: 100%;
  height: auto;
  display: block;
}
.kernel-taglines {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-top: 2rem;
  max-width: 760px;
  margin-left: auto;
  margin-right: auto;
}
.tagline-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-left: 4px solid var(--green);
  border-radius: 8px;
  padding: 1rem 1.1rem;
}
.tagline-card.govern  { border-left-color: var(--green); }
.tagline-card.route   { border-left-color: var(--blue); }
.tagline-card.trace   { border-left-color: var(--green-dim); }
.tagline-card h4 {
  font-size: 0.92rem;
  color: var(--text);
  font-weight: 700;
  margin-bottom: 0.35rem;
}
.tagline-card p {
  color: var(--text2);
  font-size: 0.82rem;
  line-height: 1.4;
}
@media (max-width: 900px) {
  .kernel-taglines { grid-template-columns: 1fr; }
}

/* ---------- ROADMAP ---------- */
.roadmap-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1.5rem;
  margin-top: 1.5rem;
}
.roadmap-col {
  border-radius: 12px;
  padding: 1.6rem 1.5rem;
  border: 1px solid var(--border);
  background: var(--surface);
  display: flex;
  flex-direction: column;
  gap: 0.8rem;
}
.roadmap-col.done {
  background: rgba(0, 208, 132, 0.06);
  border-color: rgba(0, 208, 132, 0.35);
}
.roadmap-col.now {
  background: rgba(245, 166, 35, 0.06);
  border-color: rgba(245, 166, 35, 0.35);
}
.roadmap-col.future { background: var(--surface); }
.roadmap-col h3 {
  font-size: 0.82rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--text2);
  font-weight: 700;
  margin-bottom: 0.4rem;
}
.roadmap-col.done h3 { color: var(--green); }
.roadmap-col.now h3 { color: var(--amber); }
.roadmap-col.future h3 { color: var(--text2); }
.roadmap-list { list-style: none; display: flex; flex-direction: column; gap: 0.55rem; }
.roadmap-list li {
  font-size: 0.88rem;
  color: var(--text2);
  line-height: 1.5;
  padding-left: 1.4rem;
  position: relative;
  font-family: ui-monospace, monospace;
}
.roadmap-list li .tag {
  color: var(--text);
  font-weight: 700;
  display: inline-block;
  min-width: 3.2rem;
}
.roadmap-col.done .roadmap-list li::before {
  content: "✓";
  position: absolute;
  left: 0;
  color: var(--green);
  font-weight: 700;
}
.roadmap-col.now .roadmap-list li::before {
  content: "→";
  position: absolute;
  left: 0;
  color: var(--amber);
  font-weight: 700;
}
.roadmap-col.future .roadmap-list li::before {
  content: "○";
  position: absolute;
  left: 0;
  color: var(--text3);
}
.roadmap-col .foot {
  margin-top: auto;
  color: var(--text3);
  font-size: 0.78rem;
  padding-top: 0.6rem;
  border-top: 1px dashed var(--border);
}
.roadmap-bar {
  margin-top: 1.8rem;
  padding: 1rem 1.2rem;
  background: rgba(245, 166, 35, 0.08);
  border: 1px solid var(--amber);
  border-radius: 8px;
  color: #ffd580;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  gap: 0.8rem;
  justify-content: center;
}
.roadmap-bar strong { color: var(--amber); }

/* ---------- TRY IT ---------- */
.try {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 16px;
  padding: 3rem 2rem;
  text-align: center;
}
.try h2 { margin-bottom: 1.5rem; }
.try .step { font-family: ui-monospace, monospace; background: #0a0e14; padding: 0.9rem 1.4rem;
             border-radius: 8px; display: inline-block; margin: 0.3rem 0; color: var(--green); font-size: 0.95rem; }
.try .sep { color: var(--text3); margin: 1.2rem 0 0.8rem; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 0.1em; }
.try pre {
  text-align: left;
  max-width: 560px;
  margin: 0 auto;
  font-family: ui-monospace, monospace;
  background: #0a0e14;
  padding: 1.2rem;
  border-radius: 8px;
  color: var(--text);
  font-size: 0.85rem;
  overflow-x: auto;
}
.try .small { color: var(--text3); font-size: 0.78rem; margin-top: 0.6rem; }

/* ---------- FOOTER ---------- */
footer {
  padding: 3rem 0 4rem;
  text-align: center;
  color: var(--text3);
  font-size: 0.88rem;
}
footer .links { display: flex; justify-content: center; gap: 1.5rem; margin-bottom: 1rem; flex-wrap: wrap; }
footer .motto { color: var(--text2); margin-top: 0.6rem; }

/* ---------- RESPONSIVE ---------- */
@media (max-width: 900px) {
  .hero { min-height: auto; padding: 3rem 0; }
  .hero-grid { grid-template-columns: 1fr; gap: 2rem; }
  .hero h1 { font-size: 2.6rem; }
  .panels { grid-template-columns: 1fr; }
  .industry-grid { grid-template-columns: 1fr; }
  .inside-grid { grid-template-columns: 1fr; }
  .dep-cols { grid-template-columns: 1fr; }
  .enforce-inner { flex-direction: column; align-items: flex-start; }
  .compare { font-size: 0.82rem; }
  .roadmap-grid { grid-template-columns: 1fr; }
}
"""


# ---------------------------------------------------------------------------
# JS — minimal, no dependencies
# ---------------------------------------------------------------------------

JS = r"""
// Copy-to-clipboard install button
(function() {
  var btn = document.getElementById('install-btn');
  if (!btn) return;
  btn.addEventListener('click', function() {
    var txt = 'pip install sentinel-kernel';
    if (navigator.clipboard) navigator.clipboard.writeText(txt);
    var original = btn.innerHTML;
    btn.innerHTML = '\u2713 Copied!';
    setTimeout(function() { btn.innerHTML = original; }, 2000);
  });
})();

// Tab switching
(function() {
  var btns = document.querySelectorAll('.tab-btn');
  btns.forEach(function(b) {
    b.addEventListener('click', function() {
      var target = b.getAttribute('data-tab');
      document.querySelectorAll('.tab-btn').forEach(function(x) { x.classList.remove('active'); });
      document.querySelectorAll('.tab-panel').forEach(function(x) { x.classList.remove('active'); });
      b.classList.add('active');
      document.getElementById('tab-' + target).classList.add('active');
    });
  });
})();

// Live enforcement countdown (recalculated in browser so it ages gracefully)
(function() {
  var d = Math.ceil((new Date('2026-08-02') - new Date()) / 86400000);
  if (d < 0) d = 0;
  ['days-count', 'days-count-2', 'days-count-3', 'hero-days'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.textContent = d;
  });
})();

// Same-origin data.json refresh — air-gap safe, no external fetch
(function() {
  if (!window.fetch) return;
  fetch('data.json', { cache: 'no-store' }).then(function(r) {
    return r.ok ? r.json() : null;
  }).then(function(d) {
    if (!d) return;
    var set = function(id, text) {
      var el = document.getElementById(id);
      if (el && text != null) el.textContent = text;
    };
    if (d.version) set('stat-version', 'v' + d.version);
    if (d.tests != null)    set('stat-tests', d.tests + ' passing');
    if (d.coverage)         set('stat-coverage', d.coverage + ' coverage');
    if (d.smoke)            set('stat-smoke', d.smoke + ' smoke');
  }).catch(function() { /* offline: static render is already correct */ });
})();
"""


# ---------------------------------------------------------------------------
# Brand mark — inline SVG, works at any size, zero external resources
# ---------------------------------------------------------------------------

MARK_SVG = (
    "<svg viewBox='0 0 40 48' xmlns='http://www.w3.org/2000/svg' "
    "aria-hidden='true'>"
    "<path d='M20 2 L38 12 L38 36 L20 46 L2 36 L2 12 Z' "
    "fill='none' stroke='#00d084' stroke-width='2.5' "
    "stroke-linejoin='round'/>"
    "<line x1='20' y1='10' x2='20' y2='38' "
    "stroke='#00d084' stroke-width='2.5' stroke-linecap='round'/>"
    "<line x1='13' y1='22' x2='27' y2='22' "
    "stroke='#00d084' stroke-width='2' stroke-linecap='round'/>"
    "<circle cx='20' cy='14' r='2' fill='#00d084'/>"
    "</svg>"
)

# Same SVG, URL-encoded for data URI favicon — `#` must become `%23`.
FAVICON_DATA_URI = (
    "data:image/svg+xml,"
    "<svg viewBox='0 0 40 48' xmlns='http://www.w3.org/2000/svg'>"
    "<path d='M20 2 L38 12 L38 36 L20 46 L2 36 L2 12 Z' "
    "fill='none' stroke='%2300d084' stroke-width='2.5' "
    "stroke-linejoin='round'/>"
    "<line x1='20' y1='10' x2='20' y2='38' "
    "stroke='%2300d084' stroke-width='2.5' stroke-linecap='round'/>"
    "<line x1='13' y1='22' x2='27' y2='22' "
    "stroke='%2300d084' stroke-width='2' stroke-linecap='round'/>"
    "<circle cx='20' cy='14' r='2' fill='%2300d084'/>"
    "</svg>"
)


# ---------------------------------------------------------------------------
# HTML sections
# ---------------------------------------------------------------------------


def _section_hero(
    days: int,
    *,
    version: str,
    tests: str,
    coverage: str,
    smoke: str,
) -> str:
    return f"""
<section class="hero">
  <div class="container hero-grid">
    <div>
      <div class="sentinel-mark">{MARK_SVG}</div>
      <div class="eyebrow">v{version} · EU AI Act Art. 12 · 2 Aug 2026 · Apache 2.0 permanent</div>
      <h1>
        <span>AI decisions.</span>
        <span class="underline">Sovereign.</span>
        <span>Auditable.</span>
      </h1>
      <p class="lead">
        Sentinel wraps any AI agent and records tamper-resistant decision
        traces to local sovereign storage. Client-side ML-DSA-65 signing.
        Zero cloud. Zero US CLOUD Act exposure. Air-gapped capable.
        <strong><span id="hero-days">{days}</span> days to EU AI Act enforcement.</strong>
      </p>
      <div class="stats">
        <span class="stat-pill"><span class="ok">✓</span><span id="stat-version">v{version}</span></span>
        <span class="stat-pill"><span class="ok">✓</span><span id="stat-tests">{tests}</span></span>
        <span class="stat-pill"><span class="ok">✓</span><span id="stat-coverage">{coverage} coverage</span></span>
        <span class="stat-pill"><span class="ok">✓</span><span id="stat-smoke">{smoke} smoke</span></span>
      </div>
      <div class="cta-row">
        <button id="install-btn" class="btn-primary">
          <span class="mono-inline">$ pip install sentinel-kernel</span>
        </button>
        <a href="https://github.com/sebastianweiss83/sentinel-kernel" class="link-secondary">View on GitHub →</a>
        <a href="report.html" class="link-tertiary">sentinel report ↗</a>
      </div>
    </div>
    <div>
      {_terminal_block()}
    </div>
  </div>
</section>
"""


def _terminal_block() -> str:
    return """
<div class="terminal">
  <div class="terminal-bar">
    <span class="dot dot-red"></span>
    <span class="dot dot-amber"></span>
    <span class="dot dot-green"></span>
    <span class="title">~/sentinel — python</span>
  </div>
  <div class="terminal-body">
    <div class="line l1"><span class="prompt">$</span> pip install sentinel-kernel</div>
    <div class="line l2"><span class="prompt">$</span> python3</div>
    <div class="line l3"><span class="py">&gt;&gt;&gt;</span> <span class="kw">from</span> sentinel <span class="kw">import</span> Sentinel</div>
    <div class="line l4"><span class="py">&gt;&gt;&gt;</span> s = <span class="fn">Sentinel</span>()</div>
    <div class="line l5"><span class="py">&gt;&gt;&gt;</span> @s.trace</div>
    <div class="line l6"><span class="py">...</span> <span class="kw">async def</span> <span class="fn">approve</span>(ctx):</div>
    <div class="line l7"><span class="py">...</span> &nbsp;&nbsp;&nbsp;&nbsp;<span class="kw">return</span> {<span class="str">"ok"</span>: <span class="kw">True</span>}</div>
    <div class="line l8"><span class="py">&gt;&gt;&gt;</span> <span class="kw">import</span> asyncio</div>
    <div class="line l9"><span class="py">&gt;&gt;&gt;</span> asyncio.<span class="fn">run</span>(<span class="fn">approve</span>({<span class="str">"amount"</span>: <span class="nu">5000</span>}))</div>
    <div class="line l10"><span class="json">{<br>
&nbsp;&nbsp;"trace_id": "01hx7k9m2n3p",<br>
&nbsp;&nbsp;"policy_result": "ALLOW",<br>
&nbsp;&nbsp;"sovereign_scope": "EU",<br>
&nbsp;&nbsp;"data_residency": "local",<br>
&nbsp;&nbsp;"inputs_hash": "sha256:a3f8c2d1...",<br>
&nbsp;&nbsp;"latency_ms": 3,<br>
&nbsp;&nbsp;"schema_version": "1.0.0"<br>
}</span></div>
    <div class="line l11 success">✓ Trace written. Sovereign. Local. Yours.</div>
  </div>
</div>
"""


def _section_enforcement(days: int) -> str:
    return f"""
<div class="enforce">
  <div class="container enforce-inner">
    <div class="enforce-text">
      <strong>⚠ EU AI Act Annex III enforcement: 2 August 2026</strong> —
      High-risk AI systems must prove automatic tamper-resistant logging.
      Penalties: up to €15M or 3% of global annual turnover.
    </div>
    <div class="enforce-days">
      <div class="n" id="days-count">{days}</div>
      <div class="label">days remaining</div>
    </div>
  </div>
</div>
"""


def _section_v3_highlights(version: str) -> str:
    return f"""
<section class="block">
  <div class="container">
    <h2>What's new in v{version}</h2>
    <p class="sub">Sovereign-first governance primitives. Quantum-safe signing. Multi-language. No external services for any of it.</p>

    <div class="industry-grid">
      <div class="industry-card">
        <h3>Quantum-safe trace signing</h3>
        <p><strong>ML-DSA-65 (FIPS 204)</strong>, BSI TR-02102-1 recommended. Keys stay client-side, forever. Same algorithm as cloud competitors — your keys, your infrastructure, your law.</p>
        <div class="ks-code">pip install sentinel-kernel[pqc] &amp;&amp; sentinel keygen</div>
      </div>
      <div class="industry-card">
        <h3>Attestations · BudgetTracker · Preflight</h3>
        <p><strong>Attestations</strong> — portable self-contained governance JSON, verifiable offline.
        <strong>BudgetTracker</strong> — spend recorded as sovereign traces.
        <strong>Preflight</strong> — check before you act, without writing a trace.</p>
        <div class="ks-code">sentinel attestation generate --output governance.json</div>
      </div>
      <div class="industry-card">
        <h3>CrewAI · AutoGen · LangFuse panel</h3>
        <p>New framework integrations: <strong>CrewAI</strong> task callback and <strong>AutoGen</strong> agent hook. LangFuse gains a <strong>sovereignty widget</strong> — self-contained HTML, no CDN.</p>
        <div class="ks-code">pip install sentinel-kernel[crewai,autogen]</div>
      </div>
      <div class="industry-card">
        <h3>Rust SovereigntyManifest</h3>
        <p>RFC-001 is <strong>ACCEPTED</strong>. Python reference plus a <strong>Rust implementation</strong> (<code>sentinel-manifest</code> v0.1.0). Go and TypeScript are wanted as good-first-issues.</p>
        <div class="ks-code">cargo add sentinel-manifest</div>
      </div>
    </div>

    <div class="note" style="margin-top:1.5rem;">
      Manifesto-as-code now runs as <strong>5 named CI theses</strong> on every PR: no US-owned deps,
      air-gap proven, Apache 2.0 enforced, Sentinel passes its own manifesto,
      trace immutability verified. The project dogfoods its own check.
    </div>
  </div>
</section>
"""


def _section_problem() -> str:
    return """
<section class="block">
  <div class="container">
    <h2>Most solutions fail the sovereignty test</h2>
    <p class="sub">Three ways to log AI decisions. Only one passes the EU AI Act, the CLOUD Act, and the air-gap test.</p>

    <table class="compare">
      <thead>
        <tr>
          <th>Requirement</th>
          <th class="col-bad">Cloud observability</th>
          <th class="col-bad">Proprietary platforms</th>
          <th class="col-good">Sentinel</th>
        </tr>
      </thead>
      <tbody>
        <tr><td class="row-label">Decision records</td><td class="yes">✓</td><td class="yes">✓</td><td class="col-good-cell yes">✓</td></tr>
        <tr><td class="row-label">EU AI Act Art. 12</td><td class="partial">Partial</td><td class="partial">Partial</td><td class="col-good-cell yes">✓ Full</td></tr>
        <tr><td class="row-label">US CLOUD Act exposure</td><td class="no">✗ Applies</td><td class="no">✗ Applies</td><td class="col-good-cell yes">✓ None</td></tr>
        <tr><td class="row-label">Air-gapped capable</td><td class="no">✗</td><td class="no">✗</td><td class="col-good-cell yes">✓</td></tr>
        <tr><td class="row-label">Open source</td><td class="partial">Some</td><td class="no">✗</td><td class="col-good-cell yes">✓ Apache 2.0</td></tr>
        <tr><td class="row-label">On-premise</td><td class="no">✗</td><td class="partial">Expensive</td><td class="col-good-cell yes">✓ Default</td></tr>
        <tr><td class="row-label">BSI path</td><td class="no">✗</td><td class="no">✗</td><td class="col-good-cell yes">✓ v3.0 ready</td></tr>
        <tr><td class="row-label">Quantum-safe signing</td><td class="no">✗</td><td class="partial">Server-side</td><td class="col-good-cell yes">✓ ML-DSA-65, client-side</td></tr>
        <tr><td class="row-label">Manifesto-as-code CI</td><td class="no">✗</td><td class="no">✗</td><td class="col-good-cell yes">✓ 5 theses, every PR</td></tr>
      </tbody>
    </table>

    <div class="note">
      The US CLOUD Act (18 U.S.C. § 2713) requires US-incorporated companies
      to produce data stored anywhere in the world. No EU data-centre
      agreement eliminates this obligation.
    </div>
  </div>
</section>
"""


def _section_kernel() -> str:
    """The Sovereign AI Kernel — three-layer architecture diagram."""
    # SVG diagram: single viewBox, all elements positioned absolutely.
    # Dimensions chosen so width scales to container up to 760px.
    svg = """
<svg viewBox="0 0 720 720" xmlns="http://www.w3.org/2000/svg" role="img"
     aria-label="Three-layer Sentinel kernel: business logic, kernel (Govern, Route, Trace), model layer, sovereign storage.">
  <defs>
    <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5"
            markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 0 L 10 5 L 0 10 z" fill="#00d084"/>
    </marker>
    <style>
      .lbl        { font: 600 14px system-ui, -apple-system, "Segoe UI", sans-serif; fill: #e5e7eb; }
      .lbl-sm     { font: 500 12px system-ui, -apple-system, "Segoe UI", sans-serif; fill: #9ca3af; }
      .lbl-xs     { font: 500 10px ui-monospace, monospace; letter-spacing: 0.05em; fill: #6b7280; }
      .lbl-big    { font: 800 18px system-ui, -apple-system, "Segoe UI", sans-serif; fill: #e5e7eb; letter-spacing: 0.02em; }
      .tag        { font: 700 11px ui-monospace, monospace; fill: #00d084; }
      .tag-blue   { font: 700 11px ui-monospace, monospace; fill: #3b82f6; }
      .mono       { font: 500 11px ui-monospace, monospace; fill: #9ca3af; }
    </style>
  </defs>

  <!-- Box 1: Your business logic -->
  <rect x="220" y="14" width="280" height="52" rx="8"
        fill="#111827" stroke="#1f2937" stroke-width="1"/>
  <text x="360" y="40" text-anchor="middle" class="lbl">Your business logic</text>
  <text x="360" y="56" text-anchor="middle" class="lbl-xs">any agent, any framework</text>

  <!-- Arrow down -->
  <line x1="360" y1="72" x2="360" y2="108"
        stroke="#00d084" stroke-width="2" marker-end="url(#arrow)"/>

  <!-- Box 2: SENTINEL KERNEL (big green border) -->
  <rect x="40" y="116" width="640" height="298" rx="14"
        fill="#0a0e14" stroke="#00d084" stroke-width="2"/>
  <text x="60" y="148" class="lbl-big">SENTINEL KERNEL</text>
  <text x="60" y="168" class="lbl-xs">EU-SOVEREIGN · OPEN SOURCE · APACHE 2.0</text>

  <!-- Inner GOVERN box -->
  <rect x="64" y="186" width="292" height="112" rx="10"
        fill="#111827" stroke="#00d084" stroke-width="1.5"/>
  <text x="80" y="212" class="lbl">GOVERN</text>
  <text x="326" y="212" text-anchor="end" class="tag">v3.0 ✓</text>
  <text x="80" y="240" class="lbl-sm">Policy-as-code</text>
  <text x="80" y="258" class="lbl-sm">Kill switch (Art. 14)</text>
  <text x="80" y="276" class="lbl-sm">Preflight · Manifesto</text>

  <!-- Inner ROUTE box -->
  <rect x="364" y="186" width="292" height="112" rx="10"
        fill="#111827" stroke="#3b82f6" stroke-width="1.5"/>
  <text x="380" y="212" class="lbl">ROUTE</text>
  <text x="626" y="212" text-anchor="end" class="tag-blue">v4.0 →</text>
  <text x="380" y="240" class="lbl-sm">Which model?</text>
  <text x="380" y="258" class="lbl-sm">Which sovereignty?</text>
  <text x="380" y="276" class="lbl-sm">Which data class?</text>

  <!-- Inner TRACE box (full width) -->
  <rect x="64" y="314" width="592" height="82" rx="10"
        fill="#111827" stroke="#00a368" stroke-width="1.5"/>
  <text x="80" y="340" class="lbl">TRACE</text>
  <text x="626" y="340" text-anchor="end" class="tag">v3.0 ✓</text>
  <text x="80" y="364" class="lbl-sm">Every decision · sovereign · tamper-resistant · auditable</text>
  <text x="80" y="382" class="lbl-xs">EU AI ACT ART. 12 AUTOMATED · ML-DSA-65 SIGNED · NDJSON PORTABLE</text>

  <!-- Arrow down -->
  <line x1="360" y1="418" x2="360" y2="454"
        stroke="#00d084" stroke-width="2" marker-end="url(#arrow)"/>

  <!-- Box 3: MODEL LAYER -->
  <rect x="120" y="462" width="480" height="72" rx="10"
        fill="#2d1f00" stroke="#f5a623" stroke-width="1"/>
  <text x="360" y="490" text-anchor="middle" class="lbl">MODEL LAYER (your choice)</text>
  <text x="360" y="510" text-anchor="middle" class="mono">Claude · Mistral · Llama · Kimi · local model</text>
  <text x="360" y="526" text-anchor="middle" class="lbl-xs">SWITCH ANYTIME. NO LOCK-IN.</text>

  <!-- Arrow down -->
  <line x1="360" y1="540" x2="360" y2="576"
        stroke="#00d084" stroke-width="2" marker-end="url(#arrow)"/>

  <!-- Box 4: SOVEREIGN STORAGE -->
  <rect x="120" y="584" width="480" height="72" rx="10"
        fill="#111827" stroke="#1f2937" stroke-width="1"/>
  <text x="360" y="612" text-anchor="middle" class="lbl">SOVEREIGN STORAGE</text>
  <text x="360" y="632" text-anchor="middle" class="mono">SQLite · PostgreSQL · NDJSON</text>
  <text x="360" y="648" text-anchor="middle" class="lbl-xs">YOUR INFRASTRUCTURE. ALWAYS.</text>
</svg>
"""
    return f"""
<section class="block">
  <div class="container">
    <h2>The Sovereign AI Kernel</h2>
    <p class="sub">Three layers between your business logic and your AI models. One thin kernel you can read end-to-end.</p>

    <div class="kernel-wrap">
      {svg}
    </div>

    <div class="kernel-taglines">
      <div class="tagline-card trace">
        <h4>Trace</h4>
        <p>What was decided. EU AI Act Art. 12, automated.</p>
      </div>
      <div class="tagline-card govern">
        <h4>Govern</h4>
        <p>What may be decided. Policy-as-code, kill switch, preflight.</p>
      </div>
      <div class="tagline-card route">
        <h4>Route</h4>
        <p>Which model decides. Coming v4.0 — RFC-002 in discussion.</p>
      </div>
    </div>
  </div>
</section>
"""


def _section_dashboard(days: int) -> str:
    return f"""
<section class="block">
  <div class="container">
    <h2>What Sentinel shows you</h2>
    <p class="sub">Live data from a sample deployment. Every chart is inline SVG — zero external resources.</p>

    <div class="panels">

      <div class="panel">
        <h3>Sovereignty score</h3>
        <svg class="gauge-svg" viewBox="0 0 200 200" width="200" height="200" xmlns="http://www.w3.org/2000/svg">
          <circle class="gauge-ring" cx="100" cy="100" r="70"/>
          <circle class="gauge-fill" cx="100" cy="100" r="70" style="--g: 0.78;"/>
          <text class="gauge-text" x="100" y="112" text-anchor="middle">78%</text>
        </svg>
        <div class="gauge-label">Overall sovereignty</div>
        <div class="gauge-sub">Runtime: EU ✓ · Storage: On-premise ✓ · CI/CD: ⚠ acknowledged</div>
      </div>

      <div class="panel">
        <h3>EU AI Act coverage</h3>
        <div class="bars">
          <div class="bar-row"><span class="art">Art. 12</span><div class="bar-track"><div class="bar-fill green" style="--w: 100%;"></div></div><span class="status">compliant</span></div>
          <div class="bar-row"><span class="art">Art. 13</span><div class="bar-track"><div class="bar-fill green" style="--w: 100%;"></div></div><span class="status">compliant</span></div>
          <div class="bar-row"><span class="art">Art. 14</span><div class="bar-track"><div class="bar-fill green" style="--w: 100%;"></div></div><span class="status">compliant</span></div>
          <div class="bar-row"><span class="art">Art. 9</span><div class="bar-track"><div class="bar-fill amber" style="--w: 60%;"></div></div><span class="status">partial</span></div>
          <div class="bar-row"><span class="art">Art. 17</span><div class="bar-track"><div class="bar-fill amber" style="--w: 70%;"></div></div><span class="status">partial</span></div>
          <div class="bar-row"><span class="art">Art. 10</span><div class="bar-track"><div class="bar-fill blue" style="--w: 0%;"></div></div><span class="status">human action</span></div>
          <div class="bar-row"><span class="art">Art. 15</span><div class="bar-track"><div class="bar-fill blue" style="--w: 0%;"></div></div><span class="status">human action</span></div>
        </div>
      </div>

      <div class="panel">
        <h3>Live decision feed</h3>
        <table class="feed-table">
          <thead><tr><th>Time</th><th>Agent</th><th>Result</th><th class="ms">ms</th></tr></thead>
          <tbody>
            <tr class="feed-row"><td>12:34:51</td><td>procurement_agent</td><td><span class="pill allow">ALLOW</span></td><td class="ms">3</td></tr>
            <tr class="feed-row"><td>12:34:52</td><td>access_control</td><td><span class="pill deny">DENY</span></td><td class="ms">2</td></tr>
            <tr class="feed-row"><td>12:34:53</td><td>doc_classifier</td><td><span class="pill allow">ALLOW</span></td><td class="ms">4</td></tr>
            <tr class="feed-row"><td>12:34:54</td><td>procurement_agent</td><td><span class="pill allow">ALLOW</span></td><td class="ms">3</td></tr>
            <tr class="feed-row"><td>12:34:55</td><td>mission_eval</td><td><span class="pill exc">EXCEPTION</span></td><td class="ms">8</td></tr>
            <tr class="feed-row"><td>12:34:56</td><td>access_control</td><td><span class="pill allow">ALLOW</span></td><td class="ms">2</td></tr>
            <tr class="feed-row"><td>12:34:57</td><td>doc_classifier</td><td><span class="pill deny">DENY</span></td><td class="ms">3</td></tr>
            <tr class="feed-row"><td>12:34:58</td><td>procurement_agent</td><td><span class="pill allow">ALLOW</span></td><td class="ms">4</td></tr>
          </tbody>
        </table>
      </div>

      <div class="panel">
        <h3>Dependency map</h3>
        <div class="dep-cols">
          <div>
            <h4 class="ok">Sovereign ✓</h4>
            <ul class="dep-list">
              <li>sentinel-kernel <span class="residency">EU · DE</span></li>
              <li>postgresql <span class="residency">EU-neutral</span></li>
              <li>langfuse/self <span class="residency">EU · DE (self-hosted)</span></li>
              <li>prometheus <span class="residency">CNCF · neutral</span></li>
            </ul>
          </div>
          <div>
            <h4 class="warn">Acknowledged gaps ⚠</h4>
            <ul class="dep-list warn">
              <li>github-actions <span class="residency">US · Microsoft</span></li>
              <li>pypi <span class="residency">US-hosted</span></li>
            </ul>
          </div>
        </div>
        <div class="dep-note">Acknowledged gaps are documented. Not violations.</div>
      </div>

      <div class="panel">
        <h3>Kill switch</h3>
        <div class="killswitch">
          <div class="ks-indicator"></div>
          <div class="ks-label">● INACTIVE</div>
          <div class="ks-sub">EU AI Act Art. 14 — human oversight active</div>
          <div class="ks-code">sentinel.engage_kill_switch("reason")</div>
          <div class="ks-sub">Halts all agent calls instantly. No restart.</div>
        </div>
      </div>

      <div class="panel">
        <h3>Enforcement countdown</h3>
        <div class="count-big" id="days-count-2">{days}</div>
        <div class="count-label">Days to EU AI Act Annex III</div>
        <div class="count-sub">2 August 2026 · Penalties up to €15M</div>
      </div>

    </div>
  </div>
</section>
"""


def _section_code() -> str:
    return """
<section class="block">
  <div class="container">
    <h2>Start in 5 minutes</h2>
    <p class="sub">Four snippets. Real working code. No placeholders.</p>

    <div class="tabs">
      <div class="tab-headers">
        <button class="tab-btn active" data-tab="minimal">Minimal</button>
        <button class="tab-btn" data-tab="policy">With Policy</button>
        <button class="tab-btn" data-tab="full">Full Pipeline</button>
        <button class="tab-btn" data-tab="governance">Governance v3.0</button>
      </div>

      <div id="tab-minimal" class="tab-panel active"><pre><span class="kw">from</span> sentinel <span class="kw">import</span> Sentinel

sentinel = <span class="fn">Sentinel</span>()  <span class="cm"># SQLite, zero config</span>

<span class="fn">@sentinel.trace</span>
<span class="kw">async def</span> <span class="fn">my_agent</span>(context: <span class="cls">dict</span>) -&gt; <span class="cls">dict</span>:
    <span class="kw">return</span> {<span class="st">"decision"</span>: <span class="st">"approved"</span>}

<span class="cm"># Every call produces a sovereign trace</span>
result = <span class="kw">await</span> <span class="fn">my_agent</span>({<span class="st">"amount"</span>: <span class="nu">5000</span>})
<span class="fn">print</span>(result)  <span class="cm"># {"decision": "approved"}</span>

<span class="cm"># Query traces</span>
traces = sentinel.<span class="fn">query</span>(limit=<span class="nu">1</span>)
<span class="fn">print</span>(traces[<span class="nu">0</span>].policy_result)  <span class="cm"># ALLOW</span></pre></div>

      <div id="tab-policy" class="tab-panel"><pre><span class="kw">from</span> sentinel <span class="kw">import</span> Sentinel
<span class="kw">from</span> sentinel.policy.evaluator <span class="kw">import</span> SimpleRuleEvaluator
<span class="kw">from</span> sentinel.storage.filesystem <span class="kw">import</span> FilesystemStorage

sentinel = <span class="fn">Sentinel</span>(
    policy_evaluator=<span class="fn">SimpleRuleEvaluator</span>({
        <span class="st">"threshold"</span>: <span class="kw">lambda</span> ctx: ctx[<span class="st">"amount"</span>] &lt;= <span class="nu">10_000</span>
    }),
    storage=<span class="fn">FilesystemStorage</span>(<span class="st">"/mnt/traces"</span>),
    sovereign_scope=<span class="st">"EU"</span>,
    data_residency=<span class="st">"on-premise-de"</span>,
)

<span class="fn">@sentinel.trace</span>
<span class="kw">async def</span> <span class="fn">approve_procurement</span>(ctx: <span class="cls">dict</span>) -&gt; <span class="cls">dict</span>:
    <span class="kw">return</span> {<span class="st">"approved"</span>: ctx[<span class="st">"amount"</span>] &lt;= <span class="nu">10_000</span>}

<span class="cm"># DENY recorded automatically for high-value requests</span>
<span class="kw">await</span> <span class="fn">approve_procurement</span>({<span class="st">"amount"</span>: <span class="nu">50_000</span>})</pre></div>

      <div id="tab-full" class="tab-panel"><pre><span class="kw">from</span> sentinel <span class="kw">import</span> Sentinel
<span class="kw">from</span> sentinel.manifesto <span class="kw">import</span> SentinelManifesto
<span class="kw">from</span> sentinel.manifesto.requirements <span class="kw">import</span> (
    EUOnly, Required, AcknowledgedGap,
)
<span class="kw">from</span> sentinel.compliance.euaiact <span class="kw">import</span> EUAIActChecker

<span class="kw">class</span> <span class="cls">OurPolicy</span>(SentinelManifesto):
    name = <span class="st">"Production Sovereignty Policy v1"</span>
    jurisdiction = <span class="fn">EUOnly</span>()
    kill_switch = <span class="fn">Required</span>()
    ci_cd = <span class="fn">AcknowledgedGap</span>(
        provider=<span class="st">"GitHub Actions (Microsoft/US)"</span>,
        migrating_to=<span class="st">"Self-hosted Forgejo"</span>,
        by=<span class="st">"2027-Q2"</span>,
        reason=<span class="st">"No EU-sovereign CI with comparable UX"</span>,
    )

sentinel = <span class="fn">Sentinel</span>()

<span class="cm"># Check EU AI Act compliance</span>
report = <span class="fn">EUAIActChecker</span>().<span class="fn">check</span>(sentinel)
<span class="fn">print</span>(report.<span class="fn">diff</span>())

<span class="cm"># Generate self-contained HTML report</span>
report.<span class="fn">save_html</span>(<span class="st">"sovereignty_report.html"</span>)

<span class="cm"># Check manifesto vs reality</span>
manifesto_report = <span class="fn">OurPolicy</span>().<span class="fn">check</span>(sentinel_instance=sentinel)
<span class="fn">print</span>(<span class="st">f"Score: {manifesto_report.overall_score:.0%}"</span>)</pre></div>

      <div id="tab-governance" class="tab-panel"><pre><span class="kw">from</span> sentinel <span class="kw">import</span> (
    Sentinel, BudgetTracker,
    generate_attestation, verify_attestation,
)
<span class="kw">from</span> sentinel.crypto <span class="kw">import</span> QuantumSafeSigner

<span class="cm"># Quantum-safe signing — keys stay on your infrastructure</span>
signer = <span class="fn">QuantumSafeSigner</span>(
    key_path=<span class="st">"/etc/sentinel/keys/signing.key"</span>,
    public_key_path=<span class="st">"/etc/sentinel/keys/signing.pub"</span>,
)
sentinel = <span class="fn">Sentinel</span>(signer=signer)

<span class="cm"># Preflight — check before you act, no trace written</span>
result = sentinel.<span class="fn">preflight</span>(<span class="st">"data:delete:production"</span>)
<span class="kw">if not</span> result.cleared:
    <span class="kw">raise</span> <span class="cls">RuntimeError</span>(result.reasons)

<span class="cm"># BudgetTracker — every cost entry is a sovereign trace</span>
budget = <span class="fn">BudgetTracker</span>(sentinel=sentinel, limit=<span class="nu">10.0</span>)
check = budget.<span class="fn">check</span>(estimated_cost=<span class="nu">0.25</span>)
budget.<span class="fn">record</span>(<span class="st">"api:mistral"</span>, actual_cost=<span class="nu">0.23</span>)

<span class="cm"># Portable attestation — verifiable offline, no service needed</span>
att = <span class="fn">generate_attestation</span>(sentinel=sentinel)
<span class="kw">assert</span> <span class="fn">verify_attestation</span>(att).valid</pre></div>

    </div>
  </div>
</section>
"""


def _section_industry() -> str:
    shield = """<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>"""
    med = """<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2h6v6h6v6h-6v6H9v-6H3V8h6z"/></svg>"""
    bars = """<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/><line x1="3" y1="20" x2="21" y2="20"/></svg>"""
    gov = """<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21h18"/><path d="M5 21V9l7-5 7 5v12"/><path d="M9 21v-6h6v6"/></svg>"""
    return f"""
<section class="block">
  <div class="container">
    <h2>Built for regulated industries</h2>
    <p class="sub">Four scenarios where a missing trace is worse than a crash.</p>
    <div class="industry-grid">
      <div class="industry-card">
        {shield}
        <h3>Defence &amp; Aerospace</h3>
        <p>Autonomous go/no-go decisions with mission policy evaluation. Kill switch for immediate halt (Art. 14). Air-gapped deployment verified by dedicated test suite. VS-NfD roadmap.</p>
      </div>
      <div class="industry-card">
        {med}
        <h3>Healthcare AI</h3>
        <p>Treatment recommendation audit trail. GDPR-compliant data residency. Every clinical AI decision recorded with SHA-256 hash. Art. 14 human oversight for escalation workflows.</p>
      </div>
      <div class="industry-card">
        {bars}
        <h3>Financial Services</h3>
        <p>Transaction approval automation with DORA-aligned logging. Append-only tamper-resistant records. Regulators get the full trace: what, when, which model, which policy.</p>
      </div>
      <div class="industry-card">
        {gov}
        <h3>Public Administration</h3>
        <p>Government AI transparency requirements met by default. Sovereign deployment — no foreign jurisdiction access possible. EU AI Act compliance diff for internal auditors.</p>
      </div>
    </div>
  </div>
</section>
"""


def _section_inside() -> str:
    return """
<section class="block">
  <div class="container">
    <h2>What's inside</h2>
    <p class="sub">Every v1 → v3 capability. Eleven articles mapped. One honest compliance story.</p>

    <div class="inside-grid">
      <div>
        <ul class="feature-list">
          <li><strong>@sentinel.trace</strong> — any agent, sync or async</li>
          <li><strong>Kill switch</strong> — Art. 14, no restart, thread-safe</li>
          <li><strong>Preflight</strong> — check before you act, no trace written</li>
          <li><strong>BudgetTracker</strong> — spend as sovereign DecisionTrace</li>
          <li><strong>Attestations</strong> — portable, verifiable offline</li>
          <li><strong>Output verification</strong> — hash-check any stored output</li>
          <li><strong>Quantum-safe signing</strong> — ML-DSA-65, client-side keys</li>
          <li><strong>RFC 3161 timestamping</strong> — EU TSAs only (DFN, D-Trust)</li>
          <li><strong>SimpleRule + LocalRego (OPA)</strong> policy evaluation</li>
          <li><strong>SQLite + PostgreSQL + Filesystem</strong> storage backends</li>
          <li><strong>Air-gapped</strong> — network blocked at socket level in CI</li>
          <li><strong>LangChain · CrewAI · AutoGen</strong> callbacks &amp; hooks</li>
          <li><strong>Haystack · LangGraph</strong> integrations</li>
          <li><strong>OpenTelemetry</strong> — sovereignty attrs in every span</li>
          <li><strong>LangFuse sovereignty panel</strong> — self-contained HTML widget</li>
          <li><strong>Jupyter · FastAPI · Django · Prometheus</strong> integrations</li>
          <li><strong>Sovereignty scanner</strong> — 60+ packages mapped</li>
          <li><strong>Manifesto-as-code</strong> — 5 theses as named CI checks</li>
          <li><strong>EU AI Act · DORA · NIS2</strong> compliance checkers</li>
          <li><strong>RFC-001 SovereigntyManifest</strong> — Python + Rust impls</li>
          <li><strong>Full CLI</strong> — demo, scan, compliance, report, attestation, keygen</li>
          <li><strong>Docker Compose</strong> — Grafana + LangFuse + OTel</li>
        </ul>
      </div>
      <div>
        <table class="compliance-table">
          <thead>
            <tr><th>Article</th><th>Requirement</th><th>Sentinel</th><th>What to do</th></tr>
          </thead>
          <tbody>
            <tr><td class="art">Art. 12</td><td>Automatic logging</td><td class="full">✓ Full</td><td>Nothing — automated</td></tr>
            <tr><td class="art">Art. 13</td><td>Transparency</td><td class="full">✓ Full</td><td>Nothing — automated</td></tr>
            <tr><td class="art">Art. 14</td><td>Human oversight</td><td class="full">✓ Full</td><td>Name the operator of the kill switch</td></tr>
            <tr><td class="art">Art. 9</td><td>Risk management</td><td class="partial">~ Partial</td><td>Document risk categories and plan</td></tr>
            <tr><td class="art">Art. 11</td><td>Technical documentation</td><td class="human">→ Human action</td><td>Write the Annex IV tech doc package</td></tr>
            <tr><td class="art">Art. 17</td><td>Quality management</td><td class="partial">~ Partial</td><td>Define change control and QMS procedures</td></tr>
            <tr><td class="art">Art. 16</td><td>Provider obligations</td><td class="partial">~ Partial</td><td>Register, CE mark, conformity assessment</td></tr>
            <tr><td class="art">Art. 26</td><td>Deployer obligations</td><td class="partial">~ Partial</td><td>Staff training, oversight procedures</td></tr>
            <tr><td class="art">Art. 10</td><td>Data governance</td><td class="human">→ Human action</td><td>Document training data provenance</td></tr>
            <tr><td class="art">Art. 15</td><td>Accuracy &amp; robustness</td><td class="human">→ Human action</td><td>Accuracy metrics and pen testing</td></tr>
            <tr><td class="art">Art. 72</td><td>GPAI post-market</td><td class="partial">~ Conditional</td><td>Model card if deploying GPAI as high-risk</td></tr>
          </tbody>
        </table>
        <div class="note" style="margin-top:1rem;">
          Sentinel is honest about what can and cannot be automated.
          Articles requiring human action are clearly marked — we never overclaim.
        </div>
      </div>
    </div>
  </div>
</section>
"""


def _section_roadmap(days: int) -> str:
    return f"""
<section class="block">
  <div class="container">
    <h2>Roadmap</h2>
    <p class="sub">Phase 1 done. Phase 2 in motion. Phase 3 designed. Every version reflects shipped code, not plans.</p>

    <div class="roadmap-grid">
      <div class="roadmap-col done">
        <h3>Trace + Govern · v3.0 ✓</h3>
        <ul class="roadmap-list">
          <li><span class="tag">trace</span> Sovereign decision records</li>
          <li><span class="tag">gov</span> Policy-as-code · manifesto-as-code</li>
          <li><span class="tag">safe</span> Kill switch (Art. 14)</li>
          <li><span class="tag">bsi</span> BSI pre-engagement ready · 608 tests · 100% cov</li>
        </ul>
        <div class="foot">Shipped and verified on main.</div>
      </div>
      <div class="roadmap-col now">
        <h3>Certify + Route · 2026 →</h3>
        <ul class="roadmap-list">
          <li><span class="tag">v3.1</span> Linux Foundation Europe application</li>
          <li><span class="tag">v3.2</span> BSI IT-Grundschutz assessment</li>
          <li><span class="tag">v4.0</span> SovereignRouter — policy-driven model selection</li>
          <li><span class="tag">v4.1</span> Local adapters: Ollama · vLLM · llama.cpp</li>
        </ul>
        <div class="foot">RFC-002 in discussion. Issues #19, #20 open.</div>
      </div>
      <div class="roadmap-col future">
        <h3>Ecosystem · 2027+</h3>
        <ul class="roadmap-list">
          <li><span class="tag">pipe</span> EU-sovereign build pipeline</li>
          <li><span class="tag">ml</span> Multi-language: Python · Rust · Go · TS</li>
          <li><span class="tag">llm</span> LLM-guided deployment</li>
          <li><span class="tag">pkg</span> EU package registry instead of PyPI</li>
        </ul>
        <div class="foot">Breaking the American convenience layer completely.</div>
      </div>
    </div>

    <div class="roadmap-bar">
      ⚠ <strong><span id="days-count-3">{days}</span> days</strong> until EU AI Act Annex III enforcement (2 August 2026)
    </div>
  </div>
</section>
"""


def _section_try() -> str:
    return """
<section class="block">
  <div class="container">
    <div class="try">
      <h2>Try it now</h2>
      <div><div class="step">$ pip install sentinel-kernel</div></div>
      <div><div class="step">$ sentinel demo</div></div>
      <div class="small">Runs 50 decisions · Kill switch demo · Compliance check<br>
        Generates sovereignty_report.html · No Docker required</div>
      <div class="sep">or — full Grafana demo</div>
      <pre>git clone https://github.com/sebastianweiss83/sentinel-kernel
cd sentinel-kernel/demo
docker compose -f docker-compose.minimal.yml up
# http://localhost:3001 — Grafana dashboard</pre>
    </div>
  </div>
</section>
"""


def _footer() -> str:
    stamp = _head_commit_date()
    return f"""
<footer>
  <div class="container">
    <div class="links">
      <a href="https://github.com/sebastianweiss83/sentinel-kernel">GitHub</a>
      <a href="https://pypi.org/project/sentinel-kernel/">PyPI</a>
      <a href="report.html">Documentation</a>
      <a href="https://github.com/sebastianweiss83/sentinel-kernel/blob/main/docs/rfcs/RFC-001-sovereignty-manifest.md">RFC-001</a>
      <a href="https://github.com/sebastianweiss83/sentinel-kernel/discussions">Discussions</a>
    </div>
    <div><span class="sentinel-mark-sm">{MARK_SVG}</span>sentinel-kernel · Swentures UG · Apache 2.0</div>
    <div class="motto">No BSL. No commercial-only features. No relicensing. Ever.</div>
    <div style="margin-top:1rem;font-size:0.75rem;">Generated from HEAD commit: {stamp}</div>
  </div>
</footer>
"""


def _head_commit_date() -> str:
    """HEAD commit date so the preview is idempotent across sync_all runs."""
    import subprocess as _sp
    try:
        out = _sp.run(
            ["git", "log", "-1", "--pretty=format:%cs"],
            cwd=OUT_DIR.parent.parent,
            capture_output=True,
            text=True,
            check=False,
        ).stdout.strip()
        return out or "unknown"
    except (OSError, FileNotFoundError):
        return "unknown"


def _render_index(
    *,
    sentinel: Sentinel,
    sovereignty_score: float,
    compliance: object,
    days_to_enforcement: int,
    version: str,
    tests: str,
    coverage: str,
    smoke: str,
) -> str:
    # sentinel/compliance/sovereignty_score are computed for report.html;
    # the landing page uses the sample data as narrative scaffolding.
    del sentinel, sovereignty_score, compliance
    days = days_to_enforcement

    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="description" content="EU-sovereign AI decision middleware v{version}. ML-DSA-65 quantum-safe trace signing. BudgetTracker, attestations, CrewAI + AutoGen. Air-gapped. Apache 2.0.">
<link rel="icon" type="image/svg+xml" href="{FAVICON_DATA_URI}">
<title>Sentinel v{version} — Sovereign AI Decision Middleware</title>
<style>{CSS}</style>
</head>
<body>
{_section_hero(days, version=version, tests=tests, coverage=coverage, smoke=smoke)}
{_section_enforcement(days)}
{_section_v3_highlights(version)}
{_section_problem()}
{_section_kernel()}
{_section_dashboard(days)}
{_section_code()}
{_section_industry()}
{_section_inside()}
{_section_roadmap(days)}
{_section_try()}
{_footer()}
<script>{JS}</script>
</body>
</html>
"""


def _write_data_json(
    *,
    out_dir: Path,
    tests: str,
    coverage: str,
    smoke: str,
    days: int,
) -> None:
    """Emit docs/preview/data.json — live metrics for the preview page.

    Same-origin, no external fetch. Air-gap safe.
    """
    import json as _json

    from sentinel import __version__ as _version

    tests_n: int | str
    try:
        tests_n = int("".join(ch for ch in tests if ch.isdigit()))
    except ValueError:
        tests_n = tests

    payload = {
        "version": _version,
        "tests": tests_n,
        "coverage": coverage,
        "smoke": smoke,
        "days_to_enforcement": days,
        "enforcement_date": "2026-08-02",
        "integrations": [
            "LangChain",
            "CrewAI",
            "AutoGen",
            "Haystack",
            "LangGraph",
            "OpenTelemetry",
            "LangFuse",
            "Jupyter",
            "FastAPI",
            "Django",
            "Prometheus",
        ],
        "eu_ai_act": {
            "Art. 12": "COMPLIANT",
            "Art. 13": "COMPLIANT",
            "Art. 14": "COMPLIANT",
            "Art. 9": "PARTIAL",
            "Art. 17": "PARTIAL",
            "Art. 16": "PARTIAL",
            "Art. 26": "PARTIAL",
            "Art. 72": "CONDITIONAL",
            "Art. 11": "HUMAN_ACTION",
            "Art. 10": "HUMAN_ACTION",
            "Art. 15": "HUMAN_ACTION",
        },
    }
    (out_dir / "data.json").write_text(
        _json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    import os as _os

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # Pin the HTMLReport generated-at timestamp so repeated runs are
    # byte-identical when no repo state changed.
    _os.environ.setdefault("SENTINEL_REPORT_TIMESTAMP", _head_commit_date())

    sentinel = _build_sentinel_with_sample_data()
    sovereignty_score = RuntimeScanner().scan().sovereignty_score
    compliance = EUAIActChecker().check(sentinel)
    days = _countdown_days()

    # Pull live test/coverage/smoke stats from the existing state reader so
    # the hero pills are never stale. Falls back to conservative defaults
    # when pytest is unavailable.
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from update_claude_md import (
        read_smoke_test,
        read_tests_and_coverage,
    )

    tests, coverage = read_tests_and_coverage()
    smoke_raw = read_smoke_test()
    # read_smoke_test returns "40/40 ✓" or "failed at step N"; we want a
    # terse label for the pill so it reads "40/40 smoke" not "40/40 ✓ smoke".
    smoke = smoke_raw.replace(" ✓", "").strip()

    from sentinel import __version__ as _version

    index_html = _render_index(
        sentinel=sentinel,
        sovereignty_score=sovereignty_score,
        compliance=compliance,
        days_to_enforcement=days,
        version=_version,
        tests=tests,
        coverage=coverage,
        smoke=smoke,
    )
    (OUT_DIR / "index.html").write_text(index_html, encoding="utf-8")

    report_html = HTMLReport().generate(sentinel, manifesto=PreviewPolicy())
    (OUT_DIR / "report.html").write_text(report_html, encoding="utf-8")

    _write_data_json(
        out_dir=OUT_DIR,
        tests=tests,
        coverage=coverage,
        smoke=smoke,
        days=days,
    )

    # .nojekyll so GitHub Pages serves files as-is
    (OUT_DIR / ".nojekyll").write_text("", encoding="utf-8")

    print(f"Generated {OUT_DIR / 'index.html'}")
    print(f"Generated {OUT_DIR / 'report.html'}")
    print(f"Generated {OUT_DIR / 'data.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
