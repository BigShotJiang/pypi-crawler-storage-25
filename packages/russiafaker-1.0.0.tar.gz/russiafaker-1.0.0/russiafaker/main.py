from russiafaker.b_a__address_generator import AddressGenerator
from russiafaker.b_b__bio_generator import BioGenerator
from russiafaker.b_c__contact_generator import ContactGenerator
from russiafaker.b_d__document_generator import DocumentGenerator
from russiafaker.b_e__finance_generator import FinanceGenerator
from russiafaker.b_f__work_generator import WorkGenerator
from russiafaker.b_g__vehicle_generator import VehicleGenerator
from russiafaker.b_i__family_generator import FamilyGenerator


class FakerRussia:
    """
    Суть: Главный класс-агрегатор для генерации полного набора данных о человеке.
    Объединяет все специализированные генераторы (биографии, адреса, контактов,
    документов, финансов, работы, транспорта, семьи) в единый интерфейс. Предоставляет
    методы для генерации всех данных одновременно, сброса всех данных и вывода полной
    информации о сгенерированном человеке. При инициализации создает экземпляры всех
    дочерних генераторов, передавая между ними необходимые зависимости.
    """

    def __init__(self, my_gender: str = None):
        """
        Суть: Инициализация главного генератора FakerRussia. Создает экземпляры всех
        специализированных генераторов в правильном порядке с учетом их зависимостей.
        Сначала создается генератор биографии (bio) с возможностью указания пола,
        затем генератор адреса (address), затем генератор работы (work) с привязкой к
        биографии, затем генератор контактов (contact) с привязкой к биографии и
        адресу, затем генератор транспорта (vehicle) с привязкой к биографии и адресу,
        затем генератор документов (document) с привязкой к биографии, адресу и транспорту,
        затем генератор финансов (finance) с привязкой к биографии, адресу, документам и
        работе, затем генератор семьи (family) с привязкой к биографии и финансам. Все
        генераторы сохраняются как атрибуты класса для последующего доступа.
        """
        self.bio = BioGenerator(my_gender)
        self.address = AddressGenerator()
        self.work = WorkGenerator(self.bio)
        self.contact = ContactGenerator(self.bio, self.address)
        self.vehicle = VehicleGenerator(self.bio, self.address)
        self.document = DocumentGenerator(self.bio, self.address, self.vehicle)
        self.finance = FinanceGenerator(self.bio, self.address, self.document, self.work)
        self.family = FamilyGenerator(self.bio, self.finance)

    def reset(self):
        """
        Суть: Сброс всех сгенерированных данных. Вызывает метод reset у каждого из
        специализированных генераторов (bio, address, work, contact, document, finance,
        vehicle, family), очищая все внутренние хранилища данных. Возвращает сообщение
        об успешном сбросе всех данных. После сброса можно генерировать новый полный набор данных.
        """
        self.bio.reset()
        self.address.reset()
        self.work.reset()
        self.contact.reset()
        self.document.reset()
        self.finance.reset()
        self.vehicle.reset()
        self.family.reset()
        return "Все данные сброшены"

    def __str__(self):
        """
        Суть: Строковое представление полного набора данных о человеке. Объединяет строковые
        представления всех специализированных генераторов (bio, address, document, contact,
        work, finance, vehicle, family) в единую многострочную строку. Используется для удобного
        вывода всей информации о сгенерированном человеке в консоль или лог.
        """
        return (f"{self.bio}\n"
                f"{self.address}\n"
                f"{self.document}\n"
                f"{self.contact}\n"
                f"{self.work}\n"
                f"{self.finance}\n"
                f"{self.vehicle}\n"
                f"{self.family}")


if __name__ == "__main__":
    faker = FakerRussia()
    print(faker)