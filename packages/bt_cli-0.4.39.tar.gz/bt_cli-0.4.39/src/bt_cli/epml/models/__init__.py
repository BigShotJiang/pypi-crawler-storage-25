"""EPM Linux Pydantic models."""
