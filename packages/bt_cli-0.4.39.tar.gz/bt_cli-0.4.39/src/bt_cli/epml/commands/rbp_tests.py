"""RBP test suites — policy unit tests (`/api/pbul/rbp/testsuite`).

Suites are *not* host-scoped (CRUD lives at `/api/pbul/rbp/testsuite/...`).
Only `run` is host-scoped: `/api/pbul/{hostid}/rbp/testsuite/{id}/run`.

PAT auth coverage (verified 2026-05-01 — gateway is inconsistent per-method):
  Bearer-OK : list / get / create / delete suites; update/delete *individual tests*; run
  IAM-only  : update suite (PUT /testsuite/{id}); ADD test (POST /testsuite/test)

So the canonical PAT workflow is: create suites + add tests via the GUI, then
let the CLI run them in CI / pre-deploy. The CLI's `tests add` and
`suites update` commands will return 403 against the cloud gateway today.
"""

import json
from pathlib import Path
from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_error, print_json, print_success, print_table

app = typer.Typer(no_args_is_help=True, help="RBP test suites (policy unit tests)")


# ---- suites ---------------------------------------------------------------

suites_app = typer.Typer(no_args_is_help=True, help="Test suite CRUD")
app.add_typer(suites_app, name="suites")


@suites_app.command("list")
def list_suites(
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List all RBP test suites."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_testsuites()
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [("ID", "id"), ("Name", "name"), ("Description", "description")], title="RBP test suites")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list testsuites"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list testsuites"); raise typer.Exit(1)


@suites_app.command("get")
def get_suite(
    suite_id: int = typer.Argument(...),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Get a test suite (with its tests)."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.get_testsuite(suite_id)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get testsuite"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get testsuite"); raise typer.Exit(1)


@suites_app.command("create")
def create_suite(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
):
    """Create a test suite."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            result = c.create_testsuite(name, description)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create testsuite"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create testsuite"); raise typer.Exit(1)


@suites_app.command("update")
def update_suite(
    suite_id: int = typer.Argument(...),
    name: Optional[str] = typer.Option(None, "--name", "-n"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
):
    """Update a test suite (name/description).

    NOTE: PUT /testsuite/{id} is currently IAM-protected on the cloud gateway —
    PAT-based callers will receive 403 AccessDeniedException. Edit suites via
    the GUI, or via an IAM-credentialed client.
    """
    from bt_cli.epml.client import get_client
    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if not body:
        print_error("Nothing to update — provide --name and/or --description")
        raise typer.Exit(2)
    try:
        with get_client() as c:
            result = c.update_testsuite(suite_id, body)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update testsuite"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update testsuite"); raise typer.Exit(1)


@suites_app.command("delete")
def delete_suite(suite_id: int = typer.Argument(...)):
    """Delete a test suite."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            c.delete_testsuite(suite_id)
        typer.echo(f"Deleted test suite {suite_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete testsuite"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete testsuite"); raise typer.Exit(1)


# ---- individual tests within a suite -------------------------------------

tests_app = typer.Typer(no_args_is_help=True, help="Manage tests within a suite")
app.add_typer(tests_app, name="tests")


@tests_app.command("add")
def add_test(
    suite_id: int = typer.Option(..., "--suite", "-s", help="Test suite ID"),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="JSON file with full test body"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Test name (required if not using --file)"),
    command: Optional[str] = typer.Option(None, "--command", help="Command to simulate"),
    submituser: Optional[str] = typer.Option(None, "--submituser", help="Simulated submitter username"),
    submithost: Optional[str] = typer.Option(None, "--submithost", help="Simulated submitter host"),
    requestuser: Optional[str] = typer.Option(None, "--requestuser", help="Requested run-as user"),
    requesthost: Optional[str] = typer.Option(None, "--requesthost", help="Requested run-on host"),
    expected_access: Optional[str] = typer.Option(None, "--expected-access", help="Expected access verdict (e.g. Allow / Reject)"),
    expected_runuser: Optional[str] = typer.Option(None, "--expected-runuser", help="Expected runuser"),
    expected_runhost: Optional[str] = typer.Option(None, "--expected-runhost", help="Expected runhost"),
    match_type: str = typer.Option("exact", "--match-type", help="Default *_match_type for any expected_* set via short flags"),
):
    """Add a test to a suite.

    NOTE: This endpoint (POST /testsuite/test) is currently IAM-protected on the
    cloud gateway and is NOT reachable with a PAT — calls will return 403
    `AccessDeniedException`. Use the GUI to add tests; use this CLI to run them.

    Provide --file with a full test body, or use short flags for the most common
    fields. The schema's 18 properties are not all required; the most common
    minimum is `name`, `command`, `submituser`, `requestuser`, and at least one
    `expected_*` with its corresponding `*_match_type` (defaults to `exact`).
    """
    from bt_cli.epml.client import get_client
    if file:
        body = json.loads(file.read_text())
    else:
        if not name:
            print_error("Provide --file, or at minimum --name and one --expected-*")
            raise typer.Exit(2)
        body = {"name": name}
        if command is not None:
            body["command"] = command
        if submituser is not None:
            body["submituser"] = submituser
        if submithost is not None:
            body["submithost"] = submithost
        if requestuser is not None:
            body["requestuser"] = requestuser
        if requesthost is not None:
            body["requesthost"] = requesthost
        if expected_access is not None:
            body["expected_access"] = expected_access
            body["expected_access_match_type"] = match_type
        if expected_runuser is not None:
            body["expected_runuser"] = expected_runuser
            body["expected_runuser_match_type"] = match_type
        if expected_runhost is not None:
            body["expected_runhost"] = expected_runhost
            body["expected_runhost_match_type"] = match_type
    try:
        with get_client() as c:
            result = c.add_testsuite_test(suite_id, body)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "add test"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "add test"); raise typer.Exit(1)


@tests_app.command("update")
def update_test(
    test_id: int = typer.Argument(...),
    file: Path = typer.Option(..., "--file", "-f", help="JSON file with full test body"),
):
    """Update a test (replace body from file)."""
    from bt_cli.epml.client import get_client
    try:
        body = json.loads(file.read_text())
        with get_client() as c:
            result = c.update_testsuite_test(test_id, body)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update test"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update test"); raise typer.Exit(1)


@tests_app.command("delete")
def delete_test(test_id: int = typer.Argument(...)):
    """Delete a test."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            c.delete_testsuite_test(test_id)
        typer.echo(f"Deleted test {test_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete test"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete test"); raise typer.Exit(1)


# ---- run -------------------------------------------------------------------

@app.command("run")
def run_suite(
    suite_id: int = typer.Option(..., "--suite", "-s", help="Test suite ID"),
    host: Optional[int] = typer.Option(None, "--host", "-H", help="PMUL host id"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Run a test suite against the live policy.

    Exit code 0 if total > 0 and failures == 0. Exit code 1 otherwise.
    """
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.run_testsuite(suite_id, host_id=host) or {}
        total = data.get("total", 0)
        failures = data.get("failures") or []
        fail_count = len(failures) if isinstance(failures, list) else (1 if failures else 0)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            typer.echo(f"Total tests: {total}")
            typer.echo(f"Failures:    {fail_count}")
            for f in failures or []:
                typer.echo(f"  - {f}")

        if total <= 0 or fail_count > 0:
            raise typer.Exit(1)
        print_success(f"All {total} tests passed")
    except typer.Exit:
        raise
    except httpx.HTTPStatusError as e:
        print_api_error(e, "run testsuite"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "run testsuite"); raise typer.Exit(1)
