"""RBP time/date groups (`/api/pbul/{hostid}/rbp/tmdategrps`).

`tmdate` = TimeDate. A tmdategrp is a named bundle of time windows attached
to a role to make it active only during those times. Each tmdategrp can hold
multiple individual `tmdate` entries (e.g., "Mon-Fri 09:00-17:00").
"""

import json as _json
from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="RBP time/date groups")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id (default: BT_EPML_DEFAULT_HOST)")


@app.command("list")
def list_tmdategrps(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List time/date groups."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_tmdategrps(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
                ("Disabled", "disabled"),
                ("Type", "type"),
            ], title="Time/date groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list tmdategrps"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list tmdategrps"); raise typer.Exit(1)


@app.command("create")
def create_tmdategrp(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
    host: Optional[int] = _host_opt(),
):
    """Create a time/date group."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            result = c.create_tmdategrp({"name": name, "description": description}, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create tmdategrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create tmdategrp"); raise typer.Exit(1)


@app.command("delete")
def delete_tmdategrp(
    ids: str = typer.Argument(..., help="Comma-separated tmdategrp IDs"),
    host: Optional[int] = _host_opt(),
):
    """Delete one or more time/date groups by ID."""
    from bt_cli.epml.client import get_client
    try:
        id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
        with get_client() as c:
            c.delete_tmdategrps(id_list, host_id=host)
        typer.echo(f"Deleted {len(id_list)} time/date group(s)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete tmdategrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete tmdategrp"); raise typer.Exit(1)


# ---- tmdates inside a tmdategrp ----

tmdates_app = typer.Typer(no_args_is_help=True, help="Manage time/date entries inside a tmdategrp")
app.add_typer(tmdates_app, name="tmdates")


@tmdates_app.command("list")
def list_tmdates(
    tmdategrp_id: int = typer.Argument(..., help="Time/Date group ID"),
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """List time/date entries in a group.

    Each entry's schedule lives in the nested `dotw` map. Defaults to JSON
    output because the structure is non-tabular; use `-o table` for a
    summarized day-by-day view.
    """
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_tmdategrp_tmdates(tmdategrp_id, host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            view = []
            for r in rows:
                dotw = (r.get("dotw") or {})
                active_days = [d for d in ("mon","tue","wed","thu","fri","sat","sun") if dotw.get(d)]
                # Show window summary using the first day's first window if any
                window = ""
                for d in active_days:
                    rng = (dotw.get(d) or [{}])[0]
                    if rng.get("from") and rng.get("to"):
                        window = f"{rng['from']}-{rng['to']}"
                        break
                view.append({
                    "description": r.get("description", "") or r.get("name", "") or "-",
                    "days": ",".join(active_days) or "-",
                    "window": window or "-",
                })
            print_table(view, [
                ("Description", "description"),
                ("Days", "days"),
                ("Window", "window"),
            ], title=f"tmdates in tmdategrp {tmdategrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list tmdates"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list tmdates"); raise typer.Exit(1)


_VALID_DAYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")


def _build_dotw(from_: str, to: str, days: str) -> dict:
    """Build a `dotw` map (day-of-the-week → list of from/to ranges).

    The spec calls the per-tmdate field `tmdate: string` (a JSON definition)
    but the actual API uses a structured object: `{"dotw": {"mon": [{"from":"...","to":"..."}], ...}}`.
    Days that aren't in `--days` get an empty list (= not active).
    """
    selected = {d.strip().lower() for d in days.split(",") if d.strip()}
    bad = selected - set(_VALID_DAYS)
    if bad:
        raise ValueError(f"unknown days: {','.join(sorted(bad))} — must be in {','.join(_VALID_DAYS)}")
    window = {"from": from_, "to": to}
    return {d: ([window] if d in selected else []) for d in _VALID_DAYS}


@tmdates_app.command("add")
def add_tmdates(
    tmdategrp_id: int = typer.Argument(..., help="Time/Date group ID"),
    file: Optional[typer.FileText] = typer.Option(None, "--file", "-f", help="JSON file: array of tmdate objects (full shape, with `dotw`)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description for a single tmdate (used with --from/--to)"),
    from_: Optional[str] = typer.Option(None, "--from", help="Time window start (e.g. 09:00)"),
    to: Optional[str] = typer.Option(None, "--to", help="Time window end (e.g. 17:00)"),
    days: str = typer.Option("mon,tue,wed,thu,fri", "--days", help="Comma-separated days when --from/--to applies"),
    host: Optional[int] = _host_opt(),
):
    """Add tmdate entries.

    Two ways to specify entries:

    - **--from / --to / --days**: quick one-window helper. Builds a per-day-of-week
      schedule (`dotw` map). Default `--days mon,tue,wed,thu,fri` (weekdays).
    - **--file**: a JSON array of full tmdate objects. Each object should be
      `{"dotw": {"mon": [{"from":"09:00","to":"17:00"}], ...}}` — every weekday key
      with a list of windows. Days you omit are silently treated as inactive.

    The wrapper around the array (`{"tmdates": [...]}`) is added by the client
    automatically — it's not in the spec but is required by the server.
    """
    from bt_cli.epml.client import get_client
    if file:
        tmdates = _json.load(file)
        if not isinstance(tmdates, list):
            typer.echo("File must contain a JSON array of tmdate objects", err=True)
            raise typer.Exit(2)
    else:
        if not (from_ and to):
            typer.echo("Provide --file, or both --from and --to (with optional --description / --days)", err=True)
            raise typer.Exit(2)
        try:
            entry = {"dotw": _build_dotw(from_, to, days)}
        except ValueError as e:
            typer.echo(f"Bad --days: {e}", err=True)
            raise typer.Exit(2)
        if description:
            entry["description"] = description
        tmdates = [entry]
    try:
        with get_client() as c:
            result = c.add_tmdategrp_tmdates(tmdategrp_id, tmdates, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "add tmdates"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "add tmdates"); raise typer.Exit(1)


@tmdates_app.command("clear")
def clear_tmdates(
    tmdategrp_id: int = typer.Argument(..., help="Time/Date group ID"),
    host: Optional[int] = _host_opt(),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Remove ALL tmdates in a tmdategrp.

    The API has no per-item delete; DELETE clears everything.
    Use `replace` for a selective rewrite.
    """
    from bt_cli.epml.client import get_client
    if not yes:
        typer.confirm(f"Clear all tmdates in tmdategrp {tmdategrp_id}?", abort=True)
    try:
        with get_client() as c:
            c.clear_tmdategrp_tmdates(tmdategrp_id, host_id=host)
        typer.echo(f"Cleared all tmdates from tmdategrp {tmdategrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "clear tmdates"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "clear tmdates"); raise typer.Exit(1)


@tmdates_app.command("replace")
def replace_tmdates(
    tmdategrp_id: int = typer.Argument(..., help="Time/Date group ID"),
    file: typer.FileText = typer.Option(..., "--file", "-f", help="JSON file: array of tmdate objects — final list"),
    host: Optional[int] = _host_opt(),
):
    """Replace the entire tmdate list (clear + add). Two requests; not server-atomic."""
    from bt_cli.epml.client import get_client
    try:
        tmdates = _json.load(file)
        if not isinstance(tmdates, list):
            typer.echo("File must contain a JSON array", err=True)
            raise typer.Exit(2)
        with get_client() as c:
            result = c.replace_tmdategrp_tmdates(tmdategrp_id, tmdates, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "replace tmdates"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "replace tmdates"); raise typer.Exit(1)
