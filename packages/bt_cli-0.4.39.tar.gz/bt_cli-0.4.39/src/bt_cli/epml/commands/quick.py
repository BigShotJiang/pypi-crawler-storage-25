"""EPM Linux quick / cross-step workflows."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import print_api_error, print_error, print_success, print_warning

app = typer.Typer(no_args_is_help=True, help="Multi-step workflows")


@app.command("tests-then-deploy")
def tests_then_deploy(
    suite_id: int = typer.Option(..., "--suite", "-s", help="Test suite ID to run"),
    host: Optional[int] = typer.Option(None, "--host", "-H", help="PMUL host id"),
    rollback_on_failure: bool = typer.Option(
        True, "--rollback-on-failure/--keep-on-failure",
        help="Roll back the in-flight tx if tests fail (default: yes)",
    ),
):
    """Tests-then-deploy: run a suite, then commit or rollback the in-flight tx based on results.

    Workflow:
      1. Verify a transaction is currently in progress (`bt epml rbp tx begin` first).
      2. Run test suite `--suite`.
      3. If all tests pass → commit the tx.
      4. If any test fails → roll back the tx (unless --keep-on-failure).
    """
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            try:
                tx = c.transaction_status(host_id=host)
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 400:
                    print_error("No transaction in progress — run `bt epml rbp tx begin` first")
                    raise typer.Exit(2)
                raise
            typer.echo(f"Transaction in progress: {tx}")

            results = c.run_testsuite(suite_id, host_id=host) or {}
            total = results.get("total", 0)
            failures = results.get("failures") or []
            fail_count = len(failures) if isinstance(failures, list) else (1 if failures else 0)

            typer.echo(f"Test results: {total} total, {fail_count} failures")

            if total > 0 and fail_count == 0:
                c.transaction_commit(host_id=host)
                print_success(f"All {total} tests passed → transaction committed")
                return

            if rollback_on_failure:
                c.transaction_rollback(host_id=host)
                print_warning(f"{fail_count}/{total} tests failed → transaction rolled back")
            else:
                print_warning(
                    f"{fail_count}/{total} tests failed — transaction left in place per --keep-on-failure"
                )
            raise typer.Exit(1)
    except typer.Exit:
        raise
    except httpx.HTTPStatusError as e:
        print_api_error(e, "tests-then-deploy"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "tests-then-deploy"); raise typer.Exit(1)
