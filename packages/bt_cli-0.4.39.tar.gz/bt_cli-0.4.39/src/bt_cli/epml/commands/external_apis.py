"""EPM Linux external-API integration commands (`/api/externalapis/`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="External API integrations")


@app.command("list")
def list_external_apis(
    name: Optional[str] = typer.Option(None, "--name", help="Filter by name"),
    types: Optional[str] = typer.Option(None, "--types", help="Filter by types"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List external API integrations."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_external_apis(name=name, types=types)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("Name", "name"),
                ("Type", "type"),
                ("Base URL", "BaseURL"),
            ], title="External APIs")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list external apis")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list external apis")
        raise typer.Exit(1)


@app.command("get")
def get_external_api(
    ext_id: str = typer.Argument(..., help="External API ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get an external API by ID."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.get_external_api(ext_id)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            for k, v in (data or {}).items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get external api")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get external api")
        raise typer.Exit(1)
