"""EPM Linux iolog commands (`/api/pbul/{hostid}/iologs`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="I/O log files (host-scoped)")


@app.command("list")
def list_iologs(
    host: Optional[int] = typer.Option(None, "--host", "-H", help="PMUL host id (defaults to BT_EPML_DEFAULT_HOST)"),
    start: int = typer.Option(0, "--start", help="Offset"),
    length: int = typer.Option(100, "--len", "-n", help="Page size"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List iolog files for a host."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_iologs(host_id=host, start=start, length=length)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("File", "file"),
                ("Size", "size"),
                ("Created", "created"),
                ("User", "user"),
            ], title=f"iologs (host {host or '(default)'})")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list iologs")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list iologs")
        raise typer.Exit(1)
