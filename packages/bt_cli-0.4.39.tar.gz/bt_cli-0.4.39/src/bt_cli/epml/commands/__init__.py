"""EPM Linux commands module."""

import typer

from .audit import app as audit_app
from .auth import app as auth_app
from .client_pkg import app as client_pkg_app
from .external_apis import app as external_apis_app
from .hosts import app as hosts_app
from .iolog import app as iolog_app
from .license import app as license_app
from .rbp_cmdgrps import app as rbp_cmdgrps_app
from .rbp_entitlement import app as rbp_entitlement_app
from .rbp_hostgrps import app as rbp_hostgrps_app
from .rbp_policy import app as rbp_policy_app
from .rbp_roles import app as rbp_roles_app
from .rbp_tests import app as rbp_tests_app
from .rbp_tmdategrps import app as rbp_tmdategrps_app
from .rbp_tx import app as rbp_tx_app
from .rbp_usergrps import app as rbp_usergrps_app
from .quick import app as quick_app
from .settings import app as settings_app
from .siems import app as siems_app
from .users import app as users_app

app = typer.Typer(
    name="epml",
    help="EPM Linux endpoint privilege management",
    no_args_is_help=True,
)

# Top-level resources
app.add_typer(auth_app, name="auth")
app.add_typer(settings_app, name="settings")
app.add_typer(users_app, name="users")
app.add_typer(hosts_app, name="hosts")
app.add_typer(license_app, name="license")
app.add_typer(siems_app, name="siems")
app.add_typer(audit_app, name="audit")
app.add_typer(client_pkg_app, name="client-pkg")
app.add_typer(external_apis_app, name="external-apis")
app.add_typer(iolog_app, name="iolog")

# RBP family — grouped under `bt epml rbp ...`
rbp_app = typer.Typer(no_args_is_help=True, help="Role-Based Policy management")
rbp_app.add_typer(rbp_cmdgrps_app, name="cmdgrps")
rbp_app.add_typer(rbp_hostgrps_app, name="hostgrps")
rbp_app.add_typer(rbp_usergrps_app, name="usergrps")
rbp_app.add_typer(rbp_tmdategrps_app, name="tmdategrps")
rbp_app.add_typer(rbp_roles_app, name="roles")
rbp_app.add_typer(rbp_entitlement_app, name="entitlement")
rbp_app.add_typer(rbp_policy_app, name="policy")
rbp_app.add_typer(rbp_tests_app, name="tests")
rbp_app.add_typer(rbp_tx_app, name="tx")
app.add_typer(rbp_app, name="rbp")

# Cross-step workflows
app.add_typer(quick_app, name="quick", help="Multi-step workflows")
