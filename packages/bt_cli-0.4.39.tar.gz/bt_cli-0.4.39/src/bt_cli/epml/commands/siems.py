"""EPM Linux SIEM commands (read-only — POST/PUT/DELETE are IAM-blocked)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="SIEM forwarders (read only)")


@app.command("list")
def list_siems(
    filter_str: Optional[str] = typer.Option(None, "--filter", "-f", help="Spec filter expression"),
    take: Optional[int] = typer.Option(None, "--take", help="Page size"),
    skip: Optional[int] = typer.Option(None, "--skip", help="Offset"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort expression"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List SIEM forwarders (`/api/v4/siems`)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_siems(filter_str=filter_str, take=take, skip=skip, sort=sort)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data.get("data", []) if isinstance(data, dict) else (data or [])
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Type", "siem_type"),
                ("Verify Cert", "verify_cert"),
            ]
            print_table(rows, columns, title=f"SIEMs (total {data.get('total', len(rows))})" if isinstance(data, dict) else "SIEMs")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list siems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list siems")
        raise typer.Exit(1)
