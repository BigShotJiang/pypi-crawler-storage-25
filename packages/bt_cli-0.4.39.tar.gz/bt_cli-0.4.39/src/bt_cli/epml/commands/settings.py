"""EPM Linux settings commands (read-only — write is IAM-blocked)."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="Site-level settings (read-only)")


@app.command("list")
def list_settings(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all site-level settings (`/api/settings`)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            settings = client.get_settings() or {}

        if output == OutputFormat.JSON:
            print_json(settings)
        else:
            rows = [{"key": k, "value": str(v)} for k, v in sorted(settings.items())]
            print_table(rows, [("Key", "key"), ("Value", "value")], title="Settings")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list settings")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list settings")
        raise typer.Exit(1)


@app.command("get")
def get_setting(
    key: str = typer.Argument(..., help="Setting key"),
):
    """Get a single setting value by key."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            settings = client.get_settings() or {}
        if key not in settings:
            typer.echo(f"Setting '{key}' not found", err=True)
            raise typer.Exit(1)
        typer.echo(settings[key])
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get setting")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get setting")
        raise typer.Exit(1)
