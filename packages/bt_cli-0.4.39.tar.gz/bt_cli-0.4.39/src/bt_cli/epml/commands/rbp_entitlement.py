"""RBP entitlement reports (`/api/pbul/{hostid}/rbp/entitlement`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json

app = typer.Typer(no_args_is_help=True, help="RBP entitlement reports")


@app.command("run")
def run_entitlement(
    host: Optional[int] = typer.Option(None, "--host", "-H", help="PMUL host id"),
    raw: bool = typer.Option(False, "--raw", help="Use the /entitlement/raw variant"),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Run the entitlement report ('who can do what')."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.get_entitlement(host_id=host, raw=raw)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            # Plain dump — entitlement output shape varies; JSON is the useful form.
            print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "entitlement report"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "entitlement report"); raise typer.Exit(1)
