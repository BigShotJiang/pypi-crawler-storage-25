"""EPM Linux client package commands (`/api/epml/clientpkg`)."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table, print_warning

app = typer.Typer(no_args_is_help=True, help="EPM Linux client installer packages")


@app.command("list")
def list_packages(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List built client installer packages.

    Each entry includes a presigned S3 download URL (`link`) valid for ~30 minutes.
    """
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_client_packages() or {}

        rows = data.get("clientpkg", []) if isinstance(data, dict) else []

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            view = [
                {
                    "file": r.get("file"),
                    "version": r.get("version"),
                    "release": r.get("release"),
                    "arch": r.get("arch"),
                    "created": r.get("created"),
                }
                for r in rows
            ]
            print_table(view, [
                ("File", "file"),
                ("Version", "version"),
                ("Release", "release"),
                ("Arch", "arch"),
                ("Created", "created"),
            ], title=f"Client packages ({len(rows)})")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list client packages")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list client packages")
        raise typer.Exit(1)


@app.command("status")
def package_status():
    """Show client-package build status."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.get_client_package_status() or {}
        building = bool(data.get("building"))
        if building:
            typer.echo("Build in progress: yes")
        else:
            typer.echo("Build in progress: no")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "client pkg status")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "client pkg status")
        raise typer.Exit(1)


@app.command("link")
def package_link(
    file: str = typer.Argument(..., help="Package file name (e.g. epml-client.x86_64.rpm)"),
):
    """Print the presigned S3 download URL for a single package file."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_client_packages() or {}
        for r in data.get("clientpkg", []):
            if r.get("file") == file:
                typer.echo(r.get("link"))
                return
        typer.echo(f"Package '{file}' not found", err=True)
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "client pkg link")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "client pkg link")
        raise typer.Exit(1)
