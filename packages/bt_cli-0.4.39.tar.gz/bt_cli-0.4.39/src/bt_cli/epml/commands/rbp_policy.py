"""RBP policy (export/import/versions/diff/revert)."""

import json
from pathlib import Path
from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="RBP policy management")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id (default: BT_EPML_DEFAULT_HOST)")


@app.command("export")
def export_policy(
    host: Optional[int] = _host_opt(),
    file: Optional[Path] = typer.Option(None, "--file", "-f", help="Write to file (default: stdout)"),
):
    """Export the full RBP DB."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.export_rbp(host_id=host)
        text = json.dumps(data, indent=2, default=str)
        if file:
            file.write_text(text)
            typer.echo(f"Wrote {len(text)} bytes to {file}")
        else:
            typer.echo(text)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "export rbp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "export rbp"); raise typer.Exit(1)


@app.command("import")
def import_policy(
    file: Path = typer.Argument(..., help="JSON file to import"),
    host: Optional[int] = _host_opt(),
):
    """Import an RBP DB serialization."""
    from bt_cli.epml.client import get_client
    try:
        payload = json.loads(file.read_text())
        with get_client() as c:
            result = c.import_rbp(payload, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "import rbp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "import rbp"); raise typer.Exit(1)


@app.command("revert")
def revert_policy(
    host: Optional[int] = _host_opt(),
):
    """Revert the policy to the last committed state."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            result = c.revert_rbp(host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "revert rbp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "revert rbp"); raise typer.Exit(1)


@app.command("versions")
def list_versions(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List RBP policy versions."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_rbp_versions(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("Version", "version"),
                ("Created", "created"),
                ("Author", "author"),
                ("Comment", "comment"),
            ], title="RBP versions")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list versions"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list versions"); raise typer.Exit(1)


@app.command("diff")
def diff_policy(
    host: Optional[int] = _host_opt(),
    against: Optional[str] = typer.Option(None, "--against", help="Version or ref to diff against"),
):
    """Diff current draft against a prior version."""
    from bt_cli.epml.client import get_client
    try:
        params = {"version": against} if against else None
        with get_client() as c:
            data = c.diff_rbp(host_id=host, params=params)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "diff rbp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "diff rbp"); raise typer.Exit(1)


@app.command("snapshot")
def snapshot(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
):
    """Get the full current RBP snapshot (`/api/pbul/{hostid}/rbp`)."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.get_rbp(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            # Print high-level counts only — the snapshot is large.
            counts = {k: (len(v) if hasattr(v, "__len__") else "(scalar)") for k, v in (data or {}).items()}
            for k, v in counts.items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "rbp snapshot"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "rbp snapshot"); raise typer.Exit(1)


@app.command("delete-all")
def delete_all(
    host: Optional[int] = _host_opt(),
    yes: bool = typer.Option(False, "--yes-i-mean-it", help="Confirm destructive operation"),
):
    """Delete the entire RBP DB. Requires --yes-i-mean-it."""
    if not yes:
        typer.echo("Refusing to delete-all without --yes-i-mean-it", err=True)
        raise typer.Exit(2)
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            c.delete_rbp_all(host_id=host)
        typer.echo("RBP DB cleared")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete rbp all"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete rbp all"); raise typer.Exit(1)
