"""RBP host groups (`/api/pbul/{hostid}/rbp/hostgrps`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="RBP host groups")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id (default: BT_EPML_DEFAULT_HOST)")


@app.command("list")
def list_hostgrps(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List host groups."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_hostgrps(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
                ("Disabled", "disabled"),
                ("Type", "type"),
            ], title="Host groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list hostgrps"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list hostgrps"); raise typer.Exit(1)


@app.command("create")
def create_hostgrp(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
    type_: str = typer.Option("I", "--type", "-t", help="Group type: I=Internal, E=External"),
    host: Optional[int] = _host_opt(),
):
    """Create a host group. API requires `type` ∈ {I,E}; defaults to Internal."""
    from bt_cli.epml.client import get_client
    if type_ not in ("I", "E"):
        typer.echo(f"--type must be 'I' or 'E', got {type_!r}", err=True)
        raise typer.Exit(2)
    try:
        with get_client() as c:
            result = c.create_hostgrp({"name": name, "description": description, "type": type_}, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create hostgrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create hostgrp"); raise typer.Exit(1)


@app.command("delete")
def delete_hostgrp(
    ids: str = typer.Argument(..., help="Comma-separated hostgrp IDs"),
    host: Optional[int] = _host_opt(),
):
    """Delete one or more host groups by ID."""
    from bt_cli.epml.client import get_client
    try:
        id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
        with get_client() as c:
            c.delete_hostgrps(id_list, host_id=host)
        typer.echo(f"Deleted {len(id_list)} host group(s)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete hostgrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete hostgrp"); raise typer.Exit(1)


hosts_app = typer.Typer(no_args_is_help=True, help="Manage hosts within a host group")
app.add_typer(hosts_app, name="hosts")


@hosts_app.command("list")
def list_hosts(
    hostgrp_id: int = typer.Argument(..., help="Host group ID"),
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List hosts in a host group."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_hostgrp_hosts(hostgrp_id, host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [("Host", "host"), ("Description", "description"), ("Disabled", "disabled")], title=f"Hosts in hostgrp {hostgrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list hostgrp hosts"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list hostgrp hosts"); raise typer.Exit(1)


@hosts_app.command("add")
def add_hosts(
    hostgrp_id: int = typer.Argument(..., help="Host group ID"),
    hosts: str = typer.Option(..., "--hosts", help="Comma-separated host name/glob expressions"),
    host: Optional[int] = _host_opt(),
):
    """Add hosts to a host group."""
    from bt_cli.epml.client import get_client
    try:
        host_list = [x.strip() for x in hosts.split(",") if x.strip()]
        with get_client() as c:
            result = c.add_hostgrp_hosts(hostgrp_id, host_list, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "add hostgrp hosts"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "add hostgrp hosts"); raise typer.Exit(1)


@hosts_app.command("clear")
def clear_hosts(
    hostgrp_id: int = typer.Argument(..., help="Host group ID"),
    host: Optional[int] = _host_opt(),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Remove ALL hosts from a host group.

    The API has no per-item delete — DELETE clears everything. Use `replace`
    for selective removal.
    """
    from bt_cli.epml.client import get_client
    if not yes:
        typer.confirm(f"Clear all hosts in hostgrp {hostgrp_id}?", abort=True)
    try:
        with get_client() as c:
            c.clear_hostgrp_hosts(hostgrp_id, host_id=host)
        typer.echo(f"Cleared all hosts from hostgrp {hostgrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "clear hostgrp hosts"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "clear hostgrp hosts"); raise typer.Exit(1)


@hosts_app.command("replace")
def replace_hosts(
    hostgrp_id: int = typer.Argument(..., help="Host group ID"),
    hosts: str = typer.Option(..., "--hosts", help="Comma-separated host name/glob expressions — final list"),
    host: Optional[int] = _host_opt(),
):
    """Replace the entire host list (clear + add). Two requests; not server-atomic."""
    from bt_cli.epml.client import get_client
    try:
        host_list = [x.strip() for x in hosts.split(",") if x.strip()]
        with get_client() as c:
            result = c.replace_hostgrp_hosts(hostgrp_id, host_list, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "replace hostgrp hosts"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "replace hostgrp hosts"); raise typer.Exit(1)
