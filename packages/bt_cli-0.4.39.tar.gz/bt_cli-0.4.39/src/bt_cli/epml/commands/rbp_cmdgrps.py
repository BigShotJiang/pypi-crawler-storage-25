"""RBP command groups (`/api/pbul/{hostid}/rbp/cmdgrps`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="RBP command groups")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id (default: BT_EPML_DEFAULT_HOST)")


@app.command("list")
def list_cmdgrps(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List command groups."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_cmdgrps(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
                ("Disabled", "disabled"),
                ("Type", "type"),
            ], title="Command groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list cmdgrps"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list cmdgrps"); raise typer.Exit(1)


@app.command("create")
def create_cmdgrp(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
    host: Optional[int] = _host_opt(),
):
    """Create a command group."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            result = c.create_cmdgrp({"name": name, "description": description}, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create cmdgrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create cmdgrp"); raise typer.Exit(1)


@app.command("delete")
def delete_cmdgrp(
    ids: str = typer.Argument(..., help="Comma-separated cmdgrp IDs"),
    host: Optional[int] = _host_opt(),
):
    """Delete one or more command groups by ID."""
    from bt_cli.epml.client import get_client
    try:
        id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
        with get_client() as c:
            c.delete_cmdgrps(id_list, host_id=host)
        typer.echo(f"Deleted {len(id_list)} command group(s)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete cmdgrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete cmdgrp"); raise typer.Exit(1)


commands_app = typer.Typer(no_args_is_help=True, help="Manage commands within a command group")
app.add_typer(commands_app, name="commands")


@commands_app.command("list")
def list_commands(
    cmdgrp_id: int = typer.Argument(..., help="Command group ID"),
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List commands in a command group."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_cmdgrp_commands(cmdgrp_id, host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [("Command", "cmd"), ("Description", "description"), ("Disabled", "disabled")], title=f"Commands in cmdgrp {cmdgrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list commands"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list commands"); raise typer.Exit(1)


@commands_app.command("add")
def add_commands(
    cmdgrp_id: int = typer.Argument(..., help="Command group ID"),
    commands: str = typer.Option(..., "--commands", "-c", help="Comma-separated command strings"),
    host: Optional[int] = _host_opt(),
):
    """Add commands to a command group."""
    from bt_cli.epml.client import get_client
    try:
        cmds = [x.strip() for x in commands.split(",") if x.strip()]
        with get_client() as c:
            result = c.add_cmdgrp_commands(cmdgrp_id, cmds, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "add commands"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "add commands"); raise typer.Exit(1)


@commands_app.command("clear")
def clear_commands(
    cmdgrp_id: int = typer.Argument(..., help="Command group ID"),
    host: Optional[int] = _host_opt(),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Remove ALL commands from a command group.

    The API has no per-item delete — DELETE on the children collection clears
    everything. To selectively remove, use `replace`.
    """
    from bt_cli.epml.client import get_client
    if not yes:
        typer.confirm(f"Clear all commands in cmdgrp {cmdgrp_id}?", abort=True)
    try:
        with get_client() as c:
            c.clear_cmdgrp_commands(cmdgrp_id, host_id=host)
        typer.echo(f"Cleared all commands from cmdgrp {cmdgrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "clear commands"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "clear commands"); raise typer.Exit(1)


@commands_app.command("replace")
def replace_commands(
    cmdgrp_id: int = typer.Argument(..., help="Command group ID"),
    commands: str = typer.Option(..., "--commands", "-c", help="Comma-separated command strings — final list"),
    host: Optional[int] = _host_opt(),
):
    """Replace the entire command list (clear + add). Two requests; not server-atomic."""
    from bt_cli.epml.client import get_client
    try:
        cmds = [x.strip() for x in commands.split(",") if x.strip()]
        with get_client() as c:
            result = c.replace_cmdgrp_commands(cmdgrp_id, cmds, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "replace commands"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "replace commands"); raise typer.Exit(1)
