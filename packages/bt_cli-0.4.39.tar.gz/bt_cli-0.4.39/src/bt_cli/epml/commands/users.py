"""EPM Linux user commands (`/api/v1/users`, `/api/v2/users`)."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="EPM Linux user accounts")


def _user_columns():
    return [
        ("ID", "ID"),
        ("Username", "username"),
        ("Name", "_name"),
        ("Email", "email"),
        ("Admin", "admin"),
        ("Active", "active"),
    ]


def _flatten_user(u: dict) -> dict:
    """Add a synthetic `_name` field combining first/last for table display."""
    first = (u.get("firstname") or "").strip()
    last = (u.get("lastname") or "").strip()
    u = dict(u)
    u["_name"] = f"{first} {last}".strip() or "-"
    return u


@app.command("list")
def list_users(
    v2: bool = typer.Option(False, "--v2", help="Use the /api/v2/users variant"),
    total: bool = typer.Option(False, "--total", help="Include total count (v1 only)"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List EPM Linux users."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_users_v2() if v2 else client.list_users(total=total)

        # Both endpoints can return either a list or a paginated object — normalize.
        if isinstance(data, dict) and "data" in data:
            rows = data["data"]
        elif isinstance(data, list):
            rows = data
        else:
            rows = [data] if data else []

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            print_table([_flatten_user(r) for r in rows], _user_columns(), title=f"Users ({'v2' if v2 else 'v1'})")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)


@app.command("get")
def get_user(
    user_id: str = typer.Argument(..., help="User ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get a user by ID (`/api/v1/users/{id}`)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            user = client.get_user(user_id)

        if output == OutputFormat.JSON:
            print_json(user)
        else:
            for k, v in (user or {}).items():
                typer.echo(f"{k}: {v}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
