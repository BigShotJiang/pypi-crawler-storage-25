"""EPM Linux authentication / connectivity commands."""

import os

import httpx
import typer

from bt_cli.core.output import print_error, print_success, print_warning, print_api_error

app = typer.Typer(no_args_is_help=True, help="Authentication and connection testing")


@app.command()
def test():
    """Test EPM Linux API connection by fetching `/settings`.

    The 401 vs 403 distinction is meaningful here:

    - 401 "Access denied for this site" → wrong site prefix; the request
      didn't reach the EPM-L authorizer at all (check BT_EPML_SITE_ID).
    - 403 "Invalid key=value pair ... SHA-256 ... Base64 ..." → the path
      is wired to AWS IAM auth instead of PAT, so the PAT can't reach
      it. (Settings GET should be PAT-allowed; if you see this on /settings
      something has been re-wired upstream.)
    """
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            settings = client.get_settings()
            count = len(settings) if isinstance(settings, dict) else 0
            print_success(f"Connected to EPM Linux at site {client.site_id}")
            print_success(f"Settings reachable ({count} keys)")
            print_success(f"Default host id: {client.default_host_id}")
    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            print_error("401 Access denied for this site — check BT_EPML_SITE_ID")
        elif e.response.status_code == 403:
            print_error("403 IAM-auth required for this path — PAT cannot reach it")
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)


@app.command()
def status():
    """Show EPM Linux configuration status."""
    api_url = os.getenv("BT_EPML_API_URL", "https://api.beyondtrust.io")
    site_id = os.getenv("BT_EPML_SITE_ID", "")
    pat = os.getenv("BT_EPML_PAT", "")
    default_host = os.getenv("BT_EPML_DEFAULT_HOST", "100")

    typer.echo("EPM Linux Configuration:")
    typer.echo(f"  Gateway URL:  {api_url}")
    typer.echo(f"  Site ID:      {site_id or '(not set)'}")
    typer.echo(f"  PAT:          {pat[:12] + '...' if pat else '(not set)'}")
    typer.echo(f"  Default host: {default_host}")

    if not site_id:
        print_warning("BT_EPML_SITE_ID is not set")
    if not pat:
        print_warning("BT_EPML_PAT is not set")
