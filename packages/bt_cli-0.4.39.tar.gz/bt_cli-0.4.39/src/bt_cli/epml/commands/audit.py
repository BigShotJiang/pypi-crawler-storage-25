"""EPM Linux audit commands (`/api/v4/audit/sessions`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="Audit logs")
sessions_app = typer.Typer(no_args_is_help=True, help="Audit session records")
app.add_typer(sessions_app, name="sessions")


@sessions_app.command("list")
def list_sessions(
    filter_str: Optional[str] = typer.Option(None, "--filter", "-f", help="Filter expression"),
    take: Optional[int] = typer.Option(None, "--take", help="Page size"),
    skip: Optional[int] = typer.Option(None, "--skip", help="Offset"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort expression"),
    not_before: Optional[str] = typer.Option(None, "--not-before", help="ISO timestamp lower bound"),
    not_after: Optional[str] = typer.Option(None, "--not-after", help="ISO timestamp upper bound"),
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List audit session records."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_audit_sessions(
                filter_str=filter_str, take=take, skip=skip, sort=sort,
                not_before=not_before, not_after=not_after,
            )

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            raw_rows = data.get("data", []) if isinstance(data, dict) else (data or [])
            view = []
            for r in raw_rows:
                u = r.get("user") or {}
                user_str = u.get("username") if isinstance(u, dict) else str(u)
                view.append({
                    "session_id": r.get("session_id"),
                    "timestamp": r.get("timestamp"),
                    "user": user_str,
                    "ip": r.get("ip_address"),
                })
            print_table(view, [
                ("Session", "session_id"),
                ("Timestamp", "timestamp"),
                ("User", "user"),
                ("IP", "ip"),
            ], title="Audit Sessions")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list audit sessions")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list audit sessions")
        raise typer.Exit(1)


@sessions_app.command("categories")
def session_categories(
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """List audit session categories (`/api/v4/audit/sessions/categories`)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_audit_session_categories()

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            for c in data or []:
                typer.echo(c)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "audit categories")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "audit categories")
        raise typer.Exit(1)
