"""EPM Linux license commands (read only — `/api/epml/license` write paths are IAM-blocked)."""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json

app = typer.Typer(no_args_is_help=True, help="License information (read only)")


@app.command("get")
def get_license(
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get the enhanced license (`/api/epml/enhancedlicense`)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.get_license()

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            lic = (data or {}).get("license", data) or {}
            typer.echo(f"Owner:        {lic.get('Owner')}")
            typer.echo(f"Comment:      {lic.get('Comment')}")
            typer.echo(f"Expires:      {lic.get('Expires') or '(none)'}")
            typer.echo(f"Auto-retire:  {lic.get('AutoRetire')}")
            typer.echo(f"Recycle:      {lic.get('Recycle')}")
            typer.echo(f"PBUL clients: {lic.get('PBULPolClnts')}")
            typer.echo(f"RBP clients:  {lic.get('RBPClnts')}")
            typer.echo(f"FIM clients:  {lic.get('FIMClnts')}")
            typer.echo(f"Sudo clients: {lic.get('SudoPolClnts')}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get license")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get license")
        raise typer.Exit(1)
