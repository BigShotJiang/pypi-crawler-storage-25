"""RBP user groups (`/api/pbul/{hostid}/rbp/usergrps`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="RBP user groups")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id (default: BT_EPML_DEFAULT_HOST)")


@app.command("list")
def list_usergrps(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List user groups."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_usergrps(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
                ("Disabled", "disabled"),
                ("Type", "type"),
            ], title="User groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list usergrps"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list usergrps"); raise typer.Exit(1)


@app.command("create")
def create_usergrp(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
    type_: str = typer.Option("I", "--type", "-t", help="Group type: I=Internal, E=External"),
    host: Optional[int] = _host_opt(),
):
    """Create a user group. API requires `type` ∈ {I,E}; defaults to Internal."""
    from bt_cli.epml.client import get_client
    if type_ not in ("I", "E"):
        typer.echo(f"--type must be 'I' or 'E', got {type_!r}", err=True)
        raise typer.Exit(2)
    try:
        with get_client() as c:
            result = c.create_usergrp({"name": name, "description": description, "type": type_}, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create usergrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create usergrp"); raise typer.Exit(1)


@app.command("delete")
def delete_usergrp(
    ids: str = typer.Argument(..., help="Comma-separated usergrp IDs"),
    host: Optional[int] = _host_opt(),
):
    """Delete one or more user groups by ID."""
    from bt_cli.epml.client import get_client
    try:
        id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
        with get_client() as c:
            c.delete_usergrps(id_list, host_id=host)
        typer.echo(f"Deleted {len(id_list)} user group(s)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete usergrp"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete usergrp"); raise typer.Exit(1)


users_app = typer.Typer(no_args_is_help=True, help="Manage users within a user group")
app.add_typer(users_app, name="users")


@users_app.command("list")
def list_users(
    usergrp_id: int = typer.Argument(..., help="User group ID"),
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List users in a user group."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_usergrp_users(usergrp_id, host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [("User", "user"), ("Description", "description"), ("Disabled", "disabled")], title=f"Users in usergrp {usergrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list usergrp users"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list usergrp users"); raise typer.Exit(1)


@users_app.command("add")
def add_users(
    usergrp_id: int = typer.Argument(..., help="User group ID"),
    users: str = typer.Option(..., "--users", help="Comma-separated usernames"),
    host: Optional[int] = _host_opt(),
):
    """Add users to a user group."""
    from bt_cli.epml.client import get_client
    try:
        user_list = [x.strip() for x in users.split(",") if x.strip()]
        with get_client() as c:
            result = c.add_usergrp_users(usergrp_id, user_list, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "add usergrp users"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "add usergrp users"); raise typer.Exit(1)


@users_app.command("clear")
def clear_users(
    usergrp_id: int = typer.Argument(..., help="User group ID"),
    host: Optional[int] = _host_opt(),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Remove ALL users from a user group.

    The API has no per-item delete — DELETE clears everything. Use `replace`
    for selective removal.
    """
    from bt_cli.epml.client import get_client
    if not yes:
        typer.confirm(f"Clear all users in usergrp {usergrp_id}?", abort=True)
    try:
        with get_client() as c:
            c.clear_usergrp_users(usergrp_id, host_id=host)
        typer.echo(f"Cleared all users from usergrp {usergrp_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "clear usergrp users"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "clear usergrp users"); raise typer.Exit(1)


@users_app.command("replace")
def replace_users(
    usergrp_id: int = typer.Argument(..., help="User group ID"),
    users: str = typer.Option(..., "--users", help="Comma-separated usernames — final list"),
    host: Optional[int] = _host_opt(),
):
    """Replace the entire user list (clear + add). Two requests; not server-atomic."""
    from bt_cli.epml.client import get_client
    try:
        user_list = [x.strip() for x in users.split(",") if x.strip()]
        with get_client() as c:
            result = c.replace_usergrp_users(usergrp_id, user_list, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "replace usergrp users"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "replace usergrp users"); raise typer.Exit(1)


@app.command("create-multiple")
def create_multiple_usergrps(
    file: typer.FileText = typer.Argument(..., help="JSON file: array of {name, type, description?, ...} objects"),
    host: Optional[int] = _host_opt(),
):
    """Bulk create user groups from a JSON file (`POST /usergrps/multiple`).

    File contents must be a JSON array of group objects. Each entry needs at
    least `name`; `type` defaults to `I` if omitted.

    Example file:
        [
          {"name": "ops",      "type": "I", "description": "ops team"},
          {"name": "sec",      "type": "I"},
          {"name": "ldap-grp", "type": "E", "extinfo": "cn=foo,..."}
        ]
    """
    import json
    from bt_cli.epml.client import get_client
    try:
        groups = json.load(file)
        if not isinstance(groups, list):
            typer.echo("File must contain a JSON array", err=True)
            raise typer.Exit(2)
        with get_client() as c:
            result = c.create_multiple_usergrps(groups, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "bulk create usergrps"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "bulk create usergrps"); raise typer.Exit(1)
