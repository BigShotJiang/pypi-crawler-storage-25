"""RBP transactions (`/api/pbul/{hostid}/rbp/transaction`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import print_api_error, print_json

app = typer.Typer(no_args_is_help=True, help="RBP transactions (atomic policy changes)")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id")


@app.command("status")
def status(host: Optional[int] = _host_opt()):
    """Show current transaction state."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.transaction_status(host_id=host)
        print_json(data)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 400:
            typer.echo("(no transaction in progress)")
            return
        print_api_error(e, "tx status"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "tx status"); raise typer.Exit(1)


@app.command("begin")
def begin(host: Optional[int] = _host_opt()):
    """Begin a new RBP transaction."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.transaction_begin(host_id=host)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "tx begin"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "tx begin"); raise typer.Exit(1)


@app.command("commit")
def commit(host: Optional[int] = _host_opt()):
    """Commit the in-flight transaction."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.transaction_commit(host_id=host)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "tx commit"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "tx commit"); raise typer.Exit(1)


@app.command("rollback")
def rollback(host: Optional[int] = _host_opt()):
    """Roll back the in-flight transaction."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.transaction_rollback(host_id=host)
        print_json(data)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "tx rollback"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "tx rollback"); raise typer.Exit(1)


@app.command("abort")
def abort(host: Optional[int] = _host_opt()):
    """Abort the in-flight transaction (DELETE /transaction)."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            c.transaction_abort(host_id=host)
        typer.echo("Transaction aborted")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "tx abort"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "tx abort"); raise typer.Exit(1)
