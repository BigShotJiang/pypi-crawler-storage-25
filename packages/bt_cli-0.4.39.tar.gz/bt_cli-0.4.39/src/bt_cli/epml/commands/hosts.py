"""EPM Linux PMUL hosts commands.

Synthesized from `/api/pbul/features` because `/api/v1/hosts` is IAM-protected
on the cloud gateway and cannot be reached with a PAT.
"""

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="PMUL hosts within the tenant")


@app.command("list")
def list_hosts(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List PMUL hosts (synthesized from /pbul/features)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            hosts = client.list_hosts()

        if output == OutputFormat.JSON:
            # Strip the embedded raw blob for cleaner JSON; pass --raw for full
            print_json([{k: v for k, v in row.items() if k != "raw"} for row in hosts])
        else:
            columns = [
                ("ID", "id"),
                ("Hostname", "hostname"),
                ("IP", "ip"),
                ("Version", "version"),
                ("RBP", "rbp_enabled"),
                ("REST", "rest_enabled"),
            ]
            print_table(hosts, columns, title="PMUL Hosts")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list hosts")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list hosts")
        raise typer.Exit(1)


@app.command("features")
def list_features(
    server_type: str = typer.Option(None, "--type", "-t", help="Filter by server type"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Dump full /pbul/features response (raw feature flags per host)."""
    from bt_cli.epml.client import get_client

    try:
        with get_client() as client:
            data = client.list_features(server_type=server_type)

        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = []
            for h in data:
                rows.append({
                    "host": f"{h.get('Hostname')} ({h.get('HostID')})",
                    "version": h.get("PbulVersion"),
                    "features": ",".join(k for k, v in (h.get("Features") or {}).items() if v),
                })
            print_table(rows, [
                ("Host", "host"),
                ("Version", "version"),
                ("Enabled features", "features"),
            ], title="PMUL Host Features")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list features")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list features")
        raise typer.Exit(1)
