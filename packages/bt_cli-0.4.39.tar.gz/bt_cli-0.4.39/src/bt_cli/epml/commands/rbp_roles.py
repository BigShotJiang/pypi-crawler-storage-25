"""RBP roles + role/group assignments (`/api/pbul/{hostid}/rbp/roles`)."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="RBP roles")


def _host_opt():
    return typer.Option(None, "--host", "-H", help="PMUL host id (default: BT_EPML_DEFAULT_HOST)")


_BAR = "#" * 60


def _build_banner(title: Optional[str] = None) -> str:
    """Build a banner-style policy message.

    Server substitutes `%rbprole%` and `%event%` at session time. Pass a
    title string to replace the role-name line with literal text.
    """
    title_line = f" Policy:           {title}\r\n" if title else " Policy:           %rbprole%\r\n"
    return (
        "\r\n"
        + _BAR + "\r\n"
        + title_line
        + " Status:           %event%\r\n"
        + " Session Recorded: Yes\r\n"
        + _BAR + "\r\n"
    )


def _resolve_message(message: Optional[str], banner: bool, banner_text: Optional[str]) -> Optional[str]:
    """Pick the final message: explicit --message wins; else build a banner if asked."""
    if message is not None:
        return message
    if banner_text is not None:
        return _build_banner(banner_text)
    if banner:
        return _build_banner()
    return None  # leave message unset


@app.command("list")
def list_roles(
    host: Optional[int] = _host_opt(),
    output: OutputFormat = typer.Option(OutputFormat.TABLE, "--output", "-o"),
):
    """List roles."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            data = c.list_roles(host_id=host)
        if output == OutputFormat.JSON:
            print_json(data)
        else:
            rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
            print_table(rows, [
                ("ID", "id"),
                ("Name", "name"),
                ("Description", "description"),
                ("Disabled", "disabled"),
                ("Type", "type"),
            ], title="Roles")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list roles"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list roles"); raise typer.Exit(1)


@app.command("create")
def create_role(
    name: str = typer.Option(..., "--name", "-n"),
    description: str = typer.Option("", "--description", "-d"),
    comment: Optional[str] = typer.Option(None, "--comment", "-c", help="Internal comment (defaults to description if omitted)"),
    tag: Optional[str] = typer.Option(None, "--tag", help="Free-form tag for filtering/reporting"),
    risk: Optional[int] = typer.Option(None, "--risk", "-r", help="Risk score 0-9 (Postgres-style example uses 6)"),
    rpt: Optional[int] = typer.Option(None, "--rpt", help="Entitlement reporting: 1 to surface in `entitlement run`, 0 to hide"),
    action: str = typer.Option("A", "--action", "-a", help="Role verdict: A=Allow, R=Reject"),
    iolog: Optional[str] = typer.Option(
        None, "--iolog",
        help="I/O log path template (e.g. /iologs/%date%/%uniqueid%.iolog). Omit to disable.",
    ),
    message: Optional[str] = typer.Option(None, "--message", "-m", help="Raw message shown to the requesting user (multi-line OK; verbatim)"),
    banner: bool = typer.Option(False, "--banner", help="Use a standard ###-framed banner with %rbprole% and %event% template variables"),
    banner_text: Optional[str] = typer.Option(None, "--banner-text", help="Like --banner but use the given title text instead of %rbprole% substitution"),
    disabled: bool = typer.Option(False, "--disabled", help="Create the role disabled"),
    host: Optional[int] = _host_opt(),
):
    """Create a role.

    The API requires `action` to be exactly `A` (Allow) or `R` (Reject) —
    not 'Allow'/'Reject'. Defaults to A.

    `iolog` accepts the appliance's path template syntax — typical value is
    `/iologs/%date%/%uniqueid%.iolog`. Omit to disable I/O logging on this role.

    Three ways to set the user-visible message (in priority order):
      --message "raw text"            verbatim
      --banner-text "Custom Title"    builds the standard banner with this title
      --banner                        builds the standard banner using %rbprole%

    The standard banner format mirrors the appliance's existing roles:
      ##############################
       Policy:           <title or %rbprole%>
       Status:           %event%
       Session Recorded: Yes
      ##############################
    """
    from bt_cli.epml.client import get_client
    if action not in ("A", "R"):
        typer.echo(f"--action must be 'A' or 'R', got {action!r}", err=True)
        raise typer.Exit(2)

    body = {"name": name, "description": description, "action": action, "disabled": disabled}
    if comment is not None:
        body["comment"] = comment
    elif description:
        body["comment"] = description  # mirror description into comment (matches existing roles)
    if tag is not None:
        body["tag"] = tag
    if risk is not None:
        body["risk"] = risk
    if rpt is not None:
        body["rpt"] = rpt
    if iolog is not None:
        body["iolog"] = iolog

    final_message = _resolve_message(message, banner, banner_text)
    if final_message is not None:
        body["message"] = final_message

    try:
        with get_client() as c:
            result = c.create_role(body, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create role"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create role"); raise typer.Exit(1)


@app.command("update")
def update_role(
    role_id: int = typer.Argument(..., help="Role ID to update"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Rename the role"),
    description: Optional[str] = typer.Option(None, "--description", "-d"),
    comment: Optional[str] = typer.Option(None, "--comment", "-c"),
    tag: Optional[str] = typer.Option(None, "--tag"),
    risk: Optional[int] = typer.Option(None, "--risk", "-r"),
    rpt: Optional[int] = typer.Option(None, "--rpt"),
    action: Optional[str] = typer.Option(None, "--action", "-a", help="A=Allow / R=Reject"),
    iolog: Optional[str] = typer.Option(None, "--iolog", help="I/O log template; pass '' to disable"),
    message: Optional[str] = typer.Option(None, "--message", "-m"),
    banner: bool = typer.Option(False, "--banner"),
    banner_text: Optional[str] = typer.Option(None, "--banner-text"),
    disabled: Optional[bool] = typer.Option(None, "--disabled/--enabled"),
    host: Optional[int] = _host_opt(),
):
    """Update a role's metadata in place. Only fields you pass are modified.

    Examples:
      bt epml rbp roles update 126 --tag "RootAccess" --risk 9 --rpt 1
      bt epml rbp roles update 126 --banner-text "Root Shell Access"
      bt epml rbp roles update 126 --message "Custom session header..."
    """
    from bt_cli.epml.client import get_client
    if action is not None and action not in ("A", "R"):
        typer.echo(f"--action must be 'A' or 'R', got {action!r}", err=True)
        raise typer.Exit(2)

    body: dict = {}
    for key, val in (
        ("name", name), ("description", description), ("comment", comment),
        ("tag", tag), ("risk", risk), ("rpt", rpt), ("action", action),
        ("iolog", iolog), ("disabled", disabled),
    ):
        if val is not None:
            body[key] = val

    final_message = _resolve_message(message, banner, banner_text)
    if final_message is not None:
        body["message"] = final_message

    if not body:
        typer.echo("Nothing to update — pass at least one field flag.", err=True)
        raise typer.Exit(2)

    try:
        with get_client() as c:
            result = c.update_role(role_id, body, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update role"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update role"); raise typer.Exit(1)


@app.command("delete")
def delete_role(
    ids: str = typer.Argument(..., help="Comma-separated role IDs"),
    host: Optional[int] = _host_opt(),
):
    """Delete one or more roles by ID."""
    from bt_cli.epml.client import get_client
    try:
        id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
        with get_client() as c:
            c.delete_roles(id_list, host_id=host)
        typer.echo(f"Deleted {len(id_list)} role(s)")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete role"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete role"); raise typer.Exit(1)


@app.command("duplicate")
def duplicate_role(
    role_id: int = typer.Argument(..., help="Role ID to duplicate"),
    host: Optional[int] = _host_opt(),
):
    """Duplicate a role."""
    from bt_cli.epml.client import get_client
    try:
        with get_client() as c:
            result = c.duplicate_role(role_id, host_id=host)
        print_json(result)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "duplicate role"); raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "duplicate role"); raise typer.Exit(1)


# ---- assignments: cmdgrps / hostgrps / usergrps / tmdategrps ----

def _make_assignment_app(label: str, list_fn: str, add_fn: str, remove_fn: str, has_kind: bool = False):
    """Build a sub-typer for managing one role-child resource type.

    has_kind: if True, expose --kind S|R|B (Submit / Run-as / Both). Used for
    hostgrps and usergrps where each assignment carries a type. Cmdgrps and
    tmdategrps don't take a kind.
    """
    sub = typer.Typer(no_args_is_help=True, help=f"Manage {label} on a role")

    @sub.command("list")
    def _list(
        role_id: int = typer.Argument(..., help="Role ID"),
        host: Optional[int] = _host_opt(),
        output: OutputFormat = typer.Option(OutputFormat.JSON, "--output", "-o"),
    ):
        f"""List {label} assigned to a role."""
        from bt_cli.epml.client import get_client
        try:
            with get_client() as c:
                data = getattr(c, list_fn)(role_id, host_id=host)
            if output == OutputFormat.JSON:
                print_json(data)
            else:
                rows = data if isinstance(data, list) else (data.get("data", []) if isinstance(data, dict) else [])
                # Best-effort table: include `type` column when present
                if rows and isinstance(rows[0], dict) and "type" in rows[0]:
                    cols = [(k.upper(), k) for k in rows[0].keys()]
                else:
                    cols = [("ID", "id"), ("Name", "name")]
                print_table(rows, cols, title=f"{label} on role {role_id}")
        except httpx.HTTPStatusError as e:
            print_api_error(e, f"list role {label}"); raise typer.Exit(1)
        except Exception as e:
            print_api_error(e, f"list role {label}"); raise typer.Exit(1)

    if has_kind:
        @sub.command("add")
        def _add(
            role_id: int = typer.Argument(..., help="Role ID"),
            ids: str = typer.Option(..., "--ids", help=f"Comma-separated {label} IDs to add"),
            kind: str = typer.Option(
                "B", "--kind", "-k",
                help="Assignment type: S=Submit, R=Run-as, B=Both (creates two assignments per id)",
            ),
            host: Optional[int] = _host_opt(),
        ):
            f"""Add {label} to a role."""
            from bt_cli.epml.client import get_client
            if kind.upper() not in ("S", "R", "B"):
                typer.echo(f"--kind must be S, R, or B; got {kind!r}", err=True)
                raise typer.Exit(2)
            try:
                id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
                with get_client() as c:
                    result = getattr(c, add_fn)(role_id, id_list, kind=kind.upper(), host_id=host)
                print_json(result)
            except httpx.HTTPStatusError as e:
                print_api_error(e, f"add role {label}"); raise typer.Exit(1)
            except Exception as e:
                print_api_error(e, f"add role {label}"); raise typer.Exit(1)
    else:
        @sub.command("add")
        def _add(
            role_id: int = typer.Argument(..., help="Role ID"),
            ids: str = typer.Option(..., "--ids", help=f"Comma-separated {label} IDs to add"),
            host: Optional[int] = _host_opt(),
        ):
            f"""Add {label} to a role."""
            from bt_cli.epml.client import get_client
            try:
                id_list = [int(x.strip()) for x in ids.split(",") if x.strip()]
                with get_client() as c:
                    result = getattr(c, add_fn)(role_id, id_list, host_id=host)
                print_json(result)
            except httpx.HTTPStatusError as e:
                print_api_error(e, f"add role {label}"); raise typer.Exit(1)
            except Exception as e:
                print_api_error(e, f"add role {label}"); raise typer.Exit(1)

    @sub.command("remove")
    def _remove(
        role_id: int = typer.Argument(..., help="Role ID"),
        item_id: int = typer.Argument(..., help=f"{label} ID to remove"),
        host: Optional[int] = _host_opt(),
    ):
        f"""Remove a {label} from a role."""
        from bt_cli.epml.client import get_client
        try:
            with get_client() as c:
                getattr(c, remove_fn)(role_id, item_id, host_id=host)
            typer.echo(f"Removed {label} {item_id} from role {role_id}")
        except httpx.HTTPStatusError as e:
            print_api_error(e, f"remove role {label}"); raise typer.Exit(1)
        except Exception as e:
            print_api_error(e, f"remove role {label}"); raise typer.Exit(1)

    return sub


app.add_typer(_make_assignment_app("cmdgrps", "list_role_cmdgrps", "add_role_cmdgrps", "remove_role_cmdgrp"), name="cmdgrps")
app.add_typer(_make_assignment_app("hostgrps", "list_role_hostgrps", "add_role_hostgrps", "remove_role_hostgrp", has_kind=True), name="hostgrps")
app.add_typer(_make_assignment_app("usergrps", "list_role_usergrps", "add_role_usergrps", "remove_role_usergrp", has_kind=True), name="usergrps")
app.add_typer(_make_assignment_app("tmdategrps", "list_role_tmdategrps", "add_role_tmdategrps", "remove_role_tmdategrp"), name="tmdategrps")
