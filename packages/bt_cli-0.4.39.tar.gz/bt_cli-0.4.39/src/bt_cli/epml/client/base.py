"""EPM Linux API client (PAT bearer auth, gateway URL transform)."""

import logging
from typing import Any, Dict, List, Optional
from urllib.parse import quote as _urlquote

import httpx

from bt_cli.core.client import _warn_ssl_disabled
from bt_cli.core.config import EPMLConfig, load_epml_config
from bt_cli.core.rest_debug import get_event_hooks

logger = logging.getLogger(__name__)


class EPMLClient:
    """Client for the BeyondTrust EPM Linux API.

    The OpenAPI spec lists paths starting with `/api/...` and has an empty
    `servers` block. The deployed gateway requires a site/product prefix
    that is NOT in the spec:

        spec /api/<rest>  ->  {api_url}/site/{site_id}/epm/linux/<rest>

    `_build_url()` does that transform. Every request method calls it.
    Pass spec paths verbatim from the OpenAPI doc — the transform is
    applied centrally.

    Auth is `Authorization: Bearer <pat>`. No token exchange.

    Two-authorizer reality: some routes in the spec are protected by AWS
    IAM (SigV4) instead of the Nomine PAT custom authorizer despite the
    spec claiming `nomine-authorizer` globally. Those return 403 with an
    AWS-flavored error body. The client surfaces 403 distinctly so
    callers can offer a useful message.
    """

    def __init__(self, config: EPMLConfig):
        """Initialize EPM-L client.

        Args:
            config: EPM-L configuration with gateway URL, site ID, PAT.
        """
        self.config = config
        self.base_url = config.api_url.rstrip("/")
        self.site_id = config.site_id
        self.default_host_id = config.default_host_id
        self.site_base = f"{self.base_url}/site/{self.site_id}/epm/linux"

        if not config.verify_ssl:
            _warn_ssl_disabled()

        self._client = httpx.Client(
            verify=config.verify_ssl,
            timeout=config.timeout,
            event_hooks=get_event_hooks(),
        )

    def _build_url(self, spec_path: str) -> str:
        """Turn a spec path into the real gateway URL.

        Args:
            spec_path: Path as it appears in the OpenAPI spec (e.g.
                `/api/v1/users`, `/api/pbul/{hostid}/rbp/cmdgrps`).
                A `{hostid}` placeholder must be substituted by the
                caller before passing in.

        Returns:
            Fully-qualified URL on the gateway.
        """
        path = spec_path
        if path.startswith("/api/"):
            path = path[len("/api"):]  # leave the leading slash
        elif not path.startswith("/"):
            path = "/" + path
        return f"{self.site_base}{path}"

    def _headers(self) -> Dict[str, str]:
        """Get request headers with Bearer PAT."""
        return {
            "Authorization": f"Bearer {self.config.pat}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def host(self, host_id: Optional[int] = None) -> int:
        """Resolve the host id to use for host-scoped paths."""
        return host_id if host_id is not None else self.default_host_id

    @staticmethod
    def _q(value: Any) -> str:
        """URL-quote a path segment to prevent traversal / query injection.

        Path components like user IDs and external API IDs are user-supplied
        strings — `quote(safe="")` ensures `..`, `/`, `?`, `#`, etc. are
        percent-encoded before f-string interpolation into URLs.
        """
        return _urlquote(str(value), safe="")

    # ----- HTTP verb helpers ---------------------------------------------

    def get(
        self,
        spec_path: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """GET against a spec path. Returns parsed JSON (or text for 200/empty)."""
        response = self._client.get(self._build_url(spec_path), headers=self._headers(), params=params)
        response.raise_for_status()
        if not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    def post(
        self,
        spec_path: str,
        json: Optional[Any] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """POST against a spec path."""
        response = self._client.post(
            self._build_url(spec_path), headers=self._headers(), json=json, params=params
        )
        response.raise_for_status()
        if response.status_code == 204 or not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    def put(
        self,
        spec_path: str,
        json: Optional[Any] = None,
    ) -> Any:
        """PUT against a spec path."""
        response = self._client.put(self._build_url(spec_path), headers=self._headers(), json=json)
        response.raise_for_status()
        if response.status_code == 204 or not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    def delete(self, spec_path: str) -> None:
        """DELETE a spec path."""
        response = self._client.delete(self._build_url(spec_path), headers=self._headers())
        response.raise_for_status()

    # ----- lifecycle ------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "EPMLClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()

    # ----- Settings -------------------------------------------------------

    def get_settings(self) -> Dict[str, Any]:
        """GET /api/settings — site-level settings dict."""
        return self.get("/api/settings")

    # ----- Users ----------------------------------------------------------

    def list_users(self, total: bool = False) -> Any:
        """GET /api/v1/users.

        Args:
            total: If True, ask the API to include the total count.
        """
        params = {"total": "true"} if total else None
        return self.get("/api/v1/users", params=params)

    def get_user(self, user_id: str) -> Dict[str, Any]:
        """GET /api/v1/users/{id}."""
        return self.get(f"/api/v1/users/{self._q(user_id)}")

    def list_users_v2(self) -> Any:
        """GET /api/v2/users."""
        return self.get("/api/v2/users")

    # ----- Hosts (synthesized from /api/pbul/features) -------------------

    def list_features(self, server_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """GET /api/pbul/features — returns a list of PMUL hosts and their feature flags."""
        params = {"server_type": server_type} if server_type else None
        result = self.get("/api/pbul/features", params=params)
        return result if isinstance(result, list) else []

    def list_hosts(self) -> List[Dict[str, Any]]:
        """List PMUL hosts. Synthesized from /pbul/features because /v1/hosts is IAM-blocked.

        Returns rows shaped for table display: id, hostname, ip, version, rbp_enabled.
        """
        rows = []
        for feat in self.list_features():
            features = feat.get("Features", {}) or {}
            rows.append({
                "id": feat.get("HostID"),
                "hostname": feat.get("Hostname"),
                "ip": feat.get("IP"),
                "version": feat.get("PbulVersion"),
                "rbp_enabled": features.get("Rbp", False),
                "rest_enabled": features.get("Rest", False),
                "raw": feat,
            })
        return rows

    # ----- License -------------------------------------------------------

    def get_license(self) -> Dict[str, Any]:
        """GET /api/epml/enhancedlicense."""
        return self.get("/api/epml/enhancedlicense")

    # ----- Client packages -----------------------------------------------

    def list_client_packages(self) -> Dict[str, Any]:
        """GET /api/epml/clientpkg — list of built client installers (signed S3 URLs)."""
        return self.get("/api/epml/clientpkg")

    def get_client_package_status(self) -> Dict[str, Any]:
        """GET /api/epml/clientpkg/status — `{building: bool}` build queue status."""
        return self.get("/api/epml/clientpkg/status")

    # ----- SIEMs ---------------------------------------------------------

    def list_siems(
        self,
        filter_str: Optional[str] = None,
        take: Optional[int] = None,
        skip: Optional[int] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """GET /api/v4/siems — `{total, data: [...]}`."""
        params: Dict[str, Any] = {}
        if filter_str:
            params["filter"] = filter_str
        if take is not None:
            params["take"] = take
        if skip is not None:
            params["skip"] = skip
        if sort:
            params["sort"] = sort
        return self.get("/api/v4/siems", params=params or None)

    # ----- Audit sessions ------------------------------------------------

    def list_audit_sessions(
        self,
        filter_str: Optional[str] = None,
        take: Optional[int] = None,
        skip: Optional[int] = None,
        sort: Optional[str] = None,
        not_before: Optional[str] = None,
        not_after: Optional[str] = None,
    ) -> Any:
        """GET /api/v4/audit/sessions."""
        params: Dict[str, Any] = {}
        if filter_str:
            params["filter"] = filter_str
        if take is not None:
            params["take"] = take
        if skip is not None:
            params["skip"] = skip
        if sort:
            params["sort"] = sort
        if not_before:
            params["not_before"] = not_before
        if not_after:
            params["not_after"] = not_after
        return self.get("/api/v4/audit/sessions", params=params or None)

    def list_audit_session_categories(self) -> Any:
        """GET /api/v4/audit/sessions/categories."""
        return self.get("/api/v4/audit/sessions/categories")

    # ----- External APIs -------------------------------------------------

    def list_external_apis(
        self,
        name: Optional[str] = None,
        types: Optional[str] = None,
    ) -> Any:
        """GET /api/externalapis/."""
        params: Dict[str, Any] = {}
        if name:
            params["name"] = name
        if types:
            params["types"] = types
        return self.get("/api/externalapis/", params=params or None)

    def get_external_api(self, ext_id: str) -> Dict[str, Any]:
        """GET /api/externalapis/{id}."""
        return self.get(f"/api/externalapis/{self._q(ext_id)}")

    # ----- RBP: command groups -------------------------------------------

    def list_cmdgrps(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/cmdgrps")

    def create_cmdgrp(self, data: Dict[str, Any], host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/cmdgrps", json=data)

    def delete_cmdgrps(self, ids: List[int], host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        for cid in ids:
            self._delete_with_query(f"/api/pbul/{h}/rbp/cmdgrps", {"id": cid})

    def list_cmdgrp_commands(self, cmdgrp_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/cmdgrps/{cmdgrp_id}/commands")

    def add_cmdgrp_commands(self, cmdgrp_id: int, commands: List[str], host_id: Optional[int] = None) -> Any:
        """Append commands to a cmdgrp. POST is additive, not replacing."""
        h = self.host(host_id)
        body = [{"cmd": c} for c in commands]
        return self.post(f"/api/pbul/{h}/rbp/cmdgrps/{cmdgrp_id}/commands", json=body)

    def clear_cmdgrp_commands(self, cmdgrp_id: int, host_id: Optional[int] = None) -> None:
        """DELETE all commands in a cmdgrp. The API has no per-item delete."""
        h = self.host(host_id)
        self._delete_no_body(f"/api/pbul/{h}/rbp/cmdgrps/{cmdgrp_id}/commands")

    def replace_cmdgrp_commands(self, cmdgrp_id: int, commands: List[str], host_id: Optional[int] = None) -> Any:
        """Atomic-ish replace: clear then add. Two requests; not server-atomic."""
        self.clear_cmdgrp_commands(cmdgrp_id, host_id=host_id)
        return self.add_cmdgrp_commands(cmdgrp_id, commands, host_id=host_id)

    # ----- RBP: host groups ---------------------------------------------

    def list_hostgrps(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/hostgrps")

    def create_hostgrp(self, data: Dict[str, Any], host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        # Server requires `type` ∈ {"I","E"}. Default to Internal if omitted.
        body = dict(data)
        body.setdefault("type", "I")
        return self.post(f"/api/pbul/{h}/rbp/hostgrps", json=body)

    def delete_hostgrps(self, ids: List[int], host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        for hid in ids:
            self._delete_with_query(f"/api/pbul/{h}/rbp/hostgrps", {"id": hid})

    def list_hostgrp_hosts(self, hostgrp_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/hostgrps/{hostgrp_id}/hosts")

    def add_hostgrp_hosts(self, hostgrp_id: int, hosts: List[str], host_id: Optional[int] = None) -> Any:
        """Append hostnames/patterns to a hostgrp. POST is additive."""
        h = self.host(host_id)
        body = [{"host": x} for x in hosts]
        return self.post(f"/api/pbul/{h}/rbp/hostgrps/{hostgrp_id}/hosts", json=body)

    def clear_hostgrp_hosts(self, hostgrp_id: int, host_id: Optional[int] = None) -> None:
        """DELETE all hosts in a hostgrp. The API has no per-item delete."""
        h = self.host(host_id)
        self._delete_no_body(f"/api/pbul/{h}/rbp/hostgrps/{hostgrp_id}/hosts")

    def replace_hostgrp_hosts(self, hostgrp_id: int, hosts: List[str], host_id: Optional[int] = None) -> Any:
        self.clear_hostgrp_hosts(hostgrp_id, host_id=host_id)
        return self.add_hostgrp_hosts(hostgrp_id, hosts, host_id=host_id)

    # ----- RBP: user groups ---------------------------------------------

    def list_usergrps(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/usergrps")

    def create_usergrp(self, data: Dict[str, Any], host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        # Server requires `type` ∈ {"I","E"}. Default to Internal if omitted.
        body = dict(data)
        body.setdefault("type", "I")
        return self.post(f"/api/pbul/{h}/rbp/usergrps", json=body)

    def delete_usergrps(self, ids: List[int], host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        for uid in ids:
            self._delete_with_query(f"/api/pbul/{h}/rbp/usergrps", {"id": uid})

    def list_usergrp_users(self, usergrp_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/usergrps/{usergrp_id}/users")

    def add_usergrp_users(self, usergrp_id: int, users: List[str], host_id: Optional[int] = None) -> Any:
        """Append usernames to a usergrp. POST is additive."""
        h = self.host(host_id)
        body = [{"user": u} for u in users]
        return self.post(f"/api/pbul/{h}/rbp/usergrps/{usergrp_id}/users", json=body)

    def clear_usergrp_users(self, usergrp_id: int, host_id: Optional[int] = None) -> None:
        """DELETE all users in a usergrp. The API has no per-item delete."""
        h = self.host(host_id)
        self._delete_no_body(f"/api/pbul/{h}/rbp/usergrps/{usergrp_id}/users")

    def replace_usergrp_users(self, usergrp_id: int, users: List[str], host_id: Optional[int] = None) -> Any:
        self.clear_usergrp_users(usergrp_id, host_id=host_id)
        return self.add_usergrp_users(usergrp_id, users, host_id=host_id)

    def create_multiple_usergrps(self, groups: List[Dict[str, Any]], host_id: Optional[int] = None) -> Any:
        """Bulk create user groups via /usergrps/multiple.

        Each group dict needs at least `name` and `type` (`I` or `E`).
        Body is wrapped: `{"usergroups": [...]}` — the spec doesn't document
        the wrapper key.
        """
        h = self.host(host_id)
        # Default any missing types to "I"
        normalized = []
        for g in groups:
            entry = dict(g)
            entry.setdefault("type", "I")
            normalized.append(entry)
        return self.post(f"/api/pbul/{h}/rbp/usergrps/multiple", json={"usergroups": normalized})

    # ----- RBP: time/date groups ----------------------------------------

    def list_tmdategrps(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/tmdategrps")

    def create_tmdategrp(self, data: Dict[str, Any], host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/tmdategrps", json=data)

    def delete_tmdategrps(self, ids: List[int], host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        for tid in ids:
            self._delete_with_query(f"/api/pbul/{h}/rbp/tmdategrps", {"id": tid})

    # --- tmdates (children of tmdategrps) ---

    def list_tmdategrp_tmdates(self, tmdategrp_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/tmdategrps/{tmdategrp_id}/tmdates")

    def add_tmdategrp_tmdates(self, tmdategrp_id: int, tmdates: List[Dict[str, Any]], host_id: Optional[int] = None) -> Any:
        """Append time/date entries to a tmdategrp. Body is wrapped: `{tmdates: [...]}`."""
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/tmdategrps/{tmdategrp_id}/tmdates", json={"tmdates": tmdates})

    def clear_tmdategrp_tmdates(self, tmdategrp_id: int, host_id: Optional[int] = None) -> None:
        """DELETE all tmdates in a tmdategrp."""
        h = self.host(host_id)
        self._delete_no_body(f"/api/pbul/{h}/rbp/tmdategrps/{tmdategrp_id}/tmdates")

    def replace_tmdategrp_tmdates(self, tmdategrp_id: int, tmdates: List[Dict[str, Any]], host_id: Optional[int] = None) -> Any:
        self.clear_tmdategrp_tmdates(tmdategrp_id, host_id=host_id)
        return self.add_tmdategrp_tmdates(tmdategrp_id, tmdates, host_id=host_id)

    # ----- RBP: roles ---------------------------------------------------

    def list_roles(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/roles")

    def create_role(self, data: Dict[str, Any], host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        # Server requires `action` ∈ {"A","R"} (Allow / Reject). Default Allow.
        body = dict(data)
        body.setdefault("action", "A")
        return self.post(f"/api/pbul/{h}/rbp/roles", json=body)

    def update_role(self, role_id: int, partial: Dict[str, Any], host_id: Optional[int] = None) -> Any:
        """Update an existing role (read-modify-write).

        The API's create/update endpoint OVERWRITES on `id` match — fields not
        in the body get zeroed/cleared. To make an update feel like a partial
        modification, this helper fetches the current role, merges in your
        changes, and posts the merged record. Avoids accidentally clobbering
        `action`, `name`, `iolog`, etc. when you only meant to change `tag`.

        Caveat: the v1 API has no GET-single-role, so we list and filter.
        """
        h = self.host(host_id)
        roles = self.list_roles(host_id=host_id) or []
        current = next((r for r in roles if r.get("id") == role_id), None)
        if current is None:
            raise ValueError(f"role id {role_id} not found")
        # role child relations (rolecmds/roleusers/etc.) get filtered out so we
        # don't accidentally rewrite assignments — those have their own endpoints.
        merged = {k: v for k, v in current.items() if not k.startswith("role")}
        merged.update(partial)
        merged["id"] = role_id
        return self.post(f"/api/pbul/{h}/rbp/roles", json=merged)

    def delete_roles(self, ids: List[int], host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        for rid in ids:
            self._delete_with_query(f"/api/pbul/{h}/rbp/roles", {"id": rid})

    def duplicate_role(self, role_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/roles/duplicate/{role_id}")

    def list_role_cmdgrps(self, role_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/roles/{role_id}/cmdgrps")

    def add_role_cmdgrps(self, role_id: int, cmdgrp_ids: List[int], host_id: Optional[int] = None) -> List[Any]:
        """Add cmdgrps to a role. The API accepts ONE assignment per request
        as a bare object (`{cmds: <id>}`) — not an array. Loop here.
        """
        h = self.host(host_id)
        path = f"/api/pbul/{h}/rbp/roles/{role_id}/cmdgrps"
        return [self.post(path, json={"cmds": cid}) for cid in cmdgrp_ids]

    def remove_role_cmdgrp(self, role_id: int, cmdgrp_id: int, host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        self.delete(f"/api/pbul/{h}/rbp/roles/{role_id}/cmdgrps/{cmdgrp_id}")

    def list_role_hostgrps(self, role_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/roles/{role_id}/hostgrps")

    def add_role_hostgrps(
        self,
        role_id: int,
        hostgrp_ids: List[int],
        kind: str = "B",
        host_id: Optional[int] = None,
    ) -> List[Any]:
        """Add hostgrps to a role. Each assignment carries a `type`:
          S = Submit (where the request comes from)
          R = Run-as (where the command actually runs)

        For a typical "users on these hosts can run on these same hosts" rule,
        you usually want BOTH — pass `kind="B"` (default) and the client posts
        twice, once with type S and once with type R.
        """
        h = self.host(host_id)
        path = f"/api/pbul/{h}/rbp/roles/{role_id}/hostgrps"
        types = ("S", "R") if kind.upper() == "B" else (kind.upper(),)
        if not all(t in ("S", "R") for t in types):
            raise ValueError(f"hostgrp kind must be S, R, or B (both); got {kind!r}")
        results = []
        for hid in hostgrp_ids:
            for t in types:
                results.append(self.post(path, json={"hosts": hid, "type": t}))
        return results

    def remove_role_hostgrp(self, role_id: int, hostgrp_id: int, host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        self.delete(f"/api/pbul/{h}/rbp/roles/{role_id}/hostgrps/{hostgrp_id}")

    def list_role_usergrps(self, role_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/roles/{role_id}/usergrps")

    def add_role_usergrps(
        self,
        role_id: int,
        usergrp_ids: List[int],
        kind: str = "B",
        host_id: Optional[int] = None,
    ) -> List[Any]:
        """Add usergrps to a role. Same S/R/B `type` semantics as hostgrps.
          S = Submit user (who requests)
          R = Run-as user (whose identity the command runs under)
        """
        h = self.host(host_id)
        path = f"/api/pbul/{h}/rbp/roles/{role_id}/usergrps"
        types = ("S", "R") if kind.upper() == "B" else (kind.upper(),)
        if not all(t in ("S", "R") for t in types):
            raise ValueError(f"usergrp kind must be S, R, or B (both); got {kind!r}")
        results = []
        for uid in usergrp_ids:
            for t in types:
                results.append(self.post(path, json={"users": uid, "type": t}))
        return results

    def remove_role_usergrp(self, role_id: int, usergrp_id: int, host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        self.delete(f"/api/pbul/{h}/rbp/roles/{role_id}/usergrps/{usergrp_id}")

    def list_role_tmdategrps(self, role_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/roles/{role_id}/tmdategrps")

    def add_role_tmdategrps(self, role_id: int, tmdategrp_ids: List[int], host_id: Optional[int] = None) -> List[Any]:
        """Add tmdategrps to a role. Single object per request, key is `tmdates`."""
        h = self.host(host_id)
        path = f"/api/pbul/{h}/rbp/roles/{role_id}/tmdategrps"
        return [self.post(path, json={"tmdates": tid}) for tid in tmdategrp_ids]

    def remove_role_tmdategrp(self, role_id: int, tmdategrp_id: int, host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        self.delete(f"/api/pbul/{h}/rbp/roles/{role_id}/tmdategrps/{tmdategrp_id}")

    # ----- RBP: entitlement / policy / versions / diff -------------------

    def get_rbp(self, host_id: Optional[int] = None) -> Any:
        """GET /api/pbul/{hostid}/rbp — full RBP snapshot."""
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp")

    def get_entitlement(self, host_id: Optional[int] = None, raw: bool = False) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/entitlement{'/raw' if raw else ''}")

    def export_rbp(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/export")

    def import_rbp(self, payload: Any, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/import", json=payload)

    def revert_rbp(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/revert")

    def list_rbp_versions(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/versions")

    def diff_rbp(self, host_id: Optional[int] = None, params: Optional[Dict[str, Any]] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/diff", params=params)

    def delete_rbp_all(self, host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        self.delete(f"/api/pbul/{h}/rbp/all")

    # ----- RBP: transactions ---------------------------------------------

    def transaction_status(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/transaction")

    def transaction_begin(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/transaction/begin")

    def transaction_commit(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/transaction/commit")

    def transaction_rollback(self, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.post(f"/api/pbul/{h}/rbp/transaction/rollback")

    def transaction_abort(self, host_id: Optional[int] = None) -> None:
        h = self.host(host_id)
        self.delete(f"/api/pbul/{h}/rbp/transaction")

    # ----- RBP: test suites ---------------------------------------------

    def list_testsuites(self) -> Any:
        return self.get("/api/pbul/rbp/testsuite")

    def get_testsuite(self, suite_id: int) -> Any:
        return self.get(f"/api/pbul/rbp/testsuite/{suite_id}")

    def create_testsuite(self, name: str, description: str = "") -> Any:
        return self.post("/api/pbul/rbp/testsuite", json={"name": name, "description": description})

    def update_testsuite(self, suite_id: int, data: Dict[str, Any]) -> Any:
        return self.put(f"/api/pbul/rbp/testsuite/{suite_id}", json=data)

    def delete_testsuite(self, suite_id: int) -> None:
        self.delete(f"/api/pbul/rbp/testsuite/{suite_id}")

    def add_testsuite_test(self, suite_id: int, test: Dict[str, Any]) -> Any:
        body = dict(test)
        body.setdefault("testsuite_id", suite_id)
        return self.post("/api/pbul/rbp/testsuite/test", json=body)

    def update_testsuite_test(self, test_id: int, data: Dict[str, Any]) -> Any:
        return self.put(f"/api/pbul/rbp/testsuite/test/{test_id}", json=data)

    def delete_testsuite_test(self, test_id: int) -> None:
        self.delete(f"/api/pbul/rbp/testsuite/test/{test_id}")

    def run_testsuite(self, suite_id: int, host_id: Optional[int] = None) -> Any:
        h = self.host(host_id)
        return self.get(f"/api/pbul/{h}/rbp/testsuite/{suite_id}/run")

    # ----- helpers -------------------------------------------------------

    def _delete_with_body(self, spec_path: str, body: Any) -> Any:
        """DELETE with a JSON body (httpx supports this via request())."""
        response = self._client.request(
            "DELETE",
            self._build_url(spec_path),
            headers=self._headers(),
            json=body,
        )
        response.raise_for_status()
        if response.status_code == 204 or not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    def _delete_no_body(self, spec_path: str) -> None:
        """DELETE with no params and no body.

        RBP child collections (e.g. cmdgrps/{id}/commands, hostgrps/{id}/hosts,
        usergrps/{id}/users, tmdategrps/{id}/tmdates) all behave as
        "delete all" when this is called — there's no per-item delete in the
        v1 API. To remove a single child, GET the list, clear, then re-add the
        ones you want to keep.
        """
        response = self._client.delete(self._build_url(spec_path), headers=self._headers())
        response.raise_for_status()

    def _delete_with_query(self, spec_path: str, params: Dict[str, Any]) -> None:
        """DELETE with query parameters (no body).

        RBP collection deletes (`/pbul/{hostid}/rbp/{entity}`) take `id` as a
        query param, not a JSON body. Repeated `?id=A&id=B` is accepted by the
        server but only the first value is honored — callers should loop.
        """
        response = self._client.delete(
            self._build_url(spec_path),
            headers=self._headers(),
            params=params,
        )
        response.raise_for_status()

    # ----- iologs --------------------------------------------------------

    def list_iologs(
        self,
        host_id: Optional[int] = None,
        start: int = 0,
        length: int = 100,
    ) -> Any:
        """GET /api/pbul/{hostid}/iologs — paginated list of iolog files.

        Args:
            host_id: PMUL host id; defaults to `default_host_id`.
            start: Offset (the spec calls it `start`).
            length: Page size (spec calls it `len`).
        """
        h = self.host(host_id)
        params = {"start": start, "len": length}
        return self.get(f"/api/pbul/{h}/iologs", params=params)


def get_client() -> EPMLClient:
    """Get an EPM-L client with configuration from environment / config file."""
    config = load_epml_config()
    return EPMLClient(config)
