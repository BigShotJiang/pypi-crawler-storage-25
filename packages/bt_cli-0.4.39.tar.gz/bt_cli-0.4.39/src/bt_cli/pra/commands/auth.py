"""PRA authentication commands."""

import os

import httpx
import typer

from bt_cli.core.output import print_success, print_error, print_warning, print_api_error

app = typer.Typer(no_args_is_help=True)


@app.command()
def test():
    """Test PRA API connection."""
    from bt_cli.pra.client import get_client

    try:
        client = get_client()
        # Try to list jumpoints as a connection test
        jumpoints = client.list_jumpoints()
        print_success(f"Connected to PRA API")
        print_success(f"Found {len(jumpoints)} jumpoints")
    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)


@app.command()
def status():
    """Show PRA configuration status."""
    api_url = os.getenv("BT_PRA_API_URL", "")
    client_id = os.getenv("BT_PRA_CLIENT_ID", "")
    client_secret = os.getenv("BT_PRA_CLIENT_SECRET", "")

    typer.echo("PRA Configuration:")
    typer.echo(f"  API URL: {api_url or '(not set)'}")
    typer.echo(f"  Client ID: {client_id[:8] + '...' if client_id else '(not set)'}")
    typer.echo(f"  Client Secret: {'*' * 8 if client_secret else '(not set)'}")

    if not api_url:
        print_warning("BT_PRA_API_URL is not set")
    if not client_id:
        print_warning("BT_PRA_CLIENT_ID is not set")
    if not client_secret:
        print_warning("BT_PRA_CLIENT_SECRET is not set")
