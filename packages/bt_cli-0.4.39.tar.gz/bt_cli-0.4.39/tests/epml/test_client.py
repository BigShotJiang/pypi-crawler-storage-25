"""Tests for the EPM Linux client (URL transform + PAT auth + verb helpers)."""

import httpx
import pytest
import respx

from bt_cli.core.config import EPMLConfig
from bt_cli.epml.client import EPMLClient


@pytest.fixture
def epml_config() -> EPMLConfig:
    return EPMLConfig(
        api_url="https://mock-gateway.example.com",
        site_id="SITE",
        pat="PAT_test",
        default_host_id=100,
        verify_ssl=False,
        timeout=30.0,
    )


# ---------------------------------------------------------------------------
# URL transform — every spec path must round-trip through `_build_url` correctly.
# ---------------------------------------------------------------------------

class TestURLTransform:
    """Spec path → real gateway URL."""

    def test_strips_api_prefix(self, epml_config):
        c = EPMLClient(epml_config)
        assert c._build_url("/api/settings") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/settings"

    def test_strips_api_prefix_with_subpath(self, epml_config):
        c = EPMLClient(epml_config)
        assert c._build_url("/api/v1/users") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/v1/users"

    def test_strips_api_prefix_host_scoped(self, epml_config):
        c = EPMLClient(epml_config)
        assert c._build_url("/api/pbul/100/rbp/cmdgrps") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/100/rbp/cmdgrps"

    def test_passes_through_already_stripped(self, epml_config):
        """A path without /api/ prefix should still be valid (no double-strip)."""
        c = EPMLClient(epml_config)
        assert c._build_url("/externalapis") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/externalapis"

    def test_adds_leading_slash_when_missing(self, epml_config):
        c = EPMLClient(epml_config)
        assert c._build_url("settings") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/settings"

    def test_preserves_trailing_slash(self, epml_config):
        """`/api/externalapis/` (trailing slash in spec) should keep it."""
        c = EPMLClient(epml_config)
        assert c._build_url("/api/externalapis/") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/externalapis/"

    def test_strips_trailing_slash_in_base_url(self):
        """Base URL with trailing slash shouldn't double up."""
        cfg = EPMLConfig(
            api_url="https://mock-gateway.example.com/",
            site_id="SITE", pat="PAT", default_host_id=100,
            verify_ssl=False,
        )
        c = EPMLClient(cfg)
        assert c._build_url("/api/settings") == \
            "https://mock-gateway.example.com/site/SITE/epm/linux/settings"


# ---------------------------------------------------------------------------
# Auth header
# ---------------------------------------------------------------------------

class TestAuthHeader:
    def test_bearer_pat_in_headers(self, epml_config):
        c = EPMLClient(epml_config)
        h = c._headers()
        assert h["Authorization"] == "Bearer PAT_test"
        assert h["Accept"] == "application/json"
        assert h["Content-Type"] == "application/json"

    @respx.mock
    def test_request_includes_bearer(self, epml_config):
        """A real GET should send the Bearer header."""
        respx.get(
            "https://mock-gateway.example.com/site/SITE/epm/linux/settings"
        ).mock(return_value=httpx.Response(200, json={"ok": True}))

        c = EPMLClient(epml_config)
        result = c.get("/api/settings")
        assert result == {"ok": True}

        # Confirm the captured request had our PAT
        assert respx.calls[0].request.headers["Authorization"] == "Bearer PAT_test"


# ---------------------------------------------------------------------------
# Verb helpers
# ---------------------------------------------------------------------------

class TestHTTPVerbs:
    @respx.mock
    def test_get_returns_json(self, epml_config):
        respx.get(
            "https://mock-gateway.example.com/site/SITE/epm/linux/v1/users"
        ).mock(return_value=httpx.Response(200, json=[{"ID": 1}]))

        c = EPMLClient(epml_config)
        assert c.get("/api/v1/users") == [{"ID": 1}]

    @respx.mock
    def test_get_with_params(self, epml_config):
        route = respx.get(
            "https://mock-gateway.example.com/site/SITE/epm/linux/v4/siems"
        ).mock(return_value=httpx.Response(200, json={"total": 0, "data": []}))

        c = EPMLClient(epml_config)
        c.list_siems(filter_str="x", take=10, skip=20, sort="name")

        req = route.calls.last.request
        assert "filter=x" in str(req.url)
        assert "take=10" in str(req.url)
        assert "skip=20" in str(req.url)
        assert "sort=name" in str(req.url)

    @respx.mock
    def test_post_returns_json(self, epml_config):
        respx.post(
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/rbp/testsuite"
        ).mock(return_value=httpx.Response(201, json={"id": 5}))

        c = EPMLClient(epml_config)
        assert c.create_testsuite("foo", "bar") == {"id": 5}

    @respx.mock
    def test_delete_returns_none(self, epml_config):
        respx.delete(
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/rbp/testsuite/1"
        ).mock(return_value=httpx.Response(204))

        c = EPMLClient(epml_config)
        assert c.delete_testsuite(1) is None

    @respx.mock
    def test_delete_via_query_param_one_per_id(self, epml_config):
        """RBP collection deletes use ?id=N query string, single ID per call."""
        route = respx.delete(
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/100/rbp/cmdgrps"
        ).mock(return_value=httpx.Response(200))

        c = EPMLClient(epml_config)
        c.delete_cmdgrps([1, 2, 3])
        # Three separate requests, one per id
        assert route.call_count == 3
        sent_ids = sorted(call.request.url.params["id"] for call in route.calls)
        assert sent_ids == ["1", "2", "3"]


# ---------------------------------------------------------------------------
# Host-id resolution for host-scoped paths
# ---------------------------------------------------------------------------

class TestHostId:
    @respx.mock
    def test_default_host_used(self, epml_config):
        route = respx.get(
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/100/rbp/cmdgrps"
        ).mock(return_value=httpx.Response(200, json=[]))
        c = EPMLClient(epml_config)
        c.list_cmdgrps()
        assert route.called

    @respx.mock
    def test_host_override(self, epml_config):
        route = respx.get(
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/42/rbp/cmdgrps"
        ).mock(return_value=httpx.Response(200, json=[]))
        c = EPMLClient(epml_config)
        c.list_cmdgrps(host_id=42)
        assert route.called


# ---------------------------------------------------------------------------
# Synthesized hosts list (from /pbul/features)
# ---------------------------------------------------------------------------

class TestSynthesizedHosts:
    @respx.mock
    def test_list_hosts_from_features(self, epml_config):
        respx.get(
            "https://mock-gateway.example.com/site/SITE/epm/linux/pbul/features"
        ).mock(return_value=httpx.Response(200, json=[
            {"HostID": 100, "Hostname": "PMUL", "IP": "1.2.3.4", "PbulVersion": "24.1",
             "Features": {"Rbp": True, "Rest": True, "Sudo": False}},
        ]))

        c = EPMLClient(epml_config)
        hosts = c.list_hosts()
        assert len(hosts) == 1
        h = hosts[0]
        assert h["id"] == 100
        assert h["hostname"] == "PMUL"
        assert h["rbp_enabled"] is True
        assert h["rest_enabled"] is True
