"""CLI command tests for `bt epml ...`."""

from unittest.mock import patch

import httpx
import pytest
import respx
from typer.testing import CliRunner

from bt_cli.core.config import EPMLConfig
from bt_cli.epml.commands import app as epml_app


@pytest.fixture
def env_overrides(monkeypatch):
    monkeypatch.setenv("BT_EPML_API_URL", "https://mock-gateway.example.com")
    monkeypatch.setenv("BT_EPML_SITE_ID", "SITE")
    monkeypatch.setenv("BT_EPML_PAT", "PAT_test")
    monkeypatch.setenv("BT_EPML_DEFAULT_HOST", "100")
    monkeypatch.setenv("BT_EPML_VERIFY_SSL", "false")


def _gw(path: str) -> str:
    return f"https://mock-gateway.example.com/site/SITE/epm/linux{path}"


class TestAuth:
    @respx.mock
    def test_auth_test_success(self, env_overrides):
        respx.get(_gw("/settings")).mock(
            return_value=httpx.Response(200, json={"session_timeout": "8h"})
        )
        result = CliRunner().invoke(epml_app, ["auth", "test"])
        assert result.exit_code == 0
        assert "Connected to EPM Linux" in result.stdout
        assert "1 keys" in result.stdout

    @respx.mock
    def test_auth_test_401_explains_site(self, env_overrides):
        respx.get(_gw("/settings")).mock(
            return_value=httpx.Response(401, json={"error": "Access denied for this site"})
        )
        result = CliRunner().invoke(epml_app, ["auth", "test"])
        assert result.exit_code == 1
        assert "401" in result.stdout
        assert "BT_EPML_SITE_ID" in result.stdout

    @respx.mock
    def test_auth_test_403_explains_iam(self, env_overrides):
        respx.get(_gw("/settings")).mock(
            return_value=httpx.Response(403, text="iam-denied")
        )
        result = CliRunner().invoke(epml_app, ["auth", "test"])
        assert result.exit_code == 1
        assert "IAM" in result.stdout

    def test_auth_status_unconfigured_warns(self, monkeypatch):
        # Clear env so status reports unconfigured
        for key in ("BT_EPML_SITE_ID", "BT_EPML_PAT"):
            monkeypatch.delenv(key, raising=False)
        result = CliRunner().invoke(epml_app, ["auth", "status"])
        assert result.exit_code == 0
        assert "BT_EPML_SITE_ID is not set" in result.stdout
        assert "BT_EPML_PAT is not set" in result.stdout


class TestSettings:
    @respx.mock
    def test_settings_list(self, env_overrides):
        respx.get(_gw("/settings")).mock(
            return_value=httpx.Response(200, json={"k1": "v1", "k2": "v2"})
        )
        result = CliRunner().invoke(epml_app, ["settings", "list", "-o", "json"])
        assert result.exit_code == 0
        assert "k1" in result.stdout
        assert "v1" in result.stdout

    @respx.mock
    def test_settings_get(self, env_overrides):
        respx.get(_gw("/settings")).mock(
            return_value=httpx.Response(200, json={"session_timeout": "8h"})
        )
        result = CliRunner().invoke(epml_app, ["settings", "get", "session_timeout"])
        assert result.exit_code == 0
        assert "8h" in result.stdout


class TestHosts:
    @respx.mock
    def test_hosts_list_synthesizes(self, env_overrides):
        respx.get(_gw("/pbul/features")).mock(
            return_value=httpx.Response(200, json=[{
                "HostID": 100, "Hostname": "PMUL", "IP": "1.2.3.4",
                "PbulVersion": "24.1.0",
                "Features": {"Rbp": True, "Rest": True},
            }])
        )
        result = CliRunner().invoke(epml_app, ["hosts", "list"])
        assert result.exit_code == 0
        assert "PMUL" in result.stdout
        assert "100" in result.stdout


class TestRBPCmdgrps:
    @respx.mock
    def test_cmdgrps_list(self, env_overrides):
        respx.get(_gw("/pbul/100/rbp/cmdgrps")).mock(
            return_value=httpx.Response(200, json=[
                {"id": 1, "name": "Any", "description": "any cmd", "disabled": 0},
            ])
        )
        result = CliRunner().invoke(epml_app, ["rbp", "cmdgrps", "list"])
        assert result.exit_code == 0
        assert "Any" in result.stdout

    @respx.mock
    def test_cmdgrps_list_host_override(self, env_overrides):
        respx.get(_gw("/pbul/77/rbp/cmdgrps")).mock(
            return_value=httpx.Response(200, json=[])
        )
        result = CliRunner().invoke(epml_app, ["rbp", "cmdgrps", "list", "-H", "77"])
        assert result.exit_code == 0


class TestTestSuite:
    @respx.mock
    def test_run_suite_pass(self, env_overrides):
        respx.get(_gw("/pbul/100/rbp/testsuite/5/run")).mock(
            return_value=httpx.Response(200, json={"id": 5, "total": 3, "failures": []})
        )
        result = CliRunner().invoke(epml_app, ["rbp", "tests", "run", "--suite", "5"])
        assert result.exit_code == 0

    @respx.mock
    def test_run_suite_failure_exits_nonzero(self, env_overrides):
        respx.get(_gw("/pbul/100/rbp/testsuite/5/run")).mock(
            return_value=httpx.Response(200, json={
                "id": 5, "total": 3, "failures": [{"id": 1, "command": "rm -rf /"}]
            })
        )
        result = CliRunner().invoke(epml_app, ["rbp", "tests", "run", "--suite", "5"])
        assert result.exit_code == 1


class TestQuickWorkflow:
    @respx.mock
    def test_tests_then_deploy_commits_on_pass(self, env_overrides):
        respx.get(_gw("/pbul/100/rbp/transaction")).mock(
            return_value=httpx.Response(200, json={"transaction_id": "abc"})
        )
        respx.get(_gw("/pbul/100/rbp/testsuite/5/run")).mock(
            return_value=httpx.Response(200, json={"total": 2, "failures": []})
        )
        commit_route = respx.post(_gw("/pbul/100/rbp/transaction/commit")).mock(
            return_value=httpx.Response(200, json={})
        )

        result = CliRunner().invoke(epml_app, ["quick", "tests-then-deploy", "-s", "5"])
        assert result.exit_code == 0
        assert commit_route.called

    @respx.mock
    def test_tests_then_deploy_rolls_back_on_failure(self, env_overrides):
        respx.get(_gw("/pbul/100/rbp/transaction")).mock(
            return_value=httpx.Response(200, json={"transaction_id": "abc"})
        )
        respx.get(_gw("/pbul/100/rbp/testsuite/5/run")).mock(
            return_value=httpx.Response(200, json={"total": 2, "failures": [{"id": 1}]})
        )
        rollback_route = respx.post(_gw("/pbul/100/rbp/transaction/rollback")).mock(
            return_value=httpx.Response(200, json={})
        )

        result = CliRunner().invoke(epml_app, ["quick", "tests-then-deploy", "-s", "5"])
        assert result.exit_code == 1
        assert rollback_route.called

    @respx.mock
    def test_tests_then_deploy_errors_with_no_tx(self, env_overrides):
        respx.get(_gw("/pbul/100/rbp/transaction")).mock(
            return_value=httpx.Response(400, text="no tx")
        )

        result = CliRunner().invoke(epml_app, ["quick", "tests-then-deploy", "-s", "5"])
        assert result.exit_code == 2
        assert "tx begin" in result.stdout
