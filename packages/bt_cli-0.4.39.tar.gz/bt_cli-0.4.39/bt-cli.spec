# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec file for bt-cli CLI.

Build commands:
    # Single file executable (recommended for distribution)
    pyinstaller bt-cli.spec

    # Or build manually:
    pip install -e .
    pyinstaller --onefile --name bt scripts/bt_entry.py
"""

import sys
from pathlib import Path

# Get the project root directory
project_root = Path(SPECPATH)

a = Analysis(
    ['scripts/bt_entry.py'],
    pathex=[str(project_root / 'src')],
    binaries=[],
    datas=[
        # Include CLAUDE.md in package data
        (str(project_root / 'CLAUDE.md'), 'bt_cli/data'),
        # Include skills for bt skills command
        (str(project_root / '.claude' / 'skills'), 'bt_cli/data/skills'),
    ],
    hiddenimports=[
        # Core dependencies
        'typer',
        'typer.main',
        'typer.core',
        'click',
        'click.core',
        'click.shell_completion',
        'rich',
        'rich.console',
        'rich.table',
        'rich.panel',
        'rich.prompt',
        'httpx',
        'httpx._transports',
        'httpx._transports.default',
        'pydantic',
        'pydantic.fields',
        'pydantic_core',
        'yaml',
        'dotenv',
        # Shell detection for completions
        'shellingham',
        'shellingham.posix',
        'shellingham.nt',
        # Product modules
        'bt_cli',
        'bt_cli.cli',
        'bt_cli.core',
        'bt_cli.core.config',
        'bt_cli.core.config_file',
        'bt_cli.core.auth',
        'bt_cli.core.client',
        'bt_cli.core.output',
        'bt_cli.commands',
        'bt_cli.commands.configure',
        'bt_cli.data',
        'bt_cli.pws',
        'bt_cli.pws.client',
        'bt_cli.pws.commands',
        'bt_cli.pws.models',
        'bt_cli.entitle',
        'bt_cli.entitle.client',
        'bt_cli.entitle.commands',
        'bt_cli.entitle.models',
        'bt_cli.pra',
        'bt_cli.pra.client',
        'bt_cli.pra.commands',
        'bt_cli.pra.models',
        'bt_cli.epmw',
        'bt_cli.epmw.client',
        'bt_cli.epmw.commands',
        'bt_cli.epmw.models',
        # SSL/TLS support
        'ssl',
        'certifi',
        # Encoding support
        'encodings',
        'encodings.idna',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude test modules
        'pytest',
        'respx',
        # Exclude unnecessary modules
        'tkinter',
        'matplotlib',
        'numpy',
        'pandas',
        'PIL',
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='bt',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
