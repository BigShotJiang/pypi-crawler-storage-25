import wbcore.serializers as wb_serializers
from rest_framework.reverse import reverse
from wbcore.contrib.icons import WBIcon
from wbcore.enums import RequestType
from wbcore.metadata.configs import buttons as bt
from wbcore.metadata.configs.buttons.enums import ButtonDefaultColor
from wbcore.metadata.configs.buttons.view_config import ButtonViewConfig
from wbcore.metadata.configs.display import create_simple_display
from wbcrm.models import Account
from wbcrm.serializers import AccountRepresentationSerializer


def get_reconciliation_bulkcreate_serializer():
    class CustomSerializer(wb_serializers.Serializer):
        reconciliation_date = wb_serializers.DateField()
        accounts = wb_serializers.PrimaryKeyRelatedField(queryset=Account.objects.all())
        _accounts = AccountRepresentationSerializer(
            many=True,
            source="accounts",
            depends_on=[{"field": "reconciliation_date", "options": {}}],
            optional_get_parameters={"reconciliation_date": "aum_date"},
        )

    return CustomSerializer


class AccountReconciliationButtonViewConfig(ButtonViewConfig):
    def get_custom_buttons(self) -> set:
        if "pk" not in self.view.kwargs:
            return {
                bt.ActionButton(
                    method=RequestType.PATCH,
                    identifiers=("wbportfolio:accountreconciliationline",),
                    icon=WBIcon.FOLDERS_ADD.icon,
                    endpoint=reverse("wbportfolio:accountreconciliation-bulkcreate", args=[], request=self.request),
                    serializer=get_reconciliation_bulkcreate_serializer(),
                    instance_display=create_simple_display([["reconciliation_date", "accounts"]]),
                    label="Create Reconciliation in batch",
                    action_label="Reconciliation created",
                    description_fields="""
                    <p>Select the account and the date you wish to create reconciliation from</p>
                    <p><strong>Note:</strong> Already created reconciliation for a given account and date won't automatically trigger the notification. You need to manually notify.
                    """,
                ),
            }
        return set()

    def get_custom_instance_buttons(self):
        return {
            bt.ActionButton(
                method=RequestType.PATCH,
                color=ButtonDefaultColor.SUCCESS,
                identifiers=("wbportfolio:accountreconciliation",),
                icon=WBIcon.APPROVE.icon,
                key="agree_customer",
                label="Agree",
                action_label="Agreeing",
                description_fields="<p>After agreening to this holdings, you cannot change this reconcilation anymore!</p>",
            ),
            bt.ActionButton(
                method=RequestType.PATCH,
                color=ButtonDefaultColor.ERROR,
                identifiers=("wbportfolio:accountreconciliation",),
                icon=WBIcon.DENY.icon,
                key="disagree_customer",
                label="Communicate Differences",
                action_label="Communicating Differences",
                description_fields="<p>After disagreeing with this holdings, someone will reach out to you do discuss the differences.</p>",
            ),
            bt.ActionButton(
                method=RequestType.PATCH,
                color=ButtonDefaultColor.ERROR,
                identifiers=("wbportfolio:accountreconciliationline", "wbportfolio:accountreconciliation"),
                icon=WBIcon.REFRESH.icon,
                key="recalculate",
                label="Recalculate",
                action_label="Recalculating",
                description_fields="<p>After confirming, the Reconciliation will recompute 'Our Calculations'</p>",
            ),
            bt.ActionButton(
                method=RequestType.PATCH,
                color=ButtonDefaultColor.WARNING,
                identifiers=("wbportfolio:accountreconciliationline",),
                icon=WBIcon.MAIL.icon,
                key="notify",
                label="Notify Reconciliation Managers",
                action_label="Notifying",
                description_fields="<p>After confirming the reconciliation managers of this account reconciliation will be notified.</p>",
            ),
            bt.WidgetButton(key="claims", label="Show Subscriptions/Redemptions", icon=WBIcon.TRADE.icon, weight=200),
            bt.WidgetButton(
                key="add-claim", label="Add Subscription/Redemption", icon=WBIcon.ADD.icon, new_mode=True, weight=300
            ),
        }


class AccountReconciliationLineButtonViewConfig(ButtonViewConfig):
    def get_custom_list_instance_buttons(self):
        return {
            bt.WidgetButton(key="product-claims", label="Show Subscriptions/Redemptions", icon=WBIcon.TRADE.icon),
            bt.WidgetButton(
                key="add-product-claim", label="Add Subscription/Redemption", icon=WBIcon.ADD.icon, new_mode=True
            ),
        }
