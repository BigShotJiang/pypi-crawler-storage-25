from rest_framework.reverse import reverse
from wbcore.contrib.icons import WBIcon
from wbcore.enums import RequestType
from wbcore.metadata.configs import buttons as bt
from wbcore.metadata.configs.buttons.view_config import ButtonViewConfig
from wbcore.metadata.configs.display import create_simple_display
from wbfdm.viewsets.configs.buttons.instruments import InstrumentButtonViewConfig

from wbportfolio.models import Product
from wbportfolio.serializers.products import CreateProductSerializer


class ProductButtonConfig(ButtonViewConfig):
    def get_custom_buttons(self) -> set:
        if "pk" not in self.view.kwargs:
            return {
                bt.ActionButton(
                    method=RequestType.POST,
                    identifiers=("wbportfolio:product",),
                    endpoint=reverse("wbportfolio:product-createproduct", request=self.request),
                    icon=WBIcon.FOLDERS_ADD.icon,
                    label="Create Product",
                    description_fields="""
                                <p>Merge the custodian <strong>{{name}}</strong> with another custodian in the list bellow</p>
                                """,
                    serializer=CreateProductSerializer,
                    action_label="Merge",
                    title="Create Product",
                    instance_display=create_simple_display(
                        [
                            ["name", "name", "inception_date"],
                            ["isin", "isin", "ticker"],
                            ["currency", "bank", "bank"],
                            ["management_fees", "issuer_fees", "performance_fees"],
                            ["report_class", "report_class", "."],
                            ["product_portfolio", "product_portfolio", "lookthrough_portfolio"],
                            ["replication_index_tickers", "replication_index_tickers", "replication_index_tickers"],
                        ]
                    ),
                )
            }
        return set()

    def get_custom_list_instance_buttons(self):
        return self.get_custom_instance_buttons()

    def get_custom_instance_buttons(self):
        buttons = [
            bt.DropDownButton(
                label="Commission",
                icon=WBIcon.UNFOLD.icon,
                buttons=(
                    bt.WidgetButton(key="claims", label="Claims"),
                    bt.WidgetButton(key="aum", label="AUM per account"),
                ),
            ),
            *InstrumentButtonViewConfig(self.view, self.request, self.instance).get_custom_instance_buttons(),
            bt.DropDownButton(
                label="Risk Management",
                icon=WBIcon.UNFOLD.icon,
                buttons=[
                    bt.WidgetButton(
                        key="risk_rules",
                        label="Rules",
                        icon=WBIcon.CONFIGURE.icon,
                    ),
                    bt.WidgetButton(
                        key="risk_incidents",
                        label="Incidents",
                        icon=WBIcon.WARNING.icon,
                    ),
                ],
            ),
        ]
        if product_id := self.view.kwargs.get("pk", None):
            product = Product.objects.get(id=product_id)
            report_buttons = []
            for report in product.reports.filter(is_active=True):
                tmp_buttons = []
                if primary_version := report.primary_version:
                    tmp_buttons.append(
                        bt.HyperlinkButton(
                            label="Public Report",
                            endpoint=reverse(
                                "public_report:report_version", args=[primary_version.lookup], request=self.request
                            ),
                        ),
                    )
                    if self.request.user.is_internal or self.request.user.is_superuser:
                        tmp_buttons.append(
                            bt.WidgetButton(
                                label="Widget",
                                endpoint=reverse("wbreport:report-detail", args=[report.id], request=self.request),
                            ),
                        )
                if tmp_buttons:
                    report_buttons.append(bt.DropDownButton(label=str(report), buttons=tmp_buttons))
            if report_buttons:
                buttons.append(bt.DropDownButton(label="Reports", buttons=report_buttons))

        return set(buttons)


class ProductCustomerButtonConfig(ButtonViewConfig):
    def get_custom_list_instance_buttons(self):
        return {
            bt.WidgetButton(
                key="historical-chart",
                label="Historical Chart",
                icon=WBIcon.STATS.icon,
            )
        }

    def get_custom_instance_buttons(self):
        return self.get_custom_list_instance_buttons()
