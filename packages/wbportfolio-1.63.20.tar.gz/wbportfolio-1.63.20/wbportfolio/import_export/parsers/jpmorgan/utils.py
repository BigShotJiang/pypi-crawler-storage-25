def parse_bbg_ticker(raw_ticker: str) -> tuple[str, str, str | None]:
    bbg_tickers = raw_ticker.split(" ")
    exchange = None
    if len(bbg_tickers) == 2:
        ticker = bbg_tickers[0]
        instrument_type = bbg_tickers[1]
    elif len(bbg_tickers) == 3:
        ticker = bbg_tickers[0]
        exchange = bbg_tickers[1]
        instrument_type = bbg_tickers[2]
    else:
        raise ValueError("Incorect Bloomberg ticker format")
    return ticker, instrument_type, exchange
