from decimal import Decimal
from unittest.mock import patch

import pytest
from django.contrib.contenttypes.models import ContentType
from pandas._libs.tslibs.offsets import BDay
from wbreport.models import Report

from wbportfolio.models import (
    AssetPosition,
    FeeProductPercentage,
    Index,
    InstrumentPortfolioThroughModel,
    Order,
    OrderProposal,
    Portfolio,
    PortfolioPortfolioThroughModel,
    Product,
)
from wbportfolio.models.asset import adjust_assets
from wbportfolio.models.orders.orders import adjust_orders
from wbportfolio.models.utils import get_adjusted_shares
from wbportfolio.models.workflow import adjust_quote, create_product


def test_get_adjusted_shares():
    assert get_adjusted_shares(Decimal("150"), Decimal("100"), Decimal("200")) == Decimal("75")


@pytest.mark.django_db
@patch.object(Order, "_get_price")
def test_adjust_orders(mock_get_price, weekday, order_factory, instrument_factory):
    mock_get_price.return_value = (Decimal("100"), Decimal("0"))
    old_quote = instrument_factory.create()
    new_quote = instrument_factory.create()
    o1 = order_factory.create(
        underlying_instrument=old_quote, order_proposal__trade_date=weekday, price=Decimal("100"), shares=Decimal("10")
    )
    o2 = order_factory.create(
        underlying_instrument=old_quote, order_proposal__trade_date=weekday, price=Decimal("100"), shares=Decimal("20")
    )
    adjust_orders(Order.objects.filter(underlying_instrument=old_quote), new_quote, force_share_adjustment=True)

    o1.refresh_from_db()
    o2.refresh_from_db()

    assert o1.underlying_instrument == new_quote
    assert o2.underlying_instrument == new_quote
    assert o1.price == Decimal("100")
    assert o2.price == Decimal("100")
    assert o1.shares == Decimal("10")
    assert o2.shares == Decimal("20")

    mock_get_price.return_value = (Decimal("200"), Decimal("0"))
    adjust_orders(Order.objects.filter(underlying_instrument=new_quote), old_quote, force_share_adjustment=True)

    o1.refresh_from_db()
    o2.refresh_from_db()

    assert o1.underlying_instrument == old_quote
    assert o2.underlying_instrument == old_quote
    assert o1.price == Decimal("200")
    assert o2.price == Decimal("200")
    assert o1.shares == Decimal("5")
    assert o2.shares == Decimal("10")


@pytest.mark.django_db
def test_adjust_assets(weekday, asset_position_factory, instrument_factory, instrument_price_factory):
    old_quote = instrument_factory.create()
    new_quote = instrument_factory.create()
    old_quote_price = instrument_price_factory.create(
        instrument=old_quote, net_value=Decimal("100"), date=weekday, calculated=False
    )
    new_quote_price = instrument_price_factory.create(
        instrument=new_quote, net_value=Decimal("100"), date=weekday, calculated=False
    )

    a1 = asset_position_factory.create(
        underlying_quote=old_quote, date=weekday, initial_price=Decimal("100"), initial_shares=Decimal("10")
    )
    a2 = asset_position_factory.create(
        underlying_quote=old_quote, date=weekday, initial_price=Decimal("100"), initial_shares=Decimal("20")
    )
    adjust_assets(AssetPosition.objects.filter(underlying_quote=old_quote), new_quote)

    a1.refresh_from_db()
    a2.refresh_from_db()

    assert a1.underlying_quote == new_quote
    assert a2.underlying_quote == new_quote
    assert a1.underlying_quote_price == new_quote_price
    assert a2.underlying_quote_price == new_quote_price
    assert a1.initial_price == Decimal("100")
    assert a2.initial_price == Decimal("100")
    assert a1.initial_shares == Decimal("10")
    assert a2.initial_shares == Decimal("20")

    old_quote_price.net_value = new_quote_price.net_value = Decimal("200")
    old_quote_price.save()
    new_quote_price.save()

    adjust_assets(AssetPosition.objects.filter(underlying_quote=new_quote), old_quote, force_share_adjustment=True)

    a1.refresh_from_db()
    a2.refresh_from_db()

    assert a1.underlying_quote == old_quote
    assert a2.underlying_quote == old_quote
    assert a1.underlying_quote_price == old_quote_price
    assert a2.underlying_quote_price == old_quote_price
    assert a1.initial_price == Decimal("200")
    assert a2.initial_price == Decimal("200")
    assert a1.initial_shares == Decimal("5")
    assert a2.initial_shares == Decimal("10")


@pytest.mark.django_db
@patch("wbportfolio.models.workflow.adjust_assets")
@patch("wbportfolio.models.workflow.adjust_orders")
@patch.object(OrderProposal, "replay")
def test_adjust_quote(mock_replay, mock_adjust_orders, mock_adjust_assets, weekday, order_factory, instrument_factory):
    old_quote = instrument_factory.create()
    new_quote = instrument_factory.create()
    o1 = order_factory.create(  # noqa: F841
        underlying_instrument=old_quote, order_proposal__trade_date=weekday, price=Decimal("100"), shares=Decimal("10")
    )
    o2 = order_factory.create(  # noqa: F841
        underlying_instrument=old_quote,
        order_proposal__trade_date=(weekday + BDay(1)),
        price=Decimal("100"),
        shares=Decimal("10"),
    )
    o3 = order_factory.create(
        underlying_instrument=old_quote,
        order_proposal__trade_date=(weekday + BDay(1)),
        price=Decimal("100"),
        shares=Decimal("10"),
    )
    adjust_quote(
        old_quote,
        new_quote,
        adjust_after=weekday,
        only_portfolios=Portfolio.objects.filter(id=o3.order_proposal.portfolio.id),
    )

    mock_adjust_assets.asser_called_once()
    assert set(mock_adjust_assets.call_args[0][0]) == set(AssetPosition.objects.none())
    assert mock_adjust_assets.call_args[0][1] == new_quote

    mock_adjust_orders.assert_called_once()
    assert set(mock_adjust_orders.call_args[0][0]) == set(Order.objects.filter(id=o3.id))
    assert mock_adjust_orders.call_args[0][1] == new_quote

    mock_replay.assert_called_once_with(reapply_order_proposal=True)


@pytest.mark.django_db
class TestProductCreation:
    def test_create_product_creates_product_and_updates_existing(self, currency, company_factory, weekday):
        bank = company_factory.create()

        product = create_product("My product", "ISIN0000001", "AAA", currency, bank, weekday)

        assert product.isin == "ISIN0000001"
        assert product.name == "My product"
        assert product.ticker == "AAA"
        assert product.currency == currency
        assert product.bank == bank
        assert Product.objects.filter(isin="ISIN0000001").count() == 1

        updated = create_product("New title", "ISIN0000001", "BBB", currency, bank, weekday)

        assert updated.id == product.id
        product.refresh_from_db()
        assert product.name == "New title"
        assert product.ticker == "BBB"

    def test_create_product_creates_fees_only_when_nonzero(self, currency, company_factory, weekday):
        bank = company_factory.create()

        product = create_product(
            "Fee product",
            "ISIN0000002",
            "FEE",
            currency,
            bank,
            weekday,
            management_fees=0.012,
            issuer_fees=0.05,
            performance_fees=0.15,
        )

        fees = FeeProductPercentage.objects.filter(product=product)
        assert fees.count() == 3
        assert fees.filter(type=FeeProductPercentage.Type.MANAGEMENT, percent=0.012).exists()
        assert fees.filter(type=FeeProductPercentage.Type.BANK, percent=0.05).exists()
        assert fees.filter(type=FeeProductPercentage.Type.PERFORMANCE, percent=0.15).exists()

    def test_create_product_does_not_create_fee_when_zero(self, currency, company_factory, weekday):
        bank = company_factory.create()

        product = create_product("No fee product", "ISIN0000003", "NF", currency, bank, weekday)

        assert FeeProductPercentage.objects.filter(product=product).count() == 0

    def test_create_product_creates_portfolio_and_link(self, currency, company_factory, weekday):
        bank = company_factory.create()

        product = create_product("Portfolio product", "ISIN0000004", "PTF", currency, bank, weekday)

        assert product.portfolio is not None
        assert product.portfolio.name == f"Product Portfolio product - {bank} - ISIN0000004"
        assert product.portfolio.currency == currency
        assert product.portfolio.is_lookthrough is False
        assert InstrumentPortfolioThroughModel.objects.filter(instrument=product, portfolio=product.portfolio).exists()

    def test_create_product_creates_lookthrough_structure(self, currency, company_factory, weekday):
        bank = company_factory.create()

        product = create_product(
            "Lookthrough product",
            "ISIN0000005",
            "IDX",
            currency,
            bank,
            weekday,
            replication_ownership=[("SPX", 1.0, [])],
        )

        portfolio = product.portfolio
        assert portfolio is not None
        assert portfolio.is_lookthrough is True
        assert "Look-Through" in portfolio.name

        dependency = PortfolioPortfolioThroughModel.objects.get(portfolio=portfolio)
        assert dependency.type == PortfolioPortfolioThroughModel.Type.LOOK_THROUGH
        assert dependency.dependency_portfolio is not None

        primary_dependency = PortfolioPortfolioThroughModel.objects.get(
            portfolio=dependency.dependency_portfolio, type=PortfolioPortfolioThroughModel.Type.HIERARCHICAL
        )

        index = Index.objects.get(ticker="SPX")
        assert InstrumentPortfolioThroughModel.objects.filter(
            instrument=index, portfolio=primary_dependency.dependency_portfolio
        ).exists()

    def test_create_product_creates_factsheet_report_when_report_class_provided(
        self, currency, company_factory, report_class, report_factory, weekday
    ):
        bank = company_factory.create()
        report_factory.create(namespace="factsheet", parent_report=None)
        product = create_product(
            "Factsheet product",
            "ISIN0000006",
            "RPT",
            currency,
            bank,
            weekday,
            report_class=report_class,
        )

        assert product is not None

        report_ct = ContentType.objects.get_for_model(Product)
        assert Report.objects.filter(
            content_type=report_ct,
            object_id=product.id,
        ).exists()
