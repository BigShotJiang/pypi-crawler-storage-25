class RoutingError(Exception):
    def __init__(self, errors):
        # messages: a list of strings
        super().__init__()  # You can pass a summary to the base Exception
        self.errors = errors

    def __str__(self):
        return str(self.errors)
