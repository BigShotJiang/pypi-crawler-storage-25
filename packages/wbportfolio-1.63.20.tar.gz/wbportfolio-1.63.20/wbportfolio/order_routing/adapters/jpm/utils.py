import pandas as pd


def convert_results_to_html(results: list) -> str:
    df = pd.DataFrame(results)
    return df.to_html(
        index=False,
        classes="table",  # Bootstrap-style
        border=1,
        na_rep="—",  # For empty fields
    )
