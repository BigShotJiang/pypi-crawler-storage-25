"""Nix store and profile forwarding into containers."""

from __future__ import annotations

from pathlib import Path


def nix_mounts(host_user: str) -> list[tuple[str, str, str]]:
    """Return (host_path, container_path, mode) tuples for nix mounts.

    Uses unresolved symlink-tree paths so they survive nixos-rebuild + GC.
    """
    mounts: list[tuple[str, str, str]] = []

    nix_store = Path("/nix/store")
    if nix_store.is_dir():
        mounts.append((str(nix_store), str(nix_store), "ro"))

    profile = Path(f"/etc/profiles/per-user/{host_user}")
    if profile.exists():
        mounts.append((str(profile), str(profile), "ro"))

    sys_sw = Path("/run/current-system")
    if sys_sw.exists():
        mounts.append((str(sys_sw), str(sys_sw), "ro"))

    return mounts


def nix_path_entries(host_user: str) -> list[str]:
    """Return PATH entries for nix binaries (unresolved symlink paths)."""
    entries: list[str] = []

    profile_bin = Path(f"/etc/profiles/per-user/{host_user}/bin")
    if profile_bin.exists():
        entries.append(str(profile_bin))

    sys_bin = Path("/run/current-system/sw/bin")
    if sys_bin.exists():
        entries.append(str(sys_bin))

    return entries
