"""Dashboard FastAPI application."""

import hashlib
import os
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlencode

from fastapi import FastAPI, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from qualito.dashboard.admin_routes import router as admin_router
from qualito.dashboard.api import router
from qualito.dashboard.auth_routes import router as auth_router
from qualito.dashboard.billing_routes import router as billing_router
from qualito.dashboard.email_webhook import router as email_webhook_router
from qualito.dashboard.mcp_oauth import (
    QualitOAuthProvider,
    QualitTokenVerifier,
    _AUTH_ERROR_HTML,
    _AUTH_FORM_HTML,
    _pending_auths,
    _auth_codes,
    AuthCodeData,
)
from qualito.dashboard.mcp_routes import create_mcp_app, mcp_lifespan
from qualito.dashboard.setup_routes import router as setup_router

try:
    from slowapi import _rate_limit_exceeded_handler
    from slowapi.errors import RateLimitExceeded

    _slowapi_available = True
except ImportError:
    _slowapi_available = False

# Default CORS origins for local development
_DEFAULT_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:8090",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:8090",
]

# Shared OAuth provider instances
_oauth_provider = QualitOAuthProvider()
_token_verifier = QualitTokenVerifier()


def _get_cors_origins() -> list[str]:
    """Build CORS origins from CORS_ORIGINS env var + defaults."""
    env_origins = os.environ.get("CORS_ORIGINS", "")
    if env_origins:
        return [o.strip() for o in env_origins.split(",") if o.strip()]
    return _DEFAULT_ORIGINS


def _get_api_url() -> str:
    """Get the API base URL."""
    return os.environ.get("API_URL", "https://api.qualito.ai")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    # Create MCP ASGI app with OAuth token verification
    mcp_app = create_mcp_app(token_verifier=_token_verifier)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Init DB
        from qualito.core.db import init_db
        init_db()
        # Migrate: add missing columns to existing tables (SA create_all doesn't ALTER)
        from qualito.core.db import get_sa_connection
        conn = get_sa_connection()
        try:
            from sqlalchemy import text
            migrations = [
                "ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR DEFAULT 'user'",
                "ALTER TABLE users ADD COLUMN IF NOT EXISTS suspended BOOLEAN DEFAULT FALSE",
                "ALTER TABLE users ADD COLUMN IF NOT EXISTS stripe_subscription_id VARCHAR",
                "ALTER TABLE users ADD COLUMN IF NOT EXISTS marketing_consent BOOLEAN DEFAULT FALSE",
                "ALTER TABLE users ADD COLUMN IF NOT EXISTS marketing_consent_date VARCHAR",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id)",
                "ALTER TABLE email_logs ADD COLUMN IF NOT EXISTS delivery_status VARCHAR",
                "ALTER TABLE email_logs ADD COLUMN IF NOT EXISTS delivery_updated_at VARCHAR",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS session_type VARCHAR DEFAULT 'unknown'",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS entrypoint VARCHAR",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS claude_version VARCHAR",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS session_name VARCHAR",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS has_subagents BOOLEAN DEFAULT FALSE",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS subagent_count INTEGER DEFAULT 0",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS error_count INTEGER DEFAULT 0",
                "ALTER TABLE runs ADD COLUMN IF NOT EXISTS tool_count INTEGER DEFAULT 0",
            ]
            for sql in migrations:
                try:
                    conn.execute(text(sql))
                except Exception:
                    pass  # Column already exists or SQLite doesn't support IF NOT EXISTS
            conn.commit()
        except Exception:
            pass
        finally:
            conn.close()
        # Bootstrap admin from ADMIN_EMAIL env var
        admin_email = os.environ.get("ADMIN_EMAIL")
        if admin_email:
            from qualito.core.db import get_sa_connection, users_table
            conn = get_sa_connection()
            try:
                from sqlalchemy import select
                row = conn.execute(
                    select(users_table.c.id, users_table.c.role)
                    .where(users_table.c.email == admin_email.lower().strip())
                ).mappings().fetchone()
                if row and row["role"] != "admin":
                    conn.execute(
                        users_table.update()
                        .where(users_table.c.id == row["id"])
                        .values(role="admin")
                    )
                    conn.commit()
            except Exception:
                pass
            finally:
                conn.close()
        # Start MCP session manager
        async with mcp_lifespan():
            yield

    app = FastAPI(
        title="Qualito Dashboard",
        description="Qualito — Quality metrics for AI-assisted development",
        version="0.1.0",
        lifespan=lifespan,
    )

    # CORS — configurable via CORS_ORIGINS env var
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_get_cors_origins(),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Rate limiting (if slowapi is available)
    if _slowapi_available:
        from qualito.dashboard.auth_routes import limiter as _limiter

        if _limiter is not None:
            app.state.limiter = _limiter
            app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    # Mount routers
    app.include_router(admin_router)
    app.include_router(auth_router)
    app.include_router(billing_router)
    app.include_router(email_webhook_router)
    app.include_router(setup_router)
    app.include_router(router)

    # Health check — must be defined BEFORE catch-all static mount
    @app.get("/health")
    def health():
        """Health check."""
        db_path_env = os.environ.get("QUALITO_DIR")
        if db_path_env:
            db_exists = (Path(db_path_env) / "qualito.db").exists()
        else:
            db_exists = (Path.cwd() / ".qualito" / "qualito.db").exists()

        return {"status": "ok", "db_exists": db_exists}

    # ------------------------------------------------------------------
    # OAuth 2.0 endpoints for MCP authentication (root level)
    # ------------------------------------------------------------------

    api_url = _get_api_url()

    @app.get("/.well-known/oauth-protected-resource")
    def oauth_protected_resource():
        """RFC 9470 — tells clients where to find the authorization server."""
        return JSONResponse({
            "resource": f"{api_url}/mcp/",
            "authorization_servers": [f"{api_url}"],
        })

    @app.get("/.well-known/oauth-protected-resource/{path:path}")
    def oauth_protected_resource_path(path: str):
        """Path-insertion variant for MCP URL discovery."""
        return JSONResponse({
            "resource": f"{api_url}/mcp/",
            "authorization_servers": [f"{api_url}"],
        })

    @app.get("/.well-known/oauth-authorization-server")
    @app.get("/.well-known/oauth-authorization-server/{path:path}")
    def oauth_authorization_server_metadata(request: Request):
        """OAuth 2.0 Authorization Server Metadata (RFC 8414)."""
        return JSONResponse({
            "issuer": f"{api_url}",
            "authorization_endpoint": f"{api_url}/authorize",
            "token_endpoint": f"{api_url}/token",
            "registration_endpoint": f"{api_url}/register",
            "response_types_supported": ["code"],
            "grant_types_supported": ["authorization_code"],
            "token_endpoint_auth_methods_supported": [
                "client_secret_post", "client_secret_basic"
            ],
            "code_challenge_methods_supported": ["S256"],
        })

    @app.post("/register")
    async def oauth_register(request: Request):
        """Dynamic client registration (RFC 7591)."""
        import uuid
        body = await request.json()
        client_id = str(uuid.uuid4())
        client_secret = secrets.token_hex(32)
        from mcp.server.auth.provider import OAuthClientInformationFull
        from pydantic import AnyUrl
        client_info = OAuthClientInformationFull(
            client_id=client_id,
            client_secret=client_secret,
            redirect_uris=body.get("redirect_uris", []),
            client_name=body.get("client_name"),
            grant_types=body.get("grant_types", ["authorization_code"]),
            response_types=body.get("response_types", ["code"]),
            token_endpoint_auth_method=body.get(
                "token_endpoint_auth_method", "client_secret_post"
            ),
        )
        await _oauth_provider.register_client(client_info)
        return JSONResponse({
            "client_id": client_id,
            "client_secret": client_secret,
            "client_name": body.get("client_name"),
            "redirect_uris": body.get("redirect_uris", []),
            "grant_types": body.get("grant_types", ["authorization_code"]),
            "response_types": body.get("response_types", ["code"]),
            "token_endpoint_auth_method": body.get(
                "token_endpoint_auth_method", "client_secret_post"
            ),
        }, status_code=201)

    @app.get("/authorize")
    async def oauth_authorize(request: Request):
        """OAuth authorization endpoint — redirects to API key form."""
        from mcp.server.auth.provider import AuthorizationParams
        from pydantic import AnyUrl

        params = dict(request.query_params)
        client_id = params.get("client_id")
        redirect_uri = params.get("redirect_uri")
        code_challenge = params.get("code_challenge")
        state = params.get("state")

        if not client_id or not redirect_uri or not code_challenge:
            return JSONResponse(
                {"error": "invalid_request", "error_description": "Missing required parameters"},
                status_code=400,
            )

        client = await _oauth_provider.get_client(client_id)
        if not client:
            return JSONResponse(
                {"error": "invalid_client", "error_description": "Unknown client"},
                status_code=400,
            )

        auth_params = AuthorizationParams(
            state=state,
            scopes=params.get("scope", "").split() if params.get("scope") else None,
            code_challenge=code_challenge,
            redirect_uri=AnyUrl(redirect_uri),
            redirect_uri_provided_explicitly=True,
        )
        form_url = await _oauth_provider.authorize(client, auth_params)
        return RedirectResponse(form_url, status_code=302)

    @app.get("/mcp-authorize", response_class=HTMLResponse)
    async def mcp_authorize_form(state: str = ""):
        """Show API key entry form for MCP authorization."""
        if state not in _pending_auths:
            return HTMLResponse(
                "<h1>Invalid or expired authorization request.</h1>"
                "<p>Please try connecting again from Claude Code.</p>",
                status_code=400,
            )
        html = _AUTH_FORM_HTML.replace("{state}", state).replace("{error_html}", "")
        return HTMLResponse(html)

    @app.post("/mcp-authorize-callback")
    async def mcp_authorize_callback(state: str = Form(""), api_key: str = Form("")):
        """Validate API key and redirect with authorization code."""
        pending = _pending_auths.get(state)
        if not pending:
            return HTMLResponse(
                "<h1>Invalid or expired authorization request.</h1>",
                status_code=400,
            )

        # Validate API key against database
        from qualito.core.db import get_sa_connection
        from qualito.dashboard.auth import verify_api_key

        conn = get_sa_connection()
        try:
            user = verify_api_key(conn, api_key)
        finally:
            conn.close()

        if not user:
            error_html = _AUTH_ERROR_HTML.replace("{message}", "Invalid API key.")
            html = _AUTH_FORM_HTML.replace("{state}", state).replace(
                "{error_html}", error_html
            )
            return HTMLResponse(html, status_code=200)

        if user.get("suspended"):
            error_html = _AUTH_ERROR_HTML.replace("{message}", "Account is suspended.")
            html = _AUTH_FORM_HTML.replace("{state}", state).replace(
                "{error_html}", error_html
            )
            return HTMLResponse(html, status_code=200)

        # Generate authorization code
        code = secrets.token_urlsafe(32)
        _auth_codes[code] = AuthCodeData(
            code=code,
            client_id=pending.client_id,
            redirect_uri=pending.redirect_uri,
            redirect_uri_provided_explicitly=pending.redirect_uri_provided_explicitly,
            code_challenge=pending.code_challenge,
            user_id=user["id"],
            scopes=pending.scopes or [],
        )
        _pending_auths.pop(state, None)

        # Redirect back to client with authorization code
        redirect_params = {"code": code}
        if pending.state:
            redirect_params["state"] = pending.state
        redirect_url = f"{pending.redirect_uri}?{urlencode(redirect_params)}"
        return RedirectResponse(redirect_url, status_code=302)

    @app.post("/token")
    async def oauth_token(request: Request):
        """OAuth token endpoint — exchanges authorization code for access token."""
        # Parse form or JSON body
        content_type = request.headers.get("content-type", "")
        if "application/x-www-form-urlencoded" in content_type:
            body = dict(await request.form())
        else:
            body = await request.json()

        grant_type = body.get("grant_type")
        if grant_type != "authorization_code":
            return JSONResponse(
                {"error": "unsupported_grant_type"}, status_code=400
            )

        code = body.get("code")
        client_id = body.get("client_id")
        client_secret = body.get("client_secret")
        code_verifier = body.get("code_verifier")

        # Support client_secret_basic (Authorization: Basic base64(client_id:client_secret))
        if not client_id:
            import base64 as b64
            auth_header = request.headers.get("authorization", "")
            if auth_header.startswith("Basic "):
                try:
                    decoded = b64.b64decode(auth_header[6:]).decode()
                    client_id, client_secret = decoded.split(":", 1)
                except Exception:
                    pass

        if not code or not client_id:
            return JSONResponse(
                {"error": "invalid_request", "error_description": "Missing code or client_id"},
                status_code=400,
            )

        # Validate client
        client = await _oauth_provider.get_client(client_id)
        if not client:
            return JSONResponse({"error": "invalid_client"}, status_code=401)

        if client.client_secret and client.client_secret != client_secret:
            return JSONResponse({"error": "invalid_client"}, status_code=401)

        # Load and validate authorization code
        auth_code = await _oauth_provider.load_authorization_code(client, code)
        if not auth_code:
            return JSONResponse(
                {"error": "invalid_grant", "error_description": "Invalid or expired code"},
                status_code=400,
            )

        # PKCE verification
        if code_verifier:
            import base64
            sha256 = hashlib.sha256(code_verifier.encode()).digest()
            hashed = base64.urlsafe_b64encode(sha256).decode().rstrip("=")
            if hashed != auth_code.code_challenge:
                return JSONResponse(
                    {"error": "invalid_grant", "error_description": "Invalid code_verifier"},
                    status_code=400,
                )

        # Exchange for access token
        token = await _oauth_provider.exchange_authorization_code(client, auth_code)
        return JSONResponse(token.model_dump(exclude_none=True))

    # ------------------------------------------------------------------
    # MCP server mount
    # ------------------------------------------------------------------

    # Redirect /mcp → /mcp/ (Starlette mount requires trailing slash)
    @app.api_route("/mcp", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
    async def mcp_redirect():
        return RedirectResponse(url="/mcp/", status_code=307)

    # Mount remote MCP server at /mcp/
    app.mount("/mcp", mcp_app)

    # Serve static files for production frontend build (if exists)
    frontend_dir = Path(__file__).parent / "frontend" / "build"
    if frontend_dir.is_dir():
        from fastapi.staticfiles import StaticFiles
        app.mount("/", StaticFiles(directory=str(frontend_dir), html=True), name="frontend")

    return app
