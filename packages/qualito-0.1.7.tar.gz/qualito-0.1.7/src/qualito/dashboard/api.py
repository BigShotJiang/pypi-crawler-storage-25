"""Dashboard API router.

All endpoints read from the local .qualito/qualito.db via core modules.
"""

import json
import os
import re
from datetime import datetime, timedelta
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import and_, case, func, select

from qualito.config import QualityConfig, load_config
from qualito.core.db import (
    api_keys_table,
    conversations_table,
    evaluations_table,
    experiment_comparisons_table,
    experiments_table,
    file_activity_table,
    get_conversation,
    get_engine,
    get_incident,
    get_incidents,
    get_run,
    incidents_table,
    init_db,
    runs_table,
    tool_calls_table,
    users_table,
)
from qualito.dashboard.auth import get_current_user, user_has_plan

router = APIRouter(prefix="/api")


# ---------------------------------------------------------------------------
# DB resolution
# ---------------------------------------------------------------------------


def _resolve_db_path() -> Path:
    """Resolve the DB path from env or cwd."""
    qualito_dir = os.environ.get("QUALITO_DIR")
    if qualito_dir:
        return Path(qualito_dir) / "qualito.db"
    return Path.cwd() / ".qualito" / "qualito.db"


def _get_conn():
    """Get a SA Connection. Raises 503 if DB doesn't exist (SQLite only).

    When DATABASE_URL is set, uses PostgreSQL (no file check needed).
    Otherwise, resolves the SQLite path and verifies the file exists.
    """
    db_url = os.environ.get("DATABASE_URL")
    if db_url:
        engine = get_engine()
        init_db(engine)
        return engine.connect()

    db_path = _resolve_db_path()
    if not db_path.exists():
        raise HTTPException(status_code=503, detail="Qualito database not found. Run 'qualito init' first.")
    engine = get_engine(str(db_path))
    init_db(engine)
    return engine.connect()


def _since_date(days: int) -> str:
    """Return ISO date string for N days ago."""
    return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------


class TransitionRequest(BaseModel):
    status: str


class ConfigUpdate(BaseModel):
    slo_quality: float | None = None
    slo_availability: float | None = None
    slo_cost: float | None = None


class DeleteRunsRequest(BaseModel):
    workspace: str | None = None
    run_ids: list[str] | None = None


# ---------------------------------------------------------------------------
# GET /api/dashboard — hero metrics
# ---------------------------------------------------------------------------


@router.get("/dashboard")
def dashboard_hero():
    """Hero metrics for the dashboard."""
    conn = _get_conn()
    try:
        since = _since_date(30)

        r = runs_table
        e = evaluations_table

        # Average DQI (last 30 days)
        dqi_stmt = (
            select(
                func.avg(e.c.score).label("avg_dqi"),
                func.count(r.c.id.distinct()).label("run_count"),
            )
            .select_from(e.join(r, r.c.id == e.c.run_id))
            .where(and_(e.c.eval_type == "dqi", r.c.started_at >= since))
        )
        dqi_row = conn.execute(dqi_stmt).mappings().fetchone()
        avg_dqi = round(dqi_row["avg_dqi"], 4) if dqi_row["avg_dqi"] is not None else None
        run_count = dqi_row["run_count"] or 0

        # Total cost (last 30 days)
        cost_stmt = select(
            func.coalesce(func.sum(r.c.cost_usd), 0).label("total_cost")
        ).where(r.c.started_at >= since)
        cost_row = conn.execute(cost_stmt).mappings().fetchone()
        total_cost_30d = round(cost_row["total_cost"], 2)

        # Active incidents
        inc = incidents_table
        active_stmt = select(
            func.count().label("cnt")
        ).where(inc.c.status.in_(["detected", "confirmed"]))
        active_row = conn.execute(active_stmt).mappings().fetchone()
        active_incidents = active_row["cnt"]

        # SLO status
        config = load_config()
        slo_status = _compute_slo_status(conn, since, config)

        return {
            "avg_dqi": avg_dqi,
            "run_count": run_count,
            "total_cost_30d": total_cost_30d,
            "active_incidents": active_incidents,
            "slo_status": slo_status,
        }
    finally:
        conn.close()


def _compute_slo_status(conn, since: str, config: QualityConfig) -> dict:
    """Compute SLO pass/fail for quality, availability, cost."""
    r = runs_table
    e = evaluations_table

    # Total runs
    total_stmt = select(
        func.count().label("total"),
        func.sum(case((r.c.status == "completed", 1), else_=0)).label("completed"),
        func.sum(case((r.c.cost_usd < config.slo_cost, 1), else_=0)).label("under_cost"),
    ).where(r.c.started_at >= since)
    total_row = conn.execute(total_stmt).mappings().fetchone()

    total = total_row["total"] or 0
    completed = total_row["completed"] or 0
    under_cost = total_row["under_cost"] or 0

    # Quality
    quality_stmt = (
        select(
            func.count().label("total_scored"),
            func.sum(case((e.c.score >= config.slo_quality, 1), else_=0)).label("quality_ok"),
        )
        .select_from(e.join(r, r.c.id == e.c.run_id))
        .where(and_(e.c.eval_type == "dqi", r.c.started_at >= since))
    )
    quality_row = conn.execute(quality_stmt).mappings().fetchone()

    total_scored = quality_row["total_scored"] or 0
    quality_ok = quality_row["quality_ok"] or 0

    quality_pct = (quality_ok / total_scored) if total_scored > 0 else None
    avail_pct = (completed / total) if total > 0 else None
    cost_pct = (under_cost / total) if total > 0 else None

    return {
        "quality": {
            "current": round(quality_pct, 4) if quality_pct is not None else None,
            "target": config.slo_quality,
            "pass": quality_pct is not None and quality_pct >= config.slo_quality,
        },
        "availability": {
            "current": round(avail_pct, 4) if avail_pct is not None else None,
            "target": config.slo_availability,
            "pass": avail_pct is not None and avail_pct >= config.slo_availability,
        },
        "cost": {
            "current": round(cost_pct, 4) if cost_pct is not None else None,
            "target": config.slo_cost,
            "pass": cost_pct is not None and cost_pct >= 0.80,
        },
    }


# ---------------------------------------------------------------------------
# GET /api/runs — paginated run list
# ---------------------------------------------------------------------------


@router.get("/runs")
def list_runs(
    workspace: str | None = None,
    task_type: str | None = None,
    status: str | None = None,
    since: str | None = None,
    session_type: str | None = None,
    model: str | None = None,
    has_subagents: bool | None = None,
    limit: int = Query(default=50, le=200),
    offset: int = Query(default=0, ge=0),
):
    """Paginated run list with optional filters."""
    conn = _get_conn()
    try:
        r = runs_table
        e = evaluations_table

        conditions = []
        if workspace:
            conditions.append(r.c.workspace == workspace)
        if task_type:
            conditions.append(r.c.task_type == task_type)
        if status:
            conditions.append(r.c.status == status)
        if since:
            conditions.append(r.c.started_at >= since)
        if session_type:
            conditions.append(r.c.session_type == session_type)
        if model:
            conditions.append(r.c.model == model)
        if has_subagents is not None:
            conditions.append(r.c.has_subagents == has_subagents)

        where_clause = and_(*conditions) if conditions else None

        # Count total
        count_stmt = select(func.count().label("cnt")).select_from(r)
        if where_clause is not None:
            count_stmt = count_stmt.where(where_clause)
        total_row = conn.execute(count_stmt).mappings().fetchone()
        total = total_row["cnt"]

        # Fetch page with all fields including new ones
        page_stmt = select(
            r.c.id, r.c.workspace, r.c.task, r.c.task_type, r.c.model,
            r.c.status, r.c.cost_usd, r.c.duration_ms, r.c.started_at,
            r.c.completed_at, r.c.source, r.c.session_type, r.c.entrypoint,
            r.c.claude_version, r.c.session_name, r.c.has_subagents,
            r.c.subagent_count, r.c.error_count, r.c.branch, r.c.files_changed,
        )
        if where_clause is not None:
            page_stmt = page_stmt.where(where_clause)
        page_stmt = page_stmt.order_by(r.c.started_at.desc()).limit(limit).offset(offset)
        rows = conn.execute(page_stmt).mappings().fetchall()

        # Attach DQI score to each run
        runs = []
        for row in rows:
            run = dict(row)
            dqi_row = conn.execute(
                select(e.c.score)
                .where(and_(e.c.run_id == row["id"], e.c.eval_type == "dqi"))
            ).mappings().fetchone()
            run["dqi"] = dqi_row["score"] if dqi_row else None
            # Parse files_changed JSON if present
            if run.get("files_changed"):
                try:
                    run["files_changed"] = json.loads(run["files_changed"])
                except (json.JSONDecodeError, TypeError):
                    pass
            runs.append(run)

        return {"runs": runs, "total": total}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# GET /api/runs/{run_id} — run detail
# ---------------------------------------------------------------------------


@router.get("/runs/{run_id}")
def run_detail(run_id: str):
    """Full run detail with evaluations, tool_calls, file_activity, summaries."""
    conn = _get_conn()
    try:
        run = get_run(conn, run_id)
        if not run:
            raise HTTPException(status_code=404, detail="Run not found")

        # Parse files_changed JSON if present
        if run.get("files_changed") and isinstance(run["files_changed"], str):
            try:
                run["files_changed"] = json.loads(run["files_changed"])
            except (json.JSONDecodeError, TypeError):
                pass

        # Build tool_summary: tool name -> count
        tool_summary = {}
        for tc in run.get("tool_calls", []):
            name = tc.get("tool_name", "unknown")
            tool_summary[name] = tool_summary.get(name, 0) + 1
        run["tool_summary"] = tool_summary

        # Build files_summary: file -> {action -> count}
        files_summary = {}
        for fa in run.get("file_activity", []):
            path = fa.get("file_path", "")
            action = fa.get("action", "unknown")
            if path not in files_summary:
                files_summary[path] = {}
            files_summary[path][action] = files_summary[path].get(action, 0) + 1
        run["files_summary"] = files_summary

        return run
    finally:
        conn.close()


@router.get("/runs/{run_id}/conversation")
def run_conversation(run_id: str):
    """Get condensed conversation for a run."""
    conn = _get_conn()
    try:
        # Verify run exists
        row = conn.execute(
            select(runs_table.c.id).where(runs_table.c.id == run_id)
        ).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Run not found")

        conv = get_conversation(conn, run_id)
        if not conv:
            return {"run_id": run_id, "messages": [], "message_count": 0}

        return {
            "run_id": run_id,
            "messages": conv["messages"],
            "message_count": conv["message_count"],
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# GET /api/metrics — charts data
# ---------------------------------------------------------------------------


@router.get("/metrics")
def metrics_data(
    workspace: str | None = None,
    days: int = Query(default=30, le=365),
):
    """Aggregated metrics for charts."""
    conn = _get_conn()
    try:
        since = _since_date(days)
        r = runs_table
        e = evaluations_table

        # Base conditions
        run_conditions = [r.c.started_at >= since]
        if workspace:
            run_conditions.append(r.c.workspace == workspace)

        # DQI trend by day
        dqi_stmt = (
            select(
                func.date(r.c.started_at).label("date"),
                func.avg(e.c.score).label("avg_dqi"),
            )
            .select_from(e.join(r, r.c.id == e.c.run_id))
            .where(and_(e.c.eval_type == "dqi", *run_conditions))
            .group_by(func.date(r.c.started_at))
            .order_by(func.date(r.c.started_at))
        )
        dqi_trend = conn.execute(dqi_stmt).mappings().fetchall()

        # Cost trend by day
        cost_stmt = (
            select(
                func.date(r.c.started_at).label("date"),
                func.coalesce(func.sum(r.c.cost_usd), 0).label("total_cost"),
            )
            .where(and_(*run_conditions))
            .group_by(func.date(r.c.started_at))
            .order_by(func.date(r.c.started_at))
        )
        cost_trend = conn.execute(cost_stmt).mappings().fetchall()

        # By workspace
        ws_stmt = (
            select(
                r.c.workspace,
                func.count().label("run_count"),
                func.avg(r.c.cost_usd).label("avg_cost"),
                func.sum(r.c.cost_usd).label("total_cost"),
                func.sum(case((r.c.status == "completed", 1), else_=0)).label("completed"),
            )
            .where(and_(*run_conditions))
            .group_by(r.c.workspace)
            .order_by(func.count().desc())
        )
        by_workspace = conn.execute(ws_stmt).mappings().fetchall()

        # By task type
        type_stmt = (
            select(
                r.c.task_type,
                func.count().label("run_count"),
                func.avg(r.c.cost_usd).label("avg_cost"),
                func.sum(r.c.cost_usd).label("total_cost"),
                func.sum(case((r.c.status == "completed", 1), else_=0)).label("completed"),
            )
            .where(and_(*run_conditions))
            .group_by(r.c.task_type)
            .order_by(func.count().desc())
        )
        by_task_type = conn.execute(type_stmt).mappings().fetchall()

        dqi_items = [
            {
                "date": row["date"],
                "avg_dqi": round(row["avg_dqi"], 4) if row["avg_dqi"] else None,
            }
            for row in dqi_trend
        ]
        cost_items = [
            {"date": row["date"], "total_cost": round(row["total_cost"], 2)}
            for row in cost_trend
        ]

        return {
            "dqi_trend": dqi_items,
            "cost_trend": cost_items,
            "by_workspace": [dict(row) for row in by_workspace],
            "by_task_type": [dict(row) for row in by_task_type],
        }
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Experiments
# ---------------------------------------------------------------------------


@router.get("/experiments")
def list_experiments(
    status: str | None = None,
    limit: int = Query(default=50, le=200),
):
    """List experiments."""
    conn = _get_conn()
    try:
        exp = experiments_table
        conditions = []
        if status:
            conditions.append(exp.c.status == status)

        stmt = select(
            exp.c.id, exp.c.name, exp.c.description, exp.c.suite_id,
            exp.c.status, exp.c.avg_dqi, exp.c.created_at, exp.c.completed_at,
        )
        if conditions:
            stmt = stmt.where(and_(*conditions))
        stmt = stmt.order_by(exp.c.created_at.desc()).limit(limit)

        rows = conn.execute(stmt).mappings().fetchall()
        return {"experiments": [dict(row) for row in rows]}
    finally:
        conn.close()


@router.get("/experiments/compare/{before_id}/{after_id}")
def compare_experiments_endpoint(before_id: int, after_id: int):
    """Compare two experiments."""
    conn = _get_conn()
    try:
        exp = experiments_table
        ec = experiment_comparisons_table

        before = conn.execute(
            select(exp).where(exp.c.id == before_id)
        ).mappings().fetchone()
        after = conn.execute(
            select(exp).where(exp.c.id == after_id)
        ).mappings().fetchone()

        if not before or not after:
            raise HTTPException(status_code=404, detail="Experiment not found")
        if before["status"] != "completed" or after["status"] != "completed":
            raise HTTPException(status_code=400, detail="Both experiments must be completed")

        before_tasks = json.loads(before["per_task_dqi"]) if before["per_task_dqi"] else {}
        after_tasks = json.loads(after["per_task_dqi"]) if after["per_task_dqi"] else {}

        labels = sorted(set(before_tasks.keys()) & set(after_tasks.keys()))
        per_task_delta = {}
        for label in labels:
            b, a = before_tasks[label], after_tasks[label]
            per_task_delta[label] = {"before": b, "after": a, "delta": round(a - b, 4)}

        # Check for existing comparison
        comp = conn.execute(
            select(ec).where(and_(
                ec.c.before_experiment_id == before_id,
                ec.c.after_experiment_id == after_id,
            ))
        ).mappings().fetchone()

        return {
            "before": {"id": before["id"], "name": before["name"], "avg_dqi": before["avg_dqi"]},
            "after": {"id": after["id"], "name": after["name"], "avg_dqi": after["avg_dqi"]},
            "per_task_delta": per_task_delta,
            "comparison": dict(comp) if comp else None,
        }
    finally:
        conn.close()


@router.get("/experiments/{experiment_id}")
def experiment_detail(experiment_id: int):
    """Experiment detail with per-task DQI."""
    conn = _get_conn()
    try:
        exp = experiments_table
        row = conn.execute(
            select(exp).where(exp.c.id == experiment_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Experiment not found")

        experiment = dict(row)
        experiment["per_task_dqi"] = (
            json.loads(experiment["per_task_dqi"]) if experiment["per_task_dqi"] else {}
        )
        experiment["run_ids"] = (
            json.loads(experiment["run_ids"]) if experiment["run_ids"] else []
        )
        experiment["config_snapshot"] = (
            json.loads(experiment["config_snapshot"]) if experiment["config_snapshot"] else {}
        )

        return experiment
    finally:
        conn.close()


@router.get("/experiments/{experiment_id}/transitions")
def experiment_transitions(experiment_id: int):
    """Available status transitions for an experiment."""
    conn = _get_conn()
    try:
        exp = experiments_table
        row = conn.execute(
            select(exp.c.status).where(exp.c.id == experiment_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Experiment not found")

        current = row["status"]
        transitions_map = {
            "running": ["completed", "failed"],
            "completed": ["archived"],
            "failed": ["running", "archived"],
            "archived": [],
        }
        return {
            "current_status": current,
            "available_transitions": transitions_map.get(current, []),
        }
    finally:
        conn.close()


@router.post("/experiments/{experiment_id}/transition")
def experiment_transition(experiment_id: int, body: TransitionRequest):
    """Transition an experiment's status."""
    conn = _get_conn()
    try:
        exp = experiments_table
        row = conn.execute(
            select(exp.c.status).where(exp.c.id == experiment_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Experiment not found")

        current = row["status"]
        transitions_map = {
            "running": ["completed", "failed"],
            "completed": ["archived"],
            "failed": ["running", "archived"],
            "archived": [],
        }
        allowed = transitions_map.get(current, [])

        if body.status not in allowed:
            raise HTTPException(
                status_code=400,
                detail=f"Cannot transition from '{current}' to '{body.status}'. "
                       f"Allowed: {allowed}",
            )

        update_values = {"status": body.status}
        if body.status == "completed":
            update_values["completed_at"] = datetime.now().isoformat()

        conn.execute(
            exp.update().where(exp.c.id == experiment_id).values(**update_values)
        )
        conn.commit()

        return {"id": experiment_id, "status": body.status}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Incidents
# ---------------------------------------------------------------------------


@router.get("/incidents/summary")
def incidents_summary():
    """Incident counts by severity."""
    conn = _get_conn()
    try:
        inc = incidents_table
        rows = conn.execute(
            select(
                inc.c.severity,
                func.count().label("count"),
            )
            .where(inc.c.status.in_(["detected", "confirmed"]))
            .group_by(inc.c.severity)
        ).mappings().fetchall()

        summary = {row["severity"]: row["count"] for row in rows}
        total = sum(summary.values())

        return {"total": total, "by_severity": summary}
    finally:
        conn.close()


@router.get("/incidents/slo")
def incidents_slo():
    """SLO compliance data."""
    conn = _get_conn()
    try:
        config = load_config()
        since = _since_date(30)
        slo_status = _compute_slo_status(conn, since, config)
        return slo_status
    finally:
        conn.close()


@router.get("/incidents")
def list_incidents_endpoint(
    workspace: str | None = None,
    status: str | None = None,
    severity: str | None = None,
    limit: int = Query(default=50, le=200),
):
    """List incidents with optional filters."""
    conn = _get_conn()
    try:
        rows = get_incidents(
            conn,
            workspace=workspace,
            status=status,
            severity=severity,
            limit=limit,
        )
        return {"incidents": rows}
    finally:
        conn.close()


@router.get("/incidents/{incident_id}")
def incident_detail(incident_id: int):
    """Incident detail with events."""
    conn = _get_conn()
    try:
        incident = get_incident(conn, incident_id)
        if not incident:
            raise HTTPException(status_code=404, detail="Incident not found")
        return incident
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------


@router.get("/config")
def get_config():
    """Current Qualito configuration."""
    config = load_config()
    return {
        "db_path": str(config.db_path),
        "workspace": config.workspace,
        "slo_quality": config.slo_quality,
        "slo_availability": config.slo_availability,
        "slo_cost": config.slo_cost,
        "templates_dir": str(config.templates_dir) if config.templates_dir else None,
    }


@router.put("/config")
def update_config(body: ConfigUpdate):
    """Update SLO targets in .qualito/config.toml."""
    qualito_dir = os.environ.get("QUALITO_DIR")
    if qualito_dir:
        config_path = Path(qualito_dir) / "config.toml"
    else:
        config_path = Path.cwd() / ".qualito" / "config.toml"

    if not config_path.exists():
        raise HTTPException(status_code=404, detail="Config file not found. Run 'qualito init' first.")

    # Read existing config
    content = config_path.read_text()

    # Update values
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    for key, value in updates.items():
        pattern = rf"^{key}\s*=.*$"
        replacement = f"{key} = {value}"
        new_content, count = re.subn(pattern, replacement, content, flags=re.MULTILINE)
        if count > 0:
            content = new_content
        else:
            # Append if not found
            content += f"\n{key} = {value}\n"

    config_path.write_text(content)

    # Return updated config
    config = load_config()
    return {
        "slo_quality": config.slo_quality,
        "slo_availability": config.slo_availability,
        "slo_cost": config.slo_cost,
    }


# ---------------------------------------------------------------------------
# DELETE /api/runs/{run_id} — single run deletion
# ---------------------------------------------------------------------------


@router.delete("/runs/{run_id}")
def delete_run(run_id: str, user: dict = Depends(get_current_user)):
    """Delete a single run and its child records (evaluations, tool_calls, file_activity)."""
    conn = _get_conn()
    try:
        r = runs_table
        row = conn.execute(
            select(r.c.id, r.c.user_id).where(r.c.id == run_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Run not found")
        if row["user_id"] != user["id"]:
            raise HTTPException(status_code=403, detail="Not your run")

        # Cascade delete children, then the run
        conn.execute(conversations_table.delete().where(conversations_table.c.run_id == run_id))
        conn.execute(evaluations_table.delete().where(evaluations_table.c.run_id == run_id))
        conn.execute(tool_calls_table.delete().where(tool_calls_table.c.run_id == run_id))
        conn.execute(file_activity_table.delete().where(file_activity_table.c.run_id == run_id))
        conn.execute(r.delete().where(r.c.id == run_id))
        conn.commit()

        return {"deleted": True, "run_id": run_id}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# DELETE /api/runs — batch run deletion
# ---------------------------------------------------------------------------


@router.delete("/runs")
def delete_runs_batch(body: DeleteRunsRequest, user: dict = Depends(get_current_user)):
    """Delete runs in batch: by workspace or by specific run IDs."""
    if not body.workspace and not body.run_ids:
        raise HTTPException(status_code=400, detail="Provide 'workspace' or 'run_ids'")

    conn = _get_conn()
    try:
        r = runs_table
        conditions = [r.c.user_id == user["id"]]
        if body.workspace:
            conditions.append(r.c.workspace == body.workspace)
        if body.run_ids:
            conditions.append(r.c.id.in_(body.run_ids))

        # Fetch IDs to delete
        rows = conn.execute(
            select(r.c.id).where(and_(*conditions))
        ).fetchall()
        ids_to_delete = [row[0] for row in rows]

        if not ids_to_delete:
            return {"deleted_count": 0}

        # Cascade delete children, then runs
        conn.execute(conversations_table.delete().where(conversations_table.c.run_id.in_(ids_to_delete)))
        conn.execute(evaluations_table.delete().where(evaluations_table.c.run_id.in_(ids_to_delete)))
        conn.execute(tool_calls_table.delete().where(tool_calls_table.c.run_id.in_(ids_to_delete)))
        conn.execute(file_activity_table.delete().where(file_activity_table.c.run_id.in_(ids_to_delete)))
        conn.execute(r.delete().where(r.c.id.in_(ids_to_delete)))
        conn.commit()

        return {"deleted_count": len(ids_to_delete)}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Sync endpoints (cloud → local upsert)
# ---------------------------------------------------------------------------


class SyncRunsRequest(BaseModel):
    runs: list[dict]


class SyncIncidentsRequest(BaseModel):
    incidents: list[dict]


@router.post("/sync/runs")
def sync_runs(body: SyncRunsRequest, user: dict = Depends(get_current_user)):
    """Accept a batch of runs from the CLI. Upserts (skips if ID exists)."""
    conn = _get_conn()
    try:
        r = runs_table
        e = evaluations_table
        tc_t = tool_calls_table
        fa_t = file_activity_table

        # Plan gating: free tier limits
        if not user_has_plan(user, "pro"):
            # Check run count limit (100 for free tier)
            run_count_row = conn.execute(
                select(func.count().label("cnt")).select_from(r).where(r.c.user_id == user["id"])
            ).mappings().fetchone()
            if run_count_row["cnt"] >= 100:
                raise HTTPException(
                    status_code=403,
                    detail="Free plan limited to 100 runs. Upgrade to Pro for unlimited.",
                )
            # Check workspace limit (3 for free tier)
            incoming_workspaces = {rd.get("workspace") for rd in body.runs if rd.get("workspace")}
            existing_ws_rows = conn.execute(
                select(r.c.workspace.distinct()).where(r.c.user_id == user["id"])
            ).fetchall()
            existing_workspaces = {row[0] for row in existing_ws_rows}
            all_workspaces = existing_workspaces | incoming_workspaces
            if len(all_workspaces) > 3:
                raise HTTPException(
                    status_code=403,
                    detail="Free plan limited to 3 workspaces. Upgrade to Pro for unlimited.",
                )

        synced = 0
        skipped = 0

        run_cols = [
            "id", "workspace", "task", "task_type", "model", "pipeline_mode",
            "status", "summary", "files_changed", "cost_usd", "input_tokens",
            "output_tokens", "cache_read_tokens", "duration_ms", "branch",
            "prompt", "original_prompt", "started_at", "completed_at",
            "researcher_summary", "implementer_summary", "verifier_verdict",
            "paper_live_gap", "skill_name", "source", "prompt_components",
            "session_type", "entrypoint", "claude_version", "session_name",
            "has_subagents", "subagent_count", "error_count",
        ]

        for run_data in body.runs:
            run_id = run_data.get("id")
            if not run_id:
                skipped += 1
                continue

            # Check if run already exists
            existing = conn.execute(
                select(r.c.id).where(r.c.id == run_id)
            ).fetchone()
            if existing:
                skipped += 1
                continue

            # Validate required fields
            if not run_data.get("workspace") or not run_data.get("task") or not run_data.get("started_at"):
                skipped += 1
                continue

            # Build values dict from present columns
            values = {}
            for c in run_cols:
                if c in run_data and run_data[c] is not None:
                    values[c] = run_data[c]
            if "id" not in values:
                values["id"] = run_id

            values["user_id"] = user["id"]
            conn.execute(r.insert().values(**values))

            # Insert evaluations
            for ev in run_data.get("evaluations", []):
                conn.execute(
                    e.insert().values(
                        run_id=run_id,
                        eval_type=ev.get("eval_type"),
                        checks=ev.get("checks"),
                        score=ev.get("score"),
                        categories=ev.get("categories"),
                        notes=ev.get("notes"),
                    )
                )

            # Insert tool calls
            for tc in run_data.get("tool_calls", []):
                conn.execute(
                    tc_t.insert().values(
                        run_id=run_id,
                        tool_name=tc.get("tool_name"),
                        arguments_summary=tc.get("arguments_summary"),
                        result_summary=tc.get("result_summary"),
                        is_error=tc.get("is_error", False),
                        phase=tc.get("phase"),
                        timestamp=tc.get("timestamp"),
                        duration_ms=tc.get("duration_ms"),
                    )
                )

            # Insert file activity
            for fa in run_data.get("file_activity", []):
                conn.execute(
                    fa_t.insert().values(
                        run_id=run_id,
                        file_path=fa.get("file_path"),
                        action=fa.get("action"),
                        timestamp=fa.get("timestamp"),
                    )
                )

            synced += 1

        conn.commit()
        return {"synced": synced, "skipped": skipped}
    finally:
        conn.close()


@router.post("/sync/incidents")
def sync_incidents(body: SyncIncidentsRequest, user: dict = Depends(get_current_user)):
    """Accept a batch of incidents from the CLI. Upserts by incident_key."""
    conn = _get_conn()
    try:
        inc = incidents_table
        synced = 0
        skipped = 0

        for inc_data in body.incidents:
            incident_key = inc_data.get("incident_key")
            if not incident_key:
                skipped += 1
                continue

            # Check if incident already exists by key
            existing = conn.execute(
                select(inc.c.id).where(inc.c.incident_key == incident_key)
            ).fetchone()
            if existing:
                skipped += 1
                continue

            # Validate required fields
            inc_cols = [
                "incident_key", "category", "severity", "status", "workspace",
                "task_type", "title", "description", "detection_method",
                "trigger_metric", "trigger_value", "baseline_value", "burn_rate",
                "affected_run_ids", "total_affected_runs", "cost_impact_usd",
                "fix_description", "resolution_type", "created_at",
                "confirmed_at", "resolved_at", "time_to_detect_runs",
                "time_to_resolve_runs",
            ]
            present = {c: inc_data[c] for c in inc_cols if c in inc_data and inc_data[c] is not None}

            required = {"incident_key", "category", "severity", "workspace", "title"}
            if not required.issubset(set(present.keys())):
                skipped += 1
                continue

            # Serialize affected_run_ids if it's a list
            if "affected_run_ids" in present and isinstance(present["affected_run_ids"], list):
                present["affected_run_ids"] = json.dumps(present["affected_run_ids"])

            conn.execute(inc.insert().values(**present))
            synced += 1

        conn.commit()
        return {"synced": synced, "skipped": skipped}
    finally:
        conn.close()
