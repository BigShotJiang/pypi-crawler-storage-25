"""Remote MCP server — user-scoped quality metrics over Streamable HTTP.

8 tools (mirrors local MCP server minus qualito_setup):
qualito_status, dqi_score, dqi_cost, dqi_patterns, dqi_warnings,
dqi_templates, dqi_incidents, dqi_slo.

All DB queries are scoped to the authenticated user's synced runs.
Auth: OAuth 2.0 via MCP SDK (token issued through API key authorization flow).
"""

import contextlib
import json
import logging
import re
import secrets
from collections.abc import AsyncIterator
from datetime import datetime, timedelta

from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from sqlalchemy import and_, case, func, select

from qualito.core.db import (
    conversations_table,
    evaluations_table,
    file_activity_table,
    get_sa_connection,
    incidents_table,
    runs_table,
    tool_calls_table,
    users_table,
)

# Lazy import to avoid circular dependency (mcp_oauth imports nothing from here)
def get_user_id_for_token(token: str):
    from qualito.dashboard.mcp_oauth import get_user_id_for_token as _lookup
    return _lookup(token)

logger = logging.getLogger("qualito-remote-mcp")


def _get_user_id() -> int:
    """Get the authenticated user's ID from the OAuth access token."""
    access_token = get_access_token()
    if access_token is None:
        raise RuntimeError("Not authenticated")
    user_id = get_user_id_for_token(access_token.token)
    if user_id is None:
        raise RuntimeError("Invalid access token")
    return user_id


def _get_conn():
    """Get a short-lived SA connection."""
    return get_sa_connection()


def _since_date(days: int) -> str:
    """Return ISO date string for N days ago."""
    return (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# FastMCP instance
# ---------------------------------------------------------------------------

remote_mcp = FastMCP(
    "qualito-remote",
    instructions="Qualito remote MCP server — user-scoped quality metrics.",
    streamable_http_path="/",
    stateless_http=True,
    transport_security=TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=[
            "api.qualito.ai",
            "api.qualito.ai:*",
            "127.0.0.1:*",
            "localhost:*",
        ],
        allowed_origins=[
            "https://api.qualito.ai",
            "https://app.qualito.ai",
            "http://127.0.0.1:*",
            "http://localhost:*",
        ],
    ),
)


# ---------------------------------------------------------------------------
# Tool 0: qualito_status (onboarding + account overview)
# ---------------------------------------------------------------------------

@remote_mcp.tool()
def qualito_status() -> str:
    """Check your Qualito account status and get onboarding guidance.

    Returns account state: run count, workspaces, last sync date.
    If no data exists, generates a one-command setup instruction.
    Call this first to understand what data is available."""
    from qualito.dashboard.setup_routes import store_setup_token

    user_id = _get_user_id()
    conn = _get_conn()
    try:
        # Get user email
        user_row = conn.execute(
            select(users_table.c.email, users_table.c.plan).where(users_table.c.id == user_id)
        ).mappings().fetchone()
        email = user_row["email"] if user_row else "unknown"
        plan = user_row["plan"] if user_row else "free"

        # Get run stats for this user
        stats = conn.execute(
            select(
                func.count().label("run_count"),
                func.max(runs_table.c.started_at).label("last_sync"),
            ).where(runs_table.c.user_id == user_id)
        ).mappings().fetchone()

        run_count = stats["run_count"]

        if run_count == 0:
            # Generate a setup token
            token = "st_setup_" + secrets.token_urlsafe(24)
            store_setup_token(token, user_id, email)

            return json.dumps({
                "status": "empty",
                "account": email,
                "plan": plan,
                "message": "No data yet. Run this command in your terminal (not inside Claude Code — it needs interactive input):",
                "command": f"uvx qualito@latest setup {token}",
                "note": "This token expires in 15 minutes. If you've used qualito before, use: uvx qualito@latest setup",
            }, indent=2)

        # Has runs — gather workspace list
        ws_rows = conn.execute(
            select(runs_table.c.workspace.distinct())
            .where(runs_table.c.user_id == user_id)
        ).fetchall()
        workspaces = sorted([row[0] for row in ws_rows if row[0]])

        # Average DQI score
        join = evaluations_table.join(
            runs_table, evaluations_table.c.run_id == runs_table.c.id
        )
        avg_row = conn.execute(
            select(func.avg(evaluations_table.c.score).label("avg_dqi"))
            .select_from(join)
            .where(and_(
                evaluations_table.c.eval_type == "dqi",
                runs_table.c.user_id == user_id,
            ))
        ).mappings().fetchone()

        return json.dumps({
            "status": "active",
            "account": email,
            "plan": plan,
            "run_count": run_count,
            "workspaces": workspaces,
            "avg_dqi": round(avg_row["avg_dqi"], 4) if avg_row["avg_dqi"] else None,
            "last_sync": stats["last_sync"],
            "available_tools": [
                "dqi_score", "dqi_cost", "dqi_patterns", "dqi_warnings",
                "dqi_templates", "dqi_incidents", "dqi_slo",
            ],
        }, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 1: dqi_score
# ---------------------------------------------------------------------------

@remote_mcp.tool()
def dqi_score(workspace: str = "", days: int = 30) -> str:
    """Get DQI score summary: average, trend, component breakdown, tier distribution.

    Use this to understand overall delegation quality for a workspace over time.

    Args:
        workspace: Filter by workspace name. Empty string = all workspaces.
        days: Number of days to look back (default 30).
    """
    user_id = _get_user_id()
    conn = _get_conn()
    try:
        since = _since_date(days)
        join = evaluations_table.join(runs_table, evaluations_table.c.run_id == runs_table.c.id)
        base_conds = [
            evaluations_table.c.eval_type == "dqi",
            runs_table.c.started_at >= since,
            runs_table.c.user_id == user_id,
        ]
        if workspace:
            base_conds.append(runs_table.c.workspace == workspace)

        avg_row = conn.execute(
            select(
                func.avg(evaluations_table.c.score).label("avg_dqi"),
                func.count(evaluations_table.c.id).label("scored_runs"),
            ).select_from(join).where(and_(*base_conds))
        ).mappings().fetchone()

        trend_rows = conn.execute(
            select(evaluations_table.c.score, runs_table.c.started_at)
            .select_from(join)
            .where(and_(*base_conds))
            .order_by(runs_table.c.started_at.desc())
            .limit(10)
        ).mappings().fetchall()

        cat_rows = conn.execute(
            select(evaluations_table.c.categories)
            .select_from(join)
            .where(and_(*base_conds, evaluations_table.c.categories.isnot(None)))
        ).mappings().fetchall()

        components = {"completion": [], "quality": [], "efficiency": [], "cost_score": []}
        tier_counts = {}
        for row in cat_rows:
            try:
                raw = row["categories"]
                cats = json.loads(raw) if isinstance(raw, str) else raw
            except (json.JSONDecodeError, TypeError):
                continue
            for key in components:
                if key in cats:
                    components[key].append(cats[key])
            tier_label = cats.get("tier_label", "unknown")
            tier_counts[tier_label] = tier_counts.get(tier_label, 0) + 1

        component_avgs = {}
        for key, vals in components.items():
            component_avgs[key] = round(sum(vals) / len(vals), 4) if vals else None

        trend = [{"dqi": round(r["score"], 4), "date": r["started_at"]} for r in trend_rows]

        return json.dumps({
            "avg_dqi": round(avg_row["avg_dqi"], 4) if avg_row["avg_dqi"] else None,
            "scored_runs": avg_row["scored_runs"],
            "days": days,
            "workspace": workspace or "all",
            "trend": trend,
            "components": component_avgs,
            "tier_distribution": tier_counts,
        }, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 2: dqi_cost
# ---------------------------------------------------------------------------

@remote_mcp.tool()
def dqi_cost(workspace: str = "", days: int = 30) -> str:
    """Get cost analysis: total spend, average per run, daily trend, waste estimate.

    Runs with DQI < 0.5 are classified as waste. Use this to track delegation costs.

    Args:
        workspace: Filter by workspace name. Empty string = all workspaces.
        days: Number of days to look back (default 30).
    """
    user_id = _get_user_id()
    conn = _get_conn()
    try:
        since = _since_date(days)
        base_conds = [
            runs_table.c.started_at >= since,
            runs_table.c.source == "delegation",
            runs_table.c.user_id == user_id,
        ]
        if workspace:
            base_conds.append(runs_table.c.workspace == workspace)

        stats = conn.execute(
            select(
                func.count().label("total_runs"),
                func.coalesce(func.sum(runs_table.c.cost_usd), 0).label("total_spend"),
                func.avg(runs_table.c.cost_usd).label("avg_per_run"),
            ).where(and_(*base_conds))
        ).mappings().fetchone()

        day_col = func.date(runs_table.c.started_at).label("day")
        daily = conn.execute(
            select(
                day_col,
                func.count().label("runs"),
                func.coalesce(func.sum(runs_table.c.cost_usd), 0).label("spend"),
            )
            .where(and_(*base_conds))
            .group_by(func.date(runs_table.c.started_at))
            .order_by(day_col.desc())
        ).mappings().fetchall()

        waste_join = runs_table.join(
            evaluations_table,
            and_(evaluations_table.c.run_id == runs_table.c.id,
                 evaluations_table.c.eval_type == "dqi"),
        )
        waste_conds = list(base_conds) + [evaluations_table.c.score < 0.5]
        waste = conn.execute(
            select(
                func.count().label("waste_runs"),
                func.coalesce(func.sum(runs_table.c.cost_usd), 0).label("waste_cost"),
            ).select_from(waste_join).where(and_(*waste_conds))
        ).mappings().fetchone()

        return json.dumps({
            "total_runs": stats["total_runs"],
            "total_spend": round(stats["total_spend"], 2),
            "avg_per_run": round(stats["avg_per_run"], 2) if stats["avg_per_run"] else None,
            "days": days,
            "workspace": workspace or "all",
            "daily_trend": [
                {"day": r["day"], "runs": r["runs"], "spend": round(r["spend"], 2)}
                for r in daily
            ],
            "waste": {
                "runs": waste["waste_runs"],
                "cost": round(waste["waste_cost"], 2),
                "pct_of_total": round(
                    waste["waste_cost"] / stats["total_spend"] * 100, 1
                ) if stats["total_spend"] > 0 else 0,
            },
        }, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 3: dqi_patterns (inline user-scoped query)
# ---------------------------------------------------------------------------

def _normalize_task(task: str) -> str:
    """Normalize task text into a groupable pattern key."""
    first_line = task.split("\n")[0].strip()
    normalized = re.sub(r"#\d+", "#N", first_line)
    normalized = re.sub(r"\b\d{6,}\b", "ID", normalized)
    words = normalized.lower().split()[:8]
    return " ".join(words)


@remote_mcp.tool()
def dqi_patterns(min_count: int = 3) -> str:
    """Detect repeated task patterns with classification and recommendations.

    Groups runs by normalized task text and identifies patterns that should
    become scripts, skills, or be reviewed. Use to find automation opportunities.

    Args:
        min_count: Minimum occurrences to include (default 3).
    """
    user_id = _get_user_id()
    conn = _get_conn()
    try:
        r = runs_table
        e = evaluations_table
        since_date = _since_date(30)

        conditions = [
            r.c.status == "completed",
            r.c.source == "delegation",
            r.c.started_at >= since_date,
            r.c.user_id == user_id,
        ]

        rows = conn.execute(
            select(
                r.c.id, r.c.task, r.c.cost_usd, r.c.task_type,
                r.c.workspace, r.c.skill_name,
                e.c.score.label("dqi_score"),
            )
            .select_from(
                r.outerjoin(e, and_(e.c.run_id == r.c.id, e.c.eval_type == "dqi"))
            )
            .where(and_(*conditions))
            .order_by(r.c.started_at.desc())
        ).mappings().fetchall()

        # Group by normalized pattern
        groups: dict[str, dict] = {}
        for row in rows:
            task = row["task"] or ""
            pattern = _normalize_task(task)
            if not pattern:
                continue

            if pattern not in groups:
                groups[pattern] = {
                    "pattern": pattern,
                    "count": 0,
                    "total_cost": 0.0,
                    "dqi_scores": [],
                    "task_types": set(),
                    "workspaces": set(),
                }

            g = groups[pattern]
            g["count"] += 1
            g["total_cost"] += row["cost_usd"] or 0.0
            if row["dqi_score"] is not None:
                g["dqi_scores"].append(row["dqi_score"])
            if row["task_type"]:
                g["task_types"].add(row["task_type"])
            if row["workspace"]:
                g["workspaces"].add(row["workspace"])

        # Filter by min count, classify
        results = []
        for g in groups.values():
            if g["count"] < min_count:
                continue

            avg_dqi = sum(g["dqi_scores"]) / len(g["dqi_scores"]) if g["dqi_scores"] else 0.0
            classification = "script" if g["count"] >= 5 and avg_dqi > 0.85 else "skill"

            results.append({
                "pattern": g["pattern"],
                "count": g["count"],
                "total_cost": round(g["total_cost"], 2),
                "avg_dqi": round(avg_dqi, 3),
                "type": classification,
                "recommendation": "Replace with script" if classification == "script"
                    else "Create new skill",
                "task_types": sorted(g["task_types"]),
                "workspaces": sorted(g["workspaces"]),
            })

        results.sort(key=lambda r: r["total_cost"], reverse=True)
        return json.dumps({"pattern_count": len(results), "patterns": results}, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 4: dqi_warnings (inline user-scoped query)
# ---------------------------------------------------------------------------

# Copied from feedback_loop — suggestion map
_CHECK_SUGGESTIONS = {
    "has_summary": "Ensure task asks for a structured summary",
    "has_output": "Task may be too vague - add specific deliverables",
    "has_findings": "Add 'Report your findings' to the task",
    "cost_reasonable": "Consider breaking into smaller tasks",
    "completed": "Tasks failing to complete - check timeout or scope",
    "tool_calls_made": "Delegate may not be using available tools",
    "chains_recorded": "Add explicit si_reason instruction to the task",
    "within_timeout": "Tasks timing out - reduce scope or increase timeout",
}


@remote_mcp.tool()
def dqi_warnings(workspace: str = "") -> str:
    """Get warnings for underperforming workspace/task_type combinations.

    Shows combos with low average DQI, their most common failing check,
    and actionable suggestions to improve. Use to identify delegation weak spots.

    Args:
        workspace: Filter by workspace name. Empty string = all workspaces.
    """
    user_id = _get_user_id()
    conn = _get_conn()
    try:
        r = runs_table
        e = evaluations_table

        # Find flagged combos
        combo_conds = [
            r.c.status == "completed",
            r.c.source == "delegation",
            r.c.user_id == user_id,
        ]
        if workspace:
            combo_conds.append(r.c.workspace == workspace)

        combos = conn.execute(
            select(
                r.c.workspace,
                r.c.task_type,
                func.count().label("cnt"),
                func.avg(e.c.score).label("avg_dqi"),
                func.sum(case((e.c.score < 0.70, 1), else_=0)).label("low_count"),
            )
            .select_from(r.join(e, and_(e.c.run_id == r.c.id, e.c.eval_type == "dqi")))
            .where(and_(*combo_conds))
            .group_by(r.c.workspace, r.c.task_type)
            .having(and_(func.count() >= 3, func.avg(e.c.score) < 0.75))
        ).mappings().fetchall()

        warnings = []
        for combo in combos:
            ws = combo["workspace"]
            task_type = combo["task_type"]

            # Analyze failure patterns (user-scoped)
            fp_rows = conn.execute(
                select(e.c.checks)
                .select_from(e.join(r, r.c.id == e.c.run_id))
                .where(and_(
                    r.c.workspace == ws,
                    r.c.task_type == task_type,
                    r.c.user_id == user_id,
                    e.c.eval_type == "auto",
                    r.c.status == "completed",
                    r.c.source == "delegation",
                ))
            ).mappings().fetchall()

            check_fail_counts: dict[str, int] = {}
            total_evals = 0
            for fp_row in fp_rows:
                checks_json = fp_row["checks"]
                if not checks_json:
                    continue
                try:
                    checks = json.loads(checks_json)
                except (json.JSONDecodeError, TypeError):
                    continue
                total_evals += 1
                for check_name, check_data in checks.items():
                    if isinstance(check_data, dict) and not check_data.get("passed", True):
                        check_fail_counts[check_name] = check_fail_counts.get(check_name, 0) + 1

            top_check = None
            top_pct = 0.0
            if check_fail_counts and total_evals > 0:
                top_check = max(check_fail_counts, key=check_fail_counts.get)
                top_pct = (check_fail_counts[top_check] / total_evals) * 100

            suggestion = _CHECK_SUGGESTIONS.get(
                top_check, f"Investigate '{top_check}' failures"
            ) if top_check else None

            # Cost gap (user-scoped)
            cost_row = conn.execute(
                select(
                    func.avg(case((e.c.score < 0.70, r.c.cost_usd))).label("avg_cost_low"),
                    func.avg(case((e.c.score >= 0.70, r.c.cost_usd))).label("avg_cost_high"),
                )
                .select_from(r.join(e, and_(e.c.run_id == r.c.id, e.c.eval_type == "dqi")))
                .where(and_(
                    r.c.workspace == ws,
                    r.c.task_type == task_type,
                    r.c.user_id == user_id,
                    r.c.status == "completed",
                    r.c.source == "delegation",
                ))
            ).mappings().fetchone()

            warnings.append({
                "workspace": ws,
                "task_type": task_type,
                "avg_dqi": round(combo["avg_dqi"], 3),
                "run_count": combo["cnt"],
                "low_dqi_runs": combo["low_count"],
                "top_failing_check": top_check,
                "top_fail_pct": round(top_pct, 1),
                "suggestion": suggestion,
                "avg_cost_low_dqi": (
                    round(cost_row["avg_cost_low"], 2) if cost_row["avg_cost_low"] else None
                ),
                "avg_cost_high_dqi": (
                    round(cost_row["avg_cost_high"], 2) if cost_row["avg_cost_high"] else None
                ),
            })

        return json.dumps({"warning_count": len(warnings), "warnings": warnings}, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 5: dqi_templates (pure logic, no DB)
# ---------------------------------------------------------------------------

def _infer_task_type(description: str) -> str:
    """Infer task type from a description using keyword matching."""
    desc = description.lower()
    keywords = {
        "test": ["test", "spec", "coverage", "pytest", "jest"],
        "pr_review": ["review", "pr ", "pull request", "code review"],
        "code": ["implement", "build", "create", "add feature", "write code", "develop"],
        "refactor": ["refactor", "clean up", "reorganize", "restructure", "simplify"],
        "research": ["research", "investigate", "explore", "analyze", "audit"],
        "jira": ["jira", "ticket", "issue", "backlog"],
        "confluence": ["confluence", "wiki", "documentation", "docs"],
        "slack": ["slack", "message", "draft", "notify"],
    }
    for task_type, kws in keywords.items():
        if any(kw in desc for kw in kws):
            return task_type
    return "other"


@remote_mcp.tool()
def dqi_templates(task_description: str) -> str:
    """Recommend a delegation template based on a task description.

    Infers the task type from keywords and suggests a matching template
    with best practices. Use before delegating to get a better prompt structure.

    Args:
        task_description: Description of the task you want to delegate.
    """
    task_type = _infer_task_type(task_description)

    templates = {
        "code": {
            "name": "code-implementation",
            "description": "Standard code implementation task",
            "structure": [
                "## Task", "<clear description of what to build>", "",
                "## Context", "- Read <relevant files> first",
                "- Follow existing patterns in <module>", "",
                "## Requirements", "- <specific acceptance criteria>", "",
                "## Verification", "- Run tests: <command>", "- Verify: <what to check>",
            ],
        },
        "refactor": {
            "name": "refactoring",
            "description": "Code refactoring task",
            "structure": [
                "## Task", "Refactor <target> to <goal>", "",
                "## Constraints", "- No behavior changes",
                "- Keep existing tests passing", "- Follow <convention>", "",
                "## Verification", "- All tests pass", "- No regressions",
            ],
        },
        "test": {
            "name": "test-writing",
            "description": "Write tests for existing code",
            "structure": [
                "## Task", "Write tests for <module>", "",
                "## Coverage", "- <happy path scenarios>",
                "- <edge cases>", "- <error cases>", "",
                "## Stack", "- Use <test framework>",
                "- Follow patterns in <existing test file>",
            ],
        },
        "research": {
            "name": "research-investigation",
            "description": "Research or investigation task",
            "structure": [
                "## Task", "Investigate <topic>", "",
                "## Questions", "1. <specific question>", "2. <specific question>", "",
                "## Output", "- Report findings in structured format",
                "- Include evidence and sources",
            ],
        },
        "pr_review": {
            "name": "pr-review",
            "description": "Pull request review task",
            "structure": [
                "## Task", "Review PR #<number> on <repo>", "",
                "## Focus Areas", "- Correctness", "- Code quality",
                "- Security concerns", "- Test coverage", "",
                "## Output", "- Post review comments on the PR",
            ],
        },
    }

    template = templates.get(task_type, {
        "name": "generic",
        "description": "Generic delegation task",
        "structure": [
            "## Task", "<clear description>", "",
            "## Context", "- Read relevant files first", "",
            "## Requirements", "- <specific deliverables>", "",
            "## Verification", "- <how to verify completion>",
        ],
    })

    return json.dumps({
        "inferred_task_type": task_type,
        "template_name": template["name"],
        "template_description": template["description"],
        "template_content": "\n".join(template["structure"]),
    }, indent=2)


# ---------------------------------------------------------------------------
# Tool 6: dqi_incidents
# ---------------------------------------------------------------------------

@remote_mcp.tool()
def dqi_incidents(workspace: str = "", status: str = "active") -> str:
    """Get DQI incidents -- quality regressions and anomalies detected by monitoring.

    Returns incidents filtered by status. 'active' shows non-resolved incidents
    (detected, confirmed, investigating). Use to track ongoing quality issues.

    Args:
        workspace: Filter by workspace name. Empty string = all workspaces.
        status: Filter by status -- 'active' (non-resolved), 'resolved', or 'all' (default 'active').
    """
    user_id = _get_user_id()
    conn = _get_conn()
    try:
        # Incidents are tied to workspaces. Filter by runs the user owns.
        # Get the user's workspaces first.
        ws_rows = conn.execute(
            select(runs_table.c.workspace.distinct())
            .where(runs_table.c.user_id == user_id)
        ).fetchall()
        user_workspaces = [row[0] for row in ws_rows]

        if not user_workspaces:
            return json.dumps({
                "incident_count": 0,
                "filter": {"workspace": workspace or "all", "status": status},
                "incidents": [],
            }, indent=2)

        conditions: list = [incidents_table.c.workspace.in_(user_workspaces)]

        if status == "active":
            conditions.append(incidents_table.c.status.notin_(["resolved", "false_positive"]))
        elif status == "resolved":
            conditions.append(incidents_table.c.status == "resolved")

        if workspace:
            conditions.append(incidents_table.c.workspace == workspace)

        severity_order = case(
            (incidents_table.c.severity == "critical", 0),
            (incidents_table.c.severity == "high", 1),
            (incidents_table.c.severity == "medium", 2),
            else_=3,
        )

        cols = [
            incidents_table.c.id, incidents_table.c.incident_key,
            incidents_table.c.category, incidents_table.c.severity,
            incidents_table.c.status, incidents_table.c.workspace,
            incidents_table.c.task_type, incidents_table.c.title,
            incidents_table.c.description, incidents_table.c.detection_method,
            incidents_table.c.trigger_metric, incidents_table.c.trigger_value,
            incidents_table.c.baseline_value, incidents_table.c.total_affected_runs,
            incidents_table.c.cost_impact_usd, incidents_table.c.created_at,
            incidents_table.c.confirmed_at, incidents_table.c.resolved_at,
        ]

        stmt = select(*cols)
        if conditions:
            stmt = stmt.where(and_(*conditions))
        stmt = stmt.order_by(severity_order, incidents_table.c.created_at.desc())

        rows = conn.execute(stmt).mappings().fetchall()
        incidents = [dict(r) for r in rows]

        return json.dumps({
            "incident_count": len(incidents),
            "filter": {"workspace": workspace or "all", "status": status},
            "incidents": incidents,
        }, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 7: dqi_slo
# ---------------------------------------------------------------------------

@remote_mcp.tool()
def dqi_slo(workspace: str = "") -> str:
    """Check SLO compliance: quality, availability, and cost targets over last 30 days.

    Compares current performance against configured thresholds:
    - Quality: % of runs with DQI >= 0.60
    - Availability: completion rate (completed / total)
    - Cost: % of runs under $3.00

    Args:
        workspace: Filter by workspace name. Empty string = all workspaces.
    """
    user_id = _get_user_id()
    conn = _get_conn()
    try:
        since = _since_date(30)
        base_conds = [
            runs_table.c.started_at >= since,
            runs_table.c.source == "delegation",
            runs_table.c.user_id == user_id,
        ]
        if workspace:
            base_conds.append(runs_table.c.workspace == workspace)

        total_row = conn.execute(
            select(
                func.count().label("total"),
                func.sum(case((runs_table.c.status == "completed", 1), else_=0)).label("completed"),
                func.sum(case((runs_table.c.cost_usd < 3.00, 1), else_=0)).label("under_cost"),
            ).where(and_(*base_conds))
        ).mappings().fetchone()

        total = total_row["total"] or 0
        completed = total_row["completed"] or 0
        under_cost = total_row["under_cost"] or 0

        join = evaluations_table.join(runs_table, evaluations_table.c.run_id == runs_table.c.id)
        quality_conds = list(base_conds) + [evaluations_table.c.eval_type == "dqi"]

        quality_row = conn.execute(
            select(
                func.count().label("total_scored"),
                func.sum(case((evaluations_table.c.score >= 0.60, 1), else_=0)).label("quality_ok"),
            ).select_from(join).where(and_(*quality_conds))
        ).mappings().fetchone()

        total_scored = quality_row["total_scored"] or 0
        quality_ok = quality_row["quality_ok"] or 0

        quality_pct = (quality_ok / total_scored * 100) if total_scored > 0 else None
        availability_pct = (completed / total * 100) if total > 0 else None
        cost_pct = (under_cost / total * 100) if total > 0 else None

        # Default SLO targets
        slo_quality = 60.0
        slo_availability = 95.0
        slo_cost = 80.0

        slos = {
            "quality": {
                "current": round(quality_pct, 1) if quality_pct is not None else None,
                "target": slo_quality,
                "met": quality_pct >= slo_quality if quality_pct is not None else None,
                "description": f"% of runs with DQI >= 0.60 (target: {slo_quality}%)",
                "scored_runs": total_scored,
            },
            "availability": {
                "current": round(availability_pct, 1) if availability_pct is not None else None,
                "target": slo_availability,
                "met": (
                    availability_pct >= slo_availability
                    if availability_pct is not None else None
                ),
                "description": f"Completion rate (target: {slo_availability}%)",
                "total_runs": total,
                "completed_runs": completed,
            },
            "cost": {
                "current": round(cost_pct, 1) if cost_pct is not None else None,
                "target": slo_cost,
                "met": cost_pct >= slo_cost if cost_pct is not None else None,
                "description": f"% of runs under $3.00 (target: {slo_cost}%)",
                "total_runs": total,
                "under_threshold": under_cost,
            },
        }

        all_met = all(s["met"] for s in slos.values() if s["met"] is not None)

        return json.dumps({
            "workspace": workspace or "all",
            "period_days": 30,
            "all_slos_met": all_met if any(s["met"] is not None for s in slos.values()) else None,
            "slos": slos,
        }, indent=2)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Tool 8: qualito_delete_runs
# ---------------------------------------------------------------------------

@remote_mcp.tool()
def qualito_delete_runs(workspace: str = "", run_ids: list[str] | None = None) -> str:
    """Delete synced runs from your cloud account.

    Provide workspace name to delete all runs in that workspace,
    or specific run_ids to delete individual runs. Returns count deleted.

    Args:
        workspace: Delete all runs in this workspace. Empty string = ignored.
        run_ids: List of specific run IDs to delete. None = ignored.
    """
    if not workspace and not run_ids:
        return json.dumps({"error": "Provide 'workspace' or 'run_ids'"})

    user_id = _get_user_id()
    conn = _get_conn()
    try:
        r = runs_table
        conditions = [r.c.user_id == user_id]
        if workspace:
            conditions.append(r.c.workspace == workspace)
        if run_ids:
            conditions.append(r.c.id.in_(run_ids))

        # Fetch IDs to delete
        rows = conn.execute(
            select(r.c.id).where(and_(*conditions))
        ).fetchall()
        ids_to_delete = [row[0] for row in rows]

        if not ids_to_delete:
            return json.dumps({"deleted_count": 0})

        # Cascade delete children, then runs
        conn.execute(conversations_table.delete().where(conversations_table.c.run_id.in_(ids_to_delete)))
        conn.execute(evaluations_table.delete().where(evaluations_table.c.run_id.in_(ids_to_delete)))
        conn.execute(tool_calls_table.delete().where(tool_calls_table.c.run_id.in_(ids_to_delete)))
        conn.execute(file_activity_table.delete().where(file_activity_table.c.run_id.in_(ids_to_delete)))
        conn.execute(r.delete().where(r.c.id.in_(ids_to_delete)))
        conn.commit()

        return json.dumps({"deleted_count": len(ids_to_delete)})
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_mcp_app(token_verifier=None):
    """Create the MCP Starlette app with OAuth token verification.

    Args:
        token_verifier: OAuth token verifier instance. If provided, enables
                       Bearer token auth on the MCP endpoint.

    Must be called before accessing remote_mcp.session_manager.
    """
    if token_verifier:
        from mcp.server.auth.settings import AuthSettings
        from pydantic import AnyHttpUrl
        import os

        api_url = os.environ.get("API_URL", "https://api.qualito.ai")
        remote_mcp._token_verifier = token_verifier
        remote_mcp.settings.auth = AuthSettings(
            issuer_url=AnyHttpUrl(api_url),
            resource_server_url=AnyHttpUrl(f"{api_url}/mcp"),
        )
    return remote_mcp.streamable_http_app()


@contextlib.asynccontextmanager
async def mcp_lifespan() -> AsyncIterator[None]:
    """Async context manager to run the MCP session manager.

    Must be entered during the FastAPI app lifespan (after create_mcp_app).
    """
    async with remote_mcp.session_manager.run():
        yield
