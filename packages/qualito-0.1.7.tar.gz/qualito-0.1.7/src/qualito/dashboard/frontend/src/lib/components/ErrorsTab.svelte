<script lang="ts">
	import type { ToolCallRecord } from '$lib/types';

	interface Props {
		toolCalls: ToolCallRecord[];
		sessionType: string | null;
		errorCount: number;
	}

	let { toolCalls, sessionType, errorCount }: Props = $props();

	// Filter to errors only
	let errors = $derived(() => {
		return toolCalls.filter(tc => tc.error || tc.is_error);
	});

	// Group errors by tool name
	let errorGroups = $derived(() => {
		const groups: Record<string, typeof errors extends () => (infer T)[] ? T[] : never[]> = {};
		for (const err of errors()) {
			const key = err.tool_name || 'unknown';
			if (!groups[key]) groups[key] = [];
			groups[key].push(err);
		}
		return Object.entries(groups).sort((a, b) => b[1].length - a[1].length);
	});

	function truncate(s: string | null | undefined, max = 120): string {
		if (!s) return '\u2014';
		return s.length > max ? s.slice(0, max - 1) + '\u2026' : s;
	}
</script>

{#if sessionType === 'delegated'}
	<div class="flex flex-col items-center justify-center py-12 text-center">
		<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color: var(--text-faint)" class="mb-3">
			<circle cx="12" cy="12" r="10" />
			<line x1="12" y1="8" x2="12" y2="12" />
			<line x1="12" y1="16" x2="12.01" y2="16" />
		</svg>
		<p class="text-sm" style="color: var(--text-muted)">Limited error data for SDK sessions</p>
		<p class="text-xs mt-1" style="color: var(--text-faint)">Only API-level errors are captured</p>
	</div>
{:else if errors().length === 0}
	<div class="flex flex-col items-center justify-center py-12 text-center">
		<div class="w-10 h-10 rounded-full flex items-center justify-center mb-3" style="background: var(--success-muted)">
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--success)">
				<polyline points="20 6 9 17 4 12" />
			</svg>
		</div>
		<p class="text-sm" style="color: var(--text-muted)">No errors in this session</p>
	</div>
{:else}
	<div class="space-y-3">
		<div class="p-3 flex items-center gap-2" style="border-bottom: 1px solid var(--border-subtle)">
			<span class="text-xs font-semibold" style="color: var(--error)">{errors().length} error{errors().length !== 1 ? 's' : ''}</span>
			<span class="text-xs" style="color: var(--text-faint)">
				across {errorGroups().length} tool{errorGroups().length !== 1 ? 's' : ''}
			</span>
		</div>

		{#each errorGroups() as [toolName, errs]}
			<div class="p-3">
				<div class="flex items-center gap-2 mb-2">
					<span class="font-mono text-xs font-semibold" style="color: var(--text)">{toolName}</span>
					<span class="badge badge-error text-[10px]">{errs.length}</span>
				</div>
				<div class="space-y-1.5">
					{#each errs as err}
						<div class="p-2 rounded-lg" style="background: var(--error-muted); border: 1px solid rgba(248, 113, 113, 0.2);">
							<p class="text-xs" style="color: var(--error)">{truncate(err.error || err.result_summary)}</p>
							{#if err.timestamp}
								<span class="text-[10px] mt-1 block" style="color: var(--text-faint)">{new Date(err.timestamp).toLocaleTimeString()}</span>
							{/if}
						</div>
					{/each}
				</div>
			</div>
		{/each}
	</div>
{/if}
