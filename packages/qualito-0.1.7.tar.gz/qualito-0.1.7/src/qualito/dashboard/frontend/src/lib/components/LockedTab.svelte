<script lang="ts">
	interface Props {
		title: string;
		description: string;
		ctaText?: string;
		ctaLink?: string;
	}

	let { title, description, ctaText = 'Learn more', ctaLink = '#' }: Props = $props();
</script>

<div class="flex flex-col items-center justify-center py-16 px-6 text-center">
	<div class="w-12 h-12 rounded-full flex items-center justify-center mb-4" style="background: var(--bg-elevated); border: 1px solid var(--border);">
		<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color: var(--text-faint)">
			<rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
			<path d="M7 11V7a5 5 0 0 1 10 0v4" />
		</svg>
	</div>
	<h3 class="text-sm font-semibold mb-2" style="color: var(--text-secondary)">{title}</h3>
	<p class="text-xs max-w-sm mb-4" style="color: var(--text-faint)">{description}</p>
	<a
		href={ctaLink}
		class="text-xs font-medium px-4 py-2 rounded-lg transition-all duration-150"
		style="color: var(--accent); background: var(--accent-subtle); border: 1px solid transparent;"
		onmouseenter={(e) => { const t = e.currentTarget as HTMLElement; t.style.borderColor = 'var(--accent)'; }}
		onmouseleave={(e) => { const t = e.currentTarget as HTMLElement; t.style.borderColor = 'transparent'; }}
	>
		{ctaText} &rarr;
	</a>
</div>
