<script lang="ts">
	import { onMount } from 'svelte';
	import Card from '$lib/components/Card.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import { listRuns } from '$lib/api';
	import { formatDate, formatEstimateCost, formatDurationMs, shortModelName, dqiColor, runDisplayName } from '$lib/format';
	import type { Run } from '$lib/types';

	let runs = $state<Run[]>([]);
	let total = $state(0);
	let error = $state<string | null>(null);
	let loading = $state(true);

	// Filters
	let filterWorkspace = $state('');
	let filterType = $state('');
	let filterModel = $state('');
	let searchQuery = $state('');
	let sortBy = $state('started_at');

	// Pagination
	let pageSize = 25;
	let currentPage = $state(0);

	// Unique filter values
	let workspaces = $state<string[]>([]);

	// Summary stats
	let summaryStats = $state({
		total: 0,
		interactive: 0,
		delegated: 0,
		totalCost: 0,
		avgDuration: 0,
		totalErrors: 0,
	});

	async function fetchRuns() {
		loading = true;
		error = null;
		try {
			const params: Record<string, string | number | boolean> = {
				limit: pageSize,
				offset: currentPage * pageSize
			};
			if (filterWorkspace) params.workspace = filterWorkspace;
			if (filterType) params.session_type = filterType;
			if (filterModel) {
				// Map short names to model patterns
				const modelMap: Record<string, string> = {
					opus: 'claude-opus',
					sonnet: 'claude-sonnet',
					haiku: 'claude-haiku',
				};
				if (modelMap[filterModel]) params.model = modelMap[filterModel];
			}

			const res = await listRuns(params as any);
			runs = res.runs;
			total = res.total;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load runs';
		} finally {
			loading = false;
		}
	}

	async function fetchFilterValues() {
		try {
			const res = await listRuns({ limit: 200 });
			const ws = new Set<string>();
			let interactive = 0, delegated = 0, totalCost = 0, totalDuration = 0, durationCount = 0, totalErrors = 0;
			for (const r of res.runs) {
				if (r.workspace) ws.add(r.workspace);
				if (r.session_type === 'interactive') interactive++;
				else if (r.session_type === 'delegated') delegated++;
				if (r.cost_usd) totalCost += r.cost_usd;
				if (r.duration_ms) { totalDuration += r.duration_ms; durationCount++; }
				if (r.error_count) totalErrors += r.error_count;
			}
			workspaces = [...ws].sort();
			summaryStats = {
				total: res.total,
				interactive,
				delegated,
				totalCost,
				avgDuration: durationCount > 0 ? totalDuration / durationCount : 0,
				totalErrors,
			};
		} catch {
			// Ignore
		}
	}

	onMount(() => {
		fetchRuns();
		fetchFilterValues();
	});

	function onFilterChange() {
		currentPage = 0;
		fetchRuns();
	}

	// Client-side search + sort
	let filteredRuns = $derived(() => {
		let result = [...runs];

		// Client-side search filter
		if (searchQuery.trim()) {
			const q = searchQuery.toLowerCase();
			result = result.filter(r =>
				(r.session_name || '').toLowerCase().includes(q) ||
				(r.task || '').toLowerCase().includes(q)
			);
		}

		// Sort
		result.sort((a, b) => {
			let va: any = (a as any)[sortBy];
			let vb: any = (b as any)[sortBy];
			if (va == null) return 1;
			if (vb == null) return -1;
			if (typeof va === 'string') va = va.toLowerCase();
			if (typeof vb === 'string') vb = vb.toLowerCase();
			return va < vb ? 1 : va > vb ? -1 : 0; // descending by default
		});

		return result;
	});

	let totalPages = $derived(Math.ceil(total / pageSize));

	function prevPage() {
		if (currentPage > 0) { currentPage--; fetchRuns(); }
	}
	function nextPage() {
		if (currentPage < totalPages - 1) { currentPage++; fetchRuns(); }
	}

	function toolCount(r: Run): number {
		// tool count from the run — not directly available in list, use 0 as fallback
		return 0;
	}

	function sessionTypeBadge(type: string | null): { variant: 'info' | 'accent' | 'neutral'; text: string } {
		if (type === 'interactive') return { variant: 'info', text: 'interactive' };
		if (type === 'delegated') return { variant: 'accent', text: 'delegated' };
		return { variant: 'neutral', text: type || 'unknown' };
	}
</script>

<div class="space-y-5">
	<h1 class="text-xl font-semibold" style="color: var(--text)">Sessions</h1>

	<!-- Summary stats -->
	<div class="grid grid-cols-2 md:grid-cols-4 gap-3">
		<div class="metric-card">
			<div class="relative z-10">
				<p class="text-[10px] font-semibold uppercase tracking-wider" style="color: var(--text-faint)">Total Sessions</p>
				<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{summaryStats.total}</p>
				<p class="text-[10px] mt-0.5" style="color: var(--text-faint)">
					{summaryStats.interactive} interactive, {summaryStats.delegated} delegated
				</p>
			</div>
		</div>
		<div class="metric-card">
			<div class="relative z-10">
				<p class="text-[10px] font-semibold uppercase tracking-wider" style="color: var(--text-faint)">Total Cost</p>
				<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">
					~${summaryStats.totalCost.toFixed(2)}
				</p>
				<p class="text-[10px] mt-0.5" style="color: var(--text-faint)">estimate</p>
			</div>
		</div>
		<div class="metric-card">
			<div class="relative z-10">
				<p class="text-[10px] font-semibold uppercase tracking-wider" style="color: var(--text-faint)">Avg Duration</p>
				<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">
					{formatDurationMs(summaryStats.avgDuration)}
				</p>
			</div>
		</div>
		<div class="metric-card">
			<div class="relative z-10">
				<p class="text-[10px] font-semibold uppercase tracking-wider" style="color: var(--text-faint)">Total Errors</p>
				<p class="text-2xl font-semibold font-mono mt-1" style="color: {summaryStats.totalErrors > 0 ? 'var(--error)' : 'var(--text)'}">
					{summaryStats.totalErrors}
				</p>
			</div>
		</div>
	</div>

	<!-- Filter bar -->
	<div class="flex flex-wrap gap-3 items-center">
		<input
			class="input text-sm"
			placeholder="Search sessions..."
			style="min-width: 180px;"
			bind:value={searchQuery}
		/>

		<select class="select-field text-sm" bind:value={filterWorkspace} onchange={onFilterChange}>
			<option value="">All workspaces</option>
			{#each workspaces as ws}
				<option value={ws}>{ws}</option>
			{/each}
		</select>

		<select class="select-field text-sm" bind:value={filterType} onchange={onFilterChange}>
			<option value="">All types</option>
			<option value="interactive">Interactive</option>
			<option value="delegated">Delegated</option>
		</select>

		<select class="select-field text-sm" bind:value={filterModel} onchange={onFilterChange}>
			<option value="">All models</option>
			<option value="opus">Opus</option>
			<option value="sonnet">Sonnet</option>
			<option value="haiku">Haiku</option>
		</select>

		<select class="select-field text-sm" bind:value={sortBy} onchange={() => {}}>
			<option value="started_at">Sort: Date</option>
			<option value="cost_usd">Sort: Cost</option>
			<option value="duration_ms">Sort: Duration</option>
			<option value="error_count">Sort: Errors</option>
		</select>

		<span class="text-xs ml-auto" style="color: var(--text-muted)">
			{total} session{total !== 1 ? 's' : ''}
		</span>
	</div>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if loading}
		<div class="space-y-2">
			{#each Array(5) as _}
				<div class="skeleton h-12 rounded-lg"></div>
			{/each}
		</div>
	{:else if filteredRuns().length === 0}
		<Card padding="p-8">
			<p class="text-center text-sm" style="color: var(--text-muted)">No sessions found</p>
		</Card>
	{:else}
		<div class="table-container">
			<table>
				<thead>
					<tr>
						<th>Session</th>
						<th>Workspace</th>
						<th>Type</th>
						<th>Model</th>
						<th>DQI</th>
						<th>Cost</th>
						<th>Duration</th>
						<th>Tools</th>
						<th>Errors</th>
						<th>Date</th>
					</tr>
				</thead>
				<tbody>
					{#each filteredRuns() as run}
						{@const badge = sessionTypeBadge(run.session_type)}
						<tr class="cursor-pointer" onclick={() => window.location.href = `/runs/${run.id}`}>
							<td>
								<span class="text-sm font-medium" style="color: var(--text)">
									{runDisplayName(run)}
								</span>
							</td>
							<td>
								{#if run.workspace}
									<span class="badge badge-accent">{run.workspace}</span>
								{/if}
							</td>
							<td>
								<Badge variant={badge.variant} text={badge.text} />
							</td>
							<td>
								<span class="font-mono text-xs" style="color: var(--text-secondary)">
									{shortModelName(run.model)}
								</span>
							</td>
							<td>
								{#if run.dqi != null}
									<span class="font-mono text-sm font-semibold" style="color: {dqiColor(run.dqi)}">
										{(run.dqi * 100).toFixed(0)}
									</span>
								{:else}
									<span class="text-xs" style="color: var(--text-faint)">&mdash;</span>
								{/if}
							</td>
							<td>
								<span class="font-mono text-xs" style="color: var(--text-secondary)">
									{formatEstimateCost(run.cost_usd)}
								</span>
							</td>
							<td>
								<span class="text-xs" style="color: var(--text-secondary)">
									{formatDurationMs(run.duration_ms)}
								</span>
							</td>
							<td>
								<span class="font-mono text-xs" style="color: var(--text-secondary)">{run.tool_count ?? '—'}</span>
							</td>
							<td>
								{#if run.error_count != null && run.error_count > 0}
									<span class="font-mono text-xs font-semibold" style="color: var(--error)">{run.error_count}</span>
								{:else}
									<span class="font-mono text-xs" style="color: var(--text-faint)">0</span>
								{/if}
							</td>
							<td>
								<span class="text-xs" style="color: var(--text-muted)">{formatDate(run.started_at)}</span>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>

		<!-- Pagination -->
		{#if totalPages > 1}
			<div class="flex items-center justify-between">
				<span class="text-xs" style="color: var(--text-muted)">
					Page {currentPage + 1} of {totalPages}
				</span>
				<div class="flex gap-2">
					<button class="btn btn-ghost text-xs" onclick={prevPage} disabled={currentPage === 0}>
						&larr; Prev
					</button>
					<button class="btn btn-ghost text-xs" onclick={nextPage} disabled={currentPage >= totalPages - 1}>
						Next &rarr;
					</button>
				</div>
			</div>
		{/if}
	{/if}
</div>
