<script lang="ts">
	import type { RunDetail } from '$lib/types';
	import Card from './Card.svelte';

	interface Props {
		run: RunDetail;
	}

	let { run }: Props = $props();

	// Stats
	let totalToolCalls = $derived(run.tool_calls?.length ?? 0);
	let totalFiles = $derived(Object.keys(run.files_summary ?? {}).length);
	let errorCount = $derived(run.error_count ?? 0);
	let subagentCount = $derived(run.subagent_count ?? 0);

	// Tool frequency — sorted by count descending
	let toolFrequency = $derived(() => {
		const summary = run.tool_summary ?? {};
		return Object.entries(summary)
			.sort((a, b) => b[1] - a[1])
			.slice(0, 15);
	});

	let maxToolCount = $derived(() => {
		const freq = toolFrequency();
		return freq.length > 0 ? freq[0][1] : 1;
	});

	// Files from files_summary — sorted by total operations
	let filesList = $derived(() => {
		const summary = run.files_summary ?? {};
		return Object.entries(summary)
			.map(([path, actions]) => ({
				path,
				actions,
				total: Object.values(actions).reduce((a, b) => a + b, 0),
				primaryAction: Object.entries(actions).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'read',
			}))
			.sort((a, b) => b.total - a.total)
			.slice(0, 20);
	});

	// Timeline data — tool calls with timestamps
	let timelineData = $derived(() => {
		if (!run.tool_calls || run.tool_calls.length === 0) return null;
		const startTime = run.started_at ? new Date(run.started_at).getTime() : 0;
		const endTime = run.completed_at ? new Date(run.completed_at).getTime() : startTime + (run.duration_ms ?? 0);
		const span = endTime - startTime;
		if (span <= 0) return null;

		const points = run.tool_calls
			.filter(tc => tc.timestamp)
			.map(tc => {
				const t = new Date(tc.timestamp!).getTime();
				return {
					x: ((t - startTime) / span) * 100,
					isError: !!tc.error || tc.is_error === true,
					name: tc.tool_name,
				};
			})
			.filter(p => p.x >= 0 && p.x <= 100);

		return points;
	});

	function actionColor(action: string): string {
		switch (action) {
			case 'read': return 'var(--text-faint)';
			case 'edit': return 'var(--warning)';
			case 'write': return 'var(--success)';
			case 'create': return 'var(--success)';
			case 'delete': return 'var(--error)';
			default: return 'var(--text-muted)';
		}
	}

	function shortenPath(path: string): string {
		const parts = path.split('/');
		if (parts.length <= 3) return path;
		return '.../' + parts.slice(-3).join('/');
	}
</script>

<div class="space-y-5">
	<!-- Quick stats -->
	<div class="grid grid-cols-2 md:grid-cols-4 gap-3">
		<div class="card-inset p-4 text-center">
			<p class="text-2xl font-semibold font-mono" style="color: var(--text)">{totalToolCalls}</p>
			<p class="text-[10px] uppercase tracking-wider mt-1" style="color: var(--text-faint)">Tool Calls</p>
		</div>
		<div class="card-inset p-4 text-center">
			<p class="text-2xl font-semibold font-mono" style="color: var(--text)">{totalFiles}</p>
			<p class="text-[10px] uppercase tracking-wider mt-1" style="color: var(--text-faint)">Files</p>
		</div>
		<div class="card-inset p-4 text-center">
			<p class="text-2xl font-semibold font-mono" style="color: {errorCount > 0 ? 'var(--error)' : 'var(--text)'}">{errorCount}</p>
			<p class="text-[10px] uppercase tracking-wider mt-1" style="color: var(--text-faint)">Errors</p>
		</div>
		{#if subagentCount > 0}
			<div class="card-inset p-4 text-center">
				<p class="text-2xl font-semibold font-mono" style="color: var(--accent)">{subagentCount}</p>
				<p class="text-[10px] uppercase tracking-wider mt-1" style="color: var(--text-faint)">Subagents</p>
			</div>
		{:else}
			<div class="card-inset p-4 text-center">
				<p class="text-2xl font-semibold font-mono" style="color: var(--text)">0</p>
				<p class="text-[10px] uppercase tracking-wider mt-1" style="color: var(--text-faint)">Subagents</p>
			</div>
		{/if}
	</div>

	<!-- Task -->
	{#if run.task}
		<Card title="Task" padding="p-4">
			<p class="text-sm" style="color: var(--text-secondary); white-space: pre-wrap; word-break: break-word;">
				{run.task}
			</p>
		</Card>
	{/if}

	<!-- Timeline visualization -->
	{#if timelineData()}
		<Card title="Activity Timeline" padding="p-4">
			<div class="relative h-10 rounded-lg overflow-hidden" style="background: var(--bg-inset);">
				<!-- Duration bar -->
				<div class="absolute inset-0 rounded-lg" style="background: linear-gradient(90deg, var(--accent-subtle), transparent);"></div>
				<!-- Tool call dots -->
				{#each timelineData()! as point}
					<div
						class="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full"
						style="left: {point.x}%; background: {point.isError ? 'var(--error)' : 'var(--accent)'};"
						title="{point.name}{point.isError ? ' (error)' : ''}"
					></div>
				{/each}
			</div>
			<div class="flex justify-between mt-1">
				<span class="text-[10px]" style="color: var(--text-faint)">start</span>
				<span class="text-[10px]" style="color: var(--text-faint)">end</span>
			</div>
		</Card>
	{/if}

	<!-- Tool frequency -->
	{#if toolFrequency().length > 0}
		<Card title="Tool Usage" padding="p-4">
			<div class="space-y-1.5">
				{#each toolFrequency() as [name, count]}
					<div class="flex items-center gap-3">
						<span class="font-mono text-xs w-28 text-right flex-shrink-0 truncate" style="color: var(--text-secondary)" title={name}>{name}</span>
						<div class="flex-1 h-4 rounded" style="background: var(--bg-inset)">
							<div
								class="h-full rounded transition-all"
								style="width: {(count / maxToolCount()) * 100}%; background: var(--accent); opacity: 0.7;"
							></div>
						</div>
						<span class="font-mono text-xs w-8 text-right" style="color: var(--text-muted)">{count}</span>
					</div>
				{/each}
			</div>
		</Card>
	{/if}

	<!-- Files list -->
	{#if filesList().length > 0}
		<Card title="Files ({totalFiles})" padding="p-0">
			<div class="table-container" style="border: none; border-radius: 0;">
				<table>
					<thead>
						<tr>
							<th>File</th>
							<th>Action</th>
							<th>Count</th>
						</tr>
					</thead>
					<tbody>
						{#each filesList() as file}
							<tr>
								<td>
									<span class="font-mono text-xs" style="color: var(--text-secondary)" title={file.path}>
										{shortenPath(file.path)}
									</span>
								</td>
								<td>
									<span class="text-xs font-medium" style="color: {actionColor(file.primaryAction)}">
										{file.primaryAction}
									</span>
								</td>
								<td>
									<span class="font-mono text-xs" style="color: var(--text-muted)">{file.total}</span>
								</td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>
		</Card>
	{/if}
</div>
