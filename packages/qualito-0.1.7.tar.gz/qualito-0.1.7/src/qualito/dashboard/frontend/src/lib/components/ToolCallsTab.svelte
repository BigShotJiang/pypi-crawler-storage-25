<script lang="ts">
	import type { ToolCallRecord } from '$lib/types';

	interface Props {
		toolCalls: ToolCallRecord[];
		sessionType: string | null;
	}

	let { toolCalls, sessionType }: Props = $props();

	let filterTool = $state('');

	// Unique tool names
	let toolNames = $derived(() => {
		const names = new Set<string>();
		for (const tc of toolCalls) {
			if (tc.tool_name) names.add(tc.tool_name);
		}
		return [...names].sort();
	});

	// Tool counts
	let toolCounts = $derived(() => {
		const counts: Record<string, number> = {};
		for (const tc of toolCalls) {
			counts[tc.tool_name] = (counts[tc.tool_name] || 0) + 1;
		}
		return counts;
	});

	let filtered = $derived(() => {
		if (!filterTool) return toolCalls;
		return toolCalls.filter(tc => tc.tool_name === filterTool);
	});

	function truncate(s: string | null | undefined, max = 80): string {
		if (!s) return '\u2014';
		return s.length > max ? s.slice(0, max - 1) + '\u2026' : s;
	}
</script>

{#if sessionType === 'delegated'}
	<div class="flex flex-col items-center justify-center py-12 text-center">
		<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color: var(--text-faint)" class="mb-3">
			<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
		</svg>
		<p class="text-sm" style="color: var(--text-muted)">SDK sessions don't capture tool calls in the session file</p>
		<p class="text-xs mt-1" style="color: var(--text-faint)">Tool execution happens inside the SDK process</p>
	</div>
{:else if toolCalls.length === 0}
	<div class="flex flex-col items-center justify-center py-12 text-center">
		<p class="text-sm" style="color: var(--text-muted)">No tool calls recorded</p>
	</div>
{:else}
	<div class="space-y-3">
		<!-- Filter -->
		<div class="flex items-center gap-3 p-3" style="border-bottom: 1px solid var(--border-subtle)">
			<select class="select-field text-xs" bind:value={filterTool}>
				<option value="">All tools ({toolCalls.length})</option>
				{#each toolNames() as name}
					<option value={name}>{name} ({toolCounts()[name]})</option>
				{/each}
			</select>
		</div>

		<div class="table-container" style="border: none; border-radius: 0;">
			<table>
				<thead>
					<tr>
						<th>Tool</th>
						<th>Arguments</th>
						<th>Result</th>
						<th>Status</th>
						<th>Time</th>
					</tr>
				</thead>
				<tbody>
					{#each filtered().slice(0, 100) as tc}
						<tr style="{tc.error || tc.is_error ? 'background: var(--error-muted);' : ''}">
							<td>
								<span class="font-mono text-xs" style="color: var(--text-secondary)">{tc.tool_name}</span>
							</td>
							<td>
								<span class="text-xs" style="color: var(--text-muted)">{truncate(tc.arguments_summary)}</span>
							</td>
							<td>
								<span class="text-xs" style="color: var(--text-muted)">{truncate(tc.result_summary)}</span>
							</td>
							<td>
								{#if tc.error || tc.is_error}
									<span class="text-xs font-semibold" style="color: var(--error)">error</span>
								{:else}
									<span class="text-xs" style="color: var(--success)">ok</span>
								{/if}
							</td>
							<td>
								<span class="font-mono text-[10px]" style="color: var(--text-faint)">
									{tc.duration_ms != null ? `${tc.duration_ms}ms` : '\u2014'}
								</span>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
			{#if filtered().length > 100}
				<div class="p-2 text-center text-xs" style="color: var(--text-faint)">
					Showing 100 of {filtered().length} tool calls
				</div>
			{/if}
		</div>
	</div>
{/if}
