<script lang="ts">
	import type { FileActivityRecord } from '$lib/types';

	interface Props {
		fileActivity: FileActivityRecord[];
		filesSummary: Record<string, Record<string, number>>;
		sessionType: string | null;
	}

	let { fileActivity, filesSummary, sessionType }: Props = $props();

	// Deduplicated file list from filesSummary, sorted by total operations
	let files = $derived(() => {
		return Object.entries(filesSummary)
			.map(([path, actions]) => ({
				path,
				actions,
				total: Object.values(actions).reduce((a, b) => a + b, 0),
				primaryAction: Object.entries(actions).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'read',
			}))
			.sort((a, b) => b.total - a.total);
	});

	function actionColor(action: string): string {
		switch (action) {
			case 'read': return 'var(--text-faint)';
			case 'edit': return 'var(--warning)';
			case 'write': return 'var(--success)';
			case 'create': return 'var(--success)';
			case 'delete': return 'var(--error)';
			case 'glob': return 'var(--info)';
			default: return 'var(--text-muted)';
		}
	}

	function actionBg(action: string): string {
		switch (action) {
			case 'read': return 'rgba(100, 116, 139, 0.15)';
			case 'edit': return 'var(--warning-muted)';
			case 'write': return 'var(--success-muted)';
			case 'create': return 'var(--success-muted)';
			case 'delete': return 'var(--error-muted)';
			case 'glob': return 'var(--info-muted)';
			default: return 'rgba(100, 116, 139, 0.15)';
		}
	}

	function shortenPath(path: string): string {
		const parts = path.split('/');
		if (parts.length <= 4) return path;
		return '.../' + parts.slice(-4).join('/');
	}
</script>

{#if sessionType === 'delegated'}
	<div class="flex flex-col items-center justify-center py-12 text-center">
		<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color: var(--text-faint)" class="mb-3">
			<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" />
			<polyline points="13 2 13 9 20 9" />
		</svg>
		<p class="text-sm" style="color: var(--text-muted)">SDK sessions don't capture file activity in the session file</p>
	</div>
{:else if files().length === 0}
	<div class="flex flex-col items-center justify-center py-12 text-center">
		<p class="text-sm" style="color: var(--text-muted)">No file activity recorded</p>
	</div>
{:else}
	<div class="table-container" style="border: none; border-radius: 0;">
		<table>
			<thead>
				<tr>
					<th>File</th>
					<th>Actions</th>
					<th>Count</th>
				</tr>
			</thead>
			<tbody>
				{#each files() as file}
					<tr>
						<td>
							<span class="font-mono text-xs" style="color: var(--text-secondary)" title={file.path}>
								{shortenPath(file.path)}
							</span>
						</td>
						<td>
							<div class="flex gap-1 flex-wrap">
								{#each Object.entries(file.actions) as [action, count]}
									<span
										class="text-[10px] font-medium px-1.5 py-0.5 rounded"
										style="background: {actionBg(action)}; color: {actionColor(action)};"
									>
										{action} ({count})
									</span>
								{/each}
							</div>
						</td>
						<td>
							<span class="font-mono text-xs" style="color: var(--text-muted)">{file.total}</span>
						</td>
					</tr>
				{/each}
			</tbody>
		</table>
	</div>
{/if}
