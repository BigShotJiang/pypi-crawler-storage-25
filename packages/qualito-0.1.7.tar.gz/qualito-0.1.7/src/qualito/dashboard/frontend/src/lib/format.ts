/**
 * Format an ISO date string to a human-readable local format.
 */
export function formatDate(iso: string | null | undefined): string {
	if (!iso) return '—';
	const d = new Date(iso);
	return d.toLocaleDateString('en-US', {
		month: 'short',
		day: 'numeric',
		hour: '2-digit',
		minute: '2-digit'
	});
}

/**
 * Format seconds into a human-readable duration (e.g. "2m 34s").
 */
export function formatDuration(seconds: number | null | undefined): string {
	if (seconds == null) return '—';
	if (seconds < 60) return `${Math.round(seconds)}s`;
	const m = Math.floor(seconds / 60);
	const s = Math.round(seconds % 60);
	if (m < 60) return `${m}m ${s}s`;
	const h = Math.floor(m / 60);
	const rm = m % 60;
	return `${h}h ${rm}m`;
}

/**
 * Format a USD cost value.
 */
export function formatCost(usd: number | null | undefined): string {
	if (usd == null) return '—';
	if (usd < 0.01) return `$${usd.toFixed(4)}`;
	if (usd < 1) return `$${usd.toFixed(3)}`;
	return `$${usd.toFixed(2)}`;
}

/**
 * Format a number as a percentage.
 */
export function formatPercent(value: number | null | undefined, decimals = 1): string {
	if (value == null) return '—';
	return `${(value * 100).toFixed(decimals)}%`;
}

/**
 * Return the CSS color variable for a DQI score.
 */
export function dqiColor(score: number | null | undefined): string {
	if (score == null) return 'var(--text-muted)';
	if (score >= 0.8) return 'var(--success)';
	if (score >= 0.6) return 'var(--accent)';
	if (score >= 0.4) return 'var(--warning)';
	return 'var(--error)';
}

/**
 * Return the CSS color variable for an incident severity.
 */
export function severityColor(severity: string): string {
	switch (severity) {
		case 'critical':
			return 'var(--error)';
		case 'warning':
			return 'var(--warning)';
		case 'info':
			return 'var(--info)';
		default:
			return 'var(--text-muted)';
	}
}

/**
 * Format milliseconds into a human-readable duration.
 */
export function formatDurationMs(ms: number | null | undefined): string {
	if (ms == null) return '\u2014';
	const secs = ms / 1000;
	if (secs < 60) return `${Math.round(secs)}s`;
	const m = Math.floor(secs / 60);
	const s = Math.round(secs % 60);
	if (m < 60) return `${m}m ${s}s`;
	const h = Math.floor(m / 60);
	const rm = m % 60;
	return `${h}h ${rm}m`;
}

/**
 * Derive a short model name from the full model string.
 */
export function shortModelName(model: string | null | undefined): string {
	if (!model || model === '<synthetic>') return '\u2014';
	if (model.includes('opus')) return 'opus';
	if (model.includes('sonnet')) return 'sonnet';
	if (model.includes('haiku')) return 'haiku';
	return model;
}

/**
 * Format cost with tilde estimate prefix.
 */
export function formatEstimateCost(usd: number | null | undefined): string {
	if (usd == null) return '\u2014';
	if (usd < 0.01) return `~$${usd.toFixed(4)}`;
	if (usd < 1) return `~$${usd.toFixed(3)}`;
	return `~$${usd.toFixed(2)}`;
}

/**
 * Get display name for a run — session name or truncated task.
 */
export function runDisplayName(run: { session_name?: string | null; task?: string }): string {
	if (run.session_name) return run.session_name;
	const task = run.task || '(untitled session)';
	return task.length > 60 ? task.slice(0, 57) + '\u2026' : task;
}
