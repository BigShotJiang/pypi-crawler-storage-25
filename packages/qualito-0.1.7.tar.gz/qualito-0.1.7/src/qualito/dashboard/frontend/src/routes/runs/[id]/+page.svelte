<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import Breadcrumb from '$lib/components/Breadcrumb.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import Card from '$lib/components/Card.svelte';
	import OverviewTab from '$lib/components/OverviewTab.svelte';
	import ConversationTab from '$lib/components/ConversationTab.svelte';
	import ToolCallsTab from '$lib/components/ToolCallsTab.svelte';
	import FilesTab from '$lib/components/FilesTab.svelte';
	import ErrorsTab from '$lib/components/ErrorsTab.svelte';
	import LockedTab from '$lib/components/LockedTab.svelte';
	import { getRun } from '$lib/api';
	import { formatDate, formatEstimateCost, formatDurationMs, shortModelName, dqiColor, runDisplayName } from '$lib/format';
	import type { RunDetail } from '$lib/types';

	let run = $state<RunDetail | null>(null);
	let error = $state<string | null>(null);
	let activeTab = $state('overview');

	let runId = $derived($page.params.id ?? '');

	onMount(async () => {
		try {
			run = await getRun(runId!);
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load run';
		}
	});

	function sessionTypeBadge(type: string | null): { variant: 'info' | 'accent' | 'neutral'; text: string } {
		if (type === 'interactive') return { variant: 'info', text: 'interactive' };
		if (type === 'delegated') return { variant: 'accent', text: 'delegated' };
		return { variant: 'neutral', text: type || 'unknown' };
	}

	let displayTitle = $derived(() => {
		if (!run) return '';
		return runDisplayName(run);
	});

	let badge = $derived(() => {
		if (!run) return { variant: 'neutral' as const, text: '' };
		return sessionTypeBadge(run.session_type);
	});

	let totalFiles = $derived(() => {
		if (!run) return 0;
		return Object.keys(run.files_summary ?? {}).length;
	});

	const tabs = [
		{ id: 'overview', label: 'Overview', locked: false },
		{ id: 'conversation', label: 'Conversation', locked: false },
		{ id: 'tools', label: 'Tool Calls', locked: false },
		{ id: 'files', label: 'Files', locked: false },
		{ id: 'errors', label: 'Errors', locked: false },
		{ id: 'delegation', label: 'Delegation', locked: true },
		{ id: 'artifacts', label: 'Artifacts', locked: true },
		{ id: 'reasoning', label: 'Reasoning', locked: true },
	];
</script>

<div class="space-y-5">
	<Breadcrumb items={[
		{ label: 'Sessions', href: '/runs' },
		{ label: runId.slice(0, 8) }
	]} />

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !run}
		<div class="space-y-4">
			<div class="skeleton h-10 w-64 rounded-lg"></div>
			<div class="skeleton h-24 rounded-xl"></div>
			<div class="skeleton h-8 rounded-lg"></div>
			<div class="skeleton h-64 rounded-xl"></div>
		</div>
	{:else}
		<!-- Header -->
		<div class="flex flex-wrap items-center gap-3">
			<h1 class="text-lg font-semibold" style="color: var(--text)">{displayTitle()}</h1>
			<Badge variant={badge().variant} text={badge().text} />
		</div>

		<!-- Metadata row -->
		<div class="card p-4">
			<div class="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-4">
				<!-- DQI -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">DQI</p>
					{#if run.dqi != null}
						<p class="text-lg font-semibold font-mono" style="color: {dqiColor(run.dqi)}">
							{(run.dqi * 100).toFixed(0)}
						</p>
					{:else}
						<div class="flex items-center gap-1.5">
							<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--text-faint)">
								<rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
								<path d="M7 11V7a5 5 0 0 1 10 0v4" />
							</svg>
							<span class="text-[10px]" style="color: var(--text-faint)">Tag to unlock</span>
						</div>
					{/if}
				</div>
				<!-- Started -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Started</p>
					<p class="text-sm" style="color: var(--text-secondary)">{formatDate(run.started_at)}</p>
				</div>
				<!-- Workspace -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Workspace</p>
					{#if run.workspace}
						<span class="badge badge-accent">{run.workspace}</span>
					{:else}
						<span class="text-sm" style="color: var(--text-faint)">&mdash;</span>
					{/if}
				</div>
				<!-- Type -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Type</p>
					<Badge variant={badge().variant} text={badge().text} />
				</div>
				<!-- Status -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Status</p>
					<span class="text-sm" style="color: var(--text-faint)">&mdash;</span>
				</div>
				<!-- Model -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Model</p>
					<p class="font-mono text-sm" style="color: var(--text-secondary)">{shortModelName(run.model)}</p>
				</div>
				<!-- Cost -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Cost</p>
					<p class="font-mono text-sm" style="color: var(--text-secondary)">{formatEstimateCost(run.cost_usd)}</p>
				</div>
				<!-- Files -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Files</p>
					<p class="font-mono text-sm" style="color: var(--text-secondary)">{totalFiles()}</p>
				</div>
				<!-- Duration -->
				<div>
					<p class="text-[10px] font-semibold uppercase tracking-wider mb-1" style="color: var(--text-faint)">Duration</p>
					<p class="text-sm" style="color: var(--text-secondary)">{formatDurationMs(run.duration_ms)}</p>
				</div>
			</div>
		</div>

		<!-- Tabs -->
		<div>
			<!-- Tab bar -->
			<div class="flex flex-wrap gap-0 overflow-x-auto" style="border-bottom: 1px solid var(--border);">
				{#each tabs as tab}
					<button
						class="px-4 py-2.5 text-xs font-medium transition-all duration-150 relative whitespace-nowrap flex items-center gap-1.5"
						style="color: {activeTab === tab.id ? 'var(--text)' : 'var(--text-muted)'}; background: transparent; border: none; cursor: pointer;"
						onclick={() => activeTab = tab.id}
					>
						{#if tab.locked}
							<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--text-faint); flex-shrink: 0;">
								<rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
								<path d="M7 11V7a5 5 0 0 1 10 0v4" />
							</svg>
						{/if}
						{tab.label}
						{#if activeTab === tab.id}
							<div class="absolute bottom-0 left-0 right-0 h-0.5" style="background: var(--accent)"></div>
						{/if}
					</button>
				{/each}
			</div>

			<!-- Tab content -->
			<div class="card" style="border-top: none; border-top-left-radius: 0; border-top-right-radius: 0;">
				{#if activeTab === 'overview'}
					<div class="p-4">
						<OverviewTab {run} />
					</div>
				{:else if activeTab === 'conversation'}
					<ConversationTab runId={run.id} sessionType={run.session_type} />
				{:else if activeTab === 'tools'}
					<ToolCallsTab toolCalls={run.tool_calls ?? []} sessionType={run.session_type} />
				{:else if activeTab === 'files'}
					<FilesTab fileActivity={run.file_activity ?? []} filesSummary={run.files_summary ?? {}} sessionType={run.session_type} />
				{:else if activeTab === 'errors'}
					<ErrorsTab toolCalls={run.tool_calls ?? []} sessionType={run.session_type} errorCount={run.error_count ?? 0} />
				{:else if activeTab === 'delegation'}
					<LockedTab
						title="Pipeline tracking available with qualito run"
						description="Track researcher, implementer, and verifier stages. See which phase each tool call belongs to and how the pipeline progresses."
						ctaText="Learn more"
					/>
				{:else if activeTab === 'artifacts'}
					<LockedTab
						title="Artifact tracking available with qualito run"
						description="Capture code snippets, documentation, and outputs from each session automatically."
						ctaText="Learn more"
					/>
				{:else if activeTab === 'reasoning'}
					<LockedTab
						title="Reasoning chains available with qualito run"
						description="See the decision process behind each action. Understand why the agent chose one approach over another."
						ctaText="Learn more"
					/>
				{/if}
			</div>
		</div>
	{/if}
</div>
