<script lang="ts">
	import { onMount } from 'svelte';
	import { getRunConversation } from '$lib/api';
	import type { ConversationMessage } from '$lib/types';

	interface Props {
		runId: string;
		sessionType: string | null;
	}

	let { runId, sessionType }: Props = $props();

	let messages = $state<ConversationMessage[]>([]);
	let loading = $state(true);
	let error = $state<string | null>(null);
	let expanded = $state(true);

	onMount(async () => {
		try {
			const data = await getRunConversation(runId);
			messages = data.messages;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load conversation';
		} finally {
			loading = false;
		}
	});

	function formatTimestamp(ts: string | null): string {
		if (!ts) return '';
		const d = new Date(ts);
		return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
	}

	function truncateContent(content: string, maxLen = 2000): string {
		if (content.length <= maxLen) return content;
		return content.slice(0, maxLen) + '\n\n... (truncated)';
	}
</script>

<div class="space-y-3">
	{#if sessionType === 'delegated'}
		<div class="flex flex-col items-center justify-center py-12 text-center">
			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="color: var(--text-faint)" class="mb-3">
				<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
			</svg>
			<p class="text-sm" style="color: var(--text-muted)">SDK sessions capture limited conversation data</p>
			<p class="text-xs mt-1" style="color: var(--text-faint)">
				The prompt is available in the Overview tab
			</p>
		</div>
	{:else if loading}
		<div class="space-y-3 p-4">
			{#each Array(4) as _}
				<div class="skeleton h-16 rounded-lg"></div>
			{/each}
		</div>
	{:else if error}
		<div class="p-4">
			<p class="text-sm" style="color: var(--error)">{error}</p>
		</div>
	{:else if messages.length === 0}
		<div class="flex flex-col items-center justify-center py-12 text-center">
			<p class="text-sm" style="color: var(--text-muted)">No conversation data available</p>
		</div>
	{:else}
		<div class="flex items-center justify-between p-3" style="border-bottom: 1px solid var(--border-subtle)">
			<span class="text-xs font-semibold uppercase tracking-wider" style="color: var(--text-faint)">
				{messages.length} message{messages.length !== 1 ? 's' : ''}
			</span>
			<button
				class="text-xs font-medium px-2 py-1 rounded" style="color: var(--text-muted); background: var(--bg-inset);"
				onclick={() => expanded = !expanded}
			>
				{expanded ? 'Collapse' : 'Expand'}
			</button>
		</div>

		{#if expanded}
			<div class="space-y-2 p-3 max-h-[600px] overflow-y-auto">
				{#each messages as msg}
					<div class="flex gap-3 {msg.role === 'user' ? '' : 'flex-row-reverse'}">
						<!-- Avatar -->
						<div
							class="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-semibold"
							style="background: {msg.role === 'user' ? 'var(--info-muted)' : 'var(--accent-subtle)'}; color: {msg.role === 'user' ? 'var(--info)' : 'var(--accent)'};"
						>
							{msg.role === 'user' ? 'U' : 'A'}
						</div>
						<!-- Message -->
						<div
							class="max-w-[80%] rounded-lg p-3"
							style="background: {msg.role === 'user' ? 'var(--bg-elevated)' : 'var(--bg-card)'}; border: 1px solid var(--border-subtle);"
						>
							<pre class="text-xs whitespace-pre-wrap break-words" style="color: var(--text-secondary); font-family: inherit;">{truncateContent(msg.content)}</pre>
							{#if msg.timestamp}
								<span class="text-[10px] block mt-1.5" style="color: var(--text-faint)">{formatTimestamp(msg.timestamp)}</span>
							{/if}
						</div>
					</div>
				{/each}
			</div>
		{/if}
	{/if}
</div>
