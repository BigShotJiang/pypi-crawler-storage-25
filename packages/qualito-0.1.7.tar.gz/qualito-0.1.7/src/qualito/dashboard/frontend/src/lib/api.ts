import type {
  DashboardData,
  MetricsData,
  Run,
  RunDetail,
  ConversationData,
  Experiment,
  Incident,
  IncidentEvent,
  TransitionDef,
  User,
  ApiKey,
  BillingStatus,
  SetupEvent,
} from "./types";

const BASE = (import.meta.env.VITE_API_URL || "") + "/api";

function getAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };
  const token =
    typeof localStorage !== "undefined"
      ? localStorage.getItem("qualito_token")
      : null;
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
}

async function fetchJSON<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: getAuthHeaders(),
    ...init,
  });
  if (!res.ok) {
    const text = await res.text().catch(() => res.statusText);
    throw new Error(`API ${res.status}: ${text}`);
  }
  return res.json();
}

// Dashboard
export function getDashboard(): Promise<DashboardData> {
  return fetchJSON("/dashboard");
}

// Runs
export function listRuns(params?: {
  limit?: number;
  offset?: number;
  status?: string;
  workspace?: string;
  task_type?: string;
  since?: string;
  session_type?: string;
  model?: string;
  has_subagents?: boolean;
}): Promise<{ runs: Run[]; total: number }> {
  const q = new URLSearchParams();
  if (params?.limit) q.set("limit", String(params.limit));
  if (params?.offset) q.set("offset", String(params.offset));
  if (params?.status) q.set("status", params.status);
  if (params?.workspace) q.set("workspace", params.workspace);
  if (params?.task_type) q.set("task_type", params.task_type);
  if (params?.since) q.set("since", params.since);
  if (params?.session_type) q.set("session_type", params.session_type);
  if (params?.model) q.set("model", params.model);
  if (params?.has_subagents !== undefined)
    q.set("has_subagents", String(params.has_subagents));
  const qs = q.toString();
  return fetchJSON(`/runs${qs ? `?${qs}` : ""}`);
}

export function getRun(id: string): Promise<RunDetail> {
  return fetchJSON(`/runs/${id}`);
}

export function getRunConversation(
  id: string,
): Promise<ConversationData> {
  return fetchJSON(`/runs/${id}/conversation`);
}

// Metrics
export function getMetrics(params?: {
  days?: number;
  workspace?: string;
}): Promise<MetricsData> {
  const q = new URLSearchParams();
  if (params?.days) q.set("days", String(params.days));
  if (params?.workspace) q.set("workspace", params.workspace);
  return fetchJSON(`/metrics?${q.toString()}`);
}

// Experiments
export function listExperiments(): Promise<{ experiments: Experiment[] }> {
  return fetchJSON("/experiments");
}

export function getExperiment(id: string): Promise<Experiment> {
  return fetchJSON(`/experiments/${id}`);
}

export function getExperimentTransitions(
  id: string,
): Promise<{ current_status: string; available_transitions: string[] }> {
  return fetchJSON(`/experiments/${id}/transitions`);
}

export function transitionExperiment(
  id: string,
  status: string,
): Promise<{ id: number; status: string }> {
  return fetchJSON(`/experiments/${id}/transition`, {
    method: "POST",
    body: JSON.stringify({ status }),
  });
}

export function compareExperiments(
  beforeId: number,
  afterId: number,
): Promise<unknown> {
  return fetchJSON(`/experiments/compare/${beforeId}/${afterId}`);
}

// Incidents
export function listIncidents(params?: {
  status?: string;
  severity?: string;
  workspace?: string;
}): Promise<{ incidents: Incident[] }> {
  const q = new URLSearchParams();
  if (params?.status) q.set("status", params.status);
  if (params?.severity) q.set("severity", params.severity);
  if (params?.workspace) q.set("workspace", params.workspace);
  const qs = q.toString();
  return fetchJSON(`/incidents${qs ? `?${qs}` : ""}`);
}

export function getIncident(
  id: string,
): Promise<Incident & { events: IncidentEvent[] }> {
  return fetchJSON(`/incidents/${id}`);
}

export function getIncidentSummary(): Promise<{
  total: number;
  by_severity: Record<string, number>;
}> {
  return fetchJSON("/incidents/summary");
}

// SLO
export function getSloData(): Promise<unknown> {
  return fetchJSON("/incidents/slo");
}

// Config
export function getConfig(): Promise<Record<string, unknown>> {
  return fetchJSON("/config");
}

export function updateConfig(
  config: Record<string, unknown>,
): Promise<Record<string, unknown>> {
  return fetchJSON("/config", {
    method: "PUT",
    body: JSON.stringify(config),
  });
}

// Auth
export function register(
  email: string,
  password: string,
  name?: string,
  consent?: {
    tos_accepted: boolean;
    privacy_accepted: boolean;
    marketing_opt_in: boolean;
  },
): Promise<{ user: User; token: string; setup_token: string; api_key: string }> {
  return fetchJSON("/auth/register", {
    method: "POST",
    body: JSON.stringify({ email, password, name, ...consent }),
  });
}

export function login(
  email: string,
  password: string,
): Promise<{ user: User; token: string }> {
  return fetchJSON("/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
}

export function getMe(): Promise<User> {
  return fetchJSON("/auth/me");
}

export function createApiKey(
  name?: string,
): Promise<{ key: string; api_key: ApiKey }> {
  return fetchJSON("/auth/api-keys", {
    method: "POST",
    body: JSON.stringify({ name }),
  });
}

export function listApiKeys(): Promise<{ api_keys: ApiKey[] }> {
  return fetchJSON("/auth/api-keys");
}

export function revokeApiKey(id: number): Promise<{ revoked: boolean }> {
  return fetchJSON(`/auth/api-keys/${id}`, { method: "DELETE" });
}

export function deleteAccount(): Promise<{ deleted: boolean }> {
  return fetchJSON("/auth/account", { method: "DELETE" });
}

export function deleteAllData(): Promise<{ deleted_runs: number }> {
  return fetchJSON("/auth/data", { method: "DELETE" });
}

// Billing
export function createCheckout(): Promise<{ url: string }> {
  return fetchJSON("/billing/checkout", { method: "POST" });
}

export function getBillingStatus(): Promise<BillingStatus> {
  return fetchJSON("/billing/status");
}

export function cancelSubscription(): Promise<{ cancelled: boolean }> {
  return fetchJSON("/billing/cancel", { method: "POST" });
}

export function createPortalSession(): Promise<{ url: string }> {
  return fetchJSON("/billing/portal", { method: "POST" });
}

// Email verification + password reset
export function verifyEmail(
  token: string,
): Promise<{ verified: boolean }> {
  return fetchJSON("/auth/verify-email", {
    method: "POST",
    body: JSON.stringify({ token }),
  });
}

export function resendVerification(): Promise<{ message: string }> {
  return fetchJSON("/auth/resend-verification", { method: "POST" });
}

export function forgotPassword(
  email: string,
): Promise<{ message: string }> {
  return fetchJSON("/auth/forgot-password", {
    method: "POST",
    body: JSON.stringify({ email }),
  });
}

export function resetPassword(
  token: string,
  password: string,
): Promise<{ reset: boolean }> {
  return fetchJSON("/auth/reset-password", {
    method: "POST",
    body: JSON.stringify({ token, password }),
  });
}

// Setup
export function subscribeToSetupEvents(
  token: string,
  onEvent: (data: SetupEvent) => void,
): () => void {
  const url = `${BASE}/setup/events?token=${encodeURIComponent(token)}`;
  const eventSource = new EventSource(url);

  eventSource.onmessage = (event) => {
    try {
      const data: SetupEvent = JSON.parse(event.data);
      onEvent(data);
    } catch {
      // ignore malformed events
    }
  };

  eventSource.onerror = () => {
    // EventSource auto-reconnects on transient errors
  };

  // Return cleanup function
  return () => eventSource.close();
}
