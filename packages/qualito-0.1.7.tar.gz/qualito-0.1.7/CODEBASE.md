# Qualito Codebase Map

## Project Structure

```
qualito/
  pyproject.toml          # Package config (hatchling, click CLI, 4 optional dep groups)
  Dockerfile              # Railway deployment (Python 3.13-slim + uv)
  railway.json            # Railway build config
  .env.example            # Environment variables template
  LICENSE                 # MIT
  CODEBASE.md             # This file
  README.md               # Product README with quick start + CLI reference
  landing/                # Standalone landing page (qualito.ai) — Vite + vanilla HTML/CSS/JS
    index.html            # Full static landing page (13 sections)
    style.css             # Design system + all page styles
    main.js               # Copy buttons, FAQ accordion, mobile nav, smooth scroll
    vercel.json           # Vercel deployment config
    package.json          # Minimal: vite as dev dependency
  src/qualito/
    __init__.py            # Package root, __version__
    config.py              # Config: QualityConfig, get_global_dir(), load_config(), init_project(local=False)
    importer.py            # Session importer: discover_all_projects(), import_project(), reimport_all(). Session classification (interactive/delegated/vscode), metadata extraction, model-aware cost, conversation storage.
    cloud.py               # Cloud sync client: login, sync runs/incidents to hosted API
    core/                  # Core library modules (no CLI, no hardcoded paths)
      __init__.py          # Re-exports all public APIs
      db.py                # SQLAlchemy Core: 19 SA Table defs, get_engine(), init_db(), get_sa_connection(), all CRUD functions. Dual-backend: SQLite (local) / PostgreSQL (DATABASE_URL)
      dqi.py               # DQI calculator: calculate_dqi() (pure), store_dqi()
      evaluator.py         # Auto-eval engine: 8 checks, human_score()
      stream_parser.py     # Claude stream-json parser: parse_stream() -> ParsedStream
      measure.py           # Measurement: baselines, Bayesian comparison, CUSUM monitor
      benchmark.py         # Benchmark suites, experiment runner, statistical comparison
      pattern_detector.py  # Repeated task pattern detection + classification
      feedback_loop.py     # Warning generation for underperforming combos
      incident_detector.py # Incident detection: 4 rules, workspace baselines, auto-resolve
    cli/
      __init__.py
      main.py              # Click CLI: 13 commands (setup, init, status, import, reimport, score, costs, incidents, slo, dashboard, login, sync, logout)
      migrate.py           # qualito-migrate: SQLite → PostgreSQL data migration tool
    mcp/
      __init__.py
      server.py            # MCP server: 8 tools (FastMCP, stdio transport)
    dashboard/
      __init__.py
      app.py               # FastAPI factory, CORS, rate limiting, MCP mount, OAuth 2.0 endpoints (discovery, register, authorize, token), static files
      api.py               # 19 API endpoints (dashboard, runs, run deletion single+batch, metrics, experiments, incidents, SLO, config, sync)
      admin_routes.py      # 6 admin endpoints (list/create/delete users, suspend/activate, role management). Protected by get_admin_user.
      auth.py              # Auth service: JWT, bcrypt, API keys, user management, admin guard
      auth_routes.py       # 14 auth endpoints (register, login, me, API keys, CLI token, account deletion, delete all data, email verification, password reset). Rate limited.
      billing.py           # Stripe integration: checkout, 7 webhook handlers, Customer Portal, subscription management, idempotency
      billing_routes.py    # 5 billing endpoints (checkout, webhook, status, cancel, portal)
      email.py             # Resend email service: 6 email types (welcome, verification, reset, subscription, payment failed, cancellation). Graceful degradation.
      email_webhook.py     # Resend webhook endpoint: delivery tracking (sent, delivered, bounced, complained, delayed). svix signature verification.
      mcp_routes.py        # Remote MCP server: 9 tools (7 data + qualito_status + qualito_delete_runs) over Streamable HTTP, OAuth 2.0 token verification
      mcp_oauth.py         # OAuth 2.0 provider for MCP: in-memory client/token storage, API key authorization form, token verifier
      setup_routes.py      # 3 setup endpoints (validate token, report progress, SSE events)
      frontend/            # SvelteKit 5 + Tailwind 4 dashboard
        src/
          app.css          # Design system (teal #14b8a6 accent, dark theme)
          app.html         # Shell with Inter + JetBrains Mono fonts
          routes/          # 8 pages + 1 layout
            +layout.svelte     # Sidebar nav, SSE, auth guard, incident badge. Public pages: /login, /reset-password, /verify-email (no auth required).
            +page.svelte       # Dashboard: SSE onboarding tracker OR DQI gauge + stats + runs
            login/             # Login/register form (stores setup_token on register)
            runs/              # Run list (filters, table) + [id] detail (DQI breakdown)
            metrics/           # Charts: DQI trend, cost trend, by-workspace, by-type
            experiments/       # Experiment cards + [id] detail + compare
            incidents/         # Incident list + [id] detail (timeline, report slide panel)
            slo/               # SLO gauges (quality, availability, cost)
            settings/          # Account, API keys, billing, plan management
          lib/
            api.ts             # 25 typed fetch wrappers (auth-aware, JWT, SSE subscription)
            types.ts           # 20 TypeScript interfaces (Run, Experiment, Incident, User, SetupEvent, etc.)
            format.ts          # Date, cost, duration, DQI color formatting
            sse.ts             # SSE client with auto-reconnect
            dqi-constants.ts   # Tier labels, colors, weights
            components/        # 15 reusable Svelte components
              Badge.svelte, Breadcrumb.svelte, Card.svelte, Chart.svelte,
              DqiBreakdown.svelte, DqiGauge.svelte, Landing.svelte, SlidePanel.svelte, StatusBadge.svelte,
              OverviewTab.svelte, ConversationTab.svelte, ToolCallsTab.svelte, FilesTab.svelte, ErrorsTab.svelte, LockedTab.svelte
        vercel.json        # Vercel deployment config (API rewrites)
  tests/
    __init__.py
    test_smoke.py          # 16 import + function tests
    test_config.py         # 10 config + CLI tests (monkeypatched Path.home)
    test_global.py         # 21 global dir, discovery, cross-platform, idempotent import tests
    test_setup.py          # 35 setup command + MCP config + API route tests
```

## CLI Commands (13)

| Command | What |
|---|---|
| `qualito setup [token]` | Interactive wizard (no token) or auto-setup (with setup token). Discovers projects, imports, scores, configures MCP. |
| `qualito init` | Initialize ~/.qualito/ globally (--local for per-project) |
| `qualito status` | Show config, DB, run count |
| `qualito import` | Import Claude Code sessions (--all-projects for cross-project) |
| `qualito score` | DQI scores table with trends |
| `qualito costs` | Cost breakdown + waste analysis |
| `qualito incidents` | Active quality incidents |
| `qualito slo` | SLO compliance (quality, availability, cost) |
| `qualito dashboard` | Launch web dashboard |
| `qualito login` | Authenticate with cloud API |
| `qualito sync` | Push local data to cloud |
| `qualito reimport` | Re-import all sessions with updated extraction (classification, metadata, cost fix) |
| `qualito logout` | Remove cloud credentials |

## API Endpoints (48 + OAuth)

| Method | Path | Purpose |
|---|---|---|
| GET | /api/dashboard | Hero metrics (avg DQI, run count, cost, incidents) |
| GET | /api/runs | Paginated run list with filters |
| GET | /api/runs/{id} | Run detail with evaluations |
| GET | /api/metrics | DQI trend, cost trend, breakdowns |
| GET | /api/experiments | List experiments |
| GET | /api/experiments/{id} | Experiment detail |
| GET | /api/experiments/{id}/transitions | Available state transitions |
| POST | /api/experiments/{id}/transition | Transition experiment status |
| GET | /api/experiments/compare/{before}/{after} | Comparison data |
| GET | /api/incidents | List incidents with filters |
| GET | /api/incidents/{id} | Incident detail with events |
| GET | /api/incidents/summary | Counts by severity |
| GET | /api/incidents/slo | SLO compliance |
| GET | /api/config | Current config |
| PUT | /api/config | Update SLO targets |
| POST | /api/sync/runs | Receive synced runs from CLI |
| POST | /api/sync/incidents | Receive synced incidents from CLI |
| POST | /api/auth/register | Create account + setup token + consent record |
| POST | /api/auth/login | Get JWT token |
| GET | /api/auth/me | Current user |
| POST | /api/auth/api-keys | Create API key |
| GET | /api/auth/api-keys | List API keys |
| DELETE | /api/auth/api-keys/{id} | Revoke API key |
| POST | /api/auth/cli-token | CLI auth token |
| GET | /api/auth/cli-callback | CLI auth callback |
| DELETE | /api/auth/account | Delete user account and all associated data (cascades runs, revokes OAuth tokens) |
| DELETE | /api/auth/data | Delete all synced data, API keys, setup tokens, OAuth tokens (keeps account) |
| POST | /api/auth/verify-email | Validate verification token, set email_verified=True |
| POST | /api/auth/resend-verification | Resend verification email (authenticated, rate limited) |
| POST | /api/auth/forgot-password | Send password reset email (always returns 200) |
| POST | /api/auth/reset-password | Reset password with valid reset token |
| GET | /api/admin/users | List all users (admin only) |
| POST | /api/admin/users | Create user with role (admin only) |
| DELETE | /api/admin/users/{id} | Cascade-delete user (admin only, no self-delete) |
| POST | /api/admin/users/{id}/suspend | Suspend user (admin only) |
| POST | /api/admin/users/{id}/activate | Activate user (admin only) |
| PATCH | /api/admin/users/{id}/role | Change role (admin only, no self-change) |
| POST | /api/billing/checkout | Create Stripe checkout (promo codes enabled) |
| POST | /api/billing/webhook | Stripe webhook (7 events, idempotent, graceful degradation) |
| GET | /api/billing/status | Subscription status |
| POST | /api/billing/cancel | Cancel subscription |
| POST | /api/billing/portal | Create Stripe Customer Portal session |
| DELETE | /api/runs/{id} | Delete single run with cascade (evaluations, tool_calls, file_activity) |
| DELETE | /api/runs | Batch delete by workspace or run_ids |
| POST | /api/email/webhook | Resend delivery webhook (svix verified, updates email_logs) |
| POST | /api/setup/validate | Validate setup token, return API key |
| POST | /api/setup/progress | CLI reports setup step progress |
| GET | /api/setup/events | SSE stream of setup progress |
| GET | /health | Health check |

### OAuth 2.0 Endpoints (MCP authentication, root level)

| Method | Path | Purpose |
|---|---|---|
| GET | /.well-known/oauth-protected-resource | RFC 9470 resource metadata (points to auth server) |
| GET | /.well-known/oauth-authorization-server | RFC 8414 auth server metadata (endpoints, grants, PKCE) |
| POST | /register | OAuth dynamic client registration |
| GET | /authorize | OAuth authorization (redirects to API key form) |
| GET | /mcp-authorize | API key entry form (browser) |
| POST | /mcp-authorize-callback | Validates API key, issues auth code, redirects |
| POST | /token | OAuth token exchange (auth code → access token, PKCE) |

## MCP Tools

### Local MCP Server (8 tools, stdio transport)

| Tool | Purpose |
|---|---|
| dqi_score | DQI score summary: average, trend, component breakdown |
| dqi_cost | Cost analysis: total spend, average per run, waste estimate |
| dqi_patterns | Repeated task pattern detection with classification |
| dqi_warnings | Underperforming workspace/task_type combos |
| dqi_templates | Task type inference and delegation template recommendations |
| dqi_incidents | Quality incidents: regressions, anomalies, severity tracking |
| dqi_slo | SLO compliance: quality, availability, and cost targets |
| qualito_setup | Scan-only: discovers projects or returns existing data summary |

### Remote MCP Server (9 tools, Streamable HTTP at /mcp/)

7 data tools (same as local minus qualito_setup) + qualito_status (onboarding, account info, setup token generation) + qualito_delete_runs (single/batch deletion by workspace or IDs). All queries scoped to authenticated user. Auth: OAuth 2.0 (user enters API key in browser form → server issues OAuth token → MCP SDK validates Bearer token). Stateless HTTP transport with DNS rebinding protection. Install: `claude mcp add -s user --transport http qualito https://api.qualito.ai/mcp/`

## Database (19 tables)

Core: runs (with user_id FK + session_type, entrypoint, claude_version, session_name, has_subagents, subagent_count, error_count, tool_count), tool_calls, file_activity, evaluations, artifacts, conversations (condensed message history, 1:1 with runs), baselines, system_changes, benchmark_suites, experiments, experiment_comparisons, incidents, incident_events

Auth: users, api_keys, setup_tokens (persistent onboarding tokens — survive redeployments)

Billing: processed_events (webhook idempotency), consent (GDPR — ToS/privacy/marketing with version tracking)

Email: email_logs (with delivery_status + delivery_updated_at for webhook tracking)

## Data Storage

- **Global**: `~/.qualito/` (config.toml, qualito.db) — default, cross-project
- **Local**: `.qualito/` in project dir (--local flag) — backward compat
- **Sessions**: `~/.claude/projects/` (read-only, Claude Code creates these)
- **Credentials**: `~/.qualito/credentials.json` (API key for cloud sync)
- **Resolution order**: local `.qualito/` → global `~/.qualito/`

## Key Design Decisions

- **SQLAlchemy Core**: All DB access via SA Core expressions. Dual-backend: SQLite locally, PostgreSQL in production via DATABASE_URL. Zero raw SQL.
- **Global-first**: ~/.qualito/ holds all data across projects. Local .qualito/ is an override.
- **Cloud-first**: CLI collects locally, syncs to hosted API, dashboard is hosted
- **Idempotent imports**: Session ID (JSONL filename) is primary key, re-imports skip existing
- **Cross-platform**: Session discovery works on macOS/Linux/Windows (verified paths)
- **Pure functions where possible**: calculate_dqi() and parse_stream() are side-effect-free
- **Auth**: JWT + API keys + setup tokens (15-min TTL for onboarding)
- **MCP Auth**: OAuth 2.0 (MCP spec requires it for HTTP transport). API key entered in browser form, exchanged for OAuth token. In-memory token storage (clears on redeploy).
- **Email**: Resend transactional emails (6 types). Resend webhooks for delivery tracking (svix signature verification). Graceful degradation when unconfigured.
- **Billing**: Stripe checkout (promo codes) + 7 webhook events (idempotent) + Customer Portal + graceful degradation
- **Consent**: GDPR-compliant — ToS/privacy/marketing recorded with version tracking on registration
- **Rate limiting**: slowapi on auth endpoints (5/min login, 5/min register)
- **Setup token flow**: Register → get st_setup_xxx → CLI validates → gets long-lived API key
- **MCP scan-only**: qualito_setup tool reads data, never imports (avoids MCP timeout)

## Tests (196+)

| File | Count | Coverage |
|---|---|---|
| test_smoke.py | 16 | Module imports, calculate_dqi, parse_stream, DB creation |
| test_config.py | 10 | Config loading, init modes, monkeypatched Path.home |
| test_global.py | 21 | Global dir, discovery, cross-platform paths, idempotent import |
| test_setup.py | 35 | Setup wizard helpers, MCP config, API routes (validate, progress, SSE, expiry) |
| test_sa_tables.py | 12 | SA engine creation, table definitions, init_db idempotency |
| test_sa_crud.py | 35 | SA Core CRUD functions for all core modules |
| test_sa_dashboard.py | 37 | SA dashboard API, auth, billing, admin management |
| test_billing.py | 15 | Webhook idempotency, portal session, consent recording, webhook handlers |
| test_email.py | 17 | Email sending, verification tokens, password reset tokens |
