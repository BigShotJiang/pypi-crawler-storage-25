# Qualito — Quality Tracking for Claude Code

CLI tool + MCP server + cloud dashboard for measuring and improving AI-assisted development quality. Claude Code-specific.

## Architecture

- `src/qualito/core/` — Core modules (DQI calculator, evaluator, stream parser, DB, measurement, benchmarks, pattern detector, feedback loop, incident detector)
- `src/qualito/cli/` — Click CLI: 13 commands (setup, init, status, import, reimport, score, costs, incidents, slo, dashboard, login, sync, logout)
- `src/qualito/mcp/` — MCP server: 8 tools (FastMCP, stdio transport)
- `src/qualito/dashboard/` — FastAPI backend (48 endpoints + OAuth) + SvelteKit frontend (8 pages)
- `landing/` — Static landing page (qualito.ai, Vite + vanilla HTML/CSS/JS)
- `tests/` — 196+ tests across 9 files

## Stack

- **Python 3.11+**, managed with **uv**
- **SQLAlchemy Core** — dual-backend: SQLite (local) / PostgreSQL (DATABASE_URL)
- **FastAPI** — dashboard backend with JWT auth, Stripe billing, rate limiting (slowapi)
- **SvelteKit 5 + Tailwind 4** — dashboard frontend
- **Stripe** — checkout, 7 webhook events (idempotent), Customer Portal, promo codes
- **Resend** — transactional emails (6 types), webhook delivery tracking (svix)
- **click** for CLI, **mcp** SDK for MCP server (OAuth 2.0 for remote HTTP transport)
- **pytest** for testing

## Conventions

- All modules importable as `from qualito.core import ...`
- All DB access via SQLAlchemy Core expressions — zero raw SQL
- `~/.qualito/` global data directory (config.toml, qualito.db)
- `DATABASE_URL` env var switches to PostgreSQL (production)
- Type hints on all public functions
- Docstrings on all modules and public functions
- Auth: JWT + bcrypt + API keys + setup tokens
- MCP auth: OAuth 2.0 (required by MCP spec for HTTP transport). Tokens stored in-memory.
- Email: Resend with graceful degradation. Env vars: RESEND_QUALITO_API_KEY, EMAIL_VERIFY_SECRET, PASSWORD_RESET_SECRET
- GDPR: consent table with version tracking on registration

## Entry Points

- CLI: `qualito = "qualito.cli.main:cli"`
- MCP: `qualito-mcp = "qualito.mcp.server:main"`
- Dashboard: `qualito dashboard` or direct `uvicorn qualito.dashboard.app:create_app`
- Migrate: `qualito-migrate = "qualito.cli.migrate:cli"`

## Key Files

| File | What |
|---|---|
| `src/qualito/core/db.py` | 19 SA tables, engine, all CRUD functions |
| `src/qualito/core/dqi.py` | DQI scoring (pure function + DB storage) |
| `src/qualito/core/evaluator.py` | 8 auto-eval checks + human scoring |
| `src/qualito/core/benchmark.py` | Experiment runner + Wilcoxon/Bayesian comparison |
| `src/qualito/dashboard/billing.py` | Stripe: checkout, 7 webhooks, portal, idempotency |
| `src/qualito/dashboard/auth.py` | JWT, bcrypt, API keys, user management |
| `src/qualito/dashboard/app.py` | FastAPI factory, CORS, rate limiting, OAuth 2.0 endpoints |
| `src/qualito/dashboard/mcp_oauth.py` | OAuth provider + token verifier for MCP auth |
| `src/qualito/dashboard/email.py` | Resend email service (6 types, graceful degradation) |
| `src/qualito/dashboard/email_webhook.py` | Resend delivery webhook (svix verification) |
| `CODEBASE.md` | Full codebase map with all endpoints and tables |
