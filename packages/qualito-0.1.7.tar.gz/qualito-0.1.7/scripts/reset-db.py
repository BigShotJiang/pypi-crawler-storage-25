#!/usr/bin/env python3
"""Reset the Qualito production database.

Deletes all users and data except the admin account.
Connects via DATABASE_PUBLIC_URL or DATABASE_URL.

Usage:
    # Dry run (default) — shows what would be deleted
    python3 scripts/reset-db.py

    # Actually delete
    python3 scripts/reset-db.py --confirm

    # Custom admin email
    python3 scripts/reset-db.py --confirm --admin other@email.com

    # Custom database URL
    DATABASE_PUBLIC_URL=postgresql://... python3 scripts/reset-db.py --confirm
"""

import argparse
import os
import sys

from sqlalchemy import create_engine, text


def get_db_url() -> str:
    """Resolve database URL. Prefers public URL for local access."""
    for var in ("DATABASE_PUBLIC_URL", "DATABASE_URL"):
        url = os.environ.get(var)
        if url:
            if url.startswith("postgres://"):
                url = url.replace("postgres://", "postgresql://", 1)
            return url
    print("Error: Set DATABASE_PUBLIC_URL or DATABASE_URL environment variable.")
    print("Get it from: cd ~/qualito && railway service Postgres && railway variables")
    sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="Reset Qualito database (keep admin)")
    parser.add_argument("--confirm", action="store_true", help="Actually delete (default is dry run)")
    parser.add_argument("--admin", default="mp.web3@gmail.com", help="Admin email to preserve")
    args = parser.parse_args()

    db_url = get_db_url()
    engine = create_engine(db_url)

    with engine.connect() as conn:
        # Show current state
        users = conn.execute(text("SELECT id, email, role FROM users ORDER BY id")).fetchall()
        print(f"Users in database: {len(users)}")
        for u in users:
            marker = " ← KEEP" if u[1] == args.admin else " ← DELETE"
            print(f"  [{u[0]}] {u[1]} ({u[2]}){marker}")

        admin = conn.execute(
            text("SELECT id FROM users WHERE email = :email"),
            {"email": args.admin},
        ).fetchone()
        if not admin:
            print(f"\nError: Admin {args.admin} not found in database.")
            sys.exit(1)
        admin_id = admin[0]

        to_delete = [u for u in users if u[1] != args.admin]
        if not to_delete:
            print("\nNothing to delete — only admin exists.")
            return

        # Check which tables exist
        existing = {row[0] for row in conn.execute(
            text("SELECT tablename FROM pg_tables WHERE schemaname = 'public'")
        ).fetchall()}

        # Count what will be deleted
        counts = {}
        for table in ("runs", "api_keys", "setup_tokens", "consent"):
            row = conn.execute(
                text(f"SELECT count(*) FROM {table} WHERE user_id != :aid"),
                {"aid": admin_id},
            ).fetchone()
            counts[table] = row[0]

        for table in ("tool_calls", "file_activity", "evaluations", "artifacts", "conversations"):
            if table not in existing:
                continue
            row = conn.execute(
                text(f"SELECT count(*) FROM {table} WHERE run_id IN (SELECT id FROM runs WHERE user_id != :aid)"),
                {"aid": admin_id},
            ).fetchone()
            counts[table] = row[0]

        row = conn.execute(
            text("SELECT count(*) FROM email_logs WHERE recipient_email != :email"),
            {"email": args.admin},
        ).fetchone()
        counts["email_logs"] = row[0]

        row = conn.execute(text("SELECT count(*) FROM processed_events")).fetchone()
        counts["processed_events"] = row[0]

        print(f"\nRows to delete:")
        total = 0
        for table, count in counts.items():
            if count > 0:
                print(f"  {table}: {count}")
                total += count
        print(f"  users: {len(to_delete)}")
        total += len(to_delete)
        print(f"  TOTAL: {total}")

        if not args.confirm:
            print("\nDry run — pass --confirm to delete.")
            return

        # Delete in FK order
        print("\nDeleting...")
        for table in ("tool_calls", "file_activity", "evaluations", "artifacts", "conversations"):
            if table not in existing:
                print(f"  {table}: (table not found, skipped)")
                continue
            r = conn.execute(
                text(f"DELETE FROM {table} WHERE run_id IN (SELECT id FROM runs WHERE user_id != :aid)"),
                {"aid": admin_id},
            )
            print(f"  {table}: {r.rowcount}")

        r = conn.execute(text("DELETE FROM runs WHERE user_id != :aid"), {"aid": admin_id})
        print(f"  runs: {r.rowcount}")

        for table in ("api_keys", "setup_tokens", "consent"):
            r = conn.execute(text(f"DELETE FROM {table} WHERE user_id != :aid"), {"aid": admin_id})
            print(f"  {table}: {r.rowcount}")

        r = conn.execute(
            text("DELETE FROM email_logs WHERE recipient_email != :email"),
            {"email": args.admin},
        )
        print(f"  email_logs: {r.rowcount}")

        r = conn.execute(text("DELETE FROM users WHERE id != :aid"), {"aid": admin_id})
        print(f"  users: {r.rowcount}")

        r = conn.execute(text("DELETE FROM processed_events"))
        print(f"  processed_events: {r.rowcount}")

        conn.commit()
        print("\nDone. Only admin remains.")


if __name__ == "__main__":
    main()
