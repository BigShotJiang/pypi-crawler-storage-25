from dataclasses import dataclass, field


@dataclass
class ImportResult:
    file_path: str
    file_hash: str
    file_id: str = ""
    status: str = "success"
    message_count: int = 0
    tables_affected: list[str] = field(default_factory=list)
    error_message: str | None = None
    weather_rows: int = 0

    @property
    def skipped(self):
        return self.status == "skipped"

    @property
    def failed(self):
        return self.status == "error"


@dataclass
class BatchImportResult:
    files_processed: int = 0
    files_imported: int = 0
    files_skipped: int = 0
    files_failed: int = 0
    total_messages: int = 0
    total_weather_rows: int = 0
    results: list[ImportResult] = field(default_factory=list)

    def add(self, result: ImportResult):
        self.results.append(result)
        self.files_processed += 1
        if result.status == "success":
            self.files_imported += 1
            self.total_messages += result.message_count
            self.total_weather_rows += result.weather_rows
        elif result.status == "skipped":
            self.files_skipped += 1
        else:
            self.files_failed += 1
