import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

API_URL = "https://archive-api.open-meteo.com/v1/archive"
WEATHER_VARIABLES = ("temperature_2m", "apparent_temperature", "relativehumidity_2m")
SEMICIRCLE_TO_DEGREE = 180.0 / (2 ** 31)


def semicircles_to_degrees(semicircles):
    return semicircles * SEMICIRCLE_TO_DEGREE


def _parse_iso_utc(s):
    return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp())


def fetch_hourly(lat_deg, lon_deg, date_str, *, timeout=10):
    params = {
        "latitude": f"{lat_deg:.4f}",
        "longitude": f"{lon_deg:.4f}",
        "start_date": date_str,
        "end_date": date_str,
        "hourly": ",".join(WEATHER_VARIABLES),
        "timezone": "UTC",
    }
    url = f"{API_URL}?{urllib.parse.urlencode(params)}"
    with urllib.request.urlopen(url, timeout=timeout) as resp:
        payload = json.loads(resp.read().decode("utf-8"))

    hourly = payload.get("hourly") or {}
    times = hourly.get("time") or []
    temps = hourly.get("temperature_2m") or [None] * len(times)
    apparent = hourly.get("apparent_temperature") or [None] * len(times)
    humidity = hourly.get("relativehumidity_2m") or [None] * len(times)

    rows = []
    for i, iso in enumerate(times):
        rows.append({
            "hour_timestamp": _parse_iso_utc(iso),
            "temperature_c": temps[i] if i < len(temps) else None,
            "apparent_temperature_c": apparent[i] if i < len(apparent) else None,
            "relativehumidity_pct": humidity[i] if i < len(humidity) else None,
        })
    return rows


def fetch_for_session(db, file_hash, start_lat_semi, start_lon_semi, start_unix_ts):
    if start_lat_semi is None or start_lon_semi is None or start_unix_ts is None:
        return 0

    lat = semicircles_to_degrees(start_lat_semi)
    lon = semicircles_to_degrees(start_lon_semi)
    date_str = datetime.fromtimestamp(start_unix_ts, tz=timezone.utc).strftime("%Y-%m-%d")

    try:
        readings = fetch_hourly(lat, lon, date_str)
    except urllib.error.HTTPError as e:
        if e.code == 429:
            logger.warning("Weather API rate limited for %s, will retry on next run", file_hash[:12])
        else:
            logger.warning("Weather API HTTP %d for %s: %s", e.code, file_hash[:12], e.reason)
        return 0
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, ValueError) as e:
        logger.warning("Weather fetch failed for %s: %s", file_hash[:12], e)
        return 0

    if not readings:
        return 0

    rows = [{"file_hash": file_hash, **r} for r in readings]
    try:
        with db.transaction():
            db.insert_rows("weather_hourly", rows)
    except Exception as e:
        logger.warning("Weather insert failed for %s: %s", file_hash[:12], e)
        return 0
    logger.info("Weather: %d rows for %s", len(rows), file_hash[:12])
    return len(rows)


def backfill(db, *, force=False):
    if force:
        sql = """
        SELECT s.file_hash, s.start_position_lat, s.start_position_long,
               COALESCE(s.start_time, s.timestamp) AS ts
        FROM session s
        WHERE s.start_position_lat IS NOT NULL
          AND s.start_position_long IS NOT NULL
          AND COALESCE(s.start_time, s.timestamp) IS NOT NULL
        """
    else:
        sql = """
        SELECT s.file_hash, s.start_position_lat, s.start_position_long,
               COALESCE(s.start_time, s.timestamp) AS ts
        FROM session s
        WHERE s.start_position_lat IS NOT NULL
          AND s.start_position_long IS NOT NULL
          AND COALESCE(s.start_time, s.timestamp) IS NOT NULL
          AND NOT EXISTS (SELECT 1 FROM weather_hourly wh WHERE wh.file_hash = s.file_hash)
        """

    sessions = db.conn.execute(sql).fetchall()
    total = len(sessions)
    if total == 0:
        print("No sessions need weather data.")
        return 0, 0

    print(f"Fetching weather for {total} session(s)...")
    fetched = 0
    warnings = 0
    for i, row in enumerate(sessions, 1):
        fhash = row["file_hash"]
        if force:
            db.conn.execute("DELETE FROM weather_hourly WHERE file_hash = ?", (fhash,))
            db.conn.commit()
        count = fetch_for_session(
            db, fhash, row["start_position_lat"], row["start_position_long"], row["ts"],
        )
        if count > 0:
            fetched += 1
        else:
            warnings += 1
        print(f"  [{i}/{total}] {fhash[:12]} {'OK' if count > 0 else 'skipped'}")

    print(f"Done: {fetched} fetched, {warnings} skipped/failed.")
    return fetched, warnings
