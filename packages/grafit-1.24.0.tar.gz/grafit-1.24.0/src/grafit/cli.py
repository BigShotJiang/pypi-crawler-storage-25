import argparse
import logging
import shutil
import sys
from importlib import resources
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from grafit import weather
from grafit.db import Database
from grafit.schema import generate_full_schema
from grafit.importer import import_directory, import_file


def get_version():
    try:
        return version("grafit")
    except PackageNotFoundError:
        return "unknown"


def cmd_generate_schema(args):
    sql = generate_full_schema()
    output = Path(args.output)
    output.write_text(sql)
    print(f"Schema written to {output} ({len(sql)} bytes)")


def cmd_init(args):
    db_path = Path(args.db_path)
    with Database(db_path) as db:
        db.init_schema()
    print(f"Database initialized: {db_path}")


def cmd_import(args):
    db_path = Path(args.db_path)
    source = Path(args.path)

    with Database(db_path) as db:
        db.init_schema()
        result = import_directory(
            db, source,
            force=args.force,
            recursive=not args.no_recursive,
            fetch_weather=args.fetch_weather,
        )

        print(f"Processed: {result.files_processed}")
        print(f"Imported:  {result.files_imported}")
        print(f"Skipped:   {result.files_skipped}")
        print(f"Failed:    {result.files_failed}")
        print(f"Messages:  {result.total_messages}")
        if args.fetch_weather:
            print(f"Weather:   {result.total_weather_rows} rows from new imports")
            weather.backfill(db)

    if result.files_failed:
        for r in result.results:
            if r.failed:
                print(f"  ERROR: {r.file_path}: {r.error_message}")


def cmd_stats(args):
    db_path = Path(args.db_path)
    with Database(db_path) as db:
        stats = db.get_stats()

    if not stats:
        print("No data in database.")
        return

    max_name = max(len(name) for name in stats)
    for name, count in stats.items():
        print(f"  {name:<{max_name}}  {count:>8}")
    print(f"  {'TOTAL':<{max_name}}  {sum(stats.values()):>8}")


def cmd_purge(args):
    db_path = Path(args.db_path)
    with Database(db_path) as db:
        count = db.purge_file(args.file_hash)
    print(f"Purged {count} rows for hash {args.file_hash}")


def cmd_backfill_weather(args):
    db_path = Path(args.db_path)
    with Database(db_path) as db:
        db.init_schema()
        weather.backfill(db, force=args.force)


def cmd_provisioning_install(args):
    dest = Path(args.dest)
    if dest.exists() and not args.force:
        print(f"Destination exists: {dest} (use --force to overwrite)", file=sys.stderr)
        sys.exit(1)

    source = resources.files("grafit") / "provisioning"
    with resources.as_file(source) as src_path:
        if dest.exists():
            for child in dest.iterdir():
                if child.is_dir() and not child.is_symlink():
                    shutil.rmtree(child)
                else:
                    child.unlink()
            shutil.copytree(src_path, dest, dirs_exist_ok=True)
        else:
            shutil.copytree(src_path, dest)

    print(f"Provisioning files installed to {dest}")


def main():
    ver = get_version()
    print(f"grafit v{ver}", file=sys.stderr)

    parser = argparse.ArgumentParser(prog="grafit", description="Garmin FIT to SQLite loader")
    parser.add_argument("-v", "--verbose", action="store_true")
    parser.add_argument("--version", action="version", version=f"grafit v{ver}")
    sub = parser.add_subparsers(dest="command", required=True)

    p_schema = sub.add_parser("generate-schema", help="Generate DDL SQL from FIT profile")
    p_schema.add_argument("output", help="Output SQL file path")
    p_schema.set_defaults(func=cmd_generate_schema)

    p_init = sub.add_parser("init", help="Create and initialize database")
    p_init.add_argument("db_path", help="SQLite database path")
    p_init.set_defaults(func=cmd_init)

    p_import = sub.add_parser("import", help="Import FIT files into database")
    p_import.add_argument("path", help="FIT file or directory")
    p_import.add_argument("db_path", help="SQLite database path")
    p_import.add_argument("--force", action="store_true", help="Reimport existing files")
    p_import.add_argument("--no-recursive", action="store_true", help="Don't recurse into subdirectories")
    p_import.add_argument(
        "--fetch-weather", action="store_true",
        help="Fetch historical weather (Open-Meteo) for each session's start coords/date",
    )
    p_import.set_defaults(func=cmd_import)

    p_stats = sub.add_parser("stats", help="Show row counts per table")
    p_stats.add_argument("db_path", help="SQLite database path")
    p_stats.set_defaults(func=cmd_stats)

    p_purge = sub.add_parser("purge", help="Remove all data for a file")
    p_purge.add_argument("db_path", help="SQLite database path")
    p_purge.add_argument("--file-hash", required=True, help="SHA-256 hash of file to purge")
    p_purge.set_defaults(func=cmd_purge)

    p_weather = sub.add_parser(
        "backfill-weather",
        help="Fetch historical weather for sessions that don't have it yet",
    )
    p_weather.add_argument("db_path", help="SQLite database path")
    p_weather.add_argument(
        "--force", action="store_true",
        help="Re-fetch weather even for sessions that already have it",
    )
    p_weather.set_defaults(func=cmd_backfill_weather)

    p_prov = sub.add_parser("install-provisioning", help="Install bundled Grafana provisioning files")
    p_prov.add_argument("dest", help="Destination directory (e.g. /etc/grafana/provisioning)")
    p_prov.add_argument("--force", action="store_true", help="Overwrite destination if it exists")
    p_prov.set_defaults(func=cmd_provisioning_install)

    args = parser.parse_args()

    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")

    args.func(args)


if __name__ == "__main__":
    main()
