import sys
from pathlib import Path

from fitparse.profile import MESSAGE_TYPES, FIELD_TYPES
from fitparse.records import BASE_TYPES, Field, SubField, ComponentField

SQL_RESERVED = frozenset({
    "abort", "action", "add", "after", "all", "alter", "always", "analyze",
    "and", "as", "asc", "attach", "autoincrement", "before", "begin", "between",
    "by", "cascade", "case", "cast", "check", "collate", "column", "commit",
    "conflict", "constraint", "create", "cross", "current", "current_date",
    "current_time", "current_timestamp", "database", "default", "deferrable",
    "deferred", "delete", "desc", "detach", "distinct", "do", "drop", "each",
    "else", "end", "escape", "except", "exclude", "exclusive", "exists",
    "explain", "fail", "filter", "first", "following", "for", "foreign", "from",
    "full", "glob", "group", "groups", "having", "if", "ignore", "immediate",
    "in", "index", "indexed", "initially", "inner", "insert", "instead",
    "intersect", "into", "is", "isnull", "join", "key", "last", "left", "like",
    "limit", "match", "materialized", "natural", "no", "not", "nothing",
    "notnull", "null", "nulls", "of", "offset", "on", "or", "order", "others",
    "outer", "over", "partition", "plan", "pragma", "preceding", "primary",
    "query", "raise", "range", "recursive", "references", "regexp", "reindex",
    "release", "rename", "replace", "restrict", "returning", "right", "rollback",
    "row", "rows", "savepoint", "select", "set", "table", "temp", "temporary",
    "then", "ties", "to", "transaction", "trigger", "unbounded", "union",
    "unique", "update", "using", "vacuum", "values", "view", "virtual", "when",
    "where", "window", "with", "without",
})

BASE_TYPE_TO_SQLITE = {
    0x00: "TEXT",      # enum -> store resolved string
    0x01: "INTEGER",   # sint8
    0x02: "INTEGER",   # uint8
    0x83: "INTEGER",   # sint16
    0x84: "INTEGER",   # uint16
    0x85: "INTEGER",   # sint32
    0x86: "INTEGER",   # uint32
    0x07: "TEXT",      # string
    0x88: "REAL",      # float32
    0x89: "REAL",      # float64
    0x0A: "INTEGER",   # uint8z
    0x8B: "INTEGER",   # uint16z
    0x8C: "INTEGER",   # uint32z
    0x0D: "BLOB",      # byte
    0x8E: "INTEGER",   # sint64
    0x8F: "INTEGER",   # uint64
    0x90: "INTEGER",   # uint64z
}


def _quote(name):
    return '"' + name.replace('"', '""') + '"'


def _get_base_type_id(field):
    t = field.type
    if hasattr(t, "identifier"):
        return t.identifier
    if hasattr(t, "base_type") and hasattr(t.base_type, "identifier"):
        return t.base_type.identifier
    return None


def _sqlite_type_for_field(field):
    if getattr(field, "scale", None) is not None:
        return "REAL"
    type_id = _get_base_type_id(field)
    if type_id is not None:
        return BASE_TYPE_TO_SQLITE.get(type_id, "TEXT")
    return "TEXT"


RESERVED_COLUMNS = frozenset({"id", "file_hash", "timestamp"})


def _collect_columns(message_type):
    seen = set()
    columns = []

    for _def_num, field in message_type.fields.items():
        name = field.name.lower()
        if name in RESERVED_COLUMNS:
            continue
        if name not in seen:
            seen.add(name)
            columns.append((name, _sqlite_type_for_field(field)))

        if getattr(field, "subfields", None):
            for sf in field.subfields:
                sf_name = sf.name.lower()
                if sf_name not in seen and sf_name not in RESERVED_COLUMNS:
                    seen.add(sf_name)
                    columns.append((sf_name, _sqlite_type_for_field(sf)))

    return columns


def _has_timestamp(message_type):
    return any(f.name.lower() == "timestamp" for f in message_type.fields.values())


def generate_table_ddl(message_name, message_type):
    table = _quote(message_name)
    raw_name = message_name

    lines = [
        f"CREATE TABLE IF NOT EXISTS {table} (",
        "    id INTEGER PRIMARY KEY AUTOINCREMENT,",
        "    file_hash TEXT NOT NULL,",
    ]

    has_ts = _has_timestamp(message_type)
    if has_ts:
        lines.append("    timestamp INTEGER,")

    for col_name, col_type in _collect_columns(message_type):
        lines.append(f"    {_quote(col_name)} {col_type},")

    last = lines[-1]
    lines[-1] = last.rstrip(",")
    lines.append(");")

    stmts = ["\n".join(lines)]

    stmts.append(
        f"CREATE INDEX IF NOT EXISTS idx_{raw_name}_file_hash ON {table}(file_hash);"
    )
    if has_ts:
        stmts.append(
            f"CREATE INDEX IF NOT EXISTS idx_{raw_name}_timestamp ON {table}(timestamp);"
        )
        stmts.append(
            f"CREATE INDEX IF NOT EXISTS idx_{raw_name}_file_hash_timestamp "
            f"ON {table}(file_hash, timestamp);"
        )

    if raw_name == "session":
        stmts.append(
            f"CREATE INDEX IF NOT EXISTS idx_session_sport ON {table}(sport);"
        )

    return "\n".join(stmts)


def generate_tracking_tables():
    return """CREATE TABLE IF NOT EXISTS _import_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_hash TEXT NOT NULL UNIQUE,
    file_path TEXT NOT NULL,
    file_id TEXT NOT NULL,
    file_dir TEXT NOT NULL,
    file_size INTEGER,
    imported_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now')),
    message_count INTEGER,
    status TEXT NOT NULL DEFAULT 'success',
    error_message TEXT
);

CREATE TABLE IF NOT EXISTS _schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now'))
);

CREATE TABLE IF NOT EXISTS _field_overflow (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_hash TEXT NOT NULL,
    message_type TEXT NOT NULL,
    timestamp INTEGER,
    field_name TEXT NOT NULL,
    field_value TEXT,
    field_units TEXT,
    field_type TEXT
);
CREATE INDEX IF NOT EXISTS idx__field_overflow_file_hash ON _field_overflow(file_hash);
CREATE INDEX IF NOT EXISTS idx__field_overflow_message_type ON _field_overflow(message_type);"""


def generate_extension_tables():
    return """CREATE TABLE IF NOT EXISTS weather_hourly (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_hash TEXT NOT NULL,
    hour_timestamp INTEGER NOT NULL,
    temperature_c REAL,
    apparent_temperature_c REAL,
    relativehumidity_pct REAL,
    fetched_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now')),
    UNIQUE(file_hash, hour_timestamp)
);
CREATE INDEX IF NOT EXISTS idx_weather_hourly_file_hash ON weather_hourly(file_hash);
CREATE INDEX IF NOT EXISTS idx_weather_hourly_hour ON weather_hourly(hour_timestamp);"""


def generate_views():
    return """DROP VIEW IF EXISTS record_v;
CREATE VIEW record_v AS
SELECT r.*, il.file_id FROM record r
JOIN _import_log il ON r.file_hash = il.file_hash;

DROP VIEW IF EXISTS session_v;
CREATE VIEW session_v AS
SELECT s.*, il.file_id,
  (SELECT a.local_timestamp - a.timestamp FROM activity a
   WHERE a.file_hash = s.file_hash
     AND a.local_timestamp IS NOT NULL
     AND a.timestamp IS NOT NULL
   LIMIT 1) AS tz_offset_seconds,
  COALESCE(s.start_time, s.timestamp) + COALESCE(
    (SELECT a.local_timestamp - a.timestamp FROM activity a
     WHERE a.file_hash = s.file_hash
       AND a.local_timestamp IS NOT NULL
       AND a.timestamp IS NOT NULL
     LIMIT 1), 0) AS local_start_time,
  (SELECT SUM(wh.temperature_c * (
       MIN(COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1), wh.hour_timestamp + 3600)
       - MAX(COALESCE(s.start_time, s.timestamp), wh.hour_timestamp)
     )) * 1.0 / NULLIF(SUM(
       MIN(COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1), wh.hour_timestamp + 3600)
       - MAX(COALESCE(s.start_time, s.timestamp), wh.hour_timestamp)
     ), 0)
   FROM weather_hourly wh
   WHERE wh.file_hash = s.file_hash
     AND wh.hour_timestamp + 3600 > COALESCE(s.start_time, s.timestamp)
     AND wh.hour_timestamp < COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1)
  ) AS weather_temperature_c,
  (SELECT SUM(wh.apparent_temperature_c * (
       MIN(COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1), wh.hour_timestamp + 3600)
       - MAX(COALESCE(s.start_time, s.timestamp), wh.hour_timestamp)
     )) * 1.0 / NULLIF(SUM(
       MIN(COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1), wh.hour_timestamp + 3600)
       - MAX(COALESCE(s.start_time, s.timestamp), wh.hour_timestamp)
     ), 0)
   FROM weather_hourly wh
   WHERE wh.file_hash = s.file_hash
     AND wh.hour_timestamp + 3600 > COALESCE(s.start_time, s.timestamp)
     AND wh.hour_timestamp < COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1)
  ) AS weather_apparent_temperature_c,
  (SELECT SUM(wh.relativehumidity_pct * (
       MIN(COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1), wh.hour_timestamp + 3600)
       - MAX(COALESCE(s.start_time, s.timestamp), wh.hour_timestamp)
     )) * 1.0 / NULLIF(SUM(
       MIN(COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1), wh.hour_timestamp + 3600)
       - MAX(COALESCE(s.start_time, s.timestamp), wh.hour_timestamp)
     ), 0)
   FROM weather_hourly wh
   WHERE wh.file_hash = s.file_hash
     AND wh.hour_timestamp + 3600 > COALESCE(s.start_time, s.timestamp)
     AND wh.hour_timestamp < COALESCE(s.start_time, s.timestamp) + MAX(COALESCE(s.total_elapsed_time, 0), 1)
  ) AS weather_relativehumidity_pct
FROM session s
JOIN _import_log il ON s.file_hash = il.file_hash;

DROP VIEW IF EXISTS lap_v;
CREATE VIEW lap_v AS
SELECT l.*, il.file_id FROM lap l
JOIN _import_log il ON l.file_hash = il.file_hash;

DROP VIEW IF EXISTS sleep_assessment_v;
CREATE VIEW sleep_assessment_v AS
SELECT sa.*, il.file_id,
  MIN(sl.timestamp) AS sleep_start,
  MAX(sl.timestamp) AS sleep_end,
  (MAX(sl.timestamp) - MIN(sl.timestamp)) / 3600.0 AS sleep_hours
FROM sleep_assessment sa
JOIN _import_log il ON sa.file_hash = il.file_hash
LEFT JOIN sleep_level sl ON sa.file_hash = sl.file_hash
GROUP BY sa.id;

DROP VIEW IF EXISTS daily_steps_v;
CREATE VIEW daily_steps_v AS
SELECT date(timestamp, 'unixepoch') AS day,
  MAX(timestamp) AS day_timestamp,
  MAX(distance) / 1000.0 AS total_distance_km,
  MAX(distance) AS total_distance_m
FROM monitoring
WHERE timestamp IS NOT NULL AND distance IS NOT NULL
GROUP BY date(timestamp, 'unixepoch');

DROP VIEW IF EXISTS daily_stress_v;
CREATE VIEW daily_stress_v AS
SELECT date(stress_level_time, 'unixepoch') AS day,
  MAX(stress_level_time) AS day_timestamp,
  AVG(CASE WHEN stress_level_value > 0 THEN stress_level_value END) AS avg_stress,
  MAX(CASE WHEN stress_level_value > 0 THEN stress_level_value END) AS max_stress,
  COUNT(CASE WHEN stress_level_value > 0 THEN 1 END) AS readings
FROM stress_level
WHERE stress_level_time IS NOT NULL
GROUP BY date(stress_level_time, 'unixepoch');

DROP VIEW IF EXISTS daily_resting_hr_v;
CREATE VIEW daily_resting_hr_v AS
SELECT date(timestamp, 'unixepoch') AS day,
  MAX(timestamp) AS day_timestamp,
  MIN(resting_heart_rate) AS resting_hr,
  MIN(current_day_resting_heart_rate) AS current_day_resting_hr
FROM monitoring_hr_data
WHERE timestamp IS NOT NULL AND resting_heart_rate IS NOT NULL
GROUP BY date(timestamp, 'unixepoch');

DROP VIEW IF EXISTS nap_event_v;
CREATE VIEW nap_event_v AS
SELECT ne.*, il.file_id,
  (ne.end_time - ne.start_time) / 60.0 AS nap_duration_minutes
FROM nap_event ne
JOIN _import_log il ON ne.file_hash = il.file_hash
WHERE ne.start_time IS NOT NULL AND ne.end_time IS NOT NULL;

DROP VIEW IF EXISTS sleep_stage_totals_v;
CREATE VIEW sleep_stage_totals_v AS
WITH transitions AS (
  SELECT sl.file_hash, sl.timestamp, sl.sleep_level,
    LEAD(sl.timestamp) OVER (PARTITION BY sl.file_hash ORDER BY sl.timestamp) AS next_ts
  FROM sleep_level sl
)
SELECT t.file_hash, il.file_id,
  MIN(t.timestamp) AS sleep_start,
  MAX(t.timestamp) AS sleep_end,
  SUM(CASE WHEN t.sleep_level='deep'  THEN (t.next_ts - t.timestamp)/60.0 ELSE 0 END) AS deep_minutes,
  SUM(CASE WHEN t.sleep_level='light' THEN (t.next_ts - t.timestamp)/60.0 ELSE 0 END) AS light_minutes,
  SUM(CASE WHEN t.sleep_level='rem'   THEN (t.next_ts - t.timestamp)/60.0 ELSE 0 END) AS rem_minutes,
  SUM(CASE WHEN t.sleep_level='awake' THEN (t.next_ts - t.timestamp)/60.0 ELSE 0 END) AS awake_minutes
FROM transitions t
JOIN _import_log il ON t.file_hash = il.file_hash
WHERE t.next_ts IS NOT NULL
GROUP BY t.file_hash, il.file_id;"""


def generate_full_schema():
    parts = [generate_tracking_tables(), ""]

    for _mesg_num, mt in sorted(MESSAGE_TYPES.items()):
        parts.append(generate_table_ddl(mt.name, mt))
        parts.append("")

    parts.append(generate_extension_tables())
    parts.append("")
    parts.append(generate_views())
    return "\n".join(parts)


def get_table_columns(message_name):
    for mt in MESSAGE_TYPES.values():
        if mt.name == message_name:
            cols = {"id", "file_hash", "timestamp"}
            for name, _ in _collect_columns(mt):
                cols.add(name)
            return cols
    return None
