from __future__ import annotations

from servestatic.asgi import ServeStaticASGI
from servestatic.wsgi import ServeStatic

__version__ = "4.2.0"

__all__ = ["ServeStatic", "ServeStaticASGI"]
