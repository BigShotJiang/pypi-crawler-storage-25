"""SDK-level review gate for agent continuation loops.

Wraps the common pattern: agent executes → review runs → merge if passed →
continue with feedback if failed. Creates standardized OTel spans with
``plato.review.*`` attributes so the Chronos parallel agent view can
render review results and merge status.

Usage::

    from plato.agents.review_gate import ReviewGateResult, attach_review_gate

    async def my_review(hostname: str) -> ReviewGateResult:
        result = await run_my_review_pipeline(hostname)
        return ReviewGateResult(
            passed=result.passed,
            feedback=result.feedback,
            result_data=result.model_dump(mode="json"),
        )

    runner = world.agent(config, display_name="builder-1", mounts=[mount])
    attach_review_gate(
        runner,
        review_fn=my_review,
        branch_name="pr/feature-1",
        merge_fn=lambda: integrate_and_refresh(transport, ref, branch_name),
    )
    await runner.run(instruction)
"""

from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from plato.agents.task import AgentTask

logger = logging.getLogger(__name__)


@dataclass
class ReviewGateResult:
    """Result from a review function.

    Attributes:
        passed: Whether the review passed (agent work is acceptable).
        feedback: Human-readable feedback for the agent on failure.
        result_data: Arbitrary JSON-serializable dict with full review details.
            Attached to the OTel span as ``plato.review.result_json``.
        score: Optional numeric score (0.0-1.0).
        verdict: Optional verdict string (e.g. "pass", "fail").
    """

    passed: bool
    feedback: str = ""
    result_data: dict[str, Any] = field(default_factory=dict)
    score: float | None = None
    verdict: str | None = None


@dataclass(frozen=True)
class ReviewGateMergeResult:
    """Outcome of the post-review merge attempt."""

    merged: bool
    conflict_files: list[str] = field(default_factory=list)
    error: str = ""


def attach_review_gate(
    runner: AgentTask,
    *,
    review_fn: Callable[[str], Awaitable[ReviewGateResult]],
    branch_name: str,
    merge_fn: Callable[[], Awaitable[bool | ReviewGateMergeResult]] | None = None,
    reviewed_commit_fn: Callable[[], str | None] | None = None,
    max_continuations: int = 2,
    checkpoint_fn: Callable[[str], Awaitable[None]] | None = None,
    result_dir: Path | None = None,
) -> AgentTask:
    """Wire up a review gate with standardized OTel span attributes.

    After each agent execution:
    1. Calls ``review_fn(agent_hostname)`` inside a ``pr_review.{branch_name}`` span.
    2. Attaches review results as ``plato.review.*`` span attributes.
    3. If passed and ``merge_fn`` is provided, merges and checkpoints.
    4. If failed, continues the agent with feedback.

    Args:
        runner: The AgentTask to attach the gate to.
        review_fn: Async function that takes the agent hostname and returns a ReviewGateResult.
        branch_name: Git branch name for span naming and result persistence.
        merge_fn: Optional async function that merges the branch. Returns True on success.
        reviewed_commit_fn: Optional function that returns the commit SHA currently
            under review. Attached to the span as ``plato.review.commit_sha`` when available.
        max_continuations: Max retry attempts after the initial run.
        checkpoint_fn: Optional async function called after successful merge.
        result_dir: Optional directory to persist review results as JSON.
    """
    _last_result: dict[str, Any] = {}
    _review_history: list[dict[str, Any]] = []

    if result_dir is not None:
        _results_path = result_dir / ".pr-review-results" / f"{branch_name}.json"
    else:
        _results_path = None

    async def _review_and_merge_passed() -> bool:
        from opentelemetry import trace

        tracer = trace.get_tracer("plato.agents.review_gate")
        hostname = runner.runtime_info.hostname if runner.runtime_info else ""

        with tracer.start_as_current_span(
            f"pr_review.{branch_name}",
            attributes={"plato.review.branch": branch_name},
        ) as review_span:
            reviewed_commit = reviewed_commit_fn() if reviewed_commit_fn is not None else None
            gate_result = await review_fn(hostname)

            result_dict = gate_result.result_data
            overall_passed = gate_result.passed

            # If review passed, attempt merge as part of the same review cycle
            merge_status = None
            merge_conflict_files: list[str] = []
            merge_error = ""
            if overall_passed and merge_fn is not None:
                try:
                    merge_result = await merge_fn()
                    if isinstance(merge_result, ReviewGateMergeResult):
                        merged = merge_result.merged
                        merge_conflict_files = list(merge_result.conflict_files)
                        merge_error = merge_result.error
                    else:
                        merged = merge_result
                    if merged:
                        merge_status = "merged"
                        logger.info("Merged branch %s to main", branch_name)
                        if checkpoint_fn:
                            await checkpoint_fn(f"merged.{branch_name.replace('/', '.')}")
                    else:
                        overall_passed = False
                        if merge_conflict_files:
                            merge_status = "conflict"
                            feedback = [
                                "Your code passed review but has merge conflicts with main.",
                            ]
                            feedback.append(
                                "Conflicting files:\n" + "\n".join(f"- {path}" for path in merge_conflict_files)
                            )
                            feedback.append("Pull the latest main into your branch, resolve conflicts, and commit.")
                            gate_result.feedback = "\n\n".join(feedback)
                            logger.warning("Merge conflict for branch %s", branch_name)
                        else:
                            merge_status = "error"
                            merge_error = merge_error or "merge returned merged=False without conflict files"
                            gate_result.feedback = (
                                "Your code passed review but could not be merged automatically.\n\n"
                                f"Merge error: {merge_error}\n\n"
                                "Re-run the task or inspect the git state before making code changes."
                            )
                            logger.warning("Merge error for branch %s: %s", branch_name, merge_error)
                except Exception as exc:
                    merge_status = "error"
                    overall_passed = False
                    merge_error = str(exc)
                    gate_result.feedback = (
                        f"Your code passed review but could not be merged: {exc}\n"
                        "Re-run the task or inspect the git state before making code changes."
                    )
                    logger.error("Merge error for branch %s: %s", branch_name, exc)

            _last_result.clear()
            _last_result.update(result_dict)
            _last_result["passed"] = overall_passed
            _last_result["feedback"] = gate_result.feedback
            _last_result["score"] = gate_result.score
            _last_result["verdict"] = gate_result.verdict
            if reviewed_commit:
                _last_result["reviewed_commit_sha"] = reviewed_commit
            if merge_conflict_files:
                _last_result["merge_conflict_files"] = merge_conflict_files
            if merge_error:
                _last_result["merge_error"] = merge_error
            if merge_status is not None:
                _last_result["merge_status"] = merge_status
            _review_history.append(dict(_last_result))

            # Attach final attributes to the span (includes merge outcome)
            review_span.set_attribute("plato.review.passed", overall_passed)
            if reviewed_commit:
                result_dict["reviewed_commit_sha"] = reviewed_commit
                review_span.set_attribute("plato.review.commit_sha", reviewed_commit)
            if merge_conflict_files:
                result_dict["merge_conflict_files"] = merge_conflict_files
                review_span.set_attribute("plato.merge.conflict_files", json.dumps(merge_conflict_files))
            if merge_error:
                result_dict["merge_error"] = merge_error
                review_span.set_attribute("plato.merge.error", merge_error[:4000])
            if merge_status is not None:
                result_dict["merge_status"] = merge_status
            review_json = json.dumps(result_dict, default=str)
            review_span.set_attribute("plato.review.result_json", review_json[:32000])
            if gate_result.score is not None:
                review_span.set_attribute("plato.review.score", gate_result.score)
            if gate_result.verdict is not None:
                review_span.set_attribute("plato.review.verdict", gate_result.verdict)
            if merge_status is not None:
                review_span.set_attribute("plato.merge.status", merge_status)

            # Persist to disk if configured
            if _results_path is not None:
                _results_path.parent.mkdir(parents=True, exist_ok=True)
                _results_path.write_text(json.dumps(result_dict, default=str, indent=2))

            logger.info(
                "Review gate [%s]: passed=%s score=%s verdict=%s merge=%s",
                branch_name,
                overall_passed,
                gate_result.score,
                gate_result.verdict,
                merge_status,
            )

        return overall_passed

    def _build_continuation_instruction() -> str:
        if not _last_result:
            return (
                "Your code did not pass review. "
                "Run validate.sh to check for errors, fix any issues, "
                "and commit your changes."
            )
        if _last_result.get("passed"):
            return "Your code passed review. Say AGENT_FINISH."

        feedback = _last_result.get("feedback", "")
        merge_status = _last_result.get("merge_status")
        merge_error = str(_last_result.get("merge_error", ""))

        if merge_status == "conflict":
            parts = [
                f"Your code passed the automated review (attempt {len(_review_history)}), "
                "but could not be merged into main due to conflicts."
            ]
        elif merge_status and merge_status != "merged":
            parts = [
                f"Your code passed the automated review (attempt {len(_review_history)}), but the merge step failed."
            ]
        else:
            parts = [f"Your code did not pass the automated review (attempt {len(_review_history)})."]
        if feedback:
            parts.append(f"Here is the review feedback:\n\n{feedback}")
        elif merge_error:
            parts.append(f"Merge error: {merge_error}")
        else:
            parts.append("No detailed feedback available — re-run validate.sh to check for errors.")

        # Include prior review history so the agent knows what was already tried
        if len(_review_history) > 1:
            history_lines = []
            for i, prev in enumerate(_review_history[:-1], 1):
                prev_score = prev.get("score", "?")
                prev_verdict = prev.get("verdict", "?")
                prev_feedback = str(prev.get("feedback", ""))
                history_lines.append(
                    f"  Review #{i}: verdict={prev_verdict} score={prev_score}\n    Feedback: {prev_feedback}"
                )
            parts.append("Previous review attempts for this branch:\n" + "\n".join(history_lines))

        parts.append("\nFix the issues described above and commit your changes.")
        return "\n\n".join(parts)

    runner.with_continuation(
        exit_condition=_review_and_merge_passed,
        max_continuations=max_continuations,
        continuation_instruction=_build_continuation_instruction,
    )
    return runner
