from blues_lib.types import ToolDef
from blues_lib.resources.definition.StandardDefConverter import StandardDefConverter

class ToolDefConverter:
  '''
  ToolDefConverter is used to convert simple tool definitions to std tool definitions. A standard definition is like:
  {
    "name":"click",
    "options":{
      "target":".user-name",
    },
  }
  '''

  @classmethod
  def convert(cls,atoms:list[ToolDef|list])->list[ToolDef]:
    '''
    Convert a list of simple tool definitions to std tool definitions.
    Args:
      atoms: A list of simple tool definitions. like:
      [
        ["click", ".user-name"],
        ["click", [".user-name", ".user-password"]],
        ["get_attribute", [["a", "href"]]],
        ["get_attribute", {"target":".user-name","value":"href"}],
        ["get_attribute", [{"target":".user-name","value":"href"]]],
        {"name":"click","options":{"target":".user-name"}},
      ]
    Returns:
      A list of std tool definitions.
    '''
    tool_defs:list[ToolDef] = []
    for atom in atoms:
      if not atom:
        continue
      if isinstance(atom,list):
        seq_tool_defs:list[ToolDef] = StandardDefConverter.convert(atom)
        tool_defs.extend(seq_tool_defs)
      else:
        tool_defs.append(atom)
    return tool_defs
  