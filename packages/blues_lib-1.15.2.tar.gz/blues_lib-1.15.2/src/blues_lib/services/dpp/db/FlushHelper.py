from blues_lib.services.sql.DBMutator import DBMutator
from blues_lib.services.dpp.db.FieldSelectorHelper import FieldSelectorHelper
from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut

class FlushHelper:

  @staticmethod
  def flush(records: list[dict], stat: str, config: dict) -> SQLSTDOut:
    if not records:
      return SQLSTDOut(200, 'success, no records to flush')

    records = [{**e, 'stat': stat} for e in records]
    mapping = config.get('mapping', {})
    if mapping:
      records = FieldSelectorHelper.process(records, config)
    mutator = DBMutator('ap_mat')
    return mutator.insert(records)
