from blues_lib.services.dpp.processors.ImageProcessor import ImageProcessor
from blues_lib.utils.url.URLManager import URLManager
from blues_lib.utils.file.File import File
from blues_lib.utils.file.FileDownloader import FileDownloader
from blues_lib.utils.image.ImageResizer import ImageResizer
from blues_lib.utils.convert.Algorithm import Algorithm


class ImageValidator(ImageProcessor):
  """
  验证图片字段。
  """

  def _is_valid(self, entity: dict, config: dict) -> tuple[bool, str]:
    paras_valid = self._validate_paras(entity, config)

    thumb_valid = self._validate_thumb(entity, config)

    return paras_valid and thumb_valid, ''

  def _validate_paras(self, entity: dict, config: dict) -> bool:
    if 'paras' not in entity:
      return True

    paras = entity.get('paras', [])
    if not paras:
      self._logger.warning('paras is empty, failed to validate')
      return False

    valid_images, new_paras = self._filter_paras_images(paras, config)
    entity['paras'] = new_paras

    min_images = config.get('min_length', 1)
    max_images = config.get('max_length', 8)
    paras_valid = min_images <= len(valid_images) <= max_images
    if not paras_valid:
      self._logger.warning(f'paras image count {len(valid_images)} not in [{min_images}, {max_images}]')
    return paras_valid

  def _validate_thumb(self, entity: dict, config: dict) -> bool:
    if 'thumb' not in entity:
      return True

    thumb = entity.get('thumb', '')
    if not thumb:
      self._logger.warning('thumb is empty, failed to validate')
      return False

    success, entity['thumb'] = self._process_thumb(thumb, config)
    if not success:
      paras = entity.get('paras', [])
      entity['thumb'] = self._get_first_image(paras)
      success = bool(entity['thumb'])
      if not success:
        self._logger.warning('thumb processing failed and no fallback image')

    return success

  def _filter_paras_images(self, paras: list[dict], config: dict) -> tuple[list[str], list[dict]]:
    valid_images = []
    new_paras = []
    max_images = config.get('max_length', 8)

    for p in paras:
      if p.get('type') != 'image':
        new_paras.append(p)
        continue
      value = p.get('value', '')
      success, processed = self._process_single_image(value, config)
      if success and len(valid_images) < max_images:
        valid_images.append(processed)
        new_paras.append({**p, 'value': processed})

    return valid_images, new_paras

  def _process_thumb(self, thumb: str, config: dict) -> tuple[bool, str]:
    if not thumb:
      self._logger.warning('thumb is empty')
      return False, ''
    success, result = self._process_single_image(thumb, config)
    if not success:
      self._logger.warning('thumb download/processing failed')
    return success, result

  def _process_single_image(self, image_source: str, config: dict) -> tuple[bool, str]:
    if not image_source:
      return False, ''

    local_path = image_source
    if URLManager.is_http_url(image_source):
      code, path = self._download_image(image_source)
      if code != 200:
        self._logger.warning(f'image download failed, code={code}')
        return False, path
      local_path = path

    if not File.exists(local_path):
      return False, ''

    return ImageResizer.handle(local_path, config)

  def _download_image(self, image_url: str) -> tuple[int, str]:
    file_dir = URLManager.get_main_domain(image_url)
    file_name = Algorithm.md5(image_url)
    image_dir = File.get_today_download_home(file_dir)
    return FileDownloader.download_one(image_url, image_dir, file_name)

  def _get_first_image(self, paras: list[dict]) -> str:
    for p in paras:
      if p.get('type') == 'image' and p.get('value'):
        return p['value']
    return ''
