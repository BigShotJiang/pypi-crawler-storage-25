from abc import abstractmethod
import pandas as pd
from .BaseProcessor import BaseProcessor


class TextProcessor(BaseProcessor):
  """
  文本数据处理基类，使用 Pandas。
  """

  _RULE_KEY: str = 'text'

  def _process(self, entities: list, config: dict) -> tuple[list, list]:
    df = pd.DataFrame(entities)
    df = self._process_df(df, config)

    temp_cols = [c for c in df.columns if c.startswith('_')]
    valid_cols = [c for c in temp_cols if c.endswith('_valid')]
    
    if not valid_cols:
      # When no valid columns exist, all records are considered valid
      valid_records = df.to_dict(orient='records')
      invalid_records = []
      return self._clean_records(valid_records, temp_cols), invalid_records

    mask = df[valid_cols[0]]
    for col in valid_cols[1:]:
      mask = mask & df[col]
    mask = mask.fillna(True)

    valid_records = df[mask].to_dict(orient='records')
    invalid_records = df[~mask].to_dict(orient='records')
    
    return self._clean_records(valid_records, temp_cols), self._clean_records(invalid_records, temp_cols)

  def _clean_records(self, records: list[dict], temp_cols: list[str]) -> list[dict]:
    if not temp_cols:
      return records
    return [{k: v for k, v in r.items() if k not in temp_cols} for r in records]

  @abstractmethod
  def _process_df(self, df: pd.DataFrame, config: dict) -> pd.DataFrame: ...
