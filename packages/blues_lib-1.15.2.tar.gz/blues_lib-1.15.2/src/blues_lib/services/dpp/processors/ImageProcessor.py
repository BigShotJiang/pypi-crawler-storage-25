from abc import abstractmethod
from .BaseProcessor import BaseProcessor


class ImageProcessor(BaseProcessor):
  """
  图片数据处理基类，直接操作实体列表。
  """

  _RULE_KEY: str = 'image'

  def _process(self, entities: list, config: dict) -> tuple[list, list]:
    valid_entities = []
    invalid_entities = []

    for e in entities:
      result = self._is_valid(e, config)
      if isinstance(result, tuple):
        is_valid, _ = result
      else:
        is_valid = result

      if is_valid:
        valid_entities.append(e)
      else:
        invalid_entities.append(e)

    return valid_entities, invalid_entities

  @abstractmethod
  def _is_valid(self, entity: dict, config: dict):
    ...
