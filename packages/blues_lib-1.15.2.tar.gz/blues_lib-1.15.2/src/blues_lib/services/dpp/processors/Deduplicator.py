from blues_lib.services.dpp.processors.BaseProcessor import BaseProcessor
from blues_lib.services.sql.DBQuerier import DBQuerier


class Deduplicator(BaseProcessor):
  """
  去重处理器，从 entities 中移除数据库已存在的重复记录。
  配置项 persist.unique:
    - key: entity 属性名（必填）
    - field: 数据库字段名（可选，默认取 key 的值）
    - comparator: 比较符号（可选，默认 =）
  """

  _RULE_KEY = 'unique'

  def _process(self, entities: list[dict], config: dict) -> tuple[list, list]:
    if not config.get('key'):
      return entities, []

    key = config['key']
    field = config.get('field', key)
    comparator = config.get('comparator', '=')

    querier = DBQuerier('ap_mat')

    valid = []
    for e in entities:
      value = e.get(key)
      if not value:
        self._logger.warning(f'{key} is None, removed')
        continue

      condition = {
        'field': field,
        'comparator': comparator,
        'value': value,
      }
      if querier.search(condition):
        self._logger.warning(f'duplicate found for {key}={value}, removed')
        continue

      valid.append(e)

    return valid, []

  def _post_process(self, valid_entities: list, invalid_entities: list, config: dict) -> bool:
    self._request['entities'] = valid_entities
    return True
