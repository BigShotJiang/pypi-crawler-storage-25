import pandas as pd
from blues_lib.services.dpp.processors.TextProcessor import TextProcessor
from blues_lib.utils.convert.Algorithm import Algorithm


class TextValidator(TextProcessor):
  """
  验证text字段。
  """

  def _process_df(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    df = self._validate_url(df, config.get('url', {}))
    df = self._validate_title(df, config.get('title', {}))
    df = self._validate_paras(df, config.get('paras', {}))
    df = self._validate_content(df, config.get('content', {}))
    return df

  def _validate_url(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    if 'url' not in df.columns:
      return df
    valid = df['url'].str.startswith('http', na=False)
    df['_url_valid'] = valid
    invalid_count = (~valid).sum()
    if invalid_count > 0:
      self._logger.warning(f'{invalid_count} invalid(s): url not starts with http')
    return df

  def _validate_title(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    if not config or 'title' not in df.columns:
      return df
    length = df['title'].str.len()
    min_len = config.get('min_length', 10)
    max_len = config.get('max_length', 30)
    valid = (length >= min_len) & (length <= max_len)
    df['_title_valid'] = valid
    invalid_count = (~valid).sum()
    if invalid_count > 0:
      self._logger.warning(f'{invalid_count} invalid(s): title length not in [{min_len}, {max_len}]')
    return df

  def _validate_content(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    if not config or 'content' not in df.columns:
      return df
    length = df['content'].str.len()
    min_len = config.get('min_length', 250)
    max_len = config.get('max_length', 1500)
    valid = (length >= min_len) & (length <= max_len)
    df['_content_valid'] = valid
    invalid_count = (~valid).sum()
    if invalid_count > 0:
      self._logger.warning(f'{invalid_count} invalid(s): content length not in [{min_len}, {max_len}]')
    return df

  def _validate_paras(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    if not config or 'paras' not in df.columns:
      return df
    df['_paras_length'] = df['paras'].apply(self._calc_paras_text_length)
    min_len = config.get('min_length', 250)
    max_len = config.get('max_length', 1500)
    valid = (df['_paras_length'] >= min_len) & (df['_paras_length'] <= max_len)
    df['_paras_valid'] = valid
    invalid_count = (~valid).sum()
    if invalid_count > 0:
      self._logger.warning(f'{invalid_count} invalid(s): paras length not in [{min_len}, {max_len}]')
    return df

  def _calc_paras_text_length(self, paras: list[dict]) -> int:
    if not paras:
      return 0
    total = 0
    for p in paras:
      if p.get('type') == 'text' and p.get('value'):
        total += Algorithm.get_cn_length(p.get('value', ''))
    return total
