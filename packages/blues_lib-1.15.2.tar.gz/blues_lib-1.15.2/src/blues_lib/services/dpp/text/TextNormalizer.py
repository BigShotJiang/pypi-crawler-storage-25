import pandas as pd
from blues_lib.services.dpp.processors.TextProcessor import TextProcessor
from blues_lib.utils.convert.Algorithm import Algorithm


class TextNormalizer(TextProcessor):
  """
  标准化text字段。
  """

  def _process_df(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    max_length = config.get('paras', {}).get('max_length')
    if max_length and 'paras' in df.columns:
      df['paras'] = df['paras'].apply(lambda x: self._truncate_paras(x, max_length))
    return df

  def _truncate_paras(self, paras: list[dict], max_length: int) -> list[dict]:
    if not paras or not max_length:
      return paras

    new_paras = []
    cn_length = 0
    should_skip = False

    for para in paras:
      p_type = para.get('type', '')
      p_value = para.get('value', '')

      if p_type != 'text':
        new_paras.append(para)
        continue

      if should_skip:
        continue

      text_length = Algorithm.get_cn_length(p_value)
      cn_length += text_length

      if cn_length <= max_length:
        new_paras.append(para)
      else:
        should_skip = True

    return new_paras
