from typing import Any
from blues_lib.supports.dp.chain.AllMatchHandler import AllMatchHandler
from blues_lib.services.dpp.text import TextValidator, TextNormalizer, TextEnricher
from blues_lib.services.dpp.image import ImageValidator
from blues_lib.services.dpp.db.TableInserter import TableInserter
from blues_lib.services.dpp.processors.Deduplicator import Deduplicator


class DPPChain(AllMatchHandler):
  """
  Main chain coordinator for Data Preprocessing Pipeline.
  Orchestrates processors in sequence.
  """

  _HANDLERS: list[type] = [
      Deduplicator,
      TextValidator,
      TextNormalizer,
      TextEnricher,
      ImageValidator,
      TableInserter,
  ]

  def __init__(self, request):
    super().__init__(request)
    self._chain_names = []

  def resolve(self) -> bool:
    self._chain_names = []
    handlers = self._get_handlers()
    if not handlers:
      self._request['_message'] = f'{self.__class__.__name__} failed to create handler chain'
      return False

    chain = self._get_chain(handlers)
    self._logger.info(f'{self.__class__.__name__} chain: {" -> ".join(self._chain_names)}')

    return chain.handle()

  def _get_handlers(self) -> list[Any]:
    rule = self._request.get('rule', {})
    handlers = []
    for handler_class in self._HANDLERS:
      handler = handler_class(self._request)
      config = handler._get_config()
      if not config:
        continue
      handlers.append(handler)
      self._chain_names.append(handler_class.__name__)
    return handlers

  def _get_chain(self, handlers: list[Any]) -> Any:
    if not handlers:
      return None
    last_handler = handlers[0]
    for handler in handlers[1:]:
      last_handler.set_next(handler)
      last_handler = handler
    return handlers[0]
