import time,logging,json,requests
from blues_lib.types import LLMMessage,LLMBaseReqOpts
from blues_lib.services.llm.DefaultLLMOpts import DefaultLLMOpts
from blues_lib.utils.file.FileWriter import FileWriter

class BaseLLMClient:

  def __init__(self,std_opts:LLMBaseReqOpts) -> None:
    self._logger = logging.getLogger('airflow.task')
    self._std_opts = std_opts
    self._prepare(std_opts)
    
  def _prepare(self,std_opts:LLMBaseReqOpts):
    self._url = std_opts.get('url') or DefaultLLMOpts.URL

    payload = std_opts.get('payload') or {}
    default_payload = {**DefaultLLMOpts.PAYLOAD,**DefaultLLMOpts.DEEPSEEK_PAYLOAD} if self._is_deepseek_api() else DefaultLLMOpts.PAYLOAD
    self._payload = {**default_payload,**payload}

    headers = std_opts.get('headers') or {}
    self._headers = {**DefaultLLMOpts.HEADERS,**headers}
  
  def request(self,messages:list[LLMMessage]|None=None)->any:
    if messages:
      self._payload['messages'] = messages
    payload = json.dumps(self._payload)
    try:
      self._console(self._payload['messages'])
      request_start = time.time()
      response = requests.request("POST", self._url, headers=self._headers, data=payload)
      request_end = time.time()

      if response.status_code != 200:
        raise Exception(f'LLM request error: {response.status_code} {response.text}')

      self._logger.info(f"LLM request time: {request_end - request_start:.2f} seconds")
      content_only:bool = self._std_opts.get('content_only') or True
      orig_result:dict = response.json()
      result:any = self._get_content(orig_result) if content_only else orig_result
      return FileWriter.write_or_return(self._std_opts,result)
    except Exception as e:
      self._logger.error(f'LLM request error: {e}')
      return {}

  def _get_content(self,chat_completion:dict)->str:
    try:
      return chat_completion.get('choices',[{}])[0].get('message',{}).get('content','')
    except:
      self._logger.error(f'LLM output: no choices[0].message.content in {chat_completion}')
      return ''

  def _is_deepseek_api(self)->bool:
    return 'deepseek' in self._url.lower()

  def _console(self,messages:list[dict[str,str]]):
    url:str = self._url
    model:str = self._payload['model']
    self._logger.info(f'LLM : {url} {model}')

    if len(messages) < 2:
      system_content:str = ''
      user_content:str = messages[0]['content'].strip()
    else:
      system_content:str = messages[0]['content'].strip()
      user_content:str = messages[1]['content'].strip()

    if system_content:
      system_content_len = len(system_content)
      system_msg = system_content[:50]+'...' if system_content_len > 50 else system_content
      self._logger.info(f'LLM system prompt [{system_content_len}] : {system_msg}')

    user_content_len = len(user_content)
    user_msg = user_content[:50]+'...' if user_content_len > 50 else user_content
    self._logger.info(f'LLM user prompt [{user_content_len}] : {user_msg}')
    

