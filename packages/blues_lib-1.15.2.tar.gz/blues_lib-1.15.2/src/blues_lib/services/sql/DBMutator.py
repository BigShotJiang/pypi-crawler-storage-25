import json

from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut
from blues_lib.services.sql.DBExecutor import DBExecutor


class DBMutator:

  _SQL_IO = None

  def __init__(self, table: str, should_encode: bool = True) -> None:
    self._table = table
    self._should_encode = should_encode

  @property
  def _io(self) -> DBExecutor:
    if not self._SQL_IO:
      self._SQL_IO = DBExecutor()
    return self._SQL_IO

  def post(self, fields: list[str], values: list[list]) -> SQLSTDOut:
    self._encode_entities(values)
    return self._io.post(self._table, fields, values)

  def insert(self, entities: list[dict]) -> SQLSTDOut:
    self._encode_entities(entities)
    return self._io.insert(self._table, entities)

  def put(self, fields: list[str], values: list, conditions: dict | list[dict]) -> SQLSTDOut:
    self._encode_entity(values)
    return self._io.put(self._table, fields, values, conditions)

  def update(self, entity: dict, conditions: dict | list[dict]) -> SQLSTDOut:
    self._encode_entity(entity)
    return self._io.update(self._table, entity, conditions)

  def delete(self, conditions: dict | list[dict]) -> SQLSTDOut:
    return self._io.delete(self._table, conditions)

  def _encode_entities(self, entities: list) -> None:
    if self._should_encode and isinstance(entities, list):
      for entity in entities:
        self._encode_entity(entity)

  def _encode_entity(self, entity: dict | list) -> None:
    if self._should_encode:
      self._encode(entity)

  def _encode(self, entity: dict | list) -> None:
    mysql_types = {int, float, str, bool, type(None)}

    if isinstance(entity, dict):
      for key, value in entity.items():
        if type(value) in mysql_types:
          continue
        try:
          entity[key] = json.dumps(value, ensure_ascii=False)
        except json.JSONDecodeError as e:
          entity[key] = str(e)

    if isinstance(entity, list):
      for index, item in enumerate(entity):
        if type(item) in mysql_types:
          continue
        try:
          entity[index] = json.dumps(item, ensure_ascii=False)
        except json.JSONDecodeError as e:
          entity[index] = str(e)
