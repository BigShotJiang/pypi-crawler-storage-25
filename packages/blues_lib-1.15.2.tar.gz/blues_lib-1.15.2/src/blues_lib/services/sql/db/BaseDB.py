from abc import ABC, abstractmethod
import traceback
from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut


class BaseDB(ABC):

  _instance = None

  @classmethod
  def get_instance(cls, account):
    if not cls._instance:
      cls._instance = cls(account)
    return cls._instance

  @property
  @abstractmethod
  def db_type(self) -> str:
    pass

  def __init__(self, account: dict | None = None):
    self._account = account or {}
    self._set_cursor()

  def _set_cursor(self):
    self.connector = self._get_connector()
    self.cursor = self.connector.cursor()

  @abstractmethod
  def _get_connector(self):
    pass

  @abstractmethod
  def _execute(self, sql: str, values=None) -> SQLSTDOut:
    pass

  def is_conn_lost(self) -> bool:
    try:
      self.cursor.execute('SELECT 1')
      return False
    except Exception:
      return True

  def get(self, sql: str) -> SQLSTDOut:
    return self._fetchall(sql)

  def post(self, sql: str, values=None) -> SQLSTDOut:
    return self._execute(sql, values)

  def put(self, sql: str, values=None) -> SQLSTDOut:
    return self._execute(sql, values)

  def delete(self, sql: str) -> SQLSTDOut:
    return self._execute(sql)

  def _build_result(self, invoker: str, code: int, count: int = 0, lastid: int = None, message: str = None, sql: str = None) -> SQLSTDOut:
    kwargs = {'code': code}

    if code == 200:
      kwargs['count'] = count
      if invoker in ('get', 'delete'):
        kwargs['sql'] = sql
      if invoker == 'post' and lastid is not None:
        kwargs['lastid'] = lastid
    else:
      kwargs['message'] = message
      if invoker in ('get', 'delete'):
        kwargs['sql'] = sql

    return SQLSTDOut(**kwargs)

  def _get_invoker_name(self) -> str:
    invoker_info = traceback.extract_stack()
    return invoker_info[-2][2]

  def _is_series(self, value) -> bool:
    return isinstance(value, (list, tuple))

  def _fetchall(self, sql: str) -> SQLSTDOut:
    if self.is_conn_lost():
      self._set_cursor()

    try:
      self.cursor.execute(sql)
      rows = self.cursor.fetchall()
      self.connector.commit()

      dict_rows = self._rows_to_dict(rows)

      result = self._build_result(
        invoker='get',
        code=200,
        sql=sql,
        count=len(dict_rows)
      )
      result.data = dict_rows
      return result

    except Exception as e:
      return self._build_result(
        invoker='get',
        code=500,
        message=str(e),
        sql=sql
      )

  @abstractmethod
  def _rows_to_dict(self, rows) -> list:
    pass
