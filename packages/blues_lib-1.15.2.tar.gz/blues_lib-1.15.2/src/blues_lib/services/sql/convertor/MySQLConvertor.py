from blues_lib.services.sql.convertor.BaseSQLConvertor import BaseSQLConvertor


class MySQLConvertor(BaseSQLConvertor):

  @classmethod
  def get_placeholder(cls) -> str:
    return '%s'

  @classmethod
  def get_limit_sql(cls, pagination) -> str:
    if not pagination:
      return ''

    no = int(pagination.get('no', 1))
    size = int(pagination.get('size', 50))
    from_index = (no - 1) * size
    return ' limit %s,%s ' % (from_index, size)
