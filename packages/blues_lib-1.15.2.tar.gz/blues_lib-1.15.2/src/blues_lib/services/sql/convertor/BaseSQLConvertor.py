from abc import ABC, abstractmethod


class BaseSQLConvertor(ABC):

  @classmethod
  @abstractmethod
  def get_placeholder(cls) -> str:
    pass

  @classmethod
  def get_in_sql(cls, condition):
    sql = ''
    field = condition.get('field', '')
    values = condition.get('values')

    if not values:
      return ''

    for value in values:
      sql += '"%s",' % value
    return ' %s in (%s) ' % (field, sql[:-1])

  @classmethod
  def get_order_sql(cls, orders):
    sql = ''
    if not orders:
      return sql

    order_list = [orders] if isinstance(orders, dict) else orders
    for order in order_list:
      field = order.get('field')
      sort = order.get('sort')

      if not field:
        continue

      sql += '%s %s,' % (field, sort)

    if not sql:
      return ''

    return ' order by %s ' % sql[:-1]

  @classmethod
  def get_update_template_sql(cls, fields, conditions):
    sql = ''
    condition_sql = cls.get_condition_sql(conditions)
    placeholder = cls.get_placeholder()
    for field in fields:
      sql += field + '=%s,' % placeholder
    return ' set %s %s ' % (sql[:-1], condition_sql)

  @classmethod
  def get_update_sql(cls, entity, conditions):
    sql = ''
    condition_sql = cls.get_condition_sql(conditions)
    for field in entity:
      value = entity[field]
      if isinstance(value, str):
        sql += f"{field}='{value}',"
      else:
        sql += f"{field}={value},"
    return ' set %s %s ' % (sql[:-1], condition_sql)

  @classmethod
  def get_insert_template_sql(cls, fields):
    key_sql = ''
    value_sql = ''
    placeholder = cls.get_placeholder()

    for field in fields:
      key_sql += '%s,' % field
      value_sql += '%s,' % placeholder

    return ' (%s) values (%s) ' % (key_sql[:-1], value_sql[:-1])

  @classmethod
  def get_insert_sql(cls, entities):
    '''
    @description: Build INSERT SQL from entity dict list.
      - String values: escape single quotes by doubling them, wrap with single quotes
      - None values: use NULL
      - Other values (int, float, bool): convert to string directly
    @note: This method directly concatenates values into SQL string (not using placeholder).
      Values should be pre-processed by DBMutator._encode() which converts complex types
      (like list/dict) to JSON strings before calling this method.
    '''
    entity_list = [entities] if isinstance(entities, dict) else entities
    key_sql = ''
    value_sql = ''

    first_entity = entity_list[0]
    for key in first_entity:
      key_sql += '%s,' % key

    for entity in entity_list:
      unit_value_sql = ''
      for key in entity:
        value = entity[key]
        if isinstance(value, str):
          escaped_value = value.replace("'", "''")
          unit_value_sql += "'%s'," % escaped_value
        elif value is None:
          unit_value_sql += "NULL,"
        else:
          unit_value_sql += "%s," % value
      value_sql += '(%s),' % unit_value_sql[:-1]

    return ' (%s) values %s ' % (key_sql[:-1], value_sql[:-1])

  @classmethod
  def get_condition_sql(cls, conditions):
    sql = ''
    if not conditions:
      return sql

    avail_condition_count = 0
    condition_list = [conditions] if isinstance(conditions, dict) else conditions
    for condition in condition_list:
      field = condition.get('field')
      comparator = condition.get('comparator', '=')
      operator = condition.get('operator', 'and')
      value_type = condition.get('value_type')

      if comparator == 'in':
        original_value = condition.get('value')
        if not original_value:
          continue

        value = cls.get_in_sql(field, original_value)
      else:
        value = condition.get('value', '')

      if not field:
        continue

      if avail_condition_count == 0:
        operator = ''

      avail_condition_count += 1
      if comparator == 'in':
        sql += ' %s ( %s ) ' % (operator, value)
      else:
        if value_type == 'function':
          sql += ' %s (%s %s %s) ' % (operator, field, comparator, value)
        else:
          sql += ' %s (%s %s "%s") ' % (operator, field, comparator, value)

    return ' where %s ' % sql

  @classmethod
  @abstractmethod
  def get_limit_sql(cls, pagination) -> str:
    pass
