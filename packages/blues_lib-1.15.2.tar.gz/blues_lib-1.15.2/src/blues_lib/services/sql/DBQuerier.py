import json

from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut
from blues_lib.services.sql.DBExecutor import DBExecutor
from blues_lib.types import SQLCondition,SQLOrder,SQLPagination


class DBQuerier:

  _SQL_IO = None

  def __init__(self, table: str, should_decode: bool = True) -> None:
    self._table = table
    self._should_decode = should_decode

  @property
  def _io(self) -> DBExecutor:
    if not self._SQL_IO:
      self._SQL_IO = DBExecutor()
    return self._SQL_IO

  def get(self, fields: list[str] = None, conditions: list[SQLCondition] = None, orders: list[SQLOrder] = None, pagination: SQLPagination = None) -> SQLSTDOut:
    stdout = self._io.get(self._table, fields, conditions, orders, pagination)
    return self._decode_entities(stdout)

  def has(self, field: str, value) -> bool:
    fields = [field]
    conditions = [
      {
        'field': field,
        'comparator': '=',
        'value': value,
      },
    ]
    stdout = self.get(fields, conditions)
    return stdout.count > 0

  def search(self, conditions: list[SQLCondition]|SQLCondition) -> bool:
    if not isinstance(conditions, list):
      conditions = [conditions]
    stdout = self.get(conditions=conditions)
    return stdout.count > 0

  def first(self, conditions: list[SQLCondition] = None) -> SQLSTDOut:
    stdout = self.get(conditions=conditions)
    if stdout.code != 200 or not stdout.data:
      return stdout
    return SQLSTDOut(200, 'ok', stdout.data[0])

  def random(self, fields='*', conditions: list[SQLCondition] = None, size: int = 1) -> SQLSTDOut:
    orders = [{
      'field': 'rand()',
      'sort': ''
    }]
    pagination = {
      'no': 1,
      'size': size
    }
    return self.get(fields, conditions, orders, pagination)

  def latest(self, fields='*', conditions: list[SQLCondition] = None, size: int = 1) -> SQLSTDOut:
    orders = [{
      'field': 'mat_ctime',
      'sort': 'desc'
    }]
    pagination = {
      'no': 1,
      'size': size
    }
    return self.get(fields, conditions, orders, pagination)

  def _decode(self, entity: dict) -> None:
    for key, value in entity.items():
      if isinstance(value, str) and value.strip():
        try:
          entity[key] = json.loads(value)
        except Exception:
          continue

  def _decode_entities(self, stdout: SQLSTDOut):
    if stdout.code != 200 or not stdout.data or not self._should_decode:
      return stdout
    for entity in stdout.data:
      self._decode(entity)
    return stdout
