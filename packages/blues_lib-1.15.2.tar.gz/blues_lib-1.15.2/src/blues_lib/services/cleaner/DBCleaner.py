from blues_lib.services.sql.DBMutator import DBMutator
from blues_lib.services.cleaner.BaseCleaner import BaseCleaner
from blues_lib.supports.dp.output.SQLSTDOut import SQLSTDOut
from blues_lib.types import CleanOpts,SQLCondition

class DBCleaner(BaseCleaner):
  _DEFAULT_TABLES:list[str] = ['ap_mat','naps_loginer']

  def __init__(self,options:CleanOpts):
    super().__init__(options)

  def clean(self)->int:
    conditions:list[SQLCondition] = self._get_conditions()
    tables:list[str] = self._options.get('tables') or self._DEFAULT_TABLES
    total_count:int = 0
    for table in tables:
      mutator = DBMutator(table)
      output:SQLSTDOut = mutator.delete(conditions)
      count = output.count or 0
      total_count += count
      self._logger.info(f'{self.__class__.__name__} Deleted {count} rows from {table}')
    return total_count

  def _get_conditions(self)->list[dict]:
    validity_days:int = int(self._options.get('validity_days',100))
    return [
      {
        'field':'material_collect_date',
        'comparator':'<=',
        'value':'DATE_SUB(CURRENT_DATE, INTERVAL %s DAY)' % validity_days,
        'value_type':'function',
      }
    ]
