class AbilityExecError(Exception):
  def __init__(self, message="Ability execution exception"):
    super().__init__(message)
