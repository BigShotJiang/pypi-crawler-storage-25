class SkipLoopWarning(Exception):
  def __init__(self, message="Skip the loop, but don't execute the skip loop tools"):
    super().__init__(message)
