import logging
from abc import ABC, abstractmethod


class Handler(ABC):

  def __init__(self, request):
    self._next_handler = None
    self._request = request
    self._logger = logging.getLogger('airflow.task')

  def set_next(self, handler):
    self._next_handler = handler
    return handler

  @abstractmethod
  def resolve(self) -> bool:
    pass

  def handle(self) -> bool:
    result = self.resolve()
    if self._next_handler:
      return self._next_handler.handle()
    return result
