from blues_lib.supports.dp.chain.Handler import Handler


class FirstMatchHandler(Handler):
  """
  Handler that returns True on first success.
  Continues only if resolve returns False.
  """

  def handle(self) -> bool:
    result = self.resolve()
    if result:
      return True

    if self._next_handler:
      return self._next_handler.handle()
    return False
