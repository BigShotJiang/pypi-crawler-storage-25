from blues_lib.supports.dp.chain.Handler import Handler


class AllMatchHandler(Handler):
  """
  Handler that processes all handlers in chain.
  Returns True only if all handlers return True.
  """

  def handle(self) -> bool:
    result = self.resolve()

    if self._next_handler:
      return result and self._next_handler.handle()
    return result
