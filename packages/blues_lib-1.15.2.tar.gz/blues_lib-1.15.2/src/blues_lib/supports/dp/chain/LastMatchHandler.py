from blues_lib.supports.dp.chain.Handler import Handler


class LastMatchHandler(Handler):
  """
  Handler that continues while resolve returns True.
  Stops and returns False on first failure.
  """

  def handle(self) -> bool:
    result = self.resolve()
    if not result:
      return False

    if self._next_handler:
      return self._next_handler.handle()
    return True
