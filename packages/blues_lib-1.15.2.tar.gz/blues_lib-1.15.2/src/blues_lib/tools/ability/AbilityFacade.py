import logging
from blues_lib.tools.ability.atom.AtomFacade import AtomFacade
from blues_lib.tools.ability.sequence.SeqFacade import SeqFacade
from blues_lib.tools.ability.dynamic.DynamicFacade import DynamicFacade
from blues_lib.tools.TaskContext import TaskContext
from blues_lib.types import ToolDef

class AbilityFacade():
  
  def __init__(self,context:TaskContext|None=None) -> None:
    self._context = context
    self._logger = logging.getLogger('airflow.task')
    self._dynamic_tools:dict[str,ToolDef] = {}
    
  def execute(self,method:str, options:dict|None=None) -> any:
    """
    execute the method in the facade
    Args:
      method (str): the method name
      options (dict|None): the method options
    Returns:
      any: the method return
    """
    if not self._context:
      context_meta:dict|None = options.get('context')
      self._context = TaskContext(context_meta)

    return self._cast(method, options)
  
  def register(self,tools:list[ToolDef]):
    for tool in tools:
      name:str = tool.get('name')
      options:dict = tool.get('options') or {}
      self._dynamic_tools[name] = options

  def _cast(self,method:str, options:dict|None=None) -> any:
    atom_facade = AtomFacade(self._context)
    seq_facade = SeqFacade(self._context)
    dynamic_facade = DynamicFacade(self._context)

    # dynamic facade has the highest priority, because it's registered by the user
    if dynamic_facade.has(method):
      return dynamic_facade.execute(method, options) 
    elif atom_facade.has(method):
      return atom_facade.execute(method, options) 
    elif seq_facade.has(method):
      return seq_facade.execute(method, options) 
    else:
      self._logger.error(f'Unknown method: {method}')
      return None

  def clear(self):
    self._context.teardown()