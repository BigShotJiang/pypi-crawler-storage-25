import inspect
import logging
from abc import ABC, abstractmethod
from blues_lib.tools.TaskContext import TaskContext
from blues_lib.supports.decorator import AbilityIOHook
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer

class BaseFacade(ABC):

  def __init__(self, context: TaskContext) -> None:
    self._context = context
    self._logger = logging.getLogger('airflow.task')
    self._caller_instances: dict[str, any] = {}
    self._caller_methods: list[str] = []
    self._prepare()

  @property
  def methods(self) -> list[str]:
    return self._caller_methods

  def has(self, name: str) -> bool:
    return name in self._caller_methods

  @AbilityIOHook()
  def execute(self, name: str, options: dict | None = None) -> any:
    instance = self._caller_instances.get(name)
    if not instance:
      raise ValueError(f"method {name} not found")
    method = getattr(instance, name)
    if self._has_positional_params(method) and options:
      options = Jinja2Renderer.render_atom(options, self._context.result)
      return method(options)
    else:
      return method()

  def _has_positional_params(self, method) -> bool:
    sig = inspect.signature(method)
    return any(
      p.kind in (
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
        inspect.Parameter.POSITIONAL_ONLY,
        inspect.Parameter.VAR_POSITIONAL
      )
      for p in sig.parameters.values()
    )

  def _prepare(self) -> None:
    class_instances: dict[str, any] = self._get_class_instances() or {}
    if not class_instances:
      return
    instances: dict[str, any] = self._get_caller_instances(class_instances) or {}
    keys: list[str] = instances.keys() or []
    self._caller_instances.update(instances)
    self._caller_methods.extend(keys)

  @abstractmethod
  def _get_class_instances(self) -> dict[str, any]:
    pass

  def _get_caller_instances(self, class_instances: dict[str, any]) -> dict[str, any]:
    caller_instances = {**self._caller_instances}
    for class_name, instance in class_instances.items():
      attr_names: list[str] = dir(instance)
      for attr_name in attr_names:
        if attr_name.startswith("_"):
          continue
        attr_obj = getattr(instance, attr_name)
        if not callable(attr_obj):
          continue
        if attr_name in caller_instances:
          existing_instance = caller_instances[attr_name]
          message: str = f"{attr_name} exists in {type(existing_instance).__name__}, skip {class_name}"
          raise ValueError(message)
        caller_instances[attr_name] = instance
    return caller_instances
