from re import sub
from blues_lib.types import SeqOpts,AttemptBy
from blues_lib.tools.ability.sequence.cast.BaseSeq import BaseSeq
from blues_lib.tools.ability.sequence.cast.SingleSeq import SingleSeq
from blues_lib.tools.ability.sequence.cast.LoopSeq import LoopSeq
from blues_lib.tools.TaskContext import TaskContext

class PageSeq(BaseSeq):

  _SUMMARY_KEY:str = 'page'

  def cast_page(self,options:SeqOpts)->list[dict[str,any]]:
    self._prepare(options)
    return self._process()

  def _process(self)->list[dict[str,any]]:
    
    attempts:int = int(self._tool_summary.get('attempts') or -1)
    attempt_start:int = int(self._tool_summary.get('attempt_start') or 1)
    attempt_by:AttemptBy = self._tool_summary.get('attempt_by') # ['number','loc'] or ['next','loc']

    # 至少执行一次
    attempt_time:int = 1
    current_page:int = attempt_start
    if attempt_start>1:
      for i in range(attempt_start-1):
        self._iter_helper.next_page(attempt_by,i+1)

    results:list[dict[str,any]] = self._cast_once(current_page)
    while True:

      # 因为默认已执行一次，在开始前delay
      self._iter_helper.delay(self._tool_summary)
      if attempts>0 and attempt_time>=attempts:
        break

      has_next:bool = self._iter_helper.next_page(attempt_by,current_page)
      if not has_next:
        break

      attempt_time+=1
      current_page+=1
      
      result:dict = self._cast_once(current_page)
      results.extend(result)
    return results
    
  def _cast_once(self,page_no:int)->list[dict[str,any]]:
    # loop and single seq cannot have page property
    sub_opts:dict = {**self._seq_opts}
    sub_opts.pop('page', None)

    if sub_opts.get('loop'):
      self._append_page_item(sub_opts,'loop',page_no)
      return self._cast_loop(sub_opts)
    else:
      self._append_page_item(sub_opts,'single',page_no)
      return self._cast_single(sub_opts)
    
  def _append_page_item(self,sub_opts:dict,level:str,page_no:int):
      item:dict = {
        '_page_no':page_no,
        '_page_index':page_no-1,
      } 
      if not sub_opts.get(level):
        sub_opts[level] = {}
      sub_opts[level]['attempt_item'] = item
      
  def _cast_loop(self,sub_opts:dict)->list[dict[str,any]]:
    sub_context = TaskContext({"driver":self._context.driver})
    self._loop_seq = LoopSeq(sub_context)
    return self._loop_seq.cast_loop(sub_opts)

  def _cast_single(self,sub_opts:dict)->list[dict[str,any]]:
    # single seq do not have loop property
    sub_opts.pop('loop', None)
    sub_opts.pop('type_tools', None)
    sub_context = TaskContext({"driver":self._context.driver})
    self._single_seq = SingleSeq(sub_context)
    result:dict = self._single_seq.cast_single(sub_opts)
    return [result] if result else []
