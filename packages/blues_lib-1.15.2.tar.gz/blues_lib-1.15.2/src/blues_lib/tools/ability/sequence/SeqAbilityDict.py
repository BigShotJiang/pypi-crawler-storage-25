from blues_lib.tools.ability.sequence.cast.SingleSeq import SingleSeq
from blues_lib.tools.ability.sequence.cast.LoopSeq import LoopSeq
from blues_lib.tools.ability.sequence.cast.PageSeq import PageSeq
from blues_lib.tools.TaskContext import TaskContext

class SeqAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      # single seq
      SingleSeq.__name__:SingleSeq(context),
      # loop seq
      LoopSeq.__name__:LoopSeq(context),
      # page seq
      PageSeq.__name__:PageSeq(context),
    }