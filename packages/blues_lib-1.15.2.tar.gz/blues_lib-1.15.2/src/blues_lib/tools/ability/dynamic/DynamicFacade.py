from blues_lib.tools.ability.BaseFacade import BaseFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

class DynamicFacade(BaseFacade):
  
  _ability_classes: list[type[BaseAbility]] = []
  
  def _get_class_instances(self) -> dict[str,BaseAbility]:
    insts:dict[str,BaseAbility] = {}
    for cls in self._ability_classes:
      name:str = cls.__name__
      if name in insts:
        continue
      insts[name] = cls(self._context)
    return insts

  @classmethod
  def register(cls,ability_classes:list[type[BaseAbility]]|type[BaseAbility]):
    classes = ability_classes if isinstance(ability_classes,list) else [ability_classes]
    cls._ability_classes.extend(classes)
