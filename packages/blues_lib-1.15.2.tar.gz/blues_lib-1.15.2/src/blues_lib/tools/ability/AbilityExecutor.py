import logging
from blues_lib.tools.ability.AbilityFacade import AbilityFacade
from blues_lib.types import SeqOpts,ToolDef,ToolDef
from blues_lib.tools.TaskContext import TaskContext

class AbilityExecutor:
  # 执行一系列tools，可以作为独立的context并输出，也可以作为hooks辅助修改宿主tools（使用同一个context）
  
  def __init__(self,context:TaskContext)->None:
    self._context = context
    self._facade = AbilityFacade(context)
    self._logger = logging.getLogger('airflow.task')
  
  def execute(self,tools:list[ToolDef])->dict[str,any]:
    '''
    Execute a tool list and return the result dict
    '''
    if not tools:
      return self._context.result

    for tool in tools:
      self._exec_once(tool)
    return self._context.result
  
  def _exec_once(self,tool:ToolDef)->any:
    name:str = tool.get('name') or 'undefined'
    options:dict|SeqOpts = tool.get('options')
    args:list[any] = [name,options] if options else [name]
    return self._facade.execute(*args)
