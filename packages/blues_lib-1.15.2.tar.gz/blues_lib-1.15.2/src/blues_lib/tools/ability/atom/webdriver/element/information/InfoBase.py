from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility

class InfoBase(QuerierAbility):
  """
  Information class to get element information.
  Reference : https://www.selenium.dev/documentation/webdriver/elements/information/
  """
  pass