from blues_lib.tools.ability.atom.webdriver.combo.ComboForm import ComboForm
from blues_lib.tools.ability.atom.webdriver.combo.ComboLogin import ComboLogin
from blues_lib.tools.ability.atom.webdriver.combo.ComboOpen import ComboOpen
from blues_lib.tools.ability.atom.webdriver.combo.ComboUpload import ComboUpload

class Combo(ComboForm,ComboLogin,ComboOpen,ComboUpload):
  pass