from blues_lib.tools.ability.atom.webdriver.element.information.InfoState import InfoState
from blues_lib.tools.ability.atom.webdriver.element.information.InfoRect import InfoRect
from blues_lib.tools.ability.atom.webdriver.element.information.InfoAttr import InfoAttr
from blues_lib.utils.file.FileWriter import FileWriter


class Information(InfoState,InfoRect,InfoAttr):
  """
  Information class to get element information.
  Reference : https://www.selenium.dev/documentation/webdriver/elements/information/
  """  
  def get_para_group(self,options:dict)->dict[str,list[str]]:
    texts:list[str] = self.get_texts(options)

    image_options = {
      **options,
      'target':'img',
      'root':options['target'],
    }
    images:list[str] = self.get_srcs(image_options) or []
    group:dict = {
      'text':texts,
      'image':images,
    }
    return FileWriter.write_or_return(options,group)

  def get_paras(self,options:dict)->list[dict[str,str]]:
    opts:dict = options.copy()
    opts.pop('to_file',None)
    result:dict = self.get_para_group(opts)

    paras:list[dict[str,str]] = []
    
    texts:list[str] = result['text']
    images:list[str] = result['image']
    
    if texts:
      for text in texts:
        paras.append({
          'type':'text',
          'value':text,
        })
    if images:
      for image in images:
        paras.append({
          'type':'image',
          'value':image,
        })

    return FileWriter.write_or_return(options,paras)
