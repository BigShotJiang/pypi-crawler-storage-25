from blues_lib.tools.ability.atom.BaseAbility import BaseAbility

from blues_lib.tools.ability.atom.webdriver.DriverAbilityDict import DriverAbilityDict
from blues_lib.tools.ability.atom.matcher.MatcherAbilityDict import MatcherAbilityDict
from blues_lib.tools.ability.atom.tool.ToolAbilityDict import ToolAbilityDict
from blues_lib.tools.ability.atom.llm.LLMAbilityDict import LLMAbilityDict
from blues_lib.tools.ability.atom.sql.SQLAbilityDict import SQLAbilityDict
from blues_lib.tools.ability.atom.cleanup.CleanupAbilityDict import CleanupAbilityDict
from blues_lib.tools.ability.atom.hook.HookAbilityDict import HookAbilityDict
from blues_lib.tools.ability.atom.script.ScriptAbilityDict import ScriptAbilityDict
from blues_lib.tools.ability.atom.file.FileAbilityDict import FileAbilityDict
from blues_lib.tools.ability.atom.message.MessageAbilityDict import MessageAbilityDict
from blues_lib.tools.ability.atom.dpp.DppAbilityDict import DppAbilityDict
from blues_lib.tools.TaskContext import TaskContext

class AtomAbilityDict:
  """
  All atom ability class's dict
  """

  @classmethod
  def get(cls,context:TaskContext) -> dict[str,BaseAbility]:
    return {
      **ToolAbilityDict.get(context),
      **LLMAbilityDict.get(context),
      **SQLAbilityDict.get(context),
      **CleanupAbilityDict.get(context),
      **HookAbilityDict.get(context),
      **ScriptAbilityDict.get(context),
      **FileAbilityDict.get(context),
      **MessageAbilityDict.get(context),
      **DppAbilityDict.get(context),
      **DriverAbilityDict.get(context),
      **MatcherAbilityDict.get(context),
    }
