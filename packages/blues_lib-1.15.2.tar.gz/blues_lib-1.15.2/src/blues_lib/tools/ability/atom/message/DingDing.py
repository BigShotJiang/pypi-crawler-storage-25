from datetime import datetime
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.atom.sql.DBWaiter import DBWaiter
from blues_lib.utils.message.DingGroupSender import DingGroupSender
from blues_lib.types import DingOpts,TaskResponse

class DingDing(BaseAbility):
  
  def ding_group(self,options:DingOpts)->TaskResponse:
    sender:DingGroupSender = DingGroupSender.get_instance()
    return sender.send(options)

  def ding_and_wait_sms_code(self,options:dict)->str:
    timestamp:str = self.ding_login(options)
    options.setdefault('timeout',300)
    if not timestamp:
      self._logger.error('Failed to send login code')
      return ''
    options['timestamp'] = timestamp
    return DBWaiter(self._context).wait_sms_code(options)

  def ding_login(self,options:dict)->str:
    '''
    Send a login code to the user.
    Returns:
      The timestamp(id) of the code.
    '''
    domain = options.get('domain')
    timeout = options.get('timeout') or 300
    timestamp:int = int(datetime.now().timestamp() * 1000)
    
    ding_opts:DingOpts = {
      'msgtype':'link',
      'title':f'Click to submit [{domain}] login sms code',
      'text':f'Please submit within {timeout} seconds.',
      'message_url':f'http://deepbluenet.com/naps-upload-code.html?site={domain}&ts={timestamp}',
    }
    response:TaskResponse = self.ding_group(ding_opts)
    if response['code'] == 200:
      return str(timestamp)
    else:
      self._logger.error(f'Failed to ding login code: {response}')
      return ''
