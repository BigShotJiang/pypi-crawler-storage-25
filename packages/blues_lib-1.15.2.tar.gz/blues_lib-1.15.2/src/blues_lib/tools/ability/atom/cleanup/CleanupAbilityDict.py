from blues_lib.tools.ability.atom.cleanup.Cleaner import Cleaner
from blues_lib.tools.TaskContext import TaskContext

class CleanupAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      Cleaner.__name__:Cleaner(context),
    }