class UploadAPI(BaseAbility):

  def api_upload_images(self,opts:dict)->any:
    pass