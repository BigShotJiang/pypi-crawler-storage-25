# assert
from blues_lib.tools.ability.atom.matcher.AssertMatcher import AssertMatcher

# element 
from blues_lib.tools.ability.atom.matcher.ElementTextMatcher import ElementTextMatcher
from blues_lib.tools.ability.atom.matcher.ElementValueMatcher import ElementValueMatcher
from blues_lib.tools.ability.atom.matcher.ElementAttributeMatcher import ElementAttributeMatcher
from blues_lib.tools.ability.atom.matcher.ElementCountMatcher import ElementCountMatcher
from blues_lib.tools.ability.atom.matcher.UrlMatcher import UrlMatcher
from blues_lib.tools.TaskContext import TaskContext

class MatcherAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      AssertMatcher.__name__:AssertMatcher(context),
      ElementTextMatcher.__name__:ElementTextMatcher(context),
      ElementValueMatcher.__name__:ElementValueMatcher(context),
      ElementAttributeMatcher.__name__:ElementAttributeMatcher(context),
      ElementCountMatcher.__name__:ElementCountMatcher(context),
      UrlMatcher.__name__:UrlMatcher(context),
    }