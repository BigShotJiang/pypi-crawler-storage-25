from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.action.mouse.MouseBase import MouseBase


class MouseMove(MouseBase):
  
  def move_to_element(self,options:dict)->int:
    '''
    Moves the mouse to the in-view center point of the element
    If the element outside in the viewport, it will move into the viewport automatically
    Automaic moving : the element's bottom border align to the window's bottom border
    Args:
      options (dict): The element to select.
        - options['target'] (str|list[str]) : the element to move to
        - options['nths'] (list[int]) : the nth of the element, e.g. [1,2,3] for the first, second, third element
        - options['interval'] (int|float) : the interval between each move, default 0.5
    Returns:
      int : the move count
    '''
    move_count:int = 0
    opts_list:list[dict] = self.__get_opts_list(options)
    for opts in opts_list:
      move_count += self.__move_once(opts)
    return move_count
  
  def __get_nth_targets(self,target:str,nths:list[int])->list[str]:
    targets:list[str] = []
    for nth in nths:
      targets.append(f'{target}:nth-of-type({nth})')
    return targets
  
  def __get_opts_list(self,options:dict)->list[dict]:
    target:str|list[str] = options.get('target','')
    nths:list[int] = options.get('nths',[])
    if not target:
      return []

    if not isinstance(target,list):
      target = self.__get_nth_targets(target,nths) if nths else [target]

    opts_list:list[dict] = []
    for t in target:
      opts_list.append({
        **options,
        'target':t,
      })
    return opts_list
  
  def __move_once(self,options:dict)->int:
    elem:WebElement|None = self._querier.query_element(options)
    interval:int|float = options.get('interval') or 0.5
    if elem:
      self._chains.move_to_element(elem).pause(interval).perform()
      return 1
    return 0

  def move_to_element_with_offset(self,options:dict)->bool:
    '''
    Offset form the element
    This method moves the mouse to the in-view center point of the element, 
    Then moves by the provided offset.
     - if the offset pointer out of the view, will throw exception
    Args:
      options (dict): The element to select.
        - options['target'] (ElementTarget) : the element to click
        - options['value'] (tuple[int,int]) : the offset value x,y , e.g. (10, 10)
    Returns:
      bool : True if move the mouse successfully, False otherwise
    '''
    elem:WebElement|None = self._querier.query_element(options)
    value:tuple[int,int] = options.get('value') or (0,0)
    if not elem:
      return False
    self._chains.move_to_element_with_offset(elem,*value).perform()
    return True

  def move_to_location(self,options:dict)->True:
    '''
    Offset from Viewport
    The viewport's top left point to the element's center point (not the element's top left point)
    Test with hold
    Args:
      options (dict): The element to select.
        - options['value'] (tuple[int,int]) : the offset value, e.g. (10, 10)
    Returns:
      bool : True if move the mouse successfully, False otherwise
    '''
    value:tuple[int,int] = options.get('value') or (0,0)
    self._builder.pointer_action.move_to_location(*value)
    self._builder.perform()
    return True

  def move_by_offset(self,options:dict)->True:
    '''
    Offset from Viewport
    This method moves the mouse from its current position by the offset provided by the user. 
    Test with hold
    Args:
      options (dict): The element to select.
        - options['value'] (tuple[int,int]) : the offset value, e.g. (10, 10)
    Returns:
      bool : True if move the mouse successfully, False otherwise
    '''
    value:tuple[int,int] = options.get('value') or (0,0)
    self._chains.move_by_offset(*value).perform()
    return True

