from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility

class WindowBase(QuerierAbility):
  """
  Working with windows and tabs
  Reference : https://www.selenium.dev/documentation/webdriver/interactions/windows/
  """
  
  pass
