from blues_lib.tools.ability.atom.file.Reader import Reader
from blues_lib.tools.ability.atom.file.Writer import Writer
from blues_lib.tools.ability.atom.file.Remover import Remover
from blues_lib.tools.TaskContext import TaskContext

class FileAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      Reader.__name__:Reader(context),
      Writer.__name__:Writer(context),
      Remover.__name__:Remover(context),
    }