# driver
from blues_lib.tools.ability.atom.webdriver.driver.Session import Session

# element 
from blues_lib.tools.ability.atom.webdriver.element.Finder import Finder
from blues_lib.tools.ability.atom.webdriver.element.Information import Information 
from blues_lib.tools.ability.atom.webdriver.element.Interaction import Interaction 
from blues_lib.tools.ability.atom.webdriver.element.File import File

# action api
from blues_lib.tools.ability.atom.webdriver.action.Keyboard import Keyboard
from blues_lib.tools.ability.atom.webdriver.action.Mouse import Mouse
from blues_lib.tools.ability.atom.webdriver.action.Wheel import Wheel

# interaction
from blues_lib.tools.ability.atom.webdriver.interaction.JavaScript import JavaScript 
from blues_lib.tools.ability.atom.webdriver.interaction.Navigation import Navigation
from blues_lib.tools.ability.atom.webdriver.interaction.Window import Window
from blues_lib.tools.ability.atom.webdriver.interaction.Cookie import Cookie
from blues_lib.tools.ability.atom.webdriver.interaction.Alerts import Alerts
from blues_lib.tools.ability.atom.webdriver.interaction.Frame import Frame
from blues_lib.tools.ability.atom.webdriver.interaction.Browser import Browser

# wait
from blues_lib.tools.ability.atom.webdriver.wait.EC import EC
from blues_lib.tools.ability.atom.webdriver.wait.Querier import Querier
from blues_lib.tools.TaskContext import TaskContext

from blues_lib.tools.ability.atom.webdriver.combo.Combo import Combo

class DriverAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      # driver
      Session.__name__:Session(context),
        
      # element 
      Finder.__name__:Finder(context),
      Information.__name__:Information(context),
      Interaction.__name__:Interaction(context),
      File.__name__:File(context),

      # action api
      Keyboard.__name__:Keyboard(context),
      Mouse.__name__:Mouse(context),
      Wheel.__name__:Wheel(context),

      # interaction
      JavaScript.__name__:JavaScript(context),
      Navigation.__name__:Navigation(context),
      Window.__name__:Window(context),
      Cookie.__name__:Cookie(context),
      Alerts.__name__:Alerts(context),
      Frame.__name__:Frame(context),
      Browser.__name__:Browser(context),
      
      # wait
      EC.__name__:EC(context),
      Querier.__name__:Querier(context),
      
      # combo
      Combo.__name__:Combo(context),
    }