from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts,SQLCondition
from blues_lib.services.sql.DBMutator import DBMutator
from blues_lib.supports.dp.output.STDOut import STDOut
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper

class DBDeleter(BaseAbility):

  def sql_delete(self,options:SQLOpts)->STDOut:
    table:str = options.get('table')
    conditions:list[SQLCondition] = SQLHelper.get_conditions(options)
    mutator = DBMutator(table)
    return mutator.delete(conditions)
