from blues_lib.tools.ability.atom.webdriver.DriverAbility import DriverAbility
from blues_lib.tools.ability.atom.webdriver.interaction.JavaScript import JavaScript

class Session(DriverAbility):
  """
  Working with session
  Reference : https://www.selenium.dev/documentation/webdriver/drivers/
  """

  def open(self,options:dict)->str: 
    '''
    Open a page and return the current url
    Args:
      options (dict): the options
    Returns:
      str: The current url
    '''
    status = self.get(options)
    if not status:
      return False
    
    style:dict|str = options.get('style')
    if style:
      javascript = JavaScript(self._context)
      javascript.set_head_style({'value':style})

    return options.get('value','')
      
  def get(self,options:dict)->bool: 
    '''
    Open a page
    Args:
      options (dict): the options
        - value (str): The url to open
    Returns:
      bool: True if the page is opened successfully, False otherwise
    '''
    url:str = options.get('value','')
    if not url:
      return True
    try:
      self._driver.get(url)
      return True        
    except Exception as e:
      return False

  def close(self)->bool:
    '''
    Close the current window or tab
    If only one window/tab ,the browser will be closed
    Returns:
      bool: True if the window is closed successfully, False otherwise
    '''
    try:
      self._driver.close()
      return True
    except Exception as e:
      return False

  def quit(self)->bool:
    '''
    Close all windows and tabs
    Returns:
      bool: True if the browser is closed successfully, False otherwise
    '''
    try:
      self._driver.quit()
      return True
    except Exception as e:
      return False

  def get_log(self)->list:
    '''
    Get the log of the current session
    Returns:
      list: A list of log entries.
    '''
    return self._driver.get_log("browser")

  def is_driver_available(self)->bool:
    '''
    Whether the current driver is available
    Returns:
      bool 
    '''
    try:
      self._driver.current_url
      return True
    except Exception as e:
      return False
