from blues_lib.tools.ability.atom.webdriver.combo.ComboBase import ComboBase
from blues_lib.types import ToolDef

class ComboUpload(ComboBase):

  def fillin_files(self,options:dict)->bool:
    tools:list[ToolDef] = []
    self._add_click_seq_tool(options,tools,'prev_click')
    self.__add_upload_tools(options,tools)
    self.__add_wait_tool(options,tools)
    self._add_click_seq_tool(options,tools,'post_click')
    self.__add_post_desc_tools(options,tools)
    result:dict = self._exec_tools(tools)
    return self._get_result(result)
  
  def __add_upload_tools(self,options:dict,tools:list[ToolDef])->None:
    input_tools:list[ToolDef] = self._get_input_tools(options,'upload')
    tools.extend(input_tools)
      
  def __add_post_desc_tools(self,options:dict,tools:list[ToolDef])->None:
    input_tools:list[ToolDef] = self._get_input_tools(options,'send_keys','post_desc')
    tools.extend(input_tools)
      
  def __add_wait_tool(self,options:dict,tools:list[ToolDef])->None:
    post_click:list[str] = options.get('post_click') or []
    if not post_click:
      return
    target = post_click[0]
    
    tool:ToolDef = {
      "name":"element_not_to_have_attr",
      "options":{
        "target":target,
        "name":"disabled",
      }
    }
    tools.append(tool)