from blues_lib.tools.ability.atom.llm.LLMClient import LLMClient
from blues_lib.tools.TaskContext import TaskContext

class LLMAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      LLMClient.__name__:LLMClient(context),
    }