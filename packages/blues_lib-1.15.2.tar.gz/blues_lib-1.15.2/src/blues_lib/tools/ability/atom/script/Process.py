from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
import os
import uuid
import platform
import subprocess
from blues_lib.utils.file.FileWriter import FileWriter
from blues_lib.utils.file.FileReader import FileReader
from blues_lib.utils.file.File import File

class Process(BaseAbility):
  
  def kill_chrome(self)->bool:
    '''
    Stop all chrome process
    @returns {int} : 0-success >0- failure
    '''
    return self.kill({"value":"chrome"})
  
  def kill(self, options:dict)->bool:
    '''
    Stop a app's all process
    @param {str} task_name : the app's process name
    @returns {int} : 0-success >0- failure
    '''
    system = platform.system().lower()
    name:str = options.get("value","")
    if not name:
      return False
    
    try:
      if 'windows' in system:
        # Windows system
        return os.system(f'taskkill /F /IM {name}.exe') == 0
      elif 'darwin' in system:
        # macOS system
        return os.system(f'pkill -f {name}') == 0
      elif 'linux' in system:
        # Linux system
        return os.system(f'pkill -f {name}') == 0
      else:
        # Unsupported system
        self._logger.warning(f"Unsupported operating system: {system}")
        return False
    except Exception as e:
      self._logger.warning(f"Error occurred while killing process: {e}")
      return False

  def agent_cmd(self, options: dict) -> any:
    '''
    use ai agent, write the result to a file and read it back
    '''
    file_path:str = self.__get_file_path(options)
    result = self.shell_cmd(options)
    if not file_path:
      return result
    return self.__return_content(options,file_path)
  
  def agent_terminal(self, options: dict) -> str:
    '''
    use ai agent, write the result to a file and read it back
    '''
    file_path:str = self.__get_file_path(options)
    result = self.shell_terminal(options)
    if not file_path:
      return result
    options.setdefault("timeout",3600)
    options.setdefault("interval",30)
    return self.__return_content(options,file_path)

  def __return_content(self,options:dict,file_path:str)->any:
    as_path:bool = options.pop("as_path",True)
    if as_path:
      return file_path

    timeout:int|float = options.get("timeout",2)
    interval:int|float = options.get("interval",1)
    stat:bool = File.wait(file_path,timeout,interval)
    if not stat:
      self._logger.warning(f"Error: agent output file {file_path} does not exist")
      return ''


    ext:str = File.get_extension(file_path)
    if ext=='json':
      return FileReader.read_json(file_path)
    else:
      return FileReader.read_text(file_path)
    
  def __get_file_path(self, options: dict)->str:
    to_file:dict|str|bool = options.pop("to_file",{})
    if not to_file:
      return ''
    
    file_path:str = File.get_abs_file(to_file)
    prompt:str = f' ; 最后将回答或数据写入文件 {file_path}'
    command:str|list = options["command"]

    if isinstance(command,list):
      command[-1] += prompt
    else:
      if command.endswith("\""):
        command = command[:-1] + prompt + "\""
      else:
        command += prompt
    options["command"] = command 
    return file_path

  def shell_cmd(self, options: dict) -> str:
    '''
    Execute shell command synchronously (blocking) and return output
    @note: This method blocks until command completes. Use shell_terminal() for non-blocking execution.
    @param {dict} options: 
      - command: str|list - the shell command to execute (string or list of args)
      - cwd: str (optional) - working directory before execution
      - timeout: int (optional) - timeout in seconds, default 3600 (60 minutes)
    @returns {str} : command output if success, error message if failure
    '''
    command, cwd = self.__parse_shell_options(options)
    timeout: int = options.get("timeout", 3600)
    
    if not command:
      error_msg = "Error: command is empty"
      self._logger.warning(error_msg)
      return ''

    shell = isinstance(command, str)
    
    # Windows 上列表形式的命令需要通过 cmd.exe 执行
    if isinstance(command, list) and platform.system().lower() == 'windows':
      def quote_arg(arg):
        return f'"{arg}"' if ' ' in arg else arg
      command = 'cmd /c ' + ' '.join(quote_arg(arg) for arg in command)
      shell = True

    try:
      result = subprocess.run(
        command,
        cwd=cwd,
        timeout=timeout,
        shell=shell,
        capture_output=True,
        encoding='utf-8',
        errors='replace',
        text=True
      )
      
      if result.returncode == 0:
        text:str = result.stdout.strip()
        return FileWriter.write_or_return(options,text)
      else:
        error_msg = f"Command execution failed with return code {result.returncode}"
        if result.stderr:
          error_msg += f"\nstderr: {result.stderr.strip()}"
        self._logger.warning(error_msg)
        return ''
    except subprocess.TimeoutExpired:
      error_msg = f"Error: Command execution timed out after {timeout} seconds"
      self._logger.warning(error_msg)
      return ''
    except Exception as e:
      error_msg = f"Error occurred while executing shell command: {e}"
      self._logger.warning(error_msg)
      return ''


  def shell_terminal(self, options: dict) -> None:
    '''
    Execute command in a separate terminal window (non-blocking)
    @note: This method starts a new terminal window and returns immediately. 
           Use shell_cmd() to execute commands synchronously and capture output.
    @param {dict} options: 
      - command: str|list - the shell command to execute (string or list of args)
      - cwd: str (optional) - working directory before execution
    @returns {None} : always returns None
    '''
    command, cwd = self.__parse_shell_options(options)
    
    if not command:
      self._logger.warning("Error: command is empty")
      return None
    
    if isinstance(command, list):
      def quote_arg(arg):
        return f'"{arg}"' if ' ' in arg else arg
      command = ' '.join(quote_arg(arg) for arg in command)
    
    system = platform.system().lower()

    try:
      if 'windows' in system:
        subprocess.Popen(
          ['start', 'cmd', '/k', command],
          cwd=cwd,
          shell=True,
          creationflags=subprocess.CREATE_NEW_CONSOLE
        )
      elif 'darwin' in system:
        subprocess.Popen(
          ['open', '-a', 'Terminal', '--args', '-e', f"{command}"],
          cwd=cwd
        )
      elif 'linux' in system:
        subprocess.Popen(
          ['gnome-terminal', '--command', f"bash -c '{command}; exec bash'"],
          cwd=cwd
        )
      else:
        self._logger.warning(f"Unsupported operating system: {system}")
        return None
      
      self._logger.info(f"Terminal started successfully with command: {command}")
      return None
    except Exception as e:
      self._logger.warning(f"Error occurred while starting terminal: {e}")
      return None
  
  def __parse_shell_options(self, options: dict) -> tuple[str|list, str|None]:
    '''
    Parse and validate shell command options
    @param {dict} options: command options
    @returns {tuple} : (command, cwd)
    '''
    command = options.get("command", "")
    if isinstance(command, str):
      command = command.strip()
    elif isinstance(command, list):
      command = [str(arg) for arg in command]
    cwd: str|None = options.get("cwd", "").strip() or None
    
    if cwd:
      cwd = os.path.normpath(cwd)
      self._logger.info(f"cwd: {cwd}")
    
    self._logger.info(f"command: {command}")
    return (command, cwd)
