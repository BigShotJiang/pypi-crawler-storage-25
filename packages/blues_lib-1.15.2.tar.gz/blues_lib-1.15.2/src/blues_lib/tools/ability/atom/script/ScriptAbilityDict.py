from blues_lib.tools.ability.atom.script.Python import Python
from blues_lib.tools.ability.atom.script.Process import Process
from blues_lib.tools.TaskContext import TaskContext

class ScriptAbilityDict():

  @classmethod
  def get(cls,context:TaskContext)->dict:
    return {
      Python.__name__:Python(context),
      Process.__name__:Process(context),
    }