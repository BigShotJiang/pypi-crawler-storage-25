import logging
from typing import Self
from blues_lib.supports.dp.exception import  AbilityExecError, BlockSeqError 
from blues_lib.tools.ability.AbilityFacade import AbilityFacade
from blues_lib.tools.ability.AbilityExecutor import AbilityExecutor
from blues_lib.types import ToolDef
from blues_lib.tools.TaskContext import TaskContext
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.dynamic.DynamicFacade import DynamicFacade

class AbilityClient: 
  '''
  调用AbilityFacade,提供：
  - 异常捕获与driver清理
  - 多AbilityFacade Flow调用
  '''
  _logger = logging.getLogger('airflow.task')

  @classmethod
  def repeat(cls,metas_seq:list[tuple[dict|None,dict]])->list[any]:
    results:list[any] = []
    for ctx,meta in metas_seq:
      result:any = cls.execute(ctx,meta)
      results.append(result)
    return results

  @classmethod
  def execute(cls,ctx:TaskContext|dict|None,meta:ToolDef)->any:
    """
    execute the method in the facade
    Args:
      meta (ToolDef): the method name
    Returns:
      list[any]: the method return
    """
    context = cls._get_context(ctx)
    name:str = meta.get('name')
    description:str = meta.get('description')
    options = meta.get('options')
    
    try:
      facade = AbilityFacade(context)
      result:dict =  facade.execute(name,options)
      context.add_stat(True,name,description)
      return result
    except (AbilityExecError,BlockSeqError,Exception) as e:
      tools:list[ToolDef] = options.get('block_seq_tools') or []
      AbilityExecutor(context).execute(tools)
      context.add_stat(False,name,description,str(e))
      return None
    finally:
      context.teardown()
      
  @classmethod
  def _get_context(cls,ctx:TaskContext|dict|None)->TaskContext:
    if isinstance(ctx,TaskContext):
      return ctx
    return TaskContext(ctx)

  @classmethod
  def register(cls,ability_classes:list[type[BaseAbility]]|type[BaseAbility])->Self:
    DynamicFacade.register(ability_classes)
    return cls
