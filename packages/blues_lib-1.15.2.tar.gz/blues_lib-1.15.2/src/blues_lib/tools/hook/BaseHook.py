import logging
from abc import ABC
from blues_lib.types import ToolDef,ToolSummary
from blues_lib.tools.ability.AbilityExecutor import AbilityExecutor
from blues_lib.tools.hook.handler import AutoSwitchHandler
from blues_lib.tools.TaskContext import TaskContext
from blues_lib.utils.jinja2.Jinja2Renderer import Jinja2Renderer

class BaseHook(ABC):
  
  _TOOLS_KEYS = [
    'prev_tools',
    'post_tools',
    'skip_loop_tools',
    'skip_seq_tools',
    'block_seq_tools'
  ]
  
  def __init__(self,context:TaskContext,tool_summary:ToolSummary,host_id:str):
    self._logger = logging.getLogger('airflow.task')
    # use a new context in hook
    self._context:TaskContext = context
    self._executor = AbilityExecutor(self._context)

    self._tool_summary = self._get_summary(tool_summary)
    self._prev_tools: list[ToolDef] = self._tool_summary.get('prev_tools')
    self._post_tools: list[ToolDef] = self._tool_summary.get('post_tools')
    
    self._host_id:str = host_id
    self._add_builtin_tools()
    self.remove_empty_tools()
    
  def _get_summary(self,tool_summary:dict|None)->ToolSummary:
    new_summary = tool_summary or {}
    for key in self._TOOLS_KEYS:
      new_summary[key] = new_summary.get(key) or []
    return new_summary

  def prev(self)->None:
    if self._prev_tools:
      self._executor.execute(self._prev_tools)

  def post(self)->None:
    if self._post_tools:
      # 执行hook level渲染，注入当前修饰tool的原始result作为变量
      post_tools = Jinja2Renderer.render_hook(self._post_tools, self._context.result)
      self._executor.execute(post_tools)
    
  def _add_builtin_tools(self)->None:
    AutoSwitchHandler(self._tool_summary,self._context).handle()

  def remove_empty_tools(self):
    keys:list[str] = list(self._tool_summary.keys())
    for key in keys:
      if key.endswith('_tools') and not self._tool_summary[key]:
        del self._tool_summary[key]
    