from blues_lib.tools.hook.BaseHook import BaseHook

class AbilityHook(BaseHook):
  pass