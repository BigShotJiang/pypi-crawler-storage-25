import json
from typing import Any,Callable
from blues_lib.utils.file.FileReader import FileReader
from blues_lib.types import ToolDef

class PythonExecutor:

  @classmethod
  def execute(cls,cb_def:ToolDef)->Any:
    '''
    Execute python script
    Args:
      cb_def (ToolDef): Callback definition
      args (list[Any]|Any|None, optional): Arguments to pass to the script.
    '''
    name:str = cb_def.get('name')
    options:dict[str,Any] = cb_def.get('options',{})
    script_or_path:str = options.get('script','') # script or file path
    kwargs:dict[str,Any] = options.get('value',{})
    try:
      if 'lambda' in name:
        return cls.execute_lambda(script_or_path,kwargs)
      elif 'func' in name:
        return cls.execute_function(script_or_path,kwargs)
      elif 'file' in name:
        return cls.execute_file(script_or_path,kwargs)
    
    except SyntaxError as e:
      raise SyntaxError(f"SyntaxError：{e}\n Script：{script_or_path}") from e
    except NameError as e:
      raise NameError(f"NameError：{e}\n Script：{script_or_path}") from e
    except Exception as e:
      raise Exception(f"Exception：{e}\n Script：{script_or_path}") from e
    
  @classmethod
  def execute_string(cls,script_or_file:str,kwargs:Any)->Any:
    script_or_file = script_or_file.strip()
    if script_or_file.startswith('lambda'):
      return cls.execute_lambda(script_or_file,kwargs)
    elif script_or_file.startswith('def'):
      return cls.execute_function(script_or_file,kwargs)
    else:
      return cls.execute_file(script_or_file,kwargs)

  @classmethod
  def execute_lambda(cls,script:str,kwargs:dict[str,Any])->Any:
    global_ns = {'json': json}
    local_ns = {}
    func = eval(script,global_ns,local_ns)
    return func(kwargs)

  @classmethod
  def execute_function(cls,script:str,kwargs:dict[str,Any])->Any:
    global_ns = {'json': json}
    local_ns = {}
    exec(script, global_ns, local_ns)
    func = cls._get_function(local_ns)
    return func(kwargs)
  
  @classmethod
  def execute_file(cls,file_path:str,kwargs:dict[str,Any])->Any:
    script = FileReader.read(file_path).strip()
    return cls.execute_function(script,kwargs)
  
  @classmethod 
  def _get_function(cls,local_ns:dict)->Callable:
    functions = []
    for name, obj in local_ns.items():
      # 判断是否是函数（排除内置函数和类方法）
      if callable(obj) and not name.startswith('__'):
        # 排除 exec 执行过程中可能产生的特殊对象
        if type(obj).__name__ == 'function':
          functions.append((name, obj))
    
    # 处理函数数量异常的情况
    if len(functions) == 0:
      raise ValueError("no available function found in script")
    
    # return the first function found
    _, func = functions[0]
    return func
