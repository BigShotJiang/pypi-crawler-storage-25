import pandas

class CSVManager():

  @classmethod
  def read_columns(cls,csv_file:str) -> list[str]:
    '''
    Read the column names (header row) from a csv file
    @param {str} csv_file: the csv file path
    @return {list[str]}: list of column names
    '''
    df = pandas.read_csv(csv_file)
    return df.columns.tolist()

  @classmethod
  def read_rows(cls,csv_file:str) -> list[dict]:
    '''
    Read all data rows from a csv file
    @param {str} csv_file: the csv file path
    @return {list[dict]}: list of rows as dictionaries
    '''
    df = pandas.read_csv(csv_file)
    return df.to_dict(orient='records')

  @classmethod
  def write(cls,file_path:str,rows:list,columns:list[str]|None=None,index:bool=False) -> None:
    '''
    Create or overwrite a csv file
    @param {str} file_path: the csv file abs path
    @param {list} rows: data rows, either list of lists or list of dicts
    @param {list[str]|None} columns: header row names (not needed if rows are dicts)
    @param {bool} index: whether to create an index column
    '''
    if isinstance(rows[0],dict):
      df = pandas.DataFrame(rows)
    else:
      df = pandas.DataFrame(rows, columns=columns)
    df.to_csv(file_path, index=index)

  @classmethod
  def append(cls,file_path:str,rows:list,index:bool=False) -> None:
    '''
    Append rows to an existing csv file
    @param {str} file_path: the csv file abs path
    @param {list} rows: data rows, either list of lists or list of dicts
    @param {bool} index: whether to create an index column
    '''
    df = pandas.DataFrame(rows)
    df.to_csv(file_path,mode='a',header=False,index=index) 
