"""Text file processing service."""

from __future__ import annotations

import re
import types as _t
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from models import TextModel
from models.base import BaseModel, ModelConfig, ModelType
from models.provider_factory import get_text_model
from utils.file_readers import FileReadError, read_file
from utils.readers import read_file_via_safedir, read_file_via_safedir_anchored
from utils.safedir import SafeDir, SymlinkRejected
from utils.text_processing import (
    clean_text,
    truncate_text,
)


@dataclass
class ProcessedFile:
    """Result of file processing."""

    file_path: Path
    description: str
    folder_name: str
    filename: str
    original_content: str | None = None
    processing_time: float = 0.0
    error: str | None = None
    transcript: str | None = None


# Stop-words and noise words filtered from AI-generated names.
# Defined at module level to avoid recreation on every call.
_CLEAN_NAME_STOP_WORDS: frozenset[str] = frozenset(
    {
        "the",
        "a",
        "an",
        "and",
        "or",
        "but",
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "is",
        "are",
        "was",
        "were",
        "be",
        "with",
        "about",
        "very",
        "here",
        "words",
        "document",
        "file",
        "text",
        "untitled",
        "unknown",
    }
)


class TextProcessor:
    """Process text files using AI to generate metadata.

    This service:
    - Reads text from various file formats
    - Generates summaries using LLM
    - Creates folder names and filenames
    - Cleans and sanitizes output
    """

    def __init__(
        self,
        text_model: BaseModel | None = None,
        config: ModelConfig | None = None,
    ) -> None:
        """Initialize text processor.

        Args:
            text_model: Pre-initialized text model (optional). Any
                ``BaseModel`` subclass is accepted, allowing Ollama and
                OpenAI-compatible models to be passed interchangeably.
            config: Model configuration (used if ``text_model`` not provided).
                The ``config.provider`` field controls which backend is used.
                If omitted, the Ollama default configuration is applied
                regardless of any global provider setting.
        """
        if text_model is not None:
            if text_model.config.model_type != ModelType.TEXT:
                raise ValueError(
                    f"TextProcessor requires a TEXT model, got {text_model.config.model_type}"
                )
            self.text_model = text_model
            self._owns_model = False
        else:
            config = config or TextModel.get_default_config()
            self.text_model = get_text_model(config)
            self._owns_model = True

        logger.info("TextProcessor initialized")

    def initialize(self) -> None:
        """Initialize the text model if not already initialized."""
        if not self.text_model.is_initialized:
            self.text_model.initialize()
            logger.info("Text model initialized")

    def process_file(
        self,
        file_path: str | Path,
        generate_description: bool = True,
        generate_folder: bool = True,
        generate_filename: bool = True,
        scan_root: str | Path | None = None,
    ) -> ProcessedFile:
        """Process a single text file.

        Args:
            file_path: Path to file
            generate_description: Whether to generate description
            generate_folder: Whether to generate folder name
            generate_filename: Whether to generate filename
            scan_root: Optional anchor directory the caller walked to
                find *file_path*. When provided, the SafeDir read uses
                anchored traversal — every intermediate path component
                between *scan_root* and *file_path* is opened with
                ``O_NOFOLLOW`` so a symlink swapped into an ancestor
                between the walk and this read is refused with
                ``SymlinkRejected``. Closes the nested-ancestor TOCTOU
                window (#286) that parent-rooted opening leaves open.
                When ``None`` (default), falls back to parent-rooted
                opening: only the final component is symlink-protected.
                Pass *scan_root* whenever the caller has a meaningful
                trusted root (the directory tree it walked).

        Returns:
            ProcessedFile with metadata
        """
        import time

        file_path = Path(file_path)
        scan_root_path = Path(scan_root) if scan_root is not None else None
        start_time = time.time()

        try:
            # Read file content via SafeDir for the migrated extensions
            # (txt/md/docx/pdf/rtf/csv/xlsx/pptx — the LLM ingestion path).
            # When ``scan_root`` is provided, ``read_file_via_safedir_anchored``
            # walks each intermediate component with ``O_NOFOLLOW`` so a
            # symlink swapped into ANY ancestor between the walk and this
            # read is refused — closes both the final-component and the
            # nested-ancestor TOCTOU windows for the LLM-exfiltration
            # vector documented in #264. Without ``scan_root``, falls back
            # to parent-rooted ``read_file_via_safedir`` (final-component
            # protection only — same as PR3a–PR3i behaviour).
            logger.debug("Reading file: {}", file_path.name)
            content: str | None = None
            try:
                if scan_root_path is not None:
                    content = read_file_via_safedir_anchored(file_path, trusted_root=scan_root_path)
                else:
                    with SafeDir.open_root(file_path.parent) as safe_dir:
                        content = read_file_via_safedir(safe_dir, file_path.name)
            except SymlinkRejected as exc:
                logger.warning("Refused to read symlinked file {}: {}", file_path, exc)
                return ProcessedFile(
                    file_path=file_path,
                    description="",
                    folder_name="errors",
                    filename=file_path.stem,
                    error=f"Refused to read symlink: {file_path.name}",
                )
            except NotImplementedError:
                # SafeDir requires POSIX dir_fd / O_NOFOLLOW; on Windows
                # the Windows port is deferred (#264). Fall back to the
                # legacy path-based reader so Windows users can still
                # process .txt/.md/.pdf/.docx through TextProcessor.
                # Tracked for follow-up in PR3b–PR3e.
                logger.debug(
                    "SafeDir unavailable on this platform; using legacy reader for {}",
                    file_path.name,
                )
            if content is None:
                # Either the SafeDir dispatcher returned ``None`` (extension
                # not yet migrated — archives, ebooks, scientific, CAD,
                # handled in PR3b–PR3e) OR SafeDir is unavailable (Windows).
                # Real FS errors from the SafeDir branch propagate to the
                # outer ``except FileReadError`` / ``except OSError``
                # handlers — never silently masked by a path-based retry
                # that could follow a symlink swapped in mid-flight.
                content = read_file(file_path)

            if content is None:
                return ProcessedFile(
                    file_path=file_path,
                    description="",
                    folder_name="unsupported",
                    filename=file_path.stem,
                    error="Unsupported file type",
                )

            # Truncate if too long
            content = truncate_text(content, max_chars=5000)

            # Generate description (summary)
            description = ""
            if generate_description:
                description = self._generate_description(content)
                logger.debug("Generated description ({} chars)", len(description))

            # Generate folder name
            folder_name = ""
            if generate_folder:
                folder_name = self._generate_folder_name(
                    description or content, original_stem=file_path.stem
                )
                logger.debug("Generated folder name ({} chars)", len(folder_name))

            # Generate filename
            filename = ""
            if generate_filename:
                filename = self._generate_filename(
                    description or content, original_stem=file_path.stem
                )
                logger.debug("Generated filename ({} chars)", len(filename))

            processing_time = time.time() - start_time

            return ProcessedFile(
                file_path=file_path,
                description=description,
                folder_name=folder_name,
                filename=filename,
                original_content=content[:500],  # Keep first 500 chars for reference
                processing_time=processing_time,
            )

        except FileReadError as e:
            # B2: include exception type so filesystem-level failures
            # can be distinguished from downstream model errors in log
            # aggregates. Loguru ``{}`` interpolation (not f-string)
            # preserves structured capture (G2).
            logger.error(
                "Failed to read {} (type={}): {}",
                file_path.name,
                type(e).__name__,
                e,
            )
            return ProcessedFile(
                file_path=file_path,
                description="",
                folder_name="errors",
                filename=file_path.stem,
                # Preserve the existing ``error=str(e)`` contract — B2
                # scope is log-message categorisation, not the public
                # ``ProcessedFile.error`` field.
                error=str(e),
            )
        except (RuntimeError, ValueError, OSError, AttributeError) as e:
            # B2: typed tuple already narrows to "model / inference"
            # errors; log the class name so a RuntimeError
            # (provider) vs AttributeError (uninitialised model) can be
            # bucketed without reparsing.
            logger.exception(
                "Failed to process {} (type={}): {}",
                file_path.name,
                type(e).__name__,
                e,
            )
            return ProcessedFile(
                file_path=file_path,
                description="",
                folder_name="errors",
                filename=file_path.stem,
                error=str(e),
            )

    def _clean_ai_generated_name(self, name: str, max_words: int = 3) -> str:
        """Clean AI-generated folder/file names by stripping stop-words and noise.

        Filters common stop-words (articles, prepositions, filler adjectives) and
        generic noise words (file, document, untitled) so only meaningful terms remain.

        Args:
            name: AI-generated name
            max_words: Maximum number of words

        Returns:
            Cleaned name
        """
        # Convert underscores and hyphens to spaces
        name = name.replace("_", " ").replace("-", " ")

        # Remove special characters (keep letters, digits and spaces)
        name = re.sub(r"[^a-z0-9\s]", "", name.lower())

        # Split into words
        words = name.split()

        # Filter and deduplicate
        filtered = []
        seen = set()
        for word in words:
            if word and word not in _CLEAN_NAME_STOP_WORDS and word not in seen and len(word) > 1:
                filtered.append(word)
                seen.add(word)

        # Limit to max words
        filtered = filtered[:max_words]

        # Join with underscores
        return "_".join(filtered) if filtered else ""

    def _generate_description(self, content: str) -> str:
        """Generate a summary/description of the content.

        Args:
            content: File content

        Returns:
            Summary text
        """
        prompt = f"""Summarize the following text in 100-150 words. Focus on main ideas and key details.

TEXT:
{content}

SUMMARY:"""

        try:
            response = self.text_model.generate(prompt, temperature=0.5, max_tokens=200)
            summary = response.strip()

            # Remove any "Summary:" prefix the AI might add
            for prefix in ["summary:", "here is the summary:", "the summary is:"]:
                if summary.lower().startswith(prefix):
                    summary = summary[len(prefix) :].strip()

            return summary
        except (RuntimeError, ValueError, OSError, AttributeError) as e:
            # B2: include exception class name so provider / tokenizer /
            # network surface can be distinguished in log aggregates.
            logger.error(
                "Failed to generate description (type={}): {}",
                type(e).__name__,
                e,
            )
            return f"Content about {content[:100]}..."

    def _generate_folder_name(self, text: str, original_stem: str | None = None) -> str:
        """Generate a folder name from text.

        Args:
            text: Description or content
            original_stem: Original filename stem (without extension) used as an
                additional hint for small models with limited context.

        Returns:
            Folder name (max 2 words)
        """
        hint_line = (
            f"\nFILENAME HINT: {original_stem} (original filename — use only if helpful)\n"
            if original_stem
            else ""
        )
        prompt = f"""Based on the text below, generate a general category or theme.

RULES:
1. Maximum 2 words (e.g., "machine_learning", "healthcare", "recipes")
2. Use ONLY nouns, no verbs
3. Be general, not specific
4. Use lowercase with underscores between words
5. NO generic terms like 'document', 'file', 'text', 'untitled'
6. Output ONLY the category, NO explanation

EXAMPLES:
- Text about AI in healthcare → "healthcare_technology"
- Text about Python coding → "programming"
- Text about chocolate recipes → "recipes"
- Text about financial planning → "finance"
{hint_line}
TEXT:
{text[:1000]}

CATEGORY:"""

        try:
            response = self.text_model.generate(prompt, temperature=0.3, max_tokens=30)

            # Debug: Log raw AI response
            logger.debug("AI folder response received ({} chars)", len(response))

            # Clean the response
            folder_name = response.strip().lower()

            # Remove common prefixes and quotes
            for prefix in ["category:", "folder:", "the category is", "the folder is"]:
                folder_name = folder_name.replace(prefix, "").strip()
            folder_name = folder_name.strip("\"'")

            # Remove newlines and extra spaces
            folder_name = " ".join(folder_name.split())

            # Use lighter cleaning for AI-generated names
            folder_name = self._clean_ai_generated_name(folder_name, max_words=2)

            if not folder_name or len(folder_name) < 3:
                # Fallback to keyword extraction
                logger.warning(
                    "Folder name empty or too short after AI generation, using keyword fallback"
                )
                folder_name = clean_text(text, max_words=2)
                logger.debug("Fallback folder name ({} chars)", len(folder_name))

            # Skip sanitize_filename since we already cleaned it
            # Just do final safety check
            import re

            folder_name = re.sub(r"[^\w_]", "_", folder_name)
            folder_name = re.sub(r"_+", "_", folder_name).strip("_")
            result = folder_name[:50] if folder_name else "documents"
            logger.info(f"Folder name generated ({len(result)} chars)")
            return result

        except (RuntimeError, ValueError, OSError, AttributeError) as e:
            # B2: include exception class name (see ``_generate_description``
            # for rationale).
            logger.error(
                "Failed to generate folder name (type={}): {}",
                type(e).__name__,
                e,
            )
            return "documents"

    def _generate_filename(self, text: str, original_stem: str | None = None) -> str:
        """Generate a filename from text.

        Args:
            text: Description or content
            original_stem: Original filename stem (without extension) used as an
                additional hint for small models with limited context.

        Returns:
            Filename (max 3 words, no extension)
        """
        hint_line = (
            f"\nFILENAME HINT: {original_stem} (original filename — use only if helpful)\n"
            if original_stem
            else ""
        )
        prompt = f"""Based on the text below, generate a specific descriptive filename.

RULES:
1. Maximum 3 words (e.g., "ai_healthcare_analysis", "python_best_practices")
2. Use meaningful nouns (NO verbs like 'shows', 'depicts', 'presents')
3. NO generic words like 'document', 'text', 'file', 'pdf', 'untitled'
4. Use lowercase with underscores between words
5. Be specific about the content, not generic
6. Output ONLY the filename, NO explanation

EXAMPLES:
- Text about AI in healthcare → "ai_healthcare_technology"
- Text about Python coding tips → "python_coding_guide"
- Text about chocolate chip cookies → "chocolate_chip_cookies"
- Text about 2023 budget → "budget_2023"
{hint_line}
TEXT:
{text[:1000]}

FILENAME:"""

        try:
            response = self.text_model.generate(prompt, temperature=0.3, max_tokens=30)

            # Debug: Log raw AI response
            logger.debug("AI filename response received ({} chars)", len(response))

            # Clean the response
            filename = response.strip().lower()

            # Remove common prefixes and quotes
            for prefix in ["filename:", "file:", "name:", "the filename is", "the name is"]:
                filename = filename.replace(prefix, "").strip()
            filename = filename.strip("\"'")

            # Remove file extensions if AI added them
            import re

            filename = re.sub(r"\.(txt|pdf|docx|md|jpg|png)$", "", filename)

            # Remove newlines and extra spaces
            filename = " ".join(filename.split())

            # Use lighter cleaning for AI-generated names
            filename = self._clean_ai_generated_name(filename, max_words=3)

            if not filename or len(filename) < 3:
                # Fallback to keyword extraction
                logger.warning(
                    "Filename empty or too short after AI generation, using keyword fallback"
                )
                filename = clean_text(text, max_words=3)
                logger.debug("Fallback filename ({} chars)", len(filename))

            # Skip sanitize_filename since we already cleaned it
            # Just do final safety check
            import re

            filename = re.sub(r"[^\w_]", "_", filename)
            filename = re.sub(r"_+", "_", filename).strip("_")
            result = filename[:50] if filename else "document"
            logger.info(f"Filename generated ({len(result)} chars)")
            return result

        except (RuntimeError, ValueError, OSError, AttributeError) as e:
            # B2: include exception class name (see ``_generate_description``
            # for rationale).
            logger.error(
                "Failed to generate filename (type={}): {}",
                type(e).__name__,
                e,
            )
            return "document"

    def cleanup(self) -> None:
        """Cleanup resources.

        Uses ``safe_cleanup()`` to wait for any in-flight generations
        before tearing down the model client.
        """
        if self._owns_model:
            self.text_model.safe_cleanup()
            logger.info("Text model cleaned up")

    def __enter__(self) -> TextProcessor:
        """Context manager entry."""
        self.initialize()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: _t.TracebackType | None,
    ) -> None:
        """Context manager exit."""
        self.cleanup()
