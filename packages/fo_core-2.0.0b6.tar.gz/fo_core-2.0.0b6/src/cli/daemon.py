"""Daemon control and pipeline CLI commands.

Provides sub-commands for starting, stopping, and monitoring the
background file organization daemon, plus a one-shot ``process`` command.
"""

from __future__ import annotations

import os
import signal
import sys
from pathlib import Path
from typing import Any, cast

import typer
from rich.console import Console
from rich.table import Table  # pyre-ignore[21]

from cli.path_validation import resolve_cli_path, validate_pair
from config.path_manager import get_state_dir

console = Console()

daemon_app = typer.Typer(
    name="daemon",
    help="Background daemon control and file processing pipeline.",
    no_args_is_help=True,
    rich_markup_mode=cast(Any, "rich"),
)

_DEFAULT_PID_DIR = get_state_dir()
_DEFAULT_PID_FILE = _DEFAULT_PID_DIR / "daemon.pid"


@daemon_app.command()
def start(
    watch_dir: Path | None = typer.Option(
        None, "--watch-dir", "-w", help="Directory to watch for new files."
    ),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o", help="Destination directory for organized files."
    ),
    foreground: bool = typer.Option(
        False, "--foreground", "-f", help="Run in the foreground (blocking)."
    ),
    poll_interval: float = typer.Option(
        1.0, "--poll-interval", help="Seconds between file-system polls."
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without moving files."),
) -> None:
    """Start the background file organization daemon."""
    from daemon.config import DaemonConfig
    from daemon.service import DaemonService

    # A.cli: resolve + validate both paths. watch_dir must exist;
    # output_dir is created on demand. Default "organized_output" is
    # resolved too so it passes through validate_pair — otherwise
    # ``--watch-dir .`` with no ``--output-dir`` would write into the
    # watched tree, which is exactly the nested pair we're trying to reject.
    if watch_dir is not None:
        watch_dir = resolve_cli_path(watch_dir, must_exist=True, must_be_dir=True)
    if output_dir is None:
        output_dir = resolve_cli_path(Path("organized_output"), must_exist=False, must_be_dir=True)
    else:
        output_dir = resolve_cli_path(output_dir, must_exist=False, must_be_dir=True)
    if watch_dir is not None:
        validate_pair(watch_dir, output_dir)
    watch_dirs = [watch_dir] if watch_dir else []
    out = output_dir

    config = DaemonConfig(
        watch_directories=watch_dirs,
        output_directory=out,
        pid_file=_DEFAULT_PID_FILE,
        dry_run=dry_run,
        poll_interval=poll_interval,
    )

    service = DaemonService(config)

    if foreground:
        console.print(f"[bold]Starting daemon[/bold] (foreground, poll={poll_interval}s)")
        if dry_run:
            console.print("[yellow]Dry-run mode — no files will be moved.[/yellow]")
        try:
            service.start()
        except KeyboardInterrupt:
            console.print("\n[dim]Daemon stopped by user.[/dim]")
    else:
        console.print("[bold]Starting daemon[/bold] in background...")
        if dry_run:
            console.print("[yellow]Dry-run mode — no files will be moved.[/yellow]")
        service.start_background()
        console.print(f"[green]Daemon started.[/green]  PID file: {_DEFAULT_PID_FILE}")


@daemon_app.command()
def stop() -> None:
    """Stop the running daemon."""
    from daemon.pid import PidFileManager

    mgr = PidFileManager()

    if not _DEFAULT_PID_FILE.exists():
        console.print("[yellow]No PID file found — daemon may not be running.[/yellow]")
        raise typer.Exit(code=1)

    # F2 (hardening roadmap #159): use ``read_pid_record`` so we parse
    # both JSON records written by ``write_pid_record`` and legacy
    # text-only files. ``read_pid`` only handles the legacy int format
    # and would silently return None for a JSON record, causing stop to
    # delete a valid PID file and leave the daemon orphaned.
    record = mgr.read_pid_record(_DEFAULT_PID_FILE)
    if record is None:
        console.print("[yellow]Could not read PID from file.[/yellow]")
        mgr.remove_pid(_DEFAULT_PID_FILE)
        raise typer.Exit(code=1)
    pid = record.pid

    console.print(f"Sending SIGTERM to PID {pid}...")
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        console.print("[yellow]Process not found — cleaning up PID file.[/yellow]")
        mgr.remove_pid(_DEFAULT_PID_FILE)
        raise typer.Exit(code=0) from None
    except PermissionError:
        console.print("[red]Permission denied. Try running with sudo.[/red]")
        raise typer.Exit(code=1) from None

    mgr.remove_pid(_DEFAULT_PID_FILE)
    console.print("[green]Daemon stopped.[/green]")


@daemon_app.command()
def status() -> None:
    """Show the current daemon status."""
    from daemon.pid import PidFileManager

    mgr = PidFileManager()
    running = mgr.is_running(_DEFAULT_PID_FILE)
    # F2: ``read_pid_record`` handles both JSON and legacy formats.
    record = mgr.read_pid_record(_DEFAULT_PID_FILE) if _DEFAULT_PID_FILE.exists() else None
    pid = record.pid if record is not None else None

    table = Table(title="Daemon Status")
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("State", "[green]Running[/green]" if running else "[dim]Stopped[/dim]")
    table.add_row("PID", str(pid) if pid else "—")
    table.add_row("PID File", str(_DEFAULT_PID_FILE))
    table.add_row(
        "Python",
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
    )

    console.print(table)


@daemon_app.command()
def watch(
    watch_dir: Path = typer.Argument(..., help="Directory to watch for file events."),
    poll_interval: float = typer.Option(1.0, "--poll-interval", help="Seconds between polls."),
) -> None:
    """Watch a directory and stream file events (Ctrl+C to stop)."""
    from watcher.config import WatcherConfig
    from watcher.monitor import FileMonitor

    # A.cli: must exist + must be a dir — watcher would fail later otherwise.
    watch_dir = resolve_cli_path(watch_dir, must_exist=True, must_be_dir=True)
    console.print(f"[bold]Watching[/bold] {watch_dir}  (Ctrl+C to stop)")

    config = WatcherConfig(
        watch_directories=[watch_dir],
        debounce_seconds=poll_interval,
    )
    monitor = FileMonitor(config=config)
    monitor.start()

    try:
        while True:
            events = monitor.get_events_blocking(timeout=2.0)
            for event in events:
                event_type = getattr(event, "event_type", "unknown")
                event_path = getattr(event, "path", getattr(event, "src_path", "?"))
                console.print(f"  [{event_type}] {event_path}", markup=False)
    except KeyboardInterrupt:
        console.print("\n[dim]Stopped watching.[/dim]")
    finally:
        monitor.stop()


@daemon_app.command()
def process(
    input_dir: Path = typer.Argument(..., help="Directory containing files to process."),
    output_dir: Path = typer.Argument(..., help="Destination directory for organized files."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview changes without moving files."),
) -> None:
    """One-shot: organize files and display a summary."""
    from core.organizer import FileOrganizer

    # A.cli: same input/output contract as `fo organize`.
    input_dir = resolve_cli_path(input_dir, must_exist=True, must_be_dir=True)
    output_dir = resolve_cli_path(output_dir, must_exist=False, must_be_dir=True)
    validate_pair(input_dir, output_dir)
    console.print(f"[bold]Processing[/bold] {input_dir} -> {output_dir}")
    if dry_run:
        console.print("[yellow]Dry-run mode — no files will be moved.[/yellow]")

    try:
        organizer = FileOrganizer(dry_run=dry_run)
        result = organizer.organize(input_path=input_dir, output_path=output_dir)

        table = Table(title="Processing Summary")
        table.add_column("Metric", style="bold")
        table.add_column("Count", justify="right")

        table.add_row("Total files", str(result.total_files))
        table.add_row("Processed", str(result.processed_files))
        table.add_row("Skipped", str(result.skipped_files))
        table.add_row("Failed", str(result.failed_files))
        table.add_row("Folders", str(len(result.organized_structure)))

        console.print(table)

        if result.errors:
            console.print("\n[bold red]Errors:[/bold red]")
            for fname, msg in result.errors[:10]:
                console.print(f"  {fname}: {msg}")
            if len(result.errors) > 10:
                console.print(f"  [dim]... and {len(result.errors) - 10} more[/dim]")

    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from exc
