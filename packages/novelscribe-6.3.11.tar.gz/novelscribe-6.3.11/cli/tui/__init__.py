"""NovelScribe Interactive TUI — dual-pane chat and document review."""

from cli.tui.app import ScribeApp

__all__ = ["ScribeApp"]
