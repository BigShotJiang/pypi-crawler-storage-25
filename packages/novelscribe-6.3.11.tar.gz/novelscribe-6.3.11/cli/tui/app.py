"""NovelScribe TUI App — dual-pane chat and document review."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.driver import Driver
from textual.message import Message
from textual.reactive import reactive
from textual.widgets import Button, Footer, Header, Input, Static

logger = logging.getLogger("scribe")


class MessageRole(Enum):
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


@dataclass
class ChatMessage:
    role: MessageRole
    content: str


class MarkdownViewer(Static):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._content = ""

    def update_content(self, content: str) -> None:
        self._content = content
        self.update(self._format_markdown(content))

    def _format_markdown(self, content: str) -> str:
        lines = []
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("# "):
                lines.append(f"[bold cyan]{stripped[2:]}[/bold cyan]")
            elif stripped.startswith("## "):
                lines.append(f"[bold]{stripped[3:]}[/bold]")
            elif stripped.startswith("### "):
                lines.append(f"[italic]{stripped[4:]}[/italic]")
            elif not stripped:
                lines.append("")
            else:
                lines.append(stripped)
        return "\n".join(lines)


class MessageLog(Vertical):
    def append_message(self, role: MessageRole, content: str) -> None:
        prefix = "You" if role == MessageRole.USER else "Scribe"
        msg_static = Static(f"[b]{prefix}:[/b] {content}", markup=True, classes="message")
        self.mount(msg_static)


class ChatPane(Vertical):
    DEFAULT_CSS = """
    ChatPane { border: solid $primary; padding: 1; width: 40%; }
    """

    def compose(self) -> ComposeResult:
        yield MessageLog(id="message-log")
        yield Input(placeholder="Ask about your novel...", id="chat-input")

    def on_input_submitted(self, event: Input.Submitted) -> None:
        event.input.clear()


class ContextPane(Vertical):
    DEFAULT_CSS = """
    ContextPane { border: solid $accent; padding: 1; width: 60%; }
    """

    active_tab = reactive("outline")

    def __init__(self) -> None:
        super().__init__()
        self._outline_content = ""
        self._meta_content = ""
        self._chapter_content = ""

    def set_outline(self, content: str) -> None:
        self._outline_content = content
        if self.active_tab == "outline":
            self._refresh_viewer()

    def set_meta(self, content: str) -> None:
        self._meta_content = content
        if self.active_tab == "meta":
            self._refresh_viewer()

    def set_chapter(self, content: str) -> None:
        self._chapter_content = content
        if self.active_tab == "chapter":
            self._refresh_viewer()

    def _refresh_viewer(self) -> None:
        content_map = {
            "outline": self._outline_content,
            "meta": self._meta_content,
            "chapter": self._chapter_content,
        }
        content = content_map.get(self.active_tab, "Select a context to view.")
        try:
            viewer = self.query_one("#context-viewer", MarkdownViewer)
            viewer.update_content(content)
        except NoMatches:
            pass

    def switch_tab(self, tab_id: str) -> None:
        self.active_tab = tab_id
        for btn in self.query(".tab-button"):
            btn.remove_class("active")
            if getattr(btn, "tab_id", None) == tab_id:
                btn.add_class("active")
        self._refresh_viewer()

    def compose(self) -> ComposeResult:
        tabs = [("outline", "Outline"), ("meta", "META.yaml"), ("chapter", "Chapter")]
        with Horizontal():
            for tab_id, label in tabs:
                btn = Button(label, id=f"tab-{tab_id}", classes="tab-button")
                btn.tab_id = tab_id
                yield btn
        yield MarkdownViewer("Select a context to view.", id="context-viewer")


class ScribeApp(App):
    CSS = "Screen { background: $surface; }"

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", show=True),
        Binding("ctrl+t", "toggle_focus", "Toggle", show=True),
        Binding("f1", "show_help", "Help", show=True),
    ]

    def __init__(
        self,
        project_name: str = "",
        provider: str = "",
        model: str = "",
        lang: str = "",
        *,
        driver_class: type[Driver] | None = None,
    ) -> None:
        super().__init__(driver_class=driver_class)
        self.project_name = project_name
        self.provider = provider
        self.model = model
        self.lang = lang
        self._chat_engine = None
        self._messages: list[ChatMessage] = []
        self._loading = False

    def on_mount(self) -> None:
        self.title = f"NovelScribe TUI — {self.project_name or 'No Project'}"
        self._init_chat_engine()
        self._load_project_context()

    def _init_chat_engine(self) -> None:
        try:
            from core.chat import ChatEngine

            self._chat_engine = ChatEngine(
                provider=self.provider or "",
                model=self.model or "",
                lang=self.lang or None,
                project_dir=str(Path.cwd()),
            )
            if not self._chat_engine.is_configured():
                self._add_system_message(
                    "⚠️ No LLM provider configured. Run `scribe setup interactive` first."
                )
        except Exception as e:
            logger.error(f"Failed to init ChatEngine: {e}")
            self._add_system_message(f"⚠️ Failed to init chat engine: {e}")

    def _load_project_context(self) -> None:
        if not self.project_name:
            self._load_project_list()
            return

        try:
            from services.project_service import ProjectService

            svc = ProjectService()
            meta = svc.read_meta(self.project_name)
            meta_text = "\n".join(f"{k}: {v}" for k, v in meta.items())
            self.query_one("ContextPane", ContextPane).set_meta(meta_text)

            outline_path = Path(".novels") / self.project_name / "outline.md"
            if outline_path.exists():
                self.query_one("ContextPane", ContextPane).set_outline(
                    outline_path.read_text(encoding="utf-8")
                )

            chapters = svc.list_chapters(self.project_name)
            if chapters:
                first = chapters[0]
                chapter = svc.get_chapter(self.project_name, first.number)
                self.query_one("ContextPane", ContextPane).set_chapter(chapter.content)
        except Exception as e:
            logger.error(f"Failed to load project context: {e}")

    def _load_project_list(self) -> None:
        try:
            from services.project_service import ProjectService

            svc = ProjectService()
            projects = svc.list_projects()
            if projects:
                names = "\n".join(f"  • {p.name}" for p in projects)
                self._add_system_message(
                    f"Projects found:\n{names}\n\nRun `scribe tui <project>` to open one."
                )
            else:
                self._add_system_message(
                    "No projects found. Create one with:\n  scribe new my-novel"
                )
        except Exception as e:
            logger.error(f"Failed to list projects: {e}")
            self._add_system_message("⚠️ Could not load project list.")

    def _add_system_message(self, content: str) -> None:
        msg = ChatMessage(role=MessageRole.SYSTEM, content=content)
        self._messages.append(msg)
        try:
            self.query_one("MessageLog", MessageLog).append_message(msg.role, msg.content)
        except NoMatches:
            pass

    def compose(self) -> ComposeResult:
        yield Header()
        with Horizontal(id="main-area"):
            yield ChatPane()
            yield ContextPane()
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id.startswith("tab-"):
            tab_id = btn_id[4:]
            try:
                self.query_one("ContextPane", ContextPane).switch_tab(tab_id)
            except NoMatches:
                pass

    def on_input_submitted(self, event: Input.Submitted) -> None:
        question = event.value.strip()
        if not question:
            return

        msg = ChatMessage(role=MessageRole.USER, content=question)
        self._messages.append(msg)
        try:
            self.query_one("MessageLog", MessageLog).append_message(msg.role, msg.content)
        except NoMatches:
            pass

        if not self._chat_engine:
            self._add_system_message("⚠️ Chat engine not initialized.")
            return

        self._loading = True
        self._ask_async(question)

    def _ask_async(self, question: str) -> None:
        from threading import Thread

        def worker() -> None:
            try:
                answer = self._chat_engine.ask(question)
                self.post_message(self.ChatResponse(answer))
            except Exception as e:
                logger.error(f"Chat error: {e}")
                self.post_message(self.ChatResponse(f"❌ Error: {e}"))

        Thread(target=worker, daemon=True).start()

    class ChatResponse(Message):
        def __init__(self, content: str) -> None:
            super().__init__()
            self.content = content

    def on_chat_response(self, event: ChatResponse) -> None:
        self._loading = False
        msg = ChatMessage(role=MessageRole.ASSISTANT, content=event.content)
        self._messages.append(msg)
        try:
            self.query_one("MessageLog", MessageLog).append_message(msg.role, msg.content)
        except NoMatches:
            pass

    def action_quit(self) -> None:
        self.exit()

    def action_toggle_focus(self) -> None:
        try:
            chat = self.query_one("ChatPane")
            input_widget = chat.query_one(Input)
            self.set_focus(input_widget)
        except NoMatches:
            pass

    def action_show_help(self) -> None:
        self._add_system_message(
            "NovelScribe TUI Help:\n"
            "  Type a question and press Enter to chat.\n"
            "  Use the tabs on the right to switch context views.\n"
            "  Ctrl+T: focus chat input\n"
            "  Ctrl+Q: quit"
        )
