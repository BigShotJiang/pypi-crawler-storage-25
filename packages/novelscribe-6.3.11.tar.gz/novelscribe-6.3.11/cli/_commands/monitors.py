"""Monitor CLI group — background monitor agent commands."""

import click


@click.group()
@click.pass_context
def monitors(ctx: click.Context) -> None:
    """Background monitor agent commands."""
    pass


@monitors.command("status")
@click.argument("project_name")
@click.pass_context
def monitor_status(ctx: click.Context, project_name: str) -> None:
    """Show last run status for all monitors."""
    from services.monitor_service import MonitorService

    service = MonitorService()
    status_map = service.get_monitor_status(project_name)

    if not status_map:
        click.echo("No monitor reports found. Run `scribe monitors run` first.")
        return

    for name, status in status_map.items():
        score = f"{status.health_score:.1f}" if status.health_score is not None else "N/A"
        issues = str(status.issues_found) if status.issues_found is not None else "N/A"
        last = status.last_run or "never"
        click.echo(f"  {name}: score={score} issues={issues} status={status.status} last={last}")


@monitors.command("run")
@click.argument("project_name")
@click.option("--monitor", "monitor_name", default=None, help="Run a specific monitor")
@click.pass_context
def monitor_run(ctx: click.Context, project_name: str, monitor_name: str) -> None:
    """Run all monitors (or a specific one) now."""
    from services.monitor_service import MonitorService

    service = MonitorService()

    try:
        results = service.run_monitors(project_name, monitor_name=monitor_name)
    except (FileNotFoundError, ValueError) as exc:
        click.echo(f"Error: {exc}", err=True)
        ctx.exit(1)
        return

    for name, result in results.items():
        if result.error:
            click.echo(f"  {name}: ERROR - {result.error}")
        else:
            ms = result.execution_time_ms
            click.echo(
                f"  {name}: score={result.health_score:.1f}"
                f" issues={result.issues_found} time={ms}ms"
            )


@monitors.command("report")
@click.argument("project_name")
@click.argument("monitor_name", required=False)
@click.pass_context
def monitor_report(ctx: click.Context, project_name: str, monitor_name: str) -> None:
    """Display latest monitor report(s)."""
    from services.monitor_service import MonitorService

    service = MonitorService()

    if monitor_name:
        try:
            content = service.get_report(project_name, monitor_name)
            click.echo(content)
        except FileNotFoundError as exc:
            click.echo(f"Error: {exc}", err=True)
            ctx.exit(1)
        return

    status_map = service.get_monitor_status(project_name)
    for name in status_map:
        try:
            content = service.get_report(project_name, name)
            click.echo(f"\n{'=' * 60}")
            click.echo(f"  Monitor: {name}")
            click.echo(f"{'=' * 60}")
            click.echo(content)
        except FileNotFoundError:
            click.echo(f"\n  {name}: No report available")


@monitors.command("schedule")
@click.argument("project_name")
@click.option("--interval", default=30, type=int, help="Interval in minutes")
@click.option("--stop", "stop_scheduler", is_flag=True, help="Stop the scheduler")
@click.pass_context
def monitor_schedule(
    ctx: click.Context,
    project_name: str,
    interval: int,
    stop_scheduler: bool,
) -> None:
    """Start or stop the periodic monitor scheduler."""
    from services.monitor_service import MonitorService

    service = MonitorService()

    if stop_scheduler:
        service.stop_scheduler(project_name)
        click.echo(f"Scheduler stopped for {project_name}")
        return

    service.start_scheduler(project_name, interval_minutes=interval)
    click.echo(f"Scheduler started for {project_name} (interval={interval}min)")
