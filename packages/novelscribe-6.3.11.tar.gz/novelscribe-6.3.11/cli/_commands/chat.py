"""Chat command — AI-powered Q&A about NovelScribe and novel writing."""

import logging
import sys

import click

SETUP_HELP = """\
⚠️  No LLM provider configured. To set one up:

  Interactive wizard:
    scribe setup interactive

  Or configure a provider directly:
    scribe setup apikey openai sk-...
    scribe setup apikey anthropic sk-ant-...
    scribe setup apikey google YOUR_KEY
    scribe setup apikey minimax YOUR_KEY
    scribe setup apikey zhipu YOUR_KEY
    scribe setup apikey moonshot YOUR_KEY

  Local providers (no key needed):
    scribe setup apikey ollama
    scribe setup apikey lm-studio
"""


@click.command()
@click.argument("question", nargs=-1)
@click.option("--provider", default="", help="LLM provider to use (auto-detected if omitted)")
@click.option("--model", default="", help="LLM model to use (provider default if omitted)")
@click.pass_context
def chat(ctx: click.Context, question: tuple[str, ...], provider: str, model: str) -> None:
    """Ask questions about NovelScribe and novel writing.

    \b
    One-shot mode (no quotes needed):
      scribe chat how to create a new character?
      scribe chat what agents are available?

    \b
    Interactive mode (multi-turn conversation):
      scribe chat

    \b
    With specific provider:
      scribe chat --provider anthropic how to build a plot?
    """
    logger = logging.getLogger("scribe")

    from cli._commands.helpers import _resolve_lang_code
    from core.chat import ChatEngine

    lang = _resolve_lang_code(ctx.obj.get("lang") if ctx.obj else None)
    engine = ChatEngine(provider=provider, model=model, lang=lang)

    if not engine.is_configured():
        click.echo(SETUP_HELP)
        sys.exit(1)

    question_text = " ".join(question).strip()
    if question_text:
        try:
            answer = engine.ask(question_text)
            click.echo(f"\n🤖 {answer}\n")
        except Exception as e:
            logger.error(f"Chat failed: {e}")
            click.echo(f"\n❌ Error: {e}")
            click.echo("💡 Check your API key with: scribe setup verify\n")
            sys.exit(1)
    else:
        try:
            engine.run_interactive()
        except KeyboardInterrupt:
            click.echo("\n👋 Bye!")
