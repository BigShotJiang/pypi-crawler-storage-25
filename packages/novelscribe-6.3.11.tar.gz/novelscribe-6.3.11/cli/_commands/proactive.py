#!/usr/bin/env python
"""
Proactive Suggestions CLI Commands

Provides command-line interface for managing proactive suggestions
configuration and accessing suggestion features.
"""

import sys
from pathlib import Path

import click
import yaml
from rich.console import Console
from rich.table import Table

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.learning_tracker import LearningTracker
from core.suggestions.models import SuggestionCategory, SuggestionSource

console = Console()


def get_project_root() -> Path:
    """Get the current project root directory."""
    return Path.cwd()


def get_meta_path() -> Path:
    """Get the path to META.yaml."""
    return get_project_root() / "META.yaml"


def load_meta() -> dict:
    """Load META.yaml configuration."""
    meta_path = get_meta_path()
    if not meta_path.exists():
        return {}

    with open(meta_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def save_meta(meta: dict) -> None:
    """Save META.yaml configuration."""
    meta_path = get_meta_path()
    with open(meta_path, "w", encoding="utf-8") as f:
        yaml.safe_dump(meta, f, default_flow_style=False, allow_unicode=True)


def ensure_proactive_config(meta: dict) -> dict:
    """Ensure proactive config exists in META.yaml."""
    if "proactive" not in meta:
        meta["proactive"] = {
            "enabled": True,
            "continuous": False,
            "suggestions": {"genre": True, "technical": True, "workflow": True, "quality": True},
        }
    return meta


@click.group(name="proactive")
def proactive():
    """Proactive suggestion management commands."""
    pass


@proactive.command()
def enable():
    """
    Enable proactive suggestions for the current project.

    Enables AI to proactively suggest options at decision points,
    phase transitions, and when issues are detected.
    """
    meta = load_meta()
    meta = ensure_proactive_config(meta)

    if meta["proactive"].get("enabled", False):
        click.echo(click.style("Proactive suggestions are already enabled.", fg="yellow"))
        return

    meta["proactive"]["enabled"] = True
    save_meta(meta)

    click.echo(click.style("✓", fg="green") + " Proactive suggestions enabled for this project")
    click.echo("\nConfiguration:")
    click.echo(f"  • Enabled: {meta['proactive']['enabled']}")
    click.echo(f"  • Continuous mode: {meta['proactive'].get('continuous', False)}")

    suggestions = meta["proactive"].get("suggestions", {})
    if suggestions:
        click.echo("\n  Active categories:")
        for category, enabled in suggestions.items():
            status = "✓" if enabled else "✗"
            click.echo(f"    {status} {category}")


@proactive.command()
def disable():
    """
    Disable proactive suggestions for the current project.

    The AI will not make proactive suggestions unless explicitly requested.
    """
    meta = load_meta()

    if "proactive" not in meta or not meta["proactive"].get("enabled", False):
        click.echo(click.style("Proactive suggestions are already disabled.", fg="yellow"))
        return

    if "proactive" in meta:
        meta["proactive"]["enabled"] = False

    save_meta(meta)

    click.echo(click.style("✓", fg="green") + " Proactive suggestions disabled for this project")
    click.echo("\nNote: You can still request suggestions manually using 'user_request' trigger")


@proactive.command()
def status():
    """
    Show current proactive suggestion configuration.

    Displays the current settings for proactive suggestions including
    enabled status, continuous mode, and per-category settings.
    """
    meta = load_meta()

    if "proactive" not in meta:
        click.echo(click.style("Proactive suggestions not configured.", fg="yellow"))
        click.echo("\nUse 'scribe proactive enable' to enable proactive suggestions.")
        return

    proactive_config = meta["proactive"]

    click.echo("\nProactive Suggestions Configuration\n")

    status_text = (
        click.style("Enabled", fg="green")
        if proactive_config.get("enabled", False)
        else click.style("Disabled", fg="red")
    )
    click.echo(f"Status: {status_text}")

    continuous = proactive_config.get("continuous", False)
    continuous_text = click.style("On", fg="green") if continuous else click.style("Off", fg="dim")
    click.echo(f"Continuous mode: {continuous_text}")

    suggestions = proactive_config.get("suggestions", {})
    if suggestions:
        click.echo("\nCategory Settings:")
        table = Table(show_header=True, header_style="bold")
        table.add_column("Category", style="cyan")
        table.add_column("Status", style="green")

        for category, enabled in suggestions.items():
            status = "✓ Enabled" if enabled else "✗ Disabled"
            table.add_row(category, status)

        console.print(table)
    else:
        click.echo("\nNo category-specific settings configured.")


@proactive.command()
@click.argument("key")
@click.argument("value", type=bool)
def config(key, value):
    """
    Set a proactive suggestion configuration option.

    Examples:
        scribe proactive config continuous true
        scribe proactive config suggestions.genre false
        scribe proactive config suggestions.workflow true
    """
    meta = load_meta()
    meta = ensure_proactive_config(meta)

    keys = key.split(".")

    if len(keys) == 1:
        if keys[0] not in ["continuous", "enabled"]:
            click.echo(f"Error: Unknown top-level key: {keys[0]}", err=True)
            click.echo("Valid keys: 'continuous', 'enabled'")
            sys.exit(1)

        meta["proactive"][keys[0]] = value

    elif len(keys) == 2 and keys[0] == "suggestions":
        if keys[1] not in ["genre", "technical", "workflow", "quality"]:
            click.echo(f"Error: Unknown category: {keys[1]}", err=True)
            click.echo("Valid categories: 'genre', 'technical', 'workflow', 'quality'")
            sys.exit(1)

        if "suggestions" not in meta["proactive"]:
            meta["proactive"]["suggestions"] = {}

        meta["proactive"]["suggestions"][keys[1]] = value

    else:
        click.echo(f"Error: Invalid configuration key: {key}", err=True)
        click.echo("Valid formats:")
        click.echo("  • continuous")
        click.echo("  • suggestions.genre")
        click.echo("  • suggestions.technical")
        click.echo("  • suggestions.workflow")
        click.echo("  • suggestions.quality")
        sys.exit(1)

    save_meta(meta)

    value_str = click.style("true", fg="green") if value else click.style("false", fg="red")
    click.echo(click.style("✓", fg="green") + f" Set {key} to {value_str}")


@proactive.command("list")
@click.option("--category", "-c", help="Filter by category")
@click.option("--source", "-s", help="Filter by source (static/dynamic/learned)")
@click.option("--language", "-l", default="", help="Language code")
@click.option("--limit", "-n", default=20, help="Maximum number to show")
def list_suggestions(category, source, language, limit):
    """
    List all available suggestions.

    Displays suggestions from the knowledge base with optional filtering
    by category and source.
    """
    from cli._commands.helpers import _resolve_lang_code

    language = _resolve_lang_code(language)
    project_root = get_project_root()
    data_dir = project_root / "core" / "data" / "suggestions"

    kb = SuggestionKnowledgeBase(data_dir=data_dir)

    try:
        if category:
            category_enum = SuggestionCategory(category.lower())
            suggestions = kb.load_suggestions(category_enum, language, include_learned=True)
        else:
            suggestions = []
            for cat in SuggestionCategory:
                suggestions.extend(kb.load_suggestions(cat, language, include_learned=True))
    except ValueError:
        click.echo(f"Error: Invalid category: {category}", err=True)
        click.echo("Valid categories: genre, technical, workflow, quality")
        sys.exit(1)

    if source:
        try:
            source_enum = SuggestionSource(source.lower())
            suggestions = [s for s in suggestions if s.source == source_enum]
        except ValueError:
            click.echo(f"Error: Invalid source: {source}", err=True)
            click.echo("Valid sources: static, dynamic, learned")
            sys.exit(1)

    suggestions = suggestions[:limit]

    if not suggestions:
        click.echo("No suggestions found.")
        return

    click.echo(f"\nFound {len(suggestions)} suggestion(s):\n")

    for idx, suggestion in enumerate(suggestions, 1):
        source_marker = {"static": "", "dynamic": " (Dynamic)", "learned": " [Learned]"}.get(
            suggestion.source.value, ""
        )

        acceptance = (
            f" [{suggestion.acceptance_rate:.0%}]" if suggestion.acceptance_count > 0 else ""
        )

        click.echo(f"{idx}. {suggestion.name}{source_marker}{acceptance}")
        click.echo(f"   {suggestion.description}")

        if suggestion.best_for:
            click.echo(f"   Best for: {', '.join(suggestion.best_for[:2])}")

        click.echo()


@proactive.command("history")
@click.option("--days", "-d", default=7, help="Number of days to analyze")
@click.option("--project", "-p", help="Filter by project")
def show_history(days, project):
    """
    Show suggestion acceptance history and analytics.

    Displays statistics about suggestion usage including acceptance rates,
    most frequently shown suggestions, and category breakdowns.
    """
    project_root = get_project_root()
    data_dir = project_root / "core" / "data" / "suggestions"
    events_dir = data_dir / "events"

    kb = SuggestionKnowledgeBase(data_dir=data_dir)
    tracker = LearningTracker(kb=kb, events_dir=events_dir)

    analytics = tracker.get_usage_analytics(days=days)

    click.echo(f"\nSuggestion Analytics (Last {days} days)\n")

    click.echo(f"Total events: {analytics['total_events']}")
    click.echo(f"Dynamic acceptance rate: {analytics['dynamic_acceptance_rate']:.1%}")

    category_breakdown = analytics.get("category_breakdown", {})
    if category_breakdown:
        click.echo("\nCategory Breakdown:")
        for cat, count in sorted(category_breakdown.items(), key=lambda x: x[1], reverse=True):
            click.echo(f"  {cat}: {count}")

    trigger_breakdown = analytics.get("trigger_breakdown", {})
    if trigger_breakdown:
        click.echo("\nTrigger Types:")
        for trigger, count in sorted(trigger_breakdown.items(), key=lambda x: x[1], reverse=True):
            click.echo(f"  {trigger}: {count}")


@proactive.command("review")
@click.option("--language", "-l", default="", help="Language code")
def review_pending(language):
    """
    Review suggestions pending promotion.

    Shows suggestions that have high acceptance rates but haven't
    yet been promoted to the global knowledge base.
    """
    from cli._commands.helpers import _resolve_lang_code

    language = _resolve_lang_code(language)
    project_root = get_project_root()
    data_dir = project_root / "core" / "data" / "suggestions"
    events_dir = data_dir / "events"

    kb = SuggestionKnowledgeBase(data_dir=data_dir)
    tracker = LearningTracker(kb=kb, events_dir=events_dir)

    pending = tracker.get_pending_promotions()

    if not pending:
        click.echo(click.style("✓", fg="green") + " No suggestions pending promotion")
        return

    threshold = tracker.promotion_threshold

    click.echo("\nSuggestions Pending Promotion")
    click.echo(f"(Promotion threshold: {threshold} acceptances)\n")

    for suggestion_id, count in pending.items():
        suggestion = kb.get_suggestion(suggestion_id)

        if suggestion:
            click.echo(f"{suggestion.name} ({suggestion_id})")
            click.echo(f"  Acceptances: {count}/{threshold}")
            click.echo(f"  {suggestion.description}")

            if suggestion.acceptance_count > 0:
                click.echo(f"  Acceptance rate: {suggestion.acceptance_rate:.1%}")

            click.echo()
        else:
            click.echo(f"{suggestion_id}: {count} acceptances")


@proactive.command("promote")
@click.argument("suggestion_id")
@click.option("--confirm", "-y", is_flag=True, help="Skip confirmation prompt")
def promote_suggestion(suggestion_id, confirm):
    """
    Promote a suggestion to the global knowledge base.

    Promotes a locally-learned suggestion to the global knowledge base,
    making it available to all projects.
    """
    if not confirm:
        if not click.confirm(f"Promote suggestion '{suggestion_id}' to global knowledge base?"):
            sys.exit(0)

    project_root = get_project_root()
    data_dir = project_root / "core" / "data" / "suggestions"
    events_dir = data_dir / "events"

    kb = SuggestionKnowledgeBase(data_dir=data_dir)
    tracker = LearningTracker(kb=kb, events_dir=events_dir)

    success = tracker.promote_to_learned(suggestion_id)

    if success:
        click.echo(
            click.style("✓", fg="green")
            + f" Suggestion '{suggestion_id}' promoted to global knowledge base"
        )
    else:
        click.echo(f"Error: Could not promote suggestion '{suggestion_id}'", err=True)
        click.echo(
            "\nThe suggestion may not meet the promotion threshold or may already be promoted."
        )
        sys.exit(1)


# Export for integration with main CLI
app = proactive


if __name__ == "__main__":
    app()
