"""CLI dashboard command — quality dashboard for a project."""

import json
import sys
from typing import Optional

import click

from services.quality_service import QualityService


@click.command("dashboard")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Filter snapshots to a specific chapter")
@click.option(
    "--json", "as_json", is_flag=True, help="Output raw JSON instead of terminal rendering"
)
@click.pass_context
def dashboard(ctx: click.Context, project_name: str, chapter: Optional[int], as_json: bool) -> None:
    """Display quality dashboard for a project."""
    svc = QualityService()
    try:
        if not svc.get_project_path(project_name).exists():
            click.echo(f"Error: Project '{project_name}' not found")
            sys.exit(1)

        if as_json:
            _render_json(svc, project_name, chapter)
        else:
            _render_terminal(svc, project_name, chapter)
    except Exception as e:
        click.echo(f"Error: {e}")
        sys.exit(1)


def _render_json(svc: QualityService, project_name: str, chapter: Optional[int]) -> None:
    data = svc.get_dashboard(project_name)
    if chapter is not None:
        data["snapshots"] = svc.get_snapshots(project_name, chapter=chapter)
    click.echo(json.dumps(data, indent=2, default=str))


def _render_terminal(svc: QualityService, project_name: str, chapter: Optional[int]) -> None:
    data = svc.get_dashboard(project_name)
    overall = data.get("overall_score", 0.0)
    gate = data.get("gate_level") or "—"
    trend = data.get("overall_trend", "─")
    total_ch = data.get("total_chapters", 0)
    ch_with_data = data.get("chapters_with_data", 0)
    total_words = data.get("total_words", 0)
    dim_avgs = data.get("dimension_averages", {})
    chapter_scores = data.get("chapter_scores", [])
    last_updated = data.get("last_updated", "")

    click.echo()
    click.echo("  ╔══════════════════════════════════════════╗")
    click.echo(f"  ║   Quality Dashboard: {project_name:<20s} ║")
    click.echo("  ╚══════════════════════════════════════════╝")
    click.echo()

    score_bar = _score_bar(overall)
    click.echo(f"  Overall Score   {score_bar}  {overall:.1f}")
    click.echo(f"  Gate Level      {gate}")
    click.echo(f"  Trend           {trend}")
    click.echo(f"  Chapters        {ch_with_data} / {total_ch}")
    click.echo(f"  Total Words     {total_words:,}")
    if last_updated:
        click.echo(f"  Last Updated    {last_updated}")
    click.echo()

    if dim_avgs:
        click.echo("  ── Dimension Averages ──────────────────────")
        labels = {
            "readability": "Readability",
            "dialogue": "Dialogue    ",
            "pacing": "Pacing      ",
            "style": "Style       ",
            "consistency": "Consistency ",
            "continuity": "Continuity  ",
        }
        for key, val in dim_avgs.items():
            label = labels.get(key, key)
            bar = _dim_bar(val)
            click.echo(f"  {label}  {bar}  {val:.1f}")
        click.echo()

    if chapter_scores:
        if chapter is not None:
            chapter_scores = [cs for cs in chapter_scores if cs["chapter"] == chapter]

        click.echo("  ── Chapter Scores ─────────────────────────")
        click.echo(f"  {'Ch':>4s}  {'Score':>5s}  {'Gate':<8s}  {'Words':>7s}  {'Trend':>5s}")
        click.echo(f"  {'─' * 4:s}  {'─' * 5:s}  {'─' * 8:s}  {'─' * 7:s}  {'─' * 5:s}")
        for cs in chapter_scores:
            ch_num = cs["chapter"]
            score = cs["quality_score"]
            g = cs.get("gate_level") or "—"
            words = cs.get("word_count", 0)
            t = cs.get("trend", "─")
            click.echo(f"  {ch_num:>4d}  {score:>5.1f}  {g:<8s}  {words:>7,d}  {t:>5s}")
        click.echo()

    snapshots = svc.get_snapshots(project_name, chapter=chapter)
    if snapshots:
        click.echo(f"  📊 {len(snapshots)} snapshot(s) on file")
        click.echo()

    if not chapter_scores and not dim_avgs:
        click.echo("  No quality data available. Run `scribe qa analyze` first.")
        click.echo()


def _score_bar(score: float, width: int = 20) -> str:
    filled = int(round(score * width))
    return "█" * filled + "░" * (width - filled)


def _dim_bar(value: float, width: int = 15) -> str:
    filled = int(round(value * width))
    return "▓" * filled + "░" * (width - filled)
