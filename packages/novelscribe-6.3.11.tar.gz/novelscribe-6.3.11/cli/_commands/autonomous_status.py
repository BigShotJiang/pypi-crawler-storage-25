"""Autonomous status and progress CLI subcommands."""

from __future__ import annotations

import logging
from pathlib import Path

import click

from cli._commands._autonomous_options import with_checkpoint_dir_options
from cli._helpers.error_handling import handle_cli_exception
from core.autonomous.progress_tracker import ProgressTracker
from core.checkpoints.manager import CheckpointManager
from core.orchestration.autonomous import AutonomousConfig, AutonomousExecutor

DEFAULT_PROJECT_DIR = ".novels"
DEFAULT_CHECKPOINT_DIR = ".checkpoints"


@click.command("progress")
@click.argument("project_name")
@click.pass_context
@with_checkpoint_dir_options(DEFAULT_CHECKPOINT_DIR)
def show_progress(ctx: click.Context, project_name: str, checkpoint_dir: str) -> None:
    """Show project execution progress."""
    logger = logging.getLogger("scribe")

    try:
        progress_tracker = ProgressTracker(
            project_name=project_name,
            storage_path=Path(checkpoint_dir),
        )
        state = progress_tracker.get_state()

        if not state:
            logger.info(f"No progress state found for '{project_name}'")
            logger.info("Start autonomous mode to track progress")
            return

        logger.info(f"Progress for: {project_name}")
        logger.info("=" * 60)
        logger.info(f"Current Phase: {state.current_phase}")
        logger.info(f"Status: {state.status.value}")
        logger.info(f"Progress: {state.progress_percentage:.1f}%")
        logger.info(f"Steps: {state.completed_steps}/{state.total_steps}")
        logger.info("")

        if state.completed_phases:
            logger.info("Completed Phases:")
            for phase in state.completed_phases:
                logger.info(f"  \u2705 {phase}")

        logger.info("")
        logger.info(f"Started: {state.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Last Update: {state.last_update.strftime('%Y-%m-%d %H:%M:%S')}")

        if state.error:
            logger.info(f"Error: {state.error}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to show progress: {e}", e, debug=False)


@click.command("status")
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.option("--checkpoint", is_flag=True, help="Show checkpoint status")
@click.option("--hybrid", "show_hybrid", is_flag=True, help="Show hybrid mode status")
@click.pass_context
def show_status(
    ctx: click.Context, project_name: str, project_dir: str, checkpoint: bool, show_hybrid: bool
) -> None:
    """Show project status including checkpoint and hybrid mode state."""
    debug = (ctx.obj or {}).get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        progress_tracker = ProgressTracker(
            project_name=project_name,
            storage_path=Path(project_dir) / project_name,
        )
        state = progress_tracker.get_state()

        if not state:
            click.echo(f"No progress state found for '{project_name}'")
            return

        click.echo(f"\nProject: {project_name}")
        click.echo(f"Phase: {state.current_phase}")
        click.echo(f"Status: {state.status.value}")
        click.echo(f"Progress: {state.progress_percentage:.1f}%")
        click.echo(f"Steps: {state.completed_steps}/{state.total_steps}")

        if state.completed_phases:
            click.echo(f"\nCompleted: {', '.join(state.completed_phases)}")

        if checkpoint or show_hybrid:
            checkpoint_manager = CheckpointManager(
                project_name=project_name,
                storage_path=Path(project_dir) / project_name,
            )
            latest_checkpoint = checkpoint_manager.load_checkpoint()
            pre_writing_decision = None
            if latest_checkpoint is not None:
                maybe_decision = latest_checkpoint.execution_context.get("pre_writing_decision")
                if isinstance(maybe_decision, dict):
                    pre_writing_decision = maybe_decision

            config = AutonomousConfig(
                project_name=project_name,
                human_in_loop=True,
            )
            executor = AutonomousExecutor(config=config, storage_path=Path(project_dir))

            waiting = executor.checkpoint_waiting()
            if waiting:
                click.echo("\n\u26a0\ufe0f  CHECKPOINT WAITING")
                click.echo(f"   {waiting['checkpoint_id']}: {waiting['title']}")
                click.echo(f"   Confidence: {waiting['confidence']:.0%}")
                click.echo(f"   Status: {waiting['status']}")
                click.echo("   [Review Now] [Extend Timer] [Auto-Approve] [Delegate]")
            else:
                click.echo("\n\u2713 No checkpoints waiting")

            if pre_writing_decision:
                click.echo("\nPre-Writing Decision Summary")
                click.echo(f"   Decision: {pre_writing_decision.get('decision_type', 'unknown')}")
                click.echo(f"   Items: {pre_writing_decision.get('items', 'n/a')}")

        click.echo()

    except Exception as e:
        handle_cli_exception(logger, f"Failed to show status: {e}", e, debug=debug)


@click.command("extend-timer")
@click.argument("project_name")
@click.argument("checkpoint_id")
@click.option("--hours", type=float, required=True, help="Hours to extend timer")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def extend_timer(
    ctx: click.Context, project_name: str, checkpoint_id: str, hours: float, project_dir: str
) -> None:
    """Extend checkpoint timeout timer."""
    debug = (ctx.obj or {}).get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        from core.resilience import TimeoutHandler

        handler = TimeoutHandler()
        seconds = int(hours * 3600)
        result = handler.extend_timer(checkpoint_id, seconds)
        if result:
            click.echo(f"\u2713 Timer extended for {checkpoint_id} by {hours}h")
        else:
            click.echo(
                "\u2717 Could not extend timer (max extensions reached or unknown checkpoint)"
            )
    except Exception as e:
        handle_cli_exception(logger, f"Failed to extend timer: {e}", e, debug=debug)
