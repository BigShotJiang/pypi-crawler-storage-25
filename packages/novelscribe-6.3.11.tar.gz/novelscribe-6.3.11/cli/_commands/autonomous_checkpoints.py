"""Autonomous checkpoint CLI subcommands."""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from cli._commands._autonomous_options import with_checkpoint_dir_options
from cli._helpers.error_handling import handle_cli_exception
from core.checkpoints.manager import CheckpointManager

DEFAULT_CHECKPOINT_DIR = ".checkpoints"


def _make_cm(checkpoint_dir: str, project_name: str = "default") -> CheckpointManager:
    return CheckpointManager(project_name=project_name, storage_path=Path(checkpoint_dir))


@click.command("checkpoints")
@with_checkpoint_dir_options(DEFAULT_CHECKPOINT_DIR)
@click.option("--project-name", help="Filter by project name")
@click.option("--limit", type=int, default=10, help="Maximum number of checkpoints to show")
def list_checkpoints(checkpoint_dir: str, project_name: Optional[str], limit: int) -> None:
    """List available checkpoints."""
    logger = logging.getLogger("scribe")

    try:
        effective_project_name = project_name or "default"
        checkpoint_manager = _make_cm(checkpoint_dir, effective_project_name)
        checkpoints = checkpoint_manager.list_checkpoints()

        if project_name:
            checkpoints = [cp for cp in checkpoints if cp.project_name == project_name]

        if not checkpoints:
            logger.info("No checkpoints found")
            return

        logger.info(f"Found {len(checkpoints)} checkpoint(s):")
        logger.info("")

        for i, checkpoint in enumerate(checkpoints[:limit], 1):
            progress_pct = checkpoint.progress_state.progress_percentage
            status = checkpoint.progress_state.status.value

            logger.info(f"{i}. {checkpoint.checkpoint_id}")
            logger.info(f"   Project: {checkpoint.project_name}")
            logger.info(f"   Phase: {checkpoint.progress_state.current_phase}")
            logger.info(f"   Progress: {progress_pct:.1f}%")
            logger.info(f"   Status: {status}")
            logger.info(f"   Completed: {len(checkpoint.completed_workflows)} workflows")
            logger.info(f"   Timestamp: {checkpoint.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
            logger.info("")

        if len(checkpoints) > limit:
            logger.info(f"... and {len(checkpoints) - limit} more (use --limit to show more)")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to list checkpoints: {e}", e, debug=False)


@click.command("show-checkpoint")
@click.argument("checkpoint_id")
@with_checkpoint_dir_options(DEFAULT_CHECKPOINT_DIR)
def show_checkpoint(checkpoint_id: str, checkpoint_dir: str) -> None:
    """Show detailed checkpoint information."""
    logger = logging.getLogger("scribe")

    try:
        checkpoint_manager = _make_cm(checkpoint_dir)
        checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)

        if not checkpoint:
            logger.error(f"Checkpoint '{checkpoint_id}' not found")
            sys.exit(1)

        progress = checkpoint.progress_state

        logger.info(f"Checkpoint: {checkpoint.checkpoint_id}")
        logger.info("=" * 60)
        logger.info(f"Project: {checkpoint.project_name}")
        logger.info(f"Created: {checkpoint.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("")
        logger.info("Progress:")
        logger.info(f"  Current Phase: {progress.current_phase}")
        logger.info(f"  Completed Phases: {len(progress.completed_phases)}")
        if progress.completed_phases:
            for phase in progress.completed_phases:
                logger.info(f"    - {phase}")
        logger.info(f"  Steps: {progress.completed_steps}/{progress.total_steps}")
        logger.info(f"  Progress: {progress.progress_percentage:.1f}%")
        logger.info(f"  Status: {progress.status.value}")
        logger.info("")

        if progress.current_step:
            logger.info(f"Current Step: {progress.current_step}")

        if checkpoint.current_workflow:
            logger.info(f"Current Workflow: {checkpoint.current_workflow}")

        if checkpoint.execution_context:
            logger.info("Execution Context:")
            for key, value in checkpoint.execution_context.items():
                logger.info(f"  {key}: {value}")

        if progress.error:
            logger.info(f"Error: {progress.error}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to show checkpoint: {e}", e, debug=False)


@click.command("delete-checkpoint")
@click.argument("checkpoint_id")
@with_checkpoint_dir_options(DEFAULT_CHECKPOINT_DIR)
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
def delete_checkpoint(checkpoint_id: str, checkpoint_dir: str, force: bool) -> None:
    """Delete a checkpoint."""
    logger = logging.getLogger("scribe")

    try:
        checkpoint_manager = _make_cm(checkpoint_dir)

        if not force:
            checkpoint = checkpoint_manager.load_checkpoint(checkpoint_id)
            if not checkpoint:
                logger.error(f"Checkpoint '{checkpoint_id}' not found")
                sys.exit(1)

            logger.info(f"Checkpoint: {checkpoint.checkpoint_id}")
            logger.info(f"Project: {checkpoint.project_name}")
            logger.info(f"Phase: {checkpoint.progress_state.current_phase}")
            logger.info("")

            confirm = click.confirm("Are you sure you want to delete this checkpoint?")
            if not confirm:
                logger.info("Deletion cancelled")
                return

        deleted = checkpoint_manager.delete_checkpoint(checkpoint_id)

        if deleted:
            logger.info(f"\u2705 Checkpoint '{checkpoint_id}' deleted successfully")
        else:
            logger.error(f"Failed to delete checkpoint '{checkpoint_id}'")
            sys.exit(1)

    except Exception as e:
        handle_cli_exception(logger, f"Failed to delete checkpoint: {e}", e, debug=False)
