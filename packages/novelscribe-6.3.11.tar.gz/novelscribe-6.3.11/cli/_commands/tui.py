"""TUI command — interactive dual-pane chat and document review."""

import logging
import sys

import click

logger = logging.getLogger("scribe")


@click.command("tui")
@click.argument("project_name", required=False, default="")
@click.option("--provider", default="", help="LLM provider to use")
@click.option("--model", default="", help="LLM model to use")
@click.pass_context
def tui(ctx: click.Context, project_name: str, provider: str, model: str) -> None:
    """Interactive TUI for chatting and reviewing your novel.

    \b
    Open a project in the TUI:
      scribe tui my-novel

    \b
    Browse available projects (no project name):
      scribe tui

    \b
    With explicit provider/model:
      scribe tui my-novel --provider anthropic --model claude-sonnet-4-20250514
    """
    lang = ctx.obj.get("lang", "") if ctx.obj else ""

    try:
        from cli.tui.app import ScribeApp

        app = ScribeApp(
            project_name=project_name,
            provider=provider,
            model=model,
            lang=lang,
        )
        app.run()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logger.error(f"TUI error: {e}")
        click.echo(f"\n❌ Failed to start TUI: {e}")
        sys.exit(1)
