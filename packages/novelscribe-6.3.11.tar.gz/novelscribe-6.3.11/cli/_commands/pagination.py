"""
CLI commands for Phase 4.1: Chapter Pagination

Commands for:
- Paginating chapters
- Managing context windows
- Inspecting cache statistics
- Multi-chapter operations
"""

import logging
import sys
from pathlib import Path  # noqa: F401 - kept for test patch targets
from typing import Optional

import click

from cli._commands._storage_paths import project_path as resolve_project_path
from core.chapters import (
    ChapterPaginator,
    MultiChapterManager,
    MultiChapterManagerConfig,
    PageSplitStrategy,
    PaginationConfig,
)
from core.context.cache import CachedChapterManager, ContextCache, ContextCacheConfig
from core.llm.estimator import TokenEstimator

logger = logging.getLogger("scribe")


@click.group()
@click.pass_context
def paginate(ctx: click.Context) -> None:
    """Chapter pagination and context management commands."""
    pass


@paginate.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Specific chapter to paginate")
@click.option(
    "--strategy",
    default="token",
    type=click.Choice(["token", "scene", "paragraph", "semantic"]),
    help="Pagination strategy",
)
@click.option("--target-tokens", default=2500, type=int, help="Target tokens per page")
@click.option("--overlap-tokens", default=200, type=int, help="Overlap tokens between pages")
@click.pass_context
def chapter(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    strategy: str,
    target_tokens: int,
    overlap_tokens: int,
) -> None:
    """Paginate chapter(s) into manageable pages."""
    try:
        logger.info(f"Paginating chapter(s) for: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        strategy_map = {
            "token": PageSplitStrategy.TOKEN_BASED,
            "scene": PageSplitStrategy.SCENE_BASED,
            "paragraph": PageSplitStrategy.PARAGRAPH_BASED,
            "semantic": PageSplitStrategy.SEMANTIC,
        }

        config = PaginationConfig(
            target_page_tokens=target_tokens,
            overlap_tokens=overlap_tokens,
            strategy=strategy_map[strategy],
        )
        paginator = ChapterPaginator(config)

        if chapter:
            chapters_dir = project_path / "chapters"
            chapter_file = chapters_dir / f"chapter_{chapter}.md"

            if not chapter_file.exists():
                logger.error(f"Chapter {chapter} not found")
                sys.exit(1)

            text = chapter_file.read_text()
            pages = paginator.paginate_chapter(text, chapter)

            logger.info(f"✅ Paginated chapter {chapter} into {len(pages)} pages")

            for page in pages:
                logger.info(
                    f"   Page {page.page_number}: "
                    f"{page.word_count} words, {page.token_count} tokens"
                )
        else:
            chapters_dir = project_path / "chapters"
            if not chapters_dir.exists():
                logger.error("No chapters directory found")
                sys.exit(1)

            total_pages = 0
            for chapter_file in sorted(chapters_dir.glob("chapter_*.md")):
                chapter_num = int(chapter_file.stem.split("_")[1])
                text = chapter_file.read_text()
                pages = paginator.paginate_chapter(text, chapter_num)
                total_pages += len(pages)
                logger.info(f"   Chapter {chapter_num}: {len(pages)} pages")

            logger.info(f"✅ Paginated all chapters into {total_pages} total pages")

    except Exception as e:
        logger.error(f"Failed to paginate chapters: {e}")
        sys.exit(1)


@paginate.command()
@click.argument("project_name")
@click.option("--max-chapters", default=10, type=int, help="Maximum loaded chapters")
@click.option("--prefetch-count", default=3, type=int, help="Number of chapters to prefetch")
@click.pass_context
def index(ctx: click.Context, project_name: str, max_chapters: int, prefetch_count: int) -> None:
    """Build multi-chapter index for efficient access."""
    try:
        logger.info(f"Building chapter index for: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        config = MultiChapterManagerConfig(max_loaded_chapters=max_chapters)
        manager = MultiChapterManager(project_path, config)

        count = manager.build_index(project_name)

        logger.info(f"✅ Indexed {count} chapters")

        stats = manager.get_project_statistics()
        logger.info(f"   Total chapters: {stats['total_chapters']}")
        logger.info(f"   Total words: {stats['total_words']:,}")
        logger.info(f"   Total tokens: {stats['total_tokens']:,}")
        logger.info(f"   Total pages: {stats['total_pages']}")

    except Exception as e:
        logger.error(f"Failed to build index: {e}")
        sys.exit(1)


@paginate.command()
@click.argument("project_name")
@click.option("--start", type=int, required=True, help="Start chapter")
@click.option("--end", type=int, required=True, help="End chapter")
@click.option("--max-pages", default=5, type=int, help="Maximum pages per chapter")
@click.pass_context
def get_range(ctx: click.Context, project_name: str, start: int, end: int, max_pages: int) -> None:
    """Get page range across multiple chapters."""
    try:
        logger.info(f"Loading chapters {start}-{end} from: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        manager = MultiChapterManager(project_path)
        manager.build_index(project_name)

        pages = manager.get_chapter_range(start, end, max_pages_per_chapter=max_pages)

        logger.info(f"✅ Loaded {len(pages)} pages")

        for page in pages[:10]:
            logger.info(
                f"   Chapter {page.chapter_number}, "
                f"Page {page.page_number}: "
                f"{page.word_count} words"
            )

        if len(pages) > 10:
            logger.info(f"   ... and {len(pages) - 10} more pages")

    except Exception as e:
        logger.error(f"Failed to get chapter range: {e}")
        sys.exit(1)


@paginate.command()
@click.argument("project_name")
@click.option("--query", required=True, help="Search query")
@click.option("--limit", default=10, type=int, help="Maximum results")
@click.pass_context
def search(ctx: click.Context, project_name: str, query: str, limit: int) -> None:
    """Search across all indexed chapters."""
    try:
        logger.info(f"Searching chapters for: {query}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        manager = MultiChapterManager(project_path)
        manager.build_index(project_name)

        results = manager.search_chapters(query, limit=limit)

        logger.info(f"✅ Found {len(results)} results")

        for i, result in enumerate(results[:10], 1):
            logger.info(f"   {i}. {result}")

        if len(results) > 10:
            logger.info(f"   ... and {len(results) - 10} more results")

    except Exception as e:
        logger.error(f"Failed to search chapters: {e}")
        sys.exit(1)


@paginate.command()
@click.argument("text")
@click.pass_context
def estimate(ctx: click.Context, text: str) -> None:
    """Estimate tokens for text."""
    try:
        estimator = TokenEstimator()
        token_count = estimator.estimate_tokens(text)

        logger.info(f"Text token estimate: {token_count:,}")
        logger.info(f"Character count: {len(text):,}")
        logger.info(f"Word count: {len(text.split()):,}")

    except Exception as e:
        logger.error(f"Failed to estimate tokens: {e}")
        sys.exit(1)


@click.group()
@click.pass_context
def cache(ctx: click.Context) -> None:
    """Context cache management commands."""
    pass


@cache.command()
@click.argument("project_name")
@click.option("--max-size-mb", default=100.0, type=float, help="Maximum cache size in MB")
@click.option("--max-entries", default=100, type=int, help="Maximum cache entries")
@click.pass_context
def warm(ctx: click.Context, project_name: str, max_size_mb: float, max_entries: int) -> None:
    """Warm cache by loading all chapters."""
    try:
        logger.info(f"Warming cache for: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        cache_config = ContextCacheConfig(max_size_mb=max_size_mb, max_entries=max_entries)
        cache = ContextCache(cache_config)
        cached_manager = CachedChapterManager(cache)
        multi_manager = MultiChapterManager(project_path)
        multi_manager.build_index(project_name)

        def loader(chapter_num):
            return multi_manager.load_chapter(chapter_num)

        total_chapters = len(multi_manager.chapter_references)
        for i in range(1, total_chapters + 1):
            cached_manager.get_chapter(project_name, i, loader)

        logger.info(f"✅ Warmed cache with {total_chapters} chapters")

        stats = cache.get_statistics()
        logger.info(f"   Cache hits: {stats['hits']}")
        logger.info(f"   Cache size: {stats['current_size_mb']:.2f} MB")
        logger.info(f"   Utilization: {stats['utilization_percent']:.1f}%")

    except Exception as e:
        logger.error(f"Failed to warm cache: {e}")
        sys.exit(1)


@cache.command()
@click.argument("project_name")
@click.pass_context
def stats(ctx: click.Context, project_name: str) -> None:
    """Display cache statistics."""
    try:
        logger.info(f"Cache statistics for: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        cache = ContextCache()
        cached_manager = CachedChapterManager(cache)
        multi_manager = MultiChapterManager(project_path)
        multi_manager.build_index(project_name)

        def loader(chapter_num):
            return multi_manager.load_chapter(chapter_num)

        cached_manager.get_chapter(project_name, 1, loader)

        stats = cache.get_statistics()

        logger.info(f"   Total requests: {stats['total_requests']}")
        logger.info(f"   Cache hits: {stats['hits']}")
        logger.info(f"   Cache misses: {stats['misses']}")
        logger.info(f"   Hit rate: {stats['hit_rate']}")
        logger.info(f"   Evictions: {stats['evictions']}")
        logger.info(f"   Current entries: {stats['current_entries']}")
        logger.info(f"   Current size: {stats['current_size_mb']:.2f} MB")
        logger.info(f"   Utilization: {stats['utilization_percent']:.1f}%")

    except Exception as e:
        logger.error(f"Failed to get cache stats: {e}")
        sys.exit(1)


@cache.command()
@click.argument("project_name")
@click.pass_context
def clear(ctx: click.Context, project_name: str) -> None:
    """Clear all cached data for project."""
    try:
        logger.info(f"Clearing cache for: {project_name}")

        cache = ContextCache()
        cached_manager = CachedChapterManager(cache)
        cached_manager.invalidate_project(project_name)

        logger.info(f"✅ Cache cleared for '{project_name}'")

    except Exception as e:
        logger.error(f"Failed to clear cache: {e}")
        sys.exit(1)


# Preferred hierarchy: `paginate cache ...`
# Compatibility is preserved by keeping top-level `cache` in cli.py.
paginate.add_command(cache, name="cache")
