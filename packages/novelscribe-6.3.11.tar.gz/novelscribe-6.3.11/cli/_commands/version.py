"""CLI commands for version management and updates."""

import logging

import click

from core.version import VersionManager


@click.group()
def version() -> None:
    """Version and update management commands."""
    pass


@version.command()
@click.option("--check", is_flag=True, help="Check for updates")
@click.pass_context
def info(ctx: click.Context, check: bool) -> None:
    """Show version information."""
    logger = logging.getLogger("scribe")
    manager = VersionManager()

    if check:
        update_info = manager.check_for_updates(verbose=True, force=True)
        if update_info:
            if update_info.get("update_available"):
                logger.info(f"Update available: {update_info['current']} → {update_info['latest']}")
            else:
                logger.info(f"✓ You're running the latest version: {update_info['current']}")
    else:
        logger.info(f"NovelScribe v{manager.current_version}")
        logger.info(f"Package: {manager.package_name}")


@version.command()
@click.pass_context
def check_cmd(ctx: click.Context) -> None:
    """Check for available updates."""
    logger = logging.getLogger("scribe")
    manager = VersionManager()

    update_info = manager.check_for_updates(verbose=False, force=True)

    if update_info:
        if update_info.get("update_available"):
            logger.info(
                f"🔔 Update available: v{update_info['current']} → v{update_info['latest']}"
            )
            logger.info(f"Run: {update_info['upgrade_command']}")
        else:
            logger.info(f"✓ You're running the latest version: {update_info['current']}")
    else:
        logger.warning("Could not check for updates. Please check your internet connection.")


@version.command()
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt")
@click.pass_context
def update(ctx: click.Context, yes: bool) -> None:
    """Self-update novelscribe to the latest version from PyPI."""
    logger = logging.getLogger("scribe")
    manager = VersionManager()

    update_info = manager.check_for_updates(force=True)
    if not update_info:
        logger.error("Could not check for updates. Check your internet connection.")
        return

    if not update_info.get("update_available"):
        logger.info(f"Already on latest version: v{update_info['current']}")
        return

    latest = update_info["latest"]

    if not yes:
        click.confirm(
            f"Update novelscribe v{update_info['current']} → v{latest}?",
            default=True,
            abort=True,
        )

    upgrade_cmd = update_info["upgrade_command"]
    success = manager.perform_self_update()
    if not success:
        logger.error("Update failed. Try manually:")
        logger.info(f"  {upgrade_cmd}")
