"""
CLI commands for Phase 4.2: Summary System

Commands for:
- Generating chapter and group summaries
- Updating global summaries
- Retrieving context for chapter generation
- Managing summary storage
"""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from cli._commands._storage_paths import project_path as resolve_project_path
from core.llm.client import LLMClient, LLMConfig
from core.summary import SummaryManager, SummaryManagerConfig, SummaryStore

logger = logging.getLogger("scribe")


@click.group()
@click.pass_context
def summary(ctx: click.Context) -> None:
    """Summary system commands for managing novel summaries."""
    pass


@summary.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Specific chapter to summarize")
@click.option("--all", "all_chapters", is_flag=True, help="Generate all missing summaries")
@click.option("--provider", default="", help="LLM provider to use")
@click.option("--skip-existing", is_flag=True, help="Skip chapters that already have summaries")
@click.pass_context
def generate(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    all_chapters: bool,
    provider: str,
    skip_existing: bool,
) -> None:
    """Generate chapter summaries."""
    from cli._commands.helpers import _resolve_provider_from_setup

    provider = _resolve_provider_from_setup(provider)
    try:
        logger.info(f"Generating summaries for: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        llm_config = LLMConfig(provider=provider)
        llm_client = LLMClient(llm_config)

        summary_manager = SummaryManager(project_path, llm_client, SummaryManagerConfig())

        if chapter:
            chapters_dir = project_path / "chapters"
            chapter_file = chapters_dir / f"chapter_{chapter}.md"

            if not chapter_file.exists():
                logger.error(f"Chapter {chapter} not found")
                sys.exit(1)

            content = chapter_file.read_text()

            previous_summary = None
            if chapter > 1:
                prev = summary_manager.get_chapter_summary(chapter - 1)
                if prev:
                    previous_summary = prev.summary

            summary = summary_manager.generate_chapter_summary(chapter, content, previous_summary)

            logger.info(f"✅ Generated summary for Chapter {chapter}")
            logger.info(f"   Length: {len(summary.summary.split())} words")
            logger.info(f"   Key events: {len(summary.key_events)}")
            logger.info(f"   Characters: {len(summary.characters)}")

        elif all_chapters:
            chapters_dir = project_path / "chapters"
            if not chapters_dir.exists():
                logger.error("No chapters directory found")
                sys.exit(1)

            chapter_files = {}
            for chapter_file in sorted(chapters_dir.glob("chapter_*.md")):
                chapter_num = int(chapter_file.stem.split("_")[1])
                chapter_files[chapter_num] = chapter_file.read_text()

            summaries = summary_manager.batch_generate_summaries(
                chapter_files, skip_existing=skip_existing
            )

            logger.info(f"✅ Generated {len(summaries)} chapter summaries")

            for summary in summaries:
                logger.info(
                    f"   Chapter {summary.chapter_number}: {len(summary.summary.split())} words"
                )

        else:
            logger.error("Specify --chapter or --all")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Failed to generate summaries: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.option("--start", type=int, required=True, help="Start chapter")
@click.option("--end", type=int, required=True, help="End chapter")
@click.option("--provider", default="", help="LLM provider to use")
@click.pass_context
def group(ctx: click.Context, project_name: str, start: int, end: int, provider: str) -> None:
    """Generate group summary for a range of chapters."""
    from cli._commands.helpers import _resolve_provider_from_setup

    provider = _resolve_provider_from_setup(provider)
    try:
        logger.info(f"Generating group summary for chapters {start}-{end}: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        llm_config = LLMConfig(provider=provider)
        llm_client = LLMClient(llm_config)

        summary_manager = SummaryManager(project_path, llm_client, SummaryManagerConfig())

        group_summary = summary_manager.generate_group_summary(start, end)

        logger.info(f"✅ Generated group summary for chapters {start}-{end}")
        logger.info(f"   Length: {len(group_summary.summary.split())} words")
        logger.info(f"   Total chapters: {end - start + 1}")

    except Exception as e:
        logger.error(f"Failed to generate group summary: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.option("--provider", default="", help="LLM provider to use")
@click.pass_context
def update_global(ctx: click.Context, project_name: str, provider: str) -> None:
    """Update global summary with latest chapters."""
    from cli._commands.helpers import _resolve_provider_from_setup

    provider = _resolve_provider_from_setup(provider)
    try:
        logger.info(f"Updating global summary for: {project_name}")

        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        llm_config = LLMConfig(provider=provider)
        llm_client = LLMClient(llm_config)

        summary_manager = SummaryManager(project_path, llm_client, SummaryManagerConfig())

        store = SummaryStore(project_path)
        existing_summaries = store.list_chapter_summaries()

        if not existing_summaries:
            logger.error("No chapter summaries found. Generate chapter summaries first.")
            sys.exit(1)

        global_summary = summary_manager.update_global_summary(existing_summaries)

        logger.info("✅ Updated global summary")
        logger.info(f"   Chapters covered: {global_summary.total_chapters_covered}")
        logger.info(f"   Length: {len(global_summary.summary.split())} words")
        logger.info(f"   Last updated: {global_summary.last_updated}")

    except Exception as e:
        logger.error(f"Failed to update global summary: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Show specific chapter summary")
@click.option("--global", "show_global", is_flag=True, help="Show global summary")
@click.pass_context
def show(ctx: click.Context, project_name: str, chapter: Optional[int], show_global: bool) -> None:
    """Display summaries."""
    try:
        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        store = SummaryStore(project_path)

        if show_global:
            global_summary = store.load_global_summary()

            if not global_summary:
                logger.error("No global summary found")
                sys.exit(1)

            logger.info(f"## Global Summary for {project_name}")
            logger.info("")
            logger.info(global_summary.summary)
            logger.info("")
            logger.info(f"**Chapters Covered**: {global_summary.total_chapters_covered}")
            logger.info(f"**Last Updated**: {global_summary.last_updated}")

        elif chapter:
            chapter_summary = store.load_chapter_summary(chapter)

            if not chapter_summary:
                logger.error(f"No summary found for Chapter {chapter}")
                sys.exit(1)

            logger.info(f"## Chapter {chapter} Summary")
            logger.info("")
            logger.info(chapter_summary.summary)
            logger.info("")

            if chapter_summary.key_events:
                logger.info("**Key Events**:")
                for event in chapter_summary.key_events:
                    logger.info(f"  - {event}")
                logger.info("")

            if chapter_summary.characters:
                logger.info("**Characters**:")
                for char, role in chapter_summary.characters.items():
                    logger.info(f"  - {char}: {role}")
                logger.info("")

        else:
            logger.error("Specify --chapter or --global")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Failed to show summary: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True, help="Chapter number")
@click.option(
    "--context-chapters", default=3, type=int, help="Number of previous chapters to include"
)
@click.pass_context
def context(ctx: click.Context, project_name: str, chapter: int, context_chapters: int) -> None:
    """Get summarized context for chapter generation."""
    try:
        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        from cli._commands.helpers import _resolve_provider_from_setup

        llm_config = LLMConfig(provider=_resolve_provider_from_setup(""))
        llm_client = LLMClient(llm_config)

        summary_manager = SummaryManager(project_path, llm_client, SummaryManagerConfig())

        context = summary_manager.get_context_for_chapter(chapter, context_chapters)

        logger.info(f"## Context for Chapter {chapter}")
        logger.info("")
        logger.info(context)

    except Exception as e:
        logger.error(f"Failed to get context: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.pass_context
def list_cmd(ctx: click.Context, project_name: str) -> None:
    """List all summaries."""
    try:
        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        store = SummaryStore(project_path)

        chapter_summaries = store.list_chapter_summaries()
        group_summaries = store.list_group_summaries()
        has_global = store.load_global_summary() is not None

        logger.info(f"## Summaries for {project_name}")
        logger.info("")

        if has_global:
            logger.info("✅ Global Summary")

        if group_summaries:
            logger.info(f"✅ Group Summaries: {len(group_summaries)}")
            for group_id in group_summaries:
                logger.info(f"   - {group_id}")

        if chapter_summaries:
            logger.info(f"✅ Chapter Summaries: {len(chapter_summaries)}")

            missing = []
            if chapter_summaries:
                max_chapter = max(chapter_summaries)
                for i in range(1, max_chapter + 1):
                    if i not in chapter_summaries:
                        missing.append(i)

            if missing:
                logger.info(f"   Missing: {len(missing)} chapters")
                if len(missing) <= 10:
                    logger.info(f"   Chapters: {', '.join(map(str, missing))}")
        else:
            logger.info("❌ No chapter summaries found")

    except Exception as e:
        logger.error(f"Failed to list summaries: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.pass_context
def stats(ctx: click.Context, project_name: str) -> None:
    """Display summary statistics."""
    try:
        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        store = SummaryStore(project_path)
        statistics = store.get_summary_statistics()

        logger.info(f"## Summary Statistics for {project_name}")
        logger.info("")
        logger.info(f"Chapter Summaries: {statistics['chapter_summaries']}")
        logger.info(f"Group Summaries: {statistics['group_summaries']}")
        logger.info(f"Global Summary: {'✅' if statistics['has_global_summary'] else '❌'}")
        logger.info(f"Total Words Summarized: {statistics['total_words_summarized']:,}")
        logger.info(f"Storage Format: {statistics['storage_format']}")

    except Exception as e:
        logger.error(f"Failed to get statistics: {e}")
        sys.exit(1)


@summary.command()
@click.argument("project_name")
@click.option("--output", "-o", type=Path, help="Output file path")
@click.option(
    "--format",
    "format_type",
    default="markdown",
    type=click.Choice(["markdown", "json", "yaml"]),
    help="Export format",
)
@click.pass_context
def export(ctx: click.Context, project_name: str, output: Optional[Path], format_type: str) -> None:
    """Export all summaries to a single file."""
    try:
        project_path = resolve_project_path(project_name)

        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        if not output:
            output = Path(f"{project_name}_summaries.{format_type}")

        store = SummaryStore(project_path)
        store.export_summaries(output, format_type)

        logger.info(f"✅ Exported summaries to {output}")

    except Exception as e:
        logger.error(f"Failed to export summaries: {e}")
        sys.exit(1)


# Rename list to list_cmd to avoid conflict with built-in
summary.add_command(list_cmd, name="list")
