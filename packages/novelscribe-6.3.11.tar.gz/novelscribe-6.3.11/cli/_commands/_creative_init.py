from __future__ import annotations

import logging
from datetime import datetime
from importlib import import_module
from pathlib import Path

import click
import yaml

from cli._commands.helpers import (
    PROVIDER_DEFAULT_MODELS,
    _default_model_for_provider,
    _resolve_new_project_llm,
    _resolve_project_llm,
)
from cli._helpers.error_handling import handle_cli_exception
from core.agents.agent import AgentContext
from core.agents.executor import AgentExecutor
from core.agents.registry import AgentRegistry
from core.git import create_git_manager
from core.i18n import LanguageCode
from core.llm.client import LLMConfig, MultiLLMClient
from core.storage import FileStorage, StorageConfig
from services.project_service import ProjectService


def _display_creative_result(creative: dict) -> None:
    meta = creative.get("meta", {})
    recs = creative.get("recommendations", {})

    click.echo("\n📋 创意分析结果：")
    click.echo("━" * 40)

    field_labels = {
        "name": "标题",
        "genre": "流派",
        "subgenres": "子流派",
        "pov": "视角",
        "tone": "基调",
        "themes": "主题",
        "word_count_target": "目标字数",
        "chapter_count_target": "预计章节",
        "target_audience": "目标读者",
    }
    for field, label in field_labels.items():
        val = meta.get(field)
        if val:
            if isinstance(val, list):
                val = ", ".join(str(v) for v in val)
            click.echo(f"  {label}: {val}")

    if recs:
        click.echo("\n📂 推荐模板：")
        click.echo("━" * 40)
        if recs.get("plot"):
            click.echo(f"  情节结构: {recs['plot']}")
        if recs.get("character_archetypes"):
            archs = ", ".join(recs["character_archetypes"])
            click.echo(f"  角色原型: {archs}")
        if recs.get("scene_types"):
            scenes = ", ".join(recs["scene_types"])
            click.echo(f"  场景蓝图: {scenes}")
        tropes = recs.get("narrative_tropes", [])
        if tropes:
            click.echo("  叙事套路:")
            for t in tropes[:3]:
                click.echo(f"    - {t['title']} (score: {t['score']})")
        resolved = recs.get("resolved_template_ids", {})
        if resolved:
            click.echo("  已生成模板:")
            for name, tid in resolved.items():
                click.echo(f"    - {name} → {tid}")


def _run_outline_agent(
    project_path: Path,
    project_name: str,
    meta: dict,
    provider: str,
    model: str,
    lang: str,
) -> dict[str, object]:
    """Generate outline artifacts directly via outline_agent."""
    try:
        language = LanguageCode(lang)
    except ValueError:
        language = LanguageCode.EN

    storage = FileStorage(StorageConfig(base_path=str(project_path.parent)))
    llm_client = MultiLLMClient(LLMConfig(provider=provider, model=model))
    agents_dir = Path(import_module("agents").__file__).resolve().parent
    agent_registry = AgentRegistry(agents_dir=agents_dir, language=language)
    agent = agent_registry.get_agent("outline_agent")
    if agent is None:
        raise ValueError(f"Agent not found: outline_agent ({language})")

    executor = AgentExecutor(llm_client=llm_client, storage=storage, work_dir=project_path.parent)
    context = AgentContext(project_name=project_name)

    def _read_optional(path: Path) -> str:
        if not path.exists():
            return ""
        return path.read_text(encoding="utf-8").strip()

    input_data = {
        "META.yaml": yaml.safe_dump(meta, allow_unicode=True, sort_keys=False).strip(),
        "CHARACTERS.md": _read_optional(project_path / "CHARACTERS.md"),
        "LORE.md": _read_optional(project_path / "LORE.md"),
        "genre_guidelines": _read_optional(project_path / "reports" / "genre_guidelines.md"),
    }

    system_prompt = executor.construct_system_message(agent)
    user_prompt = executor._construct_prompt(agent, context, input_data)
    response = llm_client.generate(system_prompt=system_prompt, user_prompt=user_prompt)
    outputs = executor.extract_output_variables(response.content, agent)

    reports_dir = project_path / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    outline_content = str(outputs.get("OUTLINE.md") or response.content).strip()
    outline_path = project_path / "OUTLINE.md"
    outline_path.write_text(outline_content + "\n", encoding="utf-8")

    saved_files = [str(outline_path)]
    beat_sheet_content = str(outputs.get("beat_sheet") or "").strip()
    if beat_sheet_content and beat_sheet_content != outline_content:
        beat_sheet_path = reports_dir / "beat_sheet.md"
        beat_sheet_path.write_text(beat_sheet_content + "\n", encoding="utf-8")
        saved_files.append(str(beat_sheet_path))

    agent_report_path = reports_dir / "outline_agent_output.md"
    agent_report_path.write_text(response.content.rstrip() + "\n", encoding="utf-8")
    saved_files.append(str(agent_report_path))

    return {"steps_executed": 1, "saved_files": saved_files}


def _resolve_lang(ctx: click.Context) -> str:
    """Resolve language from CLI flag, persisted settings, or default."""
    from cli._commands.helpers import _resolve_lang_code

    return _resolve_lang_code(ctx.obj.get("lang") if ctx.obj else None)


@click.command()
@click.argument("project_name")
@click.option("--provider", default="", help="LLM provider (inherits setup default if omitted)")
@click.option("--model", default="", help="LLM model (inherits setup default if omitted)")
@click.option(
    "--file",
    "-f",
    "input_file",
    default=None,
    type=click.Path(exists=True),
    help="File with initial novel concept/design (.md, .txt)",
)
@click.option("--desc", "-d", "description", default=None, help="Brief concept description")
@click.option("--skip-discuss", is_flag=True, help="Skip creative discussion (lightweight mode)")
@click.pass_context
def new(
    ctx: click.Context,
    project_name: str,
    provider: str,
    model: str,
    input_file: str | None,
    description: str | None,
    skip_discuss: bool,
) -> None:
    """Initialize a new novel project."""
    debug = ctx.obj.get("debug", False)
    lang = _resolve_lang(ctx)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Creating new novel project: {project_name}")
        resolved_provider, resolved_model = _resolve_new_project_llm(provider, model)

        svc = ProjectService()
        info = svc.create_project(
            name=project_name,
            provider=resolved_provider,
            model=resolved_model,
        )

        if not skip_discuss:
            file_content = ""
            if input_file:
                p = Path(input_file)
                file_content = p.read_text(encoding="utf-8")

            user_input = description or ""
            if not user_input and not file_content:
                try:
                    user_input = click.prompt(
                        "请描述您的小说概念（或按 Enter 跳过创意初始化）",
                        default="",
                        show_default=False,
                    ).strip()
                except (click.Abort, EOFError):
                    user_input = ""

            if user_input or file_content:
                creative = svc.init_creative(
                    project_name=project_name,
                    provider=resolved_provider,
                    model=resolved_model,
                    user_input=user_input,
                    file_content=file_content,
                    lang=lang,
                )
                if creative and creative.get("meta"):
                    _display_creative_result(creative)
                    confirm = (
                        click.prompt(
                            "\n确认以上设置？[Y/n/编辑]",
                            default="Y",
                        )
                        .strip()
                        .lower()
                    )

                    if confirm in ("y", "yes", ""):
                        meta_draft = creative["meta"]
                        existing = svc.read_meta(project_name)
                        merged = {**existing, **meta_draft}
                        recs = creative.get("recommendations", {})
                        if recs:
                            merged["templates"] = recs
                        merged["updated"] = datetime.now().isoformat()
                        svc.write_meta(project_name, merged)
                        logger.info("✅ 创意信息已写入项目配置")
                    elif confirm in ("edit", "e", "编辑"):
                        meta_draft = creative["meta"]
                        existing = svc.read_meta(project_name)
                        merged = {**existing, **meta_draft}
                        recs = creative.get("recommendations", {})
                        if recs:
                            merged["templates"] = recs
                        merged["updated"] = datetime.now().isoformat()
                        for field_name in ("genre", "pov", "tone", "word_count_target"):
                            current = merged.get(field_name, "")
                            new_val = click.prompt(
                                f"  {field_name}",
                                default=str(current),
                                show_default=True,
                            ).strip()
                            if new_val:
                                merged[field_name] = new_val
                        svc.write_meta(project_name, merged)
                        logger.info("✅ 创意信息（编辑后）已写入项目配置")

        project_path = Path(info.location)
        git_manager = create_git_manager(project_path, auto_commit=True)
        git_manager.auto_commit_step(
            agent="cli",
            description=f"Initialize project {project_name}",
        )

        logger.info(f"✅ Project '{project_name}' created successfully")
        logger.info(f"   Location: {project_path}")
        if skip_discuss:
            logger.info(f"   Next: Run 'scribe outline {project_name}' to generate outline")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to create project: {e}", e, debug=debug)


@click.command()
@click.argument("project_name")
@click.pass_context
def outline(ctx: click.Context, project_name: str) -> None:
    """Generate novel outline for project."""
    debug = ctx.obj.get("debug", False)
    lang = _resolve_lang(ctx)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Generating outline for: {project_name}")

        svc = ProjectService()
        project_path = svc.get_project_path(project_name)
        meta = svc.read_meta(project_name)

        provider, model = _resolve_project_llm(
            str(meta.get("provider") or "").strip(),
            str(meta.get("model") or "").strip(),
        )

        if not provider:
            provider = click.prompt(
                "No provider found in project/setup. Enter provider",
                type=click.Choice(sorted(PROVIDER_DEFAULT_MODELS.keys()), case_sensitive=False),
            )
            provider = str(provider).strip()

        if not model:
            model = click.prompt(
                f"No model found for provider '{provider}'. Enter model",
                default=_default_model_for_provider(provider),
                show_default=True,
            ).strip()

        svc.write_meta(project_name, {**meta, "provider": provider, "model": model})

        missing = svc.validate_meta_completeness(meta)
        if missing:
            logger.warning(f"⚠️  META 缺少以下创意字段: {', '.join(missing)}")
            logger.info("正在启动创意补齐...")
            svc.ensure_meta_complete(
                project_name=project_name,
                missing_fields=missing,
                provider=provider,
                model=model,
                lang=lang,
            )
            logger.info("✅ 创意字段已补齐")

        latest_meta = svc.read_meta(project_name)
        result = _run_outline_agent(
            project_path=project_path,
            project_name=project_name,
            meta=latest_meta,
            provider=provider,
            model=model,
            lang=lang,
        )

        git_manager = create_git_manager(project_path, auto_commit=True)
        git_manager.auto_commit_step(
            agent="outline_agent",
            description=f"Generate outline for {project_name}",
        )

        logger.info(f"✅ Outline generated successfully for '{project_name}'")
        logger.info(f"   Executed {result.get('steps_executed', 0)} steps")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to generate outline: {e}", e, debug=debug)
