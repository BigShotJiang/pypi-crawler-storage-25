"""AI model management commands — list, switch, show current model."""

from __future__ import annotations

import logging
import os

import click

from cli._commands.helpers import (
    ENV_PROVIDER_KEYS,
    PROVIDER_DEFAULT_MODELS,
    _canonicalize_provider,
)
from cli._helpers.error_handling import handle_cli_exception
from services.global_settings import GlobalSettings, get_default_model


def _configured_providers() -> list[str]:
    """Return list of providers that have credentials configured."""
    configured: list[str] = []
    for provider, env_key in ENV_PROVIDER_KEYS:
        if os.getenv(env_key):
            configured.append(_canonicalize_provider(provider))
    return configured


@click.group()
def model():
    """AI model management — list, switch, show current model."""
    pass


@model.command("list")
@click.pass_context
def model_list(ctx: click.Context) -> None:
    """List all available models grouped by provider.

    Configured providers are marked with ✓. The active provider/model is
    highlighted with ★.
    """
    logger = logging.getLogger("scribe")

    configured = _configured_providers()
    gs = GlobalSettings.load()
    active_provider = gs.default_provider
    active_model = gs.default_model

    if not active_provider:
        active_provider = _detect_provider_from_env()

    logger.info("Available AI Models")
    logger.info("")

    for provider, default_model in sorted(PROVIDER_DEFAULT_MODELS.items()):
        is_configured = provider in configured
        is_active = provider == active_provider

        marker = "★" if is_active else ("✓" if is_configured else " ")
        provider_label = f"{marker} {provider}"
        model_label = default_model

        if is_active and active_model and active_model != default_model:
            model_label = f"{active_model} (default: {default_model})"
        elif is_active:
            model_label = f"{active_model}"

        logger.info(f"  {provider_label:20s} {model_label}")

    logger.info("")
    logger.info("  ★ = active   ✓ = configured")
    logger.info("  Use `scribe model switch <provider> [model]` to change.")


@model.command("switch")
@click.argument("provider")
@click.argument("model_name", required=False, default="")
@click.pass_context
def model_switch(ctx: click.Context, provider: str, model_name: str) -> None:
    """Switch the active AI provider and model.

    \b
    Switch to a provider (uses its default model):
      scribe model switch anthropic
      scribe model switch openai

    \b
    Switch to a specific model:
      scribe model switch anthropic claude-sonnet-4-20250514
      scribe model switch openai gpt-5.1-mini
    """
    logger = logging.getLogger("scribe")
    debug = ctx.obj.get("debug", False)

    try:
        canonical = _canonicalize_provider(provider)
        if canonical not in PROVIDER_DEFAULT_MODELS:
            valid = ", ".join(sorted(PROVIDER_DEFAULT_MODELS.keys()))
            logger.error(f"Unknown provider: {provider}")
            logger.info(f"Valid providers: {valid}")
            return

        resolved_model = model_name.strip() if model_name.strip() else get_default_model(canonical)

        gs = GlobalSettings.load()
        gs.configure_provider(canonical, model=resolved_model, set_as_default=True)

        logger.info(f"✅ Switched to {canonical} / {resolved_model}")
        logger.info(f"   Saved to: {gs.config_path()}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to switch model: {e}", e, debug=debug)


@model.command("current")
@click.pass_context
def model_current(ctx: click.Context) -> None:
    """Show the currently active provider and model."""
    logger = logging.getLogger("scribe")

    gs = GlobalSettings.load()
    provider = gs.default_provider
    model_name = gs.default_model

    if not provider:
        provider = _detect_provider_from_env()
    if not model_name and provider:
        model_name = get_default_model(provider)

    if not provider:
        logger.info("No AI provider configured.")
        logger.info("Run `scribe setup apikey <provider> <key>` to configure one.")
        return

    configured = _configured_providers()
    has_key = provider in configured

    logger.info(f"Provider:  {provider} {'(key ✓)' if has_key else '(no key)'}")
    logger.info(f"Model:     {model_name}")

    provider_settings = gs.get_provider_settings(provider)
    if provider_settings.base_url:
        logger.info(f"Base URL:  {provider_settings.base_url}")

    if not has_key:
        logger.info("")
        logger.info(f"⚠️  No API key detected for {provider}.")
        logger.info(f"   Run `scribe setup apikey {provider} <your-key>` to add one.")


def _detect_provider_from_env() -> str:
    """Detect provider from configured environment variables."""
    for provider, env_key in ENV_PROVIDER_KEYS:
        if os.getenv(env_key):
            return _canonicalize_provider(provider)
    return ""
