"""Shared Click options for autonomous CLI commands."""

from __future__ import annotations

from collections.abc import Callable
from typing import TypeVar

import click

F = TypeVar("F", bound=Callable[..., object])


def with_checkpoint_dir_options(
    default_dir: str,
    help_text: str = "Directory containing checkpoints",
) -> Callable[[F], F]:
    """Apply standard checkpoint directory options including legacy alias."""

    def decorator(func: F) -> F:
        wrapped = click.option(
            "--project-dir",
            "checkpoint_dir",
            help="Deprecated alias for --checkpoint-dir",
            hidden=True,
        )(func)
        wrapped = click.option(
            "--checkpoint-dir",
            "checkpoint_dir",
            default=default_dir,
            help=help_text,
        )(wrapped)
        return wrapped

    return decorator
