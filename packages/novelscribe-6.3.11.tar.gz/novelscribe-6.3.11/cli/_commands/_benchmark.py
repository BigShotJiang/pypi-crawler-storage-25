"""Synthetic agent benchmark using ParallelRunner."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

import click

from core.runtime.benchmark import BenchmarkConfig, BenchmarkReport, SubagentBenchmark


@dataclass
class ParallelBenchmarkConfig:
    agent_count: int = 8
    latency_seconds: float = 0.5
    concurrency_levels: list[int] = field(default_factory=lambda: [1, 2, 4, 8])
    iterations: int = 3
    timeout_per_agent: float = 60.0
    format: str = "table"


class ParallelBenchmark:
    """Benchmark harness using ParallelRunner."""

    def __init__(self, config: ParallelBenchmarkConfig) -> None:
        self.config = config

    async def run(self) -> BenchmarkReport:
        cfg = BenchmarkConfig(
            agent_count=self.config.agent_count,
            latency_seconds=self.config.latency_seconds,
            concurrency_levels=self.config.concurrency_levels,
            iterations=self.config.iterations,
            timeout_per_agent=self.config.timeout_per_agent,
        )
        harness = SubagentBenchmark(cfg)
        return await harness.run()


async def _run_benchmark(config: ParallelBenchmarkConfig) -> BenchmarkReport:
    benchmark = ParallelBenchmark(config)
    return await benchmark.run()


def print_report(report: BenchmarkReport, fmt: str = "table") -> None:
    """Print benchmark report in the requested format."""
    if fmt == "json":
        click.echo(report.to_json())
        return

    click.echo("\n" + "=" * 72)
    click.echo("  Subagent Parallel Execution Benchmark")
    click.echo("=" * 72)

    click.echo(
        f"\n  Agents: {report.config['agent_count']}   "
        f"Latency: {report.config['latency_seconds']}s   "
        f"Iterations: {report.config['iterations']}"
    )

    click.echo(
        f"\n  Sequential baseline: {report.sequential_baseline:.3f}s  "
        f"({report.config['agent_count']} × {report.config['latency_seconds']}s)"
    )
    click.echo("\n" + "-" * 72)
    click.echo(
        f"  {'Concurrency':>11} | {'Wall Time':>10} | {'Throughput':>11} | "
        f"{'Speedup':>7} | {'Overhead%':>9}"
    )
    click.echo("-" * 72)

    for result in report.parallel_results:
        click.echo(
            f"  {result['concurrency']:>11} | "
            f"{result['wall_time']:>10.3f}s | "
            f"{result['throughput']:>10.3f}/s | "
            f"{result['speedup']:>7.2f}x | "
            f"{result['overhead_pct']:>8.2f}%"
        )

    click.echo("-" * 72)

    s = report.summary
    click.echo("\n  Summary:")
    click.echo(f"    Sequential total:   {s['sequential_total']:.3f}s")
    click.echo(
        f"    Best concurrency:    {s['best_concurrency']} (speedup {s['max_speedup']:.2f}x)"
    )
    click.echo(
        f"    Levels tested:       {s['levels_tested']}  "
        f"({', '.join(str(c) for c in report.config['concurrency_levels'])})"
    )
    click.echo(f"    Total agents:         {s['total_agents']}")
    click.echo(f"    Iterations/level:    {s['iterations_per_level']}")
    click.echo("=" * 72 + "\n")


@click.group("benchmark")
def benchmark() -> None:
    """Performance benchmarking tools for NovelScribe subsystems."""
    pass


@benchmark.command("parallel")
@click.option("--agents", "-a", default=8, help="Number of parallel agents")
@click.option("--latency", "-l", default=0.5, help="Simulated latency per agent (seconds)")
@click.option(
    "--concurrency",
    "-c",
    default="1,2,4,8",
    help="Comma-separated concurrency levels to test",
)
@click.option("--iterations", "-i", default=3, help="Iterations per concurrency level")
@click.option("--timeout", default=60.0, help="Timeout per agent (seconds)")
@click.option(
    "--format",
    "-f",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format",
)
def benchmark_parallel(
    agents: int,
    latency: float,
    concurrency: str,
    iterations: int,
    timeout: float,
    format: str,
) -> None:
    """Benchmark parallel subagent execution via ParallelRunner.

    Measures speedup and throughput at different concurrency levels using
    synthetic agents with configurable artificial latency.

    Examples:

      scribe benchmark parallel --agents 8 --latency 0.5 --concurrency 1,2,4,8
      scribe benchmark parallel --agents 16 --latency 0.2 -i 5 --format json
    """
    concurrency_levels = [int(x.strip()) for x in concurrency.split(",") if x.strip()]

    config = ParallelBenchmarkConfig(
        agent_count=agents,
        latency_seconds=latency,
        concurrency_levels=concurrency_levels,
        iterations=iterations,
        timeout_per_agent=timeout,
        format=format,
    )

    async def run() -> None:
        report = await _run_benchmark(config)
        print_report(report, fmt=format)

    asyncio.run(run())
