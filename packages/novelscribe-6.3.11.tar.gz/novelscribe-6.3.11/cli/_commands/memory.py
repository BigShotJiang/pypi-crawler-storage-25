"""Memory CLI group and compatibility exports."""

import logging
import time  # noqa: F401

import click

from cli._memory.commands.cache_ops import register_cache_commands
from cli._memory.commands.longform import register_longform_commands
from cli._memory.commands.monitoring import register_monitoring_commands
from cli._memory.commands.profiling import register_profiling_commands
from cli._memory.kb import kb
from core.context.cache import ContextCache  # noqa: F401
from core.context.compressor import ContextCompressor  # noqa: F401
from core.llm.estimator import TokenEstimator  # noqa: F401
from core.memory.cache_manager import CacheManager, CacheManagerConfig  # noqa: F401
from core.memory.monitor import create_default_monitor  # noqa: F401
from core.memory.profiler import MemoryProfiler, MemoryProfilerConfig  # noqa: F401
from core.resilience.object_pool import get_pool_manager  # noqa: F401

logger = logging.getLogger("scribe")


@click.group()
@click.pass_context
def memory(ctx: click.Context) -> None:
    """Memory optimization and monitoring commands."""
    pass


memory.add_command(kb)
register_longform_commands(memory)
register_profiling_commands(memory)
register_cache_commands(memory)
register_monitoring_commands(memory)
