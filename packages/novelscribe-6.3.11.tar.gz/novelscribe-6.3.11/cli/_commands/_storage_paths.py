"""Shared project path helpers for CLI commands."""

from pathlib import Path

from services.project_service import ProjectService


def base_path(project_dir: str | None = None) -> Path:
    """Resolve the projects base path for CLI commands."""
    if project_dir:
        return Path(project_dir)
    return ProjectService().base_path


def project_path(name: str, project_dir: str | None = None) -> Path:
    """Resolve a project directory path from project name."""
    return base_path(project_dir) / name
