"""Command-line interface for novel writing harness."""

import logging
import sys
from difflib import get_close_matches

import click
from dotenv import load_dotenv

from cli._commands._benchmark import benchmark
from cli._commands._creative_init import new, outline  # noqa: F401
from cli._commands._dashboard import dashboard
from cli._commands.agents import agents
from cli._commands.autonomous import autonomous
from cli._commands.character import character
from cli._commands.checkpoint import checkpoint
from cli._commands.config import config
from cli._commands.drafts import drafts
from cli._commands.export import export
from cli._commands.guardrails import guardrails
from cli._commands.helpers import (
    configure_logging,
)
from cli._commands.list import templates
from cli._commands.logs import logs
from cli._commands.memory import memory
from cli._commands.model import model
from cli._commands.monitors import monitors
from cli._commands.pagination import cache, paginate
from cli._commands.parallel import parallel_cli
from cli._commands.performance import performance_cli
from cli._commands.plugins import plugins
from cli._commands.proactive import app as proactive
from cli._commands.project import project
from cli._commands.qa import qa
from cli._commands.review import review
from cli._commands.run import run
from cli._commands.setup import setup
from cli._commands.summary import summary
from cli._commands.tui import tui
from cli._commands.verify import verify
from cli._commands.version import version as version_cmd
from cli._commands.workflows import workflows
from cli._helpers.error_handling import handle_cli_exception
from cli._helpers.workflow_paths import workflow_yaml
from cli._templates.create import template_create
from core._version import get_version
from core.git import create_git_manager
from core.llm.client import LLMConfig
from core.orchestration.pipeline import (
    create_orchestrator,  # noqa: F401 — kept for test patch targets
)
from services.global_settings import load_persisted_env_secrets
from services.project_service import ProjectService
from services.workflow_service import WorkflowService

load_dotenv()
load_persisted_env_secrets()


_WORKFLOW_COMMANDS = [
    "setup",
    "new",
    "outline",
    "character",
    "write",
    "status",
    "export",
]


class ScribeCLI(click.Group):
    """Custom Click group with better error handling and grouped help."""

    _lang: str = "en"

    def _resolve_help_lang(self, ctx: click.Context | None) -> str:
        if ctx is not None:
            obj = ctx.obj or {}
            explicit = obj.get("lang")
            if explicit:
                return explicit
        try:
            from cli._commands.helpers import _resolve_lang_code

            return _resolve_lang_code(None)
        except Exception:
            return "en"

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        from core.i18n.help_strings import get_help_string

        lang = self._resolve_help_lang(ctx)
        self.help = get_help_string("cli.description", lang, self.help or "")
        super().format_help(ctx, formatter)

    def format_commands(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        from core.i18n.help_strings import get_help_string

        lang = self._resolve_help_lang(ctx)
        commands = []
        for subcommand in self.list_commands(ctx):
            cmd = self.get_command(ctx, subcommand)
            if cmd is None or cmd.hidden:
                continue
            commands.append((subcommand, cmd))

        if not commands:
            return

        limit = formatter.width - 6 - max(len(cmd[0]) for cmd in commands)

        cmd_key_map: dict[str, str] = {
            "setup": "cmd.setup",
            "new": "cmd.new",
            "outline": "cmd.outline",
            "character": "cmd.character",
            "write": "cmd.write",
            "status": "cmd.status",
            "export": "cmd.export",
            "agents": "cmd.agents",
            "workflows": "cmd.workflows",
            "run": "cmd.run",
            "autonomous": "cmd.autonomous",
            "review": "cmd.review",
            "summary": "cmd.summary",
            "config": "cmd.config",
            "model": "cmd.model",
            "logs": "cmd.logs",
            "memory": "cmd.memory",
            "drafts": "cmd.drafts",
            "verify": "cmd.verify",
            "qa": "cmd.qa",
            "checkpoint": "cmd.checkpoint",
            "templates": "cmd.templates",
            "project": "cmd.project",
            "paginate": "cmd.paginate",
            "cache": "cmd.cache",
            "tui": "cmd.tui",
            "version": "cmd.version",
            "performance": "cmd.performance",
            "parallel": "cmd.parallel",
            "guardrails": "cmd.guardrails",
            "plugins": "cmd.plugins",
            "benchmark": "cmd.benchmark",
            "dashboard": "cmd.dashboard",
            "monitors": "cmd.monitors",
            "help": "cmd.help",
            "proactive": "cmd.proactive",
        }

        def _localized_rows(names: list[str]) -> list[tuple[str, str]]:
            rows = []
            for name in names:
                cmd = self.get_command(ctx, name)
                if not cmd or cmd.hidden:
                    continue
                key = cmd_key_map.get(name)
                if key:
                    short = get_help_string(key, lang, cmd.get_short_help_str(limit))
                else:
                    short = cmd.get_short_help_str(limit)
                rows.append((name, short))
            return rows

        workflow_rows = _localized_rows(_WORKFLOW_COMMANDS)
        auxiliary_names = sorted(name for name, _ in commands if name not in _WORKFLOW_COMMANDS)
        auxiliary_rows = _localized_rows(auxiliary_names)

        if workflow_rows:
            with formatter.section(get_help_string("section.workflow", lang, "Workflow")):
                formatter.write_dl(workflow_rows)

        if auxiliary_rows:
            with formatter.section(get_help_string("section.utilities", lang, "Utilities")):
                formatter.write_dl(auxiliary_rows)

    def get_command(self, ctx: click.Context, cmd_name: str):
        """Get command by name, with suggestions for typos."""
        from core.i18n.help_strings import get_help_string

        lang = self._resolve_help_lang(ctx)
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd

        available_commands = list(self.commands.keys())
        suggestions = get_close_matches(cmd_name, available_commands, n=3, cutoff=0.4)

        if suggestions:
            suggestion_text = "\n" + get_help_string("err.did_you_mean", lang) + "\n"
            for suggestion in suggestions:
                suggestion_text += f"  • {suggestion}\n"
            msg = get_help_string("err.no_command", lang).format(name=cmd_name)
            ctx.fail(f"{msg}{suggestion_text}")
        else:
            msg = get_help_string("err.no_command", lang).format(name=cmd_name)
            hint = get_help_string("msg.see_help", lang)
            ctx.fail(f"{msg} {hint}")


HELP_SHORT = {"help_option_names": ["-h", "--help"]}


@click.group(cls=ScribeCLI, context_settings=HELP_SHORT)
@click.option("-v", "--verbose", count=True, help="Increase verbosity (can be used multiple times)")
@click.option("-d", "--debug", is_flag=True, help="Enable debug mode")
@click.option(
    "--lang",
    type=click.Choice(["en", "zh-CN", "zh-TW"], case_sensitive=False),
    default=None,
    help="Language (en, zh-CN, zh-TW). Overrides project META.yaml.",
)
@click.version_option(version=get_version(), prog_name="scribe")
@click.option("--no-update-check", is_flag=True, help="Skip update check on startup")
@click.pass_context
def cli(
    ctx: click.Context, verbose: int, debug: bool, lang: str | None, no_update_check: bool
) -> None:
    """NovelScribe - AI-powered autonomous novel generation system."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["debug"] = debug
    ctx.obj["lang"] = lang

    configure_logging(verbose, debug)

    logger = logging.getLogger("scribe")
    logger.debug(f"Scribe CLI started (verbose={verbose}, debug={debug}, lang={lang})")

    if not no_update_check and not debug:
        try:
            from core.version import notify_if_update_available

            notify_if_update_available()
        except Exception:
            pass


@cli.command()
@click.argument("project_name")
@click.option("--chapter", "-c", required=True, type=int, help="Chapter number to write")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.pass_context
def write(ctx: click.Context, project_name: str, chapter: int, provider: str) -> None:
    """Write a specific chapter."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        logger.info(f"Writing chapter {chapter} for: {project_name}")

        svc = ProjectService()
        project_path = svc.get_project_path(project_name)

        llm_config = LLMConfig(provider=provider)
        wf_svc = WorkflowService()
        result = wf_svc.execute_workflow_sync(
            project_name=project_name,
            workflow_path=workflow_yaml("writing_phase"),
            variables={"chapter": chapter},
            llm_config=llm_config,
        )

        git_manager = create_git_manager(project_path, auto_commit=True)
        git_manager.auto_commit_step(
            agent="writer_agent",
            description=f"Write chapter {chapter}",
        )

        logger.info(f"✅ Chapter {chapter} written successfully for '{project_name}'")
        logger.info(f"   Executed {result.get('steps_executed', 0)} steps")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to write chapter: {e}", e, debug=debug)


@cli.command()
@click.argument("project_name")
@click.pass_context
def status(ctx: click.Context, project_name: str) -> None:
    """Show project status."""
    logger = logging.getLogger("scribe")

    try:
        svc = ProjectService()
        project_path = svc.get_project_path(project_name)

        git_manager = create_git_manager(project_path, auto_commit=False)
        repo_status = git_manager.status()

        logger.info(f"Project: {project_name}")
        logger.info(f"Location: {project_path}")
        logger.info(f"Git Repository: {'Yes' if repo_status['is_repository'] else 'No'}")

        if repo_status["is_repository"]:
            logger.info(f"Current Branch: {repo_status['current_branch']}")
            logger.info(f"Current Commit: {repo_status['current_commit']}")

            if repo_status["has_changes"]:
                logger.info(f"Uncommitted Changes: {len(repo_status['changed_files'])} files")
            else:
                logger.info("Uncommitted Changes: None")

            tags = git_manager.get_tags()
            if tags:
                logger.info(f"Milestones: {', '.join(tag['name'] for tag in tags)}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to get status: {e}", e, debug=False)


@cli.command()
@click.argument("args", nargs=-1)
@click.option("--provider", default="", help="LLM provider to use (auto-detected if omitted)")
@click.option("--model", default="", help="LLM model to use (provider default if omitted)")
@click.pass_context
def help(ctx: click.Context, args: tuple[str, ...], provider: str, model: str) -> None:
    """Ask questions, get help, or start an interactive chat with AI.

    \b
    Interactive chat (no args):
      scribe help

    \b
    Subcommand help (first arg is a known subcommand):
      scribe help agents

    \b
    One-shot answer (first arg is NOT a known subcommand):
      scribe help how to create a new character?
      scribe help --provider anthropic what agents are available?
    """
    from cli._commands.chat import SETUP_HELP
    from core.chat import ChatEngine

    if args and args[0] in ctx.parent.command.commands:
        sub_cmd = ctx.parent.command.commands[args[0]]
        if sub_cmd:
            click.echo(sub_cmd.get_help(ctx))
            return

    lang = ctx.obj.get("lang") or ""
    engine = ChatEngine(provider=provider, model=model, lang=lang or None, project_dir=".")

    if not engine.is_configured():
        click.echo(SETUP_HELP)
        return

    question_text = " ".join(args).strip()
    if question_text:
        try:
            answer = engine.ask(question_text)
            click.echo(f"\n🤖 {answer}\n")
        except Exception as e:
            logger = logging.getLogger("scribe")
            logger.error(f"Chat failed: {e}")
            click.echo(f"\n❌ Error: {e}")
            click.echo("💡 Check your API key with: scribe setup verify\n")
    else:
        try:
            engine.run_interactive()
        except KeyboardInterrupt:
            click.echo("\n👋 Bye!")


cli.add_command(agents)
cli.add_command(character)
cli.add_command(workflows)
cli.add_command(run)
cli.add_command(autonomous)
cli.add_command(verify)
cli.add_command(drafts)
cli.add_command(paginate)
cli.add_command(cache)
cli.add_command(summary)
cli.add_command(memory)
cli.add_command(tui)
cli.add_command(model)
cli.add_command(performance_cli)
cli.add_command(version_cmd)
cli.add_command(config)
cli.add_command(setup)
cli.add_command(logs)
cli.add_command(new)
cli.add_command(outline)
cli.add_command(templates)
cli.add_command(template_create)
cli.add_command(proactive)
cli.add_command(checkpoint)
cli.add_command(export)
cli.add_command(review)
cli.add_command(qa)
cli.add_command(parallel_cli)
cli.add_command(project)
cli.add_command(guardrails)
cli.add_command(plugins)
cli.add_command(benchmark)
cli.add_command(dashboard)
cli.add_command(monitors)


def main() -> int:
    """Main entry point for CLI with improved error handling."""
    from core.i18n.help_strings import get_help_string

    try:
        cli(obj={}, standalone_mode=False)
        return 0
    except click.exceptions.UsageError as e:
        msg = e.format_message() if hasattr(e, "format_message") else str(e)
        click.echo(f"❌ {get_help_string('err.usage_prefix', 'en').format(msg=msg)}", err=True)
        click.echo(f"\n💡 {get_help_string('msg.see_help', 'en')}", err=True)
        return 1
    except click.exceptions.ClickException as e:
        e.show()
        return 1
    except KeyboardInterrupt:
        click.echo(f"\n⚠️  {get_help_string('err.cancelled', 'en')}", err=True)
        return 130
    except Exception as e:
        click.echo(f"❌ {get_help_string('err.unexpected', 'en').format(msg=str(e))}", err=True)

        import logging

        logger = logging.getLogger("scribe")
        logger.debug("Full traceback:", exc_info=True)

        click.echo(f"\n💡 {get_help_string('msg.verbose_hint', 'en')}", err=True)
        return 1


if __name__ == "__main__":
    sys.exit(main())
