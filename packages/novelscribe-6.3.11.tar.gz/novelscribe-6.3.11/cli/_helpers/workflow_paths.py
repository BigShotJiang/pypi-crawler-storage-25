"""Resolve workflow YAML paths from the installed 'workflows' package."""

from __future__ import annotations

from importlib import import_module
from pathlib import Path


def _workflows_root() -> Path:
    """Return the filesystem path of the installed ``workflows`` package."""
    mod = import_module("workflows")
    return Path(mod.__file__).parent


def workflow_yaml(name: str, language: str | None = None) -> str:
    """Resolve a workflow YAML file path.

    Resolution order:
      1. ``<workflows_pkg>/<language>/<name>.yaml``  (if *language* given)
      2. ``<workflows_pkg>/<name>.yaml``              (fallback)

    Args:
        name: Workflow filename without extension, e.g. ``"outline_phase"``.
        language: Optional language sub-directory, e.g. ``"zh-CN"``.

    Returns:
        Absolute path string to the YAML file.

    Raises:
        FileNotFoundError: If neither location contains the file.
    """
    root = _workflows_root()
    if language:
        lang_path = root / language / f"{name}.yaml"
        if lang_path.exists():
            return str(lang_path)
    default_path = root / f"{name}.yaml"
    if default_path.exists():
        return str(default_path)
    searched = [str(root / language / f"{name}.yaml")] if language else []
    searched.append(str(default_path))
    raise FileNotFoundError(f"Workflow '{name}.yaml' not found. Searched: {', '.join(searched)}")
