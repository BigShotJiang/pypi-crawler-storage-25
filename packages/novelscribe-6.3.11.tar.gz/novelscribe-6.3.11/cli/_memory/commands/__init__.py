"""Topic-based memory CLI command registration."""
