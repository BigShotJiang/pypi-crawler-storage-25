"""Cache and optimization commands for memory CLI."""

import sys

import click

from cli._memory.commands.helpers import logger, memory_module


@click.command("cache-stats")
@click.argument("project_name")
@click.option("--size-mb", default=100.0, type=float, help="Max cache size in MB")
@click.option("--max-entries", default=100, type=int, help="Max cache entries")
@click.option("--ttl", default=None, type=int, help="Default TTL in seconds")
@click.pass_context
def cache_stats(
    ctx: click.Context,
    project_name: str,
    size_mb: float,
    max_entries: int,
    ttl: int | None,
) -> None:
    """Show cache statistics."""
    try:
        memory_commands = memory_module()
        logger.info(f"Cache statistics for: {project_name}")

        config = memory_commands.CacheManagerConfig(
            max_size_mb=size_mb,
            max_entries=max_entries,
            default_ttl_seconds=ttl,
        )
        cache = memory_commands.CacheManager(config)
        stats = cache.get_statistics()

        logger.info("")
        logger.info("## Cache Statistics")
        logger.info("")
        logger.info(f"Entries: {stats['entries']}")
        logger.info(f"Hits: {stats['hits']}")
        logger.info(f"Misses: {stats['misses']}")
        logger.info(f"Hit Rate: {stats['hit_rate']}")
        logger.info(f"Evictions: {stats['evictions']}")
        logger.info(f"Expirations: {stats['expirations']}")
        logger.info(f"Current Size: {stats['current_size_mb']:.2f} MB")
        logger.info(f"Max Size: {stats['max_size_mb']:.2f} MB")
        logger.info(f"Utilization: {stats['utilization_percent']:.1f}%")
    except Exception as e:
        logger.error(f"Failed to get cache stats: {e}")
        sys.exit(1)


@click.command()
@click.argument("project_name")
@click.pass_context
def optimize(ctx: click.Context, project_name: str) -> None:
    """Optimize memory usage."""
    try:
        memory_commands = memory_module()
        logger.info(f"Optimizing memory for: {project_name}")

        caches_optimized = 0

        try:
            context_cache = memory_commands.ContextCache()
            context_cache.optimize()
            caches_optimized += 1
            logger.info("Optimized ContextCache")
        except Exception:
            pass

        try:
            cache_manager = memory_commands.CacheManager()
            cache_manager.optimize()
            caches_optimized += 1
            logger.info("Optimized CacheManager")
        except Exception:
            pass

        pool_manager = memory_commands.get_pool_manager()
        pool_manager.optimize_all()
        logger.info("Optimized object pools")

        logger.info("")
        logger.info(f"Optimized {caches_optimized} caches and object pools")
    except Exception as e:
        logger.error(f"Failed to optimize memory: {e}")
        sys.exit(1)


@click.command("clear-cache")
@click.argument("project_name")
@click.option("--all", "clear_all", is_flag=True, help="Clear all caches")
@click.option("--context", is_flag=True, help="Clear context cache")
@click.option("--summary", is_flag=True, help="Clear summary cache")
@click.pass_context
def clear_cache(
    ctx: click.Context,
    project_name: str,
    clear_all: bool,
    context: bool,
    summary: bool,
) -> None:
    """Clear caches."""
    try:
        memory_commands = memory_module()
        logger.info(f"Clearing caches for: {project_name}")

        if clear_all or context:
            try:
                cache = memory_commands.ContextCache()
                cache.clear()
                logger.info("Cleared context cache")
            except Exception:
                pass

        if clear_all or summary:
            try:
                cache = memory_commands.CacheManager()
                cache.clear()
                logger.info("Cleared summary cache")
            except Exception:
                pass

        if not (clear_all or context or summary):
            logger.error("Specify --all, --context, or --summary")
            sys.exit(1)
    except Exception as e:
        logger.error(f"Failed to clear caches: {e}")
        sys.exit(1)


@click.command("pool-stats")
@click.argument("project_name")
@click.pass_context
def pool_stats(ctx: click.Context, project_name: str) -> None:
    """Show object pool statistics."""
    try:
        memory_commands = memory_module()
        logger.info(f"Object pool statistics for: {project_name}")

        stats = memory_commands.get_pool_manager().get_all_stats()
        if not stats:
            logger.info("No object pools registered")
            return

        logger.info("")
        for pool_name, current_stats in stats.items():
            logger.info(f"## {pool_name}")
            logger.info(f"Total Acquired: {current_stats['total_acquired']}")
            logger.info(f"Total Released: {current_stats['total_released']}")
            logger.info(f"Total Created: {current_stats['total_created']}")
            logger.info(f"Current Size: {current_stats['current_size']}")
            logger.info(f"Available: {current_stats['current_available']}")
            logger.info(f"In Use: {current_stats['current_in_use']}")
            logger.info(f"Peak Size: {current_stats['peak_size']}")
            logger.info(f"Utilization: {current_stats['utilization_rate']}")
            logger.info("")
    except Exception as e:
        logger.error(f"Failed to get pool stats: {e}")
        sys.exit(1)


def register_cache_commands(memory: click.Group) -> None:
    """Register cache and optimization commands."""
    memory.add_command(cache_stats)
    memory.add_command(optimize)
    memory.add_command(clear_cache)
    memory.add_command(pool_stats)
