"""Shared helpers for memory CLI command modules."""

import logging
from pathlib import Path

logger = logging.getLogger("scribe")


def memory_module():
    """Return the legacy memory command module for compatibility patch points."""
    import cli._commands.memory as memory_commands

    return memory_commands


def resolve_project(project_name: str) -> Path:
    """Resolve a project name to its filesystem path."""
    from cli._commands._storage_paths import project_path

    return project_path(project_name)


def read_chapter_content(project_path: Path, chapter_num: int) -> str | None:
    """Read a chapter markdown file if present."""
    chapter_file = project_path / "chapters" / f"chapter_{chapter_num:03d}.md"
    if not chapter_file.exists():
        return None
    return chapter_file.read_text(encoding="utf-8")
