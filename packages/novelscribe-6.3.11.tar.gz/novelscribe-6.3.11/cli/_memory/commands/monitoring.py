"""Monitoring and stress-test commands for memory CLI."""

import sys

import click

from cli._memory.commands.helpers import logger, memory_module


@click.command("stress-test")
@click.argument("project_name")
@click.option("--chapters", default=100, type=int, help="Number of chapters to test")
@click.option("--interval", default=5, type=int, help="Check interval in seconds")
@click.pass_context
def stress_test(ctx: click.Context, project_name: str, chapters: int, interval: int) -> None:
    """Run memory stress test."""
    try:
        memory_commands = memory_module()
        logger.info(f"Running stress test for: {project_name}")
        logger.info(f"Chapters: {chapters}, Interval: {interval} seconds")

        profiler = memory_commands.MemoryProfiler()
        profiler.start_profiling(interval)

        try:
            logger.info("Starting stress test...")
            for i in range(chapters):
                memory_commands.time.sleep(1)
                if i % 10 == 0:
                    snapshot = profiler.take_snapshot()
                    logger.info(f"[Chapter {i}] Memory: {snapshot.total_memory_mb:.1f} MB")
        finally:
            profiler.stop_profiling()

        report = profiler.get_memory_report()
        logger.info("")
        logger.info("## Stress Test Results")
        logger.info("")
        logger.info(f"Peak Memory: {report['summary']['peak_memory_mb']:.1f} MB")
        logger.info(f"Average Memory: {report['summary']['average_memory_mb']:.1f} MB")
        logger.info(f"Total Change: {report['summary']['total_change_mb']:.1f} MB")

        if report["leaks_detected"]:
            logger.info("")
            logger.info("Potential Leaks:")
            for leak in report["leaks_detected"]:
                logger.info(f"   - {leak}")
        else:
            logger.info("")
            logger.info("No leaks detected")
    except Exception as e:
        logger.error(f"Failed to run stress test: {e}")
        sys.exit(1)


@click.command()
@click.argument("project_name")
@click.option("--interval", default=5, type=int, help="Check interval in seconds")
@click.option("--duration", default=60, type=int, help="Monitor duration in seconds")
@click.pass_context
def monitor(ctx: click.Context, project_name: str, interval: int, duration: int) -> None:
    """Monitor memory in real-time."""
    try:
        memory_commands = memory_module()
        logger.info(f"Monitoring memory for: {project_name}")
        logger.info(f"Interval: {interval}s, Duration: {duration}s")
        logger.info("Press Ctrl+C to stop")
        logger.info("")

        monitor_instance = memory_commands.create_default_monitor()
        monitor_instance.start_monitoring()

        try:
            start_time = memory_commands.time.time()
            while memory_commands.time.time() - start_time < duration:
                memory_commands.time.sleep(interval)
                report = monitor_instance.get_status_report()
                elapsed = int(memory_commands.time.time() - start_time)
                logger.info(
                    f"[{elapsed}s] Memory: {report['current_memory_mb']:.1f} MB, "
                    f"Trend: {report['trend']}"
                )
        finally:
            monitor_instance.stop_monitoring()

        logger.info("")
        logger.info("## Monitoring Summary")

        triggered = monitor_instance.get_triggered_actions()
        if triggered:
            logger.info(f"Triggered {len(triggered)} actions")
            for action in triggered[-5:]:
                logger.info(f"  - {action['threshold']}: {action['status']}")
        else:
            logger.info("No threshold actions triggered")
    except KeyboardInterrupt:
        logger.info("")
        logger.info("Monitoring stopped by user")
    except Exception as e:
        logger.error(f"Failed to monitor memory: {e}")
        sys.exit(1)


def register_monitoring_commands(memory: click.Group) -> None:
    """Register monitoring and stress-test commands."""
    memory.add_command(stress_test)
    memory.add_command(monitor)
