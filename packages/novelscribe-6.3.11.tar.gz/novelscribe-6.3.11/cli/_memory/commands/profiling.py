"""Profiling and analysis commands for memory CLI."""

import sys

import click

from cli._memory.commands.helpers import logger, memory_module


@click.command()
@click.argument("project_name")
@click.option("--duration", default=60, type=int, help="Profiling duration in seconds")
@click.option("--interval", default=5, type=int, help="Snapshot interval in seconds")
@click.pass_context
def profile(ctx: click.Context, project_name: str, duration: int, interval: int) -> None:
    """Profile memory usage for a duration."""
    try:
        memory_commands = memory_module()
        logger.info(f"Profiling memory for: {project_name}")
        logger.info(f"Duration: {duration} seconds, Interval: {interval} seconds")

        config = memory_commands.MemoryProfilerConfig(
            snapshot_interval_seconds=interval,
            max_snapshots=duration // interval + 10,
        )
        profiler = memory_commands.MemoryProfiler(config)
        profiler.start_profiling(interval)

        try:
            for i in range(duration // interval):
                memory_commands.time.sleep(interval)
                snapshot = profiler.take_snapshot()
                logger.info(f"[{i * interval}s] Memory: {snapshot.total_memory_mb:.1f} MB")
        finally:
            profiler.stop_profiling()

        report = profiler.get_memory_report()
        logger.info("")
        logger.info(f"## Memory Report for {project_name}")
        logger.info("")
        logger.info(f"Current Memory: {report['summary']['current_memory_mb']:.1f} MB")
        logger.info(f"Average Memory: {report['summary']['average_memory_mb']:.1f} MB")
        logger.info(f"Peak Memory: {report['summary']['peak_memory_mb']:.1f} MB")
        logger.info(f"Memory Change: {report['summary']['total_change_mb']:.1f} MB")

        if report["leaks_detected"]:
            logger.info("")
            logger.info("Potential Leaks Detected:")
            for leak in report["leaks_detected"]:
                logger.info(f"   - {leak}")
    except Exception as e:
        logger.error(f"Failed to profile memory: {e}")
        sys.exit(1)


@click.command()
@click.argument("project_name")
@click.pass_context
def stats(ctx: click.Context, project_name: str) -> None:
    """Show memory statistics."""
    try:
        memory_commands = memory_module()
        logger.info(f"Memory statistics for: {project_name}")

        profiler = memory_commands.MemoryProfiler()
        snapshot = profiler.take_snapshot()

        logger.info("")
        logger.info("## Current Memory Usage")
        logger.info("")
        logger.info(f"Total Memory: {snapshot.total_memory_mb:.1f} MB")
        logger.info(f"Available Memory: {snapshot.available_memory_mb:.1f} MB")
        logger.info(f"System Memory: {snapshot.system_memory_mb:.1f} MB")
        logger.info(
            f"Usage Percent: {(snapshot.total_memory_mb / snapshot.system_memory_mb) * 100:.1f}%"
        )

        if snapshot.component_usage:
            logger.info("")
            logger.info("## Component Usage")
            for component, size_mb in snapshot.component_usage.items():
                logger.info(f"{component}: {size_mb:.1f} MB")
    except Exception as e:
        logger.error(f"Failed to get memory stats: {e}")
        sys.exit(1)


@click.command()
@click.argument("project_name")
@click.option("--hours", default=24, type=int, help="Hours to analyze")
@click.pass_context
def analyze(ctx: click.Context, project_name: str, hours: int) -> None:
    """Analyze memory trends over time."""
    try:
        memory_commands = memory_module()
        logger.info(f"Analyzing memory trends for: {project_name}")
        logger.info(f"Time window: {hours} hours")

        monitor = memory_commands.create_default_monitor()
        report = monitor.get_status_report()

        logger.info("")
        logger.info("## Memory Analysis")
        logger.info("")
        logger.info(f"Current Memory: {report['current_memory_mb']:.1f} MB")
        logger.info(f"Trend: {report['trend']}")
        logger.info("")
        logger.info("## Threshold Status")
        for threshold in report["thresholds"]:
            status_icon = "OK" if threshold["status"] == "ok" else "WARN"
            logger.info(f"{status_icon} {threshold['name']}: {threshold['status'].upper()}")
            logger.info(f"   Current: {threshold['current_mb']:.1f} MB")
            logger.info(f"   Warning: {threshold['warning_mb']:.1f} MB")
            logger.info(f"   Critical: {threshold['critical_mb']:.1f} MB")
    except Exception as e:
        logger.error(f"Failed to analyze memory: {e}")
        sys.exit(1)


@click.command()
@click.argument("project_name")
@click.option(
    "--strategy",
    default="truncate",
    type=click.Choice(["truncate", "summarize", "extract"]),
    help="Compression strategy",
)
@click.option("--target-tokens", default=8000, type=int, help="Target token count")
@click.option("--test-context", default="", help="Test context to compress")
@click.pass_context
def prune(
    ctx: click.Context,
    project_name: str,
    strategy: str,
    target_tokens: int,
    test_context: str,
) -> None:
    """Test context compression."""
    try:
        memory_commands = memory_module()
        logger.info(f"Compressing context for: {project_name}")
        logger.info(f"Strategy: {strategy}, Target: {target_tokens} tokens")

        compressor = memory_commands.ContextCompressor()
        if not test_context:
            test_context = "This is a test context with some repeated content. " * 100

        estimator = memory_commands.TokenEstimator()
        original_tokens = estimator.estimate_tokens(test_context)

        from core.context.assembly import ContextBlock
        from core.context.schema import TokenBudget

        block = ContextBlock(
            artifact_type="test",
            content=test_context,
            token_count=original_tokens,
            priority=1.0,
        )
        budget = TokenBudget(total=target_tokens)
        result = compressor.compress([block], budget)

        logger.info("")
        logger.info("## Compression Results")
        logger.info("")
        logger.info(f"Original Size: {original_tokens} tokens")
        logger.info(f"Compressed Size: {result.token_count} tokens")
        logger.info(f"Reduction: {result.reduction_percent:.1f}%")
        logger.info(f"Tiers Applied: {[tier.value for tier in result.tiers_applied]}")
    except Exception as e:
        logger.error(f"Failed to compress context: {e}")
        sys.exit(1)


def register_profiling_commands(memory: click.Group) -> None:
    """Register profiling and analysis commands."""
    memory.add_command(profile)
    memory.add_command(stats)
    memory.add_command(analyze)
    memory.add_command(prune)
