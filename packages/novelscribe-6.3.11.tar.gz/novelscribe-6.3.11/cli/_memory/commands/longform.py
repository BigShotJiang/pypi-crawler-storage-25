"""Long-form memory CLI commands."""

import sys

import click

from cli._memory.commands.helpers import read_chapter_content, resolve_project


def _echo(msg: str) -> None:
    """Echo to stdout (captured by CliRunner)."""
    click.echo(msg)


@click.command("index")
@click.argument("project_name")
@click.option("--chapter", required=True, type=int, help="Chapter number to index")
@click.pass_context
def longform_index(ctx: click.Context, project_name: str, chapter: int) -> None:
    """Index a chapter for semantic memory retrieval."""
    from core.memory.longform import LongFormMemory

    project_path = resolve_project(project_name)
    lfm = LongFormMemory(project_path)

    content = read_chapter_content(project_path, chapter)
    if content is None:
        click.echo(f"Chapter {chapter} not found in project {project_name}", err=True)
        sys.exit(1)

    chunks = lfm.index_chapter(chapter, content)
    _echo(f"Indexed chapter {chapter}: {len(chunks)} scenes")


@click.command("search")
@click.argument("project_name")
@click.argument("query")
@click.option("--chapter", default=0, type=int, help="Hint chapter for recency weighting")
@click.option("--max-tokens", default=4000, type=int, help="Max context tokens")
@click.pass_context
def longform_search(
    ctx: click.Context, project_name: str, query: str, chapter: int, max_tokens: int
) -> None:
    """Semantic search across indexed chapters."""
    from core.memory.longform import LongFormMemory

    project_path = resolve_project(project_name)
    lfm = LongFormMemory(project_path)

    results = lfm.retrieve(query, chapter_hint=chapter, max_tokens=max_tokens)
    if not results:
        _echo("No results found.")
        return

    for block in results:
        preview = f"{block.content[:120]}"
        _echo(
            f"[{block.source.value}] ch{block.chapter_num} "
            f"({block.token_count}t, {block.score:.2f}): {preview}"
        )


@click.command("longform-stats")
@click.argument("project_name")
@click.pass_context
def longform_stats_cmd(ctx: click.Context, project_name: str) -> None:
    """Show long-form memory index statistics."""
    from core.memory.longform import LongFormMemory

    project_path = resolve_project(project_name)
    lfm = LongFormMemory(project_path)

    stats = lfm.stats()
    _echo(f"Chapters indexed: {stats.total_chapters_indexed}")
    _echo(f"Total chunks: {stats.total_chunks}")
    _echo(f"Characters tracked: {stats.total_characters}")
    _echo(f"Locations tracked: {stats.total_locations}")
    _echo(f"Index size: {stats.index_size_bytes} bytes")
    if stats.last_indexed_chapter:
        _echo(f"Last indexed: chapter {stats.last_indexed_chapter}")
    _echo(f"Embedding model: {stats.embedding_model or '(not loaded)'}")


@click.command("rebuild")
@click.argument("project_name")
@click.option("--force", is_flag=True, help="Force rebuild even if already indexed")
@click.pass_context
def longform_rebuild(ctx: click.Context, project_name: str, force: bool) -> None:
    """Rebuild the long-form memory index from all chapters."""
    from core.memory.longform import LongFormMemory

    project_path = resolve_project(project_name)
    lfm = LongFormMemory(project_path)

    chapters_dir = project_path / "chapters"
    if not chapters_dir.exists():
        click.echo(f"No chapters directory found in {project_name}", err=True)
        sys.exit(1)

    indexed = 0
    for chapter_file in sorted(chapters_dir.glob("chapter_*.md")):
        try:
            chapter_num = int(chapter_file.stem.split("_")[1])
        except (ValueError, IndexError):
            continue

        content = chapter_file.read_text(encoding="utf-8")
        chunks = lfm.index_chapter(chapter_num, content)
        _echo(f"Indexed chapter {chapter_num}: {len(chunks)} scenes")
        indexed += 1

    _echo(f"Rebuild complete: {indexed} chapters indexed")


def register_longform_commands(memory: click.Group) -> None:
    """Register long-form memory commands."""
    memory.add_command(longform_index)
    memory.add_command(longform_search)
    memory.add_command(longform_stats_cmd)
    memory.add_command(longform_rebuild)
