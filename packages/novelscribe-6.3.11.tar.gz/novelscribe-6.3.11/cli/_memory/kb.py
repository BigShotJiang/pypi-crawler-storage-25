import logging
import sys
from pathlib import Path

import click

from core.memory.bus import MemoryBus

logger = logging.getLogger("scribe")

DEFAULT_PROJECT_DIR = ".novels"


@click.group()
@click.pass_context
def kb(ctx: click.Context) -> None:
    pass


def _get_memory_bus(project_path: Path) -> MemoryBus:
    return MemoryBus(project_path=project_path)


def _resolve_project(project_name: str, project_dir: str) -> Path:
    """Resolve project path and exit if not found."""
    project_path = Path(project_dir) / project_name
    if not project_path.exists():
        logger.error(f"Project not found: {project_name}")
        sys.exit(1)
    return project_path


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def status(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)

    wiki = memory_bus.get_wiki()
    graph = memory_bus.get_graph()
    conversations = memory_bus.get_conversations()
    learning = memory_bus.get_learning()

    logger.info("")
    logger.info("## Memory System Status")
    logger.info("")
    logger.info(f"Project: {project_name}")
    logger.info(f"Path: {project_path}")

    logger.info("")
    logger.info("### Knowledge Graph")
    logger.info(f"Nodes: {len(graph._nodes)}")
    logger.info(f"Edges: {len(graph._edges)}")

    logger.info("")
    logger.info("### Novel Wiki")
    logger.info(f"Pages: {len(wiki.get_all_pages())}")

    logger.info("")
    logger.info("### Conversation Memory")
    session_files = conversations._get_all_session_files()
    logger.info(f"Sessions: {len(session_files)}")

    logger.info("")
    logger.info("### Generation Learning")
    insights = learning.get_insights()
    logger.info(f"Insights: {len(insights)}")


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def wiki_list(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    wiki = memory_bus.get_wiki()

    pages = wiki.get_all_pages()

    logger.info("")
    logger.info(f"## Wiki Pages ({len(pages)} total)")
    logger.info("")

    for page in pages:
        logger.info(f"  {page.page_id}: {page.title}")


@kb.command()
@click.argument("project_name")
@click.argument("page_id")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def wiki_view(ctx: click.Context, project_name: str, page_id: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)

    memory_bus = _get_memory_bus(project_path)
    wiki = memory_bus.get_wiki()

    content = wiki.get_page(page_id)

    if content is None:
        logger.error(f"Wiki page not found: {page_id}")
        sys.exit(1)

    logger.info("")
    logger.info(f"## {page_id}")
    logger.info("")
    logger.info(content)


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def wiki_lint(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    wiki = memory_bus.get_wiki()

    issues = wiki.lint()

    logger.info("")
    logger.info(f"## Wiki Lint Results ({len(issues)} issues)")
    logger.info("")

    if not issues:
        logger.info("✅ No issues found")
        return

    for issue in issues:
        severity = issue.severity
        icon = "❌" if severity == "error" else "⚠️"
        logger.info(f"{icon} [{severity.upper()}] {issue.description}")


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def graph_stats(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    graph = memory_bus.get_graph()

    logger.info("")
    logger.info("## Knowledge Graph Statistics")
    logger.info("")
    logger.info(f"Nodes: {len(graph._nodes)}")
    logger.info(f"Edges: {len(graph._edges)}")

    type_counts: dict[str, int] = {}
    for node_data in graph._nodes.values():
        etype = node_data.get("entity_type", "unknown")
        type_counts[etype] = type_counts.get(etype, 0) + 1

    if type_counts:
        logger.info("")
        logger.info("### Node Types")
        for ntype, count in sorted(type_counts.items()):
            logger.info(f"  {ntype}: {count}")


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def graph_visualize(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    graph = memory_bus.get_graph()

    if not graph._nodes:
        logger.info("No nodes in graph.")
        return

    logger.info("")
    logger.info("## Knowledge Graph Visualization")
    logger.info("")

    for node_id, node_data in graph._nodes.items():
        name = node_data.get("name", node_id)
        etype = node_data.get("entity_type", "unknown")
        logger.info(f"• {name} ({etype})")

        outgoing = []
        for edge_id, edge_data in graph._edges.items():
            if edge_data.get("source_id") == node_id:
                rel = edge_data.get("relation", "?")
                target_id = edge_data.get("target_id", "?")
                target_name = graph._nodes.get(target_id, {}).get("name", target_id)
                outgoing.append(f"    └── {rel} → {target_name}")

        for line in outgoing[:5]:
            logger.info(line)
        if len(outgoing) > 5:
            logger.info(f"    ... and {len(outgoing) - 5} more relationships")
        logger.info("")


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def consistency_check(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    graph = memory_bus.get_graph()

    issues = graph.check_consistency()

    logger.info("")
    logger.info(f"## Consistency Check ({len(issues)} issues)")
    logger.info("")

    if not issues:
        logger.info("\u2705 No consistency issues found")
        return

    for issue in issues:
        severity = issue.severity
        icon = (
            "\u274c"
            if severity == "error"
            else "\u26a0\ufe0f"
            if severity == "warning"
            else "\u2139\ufe0f"
        )
        logger.info(f"{icon} [{severity.upper()}] {issue.description}")


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def sessions(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    conversations = memory_bus.get_conversations()

    session_files = conversations._get_all_session_files()

    logger.info("")
    logger.info(f"## Sessions ({len(session_files)} total)")
    logger.info("")

    for session_file in session_files:
        session_id = session_file.stem
        logger.info(f"  {session_id}")


@kb.command()
@click.argument("project_name")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.pass_context
def learning(ctx: click.Context, project_name: str, project_dir: str) -> None:
    project_path = _resolve_project(project_name, project_dir)
    memory_bus = _get_memory_bus(project_path)
    learning = memory_bus.get_learning()

    insights = learning.get_insights()

    logger.info("")
    logger.info(f"## Generation Learning ({len(insights)} insights)")
    logger.info("")

    for insight in insights:
        logger.info(f"  [{insight.category}] {insight.description}")


@kb.command()
@click.argument("topic")
@click.option(
    "--kind",
    default="narrative_trope",
    help="Template kind (narrative_trope, scene_blueprint, etc.)",
)
@click.option("--lang", default="en", help="Language code (en, zh-CN, zh-TW)")
@click.option("--max-sources", default=3, help="Maximum web sources to process")
@click.option(
    "--interactive/--no-interactive", default=False, help="Confirm each template before saving"
)
@click.pass_context
def harvest(
    ctx: click.Context,
    topic: str,
    kind: str,
    lang: str,
    max_sources: int,
    interactive: bool,
) -> None:
    """Harvest novel-writing knowledge from the internet on a given TOPIC."""
    from core.kb import KnowledgeHarvester

    harvester = KnowledgeHarvester(lang=lang, default_kind=kind)
    result = harvester.harvest(topic, kind=kind, max_sources=max_sources, interactive=interactive)

    logger.info("")
    logger.info("## Knowledge Harvest Results")
    logger.info("")
    logger.info(f"Query: {result.query}")
    logger.info(f"Sources found: {result.sources_found}")
    logger.info(f"Templates created: {result.templates_created}")

    if result.template_ids:
        logger.info("")
        logger.info("### Created Templates")
        for tid in result.template_ids:
            logger.info(f"  {tid}")

    if result.errors:
        logger.info("")
        logger.info("### Errors")
        for err in result.errors:
            logger.info(f"  ❌ {err}")
