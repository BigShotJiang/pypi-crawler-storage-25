"""Periodic monitor scheduler — timer-based trigger with change detection."""

from __future__ import annotations

import asyncio
import hashlib
import logging
from pathlib import Path
from typing import Dict, Optional

from core.agents.monitor_runner import MonitorResult, MonitorRunner

logger = logging.getLogger(__name__)


class MonitorScheduler:
    """Periodic monitor scheduler using asyncio.

    Runs monitors at a configurable interval, but only when chapter
    content has changed since the last run (SHA-256 hash comparison).
    Sequential execution to avoid LLM rate limits.
    """

    def __init__(
        self,
        runner: MonitorRunner,
        interval_minutes: int = 30,
    ) -> None:
        self._runner = runner
        self._interval_minutes = interval_minutes
        self._task: Optional[asyncio.Task] = None
        self._last_hash: Optional[str] = None
        self._running = False
        self._last_results: Dict[str, MonitorResult] = {}

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def last_results(self) -> Dict[str, MonitorResult]:
        return self._last_results

    async def start(self, project_path: str) -> None:
        """Start the periodic scheduler.

        Args:
            project_path: Path to the project directory.

        Idempotent — calling start() while already running is a no-op.
        """
        if self._running:
            logger.debug("MonitorScheduler already running")
            return

        self._running = True
        self._task = asyncio.create_task(self._run_loop(project_path))
        logger.info("MonitorScheduler started (interval=%dm)", self._interval_minutes)

    async def stop(self) -> None:
        """Stop the scheduler gracefully.

        Cancels the periodic task without interrupting a running monitor.
        """
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        logger.info("MonitorScheduler stopped")

    async def _run_loop(self, project_path: str) -> None:
        """Main loop: sleep, check changes, run monitors."""
        while self._running:
            try:
                await asyncio.sleep(self._interval_minutes * 60)
            except asyncio.CancelledError:
                break

            if not self._running:
                break

            try:
                if self._has_changes(project_path):
                    logger.info("Changes detected — running monitors")
                    self._last_results = await asyncio.to_thread(
                        self._runner.run_all_monitors,
                        project_name=Path(project_path).name,
                    )
                else:
                    logger.debug("No changes detected — skipping monitor run")
            except Exception:
                logger.exception("MonitorScheduler run failed")

    def _has_changes(self, project_path: str) -> bool:
        """Check if chapter content has changed since the last run.

        Args:
            project_path: Path to the project directory.

        Returns:
            True if content hash differs from last run.
        """
        chapters_dir = Path(project_path) / "chapters"
        if not chapters_dir.exists():
            return False

        hasher = hashlib.sha256()
        chapter_files = sorted(chapters_dir.glob("*.md"))
        if not chapter_files:
            return False

        for f in chapter_files:
            try:
                hasher.update(f.read_bytes())
            except OSError:
                continue

        current_hash = hasher.hexdigest()
        if self._last_hash is None:
            self._last_hash = current_hash
            return True

        changed = current_hash != self._last_hash
        self._last_hash = current_hash
        return changed
