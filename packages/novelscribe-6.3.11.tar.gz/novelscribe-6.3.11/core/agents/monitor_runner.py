"""Background monitor runner — executes monitor agents outside the main pipeline."""

from __future__ import annotations

import logging
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from core.agents.agent import Agent, AgentCategory
from core.agents.executor import AgentExecutor
from core.agents.registry import AgentRegistry

logger = logging.getLogger(__name__)


class MonitorResult(BaseModel):
    """Result from a single monitor execution."""

    monitor_name: str
    health_score: float = Field(default=0.0, ge=0.0, le=10.0)
    issues_found: int = Field(default=0, ge=0)
    report_path: str = ""
    execution_time_ms: int = Field(default=0, ge=0)
    error: Optional[str] = None


class MonitorStatus(BaseModel):
    """Current status of a monitor."""

    name: str
    last_run: Optional[str] = None
    health_score: Optional[float] = None
    issues_found: Optional[int] = None
    status: str = "idle"


class MonitorRunner:
    """Executes monitor agents outside the main pipeline.

    Uses the existing AgentExecutor to run monitor agents.
    Saves reports to a dedicated monitors subdirectory.
    """

    def __init__(
        self,
        executor: AgentExecutor,
        registry: AgentRegistry,
        reports_dir: str = "reports/monitors",
    ) -> None:
        self._executor = executor
        self._registry = registry
        self._reports_dir = reports_dir

    def get_monitor_agents(self) -> List[Agent]:
        """Return all agents with category 'monitor'."""
        return self._registry.get_agents_by_category(AgentCategory.MONITOR)

    def _ensure_context_bus(self) -> None:
        """Lazily initialize ContextBus if not already set."""
        if self._executor.context_bus is None:
            from core.context.bus import ContextBus

            self._executor.context_bus = ContextBus.simple(
                llm_client=self._executor.llm_client,
            )

    def run_monitor(
        self,
        agent: Agent,
        project_name: str,
        provider: str = "openai",
        model_config: Optional[Dict[str, Any]] = None,
    ) -> MonitorResult:
        """Execute a single monitor agent and return structured result.

        Args:
            agent: Monitor agent to execute.
            project_name: Project name for output saving.
            provider: LLM provider name.
            model_config: Model configuration dict.

        Returns:
            MonitorResult with health score, issues, and report path.
        """
        start_ms = int(time.time() * 1000)
        config = model_config or {}

        if agent.category != AgentCategory.MONITOR:
            return MonitorResult(
                monitor_name=agent.name,
                error=f"Agent '{agent.name}' is not a monitor (category: {agent.category})",
                execution_time_ms=int(time.time() * 1000) - start_ms,
            )

        self._ensure_context_bus()

        report_dir = Path(self._executor.work_dir) / project_name / self._reports_dir
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / f"{agent.name}_report.md"

        try:
            result = self._executor.execute_with_bus(
                agent=agent,
                provider=provider,
                model_config=config,
                project_name=project_name,
            )

            output = result.output or ""
            health_score = _parse_health_score(output)
            issues_found = _parse_issues_found(output)

            if output:
                report_path.write_text(output, encoding="utf-8")

            elapsed = int(time.time() * 1000) - start_ms
            return MonitorResult(
                monitor_name=agent.name,
                health_score=health_score,
                issues_found=issues_found,
                report_path=str(report_path),
                execution_time_ms=elapsed,
                error=result.error if not result.success else None,
            )
        except Exception as exc:
            logger.exception("Monitor %s failed", agent.name)
            elapsed = int(time.time() * 1000) - start_ms
            return MonitorResult(
                monitor_name=agent.name,
                error=str(exc),
                execution_time_ms=elapsed,
            )

    def run_all_monitors(
        self,
        project_name: str,
        provider: str = "openai",
        model_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, MonitorResult]:
        """Run all monitor agents sequentially and return results.

        Args:
            project_name: Project name for output saving.
            provider: LLM provider name.
            model_config: Model configuration dict.

        Returns:
            Dict mapping monitor name to MonitorResult.
        """
        monitors = self.get_monitor_agents()
        results: Dict[str, MonitorResult] = {}

        for agent in monitors:
            logger.info("Running monitor: %s", agent.name)
            results[agent.name] = self.run_monitor(
                agent=agent,
                project_name=project_name,
                provider=provider,
                model_config=model_config,
            )

        return results


def _parse_health_score(output: str) -> float:
    """Extract overall health score from monitor output."""
    patterns = [
        r"(?:overall|health|total)\s*(?:score|rating)\s*[:/]?\s*\**\s*(\d+(?:\.\d+)?)",
    ]
    for pattern in patterns:
        match = re.search(pattern, output, re.IGNORECASE)
        if match:
            return min(10.0, max(0.0, float(match.group(1))))
    return 0.0


def _parse_issues_found(output: str) -> int:
    """Extract issue count from monitor output."""
    patterns = [
        r"(?:issues?\s*found|total\s*issues?)\s*[:/]?\s*\**\s*(\d+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, output, re.IGNORECASE)
        if match:
            return int(match.group(1))
    return 0
