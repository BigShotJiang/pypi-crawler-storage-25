"""tmux configuration model."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class TmuxConfig(BaseModel):
    """Configuration for tmux pane management during sub-agent execution.

    Attributes:
        enabled: When True (default), auto-detect tmux and enable pane creation.
            Set to False to force-disable even when running inside tmux.
        auto_close: When True, close panes after sub-agent completes.
            Default False — panes are preserved for user inspection.
        layout: Pane split direction. Currently only "horizontal" (left/right).
        reuse_panes: When True, re-use existing pane by sub-agent name on re-run
            instead of creating a new pane.
    """

    enabled: bool = Field(default=True, description="Auto-detect and enable tmux panes")
    auto_close: bool = Field(default=False, description="Close panes after sub-agent completes")
    layout: Literal["horizontal"] = Field(default="horizontal", description="Pane split direction")
    reuse_panes: bool = Field(default=True, description="Re-use pane by sub-agent name on re-run")
