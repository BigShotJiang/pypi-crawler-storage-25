"""Output adapter that formats runtime events for tmux pane display."""

from __future__ import annotations

import logging
from typing import Any

__all__ = ["TmuxOutputAdapter"]

_LOGGER = logging.getLogger("scribe")


class TmuxOutputAdapter:
    """Formats AgentRuntime emit events and writes them to a tmux pane.

    Provides structured visual output for sub-agent execution:
    - Turn headers with progress
    - Event summaries
    - Stream tokens (pass-through)
    - Completion/error status

    Args:
        pane_id: tmux pane identifier to write to.
        agent_name: Sub-agent name for display headers.
        write_fn: Callable that writes text to the pane (injected for testability).
            Defaults to a subprocess-based tmux send-keys wrapper.
    """

    def __init__(
        self,
        pane_id: str,
        agent_name: str,
        write_fn: Any | None = None,
    ) -> None:
        self._pane_id = pane_id
        self._agent_name = agent_name
        self._write_fn = write_fn or self._default_write

    def _default_write(self, text: str) -> None:
        """Default write implementation using TmuxManager."""
        from .manager import TmuxManager

        TmuxManager().write(self._pane_id, text)

    def _write(self, text: str) -> None:
        try:
            self._write_fn(text)
        except Exception:  # noqa: BLE001
            pass

    def on_emit(self, event: str, metadata: dict[str, Any]) -> None:
        """Format and display a runtime hook event.

        Args:
            event: Hook event name (e.g. 'runtime_before_turn').
            metadata: Event metadata dict.
        """
        short_event = event.replace("runtime_", "").replace("_", " ")
        summary = metadata.get("error") or metadata.get("phase") or ""
        if summary:
            self._write(f"[{self._agent_name}] {short_event}: {summary}")
        else:
            self._write(f"[{self._agent_name}] {short_event}")

    def on_turn_start(self, turn_index: int, max_turns: int) -> None:
        """Display a turn header.

        Args:
            turn_index: Current turn number (0-based).
            max_turns: Maximum number of turns.
        """
        self._write(f"--- Turn {turn_index + 1}/{max_turns} [{self._agent_name}] ---")

    def on_stream_chunk(self, token: str) -> None:
        """Write a streaming token directly.

        Args:
            token: Text chunk from LLM streaming.
        """
        self._write(token)

    def on_complete(self, output: str | None, error: str | None) -> None:
        """Display sub-agent completion status.

        Args:
            output: Final output text (truncated for display).
            error: Error message if the sub-agent failed.
        """
        if error:
            self._write(f"✗ [{self._agent_name}] Failed: {error}")
        else:
            preview = (output[:120] + "...") if output and len(output) > 120 else (output or "")
            self._write(f"✓ [{self._agent_name}] Complete: {preview}")

    def on_error(self, error: str) -> None:
        """Display an error message.

        Args:
            error: Error description.
        """
        self._write(f"✗ [{self._agent_name}] Error: {error}")
