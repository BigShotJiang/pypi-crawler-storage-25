"""tmux pane lifecycle manager for sub-agent visual isolation."""

from __future__ import annotations

import logging
import os
import shutil
import subprocess

from .config import TmuxConfig

__all__ = ["TmuxManager"]

_LOGGER = logging.getLogger(__name__)
_TMUX_TIMEOUT = 5


class TmuxManager:
    """Manages tmux panes for sub-agent output visualization.

    Creates horizontal split panes for each sub-agent, writes formatted
    output via send-keys, and optionally preserves panes after completion.

    All tmux operations degrade silently — failures never propagate to the
    execution layer.
    """

    def __init__(self, config: TmuxConfig | None = None) -> None:
        self._config = config or TmuxConfig()
        self._panes: dict[str, str] = {}

    @staticmethod
    def is_available() -> bool:
        """Check if tmux is available and we are running inside a session.

        Returns:
            True when TMUX environment variable is set and tmux binary exists.
        """
        if not os.environ.get("TMUX"):
            return False
        return shutil.which("tmux") is not None

    def create_pane(self, name: str) -> str | None:
        """Create a tmux pane for a named sub-agent, or re-use existing.

        Args:
            name: Sub-agent identifier used as pane title and reuse key.

        Returns:
            pane_id string on success, None on failure or when tmux is unavailable.
        """
        if not self.is_available() or not self._config.enabled:
            return None

        if self._config.reuse_panes and name in self._panes:
            existing_id = self._panes[name]
            self.clear_pane(existing_id)
            _LOGGER.debug(f"Re-using tmux pane {existing_id} for sub-agent '{name}'")
            return existing_id

        try:
            result = subprocess.run(
                ["tmux", "split-window", "-h", "-P", "-F", "#{pane_id}"],
                capture_output=True,
                text=True,
                timeout=_TMUX_TIMEOUT,
            )
            if result.returncode != 0:
                _LOGGER.warning(f"tmux split-window failed: {result.stderr.strip()}")
                return None

            pane_id = result.stdout.strip()
            if not pane_id:
                _LOGGER.warning("tmux split-window returned empty pane_id")
                return None

            self._panes[name] = pane_id
            _LOGGER.debug(f"Created tmux pane {pane_id} for sub-agent '{name}'")
            return pane_id
        except subprocess.SubprocessError as exc:
            _LOGGER.warning(f"tmux split-window error: {exc}")
            return None
        except Exception as exc:  # noqa: BLE001
            _LOGGER.warning(f"Unexpected tmux error: {exc}")
            return None

    def write(self, pane_id: str, text: str) -> None:
        """Write text to a tmux pane.

        Args:
            pane_id: Target pane identifier.
            text: Text to display in the pane.
        """
        if not pane_id:
            return
        try:
            subprocess.run(
                ["tmux", "send-keys", "-t", pane_id, "--", text, "Enter"],
                capture_output=True,
                text=True,
                timeout=_TMUX_TIMEOUT,
            )
        except subprocess.SubprocessError as exc:
            _LOGGER.debug(f"tmux send-keys failed for pane {pane_id}: {exc}")
            self._remove_dead_pane(pane_id)
        except Exception:  # noqa: BLE001
            pass

    def clear_pane(self, pane_id: str) -> None:
        """Clear the content of a tmux pane.

        Args:
            pane_id: Target pane identifier.
        """
        if not pane_id:
            return
        try:
            subprocess.run(
                ["tmux", "send-keys", "-t", pane_id, "-l", "\x0c"],
                capture_output=True,
                text=True,
                timeout=_TMUX_TIMEOUT,
            )
        except subprocess.SubprocessError:
            pass
        except Exception:  # noqa: BLE001
            pass

    def close_pane(self, pane_id: str) -> None:
        """Close a specific tmux pane.

        Args:
            pane_id: Target pane identifier.
        """
        if not pane_id:
            return
        try:
            subprocess.run(
                ["tmux", "kill-pane", "-t", pane_id],
                capture_output=True,
                text=True,
                timeout=_TMUX_TIMEOUT,
            )
        except subprocess.SubprocessError:
            pass
        except Exception:  # noqa: BLE001
            pass
        self._panes = {k: v for k, v in self._panes.items() if v != pane_id}

    def close_all(self) -> None:
        """Close all panes created by this manager."""
        for pane_id in list(self._panes.values()):
            self.close_pane(pane_id)
        self._panes.clear()

    def _remove_dead_pane(self, pane_id: str) -> None:
        """Remove a pane from tracking (user may have closed it manually)."""
        self._panes = {k: v for k, v in self._panes.items() if v != pane_id}
