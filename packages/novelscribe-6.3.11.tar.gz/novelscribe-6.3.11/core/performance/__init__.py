"""Performance subsystem — profiling, benchmarking, and optimization tracking."""

from .core import Clock, PerformanceProfiler, uuid4
from .file_optimizer import FileOptimizer, FileOptimizerStats, get_file_optimizer
from .profiler import ProfilingContext, _global_profiler, get_profiler, profile_function
from .types import (
    Enum,
    ExecutionProfile,
    ExecutionStatus,
    PerformanceReport,
    ProfileType,
    dataclass,
    field,
)

__all__ = [
    "Clock",
    "PerformanceProfiler",
    "uuid4",
    "FileOptimizer",
    "FileOptimizerStats",
    "get_file_optimizer",
    "ProfilingContext",
    "_global_profiler",
    "get_profiler",
    "profile_function",
    "Enum",
    "ExecutionProfile",
    "ExecutionStatus",
    "PerformanceReport",
    "ProfileType",
    "dataclass",
    "field",
]
