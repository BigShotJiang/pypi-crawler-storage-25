"""Phase-scoped cache — scope-aware invalidation for LLM response caching.

Extends LLMOptimizer with phase-scoped cache keys so that completing
a phase invalidates all cache entries for that phase.
"""

from __future__ import annotations

import hashlib
import time
from typing import Any, Dict, List, Optional

from .optimizer import CacheEntry, CachePolicy, LLMOptimizer


class PhaseScopedCache:
    """Cache wrapper that scopes entries by pipeline phase.

    Each cache entry is tagged with a phase name. When a phase completes,
    all entries for that phase can be invalidated in one call.
    """

    def __init__(
        self,
        optimizer: Optional[LLMOptimizer] = None,
        default_ttl: float = 3600.0,
    ):
        self._optimizer = optimizer or LLMOptimizer()
        self._default_ttl = default_ttl
        self._phase_index: Dict[str, List[str]] = {}

    @property
    def optimizer(self) -> LLMOptimizer:
        return self._optimizer

    def cache_key(
        self,
        prompt: str,
        model: str,
        phase: Optional[str] = None,
        step: Optional[str] = None,
    ) -> str:
        """Generate a scope-aware cache key."""
        parts = [model, prompt]
        if phase:
            parts.append(f"phase:{phase}")
        if step:
            parts.append(f"step:{step}")
        content = "|".join(parts)
        return hashlib.sha256(content.encode()).hexdigest()

    def get(
        self,
        prompt: str,
        model: str,
        phase: Optional[str] = None,
        step: Optional[str] = None,
        ttl: Optional[float] = None,
    ) -> Optional[str]:
        """Get cached response if available and not expired."""
        key = self.cache_key(prompt, model, phase, step)
        entry = self._optimizer._get_cached_response(key)
        if entry is None:
            return None

        effective_ttl = ttl if ttl is not None else self._default_ttl
        if time.time() - entry.created_at > effective_ttl:
            return None

        return entry.value if isinstance(entry, CacheEntry) else str(entry)

    def put(
        self,
        prompt: str,
        model: str,
        response: str,
        phase: Optional[str] = None,
        step: Optional[str] = None,
        policy: CachePolicy = CachePolicy.LRU,
    ) -> None:
        """Cache a response with phase scope."""
        key = self.cache_key(prompt, model, phase, step)
        self._optimizer._add_to_cache(key, response, model, policy)

        if phase:
            if phase not in self._phase_index:
                self._phase_index[phase] = []
            self._phase_index[phase].append(key)

    def invalidate_phase(self, phase: str) -> int:
        """Invalidate all cache entries for a phase.

        Returns the number of entries invalidated.
        """
        keys = self._phase_index.pop(phase, [])
        count = 0
        for key in keys:
            if key in self._optimizer._cache:
                del self._optimizer._cache[key]
                self._optimizer._cache_timestamps.pop(key, None)
                count += 1
        return count

    def invalidate_all(self) -> int:
        """Invalidate all cached entries."""
        count = len(self._optimizer._cache)
        self._optimizer._cache.clear()
        self._optimizer._cache_timestamps.clear()
        self._phase_index.clear()
        return count

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        opt_stats = self._optimizer.get_stats()
        return {
            "total_calls": opt_stats.total_calls,
            "cache_hits": opt_stats.cache_hits,
            "cache_misses": opt_stats.cache_misses,
            "tokens_saved": opt_stats.tokens_saved,
            "cost_saved": opt_stats.cost_saved,
            "phases_tracked": len(self._phase_index),
            "cache_size": len(self._optimizer._cache),
        }
