"""Phase Model Profile — config-based per-phase and per-step model routing."""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict


class StepModelOverride(BaseModel):
    """Model override for a specific step within a phase."""

    model_config = ConfigDict(extra="forbid")

    provider: Optional[str] = None
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class PhaseModelConfig(BaseModel):
    """Model configuration for a specific phase."""

    model_config = ConfigDict(extra="forbid")

    provider: Optional[str] = None
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    steps: Dict[str, StepModelOverride] = {}


class PhaseModelDefault(BaseModel):
    """Default model configuration used when no phase-specific config exists."""

    model_config = ConfigDict(extra="forbid")

    provider: str = "openai"
    model: str = "gpt-5.1"
    temperature: float = 0.7
    max_tokens: Optional[int] = None


class PhaseModelProfile(BaseModel):
    """Config mapping from phase name to LLM provider/model/temperature.

    Supports phase-level defaults with per-step overrides.
    Loaded from scribe.yaml under the ``phase_models`` key.
    """

    model_config = ConfigDict(extra="forbid")

    default: PhaseModelDefault = PhaseModelDefault()
    phases: Dict[str, PhaseModelConfig] = {}

    def resolve(
        self,
        phase_name: str,
        step_name: Optional[str] = None,
        base_config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Resolve the effective LLM config for a phase/step combination.

        Priority order (highest wins):
        1. Step-level override (``phases.<name>.steps.<step>``)
        2. Phase-level config (``phases.<name>``)
        3. Profile default (``default``)
        4. Base config passed by caller

        Args:
            phase_name: Workflow/phase name (e.g. ``writing_phase``).
            step_name: Optional step name for step-level override.
            base_config: Base config dict from the caller (``provider``, ``model``, etc.)

        Returns:
            Merged config dict with resolved ``provider``, ``model``,
            ``temperature``, ``max_tokens``.
        """
        result: Dict[str, Any] = {}

        if base_config:
            result.update(base_config)

        result.setdefault("provider", self.default.provider)
        result.setdefault("model", self.default.model)
        result.setdefault("temperature", self.default.temperature)
        if self.default.max_tokens is not None:
            result.setdefault("max_tokens", self.default.max_tokens)

        phase_cfg = self.phases.get(phase_name)
        if phase_cfg:
            if phase_cfg.provider is not None:
                result["provider"] = phase_cfg.provider
            if phase_cfg.model is not None:
                result["model"] = phase_cfg.model
            if phase_cfg.temperature is not None:
                result["temperature"] = phase_cfg.temperature
            if phase_cfg.max_tokens is not None:
                result["max_tokens"] = phase_cfg.max_tokens

        if step_name and phase_cfg and step_name in phase_cfg.steps:
            step_cfg = phase_cfg.steps[step_name]
            if step_cfg.provider is not None:
                result["provider"] = step_cfg.provider
            if step_cfg.model is not None:
                result["model"] = step_cfg.model
            if step_cfg.temperature is not None:
                result["temperature"] = step_cfg.temperature
            if step_cfg.max_tokens is not None:
                result["max_tokens"] = step_cfg.max_tokens

        return result
