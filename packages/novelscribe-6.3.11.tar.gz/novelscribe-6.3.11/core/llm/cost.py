"""
Cost Calculator for LLM API Usage

Provides accurate cost calculations for all supported LLM providers:
- OpenAI (GPT-4, GPT-3.5, etc.)
- Anthropic (Claude 3, Claude 2, etc.)
- Google (Gemini Pro, etc.)

All costs are in USD and based on official provider pricing (as of 2024).
"""

from typing import Dict, Optional


class CostCalculator:
    """
    Calculate LLM API costs based on token usage.

    Cost rates are per 1K tokens.
    """

    # OpenAI pricing (USD per 1K tokens)
    OPENAI_COSTS = {
        # GPT-4 Turbo
        "gpt-4-turbo": {"input": 0.01, "output": 0.03},
        "gpt-4-turbo-2024-04-09": {"input": 0.01, "output": 0.03},
        "gpt-4-turbo-preview": {"input": 0.01, "output": 0.03},
        # GPT-4
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-4-0613": {"input": 0.03, "output": 0.06},
        "gpt-4-32k": {"input": 0.06, "output": 0.12},
        "gpt-4-32k-0613": {"input": 0.06, "output": 0.12},
        # GPT-3.5 Turbo
        "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
        "gpt-3.5-turbo-0613": {"input": 0.0005, "output": 0.0015},
        "gpt-3.5-turbo-16k": {"input": 0.001, "output": 0.002},
        "gpt-3.5-turbo-16k-0613": {"input": 0.001, "output": 0.002},
        # gpt-5.1
        "gpt-5.1": {"input": 0.005, "output": 0.015},
        "gpt-5.1-2024-05-13": {"input": 0.005, "output": 0.015},
        # gpt-5.1-mini
        "gpt-5.1-mini": {"input": 0.00015, "output": 0.0006},
        "gpt-5.1-mini-2024-07-18": {"input": 0.00015, "output": 0.0006},
        # Embeddings
        "text-embedding-3-large": {"input": 0.00013, "output": 0.0},  # Only input
        "text-embedding-3-small": {"input": 0.00002, "output": 0.0},
        "text-embedding-ada-002": {"input": 0.0001, "output": 0.0},
    }

    # Anthropic pricing (USD per 1K tokens)
    ANTHROPIC_COSTS = {
        # Claude 3 Opus
        "claude-3-opus": {"input": 0.015, "output": 0.075},
        "claude-3-opus-20240229": {"input": 0.015, "output": 0.075},
        # Claude 3 Sonnet
        "claude-3-sonnet": {"input": 0.003, "output": 0.015},
        "claude-3-sonnet-20240229": {"input": 0.003, "output": 0.015},
        # Claude 3 Haiku
        "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
        "claude-3-haiku-20240307": {"input": 0.00025, "output": 0.00125},
        # Claude 2.1
        "claude-2.1": {"input": 0.008, "output": 0.024},
        # Claude 2.0
        "claude-2.0": {"input": 0.008, "output": 0.024},
        # Claude Instant
        "claude-instant": {"input": 0.0008, "output": 0.0024},
        "claude-instant-2023-11-30": {"input": 0.0008, "output": 0.0024},
    }

    # Google Gemini pricing (USD per 1K tokens)
    GOOGLE_COSTS = {
        # Gemini 1.5 Pro
        "gemini-1.5-pro": {"input": 0.0035, "output": 0.0105},
        "gemini-1.5-pro-latest": {"input": 0.0035, "output": 0.0105},
        # Gemini 1.5 Flash
        "gemini-1.5-flash": {"input": 0.000075, "output": 0.0003},
        "gemini-1.5-flash-latest": {"input": 0.000075, "output": 0.0003},
        # Gemini 1.0 Pro
        "gemini-pro": {"input": 0.000125, "output": 0.000375},
        "gemini-pro-001": {"input": 0.000125, "output": 0.000375},
        # Gemini 1.0 Pro Vision
        "gemini-pro-vision": {"input": 0.000125, "output": 0.000375},
        # Gemini Ultra
        "gemini-ultra": {"input": 0.007, "output": 0.021},
    }

    # Ollama (self-hosted, no cost)
    OLLAMA_COSTS = {
        "llama2": {"input": 0.0, "output": 0.0},
        "llama3": {"input": 0.0, "output": 0.0},
        "llama3.1": {"input": 0.0, "output": 0.0},
        "mistral": {"input": 0.0, "output": 0.0},
        "mixtral": {"input": 0.0, "output": 0.0},
        "codellama": {"input": 0.0, "output": 0.0},
        "default": {"input": 0.0, "output": 0.0},
    }

    # LM Studio (self-hosted, no cost)
    LM_STUDIO_COSTS = {
        "default": {"input": 0.0, "output": 0.0},
    }

    def __init__(self):
        """Initialize cost calculator"""
        # Build lookup table for faster access
        self._costs = {
            "openai": self.OPENAI_COSTS,
            "anthropic": self.ANTHROPIC_COSTS,
            "google": self.GOOGLE_COSTS,
            "ollama": self.OLLAMA_COSTS,
            "lm_studio": self.LM_STUDIO_COSTS,
        }

    def calculate(self, provider: str, model: str, input_tokens: int, output_tokens: int) -> float:
        """
        Calculate the cost of an LLM request.

        Args:
            provider: LLM provider (openai, anthropic, google, ollama, lm_studio)
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens

        Returns:
            Cost in USD
        """
        provider_lower = provider.lower()

        if provider_lower not in self._costs:
            # Unknown provider, assume no cost
            return 0.0

        model_costs = self._costs[provider_lower]

        # Try exact model match first
        if model in model_costs:
            rates = model_costs[model]
        else:
            # Try prefix match (e.g., "gpt-4" matches "gpt-4-turbo")
            rates = None
            for known_model, cost in model_costs.items():
                if model.startswith(known_model) or known_model.startswith(model):
                    rates = cost
                    break

            if rates is None:
                # Use default or unknown model pricing
                if "default" in model_costs:
                    rates = model_costs["default"]
                else:
                    # Assume no cost for unknown models
                    return 0.0

        # Calculate cost
        input_cost = (input_tokens / 1000) * rates["input"]
        output_cost = (output_tokens / 1000) * rates["output"]

        return round(input_cost + output_cost, 6)

    def get_cost_breakdown(
        self, provider: str, model: str, input_tokens: int, output_tokens: int
    ) -> Dict[str, float]:
        """
        Get detailed cost breakdown.

        Args:
            provider: LLM provider
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens

        Returns:
            Dictionary with cost breakdown
        """
        provider_lower = provider.lower()

        if provider_lower not in self._costs:
            return {
                "provider": provider,
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "input_cost_usd": 0.0,
                "output_cost_usd": 0.0,
                "total_cost_usd": 0.0,
            }

        model_costs = self._costs[provider_lower]

        if model in model_costs:
            rates = model_costs[model]
        else:
            rates = model_costs.get("default", {"input": 0.0, "output": 0.0})

        input_cost = (input_tokens / 1000) * rates["input"]
        output_cost = (output_tokens / 1000) * rates["output"]

        return {
            "provider": provider,
            "model": model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "input_rate_per_1k": rates["input"],
            "output_rate_per_1k": rates["output"],
            "input_cost_usd": round(input_cost, 6),
            "output_cost_usd": round(output_cost, 6),
            "total_cost_usd": round(input_cost + output_cost, 6),
        }

    def get_supported_models(self, provider: str) -> list:
        """
        Get list of supported models for a provider.

        Args:
            provider: LLM provider name

        Returns:
            List of model names
        """
        provider_lower = provider.lower()

        if provider_lower not in self._costs:
            return []

        return list(self._costs[provider_lower].keys())

    def get_provider_rates(self, provider: str, model: str) -> Optional[Dict[str, float]]:
        """
        Get pricing rates for a specific model.

        Args:
            provider: LLM provider name
            model: Model name

        Returns:
            Dictionary with input/output rates per 1K tokens, or None
        """
        provider_lower = provider.lower()

        if provider_lower not in self._costs:
            return None

        model_costs = self._costs[provider_lower]

        if model in model_costs:
            return model_costs[model]

        # Try prefix match
        for known_model, rates in model_costs.items():
            if model.startswith(known_model) or known_model.startswith(model):
                return rates

        return model_costs.get("default")
