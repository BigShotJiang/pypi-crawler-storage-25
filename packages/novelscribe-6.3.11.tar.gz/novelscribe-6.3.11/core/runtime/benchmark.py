"""Benchmarking framework for parallel subagent execution."""

from __future__ import annotations

import asyncio
import statistics
import time
from dataclasses import dataclass, field
from typing import Any

from .parallel_runner import ParallelRunner


@dataclass
class BenchmarkConfig:
    """Configuration for a parallel subagent benchmark run."""

    agent_count: int = 8
    latency_seconds: float = 0.5
    concurrency_levels: list[int] = field(default_factory=lambda: [1, 2, 4, 8])
    iterations: int = 3
    timeout_per_agent: float = 60.0


@dataclass
class BenchmarkResult:
    """Benchmark result for one concurrency level."""

    concurrency: int
    wall_time: float
    throughput: float
    speedup: float
    overhead_pct: float
    per_agent_durations: list[float] = field(default_factory=list)
    mean: float = 0.0
    median: float = 0.0
    stddev: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "concurrency": self.concurrency,
            "wall_time": round(self.wall_time, 3),
            "throughput": round(self.throughput, 3),
            "speedup": round(self.speedup, 2),
            "overhead_pct": round(self.overhead_pct, 2),
            "per_agent_durations": [round(d, 3) for d in self.per_agent_durations],
            "mean": round(self.mean, 3),
            "median": round(self.median, 3),
            "stddev": round(self.stddev, 3),
        }


@dataclass
class BenchmarkReport:
    """Full benchmark report with baseline and per-level results."""

    config: dict[str, Any]
    sequential_baseline: float
    parallel_results: list[dict[str, Any]] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "config": self.config,
            "sequential_baseline": round(self.sequential_baseline, 3),
            "parallel_results": self.parallel_results,
            "summary": self.summary,
        }

    def to_json(self) -> str:
        import json

        return json.dumps(self.to_dict(), indent=2)


class SyntheticAgent:
    """Simulated async subagent for benchmarking.

    Produces configurable artificial latency to model LLM call overhead.
    """

    def __init__(self, name: str, latency: float) -> None:
        self.name = name
        self.latency = latency

    async def run(self) -> dict[str, Any]:
        """Simulate a subagent execution with artificial latency."""
        await asyncio.sleep(self.latency)
        return {
            "agent": self.name,
            "latency": self.latency,
            "status": "ok",
        }


class SubagentBenchmark:
    """Orchestrates parallel subagent benchmark runs.

    Measures sequential baseline and parallel sweep across multiple concurrency
    levels with iteration averaging.
    """

    def __init__(self, config: BenchmarkConfig) -> None:
        self.config = config

    async def run(self) -> BenchmarkReport:
        """Run the full benchmark suite.

        Executes sequential baseline first, then parallel sweeps for each
        concurrency level. Returns a BenchmarkReport with aggregated statistics.
        """
        agent_count = self.config.agent_count
        latency = self.config.latency_seconds
        concurrency_levels = self.config.concurrency_levels
        iterations = self.config.iterations

        sequential_wall = await self._run_sequential(agent_count, latency)
        parallel_results: list[dict[str, Any]] = []
        max_speedup = 0.0
        best_concurrency = 1

        for level in concurrency_levels:
            result = await self._run_parallel_sweep(agent_count, latency, level, iterations)
            parallel_results.append(result.to_dict())
            if result.speedup > max_speedup:
                max_speedup = result.speedup
                best_concurrency = level

        summary = {
            "sequential_total": round(sequential_wall, 3),
            "max_speedup": round(max_speedup, 2),
            "best_concurrency": best_concurrency,
            "best_speedup_concurrency": best_concurrency,
            "levels_tested": len(concurrency_levels),
            "total_agents": agent_count,
            "iterations_per_level": iterations,
        }

        return BenchmarkReport(
            config={
                "agent_count": agent_count,
                "latency_seconds": latency,
                "concurrency_levels": concurrency_levels,
                "iterations": iterations,
            },
            sequential_baseline=sequential_wall,
            parallel_results=parallel_results,
            summary=summary,
        )

    async def _run_sequential(self, agent_count: int, latency: float) -> float:
        """Run N agents sequentially and measure wall-clock time."""
        start = time.monotonic()
        for i in range(agent_count):
            agent = SyntheticAgent(name=f"agent-{i}", latency=latency)
            await agent.run()
        return time.monotonic() - start

    async def _run_parallel_sweep(
        self,
        agent_count: int,
        latency: float,
        concurrency: int,
        iterations: int,
    ) -> BenchmarkResult:
        """Run parallel sweep for one concurrency level across multiple iterations."""
        runner = ParallelRunner(concurrency_limit=concurrency)
        wall_times: list[float] = []
        all_durations: list[float] = []

        for i in range(iterations):
            agents = [
                SyntheticAgent(name=f"agent-{j}", latency=latency) for j in range(agent_count)
            ]
            tasks = [agent.run() for agent in agents]

            start = time.monotonic()
            result = await runner.run(tasks, project_name="benchmark")
            wall_time = time.monotonic() - start

            wall_times.append(wall_time)
            all_durations.extend([o.duration for o in result.completed])

        mean_wall = statistics.mean(wall_times)
        median_wall = statistics.median(wall_times)
        stddev_wall = statistics.stdev(wall_times) if len(wall_times) > 1 else 0.0
        throughput = agent_count / mean_wall if mean_wall > 0 else 0.0
        overhead_pct = (
            ((mean_wall * concurrency) / (agent_count * latency) - 1) * 100
            if agent_count > 0
            else 0.0
        )

        seq_median = agent_count * latency
        speedup = seq_median / median_wall if median_wall > 0 else 1.0

        return BenchmarkResult(
            concurrency=concurrency,
            wall_time=mean_wall,
            throughput=throughput,
            speedup=speedup,
            overhead_pct=max(0.0, overhead_pct),
            per_agent_durations=all_durations,
            mean=mean_wall,
            median=median_wall,
            stddev=stddev_wall,
        )
