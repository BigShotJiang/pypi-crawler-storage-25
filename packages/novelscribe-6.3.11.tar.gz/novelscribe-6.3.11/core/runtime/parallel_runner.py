"""Parallel subagent execution runner with concurrency control and error isolation."""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from core.streaming.event_bus import PipelineEventBus


__all__ = [
    "ParallelRunner",
    "ConcurrencyLimiter",
    "ErrorIsolator",
    "ParallelResult",
    "SubagentOutcome",
]


@dataclass
class SubagentOutcome:
    """Outcome of a single subagent run within a parallel execution."""

    task_name: str
    success: bool
    output: str | None = None
    error: str | None = None
    duration: float = 0.0
    error_type: str | None = None


@dataclass
class ParallelResult:
    """Aggregated result from parallel subagent execution."""

    success: bool
    total_duration: float
    completed: list[SubagentOutcome] = field(default_factory=list)
    failed: list[SubagentOutcome] = field(default_factory=list)
    skipped: list[SubagentOutcome] = field(default_factory=list)
    speedup: float = 1.0
    total_agents: int = 0
    total_completed: int = 0
    total_failed: int = 0

    def summary(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "total_duration": self.total_duration,
            "speedup": self.speedup,
            "total_agents": self.total_agents,
            "completed": self.total_completed,
            "failed": self.total_failed,
        }


class ConcurrencyLimiter:
    """Semaphore-based concurrent task limiter.

    Wraps an asyncio.Semaphore to limit how many subagents run concurrently.
    Used as an async context manager within a `ParallelRunner`.
    """

    def __init__(self, max_concurrent: int = 3) -> None:
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._max_concurrent = max_concurrent

    @property
    def max_concurrent(self) -> int:
        return self._max_concurrent

    async def __aenter__(self) -> None:
        await self._semaphore.acquire()

    async def __aexit__(self, *args: Any) -> None:
        self._semaphore.release()


class ErrorIsolator:
    """Wraps subagent execution with per-agent error isolation.

    Ensures that failures in one subagent don't cascade to others.
    Captures exceptions and returns them as structured error outcomes.
    """

    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._logger = logger or logging.getLogger("scribe")

    async def run(
        self,
        task_name: str,
        coro: Any,
        timeout: float | None = None,
    ) -> SubagentOutcome:
        """Execute a coroutine and return outcome, catching all exceptions.

        Args:
            task_name: Identifier for logging
            coro: The coroutine to execute
            timeout: Optional timeout in seconds

        Returns:
            SubagentOutcome with success=True and output, or success=False and error
        """
        start = time.monotonic()
        try:
            if timeout:
                result = await asyncio.wait_for(coro, timeout=timeout)
            else:
                result = await coro
            duration = time.monotonic() - start
            return SubagentOutcome(
                task_name=task_name,
                success=True,
                output=str(result) if result else None,
                duration=duration,
            )
        except asyncio.TimeoutError:
            duration = time.monotonic() - start
            self._logger.warning(f"Subagent '{task_name}' timed out after {timeout}s")
            return SubagentOutcome(
                task_name=task_name,
                success=False,
                error=f"Timed out after {timeout}s",
                duration=duration,
                error_type="TimeoutError",
            )
        except Exception as e:  # noqa: BLE001
            duration = time.monotonic() - start
            error_type = type(e).__name__
            self._logger.error(f"Subagent '{task_name}' failed: {error_type}: {e}")
            return SubagentOutcome(
                task_name=task_name,
                success=False,
                error=str(e),
                duration=duration,
                error_type=error_type,
            )


class ParallelRunner:
    """Orchestrates parallel subagent execution with concurrency control.

    Runs multiple subagents concurrently using asyncio.gather, with a
    configurable concurrency limit to avoid overwhelming the LLM provider.
    Each subagent is wrapped in ErrorIsolator so failures are isolated.

    Usage::

        runner = ParallelRunner(concurrency_limit=3, event_bus=event_bus)
        result = await runner.run(subagent_configs, project_name="my-novel")
        for outcome in result.completed:
            print(f"{outcome.task_name}: {outcome.output}")
    """

    def __init__(
        self,
        concurrency_limit: int = 3,
        event_bus: PipelineEventBus | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self._concurrency_limit = concurrency_limit
        self._event_bus = event_bus
        self._logger = logger or logging.getLogger("scribe")
        self._limiter = ConcurrencyLimiter(max_concurrent=concurrency_limit)
        self._isolator = ErrorIsolator(self._logger)

    async def run(
        self,
        subagent_tasks: list[Any],
        project_name: str,
        timeout_per_agent: float | None = None,
    ) -> ParallelResult:
        """Run subagents in parallel with concurrency control.

        Args:
            subagent_tasks: List of coroutines to execute concurrently
            project_name: Project name for event bus emission
            timeout_per_agent: Optional timeout for each agent (seconds)

        Returns:
            ParallelResult with all outcomes and aggregated metrics
        """
        if not subagent_tasks:
            return ParallelResult(
                success=True,
                total_duration=0.0,
                total_agents=0,
                total_completed=0,
                total_failed=0,
            )

        start = time.monotonic()

        async def _wrap_task(
            task_name: str,
            coro_or_callable: Any,
        ) -> SubagentOutcome:
            async def _run_with_semaphore() -> SubagentOutcome:
                async with self._limiter:
                    resolved_coro = (
                        coro_or_callable
                        if asyncio.iscoroutine(coro_or_callable)
                        else coro_or_callable()
                    )
                    return await self._isolator.run(task_name, resolved_coro, timeout_per_agent)

            return await _run_with_semaphore()

        task_names: list[str] = [
            f"subagent-{i}" if not hasattr(t, "name") else t.name
            for i, t in enumerate(subagent_tasks)
        ]

        results: list[SubagentOutcome] = await asyncio.gather(
            *[_wrap_task(name, task) for name, task in zip(task_names, subagent_tasks)],
            return_exceptions=False,
        )

        total_duration = time.monotonic() - start

        completed: list[SubagentOutcome] = [r for r in results if r.success]
        failed: list[SubagentOutcome] = [r for r in results if not r.success]

        overall_success = len(failed) == 0

        sequential_estimate = sum(r.duration for r in results)
        speedup = sequential_estimate / total_duration if total_duration > 0 else 1.0

        return ParallelResult(
            success=overall_success,
            total_duration=total_duration,
            completed=completed,
            failed=failed,
            speedup=speedup,
            total_agents=len(results),
            total_completed=len(completed),
            total_failed=len(failed),
        )

    async def run_with_timeout(
        self,
        subagent_tasks: list[Any],
        project_name: str,
        timeout: float,
    ) -> ParallelResult:
        """Run subagents in parallel with an overall timeout.

        If the overall execution exceeds the timeout, all pending tasks
        are cancelled and the partial results are returned.
        """
        try:
            return await asyncio.wait_for(
                self.run(subagent_tasks, project_name),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            self._logger.warning(f"ParallelRunner timed out after {timeout}s")
            return ParallelResult(
                success=False,
                total_duration=timeout,
                skipped=[
                    SubagentOutcome(
                        task_name=f"subagent-{i}", success=False, error="Overall timeout"
                    )
                    for i in range(len(subagent_tasks))
                ],
                total_agents=len(subagent_tasks),
                total_completed=0,
                total_failed=0,
            )
