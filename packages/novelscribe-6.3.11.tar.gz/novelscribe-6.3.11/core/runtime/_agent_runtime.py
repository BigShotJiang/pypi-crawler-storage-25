"""Minimal Runtime kernel loop implementation.

AgentRuntime implements TurnLoopCallbacks — all business logic lives here,
the loop skeleton is delegated to TurnLoopEngine.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from core.hooks import HookEventBus
from core.llm.client import MultiLLMClient

from ._callbacks import CONTINUE_SENTINEL, TurnLoopCallbacks
from ._turn_loop import TurnLoopEngine
from .guardrails import GuardrailEngine
from .memory_bridge import MemoryBridge
from .models import RuntimeOutcome, RuntimeState, RuntimeTask, RuntimeTurnResult
from .output_parser import RuntimeOutputParser
from .prompt_assembler import PromptAssembler
from .runtime_lifecycle import (
    RuntimeConfig,
    emit_runtime_hook,
    ensure_checkpoint_store,
    load_latest_state,
    resolve_runtime_subscriptions,
    save_checkpoint,
    write_memory,
)

InferFn = Callable[[str, str], str]
_logger = logging.getLogger(__name__)


class AgentRuntime(TurnLoopCallbacks):
    """Runtime kernel that executes a minimal dumb turn loop.

    Business logic is implemented here as TurnLoopCallbacks methods.
    The loop skeleton is delegated to TurnLoopEngine.
    """

    def __init__(
        self,
        infer_fn: InferFn,
        config: RuntimeConfig | None = None,
        **kwargs: Any,
    ) -> None:
        cfg = config or RuntimeConfig()
        for k, v in kwargs.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
        self._infer_fn = infer_fn
        self._prompt_assembler = cfg.prompt_assembler or PromptAssembler()
        self._output_parser = cfg.output_parser or RuntimeOutputParser()
        self._context_bus = cfg.context_bus
        self._memory_bridge = cfg.memory_bridge
        self._tool_registry = cfg.tool_registry
        self._tool_executor = cfg.tool_executor
        self._guardrail_engine = cfg.guardrail_engine
        self._turn_checkpoint_store = cfg.turn_checkpoint_store
        self._verification_suite = cfg.verification_suite
        self._subagent_manager = cfg.subagent_manager
        self._hook_event_bus = cfg.hook_event_bus or HookEventBus()
        self._auto_feedback_enabled = cfg.auto_feedback_enabled
        self._max_feedback_rounds = cfg.max_feedback_rounds
        self._output_adapter: Any | None = None

    @classmethod
    def from_llm_client(
        cls,
        llm_client: MultiLLMClient,
        context_bus: Any | None = None,
        memory_bus: Any | None = None,
    ) -> "AgentRuntime":
        def _infer(system_prompt: str, user_prompt: str) -> str:
            response = llm_client.generate(system_prompt=system_prompt, user_prompt=user_prompt)
            return response.content

        return cls(
            infer_fn=_infer,
            context_bus=context_bus,
            memory_bridge=MemoryBridge(memory_bus) if memory_bus is not None else None,
            guardrail_engine=GuardrailEngine(),
        )

    def run_turn_loop(self, task: RuntimeTask, state: RuntimeState) -> RuntimeOutcome:
        self._turn_checkpoint_store = ensure_checkpoint_store(self._turn_checkpoint_store, task)
        engine = TurnLoopEngine(callbacks=self, checkpoint_store=self._turn_checkpoint_store)
        return engine.execute(task, state)

    def load_latest_turn_state(self, task_id: str) -> RuntimeState | None:
        return load_latest_state(self._turn_checkpoint_store, task_id)

    def run_pre_turn(self, task: RuntimeTask, state: RuntimeState) -> RuntimeOutcome | None:
        from ._pre_turn import run_pre_turn_gate

        result = run_pre_turn_gate(
            task,
            state,
            self._subagent_manager,
            self._guardrail_engine,
            self.emit,
            parent=self,
        )
        return result.outcome

    def save_checkpoint(
        self, phase: str, task: RuntimeTask | None = None, state: RuntimeState | None = None
    ) -> None:
        if task is not None and state is not None:
            save_checkpoint(self._turn_checkpoint_store, task, state, phase)

    def execute_turn(self, task: RuntimeTask, state: RuntimeState) -> tuple[RuntimeTurnResult, str]:
        from ._turn_execution import execute_turn as _exec

        return _exec(
            task,
            state,
            self._infer_fn,
            self._context_bus,
            self._memory_bridge,
            self._prompt_assembler,
            self._output_parser,
            self._tool_registry,
            self.emit,
        )

    def run_post_turn(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
        turns_executed: int,
        feedback_rounds: int,
    ) -> RuntimeOutcome | None | tuple[type[CONTINUE_SENTINEL], int]:
        from ._post_turn import run_post_turn_gate

        return run_post_turn_gate(
            task,
            state,
            final_output,
            turns_executed,
            feedback_rounds,
            self._guardrail_engine,
            self._verification_suite,
            self._auto_feedback_enabled,
            self._max_feedback_rounds,
            self._turn_checkpoint_store,
            self.emit,
        )

    def handle_tool_calls(
        self,
        turn_result: Any,
        task: RuntimeTask,
        state: RuntimeState,
        turns_executed: int,
    ) -> RuntimeOutcome | None:
        from ._tool_coordinator import handle_tool_calls as _handle

        return _handle(
            turn_result,
            task,
            state,
            turns_executed,
            self._tool_executor,
            self._guardrail_engine,
            self._tool_registry,
            self.emit,
        )

    def fail_recoverable(
        self,
        turn_result: Any,
        state: RuntimeState,
        turns_executed: int,
        task: RuntimeTask,
    ) -> RuntimeOutcome:
        from ._tool_coordinator import fail_recoverable as _fail_rec

        return _fail_rec(
            turn_result,
            state,
            turns_executed,
            task,
            self.emit,
        )

    def fail_max_turns(
        self, task: RuntimeTask, state: RuntimeState, turns_executed: int
    ) -> RuntimeOutcome:
        from ._fail_handling import fail_max_turns as _fn

        return _fn(task, state, turns_executed, self.emit)

    def fail_exception(
        self,
        exc: Exception,
        task: RuntimeTask,
        state: RuntimeState,
        turns_executed: int,
    ) -> RuntimeOutcome:
        from ._fail_handling import fail_exception as _fn

        return _fn(exc, task, state, turns_executed, self.emit)

    def write_memory(self, task: RuntimeTask, state: RuntimeState, final_output: str) -> None:
        write_memory(self._memory_bridge, task, state, final_output)

    def emit(
        self, event: str, task: RuntimeTask, state: RuntimeState, metadata: dict[str, Any]
    ) -> None:
        subs = resolve_runtime_subscriptions(task)
        emit_runtime_hook(
            self._hook_event_bus,
            event,
            task,
            state,
            metadata,
            subs,
        )
        if self._output_adapter is not None:
            try:
                self._output_adapter.on_emit(event, metadata)
            except Exception:  # noqa: BLE001
                pass

    def _infer_with_retry(self, sys_p: str, usr_p: str, task: RuntimeTask) -> str:
        from ._turn_execution import _infer_with_retry as _fn

        return _fn(self._infer_fn, sys_p, usr_p, task)

    def _resolve_final_output(self, raw_output: str, turn_result: RuntimeTurnResult) -> str:
        from ._turn_execution import _resolve_final_output as _fn

        return _fn(raw_output, turn_result)
