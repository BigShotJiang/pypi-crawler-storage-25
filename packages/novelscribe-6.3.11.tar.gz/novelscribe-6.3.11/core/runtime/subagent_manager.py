"""Subagent orchestration manager for Runtime mainline integration."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from .models import SubagentBatchResult, SubagentMode, SubagentResult, SubagentTask
from .parallel_runner import ParallelResult, ParallelRunner

SubagentRunner = Callable[[SubagentTask], SubagentResult]


class SubagentManager:
    """Execute Fork/Teammate/Handoff subagent runs and aggregate outputs."""

    def __init__(
        self,
        max_subagents: int = 8,
        parallel_subagents: bool = False,
        concurrency_limit: int = 3,
    ) -> None:
        self._max_subagents = max_subagents
        self._parallel_subagents = parallel_subagents
        self._concurrency_limit = concurrency_limit

    def parse_tasks(self, payload: object) -> list[SubagentTask]:
        """Parse raw subagent payload into typed tasks."""
        if not isinstance(payload, list):
            return []
        tasks: list[SubagentTask] = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            tasks.append(SubagentTask(**item))
        return tasks[: self._max_subagents]

    def execute(self, tasks: list[SubagentTask], runner: SubagentRunner) -> SubagentBatchResult:
        """Run subagents and aggregate protocol-compliant orchestration outputs."""
        batch = SubagentBatchResult()
        for task in tasks:
            result = runner(task)
            batch.records.append(result)

            if task.mode == SubagentMode.TEAMMATE and result.final_output:
                batch.teammate_notes.append(f"[{task.name}] {result.final_output}")

            if task.mode == SubagentMode.HANDOFF and result.success:
                batch.handoff_output = result.final_output
                break
        return batch

    async def run_independent(
        self,
        subagent_tasks: list[Any],
        config: Any,
    ) -> list[str]:
        """Run INDEPENDENT subagents in parallel or sequentially.

        When parallel_subagents is True (from config), uses ParallelRunner
        with asyncio.gather and concurrency limiting. When False (default),
        runs sequentially for backward compatibility.

        Args:
            subagent_tasks: List of tasks or coroutines to execute
            config: RuntimeConfig with parallel_subagents and concurrency_limit

        Returns:
            List of output strings from successful subagent runs
        """
        if not subagent_tasks:
            return []

        parallel = (
            getattr(config, "parallel_subagents", False) if config else self._parallel_subagents
        )
        limit = (
            getattr(config, "concurrency_limit", self._concurrency_limit)
            if config
            else self._concurrency_limit
        )

        if parallel:
            runner = ParallelRunner(concurrency_limit=limit)
            project = getattr(config, "project_name", "default") if config else "default"
            result: ParallelResult = await runner.run(subagent_tasks, project)
            return [r.output for r in result.completed if r.output]
        else:
            outputs: list[str] = []
            for task in subagent_tasks:
                try:
                    if asyncio.iscoroutine(task):
                        output = await task
                    elif callable(task):
                        output = task()
                        if asyncio.iscoroutine(output):
                            output = await output
                    else:
                        output = str(task)
                    if output:
                        outputs.append(str(output))
                except Exception:  # noqa: BLE001
                    pass
            return outputs
