"""Context Compressor — progressive compression guaranteeing token-fit.

Applies compression tiers in escalating order: NONE → TRUNCATE → EXTRACT → SUMMARIZE.
Non-compressible blocks (meta, outline) are never modified or dropped.
"""

from __future__ import annotations

import logging
import re
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from core.llm.estimator import TokenEstimator

from .assembly import ContextBlock
from .relevance_scorer import select_blocks_for_budget
from .schema import TokenBudget

logger = logging.getLogger(__name__)


class CompressionTier(str, Enum):
    """Progressive compression tiers."""

    NONE = "none"
    TRUNCATE = "truncate"
    EXTRACT = "extract"
    SUMMARIZE = "summarize"


class CompressionResult(BaseModel):
    """Result of a compression operation."""

    context_str: str = Field(..., description="Final compressed context string")
    original_tokens: int = Field(..., ge=0, description="Total tokens before compression")
    compressed_tokens: int = Field(..., ge=0, description="Total tokens after compression")
    tier_used: CompressionTier = Field(..., description="Highest compression tier applied")
    blocks_dropped: int = Field(default=0, description="Blocks removed entirely")
    blocks_truncated: int = Field(default=0, description="Blocks truncated")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional compression metadata"
    )


class ContextCompressor:
    """Progressive context compressor that guarantees token budget fit.

    Tiers:
    1. NONE — context fits as-is, no changes needed
    2. TRUNCATE — cut compressible blocks from bottom, lowest priority first
    3. EXTRACT — keep only key elements from oldest compressible blocks
    4. SUMMARIZE — LLM-based semantic compression (last resort)
    """

    def __init__(self, llm_client: Optional[Any] = None):
        """Initialize compressor.

        Args:
            llm_client: Optional LLM client for SUMMARIZE tier.
                        If None, SUMMARIZE tier is skipped.
        """
        self.llm_client = llm_client
        self._task_description = ""

    def compress(
        self,
        blocks: List[ContextBlock],
        budget: TokenBudget,
        task_description: Optional[str] = None,
    ) -> CompressionResult:
        """Compress context blocks to fit within token budget.

        Guarantee: result.context_str token_count <= budget.available_for_input

        Args:
            blocks: Context blocks to compress.
            budget: Token budget constraint.
            task_description: Optional task description for relevance scoring.
        """
        self._task_description = task_description or ""
        if not blocks:
            return CompressionResult(
                context_str="",
                original_tokens=0,
                compressed_tokens=0,
                tier_used=CompressionTier.NONE,
            )

        total_tokens = sum(b.token_count for b in blocks)

        if total_tokens <= budget.available_for_input:
            context_str = self._concatenate(blocks)
            compressed_tokens = TokenEstimator.estimate_tokens(context_str)
            return CompressionResult(
                context_str=context_str,
                original_tokens=total_tokens,
                compressed_tokens=compressed_tokens,
                tier_used=CompressionTier.NONE,
                metadata={
                    "block_count": len(blocks),
                    "sources": [b.source for b in blocks],
                },
            )

        working = [self._copy_block(b) for b in blocks]
        dropped = 0
        truncated = 0

        working, d, t = self._apply_truncate(working, budget)
        dropped += d
        truncated += t
        tier = CompressionTier.TRUNCATE

        total = sum(b.token_count for b in working)
        if total <= budget.available_for_input:
            return self._build_result(working, total_tokens, tier, dropped, truncated, budget)

        working, d, t = self._apply_extract(working, budget)
        dropped += d
        truncated += t
        tier = CompressionTier.EXTRACT

        total = sum(b.token_count for b in working)
        if total <= budget.available_for_input:
            return self._build_result(working, total_tokens, tier, dropped, truncated, budget)

        if self.llm_client is not None:
            working, d, t = self._apply_summarize(working, budget)
            dropped += d
            truncated += t
            tier = CompressionTier.SUMMARIZE

            total = sum(b.token_count for b in working)
            if total <= budget.available_for_input:
                return self._build_result(working, total_tokens, tier, dropped, truncated, budget)

        working = self._force_fit(working, budget)
        return self._build_result(
            working,
            total_tokens,
            tier or CompressionTier.TRUNCATE,
            dropped,
            truncated,
            budget,
        )

    def _apply_truncate(
        self,
        blocks: List[ContextBlock],
        budget: TokenBudget,
    ) -> tuple[List[ContextBlock], int, int]:
        """Truncate compressible blocks, using relevance scoring when available."""
        dropped = 0
        truncated = 0

        frozen_tokens = sum(b.token_count for b in blocks if not b.compressible)
        target = budget.available_for_input - frozen_tokens
        if target < 0:
            return blocks, dropped, truncated

        non_compressible = [b for b in blocks if not b.compressible]

        if self._task_description:
            selected, dropped_blocks = select_blocks_for_budget(
                blocks, self._task_description, budget.available_for_input
            )
            dropped = len(dropped_blocks)
            total = sum(b.token_count for b in selected)
            if total <= budget.available_for_input:
                return selected, dropped, truncated

            compressible = [b for b in selected if b.compressible]
        else:
            compressible = [b for b in blocks if b.compressible]
            compressible.sort(key=lambda b: (-b.priority, b.token_count), reverse=True)

        kept: List[ContextBlock] = []
        used_tokens = frozen_tokens

        for block in compressible:
            remaining = budget.available_for_input - used_tokens
            if remaining <= 0:
                dropped += 1
                continue

            if block.token_count <= remaining:
                kept.append(block)
                used_tokens += block.token_count
            else:
                truncated_content = self._truncate_block(block, remaining)
                new_tokens = TokenEstimator.estimate_tokens(truncated_content)
                kept.append(
                    ContextBlock(
                        source=block.source,
                        priority=block.priority,
                        content=truncated_content,
                        token_count=new_tokens,
                        compressible=True,
                        label=block.label,
                    )
                )
                used_tokens += new_tokens
                truncated += 1

        result = non_compressible + kept
        return result, dropped, truncated

    def _apply_extract(
        self,
        blocks: List[ContextBlock],
        budget: TokenBudget,
    ) -> tuple[List[ContextBlock], int, int]:
        """Extract key elements from compressible blocks that are still over budget."""
        dropped = 0
        truncated = 0
        result: List[ContextBlock] = []

        total = sum(b.token_count for b in blocks)
        if total <= budget.available_for_input:
            return blocks, dropped, truncated

        overage = total - budget.available_for_input

        for block in blocks:
            if not block.compressible:
                result.append(block)
                continue

            if overage <= 0:
                result.append(block)
                continue

            extracted = self._extract_key_elements(block.content)
            new_tokens = TokenEstimator.estimate_tokens(extracted)
            saved = block.token_count - new_tokens
            if saved > 0:
                overage -= saved
                result.append(
                    ContextBlock(
                        source=block.source,
                        priority=block.priority,
                        content=extracted,
                        token_count=new_tokens,
                        compressible=True,
                        label=f"{block.label} [extracted]",
                    )
                )
                truncated += 1
            else:
                result.append(block)

        return result, dropped, truncated

    def _apply_summarize(
        self,
        blocks: List[ContextBlock],
        budget: TokenBudget,
    ) -> tuple[List[ContextBlock], int, int]:
        """Use LLM to semantically compress remaining over-budget content."""
        if self.llm_client is None:
            return blocks, 0, 0

        dropped = 0
        truncated = 0
        result: List[ContextBlock] = []

        total = sum(b.token_count for b in blocks)
        if total <= budget.available_for_input:
            return blocks, dropped, truncated

        compressible = [b for b in blocks if b.compressible]
        non_compressible = [b for b in blocks if not b.compressible]

        combined = "\n\n".join(b.content for b in compressible)
        target_tokens = budget.available_for_input - sum(b.token_count for b in non_compressible)

        if target_tokens <= 0:
            return non_compressible, len(compressible), 0

        summarized = self._summarize_via_llm(combined, target_tokens)
        new_tokens = TokenEstimator.estimate_tokens(summarized)

        result.extend(non_compressible)
        if summarized:
            result.append(
                ContextBlock(
                    source="compressed",
                    priority=1,
                    content=summarized,
                    token_count=new_tokens,
                    compressible=False,
                    label="[LLM summarized]",
                )
            )
            truncated = len(compressible)
        else:
            dropped = len(compressible)

        return result, dropped, truncated

    def _truncate_block(self, block: ContextBlock, target_tokens: int) -> str:
        """Truncate a single block to approximately target_tokens.

        Applies a 10% safety margin to account for token estimation
        approximation.
        """
        content = block.content
        if not content:
            return content

        safe_target = int(target_tokens * 0.9)
        estimated = TokenEstimator.estimate_tokens(content)
        if estimated <= safe_target:
            return content

        char_ratio = safe_target / estimated
        target_chars = int(len(content) * char_ratio)

        truncated = content[:target_chars]
        last_newline = truncated.rfind("\n")
        if last_newline > target_chars // 2:
            truncated = truncated[:last_newline]

        return truncated

    def _extract_key_elements(self, content: str) -> str:
        """Extract key narrative elements from content.

        Uses regex-based extraction — no LLM needed.
        """
        if not content:
            return ""

        lines = content.split("\n")
        key_lines: list[str] = []

        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue

            if stripped.startswith("#"):
                key_lines.append(stripped)
                continue

            if re.match(r"^[-•*]\s", stripped):
                key_lines.append(stripped)
                continue

            if re.match(r"^[A-Z][a-z]+(?:\s[A-Z][a-z]+)*:", stripped):
                key_lines.append(stripped)
                continue

            if re.search(
                r"\b(?:died|killed|married|betrayed|discovered|arrived|left|became|revealed)\b",
                stripped,
                re.IGNORECASE,
            ):
                key_lines.append(stripped)
                continue

            if re.search(r'["\u201c].*?["\u201d]', stripped):
                key_lines.append(stripped)
                continue

        if not key_lines:
            sentences = re.split(r"(?<=[.!?])\s+", content)
            step = max(1, len(sentences) // 5)
            key_lines = sentences[::step]

        return "\n".join(key_lines)

    def _summarize_via_llm(self, content: str, target_tokens: int) -> str:
        """Use LLM to compress content to target token count."""
        if self.llm_client is None or not content:
            return content

        try:
            system_prompt = (
                "You are a context compression assistant. "
                "Compress the following content while preserving all key information: "
                "character names, plot points, locations, relationships, and events. "
                f"Target length: approximately {target_tokens} tokens. "
                "Be concise but complete."
            )
            response = self.llm_client.generate(
                system_prompt=system_prompt,
                user_prompt=content,
            )
            return response.content
        except Exception:
            logger.warning("LLM summarization failed, falling back to extraction")
            return self._extract_key_elements(content)

    def _force_fit(self, blocks: List[ContextBlock], budget: TokenBudget) -> List[ContextBlock]:
        """Last resort: aggressively truncate everything that's compressible."""
        non_compressible = [b for b in blocks if not b.compressible]
        compressible = [b for b in blocks if b.compressible]

        frozen_tokens = sum(b.token_count for b in non_compressible)
        remaining_budget = max(0, budget.available_for_input - frozen_tokens)

        if remaining_budget <= 0 or not compressible:
            return non_compressible

        per_block = remaining_budget // max(1, len(compressible))
        result = list(non_compressible)

        for block in compressible:
            if per_block > 0:
                truncated = self._truncate_block(block, per_block)
                new_tokens = TokenEstimator.estimate_tokens(truncated)
                result.append(
                    ContextBlock(
                        source=block.source,
                        priority=block.priority,
                        content=truncated,
                        token_count=new_tokens,
                        compressible=True,
                        label=block.label,
                    )
                )

        return result

    def _concatenate(self, blocks: List[ContextBlock]) -> str:
        """Concatenate block contents with section headers."""
        parts: list[str] = []
        for block in blocks:
            header = f"## {block.label}\n" if block.label else ""
            parts.append(f"{header}{block.content}")
        return "\n\n".join(parts)

    def _copy_block(self, block: ContextBlock) -> ContextBlock:
        """Create a copy of a ContextBlock."""
        return ContextBlock(
            source=block.source,
            priority=block.priority,
            content=block.content,
            token_count=block.token_count,
            compressible=block.compressible,
            label=block.label,
        )

    def _build_result(
        self,
        blocks: List[ContextBlock],
        original_tokens: int,
        tier: CompressionTier,
        dropped: int,
        truncated: int,
        budget: Optional[TokenBudget] = None,
    ) -> CompressionResult:
        """Build CompressionResult from processed blocks."""
        context_str = self._concatenate(blocks)
        compressed_tokens = TokenEstimator.estimate_tokens(context_str)

        if budget is not None and compressed_tokens > budget.available_for_input:
            safe_chars = int(
                len(context_str) * budget.available_for_input / compressed_tokens * 0.9
            )
            context_str = context_str[:safe_chars]
            compressed_tokens = TokenEstimator.estimate_tokens(context_str)

        return CompressionResult(
            context_str=context_str,
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            tier_used=tier,
            blocks_dropped=dropped,
            blocks_truncated=truncated,
            metadata={
                "block_count": len(blocks),
                "sources": [b.source for b in blocks],
            },
        )
