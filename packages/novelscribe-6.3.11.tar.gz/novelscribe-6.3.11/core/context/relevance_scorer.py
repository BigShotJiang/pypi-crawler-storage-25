"""Relevance Scorer — rank context blocks by semantic similarity to the task.

Uses keyword overlap and structural signals to score blocks without
requiring an embedding model. Fast enough to run on every compression pass.
"""

from __future__ import annotations

import re
from typing import List, Set

from .assembly import ContextBlock


def _tokenize(text: str) -> Set[str]:
    """Lowercase, strip punctuation, split into word set."""
    words = re.findall(r"[a-zA-Z\u4e00-\u9fff]+", text.lower())
    return set(words)


_STOP_WORDS = frozenset(
    {
        "the",
        "a",
        "an",
        "and",
        "or",
        "but",
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "with",
        "by",
        "from",
        "is",
        "it",
        "this",
        "that",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "shall",
        "can",
        "not",
        "no",
        "nor",
        "so",
        "if",
        "then",
        "than",
        "too",
        "very",
        "just",
        "about",
        "also",
        "into",
        "out",
        "up",
        "down",
        "over",
        "under",
    }
)


def _content_tokens(text: str) -> Set[str]:
    """Tokenize and remove stop words."""
    return _tokenize(text) - _STOP_WORDS


def score_relevance(block: ContextBlock, task_description: str) -> float:
    """Score a context block's relevance to a task description.

    Uses a combination of:
    - Keyword overlap (Jaccard-like)
    - Named entity overlap (capitalized words)
    - Section header match

    Returns a float in [0, 1] where 1 = perfectly relevant.
    """
    if not task_description or not block.content:
        return 0.5

    task_words = _content_tokens(task_description)
    block_words = _content_tokens(block.content)

    if not task_words or not block_words:
        return 0.5

    overlap = task_words & block_words
    union = task_words | block_words
    jaccard = len(overlap) / len(union) if union else 0.0

    task_entities = {w for w in _tokenize(task_description) if w[0].isupper() and len(w) > 1}
    block_entities = {w for w in _tokenize(block.content) if w[0].isupper() and len(w) > 1}
    entity_overlap = task_entities & block_entities
    entity_score = len(entity_overlap) / max(len(task_entities), 1)

    label_words = _content_tokens(block.label) if block.label else set()
    label_match = len(label_words & task_words) / max(len(task_words), 1) if label_words else 0.0

    score = 0.5 * jaccard + 0.35 * entity_score + 0.15 * label_match
    return min(1.0, score)


def rank_blocks_by_relevance(
    blocks: List[ContextBlock],
    task_description: str,
) -> List[tuple[ContextBlock, float]]:
    """Rank context blocks by relevance to a task.

    Returns list of (block, score) tuples sorted by score descending.
    Blocks with higher scores should be kept preferentially during compression.
    """
    scored = [(block, score_relevance(block, task_description)) for block in blocks]
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored


def select_blocks_for_budget(
    blocks: List[ContextBlock],
    task_description: str,
    token_budget: int,
) -> tuple[List[ContextBlock], List[ContextBlock]]:
    """Select the most relevant blocks that fit within a token budget.

    Returns (selected_blocks, dropped_blocks).
    Non-compressible blocks are always included regardless of relevance.
    """
    ranked = rank_blocks_by_relevance(blocks, task_description)

    non_compressible = [(b, s) for b, s in ranked if not b.compressible]
    compressible = [(b, s) for b, s in ranked if b.compressible]

    selected: List[ContextBlock] = []
    used_tokens = 0

    for block, _score in non_compressible:
        selected.append(block)
        used_tokens += block.token_count

    for block, score in compressible:
        if used_tokens + block.token_count <= token_budget:
            selected.append(block)
            used_tokens += block.token_count

    selected_set = {id(b) for b in selected}
    dropped = [b for b in blocks if id(b) not in selected_set]

    return selected, dropped
