"""Budget Report — observability for context budget allocation and usage."""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class BudgetReport(BaseModel):
    """Report on context budget allocation and usage for a single build_context call."""

    agent_name: str = Field(..., description="Agent that requested context")
    provider: str = Field(default="unknown", description="LLM provider")
    budget_allocated: int = Field(..., ge=0, description="Total tokens allocated")
    tokens_assembled: int = Field(
        ..., ge=0, description="Tokens after assembly (before compression)"
    )
    tokens_final: int = Field(..., ge=0, description="Tokens after compression (final)")
    compression_ratio: float = Field(..., ge=0, description="tokens_final / budget_allocated")
    tier_used: str = Field(default="none", description="Highest compression tier applied")
    blocks_total: int = Field(default=0, description="Total context blocks assembled")
    blocks_dropped: int = Field(default=0, description="Blocks removed during compression")
    blocks_truncated: int = Field(default=0, description="Blocks truncated during compression")
    budget_exceeded: bool = Field(default=False, description="True if final tokens exceed budget")
    phase: Optional[str] = Field(default=None, description="Pipeline phase name")

    def to_dict(self) -> Dict[str, Any]:
        return self.model_dump()

    def summary_line(self) -> str:
        status = "OK" if not self.budget_exceeded else "OVER"
        return (
            f"[BudgetReport] {self.agent_name} | "
            f"budget={self.budget_allocated} assembled={self.tokens_assembled} "
            f"final={self.tokens_final} ratio={self.compression_ratio:.2f} "
            f"tier={self.tier_used} blocks={self.blocks_total} "
            f"dropped={self.blocks_dropped} truncated={self.blocks_truncated} "
            f"status={status}"
        )


class ContextBudgetError(Exception):
    """Raised when compressed context still exceeds the allocated budget."""

    def __init__(self, report: BudgetReport):
        self.report = report
        super().__init__(
            f"Context budget exceeded for {report.agent_name}: "
            f"allocated={report.budget_allocated}, final={report.tokens_final} "
            f"({report.compression_ratio:.2f}x)"
        )
