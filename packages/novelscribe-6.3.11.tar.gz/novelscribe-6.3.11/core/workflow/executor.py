"""Workflow executor for running complete workflows."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional

from core.agents.orchestrator_integration import AgentSystemIntegration
from core.git import GitManager
from core.hooks import (
    HookDispatchBlockedError,
    HookEvent,
    HookEventBus,
    HookEventPayload,
    HookSubscription,
)
from core.llm.formatter import MessageFormatter
from core.metrics.persistor import MetricsPersistor
from core.runtime import RuntimeKernel, RuntimeOutcome, RuntimeState, RuntimeTask
from core.storage import StorageBackend
from core.workflow.execution_helpers import (
    execute_single_step,
    execute_steps,
    run_steps_with_timeout,
)
from core.workflow.loader import WorkflowLoader

from .step_executor import StepExecutor

if TYPE_CHECKING:
    from core.context.bus import ContextBus


class WorkflowExecutor:
    """Execute complete workflows with step orchestration."""

    def __init__(
        self,
        workflows_dir: str | Path,
        agent_integration: AgentSystemIntegration,
        storage: StorageBackend,
        git_manager: GitManager,
        work_dir: str | Path | None = None,
        context_bus: Optional[ContextBus] = None,
        runtime: RuntimeKernel | None = None,
        hook_event_bus: HookEventBus | None = None,
        phase_model_profile: Optional[Any] = None,
    ):
        """Initialize workflow executor."""
        self.workflows_dir = Path(workflows_dir)
        self.workflow_loader = WorkflowLoader(self.workflows_dir)
        self.step_executor = StepExecutor(
            agent_integration=agent_integration,
            storage=storage,
            git_manager=git_manager,
            work_dir=work_dir,
        )
        self.context_bus = context_bus
        self.runtime = runtime
        self.hook_event_bus = hook_event_bus or HookEventBus()
        self.phase_model_profile = phase_model_profile
        self._last_runtime_entry_outcome: RuntimeOutcome | None = None
        self._last_project_name: str | None = None
        self.logger = logging.getLogger(__name__)
        self._msg = MessageFormatter()

    def execute_workflow(
        self,
        workflow_name: str,
        project_name: str,
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute a workflow."""
        resolved_config = self._resolve_config(workflow_name, config)
        try:
            result = self._execute_workflow_inner(
                workflow_name,
                project_name,
                variables,
                resolved_config,
            )
        finally:
            self._persist_pipeline_metrics()
        return result

    def _resolve_config(self, workflow_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve LLM config using PhaseModelProfile if available."""
        if self.phase_model_profile is None:
            return config
        return self.phase_model_profile.resolve(
            phase_name=workflow_name,
            base_config=config,
        )

    def _execute_workflow_inner(
        self,
        workflow_name: str,
        project_name: str,
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Inner implementation of execute_workflow (called within finally)."""
        self._last_project_name = project_name
        try:
            runtime_entry = self._run_runtime_entry_mainline(
                workflow_name=workflow_name,
                project_name=project_name,
                variables=variables,
            )
            gate_mode = self._resolve_runtime_gate_mode(config)
            if not runtime_entry.get("success", False):
                if gate_mode == "strict":
                    self.logger.error(self._msg.format("runtime_gate_failed", name=workflow_name))
                    return {
                        "workflow": workflow_name,
                        "success": False,
                        "error": "Runtime entry gate failed in strict mode",
                        "runtime_entry": runtime_entry,
                        "executed_steps": [],
                        "failed_steps": [],
                        "step_outputs": {},
                    }

                self.logger.warning(self._msg.format("runtime_gate_compat", name=workflow_name))
            workflow = self.workflow_loader.load_workflow(
                self.workflows_dir / f"{workflow_name}.yaml"
            )

            self.logger.info(self._msg.format("workflow_started", name=workflow_name))

            merged_variables = {**workflow.variables, **variables}

            step_outputs = {}
            executed_steps = []
            failed_steps = []
            hook_reports: list[dict[str, Any]] = []
            hook_subscriptions = list(workflow.hooks)

            timeout_result = run_steps_with_timeout(
                self,
                workflow.timeout_sec,
                workflow,
                workflow_name,
                project_name,
                merged_variables,
                config,
                hook_subscriptions,
                step_outputs,
                executed_steps,
                failed_steps,
                hook_reports,
                runtime_entry,
            )
            if timeout_result is not None:
                return timeout_result

            all_success = len(failed_steps) == 0
            terminal_event = (
                HookEvent.PIPELINE_SUCCESS if all_success else HookEvent.PIPELINE_FAILURE
            )
            self._emit_hook_event(
                event=terminal_event.value,
                subscriptions=hook_subscriptions,
                hook_reports=hook_reports,
                metadata={
                    "workflow": workflow_name,
                    "project_name": project_name,
                    "success": all_success,
                    "context_status": "success" if all_success else "failure",
                    "failed_steps": len(failed_steps),
                },
                raise_on_required_failure=False,
            )

            return {
                "workflow": workflow_name,
                "success": all_success,
                "executed_steps": executed_steps,
                "failed_steps": failed_steps,
                "step_outputs": step_outputs,
                "runtime_entry": runtime_entry,
                "hook_reports": hook_reports,
            }

        except HookDispatchBlockedError as e:
            self.logger.error("Workflow hook blocked execution: %s", e)
            return {
                "workflow": workflow_name,
                "success": False,
                "error": str(e),
                "hook_blocked_by": e.report.blocked_by,
                "executed_steps": [],
                "failed_steps": [],
                "step_outputs": {},
                "hook_reports": [e.report.model_dump(mode="json")],
            }
        except Exception as e:
            self.logger.error(self._msg.format("workflow_failed", name=workflow_name, error=str(e)))

            return {
                "workflow": workflow_name,
                "success": False,
                "error": str(e),
                "executed_steps": [],
                "failed_steps": [],
                "step_outputs": {},
            }

    def _execute_steps(
        self, workflow, wf_name, proj, variables, config, hooks, outputs, executed, failed, reports
    ) -> None:
        execute_steps(
            self,
            workflow,
            wf_name,
            proj,
            variables,
            config,
            hooks,
            outputs,
            executed,
            failed,
            reports,
        )

    def _execute_single_step(
        self,
        step,
        wf_name,
        proj,
        variables,
        outputs,
        config,
        hook_subs,
        hook_reports,
        executed,
        failed,
    ) -> None:
        execute_single_step(
            self,
            step,
            wf_name,
            proj,
            variables,
            outputs,
            config,
            hook_subs,
            hook_reports,
            executed,
            failed,
        )

    def _emit_hook_event(
        self,
        event: str,
        subscriptions: list[HookSubscription],
        hook_reports: list[dict[str, Any]],
        metadata: dict[str, Any],
        *,
        raise_on_required_failure: bool = True,
    ) -> None:
        """Emit one workflow hook event and append structured report."""
        if not subscriptions:
            return
        payload = HookEventPayload(
            event=event,
            context_id=str(metadata.get("workflow", "")),
            context_status=metadata.get("context_status"),
            context_step_name=metadata.get("step_name"),
            metadata=metadata,
        )
        report = self.hook_event_bus.dispatch(
            event=event,
            payload=payload,
            subscriptions=subscriptions,
            raise_on_required_failure=raise_on_required_failure,
        )
        hook_reports.append(report.model_dump(mode="json"))

    def _resolve_runtime_gate_mode(self, config: dict[str, Any]) -> str:
        """Resolve runtime gate mode from execution config."""
        mode = config.get("runtime_gate_mode")
        if isinstance(mode, str) and mode.lower() == "strict":
            return "strict"
        return "compat"

    def _run_runtime_entry_mainline(
        self,
        workflow_name: str,
        project_name: str,
        variables: Dict[str, Any],
    ) -> dict[str, Any]:
        """Run runtime entry gating before legacy step execution."""
        from core.runtime.models import RuntimeState, RuntimeTask

        runtime = self._ensure_runtime_mainline()
        task = RuntimeTask(
            user_input=f"Execute workflow '{workflow_name}' for project '{project_name}'.",
            system_prompt="Workflow runtime entry gate",
            agent_name="workflow_runtime_mainline",
            metadata={
                "source": "workflow_executor_mainline",
                "workflow_name": workflow_name,
                "project_name": project_name,
                "variables": dict(variables),
            },
        )
        state = RuntimeState(metadata={"workflows_dir": str(self.workflows_dir)})
        self._last_runtime_entry_outcome = runtime.run(task, state)
        return self._last_runtime_entry_outcome.model_dump(mode="json")

    def _ensure_runtime_mainline(self) -> RuntimeKernel:
        """Ensure workflow executor has a runtime instance for mainline entry."""
        if self.runtime is not None:
            return self.runtime
        self.runtime = RuntimeKernel(infer_fn=lambda _s, _u: "runtime_entry_ok")
        return self.runtime

    def execute_workflow_with_loop(
        self,
        workflow_name: str,
        project_name: str,
        variables: Dict[str, Any],
        config: Dict[str, Any],
        loop_range: range,
    ) -> Dict[str, Any]:
        """Execute workflow in a loop."""
        self.logger.info(
            f"Executing workflow {workflow_name} in loop: {len(loop_range)} iterations"
        )

        all_results = []
        failed_iterations = []

        for i in loop_range:
            self.logger.info(f"Loop iteration {i}")

            loop_variables = {**variables, "iteration": i}

            result = self.execute_workflow(
                workflow_name=workflow_name,
                project_name=project_name,
                variables=loop_variables,
                config=config,
            )

            all_results.append(result)

            if not result.get("success"):
                failed_iterations.append(i)
                self.logger.error(f"Iteration {i} failed")

        all_success = len(failed_iterations) == 0

        return {
            "workflow": workflow_name,
            "success": all_success,
            "iterations": len(loop_range),
            "failed_iterations": failed_iterations,
            "results": all_results,
        }

    def list_workflows(self) -> Dict[str, str]:
        """List all available workflows."""
        workflows = self.workflow_loader.load_all_workflows()

        return {workflow.name: workflow.description for workflow in workflows}

    def get_workflow_info(self, workflow_name: str) -> Dict[str, Any]:
        """Get workflow information."""
        try:
            workflow = self.workflow_loader.load_workflow(
                self.workflows_dir / f"{workflow_name}.yaml"
            )

            return {
                "name": workflow.name,
                "version": workflow.version,
                "description": workflow.description,
                "variables": workflow.variables,
                "step_count": len(workflow.steps),
            }

        except Exception:
            return {}

    def run_runtime_preview(
        self,
        prompt: str,
        system_prompt: str = "Workflow Runtime Preview",
    ) -> RuntimeOutcome:
        """Run a side-route runtime loop without changing workflow main path."""
        runtime = self.runtime
        if runtime is None:
            runtime = RuntimeKernel.from_llm_client(
                self.step_executor.agent_integration.llm_client,
                context_bus=self.context_bus,
                memory_bus=getattr(self.context_bus, "memory_bus", None),
            )
            self.runtime = runtime

        task = RuntimeTask(
            user_input=prompt,
            system_prompt=system_prompt,
            agent_name="workflow_runtime_preview",
            metadata={"source": "workflow_executor"},
        )
        state = RuntimeState(metadata={"workflows_dir": str(self.workflows_dir)})
        return runtime.run(task, state)

    def _persist_pipeline_metrics(self) -> None:
        """Persist pipeline metrics snapshot to project directory.

        Called from the ``finally`` block of ``execute_workflow`` so that
        metrics are always recorded regardless of whether execution succeeds
        or raises an exception.
        """
        project_name = self._last_project_name
        if not project_name:
            return
        try:
            persistor = MetricsPersistor(project_name)
            persistor.persist_snapshot()
        except Exception:
            pass
