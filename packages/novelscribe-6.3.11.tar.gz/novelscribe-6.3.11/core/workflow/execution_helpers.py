"""Shared execution helpers for workflow step orchestration."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    pass

from core.hooks import HookEvent
from core.parallel import ParallelStepExecutor  # noqa: F401 (re-export: tests mock via patch)
from core.workflow._parallel import execute_parallel_steps


def run_steps_with_timeout(
    executor: Any,
    workflow_timeout: int | None,
    workflow: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hook_subs: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
    runtime_entry: dict[str, Any],
) -> Optional[dict[str, Any]]:
    """Run workflow steps with optional global timeout protection."""
    if workflow_timeout is None:
        execute_steps(
            executor,
            workflow,
            wf_name,
            proj,
            variables,
            config,
            hook_subs,
            outputs,
            executed,
            failed,
            reports,
        )
        return None

    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(
            execute_steps,
            executor,
            workflow,
            wf_name,
            proj,
            variables,
            config,
            hook_subs,
            outputs,
            executed,
            failed,
            reports,
        )
        try:
            future.result(timeout=workflow_timeout)
            return None
        except FuturesTimeoutError:
            executor.logger.error(
                executor._msg.format("workflow_timed_out", name=wf_name, timeout=workflow_timeout)
            )
            executor._emit_hook_event(
                HookEvent.PIPELINE_FAILURE.value,
                hook_subs,
                reports,
                {
                    "workflow": wf_name,
                    "project_name": proj,
                    "success": False,
                    "context_status": "timeout",
                    "error": f"Workflow timed out after {workflow_timeout}s",
                },
                raise_on_required_failure=False,
            )
            return {
                "workflow": wf_name,
                "success": False,
                "error": f"Workflow timed out after {workflow_timeout}s",
                "executed_steps": executed,
                "failed_steps": failed,
                "step_outputs": outputs,
                "runtime_entry": runtime_entry,
                "hook_reports": reports,
                "timed_out": True,
            }


def execute_steps(
    executor: Any,
    workflow: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hooks: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
) -> None:
    """Execute workflow steps, using DAG runner when dependencies/strategy exist."""
    has_dag = any(
        step.depends_on or (step.strategy and step.strategy.mode != "sequential")
        for step in workflow.steps
    )
    if not has_dag:
        for step in workflow.steps:
            execute_single_step(
                executor,
                step,
                wf_name,
                proj,
                variables,
                outputs,
                config,
                hooks,
                reports,
                executed,
                failed,
            )
        return

    execute_parallel_steps(
        executor,
        workflow.steps,
        wf_name,
        proj,
        variables,
        config,
        outputs,
        executed,
        failed,
    )


def _execute_sequential_remaining(
    executor: Any,
    sequential: list[Any],
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hooks: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
) -> None:
    """Execute a subset of sequential steps (used after DAG partition)."""
    for step in sequential:
        execute_single_step(
            executor,
            step,
            wf_name,
            proj,
            variables,
            outputs,
            config,
            hooks,
            reports,
            executed,
            failed,
        )


def execute_single_step(
    executor: Any,
    step: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    outputs: dict[str, Any],
    config: dict[str, Any],
    hook_subs: list[Any],
    hook_reports: list[dict[str, Any]],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
) -> None:
    """Execute one workflow step with hook dispatch and context ingestion."""
    from core.workflow._step_lifecycle import run_step_lifecycle

    run_step_lifecycle(
        step=step,
        project_name=proj,
        context_bus=executor.context_bus,
        step_executor_fn=executor.step_executor.execute_step,
        step_outputs=outputs,
        wf_name=wf_name,
        variables=variables,
        config=config,
        hooks=hook_subs,
        reports=hook_reports,
        executed=executed,
        failed=failed,
        logger=executor.logger,
        emit_fn=executor._emit_hook_event,
    )
