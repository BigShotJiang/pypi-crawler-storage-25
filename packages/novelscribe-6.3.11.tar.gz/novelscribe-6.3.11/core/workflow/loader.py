"""Workflow loader for parsing YAML workflow definitions."""

import logging
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field

from core.hooks import HookSubscription, StepRetryPolicy
from core.i18n import LanguageCode
from core.templates.schema_versions import SchemaVersionRegistry
from core.templates.step_loader import StepTemplateLoader

logger = logging.getLogger(__name__)


class OnFailure(str, Enum):
    """On failure behavior."""

    CONTINUE = "continue"
    STOP = "stop"


class ExecutionStrategy(BaseModel):
    """Execution strategy for workflow steps."""

    mode: str = Field(default="sequential", pattern="^(sequential|parallel|matrix)$")
    max_concurrent: int = Field(default=4, ge=1, le=16)
    matrix_variable: Optional[str] = None
    matrix_values: Optional[list[Any]] = None


class WorkflowStep(BaseModel):
    """Workflow step definition."""

    step: int = Field(..., description="Step number")
    name: str = Field(..., description="Step name")
    agent: Optional[str] = Field(None, description="Agent to execute")
    workflow: Optional[str] = Field(None, description="Nested workflow to execute")
    action: Optional[str] = Field(None, description="System action to execute")
    input: Dict[str, Any] = Field(default_factory=dict, description="Input variables")
    output: Dict[str, Any] = Field(default_factory=dict, description="Output mappings")
    condition: Optional[str] = Field(None, description="Conditional execution")
    on_failure: OnFailure = Field(default=OnFailure.STOP, description="Failure behavior")
    context_type: Optional[str] = Field(None, description="Context artifact type for bus ingestion")
    timeout_sec: Optional[int] = Field(None, description="Step execution timeout in seconds")
    retry: Optional[StepRetryPolicy] = Field(None, description="Step retry policy")
    strategy: Optional[ExecutionStrategy] = Field(None, description="Execution strategy")
    depends_on: Optional[list[str]] = Field(None, description="Step names this step depends on")
    on_rollback: Optional[Dict[str, Any]] = Field(None, description="Rollback action on failure")
    hooks: Optional[list[HookSubscription]] = Field(
        None, description="Step-level hook subscriptions"
    )
    secrets: Optional[list[str]] = Field(None, description="Secret names required by this step")
    template: Optional[str] = Field(None, description="Step template name to resolve")
    template_params: Optional[Dict[str, Any]] = Field(
        None, description="Parameters for template substitution"
    )
    output_schema: Optional[Dict[str, Any]] = Field(
        None, description="JSON Schema for output validation"
    )


class Workflow(BaseModel):
    """Workflow definition."""

    name: str = Field(..., description="Workflow name")
    version: str = Field(default="1.0.0", description="Workflow version")
    description: str = Field(..., description="Workflow description")
    variables: Dict[str, Any] = Field(default_factory=dict, description="Workflow variables")
    steps: List[WorkflowStep] = Field(default_factory=list, description="Workflow steps")
    hooks: List[HookSubscription] = Field(
        default_factory=list,
        description="Workflow-level hook subscriptions",
    )
    secrets: Optional[list[str]] = Field(None, description="Secret names required by this workflow")
    timeout_sec: Optional[int] = Field(
        None, description="Workflow-level execution timeout in seconds"
    )
    artifacts: Optional[Dict[str, Any]] = Field(
        None, description="Artifact declarations with inputs and outputs"
    )
    file_path: Optional[str] = Field(None, description="Path to workflow file")


class WorkflowLoader:
    """Load workflow definitions from YAML files."""

    def __init__(self, workflows_dir: str | Path, language: Optional[LanguageCode] = None):
        self.workflows_dir = Path(workflows_dir)
        self.language = language or LanguageCode.EN
        self._schema_registry = SchemaVersionRegistry()
        self._template_loader = StepTemplateLoader()

    def load_workflow(self, file_path: str | Path) -> Workflow:
        """Load a single workflow from YAML file.

        Args:
            file_path: Path to workflow file

        Returns:
            Workflow object

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"Workflow file not found: {file_path}")

        content = file_path.read_text(encoding="utf-8")

        return self.parse_workflow(content, file_path)

    def parse_workflow(self, content: str, file_path: Optional[Path] = None) -> Workflow:
        """Parse workflow from YAML content.

        Args:
            content: YAML content
            file_path: Optional file path for reference

        Returns:
            Workflow object

        Raises:
            ValueError: If content format is invalid
        """
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML: {e}")

        if not isinstance(data, dict):
            raise ValueError("Workflow must be a dictionary")

        return self._build_workflow(data, file_path)

    def _build_workflow(self, data: dict[str, Any], file_path: Optional[Path] = None) -> Workflow:
        """Build validated workflow model from parsed YAML data."""

        required_fields = ["name", "description"]
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")

        parsed = self._schema_registry.parse_workflow(data, file_path)

        steps = []
        for step_data in parsed.steps:
            if isinstance(step_data, dict) and step_data.get("template"):
                step_data = self._resolve_step_template(step_data)
            step = WorkflowStep(**step_data)
            steps.append(step)

        workflow = Workflow(
            name=parsed.name,
            version=parsed.version,
            description=parsed.description,
            variables=parsed.variables,
            steps=steps,
            hooks=self._parse_hooks(data),
            secrets=data.get("secrets"),
            timeout_sec=data.get("timeout_sec"),
            artifacts=data.get("artifacts"),
            file_path=parsed.file_path,
        )

        return workflow

    def _resolve_step_template(self, step_data: dict[str, Any]) -> dict[str, Any]:
        """Resolve a template reference in step data."""
        template_name = step_data.pop("template")
        template_params = step_data.pop("template_params", {})
        try:
            resolved = self._template_loader.resolve(
                template_name,
                overrides=step_data,
                parameters=template_params,
            )
            return resolved
        except (FileNotFoundError, ValueError) as exc:
            logger.warning("Template resolution failed for '%s': %s", template_name, exc)
            return step_data

    def _parse_hooks(self, data: dict[str, Any]) -> list[HookSubscription]:
        """Parse workflow-level hook subscriptions from YAML data."""
        hooks_data = data.get("hooks", {})
        if not isinstance(hooks_data, dict):
            return []

        subscriptions = hooks_data.get("subscriptions", [])
        if not isinstance(subscriptions, list):
            return []

        parsed_subscriptions: list[HookSubscription] = []
        for item in subscriptions:
            if not isinstance(item, dict):
                continue
            parsed_subscriptions.append(HookSubscription(**item))
        return parsed_subscriptions

    def _merge_overlay_data(
        self,
        canonical: dict[str, Any],
        overlay: dict[str, Any],
    ) -> dict[str, Any]:
        """Merge locale overlay into canonical workflow data."""
        merged: dict[str, Any] = dict(canonical)
        for key, overlay_value in overlay.items():
            if key not in merged:
                merged[key] = overlay_value
                continue

            base_value = merged[key]
            if isinstance(base_value, dict) and isinstance(overlay_value, dict):
                merged[key] = self._merge_overlay_data(base_value, overlay_value)
            else:
                # Scalars and arrays are replaced by overlay value.
                merged[key] = overlay_value
        return merged

    def _load_merged_workflow(
        self,
        canonical_path: Path,
        overlay_path: Optional[Path] = None,
    ) -> Workflow:
        """Load workflow using canonical file with optional locale overlay."""
        canonical_data = yaml.safe_load(canonical_path.read_text(encoding="utf-8"))
        if not isinstance(canonical_data, dict):
            raise ValueError(f"Workflow must be a dictionary: {canonical_path}")

        merged_data = canonical_data
        if overlay_path and overlay_path.exists():
            overlay_data = yaml.safe_load(overlay_path.read_text(encoding="utf-8"))
            if not isinstance(overlay_data, dict):
                raise ValueError(f"Workflow overlay must be a dictionary: {overlay_path}")
            merged_data = self._merge_overlay_data(canonical_data, overlay_data)

        return self._build_workflow(merged_data, overlay_path or canonical_path)

    def load_all_workflows(self) -> List[Workflow]:
        """Load all workflows from directory.

        Returns:
            List of Workflow objects

        Note:
            Loads workflows from language-specific subdirectory (e.g., workflows/en/).
            Falls back to English if language-specific directory is empty or missing.
            For backward compatibility, also loads from workflows_dir if no language
            subdirectories exist.
        """
        workflows: List[Workflow] = []

        if not self.workflows_dir.exists():
            return workflows

        en_dir = self.workflows_dir / str(LanguageCode.EN)
        canonical_dir = (
            en_dir if en_dir.exists() and list(en_dir.glob("*.yaml")) else self.workflows_dir
        )

        if self.language == LanguageCode.EN:
            for file_path in canonical_dir.glob("*.yaml"):
                try:
                    workflow = self.load_workflow(file_path)
                    workflows.append(workflow)
                except Exception as e:
                    logger.warning("Failed to load workflow from %s: %s", file_path, e)
            return workflows

        overlay_dir = self.workflows_dir / str(self.language)
        has_overlay = overlay_dir.exists() and list(overlay_dir.glob("*.yaml"))
        if not has_overlay:
            logger.warning(
                "No workflow overlays for language %s, using canonical workflows",
                self.language,
            )

        for canonical_path in canonical_dir.glob("*.yaml"):
            overlay_path = overlay_dir / canonical_path.name if has_overlay else None
            try:
                workflow = self._load_merged_workflow(canonical_path, overlay_path)
                workflows.append(workflow)
            except Exception as e:
                logger.warning(
                    "Failed to load workflow from canonical=%s overlay=%s: %s",
                    canonical_path,
                    overlay_path,
                    e,
                )

        return workflows

    def reload_workflow(self, workflow_name: str) -> Optional[Workflow]:
        """Reload a workflow by name.

        Args:
            workflow_name: Name of workflow to reload

        Returns:
            Workflow object if found, None otherwise

        Note:
            Checks language-specific directory first, falls back to English,
            then falls back to workflows_dir for backward compatibility.
        """
        file_name = f"{workflow_name}.yaml"
        en_dir = self.workflows_dir / str(LanguageCode.EN)
        canonical_path = (
            en_dir / file_name
            if (en_dir.exists() and (en_dir / file_name).exists())
            else self.workflows_dir / file_name
        )
        if not canonical_path.exists():
            return None

        if self.language == LanguageCode.EN:
            return self.load_workflow(canonical_path)

        overlay_dir = self.workflows_dir / str(self.language)
        overlay_path = overlay_dir / file_name
        if not overlay_path.exists():
            logger.warning(
                "No workflow overlay for %s in language %s, using canonical",
                workflow_name,
                self.language,
            )
            overlay_path = None

        return self._load_merged_workflow(canonical_path, overlay_path)
