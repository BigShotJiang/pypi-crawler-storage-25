"""Chapter pagination for long-form novel generation."""

import re
from typing import Dict, List, Optional

from core.chapters.paginator_types import (
    ChapterPage,
    PageMetadata,
    PageSplitStrategy,
    PaginationConfig,
)
from core.llm.estimator import TokenEstimator


class ChapterPaginator:
    """Split chapters into coherent pages for efficient processing."""

    SCENE_BREAK_PATTERNS = [
        re.compile(r"\n\s*\n\s*[*#-]{3,}\n"),
        re.compile(r"\n\s*\n\s*~{3,}\n"),
        re.compile(r"\n\s*#{3,}\s*.*?\n"),
        re.compile(r"\n\s*\n\s*(Chapter|Scene|Part)\s+\d+.*?\n", re.IGNORECASE),
    ]

    PARAGRAPH_PATTERN = re.compile(r"\n\s*\n")
    SENTENCE_PATTERN = re.compile(r"[.!?]+[\s\n]+")
    DIALOGUE_PATTERN = re.compile(r'"[^"]*"')

    def __init__(self, config: Optional[PaginationConfig] = None):
        """
        Initialize chapter paginator.

        Args:
            config: Optional pagination configuration
        """
        self.config = config or PaginationConfig()
        self.token_estimator = TokenEstimator()

    def paginate_chapter(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]] = None
    ) -> List[ChapterPage]:
        """
        Split chapter content into pages.

        Args:
            content: Chapter content to paginate
            chapter_number: Chapter number
            metadata: Optional chapter metadata

        Returns:
            List of ChapterPage objects
        """
        if not content or not content.strip():
            return []

        total_tokens = self.token_estimator.estimate_tokens(content)
        if total_tokens <= self.config.max_tokens_per_page:
            page = self._create_single_page(content, chapter_number, metadata)
            return [page]

        if self.config.strategy == PageSplitStrategy.SCENE_BASED:
            return self._paginate_by_scenes(content, chapter_number, metadata)
        elif self.config.strategy == PageSplitStrategy.PARAGRAPH_BASED:
            return self._paginate_by_paragraphs(content, chapter_number, metadata)
        elif self.config.strategy == PageSplitStrategy.SEMANTIC:
            return self._paginate_semantically(content, chapter_number, metadata)
        else:  # TOKEN_BASED
            return self._paginate_by_tokens(content, chapter_number, metadata)

    def _create_single_page(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> ChapterPage:
        """Create a single page for content that doesn't need pagination."""
        tokens = self.token_estimator.estimate_tokens(content)
        words = len(re.findall(r"\b\w+\b", content))

        page_metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=len(content),
            word_count=words,
            token_count=tokens,
        )

        # Extract metadata if provided
        if metadata:
            self._enrich_page_metadata(page_metadata, metadata, content)

        return ChapterPage(page_number=1, content=content, metadata=page_metadata)

    def _paginate_by_tokens(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate based purely on token count."""
        pages = []
        position = 0
        page_number = 1
        previous_content = ""

        while position < len(content):
            # Calculate target end position
            remaining_content = content[position:]
            remaining_tokens = self.token_estimator.estimate_tokens(remaining_content)

            if remaining_tokens <= self.config.target_tokens_per_page:
                # Last page
                page_content = remaining_content
                end_position = len(content)
            else:
                # Find split point
                target_position = position + int(
                    (self.config.target_tokens_per_page / remaining_tokens) * len(remaining_content)
                )
                split_position = self._find_safe_split_point(content, target_position)
                page_content = content[position:split_position]
                end_position = split_position

            # Create page
            page_metadata = PageMetadata(
                page_number=page_number,
                start_position=position,
                end_position=end_position,
                word_count=len(re.findall(r"\b\w+\b", page_content)),
                token_count=self.token_estimator.estimate_tokens(page_content),
            )

            if metadata:
                self._enrich_page_metadata(page_metadata, metadata, page_content)

            page = ChapterPage(
                page_number=page_number,
                content=page_content,
                metadata=page_metadata,
                overlap_content=(
                    previous_content[-self.config.overlap_tokens * 3 :] if previous_content else ""
                ),
            )

            pages.append(page)

            # Prepare for next page
            previous_content = page_content
            position = end_position
            page_number += 1

        return pages

    def _paginate_by_scenes(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate based on scene boundaries."""
        scene_breaks = []
        for pattern in self.SCENE_BREAK_PATTERNS:
            for match in pattern.finditer(content):
                scene_breaks.append(match.start())

        scene_breaks = sorted(set(scene_breaks))

        if not scene_breaks:
            return self._paginate_semantically(content, chapter_number, metadata)

        pages = []
        page_number = 1
        start_position = 0

        for break_position in scene_breaks + [len(content)]:
            scene_content = content[start_position:break_position].strip()
            if not scene_content:
                continue

            scene_tokens = self.token_estimator.estimate_tokens(scene_content)

            if scene_tokens > self.config.max_tokens_per_page:
                sub_pages = self._paginate_by_tokens(scene_content, chapter_number, metadata)
                for sub_page in sub_pages:
                    sub_page.metadata.page_number = page_number
                    sub_page.metadata.start_position += start_position
                    sub_page.metadata.end_position += start_position
                    pages.append(sub_page)
                    page_number += 1
            else:
                page_metadata = PageMetadata(
                    page_number=page_number,
                    start_position=start_position,
                    end_position=break_position,
                    word_count=len(re.findall(r"\b\w+\b", scene_content)),
                    token_count=scene_tokens,
                    scene_identifier=f"scene_{page_number}",
                )

                if metadata:
                    self._enrich_page_metadata(page_metadata, metadata, scene_content)

                page = ChapterPage(
                    page_number=page_number, content=scene_content, metadata=page_metadata
                )

                pages.append(page)
                page_number += 1

            start_position = break_position

        return pages

    def _paginate_by_paragraphs(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate based on paragraph boundaries."""
        paragraphs = self.PARAGRAPH_PATTERN.split(content)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]

        pages = []
        current_page_content = ""
        page_number = 1
        position = 0

        for paragraph in paragraphs:
            test_content = (
                current_page_content + "\n\n" + paragraph if current_page_content else paragraph
            )
            test_tokens = self.token_estimator.estimate_tokens(test_content)

            if test_tokens <= self.config.target_tokens_per_page:
                current_page_content = test_content
            else:
                if current_page_content:
                    page = self._create_page_from_content(
                        current_page_content, page_number, position, chapter_number, metadata
                    )
                    pages.append(page)
                    position += len(current_page_content)
                    page_number += 1

                if (
                    self.token_estimator.estimate_tokens(paragraph)
                    > self.config.max_tokens_per_page
                ):
                    sub_pages = self._paginate_by_tokens(paragraph, chapter_number, metadata)
                    for sub_page in sub_pages:
                        sub_page.metadata.page_number = page_number
                        pages.append(sub_page)
                        page_number += 1
                    current_page_content = ""
                else:
                    current_page_content = paragraph

        if current_page_content:
            page = self._create_page_from_content(
                current_page_content, page_number, position, chapter_number, metadata
            )
            pages.append(page)

        return pages

    def _paginate_semantically(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate using semantic analysis for best coherence."""
        scene_pages = self._paginate_by_scenes(content, chapter_number, metadata)

        if len(scene_pages) > 1:
            avg_tokens = sum(p.metadata.token_count for p in scene_pages) / len(scene_pages)
            if self.config.min_page_tokens <= avg_tokens <= self.config.max_tokens_per_page:
                return scene_pages

        return self._paginate_by_paragraphs(content, chapter_number, metadata)

    def _find_safe_split_point(self, content: str, target_position: int) -> int:
        """Find a safe position to split content (near sentence boundaries)."""
        search_range = min(500, len(content) - target_position)
        search_start = max(0, target_position - search_range)
        search_end = min(len(content), target_position + search_range)

        search_area = content[search_start:search_end]

        for match in self.SENTENCE_PATTERN.finditer(search_area):
            split_pos = search_start + match.end()
            if search_start <= split_pos <= search_end:
                return split_pos

        return target_position

    def _create_page_from_content(
        self,
        content: str,
        page_number: int,
        start_position: int,
        chapter_number: int,
        metadata: Optional[Dict[str, any]],
    ) -> ChapterPage:
        """Create a ChapterPage from content."""
        tokens = self.token_estimator.estimate_tokens(content)
        words = len(re.findall(r"\b\w+\b", content))

        page_metadata = PageMetadata(
            page_number=page_number,
            start_position=start_position,
            end_position=start_position + len(content),
            word_count=words,
            token_count=tokens,
        )

        if metadata:
            self._enrich_page_metadata(page_metadata, metadata, content)

        return ChapterPage(page_number=page_number, content=content, metadata=page_metadata)

    def _enrich_page_metadata(
        self, page_metadata: PageMetadata, chapter_metadata: Dict[str, any], content: str
    ):
        """Enrich page metadata with extracted information."""
        if "characters" in chapter_metadata:
            mentioned_chars = []
            for char in chapter_metadata["characters"]:
                if char.lower() in content.lower():
                    mentioned_chars.append(char)
            page_metadata.characters_present = mentioned_chars

        if "locations" in chapter_metadata:
            mentioned_locs = []
            for loc in chapter_metadata["locations"]:
                if loc.lower() in content.lower():
                    mentioned_locs.append(loc)
            page_metadata.locations_present = mentioned_locs

        dialogues = self.DIALOGUE_PATTERN.findall(content)
        if dialogues:
            page_metadata.key_events = [f"Dialogue: {d[:50]}..." for d in dialogues[:3]]

    def regenerate_page(self, original_page: ChapterPage, new_content: str) -> ChapterPage:
        """
        Regenerate a page with new content while preserving metadata.

        Args:
            original_page: Original page to regenerate
            new_content: New content for the page

        Returns:
            New ChapterPage with updated content
        """
        tokens = self.token_estimator.estimate_tokens(new_content)
        words = len(re.findall(r"\b\w+\b", new_content))

        new_metadata = PageMetadata(
            page_number=original_page.metadata.page_number,
            start_position=original_page.metadata.start_position,
            end_position=original_page.metadata.start_position + len(new_content),
            word_count=words,
            token_count=tokens,
            scene_identifier=original_page.metadata.scene_identifier,
            characters_present=original_page.metadata.characters_present,
            locations_present=original_page.metadata.locations_present,
            key_events=original_page.metadata.key_events,
        )

        return ChapterPage(
            page_number=original_page.page_number,
            content=new_content,
            metadata=new_metadata,
            overlap_content=original_page.overlap_content,
        )

    def get_pagination_summary(self, pages: List[ChapterPage]) -> Dict[str, any]:
        """
        Get summary statistics for pagination.

        Args:
            pages: List of pages

        Returns:
            Dictionary with summary statistics
        """
        if not pages:
            return {
                "total_pages": 0,
                "total_words": 0,
                "total_tokens": 0,
                "avg_words_per_page": 0,
                "avg_tokens_per_page": 0,
            }

        total_words = sum(p.word_count for p in pages)
        total_tokens = sum(p.metadata.token_count for p in pages)

        return {
            "total_pages": len(pages),
            "total_words": total_words,
            "total_tokens": total_tokens,
            "avg_words_per_page": total_words // len(pages),
            "avg_tokens_per_page": total_tokens // len(pages),
            "pages_with_scenes": sum(1 for p in pages if p.metadata.scene_identifier),
            "total_characters": len(
                set(char for p in pages for char in p.metadata.characters_present)
            ),
            "total_locations": len(set(loc for p in pages for loc in p.metadata.locations_present)),
        }
