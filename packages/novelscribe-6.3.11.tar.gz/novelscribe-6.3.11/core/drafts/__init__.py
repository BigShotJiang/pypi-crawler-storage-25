"""Drafts subsystem — draft lifecycle and artifact management."""

from .artifacts import ArtifactManager, ArtifactRecord
from .manager import DraftManager, DraftManagerConfig, DraftMetadata, DraftStatus, DraftVersion
from .version_comparator import DiffReport, SectionChange, VersionComparator, VersionDiff

__all__ = [
    "ArtifactManager",
    "ArtifactRecord",
    "DiffReport",
    "DraftManager",
    "DraftManagerConfig",
    "DraftMetadata",
    "DraftStatus",
    "DraftVersion",
    "SectionChange",
    "VersionComparator",
    "VersionDiff",
]
