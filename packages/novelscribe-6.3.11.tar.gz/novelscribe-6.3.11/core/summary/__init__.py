"""Summary subsystem — chapter/partial summarization for novels."""

from .manager import SummaryManager, SummaryManagerConfig
from .store import ChapterSummary, GlobalSummary, GroupSummary, SummaryStore, SummaryStoreConfig

__all__ = [
    "ChapterSummary",
    "GlobalSummary",
    "GroupSummary",
    "SummaryStore",
    "SummaryStoreConfig",
    "SummaryManager",
    "SummaryManagerConfig",
]
