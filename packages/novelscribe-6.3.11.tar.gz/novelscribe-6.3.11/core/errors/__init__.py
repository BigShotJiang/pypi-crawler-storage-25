"""NovelScribe exception hierarchy.

Exports:
    NovelScribeError: Base exception for all NovelScribe errors.
"""

from .base import NovelScribeError

__all__ = [
    "NovelScribeError",
]
