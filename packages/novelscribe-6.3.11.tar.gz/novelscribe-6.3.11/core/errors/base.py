"""Shared exception hierarchy for NovelScribe core modules."""


class NovelScribeError(Exception):
    """Base exception for all NovelScribe errors."""
