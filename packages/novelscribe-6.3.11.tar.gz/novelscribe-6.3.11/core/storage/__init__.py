"""NovelScribe storage abstraction layer.

Provides file-based storage operations with abstraction for future database support.
"""

from .backends import (
    AgentDefinition,
    FileStorage,
    StorageBackend,
    StorageConfig,
    WorkflowDefinition,
)
from .errors import (
    FileNotFoundError,
    FileParseError,
    FileWriteError,
    StorageError,
)
from .manager import ProjectData, Storage, StorageFactory, resolve_project_path
from .path import ensure_directories

__all__ = [
    # errors
    "StorageError",
    "FileNotFoundError",
    "FileParseError",
    "FileWriteError",
    # backends
    "StorageBackend",
    "FileStorage",
    "StorageConfig",
    "AgentDefinition",
    "WorkflowDefinition",
    # manager
    "Storage",
    "StorageFactory",
    "ProjectData",
    "ensure_directories",
    "resolve_project_path",
]
