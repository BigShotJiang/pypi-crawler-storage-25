"""Storage-specific exceptions."""

from core.errors.base import NovelScribeError


class StorageError(NovelScribeError):
    """Base exception for storage operations."""


class StorageFileNotFoundError(StorageError):
    """Raised when a file is not found."""


FileNotFoundError = StorageFileNotFoundError


class FileParseError(StorageError):
    """Raised when file parsing fails."""


class FileWriteError(StorageError):
    """Raised when file writing fails."""
