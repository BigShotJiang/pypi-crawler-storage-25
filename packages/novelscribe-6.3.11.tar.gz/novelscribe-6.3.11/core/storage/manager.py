"""Storage factory and simple storage interface."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .backends import StorageBackend, StorageConfig

logger = logging.getLogger(__name__)


class StorageFactory:
    """Factory for creating storage backends."""

    _backends: dict[str, type] = {}

    @classmethod
    def create(cls, config: "StorageConfig") -> "StorageBackend":
        """Create storage backend from configuration."""
        from .backends import FileStorage
        from .errors import StorageError

        if not cls._backends:
            cls._backends["file"] = FileStorage
        backend_class = cls._backends.get(config.backend)

        if not backend_class:
            raise StorageError(f"Unknown storage backend: {config.backend}")

        return backend_class(config)

    @classmethod
    def register_backend(cls, name: str, backend_class: type) -> None:
        """Register a new storage backend."""
        cls._backends[name] = backend_class


class ProjectData:
    """Simple project data container."""

    def __init__(self, name: str, meta: Optional[dict] = None, chapters: Optional[list] = None):
        self.name = name
        self.meta = meta or {}
        self.chapters = chapters or []


class Storage:
    """Simple storage interface for project management."""

    def __init__(self) -> None:
        """Initialize storage with default configuration."""
        from .backends import FileStorage, StorageConfig

        self._config = StorageConfig()
        self._backend: StorageBackend = FileStorage(self._config)  # type: ignore[valid-type]

    @property
    def project_dir(self) -> Path:
        """Get the project directory path."""
        if hasattr(self._backend, "base_path"):
            return self._backend.base_path  # type: ignore[return-value]
        return Path(self._config.base_path)

    def list_projects(self) -> list[str]:
        """List all projects in storage.

        Returns:
            List of project names
        """
        try:
            base = self.project_dir
            if not base.exists():
                return []
            return [d.name for d in base.iterdir() if d.is_dir() and not d.name.startswith(".")]
        except Exception:
            return []

    def load_project(self, name: str) -> ProjectData:
        """Load a project by name.

        Args:
            name: Project name

        Returns:
            ProjectData object with project information
        """

        project_path = self.project_dir / name
        meta_path = project_path / "meta.yaml"

        meta: dict = {}
        chapters: list = []

        if meta_path.exists():
            try:
                meta = self._backend.read_yaml(str(meta_path)) or {}
            except Exception:
                logger.debug("Failed to read meta.yaml for project %s", name)

        chapters_dir = project_path / "chapters"
        if chapters_dir.exists():
            for chapter_file in sorted(chapters_dir.glob("*.md")):
                chapters.append({"file": chapter_file.name, "path": str(chapter_file)})

        return ProjectData(name=name, meta=meta, chapters=chapters)

    def save_project(self, name: str, meta: Optional[dict] = None) -> None:
        """Save a project's metadata.

        Args:
            name: Project name
            meta: Project metadata dictionary
        """
        project_path = self.project_dir / name
        project_path.mkdir(parents=True, exist_ok=True)
        meta_path = project_path / "meta.yaml"
        self._backend.write_yaml(str(meta_path), meta or {})


def resolve_project_path(project_name: str, base_path: Optional[Path] = None) -> Path:
    """Resolve the path for a project directory.

    Args:
        project_name: Name of the project
        base_path: Optional base path override

    Returns:
        Resolved project directory Path
    """
    if base_path is None:
        base_path = Path(".novels")
    return base_path / project_name
