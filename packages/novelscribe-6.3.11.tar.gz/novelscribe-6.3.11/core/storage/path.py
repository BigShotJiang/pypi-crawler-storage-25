"""Path utilities for project storage."""

from __future__ import annotations

from pathlib import Path
from typing import Optional


def ensure_directories(*paths: str) -> None:
    """Ensure all directories exist, creating them if necessary."""
    for path_str in paths:
        path = Path(path_str)
        if path.suffix:
            path = path.parent
        if path_str and path:
            path.mkdir(parents=True, exist_ok=True)


def resolve_project_path(
    project_dir: str,
    relative: str,
    must_exist: bool = False,
) -> Optional[Path]:
    """Resolve a path relative to the project directory."""
    base = Path(project_dir)
    resolved = (base / relative).resolve()
    if must_exist and not resolved.exists():
        return None
    return resolved
