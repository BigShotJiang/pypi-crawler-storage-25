"""Shared logic for OpenAI-compatible provider clients."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator

from core.llm.client import LLMClient, LLMError, LLMResponse


class OpenAICompatibleClient(LLMClient):
    """Base client for providers using OpenAI-compatible chat APIs."""

    api_error_label: str = "Provider"
    config_error_message: str = "API key not configured"
    use_response_model_name: bool = True

    _MODELS_REQUIRING_MAX_COMPLETION_TOKENS = frozenset(
        {
            "o1",
            "o1-mini",
            "o1-pro",
            "o1-preview",
            "o1-mini-2024-09-12",
            "o3",
            "o3-mini",
            "o3-pro",
            "o3-mini-2025-01-31",
            "o4-mini",
            "gpt-5",
            "gpt-5.1",
            "gpt-5-mini",
            "gpt-5-nano",
            "chatgpt-4o-latest",
        }
    )

    def _max_tokens_param(self) -> dict[str, int]:
        """Return the correct token-limit kwarg for the current model."""
        model_lower = (self.config.model or "").lower()
        needs_new_param = any(
            model_lower.startswith(prefix) or model_lower == prefix
            for prefix in self._MODELS_REQUIRING_MAX_COMPLETION_TOKENS
        )
        if needs_new_param:
            return {"max_completion_tokens": self.config.max_tokens}
        return {"max_tokens": self.config.max_tokens}

    def _ensure_clients(self) -> None:
        return

    def _ensure_config(self) -> None:
        if not self.validate_config():
            raise LLMError(self.config_error_message)

    def _response_model_name(self, response: object) -> str:
        if self.use_response_model_name:
            model = getattr(response, "model", None)
            if isinstance(model, str) and model:
                return model
        return self.config.model

    def _to_response(self, response: object) -> LLMResponse:
        usage = getattr(response, "usage", None)
        choices = getattr(response, "choices", None) or []
        choice0 = choices[0]
        return LLMResponse(
            content=choice0.message.content,
            model=self._response_model_name(response),
            provider=self.provider_name,
            tokens_used=usage.total_tokens if usage else None,
            finish_reason=choice0.finish_reason,
        )

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                **self._max_tokens_param(),
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    async def generate_async(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            response = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                **self._max_tokens_param(),
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                **self._max_tokens_param(),
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    async def generate_with_history_async(self, messages: list[dict[str, str]]) -> LLMResponse:
        self._ensure_config()
        self._ensure_clients()
        try:
            response = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                **self._max_tokens_param(),
            )
            return self._to_response(response)
        except Exception as e:
            raise LLMError(f"{self.api_error_label} API error: {e}") from e

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            stream = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                **self._max_tokens_param(),
                stream=True,
            )
            for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta
        except Exception as e:
            raise LLMError(f"{self.api_error_label} streaming error: {e}") from e

    async def generate_stream_async(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        self._ensure_config()
        self._ensure_clients()
        messages = self._format_messages(system_prompt, user_prompt)
        try:
            stream = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                **self._max_tokens_param(),
                stream=True,
            )
            async for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta
        except Exception as e:
            raise LLMError(f"{self.api_error_label} streaming error: {e}") from e
