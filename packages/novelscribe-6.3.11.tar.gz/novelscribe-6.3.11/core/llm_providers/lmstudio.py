"""LM Studio (local) provider client."""

from __future__ import annotations

import os

from core.llm.client import LLMConfig, LLMError
from core.llm_providers.openai_compatible import OpenAICompatibleClient


class LMStudioClient(OpenAICompatibleClient):
    """LM Studio (local) provider client."""

    api_error_label = "LM Studio"
    config_error_message = "LM Studio API key not configured"
    use_response_model_name = False

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
            self.base_url = config.base_url or os.getenv(
                "LM_STUDIO_BASE_URL", "http://localhost:1234/v1"
            )
            self.client = openai.OpenAI(
                base_url=self.base_url, api_key="not-needed", timeout=config.timeout
            )
            self.async_client = openai.AsyncOpenAI(
                base_url=self.base_url, api_key="not-needed", timeout=config.timeout
            )
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")

    def validate_config(self) -> bool:
        """Validate LM Studio configuration."""
        return True
