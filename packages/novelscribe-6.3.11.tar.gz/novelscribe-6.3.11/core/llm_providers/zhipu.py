"""ZhipuAI (z.ai / 智谱AI) provider client (OpenAI-compatible).

ZhipuAI's v4 API is fully OpenAI-compatible, so this client reuses the openai
SDK with a custom base_url pointing to ZhipuAI's BigModel endpoint.

API docs: https://open.bigmodel.cn/
"""

from __future__ import annotations

import os

from core.llm.client import LLMConfig, LLMError
from core.llm_providers.openai_compatible import OpenAICompatibleClient


class ZhipuClient(OpenAICompatibleClient):
    """ZhipuAI (z.ai) provider client (OpenAI-compatible)."""

    api_error_label = "ZhipuAI"
    config_error_message = "ZhipuAI API key not configured"

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
            self.base_url = config.base_url or os.getenv(
                "ZHIPUAI_BASE_URL", "https://open.bigmodel.cn/api/paas/v4"
            )
            api_key = config.api_key or os.getenv("ZHIPUAI_API_KEY", "")
            self.client = openai.OpenAI(
                base_url=self.base_url, api_key=api_key, timeout=config.timeout
            )
            self.async_client = openai.AsyncOpenAI(
                base_url=self.base_url, api_key=api_key, timeout=config.timeout
            )
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")

    def validate_config(self) -> bool:
        """Validate ZhipuAI configuration."""
        return bool(self.config.api_key or os.getenv("ZHIPUAI_API_KEY"))
