"""OpenAI provider client."""

from __future__ import annotations

import os

from core.llm.client import LLMConfig, LLMError
from core.llm_providers.openai_compatible import OpenAICompatibleClient


class OpenAIClient(OpenAICompatibleClient):
    """OpenAI provider client."""

    api_error_label = "OpenAI"
    config_error_message = "OpenAI API key not configured"

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")
        self.client = None
        self.async_client = None
        try:
            self._ensure_clients()
        except Exception:
            pass

    def _ensure_clients(self) -> None:
        if self.client is not None and self.async_client is not None:
            return
        api_key = self.config.api_key or os.getenv("OPENAI_API_KEY", "")
        base_url = self.config.base_url or os.getenv("OPENAI_API_BASE", "")

        client_kwargs: dict[str, object] = {"timeout": self.config.timeout}
        if base_url:
            client_kwargs["base_url"] = base_url
        client_kwargs["api_key"] = api_key or os.getenv("OPENAI_ADMIN_KEY", "")

        if self.client is None:
            self.client = self.openai.OpenAI(**client_kwargs)
        if self.async_client is None:
            self.async_client = self.openai.AsyncOpenAI(**client_kwargs)

    def validate_config(self) -> bool:
        """Validate OpenAI configuration."""
        return bool(
            self.config.api_key or os.getenv("OPENAI_API_KEY") or os.getenv("OPENAI_ADMIN_KEY")
        )
