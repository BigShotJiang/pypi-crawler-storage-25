"""Metrics persistor — save pipeline metrics snapshots to disk.

Layout::

    .novels/{project}/.metrics/
    ├── pipeline_20260506_143022.json
    ├── pipeline_20260506_150033.json
    └── ...

Each file is a complete JSON snapshot from ``MetricsCollector.snapshot()``.
Old files are pruned to keep the last *max_files* entries.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from core.metrics.collector import MetricsCollector

_DEFAULT_BASE = Path(".novels")
_DEFAULT_MAX_FILES = 10


class MetricsPersistor:
    """Persist ``MetricsCollector.snapshot()`` to per-project JSON files."""

    def __init__(
        self,
        project_name: str,
        base_path: Path = _DEFAULT_BASE,
        max_files: int = _DEFAULT_MAX_FILES,
    ) -> None:
        self._metrics_dir = base_path / project_name / ".metrics"
        self._max_files = max_files

    def persist_snapshot(self) -> Path:
        """Write current metrics snapshot and prune old files.

        Returns the path of the newly written file.
        """
        collector = MetricsCollector()
        snapshot = collector.snapshot()
        return self._write(snapshot)

    def persist_snapshot_from(self, data: dict[str, Any]) -> Path:
        """Write a pre-built snapshot dict and prune old files."""
        return self._write(data)

    def list_snapshots(self) -> list[Path]:
        """Return persisted snapshot files sorted oldest-first."""
        if not self._metrics_dir.exists():
            return []
        files = sorted(self._metrics_dir.glob("pipeline_*.json"))
        return files

    def load_latest(self) -> dict[str, Any] | None:
        """Load the most recent snapshot, or ``None`` if none exist."""
        files = self.list_snapshots()
        if not files:
            return None
        return json.loads(files[-1].read_text(encoding="utf-8"))

    def _write(self, data: dict[str, Any]) -> Path:
        self._metrics_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        path = self._metrics_dir / f"pipeline_{ts}.json"
        path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        self._prune()
        return path

    def _prune(self) -> None:
        files = self.list_snapshots()
        while len(files) > self._max_files:
            files[0].unlink()
            files = files[1:]
