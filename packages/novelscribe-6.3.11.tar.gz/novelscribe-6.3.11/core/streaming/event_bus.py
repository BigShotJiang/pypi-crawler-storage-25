"""Pipeline event bus for real-time streaming and checkpoint events."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from api.websocket_manager import WebSocketManager

__all__ = [
    "PipelineEventBus",
    "get_streaming_event_bus",
    "SuspendState",
    "StreamChunk",
    "CheckpointSuspendEvent",
    "CheckpointDecisionEvent",
    "CheckpointTimeoutEvent",
]


_instance: "PipelineEventBus | None" = None


def get_streaming_event_bus() -> PipelineEventBus:
    """Get or create the singleton PipelineEventBus instance."""
    global _instance
    if _instance is None:
        _instance = PipelineEventBus()
    return _instance


@dataclass
class StreamChunk:
    """A single token chunk from LLM streaming."""

    token: str
    phase: str
    project: str
    is_final: bool = False
    timestamp: datetime = field(default_factory=datetime.now)
    execution_id: str | None = None

    def to_event_data(self) -> dict[str, Any]:
        return {
            "token": self.token,
            "phase": self.phase,
            "project": self.project,
            "is_final": self.is_final,
            "timestamp": self.timestamp.isoformat(),
            "execution_id": self.execution_id,
        }


@dataclass
class CheckpointSuspendEvent:
    """Event emitted when pipeline suspends at a checkpoint."""

    checkpoint_id: str
    phase: str
    chapter: int | None
    proposal_title: str
    confidence: float
    project: str
    suspended_at: datetime = field(default_factory=datetime.now)
    timeout_seconds: int | None = None

    def to_event_data(self) -> dict[str, Any]:
        return {
            "checkpoint_id": self.checkpoint_id,
            "phase": self.phase,
            "chapter": self.chapter,
            "proposal_title": self.proposal_title,
            "confidence": self.confidence,
            "project": self.project,
            "suspended_at": self.suspended_at.isoformat(),
            "timeout_seconds": self.timeout_seconds,
        }


@dataclass
class CheckpointDecisionEvent:
    """Event emitted when checkpoint decision is resolved."""

    checkpoint_id: str
    decision_type: str
    project: str
    resolved_at: datetime = field(default_factory=datetime.now)

    def to_event_data(self) -> dict[str, Any]:
        return {
            "checkpoint_id": self.checkpoint_id,
            "decision_type": self.decision_type,
            "project": self.project,
            "resolved_at": self.resolved_at.isoformat(),
        }


@dataclass
class CheckpointTimeoutEvent:
    """Event emitted when checkpoint times out and auto-approves."""

    checkpoint_id: str
    phase: str
    project: str
    timeout_seconds: int
    auto_approved: bool = True
    timed_out_at: datetime = field(default_factory=datetime.now)

    def to_event_data(self) -> dict[str, Any]:
        return {
            "checkpoint_id": self.checkpoint_id,
            "phase": self.phase,
            "project": self.project,
            "timeout_seconds": self.timeout_seconds,
            "auto_approved": self.auto_approved,
            "timed_out_at": self.timed_out_at.isoformat(),
        }


@dataclass
class SuspendState:
    """Tracks the state of a suspended checkpoint."""

    checkpoint_id: str
    phase: str
    chapter: int | None
    proposal_title: str
    confidence: float
    project: str
    suspended_at: datetime = field(default_factory=datetime.now)
    timeout_seconds: int | None = None
    resolved: bool = False
    resolved_at: datetime | None = None
    resolved_decision: str | None = None


class PipelineEventBus:
    """Central event bus for real-time pipeline events.

    Emits stream chunks, checkpoint events, and phase events to WebSocket clients.
    Thread-safe via lock. Gracefully no-ops if no WebSocket manager is attached.

    Usage::

        bus = get_streaming_event_bus()
        bus.set_ws_manager(get_websocket_manager())
        bus.emit_stream_chunk("my-novel", "writing_phase", "Once upon", False)
        bus.emit_checkpoint_suspend(checkpoint_id, phase, proposal, "my-novel")
    """

    def __init__(
        self,
        ws_manager: "WebSocketManager | None" = None,
    ) -> None:
        import threading

        self._ws_manager: "WebSocketManager | None" = ws_manager
        self._lock = threading.Lock()

    def set_ws_manager(self, manager: "WebSocketManager") -> None:
        """Attach a WebSocket manager for event broadcasting."""
        with self._lock:
            self._ws_manager = manager

    def clear_ws_manager(self) -> None:
        """Detach the WebSocket manager."""
        with self._lock:
            self._ws_manager = None

    def emit_stream_chunk(
        self,
        project: str,
        phase: str,
        token: str,
        is_final: bool,
        execution_id: str | None = None,
    ) -> int:
        """Emit a streaming token chunk to all project clients.

        Returns the number of clients that received the event.
        """
        chunk = StreamChunk(
            token=token,
            phase=phase,
            project=project,
            is_final=is_final,
            execution_id=execution_id,
        )
        return self._broadcast_event("stream_chunk", chunk.to_event_data(), project=project)

    def emit_checkpoint_suspend(
        self,
        checkpoint_id: str,
        phase: str,
        chapter: int | None,
        proposal_title: str,
        confidence: float,
        project: str,
        timeout_seconds: int | None = None,
    ) -> int:
        """Emit a checkpoint suspended event."""
        event = CheckpointSuspendEvent(
            checkpoint_id=checkpoint_id,
            phase=phase,
            chapter=chapter,
            proposal_title=proposal_title,
            confidence=confidence,
            project=project,
            timeout_seconds=timeout_seconds,
        )
        return self._broadcast_event("checkpoint_suspended", event.to_event_data(), project=project)

    def emit_checkpoint_decision(
        self,
        checkpoint_id: str,
        decision_type: str,
        project: str,
    ) -> int:
        """Emit a checkpoint decision resolved event."""
        event = CheckpointDecisionEvent(
            checkpoint_id=checkpoint_id,
            decision_type=decision_type,
            project=project,
        )
        return self._broadcast_event(
            "checkpoint_decision_resolved", event.to_event_data(), project=project
        )

    def emit_checkpoint_timeout(
        self,
        checkpoint_id: str,
        phase: str,
        project: str,
        timeout_seconds: int,
    ) -> int:
        """Emit a checkpoint timeout event."""
        event = CheckpointTimeoutEvent(
            checkpoint_id=checkpoint_id,
            phase=phase,
            project=project,
            timeout_seconds=timeout_seconds,
        )
        return self._broadcast_event(
            "checkpoint_timeout_auto_approved", event.to_event_data(), project=project
        )

    def emit_phase_event(
        self,
        project: str,
        phase: str,
        event_type: str,
        data: dict[str, Any],
    ) -> int:
        """Emit a generic phase event."""
        payload = {"phase": phase, **data}
        return self._broadcast_event(event_type, payload, project=project)

    def emit_status_change(
        self,
        project: str,
        execution_id: str,
        old_status: str,
        new_status: str,
    ) -> int:
        """Emit a status change event."""
        return self._broadcast_event(
            "status_change",
            {
                "execution_id": execution_id,
                "old_status": old_status,
                "new_status": new_status,
                "project": project,
            },
            project=project,
        )

    def _broadcast_event(
        self,
        event_type: str,
        data: dict[str, Any],
        project: str,
    ) -> int:
        """Broadcast an event via the attached WebSocket manager.

        Returns 0 if no manager is attached (no-op, no exception).
        """
        with self._lock:
            manager = self._ws_manager

        if manager is None:
            return 0

        try:
            from api.ws_types import EventType, RealtimeEvent

            event = RealtimeEvent(
                type=EventType(event_type),
                data=data,
                source=project,
            )
            return manager.broadcast_to_project(project, event)
        except Exception:
            return 0

    def has_ws_manager(self) -> bool:
        """Check if a WebSocket manager is attached."""
        with self._lock:
            return self._ws_manager is not None

    def get_connected_projects(self) -> list[str]:
        """Get list of projects with connected WebSocket clients."""
        with self._lock:
            manager = self._ws_manager

        if manager is None:
            return []

        try:
            return list(manager.project_connections.keys())
        except Exception:
            return []
