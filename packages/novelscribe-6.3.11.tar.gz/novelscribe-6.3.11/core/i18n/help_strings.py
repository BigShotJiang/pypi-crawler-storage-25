"""Localized help strings for the CLI."""

HELP_CATALOG: dict[str, dict[str, str]] = {
    "cli.description": {
        "en": "NovelScribe - AI-powered autonomous novel generation system.",
        "zh-CN": "NovelScribe - AI 驱动的自主小说创作系统。",
        "zh-TW": "NovelScribe - AI 驱動的自主小說創作系統。",
    },
    "section.workflow": {
        "en": "Workflow",
        "zh-CN": "工作流",
        "zh-TW": "工作流",
    },
    "section.utilities": {
        "en": "Utilities",
        "zh-CN": "工具",
        "zh-TW": "工具",
    },
    "opt.verbose": {
        "en": "Increase verbosity (can be used multiple times)",
        "zh-CN": "增加详细程度（可多次使用）",
        "zh-TW": "增加詳細程度（可多次使用）",
    },
    "opt.debug": {
        "en": "Enable debug mode",
        "zh-CN": "启用调试模式",
        "zh-TW": "啟用除錯模式",
    },
    "opt.lang": {
        "en": "Language (en, zh-CN, zh-TW). Overrides project META.yaml.",
        "zh-CN": "语言 (en, zh-CN, zh-TW)。覆盖项目 META.yaml 设置。",
        "zh-TW": "語言 (en, zh-CN, zh-TW)。覆蓋專案 META.yaml 設定。",
    },
    "opt.no_update_check": {
        "en": "Skip update check on startup",
        "zh-CN": "启动时跳过更新检查",
        "zh-TW": "啟動時跳過更新檢查",
    },
    "cmd.setup": {
        "en": "Configure API keys, provider, model, and language.",
        "zh-CN": "配置 API 密钥、提供商、模型和语言。",
        "zh-TW": "設定 API 金鑰、供應商、模型和語言。",
    },
    "cmd.new": {
        "en": "Initialize a new novel project.",
        "zh-CN": "初始化新小说项目。",
        "zh-TW": "初始化新小說專案。",
    },
    "cmd.outline": {
        "en": "Generate novel outline for project.",
        "zh-CN": "为项目生成小说大纲。",
        "zh-TW": "為專案生成小說大綱。",
    },
    "cmd.character": {
        "en": "Character archetype exploration and management commands.",
        "zh-CN": "角色原型探索与管理命令。",
        "zh-TW": "角色原型探索與管理命令。",
    },
    "cmd.write": {
        "en": "Write a specific chapter.",
        "zh-CN": "撰写指定章节。",
        "zh-TW": "撰寫指定章節。",
    },
    "cmd.status": {
        "en": "Show project status.",
        "zh-CN": "显示项目状态。",
        "zh-TW": "顯示專案狀態。",
    },
    "cmd.export": {
        "en": "Export novel to various formats.",
        "zh-CN": "将小说导出为各种格式。",
        "zh-TW": "將小說匯出為各種格式。",
    },
    "cmd.agents": {
        "en": "List and manage available agents.",
        "zh-CN": "列出和管理可用智能体。",
        "zh-TW": "列出和管理可用智慧代理。",
    },
    "cmd.workflows": {
        "en": "List and manage available workflows.",
        "zh-CN": "列出和管理可用工作流。",
        "zh-TW": "列出和管理可用工作流。",
    },
    "cmd.run": {
        "en": "Execute agents and workflows.",
        "zh-CN": "执行智能体和工作流。",
        "zh-TW": "執行智慧代理和工作流。",
    },
    "cmd.run_workflow": {
        "en": "Execute a workflow.",
        "zh-CN": "执行工作流。",
        "zh-TW": "執行工作流。",
    },
    "cmd.run_agent": {
        "en": "Execute an agent.",
        "zh-CN": "执行智能体。",
        "zh-TW": "執行智慧代理。",
    },
    "cmd.autonomous": {
        "en": "Autonomous novel generation commands.",
        "zh-CN": "自主小说生成命令。",
        "zh-TW": "自主小說生成命令。",
    },
    "cmd.autonomous_start": {
        "en": "Run autonomous novel generation pipeline.",
        "zh-CN": "运行自主小说生成流水线。",
        "zh-TW": "執行自主小說生成流水線。",
    },
    "cmd.review": {
        "en": "Editorial review pipeline — continuity, editorial, and humanization checks.",
        "zh-CN": "编辑审查流水线 — 连续性、编辑和拟人化检查。",
        "zh-TW": "編輯審查流水線 — 連續性、編輯和擬人化檢查。",
    },
    "cmd.review_start": {
        "en": "Run the editorial review pipeline for a project.",
        "zh-CN": "为项目运行编辑审查流水线。",
        "zh-TW": "為專案執行編輯審查流水線。",
    },
    "cmd.review_report": {
        "en": "Display review report.",
        "zh-CN": "显示审查报告。",
        "zh-TW": "顯示審查報告。",
    },
    "cmd.summary": {
        "en": "Summary system commands for managing novel summaries.",
        "zh-CN": "小说摘要管理命令。",
        "zh-TW": "小說摘要管理命令。",
    },
    "cmd.summary_generate": {
        "en": "Generate chapter summaries.",
        "zh-CN": "生成章节摘要。",
        "zh-TW": "生成章節摘要。",
    },
    "cmd.summary_group": {
        "en": "Generate group summary for a range of chapters.",
        "zh-CN": "为章节范围生成分组摘要。",
        "zh-TW": "為章節範圍生成分組摘要。",
    },
    "cmd.summary_update_global": {
        "en": "Update global summary with latest chapters.",
        "zh-CN": "用最新章节更新全局摘要。",
        "zh-TW": "用最新章節更新全局摘要。",
    },
    "cmd.summary_show": {
        "en": "Display summaries.",
        "zh-CN": "显示摘要。",
        "zh-TW": "顯示摘要。",
    },
    "cmd.summary_context": {
        "en": "Get summarized context for chapter generation.",
        "zh-CN": "获取用于章节生成的摘要上下文。",
        "zh-TW": "取得用於章節生成的摘要上下文。",
    },
    "cmd.summary_list": {
        "en": "List all summaries.",
        "zh-CN": "列出所有摘要。",
        "zh-TW": "列出所有摘要。",
    },
    "cmd.summary_stats": {
        "en": "Display summary statistics.",
        "zh-CN": "显示摘要统计。",
        "zh-TW": "顯示摘要統計。",
    },
    "cmd.summary_export": {
        "en": "Export all summaries to a single file.",
        "zh-CN": "将所有摘要导出到单个文件。",
        "zh-TW": "將所有摘要匯出到單一檔案。",
    },
    "cmd.config": {
        "en": "View and manage configuration.",
        "zh-CN": "查看和管理配置。",
        "zh-TW": "檢視和管理設定。",
    },
    "cmd.model": {
        "en": "Model management commands.",
        "zh-CN": "模型管理命令。",
        "zh-TW": "模型管理命令。",
    },
    "cmd.logs": {
        "en": "View logs, requests, and token usage.",
        "zh-CN": "查看日志、请求和令牌使用量。",
        "zh-TW": "檢視日誌、請求和令牌使用量。",
    },
    "cmd.memory": {
        "en": "Memory and knowledge management.",
        "zh-CN": "记忆和知识管理。",
        "zh-TW": "記憶和知識管理。",
    },
    "cmd.drafts": {
        "en": "Draft management commands.",
        "zh-CN": "草稿管理命令。",
        "zh-TW": "草稿管理命令。",
    },
    "cmd.verify": {
        "en": "Verification commands.",
        "zh-CN": "验证命令。",
        "zh-TW": "驗證命令。",
    },
    "cmd.qa": {
        "en": "Quality assurance commands.",
        "zh-CN": "质量保证命令。",
        "zh-TW": "品質保證命令。",
    },
    "cmd.checkpoint": {
        "en": "Checkpoint management commands.",
        "zh-CN": "检查点管理命令。",
        "zh-TW": "檢查點管理命令。",
    },
    "cmd.templates": {
        "en": "Template management commands.",
        "zh-CN": "模板管理命令。",
        "zh-TW": "模板管理命令。",
    },
    "cmd.project": {
        "en": "Project management commands.",
        "zh-CN": "项目管理命令。",
        "zh-TW": "專案管理命令。",
    },
    "cmd.paginate": {
        "en": "Pagination cache management.",
        "zh-CN": "分页缓存管理。",
        "zh-TW": "分頁快取管理。",
    },
    "cmd.cache": {
        "en": "Cache management commands.",
        "zh-CN": "缓存管理命令。",
        "zh-TW": "快取管理命令。",
    },
    "cmd.tui": {
        "en": "Terminal UI for interactive novel management.",
        "zh-CN": "交互式小说管理终端界面。",
        "zh-TW": "互動式小說管理終端介面。",
    },
    "cmd.version": {
        "en": "Show version information.",
        "zh-CN": "显示版本信息。",
        "zh-TW": "顯示版本資訊。",
    },
    "cmd.performance": {
        "en": "Performance analysis commands.",
        "zh-CN": "性能分析命令。",
        "zh-TW": "效能分析命令。",
    },
    "cmd.parallel": {
        "en": "Parallel execution commands.",
        "zh-CN": "并行执行命令。",
        "zh-TW": "並行執行命令。",
    },
    "cmd.guardrails": {
        "en": "Content guardrails management.",
        "zh-CN": "内容防护栏管理。",
        "zh-TW": "內容防護欄管理。",
    },
    "cmd.plugins": {
        "en": "Plugin management commands.",
        "zh-CN": "插件管理命令。",
        "zh-TW": "外掛管理命令。",
    },
    "cmd.benchmark": {
        "en": "Benchmark commands.",
        "zh-CN": "基准测试命令。",
        "zh-TW": "基準測試命令。",
    },
    "cmd.dashboard": {
        "en": "Dashboard commands.",
        "zh-CN": "仪表盘命令。",
        "zh-TW": "儀表板命令。",
    },
    "cmd.monitors": {
        "en": "Monitor management commands.",
        "zh-CN": "监控管理命令。",
        "zh-TW": "監控管理命令。",
    },
    "cmd.help": {
        "en": "Ask questions, get help, or start an interactive chat with AI.",
        "zh-CN": "提问、获取帮助或与 AI 开始交互式对话。",
        "zh-TW": "提問、取得幫助或與 AI 開始互動式對話。",
    },
    "cmd.proactive": {
        "en": "Proactive suggestion system.",
        "zh-CN": "主动建议系统。",
        "zh-TW": "主動建議系統。",
    },
    "opt.provider": {
        "en": "LLM provider to use",
        "zh-CN": "要使用的 LLM 提供商",
        "zh-TW": "要使用的 LLM 供應商",
    },
    "opt.model": {
        "en": "LLM model to use",
        "zh-CN": "要使用的 LLM 模型",
        "zh-TW": "要使用的 LLM 模型",
    },
    "opt.chapter": {
        "en": "Chapter number",
        "zh-CN": "章节编号",
        "zh-TW": "章節編號",
    },
    "opt.project_dir": {
        "en": "Base directory for projects",
        "zh-CN": "项目基础目录",
        "zh-TW": "專案基礎目錄",
    },
    "opt.novel": {
        "en": "Novel project name",
        "zh-CN": "小说项目名称",
        "zh-TW": "小說專案名稱",
    },
    "opt.skip_discuss": {
        "en": "Skip creative discussion (lightweight mode)",
        "zh-CN": "跳过创意讨论（轻量模式）",
        "zh-TW": "跳過創意討論（輕量模式）",
    },
    "opt.desc": {
        "en": "Brief concept description",
        "zh-CN": "简要概念描述",
        "zh-TW": "簡要概念描述",
    },
    "opt.concept_file": {
        "en": "File with initial novel concept/design (.md, .txt)",
        "zh-CN": "包含小说初始概念/设计的文件（.md, .txt）",
        "zh-TW": "包含小說初始概念/設計的檔案（.md, .txt）",
    },
    "opt.start_phase": {
        "en": "Phase to start from",
        "zh-CN": "起始阶段",
        "zh-TW": "起始階段",
    },
    "opt.end_phase": {
        "en": "Phase to end at",
        "zh-CN": "结束阶段",
        "zh-TW": "結束階段",
    },
    "opt.human_in_loop": {
        "en": "Enable human-in-the-loop checkpoints",
        "zh-CN": "启用人机协作检查点",
        "zh-TW": "啟用人機協作檢查點",
    },
    "opt.max_chapters": {
        "en": "Maximum number of chapters to generate",
        "zh-CN": "最大生成章节数",
        "zh-TW": "最大生成章節數",
    },
    "opt.quick": {
        "en": "Continuity check only (skip editor and humanizer passes)",
        "zh-CN": "仅检查连续性（跳过编辑和拟人化）",
        "zh-TW": "僅檢查連續性（跳過編輯和擬人化）",
    },
    "opt.fix": {
        "en": "Apply auto-fixable issues after review",
        "zh-CN": "审查后自动修复可修复的问题",
        "zh-TW": "審查後自動修復可修復的問題",
    },
    "opt.skip_existing": {
        "en": "Skip chapters that already have summaries",
        "zh-CN": "跳过已有摘要的章节",
        "zh-TW": "跳過已有摘要的章節",
    },
    "err.no_command": {
        "en": "No such command '{name}'.",
        "zh-CN": "没有名为 '{name}' 的命令。",
        "zh-TW": "沒有名為 '{name}' 的命令。",
    },
    "err.did_you_mean": {
        "en": "Did you mean one of these?",
        "zh-CN": "您是指以下命令之一吗？",
        "zh-TW": "您是指以下命令之一嗎？",
    },
    "err.usage": {
        "en": "Run 'scribe help' to see available commands.",
        "zh-CN": "运行 'scribe help' 查看可用命令。",
        "zh-TW": "執行 'scribe help' 檢視可用命令。",
    },
    "err.unexpected": {
        "en": "Unexpected error: {msg}",
        "zh-CN": "意外错误: {msg}",
        "zh-TW": "意外錯誤: {msg}",
    },
    "err.cancelled": {
        "en": "Operation cancelled by user.",
        "zh-CN": "用户已取消操作。",
        "zh-TW": "使用者已取消操作。",
    },
    "err.usage_prefix": {
        "en": "Usage Error: {msg}",
        "zh-CN": "用法错误: {msg}",
        "zh-TW": "用法錯誤: {msg}",
    },
    "msg.see_help": {
        "en": "Run 'scribe help' to see available commands.",
        "zh-CN": "运行 'scribe help' 查看可用命令。",
        "zh-TW": "執行 'scribe help' 檢視可用命令。",
    },
    "msg.verbose_hint": {
        "en": "Run with -v or -vv for more verbose output.",
        "zh-CN": "使用 -v 或 -vv 获取更详细的输出。",
        "zh-TW": "使用 -v 或 -vv 取得更詳細的輸出。",
    },
}


def get_help_string(key: str, lang: str, fallback: str = "") -> str:
    """Get a localized help string by key and language.

    Falls back to English if the key or language is missing,
    then to *fallback* if the key itself is absent.
    """
    entry = HELP_CATALOG.get(key)
    if entry is None:
        return fallback
    return entry.get(lang) or entry.get("en") or fallback
