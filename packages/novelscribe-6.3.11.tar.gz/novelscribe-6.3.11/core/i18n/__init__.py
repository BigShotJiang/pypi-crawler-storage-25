"""Internationalization subsystem — language configuration and resolution."""

from .config import (
    LanguageCode,
    LanguageConfig,
    LanguageResolver,
    get_current_language,
    is_supported_language,
)
from .help_strings import HELP_CATALOG, get_help_string

__all__ = [
    "HELP_CATALOG",
    "LanguageCode",
    "LanguageConfig",
    "LanguageResolver",
    "get_current_language",
    "get_help_string",
    "is_supported_language",
]
