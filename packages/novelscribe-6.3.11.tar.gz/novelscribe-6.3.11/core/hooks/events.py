"""Canonical hook events and typed event payload."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class HookEvent(str, Enum):
    """Canonical event names emitted by workflow/runtime pipelines."""

    WORKFLOW_BEFORE_STEP = "workflow.before_step"
    WORKFLOW_AFTER_STEP = "workflow.after_step"
    WORKFLOW_STEP_FAILED = "workflow.step_failed"
    RUNTIME_BEFORE_TURN = "runtime.before_turn"
    RUNTIME_AFTER_TURN = "runtime.after_turn"
    RUNTIME_TURN_FAILED = "runtime.turn_failed"
    PIPELINE_SUCCESS = "pipeline.success"
    PIPELINE_FAILURE = "pipeline.failure"
    MONITOR_TRIGGER = "monitor.trigger"


class HookEventPayload(BaseModel):
    """Typed payload passed to hook handlers for one event."""

    event: str
    context_id: str | None = None
    context_status: str | None = None
    context_step_name: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
