"""core.templates — template management subsystem."""

from core.templates.embedding import TemplateEmbeddingIndex
from core.templates.kb import (
    GlobalTemplateWikiStore,
    TemplateHit,
    TemplateWikiRetriever,
    _LoadedPage,
)
from core.templates.loader import TemplateLoader
from core.templates.outcome_tracker import TemplateOutcomeTracker
from core.templates.schema_versions import (
    AgentParser,
    AgentParseResult,
    SchemaVersionRegistry,
    WorkflowParser,
    WorkflowParseResult,
    parse_agent_v1,
    parse_workflow_v1,
)
from core.templates.step_loader import StepTemplate, StepTemplateLoader, StepTemplateParameter

__all__ = [
    "AgentParseResult",
    "AgentParser",
    "GlobalTemplateWikiStore",
    "SchemaVersionRegistry",
    "StepTemplate",
    "StepTemplateLoader",
    "StepTemplateParameter",
    "TemplateEmbeddingIndex",
    "TemplateHit",
    "TemplateLoader",
    "TemplateOutcomeTracker",
    "TemplateWikiRetriever",
    "WorkflowParseResult",
    "WorkflowParser",
    "_LoadedPage",
    "parse_agent_v1",
    "parse_workflow_v1",
]
