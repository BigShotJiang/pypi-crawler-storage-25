"""Exporter orchestrator — compiles a manuscript and renders it to the requested format."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from core.exporter.compiler import Manuscript, ManuscriptCompiler
from core.exporter.options import EpubOptions, PdfOptions
from core.exporter.renderers import RendererFactory


class ExportResult:
    """Outcome of a single export operation."""

    def __init__(
        self,
        output_path: Path,
        format_name: str,
        manuscript: Manuscript,
    ) -> None:
        self.output_path = output_path
        self.format_name = format_name
        self.manuscript = manuscript

    @property
    def file_size_bytes(self) -> int:
        return self.output_path.stat().st_size if self.output_path.exists() else 0


class Exporter:
    """High-level facade that compiles a project and renders it to a chosen format.

    Usage::

        exporter = Exporter(novels_dir=Path(".novels"))
        result = exporter.export("my_novel", fmt="pdf", output_dir=Path("output"))
    """

    def __init__(self, novels_dir: Optional[Path] = None) -> None:
        self._compiler = ManuscriptCompiler(novels_dir=novels_dir)
        self._novels_dir = novels_dir or Path(".novels")

    def export(
        self,
        project_name: str,
        fmt: str = "pdf",
        output_dir: Optional[Path] = None,
        cover_image: Optional[Path] = None,
        include_appendices: bool = False,
        epub_options: Optional[EpubOptions] = None,
        pdf_options: Optional[PdfOptions] = None,
        preset: Optional[str] = None,
        **kwargs: Any,
    ) -> ExportResult:
        """Compile and render a project to the specified format.

        Args:
            project_name: Project directory name under ``.novels/``.
            fmt: Output format (``pdf``, ``epub``, ``docx``, ``md``).
            output_dir: Destination directory. Defaults to
                ``.novels/<project>/exports/``.
            cover_image: Optional cover image path.
            include_appendices: Whether to include character list, world
                glossary, and chapter summary appendices.
            epub_options: Optional EPUB-specific rendering options.
            pdf_options: Optional PDF-specific rendering options.
            preset: Optional platform preset name.
            **kwargs: Additional renderer-specific keyword arguments.

        Returns:
            ``ExportResult`` with the output path and manuscript metadata.
        """
        if preset:
            epub_options, pdf_options = self._apply_preset(preset, epub_options, pdf_options)

        manuscript = self._compiler.compile(project_name, include_appendices=include_appendices)

        renderer = RendererFactory.get(fmt)
        out_dir = output_dir or (self._novels_dir / project_name / "exports")
        output_path = out_dir / f"{project_name}.{fmt}"

        render_kwargs: dict[str, Any] = {"cover_image": cover_image}
        if epub_options and fmt == "epub":
            render_kwargs["epub_options"] = epub_options
            if epub_options.cover_image:
                render_kwargs["cover_image"] = epub_options.cover_image
        if pdf_options and fmt == "pdf":
            render_kwargs["pdf_options"] = pdf_options

        renderer.render(manuscript, output_path, **render_kwargs)

        return ExportResult(
            output_path=output_path,
            format_name=fmt,
            manuscript=manuscript,
        )

    def _apply_preset(
        self,
        preset_name: str,
        epub_opts: Optional[EpubOptions],
        pdf_opts: Optional[PdfOptions],
    ) -> tuple[Optional[EpubOptions], Optional[PdfOptions]]:
        from core.exporter.presets import PresetRegistry

        preset = PresetRegistry.get(preset_name)
        if preset.pdf_options and not pdf_opts:
            pdf_opts = preset.pdf_options
        if preset.epub_options and not epub_opts:
            epub_opts = preset.epub_options
        return epub_opts, pdf_opts

    @staticmethod
    def available_formats() -> list[str]:
        """Return the list of formats that have their dependencies installed."""
        return RendererFactory.available_formats()
