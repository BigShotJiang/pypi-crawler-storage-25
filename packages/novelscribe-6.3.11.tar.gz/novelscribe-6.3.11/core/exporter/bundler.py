"""Chapter bundler — multi-format batch export in a single call."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from core.exporter.exporter import Exporter, ExportResult
from core.exporter.options import EpubOptions, PdfOptions


@dataclass
class ExportSpec:
    """Per-format export specification."""

    project_name: str
    fmt: str
    output_dir: Optional[Path] = None
    cover_image: Optional[Path] = None
    include_appendices: bool = False
    preset: Optional[str] = None
    pdf_options: Optional[PdfOptions] = None
    epub_options: Optional[EpubOptions] = None


@dataclass
class ExportBundle:
    """Collection of export results from a batch operation."""

    outputs: list[ExportResult] = field(default_factory=list)
    preset: Optional[str] = None

    @property
    def formats(self) -> list[str]:
        return [r.format_name for r in self.outputs]

    @property
    def total_size_bytes(self) -> int:
        return sum(r.file_size_bytes for r in self.outputs)

    @property
    def manifest(self) -> dict[str, str]:
        return {r.format_name: r.output_path.name for r in self.outputs}


class ChapterBundler:
    """Export a manuscript to multiple formats in one operation."""

    def __init__(self, novels_dir: Optional[Path] = None) -> None:
        self._exporter = Exporter(novels_dir=novels_dir)

    def export_all(
        self,
        project_name: str,
        formats: Optional[list[str]] = None,
        output_dir: Optional[Path] = None,
        cover_image: Optional[Path] = None,
        include_appendices: bool = False,
        preset: Optional[str] = None,
        epub_options: Optional[EpubOptions] = None,
        pdf_options: Optional[PdfOptions] = None,
    ) -> ExportBundle:
        """Export to all (or specified) formats in one call."""
        target_formats = formats or self._exporter.available_formats()
        results: list[ExportResult] = []

        for fmt in target_formats:
            result = self._exporter.export(
                project_name,
                fmt=fmt,
                output_dir=output_dir,
                cover_image=cover_image,
                include_appendices=include_appendices,
                preset=preset,
                epub_options=epub_options,
                pdf_options=pdf_options,
            )
            results.append(result)

        return ExportBundle(outputs=results, preset=preset)

    def export_batch(
        self,
        specs: list[ExportSpec],
    ) -> ExportBundle:
        """Export with per-format specifications."""
        results: list[ExportResult] = []
        for spec in specs:
            result = self._exporter.export(
                spec.project_name,
                fmt=spec.fmt,
                output_dir=spec.output_dir,
                cover_image=spec.cover_image,
                include_appendices=spec.include_appendices,
                preset=spec.preset,
                epub_options=spec.epub_options,
                pdf_options=spec.pdf_options,
            )
            results.append(result)

        return ExportBundle(outputs=results)
