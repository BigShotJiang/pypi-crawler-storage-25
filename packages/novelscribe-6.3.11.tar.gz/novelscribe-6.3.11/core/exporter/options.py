"""Export options dataclasses — configurable parameters for each renderer."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class EpubOptions:
    """Options for EPUB3 renderer."""

    cover_image: Optional[Path] = None
    custom_toc: Optional[list[str]] = None
    isbn: Optional[str] = None
    language: str = "en"
    publisher: Optional[str] = None
    series_name: Optional[str] = None
    series_index: Optional[int] = None
    rights: Optional[str] = None
    include_landmarks: bool = True


@dataclass
class PdfOptions:
    """Options for PDF renderer."""

    page_size: str = "letter"
    custom_size: Optional[tuple[float, float]] = None
    margin_top: float = 25.4
    margin_bottom: float = 25.4
    margin_left: float = 25.4
    margin_right: float = 25.4
    font_body: str = "Helvetica"
    font_heading: str = "Helvetica"
    font_size_body: float = 11.0
    font_size_heading: float = 16.0
    line_spacing: float = 1.5
    header_text: Optional[str] = None
    footer_text: Optional[str] = None
    show_page_numbers: bool = True
    page_number_position: str = "center"
    chapter_page_break: bool = True
    first_page_special: bool = True
    toc: bool = True

    PAGE_SIZES: dict[str, tuple[float, float]] = field(
        default_factory=lambda: {
            "letter": (215.9, 279.4),
            "a4": (210.0, 297.0),
            "a5": (148.0, 210.0),
            "6x9": (152.4, 228.6),
        }
    )

    def get_page_size_mm(self) -> tuple[float, float]:
        """Return (width, height) in mm."""
        if self.custom_size:
            return self.custom_size
        return self.PAGE_SIZES.get(self.page_size, self.PAGE_SIZES["letter"])
