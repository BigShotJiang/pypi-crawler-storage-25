"""Checkpoint decision flow for autonomous phase execution."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from core.autonomous._checkpoint import CheckpointHandler
from core.autonomous.models import AutonomousResult
from core.autonomous.progress_tracker import ExecutionStatus

if TYPE_CHECKING:
    from core.autonomous.pipeline_suspender import PipelineSuspender
    from core.orchestration.autonomous import AutonomousExecutor
    from core.streaming.event_bus import PipelineEventBus


class CheckpointFlow:
    """Coordinates phase-level checkpoint decisions."""

    def __init__(
        self,
        executor: "AutonomousExecutor",
        checkpoint_handler: CheckpointHandler,
        event_bus: "PipelineEventBus | None" = None,
    ) -> None:
        self._executor = executor
        self._checkpoint_handler = checkpoint_handler
        self._event_bus = event_bus

    def should_suspend(
        self,
        phase: str,
        human_in_loop: bool,
    ) -> bool:
        """Return True when pipeline should suspend for async approval.

        Conditions:
        - human_in_loop is True
        - Event bus has a WebSocket manager attached (clients connected)
        - Phase has checkpoints enabled (nontrivial phase names)
        """
        if not human_in_loop:
            return False
        if self._event_bus is None:
            return False
        if not self._event_bus.has_ws_manager():
            return False
        return self._is_checkpoint_phase(phase)

    def handle_phase_entry(
        self,
        workflow_name: str,
        current_chapter: Optional[int],
        execution_context: dict[str, Any],
        completed_phases: list[str],
        include_legacy: bool,
    ) -> Optional[AutonomousResult]:
        """Handle all checkpoint hooks before phase execution."""
        executor = self._executor
        if include_legacy and executor.human_handler:
            result = self._handle_legacy_human_checkpoint(
                workflow_name,
                execution_context,
                completed_phases,
            )
            if result is not None:
                return result

        if executor.checkpoint_orchestrator:
            chapter_for_checkpoint = None
            if workflow_name in ("chapter_plan_phase", "writing_phase"):
                chapter_for_checkpoint = current_chapter
            result = self._handle_orchestrated_checkpoint(
                workflow_name,
                chapter_for_checkpoint,
                execution_context,
                completed_phases,
            )
            if result is not None:
                return result
        return None

    def _handle_legacy_human_checkpoint(
        self,
        workflow_name: str,
        execution_context: dict[str, Any],
        completed_phases: list[str],
    ) -> Optional[AutonomousResult]:
        executor = self._executor
        assert executor.human_handler is not None
        if not executor.human_handler.should_pause_at_phase(
            workflow_name,
            executor.LEGACY_HUMAN_CHECKPOINTS,
        ):
            return None

        checkpoint = executor.human_handler.get_checkpoint_for_phase(
            workflow_name,
            executor.LEGACY_HUMAN_CHECKPOINTS,
        )
        if not checkpoint:
            return None

        decision = executor.human_handler.handle_checkpoint(checkpoint)
        if not decision.approved:
            executor.logger.info("Execution stopped by user")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                error="Stopped by user at checkpoint",
            )

        if decision.input:
            execution_context["user_input"] = decision.input
        if decision.modifications:
            execution_context.update(decision.modifications)
        return None

    def _handle_orchestrated_checkpoint(
        self,
        workflow_name: str,
        chapter_for_checkpoint: Optional[int],
        execution_context: dict[str, Any],
        completed_phases: list[str],
    ) -> Optional[AutonomousResult]:
        executor = self._executor
        assert executor.checkpoint_orchestrator is not None

        if not executor.checkpoint_orchestrator.should_pause_at_phase(
            workflow_name,
            chapter_for_checkpoint,
        ):
            return None

        checkpoint_result = executor._present_checkpoint(
            workflow_name,
            chapter_for_checkpoint,
            execution_context,
        )
        if checkpoint_result is None:
            executor.logger.info("Execution paused at checkpoint (waiting for input)")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                checkpoint_id=executor.checkpoint_orchestrator.get_checkpoint_id(
                    workflow_name,
                    chapter_for_checkpoint,
                ),
            )

        if checkpoint_result.get("status") == "rejected":
            executor.logger.info("Execution rejected by human at checkpoint")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                error="Rejected by human at checkpoint",
                checkpoint_id=checkpoint_result.get("checkpoint_id"),
            )

        if checkpoint_result.get("modified_content"):
            execution_context["checkpoint_modifications"] = checkpoint_result["modified_content"]
        if checkpoint_result.get("guidance"):
            execution_context["human_guidance"] = checkpoint_result["guidance"]
        return None

    def _is_checkpoint_phase(self, phase: str) -> bool:
        """Check if a phase should trigger a checkpoint."""
        return phase in {
            "new_novel",
            "worldbuilding_phase",
            "character_phase",
            "outline_phase",
            "chapter_plan_phase",
            "writing_phase",
            "continuity_phase",
        }

    async def handle_async_checkpoint(
        self,
        workflow_name: str,
        chapter_for_checkpoint: int | None,
        execution_context: dict[str, Any],
        completed_phases: list[str],
        suspender: "PipelineSuspender",
        project: str,
    ) -> Optional[AutonomousResult]:
        """Handle checkpoint with async suspend/resume (GAP-4.1)."""
        executor = self._executor

        if not executor.checkpoint_orchestrator.should_pause_at_phase(
            workflow_name,
            chapter_for_checkpoint,
        ):
            return None

        checkpoint_result = executor._present_checkpoint(
            workflow_name,
            chapter_for_checkpoint,
            execution_context,
        )
        if checkpoint_result is None:
            return None

        proposal = checkpoint_result.get("proposal")
        if proposal is None:
            return None

        checkpoint_id = suspender._orchestrator.get_checkpoint_id(
            workflow_name,
            chapter_for_checkpoint,
        )

        await suspender.suspend(
            phase=workflow_name,
            chapter=chapter_for_checkpoint,
            proposal=proposal,
            project=project,
        )

        decision = await suspender.await_decision(checkpoint_id)
        if decision is None:
            return None

        if decision.get("decision_type") == "reject":
            executor.logger.info("Execution rejected by human at checkpoint")
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            return AutonomousResult(
                success=False,
                completed_phases=completed_phases,
                final_status=ExecutionStatus.PAUSED,
                error="Rejected by human at checkpoint",
                checkpoint_id=checkpoint_id,
            )

        if decision.get("modified_content"):
            execution_context["checkpoint_modifications"] = decision["modified_content"]
        if decision.get("guidance"):
            execution_context["human_guidance"] = decision["guidance"]

        return None
