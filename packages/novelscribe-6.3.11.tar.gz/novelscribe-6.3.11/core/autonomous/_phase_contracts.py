"""Phase output contracts for autonomous pipeline quality gates."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class ContractCheckResult:
    """Result of validating phase output against lightweight contracts."""

    passed: bool
    failed_rules: list[str]
    hints: list[str]


def evaluate_phase_contract(
    *,
    workflow_name: str,
    project_root: Path,
) -> ContractCheckResult:
    """Validate output artifacts for selected autonomous phases."""
    if workflow_name == "outline_phase":
        return _check_outline_phase(project_root)
    if workflow_name == "character_phase":
        return _check_character_phase(project_root)
    if workflow_name == "writing_phase":
        return _check_writing_phase(project_root)
    return ContractCheckResult(passed=True, failed_rules=[], hints=[])


def _check_outline_phase(project_root: Path) -> ContractCheckResult:
    outline_path = project_root / "OUTLINE.md"
    failed_rules: list[str] = []
    hints: list[str] = []

    if not outline_path.exists():
        failed_rules.append("outline.file_exists")
        hints.append("Create OUTLINE.md for outline_phase output.")
        return ContractCheckResult(False, failed_rules, hints)

    content = outline_path.read_text(encoding="utf-8").strip()
    if not content:
        failed_rules.append("outline.non_empty")
        hints.append("Populate OUTLINE.md with chapter-level plan content.")
        return ContractCheckResult(False, failed_rules, hints)

    if "chapter" not in content.lower():
        failed_rules.append("outline.chapter_mentions")
        hints.append("Include explicit chapter planning entries in OUTLINE.md.")

    if not re.search(r"^#{1,3}\s+\S+", content, flags=re.MULTILINE):
        failed_rules.append("outline.has_headings")
        hints.append("Add Markdown headings to structure OUTLINE.md.")

    return ContractCheckResult(
        passed=len(failed_rules) == 0,
        failed_rules=failed_rules,
        hints=hints,
    )


def _check_character_phase(project_root: Path) -> ContractCheckResult:
    character_path = project_root / "CHARACTERS.md"
    failed_rules: list[str] = []
    hints: list[str] = []

    if not character_path.exists():
        failed_rules.append("characters.file_exists")
        hints.append("Create CHARACTERS.md for character_phase output.")
        return ContractCheckResult(False, failed_rules, hints)

    content = character_path.read_text(encoding="utf-8").strip()
    if not content:
        failed_rules.append("characters.non_empty")
        hints.append("Populate CHARACTERS.md with character entries.")
        return ContractCheckResult(False, failed_rules, hints)

    if not re.search(r"^##\s+\S+", content, flags=re.MULTILINE):
        failed_rules.append("characters.has_entries")
        hints.append("Use level-2 headings for character sections in CHARACTERS.md.")

    if "goal" not in content.lower() and "motivation" not in content.lower():
        failed_rules.append("characters.has_motivation_field")
        hints.append("Add goal/motivation details to character entries.")

    return ContractCheckResult(
        passed=len(failed_rules) == 0,
        failed_rules=failed_rules,
        hints=hints,
    )


def _check_writing_phase(project_root: Path) -> ContractCheckResult:
    chapters_dir = project_root / "chapters"
    failed_rules: list[str] = []
    hints: list[str] = []

    if not chapters_dir.exists():
        failed_rules.append("writing.chapters_dir_exists")
        hints.append("Create chapters/ directory with chapter markdown files.")
        return ContractCheckResult(False, failed_rules, hints)

    chapter_files = sorted(chapters_dir.glob("chapter_*.md"))
    if not chapter_files:
        failed_rules.append("writing.chapter_files_exist")
        hints.append("Generate at least one chapter_XXX.md file in chapters/.")
        return ContractCheckResult(False, failed_rules, hints)

    sample = chapter_files[-1].read_text(encoding="utf-8").strip()
    if not sample:
        failed_rules.append("writing.latest_chapter_non_empty")
        hints.append("Ensure generated chapter file contains narrative content.")
    elif not sample.startswith("#"):
        failed_rules.append("writing.latest_chapter_has_heading")
        hints.append("Start chapter markdown with a heading for structure.")

    return ContractCheckResult(
        passed=len(failed_rules) == 0,
        failed_rules=failed_rules,
        hints=hints,
    )


def build_contract_repair_payload(
    *,
    workflow_name: str,
    failed_rules: list[str],
    hints: list[str],
) -> dict[str, Any]:
    """Build normalized repair context passed into workflow retry execution."""
    return {
        "phase": workflow_name,
        "failed_rules": failed_rules,
        "hints": hints,
        "retry_reason": "phase_output_contract",
    }
