"""Autonomous pipeline runner — the orchestrating loop for novel generation.

Extracted from AutonomousPhaseRunner. This is the top-level orchestrator:
workflow entry → phase loop → checkpoint → context snapshot → git commit → revision.

Interface:
    run_full_pipeline(
        executor,                    # anything with executor-like interface
        checkpoint_flow,             # CheckpointFlowProtocol
        workflow_executor,           # WorkflowExecutorProtocol
        kb_recommendation_fn,        # (workflow_name: str) -> list[str]
        revision_fn,                 # (workflow_name, chapter) -> None
        include_legacy,              # bool — include human-in-the-loop checkpoints
    ) -> AutonomousResult
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Protocol

from core.autonomous._phase_contracts import (
    build_contract_repair_payload,
    evaluate_phase_contract,
)
from core.autonomous.models import AutonomousResult
from core.autonomous.progress_tracker import ExecutionStatus
from core.context.phase_cache import PhaseContextCache
from core.logging.structured import bind_phase, bind_step
from core.metrics import PhaseTimer
from core.metrics.collector import MetricsCollector

_PIPELINE_STATE_VERSION = 1

if TYPE_CHECKING:
    pass


class WorkflowExecutorProtocol(Protocol):
    """Minimal protocol for WorkflowExecutor — avoids import cycles."""

    def execute_workflow(
        self,
        workflow_name: str,
        project_name: str,
        variables: dict[str, Any],
        config: dict[str, Any],
    ) -> dict[str, Any]: ...


class CheckpointFlowProtocol(Protocol):
    """Minimal protocol for CheckpointFlow — avoids import cycles."""

    def handle_phase_entry(
        self,
        workflow_name: str,
        current_chapter: Optional[int],
        execution_context: dict[str, Any],
        completed_phases: list[str],
        include_legacy: bool,
    ) -> Optional[AutonomousResult]: ...


def _run_phase_contract_check(
    *,
    executor: Any,
    workflow_name: str,
    execution_context: dict[str, Any],
    workflow_executor: WorkflowExecutorProtocol,
) -> tuple[bool, dict[str, Any]]:
    """Run phase contracts with a single repair retry."""
    if not getattr(executor.config, "enable_artifact_contracts", False):
        return True, {}

    project_root = executor.storage_path / executor.config.project_name
    contract_result = evaluate_phase_contract(
        workflow_name=workflow_name,
        project_root=project_root,
    )
    if contract_result.passed:
        MetricsCollector().phase_count.inc(f"{workflow_name}_contract_pass")
        return True, {}

    MetricsCollector().phase_count.inc(f"{workflow_name}_contract_fail")
    executor.logger.warning(
        "⚠️  Contract failed for %s: %s",
        workflow_name,
        contract_result.failed_rules,
    )
    repair_payload = build_contract_repair_payload(
        workflow_name=workflow_name,
        failed_rules=contract_result.failed_rules,
        hints=contract_result.hints,
    )
    retry_count = int(execution_context.get("contract_retry_count", 0))
    retry_limit = int(getattr(executor.config, "contract_retry_limit", 1))
    if retry_count >= retry_limit:
        failure = {
            "phase": workflow_name,
            "failed_rules": contract_result.failed_rules,
            "hints": contract_result.hints,
        }
        execution_context["contract_failure"] = failure
        return False, failure

    execution_context["contract_repair"] = repair_payload
    execution_context["contract_retry_count"] = retry_count + 1

    with PhaseTimer(f"{workflow_name}_contract_repair"):
        bind_step("contract_repair")
        workflow_executor.execute_workflow(
            workflow_name=workflow_name,
            project_name=executor.config.project_name,
            variables=execution_context,
            config=executor.llm_config.model_dump(),
        )

    recheck = evaluate_phase_contract(
        workflow_name=workflow_name,
        project_root=project_root,
    )
    if recheck.passed:
        execution_context.pop("contract_repair", None)
        MetricsCollector().phase_count.inc(f"{workflow_name}_contract_repair_ok")
        return True, {}

    failure = {
        "phase": workflow_name,
        "failed_rules": recheck.failed_rules,
        "hints": recheck.hints,
    }
    execution_context["contract_failure"] = failure
    return False, failure


def _handle_chapter1_anchor_checkpoint(
    executor: Any,
    execution_context: dict[str, Any],
    completed_phases: list[str],
) -> Optional[AutonomousResult]:
    """Enforce a hard approval gate before continuing writing execution."""
    if execution_context.get("chapter1_anchor_approved"):
        return None

    execution_mode = getattr(executor.config, "execution_mode", "safe")
    execution_context["execution_mode"] = execution_mode

    if execution_mode == "fast":
        executor.logger.warning(
            "⚠️  Fast execution mode may increase chapter style variance after Chapter 1"
        )

    # Hard checkpoint only applies when human-in-loop is enabled.
    if not getattr(executor.config, "human_in_loop", False):
        execution_context["chapter1_anchor_approved"] = True
        return None

    orchestrator = getattr(executor, "checkpoint_orchestrator", None)
    if orchestrator is None:
        execution_context["chapter1_anchor_approved"] = True
        return None

    checkpoint_result = executor._present_checkpoint(
        workflow_name="writing_phase",
        chapter=1,
        execution_context=execution_context,
    )

    if checkpoint_result is None:
        executor.logger.info("Execution paused at Chapter 1 anchor checkpoint (waiting for input)")
        MetricsCollector().phase_count.inc("chapter1_anchor_pause")
        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
        checkpoint_id = orchestrator.get_checkpoint_id("writing_phase", 1)
        return AutonomousResult(
            success=False,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.PAUSED,
            checkpoint_id=checkpoint_id,
        )

    if checkpoint_result.get("status") in {"rejected", "reject"}:
        executor.logger.info("Execution rejected by human at Chapter 1 anchor checkpoint")
        MetricsCollector().phase_count.inc("chapter1_anchor_reject")
        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
        return AutonomousResult(
            success=False,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.PAUSED,
            error="Rejected by human at Chapter 1 anchor checkpoint",
            checkpoint_id=checkpoint_result.get("checkpoint_id"),
        )

    if checkpoint_result.get("modified_content"):
        execution_context["checkpoint_modifications"] = checkpoint_result["modified_content"]
    if checkpoint_result.get("guidance"):
        execution_context["human_guidance"] = checkpoint_result["guidance"]

    execution_context["chapter1_anchor_approved"] = True
    MetricsCollector().phase_count.inc("chapter1_anchor_approve")
    return None


def _handle_pre_writing_checkpoint(
    executor: Any,
    execution_context: dict[str, Any],
    completed_phases: list[str],
) -> Optional[AutonomousResult]:
    """Run a one-time 5-point alignment checkpoint before writing execution."""
    if execution_context.get("pre_writing_checkpoint_approved"):
        return None

    execution_mode = getattr(executor.config, "execution_mode", "safe")
    execution_context["execution_mode"] = execution_mode

    # Ensure this checkpoint is always resumable; if human loop is disabled, auto-approve.
    if not getattr(executor.config, "human_in_loop", False):
        execution_context["pre_writing_checkpoint_approved"] = True
        execution_context["pre_writing_decision"] = {
            "decision_type": "auto_approve",
            "items": "outline|character|lore|chapter_strategy|execution_mode",
        }
        return None

    checkpoint_result = executor._present_checkpoint(
        workflow_name="pre_writing_checkpoint",
        chapter=None,
        execution_context=execution_context,
    )
    if checkpoint_result is None:
        executor.logger.info("Execution paused at pre-writing checkpoint (waiting for input)")
        MetricsCollector().phase_count.inc("pre_writing_checkpoint_pause")
        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
        checkpoint_id = "cp_pre_writing_checkpoint"
        orchestrator = getattr(executor, "checkpoint_orchestrator", None)
        if orchestrator is not None:
            checkpoint_id = orchestrator.get_checkpoint_id("pre_writing_checkpoint", None)
        return AutonomousResult(
            success=False,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.PAUSED,
            checkpoint_id=checkpoint_id,
        )

    if checkpoint_result.get("status") in {"rejected", "reject"}:
        executor.logger.info("Execution rejected by human at pre-writing checkpoint")
        MetricsCollector().phase_count.inc("pre_writing_checkpoint_reject")
        executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
        return AutonomousResult(
            success=False,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.PAUSED,
            error="Rejected by human at pre-writing checkpoint",
            checkpoint_id=checkpoint_result.get("checkpoint_id"),
        )

    execution_context["pre_writing_checkpoint_approved"] = True
    MetricsCollector().phase_count.inc("pre_writing_checkpoint_approve")
    execution_context["pre_writing_decision"] = {
        "decision_type": checkpoint_result.get("status", "approved"),
        "items": "outline|character|lore|chapter_strategy|execution_mode",
    }
    if checkpoint_result.get("modified_content"):
        execution_context["checkpoint_modifications"] = checkpoint_result["modified_content"]
    if checkpoint_result.get("guidance"):
        execution_context["human_guidance"] = checkpoint_result["guidance"]
    return None


def _run_phase_once(
    executor: Any,
    workflow_name: str,
    checkpoint_flow: CheckpointFlowProtocol,
    workflow_executor: WorkflowExecutorProtocol,
    execution_context: dict[str, Any],
    completed_phases: list[str],
    current_chapter: Optional[int],
    include_legacy: bool,
) -> tuple[Optional[AutonomousResult], Optional[int]]:
    """Run a single phase: handle entry → KB → execute → checkpoint → snapshot → git → revision.

    Returns (early_return, updated_current_chapter).
    early_return is non-None when the checkpoint flow returned a result (early exit).
    """
    phase_cache = PhaseContextCache()
    bind_phase(workflow_name)
    bind_step("start")
    try:
        try:
            phase_cache.preload(executor.context_bus.store)
        except Exception:
            executor.logger.debug("Phase cache preload failed, continuing without cache")
        executor.context_bus.phase_cache = phase_cache

        if workflow_name == "writing_phase":
            pre_writing_result = _handle_pre_writing_checkpoint(
                executor=executor,
                execution_context=execution_context,
                completed_phases=completed_phases,
            )
            if pre_writing_result is not None:
                return pre_writing_result, current_chapter

            anchor_result = _handle_chapter1_anchor_checkpoint(
                executor=executor,
                execution_context=execution_context,
                completed_phases=completed_phases,
            )
            if anchor_result is not None:
                return anchor_result, current_chapter

        checkpoint_result = checkpoint_flow.handle_phase_entry(
            workflow_name=workflow_name,
            current_chapter=current_chapter,
            execution_context=execution_context,
            completed_phases=completed_phases,
            include_legacy=include_legacy,
        )
        if checkpoint_result is not None:
            return checkpoint_result, current_chapter

        from core.autonomous._phase_runner import AutonomousPhaseRunner

        AutonomousPhaseRunner._run_kb_recommendation_static(executor, workflow_name)

        with PhaseTimer(workflow_name):
            bind_step("execute")
            result = workflow_executor.execute_workflow(
                workflow_name=workflow_name,
                project_name=executor.config.project_name,
                variables=execution_context,
                config=executor.llm_config.model_dump(),
            )

        if not result.get("success"):
            executor.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

        contract_ok, contract_failure = _run_phase_contract_check(
            executor=executor,
            workflow_name=workflow_name,
            execution_context=execution_context,
            workflow_executor=workflow_executor,
        )
        if not contract_ok:
            executor.logger.error(
                "Phase output contract failed for %s after retry: %s",
                workflow_name,
                contract_failure.get("failed_rules", []),
            )
            executor.progress_tracker.set_status(ExecutionStatus.PAUSED)
            checkpoint_id = None
            orchestrator = getattr(executor, "checkpoint_orchestrator", None)
            if orchestrator is not None:
                checkpoint_id = orchestrator.get_checkpoint_id(workflow_name, current_chapter)
            return (
                AutonomousResult(
                    success=False,
                    completed_phases=completed_phases,
                    final_status=ExecutionStatus.PAUSED,
                    error=f"Phase output contract failed: {workflow_name}",
                    checkpoint_id=checkpoint_id,
                ),
                current_chapter,
            )

        completed_phases.append(workflow_name)
        executor.progress_tracker.complete_phase(workflow_name)

        new_chapter = current_chapter
        if workflow_name == "chapter_plan_phase":
            plan = result.get("plan", {})
            if isinstance(plan, dict):
                chapters = plan.get("chapters", [])
                new_chapter = len(chapters) if chapters else 0
            else:
                new_chapter = 0

        state = executor.progress_tracker.get_state()
        if state is None:
            raise RuntimeError("Progress state is None after completing phase")

        executor.checkpoint_manager.create_checkpoint(
            completed_workflows=completed_phases,
            current_workflow=None,
            execution_context=execution_context,
            progress_state=state,
        )

        bind_step("snapshot")
        executor.context_bus.save_snapshot(
            run_id=executor.config.project_name,
            phase=workflow_name,
            step="complete",
        )

        executor.git_manager.auto_commit_step(
            agent="autonomous",
            description=f"Complete {workflow_name}",
        )

        bind_step("revision")
        from core.autonomous._phase_runner import AutonomousPhaseRunner

        AutonomousPhaseRunner._run_revision_loop_static(executor, workflow_name, new_chapter)

        return None, new_chapter
    except Exception as exc:
        executor.logger.error(f"Failed to execute workflow '{workflow_name}': {exc}")
        raise
    finally:
        executor.context_bus.phase_cache = None
        phase_cache.clear()


def run_full_pipeline(
    executor: Any,
    checkpoint_flow: CheckpointFlowProtocol,
    workflow_executor: WorkflowExecutorProtocol,
    kb_recommendation_fn: Any,
    revision_fn: Any,
    include_legacy: bool = True,
) -> AutonomousResult:
    """Execute the full autonomous pipeline for novel generation."""
    executor.logger.info(f"🚀 Starting autonomous pipeline for '{executor.config.project_name}'")

    total_steps = len(executor.WORKFLOW_CHAIN)
    executor.progress_tracker.initialize(total_steps, executor.config.start_phase)

    completed_phases: list[str] = []
    execution_context: dict[str, Any] = {
        "project_name": executor.config.project_name,
        "execution_mode": getattr(executor.config, "execution_mode", "safe"),
        "pipeline_state_version": _PIPELINE_STATE_VERSION,
    }
    current_chapter: Optional[int] = None

    start_index = executor._get_workflow_index(executor.config.start_phase)
    end_index = executor._get_workflow_index(executor.config.end_phase)

    for i in range(start_index, end_index + 1):
        workflow_name = executor.WORKFLOW_CHAIN[i]
        if workflow_name == "new_novel" and executor.config.start_phase != "new_novel":
            continue

        executor.progress_tracker.update_phase(workflow_name)
        executor._optimizing_client.reset_circuits()
        executor.logger.info(f"→ Executing phase: {workflow_name}")

        early_return, current_chapter = _run_phase_once(
            executor=executor,
            workflow_name=workflow_name,
            checkpoint_flow=checkpoint_flow,
            workflow_executor=workflow_executor,
            execution_context=execution_context,
            completed_phases=completed_phases,
            current_chapter=current_chapter,
            include_legacy=include_legacy,
        )
        if early_return is not None:
            return early_return

    executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
    executor.logger.info(
        f"✅ Autonomous pipeline completed successfully for '{executor.config.project_name}'"
    )
    return AutonomousResult(
        success=True,
        completed_phases=completed_phases,
        final_status=ExecutionStatus.COMPLETED,
    )


def run_resume_pipeline(
    executor: Any,
    checkpoint_flow: CheckpointFlowProtocol,
    workflow_executor: WorkflowExecutorProtocol,
    kb_recommendation_fn: Any,
    revision_fn: Any,
) -> AutonomousResult:
    """Resume autonomous pipeline from the latest checkpoint."""
    executor.logger.info(f"🔄 Resuming autonomous pipeline for '{executor.config.project_name}'")

    checkpoint = executor.checkpoint_manager.load_checkpoint()
    if not checkpoint:
        executor.logger.error("No checkpoint found to resume from")
        return AutonomousResult(
            success=False,
            completed_phases=[],
            final_status=ExecutionStatus.FAILED,
            error="No checkpoint found",
        )

    if not executor.checkpoint_manager.validate_checkpoint(checkpoint):
        executor.logger.error("Invalid checkpoint")
        return AutonomousResult(
            success=False,
            completed_phases=[],
            final_status=ExecutionStatus.FAILED,
            error="Invalid checkpoint",
        )

    executor.progress_tracker._state = checkpoint.progress_state
    executor.progress_tracker.set_status(ExecutionStatus.RUNNING)

    context_snapshot = executor.context_bus.restore_snapshot(
        run_id=executor.config.project_name,
    )
    if context_snapshot is not None:
        executor.logger.info(
            f"Restored context snapshot at phase={context_snapshot.phase} "
            f"step={context_snapshot.step}"
        )

    completed_phases: list[str] = checkpoint.completed_workflows
    execution_context: dict[str, Any] = checkpoint.execution_context
    execution_context.setdefault(
        "execution_mode", getattr(executor.config, "execution_mode", "safe")
    )
    saved_version = execution_context.get("pipeline_state_version", 0)
    if saved_version != _PIPELINE_STATE_VERSION:
        executor.logger.warning(
            "Pipeline state version mismatch: saved=%s current=%s — cursor reset may occur",
            saved_version,
            _PIPELINE_STATE_VERSION,
        )
        MetricsCollector().errors_by_type.inc("pipeline_state_version_mismatch")
    current_chapter: Optional[int] = None

    last_completed = completed_phases[-1] if completed_phases else None
    start_index = executor._get_workflow_index(last_completed) + 1 if last_completed else 0
    end_index = executor._get_workflow_index(executor.config.end_phase)

    for i in range(start_index, end_index + 1):
        workflow_name = executor.WORKFLOW_CHAIN[i]
        executor.progress_tracker.update_phase(workflow_name)
        executor.logger.info(f"→ Executing phase: {workflow_name}")

        early_return, current_chapter = _run_phase_once(
            executor=executor,
            workflow_name=workflow_name,
            checkpoint_flow=checkpoint_flow,
            workflow_executor=workflow_executor,
            execution_context=execution_context,
            completed_phases=completed_phases,
            current_chapter=current_chapter,
            include_legacy=False,
        )
        if early_return is not None:
            return early_return

    executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
    executor.logger.info("✅ Resumed pipeline completed successfully")
    return AutonomousResult(
        success=True,
        completed_phases=completed_phases,
        final_status=ExecutionStatus.COMPLETED,
    )
