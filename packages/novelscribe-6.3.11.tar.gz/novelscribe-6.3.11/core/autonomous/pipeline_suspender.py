"""Pipeline suspend/resume for async API checkpoint approval."""

from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from core.checkpoints.orchestrator import CheckpointOrchestrator
    from core.streaming.event_bus import PipelineEventBus


__all__ = [
    "PipelineSuspender",
    "SuspendConfig",
]


DEFAULT_PHASE_TIMEOUTS = {
    "new_novel": 7200,
    "outline_phase": 3600,
    "chapter_plan_phase": 1800,
    "character_phase": 1800,
    "writing_phase": 300,
    "worldbuilding_phase": 3600,
    "continuity_phase": 600,
    "verification_phase": 600,
}


@dataclass
class SuspendConfig:
    """Configuration for pipeline suspension behavior."""

    timeout_seconds: dict[str, int] = field(default_factory=lambda: dict(DEFAULT_PHASE_TIMEOUTS))
    default_timeout: int = 3600
    auto_approve_on_timeout: bool = True

    def get_timeout(self, phase: str) -> int:
        return self.timeout_seconds.get(phase, self.default_timeout)


@dataclass
class SuspendState:
    """Tracks the state of a suspended checkpoint."""

    checkpoint_id: str
    phase: str
    chapter: int | None
    proposal_title: str
    confidence: float
    project: str
    timeout_seconds: int
    suspended_at: datetime = field(default_factory=lambda: datetime.now())
    resolved: bool = False
    resolved_at: datetime | None = None
    resolved_decision: str | None = None


class PipelineSuspender:
    """Manages async pipeline suspension at checkpoints.

    Allows the autonomous pipeline to suspend at checkpoints and await
    decisions via async API or WebSocket. Supports per-phase configurable
    timeouts with auto-approve behavior.

    Usage::

        suspender = PipelineSuspender(
            checkpoint_orchestrator=orchestrator,
            event_bus=get_streaming_event_bus(),
        )

        # Suspend pipeline at checkpoint
        await suspender.suspend(phase, chapter, proposal, "my-novel")

        # Elsewhere: resolve the decision
        await suspender.resume(checkpoint_id, {"decision_type": "approve"})

        # Check if suspended
        state = suspender.get_suspend_state(checkpoint_id)
    """

    def __init__(
        self,
        checkpoint_orchestrator: CheckpointOrchestrator,
        event_bus: PipelineEventBus | None = None,
        config: SuspendConfig | None = None,
    ) -> None:
        self._orchestrator = checkpoint_orchestrator
        self._event_bus = event_bus
        self._config = config or SuspendConfig()

        self._suspend_events: dict[str, asyncio.Event] = {}
        self._suspend_states: dict[str, SuspendState] = {}
        self._decision_results: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

        self.logger = logging.getLogger("scribe")

    async def suspend(
        self,
        phase: str,
        chapter: int | None,
        proposal: Any,
        project: str,
    ) -> str:
        """Suspend pipeline, emit checkpoint event, await decision.

        Args:
            phase: Current phase name
            chapter: Current chapter number
            proposal: CheckpointProposal from orchestrator
            project: Project name

        Returns:
            Checkpoint ID for the suspension
        """
        orchestrator = self._orchestrator
        checkpoint_id = orchestrator.get_checkpoint_id(phase, chapter)

        timeout_seconds = self._config.get_timeout(phase)

        state = SuspendState(
            checkpoint_id=checkpoint_id,
            phase=phase,
            chapter=chapter,
            proposal_title=proposal.plan.title if hasattr(proposal.plan, "title") else str(phase),
            confidence=float(proposal.confidence) if hasattr(proposal, "confidence") else 0.0,
            project=project,
            timeout_seconds=timeout_seconds,
        )

        suspend_event = asyncio.Event()

        with self._lock:
            self._suspend_events[checkpoint_id] = suspend_event
            self._suspend_states[checkpoint_id] = state

        if self._event_bus:
            self._event_bus.emit_checkpoint_suspend(
                checkpoint_id=checkpoint_id,
                phase=phase,
                chapter=chapter,
                proposal_title=state.proposal_title,
                confidence=state.confidence,
                project=project,
                timeout_seconds=timeout_seconds,
            )

        self.logger.info(
            f"Pipeline suspended at checkpoint {checkpoint_id} ({phase}). "
            f"Timeout: {timeout_seconds}s. Awaiting decision."
        )

        return checkpoint_id

    async def await_decision(
        self,
        checkpoint_id: str,
    ) -> dict[str, Any] | None:
        """Wait for decision on a suspended checkpoint.

        Returns when:
        - A decision is submitted via `resume()` (returns decision dict)
        - Timeout expires and auto_approve is enabled (returns auto-approve decision)
        - Checkpoint not found (returns None)
        """
        event: asyncio.Event | None = None
        timeout_seconds: int = 3600

        with self._lock:
            event = self._suspend_events.get(checkpoint_id)
            state = self._suspend_states.get(checkpoint_id)
            if state:
                timeout_seconds = state.timeout_seconds

        if event is None:
            return None

        try:
            await asyncio.wait_for(event.wait(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            self.logger.warning(
                f"Checkpoint {checkpoint_id} timed out after {timeout_seconds}s. "
                "Auto-approving proposal."
            )

            if self._config.auto_approve_on_timeout:
                auto_decision = {
                    "decision_type": "approve",
                    "checkpoint_id": checkpoint_id,
                    "auto_approved": True,
                    "timeout_seconds": timeout_seconds,
                }
                with self._lock:
                    if checkpoint_id in self._suspend_states:
                        s = self._suspend_states[checkpoint_id]
                        s.resolved = True
                        s.resolved_at = datetime.now()
                        s.resolved_decision = "auto_approve"

                if self._event_bus:
                    self._event_bus.emit_checkpoint_timeout(
                        checkpoint_id=checkpoint_id,
                        phase=state.phase if state else "unknown",
                        project=state.project if state else "",
                        timeout_seconds=timeout_seconds,
                    )

                return auto_decision
            return None

        with self._lock:
            return self._decision_results.pop(checkpoint_id, None)

    async def resume(self, checkpoint_id: str, decision: dict[str, Any]) -> None:
        """Resume pipeline from suspension with decision.

        Args:
            checkpoint_id: The checkpoint that was suspended
            decision: Decision dict with decision_type and optional modifications
        """
        with self._lock:
            event = self._suspend_events.pop(checkpoint_id, None)
            if checkpoint_id in self._suspend_states:
                state = self._suspend_states[checkpoint_id]
                state.resolved = True
                state.resolved_at = datetime.now()
                state.resolved_decision = decision.get("decision_type", "unknown")

            self._decision_results[checkpoint_id] = decision

        if event is not None:
            event.set()

        decision_type = decision.get("decision_type", "unknown")
        project = ""
        with self._lock:
            st = self._suspend_states.get(checkpoint_id)
            if st:
                project = st.project

        if self._event_bus and project:
            self._event_bus.emit_checkpoint_decision(
                checkpoint_id=checkpoint_id,
                decision_type=decision_type,
                project=project,
            )

        self.logger.info(f"Checkpoint {checkpoint_id} resolved: {decision_type}")

        self._orchestrator.incorporate_decision(checkpoint_id, decision)

    def is_suspended(self, checkpoint_id: str) -> bool:
        """Check if a checkpoint is currently suspended."""
        with self._lock:
            return checkpoint_id in self._suspend_events and not (
                checkpoint_id in self._suspend_states
                and self._suspend_states[checkpoint_id].resolved
            )

    def get_suspend_state(self, checkpoint_id: str) -> SuspendState | None:
        """Get the suspend state for a checkpoint."""
        with self._lock:
            return self._suspend_states.get(checkpoint_id)

    def get_active_suspend_ids(self) -> list[str]:
        """Get IDs of all currently suspended checkpoints."""
        with self._lock:
            return [cp_id for cp_id, state in self._suspend_states.items() if not state.resolved]

    def clear_resolved(self) -> None:
        """Remove resolved checkpoints from state."""
        with self._lock:
            resolved_ids = [
                cp_id for cp_id, state in self._suspend_states.items() if state.resolved
            ]
            for cp_id in resolved_ids:
                self._suspend_states.pop(cp_id, None)
                self._suspend_events.pop(cp_id, None)
                self._decision_results.pop(cp_id, None)
