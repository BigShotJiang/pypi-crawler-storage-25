"""Resilience subsystem — circuit breakers, timeouts, and fault tolerance."""

from .circuit import CircuitBreaker, CircuitConfig, CircuitState
from .object_pool import (
    ContentBufferPool,
    ObjectPool,
    ObjectPoolConfig,
    PagedContentBuffer,
    PoolableObject,
    PooledStringBuilder,
    PoolManager,
    PoolStats,
    StringBuilderPool,
    get_global_pool,
    get_pool_manager,
    register_global_pool,
)
from .timeout import (
    TimeoutAction,
    TimeoutHandler,
    create_timeout_handler,
)

__all__ = [
    "CircuitBreaker",
    "CircuitConfig",
    "CircuitState",
    "ContentBufferPool",
    "ObjectPool",
    "ObjectPoolConfig",
    "PagedContentBuffer",
    "PoolableObject",
    "PooledStringBuilder",
    "PoolManager",
    "PoolStats",
    "StringBuilderPool",
    "get_global_pool",
    "get_pool_manager",
    "register_global_pool",
    "TimeoutAction",
    "TimeoutHandler",
    "create_timeout_handler",
]
