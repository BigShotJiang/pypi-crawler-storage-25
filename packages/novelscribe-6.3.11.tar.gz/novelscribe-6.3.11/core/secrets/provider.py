"""Secret provider protocol and built-in implementations."""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)

_REDACTED = "***REDACTED***"


@runtime_checkable
class SecretProvider(Protocol):
    """Protocol for resolving secret values by name."""

    def get_secret(self, name: str) -> Optional[str]:
        """Return the secret value or None if not found."""
        ...

    def available_names(self) -> List[str]:
        """Return the list of secret names available from this provider."""
        ...


class EnvSecretProvider:
    """Resolve secrets from environment variables.

    Looks up ``name`` in ``os.environ``.  An optional ``prefix``
    narrows the search (e.g. prefix ``SCRIBE_`` resolves
    ``api_key`` from ``SCRIBE_API_KEY``).
    """

    def __init__(self, prefix: str = "") -> None:
        self._prefix = prefix.upper()

    def get_secret(self, name: str) -> Optional[str]:
        key = f"{self._prefix}{name.upper()}" if self._prefix else name.upper()
        return os.environ.get(key)

    def available_names(self) -> List[str]:
        if not self._prefix:
            return sorted(os.environ.keys())
        return sorted(
            k[len(self._prefix) :].lower() for k in os.environ if k.startswith(self._prefix)
        )


class FileSecretProvider:
    """Resolve secrets from files in a directory.

    Each file in ``secrets_dir`` represents one secret; the file *name*
    (stem) is the secret name and the file *content* (stripped) is the
    value.  Files are expected to have restricted permissions (0600 on
    POSIX).
    """

    def __init__(self, secrets_dir: str | Path) -> None:
        self._dir = Path(secrets_dir)
        self._cache: Dict[str, str] = {}
        self._loaded = False

    def _load(self) -> None:
        if self._loaded:
            return
        self._cache.clear()
        if not self._dir.is_dir():
            logger.debug("Secrets directory %s does not exist", self._dir)
            self._loaded = True
            return
        for fp in self._dir.iterdir():
            if fp.is_file() and not fp.name.startswith("."):
                self._cache[fp.stem] = fp.read_text(encoding="utf-8").strip()
        self._loaded = True

    def get_secret(self, name: str) -> Optional[str]:
        self._load()
        return self._cache.get(name)

    def available_names(self) -> List[str]:
        self._load()
        return sorted(self._cache.keys())

    def invalidate(self) -> None:
        self._loaded = False
        self._cache.clear()


class CompositeSecretProvider:
    """Chain multiple providers; first non-None result wins."""

    def __init__(self, providers: Optional[List[SecretProvider]] = None) -> None:
        self._providers: List[SecretProvider] = providers or []

    def add_provider(self, provider: SecretProvider) -> None:
        self._providers.append(provider)

    def get_secret(self, name: str) -> Optional[str]:
        for provider in self._providers:
            value = provider.get_secret(name)
            if value is not None:
                return value
        return None

    def available_names(self) -> List[str]:
        names: set[str] = set()
        for provider in self._providers:
            names.update(provider.available_names())
        return sorted(names)
