"""High-level secret access with resolution and redaction."""

from __future__ import annotations

from pathlib import Path
from typing import Dict, Optional

# Import from the package namespace so that tests patching
# ``core.secrets.*`` classes can intercept these references.
from core.secrets import (
    CompositeSecretProvider,
    EnvSecretProvider,
    FileSecretProvider,
    SecretProvider,
)

_REDACTED = "***REDACTED***"


class SecretStore:
    """High-level secret access with resolution and redaction.

    Holds a ``CompositeSecretProvider`` and exposes:
    - ``resolve(name)`` – get a secret value
    - ``redact(text)`` – replace all known secret values with a redaction marker
    - ``resolve_variable(path)`` – resolve ``secrets.<name>`` dot-path syntax
    """

    def __init__(self, provider: Optional[SecretProvider] = None) -> None:
        if provider is None:
            composite = CompositeSecretProvider()
            composite.add_provider(FileSecretProvider(Path.cwd() / ".secrets"))
            composite.add_provider(EnvSecretProvider())
            provider = composite
        self._provider = provider
        self._known_values: Dict[str, str] = {}

    def resolve(self, name: str) -> str:
        """Return secret value or raise ``LookupError``."""
        value = self._provider.get_secret(name)
        if value is None:
            raise LookupError(f"Secret '{name}' not found in any provider")
        self._known_values[name] = value
        return value

    def resolve_variable(self, path: str) -> Optional[str]:
        """Resolve a ``secrets.<name>`` dot-path string.

        Returns None if *path* does not start with ``secrets.``.
        """
        if not path.startswith("secrets."):
            return None
        name = path[len("secrets.") :]
        return self.resolve(name)

    def redact(self, text: str) -> str:
        """Replace all previously resolved secret values in *text*."""
        for value in self._known_values.values():
            if value and value in text:
                text = text.replace(value, _REDACTED)
        return text

    @staticmethod
    def redaction_marker() -> str:
        return _REDACTED
