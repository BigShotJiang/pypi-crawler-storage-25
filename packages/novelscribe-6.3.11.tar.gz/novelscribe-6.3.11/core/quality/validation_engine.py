"""
Validation Engine for Novel Content.

Provides the ValidationSystem class that manages validation rules,
executes validation checks, and generates detailed reports.
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.quality.validation_report import ValidationReport
from core.quality.validation_rules import (
    AdverbOveruseRule,
    ChapterOutlineAlignmentRule,
    CharacterConsistencyRule,
    DialogueAttributionRule,
    DialogueBalanceRule,
    MaxSentenceLengthRule,
    MinimumWordCountRule,
    PassiveVoiceRule,
    SceneLengthRule,
    TimelineContinuityRule,
)
from core.quality.validation_types import RuleCategory, Severity, ValidationResult, ValidationRule

DEFAULT_RULES = (
    MinimumWordCountRule,
    MaxSentenceLengthRule,
    DialogueAttributionRule,
    CharacterConsistencyRule,
    ChapterOutlineAlignmentRule,
    TimelineContinuityRule,
    PassiveVoiceRule,
    AdverbOveruseRule,
    DialogueBalanceRule,
    SceneLengthRule,
)


class ValidationSystem:
    """
    Comprehensive validation system for novel content.

    Manages validation rules, executes validation checks, and generates
    detailed validation reports with actionable feedback.
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize the validation system.

        Args:
            project_root: Path to project directory for context
        """
        self.project_root = project_root or Path.cwd()
        self.rules: Dict[str, ValidationRule] = {}
        self._register_default_rules()

    def _register_default_rules(self) -> None:
        """Register default validation rules."""
        for rule_cls in DEFAULT_RULES:
            self.add_rule(rule_cls())

    def add_rule(self, rule: ValidationRule) -> None:
        """Add a validation rule to the system."""
        self.rules[rule.rule_id] = rule

    def remove_rule(self, rule_id: str) -> None:
        """Remove a validation rule from the system."""
        if rule_id in self.rules:
            del self.rules[rule_id]

    def enable_rule(self, rule_id: str) -> None:
        """Enable a specific validation rule."""
        if rule_id in self.rules:
            self.rules[rule_id].enabled = True

    def disable_rule(self, rule_id: str) -> None:
        """Disable a specific validation rule."""
        if rule_id in self.rules:
            self.rules[rule_id].enabled = False

    def validate_content(
        self,
        content: str,
        context: Optional[Dict[str, Any]] = None,
        rule_ids: Optional[List[str]] = None,
    ) -> ValidationReport:
        """
        Validate content against all enabled rules.

        Args:
            content: Content to validate
            context: Additional context for validation
            rule_ids: Specific rules to validate (None = all enabled)

        Returns:
            ValidationReport with all validation results
        """
        context = context or {}
        results = []

        rules_to_check = self._get_rules_to_check(rule_ids)

        for rule in rules_to_check.values():
            try:
                result = rule.validate_content(content, context)
                results.append(result)
            except Exception as e:
                results.append(
                    ValidationResult(
                        rule=rule,
                        passed=False,
                        message=f"Validation error: {str(e)}",
                        suggestion="Check rule implementation",
                    )
                )

        return self._generate_report(results, context.get("content_path"))

    def _get_rules_to_check(
        self, rule_ids: Optional[List[str]] = None
    ) -> Dict[str, ValidationRule]:
        """Get the set of rules to validate against."""
        if rule_ids:
            return {rid: self.rules[rid] for rid in rule_ids if rid in self.rules}
        else:
            return {rid: rule for rid, rule in self.rules.items() if rule.enabled}

    def _generate_report(
        self, results: List[ValidationResult], content_path: Optional[str] = None
    ) -> ValidationReport:
        """Generate a validation report from results."""
        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        warnings = sum(1 for r in results if not r.passed and r.rule.severity == Severity.WARNING)
        errors = sum(1 for r in results if not r.passed and r.rule.severity == Severity.ERROR)

        return ValidationReport(
            content_path=content_path,
            timestamp=datetime.now(),
            total_rules_checked=len(results),
            passed_rules=passed,
            failed_rules=failed,
            warnings=warnings,
            errors=errors,
            results=results,
        )

    def get_rules_by_category(self, category: RuleCategory) -> List[ValidationRule]:
        """Get all rules in a specific category."""
        return [rule for rule in self.rules.values() if rule.category == category]

    def get_rules_by_severity(self, severity: Severity) -> List[ValidationRule]:
        """Get all rules with a specific severity level."""
        return [rule for rule in self.rules.values() if rule.severity == severity]

    def generate_report_summary(self, report: ValidationReport) -> str:
        """Generate a human-readable summary of the validation report."""
        summary = [
            "## Validation Report",
            f"Generated: {report.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "**Overall Results**",
            f"- Rules Checked: {report.total_rules_checked}",
            f"- Passed: {report.passed_rules}",
            f"- Failed: {report.failed_rules}",
            f"- Warnings: {report.warnings}",
            f"- Errors: {report.errors}",
            f"- Success Rate: {report.success_rate:.1%}",
            "",
        ]

        if report.errors > 0:
            summary.append("**Errors**")
            for result in report.get_results_by_severity(Severity.ERROR):
                summary.append(f"- {result.rule.name}: {result.message}")
                if result.suggestion:
                    summary.append(f"  Suggestion: {result.suggestion}")
            summary.append("")

        if report.warnings > 0:
            summary.append("**Warnings**")
            for result in report.get_results_by_severity(Severity.WARNING):
                summary.append(f"- {result.rule.name}: {result.message}")
                if result.suggestion:
                    summary.append(f"  Suggestion: {result.suggestion}")
            summary.append("")

        return "\n".join(summary)
