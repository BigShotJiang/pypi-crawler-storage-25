"""Quality snapshot store — append-only JSONL persistence."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from core.quality.snapshot import QualitySnapshot


class QualitySnapshotStore:
    """Append-only JSONL store for quality snapshots.

    Layout::

        .novels/{project}/.quality/snapshots/
        ├── chapter_001.jsonl
        ├── chapter_002.jsonl
        └── ...

    Each file is one JSON object per line (JSONL).
    """

    def __init__(self, project_path: Path) -> None:
        self._snapshots_dir = project_path / ".quality" / "snapshots"

    def save(self, snapshot: QualitySnapshot) -> Path:
        """Append a snapshot to the chapter's JSONL file."""
        self._snapshots_dir.mkdir(parents=True, exist_ok=True)
        path = self._snapshots_dir / f"chapter_{snapshot.chapter:03d}.jsonl"
        line = snapshot.to_jsonl_line()
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
        return path

    def load_chapter(self, chapter: int) -> list[QualitySnapshot]:
        """Load all snapshots for a specific chapter, ordered by timestamp."""
        path = self._snapshots_dir / f"chapter_{chapter:03d}.jsonl"
        if not path.exists():
            return []
        return self._read_jsonl(path)

    def load_all(self) -> list[QualitySnapshot]:
        """Load all snapshots across all chapters."""
        if not self._snapshots_dir.exists():
            return []
        snapshots: list[QualitySnapshot] = []
        for path in sorted(self._snapshots_dir.glob("chapter_*.jsonl")):
            snapshots.extend(self._read_jsonl(path))
        return snapshots

    def load_range(self, start_chapter: int, end_chapter: int) -> list[QualitySnapshot]:
        """Load snapshots for a range of chapters (inclusive)."""
        snapshots: list[QualitySnapshot] = []
        for ch in range(start_chapter, end_chapter + 1):
            snapshots.extend(self.load_chapter(ch))
        return snapshots

    def list_chapters(self) -> list[int]:
        """Return sorted list of chapter numbers that have snapshots."""
        if not self._snapshots_dir.exists():
            return []
        chapters: list[int] = []
        for path in self._snapshots_dir.glob("chapter_*.jsonl"):
            name = path.stem.replace("chapter_", "")
            try:
                chapters.append(int(name))
            except ValueError:
                continue
        return sorted(chapters)

    def latest_snapshot(self, chapter: int) -> Optional[QualitySnapshot]:
        """Return the most recent snapshot for a chapter, or None."""
        snapshots = self.load_chapter(chapter)
        if not snapshots:
            return None
        return snapshots[-1]

    def prune(self, max_per_chapter: int = 100) -> int:
        """Prune each chapter file to keep only the last N snapshots.

        Returns the total number of pruned entries.
        """
        if not self._snapshots_dir.exists():
            return 0

        pruned = 0
        for path in self._snapshots_dir.glob("chapter_*.jsonl"):
            snapshots = self._read_jsonl(path)
            if len(snapshots) <= max_per_chapter:
                continue
            pruned += len(snapshots) - max_per_chapter
            kept = snapshots[-max_per_chapter:]
            self._write_jsonl(path, kept)

        return pruned

    def _read_jsonl(self, path: Path) -> list[QualitySnapshot]:
        snapshots: list[QualitySnapshot] = []
        try:
            lines = path.read_text(encoding="utf-8").strip().split("\n")
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    snapshots.append(QualitySnapshot.model_validate(data))
                except (json.JSONDecodeError, Exception):
                    continue
        except OSError:
            pass
        return snapshots

    def _write_jsonl(self, path: Path, snapshots: list[QualitySnapshot]) -> None:
        lines = [s.to_jsonl_line() for s in snapshots]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
