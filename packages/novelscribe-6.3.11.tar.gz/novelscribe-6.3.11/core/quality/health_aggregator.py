"""Project health aggregation from quality snapshots."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field

from core.quality.snapshot import QualitySnapshot
from core.quality.snapshot_store import QualitySnapshotStore


class ChapterScore(BaseModel):
    chapter: int
    quality_score: float = 0.0
    gate_level: Optional[str] = None
    word_count: int = 0
    trend: str = "─"
    previous_score: Optional[float] = None


class ProjectHealthReport(BaseModel):
    project_name: str = ""
    overall_score: float = 0.0
    gate_level: Optional[str] = None
    total_chapters: int = 0
    total_words: int = 0
    chapters_with_data: int = 0

    dimension_averages: dict[str, float] = Field(default_factory=dict)
    chapter_scores: list[ChapterScore] = Field(default_factory=list)

    overall_trend: str = "─"
    last_updated: str = ""

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

    def to_json(self) -> str:
        return self.model_dump_json(indent=2)


class ProjectHealthAggregator:
    """Aggregate quality snapshots into a project-level health report."""

    DIMENSION_KEYS: dict[str, str] = {
        "readability": "flesch_kincaid",
        "dialogue": "ratio",
        "pacing": "scene_variation",
        "style": "passive_voice_ratio",
        "consistency": "_direct",
        "continuity": "_direct",
    }

    GATE_PRECEDENCE: list[str] = ["platinum", "gold", "silver", "bronze"]

    def aggregate(self, project_name: str, store: QualitySnapshotStore) -> ProjectHealthReport:
        all_snapshots = store.load_all()
        if not all_snapshots:
            return ProjectHealthReport(project_name=project_name)

        chapter_numbers = store.list_chapters()
        chapter_scores = self._build_chapter_scores(store, chapter_numbers)
        dim_avgs = self._compute_dimension_averages(all_snapshots)
        overall = self._compute_overall_score(all_snapshots)
        best_gate = self._compute_best_gate(all_snapshots)
        total_words = sum(
            s.word_count for s in all_snapshots if s == store.latest_snapshot(s.chapter)
        )
        latest_ts = max(s.timestamp for s in all_snapshots) if all_snapshots else ""
        trend = self._compute_overall_trend(chapter_scores)

        return ProjectHealthReport(
            project_name=project_name,
            overall_score=round(overall, 1),
            gate_level=best_gate,
            total_chapters=max(chapter_numbers) if chapter_numbers else 0,
            total_words=total_words,
            chapters_with_data=len(chapter_numbers),
            dimension_averages=dim_avgs,
            chapter_scores=chapter_scores,
            overall_trend=trend,
            last_updated=latest_ts,
        )

    def aggregate_health_only(
        self, project_name: str, store: QualitySnapshotStore
    ) -> dict[str, Any]:
        report = self.aggregate(project_name, store)
        return {
            "project_name": report.project_name,
            "overall_score": report.overall_score,
            "gate_level": report.gate_level,
            "total_chapters": report.total_chapters,
            "overall_trend": report.overall_trend,
            "last_updated": report.last_updated,
        }

    def _build_chapter_scores(
        self, store: QualitySnapshotStore, chapters: list[int]
    ) -> list[ChapterScore]:
        scores: list[ChapterScore] = []
        for ch in chapters:
            snapshots = store.load_chapter(ch)
            if not snapshots:
                continue
            latest = snapshots[-1]
            trend = "─"
            previous_score: Optional[float] = None
            if len(snapshots) >= 2:
                prev = snapshots[-2]
                previous_score = prev.quality_score
                diff = latest.quality_score - prev.quality_score
                if diff > 0.01:
                    trend = "▲"
                elif diff < -0.01:
                    trend = "▼"
            scores.append(
                ChapterScore(
                    chapter=ch,
                    quality_score=round(latest.quality_score, 1),
                    gate_level=latest.gate_level,
                    word_count=latest.word_count,
                    trend=trend,
                    previous_score=round(previous_score, 1) if previous_score is not None else None,
                )
            )
        return scores

    def _compute_dimension_averages(self, snapshots: list[QualitySnapshot]) -> dict[str, float]:
        if not snapshots:
            return {}
        avgs: dict[str, list[float]] = {}
        for key, sub_key in self.DIMENSION_KEYS.items():
            values: list[float] = []
            for s in snapshots:
                if key == "consistency":
                    values.append(s.consistency)
                elif key == "continuity":
                    values.append(s.continuity)
                else:
                    sub_dict = getattr(s, key, {})
                    if isinstance(sub_dict, dict) and sub_key in sub_dict:
                        values.append(sub_dict[sub_key])
            if values:
                avg = sum(values) / len(values)
                avgs[key] = round(avg, 1)
        return avgs

    def _compute_overall_score(self, snapshots: list[QualitySnapshot]) -> float:
        if not snapshots:
            return 0.0
        return sum(s.quality_score for s in snapshots) / len(snapshots)

    def _compute_best_gate(self, snapshots: list[QualitySnapshot]) -> Optional[str]:
        gate_levels: set[str] = set()
        for s in snapshots:
            if s.gate_level:
                gate_levels.add(s.gate_level.lower())
        for level in self.GATE_PRECEDENCE:
            if level in gate_levels:
                return level
        return None

    def _compute_overall_trend(self, chapter_scores: list[ChapterScore]) -> str:
        if not chapter_scores:
            return "─"
        ups = sum(1 for cs in chapter_scores if cs.trend == "▲")
        downs = sum(1 for cs in chapter_scores if cs.trend == "▼")
        if ups > downs:
            return "▲"
        if downs > ups:
            return "▼"
        return "─"
