"""Quality snapshot model for persistent quality tracking."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from pydantic import BaseModel, Field


class QualitySnapshot(BaseModel):
    """A single quality evaluation snapshot for one chapter.

    Stored as append-only JSONL in ``.novels/{project}/.quality/snapshots/chapter_XXX.jsonl``.
    """

    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    chapter: int
    source: str = "analyze"
    quality_score: float = 0.0

    readability: dict[str, float] = Field(default_factory=dict)
    dialogue: dict[str, float] = Field(default_factory=dict)
    pacing: dict[str, float] = Field(default_factory=dict)
    style: dict[str, float] = Field(default_factory=dict)
    consistency: float = 0.0
    continuity: float = 0.0

    gate_level: Optional[str] = None
    gate_passed: Optional[bool] = None
    word_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

    def to_jsonl_line(self) -> str:
        return self.model_dump_json()
