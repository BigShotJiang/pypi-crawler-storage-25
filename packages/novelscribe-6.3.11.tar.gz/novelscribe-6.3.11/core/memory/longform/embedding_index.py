"""Embedding index for long-form memory using sentence-transformers + numpy."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Optional

from core.memory.longform.config import LongFormConfig
from core.memory.longform.models import SceneChunk, ScoredChunk

logger = logging.getLogger("scribe")


def is_embedding_available() -> bool:
    try:
        import sentence_transformers  # noqa: F401

        return True
    except ImportError:
        return False


class EmbeddingIndex:
    """Vector similarity index backed by numpy and sentence-transformers.

    Vectors are cached to .npz files with metadata in .meta.json,
    consistent with the core/templates/embedding.py pattern.
    """

    def __init__(self, db_path: Path, config: Optional[LongFormConfig] = None):
        self._db_path = db_path
        self._config = config or LongFormConfig()
        self._model_name = self._config.embedding_model
        self._dim = self._config.embedding_dim
        self._model: Any = None
        self._chunk_ids: list[str] = []
        self._vectors: Any = None

    @property
    def size(self) -> int:
        return len(self._chunk_ids)

    def _load_model(self) -> Any:
        from sentence_transformers import SentenceTransformer

        logger.info("Loading embedding model %s ...", self._model_name)
        return SentenceTransformer(self._model_name)

    def _ensure_model(self) -> Any:
        if self._model is None:
            self._model = self._load_model()
        return self._model

    def _npz_path(self) -> Path:
        return self._db_path / "vectors.npz"

    def _meta_path(self) -> Path:
        return self._db_path / "vectors.meta.json"

    def add(self, chunk_id: str, text: str, metadata: dict | None = None) -> None:
        model = self._ensure_model()
        vector = model.encode([text], normalize_embeddings=True)

        import numpy as np

        if self._vectors is None:
            self._vectors = vector
        else:
            self._vectors = np.vstack([self._vectors, vector])

        self._chunk_ids.append(chunk_id)

    def add_batch(self, chunks: list[SceneChunk]) -> None:
        if not chunks:
            return

        model = self._ensure_model()
        texts = [chunk.to_text() for chunk in chunks]

        import numpy as np

        logger.info("Encoding %d chunks ...", len(texts))
        vectors = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)

        if self._vectors is None:
            self._vectors = vectors
        else:
            self._vectors = np.vstack([self._vectors, vectors])

        for chunk in chunks:
            self._chunk_ids.append(chunk.chunk_id)

    def search(
        self,
        query: str,
        top_k: int = 20,
        chapter_filter: int | None = None,
    ) -> list[ScoredChunk]:
        if self._vectors is None or len(self._chunk_ids) == 0:
            return []

        model = self._ensure_model()

        query_vec = model.encode([query], normalize_embeddings=True)
        scores = (self._vectors @ query_vec.T).flatten()

        scored: list[tuple[int, float]] = []
        for i, chunk_id in enumerate(self._chunk_ids):
            if chapter_filter is not None:
                ch_str = f"ch{chapter_filter:03d}"
                if not chunk_id.startswith(ch_str):
                    continue
            scored.append((i, float(scores[i])))

        scored.sort(key=lambda x: x[1], reverse=True)
        top = scored[:top_k]

        results: list[ScoredChunk] = []
        for idx, score in top:
            results.append(
                ScoredChunk(
                    chunk=SceneChunk(
                        chunk_id=self._chunk_ids[idx],
                        chapter_num=0,
                        scene_num=0,
                        content="",
                        token_count=0,
                    ),
                    score=score,
                )
            )
        return results

    def remove_chapter(self, chapter_num: int) -> int:
        if self._vectors is None:
            return 0

        ch_prefix = f"ch{chapter_num:03d}"
        keep_indices = [i for i, cid in enumerate(self._chunk_ids) if not cid.startswith(ch_prefix)]
        removed = len(self._chunk_ids) - len(keep_indices)

        if removed == 0:
            return 0

        self._vectors = self._vectors[keep_indices]
        self._chunk_ids = [self._chunk_ids[i] for i in keep_indices]
        return removed

    def save(self) -> None:
        if self._vectors is None:
            return

        self._db_path.mkdir(parents=True, exist_ok=True)

        import numpy as np

        np.savez_compressed(str(self._npz_path()), vectors=self._vectors)

        meta = {
            "model_name": self._model_name,
            "dim": int(self._vectors.shape[1]),
            "chunk_count": len(self._chunk_ids),
            "chunk_ids": self._chunk_ids,
        }
        with open(self._meta_path(), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)

    def load(self) -> bool:
        npz = self._npz_path()
        meta_path = self._meta_path()
        if not npz.exists() or not meta_path.exists():
            return False

        try:
            with open(meta_path, encoding="utf-8") as f:
                meta = json.load(f)
        except (json.JSONDecodeError, OSError):
            return False

        import numpy as np

        data = np.load(str(npz), allow_pickle=False)
        self._vectors = data["vectors"]
        self._chunk_ids = list(meta["chunk_ids"])
        return True

    def clear(self) -> None:
        self._vectors = None
        self._chunk_ids = []
        npz = self._npz_path()
        meta = self._meta_path()
        if npz.exists():
            npz.unlink()
        if meta.exists():
            meta.unlink()
