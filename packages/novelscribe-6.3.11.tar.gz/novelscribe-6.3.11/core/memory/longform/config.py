"""Configuration for long-form memory system."""

from typing import Optional

from pydantic import BaseModel


class LongFormConfig(BaseModel):
    enabled: bool = True

    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_dim: int = 384

    chunk_tokens: int = 512
    overlap_tokens: int = 64

    retrieval_top_k: int = 20
    max_context_tokens: int = 4000
    recency_weight: float = 0.3

    contradiction_check: bool = True
    contradiction_threshold: float = 0.8

    store_path: Optional[str] = None
