# ruff: noqa: F401
"""Long-form memory — semantic recall of narrative prose across chapters."""

from core.memory.longform.chapter_store import ChapterTextStore
from core.memory.longform.config import LongFormConfig
from core.memory.longform.embedding_index import EmbeddingIndex, is_embedding_available
from core.memory.longform.longform import LongFormMemory
from core.memory.longform.models import (
    ContextBlock,
    ContextSource,
    Contradiction,
    ContradictionSeverity,
    LongFormStats,
    SceneChunk,
    ScoredChunk,
)
