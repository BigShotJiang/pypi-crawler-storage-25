"""Recency + relevance reranker for long-form memory retrieval."""

from core.memory.longform.config import LongFormConfig
from core.memory.longform.models import ContextBlock, ScoredChunk


def compute_recency_score(
    chunk_chapter: int,
    hint_chapter: int,
    total_chapters: int,
    recency_weight: float,
) -> float:
    if total_chapters <= 1:
        return 1.0
    distance = abs(hint_chapter - chunk_chapter)
    return 1.0 - (distance / total_chapters) * recency_weight


def rerank(
    scored_chunks: list[ScoredChunk],
    hint_chapter: int,
    total_chapters: int,
    config: LongFormConfig | None = None,
) -> list[ScoredChunk]:
    config = config or LongFormConfig()

    for sc in scored_chunks:
        recency = compute_recency_score(
            sc.chunk.chapter_num,
            hint_chapter,
            total_chapters,
            config.recency_weight,
        )
        sc.score = sc.score * (1.0 - config.recency_weight) + recency * config.recency_weight

    scored_chunks.sort(key=lambda x: x.score, reverse=True)
    return scored_chunks


def assemble_context(
    scored_chunks: list[ScoredChunk],
    max_tokens: int,
) -> list[ContextBlock]:
    blocks: list[ContextBlock] = []
    budget = max_tokens

    for sc in scored_chunks:
        if budget <= 0:
            break

        token_count = sc.chunk.token_count
        if token_count > budget:
            continue

        blocks.append(
            ContextBlock(
                source=sc.source,
                content=sc.chunk.to_text(),
                token_count=token_count,
                chapter_num=sc.chunk.chapter_num,
                score=sc.score,
                metadata={
                    "chunk_id": sc.chunk.chunk_id,
                    "characters": sc.chunk.characters,
                    "locations": sc.chunk.locations,
                },
            )
        )
        budget -= token_count

    return blocks
