"""Dynamic context window manager — token-budgeted context assembly."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Optional

from core.memory.longform.models import (
    ArchivedChapterSummary,
    ContextBlock,
    ContextWindow,
    ContextWindowConfig,
    ContextWindowStats,
)

if TYPE_CHECKING:
    from core.memory.longform.longform import LongFormMemory


class ContextWindowManager:
    """Manage dynamic context windows with chapter archiving."""

    def __init__(
        self,
        longform: "LongFormMemory",
        config: Optional[ContextWindowConfig] = None,
    ) -> None:
        self._longform = longform
        self._config = config or ContextWindowConfig()
        self._archived: dict[int, ArchivedChapterSummary] = {}
        self._summaries_path: Optional[Path] = None

    def set_summaries_path(self, path: Path) -> None:
        self._summaries_path = path
        self._load_summaries()

    def build_context(
        self,
        current_chapter: int,
        query: Optional[str] = None,
        extra_budget: int = 0,
    ) -> ContextWindow:
        budget = self._config.max_tokens + extra_budget
        entity_budget = self._config.entity_summary_budget
        plot_budget = self._config.plot_thread_budget
        scene_budget = min(
            self._config.recent_scene_budget,
            budget - entity_budget - plot_budget,
        )

        recent_scenes = self._collect_recent_scenes(current_chapter, scene_budget, query)
        archived_summaries = self._collect_archived_summaries(budget)
        entity_summaries = self._collect_entity_summaries(entity_budget)
        plot_threads = self._collect_plot_threads(plot_budget)

        total = (
            sum(s.token_count for s in recent_scenes)
            + sum(s.token_count for s in archived_summaries)
            + sum(self._estimate_tokens(e) for e in entity_summaries)
            + sum(self._estimate_tokens(p) for p in plot_threads)
        )

        return ContextWindow(
            entity_summaries=entity_summaries,
            active_plot_threads=plot_threads,
            recent_scenes=recent_scenes,
            archived_chapter_summaries=archived_summaries,
            total_tokens=total,
            budget_allocation={
                "entity": entity_budget,
                "plot": plot_budget,
                "scene": scene_budget,
            },
        )

    def archive_chapter(self, chapter_num: int) -> ArchivedChapterSummary:
        summary = ArchivedChapterSummary(
            chapter_num=chapter_num,
            summary=f"Chapter {chapter_num} archived content.",
            token_count=20,
            key_entities=[],
            key_plot_points=[],
            archived_at=datetime.now().isoformat(),
        )
        self._archived[chapter_num] = summary
        self._save_summaries()
        return summary

    def reactivate_chapter(self, chapter_num: int) -> None:
        if chapter_num in self._archived:
            del self._archived[chapter_num]
            self._save_summaries()

    def get_active_window_stats(self) -> ContextWindowStats:
        stats = self._longform.stats()
        all_chapters = list(range(1, stats.total_chapters_indexed + 1))
        archived = list(self._archived.keys())
        active = [c for c in all_chapters if c not in self._archived]
        return ContextWindowStats(
            total_chapters=stats.total_chapters_indexed,
            active_chapters=active,
            archived_chapters=archived,
            total_active_chunks=stats.total_chunks,
            budget_max_tokens=self._config.max_tokens,
        )

    def _collect_recent_scenes(
        self,
        current_chapter: int,
        budget: int,
        query: Optional[str],
    ) -> list[ContextBlock]:
        effective_query = query or f"chapter {current_chapter}"
        results = self._longform.retrieve(
            effective_query,
            chapter_hint=current_chapter,
            max_tokens=budget,
        )
        filtered: list[ContextBlock] = []
        used = 0
        for block in results:
            if block.chapter_num >= current_chapter - self._config.active_chapter_range:
                decay = self._config.relevance_decay_rate ** abs(
                    current_chapter - block.chapter_num
                )
                adjusted_score = block.score * decay
                if adjusted_score >= self._config.min_relevance_score:
                    block.score = adjusted_score
                    filtered.append(block)
                    used += block.token_count
                    if used >= budget:
                        break
        return filtered

    def _collect_archived_summaries(self, budget: int) -> list[ArchivedChapterSummary]:
        summaries = sorted(self._archived.values(), key=lambda s: s.chapter_num)
        result: list[ArchivedChapterSummary] = []
        used = 0
        for s in summaries:
            if used + s.token_count <= budget * 0.3:
                result.append(s)
                used += s.token_count
        return result

    def _collect_entity_summaries(self, budget: int) -> list[str]:
        return []

    def _collect_plot_threads(self, budget: int) -> list[str]:
        return []

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        return max(1, len(text) // 4)

    def _save_summaries(self) -> None:
        if not self._summaries_path:
            return
        self._summaries_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            str(k): {
                "chapter_num": v.chapter_num,
                "summary": v.summary,
                "token_count": v.token_count,
                "key_entities": v.key_entities,
                "key_plot_points": v.key_plot_points,
                "archived_at": v.archived_at,
            }
            for k, v in self._archived.items()
        }
        self._summaries_path.write_text(json.dumps(data, indent=2))

    def _load_summaries(self) -> None:
        if self._summaries_path and self._summaries_path.exists():
            data = json.loads(self._summaries_path.read_text())
            for k, v in data.items():
                self._archived[int(k)] = ArchivedChapterSummary(
                    chapter_num=v["chapter_num"],
                    summary=v["summary"],
                    token_count=v["token_count"],
                    key_entities=v.get("key_entities", []),
                    key_plot_points=v.get("key_plot_points", []),
                    archived_at=v.get("archived_at", ""),
                )
