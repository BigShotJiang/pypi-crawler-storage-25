"""Long-form memory facade — semantic recall of narrative prose across chapters."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from core.memory.longform.chapter_store import ChapterTextStore
from core.memory.longform.config import LongFormConfig
from core.memory.longform.embedding_index import EmbeddingIndex, is_embedding_available
from core.memory.longform.models import (
    ContextBlock,
    ContextWindow,
    ContextWindowConfig,
    ContinuityScore,
    Contradiction,
    ContradictionSeverity,
    Entity,
    LongFormStats,
    NarrativeState,
    SceneChunk,
)
from core.memory.longform.reranker import assemble_context, rerank

logger = logging.getLogger("scribe")


class LongFormMemory:
    """Semantic recall of narrative prose across chapters.

    Composes ChapterTextStore (scene storage) + EmbeddingIndex (vector search)
    + reranker (recency + relevance scoring). Extended with context window
    management, entity tracking, continuity scoring, and narrative state.
    """

    def __init__(
        self,
        project_path: Path,
        config: Optional[LongFormConfig] = None,
    ):
        self._config = config or LongFormConfig()
        self._project_path = project_path
        store_base = (
            Path(self._config.store_path)
            if self._config.store_path
            else project_path / "memory" / "longform"
        )

        self._store = ChapterTextStore(store_base, self._config)
        self._index = EmbeddingIndex(store_base / "vectors", self._config)
        self._initialized = False
        self._context_manager: Optional[Any] = None
        self._entity_tracker: Optional[Any] = None
        self._continuity_scorer: Optional[Any] = None
        self._narrative_store: Optional[Any] = None

    def _ensure_loaded(self) -> None:
        if self._initialized:
            return
        self._index.load()
        self._initialized = True

    def index_chapter(self, chapter_num: int, content: str) -> list[SceneChunk]:
        if not self._config.enabled:
            logger.debug("Long-form memory disabled, skipping index_chapter(%d)", chapter_num)
            return []

        self._ensure_loaded()

        existing = self._store.load_chapter(chapter_num)
        if existing:
            self._index.remove_chapter(chapter_num)

        chunks = self._store.store_chapter(chapter_num, content)

        if is_embedding_available():
            self._index.add_batch(chunks)
            self._index.save()
            logger.info(
                "Indexed chapter %d: %d scenes, %d total chunks",
                chapter_num,
                len(chunks),
                self._index.size,
            )
        else:
            logger.warning(
                "sentence-transformers not installed; chapter %d stored without embeddings",
                chapter_num,
            )

        return chunks

    def retrieve(
        self,
        query: str,
        chapter_hint: int = 0,
        max_tokens: int = 0,
        cross_chapter_weight: float = 0.0,
    ) -> list[ContextBlock]:
        if not self._config.enabled:
            return []

        self._ensure_loaded()

        if not is_embedding_available() or self._index.size == 0:
            return []

        max_tokens = max_tokens or self._config.max_context_tokens
        top_k = self._config.retrieval_top_k

        scored = self._index.search(query, top_k=top_k)

        if not scored:
            return []

        chapters = self._store.list_chapters()
        total_chapters = max(len(chapters), 1)

        scored = rerank(scored, chapter_hint, total_chapters, self._config)

        self._fill_chunk_content(scored)

        return assemble_context(scored, max_tokens)

    def stats(self) -> LongFormStats:
        self._ensure_loaded()

        chapters = self._store.list_chapters()
        all_chunks: list[SceneChunk] = []
        for ch in chapters:
            all_chunks.extend(self._store.load_chapter(ch))

        characters: set[str] = set()
        locations: set[str] = set()
        for chunk in all_chunks:
            characters.update(chunk.characters)
            locations.update(chunk.locations)

        index_size = 0
        npz = self._index._npz_path()
        if npz.exists():
            index_size = npz.stat().st_size

        return LongFormStats(
            total_chapters_indexed=len(chapters),
            total_chunks=len(all_chunks),
            total_characters=len(characters),
            total_locations=len(locations),
            index_size_bytes=index_size,
            last_indexed_chapter=max(chapters) if chapters else None,
            embedding_model=self._config.embedding_model,
        )

    def remove_chapter(self, chapter_num: int) -> bool:
        self._ensure_loaded()
        removed = self._store.delete_chapter(chapter_num)
        if removed:
            self._index.remove_chapter(chapter_num)
            self._index.save()
        return removed

    def find_contradictions(
        self,
        new_chapter_content: str,
        chapter_num: int,
        knowledge_graph: object | None = None,
    ) -> list[Contradiction]:
        if not self._config.contradiction_check:
            return []

        subjects: set[str] = set()
        for line in new_chapter_content.split("\n"):
            words = line.strip().split()
            if words and words[0][0].isupper() and len(words[0]) > 1:
                subjects.add(words[0])

        if not subjects or knowledge_graph is None:
            return []

        contradictions: list[Contradiction] = []

        for subject in subjects:
            node = knowledge_graph.find_by_name(subject)
            if node is None:
                continue

            rels = knowledge_graph.get_relationships(node.node_id, direction="outgoing")
            if not rels:
                continue

            for edge, target in rels:
                contradictions.append(
                    Contradiction(
                        contradiction_type="established_fact",
                        subject=subject,
                        predicate="exists_in_graph",
                        object_ref=target.name if hasattr(target, "name") else "",
                        established_in_chapter=(
                            edge.metadata.get("chapter", 0)
                            if hasattr(edge, "metadata") and edge.metadata
                            else 0
                        ),
                        new_statement_in_chapter=chapter_num,
                        evidence=f"Graph: {subject} has established relationships",
                        new_evidence=f"New chapter {chapter_num} mentions {subject}",
                        severity=ContradictionSeverity.WARNING,
                        confidence=0.0,
                    )
                )
                break

        return contradictions

    def build_context_window(
        self,
        current_chapter: int,
        query: Optional[str] = None,
        extra_budget: int = 0,
        config: Optional[ContextWindowConfig] = None,
    ) -> ContextWindow:
        from core.memory.longform.context_window import ContextWindowManager

        if self._context_manager is None:
            store_base = (
                Path(self._config.store_path)
                if self._config.store_path
                else self._project_path / "memory" / "longform"
            )
            mgr = ContextWindowManager(self, config)
            mgr.set_summaries_path(store_base / "archived_summaries.json")
            self._context_manager = mgr
        return self._context_manager.build_context(current_chapter, query, extra_budget)

    def archive_chapter(self, chapter_num: int) -> Any:

        if self._context_manager is None:
            self.build_context_window(chapter_num)
        return self._context_manager.archive_chapter(chapter_num)

    def reactivate_chapter(self, chapter_num: int) -> None:
        if self._context_manager is not None:
            self._context_manager.reactivate_chapter(chapter_num)

    def track_entities(
        self,
        chapter_num: int,
        content: str,
        llm_client: Any = None,
    ) -> list[Entity]:
        from core.memory.longform.entity_tracker import EntityTracker

        if self._entity_tracker is None:
            store_base = (
                Path(self._config.store_path)
                if self._config.store_path
                else self._project_path / "memory" / "longform"
            )
            self._entity_tracker = EntityTracker(store_base)
        return self._entity_tracker.extract_and_update(chapter_num, content, llm_client)

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        if self._entity_tracker is None:
            return None
        return self._entity_tracker.get_entity(entity_id)

    def get_entities(self, current_chapter: int = 0, within_chapters: int = 5) -> list[Entity]:
        if self._entity_tracker is None:
            return []
        if current_chapter > 0:
            return self._entity_tracker.get_active_entities(current_chapter, within_chapters)
        return list(self._entity_tracker._entities.values())

    def get_character_arc(self, entity_id: str) -> Any:
        if self._entity_tracker is None:
            return None
        return self._entity_tracker.get_character_arc(entity_id)

    def score_continuity(
        self,
        chapter_num: int,
        chapter_content: str,
        llm_client: Any = None,
    ) -> ContinuityScore:
        from core.memory.longform.continuity import ContinuityScorer

        if self._continuity_scorer is None:
            self._continuity_scorer = ContinuityScorer(self, self._entity_tracker)
        return self._continuity_scorer.score_chapter(chapter_num, chapter_content, llm_client)

    def get_narrative_state(self) -> Optional[NarrativeState]:
        if self._narrative_store is None:
            return None
        return self._narrative_store.get_state()

    def update_narrative_state(
        self,
        chapter_num: int,
        chapter_content: str,
        llm_client: Any = None,
    ) -> NarrativeState:
        from core.memory.longform.narrative_state import NarrativeStateStore

        if self._narrative_store is None:
            self._narrative_store = NarrativeStateStore(self._project_path)
        return self._narrative_store.update_from_chapter(
            chapter_num,
            chapter_content,
            entity_tracker=self._entity_tracker,
            llm_client=llm_client,
        )

    def _fill_chunk_content(self, scored_chunks: list) -> None:
        if not scored_chunks:
            return

        needed_chapters: set[int] = set()
        for sc in scored_chunks:
            needed_chapters.add(
                sc.chunk.chapter_num
                if sc.chunk.chapter_num
                else self._chapter_from_id(sc.chunk.chunk_id)
            )

        chapter_chunks: dict[int, dict[str, SceneChunk]] = {}
        for ch in needed_chapters:
            chunks = self._store.load_chapter(ch)
            chapter_chunks[ch] = {c.chunk_id: c for c in chunks}

        for sc in scored_chunks:
            cid = sc.chunk.chunk_id
            ch = sc.chunk.chapter_num or self._chapter_from_id(cid)
            stored = chapter_chunks.get(ch, {}).get(cid)
            if stored:
                sc.chunk = stored

    @staticmethod
    def _chapter_from_id(chunk_id: str) -> int:
        try:
            return int(chunk_id.split("_")[0][2:])
        except (ValueError, IndexError):
            return 0
