"""Data models for long-form memory system."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class ContradictionSeverity(str, Enum):
    WARNING = "warning"
    ERROR = "error"


class ContextSource(str, Enum):
    SEMANTIC = "semantic"
    GRAPH = "graph"
    WIKI = "wiki"


class EntityType(str, Enum):
    CHARACTER = "character"
    LOCATION = "location"
    ORGANIZATION = "organization"
    ITEM = "item"
    CONCEPT = "concept"


@dataclass
class SceneChunk:
    chunk_id: str
    chapter_num: int
    scene_num: int
    content: str
    token_count: int
    characters: list[str] = field(default_factory=list)
    locations: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now())

    def to_text(self) -> str:
        return f"[Chapter {self.chapter_num}, Scene {self.scene_num}]\n{self.content}"


@dataclass
class ScoredChunk:
    chunk: SceneChunk
    score: float
    source: ContextSource = ContextSource.SEMANTIC

    def to_text(self) -> str:
        return self.chunk.to_text()


@dataclass
class ContextBlock:
    source: ContextSource
    content: str
    token_count: int
    chapter_num: int
    score: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Contradiction:
    contradiction_type: str
    subject: str
    predicate: str
    object_ref: str
    established_in_chapter: int
    new_statement_in_chapter: int
    evidence: str
    new_evidence: str
    severity: ContradictionSeverity = ContradictionSeverity.WARNING
    confidence: float = 0.0


@dataclass
class LongFormStats:
    total_chapters_indexed: int = 0
    total_chunks: int = 0
    total_characters: int = 0
    total_locations: int = 0
    index_size_bytes: int = 0
    last_indexed_chapter: Optional[int] = None
    embedding_model: str = ""


@dataclass
class ContextWindowConfig:
    max_tokens: int = 8000
    active_chapter_range: int = 3
    archive_threshold_chapters: int = 5
    entity_summary_budget: int = 1500
    plot_thread_budget: int = 1000
    recent_scene_budget: int = 4000
    relevance_decay_rate: float = 0.85
    min_relevance_score: float = 0.15


@dataclass
class ArchivedChapterSummary:
    chapter_num: int
    summary: str
    token_count: int
    key_entities: list[str] = field(default_factory=list)
    key_plot_points: list[str] = field(default_factory=list)
    archived_at: str = ""


@dataclass
class ContextWindow:
    entity_summaries: list[str] = field(default_factory=list)
    active_plot_threads: list[str] = field(default_factory=list)
    recent_scenes: list[ContextBlock] = field(default_factory=list)
    archived_chapter_summaries: list[ArchivedChapterSummary] = field(default_factory=list)
    total_tokens: int = 0
    budget_allocation: dict[str, int] = field(default_factory=dict)


@dataclass
class ContextWindowStats:
    total_chapters: int = 0
    active_chapters: list[int] = field(default_factory=list)
    archived_chapters: list[int] = field(default_factory=list)
    total_active_chunks: int = 0
    budget_used_tokens: int = 0
    budget_max_tokens: int = 0
    utilization_pct: float = 0.0


@dataclass
class EntityState:
    chapter_num: int
    state: dict[str, Any] = field(default_factory=dict)
    summary: str = ""
    confidence: float = 0.0


@dataclass
class Entity:
    entity_id: str
    name: str
    entity_type: EntityType
    first_seen_chapter: int
    last_seen_chapter: int
    mention_count: int = 0
    attributes: dict[str, str] = field(default_factory=dict)
    state_history: list[EntityState] = field(default_factory=list)


@dataclass
class RelationEvolution:
    chapter_num: int
    change: str = ""
    description: str = ""


@dataclass
class EntityRelation:
    source_id: str
    target_id: str
    relation_type: str = ""
    first_seen_chapter: int = 0
    last_seen_chapter: int = 0
    evolution: list[RelationEvolution] = field(default_factory=list)


@dataclass
class CharacterArc:
    entity_id: str
    arc_type: str = "flat"
    beginning_state: str = ""
    current_state: str = ""
    key_turning_points: list[tuple[int, str]] = field(default_factory=list)
    confidence: float = 0.0


@dataclass
class DimensionScore:
    name: str
    score: float = 0.0
    details: str = ""


@dataclass
class ContinuityWarning:
    dimension: str
    severity: str = "low"
    description: str = ""
    evidence: str = ""


@dataclass
class ContinuityScore:
    overall: float = 0.0
    dimensions: list[DimensionScore] = field(default_factory=list)
    warnings: list[ContinuityWarning] = field(default_factory=list)
    chapter_num: int = 0
    scored_at: str = ""


@dataclass
class PlotThread:
    thread_id: str
    description: str = ""
    introduced_chapter: int = 0
    last_advanced_chapter: int = 0
    status: str = "active"
    priority: str = "sub"
    related_entities: list[str] = field(default_factory=list)


@dataclass
class CharacterState:
    entity_id: str
    name: str
    current_role: str = ""
    current_location: Optional[str] = None
    emotional_state: Optional[str] = None
    active_goals: list[str] = field(default_factory=list)
    relationships_summary: str = ""


@dataclass
class ToneProfile:
    primary_tone: str = ""
    secondary_tones: list[str] = field(default_factory=list)
    intensity: float = 0.0


@dataclass
class PacingProfile:
    average_scene_length: int = 0
    dialogue_ratio: float = 0.0
    action_ratio: float = 0.0
    current_act: Optional[str] = None


@dataclass
class NarrativeState:
    project_name: str = ""
    current_chapter: int = 0
    total_chapters: int = 0
    active_plot_threads: list[PlotThread] = field(default_factory=list)
    resolved_plot_threads: list[PlotThread] = field(default_factory=list)
    active_characters: list[CharacterState] = field(default_factory=list)
    world_state: dict[str, Any] = field(default_factory=dict)
    tone_profile: Optional[ToneProfile] = None
    pacing_profile: Optional[PacingProfile] = None
    last_updated: str = ""
