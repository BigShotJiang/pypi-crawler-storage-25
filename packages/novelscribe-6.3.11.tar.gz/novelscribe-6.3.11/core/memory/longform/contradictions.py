"""Contradiction detection — LLM fact extraction vs KnowledgeGraph comparison."""

from __future__ import annotations

import json
import logging
from typing import Any

from core.memory.longform.models import Contradiction, ContradictionSeverity

logger = logging.getLogger("scribe")

_EXTRACTION_PROMPT = (
    "Extract factual statements from this text as a JSON array.\n"
    "Each fact should have: subject, predicate, object\n"
    'Example: [{{"subject": "Elena", "predicate": "is_allied_with", '
    '"object": "Marcus"}}]\n\n'
    "Text:\n{text}\n\n"
    "Respond with ONLY the JSON array, no other text."
)

_CONTRADICTION_PROMPT = (
    "Compare these new facts against established facts "
    "and find contradictions.\n\n"
    "New facts from chapter {new_chapter}:\n{new_facts}\n\n"
    "Established facts from earlier chapters:\n{established_facts}\n\n"
    "For each contradiction found, respond with a JSON array of objects:\n"
    '[{{"type": "...", "subject": "...", '
    '"predicate": "...", "object": "...", '
    '"evidence": "...", "new_evidence": "...", '
    '"severity": "warning" or "error"}}]\n\n'
    "If no contradictions, respond with: []"
)


def _parse_json_response(text: str) -> list[dict]:
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        lines = [line for line in lines if not line.strip().startswith("```")]
        text = "\n".join(lines)
    try:
        result = json.loads(text)
        if isinstance(result, list):
            return result
        return []
    except json.JSONDecodeError:
        return []


async def extract_facts_with_llm(
    content: str,
    llm_client: Any,
) -> list[dict]:
    prompt = _EXTRACTION_PROMPT.format(text=content[:2000])
    try:
        response = await llm_client.generate(
            prompt=prompt,
            max_tokens=500,
            temperature=0.1,
        )
        return _parse_json_response(response)
    except Exception:
        logger.warning("Fact extraction LLM call failed", exc_info=True)
        return []


async def find_contradictions_with_llm(
    new_facts: list[dict],
    established_facts: list[dict],
    new_chapter: int,
    llm_client: Any,
) -> list[Contradiction]:
    if not new_facts or not established_facts:
        return []

    new_str = json.dumps(new_facts, ensure_ascii=False)
    est_str = json.dumps(established_facts, ensure_ascii=False)
    prompt = _CONTRADICTION_PROMPT.format(
        new_chapter=new_chapter,
        new_facts=new_str,
        established_facts=est_str,
    )

    try:
        response = await llm_client.generate(
            prompt=prompt,
            max_tokens=1000,
            temperature=0.1,
        )
        raw = _parse_json_response(response)
    except Exception:
        logger.warning("Contradiction detection LLM call failed", exc_info=True)
        return []

    contradictions: list[Contradiction] = []
    for item in raw:
        contradictions.append(
            Contradiction(
                contradiction_type=item.get("type", "unknown"),
                subject=item.get("subject", ""),
                predicate=item.get("predicate", ""),
                object_ref=item.get("object", ""),
                established_in_chapter=0,
                new_statement_in_chapter=new_chapter,
                evidence=item.get("evidence", ""),
                new_evidence=item.get("new_evidence", ""),
                severity=ContradictionSeverity(item.get("severity", "warning")),
            )
        )
    return contradictions


def find_contradictions_with_graph(
    facts: list[dict],
    knowledge_graph: Any,
    new_chapter: int,
) -> list[Contradiction]:
    contradictions: list[Contradiction] = []

    for fact in facts:
        subject = fact.get("subject", "")
        predicate = fact.get("predicate", "")
        obj = fact.get("object", "")

        if not subject:
            continue

        node = knowledge_graph.find_by_name(subject)
        if node is None:
            continue

        rels = knowledge_graph.get_relationships(node.node_id, direction="outgoing")

        for edge, target in rels:
            edge_relation = edge.relation if hasattr(edge, "relation") else ""
            edge_target_name = target.name if hasattr(target, "name") else ""

            if _is_contradictory(predicate, obj, edge_relation, edge_target_name):
                established_ch = (
                    edge.metadata.get("chapter", 0)
                    if hasattr(edge, "metadata") and edge.metadata
                    else 0
                )
                contradictions.append(
                    Contradiction(
                        contradiction_type="relationship_violation",
                        subject=subject,
                        predicate=predicate,
                        object_ref=obj,
                        established_in_chapter=established_ch,
                        new_statement_in_chapter=new_chapter,
                        evidence=f"Graph: {subject} {edge_relation} {edge_target_name}",
                        new_evidence=f"New: {subject} {predicate} {obj}",
                        severity=ContradictionSeverity.WARNING,
                    )
                )

    return contradictions


_OPPOSITES = {
    "is_allied_with": {"is_enemy_of", "betrayed", "killed"},
    "is_enemy_of": {"is_allied_with", "helped", "saved"},
    "loves": {"hates", "killed"},
    "hates": {"loves", "helped"},
    "alive": {"dead", "killed"},
    "dead": {"alive", "resurrected"},
    "at": {"left", "fled_from"},
    "owns": {"lost", "sold", "gave_away"},
}


def _is_contradictory(
    new_predicate: str,
    new_object: str,
    existing_relation: str,
    existing_target: str,
) -> bool:
    new_pred = new_predicate.lower().replace(" ", "_")
    existing_rel = str(existing_relation).lower().replace(" ", "_")

    if new_pred == existing_rel:
        new_obj = new_object.lower().strip()
        existing_tgt = existing_target.lower().strip()
        if new_obj and existing_tgt and new_obj != existing_tgt:
            return True
        return False

    opposites = _OPPOSITES.get(new_pred, set())
    if existing_rel in opposites:
        return True

    return False
