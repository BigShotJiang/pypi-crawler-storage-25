"""Narrative continuity scoring — multi-dimensional consistency analysis."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any, Optional

from core.memory.longform.models import (
    ContinuityScore,
    ContinuityWarning,
    DimensionScore,
)

if TYPE_CHECKING:
    from core.memory.longform.entity_tracker import EntityTracker
    from core.memory.longform.longform import LongFormMemory


class ContinuityScorer:
    """Score narrative continuity across multiple dimensions."""

    DIMENSIONS = [
        "tone_consistency",
        "character_consistency",
        "plot_thread_continuity",
        "temporal_consistency",
        "setting_consistency",
        "pacing",
    ]

    def __init__(
        self,
        longform: "LongFormMemory",
        entity_tracker: Optional["EntityTracker"] = None,
    ) -> None:
        self._longform = longform
        self._entity_tracker = entity_tracker

    def score_chapter(
        self,
        chapter_num: int,
        chapter_content: str,
        llm_client: Any = None,
    ) -> ContinuityScore:
        dimensions: list[DimensionScore] = []
        warnings: list[ContinuityWarning] = []

        dimensions.append(self._score_tone(chapter_num, chapter_content))
        dimensions.append(self._score_character(chapter_num, chapter_content))
        dimensions.append(self._score_plot_threads(chapter_num, chapter_content))
        dimensions.append(self._score_temporal(chapter_num, chapter_content))
        dimensions.append(self._score_setting(chapter_num, chapter_content))
        dimensions.append(self._score_pacing(chapter_num, chapter_content))

        overall = sum(d.score for d in dimensions) / len(dimensions) if dimensions else 0.0

        for dim in dimensions:
            if dim.score < 0.5:
                sev = "high" if dim.score < 0.3 else "medium"
                warnings.append(
                    ContinuityWarning(
                        dimension=dim.name,
                        severity=sev,
                        description=dim.details,
                    )
                )

        return ContinuityScore(
            overall=round(overall, 3),
            dimensions=dimensions,
            warnings=warnings,
            chapter_num=chapter_num,
            scored_at=datetime.now().isoformat(),
        )

    def _score_tone(self, chapter_num: int, content: str) -> DimensionScore:
        positive = sum(
            1
            for w in [
                "happy",
                "joy",
                "love",
                "hope",
                "bright",
                "warm",
                "peaceful",
                "calm",
                "gentle",
                "beautiful",
            ]
            if w in content.lower()
        )
        negative = sum(
            1
            for w in [
                "dark",
                "fear",
                "anger",
                "death",
                "cold",
                "harsh",
                "violent",
                "cruel",
                "grim",
                "despair",
            ]
            if w in content.lower()
        )
        total = positive + negative
        if total == 0:
            return DimensionScore(
                name="tone_consistency",
                score=0.8,
                details="Neutral tone detected.",
            )
        ratio = abs(positive - negative) / total
        score = max(0.2, 1.0 - ratio * 0.5)
        return DimensionScore(
            name="tone_consistency",
            score=round(score, 3),
            details=f"Tone balance: {positive} positive, {negative} negative markers.",
        )

    def _score_character(self, chapter_num: int, content: str) -> DimensionScore:
        if not self._entity_tracker:
            return DimensionScore(
                name="character_consistency",
                score=0.7,
                details="No entity tracker available.",
            )
        active = self._entity_tracker.get_active_entities(chapter_num)
        mentioned = 0
        for entity in active:
            if entity.name.lower() in content.lower():
                mentioned += 1
        if not active:
            return DimensionScore(
                name="character_consistency",
                score=0.9,
                details="No active entities to check.",
            )
        score = min(1.0, mentioned / max(1, len(active)) + 0.3)
        return DimensionScore(
            name="character_consistency",
            score=round(score, 3),
            details=(f"{mentioned}/{len(active)} active characters referenced in chapter."),
        )

    def _score_plot_threads(self, chapter_num: int, content: str) -> DimensionScore:
        if chapter_num <= 2:
            return DimensionScore(
                name="plot_thread_continuity",
                score=0.9,
                details="Early chapter — plot threads still establishing.",
            )
        paragraphs = content.split("\n\n")
        scene_density = len([p for p in paragraphs if p.strip()])
        if scene_density < 2:
            return DimensionScore(
                name="plot_thread_continuity",
                score=0.5,
                details="Low scene density — may need more plot advancement.",
            )
        return DimensionScore(
            name="plot_thread_continuity",
            score=0.8,
            details=f"Scene density: {scene_density} scenes.",
        )

    def _score_temporal(self, chapter_num: int, content: str) -> DimensionScore:
        time_words = [
            "then",
            "later",
            "after",
            "before",
            "suddenly",
            "meanwhile",
            "now",
            "soon",
            "eventually",
            "immediately",
        ]
        count = sum(1 for w in time_words if w in content.lower())
        score = min(1.0, 0.5 + count * 0.1)
        return DimensionScore(
            name="temporal_consistency",
            score=round(score, 3),
            details=f"Temporal markers found: {count}.",
        )

    def _score_setting(self, chapter_num: int, content: str) -> DimensionScore:
        if not self._entity_tracker:
            return DimensionScore(
                name="setting_consistency",
                score=0.7,
                details="No entity tracker available.",
            )
        locations = [
            e for e in self._entity_tracker._entities.values() if e.entity_type.value == "location"
        ]
        if not locations:
            return DimensionScore(
                name="setting_consistency",
                score=0.8,
                details="No tracked locations.",
            )
        mentioned = sum(1 for loc in locations if loc.name.lower() in content.lower())
        score = min(1.0, 0.6 + mentioned * 0.15)
        return DimensionScore(
            name="setting_consistency",
            score=round(score, 3),
            details=f"{mentioned}/{len(locations)} locations referenced.",
        )

    def _score_pacing(self, chapter_num: int, content: str) -> DimensionScore:
        word_count = len(content.split())
        dialogue_count = content.count('"') // 2 + content.count("'") // 2
        if word_count == 0:
            return DimensionScore(name="pacing", score=0.5, details="Empty chapter.")
        dialogue_ratio = dialogue_count / max(1, word_count / 100)
        if dialogue_ratio < 0.1:
            score = 0.6
            detail = "Low dialogue density — mostly narrative."
        elif dialogue_ratio > 0.8:
            score = 0.6
            detail = "High dialogue density — may need narrative breaks."
        else:
            score = 0.85
            detail = f"Balanced pacing: {word_count} words, dialogue ratio {dialogue_ratio:.1f}."
        return DimensionScore(name="pacing", score=round(score, 3), details=detail)
