"""Narrative state store — plot threads, character states, tone/pacing profiles."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

from core.memory.longform.models import (
    CharacterState,
    EntityType,
    NarrativeState,
    PacingProfile,
    PlotThread,
    ToneProfile,
)

if TYPE_CHECKING:
    from core.memory.longform.entity_tracker import EntityTracker


class NarrativeStateStore:
    """Persistent narrative state independent of the knowledge base."""

    def __init__(self, project_path: Path) -> None:
        self._state_path = project_path / "memory" / "longform" / "narrative_state.json"
        self._state: Optional[NarrativeState] = None

    def get_state(self) -> Optional[NarrativeState]:
        if self._state is None:
            self.load()
        return self._state

    def update_from_chapter(
        self,
        chapter_num: int,
        chapter_content: str,
        entity_tracker: Optional["EntityTracker"] = None,
        llm_client: Any = None,
    ) -> NarrativeState:
        if self._state is None:
            self._state = NarrativeState()

        self._state.current_chapter = chapter_num
        self._state.total_chapters = max(self._state.total_chapters, chapter_num)
        self._state.last_updated = datetime.now().isoformat()

        self._update_plot_threads(chapter_num, chapter_content)

        if entity_tracker:
            self._update_character_states(chapter_num, entity_tracker)

        self._update_tone_profile(chapter_content)
        self._update_pacing_profile(chapter_content)

        self.save()
        return self._state

    def get_active_plot_threads(self) -> list[PlotThread]:
        if not self._state:
            return []
        return [t for t in self._state.active_plot_threads if t.status == "active"]

    def get_character_states(self, entity_ids: Optional[list[str]] = None) -> list[CharacterState]:
        if not self._state:
            return []
        if entity_ids:
            return [c for c in self._state.active_characters if c.entity_id in entity_ids]
        return self._state.active_characters

    def save(self) -> None:
        if not self._state:
            return
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        self._state_path.write_text(self._serialize(self._state))

    def load(self) -> bool:
        if not self._state_path.exists():
            return False
        try:
            data = json.loads(self._state_path.read_text())
            self._state = self._deserialize(data)
            return True
        except (json.JSONDecodeError, KeyError):
            return False

    def _update_plot_threads(self, chapter_num: int, content: str) -> None:
        if not self._state:
            return
        lower = content.lower()
        keywords = [
            "quest",
            "mission",
            "goal",
            "find",
            "defeat",
            "solve",
            "discover",
            "protect",
            "destroy",
            "escape",
            "rescue",
        ]
        for kw in keywords:
            if kw in lower:
                existing = next(
                    (t for t in self._state.active_plot_threads if kw in t.description.lower()),
                    None,
                )
                if existing:
                    existing.last_advanced_chapter = chapter_num
                else:
                    tid = f"thread_{len(self._state.active_plot_threads) + 1}"
                    self._state.active_plot_threads.append(
                        PlotThread(
                            thread_id=tid,
                            description=f"Plot involving '{kw}'",
                            introduced_chapter=chapter_num,
                            last_advanced_chapter=chapter_num,
                            status="active",
                            priority="sub",
                        )
                    )

        for thread in self._state.active_plot_threads:
            if thread.status == "active" and chapter_num - thread.last_advanced_chapter > 5:
                thread.status = "dormant"

    def _update_character_states(
        self,
        chapter_num: int,
        entity_tracker: "EntityTracker",
    ) -> None:
        if not self._state:
            return
        active = entity_tracker.get_active_entities(chapter_num, within_chapters=3)
        characters = [e for e in active if e.entity_type == EntityType.CHARACTER]
        self._state.active_characters = [
            CharacterState(
                entity_id=e.entity_id,
                name=e.name,
                current_role=e.attributes.get("role", ""),
                current_location=e.attributes.get("location"),
            )
            for e in characters
        ]

    def _update_tone_profile(self, content: str) -> None:
        if not self._state:
            return
        positive = sum(1 for w in ["hope", "joy", "love", "bright", "warm"] if w in content.lower())
        negative = sum(
            1 for w in ["dark", "fear", "anger", "death", "cold"] if w in content.lower()
        )
        if positive > negative:
            primary = "hopeful"
        elif negative > positive:
            primary = "tense"
        else:
            primary = "neutral"

        intensity = min(1.0, (positive + negative) / max(1, len(content.split()) / 200))
        self._state.tone_profile = ToneProfile(
            primary_tone=primary,
            intensity=round(intensity, 2),
        )

    def _update_pacing_profile(self, content: str) -> None:
        if not self._state:
            return
        words = len(content.split())
        dialogue = content.count('"') // 2 + content.count("'") // 2
        self._state.pacing_profile = PacingProfile(
            average_scene_length=words,
            dialogue_ratio=round(dialogue / max(1, words / 100), 2),
        )

    @staticmethod
    def _serialize(state: NarrativeState) -> str:
        data: dict[str, Any] = {
            "project_name": state.project_name,
            "current_chapter": state.current_chapter,
            "total_chapters": state.total_chapters,
            "last_updated": state.last_updated,
            "world_state": state.world_state,
        }
        data["active_plot_threads"] = [
            {
                "thread_id": t.thread_id,
                "description": t.description,
                "introduced_chapter": t.introduced_chapter,
                "last_advanced_chapter": t.last_advanced_chapter,
                "status": t.status,
                "priority": t.priority,
                "related_entities": t.related_entities,
            }
            for t in state.active_plot_threads
        ]
        data["resolved_plot_threads"] = [
            {
                "thread_id": t.thread_id,
                "description": t.description,
                "introduced_chapter": t.introduced_chapter,
                "last_advanced_chapter": t.last_advanced_chapter,
                "status": t.status,
            }
            for t in state.resolved_plot_threads
        ]
        data["active_characters"] = [
            {
                "entity_id": c.entity_id,
                "name": c.name,
                "current_role": c.current_role,
                "current_location": c.current_location,
                "emotional_state": c.emotional_state,
                "active_goals": c.active_goals,
                "relationships_summary": c.relationships_summary,
            }
            for c in state.active_characters
        ]
        if state.tone_profile:
            data["tone_profile"] = {
                "primary_tone": state.tone_profile.primary_tone,
                "secondary_tones": state.tone_profile.secondary_tones,
                "intensity": state.tone_profile.intensity,
            }
        if state.pacing_profile:
            data["pacing_profile"] = {
                "average_scene_length": state.pacing_profile.average_scene_length,
                "dialogue_ratio": state.pacing_profile.dialogue_ratio,
                "action_ratio": state.pacing_profile.action_ratio,
                "current_act": state.pacing_profile.current_act,
            }
        return json.dumps(data, indent=2)

    @staticmethod
    def _deserialize(data: dict[str, Any]) -> NarrativeState:
        state = NarrativeState(
            project_name=data.get("project_name", ""),
            current_chapter=data.get("current_chapter", 0),
            total_chapters=data.get("total_chapters", 0),
            world_state=data.get("world_state", {}),
            last_updated=data.get("last_updated", ""),
        )
        state.active_plot_threads = [
            PlotThread(
                thread_id=t["thread_id"],
                description=t.get("description", ""),
                introduced_chapter=t.get("introduced_chapter", 0),
                last_advanced_chapter=t.get("last_advanced_chapter", 0),
                status=t.get("status", "active"),
                priority=t.get("priority", "sub"),
                related_entities=t.get("related_entities", []),
            )
            for t in data.get("active_plot_threads", [])
        ]
        state.resolved_plot_threads = [
            PlotThread(
                thread_id=t["thread_id"],
                description=t.get("description", ""),
            )
            for t in data.get("resolved_plot_threads", [])
        ]
        state.active_characters = [
            CharacterState(
                entity_id=c["entity_id"],
                name=c["name"],
                current_role=c.get("current_role", ""),
                current_location=c.get("current_location"),
                emotional_state=c.get("emotional_state"),
                active_goals=c.get("active_goals", []),
                relationships_summary=c.get("relationships_summary", ""),
            )
            for c in data.get("active_characters", [])
        ]
        tp = data.get("tone_profile")
        if tp:
            state.tone_profile = ToneProfile(
                primary_tone=tp.get("primary_tone", ""),
                secondary_tones=tp.get("secondary_tones", []),
                intensity=tp.get("intensity", 0.0),
            )
        pp = data.get("pacing_profile")
        if pp:
            state.pacing_profile = PacingProfile(
                average_scene_length=pp.get("average_scene_length", 0),
                dialogue_ratio=pp.get("dialogue_ratio", 0.0),
                action_ratio=pp.get("action_ratio", 0.0),
                current_act=pp.get("current_act"),
            )
        return state
