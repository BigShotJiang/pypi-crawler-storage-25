"""Chapter text storage with scene-based chunking."""

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from core.memory.longform.config import LongFormConfig
from core.memory.longform.models import SceneChunk

_CAPITALIZED_WORD_RE = re.compile(r"^[A-Z\u4e00-\u9fff][\w\u4e00-\u9fff]*")
_SCENE_BREAK_RE = re.compile(r"\n\s*\n")
_PARAGRAPH_BREAK_RE = re.compile(r"\n")


def _estimate_tokens(text: str) -> int:
    return max(1, int(len(text.split()) * 1.3))


def _extract_characters(text: str) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for line in text.split("\n"):
        stripped = line.strip()
        if not stripped:
            continue
        first_word = stripped.split()[0] if stripped.split() else ""
        if (
            _CAPITALIZED_WORD_RE.match(first_word)
            and first_word not in seen
            and len(first_word) > 1
            and first_word.lower() not in _NARRATIVE_WORDS
        ):
            seen.add(first_word)
            result.append(first_word)
    return result


def _extract_locations(text: str) -> list[str]:
    location_hints = (
        " in the ",
        " at the ",
        " inside the ",
        " to the ",
        " entered the ",
        " arrived at ",
        " left the ",
        "回到",
        "走进",
        "来到",
    )
    seen: set[str] = set()
    result: list[str] = []
    lower = text.lower()
    for hint in location_hints:
        idx = 0
        while True:
            pos = lower.find(hint, idx)
            if pos == -1:
                break
            after = text[pos + len(hint) :].strip()
            words = after.split()
            if words:
                candidate = words[0].rstrip(".,;:!?")
                if len(candidate) > 2 and candidate not in seen and candidate[0].isupper():
                    seen.add(candidate)
                    result.append(candidate)
            idx = pos + len(hint)
    return result


_NARRATIVE_WORDS = frozenset(
    {
        "the",
        "a",
        "an",
        "he",
        "she",
        "it",
        "they",
        "we",
        "you",
        "i",
        "his",
        "her",
        "its",
        "their",
        "our",
        "my",
        "your",
        "this",
        "that",
        "these",
        "those",
        "but",
        "and",
        "or",
        "not",
        "so",
        "if",
        "when",
        "while",
        "as",
        "after",
        "before",
        "then",
        "than",
        "with",
        "from",
        "into",
        "there",
        "here",
        "where",
        "what",
        "which",
        "who",
        "how",
        "she",
        "he",
        "they",
        "them",
        "him",
        "us",
        "said",
        "asked",
        "replied",
        "thought",
        "felt",
        "knew",
        "looked",
        "turned",
        "walked",
        "stood",
        "sat",
        "The",
        "A",
        "An",
        "But",
        "And",
        "Or",
        "So",
        "If",
        "When",
        "While",
        "After",
        "Before",
        "Then",
        "There",
        "Here",
        "He",
        "She",
        "It",
        "They",
        "We",
        "You",
        "I",
        "His",
        "Her",
        "Its",
        "Their",
        "Our",
        "My",
        "Your",
        "This",
        "That",
        "These",
        "Those",
    }
)


class ChapterTextStore:
    """JSON-based scene storage for long-form memory."""

    def __init__(self, store_path: Path, config: Optional[LongFormConfig] = None):
        self._path = store_path
        self._config = config or LongFormConfig()

    def store_chapter(self, chapter_num: int, content: str) -> list[SceneChunk]:
        chunks = self.split_into_scenes(chapter_num, content)
        chapter_dir = self._path / "scenes" / f"{chapter_num:03d}"
        chapter_dir.mkdir(parents=True, exist_ok=True)
        for chunk in chunks:
            scene_file = chapter_dir / f"{chunk.scene_num:03d}.json"
            scene_file.write_text(
                json.dumps(self._chunk_to_dict(chunk), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        return chunks

    def load_chapter(self, chapter_num: int) -> list[SceneChunk]:
        chapter_dir = self._path / "scenes" / f"{chapter_num:03d}"
        if not chapter_dir.exists():
            return []
        chunks: list[SceneChunk] = []
        for scene_file in sorted(chapter_dir.glob("*.json")):
            data = json.loads(scene_file.read_text(encoding="utf-8"))
            chunks.append(self._dict_to_chunk(data))
        return chunks

    def delete_chapter(self, chapter_num: int) -> bool:
        chapter_dir = self._path / "scenes" / f"{chapter_num:03d}"
        if not chapter_dir.exists():
            return False
        for f in chapter_dir.iterdir():
            f.unlink()
        chapter_dir.rmdir()
        return True

    def list_chapters(self) -> list[int]:
        scenes_dir = self._path / "scenes"
        if not scenes_dir.exists():
            return []
        return sorted(int(d.name) for d in scenes_dir.iterdir() if d.is_dir() and d.name.isdigit())

    def split_into_scenes(self, chapter_num: int, content: str) -> list[SceneChunk]:
        paragraphs = _SCENE_BREAK_RE.split(content)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]

        if not paragraphs:
            return []

        scenes: list[SceneChunk] = []
        current_scene_parts: list[str] = []
        current_tokens = 0
        scene_num = 0
        chunk_limit = self._config.chunk_tokens

        for para in paragraphs:
            para_tokens = _estimate_tokens(para)

            if current_scene_parts and current_tokens + para_tokens > chunk_limit:
                scene_num += 1
                scene_text = "\n\n".join(current_scene_parts)
                scenes.append(self._make_chunk(chapter_num, scene_num, scene_text))
                current_scene_parts = []
                current_tokens = 0

            current_scene_parts.append(para)
            current_tokens += para_tokens

        if current_scene_parts:
            scene_num += 1
            scene_text = "\n\n".join(current_scene_parts)
            scenes.append(self._make_chunk(chapter_num, scene_num, scene_text))

        return scenes

    def _make_chunk(self, chapter_num: int, scene_num: int, content: str) -> SceneChunk:
        return SceneChunk(
            chunk_id=f"ch{chapter_num:03d}_s{scene_num:03d}",
            chapter_num=chapter_num,
            scene_num=scene_num,
            content=content,
            token_count=_estimate_tokens(content),
            characters=_extract_characters(content),
            locations=_extract_locations(content),
            created_at=datetime.now(),
        )

    @staticmethod
    def _chunk_to_dict(chunk: SceneChunk) -> dict:
        return {
            "chunk_id": chunk.chunk_id,
            "chapter_num": chunk.chapter_num,
            "scene_num": chunk.scene_num,
            "content": chunk.content,
            "token_count": chunk.token_count,
            "characters": chunk.characters,
            "locations": chunk.locations,
            "created_at": chunk.created_at.isoformat(),
        }

    @staticmethod
    def _dict_to_chunk(data: dict) -> SceneChunk:
        return SceneChunk(
            chunk_id=data["chunk_id"],
            chapter_num=data["chapter_num"],
            scene_num=data["scene_num"],
            content=data["content"],
            token_count=data["token_count"],
            characters=data.get("characters", []),
            locations=data.get("locations", []),
            created_at=datetime.fromisoformat(data["created_at"]),
        )
