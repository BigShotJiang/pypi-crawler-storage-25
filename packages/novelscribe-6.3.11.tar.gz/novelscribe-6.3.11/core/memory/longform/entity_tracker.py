"""Cross-chapter entity tracking — extraction, state history, relationships, arcs."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Optional

from core.memory.longform.models import (
    CharacterArc,
    Entity,
    EntityRelation,
    EntityState,
    EntityType,
    RelationEvolution,
)


class EntityTracker:
    """Track entities across chapters with state history and relationships."""

    def __init__(self, store_path: Path) -> None:
        self._store_path = store_path
        self._entities_path = store_path / "entities.json"
        self._relations_path = store_path / "relations.json"
        self._entities: dict[str, Entity] = {}
        self._relations: list[EntityRelation] = []
        self.load()

    def extract_and_update(
        self,
        chapter_num: int,
        content: str,
        llm_client: Any = None,
    ) -> list[Entity]:
        names = self._extract_names(content)
        updated: list[Entity] = []

        for name, etype in names:
            entity = self._match_or_create(name, etype, chapter_num)
            entity.last_seen_chapter = chapter_num
            entity.mention_count += 1
            entity.state_history.append(
                EntityState(
                    chapter_num=chapter_num,
                    summary=f"Mentioned in chapter {chapter_num}",
                    confidence=0.5,
                )
            )
            updated.append(entity)

        self.save()
        return updated

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        return self._entities.get(entity_id)

    def get_entity_timeline(self, entity_id: str) -> list[EntityState]:
        entity = self._entities.get(entity_id)
        return entity.state_history if entity else []

    def get_active_entities(self, current_chapter: int, within_chapters: int = 5) -> list[Entity]:
        threshold = current_chapter - within_chapters
        return [e for e in self._entities.values() if e.last_seen_chapter >= threshold]

    def get_relations(self, entity_id: str) -> list[EntityRelation]:
        return [r for r in self._relations if r.source_id == entity_id or r.target_id == entity_id]

    def get_character_arc(self, entity_id: str) -> Optional[CharacterArc]:
        entity = self._entities.get(entity_id)
        if not entity or entity.entity_type != EntityType.CHARACTER:
            return None
        if len(entity.state_history) < 2:
            return CharacterArc(
                entity_id=entity_id,
                arc_type="flat",
                beginning_state="unknown",
                current_state="unknown",
                confidence=0.0,
            )

        beginning = entity.state_history[0].summary
        current = entity.state_history[-1].summary
        turning_points = [
            (s.chapter_num, s.summary) for s in entity.state_history if s.confidence > 0.7
        ]
        arc_type = self._detect_arc_type(entity)

        return CharacterArc(
            entity_id=entity_id,
            arc_type=arc_type,
            beginning_state=beginning,
            current_state=current,
            key_turning_points=turning_points,
            confidence=min(1.0, len(entity.state_history) * 0.15),
        )

    def save(self) -> None:
        self._store_path.mkdir(parents=True, exist_ok=True)
        entities_data = {
            k: {
                "entity_id": v.entity_id,
                "name": v.name,
                "entity_type": v.entity_type.value,
                "first_seen_chapter": v.first_seen_chapter,
                "last_seen_chapter": v.last_seen_chapter,
                "mention_count": v.mention_count,
                "attributes": v.attributes,
                "state_history": [
                    {
                        "chapter_num": s.chapter_num,
                        "summary": s.summary,
                        "confidence": s.confidence,
                    }
                    for s in v.state_history
                ],
            }
            for k, v in self._entities.items()
        }
        self._entities_path.write_text(json.dumps(entities_data, indent=2))

        relations_data = [
            {
                "source_id": r.source_id,
                "target_id": r.target_id,
                "relation_type": r.relation_type,
                "first_seen_chapter": r.first_seen_chapter,
                "last_seen_chapter": r.last_seen_chapter,
                "evolution": [
                    {
                        "chapter_num": e.chapter_num,
                        "change": e.change,
                        "description": e.description,
                    }
                    for e in r.evolution
                ],
            }
            for r in self._relations
        ]
        self._relations_path.write_text(json.dumps(relations_data, indent=2))

    def load(self) -> bool:
        if not self._entities_path.exists():
            return False
        try:
            data = json.loads(self._entities_path.read_text())
            for k, v in data.items():
                self._entities[k] = Entity(
                    entity_id=v["entity_id"],
                    name=v["name"],
                    entity_type=EntityType(v["entity_type"]),
                    first_seen_chapter=v["first_seen_chapter"],
                    last_seen_chapter=v["last_seen_chapter"],
                    mention_count=v.get("mention_count", 0),
                    attributes=v.get("attributes", {}),
                    state_history=[
                        EntityState(
                            chapter_num=s["chapter_num"],
                            summary=s["summary"],
                            confidence=s.get("confidence", 0.0),
                        )
                        for s in v.get("state_history", [])
                    ],
                )

            if self._relations_path.exists():
                rdata = json.loads(self._relations_path.read_text())
                self._relations = [
                    EntityRelation(
                        source_id=r["source_id"],
                        target_id=r["target_id"],
                        relation_type=r.get("relation_type", ""),
                        first_seen_chapter=r.get("first_seen_chapter", 0),
                        last_seen_chapter=r.get("last_seen_chapter", 0),
                        evolution=[
                            RelationEvolution(
                                chapter_num=e["chapter_num"],
                                change=e.get("change", ""),
                                description=e.get("description", ""),
                            )
                            for e in r.get("evolution", [])
                        ],
                    )
                    for r in rdata
                ]
            return True
        except (json.JSONDecodeError, KeyError):
            return False

    def _extract_names(self, content: str) -> list[tuple[str, EntityType]]:
        results: list[tuple[str, EntityType]] = []
        seen: set[str] = set()
        capitalized = re.findall(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\b", content)
        skip_words = {
            "The",
            "A",
            "An",
            "In",
            "On",
            "At",
            "To",
            "For",
            "Of",
            "With",
            "By",
            "From",
            "It",
            "He",
            "She",
            "They",
            "We",
            "His",
            "Her",
            "Its",
            "My",
            "Your",
            "This",
            "That",
            "These",
            "Those",
            "But",
            "And",
            "Or",
            "Not",
            "Was",
            "Were",
            "Had",
            "Has",
            "Have",
            "Did",
            "Chapter",
            "Scene",
            "Part",
            "Book",
            "One",
            "Two",
            "Three",
            "There",
            "Here",
            "Now",
            "Then",
            "When",
            "Where",
            "What",
            "How",
            "After",
            "Before",
            "Into",
            "Through",
            "Over",
            "Under",
            "Between",
            "About",
            "Just",
            "Still",
            "Even",
            "Only",
            "Also",
            "Very",
            "Back",
            "Down",
            "Up",
            "Out",
            "Off",
            "Around",
            "Again",
        }
        for name in capitalized:
            if name not in skip_words and name not in seen and len(name) > 2:
                seen.add(name)
                existing = self._find_by_name(name)
                if existing:
                    results.append((name, existing.entity_type))
                else:
                    results.append((name, EntityType.CHARACTER))
        return results

    def _find_by_name(self, name: str) -> Optional[Entity]:
        lower = name.lower()
        for entity in self._entities.values():
            if entity.name.lower() == lower:
                return entity
            if lower in entity.name.lower() or entity.name.lower() in lower:
                return entity
        return None

    def _match_or_create(self, name: str, etype: EntityType, chapter_num: int) -> Entity:
        existing = self._find_by_name(name)
        if existing:
            return existing
        entity_id = name.lower().replace(" ", "_")
        entity = Entity(
            entity_id=entity_id,
            name=name,
            entity_type=etype,
            first_seen_chapter=chapter_num,
            last_seen_chapter=chapter_num,
        )
        self._entities[entity_id] = entity
        return entity

    @staticmethod
    def _detect_arc_type(entity: Entity) -> str:
        if len(entity.state_history) < 3:
            return "flat"
        return "growth"
