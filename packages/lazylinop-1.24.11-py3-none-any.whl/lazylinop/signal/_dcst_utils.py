from lazylinop import LazyLinOp
from array_api_compat import array_namespace


def _mult_xi(N, idx, a):
    """Constructs a LazyLinOp that multiplies some of the elements
    of an input array by a factor and left unchanged the others.

    Args:
        N: int
            Length of the input array.
        idx: list
            List of indices.
        a: list
            List of factors.

    Returns:
        LazyLinOp
    """

    if len(idx) == 0 or len(a) == 0:
        raise Exception("idx and a must have one element at least.")
    if len(idx) != len(a):
        raise Exception("idx and a must have the same length.")

    def _matmat(x):
        # x is always 2d
        xp = array_namespace(x)
        y = xp.asarray(x, dtype=x.dtype, device=x.device, copy=True)
        for i, v in enumerate(idx):
            y[v, :] *= a[i]
        return y

    return LazyLinOp(
        shape=(N, N),
        matmat=lambda x: _matmat(x),
        rmatmat=lambda x: _matmat(x)
    )


def _dtype_sanitized_x(x):
    if 'complex' in str(x.dtype):
        xp = array_namespace(x)
        nz = xp.nonzero(xp.imag(x))
        if nz[0].shape[0] > 0 or nz[1].shape[0] > 0:
            raise ValueError(
                "dct and dst are real functions but x is not real")
    return x


def _check_norm(norm):
    _valid_norms = ['ortho', None, '1/(2n)']
    if norm not in _valid_norms:
        raise ValueError("norm must be either 'ortho'," +
                         " '1/(2n)' or None.")
    return norm


def _scipy_norm(lz_norm):
    # determine *fft, i*fft norm arguments
    # form lz norm argument
    if lz_norm is None:
        sp_norm = 'backward'
        sp_norm_inv = 'forward'
    elif lz_norm == '1/(2n)':
        sp_norm = 'forward'
        sp_norm_inv = 'backward'
    else:  # lz_norm is 'ortho'
        assert lz_norm == 'ortho'
        sp_norm = sp_norm_inv = 'ortho'
    return sp_norm, sp_norm_inv


class LazyLinOpDCST(LazyLinOp):

    def inv(L):
        norm = L.norm
        scale = L.scale
        if norm == 'ortho':
            L_out = L.H
        elif norm == '1/(2n)':
            L_out = scale * L.H
        else:
            assert norm is None
            L_out = 1 / scale * L.H
        if hasattr(L, 'pre_adj'):
            L_out = L_out @ L.pre_adj
        if hasattr(L, 'post_adj'):
            L_out = L.post_adj @ L_out
        return L_out
