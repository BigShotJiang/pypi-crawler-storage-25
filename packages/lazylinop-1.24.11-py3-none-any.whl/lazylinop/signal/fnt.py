from lazylinop import LazyLinOp
from lazylinop.basicops import bitrev
from array_api_compat import array_namespace, is_torch_array


def fnt(N):
    r"""
    Returns a :class:`.LazyLinOp` ```L`` for the
    Fast-Noiselet-Transform (FNT)
    (see :ref:`[1] <noiselets>` for more details).

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two.

    ``L`` is orthonormal, and the :class:`.LazyLinOp`
    for the inverse FNT is ``L.H``.

    We use the
    `implementation of the PyNoiselet package
    <https://gitlab.com/laurentjacques/PyNoiselet>`_
    by Laurent Jacques.

    Args:
        N: ``int``
            Size of the input.
            $N$ must be a power of two.

    Returns:
        :py:class:`LazyLinOp` `L` corresponding to the FNT.

    Examples:
        >>> from lazylinop.signal import fnt
        >>> import numpy as np
        >>> N = 32
        >>> x = np.random.randn(N)
        >>> F = fnt(N)
        >>> y = F @ x
        >>> # easy inverse
        >>> x_ = F.H @ y
        >>> np.allclose(x_, x)
        True

    .. _noiselets:

        **References:**

        [1] Noiselets.
        R. Coifman, F. Geshwind, Y. Meyer
        https://www.sciencedirect.com/science/article/pii/S1063520300903130

    .. seealso::
        - `On the incoherence of noiselet and Haar bases
          <https://hal.science/hal-00453288/document>`_,
        - `PyNoiselet repository
          <https://gitlab.com/laurentjacques/PyNoiselet>`_.
    """
    if not isinstance(N, int):
        raise TypeError("N must be a int and a power of two.")
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")

    # Bit-reversal permutation
    P = bitrev(N)

    ndigit, _N = 0, N
    while _N >> 1 != 0:
        _N >>= 1
        ndigit += 1

    def _matmat(x, adjoint: bool = False):
        xp = array_namespace(x)
        ind = xp.arange(N, dtype=xp.int32, device=x.device)
        pos = (ind % 2 == 1)
        cp = xp.asarray(1 + 1j, dtype=(1j * x).dtype, device=x.device)
        cm = xp.asarray(1 - 1j, dtype=cp.dtype, device=x.device)
        # Apply bit-reversal permutation.
        y = xp.asarray(
            P @ x,
            dtype=cp.dtype,
            device=x.device,
        )
        for _ in range(ndigit):
            # Re-order pos: interleave even and odd indices.
            pos = xp.concat((pos[::2], pos[1::2]))

            ni = ind[~pos]
            nj = ind[pos]

            temp1 = y[ni, :]
            temp2 = y[nj, :]

            y[ni, :] = cm * temp1 + cp * temp2
            y[nj, :] = cp * temp1 + cm * temp2

        if adjoint:
            return (1.0 / N) * xp.flip(y, axis=0)
        else:
            return (1.0 / N) * y

    return LazyLinOp(
        shape=(N, N),
        matmat=lambda x: _matmat(x),
        rmatmat=lambda x: _matmat(x, True),
    )
