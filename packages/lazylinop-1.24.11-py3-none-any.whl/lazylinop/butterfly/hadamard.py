import numpy as np
from lazylinop.butterfly import KsmLazyLinOp
from lazylinop.butterfly import optimize as _optimize
try:
    import torch
except ModuleNotFoundError:
    torch = None
try:
    import cupy as cp
except ModuleNotFoundError:
    cp = None
import array_api_compat


def _hadamard_square_dyadic_ks_values(N: int,
                                      dtype: str = 'float64',
                                      device='cpu'):
    r"""
    Return a list of ``ks_values`` that corresponds
    to the ``H @ P.T`` matrix decomposition into
    ``n = int(np.log2(N))`` factors, where ``H`` is the Hadamard
    matrix and ``P`` the bit-reversal permutation matrix.
    The size $N=2^n$ of the Hadamard matrix must be a power of $2$.

    We can draw the square-dyadic decomposition for $N=16$:

    .. image:: _static/square_dyadic.svg

    Args:
        N: ``int``
            FWHT of size $N=2^n$.
        dtype: ``str``, optional
            The dtype of Hadamard matrix elements.
            The defaut value is 'float64'.
        device: optional
            Send ``ks_values`` to device ``device``.
            The default value is ``'cpu'``.

    Returns:
        List of 4d arrays corresponding to ``ks_values``.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``ks_values`` is ``numpy``
        and dtype is ``'float64'``.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly.hadamard import _hadamard_square_dyadic_ks_values
        >>> from lazylinop.butterfly import ksm
        >>> from lazylinop.signal import fwht
        >>> N = 2 ** 5
        >>> ks_values = _hadamard_square_dyadic_ks_values(N)
        >>> x = np.random.randn(N)
        >>> L = ksm(ks_values)
        >>> np.allclose(fwht(N) @ x, (L @ x) / np.sqrt(N))
        True
    """
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")
    norm = 1.0  # / np.sqrt(2.0)
    p = int(np.log2(N))
    # Infer the namespace from dtype and device.
    try:
        import array_api_compat.torch as xp
        xp.asarray([1], dtype=dtype, device=device)
    except (ModuleNotFoundError, TypeError):
        try:
            import array_api_compat.cupy as xp
            xp.asarray([1], dtype=dtype, device=device)
        except (ModuleNotFoundError, ValueError):
            import array_api_compat.numpy as xp
    # Build ks_values.
    if 'bool' in str(dtype):
        _dtype = xp.int32
    else:
        _dtype = dtype
    ks_values = [None] * p
    for n in range(p):
        if n == (p - 1):
            h2 = norm * xp.asarray([[1, 1], [1, -1]], dtype=_dtype,
                                   device=device)
            a = N // 2
            b, c = 2, 2
            d = 1
            ks_values[n] = xp.empty((a, b, c, d), dtype=_dtype,
                                    device=device)
            for i in range(a):
                ks_values[n][i, :, :, 0] = h2
        else:
            s = N // 2 ** (p - n)
            t = N // 2 ** (n + 1)
            a = s
            b, c = 2, 2
            d = t
            ks_values[n] = xp.empty((a, b, c, d), dtype=_dtype,
                                    device=device)
            # Map between 2d and 4d representations.
            # col = i * c * d + k * d + l
            # row = i * b * d + j * d + l
            # Loop over the a blocks.
            for i in range(a):
                for u in range(t):
                    for v in range(4):
                        if v == 0:
                            # Identity.
                            sub_col = u
                            sub_row = u
                            tmp = norm
                        elif v == 1:
                            # Identity.
                            sub_col = u + t
                            sub_row = u
                            tmp = norm
                        elif v == 2:
                            # Identity.
                            sub_col = u
                            sub_row = u + t
                            tmp = norm
                        else:
                            # -Identity.
                            sub_col = u + t
                            sub_row = u + t
                            tmp = -norm
                        j = sub_row // d
                        k = sub_col // d
                        ks_values[n][i, j, k, sub_col - k * d] = tmp
    if 'bool' in str(dtype):
        bs = [None] * p
        for i, k in enumerate(ks_values):
            k[k == -1] = 0
            bs[i] = xp.asarray(k, dtype=xp.bool)
        return bs
    else:
        return ks_values


def fwht(N: int, optimize: bool = False, **kwargs):
    r"""
    Return a :class:`LazyLinOp` `L` with the Butterfly structure
    corresponding to the Fast-Walsh-Hadamard-Transform (FWHT).

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two.

    ``L`` is orthogonal and *symmetric* and
    the inverse WHT operator is ``L.T = L``.

    Args:
        N: ``int``
            Size of the FWHT. $N$ must be a power of two.
        optimize: ``bool``, optional
            :octicon:`alert-fill;1em;sd-text-danger`
            Optimization usually results in the most optimized
            implementation, but the optimization process may be time
            consuming, depending notably on the size of the factors,
            on the backend
            (see :py:func:`lazylinop.butterfly.ksm` for more details),
            on the dtype and on the device of the ``ks_values``.
            The default value is ``False``.

    Kwargs:
        Additional arguments ``ksm_backend``, ``ksm_params``,
        ``dtype`` and ``device`` of the ``ks_values``
        to pass to :py:func:`ksm` function.
        See :py:func:`ksm` for more details.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``L.ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``L.ks_values`` is ``numpy``
        and dtype is ``'float64'``.

    Returns:
        :class:`LazyLinOp` `L` corresponding to the FWHT.
        ``L`` is equivalent to ``hadamard(N, backend, dtype) / sqrt(N)``.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import fwht as bfwht
        >>> from lazylinop.signal import fwht as sfwht
        >>> N = 2 ** 5
        >>> x = np.random.randn(N).astype('float64')
        >>> y = bfwht(N) @ x
        >>> z = sfwht(N) @ x
        >>> np.allclose(y, z)
        True

    .. seealso::

        :py:func:`hadamard`
    """
    return hadamard(
        N,
        optimize,
        normalize=True,
        **kwargs,
    )


def hadamard(N: int, optimize: bool = False, **kwargs):
    r"""
    Return a :class:`LazyLinOp` `L` with the Butterfly structure
    corresponding to the Hadamard matrix.

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two.

    ``L`` is not orthogonal and its inverse is ``L.T / N``.
    ``L`` is *symmetric*.

    The number of factors $n$ of the square-dyadic decomposition
    is given by $n=\log_2\left(N\right)$.

    Infer the namespace (see
    `array-api-compat <https://data-apis.org/array-api-compat/>`_
    for more details)
    of ``L.ks_values`` from ``dtype`` and ``device`` arguments.
    By default, namespace of ``L.ks_values`` is ``numpy``
    and dtype is ``'float64'``.

    Args:
        N: ``int``
            Size of the Hadamard matrix.
            $N$ must be a power of two.
        optimize: ``bool``, optional
            :octicon:`alert-fill;1em;sd-text-danger`
            Optimization usually results in the most optimized
            implementation, but the optimization process may be time
            consuming, depending notably on the size of the factors,
            on the backend
            (see :py:func:`lazylinop.butterfly.ksm` for more details),
            on the dtype and on the device of the ``ks_values``.
            The default value is ``False``.

    Kwargs:
        Additional arguments ``ksm_backend``, ``ksm_params``,
        ``dtype`` and ``device`` of the ``ks_values``
        to pass to :py:func:`ksm` function.
        The default values are ``'xp'``, ``None``,
        ``float64`` and ``'cpu'``.
        See :py:func:`ksm` for more details.

    Returns:
        :class:`LazyLinOp` `L` corresponding to the
        Hadamard matrix.

    Examples:
        >>> import numpy as np
        >>> import scipy as sp
        >>> from lazylinop.butterfly import hadamard
        >>> N = 2 ** 5
        >>> x = np.random.randn(N).astype('float64')
        >>> y = hadamard(N) @ x
        >>> z = sp.linalg.hadamard(N) @ x
        >>> np.allclose(y, z)
        True

    .. seealso::

        - `Wikipedia <https://en.wikipedia.org/wiki/Hadamard_matrix>`_,
        - :py:func:`fwht`.
    """
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")

    keys = kwargs.keys()
    ksm_backend = kwargs["ksm_backend"] if "ksm_backend" in keys else 'xp'
    dtype = kwargs["dtype"] if "dtype" in keys else 'float64'
    device = kwargs["device"] if "device" in keys else 'cpu'
    ksm_params = kwargs["ksm_params"] if "ksm_params" in keys else None

    ksv = _hadamard_square_dyadic_ks_values(
        N, dtype=dtype, device=device)

    if optimize:
        # Use ksv device.
        xp = array_api_compat.array_namespace(ksv[0])
        params = {'backend': ksm_backend}
        if "opt_dtype" in kwargs.keys():
            # Optimize against input with dtype.
            params['dtype'] = kwargs["opt_dtype"]
        elif (
                "int8" in str(dtype) or
                "int16" in str(dtype) or
                "int32" in str(dtype)
        ):
            # Use Hadamard specialized kernel.
            params['dtype'] = xp.float64
        else:
            # Default uses ks_values dtype.
            params['dtype'] = dtype
        ksv = _optimize(
            ksv, strategy='benchmark', params=params)

    normalize = False
    if 'normalize' in kwargs.keys() and isinstance(kwargs['normalize'], bool):
        normalize = kwargs['normalize']
    if normalize:
        xp = array_api_compat.array_namespace(ksv[0])
        norm = 1.0 / xp.sqrt(xp.asarray(N, dtype=dtype, device=device))
        _dtype = (ksv[0] * norm).dtype
        ksv = [
            xp.asarray(
                k,
                dtype=_dtype,
                device=device,
                copy=True,
            ) for k in ksv
        ]
        ksv[0] *= norm

    return KsmLazyLinOp(
        ksv,
        backend=ksm_backend,
        params=ksm_params,
    )
