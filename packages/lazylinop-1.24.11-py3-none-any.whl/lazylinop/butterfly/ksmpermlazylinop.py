from lazylinop.butterfly import KsmLazyLinOp
from lazylinop.butterfly.ksm import _ksm, _multiple_ksm
from array_api_compat import (
    array_namespace, is_array_api_obj,
    is_cupy_array, is_numpy_array, is_torch_array)
from lazylinop.basicops import bitrev
from numbers import Number
from warnings import warn


class KsmPermLazyLinOp(KsmLazyLinOp):
    """
    :py:class:`KsmPermLazyLinOp` class is a specialization of
    :py:class:`.LazyLinOp` when the underlying linear operator
    resulting from a call to :py:func`lazylinop.butterfly.dft` function.

    The operations ``s * L``, ``L.T``, ``L.H`` and ``L.conj()``
    return an instance of the :py:class:`KsmPermLazyLinOp` class.
    """

    def __init__(
            self,
            ks_values: list,
            backend="xp",
            params: list = None,
            bitrev_perm: str = 'right',
            shape: tuple = None,
            matmat=None,
            rmatmat=None,
            **kwargs,
    ):
        """
        Create a ``lazylinop.butterfly.KsmPermLazyLinOp`` instance ``L``.

        Args:
            ks_values: list of 4d arrays
                All the ``ks_values`` must have the same ``dtype``.
                See :py:func:`lazylinop.butterfly.ksm`
                for more details.
            backend: optional
                See :py:func:`lazylinop.butterfly.ksm`
                for more details.
            params: optional
                See :py:func:`lazylinop.butterfly.ksm`
                for more details.
            bitrev_perm: ``str``, optional
                Possible choices among the following:

                - ``'right'`` (default):
                  add bit-reversal permutation to the right.
                  ``matmat`` returns $L*P*V$ where ``P``
                  is a :py:class:`.LazyLinOp` and where $V$ is a batch
                  of vectors of shape $(N,~K)$.
                - ``'left'``: add bit-reversal permutation to the left.
                  ``matmat`` returns $P*L*V$ where ``P``
                  is a :py:class:`.LazyLinOp` and where $V$ is a batch
                  of vectors of shape $(N,~K)$.
                - ``'both'``: add bit-reversal permutation to
                  the left and to the right.
                  ``matmat`` returns $P*L*P*V$ where ``P``
                  is a :py:class:`.LazyLinOp` and where $V$ is a batch
                  of vectors of shape $(N,~K)$
            shape: ``tuple[int, int]``, optional
                Dimensions of operator $L$ is $(M,~N)$.
                The default value is ``None``:
                use ``ks_values`` to determine $M$ and $N$.
            matmat: ``callable``, optional
                Returns $L*V$ where $V$ is a batch
                of vectors of shape $(N,~K)$.
                The output matrix shape is $(M,~K)$.
                The default value is ``None``:
                ``matmat`` is determined according to
                ``ks_values`` and ``backend``.
            rmatmat: ``callable``, optional
                Returns $L^H*V$ where $V$ is a batch
                of vectors of shape $(M,~K)$.
                The output matrix shape is $(N,~K)$.
                The default value is ``None``:
                ``rmatmat`` is determined according to
                ``ks_values`` and ``backend``.

        Return:
            ``KsmPermLazyLinOp``

        Examples:
            >>> from lazylinop.butterfly import dft
            >>> from lazylinop.butterfly import KsmPermLazyLinOp
            >>> import numpy as np
            >>> N = 16
            >>> L = dft(N, backend="xp")
            >>> isinstance(L, KsmPermLazyLinOp)
            True
            >>> H = L.H
            >>> isinstance(H, KsmPermLazyLinOp)
            True
            >>> # Check that ks_values of adjoint operator H
            >>> # can be deduced from operator L.
            >>> ksv = L.ks_values
            >>> np.allclose(np.conj(ksv[0].swapaxes(1, 2)), H.ks_values[-1])
            True
        """

        if bitrev_perm not in ['left', 'both', 'right']:
            raise Exception(
                "bitrev_perm must be either 'left', 'both' or 'right'.")

        for k in kwargs.keys():
            if k not in [
                    "interval",
                    "ksm_data",
                    "ksv_xp",
            ]:
                raise Exception("Unknown kwargs key.")

        # Compute namespace of ks_values.
        if callable(ks_values) and "ksv_xp" not in kwargs.keys():
            raise Exception(
                "ks_values is a callable: expect ksv_xp in kwargs.")
        xp = (
            kwargs["ksv_xp"] if callable(ks_values) else
            array_namespace(ks_values[0])
        )

        if matmat is None or rmatmat is None:

            # Compute input dimension because of the bit-reversal
            # permutation we need to check if it is a power of 2.
            if shape is not None:
                N = shape[1]
            else:
                if callable(ks_values):
                    a, _, c, d = ks_values()[-1].shape
                else:
                    a, _, c, d = ks_values[-1].shape
                N = a * c * d
            if not (((N & (N - 1)) == 0) and N > 0):
                raise ValueError("N must be a power of two.")

            if "interval" in kwargs.keys():
                interval = kwargs["interval"]
                _is_tuple = isinstance(interval, tuple)
                if not _is_tuple or (
                        _is_tuple and len(interval) != 2):
                    raise Exception(
                        "interval must be a tuple of two" +
                        " integers (start, end) or (start, None).")
            else:
                interval = (0, N)

            if interval != (0, N):
                # First copy the ks_values.
                ksv = [xp.asarray(k, copy=True) for k in ks_values]
            else:
                ksv = ks_values

            # Compute leftmost ks_values according to interval.
            start = interval[0]
            end = N if interval[1] is None else interval[1]
            if start >= end:
                raise Exception("interval must satisfy start < end.")

            if start > 0 or end < N:
                # Select a, b and d according to interval argument.
                # By construction a is always equal to 1.
                # a * c * d is the number of columns that is left
                # unchanged after the slicing along the rows.
                # Therefore only b changes.
                a, b, c, d = ksv[0].shape
                assert a == 1
                # Modify start and end to left d unchanged.
                # At the end we will need another slicing.
                _start = d * (start // d)
                _end = d * (end // d + int(end % d != 0))
                rows = xp.arange(_start, _end)
                i_a = rows // (b * d)
                i_b = xp.unique((rows - i_a * b * d) // d)
                ksv[0] = ksv[0][:, i_b, :, :]
            else:
                _start, _end = start, end

            if start == _start and end == _end:
                # No modifications of start and end.
                # Therefore, no need to slice again along the rows.
                pass
            else:
                # return L[(start - _start):(end - _start), :]
                raise Exception(
                    "KsmPermLazyLinOp interval argument is not valid.")

            if backend in ("cupyx", "scipy", "xp"):
                ksm_data = None
                _matmat, _rmatmat = _ksm(ksv, backend)
            else:
                # FIXME: params_perm
                # Check params in _multiple_ksm fn.
                _matmat, _rmatmat, ksm_data = _multiple_ksm(
                    ksv,
                    params=params,
                    backend=backend,
                    perm=False,
                    params_perm=None,
                )

            # Add bit-reversal permutation(s).
            P = bitrev(N)
            # rmatmat position of the bit-reversal permutation.
            rbitrev_perm = {
                'left': 'right',
                'both': 'both',
                'right': 'left',
            }[bitrev_perm]

            def _fx(f, x, bitrev_perm):
                if bitrev_perm == "left":
                    return P @ f(x)
                elif bitrev_perm == "both":
                    return P @ f(P @ x)
                elif bitrev_perm == "right":
                    return f(P @ x)

            super().__init__(
                ksv,
                backend=backend,
                params=params,
                shape=shape,
                matmat=lambda x: _fx(_matmat, x, bitrev_perm),
                rmatmat=lambda x: _fx(_rmatmat, x, rbitrev_perm),
                ksv_xp=xp,
            )
            # ksm_data is used to host/device pointers.
            self._ksm_data = ksm_data
        else:
            # Use already existing matmat and rmatmat
            # if both keys exist.
            super().__init__(
                ks_values,
                backend=backend,
                params=params,
                shape=shape,
                matmat=matmat,
                rmatmat=rmatmat,
                ksv_xp=xp,
            )
            # ksm_data is used to host/device pointers.
            self._ksm_data = kwargs["ksm_data"]
        self._bitrev_perm = bitrev_perm

    @property
    def bitrev_perm(self):
        return self._bitrev_perm

    @bitrev_perm.setter
    def bitrev_perm(self, value):
        warn("You cannot modify self.bitrev_perm.")

    @bitrev_perm.deleter
    def bitrev_perm(self):
        pass

    def conj(self):
        """
        Returns the :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        conjugate.
        """
        # Inheritance of the ksm_data.
        return KsmPermLazyLinOp(
            lambda: [
                self.ksv_xp.conj(k) for k in self.ks_values
            ],
            backend=self.backend,
            params=self.params,
            bitrev_perm=self.bitrev_perm,
            shape=self.shape,
            matmat=lambda x: self.ksv_xp.conj(
                self.matmat(self.ksv_xp.conj(x))
            ),
            rmatmat=lambda x: self.ksv_xp.conj(
                self.rmatmat(self.ksv_xp.conj(x))
            ),
            ksv_xp=self.ksv_xp,
            ksm_data=self.ksm_data,
        )

    @property
    def T(self):
        """
        Returns the :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        transpose.
        """
        rbitrev_perm = {
            'left': 'right',
            'both': 'both',
            'right': 'left',
        }[self.bitrev_perm]
        # Inheritance of the ksm_data.
        return KsmPermLazyLinOp(
            lambda: [
                self.ksv_xp.asarray(
                    k.swapaxes(1, 2),
                    copy=True,
                ) for k in self.ks_values
            ][::-1],
            backend=self.backend,
            params=self.params_transposition(),
            bitrev_perm=rbitrev_perm,
            shape=(self.shape[1], self.shape[0]),
            matmat=lambda x: self.ksv_xp.conj(
                self.rmatmat(
                    self.ksv_xp.conj(x)
                )
            ),
            rmatmat=lambda x: self.ksv_xp.conj(
                self.matmat(
                    self.ksv_xp.conj(x)
                )
            ),
            ksv_xp=self.ksv_xp,
            ksm_data=self.ksm_data,
        )

    @property
    def H(self):
        """
        Returns the :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        adjoint/transconjugate.
        """
        rbitrev_perm = {
            'left': 'right',
            'both': 'both',
            'right': 'left',
        }[self.bitrev_perm]
        # Inheritance of the ksm_data.
        return KsmPermLazyLinOp(
            lambda: [
                self.ksv_xp.conj(
                    k.swapaxes(1, 2)
                ) for k in self.ks_values
            ][::-1],
            backend=self.backend,
            params=self.params_transposition(),
            bitrev_perm=rbitrev_perm,
            shape=(self.shape[1], self.shape[0]),
            matmat=lambda x: self.rmatmat(x),
            rmatmat=lambda x: self.matmat(x),
            ksv_xp=self.ksv_xp,
            ksm_data=self.ksm_data,
        )

    def __mul__(self, s):
        """
        Returns the :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        for self * s.

        Args:
            s: a scalar.
        """
        if (is_array_api_obj(s) and s.shape == ()) or isinstance(s, Number):
            # Inheritance of the ksm_data.
            return KsmPermLazyLinOp(
                lambda: [
                    (
                        s if i == 0 else 1 + 0 * s
                    ) * k for i, k in enumerate(self.ks_values)
                ],
                backend=self.backend,
                params=self.params,
                bitrev_perm=self.bitrev_perm,
                shape=self.shape,
                matmat=lambda x: self.matmat(x) * s,
                rmatmat=lambda x: self.rmatmat(x) * s,
                ksv_xp=self.ksv_xp,
                ksm_data=self.ksm_data,
            )
        else:
            raise TypeError("Cannot multiply by a non-scalar object")

    def __pow__(self, n):
        if n != 1:
            L = super().__pow__(n)
        else:
            # Inheritance of the ksm_data.
            L = KsmPermLazyLinOp(
                ks_values=lambda: [
                    self.ksv_xp.asarray(k, copy=True) for k in self.ks_values],
                backend=self.backend,
                params=self.params,
                bitrev_perm=self.bitrev_perm,
                shape=self.shape,
                matmat=self.matmat,
                rmatmat=self.rmatmat,
                ksv_xp=self.ksv_xp,
                ksm_data=self.ksm_data,
            )
        return L

    @staticmethod
    def del_all_contexts():
        """
        Delete all PyOpenCL and PyCUDA contexts.
        After that, all the :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        and :py:class:`lazylinop.butterfly.KsmLazyLinOp`
        using PyOpenCL or PyCUDA backends won't work anymore.
        """
        KsmLazyLinOp.del_all_contexts()

    @staticmethod
    def load(name: str):
        """
        Load ``L`` an instance of
        :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        from file ``name.json``.
        The file ``name.json`` has been created by
        :py:func:`lazylinop.butterfly.KsmPermLazyLinOp.save`.

        Args:
            name: ``str``
                Name of the ``.json`` file where to load ``L``.

        Returns:
            ``L`` an instance of
            :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`.
            If file does not exist, return ``None``.

        .. seealso::
            - :py:func:`lazylinop.butterfly.KsmPermLazyLinOp.save`.

        Examples:
            >>> import numpy as np
            >>> from lazylinop.butterfly import dft, KsmPermLazyLinOp
            >>> x = np.random.randn(8)
            >>> L = dft(8, backend="xp")
            >>> L.save("dft_8x8")
            >>> L_ = KsmPermLazyLinOp.load("dft_8x8")
            >>> y = L @ x
            >>> y_ = L_ @ x
            >>> np.allclose(y, y_)
            True
        """
        try:
            from numpy import asarray as np_asarray
            from json import load
            L = None
            with open(name + '.json', 'r') as f:
                data = load(f)
                # Loop over the Kronecker-sparse factors.
                ks_values = []
                backend = data['backend']
                if data['params'] is None:
                    params = None
                else:
                    params = [tuple(p) for p in data['params']]
                bitrev_perm = data["bitrev_perm"]
                for k in data.keys():
                    if k == "backend" or k == "params" or k == "bitrev_perm":
                        continue
                    if data[k]['package'] == 'cupy':
                        import array_api_compat.cupy as xp
                    elif data[k]['package'] == 'numpy':
                        import array_api_compat.numpy as xp
                    elif data[k]['package'] == 'torch':
                        import array_api_compat.torch as xp
                    if 'complex' in str(data[k]['dtype']):
                        ks_values.append(
                            xp.asarray(
                                np_asarray(
                                    data[k]['ks_values_real'],
                                    dtype=data[k]['dtype'],
                                ) +
                                1j * np_asarray(
                                    data[k]['ks_values_imag'],
                                    dtype=data[k]['dtype'],
                                ),
                                device=data[k]['device'],
                            )
                        )
                    else:
                        ks_values.append(
                            xp.asarray(
                                np_asarray(
                                    data[k]['ks_values_real'],
                                    dtype=data[k]['dtype'],
                                ),
                                device=data[k]['device'],
                            )
                        )
                L = KsmPermLazyLinOp(
                    ks_values,
                    backend=backend,
                    params=params,
                    bitrev_perm=bitrev_perm,
                )
            return L
        except IOError:
            raise IOError(f"Did not find {name}.json.")

    def save(self, name: str):
        """
        Save ``L`` returned by ``L = dft(...)``
        or ``L = KsmPermLazyLinOp(...)`` in a json file ``name + '.json'``.

        Args:
            name: ``str``
                Name of the file.

        .. seealso::
            - :py:func:`lazylinop.butterfly.KsmPermLazyLinOp.load`.

        Examples:
            >>> import numpy as np
            >>> from lazylinop.butterfly import dft, KsmPermLazyLinOp
            >>> x = np.random.randn(8)
            >>> L = dft(8, backend="xp")
            >>> L.save("dft_8x8")
            >>> L_ = KsmPermLazyLinOp.load("dft_8x8")
            >>> y = L @ x
            >>> y_ = L_ @ x
            >>> np.allclose(y, y_)
            True
        """
        from json import dump
        data = {}
        for i, k in enumerate(self.ks_values):
            data["factor" + str(i)] = {}
            if is_torch_array(k):
                data["factor" + str(i)]['package'] = 'torch'
                data["factor" + str(i)]['device'] = str(k.device)
            elif is_numpy_array(k):
                data["factor" + str(i)]['package'] = 'numpy'
                data["factor" + str(i)]['device'] = k.device
            elif is_cupy_array(k):
                data["factor" + str(i)]['package'] = 'cupy'
                data["factor" + str(i)]['device'] = int(k.device)
            # Store current factor in a dict.
            data["factor" + str(i)]['ks_values_real'] = k.real.tolist()
            if 'complex' in str(k.dtype):
                data["factor" + str(i)]['ks_values_imag'] = k.imag.tolist()
            if is_torch_array(k):
                data["factor" + str(i)][
                    'dtype'] = str(k.numpy(force=True).dtype)
            else:
                data["factor" + str(i)]['dtype'] = str(k.dtype)
        data["params"] = self.params
        data["backend"] = self.backend
        data["bitrev_perm"] = self.bitrev_perm
        with open(name + '.json', 'w') as f:
            dump(data, f, indent=1)


def _dft_square_dyadic_ks_values(N: int,
                                 dtype: str = 'complex128',
                                 device='cpu'):
    r"""
    Return a list of ``ks_values`` that corresponds
    to the ``F @ P.T`` matrix decomposition into
    ``n = int(np.log2(N))`` factors, where ``F`` is the DFT matrix
    and ``P`` the bit-reversal permutation matrix.
    The size $N=2^n$ of the DFT must be a power of $2$.

    We can draw the square-dyadic decomposition for $N=16$:

    .. image:: _static/square_dyadic.svg

    Args:
        N: ``int``
            DFT of size $N=2^n$.
        dtype: ``str``, optional
            It could be either ``'complex64'`` or ``'complex128'`` (default).
        device: optional
            Send ``ks_values`` to device ``device``.
            The default value is ``'cpu'``.

    Returns:
        List of 4d arrays corresponding to ``ks_values``.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly.dft import _dft_square_dyadic_ks_values
        >>> from lazylinop.butterfly import ksm
        >>> from lazylinop.signal import fft
        >>> from lazylinop.basicops import bitrev
        >>> N = 2 ** 5
        >>> ks_values = _dft_square_dyadic_ks_values(N)
        >>> x = np.random.randn(N)
        >>> L = ksm(ks_values)
        >>> P = bitrev(N)
        >>> np.allclose(fft(N) @ x, L @ P @ x)
        True

    References:
        - Learning Fast Algorithms for Linear Transforms
          Using Butterfly Factorizations.

          Dao T, Gu A, Eichhorn M, Rudra A, Re C.
          Proc Mach Learn Res. 2019 Jun;97:1517-1527.
          PMID: 31777847; PMCID: PMC6879380.
    """
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")
    # int(np.log2(N))
    p, _N = 0, N
    while _N >> 1 != 0:
        _N >>= 1
        p += 1
    # Infer the namespace from dtype and device.
    try:
        import array_api_compat.torch as xp
        xp.asarray([1], dtype=dtype, device=device)
    except (ModuleNotFoundError, TypeError):
        try:
            import array_api_compat.cupy as xp
            xp.asarray([1], dtype=dtype, device=device)
        except (ModuleNotFoundError, ValueError):
            import array_api_compat.numpy as xp
    inv_sqrt2 = 1.0 / xp.sqrt(
        xp.asarray([2.0], dtype=dtype, device=device))
    # Build ks_values.
    ks_values = [None] * p
    for n in range(p):
        if n == (p - 1):
            f2 = xp.asarray([[1.0, 1.0], [1.0, -1.0]],
                            dtype=dtype, device=device) * inv_sqrt2
            a = N // 2
            b, c = 2, 2
            d = 1
            ks_values[n] = xp.empty((a, b, c, d), dtype=dtype,
                                    device=device)
            for i in range(a):
                ks_values[n][i, :, :, 0] = f2
        else:
            s = N // 2 ** (p - n)
            t = N // 2 ** (n + 1)
            w = xp.exp(
                xp.asarray([2.0j * xp.pi / (2 * t)],
                           dtype=dtype, device=device))
            omega = w ** (-xp.arange(t, device=device))
            a = s
            b, c = 2, 2
            d = t
            ks_values[n] = xp.empty((a, b, c, d), dtype=dtype,
                                    device=device)
            # Map between 2d and 4d representations.
            # col = i * c * d + k * d + l
            # row = i * b * d + j * d + l
            # Loop over the a blocks.
            for i in range(a):
                for u in range(t):
                    for v in range(4):
                        if v == 0:
                            # Identity.
                            sub_col = u
                            sub_row = u
                            tmp = inv_sqrt2
                        elif v == 1:
                            # diag(omega).
                            sub_col = u + t
                            sub_row = u
                            tmp = omega[u] * inv_sqrt2
                        elif v == 2:
                            # Identity.
                            sub_col = u
                            sub_row = u + t
                            tmp = inv_sqrt2
                        else:
                            # -diag(omega)
                            sub_col = u + t
                            sub_row = u + t
                            tmp = -omega[u] * inv_sqrt2
                        j = sub_row // d
                        k = sub_col // d
                        ks_values[n][i, j, k, sub_col - k * d] = tmp[0]
    return ks_values
