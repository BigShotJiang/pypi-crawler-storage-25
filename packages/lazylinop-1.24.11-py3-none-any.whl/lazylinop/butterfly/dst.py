from math import sqrt
from lazylinop.butterfly import Chain, dft, ksd
from lazylinop.butterfly import optimize as _optimize
from lazylinop.butterfly import dct, KsmPermLazyLinOp
from lazylinop.signal import chunk, fft
from lazylinop.signal.dst import _dtype_sanitized_x
from lazylinop.basicops import (
    anti_eye, bitrev, diag, eye, mpad, slicer, vstack)
from lazylinop import LazyLinOp


def dst(
        N: int,
        type: int = 2,
        optimize: bool = False,
        real_valued: bool = False,
        **kwargs,
):
    r"""
    Returns a :class:`.LazyLinOp` ```L`` for the Direct Sine Transform (DST).

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two except for DST I (see below).

    ``L`` is orthonormal, and the :class:`.LazyLinOp`
    for the inverse DST is ``L.T``.

    Args:
        N: ``int``
            Size of the input (N > 0).

            $N$ must be:

            - a power of two for DCT II, III and IV.
            - a power of two minus one for DCT I.
        type: ``int``, optional
            1, 2, 3, 4 (I, II, III, IV).
            Defaut is 2.
            See `SciPy DST <https://docs.scipy.org/doc/scipy/
            reference/generated/
            scipy.fft.dst.html#scipy-fft-dst>`_ and
            `CuPy DST <https://docs.cupy.dev/en/latest/reference/
            generated/cupyx.scipy.fft.dst.html>`_ for more details.
        optimize: ``bool``, optional
            :octicon:`alert-fill;1em;sd-text-danger`
            Optimization usually results in the most optimized
            implementation, but the optimization process may be time
            consuming, depending notably on the size of the factors,
            on the backend
            (see :py:func:`lazylinop.butterfly.ksm` for more details),
            on the dtype and on the device of the ``ks_values``.
            The default value is ``False``.
        real_valued: ``bool``, optional
            According the a seminal paper of Makhoul the DST matrix of size N,
            $\mathbf{S}_N$, can be expressed in terms of the
            DFT matrix of size M, $\mathbf{F}_{M}$ where $M$ depends on the DST-type.
            The most well-known expression is as
            $\mathbf{S}_N=-\mathtt{Im}(\mathbf{L}\mathbf{F}_MR)$
            where the left and right matrices $\mathbf{L}$ (of size $N\times M$)
            and $\mathbf{R}$ (of size $M\times N$) are real-valued,
            but the DFT matrix $\mathbf{F}_M$ is complex-valued.

            This shows the existence of a "butterfly implementation"
            of the DST $\mathbf{S}_N=-\mathtt{Im}(\mathbf{L}\mathbf{B}_M\mathbf{R})$
            however with two caveats:

            - the Kronecker-sparse factors in $\mathbf{B}_M$ are *complex-valued*
              ``real_valued = False``
            - because of the $\mathtt{Im()}$ operator,
              this actually expresses the DST via a *sum* of two butterfly matrices
              $\mathbf{S}_N=\mathbf{L}(\mathbf{B}_M-\overline{\mathbf{B}_M})\mathbf{R}$.

            Since the DST is real-valued, it would be desirable to have instead
            an expression in terms of a *single* butterfly matrix $\mathbf{B}$
            with real-valued factors ``real_valued = True``,
            $\mathbf{S}_N=\mathbf{LB'R}$ where
            $\mathbf{B}':=\mathtt{real}(\mathbf{B}_M)=(\mathbf{B}_M-\overline{\mathbf{B}_M})/2$.

            By the complementary low-rank characterization of butterfly matrices
            it is possible to show that $\mathbf{B}'$ admits a Kronecker-sparse
            factorization with a *different* chain where each
            Kronecker-sparse pattern $(a,b,c,d)$ is replaced by
            $(a,2b,2c,d)$ except the lefmost (which is replaced by $(a,b,2c,d)$)
            and the rightmost (replaced by $(a,2b,c,d)$) ones.

            :octicon:`alert-fill;1em;sd-text-danger` The creation of the
            operator ``L = dst(N, ..., real_valued=True)`` can take more
            than one minute when $N\ge 8192$ due to a call
            to the decomposition function :py:func:`ksd`.

    Kwargs:
        Additional arguments ``ksm_backend``, ``ksm_params``,
        ``dtype`` and ``device`` of the ``ks_values``
        to pass to :py:func:`ksm` function.
        The default values are ``'xp'``, ``None``,
        ``complex128`` and ``'cpu'``.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``L.ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``L.ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Returns:
        :py:class:`.LazyLinOp`

    Example:
        >>> from lazylinop.butterfly import dst
        >>> from scipy.fft import dst as sp_dst
        >>> import numpy as np
        >>> N = 32
        >>> x = np.random.randn(N)
        >>> F = dst(N, 2)
        >>> y = F @ x
        >>> np.allclose(y, sp_dst(x, norm='ortho'))
        True
        >>> # compute the inverse DST
        >>> z = F.T @ y
        >>> np.allclose(z, x)
        True

    .. seealso::
        - `DST (Wikipedia) <https://en.wikipedia.org/
          wiki/Discrete_sine_transform>`_,
        - `SciPy DST <https://docs.scipy.org/doc/scipy/
          reference/generated/ scipy.fft.dst.html>`_,
        - `SciPy inverse DST <https://docs.scipy.org/doc/scipy/
          reference/generated/scipy.fft.idst.html>`_,
        - `CuPy DST <https://docs.cupy.dev/en/latest/reference/
          generated/cupyx.scipy.fft.dst.html>`_,
        - :py:func:`lazylinop.signal.dct`.
        - :py:func:`lazylinop.signal.dst`,
        - :py:func:`lazylinop.butterfly.dct`.
    """

    if type == 1:
        if N <= 1:
            raise Exception("DST I: N must be > 1.")
    p, _N = 0, N + int(type == 1)
    while _N >> 1 != 0:
        p += 1
        _N >>= 1
    if type == 1 and (N + 1) != 2 ** p:
        raise Exception("DST I: size of the input plus one" +
                        "  must be a power of two.")
    if type in [2, 3, 4] and N != 2 ** p:
        raise Exception("DST II, III, IV: size of the input" +
                        " must be a power of two.")

    dtype = kwargs.get('dtype', 'complex128')
    device = kwargs.get('device', 'cpu')
    ksm_backend = kwargs.get("ksm_backend", 'xp')
    ksm_params = kwargs.get("ksm_params", None)

    # Infer the namespace from dtype and device.
    try:
        import array_api_compat.torch as xp
        xp.asarray([1], dtype=dtype, device=device)
    except (ModuleNotFoundError, TypeError):
        try:
            import array_api_compat.cupy as xp
            xp.asarray([1], dtype=dtype, device=device)
        except (ModuleNotFoundError, ValueError):
            import array_api_compat.numpy as xp

    # The square dyadic chain for butterfly matrices.
    if type == 1:
        Q = 2 * (N + 1)
    elif type == 2 or type == 3:
        Q = 4 * N
    elif type == 4:
        Q = 8 * N
    else:
        raise Exception("type must be either 1, 2, 3 or 4.")

    chain = Chain.square_dyadic((Q, Q))

    scale = [
        sqrt(2 * (N + 1)),
        sqrt(2 * N),
        sqrt(2 * N),
        sqrt(2 * N)
    ][type - 1]

    if type in [2, 3]:
        # Do nothing because DST II is equivalent to
        # DCT II with reversed output and each element $x_i$
        # of the input $x$ multiplied by $(-1)^i$.
        # DST III is equivalent to transposition of DST II.
        B = dct(
            N,
            2,
            optimize,
            real_valued,
            **kwargs,
        )
        v = xp.full(N, -1, dtype=dtype, device=device)
        v[0::2] *= -1
        D = diag(v)
    elif real_valued:

        # Bit-reversal permutation.
        P = bitrev(Q)

        B = ((fft(Q) * (sqrt(Q) / scale)) @ P.T).toarray(
            array_namespace=xp,
            dtype=dtype,
            device=device,
        )
        Bimag = -xp.imag(B)

        pattern2 = [None] * chain.n_patterns
        for i in range(chain.n_patterns):
            pattern = chain.ks_patterns[i]
            if i == 0:
                new_pattern = (
                    pattern[0], pattern[1], pattern[2] * 2, pattern[3])
            elif i == chain.n_patterns - 1:
                new_pattern = (
                    pattern[0], pattern[1] * 2, pattern[2], pattern[3])
            else:
                new_pattern = (
                    pattern[0], pattern[1] * 2, pattern[2] * 2, pattern[3])
            pattern2[i] = new_pattern
        chain2 = Chain(pattern2)

        _B = ksd(Bimag, chain2, ksm_backend=ksm_backend)
        _ksv = _B.ks_values
        if optimize:
            _ksv = _optimize(
                _ksv,
                strategy=kwargs.get("opt_strategy", 'benchmark'),
                params=kwargs.get("opt_params", {'backend': ksm_backend}),
            )
        B = KsmPermLazyLinOp(
            _ksv,
            backend=ksm_backend,
            params=ksm_params,
            bitrev_perm='right',
        )

        Bhat = _B.toarray(
            array_namespace=xp,
            dtype=dtype,
            device=device,
        )
        del _B
        rerr = xp.linalg.norm(Bhat - Bimag, 'fro') / xp.linalg.norm(Bimag)
        if rerr > 1e-6:
            print(rerr)
    else:
        B = dft(
            Q,
            optimize,
            backend=ksm_backend,
            params=ksm_params,
            dtype=dtype,
            device=device,
            opt_strategy=kwargs.get("opt_strategy", 'benchmark'),
            opt_params=kwargs.get("opt_params", {'backend': ksm_backend}),
        ) * (sqrt(Q) / scale)

    if type == 1:
        # L @ x is equivalent to
        # sp.fft.dst(x, 1, n, 0, norm, False, 1, True)
        # up to a scale factor depending on norm.
        S = slicer(Q, 1, N + 1)
        L = S @ B @ vstack(
            (
                eye(N + 2, N, k=-1),
                -anti_eye(N),
            )
        )
    elif type == 2:
        # L @ x is equivalent to
        # sp.fft.dst(x, 2, n, 0, norm, False, 1, True)
        # up to a scale factor depending on norm.
        L = anti_eye(N) @ B @ D
    elif type == 3:
        # L @ x is equivalent to
        # sp.fft.dst(x, 3, n, 0, norm, False, 1, True)
        # up to a scale factor depending on norm.
        L = D @ B.T @ anti_eye(N)
    elif type == 4:
        # L @ x is equivalent to
        # sp.fft.dst(x, 4, n, 0, norm, False, 1, True)
        # up to a scale factor depending on norm.
        # Append flip(x), -x and -flip(x) to the original input x.
        # Interleave with zeros such that the first element is zero.
        # Compute the DFT of length 8 * N and keep N odd elements.
        S = chunk(Q, size=1, hop=2, start=1, stop=2 * N + 1)
        M = mpad(1, 4 * N, 1, ('before'))
        L = 0.5 * (
            S @ B @ M @ vstack(
                (
                    vstack(
                        (
                            eye(N),
                            anti_eye(N),
                        )
                    ),
                    vstack(
                        (
                            -eye(N),
                            -anti_eye(N),
                        )
                    )
                )
            )
        )
    else:
        raise Exception("type must be either 1, 2, 3 or 4.")

    def _lx(op, x):
        if 'complex' in str(x.dtype):
            y = op @ _dtype_sanitized_x(x)
        else:
            y = op @ x
        return xp.real(y) if 'complex' in str(y.dtype) else y

    if type in [2, 3] or real_valued:
        S = LazyLinOp(
            shape=L.shape,
            matmat=lambda x: _lx(L, x),
            rmatmat=lambda x: _lx(L.T, x),
        )
    else:
        S = LazyLinOp(
            shape=L.shape,
            matmat=lambda x: -(L @ _dtype_sanitized_x(x)).imag,
            rmatmat=lambda x: -(L.T @ _dtype_sanitized_x(x)).imag,
        )

    S.ksm_data = B.ksm_data
    return S
