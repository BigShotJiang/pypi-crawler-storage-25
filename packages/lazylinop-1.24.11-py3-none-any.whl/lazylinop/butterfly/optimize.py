# -*- coding-utf8 -*-
import numpy as np
from lazylinop.butterfly import (
    Chain, fuse, KsmLazyLinOp, KsmPermLazyLinOp)
try:
    import cupy as cp
except ModuleNotFoundError:
    cp = None
try:
    import torch
except ModuleNotFoundError:
    torch = None
import time
from array_api_compat import (
    array_namespace, is_cupy_array, is_numpy_array, is_torch_array)
from typing import Union
try:
    import pandas as pd
except ModuleNotFoundError:
    from warnings import warn
    warn("Please install pandas to save results" +
         " of calls to optimize function.")
    pd = None
import hashlib
import os
# Number of threads.
if "OMP_NUM_THREADS" in os.environ.keys():
    n_threads = int(os.environ["OMP_NUM_THREADS"])
else:
    n_threads = os.cpu_count()
    os.environ["OMP_NUM_THREADS"] = str(n_threads)
    os.environ["OPENBLAS_NUM_THREADS"] = str(n_threads)
    os.environ["MKL_NUM_THREADS"] = str(n_threads)
# Import NumPy here because of previous OMP_NUM_THREADS assignement.
import numpy as np

if torch is not None:
    torch.set_num_threads(n_threads)


def _fx(f, x, **kwargs):
    return f(x)


def _lx(L, x, **kwargs):
    return L @ x


def _benchmark(f, op, x, n1, n2, **kwargs):
    """
    To benchmark f(op, x).
    """
    # Warmup
    for _ in range(3):
        y = f(op, x, **kwargs)
    # Benchmark
    xp = array_namespace(x)
    device = x.device
    duration = {
        "cpu": [0.0] * n1,
        "gpu": [0.0] * n1,
        "cpu+gpu": [0.0] * n1,
        "op": [0.0] * n1,
        "ksmm": [None] * n1,
        "perm": [None] * n1,
        "copy": [None] * n1,
    }
    if cp is not None and is_cupy_array(x):
        # CUDA event to measure kernel execution time.
        start = cp.cuda.Event()
        end = cp.cuda.Event()
        _synchronize = cp.cuda.Stream.null.synchronize()
    elif torch is not None and is_torch_array(x) and x.device.type == "cuda":
        # CUDA event to measure kernel execution time.
        start = torch.Event(device=x.device, enable_timing=True)
        end = torch.Event(device=x.device, enable_timing=True)
        _synchronize = torch.cuda.synchronize()
    elif torch is not None and is_torch_array(x) and x.device.type == "cpu":
        # CUDA event to measure kernel execution time.
        start = torch.cpu.Event()
        end = torch.cpu.Event()
        _synchronize = torch.cpu.synchronize()
    else:
        _synchronize = 0
    # Run benchmark.
    for i in range(n1):
        # Record before the n2 repeats.
        if is_cupy_array(x):
            start.record()
        elif is_torch_array(x) and x.device.type == "cuda":
            start.record()
        else:
            t0 = time.time()
        for _ in range(n2):
            f(op, x, **kwargs)
            _synchronize
            # Check if op has attributes from _multiple_ksm fn.
            if hasattr(op, "ksm_data") and hasattr(op.ksm_data, "duration"):
                duration["op"][i] += (
                    sum(op.ksm_data.duration["ksmm"]) +
                    op.ksm_data.duration["perm"] +
                    op.ksm_data.duration["copy"]
                ) / n2
                if duration["ksmm"][i] is None:
                    duration["ksmm"][i] = op.ksm_data.duration["ksmm"]
                else:
                    for j, v in enumerate(op.ksm_data.duration["ksmm"]):
                        duration["ksmm"][i][j] += v / n2
                if duration["perm"][i] is None:
                    duration["perm"][i] = op.ksm_data.duration["perm"] / n2
                else:
                    duration["perm"][i] += op.ksm_data.duration["perm"] / n2
                if duration["copy"][i] is None:
                    duration["copy"][i] = op.ksm_data.duration["copy"] / n2
                else:
                    duration["copy"][i] += op.ksm_data.duration["copy"] / n2
            # Record after the end of the n2 repeats.
            if is_cupy_array(x):
                end.record()
                end.synchronize()
                duration["gpu"][i] = 1e-3 * cp.cuda.get_elapsed_time(
                    start, end) / n2
            elif is_torch_array(x) and x.device.type == "cuda":
                end.record()
                end.synchronize()
                duration["gpu"][i] = 1e-3 * start.elapsed_time(end) / n2
            else:
                duration["cpu"][i] = (time.time() - t0) / n2
            duration["cpu+gpu"][i] = duration["cpu"][i] + duration["gpu"][i]

    return duration, y


def optimize(
        input,
        strategy: str = "benchmark",
        params: Union[dict, int] = {"backend": "xp"},
        verbose: bool = True,
):
    r"""
    Adaptively fuse:

    - a list ``input`` of chainable 4D arrays
      (see :py:func:`lazylinop.butterfly.Chain` for more details)
    - an instance of :py:class:`lazylinop.butterfly.KsmLazyLinOp`
    - an instance of :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
    - an instance of :py:class:`lazylinop.butterfly.Chain`
      according to ``strategy`` argument and return:

    - a new list ``res`` of ``ks_values``.
      The resulting list ``res`` of 4D arrays
      is of length ``n_factors <= len(input)`` and satisfies
      ``ksm(input).toarray() == ksm(res).toarray()``.
    - a new chain.

    This function is a utility to optimize the implementation of butterfly
    matrices: while being frugal in memory, butterfly matrices implemented
    via many (chainable) Kronecker sparse factors are sometimes less
    computationally efficient than their (exact) fused
    implementation using fewer factors.

    The input can be either a :py:class:`lazylinop.butterfly.Chain`
    describing the structure of the Kronecker sparse factors,
    or an explicit list of (chainable) 4D arrays of ``ks_values``
    fully specifying these factors.
    In the first case the output is an optimized chain,
    in the second one it is an optimized list of ``ks_values``
    resulting from the needed hierarchical fusions,
    see :py:func:`lazylinop.butterfly.fuse`.

    :octicon:`alert-fill;1em;sd-text-danger`
    Optimization using ``strategy='benchmark'`` usually
    results in the most optimized implementation, but the optimization
    process may be time consuming,
    depending notably on the size of the factors,
    on the backend (see :py:func:`lazylinop.butterfly.ksm` for more details),
    on the dtype and on the device of the ``ks_values``.

    Args:
        input: :py:class:`lazylinop.butterfly.Chain` or ``list`` of 4D arrays
            An instance of :py:class:`lazylinop.butterfly.Chain`
            or a list of chainable 4D arrays or.
        strategy: ``str``
            To be chosen among the following:

            - ``'benchmark'`` (default):
              recursively fuses two consecutive elements
              if the resulting fused factor gives better matrix-vector
              multiplication performance than the succession of the two,
              non-fuses ones.
              Do not fuse if the resulting factor is dense.
            - ``'memory'`` iteratively fuse the two consecutive
              Kronecker-sparse factors that minimize the memory of the
              resulting fused one, until a target number of factors has
              been reached.
            - ``'sparsity'``: iteratively fuse the two consecutive
              Kronecker-sparse factors that minimize the ratio $\frac{1}{ad}$
              of the resulting fused one, until a target number of factors
              has been reached.
            - ``'speed'``: iteratively fuse the two consecutive
              Kronecker-sparse factors that minimize the ratio $\frac{bc}{b+c}$
              of the resulting fused one, until a target number of factors
              has been reached.
            - ``l2r``: iteratively fuse factors from left to right until a
              target number of factors has been reached.
            - ``r2l``: iteratively fuse factors from right to left until a
              target number of factors has been reached.
            - ``balanced``: iteratively and alternatively fuse
              the two leftmost factors / the two rightmost ones,
              until a target number of factors has been reached.

            Examples:

            - ``strategy='balanced'``:

              - Case ``n = 6`` and ``n_factors = 2``:

                - step 0: 0 1 2 3 4 5
                - step 1: 01 2 3 45
                - step 2: 012 345
              - Case ``n = 7`` and ``n_factors = 2``:

                - step 0: 0 1 2 3 4 5 6
                - step 1: 01 2 3 4 56
                - step 2: 012 3 456
                - step 3: 0123 456
              - Case ``n = 7`` and ``n_factors = 3``:

                - step 0: 0 1 2 3 4 5 6
                - step 1: 01 2 3 4 56
                - step 2: 012 3 456
            - ``strategy='l2r'``:

              - Case ``n = 6`` and ``n_factors = 3``:

                - step 0: 0 1 2 3 4 5
                - step 1: 01 2 3 4 5
                - step 2: 01 23 4 5
                - step 3: 01 23 45
              - Case ``n = 7`` and ``n_factors = 2``:

                - step 0: 0 1 2 3 4 5 6
                - step 1: 01 2 3 4 5 6
                - step 2: 01 23 4 5 6
                - step 3: 01 23 45 6
                - step 4: 0123 45 6
                - step 5: 0123 456
        params: ``dict`` or ``int``
            - When
              ``strategy='memory', 'sparsity', 'speed'`` or
              ``'balanced', 'l2r', 'r2l'``,
              ``params = n_factors`` where ``n_factors``
              is the target number of factors.
            - When ``strategy='benchmark'``
              the value of ``params`` depends on the type of ``input``:

              - If ``input`` is a chain, the four arguments
                ``params = {"backend": backend,
                "array_namespace": array_namespace,
                "dtype": dtype,
                "device": device}`` are mandatory.
              - If ``input`` is a list of ``ks_values``,
                ``params = {"backend": backend}``
                argument is mandatory while ``array_namespace, dtype, device``
                are determined using the ``ks_values``.
              Possible values of ``array_namespace`` are

              - ``cp`` using ``import cupy as cp``
              - ``np`` using ``import numpy as np``
              - ``torch`` using ``import torch``
              Possible values of ``dtype`` and ``device`` depend on the
              array namespace.
              Please refer to the documentation of CuPy, NumPy and PyTorch.
        verbose: ``bool``, optional
            Print fuse steps.
            If ``strategy='benchmark'`` writes the duration time
            of all possible combinations of successive fuses
            of the ``input`` in the output file ``optimize.csv``.
            Default value is ``True``.

    Returns:
        - If ``input`` is a list of 4d arrays return
          a list ``res`` of chainable 4D arrays that satisfies
          ``ksm(input).toarray() == ksm(res).toarray()``.
        - If ``input`` is :py:func:`lazylinop.butterfly.Chain` return
          a new chain ``res`` that satisfies ``res.n_patterns = n_factors``.

    .. seealso::
        - :py:func:`lazylinop.butterfly.fuse`,
        - :py:func:`lazylinop.butterfly.ksm`,
        - :py:class:`lazylinop.butterfly.Chain`.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import ksm, optimize
        >>> a1, b1, c1, d1 = 2, 2, 2, 4
        >>> a2, b2, c2, d2 = 4, 2, 2, 2
        >>> v1 = np.random.randn(a1, b1, c1, d1)
        >>> v2 = np.random.randn(a2, b2, c2, d2)
        >>> v = optimize([v1, v2], strategy='memory', params=1)
               ['0', '1']
        step=0 ['01']
        >>> v[0].shape
        (2, 4, 4, 2)
        >>> L = ksm(v)
        >>> L1 = ksm(v1)
        >>> L2 = ksm(v2)
        >>> x = np.random.randn(L.shape[1])
        >>> np.allclose(L @ x, L1 @ L2 @ x)
        True
        >>> # Left-to-right strategy.
        >>> n = 5
        >>> ksv = [np.random.randn(2, 2, 2, 2)] * n
        >>> v = optimize(ksv, strategy='l2r', params=2)
               ['0', '1', '2', '3', '4']
        step=0 ['01', '2', '3', '4']
        step=1 ['01', '23', '4']
        step=2 ['0123', '4']
        >>> # Balanced strategy.
        >>> n = 3
        >>> ksv = [np.random.randn(2, 2, 2, 2)] * n
        >>> v = optimize(ksv, strategy='balanced', params=2)
               ['0', '1', '2']
        step=0 ['01', '2']
        >>> n = 5
        >>> ksv = [np.random.randn(2, 2, 2, 2)] * n
        >>> v = optimize(ksv, strategy='balanced', params=2)
               ['0', '1', '2', '3', '4']
        step=0 ['01', '2', '3', '4']
        step=1 ['01', '2', '34']
        step=2 ['012', '34']
    """

    _is_list, _is_chain, _is_ksm = False, False, False
    if isinstance(input, list):
        _is_list = True
        n = len(input)
        for i in range(n):
            if len(input[i].shape) != 4:
                raise Exception(
                    "Each element of ks_values must be a 4D array.")
        chain = Chain([input[i].shape for i in range(n)])
        if not chain.chainable or not chain.valid:
            raise Exception("Each element of ks must be" +
                            " chainable and valid.")
    elif isinstance(input, KsmLazyLinOp):
        _is_ksm = True
        n = len(input.ks_values)
    elif isinstance(input, Chain):
        _is_chain = True
        n = input.n_patterns
    else:
        raise Exception("input must be a list or a Chain.")

    n_factors = None
    if strategy != "benchmark":
        if isinstance(params, int):
            n_factors = params
        else:
            raise Exception(
                f"{strategy} expects params to be the number of factors.")

    if (n_factors is not None and n <= n_factors) or n == 1:
        # Nothing to fuse.
        if _is_list:
            xp = array_namespace(input[0])
            return [xp.asarray(k, copy=True) for k in input]
        elif _is_ksm:
            # Return a copy.
            if hasattr(input, "bitrev_perm"):
                xp = array_namespace(input.ks_values[0])
                return KsmPermLazyLinOp(
                    [xp.asarray(k, copy=True) for k in input.ks_values],
                    backend=input.backend,
                    params=input.params,
                    bitrev_perm=input.bitrev_perm,
                )
            else:
                xp = array_namespace(input.ks_values[0])
                return KsmLazyLinOp(
                    [xp.asarray(k, copy=True) for k in input.ks_values],
                    backend=input.backend,
                    params=input.params,
                )
        elif _is_chain:
            return Chain([k for k in input.ks_patterns])
    else:
        # Copy the input list.
        if _is_list:
            xp = array_namespace(input[0])
            _x = [xp.asarray(k, copy=True) for k in input]
        elif _is_ksm:
            xp = array_namespace(input.ks_values[0])
            _x = [xp.asarray(k, copy=True) for k in input.ks_values]
        elif _is_chain:
            _x = Chain([k for k in input.ks_patterns])
        else:
            _x = None
        ksv_params = {}
        m, target = n, n
        if strategy == 'balanced':
            # Fuse from left to right and from right to left.
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            lpos, rpos, left = 0, m - 1, True
            while True:
                if left and target > n_factors:
                    # From left to right.
                    idx[lpos] = idx[lpos] + idx[lpos + 1]
                    idx.pop(lpos + 1)
                    if _is_chain:
                        _x = _x.fuse(lpos)
                    else:
                        _x[lpos] = fuse([_x[lpos], _x[lpos + 1]])
                        _x.pop(lpos + 1)
                    target -= 1
                    lpos += 1
                    rpos -= 1
                if not left and target > n_factors and rpos > lpos:
                    # From right to left.
                    idx[rpos - 1] = idx[rpos - 1] + idx[rpos]
                    idx.pop(rpos)
                    if _is_chain:
                        _x = _x.fuse(rpos - 1)
                    else:
                        _x[rpos - 1] = fuse([_x[rpos - 1], _x[rpos]])
                        _x.pop(rpos)
                    target -= 1
                    rpos -= 2
                left = not left
                if lpos >= rpos:
                    lpos, rpos = 0, target - 1
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
        elif strategy == 'l2r':
            # Fuse from left to right.
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            lpos = 0
            while True:
                if target > n_factors:
                    # From left to right.
                    idx[lpos] = idx[lpos] + idx[lpos + 1]
                    idx.pop(lpos + 1)
                    if _is_chain:
                        _x = _x.fuse(lpos)
                    else:
                        _x[lpos] = fuse([_x[lpos], _x[lpos + 1]])
                        _x.pop(lpos + 1)
                    target -= 1
                    lpos += 1
                if lpos + 1 >= len(idx):
                    lpos = 0
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
            if _is_chain:
                _x = Chain([k for k in _x.ks_patterns[:n_factors]])
            else:
                _x = _x[:n_factors]
        elif strategy == 'r2l':
            # Fuse from right to left.
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            rpos = n - 1
            while True:
                if target > n_factors:
                    # From right to left.
                    idx[rpos - 1] = idx[rpos - 1] + idx[rpos]
                    idx.pop(rpos)
                    if _is_chain:
                        _x = _x.fuse(rpos - 1)
                    else:
                        _x[rpos - 1] = fuse([_x[rpos - 1], _x[rpos]])
                        _x.pop(rpos)
                    target -= 1
                    rpos -= 2
                if rpos < 1:
                    rpos = len(idx) - 1
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
            if _is_chain:
                _x = Chain([k for k in _x.ks_patterns[:n_factors]])
            else:
                _x = _x[:n_factors]
        elif strategy in ('memory', 'speed', 'sparsity'):
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            n_fuses = 0
            while True:
                # Build memory list.
                heuristic = np.full(n - n_fuses - 1, 0.0)
                memory = np.full(n - n_fuses - 1, 0)
                sparsity = np.full(n - n_fuses - 1, 0.0)
                for i in range(n - n_fuses - 1):
                    if _is_chain:
                        a1, b1, c1, d1 = _x.ks_patterns[i]
                        a2, b2, c2, d2 = _x.ks_patterns[i + 1]
                    else:
                        a1, b1, c1, d1 = _x[i].shape
                        a2, b2, c2, d2 = _x[i + 1].shape
                    b = (b1 * d1) // d2
                    c = (a2 * c2) // a1
                    memory[i] = a1 * b * c * d2
                    # Because of argmin, compute the inverse.
                    heuristic[i] = 1.0 / ((b + c) / (b * c))
                    sparsity[i] = 1.0 / (a1 * d2)
                # Find argmin.
                if strategy == 'memory':
                    # argmin = np.argmin(memory)
                    tmp = np.where(memory == memory[np.argmin(memory)])[0]
                    if n_fuses % 2 == 0:
                        argmin = tmp[0]
                    else:
                        argmin = tmp[-1]
                elif strategy == 'speed':
                    # argmin = np.argmin(heuristic)
                    tmp = np.where(
                        heuristic == heuristic[np.argmin(heuristic)])[0]
                    if n_fuses % 2 == 0:
                        argmin = tmp[0]
                    else:
                        argmin = tmp[-1]
                elif strategy == 'sparsity':
                    # argmin = np.argmin(sparsity)
                    tmp = np.where(
                        sparsity == sparsity[np.argmin(sparsity)])[0]
                    if n_fuses % 2 == 0:
                        argmin = tmp[0]
                    else:
                        argmin = tmp[-1]
                # Fuse argmin and argmin + 1.
                if _is_chain:
                    _x = _x.fuse(argmin)
                else:
                    _x[argmin] = fuse([_x[argmin], _x[argmin + 1]])
                idx[argmin] = idx[argmin] + idx[argmin + 1]
                n_fuses += 1
                # Delete argmin + 1.
                if not _is_chain:
                    _x.pop(argmin + 1)
                idx.pop(argmin + 1)
                target -= 1
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
        elif strategy == "benchmark":
            if _is_chain:
                if 'array_namespace' not in params.keys():
                    raise Exception(
                        "strategy expects params to be a dict" +
                        " with a 'array_namespace' key.")
                if 'dtype' not in params.keys():
                    raise Exception(
                        "strategy expects params to be a dict" +
                        " with a 'dtype' key.")
                if 'device' not in params.keys():
                    raise Exception(
                        "strategy expects params to be a dict" +
                        " with a 'device' key.")
                xp = params["array_namespace"]
                dtype = params["dtype"]
                device = params["device"]
            else:
                xp = array_namespace(_x[0])
                if 'dtype' in params.keys():
                    dtype = params['dtype']
                else:
                    # Default uses ks_values dtype.
                    dtype = _x[0].dtype
                if 'device' in params.keys():
                    # Default uses ks_values device.
                    device = params['device']
                else:
                    device = _x[0].device
            if "backend" not in params.keys():
                raise Exception(
                    "strategy expects params to be a dict" +
                    " with a 'backend' key.")
            _backend = params["backend"]
            if "batch_size" in params.keys() and isinstance(
                    params["batch_size"], int):
                batch_size = max(1, params["batch_size"])
            else:
                batch_size = 16
            n1 = max(1, params.get('n1', 10))
            n2 = max(1, params.get('n2', 3))
            n_tests = max(1, params.get('n_tests', 1))

            def _all_fuses(x):
                """
                Return all possible combination of fuses.

                Args:
                    x: ``list``
                        List of ``int``.

                Returns:
                    List of lists.
                """
                y = [[str(i) for i in x]]
                i0, i1 = 0, 1
                data = {}
                while 1:
                    new = 0
                    for i in range(i0, i1):
                        x = y[i]
                        n = len(x)
                        for j in range(n - 1):
                            current = [f"{x[j]}*{x[j + 1]}"]
                            if j > 0:
                                current = [str(x[k]) for k in range(j)] + current
                            if j < (n - 2):
                                current = current + [str(x[k]) for k in range(j + 2, n)]
                            if str(current) not in data.keys():
                                y.append(current)
                                data[str(current)] = True
                                new += 1
                    i0, i1 = i1, len(y)
                    if new == 0:
                        del data
                        break
                return y

            _y = [i for i in range(_x.n_patterns if _is_chain else len(_x))]
            y = _all_fuses(_y)
            if verbose:
                print(f"{len(y)} chains to benchmark.")
            best, best_x = 1e9, None
            times_per_ksv = {}
            # Save fuses for further usage.
            ksvs = {}
            for k, i in enumerate(y):
                total = 0.0
                for j in i:
                    s = j.split("*")
                    if _is_chain:
                        chain = Chain([_x.ks_patterns[int(t)] for t in s])
                        for _ in range(chain.n_patterns - 1):
                            chain = chain.fuse(0)
                        # If chain, generate random ks_values.
                        if j in ksvs.keys():
                            ksv = ksvs[j]
                        else:
                            ksv = xp.asarray(
                                np.random.randn(*chain.ks_patterns[0]),
                                dtype=dtype,
                                device=device,
                            )
                            ksvs[j] = ksv
                    else:
                        if j in ksvs.keys():
                            ksv = ksvs[j]
                        else:
                            # Does partial fuse exists?
                            tmp, count = s[0], 1
                            for r in s[1:]:
                                if f"tmp*{r}" not in ksvs.keys():
                                    break
                                else:
                                    tmp += f"*{r}"
                                count += 1
                            if tmp in ksvs.keys():
                                ksv = fuse([ksvs[tmp]] + [_x[int(t)] for t in s[count:]])
                            else:
                                ksv = fuse([_x[int(t)] for t in s])
                            ksvs[j] = ksv
                        # Do we need to fuse ks_values here?
                        # Build a Chain instance, fuse ks_patterns
                        # and draw ks_values at random.
                        chain = Chain([_x[int(t)].shape for t in s])
                        for _ in range(chain.n_patterns - 1):
                            chain = chain.fuse(0)
                    # It makes no sense to use *sparse backend
                    # when a=d=1.
                    if (
                            chain.n_patterns == 1 and
                            chain.ks_patterns[0][0] == 1 and
                            chain.ks_patterns[0][3] == 1 and
                            _backend != 'xp'
                    ):
                        total = 1e9
                        break
                    str_shape = str(ksv.shape)
                    if str_shape in times_per_ksv.keys():
                        # Already benchmark the single ks-values.
                        total += times_per_ksv[str_shape]
                        continue
                    # Find best hyper-parameters.
                    if n_tests > 1:
                        opt_params = [
                            _optimize_hp(
                                KsmLazyLinOp(ksv, backend=_backend),
                                batch_size,
                                n1=n1,
                                n2=n2,
                                n_tests=n_tests,
                            )
                        ]
                        ksv_params[str_shape] = opt_params[0]
                        str_params = str(opt_params[0])
                    else:
                        opt_params = None
                        str_params = 'no'
                    # Benchmark current ks-values.
                    L = KsmLazyLinOp(
                        ksv,
                        backend=_backend,
                        params=opt_params,
                    )
                    u = xp.asarray(
                        np.random.randn(L.shape[1], batch_size),
                        dtype=dtype,
                        device=device,
                    )
                    # Determine n1 and n2 to get a good statistics.
                    _n1, _n2, ok = n1, n2, False
                    while not ok:
                        ok = True
                        d, _ = _benchmark(_lx, L, u, _n1, _n2)
                        _time = np.asarray(d["cpu"]) + np.asarray(d["gpu"])
                        median = np.median(_time)
                        iqr = np.subtract(*np.percentile(_time, [75, 25]))
                        xxx = 0.001
                        if (_n2 * np.sum(_time)) < xxx:
                            # At least xxx ms per run.
                            _n2 = int(1.1 * xxx / np.sum(_time))
                            ok = False
                        if iqr > (0.1 * median) and _n1 < (4 * n1):
                            # Increase statistics.
                            _n1 *= 2
                            ok = False
                        times_per_ksv[str_shape] = median
                    # Save to csv file.
                    if pd is not None:
                        try:
                            data = pd.read_csv("optimize.csv", sep=",")
                        except FileNotFoundError:
                            data = pd.DataFrame(
                                {
                                    "array namespace": [],
                                    "device": [],
                                    "dtype": [],
                                    "backend": [],
                                    "cpu": [],
                                    "gpu": [],
                                    "shape": [],
                                    "batch size": [],
                                    "params": [],
                                    "OMP_NUM_THREADS": [],
                                    "median": [],
                                    "iqr": [],
                                    "hash": [],
                                },
                                index=[],
                            )
                        # Use hashlib to compute indexes of df.
                        current_hash, cpu, gpu, name = _hash(
                            ksv,
                            _backend,
                            batch_size,
                            str_params,
                        )
                        # Find hash and update median and iqr.
                        if data.empty or data[data["hash"] == current_hash].empty:
                            data = pd.concat(
                                [
                                    data,
                                    pd.DataFrame(
                                        {
                                            "array namespace": str(xp.__package__),
                                            "device": str(device),
                                            "dtype": str(dtype),
                                            "backend": name,
                                            "cpu": cpu,
                                            "gpu": gpu,
                                            "shape": str(ksv.shape),
                                            "batch size": int(batch_size),
                                            "params": str_params,
                                            "OMP_NUM_THREADS": int(n_threads),
                                            "median": float(median),
                                            "iqr": float(iqr),
                                            "hash": current_hash,
                                        },
                                        index=[current_hash],
                                    ),
                                ],
                                axis=0,
                            )
                        else:
                            _df = data.loc[data["hash"] == current_hash]
                            data.loc[_df.index, ["median", "iqr"]] = [
                                median,
                                iqr,
                            ]
                        data.to_csv("optimize.csv", sep=",", index=False)
                    total += times_per_ksv[str_shape]
                    del L
                # Keep best according to median.
                if k == 0 or total < best:
                    best = total
                    best_i = i
                    if verbose:
                        print(
                            f"New best {i}\n"
                            # + f"median={median:.3e} iqr={iqr:.3e}\n"
                            + f"{_n1} repeats and {_n2} runs."
                        )
            del ksvs
            # Compute the fuses.
            idx = 0
            best_x = [None] * len(best_i)
            if _is_chain:
                for j in best_i:
                    s = j.split("*")
                    best_x[idx] = Chain(
                        [_x.ks_patterns[int(t)] for t in s])
                    for _ in range(best_x[idx].n_patterns - 1):
                        best_x[idx] = best_x[idx].fuse(0)
                    idx += 1
                # Only one pattern per chain.
                best_x = Chain([c.ks_patterns[0] for c in best_x])
            else:
                for j in best_i:
                    s = j.split("*")
                    best_x[idx] = fuse([_x[int(t)] for t in s])
                    idx += 1
            _x = best_x
        else:
            raise Exception(
                "strategy must be either 'balanced'," +
                " 'l2r', 'memory', 'sparsity'" +
                " 'speed' or 'benchmark'.")

        if _is_ksm:
            ksv = [xp.asarray(k) for k in _x]
            params = []
            for k in ksv:
                if str(k.shape) in ksv_params.keys():
                    params.append(ksv_params[str(k.shape)])
                else:
                    params.append((None, None))
            if hasattr(input, "bitrev_perm"):
                return KsmPermLazyLinOp(
                    ksv,
                    backend=input.backend,
                    params=params,
                    bitrev_perm=input.bitrev_perm,
                )
            else:
                return KsmLazyLinOp(
                    ksv,
                    backend=input.backend,
                    params=params,
                )
        else:
            return _x


def _optimize_hp(L, batch_size: int, **kwargs):
    """
    Optimize hyper-parameters of a single *ks-values*.

    Args:
        L: :py:class:`lazylinop.butterfly.KsmLazyLinOp`
    """

    if len(L.ks_values) > 1:
        raise Exception("Length of ks-values must be one.")
    ksv = L.ks_values[0]

    try:
        import pyopencl as cl
    except (ImportError, ModuleNotFoundError):
        cl = None

    try:
        import pycuda.driver as cuda
        import pycuda._driver as _cuda
        # No need of an automatic make_default_context().
        # Memory leak ?
        # import pycuda.autoinit
        from pycuda.compiler import SourceModule
    except (ImportError, ModuleNotFoundError):
        cuda = None
        _cuda = None
        SourceModule = None
    if cuda is not None and _cuda is not None:
        try:
            cuda.init()
        except _cuda.RuntimeError:
            cuda, _cuda = None, None

    from lazylinop.butterfly.ksm import (
        _find_all_hyper_parameters,
        _get_info_dim,
    )

    xp = array_namespace(ksv)
    dtype = ksv.dtype
    device = ksv.device
    backend = L.backend
    if backend in ['cupyx', 'scipy', 'xp']:
        # Those backends do not use params.
        return None

    # Get device informations.
    # print(device, backend)
    if (
            (
                isinstance(backend, tuple) and
                cl is not None and
                isinstance(backend[0], cl.Platform) and
                isinstance(backend[1], cl.Device)
            )
    ) or (
            cuda is not None and isinstance(backend, cuda.Device)
    ):
        tmp = backend[1]
    else:
        tmp = device
    (
        smem,
        max_work_group_size,
        max_block_dim,
        max_grid_dim,
    ) = _get_info_dim(tmp)

    best_hp, best_rhp = None, None
    n1 = kwargs.get('n1', 10)
    n2 = kwargs.get('n2', 3)
    n_tests = kwargs.get('n_tests', 5)

    # Find all hyper-parameters.
    hps, rhps = [], []
    a, b, c, d = ksv.shape
    for w in [True, False]:
        try:
            hps += _find_all_hyper_parameters(
                a, b, c, d, batch_size=batch_size,
                smem=smem, nbytes=(
                    ksv.dtype.itemsize,
                    ksv.dtype.itemsize,
                ),
                max_block_dim=max_block_dim,
                max_grid_dim=max_grid_dim,
                max_work_group_size=max_work_group_size,
                warp_tiling=w,
            )
        except Exception:
            pass
        try:
            rhps += _find_all_hyper_parameters(
                a, c, b, d, batch_size=batch_size,
                smem=smem, nbytes=(
                    ksv.dtype.itemsize,
                    ksv.dtype.itemsize,
                ),
                max_block_dim=max_block_dim,
                max_grid_dim=max_grid_dim,
                max_work_group_size=max_work_group_size,
                warp_tiling=w,
            )
        except Exception:
            pass
    n_hps = len(hps)

    for w in ['hp', 'rhp']:
        # Use x to benchmark L @ x.
        x = xp.asarray(
            np.random.randn(a * (c if w == 'hp' else b) * d, batch_size),
            dtype=dtype,
            device=device,
        )
        # Biggest hyper-parameters first.
        best_median = xp.inf
        for i in range(min(n_tests, n_hps)):
            hp = (hps[i], rhps[i])
            # Do not compute if entry exists in optimize.csv file.
            _median = None
            if pd is not None:
                try:
                    data = pd.read_csv("optimize.csv", sep=",")
                except FileNotFoundError:
                    data = None
                if data is not None and not data.empty:
                    # Use hashlib to compute indexes of df.
                    current_hash, _, _, _ = _hash(
                        ksv,
                        backend,
                        batch_size,
                        hp,
                    )
                    # Find hash and update median and iqr.
                    df = data[data["hash"] == current_hash]
                    if not df["median"].empty:
                        assert len(df["median"].values) == 1
                        _median = float(df["median"].values[0])
            if _median is None:
                L = KsmLazyLinOp(
                    ksv,
                    backend=backend,
                    params=[hp],
                )
                tmp, y = _benchmark(_lx, L if w == 'hp' else L.H, x, n1, n2)
                _median = np.median(np.asarray(tmp["cpu+gpu"]))
                del L
            if _median < best_median:
                best_median = _median
                if w == 'hp':
                    best_hp = hp[0]
                else:
                    best_rhp = hp[1]

    return (best_hp, best_rhp)


def _hash(ksv, backend, batch_size, hp):
    """
    Build hash.
    """
    dtype = ksv.dtype
    device = ksv.device
    hl = hashlib.sha256()
    if isinstance(backend, tuple):
        if hasattr(backend[0], 'name') and hasattr(backend[1], 'name'):
            name = f"{backend[0].name} {backend[1].name}"
        else:
            name = str(backend)
    else:
        name = str(backend)
    cpu = 'unknown'
    if torch is not None and is_torch_array(ksv):
        if torch.cuda.is_available():
            gpu = str(torch.cuda.get_device_name(device))
        else:
            gpu = 'unknown'
    elif cp is not None and is_cupy_array(ksv):
        gpu = cp.cuda.runtime.getDeviceProperties(device)[
            'name'
        ].decode()
    else:
        gpu = 'unknown'
    tmp = f"{array_namespace(ksv).__package__},{str(device)},{str(dtype)},{name},{cpu},{gpu},{str(ksv.shape)},{batch_size},{str(hp)},{n_threads}"
    hl.update(tmp.encode())
    current_hash = str(hl.hexdigest())
    return current_hash, cpu, gpu, name
