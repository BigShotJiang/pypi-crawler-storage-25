from lazylinop import LazyLinOp
from lazylinop.butterfly import ksd
import array_api_compat
import gc


def _toarray(L, dtype: str = None,
             array_namespace=None, device: str = None):
    """
    Do not build entire eye matrix: use batch to save memory.
    """
    if array_namespace is None:
        import array_api_compat.numpy as xp
    else:
        if hasattr(
                array_api_compat, array_namespace.__name__):
            xp = getattr(
                array_api_compat, array_namespace.__name__)
        else:
            xp = array_namespace
    M, N = L.shape
    if dtype is None:
        if "torch" in str(xp):
            for t in [
                    xp.float32,
                    xp.float64,
                    xp.complex64,
                    xp.complex128,
                    xp.float16,
                    xp.bfloat16,
                    xp.int32,
                    xp.int64,
                    xp.int16,
                    xp.int8,
                    xp.uint8,
                    xp.bool,
            ]:
                try:
                    L @ xp.ones((L.shape[1], 1), dtype=t, device=device)
                    eye_dtype = t
                    break
                except RuntimeError:
                    pass
        else:
            eye_dtype = "int8"
    else:
        eye_dtype = dtype
    if N <= 1024:
        return L @ xp.eye(L.shape[1], dtype=eye_dtype, device=device)
    else:
        _batch = 1024
        if _batch > N or N % _batch != 0:
            # Compute new batch value.
            batch = 1
            for i in range(min(_batch, N), 1, -1):
                if N % i == 0:
                    batch = i
                    break
        else:
            batch = _batch
        # Init batch of eye matrix.
        x = xp.zeros((N, batch), dtype=eye_dtype, device=device)
        # Compute L @ eye.
        for i in range(N // batch):
            # Fill the batch with 1.
            j = xp.arange(i * batch, (i + 1) * batch, 1)
            x[j, j - i * batch] = 1
            if i == 0:
                # Do not know the dtype of the output yet.
                _y = L @ x
                y = xp.empty((_y.shape[0], N),
                             dtype=_y.dtype, device=device)
                y[:, :batch] = _y
                del _y
            else:
                y[:, (i * batch):((i + 1) * batch)] = L @ x
            # Fill the batch with 0.
            x[j, j - i * batch] = 0
        return y


def suksd(A, chain, rtol: float = 1e-6,
          max_iter: int = 100, verbose: bool = True):
    """
    To approximate a 2d array ``A`` by
    a sum of Kronecker-Sparse decomposition.

    Args:
        A: 2d array
            Matrix or :py:class:`.LazyLinOp` to factorize.
            :octicon:`info;1em;sd-text-info` when ``A`` is a
            small :py:class:`.LazyLinOp` it is often faster
            to perform ``suksd(A.toarray(), ...)`` than ``suksd(A, ...)``
            if the dense array ``A.toarray()`` fits in memory.
        chain: ``Chain``
            *Chainable* instance of the ``Chain`` class.
            See :class:`lazylinop.butterfly.Chain`
            documentation for more details.
        rtol: ``float``, optional
            Stop if the residual Frobenius norm of ``A - approx``
            divided by the Frobenius norm of ``A`` is smaller than ``rtol``.
        max_iter: ``int``, optional
            Stop if the number of iterations
            is greater than ``max_iter``.
        verbose: ``bool``, optional
            Print number of iterations and relative error.

    Returns:
        A tuple ``(L, residual, rerr)`` where
        ``L`` is a :py:class:`.LazyLinOp` resulting from the
        approximation of ``A``, ``residual`` is an array
        given by ``A - L.toarray(...)``
        and ``rerr`` is the list of relative errors.
        The array namespace of ``residual`` is equal to:

        - the array namespace of ``A`` if ``A`` is an array.
        - NumPy if ``L`` is a :py:class:`.LazyLinOp`.
        The length of ``rerr`` is the number of iterations of the algorithm.

    Examples:
        >>> from lazylinop.butterfly.suksd import suksd
        >>> from lazylinop.butterfly import Chain
        >>> import numpy as np
        >>> N = 16
        >>> A = np.random.randn(N, N)
        >>> chain = Chain.monarch((N, N))
        >>> L, res, rerr = suksd(A, chain, 1e-6, 100, False)
        >>> bool(rerr[-1] < 1e-6 or len(rerr) == 100)
        True

    .. seealso::
        - :py:func:`lazylinop.butterfly.Chain`,
        - :py:func:`lazylinop.butterfly.ksd`.
    """
    xp = array_api_compat.array_namespace(A)
    backend = 'xp'
    # svd_backend = 'scipy_svds_lobpcg'
    if array_api_compat.is_torch_array(A):
        device = A.device
        if device.type == 'cpu':
            svd_backend = 'pytorch_svd_cpu'
        elif device.type == 'cuda':
            svd_backend = f"pytorch_svd_{device.index}"
    else:
        svd_backend = 'scipy_svd'
    iterations, rerr = 0, []
    if isinstance(A, LazyLinOp):
        normA = xp.linalg.norm(A.toarray(array_namespace=xp), ord='fro')
    else:
        normA = xp.linalg.norm(A, ord='fro')
    for i in range(max_iter):
        # Butterfly decomposition.
        _ksd = ksd(A if i == 0 else res,
                   chain, ksm_backend=backend, svd_backend=svd_backend)
        if i == 0:
            # Init LazyLinOp (approximation of A)
            _L = _ksd
            # Residual
            res = A - _toarray(_ksd, array_namespace=xp,
                               dtype=A.dtype, device=A.device)
        else:
            # Update LazyLinOp (approximation of A)
            _L = _L + _ksd
            # Residual
            xp.subtract(res, _toarray(_ksd, array_namespace=xp,
                                      dtype=A.dtype, device=A.device), out=res)
        rerr.append(float(xp.linalg.norm(res, ord='fro') / normA))
        iterations += 1
        if verbose:
            print(f"shape={A.shape} iter={i} rerr={rerr[i]}/{rtol}")
        gc.collect()
        if rerr[i] < rtol:
            break
    return _L, res, rerr
