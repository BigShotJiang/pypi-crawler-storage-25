// C++ interface.
#define CHECK_CUDA(x) TORCH_CHECK(x.device().is_cuda(), #x " must be a CUDA tensor")
#define CHECK_CONTIGUOUS(x) TORCH_CHECK(x.is_contiguous(), #x " must be contiguous")
#define CHECK_INPUT(x) \
  CHECK_CUDA(x);       \
  CHECK_CONTIGUOUS(x)

torch::Tensor forward(uint gx,
		      uint gy,
		      uint gz,
		      uint bx,
		      uint by,
		      uint bz,
		      torch::Tensor values,
		      torch::Tensor input,
		      torch::Tensor output,
		      int batch_size)
{
  CHECK_INPUT(values);
  CHECK_INPUT(input);
  CHECK_INPUT(output);
  dim3 g3(gx, gy, gz);
  dim3 b3(bx, by, bz);
  bitrev_perm<<<g3, b3>>>(reinterpret_cast<int *>(values.data_ptr()),
			  reinterpret_cast<dtype *>(input.data_ptr()),
			  reinterpret_cast<dtype *>(output.data_ptr()),
			  batch_size);
  return output;
}
