import numpy as np
from math import sqrt
from lazylinop.butterfly import Chain, dft, ksd, KsmPermLazyLinOp
from lazylinop.butterfly import optimize as _optimize
from lazylinop.signal import chunk, fft
from lazylinop.signal.dst import _mult_xi, _dtype_sanitized_x
from lazylinop.basicops import (
    anti_eye, bitrev, eye, mpad, slicer, vstack)
from lazylinop import LazyLinOp
from lazylinop.signal.dct import _diag, _reorder


def dct(
        N: int,
        type: int = 2,
        optimize: bool = False,
        real_valued: bool = False,
        **kwargs,
):
    r"""
    Returns a :class:`.LazyLinOp` ```L`` for the Direct Cosine Transform (DCT).

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two except for DCT I (see below).

    ``L`` is orthonormal, and the :class:`.LazyLinOp`
    for the inverse DCT is ``L.T``.

    Args:
        N: ``int``
            Size of the input (N > 0).
            $N$ must be:

            - a power of two for DCT II, III and IV.
            - a power of two plus one for DCT I.
        type: ``int``, optional
            1, 2, 3, 4 (I, II, III, IV).
            Defaut is 2.
            See `SciPy DCT <https://docs.scipy.org/doc/scipy/
            reference/generated/
            scipy.fft.dct.html#scipy-fft-dct>`_ and
            `CuPy DCT <https://docs.cupy.dev/en/latest/reference/
            generated/cupyx.scipy.fft.dct.html>`_ for more details.
        optimize: ``bool``, optional
            :octicon:`alert-fill;1em;sd-text-danger`
            Optimization usually results in the most optimized
            implementation, but the optimization process may be time
            consuming, depending notably on the size of the factors,
            on the backend
            (see :py:func:`lazylinop.butterfly.ksm` for more details),
            on the dtype and on the device of the ``ks_values``.
            The default value is ``False``.
        real_valued: ``bool``, optional
            According the a seminal paper of Makhoul the DCT matrix of size N,
            $\mathbf{C}_N$, can be expressed in terms of the
            DFT matrix of size M, $\mathbf{F}_{M}$ where $M$ depends on the DCT-type.
            The most well-known expression is as
            $\mathbf{C}_N=\mathtt{Re}(\mathbf{L}\mathbf{F}_MR)$
            where the left and right matrices $\mathbf{L}$ (of size $N\times M$)
            and $\mathbf{R}$ (of size $M\times N$) are real-valued,
            but the DFT matrix $\mathbf{F}_M$ is complex-valued.

            This shows the existence of a "butterfly implementation"
            of the DCT $\mathbf{C}_N=\mathtt{Re}(\mathbf{L}\mathbf{B}_M\mathbf{R})$
            however with two caveats:

            - the Kronecker-sparse factors in $\mathbf{B}_M$ are *complex-valued*
              ``real_valued = False``
            - because of the $\mathtt{Re()}$ operator,
              this actually expresses the DCT via a *sum* of two butterfly matrices
              $\mathbf{C}_N=\mathbf{L}(\mathbf{B}_M+\overline{\mathbf{B}_M})\mathbf{R}$.

            Since the DCT is real-valued, it would be desirable to have instead
            an expression in terms of a *single* butterfly matrix $\mathbf{B}$
            with real-valued factors ``real_valued = True``,
            $\mathbf{C}_N=\mathbf{LB'R}$ where
            $\mathbf{B}':=\mathtt{real}(\mathbf{B}_M)=(\mathbf{B}_M+\overline{\mathbf{B}_M})/2$.

            By the complementary low-rank characterization of butterfly matrices
            it is possible to show that $\mathbf{B}'$ admits a Kronecker-sparse
            factorization with a *different* chain where each
            Kronecker-sparse pattern $(a,b,c,d)$ is replaced by
            $(a,2b,2c,d)$ except the lefmost (which is replaced by $(a,b,2c,d)$)
            and the rightmost (replaced by $(a,2b,c,d)$) ones.

            :octicon:`alert-fill;1em;sd-text-danger` The creation of the
            operator ``L = dct(N, ..., real_valued=True)`` can take more
            than one minute when $N\ge 8192$ due to a call
            to the decomposition function :py:func:`ksd`.

    Kwargs:
        Additional arguments ``ksm_backend``, ``ksm_params``,
        ``dtype`` and ``device`` of the ``ks_values``
        to pass to :py:func:`ksm` function.
        The default values are ``'xp'``, ``None``,
        ``complex128`` and ``'cpu'``.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``L.ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``L.ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Returns:
        :py:class:`.LazyLinOp`

    Example:
        >>> from lazylinop.butterfly import dct
        >>> from scipy.fft import dct as sp_dct
        >>> import numpy as np
        >>> N = 32
        >>> x = np.random.randn(N)
        >>> F = dct(N, 2)
        >>> y = F @ x
        >>> np.allclose(y, sp_dct(x, norm='ortho'))
        True
        >>> # compute the inverse DCT
        >>> z = F.T @ y
        >>> np.allclose(z, x)
        True
        >>> # To mimick SciPy DCT II norm='ortho' and orthogonalize=False
        >>> from lazylinop.basicops import diag
        >>> v = np.full(N, 1.0)
        >>> v[0] = np.sqrt(2.0)
        >>> y = diag(v) @ F @ x
        >>> z = sp_dct(x, 2, N, 0, 'ortho', False, 1, orthogonalize=False)
        >>> np.allclose(y, z)
        True

    References:
        [1] A Fast Cosine Transform in One and Two Dimensions,
            by J. Makhoul, `IEEE Transactions on acoustics,
            speech and signal processing` vol. 28(1), pp. 27-34,
            :doi:`10.1109/TASSP.1980.1163351` (1980).

    .. seealso::
        - `DCT (Wikipedia) <https://en.wikipedia.org/
          wiki/Discrete_cosine_transform>`_,
        - `SciPy DCT <https://docs.scipy.org/doc/scipy/
          reference/generated/ scipy.fft.dct.html#scipy-fft-dct>`_,
        - `SciPy inverse DCT <https://docs.scipy.org/doc/scipy/
          reference/generated/ scipy.fft.idct.html#scipy-fft-idct>`_,
        - `CuPy DCT <https://docs.cupy.dev/en/latest/reference/
          generated/cupyx.scipy.fft.dct.html>`_,
        - :py:func:`lazylinop.signal.dct`.
        - :py:func:`lazylinop.signal.dst`,
        - :py:func:`lazylinop.butterfly.dst`.
    """

    if type == 1:
        if N < 2:
            raise Exception("DCT I: size of the input must be >= 2.")
    p, _N = 0, N - int(type == 1)
    while _N >> 1 != 0:
        p += 1
        _N >>= 1
    if type == 1 and (N - 1) != 2 ** p:
        raise Exception("DCT I: size of the input minus one" +
                        " must be a power of two.")
    if type in [2, 3, 4] and N != 2 ** p:
        raise Exception("DCT II, III, IV: size of the input" +
                        " must be a power of two.")

    dtype = kwargs.get('dtype', 'complex128')
    device = kwargs.get('device', 'cpu')
    ksm_backend = kwargs.get("ksm_backend", 'xp')
    ksm_params = kwargs.get("ksm_params", None)

    # Infer the namespace from dtype and device.
    try:
        import array_api_compat.torch as xp
        xp.asarray([1], dtype=dtype, device=device)
    except (ModuleNotFoundError, TypeError):
        try:
            import array_api_compat.cupy as xp
            xp.asarray([1], dtype=dtype, device=device)
        except (ModuleNotFoundError, ValueError):
            import array_api_compat.numpy as xp

    # The square dyadic chain for butterfly matrices.
    if type == 1:
        Q = 2 * (N - 1)
    elif type in [2, 3]:
        Q = N
    elif type == 4:
        Q = 8 * N
    else:
        raise Exception("type must be either 1, 2, 3 or 4.")

    chain = Chain.square_dyadic((Q, Q))

    scale = [
        sqrt(2 * (N - 1)),
        sqrt(2 * N),
        sqrt(2 * N),
        sqrt(2 * N)
    ][type - 1]

    if real_valued:

        # Bit-reversal permutation.
        P = bitrev(Q)
        if type in [2, 3]:
            D = _diag(
                2 * np.exp(
                    -1j * np.pi * np.arange(Q) / (2 * Q),
                )
            )
            B = ((D @ fft(Q) * (sqrt(Q) / scale)) @ P.T).toarray(
                array_namespace=xp,
                dtype=dtype,
                device=device,
            )
        else:
            B = ((fft(Q) * (sqrt(Q) / scale)) @ P.T).toarray(
                array_namespace=xp,
                dtype=dtype,
                device=device,
            )
        Breal = xp.real(B)
        # xp.imag(B) is nonzero, showing that B is not real-valued.

        pattern2 = [None] * chain.n_patterns
        for i in range(chain.n_patterns):
            pattern = chain.ks_patterns[i]
            if i == 0:
                new_pattern = (
                    pattern[0], pattern[1], pattern[2] * 2, pattern[3])
            elif i == chain.n_patterns - 1:
                new_pattern = (
                    pattern[0], pattern[1] * 2, pattern[2], pattern[3])
            else:
                new_pattern = (
                    pattern[0], pattern[1] * 2, pattern[2] * 2, pattern[3])
            pattern2[i] = new_pattern
        chain2 = Chain(pattern2)

        if Q == 2:
            _ksv = [Breal.reshape(1, 2, 2, 1)]
        else:
            _B = ksd(Breal, chain2, ksm_backend=ksm_backend)
            _ksv = _B.ks_values
            Bhat = _B.toarray(
                array_namespace=xp,
                dtype=dtype,
                device=device,
            )
            del _B
            rerr = xp.linalg.norm(Bhat - Breal, 'fro') / xp.linalg.norm(Breal)
            if rerr > 1e-6:
                print(f"relative error={rerr}")
        if optimize:
            _ksv = _optimize(
                _ksv,
                strategy=kwargs.get("opt_strategy", 'benchmark'),
                params=kwargs.get("opt_params", {'backend': ksm_backend}),
            )
        if type in [2, 3]:
            # Divide first element of the output by sqrt(2)
            # directly in the leftmost ks-values.
            a, b, c, d = _ksv[0].shape
            v = xp.full(
                a * b * d,
                1,
                dtype=_ksv[0].dtype,
                device=_ksv[0].device,
            )
            v[0] = 1.0 / sqrt(2)
            _ksv[0] = (
                v.reshape(-1, 1) * _ksv[0].swapaxes(2, 3).reshape(a * b * d, c)
            ).reshape(a, b, d, c).swapaxes(2, 3)
        B = KsmPermLazyLinOp(
            _ksv,
            backend=ksm_backend,
            params=ksm_params,
            bitrev_perm='right',
        )
    else:
        # Here, dtype of ks_values is complex.
        _B = dft(
            Q,
            optimize,
            backend=ksm_backend,
            params=ksm_params,
            dtype=dtype,
            device=device,
            opt_strategy=kwargs.get("opt_strategy", 'benchmark'),
            opt_params=kwargs.get("opt_params", {'backend': 'xp'}),
            interval=(0, Q),
        ) * (sqrt(Q) / scale)
        if type in [2, 3]:
            # See Ref.[1] for more details.
            ksv = [xp.asarray(k, copy=True) for k in _B.ks_values]
            a, b, c, d = ksv[0].shape
            dim_out = a * b * d
            ksv[0] = (
                _diag(
                    2 * np.exp(
                        -1j * np.pi * np.arange(dim_out) / (2 * dim_out),
                    )
                ) @ ksv[0].swapaxes(2, 3).reshape(dim_out, c)
            ).reshape(a, b, d, c).swapaxes(2, 3)
            # Divide first element of the output by sqrt(2)
            # directly in the leftmost ks-values.
            v = xp.full(a * b * d, 1, dtype=ksv[0].dtype, device=ksv[0].device)
            v[0] = 1.0 / sqrt(2)
            ksv[0] = (
                v.reshape(-1, 1) * ksv[0].swapaxes(2, 3).reshape(a * b * d, c)
            ).reshape(a, b, d, c).swapaxes(2, 3)
            B = KsmPermLazyLinOp(
                ksv,
                backend=ksm_backend,
                params=ksm_params,
                bitrev_perm='right',
            )
            del _B
        else:
            B = _B

    if type == 1:
        # L @ x is equivalent to
        # sp.fft.dct(x, 1, n, 0, norm, False, 1, True)
        # up to a scale factor depending on norm.
        if N < 2:
            raise Exception("DCT I: size of the input must be >= 2.")
        L = slicer(2 * (N - 1), 0, N) @ B
        if N > 2:
            S = slicer(N, 1, N - 1)
            L = L @ vstack(
                (
                    eye(N),
                    anti_eye(N - 2) @ S,
                )
            )
        L = L @ _mult_xi(N, [0, N - 1], [sqrt(2.0)] * 2)
        L = _mult_xi(N, [0, N - 1], [1.0 / sqrt(2.0)] * 2) @ L
    elif type == 2:
        # type = 2: L @ x is equivalent to
        # sp.fft.dct(x, 2, n, 0, norm, False, 1, True)
        # Algorithm 1: Append flip(x) to the original input x.
        # Interleave with zeros such that the first element is zero.
        # Compute the DFT of length 4 * N and keep first N elements.
        # Divide first element of the output by sqrt(2).
        # M = mpad(1, 2 * N, 1, ('before'))
        # L = _mult_xi(
        #     N,
        #     [0],
        #     [1.0 / sqrt(2.0)],
        # ) @ B @ M @ vstack((eye(N), anti_eye(N)))
        # Algorithm 2: Compute FFT of size 2N of the padded input
        # and keep only the first N elements of the output.
        # L = _mult_xi(N, [0], [1.0 / sqrt(2.0)]) @ B @ eye(Q, N)
        # Algorithm 3: Follow FCT procedure from Ref.[1]
        # to use only FFT of size N.
        L = B @ _reorder(Q)
    elif type == 3:
        # type = 3: L @ x is equivalent to
        # sp.fft.dct(x, 3, n, 0, norm, False, 1, True)
        # up to a scale factor depending on norm.
        # type 3 is transpose of type 2 if first element
        # of x is divided by 2.
        L = (B @ _reorder(Q)).T
    elif type == 4:
        # L @ x is equivalent to
        # sp.fft.dct(x, 4, n, 0, norm, False, 1, True)
        # Append -flip(x), -x and flip(x) to the original input x.
        # Interleave with zeros such that the first element is zero.
        # Compute the DFT of length 8 * N and keep N odd elements.
        S = chunk(8 * N, size=1, hop=2, start=1, stop=2 * N + 1)
        M = mpad(1, 4 * N, 1, ('before'))
        L = 0.5 * (
            S @ B @ M @ vstack(
                (
                    vstack((eye(N),
                            -anti_eye(N))),
                    vstack((-eye(N),
                            anti_eye(N)))
                )
            )
        )
    else:
        raise Exception("type must be either 1, 2, 3 or 4.")

    def _lx(op, x):
        if 'complex' in str(x.dtype):
            y = op @ _dtype_sanitized_x(x)
        else:
            y = op @ x
        return xp.real(y) if 'complex' in str(y.dtype) else y

    C = LazyLinOp(
        shape=L.shape,
        matmat=lambda x: _lx(L, x),
        rmatmat=lambda x: _lx(L.T, x),
    )
    C.ksm_data = B.ksm_data

    return C
