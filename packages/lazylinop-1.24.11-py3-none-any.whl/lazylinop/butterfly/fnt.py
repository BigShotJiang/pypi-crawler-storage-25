from lazylinop.butterfly import KsmPermLazyLinOp
import array_api_compat
from lazylinop.basicops import bitrev
from lazylinop.butterfly import optimize as _optimize


def _fnt_square_dyadic_ks_values(N: int,
                                 dtype: str = 'complex128',
                                 device='cpu'):
    r"""
    Return a list of ``ks_values`` that corresponds
    to the ``F @ P.T`` matrix decomposition into
    ``n = int(np.log2(N))`` factors, where ``F`` is the FNT matrix
    and ``P`` the bit-reversal permutation matrix.
    The size $N=2^n$ of the FNT must be a power of $2$.

    We can draw the square-dyadic decomposition for $N=16$:

    .. image:: _static/square_dyadic.svg

    Args:
        N: ``int``
            FNT of size $N=2^n$.
        dtype: ``str``, optional
            It could be either ``'complex64'``, ``'complex128'`` (default)
            or ``torch.complex32``.
        device: optional
            Send ``ks_values`` to device ``device``.
            The default value is ``'cpu'``.

    Returns:
        List of 4d arrays corresponding to ``ks_values``.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly.fnt import _fnt_square_dyadic_ks_values
        >>> from lazylinop.butterfly import ksm
        >>> from lazylinop.signal import fnt
        >>> from lazylinop.basicops import bitrev
        >>> N = 2 ** 5
        >>> ks_values = _fnt_square_dyadic_ks_values(N)
        >>> x = np.random.randn(N)
        >>> L = ksm(ks_values)
        >>> P = bitrev(N)
        >>> np.allclose(N * (fnt(N) @ x), L @ P @ x)
        True

    References:
        - Learning Fast Algorithms for Linear Transforms
          Using Butterfly Factorizations.

          Dao T, Gu A, Eichhorn M, Rudra A, Re C.
          Proc Mach Learn Res. 2019 Jun;97:1517-1527.
          PMID: 31777847; PMCID: PMC6879380.
    """
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")
    if 'complex' not in str(dtype):
        raise TypeError("dtype must be complex.")
    # int(np.log2(N))
    p, _N = 0, N
    while _N >> 1 != 0:
        _N >>= 1
        p += 1
    # Infer the namespace from dtype and device.
    try:
        import array_api_compat.torch as xp
        xp.asarray([1], dtype=dtype, device=device)
    except (ModuleNotFoundError, TypeError):
        try:
            import array_api_compat.cupy as xp
            xp.asarray([1], dtype=dtype, device=device)
        except (ModuleNotFoundError, ValueError):
            import array_api_compat.numpy as xp
    # Build ks_values.
    if N == 1:
        return xp.asarray(
            [1],
            dtype=dtype,
            device=device,
        ).reshape(1, 1, 1, 1)
    ks_values = [None] * p
    for n in range(p):
        if n == (p - 1):
            f2 = xp.asarray(
                [
                    [1 - 1j, 1 + 1j],
                    [1 + 1j, 1 - 1j],
                ],
                dtype=dtype,
                device=device,
            )
            a = N // 2
            b, c = 2, 2
            d = 1
            ks_values[n] = xp.empty((a, b, c, d), dtype=dtype,
                                    device=device)
            for i in range(a):
                ks_values[n][i, :, :, 0] = f2
        else:
            s = N // 2 ** (p - n)
            t = N // 2 ** (n + 1)
            cp = xp.asarray(1 + 1j, dtype=dtype, device=device)
            cm = xp.asarray(1 - 1j, dtype=dtype, device=device)
            a = s
            b, c = 2, 2
            d = t
            ks_values[n] = xp.empty((a, b, c, d), dtype=dtype,
                                    device=device)
            # Map between 2d and 4d representations.
            # col = i * c * d + k * d + l
            # row = i * b * d + j * d + l
            # Loop over the a blocks.
            for i in range(a):
                for u in range(t):
                    for v in range(4):
                        if v == 0:
                            # 1 - 1j
                            sub_col = u
                            sub_row = u
                            tmp = cm
                        elif v == 1:
                            # 1 + 1j
                            sub_col = u + t
                            sub_row = u
                            tmp = cp
                        elif v == 2:
                            # 1 + 1j
                            sub_col = u
                            sub_row = u + t
                            tmp = cp
                        else:
                            # 1 - 1j
                            sub_col = u + t
                            sub_row = u + t
                            tmp = cm
                        j = sub_row // d
                        k = sub_col // d
                        ks_values[n][i, j, k, sub_col - k * d] = tmp
    return ks_values


def fnt(N: int, optimize: bool = False, **kwargs):
    r"""
    Return a :py:class:`LazyLinOp` `L` with the Butterfly structure
    corresponding to the Fast-Noiselet-Transform (FNT)
    (see :ref:`[1] <noiselets>` for more details).

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two.

    ``L`` is orthonormal, and the :class:`.LazyLinOp`
    for the inverse FNT is ``L.H``.

    Args:
        N: ``int``
            Size of the FNT.
            $N$ must be a power of two.
        optimize: ``bool``, optional
            :octicon:`alert-fill;1em;sd-text-danger`
            Optimization usually results in the most optimized
            implementation, but the optimization process may be time
            consuming, depending notably on the size of the factors,
            on the backend
            (see :py:func:`lazylinop.butterfly.ksm` for more details),
            on the dtype and on the device of the ``ks_values``.
            The default value is ``False``.

    Kwargs:
        Additional arguments ``ksm_backend``, ``ksm_params``,
        ``dtype`` and ``device`` of the ``ks_values``
        to pass to :py:func:`ksm` function.
        The default values are ``'xp'``, ``None``,
        ``complex128`` and ``'cpu'``.
        See :py:func:`ksm` for more details.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``L.ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``L.ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Returns:
        :py:class:`LazyLinOp` `L` corresponding to the FNT.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import fnt as bfnt
        >>> from lazylinop.signal import fnt as sfnt
        >>> N = 2 ** 5
        >>> x = np.random.randn(N)
        >>> L = bfnt(N)
        >>> y = L @ x
        >>> z = sfnt(N) @ x
        >>> np.allclose(y, z)
        True
        >>> # L is orthonormal.
        >>> np.allclose(L.H @ y, x)
        True

    .. _noiselets:

        **References:**

        [1] Noiselets.
        R. Coifman, F. Geshwind, Y. Meyer
        https://www.sciencedirect.com/science/article/pii/S1063520300903130

    .. seealso::
        - `On the incoherence of noiselet and Haar bases
          <https://hal.science/hal-00453288/document>`_,
        - :py:func:`lazylinop.signal.fnt`.
    """

    ksv = _fnt_square_dyadic_ks_values(
        N,
        dtype=kwargs.get("dtype", 'complex128'),
        device=kwargs.get("device", 'cpu'),
    )

    # Normalize.
    xp = array_api_compat.array_namespace(ksv[0])
    ksv[0] *= (1.0 / xp.asarray(N, dtype=ksv[0].dtype, device=ksv[0].device))

    if optimize:
        # Optimize ks_values.
        ksv = _optimize(
            ksv,
            strategy=kwargs.get("opt_strategy", 'benchmark'),
            params=kwargs.get("opt_params", {'backend': 'xp'}),
        )

    return KsmPermLazyLinOp(
        ksv,
        backend=kwargs.get("ksm_backend", 'xp'),
        params=kwargs.get("ksm_params", None),
        bitrev_perm='right',
        **kwargs,
    )
