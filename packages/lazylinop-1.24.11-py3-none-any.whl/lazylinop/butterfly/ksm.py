# -*- coding: utf-8 -*-

from lazylinop import LazyLinOp
from lazylinop.basicops import bitrev
from lazylinop.butterfly import Chain
import numpy as np
from pathlib import Path
from typing import Union
from warnings import warn
import importlib
from numbers import Number

try:
    import pyopencl as cl
except (ImportError, ModuleNotFoundError):
    cl = None
try:
    import pycuda.driver as cuda
    import pycuda._driver as _cuda
    # No need of an automatic make_default_context().
    # Memory leak ?
    # import pycuda.autoinit
    from pycuda.compiler import SourceModule
except (ImportError, ModuleNotFoundError):
    cuda = None
    _cuda = None
    SourceModule = None
if cuda is not None and _cuda is not None:
    try:
        cuda.init()
    except _cuda.RuntimeError:
        cuda, _cuda = None, None
try:
    import json
except ModuleNotFoundError:
    warn("json not found, please install" +
         " json to save result of ksd function.")
from array_api_compat import (
    array_namespace,
    is_cupy_array, is_numpy_array, is_torch_array, is_array_api_obj)
try:
    import cupy as cp
    import cupy_backends
except ModuleNotFoundError:
    cp = None
if cp is not None:
    try:
        cp.cuda.runtime.getDeviceCount()
    except cupy_backends.cuda.api.runtime.CUDARuntimeError:
        cp = None
try:
    import torch
    from torch.utils.cpp_extension import load_inline
except ModuleNotFoundError:
    torch = None
import time


contexts = []


def _check_hyper_parameters(hp, a: int, b: int, c: int, d: int,
                            batch_size: int, smem: int,
                            nbytes: tuple[int, int],
                            max_block_dim: tuple,
                            max_grid_dim: tuple,
                            max_work_group_size: int = None) -> bool:
    """
    Check if the given hyper-parameters satisfy the kernel assertions.

    Args:
        hp:
            Tuple of hyper-parameters
            ``(TILEX, TILEK, TILEY, TX, TY, VSIZE, WARP_TILEX, WARP_TILEX, WARP_TX, WARP_TY)``.
            Do not check warp-tiling hyper-parameters if
            ``None in (WARP_TILEX, WARP_TX, WARP_TILEY, WARP_TY)``.
        a, b, c, d: ``int``, ``int``, ``int``, ``int``
            Pattern of the Kronecker-Sparse factor.
        batch_size: ``int``
            Size of the batch ``x.shape[1]`` in ``L @ x``.
        smem: ``int``
            Size of shared memory of your hardware.
        nbytes: ``tuple`` of two ``int``
            Number of bytes of the elements of the
            Kronecker-Sparse factor and number of bytes
            of the elements of the input.
            Default value is ``(8, 8)``.
        max_block_dim: ``tuple``
            Tuple ``(x, y, z)`` for max block dimensions.
        max_grid_dim: ``tuple``
            Tuple ``(x, y, z)`` for max grid dimensions.
        max_work_group_size: ``int``, optional
            Maximum number of items in a work group (OpenCL only)
            or maximum number of threads per block (CUDA only).
            Default value is ``None``.

    Returns:
        ``bool``
    """
    warp_tiling = None not in hp[6:10]
    n_rows = a * b * d
    n_cols = a * c * d
    tile_x, tile_k, tile_y = hp[0], hp[1], hp[2]
    tx, ty, vsize = hp[3], hp[4], hp[5]
    warp_tile_x, warp_tile_y = hp[6], hp[7]
    warp_tx, warp_ty = hp[8], hp[9]
    if tile_k > n_cols or tile_k > c or (c % tile_k) != 0:
        return False
    if max_grid_dim is not None and \
       ((n_rows + tile_y - 1) // tile_y) > max_grid_dim[1]:
        return False
    if tile_y > n_rows or tile_y > b:
        return False
    if max_grid_dim is not None and \
       ((batch_size + tile_x - 1) // tile_x) > max_grid_dim[0]:
        return False
    if batch_size > 0 and (tile_x > batch_size or
                           batch_size % tile_x != 0):
        return False
    if (nbytes[0] * 2 * tile_y * tile_k +
        nbytes[1] * 2 * tile_k * tile_x) >= smem:
        return False
    if (tx % vsize) != 0 or (ty % vsize) != 0:
        return False
    x, y = tile_x // tx, tile_y // ty
    if max_block_dim is not None and \
       x > max_block_dim[0]:
        return False
    if max_block_dim is not None and \
       y > max_block_dim[1]:
        return False
    if (x * y) >= 512:
        print("here 9", x, y, x * y)
        return False
    if max_work_group_size is not None and (
            x * y) > max_work_group_size:
        return False
    strideInput = (vsize * x * y) / tile_x
    if (vsize * x * y) % tile_x != 0:
        return False
    strideValues = (vsize * x * y) / tile_k
    if (vsize * x * y) % tile_k != 0:
        return False
    if tile_k > tile_x or tile_k > tile_y:
        return False
    if (b * d) % (d * tile_y) != 0:
        return False
    if tile_k % strideInput != 0:
        return False
    if tile_y % strideValues != 0:
        return False
    if not warp_tiling:
        n_threads = x * y
        # Do not allow more than 0.8 * 255 registers per thread.
        if (x * y + x + y) > int(0.8 * 255):
            return False
        # Do not allow more than 0.8 * 65536 registers per block.
        if (n_threads * (x * y + x + y)) > int(0.8 * 65536):
            return False
    else:
        # Only check warp-tiling hyper-parameters if not None.
        # if warp_tile_x < 32 or warp_tile_y < 32:
        #     return False
        # Number of threads is x*y if no warp-tiling strategy.
        n_warps = (tile_x // warp_tile_x) * (tile_y // warp_tile_y)
        n_threads = 32 * n_warps
        if (x * y) != n_threads:
            return False
        if max_block_dim is not None and \
           (x * y) > max_block_dim[0]:
            return False
        if warp_tx < tx or warp_tx % tx != 0:
            return False
        if warp_tile_x < warp_tx or warp_tile_x % warp_tx != 0:
            return False
        if tile_x < warp_tile_x or tile_x % warp_tile_x != 0:
            return False
        if warp_ty < ty or warp_ty % ty != 0:
            return False
        if warp_tile_y < warp_ty or warp_tile_y % warp_ty != 0:
            return False
        if tile_y < warp_tile_y or tile_y % warp_tile_y != 0:
            return False
        i = warp_tile_x // warp_tx
        j = warp_tile_y // warp_ty
        # A thread computes tx * ty * i * j tiles.
        if (warp_tile_x * warp_tile_y) % (32 * tx * ty * i * j) != 0:
            return False
        # Do not allow more than 0.8 * 255 registers per thread.
        n_registers = i * tx * j * ty + i * tx + j * ty
        if n_registers > int(0.8 * 255):
            return False
        # Do not allow more than 0.8 * 65536 registers per block.
        if (n_threads * n_registers) > int(0.8 * 65536):
            return False
    return True


def _find_all_hyper_parameters(a, b, c, d, batch_size: int = 0,
                               smem: int = 163000,
                               nbytes: tuple[int, int] = (8, 8),
                               max_block_dim: tuple = None,
                               max_grid_dim: tuple = None,
                               max_work_group_size: int = None,
                               warp_tiling: bool = False,
                               choice: int = None) -> list:
    """
    Nested loops over tile size to find all the possible sets
    of hyper-parameters for a given pattern.

    Args:
        a, b, c, d: ``int``, ``int``, ``int``, ``int``
            Pattern of the Kronecker-Sparse factor.
        batch_size: ``int``, optional
            Size of the batch ``x.shape[1]`` in ``L @ x``.
            Default value is 0 (skip batch size condition).
        smem: ``int``
            Size of shared memory of your hardware.
            Default size is 163000 bytes.
        nbytes: ``tuple`` of two ``int``
            Number of bytes of the elements of the
            Kronecker-Sparse factor and number of bytes
            of the elements of the input.
            Default value is ``(8, 8)``.
        max_block_dim: ``tuple``, optional
            Tuple ``(x, y, z)`` for max block dimensions.
            ``None`` is default value.
        max_grid_dim: ``tuple``, optional
            Tuple ``(x, y, z)`` for max grid dimensions.
            ``None`` is default value.
        max_work_group_size: ``int``, optional
            Maximum number of items in a work group (OpenCL only)
            or maximum number of threads per block (CUDA only).
            Default value is ``None``.
        warp_tiling: ``bool``, optional
            Find hyper-parameters that
            do satisfy warp-tiling strategy.
            Default value is ``False``.
        choice: ``int``, optional
            Default value is ``None`` corresponding to return
            all possible tuples of hyper-parameters.
            If ``choice`` is a positive integer, return only
            the corresponding tuple of hyper-parameters.

    Returns:
        ``List`` of ``tuple`` of hyper-parameters
        ``(TILEX, TILEK, TILEY, TX, TY, VSIZE, WARP_TILEX, WARP_TILEX, WARP_TX, WARP_TY)``.
    """
    n_rows = a * b * d
    n_cols = a * c * d
    hp = []
    if isinstance(max_block_dim, tuple) and len(max_block_dim) > 1:
        tmp = max(max_block_dim[0], max_block_dim[1])
    else:
        tmp = 32
    if max_block_dim is not None:
        max_x = min(tmp, max_block_dim[0])
        max_y = min(tmp, max_block_dim[1])
    else:
        max_x, max_y = tmp, tmp
    max_bx = 1e9 if max_block_dim is None else max_block_dim[0]
    max_gx = 1e9 if max_grid_dim is None else max_grid_dim[0]
    max_gy = 1e9 if max_grid_dim is None else max_grid_dim[1]
    max_wgs = 1e9 if max_work_group_size is None else max_work_group_size
    if isinstance(choice, int) and choice >= 0:
        _choice = choice
    else:
        _choice = None
    for vsize in range(4, 0, -1):
        for x in range(max_x, 0, -1):
            for tx in range(16 * vsize, vsize - 1, -vsize):
                tile_x = x * tx
                if batch_size > 0:
                    if (
                            (batch_size + tile_x - 1) // tile_x > max_gx or
                            tile_x > batch_size or
                            batch_size % tile_x != 0
                    ):
                        continue
                for k in range(min(tile_x // vsize, 16), 0, -1):
                    tile_k = k * vsize
                    if tile_k > n_cols or tile_k > c or (c % tile_k) != 0:
                        continue
                    for y in range(min(int(512 / x - 1), max_y), 0, -1):
                        strideInput = (vsize * x * y) / tile_x
                        strideValues = (vsize * x * y) / tile_k
                        if (
                                (x * y) > max_wgs or
                                (vsize * x * y) % tile_x != 0 or
                                (vsize * x * y) % tile_k != 0 or
                                tile_k % strideInput != 0
                        ):
                            continue
                        for ty in range(16 * vsize, vsize - 1, -vsize):
                            tile_y = y * ty
                            if (
                                    nbytes[0] * 2 * tile_y * tile_k +
                                    nbytes[1] * 2 * tile_k * tile_x
                            ) >= smem:
                                continue
                            if (
                                    (n_rows + tile_y - 1) // tile_y > max_gy or
                                    tile_k > tile_y or
                                    tile_y > n_rows or
                                    tile_y > b or
                                    tile_y % strideValues != 0 or
                                    (b * d) % (d * tile_y) != 0
                            ):
                                continue
                            if not warp_tiling:
                                n_threads = x * y
                                n_registers = x * y + x + y
                                # Do not allow more than
                                # 0.8 * 255 registers per thread
                                # and more than 0.8 * 65536 registers per block.
                                if (
                                        n_registers > int(0.8 * 255) or
                                        (n_threads * n_registers) > int(0.8 * 65536)
                                ):
                                    continue
                                hp.append(
                                    (
                                        tile_x, tile_k, tile_y, tx, ty, vsize,
                                        None, None, None, None
                                    )
                                )
                                if _choice is not None and _choice < len(hp):
                                    return hp[_choice]
                            else:
                                for j in range(tmp, 0, -1):
                                    for warp_ty in range(
                                            64,
                                            max(16 // j, max(ty, vsize)) - 1,
                                            -1,
                                    ):
                                        warp_tile_y = j * warp_ty
                                        n_warps_y = tile_y // warp_tile_y
                                        if (
                                                tile_y < warp_tile_y or
                                                tile_y % warp_tile_y != 0 or
                                                warp_ty < ty or
                                                warp_ty % ty != 0
                                        ):
                                            continue
                                        for i in range(tmp, 0, -1):
                                            for warp_tx in range(
                                                    64,
                                                    max(16 // i, max(tx, vsize)) - 1,
                                                    -1,
                                            ):
                                                warp_tile_x = i * warp_tx
                                                if (
                                                        tile_x < warp_tile_x or
                                                        tile_x % warp_tile_x != 0 or
                                                        warp_tx < tx or
                                                        warp_tx % tx != 0
                                                ):
                                                    continue
                                                # Number of threads is x*y if no warp-tiling strategy.
                                                n_warps = (tile_x // warp_tile_x) * n_warps_y
                                                n_threads = 32 * n_warps
                                                if (
                                                        (x * y) != n_threads or
                                                        n_threads > max_bx
                                                ):
                                                    continue
                                                # A thread computes tx * ty * i * j tiles.
                                                if (warp_tile_x * warp_tile_y) % (
                                                        32 * tx * ty * i * j) != 0:
                                                    continue
                                                # Do not allow more than 0.8 * 255 registers per thread.
                                                # Do not allow more than 0.8 * 65536 registers per block.
                                                n_registers = i * tx * j * ty + i * tx + j * ty
                                                if (
                                                        n_registers > int(0.8 * 255) or
                                                        (n_threads * n_registers) > int(0.8 * 65536)
                                                ):
                                                    continue
                                                hp.append(
                                                    (
                                                        tile_x, tile_k, tile_y, tx, ty, vsize,
                                                        warp_tile_x, warp_tile_y, warp_tx, warp_ty
                                                    )
                                                )
                                                if _choice is not None and _choice < len(hp):
                                                    return hp[_choice]

    if len(hp) == 0:
        raise Exception("Did not find hyper-parameters.")
    return hp


def _modify_template(a: int, b: int, c: int, d: int,
                     batch_size: int, dtype: tuple,
                     smem: int = 163000,
                     max_block_dim: tuple = None,
                     max_grid_dim: tuple = None,
                     max_work_group_size: int = None,
                     params: tuple = (None, None),
                     ext: str = 'clh',
                     hadamard: bool = False):
    r"""
    Add explicit values of the hyper-parameters to the kernel.

    Args:
        a, b, c, d: ``int``, ``int``, ``int``, ``int``
            Pattern of the Kronecker-Sparse factor.
        batch_size: ``int``
            Size of the batch ``x.shape[1]`` in ``L @ x``.
        dtype: ``tuple``
            dtype of the Kronecker-Sparse factor
            and dtype of the input.
        smem: ``int``
            Size of shared memory of your hardware.
            Default size is 163000 bytes.
        max_block_dim: ``tuple``
            Tuple ``(x, y, z)`` for max block dimensions.
        max_grid_dim: ``tuple``
            Tuple ``(x, y, z)`` for max grid dimensions.
        max_work_group_size: ``int``, optional
            Maximum number of items in a work group (OpenCL only)
            or maximum number of threads per block (CUDA only).
            Default value is ``None``.
        params: ``tuple``, optional
            ``params[0]`` and ``params[1]`` expect a tuple of ten elements
            ``(TILEX, TILEK, TILEY, TX, TY, VSIZE, WARP_TILEX, WARP_TILEY, WARP_TX, WARP_TY)``
            (see :ref:`[1] <ksm>` for more details).
            Do not use warp-tiling if
            ``WARP_TILEX = WARP_TX = WARP_TILEY = WARP_TY = None``.
            If ``(None, None)`` (default), the choice of
            hyper-parameters for multiplication ``L @ X`` and the
            multiplication ``L.H @ X`` is automatic.
            Because we did not run a fine-tuning for all the
            possible $\left(a,~b,~c,~d\right)$ and $\left(a,~c,~b,~d\right)$
            tuples, automatic does not always correspond to the best choice.
        ext: ``str``, optional

            - ``'clh'`` uses OpenCL kernel template.
            - ``'cuh'`` uses CUDA kernel template.
        hadamard: ``bool``, optional
            If ``True`` use Hadamard specialized kernel.
            Default value is ``False``.
    """
    lines, hp, rhp, valid = {}, {}, {}, {}
    prefix = "h" if hadamard else ""
    msg = (
        "ksmm kernel: hyper-parameters do not" +
        " satisfy the block and grid dimensions.\n" +
        "It is possible the batch size of the" +
        " current input changed from its inital value.\n" +
        "Therefore, use default hyper-parameters."
    )
    for f in ["ksmm", "rksmm", "ksmm_wt", "rksmm_wt"]:
        lines[f] = []
        valid[f] = True
        _f = f.replace("rksmm", "ksmm")
        with open(
                Path(__file__).parent.joinpath(
                    f"kernels/{prefix}{f}.{ext}"), 'w') as out_file:
            with open(
                    Path(__file__).parent.joinpath(
                        f"kernels/template_{prefix}{_f}.{ext}"), 'r') as in_file:
                if f == "ksmm" or f == "ksmm_wt":
                    ip = 0
                    _b, _c = b, c
                    msg = (
                        "matmat: hyper-parameters do not" +
                        " satisfy the kernel assertions or" +
                        " block and grid dimensions."
                    )
                else:
                    ip = 1
                    _b, _c = c, b
                    msg = (
                        "rmatmat: hyper-parameters do not" +
                        " satisfy the kernel assertions or" +
                        " block and grid dimensions."
                    )
                if params is None or params[ip] is None:
                    try:
                        tmp = _find_all_hyper_parameters(
                            a, _b, _c, d, batch_size,
                            smem=smem,
                            nbytes=(
                                dtype[0].itemsize,
                                dtype[1].itemsize,
                            ),
                            max_block_dim=max_block_dim,
                            max_grid_dim=max_grid_dim,
                            max_work_group_size=max_work_group_size,
                            warp_tiling=f in ("ksmm_wt", "rksmm_wt"),
                            choice=0,
                        )
                    except Exception:
                        tmp = tuple([None] * 10)
                        valid[f] = False
                else:
                    if len(params[ip]) != 10:
                        raise Exception(
                            "matmat: hyper-parameters must be "
                            + "a tuple of ten elements.")
                    else:
                        tmp = params[ip]
                        if not _check_hyper_parameters(
                                tmp, a, _b, _c, d,
                                batch_size,
                                smem=smem,
                                nbytes=(
                                    dtype[0].itemsize,
                                    dtype[1].itemsize,
                                ),
                                max_block_dim=max_block_dim,
                                max_grid_dim=max_grid_dim,
                                max_work_group_size=max_work_group_size,
                        ):
                            raise Exception(msg)
                if f == "ksmm" or f == "ksmm_wt":
                    hp[f] = tmp
                else:
                    rhp[f] = tmp

                p = hp[f] if f in ("ksmm", "ksmm_wt") else rhp[f]
                if p == tuple([None] * 10):
                    # Did not find warp-tiling hyper-parameters,
                    # therefore kernel f is not valid.
                    valid[f] = False
                    continue

                # Number of threads.
                if f in ("ksmm_wt", "rksmm_wt"):
                    # Number of warp-tiles in a tile times WARP_SIZE.
                    if None in p[6:10]:
                        # Did not find warp-tiling hyper-parameters,
                        # therefore kernel f is not valid.
                        valid[f] = False
                        continue
                    else:
                        nthreads = (p[0] // p[6]) * (p[2] // p[7]) * 32
                        p = tuple(list(p) + [nthreads, 1, 1])
                else:
                    nthreads = (p[0] // p[3]) * (p[2] // p[4])
                    p = tuple(list(p) + [p[0] // p[3], p[2] // p[4], 1])
                if f in ("ksmm", "ksmm_wt"):
                    hp[f] = p
                else:
                    rhp[f] = p
                if max_work_group_size is not None and nthreads > max_work_group_size:
                    raise Exception("nthreads > max_work_group_size.")

                if prefix == "h":
                    # Define integer.
                    if 'int8' in str(dtype[0]):
                        lines[f].append("#define USE_INT8\n")
                    if 'int16' in str(dtype[0]):
                        lines[f].append("#define USE_INT16\n")
                    elif 'int32' in str(dtype[0]):
                        lines[f].append("#define USE_INT32\n")
                    else:
                        pass

                if 'complex' in str(dtype[0]):
                    lines[f].append("#define VALUES_IS_CPLX\n")
                else:
                    lines[f].append("#define VALUES_IS_REAL\n")
                if 'complex' in str(dtype[1]):
                    lines[f].append("#define INPUT_IS_CPLX\n")
                else:
                    lines[f].append("#define INPUT_IS_REAL\n")

                for i in range(2):
                    str_dtype = str(dtype[i])
                    # Define floating point precision.
                    if 'bfloat16' in str_dtype:
                        lines[f].append("#define USE_BFLOAT16\n")
                    elif 'float16' in str_dtype:
                        lines[f].append("#define USE_FLOAT16\n")
                    elif 'float32' in str_dtype:
                        lines[f].append("#define USE_FLOAT32\n")
                    elif 'float64' in str_dtype:
                        lines[f].append("#define USE_FLOAT64\n")
                    elif 'complex64' in str_dtype:
                        lines[f].append("#define USE_COMPLEX64\n")
                    elif 'complex128' in str_dtype:
                        lines[f].append("#define USE_COMPLEX128\n")
                    else:
                        pass
                # vloadn and vstoren depend on the values of b and c.
                lines[f].append("#define V" + str(p[5]) + "\n")
                lines[f].append("#define xTILEXx " + str(p[0]) + "\n")
                lines[f].append("#define xTILEKx " + str(p[1]) + "\n")
                lines[f].append("#define xTILEYx " + str(p[2]) + "\n")
                lines[f].append("#define xTXx " + str(p[3]) + "\n")
                lines[f].append("#define xTYx " + str(p[4]) + "\n")
                lines[f].append(
                    "#define xNTHREADSx " + str(nthreads) + "\n\n")
                if f in ("ksmm_wt", "rksmm_wt"):
                    lines[f].append("#define xWARPTILEXx " + str(p[6]) + "\n")
                    lines[f].append("#define xWARPTILEYx " + str(p[7]) + "\n")
                    lines[f].append("#define xWARPTXx " + str(p[8]) + "\n")
                    lines[f].append("#define xWARPTYx " + str(p[9]) + "\n")
                lines[f].extend(in_file.readlines())

    return (
        hp["ksmm_wt" if valid["ksmm_wt"] else "ksmm"],
        rhp["rksmm_wt" if valid["rksmm_wt"] else "rksmm"],
        lines["ksmm_wt" if valid["ksmm_wt"] else "ksmm"],
        lines["rksmm_wt" if valid["rksmm_wt"] else "rksmm"]
    )


def _find_all_hyper_parameters_perm(M: int, batch_size: int,
                                    max_block_dim: tuple = None,
                                    max_grid_dim: tuple = None,
                                    max_work_group_size: int = None,
                                    choice: int = None):
    r"""
    Find all the possible hyper-parameters
    for the bit-reversal permutation kernel.
    ``(TILEX, TILEY, VSIZE)`` that must satisfy
    the following conditions:

    - ``M % TILEY == 0``
    - ``VSIZE >= 1`` and ``VSIZE <= 4``
    - ``batch_size % (VSIZE * TILEX) == 0``

    Args:
        M: ``int``
            Number of rows of the bit-reversal permutation matrix.
        batch_size: ``int``
            Size of the batch ``x.shape[1]`` in ``L @ x``.
        max_block_dim: ``tuple``
            Tuple ``(x, y, z)`` for max block dimensions.
        max_grid_dim: ``tuple``
            Tuple ``(x, y, z)`` for max grid dimensions.
        max_work_group_size: ``int``, optional
            Maximum number of items in a work group (OpenCL only)
            or maximum number of threads per block (CUDA only).
            Default value is ``None``.
        choice: ``int``, optional
            Default value is ``None`` corresponding to return
            all possible tuples of hyper-parameters.
            If ``choice`` is a positive integer, return only
            the corresponding tuple of hyper-parameters.

    Returns:
        ``List`` of ``tuple`` of hyper-parameters
        ``(TILEX, TILEY, VSIZE)``.
    """
    hp = []
    for v in range(4, 0, -1):
        # batch_size % (v * tile) = 0
        for tx in range(64, 0, -1):
            if max_grid_dim is not None:
                if (batch_size + v * tx - 1) // (v * tx) > max_grid_dim[0]:
                    continue
            if max_block_dim is not None:
                if tx > max_block_dim[0]:
                    continue
            if batch_size % (v * tx) == 0:
                # M % tile = 0
                for ty in range(64, 0, -1):
                    if max_work_group_size is not None and (tx * ty) > max_work_group_size:
                        continue
                    if max_grid_dim is not None:
                        if (M + ty - 1) // ty > max_grid_dim[1]:
                            continue
                    if max_block_dim is not None:
                        if ty > max_block_dim[1]:
                            continue
                    if M % ty == 0:
                        hp.append((tx, ty, v))
                        if isinstance(choice, int) and (
                                choice >= 0 and choice < len(hp)):
                            return hp[choice]
    if len(hp) == 0:
        raise Exception("Did not find hyper-parameters.")
    return hp


def _modify_template_bitrev_perm(M: int, batch_size: int,
                                 dtype, smem: int = 163000,
                                 max_block_dim: tuple = None,
                                 max_grid_dim: tuple = None,
                                 max_work_group_size: int = None,
                                 params: tuple = None,
                                 ext: str = 'clh'):
    r"""
    Add explicit values of the hyper-parameters to the kernel.

    Args:
        M: ``int``
            Number of rows of the bit-reversal permutation matrix.
        batch_size: ``int``
            Size of the batch ``x.shape[1]`` in ``L @ x``.
        dtype:
            dtype of the input array.
        smem: ``int``
            Size of shared memory of your hardware.
            Default size is 163000 bytes.
        max_block_dim: ``tuple``
            Tuple ``(x, y, z)`` for max block dimensions.
        max_grid_dim: ``tuple``
            Tuple ``(x, y, z)`` for max grid dimensions.
        max_work_group_size: ``int``, optional
            Maximum number of items in a work group (OpenCL only)
            or maximum number of threads per block (CUDA only).
            Default value is ``None``.
        params: ``tuple``, optional
            ``params`` expect a tuple of three elements
            ``(TILEX, TILEY, VSIZE)`` that must satisfy
            the following conditions:

            - ``M % TILEY == 0``
            - ``VSIZE >= 1`` and ``VSIZE <= 4``
            - ``batch_size % (VSIZE * TILEX) == 0``
            If ``None`` (default), the choice of
            hyper-parameters for multiplication ``L @ X`` and the
            multiplication ``L.H @ X`` is automatic.
            Because we did not run a fine-tuning for all the
            possible $\left(a,~b,~c,~d\right)$ and $\left(a,~c,~b,~d\right)$
            tuples, automatic does not always correspond to the best choice.
        ext: ``str``, optional

            - ``'clh'`` uses OpenCL kernel template.
            - ``'cuh'`` uses CUDA kernel template.
    """
    lines, pbx, pby, vsize = [], None, None, None
    with open(
            Path(__file__).parent.joinpath(
                f"kernels/template_bitrev_perm.{ext}"), 'r') as in_file:

        # Define floating point precision.
        if 'float16' in str(dtype):
            lines.append("#define USE_FLOAT16\n")
        elif 'float32' in str(dtype):
            lines.append("#define USE_FLOAT32\n")
        elif 'float64' in str(dtype):
            lines.append("#define USE_FLOAT64\n")
        elif 'complex64' in str(dtype):
            lines.append("#define USE_COMPLEX64\n")
        elif 'complex128' in str(dtype):
            lines.append("#define USE_COMPLEX128\n")
        else:
            pass
        if params is None:
            hp = _find_all_hyper_parameters_perm(
                M,
                batch_size,
                max_block_dim,
                max_grid_dim,
                max_work_group_size,
                choice=0,
            )
            pbx, pby, vsize = hp
        else:
            valid = True
            pbx = params[0]
            pby = params[1]
            vsize = params[2]
            if (
                    batch_size % (vsize * pbx) != 0 or
                    M % pby != 0 or
                    vsize < 1 or vsize > 4
            ):
                valid = False
            if max_block_dim is not None and (
                    pbx > max_block_dim[0] or pby > max_block_dim[1]):
                valid = False
            if max_grid_dim is not None:
                if (batch_size + vsize * pbx - 1) // (vsize * pbx) > max_grid_dim[0]:
                    valid = False
                if (M + pby - 1) // pby > max_grid_dim[1]:
                    valid = False
            if max_work_group_size is not None and (pbx * pby) > max_work_group_size:
                valid = False
            if not valid:
                warn(
                    "bit-reversal permutation: hyper-parameters do not" +
                    " satisfy the block and grid dimensions.\n" +
                    "It is possible the batch size of the" +
                    " current input changed from its inital value.\n" +
                    "Therefore, use default hyper-parameters."
                )
                pbx, pby, vsize = _find_all_hyper_parameters_perm(
                    M,
                    batch_size,
                    max_block_dim,
                    max_grid_dim,
                    max_work_group_size,
                    choice=0,
                )

        lines.append("#define V" + str(vsize) + "\n")
        lines.extend(in_file.readlines())

    return pbx, pby, vsize, lines


def _get_info_dim(dev):
    """
    Return max shared memory, max work group size,
    max block dim and max grid dim of dev.

    Args:
        dev:
            A ``cl.Device``, ``pycuda.driver.Device``,
            ``torch.Device `` or``cp.cuda.Device``.
    """
    msg = "dev must be either a cl.Device,"
    msg += " a pycuda.driver.Device,"
    msg += " a torch or a CuPy device."
    # Shared memory and grid/block sizes.
    if cl is not None and isinstance(dev, cl.Device):
        smem = dev.get_info(cl.device_info.LOCAL_MEM_SIZE)
        max_work_group_size = dev.get_info(
            cl.device_info.MAX_WORK_GROUP_SIZE)
        max_block_dim = dev.get_info(
            cl.device_info.MAX_WORK_ITEM_SIZES)
        max_grid_dim = None
    elif cuda is not None and isinstance(dev, cuda.Device):
        smem = dev.get_attribute(
            _cuda.device_attribute.MAX_SHARED_MEMORY_PER_BLOCK)
        max_work_group_size = dev.get_attribute(
            _cuda.device_attribute.MAX_THREADS_PER_BLOCK)
        max_block_dim = (
            dev.get_attribute(
                cuda.device_attribute.MAX_BLOCK_DIM_X),
            dev.get_attribute(
                cuda.device_attribute.MAX_BLOCK_DIM_Y),
            dev.get_attribute(
                cuda.device_attribute.MAX_BLOCK_DIM_Z))
        max_grid_dim = (
            dev.get_attribute(
                cuda.device_attribute.MAX_GRID_DIM_X),
            dev.get_attribute(
                cuda.device_attribute.MAX_GRID_DIM_Y),
            dev.get_attribute(
                cuda.device_attribute.MAX_GRID_DIM_Z))
    elif torch is not None and isinstance(dev, torch.device):
        import ctypes
        _libcuda = ctypes.CDLL("libcuda.so")
        tmp = ctypes.c_int()
        _libcuda.cuDeviceGet(ctypes.byref(tmp), dev.index)
        _id = tmp.value
        # nGpus = ctypes.c_int()
        # _libcuda.cuDeviceGetCount(ctypes.byref(nGpus))
        tmp = ctypes.c_size_t()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(tmp), 8, _id)
        smem = tmp.value
        tmp = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(tmp), 1, _id)
        max_work_group_size = tmp.value
        bx = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(bx), 2, _id)
        by = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(by), 3, _id)
        bz = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(bz), 4, _id)
        max_block_dim = (bx.value, by.value, bz.value)
        gx = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(gx), 5, _id)
        gy = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(gy), 6, _id)
        gz = ctypes.c_int()
        _libcuda.cuDeviceGetAttribute(ctypes.byref(gz), 7, _id)
        max_grid_dim = (gx.value, gy.value, gz.value)
    elif cp is not None and isinstance(dev, cp.cuda.Device):
        # for k in dev.attributes.keys():
        #     print(k, dev.attributes[k])
        # assert 0
        smem = dev.attributes['MaxSharedMemoryPerBlock']
        max_work_group_size = dev.attributes['MaxThreadsPerBlock']
        max_block_dim = (
            dev.attributes['MaxBlockDimX'],
            dev.attributes['MaxBlockDimY'],
            dev.attributes['MaxBlockDimZ'])
        max_grid_dim = (
            dev.attributes['MaxGridDimX'],
            dev.attributes['MaxGridDimY'],
            dev.attributes['MaxGridDimZ'])
    else:
        raise Exception(msg)
    return smem, max_work_group_size, max_block_dim, max_grid_dim


class Ksm_data():
    """
    This class keeps track of the last batch size.
    """
    def __init__(self, batch_size: int = None):
        self.batch_size = batch_size
        self.hp = None
        self.rhp = None
        self.program = None
        self.rprogram = None
        self.last_call = None
        self.dev_ptr = [None] * 3
        self.rdev_ptr = [None] * 3
        self.ksv_dev_ptr = None
        self.duration = {
            "ksmm": None, "perm": 0.0, "copy": 0.0}


def ksm(ks_values: Union[np.ndarray, list],
        backend: str = 'xp',
        params: Union[tuple, list] = None):
    r"""
    Returns a specialization ``L`` of :class:`.LazyLinOp` for
    Kronecker Sparse Matrix Multiplication (KSMM see :ref:`[1] <ksm>`).
    The sparsity pattern (or support) of a Kronecker-Sparse factor
    is defined as $I_a\otimes 1_{b,c}\otimes I_d$
    while its values are given by either a 4D NumPy, CuPy array or
    torch tensor of shape ``(a, b, c, d)``.

    The shape of ``L`` is $\left(abd,~acd\right)$.

    To fill a ``ks_values`` and its Kronecker-Sparse factor ``M``:

    .. _indexing:

    .. code-block:: python3

        M = np.zeros((a * b * d, a * c * d), dtype=np.float32)
        ks_values = np.empty((a, b, c, d), dtype=M.dtype)
        for i in range(a):
            for j in range(b):
                for k in range(c):
                    for l in range(d):
                        tmp = np.random.randn()
                        ks_values[i, j, k, l] = tmp
                        M[i * b * d + j * d + l,
                          i * c * d + k * d + l] = tmp

    For ``a = 3, b = 3, c = 5, d = 5`` we have the following pattern.

    .. image:: _static/abcd.svg

    .. note::

        You can access the ``ks_values`` of
        ``L = ksm(...)`` using ``L.ks_values``.

    :octicon:`megaphone;1em;sd-text-danger` With OpenCL and CUDA
    backend, ``L @ X`` will implicitly cast ``X`` to:

    - match the dtype of ``L.ks_values``
    - be of contiguous type
    This can incur a loss of performance, as-well-as a loss of
    precision if the dtype of X was initially of higher precision
    than that of ``L.ks_values``.

    Args:
        ks_values: CuPy/NumPy arrays, torch tensors or ``list`` of arrays
            It could be:

            - A 4D array of values of the Kronecker-Sparse factor.
            - List of values of the Kronecker-Sparse factors.
              The length of the list corresponds to the number
              of Kronecker-Sparse factors.
            The ``dtype`` of each ``ks_values`` is either
            ``torch.bfloat16`` (torch only), ``'float16'``,
            ``'float32'``, ``'float64'``, ``'complex64'`` or ``'complex128'``.
            See :ref:`code <indexing>` above for details on the
            expected indexing of ``ks_values``.

            :octicon:`alert-fill;1em;sd-text-danger` The chain infered by the
            shape of ``ks_values`` must be valid and chainable.
        backend: optional
            The available backends depend on the namespace (see
            `array-api-compat <https://data-apis.org/array-api-compat/>`_
            for more details) of the ``ks_values``.
            By default, use a namespace-based implementation.

            - For ``torch`` namespace:

                - ``backend='ksmm'`` to run the algorithm of :ref:`[1] <ksm>`.
                  :octicon:`info;1em;sd-text-danger` It uses a CUDA device
                  determined by ``ks_values`` and relies on
                  ``torch.utils.cpp_extension.load_inline``.
            - For ``cupy`` namespace:

                - ``backend='ksmm'`` to run the algorithm of :ref:`[1] <ksm>`.
                  :octicon:`info;1em;sd-text-danger` It uses a CUDA device
                  determined by ``ks_values`` (must be on GPU) and
                  relies on ``cp.RawModule``.
                - ``backend='cupyx'`` uses the
                  ``cupyx.scipy.sparse.csr_matrix`` function.
            - For ``numpy`` namespace:

                - ``backend='scipy'`` uses the SciPy sparse functions
                  ``scipy.sparse.block_diag`` and ``scipy.sparse.csr_matrix``.
                - ``backend=(platform, device)`` to use OpenCL
                  to run the algorithm of :ref:`[1] <ksm>`.

                    - ``(None, None)``  uses the first platform and device.
                    - ``(None, 'cpu')`` use the first platform and CPU device.
                    - ``(None, 'gpu')`` use the first platform and GPU device.

                  Please consider the following piece of code
                  for advanced choices:

                  .. code-block:: python3

                      import pyopencl as cl
                      # Get your favorite platform.
                      platform = cl.get_platforms()[pl_id]
                      # To get your favorite CPU device.
                      device = platform.get_devices(device_type=cl.device_type.CPU)[dev_id]
                      # To get your favorite GPU device.
                      device = platform.get_devices(device_type=cl.device_type.GPU)[dev_id]
                  To check platforms and devices of your system you can also
                  run the command line ``clinfo -a``.
                  See `PyOpenCL documentation <https://documen.tician.de/pyopencl/>`_
                  for more details.
                - ``backend=pycuda.driver.Device(id)`` uses a CUDA device
                  to run the algorithm of :ref:`[1] <ksm>`.
                  See `PyCUDA documentation <https://documen.tician.de/pycuda/>`_
                  for more details.
        params: ``tuple`` or ``list`` of ``tuple``, optional
            Argument ``params`` only works for OpenCL and CUDA backends.
            It could be:

            - A tuple ``params`` of tuples where
              ``params[0]`` and ``params[1]`` expect a tuple of ten elements
              ``(TILEX, TILEK, TILEY, TX, TY, VSIZE, WARP_TILEX, WARP_TILEY, WARP_TX, WARP_TY)``
              (see :ref:`[1] <ksm>` for more details).
              Do not use warp-tiling if
              ``WARP_TILEX = WARP_TX = WARP_TILEY = WARP_TY = None``.
              If ``(None, None)`` (default), the choice of
              hyper-parameters for multiplication ``L @ X`` and the
              multiplication ``L.H @ X`` is automatic.
              Because we did not run a fine-tuning for all the
              possible $\left(a,~b,~c,~d\right)$ and $\left(a,~c,~b,~d\right)$
              tuples, automatic does not always correspond to the best choice.
            - List of tuple of length the number of factors.
              ``params[i][0]`` and ``params[i][1]`` expect a tuple
              of ten elements
              ``(TILEX, TILEK, TILEY, TX, TY, VSIZE, WARP_TILEX, WARP_TILEY, WARP_TX, WARP_TY)``
              (see :ref:`[1] <ksm>` for more details).
              Do not use warp-tiling if
              ``WARP_TILEX = WARP_TX = WARP_TILEY = WARP_TY = None``.
              See `How to Optimize a CUDA Matmul Kernel for cuBLAS-like
              Performance: a Worklog <https://siboehm.com/articles/22/CUDA-MMM>`_
              for more details about warp-tiling.
              If ``None`` (default), the choice of
              hyper-parameters for multiplication ``L @ X`` and the
              multiplication ``L.H @ X`` is automatic.
              Because we did not run a fine-tuning for all the
              possible $\left(a,~b,~c,~d\right)$ and $\left(a,~c,~b,~d\right)$
              tuples, automatic does not always correspond to the best choice.

            List of assertions the tuple
            ``(TILEX, TILEK, TILEY, TX, TY, VSIZE)`` must satisfy:

            - ``TILEX = X * TX``
            - ``TILEY = Y * TY``
            - ``batch size % TILEX == 0`` for performance reason.
              Consider zero-padding of the batch.
            - ``TILEX < batch size``
            - ``TILEK <= c and c % TILEK == 0`` for performance reason.
            - ``TILEX > TILEK and TILEY > TILEK``
            - ``(VSIZE * X * Y) % TILEX == 0``
            - ``TILEK % strideInput == 0``
            - ``(VSIZE * X * Y) % TILEK == 0``
            - ``TILEY % strideValues == 0``
            - ``TILEY <= b``
            - ``(b * d) % (d * TILEY) == 0``
            - ``ks_values.dtype.itemsize * 2 * (TILEY * TILEK + TILEK * TILEX) < smem``

            where ``smem`` is the shared memory of the hardware
            used to compute, ``VSIZE`` ranges from $1$ to $4$,
            ``strideValues = VSIZE * X * Y / TILEK``
            and ``strideInput = VSIZE * X * Y / TILEX``.

    Returns:
        An instance ``L`` of
        :py:class:`lazylinop.butterfly.KsmLazyLinOp` class
        that is a specialization of
        :py:class:`.LazyLinOp` for
        Kronecker Sparse Matrix Multiplication (KSMM).
        You can access the *ks-values* (resp. the *chain*) of
        ``L`` using ``L.ks_values`` (resp. ``L.chain``).

    Examples:
        >>> from lazylinop.butterfly.ksm import ksm
        >>> import numpy as np
        >>> a, b, c, d = 2, 4, 3, 2
        >>> ks_values = np.full((a, b, c, d), 1.0, dtype=np.float32)
        >>> L = ksm(ks_values)
        >>> L.toarray(dtype='float')
        array([[1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0.],
               [0., 1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0.],
               [1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0.],
               [0., 1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0.],
               [1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0.],
               [0., 1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0.],
               [1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0., 0.],
               [0., 1., 0., 1., 0., 1., 0., 0., 0., 0., 0., 0.],
               [0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1., 0.],
               [0., 0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1.],
               [0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1., 0.],
               [0., 0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1.],
               [0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1., 0.],
               [0., 0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1.],
               [0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1., 0.],
               [0., 0., 0., 0., 0., 0., 0., 1., 0., 1., 0., 1.]])
        >>> # List of Kronecker-Sparse factors.
        >>> a1, b1, c1, d1 = 2, 4, 3, 3
        >>> ks_values1 = np.full((a1, b1, c1, d1), 1.0, dtype=np.float32)
        >>> a2, b2, c2, d2 = 3, 3, 5, 2
        >>> ks_values2 = np.full((a2, b2, c2, d2), 1.0, dtype=np.float32)
        >>> L = ksm(ks_values1) @ ksm(ks_values2)
        >>> M = ksm([ks_values1, ks_values2])
        >>> np.allclose(L.toarray(dtype='float'), M.toarray(dtype='float'))
        True

    .. _ksm:

        **References:**

        [1] Fast inference with Kronecker-sparse matrices.
        Antoine Gonon and Léon Zheng and Pascal Carrivain and Quoc-Tung Le
        https://arxiv.org/abs/2405.15013

    .. seealso::

        - `CuPy RawModule <https://docs.cupy.dev/en/stable/reference/
          generated/cupy.RawModule.html#cupy.RawModule>`_,
        - `Interoperability <https://docs.cupy.dev/en/stable/
          user_guide/interoperability.html>`_,
        - `Data interchange mechanism <https://data-apis.org/array-api/
          latest/design_topics/data_interchange.html>`_.
    """

    return KsmLazyLinOp(ks_values=ks_values,
                        backend=backend, params=params)


def _fp_support(platform, device, dtype):
    """
    Check OpenCL and platform fp support.

    Args:
        platform: ``cl.Platform``
            OpenCL platform.
        device: ``cl.Device``
            OpenCL device.
        dtype: ``str`` or ``torch.dtype``
            dtype of the arrays.

    Returns:
        ``tuple`` of ``bool``
        (``True`` if dtype is in ``cl.platform_info.EXTENSIONS``)
        and ``str`` (message if dtype is not in
        ``cl.platform_info.EXTENSIONS``).
    """
    # Return False if dtype is not in cl.platform_info.EXTENSIONS
    # and not in cl.device_info.EXTENSIONS.
    _extensions = platform.get_info(cl.platform_info.EXTENSIONS)
    _extensions += device.get_info(cl.device_info.EXTENSIONS)
    if (
            ('float16' in str(dtype) or 'half' in str(dtype)) and
            not ('cl_khr_fp16' in _extensions or
                 'cl_amd_fp16' in _extensions)
    ):
        return False, f"{platform}:{device} has no fp16 extension."
    if (
            ('float64' in str(dtype) or 'complex128' in str(dtype)) and
            not ('cl_khr_fp64' in _extensions or
                 'cl_amd_fp64' in _extensions)
    ):
        return False, f"{platform}:{device} has no fp64 extension."
    return True, ""


def _context(backend, dtype):
    """
    Return either PyOpenCL, PyCUDA context or ``None`` for other backends``.

    Args:
        backend: ``str``, ``tuple[cl.Platform, cl.Device]`` or ``pycuda.driver.Device``
            Use ``backend`` to compute the Kronecker-Sparse
            matrix multiplication.
        dtype: ``str`` or ``torch.dtype``
            dtype of the ``ks_values``.

    Returns:
        ``cl.Context``, ``pycuda.driver.Context``
        or ``None`` for other backends``.
    """
    global contexts
    # OpenCL variables declaration.
    if isinstance(backend, tuple) and len(backend) == 2 and \
       cl is not None and \
       isinstance(backend[0], cl.Platform) and \
       isinstance(backend[1], cl.Device):
        # OpenCL and fp support.
        _support, msg = _fp_support(backend[0], backend[1], dtype)
        if not _support:
            raise RuntimeError(msg)
        # Do we already have a cl.Context ?
        for i in range(len(contexts)):
            if isinstance(contexts[i], cl.Context) and \
               contexts[i].devices[0].platform.name == backend[0].name and \
               contexts[i].devices[0].name == backend[1].name:
                return contexts[i], i
        # If not create a new cl.Context.
        contexts.append(cl.Context(devices=[backend[1]]))
        return contexts[len(contexts) - 1], len(contexts) - 1
    elif cl is not None and (
            backend == (None, None) or
            backend == (None, 'cpu') or
            backend == (None, 'gpu')
    ):
        # Do we already have a cl.Context ?
        for i in range(len(contexts)):
            if isinstance(contexts[i], cl.Context):
                # OpenCL and fp support.
                if _fp_support(contexts[i].devices[0].platform,
                               contexts[i].devices[0],
                               dtype)[0]:
                    return contexts[i], i
        # If not create a new cl.Context.
        n_devices, no_fp_support = 0, False
        platforms = cl.get_platforms()
        for platform in platforms:
            # OpenCL and fp support.
            devices = platform.get_devices(
                device_type=(
                    cl.device_type.GPU if backend[1] == 'gpu' else
                    cl.device_type.CPU))
            if len(devices) == 0:
                continue
            n_devices += len(devices)
            # Use the first device.
            if not _fp_support(platform, devices[0], dtype)[0]:
                no_fp_support = True
                continue
            contexts.append(cl.Context(devices=[devices[0]]))
            return contexts[len(contexts) - 1], len(contexts) - 1
        if no_fp_support:
            raise RuntimeError(f"{backend} does not support {dtype}.")
        if n_devices == 0:
            raise Exception("No device found.")
    elif cuda is not None and isinstance(backend, cuda.Device):
        # Do we already have a cuda.Context ?
        for i in range(len(contexts)):
            if (
                    isinstance(contexts[i], cuda.Context) and
                    contexts[i].get_device().name() == backend.name()
            ):
                # Push it at the top of the stack ?
                # PyCUDA ERROR: The context stack
                # was not empty upon module cleanup.
                contexts[i].push()
                return contexts[i], i
        # If not create a new cuda.Context.
        contexts.append(backend.make_context())
        return contexts[len(contexts) - 1], len(contexts) - 1
    elif (
            cuda is not None and
            isinstance(backend, str) and 'cuda' in backend
    ):
        # Do we already have a cuda.Context ?
        for i in range(len(contexts)):
            if isinstance(contexts[i], cuda.Context):
                # Push it at the top of the stack?
                # PyCUDA ERROR: The context stack
                # was not empty upon module cleanup.
                contexts[i].push()
                return contexts[i], i
        # If not create a new cuda.Context.
        for i in range(cuda.Device.count()):
            try:
                contexts.append(cuda.Device(i).make_context())
                return contexts[len(contexts) - 1], len(contexts) - 1
            except _cuda.LogicError:
                pass
    elif backend in ('cupy', 'ksmm', 'numpy',
                     'pytorch', 'scipy', 'xp'):
        # backend does not need context.
        # CuPy/PyTorch get device from ks_values.
        return None, -1
    else:
        raise Exception("backend not found.")


def _multiple_ksm(ks_values: list,
                  params: list = None, backend=(None, 'cpu'),
                  perm: bool = False, params_perm: tuple = None):
    """
    pyopencl and pycuda versions of ``multiple_ksm()``.
    """

    n_factors = len(ks_values)
    dtype = ks_values[0].dtype
    device = ks_values[0].device
    for i in range(1, n_factors):
        if dtype != ks_values[i].dtype:
            raise TypeError("All elements of ks_values" +
                            " must have the same dtype.")
        if device != ks_values[i].device:
            raise TypeError("All elements of ks_values" +
                            " must have the same device.")

    # params must be a list of tuples or None.
    if isinstance(params, list):
        if len(params) != n_factors:
            raise Exception(
                "Length of params and length of ks_values must be equal.")
        for p in params:
            if not isinstance(p, tuple) or (
                    isinstance(p, tuple) and not len(p) == 2):
                raise Exception(
                    "params must be a list of tuples or None.")
    elif params is None:
        pass
    else:
        raise Exception(
            "params must be a list of tuples or None.")

    _msg = "Namespace, device and backend are not compatibles."
    _device = ks_values[0].device
    if is_torch_array(ks_values[0]) and _device.type == "cpu":
        if backend == "ksmm":
            raise Exception("ksmm backend does not work" +
                            " with torch tensors that are on cpu.")
        _dtype = torch.randn(2).to(
            dtype=ks_values[0].dtype).numpy().dtype
        context, context_idx = _context(backend, _dtype)
        is_opencl, is_cuda = True, False
    elif is_torch_array(ks_values[0]) and _device.type == "cuda":
        if backend == "ksmm" and not torch.cuda.is_bf16_supported(
                including_emulation=False) and ks_values[0].dtype == torch.bfloat16:
            raise Exception("device does not support bfloat16.")
        if backend != "ksmm":
            raise Exception("ks_values that are torch tensors on cuda" +
                            " devices only work with ksmm backend.")
        context, context_idx = None, -1
        is_opencl, is_cuda = False, False
    elif is_cupy_array(ks_values[0]):
        if backend != "ksmm":
            raise Exception("ks_values that are CuPy arrays only" +
                            " work with ksmm backend.")
        context, context_idx = None, -1
        is_opencl, is_cuda = False, False
    elif is_numpy_array(ks_values[0]):
        context, context_idx = _context(backend, ks_values[0].dtype)
        is_opencl = isinstance(context, cl.Context)
        is_cuda = not is_opencl
    else:
        raise Exception(_msg)

    # Use this instance to keep track of the last batch size.
    # If batch size changes, we need to compute new hyper-parameters.
    ksm_data = Ksm_data()

    if is_opencl:
        # Create command queue
        queue = cl.CommandQueue(
            context,
            properties=cl.command_queue_properties.PROFILING_ENABLE)

    # Input and output sizes.
    a, b, c, d = ks_values[n_factors - 1].shape
    input_size = a * c * d
    a, b, c, d = ks_values[0].shape
    output_size = a * b * d

    # Sanity check of ks_values.
    _check_ks_values(ks_values, backend)

    # Device pointers of the Kronecker-Sparse values.
    patterns = []
    d_values, d_rvalues, = [None] * n_factors, [None] * n_factors
    # Array namespace of ks_values.
    xp = array_namespace(ks_values[0])
    # Does it use Hadamard specialized kernel?
    hadamard = True
    for f in range(n_factors):
        if (
                "int8" not in str(ks_values[f].dtype) and
                "int16" not in str(ks_values[f].dtype) and
                "int32" not in str(ks_values[f].dtype)
        ):
            hadamard = False
            break
        a, b, c, d = ks_values[f].shape
        if xp.sum(xp.abs(ks_values[f])) != a * b * c * d:
            hadamard = False
            break
    # Transform ks_values from 4D to 2d array once and for all.
    for f in range(n_factors):
        if len(ks_values[f].shape) != 4:
            raise Exception("Element of ks_values must be a" +
                            " either a 4d NumPy or CuPy array" +
                            " or a torch tensor.")
        a, b, c, d = ks_values[f].shape
        patterns.append((a, b, c, d))
        if is_torch_array(ks_values[f]):
            if ks_values[f].device.type == 'cpu':
                values = np.from_dlpack(
                    xp.swapaxes(ks_values[f], 2, 3).reshape(
                        a * d * b, c).contiguous())
            elif ks_values[f].device.type == 'cuda':
                d_values[f] = ks_values[f].permute(
                    0, 1, 3, 2).reshape(a * d * b, c).contiguous()
        elif is_cupy_array(ks_values[f]):
            # CuPy array is already on the device.
            d_values[f] = xp.ascontiguousarray(
                xp.swapaxes(
                    ks_values[f], 2, 3).reshape(a * d * b, c))
        elif is_numpy_array(ks_values[f]):
            values = xp.ascontiguousarray(
                xp.swapaxes(ks_values[f], 2, 3).reshape(a * d * b, c))
        # Host to device.
        if is_opencl:
            d_values[f] = cl.Buffer(
                context,
                cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
                hostbuf=values)
        elif is_cuda:
            d_values[f] = cuda.mem_alloc(values.nbytes)
            cuda.memcpy_htod(d_values[f], values)
            context.synchronize()

        # Transform acbd from 4D to 2d array once and for all.
        # The transpose of the support I_a\otimes 1_{b,c}\otimes I_d
        # is given by I_a\otimes 1_{c,b}\otimes I_d.
        a, b, c, d = ks_values[f].shape
        if is_torch_array(ks_values[f]):
            acbd = xp.conj(ks_values[f]).permute(0, 2, 1, 3)
            if ks_values[f].device.type == 'cpu':
                acbd = xp.swapaxes(xp.conj(ks_values[f]), 1, 2)
                rvalues = np.from_dlpack(
                    xp.swapaxes(acbd, 2, 3).reshape(
                        a * d * c, b).contiguous())
            elif ks_values[f].device.type == 'cuda':
                d_rvalues[f] = acbd.permute(
                    0, 1, 3, 2).reshape(a * d * c, b).contiguous()
        elif is_cupy_array(ks_values[f]):
            # CuPy array is already on the device.
            acbd = xp.swapaxes(xp.conjugate(ks_values[f]), 1, 2)
            d_rvalues[f] = xp.ascontiguousarray(
                xp.swapaxes(
                    acbd, 2, 3).reshape(a * d * c, b))
        elif is_numpy_array(ks_values[f]):
            acbd = xp.swapaxes(xp.conjugate(ks_values[f]), 1, 2)
            rvalues = xp.ascontiguousarray(
                xp.swapaxes(acbd, 2, 3).reshape(a * d * c, b))
        # Host to device.
        if is_opencl:
            d_rvalues[f] = cl.Buffer(
                context,
                cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
                hostbuf=rvalues)
        elif is_cuda:
            d_rvalues[f] = cuda.mem_alloc(rvalues.nbytes)
            cuda.memcpy_htod(d_rvalues[f], rvalues)
            context.synchronize()

    if perm:
        _device = ks_values[0].device
        if is_torch_array(ks_values[0]) and _device.type == 'cpu':
            bitrev_idx = np.from_dlpack(
                bitrev(input_size) @ xp.arange(
                    input_size, dtype=xp.int32, device=_device))
            rbitrev_idx = np.from_dlpack(
                bitrev(output_size) @ xp.arange(
                    output_size, dtype=xp.int32, device=_device))
        elif is_cupy_array(ks_values[0]) or (
                is_torch_array(ks_values[0]) and _device.type == 'cuda'):
            dp_bitrev_idx = bitrev(input_size) @ xp.arange(
                input_size, dtype=xp.int32, device=_device)
            dp_rbitrev_idx = bitrev(output_size) @ xp.arange(
                output_size, dtype=xp.int32, device=_device)
        elif is_numpy_array(ks_values[0]):
            bitrev_idx = bitrev(input_size) @ xp.arange(
                input_size, dtype='int32', device=_device)
            rbitrev_idx = bitrev(output_size) @ xp.arange(
                output_size, dtype='int32', device=_device)
        # Use bit-reversal permutation for DFT.
        if is_opencl:
            dp_bitrev_idx = cl.Buffer(
                context,
                cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
                hostbuf=bitrev_idx)
            dp_rbitrev_idx = cl.Buffer(
                context,
                cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
                hostbuf=rbitrev_idx)
        elif is_cuda:
            dp_bitrev_idx = cuda.mem_alloc(bitrev_idx.nbytes)
            cuda.memcpy_htod(dp_bitrev_idx, bitrev_idx)
            dp_rbitrev_idx = cuda.mem_alloc(rbitrev_idx.nbytes)
            cuda.memcpy_htod(dp_rbitrev_idx, rbitrev_idx)
            context.synchronize()
    else:
        dp_bitrev_idx, dp_rbitrev_idx = None, None

    if is_opencl or is_cuda:
        ksm_data.ksv_dev_ptr = [None] * (2 * n_factors)
        for f in range(n_factors):
            ksm_data.ksv_dev_ptr[f] = d_values[f]
            ksm_data.ksv_dev_ptr[n_factors + f] = d_rvalues[f]
        if perm:
            ksm_data.ksv_dev_ptr.append(dp_bitrev_idx)
            ksm_data.ksv_dev_ptr.append(dp_rbitrev_idx)
    else:
        # CuPy arrays are already on the device.
        pass

    # Shared memory and grid/block sizes.
    if is_opencl:
        dev = context.devices[0]
    elif is_cuda:
        dev = context.get_device()
    else:
        dev = ks_values[0].device
    smem, max_work_group_size, max_block_dim, max_grid_dim = _get_info_dim(dev)

    def _kx(x, patterns, buf_val, context, adjoint,
            perm: bool = False, dp_perm=None):

        _ist = is_torch_array(ks_values[0])
        _isc = is_cupy_array(ks_values[0])

        if hadamard and (is_opencl or is_cuda):
            _support, _msg = _fp_support(
                context.devices[0].platform, context.devices[0], x.dtype)
            if not _support:
                raise Exception(_msg)

        # To keep track of the kernel duration.
        ksm_data.duration["ksmm"] = [0.0] * n_factors
        ksm_data.duration["perm"] = 0.0
        ksm_data.duration["copy"] = 0.0

        if is_cuda:
            # CUDA event to measure kernel execution time.
            start, end = cuda.Event(), cuda.Event()
            context.push()
        if cp is not None and _isc:
            # CuPy CUDA event to measure kernel execution time.
            start, end = cp.cuda.Event(), cp.cuda.Event()
        if torch is not None and _ist and ks_values[0].device.type == "cuda":
            start = torch.Event(enable_timing=True)
            end = torch.Event(enable_timing=True)

        if ksm_data.batch_size is None or ksm_data.batch_size != x.shape[1]:
            # Because of new batch size, reset data.
            # batch_size = None corresponds to the first call.
            new_batch_size = True
            ksm_data.batch_size = x.shape[1]
            ksm_data.hp = [None] * n_factors
            ksm_data.rhp = [None] * n_factors
            ksm_data.program = [None] * n_factors
            ksm_data.rprogram = [None] * n_factors
            if is_opencl:
                ksm_data.cl_kernel = [None] * n_factors
            if perm:
                ksm_data.pbx = None
                ksm_data.pby = None
                ksm_data.b_program = None
            ksm_data.last_call = None
        else:
            new_batch_size = False

        batch_size = x.shape[1]

        # Max output size.
        max_out_size = 0
        for i in range(n_factors):
            a, b, c, d = patterns[i]
            max_out_size = max(max_out_size,
                               a * c * d if adjoint else a * b * d)

        _store = new_batch_size or ksm_data.last_call is None or (
            adjoint and ksm_data.last_call == "matmat") or (
            not adjoint and ksm_data.last_call == "rmatmat")

        # Output array.
        # Dimensions only change when the batch size changes
        # or when we switch from matmat to rmatmat.
        _dtype = x.dtype if hadamard else ks_values[0].dtype
        if _ist and ks_values[0].device.type == "cpu":
            # Convert the output to torch tensor later on.
            t0 = time.time()
            _dtype = torch.randn(2).to(
                device='cpu',
                dtype=x.dtype if hadamard else ks_values[0].dtype,
            ).numpy().dtype
            y = np.empty((max_out_size, batch_size), dtype=_dtype)
            ksm_data.duration["copy"] += time.time() - t0
        elif _isc or (
                _ist and ks_values[0].device.type == "cuda"):
            start.record()
            y = xp.empty((max_out_size, batch_size),
                         dtype=_dtype,
                         device=ks_values[0].device)
            end.record()
            end.synchronize()
            if _ist:
                ksm_data.duration[
                    "copy"] += 1e-3 * start.elapsed_time(end)
            else:
                ksm_data.duration[
                    "copy"] += 1e-3 * cp.cuda.get_elapsed_time(
                        start, end)
        elif is_numpy_array(ks_values[0]):
            t0 = time.time()
            y = xp.empty((max_out_size, batch_size),
                         dtype=_dtype,
                         device=ks_values[0].device)
            ksm_data.duration["copy"] += time.time() - t0
        else:
            y = None

        # Loop over the factors (from right to left).
        _n_matmul = n_factors + int(perm)
        dp, read, store = [None] * 3, 0, 1
        first_call = True
        for i in range(n_factors - 1, -1, -1):
            current_dtype = x.dtype if first_call else y.dtype
            idx = n_factors - 1 - i if adjoint else i
            # Allow complex ks-values and real input.
            if (
                    'complex' in str(ks_values[idx].dtype) and
                    'complex' not in str(current_dtype) and
                    ks_values[idx].dtype == (1j * x).dtype
            ):
                # complex is two float/double.
                cplx_real = True
            else:
                cplx_real = False
            # Do not need to cast if hadamard because
            # ks_values are only -1 and 1.
            # Do not need to cast if complex ks-values and real input.
            if (
                    first_call and
                    ks_values[idx].dtype != current_dtype and
                    not hadamard and
                    not cplx_real
            ):
                x = xp.asarray(x, dtype=ks_values[idx].dtype)
                warn("Cast X to match the dtype of L.ks_values." +
                     " This can incur a loss of performance," +
                     " as-well-as a loss of precision if the dtype" +
                     " of X was initially of higher precision than" +
                     " that of L.ks_values.")
            _is_cupy_array = is_cupy_array(ks_values[idx])
            _is_torch_array = is_torch_array(ks_values[idx])
            a, b, c, d = patterns[idx]
            if new_batch_size:
                # Because of new batch size ...
                hp, rhp, knl, rknl = _modify_template(
                    a, b, c, d, x.shape[1],
                    (ks_values[idx].dtype, current_dtype),
                    smem, max_block_dim, max_grid_dim, max_work_group_size,
                    (None, None) if params is None else params[idx],
                    'clh' if is_opencl else 'cuh', hadamard)
                ksm_data.hp[idx] = hp
                ksm_data.rhp[idx] = rhp
                kernel = ''.join(knl)
                rkernel = ''.join(rknl)
                if perm:
                    # Read bit-reversal permutation kernel.
                    # Bit-reversal permutation matrix is its own transpose.
                    pbx, pby, pvsize, knl = _modify_template_bitrev_perm(
                        x.shape[0], x.shape[1],
                        ks_values[idx].dtype,
                        smem, max_block_dim, max_grid_dim,
                        max_work_group_size, params_perm,
                        'clh' if is_opencl else 'cuh')
                    ksm_data.pbx = pbx
                    ksm_data.pby = pby
                    ksm_data.pvsize = pvsize
                    b_kernel = ''.join(knl)

                # Compile kernels (L and L.H).
                if is_opencl:
                    program = cl.Program(context, kernel).build()
                    rprogram = cl.Program(context, rkernel).build()
                elif is_cuda:
                    # Because of overloading function no_extern_c=True.
                    # Use extern "C" { __global__ void ksmm(...) {...} }.
                    program = SourceModule(kernel, no_extern_c=True)
                    rprogram = SourceModule(rkernel, no_extern_c=True)
                elif _is_torch_array and ks_values[idx].device.type == "cuda":
                    prefix = "hadamard_" if hadamard else ""
                    with open(
                            Path(__file__).parent.joinpath(
                                f"{prefix}interface.cpp"), "r") as finterface:
                        interface = ''.join(finterface.readlines())
                    cpp_sources = """
                    torch::Tensor forward(
                    uint gx,
                    uint gy,
                    uint gz,
                    uint bx,
                    uint by,
                    uint bz,
                    torch::Tensor values,
                    torch::Tensor input,
                    torch::Tensor output,
                    const int a,
                    const int b,
                    const int c,
                    const int d,
                    int batch_size);
                    """
                    program = load_inline(
                        name="ksmm",
                        cuda_sources=[kernel, interface],
                        cpp_sources=cpp_sources,
                        functions=["forward"],
                        verbose=True,
                        extra_cflags=["-g", "-O2"],
                        # extra_include_paths=["/usr/local/cuda/include"],
                        # build_directory="build/",
                    )
                    rprogram = load_inline(
                        name="ksmm",
                        cuda_sources=[rkernel, interface],
                        cpp_sources=cpp_sources,
                        functions=["forward"],
                        verbose=True,
                        extra_cflags=["-g", "-O2"],
                        # extra_include_paths=["/usr/local/cuda/include"],
                        # build_directory="build/",
                    )
                elif _is_cupy_array:
                    compiler = 'nvcc'
                    cpp = 11
                    options = []
                    for _c in ['03', '11', '12']:  # , '14', '17', '20']:
                        options.append(f"-I/usr/include/c++/{_c}")
                        options.append(
                            f"-I/usr/include/x86_64-linux-gnu/c++/{_c}")
                        if compiler == 'nvrtc':
                            options.append(f"-I/usr/include/c++/{_c}/tr1")
                    if compiler == 'nvrtc':
                        options.append("-I/usr/include/linux")
                    options.append(f"--std=c++{cpp}")
                    if compiler == 'nvcc':
                        options.append("--x=cu")
                    options = tuple(options)
                    # Prefer RawModule over RawKernel here.
                    program = cp.RawModule(
                        code=kernel, options=options,
                        backend=compiler,
                        translate_cucomplex=True).get_function('ksmm')
                    program.compile()
                    rprogram = cp.RawModule(
                        code=rkernel, options=options,
                        backend=compiler,
                        translate_cucomplex=True).get_function('ksmm')
                    rprogram.compile()
                if perm:
                    if is_opencl:
                        b_program = cl.Program(context, b_kernel).build()
                    elif is_cuda:
                        b_program = SourceModule(b_kernel, no_extern_c=True)
                    elif _is_torch_array and ks_values[idx].device.type == "cuda":
                        with open(
                            Path(__file__).parent.joinpath(
                                "bitrev_interface.cpp"), "r") as finterface:
                            interface = ''.join(finterface.readlines())
                        cpp_sources = """
                        torch::Tensor forward(
                        uint gx,
                        uint gy,
                        uint gz,
                        uint bx,
                        uint by,
                        uint bz,
                        torch::Tensor values,
                        torch::Tensor input,
                        torch::Tensor output,
                        int batch_size);
                        """
                        b_program = load_inline(
                            name="bitrev_perm",
                            cuda_sources=[b_kernel, interface],
                            cpp_sources=cpp_sources,
                            functions="forward",
                            verbose=True,
                            extra_cflags=["-g", "-O2"],
                            # build_directory="build/",
                        )
                    else:
                        # Prefer RawModule over RawKernel here.
                        b_program = cp.RawModule(
                            code=b_kernel,
                            options=options,
                            backend=compiler,
                            translate_cucomplex=True,
                        ).get_function('bitrev_perm')
                        b_program.compile()
                    ksm_data.b_program = b_program
                    if is_opencl:
                        ksm_data.cl_kernel_perm = cl.Kernel(b_program, 'bitrev_perm')
                # Store data.
                ksm_data.program[idx] = program
                ksm_data.rprogram[idx] = rprogram
                if is_opencl:
                    ksm_data.cl_kernel[idx] = {"m": cl.Kernel(program, 'ksmm'),
                                               "r": cl.Kernel(rprogram, 'ksmm')}
            else:
                # Read data for L and L.H.
                hp = ksm_data.hp[idx]
                rhp = ksm_data.rhp[idx]
                program = ksm_data.program[idx]
                rprogram = ksm_data.rprogram[idx]
                if perm:
                    pbx = ksm_data.pbx
                    pby = ksm_data.pby
                    pvsize = ksm_data.pvsize
                    b_program = ksm_data.b_program

            # Define the grid.
            if adjoint:
                out_size = a * c * d
                _hp = rhp
            else:
                out_size = a * b * d
                _hp = hp
            ntx, nty = _hp[10], _hp[11]
            if is_opencl:
                local_work_size = (ntx, nty)
                global_work_size = (
                    ((batch_size + _hp[0] - 1) // _hp[0]) * ntx,
                    ((out_size + _hp[2] - 1) // _hp[2]) * nty)
                if perm:
                    bblock = (pbx, pby, 1)
                    bgrid = (((x.shape[1] + pvsize * pbx - 1)
                              // (pvsize * pbx)) * pbx,
                             ((x.shape[0] + pby - 1) // pby) * pby, 1)
            else:
                block = (ntx, nty, 1)
                grid = ((batch_size + _hp[0] - 1) // _hp[0],
                        (out_size + _hp[2] - 1) // _hp[2], 1)
                if perm:
                    bblock = (pbx, pby, 1)
                    bgrid = ((x.shape[1] + pbx * pvsize - 1)
                             // (pbx * pvsize),
                             (x.shape[0] + pby - 1) // pby, 1)

            # print("local work size",
            #       local_work_size if is_opencl else block)
            # print("global work size",
            #       global_work_size if is_opencl else grid)

            # The kernel computes K @ X where the input K and X
            # are in row-major format.
            # The output y of the computation is in row-major format.
            # Host to device.
            if first_call:
                if is_torch_array(x):
                    _contiguous = x.is_contiguous()
                    _x = x if _contiguous else x.contiguous()
                else:
                    _contiguous = x.flags['C_CONTIGUOUS']
                    _x = x if _contiguous else xp.ascontiguousarray(x)
                if not _contiguous:
                    warn("Cast X to be of C-contiguous type." +
                         " This can incur a loss of performance.")
            else:
                _x = None
            msg_event = "OpenCL command execution status is not complete."
            complete = cl.command_execution_status.COMPLETE
            if i == (n_factors - 1):
                # Multiply most right factor with x.
                if is_opencl:
                    if _store and hasattr(dp[0], "release"):
                        # Clean last computation.
                        dp[0].release()
                    if is_torch_array(x) and x.device.type == 'cpu':
                        if _store:
                            t0 = time.time()
                            dp[0] = cl.Buffer(
                                context,
                                cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
                                hostbuf=np.from_dlpack(_x))
                            # Store device pointer relative to x to avoid
                            # creation at each L @ x computation.
                            if adjoint:
                                ksm_data.rdev_ptr[0] = dp[0]
                            else:
                                ksm_data.dev_ptr[0] = dp[0]
                            ksm_data.duration[
                                "copy"] += time.time() - t0
                        else:
                            if adjoint:
                                dp[0] = ksm_data.rdev_ptr[0]
                            else:
                                dp[0] = ksm_data.dev_ptr[0]
                            event = cl.enqueue_copy(
                                queue, dp[0], np.from_dlpack(_x))
                            event.wait()
                            if event.command_execution_status != complete:
                                raise Exception(msg_event)
                            ksm_data.duration["copy"] += 1e-9 * (
                                event.profile.end - event.profile.start)
                    elif is_numpy_array(x):
                        if _store:
                            t0 = time.time()
                            dp[0] = cl.Buffer(
                                context,
                                cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR,
                                hostbuf=_x)
                            # Store device pointer relative to x to avoid
                            # creation at each L @ x computation.
                            if adjoint:
                                ksm_data.rdev_ptr[0] = dp[0]
                            else:
                                ksm_data.dev_ptr[0] = dp[0]
                            ksm_data.duration[
                                "copy"] += time.time() - t0
                        else:
                            if adjoint:
                                dp[0] = ksm_data.rdev_ptr[0]
                            else:
                                dp[0] = ksm_data.dev_ptr[0]
                            event = cl.enqueue_copy(queue, dp[0], _x)
                            event.wait()
                            if event.command_execution_status != complete:
                                raise Exception(msg_event)
                            ksm_data.duration["copy"] += 1e-9 * (
                                event.profile.end - event.profile.start)
                elif is_cuda:
                    start.record()
                    if _store:
                        if hasattr(dp[0], "free"):
                            dp[0].free()
                            context.synchronize()
                        dp[0] = cuda.mem_alloc(x.nbytes)
                        # Store device pointer relative to x to avoid
                        # creation at each L @ x computation.
                        if adjoint:
                            ksm_data.rdev_ptr[0] = dp[0]
                        else:
                            ksm_data.dev_ptr[0] = dp[0]
                    else:
                        if adjoint:
                            dp[0] = ksm_data.rdev_ptr[0]
                        else:
                            dp[0] = ksm_data.dev_ptr[0]
                    cuda.memcpy_htod(dp[0], _x)
                    end.record()
                    end.synchronize()
                    ksm_data.duration[
                        "copy"] = 1e-3 * end.time_since(start)
                elif is_cupy_array(x):
                    # CuPy array is already on the device.
                    pass
                elif is_torch_array(x) and x.device.type == 'cuda':
                    # torch tensor is already on the device.
                    pass
                # Device pointers relative to intermediate output.
                _n_buf = None
                if is_opencl and _store:
                    # No need of intermediate output if only one ks_values.
                    t0 = time.time()
                    _n_buf = 2 if (n_factors > 1 or perm) else 1
                    for j in range(_n_buf):
                        dp[1 + j] = cl.Buffer(
                            context, cl.mem_flags.READ_WRITE, y.nbytes)
                    ksm_data.duration["copy"] += time.time() - t0
                elif is_cuda and _store:
                    # No need of intermediate output if only one ks_values.
                    start.record()
                    _n_buf = 2 if (n_factors > 1 or perm) else 1
                    for j in range(_n_buf):
                        dp[1 + j] = cuda.mem_alloc(y.nbytes)
                    end.record()
                    end.synchronize()
                    ksm_data.duration[
                        "copy"] = 1e-3 * end.time_since(start)
                elif ((is_torch_array(x) and x.device.type == "cuda") or
                      is_cupy_array(x)) and _store:
                    if n_factors == 1 and not perm:
                        # No need of intermediate output if only one ks_values.
                        pass
                    else:
                        # Only one intermediate output otherwize.
                        start.record()
                        dp[1] = xp.empty((max_out_size, batch_size),
                                         dtype=y.dtype,
                                         device=ks_values[0].device)
                        end.record()
                        end.synchronize()
                        if is_cupy_array(x):
                            ksm_data.duration[
                                "copy"] += 1e-3 * cp.cuda.get_elapsed_time(start, end)
                        else:
                            ksm_data.duration[
                                "copy"] += 1e-3 * start.elapsed_time(end)
                if _store:
                    # Store device pointers relative to intermediate
                    # output to avoid creation at each L @ x computation.
                    if adjoint:
                        ksm_data.rdev_ptr[1:3] = dp[1:3]
                    else:
                        ksm_data.dev_ptr[1:3] = dp[1:3]
                else:
                    # Re-use device pointers.
                    if adjoint:
                        dp[1:3] = ksm_data.rdev_ptr[1:3]
                    else:
                        dp[1:3] = ksm_data.dev_ptr[1:3]
            # Run the kernel.
            bb = np.uint32(c if adjoint else b)
            cc = np.uint32(b if adjoint else c)
            if is_opencl:
                if perm and i == (n_factors - 1) and not adjoint:
                    # Apply bit-reversal permutation to x (right-most factor).
                    t0 = time.time()
                    knl = ksm_data.cl_kernel_perm
                    knl.set_args(dp_perm, dp[read], dp[store],
                                 np.uint32(batch_size))
                    ksm_data.duration["perm"] += time.time() - t0
                    # FIXME: do we use g_times_l (CUDA behavior)?
                    event = cl.enqueue_nd_range_kernel(
                        queue, knl, bgrid, bblock)
                    event.wait()
                    if event.command_execution_status != complete:
                        raise Exception(msg_complete)
                    ksm_data.duration["perm"] = 1e-9 * (
                        event.profile.end - event.profile.start)
                    read, store = 1, 2
                # Kronecker-sparse multiplication.
                t0 = time.time()
                if adjoint:
                    knl = ksm_data.cl_kernel[idx]["r"]
                else:
                    knl = ksm_data.cl_kernel[idx]["m"]
                knl.set_args(
                    buf_val[idx],
                    dp[read], dp[store],
                    np.uint32(a), bb, cc, np.uint32(d),
                    np.uint32(batch_size))
                ksm_data.duration["ksmm"][idx] += time.time() - t0
                event = cl.enqueue_nd_range_kernel(
                    queue, knl, global_work_size, local_work_size)
                event.wait()
                ksm_data.duration["ksmm"][idx] += 1e-9 * (
                    event.profile.end - event.profile.start)
                if event.command_execution_status != complete:
                    raise Exception(msg_event)
                if perm and i == 0 and adjoint:
                    # Apply bit-reversal permutation B to x.
                    # Because of adjoint, bit-reversal permutation
                    # is the left-most factor (B = B^T).
                    read, store = store, read
                    knl = ksm_data.cl_kernel_perm
                    t0 = time.time()
                    knl.set_args(dp_perm, dp[read], dp[store],
                                 np.uint32(batch_size))
                    ksm_data.duration["perm"] += time.time() - t0
                    event = cl.enqueue_nd_range_kernel(
                        queue, knl, bgrid, bblock)
                    event.wait()
                    if event.command_execution_status != complete:
                        raise Exception(msg_event)
                    ksm_data.duration["perm"] = 1e-9 * (
                        event.profile.end - event.profile.start)
            elif is_cuda:
                if perm and i == (n_factors - 1) and not adjoint:
                    # Apply bit-reversal permutation to x (right-most factor).
                    knl = b_program.get_function('bitrev_perm')
                    start.record()
                    knl(dp_perm, dp[read], dp[store],
                        np.uint32(batch_size),
                        block=bblock, grid=bgrid)
                    context.synchronize()
                    end.record()
                    end.synchronize()
                    ksm_data.duration[
                        "perm"] = 1e-3 * end.time_since(start)
                    read, store = 1, 2
                # Kronecker-sparse multiplication.
                knl = (rprogram if adjoint else program).get_function('ksmm')
                start.record()
                # No extern shared memory,
                # therefore do not use shared argument.
                knl(buf_val[idx],
                    dp[read], dp[store],
                    np.uint32(a), bb, cc, np.uint32(d),
                    np.uint32(batch_size),
                    block=block,
                    grid=grid)
                context.synchronize()
                end.record()
                end.synchronize()
                ksm_data.duration[
                    "ksmm"][idx] = 1e-3 * end.time_since(start)
                if perm and i == 0 and adjoint:
                    # Apply bit-reversal permutation to x.
                    # Because of adjoint, bit-reversal permutation
                    # is the left-most factor.
                    read, store = store, read
                    knl = b_program.get_function('bitrev_perm')
                    start.record()
                    knl(dp_perm, dp[read], dp[store],
                        np.uint32(batch_size),
                        block=bblock, grid=bgrid)
                    context.synchronize()
                    end.record()
                    end.synchronize()
                    ksm_data.duration[
                        "perm"] = 1e-3 * end.time_since(start)
            elif _is_cupy_array or (
                    _is_torch_array and x.device.type == "cuda"):
                if perm and i == (n_factors - 1) and not adjoint:
                    # Apply bit-reversal permutation to x (right-most factor).
                    start.record()
                    if _is_torch_array:
                        if _n_matmul % 2 == 1:
                            y = b_program.forward(
                                *bgrid, *bblock, dp_perm, _x, y, batch_size)
                        else:
                            dp[1] = b_program.forward(
                                *bgrid, *bblock, dp_perm, _x, dp[1], batch_size)
                    else:
                        b_program(bgrid, bblock,
                                  (dp_perm, _x,
                                   y if _n_matmul % 2 == 1 else dp[1], batch_size))
                    end.record()
                    end.synchronize()
                    if _is_torch_array:
                        ksm_data.duration[
                            "perm"] = 1e-3 * start.elapsed_time(end)
                    else:
                        ksm_data.duration[
                            "perm"] = 1e-3 * cp.cuda.get_elapsed_time(start, end)
                    _n_matmul -= 1
                # Kronecker-sparse multiplication.
                if _is_torch_array:
                    knl = rprogram.forward if adjoint else program.forward
                else:
                    knl = rprogram if adjoint else program
                start.record()
                if _n_matmul == (n_factors + int(perm)):
                    x_ptr = _x
                else:
                    x_ptr = dp[1] if _n_matmul % 2 == 1 else y
                if _is_torch_array:
                    if _n_matmul % 2 == 1:
                        y = knl(*grid, *block, buf_val[idx], x_ptr, y,
                                a, bb, cc, d, batch_size)
                    else:
                        dp[1] = knl(*grid, *block, buf_val[idx], x_ptr, dp[1],
                                    a, bb, cc, d, batch_size)
                else:
                    knl(grid, block, (buf_val[idx], x_ptr,
                                      y if _n_matmul % 2 == 1 else dp[1],
                                      a, bb, cc, d, batch_size))
                _n_matmul -= 1
                end.record()
                end.synchronize()
                if _is_torch_array:
                    ksm_data.duration[
                        "ksmm"][idx] = 1e-3 * start.elapsed_time(end)
                else:
                    ksm_data.duration[
                        "ksmm"][idx] = 1e-3 * cp.cuda.get_elapsed_time(start, end)
                if perm and i == 0 and adjoint:
                    # Apply bit-reversal permutation to x.
                    # Because of adjoint, bit-reversal permutation
                    # is the left-most factor.
                    read, store = store, read
                    start.record()
                    if _is_torch_array:
                        y = b_program.forward(
                            *bgrid, *bblock, dp_perm, dp[1], y, batch_size)
                    else:
                        b_program(bgrid, bblock,
                                  (dp_perm, dp[1], y, batch_size))
                    end.record()
                    end.synchronize()
                    if _is_torch_array:
                        ksm_data.duration[
                            "perm"] = 1e-3 * start.elapsed_time(end)
                    else:
                        ksm_data.duration[
                            "perm"] = 1e-3 * cp.cuda.get_elapsed_time(start, end)
                if _is_cupy_array:
                    cp.cuda.Stream.null.synchronize()  # ???
            # Get the output after multiplication
            # with the most left factor.
            if i == 0:
                if is_opencl:
                    event = cl.enqueue_copy(queue, y, dp[store])
                    event.wait()
                    if event.command_execution_status != complete:
                        raise Exception(msg_event)
                    ksm_data.duration["copy"] += 1e-9 * (
                        event.profile.end - event.profile.start)
                    if is_torch_array(x) and x.device.type == "cpu":
                        t0 = time.time()
                        y = torch.from_dlpack(y)
                        ksm_data.duration["copy"] += time.time() - t0
                elif is_cuda:
                    start.record()
                    cuda.memcpy_dtoh(y, dp[store])
                    context.synchronize()
                    end.record()
                    end.synchronize()
                    ksm_data.duration[
                        "copy"] += 1e-3 * end.time_since(start)
                elif _is_cupy_array or _is_torch_array:
                    # CuPy or torch array result stays on the device.
                    pass
            else:
                if read == 0:
                    read, store = 1, 2
                else:
                    read, store = store, read
            first_call = False
        ksm_data.duration["all"] = sum(
            ksm_data.duration["ksmm"])
        ksm_data.duration["all"] += ksm_data.duration["perm"]
        ksm_data.duration["all"] += ksm_data.duration["copy"]
        ksm_data.last_call = "rmatmat" if adjoint else "matmat"
        if max_out_size == (input_size if adjoint else output_size):
            return y
        else:
            return y[:(input_size if adjoint else output_size), :]

    return (
        lambda x: _kx(x, patterns, d_values, context, False,
                      perm, dp_bitrev_idx),
        lambda x: _kx(x, patterns, d_rvalues, context, True,
                      perm, dp_rbitrev_idx),
        ksm_data,
    )


def _pre_ksm_xp(ks_values: list):
    """
    Pre-compute 4d arrays before running ksm.
    """

    K = len(ks_values)
    values, rvalues = [None] * K, [None] * K
    for k in range(K):
        xp = array_namespace(ks_values[k])
        if is_torch_array(ks_values[k]):
            values[k] = xp.einsum(
                "abcd->adbc", ks_values[k]).contiguous()
            # Transpose and conjugate ks_values.
            rvalues[k] = xp.einsum(
                "abcd->adbc",
                xp.conj(ks_values[k].swapaxes(1, 2))).contiguous()
        else:
            values[k] = xp.ascontiguousarray(
                xp.einsum("abcd->adbc", ks_values[k]))
            # Transpose and conjugate ks_values.
            rvalues[k] = xp.ascontiguousarray(
                xp.einsum("abcd->adbc",
                          xp.conj(ks_values[k].swapaxes(1, 2))))

    return values, rvalues


def _pre_ksm_cupyx(ks_values: list):
    """
    Pre-compute sparse arrays before running ksm.
    """

    from cupyx.scipy.sparse import csr_matrix

    # Pre-compute.
    K = len(ks_values)
    B, BH = [None] * K, [None] * K
    for k in range(K):
        v = ks_values[k]
        a, b, c, d = v.shape
        # Fill indices array.
        device = v.device
        cp.cuda.runtime.setDevice(device)
        indices = cp.empty(a * b * c * d, dtype='int')
        for r in range(a * b * d):
            # Index of the block.
            i = r // (b * d)
            # Row inside the block.
            _r = r - i * b * d
            indices[(r * c):((r + 1) * c)] = i * c * d + cp.arange(
                _r % d, c * d, d)
        indptr = cp.asarray([0] + [(i + 1) * c for i in range(a * b * d)])

        # Block-diagonal matrix with a block(s).
        values = cp.empty(a * b * c * d, dtype=v.dtype)
        for i in range(a):
            values[(i * b * c * d):((i + 1) * b * c * d)] = v[
                i].swapaxes(1, 2).reshape(b * d, c).ravel()
        B[k] = csr_matrix(
            (values, indices, indptr), shape=(a * b * d, a * c * d))
        # Adjoint of B[k].
        BH[k] = B[k].T.conj()

    return B, BH


def _pre_ksm_scipy(ks_values: list):
    """
    Pre-compute sparse arrays before running ksm.
    """

    from scipy.sparse import block_diag, csr_matrix

    # Pre-compute.
    K = len(ks_values)
    B, BH = [None] * K, [None] * K
    for k in range(K):
        v = ks_values[k]
        a, b, c, d = v.shape
        rows = np.arange(b * d)
        # Compute length of indices array.
        size = 0
        for i in rows:
            size += int(np.ceil((c * d - i % d) / d))
        # Fill indices array.
        indices = np.empty(size, dtype='int')
        cum = 0
        for i in rows:
            size = int(np.ceil((c * d - i % d) / d))
            indices[cum:(cum + size)] = np.arange(i % d, c * d, d)
            cum += size
        indptr = np.array([0] + [(i + 1) * c for i in range(b * d)])

        # Block-diagonal matrix with a block(s).
        B[k] = block_diag([
            csr_matrix(
                (
                    v[i].swapaxes(1, 2).reshape(b * d, c).ravel(),
                    indices,
                    indptr
                ), shape=(b * d, c * d)) for i in range(a)])
        # Adjoint of B[k].
        BH[k] = B[k].conj().T

    return B, BH


def _ksmm_xp(x, v, rmatmat=False):
    """
    Kronecker-Sparse Matrix Multiplication for backend='xp'.
    """
    # Swap axis before einsum.
    # Therefore, the following line of code
    # is ok for both matmat and rmatmat.
    a, d, b, c = v.shape

    if x.ndim == 1:
        x = x.reshape(-1, 1)
    B = x.shape[1]
    # Avoid following error:
    # RuntimeError: "mul_cpu_reduced_float" not implemented for 'Float8_e5m2'
    dtype = (v[0, 0, 0, :] @ x[:c, 0].reshape(-1, 1)).dtype

    if a == 1 and d == 1:
        return v[0, 0, :, :] @ x
    elif a == 1:
        x = x.reshape(c, d, B)  # return a view or a copy
        x = x.swapaxes(0, 1)  # return a view
        if "float8" in str(dtype):
            # NotImplementedError: "bmm" not implemented for 'Float8_e4m3fn'
            # NotImplementedError: "baddbmm_with_gemm" not implemented for 'Float8_e5m2'
            o = xp.empty((d, b, B), dtype=dtype,
                         device=ks_values.device)
            for i_d in range(d):
                o[i_d, :, :] = v[0, i_d, :, :] @ x[i_d, :, :]
        else:
            o = v[0, :, :, :] @ x  # shape is (d, b, B)
        o1 = o.swapaxes(0, 1)  # return a view
        return o1.reshape(-1, B)  # return a view (d=1) or a copy (d>1)
    elif d == 1:
        x = x.reshape(a, c, B)  # return a view or a copy
        if "float8" in str(dtype):
            # NotImplementedError: "bmm" not implemented for 'Float8_e4m3fn'
            # NotImplementedError: "baddbmm_with_gemm" not implemented for 'Float8_e5m2'
            o = xp.empty((a, b, B), dtype=dtype,
                         device=ks_values.device)
            for i_a in range(a):
                o[i_a, :, :] = v[i_a, 0, :, :] @ x[i_a, :, :]
        else:
            o = v[:, 0, :, :] @ x  # shape is (a, b, B)
        return o.reshape(-1, B)  # return a view
    else:
        x = x.reshape(a, c, d, B)  # return a view or a copy
        x = x.swapaxes(1, 2)  # return a view
        if "float8" in str(dtype):
            o = xp.empty((a, d, b, B), dtype=dtype,
                         device=ks_values.device)
        else:
            o = None
        # Change loop order if d < a.
        if d < a and "float8" in str(dtype):
            # NotImplementedError: "bmm" not implemented for 'Float8_e4m3fn'
            # NotImplementedError: "baddbmm_with_gemm" not implemented for 'Float8_e5m2'
            for i_d in range(d):
                xd = x[:, i_d, :, :]  # shape is (a, c, B)
                vd = v[:, i_d, :, :]  # shape is (a, b, c)
                od = o[:, i_d, :, :]  # shape is (a, b, B)
                for i_a in range(a):
                    xi = xd[i_a, :, :]  # shape is (c, B)
                    vi = vd[i_a, :, :]  # shape is (b, c)
                    od[i_a] = vi @ xi  # shape is (b, B)
        elif a < d and "float8" in str(dtype):
            # NotImplementedError: "bmm" not implemented for 'Float8_e4m3fn'
            # NotImplementedError: "baddbmm_with_gemm" not implemented for 'Float8_e5m2'
            for i_a in range(a):
                xa = x[i_a, :, :, :]  # shape is (d, c, B)
                va = v[i_a, :, :, :]  # shape is (d, b, c)
                oa = o[i_a, :, :, :]  # shape is (d, b, B)
                for i_d in range(d):
                    xi = xa[i_d, :, :]  # shape is (c, B)
                    vi = va[i_d, :, :]  # shape is (b, c)
                    oa[i_d] = vi @ xi  # shape is (b, B)
        else:
            o = v @ x
        o1 = o.swapaxes(1, 2)  # return a view
        return o1.reshape(-1, B)  # return a view (d=1) or a copy (d>1)


def _ksmm(x, backend: str,
          v: list, rv: list,
          rmatmat: bool = False):
    y = x
    if rmatmat:
        K = len(rv)
        if backend == "xp":
            for k in range(K):
                y = _ksmm_xp(y, rv[k], rmatmat)
        else:
            for k in range(K):
                y = rv[k] @ y
    else:
        K = len(v)
        if backend == "xp":
            for k in range(K - 1, - 1, -1):
                y = _ksmm_xp(y, v[k], rmatmat)
        else:
            for k in range(K - 1, -1, -1):
                y = v[k] @ y
    return y


def _ksm(ks_values: list, backend: str = 'xp'):
    """
    CuPy, NumPy and PyTorch version of ``ksm()``.
    """

    # Sanity check of ks_values.
    _check_ks_values(ks_values, backend)

    if backend == 'xp':
        v, rv = _pre_ksm_xp(ks_values)
    elif backend == 'cupyx':
        v, rv = _pre_ksm_cupyx(ks_values)
    elif backend == 'scipy':
        v, rv = _pre_ksm_scipy(ks_values)
    else:
        raise NotImplementedError("No torch sparse version yet.")

    return (
        lambda x: _ksmm(x, backend, v, None, False),
        lambda x: _ksmm(x, backend, None, rv, True),
    )


def plot(
        L,
        name: str = None,
        colormap: str = 'rainbow',
        log_scale: bool = True,
):
    """
    Plot ``L.ks_values`` on a logarithmic or linear scale.
    If ``ks_values`` is complex
    plot ``xp.sqrt(ks_values * xp.conj(ks_values))``.
    Matplotlib package must be installed.

    Args:
        L: :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            Plot ``L.ks_values`` on a logarithmic scale.
        name: ``str``
            Save the plot in both PNG file ``name + '.png'``
            and SVG file ``name + '.svg'`` and show the figure.
            Default value (``None``) only returns a tuple
            ``(fig, ax)`` for further manipulations of the plot.
        colormap: ``str``, optional
            Use Matplotlib colormap.
            See `colormaps documentation <https://matplotlib.org/
            stable/users/explain/colors/colormaps.html>`_
            for more details.
        log_scale: ``bool``, optional
            - ``True``: plot ks_values on a logarithmic scale
              (default value).
            - ``False``: plot ks_values on a linear scale.

    Returns:
        If ``name`` is a ``str``, save, show and return ``(None, None)``,
        otherwize return ``(fig, ax)`` corresponding to the plot
        of ``L.ks_values`` where ``fig`` is the
        ``matplotlib.figure.Figure`` instance and ``ax``
        is the ``matplotlib.axes.Axes`` instance corresponding
        to the plot of the *ks-values*.

    Examples:
        >>> from lazylinop.butterfly import dft
        >>> from lazylinop.butterfly import plot
        >>> import matplotlib.image as mpl_img
        >>> import matplotlib.pyplot as plt
        >>> L = dft(16)
        >>> # Get fig and ax of the plot.
        >>> fig, ax = plot(L)
        >>> axs = fig.get_axes()
        >>> axs[0].set_ylim(4, 12)
        (4.0, 12.0)
        >>> fig.savefig("my_dft.png")
        >>> fig.clf()
        >>> plt.close("my_dft")
        >>> # Save the plot option.
        >>> fig, ax = plot(L, name="my_dft")
        >>> fig is None and ax is None
        True
        >>> img = mpl_img.imread("my_dft.png", format='png')
        >>> _ = plt.imshow(img)
        >>> plt.show(block=True)
        >>> plt.close()
    """

    if not hasattr(L, "ks_values"):
        raise Exception("L does not have ks_values attribute," +
                        " do nothing.")

    xp = array_namespace(L.ks_values[0])

    import itertools
    try:
        import matplotlib as mpl
        import matplotlib.pyplot as plt
        from matplotlib.patches import Rectangle
        from matplotlib.collections import PatchCollection
    except ImportError:
        raise RuntimeError("plot() requires matplotlib package")

    plt.rcParams.update({"font.size": 16})
    plt.rcParams.update({"lines.linewidth": 8})
    plt.rcParams.update({"lines.markersize": 6})
    # plt.rcParams.update({"legend.fontsize": 4})

    cmap = plt.get_cmap(colormap)
    # cmap.set_under(color='white', alpha=0.0)

    n = len(L.ks_values)
    _device = L.ks_values[0].device
    s, t = n, 1
    X, Y = 0, 0
    min_ksv = xp.full(len(L.ks_values), 0.0, device=_device)
    max_ksv = xp.full(len(L.ks_values), 0.0, device=_device)
    for i, k in enumerate(L.ks_values):
        a, b, c, d = k.shape
        X += a * c * d + 1
        Y = max(Y, a * b * d)
        if 'complex' in str(k.dtype):
            min_ksv[i] = xp.min(xp.sqrt(xp.real(k * xp.conj(k))))
            max_ksv[i] = xp.max(xp.sqrt(xp.real(k * xp.conj(k))))
        else:
            min_ksv[i] = xp.min(k)
            max_ksv[i] = xp.max(k)
    # To avoid divide by zero.
    min_ksv = xp.min(min_ksv)
    max_ksv = xp.max(max_ksv)
    # Handle the case ks_values entries are all the same.
    if xp.absolute(max_ksv - min_ksv) < (
            10.0 * xp.finfo(max_ksv.dtype).eps):
        max_ksv = min_ksv
        norm = 1.0
    else:
        if log_scale:
            norm = xp.pow(xp.log2(max_ksv - min_ksv), -1)
        else:
            norm = xp.pow(max_ksv - min_ksv, -1)

    px = 1 / plt.rcParams['figure.dpi']
    # fig = plt.figure("draw", figsize=(640 * px, 480 * px))
    # plt.gca().set_aspect('equal')
    fig = plt.figure(name, figsize=(s * 250 * px, t * 250 * px))
    abox = [0.05, 0.01, 0.9, 0.98]
    ax = fig.add_axes(
        abox,
        xlabel="",
        ylabel="",
        title="",
        xlim=(0, X),
        ylim=(0, t * Y),
        xscale="linear",
        yscale="linear",
    )
    ax.set_aspect('equal')
    plt.axis('off')

    # Loop over the patterns.
    cum = 0
    for p in range(s):
        for q in range(t):
            if p * t + q >= n:
                break
            a, b, c, d = L.ks_values[p * t + q].shape
            x, y = a * c * d, a * b * d
            ax.text(cum + x, (t - q) * Y,
                    s=f"({a}, {b}, {c}, {d})", ha='right', va='top')
            ax.text(cum + x, (t - q) * Y - y,
                    s=f"({a * b * d}, {a * c * d})",
                    ha='right', va='bottom')
            # # Borders
            # pc = PatchCollection([Rectangle((cum, (t - q) * Y - y), x, y)],
            #                      facecolor='white',
            #                      alpha=1.0, edgecolor='black')
            # ax.add_collection(pc)
            # ks_values
            is_complex = 'complex' in str(L.ks_values[p * t + q].dtype)
            rs = [None] * (a * b * c * d)
            vs = xp.empty(a * b * c * d,
                          dtype=min_ksv.dtype, device=_device)
            nz = 0
            for i, j, k, l in itertools.product(
                    range(a), range(b), range(c), range(d)):
                row = i * b * d + j * d + l
                col = i * c * d + k * d + l
                idx = i * b * c * d + j * c * d + k * d + l
                v = L.ks_values[p * t + q][i, j, k, l]
                # https://numpy.org/doc/stable/reference/generated/numpy.finfo.html
                # if v >= 0 and v <= xp.finfo(v.dtype).eps:
                #     continue
                # if v < 0 and xp.abs(v) <= xp.finfo(v.dtype).epsneg:
                #     continue
                rs[nz] = Rectangle(
                    (cum + col, (t - q) * Y - row - 1), 1, 1)
                if is_complex:
                    v = xp.sqrt(xp.real(v * xp.conj(v)))
                if min_ksv == max_ksv:
                    vs[nz] = 0.5
                elif v <= min_ksv:
                    vs[nz] = 0.0
                elif v >= max_ksv:
                    vs[nz] = 1.0
                else:
                    if log_scale:
                        vs[nz] = xp.log2(v - min_ksv) * norm
                    else:
                        vs[nz] = (v - min_ksv) * norm
                nz += 1
            pc = PatchCollection(rs[:nz], fc=cmap(vs[:nz].tolist()), alpha=1.0)
            ax.add_collection(pc)
            # Borders
            pc = PatchCollection(
                [Rectangle((cum, (t - q) * Y - y), x, y)],
                fc=(1, 1, 1, 0), ec=(0, 0, 0, 1), linewidth=0.5)
            ax.add_collection(pc)
            cum += x + 1

    # Add colorbar.
    im_ratio = (t * Y) / X
    if log_scale:
        norm = mpl.colors.Normalize(
            vmin=0, vmax=xp.log2(max_ksv - min_ksv))
        fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap),
                     ax=ax, orientation='vertical',
                     label=r"$\log_2\left(v-v_{\text{min}}\right)$",
                     fraction=0.047 * im_ratio)
    else:
        norm = mpl.colors.Normalize(vmin=min_ksv, vmax=max_ksv)
        fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap),
                     ax=ax, orientation='vertical', label=r"$v$",
                     fraction=0.047 * im_ratio)

    ax.xaxis.set_visible(False)
    ax.yaxis.set_visible(False)
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    if isinstance(name, str):
        plt.savefig(f"{name}.png", dpi='figure',
                    transparent=True, bbox_inches='tight')
        plt.savefig(f"{name}.svg", dpi='figure',
                    transparent=True, bbox_inches='tight')
        plt.show(block=True)
        plt.close(name)
        return None, None
    else:
        return fig, ax


class KsmLazyLinOp(LazyLinOp):
    """
    :py:class:`KsmLazyLinOp` class is a specialization of
    :py:class:`.LazyLinOp` when the underlying linear operator
    resulting from a call to :py:func`lazylinop.butterfly.ksm` function.

    The operations ``s * L``, ``L.T``, ``L.H``, ``L.conj()``, ``L1 @ L2``
    and ``L ** n``
    return an instance of the :py:class:`KsmLazyLinOp` class.
    """

    def __init__(
            self,
            ks_values: list,
            backend="xp",
            params: list = None,
            shape: tuple = None,
            matmat=None,
            rmatmat=None,
            **kwargs,
    ):
        """
        Create a ``lazylinop.butterfly.KsmLazyLinOp`` instance ``L``.

        Args:
            ks_values: list of 4d arrays
                 All the ``ks_values`` must have the same ``dtype``.
                 See :py:func:`lazylinop.butterfly.ksm`
                 for more details.
            backend: optional
                 See :py:func:`lazylinop.butterfly.ksm`
                 for more details.
            params: optional
                 See :py:func:`lazylinop.butterfly.ksm`
                 for more details.
            shape: ``tuple[int, int]``, optional
                 Dimensions of operator $L$ is $(M,~N)$.
                 The default value is ``None``:
                 use ``ks_values`` to determine $M$ and $N$.
            matmat: ``callable``, optional
                 Returns $L*V$ where $V$ is a batch
                 of vectors of shape $(N,~K)$.
                 The output matrix shape is $(M,~K)$.
                 The default value is ``None``:
                 ``matmat`` is determined according to
                 ``ks_values`` and ``backend``.
            rmatmat: ``callable``, optional
                 Returns $L^H*V$ where $V$ is a batch
                 of vectors of shape $(M,~K)$.
                 The output matrix shape is $(N,~K)$.
                 The default value is ``None``:
                 ``rmatmat`` is determined according to
                 ``ks_values`` and ``backend``.

        Return:
            ``KsmLazyLinOp``
        Examples:
            >>> from lazylinop.butterfly import ksm
            >>> from lazylinop.butterfly import KsmLazyLinOp
            >>> import numpy as np
            >>> n = 2
            >>> ksv = [np.random.randn(n, n, n, n) for _ in range(3)]
            >>> L = ksm(ksv, backend="xp")
            >>> isinstance(L, KsmLazyLinOp)
            True
            >>> H = L.H
            >>> isinstance(H, KsmLazyLinOp)
            True
            >>> # Check that ks_values of adjoint operator H
            >>> # can be deduced from operator L.
            >>> np.allclose(np.conj(ksv[0].swapaxes(1, 2)), H.ks_values[-1])
            True
        """

        if callable(ks_values):
            # Lazy evaluation of the ks_values.
            # conj(), T, H, return a ks_values that is a callable.
            _shape = shape
            if "ksv_xp" not in kwargs.keys():
                raise Exception("ks_values is a callable, therefore" +
                                " expects array namespace through" +
                                " ksv_xp keyword argument.")
            else:
                xp = kwargs["ksv_xp"]
        else:
            if not isinstance(ks_values, (list, tuple)):
                ks_values = [ks_values]

            # Compute shape of the operator from ks_values shape.
            xp = array_namespace(ks_values[0])
            a, b, c, d = ks_values[0].shape
            dim_out = a * b * d
            a, b, c, d = ks_values[-1].shape
            dim_in = a * c * d
            _shape = (dim_out, dim_in)
            if isinstance(shape, tuple) and shape != _shape:
                raise Exception(
                    "shape argument and shape computed from ks_values differ.")
            # Sanity check of ks_values.
            _check_ks_values(ks_values, backend)

        # ksm_data is used to host/device pointers.
        ksm_data = None
        if matmat is None or rmatmat is None:
            if backend in ("cupyx", "scipy", "xp"):
                _matmat, _rmatmat = _ksm(ks_values, backend)
            else:
                # FIXME: params_perm
                # Check params in _multiple_ksm fn.
                _matmat, _rmatmat, ksm_data = _multiple_ksm(
                    ks_values,
                    params=params,
                    backend=backend,
                    perm=False,
                    params_perm=None,
                )
        else:
            _matmat, _rmatmat = matmat, rmatmat
        super().__init__(
            shape=_shape,
            matmat=_matmat,
            rmatmat=_rmatmat,
        )
        self._ks_values = ks_values
        self._backend = backend
        self._params = params
        self._ksm_data = ksm_data
        self._ksv_xp = xp
        self._chain = None if callable(self._ks_values) else Chain(
            [k.shape for k in self._ks_values])

    @property
    def ks_values(self):
        if callable(self._ks_values):
            return self._ks_values()
        else:
            xp = array_namespace(self._ks_values[0])
            return [
                xp.asarray(k, copy=True) for k in self._ks_values]

    @ks_values.setter
    def ks_values(self, value):
        warn("You cannot modify self.ks_values.")

    @ks_values.deleter
    def ks_values(self):
        pass

    @property
    def backend(self):
        return self._backend

    @backend.setter
    def backend(self, value):
        warn("You cannot modify self.backend.")

    @backend.deleter
    def backend(self):
        pass

    @property
    def params(self):
        if isinstance(self, list):
            return self._params.copy()
        else:
            return self._params

    @params.setter
    def params(self, value):
        warn("You cannot modify self.params.")

    @params.deleter
    def params(self):
        pass

    @property
    def ksm_data(self):
        return self._ksm_data

    @ksm_data.setter
    def ksm_data(self, value):
        warn("You cannot modify self.ksm_data.")

    @ksm_data.deleter
    def ksm_data(self):
        pass

    @property
    def ksv_xp(self):
        return self._ksv_xp

    @ksv_xp.setter
    def ksv_xp(self, value):
        warn("You cannot modify self.ksv_xp.")

    @ksv_xp.deleter
    def ksv_xp(self):
        pass

    @property
    def chain(self):
        if callable(self._ks_values):
            return Chain([k.shape for k in self._ks_values()])
        else:
            return Chain([k.shape for k in self._ks_values])

    @chain.setter
    def chain(self, value):
        warn("You cannot modify self.chain.")

    @chain.deleter
    def chain(self):
        pass

    def conj(self):
        return KsmLazyLinOp(
            lambda: [
                self.ksv_xp.conj(k) for k in self.ks_values
            ],
            backend=self.backend,
            params=self.params,
            shape=self.shape,
            matmat=lambda x: self.ksv_xp.conj(
                self.matmat(self.ksv_xp.conj(x))
            ),
            rmatmat=lambda x: self.ksv_xp.conj(
                self.rmatmat(self.ksv_xp.conj(x))
            ),
            ksv_xp=self.ksv_xp,
        )

    @property
    def T(self):
        return KsmLazyLinOp(
            lambda: [
                self.ksv_xp.asarray(
                    k.swapaxes(1, 2),
                    copy=True,
                ) for k in self.ks_values
            ][::-1],
            backend=self.backend,
            params=self.params_transposition(),
            shape=(self.shape[1], self.shape[0]),
            matmat=lambda x: self.ksv_xp.conj(
                self.rmatmat(
                    self.ksv_xp.conj(x)
                )
            ),
            rmatmat=lambda x: self.ksv_xp.conj(
                self.matmat(
                    self.ksv_xp.conj(x)
                )
            ),
            ksv_xp=self.ksv_xp,
        )

    @property
    def H(self):
        return KsmLazyLinOp(
            lambda: [
                self.ksv_xp.conj(
                    k.swapaxes(1, 2)
                ) for k in self.ks_values
            ][::-1],
            backend=self.backend,
            params=self.params_transposition(),
            shape=(self.shape[1], self.shape[0]),
            matmat=lambda x: self.rmatmat(x),
            rmatmat=lambda x: self.matmat(x),
            ksv_xp=self.ksv_xp,
        )

    def __mul__(self, s):
        """
        Returns the :py:class:`lazylinop.butterfly.KsmLazyLinOp`
        for self * s.

        Args:
            s: a scalar.
        """
        if (is_array_api_obj(s) and s.shape == ()) or isinstance(s, Number):
            # All ks_values must have the same dtype.
            return KsmLazyLinOp(
                lambda: [
                    (
                        s if i == 0 else 1 + 0 * s
                    ) * k for i, k in enumerate(self.ks_values)
                ],
                backend=self.backend,
                params=self.params,
                shape=self.shape,
                matmat=lambda x: self.matmat(x) * s,
                rmatmat=lambda x: self.rmatmat(x) * s,
                ksv_xp=self.ksv_xp,
            )
        else:
            raise TypeError("Cannot multiply by a non-scalar object")

    def __matmul__(self, other):
        L = super().__matmul__(other)
        if isinstance(other, KsmLazyLinOp):
            # Check if we can return a KsmLazyLinOp.
            if self.backend != other.backend:
                warn(f"Because first backend {self.backend} and" +
                     f" second backend {other.backend} are differents," +
                     " return a LazyLinOp instead of a KsmLazyLinOp.")
                return L
            elif array_namespace(
                    self.ks_values[0]) != array_namespace(other.ks_values[0]):
                warn(f"L1 @ L2: because ks_values of L1 and L2 use" +
                     " two differents namespaces return a LazyLinOp" +
                     " instead of a KsmLazyLinOp.")
                return L
            elif self.ks_values[0].dtype != other.ks_values[0].dtype:
                warn(f"L1 @ L2: because ks_values of L1 and L2 use" +
                     " two differents dtypes return a LazyLinOp" +
                     " instead of a KsmLazyLinOp.")
                return L
            elif self.ks_values[0].device != other.ks_values[0].device:
                warn(f"L1 @ L2: because ks_values of L1 and L2 use" +
                     " two differents devices return a LazyLinOp" +
                     " instead of a KsmLazyLinOp.")
                return L
            elif self.backend != other.backend:
                warn(f"L1 @ L2: because L1 and L2 use" +
                     " two differents backends return a LazyLinOp" +
                     " instead of a KsmLazyLinOp.")
                return L
            else:
                if isinstance(self.params, list):
                    _params = self.params.copy()
                else:
                    _params = [(None, None)] * len(self.ks_values)
                if isinstance(other.params, list):
                    _params = _params + other.params.copy()
                else:
                    _params = _params + [(None, None)] * len(other.ks_values)
                xp = array_namespace(self.ks_values[0])
                return KsmLazyLinOp(
                    lambda: [
                        self.ksv_xp.asarray(
                            k,
                            copy=True,
                        ) for k in self.ks_values
                    ] + [
                        self.ksv_xp.asarray(
                            k,
                            copy=True,
                        ) for k in other.ks_values
                    ],
                    backend=self.backend,
                    params=_params,
                    shape=L.shape,
                    matmat=L.matmat,
                    rmatmat=L.rmatmat,
                    ksv_xp=self.ksv_xp,
                )
        elif isinstance(other, LazyLinOp):
            warn("L1 @ L2: L2 is not a KsmLazyLinOp return a LazyLinOp.")
            L.ks_values = self.ks_values
            L.backend = self.backend
            L.params = self.params
            return L
        else:
            return L

    def __pow__(self, n):
        xp = array_namespace(self.ks_values[0])
        L = super().__pow__(n)
        if n == 0:
            return L
        else:
            return KsmLazyLinOp(
                lambda: [
                    xp.asarray(
                        k,
                        copy=True,
                    ) for _ in range(n) for k in self.ks_values
                ],
                backend=self.backend,
                params=self.params,
                shape=L.shape,
                matmat=L.matmat,
                rmatmat=L.rmatmat,
                ksv_xp=self.ksv_xp,
            )

    def __del__(self):
        """
        Release (OpenCL) or free (CUDA) device pointers of
        :py:class:`lazylinop.butterfly.KsmLazyLinOp` ``self``
        returned by either ``ksm(...)`` or ``ksd(...)``.
        Once you compute ``y = self @ x`` and you do not
        need ``self`` anymore, use ``del self`` to clean
        host/device memory, delete ``ks_values`` and to delete ``self``.
        """
        # Delete ks_values.
        if hasattr(self, "ks_values"):
            K = len(self.ks_values)
            for i in range(K - 1, -1, -1):
                del self.ks_values[i]
        # Free/release the ks_values device pointers.
        if (
                hasattr(self, 'ksm_data') and
                hasattr(self.ksm_data, 'ksv_dev_ptr') and
                self.ksm_data.ksv_dev_ptr is not None
        ):
            # Backend 'numpy' and 'scipy' do not need device pointers.
            for i in self.ksm_data.ksv_dev_ptr:
                if hasattr(i, "free"):
                    i.free()
                    # https://docs.nvidia.com/cuda/cuda-c-programming-guide/index.html#stream-ordered-memory-allocator-intro
                    # self.context.synchronize()
                elif hasattr(i, "release"):
                    i.release()
            del self.ksm_data.ksv_dev_ptr
        # Free/release the intermediate output device pointers.
        if hasattr(self, "ksm_data") and hasattr(self.ksm_data, "dev_ptr"):
            for i in self.ksm_data.dev_ptr:
                if hasattr(i, "free"):
                    i.free()
                if hasattr(i, "release"):
                    i.release()
        if hasattr(self, "ksm_data") and hasattr(self.ksm_data, "rdev_ptr"):
            for i in self.ksm_data.rdev_ptr:
                if hasattr(i, "free"):
                    i.free()
                if hasattr(i, "release"):
                    i.release()

    def params_transposition(self):
        """
        Transposition of hyper-parameters.
        """
        hp, rhp = None, None
        if hasattr(self.ksm_data, 'hp'):
            hp = self.ksm_data.hp
        if hasattr(self.ksm_data, 'rhp'):
            rhp = self.ksm_data.rhp
        if isinstance(hp, list) and isinstance(rhp, list):
            P = len(hp)
            params = [None] * P
            for i in range(P):
                params[i] = (rhp[P - 1 - i], hp[P - 1 - i])
        else:
            params = None
        return params

    @staticmethod
    def del_all_contexts():
        """
        Delete all PyOpenCL and PyCUDA contexts.
        After that, all the :py:class:`lazylinop.butterfly.KsmLazyLinOp`
        using PyOpenCL or PyCUDA backends won't work anymore.
        """
        from gc import collect
        try:
            from pycuda.tools import clear_context_caches
        except (ModuleNotFoundError, TypeError):
            # FIXME: TypeError: unsupported operand type(s) for |: 'type' and 'types.GenericAlias'
            clear_context_caches = None

        from lazylinop.butterfly.ksm import contexts
        n_contexts = len(contexts)
        for i in range(n_contexts):
            if (
                    cuda is not None and
                    isinstance(contexts[n_contexts - 1 - i], cuda.Context)
            ) or (
                _cuda is not None and
                isinstance(contexts[n_contexts - 1 - i], _cuda.Context)
            ):
                contexts[n_contexts - 1 - i].push()
                contexts[n_contexts - 1 - i].synchronize()
                contexts[n_contexts - 1 - i].pop()
                contexts[n_contexts - 1 - i].detach()
                del contexts[n_contexts - 1 - i]
        if clear_context_caches is not None:
            clear_context_caches()
        collect()
        contexts = []

    @staticmethod
    def load(name: str):
        """
        Load ``L`` an instance of
        :py:class:`lazylinop.butterfly.KsmLazyLinOp` from file ``name.json``.
        The file ``name.json`` has been created by
        :py:func:`lazylinop.butterfly.KsmLazyLinOp.save`.

        Args:
            name: ``str``
                Name of the ``.json`` file where to load ``L``.

        Returns:
            ``L`` an instance of :py:class:`lazylinop.butterfly.KsmLazyLinOp`.
            If file does not exist, return ``None``.

        .. seealso::
            - :py:func:`lazylinop.butterfly.KsmLazyLinOp.save`.

        Examples:
            >>> import scipy as sp
            >>> import numpy as np
            >>> from lazylinop.butterfly import Chain, ksd, KsmLazyLinOp
            >>> H = sp.linalg.hadamard(8)
            >>> x = np.random.randn(8)
            >>> chain = Chain.square_dyadic(H.shape)
            >>> A = ksd(H, chain)
            >>> A.save("hadamard_8x8")
            >>> A_ = KsmLazyLinOp.load("hadamard_8x8")
            >>> y = A @ x
            >>> y_ = A_ @ x
            >>> np.allclose(y, y_)
            True
        """
        try:
            L = None
            with open(name + '.json', 'r') as f:
                data = json.load(f)
                # Loop over the Kronecker-sparse factors.
                ks_values = []
                backend = data['backend']
                if data['params'] is None:
                    params = None
                else:
                    params = [tuple(p) for p in data['params']]
                for k in data.keys():
                    if k == "backend" or k == "params":
                        continue
                    if data[k]['package'] == 'cupy':
                        import array_api_compat.cupy as xp
                    elif data[k]['package'] == 'numpy':
                        import array_api_compat.numpy as xp
                    elif data[k]['package'] == 'torch':
                        import array_api_compat.torch as xp
                    if 'complex' in str(data[k]['dtype']):
                        ks_values.append(
                            xp.asarray(
                                np.asarray(
                                    data[k]['ks_values_real'],
                                    dtype=data[k]['dtype'],
                                ) +
                                1j * np.asarray(
                                    data[k]['ks_values_imag'],
                                    dtype=data[k]['dtype'],
                                ),
                                device=data[k]['device'],
                            )
                        )
                    else:
                        ks_values.append(
                            xp.asarray(
                                np.asarray(
                                    data[k]['ks_values_real'],
                                    dtype=data[k]['dtype'],
                                ),
                                device=data[k]['device'],
                            )
                        )
                L = KsmLazyLinOp(
                    ks_values,
                    backend=backend,
                    params=params,
                )
            return L
        except IOError:
            raise IOError(f"Did not find {name}.json.")

    def save(self, name: str):
        """
        Save ``L`` returned by ``L = ksm(...)``
        or ``L = ksd(...)`` in a json file ``name + '.json'``.

        Args:
            name: ``str``
                Name of the file.

        .. seealso::
            - :py:func:`lazylinop.butterfly.KsmLazyLinOp.load`.

        Examples:
            >>> import scipy as sp
            >>> import numpy as np
            >>> from lazylinop.butterfly import Chain, ksd, KsmLazyLinOp
            >>> H = sp.linalg.hadamard(8)
            >>> x = np.random.randn(8)
            >>> chain = Chain.square_dyadic(H.shape)
            >>> L = ksd(H, chain)
            >>> L.save("hadamard_8x8")
            >>> L_ = KsmLazyLinOp.load("hadamard_8x8")
            >>> y = L @ x
            >>> y_ = L_ @ x
            >>> np.allclose(y, y_)
            True
        """
        data = {}
        for i, k in enumerate(self.ks_values):
            data["factor" + str(i)] = {}
            if is_torch_array(k):
                data["factor" + str(i)]['package'] = 'torch'
                data["factor" + str(i)]['device'] = str(k.device)
            elif is_numpy_array(k):
                data["factor" + str(i)]['package'] = 'numpy'
                data["factor" + str(i)]['device'] = k.device
            elif is_cupy_array(k):
                data["factor" + str(i)]['package'] = 'cupy'
                data["factor" + str(i)]['device'] = int(k.device)
            # Store current factor in a dict.
            data["factor" + str(i)]['ks_values_real'] = k.real.tolist()
            if 'complex' in str(k.dtype):
                data["factor" + str(i)]['ks_values_imag'] = k.imag.tolist()
            if is_torch_array(k):
                data["factor" + str(i)][
                    'dtype'] = str(k.numpy(force=True).dtype)
            else:
                data["factor" + str(i)]['dtype'] = str(k.dtype)
        data["params"] = self.params
        data["backend"] = self.backend
        with open(name + '.json', 'w') as f:
            json.dump(data, f, indent=1)


def _check_ks_values(ks_values, backend):
    """
    Sanity check of ks_values.
    """
    xp_backend = ["cupyx", "scipy", "xp"]
    # All ks_values must have the same dtype and device.
    ksv0 = ks_values[0]
    _isc = is_cupy_array(ksv0)
    _isn = is_numpy_array(ksv0)
    _ist = is_torch_array(ksv0)
    _dtype = ksv0.dtype
    _device = ksv0.device
    xp = array_namespace(ksv0)
    # Does it use Hadamard specialized kernel?
    hadamard = True
    for k in ks_values:
        if (
                "int8" not in str(k.dtype) and
                "int16" not in str(k.dtype) and
                "int32" not in str(k.dtype)
        ):
            hadamard = False
            break
        a, b, c, d = k.shape
        if xp.sum(xp.abs(k)) != a * b * c * d:
            hadamard = False
            break
    for k in ks_values:
        if k.dtype != _dtype:
            raise TypeError("All ks_values must have the same dtype.")
        if array_namespace(k) != xp:
            raise TypeError(
                "All ks_values must have the same namespace.")
        if k.ndim != 4 or not (
                is_cupy_array(k) or
                is_numpy_array(k) or
                is_torch_array(k)
        ):
            raise Exception(
                "ks_values elements must be a" +
                " 4D CuPy/NumPy array or torch tensor.")
        if backend not in xp_backend:
            if k.dtype != (
                    None if torch is None else torch.bfloat16
            ) and not hadamard and k.dtype not in (
                xp.float16,
                xp.float32,
                xp.float64,
                xp.complex64,
                xp.complex128,
            ):
                raise TypeError(
                    "dtype of ks_values must be either torch.bfloat16,"
                    + " xp.float16, xp.float32, xp.float64, xp.complex64"
                    + f" or xp.complex128 with {backend} backend.")
    if isinstance(backend, str) and backend in xp_backend:
        pass
    elif backend == 'ksmm':
        if not (_isc or (
                _ist and _device.type == "cuda")):
            raise Exception(
                "backend='ksmm'" +
                " expects ks_values to be CuPy arrays" +
                " or torch tensors on cuda device.")
    elif isinstance(backend, tuple) and len(backend) == 2 and (
            (cl is not None and
             isinstance(backend[0], cl.Platform) and
             isinstance(backend[1], cl.Device)) or
            backend in [(None, None), (None, 'cpu'), (None, 'gpu')]):
        if not (_isn or (_ist and _device.type == 'cpu')):
            raise Exception(
                "backend=(cl.platform, cl.Device) (PyOpenCL)" +
                " expects ks_values to be NumPy arrays" +
                " or torch tensors on cpu.")
    elif cuda is not None and isinstance(backend, cuda.Device):
        if not _isn:
            raise Exception(
                "backend=pycuda.driver.Device (PyCUDA)" +
                " expects ks_values to be NumPy arrays.")
    else:
        raise Exception(
            f"No such backend found: {backend}." +
            " Please check if CuPy, PyTorch, PyCUDA and/or" +
            " PyOpenCL have been installed.")


def load(name: str):
    """
    Load ``L`` from file ``name.json``.
    The file ``name.json`` has been created by
    :py:func:`lazylinop.butterfly.save`.

    Args:
        name: ``str``
            Name of the ``.json`` file where to load ``L``.

    Returns:
        ``L`` a lazy linear operator resulting from
        a call to ``ksm(...)`` or ``ksd(...)`` function.
        If file does not exist, return ``None``.

    .. seealso::
        - :py:func:`lazylinop.butterfly.save`.

    Examples:
        >>> import scipy as sp
        >>> import numpy as np
        >>> from lazylinop.butterfly import Chain, ksd, load, save
        >>> H = sp.linalg.hadamard(8)
        >>> x = np.random.randn(8)
        >>> chain = Chain.square_dyadic(H.shape)
        >>> A = ksd(H, chain)
        >>> save(A, "hadamard_8x8")
        >>> A_ = load("hadamard_8x8")
        >>> y = A @ x
        >>> y_ = A_ @ x
        >>> np.allclose(y, y_)
        True
    """
    return KsmLazyLinOp.load(name)


def save(L, name: str):
    """
    Save ``L = ksm(...)`` or ``L = ksd(...)``
    in a json file ``name + '.json'``.

    Args:
        L:
            A lazy linear operator returned by
            ``L = ksm(...)`` or ``L = ksd(...)``.
        name: ``str``
            Name of the file.

    .. seealso::
        - :py:func:`lazylinop.butterfly.load`.

    Examples:
        >>> import scipy as sp
        >>> import numpy as np
        >>> from lazylinop.butterfly import Chain, ksd, load, save
        >>> H = sp.linalg.hadamard(8)
        >>> x = np.random.randn(8)
        >>> chain = Chain.square_dyadic(H.shape)
        >>> L = ksd(H, chain)
        >>> save(L, "hadamard_8x8")
        >>> L_ = load("hadamard_8x8")
        >>> y = L @ x
        >>> y_ = L_ @ x
        >>> np.allclose(y, y_)
        True
    """
    if isinstance(L, KsmLazyLinOp):
        L.save(name)
    else:
        raise Exception("L must be a lazy linear operator returned by" +
                        " L = ksm(...) or L = ksd(...).")


def savemat(L: KsmLazyLinOp, name: str):
    """
    Save an instance ``L`` of :py:class:`lazylinop.butterfly.KsmLazyLinOp`
    into a MATLAB file ``name + '.mat'``.

    Args:
        L: ``lazylinop.butterfly.KsmLazyLinOp``
            An instance ``L`` of ``lazylinop.butterfly.KsmLazyLinOp`` to save.
        name: ``str``
            Name of the file.

    .. seealso::
        - `scipy.io.savemat function <https://docs.scipy.org/doc/
          scipy/reference/generated/scipy.io.savemat.html>`_,
        - :func:`loadmat`,
        - :func:`save`,
        - :func:`load`.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import KsmLazyLinOp
        >>> from lazylinop.butterfly import loadmat, savemat
        >>> ksv = [np.random.randn(2, 2, 2, 2) for _ in range(3)]
        >>> L = KsmLazyLinOp(ksv)
        >>> x = np.random.randn(8)
        >>> savemat(L, "savemat_L")
        >>> L_load = loadmat("savemat_L")
        >>> y = L @ x
        >>> y_load = L_load @ x
        >>> np.allclose(y, y_load)
        True
    """
    from scipy import io as sp_io
    if not isinstance(L, KsmLazyLinOp):
        raise Exception("L must be an instance of KsmLazyLinOp class.")
    # Save result of factorization in a MATLAB file.
    stack = np.empty((len(L.ks_values), 1), dtype='object')
    for i in range(len(L.ks_values)):
        if is_torch_array(L.ks_values[i]):
            stack[i, 0] = L.ks_values[i].numpy(force=True)
        elif is_cupy_array(L.ks_values[i]):
            stack[i, 0] = cp.asnumpy(L.ks_values[i])
        elif is_numpy_array(L.ks_values[i]):
            stack[i, 0] = L.ks_values[i]
    sp_io.savemat(name + '.mat', {'ks_values': stack})


def loadmat(name: str):
    """
    Load an instance ``L`` of :py:class:`lazylinop.butterfly.KsmLazyLinOp`
    from file ``name.mat``.
    The file ``name.mat`` has been created by :func:`savemat`.

    Args:
        name: ``str``
            Name of the ``.mat`` file where to load ``L``.

    Returns:
        An instance ``L`` of :py:class:`lazylinop.butterfly.KsmLazyLinOp`.
        If file does not exist, return ``None``.

    .. seealso::
        - `scipy.io.loadmat function <https://docs.scipy.org/doc/
          scipy/reference/generated/scipy.io.loadmat.html>`_,
        - :func:`savemat`,
        - :func:`save`,
        - :func:`load`.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import KsmLazyLinOp
        >>> from lazylinop.butterfly import loadmat, savemat
        >>> ksv = [np.random.randn(2, 2, 2, 2) for _ in range(3)]
        >>> L = KsmLazyLinOp(ksv)
        >>> x = np.random.randn(8)
        >>> savemat(L, "savemat_L")
        >>> L_load = loadmat("savemat_L")
        >>> y = L @ x
        >>> y_load = L_load @ x
        >>> np.allclose(y, y_load)
        True
    """
    from scipy import io as sp_io
    try:
        data = {}
        sp_io.loadmat(name + '.mat', data, appendmat=False)
    except IOError:
        data = {}
    if data == {}:
        raise IOError(f"Did not find {name}.mat.")
    else:
        ks_values = []
        if data['ks_values'].shape[1] != 1:
            raise Exception("ks_values shape must be (# factors, 1).")
        for i in range(data['ks_values'].shape[0]):
            ks_values.append(data['ks_values'][i, 0])
        return KsmLazyLinOp(ks_values, backend='xp')
