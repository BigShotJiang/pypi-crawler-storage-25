// -*- c++ -*-

#include <cuComplex.h>
#include <cuda.h>
#include <cuda_fp16.h>
#include <cuda_bf16.h>
#include <cuda_runtime.h>
#include <stdexcept>
#include <stdio.h>

#ifndef KSMM
#define KSMM

#if defined(V1)
#define VSIZE 1
#elif defined(V2)
#define VSIZE 2
#elif defined(V3)
#define VSIZE 3
#elif defined(V4)
#define VSIZE 4
#endif

#ifdef USE_BFLOAT16
#define SUPPORT_BFLOAT16
#endif

#ifdef USE_FLOAT16
#define SUPPORT_FLOAT16
#endif

#ifdef USE_FLOAT32
#define SUPPORT_FLOAT32
#endif

#ifdef USE_COMPLEX64
#define SUPPORT_COMPLEX64
#define SUPPORT_COMPLEX
#endif

#ifdef USE_FLOAT64
#define SUPPORT_FLOAT64
#endif

#ifdef USE_COMPLEX128
#define SUPPORT_COMPLEX128
#define SUPPORT_COMPLEX
#endif

#ifdef SUPPORT_BFLOAT16
typedef __nv_bfloat16 dtype;
#if defined(V1)
typedef __nv_bfloat16 dtypex;
#endif
#if defined(V2)
typedef __nv_bfloat162 dtypex;
#endif
#if defined(V3)
struct __align__(2) bfloat3
{
  __nv_bfloat16 x, y, z;
};
typedef bfloat3 dtypex;
#endif
#if defined(V4)
struct __align__(8) bfloat4
{
  __nv_bfloat16 x, y, z, w;
};
typedef bfloat4 dtypex;
#endif
#endif

#ifdef SUPPORT_FLOAT16
typedef __half dtype;
#if defined(V1)
typedef __half dtypex;
#endif
#if defined(V2)
typedef __half2 dtypex;
#endif
#if defined(V3)
struct __align__(2) half3
{
  __half x, y, z;
};
typedef half3 dtypex;
#endif
#if defined(V4)
struct __align__(8) half4
{
  __half x, y, z, w;
};
typedef half4 dtypex;
#endif
#endif

#ifdef SUPPORT_FLOAT32
typedef float dtype;
#if defined(V1)
typedef float dtypex;
#endif
#if defined(V2)
typedef float2 dtypex;
#endif
#if defined(V3)
typedef float3 dtypex;
#endif
#if defined(V4)
typedef float4 dtypex;
#endif
#endif

#ifdef SUPPORT_FLOAT64
typedef double dtype;
#if defined(V1)
typedef double dtypex;
#endif
#if defined(V2)
typedef double2 dtypex;
#endif
#if defined(V3)
typedef double3 dtypex;
#endif
#if defined(V4)
typedef double4 dtypex;
#endif
#endif

#ifdef SUPPORT_COMPLEX64
typedef cuFloatComplex dtype;
typedef float elt_t;
#if defined(V1)
typedef cuFloatComplex dtypex;
#endif
#if defined(V2)
typedef float4 dtypex;
#endif
#if defined(V3)
typedef float4 dtypex;
#endif
#if defined(V4)
struct __align__(32) float8
{
  float x, y, z, w, r, s, t, u;
};
typedef float8 dtypex;
#endif
#endif

#ifdef SUPPORT_COMPLEX128
typedef cuDoubleComplex dtype;
typedef double elt_t;
#if defined(V1)
typedef cuDoubleComplex dtypex;
#endif
#if defined(V2)
typedef double4 dtypex;
#endif
#if defined(V3)
typedef double4 dtypex;
#endif
#if defined(V4)
struct __align__(64) double8
{
  double x, y, z, w, r, s, t, u;
};
typedef double8 dtypex;
#endif
#endif

#ifdef USE_INT8
typedef char int_t;
#if defined(V1)
typedef char intx;
#endif
#if defined(V2)
typedef char2 intx;
#endif
#if defined(V3)
typedef char3 intx;
#endif
#if defined(V4)
typedef char4 intx;
#endif
#endif

#ifdef USE_INT16
typedef short int_t;
#if defined(V1)
typedef short intx;
#endif
#if defined(V2)
typedef short2 intx;
#endif
#if defined(V3)
typedef short3 intx;
#endif
#if defined(V4)
typedef short4 intx;
#endif
#endif

#ifdef USE_INT32
typedef int int_t;
#if defined(V1)
typedef int intx;
#endif
#if defined(V2)
typedef int2 intx;
#endif
#if defined(V3)
typedef int3 intx;
#endif
#if defined(V4)
typedef int4 intx;
#endif
#endif

#define load_intx(a, b)                                                            \
  reinterpret_cast<intx *>(&a)[0] = reinterpret_cast<intx *>(&b)[0]

__device__ inline void rloadi(int_t *a, int_t *b, int idx1, int idx2) {
#if defined(V1)
  a[idx1] = b[idx2];
#else
  load_intx(a[idx1], b[idx2]);
#endif
}

#define loadx(a, b)                                                            \
  reinterpret_cast<dtypex *>(&a)[0] = reinterpret_cast<dtypex *>(&b)[0]

__device__ inline void rload(dtype *a, dtype *b, int idx1, int idx2) {
#if defined(V1)
  a[idx1] = b[idx2];
#else
#if defined(SUPPORT_COMPLEX) && defined(V3)
  // No float6 and double6 structures.
  loadx(a[idx1], b[idx2]);
  a[idx1 + 2] = b[idx2 + 2];
#else
  loadx(a[idx1], b[idx2]);
#endif
#endif
}

#ifdef SUPPORT_COMPLEX
__device__ inline void make_cuXComplex(dtype &dst, elt_t r, elt_t i) {
#if defined(SUPPORT_COMPLEX64)
  dst = make_cuFloatComplex(r, i);
#else
  dst = make_cuDoubleComplex(r, i);
#endif
}
#endif

__device__ inline void kload(int_t *gmem, int_t *smem, int c, int row, int s,
                             int col) {
  // gmem is -1 or 1: (1 + gmem[v]) >> 1 is 0 or 1.
#pragma unroll
  for (int v = 0; v < VSIZE; v++)
    smem[(col * VSIZE + v) * xTILEYx + row + s] = (1 + gmem[v]) >> 1;
}

__device__ inline void iload(dtype *gmem, dtype *smem, int batch_size,
                             int row, int s, int col) {
#if defined(V1)
  smem[(row + s) * xTILEXx + col * VSIZE] = gmem[0];
#elif defined(V3)
  loadx(smem[(row + s) * xTILEXx + col * VSIZE], gmem[0]);
  smem[(row + s) * xTILEXx + col * VSIZE + 2] = gmem[2];
#else
  loadx(smem[(row + s) * xTILEXx + col * VSIZE], gmem[0]);
#endif
}

extern "C" {
  __global__ void ksmm(int_t *values, dtype *input, dtype *output, const uint a,
		       const uint b, const uint c, const uint d, uint batch_size) {
    int bx = blockIdx.x;
    int by = blockIdx.y;
    int t_id = threadIdx.x * blockDim.y + threadIdx.y;
    // Kronecker-sparse pattern (a, b, c, d)
    // K = kron(Id_{a,a}, kron(1_{b,c}, Id_{d,d}))
    // There is 'a' super-blocks of shape (b * d, c * d).
    // Number of non-zero per super-block is
    // b per column and c per row.
    // We would like to compute K @ X.
    // K (row-major format) shape is (a * b * d, a * c * d).
    // X (row-major format) shape is (a * c * d, batch).
    // TILEX / TX threads per column
    // Get the current thread
    int threadx = t_id % (xTILEXx / xTXx);
    int thready = t_id / (xTILEXx / xTXx);
    // To store input in shared memory
    __shared__ dtype shared_input[2][xTILEKx * xTILEXx];
    // To store sparse matrix in shared memory
    __shared__ int_t shared_values[2][xTILEYx * xTILEKx];
#if defined(SUPPORT_BFLOAT16)
    dtype acc[xTYx * xTXx] = {__float2bfloat16(0.0f)};
    dtype tmp[2] = {__float2bfloat16(0.0f)};
#elif defined(SUPPORT_FLOAT16)
    dtype acc[xTYx * xTXx] = {__float2half(0.0f)};
    dtype tmp[2] = {__float2half(0.0f)};
#elif defined(SUPPORT_FLOAT32)
    dtype acc[xTYx * xTXx] = {0.0f};
    dtype tmp[2] = {0.0f};
#else
    dtype acc[xTYx * xTXx] = {0.0};
    dtype tmp[2] = {0.0};
#endif
    dtype regX[xTXx];
    int_t regY[xTYx];

    dtypex src;

    // Current super-block.
    int sb_id = (by * xTILEYx) / (b * d);
    // Group and id inside the super-block.
    int grp_id = (by * xTILEYx - sb_id * b * d) / b;
    int off = ((by * xTILEYx - sb_id * b * d) % b) / xTILEYx;
    // Move to the current super-block, group and id.
    values = &values[(sb_id * b * d + grp_id + off * d * xTILEYx) * c];
    input = &input[(c * d * sb_id + grp_id % d) * batch_size];
    output = &output[(sb_id * b * d + grp_id + off * d * xTILEYx) * batch_size];
    // Move bx * TILEX columns.
    input += bx * xTILEXx;
    output += bx * xTILEXx;

    // Indices to load (Kronecker-sparse factor) in smem.
    int ValuesSubRow = t_id / (xTILEKx / VSIZE);
    int ValuesSubCol = t_id % (xTILEKx / VSIZE);
    // Indices to load (input matrix) in smem.
    int InputSubRow = t_id / (xTILEXx / VSIZE);
    int InputSubCol = t_id % (xTILEXx / VSIZE);

    // Use stride to load from GMEM to SMEM
    const int StrideValues = VSIZE * xNTHREADSx / xTILEKx;
    const int StrideInput = VSIZE * xNTHREADSx / xTILEXx;

    // Load (dtypex) the first batch of Kronecker-sparse factor from global to
    // shared memory TILEY * TILEK.
#pragma unroll
    for (int s = 0; s < xTILEYx; s += StrideValues)
      kload(&values[d * (ValuesSubRow + s) * c + (ValuesSubCol * VSIZE) % c],
	    &shared_values[0][0], c, ValuesSubRow, s, ValuesSubCol);

    // Load the first batch of input from global to shared memory TILEK * TILEX.
#pragma unroll
    for (int s = 0; s < xTILEKx; s += StrideInput)
      iload(&input[d * (InputSubRow + s) * batch_size + InputSubCol * VSIZE],
	    &shared_input[0][0], batch_size, InputSubRow, s, InputSubCol);

    int load = 0;
    int write = 1;

    // Loop over non-zero entries by TILEK
    for (int k = 0; k < xTILEKx * (c / xTILEKx); k += xTILEKx) {
      __syncthreads();
      // Load smem to register and compute accumulation.
#pragma unroll
      for (int i = 0; i < xTILEKx; i++) {
	// Kronecker-sparse factor.
#pragma unroll
	for (int y = 0; y < xTYx; y += VSIZE)
	  rloadi(regY, shared_values[load], y, i * xTILEYx + thready * xTYx + y);
	// Input.
#pragma unroll
	for (int x = 0; x < xTXx; x += VSIZE)
	  rload(regX, shared_input[load], x, i * xTILEXx + threadx * xTXx + x);

	// Compute accumulation.
#pragma unroll
	for (int y = 0; y < xTYx; y++) {
#pragma unroll
	  for (int x = 0; x < xTXx; x++) {
	    tmp[0] = -regX[x];
	    tmp[1] = regX[x];
#if defined(SUPPORT_COMPLEX64)
	    acc[y * xTXx + x] = cuCaddf(acc[y * xTXx + x], tmp[regY[y]]);
#elif defined(SUPPORT_COMPLEX128)
	    acc[y * xTXx + x] = cuCadd(acc[y * xTXx + x], tmp[regY[y]]);
#elif defined(SUPPORT_BFLOAT16) || defined(SUPPORT_FLOAT16)
	    acc[y * xTXx + x] = __hadd(acc[y * xTXx + x], tmp[regY[y]]);
#else
	    acc[y * xTXx + x] += tmp[regY[y]];
#endif
	  }
	}
      }

      load = load ^ 1;
      // Move xTILEKx columns (values is in row-major).
      values += xTILEKx;
      // Move d * xTILEKx rows (input is in row-major).
      input += d * xTILEKx * batch_size;

      // Condition on columns of values.
      if ((k + xTILEKx) < (xTILEKx * (c / xTILEKx))) {
	// Load the Kronecker-sparse factor in shared memory TILEY x TILEK.
#pragma unroll
	for (int s = 0; s < xTILEYx; s += StrideValues)
	  kload(&values[d * (ValuesSubRow + s) * c + (ValuesSubCol * VSIZE) % c],
		&shared_values[write][0], c, ValuesSubRow, s, ValuesSubCol);
        // Load next batch from global to shared memory TILEK x TILEX
#pragma unroll
	for (int s = 0; s < xTILEKx; s += StrideInput)
	  iload(&input[d * (InputSubRow + s) * batch_size + InputSubCol * VSIZE],
		&shared_input[write][0], batch_size, InputSubRow, s, InputSubCol);
	write = write ^ 1;
      }
    }

#pragma unroll
    for (int y = 0; y < xTYx; y++) {
#pragma unroll
      for (int x = 0; x < xTXx; x += VSIZE)
	rload(output, acc,
	      d * (thready * xTYx + y) * batch_size + threadx * xTXx + x, y * xTXx + x);
    }
  }
}

#endif
