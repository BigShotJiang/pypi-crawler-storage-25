from lazylinop.butterfly import KsmPermLazyLinOp
from lazylinop.butterfly import optimize as _optimize


def _dft_square_dyadic_ks_values(N: int,
                                 dtype: str = 'complex128',
                                 device='cpu'):
    r"""
    Return a list of ``ks_values`` that corresponds
    to the ``F @ P.T`` matrix decomposition into
    ``n = int(np.log2(N))`` factors, where ``F`` is the DFT matrix
    and ``P`` the bit-reversal permutation matrix.
    The size $N=2^n$ of the DFT must be a power of $2$.

    We can draw the square-dyadic decomposition for $N=16$:

    .. image:: _static/square_dyadic.svg

    Args:
        N: ``int``
            DFT of size $N=2^n$.
        dtype: ``str``, optional
            It could be either ``'complex64'`` or ``'complex128'`` (default).
        device: optional
            Send ``ks_values`` to device ``device``.
            The default value is ``'cpu'``.

    Returns:
        List of 4d arrays corresponding to ``ks_values``.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly.dft import _dft_square_dyadic_ks_values
        >>> from lazylinop.butterfly import ksm
        >>> from lazylinop.signal import fft
        >>> from lazylinop.basicops import bitrev
        >>> N = 2 ** 5
        >>> ks_values = _dft_square_dyadic_ks_values(N)
        >>> x = np.random.randn(N)
        >>> L = ksm(ks_values)
        >>> P = bitrev(N)
        >>> np.allclose(fft(N) @ x, L @ P @ x)
        True

    References:
        - Learning Fast Algorithms for Linear Transforms
          Using Butterfly Factorizations.

          Dao T, Gu A, Eichhorn M, Rudra A, Re C.
          Proc Mach Learn Res. 2019 Jun;97:1517-1527.
          PMID: 31777847; PMCID: PMC6879380.
    """
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")
    # int(np.log2(N))
    p, _N = 0, N
    while _N >> 1 != 0:
        _N >>= 1
        p += 1
    # Infer the namespace from dtype and device.
    try:
        import array_api_compat.torch as xp
        xp.asarray([1], dtype=dtype, device=device)
    except (ModuleNotFoundError, TypeError):
        try:
            import array_api_compat.cupy as xp
            xp.asarray([1], dtype=dtype, device=device)
        except (ModuleNotFoundError, ValueError):
            import array_api_compat.numpy as xp
    inv_sqrt2 = 1.0 / xp.sqrt(
        xp.asarray([2.0], dtype=dtype, device=device))
    # Build ks_values.
    ks_values = [None] * p
    for n in range(p):
        if n == (p - 1):
            f2 = xp.asarray([[1.0, 1.0], [1.0, -1.0]],
                            dtype=dtype, device=device) * inv_sqrt2
            a = N // 2
            b, c = 2, 2
            d = 1
            ks_values[n] = xp.empty((a, b, c, d), dtype=dtype,
                                    device=device)
            for i in range(a):
                ks_values[n][i, :, :, 0] = f2
        else:
            s = N // 2 ** (p - n)
            t = N // 2 ** (n + 1)
            w = xp.exp(
                xp.asarray([2.0j * xp.pi / (2 * t)],
                           dtype=dtype, device=device))
            omega = w ** (-xp.arange(t, device=device))
            a = s
            b, c = 2, 2
            d = t
            ks_values[n] = xp.empty((a, b, c, d), dtype=dtype,
                                    device=device)
            # Map between 2d and 4d representations.
            # col = i * c * d + k * d + l
            # row = i * b * d + j * d + l
            # Loop over the a blocks.
            for i in range(a):
                for u in range(t):
                    for v in range(4):
                        if v == 0:
                            # Identity.
                            sub_col = u
                            sub_row = u
                            tmp = inv_sqrt2
                        elif v == 1:
                            # diag(omega).
                            sub_col = u + t
                            sub_row = u
                            tmp = omega[u] * inv_sqrt2
                        elif v == 2:
                            # Identity.
                            sub_col = u
                            sub_row = u + t
                            tmp = inv_sqrt2
                        else:
                            # -diag(omega)
                            sub_col = u + t
                            sub_row = u + t
                            tmp = -omega[u] * inv_sqrt2
                        j = sub_row // d
                        k = sub_col // d
                        ks_values[n][i, j, k, sub_col - k * d] = tmp[0]
    return ks_values


def dft(N: int, optimize: bool = False, **kwargs):
    r"""
    Return a :py:class:`LazyLinOp` `L` with the Butterfly structure
    corresponding to the Discrete-Fourier-Transform (DFT).

    Shape of ``L`` is $\left(N,~N\right)$ where
    $N=2^n$ must be a power of two.

    Args:
        N: ``int``
            Size of the DFT. $N$ must be a power of two.
        optimize: ``bool``, optional
            :octicon:`alert-fill;1em;sd-text-danger`
            Optimization usually results in the most optimized
            implementation, but the optimization process may be time
            consuming, depending notably on the size of the factors,
            on the backend
            (see :py:func:`lazylinop.butterfly.ksm` for more details),
            on the dtype and on the device of the ``ks_values``.
            The default value is ``False``.

    Kwargs:
        Additional arguments ``ksm_backend``, ``ksm_params``,
        ``dtype`` and ``device`` of the ``ks_values``
        to pass to :py:func:`ksm` function.
        The default values are ``'xp'``, ``None``,
        ``complex128`` and ``'cpu'``.
        See :py:func:`ksm` for more details.
        Infer the namespace (see
        `array-api-compat <https://data-apis.org/array-api-compat/>`_
        for more details)
        of ``L.ks_values`` from ``dtype`` and ``device`` arguments.
        By default, namespace of ``L.ks_values`` is ``numpy``
        and dtype is ``'complex128'``.

    Returns:
        :py:class:`LazyLinOp` `L` corresponding to the DFT.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import dft as bdft
        >>> from lazylinop.signal import dft as sdft
        >>> N = 2 ** 5
        >>> x = np.random.randn(N)
        >>> y = bdft(N) @ x
        >>> z = sdft(N) @ x
        >>> np.allclose(y, z)
        True
    """
    if not (((N & (N - 1)) == 0) and N > 0):
        raise ValueError("N must be a power of two.")
    ksm_backend = kwargs.get("ksm_backend", 'xp')
    dtype = kwargs.get('dtype', 'complex128')
    device = kwargs.get('device', 'cpu')
    ksv = _dft_square_dyadic_ks_values(N, dtype=dtype, device=device)
    if optimize:
        # Optimize ks_values.
        ksv = _optimize(
            ksv,
            strategy=kwargs.get("opt_strategy", 'benchmark'),
            params=kwargs.get("opt_params", {'backend': ksm_backend}),
        )
    return KsmPermLazyLinOp(
        ksv,
        backend=kwargs.get("ksm_backend", 'xp'),
        params=kwargs.get("ksm_params", None),
        bitrev_perm='right',
        interval=kwargs.get('interval', (0, N)),
    )
