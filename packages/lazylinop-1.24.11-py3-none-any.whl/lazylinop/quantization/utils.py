from array_api_compat import array_namespace, device


def promote_types(t1, t2):
    """
    Promote to the type in which both ``t1`` and ``t2``
    may be safely cast.

    Args:
        t1, t2: NumPy/CuPy or torch dtype
            ``t1`` and ``t2`` are two dtypes.

    Returns:
        If the two types share the same namespace and
        ``t1`` and ``t2`` are not ``torch.float8_*`` return
        the promoted type, otherwise return ``None``.

    Examples:
        >>> import numpy as np
        >>> t1 = np.dtype('float16')
        >>> t2 = np.dtype('float64')
        >>> promote_types(t1, t2) == t2
        True
        >>> import torch
        >>> t1 = torch.float16
        >>> t2 = torch.bfloat16
        >>> promote_types(t1, t2) == torch.float32
        True
        >>> t1 = torch.float32
        >>> t2 = torch.bfloat16
        >>> promote_types(t1, t2) == t1
        True
        >>> t1 = torch.float8_e4m3fn
        >>> t2 = torch.float32
        >>> promote_types(t1, t2) is None
        True

    .. seealso::

        - `NumPy promote <https://numpy.org/doc/stable/reference/
          generated/numpy.promote_types.html>`_,
        - `PyTorch promote <https://docs.pytorch.org/docs/stable/
          generated/torch.promote_types.html>`_.
    """

    # Infer namespace.
    if 'torch' in str(t1) and 'torch' in str(t2):
        import array_api_compat.torch as xp
    elif 'torch' not in str(t1) and 'torch' not in str(t2):
        import array_api_compat.numpy as xp
    else:
        return None

    try:
        return xp.promote_types(t1, t2)
    except RuntimeError:
        # RuntimeError: Promotion for Float8 Types is not supported,
        # attempted to promote Float8_e5m2(e4m3fn) and Float
        if 'torch.float8_e' in str(t1) and 'torch.float8_e' in str(t2):
            return None


class _info():

    def __init__(self, dtype, nexp=None, nmant=None):

        # Infer array namespace.
        try:
            import array_api_compat.torch as xp
        except ModuleNotFoundError:
            xp = None
        if xp is not None and isinstance(dtype, xp.dtype):
            _is_torch = True
        else:
            import array_api_compat.numpy as xp
            _is_torch = False

        _f = xp.finfo(dtype)

        # Copy attribute value.
        for a in dir(_f):
            if a.startswith('__'):
                continue
            self.__setattr__(a, _f.__getattribute__(a))

        # If dtype is a torch.dtype add nmant and nexp attributes.
        if _is_torch:
            self.nexp = nexp
            self.nmant = nmant

        del _f

    def __repr__(self):
        msg = ""
        for a in dir(self):
            if a.startswith('_'):
                continue
            msg = msg + f"{a}={self.__getattribute__(a)}\n"
        return msg


def finfo(dtype):
    """
    Get info about the numerical properties of ``dtype``.
    ``dtype`` is a floating point type.
    If ``dtype`` is a ``torch.dtype`` add ``nmant`` and
    ``nexp`` attributes.

    Args:
        dtype:
            Get info about this dtype.

    Returns:
        An object that stores the numerical properties
        of ``dtype``.

    Examples:
        >>> import torch
        >>> from lazylinop.quantization import finfo
        >>> f = finfo(torch.bfloat16)
        >>> f.nmant
        7

    .. seealso::
        - `NumPy finfo <https://numpy.org/doc/stable/reference/
          generated/numpy.finfo.html>`_,
        - `PyTorch finfo <https://docs.pytorch.org/docs/
          stable/type_info.html>`_.
    """
    # AttributeError: 'torch.finfo' object has no attribute 'nmant'
    try:
        import array_api_compat.torch as xp
    except ModuleNotFoundError:
        xp = None
    if xp is not None and isinstance(dtype, xp.dtype):
        try:
            x = xp.asarray([1.0, 1.0], dtype=dtype).numpy()
            f = _info(x.dtype)
        except TypeError:
            if str(dtype) == 'torch.float8_e4m3fn':
                f = _info(dtype, 4, 3)
            elif str(dtype) == 'torch.float8_e5m2':
                f = _info(dtype, 5, 2)
            elif str(dtype) == 'torch.bfloat16':
                f = _info(dtype, 8, 7)
            elif str(dtype) == 'torch.complex32':
                f = _info(dtype, 5, 10)
    else:
        f = _info(dtype)
    return f


def _nmant(dtype):
    from numpy import finfo as np_finfo
    # AttributeError: 'torch.finfo' object has no attribute 'nmant'
    try:
        import array_api_compat.torch as xp
    except ModuleNotFoundError:
        xp = None
    if xp is not None and isinstance(dtype, xp.dtype):
        try:
            x = xp.asarray([1.0], dtype=dtype).numpy()
            t = np_finfo(x.dtype).nmant
        except TypeError:
            if str(dtype) == 'torch.float8_e4m3fn':
                t = 3
            elif str(dtype) == 'torch.float8_e5m2':
                t = 2
            elif str(dtype) == 'torch.bfloat16':
                t = 7
            elif str(dtype) == 'torch.complex32':
                t = 10
    else:
        t = np_finfo(dtype).nmant
    return t


def _map_2d_to_4d(ksv, ix, iy):
    """
    Map 2d rows ``ix`` and columns ``iy`` to 4d indices.

    Args:
        ksv: 4d array
            A 4d array ``ks_values``.
            Map 2d indexing to 4d indexing using
            ``ix = i_a * b * d + i_b * d + i_d`` and
            ``iy = i_a * c * d + i_c * d + i_d``.
        ix: ``list`` or 1d array
            Row indexes.
        iy: ``list`` or 1d array
            Column indexes.
    """
    xp = array_namespace(ksv)
    _device = device(ksv)
    a, b, c, d = ksv.shape
    if isinstance(ix, list):
        _ix = xp.asarray(ix, device=_device)
    else:
        _ix = ix
    i_a = _ix // (b * d)
    i_b = (_ix - i_a * b * d) // d
    if isinstance(iy, list):
        _iy = xp.asarray(iy, device=_device)
    else:
        _iy = iy
    i_c = (_iy - i_a * c * d) // d
    i_d = _ix - i_a * b * d - i_b * d
    return i_a, i_b, i_c, i_d


def _rerr(L, L1, L2):
    r"""
    Probabilistic estimation of the relative errors
    $\|L-L_1\|_F/\|L\|_F$ and $\|L-L_2\|_F/\|L\|_F$.

    Args:
        L:
            Reference :py:func:`lazylinop.butterfly.ksm`.
        L1:
            First :py:func:`lazylinop.butterfly.ksm`.
        L2:
            Second :py:func:`lazylinop.butterfly.ksm`.

    Returns:
        Relative errors.
    """

    if L.ks_values[0].dtype != L1.ks_values[0].dtype:
        raise Exception("L.ks_values[0].dtype and" +
                        " L1.ks_values[0].dtype must be the same.")
    if L1.ks_values[0].dtype != L2.ks_values[0].dtype:
        raise Exception("L1.ks_values[0].dtype and" +
                        " L2.ks_values[0].dtype must be the same.")
    if array_namespace(L.ks_values[0]) != array_namespace(
            L1.ks_values[0]):
        raise Exception("L.ks_values[0] and L1.ks_values[0]" +
                        " must share the same namespace.")
    if array_namespace(L1.ks_values[0]) != array_namespace(
            L2.ks_values[0]):
        raise Exception("L1.ks_values[0] and L2.ks_values[0]" +
                        " must share the same namespace.")

    n, b = L.shape[1], min(L.shape[1], 1024)
    xp = array_namespace(L.ks_values[0])
    _device = L.ks_values[0].device
    _dtype = L.ks_values[0].dtype
    # Generate batch of random vectors.
    if 'torch' in str(xp.__package__):
        W = xp.randn(n, b).to(dtype=_dtype, device=_device)
    else:
        W = xp.random.randn(n, b).astype(_dtype)
    # Compute L @ W.
    W_true = L @ W
    W1 = L1 @ W
    W2 = L2 @ W
    # Compute relative errors.
    nW = xp.linalg.norm(W_true, ord='fro')
    rerr1 = xp.linalg.norm(W_true - W1, ord='fro') / nW
    rerr2 = xp.linalg.norm(W_true - W2, ord='fro') / nW
    return rerr1, rerr2
