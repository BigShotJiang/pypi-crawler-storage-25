from array_api_compat import array_namespace
from lazylinop.quantization import chop, upcast_downcast
from lazylinop.quantization.complex_utils import (
    _c,
    _get_centroids_accum,
    _generate_midpoints,
    _generate_directions,
    _get_centroids,
    _find_e_max,
    _find_e_min,
    _normalize_direction_set
)
from lazylinop.quantization.borders import build_tiling_domain
from lazylinop.quantization.utils import _nmant, _map_2d_to_4d
from lazylinop.butterfly import KsmLazyLinOp


def _croquant(
        x,
        y,
        targetx,
        delta: int = 0,
        targety=None,
        use_cplx128: bool = True,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Returns a quantization for a rank-one matrix according to parameter delta.

    Set ``delta = 0`` to only have the centroids on the accumulation lines.

    Args:
        x: 2d array of shape (m, 1)
            Vector of size $m$ to quantize.
        y: 2d array of shape (n, 1)
            Vector of size $n$ to quantize.
        targetx: NumPy/CuPy or torch dtype
            Target dtype of the quantization for $x$.
        delta: ``int``, optional
            Parameter that controls the number of breaklines in the algorithm.
            The default value is $2$.
        targety: NumPy/CuPy or torch dtype, optional
            Target dtype of the quantization for $y$.
            The default value is ``None``
            and corresponds to ``targety = targetx``.
        use_cplx128: ``bool``, optional
            - ``True`` computes using ``'complex128'``.
            - ``False`` computes using ``x.dtype``.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        Quantized version $\hat{x}$ and $\hat{y}$ of
        $x$ and $y$, their scaling parameters and relative error.
    """
    tx = _nmant(targetx)
    if targety is None:
        ty = tx
    else:
        ty = _nmant(targety)
    # FIXME: tx != ty.
    _use_t = False
    if isinstance(t, int) and t < tx:
        tx, ty = t, t
        _use_t = True

    if x.shape[0] <= y.shape[0]:
        normalized_direction_set = _normalize_direction_set(
            _generate_directions(x[:, 0]))
        border = build_tiling_domain(normalized_direction_set, tx)
        _x, _y = x, y
    else:
        normalized_direction_set = _normalize_direction_set(
            _generate_directions(y[:, 0]))
        border = build_tiling_domain(normalized_direction_set, ty)
        _x, _y = y, x
        tx, ty = ty, tx

    # Use xp.complex128 to use extend form of the error
    # C_{x,y}(hat{x},hat{y})=||xy^T-hat{x}hat{y}^T||^2.
    _already_cplx128 = 'complex128' in str(x.dtype)
    if not _already_cplx128:
        _x = xp.asarray(_x, dtype=xp.complex128)
        _y = xp.asarray(_y, dtype=xp.complex128)

    xp = array_namespace(x)
    x_approx = xp.asarray(_x, copy=True)
    y_approx = xp.asarray(_y, copy=True)
    lbd_approx, mu_approx = 0, 0
    old_rerr = xp.inf

    centroids_accum = _get_centroids_accum(
        normalized_direction_set, tx, border)
    if delta > 0:
        e_max = _find_e_max(normalized_direction_set, tx, border)
        e_min = _find_e_min(normalized_direction_set, tx, border)

    # Search the best scaling factor among the centroids.
    if delta > 0:
        midpoint_set = _generate_midpoints(tx, e_max, e_min - delta)
        centroids = xp.asarray(
            centroids_accum + _get_centroids(
                normalized_direction_set, midpoint_set, border),
            device=_x.device,
        )
    else:
        centroids = xp.asarray(
            centroids_accum + [],
            device=_x.device,
        )
    # Compute batch of centroids.
    C = centroids.shape[0]
    batch = min(C, int(1e9 / (_x.nbytes * centroids.dtype.itemsize)))
    mem = _x.nbytes * batch * centroids.dtype.itemsize
    while (C % batch) != 0 or mem > 1e9:
        batch -= 1
        mem = _x.nbytes * batch * centroids.dtype.itemsize
    for i in range(0, C, batch):
        centroid = centroids[i:(i + batch)].reshape(1, -1)
        if rnd == "upcast_downcast" and not _use_t:
            x_hat = upcast_downcast(_x * centroid, targetx)
        else:
            x_hat = chop(_x * centroid, tx)

        # Shape of mu is (1, batch).
        mu = xp.conj(_x).reshape(1, -1) @ x_hat / (
            xp.linalg.norm(x_hat, axis=0, ord=2) ** 2
        )
        assert x_hat.shape == (_x.shape[0], batch)
        assert mu.shape == (1, batch)
        if rnd == "upcast_downcast" and not _use_t:
            y_hat = upcast_downcast(_y * mu, targety)
        else:
            y_hat = chop(_y * mu, ty)

        new_rerr = _c(_x, _y, x_hat, y_hat, True)
        assert new_rerr.shape == (1, batch)
        idx = xp.argmin(new_rerr, axis=1)[0]
        if new_rerr[0, idx] < old_rerr:
            x_approx = xp.asarray(
                x_hat[:, idx], copy=True).reshape(-1, 1)
            y_approx = xp.asarray(
                y_hat[:, idx], copy=True).reshape(-1, 1)
            lbd_approx, mu_approx = centroid[0, idx], mu[0, idx]
            old_rerr = new_rerr[0, idx]

    if use_cplx128 and not _already_cplx128:
        if rnd == "upcast_downcast":
            lbd_approx = xp.asarray(
                upcast_downcast(lbd_approx, x.dtype), dtype=x.dtype)
            mu_approx = xp.asarray(
                upcast_downcast(mu_approx, x.dtype), dtype=x.dtype)
        else:
            lbd_approx = xp.asarray(
                chop(lbd_approx, x.dtype), dtype=x.dtype)
            mu_approx = xp.asarray(
                chop(mu_approx, x.dtype), dtype=x.dtype)

    if x.shape[0] <= y.shape[0]:
        return x_approx, y_approx, lbd_approx, mu_approx, old_rerr
    else:
        return y_approx, x_approx, mu_approx, lbd_approx, old_rerr


def _find_optim_product_complex(
        X,
        Y,
        targetx,
        targety,
        delta: int = 0,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Finds the optimal quantization for a product of two matrices,
    $X$ and $Y$, when the rank-one matrices $x_iy_i^\top$, where
    $x_i$ and $y_i$ are the corresponding columns of $X$ and $Y$,
    have disjoints supports.

    Args:
        X: :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            Left :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            of shape $m\times r$ to quantize.
        Y: :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            Right :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            of shape $r\times n$ to quantize.
        targetx: NumPy/CuPy or torch dtype
            Target dtype of the quantization for $X$.
        targety: NumPy/CuPy or torch dtype
            Target dtype of the quantization for $Y$.
        delta: ``int``, optional
            Parameter that controls the number of
            breaklines in the algorithm.
            The default value is $2$.
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        Quantized version $\hat{X}$ and $\hat{Y}$ of $X$ and $Y$.
    """
    tx, ty = _nmant(targetx), _nmant(targety)
    # FIXME: tx != ty.
    if isinstance(t, int) and t < tx:
        tx, ty = t, t
    xp = array_namespace(X.ks_values[0])
    _dtype = X.ks_values[0].dtype
    _device = X.ks_values[0].device
    lbd = xp.zeros(X.shape[1], dtype=_dtype)
    mu = xp.zeros(X.shape[1], dtype=_dtype)
    batch = 1
    u = xp.zeros((Y.shape[0], batch), dtype=_dtype, device=_device)

    # Turn Xhat and Yhat to ksm later on.
    if len(X.ks_values) == 1:
        Xhat = xp.asarray(X.ks_values[0], copy=True)
        Xhat[Xhat != 0] = 1
    else:
        a1, b1, _, d1 = X.ks_values[0].shape
        an, _, cn, dn = X.ks_values[-1].shape
        a, b, c, d = a1, (b1 * d1) // dn, (an * cn) // a1, dn
        Xhat = xp.zeros((a, b, c, d), dtype=X.ks_values[0].dtype,
                        device=X.ks_values[0].device)
    if len(Y.ks_values) == 1:
        Yhat = xp.asarray(Y.ks_values[0], copy=True)
        Yhat[Yhat != 0] = 1
    else:
        a1, b1, _, d1 = Y.ks_values[0].shape
        an, _, cn, dn = Y.ks_values[-1].shape
        a, b, c, d = a1, (b1 * d1) // dn, (an * cn) // a1, dn
        Yhat = xp.zeros((a, b, c, d), dtype=Y.ks_values[0].dtype,
                        device=Y.ks_values[0].device)

    # Extract column per batch.
    a, b, c, d = X.ks_values[0].shape
    n = a * c * d
    for i in range(0, n, batch):
        # Extract columns i:(i+batch).
        u[range(i, (i + batch)), range(batch)] = 1
        xi = X @ u
        yi = Y.H @ u
        u[range(i, (i + batch)), range(batch)] = 0
        for j in range(batch):
            nzx = xp.nonzero(xi[:, j])[0]
            nz_xi = xi[nzx, j].reshape(-1, 1)
            nzy = xp.nonzero(yi[:, j])[0]
            nz_yi = yi[nzy, j].reshape(-1, 1)
            xsq, ysq, l, m, _ = _croquant(
                nz_xi, nz_yi, targetx, delta, targety, t=t
            )
            lbd[i + j], mu[i + j] = l, m
            # From 2d xsq to 4d Xhat
            Xhat[_map_2d_to_4d(Xhat, nzx, [i + j])] = xsq.reshape(-1)
            Yhat[
                _map_2d_to_4d(
                    Yhat, [i + j], nzy)] = xp.conj(ysq.T).reshape(-1)

    return Xhat, Yhat, lbd, mu


def _cplx_qbutterfly(
        L,
        target,
        order: str = "l2r",
        delta: int = 0,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Optimal quantization of a Butterfly operator ``L`` to a target format
    with ``t = finfo(target).nmant`` bits in mantissa of ``target`` dtype.

    Args:
        L: :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            Butterfly operator to be quantized, described either as
            a lazy linear operator ``L`` obtained either with
            :py:func:`lazylinop.butterfly.ksm` or with
            :py:func:`lazylinop.butterfly.ksd` using a square-dyadic chain.
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
        delta: ``int``, optional
            Parameter that controls the number of breaklines in the algorithm.
        order: ``str``, optional

            - ``"l2r"`` left-to-right
            - ``"pairwise"`` pairwise
            - ``"r2l"`` right-to-left
        rnd: ``str``, optional

            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        A tuple (list of 4d quantized arrays,
        list of 4d RTN strategy arrays).
    """
    xp = array_namespace(L.ks_values[0])
    K = len(L.ks_values)
    Lq = [None] * K

    _t = _nmant(target)
    _use_t = False
    if isinstance(t, int) and t < _t:
        _t = t
        _use_t = True

    # Round-to-nearest strategy.
    Lrtn = _cplx_qbutterfly_strategy(
        L, target, strategy="rtn", rnd="upcast_downcast", t=t)

    _is_list = isinstance(L.params, list)

    if order == "pairwise":
        for k in range(K // 2):

            odd = KsmLazyLinOp(
                L.ks_values[2 * k],
                backend=L.backend,
                params=L.params[2 * k] if _is_list else None,
            )
            even = KsmLazyLinOp(
                L.ks_values[2 * k + 1],
                backend=L.backend,
                params=L.params[2 * k + 1] if _is_list else None,
            )

            odd_hat, even_hat, _, _ = _find_optim_product_complex(
                odd,
                even,
                target,
                target,
                delta,
                t=t,
            )

            Lq[2 * k], Lq[2 * k + 1] = odd_hat, even_hat

        if K % 2 != 0:
            last = L.ks_values[K - 1]
            if rnd == "upcast_downcast" and not _use_t:
                Lq[K - 1] = upcast_downcast(last, target)
            else:
                Lq[K - 1] = chop(last, _t)

        return Lq, Lrtn
    elif order == "l2r":

        # FIXME: use a KsmLazyLinOp even if there is
        # only one ks_values?
        X = KsmLazyLinOp(
            L.ks_values[0],
            backend=L.backend,
            params=L.params[0] if _is_list else None,
        )
        Y = KsmLazyLinOp(
            L.ks_values[1:],
            backend=L.backend,
            params=L.params[1:] if _is_list else None,
        )

        for k in range(1, K - 1):
            X_hat, _, _, Mu = _find_optim_product_complex(
                X,
                Y,
                target,
                target,
                delta,
                t=t,
            )

            Lq[k - 1] = X_hat

            # FIXME: use a KsmLazyLinOp even if there is
            # only one ks_values?
            a, b, c, d = L.ks_values[k].shape
            X = KsmLazyLinOp(
                (
                    xp.conj(Mu).reshape(-1, 1) *
                    L.ks_values[k].swapaxes(2, 3).reshape(a * b * d, c)
                ).reshape(a, b, d, c).swapaxes(2, 3),
                backend=L.backend,
                params=L.params[k] if _is_list else None,
            )
            Y = KsmLazyLinOp(
                L.ks_values[(k + 1):],
                backend=L.backend,
                params=L.params[(k + 1):] if _is_list else None,
            )

        X_hat, Y_hat, _, _ = _find_optim_product_complex(
            X,
            Y,
            target,
            target,
            delta,
            t=t,
        )
        Lq[K - 2], Lq[K - 1] = X_hat, Y_hat

        return Lq, Lrtn
    elif order == "r2l":

        # FIXME: use a KsmLazyLinOp even if there is
        # only one ks_values?
        X = KsmLazyLinOp(
            L.ks_values[:-1],
            backend=L.backend,
            params=L.params[:-1] if _is_list else None,
        )
        Y = KsmLazyLinOp(
            L.ks_values[-1],
            backend=L.backend,
            params=L.params[-1] if _is_list else None,
        )

        for k in range(1, K - 1):
            _, Y_hat, Lbd, _ = _find_optim_product_complex(
                X,
                Y,
                target,
                target,
                delta,
                t=t,
            )

            Lq[K - 1 - (k - 1)] = Y_hat

            # FIXME: use a KsmLazyLinOp even if there is
            # only one ks_values?
            X = KsmLazyLinOp(
                L.ks_values[: -(k + 1)],
                backend=L.backend,
                params=L.params[: -(k + 1)] if _is_list else None,
            )
            a, b, c, d = L.ks_values[-(k + 1)].shape
            Y = KsmLazyLinOp(
                (
                    L.ks_values[-(k + 1)].swapaxes(0, 1).reshape(b, a * c * d) *
                    Lbd.reshape(1, -1)
                ).reshape(b, a, c, d).swapaxes(0, 1),
                # (
                #     Lbd.reshape(-1, 1) *
                #     L.ks_values[-(k + 1)].swapaxes(2, 3).reshape(a * b * d, c)
                # ).reshape(a, b, d, c).swapaxes(2, 3),
                backend=L.backend,
                params=L.params[-(k + 1)] if _is_list else None,
            )

        X_hat, Y_hat, _, _ = _find_optim_product_complex(
            X,
            Y,
            target,
            target,
            delta,
            t=t,
        )
        Lq[0], Lq[1] = X_hat, Y_hat

        return Lq, Lrtn
    else:
        raise NotImplementedError


def _cplx_qbutterfly_strategy(
        L,
        target,
        strategy: str = "rtn",
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Quantizes a product of butterfly matrices by using the approach
    defined by the ``strategy`` argument.

    Args:
        L: :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            Butterfly operator to be quantized, described either as
            a lazy linear operator ``L`` obtained either with
            :py:func:`lazylinop.butterfly.ksm` or with
            :py:func:`lazylinop.butterfly.ksd` using a square-dyadic chain.
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
        strategy: ``str``, optional

            - ``"rtn"`` round-to-nearest
            - ``"stochastic"`` stochastic
            - ``"fixed"`` fixed-point
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        List of 4d arrays that corresponds to
        ``strategy`` argument applied to ``L.ks_values``.
        Of note, dtype is left unchanged.
    """
    _t = _nmant(target)
    _use_t = False
    if isinstance(t, int) and t < _t:
        _t = t
        _use_t = True
    if strategy == "rtn":
        if rnd == "upcast_downcast" and not _use_t:
            return [
                upcast_downcast(k, target) for k in L.ks_values
            ]
        else:
            return [chop(k, _t) for k in L.ks_values]
    elif strategy == "stochastic":
        return [
            chop(k, _t, stochastic=True) for k in L.ks_values
        ]
    elif strategy == "fixed":
        return [
            chop(k, _t, fixed=True) for k in L.ks_values
        ]
    else:
        raise NotImplementedError
