from lazylinop.butterfly import Chain, KsmLazyLinOp, KsmPermLazyLinOp
from lazylinop.quantization.algo import (
    _algo7_3_left2right,
    _algo7_2_pairwise,
    _rerr,
)
from lazylinop.quantization.utils import finfo
# from lazylinop.quantization.utils import promote_types
from array_api_compat import (
    array_namespace, is_array_api_obj,
    is_cupy_array, is_numpy_array, is_torch_array)
try:
    from lazylinop.quantization.complex_algo import _cplx_qbutterfly
except ModuleNotFoundError:
    from warnings import warn
    warn(
        "Please install shapely to use complex quantization.")


def _qhelper(
        L,
        target,
        order: str = 'l2r',
        delta: int = 0,
        rnd: str = "upcast_downcast",
        t: int = None,
        what: str = 'qbutterfly',
):

    if not (
            isinstance(L, list) or
            isinstance(L, KsmLazyLinOp) or
            isinstance(L, KsmPermLazyLinOp)
    ):
        raise Exception(
            "L must be a list of 4d arrays or a Ksm*LazyLinOp.")

    # Infer array_namespace, dtype and device from L.
    if hasattr(L, "ks_values"):
        p = len(L.ks_values)
        if p < 2:
            raise Exception("len(L.ks_values) must be >= 2.")
        xp = array_namespace(L.ks_values[0])
        dtype = L.ks_values[0].dtype
        device = L.ks_values[0].device
        for i in range(1, p):
            if xp != array_namespace(L.ks_values[i]):
                raise Exception("Each ks_values must" +
                                " have the same array namespace.")
            if dtype != L.ks_values[i].dtype:
                raise Exception("Each ks_values must" +
                                " have the same dtype.")
            if device != L.ks_values[i].device:
                raise Exception("Each ks_values must" +
                                " have the same device.")
        # Shape.
        M, N = L.shape
        patterns = [L.ks_values[0].shape, L.ks_values[1].shape]
    elif isinstance(L, list) and is_array_api_obj(L[0]):
        p = len(L)
        if p < 2:
            raise Exception("len(L) must be >= 2.")
        xp = array_namespace(L[0])
        dtype = L[0].dtype
        device = L[0].device
        patterns = [L[0].shape, L[1].shape]
        for i in range(p):
            if not is_array_api_obj(L[i]):
                raise Exception("Each element of the list L" +
                                " must be a 4d array.")
            if xp != array_namespace(L[i]):
                raise Exception("Each element of the list L must" +
                                " have the same array namespace.")
            if dtype != L[i].dtype:
                raise Exception("Each element of the list L must" +
                                " have the same dtype.")
            if device != L[i].device:
                raise Exception("Each element of the list L must" +
                                " have the same device.")
        # Shape.
        a, b, _, d = L[0].shape
        M = a * b * d
        a, _, c, d = L[-1].shape
        N = a * c * d
    if what == 'qmonarch':
        # Check that the patterns correspond to a Monarch chain.
        _, _p, _q, _ = patterns[0]
        a, b, _, d = patterns[0]
        M = a * b * d
        a, _, c, d = patterns[1]
        N = a * c * d
        chain = Chain.monarch((M, N), _p, _q)
        for i in range(chain.n_patterns):
            shape = (
                L.ks_values[i] if hasattr(L, "ks_values") else L[i]).shape
            if shape != chain.ks_patterns[i]:
                raise Exception(
                    "Shapes of L must correspond to a square-dyadic chain.")
    elif what == 'qbutterfly':
        # Check that the shapes correspond to square-dyadic chain.
        chain = Chain.square_dyadic((M, N))
        for i in range(chain.n_patterns):
            shape = (
                L.ks_values[i] if hasattr(L, "ks_values") else L[i]).shape
            if shape != chain.ks_patterns[i]:
                raise Exception(
                    "Shapes of L must correspond to a square-dyadic chain.")
    else:
        raise NotImplementedError

    # L is NumPy/CuPy arrays and target dtype is torch.
    # Convert L to torch tensors?
    if hasattr(L, "ks_values"):
        if not is_torch_array(L.ks_values[0]) and 'torch' in str(target):
            # Update array namespace.
            import array_api_compat.torch as xp
            # FIXME: xp.asarray(...) raises an error:
            # RuntimeError: could not retrieve buffer from object
            if is_numpy_array(L.ks_values[0]):
                # NumPy array.
                device = 'cpu'
                _ksv = [xp.from_numpy(
                    L.ks_values[i]).to(device=device) for i in range(p)]
            elif is_cupy_array(L.ks_values[0]):
                # CuPy array.
                import array_api_compat.cupy as _xp
                device = f"cuda:{device.id}"
                _ksv = [xp.from_numpy(
                    _xp.asnumpy(
                        L.ks_values[i])).to(device=device) for i in range(p)]
            if hasattr(L, "bitrev_perm"):
                _L = KsmPermLazyLinOp(
                    _ksv,
                    backend=L.backend,
                    bitrev_perm=L.bitrev_perm,
                )
            else:
                _L = KsmLazyLinOp(
                    _ksv,
                    backend=L.backend,
                )
        else:
            _L = L
        # Update dtype and device.
        dtype = _L.ks_values[0].dtype
        device = _L.ks_values[0].device
    elif isinstance(L, list) and is_array_api_obj(L[0]):
        if not is_torch_array(L[0]) and 'torch' in str(target):
            # Update array namespace.
            import array_api_compat.torch as xp
            # FIXME: xp.asarray(...) raises an error:
            # RuntimeError: could not retrieve buffer from object
            if is_numpy_array(L[0]):
                # NumPy array.
                device = 'cpu'
                _L = [xp.from_numpy(L[i]).to(device=device) for i in range(p)]
            elif is_cupy_array(L[0]):
                # CuPy array.
                import array_api_compat.cupy as _xp
                device = f"cuda:{device.id}"
                _L = [xp.from_numpy(
                    _xp.asnumpy(L[i])).to(device=device) for i in range(p)]
        else:
            _L = L
        # Update dtype and device.
        dtype = _L[0].dtype
        device = _L[0].device

    if 'complex' in str(target) and 'complex' not in str(dtype):
        raise Exception("Because target is complex," +
                        " x and y dtype must be complex too.")
    if 'complex' not in str(target) and 'complex' in str(dtype):
        raise Exception("Because x and y dtype is complex," +
                        " target must be complex too.")

    # Number of bits in the mantissa of target.
    _t = finfo(target).nmant
    _use_t = False
    if isinstance(t, int) and t < _t:
        _t = t
        _use_t = True

    # _promote = promote_types(target, dtype)
    if _t >= finfo(dtype).nmant:  # or _promote == dtype:
        # If target >= dtype return a casted copy of L.
        from warnings import warn
        warn("target >= dtype return a casted copy of L.")
        # Cast ks_values and Ksm*LazyLinOp.
        if isinstance(_L, list):
            L0 = KsmLazyLinOp(_L, backend='xp')
            kc = [xp.asarray(k, dtype=target, copy=True) for k in _L]
            Lc = KsmLazyLinOp(kc, backend='xp')
        else:
            L0 = _L
            kc = [xp.asarray(
                k, dtype=target, copy=True) for k in _L.ks_values]
            if hasattr(L, "bitrev_perm"):
                Lc = KsmPermLazyLinOp(
                    kc,
                    backend=L.backend,
                    bitrev_perm=L.bitrev_perm,
                )
            else:
                Lc = KsmLazyLinOp(
                    kc,
                    backend=L.backend,
                )
        n = Lc.shape[1]
        if 'torch' in str(xp.__package__):
            W0 = xp.randn(n, 128).to(dtype=dtype, device=device)
            Wc = W0.to(dtype=target, device=device)
        else:
            W0 = xp.random.randn(n, 128).astype(dtype)
            Wc = W0.astype(target)
        W0 = L0 @ W0
        Wc = Lc @ Wc
        nY = xp.linalg.norm(W0, ord='fro')
        cast_rerr = xp.linalg.norm(W0 - Wc, ord='fro') / nY
        return (Lc if hasattr(_L, "ks_values") else kc, cast_rerr, None)

    # Quantize.
    _L = _L if hasattr(_L, "ks_values") else KsmLazyLinOp(_L, backend="xp")
    if what == 'qbutterfly':
        if 'complex' in str(_L.ks_values[0].dtype):
            q_factors, rtn_factors = _cplx_qbutterfly(
                _L, target, order=order, delta=delta, rnd=rnd, t=_t)
        else:
            if order == 'l2r':
                q_factors, rtn_factors = _algo7_3_left2right(_L, target, rnd, t=_t)
            elif order == 'pairwise':
                q_factors, rtn_factors = _algo7_2_pairwise(_L, target, rnd, t=_t)
            else:
                raise NotImplementedError("order is either 'l2r' or 'pairwise'.")
    elif what == 'qmonarch':
        if 'complex' in str(_L.ks_values[0].dtype):
            q_factors, rtn_factors = _cplx_qbutterfly(
                _L, target, order="pairwise", delta=delta, rnd=rnd, t=_t)
        else:
            q_factors, rtn_factors = _algo7_2_pairwise(_L, target, rnd, t=_t)

    # Probabilistic estimation of the error.
    if isinstance(L, list):
        Q = KsmLazyLinOp(q_factors, backend='xp')
        R = KsmLazyLinOp(rtn_factors, backend='xp')
    else:
        if hasattr(L, "bitrev_perm"):
            Q = KsmPermLazyLinOp(
                q_factors,
                backend=L.backend,
                bitrev_perm=L.bitrev_perm,
            )
            R = KsmPermLazyLinOp(
                rtn_factors,
                backend=L.backend,
                bitrev_perm=L.bitrev_perm,
            )
        else:
            Q = KsmLazyLinOp(q_factors, backend=L.backend)
            R = KsmLazyLinOp(rtn_factors, backend=L.backend)
    opt_rerr, rtn_rerr = _rerr(_L, Q, R)

    # Return ks_values such that ks_values[i].dtype == target.
    q_factors = [
        xp.asarray(i, dtype=target, device=device) for i in q_factors]
    rtn_factors = [
        xp.asarray(i, dtype=target, device=device) for i in rtn_factors]

    if isinstance(L, list):
        return (q_factors, opt_rerr, rtn_rerr)
    else:
        if hasattr(L, "bitrev_perm"):
            Q = KsmPermLazyLinOp(
                q_factors,
                backend=L.backend,
                bitrev_perm=L.bitrev_perm,
            )
        else:
            Q = KsmLazyLinOp(q_factors, backend=L.backend)
        return (Q, opt_rerr, rtn_rerr)
