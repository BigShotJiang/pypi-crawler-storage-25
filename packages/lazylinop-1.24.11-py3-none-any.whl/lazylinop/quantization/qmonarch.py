from lazylinop.quantization.qhelper import _qhelper


def qmonarch(L, target, delta: int = 0, t: int = None):
    r"""
    Optimal quantization of a Monarch operator ``L`` to a target
    format (real or complex) using algorithms from reference
    :ref:`[1, 2] <opt_qmonarch>` with ``t = finfo(target).nmant``
    bits in mantissa of ``target`` dtype.

    Args:
        L:
            Monarch operator to be quantized, described either as:

            - a list of two 4d arrays ``ks_values`` of shapes
              compatible with :py:func:`lazylinop.butterfly.Chain.monarch()`.
            - or a lazy linear operator ``L`` obtained either with
              :py:func:`lazylinop.butterfly.ksm` or with
              :py:func:`lazylinop.butterfly.ksd` using a Monarch chain.
            - an instance of :py:class:`lazylinop.butterfly.KsmLazyLinOp`
            - an instance of :py:class:`lazylinop.butterfly.KsmPermLazyLinOp`
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
            If target is complex, ``L.ks_values`` must be complex too.
        delta: ``int``, optional
            Parameter that controls the number of breaklines
            in the complex quantization algorithm.
            The default value is ``delta = 0`` to only have the centroids
            on the accumulation lines :ref:`[2] <opt_qmonarch>`.
            ``delta`` has no effect when ``L`` has real entries
            or when ``target`` is not a complex dtype.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        A tuple ``(Lq, rerr)`` where ``Lq`` is of the same nature
        as ``L`` but with ``ks_values`` of dtype ``target``
        and ``rerr`` is the quantization relative error.

        .. Note::

            - The ``dtype`` of ``ks_values`` of ``Lq`` is ``target``.
            - If ``target`` is a ``torch.dtype`` and ``ks_values`` of ``L``
              are not torch tensors convert ``ks_values`` before proceeding.
            - If ``ks_values.dtype`` of ``L`` promotes to ``target`` return
              ``(Lc, rerr)`` where ``Lc`` is ``L`` casted to ``target`` dtype.

    Examples:
        >>> import numpy as np
        >>> from lazylinop import LazyLinOp
        >>> from lazylinop.butterfly import Chain, ksm
        >>> from lazylinop.quantization import qmonarch
        >>> M, N = 4, 10
        >>> # base and target dtype.
        >>> base = 'float64'
        >>> target = 'float16'
        >>> chain = Chain.monarch((M, N))
        >>> ksp = chain.ks_patterns
        >>> # List of two random 4d arrays compatible with the Monarch chain.
        >>> ksv = [np.random.randn(*ksp[i]).astype(base) for i in range(2)]
        >>> Lq, rerr = qmonarch(ksv, target)
        >>> isinstance(Lq, list)
        True
        >>> len(Lq) == 2
        True
        >>> Lq[0].dtype == target
        True
        >>> # ksm such that len(L.ks_values) == 2.
        >>> L = ksm(ksv, backend='xp')
        >>> Lq, rerr = qmonarch(L, target)
        >>> isinstance(Lq, LazyLinOp)
        True
        >>> len(Lq.ks_values) == 2
        True
        >>> Lq.ks_values[0].dtype == target
        True
        >>> # Compute L @ X.
        >>> X = np.random.randn(L.shape[1], 128).astype(base)
        >>> Y = L @ X
        >>> # RTN strategy for comparison.
        >>> from lazylinop.quantization import chop, finfo
        >>> t = finfo(target).nmant
        >>> _ksv = [chop(k, t) for k in ksv]
        >>> Lr = ksm(_ksv, backend='xp')
        >>> Yr = Lr @ X
        >>> n = np.linalg.norm(Y, ord='fro')
        >>> rtn_rerr = np.linalg.norm(Yr - Y, ord='fro') / n
        >>> # Optimal error versus RTN error.
        >>> bool(rerr <= rtn_rerr)
        True

    .. seealso::
        - :py:func:`lazylinop.butterfly.ksm`,
        - :py:func:`lazylinop.butterfly.ksd`,
        - :py:func:`lazylinop.butterfly.Chain`,
        - :py:func:`lazylinop.quantization.finfo`,
        - :py:func:`lazylinop.quantization.qrank_one`,
        - :py:func:`lazylinop.quantization.qbutterfly`.

    .. _opt_qmonarch:

        **References:**

        [1] Rémi Gribonval, Theo Mary, Elisa Riccietti.
        Optimal quantization of rank-one matrices in
        floating-point arithmetic—with applications
        to butterfly factorizations. 2023. hal-04125381
        https://inria.hal.science/hal-04125381v1/document

        [2] Maël Chaumette, Rémi Gribonval, Elisa Riccietti.
        CROQuant: Complex Rank-One Quantization Algorithm,
        with Application to Butterfly Factorizations. 2026. hal-05520926
        https://hal.science/hal-05520926
    """
    q, opt_rerr, _ = _qhelper(
        L,
        target,
        delta=delta,
        t=t,
        what='qmonarch',
    )
    return q, opt_rerr
