from array_api_compat import (
    array_namespace, device,
    is_cupy_array, is_numpy_array, is_torch_array)
from lazylinop.quantization.utils import finfo
# from lazylinop.quantization.utils import promote_types
from lazylinop.quantization import chop
from lazylinop.quantization.chop import upcast_downcast
from lazylinop.quantization.algo import _algo5_1_opt_lambda
try:
    from lazylinop.quantization.complex_algo import _croquant
except ModuleNotFoundError:
    from warnings import warn
    warn(
        "Please install shapely to use complex quantization.")


def qrank_one(x, y, target, delta: int = 0, t: int = None):
    r"""
    Find vectors $\hat{x}$ and $\hat{y}$ in the target format
    (real or complex) such that $\hat{x}\hat{y}^H$ is closest
    to $xy^H$ using algorithms of references :ref:`[1, 2] <opt_qrank1>`.

    Args:
        x, y: 1d array
            Column vectors of shape ``(m, 1)`` and ``(n, 1)``
            to be quantized belonging to the same namespace,
            with the same dtype,
            raise an ``Exception`` otherwize.
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
            If target is complex, ``x`` and ``y`` must be complex too.
        delta: ``int``, optional
            Parameter that controls the number of breaklines
            in the complex quantization algorithm.
            The default value is ``delta = 0`` to only have the centroids
            on the accumulation lines :ref:`[2] <opt_qrank1>`.
            ``delta`` has no effect when ``x`` and ``y``
            have real entries or when ``target`` is not a complex dtype.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        A tuple ``(xh, yh, rerr)`` where
        ``xh`` is $\hat{x}$ the quantized $x$,
        ``yh`` is $\hat{y}$ the quantized $y$ and
        ``rerr`` the quantization relative error.

        .. Note::

            - The ``dtype`` of ``xh`` and ``yh`` is ``target``.
            - By construction, ``xh`` is not necessarily close to ``x``,
              ``yh`` is not necessarily close to ``y`` but ``xh @ yh.H``
              is close to ``x @ y.H``.
            - If ``target`` is a ``torch.dtype`` and ``x``, ``y``
              are not torch tensors convert ``x`` and ``y``
              before proceeding.
            - If ``x.dtype`` promotes to ``target`` return
              ``(xc, yc, rerr)`` where ``xc`` and ``yc`` are
              ``x`` and ``y`` casted to ``target`` dtype.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.quantization import qrank_one
        >>> from lazylinop.quantization import chop
        >>> m = np.random.randint(2, high=10)
        >>> n = np.random.randint(2, high=10)
        >>> base = 'float64'
        >>> x = np.random.randn(m, 1).astype(base)
        >>> y = np.random.randn(n, 1).astype(base)
        >>> # Quantize using float16.
        >>> target = 'float16'
        >>> xh, yh, rerr = qrank_one(x, y, target)
        >>> xh.shape == x.shape
        True
        >>> yh.shape == y.shape
        True
        >>> xh.dtype == target
        True
        >>> yh.dtype == target
        True
        >>> # RTN strategy for comparison.
        >>> from lazylinop.quantization import chop, finfo
        >>> t = finfo(target).nmant
        >>> n = np.linalg.norm(x @ y.T, ord='fro')
        >>> xr = chop(x, t)
        >>> yr = chop(y, t)
        >>> rtn_rerr = np.linalg.norm(x @ y.T - xr @ yr.T, ord='fro') / n
        >>> # Optimal error versus RTN error.
        >>> bool(rerr <= rtn_rerr)
        True

    .. seealso::
        - :py:func:`lazylinop.quantization.qmonarch`,
        - :py:func:`lazylinop.quantization.qbutterfly`.

    .. _opt_qrank1:

        **References:**

        [1] Rémi Gribonval, Theo Mary, Elisa Riccietti.
        Optimal quantization of rank-one matrices in
        floating-point arithmetic—with applications
        to butterfly factorizations. 2023. hal-04125381
        https://inria.hal.science/hal-04125381v1/document

        [2] Maël Chaumette, Rémi Gribonval, Elisa Riccietti.
        CROQuant: Complex Rank-One Quantization Algorithm,
        with Application to Butterfly Factorizations. 2026. hal-05520926
        https://hal.science/hal-05520926
    """
    xh, yh, opt_rerr, _ = _qrank_one(x, y, target, delta=delta, t=t)
    return xh, yh, opt_rerr


def _qrank_one(
        x,
        y,
        target,
        delta: int = 0,
        rnd: str = "upcast_downcast",
        use_fp64: bool = True,
        t: int = None,
):

    xp = array_namespace(x)
    if xp != array_namespace(y):
        raise Exception("x and y must have the" +
                        " same array namespace.")

    _dtype = x.dtype
    if _dtype != y.dtype:
        raise Exception("x and y must have the same dtype.")

    if 'complex' in str(target) and 'complex' not in str(_dtype):
        raise Exception("Because target is complex," +
                        " x and y dtype must be complex too.")
    if 'complex' not in str(target) and 'complex' in str(_dtype):
        raise Exception("Because x and y dtype is complex," +
                        " target must be complex too.")

    _device = device(x)
    if _device != device(y):
        raise Exception("x and y must have the same device.")

    if x.ndim != 2 or (x.ndim == 2 and x.shape[1]) != 1 or (
            y.ndim != 2 or (y.ndim == 2 and y.shape[1] != 1)):
        raise Exception("x and y must be column vectors.")

    # x and y are NumPy/CuPy arrays and target dtype is torch.
    # Convert x and y to torch tensors.
    if not is_torch_array(x) and 'torch' in str(target):
        # Update array namespace.
        import array_api_compat.torch as xp
        # FIXME: xp.asarray(...) raises an error:
        # RuntimeError: could not retrieve buffer from object
        if is_numpy_array(x):
            # NumPy array.
            _device = 'cpu'
            _x = xp.from_numpy(x).to(device=_device)
            _y = xp.from_numpy(y).to(device=_device)
        elif is_cupy_array(x):
            # CuPy array.
            import array_api_compat.cupy as _xp
            _device = f"cuda:{_device.id}"
            _x = xp.from_numpy(_xp.asnumpy(x)).to(device=_device)
            _y = xp.from_numpy(_xp.asnumpy(y)).to(device=_device)
    else:
        _x = x
        _y = y
    # Update dtype and device.
    _dtype = _x.dtype
    _device = _x.device

    # Number of bits in the mantissa of target.
    _t = finfo(target).nmant
    _use_t = False
    if isinstance(t, int) and t < _t:
        _t = t
        _use_t = True

    xy = _x @ xp.conj(_y).T
    nxy = xp.linalg.norm(xy, ord="fro")

    # _promote = promote_types(target, _dtype)
    if _t >= finfo(_dtype).nmant:  # or _promote == _dtype:
        # If target >= _dtype return a casted copy of x and y.
        from warnings import warn
        warn("target >= dtype return a casted copy of x and y.")
        _xc = xp.asarray(_x, dtype=target, copy=True)
        _yc = xp.asarray(_y, dtype=target, copy=True)
        rerr = xp.linalg.norm(
            xy - _xc @ xp.conj(_yc).T, ord='fro') / nxy
        return (_xc, _yc, rerr, None)

    # Compute hat(x) and hat(y).
    if 'complex' in str(x.dtype):
        xh, yh, lopt, mopt, opt_rerr = _croquant(
            _x, _y, target, delta, targety=None,
            use_cplx128=use_fp64, rnd=rnd, t=t)
    else:
        xh, yh, lopt, mopt, opt_rerr = _algo5_1_opt_lambda(
            _x, _y, target, dochopy=True, use_fp64=use_fp64, rnd=rnd)

    xh = xp.asarray(xh, dtype=target, device=xh.device)
    yh = xp.asarray(yh, dtype=target, device=xh.device)

    # Use base dtype to compute relative error.
    # Uncomment the following lines if you wish to use target dtype.
    # opt_rerr = xp.linalg.norm(
    #     xy - xp.asarray(xh @ xp.conj(yh).T, dtype=xy.dtype), ord="fro") / nxy

    # RTN strategy for comparison.
    # xr = xp.asarray(chop(_x, target), dtype=target)
    # yr = xp.asarray(chop(_y, target), dtype=target)
    # rtn_rerr = xp.linalg.norm(
    #     xy - xp.asarray(xr @ xp.conj(yr).T, dtype=xy.dtype), ord="fro") / nxy
    if rnd == "upcast_downcast" and not _use_t:
        xr, yr = upcast_downcast(_x, target), upcast_downcast(_y, target)
    else:
        xr, yr = chop(_x, _t), chop(_y, _t)
    rtn_rerr = xp.linalg.norm(xy - xr @ xp.conj(yr).T, ord="fro") / nxy

    return xh, yh, opt_rerr, rtn_rerr
