from array_api_compat import (
    array_namespace, device, is_array_api_obj)
from lazylinop import islazylinop
# from lazylinop.butterfly import fuse
from lazylinop.butterfly import ksm
# from lazylinop.butterfly import optimize
from lazylinop.quantization import chop, upcast_downcast
from lazylinop.quantization.utils import (
    _nmant, _map_2d_to_4d, _rerr)


def _rtn_strategy(
        L,
        target,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    RTN strategy using ``finfo(t).nmant`` bits in mantissa.

    Args:
        L:
            Apply RTN strategy to ``ks_values`` of ``L``.
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        List of 4d arrays that corresponds to
        RTN strategy applied to ``L.ks_values``.
        Of note, dtype is left unchanged.
    """
    _t = _nmant(target)
    _use_t = False
    if isinstance(t, int) and t < _t:
        _t = t
        _use_t = True
    # Turn ks_values to ksm later on.
    if rnd == "upcast_downcast" and not _use_t:
        rtn_factors = [
            upcast_downcast(k, target) for k in L.ks_values]
    else:
        rtn_factors = [chop(k, _t) for k in L.ks_values]
    return rtn_factors


def _algo7_1(
        X,
        Y,
        target,
        dochopy: bool,
        return_ksv: bool = True,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Implements Algorithm 7.1.

    Args:
        X: 4d array
            An array-api compatible 4d array of ks_values.
        Y: :py:func:`lazylinop.butterfly.ksm`
            ksm with only one ``ks_values``.
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
        dochopy: ``bool``
            - ``True`` if both ``X, Y`` needs to be quantized.
            - ``False`` if only ``X`` needs to be quantized.
        return_ksv: ``bool``, optional
            - ``True`` returns only ``ks_values`` (default)
            - ``False`` returns only :py:func:`lazylinop.butterfly.ksm`
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        A tuple ``(Xhat, Yhat, lambda, mu)``.
    """

    if not hasattr(Y, "ks_values"):
        raise Exception("Y must be lazylinop.butterfly.ksm.")
    if not is_array_api_obj(X):
        raise Exception("X must be an array-api compatible 4d array.")
    if X.ndim != 4:
        raise Exception("X must be a single 4d ks_values.")

    # Get namespace, dtype and device.
    xp = array_namespace(X)
    _dtype = X.dtype
    _device = device(X)
    t = _nmant(target)
    if rnd == "upcast_downcast":
        _target = target
    else:
        _target = t

    # Turn Xhat and Yhat to ksm later on.
    Xhat = xp.asarray(X, copy=True)
    Xhat[Xhat != 0] = 1
    if dochopy:
        if len(Y.ks_values) == 1:
            Yhat = xp.asarray(Y.ks_values[0], copy=True)
            Yhat[Yhat != 0] = 1
        else:
            a1, b1, _, d1 = Y.ks_values[0].shape
            an, _, cn, dn = Y.ks_values[-1].shape
            a, b, c, d = a1, (b1 * d1) // dn, (an * cn) // a1, dn
            Yhat = xp.zeros((a, b, c, d), dtype=Y.ks_values[0].dtype,
                            device=Y.ks_values[0].device)
    else:
        Yhat = None

    # Extract column per batch.
    a, b, c, d = X.shape
    n = a * c * d
    batch = min(512, n)
    while n % batch != 0 and batch > 1:
        batch -= 1
    u = xp.zeros((Y.shape[0], batch),
                 dtype=_dtype, device=_device)
    li = xp.empty(n, dtype=_dtype, device=_device)
    mi = xp.empty(n, dtype=_dtype, device=_device)
    for i in range(0, n, batch):
        # Extract columns i:(i+batch).
        u[range(i, (i + batch)), range(batch)] = 1
        yd = Y.T @ u
        u[range(i, (i + batch)), range(batch)] = 0
        for j in range(batch):
            # Find xd and yd non-zero elements.
            # Get the i-th column.
            # X is a single ks_values ksm.
            a, b, c, d = X.shape
            i_a = (i + j) // (c * d)
            i_c = (i + j - i_a * c * d) // d
            i_d = (i + j) % d
            ix = xp.arange(i_a * b * d + i_d, (i_a + 1) * b * d, d, device=X.device)
            xs = X[i_a, 0:b, i_c, i_d].reshape(-1)
            nz = xp.nonzero(xs)[0]
            ix = ix[nz]
            xs = xs[nz].reshape(-1, 1)
            iy = xp.nonzero(yd[:, j])[0]
            ys = yd[iy, j].reshape(-1, 1)
            # # Because of tranpose get the i-th row.
            # a, b, c, d = Y.ks_values[0].shape
            # i_a = i // (b * d)
            # i_b = (i - i_a * b * d) // d
            # i_d = i % d
            # iy = xp.arange(i_a * c * d + i_d, (i_a + 1) * c * d, d)
            # ys = Y.ks_values[0][i_a, i_b, 0:c, i_d].reshape(-1, 1)
            _, _, lopt, mopt, _ = _algo5_1_opt_lambda(
                xs, ys, _target, dochopy=dochopy, rnd=rnd)
            if rnd == "upcast_downcast":
                xsq = upcast_downcast(lopt * xs, target)
            else:
                xsq = chop(lopt * xs, t)
            li[i + j] = lopt
            mi[i + j] = mopt
            # From 2d xsq to 4d Xhat
            Xhat[_map_2d_to_4d(Xhat, ix, [i + j])] = xsq.reshape(-1)
            if dochopy:
                if rnd == "upcast_downcast":
                    ysq = upcast_downcast(mi[i + j] * ys, target)
                else:
                    ysq = chop(mi[i + j] * ys, t)
                # From 2d xp.conj(ysq.T) to 4d Yhat
                Yhat[
                    _map_2d_to_4d(
                        Yhat, [i + j], iy)] = xp.conj(ysq.T).reshape(-1)
    if return_ksv:
        return Xhat, Yhat if dochopy else None, li, mi
    else:
        return (
            ksm(Xhat, backend='xp'),
            ksm(Yhat, backend='xp') if dochopy else None, li, mi
        )


def _algo7_3_left2right(
        L,
        target,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Given $p$ butterfly factors $L=B_1,\cdots,B_p$ quantizes them with
    ``finfo(target).nmant`` bits using Algorithm 7.1 and
    Algorithm 7.3 (left-to-right heuristic).

    Args:
        L: :py:func:`lazylinop.butterfly.ksm`
            Butterfly factors $L=B_1,\cdots,B_p$.
            Length of ``L.ks_values`` is $p$.
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        A tuple (list of 4d quantized arrays,
        list of 4d RTN strategy arrays).
    """

    if not islazylinop(L):
        raise Exception("L must be a LazyLinOp.")

    # Get namespace, dtype and device.
    xp = array_namespace(L.ks_values[0])
    _dtype = L.ks_values[0].dtype
    _device = device(L.ks_values[0])
    p = len(L.ks_values)

    # Turn q_factors[k] to ksm later on.
    q_factors = [None] * p

    # Left to right strategy.
    X = L.ks_values[0]
    # Fuse consecutive factors to increase performance
    # and because _algo7_1 expects len(X.ks_values) == 1.
    # Avoid redundant fuses.
    if p > 2:
        list_Y = [None] * (p - 2)
        list_Y[p - 3] = [L.ks_values[p - 1]]
        for k in range(p - 4, -1, -1):
            # list_Y[k] = optimize(
            #     [L.ks_values[k + 2]] + list_Y[k + 1],
            #     strategy='memory', params=1, verbose=False,
            # )
            list_Y[k] = [L.ks_values[k + 2]] + list_Y[k + 1]
        # Y = ksm(fuse([L.ks_values[1]] + list_Y[0]), backend='xp')
        Y = ksm([L.ks_values[1]] + list_Y[0], backend='xp')
        for k in range(p - 2):
            # Quantize XY.
            q_factors[k], _, li, mi = _algo7_1(
                X, Y, target, False, return_ksv=True, rnd=rnd, t=t)
            # Compute diag(mi) @ L.ks_values[k + 1].
            a, b, c, d = L.ks_values[k + 1].shape
            # M = a * b * d
            # X = xp.asarray(L.ks_values[k + 1], copy=True)
            # for r in range(M):
            #     i_a = r // (b * d)
            #     i_b = (r - i_a * b * d) // d
            #     i_d = r % d
            #     X[i_a, i_b, 0:c, i_d] *= mi[r]
            X = (
                mi.reshape(-1, 1) *
                L.ks_values[k + 1].swapaxes(2, 3).reshape(a * b * d, c)
            ).reshape(a, b, d, c).swapaxes(2, 3)
            Y = ksm(list_Y[k], backend='xp')
        del list_Y
    elif p == 2:
        Y = ksm(L.ks_values[1], backend='xp')
    elif p == 1:
        raise Exception(
            "_algo7_3_left2right expects at least two factors.")

    # Quantize XY.
    q_factors[p - 2], q_factors[p - 1], li, mi = _algo7_1(
        X, Y, target, True, return_ksv=True, rnd=rnd, t=t)

    # RTN strategy for comparison.
    rtn_factors = _rtn_strategy(L, target, rnd)

    return q_factors, rtn_factors


def _algo7_2_pairwise(
        L,
        target,
        rnd: str = "upcast_downcast",
        t: int = None,
):
    r"""
    Given $p$ butterfly factors $B_1,\cdots,B_p$ quantizes them with
    ``t`` bits using Algorithm 7.1 and Algorithm 7.2 (pairwise heuristic).

    Args:
        L: :py:func:`lazylinop.butterfly.ksm`
            Length of ``L.ks_values`` is $p$
        target: NumPy/CuPy or torch dtype
            Target dtype of the quantization.
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.
        t: ``int``, optional
            If ``t`` is smaller than the number of bits
            in mantissa of ``target``, use ``t`` to quantize and
            then cast the results $\hat{x}$ and $\hat{y}$ to match
            the dtype given by ``target``.
            Default value is ``None``
            corresponding to ``t = finfo(target).nmant``.

    Returns:
        A tuple (list of 4d quantized arrays,
        list of 4d RTN strategy arrays).
    """

    if not islazylinop(L):
        raise Exception("L must be a LazyLinOp.")

    _t = _nmant(target)
    _use_t = False
    if isinstance(t, int) and t < _t:
        _t = t
        _use_t = True

    # Get namespace, dtype and device.
    xp = array_namespace(L.ks_values[0])
    p = len(L.ks_values)

    # Turn q_factors[k] to ksm later on.
    q_factors = [None] * p

    # Pairwise strategy.
    for k in range(p // 2):
        k1 = 2 * k
        k2 = 2 * k + 1
        # Quantize B_{2k}B_{2k+1}.
        q_factors[k1], q_factors[k2], _, _ = _algo7_1(
            L.ks_values[k1], ksm(L.ks_values[k2], backend="xp"),
            target, True, return_ksv=True, rnd=rnd, t=_t,
        )

    # p is odd.
    if p % 2 == 1:
        if rnd == "upcast_downcast" and not _use_t:
            q_factors[p - 1] = upcast_downcast(L.ks_values[p - 1], target)
        else:
            q_factors[p - 1] = xp.asarray(L.ks_values[p - 1], copy=True)
            i_a, i_b, i_c, i_d = xp.nonzero(q_factors[p - 1])
            q_factors[p - 1][i_a, i_b, i_c, i_d] = chop(
                q_factors[p - 1][i_a, i_b, i_c, i_d], _t)

    # RTN strategy for comparison.
    rtn_factors = _rtn_strategy(L, target, rnd, t=t)

    return q_factors, rtn_factors


def _algo5_1_opt_lambda(x, y, target, *, dochopy: bool = True,
                        use_fp64: bool = True, rnd: str = "upcast_downcast"):
    r"""
    Algorithm 5.1, version optimized for time for large-scale butterflies.

    Args:
        x, y: 2d arrays
            Column vectors to be quantized.
        target: NumPy/CuPy or torch dtype or ``int``
            If ``int``, ``target`` is the number of bits in mantissa,
            otherwize target dtype of the quantization.
        dochopy: ``bool``, optional
            - ``True`` if both ``x, y`` needs to be quantized.
            - ``False`` if just ``x`` needs to be quantized.
        use_fp64: ``bool``, optional
            - ``True`` computes using ``'float64'``.
            - ``False`` computes using ``x.dtype``.
        rnd: ``str``, optional
            - ``'chop'`` uses ``lazylinop.quantization.chop``
              function.
            - ``'upcast_downcast'`` uses downcast to target dtype
              followed by an upcast to base dtype ``x.dtype``.
              ``'upcast_downcast'`` is default value.

    Returns:
        ``l1opt`` optimal lambda, such that
        $\hat{x}=\text{chop}(\lambda_{opt}x,t)$ and
        $\hat{y}=\text{chop}(mu(\hat{x})y,t)$.
    """

    # FIXME
    assert x.ndim == 2
    assert y.ndim == 2

    xp = array_namespace(x)
    _dtype = x.dtype
    _device = device(x)
    if _device != device(y):
        raise Exception("x and y must be on the same device.")
    if x.ndim == 2 and x.shape[1] != 1:
        raise Exception("x must be 2d array of shape (n, 1).")
    if y.ndim == 2 and y.shape[1] != 1:
        raise Exception("y must be 2d array of shape (n, 1).")

    # Generate breakpoints.
    # x is always != 0 here.
    ax = xp.abs(x)
    # x12 = ax / xp.pow(2, xp.floor(xp.log2(ax)))
    x12 = xp.pow(2, xp.floor(xp.log2(ax))) / ax
    if isinstance(target, int):
        t = target
    else:
        t = _nmant(target)
    m = xp.arange(2 ** (t - 1), 2 ** t,
                  dtype=x12.dtype, device=_device)
    m1 = (m + 0.5) * 2 ** (1 - t)
    m2 = (m + 0.5) * 2 ** (2 - t)
    li = xp.asarray([1], dtype=_dtype, device=_device)
    # Compute breakpoints per batch.
    batch = min(x.shape[0], int(1e9 / (m1.nbytes * x12.dtype.itemsize)))
    mem = m1.nbytes * batch * x12.dtype.itemsize
    while (x.shape[0] % batch) != 0 or mem > 1e9:
        batch -= 1
        mem = m1.nbytes * batch * x12.dtype.itemsize
    for i in range(0, x.shape[0], batch):
        nextl1 = m1 * x12[i:(i + batch)]
        nextl2 = m2 * x12[i:(i + batch)]
        li = xp.concat(
            (
                li,
                nextl1[xp.logical_and(nextl1 < 2, nextl1 > 1)],
                nextl2[xp.logical_and(nextl2 < 2, nextl2 > 1)],
            )
        )
        del nextl1, nextl2

    # Sort breakpoints.
    li = xp.sort(li)

    # Find the optimum.
    lmid = ((li[:(-1)] + li[1:]) / 2).reshape(-1, 1)
    nl = lmid.shape[0]
    lopt, mopt, opt_rerr, opt_cxy = None, None, xp.inf, xp.inf
    # Use xp.float64 to use extend form of the error
    # C_{x,y}(hat{x},hat{y})=||xy^T-hat{x}hat{y}^T||^2.
    _already_fp64 = (
        'float64' in str(x.dtype) or
        'double' in str(x.dtype)
    )
    _x, _y = x, y
    if use_fp64:
        if not _already_fp64:
            _x = xp.asarray(x, dtype=xp.float64)
            _y = xp.asarray(y, dtype=xp.float64)
        nx = xp.linalg.norm(_x, ord="fro")
        ny = xp.linalg.norm(_y, ord="fro")
        nxy = nx * ny
        nx2 = nx * nx
        ny2 = ny * ny
        if not _already_fp64:
            lmid = xp.asarray(lmid, dtype=xp.float64)
    else:
        xy = x @ y.T
        nxy = xp.linalg.norm(xy, ord="fro")
        nx2 = xp.linalg.norm(_x, ord="fro") ** 2
        ny2 = xp.linalg.norm(_y, ord="fro") ** 2
    ft = nx2 * ny2
    # Compute error per batch instead of using a simple loop.
    batch = min(nl, int(1e9 / (_x.nbytes * lmid.dtype.itemsize)))
    mem = _x.nbytes * batch * lmid.dtype.itemsize
    while (nl % batch) != 0 or mem > 1e9:
        batch -= 1
        mem = _x.nbytes * batch * lmid.dtype.itemsize
    for i in range(nl // batch):
        if batch == nl:
            # lx = _x @ lmid.T
            lx = _x * lmid.T
        else:
            # lx = _x @ lmid[(i * batch):((i + 1) * batch)].T
            lx = _x * lmid[(i * batch):((i + 1) * batch)].T
        if rnd == "upcast_downcast":
            xh = upcast_downcast(lx, target)
        else:
            xh = chop(lx, t)
        # nxh2 = xp.linalg.norm(xh, axis=0) ** 2
        nxh2 = xp.sum(xh ** 2, axis=0)
        assert nxh2.shape == (batch, )
        _xTxh = _x.T @ xh
        mu = _xTxh / nxh2
        assert mu.shape == (1, batch)
        mu[0, nxh2 == 0] = 1
        if use_fp64:
            # FIXME: targetx != targety
            yh = _y * mu
            if dochopy:
                if rnd == "upcast_downcast":
                    yh = upcast_downcast(yh, target)
                else:
                    yh = chop(yh, t)
            # nyh2 = xp.linalg.norm(yh, axis=0) ** 2
            nyh2 = xp.sum(yh ** 2, axis=0)
            cxy = nxh2 * nyh2 - 2.0 * _xTxh * (_y.T @ yh)
            assert cxy.shape == (1, batch)
            idx = xp.argmin(cxy, axis=1)[0]
            if cxy[0, idx] < opt_cxy:
                opt_cxy = cxy[0, idx]
                # Use xp.abs(cxy) to avoid negative value.
                opt_rerr = xp.sqrt(xp.abs(ft + cxy[0, idx])) / nxy
                x_approx = xp.asarray(
                    xh[:, idx], copy=True).reshape(-1, 1)
                y_approx = xp.asarray(
                    yh[:, idx], copy=True).reshape(-1, 1)
                lopt = lmid[i * batch + idx, :1]
                mopt = mu[:1, idx]
        else:
            # Compute hat(x) and hat(y).
            xh = xp.asarray(xh, dtype=target, device=_device)
            # FIXME: dochopy if ty != inf.
            if rnd == "upcast_downcast":
                yh = xp.asarray(
                    upcast_downcast(y @ mu, target) if dochopy else y @ mu,
                    dtype=target, device=_device)
            else:
                yh = xp.asarray(chop(y @ mu, t) if dochopy else y @ mu,
                                dtype=target, device=_device)
            # Compute C_{x,y}(hat{x},hat{y})=||xy^T-hat{x}hat{y}^T||^2.
            # Use direct computation to avoid artifial zero in C_{x,y} that
            # arise when using expanded expression from :ref:`[1] <opt_qrank1>`
            # especially for lower precision.
            if 'float8_e5m2' in str(target) or 'float8_e4m3fn' in str(target):
                # RuntimeError: "bmm" not implemented for 'Float8_e5m2'
                for j in range(batch):
                    u = xh[:, j].reshape(-1, 1)
                    v = yh[:, j].reshape(1, -1)
                    rerr = xp.linalg.norm(
                        xy - xp.asarray(
                            u @ v, dtype=xy.dtype), ord="fro") / nxy
                    if rerr < opt_rerr:
                        opt_rerr = rerr
                        x_approx = xp.asarray(
                            xh[:, j], copy=True).reshape(-1, 1)
                        y_approx = xp.asarray(
                            yh[:, j], copy=True).reshape(-1, 1)
                        lopt = lmid[i * batch + j, :1].reshape(-1)
                        mopt = mu[:1, j].reshape(-1)
            else:
                bxh = xh.T.reshape(batch, xh.shape[0], 1)
                byh = yh.T.reshape(batch, 1, yh.shape[0])
                diff = xy - xp.asarray(bxh @ byh, dtype=xy.dtype)
                rerr = xp.linalg.norm(diff, axis=(1, 2), ord="fro") / nxy
                idx = xp.argmin(rerr)
                assert batch == rerr.shape[0]
                if rerr[idx] < opt_rerr:
                    opt_rerr = rerr[idx]
                    x_approx = xp.asarray(
                        xh[:, idx], copy=True).reshape(-1, 1)
                    y_approx = xp.asarray(
                        yh[:, idx], copy=True).reshape(-1, 1)
                    lopt = lmid[i * batch + idx, :1].reshape(-1)
                    mopt = mu[:1, idx].reshape(-1)

    if use_fp64 and not _already_fp64:
        if rnd == "upcast_downcast":
            lopt = xp.asarray(
                upcast_downcast(lopt, x.dtype), dtype=x.dtype)
            mopt = xp.asarray(
                upcast_downcast(mopt, x.dtype), dtype=x.dtype)
        else:
            lopt = xp.asarray(chop(lopt, x.dtype), dtype=x.dtype)
            mopt = xp.asarray(chop(mopt, x.dtype), dtype=x.dtype)
    return x_approx, y_approx, lopt[0], mopt[0], opt_rerr
