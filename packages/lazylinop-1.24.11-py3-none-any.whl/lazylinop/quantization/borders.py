import numpy as np
from array_api_compat import array_namespace

from shapely.geometry import LineString, Polygon
from shapely.affinity import rotate


def polygon_from_lines(lines):
    """
    From a list of lines, returns the polygon generated with the intersections
    """
    points = []
    for i in range(len(lines)):
        p = lines[i].intersection(lines[(i+1) % len(lines)])
        if not p.is_empty:
            points.append((p.x, p.y))

    return Polygon(points)


def polygon_to_lines(polygon):
    """
    Returns the sides of the polygon
    """
    exterior_coords = list(polygon.exterior.coords)
    lines = [
        LineString(
            [exterior_coords[i], exterior_coords[i + 1]]
        ) for i in range(len(exterior_coords) - 1)
    ]
    return lines


def build_tiling_domain(normalized_direction_set, t):
    """
    Builds the tiling domain (trapezoid or L-shape) according to the
    normalized direction set and the number of significand bits ``t``.

    Args:
        normalized_direction_set: ``list[complex]``
            Set of normalized directions.
        t: ``int``
            Number of significand bits.

    Returns:
        A ``TilingDomain`` object corresponding to the tiling domain.
    """
    z_ref = normalized_direction_set[0]
    xp = array_namespace(z_ref)

    y_vals = xp.linspace(-100, 100, 2)
    base_A_z = LineString([(0, y_vals[0]), (0, y_vals[1])])

    # The two non-parallel sides of the trapezoid
    if 'torch' in str(xp.__package__):
        A_z = rotate(base_A_z, -xp.rad2deg(xp.angle(z_ref)), origin=(0, 0))
    else:
        A_z = rotate(base_A_z, -xp.degrees(xp.angle(z_ref)), origin=(0, 0))
    A_iz = rotate(A_z, 90, origin=(0, 0))

    new_normalized_set = []
    for z in normalized_direction_set:
        if xp.abs(xp.angle(z) - xp.angle(z_ref)) % (xp.pi/2) <= 1e-2:
            continue
        if xp.abs(xp.angle(z) % (np.pi/2) - xp.angle(z_ref) % (xp.pi/2)) <= 1e-2:
            continue

        new_normalized_set.append(z)

    beta = (2**t + 1) * 2**(-t)

    if len(new_normalized_set) == 0:  # L-shape case
        base_D_z_beta_2 = LineString(
            [(0.5 * beta / xp.abs(z_ref), -100), (0.5 * beta / xp.abs(z_ref), 100)])
        base_D_z_beta = LineString(
            [(beta / xp.abs(z_ref), -100), (beta / xp.abs(z_ref), 100)])

        if 'torch' in str(xp.__package__):
            D_z_beta_2 = rotate(
                base_D_z_beta_2, 90 - xp.rad2deg(xp.angle(z_ref)), origin=(0, 0))
            D_z_beta = rotate(
                base_D_z_beta, 90 - xp.rad2deg(xp.angle(z_ref)), origin=(0, 0))
        else:
            D_z_beta_2 = rotate(
                base_D_z_beta_2, 90 - xp.degrees(xp.angle(z_ref)), origin=(0, 0))
            D_z_beta = rotate(
                base_D_z_beta, 90 - xp.degrees(xp.angle(z_ref)), origin=(0, 0))

        D_iz_beta = rotate(D_z_beta, 90, origin=(0, 0))
        D_iz_beta_2 = rotate(D_z_beta_2, 90, origin=(0, 0))

        long_lines_border = [A_iz, D_iz_beta_2,
                             D_z_beta_2, A_z, D_z_beta, D_iz_beta]
    else:  # Trapezoid case
        z_ref2 = new_normalized_set[0]

        base_D_iz_bis_beta_2 = LineString(
            [(0.5 * beta / xp.abs(z_ref2), -100), (0.5 * beta / xp.abs(z_ref2), 100)])
        base_D_iz_bis_beta = LineString(
            [(beta / xp.abs(z_ref2), -100), (beta / xp.abs(z_ref2), 100)])

        if 'torch' in str(xp.__package__):
            D_iz_bis_beta_2 = rotate(
                base_D_iz_bis_beta_2,
                90 - xp.rad2deg(xp.angle(z_ref2)),
                origin=(0, 0),
            )
            D_iz_bis_beta = rotate(
                base_D_iz_bis_beta,
                90 - xp.rad2deg(xp.angle(z_ref2)),
                origin=(0, 0),
            )
        else:
            D_iz_bis_beta_2 = rotate(
                base_D_iz_bis_beta_2,
                90 - xp.degrees(xp.angle(z_ref2)),
                origin=(0, 0),
            )
            D_iz_bis_beta = rotate(
                base_D_iz_bis_beta,
                90 - xp.degrees(xp.angle(z_ref2)),
                origin=(0, 0),
            )

        long_lines_border = [A_z, D_iz_bis_beta_2, A_iz, D_iz_bis_beta]

    return TilingDomain(long_lines_border)


class TilingDomain:
    """
    Class for the tiling domain defined by its border (trapezoid or L-shape).

    Attributes
        long_lines_border: ``list[shapely.geometry.LineString]``
            List of shapely LineString corresponding to the lines defining
            the border without restriction to the border.
        border: ``shapely.geometry.Polygon``
            Shapely Polygon corresponding to the border.
        lines_border: ``list[shapely.geometry.LineString]``
            List of shapely LineString corresponding to the sides of the border.
        area: ``float``
            Area of the border.
    """

    def __init__(self, long_lines_border):
        self.long_lines_border = long_lines_border
        self.border = polygon_from_lines(self.long_lines_border)

        self.lines_border = polygon_to_lines(self.border)

        self.area = self.border.area

    def get_breakpoint_accum(self, acc_line):
        """
        Returns the intersection between the accumulation line and the trapezoid.

        Args:
            acc_line: ``shapely.geometry.LineString``
                Accumulation line.

        Returns:
            breakpoint: Complex number corresponding to the intersection point.
        """
        inter = self.long_lines_border[1].intersection(acc_line)
        breakpoint = None
        if not inter.is_empty:
            if inter.geom_type == "Point":
                breakpoint = inter.xy[0][0] + 1j * inter.xy[1][0]

        return breakpoint

    def filter_all_breaklines(self, all_breaklines):
        """
        Filters the breaklines to only keep the part that are inside the trapezoid.

        Args:
            all_breaklines: ``list[list[shapely.geometry.LineString]]``
                List of list of shapely LineString corresponding to the breaklines.

        Returns:
            filtered_breaklines: ``list[list[shapely.geometry.LineString]]``
                List of list of shapely LineString corresponding to the filtered breaklines.
        """
        filtered_breaklines = []
        for breaklines in all_breaklines:
            filtered_lines = []
            for breakline in breaklines:
                inter = breakline.intersection(self.border)
                if not inter.is_empty:
                    if inter.geom_type == "MultiLineString":
                        filtered_lines.extend(list(inter.geoms))
                    elif inter.geom_type == "LineString":
                        filtered_lines.append(inter)

            filtered_breaklines.append(filtered_lines)

        return filtered_breaklines

    # def filter_breaklines(self, breaklines):
    #     """
    #     Filters the breaklines to only keep the part that are inside the trapezoid.

    #     Args:
    #     breaklines: List of shapely LineString corresponding to the breaklines.
    #         list[shapely.geometry.LineString]

    #     Returns
    #     filtered_lines: List of shapely LineString corresponding to the filtered breaklines.
    #         list[shapely.geometry.LineString]
    #     """
    #     filtered_lines = []
    #     for breakline in breaklines:
    #         inter = self.border.intersection(breakline)
    #         if not inter.is_empty:
    #             if inter.geom_type == "MultiLineString":
    #                 filtered_lines.extend(list(inter.geoms))
    #             elif inter.geom_type == "LineString":
    #                 filtered_lines.append(inter)

    #     return filtered_lines
