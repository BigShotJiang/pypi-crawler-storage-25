"""Program and Rung context managers for the immutable PLC engine.

Provides DSL syntax for building PLC programs:

    with Program() as logic:
        with Rung(Button):
            out(Light)

    runner = PLCRunner(logic)
"""

from .builders import (
    CountDownBuilder,
    CountUpBuilder,
    EventDrumBuilder,
    OffDelayBuilder,
    OnDelayBuilder,
    ShiftBuilder,
    TimeDrumBuilder,
    count_down,
    count_up,
    event_drum,
    off_delay,
    on_delay,
    shift,
    time_drum,
)
from .conditions import (
    all_of,
    any_of,
    fall,
    rise,
)
from .context import (
    Branch,
    ForLoop,
    Program,
    Rung,
    RungContext,
    Subroutine,
    SubroutineFunc,
    branch,
    comment,
    forloop,
    subroutine,
)
from .decorators import program
from .instructions import (
    blockcopy,
    calc,
    call,
    copy,
    fill,
    latch,
    out,
    pack_bits,
    pack_text,
    pack_words,
    reset,
    return_early,
    run_enabled_function,
    run_function,
    search,
    unpack_to_bits,
    unpack_to_words,
)
from .validation import (
    DialectValidator,
    ForbiddenControlFlowError,
)

__all__ = [
    # Contexts & Structure
    "Branch",
    "ForLoop",
    "Program",
    "Rung",
    "RungContext",
    "Subroutine",
    "SubroutineFunc",
    # Decorators & Factory Functions
    "branch",
    "comment",
    "forloop",
    "program",
    "subroutine",
    # Conditions
    "all_of",
    "any_of",
    "fall",
    "rise",
    # Basic Instructions
    "call",
    "copy",
    "latch",
    "out",
    "reset",
    "return_early",
    # Advanced Instructions
    "blockcopy",
    "fill",
    "calc",
    "pack_bits",
    "pack_text",
    "pack_words",
    "run_enabled_function",
    "run_function",
    "search",
    "unpack_to_bits",
    "unpack_to_words",
    # Builders & Terminal Instructions
    "CountDownBuilder",
    "CountUpBuilder",
    "EventDrumBuilder",
    "OffDelayBuilder",
    "OnDelayBuilder",
    "ShiftBuilder",
    "TimeDrumBuilder",
    "count_down",
    "count_up",
    "event_drum",
    "off_delay",
    "on_delay",
    "shift",
    "time_drum",
    # Validation & Types
    "DialectValidator",
    "ForbiddenControlFlowError",
]
