# pysymex: Python Symbolic Execution & Formal Verification
# Upstream Repository: https://github.com/darkoss1/pysymex
#
# Copyright (C) 2026 pysymex Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""
pysymex Scanner - core logic
===============================
Analysis functions, directory scanning, watch-mode CLI entry point.
"""

import argparse
import concurrent.futures
import contextvars
import dataclasses
import logging
import os
import sys
import time
import re
import types
from datetime import datetime
from pathlib import Path
from typing import TypeGuard

_LIST_VAR_RE = re.compile(r"collection|items|sequence|data|arr|list")
_DICT_VAR_RE = re.compile(r"mapping|config|settings|dict|map")

from pysymex.analysis.autotuner import AutoTuner
from pysymex.analysis.detectors import Issue, IssueKind
from pysymex.analysis.detectors.protocols import ScanReporter
from pysymex.analysis.specialized.ranges import ValueRangeChecker
from pysymex.cli.reporter import ConsoleScanReporter
from pysymex.core.solver.engine import clear_solver_caches
from pysymex.execution.executors import ExecutionConfig, SymbolicExecutor

# Import opcodes early to ensure @opcode_handler decorators are registered
from pysymex.execution.opcodes import py_version  # type: ignore  # triggers opcode handler registration
from pysymex.scanner.types import IssueRecord, ScanResult, ScanResultBuilder, ScanSession
from pysymex.watch import FileEventType, FileWatcher

logger = logging.getLogger(__name__)

_session_var: contextvars.ContextVar[ScanSession | None] = contextvars.ContextVar(
    "_session_var",
    default=None,
)


def _descending_issue_count(item: tuple[str, int]) -> int:
    return -item[1]


def _build_symbolic_vars(
    code: types.CodeType, *, include_collection_heuristics: bool
) -> dict[str, str]:
    """Build symbolic argument type hints from code object parameter names."""
    symbolic_vars: dict[str, str] = {}
    for i, name in enumerate(code.co_varnames[: code.co_argcount]):
        if i == 0 and name in {"self", "cls"}:
            symbolic_vars[name] = "object"
            continue
        if include_collection_heuristics:
            name_lower = name.lower()
            if _LIST_VAR_RE.search(name_lower):
                symbolic_vars[name] = "list"
                continue
            if _DICT_VAR_RE.search(name_lower):
                symbolic_vars[name] = "dict"
                continue
        symbolic_vars[name] = "int"
    return symbolic_vars


def _is_object_dict(value: object) -> TypeGuard[dict[object, object]]:
    """Return True if *value* is a plain dictionary."""
    return isinstance(value, dict)


def _auto_worker_count(*, use_sandbox: bool) -> int:
    """Return a conservative default worker count for symbolic scans.

    Symbolic execution is memory-heavy, and sandbox compilation may spawn
    extra short-lived helper processes per file. Aggressive CPU-count defaults
    can oversubscribe hosts (especially on Windows), causing high RSS and
    scheduler thrash.
    """
    cpu_count = max(1, os.cpu_count() or 1)
    half_cpu = max(1, cpu_count // 2)
    cap = 2 if use_sandbox else 4
    return min(cap, half_cpu)


def _hardware_acceleration_status(*, use_h_acceleration: bool, use_chtd: bool) -> str:
    """Return a human-readable summary of active acceleration backends."""
    if not use_h_acceleration or not use_chtd:
        return "none (disabled by configuration)"

    try:
        from pysymex.accel.dispatcher import get_dispatcher

        dispatcher = get_dispatcher()
        backends = dispatcher.list_backends()
        has_sat = any(b.available and b.backend_type.name == "SAT" for b in backends)
        has_cpu = any(b.available and b.backend_type.name in {"CPU", "REFERENCE"} for b in backends)

        if has_sat and has_cpu:
            availability = "both (SAT+CPU)"
        elif has_sat:
            availability = "sat"
        elif has_cpu:
            availability = "cpu"
        else:
            availability = "none"

        selected = dispatcher.selected_backend.name.lower()
        return f"{availability}; dispatcher_selected={selected}"
    except Exception:
        logger.debug("Unable to determine acceleration backend status", exc_info=True)
        return "unknown (backend probe failed)"


def get_code_objects_with_context(
    code: types.CodeType, parent_path: str | None = None
) -> list[tuple[types.CodeType, str | None, str | None]]:
    """
    Recursively extract all code objects with their full hierarchical path.

    Returns:
        List of tuples: (code_object, immediate_parent, full_path)
        - immediate_parent: Direct parent name (for class instantiation)
        - full_path: Full dotted path (for nested class imports like Outer.Inner)
    """
    current_name: str = code.co_name
    if current_name == "<module>":
        full_path: str | None = None
        immediate_parent: str | None = None
    else:
        full_path = f"{parent_path}.{current_name}" if parent_path else current_name
        immediate_parent = parent_path
    results: list[tuple[types.CodeType, str | None, str | None]] = [
        (code, immediate_parent, full_path)
    ]
    child_parent: str | None = full_path if current_name != "<module>" else None
    for const in code.co_consts:
        if hasattr(const, "co_code"):
            results.extend(get_code_objects_with_context(const, child_parent))
    return results


def analyze_source(
    content: str,
    file_path: str = "<source>",
    *,
    max_paths: int = 100,
    max_depth: int = 50,
    timeout_seconds: float = 30.0,
    solver_timeout_ms: int = 10000,
) -> ScanResult:
    """Analyse already-loaded source text â€” pure-ish core (no file I/O).

    This is the functional core of ``analyze_file`` and ``scan_file``.
    It receives *source text* instead of touching the filesystem, so
    callers control where the text comes from.

    Returns:
        A :class:`ScanResult` populated with issues, paths explored, etc.
    """
    builder = ScanResultBuilder(file_path=file_path)
    try:
        code_obj = compile(content, file_path, "exec")
        all_code_with_context = get_code_objects_with_context(code_obj)
        builder.code_objects = len(all_code_with_context)
        config = ExecutionConfig(
            max_paths=max_paths,
            max_depth=max_depth,
            max_iterations=max(50000, max_paths * 100),
            timeout_seconds=timeout_seconds,
            solver_timeout_ms=solver_timeout_ms,
        )
        executor = SymbolicExecutor(config=config)
        all_issues: list[Issue] = []
        total_paths = 0
        total_time = 0.0
        memory_samples: list[float] = []
        module_item = all_code_with_context[0] if all_code_with_context else None
        other_items = all_code_with_context[1:] if len(all_code_with_context) > 1 else []
        module_globals = _get_default_scanner_globals()

        seen_codes: set[int] = set()

        if module_item:
            code, class_name, full_path = module_item
            seen_codes.add(id(code))
            symbolic_vars = _build_symbolic_vars(code, include_collection_heuristics=False)
            try:
                exec_result = executor.execute_code(code, symbolic_vars=symbolic_vars)
                module_globals = exec_result.final_locals
                for raw_issue in exec_result.issues:
                    issue_with_context = dataclasses.replace(
                        raw_issue,
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                    all_issues.append(issue_with_context)
                total_paths += exec_result.paths_explored
                total_time += exec_result.total_time_seconds
                if exec_result.avg_memory_mb > 0:
                    memory_samples.append(exec_result.avg_memory_mb)
            except Exception as e:
                logger.debug("Module execution failed for %s", file_path, exc_info=True)
                all_issues.append(
                    Issue(
                        kind=IssueKind.RUNTIME_ERROR,
                        message=f"Internal Error during symbolic execution: {type(e).__name__}({e})",
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                )
        for code, class_name, full_path in other_items:
            if id(code) in seen_codes:
                continue
            seen_codes.add(id(code))
            symbolic_vars = _build_symbolic_vars(code, include_collection_heuristics=False)
            try:
                exec_result = executor.execute_code(
                    code,
                    symbolic_vars=symbolic_vars,
                    initial_globals=module_globals,
                )
                for raw_issue in exec_result.issues:
                    issue_ctx = dataclasses.replace(
                        raw_issue,
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                    all_issues.append(issue_ctx)
                total_paths += exec_result.paths_explored
                total_time += exec_result.total_time_seconds
                if exec_result.avg_memory_mb > 0:
                    memory_samples.append(exec_result.avg_memory_mb)
            except Exception as e:
                logger.debug(
                    "Execution failed for %s in %s", code.co_name, file_path, exc_info=True
                )
                all_issues.append(
                    Issue(
                        kind=IssueKind.RUNTIME_ERROR,
                        message=f"Internal Error during symbolic execution: {type(e).__name__}({e})",
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                )
        builder.add_paths(total_paths)
        avg_mem = sum(memory_samples) / len(memory_samples) if memory_samples else 0.0
        builder.set_performance(total_time, avg_mem)

        range_checker = ValueRangeChecker()
        seen: set[str] = set()
        seen_codes_range: set[int] = set()
        for code, class_name, full_path in all_code_with_context:
            if id(code) in seen_codes_range:
                continue
            seen_codes_range.add(id(code))
            try:
                range_warnings = range_checker.check_function(code, file_path)
                for warning in range_warnings:
                    msg = f"[Abstract Interpreter] [{warning.kind}] {warning.message} (Line {warning.line})"
                    if msg not in seen:
                        seen.add(msg)
                        builder.add_issue(
                            {
                                "kind": warning.kind,
                                "message": f"[Abstract Interpreter] {warning.message}",
                                "line": warning.line,
                                "pc": warning.pc,
                                "function_name": code.co_name,
                                "class_name": class_name,
                                "full_path": full_path,
                                "counterexample": None,
                            }
                        )
            except (RuntimeError, TypeError, ValueError):
                logger.debug("Value range analysis failed for %s", code.co_name, exc_info=True)
        for issue in all_issues:
            msg = f"[{issue.kind.name}] {issue.message} (Line {issue.line_number})"
            if msg not in seen:
                seen.add(msg)
                builder.add_issue(
                    {
                        "kind": issue.kind.name,
                        "message": issue.message,
                        "line": issue.line_number,
                        "pc": issue.pc,
                        "function_name": issue.function_name,
                        "class_name": getattr(issue, "class_name", None),
                        "full_path": getattr(issue, "full_path", None),
                        "counterexample": issue.get_counterexample(),
                    }
                )
    except SyntaxError as e:
        builder.set_error(f"Syntax Error: {e}")
    except Exception as e:
        builder.set_error(f"Analysis Error: {e}")
    return builder.build()


def _get_default_scanner_globals() -> dict[str, object]:
    """Provide a default global environment for the scanner.

    Includes symbolic objects for common standard library modules to
    prevent the engine from assuming they could be None.
    """
    import z3

    from pysymex.core.types.containers import SymbolicObject

    defaults: dict[str, object] = {}

    common_modules = [
        "sys",
        "os",
        "functools",
        "re",
        "json",
        "math",
        "time",
        "random",
        "datetime",
        "io",
        "itertools",
        "collections",
        "pathlib",
        "abc",
        "typing",
    ]

    for mod_name in common_modules:
        addr = hash(mod_name) & 0xFFFFFFFF
        obj = SymbolicObject(mod_name, addr, z3.IntVal(addr), {addr})
        defaults[mod_name] = obj

    return defaults


def analyze_file(file_path: Path) -> ScanResult:
    """Run pysymex analysis on a single file (I/O shell).

    Reads the file and delegates to :func:`analyze_source` for the
    actual analysis. Handles session tracking and console output.
    """
    session = _session_var.get()
    print(f"\n{'=' * 70}")
    print(f"ðŸ” Scanning: {file_path}")
    print("=" * 70)
    try:
        content = file_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        result = ScanResult(
            file_path=str(file_path),
            timestamp=datetime.now().isoformat(),
            error=f"Read Error: {e}",
        )
        if session:
            session.add_result(result)
        return result

    result = analyze_source(content, str(file_path))

    if result.issues:
        print(f"\nâš ï¸  Found {len(result.issues)} potential issues:\n")
        for issue in result.issues:
            print(f"   â€¢ [{issue['kind']}] {issue['message']} (Line {issue['line']})")
            counterexample = issue.get("counterexample")
            if _is_object_dict(counterexample):
                for var, val in counterexample.items():
                    print(f"       â””â”€ {var} = {val}")
    elif result.error:
        print(f"\nâŒ {result.error}")
    else:
        print("\nâœ… No issues found!")
    print(
        f"\n   ðŸ“Š Stats: {result.code_objects} code objects | {result.paths_explored} paths explored"
    )
    if session:
        session.add_result(result)
    return result


def scan_file(
    file_path: str | Path,
    verbose: bool = False,
    max_paths: int = 100,
    timeout: float = 30.0,
    auto_tune: bool = False,
    reporter: ScanReporter | None = None,
    use_sandbox: bool = True,
    use_chtd: bool = True,
    use_h_acceleration: bool = True,
    deterministic_mode: bool = False,
    random_seed: int = 42,
    no_cache: bool = False,
    max_iterations: int = 0,
    trace_enabled: bool | None = None,
    trace_output_dir: str | None = None,
    trace_verbosity: str = "delta_only",
) -> ScanResult:
    """
    Scan a single Python file for potential bugs.
    Args:
        file_path: Path to the Python file
        verbose: Print detailed output
        max_paths: Maximum paths per function
        timeout: Timeout in seconds
        auto_tune: Automatically adjust config based on complexity
    Returns:
        ScanResult with issues found
    Example:
        >>> result = scan_file("mycode.py")
        >>> for issue in result.issues:
        ...     print(f"{issue['kind']}: {issue['message']}")
    """
    file_path = Path(file_path)
    session = _session_var.get()
    result = ScanResult(
        file_path=str(file_path),
        timestamp=datetime.now().isoformat(),
    )
    start_time = time.perf_counter()
    tracer = None
    try:
        content = file_path.read_text(encoding="utf-8")
        if use_sandbox:
            from pysymex.sandbox.bridge import extract_bytecode

            bytecode_blob = extract_bytecode(
                content.encode("utf-8"),
                str(file_path),
                sandbox_config={"allow_compat_fallback": True},
            )
            code_obj = bytecode_blob.reconstruct()
        else:
            code_obj = compile(content, str(file_path), "exec")
        all_code_with_context = get_code_objects_with_context(code_obj)
        result.code_objects = len(all_code_with_context)
        config = ExecutionConfig(
            max_paths=max_paths,
            max_depth=1000,
            max_iterations=max_iterations if max_iterations > 0 else max(5000, max_paths * 100),
            timeout_seconds=timeout,
            enable_solver_cache=not no_cache,
            enable_cross_function=False,
            enable_chtd=use_chtd,
            enable_h_acceleration=use_h_acceleration,
            deterministic_mode=deterministic_mode,
            random_seed=random_seed,
        )
        base_config = config
        executor = SymbolicExecutor(config=config)
        tracer = None
        if trace_enabled is not False:
            from pysymex.tracing.schemas import TracerConfig, VerbosityLevel
            from pysymex.tracing.tracer import ExecutionTracer

            verbosity_value = trace_verbosity.strip().lower()
            verbosity = {
                "quiet": VerbosityLevel.QUIET,
                "delta_only": VerbosityLevel.DELTA_ONLY,
                "full": VerbosityLevel.FULL,
            }.get(verbosity_value, VerbosityLevel.DELTA_ONLY)

            cfg_overrides: dict[str, object] = {"verbosity": verbosity}
            if trace_enabled is not None:
                cfg_overrides["enabled"] = trace_enabled
            if trace_output_dir:
                cfg_overrides["output_dir"] = trace_output_dir

            tracer_cfg = TracerConfig.from_env(**cfg_overrides)
            if tracer_cfg.enabled:
                tracer = ExecutionTracer(config=tracer_cfg)
                tracer.start_session(
                    func_name=f"scan:{file_path.stem}",
                    signature_str="(module-scan)",
                    initial_args={},
                    config_snapshot=dataclasses.asdict(config),
                    source_file=str(file_path),
                )
                tracer.install(executor)

        seen: set[str] = set()

        def _handle_issue(issue: Issue | IssueRecord) -> None:
            """Handle issue."""
            import re

            issue_dict: IssueRecord

            if _is_object_dict(issue):
                issue_dict = {}
                for key_obj, value_obj in issue.items():
                    issue_dict[str(key_obj)] = value_obj
                raw_kind = str(issue_dict.get("kind", "UNKNOWN"))
                raw_message = str(issue_dict.get("message", ""))
                raw_line = issue_dict.get("line", "?")
                raw_msg_key = f"[{raw_kind}] {raw_message} (Line {raw_line})"
            elif isinstance(issue, Issue):
                issue_obj = issue
                raw_msg_key = (
                    f"[{issue_obj.kind.name}] {issue_obj.message} (Line {issue_obj.line_number})"
                )
                counterexample = issue_obj.get_counterexample()
                issue_dict = {
                    "kind": issue_obj.kind.name,
                    "message": issue_obj.message,
                    "line": issue_obj.line_number,
                    "pc": issue_obj.pc,
                    "function_name": issue_obj.function_name,
                    "class_name": getattr(issue_obj, "class_name", None),
                    "full_path": getattr(issue_obj, "full_path", None),
                    "counterexample": counterexample,
                }
            else:
                return

            msg_key = re.sub(r"(_\d+|@\d+)", "", raw_msg_key)

            if msg_key not in seen:
                seen.add(msg_key)
                result.issues.append(issue_dict)
                if verbose and reporter:
                    reporter.on_issue(issue_dict)

        total_paths = 0
        total_time = 0.0
        memory_samples: list[float] = []
        module_item = all_code_with_context[0] if all_code_with_context else None
        other_items = all_code_with_context[1:] if len(all_code_with_context) > 1 else []
        module_globals = _get_default_scanner_globals()

        seen_codes_scan: set[int] = set()

        if module_item:
            code, class_name, full_path = module_item
            seen_codes_scan.add(id(code))
            symbolic_vars = _build_symbolic_vars(code, include_collection_heuristics=True)
            try:
                exec_result = executor.execute_code(
                    code, symbolic_vars=symbolic_vars, initial_globals=module_globals
                )
                module_globals = exec_result.final_locals
                for raw_issue in exec_result.issues:
                    processed_issue = dataclasses.replace(
                        raw_issue,
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                    _handle_issue(processed_issue)
                total_paths += exec_result.paths_explored
                total_time += exec_result.total_time_seconds
                if exec_result.avg_memory_mb > 0:
                    memory_samples.append(exec_result.avg_memory_mb)
            except Exception as e:
                logger.debug("Module execution failed for %s: %s", str(file_path), e, exc_info=True)
                _handle_issue(
                    Issue(
                        kind=IssueKind.RUNTIME_ERROR,
                        message=f"Internal Error during symbolic execution: {type(e).__name__}({e})",
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                )

        for code, class_name, full_path in other_items:
            if id(code) in seen_codes_scan:
                continue
            seen_codes_scan.add(id(code))
            if auto_tune:
                tune_config = AutoTuner.tune(code, base_config)
                tune_config = dataclasses.replace(
                    tune_config,
                    enable_state_merging=base_config.enable_state_merging,
                    enable_caching=base_config.enable_caching,
                )
                executor = SymbolicExecutor(config=tune_config)
                if tracer:
                    tracer.install(executor)

            symbolic_vars = _build_symbolic_vars(code, include_collection_heuristics=True)
            try:
                exec_result = executor.execute_code(
                    code, symbolic_vars=symbolic_vars, initial_globals=module_globals
                )
                for raw_issue in exec_result.issues:
                    processed_issue = dataclasses.replace(
                        raw_issue,
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                    _handle_issue(processed_issue)
                total_paths += exec_result.paths_explored
            except Exception as e:
                logger.debug("Symbolic execution failed for %s", code.co_name, exc_info=True)
                _handle_issue(
                    Issue(
                        kind=IssueKind.RUNTIME_ERROR,
                        message=f"Internal Error during symbolic execution: {type(e).__name__}({e})",
                        function_name=code.co_name,
                        class_name=class_name,
                        full_path=full_path,
                    )
                )
        result.paths_explored = total_paths
        result.elapsed_time = time.perf_counter() - start_time
        result.avg_memory_mb = sum(memory_samples) / len(memory_samples) if memory_samples else 0.0

        range_checker = ValueRangeChecker()
        seen_codes_range_scan: set[int] = set()
        for code, class_name, full_path in all_code_with_context:
            if id(code) in seen_codes_range_scan:
                continue
            seen_codes_range_scan.add(id(code))
            try:
                range_warnings = range_checker.check_function(code, str(file_path))
                for warning in range_warnings:
                    _handle_issue(
                        {
                            "kind": warning.kind,
                            "message": f"[Abstract Interpreter] {warning.message}",
                            "line": warning.line,
                            "pc": warning.pc,
                            "function_name": code.co_name,
                            "class_name": class_name,
                            "full_path": full_path,
                            "counterexample": None,
                        }
                    )
            except (RuntimeError, TypeError, ValueError):
                logger.debug("Value range analysis failed for %s", code.co_name, exc_info=True)

        if verbose and not reporter:
            status_msg = f"{len(result.issues)} issues found" if result.issues else "No issues"
            print(f"{'âš ï¸' if result.issues else 'âœ…'} {file_path}: {status_msg}")
    except SyntaxError as e:
        result.error = f"Syntax Error: {e}"
        if reporter:
            reporter.on_error(file_path, result.error)
        elif verbose:
            print(f"\nâŒ {result.error}")
    except Exception as e:
        result.error = f"Analysis Error: {e}"
        if reporter:
            reporter.on_error(file_path, result.error)
        elif verbose:
            print(f"\nâŒ {result.error}")
    finally:
        if tracer is not None:
            try:
                tracer.end_session()
            except Exception:
                logger.debug("Failed to close trace session for %s", file_path, exc_info=True)
    if session:
        session.add_result(result)
    return result


def scan_directory(
    dir_path: str | Path,
    pattern: str = "**/*.py",
    verbose: bool = True,
    max_paths: int = 200,
    timeout: int = 30,
    workers: int | None = None,
    recursive: bool = False,
    mode: str = "symbolic",
    auto_tune: bool = False,
    reporter: ScanReporter | None = None,
    use_sandbox: bool = True,
    use_chtd: bool = True,
    use_h_acceleration: bool = True,
    deterministic_mode: bool = False,
    random_seed: int = 42,
    no_cache: bool = False,
    max_iterations: int = 0,
    trace_enabled: bool | None = None,
    trace_output_dir: str | None = None,
    trace_verbosity: str = "delta_only",
) -> list[ScanResult]:
    """Scan all Python files in a directory for potential bugs."""
    dir_path = Path(dir_path)
    files = sorted(dir_path.glob(pattern))

    if not reporter:
        from pysymex.cli.reporter import ConsoleScanReporter

        reporter = ConsoleScanReporter()
    assert reporter is not None

    if files:
        reporter.on_status(f"Scanning {len(files)} Python files in {dir_path}...\n")
    else:
        if verbose and reporter:
            reporter.on_summary([], 0)
        elif verbose:
            print(f"No Python files found in {dir_path}")
        return []

    workers_count = (
        _auto_worker_count(use_sandbox=use_sandbox) if workers is None or workers <= 0 else workers
    )

    if workers_count > 1 and len(files) < workers_count * 2:
        workers_count = max(1, len(files) // 2)

    logical_cores = max(1, os.cpu_count() or 1)
    execution_mode = "parallel" if workers_count > 1 else "sequential"
    hacc_status = _hardware_acceleration_status(
        use_h_acceleration=use_h_acceleration,
        use_chtd=use_chtd,
    )
    if reporter:
        reporter.on_status(
            f"Runtime: mode={execution_mode}; workers={workers_count}; logical_cores={logical_cores}"
        )
        reporter.on_status(f"Hardware acceleration: {hacc_status}\n")
    elif verbose:
        print(
            f"Runtime: mode={execution_mode}; workers={workers_count}; logical_cores={logical_cores}"
        )
        print(f"Hardware acceleration: {hacc_status}")

    if workers_count <= 1:
        return _scan_sequential(
            files,
            verbose,
            max_paths,
            timeout,
            auto_tune,
            reporter,
            use_sandbox,
            use_chtd,
            use_h_acceleration,
            deterministic_mode,
            random_seed,
            no_cache,
            max_iterations,
            trace_enabled,
            trace_output_dir,
            trace_verbosity,
        )

    return _scan_parallel(
        files,
        workers_count,
        verbose,
        max_paths,
        timeout,
        auto_tune,
        reporter,
        use_sandbox,
        use_chtd,
        use_h_acceleration,
        deterministic_mode,
        random_seed,
        no_cache,
        max_iterations,
        trace_enabled,
        trace_output_dir,
        trace_verbosity,
    )


_PARALLEL_CHUNK = 64


def _scan_sequential(
    files: list[Path],
    verbose: bool,
    max_paths: int,
    timeout: float,
    auto_tune: bool,
    reporter: ScanReporter | None = None,
    use_sandbox: bool = True,
    use_chtd: bool = True,
    use_h_acceleration: bool = True,
    deterministic_mode: bool = False,
    random_seed: int = 42,
    no_cache: bool = False,
    max_iterations: int = 0,
    trace_enabled: bool | None = None,
    trace_output_dir: str | None = None,
    trace_verbosity: str = "delta_only",
) -> list[ScanResult]:
    """Scan *files* one-by-one in the current process."""
    results: list[ScanResult] = []
    total = len(files)
    if verbose and not reporter:
        print(f"Scanning {total} file{'s' if total != 1 else ''} sequentially...")
    for i, file_path in enumerate(files, 1):
        if verbose and not reporter:
            print(f"[{i}/{total}] {file_path.name}...", end=" ", flush=True)
        try:
            result = scan_file(
                file_path,
                verbose=False,
                max_paths=max_paths,
                timeout=timeout,
                auto_tune=auto_tune,
                reporter=reporter,
                use_sandbox=use_sandbox,
                use_chtd=use_chtd,
                use_h_acceleration=use_h_acceleration,
                deterministic_mode=deterministic_mode,
                random_seed=random_seed,
                no_cache=no_cache,
                max_iterations=max_iterations,
                trace_enabled=trace_enabled,
                trace_output_dir=trace_output_dir,
                trace_verbosity=trace_verbosity,
            )
            results.append(result)
            clear_solver_caches()
            if verbose:
                if reporter:
                    reporter.on_progress(i, total, file_path, result)
                else:
                    if result.error:
                        print("\u274c Error")
                    elif result.issues:
                        print(f"\u26a0\ufe0f  {len(result.issues)} issues")
                    else:
                        print("\u2705")
        except Exception as e:
            if verbose:
                if reporter:
                    reporter.on_error(file_path, str(e))
                else:
                    print(f"\u274c Error: {e}")
    if verbose:
        if reporter:
            reporter.on_summary(results, total)
        else:
            _print_scan_summary(results, total)
    return results


def _scan_parallel(
    files: list[Path],
    workers_count: int,
    verbose: bool,
    max_paths: int,
    timeout: float,
    auto_tune: bool,
    reporter: ScanReporter | None = None,
    use_sandbox: bool = True,
    use_chtd: bool = True,
    use_h_acceleration: bool = True,
    deterministic_mode: bool = False,
    random_seed: int = 42,
    no_cache: bool = False,
    max_iterations: int = 0,
    trace_enabled: bool | None = None,
    trace_output_dir: str | None = None,
    trace_verbosity: str = "delta_only",
) -> list[ScanResult]:
    """Scan *files* across multiple worker processes.

    Uses chunked submission to cap memory usage.  Each chunk of
    ``_PARALLEL_CHUNK`` files is submitted; we wait for the whole chunk
    to finish before submitting the next one.  This keeps at most
    ``_PARALLEL_CHUNK`` futures alive at any time.

    Handles *KeyboardInterrupt* gracefully by cancelling pending futures
    and returning whatever results have been collected so far.
    """
    total = len(files)
    if verbose and not reporter:
        print(f"Scanning {total} file{'s' if total != 1 else ''} using {workers_count} workers...")

    results: list[ScanResult] = []
    completed = 0
    cancelled = False
    scan_errors: list[Exception] = []

    try:
        with concurrent.futures.ProcessPoolExecutor(
            max_workers=workers_count,
        ) as executor:
            future_to_file: dict[concurrent.futures.Future[ScanResult], Path] = {}
            file_iter = iter(files)

            for _ in range(workers_count):
                try:
                    f = next(file_iter)
                    fut = executor.submit(
                        scan_file,
                        file_path=f,
                        verbose=False,
                        max_paths=max_paths,
                        timeout=timeout,
                        auto_tune=auto_tune,
                        use_sandbox=use_sandbox,
                        use_chtd=use_chtd,
                        use_h_acceleration=use_h_acceleration,
                        deterministic_mode=deterministic_mode,
                        random_seed=random_seed,
                        no_cache=no_cache,
                        max_iterations=max_iterations,
                        trace_enabled=trace_enabled,
                        trace_output_dir=trace_output_dir,
                        trace_verbosity=trace_verbosity,
                    )
                    future_to_file[fut] = f
                except StopIteration:
                    break

            while future_to_file:
                if cancelled:
                    break

                done, _ = concurrent.futures.wait(
                    future_to_file.keys(), return_when=concurrent.futures.FIRST_COMPLETED
                )

                for future in done:
                    file_path = future_to_file.pop(future)
                    result = None
                    try:
                        result = future.result()
                        results.append(result)
                    except Exception as exc:
                        scan_errors.append(exc)
                        if verbose:
                            if reporter:
                                reporter.on_error(file_path, str(exc))
                            else:
                                print(f"âŒ Error scanning {file_path.name}: {exc}")

                    completed += 1
                    if verbose:
                        if reporter:
                            reporter.on_progress(completed, total, file_path, result)
                        else:
                            _print_parallel_progress(completed, total, file_path, result)

                    try:
                        f = next(file_iter)
                        fut = executor.submit(
                            scan_file,
                            file_path=f,
                            verbose=False,
                            max_paths=max_paths,
                            timeout=timeout,
                            auto_tune=auto_tune,
                            use_sandbox=use_sandbox,
                            use_chtd=use_chtd,
                            use_h_acceleration=use_h_acceleration,
                            deterministic_mode=deterministic_mode,
                            random_seed=random_seed,
                            no_cache=no_cache,
                            max_iterations=max_iterations,
                            trace_enabled=trace_enabled,
                            trace_output_dir=trace_output_dir,
                            trace_verbosity=trace_verbosity,
                        )
                        future_to_file[fut] = f
                    except StopIteration:
                        continue
    except KeyboardInterrupt:
        cancelled = True
        if verbose and not reporter:
            print(f"\n\u26a1 Interrupted \u2013 returning {len(results)} results collected so far.")
    except (RuntimeError, concurrent.futures.process.BrokenProcessPool) as exc:
        logger.warning("Parallel scanning failed (%s), falling back to sequential", exc)
        if reporter:
            reporter.on_status(
                "âš ï¸  Parallel scanning unavailable, falling back to sequential mode (workers=1)."
            )
        elif verbose:
            print(
                "âš ï¸  Parallel scanning unavailable, falling back to sequential mode (workers=1)."
            )
        return _scan_sequential(
            files=files,
            verbose=verbose,
            max_paths=max_paths,
            timeout=timeout,
            auto_tune=auto_tune,
            reporter=reporter,
            use_sandbox=use_sandbox,
            use_chtd=use_chtd,
            use_h_acceleration=use_h_acceleration,
            deterministic_mode=deterministic_mode,
            random_seed=random_seed,
            no_cache=no_cache,
            max_iterations=max_iterations,
            trace_enabled=trace_enabled,
            trace_output_dir=trace_output_dir,
            trace_verbosity=trace_verbosity,
        )

    if scan_errors and not cancelled:
        try:
            raise ExceptionGroup(
                f"scan: {len(scan_errors)} file(s) had errors",
                scan_errors,
            )
        except* OSError as eg:
            logger.warning("%d OS error(s) during parallel scan", len(eg.exceptions))
        except* Exception as eg:
            logger.warning("%d error(s) during parallel scan", len(eg.exceptions))

    if verbose and not cancelled:
        if reporter:
            reporter.on_summary(results, total)
        else:
            _print_scan_summary(results, total)
    return results


def _print_parallel_progress(
    completed: int,
    total: int,
    file_path: Path,
    result: ScanResult | None,
) -> None:
    """Print a single progress line for parallel scanning."""
    pct = completed * 100 // total if total > 0 else 0
    status = "âœ…"
    if result is None or result.error:
        status = "âŒ"
    elif result.issues:
        status = f"âš ï¸  {len(result.issues)}"
    print(f"[{completed}/{total}] ({pct}%) {file_path.name} {status}")


def _print_scan_summary(results: list[ScanResult], total_files: int) -> None:
    """Print end-of-scan summary."""
    total_issues = sum(len(r.issues) for r in results)
    files_with_issues = sum(1 for r in results if r.issues)
    errors = sum(1 for r in results if r.error)
    print(f"\nSummary: {total_issues} issues in {files_with_issues}/{len(results)} files", end="")
    if errors:
        print(f" ({errors} errors)")
    else:
        print()
    if len(results) < total_files:
        print(f"  âš ï¸  {total_files - len(results)} file(s) could not be scanned")


def on_file_event(event: object, reporter: ScanReporter | None = None) -> None:
    """Handle a file-system event from the watcher.

    Triggers :func:`analyze_file` for newly created or modified
    ``.py`` files.

    Args:
        event: A watch event with ``event_type`` and ``path`` attributes.
        reporter: Optional reporter for console output.
    """
    _ = reporter
    event_type = getattr(event, "event_type", None)
    event_path = getattr(event, "path", None)
    if event_type in (FileEventType.CREATED, FileEventType.MODIFIED) and isinstance(
        event_path, Path
    ):
        if event_path.suffix == ".py":
            analyze_file(event_path)


def print_final_summary(reporter: ScanReporter | None = None) -> None:
    """Print a formatted session summary to stdout.

    Reads the current :class:`ScanSession` from *_session_var* and
    displays file counts, issue breakdown, and the log-file path.
    Does nothing if no session is active.
    """
    session = _session_var.get()
    if not session:
        return
    if reporter:
        on_session_summary = getattr(reporter, "on_session_summary", None)
        if callable(on_session_summary):
            on_session_summary(session)
            return
    summary = session.get_summary()
    print(f"\n\n{'=' * 70}")
    print("\U0001f4cb SESSION SUMMARY")
    print("=" * 70)
    print(f"   Files scanned:     {summary['files_scanned']}")
    print(f"   Files with issues: {summary['files_with_issues']}")
    print(f"   Files clean:       {summary['files_clean']}")
    print(f"   Files with errors: {summary['files_error']}")
    print(f"   Total issues:      {summary['total_issues']}")
    print()
    issue_breakdown = summary["issue_breakdown"]
    if issue_breakdown:
        print("   Issue breakdown:")
        for kind, count in sorted(issue_breakdown.items(), key=_descending_issue_count):
            bar = "\u2588" * min(count, 30)
            print(f"      {kind:<25} {count:>4} {bar}")
    print(f"\n   \U0001f4c1 Log saved to: {session.log_file}")
    print("=" * 70)


def main() -> None:
    """CLI entry point for the scanner's watch mode.

    Parses ``--dir``, ``--log``, ``--watch``, ``--recursive`` arguments,
    performs an initial scan of existing files, and optionally enters
    continuous watch mode via :class:`pysymex.watch.FileWatcher`.
    """
    reporter: ScanReporter = ConsoleScanReporter()

    parser = argparse.ArgumentParser(description="pysymex Scanner")
    parser.add_argument(
        "--dir",
        "-d",
        type=str,
        default=".",
        help="Directory to scan/watch (default: current directory)",
    )
    parser.add_argument(
        "--log",
        "-l",
        type=str,
        default=None,
        help="Log file path (default: scan_log_TIMESTAMP.json)",
    )
    parser.add_argument(
        "--watch",
        "-w",
        action="store_true",
        help="Watch mode: continuously monitor for file changes",
    )
    parser.add_argument(
        "--recursive",
        "-r",
        action="store_true",
        default=True,
        help="Scan subdirectories recursively (default: True)",
    )
    parser.add_argument(
        "--auto-tune",
        "-at",
        action="store_true",
        help="Automatically tune execution parameters based on code complexity",
    )
    parser.add_argument(
        "--max-paths",
        type=int,
        default=200,
        help="Maximum paths to explore (default: 200)",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=30.0,
        help="Timeout per file in seconds (default: 30.0)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=0,
        help="Number of worker processes (0=auto)",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Disable all caching",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=0,
        help="Maximum iterations per function",
    )
    parser.add_argument(
        "--trace",
        action="store_true",
        help="Enable detailed execution tracing (generates JSONL logs)",
    )
    args = parser.parse_args()
    scan_dir = Path(args.dir)
    log_file = Path(args.log) if args.log else None
    if not scan_dir.exists():
        reporter.on_error(scan_dir, f"Directory '{scan_dir}' does not exist")
        sys.exit(1)
    session = ScanSession(log_file=log_file)
    _session_var.set(session)
    pattern = "**/*.py" if args.recursive else "*.py"
    existing_files = list(scan_dir.glob(pattern))
    if existing_files:
        results = scan_directory(
            scan_dir,
            pattern=pattern,
            max_paths=args.max_paths,
            timeout=args.timeout,
            workers=args.workers,
            auto_tune=args.auto_tune,
            reporter=reporter,
            no_cache=args.no_cache,
            max_iterations=args.max_iterations,
            trace_enabled=args.trace,
        )
        if session:
            for r in results:
                session.add_result(r)
    else:
        reporter.on_status(f"No Python files found in {scan_dir}")
    if args.watch:
        reporter.on_status(
            "\n\u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557\n"
            "\u2551                   pysymex Scanner - Watch Mode                     \u2551\n"
            "\u2551  Press Ctrl+C to stop and see summary.                               \u2551\n"
            "\u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d\n"
        )
        watcher = FileWatcher(paths=[scan_dir], patterns=["*.py"])

        def _handle_watch_event(evt: object) -> None:
            on_file_event(evt, reporter=reporter)

        watcher.on_change(_handle_watch_event)
        watcher.start()
        try:
            reporter.on_status("\U0001f441\ufe0f  Watching for file changes...")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            reporter.on_status("\n\nStopping watcher...")
            watcher.stop()
    print_final_summary(reporter=reporter)
    reporter.on_status("\nDone.")


if __name__ == "__main__":
    main()
