"""Types for faz MODULE 6 — Audit Log.

Phase 1.5 changes:
  * Replaced agent identity fields (`user`, `agent_id`) with a single
    `transport` field on `AuditEntry`. faz has no agent identity model;
    the transport (`mcp/stdio` | `rest/local` | `cli`) is the only
    attribution we keep.
  * Added `TableAccessDecision` and `RBACaudit.table_access_decisions`
    so the per-family extractor's verdicts are captured per-table.
  * Added `RBACaudit.parse_error` so fail-closed BLOCKs from extractor
    crashes are debuggable.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class AuthAudit:
    method: str = ""        # "TRANSPORT_TRUST" for v1
    outcome: str = ""       # PASS, FAIL
    roles: list[str] = field(default_factory=list)
    error: str = ""


@dataclass
class TableAccessDecision:
    """One row per AccessTarget evaluated by RBACGate.

    The per-family extractor produces a list of AccessTargets per IRStep.
    RBACGate evaluates each independently and records the verdict here.
    """

    database: str = ""
    table: str = ""
    requested_op: str = ""          # SELECT, INSERT, UPDATE, DELETE, DDL
    level_required: str = ""        # R, W, RW, RA, RWA, A — minimum that satisfies
    level_granted: str = ""         # what the policy actually grants ("" = no policy)
    decision: str = ""              # ALLOW, BLOCK


@dataclass
class RBACaudit:
    requested: list[str] = field(default_factory=list)
    stripped: list[str] = field(default_factory=list)
    outcome: str = ""               # PASS, PARTIAL, BLOCK
    table_access_decisions: list[TableAccessDecision] = field(default_factory=list)
    parse_error: str | None = None  # Set when extractor crashed → fail-closed BLOCK


@dataclass
class ASTAudit:
    blocked_nodes: list[str] = field(default_factory=list)
    outcome: str = ""  # PASS, BLOCK


@dataclass
class InjectionAudit:
    patterns_matched: list[str] = field(default_factory=list)
    outcome: str = ""  # PASS, BLOCK


@dataclass
class ExecutionAudit:
    sources_hit: list[str] = field(default_factory=list)
    rows_loaded: dict[str, int] = field(default_factory=dict)
    merge_sql: str = ""
    merge_latency_ms: float = 0.0
    iteration_count: int = 0


@dataclass
class ResultAudit:
    rows_returned: int = 0
    streamed_via: str = "SSE"
    citations_attached: bool = False
    error: str = ""


@dataclass
class LatencyAudit:
    auth_ms: float = 0.0
    safety_ms: float = 0.0
    execution_ms: float = 0.0
    response_ms: float = 0.0
    total_ms: float = 0.0


@dataclass
class AuditEntry:
    """Full audit log entry for one request — correlated by trace_id.

    `transport` is the only caller-attribution faz keeps. Values:
      * "mcp/stdio"   — MCP client connected via stdio (Claude, Cursor, …)
      * "rest/local"  — REST request from loopback
      * "cli"         — `faz query` invoked the engine directly
    """

    trace_id: str = ""
    timestamp: str = ""
    transport: str = ""             # mcp/stdio | rest/local | cli
    source_ip: str = ""             # request origin (127.0.0.1 for local)

    auth: AuthAudit = field(default_factory=AuthAudit)
    rbac: RBACaudit = field(default_factory=RBACaudit)
    ast: ASTAudit = field(default_factory=ASTAudit)
    injection_scan: InjectionAudit = field(default_factory=InjectionAudit)
    execution: ExecutionAudit = field(default_factory=ExecutionAudit)
    result: ResultAudit = field(default_factory=ResultAudit)
    latency: LatencyAudit = field(default_factory=LatencyAudit)

    def set_timestamp(self) -> None:
        self.timestamp = datetime.now(timezone.utc).isoformat()
