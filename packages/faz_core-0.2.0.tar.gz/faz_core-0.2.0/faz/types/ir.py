from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faz.safety.types import QueryLanguage


class Strategy(enum.Enum):
    """How the query engine should execute the IR steps."""

    PARALLEL = "PARALLEL"
    FETCH_THEN_LINK = "FETCH_THEN_LINK"
    SEQUENTIAL_CHAIN = "SEQUENTIAL_CHAIN"


@dataclass
class IRStep:
    """A single data-fetch step inside the IR.

    `database` and `table` are the *declared* target. RBACGate evaluates
    them, but it ALSO walks `raw_query` via the per-family access
    extractor to find any additional tables touched (JOINs, $lookup,
    Cypher rebound labels, ES _reindex dst, etc.). The declared target
    is necessary but not sufficient.

    `source` is kept as a derived back-compat field — pre-Phase-1 callers
    that parse `source.split(".", 1)` keep working without changes. New
    code should read `step.database` and `step.table` directly.
    """

    database: str = ""                       # connector name from faz.yaml
    table: str = ""                          # table/collection/index/label
    step_id: str = ""                        # "s0", "s1" — used for DAG edges
    source: str = ""                         # derived = f"{database}.{table}"
    language: "QueryLanguage | None" = None  # explicit; not inferred from connector
    depends_on: list[str] = field(default_factory=list)
    filter: str | None = None
    project: list[str] = field(default_factory=list)
    select: str | None = None
    link_key: str | None = None              # deprecated: use link_from/link_to
    link_from: str | None = None             # field to extract from dependency's results
    link_to: str | None = None               # field to filter on in this step's query
    raw_query: str | None = None             # native query in the source's language
    allow_ddl: bool = False                  # True when safety pipeline pre-approved DDL (AccessMode.A)

    def __post_init__(self) -> None:
        # Back-compat path A: caller passed only `source`. Split it.
        if self.source and not self.database:
            parts = self.source.split(".", 1)
            self.database = parts[0]
            self.table = parts[1] if len(parts) > 1 else ""
        # Forward path B: caller passed `database`/`table`. Derive `source`.
        elif self.database and not self.source:
            self.source = (
                f"{self.database}.{self.table}" if self.table else self.database
            )


@dataclass
class IntermediateRepr:
    """The structured query plan submitted by the agent.

    Downstream modules (Safety, DB Connectors, DuckDB) consume this.
    The execution order is derived from the DAG encoded in IRStep.depends_on.
    """

    steps: list[IRStep] = field(default_factory=list)
    strategy: Strategy | None = None  # Deprecated — kept for backward compat only
    raw_response: str | None = None
