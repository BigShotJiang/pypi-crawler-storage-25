"""faz MODULE 1 — Auth.

The default implementation is `PolicyLoader` (Phase 2) — a static
loader that reads `faz.yaml` once at startup and never writes. There
is no agent identity and no auth challenge in v1; the trust boundary
is the listening socket (`faz serve` binds 127.0.0.1 by default).
"""

from .base import AuthModule
from .policy_loader import PolicyLoader
from .types import AuthMethod, AuthOutcome, AuthResult, Permission, UserIdentity

__all__ = [
    "AuthMethod",
    "AuthModule",
    "AuthOutcome",
    "AuthResult",
    "Permission",
    "PolicyLoader",
    "UserIdentity",
]
