"""PolicyLoader — static AuthModule that reads faz.yaml once at startup.

Replaces the deleted PocketBaseAuth. Implements the existing `AuthModule`
ABC at `src/auth/base.py` with a "no challenge" behavior:

  * No agent identity. There are no users in faz; `identify()` wraps
    the request's transport string in a synthetic `UserIdentity` so
    the ABC's signature is satisfied.
  * No auth challenge. Every accepted request gets the same single
    permission policy that was loaded from `faz.yaml`. Trust comes
    from the listening socket — `faz serve` binds 127.0.0.1 by
    default; remote exposure is the dev's responsibility (reverse
    proxy with their own auth backend).

Usage:

    pl = PolicyLoader("faz.yaml")            # called once at startup
    perms = pl.permissions                    # for direct use by RBACGate
    result = await pl.authenticate(request)   # for FastAPI / MCP layers

The `authenticate()` method is inherited from the ABC. The default
implementation runs identify → resolve_permissions → build AuthResult,
which is exactly what we want here.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .base import AuthModule
from .types import Permission, UserIdentity

if TYPE_CHECKING:
    from faz.config.db_loader import FazConfig

logger = logging.getLogger(__name__)


# Hostnames considered "loopback" for transport detection. ASGI servers
# normally pass the IP literal; "localhost" appears rarely but harmlessly.
_LOOPBACK_HOSTS: frozenset[str] = frozenset({
    "127.0.0.1", "::1", "localhost",
})


class PolicyLoader(AuthModule):
    """Static policy loader. Reads faz.yaml once, never writes."""

    def __init__(self, faz_yaml_path: str | Path | None = None) -> None:
        # Deferred import: faz.config.db_loader imports `Permission`
        # from faz.auth.types, which would trigger this module via
        # auth/__init__.py and create a circular import. Importing
        # at call time breaks the cycle without changing the API.
        from faz.config.db_loader import load_faz_config

        self._config: FazConfig = load_faz_config(faz_yaml_path)
        logger.info(
            "PolicyLoader: %d permission row(s), %d safety key(s)",
            len(self._config.permissions), len(self._config.safety),
        )

    # ------------------------------------------------------------------
    # Cached config exposure
    # ------------------------------------------------------------------

    @property
    def permissions(self) -> list[Permission]:
        """Defensive copy of the loaded permission rows."""
        return list(self._config.permissions)

    @property
    def safety(self) -> dict[str, Any]:
        """Defensive copy of the loaded safety defaults."""
        return dict(self._config.safety)

    # ------------------------------------------------------------------
    # AuthModule ABC implementation
    # ------------------------------------------------------------------

    async def identify(self, request: Any) -> UserIdentity:
        """Map the request to a transport string, wrapped as `UserIdentity`.

        The ABC requires a `UserIdentity`; faz has no user concept, so we
        use it as a thin envelope around the transport string.

        Accepts:
          * a plain string (`"mcp/stdio"`, `"cli"`, etc.) — explicit hint
            from MCP / CLI callers that don't have a Request object
          * a FastAPI `Request` (or any object with `.client.host`) —
            inspected to decide loopback vs remote
          * `None` or an unrecognized shape → `"unknown"`
        """
        transport = self._detect_transport(request)
        return UserIdentity(
            user_id=transport,
            email="",
            display_name=transport,
            metadata={"transport": transport},
        )

    async def resolve_permissions(
        self,
        identity: UserIdentity,
        token: str | None = None,
    ) -> list[Permission]:
        """Return the cached policy. Identity is irrelevant — the policy
        is global to the whole faz instance.
        """
        return self.permissions

    def can_access(self, permissions: list[Permission], resource: str) -> bool:
        """Match the `"db.table"` resource convention used by RBACGate.

        Specific overrides win; per-database wildcards (`table_name == "*"`)
        are the fallback. No-policy → False (default-deny).
        """
        if not resource:
            return False

        # 1. Exact (db, table) match
        for p in permissions:
            if p.resource == resource:
                return True

        # 2. Wildcard fallback per-database
        for p in permissions:
            if p.table_name == "*" and resource.startswith(f"{p.database_uri}."):
                return True

        return False

    # ------------------------------------------------------------------
    # Transport detection
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_transport(request: Any) -> str:
        """Identify the request's transport.

        Returns one of:
          * `"mcp/stdio"`  | `"cli"`  — from explicit string hints
          * `"rest/local"`             — FastAPI request from loopback
          * `"rest/remote"`            — FastAPI request from non-loopback
                                         (only possible when the dev runs
                                         `faz serve --host 0.0.0.0`)
          * `"unknown"`                — no request shape we recognize
        """
        if request is None:
            return "unknown"

        if isinstance(request, str):
            return request

        client = getattr(request, "client", None)
        if client is not None:
            host = getattr(client, "host", None) or ""
            if host in _LOOPBACK_HOSTS:
                return "rest/local"
            return "rest/remote"

        return "unknown"
