"""Abstract base for all faz auth providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .types import AuthResult, Permission, UserIdentity


class AuthModule(ABC):
    """Interface every auth provider must implement."""

    @abstractmethod
    async def identify(self, request: Any) -> UserIdentity:
        """Extract and verify user identity from a request (e.g. Bearer token)."""

    @abstractmethod
    async def resolve_permissions(self, identity: UserIdentity, token: str | None = None) -> list[Permission]:
        """Load permissions for the given user."""

    @abstractmethod
    def can_access(self, permissions: list[Permission], resource: str) -> bool:
        """Check whether *permissions* grant access to *resource*."""

    async def authenticate(self, request: Any) -> AuthResult:
        """Full auth pipeline: identify -> resolve permissions -> build result."""
        from .types import AuthOutcome

        try:
            identity = await self.identify(request)
        except Exception as exc:
            return AuthResult(outcome=AuthOutcome.DENIED, error=str(exc))

        if not identity.is_active:
            return AuthResult(
                outcome=AuthOutcome.DENIED,
                identity=identity,
                error="User account is deactivated",
            )

        permissions = await self.resolve_permissions(identity)
        return AuthResult(
            outcome=AuthOutcome.AUTHENTICATED,
            identity=identity,
            permissions=permissions,
        )
