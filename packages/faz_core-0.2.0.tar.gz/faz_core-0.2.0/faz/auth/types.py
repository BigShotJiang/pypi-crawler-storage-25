"""Auth types for faz MODULE 1.

`AuthResult.permissions` carries the single permission policy loaded
from `faz.yaml`. Each `Permission` row is either:

  * the per-database baseline  (when `table_name == "*"`), or
  * an optional per-table override (specific table name).

Both layers use the same `AccessMode` enum from `src/safety/types.py`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from faz.safety.types import AccessMode


class AuthMethod(str, Enum):
    JWT = "JWT"
    OIDC = "OIDC"
    SAML = "SAML"
    POCKETBASE = "POCKETBASE"


class AuthOutcome(str, Enum):
    AUTHENTICATED = "AUTHENTICATED"
    DENIED = "DENIED"
    EXPIRED = "EXPIRED"
    INVALID = "INVALID"


@dataclass
class Permission:
    """One row of the permission policy.

    A row is either a per-database baseline (`table_name == "*"`) or a
    per-table override (`table_name` = a specific table). RBACGate
    looks up specific overrides first, then falls back to the wildcard
    baseline.

    `access_level` is typed as `AccessMode`, but the dataclass accepts
    raw strings on construction so YAML loaders can pass values through
    without coercing first.
    """

    database_uri: str
    table_name: str
    access_level: AccessMode

    def __post_init__(self) -> None:
        if isinstance(self.access_level, str) and not isinstance(self.access_level, AccessMode):
            self.access_level = AccessMode(self.access_level)

    @property
    def resource(self) -> str:
        """Format as 'database_uri.table_name' for RBAC Gate matching."""
        return f"{self.database_uri}.{self.table_name}"

    @property
    def resource_with_mode(self) -> str:
        """Format as 'database_uri.table_name:access_level' for full matching."""
        return f"{self.database_uri}.{self.table_name}:{self.access_level.value}"

    @property
    def is_baseline(self) -> bool:
        """True when this row is the per-database baseline (wildcard)."""
        return self.table_name == "*"


@dataclass
class UserIdentity:
    user_id: str
    email: str
    display_name: str = ""
    is_active: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class AuthResult:
    outcome: AuthOutcome
    identity: UserIdentity | None = None
    permissions: list[Permission] = field(default_factory=list)
    token: str | None = None
    error: str | None = None
