"""FastAPI app factory — single source of truth.

Both the `faz serve` CLI and the legacy `uvicorn main:app` invocation
go through ``create_app()``. Lives inside the installed ``faz`` package
so it resolves no matter what the user's cwd is — earlier the app was
defined in ``main.py`` at the project root, which only imported when
the cwd happened to be the ``faz/`` source directory.
"""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI

from faz.api.router import setup_api
from faz.runtime import build_runtime, resolve_config_path, shutdown_runtime


def create_app() -> FastAPI:
    """Build a configured FastAPI app.

    The lifespan loads `faz.yaml`, opens every DB connection, starts
    the scratchpad reaper, and attaches the runtime singletons to
    ``app.state`` for the FastAPI dependency injectors in
    ``faz/api/_deps.py``.

    Auth: there isn't any. faz binds 127.0.0.1 by default; remote
    exposure is the dev's responsibility (reverse proxy with their own
    auth backend). See `faz/auth/policy_loader.py` and the Phase 4
    section of `plan.md` for the full rationale.
    """
    # One-time logging config — safe to call on every create_app() because
    # basicConfig is a no-op once a handler is already attached.
    logging.basicConfig(
        level=os.getenv("FAZ_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        rt = await build_runtime(resolve_config_path())
        app.state.policy = rt.policy
        app.state.registry = rt.registry
        app.state.scratchpads = rt.scratchpads
        app.state.pipeline = rt.pipeline
        app.state.engine = rt.engine
        app.state.audit = rt.audit
        yield
        await shutdown_runtime(rt)

    app = FastAPI(
        title="faz",
        description=(
            "Safe multi-database access for AI agents. "
            "MCP server + REST API in front of the database layer, with a "
            "5-stage safety pipeline and per-table R/W/RW permissions."
        ),
        version="0.2.0",
        lifespan=lifespan,
    )
    setup_api(app)
    return app


# Eager singleton so `uvicorn faz.app:app` works without a factory call.
app = create_app()
