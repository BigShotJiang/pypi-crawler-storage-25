"""Safety Pipeline — chains Stage 1 (RBAC Gate) and Stage 2 (AST Checker).

Usage:
    from faz.safety import SafetyPipeline

    pipeline = SafetyPipeline()
    result = pipeline.run(ir, permissions, raw_sql)
    if not result.allowed:
        # reject the request
"""

from __future__ import annotations

import logging

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr

from .ast_checker import ASTChecker
from .guardrails import Guardrails
from .injection_analyser import InjectionAnalyser
from .prompt_guard import PromptGuard
from .rbac_gate import DenyPolicy, RBACGate
from .types import SecurityEvent, Severity, StageResult, StageVerdict, ValidationResult

logger = logging.getLogger(__name__)


class SafetyPipeline:
    """Orchestrates safety stages in sequence (fail-fast)."""

    def __init__(
        self,
        deny_policy: DenyPolicy = DenyPolicy.PARTIAL,
        safety_config: dict | None = None,
    ) -> None:
        """Build the 5-stage pipeline.

        ``safety_config`` is the ``safety:`` block from faz.yaml. When
        provided, its keys are passed into :class:`Guardrails` so
        ``max_rows_per_query`` / ``query_timeout_seconds`` come from the
        user's config rather than hardcoded defaults.
        """
        # Bug fix #2 (build-plan.md): PromptGuard runs first.
        self._prompt_guard = PromptGuard()
        self._rbac_gate = RBACGate(policy=deny_policy)
        self._ast_checker = ASTChecker()
        self._injection_analyser = InjectionAnalyser()

        cfg = safety_config or {}
        self._guardrails = Guardrails(
            row_cap=int(cfg.get("max_rows_per_query") or 1000),
            timeout_seconds=int(cfg.get("query_timeout_seconds") or 30),
        )

    def run(
        self,
        ir: IntermediateRepr,
        permissions: list[Permission] | None,
        raw_sql: dict[str, str] | None = None,
    ) -> ValidationResult:
        """Run the LLM response through the safety pipeline.

        Args:
            ir: The intermediate representation from MODULE 2.
            permissions: User permissions from MODULE 1 (AuthResult.permissions).
                         If None, the user is not logged in.
            raw_sql: Mapping of source -> generated SQL string (for AST checking).

        Returns:
            ValidationResult with allowed=True/False and detailed events.
        """
        # No permissions = not logged in
        if permissions is None:
            return ValidationResult(
                allowed=False,
                login_required=True,
                stages=[StageResult(
                    stage="AUTH_CHECK",
                    verdict=StageVerdict.BLOCK,
                    events=[SecurityEvent(
                        stage="AUTH_CHECK",
                        severity=Severity.BLOCK,
                        message="Authentication required. Please login first.",
                    )],
                )],
                events=[SecurityEvent(
                    stage="AUTH_CHECK",
                    severity=Severity.BLOCK,
                    message="Authentication required. Please login first.",
                )],
            )

        # Bug fix #4 (build-plan.md): don't mutate the caller's list.
        permissions = list(permissions)

        # Default: authenticated users get read-only access to any source
        # not explicitly covered by their permissions
        from faz.auth.types import Permission
        covered = set()
        for perm in permissions:
            if perm.table_name == "*":
                # Wildcard covers all tables in that database
                for step in ir.steps:
                    if step.source.startswith(f"{perm.database_uri}."):
                        covered.add(step.source)
            else:
                covered.add(perm.resource)

        for step in ir.steps:
            if step.source not in covered:
                permissions.append(Permission(
                    database_uri=step.source.split(".")[0],
                    table_name=step.source.split(".", 1)[1] if "." in step.source else "*",
                    access_level="R",
                ))

        result = ValidationResult(allowed=True)

        # Stage 0: Prompt Guard (destructive intent in raw query text)
        prompt_result = self._prompt_guard.validate(ir, permissions, raw_sql)
        result.stages.append(prompt_result)
        result.events.extend(prompt_result.events)

        if prompt_result.verdict == StageVerdict.BLOCK:
            result.allowed = False
            logger.warning("Safety pipeline BLOCKED at Prompt Guard")
            return result

        # Stage 1: RBAC Gate
        rbac_result = self._rbac_gate.validate(ir, permissions, raw_sql)
        result.stages.append(rbac_result)
        result.events.extend(rbac_result.events)

        if rbac_result.verdict == StageVerdict.BLOCK:
            result.allowed = False
            logger.warning("Safety pipeline BLOCKED at RBAC Gate")
            return result

        if rbac_result.verdict == StageVerdict.PARTIAL:
            result.stripped_sources = [
                e.message.replace("Access denied to source: ", "")
                for e in rbac_result.events
            ]

        # Stage 2: AST Checker
        ast_result = self._ast_checker.validate(ir, permissions, raw_sql)
        result.stages.append(ast_result)
        result.events.extend(ast_result.events)

        if ast_result.verdict == StageVerdict.BLOCK:
            result.allowed = False
            logger.warning("Safety pipeline BLOCKED at AST Checker")
            return result

        # Stage 3: Injection Pattern Analyser
        injection_result = self._injection_analyser.validate(ir, permissions, raw_sql)
        result.stages.append(injection_result)
        result.events.extend(injection_result.events)

        if injection_result.verdict == StageVerdict.BLOCK:
            result.allowed = False
            logger.warning("Safety pipeline BLOCKED at Injection Analyser")
            return result

        # Stage 4: Execution Path Optimiser + Guardrails
        guardrails_result = self._guardrails.validate(ir, permissions, raw_sql)
        result.stages.append(guardrails_result)
        result.events.extend(guardrails_result.events)

        # Guardrails never blocks — it only warns and rewrites.
        # Bug fix #3 (build-plan.md): use getattr() defensively. The Guardrails
        # stage attaches `rewritten_sql` dynamically; older snapshots used
        # the wrong attribute name `rewritten_queries`.
        rewritten = getattr(guardrails_result, "rewritten_sql", None)
        if rewritten is not None:
            result.rewritten_sql = rewritten  # type: ignore[attr-defined]

        return result
