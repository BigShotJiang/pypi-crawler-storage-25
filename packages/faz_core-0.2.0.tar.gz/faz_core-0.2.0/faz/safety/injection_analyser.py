"""Stage 3 — Injection Pattern Analyser.

Multi-language injection scanner that dispatches to language-specific
pattern detectors based on QueryLanguage.

SQL patterns:
  - Tautology injection (WHERE 1=1, OR 'a'='a')          → BLOCK
  - Comment sequences (--, /*, #)                         → BLOCK
  - Stacked statements (SELECT ...; DROP TABLE ...)       → BLOCK
  - Blind boolean probing (SLEEP, WAITFOR, BENCHMARK)     → BLOCK
  - Out-of-band exfiltration (LOAD_FILE, INTO OUTFILE)    → BLOCK
  - Stored procedure abuse (EXEC xp_cmdshell, CALL)       → BLOCK
  - Schema enumeration (information_schema, pg_catalog)   → WARN
  - Excessive wildcards (SELECT * with no projection)     → WARN
  - Deeply nested subqueries (depth > 5)                  → WARN

MQL patterns:
  - $where (server-side JS execution)                     → BLOCK
  - $out / $merge (write pipeline stages)                 → BLOCK
  - $function / $accumulator (arbitrary JS)               → BLOCK
  - JavaScript injection in string values                 → BLOCK

Cypher patterns:
  - APOC procedure abuse (apoc.load.*, apoc.cypher.run)   → BLOCK
  - LOAD CSV FROM (file access)                           → BLOCK
  - Stacked Cypher via semicolons                         → BLOCK

ES_DSL patterns:
  - script / scripted_field (Painless script injection)   → BLOCK
  - runtime_mappings with script                          → BLOCK
"""

from __future__ import annotations

import json
import logging
import re

import sqlglot
from sqlglot import exp

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr

from .base import SafetyStage
from .types import (
    QueryLanguage,
    SecurityEvent,
    Severity,
    StageResult,
    StageVerdict,
    resolve_query_language,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# SQL pattern definitions
# ---------------------------------------------------------------------------

_TAUTOLOGY_RE = re.compile(
    r"""(?:
        \b1\s*=\s*1\b
        | \b0\s*=\s*0\b
        | '[^']*'\s*=\s*'[^']*'
        | "[^"]*"\s*=\s*"[^"]*"
        | \btrue\s*=\s*true\b
    )""",
    re.IGNORECASE | re.VERBOSE,
)

_COMMENT_RE = re.compile(r"--|/\*|#\s")

_BLIND_FUNCS = re.compile(
    r"\b(?:SLEEP|WAITFOR\s+DELAY|BENCHMARK|PG_SLEEP)\s*\(",
    re.IGNORECASE,
)

_OOB_RE = re.compile(
    r"\b(?:LOAD_FILE|INTO\s+(?:OUT|DUMP)FILE|UTL_HTTP|DBMS_PIPE)\s*\(",
    re.IGNORECASE,
)

_PROC_ABUSE_RE = re.compile(
    r"\b(?:EXEC(?:UTE)?\s+(?:xp_|sp_)|xp_cmdshell|CALL\s+\w+)\b",
    re.IGNORECASE,
)

_SCHEMA_ENUM_RE = re.compile(
    r"\b(?:information_schema|pg_catalog|sys\.(?:tables|columns|objects)|all_tables|user_tables|sysobjects)\b",
    re.IGNORECASE,
)

_STACKED_RE = re.compile(
    r";\s*(?:DROP|DELETE|INSERT|UPDATE|ALTER|TRUNCATE|CREATE|EXEC|GRANT|REVOKE)\b",
    re.IGNORECASE,
)

MAX_SUBQUERY_DEPTH = 5

# ---------------------------------------------------------------------------
# MQL pattern definitions
# ---------------------------------------------------------------------------

_MQL_DANGEROUS_KEYS = {"$where", "$function", "$accumulator"}
_MQL_WRITE_STAGES = {"$out", "$merge"}

_MQL_JS_RE = re.compile(
    r"(?:function\s*\(|this\.\w+|sleep\s*\(|while\s*\(|for\s*\()",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Cypher pattern definitions
# ---------------------------------------------------------------------------

_CYPHER_APOC_RE = re.compile(
    r"\b(?:apoc\.load\.\w+|apoc\.cypher\.run(?:Many)?|apoc\.periodic\.\w+|apoc\.export\.\w+)\b",
    re.IGNORECASE,
)

_CYPHER_LOAD_CSV_RE = re.compile(r"\bLOAD\s+CSV\s+FROM\b", re.IGNORECASE)

_CYPHER_STACKED_RE = re.compile(
    r";\s*(?:CREATE|MERGE|DELETE|DROP|REMOVE|DETACH|CALL)\b",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# ES_DSL pattern definitions
# ---------------------------------------------------------------------------

_ES_SCRIPT_KEYS = {"script", "scripted_field", "script_fields", "runtime_mappings"}


class InjectionAnalyser(SafetyStage):
    """Stage 3: multi-language injection pattern scanner."""

    def validate(
        self,
        ir: IntermediateRepr,
        permissions: list[Permission],
        raw_sql: dict[str, str] | None = None,
    ) -> StageResult:
        events: list[SecurityEvent] = []

        # Scan IR filter expressions — dispatch by source language
        for step in ir.steps:
            if step.filter:
                lang = resolve_query_language(step.source)
                if lang == QueryLanguage.SQL:
                    events.extend(self._scan_sql_text(step.filter, f"IR filter ({step.source})"))
                elif lang == QueryLanguage.MQL:
                    events.extend(self._scan_mql(step.filter, f"IR filter ({step.source})"))
                elif lang == QueryLanguage.CYPHER:
                    events.extend(self._scan_cypher(step.filter, f"IR filter ({step.source})"))
                elif lang == QueryLanguage.ES_DSL:
                    events.extend(self._scan_es_dsl(step.filter, f"IR filter ({step.source})"))
                # VECTOR, DYNAMO, COUCHDB — no SQL patterns to check on filters

        # Scan raw queries with language dispatch
        if raw_sql:
            for source, query_text in raw_sql.items():
                language = resolve_query_language(source)

                if language == QueryLanguage.SQL:
                    events.extend(self._scan_sql_text(query_text, source))
                    events.extend(self._scan_sql_ast(query_text, source))
                elif language == QueryLanguage.MQL:
                    events.extend(self._scan_mql(query_text, source))
                elif language == QueryLanguage.CYPHER:
                    events.extend(self._scan_cypher(query_text, source))
                elif language == QueryLanguage.ES_DSL:
                    events.extend(self._scan_es_dsl(query_text, source))
                # VECTOR, DYNAMO, COUCHDB — no injection patterns to scan at this layer

        blocked = any(e.severity == Severity.BLOCK for e in events)
        return StageResult(
            stage="INJECTION_ANALYSER",
            verdict=StageVerdict.BLOCK if blocked else StageVerdict.PASS,
            events=events,
        )

    # ------------------------------------------------------------------
    # SQL scanning (existing logic)
    # ------------------------------------------------------------------

    def _scan_sql_text(self, text: str, context: str) -> list[SecurityEvent]:
        """Regex-based pattern scanning on raw SQL text."""
        events: list[SecurityEvent] = []

        if _TAUTOLOGY_RE.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"Tautology injection detected in {context}",
                detail="Always-true condition found (e.g. 1=1, 'a'='a')",
            ))

        if _COMMENT_RE.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"SQL comment sequence detected in {context}",
                detail="Comment markers (--, /*, #) can be used to bypass filters",
            ))

        if _BLIND_FUNCS.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"Blind boolean/time-based probing detected in {context}",
                detail="Functions like SLEEP(), WAITFOR DELAY, BENCHMARK() are blocked",
            ))

        if _OOB_RE.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"Out-of-band exfiltration attempt detected in {context}",
                detail="Functions like LOAD_FILE(), INTO OUTFILE are blocked",
            ))

        if _PROC_ABUSE_RE.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"Stored procedure abuse detected in {context}",
                detail="System procedure calls (xp_cmdshell, EXEC sp_) are blocked",
            ))

        if _STACKED_RE.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"Stacked statement detected in {context}",
                detail="Multiple statements with dangerous operations are blocked",
            ))

        if _SCHEMA_ENUM_RE.search(text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.WARN,
                message=f"Schema enumeration detected in {context}",
                detail="Queries against information_schema/pg_catalog are flagged",
            ))

        return events

    def _scan_sql_ast(self, sql: str, source: str) -> list[SecurityEvent]:
        """AST-based scanning for structural SQL patterns."""
        events: list[SecurityEvent] = []

        try:
            statements = sqlglot.parse(sql)
        except sqlglot.errors.ParseError:
            return events  # Parse errors already caught by Stage 2

        for stmt in statements:
            if stmt is None:
                continue

            stars = list(stmt.find_all(exp.Star))
            if stars:
                events.append(SecurityEvent(
                    stage="INJECTION_ANALYSER",
                    severity=Severity.WARN,
                    message=f"Excessive wildcard (SELECT *) in {source}",
                    detail="Consider specifying explicit columns",
                ))

            depth = self._max_subquery_depth(stmt)
            if depth > MAX_SUBQUERY_DEPTH:
                events.append(SecurityEvent(
                    stage="INJECTION_ANALYSER",
                    severity=Severity.WARN,
                    message=f"Deeply nested subqueries (depth={depth}) in {source}",
                    detail=f"Maximum recommended depth is {MAX_SUBQUERY_DEPTH}",
                ))

        return events

    # ------------------------------------------------------------------
    # MQL scanning
    # ------------------------------------------------------------------

    def _scan_mql(self, query_text: str, source: str) -> list[SecurityEvent]:
        """Scan a MongoDB query for injection patterns."""
        events: list[SecurityEvent] = []

        if _MQL_JS_RE.search(query_text):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"JavaScript injection pattern detected in MQL for {source}",
                detail="Patterns like function(), this.*, sleep() are blocked in MQL",
            ))

        try:
            parsed = json.loads(query_text)
        except (json.JSONDecodeError, TypeError):
            return events

        self._scan_mql_recursive(parsed, source, events)
        return events

    def _scan_mql_recursive(
        self, obj: object, source: str, events: list[SecurityEvent]
    ) -> None:
        """Recursively scan a parsed MQL document for dangerous keys."""
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key in _MQL_DANGEROUS_KEYS:
                    events.append(SecurityEvent(
                        stage="INJECTION_ANALYSER",
                        severity=Severity.BLOCK,
                        message=f"Dangerous MQL operator '{key}' detected in {source}",
                        detail=f"Operator '{key}' allows arbitrary code execution and is blocked",
                    ))
                if key in _MQL_WRITE_STAGES:
                    events.append(SecurityEvent(
                        stage="INJECTION_ANALYSER",
                        severity=Severity.BLOCK,
                        message=f"Write pipeline stage '{key}' detected in {source}",
                        detail=f"Stage '{key}' writes data and is blocked",
                    ))
                self._scan_mql_recursive(value, source, events)
        elif isinstance(obj, list):
            for item in obj:
                self._scan_mql_recursive(item, source, events)

    # ------------------------------------------------------------------
    # Cypher scanning
    # ------------------------------------------------------------------

    def _scan_cypher(self, cypher: str, source: str) -> list[SecurityEvent]:
        """Scan a Cypher query for injection patterns."""
        events: list[SecurityEvent] = []

        if _CYPHER_APOC_RE.search(cypher):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"APOC procedure abuse detected in Cypher for {source}",
                detail="Dangerous APOC procedures (load, cypher.run, export) are blocked",
            ))

        if _CYPHER_LOAD_CSV_RE.search(cypher):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"LOAD CSV file access detected in Cypher for {source}",
                detail="LOAD CSV FROM can access local/remote files and is blocked",
            ))

        if _CYPHER_STACKED_RE.search(cypher):
            events.append(SecurityEvent(
                stage="INJECTION_ANALYSER",
                severity=Severity.BLOCK,
                message=f"Stacked Cypher statement detected in {source}",
                detail="Multiple statements with write operations are blocked",
            ))

        return events

    # ------------------------------------------------------------------
    # Elasticsearch DSL scanning
    # ------------------------------------------------------------------

    def _scan_es_dsl(self, query_text: str, source: str) -> list[SecurityEvent]:
        """Scan an Elasticsearch Query DSL body for script injection."""
        events: list[SecurityEvent] = []

        try:
            body = json.loads(query_text)
        except (json.JSONDecodeError, TypeError):
            return events

        self._scan_es_recursive(body, source, events)
        return events

    def _scan_es_recursive(
        self, obj: object, source: str, events: list[SecurityEvent]
    ) -> None:
        """Recursively scan ES body for script-related keys."""
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key in _ES_SCRIPT_KEYS:
                    events.append(SecurityEvent(
                        stage="INJECTION_ANALYSER",
                        severity=Severity.BLOCK,
                        message=f"Script execution key '{key}' detected in ES query for {source}",
                        detail="Painless/scripted queries can execute arbitrary code and are blocked",
                    ))
                self._scan_es_recursive(value, source, events)
        elif isinstance(obj, list):
            for item in obj:
                self._scan_es_recursive(item, source, events)

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _max_subquery_depth(node: exp.Expression, current: int = 0) -> int:
        """Recursively find the maximum subquery nesting depth."""
        max_depth = current
        for child in node.iter_expressions():
            if isinstance(child, exp.Subquery):
                max_depth = max(
                    max_depth,
                    InjectionAnalyser._max_subquery_depth(child, current + 1),
                )
            else:
                max_depth = max(
                    max_depth,
                    InjectionAnalyser._max_subquery_depth(child, current),
                )
        return max_depth
