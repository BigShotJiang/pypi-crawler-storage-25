"""DynamoDB native API access target extractor.

Request shape:

    {"verb": "Query",       "TableName": "Sessions", ...}
    {"verb": "PutItem",     "TableName": "Audit",    ...}
    {"verb": "TransactWriteItems",
     "TransactItems": [{"Put":    {"TableName": "Sessions", ...}},
                       {"Update": {"TableName": "Sessions", ...}},
                       {"Delete": {"TableName": "Audit",    ...}}]}
    {"verb": "ExecuteStatement",
     "Statement": "SELECT * FROM Sessions WHERE id=?"}    # PartiQL → _sql.py

Verb mapping:

  Read   → Query, Scan, GetItem, BatchGetItem, DescribeTable (R)
  Write  → PutItem, UpdateItem, DeleteItem, BatchWriteItem (W)
  DDL    → CreateTable, DeleteTable, UpdateTable

`TransactWriteItems` fans out one target per item.
`ExecuteStatement` (PartiQL) is dispatched to `_sql` since the body is SQL.
`BatchWriteItem` body has `RequestItems = {table: [{PutRequest|DeleteRequest}]}`.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


_READ_VERBS: set[str] = {
    "query", "scan", "getitem", "batchgetitem",
    "describetable", "listtables",
}
_WRITE_VERBS: dict[str, Op] = {
    "putitem": Op.INSERT,
    "updateitem": Op.UPDATE,
    "deleteitem": Op.DELETE,
}
_DDL_VERBS: set[str] = {
    "createtable", "deletetable", "updatetable",
    "createbackup", "deletebackup", "restoretablefrombackup",
    "createglobalsecondaryindex", "deleteglobalsecondaryindex",
}


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    if not raw_query or not raw_query.strip():
        return [_target(step, step.table or "", Op.SELECT)]

    try:
        body = json.loads(raw_query)
    except json.JSONDecodeError:
        return [_target(step, step.table or "", Op.DDL)]

    if not isinstance(body, dict):
        return [_target(step, step.table or "", Op.DDL)]

    verb = (body.get("verb") or body.get("Operation") or "").strip().lower()

    # PartiQL: dispatch to _sql.
    if verb == "executestatement":
        statement = body.get("Statement") or body.get("statement") or ""
        from . import _sql
        return _sql.extract(step, statement)

    if verb == "executetransaction":
        # PartiQL transaction: list of {"Statement": "..."} entries.
        from . import _sql
        out: list[AccessTarget] = []
        seen: set[tuple[str, str, Op]] = set()
        for inner in body.get("TransactStatements") or []:
            stmt = (inner or {}).get("Statement") if isinstance(inner, dict) else None
            for t in _sql.extract(step, stmt or ""):
                key = (t.database, t.table, t.operation)
                if key not in seen:
                    seen.add(key)
                    out.append(t)
        return out or [_target(step, step.table or "", Op.SELECT)]

    if verb == "transactwriteitems":
        return _transact(step, body) or [_target(step, step.table or "", Op.DDL)]

    if verb == "transactgetitems":
        # All reads.
        out2: list[AccessTarget] = []
        seen2: set[tuple[str, str]] = set()
        for inner in body.get("TransactItems") or []:
            if not isinstance(inner, dict):
                continue
            req = inner.get("Get") or {}
            tbl = (req.get("TableName") if isinstance(req, dict) else "") or ""
            if tbl and (step.database or "", tbl) not in seen2:
                seen2.add((step.database or "", tbl))
                out2.append(_target(step, tbl, Op.SELECT))
        return out2 or [_target(step, step.table or "", Op.SELECT)]

    if verb == "batchwriteitem":
        return _batch_write(step, body) or [_target(step, step.table or "", Op.DDL)]

    if verb == "batchgetitem":
        items = body.get("RequestItems") or {}
        if not isinstance(items, dict):
            return [_target(step, step.table or "", Op.SELECT)]
        return [
            _target(step, tbl, Op.SELECT) for tbl in items.keys()
        ] or [_target(step, step.table or "", Op.SELECT)]

    table = body.get("TableName") or step.table or ""

    if verb in _READ_VERBS:
        return [_target(step, table, Op.SELECT)]
    if verb in _WRITE_VERBS:
        return [_target(step, table, _WRITE_VERBS[verb])]
    if verb in _DDL_VERBS:
        return [_target(step, table, Op.DDL)]
    if not verb:
        return [_target(step, table, Op.SELECT)]
    # Unknown verb → fail closed.
    return [_target(step, table, Op.DDL)]


# ---------------------------------------------------------------------------
# Transact / Batch helpers
# ---------------------------------------------------------------------------


_TRANSACT_OP_KEYS: dict[str, Op] = {
    "Put": Op.INSERT,
    "Update": Op.UPDATE,
    "Delete": Op.DELETE,
    "ConditionCheck": Op.SELECT,
}


def _transact(step: "IRStep", body: dict[str, Any]) -> list[AccessTarget]:
    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()
    for inner in body.get("TransactItems") or []:
        if not isinstance(inner, dict):
            continue
        for op_key, op in _TRANSACT_OP_KEYS.items():
            if op_key in inner and isinstance(inner[op_key], dict):
                tbl = inner[op_key].get("TableName") or step.table or ""
                key = (step.database or "", tbl, op)
                if key not in seen:
                    seen.add(key)
                    out.append(_target(step, tbl, op))
                break  # each inner has exactly one op key
    return out


def _batch_write(step: "IRStep", body: dict[str, Any]) -> list[AccessTarget]:
    """RequestItems = {table: [{PutRequest: {...}} | {DeleteRequest: {...}}]}."""
    items = body.get("RequestItems") or {}
    if not isinstance(items, dict):
        return []
    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()
    for table, reqs in items.items():
        if not isinstance(reqs, list):
            continue
        for req in reqs:
            if not isinstance(req, dict):
                continue
            if "PutRequest" in req:
                op = Op.INSERT
            elif "DeleteRequest" in req:
                op = Op.DELETE
            else:
                continue
            key = (step.database or "", table, op)
            if key not in seen:
                seen.add(key)
                out.append(_target(step, table, op))
    return out


def _target(step: "IRStep", table: str, op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=(table or step.table or ""),
        operation=op,
    )
