"""Vector DB access target extractor (Weaviate, Qdrant, Milvus, Pinecone).

Vector DBs don't have JOINs or compound DML — every request hits exactly
one collection/class/index. The extractor is intent-based: the request
body's top-level `intent` (or, equivalently, the API verb embedded in the
JSON) determines the op.

Request shape (chosen for faz internal use; agents send this as `raw_query`):

    {"intent": "search",  "filter": {...}, "topK": 10}
    {"intent": "upsert",  "vectors": [...]}
    {"intent": "delete",  "filter": {...}}                # ← emit DELETE
    {"intent": "delete",  "delete_all": true}             # ← emit DDL (mass wipe)
    {"intent": "delete"}                                  # ← empty filter → DDL

Operation map (case-insensitive on the intent string):

  Read:    search, query, fetch, retrieve, scroll, recommend, get, aggregate, explore
           near_text, near_vector, near_object, near_image (Weaviate near_* family)
           hybrid, bm25 (Weaviate), discover/count (Qdrant), hybrid_search (Milvus), list (Pinecone)
  Write:   upsert, insert, update, update_vectors, set_payload, clear_payload
           (delete with non-empty filter is also W; below)
  DDL:     create_collection, delete_collection, drop_collection,
           create_index, delete_index, drop_index, alter_collection,
           and any `delete` with no filter / empty filter / delete_all=True
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


_READ_INTENTS: set[str] = {
    # Generic / cross-DB
    "search", "query", "fetch", "retrieve", "scroll",
    "recommend", "get", "aggregate", "explore",
    # Weaviate near_* family + hybrid/BM25 (all reads)
    "near_text", "near_vector", "near_object", "near_image",
    "near_depth", "near_imu", "near_thermal",
    "hybrid", "bm25",
    # Qdrant extras
    "discover", "count",
    # Milvus extras
    "hybrid_search",
    # Pinecone extras
    "list",
}
_WRITE_INTENTS: set[str] = {
    "upsert", "insert", "update",
    "update_vectors", "set_payload", "clear_payload",
}
_DDL_INTENTS: set[str] = {
    "create_collection", "delete_collection", "drop_collection",
    "create_index", "delete_index", "drop_index",
    "alter_collection", "create_class", "delete_class",
}


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    if not raw_query or not raw_query.strip():
        return [_target(step, Op.SELECT)]

    try:
        body = json.loads(raw_query)
    except json.JSONDecodeError:
        # Some vector clients send opaque strings — fail closed.
        return [_target(step, Op.DDL)]

    if not isinstance(body, dict):
        return [_target(step, Op.DDL)]

    intent = (body.get("intent") or body.get("operation") or "").strip().lower()

    if intent in _READ_INTENTS:
        return [_target(step, Op.SELECT)]
    if intent in _DDL_INTENTS:
        return [_target(step, Op.DDL)]
    if intent in _WRITE_INTENTS:
        return [_target(step, Op.INSERT if intent in {"upsert", "insert"} else Op.UPDATE)]

    if intent == "delete":
        # Empty-filter delete is a mass-wipe → DDL (always blocked).
        if _is_unconstrained_delete(body):
            return [_target(step, Op.DDL)]
        return [_target(step, Op.DELETE)]

    if not intent:
        return [_target(step, Op.SELECT)]

    # Unknown intent → fail closed.
    return [_target(step, Op.DDL)]


def _is_unconstrained_delete(body: dict[str, Any]) -> bool:
    """True if `delete` request has no filter / empty filter / delete_all=True."""
    if body.get("delete_all") is True:
        return True
    if body.get("deleteAll") is True:
        return True
    filt = body.get("filter")
    if filt is None:
        # Single-UUID form: {"uuid": "..."} or {"id": "..."} targets one
        # specific object — constrained delete, not a mass-wipe.
        if body.get("uuid") or body.get("id") or body.get("_id"):
            return False
        # Multi-item id list form.
        ids = body.get("ids") or body.get("vector_ids") or body.get("primary_keys")
        return not (isinstance(ids, list) and len(ids) > 0)
    if isinstance(filt, dict) and not filt:
        return True
    if isinstance(filt, list) and not filt:
        return True
    return False


def _target(step: "IRStep", op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=step.table or "",
        operation=op,
    )
