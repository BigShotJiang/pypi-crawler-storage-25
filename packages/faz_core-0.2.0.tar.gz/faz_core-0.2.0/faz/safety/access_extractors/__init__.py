"""Per-family access target extractors.

Each module in this package walks a query body and emits one `AccessTarget`
per touched scope (table / collection / index / class / node label / relationship
type). RBACGate evaluates each target independently against the layered
permission policy. A query passes only if every target passes.

The declared `(step.database, step.table)` is always emitted as a target.
Additional targets — JOINs, $lookup, _reindex destinations, Cypher rebound
labels, BATCH-internal statements, etc. — are discovered by parsing the
query body.

Fail-closed: if extraction crashes (parse error, unknown shape), return a
single DDL target so RBAC blocks. Surface the error in the audit log.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Callable

from faz.safety.types import (
    AccessTarget,
    Op,
    QueryLanguage,
    resolve_query_language,
)

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_targets(
    step: "IRStep", raw_query: str | None = None,
) -> list[AccessTarget]:
    """Return every `(database, table, op)` the request wants to touch.

    Always includes the declared target `(step.database, step.table)`.
    May add additional targets discovered by the per-language extractor.
    Fail-closed on parse errors: returns a single DDL target so RBAC blocks.
    """
    body = raw_query if raw_query is not None else step.raw_query
    lang = _resolve_language(step)

    if lang is None:
        # No language hint at all — declared target with SELECT op.
        # This only happens when step.language is None AND the connector
        # name doesn't appear in the language map.
        return [_declared_select(step)]

    extractor = _DISPATCH.get(lang)
    if extractor is None:
        # Known language but no extractor — fall back to declared SELECT.
        return [_declared_select(step)]

    try:
        return extractor(step, body)
    except Exception as exc:  # noqa: BLE001 — fail-closed by design
        logger.warning(
            "access extractor (%s) crashed on step %s: %s",
            lang.value, step.step_id or "<unset>", exc,
        )
        return [
            AccessTarget(
                database=step.database or "",
                table=step.table or "",
                operation=Op.DDL,  # forces BLOCK at every AccessMode below A
            )
        ]


def _declared_select(step: "IRStep") -> AccessTarget:
    """Default declared-target target with op=SELECT."""
    return AccessTarget(
        database=step.database or "",
        table=step.table or "",
        operation=Op.SELECT,
    )


def _resolve_language(step: "IRStep") -> QueryLanguage | None:
    """Prefer the explicit `step.language`; fall back to connector→language map."""
    if step.language is not None:
        return step.language
    if step.database:
        return resolve_query_language(step.database)
    return None


# ---------------------------------------------------------------------------
# Dispatch table — populated by lazy imports below to avoid heavy deps
# (sqlglot, json) at package import time when only one family is needed.
# ---------------------------------------------------------------------------


def _sql_dispatch(step: "IRStep", body: str | None) -> list[AccessTarget]:
    from . import _sql
    return _sql.extract(step, body)


def _mql_dispatch(step: "IRStep", body: str | None) -> list[AccessTarget]:
    from . import _mql
    return _mql.extract(step, body)


def _cypher_dispatch(step: "IRStep", body: str | None) -> list[AccessTarget]:
    from . import _cypher
    return _cypher.extract(step, body)


def _es_dsl_dispatch(step: "IRStep", body: str | None) -> list[AccessTarget]:
    from . import _es_dsl
    return _es_dsl.extract(step, body)


def _vector_dispatch(step: "IRStep", body: str | None) -> list[AccessTarget]:
    from . import _vector
    return _vector.extract(step, body)


def _dynamo_dispatch(step: "IRStep", body: str | None) -> list[AccessTarget]:
    from . import _dynamo
    return _dynamo.extract(step, body)


_DISPATCH: dict[QueryLanguage, Callable[["IRStep", str | None], list[AccessTarget]]] = {
    QueryLanguage.SQL: _sql_dispatch,
    QueryLanguage.MQL: _mql_dispatch,
    QueryLanguage.CYPHER: _cypher_dispatch,
    QueryLanguage.ES_DSL: _es_dsl_dispatch,
    QueryLanguage.VECTOR: _vector_dispatch,
    QueryLanguage.DYNAMO: _dynamo_dispatch,
    QueryLanguage.COUCHDB: _mql_dispatch,  # CouchDB Mango shares the JSON-doc shape with MQL
}


__all__ = ["extract_targets"]
