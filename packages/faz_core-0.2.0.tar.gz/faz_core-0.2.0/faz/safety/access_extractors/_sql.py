"""SQL access target extractor.

Walks a SQL/CQL/PartiQL AST and emits one `AccessTarget` per touched table.
Covers postgres / mysql / oracle / cassandra (CQL) / dynamodb (PartiQL).

Rules:
  - Top-level statement determines the primary op (SELECT, INSERT, UPDATE,
    DELETE, MERGE, or DDL for CREATE/DROP/ALTER/TRUNCATE/GRANT/REVOKE).
  - INSERT INTO x SELECT FROM y → (x, INSERT) AND (y, SELECT). Each touched
    table gets its own op based on the role it plays in the statement.
  - JOIN target tables in a SELECT → all touched as SELECT (declared target
    is just one of several).
  - UPDATE/DELETE that pulls from another table (Postgres FROM/USING) →
    primary table gets W-op, joined tables get SELECT.
  - CQL `BATCH … APPLY BATCH` → fan out one target per inner statement.
  - Schema-qualified names (`public.users`, `db.schema.users`) → strip
    schema prefix; the table portion is always the *last* identifier.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import sqlglot
from sqlglot import expressions as exp

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


# Connector name → sqlglot dialect hint. Falls back to None (auto-detect).
# Cassandra is intentionally absent — sqlglot has no `cassandra` dialect, and
# CQL's SELECT/INSERT/UPDATE/DELETE shape parses cleanly under the default
# generic dialect (including keyspace-qualified names like `acme.activity_log`
# and the `LIMIT n` clause).
_DIALECT_BY_CONNECTOR: dict[str, str] = {
    "postgresql": "postgres",
    "postgres": "postgres",
    "mysql": "mysql",
    "oracle": "oracle",
    "dynamodb": "presto",  # PartiQL is closest to Presto in sqlglot
}


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    """Walk the SQL AST and emit one AccessTarget per touched table."""
    if not raw_query or not raw_query.strip():
        # No body — just the declared target, default to SELECT.
        return [_declared(step, Op.SELECT)]

    dialect = _DIALECT_BY_CONNECTOR.get(step.database.lower()) if step.database else None
    try:
        statements = sqlglot.parse(raw_query, dialect=dialect)
    except Exception as exc:  # parse error → fail closed
        logger.debug("sqlglot parse failed (dialect=%s): %s", dialect, exc)
        return [_declared(step, Op.DDL)]

    targets: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()

    for stmt in statements:
        if stmt is None:
            continue
        for t in _targets_for_statement(stmt, step):
            key = (t.database, t.table, t.operation)
            if key not in seen:
                seen.add(key)
                targets.append(t)

    if not targets:
        # Statement parsed but produced no recognizable targets — declared SELECT.
        return [_declared(step, Op.SELECT)]
    return targets


# ---------------------------------------------------------------------------
# Per-statement dispatch
# ---------------------------------------------------------------------------


def _targets_for_statement(stmt: exp.Expression, step: "IRStep") -> list[AccessTarget]:
    # DDL classes — block at AST_CHECKER, but emit DDL targets so RBAC also denies
    # for any caller below AccessMode.A.
    if isinstance(stmt, _DDL_CLASSES):
        return [
            _target(step, _table_name(t), Op.DDL)
            for t in stmt.find_all(exp.Table)
        ] or [_declared(step, Op.DDL)]

    # sqlglot's "I don't know what this is" fallback. Triggered by
    # MySQL ``REPLACE INTO``, Postgres ``DO $$ ... $$``, ``COPY``,
    # ``LOAD DATA INFILE``, and any other syntax the parser can't model.
    # Without this branch, Commands fell through to the SELECT shape,
    # found no Table nodes, and silently classified as a read-only
    # SELECT — letting REPLACE / DO blocks bypass an R-only policy.
    # Fail closed: classify as DDL so RBAC denies unless access==A and
    # AST_CHECKER blocks the request outright.
    if isinstance(stmt, exp.Command):
        return [_declared(step, Op.DDL)]

    # State-mutating function calls dressed up as a SELECT.
    # ``SELECT pg_terminate_backend(pid)``, ``SELECT lo_unlink(oid)``,
    # ``SELECT setval('seq', 9999)`` — all parse as innocent SELECTs but
    # have real side effects. Apply this check BEFORE the per-shape
    # dispatch so it covers SELECTs, CTEs wrapping SELECTs, UNIONs,
    # and any other shape that might embed a dangerous function call.
    if _has_side_effect_function(stmt):
        return [_declared(step, Op.DDL)]

    # Multi-statement BATCH (CQL): fan out per inner statement.
    if hasattr(exp, "Batch") and isinstance(stmt, getattr(exp, "Batch", ())):
        out: list[AccessTarget] = []
        for inner in stmt.find_all(_DML_CLASSES):
            out.extend(_targets_for_statement(inner, step))
        return out

    # INSERT
    if isinstance(stmt, exp.Insert):
        out = []
        # Primary target: the INSERT INTO table.
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.INSERT))
        # SELECT subquery's tables: SELECT-op (e.g. INSERT INTO x SELECT FROM y).
        sub = stmt.find(exp.Select)
        if sub is not None:
            for t in sub.find_all(exp.Table):
                if t is not primary:
                    out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # UPDATE
    if isinstance(stmt, exp.Update):
        out = []
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.UPDATE))
        # Postgres `UPDATE x SET ... FROM y`: y joins as SELECT.
        for t in stmt.find_all(exp.Table):
            if t is primary:
                continue
            out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # DELETE
    if isinstance(stmt, exp.Delete):
        out = []
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.DELETE))
        # Postgres `DELETE FROM x USING y`: y joins as SELECT.
        for t in stmt.find_all(exp.Table):
            if t is primary:
                continue
            out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # MERGE (UPSERT)
    if isinstance(stmt, exp.Merge):
        out = []
        primary = _first_table(stmt)
        if primary is not None:
            out.append(_target(step, _table_name(primary), Op.UPDATE))
        for t in stmt.find_all(exp.Table):
            if t is primary:
                continue
            out.append(_target(step, _table_name(t), Op.SELECT))
        return out

    # SELECT (and EXPLAIN-wrapped SELECT, CTE-wrapped SELECT, UNION, etc.)
    #
    # ``SELECT * INTO new_table FROM x`` is a Postgres CTAS that creates
    # a new table — DDL on the destination, plus normal reads on the
    # source. Without this, ``SELECT * INTO TEMPORARY hacked FROM y``
    # classified as ``[(hacked, SELECT), (y, SELECT)]`` and an R-only
    # caller could create new tables (resource exhaustion + data exfil).
    if isinstance(stmt, exp.Select) and stmt.args.get("into") is not None:
        into_node = stmt.args["into"]
        dest = ""
        dest_table_node = into_node.find(exp.Table) if into_node is not None else None
        if dest_table_node is not None:
            dest = _table_name(dest_table_node)
        out = [_target(step, dest, Op.DDL)]
        for t in stmt.find_all(exp.Table):
            name = _table_name(t)
            if name and name != dest:
                out.append(_target(step, name, Op.SELECT))
        return out

    # ``SELECT ... FOR UPDATE`` / ``FOR SHARE`` / ``FOR UPDATE NOWAIT``
    # acquires row-level write locks. Even with no row mutation, the
    # lock blocks concurrent writers and is a DoS vector. Treat every
    # touched table as Op.UPDATE so RBAC requires at least RW.
    if isinstance(stmt, exp.Select) and stmt.args.get("locks"):
        out_lock = [
            _target(step, _table_name(t), Op.UPDATE)
            for t in stmt.find_all(exp.Table)
        ]
        return out_lock or [_declared(step, Op.UPDATE)]

    # CRITICAL: a SELECT can wrap a writing CTE (Postgres data-modifying
    # CTE):  ``WITH d AS (DELETE FROM x RETURNING *) SELECT * FROM d``.
    # The outermost statement parses as Select, but the actual effect is
    # DELETE on x. Walk for any nested DML and recurse so the writing
    # CTE is classified by its real op. Without this, R-only users
    # could wipe a table by wrapping the DELETE in a CTE.
    out: list[AccessTarget] = []
    nested_primary_tables: set[str] = set()
    for nested in stmt.find_all((exp.Insert, exp.Update, exp.Delete, exp.Merge)):
        primary = _first_table(nested)
        if primary is not None:
            nested_primary_tables.add(_table_name(primary))
        out.extend(_targets_for_statement(nested, step))

    for t in stmt.find_all(exp.Table):
        name = _table_name(t)
        # Skip tables already classified as the primary write target of a
        # nested DML — adding them again as SELECT would muddy the audit
        # trail and give RBAC two contradicting verdicts on the same row.
        if name in nested_primary_tables:
            continue
        out.append(_target(step, name, Op.SELECT))

    return out or [_declared(step, Op.SELECT)]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


_DDL_CLASSES: tuple[type, ...] = tuple(
    cls for cls in (
        getattr(exp, "Create", None),
        getattr(exp, "Drop", None),
        getattr(exp, "AlterTable", None),
        getattr(exp, "AlterColumn", None),
        getattr(exp, "TruncateTable", None),
        # Permission management — schema-changing in the policy sense.
        # Without these in the DDL list, ``GRANT ALL ON x TO PUBLIC`` and
        # ``REVOKE ALL ON x FROM PUBLIC`` slipped through as plain SELECTs
        # because sqlglot found a Table node in the statement.
        getattr(exp, "Grant", None),
        getattr(exp, "Revoke", None),
        # Session / server config mutation: ``SET role = ...``,
        # ``SET search_path = ...``, ``SET statement_timeout = ...``.
        # sqlglot parses these as ``exp.Set`` (not Command, so they don't
        # hit the Command-as-DDL guard). They mutate session state —
        # role / authorization can be a privilege escalation, search_path
        # enables schema poisoning, statement_timeout is a DoS vector.
        getattr(exp, "Set", None),
    )
    if cls is not None
)


# Postgres / MySQL functions that mutate database or session state from
# inside a SELECT-shaped query. Anything in this set classifies as DDL
# so RBAC blocks unless the caller has Op.A and AST_CHECKER rejects it
# outright. Read-only counterparts (``lo_get``, ``currval``) intentionally
# excluded so plain reads still work.
#
# Why this exists: a query like ``SELECT pg_terminate_backend(pid)`` parses
# as a SELECT with one Anonymous function call; without this guard it
# would classify as a read and slip past any R-only policy. Same shape
# for ``SELECT lo_unlink(oid)``, ``SELECT setval('seq', 9999)``,
# ``SELECT pg_notify(...)``, etc. — all stateful operations dressed up
# as reads.
_DANGEROUS_SQL_FUNCS: frozenset[str] = frozenset({
    # Large objects (Postgres) — create / delete / mutate BLOBs.
    # ``lo_from_bytea`` and ``lo_creat`` were a verified bypass: they
    # parse as plain SELECTs but persist arbitrary bytea into pg_largeobject.
    "lo_create", "lo_creat", "lo_from_bytea",
    "lo_unlink", "lo_put", "lo_truncate", "lo_truncate64",
    "lo_export", "lo_import", "lo_open", "lo_close", "lowrite",
    # Sequences — write side: setval mutates, nextval increments.
    "setval", "nextval",
    # Async signalling.
    "pg_notify",
    # Backend / connection control — DoS surface.
    "pg_terminate_backend", "pg_cancel_backend",
    "pg_reload_conf", "pg_rotate_logfile", "pg_rotate_logfile_old",
    # ``pg_log_backend_memory_contexts(pid)`` signals a backend to dump
    # its memory contexts — admin-only, exfil / DoS surface.
    "pg_log_backend_memory_contexts",
    # ``set_config(name, value, is_local)`` is the function form of the
    # SQL ``SET`` command. ``set_config('role', 'postgres', false)``
    # is a privilege escalation; ``set_config('search_path', ...)``
    # enables schema poisoning; ``set_config('statement_timeout', '1')``
    # is a per-session DoS. The SQL form is caught by the new
    # ``exp.Set`` DDL classification; this catches the function form.
    "set_config",
    # XID / snapshot writers — ``txid_current`` allocates a new XID,
    # advancing the WAL counter. The ``..._if_assigned`` variant is a
    # pure read and intentionally NOT denylisted.
    "txid_current", "pg_current_xact_id",
    # Advisory locks — gate concurrent writers, hold-the-database surface.
    "pg_advisory_lock", "pg_advisory_lock_shared",
    "pg_advisory_xact_lock", "pg_advisory_xact_lock_shared",
    "pg_try_advisory_lock", "pg_try_advisory_lock_shared",
    "pg_try_advisory_xact_lock", "pg_try_advisory_xact_lock_shared",
    "pg_advisory_unlock", "pg_advisory_unlock_shared",
    "pg_advisory_unlock_all",
    # Replication / WAL — admin only.
    "pg_create_logical_replication_slot",
    "pg_create_physical_replication_slot",
    "pg_drop_replication_slot",
    "pg_replication_slot_advance",
    "pg_promote",
    "pg_switch_wal", "pg_switch_xlog",
    "pg_create_restore_point",
    "pg_start_backup", "pg_stop_backup",
    "pg_backup_start", "pg_backup_stop",
    # Logical decoding — emits to or consumes from replication slots.
    # ``pg_logical_emit_message`` is a write to the WAL stream that
    # downstream subscribers will replay. ``..._get_changes`` advances
    # the slot (consumes); the ``_peek_`` variants don't, but conservative
    # default: include them too.
    "pg_logical_emit_message",
    "pg_logical_slot_get_changes",
    "pg_logical_slot_get_binary_changes",
    "pg_logical_slot_peek_changes",
    "pg_logical_slot_peek_binary_changes",
    # Replication origin management — admin.
    "pg_replication_origin_create", "pg_replication_origin_drop",
    "pg_replication_origin_advance",
    "pg_replication_origin_session_setup",
    "pg_replication_origin_session_reset",
    "pg_replication_origin_xact_setup",
    "pg_replication_origin_xact_reset",
    # Statistics counters reset — admin / observability mutation.
    "pg_stat_reset", "pg_stat_reset_shared",
    "pg_stat_reset_single_table_counters",
    "pg_stat_reset_single_function_counters",
    "pg_stat_reset_replication_slot",
    "pg_stat_reset_subscription_stats",
    "pg_stat_reset_slru",
    "pg_stat_clear_snapshot",
    # dblink — execute on a remote server, escapes the local policy.
    # Includes the connect-and-query form ``dblink(connstr, sql)``,
    # which takes arbitrary SQL as its second argument and runs it
    # outside the local AST analyzer.
    "dblink", "dblink_exec", "dblink_send_query", "dblink_open",
    "dblink_get_result", "dblink_fetch", "dblink_cancel_query",
    # ``*_to_xml`` family — second-order SQL execution. ``query_to_xml``
    # takes a SQL string as its first argument and runs it server-side
    # with the caller's privileges. The embedded SQL is opaque to any
    # AST analyzer (it's a string literal, not a Table or Insert node),
    # so the only safe stance is to block the whole family. ``table_*``
    # / ``schema_*`` / ``database_*`` variants don't take SQL strings
    # but still bypass per-table RBAC by reading any regclass /
    # schema / database the caller can name as a string.
    "query_to_xml", "query_to_xmlschema", "query_to_xml_and_xmlschema",
    "cursor_to_xml", "cursor_to_xmlschema",
    "table_to_xml", "table_to_xmlschema", "table_to_xml_and_xmlschema",
    "schema_to_xml", "schema_to_xmlschema", "schema_to_xml_and_xmlschema",
    "database_to_xml", "database_to_xmlschema",
    "database_to_xml_and_xmlschema",
    # MySQL session / lock management + DoS surface.
    "kill", "release_lock", "get_lock", "release_all_locks",
    "benchmark", "sleep",
})


def _has_side_effect_function(stmt: exp.Expression) -> bool:
    """True if the AST contains any state-mutating function call."""
    for fn in stmt.find_all(exp.Anonymous):
        name = (fn.this or "").lower() if isinstance(fn.this, str) else ""
        if name in _DANGEROUS_SQL_FUNCS:
            return True
    return False

_DML_CLASSES: tuple[type, ...] = tuple(
    cls for cls in (exp.Select, exp.Insert, exp.Update, exp.Delete, exp.Merge)
    if cls is not None
)


def _first_table(stmt: exp.Expression) -> exp.Table | None:
    """First Table node — the primary target of INSERT/UPDATE/DELETE/MERGE."""
    return stmt.find(exp.Table)


def _table_name(t: exp.Table) -> str:
    """Strip schema/db prefix; return the table identifier only."""
    if t is None:
        return ""
    # sqlglot Table.name returns the bare table portion. `.this` handles
    # quoted/unquoted identifier nodes.
    return (t.name or "").strip('"').strip('`')


def _target(step: "IRStep", table: str, op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=table or (step.table or ""),
        operation=op,
    )


def _declared(step: "IRStep", op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=step.table or "",
        operation=op,
    )
