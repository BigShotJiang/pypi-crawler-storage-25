"""MongoDB / CouchDB access target extractor.

Parses the JSON body of an MQL request and emits AccessTarget rows.

Supported request shapes:

  Read:
    {"operation": "find",      "collection": "events", "filter": {...}}
    {"operation": "aggregate", "collection": "users",  "pipeline": [...]}
    {"operation": "count",     "collection": "x",      "filter": {...}}
    {"operation": "distinct",  "collection": "x",      "key": "..."}
    {"operation": "findOne",   ...}

  Write:
    {"operation": "insertOne"   | "insertMany",   ...}
    {"operation": "updateOne"   | "updateMany"
                  | "replaceOne",                  ...}
    {"operation": "deleteOne"   | "deleteMany",   ...}
    {"operation": "findAndModify", ...}
    {"operation": "bulkWrite",  "ops": [...]}    # fan out per inner op

  DDL (always blocked at AST_CHECKER, but emitted here too for RBAC):
    {"operation": "createCollection" | "dropCollection"
                  | "createIndex"     | "dropIndex"
                  | "runCommand", ...}

Aggregation pipeline walk:
    $lookup.from         → secondary SELECT target
    $graphLookup.from    → secondary SELECT target
    $out                 → INSERT target on destination
    $merge.into          → INSERT target on destination
                           (treated as INSERT for v1 — Phase 1.6 may refine)
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from faz.safety.types import AccessTarget, Op

if TYPE_CHECKING:
    from faz.types.ir import IRStep

logger = logging.getLogger(__name__)


_READ_OPS: set[str] = {
    "find", "findone", "aggregate", "count", "countdocuments",
    "distinct", "explain",
}
_WRITE_OPS: dict[str, Op] = {
    "insertone": Op.INSERT, "insertmany": Op.INSERT, "insert": Op.INSERT,
    "updateone": Op.UPDATE, "updatemany": Op.UPDATE, "update": Op.UPDATE,
    "replaceone": Op.UPDATE,
    "deleteone": Op.DELETE, "deletemany": Op.DELETE, "delete": Op.DELETE,
    "findandmodify": Op.UPDATE, "findoneandupdate": Op.UPDATE,
    "findoneandreplace": Op.UPDATE, "findoneanddelete": Op.DELETE,
}
_DDL_OPS: set[str] = {
    "createcollection", "dropcollection",
    "createindex", "dropindex", "createindexes", "dropindexes",
    "runcommand", "eval",
    "renamecollection", "convertto",
}


def extract(step: "IRStep", raw_query: str | None) -> list[AccessTarget]:
    """Walk the JSON body and emit AccessTargets per touched collection."""
    if not raw_query or not raw_query.strip():
        return [_target(step, step.table, Op.SELECT)]

    try:
        body = json.loads(raw_query)
    except json.JSONDecodeError as exc:
        logger.debug("MQL JSON parse failed: %s", exc)
        # Some agents send Python-dict-ish strings; treat as opaque → fail closed.
        return [_target(step, step.table, Op.DDL)]

    if not isinstance(body, dict):
        return [_target(step, step.table, Op.DDL)]

    out: list[AccessTarget] = []
    seen: set[tuple[str, str, Op]] = set()

    def _add(table: str, op: Op) -> None:
        key = (step.database or "", table or step.table or "", op)
        if key not in seen:
            seen.add(key)
            out.append(_target(step, table, op))

    op_name = (body.get("operation") or "").strip().lower()
    primary_collection = body.get("collection") or step.table

    # bulkWrite: fan out one target per inner op.
    if op_name == "bulkwrite":
        for inner in body.get("ops", []) or []:
            if isinstance(inner, dict):
                inner_op = (inner.get("operation") or "").strip().lower()
                inner_coll = inner.get("collection") or primary_collection
                _emit_for_op(_add, inner_op, inner_coll, inner)
        if not out:
            _add(primary_collection, Op.SELECT)
        return out

    # Standard ops
    _emit_for_op(_add, op_name, primary_collection, body)

    # Walk aggregation pipeline for $lookup / $out / $merge regardless of top op.
    pipeline = body.get("pipeline")
    if isinstance(pipeline, list):
        _walk_pipeline(_add, pipeline)

    if not out:
        # Unrecognized shape but parsed JSON — declared SELECT is the safest default.
        _add(primary_collection, Op.SELECT)
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _emit_for_op(
    add: Any, op_name: str, collection: str, body: dict[str, Any],
) -> None:
    """Map one operation invocation to one or more AccessTargets."""
    if op_name in _READ_OPS:
        add(collection, Op.SELECT)
        return
    if op_name in _WRITE_OPS:
        add(collection, _WRITE_OPS[op_name])
        return
    if op_name in _DDL_OPS:
        add(collection, Op.DDL)
        return
    if not op_name:
        # No operation specified — assume read.
        add(collection, Op.SELECT)
        return
    # Unknown op → fail closed.
    add(collection, Op.DDL)


def _walk_pipeline(add: Any, pipeline: list[Any]) -> None:
    """Find $lookup.from, $graphLookup.from, $out, $merge.into in a pipeline."""
    for stage in pipeline:
        if not isinstance(stage, dict):
            continue
        if "$lookup" in stage and isinstance(stage["$lookup"], dict):
            target = stage["$lookup"].get("from")
            if isinstance(target, str) and target:
                add(target, Op.SELECT)
        if "$graphLookup" in stage and isinstance(stage["$graphLookup"], dict):
            target = stage["$graphLookup"].get("from")
            if isinstance(target, str) and target:
                add(target, Op.SELECT)
        if "$out" in stage:
            target = stage["$out"]
            if isinstance(target, dict):
                target = target.get("coll") or target.get("collection")
            if isinstance(target, str) and target:
                add(target, Op.INSERT)
        if "$merge" in stage and isinstance(stage["$merge"], dict):
            into = stage["$merge"].get("into")
            if isinstance(into, dict):
                into = into.get("coll") or into.get("collection")
            if isinstance(into, str) and into:
                add(into, Op.INSERT)


def _target(step: "IRStep", table: str | None, op: Op) -> AccessTarget:
    return AccessTarget(
        database=step.database or "",
        table=(table or step.table or ""),
        operation=op,
    )
