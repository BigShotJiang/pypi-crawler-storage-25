"""Stage 1 — RBAC Gate.

For each IR step, the per-family access extractor produces a list of
`AccessTarget(database, table, op)` covering both the declared target AND
every other table touched by the query body (JOINs, $lookup, _reindex,
Cypher rebound labels, etc.). Each target is evaluated independently
against the layered permission policy:

  1. Look for a per-table override Permission for `(database, table)`.
  2. Else, fall back to the per-database baseline Permission (table_name == "*").
  3. Else, no policy applies → default-deny.

The granted `AccessMode` is matched against the required op via
`ACCESS_MODE_ALLOWED`. Any failing target produces a BLOCK.

`DenyPolicy.PARTIAL` is preserved for federated multi-step queries — a
step that fails RBAC is dropped from the IR and remaining steps continue.
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import TYPE_CHECKING

from faz.safety.access_extractors import extract_targets
from faz.safety.types import (
    ACCESS_MODE_ALLOWED,
    AccessMode,
    AccessTarget,
    Op,
    SecurityEvent,
    Severity,
    StageResult,
    StageVerdict,
)

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr, IRStep

from .base import SafetyStage

logger = logging.getLogger(__name__)


class DenyPolicy(str, Enum):
    """What to do when some (not all) steps are denied in a federated query."""

    PARTIAL = "PARTIAL"   # strip denied steps, continue with the rest
    BLOCK = "BLOCK"       # reject the entire request


class RBACGate(SafetyStage):
    """Stage 1: per-table R/W/RW with per-family body extraction."""

    def __init__(self, policy: DenyPolicy = DenyPolicy.PARTIAL) -> None:
        self._policy = policy

    def validate(
        self,
        ir: "IntermediateRepr",
        permissions: list["Permission"],
        raw_sql: dict[str, str] | None = None,
    ) -> StageResult:
        events: list[SecurityEvent] = []
        allowed_steps: list["IRStep"] = []
        denied_step_ids: list[str] = []

        for step in ir.steps:
            raw = (raw_sql or {}).get(step.source) if raw_sql else None
            targets = extract_targets(step, raw)

            # Evaluate every target. If any target on this step BLOCKs, the
            # step is denied. Other steps may still proceed under PARTIAL.
            step_blocks: list[SecurityEvent] = []
            for target in targets:
                granted = _lookup(permissions, target.database, target.table)
                ok = _satisfies(granted, target.operation)
                if ok:
                    continue
                step_blocks.append(_block_event(step, target, granted))

            if step_blocks:
                events.extend(step_blocks)
                denied_step_ids.append(step.step_id or step.source)
            else:
                allowed_steps.append(step)

        if not allowed_steps:
            logger.warning(
                "RBAC Gate: every step denied (%d) — full BLOCK",
                len(denied_step_ids),
            )
            return StageResult(
                stage="RBAC_GATE",
                verdict=StageVerdict.BLOCK,
                events=events,
            )

        if denied_step_ids:
            if self._policy == DenyPolicy.BLOCK:
                logger.warning(
                    "RBAC Gate: %d step(s) denied + BLOCK policy → full BLOCK",
                    len(denied_step_ids),
                )
                return StageResult(
                    stage="RBAC_GATE",
                    verdict=StageVerdict.BLOCK,
                    events=events,
                )
            # PARTIAL: strip denied steps and continue.
            ir.steps = allowed_steps
            logger.info(
                "RBAC Gate: stripped %d denied step(s): %s",
                len(denied_step_ids), denied_step_ids,
            )
            return StageResult(
                stage="RBAC_GATE",
                verdict=StageVerdict.PARTIAL,
                events=events,
            )

        return StageResult(stage="RBAC_GATE", verdict=StageVerdict.PASS)


# ---------------------------------------------------------------------------
# Permission lookup + matrix check
# ---------------------------------------------------------------------------


def _lookup(
    permissions: list["Permission"], database: str, table: str,
) -> AccessMode | None:
    """Layered lookup: per-table override → per-database baseline → None.

    A `Permission` row with `table_name == "*"` is the per-database
    baseline. Specific table names are overrides.

    Returns None when no policy entry applies — the matrix check then
    default-denies.
    """
    if not database:
        return None

    # 1. Specific (database, table) override.
    if table:
        for p in permissions:
            if p.database_uri == database and p.table_name == table:
                return p.access_level

    # 2. Per-database baseline (wildcard).
    for p in permissions:
        if p.database_uri == database and p.table_name == "*":
            return p.access_level

    # 3. No policy.
    return None


def _satisfies(granted: AccessMode | None, required_op: Op) -> bool:
    """True iff the granted level permits the required op."""
    if granted is None:
        return False
    return required_op.value in ACCESS_MODE_ALLOWED.get(granted, set())


def _block_event(
    step: "IRStep", target: AccessTarget, granted: AccessMode | None,
) -> SecurityEvent:
    granted_str = granted.value if granted is not None else "<none>"

    # DDL is permitted only by AccessMode.A. Any other granted level
    # (or no policy) results in a BLOCK here. Surface the policy level
    # so the dev can decide whether to upgrade the relevant entry to A.
    if target.operation == Op.DDL:
        return SecurityEvent(
            stage="RBAC_GATE",
            severity=Severity.BLOCK,
            message=(
                f"DDL is not permitted: {target.database}.{target.table} "
                "(CREATE / DROP / ALTER / TRUNCATE / schema mutation); "
                f"policy grants {granted_str}. Only AccessMode.A allows DDL."
            ),
            detail=(
                f"step={step.step_id or step.source} "
                f"database={target.database} table={target.table} "
                f"requested_op=DDL level_granted={granted_str}"
            ),
        )

    return SecurityEvent(
        stage="RBAC_GATE",
        severity=Severity.BLOCK,
        message=(
            f"Access denied: {target.database}.{target.table} requires permission "
            f"for {target.operation.value}; policy grants {granted_str}"
        ),
        detail=(
            f"step={step.step_id or step.source} "
            f"database={target.database} table={target.table} "
            f"requested_op={target.operation.value} "
            f"level_granted={granted_str}"
        ),
    )
