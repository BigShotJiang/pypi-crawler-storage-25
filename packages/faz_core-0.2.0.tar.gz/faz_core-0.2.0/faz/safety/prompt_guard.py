"""Stage 0 — Prompt Guard (pre-LLM destructive intent detection).

Scans the user's raw natural-language prompt BEFORE it reaches the LLM.
Blocks requests that express clear destructive intent (DROP, DELETE, INSERT,
UPDATE, TRUNCATE, ALTER, DETACH DELETE, etc.) with a 403.

Context-aware: distinguishes between destructive commands and legitimate
read queries that mention destructive keywords in passing.
  - "DROP TABLE employees"                    → BLOCK
  - "show me deleted records"                 → PASS
  - "list employees where status = 'active'"  → PASS
  - "INSERT a backdoor into products"         → BLOCK
"""

from __future__ import annotations

import re
import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr

from .base import SafetyStage
from .types import SecurityEvent, Severity, StageResult, StageVerdict

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Destructive intent patterns
# ---------------------------------------------------------------------------

# Phase 1.4 narrowing: PROMPT_GUARD only fires on natural-language
# destructive intent. Concrete SQL/MQL/Cypher verbs are RBACGate's and
# AST_CHECKER's job — they have full per-language semantic awareness
# (per-table R/W/RW, DDL detection per family). PROMPT_GUARD is for
# the case where an agent passes free-text into the request (e.g. as
# `step.filter` description or future LLM-NL passthrough) and that
# text contains a clearly-destructive instruction.
_DESTRUCTIVE_INTENT_PATTERNS = [
    # NL: "wipe / destroy / erase / purge / nuke" + table-like noun
    re.compile(
        r"\b(?:wipe|destroy|erase|purge|nuke)\s+(?:all|the|every|this)?\s*\w*\s*(?:table|database|collection|data|records|nodes)\b",
        re.IGNORECASE,
    ),
    # NL: "remove/delete all/every records|rows|documents|entries|nodes|data"
    re.compile(
        r"\b(?:remove|delete)\s+(?:all|every)\s+(?:records?|rows?|documents?|entries|nodes?|data)\b",
        re.IGNORECASE,
    ),
    # NL: "drop the database", "drop all tables"
    re.compile(
        r"\bdrop\s+(?:the|all)\s+(?:database|databases|tables|collections|schemas)\b",
        re.IGNORECASE,
    ),
]

# Read-context phrases — if present, the user is asking to READ about
# something, not perform a destructive action
_READ_CONTEXT_RE = re.compile(
    r"\b(?:show|list|find|get|fetch|retrieve|search|query|display|count|how\s+many|select)\b",
    re.IGNORECASE,
)


class PromptGuard(SafetyStage):
    """Pre-pipeline scanner for destructive intent in raw query text.

    Conforms to the SafetyStage interface so it can run inside
    `SafetyPipeline.run()` as the first stage. The legacy `check(prompt)`
    method is preserved for callers that already pass a single string.
    """

    def validate(
        self,
        ir: IntermediateRepr,
        permissions: list[Permission],
        raw_sql: dict[str, str] | None = None,
    ) -> StageResult:
        """Scan every query string in the request for destructive intent.

        Aggregates the raw SQL/MQL/Cypher strings from `raw_sql` and from
        any `IRStep.raw_query` fields. Each is run through `check()`; the
        first BLOCK wins.
        """
        candidates: list[str] = []
        if raw_sql:
            candidates.extend(v for v in raw_sql.values() if v)
        for step in ir.steps:
            if step.raw_query:
                candidates.append(step.raw_query)

        events: list[SecurityEvent] = []
        for query_text in candidates:
            sub = self.check(query_text)
            events.extend(sub.events)
            if sub.verdict == StageVerdict.BLOCK:
                # Fail fast on the first BLOCK
                return StageResult(
                    stage="PROMPT_GUARD",
                    verdict=StageVerdict.BLOCK,
                    events=events,
                )

        return StageResult(
            stage="PROMPT_GUARD",
            verdict=StageVerdict.PASS,
            events=events,
        )

    def check(self, prompt: str) -> StageResult:
        """Scan a user prompt for destructive intent.

        Returns a StageResult with BLOCK verdict if destructive intent is found,
        PASS otherwise.
        """
        events: list[SecurityEvent] = []

        # If the prompt starts with a read-context verb, it's likely safe
        # e.g. "show me deleted records", "list drop-shipped orders"
        stripped = prompt.strip()
        has_read_context = bool(_READ_CONTEXT_RE.match(stripped))

        for pattern in _DESTRUCTIVE_INTENT_PATTERNS:
            match = pattern.search(prompt)
            if match:
                matched_text = match.group(0)

                # If prompt STARTS with a read verb, allow it unless the
                # destructive pattern is also at the start
                if has_read_context and match.start() > 0:
                    logger.debug(
                        "Prompt guard: '%s' matched but read context detected, allowing",
                        matched_text,
                    )
                    continue

                events.append(SecurityEvent(
                    stage="PROMPT_GUARD",
                    severity=Severity.BLOCK,
                    message=f"Destructive intent detected: '{matched_text}'",
                    detail=(
                        "The prompt appears to request a destructive database "
                        "operation. faz is read-only. Rephrase as a "
                        "read query if you want to view data."
                    ),
                ))

        blocked = any(e.severity == Severity.BLOCK for e in events)
        return StageResult(
            stage="PROMPT_GUARD",
            verdict=StageVerdict.BLOCK if blocked else StageVerdict.PASS,
            events=events,
        )
