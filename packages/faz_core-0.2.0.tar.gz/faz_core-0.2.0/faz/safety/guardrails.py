"""Stage 4 — Execution Path Optimiser + Guardrails.

Multi-language guardrails that apply protective limits before execution:

  SQL:
    - Row cap: inject LIMIT 1000 if absent, cap excessive limits
    - Execution timeout: attach query timeout hint (30s)
    - Max subquery depth: warn when nesting exceeds limit

  MQL:
    - Row cap: inject $limit pipeline stage if absent
    - Timeout: attach maxTimeMS metadata

  Cypher:
    - Row cap: inject LIMIT clause if absent

  ES_DSL:
    - Row cap: inject/cap "size" field in query body

This stage never BLOCKs; it only WARNs and rewrites queries where safe to do so.
The rewritten queries are returned in ``StageResult.rewritten_sql``.
"""

from __future__ import annotations

import json
import logging
import re

import sqlglot
from sqlglot import exp

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr

from .base import SafetyStage
from .types import (
    QueryLanguage,
    SecurityEvent,
    Severity,
    StageResult,
    StageVerdict,
    resolve_query_language,
)

logger = logging.getLogger(__name__)

# Guardrail defaults
DEFAULT_ROW_CAP = 1000
DEFAULT_TIMEOUT_SECONDS = 30
MAX_SUBQUERY_DEPTH = 3


# Connector-name prefix → sqlglot dialect. The row-cap injection emits a
# `LIMIT` node, which different dialects render differently — e.g. Oracle's
# correct syntax is `FETCH FIRST n ROWS ONLY`, not `LIMIT n`. Without this
# the rewritten SQL fails at the connector with ORA-03049. Cassandra is
# intentionally absent — sqlglot has no `cassandra` dialect, and CQL's
# `LIMIT n` round-trips fine through the generic dialect.
_SQL_DIALECT_BY_CONNECTOR: dict[str, str] = {
    "postgresql": "postgres",
    "postgres":   "postgres",
    "mysql":      "mysql",
    "oracle":     "oracle",
}


def _sql_dialect_for(source: str) -> str | None:
    """Return the sqlglot dialect hint for a `<connector>.<table>` source."""
    prefix = source.split(".", 1)[0].lower() if source else ""
    return _SQL_DIALECT_BY_CONNECTOR.get(prefix)


class Guardrails(SafetyStage):
    """Stage 4: multi-language execution guardrails."""

    def __init__(
        self,
        row_cap: int = DEFAULT_ROW_CAP,
        timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
        max_depth: int = MAX_SUBQUERY_DEPTH,
    ) -> None:
        self._row_cap = row_cap
        self._timeout_seconds = timeout_seconds
        self._max_depth = max_depth

    def validate(
        self,
        ir: IntermediateRepr,
        permissions: list[Permission],
        raw_sql: dict[str, str] | None = None,
    ) -> StageResult:
        events: list[SecurityEvent] = []
        rewritten: dict[str, str] = {}

        if raw_sql:
            for source, query_text in raw_sql.items():
                language = resolve_query_language(source)

                if language == QueryLanguage.SQL:
                    new_query, source_events = self._apply_sql_guardrails(source, query_text)
                elif language == QueryLanguage.MQL:
                    new_query, source_events = self._apply_mql_guardrails(source, query_text)
                elif language == QueryLanguage.CYPHER:
                    new_query, source_events = self._apply_cypher_guardrails(source, query_text)
                elif language == QueryLanguage.ES_DSL:
                    new_query, source_events = self._apply_es_guardrails(source, query_text)
                else:
                    # VECTOR, DYNAMO, COUCHDB — pass through, connector enforces limits
                    new_query = query_text
                    source_events = [SecurityEvent(
                        stage="GUARDRAILS",
                        severity=Severity.INFO,
                        message=f"Guardrails pass-through for {language.value} on {source}",
                    )]

                events.extend(source_events)
                rewritten[source] = new_query

        result = StageResult(
            stage="GUARDRAILS",
            verdict=StageVerdict.PASS,
            events=events,
        )
        result.rewritten_sql = rewritten  # type: ignore[attr-defined]
        return result

    # ------------------------------------------------------------------
    # SQL guardrails (existing logic)
    # ------------------------------------------------------------------

    def _apply_sql_guardrails(
        self, source: str, sql: str
    ) -> tuple[str, list[SecurityEvent]]:
        """Apply all guardrails to a single SQL string."""
        events: list[SecurityEvent] = []
        dialect = _sql_dialect_for(source)

        try:
            statements = sqlglot.parse(sql, dialect=dialect)
        except sqlglot.errors.ParseError:
            return sql, events

        rewritten_parts: list[str] = []

        for stmt in statements:
            if stmt is None:
                continue

            if isinstance(stmt, exp.Select):
                stmt, limit_events = self._enforce_sql_row_cap(stmt, source)
                events.extend(limit_events)

                stmt, timeout_events = self._add_timeout_hint(stmt, source)
                events.extend(timeout_events)

            depth = self._max_subquery_depth(stmt)
            if depth > self._max_depth:
                events.append(SecurityEvent(
                    stage="GUARDRAILS",
                    severity=Severity.WARN,
                    message=f"Subquery depth ({depth}) exceeds limit ({self._max_depth}) in {source}",
                    detail="Consider flattening nested subqueries for performance",
                ))

            rewritten_parts.append(stmt.sql(dialect=dialect))

        return "; ".join(rewritten_parts) if rewritten_parts else sql, events

    def _enforce_sql_row_cap(
        self, stmt: exp.Select, source: str
    ) -> tuple[exp.Select, list[SecurityEvent]]:
        """Inject LIMIT if the SELECT doesn't already have one."""
        events: list[SecurityEvent] = []

        existing_limit = stmt.find(exp.Limit)
        if existing_limit is not None:
            limit_val = existing_limit.expression
            if isinstance(limit_val, exp.Literal) and limit_val.is_int:
                val = int(limit_val.this)
                if val > self._row_cap:
                    events.append(SecurityEvent(
                        stage="GUARDRAILS",
                        severity=Severity.WARN,
                        message=f"LIMIT {val} exceeds row cap ({self._row_cap}) in {source}",
                        detail=f"Capping to {self._row_cap}",
                    ))
                    stmt = stmt.limit(self._row_cap)
            return stmt, events

        events.append(SecurityEvent(
            stage="GUARDRAILS",
            severity=Severity.INFO,
            message=f"Row cap applied (LIMIT {self._row_cap}) to {source}",
        ))
        stmt = stmt.limit(self._row_cap)
        return stmt, events

    def _add_timeout_hint(
        self, stmt: exp.Select, source: str
    ) -> tuple[exp.Select, list[SecurityEvent]]:
        """Add a timeout hint as metadata for the query executor."""
        events: list[SecurityEvent] = []

        sql_text = stmt.sql()
        if "QUERY_TIMEOUT" in sql_text.upper() or "MAX_EXECUTION_TIME" in sql_text.upper():
            return stmt, events

        events.append(SecurityEvent(
            stage="GUARDRAILS",
            severity=Severity.INFO,
            message=f"Timeout hint ({self._timeout_seconds}s) applied to {source}",
        ))

        return stmt, events

    # ------------------------------------------------------------------
    # MQL guardrails
    # ------------------------------------------------------------------

    def _apply_mql_guardrails(
        self, source: str, query_text: str
    ) -> tuple[str, list[SecurityEvent]]:
        """Apply row cap and timeout to a MongoDB query."""
        events: list[SecurityEvent] = []

        try:
            parsed = json.loads(query_text)
        except (json.JSONDecodeError, TypeError):
            return query_text, events

        if not isinstance(parsed, dict):
            return query_text, events

        operation = parsed.get("operation", "find").lower()

        if operation == "aggregate":
            pipeline = parsed.get("pipeline", [])
            if isinstance(pipeline, list):
                has_limit = any(
                    isinstance(s, dict) and "$limit" in s for s in pipeline
                )
                if not has_limit:
                    pipeline.append({"$limit": self._row_cap})
                    parsed["pipeline"] = pipeline
                    events.append(SecurityEvent(
                        stage="GUARDRAILS",
                        severity=Severity.INFO,
                        message=f"Row cap applied ($limit {self._row_cap}) to MQL pipeline on {source}",
                    ))
                else:
                    for stage in pipeline:
                        if isinstance(stage, dict) and "$limit" in stage:
                            if stage["$limit"] > self._row_cap:
                                events.append(SecurityEvent(
                                    stage="GUARDRAILS",
                                    severity=Severity.WARN,
                                    message=f"$limit {stage['$limit']} exceeds row cap ({self._row_cap}) on {source}",
                                    detail=f"Capping to {self._row_cap}",
                                ))
                                stage["$limit"] = self._row_cap
                            break
        else:
            limit = parsed.get("limit", 0)
            if not limit:
                parsed["limit"] = self._row_cap
                events.append(SecurityEvent(
                    stage="GUARDRAILS",
                    severity=Severity.INFO,
                    message=f"Row cap applied (limit {self._row_cap}) to MQL find on {source}",
                ))
            elif limit > self._row_cap:
                events.append(SecurityEvent(
                    stage="GUARDRAILS",
                    severity=Severity.WARN,
                    message=f"MQL limit {limit} exceeds row cap ({self._row_cap}) on {source}",
                    detail=f"Capping to {self._row_cap}",
                ))
                parsed["limit"] = self._row_cap

        if "maxTimeMS" not in parsed:
            parsed["maxTimeMS"] = self._timeout_seconds * 1000
            events.append(SecurityEvent(
                stage="GUARDRAILS",
                severity=Severity.INFO,
                message=f"Timeout ({self._timeout_seconds}s) applied to MQL on {source}",
            ))

        return json.dumps(parsed), events

    # ------------------------------------------------------------------
    # Cypher guardrails
    # ------------------------------------------------------------------

    def _apply_cypher_guardrails(
        self, source: str, cypher: str
    ) -> tuple[str, list[SecurityEvent]]:
        """Inject LIMIT into a Cypher query if absent.

        Cypher's LIMIT belongs to a projection clause (RETURN / WITH).
        Pure writes — ``CREATE (n:X)``, ``MATCH (n) DELETE n`` without a
        RETURN — would parse as syntax errors if we appended LIMIT.
        Skip the injection in that case; the connector's per-query
        timeout still bounds runtime.
        """
        events: list[SecurityEvent] = []
        upper = cypher.upper()
        has_projection = "RETURN" in upper or re.search(r"\bWITH\b", upper) is not None

        if not has_projection:
            return cypher, events

        if "LIMIT" not in upper:
            cypher = f"{cypher.rstrip().rstrip(';')}\nLIMIT {self._row_cap}"
            events.append(SecurityEvent(
                stage="GUARDRAILS",
                severity=Severity.INFO,
                message=f"Row cap applied (LIMIT {self._row_cap}) to Cypher on {source}",
            ))
        else:
            match = re.search(r"\bLIMIT\s+(\d+)\b", cypher, re.IGNORECASE)
            if match:
                val = int(match.group(1))
                if val > self._row_cap:
                    events.append(SecurityEvent(
                        stage="GUARDRAILS",
                        severity=Severity.WARN,
                        message=f"Cypher LIMIT {val} exceeds row cap ({self._row_cap}) on {source}",
                        detail=f"Capping to {self._row_cap}",
                    ))
                    cypher = re.sub(
                        r"\bLIMIT\s+\d+\b",
                        f"LIMIT {self._row_cap}",
                        cypher,
                        count=1,
                        flags=re.IGNORECASE,
                    )

        return cypher, events

    # ------------------------------------------------------------------
    # Elasticsearch DSL guardrails
    # ------------------------------------------------------------------

    def _apply_es_guardrails(
        self, source: str, query_text: str
    ) -> tuple[str, list[SecurityEvent]]:
        """Inject/cap 'size' in an Elasticsearch query body."""
        events: list[SecurityEvent] = []

        try:
            body = json.loads(query_text)
        except (json.JSONDecodeError, TypeError):
            return query_text, events

        if not isinstance(body, dict):
            return query_text, events

        current_size = body.get("size")
        if current_size is None:
            body["size"] = self._row_cap
            events.append(SecurityEvent(
                stage="GUARDRAILS",
                severity=Severity.INFO,
                message=f"Row cap applied (size {self._row_cap}) to ES query on {source}",
            ))
        elif isinstance(current_size, int) and current_size > self._row_cap:
            events.append(SecurityEvent(
                stage="GUARDRAILS",
                severity=Severity.WARN,
                message=f"ES size {current_size} exceeds row cap ({self._row_cap}) on {source}",
                detail=f"Capping to {self._row_cap}",
            ))
            body["size"] = self._row_cap

        if "timeout" not in body:
            body["timeout"] = f"{self._timeout_seconds}s"
            events.append(SecurityEvent(
                stage="GUARDRAILS",
                severity=Severity.INFO,
                message=f"Timeout ({self._timeout_seconds}s) applied to ES query on {source}",
            ))

        return json.dumps(body), events

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _max_subquery_depth(node: exp.Expression, current: int = 0) -> int:
        """Recursively find the maximum subquery nesting depth."""
        max_depth = current
        for child in node.iter_expressions():
            if isinstance(child, exp.Subquery):
                max_depth = max(
                    max_depth,
                    Guardrails._max_subquery_depth(child, current + 1),
                )
            else:
                max_depth = max(
                    max_depth,
                    Guardrails._max_subquery_depth(child, current),
                )
        return max_depth
