"""Types for faz MODULE 3 — Safety Pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class AccessMode(str, Enum):
    """Access modes for per-database baseline and per-table overrides.

    Used at two layers:
      1. Per-database baseline (mandatory) — every Permission carries one.
      2. Per-table override (optional)     — same enum, scoped to one table.

    The per-table override wins; otherwise the per-database baseline applies.
    DDL is permitted only by Admin (A); every other level rejects it at
    RBACGate and AST_CHECKER acts as a defense-in-depth backstop for
    everything below A.
    """

    R = "R"          # Read-Only
    W = "W"          # Write-Only      INSERT, UPDATE, DELETE  (no SELECT)
    RW = "RW"        # Read + Write
    RA = "RA"        # Read + Append   SELECT + INSERT only
    RWA = "RWA"      # Read + Write + Append (no DELETE — append-with-update)
    A = "A"          # Admin (everything including DDL)


# Which operation classes each access mode allows.
# Source of truth for the RBACGate decision matrix.
ACCESS_MODE_ALLOWED: dict[AccessMode, set[str]] = {
    AccessMode.R:   {"SELECT", "EXPLAIN"},
    AccessMode.W:   {"INSERT", "UPDATE", "DELETE"},
    AccessMode.RW:  {"SELECT", "EXPLAIN", "INSERT", "UPDATE", "DELETE"},
    AccessMode.RA:  {"SELECT", "EXPLAIN", "INSERT"},
    AccessMode.RWA: {"SELECT", "EXPLAIN", "INSERT", "UPDATE"},
    AccessMode.A:   {"SELECT", "EXPLAIN", "INSERT", "UPDATE", "DELETE", "DDL",
                     "DROP", "TRUNCATE", "ALTER", "CREATE", "GRANT", "REVOKE"},
}


class Op(str, Enum):
    """Normalized operation classes emitted by per-family access extractors.

    Every per-family extractor (SQL/MQL/Cypher/ES_DSL/Vector/Dynamo) maps
    its native verbs onto these. RBACGate matches against
    ACCESS_MODE_ALLOWED using the same strings.
    """

    SELECT = "SELECT"        # SELECT/find/MATCH/Get/_search/scan/query (read)
    INSERT = "INSERT"        # INSERT/insertOne/CREATE/PutItem/upsert/_doc
    UPDATE = "UPDATE"        # UPDATE/updateOne/SET/UpdateItem
    DELETE = "DELETE"        # DELETE/deleteOne/DETACH DELETE/DeleteItem
    DDL    = "DDL"           # CREATE TABLE/dropCollection/_template/etc.


@dataclass(frozen=True)
class AccessTarget:
    """One scope unit that a request wants to touch.

    Per-family extractors emit one AccessTarget per touched table/collection/
    index/label. RBACGate evaluates each independently against the layered
    permission policy (per-table override → wildcard → per-database baseline).
    A query passes only if every AccessTarget passes.
    """

    database: str
    table: str
    operation: Op


class QueryLanguage(str, Enum):
    """Query language families supported by the safety pipeline."""

    SQL = "SQL"              # PostgreSQL, MySQL, Oracle, Cassandra (CQL is SQL-like)
    MQL = "MQL"              # MongoDB Query Language
    CYPHER = "CYPHER"        # Neo4j Cypher
    ES_DSL = "ES_DSL"        # Elasticsearch / OpenSearch Query DSL (JSON)
    VECTOR = "VECTOR"        # Weaviate, Qdrant, Milvus, Pinecone
    DYNAMO = "DYNAMO"        # DynamoDB PartiQL / expression syntax
    COUCHDB = "COUCHDB"      # CouchDB Mango queries


# Map ConnectorType values to their query language.
# Import ConnectorType string values to avoid circular imports.
_CONNECTOR_LANGUAGE: dict[str, QueryLanguage] = {
    "postgresql": QueryLanguage.SQL,
    "mysql": QueryLanguage.SQL,
    "oracle": QueryLanguage.SQL,
    "cassandra": QueryLanguage.SQL,
    "mongodb": QueryLanguage.MQL,
    "neo4j": QueryLanguage.CYPHER,
    "elasticsearch": QueryLanguage.ES_DSL,
    "opensearch": QueryLanguage.ES_DSL,
    "weaviate": QueryLanguage.VECTOR,
    "qdrant": QueryLanguage.VECTOR,
    "milvus": QueryLanguage.VECTOR,
    "pinecone": QueryLanguage.VECTOR,
    "dynamodb": QueryLanguage.DYNAMO,
    "couchdb": QueryLanguage.COUCHDB,
}

# Named-connector override map: connector name → QueryLanguage.
# Populated at startup by update_connector_name_mapping() so that custom
# names (e.g. "mongo_prod", "pg_primary") resolve to the correct language.
_NAME_TO_LANGUAGE: dict[str, QueryLanguage] = {}


def update_connector_name_mapping(name_to_type: dict[str, str]) -> None:
    """Register custom connector names so resolve_query_language works correctly.

    Call this at startup after loading database.yaml, passing a dict of
    connector name → connector type value (e.g. {"mongo_prod": "mongodb"}).
    Names that equal their type value are resolved via _CONNECTOR_LANGUAGE
    already; only custom names strictly need registering, but passing all
    is harmless and simpler.
    """
    _NAME_TO_LANGUAGE.clear()
    for name, type_val in name_to_type.items():
        lang = _CONNECTOR_LANGUAGE.get(type_val.lower())
        if lang is not None:
            _NAME_TO_LANGUAGE[name.lower()] = lang


def resolve_query_language(source: str) -> QueryLanguage:
    """Derive the query language from an IR source string.

    Source format is ``<connector_name>.<table>`` where connector_name is the
    routing key (ConnectionConfig.name). Checks the named-connector override
    map first (populated by update_connector_name_mapping), then falls back to
    matching the prefix against connector type values in _CONNECTOR_LANGUAGE.

    Falls back to SQL if the prefix is unrecognised.
    """
    prefix = source.split(".")[0].lower()
    if prefix in _NAME_TO_LANGUAGE:
        return _NAME_TO_LANGUAGE[prefix]
    return _CONNECTOR_LANGUAGE.get(prefix, QueryLanguage.SQL)


class Severity(str, Enum):
    INFO = "INFO"
    WARN = "WARN"
    BLOCK = "BLOCK"


class StageVerdict(str, Enum):
    PASS = "PASS"
    PARTIAL = "PARTIAL"   # some sources stripped, rest OK
    BLOCK = "BLOCK"


@dataclass
class SecurityEvent:
    """A single finding from any safety stage."""

    stage: str
    severity: Severity
    message: str
    detail: str = ""


@dataclass
class StageResult:
    """Output from a single pipeline stage."""

    stage: str
    verdict: StageVerdict
    events: list[SecurityEvent] = field(default_factory=list)


@dataclass
class ValidationResult:
    """Final output of the full safety pipeline."""

    allowed: bool
    login_required: bool = False
    stages: list[StageResult] = field(default_factory=list)
    events: list[SecurityEvent] = field(default_factory=list)
    stripped_sources: list[str] = field(default_factory=list)
