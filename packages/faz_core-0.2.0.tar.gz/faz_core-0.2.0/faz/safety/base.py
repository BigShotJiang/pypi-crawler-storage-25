"""Abstract base for safety pipeline stages."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from faz.auth.types import Permission
    from faz.types.ir import IntermediateRepr

from .types import StageResult


class SafetyStage(ABC):
    """Interface every safety stage must implement."""

    @abstractmethod
    def validate(
        self,
        ir: IntermediateRepr,
        permissions: list[Permission],
        raw_sql: dict[str, str] | None = None,
    ) -> StageResult:
        """Validate the IR (and optionally generated SQL) against safety rules.

        Args:
            ir: The intermediate representation from the LLM.
            permissions: The user's permissions from MODULE 1.
            raw_sql: Optional mapping of source -> generated SQL query string.
                     Used by Stage 2 (AST Checker) to parse and validate SQL.
        """
