"""
Qdrant connector for faz.

Uses qdrant_client.AsyncQdrantClient (REST, port 6333).
Schema discovery via get_collections() + get_collection() + scroll() for payload fields.
Read-only: only search, scroll, count, and recommend are permitted.
"""

import json
import time
from typing import Any

from qdrant_client import AsyncQdrantClient
from qdrant_client.http.models import Filter

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

CONNECTOR_TYPE = ConnectorType.QDRANT

# Allowed query intents (read-only operations)
_ALLOWED_INTENTS = {"search", "scroll", "count", "recommend"}

# Blocked operations (write / destructive)
_BLOCKED_INTENTS = {"upsert", "delete", "create_collection", "delete_collection"}


def _scored_point_to_dict(point: Any) -> dict[str, Any]:
    """Convert a ScoredPoint to a plain Python dict."""
    row: dict[str, Any] = {"id": point.id}
    if hasattr(point, "score") and point.score is not None:
        row["_score"] = point.score
    if point.payload:
        row.update(point.payload)
    return row


def _record_to_dict(point: Any) -> dict[str, Any]:
    """Convert a Record (scroll result) to a plain Python dict."""
    row: dict[str, Any] = {"id": point.id}
    if point.payload:
        row.update(point.payload)
    return row


class QdrantConnector(BaseConnector):
    """
    Async Qdrant connector using AsyncQdrantClient (REST API).

    Supports:
    - Schema discovery via collections + vector config + sample scroll
    - search  : Nearest-neighbour vector search
    - scroll  : Paginated full-collection scan
    - count   : Total point count for a collection
    - recommend: Recommendation by example points
    - Read-only by design: no upsert, delete, or collection mutations

    IntermediateQuery.filters keys:
      "vector"  : list[float]  — query vector for "search"
      "filter"  : dict         — Qdrant filter condition (optional)
      "limit"   : int          — override limit
    """

    CONNECTOR_TYPE = ConnectorType.QDRANT

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: AsyncQdrantClient | None = None

    async def connect(self) -> None:
        self._client = AsyncQdrantClient(
            host=self.config.host,
            port=self.config.port,
        )
        # Verify connectivity
        await self._client.get_collections()
        self._connected = True

    async def disconnect(self) -> None:
        if self._client:
            await self._client.close()
            self._client = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            await self._client.get_collections()
            return True
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        Introspect Qdrant:
        - List all collections
        - For each: fetch vector config (dimension, distance metric)
        - Scroll one point to discover payload field names and types
        """
        assert self._client is not None, "Not connected"

        tables: list[TableSchema] = []

        collections_response = await self._client.get_collections()
        collection_names = [c.name for c in collections_response.collections]

        for name in collection_names:
            fields: list[FieldSchema] = []
            row_count = 0

            try:
                info = await self._client.get_collection(name)
                row_count = info.points_count or 0

                # Parse vector config(s)
                vectors_config = info.config.params.vectors
                if vectors_config is not None:
                    if hasattr(vectors_config, "size"):
                        # Single unnamed vector
                        dim = vectors_config.size
                        dist = vectors_config.distance.name if hasattr(vectors_config.distance, "name") else str(vectors_config.distance)
                        fields.append(FieldSchema(
                            name="vector",
                            data_type=f"float[{dim}] {dist}",
                            description="Embedding vector",
                        ))
                    elif isinstance(vectors_config, dict):
                        # Named vectors
                        for vec_name, vec_params in vectors_config.items():
                            dim = vec_params.size
                            dist = vec_params.distance.name if hasattr(vec_params.distance, "name") else str(vec_params.distance)
                            fields.append(FieldSchema(
                                name=f"vector_{vec_name}",
                                data_type=f"float[{dim}] {dist}",
                                description=f"Embedding vector '{vec_name}'",
                            ))

            except Exception:
                pass

            # Scroll one point to discover payload fields
            try:
                scroll_result, _ = await self._client.scroll(
                    collection_name=name,
                    limit=1,
                    with_payload=True,
                    with_vectors=False,
                )
                if scroll_result:
                    sample_payload = scroll_result[0].payload or {}
                    for field_name, field_value in sample_payload.items():
                        data_type = type(field_value).__name__
                        fields.append(FieldSchema(
                            name=field_name,
                            data_type=data_type,
                            description=f"Payload field from sample point",
                        ))
            except Exception:
                pass

            tables.append(TableSchema(
                name=name,
                fields=fields,
                row_count_estimate=row_count,
                description=f"Qdrant collection: {name}",
            ))

        return SchemaMetadata(
            connector_type=ConnectorType.QDRANT,
            database=f"{self.config.host}:{self.config.port}",
            tables=tables,
        )

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """Validate the query intent.

        Reads + DML (upsert / update_vectors / set_payload / delete /
        clear_payload) flow through; RBAC owns per-collection decisions.
        DDL intents (create_collection / delete_collection) stay
        hard-blocked at the connector regardless of policy.
        """
        intent = query.strip().lower().replace("_", "")
        ddl = {
            "createcollection", "deletecollection", "dropcollection",
            "alteralias", "createalias", "deletealias",
            "createindex", "deleteindex", "createshardkey",
            "deleteshardkey", "snapshot",
        }
        if intent in ddl and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=(
                    f"DDL intent '{intent}' is hard-blocked at the "
                    "connector regardless of policy."
                ),
            )
        return ValidationResult(is_valid=True)

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Lift intent + payload from raw_query JSON into query.filters."""
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query
        if not isinstance(parsed, dict):
            return query
        intent = (
            parsed.get("intent") or parsed.get("operation") or ""
        ).strip().lower().replace("_", "")
        if intent:
            query.intent = intent
        for key in ("vector", "vectors", "points", "payload", "filter",
                    "ids", "id", "positive", "negative", "limit"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]
        return query

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a Qdrant operation based on the intent.

        IntermediateQuery fields used:
          - intent  : reads (search/scroll/count/recommend) +
                      writes (upsert/setpayload/clearpayload/delete)
          - tables  : [collection_name]
          - limit   : max results (capped at 1000)
          - filters : {"vector": [...], "points": [...], "filter": {...}, "ids": [...]}
        """
        assert self._client is not None, "Not connected"

        # Lift raw_query → intent/filters before dispatching.
        query = self._parse_raw_query(query)

        database_label = f"{self.config.host}:{self.config.port}"
        intent = query.intent.strip().lower().replace("_", "")

        # Validate intent
        validation = await self.validate_query(intent, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.QDRANT,
                database=database_label,
                error=validation.error,
            )

        if not query.tables:
            return QueryResult(
                connector_type=ConnectorType.QDRANT,
                database=database_label,
                error="No collection specified in tables[0].",
            )

        collection_name = query.tables[0]
        filters_cfg = query.filters or {}

        # Resolve limit (filters override takes precedence)
        effective_limit = min(
            filters_cfg.get("limit", query.limit),
            1000,
        )

        # Build optional Qdrant filter
        qdrant_filter: Filter | None = None
        raw_filter = filters_cfg.get("filter")
        if raw_filter and isinstance(raw_filter, dict):
            try:
                qdrant_filter = Filter(**raw_filter)
            except Exception:
                qdrant_filter = None

        # Audit representation
        query_repr: dict[str, Any] = {
            "intent": intent,
            "collection": collection_name,
            "limit": effective_limit,
        }

        start = time.monotonic()
        rows: list[dict[str, Any]] = []

        try:
            if intent == "search":
                vector = filters_cfg.get("vector", [])
                query_repr["vector_len"] = len(vector)
                results = await self._client.query_points(
                    collection_name=collection_name,
                    query=vector,
                    limit=effective_limit,
                    with_payload=True,
                    query_filter=qdrant_filter,
                )
                rows = [_scored_point_to_dict(p) for p in results.points]

            elif intent == "scroll":
                scroll_result, _ = await self._client.scroll(
                    collection_name=collection_name,
                    limit=effective_limit,
                    with_payload=True,
                    with_vectors=False,
                    scroll_filter=qdrant_filter,
                )
                rows = [_record_to_dict(p) for p in scroll_result]

            elif intent == "count":
                count_result = await self._client.count(
                    collection_name=collection_name,
                    count_filter=qdrant_filter,
                    exact=True,
                )
                rows = [{"count": count_result.count}]

            elif intent == "recommend":
                positive = filters_cfg.get("positive", [])
                negative = filters_cfg.get("negative", [])
                query_repr.update({"positive": positive, "negative": negative})
                from qdrant_client.models import RecommendInput
                recommend_input = RecommendInput(
                    positive=positive,
                    negative=negative if negative else [],
                )
                results = await self._client.query_points(
                    collection_name=collection_name,
                    query=recommend_input,
                    limit=effective_limit,
                    with_payload=True,
                    query_filter=qdrant_filter,
                )
                rows = [_scored_point_to_dict(p) for p in results.points]

            elif intent in ("upsert", "insert", "insertone", "insertmany"):
                # qdrant points: list of {id, vector, payload}
                from qdrant_client.models import PointStruct
                raw_points = (
                    filters_cfg.get("points")
                    or filters_cfg.get("vectors")
                    or []
                )
                if not isinstance(raw_points, list):
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.QDRANT, database=database_label,
                        error="upsert requires `points` (or `vectors`) as a JSON array",
                        execution_time_ms=elapsed_ms,
                    )
                points = [
                    PointStruct(
                        id=p.get("id"),
                        vector=p.get("vector"),
                        payload=p.get("payload"),
                    )
                    for p in raw_points
                    if isinstance(p, dict)
                ]
                resp = await self._client.upsert(
                    collection_name=collection_name, points=points,
                )
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{
                    "operation_id": getattr(resp, "operation_id", None),
                    "status": str(getattr(resp, "status", "")),
                    "upserted": len(points),
                }]

            elif intent in ("setpayload", "updatepayload"):
                payload = filters_cfg.get("payload") or {}
                ids = filters_cfg.get("ids")
                resp = await self._client.set_payload(
                    collection_name=collection_name, payload=payload,
                    points=ids if ids else None,
                )
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{
                    "operation_id": getattr(resp, "operation_id", None),
                    "status": str(getattr(resp, "status", "")),
                }]

            elif intent in ("clearpayload",):
                ids = filters_cfg.get("ids")
                resp = await self._client.clear_payload(
                    collection_name=collection_name,
                    points_selector=ids if ids else qdrant_filter,
                )
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{
                    "operation_id": getattr(resp, "operation_id", None),
                    "status": str(getattr(resp, "status", "")),
                }]

            elif intent in ("deletecollection", "dropcollection"):
                # DDL: drop the collection (requires access: A).
                resp = await self._client.delete_collection(collection_name=collection_name)
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"result": bool(resp), "collection": collection_name}]

            elif intent == "createcollection":
                # DDL: create a collection (requires access: A).
                from qdrant_client.models import VectorParams
                vectors_config = filters_cfg.get("vectors_config") or {}
                size = int(filters_cfg.get("size") or vectors_config.get("size") or 1536)
                distance = filters_cfg.get("distance") or vectors_config.get("distance") or "Cosine"
                resp = await self._client.create_collection(
                    collection_name=collection_name,
                    vectors_config=VectorParams(size=size, distance=distance),
                )
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"result": bool(resp), "collection": collection_name}]

            elif intent in ("delete", "deleteone", "deletemany"):
                ids = filters_cfg.get("ids")
                if ids:
                    resp = await self._client.delete(
                        collection_name=collection_name, points_selector=ids,
                    )
                elif qdrant_filter:
                    resp = await self._client.delete(
                        collection_name=collection_name,
                        points_selector=qdrant_filter,
                    )
                else:
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.QDRANT, database=database_label,
                        error=("delete requires either `ids` or a `filter` — "
                               "empty selector is refused as unintended DDL"),
                        execution_time_ms=elapsed_ms,
                    )
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{
                    "operation_id": getattr(resp, "operation_id", None),
                    "status": str(getattr(resp, "status", "")),
                }]

            else:
                elapsed_ms = (time.monotonic() - start) * 1000
                return QueryResult(
                    connector_type=ConnectorType.QDRANT,
                    database=database_label,
                    error=f"Unsupported intent: {intent}",
                    execution_time_ms=elapsed_ms,
                )

            elapsed_ms = (time.monotonic() - start) * 1000
            columns = list(rows[0].keys()) if rows else []

            return QueryResult(
                connector_type=ConnectorType.QDRANT,
                database=database_label,
                rows=rows,
                columns=columns,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=json.dumps(query_repr),
            )

        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.QDRANT,
                database=database_label,
                error=str(exc),
                execution_time_ms=elapsed_ms,
                query_executed=json.dumps(query_repr),
            )
