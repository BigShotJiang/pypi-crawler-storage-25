"""
MongoDB connector for faz.

Uses pymongo (synchronous) wrapped with run_in_executor for async compatibility.
This avoids the "Future attached to a different loop" errors that occur with
motor (async pymongo) when shared across pytest-asyncio module-scoped fixtures.

Schema discovery via collection sampling (MongoDB is schemaless).
Read-only enforcement via operation whitelist.
"""

import asyncio
import json
import time
from collections import defaultdict
from typing import Any

from pymongo import MongoClient
from pymongo.errors import PyMongoError

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldDistribution,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# Operations allowed in READ_ONLY mode
_ALLOWED_READ_OPERATIONS = {"find", "aggregate", "count_documents", "estimated_document_count", "distinct", "select"}

# Operations always blocked regardless of mode
_BLOCKED_WRITE_OPERATIONS = {"insert_one", "insert_many", "update_one", "update_many",
                              "replace_one", "delete_one", "delete_many", "drop",
                              "drop_collection", "drop_database", "create_index",
                              "create_collection", "rename_collection"}

# Aggregation pipeline stages that can cause writes — block these
_BLOCKED_PIPELINE_STAGES = {"$out", "$merge"}

_SCHEMA_SAMPLE_SIZE = 100  # documents to sample per collection for schema inference


def _infer_bson_type(value: Any) -> str:
    """Map a Python value to a readable BSON type string."""
    type_map = {
        int: "int",
        float: "double",
        str: "string",
        bool: "bool",
        list: "array",
        dict: "object",
        bytes: "binary",
    }
    return type_map.get(type(value), type(value).__name__)


def _flatten_schema(doc: dict, prefix: str = "") -> dict[str, str]:
    """Recursively extract field paths and their types from a sample document."""
    fields: dict[str, str] = {}
    for key, value in doc.items():
        full_key = f"{prefix}.{key}" if prefix else key
        fields[full_key] = _infer_bson_type(value)
        if isinstance(value, dict):
            fields.update(_flatten_schema(value, prefix=full_key))
    return fields


def _resolve_path(doc: dict, path: str) -> Any:
    """Resolve a dotted field path to its value in a document."""
    parts = path.split(".")
    current: Any = doc
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current


def _safe_str(value: Any) -> str:
    """Convert a value to a string safe for display, handling BSON types."""
    if type(value).__module__.startswith("bson"):
        return str(value)
    return str(value)


class MongoDBConnector(BaseConnector):
    """
    Async-compatible MongoDB connector using pymongo (sync) via run_in_executor.

    Supports:
    - Schema discovery via document sampling across all collections
    - Read-only enforcement via operation whitelist and pipeline stage blocking
    - Query execution via find() or aggregate() pipelines
    - Audit-ready: returns serialised query in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.MONGODB

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: MongoClient | None = None
        self._db: Any = None

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    async def connect(self) -> None:
        uri = (
            f"mongodb://{self.config.username}:{self.config.password}"
            f"@{self.config.host}:{self.config.port}"
        )

        def _connect():
            client = MongoClient(
                uri,
                serverSelectionTimeoutMS=5000,
                tls=self.config.ssl,
            )
            # Trigger connection to surface errors early
            client.admin.command("ping")
            return client

        self._client = await self._run(_connect)
        self._db = self._client[self.config.database]
        self._connected = True

    async def disconnect(self) -> None:
        if self._client:
            client = self._client
            await self._run(client.close)
            self._client = None
            self._db = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            client = self._client
            await self._run(lambda: client.admin.command("ping"))
            return True
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        MongoDB is schemaless, so schema is inferred by sampling documents.
        Merges field types across sampled documents per collection.
        """
        assert self._db is not None, "Not connected"
        db = self._db

        collection_names: list[str] = await self._run(db.list_collection_names)
        tables: list[TableSchema] = []

        for coll_name in collection_names:
            collection = db[coll_name]

            def _sample(coll=collection):
                cursor = coll.aggregate([{"$sample": {"size": _SCHEMA_SAMPLE_SIZE}}])
                return list(cursor)

            samples = await self._run(_sample)

            # Merge field types across all samples
            field_types: dict[str, set[str]] = defaultdict(set)
            # Track values per field for distribution stats
            field_values: dict[str, list[Any]] = defaultdict(list)
            null_counts: dict[str, int] = defaultdict(int)
            for doc in samples:
                seen_fields: set[str] = set()
                for field_path, field_type in _flatten_schema(doc).items():
                    field_types[field_path].add(field_type)
                    seen_fields.add(field_path)
                    value = _resolve_path(doc, field_path)
                    if value is not None:
                        field_values[field_path].append(value)
                    else:
                        null_counts[field_path] += 1
                # Fields not present in this doc count as null
                for known in field_types:
                    if known not in seen_fields:
                        null_counts[known] += 1

            # Estimate document count
            count: int = await self._run(collection.estimated_document_count)

            total_sampled = len(samples) if samples else 1

            fields = []
            for fname, ftypes in sorted(field_types.items()):
                # Build distribution from sampled values
                vals = field_values.get(fname, [])
                distinct = set()
                sample_vals: list[Any] = []
                for v in vals:
                    str_v = str(v)
                    if str_v not in distinct:
                        distinct.add(str_v)
                        if len(sample_vals) < 3:
                            sample_vals.append(v)

                dist = FieldDistribution(
                    distinct_count=len(distinct),
                    null_fraction=null_counts.get(fname, 0) / total_sampled,
                    sample_values=[_safe_str(v) for v in sample_vals],
                )

                fields.append(FieldSchema(
                    name=fname,
                    data_type=" | ".join(sorted(ftypes)),
                    is_primary=(fname == "_id"),
                    distribution=dist,
                ))

            tables.append(TableSchema(
                name=coll_name,
                fields=fields,
                row_count_estimate=count,
            ))

        return SchemaMetadata(
            connector_type=ConnectorType.MONGODB,
            database=self.config.database,
            tables=tables,
        )

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """Validate the operation name from the IntermediateQuery intent.

        Phase 6 stance: writes are gated by the faz safety pipeline /
        RBAC, **not** the connector. So we only block what's NEVER
        permissible regardless of policy:

          * DDL on collection/database/index — those are blocked at
            ``Op.DDL`` upstream and would also be rejected here.

        Reads + DML (insert/update/delete) flow through. The connector
        trusts that the safety pipeline checked the policy before
        dispatching here.
        """
        operation = query.strip().lower().replace("_", "")
        ddl_ops = {
            "drop", "dropcollection", "dropdatabase", "dropindex",
            "createindex", "createcollection", "renamecollection",
            "runcommand",
        }
        if operation in ddl_ops and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=f"DDL operation '{operation}' is not permitted",
            )
        return ValidationResult(is_valid=True)

    def _validate_pipeline(self, pipeline: list[dict]) -> ValidationResult:
        """Block aggregation pipeline stages that can write data."""
        for stage in pipeline:
            for stage_key in stage:
                if stage_key in _BLOCKED_PIPELINE_STAGES:
                    return ValidationResult(
                        is_valid=False,
                        blocked_reason=f"Pipeline stage '{stage_key}' is not permitted — writes data out",
                    )
        return ValidationResult(is_valid=True)

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Parse raw_query MQL JSON and populate filters/fields.

        Always overrides ``query.intent`` from the ``operation`` field so
        the connector dispatches on what the agent actually asked for —
        the executor's intent default is just a placeholder and would
        otherwise force every request through the find branch.

        Recognized operations (canonical, lowercase, no underscores):
          Reads:  find findone aggregate count countdocuments distinct
          Writes: insertone insertmany updateone updatemany replaceone
                  deleteone deletemany findandmodify
                  findoneandupdate findoneanddelete

        The accompanying payload is stashed into ``query.filters`` under
        a stable set of keys (filter, document, documents, update,
        replacement, pipeline) for ``execute()`` to read back.
        """
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query

        if not isinstance(parsed, dict):
            return query

        op = parsed.get("operation", "").strip().lower().replace("_", "")
        if op:
            query.intent = op

        # Stash structured payloads.
        for key in ("filter", "document", "documents", "update",
                    "replacement", "pipeline", "ops", "key"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]

        # Projection → fields (only meaningful for find/findOne).
        if "projection" in parsed and not query.fields:
            proj = parsed["projection"]
            if isinstance(proj, dict):
                query.fields = [k for k, v in proj.items() if v and k != "_id"]

        return query

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a MongoDB find or aggregate query.

        IntermediateQuery fields used:
          - intent:   "find" or "aggregate"
          - tables:   [collection_name]
          - filters:  MQL filter dict (for find) or pipeline list (for aggregate)
          - fields:   projection fields (for find)
          - raw_query: MQL JSON string (parsed into filters/fields if present)
          - limit:    max documents to return
        """
        assert self._db is not None, "Not connected"

        # Parse raw_query MQL JSON into filters/fields
        query = self._parse_raw_query(query)

        intent = query.intent.lower()
        validation = await self.validate_query(intent, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.MONGODB,
                database=self.config.database,
                error=validation.blocked_reason or validation.error,
            )

        if not query.tables:
            return QueryResult(
                connector_type=ConnectorType.MONGODB,
                database=self.config.database,
                error="No collection specified in query",
            )

        collection = self._db[query.tables[0]]
        collection_name = query.tables[0]
        limit = min(query.limit, 1000)

        start = time.monotonic()
        try:
            if intent == "aggregate":
                pipeline: list[dict] = query.filters.get("pipeline", [])
                pipeline_check = self._validate_pipeline(pipeline)
                if not pipeline_check.is_valid:
                    return QueryResult(
                        connector_type=ConnectorType.MONGODB,
                        database=self.config.database,
                        error=pipeline_check.blocked_reason,
                    )
                # Append limit stage if not present
                stage_keys = {list(s.keys())[0] for s in pipeline}
                if "$limit" not in stage_keys:
                    pipeline.append({"$limit": limit})

                def _aggregate(coll=collection, pipe=pipeline):
                    return list(coll.aggregate(pipe))

                docs = await self._run(_aggregate)
                rows = [_serialise_doc(doc) for doc in docs]
                query_repr = f"aggregate({pipeline})"

            elif intent in ("findone",):
                filter_doc: dict = query.filters.get("filter", {})
                projection: dict = (
                    {f: 1 for f in query.fields} if query.fields else {}
                )

                def _findone(coll=collection, filt=filter_doc, proj=projection):
                    doc = coll.find_one(filt, proj)
                    return [doc] if doc else []

                docs = await self._run(_findone)
                rows = [_serialise_doc(doc) for doc in docs]
                query_repr = f"findOne({filter_doc}, {projection})"

            elif intent in ("count", "countdocuments"):
                filter_doc = query.filters.get("filter", {})

                def _count(coll=collection, filt=filter_doc):
                    return coll.count_documents(filt)

                n = await self._run(_count)
                rows = [{"count": n}]
                query_repr = f"countDocuments({filter_doc})"

            elif intent == "distinct":
                key = query.filters.get("key", "")
                filter_doc = query.filters.get("filter", {})

                def _distinct(coll=collection, k=key, filt=filter_doc):
                    return coll.distinct(k, filt)

                vals = await self._run(_distinct)
                rows = [{"value": v} for v in vals]
                query_repr = f"distinct({key!r}, {filter_doc})"

            elif intent in ("insertone", "insert"):
                doc = query.filters.get("document") or {}
                if not isinstance(doc, dict):
                    return QueryResult(
                        connector_type=ConnectorType.MONGODB,
                        database=self.config.database,
                        error="insertOne requires `document` as a JSON object",
                    )

                def _insert_one(coll=collection, d=doc):
                    return coll.insert_one(d)

                r = await self._run(_insert_one)
                rows = [{
                    "inserted_id": str(r.inserted_id),
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"insertOne({doc})"

            elif intent == "insertmany":
                docs_in = query.filters.get("documents") or []
                if not isinstance(docs_in, list) or not all(
                    isinstance(d, dict) for d in docs_in
                ):
                    return QueryResult(
                        connector_type=ConnectorType.MONGODB,
                        database=self.config.database,
                        error="insertMany requires `documents` as a JSON array of objects",
                    )

                def _insert_many(coll=collection, ds=docs_in):
                    return coll.insert_many(ds)

                r = await self._run(_insert_many)
                rows = [{
                    "inserted_ids": [str(x) for x in r.inserted_ids],
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"insertMany({len(docs_in)} docs)"

            elif intent in ("updateone", "update"):
                filt = query.filters.get("filter", {})
                upd = query.filters.get("update", {})

                def _update_one(coll=collection, f=filt, u=upd):
                    return coll.update_one(f, u)

                r = await self._run(_update_one)
                rows = [{
                    "matched_count": r.matched_count,
                    "modified_count": r.modified_count,
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"updateOne({filt}, {upd})"

            elif intent == "updatemany":
                filt = query.filters.get("filter", {})
                upd = query.filters.get("update", {})

                def _update_many(coll=collection, f=filt, u=upd):
                    return coll.update_many(f, u)

                r = await self._run(_update_many)
                rows = [{
                    "matched_count": r.matched_count,
                    "modified_count": r.modified_count,
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"updateMany({filt}, {upd})"

            elif intent == "replaceone":
                filt = query.filters.get("filter", {})
                repl = query.filters.get("replacement", {})

                def _replace_one(coll=collection, f=filt, r_=repl):
                    return coll.replace_one(f, r_)

                r = await self._run(_replace_one)
                rows = [{
                    "matched_count": r.matched_count,
                    "modified_count": r.modified_count,
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"replaceOne({filt}, {repl})"

            elif intent in ("deleteone", "delete"):
                filt = query.filters.get("filter", {})

                def _delete_one(coll=collection, f=filt):
                    return coll.delete_one(f)

                r = await self._run(_delete_one)
                rows = [{
                    "deleted_count": r.deleted_count,
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"deleteOne({filt})"

            elif intent == "deletemany":
                filt = query.filters.get("filter", {})

                def _delete_many(coll=collection, f=filt):
                    return coll.delete_many(f)

                r = await self._run(_delete_many)
                rows = [{
                    "deleted_count": r.deleted_count,
                    "acknowledged": r.acknowledged,
                }]
                query_repr = f"deleteMany({filt})"

            else:  # default: find
                filter_doc = query.filters.get("filter", {})
                projection = (
                    {f: 1 for f in query.fields} if query.fields else {}
                )

                def _find(coll=collection, filt=filter_doc, proj=projection, lim=limit):
                    return list(coll.find(filt, proj).limit(lim))

                docs = await self._run(_find)
                rows = [_serialise_doc(doc) for doc in docs]
                query_repr = f"find({filter_doc}, {projection}).limit({limit})"

            elapsed_ms = (time.monotonic() - start) * 1000
            columns = list(rows[0].keys()) if rows else []

            return QueryResult(
                connector_type=ConnectorType.MONGODB,
                database=self.config.database,
                columns=columns,
                rows=rows,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=f"{collection_name}.{query_repr}",
            )

        except PyMongoError as e:
            return QueryResult(
                connector_type=ConnectorType.MONGODB,
                database=self.config.database,
                error=str(e),
            )


def _serialise_doc(doc: dict) -> dict:
    """Convert BSON-specific types (ObjectId, datetime) to JSON-serialisable equivalents."""
    result = {}
    for key, value in doc.items():
        if type(value).__module__.startswith("bson"):
            result[key] = str(value)
        elif isinstance(value, dict):
            result[key] = _serialise_doc(value)
        elif isinstance(value, list):
            result[key] = [str(v) if type(v).__module__.startswith("bson") else v for v in value]
        else:
            result[key] = value
    return result
