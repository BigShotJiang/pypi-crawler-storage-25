"""
Pinecone connector for faz.

Uses pinecone>=3.0.0 (synchronous REST client) wrapped with run_in_executor.

The connector targets a single Pinecone index. This covers both:
  - pinecone-index Docker container (ghcr.io/pinecone-io/pinecone-index):
      a single pre-configured index with no control plane — connect via
      pc.Index(host="http://localhost:<port>").
  - Managed cloud Pinecone:
      connect via pc.Index(host="https://<index-host>.pinecone.io").

ConnectionConfig mapping:
  host     : Pinecone index hostname (e.g. "localhost")
  port     : Pinecone index port     (e.g. 5081)
  password : Pinecone API key        (use any non-empty string for local container)
  database : Human-readable label for the index (used in schema output and audit logs)
  ssl      : set True to use https   (default False → http for local, https for cloud)

There is intentionally no control-plane usage (list_indexes, create_index, etc.)
because the pinecone-index container does not expose a control plane.
"""

import asyncio
import json
import time
from typing import Any

from pinecone import Pinecone

from .base import (
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# Allowed read-only intents
_ALLOWED_INTENTS = {"query", "fetch", "list"}

# Write / destructive intents — always blocked
_BLOCKED_INTENTS = {"upsert", "update", "delete", "create_index", "delete_index"}


class PineconeConnector(BaseConnector):
    """
    Async-compatible Pinecone connector using the synchronous pinecone-client
    via run_in_executor.

    Connects directly to a single Pinecone index via its host URL.
    No control-plane operations are used, making it compatible with both the
    pinecone-index local container and managed cloud indexes.

    Supports:
    - Schema discovery: dimension, metric, vector count, and namespaces
      from describe_index_stats().
    - query : Approximate nearest-neighbour (ANN) vector search
    - fetch : Retrieve specific vectors by ID
    - list  : List vector IDs in the index / namespace

    IntermediateQuery.filters keys:
      "vector"    : list[float]   — query vector (required for "query")
      "ids"       : list[str]     — vector IDs to retrieve (for "fetch")
      "namespace" : str           — target namespace (optional, all intents)
      "filter"    : dict          — metadata filter dict (optional, for "query")
    """

    CONNECTOR_TYPE = ConnectorType.PINECONE

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._pc: Pinecone | None = None
        self._index = None          # pinecone.Index bound to the configured host

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    def _api_key(self) -> str:
        return self.config.extra.get("api_key", self.config.password) or "pclocal"

    def _index_host(self) -> str:
        """Build the full index host URL from host + port in ConnectionConfig."""
        scheme = "https" if self.config.ssl else "http"
        return f"{scheme}://{self.config.host}:{self.config.port}"

    def _index_label(self) -> str:
        """Human-readable label for audit logs and schema output."""
        return self.config.database or self._index_host()

    def _database_label(self) -> str:
        return self._index_host()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        api_key = self._api_key()
        index_host = self._index_host()

        def _create():
            pc = Pinecone(api_key=api_key)
            # Connect directly to the index — bypasses the control plane entirely
            index = pc.Index(host=index_host)
            # Verify connectivity
            index.describe_index_stats()
            return pc, index

        self._pc, self._index = await self._run(_create)
        self._connected = True

    async def disconnect(self) -> None:
        self._index = None
        self._pc = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._index:
            return False
        try:
            index = self._index

            def _check():
                index.describe_index_stats()
                return True

            return await self._run(_check)
        except Exception:
            return False

    # ── Schema discovery ──────────────────────────────────────────────────────

    async def discover_schema(self) -> SchemaMetadata:
        """
        Introspect the connected index via describe_index_stats():
        - Vector dimension and distance metric
        - Total vector count
        - Namespace breakdown
        """
        assert self._index is not None, "Not connected"
        index = self._index

        def _fetch():
            return index.describe_index_stats()

        stats = await self._run(_fetch)

        dimension = getattr(stats, "dimension", None)
        total_vectors = getattr(stats, "total_vector_count", 0) or 0
        namespaces = list(stats.namespaces.keys()) if stats.namespaces else []

        fields = [
            FieldSchema(
                name="id",
                data_type="str",
                is_primary=True,
                description="Vector ID",
            ),
            FieldSchema(
                name="vector",
                data_type=f"float[{dimension}]" if dimension else "float[]",
                description="Embedding vector",
            ),
            FieldSchema(
                name="metadata",
                data_type="dict",
                description="Arbitrary metadata attached to the vector",
            ),
        ]
        if namespaces:
            fields.append(FieldSchema(
                name="namespace",
                data_type="str",
                description=f"Namespaces: {', '.join(namespaces)}",
            ))

        table = TableSchema(
            name=self._index_label(),
            fields=fields,
            row_count_estimate=total_vectors,
            description=f"Pinecone index at {self._index_host()}",
        )

        return SchemaMetadata(
            connector_type=ConnectorType.PINECONE,
            database=self._database_label(),
            tables=[table],
        )

    # ── raw_query → intent/filters lift ───────────────────────────────────

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Lift intent + payload from raw_query JSON into query.filters."""
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query
        if not isinstance(parsed, dict):
            return query
        intent = (
            parsed.get("intent") or parsed.get("operation") or ""
        ).strip().lower().replace("_", "")
        if intent:
            query.intent = intent
        for key in ("vector", "vectors", "ids", "id", "filter",
                    "namespace", "metadata", "values", "set_metadata",
                    "deleteAll", "delete_all"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]
        return query

    # ── Validation ────────────────────────────────────────────────────────────

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """Validate the intent.

        Reads + DML (upsert/update/delete) flow through; RBAC owns
        per-index decisions. DDL (create_index/delete_index) stays
        hard-blocked at the connector regardless of policy.
        """
        intent = query.strip().lower().replace("_", "")
        ddl = {
            "createindex", "deleteindex", "configureindex",
            "createcollection", "deletecollection",
        }
        if intent in ddl and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=(
                    f"DDL intent '{intent}' is hard-blocked at the "
                    "connector regardless of policy."
                ),
            )
        return ValidationResult(is_valid=True)

    # ── Execution ─────────────────────────────────────────────────────────────

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a Pinecone operation on the connected index.

        IntermediateQuery fields used:
          - intent  : "query" | "fetch" | "list"
          - limit   : top_k / max IDs (capped at 1000)
          - filters : {
                "vector"    : list[float]  — query vector (for "query")
                "ids"       : list[str]    — vector IDs (for "fetch")
                "namespace" : str          — namespace (all intents, optional)
                "filter"    : dict         — metadata filter (for "query", optional)
            }

        Note: tables[] is accepted but ignored — the index is fixed at connection time.
        """
        assert self._index is not None, "Not connected"
        index = self._index

        # Lift raw_query → intent/filters before dispatching.
        query = self._parse_raw_query(query)

        database_label = self._database_label()
        intent = query.intent.strip().lower().replace("_", "")

        validation = await self.validate_query(intent, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.PINECONE,
                database=database_label,
                error=validation.error,
            )

        filters_cfg = query.filters or {}
        namespace = filters_cfg.get("namespace", "")
        effective_limit = min(query.limit, 1000)

        query_repr: dict[str, Any] = {
            "intent": intent,
            "index": self._index_label(),
            "namespace": namespace,
            "limit": effective_limit,
        }

        start = time.monotonic()
        rows: list[dict[str, Any]] = []

        try:
            if intent == "query":
                vector = filters_cfg.get("vector", [])
                metadata_filter = filters_cfg.get("filter")
                query_repr["vector_len"] = len(vector)

                def _query(v=vector, ns=namespace, lim=effective_limit, f=metadata_filter):
                    kwargs: dict[str, Any] = {
                        "vector": v,
                        "top_k": lim,
                        "include_metadata": True,
                        "include_values": False,
                    }
                    if ns:
                        kwargs["namespace"] = ns
                    if f:
                        kwargs["filter"] = f
                    return index.query(**kwargs)

                response = await self._run(_query)
                for match in response.matches:
                    row: dict[str, Any] = {"id": match.id, "_score": match.score}
                    if match.metadata:
                        row.update(match.metadata)
                    rows.append(row)

            elif intent == "fetch":
                ids = filters_cfg.get("ids", [])
                query_repr["ids"] = ids

                def _fetch(id_list=ids, ns=namespace):
                    kwargs: dict[str, Any] = {"ids": id_list}
                    if ns:
                        kwargs["namespace"] = ns
                    return index.fetch(**kwargs)

                response = await self._run(_fetch)
                for vid, vec_data in (response.vectors or {}).items():
                    row = {"id": vid}
                    if vec_data.metadata:
                        row.update(vec_data.metadata)
                    rows.append(row)

            elif intent == "list":
                def _list(ns=namespace, lim=effective_limit):
                    ids: list[str] = []
                    kwargs: dict[str, Any] = {"limit": min(lim, 100)}
                    if ns:
                        kwargs["namespace"] = ns
                    for page in index.list(**kwargs):
                        if isinstance(page, list):
                            ids.extend(page)
                        else:
                            ids.append(page)
                        if len(ids) >= lim:
                            break
                    return ids[:lim]

                id_list = await self._run(_list)
                rows = [{"id": vid} for vid in id_list]

            elif intent in ("upsert", "insert", "insertone", "insertmany"):
                # vectors: list of {id, values, metadata}
                vectors = filters_cfg.get("vectors") or filters_cfg.get("vector") or []
                if not isinstance(vectors, list):
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.PINECONE, database=database_label,
                        error="upsert requires `vectors` as a JSON array of {id, values, metadata}",
                        execution_time_ms=elapsed_ms,
                    )
                def _upsert(vs=vectors, ns=namespace):
                    kwargs: dict[str, Any] = {"vectors": vs}
                    if ns:
                        kwargs["namespace"] = ns
                    return index.upsert(**kwargs)
                resp = await self._run(_upsert)
                rows = [{
                    "operation": "upsert",
                    "upserted_count": getattr(resp, "upserted_count", len(vectors)),
                    "namespace": namespace,
                }]

            elif intent in ("update", "updateone"):
                vid = filters_cfg.get("id")
                if not vid:
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.PINECONE, database=database_label,
                        error="update requires `id`",
                        execution_time_ms=elapsed_ms,
                    )
                values = filters_cfg.get("values")
                set_meta = filters_cfg.get("set_metadata") or filters_cfg.get("metadata")
                def _update(i=vid, v=values, m=set_meta, ns=namespace):
                    kwargs: dict[str, Any] = {"id": i}
                    if v is not None:
                        kwargs["values"] = v
                    if m is not None:
                        kwargs["set_metadata"] = m
                    if ns:
                        kwargs["namespace"] = ns
                    return index.update(**kwargs)
                await self._run(_update)
                rows = [{"operation": "update", "id": vid, "namespace": namespace}]

            elif intent in ("delete", "deleteone", "deletemany"):
                ids = filters_cfg.get("ids")
                metadata_filter = filters_cfg.get("filter")
                delete_all = bool(
                    filters_cfg.get("deleteAll") or filters_cfg.get("delete_all")
                )
                if delete_all and not ids and not metadata_filter:
                    # Defense in depth — empty-filter delete is unintended DDL.
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.PINECONE, database=database_label,
                        error="deleteAll without an explicit filter is refused as unintended DDL",
                        execution_time_ms=elapsed_ms,
                    )
                if not ids and not metadata_filter and not delete_all:
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.PINECONE, database=database_label,
                        error="delete requires either `ids` or a metadata `filter`",
                        execution_time_ms=elapsed_ms,
                    )
                def _delete(id_list=ids, f=metadata_filter, all_=delete_all, ns=namespace):
                    kwargs: dict[str, Any] = {}
                    if id_list:
                        kwargs["ids"] = id_list
                    if f:
                        kwargs["filter"] = f
                    if all_:
                        kwargs["delete_all"] = True
                    if ns:
                        kwargs["namespace"] = ns
                    return index.delete(**kwargs)
                await self._run(_delete)
                rows = [{
                    "operation": "delete",
                    "ids": ids if ids else None,
                    "filter": metadata_filter if metadata_filter else None,
                    "delete_all": delete_all,
                    "namespace": namespace,
                }]

            elif intent in ("deleteindex", "deletecollection"):
                # DDL: delete the index (requires access: A).
                # Caller passes the index name via filters["name"] or the table field.
                idx_name = str(
                    filters_cfg.get("name") or filters_cfg.get("index")
                    or (query.tables[0] if query.tables else self._index_label())
                )
                await self._run(lambda: self._pc.delete_index(idx_name))
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"index": idx_name, "result": "deleted"}]

            elif intent in ("createindex", "createcollection"):
                # DDL: create an index (requires access: A).
                # Caller must supply dimension and metric via filters.
                from pinecone import ServerlessSpec
                idx_name = str(
                    filters_cfg.get("name") or filters_cfg.get("index")
                    or (query.tables[0] if query.tables else "")
                )
                dimension = int(filters_cfg.get("dimension") or filters_cfg.get("dim") or 1536)
                metric = str(filters_cfg.get("metric") or "cosine")
                cloud = str(filters_cfg.get("cloud") or "aws")
                region = str(filters_cfg.get("region") or "us-east-1")
                await self._run(lambda: self._pc.create_index(
                    name=idx_name,
                    dimension=dimension,
                    metric=metric,
                    spec=ServerlessSpec(cloud=cloud, region=region),
                ))
                elapsed_ms = (time.monotonic() - start) * 1000
                rows = [{"index": idx_name, "dimension": dimension, "metric": metric}]

            else:
                elapsed_ms = (time.monotonic() - start) * 1000
                return QueryResult(
                    connector_type=ConnectorType.PINECONE,
                    database=database_label,
                    error=f"Unsupported intent: {intent}",
                    execution_time_ms=elapsed_ms,
                )

            elapsed_ms = (time.monotonic() - start) * 1000
            columns = list(rows[0].keys()) if rows else []

            return QueryResult(
                connector_type=ConnectorType.PINECONE,
                database=database_label,
                rows=rows,
                columns=columns,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=json.dumps(query_repr),
            )

        except Exception as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.PINECONE,
                database=database_label,
                error=str(exc),
                execution_time_ms=elapsed_ms,
                query_executed=json.dumps(query_repr),
            )
