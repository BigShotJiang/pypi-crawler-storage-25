"""
PostgreSQL connector for faz.

Uses the synchronous psycopg2 driver wrapped with run_in_executor to avoid
"Future attached to a different loop" errors when the pool is shared across
pytest-asyncio module-scoped fixtures.

Schema discovery via information_schema.
Read-only enforcement via sqlparse AST analysis.
"""

import asyncio
import time

import psycopg2
import psycopg2.pool
import psycopg2.extras
import sqlparse
from sqlparse.sql import Statement
from sqlparse.tokens import Keyword, DDL, DML

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldDistribution,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    Relationship,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# DML operations that modify data — blocked in READ_ONLY mode
_BLOCKED_DML = {"INSERT", "UPDATE", "DELETE", "MERGE", "UPSERT"}

# DDL operations — always blocked regardless of access mode
_BLOCKED_DDL = {"CREATE", "DROP", "ALTER", "TRUNCATE", "RENAME", "COMMENT"}


def _classify_statement(sql: str) -> tuple[str, str]:
    """
    Returns (statement_type, first_keyword) for a SQL string.
    Uses sqlparse token classification.
    """
    parsed = sqlparse.parse(sql.strip())
    if not parsed:
        return ("UNKNOWN", "")

    stmt: Statement = parsed[0]
    for token in stmt.tokens:
        if token.ttype in (DML, DDL, Keyword):
            return (token.ttype.__class__.__name__, token.normalized.upper())
        if token.ttype is not None and token.ttype is not sqlparse.tokens.Whitespace:
            return ("OTHER", token.normalized.upper())
    return ("UNKNOWN", "")


class PostgreSQLConnector(BaseConnector):
    """
    Async-compatible PostgreSQL connector using the synchronous psycopg2 driver
    via run_in_executor.

    Supports:
    - Schema discovery across all user tables
    - Read-only enforcement (blocks DML/DDL when access_mode=READ_ONLY)
    - Query execution with row limits
    - Audit-ready: returns the exact executed query in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.POSTGRESQL

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._pool: psycopg2.pool.ThreadedConnectionPool | None = None

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    def _conn_kwargs(self) -> dict:
        kwargs = dict(
            host=self.config.host,
            port=self.config.port,
            dbname=self.config.database,
            user=self.config.username,
            password=self.config.password,
        )
        if self.config.ssl:
            kwargs["sslmode"] = "require"
        return kwargs

    async def connect(self) -> None:
        kwargs = self._conn_kwargs()

        def _create_pool():
            pool = psycopg2.pool.ThreadedConnectionPool(2, 10, **kwargs)
            # Verify connectivity
            conn = pool.getconn()
            try:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1")
            finally:
                pool.putconn(conn)
            return pool

        self._pool = await self._run(_create_pool)
        self._connected = True

    async def disconnect(self) -> None:
        if self._pool:
            pool = self._pool
            await self._run(pool.closeall)
            self._pool = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._pool:
            return False
        try:
            pool = self._pool

            def _check():
                conn = pool.getconn()
                try:
                    with conn.cursor() as cur:
                        cur.execute("SELECT 1")
                        return cur.fetchone() is not None
                finally:
                    pool.putconn(conn)

            return await self._run(_check)
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        Introspect all user tables in the target database via information_schema.
        Captures: columns, types, PKs, foreign keys, relationships, and column distributions.
        """
        assert self._pool, "Not connected"

        schema_query = """
            SELECT
                c.table_name,
                c.column_name,
                c.data_type,
                c.is_nullable,
                CASE WHEN kcu.column_name IS NOT NULL THEN TRUE ELSE FALSE END AS is_primary
            FROM information_schema.columns c
            LEFT JOIN information_schema.key_column_usage kcu
                ON c.table_name = kcu.table_name
                AND c.column_name = kcu.column_name
                AND kcu.constraint_name IN (
                    SELECT constraint_name
                    FROM information_schema.table_constraints
                    WHERE constraint_type = 'PRIMARY KEY'
                    AND table_schema = 'public'
                )
            WHERE c.table_schema = 'public'
            ORDER BY c.table_name, c.ordinal_position
        """

        row_count_query = """
            SELECT relname AS table_name, reltuples::bigint AS row_estimate
            FROM pg_class
            JOIN pg_namespace ON pg_namespace.oid = pg_class.relnamespace
            WHERE nspname = 'public' AND relkind = 'r'
        """

        fk_query = """
            SELECT
                tc.table_name       AS from_table,
                kcu.column_name     AS from_column,
                ccu.table_name      AS to_table,
                ccu.column_name     AS to_column
            FROM information_schema.table_constraints tc
            JOIN information_schema.key_column_usage kcu
                ON tc.constraint_name = kcu.constraint_name
                AND tc.table_schema = kcu.table_schema
            JOIN information_schema.constraint_column_usage ccu
                ON tc.constraint_name = ccu.constraint_name
                AND tc.table_schema = ccu.table_schema
            WHERE tc.constraint_type = 'FOREIGN KEY'
                AND tc.table_schema = 'public'
        """

        stats_query = """
            SELECT
                s.tablename         AS table_name,
                s.attname           AS column_name,
                s.n_distinct        AS n_distinct,
                s.null_frac         AS null_frac,
                s.most_common_vals  AS most_common_vals
            FROM pg_stats s
            WHERE s.schemaname = 'public'
        """

        pool = self._pool

        def _fetch():
            conn = pool.getconn()
            try:
                with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                    cur.execute(schema_query)
                    col_rows = cur.fetchall()
                    cur.execute(row_count_query)
                    count_rows = cur.fetchall()
                    cur.execute(fk_query)
                    fk_rows = cur.fetchall()
                    cur.execute(stats_query)
                    stat_rows = cur.fetchall()
                return col_rows, count_rows, fk_rows, stat_rows
            finally:
                pool.putconn(conn)

        col_rows, count_rows, fk_rows, stat_rows = await self._run(_fetch)

        # Build FK lookup: (table, column) -> True
        fk_columns: set[tuple[str, str]] = set()
        relationships: list[Relationship] = []
        for fk in fk_rows:
            fk_columns.add((fk["from_table"], fk["from_column"]))
            relationships.append(Relationship(
                from_table=fk["from_table"],
                from_field=fk["from_column"],
                to_table=fk["to_table"],
                to_field=fk["to_column"],
                rel_type="fk",
            ))

        # Build stats lookup: (table, column) -> FieldDistribution
        stats_map: dict[tuple[str, str], FieldDistribution] = {}
        for st in stat_rows:
            n_dist = st["n_distinct"]
            # pg_stats: n_distinct > 0 = actual count, < 0 = fraction of rows
            distinct = int(abs(n_dist)) if n_dist and n_dist > 0 else 0
            samples = []
            if st["most_common_vals"]:
                raw = str(st["most_common_vals"])
                # pg returns e.g. "{val1,val2,val3}"
                raw = raw.strip("{}")
                samples = [v.strip() for v in raw.split(",")][:5]
            stats_map[(st["table_name"], st["column_name"])] = FieldDistribution(
                distinct_count=distinct,
                null_fraction=float(st["null_frac"] or 0),
                sample_values=samples,
            )

        row_estimates = {r["table_name"]: r["row_estimate"] for r in count_rows}
        tables: dict[str, TableSchema] = {}
        for row in col_rows:
            tname = row["table_name"]
            if tname not in tables:
                tables[tname] = TableSchema(
                    name=tname,
                    row_count_estimate=row_estimates.get(tname, 0),
                )
            col_name = row["column_name"]
            tables[tname].fields.append(
                FieldSchema(
                    name=col_name,
                    data_type=row["data_type"],
                    nullable=row["is_nullable"] == "YES",
                    is_primary=row["is_primary"],
                    is_foreign_key=(tname, col_name) in fk_columns,
                    distribution=stats_map.get((tname, col_name)),
                )
            )

        return SchemaMetadata(
            connector_type=ConnectorType.POSTGRESQL,
            database=self.config.database,
            tables=list(tables.values()),
            relationships=relationships,
        )

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """
        Block write/DDL operations based on access mode.
        DDL is blocked unless ``allow_ddl=True`` (set when the faz safety
        pipeline pre-approved it via AccessMode.A). Blocks DML when
        access_mode is READ_ONLY. Uses sqlparse token classification.
        """
        sql = query.strip()
        if not sql:
            return ValidationResult(is_valid=False, error="Empty query")

        # Split multi-statement queries — block if more than one statement
        statements = [s for s in sqlparse.parse(sql) if s.get_type() is not None or str(s).strip()]
        if len(statements) > 1:
            return ValidationResult(
                is_valid=False,
                blocked_reason="Multi-statement queries are not permitted",
            )

        stmt_type = statements[0].get_type()
        first_keyword = (stmt_type or "").upper()

        if first_keyword in _BLOCKED_DDL and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=f"DDL operation '{first_keyword}' is not permitted",
            )

        # DML (INSERT/UPDATE/DELETE/MERGE/UPSERT) flows through. The faz
        # safety pipeline (RBAC_GATE) decides whether the policy permits
        # writes to this specific table; the connector trusts that and
        # executes whatever was passed in.
        return ValidationResult(is_valid=True)

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Validate and execute the query. Applies row limit guardrail.
        Returns column names, rows, and the exact SQL executed for audit logging.
        """
        assert self._pool, "Not connected"

        sql = query.raw_query.strip()
        # Row-cap injection is handled upstream by Guardrails using
        # ``policy.safety.max_rows_per_query`` (it injects LIMIT only on
        # SELECTs, so writes pass through untouched). The connector
        # neither hardcodes a value nor mangles INSERT/UPDATE/DELETE.

        validation = await self.validate_query(sql, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.POSTGRESQL,
                database=self.config.database,
                error=validation.blocked_reason or validation.error,
                query_executed=sql,
            )

        pool = self._pool
        start = time.monotonic()
        try:
            def _execute(q=sql):
                conn = pool.getconn()
                try:
                    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                        cur.execute(q)
                        # SELECT/RETURNING-style statements have a description.
                        # Plain INSERT/UPDATE/DELETE return None — fetchall()
                        # would raise. Commit and return affected-row count.
                        if cur.description is None:
                            affected = cur.rowcount
                            conn.commit()
                            return ("rowcount", affected, None)
                        rows = cur.fetchall()
                        columns = [desc[0] for desc in cur.description]
                        # SELECTs in a transaction need committing too in
                        # case the user wraps in a CTE that performs writes
                        # via INSERT ... RETURNING.
                        conn.commit()
                        return ("rows", rows, columns)
                finally:
                    pool.putconn(conn)

            kind, payload, columns = await self._run(_execute)
            elapsed_ms = (time.monotonic() - start) * 1000

            if kind == "rows":
                result_rows = [dict(row) for row in payload]
            else:
                columns = ["rows_affected"]
                result_rows = [{"rows_affected": payload}]

            return QueryResult(
                connector_type=ConnectorType.POSTGRESQL,
                database=self.config.database,
                columns=columns,
                rows=result_rows,
                total_count=len(result_rows),
                execution_time_ms=elapsed_ms,
                query_executed=sql,
            )

        except Exception as e:
            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.POSTGRESQL,
                database=self.config.database,
                error=str(e),
                execution_time_ms=elapsed_ms,
                query_executed=sql,
            )
