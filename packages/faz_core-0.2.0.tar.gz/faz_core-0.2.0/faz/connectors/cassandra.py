"""
Cassandra connector for faz.

Uses cassandra-driver (synchronous) wrapped with run_in_executor for async compatibility.
Schema discovery via system_schema keyspace.
Read-only enforcement via first-keyword CQL parsing.
"""

import asyncio
import json
import time
from typing import Any

from cassandra.cluster import Cluster
from cassandra.policies import WhiteListRoundRobinPolicy

# cassandra-driver's default reactor (AsyncoreConnection) needs stdlib
# ``asyncore``, which was removed in Python 3.12. AsyncioConnection is the
# pure-Python alternative shipped with the driver — no extra deps, works on
# Linux/macOS/Windows and Python 3.10–3.13+.
from cassandra.io.asyncioreactor import AsyncioConnection

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# CQL keywords blocked in READ_ONLY mode (writes)
_BLOCKED_WRITE = {"INSERT", "UPDATE", "DELETE"}

# DDL keywords — always blocked
_BLOCKED_DDL = {"DROP", "ALTER", "TRUNCATE", "CREATE"}

# Allowed statement starts in READ_ONLY mode
_ALLOWED_READ = {"SELECT", "CALL", "DESCRIBE"}

# System keyspaces to exclude from schema discovery
_SYSTEM_KEYSPACES = {
    "system",
    "system_auth",
    "system_distributed",
    "system_traces",
    "system_schema",
}


class CassandraConnector(BaseConnector):
    """
    Async-compatible Cassandra connector using cassandra-driver (sync) via run_in_executor.

    Supports:
    - Schema discovery across user keyspaces via system_schema
    - Read-only enforcement (blocks DML/DDL when access_mode=READ_ONLY)
    - CQL execution with LIMIT guardrail
    - Audit-ready: returns the exact executed CQL in QueryResult
    """

    CONNECTOR_TYPE = ConnectorType.CASSANDRA

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._cluster: Cluster | None = None
        self._session: Any = None

    async def connect(self) -> None:
        loop = asyncio.get_event_loop()

        def _connect():
            # Pin to the configured contact point only — skip peer discovery so
            # Docker/NAT broadcast addresses (e.g. 172.18.0.x) don't get tried.
            cluster = Cluster(
                [self.config.host],
                port=self.config.port,
                connection_class=AsyncioConnection,
                load_balancing_policy=WhiteListRoundRobinPolicy([self.config.host]),
            )
            session = cluster.connect()
            return cluster, session

        self._cluster, self._session = await loop.run_in_executor(None, _connect)
        self._connected = True

    async def disconnect(self) -> None:
        loop = asyncio.get_event_loop()

        def _disconnect():
            if self._session:
                self._session.shutdown()
            if self._cluster:
                self._cluster.shutdown()

        await loop.run_in_executor(None, _disconnect)
        self._session = None
        self._cluster = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._session:
            return False
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None,
                lambda: self._session.execute("SELECT now() FROM system.local"),
            )
            return True
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        assert self._session, "Not connected"
        loop = asyncio.get_event_loop()

        def _fetch_keyspaces():
            rows = self._session.execute("SELECT keyspace_name FROM system_schema.keyspaces")
            return [r.keyspace_name for r in rows if r.keyspace_name not in _SYSTEM_KEYSPACES]

        keyspaces = await loop.run_in_executor(None, _fetch_keyspaces)

        tables: list[TableSchema] = []

        for ks in keyspaces:
            def _fetch_tables(keyspace=ks):
                stmt = self._session.prepare(
                    "SELECT table_name FROM system_schema.tables WHERE keyspace_name=?"
                )
                return self._session.execute(stmt, [keyspace])

            table_rows = await loop.run_in_executor(None, _fetch_tables)

            for table_row in table_rows:
                table_name = table_row.table_name

                def _fetch_columns(keyspace=ks, tname=table_name):
                    stmt = self._session.prepare(
                        "SELECT column_name, type, kind "
                        "FROM system_schema.columns "
                        "WHERE keyspace_name=? AND table_name=?"
                    )
                    return list(self._session.execute(stmt, [keyspace, tname]))

                col_rows = await loop.run_in_executor(None, _fetch_columns)

                fields = []
                for col in col_rows:
                    desc = ""
                    if col.kind == "partition_key":
                        desc = "partition_key"
                    elif col.kind == "clustering":
                        desc = "clustering_key"
                    fields.append(
                        FieldSchema(
                            name=col.column_name,
                            data_type=col.type,
                            nullable=col.kind not in ("partition_key", "clustering"),
                            is_primary=col.kind == "partition_key",
                            description=desc,
                        )
                    )

                # Estimate row count
                def _count(keyspace=ks, tname=table_name):
                    try:
                        rows = self._session.execute(
                            f"SELECT COUNT(*) AS cnt FROM {keyspace}.{tname} LIMIT 10000"
                        )
                        return rows.one().cnt if rows else 0
                    except Exception:
                        return 0

                row_count = await loop.run_in_executor(None, _count)

                tables.append(
                    TableSchema(
                        name=f"{ks}.{table_name}",
                        fields=fields,
                        row_count_estimate=row_count,
                    )
                )

        database = keyspaces[0] if keyspaces else self.config.host

        return SchemaMetadata(
            connector_type=ConnectorType.CASSANDRA,
            database=database,
            tables=tables,
        )

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        cql = query.strip()
        if not cql:
            return ValidationResult(is_valid=False, error="Empty query")

        # Block multi-statement queries
        parts = [p.strip() for p in cql.split(";") if p.strip()]
        if len(parts) > 1:
            return ValidationResult(
                is_valid=False,
                blocked_reason="Multi-statement queries are not permitted",
            )

        first_word = parts[0].split()[0].upper() if parts else ""

        if first_word in _BLOCKED_DDL and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=f"DDL operation '{first_word}' is not permitted",
            )

        # DML (INSERT/UPDATE/DELETE) and other CQL keywords flow through —
        # RBAC owns per-table write decisions.
        return ValidationResult(is_valid=True)

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        assert self._session, "Not connected"
        loop = asyncio.get_event_loop()

        cql = query.raw_query.strip()
        # LIMIT injection is handled upstream by Guardrails (SELECTs only,
        # row cap from ``policy.safety.max_rows_per_query``). CQL writes
        # (INSERT/UPDATE/DELETE/BATCH) pass through untouched, and pure
        # writes never get a malformed ``LIMIT`` appended.

        validation = await self.validate_query(cql, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.CASSANDRA,
                database=self.config.database or self.config.host,
                error=validation.blocked_reason or validation.error,
                query_executed=cql,
            )

        start = time.monotonic()
        try:
            def _execute():
                return list(self._session.execute(cql))

            rows = await loop.run_in_executor(None, _execute)
            elapsed_ms = (time.monotonic() - start) * 1000

            if not rows:
                return QueryResult(
                    connector_type=ConnectorType.CASSANDRA,
                    database=self.config.database or self.config.host,
                    columns=[],
                    rows=[],
                    total_count=0,
                    execution_time_ms=elapsed_ms,
                    query_executed=cql,
                )

            # cassandra-driver rows are named tuples — convert via _asdict()
            first = rows[0]
            if hasattr(first, "_asdict"):
                result_rows = [dict(r._asdict()) for r in rows]
            elif hasattr(first, "_fields"):
                columns = list(first._fields)
                result_rows = [dict(zip(columns, r)) for r in rows]
            else:
                result_rows = [dict(r) for r in rows]

            # Coerce cassandra-specific value types (Date, Time, UUID, Decimal,
            # InetAddress, …) to JSON-serialisable forms. Without this,
            # FastAPI/Pydantic raises PydanticSerializationError on the
            # response and the caller sees a bare 500 "Internal Server Error".
            # ``default=str`` in json.dumps is the universal fallback —
            # cassandra-driver's wrapper types all have sane ``__str__``
            # (Date → "2025-01-15", UUID → canonical form, Decimal → "12.34").
            result_rows = json.loads(json.dumps(result_rows, default=str))

            columns = list(result_rows[0].keys()) if result_rows else []

            return QueryResult(
                connector_type=ConnectorType.CASSANDRA,
                database=self.config.database or self.config.host,
                columns=columns,
                rows=result_rows,
                total_count=len(result_rows),
                execution_time_ms=elapsed_ms,
                query_executed=cql,
            )

        except Exception as e:
            return QueryResult(
                connector_type=ConnectorType.CASSANDRA,
                database=self.config.database or self.config.host,
                error=str(e),
                query_executed=cql,
            )
