"""
DynamoDB connector for faz.

Uses synchronous boto3 (not aioboto3). The public methods stay ``async def``
because :class:`BaseConnector` requires it and the surrounding pipeline
``await``s them — every blocking boto3 call is wrapped in
:func:`asyncio.to_thread` so it runs on a worker thread and the event loop
stays free.

Supports local DynamoDB endpoint (for development) and AWS-hosted.
Schema discovery via ListTables + DescribeTable + item sampling.
Read-only enforcement via operation whitelist.
"""

import asyncio
import base64
import json
import time
from collections import defaultdict
from decimal import Decimal
from typing import Any

import boto3
from botocore.exceptions import ClientError

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# Read-only DynamoDB operations
_ALLOWED_READ_OPERATIONS = {"query", "scan", "get_item", "batch_get_item", "describe_table"}

# Write operations — always blocked in READ_ONLY mode
_BLOCKED_WRITE_OPERATIONS = {
    "put_item", "update_item", "delete_item",
    "batch_write_item", "transact_write_items",
    "create_table", "delete_table", "update_table",
}

_SAMPLE_SIZE = 50  # items to scan per table for schema inference


def _infer_type(value: Any) -> str:
    """Map a DynamoDB Python value to a readable type string."""
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, Decimal):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, (list, set)):
        return "list"
    if isinstance(value, dict):
        return "map"
    if value is None:
        return "null"
    return type(value).__name__


def _to_jsonable(value: Any) -> Any:
    """Recursively convert a DynamoDB-deserialised value to a json.dumps-safe equivalent.

    DynamoDB's TypeDeserializer hands us:
      - ``Decimal`` for numbers (json can't serialise Decimal)
      - ``bytes`` for binary scalars (json can't serialise bytes)
      - ``set`` for SS / NS / BS (json can't serialise set)
      - nested ``dict`` / ``list`` for Maps and Lists (which can themselves
        contain any of the above at any depth)

    Conversion rules:
      - ``Decimal`` → int (whole-numbered, preserves arbitrary precision)
                  → float (otherwise; loses precision for very long decimals,
                    but that's the standard JSON tradeoff)
      - ``bytes`` → base64-encoded ASCII string
      - ``set``  → list of recursively-converted values
      - ``dict`` → dict with values recursively converted
      - ``list`` / ``tuple`` → list with values recursively converted
      - everything else (str, int, float, bool, None) is returned as-is
    """
    # bool BEFORE Decimal/int — bool is a subclass of int, would otherwise be coerced.
    if isinstance(value, bool):
        return value
    if isinstance(value, Decimal):
        return int(value) if value == int(value) else float(value)
    if isinstance(value, bytes):
        return base64.b64encode(value).decode("ascii")
    if isinstance(value, dict):
        return {k: _to_jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_jsonable(item) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_to_jsonable(item) for item in value]
    return value


def _serialise_item(item: dict) -> dict:
    """Convert a deserialised DynamoDB item into a json.dumps-safe dict."""
    return {k: _to_jsonable(v) for k, v in item.items()}


class DynamoDBConnector(BaseConnector):
    """
    DynamoDB connector backed by synchronous boto3.

    Supports:
    - Local DynamoDB endpoint (development) via config.extra["endpoint_url"]
    - AWS-hosted DynamoDB via standard boto3 credential chain
    - Schema discovery: key schema from DescribeTable + attribute inference from Scan sampling
    - Read-only enforcement: only Query, Scan, GetItem, BatchGetItem permitted
    - PartiQL query execution via execute_statement

    IntermediateQuery.intent values:
      - "query"     : DynamoDB Query operation (key-based)
      - "scan"      : Full table scan with optional filter
      - "get_item"  : Single item lookup by primary key
      - "partiql"   : PartiQL SELECT statement (raw_query field)
    """

    CONNECTOR_TYPE = ConnectorType.DYNAMODB

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: Any = None
        self._endpoint_url: str | None = config.extra.get("endpoint_url")
        self._region: str = config.extra.get("region", "us-east-1")

    def _client_kwargs(self) -> dict:
        kwargs: dict[str, Any] = {"region_name": self._region}
        if self._endpoint_url:
            kwargs["endpoint_url"] = self._endpoint_url
        if self.config.username:
            kwargs["aws_access_key_id"] = self.config.username
        if self.config.password:
            kwargs["aws_secret_access_key"] = self.config.password
        return kwargs

    def _new_client(self):
        return boto3.client("dynamodb", **self._client_kwargs())

    async def connect(self) -> None:
        # boto3.client is not trivially cheap (it parses service descriptors),
        # so build it once in a worker thread and reuse it for the connector's
        # lifetime. Verify with a lightweight ListTables call.
        self._client = await asyncio.to_thread(self._new_client)
        await asyncio.to_thread(self._client.list_tables, Limit=1)
        self._connected = True

    async def disconnect(self) -> None:
        # boto3 clients hold no persistent connections that need closing.
        self._client = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            await asyncio.to_thread(self._client.list_tables, Limit=1)
            return True
        except Exception:
            return False

    async def discover_schema(self) -> SchemaMetadata:
        """
        1. ListTables → get all table names
        2. DescribeTable → get key schema and GSIs
        3. Scan (sample) → infer non-key attribute types from actual items
        """
        assert self._client is not None, "Not connected"

        from boto3.dynamodb.types import TypeDeserializer
        deserialiser = TypeDeserializer()

        # Run the whole discovery pass in a single worker thread — it's a
        # tight loop of blocking calls, so context-switching per call would
        # waste more than it gains.
        def _discover() -> list[TableSchema]:
            client = self._client
            tables: list[TableSchema] = []

            paginator = client.get_paginator("list_tables")
            table_names: list[str] = []
            for page in paginator.paginate():
                table_names.extend(page["TableNames"])

            dynamo_type_map = {"S": "string", "N": "number", "B": "binary"}

            for table_name in table_names:
                desc = client.describe_table(TableName=table_name)
                table_desc = desc["Table"]
                item_count = table_desc.get("ItemCount", 0)

                attr_types = {a["AttributeName"]: a["AttributeType"]
                              for a in table_desc.get("AttributeDefinitions", [])}

                key_fields: dict[str, FieldSchema] = {}
                for key in table_desc.get("KeySchema", []):
                    attr_name = key["AttributeName"]
                    key_type = key["KeyType"]  # HASH or RANGE
                    data_type = dynamo_type_map.get(attr_types.get(attr_name, "S"), "string")
                    key_fields[attr_name] = FieldSchema(
                        name=attr_name,
                        data_type=f"{data_type} [{key_type} KEY]",
                        is_primary=(key_type == "HASH"),
                    )

                try:
                    sample_resp = client.scan(TableName=table_name, Limit=_SAMPLE_SIZE)
                    sample_items = sample_resp.get("Items", [])
                except ClientError:
                    sample_items = []

                inferred_types: dict[str, set[str]] = defaultdict(set)
                for item in sample_items:
                    plain_item = {k: deserialiser.deserialize(v) for k, v in item.items()}
                    for attr, value in plain_item.items():
                        inferred_types[attr].add(_infer_type(value))

                all_fields: list[FieldSchema] = list(key_fields.values())
                for attr_name, types in sorted(inferred_types.items()):
                    if attr_name not in key_fields:
                        all_fields.append(FieldSchema(
                            name=attr_name,
                            data_type=" | ".join(sorted(types)),
                        ))

                tables.append(TableSchema(
                    name=table_name,
                    fields=all_fields,
                    row_count_estimate=item_count,
                ))
            return tables

        tables = await asyncio.to_thread(_discover)

        return SchemaMetadata(
            connector_type=ConnectorType.DYNAMODB,
            database=self._endpoint_url or "aws-dynamodb",
            tables=tables,
        )

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """Validate operation name.

        DML (PutItem / UpdateItem / DeleteItem / BatchWriteItem /
        TransactWriteItems / PartiQL writes) flows through — RBAC owns
        per-table decisions. The connector hard-blocks DDL: CreateTable,
        DeleteTable, UpdateTable, backups / global-index management.
        """
        operation = query.strip().lower().replace("_", "")
        ddl_ops = {
            "createtable", "deletetable", "updatetable",
            "createbackup", "deletebackup", "restoretablefrombackup",
            "createglobalsecondaryindex", "deleteglobalsecondaryindex",
        }
        if operation in ddl_ops and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=(
                    f"DDL operation '{operation}' is hard-blocked at the "
                    "connector regardless of policy."
                ),
            )
        return ValidationResult(is_valid=True)

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Lift verb + payload from raw_query JSON.

        Agents send ``{"verb": "PutItem", "TableName": "...", "Item":
        {...}}`` (or ``"Operation"`` synonym); we override
        ``query.intent`` from the verb and stash the rest into
        ``query.filters`` for ``execute()`` to read back.
        """
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query
        if not isinstance(parsed, dict):
            return query

        verb = (parsed.get("verb") or parsed.get("Operation") or "").strip().lower().replace("_", "")
        if verb:
            query.intent = verb

        for key in ("TableName", "Key", "Item", "Items",
                    "KeyConditionExpression", "FilterExpression",
                    "UpdateExpression", "ConditionExpression",
                    "ExpressionAttributeValues", "ExpressionAttributeNames",
                    "ProjectionExpression", "ReturnValues",
                    "Statement", "TransactItems", "TransactStatements",
                    "RequestItems",
                    # CreateTable / UpdateTable DDL params — must be forwarded
                    # to the SDK or AWS rejects the call with "Missing required
                    # parameter". Previously absent, causing silent data loss.
                    "KeySchema", "AttributeDefinitions", "BillingMode",
                    "ProvisionedThroughput", "GlobalSecondaryIndexes",
                    "LocalSecondaryIndexes", "StreamSpecification",
                    "SSESpecification", "Tags", "TableClass",
                    "DeletionProtectionEnabled"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]
        return query

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a DynamoDB operation.

        IntermediateQuery fields used:
          - intent:       "query" | "scan" | "get_item" | "partiql"
          - tables:       [table_name]
          - raw_query:    PartiQL SELECT string (for intent="partiql")
          - filters:      operation-specific params (see below)
          - limit:        max items

        filters dict per intent:
          query:    {"KeyConditionExpression": "pk = :v", "ExpressionAttributeValues": {":v": {"S": "val"}}}
          scan:     {"FilterExpression": "attr = :v", "ExpressionAttributeValues": {":v": {"S": "val"}}}
          get_item: {"Key": {"pk": {"S": "val"}}}
          partiql:  (no filters needed — use raw_query)
        """
        assert self._client is not None, "Not connected"

        # Lift verb + payload from raw_query before dispatching.
        query = self._parse_raw_query(query)

        intent = query.intent.lower().replace("_", "")
        validation = await self.validate_query(intent, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.DYNAMODB,
                database=self._endpoint_url or "aws-dynamodb",
                error=validation.blocked_reason or validation.error,
            )

        if not query.tables and intent != "partiql":
            return QueryResult(
                connector_type=ConnectorType.DYNAMODB,
                database=self._endpoint_url or "aws-dynamodb",
                error="No table specified",
            )

        table_name = query.tables[0] if query.tables else ""
        limit = min(query.limit, 1000)
        from boto3.dynamodb.types import TypeDeserializer
        deserialiser = TypeDeserializer()

        client = self._client

        # Boto3-call params come from the parsed raw_query (extracted into
        # query.filters by _parse_raw_query). The same ``filters`` dict is
        # what the legacy IntermediateQuery API used, so existing callers
        # that populate filters directly still work.
        f = dict(query.filters)
        f.pop("TableName", None)  # we use table_name as the canonical source
        # Drop the audit-only key the executor stuffs in.
        f.pop("_description", None)

        if intent == "partiql" or intent == "executestatement":
            stmt = query.filters.get("Statement") or query.raw_query
            def _call():
                return client.execute_statement(Statement=stmt, Limit=limit)
            query_repr = stmt

        elif intent == "executetransaction":
            stmts = query.filters.get("TransactStatements") or []
            def _call():
                return client.execute_transaction(TransactStatements=stmts)
            query_repr = f"ExecuteTransaction({len(stmts)} stmts)"

        elif intent == "query":
            params = {"TableName": table_name, **f}
            params.setdefault("Limit", limit)
            def _call():
                return client.query(**params)
            query_repr = f"Query({table_name}, {json.dumps(f)})"

        elif intent == "scan":
            params = {"TableName": table_name, **f}
            params.setdefault("Limit", limit)
            def _call():
                return client.scan(**params)
            query_repr = f"Scan({table_name}, {json.dumps(f)})"

        elif intent in ("getitem",):
            def _call():
                return client.get_item(TableName=table_name, **f)
            query_repr = f"GetItem({table_name}, {json.dumps(f)})"

        elif intent in ("batchgetitem",):
            def _call():
                return client.batch_get_item(**f)
            query_repr = f"BatchGetItem({json.dumps(f)})"

        elif intent in ("putitem",):
            def _call():
                return client.put_item(TableName=table_name, **f)
            query_repr = f"PutItem({table_name}, {json.dumps(f)})"

        elif intent in ("updateitem",):
            def _call():
                return client.update_item(TableName=table_name, **f)
            query_repr = f"UpdateItem({table_name}, {json.dumps(f)})"

        elif intent in ("deleteitem",):
            def _call():
                return client.delete_item(TableName=table_name, **f)
            query_repr = f"DeleteItem({table_name}, {json.dumps(f)})"

        elif intent in ("batchwriteitem",):
            def _call():
                return client.batch_write_item(**f)
            query_repr = f"BatchWriteItem({json.dumps(f)})"

        elif intent in ("transactwriteitems",):
            def _call():
                return client.transact_write_items(**f)
            query_repr = f"TransactWriteItems({len(f.get('TransactItems', []))} items)"

        elif intent in ("transactgetitems",):
            def _call():
                return client.transact_get_items(**f)
            query_repr = f"TransactGetItems({len(f.get('TransactItems', []))} items)"

        elif intent == "deletetable":
            # DDL: delete a table (requires access: A).
            def _call():
                return client.delete_table(TableName=table_name)
            query_repr = f"DeleteTable({table_name})"

        elif intent == "createtable":
            # DDL: create a table (requires access: A).
            # Caller must include KeySchema, AttributeDefinitions, etc. in filters.
            params: dict[str, Any] = {"TableName": table_name}
            for key in ("KeySchema", "AttributeDefinitions",
                        "BillingMode", "ProvisionedThroughput",
                        "GlobalSecondaryIndexes", "LocalSecondaryIndexes",
                        "StreamSpecification", "SSESpecification", "Tags"):
                if key in f:
                    params[key] = f[key]
            if "BillingMode" not in params:
                params["BillingMode"] = "PAY_PER_REQUEST"
            def _call():
                return client.create_table(**params)
            query_repr = f"CreateTable({table_name})"

        else:
            return QueryResult(
                connector_type=ConnectorType.DYNAMODB,
                database=self._endpoint_url or "aws-dynamodb",
                error=f"Unsupported intent: {intent}",
            )

        start = time.monotonic()
        try:
            resp = await asyncio.to_thread(_call)
        except ClientError as e:
            return QueryResult(
                connector_type=ConnectorType.DYNAMODB,
                database=self._endpoint_url or "aws-dynamodb",
                error=str(e),
            )

        elapsed_ms = (time.monotonic() - start) * 1000

        if intent == "get_item":
            items = [resp["Item"]] if "Item" in resp else []
        else:
            items = resp.get("Items", [])

        rows = [
            _serialise_item({k: deserialiser.deserialize(v) for k, v in item.items()})
            for item in items
        ]
        columns = list(rows[0].keys()) if rows else []

        return QueryResult(
            connector_type=ConnectorType.DYNAMODB,
            database=self._endpoint_url or "aws-dynamodb",
            columns=columns,
            rows=rows,
            total_count=len(rows),
            execution_time_ms=elapsed_ms,
            query_executed=query_repr,
        )
