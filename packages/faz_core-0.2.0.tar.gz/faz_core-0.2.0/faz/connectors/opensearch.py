"""
OpenSearch connector for faz.

Uses opensearch-py synchronous OpenSearch client wrapped in run_in_executor.
This avoids the aiohttp event-loop / Task-context issues that occur with the
async client when shared across pytest-asyncio module-scoped fixtures.

Schema discovery via CAT indices and GET _mapping APIs.
Read-only enforcement: blocks write keys in Query DSL body.

Port default: 9201 (mapped from container 9200 in docker-compose to avoid
conflict with Elasticsearch on 9200).
"""

import asyncio
import json
import time
from typing import Any

from opensearchpy import OpenSearch, OpenSearchException
from urllib3.util.retry import Retry

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# OpenSearch / Elasticsearch field type → readable label (shared mapping)
_ES_TYPE_MAP: dict[str, str] = {
    "text":         "text (full-text)",
    "keyword":      "keyword (exact)",
    "integer":      "int",
    "long":         "long",
    "short":        "short",
    "byte":         "byte",
    "float":        "float",
    "double":       "double",
    "half_float":   "half_float",
    "scaled_float": "scaled_float",
    "boolean":      "bool",
    "date":         "date",
    "binary":       "binary",
    "object":       "object",
    "nested":       "nested object",
    "geo_point":    "geo_point",
    "geo_shape":    "geo_shape",
    "ip":           "ip",
    "knn_vector":   "knn_vector",
    "dense_vector": "dense_vector",
}

# System index prefixes / substrings to skip during schema discovery
_SYSTEM_INDEX_PREFIXES = (
    ".",
    "security-auditlog",
    "kibana",
    "opendistro",
)


def _flatten_mappings(properties: dict, prefix: str = "") -> list[FieldSchema]:
    """
    Recursively flatten OpenSearch mapping properties into a FieldSchema list.

    Handles nested objects by dot-joining parent/child property names.
    """
    fields: list[FieldSchema] = []
    for name, config in properties.items():
        full_name = f"{prefix}.{name}" if prefix else name
        field_type = config.get("type", "object")
        readable_type = _ES_TYPE_MAP.get(field_type, field_type)
        fields.append(FieldSchema(name=full_name, data_type=readable_type))

        # Recurse into nested / object properties
        if "properties" in config:
            fields.extend(_flatten_mappings(config["properties"], prefix=full_name))

    return fields


class OpenSearchConnector(BaseConnector):
    """
    OpenSearch connector using the synchronous client via run_in_executor.

    Supports:
    - Schema discovery via CAT indices + GET _mapping APIs
    - Read-only enforcement: Query DSL body is validated for write keys
    - Query execution via Search API with Query DSL (JSON)
    - Audit-ready: serialised query body stored in QueryResult.query_executed
    """

    CONNECTOR_TYPE = ConnectorType.OPENSEARCH

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: OpenSearch | None = None

    def _run(self, fn):
        """Run a synchronous callable in the default thread pool."""
        loop = asyncio.get_event_loop()
        return loop.run_in_executor(None, fn)

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """
        Initialise OpenSearch client and ping to verify connectivity.
        Supports optional HTTP auth and SSL.
        """
        http_auth = (
            (self.config.username, self.config.password)
            if self.config.username
            else None
        )
        host = self.config.host
        port = self.config.port
        use_ssl = self.config.ssl

        def _connect():
            # retry=Retry(read=3) tells urllib3 to retry on stale keep-alive
            # connection resets (ConnectionResetError 104) transparently.
            client = OpenSearch(
                hosts=[{"host": host, "port": port}],
                http_auth=http_auth,
                use_ssl=use_ssl,
                verify_certs=use_ssl,
                ssl_show_warn=False,
                timeout=30,
                max_retries=3,
                retry_on_timeout=True,
                connection_pool_kwargs={
                    "retries": Retry(read=3, connect=3, redirect=False, raise_on_status=False),
                },
            )
            client.ping()
            return client

        self._client = await self._run(_connect)
        self._connected = True

    async def disconnect(self) -> None:
        if self._client:
            client = self._client
            await self._run(client.close)
            self._client = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            client = self._client
            return await self._run(client.ping)
        except Exception:
            return False

    # ── Schema discovery ─────────────────────────────────────────────────────

    async def discover_schema(self) -> SchemaMetadata:
        """
        Discover all user-facing OpenSearch indices.

        Steps:
          1. GET /_cat/indices?format=json  → index names and doc counts
          2. GET /*/_mapping                → field definitions per index
          3. Skip system indices (prefix "." or "security-auditlog")
          4. Build TableSchema per index, FieldSchema per mapped field
        """
        assert self._client is not None, "Not connected"
        client = self._client

        def _fetch():
            cat_response = client.cat.indices(format="json")
            mapping_resp = client.indices.get_mapping(index="*")
            return cat_response, mapping_resp

        cat_response, mapping_resp = await self._run(_fetch)

        doc_count_map: dict[str, int] = {}
        for entry in cat_response:
            idx = entry.get("index", "")
            try:
                doc_count_map[idx] = int(entry.get("docs.count", 0) or 0)
            except (ValueError, TypeError):
                doc_count_map[idx] = 0

        tables: list[TableSchema] = []
        for index_name, mapping_data in mapping_resp.items():
            if any(index_name.startswith(prefix) for prefix in _SYSTEM_INDEX_PREFIXES):
                continue

            properties = mapping_data.get("mappings", {}).get("properties", {})
            fields = _flatten_mappings(properties)

            tables.append(TableSchema(
                name=index_name,
                fields=fields,
                row_count_estimate=doc_count_map.get(index_name, 0),
            ))

        return SchemaMetadata(
            connector_type=ConnectorType.OPENSEARCH,
            database=f"{self.config.host}:{self.config.port}",
            tables=tables,
        )

    # ── Validation ───────────────────────────────────────────────────────────

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """Validate a Query-DSL JSON string.

        DML (index / update / delete / bulk) flows through; RBAC owns
        per-index decisions. The connector still hard-blocks DDL-shaped
        endpoints — same set as the Elasticsearch connector.
        """
        if not query.strip():
            return ValidationResult(is_valid=False, error="Empty query body")
        try:
            body = json.loads(query)
        except json.JSONDecodeError as exc:
            return ValidationResult(is_valid=False, error=f"Invalid JSON query: {exc}")

        if isinstance(body, dict) and body.get("path"):
            path = str(body["path"])
            method = (body.get("method") or "GET").upper()
            ddl_endpoints = ("_template", "_index_template", "_settings",
                             "_mapping", "_close", "_open", "_aliases")
            if any(seg in path for seg in ddl_endpoints) and not allow_ddl:
                return ValidationResult(
                    is_valid=False,
                    blocked_reason=f"DDL endpoint detected in path '{path}'",
                )
            parts = [p for p in path.strip("/").split("/") if p]
            if method == "DELETE" and len(parts) == 1 and not allow_ddl:
                return ValidationResult(
                    is_valid=False,
                    blocked_reason=f"DELETE on bare index '{parts[0]}' is DDL — requires access: A",
                )
        return ValidationResult(is_valid=True)

    # ── Execution ────────────────────────────────────────────────────────────

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Execute a Query DSL search against one or more OpenSearch indices.

        IntermediateQuery fields used:
          tables    : [index_name, ...]  (comma-joined for multi-index search)
          raw_query : JSON string of the Query DSL body
          fields    : _source fields to return (optional)
          limit     : max hits (mapped to 'size', capped at 1000)

        Returned rows include: _index, _id, _score, and all _source fields.
        """
        assert self._client is not None, "Not connected"

        validation = await self.validate_query(query.raw_query, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.OPENSEARCH,
                database=f"{self.config.host}:{self.config.port}",
                error=validation.blocked_reason or validation.error,
            )

        index = ",".join(query.tables) if query.tables else "*"
        limit = min(query.limit, 1000)

        try:
            query_body: dict[str, Any] = json.loads(query.raw_query)
        except json.JSONDecodeError as exc:
            return QueryResult(
                connector_type=ConnectorType.OPENSEARCH,
                database=f"{self.config.host}:{self.config.port}",
                error=f"Invalid query JSON: {exc}",
            )

        client = self._client

        # Wire-protocol envelope: dispatch to the right OS client method.
        if "method" in query_body and "path" in query_body:
            return await self._dispatch_wire(query_body)

        # Legacy body-only search.
        query_body["size"] = min(query_body.get("size", limit), limit)
        if query.fields:
            query_body["_source"] = query.fields
        audit_repr = json.dumps({"index": index, "body": query_body})

        start = time.monotonic()
        try:
            def _search():
                return client.search(index=index, body=query_body)

            response = await self._run(_search)
            elapsed_ms = (time.monotonic() - start) * 1000

            hits = response["hits"]["hits"]

            rows: list[dict[str, Any]] = []
            for hit in hits:
                row: dict[str, Any] = {
                    "_index": hit.get("_index"),
                    "_id":    hit.get("_id"),
                    "_score": hit.get("_score"),
                }
                row.update(hit.get("_source", {}))
                rows.append(row)

            columns = list(rows[0].keys()) if rows else []

            return QueryResult(
                connector_type=ConnectorType.OPENSEARCH,
                database=f"{self.config.host}:{self.config.port}",
                columns=columns,
                rows=rows,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=audit_repr,
            )

        except OpenSearchException as exc:
            return QueryResult(
                connector_type=ConnectorType.OPENSEARCH,
                database=f"{self.config.host}:{self.config.port}",
                error=str(exc),
                query_executed=audit_repr,
            )

    # ── Wire-protocol envelope dispatch ───────────────────────────────────

    async def _dispatch_wire(self, body: dict[str, Any]) -> QueryResult:
        """Route a ``{method, path, body}`` envelope to the OS client.

        Same path → method mapping as the Elasticsearch connector. DDL
        paths are blocked at validate_query upstream.
        """
        method = (body.get("method") or "GET").upper()
        path = body.get("path") or ""
        inner = body.get("body")
        client = self._client
        host = f"{self.config.host}:{self.config.port}"
        audit = json.dumps({"method": method, "path": path})

        parts = [p for p in path.strip("/").split("/") if p]
        idx = parts[0] if parts else ""
        endpoint = parts[1] if len(parts) >= 2 else ""
        doc_id = parts[2] if len(parts) >= 3 else ""

        start = time.monotonic()
        try:
            if endpoint == "_search":
                def _go(): return client.search(index=idx, body=inner or {})
                resp = await self._run(_go)
                hits = resp["hits"]["hits"]
                rows = [
                    {"_index": h.get("_index"), "_id": h.get("_id"),
                     "_score": h.get("_score"), **h.get("_source", {})}
                    for h in hits
                ]

            elif endpoint == "_count":
                def _go(): return client.count(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{"count": resp.get("count", 0)}]

            elif endpoint == "_doc":
                if doc_id:
                    if method == "GET":
                        def _go(): return client.get(index=idx, id=doc_id)
                        resp = await self._run(_go)
                        rows = [{
                            "_index": resp.get("_index"), "_id": resp.get("_id"),
                            **resp.get("_source", {}),
                        }]
                    else:
                        def _go(): return client.index(index=idx, id=doc_id, body=inner or {})
                        resp = await self._run(_go)
                        rows = [{
                            "_id": resp.get("_id"), "_index": resp.get("_index"),
                            "result": resp.get("result"), "version": resp.get("_version"),
                        }]
                else:
                    def _go(): return client.index(index=idx, body=inner or {})
                    resp = await self._run(_go)
                    rows = [{
                        "_id": resp.get("_id"), "_index": resp.get("_index"),
                        "result": resp.get("result"), "version": resp.get("_version"),
                    }]

            elif endpoint == "_update" and doc_id:
                def _go(): return client.update(index=idx, id=doc_id, body=inner or {})
                resp = await self._run(_go)
                rows = [{
                    "_id": resp.get("_id"), "result": resp.get("result"),
                    "version": resp.get("_version"),
                }]

            elif endpoint == "_update_by_query":
                def _go(): return client.update_by_query(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{"updated": resp.get("updated", 0), "took": resp.get("took", 0)}]

            elif endpoint == "_delete_by_query":
                def _go(): return client.delete_by_query(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{"deleted": resp.get("deleted", 0), "took": resp.get("took", 0)}]

            elif method == "DELETE" and endpoint == "_doc" and doc_id:
                def _go(): return client.delete(index=idx, id=doc_id)
                resp = await self._run(_go)
                rows = [{"_id": resp.get("_id"), "result": resp.get("result")}]

            elif idx == "_bulk" or endpoint == "_bulk" or path.endswith("/_bulk"):
                def _go(): return client.bulk(body=inner)
                resp = await self._run(_go)
                rows = [{
                    "took": resp.get("took", 0),
                    "errors": resp.get("errors", False),
                    "item_count": len(resp.get("items", [])),
                }]

            elif method == "DELETE" and idx and not endpoint:
                # DELETE /<index> — drop index (DDL; requires access: A).
                def _go(): return client.indices.delete(index=idx)
                resp = await self._run(_go)
                rows = [{"acknowledged": resp.get("acknowledged", True), "index": idx}]

            elif method in ("PUT", "POST") and idx and not endpoint:
                # PUT /<index> — create index (DDL; requires access: A).
                def _go(): return client.indices.create(index=idx, body=inner or {})
                resp = await self._run(_go)
                rows = [{
                    "acknowledged": resp.get("acknowledged", True),
                    "index": resp.get("index", idx),
                }]

            else:
                return QueryResult(
                    connector_type=ConnectorType.OPENSEARCH, database=host,
                    error=(
                        f"Unsupported {method} {path}; recognized endpoints: "
                        "_search, _count, _doc, _update, _update_by_query, "
                        "_delete_by_query, _bulk, and bare-index PUT/DELETE (access: A)"
                    ),
                    query_executed=audit,
                )

            elapsed_ms = (time.monotonic() - start) * 1000
            return QueryResult(
                connector_type=ConnectorType.OPENSEARCH, database=host,
                columns=list(rows[0].keys()) if rows else [],
                rows=rows, total_count=len(rows),
                execution_time_ms=elapsed_ms, query_executed=audit,
            )

        except OpenSearchException as exc:
            return QueryResult(
                connector_type=ConnectorType.OPENSEARCH, database=host,
                error=str(exc), query_executed=audit,
            )
