"""
faz Native Connector Registry.

Supported databases:
  Relational:  PostgreSQL, MySQL, Oracle
  NoSQL:       MongoDB, DynamoDB, Cassandra, CouchDB
  Search:      Elasticsearch, OpenSearch
  Vector:      Weaviate, Qdrant, Milvus, Pinecone
  Graph:       Neo4j

Usage:
    from faz.connectors import ConnectorRegistry, ConnectorType
    from faz.connectors.base import ConnectionConfig, AccessMode

    registry = ConnectorRegistry()

    await registry.register(ConnectionConfig(
        connector_type=ConnectorType.POSTGRESQL,
        name="pg_primary",          # routing key; defaults to "postgresql" if omitted
        host="localhost", port=5432,
        database="testdb", username="postgres", password="postgres123",
        access_mode=AccessMode.READ_ONLY,
    ))

    schemas = await registry.discover_all_schemas()
    result  = await registry.execute("pg_primary", query)
"""

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldDistribution,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    Relationship,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# ── Relational ───────────────────────────────────────────────────────────────
from .postgresql import PostgreSQLConnector
from .mysql import MySQLConnector
from .oracle import OracleConnector

# ── NoSQL ────────────────────────────────────────────────────────────────────
from .mongodb import MongoDBConnector
from .dynamodb import DynamoDBConnector
from .cassandra import CassandraConnector
from .couchdb import CouchDBConnector

# ── Search ───────────────────────────────────────────────────────────────────
from .elasticsearch import ElasticsearchConnector
from .opensearch import OpenSearchConnector

# ── Vector ───────────────────────────────────────────────────────────────────
from .weaviate import WeaviateConnector
from .qdrant import QdrantConnector
from .milvus import MilvusConnector
from .pinecone import PineconeConnector

# ── Graph ────────────────────────────────────────────────────────────────────
from .neo4j import Neo4jConnector


_CONNECTOR_MAP: dict[ConnectorType, type[BaseConnector]] = {
    # Relational
    ConnectorType.POSTGRESQL:    PostgreSQLConnector,
    ConnectorType.MYSQL:         MySQLConnector,
    ConnectorType.ORACLE:        OracleConnector,
    # NoSQL
    ConnectorType.MONGODB:       MongoDBConnector,
    ConnectorType.DYNAMODB:      DynamoDBConnector,
    ConnectorType.CASSANDRA:     CassandraConnector,
    ConnectorType.COUCHDB:       CouchDBConnector,
    # Search
    ConnectorType.ELASTICSEARCH: ElasticsearchConnector,
    ConnectorType.OPENSEARCH:    OpenSearchConnector,
    # Vector
    ConnectorType.WEAVIATE:      WeaviateConnector,
    ConnectorType.QDRANT:        QdrantConnector,
    ConnectorType.MILVUS:        MilvusConnector,
    ConnectorType.PINECONE:      PineconeConnector,
    # Graph
    ConnectorType.NEO4J:         Neo4jConnector,
}


class ConnectorRegistry:
    """
    Manages database connector configs and provides on-demand execution.

    Connections are ephemeral by default: connect → operate → disconnect.
    This prevents OOM from holding all 14+ connectors open simultaneously.
    Persistent connections are still available via register/deregister for
    use cases that benefit from connection pooling.

    Connectors are keyed by their ``name`` (ConnectionConfig.name), which
    defaults to the connector type value for single-instance setups, but can
    be a custom string (e.g. "pg_primary", "pg_replica") to support multiple
    instances of the same database type.
    """

    def __init__(self):
        self._connectors: dict[str, BaseConnector] = {}
        self._configs: dict[str, ConnectionConfig] = {}

    # ── Config management (no connections opened) ─────────────────────────

    def add_config(self, config: ConnectionConfig) -> None:
        """Store a connection config for on-demand use. No connection opened."""
        self._configs[config.name] = config

    def get_config(self, name: str) -> ConnectionConfig | None:
        """Return the config for a named connector, or None if not found."""
        return self._configs.get(name)

    # ── Persistent connection management ──────────────────────────────────

    async def register(self, config: ConnectionConfig) -> None:
        """Instantiate, connect, and register a connector for the given config."""
        connector_class = _CONNECTOR_MAP.get(config.connector_type)
        if connector_class is None:
            raise ValueError(f"No connector implemented for type: {config.connector_type}")
        connector = connector_class(config)
        await connector.connect()
        self._connectors[config.name] = connector
        self._configs[config.name] = config

    async def deregister(self, name: str) -> None:
        """Disconnect and remove a named connector."""
        connector = self._connectors.pop(name, None)
        if connector:
            await connector.disconnect()

    async def discover_all_schemas(self) -> list[SchemaMetadata]:
        """Run schema discovery on all registered connectors concurrently."""
        import asyncio
        tasks = [c.discover_schema() for c in self._connectors.values()]
        return await asyncio.gather(*tasks)

    async def execute(self, name: str, query: IntermediateQuery) -> QueryResult:
        """Execute a query on a named persistent connector."""
        connector = self._connectors.get(name)
        if connector is None:
            config = self._configs.get(name)
            ct = config.connector_type if config else ConnectorType.POSTGRESQL
            return QueryResult(
                connector_type=ct,
                database="",
                error=f"No connector registered for name: {name!r}",
            )
        return await connector.execute(query)

    # ── Ephemeral (on-demand) execution ───────────────────────────────────

    async def execute_ephemeral(
        self, name: str, query: IntermediateQuery
    ) -> QueryResult:
        """Connect on-demand, execute query, disconnect immediately.

        Uses stored config — no persistent connection required.
        ``name`` is the connector name (ConnectionConfig.name).
        """
        config = self._configs.get(name)
        if config is None:
            return QueryResult(
                connector_type=ConnectorType.POSTGRESQL,
                database="",
                error=f"No config registered for connector name: {name!r}",
            )

        connector_class = _CONNECTOR_MAP.get(config.connector_type)
        if connector_class is None:
            return QueryResult(
                connector_type=config.connector_type,
                database="",
                error=f"No connector implemented for type: {config.connector_type}",
            )

        connector = connector_class(config)
        try:
            await connector.connect()
            return await connector.execute(query)
        except Exception as exc:
            return QueryResult(
                connector_type=config.connector_type,
                database=config.database,
                error=str(exc),
            )
        finally:
            await connector.disconnect()

    async def execute_multi_ephemeral(
        self, queries: list[IntermediateQuery]
    ) -> list[QueryResult]:
        """Execute multiple queries across connectors ephemerally in parallel."""
        import asyncio
        tasks = [self.execute_ephemeral(q.connector_name, q) for q in queries]
        return await asyncio.gather(*tasks)

    # ── Lifecycle ─────────────────────────────────────────────────────────

    async def execute_multi(self, queries: list[IntermediateQuery]) -> list[QueryResult]:
        """Execute multiple named queries across connectors in parallel (persistent)."""
        import asyncio
        tasks = [self.execute(q.connector_name, q) for q in queries]
        return await asyncio.gather(*tasks)

    async def health_check_all(self) -> dict[str, bool]:
        """Run health checks on all persistent connectors concurrently."""
        import asyncio
        results = await asyncio.gather(
            *[c.health_check() for c in self._connectors.values()],
            return_exceptions=True,
        )
        return {
            name: (r if isinstance(r, bool) else False)
            for name, r in zip(self._connectors.keys(), results)
        }

    async def shutdown(self) -> None:
        """Disconnect all persistent connectors cleanly."""
        import asyncio
        await asyncio.gather(*[c.disconnect() for c in self._connectors.values()])
        self._connectors.clear()

    @property
    def registered_names(self) -> list[str]:
        return list(self._connectors.keys())

    @property
    def configured_names(self) -> list[str]:
        return list(self._configs.keys())


__all__ = [
    # Registry
    "ConnectorRegistry",
    # Base types
    "AccessMode",
    "BaseConnector",
    "ConnectionConfig",
    "ConnectorType",
    "FieldDistribution",
    "FieldSchema",
    "IntermediateQuery",
    "QueryResult",
    "Relationship",
    "SchemaMetadata",
    "TableSchema",
    "ValidationResult",
    # Connectors — Relational
    "PostgreSQLConnector",
    "MySQLConnector",
    "OracleConnector",
    # Connectors — NoSQL
    "MongoDBConnector",
    "DynamoDBConnector",
    "CassandraConnector",
    "CouchDBConnector",
    # Connectors — Search
    "ElasticsearchConnector",
    "OpenSearchConnector",
    # Connectors — Vector
    "WeaviateConnector",
    "QdrantConnector",
    "MilvusConnector",
    "PineconeConnector",
    # Connectors — Graph
    "Neo4jConnector",
]
