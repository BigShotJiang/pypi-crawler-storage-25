"""
Milvus connector for faz.

Uses pymilvus MilvusClient (sync SDK).
Blocking SDK calls are acceptable for MVP; wrap with run_in_executor if
async event-loop isolation is required in production.

Supported intents: search, query, get, count.
Read-only enforcement via intent whitelist; write intents are rejected
before any network call is made.
"""

import asyncio
import json
import time
from typing import Any

from pymilvus import MilvusClient, DataType

from .base import (
    AccessMode,
    BaseConnector,
    ConnectionConfig,
    ConnectorType,
    FieldSchema,
    IntermediateQuery,
    QueryResult,
    SchemaMetadata,
    TableSchema,
    ValidationResult,
)

# Intents that are safe to execute (read-only)
_ALLOWED_INTENTS = {"search", "query", "get", "count"}

# Intents / operation names that must be blocked
_BLOCKED_INTENTS = {
    "insert", "upsert", "delete",
    "drop_collection", "create_collection",
}

# Map pymilvus DataType enum names to readable strings
_MILVUS_TYPE_MAP: dict[str, str] = {
    "INT8":         "int8",
    "INT16":        "int16",
    "INT32":        "int32",
    "INT64":        "int64",
    "FLOAT":        "float",
    "DOUBLE":       "double",
    "BOOL":         "bool",
    "VARCHAR":      "string",
    "STRING":       "string",
    "JSON":         "json",
    "ARRAY":        "array",
    "BINARY_VECTOR": "binary_vector",
    "FLOAT_VECTOR": "float_vector",
    "FLOAT16_VECTOR": "float16_vector",
    "BFLOAT16_VECTOR": "bfloat16_vector",
    "SPARSE_FLOAT_VECTOR": "sparse_float_vector",
}


def _dtype_to_str(field_info: Any) -> str:
    """
    Convert a Milvus field schema DataType to a human-readable string.
    Appends the dimension suffix for vector types when available.
    """
    dtype = field_info.dtype  # DataType enum

    # Try enum name first, then value name lookup
    type_name = dtype.name if hasattr(dtype, "name") else str(dtype)
    readable = _MILVUS_TYPE_MAP.get(type_name, type_name.lower())

    # Append dimension for vector types
    if "vector" in readable.lower():
        params = getattr(field_info, "params", {}) or {}
        dim = params.get("dim")
        if dim:
            readable = f"{readable}[{dim}]"

    return readable


class MilvusConnector(BaseConnector):
    """
    faz connector for Milvus vector database.

    Uses pymilvus MilvusClient (HTTP/gRPC REST-style API, port 19530).
    The SDK is synchronous; blocking calls are run directly for MVP.
    For async isolation, pass calls through run_in_executor as shown
    in the connect() method.

    Supported query intents:
      search  – ANN vector search
      query   – scalar-filter query (SQL-like filter expression)
      get     – point lookup by primary key IDs
      count   – total entity count in a collection
    """

    CONNECTOR_TYPE = ConnectorType.MILVUS

    def __init__(self, config: ConnectionConfig):
        super().__init__(config)
        self._client: MilvusClient | None = None

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        """
        Create a MilvusClient and verify connectivity by listing collections.
        The client constructor is synchronous; wrap in executor for true async.
        """
        loop = asyncio.get_event_loop()
        host = self.config.host
        port = self.config.port
        uri = f"http://{host}:{port}"

        self._client = await loop.run_in_executor(
            None, lambda: MilvusClient(uri=uri)
        )
        # Verify the server is reachable
        await loop.run_in_executor(None, self._client.list_collections)
        self._connected = True

    async def disconnect(self) -> None:
        if self._client is not None:
            try:
                if hasattr(self._client, "close"):
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, self._client.close)
            except Exception:
                pass
            finally:
                self._client = None
        self._connected = False

    async def health_check(self) -> bool:
        if not self._client:
            return False
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._client.list_collections)
            return True
        except Exception:
            return False

    # ── Schema discovery ─────────────────────────────────────────────────────

    async def discover_schema(self) -> SchemaMetadata:
        """
        Introspect all Milvus collections.

        For each collection:
          - describe_collection() → field list and entity count
          - Map DataType to readable label
          - Mark primary key fields with is_primary=True
        """
        assert self._client is not None, "Not connected"
        loop = asyncio.get_event_loop()

        collection_names: list[str] = await loop.run_in_executor(
            None, self._client.list_collections
        )

        tables: list[TableSchema] = []
        for name in collection_names:
            try:
                info = await loop.run_in_executor(
                    None, lambda n=name: self._client.describe_collection(n)
                )
            except Exception:
                continue

            raw_fields = []
            # describe_collection returns a dict; schema.fields path differs by
            # pymilvus version – handle both dict and object forms.
            if isinstance(info, dict):
                # pymilvus 2.4+: fields at top level; older: under "schema" key
                raw_fields = info.get("fields") or info.get("schema", {}).get("fields", [])
                num_entities = info.get("num_entities", 0)
            else:
                schema_obj = getattr(info, "schema", None)
                raw_fields = getattr(schema_obj, "fields", []) if schema_obj else []
                num_entities = getattr(info, "num_entities", 0)

            fields: list[FieldSchema] = []
            for f in raw_fields:
                # Support both dict-style and object-style field descriptors
                if isinstance(f, dict):
                    field_name = f.get("name", "")
                    # pymilvus 2.4+: "is_primary"; older: "is_primary_key"
                    is_primary = bool(f.get("is_primary") or f.get("is_primary_key", False))
                    dtype_val = f.get("type", 0)
                    # dtype_val may be an int or DataType enum
                    if isinstance(dtype_val, int):
                        try:
                            dtype_enum = DataType(dtype_val)
                            type_str = _MILVUS_TYPE_MAP.get(dtype_enum.name, dtype_enum.name.lower())
                        except ValueError:
                            type_str = str(dtype_val)
                        # Attempt to read dim from params
                        params = f.get("params", {})
                        if isinstance(params, dict):
                            dim = params.get("dim")
                            if dim and "vector" in type_str:
                                type_str = f"{type_str}[{dim}]"
                    else:
                        type_str = _dtype_to_str(type(
                            "FakeField",
                            (),
                            {"dtype": dtype_val, "params": f.get("params", {})}
                        )())
                else:
                    field_name = getattr(f, "name", "")
                    is_primary = getattr(f, "is_primary", False)
                    type_str = _dtype_to_str(f)

                fields.append(FieldSchema(
                    name=field_name,
                    data_type=type_str,
                    is_primary=is_primary,
                    nullable=not is_primary,
                ))

            tables.append(TableSchema(
                name=name,
                fields=fields,
                row_count_estimate=num_entities,
            ))

        return SchemaMetadata(
            connector_type=ConnectorType.MILVUS,
            database=f"{self.config.host}:{self.config.port}",
            tables=tables,
        )

    # ── Validation ───────────────────────────────────────────────────────────

    async def validate_query(self, query: str, *, allow_ddl: bool = False) -> ValidationResult:
        """Validate the intent.

        Reads + DML (insert/upsert/delete) flow through; RBAC owns
        per-collection decisions. DDL (create/drop/alter collection,
        index management) is hard-blocked at the connector regardless
        of policy.
        """
        intent = query.strip().lower().replace("_", "")
        ddl = {
            "createcollection", "dropcollection", "altercollection",
            "createindex", "dropindex", "createpartition",
            "droppartition", "loadcollection", "releasecollection",
            "flushcollection", "compactcollection",
        }
        if intent in ddl and not allow_ddl:
            return ValidationResult(
                is_valid=False,
                blocked_reason=(
                    f"DDL intent '{intent}' is hard-blocked at the "
                    "connector regardless of policy."
                ),
            )
        return ValidationResult(is_valid=True)

    # ── Execution ────────────────────────────────────────────────────────────

    def _parse_raw_query(self, query: IntermediateQuery) -> IntermediateQuery:
        """Lift intent + payload from raw_query JSON into query.filters."""
        if not query.raw_query:
            return query
        try:
            parsed = json.loads(query.raw_query)
        except (json.JSONDecodeError, TypeError):
            return query
        if not isinstance(parsed, dict):
            return query
        intent = (
            parsed.get("intent") or parsed.get("operation") or ""
        ).strip().lower().replace("_", "")
        if intent:
            query.intent = intent
        for key in ("vector", "data", "filter", "ids", "id",
                    "anns_field", "partition_name"):
            if key in parsed and key not in query.filters:
                query.filters[key] = parsed[key]
        return query

    async def execute(self, query: IntermediateQuery) -> QueryResult:
        """
        Translate an IntermediateQuery to a pymilvus call and return results.

        IntermediateQuery fields used:
          intent  : reads (search/query/get/count) + writes (insert/upsert/delete)
          tables  : [collection_name]
          fields  : output fields to return (empty → return all with ["*"])
          limit   : max rows (capped at 1000)
          filters : intent-specific parameters
            search → {"vector": [...], "anns_field": "vector"}
            query  → {"filter": "age > 28"}
            get    → {"ids": [1, 2, 3]}
            insert → {"data": [{...}, {...}]}
            upsert → {"data": [{...}]}
            delete → {"ids": [...]} or {"filter": "id == 5"}
        """
        assert self._client is not None, "Not connected"
        loop = asyncio.get_event_loop()

        # Lift raw_query → intent/filters before dispatching.
        query = self._parse_raw_query(query)

        validation = await self.validate_query(query.intent, allow_ddl=query.allow_ddl)
        if not validation.is_valid:
            return QueryResult(
                connector_type=ConnectorType.MILVUS,
                database=f"{self.config.host}:{self.config.port}",
                error=validation.blocked_reason or validation.error,
            )

        if not query.tables:
            return QueryResult(
                connector_type=ConnectorType.MILVUS,
                database=f"{self.config.host}:{self.config.port}",
                error="No collection specified in IntermediateQuery.tables",
            )

        collection_name = query.tables[0]
        limit = min(query.limit, 1000)
        output_fields = query.fields if query.fields else ["*"]
        intent = query.intent.lower()
        filters = query.filters or {}

        start = time.monotonic()
        try:
            raw_results: Any = None

            if intent == "search":
                vector = filters.get("vector", [])
                anns_field = filters.get("anns_field", "vector")
                raw_results = await loop.run_in_executor(
                    None,
                    lambda: self._client.search(
                        collection_name=collection_name,
                        data=[vector],
                        anns_field=anns_field,
                        limit=limit,
                        output_fields=output_fields,
                    ),
                )
                # search() returns list[list[hit_dict]]
                rows = _flatten_search_results(raw_results)

            elif intent == "query":
                filter_expr = filters.get("filter", "")
                raw_results = await loop.run_in_executor(
                    None,
                    lambda: self._client.query(
                        collection_name=collection_name,
                        filter=filter_expr,
                        output_fields=output_fields,
                        limit=limit,
                    ),
                )
                rows = _to_row_list(raw_results)

            elif intent == "get":
                ids = filters.get("ids", [])
                raw_results = await loop.run_in_executor(
                    None,
                    lambda: self._client.get(
                        collection_name=collection_name,
                        ids=ids,
                        output_fields=output_fields,
                    ),
                )
                rows = _to_row_list(raw_results)

            elif intent == "count":
                raw_results = await loop.run_in_executor(
                    None,
                    lambda: self._client.query(
                        collection_name=collection_name,
                        filter="",
                        output_fields=["count(*)"],
                    ),
                )
                rows = _to_row_list(raw_results)

            elif intent in ("insert", "insertone", "insertmany"):
                data = filters.get("data") or filters.get("vector") or []
                if not isinstance(data, list):
                    data = [data]
                raw_results = await loop.run_in_executor(
                    None,
                    lambda: self._client.insert(
                        collection_name=collection_name, data=data,
                    ),
                )
                rows = [_milvus_write_summary(raw_results, "insert", len(data))]

            elif intent in ("upsert", "update", "updateone"):
                data = filters.get("data") or filters.get("vector") or []
                if not isinstance(data, list):
                    data = [data]
                raw_results = await loop.run_in_executor(
                    None,
                    lambda: self._client.upsert(
                        collection_name=collection_name, data=data,
                    ),
                )
                rows = [_milvus_write_summary(raw_results, "upsert", len(data))]

            elif intent in ("delete", "deleteone", "deletemany"):
                ids = filters.get("ids")
                expr = filters.get("filter")
                if not ids and not expr:
                    elapsed_ms = (time.monotonic() - start) * 1000
                    return QueryResult(
                        connector_type=ConnectorType.MILVUS,
                        database=f"{self.config.host}:{self.config.port}",
                        error=("delete requires either `ids` or a `filter` "
                               "expression — empty selector refused as "
                               "unintended DDL"),
                        execution_time_ms=elapsed_ms,
                    )
                kwargs: dict[str, Any] = {"collection_name": collection_name}
                if ids:
                    kwargs["ids"] = ids
                if expr:
                    kwargs["filter"] = expr
                raw_results = await loop.run_in_executor(
                    None, lambda: self._client.delete(**kwargs),
                )
                deleted = (
                    raw_results.get("delete_count")
                    if isinstance(raw_results, dict) else None
                )
                rows = [{
                    "operation": "delete",
                    "deleted": deleted,
                    "ids": ids if ids else None,
                    "filter": expr if expr else None,
                }]

            elif intent in ("dropcollection", "deletecollection"):
                # DDL: drop the collection (requires access: A).
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None, lambda: self._client.drop_collection(collection_name),
                )
                rows = [{"operation": "drop_collection", "collection": collection_name}]

            elif intent == "createcollection":
                # DDL: create a collection (requires access: A).
                from pymilvus import CollectionSchema, FieldSchema, DataType as MilvusDataType
                loop = asyncio.get_event_loop()
                dim = int(filters.get("dim") or filters.get("dimension") or 1536)
                # Build schema from caller-supplied fields list or default to id+embedding.
                raw_fields = filters.get("fields") or []
                if raw_fields:
                    dtype_map = {
                        "INT64": MilvusDataType.INT64, "FLOAT_VECTOR": MilvusDataType.FLOAT_VECTOR,
                        "VARCHAR": MilvusDataType.VARCHAR, "FLOAT": MilvusDataType.FLOAT,
                        "BOOL": MilvusDataType.BOOL, "JSON": MilvusDataType.JSON,
                    }
                    schema_fields = []
                    for fld in raw_fields:
                        kwargs: dict[str, Any] = {
                            "name": fld["name"],
                            "dtype": dtype_map.get(str(fld.get("dtype", "")).upper(), MilvusDataType.VARCHAR),
                            "is_primary": bool(fld.get("is_primary", False)),
                            "auto_id": bool(fld.get("auto_id", False)),
                        }
                        if "dim" in fld:
                            kwargs["dim"] = int(fld["dim"])
                        if "max_length" in fld:
                            kwargs["max_length"] = int(fld["max_length"])
                        schema_fields.append(FieldSchema(**kwargs))
                else:
                    schema_fields = [
                        FieldSchema(name="id", dtype=MilvusDataType.INT64, is_primary=True, auto_id=True),
                        FieldSchema(name="embedding", dtype=MilvusDataType.FLOAT_VECTOR, dim=dim),
                    ]
                schema = CollectionSchema(fields=schema_fields)
                await loop.run_in_executor(
                    None, lambda: self._client.create_collection(collection_name, schema=schema),
                )
                rows = [{"operation": "create_collection", "collection": collection_name}]

            else:
                # Should never reach here after validate_query()
                return QueryResult(
                    connector_type=ConnectorType.MILVUS,
                    database=f"{self.config.host}:{self.config.port}",
                    error=f"Unsupported intent: {intent}",
                )

            elapsed_ms = (time.monotonic() - start) * 1000
            columns = list(rows[0].keys()) if rows else []

            query_repr = json.dumps({
                "collection": collection_name,
                "intent": intent,
                "filters": {k: (v if not isinstance(v, list) or len(v) < 10 else f"<vector len={len(v)}>")
                             for k, v in filters.items()},
                "output_fields": output_fields,
                "limit": limit,
            })

            return QueryResult(
                connector_type=ConnectorType.MILVUS,
                database=f"{self.config.host}:{self.config.port}",
                rows=rows,
                columns=columns,
                total_count=len(rows),
                execution_time_ms=elapsed_ms,
                query_executed=query_repr,
            )

        except Exception as exc:
            return QueryResult(
                connector_type=ConnectorType.MILVUS,
                database=f"{self.config.host}:{self.config.port}",
                error=str(exc),
            )


# ── Helpers ──────────────────────────────────────────────────────────────────

def _milvus_write_summary(raw: Any, op: str, requested: int) -> dict[str, Any]:
    """Pull (insert_count, primary_keys) out of a pymilvus write result.

    pymilvus returns a dict-like object — exact shape varies between
    insert/upsert and minor versions. Normalize it here so callers see
    a consistent rows[0] shape regardless of which milvus is on the
    other end.
    """
    if isinstance(raw, dict):
        return {
            "operation": op,
            "inserted": raw.get("insert_count") or raw.get("upsert_count") or requested,
            "primary_keys": raw.get("ids") or raw.get("primary_keys") or [],
        }
    return {"operation": op, "inserted": requested, "primary_keys": []}


def _to_row_list(raw: Any) -> list[dict[str, Any]]:
    """Coerce pymilvus query/get results to a list of plain dicts."""
    if raw is None:
        return []
    if isinstance(raw, list):
        rows = []
        for item in raw:
            if isinstance(item, dict):
                rows.append(item)
            elif hasattr(item, "__dict__"):
                rows.append(vars(item))
            else:
                rows.append({"value": item})
        return rows
    return []


def _flatten_search_results(raw: Any) -> list[dict[str, Any]]:
    """
    Flatten pymilvus search() results.

    search() returns list[list[hit]] where each hit may be:
      - a dict with keys: id, distance, entity (newer MilvusClient)
      - a Hit object with .id, .distance, .entity attributes
    """
    rows: list[dict[str, Any]] = []
    if not raw:
        return rows

    # Outer list is per-query-vector; we sent one vector so take index 0
    hits_list = raw[0] if raw else []

    for hit in hits_list:
        if isinstance(hit, dict):
            row: dict[str, Any] = {
                "id": hit.get("id"),
                "_distance": hit.get("distance"),
            }
            entity = hit.get("entity", {})
            if isinstance(entity, dict):
                row.update(entity)
        else:
            # Object-style hit
            row = {
                "id": getattr(hit, "id", None),
                "_distance": getattr(hit, "distance", None),
            }
            entity = getattr(hit, "entity", {})
            if isinstance(entity, dict):
                row.update(entity)
            elif hasattr(entity, "__dict__"):
                row.update(vars(entity))
        rows.append(row)

    return rows
