"""Write Claude Desktop / Cursor / OpenClaw MCP client configs to point them at faz.

Each MCP client reads a JSON file at a well-known location and starts
every server listed under a client-specific key. ``faz mcp install``
adds an entry for ``faz`` under that key:

    Claude / Cursor: ``mcpServers.faz``
    OpenClaw:        ``mcp.servers.faz``

The faz block itself is identical across clients::

    {"command": "<abs path>", "args": ["mcp"],
     "env": {"FAZ_CONFIG":   "<abs path>",
             "FAZ_AUDIT_LOG": "<config_dir>/.faz/audit.jsonl"}}

Existing entries for other servers are preserved. Writes are atomic
(``tempfile`` + ``os.replace``). If the existing file is invalid JSON
the original is backed up to ``<name>.bak.<timestamp>`` before being
replaced.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger("faz.mcp.install")


__all__ = [
    "InstallTarget",
    "InstallReport",
    "detect_targets",
    "faz_command",
    "faz_config_env",
    "install",
]


@dataclass
class InstallTarget:
    """Where to write a given MCP client's config.

    ``nest_path`` is the list of JSON keys to walk to reach the dict
    that holds per-server entries. Claude / Cursor use a single flat
    key ``mcpServers``; OpenClaw nests ``mcp.servers``.
    """

    client: str          # "claude" | "cursor" | "openclaw" | custom label
    path: Path
    nest_path: tuple[str, ...] = ("mcpServers",)


@dataclass
class InstallReport:
    """Outcome for a single target."""

    client: str
    path: Path
    status: str          # "written" | "would-write" | "unchanged" | "skipped" | "error"
    detail: str = ""
    rendered: str | None = None   # populated only when dry_run=True


# ---------------------------------------------------------------------------
# Per-OS path detection
# ---------------------------------------------------------------------------


def detect_targets(target_filter: str = "all") -> list[InstallTarget]:
    """Return the configs we'd touch for the requested client(s).

    Cursor uses ``~/.cursor/mcp.json`` on every OS — verified in the
    Phase 5 plan as the simple consistent default; if Cursor on
    Linux/Windows ends up using a different path upstream, the user
    moves the file.

    OpenClaw uses ``~/.openclaw/openclaw.json`` and nests its server
    map under ``mcp.servers`` (rather than the flat ``mcpServers``
    used by Claude / Cursor).

    Claude Code (the CLI tool, distinct from Claude Desktop) stores
    MCP servers per-project under ``projects[<abs cwd>].mcpServers``
    inside ``~/.claude.json``. Because the install is project-scoped,
    ``--target all`` does NOT include Claude Code — running it from a
    random cwd would otherwise silently pollute ``~/.claude.json`` with
    an entry that only applies to that one path. Use
    ``--target claude-code`` from the project root to opt in.
    """
    home = Path.home()
    sysname = platform.system()

    if sysname == "Darwin":
        claude_path = home / "Library/Application Support/Claude/claude_desktop_config.json"
    elif sysname == "Windows":
        appdata = os.environ.get("APPDATA")
        claude_path = (
            Path(appdata) / "Claude/claude_desktop_config.json"
            if appdata
            else home / "AppData/Roaming/Claude/claude_desktop_config.json"
        )
    else:  # Linux + everything else
        claude_path = home / ".config/Claude/claude_desktop_config.json"

    cursor_path = home / ".cursor/mcp.json"
    openclaw_path = home / ".openclaw/openclaw.json"

    # Claude Code (CLI tool) — global scope: top-level ``mcpServers`` key
    # in ``~/.claude.json``, same nesting shape as Claude Desktop.
    # Applies to every project the user opens in Claude Code.
    claude_code_path = home / ".claude.json"

    all_targets = [
        InstallTarget(client="claude", path=claude_path),
        InstallTarget(client="cursor", path=cursor_path),
        InstallTarget(
            client="openclaw",
            path=openclaw_path,
            nest_path=("mcp", "servers"),
        ),
        InstallTarget(client="claude-code", path=claude_code_path),
    ]

    f = target_filter.lower()
    if f in ("all", ""):
        return all_targets
    return [t for t in all_targets if t.client == f]


# ---------------------------------------------------------------------------
# Spawn-line construction for the MCP client
# ---------------------------------------------------------------------------


def faz_command() -> tuple[str, list[str]]:
    """How the MCP client should spawn faz: ``(command, args)``.

    Resolution order:
      1. ``faz`` on the user's PATH (via :func:`shutil.which`).
      2. The ``faz`` binary in the same venv as the running Python —
         catches the common case where the user invoked the install
         command without activating the venv first.
      3. ``<python> -m faz.cli.main`` as a last-ditch fallback.
    """
    found = shutil.which("faz")
    if found:
        return found, ["mcp"]

    venv_faz = Path(sys.executable).parent / "faz"
    if venv_faz.is_file() and os.access(venv_faz, os.X_OK):
        return str(venv_faz), ["mcp"]

    logger.warning(
        "`faz` not on PATH and not in `%s`; falling back to "
        "`python -m faz.cli.main`. Install the package "
        "(`uv pip install -e .`) for a stable command.",
        Path(sys.executable).parent,
    )
    return sys.executable, ["-m", "faz.cli.main", "mcp"]


def faz_config_env() -> dict[str, str]:
    """Build the env block for the spawned MCP server.

    Adds ``FAZ_CONFIG`` (resolved abs path) and ``FAZ_AUDIT_LOG``
    (``<config_dir>/.faz/audit.jsonl``) so the audit stream lands in the
    same project regardless of what cwd Claude / Cursor spawns the
    server with. Returns ``{}`` if no ``faz.yaml`` is resolvable, so the
    caller can omit the env block entirely.

    Resolution order: explicit ``FAZ_CONFIG`` env var, then ``./faz.yaml``
    relative to CWD, then this repo's ``faz.yaml``. ``FAZ_AUDIT_LOG``
    honours an explicit env override; otherwise it's derived from the
    resolved config's parent dir.
    """
    cfg_path = _resolve_faz_yaml()
    if cfg_path is None:
        return {}

    env: dict[str, str] = {"FAZ_CONFIG": str(cfg_path)}

    explicit_audit = os.environ.get("FAZ_AUDIT_LOG")
    if explicit_audit:
        env["FAZ_AUDIT_LOG"] = str(Path(explicit_audit).resolve())
    else:
        env["FAZ_AUDIT_LOG"] = str(cfg_path.parent / ".faz" / "audit.jsonl")

    return env


def _resolve_faz_yaml() -> Path | None:
    """Find the active faz.yaml: env var → cwd → repo-relative fallback."""
    explicit = os.environ.get("FAZ_CONFIG")
    if explicit:
        return Path(explicit).resolve()

    cwd_yaml = Path.cwd() / "faz.yaml"
    if cwd_yaml.is_file():
        return cwd_yaml.resolve()

    # Repo-relative fallback: this file lives at <repo>/faz/mcp/install.py
    # so the project's faz.yaml is three parents up.
    repo_yaml = Path(__file__).resolve().parent.parent.parent / "faz.yaml"
    if repo_yaml.is_file():
        return repo_yaml
    return None


# ---------------------------------------------------------------------------
# Atomic JSON merge
# ---------------------------------------------------------------------------


def install(
    *,
    target: str = "all",
    dry_run: bool = False,
    targets: Iterable[InstallTarget] | None = None,
) -> list[InstallReport]:
    """Merge the faz mcpServers entry into each target config.

    Behaviour per target:
      * Parent dir is created if missing.
      * If the file exists and is valid JSON, merge with the existing
        ``mcpServers`` map (preserves other servers).
      * If the file exists but is invalid JSON, back it up to
        ``<name>.bak.<unix_ts>`` and start fresh — surfaced via
        ``InstallReport.detail``.
      * Atomic write: tempfile in the same directory + ``os.replace``.
      * ``dry_run=True`` skips the write but reports what *would* happen.
    """
    cmd, args = faz_command()
    env = faz_config_env()
    base_block: dict[str, Any] = {"command": cmd, "args": args}
    if env:
        base_block["env"] = env

    chosen = list(targets) if targets is not None else detect_targets(target)
    reports: list[InstallReport] = []

    for tgt in chosen:
        # Claude Code's config schema uses an explicit ``type`` discriminator
        # (``"stdio"`` for command-spawned servers, ``"http"`` for URL-based
        # ones). Other clients (Claude Desktop, Cursor, OpenClaw) accept the
        # bare ``{command, args, env}`` form and don't read a ``type`` key.
        if tgt.client == "claude-code":
            faz_block = {"type": "stdio", **base_block}
        else:
            faz_block = base_block

        try:
            report = _install_one(tgt, faz_block, dry_run=dry_run)
        except Exception as exc:
            logger.exception("install failed for %s", tgt.client)
            report = InstallReport(
                client=tgt.client, path=tgt.path,
                status="error", detail=str(exc),
            )
        reports.append(report)
    return reports


def _install_one(
    target: InstallTarget,
    faz_block: dict[str, Any],
    *,
    dry_run: bool,
) -> InstallReport:
    path = target.path
    parent = path.parent

    existing: dict[str, Any] = {}
    backup_detail = ""

    if path.is_file():
        try:
            existing = json.loads(path.read_text())
            if not isinstance(existing, dict):
                # File is JSON but not an object — back up and reset.
                backup_detail = _backup(path, reason="non-object root", dry_run=dry_run)
                existing = {}
        except json.JSONDecodeError as exc:
            backup_detail = _backup(
                path, reason=f"invalid JSON: {exc.msg}", dry_run=dry_run,
            )
            existing = {}

    servers = _ensure_nested_dict(existing, target.nest_path)
    nest_label = ".".join(target.nest_path)

    # Idempotent: skip the write if the entry is already exactly what we'd produce.
    current = servers.get("faz")
    if current == faz_block and not backup_detail:
        return InstallReport(
            client=target.client, path=path,
            status="unchanged",
            detail=f"faz {nest_label} entry already matches",
        )

    servers["faz"] = faz_block
    rendered = json.dumps(existing, indent=2) + "\n"

    if dry_run:
        return InstallReport(
            client=target.client, path=path,
            status="would-write",
            detail=(
                f"{backup_detail}; "
                if backup_detail else ""
            ) + f"{len(rendered)} bytes",
            rendered=rendered,
        )

    parent.mkdir(parents=True, exist_ok=True)
    _atomic_write(path, rendered)

    return InstallReport(
        client=target.client, path=path,
        status="written",
        detail=backup_detail or "",
    )


def _ensure_nested_dict(root: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    """Walk ``root`` along ``keys``, replacing non-dict nodes with ``{}``.

    Returns the leaf dict. Mutates ``root`` so callers can keep using the
    original reference. ``keys`` is non-empty in practice (every caller
    passes ``InstallTarget.nest_path``).
    """
    cursor: dict[str, Any] = root
    for key in keys:
        nxt = cursor.get(key)
        if not isinstance(nxt, dict):
            nxt = {}
            cursor[key] = nxt
        cursor = nxt
    return cursor


def _backup(path: Path, *, reason: str, dry_run: bool = False) -> str:
    """Move the existing file to ``<name>.bak.<ts>``; return the new name.

    When ``dry_run`` is True the rename is skipped — we only describe what
    would happen, so ``--dry-run`` stays read-only.
    """
    bak = path.with_name(f"{path.name}.bak.{int(time.time())}")
    if dry_run:
        return f"would back up to {bak.name} ({reason})"
    path.rename(bak)
    logger.warning("backed up %s → %s (%s)", path, bak, reason)
    return f"backed up to {bak.name} ({reason})"


def _atomic_write(path: Path, content: str) -> None:
    """Write ``content`` to ``path`` atomically.

    Uses a tempfile in the same directory so ``os.replace`` is a
    same-filesystem rename and therefore atomic.
    """
    fd, tmp_path = tempfile.mkstemp(
        prefix=path.name + ".",
        suffix=".tmp",
        dir=str(path.parent),
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(content)
        os.replace(tmp_path, path)
    except Exception:
        # Clean up the tempfile if the rename never landed.
        try:
            os.unlink(tmp_path)
        except FileNotFoundError:
            pass
        raise
