"""Transport-agnostic handlers for every faz API capability.

The REST router (``faz/src/api/router.py``) and the MCP stdio server
(``faz/src/mcp/server.py``) both call into this module so the two
surfaces stay in lock-step. Handlers take explicit dependency arguments
(no FastAPI / MCP coupling) and either return a JSON-serializable dict
or raise :class:`HandlerError` carrying a status code + detail dict.

REST adapters convert :class:`HandlerError` to ``HTTPException``; MCP
returns ``HandlerError.detail`` directly so the LLM client sees the
same blocked / not-found envelope shape.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from faz.audit.logger import AuditLogger
from faz.auth.policy_loader import PolicyLoader
from faz.connectors import ConnectorRegistry, SchemaMetadata, TableSchema
from faz.engine.executor import ExecutionEngine
from faz.engine.scratchpad_store import ScratchpadStore
from faz.safety.pipeline import SafetyPipeline
from faz.safety.types import StageVerdict
from faz.types.ir import IntermediateRepr

from .ir_builder import IRBuildError, build_federated, build_simple
from .merge_resolver import resolve_step_aliases
from .schemas import FederatedQueryRequest, SimpleQueryRequest

logger = logging.getLogger(__name__)


__all__ = [
    "HandlerError",
    "health",
    "list_databases",
    "describe_table",
    "query_simple",
    "query_federated",
    "paginate_results",
]


class HandlerError(Exception):
    """Transport-neutral error.

    REST raises ``HTTPException(status_code, detail)``; MCP returns the
    detail dict as the tool result. Same envelope reaches the caller.
    """

    def __init__(self, status_code: int, detail: Any) -> None:
        super().__init__(str(detail))
        self.status_code = status_code
        self.detail = detail


# ---------------------------------------------------------------------------
# /v1/health
# ---------------------------------------------------------------------------


async def health(registry: ConnectorRegistry) -> dict[str, Any]:
    """Liveness probe. Cheap by design — no per-DB ping."""
    return {
        "status": "ok",
        "version": "0.1.1",
        "databases_connected": len(registry.registered_names),
    }


# ---------------------------------------------------------------------------
# /v1/databases
# ---------------------------------------------------------------------------


def _emit_metadata_audit(
    audit: "AuditLogger | None",
    transport: str,
    *,
    sources_hit: list[str],
    rows_returned: int = 0,
    error: str = "",
) -> None:
    """Emit one audit-log line for a metadata read.

    No-op when ``audit`` is None so the handler stays callable from any
    code path that hasn't wired up the runtime audit logger yet (tests,
    legacy callers).
    """
    if audit is None:
        return
    entry = audit.create_entry(audit.new_trace_id(), transport=transport)
    audit.record_auth(entry, method="TRANSPORT_TRUST", outcome="PASS")
    audit.record_execution(entry, sources_hit=sources_hit)
    audit.record_result(entry, rows_returned=rows_returned, error=error)
    audit.emit(entry)


async def list_databases(
    registry: ConnectorRegistry,
    *,
    page: int = 1,
    size: int = 4,
    audit: "AuditLogger | None" = None,
    transport: str = "",
) -> dict[str, Any]:
    """Every CONFIGURED database with reachability + schema, paginated.

    Iterates ``configured_names`` (not just ``registered_names``) so
    databases that failed to connect at startup still surface — they
    appear with ``reachable: false`` and an ``error`` describing the
    failure. Agents need to know what was *configured*, not just what
    happened to be online when faz booted.

    Returns the requested page and a ``pagination`` block with the
    totals so the caller can iterate. Default ``size=4`` keeps each
    response well under typical MCP / HTTP content-length thresholds
    even when one DB has many tables (Oracle's ~30 system tables, etc.)

    Args:
        registry: The :class:`ConnectorRegistry` to enumerate.
        page: 1-indexed page number. Out-of-range pages return an
            empty ``databases`` list with ``has_more=False``.
        size: Databases per page. Capped to ``len(configured_names)``
            so callers can pass a large size to force a single page.

    Returns:
        ``{"databases": [...], "pagination": {...}}``
    """
    if page < 1:
        page = 1
    if size < 1:
        size = 1

    all_names = registry.configured_names
    total = len(all_names)
    total_pages = max(1, (total + size - 1) // size)

    start = (page - 1) * size
    end = start + size
    page_names = all_names[start:end]

    try:
        results = await asyncio.gather(
            *(_inspect_connector(registry, name) for name in page_names),
            return_exceptions=True,
        )
    except Exception as exc:
        _emit_metadata_audit(
            audit, transport, sources_hit=list(page_names), error=str(exc),
        )
        raise

    databases: list[dict[str, Any]] = []
    for name, result in zip(page_names, results):
        if isinstance(result, BaseException):
            logger.warning("inspect failed for %s: %s", name, result)
            databases.append({
                "name": name,
                "type": _safe_type(registry, name),
                "database": "",
                "reachable": False,
                "tables": [],
                "error": str(result),
            })
        else:
            databases.append(result)

    response = {
        "databases": databases,
        "pagination": {
            "page": page,
            "size": size,
            "total_databases": total,
            "total_pages": total_pages,
            "has_more": end < total,
        },
    }
    _emit_metadata_audit(
        audit, transport,
        sources_hit=list(page_names),
        rows_returned=len(databases),
    )
    return response


async def describe_table(
    db: str, table: str, registry: ConnectorRegistry,
    *,
    audit: "AuditLogger | None" = None,
    transport: str = "",
) -> dict[str, Any]:
    """Single-table schema detail.

    Raises HandlerError(404) if database or table is unknown,
    HandlerError(503) if the database is currently unreachable.
    """
    if db not in registry.configured_names:
        configured = sorted(registry.configured_names)
        _emit_metadata_audit(
            audit, transport,
            sources_hit=[db],
            error=f"unknown database: {db!r}",
        )
        raise HandlerError(
            404, f"Unknown database: {db!r}. Configured: {configured}",
        )

    if db not in registry.registered_names:
        _emit_metadata_audit(
            audit, transport,
            sources_hit=[db],
            error=f"database {db!r} not connected",
        )
        raise HandlerError(
            503,
            (
                f"Database {db!r} is configured but not currently "
                "connected (failed at startup or disconnected). "
                "See /v1/databases for status."
            ),
        )

    connector = registry._connectors[db]
    try:
        schema = await connector.discover_schema()
    except Exception as exc:
        logger.warning("describe_table: %s schema failed: %s", db, exc)
        _emit_metadata_audit(
            audit, transport, sources_hit=[db], error=str(exc),
        )
        raise HandlerError(503, f"Schema discovery failed: {exc}")

    for t in schema.tables:
        if t.name == table:
            response = {
                "database": db,
                "table": _serialize_table(t),
            }
            _emit_metadata_audit(
                audit, transport,
                sources_hit=[db],
                rows_returned=len(getattr(t, "columns", []) or []),
            )
            return response

    available = sorted(t.name for t in schema.tables)
    _emit_metadata_audit(
        audit, transport,
        sources_hit=[db],
        error=f"table {table!r} not found in {db!r}",
    )
    raise HandlerError(
        404,
        (
            f"Table {table!r} not found in {db!r}. "
            f"Available: {available}"
        ),
    )


async def _inspect_connector(
    registry: ConnectorRegistry, name: str,
) -> dict[str, Any]:
    """Build one entry of the /v1/databases response.

    Three cases:
      * Configured but never registered (startup connection failed).
      * Registered but currently down (health_check fails).
      * Registered and reachable: discover_schema for tables list.
    """
    config = registry.get_config(name)
    type_value = config.connector_type.value if config else "unknown"
    database_name = config.database if config else ""

    if name not in registry.registered_names:
        return {
            "name": name,
            "type": type_value,
            "database": database_name,
            "reachable": False,
            "tables": [],
            "error": "Failed to connect at startup (check faz logs)",
        }

    connector = registry._connectors[name]

    try:
        reachable = bool(await connector.health_check())
    except Exception as exc:
        logger.debug("%s health_check raised: %s", name, exc)
        reachable = False

    if not reachable:
        return {
            "name": name,
            "type": type_value,
            "database": database_name,
            "reachable": False,
            "tables": [],
        }

    try:
        schema = await connector.discover_schema()
    except Exception as exc:
        logger.warning("%s schema discovery failed: %s", name, exc)
        return {
            "name": name,
            "type": type_value,
            "database": database_name,
            "reachable": True,
            "tables": [],
            "schema_error": str(exc),
        }

    return _serialize_database(name, type_value, database_name, schema)


def _serialize_database(
    name: str, type_value: str, database_name: str, schema: SchemaMetadata,
) -> dict[str, Any]:
    return {
        "name": name,
        "type": type_value or schema.connector_type.value,
        "database": database_name or schema.database,
        "reachable": True,
        "tables": [_serialize_table(t) for t in schema.tables],
    }


def _serialize_table(t: TableSchema) -> dict[str, Any]:
    return {
        "name": t.name,
        "row_count_estimate": t.row_count_estimate,
        "columns": [
            {
                "name": f.name,
                "data_type": f.data_type,
                "nullable": f.nullable,
                "is_primary": f.is_primary,
            }
            for f in t.fields
        ],
    }


def _safe_type(registry: ConnectorRegistry, name: str) -> str:
    cfg = registry.get_config(name)
    return cfg.connector_type.value if cfg else "unknown"


# ---------------------------------------------------------------------------
# /v1/query/simple   +   /v1/query (federated)
# ---------------------------------------------------------------------------


async def query_simple(
    body: SimpleQueryRequest,
    *,
    registry: ConnectorRegistry,
    policy: PolicyLoader,
    pipeline: SafetyPipeline,
    engine: ExecutionEngine,
    scratchpads: ScratchpadStore,
    audit: AuditLogger,
    transport: str,
) -> dict[str, Any]:
    """Single-database query: build_simple → safety → execute → audit."""
    try:
        ir = build_simple(body, registry)
    except IRBuildError as exc:
        raise HandlerError(400, str(exc))

    return await _run_query(
        ir,
        merge_sql=None,
        policy=policy,
        pipeline=pipeline,
        engine=engine,
        scratchpads=scratchpads,
        audit=audit,
        transport=transport,
        primary_database=body.database,
    )


async def query_federated(
    body: FederatedQueryRequest,
    *,
    registry: ConnectorRegistry,
    policy: PolicyLoader,
    pipeline: SafetyPipeline,
    engine: ExecutionEngine,
    scratchpads: ScratchpadStore,
    audit: AuditLogger,
    transport: str,
) -> dict[str, Any]:
    """Multi-database federated query with optional DuckDB merge."""
    try:
        ir, merge_sql = build_federated(body, registry)
    except IRBuildError as exc:
        raise HandlerError(400, str(exc))

    return await _run_query(
        ir,
        merge_sql=merge_sql,
        policy=policy,
        pipeline=pipeline,
        engine=engine,
        scratchpads=scratchpads,
        audit=audit,
        transport=transport,
        primary_database=None,
    )


async def _run_query(
    ir: IntermediateRepr,
    *,
    merge_sql: str | None,
    policy: PolicyLoader,
    pipeline: SafetyPipeline,
    engine: ExecutionEngine,
    scratchpads: ScratchpadStore,
    audit: AuditLogger,
    transport: str,
    primary_database: str | None,
) -> dict[str, Any]:
    """Shared safety + execute path used by both query handlers.

    Returns a JSON-serializable dict matching ``QueryResponseSuccess``
    or raises ``HandlerError(403)`` (blocked) / ``HandlerError(500)``
    (engine crash / step error).
    """
    request_id = AuditLogger.new_trace_id()
    entry = audit.create_entry(request_id, transport=transport)
    audit.record_auth(entry, method="TRANSPORT_TRUST", outcome="PASS")

    raw_sql = {
        step.source: step.raw_query
        for step in ir.steps
        if step.raw_query
    }

    # ── Safety pipeline ───────────────────────────────────────────────
    safety_start = time.monotonic()
    safety_result = pipeline.run(ir, list(policy.permissions), raw_sql=raw_sql)
    safety_ms = (time.monotonic() - safety_start) * 1000.0

    audit.record_safety(
        entry,
        rbac_outcome=_stage_outcome(safety_result, "RBAC_GATE"),
        ast_outcome=_stage_outcome(safety_result, "AST_CHECKER"),
        injection_outcome=_stage_outcome(safety_result, "INJECTION_ANALYSER"),
        latency_ms=safety_ms,
    )

    if not safety_result.allowed:
        first_block = next(
            (s for s in safety_result.stages if s.verdict == StageVerdict.BLOCK),
            None,
        )
        stage_name = first_block.stage if first_block else "UNKNOWN"
        reason = (
            first_block.events[0].message
            if first_block and first_block.events
            else "Request blocked by safety pipeline"
        )
        suggestion = _suggestion_for(stage_name, reason)

        audit.record_result(
            entry,
            rows_returned=0,
            error=f"BLOCKED:{stage_name} {reason}",
            latency_ms=0.0,
        )
        audit.emit(entry)
        raise HandlerError(
            403,
            {
                "request_id": request_id,
                "status": "blocked",
                "error": {
                    "stage": stage_name,
                    "reason": reason,
                    "suggestion": suggestion,
                },
            },
        )

    # ── Tag DDL-approved steps ────────────────────────────────────────
    # The safety pipeline just passed. If any step's raw query contains
    # DDL operations, the only way that passed is AccessMode.A. Flag
    # those steps so the connector's internal validate_query knows to
    # defer the DDL block to the policy that already approved it.
    from faz.safety.access_extractors import extract_targets
    from faz.safety.types import Op
    for step in ir.steps:
        raw = raw_sql.get(step.source) if raw_sql else None
        try:
            targets = extract_targets(step, raw)
            if any(t.operation == Op.DDL for t in targets):
                step.allow_ddl = True
        except Exception:
            pass  # extractor crash → leave allow_ddl=False (safe default)

    # ── Execute ───────────────────────────────────────────────────────
    rewritten_sql = getattr(safety_result, "rewritten_sql", None)
    final_merge_sql = (
        resolve_step_aliases(merge_sql, ir) if merge_sql else None
    )
    exec_start = time.monotonic()
    try:
        result = await engine.run(
            ir, rewritten_sql=rewritten_sql, merge_sql=final_merge_sql,
        )
    except Exception as exc:
        logger.exception("execution engine crashed")
        audit.record_result(
            entry, rows_returned=0, error=f"engine crash: {exc}",
        )
        audit.emit(entry)
        raise HandlerError(500, f"Execution failed: {exc}")
    exec_ms = (time.monotonic() - exec_start) * 1000.0

    audit.record_execution(
        entry,
        sources_hit=[s.source for s in ir.steps],
        merge_sql=result.merge_sql,
        merge_latency_ms=0.0,
        iteration_count=result.iteration_count,
        latency_ms=exec_ms,
    )

    if result.error:
        audit.record_result(entry, rows_returned=0, error=result.error)
        audit.emit(entry)
        raise HandlerError(500, {
            "request_id": request_id,
            "status": "error",
            "error": result.error,
        })

    if result.scratchpad is not None and len(result.rows) > 0:
        try:
            await scratchpads.put(request_id, result.scratchpad)
        except Exception as exc:
            logger.warning("scratchpad store failed for %s: %s", request_id, exc)

    audit.record_result(
        entry,
        rows_returned=len(result.rows),
        latency_ms=0.0,
    )
    audit.emit(entry)

    warnings: list[str] = []
    if safety_result.stripped_sources:
        warnings.append(
            f"Stripped {len(safety_result.stripped_sources)} step(s) "
            f"under DenyPolicy.PARTIAL: {safety_result.stripped_sources}"
        )

    return {
        "request_id": request_id,
        "status": "ok",
        "data": {
            "columns": result.columns,
            "rows": result.rows,
            "row_count": len(result.rows),
        },
        "safety": {
            "stages_passed": [
                s.stage for s in safety_result.stages
                if s.verdict in (StageVerdict.PASS, StageVerdict.PARTIAL)
            ],
            "warnings": warnings,
        },
        "metadata": {
            "database": primary_database,
            "execution_time_ms": exec_ms,
            "transport": transport,
        },
    }


def _stage_outcome(result: Any, stage_name: str) -> str:
    """Pull the verdict for a named stage from a ValidationResult."""
    for s in result.stages:
        if s.stage == stage_name:
            return s.verdict.value
    return "SKIPPED"


def _suggestion_for(stage_name: str, reason: str = "") -> str | None:
    """Generic per-stage hint included in 403 envelopes.

    `reason` lets the suggestion adapt to the *kind* of block within a
    stage — e.g. an RBAC_GATE rejection is normally fixable by editing
    faz.yaml, but a DDL rejection is policy-independent and the dev
    needs different guidance.
    """
    ddl_suggestion = (
        "DDL (CREATE/DROP/ALTER/TRUNCATE) is permitted only when the "
        "matching faz.yaml entry grants `access: A`. Either upgrade the "
        "policy or run the schema change through your migration tooling."
    )
    if "DDL" in reason:
        return ddl_suggestion

    return {
        "PROMPT_GUARD":
            "Rephrase as a read query — destructive intent words like "
            "'drop all tables' are detected even in NL descriptions.",
        "RBAC_GATE":
            "Edit faz.yaml `permissions[<db>]` to grant the required "
            "access level (R / W / RW) for the table.",
        "AST_CHECKER": ddl_suggestion,
        "INJECTION_ANALYSER":
            "Remove injection patterns (UNION, OR 1=1, stacked statements, "
            "comment markers) and resubmit the query.",
        "GUARDRAILS":
            "Lower the row count or simplify the query — exceeded "
            "max_rows_per_query / depth limit.",
    }.get(stage_name)


# ---------------------------------------------------------------------------
# /v1/results/{request_id}  — pagination
# ---------------------------------------------------------------------------


async def paginate_results(
    request_id: str,
    page: int,
    size: int,
    *,
    scratchpads: ScratchpadStore,
    policy: PolicyLoader,
) -> dict[str, Any]:
    """Paginate a stored DuckDB scratchpad by request_id.

    The scratchpad is held by ScratchpadStore for ``ttl_seconds``
    (default 300s, refreshed on access). After expiry, returns a 404
    via HandlerError.
    """
    sp = await scratchpads.get(request_id)
    if sp is None:
        raise HandlerError(
            404,
            (
                f"No stored result for {request_id} — it may have "
                "expired (default TTL 5 minutes) or never existed."
            ),
        )

    max_rows = int(policy.safety.get("max_rows_per_query", 10_000) or 10_000)
    size = min(size, max_rows)

    offset = (page - 1) * size
    try:
        rows, columns = sp.execute_sql(
            f"SELECT * FROM _merge_result LIMIT {size + 1} OFFSET {offset}"
        )
    except Exception as exc:
        logger.warning("pagination SQL failed for %s: %s", request_id, exc)
        raise HandlerError(500, f"Pagination failed: {exc}")

    has_more = len(rows) > size
    if has_more:
        rows = rows[:size]

    return {
        "request_id": request_id,
        "page": page,
        "size": size,
        "columns": columns,
        "rows": rows,
        "has_more": has_more,
    }
