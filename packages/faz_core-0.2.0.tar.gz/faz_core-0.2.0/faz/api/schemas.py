"""Pydantic request/response models for the faz REST API.

Wire-format definitions only — internal types (`IRStep`, `Permission`,
`AuthResult`, etc.) stay in their respective modules. This module is
the single source of truth for the JSON shapes that route handlers
receive and return.

Naming: external-facing models use `Request`/`Response` suffixes so
they're easy to spot in route handlers.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from faz.safety.types import QueryLanguage


def _coerce_language(value: Any) -> Any:
    """Normalize an explicit language hint, or pass ``None`` through.

    Agents commonly send ``"sql"`` not ``"SQL"`` — uppercase before the
    enum lookup so both work. ``None`` (and ``"null"`` JSON literal) is
    treated as "no hint": downstream the per-family access extractor
    falls back to ``resolve_query_language(database)`` to infer the
    connector's natural language. That keeps mongodb queries from
    failing with "expected MQL got SQL" when the agent doesn't bother
    to set the field.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value.upper()
    return value


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------


class SimpleQueryRequest(BaseModel):
    """POST /v1/query/simple body."""

    database: str = Field(..., description="Connector name from faz.yaml.")
    table: str = Field(..., description="Declared target table/collection.")
    language: QueryLanguage | None = Field(
        None,
        description=(
            "Query language. Picks the per-family extractor. "
            "Omit (or pass null) to infer from the connector's type — "
            "e.g. ``mongodb`` → MQL, ``neo4j`` → CYPHER. Pass an "
            "explicit value (sql/mql/cypher/es_dsl/vector/dynamo/couchdb) "
            "to override."
        ),
    )
    query: str = Field(..., description="Native query body (SQL/MQL/Cypher/etc.)")

    @field_validator("language", mode="before")
    @classmethod
    def _upper_language(cls, v: Any) -> Any:
        return _coerce_language(v)


class FederatedStepRequest(BaseModel):
    """One step inside POST /v1/query.steps[]."""

    step_id: str = Field(..., description='DAG node id, e.g. "s0".')
    database: str
    table: str
    language: QueryLanguage | None = None    # inferred from `database` when omitted
    query: str
    depends_on: list[str] = Field(
        default_factory=list,
        description="Other step_ids this step waits for.",
    )
    link_from: str | None = Field(
        None,
        description="Field to extract from dependency's results.",
    )
    link_to: str | None = Field(
        None,
        description="Field to filter on in this step's query.",
    )

    @field_validator("language", mode="before")
    @classmethod
    def _upper_language(cls, v: Any) -> Any:
        return _coerce_language(v)


class FederatedQueryRequest(BaseModel):
    """POST /v1/query body — multi-step federated query."""

    steps: list[FederatedStepRequest] = Field(
        ...,
        min_length=1,
        description="DAG of query steps. At least one required.",
    )
    merge: str | None = Field(
        None,
        description=(
            "DuckDB SELECT/CTE that joins per-step results "
            "(referenced as tables s0, s1, ...). Required when 2+ steps "
            "produce data."
        ),
    )


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------


class ResponseData(BaseModel):
    """Successful query payload."""

    columns: list[str]
    rows: list[dict[str, Any]]
    row_count: int


class SafetySummary(BaseModel):
    """What the safety pipeline did."""

    stages_passed: list[str]
    warnings: list[str] = Field(default_factory=list)


class StepMetadata(BaseModel):
    """Per-step metrics — only included in federated responses."""

    step_id: str
    database: str
    rows_returned: int
    latency_ms: float


class QueryMetadata(BaseModel):
    """Top-level metadata about the query execution."""

    database: str | None = None
    execution_time_ms: float
    transport: str
    steps: list[StepMetadata] = Field(default_factory=list)
    merge_latency_ms: float | None = None


class QueryResponseSuccess(BaseModel):
    """Successful query envelope (status='ok')."""

    request_id: str
    status: Literal["ok"] = "ok"
    data: ResponseData
    safety: SafetySummary
    metadata: QueryMetadata


class BlockError(BaseModel):
    """Why a query was blocked."""

    stage: str
    reason: str
    suggestion: str | None = None


class QueryResponseBlocked(BaseModel):
    """Blocked query envelope (status='blocked'). Returned with HTTP 403."""

    request_id: str
    status: Literal["blocked"] = "blocked"
    error: BlockError


class PaginatedResults(BaseModel):
    """GET /v1/results/{request_id} response."""

    request_id: str
    page: int
    size: int
    columns: list[str]
    rows: list[dict[str, Any]]
    has_more: bool
