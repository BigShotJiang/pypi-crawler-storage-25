"""faz REST API — route registration.

`setup_api(app)` mounts every endpoint under `/v1`. Each route is a thin
adapter over :mod:`faz.faz.api.handlers` — handlers do the real work and
the router just translates :class:`HandlerError` to ``HTTPException``.

Endpoints (Phase 4 surface):

    GET  /v1/health                              liveness probe
    GET  /v1/databases                           every connected DB + schemas
    GET  /v1/databases/{db}/tables/{table}       single-table detail
    POST /v1/query/simple                        single-step query
    POST /v1/query                               federated query
    GET  /v1/results/{request_id}                paginate scratchpad
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query

from faz.audit.logger import AuditLogger
from faz.auth.policy_loader import PolicyLoader
from faz.connectors import ConnectorRegistry
from faz.engine.executor import ExecutionEngine
from faz.engine.scratchpad_store import ScratchpadStore
from faz.safety.pipeline import SafetyPipeline

from . import handlers
from ._deps import (
    get_audit,
    get_engine,
    get_pipeline,
    get_policy,
    get_registry,
    get_scratchpads,
    get_transport,
)
from .handlers import HandlerError
from .schemas import FederatedQueryRequest, SimpleQueryRequest

logger = logging.getLogger(__name__)


__all__ = ["setup_api"]


def setup_api(app: FastAPI) -> None:
    """Mount the v1 router on the given FastAPI app."""
    router = APIRouter(prefix="/v1")
    _register_health_routes(router)
    _register_database_routes(router)
    _register_query_routes(router)
    _register_result_routes(router)
    app.include_router(router)


def _wrap(error: HandlerError) -> HTTPException:
    """Translate a transport-neutral HandlerError into FastAPI's HTTPException."""
    return HTTPException(status_code=error.status_code, detail=error.detail)


# ---------------------------------------------------------------------------
# /v1/health
# ---------------------------------------------------------------------------


def _register_health_routes(router: APIRouter) -> None:

    @router.get("/health")
    async def health(
        registry: ConnectorRegistry = Depends(get_registry),
    ) -> dict[str, Any]:
        return await handlers.health(registry)


# ---------------------------------------------------------------------------
# /v1/databases
# ---------------------------------------------------------------------------


def _register_database_routes(router: APIRouter) -> None:

    @router.get("/databases/{db}/tables/{table}")
    async def describe_table(
        db: str,
        table: str,
        registry: ConnectorRegistry = Depends(get_registry),
        audit: AuditLogger = Depends(get_audit),
        transport: str = Depends(get_transport),
    ) -> dict[str, Any]:
        try:
            return await handlers.describe_table(
                db, table, registry, audit=audit, transport=transport,
            )
        except HandlerError as exc:
            raise _wrap(exc)

    @router.get("/databases")
    async def list_databases(
        page: int = Query(1, ge=1, description="1-indexed page number."),
        size: int = Query(
            4, ge=1, le=100,
            description="Databases per page. Default 4 keeps responses "
                        "comfortably under MCP / HTTP size limits.",
        ),
        registry: ConnectorRegistry = Depends(get_registry),
        audit: AuditLogger = Depends(get_audit),
        transport: str = Depends(get_transport),
    ) -> dict[str, Any]:
        return await handlers.list_databases(
            registry, page=page, size=size, audit=audit, transport=transport,
        )


# ---------------------------------------------------------------------------
# /v1/query/simple   +   /v1/query (federated)
# ---------------------------------------------------------------------------


def _register_query_routes(router: APIRouter) -> None:

    @router.post("/query/simple")
    async def query_simple(
        body: SimpleQueryRequest,
        registry: ConnectorRegistry = Depends(get_registry),
        policy: PolicyLoader = Depends(get_policy),
        pipeline: SafetyPipeline = Depends(get_pipeline),
        engine: ExecutionEngine = Depends(get_engine),
        scratchpads: ScratchpadStore = Depends(get_scratchpads),
        audit: AuditLogger = Depends(get_audit),
        transport: str = Depends(get_transport),
    ) -> dict[str, Any]:
        try:
            return await handlers.query_simple(
                body,
                registry=registry,
                policy=policy,
                pipeline=pipeline,
                engine=engine,
                scratchpads=scratchpads,
                audit=audit,
                transport=transport,
            )
        except HandlerError as exc:
            raise _wrap(exc)

    @router.post("/query")
    async def query_federated(
        body: FederatedQueryRequest,
        registry: ConnectorRegistry = Depends(get_registry),
        policy: PolicyLoader = Depends(get_policy),
        pipeline: SafetyPipeline = Depends(get_pipeline),
        engine: ExecutionEngine = Depends(get_engine),
        scratchpads: ScratchpadStore = Depends(get_scratchpads),
        audit: AuditLogger = Depends(get_audit),
        transport: str = Depends(get_transport),
    ) -> dict[str, Any]:
        try:
            return await handlers.query_federated(
                body,
                registry=registry,
                policy=policy,
                pipeline=pipeline,
                engine=engine,
                scratchpads=scratchpads,
                audit=audit,
                transport=transport,
            )
        except HandlerError as exc:
            raise _wrap(exc)


# ---------------------------------------------------------------------------
# /v1/results/{request_id}
# ---------------------------------------------------------------------------


def _register_result_routes(router: APIRouter) -> None:

    @router.get("/results/{request_id}")
    async def paginate_results(
        request_id: str,
        page: int = Query(1, ge=1),
        size: int = Query(100, ge=1, le=10_000),
        scratchpads: ScratchpadStore = Depends(get_scratchpads),
        policy: PolicyLoader = Depends(get_policy),
    ) -> dict[str, Any]:
        try:
            return await handlers.paginate_results(
                request_id, page, size,
                scratchpads=scratchpads, policy=policy,
            )
        except HandlerError as exc:
            raise _wrap(exc)
