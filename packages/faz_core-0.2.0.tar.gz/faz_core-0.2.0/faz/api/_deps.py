"""FastAPI dependencies for the faz REST API.

These read from `app.state` (set up in `faz/main.py` lifespan) and
hand out the singletons that route handlers need:

  - `get_policy()`      → loaded `PolicyLoader` (permissions + safety)
  - `get_registry()`    → `ConnectorRegistry` with all DBs connected
  - `get_scratchpads()` → `ScratchpadStore` for query-result pagination
  - `get_transport()`   → `"rest/local"` or `"rest/remote"` (audit only)

There is no auth challenge. `faz serve` binds 127.0.0.1 by default;
remote exposure is the dev's responsibility (reverse proxy with their
own auth backend in front). `get_transport()` only labels the audit
log entry — it never rejects.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import Request

if TYPE_CHECKING:
    from faz.audit.logger import AuditLogger
    from faz.auth.policy_loader import PolicyLoader
    from faz.connectors import ConnectorRegistry
    from faz.engine.executor import ExecutionEngine
    from faz.engine.scratchpad_store import ScratchpadStore
    from faz.safety.pipeline import SafetyPipeline


_LOOPBACK_HOSTS: frozenset[str] = frozenset({"127.0.0.1", "::1", "localhost"})


def get_policy(request: Request) -> "PolicyLoader":
    """Return the singleton PolicyLoader attached at app startup."""
    return request.app.state.policy


def get_registry(request: Request) -> "ConnectorRegistry":
    """Return the ConnectorRegistry with all configured DBs connected."""
    return request.app.state.registry


def get_scratchpads(request: Request) -> "ScratchpadStore":
    """Return the ScratchpadStore that holds DuckDB scratchpads for pagination."""
    return request.app.state.scratchpads


def get_pipeline(request: Request) -> "SafetyPipeline":
    """Return the singleton SafetyPipeline (no per-request state)."""
    return request.app.state.pipeline


def get_engine(request: Request) -> "ExecutionEngine":
    """Return the singleton ExecutionEngine bound to the connector registry."""
    return request.app.state.engine


def get_audit(request: Request) -> "AuditLogger":
    """Return the AuditLogger that emits one entry per request."""
    return request.app.state.audit


def get_transport(request: Request) -> str:
    """Identify the request's transport for audit logging.

    Returns `"rest/local"` for loopback callers, `"rest/remote"` otherwise.
    Never raises or rejects — this is metadata, not a gate.
    """
    client = request.client
    if client is None:
        return "rest/remote"
    return "rest/local" if client.host in _LOOPBACK_HOSTS else "rest/remote"
