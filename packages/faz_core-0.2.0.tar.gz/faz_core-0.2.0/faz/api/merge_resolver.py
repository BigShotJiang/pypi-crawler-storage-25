"""Rewrite step-id aliases in agent-supplied merge SQL.

Phase 4 / `/v1/query` API contract: agents reference per-step results
in their merge SQL by `step_id` (e.g. `s0`, `s1`). The
`DuckDBScratchpad` actually loads each step's results under a longer
internal storage name (e.g. `step_s0_app_db_users`) to avoid collisions
between steps that share a source.

This module bridges the two — agent-facing names → storage names —
purely as a transformation on the merge_sql string the agent sent. It
runs in the API layer (called by `_run_query` in `router.py`) so that:

  * Nothing is hardcoded into the engine or the scratchpad.
  * The rewrite only happens when the agent actually submitted a
    merge_sql; otherwise this function is never called.
  * The transformation is driven by what's in the merge SQL (via
    sqlglot AST walk), not by a fixed convention.

Implementation: parse the merge SQL into a sqlglot AST, walk every
`Table` node, and rewrite the ones whose name matches a step_id from
the IR. AST-level rewriting is safe against string literals,
comment-embedded identifiers, and column names that happen to match
a step_id.
"""

from __future__ import annotations

import logging

import sqlglot
from sqlglot import expressions as exp

from faz.engine.scratchpad import _sanitize_table_name
from faz.types.ir import IRStep, IntermediateRepr

logger = logging.getLogger(__name__)


def resolve_step_aliases(merge_sql: str, ir: IntermediateRepr) -> str:
    """Rewrite `step_id` table references in merge SQL to storage names.

    Args:
        merge_sql: The agent-submitted DuckDB SELECT/CTE that joins per-step
            results, with table refs written as `s0`, `s1`, ... (or whatever
            step_ids the request used).
        ir: The IntermediateRepr the merge SQL operates on. Provides the
            `step_id → source` mapping needed to compute storage names.

    Returns:
        The same SQL with every `Table` node whose name matches a step_id
        rewritten to point at the storage table. Non-matching identifiers
        are left alone — agents can use CTEs, column qualifiers, etc.
        without interference.

    Falls back to the original string on parse failure; the downstream
    `validate_merge_sql()` will reject invalid SQL with a clear error.
    """
    alias_map: dict[str, str] = {
        step.step_id: _storage_name(step)
        for step in ir.steps
        if step.step_id
    }
    if not alias_map:
        return merge_sql

    try:
        tree = sqlglot.parse_one(merge_sql, dialect="duckdb")
    except Exception as exc:
        logger.debug("merge SQL parse failed during alias resolution: %s", exc)
        return merge_sql

    if tree is None:
        return merge_sql

    for tbl in tree.find_all(exp.Table):
        name = tbl.name
        if name not in alias_map:
            continue
        # Rewrite the FROM/JOIN target to the storage table name, but keep
        # the original step_id as a SQL alias so column references like
        # `s0.id`, `s1.name` in the merge SQL continue to bind correctly.
        # Without the alias, DuckDB's binder reports "Referenced table 's0'
        # not found" because column qualifiers aren't rewritten by
        # `find_all(Table)` (those are exp.Column nodes, not exp.Table).
        # Preserve any user-supplied alias if the merge SQL already had one.
        existing_alias = tbl.alias
        tbl.set("this", exp.to_identifier(alias_map[name]))
        if not existing_alias:
            tbl.set("alias", exp.TableAlias(this=exp.to_identifier(name)))

    return tree.sql(dialect="duckdb")


def _storage_name(step: IRStep) -> str:
    """The DuckDB table name where the engine loads this step's results.

    Mirrors the scheme in `executor._execute_steps`:
        f"step_{step.step_id}_{_sanitize_table_name(step.source)}"

    Kept here (rather than imported from the engine) so the API layer's
    contract is explicit — if the engine ever changes its scheme, this
    function moves alongside it as a single point of truth.
    """
    return f"step_{step.step_id}_{_sanitize_table_name(step.source)}"
