"""Single chokepoint for `IRStep` instantiation.

Every API/MCP/CLI surface that receives a query request funnels through
this module. It does the bookkeeping that downstream code expects but
shouldn't have to validate itself:

  - Verify each step's `database` is registered in the connector registry.
  - Verify `step_id` uniqueness within a federated request.
  - Verify `depends_on` only references known earlier step_ids.
  - Detect cycles in the DAG (topological sort).
  - Build properly-shaped `IRStep` objects with `database`/`table`/`language`
    set explicitly (Phase 1.1d schema).

Errors raise `IRBuildError` carrying a 400-status reason. Route handlers
catch and convert to HTTPException.
"""

from __future__ import annotations

from faz.connectors import ConnectorRegistry
from faz.types.ir import IntermediateRepr, IRStep

from .schemas import FederatedQueryRequest, SimpleQueryRequest


class IRBuildError(ValueError):
    """Raised when an incoming request can't be built into a valid IR."""


# ---------------------------------------------------------------------------
# Single-step
# ---------------------------------------------------------------------------


def build_simple(
    req: SimpleQueryRequest, registry: ConnectorRegistry,
) -> IntermediateRepr:
    """Build a one-step IR from /v1/query/simple body.

    Validates that `req.database` is configured in the registry. The
    table is not validated against schema (the agent may be hitting a
    table that wasn't there at startup; the connector's execute() will
    error appropriately if it doesn't exist).
    """
    _check_database(req.database, registry)
    return IntermediateRepr(steps=[
        IRStep(
            database=req.database,
            table=req.table,
            step_id="s0",
            language=req.language,
            raw_query=req.query,
        )
    ])


# ---------------------------------------------------------------------------
# Federated multi-step
# ---------------------------------------------------------------------------


def build_federated(
    req: FederatedQueryRequest, registry: ConnectorRegistry,
) -> tuple[IntermediateRepr, str | None]:
    """Build a multi-step IR from /v1/query body.

    Returns `(IntermediateRepr, merge_sql)`. `merge_sql` is whatever the
    caller submitted; the safety pipeline / merge-guard / engine validate
    it. Route handler is responsible for the "merge required when N>=2
    steps produce data" business rule because that depends on execution
    results, not on request shape.

    Validates:
      * Every step's `database` is registered.
      * `step_id` values are unique within the request.
      * `depends_on` only references step_ids that appear earlier in
        the list (a strict topological order; rejects forward refs and
        cycles in the same check).
    """
    if not req.steps:
        raise IRBuildError("'steps' must contain at least one step")

    seen_ids: set[str] = set()
    ir_steps: list[IRStep] = []

    for step in req.steps:
        if not step.step_id:
            raise IRBuildError(f"step missing 'step_id' (database={step.database})")
        if step.step_id in seen_ids:
            raise IRBuildError(f"duplicate step_id: {step.step_id!r}")

        _check_database(step.database, registry)

        for dep in step.depends_on:
            if dep == step.step_id:
                raise IRBuildError(
                    f"step {step.step_id!r} depends on itself"
                )
            if dep not in seen_ids:
                raise IRBuildError(
                    f"step {step.step_id!r} depends on unknown or "
                    f"forward-referenced step {dep!r}"
                )

        seen_ids.add(step.step_id)
        ir_steps.append(IRStep(
            database=step.database,
            table=step.table,
            step_id=step.step_id,
            language=step.language,
            raw_query=step.query,
            depends_on=list(step.depends_on),
            link_from=step.link_from,
            link_to=step.link_to,
        ))

    return IntermediateRepr(steps=ir_steps), req.merge


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _check_database(name: str, registry: ConnectorRegistry) -> None:
    """Raise IRBuildError if the database name isn't configured."""
    if not name:
        raise IRBuildError("'database' is required and cannot be empty")
    if name not in registry.configured_names:
        configured = sorted(registry.configured_names)
        raise IRBuildError(
            f"unknown database: {name!r}. Configured: {configured}"
        )
