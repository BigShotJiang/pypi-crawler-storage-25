"""Allow ``python -m faz`` as a fallback when the ``faz`` console script
isn't on ``PATH`` (common on Windows after ``pip install --user``).
"""

from __future__ import annotations

from faz.cli.main import cli

if __name__ == "__main__":
    cli()
