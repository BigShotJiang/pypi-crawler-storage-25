"""DuckDB in-memory scratchpad for cross-source merging.

Per-request :memory: instance. Created fresh, destroyed after use.
Not a BaseConnector — purpose-built staging layer.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

import duckdb

if TYPE_CHECKING:
    from faz.connectors.base import QueryResult

logger = logging.getLogger(__name__)


def _infer_duckdb_type(value: Any) -> str:
    """Map a Python value to the best DuckDB column type."""
    if value is None:
        return "VARCHAR"
    if isinstance(value, bool):
        return "BOOLEAN"
    if isinstance(value, int):
        return "BIGINT"
    if isinstance(value, float):
        return "DOUBLE"
    if isinstance(value, (dict, list)):
        return "JSON"
    return "VARCHAR"


def _sanitize_table_name(source: str) -> str:
    """Turn 'mongodb.users' into 'mongodb_users'."""
    return source.replace(".", "_").replace("-", "_").lower()


class DuckDBScratchpad:
    """In-memory DuckDB instance for cross-source merging.

    Lifecycle: one instance per execution request.
    Use as a context manager for automatic cleanup.
    """

    def __init__(self) -> None:
        self._conn = duckdb.connect(":memory:")

    def __enter__(self) -> DuckDBScratchpad:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def load_result(self, table_name: str, result: QueryResult) -> None:
        """CREATE TABLE and INSERT rows from a QueryResult.

        Type inference samples the first non-None value per column.
        Falls back to VARCHAR for all-None or mixed-type columns.
        """
        all_columns = result.columns or (list(result.rows[0].keys()) if result.rows else [])

        if not all_columns:
            return

        if not result.rows:
            cols_ddl = ", ".join(f'"{c}" VARCHAR' for c in all_columns)
            self._conn.execute(f'CREATE TABLE "{table_name}" ({cols_ddl})')
            return

        # Infer types — scan all rows for first non-None value per column
        col_types: dict[str, str] = {}
        for col in all_columns:
            inferred = "VARCHAR"
            for row in result.rows:
                val = row.get(col)
                if val is not None:
                    inferred = _infer_duckdb_type(val)
                    break
            col_types[col] = inferred

        # CREATE TABLE (drop first if retrying)
        self._conn.execute(f'DROP TABLE IF EXISTS "{table_name}"')
        cols_ddl = ", ".join(f'"{c}" {t}' for c, t in col_types.items())
        self._conn.execute(f'CREATE TABLE "{table_name}" ({cols_ddl})')

        # INSERT rows
        columns = list(col_types.keys())
        placeholders = ", ".join("?" for _ in columns)
        col_names = ", ".join(f'"{c}"' for c in columns)
        insert_sql = f'INSERT INTO "{table_name}" ({col_names}) VALUES ({placeholders})'

        for row in result.rows:
            values = []
            for col in columns:
                val = row.get(col)
                if isinstance(val, (dict, list)):
                    val = json.dumps(val)
                values.append(val)
            try:
                self._conn.execute(insert_sql, values)
            except duckdb.Error:
                # Type mismatch — retry with string coercion
                values_str = [str(v) if v is not None else None for v in values]
                try:
                    self._conn.execute(insert_sql, values_str)
                except duckdb.Error as e:
                    logger.warning("Failed to insert row into %s: %s", table_name, e)

    def execute_sql(self, sql: str) -> tuple[list[dict[str, Any]], list[str]]:
        """Run a SQL query and return (rows_as_dicts, column_names)."""
        result = self._conn.execute(sql)
        columns = [desc[0] for desc in result.description]
        raw_rows = result.fetchall()
        rows = [dict(zip(columns, row)) for row in raw_rows]
        return rows, columns

    def list_tables(self) -> list[str]:
        """Return names of all tables currently loaded."""
        result = self._conn.execute(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema = 'main'"
        )
        return [row[0] for row in result.fetchall()]

    def describe_table(self, name: str) -> list[tuple[str, str]]:
        """Return [(column_name, column_type), ...] for the given table."""
        result = self._conn.execute(
            "SELECT column_name, data_type FROM information_schema.columns "
            f"WHERE table_name = '{name}' AND table_schema = 'main'"
        )
        return [(row[0], row[1]) for row in result.fetchall()]

    def get_schema_summary(self) -> str:
        """Build a text summary of all loaded tables for LLM merge prompts."""
        lines = []
        for table in self.list_tables():
            cols = self.describe_table(table)
            col_strs = ", ".join(f"{name} {dtype}" for name, dtype in cols)
            count = self._conn.execute(
                f'SELECT COUNT(*) FROM "{table}"'
            ).fetchone()[0]
            lines.append(f'  "{table}" ({count} rows): {col_strs}')
        return "\n".join(lines) if lines else "  (no tables loaded)"

    def close(self) -> None:
        """Destroy the DuckDB instance."""
        self._conn.close()
