"""Lightweight SQL sanitiser for LLM-generated DuckDB merge queries.

The merge query runs against an ephemeral in-memory DuckDB, but we still
guard against LLM hallucinations that could trigger file I/O, external
connections, extension loading, or data mutation.
"""

from __future__ import annotations

import re

_FORBIDDEN_PATTERNS = [
    re.compile(r"\bDROP\b", re.IGNORECASE),
    re.compile(r"\bDELETE\b", re.IGNORECASE),
    re.compile(r"\bTRUNCATE\b", re.IGNORECASE),
    re.compile(r"\bALTER\b", re.IGNORECASE),
    re.compile(r"\bCREATE\b", re.IGNORECASE),
    re.compile(r"\bINSERT\b", re.IGNORECASE),
    re.compile(r"\bUPDATE\b", re.IGNORECASE),
    re.compile(r"\bATTACH\b", re.IGNORECASE),
    re.compile(r"\bCOPY\b", re.IGNORECASE),
    re.compile(r"\bEXPORT\b", re.IGNORECASE),
    re.compile(r"\bIMPORT\b", re.IGNORECASE),
    re.compile(r"\bINSTALL\b", re.IGNORECASE),
    re.compile(r"\bLOAD\b", re.IGNORECASE),
    re.compile(r"read_csv|read_parquet|read_json", re.IGNORECASE),
    re.compile(r"httpfs|postgres_scanner", re.IGNORECASE),
]


class MergeSQLGuardError(Exception):
    """Raised when merge SQL fails validation."""


def validate_merge_sql(sql: str) -> str:
    """Validate that LLM-generated merge SQL is a safe SELECT.

    Returns the SQL unchanged if valid. Raises MergeSQLGuardError otherwise.
    """
    stripped = sql.strip().rstrip(";").strip()

    if not stripped:
        raise MergeSQLGuardError("Empty merge SQL")

    upper = stripped.upper()
    if not (upper.startswith("SELECT") or upper.startswith("WITH")):
        raise MergeSQLGuardError(
            f"Merge SQL must be a SELECT or WITH statement, got: {stripped[:50]}..."
        )

    for pattern in _FORBIDDEN_PATTERNS:
        match = pattern.search(stripped)
        if match:
            raise MergeSQLGuardError(
                f"Forbidden keyword '{match.group(0)}' in merge SQL"
            )

    if ";" in stripped:
        raise MergeSQLGuardError("Multiple statements not allowed in merge SQL")

    return sql.strip()
