"""faz MODULE 5 — Execution Engine + DuckDB Scratchpad."""

from .executor import ExecutionEngine
from .merge_sql_guard import MergeSQLGuardError, validate_merge_sql
from .scratchpad import DuckDBScratchpad
from .scratchpad_store import ScratchpadStore
from .types import (
    EngineError,
    ExecutionResult,
    FailureReason,
    NON_RETRYABLE_FAILURES,
    RETRYABLE_FAILURES,
    StepResult,
    StepStatus,
)

__all__ = [
    "DuckDBScratchpad",
    "EngineError",
    "ExecutionEngine",
    "ExecutionResult",
    "FailureReason",
    "MergeSQLGuardError",
    "NON_RETRYABLE_FAILURES",
    "RETRYABLE_FAILURES",
    "ScratchpadStore",
    "StepResult",
    "StepStatus",
    "validate_merge_sql",
]
