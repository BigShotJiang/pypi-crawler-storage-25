"""Types for faz MODULE 5 — Execution Engine."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from faz.connectors.base import QueryResult
    from faz.engine.scratchpad import DuckDBScratchpad


class StepStatus(str, enum.Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class FailureReason(str, enum.Enum):
    """Classifies why a step failed — drives retry/no-retry decisions."""

    EMPTY_RESULT = "EMPTY_RESULT"
    CONNECTOR_ERROR = "CONNECTOR_ERROR"
    WRONG_RESULT = "WRONG_RESULT"
    TIMEOUT = "TIMEOUT"
    CONNECTION_FAILURE = "CONNECTION_FAILURE"


RETRYABLE_FAILURES = {
    FailureReason.EMPTY_RESULT,
    FailureReason.CONNECTOR_ERROR,
    FailureReason.WRONG_RESULT,
}

NON_RETRYABLE_FAILURES = {
    FailureReason.TIMEOUT,
    FailureReason.CONNECTION_FAILURE,
}


@dataclass
class StepResult:
    step_index: int
    status: StepStatus
    query_result: QueryResult | None = None
    error: str = ""
    failure_reason: FailureReason | None = None
    duckdb_table_name: str = ""
    execution_time_ms: float = 0.0


@dataclass
class ExecutionResult:
    """Final output of the execution engine."""

    rows: list[dict[str, Any]] = field(default_factory=list)
    columns: list[str] = field(default_factory=list)
    step_results: list[StepResult] = field(default_factory=list)
    merge_sql: str = ""
    iteration_count: int = 1
    total_llm_calls: int = 0
    total_execution_time_ms: float = 0.0
    error: str = ""
    skipped_merge: bool = False
    scratchpad: DuckDBScratchpad | None = None


class EngineError(Exception):
    """Raised for non-retryable engine failures."""

    def __init__(self, message: str, failure_reason: FailureReason | None = None):
        super().__init__(message)
        self.failure_reason = failure_reason
