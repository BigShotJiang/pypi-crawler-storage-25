"""ScratchpadStore — keeps DuckDB scratchpads alive with TTL-based eviction.

After Module 5 execution, the scratchpad is handed here so clients can
paginate the raw results via GET /results/{request_id}?page=N.

The store runs a background asyncio task that reaps expired entries.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from faz.engine.scratchpad import DuckDBScratchpad

logger = logging.getLogger(__name__)

DEFAULT_TTL_SECONDS = 300.0   # 5 minutes
REAP_INTERVAL_SECONDS = 30.0  # check every 30s


class ScratchpadStore:
    """Thread-safe (asyncio) store for DuckDB scratchpads with TTL eviction."""

    def __init__(
        self,
        *,
        ttl_seconds: float = DEFAULT_TTL_SECONDS,
        reap_interval: float = REAP_INTERVAL_SECONDS,
    ) -> None:
        self._ttl = ttl_seconds
        self._reap_interval = reap_interval
        self._entries: dict[str, tuple[DuckDBScratchpad, float]] = {}
        self._lock = asyncio.Lock()
        self._reaper_task: asyncio.Task[None] | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def put(self, request_id: str, scratchpad: DuckDBScratchpad) -> None:
        """Store a scratchpad. Closes any previous one under the same ID.

        Bug fix #5 (build-plan.md): protect against concurrent put/get/reap
        racing on the same dict.
        """
        async with self._lock:
            old = self._entries.get(request_id)
            if old is not None:
                try:
                    old[0].close()
                except Exception:
                    pass
            self._entries[request_id] = (scratchpad, time.monotonic())
        logger.debug("Stored scratchpad %s", request_id)

    async def get(self, request_id: str) -> DuckDBScratchpad | None:
        """Look up a scratchpad and refresh its TTL. Returns None if expired/missing."""
        async with self._lock:
            entry = self._entries.get(request_id)
            if entry is None:
                return None
            scratchpad, _ = entry
            # Touch — reset TTL on access
            self._entries[request_id] = (scratchpad, time.monotonic())
            return scratchpad

    async def remove(self, request_id: str) -> None:
        """Remove and close a scratchpad."""
        async with self._lock:
            entry = self._entries.pop(request_id, None)
        if entry is not None:
            try:
                entry[0].close()
            except Exception:
                pass
            logger.debug("Removed scratchpad %s", request_id)

    @property
    def size(self) -> int:
        return len(self._entries)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the background reaper task."""
        if self._reaper_task is None:
            self._reaper_task = asyncio.create_task(self._reap_loop())
            logger.info(
                "ScratchpadStore started (TTL=%.0fs, reap_interval=%.0fs)",
                self._ttl, self._reap_interval,
            )

    async def stop(self) -> None:
        """Cancel reaper and close all scratchpads."""
        if self._reaper_task is not None:
            self._reaper_task.cancel()
            try:
                await self._reaper_task
            except asyncio.CancelledError:
                pass
            self._reaper_task = None

        for request_id, (scratchpad, _) in list(self._entries.items()):
            try:
                scratchpad.close()
            except Exception:
                pass
        self._entries.clear()
        logger.info("ScratchpadStore stopped, all scratchpads closed")

    # ------------------------------------------------------------------
    # Background reaper
    # ------------------------------------------------------------------

    async def _reap_loop(self) -> None:
        """Periodically evict expired scratchpads."""
        try:
            while True:
                await asyncio.sleep(self._reap_interval)
                await self._reap()
        except asyncio.CancelledError:
            return

    async def _reap(self) -> None:
        """Single reap pass — evict entries older than TTL."""
        now = time.monotonic()
        expired: list[str] = []

        async with self._lock:
            for request_id, (_, timestamp) in self._entries.items():
                if now - timestamp > self._ttl:
                    expired.append(request_id)

            for request_id in expired:
                entry = self._entries.pop(request_id, None)
                if entry is not None:
                    try:
                        entry[0].close()
                    except Exception:
                        pass

        if expired:
            logger.info("Reaped %d expired scratchpad(s): %s", len(expired), expired)
