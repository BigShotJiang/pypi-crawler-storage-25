"""Post-processing enum mapper — converts enum string values to numeric codes.

Parses config files (referenced by CONFIGS env var) to build a reverse lookup
from enum string values to their numeric codes. Applied to query results after
execution so the LLM doesn't need the full mapping in its prompt.

Config format (markdown):
    ### column_name
    enum_value_001=1, enum_value_002=2, ...
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _parse_mappings_from_md(content: str) -> dict[str, dict[str, int]]:
    """Parse column → {enum_string: number} mappings from markdown config."""
    mappings: dict[str, dict[str, int]] = {}
    current_col: str | None = None

    for line in content.splitlines():
        # Match ### column_name headers
        header = re.match(r"^###\s+(\S+)", line)
        if header:
            current_col = header.group(1)
            continue

        if current_col and "=" in line:
            col_map: dict[str, int] = {}
            for pair in line.split(","):
                pair = pair.strip()
                if "=" not in pair:
                    continue
                val, code = pair.rsplit("=", 1)
                try:
                    col_map[val.strip()] = int(code.strip())
                except ValueError:
                    continue
            if col_map:
                mappings[current_col] = col_map
            current_col = None

    return mappings


def _load_mappings_from_files(filenames: list[str]) -> dict[str, dict[str, int]]:
    """Parse enum mappings from the given config files. Paths are resolved
    relative to the project root unless absolute."""
    project_root = Path(__file__).resolve().parent.parent.parent
    all_mappings: dict[str, dict[str, int]] = {}

    for filename in filenames:
        filename = filename.strip()
        if not filename:
            continue
        config_path = project_root / filename
        if not config_path.exists():
            continue
        try:
            with open(config_path, encoding="utf-8") as f:
                content = f.read()
            if filename.endswith(".md") or filename.endswith(".txt"):
                mappings = _parse_mappings_from_md(content)
                all_mappings.update(mappings)
        except OSError as e:
            logger.warning("Failed to read config %s: %s", filename, e)

    return all_mappings


def _env_config_files() -> list[str]:
    raw = os.getenv("CONFIGS", "")
    if not raw:
        return []
    return [f.strip() for f in raw.split(",") if f.strip()]


def _load_all_mappings() -> dict[str, dict[str, int]]:
    """Load enum mappings from all config files named in the CONFIGS env var."""
    files = _env_config_files()
    if not files:
        return {}
    return _load_mappings_from_files(files)


def reload_enum_mappings(extra_files: list[str] | tuple[str, ...] = ()) -> dict[str, dict[str, int]]:
    """Re-parse env CONFIGS + ``extra_files`` and reassign ``ENUM_MAPPINGS``."""
    global ENUM_MAPPINGS
    merged = list(dict.fromkeys([*_env_config_files(), *extra_files]))
    ENUM_MAPPINGS = _load_mappings_from_files(merged) if merged else {}
    return ENUM_MAPPINGS


# Load once at import time
ENUM_MAPPINGS: dict[str, dict[str, int]] = _load_all_mappings()
if ENUM_MAPPINGS:
    logger.info("Enum mapper loaded: %d columns, %d total values",
                len(ENUM_MAPPINGS), sum(len(v) for v in ENUM_MAPPINGS.values()))
else:
    logger.info("Enum mapper: no mappings loaded (CONFIGS=%s)", os.getenv("CONFIGS", ""))


def apply_enum_mapping(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Replace enum string values with their numeric codes in query results.

    Only transforms columns that have a known mapping. Passes through all
    other values unchanged.
    """
    if not ENUM_MAPPINGS or not rows:
        return rows

    # Only check columns that exist in both the rows and our mappings
    if rows:
        row_keys = set(rows[0].keys())
        mapped_cols = row_keys & set(ENUM_MAPPINGS.keys())
        if not mapped_cols:
            return rows

    result = []
    for row in rows:
        new_row = dict(row)
        for col in mapped_cols:
            val = new_row.get(col)
            if isinstance(val, str) and val in ENUM_MAPPINGS[col]:
                new_row[col] = ENUM_MAPPINGS[col][val]
        result.append(new_row)

    return result
