"""``faz policy`` — print the loaded permission tree.

Reads :class:`PolicyLoader` directly (no need for the server to be
running). Output groups by database: baseline first, then any per-table
overrides, then the global ``safety:`` block.
"""

from __future__ import annotations

from collections import defaultdict

import click

from faz.runtime import resolve_config_path


@click.command("policy")
def policy_cmd() -> None:
    """Print the loaded permission policy from faz.yaml."""
    # Imported lazily so `faz --help` doesn't pay for connector imports.
    from faz.auth.policy_loader import PolicyLoader

    pl = PolicyLoader(resolve_config_path())

    by_db: dict[str, dict] = defaultdict(lambda: {"baseline": None, "overrides": {}})
    for p in pl.permissions:
        bucket = by_db[p.database_uri]
        if p.table_name == "*":
            bucket["baseline"] = p.access_level.value
        else:
            bucket["overrides"][p.table_name] = p.access_level.value

    if not by_db:
        click.echo("(no permissions loaded — check faz.yaml)")
    for db in sorted(by_db):
        info = by_db[db]
        click.echo(db)
        baseline = info["baseline"] or "<none — every table will be denied>"
        click.echo(f"    baseline: {baseline}")
        if info["overrides"]:
            click.echo("    overrides:")
            width = max(len(t) for t in info["overrides"])
            for tbl in sorted(info["overrides"]):
                click.echo(f"        {tbl:<{width}}  →  {info['overrides'][tbl]}")
        click.echo()

    if pl.safety:
        click.echo("safety:")
        width = max(len(k) for k in pl.safety)
        for k in sorted(pl.safety):
            click.echo(f"    {k:<{width}}  =  {pl.safety[k]}")
