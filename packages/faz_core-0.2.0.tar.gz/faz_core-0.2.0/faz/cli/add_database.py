"""``faz add-database`` — interactive type-aware DB add.

After picking a name and type, the prompts adapt to the chosen
connector — e.g. ``dynamodb`` asks for region + endpoint_url instead
of database/username/password; ``qdrant`` skips auth entirely;
``pinecone`` asks for an api_key in extra.

After the prompts, the config is health-checked. If the connection
fails, nothing is written. On success, the new entry is appended to
``faz.yaml`` via ``ruamel.yaml`` round-trip so existing comments and
ordering survive intact.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import click
from ruamel.yaml import YAML

from faz.connectors import ConnectionConfig, ConnectorRegistry, ConnectorType
from faz.connectors.base import AccessMode
from faz.runtime import resolve_config_path


# ---------------------------------------------------------------------------
# Per-type prompt schema
# ---------------------------------------------------------------------------


@dataclass
class _Field:
    """One prompt for the interactive flow.

    ``key``      — config-key name (top-level field, or key inside ``extra``).
    ``label``    — human-readable label shown in the prompt.
    ``default``  — default value (or None for "no default").
    ``hide_input`` — for passwords / API keys.
    ``optional``  — pressing Enter on no-default skips the field.
    ``cast``     — coerce raw string input (e.g. int for port).
    ``target``   — "top" (top-level ConnectionConfig field) or "extra".
    """
    key: str
    label: str
    default: Any = None
    hide_input: bool = False
    optional: bool = False
    cast: Any = str
    target: str = "top"


_HOST = _Field("host", "Host", default="localhost")
_USER = _Field("username", "Username")
_PASS = _Field("password", "Password", hide_input=True)
_USER_OPT = _Field("username", "Username (optional)", optional=True)
_PASS_OPT = _Field("password", "Password (optional)", hide_input=True, optional=True)


def _port(default: int) -> _Field:
    return _Field("port", "Port", default=default, cast=int)


def _db(default: str | None = None) -> _Field:
    return _Field("database", "Database", default=default)


_PROMPTS_BY_TYPE: dict[str, list[_Field]] = {
    "postgresql":   [_HOST, _port(5432),  _db(),         _USER, _PASS],
    "mysql":        [_HOST, _port(3306),  _db(),         _USER, _PASS],
    "oracle":       [_HOST, _port(1521),  _db("FREEPDB1"), _USER, _PASS],
    "mongodb":      [_HOST, _port(27017), _db(),         _USER, _PASS],
    "couchdb":      [_HOST, _port(5984),  _db(),         _USER, _PASS],
    "cassandra":    [_HOST, _port(9042),  _db(),         _USER_OPT, _PASS_OPT],
    "elasticsearch": [_HOST, _port(9200), _USER, _PASS],
    "opensearch":   [_HOST, _port(9201),  _USER, _PASS],
    "weaviate":     [_HOST, _port(8080),
                     _Field("grpc_port", "gRPC port", default=50051,
                            cast=int, target="extra")],
    "qdrant":       [_HOST, _port(6333)],
    "milvus":       [_HOST, _port(19530), _db("default")],
    "pinecone":     [_HOST, _port(5081),
                     _Field("api_key", "API key", default="pclocal",
                            hide_input=True, target="extra")],
    "dynamodb":     [
        _Field("region", "AWS region", default="us-east-1", target="extra"),
        _Field("endpoint_url", "Endpoint URL",
               default="http://localhost:8000", target="extra"),
        _Field("username", "AWS access key (optional, dummy for local)",
               default="dummy", optional=True),
        _Field("password", "AWS secret key (optional, dummy for local)",
               default="dummy", hide_input=True, optional=True),
    ],
    "neo4j":        [_HOST, _port(7687), _db("neo4j"), _USER, _PASS],
}


# ---------------------------------------------------------------------------
# Click command
# ---------------------------------------------------------------------------


@click.command("add-database")
@click.option(
    "--access",
    type=click.Choice(["R", "W", "RW", "RA", "RWA", "A"], case_sensitive=False),
    default="R",
    show_default=True,
    help="Permission level for the new database (R = read-only).",
)
def add_database_cmd(access: str) -> None:
    """Interactively add a database to faz.yaml (type-aware prompts)."""
    cfg_path = _faz_yaml_path()
    if not cfg_path.exists():
        raise click.ClickException(
            f"{cfg_path} not found. Run `faz init` first."
        )

    name = click.prompt("Connector name (used as key in faz.yaml)", type=str)
    type_ = click.prompt(
        "Type", type=click.Choice(sorted(_PROMPTS_BY_TYPE.keys())),
    )

    fields = _PROMPTS_BY_TYPE[type_]
    top_level: dict[str, Any] = {}
    extra: dict[str, Any] = {}
    for f in fields:
        value = _prompt_field(f)
        if value is None or value == "":
            continue
        target_dict = top_level if f.target == "top" else extra
        target_dict[f.key] = value

    config = ConnectionConfig(
        connector_type=ConnectorType(type_),
        name=name,
        host=str(top_level.get("host", "localhost")),
        port=int(top_level.get("port") or _default_port(type_)),
        database=str(top_level.get("database", "")),
        username=str(top_level.get("username", "")),
        password=str(top_level.get("password", "")),
        ssl=False,
        access_mode=AccessMode.READ_ONLY,
        extra=extra,
    )

    click.echo()
    click.echo(f"Testing connection to {name} ({type_})…")
    ok, err = _health_check(config)
    if not ok:
        click.echo(click.style(f"  ✗ {err}", fg="red"))
        raise click.ClickException(
            "connection test failed; faz.yaml was NOT modified"
        )
    click.echo(click.style("  ✓ connected", fg="green"))

    access_upper = access.upper()
    _append_to_yaml(cfg_path, name, type_, top_level, extra, access=access_upper)
    click.echo()
    click.echo(f"Wrote {name} ({type_}) into {cfg_path} with permission '{access_upper}'.")
    click.echo("Restart `faz serve` to pick up the change.")


# ---------------------------------------------------------------------------
# Prompting + health check
# ---------------------------------------------------------------------------


def _prompt_field(f: _Field) -> Any:
    """Prompt for one field, casting + handling optionals."""
    kw: dict[str, Any] = {"text": f.label, "hide_input": f.hide_input}
    if f.default is not None:
        kw["default"] = f.default
    elif f.optional:
        kw["default"] = ""
        kw["show_default"] = False
    raw = click.prompt(**kw)
    if f.optional and raw == "":
        return None
    try:
        return f.cast(raw)
    except (ValueError, TypeError) as exc:
        raise click.ClickException(f"invalid value for {f.label!r}: {exc}")


def _default_port(type_: str) -> int:
    """Fall back to the known per-type default if no port was prompted."""
    return {
        "postgresql": 5432, "mysql": 3306, "oracle": 1521,
        "mongodb": 27017, "couchdb": 5984, "cassandra": 9042,
        "elasticsearch": 9200, "opensearch": 9201,
        "weaviate": 8080, "qdrant": 6333, "milvus": 19530, "pinecone": 5081,
        "dynamodb": 8000, "neo4j": 7687,
    }.get(type_, 0)


def _health_check(config: ConnectionConfig) -> tuple[bool, str]:
    """Open a temporary connector, ping it, close. Returns (ok, error)."""

    async def _go() -> tuple[bool, str]:
        registry = ConnectorRegistry()
        try:
            await registry.register(config)
            connector = registry._connectors[config.name]
            ok = bool(await connector.health_check())
            return ok, "" if ok else "health_check returned False"
        except Exception as exc:  # noqa: BLE001 — surface every failure mode
            return False, str(exc)
        finally:
            try:
                await registry.shutdown()
            except Exception:
                pass

    return asyncio.run(_go())


# ---------------------------------------------------------------------------
# YAML round-trip
# ---------------------------------------------------------------------------


def _faz_yaml_path() -> Path:
    """Use FAZ_CONFIG / ./faz.yaml / repo faz.yaml in that order."""
    explicit = resolve_config_path()
    if explicit:
        return explicit
    cwd = Path.cwd() / "faz.yaml"
    if cwd.exists():
        return cwd
    # Fall back to the repo's faz.yaml (3 dirs up from this file).
    return Path(__file__).resolve().parent.parent.parent / "faz.yaml"


def _append_to_yaml(
    path: Path, name: str, type_: str,
    top_level: dict[str, Any], extra: dict[str, Any],
    access: str = "R",
) -> None:
    """Append the new database entry to ``databases:`` preserving comments.

    Also adds a matching ``permissions:`` entry (default ``R`` = read-only)
    so the database is immediately usable after `faz serve` restart. If a
    permissions entry for ``name`` already exists, it is left untouched.
    """
    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.indent(mapping=2, sequence=4, offset=2)

    with path.open(encoding="utf-8") as fh:
        data = yaml.load(fh)

    if data is None or "databases" not in data:
        raise click.ClickException(
            f"{path} has no top-level `databases:` block; refusing to mutate."
        )

    if data["databases"] is None:
        data["databases"] = []

    entry: dict[str, Any] = {"name": name, "type": type_}
    # Order top-level fields in the canonical layout.
    for k in ("host", "port", "database", "username", "password"):
        if k in top_level:
            entry[k] = top_level[k]
    if extra:
        entry["extra"] = extra

    data["databases"].append(entry)

    if "permissions" not in data or data["permissions"] is None:
        data["permissions"] = []

    if not any(
        isinstance(p, dict) and p.get("database") == name
        for p in data["permissions"]
    ):
        data["permissions"].append({"database": name, "access": access})

    with path.open("w", encoding="utf-8") as fh:
        yaml.dump(data, fh)
