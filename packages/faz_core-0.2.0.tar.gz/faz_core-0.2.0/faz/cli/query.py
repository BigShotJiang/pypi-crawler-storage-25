"""``faz query "<sql>"`` — run a single query through the safety pipeline.

Standalone: builds the faz runtime in-process (no ``faz serve`` needed)
and calls ``faz.api.handlers.query_simple`` directly. The trade-off is
~5-10s of connector-init time on every invocation; if you're running
many queries back-to-back, leave ``faz serve`` running and use ``curl``
or ``faz mcp`` instead.

Audit log entries from this surface have ``transport="cli"``,
distinguishable from ``rest/local`` and ``mcp/stdio`` in
``faz logs``.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import click

from faz.api import handlers
from faz.api.handlers import HandlerError
from faz.api.schemas import SimpleQueryRequest
from faz.runtime import build_runtime, resolve_config_path, shutdown_runtime


@click.command("query")
@click.argument("query", required=True)
@click.option("--database", required=True, help="Connector name from faz.yaml.")
@click.option("--table", default="", help="Declared target table (recommended).")
@click.option(
    "--language", default=None,
    help=(
        "Query language: sql / mql / cypher / es_dsl / vector / dynamo / "
        "couchdb. Omit to let faz infer from the connector type "
        "(mongodb → MQL, neo4j → CYPHER, etc.)."
    ),
)
def query_cmd(
    query: str, database: str, table: str, language: str | None,
) -> None:
    """Run one query against the configured DBs and pretty-print the result.

    Standalone — opens connections to every database in faz.yaml on
    invocation, runs the query through the safety pipeline, then closes
    everything. No ``faz serve`` required.
    """
    asyncio.run(_run(query, database, table, language))


async def _run(
    query: str, database: str, table: str, language: str | None,
) -> None:
    rt = await build_runtime(resolve_config_path())
    try:
        body = SimpleQueryRequest(
            database=database, table=table, language=language, query=query,
        )
        try:
            envelope = await handlers.query_simple(
                body,
                registry=rt.registry,
                policy=rt.policy,
                pipeline=rt.pipeline,
                engine=rt.engine,
                scratchpads=rt.scratchpads,
                audit=rt.audit,
                transport="cli",
            )
        except HandlerError as exc:
            # 403 → blocked envelope (dict); 400/404/500 → plain string detail.
            if isinstance(exc.detail, dict):
                _render_blocked(exc.detail)
                raise click.exceptions.Exit(code=2)
            raise click.ClickException(str(exc.detail))
    finally:
        await shutdown_runtime(rt)

    _render_success(envelope)


def _render_success(envelope: dict[str, Any]) -> None:
    data = envelope.get("data") or {}
    rows = data.get("rows") or []
    columns = data.get("columns") or (list(rows[0].keys()) if rows else [])
    safety = envelope.get("safety") or {}
    meta = envelope.get("metadata") or {}

    if not columns:
        click.echo("(no columns)")
        return

    if not rows:
        click.echo("(0 rows)")
    else:
        _render_table(columns, rows)

    click.echo()
    click.echo(
        f"  {len(rows)} row(s) in {meta.get('execution_time_ms', 0):.1f}ms — "
        f"stages: {','.join(safety.get('stages_passed') or [])}"
    )
    for warning in safety.get("warnings") or []:
        click.echo(f"  ⚠ {warning}")


def _render_blocked(envelope: dict[str, Any]) -> None:
    """Pretty-print a 4xx/5xx envelope.

    Two shapes can land here:
      * 403 from the safety pipeline — ``error`` is a dict with
        ``stage`` / ``reason`` / ``suggestion`` keys.
      * 5xx from an engine / connector failure — ``error`` is a plain
        string describing what went wrong downstream.

    Render both consistently so the CLI doesn't crash when the engine
    surfaces a string instead of the structured envelope.
    """
    err = envelope.get("error")
    click.echo(click.style("BLOCKED", fg="red", bold=True))
    if isinstance(err, dict):
        click.echo(f"  stage:      {err.get('stage', '?')}")
        click.echo(f"  reason:     {err.get('reason', '')}")
        suggestion = err.get("suggestion")
        if suggestion:
            click.echo(f"  suggestion: {suggestion}")
    else:
        status = envelope.get("status", "?")
        click.echo(f"  status:     {status}")
        click.echo(f"  error:      {err}")


def _render_table(columns: list[str], rows: list[dict[str, Any]]) -> None:
    """Render rows as a simple aligned ASCII table — no external dep."""
    str_rows = [[_cell(row.get(c)) for c in columns] for row in rows]
    widths = [
        max(len(c), *(len(r[i]) for r in str_rows))
        for i, c in enumerate(columns)
    ]

    def _fmt(parts: list[str]) -> str:
        return "  ".join(p.ljust(w) for p, w in zip(parts, widths))

    sep = "  ".join("-" * w for w in widths)
    click.echo(_fmt(columns))
    click.echo(sep)
    for r in str_rows:
        click.echo(_fmt(r))


def _cell(value: Any) -> str:
    """Stringify a row value, keeping None and dicts/lists readable."""
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, default=str)
    return str(value)
