"""``faz serve`` — programmatic uvicorn launcher.

Binds 127.0.0.1 by default. ``--host 0.0.0.0`` (or any non-loopback)
prints a clear warning before listening — faz has no built-in remote
auth, so anything beyond loopback should sit behind a reverse proxy.
"""

from __future__ import annotations

import click

_LOOPBACK = frozenset({"127.0.0.1", "::1", "localhost"})


@click.command("serve")
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", type=int, default=8787, show_default=True)
def serve_cmd(host: str, port: int) -> None:
    """Start the faz REST API."""
    if host not in _LOOPBACK:
        click.echo(
            f"warning: binding {host!r} exposes faz off-loopback. faz has\n"
            "         no built-in remote auth — put a reverse proxy with\n"
            "         your own auth (nginx / Cloudflare Tunnel / Tailscale)\n"
            "         in front before going to prod.",
            err=True,
        )

    # Imported here so the CLI loads instantly without paying uvicorn's
    # import cost for unrelated commands.
    import uvicorn

    # Pass the app object directly (not the import string "main:app") so
    # `faz serve` works no matter what the user's cwd is — `main.py` lives
    # at the project root and isn't part of the installed package.
    from faz.app import app

    uvicorn.run(app, host=host, port=port)
