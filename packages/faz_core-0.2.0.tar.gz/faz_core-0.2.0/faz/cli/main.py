"""faz CLI entry point.

    faz init                  generate faz.yaml + .faz/
    faz serve                 start REST API on :8787
    faz query "<sql>"         run a single query through the safety pipeline
    faz test                  exercise safety against the configured DBs
    faz logs                  pretty-print / tail the audit JSONL
    faz add-database          interactive helper (type-aware prompts)
    faz policy                print the loaded permission tree
    faz mcp                   run the MCP stdio server (used by clients)
    faz mcp install           write Claude Desktop / Cursor configs
"""

from __future__ import annotations

import click

from faz.cli.add_database import add_database_cmd
from faz.cli.init import init_cmd
from faz.cli.logs import logs_cmd
from faz.cli.policy import policy_cmd
from faz.cli.query import query_cmd
from faz.cli.serve import serve_cmd
from faz.cli.test_cmd import test_cmd


@click.group()
@click.version_option(package_name="faz-core", prog_name="faz")
def cli() -> None:
    """faz — safe multi-database access for AI agents."""


cli.add_command(init_cmd)
cli.add_command(serve_cmd)
cli.add_command(query_cmd)
cli.add_command(test_cmd)
cli.add_command(logs_cmd)
cli.add_command(add_database_cmd)
cli.add_command(policy_cmd)


@cli.group("mcp", invoke_without_command=True)
@click.pass_context
def mcp_group(ctx: click.Context) -> None:
    """Run or install the faz MCP stdio server."""
    if ctx.invoked_subcommand is None:
        from faz.mcp.server import main as mcp_main
        mcp_main()


@mcp_group.command("install")
@click.option(
    "--dry-run", is_flag=True,
    help="Print the JSON that would be written, without touching files.",
)
@click.option(
    "--target",
    type=click.Choice(
        ["claude", "claude-code", "cursor", "openclaw", "all"],
        case_sensitive=False,
    ),
    default="all",
    help=(
        "Which MCP client config to write. ``claude`` = Claude Desktop "
        "(~/.config/Claude/claude_desktop_config.json), ``claude-code`` "
        "= Claude Code CLI tool (~/.claude.json, global scope — applies "
        "to every project). Defaults to all detected clients including "
        "claude-code. When combined with --path, the actual write goes "
        "to whatever --path says; --target still drives the JSON nesting."
    ),
)
@click.option(
    "--path", "path_",
    type=click.Path(dir_okay=False, resolve_path=True),
    default=None,
    help=(
        "Override the auto-detected config location and write the faz "
        "mcpServers entry to this exact file. Useful when Claude / "
        "Cursor lives in a non-standard place, when previewing the "
        "merge to /tmp/foo.json, or when shipping a config to a "
        "teammate."
    ),
)
def install_cmd(dry_run: bool, target: str, path_: str | None) -> None:
    """Write Claude Desktop / Cursor MCP configs to point them at faz."""
    from pathlib import Path

    from faz.mcp.install import InstallTarget, install

    targets = None
    if path_:
        # Single explicit path overrides auto-detection. The --target
        # flag still drives two things: the bracket label in the
        # printout, AND the JSON nesting path (Claude / Cursor use the
        # flat ``mcpServers``; OpenClaw nests ``mcp.servers``;
        # Claude Code nests ``projects.<cwd>.mcpServers``). ``all``
        # collapses to ``custom`` (flat ``mcpServers``) since there's
        # only one file being written and we have no client hint.
        t = target.lower()
        if t == "openclaw":
            targets = [InstallTarget(
                client="openclaw",
                path=Path(path_),
                nest_path=("mcp", "servers"),
            )]
        elif t == "claude-code":
            targets = [InstallTarget(client="claude-code", path=Path(path_))]
        else:
            label = t if t in ("claude", "cursor") else "custom"
            targets = [InstallTarget(client=label, path=Path(path_))]

    reports = install(target=target.lower(), dry_run=dry_run, targets=targets)
    for r in reports:
        click.echo(f"[{r.client}] {r.path}: {r.status}")
        if r.detail:
            click.echo(f"           {r.detail}")
        if r.rendered is not None:
            click.echo()
            click.echo(r.rendered, nl=False)
            click.echo()


if __name__ == "__main__":
    cli()
