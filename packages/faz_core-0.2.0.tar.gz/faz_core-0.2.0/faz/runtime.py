"""Shared runtime bootstrap for the REST and MCP entry points.

Both ``faz/main.py`` (FastAPI lifespan) and ``faz/src/mcp/server.py``
(MCP stdio) need the same set of singletons:

  * :class:`PolicyLoader`     loaded from ``faz.yaml``
  * :class:`ConnectorRegistry` with every configured DB connection
                              attempted (failures are logged, not fatal)
  * :class:`ScratchpadStore`  with its reaper task running
  * :class:`SafetyPipeline`   stateless 5-stage pipeline
  * :class:`ExecutionEngine`  bound to the registry
  * :class:`AuditLogger`      writing to ``FAZ_AUDIT_LOG`` if set

Lifting this into one module keeps the per-DB fail-soft behaviour (one
broken connection should NOT prevent faz from booting — it just shows
up as ``reachable: false`` in ``/v1/databases``) in a single place.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path

from faz.audit.logger import AuditLogger
from faz.auth.policy_loader import PolicyLoader
from faz.connectors import ConnectorRegistry
from faz.engine.executor import ExecutionEngine
from faz.engine.scratchpad_store import ScratchpadStore
from faz.safety.pipeline import SafetyPipeline

logger = logging.getLogger("faz.runtime")


__all__ = [
    "Runtime",
    "build_runtime",
    "shutdown_runtime",
    "resolve_config_path",
]


@dataclass
class Runtime:
    """Bundle of singletons that handlers need.

    Attached to ``app.state`` for FastAPI dependency injection and held
    directly by the MCP server for tool-call dispatch. Same instances
    in both surfaces — lifespan is identical.
    """

    policy: PolicyLoader
    registry: ConnectorRegistry
    scratchpads: ScratchpadStore
    pipeline: SafetyPipeline
    engine: ExecutionEngine
    audit: AuditLogger


def resolve_config_path() -> Path | None:
    """Find the ``faz.yaml`` to load.

    Resolution order:
      1. ``FAZ_CONFIG`` env var (explicit override; what `faz mcp install`
         bakes into the Claude Desktop / Cursor configs).
      2. ``./faz.yaml`` in the current working directory — so users who
         run ``faz query`` / ``faz policy`` / ``faz test`` from their own
         project dir get THEIR config, not whatever the package was
         installed alongside.
      3. ``None`` → :func:`faz.config.db_loader._resolve_config_path`
         takes over with its own fallback chain (and, if nothing is
         found, raises with a "Run `faz init`" hint).
    """
    env_path = os.getenv("FAZ_CONFIG")
    if env_path:
        return Path(env_path)

    cwd_yaml = Path.cwd() / "faz.yaml"
    if cwd_yaml.is_file():
        return cwd_yaml

    return None


async def build_runtime(config_path: Path | None = None) -> Runtime:
    """Load policy, connect every DB (fail-soft), start the scratchpad reaper.

    A single failing connector is logged at WARNING and stored as a
    config-only entry on the registry so ``/v1/databases`` can still
    report ``reachable: false`` for it instead of hiding it.
    """
    policy = PolicyLoader(config_path)
    logger.info(
        "loaded policy with %d permission row(s) and %d safety key(s)",
        len(policy.permissions), len(policy.safety),
    )

    registry = ConnectorRegistry()
    failed: list[tuple[str, str]] = []
    for cfg in policy._config.databases:
        try:
            await registry.register(cfg)
            logger.info(
                "connected %s (%s @ %s:%s)",
                cfg.name, cfg.connector_type.value, cfg.host, cfg.port,
            )
        except Exception as exc:
            failed.append((cfg.name, str(exc)))
            registry.add_config(cfg)
            logger.warning(
                "FAILED to connect %s — %s. Continuing without it.",
                cfg.name, exc,
            )

    scratchpads = ScratchpadStore()
    await scratchpads.start()

    if failed:
        logger.warning(
            "%d database(s) failed to connect at startup: %s",
            len(failed), ", ".join(name for name, _ in failed),
        )

    return Runtime(
        policy=policy,
        registry=registry,
        scratchpads=scratchpads,
        # Pass the loaded safety block so guardrails picks up
        # max_rows_per_query / query_timeout_seconds from faz.yaml
        # instead of using hardcoded defaults.
        pipeline=SafetyPipeline(safety_config=policy.safety),
        engine=ExecutionEngine(registry),
        audit=AuditLogger(audit_file=os.getenv("FAZ_AUDIT_LOG")),
    )


async def shutdown_runtime(rt: Runtime) -> None:
    """Reverse-order teardown: stop the reaper, then close all connectors."""
    logger.info("shutting down")
    await rt.scratchpads.stop()
    await rt.registry.shutdown()
