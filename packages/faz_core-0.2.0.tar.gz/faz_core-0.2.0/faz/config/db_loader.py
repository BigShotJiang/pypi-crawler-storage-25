"""Load database connections + permission policy + safety defaults from faz.yaml.

faz.yaml is the single config file. It contains three top-level sections:

  databases:    list of connection configs (parsed by load_db_configs)
  permissions:  per-database baseline + optional per-table overrides
  safety:       global safety defaults (max_rows_per_query, etc.)

`load_faz_config(path)` is the unified entry point and returns a `FazConfig`
object with all three. `load_db_configs(path)` is kept unchanged for Phase 0
back-compat (returns just the databases list).

The default config path lookup tries `faz.yaml` first and falls back to
`database.yaml` so older Phase 0 setups keep working.

Per-connection access_mode is intentionally absent from the YAML schema: the
ConnectionConfig stays READ_ONLY as a defense-in-depth measure. Write access
is controlled exclusively by the per-table RBAC matrix (Permission.access_level
+ AccessMode), enforced by RBACGate at request time.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from faz.auth.types import Permission
from faz.connectors.base import AccessMode, ConnectionConfig, ConnectorType
from faz.safety.types import AccessMode as PermissionMode

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Unified faz.yaml config
# ---------------------------------------------------------------------------


@dataclass
class FazConfig:
    """Everything loaded from faz.yaml in one object.

    `permissions` is a flat list of Permission rows. Per-database baselines
    have `table_name == "*"`; per-table overrides have a specific table name.
    RBACGate's lookup walks specific overrides first, then the wildcard.

    `safety` is intentionally a raw dict for Phase 1 — Phase 3 (sensitive
    columns) and the Phase 4 rate limiter will type the keys they care
    about (max_rows_per_query, queries_per_minute, query_timeout_seconds,
    auto_block_sensitive, sensitive_patterns).
    """

    databases: list[ConnectionConfig] = field(default_factory=list)
    permissions: list[Permission] = field(default_factory=list)
    safety: dict[str, Any] = field(default_factory=dict)


def load_faz_config(path: str | Path | None = None) -> FazConfig:
    """Parse faz.yaml and return databases + permissions + safety defaults.

    Args:
        path: Path to faz.yaml. Defaults to `faz.yaml` in the project root,
              falling back to `database.yaml` for Phase 0 back-compat.

    Raises:
        FileNotFoundError: if neither faz.yaml nor database.yaml exists.
        ValueError: on malformed entries.
    """
    resolved = _resolve_config_path(path)

    with open(resolved, encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    if not isinstance(data, dict):
        raise ValueError(
            f"{resolved.name} must be a mapping at the top level "
            f"(got {type(data).__name__})."
        )

    databases = _parse_databases(data, resolved)
    permissions = _parse_permissions(data.get("permissions"), resolved)
    safety = _parse_safety(data.get("safety"))

    logger.info(
        "Loaded faz config from %s: %d database(s), %d permission row(s), "
        "safety keys=%s",
        resolved, len(databases), len(permissions), sorted(safety.keys()),
    )
    return FazConfig(databases=databases, permissions=permissions, safety=safety)


def _resolve_config_path(path: str | Path | None) -> Path:
    """Find faz.yaml (preferred) or fall back to database.yaml."""
    if path is not None:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"config file not found: {p}")
        return p

    project_root = Path(__file__).resolve().parent.parent.parent
    for candidate in ("faz.yaml", "database.yaml"):
        p = project_root / candidate
        if p.exists():
            return p

    raise FileNotFoundError(
        f"no faz.yaml or database.yaml in {project_root}. "
        "Run `faz init` to generate a starter faz.yaml."
    )


def _parse_databases(data: dict[str, Any], cfg_path: Path) -> list[ConnectionConfig]:
    """Reuse the existing per-entry parser, sharing dup-name diagnostics."""
    if "databases" not in data:
        raise ValueError(
            f"{cfg_path.name} must have a top-level 'databases' list."
        )
    entries = data["databases"]
    # `faz init` writes `databases:` with no value (null) so the user can
    # uncomment the example below it. Treat null as an empty list rather
    # than crashing — same shape `faz add-database` already accepts.
    if entries is None:
        entries = []
    if not isinstance(entries, list):
        raise ValueError(f"'databases' in {cfg_path.name} must be a list.")

    configs: list[ConnectionConfig] = []
    for i, entry in enumerate(entries):
        try:
            configs.append(_parse_entry(entry))
        except (KeyError, ValueError) as exc:
            raise ValueError(f"{cfg_path.name} entry #{i + 1} is invalid: {exc}") from exc

    seen: set[str] = set()
    for cfg in configs:
        if cfg.name in seen:
            logger.warning(
                "Duplicate connector name %r in %s — only the last entry "
                "will be used. Add a unique 'name' to each.",
                cfg.name, cfg_path.name,
            )
        seen.add(cfg.name)

    return configs


def _parse_permissions(
    raw: Any, cfg_path: Path,
) -> list[Permission]:
    """Flatten the nested `permissions:` block into Permission rows.

    Input:
        permissions:
          - database: app_db
            access: R                # baseline (mandatory)
            tables:                  # OPTIONAL per-table overrides
              orders: RW
              audit:  W

    Output:
        [Permission(app_db, "*",      R),     # baseline
         Permission(app_db, "orders", RW),    # override
         Permission(app_db, "audit",  W)]     # override
    """
    if raw is None:
        logger.warning(
            "%s has no `permissions:` block — every request will be denied "
            "until you add one. Run `faz init` to generate a sample.",
            cfg_path.name,
        )
        return []
    if not isinstance(raw, list):
        raise ValueError(
            f"`permissions:` in {cfg_path.name} must be a list "
            f"(got {type(raw).__name__})."
        )

    rows: list[Permission] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, dict):
            raise ValueError(
                f"permissions[{i}] in {cfg_path.name} must be a mapping."
            )
        db_name = entry.get("database")
        if not db_name:
            raise ValueError(
                f"permissions[{i}] in {cfg_path.name} missing required 'database' field."
            )
        access_raw = entry.get("access")
        if not access_raw:
            raise ValueError(
                f"permissions[{i}] (database={db_name}) in {cfg_path.name} "
                "missing required 'access' field — the per-database baseline."
            )
        try:
            baseline_mode = PermissionMode(str(access_raw))
        except ValueError:
            valid = [m.value for m in PermissionMode]
            raise ValueError(
                f"permissions[{i}] (database={db_name}) has unknown access "
                f"level {access_raw!r}. Valid: {valid}"
            )

        # Per-database baseline row
        rows.append(Permission(
            database_uri=str(db_name),
            table_name="*",
            access_level=baseline_mode,
        ))

        # Optional per-table overrides
        tables = entry.get("tables") or {}
        if not isinstance(tables, dict):
            raise ValueError(
                f"permissions[{i}].tables in {cfg_path.name} must be a "
                f"mapping (got {type(tables).__name__})."
            )
        for table_name, override_raw in tables.items():
            try:
                override_mode = PermissionMode(str(override_raw))
            except ValueError:
                valid = [m.value for m in PermissionMode]
                raise ValueError(
                    f"permissions[{i}].tables[{table_name}] has unknown "
                    f"access level {override_raw!r}. Valid: {valid}"
                )
            rows.append(Permission(
                database_uri=str(db_name),
                table_name=str(table_name),
                access_level=override_mode,
            ))

    return rows


def _parse_safety(raw: Any) -> dict[str, Any]:
    """Pass-through for the safety block. Kept untyped until Phase 3."""
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise ValueError(
            f"`safety:` must be a mapping (got {type(raw).__name__})."
        )
    return dict(raw)


# ---------------------------------------------------------------------------
# Phase 0 back-compat: just the databases list
# ---------------------------------------------------------------------------


def load_db_configs(path: str | Path | None = None) -> list[ConnectionConfig]:
    """Parse database.yaml and return a list of ConnectionConfig objects.

    Args:
        path: Path to the YAML file.  Defaults to ``database.yaml`` in the
              project root (the directory containing this package).

    Raises:
        FileNotFoundError: If the YAML file does not exist.
        ValueError: If a database entry has an unknown ``type`` or is missing
                    required fields.
    """
    if path is None:
        # Project root = three levels up from this file (src/config/db_loader.py)
        project_root = Path(__file__).resolve().parent.parent.parent
        path = project_root / "database.yaml"
    else:
        path = Path(path)

    if not path.exists():
        raise FileNotFoundError(
            f"database.yaml not found at {path}. "
            "Copy database.yaml.example to database.yaml and fill in your connection details."
        )

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict) or "databases" not in data:
        raise ValueError("database.yaml must have a top-level 'databases' list.")

    entries = data["databases"]
    if not isinstance(entries, list):
        raise ValueError("'databases' in database.yaml must be a list.")

    configs: list[ConnectionConfig] = []
    for i, entry in enumerate(entries):
        try:
            cfg = _parse_entry(entry)
            configs.append(cfg)
            logger.info(
                "Loaded DB config: name=%s type=%s @ %s:%s",
                cfg.name, cfg.connector_type.value, cfg.host, cfg.port,
            )
        except (KeyError, ValueError) as exc:
            raise ValueError(f"database.yaml entry #{i + 1} is invalid: {exc}") from exc

    if not configs:
        logger.warning("database.yaml has no database entries — no connectors will be registered.")

    # Warn on duplicate names
    seen_names: set[str] = set()
    for cfg in configs:
        if cfg.name in seen_names:
            logger.warning(
                "Duplicate connector name %r in database.yaml — "
                "only the last entry will be used. Add a unique 'name' field to each.",
                cfg.name,
            )
        seen_names.add(cfg.name)

    return configs


def _parse_entry(entry: dict[str, Any]) -> ConnectionConfig:
    """Convert a single YAML database entry to a ConnectionConfig."""
    type_str = entry.get("type", "").lower()
    if not type_str:
        raise ValueError("missing required field 'type'")

    try:
        connector_type = ConnectorType(type_str)
    except ValueError:
        valid = [ct.value for ct in ConnectorType]
        raise ValueError(
            f"unknown connector type {type_str!r}. Valid types: {valid}"
        )

    host = str(entry.get("host", "localhost"))
    port = int(entry.get("port", _default_port(connector_type)))
    database = str(entry.get("database", ""))
    username = str(entry.get("username", ""))
    password = str(entry.get("password", ""))
    ssl = bool(entry.get("ssl", False))
    extra: dict[str, Any] = entry.get("extra") or {}

    # name is the routing key used in IR steps (e.g. "pg_primary.users").
    # Defaults to connector_type.value so single-instance setups need no name.
    name = str(entry.get("name", "") or connector_type.value)

    # access_mode is always READ_ONLY — controlled by RBAC, not this config
    return ConnectionConfig(
        connector_type=connector_type,
        host=host,
        port=port,
        database=database,
        name=name,
        username=username,
        password=password,
        ssl=ssl,
        extra=extra,
        access_mode=AccessMode.READ_ONLY,
    )


def _default_port(ct: ConnectorType) -> int:
    """Sensible default port per connector type."""
    return {
        ConnectorType.POSTGRESQL:     5432,
        ConnectorType.MYSQL:          3306,
        ConnectorType.ORACLE:         1521,
        ConnectorType.MONGODB:        27017,
        ConnectorType.DYNAMODB:       8000,
        ConnectorType.CASSANDRA:      9042,
        ConnectorType.COUCHDB:        5984,
        ConnectorType.ELASTICSEARCH:  9200,
        ConnectorType.OPENSEARCH:     9200,
        ConnectorType.WEAVIATE:       8080,
        ConnectorType.QDRANT:         6333,
        ConnectorType.MILVUS:         19530,
        ConnectorType.PINECONE:       5081,
        ConnectorType.NEO4J:          7687,
    }.get(ct, 0)
