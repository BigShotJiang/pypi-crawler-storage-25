"""Unit tests for ``faz init``.

Exercises the template writer + .faz/ creation + --force semantics
under ``tmp_path`` isolation (no cwd pollution).
"""

from __future__ import annotations

from click.testing import CliRunner

from faz.cli.init import init_cmd


def test_init_writes_yaml_and_dot_dir(tmp_path, monkeypatch):
    """A fresh `faz init` creates faz.yaml + .faz/ in cwd."""
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(init_cmd, [])
    assert result.exit_code == 0, result.output

    assert (tmp_path / "faz.yaml").is_file()
    assert (tmp_path / ".faz").is_dir()

    yaml_text = (tmp_path / "faz.yaml").read_text()
    # Template should contain each top-level section.
    assert "databases:" in yaml_text
    assert "permissions:" in yaml_text
    assert "safety:" in yaml_text


def test_init_refuses_overwrite_without_force(tmp_path, monkeypatch):
    """If faz.yaml already exists, init fails unless --force is set."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / "faz.yaml").write_text("user: data\n")

    runner = CliRunner()
    result = runner.invoke(init_cmd, [])
    assert result.exit_code != 0, "expected an error exit"
    assert "already exists" in result.output

    # Original content was not touched.
    assert (tmp_path / "faz.yaml").read_text() == "user: data\n"


def test_init_force_overwrites(tmp_path, monkeypatch):
    """`faz init --force` replaces an existing faz.yaml with the template."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / "faz.yaml").write_text("user: data\n")

    runner = CliRunner()
    result = runner.invoke(init_cmd, ["--force"])
    assert result.exit_code == 0, result.output

    yaml_text = (tmp_path / "faz.yaml").read_text()
    assert "user: data" not in yaml_text
    assert "databases:" in yaml_text
