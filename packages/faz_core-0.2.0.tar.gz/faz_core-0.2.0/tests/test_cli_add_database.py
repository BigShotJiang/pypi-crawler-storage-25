"""Unit tests for ``faz add-database`` — the YAML round-trip writer.

The interactive Click flow + connection health check are integration-
shaped and exercised by the manual walkthrough. Here we test the
parts that are pure functions on data:

  * Comments + ordering survive when ``_append_to_yaml`` adds an entry.
  * The new entry's keys are written in the canonical order.
  * Per-type prompt schemas exist for every ConnectorType (sanity).
"""

from __future__ import annotations

from faz.cli.add_database import _PROMPTS_BY_TYPE, _append_to_yaml
from faz.connectors import ConnectorType


_FAZ_YAML_WITH_COMMENTS = """\
# faz.yaml — heavily commented user file.
# This block-header comment must survive the round-trip.

databases:

  # ── Relational ─────────────────────────────────────────────────────
  - name: postgres
    type: postgresql
    host: localhost
    port: 5432
    database: testdb
    username: postgres
    password: secret

# ─────────────────────────────────────────────────────────────────────
# Permissions block
# ─────────────────────────────────────────────────────────────────────
permissions:
  - database: postgres
    access: R

safety:
  max_rows_per_query: 5000
"""


def test_append_preserves_comments(tmp_path):
    """The block headers and inline comments must round-trip intact."""
    path = tmp_path / "faz.yaml"
    path.write_text(_FAZ_YAML_WITH_COMMENTS)

    _append_to_yaml(
        path, name="newdb", type_="mysql",
        top_level={
            "host": "localhost", "port": 3306,
            "database": "extra", "username": "admin", "password": "pw",
        },
        extra={},
    )

    text = path.read_text()
    # Every distinctive comment from the original survives.
    assert "# faz.yaml — heavily commented user file." in text
    assert "# This block-header comment must survive the round-trip." in text
    assert "# ── Relational ─────────────────────────────────────────────────────" in text
    assert "# Permissions block" in text

    # The original entry survives.
    assert "name: postgres" in text

    # The new entry was appended.
    assert "name: newdb" in text
    assert "type: mysql" in text
    assert "database: extra" in text


def test_append_writes_keys_in_canonical_order(tmp_path):
    """Keys appear in the order: name, type, host, port, database, username, password, extra."""
    path = tmp_path / "faz.yaml"
    path.write_text(_FAZ_YAML_WITH_COMMENTS)

    _append_to_yaml(
        path, name="myadd", type_="postgresql",
        # Pass the dict in shuffled order — output should still be canonical.
        top_level={
            "password": "p", "host": "h", "port": 5432,
            "username": "u", "database": "d",
        },
        extra={},
    )

    text = path.read_text()
    # Find the appended block.
    block = text.split("name: myadd", 1)[1]
    # Locate each key and assert ascending positions (canonical order).
    positions = [block.index(f"{k}:") for k in ("type", "host", "port", "database", "username", "password")]
    assert positions == sorted(positions), (
        f"keys not in canonical order: {positions}"
    )


def test_append_with_extra_block(tmp_path):
    """`extra:` keys land under an `extra:` map after the top-level fields."""
    path = tmp_path / "faz.yaml"
    path.write_text(_FAZ_YAML_WITH_COMMENTS)

    _append_to_yaml(
        path, name="vec", type_="pinecone",
        top_level={"host": "localhost", "port": 5081},
        extra={"api_key": "pclocal"},
    )

    text = path.read_text()
    block = text.split("name: vec", 1)[1]
    assert "extra:" in block
    assert "api_key: pclocal" in block


def test_every_connector_type_has_a_prompt_schema():
    """No ConnectorType should be missing from `_PROMPTS_BY_TYPE`."""
    missing = [t.value for t in ConnectorType if t.value not in _PROMPTS_BY_TYPE]
    assert not missing, f"Missing prompt schema for: {missing}"


def test_append_adds_default_readonly_permission_for_new_db(tmp_path):
    """A fresh add must auto-write a `permissions:` entry with access R."""
    path = tmp_path / "faz.yaml"
    path.write_text("databases:\npermissions:\n")

    _append_to_yaml(
        path, name="newdb", type_="postgresql",
        top_level={"host": "localhost", "port": 5432, "database": "d",
                   "username": "u", "password": "p"},
        extra={},
    )

    from ruamel.yaml import YAML
    data = YAML().load(path.read_text())
    perms = data["permissions"]
    assert len(perms) == 1
    assert perms[0]["database"] == "newdb"
    assert perms[0]["access"] == "R"


def test_append_honours_explicit_access(tmp_path):
    """`--access RW` flows through to the permissions entry."""
    path = tmp_path / "faz.yaml"
    path.write_text("databases:\npermissions:\n")

    _append_to_yaml(
        path, name="newdb", type_="postgresql",
        top_level={"host": "h", "port": 1, "database": "d",
                   "username": "u", "password": "p"},
        extra={}, access="RW",
    )

    from ruamel.yaml import YAML
    data = YAML().load(path.read_text())
    assert data["permissions"][0]["access"] == "RW"


def test_append_does_not_duplicate_existing_permission(tmp_path):
    """Re-adding a database name must not duplicate its permissions row."""
    path = tmp_path / "faz.yaml"
    path.write_text(_FAZ_YAML_WITH_COMMENTS)  # already has postgres + perm

    _append_to_yaml(
        path, name="postgres", type_="postgresql",
        top_level={"host": "h", "port": 1, "database": "d",
                   "username": "u", "password": "p"},
        extra={},
    )

    from ruamel.yaml import YAML
    data = YAML().load(path.read_text())
    postgres_perms = [p for p in data["permissions"] if p["database"] == "postgres"]
    assert len(postgres_perms) == 1, "permission entry got duplicated"
