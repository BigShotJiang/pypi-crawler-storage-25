"""Smoke tests for /v1/health and /v1/databases.

These hit the full FastAPI stack with a FakeConnector — nothing
touches a real database.
"""

from __future__ import annotations

from fastapi.testclient import TestClient

from faz.safety.types import AccessMode

from ._fakes import build_fake_app, make_perms


def test_health_returns_ok():
    app = build_fake_app(make_perms([("app_db", "*", AccessMode.R)]))
    with TestClient(app) as client:
        r = client.get("/v1/health")
        assert r.status_code == 200
        body = r.json()
        assert body["status"] == "ok"
        assert body["version"] == "0.1.1"
        assert body["databases_connected"] >= 1


def test_databases_lists_configured_with_reachable_true():
    """FakeConnector reports reachable=True when registered successfully."""
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.R)]),
        connectors=[
            ("app_db", {
                "users":  [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}],
                "orders": [{"id": 100, "user_id": 1, "total": 99.0}],
            }),
        ],
    )
    with TestClient(app) as client:
        r = client.get("/v1/databases")
        assert r.status_code == 200
        body = r.json()
        assert len(body["databases"]) == 1
        db = body["databases"][0]
        assert db["name"] == "app_db"
        assert db["reachable"] is True
        table_names = {t["name"] for t in db["tables"]}
        assert table_names == {"users", "orders"}


def test_describe_table_returns_columns():
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.R)]),
        connectors=[
            ("app_db", {"users": [{"id": 1, "name": "Alice", "email": "a@x"}]}),
        ],
    )
    with TestClient(app) as client:
        r = client.get("/v1/databases/app_db/tables/users")
        assert r.status_code == 200
        body = r.json()
        assert body["database"] == "app_db"
        assert body["table"]["name"] == "users"
        col_names = {c["name"] for c in body["table"]["columns"]}
        assert col_names == {"id", "name", "email"}


def test_describe_table_404_unknown_database():
    app = build_fake_app(make_perms([("app_db", "*", AccessMode.R)]))
    with TestClient(app) as client:
        r = client.get("/v1/databases/ghost/tables/anything")
        assert r.status_code == 404


def test_describe_table_404_unknown_table():
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.R)]),
        connectors=[("app_db", {"users": [{"id": 1}]})],
    )
    with TestClient(app) as client:
        r = client.get("/v1/databases/app_db/tables/ghost_table")
        assert r.status_code == 404
