"""End-to-end /v1/query/simple tests.

Each test boots a FastAPI app with FakeConnector, posts a query, and
asserts on the response envelope. The full safety pipeline runs
inline — these are integration tests for the API layer + safety pipeline
+ execution engine wiring.
"""

from __future__ import annotations

from fastapi.testclient import TestClient

from faz.safety.types import AccessMode

from ._fakes import build_fake_app, make_perms


_USERS_ROWS = [
    {"id": 1, "name": "Alice", "email": "a@x.io", "plan": "enterprise"},
    {"id": 2, "name": "Bob",   "email": "b@y.io", "plan": "free"},
    {"id": 3, "name": "Carol", "email": "c@z.io", "plan": "enterprise"},
]
_ORDERS_ROWS = [
    {"id": 100, "user_id": 1, "total": 99.0},
    {"id": 101, "user_id": 1, "total": 49.0},
]


def _post_simple(client, **body):
    return client.post("/v1/query/simple", json=body)


# ---------------------------------------------------------------------------
# Happy path: SELECT against R-baseline succeeds
# ---------------------------------------------------------------------------


def test_select_against_r_baseline_succeeds():
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.R)]),
        connectors=[("app_db", {"users": _USERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="users", language="sql",
            query="SELECT id, name FROM users",
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["status"] == "ok"
        assert body["data"]["row_count"] == 3
        assert "PROMPT_GUARD" in body["safety"]["stages_passed"]
        assert "RBAC_GATE" in body["safety"]["stages_passed"]
        # FastAPI's TestClient identifies its caller as "testclient"
        # (not 127.0.0.1), which `get_transport` classifies as remote.
        # Real localhost callers see "rest/local"; this is a TestClient
        # quirk, not a bug.
        assert body["metadata"]["transport"] in ("rest/local", "rest/remote")
        assert body["request_id"].startswith("req_")


# ---------------------------------------------------------------------------
# RBAC blocks
# ---------------------------------------------------------------------------


def test_insert_against_r_baseline_blocked():
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.R)]),
        connectors=[("app_db", {"users": _USERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="users", language="sql",
            query="INSERT INTO users VALUES (4, 'Dan', 'd@x.io', 'free')",
        )
        assert r.status_code == 403, r.text
        body = r.json()["detail"]
        assert body["status"] == "blocked"
        assert body["error"]["stage"] == "RBAC_GATE"
        assert "INSERT" in body["error"]["reason"]


def test_delete_against_r_baseline_blocked():
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.R)]),
        connectors=[("app_db", {"users": _USERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="users", language="sql",
            query="DELETE FROM users WHERE id = 1",
        )
        assert r.status_code == 403
        assert r.json()["detail"]["error"]["stage"] == "RBAC_GATE"


def test_drop_table_blocked_when_policy_below_admin():
    """DDL is rejected at RBAC_GATE / AST_CHECKER for any level below A."""
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.RW)]),
        connectors=[("app_db", {"users": _USERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="users", language="sql",
            query="DROP TABLE users",
        )
        assert r.status_code == 403
        body = r.json()["detail"]
        assert body["error"]["stage"] in ("RBAC_GATE", "AST_CHECKER")


def test_drop_table_allowed_under_admin():
    """AccessMode.A grants DDL; the safety pipeline lets DROP through."""
    app = build_fake_app(
        make_perms([("app_db", "*", AccessMode.A)]),
        connectors=[("app_db", {"users": _USERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="users", language="sql",
            query="DROP TABLE users",
        )
        # FakeConnector ignores the query body, so a successful pass
        # through the pipeline returns 200 with whatever rows the canned
        # table holds. The point is: not 403.
        assert r.status_code != 403, r.text


# ---------------------------------------------------------------------------
# Per-table override (RW orders) → INSERT allowed
# ---------------------------------------------------------------------------


def test_insert_against_rw_override_succeeds():
    app = build_fake_app(
        make_perms([
            ("app_db", "*",      AccessMode.R),
            ("app_db", "orders", AccessMode.RW),
        ]),
        connectors=[("app_db", {"orders": _ORDERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="orders", language="sql",
            query="INSERT INTO orders VALUES (102, 2, 19.99)",
        )
        assert r.status_code == 200, r.text


# ---------------------------------------------------------------------------
# IRBuildError → 400
# ---------------------------------------------------------------------------


def test_unknown_database_returns_400():
    app = build_fake_app(make_perms([("app_db", "*", AccessMode.R)]))
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="ghost_db", table="x", language="sql", query="SELECT 1",
        )
        assert r.status_code == 400


# ---------------------------------------------------------------------------
# Pydantic validation → 422
# ---------------------------------------------------------------------------


def test_missing_query_field_returns_422():
    app = build_fake_app(make_perms([("app_db", "*", AccessMode.R)]))
    with TestClient(app) as client:
        r = client.post(
            "/v1/query/simple",
            json={"database": "app_db", "table": "users", "language": "sql"},
        )
        assert r.status_code == 422


def test_bogus_language_returns_422():
    app = build_fake_app(make_perms([("app_db", "*", AccessMode.R)]))
    with TestClient(app) as client:
        r = client.post(
            "/v1/query/simple",
            json={"database": "app_db", "table": "users",
                  "language": "magic", "query": "SELECT 1"},
        )
        assert r.status_code == 422


# ---------------------------------------------------------------------------
# JOIN body extraction — proves RBAC walks the query body
# ---------------------------------------------------------------------------


def test_join_to_unauthorized_table_blocks():
    """Declared target = users (R). Query JOINs `secrets` (no policy)."""
    app = build_fake_app(
        make_perms([("app_db", "users", AccessMode.R)]),  # ONLY users — no wildcard
        connectors=[("app_db", {"users": _USERS_ROWS})],
    )
    with TestClient(app) as client:
        r = _post_simple(
            client,
            database="app_db", table="users", language="sql",
            query=(
                "SELECT u.id, s.token "
                "FROM users u JOIN secrets s ON s.user_id = u.id"
            ),
        )
        assert r.status_code == 403, r.text
        body = r.json()["detail"]
        # The body-extracted `secrets` target should be in the reason.
        assert "secrets" in body["error"]["reason"]
