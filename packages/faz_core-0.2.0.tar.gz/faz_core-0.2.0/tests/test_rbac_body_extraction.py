"""Body-extraction proof: RBAC walks the query body, not just declared targets.

If a query declares `step.table = users` but JOINs to `orders` (no policy),
the JOIN target must BLOCK. Same for Mongo `$lookup`, ES `_reindex`,
Cypher rebound `DETACH DELETE`, and SQL compound DML.
"""

from __future__ import annotations

import json

import pytest

from faz.auth.types import Permission
from faz.safety.rbac_gate import RBACGate
from faz.safety.types import AccessMode, QueryLanguage, StageVerdict
from faz.types.ir import IntermediateRepr, IRStep


def _gate() -> RBACGate:
    return RBACGate()


def _ir(step: IRStep) -> IntermediateRepr:
    return IntermediateRepr(steps=[step])


@pytest.fixture
def perms_users_only() -> list[Permission]:
    """app_db has policy ONLY for users — orders/secrets have no policy."""
    return [Permission("app_db", "users", AccessMode.R)]


# ---------------------------------------------------------------------------
# SQL: JOIN to unauthorized table
# ---------------------------------------------------------------------------


def test_sql_join_to_unauthorized_blocks(perms_users_only):
    """Declared target = users (R), but query JOINs orders (no policy)."""
    step = IRStep(
        database="app_db", table="users", step_id="s0",
        language=QueryLanguage.SQL,
        raw_query="SELECT u.id, o.total FROM users u JOIN orders o ON o.user_id=u.id",
    )
    res = _gate().validate(_ir(step), perms_users_only)
    assert res.verdict == StageVerdict.BLOCK
    # Block reason mentions orders, the unauthorized table.
    assert any("orders" in (e.message or "") for e in res.events)


def test_sql_compound_insert_select_blocks_on_dest(perms_users_only):
    """INSERT INTO archive SELECT FROM users → archive has no policy → BLOCK."""
    step = IRStep(
        database="app_db", table="archive", step_id="s0",
        language=QueryLanguage.SQL,
        raw_query="INSERT INTO archive SELECT id FROM users",
    )
    res = _gate().validate(_ir(step), perms_users_only)
    assert res.verdict == StageVerdict.BLOCK
    assert any("archive" in (e.message or "") for e in res.events)


def test_sql_update_from_other_table_checks_both(perms_users_only):
    """Postgres UPDATE x SET ... FROM y — y is a SELECT target."""
    step = IRStep(
        database="app_db", table="users", step_id="s0",
        language=QueryLanguage.SQL,
        raw_query="UPDATE users SET total=o.total FROM orders o WHERE o.user_id=users.id",
    )
    res = _gate().validate(_ir(step), perms_users_only)
    assert res.verdict == StageVerdict.BLOCK
    # users requires UPDATE (R doesn't permit), orders requires SELECT (no policy).
    # Either one would block — both are valid causes.


# ---------------------------------------------------------------------------
# Mongo $lookup
# ---------------------------------------------------------------------------


def test_mql_lookup_to_unauthorized_collection_blocks():
    perms = [
        Permission("mongo", "events", AccessMode.R),
        # NOTE: no policy for "users" collection
    ]
    body = json.dumps({
        "operation": "aggregate",
        "collection": "events",
        "pipeline": [
            {"$lookup": {"from": "users", "localField": "user_id", "foreignField": "_id", "as": "u"}},
        ],
    })
    step = IRStep(
        database="mongo", table="events", step_id="s0",
        language=QueryLanguage.MQL, raw_query=body,
    )
    res = _gate().validate(_ir(step), perms)
    assert res.verdict == StageVerdict.BLOCK
    assert any("users" in (e.message or "") for e in res.events)


def test_mql_out_to_unauthorized_collection_blocks():
    perms = [Permission("mongo", "events", AccessMode.R)]
    body = json.dumps({
        "operation": "aggregate",
        "collection": "events",
        "pipeline": [{"$out": "archive"}],
    })
    step = IRStep(
        database="mongo", table="events", step_id="s0",
        language=QueryLanguage.MQL, raw_query=body,
    )
    res = _gate().validate(_ir(step), perms)
    assert res.verdict == StageVerdict.BLOCK


# ---------------------------------------------------------------------------
# ES _reindex src + dst
# ---------------------------------------------------------------------------


def test_es_reindex_blocks_when_dst_unauthorized():
    perms = [Permission("es", "old_logs", AccessMode.R)]   # source is fine
    body = json.dumps({
        "method": "POST", "path": "/_reindex",
        "body": {"source": {"index": "old_logs"}, "dest": {"index": "archive"}},
    })
    step = IRStep(
        database="es", table="old_logs", step_id="s0",
        language=QueryLanguage.ES_DSL, raw_query=body,
    )
    res = _gate().validate(_ir(step), perms)
    assert res.verdict == StageVerdict.BLOCK
    assert any("archive" in (e.message or "") for e in res.events)


# ---------------------------------------------------------------------------
# Cypher: rebound DETACH DELETE
# ---------------------------------------------------------------------------


def test_cypher_detach_delete_on_rebound_label_blocks():
    """`MATCH (u:User)-[]-(p:Post) DETACH DELETE p` — Post needs DELETE not SELECT."""
    perms = [Permission("neo4j", "*", AccessMode.R)]   # all labels R-only
    step = IRStep(
        database="neo4j", table="User", step_id="s0",
        language=QueryLanguage.CYPHER,
        raw_query="MATCH (u:User)-[:WROTE]->(p:Post) DETACH DELETE p",
    )
    res = _gate().validate(_ir(step), perms)
    assert res.verdict == StageVerdict.BLOCK
    # Block message mentions Post (the deleted label).
    assert any("Post" in (e.message or "") for e in res.events)


def test_cypher_apoc_runwrite_blocks_below_admin():
    """APOC procs outside the read allowlist are emitted as DDL — blocked
    for any level below A; permitted only when the policy grants Admin."""
    step = IRStep(
        database="neo4j", table="X", step_id="s0",
        language=QueryLanguage.CYPHER,
        raw_query='CALL apoc.cypher.runWrite("CREATE (n:Sneaky)")',
    )

    # Below-Admin policy: BLOCK.
    rw_perms = [Permission("neo4j", "*", AccessMode.RW)]
    assert _gate().validate(_ir(step), rw_perms).verdict == StageVerdict.BLOCK

    # Admin policy: PASS — A grants DDL.
    a_perms = [Permission("neo4j", "*", AccessMode.A)]
    assert _gate().validate(_ir(step), a_perms).verdict == StageVerdict.PASS
