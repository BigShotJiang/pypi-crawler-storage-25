"""PolicyLoader tests — Phase 2.

Coverage:
  * faz.yaml parsing happy + error paths
  * Defensive-copy semantics on `permissions` / `safety` properties
  * `identify()` transport detection (string hints, FastAPI Request shapes)
  * `authenticate()` returns AUTHENTICATED with cached permissions
  * `can_access()` matches exact rows + per-database wildcards
"""

from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path

import pytest

from faz.auth import PolicyLoader
from faz.auth.types import AuthOutcome, Permission
from faz.safety.types import AccessMode


# ---------------------------------------------------------------------------
# YAML fixtures
# ---------------------------------------------------------------------------


_VALID_YAML = """
databases:
  - name: app_db
    type: postgresql
    host: localhost
    port: 5432
    database: myapp
    username: u
    password: p

  - name: logs
    type: mongodb
    host: localhost
    port: 27017
    database: app_logs
    username: u
    password: p

permissions:
  - database: app_db
    access: R
    tables:
      orders: RW
      audit:  W

  - database: logs
    access: R

safety:
  max_rows_per_query: 5000
  queries_per_minute: 60
  query_timeout_seconds: 30
  auto_block_sensitive: true
"""

_NO_PERMS_YAML = """
databases:
  - name: app_db
    type: postgresql
    host: localhost
    port: 5432
    database: myapp
    username: u
    password: p
"""

_MALFORMED_YAML = """
databases:
  - name: app_db
    type: postgresql
    host: localhost
"""

_BROKEN_YAML = """
databases:
  - name: app_db
    type: invalid_db_type
    host: localhost
    port: 5432
    database: x
    username: u
    password: p
"""


@pytest.fixture
def valid_yaml(tmp_path: Path) -> Path:
    p = tmp_path / "faz.yaml"
    p.write_text(_VALID_YAML)
    return p


@pytest.fixture
def no_perms_yaml(tmp_path: Path) -> Path:
    p = tmp_path / "faz.yaml"
    p.write_text(_NO_PERMS_YAML)
    return p


# ---------------------------------------------------------------------------
# Fake FastAPI Request shape for identify() tests
# ---------------------------------------------------------------------------


@dataclass
class _FakeClient:
    host: str = ""
    port: int = 0


@dataclass
class _FakeRequest:
    client: _FakeClient | None = None


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


class TestLoading:
    def test_loads_valid_yaml(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        # 2 baselines + 2 overrides = 4 rows
        assert len(pl.permissions) == 4
        baselines = [p for p in pl.permissions if p.is_baseline]
        overrides = [p for p in pl.permissions if not p.is_baseline]
        assert len(baselines) == 2
        assert len(overrides) == 2

    def test_safety_keys_loaded(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        assert pl.safety["max_rows_per_query"] == 5000
        assert pl.safety["queries_per_minute"] == 60
        assert pl.safety["auto_block_sensitive"] is True

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            PolicyLoader("/nonexistent/path/faz.yaml")

    def test_missing_permissions_block_warns_but_loads(self, no_perms_yaml: Path):
        # Should load with empty permissions list, no exception.
        pl = PolicyLoader(no_perms_yaml)
        assert pl.permissions == []
        # safety block also missing → empty dict
        assert pl.safety == {}

    def test_invalid_db_type_rejected(self, tmp_path: Path):
        p = tmp_path / "faz.yaml"
        p.write_text(_BROKEN_YAML)
        with pytest.raises(ValueError):
            PolicyLoader(p)


# ---------------------------------------------------------------------------
# Defensive-copy semantics
# ---------------------------------------------------------------------------


class TestDefensiveCopies:
    def test_permissions_returns_copy(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        first = pl.permissions
        first.clear()
        # Internal state must not be affected by mutating the returned list.
        assert len(pl.permissions) == 4

    def test_safety_returns_copy(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        first = pl.safety
        first["max_rows_per_query"] = 1
        # Internal state must not be affected.
        assert pl.safety["max_rows_per_query"] == 5000


# ---------------------------------------------------------------------------
# Transport identification
# ---------------------------------------------------------------------------


class TestIdentify:
    @pytest.mark.asyncio
    async def test_explicit_string_hint_passed_through(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        for hint in ("mcp/stdio", "cli", "rest/local"):
            ident = await pl.identify(hint)
            assert ident.metadata["transport"] == hint
            assert ident.user_id == hint

    @pytest.mark.asyncio
    async def test_loopback_request_is_rest_local(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        for host in ("127.0.0.1", "::1", "localhost"):
            ident = await pl.identify(_FakeRequest(client=_FakeClient(host=host)))
            assert ident.metadata["transport"] == "rest/local", host

    @pytest.mark.asyncio
    async def test_remote_request_is_rest_remote(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        ident = await pl.identify(_FakeRequest(client=_FakeClient(host="10.0.0.5")))
        assert ident.metadata["transport"] == "rest/remote"

    @pytest.mark.asyncio
    async def test_no_client_is_unknown(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        ident = await pl.identify(_FakeRequest(client=None))
        assert ident.metadata["transport"] == "unknown"

    @pytest.mark.asyncio
    async def test_none_request_is_unknown(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        ident = await pl.identify(None)
        assert ident.metadata["transport"] == "unknown"


# ---------------------------------------------------------------------------
# authenticate() (inherited from ABC; verifies our identify+resolve compose)
# ---------------------------------------------------------------------------


class TestAuthenticate:
    @pytest.mark.asyncio
    async def test_returns_authenticated_with_cached_permissions(self, valid_yaml: Path):
        pl = PolicyLoader(valid_yaml)
        result = await pl.authenticate("mcp/stdio")
        assert result.outcome == AuthOutcome.AUTHENTICATED
        assert len(result.permissions) == 4
        assert result.identity is not None
        assert result.identity.metadata["transport"] == "mcp/stdio"


# ---------------------------------------------------------------------------
# can_access() — resource = "db.table" convention
# ---------------------------------------------------------------------------


class TestCanAccess:
    @pytest.fixture
    def perms(self) -> list[Permission]:
        return [
            Permission("app_db", "*",      AccessMode.R),    # baseline
            Permission("app_db", "orders", AccessMode.RW),   # override
            Permission("logs",   "events", AccessMode.R),    # specific only
        ]

    def test_exact_match_via_override(self, valid_yaml: Path, perms):
        pl = PolicyLoader(valid_yaml)
        assert pl.can_access(perms, "app_db.orders") is True

    def test_wildcard_baseline_covers_table(self, valid_yaml: Path, perms):
        pl = PolicyLoader(valid_yaml)
        # users has no override but app_db has a "*" baseline → ALLOW
        assert pl.can_access(perms, "app_db.users") is True

    def test_specific_only_no_wildcard(self, valid_yaml: Path, perms):
        pl = PolicyLoader(valid_yaml)
        # logs has only an explicit `events` row, no "*" baseline → other tables denied
        assert pl.can_access(perms, "logs.events") is True
        assert pl.can_access(perms, "logs.unlisted") is False

    def test_no_policy_for_database_denies(self, valid_yaml: Path, perms):
        pl = PolicyLoader(valid_yaml)
        assert pl.can_access(perms, "ghost_db.x") is False

    def test_empty_resource_denies(self, valid_yaml: Path, perms):
        pl = PolicyLoader(valid_yaml)
        assert pl.can_access(perms, "") is False
