"""IR builder unit tests — request → IntermediateRepr conversion."""

from __future__ import annotations

import pytest

from faz.api.ir_builder import IRBuildError, build_federated, build_simple
from faz.api.schemas import (
    FederatedQueryRequest,
    FederatedStepRequest,
    SimpleQueryRequest,
)
from faz.connectors import ConnectorRegistry
from faz.connectors.base import (
    AccessMode,
    ConnectionConfig,
    ConnectorType,
)
from faz.safety.types import QueryLanguage


@pytest.fixture
def registry() -> ConnectorRegistry:
    """Registry pre-loaded with `app_db` and `logs` configs (no real connections)."""
    reg = ConnectorRegistry()
    for name, ctype in [("app_db", ConnectorType.POSTGRESQL),
                        ("logs",   ConnectorType.MONGODB)]:
        reg.add_config(ConnectionConfig(
            connector_type=ctype, name=name, host="x", port=1, database=name,
            username="u", password="p", access_mode=AccessMode.READ_ONLY,
        ))
    return reg


# ---------------------------------------------------------------------------
# build_simple
# ---------------------------------------------------------------------------


class TestBuildSimple:
    def test_happy_path(self, registry):
        req = SimpleQueryRequest(
            database="app_db", table="users",
            language=QueryLanguage.SQL, query="SELECT 1",
        )
        ir = build_simple(req, registry)
        assert len(ir.steps) == 1
        s = ir.steps[0]
        assert s.database == "app_db"
        assert s.table == "users"
        assert s.step_id == "s0"
        assert s.language == QueryLanguage.SQL
        assert s.raw_query == "SELECT 1"

    def test_unknown_database_raises(self, registry):
        req = SimpleQueryRequest(
            database="ghost", table="x",
            language=QueryLanguage.SQL, query="SELECT 1",
        )
        with pytest.raises(IRBuildError) as exc:
            build_simple(req, registry)
        assert "ghost" in str(exc.value)

    def test_lowercase_language_accepted(self, registry):
        # Pydantic schema applies _coerce_language; "sql" → QueryLanguage.SQL.
        req = SimpleQueryRequest.model_validate({
            "database": "app_db", "table": "users",
            "language": "sql", "query": "SELECT 1",
        })
        ir = build_simple(req, registry)
        assert ir.steps[0].language == QueryLanguage.SQL


# ---------------------------------------------------------------------------
# build_federated
# ---------------------------------------------------------------------------


def _step(step_id: str, db: str = "app_db", table: str = "users",
          query: str = "SELECT 1", depends_on=None,
          link_from=None, link_to=None) -> FederatedStepRequest:
    return FederatedStepRequest(
        step_id=step_id, database=db, table=table,
        language=QueryLanguage.SQL, query=query,
        depends_on=depends_on or [],
        link_from=link_from, link_to=link_to,
    )


class TestBuildFederated:
    def test_two_step_with_dependency(self, registry):
        req = FederatedQueryRequest(
            steps=[
                _step("s0", db="app_db", table="users",
                      query="SELECT id FROM users"),
                _step("s1", db="logs", table="events",
                      query="SELECT * FROM events",
                      depends_on=["s0"], link_from="id", link_to="user_id"),
            ],
            merge="SELECT * FROM s0 JOIN s1 ON s0.id=s1.user_id",
        )
        ir, merge = build_federated(req, registry)
        assert len(ir.steps) == 2
        assert ir.steps[0].step_id == "s0"
        assert ir.steps[1].step_id == "s1"
        assert ir.steps[1].depends_on == ["s0"]
        assert ir.steps[1].link_from == "id"
        assert ir.steps[1].link_to == "user_id"
        assert merge is not None and "JOIN" in merge

    def test_empty_steps_rejected(self, registry):
        # Pydantic min_length=1 catches this before our validator.
        with pytest.raises(Exception):
            FederatedQueryRequest(steps=[])

    def test_duplicate_step_id(self, registry):
        req = FederatedQueryRequest(steps=[
            _step("s0", table="a"),
            _step("s0", table="b"),
        ])
        with pytest.raises(IRBuildError) as exc:
            build_federated(req, registry)
        assert "s0" in str(exc.value)

    def test_unknown_database(self, registry):
        req = FederatedQueryRequest(steps=[_step("s0", db="ghost")])
        with pytest.raises(IRBuildError) as exc:
            build_federated(req, registry)
        assert "ghost" in str(exc.value)

    def test_self_loop(self, registry):
        req = FederatedQueryRequest(steps=[
            _step("s0", depends_on=["s0"]),
        ])
        with pytest.raises(IRBuildError) as exc:
            build_federated(req, registry)
        assert "depends on itself" in str(exc.value)

    def test_forward_reference(self, registry):
        req = FederatedQueryRequest(steps=[
            _step("s0", depends_on=["s99"]),
        ])
        with pytest.raises(IRBuildError) as exc:
            build_federated(req, registry)
        assert "s99" in str(exc.value)

    def test_merge_can_be_omitted(self, registry):
        req = FederatedQueryRequest(steps=[_step("s0")])
        ir, merge = build_federated(req, registry)
        assert ir.steps[0].step_id == "s0"
        assert merge is None
