"""`faz mcp install` — atomic JSON-merge writer for Claude Desktop / Cursor.

Per-OS path detection, fresh-config write, merge with existing entries
(preserving other servers), idempotency, and corrupt-file recovery
(backup-then-replace). All tests run with `tmp_path` filesystem
isolation — no Docker / no faz REST server / no live MCP client.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from faz.mcp.install import (
    InstallTarget,
    detect_targets,
    faz_command,
    faz_config_env,
    install,
)


# ---------------------------------------------------------------------------
# detect_targets — per-OS paths
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "system, env, claude_suffix",
    [
        ("Darwin",  {},                            "Library/Application Support/Claude/claude_desktop_config.json"),
        ("Linux",   {},                            ".config/Claude/claude_desktop_config.json"),
        ("Windows", {"APPDATA": "/fake/AppData"},  None),  # claude lives under APPDATA
    ],
)
def test_detect_targets_per_os(monkeypatch, tmp_path, system, env, claude_suffix):
    monkeypatch.setattr("platform.system", lambda: system)
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    for k, v in env.items():
        monkeypatch.setenv(k, v)

    targets = detect_targets()
    assert {t.client for t in targets} == {"claude", "cursor", "openclaw", "claude-code"}

    cursor = next(t for t in targets if t.client == "cursor")
    # Cursor path is the same on every OS (per Phase 5 plan).
    assert cursor.path == tmp_path / ".cursor/mcp.json"

    openclaw = next(t for t in targets if t.client == "openclaw")
    assert openclaw.path == tmp_path / ".openclaw/openclaw.json"
    # OpenClaw nests `mcp.servers.<name>` rather than `mcpServers.<name>`.
    assert openclaw.nest_path == ("mcp", "servers")

    claude = next(t for t in targets if t.client == "claude")
    if system == "Windows":
        assert str(claude.path).endswith("Claude/claude_desktop_config.json")
        assert "AppData" in str(claude.path)
    else:
        assert claude.path == tmp_path / claude_suffix


def test_detect_targets_filter_single_client(monkeypatch, tmp_path):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    targets = detect_targets("claude")
    assert [t.client for t in targets] == ["claude"]
    targets = detect_targets("cursor")
    assert [t.client for t in targets] == ["cursor"]
    targets = detect_targets("openclaw")
    assert [t.client for t in targets] == ["openclaw"]
    assert targets[0].nest_path == ("mcp", "servers")


def test_detect_targets_all_includes_claude_code(monkeypatch, tmp_path):
    """``--target all`` must include claude-code — it's global scope,
    just like claude and cursor, so there's no reason to exclude it."""
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    clients = {t.client for t in detect_targets("all")}
    assert clients == {"claude", "cursor", "openclaw", "claude-code"}


def test_detect_targets_claude_code_global_scope(monkeypatch, tmp_path):
    """``--target claude-code`` produces a global target at
    ``~/.claude.json`` with flat ``("mcpServers",)`` nesting — same
    shape as Claude Desktop, applies to every project the user opens.
    """
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    targets = detect_targets("claude-code")
    assert len(targets) == 1
    t = targets[0]

    assert t.client == "claude-code"
    assert t.path == tmp_path / ".claude.json"
    assert t.nest_path == ("mcpServers",)


# ---------------------------------------------------------------------------
# install — atomic JSON merge
# ---------------------------------------------------------------------------


def _config_paths(tmp_path: Path) -> list[InstallTarget]:
    return [
        InstallTarget("claude", tmp_path / "claude_desktop_config.json"),
        InstallTarget("cursor", tmp_path / "cursor_mcp.json"),
    ]


def test_install_creates_fresh_config(tmp_path):
    """No prior config → both files are created with the faz block.

    ``FAZ_CONFIG`` is only injected into the env block when
    ``faz_config_env()`` can resolve a real ``faz.yaml`` (explicit env
    var, cwd, or repo-relative). On a clean checkout / CI runner none of
    those exist, so the env block is omitted — assert the conditional
    contract instead of a hard requirement.
    """
    targets = _config_paths(tmp_path)
    reports = install(targets=targets)

    assert {r.status for r in reports} == {"written"}
    for tgt in targets:
        data = json.loads(tgt.path.read_text())
        faz = data["mcpServers"]["faz"]
        assert "command" in faz
        assert faz["args"] == ["mcp"]
        env = faz.get("env", {})
        if env:
            assert "FAZ_CONFIG" in env


def test_faz_config_env_includes_audit_log_when_config_resolves(tmp_path, monkeypatch):
    """``faz_config_env`` must derive ``FAZ_AUDIT_LOG`` from the config dir.

    When Claude / Cursor spawns the MCP server with a different cwd, the
    audit log would otherwise either go nowhere (no ``.faz/`` in spawn
    cwd) or land in the wrong directory. ``mcp install`` writes both
    keys so the audit stream reliably ends up beside the user's project.
    """
    cfg = tmp_path / "faz.yaml"
    cfg.write_text("databases:\npermissions:\n")
    monkeypatch.setenv("FAZ_CONFIG", str(cfg))
    monkeypatch.delenv("FAZ_AUDIT_LOG", raising=False)

    env = faz_config_env()

    assert env["FAZ_CONFIG"] == str(cfg.resolve())
    assert env["FAZ_AUDIT_LOG"] == str(tmp_path / ".faz" / "audit.jsonl")


def test_faz_config_env_honours_explicit_audit_log(tmp_path, monkeypatch):
    """If the user already set ``FAZ_AUDIT_LOG``, don't override it."""
    cfg = tmp_path / "faz.yaml"
    cfg.write_text("databases:\npermissions:\n")
    explicit_log = tmp_path / "elsewhere" / "audit.jsonl"
    monkeypatch.setenv("FAZ_CONFIG", str(cfg))
    monkeypatch.setenv("FAZ_AUDIT_LOG", str(explicit_log))

    env = faz_config_env()

    assert env["FAZ_AUDIT_LOG"] == str(explicit_log.resolve())


def test_install_claude_code_writes_global_block(tmp_path, monkeypatch):
    """End-to-end: ``--target claude-code`` writes a global
    ``mcpServers.faz`` at the top level of ``~/.claude.json`` with
    ``type: "stdio"``, and preserves all other keys and projects.
    """
    cfg = tmp_path / ".claude.json"
    cfg.write_text(json.dumps({
        "numStartups": 13,
        "userID": "abc",
        "projects": {
            "/some/other/project": {
                "hasTrustDialogAccepted": True,
                "mcpServers": {
                    "linear-server": {
                        "type": "http",
                        "url": "https://mcp.linear.app/mcp",
                    },
                },
            },
        },
    }, indent=2))

    target = InstallTarget(client="claude-code", path=cfg)
    install(targets=[target])

    data = json.loads(cfg.read_text())

    # Top-level keys preserved.
    assert data["numStartups"] == 13
    assert data["userID"] == "abc"

    # Existing project entry untouched.
    other = data["projects"]["/some/other/project"]
    assert other["hasTrustDialogAccepted"] is True
    assert other["mcpServers"]["linear-server"]["type"] == "http"

    # Global faz entry written at top-level mcpServers with type: stdio.
    assert "faz" in data["mcpServers"]
    faz = data["mcpServers"]["faz"]
    assert faz["type"] == "stdio"
    assert "command" in faz
    assert faz["args"] == ["mcp"]


def test_faz_config_env_empty_when_no_config(tmp_path, monkeypatch):
    """No resolvable yaml → empty env, no audit-log key floating loose."""
    monkeypatch.delenv("FAZ_CONFIG", raising=False)
    monkeypatch.delenv("FAZ_AUDIT_LOG", raising=False)
    monkeypatch.chdir(tmp_path)  # no faz.yaml here

    # Clobber the repo-relative fallback by faking a non-existent ancestor.
    # If a real faz.yaml happens to exist 3 dirs up, this assertion is
    # already lenient enough — we only assert *if* env is empty.
    env = faz_config_env()
    if env:
        assert "FAZ_CONFIG" in env
        assert "FAZ_AUDIT_LOG" in env
    else:
        assert env == {}


def test_install_merges_existing_servers(tmp_path):
    """Pre-existing entries for OTHER servers must survive the merge."""
    targets = _config_paths(tmp_path)
    pre_existing = {
        "mcpServers": {
            "other-server": {
                "command": "/usr/bin/other",
                "args": ["--flag"],
            }
        },
        "unrelatedField": {"keep": "this"},
    }
    for tgt in targets:
        tgt.path.write_text(json.dumps(pre_existing))

    install(targets=targets)

    for tgt in targets:
        data = json.loads(tgt.path.read_text())
        # Other server preserved
        assert "other-server" in data["mcpServers"]
        assert data["mcpServers"]["other-server"]["command"] == "/usr/bin/other"
        # Unrelated top-level field preserved
        assert data["unrelatedField"] == {"keep": "this"}
        # New faz entry added
        assert "faz" in data["mcpServers"]


def test_install_dry_run_does_not_write(tmp_path):
    """--dry-run must not touch the filesystem."""
    targets = _config_paths(tmp_path)
    reports = install(targets=targets, dry_run=True)

    assert {r.status for r in reports} == {"would-write"}
    for tgt in targets:
        assert not tgt.path.exists()


def test_install_idempotent(tmp_path):
    """Running install twice with no changes reports `unchanged` second time."""
    targets = _config_paths(tmp_path)
    install(targets=targets)
    second = install(targets=targets)
    assert {r.status for r in second} == {"unchanged"}


def test_install_atomic_on_invalid_json(tmp_path):
    """A corrupt config gets backed up; the new write produces valid JSON."""
    targets = _config_paths(tmp_path)
    for tgt in targets:
        tgt.path.write_text("{this is { not json")

    reports = install(targets=targets)
    for r in reports:
        assert r.status == "written"
        assert "backed up" in r.detail

    # The new file is valid JSON
    for tgt in targets:
        data = json.loads(tgt.path.read_text())
        assert "faz" in data["mcpServers"]

    # And a backup exists alongside.
    for tgt in targets:
        backups = list(tgt.path.parent.glob(f"{tgt.path.name}.bak.*"))
        assert len(backups) == 1


def test_install_preserves_non_object_root(tmp_path):
    """If the file's JSON root isn't a dict, back up and start fresh."""
    targets = _config_paths(tmp_path)
    for tgt in targets:
        tgt.path.write_text(json.dumps(["a", "list"]))

    reports = install(targets=targets)
    for r in reports:
        assert r.status == "written"
        assert "non-object root" in r.detail


def test_install_targets_override_writes_only_to_given_path(tmp_path):
    """`--path` (via the CLI) translates to a single InstallTarget — install()
    must respect that override and ignore per-OS auto-detection.
    """
    custom = tmp_path / "custom-config.json"
    targets = [InstallTarget(client="custom", path=custom)]

    reports = install(targets=targets)
    assert [r.client for r in reports] == ["custom"]
    assert [r.path for r in reports] == [custom]
    assert reports[0].status == "written"

    data = json.loads(custom.read_text())
    assert "faz" in data["mcpServers"]


def test_install_writes_under_nested_path_for_openclaw(tmp_path):
    """OpenClaw config nests under ``mcp.servers.<name>``; the merge must
    walk that path instead of writing the flat ``mcpServers`` key."""
    custom = tmp_path / "openclaw.json"
    targets = [InstallTarget(
        client="openclaw", path=custom, nest_path=("mcp", "servers"),
    )]

    install(targets=targets)
    data = json.loads(custom.read_text())

    # Faz lives under mcp.servers.faz, NOT under top-level mcpServers.
    assert "mcpServers" not in data
    assert "faz" in data["mcp"]["servers"]
    faz = data["mcp"]["servers"]["faz"]
    assert "command" in faz
    assert faz["args"] == ["mcp"]


def test_install_merges_existing_openclaw_servers(tmp_path):
    """Pre-existing OpenClaw servers under ``mcp.servers`` must survive merge."""
    custom = tmp_path / "openclaw.json"
    custom.write_text(json.dumps({
        "mcp": {
            "servers": {
                "other": {"command": "/usr/bin/other", "args": []},
            },
        },
        "ui": {"theme": "dark"},
    }))
    targets = [InstallTarget(
        client="openclaw", path=custom, nest_path=("mcp", "servers"),
    )]

    install(targets=targets)
    data = json.loads(custom.read_text())

    assert "other" in data["mcp"]["servers"]
    assert data["mcp"]["servers"]["other"]["command"] == "/usr/bin/other"
    assert "faz" in data["mcp"]["servers"]
    # Sibling top-level keys outside the nest path are preserved.
    assert data["ui"] == {"theme": "dark"}


def test_install_idempotent_under_nested_path(tmp_path):
    """A second install on an OpenClaw config reports `unchanged`."""
    custom = tmp_path / "openclaw.json"
    targets = [InstallTarget(
        client="openclaw", path=custom, nest_path=("mcp", "servers"),
    )]
    install(targets=targets)
    second = install(targets=targets)
    assert [r.status for r in second] == ["unchanged"]


def test_install_targets_dry_run_does_not_write_to_custom_path(tmp_path):
    """`--path` + `--dry-run` reports `would-write` and leaves the file alone."""
    custom = tmp_path / "preview.json"
    targets = [InstallTarget(client="custom", path=custom)]

    reports = install(targets=targets, dry_run=True)
    assert [r.status for r in reports] == ["would-write"]
    assert not custom.exists()


def test_faz_command_returns_invokable():
    """The chosen command should resolve to either ``faz`` on PATH, the
    venv-relative binary, or ``python -m faz.cli.main``. In every case
    the first element is a non-empty string and ``mcp`` is in args."""
    cmd, args = faz_command()
    assert cmd
    assert "mcp" in args
