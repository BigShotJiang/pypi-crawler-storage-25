"""RBACGate PARTIAL strip behavior for federated multi-step queries."""

from __future__ import annotations

import pytest

from faz.auth.types import Permission
from faz.safety.rbac_gate import DenyPolicy, RBACGate
from faz.safety.types import AccessMode, QueryLanguage, StageVerdict
from faz.types.ir import IntermediateRepr, IRStep


@pytest.fixture
def perms() -> list[Permission]:
    return [
        Permission("app_db", "*", AccessMode.R),
        Permission("app_db", "orders", AccessMode.RW),
    ]


def _step(table: str, sql: str, step_id: str = "s0") -> IRStep:
    return IRStep(
        database="app_db",
        table=table,
        step_id=step_id,
        language=QueryLanguage.SQL,
        raw_query=sql,
    )


def test_all_steps_allowed_passes(perms):
    gate = RBACGate(policy=DenyPolicy.PARTIAL)
    ir = IntermediateRepr(steps=[
        _step("users", "SELECT * FROM users", step_id="s0"),
        _step("orders", "SELECT * FROM orders", step_id="s1"),
    ])
    res = gate.validate(ir, perms)
    assert res.verdict == StageVerdict.PASS
    assert [s.step_id for s in ir.steps] == ["s0", "s1"]


def test_all_steps_denied_blocks(perms):
    gate = RBACGate(policy=DenyPolicy.PARTIAL)
    ir = IntermediateRepr(steps=[
        _step("users", "DELETE FROM users WHERE id=1", step_id="s0"),
        _step("users", "INSERT INTO users VALUES (1)", step_id="s1"),
    ])
    res = gate.validate(ir, perms)
    assert res.verdict == StageVerdict.BLOCK


def test_partial_strips_denied_step_keeps_allowed(perms):
    gate = RBACGate(policy=DenyPolicy.PARTIAL)
    ir = IntermediateRepr(steps=[
        _step("users", "SELECT * FROM users", step_id="s0"),    # PASS (R)
        _step("users", "DELETE FROM users", step_id="s1"),      # BLOCK
        _step("orders", "SELECT * FROM orders", step_id="s2"),  # PASS (RW)
    ])
    res = gate.validate(ir, perms)
    assert res.verdict == StageVerdict.PARTIAL
    surviving = [s.step_id for s in ir.steps]
    assert surviving == ["s0", "s2"], surviving


def test_block_policy_rejects_when_any_step_fails(perms):
    gate = RBACGate(policy=DenyPolicy.BLOCK)
    ir = IntermediateRepr(steps=[
        _step("users", "SELECT * FROM users", step_id="s0"),
        _step("users", "DELETE FROM users", step_id="s1"),
    ])
    res = gate.validate(ir, perms)
    assert res.verdict == StageVerdict.BLOCK
