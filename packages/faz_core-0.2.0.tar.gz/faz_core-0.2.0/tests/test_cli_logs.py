"""Unit tests for ``faz logs``.

Exercises the JSONL pretty-printer + the missing-file error path.
The ``--follow`` mode is integration-shaped (would need timing) and
isn't covered here.
"""

from __future__ import annotations

import json

from click.testing import CliRunner

from faz.cli.logs import logs_cmd


def _sample_entry(trace_id: str, transport: str = "rest/local") -> dict:
    return {
        "trace_id": trace_id,
        "transport": transport,
        "rbac": {"outcome": "PASS"},
        "ast": {"outcome": "PASS"},
        "injection_scan": {"outcome": "PASS"},
        "result": {"rows_returned": 5, "error": ""},
        "latency": {"total_ms": 42.0},
    }


def test_logs_prints_existing_lines(tmp_path):
    """Running `faz logs --path <file>` prints every line in the file."""
    log_path = tmp_path / "audit.jsonl"
    lines = [_sample_entry("req_aaa"), _sample_entry("req_bbb"), _sample_entry("req_ccc")]
    with log_path.open("w") as fh:
        for entry in lines:
            fh.write(json.dumps(entry) + "\n")

    runner = CliRunner()
    result = runner.invoke(logs_cmd, ["--path", str(log_path)])
    assert result.exit_code == 0, result.output

    for entry in lines:
        assert entry["trace_id"] in result.output


def test_logs_404_when_no_file(tmp_path):
    """A missing file should error out clearly, not crash."""
    runner = CliRunner()
    result = runner.invoke(logs_cmd, ["--path", str(tmp_path / "nope.jsonl")])
    assert result.exit_code != 0
    assert "no audit log" in result.output


def test_logs_handles_malformed_lines(tmp_path):
    """A bad line passes through verbatim instead of crashing."""
    log_path = tmp_path / "audit.jsonl"
    with log_path.open("w") as fh:
        fh.write("this is not json\n")
        fh.write(json.dumps(_sample_entry("req_zzz")) + "\n")

    runner = CliRunner()
    result = runner.invoke(logs_cmd, ["--path", str(log_path)])
    assert result.exit_code == 0, result.output
    assert "this is not json" in result.output
    assert "req_zzz" in result.output


def test_logs_skips_blank_lines(tmp_path):
    """Empty lines in the JSONL shouldn't produce empty echoes."""
    log_path = tmp_path / "audit.jsonl"
    log_path.write_text(
        json.dumps(_sample_entry("req_xxx")) + "\n\n\n"
    )

    runner = CliRunner()
    result = runner.invoke(logs_cmd, ["--path", str(log_path)])
    assert result.exit_code == 0, result.output
    # Exactly one trace_id printed → exactly one non-empty content line.
    non_empty = [ln for ln in result.output.splitlines() if ln.strip()]
    assert len(non_empty) == 1
    assert "req_xxx" in non_empty[0]
