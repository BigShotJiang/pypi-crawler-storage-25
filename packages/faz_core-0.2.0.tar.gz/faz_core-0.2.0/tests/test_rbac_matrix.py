"""Language-agnostic RBAC matrix + layered-lookup tests.

Covers:
  * 6 AccessMode levels × 5 op classes (SELECT/INSERT/UPDATE/DELETE/DDL).
  * Layered lookup: per-table override → per-database baseline → None.
  * Wildcard fallback per-database (cross-database wildcards do NOT apply).
  * Default-deny when no policy entry covers a (database, table) pair.
"""

from __future__ import annotations

import pytest

from faz.auth.types import Permission
from faz.safety.rbac_gate import _lookup, _satisfies
from faz.safety.types import AccessMode, Op


# ---------------------------------------------------------------------------
# Layered lookup
# ---------------------------------------------------------------------------


@pytest.fixture
def perms() -> list[Permission]:
    """Standard test policy:
        app_db: baseline R; orders RW; audit W
        logs:   baseline R
    """
    return [
        Permission("app_db", "*", AccessMode.R),
        Permission("app_db", "orders", AccessMode.RW),
        Permission("app_db", "audit", AccessMode.W),
        Permission("logs", "*", AccessMode.R),
    ]


class TestLayeredLookup:
    def test_per_table_override_beats_baseline(self, perms):
        assert _lookup(perms, "app_db", "orders") == AccessMode.RW
        assert _lookup(perms, "app_db", "audit") == AccessMode.W

    def test_baseline_applies_when_no_override(self, perms):
        assert _lookup(perms, "app_db", "users") == AccessMode.R
        assert _lookup(perms, "logs", "events") == AccessMode.R

    def test_no_policy_returns_none(self, perms):
        assert _lookup(perms, "unknown_db", "anything") is None

    def test_empty_database_returns_none(self, perms):
        assert _lookup(perms, "", "x") is None

    def test_cross_db_wildcard_does_not_apply(self, perms):
        # logs has its own baseline; app_db's "*" does not bleed across.
        assert _lookup(perms, "logs", "x") == AccessMode.R
        # Removing the logs baseline → no policy for logs.
        narrowed = [p for p in perms if p.database_uri != "logs"]
        assert _lookup(narrowed, "logs", "x") is None


# ---------------------------------------------------------------------------
# AccessMode × Op matrix
# ---------------------------------------------------------------------------


# Full grid. True = allowed, False = blocked.
_MATRIX: list[tuple[AccessMode, Op, bool]] = [
    # Read-only
    (AccessMode.R,   Op.SELECT, True),
    (AccessMode.R,   Op.INSERT, False),
    (AccessMode.R,   Op.UPDATE, False),
    (AccessMode.R,   Op.DELETE, False),
    (AccessMode.R,   Op.DDL,    False),
    # Write-only
    (AccessMode.W,   Op.SELECT, False),
    (AccessMode.W,   Op.INSERT, True),
    (AccessMode.W,   Op.UPDATE, True),
    (AccessMode.W,   Op.DELETE, True),
    (AccessMode.W,   Op.DDL,    False),
    # Read + Write
    (AccessMode.RW,  Op.SELECT, True),
    (AccessMode.RW,  Op.INSERT, True),
    (AccessMode.RW,  Op.UPDATE, True),
    (AccessMode.RW,  Op.DELETE, True),
    (AccessMode.RW,  Op.DDL,    False),
    # Read + Append (INSERT only on the write side)
    (AccessMode.RA,  Op.SELECT, True),
    (AccessMode.RA,  Op.INSERT, True),
    (AccessMode.RA,  Op.UPDATE, False),
    (AccessMode.RA,  Op.DELETE, False),
    (AccessMode.RA,  Op.DDL,    False),
    # Read + Write + Append (no DELETE — counter-intuitive but documented)
    (AccessMode.RWA, Op.SELECT, True),
    (AccessMode.RWA, Op.INSERT, True),
    (AccessMode.RWA, Op.UPDATE, True),
    (AccessMode.RWA, Op.DELETE, False),
    (AccessMode.RWA, Op.DDL,    False),
    # Admin: everything, including DDL.
    (AccessMode.A,   Op.SELECT, True),
    (AccessMode.A,   Op.INSERT, True),
    (AccessMode.A,   Op.UPDATE, True),
    (AccessMode.A,   Op.DELETE, True),
    (AccessMode.A,   Op.DDL,    True),
]


@pytest.mark.parametrize("mode,op,expected", _MATRIX)
def test_satisfies_matrix(mode: AccessMode, op: Op, expected: bool):
    assert _satisfies(mode, op) is expected


def test_satisfies_none_always_blocks():
    for op in Op:
        assert _satisfies(None, op) is False


# ---------------------------------------------------------------------------
# RWA gotcha — explicit test (this is the one most likely to surprise users)
# ---------------------------------------------------------------------------


def test_rwa_blocks_delete():
    """RWA = SELECT/INSERT/UPDATE only. DELETE is the absent op."""
    assert _satisfies(AccessMode.RWA, Op.DELETE) is False


def test_w_blocks_select():
    """W = INSERT/UPDATE/DELETE only. SELECT is forbidden."""
    assert _satisfies(AccessMode.W, Op.SELECT) is False
