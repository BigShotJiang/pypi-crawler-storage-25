"""`faz mcp` — MCP stdio server tool registration + envelope-shape tests.

Exercises:
  * The MCP server module imports cleanly and exposes ``serve`` / ``main``.
  * Each MCP tool's input schema matches the corresponding REST Pydantic
    request model (so the agent-facing contract is identical across
    surfaces).
  * ``HandlerError`` round-trips status + detail (used by REST adapters
    and MCP envelope builders).

Live stdio verification is deferred to ``tests/_mcp_smoke.py``, which
spawns ``faz mcp`` and round-trips a real ``initialize`` + ``tools/list``
JSON-RPC frame; that needs Docker up.
"""

from __future__ import annotations

from faz.api.schemas import FederatedQueryRequest, SimpleQueryRequest


def test_simple_request_validates_against_tool_schema():
    """`query_simple` MCP tool input schema = SimpleQueryRequest's JSON schema."""
    schema = SimpleQueryRequest.model_json_schema()
    assert schema["type"] == "object"
    required = schema.get("required") or []
    assert {"database", "table", "query"}.issubset(set(required))
    body = SimpleQueryRequest(
        database="x", table="y", language="sql", query="SELECT 1",
    )
    assert body.database == "x"


def test_federated_request_validates_against_tool_schema():
    """`query` MCP tool input schema = FederatedQueryRequest's JSON schema."""
    schema = FederatedQueryRequest.model_json_schema()
    assert schema["type"] == "object"
    body = FederatedQueryRequest(steps=[{
        "step_id": "s0", "database": "x", "table": "y",
        "language": "sql", "query": "SELECT 1",
    }])
    assert len(body.steps) == 1


def test_mcp_server_module_exposes_serve_and_main():
    """The MCP server module is importable; ``serve`` is async, ``main`` callable."""
    import inspect

    from faz.mcp import server as mcp_server

    assert callable(mcp_server.main)
    assert inspect.iscoroutinefunction(mcp_server.serve)


def test_handler_error_carries_status_and_detail():
    """HandlerError round-trips status + detail to REST and MCP callers."""
    from faz.api.handlers import HandlerError

    err = HandlerError(404, {"reason": "missing"})
    assert err.status_code == 404
    assert err.detail == {"reason": "missing"}
