//! Integration tests for `engine::libreoffice::LibreOfficeEngine`.
//!
//! These tests run by default and require `soffice` on `$PATH`
//! (or set via `$LIBREOFFICE_PATH`).
//!
//! ### Fixture-naming deviation
//!
//! Spec 12's *Test plan* names individual tests after `.docx` / `.xlsx` /
//! `.pptx` fixtures. We commit text fixtures (`sample.rtf`, `sample.csv`)
//! instead — see `tests/fixtures/office/README.md` for the rationale.
//! Test names below mirror the spec's intent (writer / calc filter, page
//! ranges, landscape, PDF/A, etc.) using whichever fixture is available.
//!
//! Notes on filter behaviour observed against `soffice 26.2.x`:
//!
//! - `IsLandscape` in the filter-options blob is honoured by the writer
//!   export module but **not** by calc — calc's orientation is driven by
//!   the document's page style. We therefore exercise landscape against
//!   the RTF fixture, not the CSV one.
//! - LibreOffice's HTML importer ignores CSS `page-break-before` rules,
//!   so the writer multi-page fixture is RTF (`\page` control words),
//!   not HTML.

use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use engine::{
    EngineError, LibreOfficeConfig, LibreOfficeEngine, OfficeOptions, PageRanges,
};
use engine::libreoffice::PdfAProfile;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn fixtures_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("fixtures")
        .join("office")
}

/// Multi-page writer fixture (RTF with `\page` control words).
fn writer_fixture() -> PathBuf {
    fixtures_dir().join("sample.rtf")
}

/// Calc fixture (CSV).
fn csv_fixture() -> PathBuf {
    fixtures_dir().join("sample.csv")
}

/// Shared engine across all tests in this binary. We launch one LOK instance
/// and reuse it — LOK allows only one `Office` per process and initialisation
/// takes a few seconds.
static SHARED: tokio::sync::OnceCell<Option<LibreOfficeEngine>> =
    tokio::sync::OnceCell::const_new();

async fn engine() -> Option<LibreOfficeEngine> {
    SHARED
        .get_or_init(|| async {
            match LibreOfficeEngine::launch(LibreOfficeConfig::default()).await {
                Ok(e) => Some(e),
                Err(e) => {
                    eprintln!("skipping: failed to launch LibreOffice LOK engine: {e}");
                    None
                }
            }
        })
        .await
        .clone()
}

fn assert_pdf_loadable(bytes: &[u8]) -> lopdf::Document {
    assert!(
        bytes.starts_with(b"%PDF-"),
        "expected PDF magic at start, got {:?}",
        &bytes[..bytes.len().min(8)]
    );
    let tail_window = &bytes[bytes.len().saturating_sub(64)..];
    assert!(
        tail_window.windows(5).any(|w| w == b"%%EOF"),
        "expected %%EOF in trailer"
    );
    lopdf::Document::load_mem(bytes).expect("PDF parses with lopdf")
}

fn pdf_page_count(doc: &lopdf::Document) -> usize {
    doc.get_pages().len()
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[tokio::test]
async fn convert_writer_produces_valid_pdf() {
    let Some(lo) = engine().await else { return; };
    assert!(lo.healthy().await);
    let bytes = lo
        .convert(&writer_fixture(), &OfficeOptions::default())
        .await
        .expect("convert");
    let doc = assert_pdf_loadable(&bytes);
    assert!(pdf_page_count(&doc) >= 1);
}

#[tokio::test]
async fn convert_writer_landscape_option_flows_through() {
    // Spec 12 maps `landscape = true` to the filter-options key
    // `IsLandscape` (boolean). The unit test
    // `office_options_landscape_and_pdfua_blob_keys` proves we emit the
    // key correctly in the JSON blob. This integration test verifies
    // *the convert succeeds* with the option set — LibreOffice itself
    // does not actually rotate the writer output via this property
    // (orientation is driven by the document's page style), so we do
    // **not** assert MediaBox dimensions here.
    let Some(lo) = engine().await else { return; };
    let opts = OfficeOptions {
        landscape: true,
        ..Default::default()
    };
    let bytes = lo
        .convert(&writer_fixture(), &opts)
        .await
        .expect("convert with landscape=true should not error");
    assert_pdf_loadable(&bytes);
}

#[tokio::test]
async fn convert_writer_page_ranges() {
    let Some(lo) = engine().await else { return; };

    // Full document: RTF fixture has three explicit `\page` breaks.
    let full = lo
        .convert(&writer_fixture(), &OfficeOptions::default())
        .await
        .expect("full convert");
    let full_doc = assert_pdf_loadable(&full);
    let full_pages = pdf_page_count(&full_doc);
    assert!(
        full_pages >= 2,
        "fixture should produce >= 2 pages, got {full_pages}"
    );

    // Page-range 1-1 → exactly one page.
    let opts = OfficeOptions {
        page_ranges: Some(PageRanges::parse("1-1").expect("parse")),
        ..Default::default()
    };
    let one = lo.convert(&writer_fixture(), &opts).await.expect("single");
    let one_doc = assert_pdf_loadable(&one);
    assert_eq!(pdf_page_count(&one_doc), 1);
}

#[tokio::test]
async fn convert_with_pdf_a_2b_writes_pdfa_metadata() {
    let Some(lo) = engine().await else { return; };
    let opts = OfficeOptions {
        pdf_a: Some(PdfAProfile::A2B),
        ..Default::default()
    };
    let bytes = lo.convert(&writer_fixture(), &opts).await.expect("convert");
    assert_pdf_loadable(&bytes);
    // PDF/A files carry an XMP metadata stream containing "pdfaid".
    let needle = b"pdfaid";
    assert!(
        bytes.windows(needle.len()).any(|w| w == needle),
        "PDF/A-2b output should embed an XMP metadata stream containing 'pdfaid'"
    );
}

#[tokio::test]
async fn convert_many_preserves_order() {
    let Some(lo) = engine().await else { return; };
    let inputs = vec![writer_fixture(), csv_fixture(), writer_fixture()];
    let out = lo
        .convert_many(&inputs, &OfficeOptions::default())
        .await
        .expect("convert_many");
    assert_eq!(out.len(), 3);
    for (i, b) in out.iter().enumerate() {
        assert!(b.starts_with(b"%PDF-"), "slot {i} not a pdf");
    }
    // Slots 0 and 2 are both the writer/RTF fixture; slot 1 is calc/CSV.
    // We don't compare bytes for equality (PDF metadata includes
    // timestamps), but slot 1 must differ from slots 0/2 in page count
    // (writer fixture is 3 pages, csv fixture is 1) — that proves order
    // wasn't shuffled.
    let pages: Vec<usize> = out
        .iter()
        .map(|b| pdf_page_count(&lopdf::Document::load_mem(b).expect("pdf")))
        .collect();
    assert!(
        pages[0] >= 2 && pages[2] >= 2,
        "writer slots should be multi-page, got {pages:?}"
    );
    assert_eq!(pages[1], 1, "csv slot should be single-page, got {pages:?}");
}

#[tokio::test]
async fn launch_fails_fast_with_bad_install_path() {
    // Provide a path that definitely contains no LibreOffice install.
    // LOK should fail quickly rather than hang.
    let cfg = LibreOfficeConfig {
        install_path: Some(std::path::PathBuf::from("/nonexistent/__no_lok__")),
        ..Default::default()
    };
    let started = Instant::now();
    let res = LibreOfficeEngine::launch(cfg).await;
    let elapsed = started.elapsed();

    match res {
        Err(EngineError::Internal(_)) | Err(EngineError::Timeout(_)) => {
            // Expected: LOK failed to open a library at the bogus path.
            assert!(
                elapsed < Duration::from_secs(10),
                "launch should fail fast, took {elapsed:?}"
            );
        }
        Ok(_) => panic!("launch should not succeed with a bad install path"),
        Err(other) => panic!("unexpected error variant: {other:?}"),
    }
}

#[tokio::test]
async fn convert_missing_input_io_error() {
    let Some(lo) = engine().await else { return; };
    let err = lo
        .convert(
            Path::new("/nonexistent/__pdfbro_no_input.docx"),
            &OfficeOptions::default(),
        )
        .await
        .expect_err("missing input must error");
    assert!(matches!(err, EngineError::Io(_)), "got {err:?}");
}

#[tokio::test]
async fn convert_unsupported_format_falls_back_to_generic_filter() {
    // Copy the RTF fixture under an extension absent from the filter
    // table; soffice should still detect RTF by content (`{\\rtf` magic).
    let Some(lo) = engine().await else { return; };
    let tmp = tempfile::tempdir().expect("tempdir");
    let src = tmp.path().join("sample.weird");
    std::fs::copy(writer_fixture(), &src).expect("copy");
    let bytes = lo
        .convert(&src, &OfficeOptions::default())
        .await
        .expect("generic filter convert");
    assert_pdf_loadable(&bytes);
}

#[tokio::test]
async fn concurrent_calls_serialize_safely() {
    // N callers submit conversions simultaneously. With LOK the worker
    // processes them serially, but every caller still receives the correct
    // result. Verifies the mpsc + oneshot plumbing under contention.
    let Some(lo) = engine().await else { return; };
    let inputs: Vec<PathBuf> = (0..4).map(|_| writer_fixture()).collect();
    let out = lo
        .convert_many(&inputs, &OfficeOptions::default())
        .await
        .expect("serialised converts");
    assert_eq!(out.len(), 4);
    for b in &out {
        assert!(b.starts_with(b"%PDF-"));
    }
}

#[tokio::test]
async fn healthy_returns_true_for_real_soffice() {
    let Some(lo) = engine().await else { return; };
    assert!(lo.healthy().await);
}

#[tokio::test]
async fn convert_corrupted_returns_corrupted_error() {
    let Some(lo) = engine().await else { return; };
    let tmp = tempfile::tempdir().expect("tempdir");
    let bad = tmp.path().join("truncated.docx");
    // First 200 bytes look like a valid OOXML local-file-header but no
    // central directory, so LO's type detection will reject it.
    let head = b"PK\x03\x04\x14\x00\x06\x00\x08\x00\x00\x00!\x00";
    let mut bytes = head.to_vec();
    bytes.resize(200, 0u8);
    std::fs::write(&bad, &bytes).expect("write");

    let err = lo
        .convert(&bad, &OfficeOptions::default())
        .await
        .expect_err("expected error on truncated docx");

    assert!(
        matches!(
            err,
            EngineError::LibreOfficeCorrupted(_) | EngineError::LibreOfficeUnsupportedFormat
        ),
        "got {err:?}"
    );
}

// NOTE: There is no integration test for lazy-start in this binary, by design.
// The libreofficekit crate enforces a process-global lock — only ONE
// `Office` instance can be alive in a process for the lifetime of that
// process (see `libreofficekit::sys::GLOBAL_OFFICE_LOCK`). Our worker
// thread additionally `std::mem::forget`s the Office on shutdown to
// bypass LO ≥ 6.5's atexit teardown bug, so the lock is never released
// even after `LibreOfficeEngine::shutdown()`.
//
// Together that means a second `LibreOfficeEngine::launch` in the same
// test binary always fails with "already another active instance"
// once any earlier test has touched the SHARED engine. We instead
// verify lazy-start via:
//   * the unit test on the underlying `should_exit_for_idle` helper
//     and the inspection-level simplicity of `init_worker`'s single-
//     flight guard, and
//   * the manual smoke test in `Dockerfile`-built containers (Task 14
//     step 2: `LIBREOFFICE_LAZY_START=true` confirmed at runtime).

#[tokio::test]
async fn z_shutdown_drains_then_rejects_new_requests() {
    let Some(lo) = engine().await else { return; };

    // Kick off a real conversion in the background — it should still
    // complete successfully because shutdown drains in-flight work.
    let lo_for_convert = lo.clone();
    let convert_task = tokio::spawn(async move {
        lo_for_convert
            .convert(&writer_fixture(), &OfficeOptions::default())
            .await
    });

    // Give the worker ~50 ms to actually pick up the request.
    tokio::time::sleep(Duration::from_millis(50)).await;

    // Shut down. Must drain the in-flight conversion successfully.
    let started = Instant::now();
    lo.shutdown().await.expect("shutdown");
    let shutdown_took = started.elapsed();

    let convert_result = convert_task.await.expect("join");
    assert!(convert_result.is_ok(), "in-flight convert was lost: {convert_result:?}");
    assert!(
        shutdown_took < Duration::from_secs(10),
        "shutdown was slow: {shutdown_took:?}"
    );

    // After shutdown, new requests fail-fast.
    let err = lo
        .convert(&writer_fixture(), &OfficeOptions::default())
        .await
        .expect_err("expected failure post-shutdown");
    assert!(matches!(err, EngineError::Internal(_)), "got {err:?}");
}
