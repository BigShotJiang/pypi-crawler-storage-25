"""External integration adapters."""
