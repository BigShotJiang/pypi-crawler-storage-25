from collections import defaultdict

import volgrids as vg
import volgrids.smiffer as sm

# ------------------------------------------------------------------------------
def _parse_atoms_triplet(triplet: str) -> tuple[str, str, str, str, bool]:
    def _assert(condition: bool):
        assert condition, \
            f"Triplet '{triplet}' is not in the expected formats 'I=T->H' or 'I=T0.T1->H'."

    stripped = triplet.strip('!')
    hbond_fixed = stripped != triplet

    parts = stripped.split('=')
    _assert(len(parts) == 2)

    interactor, direction = parts
    parts = direction.split("->")
    _assert(len(parts) == 2)

    tail, head = parts
    _assert(tail and head and interactor)

    ### valid syntax?  | yes | no |
    ### 'i=t->h'       |  X  |    |
    ### 'i=t0.t1->h'   |  X  |    |
    ### 'i=t0.t1.t2->h'|  X  |    |
    ### 'i=t0.->h'     |     | X  |
    ### 'i=.t1->h'     |     | X  |
    tail_points = tail.split('.')
    _assert(len(tail_points) > 0 and all(tail_points))

    return interactor, tail_points, head, hbond_fixed


# //////////////////////////////////////////////////////////////////////////////
class ParserChemTable:
    _RESNAME_NUCL_STANDARD = (
        "U", "C", "A", "G"
    )
    _RESNAME_DNA_TO_STANDARD = {
        "DT": "U", "DC": "C", "DA": "A", "DG": "G"
    }
    _RESNAME_ALTRNA_TO_STANDARD = {
        "RU": "U", "RC": "C", "RA": "A", "RG": "G"
    }

    # --------------------------------------------------------------------------
    def __init__(self, path_table):
        self._selection_query: str = ''
        self._selection_query_custom: str = ''
        self._parser_ini = vg.ParserIni.from_file(path_table)
        self._residues_hphob: dict[str, float] = {}
        self._atoms_hphob: defaultdict[str, dict[str, float]] = defaultdict(dict)
        self._names_stk: dict[str, list[str]] = defaultdict(list)
        self._names_hba: dict[str, list[tuple[str, str, str, bool]]] = {}
        self._names_hbd: dict[str, list[tuple[str, str, str, bool]]] = {}
        self._parse_table()


    # --------------------------------------------------------------------------
    def get_selection_query(self, use_custom):
        """
        Custom query includes an additional condition to select only the residues specified in the `CUSTOM_RESIDUES` parameter.
        Otherwise, the standard query is returned (i.e. that one specified in the .chem table), which does not filter by residue.
        """
        return self._selection_query_custom if use_custom else self._selection_query


    # --------------------------------------------------------------------------
    def get_residue_hphob(self, atom):
        resname = self._standardize_resname_nucl(atom.resname)
        return self._residues_hphob.get(resname)


    # --------------------------------------------------------------------------
    def get_atom_hphob(self, atom):
        resname = self._standardize_resname_nucl(atom.resname)
        dict_resid = self._atoms_hphob.get(resname)
        if dict_resid is None: return None
        return dict_resid.get(atom.name)


    # --------------------------------------------------------------------------
    def get_names_stacking(self, resname: str) -> list[str] | None:
        resname = self._standardize_resname_nucl(resname)
        return self._names_stk.get(resname)


    # --------------------------------------------------------------------------
    def get_names_hba(self, resname: str):
        resname = self._standardize_resname_nucl(resname)
        return self._names_hba.get(resname)


    # --------------------------------------------------------------------------
    def get_names_hbd(self, resname: str):
        resname = self._standardize_resname_nucl(resname)
        return self._names_hbd.get(resname)


    # --------------------------------------------------------------------------
    @classmethod
    def _standardize_resname_nucl(cls, resname: str) -> str:
        if not sm.CURRENT_MOLTYPE.is_rna(): return resname
        if resname in cls._RESNAME_NUCL_STANDARD: return resname

        if resname in cls._RESNAME_ALTRNA_TO_STANDARD:
            return cls._RESNAME_ALTRNA_TO_STANDARD[resname]

        if resname in cls._RESNAME_DNA_TO_STANDARD:
            return cls._RESNAME_DNA_TO_STANDARD[resname]

        return resname


    # --------------------------------------------------------------------------
    def _parse_table(self):
        ### extract values from the lines
        query = self._parser_ini.get("SELECTION_QUERY")
        if query is None: raise ValueError("No selection query found in the table file.")

        self._selection_query = query[0]
        self._selection_query_custom = self._selection_query

        if sm.CUSTOM_RESIDUES:
            self._selection_query_custom += " and ("
            for residue in sm.CUSTOM_RESIDUES.split():
                chain, resid = residue.split('.')
                self._selection_query_custom += f"(chainID {chain} and resid {resid}) or "
            self._selection_query_custom =\
                self._selection_query_custom[:-4] + ")" # remove the last " or "


        for resname, value in self._parser_ini.iter_splitted_lines("RES_HPHOBICITY", sep = ':'):
            self._residues_hphob[resname] = float(value)

        for names, value in self._parser_ini.iter_splitted_lines("ATOM_HPHOBICITY", sep = ':'):
            resname, atomname = names.split('/')
            self._atoms_hphob[resname][atomname] = float(value)

        for resname, atomnames in self._parser_ini.iter_splitted_lines("NAMES_STACKING", sep = ':'):
            self._names_stk[resname].append(atomnames)

        for resname, str_triplets in self._parser_ini.iter_splitted_lines("NAMES_HBACCEPTORS", sep = ':'):
            triplets = map(_parse_atoms_triplet, str_triplets.split())
            self._names_hba[resname] = [(hba,tail,head,False) for hba,tail,head,_ in triplets] # hbond_fixed must always be False for HBAcceptors

        for resname, str_triplets in self._parser_ini.iter_splitted_lines("NAMES_HBDONORS", sep = ':'):
            triplets = list(map(_parse_atoms_triplet, str_triplets.split()))
            self._names_hbd[resname] = triplets

        ### expand the atoms declared with the '*' wildcard to all residues (hydrophobicity)
        hphob_wildcard = self._atoms_hphob.get('*')
        if hphob_wildcard is None: return

        del self._atoms_hphob['*']
        for res_dict in self._atoms_hphob.values():
            res_dict.update(hphob_wildcard)


# //////////////////////////////////////////////////////////////////////////////
