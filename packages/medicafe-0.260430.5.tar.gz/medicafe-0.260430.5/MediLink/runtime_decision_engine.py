"""Runtime decision engine for transfer and interoperability behavior.

This module embeds operator runbook logic in executable policy so runtime behavior
can adapt to environment signals without adding more manual flags.
"""

from __future__ import absolute_import

import platform
import shutil


def _safe_int(value, default_value):
    try:
        return int(value)
    except Exception:
        return int(default_value)


def _default_policy():
    return {
        'profile': 'runtime_policy_error_fallback',
        'fallback_wait_seconds': 20,
        'direct_gas_fallback_enabled': True,
        'primary_transfer_route': 'browser_handoff',
        'secondary_transfer_route': 'direct_gas',
        'browser_handoff_enabled': True,
        'reasons': ['policy_resolution_failed', 'fallback_defaults_applied'],
    }


def _sanitize_policy(policy):
    """Normalize a policy dict to safe, bounded values."""
    base = _default_policy()
    if isinstance(policy, dict):
        base.update(policy)

    try:
        wait = int(base.get('fallback_wait_seconds', 20))
    except Exception:
        wait = 20
    base['fallback_wait_seconds'] = int(max(5, min(300, wait)))

    base['profile'] = str(base.get('profile') or 'runtime_policy_error_fallback')
    base['direct_gas_fallback_enabled'] = bool(base.get('direct_gas_fallback_enabled', True))
    primary_route = str(base.get('primary_transfer_route') or 'browser_handoff').strip().lower()
    secondary_route = str(base.get('secondary_transfer_route') or 'direct_gas').strip().lower()
    valid_routes = ('browser_handoff', 'direct_gas')
    if primary_route not in valid_routes:
        primary_route = 'browser_handoff'
    if secondary_route not in valid_routes:
        secondary_route = 'direct_gas'
    if secondary_route == primary_route:
        secondary_route = 'direct_gas' if primary_route == 'browser_handoff' else 'browser_handoff'
    base['primary_transfer_route'] = primary_route
    base['secondary_transfer_route'] = secondary_route
    base['browser_handoff_enabled'] = bool(base.get('browser_handoff_enabled', True))

    reasons = base.get('reasons')
    if isinstance(reasons, (list, tuple)):
        base['reasons'] = [str(r) for r in reasons if str(r).strip()]
    elif reasons:
        base['reasons'] = [str(reasons)]
    else:
        base['reasons'] = ['fallback_defaults_applied']

    return base


def resolve_transfer_runtime_policy(medi_config, use_http_mode, cert_mode):
    """Resolve transfer policy from environment + config hints.

    This function is intentionally no-throw for reliability-critical call sites.

    Returns dict with:
      - profile: short identifier for active environment profile
      - fallback_wait_seconds: wait before direct GAS fallback starts
      - direct_gas_fallback_enabled: bool
      - primary_transfer_route: browser_handoff|direct_gas
      - secondary_transfer_route: browser_handoff|direct_gas
      - browser_handoff_enabled: bool
      - reasons: list[str] for observability/telemetry

    Precedence:
      1) Safe explicit config (existing key) when valid.
      2) Environment defaults based on XP/certutil/runtime mode.
    """
    try:
        medi_config = medi_config or {}
        reasons = []
        profile = 'default_managed_https'

        configured_wait = _safe_int(medi_config.get('browser_handoff_fallback_seconds', 20), 20)
        # Keep runtime safe guardrails bounded.
        configured_wait = max(5, min(300, configured_wait))

        os_name = str(platform.system() or '')
        os_release = str(platform.release() or '')
        is_windows = (os_name == 'Windows')
        is_xp = is_windows and os_release.startswith('5.')
        certutil_present = bool(shutil.which('certutil')) if is_windows else True

        fallback_wait = configured_wait
        direct_gas_fallback_enabled = True
        primary_transfer_route = 'browser_handoff'
        secondary_transfer_route = 'direct_gas'
        browser_handoff_enabled = True

        if use_http_mode:
            profile = 'http_mode_local_loopback'
            # HTTP mode avoids trust friction; shorter wait improves recovery speed.
            fallback_wait = min(configured_wait, 12)
            reasons.append('http_mode_active')
        elif is_windows and str(cert_mode or '').strip().lower() == 'managed_ca':
            profile = 'windows_managed_ca_browser_handoff_with_direct_gas_fallback'
            direct_gas_fallback_enabled = True
            primary_transfer_route = 'browser_handoff'
            secondary_transfer_route = 'direct_gas'
            fallback_wait = configured_wait
            reasons.append('managed_ca_browser_handoff_primary')
            reasons.append('direct_gas_fallback_enabled')
            if is_xp:
                reasons.append('windows_xp_under_managed_ca')
            if not certutil_present:
                reasons.append('certutil_missing_managed_ca')
            else:
                reasons.append('certutil_present_managed_ca')
        elif is_xp:
            profile = 'windows_xp_https_legacy_tls'
            # Prefer direct GAS first on legacy XP stacks where browser->localhost trust is often the slow leg.
            # Skipped when cert_mode is managed_ca (handled above).
            fallback_wait = 5
            primary_transfer_route = 'direct_gas'
            secondary_transfer_route = 'browser_handoff'
            reasons.append('xp_legacy_tls_profile')
            reasons.append('primary_route=direct_gas')
        else:
            reasons.append('default_profile')

        reasons.append('cert_mode={}'.format(cert_mode if cert_mode else 'unknown'))

        return _sanitize_policy({
            'profile': profile,
            'fallback_wait_seconds': fallback_wait,
            'direct_gas_fallback_enabled': direct_gas_fallback_enabled,
            'primary_transfer_route': primary_transfer_route,
            'secondary_transfer_route': secondary_transfer_route,
            'browser_handoff_enabled': browser_handoff_enabled,
            'reasons': reasons,
        })
    except Exception as policy_err:
        fallback = _default_policy()
        fallback['reasons'] = list(fallback.get('reasons') or []) + [
            'resolver_exception={}'.format(policy_err.__class__.__name__)
        ]
        return _sanitize_policy(fallback)
