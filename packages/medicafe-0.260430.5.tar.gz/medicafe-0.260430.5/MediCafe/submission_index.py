"""
submission_index.py - Centralized submission index scaffolding (Phase 3)

Purpose:
- Provide a shared, efficient index of successful claim submissions (and optionally attempts)
- Avoid repeated scanning of historical receipt files across apps (MediLink, MediBot)
- Enable fast deconfliction, window validation, and reporting

Design:
- Backed by a compact JSONL file in receipts_root (one JSON record per line)
- Claim key: (patient_id, payer_id or primary_insurance, date_of_service, service_hash)
- Fields: claim_key, patient_id, payer_id, primary_insurance, dos, endpoint, submitted_at,
          receipt_file, status, checksum, notes, duplicate_override

This is an incremental implementation with JSONL; SQLite can be added later if needed.
"""
import os
import json
import time

META_FILENAME = 'submission_index_meta.json'
INDEX_FILENAME = 'submission_index.jsonl'
LOCK_FILENAME = 'submission_index.lock'

# New: ack field keys for richer timeline entries
ACK_FIELDS = ['ack_type', 'ack_timestamp', 'control_ids', 'source', 'file_name']

# JSONL row kinds (Phase 0 crosswalk contract)
RECORD_TYPE_SUBMISSION = 'submission'
RECORD_TYPE_ACK = 'ack_event'


def _is_ack_event_entry(entry):
    if not isinstance(entry, dict):
        return False
    if entry.get('notes') == 'ack event':
        return True
    return str(entry.get('record_type', '')).strip() == RECORD_TYPE_ACK


def _is_submission_index_entry(entry):
    """True for successful submission rows (excludes ack timeline lines)."""
    if not isinstance(entry, dict) or _is_ack_event_entry(entry):
        return False
    rt = str(entry.get('record_type', '')).strip()
    if not rt or rt == RECORD_TYPE_SUBMISSION:
        return True
    return rt == RECORD_TYPE_SUBMISSION


def build_initial_index(receipts_root, lookback_days=200):
    """
    Initial index builder for legacy receipts.
    NOTE: Legacy receipts do not include patient_id in the printed table, so we cannot
    reliably backfill claim-level keys from historical receipts. This builder will:
    - Create index/meta files if missing
    - Record meta stats
    - Return 0 (no historical claim entries)
    """
    if not os.path.isdir(receipts_root):
        return 0
    _ensure_files_exist(receipts_root)
    count, max_mtime = _get_receipt_stats(receipts_root)
    meta = _read_meta(receipts_root)
    meta['last_indexed_mtime'] = max_mtime
    meta['last_indexed_count'] = count
    meta['last_full_build_at'] = time.time()
    meta['rebuild_state'] = 'none'
    meta['rebuild_progress'] = 0
    _write_meta(receipts_root, meta)
    return 0


def append_submission_record(receipts_root, record):
    """
    Append a new successful submission record to the index after a claim is submitted.
    """
    try:
        _ensure_files_exist(receipts_root)
        record = _normalize_submission_record_for_index(record)
        line = json.dumps(record)
        path = _index_path(receipts_root)
        with open(path, 'a') as f:
            f.write(line)
            f.write("\n")
    except Exception:
        pass


def _safe_text(value):
    if value is None:
        return ''
    try:
        return str(value).strip()
    except Exception:
        return ''


def _claim_key_parts(claim_key):
    text = _safe_text(claim_key)
    if not text:
        return []
    return text.split('|')


def _normalize_submission_record_for_index(record):
    """
    Best-effort identity completion for submission rows before JSONL append.
    Ack/timeline rows are intentionally exempt because they may not be claim scoped.
    """
    if not isinstance(record, dict):
        return record
    out = dict(record)
    if _is_ack_event_entry(out):
        return out

    parts = _claim_key_parts(out.get('claim_key'))
    key_patient = parts[0].strip() if len(parts) > 0 else ''
    key_payer = parts[1].strip() if len(parts) > 1 else ''
    key_dos = parts[2].strip() if len(parts) > 2 else ''

    internal_chart = _safe_text(out.get('internal_chart') or out.get('patient_id') or key_patient)
    if internal_chart:
        if not _safe_text(out.get('internal_chart')):
            out['internal_chart'] = internal_chart
        if not _safe_text(out.get('patient_id')):
            out['patient_id'] = internal_chart

    internal_patid = _safe_text(out.get('internal_patid') or out.get('patid') or out.get('PATID'))
    if internal_patid and not _safe_text(out.get('internal_patid')):
        out['internal_patid'] = internal_patid

    payer_id = _safe_text(out.get('payer_id') or key_payer)
    if payer_id and not _safe_text(out.get('payer_id')):
        out['payer_id'] = payer_id

    dos = _safe_text(out.get('dos') or out.get('service_start_date') or key_dos)
    if dos and not _safe_text(out.get('dos')):
        out['dos'] = dos

    patient_name = _safe_text(out.get('patient_name'))
    if not patient_name:
        first = _safe_text(out.get('member_first_name') or out.get('memberFirstName'))
        last = _safe_text(out.get('member_last_name') or out.get('memberLastName'))
        if first or last:
            out['patient_name'] = '{} {}'.format(first, last).strip()

    return out


def find_by_claim_key(receipts_root, claim_key):
    """
    Look up a claim by its stable key to detect potential duplicates.
    Returns the first matching record or None (legacy behavior).
    Prefer find_by_claim_key_latest for resubmit-safe resolution.
    """
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return None
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if isinstance(entry, dict) and entry.get('claim_key') == claim_key:
                        return entry
                except Exception:
                    continue
    except Exception:
        pass
    return None


def find_by_claim_key_latest(receipts_root, claim_key):
    """
    Last matching submission row for claim_key (skips ack events).
    Use for duplicate detection and remittance crosswalk after resubmits.
    """
    if not claim_key:
        return None
    last = None
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return None
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not isinstance(entry, dict):
                        continue
                    if not _is_submission_index_entry(entry):
                        continue
                    if entry.get('claim_key') == claim_key:
                        last = entry
                except Exception:
                    continue
    except Exception:
        pass
    return last


def load_latest_submissions_by_claim_key(receipts_root):
    """
    Scan submission_index.jsonl once; return dict claim_key -> latest submission row.
    Skips ack events and non-submission lines.
    """
    result = {}
    if not receipts_root:
        return result
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return result
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not _is_submission_index_entry(entry):
                        continue
                    ck = entry.get('claim_key')
                    if ck:
                        result[ck] = entry
                except Exception:
                    continue
    except Exception:
        pass
    return result


def load_latest_submissions_by_submitted_claim_number(receipts_root):
    """
    dict submitted_claim_number -> latest submission row (CLM01 / format_claim_number shape).
    """
    result = {}
    if not receipts_root:
        return result
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return result
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not _is_submission_index_entry(entry):
                        continue
                    scn = str(entry.get('submitted_claim_number', '') or '').strip()
                    if scn:
                        result[scn] = entry
                except Exception:
                    continue
    except Exception:
        pass
    return result


def find_by_dos_and_basename(receipts_root, date_of_service, basename):
    """
    Look up a claim by (dos, receipt_file) when full claim_key may differ.
    Used when X12 extraction fails on pre-check but prior submission wrote
    with full key (patient_id|payer_id|dos|basename). Returns first match or None.
    """
    if not date_of_service and not basename:
        return None
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return None
        dos_norm = (date_of_service or "").strip()
        base_norm = (basename or "").strip()
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not isinstance(entry, dict):
                        continue
                    entry_dos = (entry.get('dos') or entry.get('service_start_date') or "").strip()
                    entry_file = (entry.get('receipt_file') or "").strip()
                    if entry_file == base_norm and (not dos_norm or entry_dos == dos_norm):
                        return entry
                except Exception:
                    continue
    except Exception:
        pass
    return None


def reconcile_recent_receipts(receipts_root, since_timestamp, max_seconds):
    """
    Incrementally scan receipts newer than 'since_timestamp' and update meta only.
    JSONL index is built at submission time; this reconcile only updates meta counters.
    Returns number of new files detected.
    """
    start = time.time()
    count = 0
    try:
        for root, dirs, files in os.walk(receipts_root):
            for name in files:
                try:
                    _ = name.encode('ascii')
                except Exception:
                    continue
                try:
                    mtime = os.path.getmtime(os.path.join(root, name))
                    if mtime > since_timestamp:
                        count += 1
                except Exception:
                    continue
                if int(time.time() - start) >= int(max_seconds):
                    return count
    except Exception:
        return count
    return count


def compute_claim_key(internal_chart, payer_id, primary_insurance, date_of_service, service_hash):
    """
    Compute a deterministic claim key for deconfliction.
    First argument is internal_chart (clinic CHART / CLM01 family), not wire member_id.
    """
    return "|".join([
        (internal_chart or ""),
        (payer_id or primary_insurance or ""),
        (date_of_service or ""),
        (service_hash or "")
    ])


def append_ack_event(receipts_root, claim_key, status_text, ack_type, file_name, control_ids, source, ack_timestamp=None):
    """
    Append a lightweight ack/timeline event to the index. XP/Py3.4/ASCII-safe.
    - claim_key may be empty if unknown. Caller should pass when available.
    - control_ids is a dict with optional ISA/GS/ST/TRN or transactionId.
    """
    try:
        _ensure_files_exist(receipts_root)
        event = {
            'record_type': RECORD_TYPE_ACK,
            'claim_key': claim_key or '',
            'patient_id': '',
            'payer_id': '',
            'primary_insurance': '',
            'dos': '',
            'endpoint': source or 'download_ack',
            'submitted_at': '',
            'receipt_file': file_name or '',
            'status': status_text or '',
            'notes': 'ack event',
        }
        # Attach ack fields with basic validation
        try:
            event['ack_type'] = ack_type or ''
            event['ack_timestamp'] = ack_timestamp or int(time.time())
            event['control_ids'] = control_ids or {}
            event['source'] = source or ''
            event['file_name'] = file_name or ''
        except Exception:
            pass
        path = _index_path(receipts_root)
        line = json.dumps(event)
        f = open(path, 'a')
        try:
            f.write(line)
            f.write("\n")
        finally:
            f.close()
    except Exception:
        pass


# ------------------------- ASCII-safe meta/lock helpers -----------------------

def _meta_path(root_dir):
    return os.path.join(root_dir, META_FILENAME)


def _index_path(root_dir):
    return os.path.join(root_dir, INDEX_FILENAME)


def _lock_path(root_dir):
    return os.path.join(root_dir, LOCK_FILENAME)


def _ensure_files_exist(root_dir):
    try:
        meta_path = _meta_path(root_dir)
        if not os.path.exists(meta_path):
            _write_meta(root_dir, {
                'last_indexed_mtime': 0.0,
                'last_indexed_count': 0,
                'last_full_build_at': 0.0,
                'rebuild_state': 'none',
                'rebuild_progress': 0
            })
        index_path = _index_path(root_dir)
        if not os.path.exists(index_path):
            with open(index_path, 'w') as f:
                f.write("")
    except Exception:
        pass


def _read_meta(root_dir):
    path = _meta_path(root_dir)
    if not os.path.exists(path):
        return {
            'last_indexed_mtime': 0.0,
            'last_indexed_count': 0,
            'last_full_build_at': 0.0,
            'rebuild_state': 'none',  # 'none' | 'pending' | 'in_progress'
            'rebuild_progress': 0
        }
    try:
        with open(path, 'r') as f:
            data = f.read()
            try:
                meta = json.loads(data)
            except Exception:
                return {
                    'last_indexed_mtime': 0.0,
                    'last_indexed_count': 0,
                    'last_full_build_at': 0.0,
                    'rebuild_state': 'none',
                    'rebuild_progress': 0
                }
            return meta if isinstance(meta, dict) else {}
    except Exception:
        return {
            'last_indexed_mtime': 0.0,
            'last_indexed_count': 0,
            'last_full_build_at': 0.0,
            'rebuild_state': 'none',
            'rebuild_progress': 0
        }


def _write_meta(root_dir, meta):
    try:
        with open(_meta_path(root_dir), 'w') as f:
            f.write(json.dumps(meta))
    except Exception:
        pass


def _try_acquire_lock(root_dir):
    lock = _lock_path(root_dir)
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        return True
    except Exception:
        return False


def _release_lock(root_dir):
    try:
        os.remove(_lock_path(root_dir))
    except Exception:
        pass


def _get_receipt_stats(receipts_root):
    count = 0
    max_mtime = 0.0
    try:
        for root, dirs, files in os.walk(receipts_root):
            for name in files:
                try:
                    _ = name.encode('ascii')
                except Exception:
                    continue
                count += 1
                try:
                    mtime = os.path.getmtime(os.path.join(root, name))
                    if mtime > max_mtime:
                        max_mtime = mtime
                except Exception:
                    continue
    except Exception:
        pass
    return count, max_mtime


# ------------------------- Public entry point --------------------------------

def ensure_submission_index(receipts_root, lookback_days=200, large_growth_threshold=0.1, max_inline_seconds=2):
    """
    XP/ASCII-safe, inline-only upkeep for the submission index.
    - No background tasks
    - Bounded work per call
    - Chunked rebuild across boots
    """
    if not receipts_root or not os.path.isdir(receipts_root):
        return

    # Ensure files exist early
    _ensure_files_exist(receipts_root)

    if not _try_acquire_lock(receipts_root):
        return

    try:
        meta = _read_meta(receipts_root)
        current_count, current_max_mtime = _get_receipt_stats(receipts_root)

        if meta.get('last_indexed_mtime', 0.0) == 0.0 and meta.get('last_indexed_count', 0) == 0:
            # First-time or corrupt meta: do bounded initial build
            build_initial_index(receipts_root, lookback_days)
            return

        # Incremental reconcile if new files detected by mtime
        if current_max_mtime > meta.get('last_indexed_mtime', 0.0):
            added = reconcile_recent_receipts(receipts_root, meta.get('last_indexed_mtime', 0.0), max_inline_seconds)
            meta['last_indexed_mtime'] = current_max_mtime
            meta['last_indexed_count'] = meta.get('last_indexed_count', 0) + int(added)
            _write_meta(receipts_root, meta)
            return

        # Large growth heuristic -> schedule chunked rebuild (across boots)
        last_count = meta.get('last_indexed_count', 0)
        delta = current_count - last_count
        if delta > 0 and delta >= max(100, int(large_growth_threshold * (last_count or 1))):
            if meta.get('rebuild_state') == 'none':
                meta['rebuild_state'] = 'pending'
                meta['rebuild_progress'] = 0
                _write_meta(receipts_root, meta)
            return

        # If rebuild pending, we would process a chunk here in a future implementation
        return
    finally:
        _release_lock(receipts_root)


# ------------------------- Query helper functions -----------------------------

def get_submission_by_transaction_id(receipts_root, transaction_id):
    """
    Find a submission record by transactionId.
    
    Args:
        receipts_root: Path to receipts directory
        transaction_id: Transaction ID to search for
    
    Returns:
        dict: Submission record if found, None otherwise
    """
    if not transaction_id:
        return None
    
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return None
        
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not isinstance(entry, dict):
                        continue
                    
                    # Check transactionId in submission record
                    if entry.get('transactionId') == transaction_id:
                        return entry
                    
                    # Check transactionId in ack event control_ids
                    control_ids = entry.get('control_ids', {})
                    if isinstance(control_ids, dict):
                        if control_ids.get('transactionId') == transaction_id:
                            return entry
                            
                except Exception:
                    continue
                    
    except Exception:
        pass
    
    return None


def get_ack_events_by_transaction_id(receipts_root, transaction_id):
    """
    Get all ack events (277CA, etc.) for a given transactionId.
    
    Args:
        receipts_root: Path to receipts directory
        transaction_id: Transaction ID to search for
    
    Returns:
        list: List of ack event records matching the transactionId
    """
    if not transaction_id:
        return []
    
    results = []
    
    try:
        path = _index_path(receipts_root)
        if not os.path.exists(path):
            return results
        
        with open(path, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if not isinstance(entry, dict):
                        continue
                    
                    # Only look at ack events
                    if entry.get('notes') != 'ack event':
                        continue
                    
                    # Check transactionId in control_ids
                    control_ids = entry.get('control_ids', {})
                    if isinstance(control_ids, dict):
                        if control_ids.get('transactionId') == transaction_id:
                            results.append(entry)
                            
                except Exception:
                    continue

    except Exception:
        pass

    return results


def summarize_submission_index_identity(index_path):
    """
    Scan submission_index.jsonl for identity completeness on submission rows.
    Ack/timeline rows increment ack_exempt only (transport-only / exempt).
    Missing_* counts are per-row tallies (a row may increment multiple buckets).
    """
    out = {
        'schema_version': 1,
        'rows_scanned': 0,
        'ack_exempt': 0,
        'submission_rows': 0,
        'identity_complete': 0,
        'missing_patient_id': 0,
        'missing_patient_name': 0,
        'missing_claim_number': 0,
        'missing_claim_key': 0,
        'missing_payer_id': 0,
        'missing_dos': 0,
    }
    if not index_path or not os.path.isfile(index_path):
        out['error'] = 'index_missing'
        return out
    try:
        with open(index_path, 'r') as handle:
            for line in handle:
                text = str(line or '').strip()
                if not text:
                    continue
                try:
                    row = json.loads(text)
                except Exception:
                    continue
                if not isinstance(row, dict):
                    continue
                out['rows_scanned'] += 1
                if _is_ack_event_entry(row):
                    out['ack_exempt'] += 1
                    continue
                if not _is_submission_index_entry(row):
                    continue
                out['submission_rows'] += 1
                pid = _safe_text(row.get('patient_id') or row.get('internal_chart') or row.get('internal_patid'))
                pname = _safe_text(row.get('patient_name'))
                cnum = _safe_text(row.get('claim_number') or row.get('claimNumber'))
                ckey = _safe_text(row.get('claim_key'))
                payer = _safe_text(row.get('payer_id') or row.get('primary_insurance'))
                dos = _safe_text(
                    row.get('dos')
                    or row.get('service_start_date')
                    or row.get('service_date')
                )
                row_miss = False
                if not pid:
                    out['missing_patient_id'] += 1
                    row_miss = True
                if not pname:
                    out['missing_patient_name'] += 1
                    row_miss = True
                if not cnum:
                    out['missing_claim_number'] += 1
                    row_miss = True
                if not ckey:
                    out['missing_claim_key'] += 1
                    row_miss = True
                if not payer:
                    out['missing_payer_id'] += 1
                    row_miss = True
                if not dos:
                    out['missing_dos'] += 1
                    row_miss = True
                if not row_miss:
                    out['identity_complete'] += 1
    except Exception as exc:
        out['error'] = str(exc)
    return out
