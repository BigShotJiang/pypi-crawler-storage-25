#!/usr/bin/env python
"""
Layer 1 join debug pack: deterministic parse-normalize-join diagnostics (CSV / DOCX / DAT).
XP-compatible: Python 3.4.4, stdlib only.

Not a readiness layer — narrow instrumentation at the annotate_csv_docx_join /
annotate_dat_csv_alignment boundary only.
"""
from __future__ import print_function

import hashlib
import json
import os

LAYER1_SCHEMA_VERSION = "layer1_join_debug_v1"
JOIN_KEY_POLICY = "patient_id+surgery_date"

SAMPLES_CAP_PER_KIND = 8
TOTAL_SAMPLES_CAP = 64


def _load_json_dict(text):
    try:
        data = json.loads(text or "{}")
    except (TypeError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _to_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _sanitize_ext_piece(suffix):
    """Keep a short extension fragment for telemetry; alphanumeric + dot only."""
    out = []
    try:
        for c in str(suffix or "").lower()[:16]:
            if c.isalnum() or c == ".":
                out.append(c)
    except Exception:
        return ""
    return "".join(out)


def _source_locator_evidence_token(locator_or_path):
    """
    Redacted locator sketch for support JSONL: SHA-256 prefix + extension +
    coarse shape (UTF-8 byte length, path segment count). Never embeds basename
    text (filenames often carry names, MRNs, or chart tokens).
    """
    s = ""
    try:
        s = str(locator_or_path or "").strip().replace("\\", "/")
    except Exception:
        s = ""
    if not s:
        return "h16:|ext:|path_bytes:0|segments:0"
    slash = s.rfind("/")
    dot = s.rfind(".")
    ext = "(none)"
    if dot > slash:
        ext = _sanitize_ext_piece(s[dot:])
        if not ext.startswith(".") or len(ext) < 2:
            ext = "(none)"
    try:
        b = len(s.encode("utf-8"))
    except Exception:
        b = len(s)
    seg_n = 0
    try:
        for part in s.split("/"):
            if part:
                seg_n += 1
    except Exception:
        seg_n = 0
    h = _sha16("layer1_source_locator|{0}".format(s))
    return "h16:{0}|ext:{1}|path_bytes:{2}|segments:{3}".format(h, ext, b, seg_n)


def _sha16(text):
    h = hashlib.sha256()
    try:
        h.update((text or "").encode("utf-8"))
    except Exception:
        h.update(b"")
    return h.hexdigest()[:16]


def _patient_id_token(pid, classify_fn):
    if pid is None or str(pid).strip() == "":
        return {"shape": "empty", "diag_token": "external_id_missing", "raw_len": 0}
    diag = classify_fn(pid, "layer1_join_debug") if callable(classify_fn) else {}
    if not isinstance(diag, dict):
        diag = {}
    if diag.get("is_valid"):
        return {
            "shape": "digits5_valid",
            "diag_token": "external_id_digits5",
            "raw_len": _to_int(diag.get("length"), len(str(pid).strip())),
        }
    reason = str(diag.get("reason") or "invalid").strip() or "invalid"
    fam = str(diag.get("pattern_family") or "").strip()
    pk = "{0}:{1}".format(reason, fam) if fam else reason
    return {
        "shape": "invalid",
        "diag_token": pk[:80],
        "raw_len": _to_int(diag.get("length"), len(str(pid).strip())),
    }


def _join_key_token(norm_key):
    if not norm_key:
        return ""
    parts = str(norm_key).split("|", 1)
    pid_tok = _sha16("pid|{0}".format(parts[0] if parts else ""))
    date_part = parts[1] if len(parts) > 1 else ""
    return "{0}|{1}".format(pid_tok, date_part)


def _csv_docx_join_key(extract_external_patient_id_fn, normalize_surgery_date_key_fn, row):
    pid = ""
    nk = ""
    try:
        pid = extract_external_patient_id_fn(row) if callable(extract_external_patient_id_fn) else ""
        dt_raw = ""
        try:
            from patient_field_mapper import extract_surgery_date

            dt_raw = extract_surgery_date(row) if isinstance(row, dict) else ""
        except Exception:
            dt_raw = ""
        nk = normalize_surgery_date_key_fn(dt_raw) if callable(normalize_surgery_date_key_fn) else ""
    except Exception:
        pid = ""
        nk = ""
    pid = str(pid or "").strip()
    nk = str(nk or "").strip()
    if not pid or not nk:
        return ""
    return "{0}|{1}".format(pid, nk)


def _docx_join_key_from_rec(rec, normalize_surgery_date_key_fn):
    provenance = _load_json_dict(rec.get("provenance_json"))
    data = _load_json_dict(rec.get("canonical_json"))
    pid = str(provenance.get("patient_id") or data.get("patient_id") or "").strip()
    sk = provenance.get("schedule_key") or data.get("schedule_key")
    nk = ""
    try:
        nk = normalize_surgery_date_key_fn(sk) if callable(normalize_surgery_date_key_fn) else ""
    except Exception:
        nk = ""
    nk = str(nk or "").strip()
    if not pid or not nk:
        return ""
    return "{0}|{1}".format(pid, nk)


def _dat_join_key_extract(rec, extract_dat_identity_fn, normalize_surgery_date_key_fn):
    """
    resolve_dat-backed patient id + date from canonical dat_record.
    extract_dat_identity_fn(rec) -> (pid, dos_raw); default uses join_contract.
    """
    data = _load_json_dict(rec.get("canonical_json"))
    provenance = _load_json_dict(rec.get("provenance_json"))
    if callable(extract_dat_identity_fn):
        pid, dos_raw = extract_dat_identity_fn(data)
    else:
        pid, dos_raw = "", ""
    pid = str(pid or "").strip()
    nk = ""
    try:
        nk = normalize_surgery_date_key_fn(dos_raw) if callable(normalize_surgery_date_key_fn) else ""
    except Exception:
        nk = ""
    nk = str(nk or "").strip()
    if not pid or not nk:
        return "", dos_raw or "", nk, provenance
    return "{0}|{1}".format(pid, nk), dos_raw or "", nk, provenance


def _infer_source_class(canonical_type):
    ct = str(canonical_type or "").strip().lower()
    if ct == "patient_csv_row":
        return "csv"
    if ct == "docx_schedule":
        return "docx"
    if ct == "dat_record":
        return "dat"
    return "other"


def _count_multimap(keys_seq):
    m = {}
    for k in keys_seq:
        kk = str(k or "").strip()
        if not kk:
            continue
        m[kk] = m.get(kk, 0) + 1
    return m


def _ambiguous_distinct_keys(mm):
    return len([kk for kk, c in mm.items() if _to_int(c, 0) > 1])


def _source_inventory(canonical_records, ingress_stats, patient_field_mapper_mod, join_extract_fn):
    extract_pid = getattr(patient_field_mapper_mod, "extract_external_patient_id", lambda r: "")
    extract_surgery = getattr(patient_field_mapper_mod, "extract_surgery_date", lambda r: "")
    norm_date = getattr(patient_field_mapper_mod, "normalize_surgery_date_key", lambda v: "")
    is_valid = getattr(patient_field_mapper_mod, "is_valid_external_patient_id_5_digit", lambda v: False)
    classify_fn = getattr(patient_field_mapper_mod, "classify_external_patient_id_5_digit", lambda v, s=None: {})

    inv = {}
    classes = ("csv", "docx", "dat")
    for c in classes:
        inv[c] = {
            "total_canonical_records": 0,
            "keyable_records": 0,
            "missing_patient_id": 0,
            "invalid_patient_id": 0,
            "missing_date": 0,
            "parse_rejected_artifacts": 0,
            "artifacts_processed": 0,
        }

    stats = ingress_stats if isinstance(ingress_stats, dict) else {}
    for c in classes:
        block = stats.get(c) if isinstance(stats.get(c), dict) else {}
        inv[c]["parse_rejected_artifacts"] = _to_int(block.get("parse_rejected_artifacts"), 0)
        inv[c]["artifacts_processed"] = _to_int(block.get("artifacts_processed"), 0)

    for rec in canonical_records or []:
        sc = _infer_source_class(rec.get("canonical_type") or "")
        if sc not in inv:
            continue
        bucket = inv[sc]
        bucket["total_canonical_records"] += 1
        cid = ""

        raw = _load_json_dict(rec.get("canonical_json"))

        pid = ""
        dos_raw = ""

        keyable = False
        missing_pid = False
        invalid_pid = False
        missing_date = False

        try:
            if sc == "csv":
                pid = str(extract_pid(raw) if callable(extract_pid) else "").strip()
                dos_raw = str(extract_surgery(raw) if callable(extract_surgery) else "").strip()
            elif sc == "docx":
                prov_inner = _load_json_dict(rec.get("provenance_json"))
                pid = str(prov_inner.get("patient_id") or raw.get("patient_id") or "").strip()
                sk_in = prov_inner.get("schedule_key") or raw.get("schedule_key")
                dos_raw = str(sk_in or "").strip()
            else:
                pid, dos_raw = join_extract_fn(raw) if callable(join_extract_fn) else ("", "")
                pid = str(pid or "").strip()
                dos_raw = str(dos_raw or "").strip()

            nk = ""
            try:
                nk = str(norm_date(dos_raw) if callable(norm_date) else "").strip()
            except Exception:
                nk = ""

            if not pid:
                missing_pid = True
            elif callable(is_valid) and not is_valid(pid):
                invalid_pid = True
            if not nk:
                missing_date = True

            if sc == "csv":
                jk_inner = ""
                try:
                    jk_inner = _csv_docx_join_key(extract_pid, norm_date, raw)
                except Exception:
                    jk_inner = ""
                keyable = bool(jk_inner)
            elif sc == "docx":
                keyable = bool(_docx_join_key_from_rec(rec, norm_date))
            else:
                jk_inner = ""
                try:
                    jk_inner, _, __, ___ = _dat_join_key_extract(rec, join_extract_fn, norm_date)
                except Exception:
                    jk_inner = ""
                keyable = bool(jk_inner)

        except Exception:
            missing_pid = True
            missing_date = True
            keyable = False

        if keyable:
            bucket["keyable_records"] += 1
        if missing_pid:
            bucket["missing_patient_id"] += 1
        if invalid_pid:
            bucket["invalid_patient_id"] += 1
        if missing_date:
            bucket["missing_date"] += 1

    return inv, {
        "extract_external_patient_id": extract_pid,
        "normalize_surgery_date_key": norm_date,
        "is_valid_external_patient_id_5_digit": is_valid,
        "classify_external_patient_id_5_digit": classify_fn,
        "extract_dat_join_identity": join_extract_fn,
    }


def _overlap_metrics(csv_keys, docx_keys, dat_keys):
    """
    Arguments are flattened per-record join-key lists (empty strings filtered by callers).
    """
    scsv = set(csv_keys or [])
    sdoc = set(docx_keys or [])
    sdat = set(dat_keys or [])

    return {
        "csv_docx": len(scsv & sdoc),
        "dat_csv": len(sdat & scsv),
        "dat_docx": len(sdat & sdoc),
        "all_three": len(scsv & sdoc & sdat),
        "csv_only": len(scsv - sdoc - sdat),
        "docx_only": len(sdoc - scsv - sdat),
        "dat_only": len(sdat - scsv - sdoc),
    }


def _normalized_key_presence(canonical_records, helpers):
    """Distinct join keys contributed by each source."""
    extract_pid = helpers["extract_external_patient_id"]
    norm_date = helpers["normalize_surgery_date_key"]
    extract_dat_join = helpers.get("extract_dat_join_identity")

    ckeys = []
    dkeys = []
    xkeys = []
    extract_dat = None
    try:
        from join_contract import extract_dat_join_identity
        extract_dat = extract_dat_join_identity
    except Exception:
        extract_dat = extract_dat_join

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        raw = _load_json_dict(rec.get("canonical_json"))
        if ctype == "patient_csv_row":
            try:
                from patient_field_mapper import extract_surgery_date
                jk = _csv_docx_join_key(extract_pid, norm_date, raw)
                if jk:
                    ckeys.append(jk)
            except Exception:
                pass
        elif ctype == "docx_schedule":
            jk = _docx_join_key_from_rec(rec, norm_date)
            if jk:
                xkeys.append(jk)
        elif ctype == "dat_record":
            jk = ""
            try:
                jk, _, __, ___ = _dat_join_key_extract(rec, extract_dat, norm_date)
            except Exception:
                jk = ""
            if jk:
                dkeys.append(jk)

    return {
        "csv_distinct_normalized_key_count": len(set(ckeys)),
        "docx_distinct_normalized_key_count": len(set(xkeys)),
        "dat_distinct_normalized_key_count": len(set(dkeys)),
    }


def compute_layer1_support_bundle_attachment_recommended(
        summary_fragment,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        phase_d_ok=True,
        recommendation_kind=""):
    """
    True when run-evidence/support bundle should attach Layer 1 artifacts.
    """
    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}

    rk = str(recommendation_kind or "").strip()
    if rk == "review_dat_qa_full_block":
        return bool(summary_fragment.get("layer1_join_debug_generated"))

    if not summary_fragment.get("layer1_join_debug_generated"):
        return False

    if not phase_d_ok:
        return True

    cmat = _to_int(csv_docx_join_telemetry.get("matched_count"), 0)
    dmat = _to_int(dat_csv_join_telemetry.get("matched_count"), 0)
    if _to_int(summary_fragment.get("layer1_invalid_external_pressure"), 0) > 0:
        return True
    # zero overlap pressure
    ck = _to_int(csv_docx_join_telemetry.get("csv_join_key_count"), 0)
    dk = _to_int(csv_docx_join_telemetry.get("docx_join_key_count"), 0)
    if ck > 0 and dk > 0 and cmat == 0:
        return True
    dk2 = _to_int(summary_fragment.get("layer1_dat_keyable_count"), 0)
    dk_csv = _to_int(dat_csv_join_telemetry.get("dat_only_count"), 0)
    crc = _to_int(csv_docx_join_telemetry.get("csv_join_key_count"), 0)
    if crc > 0 and dk2 > 0 and dmat == 0:
        return True
    invalid_join = _to_int(dat_csv_join_telemetry.get("invalid_external_id_join_block_count"), 0)
    if invalid_join > 0:
        return True
    tb = str(summary_fragment.get("layer1_top_blocker") or "").strip()
    if tb:
        high_signal = (
            "dat_parse_rejects",
            "dat_zero_selected",
            "invalid_external_patient_id",
            "missing_dos",
            "csv_docx_zero_overlap",
            "dat_csv_zero_overlap",
            "ambiguous_join_keys",
        )
        if tb in high_signal:
            return True
    return False


def _rank_blockers(
        ingress_stats,
        source_inv,
        overlap,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        normalized_key_presence,
        _dat_keyable_count_unused,
):
    blockers = []
    agg = ingress_stats if isinstance(ingress_stats, dict) else {}
    dat_parse = _to_int((agg.get("dat") or {}).get("parse_rejected_artifacts"), 0)

    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}

    if _to_int((agg.get("dat") or {}).get("artifacts_processed"), 0) == 0 and _to_int(
            source_inv.get("dat", {}).get("total_canonical_records"), 0
    ) == 0:
        blockers.append({
            "code": "dat_zero_selected",
            "rank": 1,
            "detail": "no_dat_artifacts_processed_or_canonical_records",
        })

    if dat_parse > 0:
        blockers.append({"code": "dat_parse_rejects", "rank": 2, "detail": str(dat_parse)})

    inv_csv = dat_csv_join_telemetry.get("invalid_external_id_csv_count") or 0
    inv_dat = dat_csv_join_telemetry.get("invalid_external_id_dat_count") or 0
    inv_join = dat_csv_join_telemetry.get("invalid_external_id_join_block_count") or 0
    if _to_int(inv_csv, 0) + _to_int(inv_dat, 0) + _to_int(inv_join, 0) > 0:
        blockers.append({"code": "invalid_external_patient_id", "rank": 3, "detail": "csv={0},dat={1},join_block={2}".format(
            inv_csv, inv_dat, inv_join)})

    miss_dos = (
        _to_int(source_inv.get("csv", {}).get("missing_date"), 0)
        + _to_int(source_inv.get("docx", {}).get("missing_date"), 0)
        + _to_int(source_inv.get("dat", {}).get("missing_date"), 0)
    )
    if miss_dos > 0:
        blockers.append({"code": "missing_dos", "rank": 4, "detail": str(miss_dos)})

    cjx = csv_docx_join_telemetry.get("matched_count") or 0
    ck = normalized_key_presence.get("csv_distinct_normalized_key_count") or 0
    dk = normalized_key_presence.get("docx_distinct_normalized_key_count") or 0
    if ck > 0 and dk > 0 and _to_int(cjx, 0) == 0:
        blockers.append({"code": "csv_docx_zero_overlap", "rank": 5, "detail": "{0}:{1}:{2}".format(overlap.get("csv_docx"), ck, dk)})

    dj = dat_csv_join_telemetry.get("matched_count") or 0
    dnk = normalized_key_presence.get("dat_distinct_normalized_key_count") or 0
    csv_k = normalized_key_presence.get("csv_distinct_normalized_key_count") or 0
    if csv_k > 0 and dnk > 0 and _to_int(dj, 0) == 0:
        blockers.append({"code": "dat_csv_zero_overlap", "rank": 6, "detail": "{0}:{1}:{2}".format(overlap.get("dat_csv"), dnk, csv_k)})

    amb = (_to_int(csv_docx_join_telemetry.get("ambiguous_count"), 0)
           + _to_int(dat_csv_join_telemetry.get("ambiguous_multi_dat_count"), 0))
    if amb > 0:
        blockers.append({"code": "ambiguous_join_keys", "rank": 7, "detail": str(amb)})

    blockers.sort(key=lambda b: _to_int(b.get("rank"), 99))
    return blockers


def _compose_samples(
        canonical_records,
        helpers,
        _membership_unused,
        ingress_stats,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        overlap_counts,
):
    extract_pid = helpers["extract_external_patient_id"]
    norm_date = helpers["normalize_surgery_date_key"]
    classify_fn = helpers["classify_external_patient_id_5_digit"]
    is_valid_pid = helpers["is_valid_external_patient_id_5_digit"]
    extract_dat_join = helpers.get("extract_dat_join_identity")

    try:
        from join_contract import extract_dat_join_identity
        if extract_dat_join is None:
            extract_dat_join = extract_dat_join_identity
    except Exception:
        pass

    samples = []
    counts = {}

    def _want(kind):
        counts[kind] = counts.get(kind, 0) + 1
        return counts[kind] <= SAMPLES_CAP_PER_KIND and len(samples) < TOTAL_SAMPLES_CAP

    mm_csv = {}
    mm_doc = {}
    mm_dat = {}

    csv_jkeys = []
    docx_jkeys = []
    dat_jkeys = []

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        raw = _load_json_dict(rec.get("canonical_json"))
        join_key_u = ""

        if ctype == "patient_csv_row":
            try:
                join_key_u = _csv_docx_join_key(extract_pid, norm_date, raw)
            except Exception:
                join_key_u = ""
            csv_jkeys.append(join_key_u)
            if join_key_u:
                mm_csv[join_key_u] = mm_csv.get(join_key_u, 0) + 1
        elif ctype == "docx_schedule":
            join_key_u = _docx_join_key_from_rec(rec, norm_date)
            docx_jkeys.append(join_key_u)
            if join_key_u:
                mm_doc[join_key_u] = mm_doc.get(join_key_u, 0) + 1
        elif ctype == "dat_record":
            try:
                join_key_u = _dat_join_key_extract(rec, extract_dat_join, norm_date)[0]
            except Exception:
                join_key_u = ""
            dat_jkeys.append(join_key_u or "")
            if join_key_u:
                mm_dat[join_key_u] = mm_dat.get(join_key_u, 0) + 1

    set_csv_keys = set([k for k in csv_jkeys if k])
    set_doc_keys = set([k for k in docx_jkeys if k])
    set_dat_keys = set([k for k in dat_jkeys if k])

    csv_idx = 0
    doc_idx = 0
    dat_idx = 0

    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        if ctype not in ("patient_csv_row", "docx_schedule", "dat_record"):
            continue

        raw = _load_json_dict(rec.get("canonical_json"))
        prov = _load_json_dict(rec.get("provenance_json"))
        loc = str(prov.get("source_ref") or prov.get("locator") or "")
        artifact_id = rec.get("artifact_id")

        pid = ""
        dos_raw = ""
        join_key = ""
        nk_safe = ""
        pv = {}

        ctype_l = ctype
        idx_token = ""

        if ctype == "patient_csv_row":
            try:
                pid = extract_pid(raw) if callable(extract_pid) else ""
                from patient_field_mapper import extract_surgery_date as _esd

                dos_raw = _esd(raw) if isinstance(raw, dict) else ""
                join_key = _csv_docx_join_key(extract_pid, norm_date, raw)
                nk_safe = str(norm_date(dos_raw) or "").strip() if dos_raw else ""
            except Exception:
                join_key = ""
            idx_token = "csv_record_index:{0}".format(csv_idx)
            csv_idx += 1

        elif ctype == "docx_schedule":
            join_key = _docx_join_key_from_rec(rec, norm_date)
            try:
                prv2 = prov
                sk_in = prv2.get("schedule_key") or raw.get("schedule_key")
                pid = str(prv2.get("patient_id") or raw.get("patient_id") or "").strip()
                nk_safe = str(norm_date(sk_in) if sk_in else "").strip()
            except Exception:
                nk_safe = ""
                pid = ""
            idx_token = "docx_record_index:{0}".format(doc_idx)
            doc_idx += 1

        else:
            try:
                join_key, dos_raw, nk_safe, pv = _dat_join_key_extract(rec, extract_dat_join, norm_date)
                pid_u, _ddr = extract_dat_join(raw) if callable(extract_dat_join) else ("", "")
                pid = str(pid_u or "").strip()
            except Exception:
                join_key = dos_raw = nk_safe = ""
                pid = ""
            rid = pv.get("record_index")
            idx_token = "dat_record_index:{0}".format(rid if rid is not None else dat_idx)
            dat_idx += 1

        hk = bool(join_key and join_key in set_csv_keys)
        hc = bool(join_key and join_key in set_doc_keys)
        hm = bool(join_key and join_key in set_dat_keys)

        reason_codes = []
        key_status = "absent"
        ambiguous_row = False

        if ctype == "patient_csv_row" and join_key and mm_csv.get(join_key, 0) > 1:
            ambiguous_row = True
            reason_codes.append("csv_duplicate_normalized_key_bucket")
        if ctype == "docx_schedule" and join_key and mm_doc.get(join_key, 0) > 1:
            ambiguous_row = True
            reason_codes.append("docx_duplicate_normalized_key_bucket")
        if ctype == "dat_record" and join_key and mm_dat.get(join_key, 0) > 1:
            ambiguous_row = True
            reason_codes.append("dat_duplicate_normalized_key_bucket")

        if not join_key:
            key_status = "missing_join_key_components"
            if not str(pid or "").strip():
                reason_codes.append("missing_patient_id")
            elif not nk_safe:
                reason_codes.append("missing_or_unparsed_date")
        else:
            pid_s_chk = str(pid or "").strip()
            if ctype == "patient_csv_row" and pid_s_chk and callable(is_valid_pid) and not is_valid_pid(pid_s_chk):
                key_status = "invalid_external_patient_id"
                reason_codes.append("csv_external_id_contract_violation")
            elif ctype == "dat_record" and pid_s_chk and callable(is_valid_pid) and not is_valid_pid(pid_s_chk):
                key_status = "invalid_external_patient_id"
                reason_codes.append("dat_external_id_contract_violation")
            elif ctype == "patient_csv_row":
                st_d = raw.get("docx_schedule_match_status") or ""
                st_a = raw.get("dat_alignment_status") or ""
                if st_d == "matched" or st_a == "matched":
                    key_status = "matched"
                elif st_d == "ambiguous":
                    ambiguous_row = True
                    key_status = "ambiguous_join_key_bucket"
                    reason_codes.append("csv_docx_ambiguous")
                elif st_a == "ambiguous_multi_dat":
                    ambiguous_row = True
                    key_status = "ambiguous_multi_dat"
                    reason_codes.append("dat_csv_ambiguous_multi_dat")
                elif st_a == "no_join_key":
                    key_status = "csv_row_no_alignment_key_in_annotation"
                    reason_codes.append("dat_alignment_missing_key_annotation")
                else:
                    key_status = "present"
            else:
                key_status = "present"

        jt = _join_key_token(join_key)
        pk_token = _patient_id_token(pid, classify_fn)

        skind = None
        if ambiguous_row and _want("ambiguous_key"):
            skind = "ambiguous_key"
        elif skind is None and key_status == "matched" and _want("matched"):
            skind = "matched"
        elif skind is None and ctype == "patient_csv_row" and raw.get("docx_schedule_match_status") == "csv_only" and join_key and _want("csv_only"):
            skind = "csv_only"
        elif skind is None and ctype == "docx_schedule" and join_key and join_key not in set_csv_keys and _want("docx_only"):
            skind = "docx_only"
        elif skind is None and ctype == "dat_record" and join_key and join_key not in set_csv_keys and _want("dat_only"):
            skind = "dat_only"
        elif skind is None and not join_key and _want("missing_key"):
            skind = "missing_key"
        elif skind is None and key_status == "invalid_external_patient_id" and _want("invalid_patient_id"):
            skind = "invalid_patient_id"

        if not skind:
            continue

        samples.append({
            "sample_kind": skind,
            "source_class": _infer_source_class(ctype_l),
            "source_file_token": _source_locator_evidence_token(loc),
            "artifact_id": artifact_id,
            "record_index": idx_token,
            "patient_id_shape": pk_token.get("shape"),
            "patient_id_diag_token": pk_token.get("diag_token"),
            "date_raw_shape": str(len(str(dos_raw or ""))),
            "normalized_date_safe": nk_safe or "",
            "join_key_token": jt if join_key else "",
            "key_status": key_status,
            "reason_codes": reason_codes,
            "has_csv": hk,
            "has_docx": hc,
            "has_dat": hm,
        })

    stats = ingress_stats if isinstance(ingress_stats, dict) else {}
    for cls in ("csv", "docx", "dat"):
        pr = stats.get(cls) if isinstance(stats.get(cls), dict) else {}
        prej = _to_int(pr.get("parse_rejected_artifacts"), 0)
        for i in range(min(prej, SAMPLES_CAP_PER_KIND)):
            if len(samples) >= TOTAL_SAMPLES_CAP:
                break
            samples.append({
                "sample_kind": "parse_reject",
                "source_class": cls,
                "source_file_token": "(parse_stage)",
                "artifact_id": None,
                "record_index": "parse:{0}:{1}".format(cls, i),
                "patient_id_shape": "n/a",
                "patient_id_diag_token": "parse_rejected_artifact",
                "date_raw_shape": "n/a",
                "normalized_date_safe": "",
                "join_key_token": "",
                "key_status": "parse_rejected",
                "reason_codes": ["qa_parse_failure"],
                "has_csv": False,
                "has_docx": False,
                "has_dat": False,
            })

    return samples


def build_layer1_text_pack(summary_blob, capped_samples_lines):
    lines = []

    evaluated = summary_blob.get("layer1_join_evaluated", True)

    lines.append("Layer 1 Join Debug Pack (developer/support)")
    lines.append("===========================================")
    lines.append("layer1_pipeline=parse_normalize_join (patient_id + surgery/service date)")
    lines.append("")
    lines.append("Key policy:")
    lines.append(" - normalized composite join key={0}".format(JOIN_KEY_POLICY))
    lines.append("")

    if not evaluated:
        lines.append("Layer 1 join evaluation:")
        lines.append(" - STATUS: NOT EVALUATED for this Phase D invocation.")
        br = summary_blob.get("layer1_evaluation_blocked_reason") or "unknown_blocker"
        lines.append(" - blocked_reason_code={0}".format(br))
        zr = summary_blob.get("phase_d_zero_selection_reason_codes") or []
        if isinstance(zr, list) and zr:
            lines.append(" - zero_selection_reason_codes={0}".format(",".join([str(z) for z in zr[:8]])))
        lines.append("")
        lines.append("Next developer action:")
        lines.append(
            " - Restore ingest selection (Phase B/C ingest into lab) until Phase D selects at least one artifact,"
            " then re-run Phase D.")
        lines.append("")
        lines.append("Capped sanitized examples:")
        lines.append(" - none (no canonical join rows materialized)")
        return "\n".join(lines)

    si = summary_blob.get("source_inventory") if isinstance(summary_blob.get("source_inventory"), dict) else {}
    for label in ("csv", "docx", "dat"):
        b = si.get(label) if isinstance(si.get(label), dict) else {}
        lines.append("{0}: total_canonical_records={1} keyable={2}".format(
            label,
            _to_int(b.get("total_canonical_records"), 0),
            _to_int(b.get("keyable_records"), 0),
        ))
        lines.append(
            "   missing_pid={0} invalid_pid={1} missing_date={2} parse_rejected_artifacts={3}".format(
                _to_int(b.get("missing_patient_id"), 0),
                _to_int(b.get("invalid_patient_id"), 0),
                _to_int(b.get("missing_date"), 0),
                _to_int(b.get("parse_rejected_artifacts"), 0),
            )
        )
    lines.append("")

    om = summary_blob.get("overlap_matrix") if isinstance(summary_blob.get("overlap_matrix"), dict) else {}
    lines.append("Overlap matrix (distinct normalized keys):")
    for k in sorted(om.keys()):
        lines.append(" - {0}={1}".format(k, _to_int(om.get(k), 0)))

    nk = summary_blob.get("normalized_key_counts") if isinstance(summary_blob.get("normalized_key_counts"), dict) else {}
    lines.append("")
    lines.append("Normalized key counts:")
    for k in sorted(nk.keys()):
        lines.append(" - {0}={1}".format(k, _to_int(nk.get(k), 0)))

    lines.append("")
    lines.append("Top blockers (ranked):")
    for b in summary_blob.get("ranked_join_blockers") or []:
        if not isinstance(b, dict):
            continue
        lines.append(" - [{0}] {1}: {2}".format(
            _to_int(b.get("rank"), 0),
            b.get("code"),
            str(b.get("detail") or "")[:120],
        ))

    lines.append("")
    lines.append("Capped sanitized examples:")
    lines.extend(capped_samples_lines[:20])

    lines.append("")
    lines.append("Next developer action:")
    top = summary_blob.get("layer1_top_blocker") or ""

    hints = []
    if "invalid_external_patient_id" in top:
        hints.append(
            "Enforce strictly 5-digit external patient identifiers on DAT and CSV per contract; rerun Phase D.")
    if "csv_docx_zero_overlap" in top or str(summary_blob.get("layer1_csv_docx_overlap_count", "")) == "0":
        if _to_int(summary_blob.get("csv_docx_overlap_count_fallback"), -1) == 0:
            hints.append("Verify DOCX locator scope and Surgery Date normalization against CSV DOS align.")
    if "dat_csv_zero_overlap" in top:
        hints.append("Compare DAT payer/DOS anchors with CSV rows; reconcile Medisoft PATID+DOS aliases.")
    if "dat_parse_rejects" in top or top.startswith("dat_parse"):
        hints.append("Repair tuple parse / ingest for DAT blobs; inspect qa_reject_samples for parse diagnostics.")

    hints.append(
        "Open layer1_join_debug_summary JSON for telemetry and layer1_join_debug_samples JSONL"
        " for sanitized row sketches.")
    hints.append(
        "Do not expose raw PHI: keep operator-facing Artifact Triage Pack + Follow recommendation; developers use packs.")

    for h in hints[:6]:
        lines.append(" - {0}".format(h))

    return "\n".join(lines)


def write_layer1_join_debug_artifacts(
        reports_dir,
        run_id,
        canonical_records,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        patient_field_mapper_mod,
        ingress_stats=None,
        phase_run_ids=None,
        layer1_evaluation_blocked_reason=None,
        zero_selection_reason_codes=None,
):
    """
    Write layer1_join_debug_* files and return flattened keys for qa_canonical_summary.
    """
    out = {}

    ingress_stats = ingress_stats if isinstance(ingress_stats, dict) else {}
    rid = str(run_id or "").strip()
    paths = {}

    iso_fn = None
    try:
        from phase_d_common import iso_utc_now
        iso_fn = iso_utc_now
    except Exception:
        iso_fn = None

    def _iso_now():
        if iso_fn:
            try:
                return iso_fn()
            except Exception:
                pass
        import time as _time
        return _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime())

    generated_at = _iso_now()

    join_extract_fn = None
    try:
        from join_contract import extract_dat_join_identity
        join_extract_fn = extract_dat_join_identity
    except Exception:
        join_extract_fn = lambda d: ("", "")  # noqa: E731 simplification guarded

    inv = {"csv": {}, "docx": {}, "dat": {}}
    helpers = None
    try:
        inv, helpers = _source_inventory(canonical_records, ingress_stats, patient_field_mapper_mod, join_extract_fn)
    except Exception:
        inv = {"csv": {}, "docx": {}, "dat": {}}

    if helpers is None:
        classify_fn_dummy = getattr(
            patient_field_mapper_mod,
            "classify_external_patient_id_5_digit",
            lambda v, s=None: {})
        helpers = {
            "extract_external_patient_id": lambda r: "",
            "normalize_surgery_date_key": lambda v: "",
            "is_valid_external_patient_id_5_digit": lambda v: False,
            "classify_external_patient_id_5_digit": classify_fn_dummy,
            "extract_dat_join_identity": join_extract_fn,
        }

    mm_csv_mm = []
    mm_doc_mm = []
    mm_dat_mm = []
    for rec in canonical_records or []:
        ctype = rec.get("canonical_type") or ""
        raw = _load_json_dict(rec.get("canonical_json"))
        if ctype == "patient_csv_row":
            try:
                j = _csv_docx_join_key(helpers["extract_external_patient_id"], helpers["normalize_surgery_date_key"], raw)
            except Exception:
                j = ""
            if j:
                mm_csv_mm.append(j)
        elif ctype == "docx_schedule":
            j = _docx_join_key_from_rec(rec, helpers["normalize_surgery_date_key"])
            if j:
                mm_doc_mm.append(j)
        elif ctype == "dat_record":
            try:
                j, _, _, _ = _dat_join_key_extract(rec, join_extract_fn, helpers["normalize_surgery_date_key"])
            except Exception:
                j = ""
            if j:
                mm_dat_mm.append(j)

    mm_counts = (
        ("csv_source", mm_csv_mm),
        ("docx_source", mm_doc_mm),
        ("dat_source", mm_dat_mm),
    )
    dup_summary = {}
    for label, seq in mm_counts:
        m = _count_multimap(seq)
        dup_summary[label] = _ambiguous_distinct_keys(m)

    csv_keys = [k for k in mm_csv_mm if k]
    docx_keys = [k for k in mm_doc_mm if k]
    dat_keys = [k for k in mm_dat_mm if k]

    overlap = _overlap_metrics(csv_keys, docx_keys, dat_keys)
    nk_presence = _normalized_key_presence(canonical_records, helpers)

    dat_keyable = _to_int(inv.get("dat", {}).get("keyable_records"), 0)

    evaluated = True
    blocked_reason = layer1_evaluation_blocked_reason or ""
    zsc = zero_selection_reason_codes if isinstance(zero_selection_reason_codes, list) else []

    if not canonical_records and blocked_reason:
        evaluated = False

    csv_docx_join_telemetry = csv_docx_join_telemetry or {}
    dat_csv_join_telemetry = dat_csv_join_telemetry or {}

    blockers = _rank_blockers(
        ingress_stats,
        inv,
        overlap,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        nk_presence,
        dat_keyable,
    )

    top_blocker = str(blockers[0].get("code") or "") if blockers else ""

    summary_core = {
        "schema_version": LAYER1_SCHEMA_VERSION,
        "run_id": rid,
        "generated_at_utc": generated_at,
        "join_key_policy": JOIN_KEY_POLICY,
        "phase_run_ids": dict(phase_run_ids) if isinstance(phase_run_ids, dict) else {},
        "layer1_join_evaluated": evaluated,
        "layer1_evaluation_blocked_reason": blocked_reason or ("" if evaluated else "no_canonical_records"),
        "phase_d_zero_selection_reason_codes": list(zsc),
        "source_inventory": inv,
        "normalized_key_counts": nk_presence,
        "overlap_matrix": overlap,
        "duplicate_ambiguous_key_counts": dup_summary,
        "ranked_join_blockers": blockers,
        "layer1_top_blocker": top_blocker,
        "layer1_csv_docx_overlap_count": overlap.get("csv_docx", 0),
        "layer1_dat_csv_overlap_count": overlap.get("dat_csv", 0),
        "layer1_dat_keyable_count": dat_keyable,
        "layer1_invalid_external_pressure": _to_int(dat_csv_join_telemetry.get("invalid_external_id_join_block_count"), 0),
        "csv_docx_join_telemetry_ref": {
            "matched_count": _to_int(csv_docx_join_telemetry.get("matched_count"), 0),
            "primary_join_blocker_class": str(csv_docx_join_telemetry.get("primary_join_blocker_class") or ""),
        },
        "dat_csv_join_telemetry_ref": {
            "matched_count": _to_int(dat_csv_join_telemetry.get("matched_count"), 0),
            "primary_join_blocker_class": str(dat_csv_join_telemetry.get("primary_join_blocker_class") or ""),
        },
    }

    # samples
    try:
        samples = _compose_samples(
            canonical_records,
            helpers,
            {},
            ingress_stats,
            csv_docx_join_telemetry,
            dat_csv_join_telemetry,
            overlap,
        )
    except Exception:
        samples = []

    sample_lines = []
    for s in samples:
        try:
            sample_lines.append(json.dumps(s, ensure_ascii=False))
        except Exception:
            pass

    text_pack = build_layer1_text_pack(dict(summary_core, csv_docx_overlap_count_fallback=overlap.get("csv_docx", 0)), sample_lines)

    def _write(p, text):
        try:
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(text)
            return True
        except (IOError, OSError):
            return False

    sum_path = os.path.join(reports_dir, "layer1_join_debug_summary_{0}.json".format(rid))
    smp_path = os.path.join(reports_dir, "layer1_join_debug_samples_{0}.jsonl".format(rid))
    txt_path = os.path.join(reports_dir, "layer1_join_debug_pack_{0}.txt".format(rid))

    summary_core["layer1_join_debug_samples_path"] = smp_path
    summary_core["layer1_join_debug_summary_path"] = sum_path
    summary_core["layer1_join_debug_pack_path"] = txt_path

    ok_sum = _write(sum_path, json.dumps(summary_core, ensure_ascii=False, indent=2, sort_keys=True))
    ok_smp = _write(smp_path, "\n".join(sample_lines) + ("\n" if sample_lines else ""))
    ok_txt = _write(txt_path, text_pack + "\n")

    generated = bool(ok_sum and ok_smp and ok_txt)

    flat_for_qa = {
        "layer1_join_debug_generated": generated,
        "layer1_join_debug_pack_path": txt_path if ok_txt else "",
        "layer1_join_debug_summary_path": sum_path if ok_sum else "",
        "layer1_join_debug_samples_path": smp_path if ok_smp else "",
        "layer1_top_blocker": summary_core.get("layer1_top_blocker") or "",
        "layer1_csv_docx_overlap_count": summary_core.get("layer1_csv_docx_overlap_count") or 0,
        "layer1_dat_csv_overlap_count": summary_core.get("layer1_dat_csv_overlap_count") or 0,
        "layer1_dat_keyable_count": summary_core.get("layer1_dat_keyable_count") or 0,
        "layer1_invalid_external_pressure": summary_core.get("layer1_invalid_external_pressure") or 0,
    }

    out["summary_fields"] = flat_for_qa
    out["summary_blob"] = summary_core
    out["paths"] = {"summary": sum_path, "samples": smp_path, "text": txt_path}
    return out


def finalize_layer1_qa_summary_fields(
        bundle_out,
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        phase_d_success=True,
        recommendation_kind=""):
    flat = dict((bundle_out or {}).get("summary_fields") or {})
    flat["layer1_support_bundle_attachment_recommended"] = compute_layer1_support_bundle_attachment_recommended(
        {
            "layer1_join_debug_generated": flat.get("layer1_join_debug_generated"),
            "layer1_top_blocker": flat.get("layer1_top_blocker") or "",
            "layer1_invalid_external_pressure": flat.get("layer1_invalid_external_pressure"),
            "layer1_dat_keyable_count": flat.get("layer1_dat_keyable_count"),
        },
        csv_docx_join_telemetry,
        dat_csv_join_telemetry,
        phase_d_ok=phase_d_success,
        recommendation_kind=recommendation_kind,
    )
    return flat


def format_layer1_triage_lines(phase_d_summary_payload):
    """
    Short lines for artifact triage pack (operator sees pointer; details are developer-facing).
    """
    if not isinstance(phase_d_summary_payload, dict):
        return []
    if not phase_d_summary_payload.get("layer1_join_debug_generated"):
        return []
    lines = []
    lines.append("Layer 1 join debug (developer/support; not operator diagnostics):")
    lines.append(
        " - pack={0}".format(
            _source_locator_evidence_token(phase_d_summary_payload.get("layer1_join_debug_pack_path") or "")
        )
    )
    lines.append(" - top_blocker={0}".format(str(phase_d_summary_payload.get("layer1_top_blocker") or "-")))
    lines.append(
        " - overlap_csv_docx={0} overlap_dat_csv={1} dat_keyable={2}".format(
            _to_int(phase_d_summary_payload.get("layer1_csv_docx_overlap_count"), 0),
            _to_int(phase_d_summary_payload.get("layer1_dat_csv_overlap_count"), 0),
            _to_int(phase_d_summary_payload.get("layer1_dat_keyable_count"), 0),
        )
    )
    attach = phase_d_summary_payload.get("layer1_support_bundle_attachment_recommended")
    lines.append(" - support_bundle_attachment_recommended={0}".format(bool(attach)))
    return lines


def collect_existing_layer1_paths_from_qa_summary(qa_summary_dict):
    """Return existing file paths for support bundle attachment."""
    out = []
    if not isinstance(qa_summary_dict, dict):
        return out
    if not qa_summary_dict.get("layer1_join_debug_generated"):
        return out
    for key in ("layer1_join_debug_pack_path", "layer1_join_debug_summary_path", "layer1_join_debug_samples_path"):
        p = str(qa_summary_dict.get(key) or "").strip()
        if p and os.path.isfile(p):
            out.append(p)
    return out
