"""Static contract checks for the GAS/local MediLink Gmail handoff.

These checks cover Apps Script and HTML assets that are difficult to execute in
the Python test runner, but still need regression coverage for the handoff
protocol.
"""
from __future__ import absolute_import

import os


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read_repo_file(*parts):
    path = os.path.join(PROJECT_ROOT, *parts)
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def test_gas_direct_fallback_actions_are_available_and_clear_stale_results():
    main_js = _read_repo_file("MediLink", "main.js")

    assert "const ACTION_GET_DOCX_RESULTS = 'get_docx_results';" in main_js
    assert "case ACTION_GET_DOCX_RESULTS:" in main_js
    assert "function handleGetDocxResults(payload)" in main_js
    assert "function storeDownloadedEmailsForTransfer(downloadedEmails, telemetry, reason)" in main_js
    assert "deleteProperty('docxResult')" in main_js
    assert "return handleProcessDocx(payload);" in main_js


def test_browser_failure_telemetry_preserves_fetch_error_context_for_gas_logs():
    webapp_html = _read_repo_file("MediLink", "webapp.html")
    main_js = _read_repo_file("MediLink", "main.js")

    assert "failurePayload.downloadFailure = {" in webapp_html
    assert "stage: 'webapp_download_fetch_failed'" in webapp_html
    assert "failurePayload.downloadSuccess = false;" in webapp_html
    assert "downloadFailure: failureSource ? {" in main_js
    assert "errorMessage: String(failureSource.errorMessage || '')" in main_js
