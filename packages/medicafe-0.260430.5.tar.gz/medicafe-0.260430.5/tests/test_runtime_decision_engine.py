# tests/test_runtime_decision_engine.py
"""Tests for MediLink.runtime_decision_engine transfer policy."""
from __future__ import absolute_import

import os
import sys
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from MediLink.runtime_decision_engine import resolve_transfer_runtime_policy


class TestResolveTransferRuntimePolicy(unittest.TestCase):

    def test_windows_xp_non_managed_ca_uses_direct_gas_primary(self):
        """XP + non-managed_ca still prefers direct_gas (legacy path)."""
        medi = {}
        with patch('MediLink.runtime_decision_engine.platform.system', return_value='Windows'):
            with patch('MediLink.runtime_decision_engine.platform.release', return_value='5.1.2600'):
                policy = resolve_transfer_runtime_policy(medi, False, 'self_signed')
        self.assertEqual(policy['primary_transfer_route'], 'direct_gas')
        self.assertEqual(policy['secondary_transfer_route'], 'browser_handoff')
        self.assertEqual(policy['profile'], 'windows_xp_https_legacy_tls')
        self.assertIn('xp_legacy_tls_profile', policy['reasons'])

    def test_windows_xp_managed_ca_keeps_browser_primary_with_direct_gas_fallback(self):
        medi = {}
        with patch('MediLink.runtime_decision_engine.platform.system', return_value='Windows'):
            with patch('MediLink.runtime_decision_engine.platform.release', return_value='5.1.2600'):
                with patch('MediLink.runtime_decision_engine.shutil.which', return_value=None):
                    policy = resolve_transfer_runtime_policy(medi, False, 'managed_ca')
        self.assertEqual(policy['primary_transfer_route'], 'browser_handoff')
        self.assertEqual(policy['secondary_transfer_route'], 'direct_gas')
        self.assertEqual(policy['profile'], 'windows_managed_ca_browser_handoff_with_direct_gas_fallback')
        self.assertTrue(policy['direct_gas_fallback_enabled'])
        self.assertIn('managed_ca_browser_handoff_primary', policy['reasons'])
        self.assertIn('windows_xp_under_managed_ca', policy['reasons'])

    def test_modern_windows_managed_ca_keeps_browser_primary_with_direct_gas_fallback(self):
        medi = {}
        with patch('MediLink.runtime_decision_engine.platform.system', return_value='Windows'):
            with patch('MediLink.runtime_decision_engine.platform.release', return_value='10'):
                policy = resolve_transfer_runtime_policy(medi, False, 'managed_ca')
        self.assertEqual(policy['primary_transfer_route'], 'browser_handoff')
        self.assertEqual(policy['secondary_transfer_route'], 'direct_gas')
        self.assertEqual(policy['profile'], 'windows_managed_ca_browser_handoff_with_direct_gas_fallback')
        self.assertTrue(policy['direct_gas_fallback_enabled'])
        self.assertIn('managed_ca_browser_handoff_primary', policy['reasons'])

    def test_modern_windows_managed_ca_missing_certutil_still_has_fallback(self):
        medi = {}
        with patch('MediLink.runtime_decision_engine.platform.system', return_value='Windows'):
            with patch('MediLink.runtime_decision_engine.platform.release', return_value='10'):
                with patch('MediLink.runtime_decision_engine.shutil.which', return_value=None):
                    policy = resolve_transfer_runtime_policy(medi, False, 'managed_ca')
        self.assertEqual(policy['primary_transfer_route'], 'browser_handoff')
        self.assertTrue(policy['direct_gas_fallback_enabled'])
        self.assertIn('certutil_missing_managed_ca', policy['reasons'])

    def test_modern_windows_non_managed_default_profile(self):
        medi = {}
        with patch('MediLink.runtime_decision_engine.platform.system', return_value='Windows'):
            with patch('MediLink.runtime_decision_engine.platform.release', return_value='10'):
                policy = resolve_transfer_runtime_policy(medi, False, 'self_signed')
        self.assertEqual(policy['primary_transfer_route'], 'browser_handoff')
        self.assertEqual(policy['profile'], 'default_managed_https')
        self.assertTrue(policy['direct_gas_fallback_enabled'])

    def test_http_mode_overrides_xp_profile(self):
        medi = {}
        with patch('MediLink.runtime_decision_engine.platform.system', return_value='Windows'):
            with patch('MediLink.runtime_decision_engine.platform.release', return_value='5.1.2600'):
                policy = resolve_transfer_runtime_policy(medi, True, 'managed_ca')
        self.assertEqual(policy['profile'], 'http_mode_local_loopback')
        self.assertEqual(policy['primary_transfer_route'], 'browser_handoff')


if __name__ == '__main__':
    unittest.main()
